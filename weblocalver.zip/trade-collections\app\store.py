"""Stateful store behind every screen and every JSON route.

This is the swap point. Replace ``CaseStore`` with an implementation that talks
to WFMS / TradePay for intake, the port directory for code resolution, OEMS
(Autobahn processing instructions) for tariffs and TF3 for the hand-off. The
templates and the JavaScript do not change.
"""

from __future__ import annotations

import secrets
import threading
from datetime import datetime, timedelta
from typing import Iterable

from .models import (
    AuditEntry,
    CaseStatus,
    ChargeLine,
    Charges,
    Check,
    ClientTariff,
    CollectionCase,
    ExtractedField,
    PortEntry,
    Query,
    RuleSet,
    Stage,
)
from .seed import (
    FX,
    PORT_BY_CODE,
    PORTS,
    RULE_SETS,
    TARIFF_BY_CUSTOMER,
    TARIFFS,
    build_cases,
)

SORTABLE = {
    "case_id":    lambda c: c.case_id,
    "received":   lambda c: c.received_at,
    "customer":   lambda c: c.customer.lower(),
    "principal":  lambda c: c.principal,
    "status":     lambda c: c.status.value,
    "sla":        lambda c: c.sla_due or datetime.max,
    "priority":   lambda c: {"high": 0, "medium": 1, "low": 2}[c.priority],
    "charges":    lambda c: c.charges.total if c.charges.lines else -1.0,
    # how much is standing in the way — ascending puts the nearly-clear first
    "exceptions": lambda c: len(c.action_items),
    # how far the automated checks got
    "checks":     lambda c: (c.checks_passed / c.checks_total) if c.checks_total else 0.0,
    "source":     lambda c: c.source,
    "boe":        lambda c: c.boe_number,
    "currency":   lambda c: (c.currency, -c.principal),
    "collection": lambda c: (c.direction, c.terms),
    # unassigned sorts last either way, so it never buries real owners
    "assignee":   lambda c: (c.assignee is None, (c.assignee or "").lower()),
}

VIEWS: dict[str, dict] = {
    "all": {"label": "All open", "statuses": None},
    "mine": {"label": "My queue", "statuses": None, "mine": True},
    "attention": {"label": "Needs attention", "statuses": [CaseStatus.NEEDS_ATTENTION]},
    "ready": {"label": "Ready for review", "statuses": [CaseStatus.READY_FOR_REVIEW]},
    "processing": {"label": "Processing", "statuses": [CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING]},
    "checker": {"label": "Checker queue", "statuses": [CaseStatus.IN_CHECKER_QUEUE]},
    "completed": {"label": "Completed", "statuses": [CaseStatus.COMPLETED]},
}

OPEN_STATUSES = (
    CaseStatus.RECEIVED,
    CaseStatus.AI_PROCESSING,
    CaseStatus.NEEDS_ATTENTION,
    CaseStatus.READY_FOR_REVIEW,
    CaseStatus.RETURNED,
)


class Session:
    """Who is driving. A real deployment reads this from SSO."""

    def __init__(self) -> None:
        self.name = "R. Kadiam"
        self.initials = "RK"
        self.role = "Maker"
        self.desk = "Trade Finance Ops"

    def switch(self, role: str) -> None:
        self.role = "Checker" if role.lower() == "checker" else "Maker"
        if self.role == "Checker":
            self.name, self.initials = "S. Iyer", "SI"
        else:
            self.name, self.initials = "R. Kadiam", "RK"


class CaseStore:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._cases: dict[str, CollectionCase] = {c.case_id: c for c in build_cases()}
        self._query_seq = 4090
        self._undo: dict[str, tuple[str, CollectionCase, datetime]] = {}
        self.session = Session()

    # ------------------------------------------------------------------ undo
    # A workflow transition is reversible for a short window. Snapshotting the
    # whole case and putting it back is simpler, and safer, than unpicking the
    # status, assignee, stage states and audit entries one at a time.
    UNDO_TTL = timedelta(seconds=90)

    def _snapshot(self, case: CollectionCase) -> str:
        now = datetime.now()
        for stale in [t for t, (_, _, at) in self._undo.items() if now - at > self.UNDO_TTL]:
            self._undo.pop(stale, None)
        token = secrets.token_urlsafe(9)
        self._undo[token] = (case.case_id, case.model_copy(deep=True), now)
        return token

    def undo(self, token: str) -> CollectionCase | None:
        """Single use. Returns the restored case, or None if unknown or expired."""
        entry = self._undo.pop(token, None)
        if entry is None:
            return None
        case_id, snapshot, at = entry
        if datetime.now() - at > self.UNDO_TTL:
            return None
        self._cases[case_id] = snapshot
        return snapshot

    # ------------------------------------------------------------------ read
    def _tick(self) -> None:
        """Advance any case the AI pipeline is still working on."""
        now = datetime.now()
        for case in self._cases.values():
            if case.status is not CaseStatus.AI_PROCESSING or case.processing_started is None:
                continue
            elapsed = (now - case.processing_started).total_seconds()
            frac = elapsed / case.processing_seconds

            if frac >= 1.0:
                self._finish_processing(case, now)
            elif frac >= 0.66:
                self._set_stages(case, ["done", "done", "done", "running", "queued"])
            elif frac >= 0.33:
                self._set_stages(case, ["done", "done", "running", "queued", "queued"])

    @staticmethod
    def _set_stages(case: CollectionCase, states: list[str]) -> None:
        for stage, state in zip(case.stages, states):
            stage.state = state  # type: ignore[assignment]

    def _finish_processing(self, case: CollectionCase, now: datetime) -> None:
        case.status = (
            CaseStatus.NEEDS_ATTENTION if case.open_exceptions else CaseStatus.READY_FOR_REVIEW
        )
        case.processing_started = None
        self._set_stages(case, ["done", "done", "done", "done", "done"])
        if case.charges.status == "pending":
            case.charges = self._calculate_charges(case, now)
        case.audit.append(AuditEntry(
            at=now, actor="AI engine", role="AI", action="Processing complete",
            detail=f"{case.checks_passed} of {case.checks_total} rule sets passed; "
                   f"case moved to {case.status_label.lower()}."))

    def progress(self, case: CollectionCase) -> int:
        if case.status is not CaseStatus.AI_PROCESSING or case.processing_started is None:
            return 100 if case.status not in (CaseStatus.RECEIVED,) else 0
        elapsed = (datetime.now() - case.processing_started).total_seconds()
        return max(5, min(97, int(elapsed / case.processing_seconds * 100)))

    def all_cases(self) -> list[CollectionCase]:
        with self._lock:
            self._tick()
            return list(self._cases.values())

    def get(self, case_id: str) -> CollectionCase | None:
        with self._lock:
            self._tick()
            return self._cases.get(case_id.upper())

    def list_cases(
        self,
        *,
        view: str = "all",
        search: str | None = None,
        source: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        assignee: str | None = None,
        sort: str = "received",
        direction: str = "desc",
    ) -> list[CollectionCase]:
        rows = self.all_cases()
        spec = VIEWS.get(view, VIEWS["all"])

        if spec.get("statuses"):
            rows = [c for c in rows if c.status in spec["statuses"]]
        elif view == "all":
            rows = [c for c in rows if c.status in OPEN_STATUSES]

        if spec.get("mine"):
            rows = [c for c in rows if c.assignee == self.session.name]

        if source and source != "all":
            rows = [c for c in rows if c.source == source]
        if status and status != "all":
            rows = [c for c in rows if c.status.value == status]
        if priority and priority != "all":
            rows = [c for c in rows if c.priority == priority]
        if assignee and assignee != "all":
            rows = [c for c in rows if (c.assignee or "") == assignee]

        if search:
            n = search.strip().lower()
            rows = [
                c for c in rows
                if n in c.case_id.lower() or n in c.customer.lower()
                or n in c.customer_id.lower() or n in c.boe_number.lower()
                or n in c.tf3_reference.lower()
                or any(n in f.value.lower() for f in c.fields)
            ]

        key = SORTABLE.get(sort, SORTABLE["received"])
        rows.sort(key=key, reverse=(direction == "desc"))
        return rows

    def counts(self) -> dict[str, int]:
        rows = self.all_cases()
        mine = self.session.name
        return {
            "all": sum(1 for c in rows if c.status in OPEN_STATUSES),
            "mine": sum(1 for c in rows if c.assignee == mine and c.status in OPEN_STATUSES),
            "attention": sum(1 for c in rows if c.status is CaseStatus.NEEDS_ATTENTION),
            "ready": sum(1 for c in rows if c.status is CaseStatus.READY_FOR_REVIEW),
            "processing": sum(1 for c in rows if c.status in
                              (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING)),
            "checker": sum(1 for c in rows if c.status is CaseStatus.IN_CHECKER_QUEUE),
            "completed": sum(1 for c in rows if c.status is CaseStatus.COMPLETED),
            "queries": sum(len(c.open_queries) for c in rows),
            "breached": sum(1 for c in rows if c.sla_state == "breached"),
        }

    def queries(self) -> list[tuple[CollectionCase, Query]]:
        out: list[tuple[CollectionCase, Query]] = []
        for case in self.all_cases():
            for q in case.queries:
                out.append((case, q))
        out.sort(key=lambda pair: pair[1].raised_at, reverse=True)
        return out

    # ----------------------------------------------------------- reference
    @staticmethod
    def ports(search: str | None = None) -> list[PortEntry]:
        if not search:
            return PORTS
        n = search.strip().lower()
        return [p for p in PORTS if n in p.code.lower() or n in p.name.lower()
                or n in p.country.lower()]

    @staticmethod
    def tariffs() -> list[ClientTariff]:
        return TARIFFS

    @staticmethod
    def rule_sets() -> list[RuleSet]:
        return RULE_SETS

    # ----------------------------------------------------------- mutations
    def _log(self, case: CollectionCase, action: str, detail: str, role: str | None = None) -> None:
        case.audit.append(AuditEntry(
            at=datetime.now(), actor=self.session.name,
            role=role or self.session.role, action=action, detail=detail))

    def _calculate_charges(self, case: CollectionCase, when: datetime | None = None) -> Charges:
        tariff = TARIFF_BY_CUSTOMER.get(case.customer_id)
        if tariff is None:
            return case.charges
        rate = FX.get(case.currency, 83.0)
        inr = case.principal * rate
        commission = max(inr * tariff.commission_bps / 10_000, tariff.minimum_inr)
        fees = commission + tariff.swift_inr + tariff.handling_inr
        return Charges(
            tariff_ref=tariff.tariff_ref,
            status="calculated",
            calculated_at=when or datetime.now(),
            lines=[
                ChargeLine(code="COMM", label="Collection commission",
                           basis=f"{tariff.commission_bps:.4g} bps on {case.currency} "
                                 f"{case.principal:,.0f} @ {rate:.2f}",
                           amount_inr=round(commission, 2)),
                ChargeLine(code="SWFT", label="Swift / correspondence",
                           basis="Flat per collection", amount_inr=tariff.swift_inr),
                ChargeLine(code="HNDL", label="Document handling",
                           basis=f"Flat, {tariff.product}", amount_inr=tariff.handling_inr),
                ChargeLine(code="GST", label="GST",
                           basis=f"{tariff.gst_pct:.0f}% on fee lines",
                           amount_inr=round(fees * tariff.gst_pct / 100, 2)),
            ],
        )

    def start_processing(self, case: CollectionCase) -> None:
        case.status = CaseStatus.AI_PROCESSING
        case.processing_started = datetime.now()
        case.processing_seconds = 18
        self._set_stages(case, ["done", "done", "running", "queued", "queued"])
        self._log(case, "Processing started", "Maker released the case to the AI pipeline.", role="Maker")

    def assign(self, case: CollectionCase, to: str | None) -> None:
        case.assignee = to
        self._log(case, "Assigned", f"Case assigned to {to}." if to else "Case unassigned.")

    def update_field(self, case: CollectionCase, key: str, value: str, note: str | None) -> ExtractedField | None:
        field = case.field(key)
        if field is None:
            return None
        previous = field.value or "(empty)"
        if field.original_value is None:
            field.original_value = field.value
        field.value = value
        field.status = "overridden"
        field.note = note or f"Maker set this value; extraction read {previous}."
        field.confidence = 1.0
        self._log(case, "Field overridden", f"{field.label}: {previous} -> {value}.")
        self._revalidate(case)
        return field

    def accept_field(self, case: CollectionCase, key: str) -> ExtractedField | None:
        field = case.field(key)
        if field is None:
            return None
        field.status = "accepted"
        self._log(case, "Field accepted", f"{field.label} confirmed against the source document.")
        return field

    def resolve_port(self, case: CollectionCase, key: str, code: str) -> ExtractedField | None:
        port = PORT_BY_CODE.get(code.upper())
        field = case.field(key)
        if port is None or field is None:
            return None
        field.value = port.name
        field.status = "overridden"
        field.confidence = 1.0
        field.note = f"Resolved from the port directory: {port.code} - {port.name}, {port.country}."
        self._log(case, "Port resolved",
                  f"{field.label} set to {port.name} ({port.code}) from the port directory.")
        # A consistency failure raised purely because a port would not resolve
        # clears once every port field carries a value.
        if not case.unresolved_fields:
            for check in case.checks:
                if (check.group == "consistency" and check.status == "fail"
                        and "did not resolve" in check.detail):
                    check.status = "resolved"
                    check.resolution = f"Port resolved to {port.name} ({port.code})."
                    check.resolved_by = self.session.name
                    check.resolved_at = datetime.now()
        self._revalidate(case)
        return field

    def resolve_check(self, case: CollectionCase, check_id: str, resolution: str) -> Check | None:
        check = next((c for c in case.checks if c.id == check_id), None)
        if check is None or not check.blocking:
            return None
        check.status = "resolved"
        check.resolution = resolution
        check.resolved_by = self.session.name
        check.resolved_at = datetime.now()
        self._log(case, "Exception resolved", f"{check.label}: {resolution}")
        self._revalidate(case)
        return check

    def _revalidate(self, case: CollectionCase) -> None:
        """Recompute the case state after a maker edit."""
        if case.status in (CaseStatus.IN_CHECKER_QUEUE, CaseStatus.COMPLETED):
            return
        if case.open_exceptions or case.unresolved_fields:
            case.status = CaseStatus.NEEDS_ATTENTION
            return
        if case.charges.status != "calculated":
            case.charges = self._calculate_charges(case)
            case.audit.append(AuditEntry(
                at=datetime.now(), actor="AI engine", role="AI", action="Charges calculated",
                detail=f"Tariff {case.charges.tariff_ref} applied; "
                       f"total INR {case.charges.total:,.2f}."))
            for stage in case.stages:
                if stage.key == "charges":
                    stage.state = "done"
        case.status = CaseStatus.READY_FOR_REVIEW
        for stage in case.stages:
            if stage.key == "checks":
                stage.state = "done"

    def recalculate_charges(self, case: CollectionCase) -> Charges:
        case.charges = self._calculate_charges(case)
        self._log(case, "Charges recalculated",
                  f"Tariff {case.charges.tariff_ref} reapplied; total INR {case.charges.total:,.2f}.")
        return case.charges

    def waive_charge(self, case: CollectionCase, code: str, reason: str) -> Charges:
        for line in case.charges.lines:
            if line.code == code:
                line.amount_inr = 0.0
                line.overridden = True
                line.waiver_reason = reason
                self._log(case, "Charge waived", f"{line.label} waived: {reason}")
        return case.charges

    def raise_query(self, case: CollectionCase, reason: str, recipient: str,
                    check_id: str | None) -> Query:
        self._query_seq += 1
        query = Query(
            query_id=f"QRY-{self._query_seq}", check_id=check_id, recipient=recipient,
            reason=reason, raised_by=self.session.name, raised_at=datetime.now())
        case.queries.append(query)
        case.status = CaseStatus.NEEDS_ATTENTION
        self._log(case, "Query raised", f"{query.query_id} to {recipient}: {reason}")
        return query

    def close_query(self, case: CollectionCase, query_id: str, response: str) -> Query | None:
        query = next((q for q in case.queries if q.query_id == query_id), None)
        if query is None:
            return None
        query.status = "answered"
        query.response = response
        self._log(case, "Query answered", f"{query.query_id}: {response}")
        self._revalidate(case)
        return query

    def validate(self, case: CollectionCase, note: str | None) -> tuple[bool, str, str | None]:
        if case.blockers:
            return False, "Resolve before validating: " + "; ".join(case.blockers) + ".", None
        token = self._snapshot(case)
        case.status = CaseStatus.IN_CHECKER_QUEUE
        case.assignee = case.assignee or self.session.name
        self._log(case, "Validated",
                  note or "Source data reviewed and exceptions cleared; released to the checker queue.")
        case.audit.append(AuditEntry(
            at=datetime.now(), actor="TF3", role="System", action="TF3 updated",
            detail=f"Final data and charges posted against {case.tf3_reference}."))
        for stage in case.stages:
            stage.state = "done"
        return (True,
                f"{case.case_id} validated. TF3 {case.tf3_reference} updated and the case "
                f"is with the checker.", token)

    def approve(self, case: CollectionCase, note: str | None) -> tuple[bool, str, str | None]:
        if case.status is not CaseStatus.IN_CHECKER_QUEUE:
            return False, f"{case.case_id} is not in the checker queue.", None
        token = self._snapshot(case)
        case.status = CaseStatus.COMPLETED
        case.completed_at = datetime.now()
        self._log(case, "Approved", note or "Checker controls complete; transaction closed.",
                  role="Checker")
        case.audit.append(AuditEntry(
            at=datetime.now(), actor="WFMS", role="System", action="WFMS updated",
            detail="Process update posted back to WFMS; case closed."))
        return True, f"{case.case_id} approved and closed. WFMS updated.", token

    def return_to_maker(self, case: CollectionCase, reason: str) -> tuple[bool, str, str | None]:
        if case.status is not CaseStatus.IN_CHECKER_QUEUE:
            return False, f"{case.case_id} is not in the checker queue.", None
        token = self._snapshot(case)
        case.status = CaseStatus.RETURNED
        case.returned_reason = reason
        self._log(case, "Returned to maker", reason, role="Checker")
        return True, f"{case.case_id} returned to the maker.", token


store = CaseStore()


def get_store() -> CaseStore:
    """FastAPI dependency. Override in tests or point at the real backend."""
    return store
