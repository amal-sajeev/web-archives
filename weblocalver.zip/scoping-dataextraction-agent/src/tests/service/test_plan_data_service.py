import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from model.plan_artifact_enum import PlanArtifact
from service import action_service
from service import plan_data_service
from service.plan_data_service import get_plan_artifact


@pytest.fixture
def local_bucket_root(tmp_path):
    return tmp_path / "local-bucket"


def _write_json(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8")


@pytest.mark.parametrize(
    "artifact_value, relative_path, payload",
    [
        (
            "historical_plan_details",
            "dbaware/historical_plan_details.json",
            {"Plan Item Number": 20429},
        ),
        (
            "risk_driver_details",
            "dbgrc/risk_driver_details.json",
            [{"riskid": "R033", "risk_drivers": [{"risk_driver_id": "RD1", "rationale": "Relevant to the plan."}]}],
        ),
    ],
)
def test_get_plan_artifact_handles_missing_agent_card(monkeypatch, artifact_value, relative_path, payload):
    recorded_cards = []
    monkeypatch.setenv("bucket_name", "test-bucket")
    monkeypatch.setattr(
        plan_data_service.AgentCard,
        "get_agent_card",
        lambda plan_number: None,
    )
    monkeypatch.setattr(
        action_service,
        "construct_human_actor_retrieve_records",
        lambda *args, **kwargs: recorded_cards.append(kwargs.get("agent_card", {})),
    )
    monkeypatch.setattr(
        action_service,
        "construct_ai_actor_retrieve_records",
        lambda *args, **kwargs: recorded_cards.append(kwargs.get("agent_card", {})),
    )
    monkeypatch.setattr(plan_data_service, "json_exists_in_gcs", lambda uri: True)
    monkeypatch.setattr(
        plan_data_service,
        "download_json_from_gcs",
        lambda uri: payload,
    )

    result = get_plan_artifact("20429", PlanArtifact(artifact_value))

    assert result["status"] == "SUCCESS"
    assert result["artifact"] == artifact_value
    assert result["source"] == f"gs://test-bucket/dbaware_review_20429/inbound-data/{relative_path}"
    assert result["data"][artifact_value] == payload
    assert recorded_cards == [{}, {}]


class TestGetPlanArtifactPolicy:

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_combines_referenced_documents_from_all_three_results(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(
            base / "relevant_policy.json",
            '{"referenced_documents": [{"document_name": "PolicyDoc", "gs_uri": "gs://docs/policy.pdf"}]}',
        )
        _write_json(
            base / "relevant_procedure.json",
            '{"referenced_documents": [{"document_name": "ProcedureDoc", "gs_uri": "gs://docs/procedure.pdf"}, {"document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"}]}',
        )
        _write_json(
            base / "relevant_kod.json",
            '{"referenced_documents": [{"document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"}, {"document_name": "KodDoc", "gs_uri": "gs://docs/kod.pdf"}], "kod_text": "hello"}',
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["source"] == "gs://bucket/dbaware_review_20090/inbound-data/policy"
        assert result["data"]["referenced_documents"] == [
            {"document_type": "policy", "document_name": "PolicyDoc", "gs_uri": "gs://docs/policy.pdf"},
            {"document_type": "procedure", "document_name": "ProcedureDoc", "gs_uri": "gs://docs/procedure.pdf"},
            {"document_type": "procedure", "document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"},
            {"document_type": "kod", "document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"},
            {"document_type": "kod", "document_name": "KodDoc", "gs_uri": "gs://docs/kod.pdf"},
        ]

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_returns_empty_list_when_policy_payload_has_no_documents(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(base / "relevant_policy.json", '{"referenced_documents": []}')

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["data"]["referenced_documents"] == []

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_raises_when_policy_artifact_missing(self, local_bucket_root):
        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            with pytest.raises(FileNotFoundError, match="No data found"):
                get_plan_artifact("20090", PlanArtifact.POLICY)

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_returns_empty_list_when_policy_files_contain_null(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(base / "relevant_policy.json", "null")
        _write_json(base / "relevant_procedure.json", "null")
        _write_json(base / "relevant_kod.json", "null")

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["data"]["referenced_documents"] == []

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_policy_reader_supports_legacy_relevant_data_filename(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(
            base / "policy" / "relevant_data.json",
            '{"referenced_documents": [{"document_name": "LegacyDoc", "gs_uri": "gs://docs/legacy.pdf"}]}'
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["data"]["referenced_documents"] == [
            {
                "document_type": "policy",
                "document_name": "LegacyDoc",
                "gs_uri": "gs://docs/legacy.pdf",
            }
        ]

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_filters_excluded_and_removed_referenced_documents(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(
            base / "relevant_policy.json",
            '{"referenced_documents": ['
            '{"document_name": "ActivePolicy", "gs_uri": "gs://docs/active.pdf"}, '
            '{"document_name": "ExcludedPolicy", "gs_uri": "gs://docs/ex.pdf", "excluded": true}, '
            '{"document_name": "RemovedPolicy", "gs_uri": "gs://docs/rem.pdf", "status": "removed"}'
            ']}',
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["data"]["referenced_documents"] == [
            {
                "document_type": "policy",
                "document_name": "ActivePolicy",
                "gs_uri": "gs://docs/active.pdf",
            }
        ]

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_supports_top_level_list_and_documents_dict_in_policy_artifacts(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20440" / "inbound-data" / "policy"
        _write_json(
            base / "relevant_policy.json",
            '[{"document_id": 1, "document_title": "Policy One", "storage_uri": "gs://docs/p1.pdf"}, '
            '{"document_id": 2, "document_title": "Excluded Policy", "storage_uri": "gs://docs/p2.pdf", "excluded": true}]',
        )
        _write_json(
            base / "relevant_kod.json",
            '{"documents": [{"document_id": 10, "document_title": "KOD Ten", "storage_uri": "gs://docs/kod10.pdf"}]}',
        )
        _write_json(
            base / "relevant_procedure.json",
            "[]",
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20440", PlanArtifact.POLICY)

        assert result["data"]["referenced_documents"] == [
            {
                "document_type": "policy",
                "document_name": "Policy One",
                "gs_uri": "gs://docs/p1.pdf",
            },
            {
                "document_type": "kod",
                "document_name": "KOD Ten",
                "gs_uri": "gs://docs/kod10.pdf",
            },
        ]

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_prefers_relevant_parts_folder_so_deleted_or_excluded_parts_disappear(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        # Legacy/aggregate file still has all 3 policies + 1 procedure:
        _write_json(
            base / "relevant_policy.json",
            '{"referenced_documents": ['
            '{"document_name": "Operational_Risk_Management_Policy", "gs_uri": "gs://docs/p1.pdf"}, '
            '{"document_name": "Risk_Appetite_Policy", "gs_uri": "gs://docs/p3.pdf"}'
            ']}',
        )
        # Per-document folder only has policy1.json (policy3 was deleted) and procedure4 is marked excluded:
        _write_json(
            base / "relevant_policy" / "policy1.json",
            '{"document_id": "1", "document_title": "Operational_Risk_Management_Policy", "storage_uri": "gs://docs/p1.pdf"}',
        )
        _write_json(
            base / "relevant_procedure" / "procedure4.json",
            '{"document_id": "4", "document_title": "Operational_Risk_Event_Management_Procedure", "storage_uri": "gs://docs/proc4.pdf", "excluded": true}',
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["data"]["referenced_documents"] == [
            {
                "document_type": "policy",
                "document_name": "Operational_Risk_Management_Policy",
                "gs_uri": "gs://docs/p1.pdf",
            }
        ]

    @patch.dict("os.environ", {"LOCAL_BUCKET_MODE": "true", "bucket_name": "bucket"})
    def test_policy_reads_sources_fallback_and_filters_exclusions(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20440" / "inbound-data" / "policy"
        _write_json(
            base / "relevant_policy.json",
            '{"sources": ['
            '{"document_name": "GBSA.pdf", "gs_uri": "gs://docs/gbsa.pdf"}, '
            '{"document_name": "DropMe.pdf", "gs_uri": "gs://docs/drop.pdf", "excluded": true}'
            ']}',
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20440", PlanArtifact.POLICY)

        assert result["data"]["referenced_documents"] == [
            {"document_type": "policy", "document_name": "GBSA.pdf", "gs_uri": "gs://docs/gbsa.pdf"}
        ]


def test_getdata_filters_historical_gfms_and_lrr_exclusions(monkeypatch):
    monkeypatch.setenv("bucket_name", "test-bucket")
    monkeypatch.setattr(plan_data_service.AgentCard, "get_agent_card", lambda _: {})
    monkeypatch.setattr(action_service, "construct_human_actor_retrieve_records", lambda *a, **kw: None)
    monkeypatch.setattr(action_service, "construct_ai_actor_retrieve_records", lambda *a, **kw: None)

    monkeypatch.setattr(
        plan_data_service.DBConnector,
        "get_data_extraction_metadata_map",
        lambda self, plan_number=None: {
            "historical_plan_details": {
                "documents": [
                    {
                        "document_id": "historical_plan_details",
                        "excluded": False,
                        "sections": [{"section_id": "20061", "excluded": True}],
                    }
                ]
            },
            "findings_details": {
                "documents": [
                    {
                        "document_id": "findings_details",
                        "excluded": False,
                        "sections": [{"section_id": "F-1", "node_id": "gfms:finding:F-1", "excluded": True}],
                    }
                ]
            },
            "lrr": {
                "documents": [
                    {
                        "document_id": "lrr_internet_search_data_enriched",
                        "excluded": False,
                        "sections": [{"section_id": 1, "node_id": "lrr:mandate:1", "excluded": True}],
                    }
                ]
            },
        },
    )

    monkeypatch.setattr(
        plan_data_service,
        "json_exists_in_gcs",
        lambda uri: not uri.endswith("internet_search_data.json"),
    )
    payloads = {
        "historical_plan_details.json": [
            {"Plan Item Number": 20061, "Plan Item Title": "Drop Plan"},
            {"Plan Item Number": 20062, "Plan Item Title": "Keep Plan"},
        ],
        "findings_details.json": [
            {"statusCode": 200, "responsePayload": [{"findingId": "F-1"}, {"findingId": "F-2"}]}
        ],
        "internet_search_data_enriched.json": [
            {
                "Risk Name": "R034",
                "Mandates": [{"Regulatory Mandate": "M1"}, {"Regulatory Mandate": "M2"}],
            }
        ],
    }
    monkeypatch.setattr(
        plan_data_service,
        "download_json_from_gcs",
        lambda uri: payloads[uri.rsplit("/", 1)[-1]],
    )

    hist_res = get_plan_artifact("20440", PlanArtifact.HISTORICAL_PLAN_DETAILS)
    assert [x["Plan Item Number"] for x in hist_res["data"]["historical_plan_details"]] == [20062]

    gfms_res = get_plan_artifact("20440", PlanArtifact.FINDINGS_DETAILS)
    assert [x["findingId"] for x in gfms_res["data"]["findings_details"][0]["responsePayload"]] == ["F-2"]

    lrr_res = get_plan_artifact("20440", PlanArtifact.LRR)
    assert lrr_res["data"]["internet_search_data_enriched"][0]["Mandates"] == [{"Regulatory Mandate": "M2"}]


def test_getdata_policy_excludes_docs_when_all_sections_excluded(monkeypatch):
    monkeypatch.setenv("bucket_name", "test-bucket")
    monkeypatch.setattr(plan_data_service.AgentCard, "get_agent_card", lambda _: {})
    monkeypatch.setattr(action_service, "construct_human_actor_retrieve_records", lambda *a, **kw: None)
    monkeypatch.setattr(action_service, "construct_ai_actor_retrieve_records", lambda *a, **kw: None)
    monkeypatch.setattr(
        plan_data_service.DBConnector,
        "get_data_extraction_metadata_map",
        lambda self, plan_number=None: {
            "policy": {
                "documents": [
                    {
                        "document_id": "1",
                        "document_title": "Policy One",
                        "excluded": False,
                        "sections": [{"section_id": "1.1", "excluded": True}],
                    }
                ]
            }
        },
    )
    monkeypatch.setattr(
        plan_data_service,
        "list_json_blobs_in_gcs",
        lambda uri: [f"{uri}/policy1.json"] if uri.endswith("relevant_policy") else [],
    )
    monkeypatch.setattr(plan_data_service, "json_exists_in_gcs", lambda uri: False)
    monkeypatch.setattr(
        plan_data_service,
        "download_json_from_gcs",
        lambda uri: {"document_id": "1", "document_title": "Policy One", "storage_uri": "gs://docs/p1.pdf"},
    )
    res = get_plan_artifact("20440", PlanArtifact.POLICY)
    assert res["data"]["referenced_documents"] == []


def test_getdata_historical_keeps_plan_when_only_one_of_multiple_pdfs_is_excluded(monkeypatch):
    from service.plan_data_service import _filter_historical_plan_payload

    payload = [
        {"Plan Item Number": 20061, "Plan Item Title": "High-Frequency Trading (GBSA) Review"},
        {"Plan Item Number": 4448, "Plan Item Title": "Volcker Trading Desk Review"},
    ]
    partial_pdf_exclusion_meta = {
        "documents": [
            {
                "filename": "historical_plan_details.json",
                "document_id": "historical_plan_details",
                "excluded": False,
                "sections": [
                    {
                        "section_id": "20061",
                        "section_title": "High-Frequency Trading (GBSA) Review",
                        "node_id": "historical_plan:20061",
                        "excluded": False,
                    },
                    {
                        "section_id": "4448",
                        "section_title": "Volcker Trading Desk Review",
                        "node_id": "historical_plan:4448",
                        "excluded": False,
                    },
                ],
            },
            {
                "filename": "020525 - Scoping Document - HFT (20061).pdf",
                "document_id": "20061",
                "historic_plan_number": "20061",
                "document_title": "High-Frequency Trading (GBSA) Review",
                "excluded": True,
                "sections": [
                    {
                        "section_id": "20061",
                        "section_title": "020525 - Scoping Document - HFT (20061).pdf",
                        "node_id": "historical_pdf:20061:020525 - Scoping Document - HFT (20061).pdf",
                        "excluded": True,
                    }
                ],
            },
            {
                "filename": "020525 - Scoping Document - HFT (20061)_Final.pdf",
                "document_id": "20061",
                "historic_plan_number": "20061",
                "document_title": "High-Frequency Trading (GBSA) Review",
                "excluded": False,
                "sections": [
                    {
                        "section_id": "20061",
                        "section_title": "020525 - Scoping Document - HFT (20061)_Final.pdf",
                        "node_id": "historical_pdf:20061:020525 - Scoping Document - HFT (20061)_Final.pdf",
                        "excluded": False,
                    }
                ],
            },
        ]
    }
    kept = _filter_historical_plan_payload(payload, partial_pdf_exclusion_meta)
    assert [item["Plan Item Number"] for item in kept] == [20061, 4448]

    all_pdfs_excluded_meta = {
        "documents": [
            partial_pdf_exclusion_meta["documents"][0],
            partial_pdf_exclusion_meta["documents"][1],
            {**partial_pdf_exclusion_meta["documents"][2], "excluded": True},
        ]
    }
    filtered = _filter_historical_plan_payload(payload, all_pdfs_excluded_meta)
    assert [item["Plan Item Number"] for item in filtered] == [4448]


