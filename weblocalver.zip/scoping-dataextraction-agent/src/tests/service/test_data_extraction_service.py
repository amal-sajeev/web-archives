import sys
import asyncio
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock, call

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

# Mock action_service prior to importing data_extraction_service
# to prevent ActionServiceClt initialization from failing on config.dev
mock_action_service = MagicMock()
mock_action_service.action_clt.persist_action = lambda fn: fn
sys.modules["service.action_service"] = mock_action_service
sys.modules["action_client"] = MagicMock()

from service.data_extraction_service import (
    run_extraction_pipeline,
    run_extraction_background,
)
from service.group_audit_client import _build_group_audit_payload
from model.status_enum import Status


@pytest.fixture(autouse=True)
def mock_delete_prefix(monkeypatch):
    mock = MagicMock(return_value=0)
    monkeypatch.setattr("service.data_extraction_service.delete_prefix", mock)
    return mock


@pytest.fixture(autouse=True)
def mock_group_audit(monkeypatch):
    monkeypatch.setattr(
        "service.data_extraction_service.get_group_audit_data",
        AsyncMock(return_value={"group_audit": []}),
    )


@pytest.fixture(autouse=True)
def mock_internet_search(monkeypatch):
    mock = AsyncMock(return_value={"results": []})
    monkeypatch.setattr("service.data_extraction_service.perform_internet_search", mock)
    return mock


@pytest.fixture(autouse=True)
def mock_risk_driver_data(monkeypatch):
    monkeypatch.setattr(
        "service.data_extraction_service.get_risk_driver_data",
        AsyncMock(
            return_value=[
                {
                    "riskid": "R033",
                    "risk_name": "Supervisory Arrangements",
                    "risk_drivers": [
                        {"risk_driver_id": "RD1", "rationale": "Relevant to the plan."}
                    ],
                }
            ]
        ),
    )


def test_build_group_audit_payload_extracts_and_deduplicates_fields():
    current_data = [
        {
            "UoT Countries": "Germany; France; Germany",
            "AU-RT-KC": [
                {"RT": "R030", "KC": "KC-100"},
                {"RT": "R030", "KC": "KC-100"},
            ],
        },
        {
            "UoT Countries": "France; Luxembourg",
            "AU-RT-KC": [{"RT": "R077", "KC": "KC-200"}],
        },
    ]

    assert _build_group_audit_payload(current_data) == {
        "countries": ["Germany", "France", "Luxembourg"],
        "risk_types": ["R030", "R077"],
        "key_controls": ["KC-100", "KC-200"],
    }


def test_build_group_audit_payload_defaults_empty_values():
    assert _build_group_audit_payload({}) == {
        "countries": [],
        "risk_types": [],
        "key_controls": [],
    }


class TestRunExtractionPipelineSuccess:

    @patch(
        "service.data_extraction_service.save_folder_to_destination",
        return_value="gs://bucket/folder",
    )
    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "12345",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={"findings": []},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": [{"id": 1, "name": "C1", "control": "C1"}]},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[{"control": "data"}],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("plan_folder", "plan_folder/inbound-data"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_full_pipeline_success(
        self,
        mock_dbaware,
        mock_build_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms_findings,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_save_json,
        mock_save_folder,
        mock_internet_search,
    ):
        mock_dbaware.return_value = {
            "current_data": {"Plan Item Title": "Test", "AU-RT-KC": []},
            "alc_nalc_details": [{"alc": "data"}],
            "historical_data": [{"hist": "data"}],
        }

        result = asyncio.run(run_extraction_pipeline("12345"))

        assert result["status"] == "success"
        assert "12345" in result["message"]
        assert result["output_location"] == "gs://bucket/folder"

        mock_dbaware.assert_awaited_once_with("12345", session_id=None)
        mock_build_paths.assert_called_once()
        mock_dbgrc.assert_awaited_once()
        mock_gfms_payload.assert_called_once()
        mock_gfms_findings.assert_awaited()
        # mock_build_rag.assert_awaited_once()
        mock_build_rag.assert_called_once()
        mock_get_rag.assert_called_once()
        mock_persist_rag.assert_awaited_once()
        mock_save_folder.assert_called_once()
        mock_internet_search.assert_awaited_once_with(
            None,
            {
                "searchTerm": "reviewIds=12345",
                "data": [mock_dbaware.return_value["current_data"]],
                "alc_nalc_details": mock_dbaware.return_value["alc_nalc_details"],
                "historical_data": mock_dbaware.return_value["historical_data"],
                "count": 1,
            },
        )
        assert [
            (saved_call.args[3], saved_call.args[2])
            for saved_call in mock_save_json.call_args_list
        ] == [
            ("dbaware", "plan_details.json"),
            ("dbaware", "alc_nalc_details.json"),
            ("dbaware", "historical_plan_details.json"),
            ("dbgrc", "control_details.json"),
            ("dbgrc", "risk_driver_details.json"),
            ("gfms", "findings_details.json"),
            ("group_audit", "group_audit_details.json"),
            ("lrr", "internet_search_data.json"),
        ]
        assert (
            mock_save_json.call_args_list[-1].args[0]
            == mock_internet_search.return_value
        )
        assert any(
            call.args[2] == "risk_driver_details.json"
            for call in mock_save_json.call_args_list
        )

    @patch(
        "service.data_extraction_service.save_folder_to_destination",
        return_value="gs://bucket/folder",
    )
    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "999",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": []},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("folder", "folder/inbound-data"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_pipeline_with_no_controls_no_gfms_tasks(
        self,
        mock_dbaware,
        mock_build_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms_findings,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_save_json,
        mock_save_folder,
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        result = asyncio.run(run_extraction_pipeline("999"))

        assert result["status"] == "success"
        # No controls means no gfms_findings calls
        mock_gfms_findings.assert_not_awaited()


class TestRunExtractionPipelineErrors:

    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
        side_effect=RuntimeError("dbaware down"),
    )
    def test_raises_on_dbaware_failure(self, mock_dbaware):
        with pytest.raises(RuntimeError, match="dbaware down"):
            asyncio.run(run_extraction_pipeline("111"))

    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        side_effect=RuntimeError("dbgrc fail"),
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("f", "f/i"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_raises_on_dbgrc_failure(
        self, mock_dbaware, mock_paths, mock_dbgrc, mock_save
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        with pytest.raises(RuntimeError, match="dbgrc fail"):
            asyncio.run(run_extraction_pipeline("222"))

    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "333",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_group_audit_data",
        new_callable=AsyncMock,
        side_effect=RuntimeError("group audit fail"),
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": []},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("f", "f/i"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_raises_on_group_audit_failure(
        self,
        mock_dbaware,
        mock_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_group_audit_call,
        mock_save,
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        with pytest.raises(RuntimeError, match="group audit fail"):
            asyncio.run(run_extraction_pipeline("333"))

    @patch(
        "service.data_extraction_service.save_folder_to_destination",
        side_effect=RuntimeError("upload fail"),
    )
    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "444",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": []},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("f", "f/i"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_raises_on_upload_failure(
        self,
        mock_dbaware,
        mock_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_save,
        mock_upload,
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        with pytest.raises(RuntimeError, match="upload fail"):
            asyncio.run(run_extraction_pipeline("444"))


class TestSessionHandling:
    """Test session management and session status updates during extraction."""

    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    def test_session_status_updated_on_processing_start(
        self, mock_pipeline, mock_update_status
    ):
        """Verify session status is set to PROCESSING when extraction starts."""
        session_id = "sess-001"
        plan_number = "5678"

        asyncio.run(run_extraction_background(session_id, plan_number))

        # First call should set PROCESSING status
        calls = mock_update_status.call_args_list
        assert any(
            call_obj[1].get("status") == Status.PROCESSING for call_obj in calls
        ), "Session should be marked as PROCESSING"

    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    def test_session_status_updated_on_completion(
        self, mock_pipeline, mock_update_status
    ):
        """Verify session status is set to COMPLETED when extraction succeeds."""
        session_id = "sess-002"
        plan_number = "5679"

        asyncio.run(run_extraction_background(session_id, plan_number))

        # Final call should set COMPLETED status
        final_call = mock_update_status.call_args_list[-1]
        assert (
            final_call[1]["status"] == Status.COMPLETED
        ), "Session should be marked as COMPLETED on success"
        assert final_call[1]["session_id"] == session_id
        assert final_call[1]["plan_number"] == plan_number

    @patch("service.session_service.get_session")
    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        side_effect=RuntimeError("pipeline error"),
    )
    def test_session_status_updated_on_failure(
        self, mock_pipeline, mock_update_status, mock_get_session
    ):
        """Verify session status is set to FAILED when extraction fails."""
        session_id = "sess-003"
        plan_number = "5680"
        mock_get_session.return_value = {"stage": "data_extraction"}

        asyncio.run(run_extraction_background(session_id, plan_number))

        # Final call should set FAILED status with error message
        final_call = mock_update_status.call_args_list[-1]
        assert (
            final_call[1]["status"] == Status.FAILED
        ), "Session should be marked as FAILED on error"
        assert "error" in final_call[1], "Error message should be included"
        assert session_id in str(
            mock_update_status.call_args_list
        ), "Session ID should be tracked"

    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    def test_session_id_passed_to_pipeline(self, mock_pipeline, mock_update_status):
        """Verify session ID is properly passed to extraction pipeline."""
        session_id = "sess-004"
        plan_number = "5681"

        asyncio.run(run_extraction_background(session_id, plan_number))

        # Pipeline should receive session_id
        mock_pipeline.assert_awaited_once()
        call_kwargs = mock_pipeline.call_args[1]
        assert (
            call_kwargs.get("session_id") == session_id
        ), "Session ID should be passed to pipeline"


class TestSessionPooling:
    """Test concurrent session pooling and concurrency control."""

    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    @patch("service.data_extraction_service.update_session_status")
    def test_multiple_sessions_concurrent_processing(
        self, mock_update_status, mock_pipeline
    ):
        """Verify multiple sessions can be processed concurrently within limit."""
        sessions = [
            ("sess-101", "plan-A"),
            ("sess-102", "plan-B"),
            ("sess-103", "plan-C"),
        ]

        async def run_all_sessions():
            tasks = [run_extraction_background(sid, plan) for sid, plan in sessions]
            await asyncio.gather(*tasks)

        asyncio.run(run_all_sessions())

        # All sessions should be processed
        assert mock_pipeline.await_count == len(
            sessions
        ), "All sessions should be processed"
        update_calls = mock_update_status.call_args_list
        session_ids = [call_obj[1]["session_id"] for call_obj in update_calls]
        assert "sess-101" in session_ids
        assert "sess-102" in session_ids
        assert "sess-103" in session_ids

    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    @patch("service.data_extraction_service.update_session_status")
    def test_concurrency_limit_enforced(self, mock_update_status, mock_pipeline):
        """Verify multiple sessions can execute with semaphore-based pooling."""
        sessions = [(f"sess-{i:03d}", f"plan-{i}") for i in range(3)]

        async def run_all_sessions():
            tasks = [run_extraction_background(sid, plan) for sid, plan in sessions]
            await asyncio.gather(*tasks)

        # Should complete without error despite semaphore pooling
        asyncio.run(run_all_sessions())

        # Verify all sessions were started
        assert mock_pipeline.await_count == len(
            sessions
        ), "All sessions should be processed"
        assert mock_update_status.call_count >= len(
            sessions
        ), "Status should be updated for each session"

    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    @patch("service.data_extraction_service.update_session_status")
    def test_session_isolation_in_pool(self, mock_update_status, mock_pipeline):
        """Verify sessions are isolated and don't interfere with each other."""
        session_data = {}

        async def tracked_pipeline(plan_number, session_id=None, user_request=None):
            # Simulate that each session has isolated state
            session_data[session_id] = plan_number
            await asyncio.sleep(0.05)
            return {"status": "success"}

        mock_pipeline.side_effect = tracked_pipeline

        sessions = [
            ("sess-201", "plan-X"),
            ("sess-202", "plan-Y"),
            ("sess-203", "plan-Z"),
        ]

        async def run_all_sessions():
            tasks = [run_extraction_background(sid, plan) for sid, plan in sessions]
            await asyncio.gather(*tasks)

        asyncio.run(run_all_sessions())

        # Each session should have its own isolated data
        assert session_data["sess-201"] == "plan-X"
        assert session_data["sess-202"] == "plan-Y"
        assert session_data["sess-203"] == "plan-Z"
        assert len(session_data) == 3, "All sessions should maintain isolated state"


class TestStructuredMetadataBuilders:
    """Verify structured review_data_extraction metadata generation for RAG, GFMS, and Historical sources."""

    def test_build_rag_source_metadata_from_result_includes_sections_and_node_ids(
        self, monkeypatch
    ):
        from service.rag_retrieval_service import build_rag_source_metadata_from_result

        monkeypatch.setenv("bucket_name", "test-bucket")
        rag_result = {
            "documents": [
                {
                    "document_id": "20",
                    "document_title": "KOD 20 - Controls",
                    "document_version": "1.0",
                    "storage_uri": "gs://doc-store/kod/KOD_20.pdf",
                    "nodes": [
                        {
                            "section_id": "3",
                            "section_title": "Roles & Responsibility",
                            "node_id": "1d306bdb1f6de466aec07c43:section:3",
                            "page_start": 4,
                            "page_end": 5,
                        }
                    ],
                }
            ]
        }

        meta = build_rag_source_metadata_from_result(
            "kod", rag_result, "dbaware_review_20440/inbound-data"
        )
        assert meta["source_type"] == "kod"
        assert len(meta["documents"]) == 1
        doc = meta["documents"][0]
        assert doc["filename"] == "kod20.json"
        assert (
            doc["storage_uri"]
            == "gs://test-bucket/dbaware_review_20440/inbound-data/policy/relevant_kod/kod20.json"
        )
        assert doc["status"] == "active"
        assert doc["excluded"] is False
        assert len(doc["sections"]) == 1
        sec = doc["sections"][0]
        assert sec["section_id"] == "3"
        assert sec["section_title"] == "Roles & Responsibility"
        assert sec["node_id"] == "1d306bdb1f6de466aec07c43:section:3"
        assert sec["status"] == "active"
        assert sec["excluded"] is False

    def test_build_gfms_metadata_extracts_findings_into_sections(self, monkeypatch):
        from service.data_extraction_service import _build_gfms_metadata

        monkeypatch.setenv("bucket_name", "test-bucket")
        gfms_payload = [
            {
                "statusCode": 200,
                "responsePayload": [
                    {
                        "auditNumber": "93-105/2026",
                        "auditName": "GFMS sample data test",
                        "findingId": "93-105/2026#3",
                        "findingTitle": "WP GFMS test",
                        "rating": "F4",
                        "controlNumber": "IRC-CD-1019363",
                    }
                ],
            }
        ]

        meta = _build_gfms_metadata(gfms_payload, "dbaware_review_20440/inbound-data")
        assert meta["source_type"] == "gfms"
        assert len(meta["documents"]) == 1
        doc = meta["documents"][0]
        assert doc["filename"] == "findings_details.json"
        assert (
            doc["storage_uri"]
            == "gs://test-bucket/dbaware_review_20440/inbound-data/gfms/findings_details.json"
        )
        assert len(doc["sections"]) == 1
        sec = doc["sections"][0]
        assert sec["section_id"] == "93-105/2026#3"
        assert sec["section_title"] == "WP GFMS test"
        assert sec["node_id"] == "gfms:finding:93-105/2026#3"
        assert sec["status"] == "active"
        assert sec["excluded"] is False

    def test_build_historical_plan_metadata_includes_plan_sections(self, monkeypatch):
        from service.data_extraction_service import _build_historical_plan_metadata

        monkeypatch.setenv("bucket_name", "test-bucket")
        monkeypatch.setattr(
            "service.data_extraction_service.list_historical_scoping_pdfs",
            lambda plan_num: [
                {
                    "filename": f"Scoping_{plan_num}.pdf",
                    "storage_uri": f"gs://test-bucket/historical_scoping_documents/{plan_num}/Scoping_{plan_num}.pdf",
                }
            ],
        )
        historical_data = [
            {
                "Plan Item Number": 20061,
                "Plan Item Title": "High-Frequency Trading (GBSA) Review",
                "Report Number": "51-101/2025",
                "Plan Year": 2025,
            }
        ]

        meta = _build_historical_plan_metadata(
            historical_data, "dbaware_review_20440/inbound-data"
        )
        assert meta["source_type"] == "historical_scoping_document"
        assert len(meta["documents"]) == 2
        json_doc = meta["documents"][0]
        assert json_doc["filename"] == "historical_plan_details.json"
        assert len(json_doc["sections"]) == 1
        assert json_doc["sections"][0]["section_id"] == "20061"
        assert (
            json_doc["sections"][0]["section_title"]
            == "High-Frequency Trading (GBSA) Review"
        )
        assert json_doc["sections"][0]["node_id"] == "historical_plan:20061"

        pdf_doc = meta["documents"][1]
        assert pdf_doc["filename"] == "Scoping_20061.pdf"
        assert pdf_doc["document_id"] == "20061"
        assert pdf_doc["excluded"] is False

    def test_build_structured_gcs_source_metadata_builders(self, monkeypatch):
        from service.data_extraction_service import (
            _build_alc_nalc_metadata,
            _build_control_details_metadata,
            _build_current_plan_metadata,
            _build_group_audit_metadata,
            _build_lrr_initial_metadata,
            _build_risk_driver_metadata,
        )

        monkeypatch.setenv("bucket_name", "test-bucket")
        key = "dbaware_review_20440/inbound-data"

        curr = _build_current_plan_metadata(
            [{"Plan Item Number": 20440, "Plan Item Title": "HFT Review", "UoT Regions": "Germany", "AU-RT-KC": [{}]}],
            key,
        )
        assert curr["documents"][0]["sections"][0]["node_id"] == "current_details:20440"
        assert curr["documents"][0]["sections"][0]["assessment_unit_count"] == 1

        ctrl = _build_control_details_metadata(
            {"included_kcs": [{"inventory": {"controlDefinitionNumber": "IRC-CD-1", "controlDefinitionName": "Ctrl 1"}}]},
            key,
        )
        assert ctrl["documents"][0]["sections"][0]["section_id"] == "IRC-CD-1"

        lrr_init = _build_lrr_initial_metadata(
            [{"plan_item_number": 20440, "plan_item_title": "HFT LRR", "search_combination": {"UoT Regions": "Germany"}}],
            key,
        )
        assert lrr_init["documents"][0]["sections"][0]["search_combination"]["UoT Regions"] == "Germany"

        assert len(_build_alc_nalc_metadata([{"id": "A1", "name": "AU 1"}], key)["documents"][0]["sections"]) == 1
        assert len(_build_risk_driver_metadata([{"risk_driver_id": "RD-1", "risk_name": "Risk 1"}], key)["documents"][0]["sections"]) == 1
        assert len(_build_group_audit_metadata([{"audit_id": "GA-1", "title": "Audit 1"}], key)["documents"][0]["sections"]) == 1

    def test_build_alc_nalc_metadata_maps_dbaware_fields_and_disambiguates_duplicates(
        self, monkeypatch
    ):
        from service.data_extraction_service import _build_alc_nalc_metadata

        monkeypatch.setenv("bucket_name", "test-bucket")
        key = "dbaware_review_20440/inbound-data"

        empty_meta = _build_alc_nalc_metadata(
            {"success": True, "count": 0, "data": []}, key
        )
        assert empty_meta["documents"][0]["sections"] == []

        meta = _build_alc_nalc_metadata(
            [
                {
                    "AU ID": "9756",
                    "NEW KC_ID": "IRC-CD-1000699",
                    "KC Full name": "Reg H Flood Zone Loan Checklist",
                    "Alternative coverage Name": "FRB Regulation H",
                    "Alternative coverage plan year": 2025,
                    "RT_ID": "R034",
                    "Country": "US",
                    "Status": "Approved",
                },
                {
                    "AU ID": "9756",
                    "NEW KC_ID": "IRC-CD-1000699",
                    "Alternative coverage Name": "FRB Regulation H Followup",
                    "RT_ID": "R034",
                    "Country": "UK",
                },
            ],
            key,
        )
        secs = meta["documents"][0]["sections"]
        assert len(secs) == 2
        assert secs[0]["section_id"] == "9756:IRC-CD-1000699"
        assert secs[0]["section_title"] == "Reg H Flood Zone Loan Checklist"
        assert secs[0]["node_id"] == "alc_nlac:9756:IRC-CD-1000699"
        assert secs[0]["au_id"] == "9756"
        assert secs[0]["kc_id"] == "IRC-CD-1000699"
        assert secs[0]["rt_id"] == "R034"
        assert secs[0]["country"] == "US"
        assert secs[1]["section_title"] == "FRB Regulation H Followup"
        assert secs[1]["node_id"] == "alc_nlac:9756:IRC-CD-1000699:2"

    def test_build_risk_driver_metadata_handles_nested_and_empty_groups(
        self, monkeypatch
    ):
        from service.data_extraction_service import _build_risk_driver_metadata

        monkeypatch.setenv("bucket_name", "test-bucket")
        key = "dbaware_review_20440/inbound-data"

        meta = _build_risk_driver_metadata(
            [
                {
                    "riskid": "R033",
                    "risk_name": "Supervisory Arrangements",
                    "risk_drivers": [
                        {
                            "riskDriverId": "R033 - RD1",
                            "riskDrivers": "Failure to define supervision.",
                            "rationale": "Relevant to supervised trading.",
                        }
                    ],
                },
                {
                    "riskid": "R034",
                    "risk_name": "Participation in Trading Markets",
                    "risk_drivers": [],
                },
            ],
            key,
        )
        secs = meta["documents"][0]["sections"]
        assert len(secs) == 2
        assert secs[0]["section_id"] == "R033 - RD1"
        assert secs[0]["section_title"] == "Failure to define supervision."
        assert secs[0]["node_id"] == "risk_driver:R033 - RD1"
        assert secs[0]["risk_id"] == "R033"
        assert secs[0]["risk_name"] == "Supervisory Arrangements"
        assert secs[0]["rationale"] == "Relevant to supervised trading."
        assert secs[1]["section_id"] == "R034"
        assert secs[1]["section_title"] == "Participation in Trading Markets"
        assert secs[1]["driver_count"] == 0

    def test_build_group_audit_metadata_unwraps_mcp_envelope(self, monkeypatch):
        from service.data_extraction_service import _build_group_audit_metadata

        monkeypatch.setenv("bucket_name", "test-bucket")
        key = "dbaware_review_20440/inbound-data"

        empty_meta = _build_group_audit_metadata(
            {"parameters": {"planyear": "2026"}, "success": True, "count": 0, "data": []},
            key,
        )
        assert empty_meta["documents"][0]["sections"] == []

        non_empty_meta = _build_group_audit_metadata(
            {
                "parameters": {"planyear": "2026"},
                "success": True,
                "count": 1,
                "data": [{"report_number": "GA-2026-1", "audit_name": "HFT Audit"}],
            },
            key,
        )
        secs = non_empty_meta["documents"][0]["sections"]
        assert len(secs) == 1
        assert secs[0]["section_id"] == "GA-2026-1"
        assert secs[0]["section_title"] == "HFT Audit"
        assert secs[0]["node_id"] == "group_audit:GA-2026-1"

    def test_build_rag_source_metadata_top_level_fields_and_dedup(self, monkeypatch):
        from service.rag_retrieval_service import build_rag_source_metadata_from_result

        monkeypatch.setenv("bucket_name", "test-bucket")
        key = "dbaware_review_20440/inbound-data"

        err_meta = build_rag_source_metadata_from_result(
            "kod", None, key, error="RAG timeout"
        )
        assert err_meta["source_type"] == "kod"
        assert err_meta["filename"] == "relevant_kod.json"
        assert (
            err_meta["storage_uri"]
            == "gs://test-bucket/dbaware_review_20440/inbound-data/policy/relevant_kod.json"
        )
        assert err_meta["registry_filename"] == "relevant_kod.json"
        assert err_meta["registry_storage_uri"] == err_meta["storage_uri"]
        assert err_meta["status"] == "active"
        assert err_meta["excluded"] is False
        assert err_meta["error"] == "RAG timeout"
        assert err_meta["documents"] == []

        dup_meta = build_rag_source_metadata_from_result(
            "kod",
            [
                {
                    "document_id": "20",
                    "document_title": "Central Inventory KOD",
                    "storage_uri": "gs://src/kod20.pdf",
                    "nodes": [{"section_id": "1", "section_title": "Intro", "node_id": "20:1"}],
                },
                {
                    "document_id": "20",
                    "document_title": "Central Inventory KOD",
                    "storage_uri": "gs://src/kod20.pdf",
                    "nodes": [{"section_id": "2", "section_title": "Scope", "node_id": "20:2"}],
                },
            ],
            key,
        )
        assert len(dup_meta["documents"]) == 1
        assert [s["section_id"] for s in dup_meta["documents"][0]["sections"]] == ["1", "2"]

    def test_build_gfms_metadata_ct_fallback_and_historical_dedup(self, monkeypatch):
        from service.data_extraction_service import (
            _build_gfms_metadata,
            _build_historical_plan_metadata,
        )

        monkeypatch.setenv("bucket_name", "test-bucket")
        key = "dbaware_review_20440/inbound-data"

        gfms_meta = _build_gfms_metadata(
            [
                {
                    "statusCode": 200,
                    "responsePayload": [
                        {
                            "findingId": "04147/2026",
                            "findingTitle": "HFT Line Bandwidth",
                            "ct1": "Control Not Applicable",
                            "ct2": "IRC-CD-1001083-Monthly review",
                        }
                    ],
                }
            ],
            key,
        )
        assert (
            gfms_meta["documents"][0]["sections"][0]["control_number"]
            == "IRC-CD-1001083-Monthly review"
        )

        monkeypatch.setattr(
            "service.data_extraction_service.list_historical_scoping_pdfs",
            lambda p: [
                {"filename": "DocA.pdf", "storage_uri": f"gs://b/{p}/DocA.pdf"},
                {"filename": "DocA.pdf", "storage_uri": f"gs://b/{p}/DocA.pdf"},
            ],
        )
        hist_meta = _build_historical_plan_metadata(
            [
                {"Plan Item Number": 20061, "Plan Item Title": "HFT Review"},
                {"Plan Item Number": 20061, "Plan Item Title": "HFT Review Duplicate"},
            ],
            key,
        )
        assert len(hist_meta["documents"]) == 2
        assert len(hist_meta["documents"][0]["sections"]) == 1

    @patch(
        "service.data_extraction_service.save_folder_to_destination",
        side_effect=RuntimeError("upload fail"),
    )
    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "555",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value=[],
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": []},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value={"included_kcs": []},
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("f", "f/i"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_db_persistence_skipped_when_upload_fails(
        self,
        mock_dbaware,
        mock_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_save,
        mock_upload,
        monkeypatch,
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }
        persist_mock = MagicMock()
        monkeypatch.setattr("service.data_extraction_service._persist_source_response", persist_mock)

        with pytest.raises(RuntimeError, match="upload fail"):
            asyncio.run(run_extraction_pipeline("555"))

        persist_mock.assert_not_called()


