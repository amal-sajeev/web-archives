import logging
import os
import site
import sys
from datetime import datetime, timezone
import uuid
import json
from typing import Any, Dict, List, Optional
from util.agent_card import AgentCard
from constant.data_extraction_constant import DataExtractionActionConstant

logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    stream=sys.stdout)
logger = logging.getLogger(__name__)


# Stash any already imported local 'config' modules so ActionServiceClt can load
# the wheel's config.dev package from dependencies without collision.
_stashed_config_modules = {
    name: mod
    for name, mod in list(sys.modules.items())
    if name == "config" or name.startswith("config.")
}
for name in _stashed_config_modules:
    sys.modules.pop(name, None)

_site_packages = site.getsitepackages() if hasattr(site, "getsitepackages") else []
# Support custom container dependency paths like /opt/python-deps or PYTHONPATH entries
_custom_dep_paths = [
    path
    for path in ["/opt/python-deps", *os.getenv("PYTHONPATH", "").split(os.pathsep)]
    if path and os.path.isdir(path)
]
_target_dep_paths = list(dict.fromkeys(_custom_dep_paths + _site_packages))

_saved_sys_path = list(sys.path)

try:
    # Put dependency directories at the top of sys.path for action client initialization
    for sp in reversed(_target_dep_paths):
        while sp in sys.path:
            sys.path.remove(sp)
        sys.path.insert(0, sp)

    from action_client import ActionServiceClt

    env = os.getenv("ENV_NAME", "dev")
    action_clt = ActionServiceClt()
finally:
    # Restore sys.path and restore local config module cache
    sys.path[:] = _saved_sys_path
    # Retain the loaded config.dev subpackage if present
    dev_submod = sys.modules.get("config.dev")
    sys.modules.update(_stashed_config_modules)
    if dev_submod is not None:
        sys.modules["config.dev"] = dev_submod
        if "config" in sys.modules and hasattr(sys.modules["config"], "__path__"):
            for sp in _target_dep_paths:
                candidate = os.path.join(sp, "config")
                if (
                    os.path.isdir(candidate)
                    and candidate not in sys.modules["config"].__path__
                ):
                    sys.modules["config"].__path__.append(candidate)


def _get_prompt_version(filename: str = "qna_prompt.json") -> str:
    """Helper to read prompt version dynamically from prompts directory."""
    try:
        # Resolves path relative to service file down to main/etc/prompts/
        base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        prompt_path = os.path.join(base_path, "etc", "prompts", filename)
        if os.path.exists(prompt_path):
            with open(prompt_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                version_str = data.get("_comment")
                split_words = version_str.split(" ")
                version = split_words[0].split("=")[1]
                return version
    except FileNotFoundError:
        logger.warning("Prompt file not found: %s", filename)
    except json.JSONDecodeError as e:
        logger.warning("Failed to parse JSON from %s: %s", filename, e)
    except Exception as e:
        logger.warning(
            "An unexpected error occurred while parsing prompt version from %s: %s",
            filename,
            e,
        )
    return "0.1"


decomposition_prompt = _get_prompt_version("decomposition_prompt.json")
historical_plan_matching_prompt = _get_prompt_version(
    "historical_plan_matching_prompt.json"
)
mandate_generation_prompt = _get_prompt_version("mandate_generation_prompt.json")
risktype_mapping = _get_prompt_version("risktype_mapping.json")


@action_clt.persist_action
def call_to_action_service(json_data):
    logger.info(f"********* in call_to_action_service json data = {json_data}")
    return json_data


def construct_cta_action_record(plan_number: str,
                                action_type: str,
                                actor_type: str,
                                actor_id: str,
                                activity_type : str,
                                payload: Dict[str,str]):
    logger.info(f"inside construct_cta_action_record plan -idplan_number = {plan_number}, action_type = {action_type}, "
                f" actor_type = {actor_type}, actor_id= {actor_id} ")
    agent_card = AgentCard.build_agent_card(entity_type=DataExtractionActionConstant.DEFAULT_ENTITY_TYPE,
                                            plan_item_number=plan_number)


    now_utc = datetime.now(timezone.utc)
    create_ts = now_utc.isoformat()

    if actor_id is None:
        actor_id = agent_card.get('ACTOR_ID', DataExtractionActionConstant.DEFAULT_ACTOR_ID)
    json_data = {
        "CTA_ACTION": {
            DataExtractionActionConstant.ActionHistoryFields.action_id.value:None,
            DataExtractionActionConstant.ActionHistoryFields.entity_id.value: agent_card.get('ENTITY_ID', str(uuid.uuid5(uuid.NAMESPACE_DNS, plan_number))),
            DataExtractionActionConstant.ActionHistoryFields.entity_type.value: agent_card.get('ENTITY_TYPE', "DATA_EXTRACTION"),
            DataExtractionActionConstant.ActionHistoryFields.create_ts.value: create_ts,
            DataExtractionActionConstant.ActionHistoryFields.insert_ts.value: None,
            DataExtractionActionConstant.ActionHistoryFields.actor_type.value: actor_type,
            DataExtractionActionConstant.ActionHistoryFields.actor_id.value: actor_id,
            DataExtractionActionConstant.ActionHistoryFields.action_type.value: action_type,
            DataExtractionActionConstant.ActionHistoryFields.parent_entity_type.value: agent_card.get("PARENT_ENTITY_TYPE", "SCOPING"),
            DataExtractionActionConstant.ActionHistoryFields.parent_entity_id.value: agent_card.get("PARENT_ENTITY_ID", plan_number),
            DataExtractionActionConstant.ActionHistoryFields.activity_type.value: activity_type or agent_card.get("ACTIVITY_TYPE", ""),
            DataExtractionActionConstant.ActionHistoryFields.payload.value: payload


        }
    }

    logging.info(f"ACTION_TYPE={action_type}")
    return json_data


def construct_human_actor_record_generate(session_data):
    logger.info(" INSIDE construct_human_actor_record_generate *******")
    session_data = session_data or {}

    payload = {
        DataExtractionActionConstant.Payload.Human_Notes.value: "extract data for plan " + str(session_data.get('plan_number', 0)),
        DataExtractionActionConstant.Payload.Remarks.value: ""
    }

    json_data = construct_cta_action_record(plan_number=session_data.get('plan_number', 0),
                                            action_type='DATA_EXTRACT_AND_SAVE',
                                            actor_type='SYSTEM',
                                            actor_id=DataExtractionActionConstant.HUMAN_ACTOR_ID,
                                            activity_type="DBAWARE, DBGRC, GFMS, GROUP_AUDIT, INTERNET_SEARCH",
                                            payload=payload)


    call_to_action_service(json_data)


def construct_ai_actor_record_generate(session_data):
    logger.info(" INSIDE construct_ai_actor_record_generate *******")
    session_data = session_data or {}
    agent_card = session_data.get("agent_card", None)
    llm_usage = session_data.get("llm_usage", None) or []

    first_usage = llm_usage[0] if isinstance(llm_usage, list) and llm_usage else {}
    model_params = (
        first_usage.get("model_params", None) if isinstance(first_usage, dict) else None
    )
    response = session_data.get("response", None)

    model_name = None
    model_version = None

    if isinstance(model_params, dict):
        model_name = model_params.get("model", "")
        if isinstance(model_name, str) and model_name:
            model_version = model_name.split("-", 1)[1] if "-" in model_name else None

    input_tokens = 0
    output_tokens = 0
    if isinstance(llm_usage, list):
        for usage_entry in llm_usage:
            if not isinstance(usage_entry, dict):
                continue
            usage_metadata = usage_entry.get("usage_metadata")
            if isinstance(usage_metadata, dict):
                input_tokens += int(usage_metadata.get("input_tokens") or 0)
                output_tokens += int(usage_metadata.get("output_tokens") or 0)
    response_code = None
    response_text = ""
    save_location = None


    if isinstance(response, dict):
        response_code = response.get('response_code', None)
        response_text = response.get('message', None)
        save_location = response.get('output_location', None)

    plan_title = session_data.get('plan_title_name', None)
    mcp_tools = session_data.get('mcp_tool', None) or []

    payload = {
        DataExtractionActionConstant.Payload.Agent_Name.value: DataExtractionActionConstant.DEFAULT_ACTOR_ID,
        DataExtractionActionConstant.Payload.Action_type.value: 'RESPONSE',
        DataExtractionActionConstant.Payload.AI_Model_Name.value: model_name,
        DataExtractionActionConstant.Payload.AI_Model_Version.value: model_version,
        DataExtractionActionConstant.Payload.Plan_number.value: session_data.get('plan_number', None),
        DataExtractionActionConstant.Payload.Plan_Title.value: plan_title,
        DataExtractionActionConstant.Payload.AI_Model_Config_Setting.value: {},
        DataExtractionActionConstant.Payload.Prompt_Version.value: {
            "historical_plan_matching_prompt": historical_plan_matching_prompt
        },
        DataExtractionActionConstant.Payload.AI_Rationale.value: None,
        DataExtractionActionConstant.Payload.AI_Confidence_Score.value: None,
        DataExtractionActionConstant.Payload.Mcp_Tools.value: list(mcp_tools),
        DataExtractionActionConstant.Payload.Token_Input_Count.value: input_tokens if input_tokens > 0 else 0,
        DataExtractionActionConstant.Payload.Token_Output_Count.value: output_tokens if output_tokens > 0 else 0,
        DataExtractionActionConstant.Payload.Execution_Start_Time.value: session_data.get('extract_start_time', 0),
        DataExtractionActionConstant.Payload.Execution_End_Time.value: session_data.get('extract_end_time', 0),
        DataExtractionActionConstant.Payload.Response_Code.value: response_code,
        DataExtractionActionConstant.Payload.Save_Location.value: save_location,
        DataExtractionActionConstant.Payload.Remarks.value: ""
    }
    json_data = construct_cta_action_record(
        plan_number=session_data.get('plan_number', 0),
        action_type='RESPONSE',
        actor_type=DataExtractionActionConstant.DEFAULT_ACTOR_TYPE,
        actor_id=DataExtractionActionConstant.DEFAULT_ACTOR_ID,
        activity_type="DBAWARE, DBGRC, GFMS, GROUP_AUDIT, INTERNET_SEARCH",
        payload=payload,
    )

    call_to_action_service(json_data)


def construct_human_actor_retrieve_records(plan_number, artifact, agent_card):
    agent_card = agent_card or {}
    if artifact == 'current_details':
        artifact = 'current_plan_details'

    payload = {

        DataExtractionActionConstant.Payload.Human_Notes.value: 'Retrieve data for plan number ' + str(plan_number) + ", artifact = " + artifact,
        DataExtractionActionConstant.Payload.Remarks.value: ""
    }
    artifact_upper = artifact.upper()


    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='DATA_RETRIEVAL_REQUEST',
                                            actor_type=DataExtractionActionConstant.HUMAN_ACTOR_TYPE,
                                            actor_id=DataExtractionActionConstant.HUMAN_ACTOR_ID,
                                            activity_type=artifact_upper,
                                            payload=payload)

    call_to_action_service(json_data)



def construct_ai_actor_retrieve_records(plan_number,
                                        artifact,
                                        response,
                                        agent_card=None,
                                        start_time=None,
                                        end_time=None):
    agent_card = agent_card or {}
    if artifact == 'current_details':
        artifact = 'current_plan_details'

    artifact_upper = artifact.upper()
    now = datetime.now(timezone.utc)
    start_time = start_time or now
    end_time = end_time or now
    payload = {

        DataExtractionActionConstant.Payload.Response_Text.value: response.get('status', None),
        DataExtractionActionConstant.Payload.Response_Code.value: response.get('response_code', None),
        DataExtractionActionConstant.Payload.Remarks.value: "",
        DataExtractionActionConstant.Payload.Execution_Start_Time.value: start_time.isoformat(),
        DataExtractionActionConstant.Payload.Execution_End_Time.value: end_time.isoformat()

    }

    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='DATA_RETRIEVAL_RESPONSE',
                                            actor_type=DataExtractionActionConstant.DEFAULT_ACTOR_TYPE,
                                            actor_id=DataExtractionActionConstant.DEFAULT_ACTOR_ID,
                                            activity_type=artifact_upper,
                                            payload=payload)

    call_to_action_service(json_data)
