import logging
import re
from pathlib import Path
from typing import Any
from datetime import datetime, timezone

from model.plan_artifact_enum import PlanArtifact
from persister.gcp_bucket_persister import (
    download_json_from_gcs,
    gcs_prefix_exists,
    inbound_prefix_uri,
    json_exists_in_gcs,
    list_json_blobs_in_gcs,
    plan_prefix_uri,
)
from service import action_service
from util.agent_card import AgentCard
from util.db_connector import DBConnector

logger = logging.getLogger(__name__)
POLICY_DOCUMENT_TYPES = ("policy", "procedure", "kod")
_EXCLUDED_DOC_STATUSES = {"removed", "excluded", "deleted", "inactive"}



def _validate_plan_number(plan_number: str) -> str:
    plan_id = str(plan_number).strip()
    if not re.fullmatch(r"\d+", plan_id):
        raise ValueError("plan_number must be a numeric value.")
    return plan_id


# Artifact -> object path relative to <plan folder>/inbound-data
ARTIFACT_FILES: dict[PlanArtifact, str] = {
    PlanArtifact.CURRENT_DETAILS: "dbaware/plan_details.json",
    PlanArtifact.LRR: "lrr/internet_search_data.json",
    PlanArtifact.HISTORICAL_PLAN_DETAILS: "dbaware/historical_plan_details.json",
    PlanArtifact.ALC_NALC: "dbaware/alc_nalc_details.json",
    PlanArtifact.FINDINGS_DETAILS: "gfms/findings_details.json",
    PlanArtifact.CONTROL_DETAILS: "dbgrc/control_details.json",
    PlanArtifact.RISK_DRIVER_DETAILS: "dbgrc/risk_driver_details.json",
    PlanArtifact.GROUP_AUDIT: "group_audit/group_audit_details.json",
}

# Artifacts served as every JSON file inside a folder instead of a single file.
ARTIFACT_FOLDERS: dict[PlanArtifact, str] = {
    PlanArtifact.POLICY: "policy",
}


def _dedup_documents(documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []

    for document in documents:
        if not isinstance(document, dict):
            continue

        key = str(
            document.get("document_type")
            or ""
        ) + "|" + str(document.get("gs_uri") or document.get("document_name") or document)
        if key in seen:
            continue

        seen.add(key)
        deduped.append(document)

    return deduped


def _load_json_if_present(uri: str) -> tuple[bool, Any]:
    """Return (file_exists, parsed_content). Content is None when the file is absent or its JSON is null."""
    if not json_exists_in_gcs(uri):
        return False, None
    return True, download_json_from_gcs(uri)


def _relevant_filename_for_document_type(document_type: str) -> str:
    return f"relevant_{document_type}.json"


def _is_excluded_doc_entry(item: Any) -> bool:
    if not isinstance(item, dict):
        return False
    if item.get("excluded") is True:
        return True
    return str(item.get("status") or "").strip().lower() in _EXCLUDED_DOC_STATUSES


_WHOLE_FILE_DOC_IDS = {
    "findings_details",
    "findings_details.json",
    "historical_plan_details",
    "historical_plan_details.json",
    "lrr",
    "lrr_internet_search_data_enriched",
    "internet_search_data.json",
    "internet_search_data_enriched.json",
}


def _extract_exclusion_sets(
    db_source_meta: Any,
) -> tuple[bool, set[str], set[str], set[str], set[str]]:
    """Collect whole-file, document-level, and section-level exclusion markers."""
    whole_file_excluded = _is_excluded_doc_entry(db_source_meta)
    excluded_doc_ids: set[str] = set()
    excluded_doc_titles: set[str] = set()
    excluded_sec_ids: set[str] = set()
    excluded_sec_titles: set[str] = set()

    if not isinstance(db_source_meta, dict):
        return (
            whole_file_excluded,
            excluded_doc_ids,
            excluded_doc_titles,
            excluded_sec_ids,
            excluded_sec_titles,
        )

    for doc in db_source_meta.get("documents") or []:
        if not isinstance(doc, dict):
            continue
        doc_id_low = str(doc.get("document_id") or "").strip().lower()
        hist_id_low = str(doc.get("historic_plan_number") or "").strip().lower()
        doc_fname_low = str(doc.get("filename") or "").strip().lower()
        sections = [sec for sec in (doc.get("sections") or []) if isinstance(sec, dict)]
        if _is_excluded_doc_entry(doc):
            if doc_id_low in _WHOLE_FILE_DOC_IDS or doc_fname_low in _WHOLE_FILE_DOC_IDS:
                if not hist_id_low:
                    whole_file_excluded = True
            if doc_id_low:
                excluded_doc_ids.add(doc_id_low)
            if hist_id_low:
                excluded_doc_ids.add(hist_id_low)
            for t_key in ("document_title", "title", "document_name", "name"):
                if doc.get(t_key):
                    excluded_doc_titles.add(str(doc[t_key]).strip().lower())
        for sec in sections:
            if not _is_excluded_doc_entry(sec):
                continue
            for id_key in ("section_id", "node_id"):
                val = sec.get(id_key)
                if val not in (None, ""):
                    excluded_sec_ids.add(str(val).strip().lower())
            sec_title = sec.get("section_title") or sec.get("title")
            if sec_title:
                excluded_sec_titles.add(str(sec_title).strip().lower())

    return (
        whole_file_excluded,
        excluded_doc_ids,
        excluded_doc_titles,
        excluded_sec_ids,
        excluded_sec_titles,
    )


def _filter_historical_plan_payload(payload: Any, db_source_meta: Any) -> Any:
    whole_file_excluded = _is_excluded_doc_entry(db_source_meta)
    all_excluded_ids: set[str] = set()
    all_excluded_titles: set[str] = set()
    pdf_docs_by_plan: dict[str, list[tuple[bool, set[str]]]] = {}

    if isinstance(db_source_meta, dict):
        for doc in db_source_meta.get("documents") or []:
            if not isinstance(doc, dict):
                continue
            doc_id_low = str(doc.get("document_id") or "").strip().lower()
            hist_id_low = str(doc.get("historic_plan_number") or "").strip().lower()
            doc_fname_low = str(doc.get("filename") or "").strip().lower()
            sections = [sec for sec in (doc.get("sections") or []) if isinstance(sec, dict)]
            is_pdf_doc = bool(hist_id_low) or doc_fname_low.endswith(".pdf")

            if is_pdf_doc:
                plan_key = hist_id_low or doc_id_low
                doc_ex = _is_excluded_doc_entry(doc) or (
                    bool(sections) and all(_is_excluded_doc_entry(sec) for sec in sections)
                )
                titles = {
                    str(doc[t_key]).strip().lower()
                    for t_key in ("document_title", "title", "document_name", "name")
                    if doc.get(t_key)
                }
                if plan_key:
                    pdf_docs_by_plan.setdefault(plan_key, []).append((doc_ex, titles))
                continue

            if _is_excluded_doc_entry(doc):
                if doc_id_low in _WHOLE_FILE_DOC_IDS or doc_fname_low in _WHOLE_FILE_DOC_IDS:
                    whole_file_excluded = True
                if doc_id_low:
                    all_excluded_ids.add(doc_id_low)
                for t_key in ("document_title", "title", "document_name", "name"):
                    if doc.get(t_key):
                        all_excluded_titles.add(str(doc[t_key]).strip().lower())

            for sec in sections:
                if not _is_excluded_doc_entry(sec):
                    continue
                for id_key in ("section_id", "node_id"):
                    val = sec.get(id_key)
                    if val not in (None, ""):
                        all_excluded_ids.add(str(val).strip().lower())
                sec_title = sec.get("section_title") or sec.get("title")
                if sec_title:
                    all_excluded_titles.add(str(sec_title).strip().lower())

        for plan_key, pdf_entries in pdf_docs_by_plan.items():
            if pdf_entries and all(is_ex for is_ex, _ in pdf_entries):
                all_excluded_ids.add(plan_key)
                for _, titles in pdf_entries:
                    all_excluded_titles.update(titles)

    def _is_plan_item_excluded(item: dict[str, Any]) -> bool:
        if whole_file_excluded or _is_excluded_doc_entry(item):
            return True
        plan_num = str(
            item.get("Plan Item Number")
            or item.get("plan_item_number")
            or item.get("document_id")
            or ""
        ).strip().lower()
        plan_title = str(
            item.get("Plan Item Title")
            or item.get("plan_item_title")
            or item.get("title")
            or ""
        ).strip().lower()
        node_id = str(item.get("node_id") or "").strip().lower()
        if plan_num and (
            plan_num in all_excluded_ids
            or f"historical_plan:{plan_num}" in all_excluded_ids
        ):
            return True
        if node_id and node_id in all_excluded_ids:
            return True
        if plan_title and plan_title in all_excluded_titles:
            return True
        return False

    if isinstance(payload, list):
        return [
            item
            for item in payload
            if not (isinstance(item, dict) and _is_plan_item_excluded(item))
        ]
    if isinstance(payload, dict) and _is_plan_item_excluded(payload):
        return []
    return payload


def _filter_gfms_payload(payload: Any, db_source_meta: Any) -> Any:
    (
        whole_file_excluded,
        excluded_doc_ids,
        excluded_doc_titles,
        excluded_sec_ids,
        excluded_sec_titles,
    ) = _extract_exclusion_sets(db_source_meta)
    all_excluded_ids = excluded_sec_ids | (excluded_doc_ids - _WHOLE_FILE_DOC_IDS)
    all_excluded_titles = excluded_sec_titles | (excluded_doc_titles - {"gfms findings details"})

    def _is_finding_excluded(item: dict[str, Any]) -> bool:
        if whole_file_excluded or _is_excluded_doc_entry(item):
            return True
        fid = str(
            item.get("findingId") or item.get("finding_id") or item.get("id") or ""
        ).strip().lower()
        ftitle = str(
            item.get("findingTitle") or item.get("title") or item.get("auditName") or ""
        ).strip().lower()
        node_id = str(item.get("node_id") or "").strip().lower()
        if fid and (
            fid in all_excluded_ids or f"gfms:finding:{fid}" in all_excluded_ids
        ):
            return True
        if node_id and node_id in all_excluded_ids:
            return True
        if ftitle and ftitle in all_excluded_titles:
            return True
        return False

    if isinstance(payload, list):
        filtered_list: list[Any] = []
        for entry in payload:
            if not isinstance(entry, dict):
                filtered_list.append(entry)
                continue
            if isinstance(entry.get("responsePayload"), list):
                kept = [
                    f
                    for f in entry["responsePayload"]
                    if not (isinstance(f, dict) and _is_finding_excluded(f))
                ]
                if kept or not entry["responsePayload"]:
                    filtered_list.append({**entry, "responsePayload": kept})
            elif isinstance(entry.get("findings"), list):
                kept = [
                    f
                    for f in entry["findings"]
                    if not (isinstance(f, dict) and _is_finding_excluded(f))
                ]
                if kept or not entry["findings"]:
                    filtered_list.append({**entry, "findings": kept})
            elif not _is_finding_excluded(entry):
                filtered_list.append(entry)
        return filtered_list
    if isinstance(payload, dict) and _is_finding_excluded(payload):
        return []
    return payload


def _filter_lrr_payload(payload: Any, db_source_meta: Any) -> Any:
    (
        whole_file_excluded,
        excluded_doc_ids,
        excluded_doc_titles,
        excluded_sec_ids,
        excluded_sec_titles,
    ) = _extract_exclusion_sets(db_source_meta)
    all_excluded_ids = excluded_sec_ids | (excluded_doc_ids - _WHOLE_FILE_DOC_IDS)
    all_excluded_titles = excluded_sec_titles | (
        excluded_doc_titles - {"regulatory & internet search mandates", "lrr internet search data"}
    )

    if not isinstance(payload, list):
        if whole_file_excluded or _is_excluded_doc_entry(payload):
            return []
        return payload

    if whole_file_excluded:
        return []

    filtered_items: list[Any] = []
    mandate_idx = 0
    for idx, entry in enumerate(payload, start=1):
        if not isinstance(entry, dict):
            filtered_items.append(entry)
            continue
        if _is_excluded_doc_entry(entry):
            continue
        if isinstance(entry.get("Mandates"), list):
            kept_mandates: list[dict[str, Any]] = []
            for mandate in entry["Mandates"]:
                if not isinstance(mandate, dict):
                    continue
                mandate_idx += 1
                if _is_excluded_doc_entry(mandate):
                    continue
                mtitle = str(
                    mandate.get("Regulatory Mandate")
                    or mandate.get("mandate")
                    or mandate.get("Citation")
                    or ""
                ).strip().lower()
                id_hit = (
                    str(mandate_idx) in all_excluded_ids
                    or f"lrr:mandate:{mandate_idx}" in all_excluded_ids
                )
                title_hit = bool(mtitle and mtitle in all_excluded_titles)
                if not id_hit and not title_hit:
                    kept_mandates.append(mandate)
            if kept_mandates:
                filtered_items.append({**entry, "Mandates": kept_mandates})
        else:
            pnum = str(entry.get("plan_item_number") or idx).strip().lower()
            title = str(entry.get("plan_item_title") or entry.get("title") or "").strip().lower()
            if (
                pnum in all_excluded_ids
                or f"lrr:search:{idx}" in all_excluded_ids
                or (title and title in all_excluded_titles)
            ):
                continue
            filtered_items.append(entry)
    return filtered_items


def _get_policy_artifact_data(plan_id: str) -> list[dict[str, Any]]:
    """Load and merge referenced_documents from all 3 policy-type artifacts."""
    policy_root_uri = _artifact_uri(plan_id, PlanArtifact.POLICY)
    legacy_policy_root_uri = f"{inbound_prefix_uri(plan_id)}/policy"
    combined_referenced_documents: list[dict[str, Any]] = []
    found_payload = False

    db_meta_map: dict[str, dict[str, Any]] = {}
    try:
        db_meta_map = DBConnector().get_data_extraction_metadata_map(plan_number=plan_id)
    except Exception:
        db_meta_map = {}

    for document_type in POLICY_DOCUMENT_TYPES:
        db_excluded_ids: set[str] = set()
        db_excluded_titles: set[str] = set()
        db_source_meta = db_meta_map.get(document_type)
        if isinstance(db_source_meta, dict):
            for doc in db_source_meta.get("documents") or []:
                if not isinstance(doc, dict):
                    continue
                doc_sections = [s for s in (doc.get("sections") or []) if isinstance(s, dict)]
                all_secs_excluded = bool(doc_sections) and all(
                    _is_excluded_doc_entry(s) for s in doc_sections
                )
                if _is_excluded_doc_entry(doc) or all_secs_excluded:
                    if doc.get("document_id") not in (None, ""):
                        db_excluded_ids.add(str(doc.get("document_id")).strip())
                    for t_key in ("document_title", "title", "document_name", "name"):
                        if doc.get(t_key):
                            db_excluded_titles.add(str(doc.get(t_key)).strip().lower())

        # 1. Check per-document folder (relevant_{document_type}/) where query-service
        # deletes/excludes or uploads individual policy1.json / procedure4.json files.
        parts_folder_uri = f"{policy_root_uri}/relevant_{document_type}"
        try:
            part_uris = list_json_blobs_in_gcs(parts_folder_uri)
        except Exception:
            part_uris = []

        if part_uris:
            found_payload = True
            for part_uri in part_uris:
                try:
                    part_doc = download_json_from_gcs(part_uri)
                except Exception:
                    continue
                if not isinstance(part_doc, dict) or _is_excluded_doc_entry(part_doc):
                    continue
                part_nodes = [n for n in (part_doc.get("nodes") or []) if isinstance(n, dict)]
                if part_nodes and all(_is_excluded_doc_entry(n) for n in part_nodes):
                    continue
                part_id = str(part_doc.get("document_id") or "").strip()
                doc_name = (
                    part_doc.get("document_name")
                    or part_doc.get("document_title")
                    or part_doc.get("title")
                    or part_doc.get("name")
                )
                if (part_id and part_id in db_excluded_ids) or (
                    doc_name and str(doc_name).strip().lower() in db_excluded_titles
                ):
                    continue
                doc_uri = (
                    part_doc.get("gs_uri")
                    or part_doc.get("source_uri")
                    or part_doc.get("storage_uri")
                    or part_doc.get("uri")
                    or part_uri
                )
                if doc_name or doc_uri:
                    combined_referenced_documents.append(
                        {
                            "document_type": document_type,
                            "document_name": doc_name,
                            "gs_uri": doc_uri,
                        }
                    )
            continue

        # 2. Fallback to relevant_{document_type}.json registry file.
        preferred_uri = f"{policy_root_uri}/{_relevant_filename_for_document_type(document_type)}"
        legacy_flat_uri = f"{policy_root_uri}/relevant_{document_type}.json"
        legacy_nested_uri = f"{legacy_policy_root_uri}/{document_type}/relevant_{document_type}.json"
        legacy_data_uri = f"{legacy_policy_root_uri}/{document_type}/relevant_data.json"

        file_found = False
        payload = None
        for candidate_uri in (preferred_uri, legacy_flat_uri, legacy_nested_uri, legacy_data_uri):
            file_found, payload = _load_json_if_present(candidate_uri)
            if file_found:
                break
        if not file_found:
            continue

        found_payload = True
        def _append_from_items(
            items: list[Any],
            ex_ids: set[str],
            ex_titles: set[str],
        ) -> None:
            for item in items:
                if not isinstance(item, dict) or _is_excluded_doc_entry(item):
                    continue
                item_id = str(item.get("document_id") or "").strip()
                doc_name = (
                    item.get("document_name")
                    or item.get("document_title")
                    or item.get("title")
                    or item.get("name")
                )
                if (item_id and item_id in ex_ids) or (
                    doc_name and str(doc_name).strip().lower() in ex_titles
                ):
                    continue
                doc_uri = (
                    item.get("gs_uri")
                    or item.get("storage_uri")
                    or item.get("source_uri")
                    or item.get("uri")
                )
                if doc_name or doc_uri:
                    combined_referenced_documents.append(
                        {
                            "document_type": document_type,
                            "document_name": doc_name,
                            "gs_uri": doc_uri,
                        }
                    )

        if isinstance(payload, list):
            _append_from_items(payload, db_excluded_ids, db_excluded_titles)
        elif isinstance(payload, dict):
            referenced_documents = payload.get("referenced_documents")
            documents_list = payload.get("documents")
            excluded_ids: set[str] = set(db_excluded_ids)
            excluded_titles: set[str] = set(db_excluded_titles)
            if isinstance(documents_list, list):
                for doc in documents_list:
                    if isinstance(doc, dict) and _is_excluded_doc_entry(doc):
                        if doc.get("document_id") not in (None, ""):
                            excluded_ids.add(str(doc.get("document_id")).strip())
                        for t_key in ("document_title", "title", "document_name", "name"):
                            if doc.get(t_key):
                                excluded_titles.add(str(doc.get(t_key)).strip().lower())
            if isinstance(referenced_documents, list) and referenced_documents:
                _append_from_items(referenced_documents, excluded_ids, excluded_titles)
            elif isinstance(documents_list, list) and documents_list:
                _append_from_items(documents_list, excluded_ids, excluded_titles)
            elif isinstance(payload.get("sources"), list):
                _append_from_items(payload["sources"], excluded_ids, excluded_titles)

    if not found_payload:
        raise FileNotFoundError(f"No data found for plan {plan_id} artifact {PlanArtifact.POLICY.value}")

    return _dedup_documents(combined_referenced_documents)



def _artifact_uri(plan_number: str, artifact: PlanArtifact) -> str:
    base = inbound_prefix_uri(plan_number)
    if artifact in ARTIFACT_FOLDERS:
        return f"{base}/{ARTIFACT_FOLDERS[artifact]}"
    return f"{base}/{ARTIFACT_FILES[artifact]}"


def check_plan_data_availability(plan_number: str) -> dict[str, Any]:
    """Report whether the plan's root prefix exists in the bucket."""
    plan_id = _validate_plan_number(plan_number)
    plan_prefix = plan_prefix_uri(plan_id)
    plan_exists = gcs_prefix_exists(plan_prefix)

    return {
        "plan_number": plan_id,
        "available": plan_exists,
    }


def get_plan_artifact(plan_number: str, artifact: PlanArtifact) -> dict[str, Any]:
    """Return the stored content of one extracted artifact for a plan."""
    plan_id = _validate_plan_number(plan_number)
    # Calling Action-Service
    start_time = datetime.now(timezone.utc)
    agent_card = AgentCard.get_agent_card(plan_number.strip()) or {}
    action_service.construct_human_actor_retrieve_records(
        plan_number=plan_number,
        artifact=artifact.value,
        agent_card=agent_card,
    )

    if artifact is PlanArtifact.POLICY:
        uri = _artifact_uri(plan_id, artifact)
        referenced_documents = _get_policy_artifact_data(plan_id)
        response = {
            "plan_number": plan_id,
            "artifact": artifact.value,
            "source": uri,
            "data": {"referenced_documents": referenced_documents},
            "status": 'SUCCESS',
            "response_code": 200
        }
        action_service.construct_ai_actor_retrieve_records(
            plan_number=plan_number,
            artifact=artifact.value,
            response=response,
            agent_card=agent_card,
            start_time=start_time,
            end_time=datetime.now(timezone.utc),
        )
        return response

    uri = _artifact_uri(plan_id, artifact)

    response = {
        "plan_number": plan_id,
        "artifact": artifact.value,
        "source": uri,
    }

    if artifact in ARTIFACT_FOLDERS:
        blob_uris = list_json_blobs_in_gcs(uri)
        if not blob_uris:
            response["response_code"] = 500
            response["status"] = 'FAILED'
            action_service.construct_ai_actor_retrieve_records(
                plan_number=plan_number,
                artifact=artifact.value,
                response=response,
                agent_card=agent_card,
                start_time=start_time,
                end_time=datetime.now(timezone.utc),
            )
            raise FileNotFoundError(f"No data found for plan {plan_id} artifact {artifact.value}")
        data = {Path(blob_uri).stem: download_json_from_gcs(blob_uri) for blob_uri in blob_uris}
    else:
        resolved_uri = uri
        if not json_exists_in_gcs(resolved_uri):
            enriched_fallback = (
                f"{inbound_prefix_uri(plan_id)}/lrr/internet_search_data_enriched.json"
                if artifact is PlanArtifact.LRR
                else None
            )
            if enriched_fallback and json_exists_in_gcs(enriched_fallback):
                resolved_uri = enriched_fallback
                response["source"] = resolved_uri
            else:
                response["response_code"] = 500
                response["status"] = 'FAILED'
                action_service.construct_ai_actor_retrieve_records(
                    plan_number=plan_number,
                    artifact=artifact.value,
                    response=response,
                    agent_card=agent_card,
                    start_time=start_time,
                    end_time=datetime.now(timezone.utc),
                )
                raise FileNotFoundError(f"No data found for plan {plan_id} artifact {artifact.value}")

        raw_payload = download_json_from_gcs(resolved_uri)
        if artifact in (
            PlanArtifact.HISTORICAL_PLAN_DETAILS,
            PlanArtifact.FINDINGS_DETAILS,
            PlanArtifact.LRR,
        ):
            try:
                db_meta_map = DBConnector().get_data_extraction_metadata_map(plan_number=plan_id)
            except Exception:
                db_meta_map = {}
            if artifact is PlanArtifact.HISTORICAL_PLAN_DETAILS:
                raw_payload = _filter_historical_plan_payload(
                    raw_payload, db_meta_map.get("historical_plan_details")
                )
            elif artifact is PlanArtifact.FINDINGS_DETAILS:
                raw_payload = _filter_gfms_payload(
                    raw_payload, db_meta_map.get("findings_details")
                )
            elif artifact is PlanArtifact.LRR:
                raw_payload = _filter_lrr_payload(raw_payload, db_meta_map.get("lrr"))

        data = {Path(resolved_uri).stem: raw_payload}

    response["status"] = 'SUCCESS'
    response["response_code"] = 200
    response["data"] = data
    end_time = datetime.now(timezone.utc)
    action_service.construct_ai_actor_retrieve_records(
        plan_number=plan_number,
        artifact=artifact.value,
        response=response,
        agent_card=agent_card,
        start_time=start_time,
        end_time=end_time,
    )
    return response
