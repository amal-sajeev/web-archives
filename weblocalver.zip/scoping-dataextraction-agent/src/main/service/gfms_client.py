import json
import logging
from typing import Any, Dict

from config.settings import Config
from util.mcp_client import MCPClient
from util.status_helper import  update_session_extract_mcp_tool

logger = logging.getLogger(__name__)


def create_gfms_payload_from_dbaware(plan_item: Any) -> Dict[str, Any]:
    """
    Transforms a dbAware plan item into a payload for the GFMS findings API.

    Args:
        plan_item: A dictionary (or list of dictionaries) representing a plan item from the dbAware "current_data".

    Returns:
        A dictionary formatted as the request body for the GFMS API containing control and findingStatus.
    """
    payload: Dict[str, Any] = {}
    records = (
        [item for item in plan_item if isinstance(item, dict)]
        if isinstance(plan_item, list)
        else ([plan_item] if isinstance(plan_item, dict) else [])
    )

    unique_kcs: list[str] = []
    seen_kcs: set[str] = set()
    for record in records:
        for item in record.get("AU-RT-KC") or []:
            if not isinstance(item, dict):
                continue
            kc = str(item.get("KC") or "").strip()
            if kc and len(kc) > 3 and kc not in seen_kcs:
                seen_kcs.add(kc)
                unique_kcs.append(kc)

    if unique_kcs:
        payload["control"] = [
            {"id": 1, "name": kc, "control": kc} for kc in unique_kcs
        ]

    payload["findingStatus"] = [{"id": 0, "name": "Open"}]

    logger.debug(
        "Built GFMS payload with control count: %d", len(payload.get("control", []))
    )
    return payload


async def get_gfms_findings(session_id: str, payload: Dict[str, Any]) -> Any:
    """
    Fetches GFMS findings based on the provided payload.

    Args:
        payload: The GFMS request payload.

    Returns:
        The findings data from the MCP tool.
    """
    if isinstance(payload, dict):
        ctrl = payload.get("control")
        control_count = (
            len(ctrl)
            if isinstance(ctrl, list)
            else (1 if isinstance(ctrl, dict) and ctrl else 0)
        )
        logger.info("Fetching GFMS findings for %d control(s)", control_count)
    else:
        logger.info("Fetching GFMS findings")

    mcp = MCPClient(Config.data_extraction_mcp_server_url)
    try:
        gfms_result = await mcp.invoke("get_gfms_finding_data", {"request": payload})
        update_session_extract_mcp_tool(session_id, 'get_gfms_finding_data')
        logger.info("Successfully fetched GFMS findings")
        return gfms_result
    except Exception as exc:
        ctrl = payload.get("control") if isinstance(payload, dict) else None
        payload_controls = (
            len(ctrl)
            if isinstance(ctrl, list)
            else (1 if isinstance(ctrl, dict) and ctrl else 0)
        )
        logger.warning(
            "GFMS call failed: payload_controls=%s error=%s",
            payload_controls,
            exc,
        )
        raise
    finally:
        try:
            await mcp.close()
        except Exception as exc:
            logger.warning("GFMS MCP client close failed: %s", exc)
