import asyncio
import base64
import json
import logging
import os
import re
from pathlib import Path
from time import perf_counter
from typing import Any

import httpx

from config.settings import Config

logger = logging.getLogger(__name__)

DOCUMENT_TYPES = ("policy", "procedure", "kod")
LIST_FIELDS = (
    "au_countries",
    "au_list",
    "rt_list",
    "kc_list",
    "control_name",
    "control_how",
    "control_what",
    "control_why",
)
RETRY_STATUS_CODES = {429, 500, 502, 503, 504}
MAX_RETRIES = 3
BACKOFF_BASE_SECONDS = 0.5
RAG_TIMEOUT_SECONDS = 180.0


def _relevant_metadata_filename(document_type: str) -> str:
    return f"relevant_{document_type}.json"


def _split_semicolon_field(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [part.strip() for part in str(value).split(";") if part.strip()]


def _normalize_to_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _dedup_keep_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


def _dedup_documents(documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []

    for document in documents:
        if not isinstance(document, dict):
            continue

        key = str(
            document.get("gs_uri")
            or document.get("document_name")
            or json.dumps(document, sort_keys=True, default=str)
        )
        if key in seen:
            continue

        seen.add(key)
        deduped.append(document)

    return deduped


def _extract_referenced_documents(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, dict):
        referenced = result_payload.get("referenced_documents")
        if isinstance(referenced, list):
            return [item for item in referenced if isinstance(item, dict)]
    return []


def _extract_citations(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, dict):
        citations = result_payload.get("citations")
        if isinstance(citations, list):
            return [item for item in citations if isinstance(item, dict)]
    return []


def _extract_control_fields(dbgrc_analysis: dict[str, Any]) -> dict[str, list[str]]:
    controls = [
        item for item in _normalize_to_list(dbgrc_analysis.get("included_kcs")) if isinstance(item, dict)
    ]
    if not controls and isinstance(dbgrc_analysis.get("excluded_kcs"), list):
        controls = [
            item["details"]
            for item in dbgrc_analysis["excluded_kcs"]
            if isinstance(item, dict) and isinstance(item.get("details"), dict)
        ]

    control_name: list[str] = []
    control_how: list[str] = []
    control_what: list[str] = []
    control_why: list[str] = []

    for control in controls:
        inventory = (
            control.get("inventory")
            if isinstance(control.get("inventory"), dict)
            else {}
        )
        definition = (
            control.get("definition")
            if isinstance(control.get("definition"), dict)
            else {}
        )
        details = (
            control.get("details") if isinstance(control.get("details"), dict) else {}
        )

        name = (
            inventory.get("controlDefinitionNumber")
            or inventory.get("externalReferenceId")
            or definition.get("controlDefinitionNumber")
            or definition.get("externalReferenceId")
            or details.get("control_name")
            or details.get("name")
            or control.get("controlIdentifier")
        )
        how_value = (
            details.get("control_how")
            or details.get("how")
            or details.get("description")
            or inventory.get("controlHow")
            or inventory.get("controlDescription")
            or definition.get("controlHow")
            or definition.get("description")
        )
        what_value = (
            details.get("control_what")
            or details.get("what")
            or inventory.get("controlWhat")
            or definition.get("controlWhat")
        )
        why_value = (
            details.get("control_why")
            or details.get("why")
            or inventory.get("controlWhy")
            or definition.get("controlWhy")
        )

        if name:
            control_name.append(str(name).strip())
        if how_value:
            control_how.append(str(how_value).strip())
        if what_value:
            control_what.append(str(what_value).strip())
        if why_value:
            control_why.append(str(why_value).strip())

    return {
        "control_name": _dedup_keep_order([item for item in control_name if item]),
        "control_how": _dedup_keep_order([item for item in control_how if item]),
        "control_what": _dedup_keep_order([item for item in control_what if item]),
        "control_why": _dedup_keep_order([item for item in control_why if item]),
    }


def build_rag_base_payload(
    review_id: str,
    plan_item: dict[str, Any],
    dbgrc_analysis: dict[str, Any],
) -> dict[str, Any]:
    if not isinstance(plan_item, dict):
        raise ValueError("plan_item must be a dictionary.")

    au_rt_kc = _normalize_to_list(plan_item.get("AU-RT-KC"))
    au_list: list[str] = []
    rt_list: list[str] = []
    kc_list: list[str] = []

    # Extract Risk Type from UoT Risk Type field (has full description)
    uot_rt = str(plan_item.get("UoT Risk Type") or "").strip()
    if uot_rt:
        rt_list.append(uot_rt)

    # Extract Key Controls from UoT KCs field (has full description)
    uot_kc = str(plan_item.get("UoT KCs") or "").strip()
    if uot_kc:
        kc_list = _split_semicolon_field(uot_kc)

    for row in au_rt_kc:
        if not isinstance(row, dict):
            continue

        au_raw = str(row.get("AU") or "").strip()
        if au_raw:
            au_parts = [part.strip() for part in au_raw.split("~")]
            if len(au_parts) > 4 and au_parts[4]:
                au_list.append(au_parts[4])
            else:
                au_list.append(au_raw)

    control_fields = _extract_control_fields(dbgrc_analysis)
    review_id_str = str(review_id).strip()
    plan_item_title = str(plan_item.get("Plan Item Title") or "").strip() or f"Plan {review_id_str}"
    plan_item_description = (
        str(plan_item.get("Description of Plan Item") or "").strip() or plan_item_title
    )

    return {
        "review_id": review_id_str,
        "region": str(plan_item.get("UoT Regions") or "").strip(),
        "au_countries": _split_semicolon_field(plan_item.get("UoT Countries")),
        "plan_item_title": plan_item_title,
        "plan_item_description": plan_item_description,
        "au_list": _dedup_keep_order([item for item in au_list if item]),
        "rt_list": _dedup_keep_order([item for item in rt_list if item]),
        "kc_list": _dedup_keep_order([item for item in kc_list if item]),
        "control_name": control_fields["control_name"],
        "control_how": control_fields["control_how"],
        "control_what": control_fields["control_what"],
        "control_why": control_fields["control_why"],
    }


def validate_base_payload(base_payload: dict[str, Any]) -> None:
    if not isinstance(base_payload, dict):
        raise ValueError("RAG base payload must be a dictionary.")

    required_scalar_fields = (
        "review_id",
        "plan_item_title",
        "plan_item_description",
    )

    for field_name in required_scalar_fields:
        value = base_payload.get(field_name)
        if value is None or not str(value).strip():
            raise ValueError(f"Missing required payload field: {field_name}")

    for field_name in LIST_FIELDS:
        if field_name not in base_payload:
            raise ValueError(f"Missing required list field: {field_name}")
        if not isinstance(base_payload[field_name], list):
            raise ValueError(f"Payload field '{field_name}' must be a list.")


def _compose_rag_url() -> str:
    base = Config.RAG_BASE_URL.strip().rstrip("/")
    if not base:
        raise ValueError("RAG_BASE_URL is required.")
    if base.endswith("/get-relevant-data"):
        return base
    return f"{base}/get-relevant-data"


def _auth_headers(request_id: str | None) -> dict[str, str]:
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if request_id:
        headers["X-Request-ID"] = request_id
    return headers


async def _post_with_retry(
    client: httpx.AsyncClient,
    url: str,
    json_payload: dict[str, Any],
    headers: dict[str, str],
    request_id: str | None,
    document_type: str,
) -> httpx.Response:
    last_error: Exception | None = None

    for attempt in range(MAX_RETRIES + 1):
        try:
            response = await client.post(url, json=json_payload, headers=headers)

            if response.status_code in RETRY_STATUS_CODES and attempt < MAX_RETRIES:
                wait_seconds = BACKOFF_BASE_SECONDS * (2**attempt)
                logger.warning(
                    "RAG retry scheduled request_id=%s document_type=%s status=%s attempt=%s wait_seconds=%s",
                    request_id,
                    document_type,
                    response.status_code,
                    attempt + 1,
                    wait_seconds,
                )
                await asyncio.sleep(wait_seconds)
                continue

            return response
        except (
            httpx.ConnectError,
            httpx.ReadTimeout,
            httpx.RemoteProtocolError,
        ) as error:
            last_error = error
            if attempt >= MAX_RETRIES:
                break
            wait_seconds = BACKOFF_BASE_SECONDS * (2**attempt)
            logger.warning(
                "RAG transient error request_id=%s document_type=%s attempt=%s wait_seconds=%s error=%s",
                request_id,
                document_type,
                attempt + 1,
                wait_seconds,
                error,
            )
            await asyncio.sleep(wait_seconds)

    if last_error is not None:
        raise RuntimeError(
            f"RAG call failed for {document_type}: {last_error}"
        ) from last_error

    raise RuntimeError(f"RAG call failed for {document_type}: exhausted retries")


async def call_rag(
    document_type: str,
    base_payload: dict[str, Any],
    *,
    request_id: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    if document_type not in DOCUMENT_TYPES:
        raise ValueError(f"Unsupported document_type: {document_type}")

    validate_base_payload(base_payload)

    payload = dict(base_payload)
    payload["document_type"] = document_type

    url = _compose_rag_url()
    headers = _auth_headers(request_id)

    started = perf_counter()
    owns_client = client is None
    rag_client = client or httpx.AsyncClient(timeout=RAG_TIMEOUT_SECONDS)

    try:
        logger.info(
            "RAG request started request_id=%s document_type=%s",
            request_id,
            document_type,
        )
        response = await _post_with_retry(
            rag_client, url, payload, headers, request_id, document_type
        )

        if response.status_code >= 400:
            error_body = response.text[:1000]
            raise RuntimeError(
                f"RAG call failed for {document_type}. status={response.status_code}, body={error_body}"
            )

        try:
            response_json = response.json()
        except json.JSONDecodeError as error:
            raise RuntimeError(
                f"RAG response for {document_type} was not valid JSON"
            ) from error

        latency_ms = round((perf_counter() - started) * 1000, 2)
        logger.info(
            "RAG request completed request_id=%s document_type=%s latency_ms=%s",
            request_id,
            document_type,
            latency_ms,
        )

        return {
            "response": response_json,
            "latency_ms": latency_ms,
        }
    finally:
        if owns_client:
            await rag_client.aclose()


async def get_all_relevant_data(
    base_payload: dict[str, Any],
    *,
    request_id: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    validate_base_payload(base_payload)

    started = perf_counter()
    results: dict[str, Any] = {doc_type: None for doc_type in DOCUMENT_TYPES}
    errors: dict[str, Any] = {doc_type: None for doc_type in DOCUMENT_TYPES}
    latency_ms_per_type: dict[str, float] = {
        doc_type: 0.0 for doc_type in DOCUMENT_TYPES
    }
    combined_referenced_documents: list[dict[str, Any]] = []
    combined_citations: list[dict[str, Any]] = []

    for doc_type in DOCUMENT_TYPES:
        try:
            outcome = await call_rag(
                document_type=doc_type,
                base_payload=base_payload,
                request_id=request_id,
                client=client,
            )
        except BaseException as error:
            errors[doc_type] = str(error)
            logger.error(
                "RAG request failed request_id=%s document_type=%s error=%s",
                request_id,
                doc_type,
                error,
            )
            continue

        results[doc_type] = outcome.get("response")
        latency_ms_per_type[doc_type] = float(outcome.get("latency_ms") or 0.0)
        combined_referenced_documents.extend(
            _extract_referenced_documents(outcome.get("response"))
        )
        combined_citations.extend(_extract_citations(outcome.get("response")))

    successful_count = sum(1 for item in results.values() if item is not None)
    if successful_count == len(DOCUMENT_TYPES):
        status = "success"
    elif successful_count == 0:
        status = "failed"
    else:
        status = "partial_success"

    return {
        "status": status,
        "query_context": {
            "review_id": base_payload.get("review_id"),
            "region": base_payload.get("region"),
            "plan_item_title": base_payload.get("plan_item_title"),
        },
        "results": results,
        "errors": errors,
        "referenced_documents": _dedup_documents(combined_referenced_documents),
        "citations": _dedup_documents(combined_citations),
        "latency_ms_per_type": latency_ms_per_type,
        "total_latency_ms": round((perf_counter() - started) * 1000, 2),
    }


def _extract_candidate_documents(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, dict):
        if isinstance(result_payload.get("documents"), list):
            return [
                item for item in result_payload["documents"] if isinstance(item, dict)
            ]
        if isinstance(result_payload.get("data"), dict) and isinstance(
            result_payload["data"].get("documents"), list
        ):
            return [
                item
                for item in result_payload["data"]["documents"]
                if isinstance(item, dict)
            ]
        if isinstance(result_payload.get("items"), list):
            return [item for item in result_payload["items"] if isinstance(item, dict)]
    return []


def _group_sources_into_documents(sources: Any) -> list[dict[str, Any]]:
    """Group flat RAG `sources[]` chunks into document dicts when `documents` is absent."""
    if not isinstance(sources, list) or not sources:
        return []
    grouped: dict[str, dict[str, Any]] = {}
    for item in sources:
        if not isinstance(item, dict):
            continue
        doc_id = item.get("document_id")
        uri = str(item.get("gs_uri") or item.get("storage_uri") or "").strip()
        title = str(
            item.get("document_name")
            or item.get("document_title")
            or item.get("title")
            or item.get("name")
            or ""
        ).strip()
        key = str(doc_id).strip() if doc_id not in (None, "") else (uri or title.lower())
        if not key:
            continue
        if key not in grouped:
            doc_entry: dict[str, Any] = {
                "document_name": title or uri,
                "document_title": title or uri,
                "gs_uri": uri,
                "nodes": [],
            }
            if doc_id not in (None, ""):
                doc_entry["document_id"] = doc_id
            if item.get("document_type"):
                doc_entry["document_type"] = item["document_type"]
            if item.get("classification"):
                doc_entry["classification"] = item["classification"]
            grouped[key] = doc_entry
        grouped[key]["nodes"].append(item)
    return list(grouped.values())


def _enrich_referenced_documents(
    ref_docs: list[dict[str, Any]],
    sources: Any,
) -> list[dict[str, Any]]:
    if not isinstance(sources, list) or not sources:
        return ref_docs
    by_uri: dict[str, dict[str, Any]] = {}
    by_title: dict[str, dict[str, Any]] = {}
    for src in sources:
        if not isinstance(src, dict):
            continue
        uri = str(src.get("gs_uri") or src.get("storage_uri") or "").strip()
        title = str(
            src.get("document_name") or src.get("document_title") or src.get("title") or ""
        ).strip().lower()
        if uri and uri not in by_uri:
            by_uri[uri] = src
        if title and title not in by_title:
            by_title[title] = src

    enriched: list[dict[str, Any]] = []
    for doc in ref_docs:
        item = dict(doc)
        uri = str(item.get("gs_uri") or item.get("storage_uri") or "").strip()
        title = str(
            item.get("document_name")
            or item.get("document_title")
            or item.get("title")
            or item.get("name")
            or ""
        ).strip().lower()
        matched = (by_uri.get(uri) if uri else None) or (by_title.get(title) if title else None)
        if matched:
            if item.get("document_id") in (None, "") and matched.get("document_id") not in (None, ""):
                item["document_id"] = matched["document_id"]
            if not item.get("classification") and matched.get("classification"):
                item["classification"] = matched["classification"]
        enriched.append(item)
    return enriched


def _extract_relevant_documents(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, list):
        return [item for item in result_payload if isinstance(item, dict)]
    if not isinstance(result_payload, dict):
        return []
    if result_payload.get("document_id") is not None:
        return [result_payload]

    data = result_payload.get("data")
    top_sources = result_payload.get("sources")
    data_sources = data.get("sources") if isinstance(data, dict) else None
    all_sources = top_sources if isinstance(top_sources, list) else data_sources

    for container in (result_payload, data if isinstance(data, dict) else None):
        if not isinstance(container, dict):
            continue
        documents = container.get("documents")
        if isinstance(documents, list) and documents:
            return [item for item in documents if isinstance(item, dict)]
        referenced = container.get("referenced_documents")
        if isinstance(referenced, list) and referenced:
            ref_docs = [item for item in referenced if isinstance(item, dict)]
            return _enrich_referenced_documents(ref_docs, all_sources)
        items = container.get("items")
        if isinstance(items, list) and items:
            return [item for item in items if isinstance(item, dict)]

    if isinstance(top_sources, list) and top_sources:
        return _group_sources_into_documents(top_sources)
    if isinstance(data_sources, list) and data_sources:
        return _group_sources_into_documents(data_sources)
    return []


def _sanitize_filename(name: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return safe or "document"


def _decode_base64_field(item: dict[str, Any]) -> bytes | None:
    for key in ("pdf_base64", "content_base64", "file_base64", "blob_base64"):
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            try:
                return base64.b64decode(value)
            except Exception:
                logger.warning("Unable to decode base64 field %s", key)
                return None
    return None


async def _download_pdf_bytes(
    client: httpx.AsyncClient,
    url: str,
    *,
    request_id: str | None,
    document_type: str,
) -> bytes | None:
    try:
        response = await client.get(url, headers=_auth_headers(request_id))
    except Exception:
        logger.exception(
            "Failed to download document bytes request_id=%s document_type=%s url=%s",
            request_id,
            document_type,
            url,
        )
        return None

    if response.status_code >= 400:
        logger.warning(
            "Document download returned non-2xx request_id=%s document_type=%s status=%s url=%s",
            request_id,
            document_type,
            response.status_code,
            url,
        )
        return None
    return response.content


def _resolve_bucket_name(bucket_name: str | None = None) -> str:
    if bucket_name and str(bucket_name).strip():
        return str(bucket_name).strip()
    return (
        os.getenv("bucket_name", "").strip()
        or os.getenv("BUCKET_NAME", "").strip()
        or os.getenv("GCS_BUCKET_NAME", "").strip()
        or "db-dev-euwe3-gcs-155081-dbaware_review"
    )


_EXTRA_SECTION_SCALAR_FIELDS = (
    "section_path",
    "parent_node_id",
    "content_type",
    "classification",
    "rationale",
    "impacted_process",
    "risk_scenario",
    "control_area",
    "testing_implication",
    "jurisdictional_applicability",
    "chunk_score_source",
)
_EXTRA_SECTION_RAW_FIELDS = (
    "chunk_id",
    "page_start",
    "page_end",
    "page_number",
    "source_start",
    "source_end",
    "similarity_score",
    "retrieval_score",
    "rrf_score",
    "chunk_relevance_score",
)


def _build_section_entry(
    node: dict[str, Any],
    doc_id_str: str,
    idx: int,
    doc_excluded: bool,
) -> dict[str, Any]:
    raw_sec_id = node.get("section_id")
    if raw_sec_id in (None, ""):
        raw_sec_id = node.get("source_index")
    section_id = raw_sec_id if raw_sec_id not in (None, "") else idx

    page_fallback = f"Page {node['page_number']}" if node.get("page_number") is not None else None
    section_title = str(
        node.get("section_title")
        or node.get("title")
        or node.get("section_path")
        or page_fallback
        or f"Section {section_id}"
    ).strip()
    node_id = str(node.get("node_id") or f"{doc_id_str}:section:{section_id}").strip()

    sec_excluded = bool(node.get("excluded", False)) or doc_excluded
    raw_sec_status = str(node.get("status") or "").strip().lower()
    if raw_sec_status in {"excluded", "removed", "deleted", "inactive"}:
        sec_excluded = True
    sec_status = raw_sec_status if raw_sec_status else ("excluded" if sec_excluded else "active")

    entry: dict[str, Any] = {
        "section_id": section_id,
        "section_title": section_title,
        "node_id": node_id,
        "status": sec_status,
        "excluded": sec_excluded,
    }
    for field in _EXTRA_SECTION_SCALAR_FIELDS:
        if node.get(field) not in (None, ""):
            entry[field] = str(node.get(field))
    for field in _EXTRA_SECTION_RAW_FIELDS:
        if node.get(field) is not None:
            entry[field] = node.get(field)
    return entry


def build_rag_source_metadata_from_result(
    doc_type: str,
    rag_result: Any,
    plan_storage_key: str,
    *,
    bucket_name: str | None = None,
    error: str | None = None,
) -> dict[str, Any]:
    """Build structured document + section metadata for review_data_extraction."""
    resolved_bucket = _resolve_bucket_name(bucket_name)
    clean_key = str(plan_storage_key).strip("/")
    registry_filename = _relevant_metadata_filename(doc_type)
    registry_storage_uri = f"gs://{resolved_bucket}/{clean_key}/policy/{registry_filename}"

    relevant_documents = _extract_relevant_documents(rag_result)
    documents_metadata: list[dict[str, Any]] = []
    seen_docs: dict[tuple[str, str, str], dict[str, Any]] = {}
    seen_doc_section_keys: dict[tuple[str, str, str], set[tuple[str, str]]] = {}
    top_level_sources = (
        rag_result.get("sources")
        if isinstance(rag_result, dict) and isinstance(rag_result.get("sources"), list)
        else []
    )

    for doc_idx, document in enumerate(relevant_documents, start=1):
        if not isinstance(document, dict):
            continue
        raw_doc_id = document.get("document_id")
        if raw_doc_id in (None, ""):
            raw_doc_id = document.get("id")

        source_uri = str(
            document.get("storage_uri") or document.get("gs_uri") or ""
        ).strip()
        raw_title = (
            document.get("document_title")
            or document.get("title")
            or document.get("document_name")
            or document.get("name")
        )
        if raw_doc_id in (None, "") and not raw_title and not source_uri:
            continue

        has_explicit_doc_id = document.get("document_id") not in (None, "")
        doc_id_str = (
            str(raw_doc_id).strip()
            if raw_doc_id not in (None, "")
            else str(doc_idx)
        )
        if has_explicit_doc_id:
            file_name = f"{doc_type}{_sanitize_filename(doc_id_str)}.json"
            storage_uri = (
                f"gs://{resolved_bucket}/{clean_key}/policy/relevant_{doc_type}/{file_name}"
            )
        else:
            file_name = registry_filename
            storage_uri = registry_storage_uri

        doc_title = str(raw_title or file_name).strip()
        doc_version = str(document.get("document_version") or "").strip()
        doc_excluded = bool(document.get("excluded", False))
        raw_doc_status = str(document.get("status") or "").strip().lower()
        if raw_doc_status in {"excluded", "removed", "deleted", "inactive"}:
            doc_excluded = True
        doc_status = (
            raw_doc_status
            if raw_doc_status
            else ("excluded" if doc_excluded else "active")
        )

        raw_nodes = document.get("nodes")
        if not isinstance(raw_nodes, list):
            raw_nodes = (
                document.get("sections")
                if isinstance(document.get("sections"), list)
                else []
            )
        if not raw_nodes and top_level_sources:
            raw_nodes = [
                src
                for src in top_level_sources
                if isinstance(src, dict)
                and (
                    (
                        source_uri
                        and str(src.get("gs_uri") or src.get("storage_uri") or "").strip()
                        == source_uri
                    )
                    or (
                        raw_title
                        and str(
                            src.get("document_name")
                            or src.get("document_title")
                            or src.get("title")
                            or ""
                        ).strip().lower()
                        == str(raw_title).strip().lower()
                    )
                )
            ]

        doc_dedup_key = (doc_id_str, storage_uri, doc_title.lower())
        existing_section_keys = seen_doc_section_keys.setdefault(doc_dedup_key, set())
        sections: list[dict[str, Any]] = []
        for idx, node in enumerate(raw_nodes, start=1):
            if not isinstance(node, dict):
                continue
            section_entry = _build_section_entry(node, doc_id_str, idx, doc_excluded)
            dedup_key = (str(section_entry["node_id"]), str(section_entry["section_id"]))
            if dedup_key in existing_section_keys:
                continue
            existing_section_keys.add(dedup_key)
            sections.append(section_entry)

        if doc_dedup_key in seen_docs:
            seen_docs[doc_dedup_key]["sections"].extend(sections)
            continue

        doc_record: dict[str, Any] = {
            "filename": file_name,
            "storage_uri": storage_uri,
            "source_uri": source_uri,
            "document_id": doc_id_str,
            "document_title": doc_title,
            "document_version": doc_version,
            "document_type": doc_type,
            "status": doc_status,
            "excluded": doc_excluded,
            "sections": sections,
        }
        doc_classification = document.get("classification")
        if not doc_classification:
            for node in raw_nodes:
                if isinstance(node, dict) and node.get("classification"):
                    doc_classification = node["classification"]
                    break
        if doc_classification:
            doc_record["classification"] = str(doc_classification)
        for meta_key in ("rationale", "document_relevance_verdict"):
            if document.get(meta_key) not in (None, ""):
                doc_record[meta_key] = str(document[meta_key])
        if document.get("document_relevance_score") is not None:
            doc_record["document_relevance_score"] = document["document_relevance_score"]

        seen_docs[doc_dedup_key] = doc_record
        documents_metadata.append(doc_record)

    meta: dict[str, Any] = {
        "source_type": doc_type,
        "filename": registry_filename,
        "storage_uri": registry_storage_uri,
        "registry_filename": registry_filename,
        "registry_storage_uri": registry_storage_uri,
        "status": "active",
        "excluded": False,
        "documents": documents_metadata,
    }
    if error:
        meta["error"] = str(error)
    return meta


async def persist_rag_documents(
    aggregated_response: dict[str, Any],
    plan_storage_key: str,
    base_dir: str,
    *,
    request_id: str | None = None,
) -> dict[str, Any]:
    base_path = Path(base_dir) / plan_storage_key / "policy"
    base_path.mkdir(parents=True, exist_ok=True)

    write_report: dict[str, Any] = {
        doc_type: {"saved_files": [], "documents": []} for doc_type in DOCUMENT_TYPES
    }

    async with httpx.AsyncClient(timeout=RAG_TIMEOUT_SECONDS) as client:
        for doc_type in DOCUMENT_TYPES:
            rag_result = (aggregated_response.get("results") or {}).get(doc_type)
            metadata_path = base_path / _relevant_metadata_filename(doc_type)
            metadata_path.write_text(
                json.dumps(rag_result, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            write_report[doc_type]["saved_files"].append(str(metadata_path.name))
            source_meta = build_rag_source_metadata_from_result(
                doc_type,
                rag_result,
                plan_storage_key,
            )
            write_report[doc_type]["registry_storage_uri"] = source_meta[
                "registry_storage_uri"
            ]
            write_report[doc_type]["documents"] = source_meta["documents"]

            relevant_documents = _extract_relevant_documents(rag_result)
            relevant_folder = base_path / f"relevant_{doc_type}"
            for document in relevant_documents:
                document_id = document.get("document_id")
                if document_id in (None, ""):
                    logger.warning(
                        "Skipping relevant document without document_id document_type=%s",
                        doc_type,
                    )
                    continue
                relevant_folder.mkdir(parents=True, exist_ok=True)
                file_name = f"{doc_type}{_sanitize_filename(str(document_id))}.json"
                output_path = relevant_folder / file_name
                output_path.write_text(
                    json.dumps(document, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                write_report[doc_type]["saved_files"].append(
                    output_path.relative_to(base_path).as_posix()
                )

            if not isinstance(rag_result, dict):
                continue

            doc_folder = base_path / doc_type
            doc_folder.mkdir(parents=True, exist_ok=True)

            documents = _extract_candidate_documents(rag_result)
            for index, document in enumerate(documents, start=1):
                binary = _decode_base64_field(document)

                if binary is None:
                    candidate_url = document.get("pdf_url") or document.get("url")
                    if isinstance(candidate_url, str) and candidate_url.strip():
                        binary = await _download_pdf_bytes(
                            client,
                            candidate_url.strip(),
                            request_id=request_id,
                            document_type=doc_type,
                        )

                if binary is None:
                    continue

                name_from_payload = document.get("file_name") or document.get("name")
                file_name = _sanitize_filename(
                    str(name_from_payload)
                    if name_from_payload
                    else f"{doc_type}_{index}.pdf"
                )
                if not file_name.lower().endswith(".pdf"):
                    file_name = f"{file_name}.pdf"

                output_path = doc_folder / file_name
                output_path.write_bytes(binary)
                write_report[doc_type]["saved_files"].append(str(output_path.name))

    return write_report


def build_rag_metadata_payload(
    aggregated_response: dict[str, Any],
    *,
    persisted_files: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not isinstance(aggregated_response, dict):
        raise ValueError("aggregated_response must be a dictionary.")

    nested_payload: dict[str, Any] = {}
    results = (
        aggregated_response.get("results")
        if isinstance(aggregated_response, dict)
        else {}
    )
    if isinstance(results, dict):
        for doc_type in DOCUMENT_TYPES:
            if doc_type in results:
                nested_payload[doc_type] = json.loads(
                    json.dumps(results[doc_type], ensure_ascii=False, default=str)
                )

    metadata = {
        "status": aggregated_response.get("status"),
        "query_context": aggregated_response.get("query_context", {}),
        "errors": aggregated_response.get("errors", {}),
        "latency_ms_per_type": aggregated_response.get("latency_ms_per_type", {}),
        "total_latency_ms": aggregated_response.get("total_latency_ms"),
        "results": nested_payload,
    }
    if persisted_files is not None:
        metadata["persisted_files"] = json.loads(
            json.dumps(persisted_files, ensure_ascii=False, default=str)
        )
    return metadata
