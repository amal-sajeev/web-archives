import logging
from typing import Any, Dict, Iterable, List

from config.settings import Config
from util.risk_driver_matcher import select_applicable_risk_drivers
from util.mcp_client import MCPClient
from util.status_helper import update_session_extract_mcp_tool

logger = logging.getLogger(__name__)

DEFAULT_LIMIT = 1000


def _plan_items(current_data: Any) -> Iterable[Dict[str, Any]]:
    if isinstance(current_data, dict):
        yield current_data
    elif isinstance(current_data, list):
        yield from (item for item in current_data if isinstance(item, dict))


def _plan_risks(current_data: Any) -> List[Dict[str, str]]:
    risks: List[Dict[str, str]] = []
    seen: set[str] = set()

    for plan_item in _plan_items(current_data):
        risk_types = plan_item.get("UoT Risk Type")
        if isinstance(risk_types, str):
            for risk_type in risk_types.split(";"):
                risk_id, separator, risk_name = risk_type.partition("-")
                risk_id = risk_id.strip()
                if not risk_id:
                    continue

                if risk_id in seen:
                    existing = next(risk for risk in risks if risk["riskid"] == risk_id)
                    if not existing["risk_name"] and separator:
                        existing["risk_name"] = risk_name.strip()
                    continue

                seen.add(risk_id)
                risks.append({
                    "riskid": risk_id,
                    "risk_name": risk_name.strip() if separator else "",
                })
    return risks


def _risk_driver_records(response: Any) -> List[Dict[str, Any]]:
    if isinstance(response, list):
        return [record for record in response if isinstance(record, dict)]
    if isinstance(response, dict):
        for key in ("riskDrivers", "risk_drivers", "records", "results", "data"):
            records = response.get(key)
            if isinstance(records, list):
                return [record for record in records if isinstance(record, dict)]
    return []


def _record_risk_id(record: Dict[str, Any]) -> str:
    risk_id = record.get("riskId", record.get("risk_id", record.get("Risk ID")))
    return str(risk_id).strip() if risk_id is not None else ""


async def get_risk_driver_data(
    current_data: Any,
    limit: int = DEFAULT_LIMIT,
    session_id: str | None = None,
) -> List[Dict[str, Any]]:
    """Fetch plan risk drivers and return only semantically applicable drivers."""
    applicable_risks = _plan_risks(current_data)
    if not applicable_risks:
        logger.info("No risk IDs found in current plan; skipping risk-driver lookup")
        return []

    page_limit = max(1, int(limit))
    mcp_client = MCPClient(base_url=Config.data_extraction_mcp_server_url)
    risk_drivers_by_id: Dict[str, List[Dict[str, Any]]] = {
        risk["riskid"]: [] for risk in applicable_risks
    }
    offset = 0
    try:
        while True:
            page = _risk_driver_records(await mcp_client.invoke(
                "get_risk_drivers",
                {"offset": offset, "limit": page_limit},
            ))
            if session_id:
                update_session_extract_mcp_tool(session_id, "get_risk_drivers")
            for record in page:
                risk_id = _record_risk_id(record)
                if risk_id in risk_drivers_by_id:
                    risk_drivers_by_id[risk_id].append(record)
            if len(page) < page_limit:
                break
            offset += page_limit
    except Exception:
        logger.exception("Failed to fetch dbGRC risk-driver data")
        raise
    finally:
        try:
            await mcp_client.close()
        except Exception:
            logger.exception("Error closing risk-driver MCP client")

    logger.info(
        "Fetched %d risk-driver records for %d current-plan risk IDs",
        sum(len(records) for records in risk_drivers_by_id.values()),
        len(applicable_risks),
    )
    candidate_groups = [
        {
            "riskid": risk["riskid"],
            "risk_name": risk["risk_name"],
            "risk_drivers": risk_drivers_by_id[risk["riskid"]],
        }
        for risk in applicable_risks
    ]
    return select_applicable_risk_drivers(
        current_data,
        candidate_groups,
        session_id=session_id,
    )