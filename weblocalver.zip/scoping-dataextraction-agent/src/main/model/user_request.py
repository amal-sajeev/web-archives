from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class UserRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    review_scope_instance_id: int | str | None = Field(
        default=None,
        validation_alias=AliasChoices(
            "review_scope_instance_id",
            "review_scope_id",
            "reviewScopeId",
            "reviewScopeInstanceId",
        ),
    )
    process_instance_id: str | None = Field(
        default=None,
        validation_alias=AliasChoices("process_instance_id", "processInstanceId"),
    )
    task_id: str | None = Field(
        default=None,
        validation_alias=AliasChoices("task_id", "taskId"),
    )
    review_scope_stage: str | None = Field(
        default=None,
        validation_alias=AliasChoices(
            "review_scope_stage",
            "reviewScopeStage",
            "task_definition_key",
            "taskDefinitionKey",
        ),
    )
    user: str | None = Field(
        default=None,
        validation_alias=AliasChoices("user", "username", "email", "owner"),
    )
    remarks: str | None = None

    @property
    def review_scope_id(self) -> int | str | None:
        return self.review_scope_instance_id

