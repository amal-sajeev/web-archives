import os
import sys
import logging
import tempfile
import certifi
from typing import Dict, Any

from google.auth import default
from google.auth.transport.requests import Request
from langchain_google_genai import ChatGoogleGenerativeAI

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.settings import Config

logger = logging.getLogger(__name__)


AI_ACCESS_LAYER_BASE_URL = os.getenv("AI_ACCESS_LAYER_BASE_URL") or os.getenv(
    "GENAI_BASE_URL"
)
_CERTIFICATE_CONFIGURED = False


def _is_local_cert_auth_enabled() -> bool:
    """
    Enables custom certificate auth only when explicitly turned on.
    Intended for local development.
    """
    raw_value = str(os.getenv("ENABLE_LOCAL_CERT_AUTH", "")).strip().lower()
    return raw_value == "true"


def _is_local_runtime() -> bool:
    """
    Treat Kubernetes runtime as non-local; everything else defaults to local.
    """
    return not bool(os.getenv("KUBERNETES_SERVICE_HOST"))


def _set_ssl_bundle_env(path: str) -> None:
    """
    Set SSL bundle environment variables without overriding pre-existing values.
    """
    os.environ["REQUESTS_CA_BUNDLE"] = path
    os.environ["SSL_CERT_FILE"] = path
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = path
    os.environ["CURL_CA_BUNDLE"] = path


def configure_certificate(custom_cert_paths: list[str]) -> str:
    """
    Combines certifi's default CA bundle with one or more custom certificates
    and sets the required environment variables.
    """
    if not custom_cert_paths:
        raise ValueError("No custom certificate paths are set")

    # 1. Read the default trusted CA bundle from certifi
    with open(certifi.where(), "r", encoding="utf-8") as f:
        ca_bundle = f.read()

    custom_certs: list[str] = []
    for custom_cert_path in custom_cert_paths:
        if not os.path.exists(custom_cert_path):
            raise FileNotFoundError(f"Certificate file not found: {custom_cert_path}")

        with open(custom_cert_path, "r", encoding="utf-8") as f:
            custom_cert = f.read()

        if "-----BEGIN CERTIFICATE-----" not in custom_cert:
            raise ValueError(f"Certificate file is not PEM format: {custom_cert_path}")
        custom_certs.append(custom_cert)

    # 3. Create a combined bundle file in the same directory as the custom cert,
    # falling back to tempfile if the folder is OneDrive-protected or read-only.
    combined_path = os.path.join(
        os.path.dirname(custom_cert_paths[0]), "combined-ca-bundle.pem"
    )
    try:
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)
    except OSError:
        combined_path = os.path.join(
            tempfile.gettempdir(), "combined-ca-bundle.pem"
        )
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)

    # 4. Set the environment variables globally for the runtime
    os.environ["REQUESTS_CA_BUNDLE"] = combined_path
    os.environ["SSL_CERT_FILE"] = combined_path
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = combined_path
    return combined_path


def _configure_certificate_once() -> None:
    global _CERTIFICATE_CONFIGURED
    if _CERTIFICATE_CONFIGURED:
        return

    if not _is_local_runtime():
        configured_path = os.getenv("CA_BUNDLE_PATH", "").strip()
        if configured_path:
            _set_ssl_bundle_env(configured_path)
            logger.info(
                "Configured SSL CA bundle from CA_BUNDLE_PATH: %s", configured_path
            )
        else:
            logger.info("CA_BUNDLE_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    if not _is_local_cert_auth_enabled():
        logger.info("Local certificate auth is disabled; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    custom_paths = str(os.getenv("CUSTOM_CERT_PATHS") or "").strip()
    if custom_paths:
        cert_paths = [p.strip() for p in custom_paths.split(",") if p.strip()]
    else:
        legacy_path = str(os.getenv("CUSTOM_CERT_PATH") or "").strip()
        cert_paths = [legacy_path] if legacy_path else []

    if not cert_paths:
        logger.info("CUSTOM_CERT_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    combined_path = configure_certificate(cert_paths)
    logger.info("Custom certificate bundle configured at: %s", combined_path)
    _CERTIFICATE_CONFIGURED = True


class GoogleOAuthTokenProvider:
    def __init__(self):
        _configure_certificate_once()
        self.credentials, _ = default(
            scopes=[
                "https://www.googleapis.com/auth/cloud-platform",
                "https://www.googleapis.com/auth/userinfo.email",
            ]
        )
        self.request = Request()

    @property
    def token(self):
        if not self.credentials.valid:
            _configure_certificate_once()
            self.credentials.refresh(self.request)
        return self.credentials.token


def initialize_gemini_model() -> ChatGoogleGenerativeAI:
    """Initialize and return a ChatGoogleGenerativeAI model instance.

    This uses the AI access layer rather than Vertex project/location mode.
    """
    try:
        if not Config.MODEL_NAME:
            raise ValueError("MODEL_NAME not configured")

        base_url = os.getenv("AI_ACCESS_LAYER_BASE_URL") or os.getenv("GENAI_BASE_URL")
        if not base_url:
            raise ValueError("AI_ACCESS_LAYER_BASE_URL not configured")

        logger.info(
            "Initializing Gemini via AI access layer: model=%s base_url=%s cert_auth=%s kubernetes=%s ca_bundle=%s",
            Config.MODEL_NAME,
            base_url,
            _is_local_cert_auth_enabled(),
            bool(os.getenv("KUBERNETES_SERVICE_HOST")),
            os.getenv("CA_BUNDLE_PATH"),
        )

        _configure_certificate_once()
        logger.info(
            "Gemini certificate configuration complete. REQUESTS_CA_BUNDLE=%s",
            os.getenv("REQUESTS_CA_BUNDLE"),
        )

        model_kwargs: Dict[str, Any] = {
            "model": Config.MODEL_NAME,
            "api_key": GoogleOAuthTokenProvider().token,
            "base_url": base_url,
            "safety_settings": Config.SAFETY_CONFIG.get("safety_settings", []),
        }

        logger.info(
            "Attempting ChatGoogleGenerativeAI construction with model=%s base_url=%s",
            Config.MODEL_NAME,
            base_url,
        )
        model = ChatGoogleGenerativeAI(**model_kwargs)
        logger.info(
            "Gemini model initialized: %s (base_url=%s)", Config.MODEL_NAME, base_url
        )
        return model

    except ValueError as e:
        logger.error("Configuration validation failed: %s", e)
        raise
    except Exception as e:
        logger.exception("Failed to initialize Gemini model using AI access layer")
        raise
