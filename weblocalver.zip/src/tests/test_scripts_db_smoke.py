"""Tests for scripts/db_smoke.py against a real temporary SQLite database."""

from __future__ import annotations

import runpy
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))

import db_smoke
from core.config import Config
from repository.sqlite_repo import SqliteRepository

PG_URL = "postgresql://"


@pytest.fixture
def sqlite_url(monkeypatch, tmp_path):
    db = tmp_path / "smoke.db"
    monkeypatch.setattr(Config, "DB_URL", f"sqlite:///{db.as_posix()}")
    return db


def _adc(monkeypatch, *, fail: bool = False) -> None:
    def default():
        if fail:
            raise RuntimeError("no credentials")
        return SimpleNamespace(), "proj-1"

    monkeypatch.setattr("google.auth.default", default)


class TestCheckAdc:
    def test_skipped_for_sqlite(self, sqlite_url, capsys):
        assert db_smoke.check_adc() is True
        assert "[skip]" in capsys.readouterr().out

    def test_uses_resolved_config_url_not_only_the_env_var(self, monkeypatch, capsys):
        monkeypatch.delenv("EVAL_DB_URL", raising=False)
        monkeypatch.setattr(Config, "DB_URL", PG_URL)
        _adc(monkeypatch)
        assert db_smoke.check_adc() is True
        assert "[ok] ADC resolved: SimpleNamespace (project=proj-1)" in capsys.readouterr().out

    def test_adc_failure(self, monkeypatch, capsys):
        monkeypatch.setattr(Config, "DB_URL", PG_URL)
        _adc(monkeypatch, fail=True)
        assert db_smoke.check_adc() is False
        assert "ADC not available: no credentials" in capsys.readouterr().out


class TestMain:
    def test_round_trips_a_run_through_sqlite(self, sqlite_url, capsys):
        assert db_smoke.main() == db_smoke.EXIT_OK
        assert "SUCCESS" in capsys.readouterr().out
        repo = SqliteRepository(str(sqlite_url))
        runs = repo.list_runs(agent_id=db_smoke.SMOKE_AGENT_ID)
        repo.close()
        assert len(runs) == 1

    def test_missing_adc(self, monkeypatch):
        monkeypatch.setattr(Config, "DB_URL", PG_URL)
        _adc(monkeypatch, fail=True)
        assert db_smoke.main() == db_smoke.EXIT_NO_ADC

    def test_build_failure(self, monkeypatch, capsys):
        monkeypatch.setattr(Config, "DB_URL", "mysql://nope")
        assert db_smoke.main() == db_smoke.EXIT_BUILD_FAILED
        assert "could not build repository: NotImplementedError" in capsys.readouterr().out

    def test_silent_sqlite_fallback_is_a_failure(self, monkeypatch, tmp_path, capsys):
        import repository

        monkeypatch.setattr(Config, "DB_URL", PG_URL)
        _adc(monkeypatch)
        monkeypatch.setattr(repository, "build_repository", lambda: SqliteRepository(str(tmp_path / "fb.db")))
        assert db_smoke.main() == db_smoke.EXIT_BUILD_FAILED
        out = capsys.readouterr().out
        assert "fell back to SQLite" in out and "SUCCESS" not in out

    def test_mismatch_closes_repo_and_skips_success(self, monkeypatch, capsys):
        import repository

        class Repo:
            closed = False

            def save_run(self, run):
                pass

            def get_run(self, run_id):
                return None

            def close(self):
                Repo.closed = True

        monkeypatch.setattr(repository, "build_repository", Repo)
        monkeypatch.setattr(Config, "DB_URL", "sqlite:///unused")
        assert db_smoke.main() == db_smoke.EXIT_MISMATCH
        assert Repo.closed
        assert "SUCCESS" not in capsys.readouterr().out


def test_round_trip_reports_driver_errors(capsys):
    class Broken:
        def save_run(self, run):
            raise OSError("disk full")

    assert db_smoke.round_trip(Broken()) == db_smoke.EXIT_IO_FAILED
    assert "write/read failed: OSError('disk full')" in capsys.readouterr().out


def test_smoke_run_is_easy_to_find():
    run = db_smoke.build_smoke_run()
    assert run.agent_id == run.dataset_id == db_smoke.SMOKE_AGENT_ID
    assert run.run_id.startswith("smoke_")


def test_script_entry_point(monkeypatch):
    monkeypatch.setattr(Config, "DB_URL", "mysql://nope")
    with pytest.raises(SystemExit) as exc:
        runpy.run_path(db_smoke.__file__, run_name="__main__")
    assert exc.value.code == db_smoke.EXIT_BUILD_FAILED
