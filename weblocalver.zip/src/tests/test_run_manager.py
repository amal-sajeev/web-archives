from __future__ import annotations

import asyncio
import time

import pytest

from core.run_manager import LiveRun, run_manager


def test_live_run_request_cancel_is_idempotent():
    live = LiveRun(stream_id="s1", agent_id="a1")

    first = live.request_cancel()
    second = live.request_cancel()

    assert first is True
    assert second is False
    assert live.cancel_requested is True
    assert live.events[-1]["type"] == "run_cancel_requested"


def test_run_manager_list_runs_includes_lifecycle_fields():
    live = run_manager.create("agent-x")
    live.publish({"type": "case_started", "case_id": "c1"})

    streams = run_manager.list_runs()
    stream = next(s for s in streams if s["stream_id"] == live.stream_id)

    assert stream["agent_id"] == "agent-x"
    assert stream["done"] is False
    assert stream["event_count"] >= 1
    assert stream["cancel_requested"] is False


def test_live_run_subscribe_replays_history_and_done_sentinel():
    live = LiveRun(stream_id="s2", agent_id="a2")
    live.publish({"type": "case_started"})
    live.finish()

    queue = live.subscribe()

    first = queue.get_nowait()
    second = queue.get_nowait()

    assert first["type"] == "case_started"
    assert first["seq"] == 1
    assert second is not None


def test_live_run_publish_sets_run_id_from_completion_event():
    live = LiveRun(stream_id="s3", agent_id="a3")

    live.publish({"type": "run_done", "run_id": "run-123"})

    assert live.run_id == "run-123"


def test_run_manager_get_prunes_stale_runs(monkeypatch):
    run_manager._runs.clear()
    live = run_manager.create("agent-y")
    live.done = True
    live.finished_at = 1.0

    monkeypatch.setattr(time, "monotonic", lambda: 5000.0)

    assert run_manager.get(live.stream_id) is None


def test_live_run_unsubscribe_removes_queue():
    live = LiveRun(stream_id="s4", agent_id="a4")
    queue = live.subscribe()

    live.unsubscribe(queue)

    assert queue not in live._subscribers


def _run_dict(run_id="run-9"):
    return {
        "run_id": run_id, "agent_id": "a", "dataset_id": "d", "dataset_version": "1",
        "weighted_score": 1.0, "weighted_delta": 0.0, "status": "PASS",
        "creation_ts": "2026-01-01T00:00:00+00:00",
    }


def test_playground_done_event_sets_finished_run():
    live = LiveRun(stream_id="s5", agent_id="playground")

    live.publish({"type": "playground_done", "run": _run_dict()})

    assert live.finished_run is not None
    assert live.finished_run.run_id == "run-9"
    assert live.run_id == "run-9"


def test_set_finished_run_accepts_record_and_ignores_none():
    from core.models import RunRecord

    live = LiveRun(stream_id="s6", agent_id="a")
    live.set_finished_run(None)
    assert live.finished_run is None
    live.set_finished_run(RunRecord(**_run_dict("run-10")))
    assert live.finished_run.run_id == "run-10"


def test_invalid_completion_run_is_ignored_not_raised():
    live = LiveRun(stream_id="s7", agent_id="a")
    live.publish({"type": "run_done", "run": {"bogus": True}, "run_id": "r-1"})
    assert live.finished_run is None
    assert live.run_id == "r-1"


def test_subscriber_queue_is_bounded_and_drops_oldest(monkeypatch):
    from core import run_manager as rm

    monkeypatch.setattr(rm, "_SUBSCRIBER_QUEUE_MAX", 2)
    live = LiveRun(stream_id="s8", agent_id="a")
    queue = live.subscribe()
    for i in range(5):
        live.publish({"type": "tick", "i": i})
    items = [queue.get_nowait()["i"] for _ in range(queue.qsize())]
    assert items == [3, 4]


def test_cancel_requested_is_read_only():
    live = LiveRun(stream_id="s9", agent_id="a")
    with pytest.raises(AttributeError):
        live.cancel_requested = True
    assert live.cancel_requested is False
    live.finish()
    assert live.request_cancel() is False


async def test_shutdown_cancels_only_in_flight_runs():
    manager = type(run_manager)()
    running = manager.create("a")
    running.task = asyncio.create_task(asyncio.sleep(3600))
    finished = manager.create("b")
    finished.task = asyncio.create_task(asyncio.sleep(0))
    await finished.task
    idle = manager.create("c")  # no task attached

    cancelled = await manager.shutdown(timeout=1)

    assert cancelled == 1
    assert running.task.cancelled()
    assert running.cancel_requested is True
    assert running.events[-1]["type"] == "run_cancel_requested"
    assert finished.cancel_requested is False
    assert idle.cancel_requested is False


async def test_shutdown_is_bounded_when_a_run_ignores_cancel():
    manager = type(run_manager)()
    release = asyncio.Event()

    async def _stubborn():
        while not release.is_set():
            try:
                await asyncio.sleep(3600)
            except asyncio.CancelledError:
                continue  # swallows cancellation on purpose

    live = manager.create("a")
    live.task = asyncio.create_task(_stubborn())
    await asyncio.sleep(0)

    assert await manager.shutdown(timeout=0.01) == 1
    assert not live.task.done()
    release.set()
    live.task.cancel()
    await asyncio.wait([live.task], timeout=1)


async def test_shutdown_with_nothing_running():
    assert await type(run_manager)().shutdown() == 0


def test_prune_drops_runs_finished_long_ago(monkeypatch):
    from core import run_manager as rm

    manager = type(run_manager)()
    old = manager.create("a")
    old.finish()
    old.finished_at = time.monotonic() - rm._RETAIN_SECONDS - 1

    assert manager.get(old.stream_id) is None


def test_finish_signals_live_subscribers():
    from core.run_manager import DONE

    live = LiveRun(stream_id="s10", agent_id="a")
    queue = live.subscribe()
    live.finish()
    assert queue.get_nowait() is DONE


def test_clear_forgets_every_stream():
    manager = type(run_manager)()
    live = manager.create("a")
    manager.clear()
    assert manager.get(live.stream_id) is None
    assert manager.list_runs() == []
