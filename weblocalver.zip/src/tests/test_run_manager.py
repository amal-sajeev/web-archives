from __future__ import annotations

from run_manager import LiveRun, run_manager


def test_live_run_request_cancel_is_idempotent():
    live = LiveRun(stream_id="s1", agent_id="a1")

    first = live.request_cancel()
    second = live.request_cancel()

    assert first is True
    assert second is False
    assert live.cancel_requested is True
    assert live.events[-1]["type"] == "run_cancel_requested"


def test_run_manager_list_runs_includes_lifecycle_fields():
    live = run_manager.create("agent-x")
    live.publish({"type": "case_started", "case_id": "c1"})

    streams = run_manager.list_runs()
    stream = next(s for s in streams if s["stream_id"] == live.stream_id)

    assert stream["agent_id"] == "agent-x"
    assert stream["done"] is False
    assert stream["event_count"] >= 1
    assert stream["cancel_requested"] is False
