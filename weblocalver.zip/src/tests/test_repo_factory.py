"""``repository.build_repository`` backend selection and the CloudSQL fallback."""

from __future__ import annotations

import pytest

import repository
from core.config import Config
from repository import postgres_repo
from repository.sqlite_repo import SqliteRepository


class _FakeCloudRepo:
    fail_init = False
    closed = False

    def init_schema(self):
        if _FakeCloudRepo.fail_init:
            raise RuntimeError("schema missing")

    def close(self):
        _FakeCloudRepo.closed = True


@pytest.fixture
def cloud(monkeypatch):
    _FakeCloudRepo.fail_init = False
    _FakeCloudRepo.closed = False
    monkeypatch.setattr(postgres_repo, "CloudSqlRepository", _FakeCloudRepo)
    monkeypatch.setattr(Config, "DB_URL", "postgresql://")
    return _FakeCloudRepo


def test_sqlite_url_builds_initialised_sqlite(monkeypatch, tmp_path):
    monkeypatch.setattr(Config, "DB_URL", f"sqlite:///{(tmp_path / 'x.db').as_posix()}")
    repo = repository.build_repository()
    assert isinstance(repo, SqliteRepository)
    assert repo.ping() is True


def test_postgres_url_builds_cloud_repo(cloud):
    assert isinstance(repository.build_repository(), _FakeCloudRepo)


def test_postgres_failure_without_fallback_raises_and_closes(cloud, monkeypatch):
    cloud.fail_init = True
    monkeypatch.setattr(Config, "ALLOW_SQLITE_FALLBACK", False)

    with pytest.raises(RuntimeError, match="SQLite fallback is disabled"):
        repository.build_repository()
    assert cloud.closed is True


def test_postgres_failure_with_fallback_uses_sqlite(cloud, monkeypatch, tmp_path):
    cloud.fail_init = True
    monkeypatch.setattr(Config, "ALLOW_SQLITE_FALLBACK", True)
    monkeypatch.setattr(Config, "STATIC_DIR", tmp_path / "src" / "main" / "static")

    repo = repository.build_repository()

    assert isinstance(repo, SqliteRepository)
    assert (tmp_path / "eval_service.db").exists()


def test_postgres_constructor_failure_does_not_close(monkeypatch):
    def _boom():
        raise RuntimeError("no DB_NAME")

    monkeypatch.setattr(postgres_repo, "CloudSqlRepository", _boom)
    monkeypatch.setattr(Config, "DB_URL", "postgres://")
    monkeypatch.setattr(Config, "ALLOW_SQLITE_FALLBACK", False)
    with pytest.raises(RuntimeError, match="no DB_NAME"):
        repository.build_repository()


def test_unsupported_url(monkeypatch):
    monkeypatch.setattr(Config, "DB_URL", "mysql://x")
    with pytest.raises(NotImplementedError, match="Unsupported EVAL_DB_URL"):
        repository.build_repository()
