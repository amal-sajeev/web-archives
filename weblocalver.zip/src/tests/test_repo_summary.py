"""``run_summary`` semantics: the SQLite single-query version and the portable
``list_runs``-based default must agree on the same data."""

from __future__ import annotations

import pytest

from core.playground import PreviewRepository
from repository import _summary_fallback
from repository._summary_sql import build_run_summary_query, summary_from_row
from repository.sqlite_repo import _DIALECT


def _day(day: int) -> str:
    return f"2026-02-{day:02d}T00:00:00+00:00"


@pytest.fixture(params=["sqlite", "fallback"])
def seeded(request, sqlite_repo, make_run):
    """Two agents and two datasets; agent-1/ds-1 has PASS, FAIL, cancelled, ERROR runs."""
    repo = sqlite_repo if request.param == "sqlite" else PreviewRepository()
    runs = [
        make_run("a1", status="PASS", score=1.0, creation_ts=_day(1), cases=[("c1", True, 1.0)]),
        make_run("a2", status="FAIL", score=0.4, creation_ts=_day(2), cases=[("c1", False, 0.4)]),
        make_run("a3", status="ERROR", score=0.0, creation_ts=_day(3), error_detail="cancelled"),
        make_run("a4", status="ERROR", score=0.0, creation_ts=_day(4), error_detail="ValueError: bad"),
        make_run("o1", status="PASS", score=0.8, creation_ts=_day(5), dataset_id="ds-2"),
        make_run("b1", agent_id="agent-2", status="PASS", score=0.6, creation_ts=_day(6)),
    ]
    for run in runs:
        repo.save_run(run)
    return repo


def test_unfiltered_counts_and_mean(seeded):
    summary = seeded.run_summary()

    assert {k: summary[k] for k in ("total", "passed", "failed", "errored", "cancelled")} == {
        "total": 6, "passed": 3, "failed": 1, "errored": 1, "cancelled": 1,
    }
    assert summary["average_score"] == pytest.approx((1.0 + 0.4 + 0.8 + 0.6) / 4)
    assert summary["latest"]["run_id"] == "b1"
    assert summary["previous"] is None


def test_previous_is_same_agent_and_honours_dataset(seeded):
    by_agent = seeded.run_summary(agent_id="agent-1")
    by_dataset = seeded.run_summary(agent_id="agent-1", dataset_id="ds-1")

    assert (by_agent["latest"]["run_id"], by_agent["previous"]["run_id"]) == ("o1", "a4")
    assert (by_dataset["latest"]["run_id"], by_dataset["previous"]["run_id"]) == ("a4", "a3")
    assert by_dataset["latest"]["error_detail"] == "ValueError: bad"


def test_since_limits_window_but_not_previous(seeded):
    summary = seeded.run_summary(agent_id="agent-1", dataset_id="ds-1", since="2026-02-04")

    assert (summary["total"], summary["errored"]) == (1, 1)
    assert summary["average_score"] is None  # only an ERROR run in the window
    assert summary["previous"]["run_id"] == "a3"


def test_list_item_shape(seeded):
    latest = seeded.run_summary(agent_id="agent-1", dataset_id="ds-1", since="2026-02-01")["previous"]
    assert set(latest) == {
        "run_id", "agent_id", "dataset_id", "dataset_version", "weighted_score", "weighted_delta",
        "status", "creation_ts", "created_by", "case_count", "passed_case_count", "error_detail",
    }


def test_empty_repository(sqlite_repo):
    assert sqlite_repo.run_summary() == {
        "total": 0, "passed": 0, "failed": 0, "errored": 0, "cancelled": 0,
        "average_score": None, "latest": None, "previous": None,
    }


def test_fallback_pages_through_every_run(monkeypatch, make_run):
    monkeypatch.setattr(_summary_fallback, "PAGE_SIZE", 2)
    repo = PreviewRepository()
    for i in range(5):
        repo.save_run(make_run(f"r{i}", creation_ts=_day(i + 1)))

    assert repo.run_summary()["total"] == 5


def test_query_without_filters_has_no_where_on_window():
    sql, params = build_run_summary_query(_DIALECT)
    assert "FROM eval_execution), totals" in sql
    assert "agent_id" not in params and "since" not in params


def test_summary_from_row_defaults_and_ts_conversion():
    row = {"total": None, "average_score": None, "latest_run_id": "r", "latest_creation_ts": 5}
    summary = summary_from_row(row, convert_ts=lambda v: f"ts{v}")
    assert summary["total"] == 0
    assert summary["latest"]["creation_ts"] == "ts5"
    assert summary["previous"] is None


def test_interface_defaults_for_minimal_backends():
    repo = PreviewRepository()
    assert repo.ping() is True
    assert repo.delete_old_runs(30) == 0
    assert repo.close() is None


def test_fallback_matches_single_query_on_same_data(sqlite_repo, make_run):
    sqlite_repo.save_run(make_run("a", status="PASS", score=0.9, creation_ts=_day(1)))
    sqlite_repo.save_run(make_run("b", status="ERROR", score=0.0, creation_ts=_day(2), error_detail="cancelled"))
    sqlite_repo.save_run(make_run("c", status="FAIL", score=0.2, creation_ts=_day(3)))

    for kwargs in ({}, {"agent_id": "agent-1", "since": "2026-02-02"}, {"dataset_id": "none"}):
        assert _summary_fallback.summarize_repository(sqlite_repo, **kwargs) == sqlite_repo.run_summary(**kwargs)


class _RowsWithoutErrorDetail(PreviewRepository):
    """A minimal backend whose ``list_runs`` rows predate the ``error_detail`` column."""

    def list_runs(self, *args, **kwargs):
        return [{k: v for k, v in row.items() if k != "error_detail"} for row in super().list_runs(*args, **kwargs)]


def test_fallback_loads_error_detail_for_error_rows_only(make_run):
    repo = _RowsWithoutErrorDetail()
    repo.save_run(make_run("ok", status="PASS", creation_ts=_day(1)))
    repo.save_run(make_run("stopped", status="ERROR", creation_ts=_day(2), error_detail="cancelled"))
    repo.save_run(make_run("broken", status="ERROR", creation_ts=_day(3), error_detail="agent down"))

    summary = _summary_fallback.summarize_repository(repo)

    assert (summary["passed"], summary["cancelled"], summary["errored"]) == (1, 1, 1)
    assert summary["latest"]["error_detail"] == "agent down"
