"""Builders shared by the scorer test modules (not a test module itself)."""

from __future__ import annotations

from typing import Any

from core.models import GoldenCase, MetricSpec, Observation
from scorers import get_scorer


def obs(output: Any, metadata: dict | None = None, **kw: Any) -> Observation:
    params: dict[str, Any] = {
        "target_id": "test", "output": output, "metadata": metadata or {},
        "tool_calls": [], "latency_ms": 100,
    }
    params.update(kw)
    return Observation(**params)


def case(**kw: Any) -> GoldenCase:
    params: dict[str, Any] = {"id": "test", "input": {}, "expected": {}}
    params.update(kw)
    return GoldenCase(**params)


def spec(scorer_name: str, config: dict | None = None, **kw: Any) -> MetricSpec:
    params: dict[str, Any] = {
        "name": "m", "type": "deterministic", "scorer": scorer_name, "config": config or {},
    }
    params.update(kw)
    return MetricSpec(**params)


def run(scorer_name: str, observation: Observation, golden_case: GoldenCase | None = None,
        config: dict | None = None, **kw: Any):
    """Call a registered scorer with a spec built from `config`."""
    fn = get_scorer(scorer_name)
    return fn(observation=observation, case=golden_case or case(),
              spec=spec(scorer_name, config), **kw)


class ScriptedJudge:
    """Judge stand-in returning pre-built verdict objects in order (cycling)."""

    def __init__(self, verdicts: list[Any]):
        self._verdicts = list(verdicts)
        self._i = 0
        self.prompts: list[str] = []

    def invoke(self, prompt: str) -> Any:
        self.prompts.append(prompt)
        verdict = self._verdicts[self._i % len(self._verdicts)]
        self._i += 1
        return verdict


def fast_retries(monkeypatch, attempts: int = 1) -> None:
    """Make judge retries instant (and optionally single-shot) for a test."""
    from core.config import Config
    from scorers import judge_invoke

    monkeypatch.setattr(judge_invoke, "_BACKOFF_BASE_S", 0.0)
    monkeypatch.setattr(Config, "JUDGE_TRANSIENT_RETRIES", attempts)
