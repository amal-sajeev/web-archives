"""Deterministic, trajectory and reference-similarity scorers."""

from __future__ import annotations

import pytest

from scorer_helpers import case, obs, run, spec
from scorers import get_scorer
from scorers.base import MetricSkipped

_CALL = {"name": "lookup", "args": {"id": "AU-10001", "org": "Acme"}}


def _call(name, observation, golden_case, **kw):
    return get_scorer(name)(observation=observation, case=golden_case, **kw)


class TestToolSelection:
    def test_skips_without_expected_tool(self):
        with pytest.raises(MetricSkipped, match="expected_tool"):
            _call("tool_selection", obs("x", tool_calls=[_CALL]), case())

    def test_string_expected_values_is_one_value(self):
        golden = case(expected={"expected_tool": "lookup", "expected_values": "AU-10001"})
        score, rationale, _ = _call("tool_selection", obs("x", tool_calls=[_CALL]), golden)
        assert score == 1.0
        assert rationale == "2/2 tool-selection checks passed"

    def test_wrong_tool(self):
        golden = case(expected={"expected_tool": "other"})
        assert _call("tool_selection", obs("x", tool_calls=[_CALL]), golden)[0] == 0.0


class TestMetricScorers:
    def test_metric_threshold_clamps_and_reports_raw(self):
        golden = case(expected={"metric_name": "hit_rate"})
        score, _, _, extras = _call("metric_threshold", obs("x"), golden, metrics={"hit_rate": 7})
        assert score == 1.0
        assert extras["raw_value"] == 7.0
        assert _call("metric_threshold", obs("x"), golden, metrics={"hit_rate": -2})[0] == 0.0

    def test_metric_threshold_nan_is_zero(self):
        golden = case(expected={"metric_name": "hit_rate"})
        assert _call("metric_threshold", obs("x"), golden, metrics={"hit_rate": float("nan")})[0] == 0.0

    def test_metric_threshold_missing_skips(self):
        with pytest.raises(MetricSkipped, match="missing"):
            _call("metric_threshold", obs("x"), case(expected={"metric_name": "hit_rate"}), metrics={})

    def test_metric_threshold_non_numeric_skips(self):
        with pytest.raises(MetricSkipped, match="not numeric"):
            _call("metric_threshold", obs("x"), case(expected={"metric_name": "m"}), metrics={"m": "abc"})

    def test_ai_confidence(self):
        assert _call("ai_confidence", obs("x"), case(), metrics={"ai_confidence_score": "0.4"})[0] == 0.4
        assert _call("ai_confidence", obs("x"), case(), metrics={"ai_confidence_score": "nan"})[0] == 0.0
        with pytest.raises(MetricSkipped):
            _call("ai_confidence", obs("x"), case(), metrics={})
        with pytest.raises(MetricSkipped):
            _call("ai_confidence", obs("x"), case(), metrics={"ai_confidence_score": "high"})


class TestAssertions:
    def test_terms_are_normalised_like_text(self):
        golden = case(expected={"spot_checks": [{"id": "a", "all_of": ["**Acme**", "Plan_Item"]}]})
        score, _, _ = _call("assertions", obs("The **Acme** planitem"), golden)
        assert score == 1.0

    def test_absent_expectation(self):
        golden = case(expected={"spot_checks": [{"id": "a", "any_of": ["secret"], "expect": "absent"}]})
        assert _call("assertions", obs("public text"), golden)[0] == 1.0

    def test_string_term_is_not_split_into_characters(self):
        golden = case(expected={"spot_checks": [{"id": "a", "any_of": "zzz"}]})
        assert _call("assertions", obs("z"), golden)[0] == 0.0

    def test_no_spot_checks_passes_trivially(self):
        assert _call("assertions", obs("x"), case())[:2] == (1.0, "no assertions defined")

    def test_report_json_keys_do_not_trip_absent_checks(self):
        report = {"report_title": "Plan", "paragraphs": [{"content": "Acme renewal"}]}
        golden = case(expected={"spot_checks": [
            {"id": "no-content-word", "any_of": ["content"], "expect": "absent"},
            {"id": "acme", "all_of": ["acme", "renewal"]},
        ]})
        score, _, evidence = _call("assertions", obs(report), golden)
        assert score == 1.0
        assert evidence == ["✓ no-content-word", "✓ acme"]

    def test_prefers_adapter_extracted_text(self):
        golden = case(expected={"spot_checks": [{"any_of": ["invoice total"]}]})
        observation = obs("<binary>", {"extracted_text": "Invoice Total: 10"})
        score, _, evidence = _call("assertions", observation, golden)
        assert score == 1.0
        assert evidence == ["✓ ?"]


class TestIdentifierPassthrough:
    def test_no_identifiers_passes(self):
        assert _call("identifier_passthrough", obs("x"), case())[:2] == (1.0, "no identifiers to check")

    def test_all_identifiers_present_case_insensitively(self):
        golden = case(expected={"expected_values": ["au-10001", "ACME"]})
        score, rationale, evidence = _call("identifier_passthrough", obs("x", tool_calls=[_CALL]), golden)
        assert (score, rationale) == (1.0, "all identifiers passed through")
        assert len(evidence) == 2

    def test_missing_identifier_fails(self):
        golden = case(expected={"expected_values": ["AU-10001", "AU-99999"]})
        score, rationale, evidence = _call("identifier_passthrough", obs("x", tool_calls=[_CALL]), golden)
        assert score == 0.0
        assert rationale == "missing: ['AU-99999']"
        assert evidence[1].startswith("✗")


class TestTrajectory:
    def test_tool_arg_accuracy_string_value(self):
        golden = case(expected={"expected_tool_args": {"lookup": "AU-10001"}})
        score, rationale, _ = _call("tool_arg_accuracy", obs("x", tool_calls=[_CALL]), golden)
        assert score == 1.0
        assert rationale == "1/1 tool-arg checks passed"

    def test_tool_order_single_expected_tool(self):
        golden = case(expected={"expected_tool": "lookup"})
        assert _call("tool_order_correct", obs("x", tool_calls=[_CALL]), golden)[0] == 1.0

    @pytest.mark.parametrize(("optimal", "calls", "expected"), [
        (0, 0, 1.0), (0, 2, 0.0), (1, 2, 0.5), (2, 1, 1.0), (None, 0, 1.0),
    ])
    def test_step_efficiency(self, optimal, calls, expected):
        golden = case(expected={} if optimal is None else {"optimal_steps": optimal})
        observation = obs("x", tool_calls=[_CALL] * calls)
        assert _call("step_efficiency", observation, golden)[0] == expected

    def test_tool_error_free_measured_not_raw(self):
        score, _, _, extras = _call("tool_error_free", obs("x"), case(), metrics={"tool_error_count": 0})
        assert score == 1.0
        assert extras == {"measured": 0.0}

    def test_tool_error_free_raw_when_opted_in(self):
        opted = spec("tool_error_free", direction="lower_is_better", norm_max=5)
        _, _, _, extras = _call("tool_error_free", obs("x"), case(), metrics={"tool_error_count": 2}, spec=opted)
        assert extras == {"raw_value": 2.0}

    def test_no_redundant_calls(self):
        assert _call("no_redundant_calls", obs("x", tool_calls=[_CALL, _CALL]), case())[0] == 0.5
        assert _call("no_redundant_calls", obs("x"), case())[:2] == (1.0, "no tool calls")

    def test_tool_order_partial_and_undefined(self):
        calls = [{"name": "b"}, {"Tool_Id": "a"}, {"name": "c"}, {"name": "b"}]
        golden = case(expected={"expected_tool_sequence": ["a", "b"]})
        assert _call("tool_order_correct", obs("x", tool_calls=calls), golden)[0] == 1.0
        golden = case(expected={"expected_tool_sequence": ["c", "a"]})
        assert _call("tool_order_correct", obs("x", tool_calls=calls), golden)[0] == 0.5
        assert _call("tool_order_correct", obs("x"), case())[0] == 1.0

    def test_tool_arg_accuracy_fallback_and_legacy_param_key(self):
        legacy = {"Tool_Id": "lookup", "Tool_Param": "AU-10001;Acme"}
        golden = case(expected={"expected_tool": "lookup", "expected_values": ["acme", "zzz"]})
        score, _, evidence = _call("tool_arg_accuracy", obs("x", tool_calls=[legacy]), golden)
        assert score == 0.5
        assert evidence == ["✓ lookup:acme", "✗ lookup:zzz"]

    @pytest.mark.parametrize("expected", [{}, {"expected_tool": "lookup"}, {"expected_tool_args": {"lookup": []}}])
    def test_tool_arg_accuracy_nothing_to_check(self, expected):
        result = _call("tool_arg_accuracy", obs("x", tool_calls=[_CALL]), case(expected=expected))
        assert result == (1.0, "no expected tool args defined", [])

    def test_tool_error_free_falls_back_to_observation_error(self):
        failed = obs("x", error="HTTP 500")
        assert _call("tool_error_free", failed, case())[0] == 0.0
        assert _call("tool_error_free", obs("x"), case(), metrics={})[0] == 1.0

    @pytest.mark.parametrize(("value", "reason"), [("lots", "not numeric"), (float("nan"), "is NaN")])
    def test_tool_error_free_unusable_count_skips(self, value, reason):
        with pytest.raises(MetricSkipped, match=reason):
            _call("tool_error_free", obs("x"), case(), metrics={"tool_error_count": value})

    def test_step_efficiency_defaults_to_sequence_length(self):
        golden = case(expected={"expected_tool_sequence": ["a", "b"]})
        assert _call("step_efficiency", obs("x", tool_calls=[_CALL] * 4), golden)[0] == 0.5

    def test_step_efficiency_bad_optimal_steps_skips(self):
        with pytest.raises(MetricSkipped, match="optimal_steps must be a whole number, got 'two'"):
            _call("step_efficiency", obs("x"), case(expected={"optimal_steps": "two"}))


class TestSimilarity:
    @pytest.mark.parametrize("name", ["token_overlap_f1", "edit_similarity", "embedding_similarity"])
    def test_no_golden_skips(self, name):
        with pytest.raises(MetricSkipped, match="no golden_output"):
            _call(name, obs("x"), case(golden_output=None))

    def test_token_f1_counts_duplicates(self):
        score, _, evidence = _call("token_overlap_f1", obs("a a b"), case(golden_output="a b b"))
        assert score == pytest.approx(2 / 3)
        assert evidence == ["overlap=2"]

    def test_token_f1_unicode_tokens(self):
        score, _, _ = _call("token_overlap_f1", obs("Größe café"), case(golden_output="größe CAFÉ"))
        assert score == 1.0

    def test_edit_similarity(self):
        assert _call("edit_similarity", obs("abcd"), case(golden_output="abcd"))[0] == 1.0
        score = _call("edit_similarity", obs("abcd"), case(golden_output="abxd"))[0]
        assert score == pytest.approx(0.75)

    def test_edit_similarity_long_text_is_fast(self):
        text = "lorem ipsum " * 5000
        assert _call("edit_similarity", obs(text), case(golden_output=text + "x"))[0] > 0.99

    def test_json_schema_valid_uses_configurable_implementation(self):
        from scorers.configurable_json import json_schema_valid_config

        assert get_scorer("json_schema_valid") is json_schema_valid_config
        assert run("json_schema_valid", obs({"n": 1}), config={"schema": {"type": "object"}})[0] == 1.0
