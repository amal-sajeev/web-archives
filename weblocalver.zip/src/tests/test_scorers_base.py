"""Scorer registry primitives: judge flag, duplicate warning, snapshot/restore, shims."""

from __future__ import annotations

import logging

import pytest

from scorers import base
from scorers.base import all_scorers, is_judge_scorer, restore_scorers, scorer, snapshot_scorers


@pytest.fixture
def scoped_registry():
    snap = snapshot_scorers()
    yield
    restore_scorers(snap)


def test_judge_flag_recorded(scoped_registry):
    @scorer("tmp_judge", judge=True)
    def _j(**_):
        return 1.0, "", []

    @scorer("tmp_plain")
    def _p(**_):
        return 1.0, "", []

    assert is_judge_scorer("tmp_judge")
    assert not is_judge_scorer("tmp_plain")


def test_judge_flag_survives_snapshot_restore(scoped_registry):
    snap = snapshot_scorers()

    @scorer("faithfulness")
    def _override(**_):
        return 1.0, "", []

    assert not is_judge_scorer("faithfulness")
    restore_scorers(snap)
    assert is_judge_scorer("faithfulness")


def test_duplicate_registration_warns(scoped_registry, caplog):
    @scorer("tmp_dup")
    def first(**_):
        return 1.0, "", []

    def second(**_):
        return 0.0, "", []

    with caplog.at_level(logging.WARNING, logger=base.__name__):
        scorer("tmp_dup")(second)
    assert any("registered twice" in r.message for r in caplog.records)
    assert all_scorers()["tmp_dup"] is second


def test_same_definition_reregistered_does_not_warn(scoped_registry, caplog):
    def make():
        def fn(**_):
            return 1.0, "", []
        return fn

    scorer("tmp_same")(make())
    with caplog.at_level(logging.WARNING, logger=base.__name__):
        scorer("tmp_same")(make())
    assert not caplog.records


def test_legacy_import_paths_still_work():
    from scorers import configurable, configurable_advanced, llm_judge

    assert configurable.rubric_multi is configurable_advanced.rubric_multi
    assert callable(configurable.build_judge_for)
    assert callable(llm_judge.reset_cache)
    assert llm_judge._samples(3) == 3
    assert "Judge only on substance" in llm_judge._BIAS_GUARD


class _Bound:
    """Bound methods refuse attribute writes, like some C-level callables."""

    def score(self, **_):
        return 1.0, "", []


def test_judge_flag_for_callables_that_refuse_attributes(scoped_registry):
    scorer("tmp_bound_judge", judge=True)(_Bound().score)
    scorer("tmp_bound_plain")(_Bound().score)
    assert is_judge_scorer("tmp_bound_judge")
    assert not is_judge_scorer("tmp_bound_plain")


def test_plain_function_replacing_bound_judge_is_not_a_judge(scoped_registry):
    scorer("tmp_swap", judge=True)(_Bound().score)

    def plain(**_):
        return 1.0, "", []

    scorer("tmp_swap")(plain)
    assert not is_judge_scorer("tmp_swap")


def test_unknown_scorer_is_not_a_judge_and_lookup_explains():
    assert not is_judge_scorer("no_such_scorer")
    with pytest.raises(KeyError, match="Add it as a built-in or in the agent's custom_tests.py"):
        base.get_scorer("no_such_scorer")
