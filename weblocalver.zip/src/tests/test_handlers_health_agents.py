"""Handler tests: health / liveness / readiness and agent discovery."""

from __future__ import annotations

import importlib
import json
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException

from handlers.agents import agent_target, list_agents
from handlers.health import health, livez, readyz


def test_health_returns_ok_status(monkeypatch):
    registry = MagicMock()
    registry.list_agents.return_value = [{"agent_id": "a1"}]
    health_module = importlib.import_module("handlers.health")
    monkeypatch.setattr(health_module, "require_vertex_credentials", lambda: "Credentials")
    monkeypatch.setattr(health_module.Config, "PROJECT_NAME", "demo-project")

    result = health(registry, MagicMock())

    assert result["status"] == "ok"
    assert result["agents"] == 1
    assert result["credential_class"] == "Credentials"


def test_health_degraded_without_project(monkeypatch):
    registry = MagicMock()
    registry.list_agents.return_value = []
    monkeypatch.setattr(importlib.import_module("handlers.health").Config, "PROJECT_NAME", "")

    assert health(registry, MagicMock())["status"] == "degraded"


def test_health_degraded_when_credentials_fail(monkeypatch):
    health_module = importlib.import_module("handlers.health")

    def _boom():
        raise RuntimeError("no adc")

    monkeypatch.setattr(health_module, "require_vertex_credentials", _boom)
    monkeypatch.setattr(health_module.Config, "PROJECT_NAME", "demo-project")
    registry = MagicMock()
    registry.list_agents.return_value = []

    result = health(registry, MagicMock())

    assert result["status"] == "degraded"
    assert "RuntimeError" in result["vertex"]


def test_livez_is_static_ok():
    assert livez() == {"status": "ok"}


def test_readyz_ok_when_repo_pings(sqlite_repo):
    response = readyz(sqlite_repo)
    assert response.status_code == 200
    assert json.loads(response.body)["status"] == "ok"


def test_readyz_503_when_repo_down():
    repo = MagicMock()
    repo.ping.return_value = False

    response = readyz(repo)

    assert response.status_code == 503
    assert json.loads(response.body)["status"] == "degraded"


def test_list_agents_returns_agent_list():
    registry = MagicMock()
    rows = [{"agent_id": "agent1", "enabled": True}, {"agent_id": "agent2", "enabled": False}]
    registry.list_agents.return_value = rows

    assert list_agents(registry) == {"agents": rows}
    registry.list_agents.assert_called_with(include_disabled=False)
    list_agents(registry, include_disabled=True)
    registry.list_agents.assert_called_with(include_disabled=True)


def test_agent_target_returns_target_config():
    registry = MagicMock()
    registry.get.return_value = SimpleNamespace(
        config=SimpleNamespace(agent_id="test_agent", base_url="https://example.test"),
        dataset=SimpleNamespace(
            dataset_id="dataset-1",
            version="v1",
            target=SimpleNamespace(
                adapter="http",
                endpoint="/eval",
                method="POST",
                trust_env=False,
                timeout=30,
                headers={"Content-Type": "application/json"},
                auth={"type": "bearer"},
                response=SimpleNamespace(output_path="data.output", error_path="data.error"),
            ),
        ),
    )

    result = agent_target("test_agent", registry)

    assert result["agent_id"] == "test_agent"
    assert result["request_url"] == "https://example.test/eval"
    assert result["headers_configured"] == ["Content-Type"]
    assert result["walkthrough_upload_url"] is None


def test_agent_target_raises_404_for_unknown_agent():
    registry = MagicMock()
    registry.get.side_effect = KeyError("Unknown agent 'unknown'")

    with pytest.raises(HTTPException) as exc_info:
        agent_target("unknown", registry)

    assert exc_info.value.status_code == 404
    assert exc_info.value.detail == "Unknown agent 'unknown'"
