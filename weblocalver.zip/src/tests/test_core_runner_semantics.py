"""Runner semantics: normalisation, baselines, gate vetoes, cancellation, failures."""

from __future__ import annotations

import asyncio
import threading
import time

import pytest

from core.config import Config
from core.labels import label_store
from core.models import GoldenCase, HumanLabel, MetricSpec
from core.runner import Runner
from core_helpers import InMemoryRepo, StubTarget, make_dataset, make_registry, patch_runner_io
from scorers.base import MetricSkipped, restore_scorers, scorer, snapshot_scorers


@pytest.fixture(autouse=True)
def _isolated_scorers():
    snap = snapshot_scorers()
    yield
    restore_scorers(snap)


def _spec(name, scorer_name=None, **kw):
    return MetricSpec(name=name, type="deterministic", scorer=scorer_name or name, **kw)


def _cases(n, metrics):
    return [GoldenCase(id=f"c{i}", input={}, baseline_metrics={m: 1.0 for m in metrics}) for i in range(n)]


async def test_raw_value_is_normalised_instead_of_score(monkeypatch):
    @scorer("t_latency")
    def _latency(**_):
        return 0.123, "latency", [], {"raw_value": 500.0}

    spec = _spec("lat", "t_latency", direction="lower_is_better", norm_min=0, norm_max=1000, threshold=0.4)
    patch_runner_io(monkeypatch)
    run = await Runner(make_registry(make_dataset([spec])), InMemoryRepo()).evaluate("t")
    score = run.case_results[0].scores[0]
    assert score.score == pytest.approx(0.5)
    assert score.raw_value == pytest.approx(500.0)


async def test_raw_baseline_is_normalised_but_quality_baseline_is_kept(monkeypatch):
    @scorer("t_latency")
    def _latency(**_):
        return 0.0, "latency", [], {"raw_value": 500.0}

    spec = _spec("lat", "t_latency", direction="lower_is_better", norm_min=0, norm_max=1000)
    ds = make_dataset([spec], [GoldenCase(id="raw", input={}, baseline_metrics={"lat": 250.0}),
                               GoldenCase(id="quality", input={}, baseline_metrics={"lat": 0.7})])
    patch_runner_io(monkeypatch)
    run = await Runner(make_registry(ds), InMemoryRepo()).evaluate("t")
    by_case = {c.case_id: c.scores[0] for c in run.case_results}
    assert by_case["raw"].baseline == pytest.approx(0.75)
    assert by_case["raw"].delta == pytest.approx(-0.25)
    assert by_case["quality"].baseline == pytest.approx(0.7)


async def test_skipped_critical_metric_fails_case(monkeypatch):
    @scorer("t_ok")
    def _ok(**_):
        return 1.0, "fine", []

    @scorer("t_skip")
    def _skip(**_):
        raise MetricSkipped("no data")

    ds = make_dataset([_spec("ok", "t_ok"), _spec("safety", "t_skip", critical=True)])
    patch_runner_io(monkeypatch)
    run = await Runner(make_registry(ds), InMemoryRepo()).evaluate("t")
    assert run.case_results[0].skipped[0].critical is True
    assert run.case_results[0].passed is False
    assert run.status == "FAIL"


async def test_malformed_scorer_result_becomes_skipped(monkeypatch):
    @scorer("t_bad")
    def _bad(**_):
        return "oops"

    patch_runner_io(monkeypatch)
    run = await Runner(make_registry(make_dataset([_spec("bad", "t_bad")])), InMemoryRepo()).evaluate("t")
    case = run.case_results[0]
    assert case.scores == []
    assert "ValueError" in case.skipped[0].reason
    assert case.passed is False  # no scores at all -> fail


async def test_judge_semaphore_applies_only_to_judge_scorers(monkeypatch):
    released = threading.Event()

    @scorer("t_judge", judge=True)
    def _judge(**_):
        return (1.0 if released.wait(timeout=2) else 0.0), "judge", []

    @scorer("t_plain")
    def _plain(**_):
        released.set()
        return 1.0, "plain", []

    monkeypatch.setattr(Config, "JUDGE_CONCURRENCY", 1)
    ds = make_dataset([_spec("j", "t_judge"), _spec("p", "t_plain")])
    patch_runner_io(monkeypatch)
    run = await Runner(make_registry(ds), InMemoryRepo()).evaluate("t")
    judge_score = next(s for s in run.case_results[0].scores if s.metric == "j")
    assert judge_score.score == 1.0  # the plain scorer ran while the judge held the semaphore


async def test_labels_are_read_only_for_the_runs_agent(monkeypatch):
    @scorer("t_ok")
    def _ok(**_):
        return 1.0, "fine", []

    label_store.add(HumanLabel(case_id="c1", verdict="fail", agent_id="other-agent"))
    patch_runner_io(monkeypatch)
    runner = Runner(make_registry(make_dataset([_spec("ok", "t_ok")])), InMemoryRepo())
    assert (await runner.evaluate("t")).stats.labeled_cases == 0
    label_store.add(HumanLabel(case_id="c1", verdict="fail", agent_id="t"))
    assert (await runner.evaluate("t")).stats.labeled_cases == 1


async def test_cancel_flag_saves_cancelled_error_record(monkeypatch):
    @scorer("t_ok")
    def _ok(**_):
        return 1.0, "fine", []

    target = StubTarget()
    patch_runner_io(monkeypatch, target=target)
    repo = InMemoryRepo()
    ds = make_dataset([_spec("ok", "t_ok")], _cases(3, ["ok"]))
    with pytest.raises(asyncio.CancelledError):
        await Runner(make_registry(ds), repo).evaluate("t", should_cancel=lambda: len(target.calls) >= 1)
    run = next(iter(repo.runs.values()))
    assert run.status == "ERROR"
    assert run.error_detail == "cancelled"
    assert [c.case_id for c in run.case_results] == ["c0"]


async def test_task_cancel_saves_cancelled_record(monkeypatch):
    started = asyncio.Event()

    class SlowTarget:
        async def run_case(self, case):
            started.set()
            await asyncio.sleep(30)

    patch_runner_io(monkeypatch, target=SlowTarget())
    repo = InMemoryRepo()
    task = asyncio.create_task(Runner(make_registry(make_dataset([_spec("ok", "t_ok")])), repo).evaluate("t"))
    await started.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert next(iter(repo.runs.values())).error_detail == "cancelled"


async def test_failing_case_cancels_siblings(monkeypatch):
    class MixedTarget:
        async def run_case(self, case):
            if case.id == "c0":
                await asyncio.sleep(0.01)
                raise RuntimeError("case c0 failed")
            await asyncio.sleep(30)

    monkeypatch.setattr(Config, "CASE_CONCURRENCY", 2)
    patch_runner_io(monkeypatch, target=MixedTarget())
    ds = make_dataset([_spec("ok", "t_ok")], _cases(2, ["ok"]))
    start = time.monotonic()
    with pytest.raises(RuntimeError, match="case c0 failed"):
        await Runner(make_registry(ds), InMemoryRepo()).evaluate("t")
    assert time.monotonic() - start < 5


async def test_save_failure_in_error_path_keeps_original_exception(monkeypatch):
    class ExplodingTarget:
        async def run_case(self, case):
            raise RuntimeError("agent call blew up")

    patch_runner_io(monkeypatch, target=ExplodingTarget())
    with pytest.raises(RuntimeError, match="agent call blew up"):
        await Runner(make_registry(make_dataset([_spec("ok", "t_ok")])), InMemoryRepo(fail_save=True)).evaluate("t")


async def test_adapter_construction_error_is_persisted(monkeypatch):
    from registry import RegisteredAgent

    monkeypatch.setattr(RegisteredAgent, "metrics_stub_path", property(lambda self: None))
    ds = make_dataset([_spec("ok", "t_ok")])
    ds.target.adapter = "does_not_exist"
    repo = InMemoryRepo()
    with pytest.raises(ValueError, match="Unknown target adapter"):
        await Runner(make_registry(ds), repo).evaluate("t")
    assert next(iter(repo.runs.values())).status == "ERROR"


async def test_observation_preview_uses_rendered_prose(monkeypatch):
    @scorer("t_ok")
    def _ok(**_):
        return 1.0, "fine", []

    bundle = {"r": {"report_title": "Past Review", "paragraphs": [{"content": "x" * 900}]}}
    patch_runner_io(monkeypatch, target=StubTarget(output=bundle))
    events = []

    async def progress(event):
        events.append(event)

    await Runner(make_registry(make_dataset([_spec("ok", "t_ok")])), InMemoryRepo()).evaluate("t", progress=progress)
    preview = next(e for e in events if e["type"] == "observation")["output_preview"]
    assert preview.startswith("Past Review")
    assert len(preview) == 601 and preview.endswith("…")
