"""pdf_table_has / docx_table_has edge cases not covered by test_configurable_advanced."""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest

from scorer_helpers import obs, run
from scorers.base import MetricSkipped
from scorers.document_tables import _match_tables, _resolve_doc_bytes

_TABLES = {"tables": [{"required_headers": ["Name", "Amount"], "min_rows": 2}]}


class _Page:
    def __init__(self, tables: list | None) -> None:
        self._tables = tables

    def extract_tables(self) -> list | None:
        return self._tables


class _Pdf:
    def __init__(self, pages: list[_Page]) -> None:
        self.pages = pages

    def __enter__(self) -> _Pdf:
        return self

    def __exit__(self, *exc: Any) -> None:
        return None


def _fake_pdfplumber(monkeypatch, pages: list[_Page]) -> list[bytes]:
    """Install a stand-in ``pdfplumber`` module; returns the bytes it was opened with."""
    opened: list[bytes] = []
    module = types.ModuleType("pdfplumber")

    def _open(stream):
        opened.append(stream.read())
        return _Pdf(pages)

    module.open = _open
    monkeypatch.setitem(sys.modules, "pdfplumber", module)
    return opened


def test_pdf_tables_are_collected_across_pages(monkeypatch):
    pages = [_Page(None), _Page([[["Other"]]]), _Page([[["Name", "Amount"], ["a", "1"]]])]
    opened = _fake_pdfplumber(monkeypatch, pages)
    score, rationale, evidence = run("pdf_table_has", obs(b"%PDF-1.4 doc"), config=_TABLES)
    assert score == 1.0
    assert rationale == "1/1 table constraints met"
    assert evidence[0].startswith("✓ table #0")
    assert opened == [b"%PDF-1.4 doc"]


def test_pdf_table_missing_header_fails(monkeypatch):
    _fake_pdfplumber(monkeypatch, [_Page([[["Name"], ["a"], ["b"]]])])
    assert run("pdf_table_has", obs(b"%PDF"), config=_TABLES)[0] == 0.0


def test_missing_pdfplumber_skips_with_install_hint(monkeypatch):
    monkeypatch.setitem(sys.modules, "pdfplumber", None)
    with pytest.raises(MetricSkipped, match="pdfplumber is not installed; pdf_table_has is skipped"):
        run("pdf_table_has", obs(b"%PDF"), config=_TABLES)


def test_url_output_skips(monkeypatch):
    _fake_pdfplumber(monkeypatch, [])
    with pytest.raises(MetricSkipped, match="PDF output is a URL"):
        run("pdf_table_has", obs("https://x/doc.pdf", {"output_kind": "url"}), config=_TABLES)


def test_non_text_output_skips():
    with pytest.raises(MetricSkipped, match="could not resolve DOCX bytes"):
        _resolve_doc_bytes(obs({"not": "bytes"}), {}, "docx")


def test_raw_output_metadata_wins_over_output():
    assert _resolve_doc_bytes(obs("text", {"raw_output": bytearray(b"PK..")}), {}, "docx") == b"PK.."


def test_undeclared_non_base64_text_is_kept_as_utf8():
    assert _resolve_doc_bytes(obs("not base64!"), {}, "pdf") == b"not base64!"


def test_declared_bytes_kind_encodes_text():
    assert _resolve_doc_bytes(obs("PK text"), {"output_kind": "BYTES"}, "docx") == b"PK text"


def test_non_numeric_min_rows_is_a_config_error():
    with pytest.raises(MetricSkipped, match="config error: 'min_rows' must be a whole number, got 'many'"):
        _match_tables([{"required_headers": ["a"], "min_rows": "many"}], [[["a"]]])
