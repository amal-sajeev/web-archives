"""Tests for the text/regex config-driven scorers (scorers/configurable_text.py)."""

from __future__ import annotations

import pytest

from scorer_helpers import case, obs, run, spec
from scorers.base import MetricSkipped, get_scorer


class TestContains:
    def test_all_present(self):
        score = run("contains", obs("The quick brown fox jumps over the lazy dog"),
                    config={"terms": ["quick", "fox", "dog"]})[0]
        assert score == 1.0

    def test_some_missing(self):
        score = run("contains", obs("The quick brown fox"), config={"terms": ["quick", "cat", "dog"]})[0]
        assert score == pytest.approx(1 / 3)

    def test_min_count(self):
        score, _, _ = run("contains", obs("ha ha ha ha"), config={"terms": ["ha"], "min_count": 3})
        assert score == 1.0

    def test_case_insensitive(self):
        score, _, _ = run("contains", obs("Hello World"), config={"terms": ["hello"], "case_sensitive": False})
        assert score == 1.0

    def test_op_not_empty_nonempty(self):
        assert run("contains", obs("hello"), config={"op": "not_empty", "substring": ""})[0] == 1.0

    def test_op_not_empty_blank_fails(self):
        assert run("contains", obs("   "), config={"op": "not_empty", "substring": ""})[0] == 0.0

    def test_empty_terms_without_op_still_passes(self):
        assert run("contains", obs("hello"), config={})[0] == 1.0

    def test_string_terms_is_one_term_not_characters(self):
        score, rationale, _ = run("contains", obs("xyz"), config={"terms": "abc"})
        assert score == 0.0
        assert rationale == "0/1 required terms present"

    def test_non_string_terms_are_safe(self):
        score, _, _ = run("contains", obs("Invoice 2025 total 42"), config={"terms": [2025, 42]})
        assert score == 1.0


class TestNotEmpty:
    @pytest.mark.parametrize(("output", "expected"), [
        ("hello", 1.0), ("  \n", 0.0), (None, 0.0), ({}, 0.0), ([], 0.0), (b"", 0.0),
    ])
    def test_outputs(self, output, expected):
        assert get_scorer("not_empty")(observation=obs(output), case=case())[0] == expected


class TestNotContains:
    def test_all_absent(self):
        score, _, _ = run("not_contains", obs("Coverage includes medical and dental."),
                          config={"terms": ["guaranteed return", "ignore previous"]})
        assert score == 1.0

    def test_some_present(self):
        score, _, _ = run("not_contains", obs("The secret code is 1"), config={"forbidden": ["secret", "password"]})
        assert score == pytest.approx(0.5)

    def test_string_forbidden_is_one_term(self):
        score, _, evidence = run("not_contains", obs("a b c"), config={"terms": "abc"})
        assert score == 1.0
        assert len(evidence) == 1


class TestRegexMatch:
    def test_match(self):
        score, _, _ = run("regex_match", obs("Invoice #INV-2025-001"),
                          config={"patterns": [{"pattern": r"INV-\d{4}-\d{3}"}]})
        assert score == 1.0

    def test_no_match(self):
        score, _, _ = run("regex_match", obs("Hello World"), config={"patterns": [{"pattern": r"INV-\d+"}]})
        assert score == 0.0

    def test_optional_pattern(self):
        score, _, _ = run("regex_match", obs("Hello"), config={"patterns": [
            {"pattern": r"Hello", "required": True}, {"pattern": r"World", "required": False},
        ]})
        assert score == 1.0

    def test_flags(self):
        score, _, _ = run("regex_match", obs("HELLO"), config={"patterns": [{"pattern": "hello", "flags": "i"}]})
        assert score == 1.0

    def test_invalid_regex_is_config_error(self):
        with pytest.raises(MetricSkipped, match="invalid regex"):
            run("regex_match", obs("x"), config={"patterns": [{"pattern": "([unclosed"}]})

    def test_invalid_flag_is_config_error(self):
        with pytest.raises(MetricSkipped, match="invalid regex flags"):
            run("regex_match", obs("x"), config={"patterns": [{"pattern": "x", "flags": "q"}]})

    def test_invalid_regex_reported_even_if_optional(self):
        with pytest.raises(MetricSkipped):
            run("regex_match", obs("x"), config={"patterns": [
                {"pattern": "x"}, {"pattern": "(", "required": False},
            ]})


class TestLengthRange:
    def test_within_range(self):
        score = run("length_range", obs("one two three four five"),
                    config={"min": 3, "max": 10, "unit": "words"})[0]
        assert score == 1.0

    def test_below_min(self):
        score, _, _, _ = run("length_range", obs("one two"), config={"min": 5, "unit": "words"})
        assert score == pytest.approx(0.4)

    def test_above_max(self):
        score, _, _, _ = run("length_range", obs(" ".join(["word"] * 100)),
                             config={"min": 1, "max": 10, "unit": "words"})
        assert score == pytest.approx(0.1)

    def test_upper_bound_inclusive_with_zero_min(self):
        score, rationale, _, _ = run("length_range", obs("abcde"), config={"max": 5, "unit": "chars"})
        assert score == 1.0
        assert "[0, 5]" in rationale

    def test_measured_by_default_raw_value_when_opted_in(self):
        default = run("length_range", obs("a b c"), config={"min": 1})[3]
        assert default == {"measured": 3.0}
        fn = get_scorer("length_range")
        opted = fn(observation=obs("a b c"), case=case(),
                   spec=spec("length_range", {"min": 1}, direction="lower_is_better", norm_max=10))[3]
        assert opted == {"raw_value": 3.0}


class TestKeywordCount:
    def test_count_and_bounded_score(self):
        score, _, _, extras = run("keyword_count", obs("error error error warning info"),
                                  config={"terms": ["error", "warning"]})
        assert score == 1.0
        assert extras["measured"] == 4.0  # 3 "error" + 1 "warning"

    def test_score_scales_with_min_count(self):
        score, _, _, _ = run("keyword_count", obs("error error"), config={"terms": ["error"], "min_count": 4})
        assert score == pytest.approx(0.5)

    def test_zero_hits_scores_zero(self):
        assert run("keyword_count", obs("nothing here"), config={"terms": ["error"]})[0] == 0.0

    def test_string_terms_single_keyword(self):
        _, _, evidence, extras = run("keyword_count", obs("abc abc"), config={"terms": "abc"})
        assert extras["measured"] == 2.0
        assert evidence == ["'abc': 2"]

    def test_requires_terms(self):
        with pytest.raises(MetricSkipped):
            run("keyword_count", obs("x"), config={})


class TestTextEdges:
    def test_substring_alias_adds_a_term(self):
        score, rationale, _ = run("contains", obs("Acme Corp"), config={"terms": ["acme"], "substring": "corp"})
        assert (score, rationale) == (1.0, "2/2 required terms present")

    def test_not_empty_on_numeric_output_uses_text(self):
        assert run("not_empty", obs(0))[:2] == (1.0, "output is non-empty")

    def test_not_contains_without_terms_passes(self):
        assert run("not_contains", obs("x"), config={})[:2] == (1.0, "no forbidden terms configured")

    def test_only_optional_patterns_says_so(self):
        score, rationale, evidence = run("regex_match", obs("abc"), config={"patterns": [
            {"pattern": "a", "required": False}, {"pattern": "z", "required": False},
        ]})
        assert score == 1.0
        assert rationale == "no required patterns (2 optional checked)"
        assert evidence[1].endswith("miss (optional)")

    def test_no_patterns_configured_passes(self):
        assert run("regex_match", obs("x"), config={})[:2] == (1.0, "no patterns configured")

    @pytest.mark.parametrize(("scorer_name", "config", "key"), [
        ("contains", {"terms": ["a"], "min_count": "several"}, "min_count"),
        ("keyword_count", {"terms": ["a"], "min_count": None}, "min_count"),
        ("length_range", {"min": "ten"}, "min"),
        ("length_range", {"max": [5]}, "max"),
        ("heading_count", {"min": "two"}, "min"),
    ])
    def test_non_numeric_config_is_a_clear_config_error(self, scorer_name, config, key):
        with pytest.raises(MetricSkipped, match=f"config error: '{key}' must be a whole number"):
            run(scorer_name, obs("a b"), config=config)
