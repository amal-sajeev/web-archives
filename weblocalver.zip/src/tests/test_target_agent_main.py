"""Target adapters (adapters/target_agent.py) and the app's route table."""

from __future__ import annotations

import httpx
import pytest

from adapters import registry as adapter_registry
from adapters import target_agent
from adapters.registry import register_adapter
from core.models import Dataset, GoldenCase, TargetSpec
from core_helpers import mock_http_fixture  # noqa: F401


@pytest.fixture(autouse=True)
def _isolated_adapter_registry(monkeypatch):
    monkeypatch.setattr(adapter_registry, "_ADAPTER_REGISTRY", dict(adapter_registry._ADAPTER_REGISTRY))


def _dataset(adapter: str, endpoint: str = "/eval", **target_kw) -> Dataset:
    return Dataset(dataset_id="d1", version="v1", target=TargetSpec(adapter=adapter, endpoint=endpoint, **target_kw))


def test_build_target_adapter_uses_http_adapter(monkeypatch):
    captured = {}

    class FakeHttpAdapter:
        def __init__(self, base, endpoint, target):
            captured.update(base=base, endpoint=endpoint, target=target)

    monkeypatch.setattr("adapters.http_adapter.HttpAdapter", FakeHttpAdapter)
    monkeypatch.setattr(target_agent.Config, "AGENT_SERVICE_BASE_URL", "https://agent-base")

    adapter = target_agent.build_target_adapter(_dataset("http"))

    assert isinstance(adapter, FakeHttpAdapter)
    assert captured["base"] == "https://agent-base"
    assert captured["endpoint"] == "/eval"


def test_build_target_adapter_uses_custom_registered_adapter():
    @register_adapter("custom_test_adapter")
    class FakeCustomAdapter:
        def __init__(self, base, endpoint, target):
            self.base, self.endpoint, self.target = base, endpoint, target

    adapter = target_agent.build_target_adapter(_dataset("custom_test_adapter", "/custom"), base_url="https://custom-base")

    assert isinstance(adapter, FakeCustomAdapter)
    assert adapter.base == "https://custom-base"
    assert adapter.endpoint == "/custom"


def test_builtin_adapters_win_over_custom_registrations():
    @register_adapter("scoping_analytics")
    class Shadow:
        def __init__(self, *args):
            pass

    adapter = target_agent.build_target_adapter(_dataset("scoping_analytics"), base_url="https://x")
    assert isinstance(adapter, target_agent.ScopingAnalyticsAdapter)


def test_unknown_adapter_raises():
    with pytest.raises(ValueError, match="Unknown target adapter 'nope'"):
        target_agent.build_target_adapter(_dataset("nope"), base_url="https://x")


def test_missing_base_url_raises(monkeypatch):
    monkeypatch.setattr(target_agent.Config, "AGENT_SERVICE_BASE_URL", None)
    with pytest.raises(ValueError, match="No base URL"):
        target_agent.build_target_adapter(_dataset("agent_eval_hook"))


def test_target_timeout_and_trust_env_are_honoured(monkeypatch):
    captured = {}

    def fake_kwargs(**kwargs):
        captured.update(kwargs)
        return {}

    monkeypatch.setattr(target_agent, "build_async_client_kwargs", fake_kwargs)
    adapter = target_agent.build_target_adapter(
        _dataset("agent_eval_hook", timeout=7.5, trust_env=True), base_url="https://x"
    )
    adapter._client_kwargs()
    assert captured == {"timeout": 7.5, "trust_env": True}


async def test_agent_eval_hook_adapter_returns_error_observation_on_http_status(mock_http):
    mock_http(lambda request: httpx.Response(500, text="boom"))

    adapter = target_agent.AgentEvalHookAdapter("https://agent", "/eval")
    observation = await adapter.run_case(GoldenCase(id="case-1", input={"hello": "world"}))

    assert observation.target_id == "case-1"
    assert observation.error == "HTTP 500: boom"


async def test_agent_eval_hook_adapter_maps_invalid_envelope_to_error(mock_http):
    mock_http(lambda request: httpx.Response(200, json={"no_target_id": True}))

    observation = await target_agent.AgentEvalHookAdapter("https://agent", "/eval").run_case(
        GoldenCase(id="case-3", input={})
    )
    assert observation.error.startswith("The agent replied, but not in the expected format. (ValidationError:")


async def test_scoping_analytics_adapter_maps_reports_to_observation(mock_http):
    mock_http(lambda request: httpx.Response(200, json={
        "plan_number": "20090",
        "plan_name": "Swap Dealer",
        "session_id": "sess-1",
        "analysis_report": {"past_review": {"report_title": "Past Review", "paragraphs": ["one", "two"]}},
    }))

    adapter = target_agent.ScopingAnalyticsAdapter("https://agent", "/run-analytics-agent")
    observation = await adapter.run_case(GoldenCase(id="case-2", input={"planNumber": "20090", "planName": "Swap Dealer"}))

    assert observation.target_id == "case-2"
    assert observation.output["past_review"]["report_title"] == "Past Review"
    assert observation.tool_calls[0]["name"] == "generate_report"
    assert observation.tool_calls[0]["paragraphs"] == 2
    assert observation.metadata["report_count"] == 1
    assert observation.metadata["session_id"] == "sess-1"


async def test_eval_hook_non_json_reply_is_explained(mock_http):
    mock_http(lambda request: httpx.Response(200, text="<html>login</html>"))
    observation = await target_agent.AgentEvalHookAdapter("https://agent", "/eval").run_case(GoldenCase(id="c", input={}))
    assert observation.error.startswith("The agent replied, but the reply was not valid JSON.")


async def test_scoping_adapter_non_dict_reply_is_the_output(mock_http):
    mock_http(lambda request: httpx.Response(200, json=["just", "text"]))
    adapter = target_agent.ScopingAnalyticsAdapter("https://agent", "/run")
    observation = await adapter.run_case(GoldenCase(id="c", input={"plan_number": "1"}))
    assert observation.output == ["just", "text"]
    assert observation.tool_calls == []
    assert observation.metadata["plan_number"] is None


async def test_scoping_adapter_unreachable_agent(mock_http):
    def _refuse(request):
        raise httpx.ConnectError("refused", request=request)

    mock_http(_refuse)
    adapter = target_agent.ScopingAnalyticsAdapter("https://agent", "/run")
    observation = await adapter.run_case(GoldenCase(id="c", input={}))
    assert observation.error.startswith("Could not connect to the agent.")
    assert observation.output is None


def _route_paths(routes) -> set[str]:
    """Paths of all routes, descending into included routers (no prefixes are used)."""
    paths: set[str] = set()
    for route in routes:
        if getattr(route, "path", None):
            paths.add(route.path)
        included = getattr(route, "original_router", None)
        if included is not None:
            paths |= _route_paths(included.routes)
    return paths


def test_main_registers_expected_routes():
    import main

    paths = _route_paths(main.app.routes)

    assert "/api/health" in paths
    assert "/api/evaluate/start" in paths
    assert "/api/evaluate/stream/{stream_id}" in paths
    assert "/api/playground/http" in paths
    assert "/api/settings" in paths
