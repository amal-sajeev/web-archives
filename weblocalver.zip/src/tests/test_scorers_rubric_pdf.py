"""rubric_multi and pdf_table_has scorers (moved from test_upgrades.py)."""

from __future__ import annotations

import pytest

from core.config import Config
from scorer_helpers import ScriptedJudge, obs, run
from scorers.base import MetricSkipped
from scorers.vertex import MultiRubricVerdict, RubricCriterionScore

_CRITERIA = {"criteria": [{"name": "tone", "rubric": "professional"}, {"name": "accuracy", "rubric": "correct"}]}


def _verdict(**scores: float) -> MultiRubricVerdict:
    return MultiRubricVerdict(
        scores=[RubricCriterionScore(criterion=k, score=v) for k, v in scores.items()],
        overall_rationale="fine",
    )


@pytest.fixture
def patch_multi(monkeypatch):
    def _apply(*verdicts):
        judge = ScriptedJudge(list(verdicts))
        monkeypatch.setattr("scorers.rubric.build_judge_for", lambda schema: judge)
        return judge
    return _apply


class TestRubricMultiScorer:
    def test_skips_without_criteria(self):
        with pytest.raises(MetricSkipped, match=r"requires config\.criteria"):
            run("rubric_multi", obs("text"), config={}, judge_repetitions=1)

    def test_skips_offline(self, monkeypatch):
        def _raise(*_args, **_kwargs):
            raise RuntimeError("no ADC")

        monkeypatch.setattr("scorers.rubric.build_judge_for", _raise)
        with pytest.raises(MetricSkipped, match="LLM judge unavailable"):
            run("rubric_multi", obs("text"), config={"criteria": [{"name": "tone", "rubric": "x"}]})

    def test_mean_over_configured_criteria(self, patch_multi):
        patch_multi(_verdict(tone=1.0, accuracy=0.5))
        score, _, evidence, extras = run("rubric_multi", obs("text"), config=_CRITERIA)
        assert score == pytest.approx(0.75)
        assert evidence[0].startswith("tone: 1.000")
        assert extras["variance"] == 0.0

    def test_missing_criterion_scores_zero_and_extra_ignored(self, patch_multi):
        patch_multi(_verdict(tone=1.0, invented=1.0))
        score, _, evidence, _ = run("rubric_multi", obs("text"), config=_CRITERIA)
        assert score == pytest.approx(0.5)
        assert any("accuracy: 0.000" in e and "missing" in e for e in evidence)

    def test_name_matching_is_case_insensitive(self, patch_multi):
        patch_multi(_verdict(Tone=0.8, ACCURACY=0.6))
        assert run("rubric_multi", obs("text"), config=_CRITERIA)[0] == pytest.approx(0.7)

    def test_unnamed_criterion_gets_fallback_name(self, patch_multi):
        judge = patch_multi(_verdict(criterion_1=0.4))
        score, _, evidence, _ = run("rubric_multi", obs("text"), config={"criteria": [{"rubric": "tone"}]})
        assert score == pytest.approx(0.4)
        assert "1. criterion_1: tone" in judge.prompts[0]
        assert evidence[0].startswith("criterion_1:")

    def test_unstable_flag_on_high_variance(self, patch_multi, monkeypatch):
        monkeypatch.setattr(Config, "JUDGE_MAX_VARIANCE", 0.05)
        patch_multi(_verdict(tone=0.0, accuracy=0.0), _verdict(tone=1.0, accuracy=1.0))
        score, _, _, extras = run("rubric_multi", obs("text"), config=_CRITERIA, judge_repetitions=2)
        assert score == pytest.approx(0.5)
        assert extras["unstable"] is True

    def test_uses_golden_without_golden_skips(self, patch_multi):
        patch_multi(_verdict(tone=1.0))
        with pytest.raises(MetricSkipped, match="no golden_output"):
            run("rubric_multi", obs("text"), config={**_CRITERIA, "uses_golden": True})


class TestPdfTableHasScorer:
    def test_skips_without_pdfplumber(self):
        try:
            import pdfplumber  # noqa: F401
            pytest.skip("pdfplumber installed; skip test is for missing lib")
        except ImportError:
            pass
        observation = obs(b"%PDF-1.4 test", {"raw_output": b"%PDF-1.4 test"})
        with pytest.raises(MetricSkipped, match="pdfplumber is not installed"):
            run("pdf_table_has", observation, config={"tables": [{"required_headers": ["A", "B"], "min_rows": 2}]})

    def test_no_tables_config_returns_pass(self):
        score, _, _ = run("pdf_table_has", obs(b""), config={})
        assert score == 1.0
