"""Helpers shared by the core/adapter test modules (not a test module itself).

Import the ``mock_http`` fixture into a test module with
``from core_helpers import mock_http_fixture  # noqa: F401``.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from typing import Any

import httpx
import pytest

from core.models import AgentConfig, Dataset, GoldenCase, MetricSpec, Observation, RunRecord
from registry import RegisteredAgent, Registry
from repository.base import EvaluationRepository

Handler = Callable[[httpx.Request], httpx.Response]


@pytest.fixture(name="mock_http")
def mock_http_fixture(monkeypatch: pytest.MonkeyPatch) -> Callable[[Handler], list[httpx.Request]]:
    """Route every ``httpx.AsyncClient`` through a ``MockTransport``.

    Call the fixture with a request handler; it returns the list the seen
    requests are appended to. The patch is undone automatically.
    """

    def _install(handler: Handler) -> list[httpx.Request]:
        seen: list[httpx.Request] = []

        def _record(request: httpx.Request) -> httpx.Response:
            seen.append(request)
            return handler(request)

        transport = httpx.MockTransport(_record)
        original = httpx.AsyncClient.__init__

        def _patched(self: httpx.AsyncClient, *args: Any, **kwargs: Any) -> None:
            kwargs["transport"] = transport
            original(self, *args, **kwargs)

        monkeypatch.setattr(httpx.AsyncClient, "__init__", _patched)
        return seen

    return _install


class InMemoryRepo(EvaluationRepository):
    """Dict-backed repository; ``fail_save`` makes ``save_run`` raise."""

    def __init__(self, fail_save: bool = False) -> None:
        self.runs: dict[str, RunRecord] = {}
        self.baselines: dict[tuple[str, str, str, str], float] = {}
        self.fail_save = fail_save

    def init_schema(self) -> None:
        return None

    def save_run(self, run: RunRecord) -> None:
        if self.fail_save:
            raise RuntimeError("database down")
        self.runs[run.run_id] = run

    def get_run(self, run_id: str) -> RunRecord | None:
        return self.runs.get(run_id)

    def list_runs(self, agent_id=None, limit=50, before=None, status=None, dataset_id=None, before_id=None):
        return [r.model_dump() for r in self.runs.values()][:limit]

    def get_baseline(self, agent_id, dataset_id, dataset_version, metric):
        return self.baselines.get((agent_id, dataset_id, dataset_version, metric))

    def set_baseline(self, agent_id, dataset_id, dataset_version, metric, value, created_by):
        self.baselines[(agent_id, dataset_id, dataset_version, metric)] = value


class StubTarget:
    """Target adapter returning a fixed successful Observation."""

    def __init__(self, output: Any = "AU-10001 Acme Corp inventory") -> None:
        self.output = output
        self.calls: list[str] = []

    async def run_case(self, case: GoldenCase) -> Observation:
        self.calls.append(case.id)
        return Observation(
            target_id="t",
            output=self.output,
            tool_calls=[{"name": "get_application_data", "args": "AU-10001;Acme Corp", "error": None}],
            latency_ms=1000,
            usage={"input_tokens": 100, "output_tokens": 50},
        )


class StubMetrics:
    async def fetch(self, case_id: str, observation: Observation | None = None) -> dict[str, float]:
        return {"ai_confidence_score": 0.95, "response_code": 200}


def make_registry(dataset: Dataset, agent_id: str = "t") -> Registry:
    """Registry holding one agent, bypassing folder discovery."""
    reg = Registry()
    reg._agents = {agent_id: RegisteredAgent(folder=None, config=AgentConfig(agent_id=agent_id, name="T"),
                                             dataset=dataset)}
    return reg


def make_dataset(metrics: list[MetricSpec], cases: list[GoldenCase] | None = None) -> Dataset:
    return Dataset(dataset_id="t", version="v1", metrics=metrics,
                   cases=cases or [GoldenCase(id="c1", input={}, baseline_metrics={m.name: 1.0 for m in metrics})])


def patch_runner_io(monkeypatch: pytest.MonkeyPatch, target: Any = None, metrics: Any = None) -> None:
    """Replace the runner's adapter/metrics factories with stubs."""
    tgt = target or StubTarget()
    met = metrics or StubMetrics()
    monkeypatch.setattr("core.runner.build_target_adapter", lambda dataset, base_url: tgt)
    monkeypatch.setattr("core.runner.build_metrics_client", lambda *a, **kw: met)
    monkeypatch.setattr(RegisteredAgent, "metrics_stub_path", property(lambda self: None))


@contextmanager
def capture_logs(logger_name: str) -> Iterator[list[logging.LogRecord]]:
    """Collect records from a (possibly non-propagating) logger."""
    records: list[logging.LogRecord] = []

    class _Collect(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            records.append(record)

    handler = _Collect(level=logging.DEBUG)
    logger = logging.getLogger(logger_name)
    old_level = logger.level
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    try:
        yield records
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)
