"""Run the frontend's pure-JS unit tests (``src/tests/js/*.test.mjs``) through node's test runner.

Skipped when node is not installed, so the Python suite stays runnable everywhere.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

_JS_TEST_DIR = Path(__file__).resolve().parent / "js"
_NODE = shutil.which("node")


@pytest.mark.skipif(_NODE is None, reason="node is not installed")
def test_js_unit_suite_passes():
    files = sorted(str(p) for p in _JS_TEST_DIR.glob("*.test.mjs"))
    assert files, "no JS unit tests found"
    result = subprocess.run(
        [_NODE, "--test", *files], capture_output=True, text=True, timeout=300, check=False,
    )
    assert result.returncode == 0, result.stdout[-4000:] + result.stderr[-2000:]
