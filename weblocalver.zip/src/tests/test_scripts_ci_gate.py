"""Tests for scripts/ci_gate.py: gates, argument handling and the end-to-end exit codes."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))

import ci_gate
import ci_gate_client

_ENV_KEYS = (
    "EVAL_SERVICE_URL", "AGENT_ID", "EVAL_TIMEOUT_SECONDS", "EVAL_MIN_SCORE",
    "EVAL_MAX_DELTA_REGRESS", "EVAL_MIN_PASS_RATE", "EVAL_JUDGE_REPS",
)


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    for key in _ENV_KEYS:
        monkeypatch.delenv(key, raising=False)


def _run(**overrides: Any) -> dict[str, Any]:
    run = {"run_id": "r1", "status": "PASS", "weighted_score": 0.9, "weighted_delta": 0.0,
           "stats": {"pass_rate": 1.0}}
    run.update(overrides)
    return run


class TestGates:
    def test_default_thresholds_check_status_and_delta_only(self):
        results = ci_gate.evaluate_gates(_run(), ci_gate.Thresholds())
        assert [ok for ok, _ in results] == [True, True]
        assert results[0][1] == "run status: PASS"

    def test_every_gate_can_fail(self):
        run = _run(status="FAIL", weighted_score=0.5, weighted_delta=-0.3, stats={"pass_rate": 0.25})
        results = ci_gate.evaluate_gates(run, ci_gate.Thresholds(0.8, -0.1, 0.9))
        assert [ok for ok, _ in results] == [False, False, False, False]
        assert "weighted_score 0.500 (min 0.800)" in results[1][1]
        assert "weighted_delta -0.300 (lowest allowed -0.100)" in results[2][1]
        assert "pass_rate 25.0% (min 90.0%)" in results[3][1]

    def test_missing_or_non_numeric_values_count_as_zero(self):
        run = _run(weighted_score=True, weighted_delta=None, stats="broken")
        score, delta, rate = ci_gate.evaluate_gates(run, ci_gate.Thresholds(0.1, 0.0, 0.1))[1:]
        assert not score[0] and delta[0] and not rate[0]


def test_summarise_keeps_only_summary_fields():
    summary = ci_gate.summarise(_run(cases=[1, 2, 3]))
    assert set(summary) == set(ci_gate.SUMMARY_FIELDS)
    assert summary["dataset_id"] is None


def test_export_summary_to_file_and_stdout(tmp_path, capsys):
    out = tmp_path / "summary.json"
    ci_gate.export_summary({"a": 1}, str(out))
    assert json.loads(out.read_text(encoding="utf-8")) == {"a": 1}
    ci_gate.export_summary({"b": 2}, None)
    printed = capsys.readouterr().out
    assert f"Results exported to {out}" in printed
    assert "=== Evaluation Results ===" in printed and '"b": 2' in printed


def test_report_gates(capsys):
    assert ci_gate.report_gates([(True, "x")]) is True
    assert ci_gate.report_gates([(True, "x"), (False, "y")]) is False
    printed = capsys.readouterr().out
    assert "[PASS] x" in printed and "[FAIL] y" in printed
    assert "ALL GATES PASSED" in printed and "GATES FAILED" in printed


class TestArguments:
    def test_env_defaults(self, monkeypatch):
        monkeypatch.setenv("EVAL_SERVICE_URL", "http://ci:9")
        monkeypatch.setenv("EVAL_TIMEOUT_SECONDS", "60")
        monkeypatch.setenv("EVAL_JUDGE_REPS", "3")
        args = ci_gate.build_parser().parse_args([])
        assert (args.eval_url, args.timeout, args.judge_reps, args.delta) == ("http://ci:9", 60.0, 3, -0.1)

    def test_bad_env_value_is_a_usage_error_not_a_traceback(self, monkeypatch, capsys):
        monkeypatch.setenv("EVAL_TIMEOUT_SECONDS", "twenty")
        with pytest.raises(SystemExit) as exc:
            ci_gate.main(["agent-a"])
        assert exc.value.code == ci_gate.EXIT_INFRA_ERROR
        assert "argument --timeout: invalid float value: 'twenty'" in capsys.readouterr().err

    @pytest.mark.parametrize(("argv", "env", "expected"), [
        (["pos"], None, "pos"),
        (["--agent", "flag"], None, "flag"),
        (["same", "--agent", "same"], None, "same"),
        ([], "from-env", "from-env"),
    ])
    def test_resolve_agent(self, monkeypatch, argv, env, expected):
        if env:
            monkeypatch.setenv("AGENT_ID", env)
        assert ci_gate.resolve_agent(ci_gate.build_parser().parse_args(argv)) == expected

    @pytest.mark.parametrize(("argv", "message"), [
        ([], "give one agent id"),
        (["a", "--agent", "b"], "two different agent ids given: 'a' (positional) and 'b' (--agent)"),
    ])
    def test_main_rejects_missing_or_conflicting_agent(self, capsys, argv, message):
        assert ci_gate.main(argv) == ci_gate.EXIT_INFRA_ERROR
        assert message in capsys.readouterr().err


def _service(run: dict[str, Any], seen: list[httpx.Request]):
    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        path = request.url.path
        if path == ci_gate_client.HEALTH_PATH:
            return httpx.Response(200, json={"status": "ok"})
        if path == ci_gate_client.START_PATH:
            return httpx.Response(202, json={"stream_id": "s1"})
        if path.endswith("/events"):
            return httpx.Response(200, json={"events": [{"type": "run_done"}], "seq": 1, "done": True,
                                             "run_id": "r1"})
        return httpx.Response(200, json=run)

    return handler


@pytest.fixture
def fake_service(monkeypatch):
    """Route ci_gate's EvalClient through a MockTransport serving ``state['run']``."""
    state: dict[str, Any] = {"run": _run(), "seen": []}
    real = ci_gate_client.EvalClient

    def factory(base_url: str, **kwargs: Any) -> ci_gate_client.EvalClient:
        transport = httpx.MockTransport(_service(state["run"], state["seen"]))
        return real(base_url, client=httpx.Client(base_url=base_url, transport=transport), **kwargs)

    monkeypatch.setattr(ci_gate, "EvalClient", factory)
    return state


class TestMain:
    def test_passing_run_exits_zero_and_clamps_judge_reps(self, fake_service, tmp_path, capsys):
        out = tmp_path / "s.json"
        code = ci_gate.main(["agent-a", "--judge-reps", "9", "--poll-interval", "0", "-v", "--output", str(out)])
        assert code == ci_gate.EXIT_PASS
        start = next(r for r in fake_service["seen"] if r.url.path == ci_gate_client.START_PATH)
        assert json.loads(start.read())["judge_repetitions"] == ci_gate.MAX_JUDGE_REPS
        assert json.loads(out.read_text(encoding="utf-8"))["run_id"] == "r1"
        printed = capsys.readouterr().out
        assert "[INFO] event: run_done" in printed and "ALL GATES PASSED" in printed

    def test_failing_gate_exits_one(self, fake_service, capsys):
        fake_service["run"] = _run(status="FAIL")
        assert ci_gate.main(["agent-a", "--poll-interval", "0"]) == ci_gate.EXIT_GATE_FAILED
        assert "[INFO]" not in capsys.readouterr().out  # quiet without -v

    def test_infrastructure_error_exits_two(self, monkeypatch, capsys):
        def factory(base_url: str, **kwargs: Any) -> ci_gate_client.EvalClient:
            def refuse(request):
                raise httpx.ConnectError("refused", request=request)
            http = httpx.Client(base_url=base_url, transport=httpx.MockTransport(refuse))
            return ci_gate_client.EvalClient(base_url, client=http, **kwargs)

        monkeypatch.setattr(ci_gate, "EvalClient", factory)
        assert ci_gate.main(["agent-a"]) == ci_gate.EXIT_INFRA_ERROR
        assert "[ERROR] eval service unreachable" in capsys.readouterr().err

    def test_unexpected_exception_is_reported_not_raised(self, monkeypatch, capsys):
        def explode(*_args: Any, **_kwargs: Any) -> None:
            raise KeyError("boom")

        monkeypatch.setattr(ci_gate, "EvalClient", explode)
        assert ci_gate.main(["agent-a"]) == ci_gate.EXIT_INFRA_ERROR
        assert "unexpected failure: KeyError" in capsys.readouterr().err


def test_script_entry_point_exits_with_main_code(monkeypatch, capsys):
    import runpy

    monkeypatch.setattr(sys, "argv", ["ci_gate.py"])
    with pytest.raises(SystemExit) as exc:
        runpy.run_path(ci_gate.__file__, run_name="__main__")
    assert exc.value.code == ci_gate.EXIT_INFRA_ERROR
    assert "give one agent id" in capsys.readouterr().err
