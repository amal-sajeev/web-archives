"""Judge failure wording, cache races, timeouts and golden-reference prompts."""

from __future__ import annotations

import httpx
import pytest

from core.config import Config
from scorer_helpers import ScriptedJudge, case, fast_retries, obs, run
from scorers import get_scorer, judge_invoke
from scorers.base import MetricSkipped
from scorers.vertex import JudgeVerdict, MultiRubricVerdict, RubricCriterionScore


class _Raises:
    def __init__(self, exc: Exception) -> None:
        self.exc = exc

    def invoke(self, prompt: str):
        raise self.exc


class TestFailureWording:
    def test_unreachable_judge_is_described_plainly(self, monkeypatch):
        fast_retries(monkeypatch, attempts=1)
        judge = _Raises(httpx.ConnectError("[Errno 11001] getaddrinfo failed"))
        with pytest.raises(MetricSkipped) as err:
            judge_invoke._invoke_metric(judge, "p")
        assert err.value.reason == (
            "LLM judge invocation failed: Could not connect to the AI assessment service. "
            "Check that it is running and that its address is correct. "
            "(ConnectError: [Errno 11001] getaddrinfo failed)"
        )

    def test_timeout_keeps_timed_out_wording_for_the_ui(self, monkeypatch):
        fast_retries(monkeypatch, attempts=1)
        with pytest.raises(MetricSkipped) as err:
            judge_invoke._invoke_metric(_Raises(TimeoutError("judge invoke timed out after 5.0s")), "p")
        assert "did not respond within the time limit" in err.value.reason
        assert "timed out" in err.value.reason

    def test_unknown_error_keeps_technical_text(self, monkeypatch):
        fast_retries(monkeypatch, attempts=1)
        with pytest.raises(MetricSkipped) as err:
            judge_invoke._invoke_metric(_Raises(ValueError("schema mismatch")), "p")
        assert err.value.reason == "LLM judge invocation failed: ValueError: schema mismatch"


class TestPlumbing:
    def test_cache_put_keeps_the_first_value_on_a_race(self):
        key = ("model", "prompt", 0)
        first = judge_invoke._cache_put(key, "first")
        assert judge_invoke._cache_put(key, "second") == first

    def test_zero_timeout_invokes_inline(self, monkeypatch):
        monkeypatch.setattr(Config, "JUDGE_CALL_TIMEOUT", 0)
        judge = ScriptedJudge([JudgeVerdict(score=0.3)])
        assert judge_invoke._invoke_with_timeout(judge, "p").score == pytest.approx(0.3)

    def test_slow_judge_times_out(self, monkeypatch):
        import threading

        release = threading.Event()

        class _Slow:
            def invoke(self, prompt):
                release.wait(5)

        monkeypatch.setattr(Config, "JUDGE_CALL_TIMEOUT", 0.05)
        try:
            with pytest.raises(TimeoutError, match="timed out after 0.1s"):
                judge_invoke._invoke_with_timeout(_Slow(), "p")
        finally:
            release.set()

    def test_judge_exception_is_re_raised_from_worker_thread(self, monkeypatch):
        monkeypatch.setattr(Config, "JUDGE_CALL_TIMEOUT", 5)
        with pytest.raises(ValueError, match="bad"):
            judge_invoke._invoke_with_timeout(_Raises(ValueError("bad")), "p")


class TestGoldenReference:
    def test_completeness_needs_a_golden_output(self, monkeypatch):
        monkeypatch.setattr("scorers.llm_judge.build_judge", lambda: ScriptedJudge([JudgeVerdict(score=1.0)]))
        with pytest.raises(MetricSkipped, match="completeness requires a golden_output reference"):
            get_scorer("completeness")(observation=obs("x"), case=case())

    def test_completeness_prompt_includes_golden(self, monkeypatch):
        judge = ScriptedJudge([JudgeVerdict(score=0.7)])
        monkeypatch.setattr("scorers.llm_judge.build_judge", lambda: judge)
        score, *_ = get_scorer("completeness")(observation=obs("x"), case=case(golden_output="THE-GOLDEN"))
        assert score == pytest.approx(0.7)
        assert "THE-GOLDEN" in judge.prompts[0]

    def test_custom_rubric_golden_block(self, monkeypatch):
        judge = ScriptedJudge([JudgeVerdict(score=1.0)])
        monkeypatch.setattr("scorers.rubric.build_judge", lambda: judge)
        cfg = {"rubric": "accurate", "uses_golden": True, "examples": "EX-1"}
        run("rubric", obs("x"), case(golden_output="REF"), config=cfg)
        assert "GOLDEN OUTPUT:\nREF" in judge.prompts[0]
        assert judge.prompts[0].endswith("Examples:\nEX-1")
        with pytest.raises(MetricSkipped, match="uses_golden=true but no golden_output"):
            run("rubric", obs("x"), case(), config=cfg)

    def test_rubric_multi_without_overall_rationale(self, monkeypatch):
        verdict = MultiRubricVerdict(scores=[RubricCriterionScore(criterion="tone", score=1.0)])
        monkeypatch.setattr("scorers.rubric.build_judge_for", lambda schema: ScriptedJudge([verdict]))
        _, _, evidence, _ = run("rubric_multi", obs("x"), config={"criteria": [{"name": "tone", "rubric": "r"}]})
        assert evidence == ["tone: 1.000 (1 samples)"]
