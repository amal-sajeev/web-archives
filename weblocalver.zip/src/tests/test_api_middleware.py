"""Cross-cutting HTTP behaviour: request ids, error envelope, cache headers, gzip,
HEAD probes, repository-unavailable 503s and the OpenAPI document."""

from __future__ import annotations

import logging
import sqlite3

import pytest
from sqlalchemy import exc as sa_exc

import main
from core.run_manager import run_manager
from error_handlers import error_type_for
from http_middleware import (
    NO_STORE,
    CacheControlMiddleware,
    RequestIdMiddleware,
    REVALIDATE,
    VERSIONED_ASSET,
    cache_policy,
    current_request_id,
    install_request_id_logging,
)


async def test_request_id_generated_and_echoed_in_error_body(api):
    response = await api.client.get("/api/runs/missing")

    request_id = response.headers["x-request-id"]
    assert len(request_id) == 32
    assert response.json() == {
        "detail": "Run 'missing' not found", "error_type": "not_found", "request_id": request_id,
    }


async def test_inbound_request_id_is_kept_and_invalid_one_replaced(api):
    kept = await api.client.get("/livez", headers={"X-Request-ID": "trace-123:abc"})
    replaced = await api.client.get("/livez", headers={"X-Request-ID": "bad id\twith spaces"})

    assert kept.headers["x-request-id"] == "trace-123:abc"
    assert replaced.headers["x-request-id"] != "bad id\twith spaces"
    assert current_request_id() is None  # context is reset after the request


async def test_unknown_route_and_validation_errors_use_envelope(api):
    missing = await api.client.get("/api/nope")
    invalid = await api.client.get("/api/runs?limit=abc")

    assert missing.status_code == 404
    assert missing.json()["error_type"] == "not_found"
    assert invalid.status_code == 422
    assert invalid.json()["error_type"] == "validation_error"
    assert invalid.json()["detail"][0]["loc"] == ["query", "limit"]
    assert invalid.json()["request_id"] == invalid.headers["x-request-id"]


async def test_method_not_allowed_uses_envelope(api):
    response = await api.client.delete("/api/runs")
    assert response.status_code == 405
    assert response.json()["error_type"] == "method_not_allowed"


async def test_unhandled_500_carries_request_id_header_and_body(api, monkeypatch):
    def _boom(**_kwargs):
        raise RuntimeError("hidden")

    monkeypatch.setattr(api.registry, "list_agents", _boom)
    response = await api.client.get("/api/agents", headers={"X-Request-ID": "req-500"})

    assert response.status_code == 500
    assert response.headers["x-request-id"] == "req-500"
    assert response.json()["request_id"] == "req-500"
    assert response.json()["error_type"] == "RuntimeError"


@pytest.mark.parametrize("error", [
    sqlite3.OperationalError("database is locked"),
    sa_exc.OperationalError("SELECT 1", {}, Exception("connection refused")),
])
async def test_repository_unavailable_is_503_with_retry_after(api, monkeypatch, error):
    def _down(**_kwargs):
        raise error

    monkeypatch.setattr(api.repo, "list_runs", _down)
    response = await api.client.get("/api/runs")

    assert response.status_code == 503
    assert response.headers["retry-after"] == "5"
    assert response.json()["error_type"] == "service_unavailable"
    assert "database is locked" not in response.json()["detail"]


async def test_evaluate_maps_repository_outage_to_503(api):
    async def _down(agent_id, progress=None):
        raise sqlite3.OperationalError("unable to open database file")

    api.runner.handler = _down
    response = await api.client.post("/api/evaluate", json={"agent_id": "agent-1"})

    assert response.status_code == 503
    assert response.headers["retry-after"] == "5"
    assert "error_id=" in response.json()["detail"]


async def test_cache_headers(api):
    live = run_manager.create("agent-1")
    live.finish()

    api_resp = await api.client.get("/api/runs")
    sse = await api.client.get(f"/api/evaluate/stream/{live.stream_id}")
    page = await api.client.get("/")

    assert api_resp.headers["cache-control"] == NO_STORE
    assert sse.headers["cache-control"] == "no-cache, no-transform"  # handler's own value wins
    assert page.headers["cache-control"] == REVALIDATE


@pytest.mark.parametrize(("path", "query", "status", "expected"), [
    ("/api/runs", b"", 200, NO_STORE),
    ("/readyz", b"", 200, NO_STORE),
    ("/css/base.css", b"v=1.2.3", 200, VERSIONED_ASSET),
    ("/css/base.css", b"", 200, REVALIDATE),
    ("/css/missing.css", b"v=1", 404, NO_STORE),
])
def test_cache_policy(path, query, status, expected):
    assert cache_policy(path, query, status) == expected


async def test_large_json_is_gzipped_small_is_not(api, make_run):
    for i in range(40):
        api.repo.save_run(make_run(f"run-{i:03d}", creation_ts=f"2026-01-01T00:00:{i:02d}+00:00"))

    big = await api.client.get("/api/runs?limit=40", headers={"Accept-Encoding": "gzip"})
    small = await api.client.get("/livez", headers={"Accept-Encoding": "gzip"})

    assert big.headers["content-encoding"] == "gzip"
    assert len(big.json()["runs"]) == 40  # httpx decodes transparently
    assert "content-encoding" not in small.headers


@pytest.mark.parametrize("path", ["/api/health", "/health", "/livez", "/readyz"])
async def test_head_supported_on_probes(api, path, monkeypatch):
    from core.config import Config

    monkeypatch.setattr(Config, "PROJECT_NAME", "")
    response = await api.client.head(path)
    assert response.status_code == 200
    assert response.content == b""


def test_error_type_for_statuses():
    assert error_type_for(404) == "not_found"
    assert error_type_for(418) == "http_error"
    assert error_type_for(507) == "server_error"


def test_openapi_has_tags_summaries_and_models():
    schema = main.app.openapi()
    summary_op = schema["paths"]["/api/runs/summary"]["get"]
    runs_op = schema["paths"]["/api/runs"]["get"]

    assert {t["name"] for t in schema["tags"]} >= {"runs", "health", "agents", "playground"}
    assert summary_op["tags"] == ["runs"]
    assert summary_op["summary"].startswith("Status counts")
    assert "RunSummaryResponse" in str(summary_op["responses"]["200"])
    assert "ErrorResponse" in str(runs_op["responses"]["503"])
    assert "RunDetailResponse" in str(schema["paths"]["/api/runs/{run_id}"]["get"]["responses"]["200"])
    assert "head" not in schema["paths"]["/livez"]


def _record() -> logging.LogRecord:
    return logging.getLogger("eval_service.test").makeRecord(
        "eval_service.test", logging.INFO, __file__, 1, "msg", None, None)


async def test_log_records_carry_request_id_during_request():
    install_request_id_logging()
    install_request_id_logging()  # idempotent: the factory is wrapped once
    seen: dict[str, logging.LogRecord] = {}
    sent: list[dict] = []

    async def _app(scope, receive, send):
        seen["inside"] = _record()
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    async def _send(message):
        sent.append(message)

    await RequestIdMiddleware(_app)({"type": "http", "headers": [(b"x-request-id", b"log-req")]}, None, _send)

    assert seen["inside"].request_id == "log-req"
    assert not hasattr(_record(), "request_id")
    assert (b"x-request-id", b"log-req") in sent[0]["headers"]


@pytest.mark.parametrize("middleware", [RequestIdMiddleware, CacheControlMiddleware])
async def test_middleware_passes_non_http_scopes_through(middleware):
    calls = []

    async def _app(scope, receive, send):
        calls.append(scope["type"])

    await middleware(_app)({"type": "lifespan"}, None, None)
    assert calls == ["lifespan"]


async def test_cache_middleware_strips_root_path():
    sent: list[dict] = []

    async def _app(scope, receive, send):
        await send({"type": "http.response.start", "status": 200, "headers": []})

    async def _send(message):
        sent.append(message)

    scope = {"type": "http", "path": "/eval/api/runs", "root_path": "/eval", "query_string": b""}
    await CacheControlMiddleware(_app)(scope, None, _send)
    assert (b"cache-control", NO_STORE.encode()) in sent[0]["headers"]
