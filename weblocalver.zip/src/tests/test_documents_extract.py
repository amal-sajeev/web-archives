"""Document extraction with real PDF/DOCX files, encoded inputs and golden files."""

from __future__ import annotations

import base64
import io

import docx
import httpx
import pytest

from adapters.documents import detect_content_type, extract_text, parse_headings, try_extract_text
from adapters.golden_files import load_golden_file
from utils import build_text_pdf

_DOCX_CTYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


def _docx_bytes() -> bytes:
    document = docx.Document()
    document.add_paragraph("Executive summary")
    document.add_paragraph("   ")  # blank paragraphs are dropped
    table = document.add_table(rows=2, cols=2)
    for r, row in enumerate([("Item", "Total"), ("Widget", " 42 ")]):
        for c, value in enumerate(row):
            table.cell(r, c).text = value
    buf = io.BytesIO()
    document.save(buf)
    return buf.getvalue()


@pytest.fixture(scope="module")
def pdf_bytes() -> bytes:
    return build_text_pdf(["Quarterly report", "Revenue grew"])


@pytest.fixture(scope="module")
def docx_bytes() -> bytes:
    return _docx_bytes()


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


class TestRealDocuments:
    def test_pdf_from_raw_bytes(self, pdf_bytes):
        text = extract_text(pdf_bytes, "pdf", output_kind="bytes")
        assert "Quarterly report" in text and "Revenue grew" in text

    def test_pdf_from_base64_with_auto_detection(self, pdf_bytes):
        assert detect_content_type(_b64(pdf_bytes), "base64") == "pdf"
        assert "Revenue grew" in extract_text(_b64(pdf_bytes), output_kind="base64")

    def test_docx_paragraphs_and_tables(self, docx_bytes):
        text = extract_text(docx_bytes, "auto", output_kind="bytes")
        assert text.split("\n\n") == ["Executive summary", "Item\tTotal", "Widget\t42"]

    def test_corrupt_pdf_reports_a_parse_error(self):
        text, error = try_extract_text(b"%PDF-1.4 truncated garbage", "pdf", output_kind="bytes")
        assert text == "" and error.startswith("PDF could not be parsed")

    def test_corrupt_docx_reports_a_parse_error(self):
        _, error = try_extract_text(b"PK not really a zip", "docx", output_kind="bytes")
        assert error.startswith("DOCX could not be parsed")

    def test_text_string_is_encoded_for_pdf_kind(self):
        # A str value with output_kind "text" is encoded, then fails to parse as PDF (reported, not raised).
        _, error = try_extract_text("%PDF not really", "pdf")
        assert "PDF could not be parsed" in error

    def test_str_with_bytes_kind_is_rejected(self):
        _, error = try_extract_text("abc", "docx", output_kind="bytes")
        assert error == "cannot read a document from str (bytes)"

    def test_base64_kind_needs_a_string(self):
        _, error = try_extract_text(b"raw", "pdf", output_kind="base64")
        assert error == "base64 output is not a string"


class TestUrlOutputs:
    def test_url_is_fetched_with_the_client(self, pdf_bytes):
        client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, content=pdf_bytes)))
        assert "Quarterly report" in extract_text("https://docs.test/r.pdf", "pdf", output_kind="url", http_client=client)

    def test_url_fetch_failure_is_reported(self):
        client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(404)))
        _, error = try_extract_text("https://docs.test/x.pdf", "pdf", output_kind="url", http_client=client)
        assert error.startswith("could not fetch https://docs.test/x.pdf")


class TestTextLikeKinds:
    def test_bytes_are_decoded_not_repr(self):
        # Before: str(b"hello") -> "b'hello'" leaked into every text scorer.
        assert extract_text(b"hello", "text") == "hello"

    def test_base64_markdown_is_decoded(self):
        assert extract_text(_b64(b"# Title\n**bold**"), "markdown", output_kind="base64") == "Title\nbold"

    def test_json_edge_cases(self):
        assert extract_text("not json", "json") == "not json"
        assert extract_text(5, "json") == "5"
        assert extract_text(b'{"a": 1}', "json") == '{\n  "a": 1\n}'

    def test_non_string_value_is_text(self):
        assert detect_content_type(12.5) == "text"
        assert extract_text(12.5) == "12.5"


class TestDetection:
    @pytest.mark.parametrize(("value", "kind", "expected"), [
        ("  %PDF-1.7 ...", "text", "pdf"),
        ("@@not base64@@", "base64", "text"),
        (_b64(b"plain words"), "base64", "text"),
        (b"plain bytes", "text", "text"),
        (bytearray(b"%PDF-"), "text", "pdf"),
        ([1, 2], "text", "json"),
    ])
    def test_detect(self, value, kind, expected):
        assert detect_content_type(value, kind) == expected

    def test_auto_headings_for_plain_text(self):
        assert parse_headings("Summary\nthis line is body text.") == ["Summary"]


class TestGoldenFiles:
    def test_pdf_and_docx_files_on_disk(self, tmp_path, pdf_bytes, docx_bytes):
        (tmp_path / "g.pdf").write_bytes(pdf_bytes)
        (tmp_path / "g.DOCX").write_bytes(docx_bytes)
        assert "Revenue grew" in load_golden_file("g.pdf", tmp_path)
        assert "Executive summary" in load_golden_file("g.DOCX", tmp_path)

    def test_data_urls_for_documents(self, tmp_path, pdf_bytes, docx_bytes):
        assert "Quarterly" in load_golden_file(f"data:application/pdf;base64,{_b64(pdf_bytes)}", tmp_path)
        assert "Widget" in load_golden_file(f"data:{_DOCX_CTYPE};base64,{_b64(docx_bytes)}", tmp_path)

    def test_data_url_with_charset_parameter(self, tmp_path):
        url = "data:text/plain;charset=utf-8;base64," + _b64("café".encode())
        assert load_golden_file(url, tmp_path) == "café"

    def test_spreadsheet_data_url_is_not_parsed_as_docx(self, tmp_path):
        ctype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        assert load_golden_file(f"data:{ctype};base64,{_b64(b'cells')}", tmp_path) == "cells"

    def test_unreadable_golden_document_raises(self, tmp_path):
        (tmp_path / "broken.pdf").write_bytes(b"%PDF-1.4 broken")
        with pytest.raises(ValueError, match="golden_file broken.pdf could not be read as PDF"):
            load_golden_file("broken.pdf", tmp_path)

    def test_invalid_base64_payload_raises(self, tmp_path):
        with pytest.raises(ValueError, match="invalid base64 payload"):
            load_golden_file("data:text/plain;base64,@@@", tmp_path)
