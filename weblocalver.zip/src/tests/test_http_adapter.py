"""Tests for the config-driven HTTP adapter: templating and request building."""

from __future__ import annotations

import json

import httpx

from adapters.http_adapter import HttpAdapter, _dotted, _resolve_template
from core.models import GoldenCase, ResponseMapping, TargetSpec
from core_helpers import capture_logs, mock_http_fixture  # noqa: F401

_BASE = "http://localhost:9999"


def _ok(request: httpx.Request) -> httpx.Response:
    return httpx.Response(200, json={"output": "ok"})


class TestResolveTemplate:
    def test_env_substitution(self, monkeypatch):
        monkeypatch.setenv("MY_TOKEN", "secret123")
        assert _resolve_template("Bearer ${env.MY_TOKEN}", {}) == "Bearer secret123"

    def test_input_substitution(self):
        assert _resolve_template("${input.query}", {"query": "hello"}) == "hello"

    def test_nested_input(self):
        assert _resolve_template("${input.data.topic}", {"data": {"topic": "finance"}}) == "finance"

    def test_dict_substitution(self, monkeypatch):
        monkeypatch.setenv("TEST_KEY", "val")
        result = _resolve_template({"key": "${env.TEST_KEY}", "q": "${input.query}"}, {"query": "hi"})
        assert result == {"key": "val", "q": "hi"}

    def test_no_template(self):
        assert _resolve_template("plain text", {}) == "plain text"

    def test_whole_string_placeholder_keeps_type(self):
        inp = {"n": 3, "filters": {"a": [1, 2]}, "flag": False}
        assert _resolve_template("${input.n}", inp) == 3
        assert _resolve_template("${input.filters}", inp) == {"a": [1, 2]}
        assert _resolve_template("${input.flag}", inp) is False

    def test_missing_value_becomes_empty_string(self):
        assert _resolve_template("${input.nope}", {}) == ""
        assert _resolve_template("q=${input.nope}!", {}) == "q=!"

    def test_embedded_non_string_is_json_encoded(self):
        assert _resolve_template("ids=${input.ids}", {"ids": [1, 2]}) == "ids=[1, 2]"
        assert _resolve_template("n=${input.n}", {"n": 4}) == "n=4"

    def test_bracket_paths(self):
        assert _resolve_template("${input.items[1].id}", {"items": [{"id": 1}, {"id": 2}]}) == 2


class TestDotted:
    def test_simple(self):
        assert _dotted({"a": 1}, "a") == 1

    def test_nested(self):
        assert _dotted({"a": {"b": {"c": 42}}}, "a.b.c") == 42

    def test_missing(self):
        assert _dotted({"a": 1}, "b") is None

    def test_list_index(self):
        assert _dotted({"items": [{"id": 1}, {"id": 2}]}, "items.1.id") == 2

    def test_bracket_index(self):
        assert _dotted({"items": [{"id": 1}, {"id": 2}]}, "items[1].id") == 2


class TestRequestBuilding:
    async def test_post_json_default_body(self, mock_http):
        """When body is not set, case.input is sent as JSON (back-compat)."""
        seen = mock_http(_ok)
        target = TargetSpec(adapter="http", endpoint="/test", response=ResponseMapping(output_path="output"))
        obs = await HttpAdapter(_BASE, "/test", target).run_case(GoldenCase(id="t1", input={"query": "hello"}))

        assert seen[0].method == "POST"
        assert json.loads(seen[0].content) == {"query": "hello"}
        assert obs.output == "ok"
        assert obs.error is None

    async def test_get_request_has_no_body_or_content_type(self, mock_http):
        seen = mock_http(_ok)
        target = TargetSpec(adapter="http", endpoint="/q", method="GET", body_type="text", body="x",
                            params={"q": "${input.query}"})
        await HttpAdapter(_BASE, "/q", target).run_case(GoldenCase(id="t1", input={"query": "hi"}))

        assert seen[0].content == b""
        assert "content-type" not in seen[0].headers
        assert seen[0].url.params["q"] == "hi"

    async def test_text_body_sets_text_plain(self, mock_http):
        seen = mock_http(_ok)
        target = TargetSpec(adapter="http", endpoint="/t", body_type="text", body="Q: ${input.q}")
        await HttpAdapter(_BASE, "/t", target).run_case(GoldenCase(id="t1", input={"q": "why"}))

        assert seen[0].headers["content-type"] == "text/plain"
        assert seen[0].content == b"Q: why"

    async def test_typed_json_body_template(self, mock_http):
        seen = mock_http(_ok)
        target = TargetSpec(adapter="http", endpoint="/t", body={"limit": "${input.limit}", "tag": "${input.x}"})
        await HttpAdapter(_BASE, "/t", target).run_case(GoldenCase(id="t1", input={"limit": 5}))

        assert json.loads(seen[0].content) == {"limit": 5, "tag": ""}

    async def test_auth_bearer(self, mock_http, monkeypatch):
        monkeypatch.setenv("TEST_TOKEN", "tok123")
        seen = mock_http(_ok)
        target = TargetSpec(adapter="http", endpoint="/test", auth={"type": "bearer", "token_env": "TEST_TOKEN"})
        await HttpAdapter(_BASE, "/test", target).run_case(GoldenCase(id="t1", input={"q": "x"}))

        assert seen[0].headers["authorization"] == "Bearer tok123"

    async def test_auth_api_key_query(self, mock_http, monkeypatch):
        monkeypatch.setenv("KEY_ENV", "k-1")
        seen = mock_http(_ok)
        target = TargetSpec(adapter="http", endpoint="/t",
                            auth={"type": "api_key_query", "token_env": "KEY_ENV", "param": "key"})
        await HttpAdapter(_BASE, "/t", target).run_case(GoldenCase(id="t1", input={}))

        assert seen[0].url.params["key"] == "k-1"

    async def test_unsupported_or_empty_auth_warns(self, mock_http, monkeypatch):
        monkeypatch.delenv("MISSING_TOKEN", raising=False)
        seen = mock_http(_ok)
        with capture_logs("eval_service.adapters.http") as records:
            for auth in ({"type": "oauth2"}, {"type": "bearer", "token_env": "MISSING_TOKEN"}):
                target = TargetSpec(adapter="http", endpoint="/t", auth=auth)
                await HttpAdapter(_BASE, "/t", target).run_case(GoldenCase(id="t1", input={}))

        assert all("authorization" not in r.headers for r in seen)
        messages = " ".join(r.getMessage() for r in records)
        assert "unsupported or empty auth type" in messages
        assert "MISSING_TOKEN" in messages

    async def test_error_handling(self, mock_http):
        mock_http(lambda request: httpx.Response(500, text="Internal Server Error"))
        target = TargetSpec(adapter="http", endpoint="/test")
        obs = await HttpAdapter(_BASE, "/test", target).run_case(GoldenCase(id="t1", input={"q": "test"}))

        assert obs.error.startswith("HTTP 500")

    async def test_transport_error_becomes_error_observation(self, mock_http):
        def _boom(request):
            raise httpx.ConnectError("refused")

        mock_http(_boom)
        obs = await HttpAdapter(_BASE, "/t").run_case(GoldenCase(id="t1", input={}))
        assert obs.error.startswith("Could not connect to the agent.")
        assert obs.error.endswith("(ConnectError: refused)")
