"""Tests for the JSON config-driven scorers (scorers/configurable_json.py)."""

from __future__ import annotations

import pytest

from scorer_helpers import obs, run

_ITEMS = {"data": {"items": [{"id": 42}]}}


class TestJsonPath:
    @pytest.mark.parametrize(("output", "config", "expected"), [
        ({"total": 8000}, {"path": "total", "op": "equals", "value": 8000}, 1.0),
        ({"total": 5000}, {"path": "total", "op": "equals", "value": 8000}, 0.0),
        ({"vendor": "Acme"}, {"path": "vendor", "op": "exists"}, 1.0),
        ({"a": 1}, {"path": "b.c", "op": "exists"}, 0.0),
        (_ITEMS, {"path": "data.items.0.id", "op": "equals", "value": 42}, 1.0),
        (_ITEMS, {"path": "data.items[0].id", "op": "equals", "value": 42}, 1.0),
        ("plain text", {"path": "a", "op": "exists"}, 0.0),
        ({"tags": ["x", "y"]}, {"path": "tags", "op": "contains", "value": "y"}, 1.0),
        ({"id": "INV-9"}, {"path": "id", "op": "regex", "value": r"INV-\d"}, 1.0),
    ])
    def test_ops(self, output, config, expected):
        assert run("json_path", obs(output), config=config)[0] == expected

    def test_exists_true_for_present_null(self):
        score, rationale, _ = run("json_path", obs({"note": None}), config={"path": "note", "op": "exists"})
        assert score == 1.0
        assert "exists" in rationale

    def test_equals_none_fails_when_missing(self):
        score, _, _ = run("json_path", obs({}), config={"path": "note", "op": "equals", "value": None})
        assert score == 0.0

    def test_unknown_op_is_config_error(self):
        score, rationale, _ = run("json_path", obs({"a": 1}), config={"path": "a", "op": "startswith"})
        assert score == 0.0
        assert rationale.startswith("config error: unknown op 'startswith'")


class TestFieldMatch:
    def test_all_fields_present(self):
        score, _, _ = run("field_match", obs({"vendor": "Acme", "total": 100, "currency": "USD"}), config={"fields": [
            {"name": "vendor", "op": "exists"},
            {"name": "total", "op": "type", "value": "number"},
            {"name": "currency", "op": "==", "value": "USD"},
        ]})
        assert score == 1.0

    def test_missing_field(self):
        score, _, _ = run("field_match", obs({"vendor": "Acme"}), config={"fields": [
            {"name": "vendor", "op": "exists"}, {"name": "total", "op": "exists"},
        ]})
        assert score == 0.5

    def test_contains_op(self):
        score, _, _ = run("field_match", obs({"items": ["apple", "banana"]}), config={"fields": [
            {"name": "items", "op": "contains", "value": "banana"},
        ]})
        assert score == 1.0

    def test_optional_field_does_not_dilute_score(self):
        score, _, _ = run("field_match", obs({"vendor": "Acme"}), config={"fields": [
            {"name": "vendor", "op": "exists", "required": True},
            {"name": "discount", "op": "exists", "required": False},
        ]})
        assert score == 1.0

    def test_nested_field_path(self):
        score, _, _ = run("field_match", obs({"line_items": [{"amount": 100}]}), config={"fields": [
            {"name": "line_items[0].amount", "op": "==", "value": 100},
        ]})
        assert score == 1.0

    @pytest.mark.parametrize(("op", "value", "expected"), [
        ("!=", "EUR", 1.0), ("in", ["USD", "GBP"], 1.0), ("in", "USD", 1.0),
        ("regex", "^U", 1.0), ("regex", "(", 0.0),
    ])
    def test_other_ops(self, op, value, expected):
        score, _, _ = run("field_match", obs({"currency": "USD"}), config={"fields": [
            {"name": "currency", "op": op, "value": value},
        ]})
        assert score == expected

    def test_bool_is_not_a_number(self):
        score, _, _ = run("field_match", obs({"total": True}), config={"fields": [
            {"name": "total", "op": "type", "value": "int"},
        ]})
        assert score == 0.0

    def test_unknown_op_reported_as_config_error(self):
        score, _, evidence = run("field_match", obs({"a": 1}), config={"fields": [{"name": "a", "op": "~="}]})
        assert score == 0.0
        assert "config error: unknown op '~='" in evidence[0]


_INVOICE_SCHEMA = {
    "type": "object",
    "required": ["vendor", "total"],
    "properties": {"vendor": {"type": "string"}, "total": {"type": "number"}, "items": {"type": "array"}},
}


class TestJsonSchemaValid:
    def test_valid_schema(self):
        score, _, _ = run("json_schema_valid", obs({"vendor": "Acme", "total": 100, "items": []}),
                          config={"schema": _INVOICE_SCHEMA})
        assert score == 1.0

    def test_missing_required(self):
        score, _, _ = run("json_schema_valid", obs({"vendor": "Acme"}),
                          config={"schema": {"type": "object", "required": ["vendor", "total"]}})
        assert score == 0.0

    def test_shortcut_required_types(self):
        score, _, _ = run("json_schema_valid", obs({"vendor": "Acme", "total": 100}),
                          config={"required": ["vendor", "total"], "types": {"total": "number"}})
        assert score == 1.0

    def test_shortcut_rejects_bool_for_number(self):
        score, _, _ = run("json_schema_valid", obs({"total": False}),
                          config={"required": ["total"], "types": {"total": "number"}})
        assert score == pytest.approx(0.5)

    def test_type_list(self):
        schema = {"type": "object", "properties": {"note": {"type": ["string", "null"]}}}
        assert run("json_schema_valid", obs({"note": None}), config={"schema": schema})[0] == 1.0
        assert run("json_schema_valid", obs({"note": 3}), config={"schema": schema})[0] == 0.0

    @pytest.mark.parametrize("stype", ["integer", "number"])
    def test_bool_rejected_for_numeric_types(self, stype):
        schema = {"type": "object", "properties": {"n": {"type": stype}}}
        score, _, errors = run("json_schema_valid", obs({"n": True}), config={"schema": schema})
        assert score == 0.0
        assert "expected" in errors[0]

    def test_unsupported_keyword_reported(self):
        schema = {"type": "object", "oneOf": [{"type": "object"}]}
        score, _, errors = run("json_schema_valid", obs({}), config={"schema": schema})
        assert score == 0.0
        assert any("unsupported schema keyword 'oneOf'" in e for e in errors)

    @pytest.mark.parametrize(("schema", "value", "ok"), [
        ({"enum": ["a", "b"]}, "a", True), ({"enum": ["a", "b"]}, "c", False),
        ({"type": "string", "pattern": "^INV-"}, "INV-1", True),
        ({"type": "string", "pattern": "^INV-"}, "X", False),
        ({"type": "string", "minLength": 2, "maxLength": 3}, "abcd", False),
        ({"type": "number", "minimum": 0, "maximum": 10}, 11, False),
        ({"type": "array", "minItems": 1}, [], False),
        ({"type": "array", "maxItems": 1, "items": {"type": "integer"}}, [1], True),
        ({"const": 5}, 5, True),
    ])
    def test_simple_keywords(self, schema, value, ok):
        full = {"type": "object", "properties": {"v": schema}}
        assert run("json_schema_valid", obs({"v": value}), config={"schema": full})[0] == float(ok)

    def test_additional_properties_false(self):
        schema = {"type": "object", "properties": {"a": {}}, "additionalProperties": False}
        score, _, errors = run("json_schema_valid", obs({"a": 1, "b": 2}), config={"schema": schema})
        assert score == 0.0
        assert ".b: additional property not allowed" in errors
