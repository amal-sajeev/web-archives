"""Bundle inspection: manifest discovery, config errors in plain words, file items, custom tests."""

from __future__ import annotations

import yaml
import pytest

from core.playground import bundle, inspect_bundle
from test_playground import _AGENT_YAML, _DATASET
from test_playground_archive import _BASE, make_zip

_NOT_UTF8 = bytes([0xFF, 0xFE, 0xFA])
_BOM = chr(0xFEFF)


class TestManifestDiscovery:
    def test_no_agent_yaml(self):
        with pytest.raises(ValueError, match="No agent.yaml was found"):
            inspect_bundle(make_zip({"readme.md": "hi"}))

    def test_several_agent_yaml_files_are_listed(self):
        blob = make_zip({"a/agent.yaml": _AGENT_YAML, "b/agent.yaml": _AGENT_YAML}, root="")
        with pytest.raises(ValueError, match=r"contains 2 agent.yaml files \(a/agent.yaml, b/agent.yaml\)"):
            inspect_bundle(blob)


class TestConfigErrors:
    def test_yaml_syntax_error_names_the_line(self):
        with pytest.raises(ValueError, match="agent.yaml is invalid: line 2: mapping values are not allowed here"):
            inspect_bundle(make_zip({**_BASE, "agent.yaml": "agent_id: demo\nname: a: b\n"}))

    def test_missing_field_is_named(self):
        with pytest.raises(ValueError, match="agent.yaml is invalid: agent_id: Field required"):
            inspect_bundle(make_zip({**_BASE, "agent.yaml": "name: Demo\n"}))

    def test_wrong_top_level_shape(self):
        with pytest.raises(ValueError, match="agent.yaml is invalid: Input should be a valid dictionary"):
            inspect_bundle(make_zip({**_BASE, "agent.yaml": "- a\n- b\n"}))

    def test_missing_dataset(self):
        files = {k: v for k, v in _BASE.items() if k != "dataset.json"}
        with pytest.raises(ValueError, match="Configured dataset file is missing: dataset.json"):
            inspect_bundle(make_zip(files))

    def test_dataset_json_error_names_the_line(self):
        with pytest.raises(ValueError, match="Dataset is invalid: line 1: "):
            inspect_bundle(make_zip({**_BASE, "dataset.json": "{broken"}))

    def test_dataset_not_utf8(self):
        with pytest.raises(ValueError, match="Dataset is invalid: the file is not UTF-8 text"):
            inspect_bundle(make_zip({**_BASE, "dataset.json": _NOT_UTF8}))

    def test_dot_slash_dataset_path_is_accepted(self):
        """Regression: ``dataset_file: ./dataset.json`` works on disk but was reported missing."""
        cfg = _AGENT_YAML.replace("dataset_file: dataset.json", "dataset_file: ./dataset.json")
        assert inspect_bundle(make_zip({**_BASE, "agent.yaml": cfg}))["dataset"]["dataset_id"] == "demo-data"

    def test_stub_metrics_source_requires_the_stub_file(self):
        files = {k: v for k, v in _BASE.items() if k != "metrics_stub.json"}
        files["agent.yaml"] = _AGENT_YAML + "metrics_source: STUB\n"
        with pytest.raises(ValueError, match="metrics stub file is missing: metrics_stub.json"):
            inspect_bundle(make_zip(files))

    def test_stub_file_optional_for_other_sources(self):
        files = {k: v for k, v in _BASE.items() if k != "metrics_stub.json"}
        assert inspect_bundle(make_zip(files))["agent"]["agent_id"] == "demo"

    def test_yaml_error_without_position_falls_back_to_text(self):
        assert bundle._describe_error(yaml.YAMLError("boom")) == "boom"


class TestFileItems:
    def test_text_binary_and_undecodable_files(self):
        blob = make_zip({**_BASE, "logo.png": bytes([137, 80, 78, 71]), "notes.txt": _NOT_UTF8,
                         "bom.md": _BOM + "hello"})
        items = {f["path"]: f for f in inspect_bundle(blob)["files"]}
        assert items["logo.png"]["kind"] == "binary" and items["logo.png"]["content"] == "iVBORw=="
        assert items["notes.txt"]["encoding"] == "base64"
        assert items["bom.md"] == {"path": "bom.md", "size": 8, "encoding": "utf-8", "kind": "text", "content": "hello"}
        assert items["dataset.json"]["content"] == _DATASET


class TestCustomTests:
    def test_all_decorator_spellings_are_discovered(self):
        source = (
            "import scorers, functools\n"
            "from scorers import scorer\n"
            "@scorer('positional')\ndef a(*_): ...\n"
            "@scorer(name='keyword', judge=True)\nasync def b(*_): ...\n"
            "@scorers.scorer('attribute')\ndef c(*_): ...\n"
            "@functools.lru_cache\n@other('ignored')\n@scorer(NAME)\ndef d(*_): ...\n"
        )
        info = inspect_bundle(make_zip({**_BASE, "custom_tests.py": source}))["custom_tests"]
        assert info["declared_scorers"] == ["attribute", "keyword", "positional"]

    def test_absent_custom_tests_has_no_warnings(self):
        result = inspect_bundle(make_zip(_BASE))
        assert result["custom_tests"]["present"] is False and result["warnings"] == []

    def test_non_utf8_custom_tests_is_reported_not_crashing(self):
        """Regression: a Latin-1 custom_tests.py made inspect fail with a raw codec error."""
        result = inspect_bundle(make_zip({**_BASE, "custom_tests.py": _NOT_UTF8}))
        assert result["custom_tests"]["syntax_error"] == "the file is not UTF-8 text"
        assert "custom_tests.py syntax error: the file is not UTF-8 text" in result["warnings"]
