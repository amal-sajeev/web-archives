"""Core edge cases: case selection, result validation, failure reporting, previews."""

from __future__ import annotations

import math

import pytest

from core import run_events
from core.labels import LabelStore
from core.metric_scoring import parse_result
from core.models import HumanLabel, MetricSpec, Observation
from core.runner import Runner, _select_cases
from core_helpers import InMemoryRepo, StubTarget, capture_logs, make_dataset, make_registry, patch_runner_io
from scorers.base import restore_scorers, scorer, snapshot_scorers


@pytest.fixture(autouse=True)
def _isolated_scorers():
    snap = snapshot_scorers()
    yield
    restore_scorers(snap)


def _spec(name: str, scorer_name: str) -> MetricSpec:
    return MetricSpec(name=name, type="deterministic", scorer=scorer_name)


class TestCaseSelection:
    def test_empty_selection_is_rejected(self):
        with pytest.raises(ValueError, match="At least one case must be selected"):
            _select_cases(make_dataset([_spec("m", "contains")]), [])

    def test_selected_ids_keep_dataset_order(self):
        from core.models import GoldenCase

        cases = [GoldenCase(id=f"c{i}", input={}) for i in range(3)]
        dataset = make_dataset([_spec("m", "contains")], cases)
        assert [c.id for c in _select_cases(dataset, ["c2", "c0"])] == ["c0", "c2"]

    def test_unknown_ids_are_named(self):
        with pytest.raises(ValueError, match="Unknown case id\\(s\\): nope"):
            _select_cases(make_dataset([_spec("m", "contains")]), ["c1", "nope"])


class TestParseResult:
    @pytest.mark.parametrize(("result", "exc", "message"), [
        ((1.0, "r"), ValueError, "3- or 4-tuple"),
        ((1.0, "r", [], "extras"), TypeError, "extras must be a dict"),
        ((1.0, "r", "evidence"), TypeError, "evidence must be a list"),
        ((1.0, "r", [], {"raw_value": math.nan}), ValueError, "extras.raw_value is NaN"),
    ])
    def test_malformed_results_are_rejected(self, result, exc, message):
        with pytest.raises(exc, match=message):
            parse_result(result)

    def test_display_value_falls_through_to_measured_or_ignores_junk(self):
        assert parse_result((1.0, None, (), {"measured": "7"})).display_value == 7.0
        out = parse_result((1.0, None, (), {"measured": "lots"}))
        assert out.display_value is None
        assert out.rationale == ""


class TestFailureReporting:
    async def test_scorer_crash_is_a_prefixed_skip(self, monkeypatch):
        @scorer("t_crash")
        def _crash(**_):
            raise KeyError("config")

        patch_runner_io(monkeypatch)
        run = await Runner(make_registry(make_dataset([_spec("m", "t_crash")])), InMemoryRepo()).evaluate("t")
        skipped = run.case_results[0].skipped[0]
        assert skipped.reason == "Scorer error: KeyError: 'config'"

    async def test_run_done_emit_failure_does_not_mask_the_error(self, monkeypatch):
        class _Exploding(StubTarget):
            async def run_case(self, case):
                raise RuntimeError("agent down")

        async def progress(event):
            if event["type"] == "run_done":
                raise OSError("client went away")

        patch_runner_io(monkeypatch, target=_Exploding())
        repo = InMemoryRepo()
        with capture_logs("eval_service.runner") as records, pytest.raises(RuntimeError, match="agent down"):
            await Runner(make_registry(make_dataset([_spec("m", "contains")])), repo).evaluate("t", progress=progress)
        assert next(iter(repo.runs.values())).status == "ERROR"
        assert any(r.getMessage() == "run_done_emit_failed" for r in records)

    async def test_observation_error_is_logged(self, monkeypatch):
        class _Failing(StubTarget):
            async def run_case(self, case):
                return Observation(target_id="t", error="HTTP 500: boom")

        patch_runner_io(monkeypatch, target=_Failing())
        with capture_logs("eval_service.runner") as records:
            await Runner(make_registry(make_dataset([_spec("m", "contains")])), InMemoryRepo()).evaluate("t")
        assert any(r.getMessage() == "observation_error" for r in records)


def test_output_preview_falls_back_to_str(monkeypatch):
    def _boom(value):
        raise ValueError("circular")

    monkeypatch.setattr(run_events, "render_output_text", _boom)
    assert run_events.output_preview({"a": 1}) == "{'a': 1}"


def test_label_store_clear():
    store = LabelStore()
    store.add(HumanLabel(case_id="c", verdict="pass", agent_id="a"))
    store.clear()
    assert store.verdict_map() == {}
