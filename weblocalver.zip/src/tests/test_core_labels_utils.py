"""Label store, text-PDF builder, git fallback and the shared HTTP client kwargs."""

from __future__ import annotations

import re
import subprocess

import pytest

import utils
from core.config import Config
from core.labels import LabelStore
from core.models import HumanLabel
from core_helpers import capture_logs
from service.http_client import build_async_client_kwargs


class TestLabelStore:
    def test_labels_are_keyed_by_agent_and_case(self):
        store = LabelStore()
        store.add(HumanLabel(case_id="c1", verdict="pass", agent_id="a"))
        store.add(HumanLabel(case_id="c1", verdict="fail", agent_id="b"))
        assert store.verdict_map(agent_id="a") == {"c1": "pass"}
        assert store.verdict_map(agent_id="b") == {"c1": "fail"}
        assert store.get("c1", agent_id="a").verdict == "pass"
        assert len(store.all()) == 2 and len(store.all(agent_id="b")) == 1

    def test_unscoped_get_returns_latest(self):
        store = LabelStore()
        store.add(HumanLabel(case_id="c1", verdict="pass", agent_id="a", created_at="2026-01-01"))
        store.add(HumanLabel(case_id="c1", verdict="fail", agent_id="b", created_at="2026-02-01"))
        assert store.get("c1").verdict == "fail"
        assert store.get("missing") is None

    def test_store_is_bounded(self):
        store = LabelStore(max_labels=2)
        for i in range(4):
            store.add(HumanLabel(case_id=f"c{i}", verdict="pass"))
        assert set(store.verdict_map()) == {"c2", "c3"}


def _page_count(pdf: bytes) -> int:
    return int(re.search(rb"/Type /Pages /Kids \[[^\]]*\] /Count (\d+)", pdf).group(1))


class TestTextPdf:
    def test_escapes_backslash_before_parens(self):
        pdf = utils.build_text_pdf([r"a\b (c)"])
        assert rb"(a\\b \(c\)) Tj" in pdf

    def test_truncates_before_escaping(self):
        line = "x" * 199 + "(" + "y" * 10
        pdf = utils.build_text_pdf([line])
        assert ("(" + "x" * 199 + "\\() Tj").encode() in pdf

    def test_paginates_long_reports(self):
        assert _page_count(utils.build_text_pdf(["line"] * 10)) == 1
        assert _page_count(utils.build_text_pdf(["line"] * 100)) == 3
        assert _page_count(utils.build_text_pdf([])) == 1

    def test_plain_string_is_split_into_lines_not_characters(self):
        pdf = utils.build_text_pdf("first line\nsecond")
        assert b"(first line) Tj" in pdf
        assert b"(second) Tj" in pdf

    def test_pdf_structure_is_well_formed(self):
        pdf = utils.build_text_pdf(["hello"] * 60)
        assert pdf.startswith(b"%PDF-1.4") and pdf.endswith(b"%%EOF")
        assert pdf.count(b"/Type /Page ") == 2


class TestStaticFallback:
    def test_git_fallback_uses_resolved_path_and_timeout(self, monkeypatch, tmp_path):
        captured = {}

        def fake_run(argv, **kwargs):
            captured["argv"], captured["timeout"] = argv, kwargs.get("timeout")
            return subprocess.CompletedProcess(argv, 0, stdout="<html/>")

        def deny(*_a, **_kw):
            raise PermissionError("locked")

        monkeypatch.setattr(Config, "STATIC_DIR", tmp_path)
        monkeypatch.setattr(type(tmp_path), "read_text", deny)
        monkeypatch.setattr(utils.shutil, "which", lambda name: "/usr/bin/git")
        monkeypatch.setattr(utils.subprocess, "run", fake_run)
        assert utils.load_static_text("index.html") == "<html/>"
        assert captured["argv"][0] == "/usr/bin/git"
        assert captured["timeout"] == utils._GIT_TIMEOUT_SECONDS

    def test_no_git_reraises_permission_error(self, monkeypatch, tmp_path):
        def deny(*_a, **_kw):
            raise PermissionError("locked")

        monkeypatch.setattr(Config, "STATIC_DIR", tmp_path)
        monkeypatch.setattr(type(tmp_path), "read_text", deny)
        monkeypatch.setattr(utils.shutil, "which", lambda name: None)
        with pytest.raises(PermissionError):
            utils.load_static_text("index.html")


class TestHttpClientKwargs:
    def test_tls_disabled_logs_warning(self, monkeypatch):
        monkeypatch.setattr(Config, "EXCLUDE_TLS", True)
        with capture_logs("eval_service.http_client") as records:
            kwargs = build_async_client_kwargs(timeout=5)
        assert kwargs["verify"] is False
        assert any("verification is disabled" in r.getMessage() for r in records)

    def test_tls_enabled_has_no_verify_override(self, monkeypatch):
        monkeypatch.setattr(Config, "EXCLUDE_TLS", False)
        assert "verify" not in build_async_client_kwargs(timeout=5, trust_env=True)
