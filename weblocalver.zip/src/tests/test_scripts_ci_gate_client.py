"""Tests for scripts/ci_gate_client.py, driven through httpx.MockTransport (no network)."""

from __future__ import annotations

import sys
from collections.abc import Callable
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))

import ci_gate_client as gc

BASE = "http://svc"
Handler = Callable[[httpx.Request], httpx.Response]


def _client(handler: Handler, logs: list[str] | None = None) -> gc.EvalClient:
    http = httpx.Client(base_url=BASE, transport=httpx.MockTransport(handler))
    log = logs.append if logs is not None else gc._noop
    return gc.EvalClient(BASE + "/", poll_interval=0, log=log, client=http)


def _scripted(responses: list[httpx.Response | Exception]) -> tuple[Handler, list[httpx.Request]]:
    """A handler that replays ``responses`` in order and records the requests."""
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        item = responses.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    return handler, seen


class TestHealth:
    def test_returns_body(self):
        client = _client(lambda r: httpx.Response(200, json={"status": "ok"}))
        assert client.check_health() == {"status": "ok"}

    def test_http_status_names_the_code_and_the_likely_cause(self):
        client = _client(lambda r: httpx.Response(404, text="nope"))
        with pytest.raises(gc.GateError, match=r"HTTP 404.*--eval-url"):
            client.check_health()

    def test_unreachable(self):
        def boom(request):
            raise httpx.ConnectError("refused", request=request)

        with pytest.raises(gc.GateError, match="unreachable at http://svc: refused"):
            _client(boom).check_health()

    def test_non_json_body_is_a_gate_error(self):
        client = _client(lambda r: httpx.Response(200, text="<html>proxy login</html>"))
        with pytest.raises(gc.GateError, match="is not JSON"):
            client.check_health()

    def test_non_object_json_is_a_gate_error(self):
        client = _client(lambda r: httpx.Response(200, json=[1, 2]))
        with pytest.raises(gc.GateError, match="unexpected response"):
            client.check_health()


class TestStart:
    def test_posts_payload_and_returns_stream_id(self):
        handler, seen = _scripted([httpx.Response(202, json={"stream_id": 42})])
        assert _client(handler).start("agent-a", 3) == "42"
        assert seen[0].url.path == gc.START_PATH
        body = seen[0].read().decode()
        assert '"agent_id":"agent-a"' in body.replace(" ", "")
        assert '"created_by":"CI_CD"' in body.replace(" ", "")

    def test_http_error_includes_status_and_body(self):
        client = _client(lambda r: httpx.Response(422, text="judge_repetitions too high"))
        with pytest.raises(gc.GateError, match="HTTP 422 judge_repetitions too high"):
            client.start("a", 9)

    def test_transport_error(self):
        def boom(request):
            raise httpx.ReadTimeout("slow", request=request)

        with pytest.raises(gc.GateError, match="start failed: slow"):
            _client(boom).start("a", 1)

    def test_missing_stream_id(self):
        client = _client(lambda r: httpx.Response(200, json={"ok": True}))
        with pytest.raises(gc.GateError, match="no stream_id"):
            client.start("a", 1)


class TestWaitForRunId:
    def test_retries_transport_errors_and_tracks_seq(self):
        req = httpx.Request("GET", BASE)
        handler, seen = _scripted([
            httpx.ConnectError("blip", request=req),
            httpx.Response(200, json={"events": [{"type": "case_done"}, "junk"], "seq": 5, "done": False}),
            httpx.Response(200, json={"events": [{"type": "run_done"}], "done": True, "run_id": "r1"}),
        ])
        logs: list[str] = []
        assert _client(handler, logs).wait_for_run_id("s1", timeout=30) == "r1"
        assert [r.url.params["after"] for r in seen] == ["0", "0", "5"]
        assert seen[0].url.path == "/api/evaluate/stream/s1/events"
        assert logs == ["poll error (retrying): blip", "event: case_done", "event: run_done"]

    def test_missing_seq_advances_by_event_count(self):
        handler, seen = _scripted([
            httpx.Response(200, json={"events": [{"type": "a"}, {"type": "b"}], "seq": None}),
            httpx.Response(200, json={"events": None, "done": True, "run_id": 7}),
        ])
        assert _client(handler).wait_for_run_id("s", timeout=30) == "7"
        assert seen[1].url.params["after"] == "2"

    def test_failed_run_reports_the_failure_event(self):
        events = [
            {"type": "run_started"},
            {"type": "run_failed", "detail": "adapter blew up", "error_type": "ValueError", "error_id": "e-1"},
        ]
        client = _client(lambda r: httpx.Response(200, json={"events": events, "done": True}))
        with pytest.raises(gc.GateError, match="run_failed: adapter blew up error_type=ValueError error_id=e-1"):
            client.wait_for_run_id("s", timeout=30)

    def test_poll_http_error_is_fatal(self):
        client = _client(lambda r: httpx.Response(404, json={"detail": "unknown stream"}))
        with pytest.raises(gc.GateError, match="events poll failed: HTTP 404"):
            client.wait_for_run_id("s", timeout=30)

    def test_timeout(self):
        client = _client(lambda r: pytest.fail("must not poll after the deadline"))
        with pytest.raises(gc.GateError, match=r"timed out after 0s \(stream s\)"):
            client.wait_for_run_id("s", timeout=0)


class TestFailureMessage:
    def test_bare_type_when_no_detail(self):
        assert gc._failure_message([{"type": "run_cancelled"}]) == "run_cancelled"

    def test_message_used_when_no_detail(self):
        assert gc._failure_message([{"type": "run_cancelled", "message": "user"}]) == "run_cancelled: user"

    def test_no_failure_event(self):
        assert gc._failure_message([{"type": "run_done"}]) == "stream finished without a run_id"


class TestGetRunAndCompletion:
    def test_get_run_http_error(self):
        client = _client(lambda r: httpx.Response(404, json={"detail": "no"}))
        with pytest.raises(gc.GateError, match="could not fetch run r9"):
            client.get_run("r9")

    def test_run_to_completion_end_to_end(self):
        handler, seen = _scripted([
            httpx.Response(202, json={"stream_id": "s1"}),
            httpx.Response(200, json={"events": [], "seq": 0, "done": True, "run_id": "r1"}),
            httpx.Response(200, json={"run_id": "r1", "status": "PASS"}),
        ])
        logs: list[str] = []
        with _client(handler, logs) as client:
            assert client.run_to_completion("a", 1, timeout=30) == {"run_id": "r1", "status": "PASS"}
        assert seen[-1].url.path == "/api/runs/r1"
        assert logs[0] == "evaluation started: stream_id=s1"
        assert logs[-1].endswith("run_id=r1")


def test_default_client_and_negative_poll_interval_are_safe():
    client = gc.EvalClient("http://localhost:1/", poll_interval=-3)
    assert client._poll_interval == 0.0
    assert str(client._client.base_url) == "http://localhost:1"
    client.close()
