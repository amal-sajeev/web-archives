"""Handler tests: run listing (keyset cursor + counts), compare, get, export, promote."""

from __future__ import annotations

import csv
import io
from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException

from handlers.runs import (
    _change_text,
    compare_runs,
    decode_cursor,
    encode_cursor,
    export_run,
    get_run,
    list_runs,
    promote_baselines,
)


def _ts(day: int) -> str:
    return datetime(2026, 1, day, tzinfo=UTC).isoformat()


def test_list_runs_fetches_limit_plus_one_and_builds_cursor():
    repo = MagicMock()
    repo.list_runs.return_value = [
        {"run_id": "r3", "creation_ts": _ts(3)},
        {"run_id": "r2", "creation_ts": _ts(2)},
        {"run_id": "r1", "creation_ts": _ts(1)},
    ]

    result = list_runs(repo, limit=2)

    assert repo.list_runs.call_args.kwargs["limit"] == 3
    assert [r["run_id"] for r in result["runs"]] == ["r3", "r2"]
    assert decode_cursor(result["next_cursor"]) == (_ts(2), "r2")
    repo.get_run.assert_not_called()  # no N+1


def test_list_runs_last_page_has_no_cursor():
    repo = MagicMock()
    repo.list_runs.return_value = [{"run_id": "r1", "creation_ts": _ts(1)}]
    assert list_runs(repo, limit=2)["next_cursor"] is None


def test_list_runs_passes_decoded_cursor_to_repo():
    repo = MagicMock()
    repo.list_runs.return_value = []

    list_runs(repo, before=encode_cursor(_ts(2), "r2"), status="PASS")

    kwargs = repo.list_runs.call_args.kwargs
    assert (kwargs["before"], kwargs["before_id"], kwargs["status"]) == (_ts(2), "r2", "PASS")


def test_cursor_is_url_safe_and_legacy_timestamp_accepted():
    cursor = encode_cursor("2026-01-01T00:00:00.000+00:00", "abc")
    assert all(ch.isalnum() or ch in "-_" for ch in cursor)
    assert decode_cursor("2026-01-01T00:00:00+00:00") == ("2026-01-01T00:00:00+00:00", None)


def test_list_runs_paginates_real_repo_with_ties_and_counts(sqlite_repo, make_run):
    same_ts = _ts(5)
    for rid in ("a", "b", "c"):
        sqlite_repo.save_run(make_run(rid, creation_ts=same_ts, cases=[("c1", True, 0.9), ("c2", False, 0.1)]))
    sqlite_repo.save_run(make_run("old", creation_ts=_ts(1), cases=[("c1", True, 0.9)]))

    seen, cursor = [], None
    while True:
        page = list_runs(sqlite_repo, limit=2, before=cursor)
        seen.extend(page["runs"])
        cursor = page["next_cursor"]
        if cursor is None:
            break

    assert [r["run_id"] for r in seen] == ["c", "b", "a", "old"]
    assert (seen[0]["case_count"], seen[0]["passed_case_count"]) == (2, 1)
    assert (seen[-1]["case_count"], seen[-1]["passed_case_count"]) == (1, 1)


def test_compare_runs_shared_shape(sqlite_repo, make_run):
    sqlite_repo.save_run(make_run("ra", score=0.5, cases=[("c1", False, 0.5), ("only_a", True, 0.9)]))
    sqlite_repo.save_run(make_run("rb", score=0.9, cases=[("c1", True, 0.9)]))

    result = compare_runs(sqlite_repo, "ra", "rb")

    assert result["a"]["run_id"] == "ra"
    assert result["winner"] == "b"
    assert result["score_diff"] == pytest.approx(0.4)
    rows = {c["case_id"]: c for c in result["cases"]}
    assert rows["c1"]["improved"] is True
    assert rows["c1"]["winner"] == "b"
    assert rows["only_a"]["b"] is None
    assert rows["only_a"]["winner"] is None


def test_compare_runs_rejects_same_run():
    with pytest.raises(HTTPException) as exc_info:
        compare_runs(MagicMock(), "x", "x")
    assert exc_info.value.status_code == 400


def test_compare_runs_missing_404(sqlite_repo):
    with pytest.raises(HTTPException) as exc_info:
        compare_runs(sqlite_repo, "nope-a", "nope-b")
    assert exc_info.value.status_code == 404


def test_get_run_returns_and_404(sqlite_repo, make_run):
    sqlite_repo.save_run(make_run("r1"))
    assert get_run(sqlite_repo, "r1")["run_id"] == "r1"
    with pytest.raises(HTTPException) as exc_info:
        get_run(sqlite_repo, "unknown")
    assert exc_info.value.status_code == 404


def _run_with_scores(rationale, baseline=0.8):
    return SimpleNamespace(
        run_id="12345678abc", agent_id="a", dataset_id="d", dataset_version="1",
        weighted_score=0.9, weighted_delta=0.1, status="PASS", creation_ts=_ts(1), created_by="DEVELOPER",
        case_results=[SimpleNamespace(
            case_id="c1", passed=True, weighted_score=0.9, weighted_delta=0.1,
            scores=[SimpleNamespace(metric="m1", score=0.9, threshold=0.8, passed=True,
                                    critical=False, rationale=rationale, baseline=baseline)],
        )],
    )


def test_export_run_csv():
    repo = MagicMock()
    repo.get_run.return_value = _run_with_scores("ok")

    result = export_run(repo, "12345678abc", "csv")

    assert result.media_type == "text/csv"
    assert "run_12345678.csv" in result.headers["content-disposition"]
    assert b"m1" in result.body


def _csv_rows(run):
    repo = MagicMock()
    repo.get_run.return_value = run
    return list(csv.DictReader(io.StringIO(export_run(repo, "12345678abc", "csv").body.decode())))


def test_export_run_csv_keeps_old_columns_and_adds_raw_change_numbers():
    repo = MagicMock()
    repo.get_run.return_value = _run_with_scores("ok")
    header = export_run(repo, "12345678abc", "csv").body.decode().splitlines()[0].split(",")

    assert header[:10] == [
        "case_id", "case_status", "weighted_score", "weighted_delta",
        "metric", "score", "threshold", "passed_metric", "critical", "rationale",
    ]
    assert header[10:] == ["case_baseline_score", "case_change_pct", "baseline", "change_pct"]
    row = _csv_rows(_run_with_scores("ok"))[0]
    assert (row["weighted_score"], row["weighted_delta"]) == ("0.9", "0.1")
    assert (row["case_baseline_score"], row["case_change_pct"]) == ("0.8", "12.5")
    assert (row["score"], row["baseline"], row["change_pct"]) == ("0.9", "0.8", "12.5")


def test_export_run_csv_leaves_change_blank_without_a_usable_baseline():
    row = _csv_rows(_run_with_scores("ok", baseline=None))[0]
    assert (row["case_baseline_score"], row["case_change_pct"], row["baseline"], row["change_pct"]) == ("", "", "", "")
    zero = _csv_rows(_run_with_scores("ok", baseline=0.0))[0]
    assert (zero["baseline"], zero["change_pct"]) == ("0.0", "")


def test_export_run_pdf_prints_relative_change_and_values():
    repo = MagicMock()
    repo.get_run.return_value = _run_with_scores("ok")

    body = export_run(repo, "12345678abc", "pdf").body

    assert b"Vs baseline: +12.5%" in body
    assert b"vs baseline: +12.5%" in body
    assert b"->" not in body
    assert b"pts" not in body and b"Delta" not in body


@pytest.mark.parametrize(("current", "baseline", "expected"), [
    (0.79, 0.96, "-17.7%"),
    (0.74, 0.69, "+7.2%"),
    (0.96, 0.96, "Unchanged"),
    (0.45, 0.0, "Up from 0%"),
    (0.5, None, "No baseline"),
    (0.792, 0.794, "-0.3%"),
    (0.9994, 1.0, "-0.1%"),
])
def test_change_text_matches_ui_rules(current, baseline, expected):
    assert _change_text(current, baseline) == expected


def test_export_run_pdf_tolerates_null_rationale():
    repo = MagicMock()
    repo.get_run.return_value = _run_with_scores(None)

    result = export_run(repo, "12345678abc", "pdf")

    assert result.media_type == "application/pdf"
    assert result.body.startswith(b"%PDF")


def test_export_run_unknown_format_400():
    repo = MagicMock()
    repo.get_run.return_value = _run_with_scores("ok")
    with pytest.raises(HTTPException) as exc_info:
        export_run(repo, "12345678abc", "xml")
    assert exc_info.value.status_code == 400


def test_promote_baselines_persists_mean(sqlite_repo, make_run):
    sqlite_repo.save_run(make_run("r1", cases=[("c1", True, 0.8), ("c2", True, 1.0)]))

    result = promote_baselines(sqlite_repo, "r1", MagicMock())

    assert result["promoted"] == [{"metric": "m1", "baseline": 0.9, "samples": 2}]
    assert sqlite_repo.get_baseline("agent-1", "ds-1", "1", "m1") == pytest.approx(0.9)
