"""Integration tests for Runner.evaluate with an in-memory repo + stub adapters.

Exercises the orchestration offline: target replay -> metrics -> scorers ->
gate -> persisted RunRecord. The LLM judge is monkeypatched at build_judge so no
Vertex call happens; deterministic scorers run for real.
"""

from __future__ import annotations

import pytest

from core.models import Dataset, GoldenCase, MetricSpec
from core.runner import Runner
from core_helpers import InMemoryRepo, make_registry, patch_runner_io
from scorers.vertex import JudgeVerdict


class FakeJudge:
    def invoke(self, prompt):
        return JudgeVerdict(score=0.95, passed=False, rationale="ok", evidence=[])


@pytest.fixture
def registry_with_dataset():
    dataset = Dataset(
        dataset_id="t", version="v1",
        metrics=[
            MetricSpec(name="tool_selection", type="deterministic", scorer="tool_selection",
                       weight=2.0, threshold=1.0),
            MetricSpec(name="faithfulness", type="llm_judge", scorer="faithfulness",
                       weight=3.0, threshold=0.8),
        ],
        cases=[GoldenCase(
            id="app_single_unit",
            input={"query": "Get AppCatalog data for AU-10001 at Acme Corp."},
            golden_output="AU-10001 Acme Corp inventory",
            expected={"expected_tool": "get_application_data", "expected_values": ["AU-10001", "Acme Corp"]},
            baseline_metrics={"tool_selection": 1.0, "faithfulness": 0.9},
        )],
    )
    return make_registry(dataset)


async def test_runner_end_to_end_with_mocked_judge(registry_with_dataset, monkeypatch):
    monkeypatch.setattr("scorers.llm_judge.build_judge", lambda: FakeJudge())
    patch_runner_io(monkeypatch)

    repo = InMemoryRepo()
    events = []

    async def progress(event):
        events.append(event)

    run = await Runner(registry_with_dataset, repo).evaluate("t", created_by="CI_CD", progress=progress)

    assert run.run_id in repo.runs
    assert run.status == "PASS"
    assert run.created_by == "CI_CD"
    faith = next(s for s in run.case_results[0].scores if s.metric == "faithfulness")
    # Pass is re-applied in code from the score, not trusted from the model.
    assert faith.score == pytest.approx(0.95)
    assert faith.passed is True
    types = [e["type"] for e in events]
    assert types[0] == "run_started" and types[-1] == "run_done"
    started = events[0]["metrics"]
    assert {m["name"]: m["judge"] for m in started} == {"tool_selection": False, "faithfulness": True}


async def test_runner_skips_judge_when_unavailable(registry_with_dataset, monkeypatch):
    def _raise():
        raise RuntimeError("no ADC")

    monkeypatch.setattr("scorers.llm_judge.build_judge", _raise)
    patch_runner_io(monkeypatch)

    run = await Runner(registry_with_dataset, InMemoryRepo()).evaluate("t")
    case = run.case_results[0]
    # Judge metric omitted (skipped, recorded) but the deterministic one remains.
    assert {s.metric for s in case.scores} == {"tool_selection"}
    assert [s.metric for s in case.skipped] == ["faithfulness"]
    assert case.skipped[0].judge is True
    assert run.status == "PASS"


async def test_runner_persists_error_status_on_failure(registry_with_dataset, monkeypatch):
    class ExplodingTarget:
        async def run_case(self, case):
            raise RuntimeError("agent call blew up")

    patch_runner_io(monkeypatch, target=ExplodingTarget())
    repo = InMemoryRepo()

    with pytest.raises(RuntimeError, match="agent call blew up"):
        await Runner(registry_with_dataset, repo).evaluate("t", created_by="DEVELOPER")

    errored_run = next(iter(repo.runs.values()))
    assert errored_run.created_by == "DEVELOPER"
    assert errored_run.status == "ERROR"
    assert errored_run.error_detail == "RuntimeError: agent call blew up"


async def test_runner_only_applies_metrics_listed_in_case_baseline(registry_with_dataset, monkeypatch):
    """A case opts into metrics via baseline_metrics keys only."""
    registry_with_dataset.get("t").dataset.cases[0].baseline_metrics = {"tool_selection": 1.0}
    monkeypatch.setattr("scorers.llm_judge.build_judge", lambda: FakeJudge())
    patch_runner_io(monkeypatch)

    run = await Runner(registry_with_dataset, InMemoryRepo()).evaluate("t")
    metrics = {s.metric for s in run.case_results[0].scores}

    assert metrics == {"tool_selection"}


async def test_runner_rejects_unknown_case_ids_and_version(registry_with_dataset, monkeypatch):
    patch_runner_io(monkeypatch)
    runner = Runner(registry_with_dataset, InMemoryRepo())
    with pytest.raises(ValueError, match="Unknown case id"):
        await runner.evaluate("t", case_ids=["nope"])
    with pytest.raises(ValueError, match="not loaded"):
        await runner.evaluate("t", dataset_version="v9")


def test_compose_status_truncates_and_sanitizes_error_detail():
    noisy = "line1\nline2\t" + ("x" * 3000)
    status = Runner._compose_status(run_passed=False, error_detail=noisy)
    detail = Runner._clean_error_detail(noisy)

    assert status == "ERROR"
    assert detail.startswith("line1 line2")
    assert len(detail) == 3012
