"""Vertex judge/embedding factory: credential guard, caching and client wiring.

Nothing here touches the network: ``google.auth.default`` and the LangChain
Vertex classes are replaced with in-process fakes.
"""

from __future__ import annotations

from typing import Any

import pytest

from core.config import Config
from scorers import vertex

google_auth = pytest.importorskip("google.auth")
genai = pytest.importorskip("langchain_google_genai")
auth_exceptions = pytest.importorskip("google.auth.exceptions")


class _Creds:
    """Stands in for a google.auth credentials object (only the class name is read)."""


class _FakeChat:
    instances: list[dict[str, Any]] = []

    def __init__(self, **kwargs: Any) -> None:
        _FakeChat.instances.append(kwargs)
        self.kwargs = kwargs

    def with_structured_output(self, schema: Any) -> tuple[str, Any]:
        return ("bound", schema)


class _FakeEmbeddings:
    def __init__(self, **kwargs: Any) -> None:
        self.kwargs = kwargs

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [[float(len(t)), 1.0] for t in texts]


@pytest.fixture(autouse=True)
def _vertex_env(monkeypatch):
    """A configured project, empty caches, and counted ADC resolutions."""
    calls = {"n": 0}

    def _default():
        calls["n"] += 1
        return _Creds(), "proj"

    monkeypatch.setattr(Config, "PROJECT_NAME", "demo-project")
    monkeypatch.setattr(google_auth, "default", _default)
    monkeypatch.setattr(vertex, "_JUDGE_CACHE", {})
    _FakeChat.instances = []
    vertex.reset_credentials_cache()
    yield calls
    vertex.reset_credentials_cache()


def test_missing_project_name_explains_how_to_fix(monkeypatch):
    monkeypatch.setattr(Config, "PROJECT_NAME", None)
    with pytest.raises(RuntimeError, match="PROJECT_NAME is not set"):
        vertex.require_vertex_credentials()


def test_credentials_are_resolved_once_within_ttl(_vertex_env):
    assert vertex.require_vertex_credentials() == "_Creds"
    assert vertex.require_vertex_credentials() == "_Creds"
    assert _vertex_env["n"] == 1


def test_expired_cache_resolves_again(monkeypatch, _vertex_env):
    vertex.require_vertex_credentials()
    monkeypatch.setattr(vertex, "_CREDENTIALS_TTL_S", -1.0)
    vertex.require_vertex_credentials()
    assert _vertex_env["n"] == 2


def test_reset_forgets_cached_resolution(_vertex_env):
    vertex.require_vertex_credentials()
    vertex.reset_credentials_cache()
    vertex.require_vertex_credentials()
    assert _vertex_env["n"] == 2


def test_adc_failure_is_not_cached_and_names_the_fix(monkeypatch, _vertex_env):
    def _no_creds():
        raise auth_exceptions.DefaultCredentialsError("nothing found")

    monkeypatch.setattr(google_auth, "default", _no_creds)
    with pytest.raises(RuntimeError, match="gcloud auth application-default login") as err:
        vertex.require_vertex_credentials()
    assert "nothing found" in str(err.value)
    assert vertex._CREDS_CACHE == {}


def test_build_judge_wires_vertex_client_and_memoises(monkeypatch):
    monkeypatch.setattr(genai, "ChatGoogleGenerativeAI", _FakeChat)
    monkeypatch.setattr(Config, "JUDGE_CALL_TIMEOUT", 30)
    first = vertex.build_judge()
    second = vertex.build_judge()
    assert first == ("bound", vertex.JudgeVerdict)
    assert first is second
    assert len(_FakeChat.instances) == 1
    kwargs = _FakeChat.instances[0]
    assert kwargs["project"] == "demo-project"
    assert kwargs["max_retries"] == 0
    assert kwargs["timeout"] == pytest.approx(30.0)


def test_each_schema_gets_its_own_client(monkeypatch):
    monkeypatch.setattr(genai, "ChatGoogleGenerativeAI", _FakeChat)
    vertex.build_judge_for(vertex.PairwiseVerdict)
    vertex.build_judge_for(vertex.MultiRubricVerdict)
    assert len(_FakeChat.instances) == 2


@pytest.mark.parametrize("configured", [0, None])
def test_zero_or_unset_timeout_means_no_client_timeout(monkeypatch, configured):
    monkeypatch.setattr(genai, "ChatGoogleGenerativeAI", _FakeChat)
    monkeypatch.setattr(Config, "JUDGE_CALL_TIMEOUT", configured)
    vertex.build_judge_for(vertex.JudgeVerdict)
    assert _FakeChat.instances[0]["timeout"] is None


def test_build_judge_refuses_without_credentials(monkeypatch):
    monkeypatch.setattr(Config, "PROJECT_NAME", "")
    monkeypatch.setattr(genai, "ChatGoogleGenerativeAI", _FakeChat)
    with pytest.raises(RuntimeError):
        vertex.build_judge()
    assert _FakeChat.instances == []


def test_embed_texts_returns_vectors(monkeypatch):
    monkeypatch.setattr(genai, "GoogleGenerativeAIEmbeddings", _FakeEmbeddings)
    assert vertex.embed_texts(["ab", "abcd"]) == [[2.0, 1.0], [4.0, 1.0]]


def test_embed_texts_wraps_provider_errors(monkeypatch):
    class _Broken(_FakeEmbeddings):
        def embed_documents(self, texts):
            raise ValueError("model not found")

    monkeypatch.setattr(genai, "GoogleGenerativeAIEmbeddings", _Broken)
    with pytest.raises(RuntimeError, match="embedding model unavailable: model not found"):
        vertex.embed_texts(["x"])


def test_verdict_models_validate_score_range():
    with pytest.raises(ValueError):
        vertex.JudgeVerdict(score=1.5)
    assert vertex.PairwiseVerdict().winner == "tie"
    assert vertex.MultiRubricVerdict(scores=[{"criterion": "c", "score": 0.4}]).scores[0].score == pytest.approx(0.4)
