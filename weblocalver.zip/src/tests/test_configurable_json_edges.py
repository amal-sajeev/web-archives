"""Edge cases for configurable_json and the JSON Schema subset checker."""

from __future__ import annotations

import pytest

from scorer_helpers import obs, run
from scorers.json_schema_check import check_schema


def _violations(value, schema) -> list[str]:
    errors: list[str] = []
    check_schema(value, schema, "", errors)
    return errors


class TestJsonPathEdges:
    def test_no_path_configured_passes(self):
        assert run("json_path", obs({"a": 1}), config={})[:2] == (1.0, "no path configured")

    @pytest.mark.parametrize("path", ["items.5", "items.first", "items.0.id.deeper"])
    def test_unreachable_paths_are_missing(self, path):
        score, rationale, evidence = run("json_path", obs({"items": [{"id": 1}]}), config={"path": path})
        assert score == 0.0
        assert rationale == f"path '{path}' missing"
        assert evidence == [f"{path}=absent"]

    def test_contains_on_non_container_fails_instead_of_crashing(self):
        score, _, evidence = run("json_path", obs({"n": 5}), config={"path": "n", "op": "contains", "value": 5})
        assert score == 0.0
        assert evidence == ["n=5"]

    def test_non_json_output_types_fail_clearly(self):
        score, rationale, _ = run("json_path", obs(b"\x00binary"), config={"path": "a"})
        assert score == 0.0
        assert rationale == "output is not valid JSON: output is not JSON"

    def test_json_string_output_is_parsed(self):
        assert run("json_path", obs('{"a": {"b": 2}}'), config={"path": "a.b", "op": "equals", "value": 2})[0] == 1.0


class TestFieldMatchEdges:
    def test_no_fields_configured_passes(self):
        assert run("field_match", obs({}), config={})[:2] == (1.0, "no fields configured")

    def test_invalid_json_fails(self):
        assert run("field_match", obs("{broken"), config={"fields": [{"name": "a"}]})[0] == 0.0

    def test_only_optional_fields_says_so(self):
        score, rationale, evidence = run("field_match", obs({"a": 1}), config={"fields": [
            {"name": "a", "required": False}, {"name": "b", "required": False},
        ]})
        assert score == 1.0
        assert rationale == "no required fields (2 optional checked)"
        assert evidence[0].startswith("✓ a exists") and evidence[1].startswith("✗ b")

    def test_field_without_name_fails(self):
        assert run("field_match", obs({"a": 1}), config={"fields": [{"op": "exists"}]})[0] == 0.0


class TestSchemaShortcutEdges:
    def test_types_without_required_are_checked_when_present(self):
        score, rationale, evidence = run("json_schema_valid", obs({"total": "12"}),
                                         config={"types": {"total": "number", "note": "string"}})
        assert score == 0.0
        assert rationale == "0/1 schema checks passed"
        assert evidence == ["✗ total", "- note (optional, absent)"]

    def test_nothing_configured_on_object(self):
        assert run("json_schema_valid", obs({"a": 1}), config={})[:2] == (1.0, "no schema checks applied")

    def test_non_object_json(self):
        assert run("json_schema_valid", obs([1, 2]), config={})[:2] == (1.0, "valid JSON (non-object)")
        assert run("json_schema_valid", obs([1]), config={"required": ["a"]})[:2] == (0.0, "expected JSON object")

    def test_invalid_json_with_and_without_schema(self):
        assert run("json_schema_valid", obs("nope"), config={"required": ["a"]})[0] == 0.0
        assert run("json_schema_valid", obs("nope"), config={"schema": {"type": "object"}})[0] == 0.0


class TestSchemaChecker:
    def test_unknown_type_name_is_reported(self):
        assert _violations("x", {"type": "text"}) == [
            "root: unsupported schema type ['text']", "root: expected text, got str",
        ]

    def test_invalid_pattern_is_reported(self):
        assert _violations("x", {"pattern": "("})[0].startswith("root: invalid schema pattern /(/")

    def test_pattern_mismatch(self):
        assert _violations("abc", {"pattern": "^z"}) == ["root: does not match pattern /^z/"]

    def test_const_and_enum_do_not_confuse_booleans_with_numbers(self):
        assert _violations(1, {"const": True}) == ["root: 1 != const True"]
        assert _violations(True, {"enum": [1, 0]}) == ["root: True not in enum [1, 0]"]
        assert _violations(1.0, {"const": 1}) == []
        assert _violations(False, {"enum": [False]}) == []

    def test_additional_properties_schema_applies_to_extras(self):
        schema = {"properties": {"a": {}}, "additionalProperties": {"type": "integer"}}
        assert _violations({"a": "x", "b": "y"}, schema) == [".b: expected integer, got str"]

    def test_items_schema_checks_every_element(self):
        schema = {"type": "array", "items": {"type": "string"}, "maxItems": 2}
        assert _violations(["a", 3, "c"], schema) == ["root: 3 > maxItems 2", "[1]: expected string, got int"]

    def test_non_object_schema_is_reported(self):
        assert _violations({"a": 1}, {"properties": {"a": "integer"}}) == [".a: schema must be an object"]

    def test_type_failure_stops_further_checks(self):
        assert _violations("abc", {"type": "integer", "minimum": 5}) == ["root: expected integer, got str"]

    def test_annotations_are_ignored(self):
        assert _violations(3, {"title": "n", "description": "d", "format": "int32", "minimum": 1}) == []


def test_unknown_type_name_in_field_match_fails_the_check():
    score, _, evidence = run("field_match", obs({"n": 1}), config={"fields": [{"name": "n", "op": "type", "value": "decimal"}]})
    assert score == 0.0
    assert evidence[0].startswith("\u2717 n type 'decimal'")
