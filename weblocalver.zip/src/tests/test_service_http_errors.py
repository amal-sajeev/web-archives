"""Plain-language wording for outbound HTTP failures (service/http_errors.py)."""

from __future__ import annotations

import httpx
import pytest

from service.http_errors import describe_http_error, plain_http_error, technical_detail


@pytest.mark.parametrize(("exc", "sentence"), [
    (httpx.ConnectError("refused"),
     "Could not connect to the agent. Check that it is running and that its address is correct."),
    (httpx.ConnectTimeout("slow"), "The agent did not accept the connection within the time limit."),
    (httpx.ReadTimeout("slow"), "The agent did not respond within the time limit."),
    (TimeoutError("slow"), "The agent did not respond within the time limit."),
    (httpx.RemoteProtocolError("eof"), "The agent closed the connection unexpectedly."),
    (httpx.ReadError("reset"), "The agent closed the connection unexpectedly."),
    (httpx.ProxyError("407"), "The network proxy refused the connection to the agent."),
    (httpx.UnsupportedProtocol("ftp"), "The address configured for the agent is not a valid URL."),
])
def test_known_transport_failures_get_a_plain_sentence(exc, sentence):
    assert plain_http_error(exc) == sentence
    assert describe_http_error(exc) == f"{sentence} ({technical_detail(exc)})"


def test_malformed_replies_are_explained():
    import json

    from core.models import Observation

    with pytest.raises(ValueError) as err:
        Observation.model_validate({})
    assert plain_http_error(err.value) == "The agent replied, but not in the expected format."
    bad_json = json.JSONDecodeError("Expecting value", "<html>", 0)
    assert plain_http_error(bad_json) == "The agent replied, but the reply was not valid JSON."


def test_subject_is_capitalised_at_sentence_start():
    assert plain_http_error(httpx.ReadTimeout("x"), "the AI assessment service") == (
        "The AI assessment service did not respond within the time limit."
    )


def test_unknown_errors_keep_only_technical_text():
    assert plain_http_error(ValueError("bad")) is None
    assert describe_http_error(ValueError("bad")) == "ValueError: bad"


def test_empty_message_shows_just_the_type():
    assert technical_detail(httpx.ReadTimeout("")) == "ReadTimeout"
