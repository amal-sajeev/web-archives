"""Playground bundle handling (core/playground) and the HTTP probe helper."""

from __future__ import annotations

import io
import json
import shutil
import sys
import zipfile
from datetime import datetime, UTC
from types import SimpleNamespace

import httpx
import pytest

from core.models import RunRecord
from core.playground import (
    PreviewRepository, ScopedRegistry, _cleanup_scoped_registry, _load_scoped_registry,
    extract_to_temp, files_to_zip, inspect_bundle, load_scoped_registry,
)
from core.playground import archive
from core_helpers import mock_http_fixture  # noqa: F401
from handlers.playground_http import playground_http

_AGENT_YAML = "agent_id: demo\nname: Demo\ndataset_file: dataset.json\nmetrics_stub_file: metrics_stub.json\n"
_DATASET = json.dumps({
    "dataset_id": "demo-data", "version": "1", "target": {"adapter": "http", "endpoint": "/eval"},
    "metrics": [], "cases": [{"id": "case-1", "input": {}, "baseline_metrics": {}}],
})
_CUSTOM = 'from scorers import scorer\n@scorer("invoice_total")\ndef invoice_total(observation, case, metrics, **_):\n    return (1.0, "ok", [])\n'


def bundle(root="demo", extra=None):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{root}/agent.yaml", _AGENT_YAML)
        z.writestr(f"{root}/dataset.json", _DATASET)
        z.writestr(f"{root}/metrics_stub.json", json.dumps({"cases": {}}))
        z.writestr(f"{root}/notes.md", "hello")
        for name, content in (extra or {}).items():
            z.writestr(f"{root}/{name}", content)
    return buf.getvalue()


def test_inspect_normalizes_agent_root():
    result = inspect_bundle(bundle())
    assert result["root"] == "demo"
    assert result["agent"]["agent_id"] == "demo"
    assert {f["path"] for f in result["files"]} == {"agent.yaml", "dataset.json", "metrics_stub.json", "notes.md"}


def test_export_round_trip_preserves_root_and_content():
    inspected = inspect_bundle(bundle())
    edited = [dict(f) for f in inspected["files"]]
    for item in edited:
        if item["path"] == "notes.md":
            item["content"] = "edited"
    exported = files_to_zip(edited, inspected["root"])
    with zipfile.ZipFile(io.BytesIO(exported)) as z:
        assert z.read("demo/notes.md").decode() == "edited"
        assert "demo/agent.yaml" in z.namelist()


def test_files_to_zip_rejects_bad_base64():
    with pytest.raises(ValueError, match="Invalid base64"):
        files_to_zip([{"path": "a.bin", "encoding": "base64", "content": "@@not-base64@@"}])


def test_rejects_path_traversal():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("../agent.yaml", "agent_id: demo")
    with pytest.raises(ValueError, match="Unsafe zip path"):
        inspect_bundle(buf.getvalue())


def test_zip_uncompressed_size_limit(monkeypatch):
    monkeypatch.setattr(archive, "MAX_UNCOMPRESSED_BYTES", 10)
    with pytest.raises(ValueError, match="expands beyond"):
        inspect_bundle(bundle())


def test_inspect_reports_declared_custom_scorers_without_executing_them():
    result = inspect_bundle(bundle(extra={"custom_tests.py": _CUSTOM}))
    assert result["custom_tests"]["present"] is True
    assert result["custom_tests"]["declared_scorers"] == ["invoice_total"]
    assert result["custom_tests"]["syntax_error"] is None


def test_inspect_reports_custom_tests_syntax_error():
    result = inspect_bundle(bundle(extra={"custom_tests.py": "def broken(:\n"}))
    assert result["custom_tests"]["syntax_error"].startswith("line 1")
    assert any("syntax error" in w for w in result["warnings"])


class FakeSevenZipFile:
    uncompressed = 100
    read_called = False

    def __init__(self, fileobj, mode="r"):
        self.fileobj = fileobj

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def list(self):
        return [SimpleNamespace(uncompressed=self.uncompressed) for _ in range(3)]

    def readall(self):
        FakeSevenZipFile.read_called = True
        return {
            "demo/agent.yaml": io.BytesIO(_AGENT_YAML.encode()),
            "demo/dataset.json": io.BytesIO(_DATASET.encode()),
            "demo/metrics_stub.json": io.BytesIO(b"{}"),
        }


@pytest.fixture
def extracted():
    dirs = []

    def _extract(blob):
        temp_dir, agent_id = extract_to_temp(blob)
        dirs.append(temp_dir)
        return temp_dir, agent_id

    yield _extract
    for d in dirs:
        shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def fake_py7zr(monkeypatch):
    FakeSevenZipFile.read_called = False
    monkeypatch.setitem(sys.modules, "py7zr", SimpleNamespace(SevenZipFile=FakeSevenZipFile))
    return FakeSevenZipFile


def test_inspect_supports_7z_archives(fake_py7zr):
    result = inspect_bundle(b"fake-7z-bytes", filename="bundle.7z")
    assert result["archive_kind"] == "7z"
    assert result["root"] == "demo"
    assert result["agent"]["agent_id"] == "demo"


def test_7z_size_is_checked_before_decompressing(fake_py7zr, monkeypatch):
    monkeypatch.setattr(fake_py7zr, "uncompressed", archive.MAX_UNCOMPRESSED_BYTES)
    with pytest.raises(ValueError, match="7z expands beyond"):
        inspect_bundle(b"fake-7z-bytes", filename="bundle.7z")
    assert fake_py7zr.read_called is False


def test_scoped_registry_reports_custom_scorers_and_restores_registry(extracted):
    from scorers import all_scorers

    temp_dir, agent_id = extracted(bundle(extra={"custom_tests.py": _CUSTOM}))
    scoped = load_scoped_registry(temp_dir)
    assert isinstance(scoped, ScopedRegistry)
    assert scoped.registry.has(agent_id)
    assert scoped.custom_scorers == ["invoice_total"]
    assert "invoice_total" in all_scorers()
    scoped.cleanup()
    assert "invoice_total" not in all_scorers()


def test_legacy_scoped_registry_tuple_api_cleans_up(extracted):
    from scorers import all_scorers

    temp_dir, _ = extracted(bundle(extra={"custom_tests.py": _CUSTOM}))
    registry, custom, collisions = _load_scoped_registry(temp_dir)
    assert custom == ["invoice_total"] and collisions == []
    _cleanup_scoped_registry(registry)
    assert "invoice_total" not in all_scorers()


def _run(run_id, day, *, status="PASS"):
    return RunRecord(run_id=run_id, agent_id="demo", dataset_id="d", dataset_version="1",
                     weighted_score=1.0, weighted_delta=0.0, status=status,
                     creation_ts=datetime(2026, 1, day, tzinfo=UTC).isoformat())


def test_preview_repository_keyset_and_counts():
    repo = PreviewRepository()
    for run_id, day in (("a", 1), ("b", 2), ("c", 2)):
        repo.save_run(_run(run_id, day))
    rows = repo.list_runs(limit=2)
    assert [r["run_id"] for r in rows] == ["c", "b"]
    assert rows[0]["case_count"] == 0 and rows[0]["passed_case_count"] == 0
    page2 = repo.list_runs(limit=2, before=rows[-1]["creation_ts"], before_id=rows[-1]["run_id"])
    assert [r["run_id"] for r in page2] == ["a"]
    assert rows[0]["error_detail"] is None
    failed = _run("e", 3, status="ERROR")
    failed.error_detail = "Could not connect to the agent."
    repo.save_run(failed)
    error_rows = repo.list_runs(status="ERROR")
    assert [r["run_id"] for r in error_rows] == ["e"]
    assert error_rows[0]["error_detail"] == "Could not connect to the agent."


async def test_playground_http_forwards_json_body_and_returns_compat_fields(mock_http):
    seen = mock_http(lambda request: httpx.Response(200, json={"result": "ok", "planNumber": "20090"}))

    response = await playground_http({
        "method": "POST",
        "url": "https://agent.example.test/scoping-dataextraction-agent",
        "headers": {"Content-Type": "application/json"},
        "body": {"planNumber": "20090"},
    })

    assert seen[0].method == "POST"
    assert seen[0].headers["content-type"] == "application/json"
    assert json.loads(seen[0].content) == {"planNumber": "20090"}
    assert response["status"] == 200
    assert response["status_code"] == 200
    assert response["body"] == {"result": "ok", "planNumber": "20090"}


async def test_playground_http_parses_string_json_body_by_content_type(mock_http):
    seen = mock_http(lambda request: httpx.Response(200, text="ok", headers={"content-type": "text/plain"}))

    response = await playground_http({
        "method": "POST",
        "url": "https://example.test/echo",
        "headers": {"Content-Type": "application/json"},
        "body": '{"planNumber":"20090"}',
    })

    assert json.loads(seen[0].content) == {"planNumber": "20090"}
    assert response["body"] == "ok"


def test_preview_repository_filters_and_baselines():
    repo = PreviewRepository()
    assert repo.init_schema() is None
    repo.save_run(_run("a", 1))
    repo.save_run(_run("b", 2, status="FAIL"))
    other = _run("c", 3).model_copy(update={"agent_id": "other", "dataset_id": "x"})
    repo.save_run(other)
    assert repo.get_run("b").status == "FAIL" and repo.get_run("missing") is None
    assert [r["run_id"] for r in repo.list_runs(status="FAIL")] == ["b"]
    assert [r["run_id"] for r in repo.list_runs(agent_id="demo", dataset_id="d")] == ["b", "a"]
    assert [r["run_id"] for r in repo.list_runs(before=_run("x", 2).creation_ts)] == ["a"]
    assert repo.get_baseline("demo", "d", "1", "m") is None
    repo.set_baseline("demo", "d", "1", "m", 0.7, created_by="tester")
    assert repo.get_baseline("demo", "d", "1", "m") == 0.7


def test_cleanup_accepts_scoped_registry_and_ignores_unknown(extracted):
    from scorers import all_scorers

    temp_dir, _ = extracted(bundle(extra={"custom_tests.py": _CUSTOM}))
    scoped = load_scoped_registry(temp_dir)
    _cleanup_scoped_registry(scoped)
    assert "invoice_total" not in all_scorers()
    _cleanup_scoped_registry(scoped.registry)  # never registered via the tuple API: a no-op
