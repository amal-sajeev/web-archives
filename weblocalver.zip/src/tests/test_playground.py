import io
import json
import sys
import zipfile

import pytest

sys.path.insert(0, "src/main")
from playground import files_to_zip, inspect_bundle


def bundle(root="demo"):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{root}/agent.yaml", """agent_id: demo\nname: Demo\nbase_url: http://127.0.0.1:9999\ndataset_file: dataset.json\nmetrics_stub_file: metrics_stub.json\n""")
        z.writestr(f"{root}/dataset.json", json.dumps({
            "dataset_id": "demo-data", "version": "1", "target": {"adapter": "http", "endpoint": "/eval"},
            "metrics": [], "cases": [{"id": "case-1", "input": {}, "baseline_metrics": {}}],
        }))
        z.writestr(f"{root}/metrics_stub.json", json.dumps({"cases": {}}))
        z.writestr(f"{root}/notes.md", "hello")
    return buf.getvalue()


def test_inspect_normalizes_agent_root():
    result = inspect_bundle(bundle())
    assert result["root"] == "demo"
    assert result["agent"]["agent_id"] == "demo"
    assert {f["path"] for f in result["files"]} == {"agent.yaml", "dataset.json", "metrics_stub.json", "notes.md"}


def test_export_round_trip_preserves_root_and_content():
    inspected = inspect_bundle(bundle())
    edited = [dict(f) for f in inspected["files"]]
    for item in edited:
        if item["path"] == "notes.md":
            item["content"] = "edited"
    exported = files_to_zip(edited, inspected["root"])
    with zipfile.ZipFile(io.BytesIO(exported)) as z:
        assert z.read("demo/notes.md").decode() == "edited"
        assert "demo/agent.yaml" in z.namelist()


def test_rejects_path_traversal():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("../agent.yaml", "agent_id: demo")
    with pytest.raises(ValueError, match="Unsafe zip path"):
        inspect_bundle(buf.getvalue())


def test_inspect_reports_declared_custom_scorers_without_executing_them():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(
            "demo/agent.yaml",
            "agent_id: demo\nname: Demo\ndataset_file: dataset.json\nmetrics_stub_file: metrics_stub.json\n",
        )
        z.writestr(
            "demo/dataset.json",
            json.dumps({
                "dataset_id": "demo-data",
                "version": "1",
                "target": {"adapter": "http", "endpoint": "/eval"},
                "metrics": [],
                "cases": [{"id": "case-1", "input": {}, "baseline_metrics": {}}],
            }),
        )
        z.writestr("demo/metrics_stub.json", "{}")
        z.writestr(
            "demo/custom_tests.py",
            'from scorers import scorer\n@scorer("invoice_total")\ndef invoice_total(observation, case, metrics):\n    return (1.0, "ok", [])\n',
        )
    result = inspect_bundle(buf.getvalue())
    assert result["custom_tests"]["present"] is True
    assert result["custom_tests"]["declared_scorers"] == ["invoice_total"]
