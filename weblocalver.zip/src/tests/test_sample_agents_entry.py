"""Sample agents run as plain scripts, plus parser fallbacks for unusual input."""

from __future__ import annotations

import importlib
import runpy
import sys
from pathlib import Path

import pytest
import uvicorn

_SRC = Path(__file__).resolve().parents[1]
_AGENTS_DIR = _SRC / "sample_agents"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

_SCRIPTS = ("data_extraction_agent.py", "document_qa_agent.py", "invoice_parser_agent.py", "report_writer_agent.py")


@pytest.mark.parametrize("script", _SCRIPTS)
def test_script_entry_point_serves_without_pythonpath(monkeypatch, script):
    """`python src/sample_agents/<agent>.py` works without PYTHONPATH=src."""
    served: list[tuple[object, str, int]] = []
    monkeypatch.setattr(uvicorn, "run", lambda app, host, port: served.append((app, host, port)))
    monkeypatch.setitem(sys.modules, "sample_agents", None)  # the package is not importable
    monkeypatch.setitem(sys.modules, "sample_agents._common", None)
    monkeypatch.delitem(sys.modules, "_common", raising=False)
    monkeypatch.syspath_prepend(str(_AGENTS_DIR))
    try:
        namespace = runpy.run_path(str(_AGENTS_DIR / script), run_name="__main__")
    finally:
        sys.modules.pop("_common", None)
    assert len(served) == 1
    app, _host, port = served[0]
    assert app is namespace["app"]
    assert port == namespace["PORT"]


def _module(name: str):
    return importlib.import_module(f"sample_agents.{name}")


def test_data_extraction_helpers_handle_missing_markers():
    module = _module("data_extraction_agent")
    assert module._entity("no known company here") == ""
    assert module._after("assessment unit", "no marker") is None
    tool_name, args = module._route("control for R3")
    assert tool_name == "get_control_data"
    assert args == {"risk_id": "R3", "external_ref": "", "assessment_unit": ""}


def test_invoice_without_total_line_totals_zero():
    module = _module("invoice_parser_agent")
    assert module.extract_total.invoke({"text": "From: Nobody\nnothing owed"}) == 0.0
    assert module.extract_vendor.invoke({"text": "no vendor line"}) == "Unknown Vendor"
