"""Metrics adapters: CTA_ACTION flattening, stub/http/capture clients, source selection."""

from __future__ import annotations

import json

import httpx
import pytest

from adapters import metrics_api
from adapters.capture import CaptureMetricsClient, CaptureStore
from adapters.metrics_api import derive_metrics, extract_action
from core.config import Config
from core.models import Observation
from core_helpers import mock_http_fixture  # noqa: F401

_PAYLOAD = {"Response_Code": "200", "Token_Input_Count": "10", "Token_Output_Count": "5"}


class TestExtractAction:
    def test_cta_action_envelope(self):
        metrics = derive_metrics(extract_action({"CTA_ACTION": {"payload": _PAYLOAD}}))
        assert metrics["response_code"] == 200.0
        assert metrics["token_total_count"] == 15.0

    def test_nested_agent_wrapper(self):
        metrics = derive_metrics(extract_action({"walkthrough_query_agent": {"payload": _PAYLOAD}}))
        assert metrics["response_code"] == 200.0
        assert metrics["token_total_count"] == 15.0

    def test_non_dict_entry(self):
        assert extract_action(["x"]) == {}
        assert metrics_api._extract_action is extract_action


class TestFieldParsing:
    def test_non_numeric_and_unparseable_fields_are_dropped(self):
        payload = {"Token_Input_Count": "many", "Token_Output_Count": "5",
                   "Execution_Start_Time": "yesterday", "Execution_End_Time": "2026-01-01 10:00:00.000"}
        metrics = derive_metrics({"payload": payload})
        assert "execution_latency_ms" not in metrics
        assert metrics.get("token_input_count") is None

    def test_unrecognised_shapes_are_returned_as_is(self):
        assert extract_action({"a": 1, "b": 2}) == {"a": 1, "b": 2}
        assert extract_action({"only": "scalar"}) == {"only": "scalar"}


class TestDeriveMetrics:
    def test_mixed_naive_and_aware_timestamps(self):
        payload = {"Execution_Start_Time": "2026-01-01 10:00:00.000", "Execution_End_Time": "2026-01-01T10:00:02.5+00:00"}
        assert derive_metrics({"payload": payload})["execution_latency_ms"] == pytest.approx(2500.0)

    def test_aware_timestamps_in_other_zones(self):
        payload = {"Execution_Start_Time": "2026-01-01T12:00:00+02:00", "Execution_End_Time": "2026-01-01T10:00:01+00:00"}
        assert derive_metrics({"payload": payload})["execution_latency_ms"] == pytest.approx(1000.0)

    def test_tolerates_malformed_payload_and_tool_calls(self):
        assert derive_metrics({"payload": "junk"})["tool_call_count"] == 0.0
        metrics = derive_metrics({"payload": {"Tool_Calls": ["bad", {"Call_Count": "2", "Tool_Errors": ["e", ""]}]}})
        assert metrics["tool_call_count"] == 2.0
        assert metrics["tool_error_count"] == 1.0


class TestStubClient:
    async def test_non_dict_stub_is_ignored(self, tmp_path):
        stub = tmp_path / "stub.json"
        stub.write_text(json.dumps(["not", "a", "dict"]), encoding="utf-8")
        assert await metrics_api.StubMetricsClient(stub).fetch("c1") == {}

    async def test_reads_cases(self, tmp_path):
        stub = tmp_path / "stub.json"
        stub.write_text(json.dumps({"cases": {"c1": {"payload": _PAYLOAD}}}), encoding="utf-8")
        assert (await metrics_api.StubMetricsClient(stub).fetch("c1"))["response_code"] == 200.0

    async def test_missing_stub_path(self):
        assert await metrics_api.StubMetricsClient(None).fetch("c1") == {}

    async def test_corrupt_stub_is_ignored_not_fatal(self, tmp_path):
        stub = tmp_path / "stub.json"
        stub.write_text("{not json", encoding="utf-8")
        assert await metrics_api.StubMetricsClient(stub).fetch("c1") == {}

    async def test_unknown_case_has_no_metrics(self, tmp_path):
        stub = tmp_path / "stub.json"
        stub.write_text(json.dumps({"c1": {"payload": _PAYLOAD}}), encoding="utf-8")
        assert await metrics_api.StubMetricsClient(stub).fetch("other") == {}


class TestHttpClient:
    async def test_fetch_error_is_logged_and_empty(self, mock_http):
        mock_http(lambda request: httpx.Response(503, text="down"))
        assert await metrics_api.HttpMetricsClient("https://metrics").fetch("c1") == {}

    async def test_fetch_success(self, mock_http):
        seen = mock_http(lambda request: httpx.Response(200, json={"CTA_ACTION": {"payload": _PAYLOAD}}))
        metrics = await metrics_api.HttpMetricsClient("https://metrics/").fetch("c1")
        assert metrics["token_total_count"] == 15.0
        assert seen[0].url.params["case_id"] == "c1"


class TestSourceSelection:
    def test_invalid_source_raises(self, monkeypatch):
        monkeypatch.setattr(Config, "METRICS_SOURCE", "bogus")
        with pytest.raises(ValueError, match="Invalid metrics source"):
            metrics_api.build_metrics_client(None)

    def test_override_and_default(self, monkeypatch):
        monkeypatch.setattr(Config, "METRICS_SOURCE", "")
        monkeypatch.setattr(Config, "METRICS_API_BASE", None)
        assert isinstance(metrics_api.build_metrics_client(None), metrics_api.StubMetricsClient)
        client = metrics_api.build_metrics_client(None, source_override="Capture", agent_id="a1")
        assert isinstance(client, CaptureMetricsClient)

    def test_http_requires_base(self, monkeypatch):
        monkeypatch.setattr(Config, "METRICS_API_BASE", None)
        with pytest.raises(RuntimeError, match="METRICS_API_BASE"):
            metrics_api.build_metrics_client(None, source_override="http")

    def test_http_with_base_builds_http_client(self, monkeypatch):
        monkeypatch.setattr(Config, "METRICS_API_BASE", "https://metrics.example/")
        client = metrics_api.build_metrics_client(None, source_override="http")
        assert isinstance(client, metrics_api.HttpMetricsClient)


class TestCaptureStore:
    async def test_agents_do_not_share_case_entries(self):
        store = CaptureStore()
        obs_a = Observation(target_id="a", usage={"input_tokens": 1, "output_tokens": 1})
        obs_b = Observation(target_id="b", usage={"input_tokens": 50, "output_tokens": 50})
        await CaptureMetricsClient(store, agent_id="a").fetch("c1", obs_a)
        await CaptureMetricsClient(store, agent_id="b").fetch("c1", obs_b)
        replay_a = await CaptureMetricsClient(store, agent_id="a").fetch("c1")
        assert replay_a["token_total_count"] == 2.0
        assert store.get("c1")["CTA_ACTION"]["target_entity_type"] == "b"  # unscoped: latest wins
        assert set(store.latest(agent_id="a")) == {"c1"}
        assert store.get("missing") is None

    def test_history_and_entries_are_bounded(self):
        store = CaptureStore(max_entries=2, max_history=3)
        for i in range(5):
            store.put(f"c{i}", {"i": i}, agent_id="a")
        assert [h["i"] for h in store.history()] == [2, 3, 4]
        assert set(store.latest()) == {"c3", "c4"}
