"""Terminal-event rules: a runner ``run_done`` (status ERROR) must not hide the failure outcome."""

from __future__ import annotations

from core.run_manager import LiveRun
from handlers._common import publish_cancelled, publish_failure


def _types(live: LiveRun) -> list[str]:
    return [e["type"] for e in live.events]


def test_cancel_published_after_runner_error_run_done():
    live = LiveRun("s1", "agent")
    live.publish({"type": "run_done", "status": "ERROR", "error_detail": "cancelled"})

    publish_cancelled(live)
    publish_cancelled(live)

    assert _types(live) == ["run_done", "run_cancelled"]


def test_failure_published_once_after_runner_error_run_done():
    live = LiveRun("s2", "agent")
    live.publish({"type": "run_done", "status": "ERROR"})

    publish_failure(live, ValueError("bad input"))
    publish_failure(live, ValueError("again"))

    assert _types(live) == ["run_done", "error"]
