"""Playground archives: real ZIP and 7z fixtures, limits, and friendly error messages."""

from __future__ import annotations

import io
import shutil
import sys
import zipfile
from types import SimpleNamespace

import py7zr
import pytest

from core.playground import archive, extract_to_temp, files_to_zip, inspect_bundle, load_scoped_registry
from test_playground import _AGENT_YAML, _DATASET

_BASE = {"agent.yaml": _AGENT_YAML, "dataset.json": _DATASET, "metrics_stub.json": "{}"}


def make_zip(files: dict[str, str | bytes], root: str = "demo") -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, content in files.items():
            z.writestr(f"{root}/{name}" if root else name, content)
    return buf.getvalue()


def make_7z(files: dict[str, str | bytes], root: str = "demo") -> bytes:
    buf = io.BytesIO()
    with py7zr.SevenZipFile(buf, "w") as z:
        for name, content in files.items():
            z.writestr(content, f"{root}/{name}")
    return buf.getvalue()


class _NoReadallArchive:
    """Wraps a real py7zr archive but hides ``readall`` (as in py7zr >= 1.0)."""

    def __init__(self, fileobj, mode="r", listing=None):
        self._real = py7zr.SevenZipFile(fileobj, mode=mode)
        self._listing = listing

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self._real.close()
        return False

    def list(self):
        return self._real.list() if self._listing is None else self._listing

    def extractall(self, path):
        self._real.extractall(path=path)


@pytest.fixture
def cleanup_dirs():
    dirs = []
    yield dirs
    for d in dirs:
        shutil.rmtree(d, ignore_errors=True)


class TestZipLimits:
    def test_blob_size_limit(self, monkeypatch):
        monkeypatch.setattr(archive, "MAX_ZIP_BYTES", 10)
        with pytest.raises(ValueError, match="Configuration ZIP exceeds"):
            inspect_bundle(make_zip(_BASE))

    def test_too_many_files(self, monkeypatch):
        monkeypatch.setattr(archive, "MAX_FILES", 2)
        with pytest.raises(ValueError, match="too many files"):
            inspect_bundle(make_zip(_BASE))

    def test_symlinks_are_rejected(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            info = zipfile.ZipInfo("demo/link")
            info.external_attr = 0o120777 << 16
            z.writestr(info, "/etc/passwd")
        with pytest.raises(ValueError, match="Symlinks are not allowed"):
            inspect_bundle(buf.getvalue())

    def test_not_a_zip_has_a_plain_message(self):
        with pytest.raises(ValueError, match="not a valid ZIP archive, or it is damaged"):
            inspect_bundle(b"just some text", filename="bundle.zip")

    def test_directory_only_zip_is_empty(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("demo/", "")
        with pytest.raises(ValueError, match="The ZIP archive is empty"):
            inspect_bundle(buf.getvalue())


class TestSevenZip:
    def test_real_7z_detected_by_magic_bytes(self):
        result = inspect_bundle(make_7z(_BASE))
        assert result["archive_kind"] == "7z" and result["root"] == "demo"

    def test_backslash_names_are_normalised(self):
        assert archive._collect_7z({"demo\\agent.yaml": b"x"}) == {"demo/agent.yaml": b"x"}

    def test_too_many_files(self, monkeypatch):
        monkeypatch.setattr(archive, "MAX_FILES", 1)
        with pytest.raises(ValueError, match="7z contains too many files"):
            inspect_bundle(make_7z(_BASE))

    def test_garbage_named_7z_is_invalid(self):
        with pytest.raises(ValueError, match="not a valid 7z archive, or it is damaged"):
            inspect_bundle(b"not seven zip", filename="bundle.7z")

    def test_corrupt_payload_is_invalid(self):
        # Stored (uncompressed) members, so a flipped data byte is a clean CRC error.
        buf = io.BytesIO()
        with py7zr.SevenZipFile(buf, "w", filters=[{"id": py7zr.FILTER_COPY}]) as z:
            z.writestr("hello " * 50, "demo/agent.yaml")
        blob = bytearray(buf.getvalue())
        blob[40] ^= 0xFF  # inside the packed stream, after the 32-byte signature header
        with pytest.raises(ValueError, match="not a valid 7z archive"):
            inspect_bundle(bytes(blob))

    def test_empty_7z(self):
        with pytest.raises(ValueError, match="The 7z archive is empty"):
            inspect_bundle(make_7z({}), filename="empty.7z")

    def test_missing_py7zr_is_explained(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "py7zr", None)
        with pytest.raises(ValueError, match="7z archives are not supported on this server"):
            inspect_bundle(b"whatever", filename="bundle.7z")

    def test_fallback_without_readall_extracts_nested_files(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "py7zr", SimpleNamespace(SevenZipFile=_NoReadallArchive))
        result = inspect_bundle(make_7z({**_BASE, "prompts/system.txt": "be nice"}))
        assert "prompts/system.txt" in {f["path"] for f in result["files"]}

    def test_decompressed_size_is_rechecked(self, monkeypatch):
        """A listing that under-reports sizes is still caught while collecting members."""
        def lying(fileobj, mode="r"):
            return _NoReadallArchive(fileobj, mode, listing=[])

        monkeypatch.setitem(sys.modules, "py7zr", SimpleNamespace(SevenZipFile=lying))
        monkeypatch.setattr(archive, "MAX_UNCOMPRESSED_BYTES", 10)
        with pytest.raises(ValueError, match="7z expands beyond"):
            inspect_bundle(make_7z(_BASE))


class TestFilesToZip:
    def test_duplicates_are_written_once_and_no_root(self):
        items = [{"path": "a.txt", "content": "first"}, {"path": "a.txt", "content": "second"}]
        with zipfile.ZipFile(io.BytesIO(files_to_zip(items))) as z:
            assert z.namelist() == ["a.txt"] and z.read("a.txt") == b"first"

    def test_base64_items_are_decoded(self):
        items = [{"path": "logo.png", "encoding": "base64", "content": "AAEC"}]
        with zipfile.ZipFile(io.BytesIO(files_to_zip(items, root="/demo/"))) as z:
            assert z.read("demo/logo.png") == bytes([0, 1, 2])

    def test_uncompressed_limit(self, monkeypatch):
        monkeypatch.setattr(archive, "MAX_UNCOMPRESSED_BYTES", 3)
        with pytest.raises(ValueError, match="too large to export"):
            files_to_zip([{"path": "a.txt", "content": "four"}])

    def test_zip_size_limit(self, monkeypatch):
        monkeypatch.setattr(archive, "MAX_ZIP_BYTES", 10)
        with pytest.raises(ValueError, match="Edited ZIP exceeds"):
            files_to_zip([{"path": "a.txt", "content": "x"}])


class TestExtractToTemp:
    def test_nested_root_is_loadable_by_the_registry(self, cleanup_dirs):
        """Regression: a nested root used to land two levels deep, so the Registry never found the agent."""
        temp_dir, agent_id = extract_to_temp(make_zip(_BASE, root="bundle/agents/demo"))
        cleanup_dirs.append(temp_dir)
        assert (temp_dir / "demo" / "agent.yaml").is_file()
        scoped = load_scoped_registry(temp_dir)
        try:
            assert scoped.registry.has(agent_id)
        finally:
            scoped.cleanup()

    def test_archive_root_level_uses_agent_id_folder(self, cleanup_dirs):
        temp_dir, agent_id = extract_to_temp(make_zip(_BASE, root=""))
        cleanup_dirs.append(temp_dir)
        assert agent_id == "demo" and (temp_dir / "demo" / "dataset.json").is_file()
