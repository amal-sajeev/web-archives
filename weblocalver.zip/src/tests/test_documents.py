"""Tests for the document text-extraction layer (adapters/documents.py)."""

from __future__ import annotations

import base64
import sys

import pytest

_ZIP_MAGIC = bytes([0x50, 0x4B, 0x03, 0x04])  # "PK\x03\x04"

from adapters.documents import (
    detect_content_type,
    extract_text,
    parse_markdown_sections,
    parse_headings,
    DocUnavailable,
)


class TestDetectContentType:
    def test_text(self):
        assert detect_content_type("hello world") == "text"

    def test_json_dict(self):
        assert detect_content_type({"a": 1}) == "json"

    def test_json_string(self):
        assert detect_content_type('{"a": 1}') == "json"

    def test_markdown_heading(self):
        assert detect_content_type("# Title\nbody") == "markdown"

    def test_pdf_magic_bytes(self):
        assert detect_content_type(b"%PDF-1.4\nstuff") == "pdf"

    def test_base64_pdf(self):
        raw = b"%PDF-1.4 test"
        b64 = base64.b64encode(raw).decode()
        assert detect_content_type(b64, "base64") == "pdf"

    def test_docx_magic_bytes(self):
        assert detect_content_type(b"PK\x03\x04stuff") == "docx"

    def test_none(self):
        assert detect_content_type(None) == "text"


class TestExtractText:
    def test_text_passthrough(self):
        assert extract_text("hello") == "hello"

    def test_markdown_strips_syntax(self):
        md = "# Title\n\n**bold** and *italic* and `code`"
        text = extract_text(md, "markdown")
        assert "Title" in text
        assert "**" not in text
        assert "*" not in text
        assert "`" not in text

    def test_json_pretty_print(self):
        result = extract_text({"a": 1}, "json")
        assert '"a": 1' in result

    def test_json_string(self):
        result = extract_text('{"b": 2}', "json")
        assert '"b": 2' in result

    def test_none_returns_empty(self):
        assert extract_text(None) == ""

    def test_pdf_raises_doc_unavailable_without_pypdf(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "pypdf", None)  # makes ``import pypdf`` fail
        with pytest.raises(DocUnavailable, match="pypdf is not installed"):
            extract_text(b"%PDF-1.4 anything", "pdf")

    def test_docx_raises_doc_unavailable_without_python_docx(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "docx", None)
        with pytest.raises(DocUnavailable, match="python-docx is not installed"):
            extract_text(_ZIP_MAGIC + bytes(100), "docx")


class TestParseMarkdownSections:
    def test_split_by_headings(self):
        md = "# Title\n\nbody1\n\n## Sub\n\nbody2"
        sections = parse_markdown_sections(md)
        assert "Title" in sections
        assert "Sub" in sections
        assert "body1" in sections["Title"]
        assert "body2" in sections["Sub"]

    def test_no_headings(self):
        sections = parse_markdown_sections("just text")
        assert sections == {}


class TestParseHeadings:
    def test_markdown_headings(self):
        text = "# A\n## B\n### C\nbody"
        headings = parse_headings(text, "markdown")
        assert len(headings) == 3

    def test_plain_text_headings(self):
        text = "Introduction\nThis is some body text.\nConclusion"
        headings = parse_headings(text, "text")
        assert len(headings) >= 1


class TestExtractionFailures:
    def test_invalid_base64_is_reported_not_hidden(self):
        from adapters.documents import try_extract_text

        text, error = try_extract_text("@@not base64@@", "pdf", output_kind="base64")
        assert text == ""
        assert "invalid base64" in error

    def test_extract_text_logs_and_returns_empty(self):
        from core_helpers import capture_logs

        with capture_logs("eval_service.adapters.documents") as records:
            assert extract_text("@@", "docx", output_kind="base64") == ""
        assert any("document extraction failed" in r.getMessage() for r in records)

    def test_url_without_client_is_an_error(self):
        from adapters.documents import try_extract_text

        _, error = try_extract_text("https://example.test/a.pdf", "pdf", output_kind="url")
        assert "HTTP client" in error


class TestHeadingsAndGoldenFiles:
    def test_markdown_headings_are_texts(self):
        assert parse_headings("# A\n## B two\nbody", "markdown") == ["A", "B two"]

    def test_missing_golden_file_raises(self, tmp_path):
        from adapters.golden_files import load_golden_file

        with pytest.raises(FileNotFoundError):
            load_golden_file("nope.txt", tmp_path)

    def test_golden_file_text_and_data_url(self, tmp_path):
        from adapters.golden_files import load_golden_file

        (tmp_path / "g.txt").write_text("golden", encoding="utf-8")
        assert load_golden_file("g.txt", tmp_path) == "golden"
        data_url = "data:text/plain;base64," + base64.b64encode(b"inline").decode()
        assert load_golden_file(data_url, tmp_path) == "inline"
        with pytest.raises(ValueError):
            load_golden_file("data:broken", tmp_path)
