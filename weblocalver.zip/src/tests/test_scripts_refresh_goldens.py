"""Tests for scripts/refresh_walkthrough_query_goldens.py using httpx.MockTransport."""

from __future__ import annotations

import json
import runpy
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))

import refresh_walkthrough_query_goldens as refresh

Handler = Callable[[httpx.Request], httpx.Response]
BASE = "http://agent/query-service"
SOURCE = {"sections": ["intro"]}


def _write(path: Path, data: Any) -> Path:
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


def _agent(seen: list[httpx.Request], upload: dict[str, Any] | None = None) -> Handler:
    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        if request.url.path.endswith("/qna/upload"):
            return httpx.Response(200, json=upload or {"gcs_uri": "gs://b/doc.json"})
        body = json.loads(request.read())
        return httpx.Response(200, json={"answer": f"re: {body['question']}"})

    return handler


@pytest.fixture
def use_transport(monkeypatch):
    """Make the script's httpx.Client use the given handler; returns the client kwargs seen."""
    real = httpx.Client
    captured: dict[str, Any] = {}

    def install(handler: Handler) -> dict[str, Any]:
        def factory(**kwargs: Any) -> httpx.Client:
            captured.update(kwargs)
            return real(transport=httpx.MockTransport(handler), **kwargs)

        monkeypatch.setattr(refresh.httpx, "Client", factory)
        return captured

    return install


@pytest.fixture
def inputs(tmp_path):
    dataset = _write(tmp_path / "dataset.json", {"cases": [
        {"id": "c1", "input": {"question": "Q1"}},
        {"id": "c2", "input": {"question": "Q2", "researchSections": {"own": True}}},
        "not-a-case",
    ]})
    source = _write(tmp_path / "source.json", SOURCE)
    out = tmp_path / "out.json"
    argv = ["--base-url", BASE + "/", "--dataset", str(dataset), "--source-document", str(source),
            "--output", str(out)]
    return argv, out


def test_main_replays_every_case_and_writes_output(inputs, use_transport, capsys):
    argv, out = inputs
    seen: list[httpx.Request] = []
    client_kwargs = use_transport(_agent(seen))
    assert refresh.main(argv) == refresh.EXIT_OK
    assert client_kwargs["verify"] is False and client_kwargs["trust_env"] is False
    assert [r.url.path for r in seen] == ["/query-service/qna/upload"] + ["/query-service/qna/chat"] * 2
    first, second = (json.loads(r.read()) for r in seen[1:])
    assert first["researchSections"] == SOURCE and first["contextGcsUri"] == "gs://b/doc.json"
    assert second["researchSections"] == {"own": True}
    written = json.loads(out.read_text(encoding="utf-8"))
    assert [r["answer"] for r in written["results"]] == ["re: Q1", "re: Q2"]
    assert written["upload"]["gcs_uri"] == "gs://b/doc.json"
    assert "[c1] re: Q1" in capsys.readouterr().out


@pytest.mark.parametrize(("payload", "expected"), [
    ({"gcs_blob_path": "eval/x.json"}, "eval/x.json"),
    ({}, refresh.UPLOAD_BLOB_PATH),
])
def test_upload_gcs_uri_fallbacks(payload, expected):
    client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, json=payload)))
    assert refresh.upload_document(client, BASE, SOURCE)["gcs_uri"] == expected


def test_upload_empty_body_uses_default_path():
    client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(204)))
    assert refresh.upload_document(client, BASE, SOURCE)["response"] == {}


class TestFailures:
    def test_no_cases(self, tmp_path, capsys):
        dataset = _write(tmp_path / "d.json", {"cases": []})
        source = _write(tmp_path / "s.json", SOURCE)
        assert refresh.main(["--dataset", str(dataset), "--source-document", str(source)]) == refresh.EXIT_NO_CASES
        assert "No cases found" in capsys.readouterr().err

    @pytest.mark.parametrize(("content", "message"), [
        (None, "cannot read"),
        ("{not json", "cannot read"),
        ("[1, 2]", "must contain a JSON object, got list"),
    ])
    def test_unreadable_dataset(self, tmp_path, capsys, content, message):
        dataset = tmp_path / "d.json"
        if content is not None:
            dataset.write_text(content, encoding="utf-8")
        assert refresh.main(["--dataset", str(dataset)]) == refresh.EXIT_FAILED
        assert message in capsys.readouterr().err

    def test_http_error_status(self, inputs, use_transport, capsys):
        argv, out = inputs
        use_transport(lambda r: httpx.Response(503, text="down"))
        assert refresh.main(argv) == refresh.EXIT_FAILED
        assert "answered HTTP 503" in capsys.readouterr().err
        assert not out.exists()

    def test_unreachable_agent(self, inputs, use_transport, capsys):
        argv, _ = inputs

        def refuse(request):
            raise httpx.ConnectError("name resolution failed", request=request)

        use_transport(refuse)
        assert refresh.main(argv) == refresh.EXIT_FAILED
        assert f"could not reach the agent at {BASE}/: name resolution failed" in capsys.readouterr().err

    @pytest.mark.parametrize(("response", "message"), [
        (httpx.Response(200, json={"answer": None}), "Case c1 returned no string answer"),
        (httpx.Response(200, text="<html>"), "returned non-JSON"),
        (httpx.Response(200, json=["a"]), "returned list, expected a JSON object"),
    ])
    def test_bad_chat_response(self, inputs, use_transport, capsys, response, message):
        argv, _ = inputs

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path.endswith("/qna/upload"):
                return httpx.Response(200, json={})
            return response

        use_transport(handler)
        assert refresh.main(argv) == refresh.EXIT_FAILED
        assert message in capsys.readouterr().err


def test_replay_case_tolerates_missing_id_and_input():
    client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, json={"answer": "a"})))
    result = refresh.replay_case(client, BASE, {}, SOURCE, "gs://x")
    assert (result.case_id, result.question, result.request["contextGcsUri"]) == ("", "", "gs://x")


def test_script_entry_point(monkeypatch, tmp_path):
    missing = tmp_path / "missing.json"
    monkeypatch.setattr(sys, "argv", ["refresh.py", "--dataset", str(missing)])
    with pytest.raises(SystemExit) as exc:
        runpy.run_path(refresh.__file__, run_name="__main__")
    assert exc.value.code == refresh.EXIT_FAILED
