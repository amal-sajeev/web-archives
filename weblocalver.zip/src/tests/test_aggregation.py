"""Unit tests for aggregation: gate, critical veto, normalisation, RunStats."""

from __future__ import annotations

import pytest

from core import aggregation
from core.models import CaseResult, MetricSpec, Observation, Score


def _score(metric, score, *, threshold=0.8, weight=1.0, critical=False, baseline=None):
    return Score(
        metric=metric, score=score, passed=score >= threshold, threshold=threshold,
        weight=weight, critical=critical, baseline=baseline,
        delta=(score - baseline) if baseline is not None else None,
    )


def test_weighted_score_and_delta():
    scores = [_score("a", 0.8, weight=1.0, baseline=0.6),
              _score("b", 1.0, weight=3.0, baseline=0.9)]
    assert aggregation.weighted_score(scores) == pytest.approx((0.8 + 3.0) / 4.0)
    # delta = ((0.8-0.6)*1 + (1.0-0.9)*3) / 4 = (0.2 + 0.3)/4
    assert aggregation.weighted_delta(scores) == pytest.approx(0.5 / 4.0)


def test_critical_failure_vetoes_run():
    """A failing critical metric fails the case even with a high weighted score."""
    scores = [_score("quality", 1.0, weight=5.0),
              _score("no_pii_leakage", 0.0, threshold=1.0, weight=1.0, critical=True)]
    passed, s, _d = aggregation.gate(scores, dataset_threshold=0.5, regression_tolerance=0.05)
    assert s > 0.5  # weighted score is high
    assert passed is False  # but the critical veto fails it


def test_gate_passes_when_all_conditions_met():
    scores = [_score("a", 0.9, weight=1.0, baseline=0.9),
              _score("b", 0.95, weight=2.0, baseline=0.9)]
    passed, _s, _d = aggregation.gate(scores, dataset_threshold=0.8, regression_tolerance=0.05)
    assert passed is True


def test_gate_fails_on_regression_beyond_tolerance():
    scores = [_score("a", 0.5, threshold=0.4, weight=1.0, baseline=0.95)]
    passed, _s, d = aggregation.gate(scores, dataset_threshold=0.4, regression_tolerance=0.05)
    assert d < -0.05 and passed is False


def test_normalise_lower_is_better_inverts():
    spec = MetricSpec(name="latency_slo", type="operational", scorer="latency_slo",
                      direction="lower_is_better", norm_min=0, norm_max=8000)
    assert aggregation.normalise(0, spec) == pytest.approx(1.0)
    assert aggregation.normalise(8000, spec) == pytest.approx(0.0)
    assert aggregation.normalise(4000, spec) == pytest.approx(0.5)


def _case(cid, wscore, wdelta, passed):
    return CaseResult(case_id=cid, scores=[], weighted_score=wscore,
                      weighted_delta=wdelta, passed=passed,
                      observation=Observation(target_id="t"))


def test_run_statistics_pass_rate_and_ci():
    cases = [_case("c1", 0.9, 0.0, True), _case("c2", 0.7, -0.1, False),
             _case("c3", 0.8, 0.05, True)]
    stats = aggregation.run_statistics(cases, labels={})
    assert stats.n_cases == 3
    assert stats.pass_rate == pytest.approx(2 / 3)
    assert stats.ci95_low <= stats.mean_score <= stats.ci95_high


def test_run_statistics_calibration_with_labels():
    """Gate pass/fail vs human labels → precision/recall/F1/κ populated."""
    cases = [_case("c1", 0.9, 0.0, True), _case("c2", 0.6, 0.0, False),
             _case("c3", 0.85, 0.0, True), _case("c4", 0.5, 0.0, False)]
    labels = {"c1": "pass", "c2": "fail", "c3": "fail", "c4": "fail"}
    stats = aggregation.run_statistics(cases, labels=labels)
    assert stats.labeled_cases == 4
    # tp=1 (c1), fp=1 (c3 predicted pass, labeled fail), fn=0, tn=2
    assert stats.precision == pytest.approx(0.5)
    assert stats.recall == pytest.approx(1.0)


def test_classification_stats_perfect_agreement():
    cls = aggregation.classification_stats([True, False, True], [True, False, True])
    assert cls["f1"] == pytest.approx(1.0)
    assert cls["cohens_kappa"] == pytest.approx(1.0)


def test_drift_significance_flags_real_regression():
    md, p, sig = aggregation.drift_significance([-0.2, -0.25, -0.22, -0.3, -0.18])
    assert md < 0 and p is not None and p < 0.05 and sig is True


def test_drift_significance_ignores_noise():
    _md, _p, sig = aggregation.drift_significance([0.1, -0.1, 0.05, -0.05])
    assert sig is False


# --- A1 scoring semantics ------------------------------------------------------

def _ratio_spec(**kw):
    return MetricSpec(name="m", type="deterministic", scorer="contains", **kw)


def test_normalise_always_clamps_and_maps_nan_to_zero():
    spec = _ratio_spec()
    assert aggregation.normalise(1.7, spec) == 1.0
    assert aggregation.normalise(-3, spec) == 0.0
    assert aggregation.normalise(float("nan"), spec) == 0.0


def test_normalise_lower_is_better_without_norm_max_is_skipped():
    from scorers.base import MetricSkipped

    spec = _ratio_spec(direction="lower_is_better", norm_min=0)
    with pytest.raises(MetricSkipped, match="norm_max"):
        aggregation.normalise(1200, spec)


def test_gate_fails_empty_scores():
    passed, s, d = aggregation.gate([], dataset_threshold=0.0, regression_tolerance=1.0)
    assert passed is False and s == 0.0 and d == 0.0


def test_gate_fails_when_critical_metric_skipped():
    from core.models import SkippedMetric

    scores = [_score("quality", 1.0)]
    skipped = [SkippedMetric(metric="pii", reason="no data", critical=True)]
    assert aggregation.gate(scores, skipped=skipped, dataset_threshold=0.5)[0] is False
    non_critical = [SkippedMetric(metric="tone", reason="offline")]
    assert aggregation.gate(scores, skipped=non_critical, dataset_threshold=0.5)[0] is True


def test_gate_reads_config_defaults_at_call_time(monkeypatch):
    from core.config import Config

    scores = [_score("a", 0.85)]
    monkeypatch.setattr(Config, "DATASET_THRESHOLD", 0.9)
    assert aggregation.gate(scores)[0] is False
    monkeypatch.setattr(Config, "DATASET_THRESHOLD", 0.8)
    assert aggregation.gate(scores)[0] is True


def test_drift_uses_sample_stdev_and_min_effect():
    # Consistent but tiny drop: statistically significant, not material.
    md, p, sig = aggregation.drift_significance([-0.001, -0.0011, -0.0009, -0.001])
    assert md < 0 and p < aggregation._ALPHA and sig is False


def test_drift_zero_variance_regression_is_significant():
    _md, p, sig = aggregation.drift_significance([-0.2, -0.2, -0.2])
    assert p == 0.0 and sig is True


def test_classification_stats_rejects_mismatched_lengths():
    with pytest.raises(ValueError):
        aggregation.classification_stats([True, False], [True])


def test_run_statistics_label_match_is_case_insensitive():
    cases = [_case("c1", 0.9, 0.0, True), _case("c2", 0.4, 0.0, False)]
    stats = aggregation.run_statistics(cases, labels={"c1": "PASS", "c2": " Fail "})
    assert stats.labeled_cases == 2
    assert stats.precision == pytest.approx(1.0)
    assert stats.recall == pytest.approx(1.0)


def _spec(**kw) -> MetricSpec:
    return MetricSpec(name="m", type="deterministic", scorer="s", **kw)


def test_higher_is_better_with_bounds_scales_linearly():
    assert aggregation.normalise(150, _spec(norm_min=100, norm_max=200)) == pytest.approx(0.5)
    assert aggregation.normalise(250, _spec(norm_min=100, norm_max=200)) == 1.0


def test_lower_is_better_with_degenerate_bounds_is_a_step():
    spec = _spec(direction="lower_is_better", norm_min=500, norm_max=500)
    assert aggregation.normalise(400, spec) == 1.0
    assert aggregation.normalise(600, spec) == 0.0


def test_empty_samples_have_neutral_statistics():
    assert aggregation.mean_confidence_interval([]) == (0.0, 0.0, 0.0, 0.0)
    assert aggregation.drift_significance([]) == (0.0, None, False)
