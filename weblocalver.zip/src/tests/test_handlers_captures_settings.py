"""Handler tests: captures, labels, runtime settings / TLS policy, UI pages."""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from adapters import capture_store
from core.config import Config
from core.models import LabelRequest
from handlers.captures import add_label, get_capture, get_label, list_captures, list_labels
from handlers.settings import TlsPolicyRequest, runtime_settings, set_tls_policy
from handlers.ui import HTML_MEDIA_TYPE, index


def test_list_and_get_captures():
    capture_store.put("c1", {"data": "one"})
    capture_store.put("c2", {"data": "two"})

    assert len(list_captures()["captures"]) == 2
    assert get_capture("c1") == {"case_id": "c1", "payload": {"data": "one"}}


def test_get_capture_404():
    with pytest.raises(HTTPException) as exc_info:
        get_capture("unknown")
    assert exc_info.value.status_code == 404


async def test_add_list_and_get_label():
    stored = await add_label(LabelRequest(case_id="c1", verdict="pass", labeler="me"))

    assert stored["case_id"] == "c1"
    assert stored["created_at"]
    assert [lbl["case_id"] for lbl in list_labels()["labels"]] == ["c1"]
    assert get_label("c1")["verdict"] == "pass"


async def test_labels_scoped_by_agent():
    await add_label(LabelRequest(case_id="c1", verdict="pass", labeler="me", agent_id="a"))
    await add_label(LabelRequest(case_id="c1", verdict="fail", labeler="me", agent_id="b"))

    assert [lbl["agent_id"] for lbl in list_labels(agent_id="a")["labels"]] == ["a"]
    assert get_label("c1", agent_id="b")["verdict"] == "fail"
    assert len(list_labels()["labels"]) == 2


def test_get_label_404():
    with pytest.raises(HTTPException) as exc_info:
        get_label("missing")
    assert exc_info.value.status_code == 404


def test_runtime_settings_reflects_config():
    result = runtime_settings()
    assert result["tls_verification_enabled"] is (not Config.EXCLUDE_TLS)


@pytest.mark.parametrize(("payload", "exclude"), [
    ({"enabled": True}, False),
    ({"enabled": "off"}, True),
    ({"exclude_tls": "yes"}, True),
    ({"exclude_tls": False}, False),
    (TlsPolicyRequest(enabled=False), True),
])
def test_set_tls_policy_accepts_bools_and_truthy_strings(payload, exclude):
    result = set_tls_policy(payload)
    assert result["exclude_tls"] is exclude
    assert Config.EXCLUDE_TLS is exclude


def test_set_tls_policy_requires_a_field():
    with pytest.raises(HTTPException) as exc_info:
        set_tls_policy({})
    assert exc_info.value.status_code == 400


def test_set_tls_policy_rejects_non_boolean():
    with pytest.raises(HTTPException) as exc_info:
        set_tls_policy({"enabled": "maybe"})
    assert exc_info.value.status_code == 422


def test_index_serves_html():
    response = index()
    assert response.media_type == HTML_MEDIA_TYPE
    assert b"<" in response.body
