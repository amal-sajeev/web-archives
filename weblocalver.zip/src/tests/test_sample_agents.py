"""End-to-end checks for the runnable sample agents in ``src/sample_agents``.

Each agent's FastAPI app is driven in-process (httpx ``ASGITransport``; the
pinned starlette ``TestClient`` is incompatible with httpx 0.28) for every
topic or case it knows about, so a broken canned data set (like the old 3-tuple
"Compliance Review" section) fails here instead of at demo time.
"""

from __future__ import annotations

import asyncio
import base64
import importlib
import sys
from pathlib import Path

import httpx
import pytest

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

_ENVELOPE_KEYS = {
    "target_id", "output", "tool_calls", "stage_trace", "source_context",
    "latency_ms", "usage", "model", "metadata", "error",
}


def _load(name: str):
    return importlib.import_module(f"sample_agents.{name}")


def _call(module, method: str, path: str, json: dict | None = None) -> httpx.Response:
    async def _go() -> httpx.Response:
        transport = httpx.ASGITransport(app=module.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://agent") as client:
            return await client.request(method, path, json=json)

    return asyncio.run(_go())


def _check_envelope(body: dict, target_id: str) -> None:
    assert set(body) >= _ENVELOPE_KEYS
    assert body["target_id"] == target_id
    assert body["error"] is None
    usage = body["usage"]
    assert usage["total_tokens"] == usage["input_tokens"] + usage["output_tokens"]
    assert body["tool_calls"]
    assert all(call["args"] for call in body["tool_calls"])


@pytest.mark.parametrize("name", [
    "data_extraction_agent", "report_writer_agent", "invoice_parser_agent", "document_qa_agent",
])
def test_health_lists_tools(name):
    module = _load(name)
    resp = _call(module, "GET", "/api/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok", "tools": sorted(module.TOOLS)}


_REPORT_TOPICS = [*_load("report_writer_agent").REPORTS, "Unknown topic"]


@pytest.mark.parametrize("topic", _REPORT_TOPICS)
def test_report_writer_every_topic(topic):
    module = _load("report_writer_agent")
    resp = _call(module, "POST", "/api/eval/report-writer", json={"topic": topic})
    assert resp.status_code == 200
    body = resp.json()
    _check_envelope(body, "report_writer")
    assert body["output"].startswith(f"# {topic}")
    assert body["output"].count("\n## ") == 3
    assert "-  " not in body["output"]  # no stray leading spaces in bullets


def test_report_writer_compliance_has_regulations():
    module = _load("report_writer_agent")
    body = _call(module, "POST", "/api/eval/report-writer", json={"topic": "Compliance Review"}).json()
    assert "- Dodd-Frank Act" in body["output"]
    assert "## Regulatory Scope" in body["output"]


@pytest.mark.parametrize(("query", "tool_name"), [
    ("Get FinLedger materiality for Acme Corp in 2024", "get_financial_data"),
    ("Show the ControlRegistry control for R12 ref 2024_01-02 in assessment unit Payments", "get_control_data"),
    ("Search for obligations imposed by the Dodd-Frank Act", "internet_search"),
    ("List AppCatalog apps for AU-100 under Globex", "get_application_data"),
    ("What is the weather?", "internet_search"),
])
def test_data_extraction_routes(query, tool_name):
    module = _load("data_extraction_agent")
    resp = _call(module, "POST", "/api/eval/data-extraction-agent", json={"query": query})
    assert resp.status_code == 200
    body = resp.json()
    _check_envelope(body, "data_extraction_agent")
    assert body["tool_calls"][0]["name"] == tool_name


def test_data_extraction_control_args():
    module = _load("data_extraction_agent")
    tool_name, args = module._route("Control for R7 ref 2023_04-05 in assessment unit Treasury")
    assert tool_name == "get_control_data"
    assert args == {"risk_id": "R7", "external_ref": "2023_04-05", "assessment_unit": "Treasury"}


@pytest.mark.parametrize(("invoice", "vendor", "total"), [
    ("acme_q1", "Acme Corp", 8000.0),
    ("globex_annual", "Globex Industries", 20000.0),
    ("initech_quarterly", "Initech Consulting", 13000.0),
    ("Invoice #X-1\nFrom: Raw Co\n- Widget : $10\nTotal: $10\n", "Raw Co", 10.0),
])
def test_invoice_parser_every_invoice(invoice, vendor, total):
    module = _load("invoice_parser_agent")
    resp = _call(module, "POST", "/api/eval/invoice-parser", json={"invoice_text": invoice})
    assert resp.status_code == 200
    body = resp.json()
    _check_envelope(body, "invoice_parser")
    parsed = body["output"]
    assert parsed["vendor"] == vendor
    assert parsed["total"] == total
    assert parsed["item_count"] == len(parsed["line_items"])


@pytest.mark.parametrize("topic", ["Risk Assessment", "Q1 Financial Summary", "Compliance Review"])
def test_document_qa_pdf(topic):
    module = _load("document_qa_agent")
    resp = _call(module, "POST", "/api/eval/document-qa", json={"document_type": "pdf", "topic": topic})
    assert resp.status_code == 200
    body = resp.json()
    _check_envelope(body, "document_qa")
    pdf = base64.b64decode(body["output"])
    assert pdf.startswith(b"%PDF-1.4")
    assert pdf.rstrip().endswith(b"%%EOF")
    assert body["answer"] == f"Generated a PDF report for {topic}."


@pytest.mark.parametrize("topic", ["Risk Assessment", "Q1 Financial Summary", "Compliance Review"])
def test_document_qa_docx(topic):
    pytest.importorskip("docx")
    module = _load("document_qa_agent")
    resp = _call(module, "POST", "/api/eval/document-qa", json={"document_type": "docx", "topic": topic})
    assert resp.status_code == 200
    assert base64.b64decode(resp.json()["output"]).startswith(b"PK")


def test_document_qa_rejects_unknown_type():
    module = _load("document_qa_agent")
    resp = _call(module, "POST", "/api/eval/document-qa", json={"document_type": "xlsx", "topic": "x"})
    assert resp.status_code == 422


def test_pdf_escapes_and_replaces_non_latin1():
    module = _load("document_qa_agent")
    pdf = module.build_pdf(["a\\b (c)", "snow ☃ man"])
    assert b"(a\\\\b \\(c\\)) Tj" in pdf
    assert b"(snow ? man) Tj" in pdf


def test_pdf_paginates_long_text():
    module = _load("document_qa_agent")
    lines = [f"line {i}" for i in range(module._LINES_PER_PAGE * 2 + 1)]
    pdf = module.build_pdf(lines)
    assert b"/Count 3" in pdf
    assert pdf.count(b"/Type /Page ") == 3
