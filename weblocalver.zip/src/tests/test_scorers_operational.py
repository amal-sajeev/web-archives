"""Operational SLO scorers, registration and groundedness context (moved from test_upgrades.py)."""

from __future__ import annotations

import pytest

from scorer_helpers import ScriptedJudge, case, obs
from scorers.base import MetricSkipped, all_scorers
from scorers.operational import latency_slo, response_success, token_cost_budget, tool_latency_slo
from scorers.safety import groundedness
from scorers.vertex import JudgeVerdict


class TestNewScorersRegistered:
    @pytest.mark.parametrize("name", ["rubric_multi", "pdf_table_has", "not_empty", "not_contains"])
    def test_registered(self, name):
        assert name in all_scorers()


class TestResponseSuccess:
    def test_missing_code_error_free_passes_without_fabricated_code(self):
        score, _, _, extras = response_success(observation=obs("ok", error=None), case=case(), metrics={})
        assert score == 1.0
        assert "raw_value" not in extras
        assert "response_code" not in extras

    def test_missing_code_with_error_fails(self):
        score, _, _, _ = response_success(observation=obs("", error="timeout"), case=case(), metrics={})
        assert score == 0.0

    def test_explicit_non_2xx_fails(self):
        score, _, _, extras = response_success(observation=obs("ok"), case=case(), metrics={"response_code": 500})
        assert score == 0.0
        assert extras == {"response_code": 500.0}

    def test_explicit_2xx_passes(self):
        score, _, _, _ = response_success(observation=obs("ok"), case=case(), metrics={"response_code": 201})
        assert score == 1.0


class TestSloScorers:
    def test_latency_from_metrics(self):
        _, _, _, extras = latency_slo(observation=obs("x"), case=case(), metrics={"execution_latency_ms": 250})
        assert extras["raw_value"] == 250.0

    def test_latency_falls_back_to_observation(self):
        _, _, _, extras = latency_slo(observation=obs("x", latency_ms=1200), case=case(), metrics={})
        assert extras["raw_value"] == 1200.0

    def test_latency_missing_skips(self):
        with pytest.raises(MetricSkipped):
            latency_slo(observation=obs("x", latency_ms=0), case=case(), metrics={})

    def test_tokens_from_usage_parts(self):
        observation = obs("x", usage={"input_tokens": 1800, "output_tokens": 500})
        _, _, _, extras = token_cost_budget(observation=observation, case=case(), metrics={})
        assert extras["raw_value"] == 2300.0

    def test_tokens_missing_skips(self):
        with pytest.raises(MetricSkipped):
            token_cost_budget(observation=obs("x"), case=case(), metrics={"token_total_count": "n/a"})

    def test_usage_total_tokens_preferred_over_parts(self):
        observation = obs("x", usage={"total_tokens": 90, "input_tokens": 1, "output_tokens": 1})
        assert token_cost_budget(observation=observation, case=case(), metrics={})[0] == 90.0

    def test_token_metric_wins_over_usage(self):
        observation = obs("x", usage={"total_tokens": 90})
        assert token_cost_budget(observation=observation, case=case(), metrics={"token_total_count": 12})[0] == 12.0

    def test_latency_without_metric_or_observation_skips(self):
        with pytest.raises(MetricSkipped, match="no metric and no observed latency"):
            latency_slo(observation=obs("x", latency_ms=0), case=case(), metrics={})

    def test_tool_latency_missing_skips(self):
        with pytest.raises(MetricSkipped):
            tool_latency_slo(observation=obs("x"), case=case(), metrics={})


class TestGroundednessContext:
    def test_no_context_skips(self):
        golden_case = case(input={"question": "q"})
        with pytest.raises(MetricSkipped, match="not applicable"):
            groundedness(observation=obs("hello"), case=golden_case)

    def test_research_sections_are_used(self, monkeypatch):
        def _raise():
            raise RuntimeError("no vertex")

        monkeypatch.setattr("scorers.safety.build_judge", _raise)
        golden_case = case(input={"researchSections": {"coverage": "medical"}})
        with pytest.raises(MetricSkipped, match="unavailable"):
            groundedness(observation=obs("hello"), case=golden_case)

    def test_shared_sampling_path(self, monkeypatch):
        judge = ScriptedJudge([JudgeVerdict(score=0.6, rationale="r"), JudgeVerdict(score=1.0)])
        monkeypatch.setattr("scorers.safety.build_judge", lambda: judge)
        golden_case = case(expected={"context": "Coverage: medical"})
        score, _, evidence, extras = groundedness(observation=obs("medical"), case=golden_case, judge_repetitions=2)
        assert score == pytest.approx(0.8)
        assert extras["variance"] == pytest.approx(0.04)
        assert any("samples=" in e for e in evidence)
        assert "SOURCE CONTEXT:\nCoverage: medical" in judge.prompts[0]
        assert "<agent_output>" in judge.prompts[0]

    def test_observation_source_context_wins(self, monkeypatch):
        judge = ScriptedJudge([JudgeVerdict(score=1.0)])
        monkeypatch.setattr("scorers.safety.build_judge", lambda: judge)
        observation = obs("x", source_context="from the agent")
        groundedness(observation=observation, case=case(expected={"context": "from the case"}))
        assert "from the agent" in judge.prompts[0]
        assert "from the case" not in judge.prompts[0]

    def test_context_is_truncated(self, monkeypatch):
        judge = ScriptedJudge([JudgeVerdict(score=1.0)])
        monkeypatch.setattr("scorers.safety.build_judge", lambda: judge)
        monkeypatch.setattr("scorers.safety._MAX_CONTEXT_CHARS", 10)
        groundedness(observation=obs("x"), case=case(expected={"context": "y" * 50}))
        assert "y" * 11 not in judge.prompts[0]
        assert "[... truncated ...]" in judge.prompts[0]
