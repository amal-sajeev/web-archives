"""Response mapping of the config-driven HTTP adapter (adapters/http_response.py)."""

from __future__ import annotations

import httpx

from adapters.http_adapter import HttpAdapter
from adapters.http_response import map_response
from core.models import GoldenCase, ResponseMapping, TargetSpec
from core_helpers import mock_http_fixture  # noqa: F401

_BASE = "http://localhost:9999"
_CASE = GoldenCase(id="t1", input={})


def _map(body=None, *, content=None, headers=None, **mapping):
    if content is None:
        resp = httpx.Response(200, json=body, headers=headers)
    else:
        resp = httpx.Response(200, content=content, headers=headers)
    return map_response(resp, _CASE, ResponseMapping(**mapping), 12)


def test_output_path_extracts_value():
    obs = _map({"data": {"result": "extracted text"}}, output_path="data.result", content_type="text")
    assert obs.output == "extracted text"
    assert obs.error is None


def test_missing_output_path_sets_error():
    obs = _map({"data": {}}, output_path="data.result")
    assert obs.output is None
    assert "output_path 'data.result' not found" in obs.error


def test_output_path_on_non_json_response_sets_error():
    obs = _map(content=b"plain words", headers={"content-type": "text/plain"}, output_path="answer")
    assert obs.output == "plain words"
    assert "not JSON" in obs.error


def test_usage_tool_calls_and_latency_are_sanitised():
    body = {"out": "x", "usage": ["bad"], "calls": [{"name": "a"}, "b"], "lat": "not-a-number"}
    obs = _map(body, output_path="out", usage_path="usage", tool_calls_path="calls", latency_path="lat")
    assert obs.usage == {}
    assert obs.tool_calls == [{"name": "a"}, {"name": "b"}]
    assert obs.latency_ms == 12


def test_float_latency_and_rich_usage_are_kept():
    body = {"out": "x", "usage": {"input_tokens": 5, "detail": {"cached": 1}}, "lat": 812.5}
    obs = _map(body, output_path="out", usage_path="usage", latency_path="lat")
    assert obs.latency_ms == 812.5
    assert obs.usage["detail"] == {"cached": 1}


def test_negative_latency_falls_back_to_measured():
    obs = _map({"out": "x", "lat": -4}, output_path="out", latency_path="lat")
    assert obs.latency_ms == 12


def test_non_string_error_is_json_encoded():
    obs = _map({"out": "x", "err": {"code": 7}}, output_path="out", error_path="err")
    assert obs.error == '{"code": 7}'


def test_binary_pdf_without_output_path_uses_raw_body():
    pdf = b"%PDF-1.4 not really a pdf"
    obs = _map(content=pdf, headers={"content-type": "application/pdf"})
    assert obs.metadata["content_type"] == "pdf"
    assert obs.metadata["raw_output"] == pdf
    # Either extraction failed (recorded) or the parser library is missing.
    assert "extraction_error" in obs.metadata or obs.output == pdf


async def test_auto_maps_source_context_field(mock_http):
    mock_http(lambda request: httpx.Response(200, json={
        "output": "answer", "source_context": {"coverage": "medical"},
    }))
    target = TargetSpec(adapter="http", endpoint="/test", response=ResponseMapping(output_path="output"))
    obs = await HttpAdapter(_BASE, "/test", target).run_case(GoldenCase(id="t1", input={"query": "hello"}))

    assert obs.output == "answer"
    assert obs.source_context == {"coverage": "medical"}


def test_real_pdf_body_is_replaced_by_its_text():
    from utils import build_text_pdf

    pdf = build_text_pdf(["Quarterly summary"])
    obs = _map(content=pdf, headers={"content-type": "application/pdf"})
    assert "Quarterly summary" in obs.output
    assert obs.metadata["extracted_text"] == obs.output
    assert "extraction_error" not in obs.metadata


def test_agent_supplied_text_for_a_pdf_is_kept_as_is():
    obs = _map({"text": "already extracted"}, output_path="text", content_type="pdf")
    assert obs.output == "already extracted"
    assert "raw_output" not in obs.metadata


def test_missing_parser_library_keeps_raw_output(monkeypatch):
    from adapters import http_response
    from adapters.documents import DocUnavailable

    def _missing(*_a, **_kw):
        raise DocUnavailable("pypdf is not installed")

    monkeypatch.setattr(http_response, "try_extract_text", _missing)
    obs = _map(content=b"%PDF-1.4", headers={"content-type": "application/pdf"})
    assert obs.output == b"%PDF-1.4"
    assert obs.metadata["extraction_error"] == "pypdf is not installed"


def test_source_context_path_and_non_json_body():
    obs = _map({"out": "a", "ctx": {"docs": [1]}}, output_path="out", source_context_path="ctx.docs")
    assert obs.source_context == [1]
    plain = _map(content=b"words", headers={"content-type": "text/plain"})
    assert plain.source_context is None


def test_http_error_with_empty_body_uses_reason_phrase():
    from adapters.http_response import error_observation

    request = httpx.Request("POST", "http://agent/x")
    response = httpx.Response(503, request=request)
    exc = httpx.HTTPStatusError("boom", request=request, response=response)
    assert error_observation("c1", exc).error == "HTTP 503: Service Unavailable"
