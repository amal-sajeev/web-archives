"""HTTP contract tests for the second-pass API additions.

Covers the fields the UI codes against: ``error_detail`` / ``agent_name`` on run
lists and details, ``enabled`` / ``include_disabled`` on agents, and
``GET /api/runs/summary``.
"""

from __future__ import annotations

from conftest import fake_agent
from handlers.runs import encode_cursor


def _day(day: int, hour: int = 0) -> str:
    return f"2026-01-{day:02d}T{hour:02d}:00:00+00:00"


def _seed(api, make_run):
    """agent-1: PASS 0.9 (d1), FAIL 0.3 (d2), cancelled (d3); unknown agent 'ghost': ERROR (d4)."""
    api.repo.save_run(make_run("p1", status="PASS", score=0.9, creation_ts=_day(1), cases=[("c1", True, 0.9)]))
    api.repo.save_run(make_run("f1", status="FAIL", score=0.3, creation_ts=_day(2)))
    api.repo.save_run(make_run("x1", status="ERROR", score=0.0, creation_ts=_day(3), error_detail="cancelled"))
    api.repo.save_run(make_run("e1", agent_id="ghost", status="ERROR", score=0.0, creation_ts=_day(4),
                               error_detail="RuntimeError: boom"))


async def test_run_list_items_carry_error_detail_and_agent_name(api, make_run):
    _seed(api, make_run)

    rows = {r["run_id"]: r for r in (await api.client.get("/api/runs")).json()["runs"]}

    assert rows["x1"]["error_detail"] == "cancelled"
    assert rows["e1"]["error_detail"] == "RuntimeError: boom"
    assert rows["p1"]["error_detail"] is None
    assert rows["p1"]["agent_name"] == "agent-1 name"
    assert rows["e1"]["agent_name"] is None  # unknown to the registry
    assert rows["p1"]["case_count"] == 1  # existing fields kept


async def test_run_detail_has_agent_name_and_every_record_field(api, make_run):
    _seed(api, make_run)

    known = (await api.client.get("/api/runs/p1")).json()
    unknown = (await api.client.get("/api/runs/e1")).json()

    assert known["agent_name"] == "agent-1 name"
    assert unknown["agent_name"] is None
    assert {"run_id", "status", "case_results", "stats", "error_detail", "creation_ts"} <= set(known)
    assert unknown["error_detail"] == "RuntimeError: boom"


async def test_agents_enabled_flag_and_include_disabled(api):
    api.registry._agents["off"] = fake_agent("off", enabled=False)

    default = (await api.client.get("/api/agents")).json()["agents"]
    everything = (await api.client.get("/api/agents?include_disabled=true")).json()["agents"]

    assert [(a["agent_id"], a["enabled"]) for a in default] == [("agent-1", True), ("agent-2", True)]
    assert [(a["agent_id"], a["enabled"]) for a in everything] == [
        ("agent-1", True), ("agent-2", True), ("off", False),
    ]
    assert everything[2] == {
        "agent_id": "off", "name": "off name", "dataset_id": "off-ds", "dataset_version": "1",
        "cases": 1, "metrics": ["m1"], "enabled": False,
    }


async def test_summary_counts_average_latest_and_previous(api, make_run):
    _seed(api, make_run)

    body = (await api.client.get("/api/runs/summary")).json()

    assert {k: body[k] for k in ("total", "passed", "failed", "errored", "cancelled")} == {
        "total": 4, "passed": 1, "failed": 1, "errored": 1, "cancelled": 1,
    }
    assert body["average_score"] == 0.6  # (0.9 + 0.3) / 2: ERROR runs excluded
    assert body["latest"]["run_id"] == "e1"
    assert body["latest"]["agent_name"] is None
    assert body["previous"] is None  # 'ghost' has no earlier run


async def test_summary_filters_by_agent_and_since(api, make_run):
    _seed(api, make_run)

    body = (await api.client.get("/api/runs/summary?agent_id=agent-1&since=2026-01-02")).json()

    assert (body["total"], body["failed"], body["cancelled"], body["passed"]) == (2, 1, 1, 0)
    assert body["average_score"] == 0.3
    assert body["latest"]["run_id"] == "x1"
    assert body["latest"]["error_detail"] == "cancelled"
    assert body["latest"]["agent_name"] == "agent-1 name"
    # previous is the run right before latest for the same agent (since does not apply).
    assert body["previous"]["run_id"] == "f1"


async def test_summary_empty_and_dataset_filter(api, make_run):
    api.repo.save_run(make_run("a", dataset_id="other", creation_ts=_day(1)))

    empty = (await api.client.get("/api/runs/summary?dataset_id=ds-1")).json()

    assert empty == {
        "total": 0, "passed": 0, "failed": 0, "errored": 0, "cancelled": 0,
        "average_score": None, "latest": None, "previous": None,
    }


async def test_summary_route_is_not_a_run_id_and_validates_since(api):
    assert (await api.client.get("/api/runs/summary")).status_code == 200
    bad = await api.client.get("/api/runs/summary?since=yesterday")
    assert bad.status_code == 422
    assert bad.json()["detail"][0]["loc"] == ["query", "since"]


async def test_garbage_cursor_is_422_not_500(api):
    response = await api.client.get("/api/runs?before=not-a-cursor")
    assert response.status_code == 422
    assert response.json()["error_type"] == "validation_error"


async def test_legacy_timestamp_cursor_still_accepted(api, make_run):
    api.repo.save_run(make_run("old", creation_ts=_day(1)))
    api.repo.save_run(make_run("new", creation_ts=_day(2)))

    by_ts = (await api.client.get("/api/runs", params={"before": _day(2)})).json()
    by_cursor = (await api.client.get("/api/runs", params={"before": encode_cursor(_day(2), "new")})).json()

    assert [r["run_id"] for r in by_ts["runs"]] == ["old"]
    assert [r["run_id"] for r in by_cursor["runs"]] == ["old"]


async def test_promote_rejects_error_runs_409(api, make_run):
    api.repo.save_run(make_run("x1", status="ERROR", error_detail="cancelled", cases=[("c1", True, 0.9)]))

    response = await api.client.post("/api/baselines/promote/x1")

    assert response.status_code == 409
    assert response.json()["error_type"] == "conflict"
    assert api.repo.get_baseline("agent-1", "ds-1", "1", "m1") is None


async def test_labels_and_captures_paging(api):
    from adapters import capture_store

    for i in range(3):
        await api.client.post("/api/labels", json={"case_id": f"c{i}", "verdict": "pass"})
        capture_store.put(f"c{i}", {"i": i}, agent_id="agent-1")

    labels = (await api.client.get("/api/labels?limit=2&offset=1")).json()
    captures = (await api.client.get("/api/captures?limit=1&agent_id=agent-1")).json()

    assert labels["total"] == 3
    assert len(labels["labels"]) == 2
    assert captures["total"] == 3
    assert captures["captures"] == [{"case_id": "c0", "payload": {"i": 0}}]
    assert (await api.client.get("/api/labels?limit=0")).status_code == 422
    assert (await api.client.get("/api/captures?offset=-1")).status_code == 422


async def test_label_request_validation(api):
    assert (await api.client.post("/api/labels", json={"case_id": "", "verdict": "pass"})).status_code == 422
    too_long = {"case_id": "c", "verdict": "pass", "note": "x" * 5000}
    assert (await api.client.post("/api/labels", json=too_long)).status_code == 422


async def test_evaluate_rejects_empty_agent_id(api):
    assert (await api.client.post("/api/evaluate/start", json={"agent_id": ""})).status_code == 422
