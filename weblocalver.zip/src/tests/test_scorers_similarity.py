"""Reference-based scorers (similarity.py) and output rendering (output_text.py)."""

from __future__ import annotations

import pytest

from scorer_helpers import case, obs, run
from scorers import MetricSkipped, similarity
from scorers.output_text import render_output_text
from utils import build_text_pdf

GOLDEN = case(golden_output="the quick brown fox")


# ---------- render_output_text ----------

def test_render_passes_strings_and_none_through():
    assert render_output_text("plain") == "plain"
    assert render_output_text(None) == ""


def test_render_single_report_with_title():
    report = {"report_title": "Summary", "paragraphs": [{"content": "One."}, "Two.", {"text": " "}, None]}
    assert render_output_text(report) == "Summary\n\nOne.\n\nTwo."


def test_render_single_report_without_title_is_body_only():
    assert render_output_text({"paragraphs": [{"paragraph": "Only."}]}) == "Only."


def test_render_bundle_uses_key_when_title_missing():
    bundle = {
        "scope": {"paragraphs": [{"content": "A"}]},
        "risks": {"report_title": "Risks", "paragraphs": ["B"]},
        "meta": {"version": 2},
    }
    assert render_output_text(bundle) == "scope\n\nA\n\n\nRisks\n\nB"


def test_render_unrecognised_shapes_as_json():
    assert render_output_text({"a": "é"}) == '{"a": "é"}'
    assert render_output_text([1, 2]) == "[1, 2]"


def test_render_bytes_extracts_document_text():
    pdf = build_text_pdf("Hello from a PDF")
    assert "Hello from a PDF" in render_output_text(pdf)


def test_render_unreadable_bytes_gives_placeholder(monkeypatch):
    def _boom(raw, kind):
        raise ValueError("corrupt")

    monkeypatch.setattr("adapters.documents.extract_text", _boom)
    assert render_output_text(bytearray(b"%PDF-garbage")) == "[binary document: text could not be extracted]"


# ---------- token_overlap_f1 / edit_similarity ----------

def test_f1_identical_text_scores_one():
    score, rationale, _ = run("token_overlap_f1", obs("The QUICK brown fox"), GOLDEN)
    assert score == pytest.approx(1.0)
    assert rationale.startswith("token F1=1.000")


def test_f1_empty_output_and_no_overlap():
    assert run("token_overlap_f1", obs(""), GOLDEN)[0] == 0.0
    assert run("token_overlap_f1", obs("lazy dog"), GOLDEN)[1] == "no token overlap with golden"


def test_reference_scorers_skip_without_golden():
    for name in ("token_overlap_f1", "edit_similarity", "embedding_similarity"):
        with pytest.raises(MetricSkipped, match="no golden_output"):
            run(name, obs("x"), case())


def test_edit_similarity_ratio():
    score, _, evidence = run("edit_similarity", obs("the quick brown fax"), GOLDEN)
    assert 0.9 < score < 1.0
    assert evidence == ["len_output=19 len_golden=19"]


# ---------- embedding_similarity ----------

def _embed_with(monkeypatch, vectors):
    seen: list[list[str]] = []

    def _fake(texts):
        seen.append(texts)
        if isinstance(vectors, Exception):
            raise vectors
        return vectors

    monkeypatch.setattr(similarity, "embed_texts", _fake)
    return seen


def test_embedding_cosine_of_parallel_vectors(monkeypatch):
    seen = _embed_with(monkeypatch, [[1.0, 2.0], [2.0, 4.0]])
    score, rationale, _ = run("embedding_similarity", obs({"paragraphs": ["fox"]}), GOLDEN)
    assert score == pytest.approx(1.0)
    assert rationale == "embedding cosine=1.000"
    assert seen == [["fox", "the quick brown fox"]]


def test_embedding_negative_cosine_clamps_to_zero(monkeypatch):
    _embed_with(monkeypatch, [[1.0, 0.0], [-1.0, 0.0]])
    assert run("embedding_similarity", obs("x"), GOLDEN)[0] == 0.0


def test_embedding_zero_vector_scores_zero(monkeypatch):
    _embed_with(monkeypatch, [[0.0, 0.0], [1.0, 1.0]])
    assert run("embedding_similarity", obs("x"), GOLDEN)[0] == 0.0


def test_embedding_blank_output_scores_zero_without_calling_model(monkeypatch):
    seen = _embed_with(monkeypatch, [[1.0], [1.0]])
    assert run("embedding_similarity", obs("   "), GOLDEN)[:2] == (0.0, "empty output to compare")
    assert seen == []


@pytest.mark.parametrize(("vectors", "reason"), [
    (RuntimeError("no ADC"), "embeddings unavailable: no ADC"),
    ([[1.0]], "fewer than two vectors"),
    (None, "fewer than two vectors"),
    ([[1.0, 2.0], [1.0]], "vector sizes differ (2 vs 1)"),
])
def test_embedding_skips_when_vectors_unusable(monkeypatch, vectors, reason):
    _embed_with(monkeypatch, vectors)
    with pytest.raises(MetricSkipped) as err:
        run("embedding_similarity", obs("x"), GOLDEN)
    assert reason in err.value.reason
