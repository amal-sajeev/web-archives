"""Scriptable SQLAlchemy engine/connection fakes for the Postgres repository tests.

No database is involved: ``FakeConnection.execute`` records every statement and
its bound parameters, then returns whatever the test's ``responder`` produces.
Import the ``pg`` fixture with ``from pg_fakes import pg_fixture  # noqa: F401``.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import contextmanager
from typing import Any

import pytest


class FakeResult:
    """The subset of ``CursorResult`` the repository uses."""

    def __init__(self, *, scalar: Any = None, row: Any = None, rows: list[dict] | None = None,
                 rowcount: int = 0) -> None:
        self._scalar = scalar
        self._row = row
        self._rows = rows or []
        self.rowcount = rowcount

    def scalar(self) -> Any:
        return self._scalar

    def fetchone(self) -> Any:
        return self._row

    def mappings(self) -> FakeResult:
        return self

    def all(self) -> list[dict]:
        return list(self._rows)

    def one(self) -> dict:
        assert len(self._rows) == 1, "expected exactly one row"
        return self._rows[0]


Responder = Callable[[str, dict[str, Any] | None], FakeResult]


class FakeConnection:
    def __init__(self, responder: Responder) -> None:
        self.responder = responder
        self.executed: list[tuple[str, dict[str, Any] | None]] = []

    def execute(self, statement: Any, params: dict[str, Any] | None = None) -> FakeResult:
        sql = str(statement)
        self.executed.append((sql, params))
        return self.responder(sql, params)


class FakeEngine:
    """``engine.begin()`` yields one shared FakeConnection; ``fail`` makes it raise."""

    def __init__(self) -> None:
        self.responder: Responder = lambda _sql, _params: FakeResult()
        self.conn = FakeConnection(lambda sql, params: self.responder(sql, params))
        self.fail: Exception | None = None
        self.disposed = False
        self.kwargs: dict[str, Any] = {}

    @contextmanager
    def begin(self) -> Iterator[FakeConnection]:
        if self.fail is not None:
            raise self.fail
        yield self.conn

    def dispose(self) -> None:
        self.disposed = True

    @property
    def statements(self) -> list[str]:
        return [sql for sql, _ in self.conn.executed]


@pytest.fixture(name="pg")
def pg_fixture(monkeypatch: pytest.MonkeyPatch) -> FakeEngine:
    """Configure TCP (Auth Proxy) mode and route ``create_engine`` to a FakeEngine."""
    from core.config import Config
    from repository import _pg_engine

    engine = FakeEngine()

    def _create_engine(url: str, **kwargs: Any) -> FakeEngine:
        engine.kwargs = {"url": url, **kwargs}
        return engine

    monkeypatch.setattr(_pg_engine, "create_engine", _create_engine)
    monkeypatch.setattr(Config, "DB_NAME", "evaldb")
    monkeypatch.setattr(Config, "DB_HOST", "127.0.0.1")
    monkeypatch.setattr(Config, "DB_PORT", 5432)
    monkeypatch.setattr(Config, "DB_USER", "runtime_user")
    monkeypatch.setattr(Config, "DB_PASSWORD", "pw")
    monkeypatch.setattr(Config, "DB_PASSWORD_SECRET", None)
    monkeypatch.setattr(Config, "DB_SCHEMA", "monitoring")
    return engine
