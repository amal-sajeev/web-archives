// Playground view switching and the Upload summary (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  DEFAULT_VIEW, VIEWS, initialView, normalizeView, tabNotes, viewForKey,
} from "../../main/static/js/playground/views-model.js";
import { bundleSummary, formatBytes, summaryHtml, unsavedNote } from "../../main/static/js/playground/upload-model.js";

const NAME = "Report writer";

test("views are Upload, Editor and Runner; unknown names fall back to Upload", () => {
  assert.deepEqual([...VIEWS], ["upload", "editor", "runner"]);
  assert.equal(DEFAULT_VIEW, "upload");
  assert.equal(normalizeView("runner"), "runner");
  assert.equal(normalizeView("steps"), "upload");
  assert.equal(normalizeView(undefined), "upload");
});

test("initialView follows the hash, else what is loaded", () => {
  assert.equal(initialView("#runner", false), "runner");
  assert.equal(initialView("editor", false), "editor");
  assert.equal(initialView("", true), "editor");
  assert.equal(initialView("#nope", false), "upload");
  assert.equal(initialView(null, false), "upload");
});

test("arrow keys wrap around; Home and End jump; other keys do nothing", () => {
  assert.equal(viewForKey("upload", "ArrowRight"), "editor");
  assert.equal(viewForKey("runner", "ArrowRight"), "upload");
  assert.equal(viewForKey("upload", "ArrowLeft"), "runner");
  assert.equal(viewForKey("editor", "ArrowLeft"), "upload");
  assert.equal(viewForKey("runner", "Home"), "upload");
  assert.equal(viewForKey("upload", "End"), "runner");
  assert.equal(viewForKey("bogus", "ArrowRight"), "editor");
  assert.equal(viewForKey("upload", "Enter"), null);
  assert.equal(viewForKey("upload", "ArrowDown"), null);
});

test("tab notes say what each view holds", () => {
  const empty = tabNotes({ loaded: false });
  const first = "Load settings first";
  assert.deepEqual(empty, { upload: "Nothing loaded yet", editor: first, runner: first });
  const loaded = tabNotes({ loaded: true, assistant: NAME, fileCount: 1, runCount: 0 });
  assert.equal(loaded.upload, `${NAME} loaded`);
  assert.equal(loaded.editor, "1 file");
  assert.equal(loaded.runner, "No evaluations yet");
  const busy = tabNotes({ loaded: true, dirty: true, running: true, runningText: "Running… 1 of 2 tests done", runCount: 3 });
  assert.equal(busy.upload, "Settings loaded");
  assert.equal(busy.editor, "Unsaved changes");
  assert.equal(busy.runner, "Running… 1 of 2 tests done");
  assert.equal(tabNotes({ loaded: true, running: true }).runner, "Running…");
  assert.equal(tabNotes({ loaded: true, runCount: 2, fileCount: 4 }).runner, "2 evaluations");
  assert.equal(tabNotes().upload, "Nothing loaded yet");
});

test("formatBytes reads plainly", () => {
  assert.equal(formatBytes(1), "1 byte");
  assert.equal(formatBytes(512), "512 bytes");
  assert.equal(formatBytes(2048), "2.0 KB");
  assert.equal(formatBytes(3 * 1024 * 1024), "3.0 MB");
  assert.equal(formatBytes(undefined), "0 bytes");
});

test("bundleSummary describes the AI assistant, tests, checks and files", () => {
  const summary = bundleSummary({
    agent: { agent_id: "rw", name: NAME, base_url: "http://x", dataset_file: "data.json" },
    dataset: { dataset_id: "rw-set", version: "2", cases: 4, metrics: 6 },
    customTests: { present: true, declared_scorers: ["tone"] },
    files: { "data.json": { kind: "text", size: 10 }, "agent.yaml": { kind: "text", size: 2048 }, "logo.png": { kind: "binary", size: 5 }, "x.txt": { kind: "text", size: 0 } },
  });
  assert.equal(summary.assistant, NAME);
  assert.equal(summary.tests, "4");
  assert.equal(summary.checks, "6");
  assert.equal(summary.testSet, "rw-set (version 2)");
  assert.equal(summary.extraChecks, "tone");
  assert.equal(summary.fileCount, 4);
  assert.deepEqual(summary.files.map((file) => file.path), ["agent.yaml", "data.json", "logo.png", "x.txt"]);
  assert.equal(summary.files[1].role, "The tests and checks");
  assert.equal(summary.files[2].role, "Not a text file");
  assert.equal(summary.files[3].role, "Other file");
  const empty = bundleSummary();
  assert.equal(empty.assistant, "AI assistant");
  assert.equal(empty.tests, "—");
  assert.equal(empty.extraChecks, "None");
  assert.equal(empty.address, "Not set in agent.yaml");
  assert.equal(bundleSummary({ dataset: { dataset_id: "d" }, customTests: { present: true, syntax_error: "line 1" } }).extraChecks, "Has a mistake");
  assert.equal(bundleSummary({ customTests: { present: true } }).extraChecks, "File found, none named");
  assert.equal(bundleSummary({ dataset: { dataset_id: "d" } }).testSet, "d");
});

test("summaryHtml escapes every value and lists the files", () => {
  const html = summaryHtml(bundleSummary({ agent: { name: "<b>Bot</b>" }, files: { "a<.txt": { kind: "text", size: 3 } } }));
  assert.match(html, /&lt;b&gt;Bot&lt;\/b&gt;/);
  assert.doesNotMatch(html, /<b>Bot/);
  assert.match(html, /a&lt;\.txt/);
  assert.match(html, /Files \(1\)/);
  assert.match(summaryHtml(bundleSummary({})), /There are no files/);
});

test("unsavedNote explains whether edits are kept in a file", () => {
  assert.equal(unsavedNote({ loaded: false }), null);
  assert.equal(unsavedNote(), null);
  assert.equal(unsavedNote({ loaded: true, dirty: false }).tone, "info");
  assert.equal(unsavedNote({ loaded: true, dirty: true, saved: true }).tone, "ok");
  const warn = unsavedNote({ loaded: true, dirty: true, saved: false });
  assert.equal(warn.tone, "warn");
  assert.match(warn.text, /Download current settings/);
});
