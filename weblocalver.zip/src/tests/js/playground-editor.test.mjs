// Playground editor rules and find/replace (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  byteLength, cleanPath, fileRole, isTextPath, languageFor, lineCount, localValidation, selectionLabel, summarizeCase,
} from "../../main/static/js/playground/editor-model.js";
import { findMatch, replaceAll, selectionMatches } from "../../main/static/js/playground/find-core.js";

// Expected fallbacks log at debug/warn level; keep the test output readable.
console.debug = () => {};
console.warn = () => {};

test("languageFor and fileRole", () => {
  assert.equal(languageFor("agent.yaml"), "YAML");
  assert.equal(languageFor("x.yml"), "YAML");
  assert.equal(languageFor("DATA.JSON"), "JSON");
  assert.equal(languageFor("custom_tests.py"), "Python");
  assert.equal(languageFor("notes"), "Plain text");
  assert.equal(languageFor(null), "Plain text");
  assert.equal(fileRole("agent.yaml"), "Describes the AI assistant");
  assert.equal(fileRole("folder/dataset.json"), "The tests and checks");
  assert.equal(fileRole("golden.json", "golden.json"), "The tests and checks");
  assert.equal(fileRole("custom_tests.py"), "Extra checks");
  assert.equal(fileRole("metrics_stub.json"), "Check settings");
  assert.equal(fileRole("notes.txt"), "");
  assert.equal(fileRole(undefined), "");
});

test("localValidation checks JSON and explains the rest", () => {
  assert.deepEqual(localValidation('{"a":1}', "JSON"), { tone: "ok", text: "✓ No formatting problems" });
  const bad = localValidation("{", "JSON");
  assert.equal(bad.tone, "warn");
  assert.match(bad.text, /^! Formatting problem: /);
  assert.match(localValidation("", "Python").text, /Check settings/);
  assert.match(localValidation("", "YAML").text, /Check settings/);
  assert.deepEqual(localValidation("", "Plain text"), { tone: "info", text: "" });
});

test("lineCount, cleanPath, isTextPath, byteLength", () => {
  assert.equal(lineCount("a\nb\nc"), 3);
  assert.equal(lineCount(""), 1);
  assert.equal(lineCount(null), 1);
  assert.equal(cleanPath("  \\docs\\a.txt "), "docs/a.txt");
  assert.equal(cleanPath("///x"), "x");
  assert.equal(cleanPath(undefined), "");
  assert.equal(isTextPath("a.YAML"), true);
  assert.equal(isTextPath("logo.png"), false);
  assert.equal(isTextPath(null), false);
  assert.equal(byteLength("é"), 2);
  assert.equal(byteLength(null), 0);
});

test("summarizeCase previews strings and objects", () => {
  assert.equal(summarizeCase("hello"), "hello");
  assert.equal(summarizeCase({ q: 1 }), '{"q":1}');
  assert.equal(summarizeCase("x".repeat(100)), `${"x".repeat(80)}…`);
  assert.equal(summarizeCase(undefined), "");
  const loop = {};
  loop.self = loop;
  assert.equal(summarizeCase(loop), "");
});

test("selectionLabel", () => {
  assert.equal(selectionLabel(3, 4), "3 of 4 tests selected");
  assert.equal(selectionLabel(1, 1), "1 of 1 test selected");
});

test("findMatch ignores case and wraps to the top", () => {
  assert.deepEqual(findMatch("Abc abc", "ABC", 1), { start: 4, end: 7, wrapped: false });
  assert.deepEqual(findMatch("Abc abc", "abc", 6), { start: 0, end: 3, wrapped: true });
  assert.equal(findMatch("abc", "zzz"), null);
  assert.equal(findMatch("abc", ""), null);
  assert.deepEqual(findMatch("abc", "a", -5), { start: 0, end: 1, wrapped: false });
});

test("replaceAll counts replacements and keeps other text", () => {
  assert.deepEqual(replaceAll("a-A-a", "a", "b"), { text: "b-b-b", count: 3 });
  assert.deepEqual(replaceAll("none", "x", "y"), { text: "none", count: 0 });
  assert.deepEqual(replaceAll("keep", "", "y"), { text: "keep", count: 0 });
});

test("selectionMatches", () => {
  assert.equal(selectionMatches("Hello", 0, 5, "hello"), true);
  assert.equal(selectionMatches("Hello", 0, 4, "hello"), false);
  assert.equal(selectionMatches("Hello", 0, 5, ""), false);
});
