// Playground workspace serialisation and edit detection (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import * as model from "../../main/static/js/playground/workspace-model.js";
import * as store from "../../main/static/js/playground/store.js";

const DATASET = { case_items: [{ id: "a" }, { id: "b" }] };

test("snapshot keeps only workspace fields, never session state", () => {
  const source = {
    ...model.emptyWorkspace(), ...model.emptySession(),
    files: { "agent.yaml": { content: "x", kind: "text", size: 1 } },
    stream: "s1", lastRun: { run_id: "r" }, environment: { a: 1 }, check: { ok: true }, saved: true,
  };
  const snap = model.snapshot(source);
  assert.deepEqual(Object.keys(snap).sort(), [...model.PERSISTED_KEYS].sort());
  assert.equal(snap.stream, undefined);
  assert.equal(snap.check, undefined);
  snap.files["agent.yaml"].content = "changed";
  assert.equal(source.files["agent.yaml"].content, "x", "snapshot is a deep copy");
});

test("applySnapshot restores the workspace and resets the session", () => {
  const target = { stream: "old", runs: [1], check: { ok: true } };
  model.applySnapshot({ files: { f: { content: "1" } }, dataset: DATASET, stream: "ignored" }, target);
  assert.equal(target.stream, null);
  assert.deepEqual(target.runs, []);
  assert.equal(target.check, null);
  assert.deepEqual(target.original, { f: { content: "1" } });
  assert.deepEqual(target.selectedCases, ["a", "b"]);
  const broken = model.applySnapshot({ files: [], selectedCases: "x", warnings: null, original: [] }, {});
  assert.deepEqual(broken.files, {});
  assert.deepEqual(broken.selectedCases, []);
  assert.deepEqual(broken.warnings, []);
  assert.deepEqual(model.applySnapshot(null, {}).files, {});
});

test("normalizeState and resetState", () => {
  const t = model.normalizeState({ files: null, selectedCases: null, warnings: "x", runs: {} });
  assert.deepEqual([t.files, t.selectedCases, t.warnings, t.runs], [{}, [], [], []]);
  const r = model.resetState({ files: { a: 1 }, stream: "x" });
  assert.deepEqual(r.files, {});
  assert.equal(r.stream, null);
});

test("file helpers: sortedPaths, fileItems, toFiles, cloneFiles, caseIds", () => {
  assert.deepEqual(model.sortedPaths({ b: 1, a: 2 }), ["a", "b"]);
  assert.deepEqual(model.sortedPaths(null), []);
  assert.deepEqual(model.fileItems({ a: { content: "x" } }), [{ path: "a", content: "x" }]);
  assert.deepEqual(model.fileItems(undefined), []);
  const files = model.toFiles([{ path: "a", content: "x", encoding: "utf-8", kind: "text", size: 1, extra: true }]);
  assert.deepEqual(files, { a: { content: "x", encoding: "utf-8", kind: "text", size: 1 } });
  assert.deepEqual(model.toFiles(null), {});
  assert.deepEqual(model.cloneFiles(null), {});
  assert.deepEqual(model.caseIds(DATASET), ["a", "b"]);
  assert.deepEqual(model.caseIds({}), []);
});

test("isDirty detects edits, additions and deletions", () => {
  const original = { a: { content: "1", kind: "text", size: 1 } };
  assert.equal(model.isDirty(model.cloneFiles(original), original), false);
  assert.equal(model.isDirty({ a: { content: "2", kind: "text", size: 1 } }, original), true);
  assert.equal(model.isDirty({ ...original, b: { content: "" } }, original), true);
  assert.equal(model.isDirty({}, original), true);
  assert.equal(model.isDirty(null, null), false);
});

test("reconcileCases keeps known ids or falls back to all", () => {
  assert.deepEqual(model.reconcileCases(["b", "gone"], DATASET), ["b"]);
  assert.deepEqual(model.reconcileCases(["gone"], DATASET), ["a", "b"]);
  assert.deepEqual(model.reconcileCases(null, DATASET), ["a", "b"]);
});

test("store wrappers act on the shared page state", () => {
  store.resetState();
  store.applySnapshot({ files: { "b.txt": { content: "x", kind: "text", size: 1 }, "a.txt": { content: "y", kind: "text", size: 1 } } });
  assert.deepEqual(store.sortedPaths(), ["a.txt", "b.txt"]);
  assert.equal(store.fileItems().length, 2);
  assert.equal(store.isDirty(), false);
  store.state.files["a.txt"] = { content: "z", kind: "text", size: 1 };
  assert.equal(store.isDirty(), true);
  assert.equal(store.snapshot().files["a.txt"].content, "z");
  assert.deepEqual(store.normalizeState({}).files, {});
  store.resetState();
  assert.deepEqual(store.state.files, {});
  assert.equal(store.MAX_RUNS, 10);
});
