// Comparing two playground evaluations (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  CHOOSE_TWO_HTML, NEED_TWO_HTML, changeClass, comparisonHtml, metricChanges, runOptionLabel, scoreChange, scoreDelta,
} from "../../main/static/js/playground/compare-model.js";
import { environmentHtml } from "../../main/static/js/playground/environment.js";

const first = {
  status: "FAIL", weighted_score: 0.6, creation_ts: new Date(2026, 8, 27, 10, 0).toISOString(),
  case_results: [
    { case_id: "a", weighted_score: 0.5, scores: [{ metric: "contains", score: 0.5 }, { metric: "same", score: 1 }] },
    { case_id: "gone<", weighted_score: 0.4, scores: [] },
  ],
};
const second = {
  status: "PASS", weighted_score: 0.8,
  case_results: [
    { case_id: "a", weighted_score: 0.9, scores: [{ metric: "contains", score: 0.9 }, { metric: "same", score: 1 }] },
    { case_id: "new", weighted_score: 1, scores: [] },
  ],
};

test("scoreDelta only subtracts real scores", () => {
  assert.ok(Math.abs(scoreDelta(0.5, 0.9) - 0.4) < 1e-9);
  assert.equal(scoreDelta(null, 0.9), null);
  assert.equal(scoreDelta(0.5, undefined), null);
  assert.equal(scoreDelta("", 0.2), null);
  assert.equal(scoreDelta("x", 0.2), null);
});

test("scoreChange shows the relative percent change; changeClass gives direction", () => {
  assert.equal(scoreChange(0.2, 0.8), "+33.3%");
  assert.equal(scoreChange(-0.17, 0.79), "−17.7%");
  assert.equal(scoreChange(0, 0.8), "Unchanged");
  assert.equal(scoreChange(0.45, 0.45), "Up from 0%");
  assert.equal(scoreChange(null, 0.8), "Only in one");
  assert.equal(changeClass(0.1), "up");
  assert.equal(changeClass(-0.1), "down");
  assert.equal(changeClass(0), "same");
  assert.equal(changeClass(null), "");
});

test("metricChanges lists only changed checks", () => {
  const changes = metricChanges(first.case_results[0], second.case_results[0]);
  assert.equal(changes.length, 1);
  assert.ok(changes[0].title.length > 0);
  assert.deepEqual(metricChanges(undefined, undefined), []);
});

test("comparisonHtml shows first/second/change and escapes ids", () => {
  const html = comparisonHtml(first, second);
  assert.match(html, /First/);
  assert.match(html, /Second/);
  assert.match(html, /\+\d+\.\d%/);
  assert.doesNotMatch(html, /→/);
  assert.match(html, /Test gone&lt;/);
  assert.match(html, /Only in one/);
  assert.match(html, /Checks that changed/);
  assert.equal(comparisonHtml(first, first), CHOOSE_TWO_HTML);
  assert.equal(comparisonHtml(null, second), CHOOSE_TWO_HTML);
  assert.match(NEED_TWO_HTML, /at least two evaluations/);
});

test("runOptionLabel uses friendly date and verdict", () => {
  const now = new Date(2026, 8, 28, 12, 0);
  assert.match(runOptionLabel(first, now), /^Yesterday at .* · Needs attention · 60%$/);
  assert.equal(runOptionLabel({}, now), "Unknown time · Needs attention · —");
});

test("environmentHtml labels settings plainly and escapes values", () => {
  const html = environmentHtml({ judge_model: "<m>", auth_mode: "vertex", judge_samples: 0 });
  assert.match(html, /AI reviewer model<\/dt><dd>&lt;m&gt;/);
  assert.match(html, /Google Cloud \(Vertex AI\)/);
  assert.match(html, /Reviews per answer<\/dt><dd>0/);
  assert.match(html, /Not set/);
  assert.match(environmentHtml({ auth_mode: "other" }), /other/);
  assert.match(environmentHtml(null), /Not set/);
});
