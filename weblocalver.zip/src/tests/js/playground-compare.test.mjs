// Comparing two playground evaluations (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  ONLY_IN_ONE, TREND_LABELS, changeClass, changeText, checkChanges, comparisonView, orderPair, scoreDelta, testTrend,
} from "../../main/static/js/playground/run-compare-model.js";
import { CHOOSE_TWO_HTML, compareRowsHtml, comparisonHtml } from "../../main/static/js/playground/run-compare.js";
import { environmentHtml } from "../../main/static/js/playground/environment.js";

const NOW = new Date(2026, 8, 28, 12, 0);
const earlier = {
  id: "e1", savedAt: 1, meta: { startedAt: new Date(2026, 8, 27, 10, 0).toISOString() },
  run: {
    status: "PASS", weighted_score: 0.96,
    case_results: [
      { case_id: "a", passed: true, weighted_score: 0.5, scores: [{ metric: "contains", score: 0.5 }, { metric: "same", score: 1 }] },
      { case_id: "down", passed: true, weighted_score: 0.9, scores: [] },
      { case_id: "gone<", passed: true, weighted_score: 0.4, scores: [] },
      { case_id: "flip", passed: true, weighted_score: 0.7, scores: [] },
    ],
  },
};
const later = {
  id: "e2", savedAt: 2, meta: { startedAt: new Date(2026, 8, 28, 10, 0).toISOString() },
  run: {
    status: "FAIL", weighted_score: 0.7872,
    case_results: [
      { case_id: "a", passed: true, weighted_score: 0.9, scores: [{ metric: "contains", score: 0.9 }, { metric: "same", score: 1 }] },
      { case_id: "down", passed: false, weighted_score: 0.45, scores: [] },
      { case_id: "new", passed: true, weighted_score: 1, scores: [] },
      { case_id: "flip", passed: false, weighted_score: 0.7, scores: [] },
    ],
  },
};

test("scoreDelta only subtracts real scores", () => {
  assert.ok(Math.abs(scoreDelta(0.5, 0.9) - 0.4) < 1e-9);
  assert.equal(scoreDelta(null, 0.9), null);
  assert.equal(scoreDelta(0.5, undefined), null);
  assert.equal(scoreDelta("", 0.2), null);
  assert.equal(scoreDelta("x", 0.2), null);
});

test("changeText is a relative percentage only; changeClass gives direction", () => {
  assert.equal(changeText(0.2, 0.8), "+33.3%");
  assert.equal(changeText(-0.17, 0.79), "−17.7%");
  assert.equal(changeText(0, 0.8), "Unchanged");
  assert.equal(changeText(0.45, 0.45), "Up from 0%");
  assert.equal(changeText(null, 0.8), ONLY_IN_ONE);
  assert.equal(changeClass(0.1), "up");
  assert.equal(changeClass(-0.1), "down");
  assert.equal(changeClass(0), "same");
  assert.equal(changeClass(null), "");
});

test("testTrend looks at the score first, then at a pass/fail flip", () => {
  const [a, down, gone, flip] = earlier.run.case_results;
  const [a2, down2, , flip2] = later.run.case_results;
  assert.equal(testTrend(a, a2), "improved");
  assert.equal(testTrend(down, down2), "regressed");
  assert.equal(testTrend(flip, flip2), "regressed");
  assert.equal(testTrend(flip2, flip), "improved");
  assert.equal(testTrend(a, a), "same");
  assert.equal(testTrend(gone, undefined), "only");
  assert.equal(TREND_LABELS.regressed, "Got worse");
});

test("checkChanges lists every check with both scores", () => {
  const rows = checkChanges(earlier.run.case_results[0], later.run.case_results[0]);
  assert.equal(rows.length, 2);
  assert.equal(rows[0].before, "50%");
  assert.equal(rows[0].after, "90%");
  assert.equal(rows[0].change, "+80.0%");
  assert.equal(rows[1].change, "Unchanged");
  assert.deepEqual(checkChanges(undefined, undefined), []);
});

test("comparisonView orders the pair and counts what got better or worse", () => {
  const view = comparisonView(later, earlier, NOW);
  assert.match(view.earlier.when, /^Yesterday/);
  assert.equal(view.earlier.verdict, "Passed");
  assert.equal(view.later.verdict, "Needs attention");
  assert.equal(view.overall.change, "−18.0%");
  assert.equal(view.overall.cls, "down");
  assert.deepEqual(view.counts, { regressed: 2, improved: 1 });
  assert.equal(view.rows.find((row) => row.id === "new").change, ONLY_IN_ONE);
  assert.equal(comparisonView(earlier, earlier), null);
  assert.equal(comparisonView(null, later), null);
  assert.deepEqual(orderPair(later, earlier), [earlier, later]);
  assert.deepEqual(orderPair({ savedAt: 1 }, { savedAt: 2 }).map((e) => e.savedAt), [1, 2]);
});

test("comparisonHtml shows both evaluations and relative changes only", () => {
  const html = comparisonHtml(earlier, later, NOW);
  assert.match(html, /Earlier evaluation/);
  assert.match(html, /Later evaluation/);
  assert.match(html, /−18\.0%/);
  assert.match(html, /2 tests got worse and 1 test got better/);
  assert.match(html, /row-regressed/);
  assert.match(html, /row-improved/);
  assert.match(html, /gone&lt;/);
  assert.doesNotMatch(html, /→|points|\(\d+% /);
  assert.equal(comparisonHtml(earlier, earlier), CHOOSE_TWO_HTML);
  const empty = comparisonHtml({ savedAt: 1, run: { status: "PASS" } }, { savedAt: 2, run: { status: "PASS" } }, NOW);
  assert.match(empty, /Neither evaluation ran any tests/);
  assert.match(empty, /No test got better or worse/);
});

test("compareRowsHtml adds a row per check", () => {
  const view = comparisonView(earlier, later, NOW);
  const html = compareRowsHtml(view.rows[0]);
  assert.equal((html.match(/<tr/g) || []).length, 3);
  assert.match(html, /check-indent/);
});

test("environmentHtml labels settings plainly and escapes values", () => {
  const html = environmentHtml({ judge_model: "<m>", auth_mode: "vertex", judge_samples: 0 });
  assert.match(html, /AI reviewer model<\/dt><dd>&lt;m&gt;/);
  assert.match(html, /Google Cloud \(Vertex AI\)/);
  assert.match(html, /Reviews per answer<\/dt><dd>0/);
  assert.match(html, /Not set/);
  assert.match(environmentHtml({ auth_mode: "other" }), /other/);
  assert.match(environmentHtml(null), /Not set/);
});
