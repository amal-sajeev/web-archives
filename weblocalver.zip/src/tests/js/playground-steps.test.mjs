// The 1-2-3-4 step flow of the playground (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import { STEP_TITLES, stateWord, stepModel } from "../../main/static/js/playground/steps-model.js";

function states(flow) {
  return stepModel(flow).map((step) => step.state);
}

test("before loading, only step 1 is current", () => {
  const steps = stepModel();
  assert.deepEqual(steps.map((s) => s.title), [...STEP_TITLES]);
  assert.deepEqual(steps.map((s) => s.state), ["current", "todo", "todo", "todo"]);
  assert.equal(steps[0].current, true);
  assert.match(steps[1].status, /after loading/);
});

test("after loading, step 2 is next", () => {
  const steps = stepModel({ loaded: true, assistant: "Report Writer" });
  assert.equal(steps[0].status, "Loaded: Report Writer");
  assert.deepEqual(steps.map((s) => s.state), ["done", "current", "todo", "todo"]);
  assert.equal(stepModel({ loaded: true }).at(0).status, "Loaded: AI assistant settings");
});

test("check states: busy, problems, passed", () => {
  assert.equal(stepModel({ loaded: true, checking: true })[1].state, "busy");
  const one = stepModel({ loaded: true, check: { ok: false, count: 1 } })[1];
  assert.equal(one.state, "problem");
  assert.equal(one.current, true);
  assert.equal(one.status, "1 problem to fix");
  assert.equal(stepModel({ loaded: true, check: { ok: false, count: 3 } })[1].status, "3 problems to fix");
  assert.equal(stepModel({ loaded: true, check: { ok: false } })[1].status, "0 problems to fix");
  assert.deepEqual(states({ loaded: true, check: { ok: true } }), ["done", "done", "current", "todo"]);
});

test("try-it states: running, no tests chosen, finished", () => {
  const base = { loaded: true, check: { ok: true } };
  assert.equal(stepModel({ ...base, running: true, runningText: "Running… 1 of 2 tests done" })[2].status, "Running… 1 of 2 tests done");
  assert.equal(stepModel({ ...base, running: true })[2].status, "Running…");
  assert.equal(stepModel({ ...base, noTestsChosen: true })[2].state, "problem");
  const done = stepModel({ ...base, lastResult: "Passed · 82%" });
  assert.equal(done[2].status, "Last result: Passed · 82%");
  assert.equal(done[3].state, "current");
});

test("save states and the all-done case", () => {
  const base = { loaded: true, check: { ok: true }, lastResult: "Passed" };
  assert.match(stepModel({ ...base, dirty: true })[3].status, /not saved/);
  assert.match(stepModel(base)[3].status, /Download/);
  const all = stepModel({ ...base, saved: true });
  assert.deepEqual(all.map((s) => s.state), ["done", "done", "done", "done"]);
  assert.ok(all.every((s) => !s.current));
});

test("stateWord gives a visible word for each state", () => {
  assert.equal(stateWord("done"), "Done");
  assert.equal(stateWord("current"), "Next");
  assert.equal(stateWord("busy"), "In progress");
  assert.equal(stateWord("problem"), "Needs attention");
  assert.equal(stateWord("todo"), "");
  assert.equal(stateWord("other"), "");
});
