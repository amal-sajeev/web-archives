// API tester request building (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  authHeaders, basicAuthValue, buildBody, buildRequest, buildUrl, cleanRows, encodeFormBody, methodSendsBody, plainError,
} from "../../main/static/js/apitester/request.js";

test("cleanRows trims keys and drops blank ones", () => {
  assert.deepEqual(cleanRows([[" a ", 1], ["", "x"], [null, "y"], ["b", null]]), [["a", "1"], ["b", ""]]);
  assert.deepEqual(cleanRows(undefined), []);
});

test("buildUrl appends params and explains bad addresses plainly", () => {
  assert.equal(buildUrl("http://h/p?x=1", [["x", "2"], ["y", "a b"]]), "http://h/p?x=1&x=2&y=a+b");
  assert.throws(() => buildUrl("  "), /Type the address/);
  assert.throws(() => buildUrl("not a url"), (err) => /should start with http/.test(err.message) && /Invalid URL/.test(err.details));
  assert.throws(() => buildUrl("ftp://h/x"), (err) => /should start with http/.test(err.message) && /ftp:/.test(err.details));
  assert.throws(() => buildUrl("localhost:8000/api"), /should start with http/);
});

test("plainError carries details and cause", () => {
  const cause = new Error("root");
  const err = plainError("Plain", "raw", cause);
  assert.equal(err.message, "Plain");
  assert.equal(err.details, "raw");
  assert.equal(err.cause, cause);
  assert.equal(plainError("x").details, "");
});

test("methodSendsBody", () => {
  assert.equal(methodSendsBody("GET"), false);
  assert.equal(methodSendsBody("head"), false);
  assert.equal(methodSendsBody("POST"), true);
  assert.equal(methodSendsBody(undefined), false);
});

test("auth presets add the right header", () => {
  assert.deepEqual(authHeaders({ type: "bearer", value: "t" }), { Authorization: "Bearer t" });
  assert.deepEqual(authHeaders({ type: "bearer" }), {});
  assert.deepEqual(authHeaders({ type: "apikey", value: "k" }), { "X-API-Key": "k" });
  assert.deepEqual(authHeaders({ type: "apikey", key: " K ", value: "k" }), { K: "k" });
  assert.deepEqual(authHeaders({ type: "apikey" }), {});
  assert.deepEqual(authHeaders({ type: "custom", key: "H", value: "v" }), { H: "v" });
  assert.deepEqual(authHeaders({ type: "custom", value: "v" }), {});
  assert.deepEqual(authHeaders({ type: "basic", user: "u", pass: "p" }), { Authorization: basicAuthValue("u", "p") });
  assert.deepEqual(authHeaders({ type: "basic" }), {});
  assert.deepEqual(authHeaders(null), {});
  assert.equal(basicAuthValue("ü", "p"), `Basic ${Buffer.from("ü:p").toString("base64")}`);
});

test("encodeFormBody and buildBody", () => {
  assert.equal(encodeFormBody("a=1\nb=x=y\n\n c =3"), "a=1&b=x%3Dy&c=3");
  assert.equal(encodeFormBody(null), "");
  const headers = {};
  assert.deepEqual(buildBody("json", '{"a":1}', headers), { json: { a: 1 }, data: null });
  assert.equal(headers["Content-Type"], "application/json");
  assert.deepEqual(buildBody("json", "  ", {}), { json: null, data: null });
  assert.throws(() => buildBody("json", "{", {}), (err) => /not valid JSON/.test(err.message) && err.details.length > 0);
  assert.deepEqual(buildBody("form", "a=1", {}), { json: null, data: "a=1" });
  const kept = { "content-type": "text/csv" };
  assert.deepEqual(buildBody("weird", null, kept), { json: null, data: "" });
  assert.deepEqual(kept, { "content-type": "text/csv" });
});

test("buildRequest combines everything; auth wins; GET sends no body", () => {
  const req = buildRequest({
    method: "post", url: "http://h", params: [], headers: [["Authorization", "old"]],
    bodyType: "json", bodyText: '{"q":1}', auth: { type: "bearer", value: "t" },
  });
  assert.equal(req.method, "POST");
  assert.equal(req.url, "http://h/");
  assert.equal(req.headers.Authorization, "Bearer t");
  assert.deepEqual(req.body, { q: 1 });
  const get = buildRequest({ url: "http://h", bodyType: "json", bodyText: "{" });
  assert.equal(get.method, "GET");
  assert.equal(get.body, null);
  assert.equal(get.headers["Content-Type"], undefined);
});
