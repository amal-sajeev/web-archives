// Playground requests and the live-progress transport, with fetch/EventSource stubbed
// (run with: node --test src/tests/js).
import { afterEach, test } from "node:test";
import assert from "node:assert/strict";

import * as api from "../../main/static/js/playground/bundle-api.js";
import { RunStream, TERMINAL_EVENTS, summaryEvent } from "../../main/static/js/playground/run-stream.js";

// Expected fallbacks log at debug/warn level; keep the test output readable.
console.debug = () => {};
console.warn = () => {};

const realFetch = globalThis.fetch;
const calls = [];

function respond(status, body, type = "application/json") {
  const text = typeof body === "string" ? body : JSON.stringify(body);
  return new Response(text, { status, headers: { "Content-Type": type } });
}

function stubFetch(handler) {
  calls.length = 0;
  globalThis.fetch = async (url, opts = {}) => {
    calls.push({ url: String(url), opts });
    return handler(String(url), opts);
  };
}

afterEach(() => {
  globalThis.fetch = realFetch;
});

test("clampReps and startQuery build the start request", () => {
  assert.equal(api.clampReps("3"), 3);
  assert.equal(api.clampReps(9), 5);
  assert.equal(api.clampReps(0), 1);
  assert.equal(api.clampReps("abc"), 1);
  const q = new URLSearchParams(api.startQuery({ baseUrl: " http://x ", reps: 2, caseIds: ["a"] }));
  assert.equal(q.get("judge_repetitions"), "2");
  assert.equal(q.get("case_ids_json"), '["a"]');
  assert.equal(q.get("base_url"), "http://x");
  const empty = new URLSearchParams(api.startQuery());
  assert.equal(empty.has("base_url"), false);
  assert.equal(empty.get("case_ids_json"), "[]");
  assert.equal(new URLSearchParams(api.startQuery({ caseIds: null })).get("case_ids_json"), "[]");
});

test("URLs stay relative and encode ids", () => {
  assert.equal(api.streamUrl("a/b"), "api/evaluate/stream/a%2Fb");
});

test("startRun posts the ZIP to the 202 endpoint", async () => {
  stubFetch(() => respond(202, { stream_id: "s1", agent_id: "playground" }));
  const out = await api.startRun(new Blob(["zip"]), { reps: 1, caseIds: ["a"] });
  assert.equal(out.stream_id, "s1");
  assert.match(calls[0].url, /^api\/playground\/start\?judge_repetitions=1/);
  assert.equal(calls[0].opts.method, "POST");
  assert.ok(calls[0].opts.body instanceof FormData);
});

test("inspect, validate, cancel, events, finished run and environment", async () => {
  stubFetch((url) => respond(200, { url }));
  assert.equal((await api.inspectBundle(new File(["z"], "a.zip"))).url, "api/playground/inspect");
  assert.equal((await api.validateBundle(new Blob(["z"]))).url, "api/playground/validate");
  assert.equal((await api.cancelRun("s 1")).url, "api/evaluate/cancel/s%201");
  assert.equal((await api.fetchStreamEvents("s", -4)).url, "api/evaluate/stream/s/events?after=0");
  assert.equal((await api.fetchStreamEvents("s", 7)).url, "api/evaluate/stream/s/events?after=7");
  assert.equal((await api.fetchFinishedRun("s")).url, "api/playground/export?stream_id=s");
  assert.equal((await api.fetchEnvironment()).url, "api/playground/environment");
});

test("cancel reports 409 when the evaluation already finished", async () => {
  stubFetch(() => respond(409, { detail: "Run already finished" }));
  await assert.rejects(api.cancelRun("s"), (err) => err.status === 409 && /already finished/.test(err.message));
});

test("exportBundle returns a blob and explains failures", async () => {
  stubFetch(() => respond(200, "PK", "application/zip"));
  const blob = await api.exportBundle([{ path: "a", content: "x" }], "root");
  assert.equal(await blob.text(), "PK");
  assert.deepEqual(JSON.parse(calls[0].opts.body), { root: "root", files: [{ path: "a", content: "x" }] });

  stubFetch(() => respond(400, { detail: "files must be an array." }));
  await assert.rejects(api.exportBundle([]), (err) => err.status === 400 && err.message === "files must be an array.");

  stubFetch(() => respond(502, "Bad gateway", "text/plain"));
  await assert.rejects(api.exportBundle([]), (err) => err.message === "Bad gateway");

  stubFetch(() => respond(500, "x".repeat(400), "text/html"));
  await assert.rejects(api.exportBundle([]), (err) => err.message === "Request failed (500)");

  globalThis.fetch = async () => { throw new TypeError("network down"); };
  await assert.rejects(api.exportBundle([]), (err) => err.status === 0 && /could not be reached/.test(err.message));
});

test("summaryEvent turns a bare run_done into a terminal event", () => {
  assert.equal(summaryEvent(null), null);
  assert.equal(summaryEvent({ error_detail: "Cancelled by user" }).type, "run_cancelled");
  assert.equal(summaryEvent({ error_detail: "boom" }).detail, "boom");
  assert.match(summaryEvent({ status: "ERROR" }).detail, /status ERROR/);
  assert.match(summaryEvent({}).detail, /unknown/);
  assert.ok(TERMINAL_EVENTS.has("playground_done"));
});

class FakeEventSource {
  static last = null;
  constructor(url) {
    this.url = url;
    this.closed = false;
    FakeEventSource.last = this;
  }
  close() {
    this.closed = true;
  }
}

function withBrowserGlobals() {
  globalThis.window = globalThis;
  globalThis.EventSource = FakeEventSource;
}

test("RunStream follows SSE, ignores repeats and stops on a terminal event", () => {
  withBrowserGlobals();
  const seen = [];
  const modes = [];
  const stream = new RunStream("s1", { onEvent: (e) => seen.push(e.type), onConnection: (m) => modes.push(m) }).start();
  const source = FakeEventSource.last;
  assert.equal(source.url, "api/evaluate/stream/s1");
  source.onopen();
  source.onmessage({ data: JSON.stringify({ seq: 1, type: "run_started" }) });
  source.onmessage({ data: JSON.stringify({ seq: 1, type: "run_started" }) });
  source.onmessage({ data: "not json" });
  source.onmessage({ data: JSON.stringify({ seq: 2, type: "run_done", status: "PASS" }) });
  source.onmessage({ data: JSON.stringify({ seq: 3, type: "playground_done", run: {} }) });
  source.onmessage({ data: JSON.stringify({ seq: 4, type: "late" }) });
  assert.deepEqual(seen, ["run_started", "run_done", "playground_done"]);
  assert.deepEqual(modes, ["live"]);
  assert.equal(source.closed, true);
  assert.equal(stream.done, true);
  stream.onSseError();
  stream.onOpen();
  assert.deepEqual(modes, ["live"], "no callbacks after stop");
});

test("RunStream polls only after an SSE error and finishes from the stored run", async () => {
  withBrowserGlobals();
  const seen = [];
  stubFetch((url) => {
    if (url.includes("/events")) return respond(200, { events: [{ seq: 1, type: "case_done" }], done: true });
    return respond(200, { run_id: "r1" });
  });
  const stream = new RunStream("s2", { onEvent: (e) => seen.push(e) }).start();
  assert.equal(calls.length, 0, "no polling while SSE is healthy");
  FakeEventSource.last.onerror();
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.deepEqual(seen.map((e) => e.type), ["case_done", "playground_done"]);
  assert.equal(seen[1].run.run_id, "r1");
  assert.equal(stream.pollTimer, null);
});

test("RunStream uses the run_done summary and reports a lost stream", async () => {
  withBrowserGlobals();
  const seen = [];
  stubFetch(() => respond(200, { events: [{ seq: 1, type: "run_done", error_detail: "cancelled" }], done: true }));
  new RunStream("s3", { onEvent: (e) => seen.push(e.type) }).startPolling();
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.deepEqual(seen, ["run_done", "run_cancelled"]);

  const lost = [];
  stubFetch(() => respond(404, { detail: "Unknown stream" }));
  const gone = new RunStream("s4", { onEvent: () => {}, onLost: (err) => lost.push(err.message) });
  await gone.poll();
  assert.match(lost[0], /no longer available/);
  assert.equal(gone.done, true);
});

test("RunStream keeps polling after a temporary error and reports a missing run", async () => {
  withBrowserGlobals();
  const lost = [];
  const warn = console.warn;
  console.warn = () => {};
  stubFetch(() => respond(500, { detail: "busy" }));
  const stream = new RunStream("s5", { onEvent: () => {}, onLost: (err) => lost.push(err) });
  await stream.poll();
  console.warn = warn;
  assert.equal(stream.done, false);
  stubFetch((url) => (url.includes("/events") ? respond(200, { events: [], done: true }) : respond(404, { detail: "not completed" })));
  await stream.poll();
  assert.equal(lost.length, 1);
  assert.equal(stream.done, true);
  stream.accept(null);
});

test("RunStream falls back to polling without EventSource", () => {
  globalThis.window = globalThis;
  const saved = globalThis.EventSource;
  delete globalThis.EventSource;
  stubFetch(() => respond(200, { events: [], done: false }));
  const stream = new RunStream("s6", { onEvent: () => {} }).start();
  assert.ok(stream.pollTimer);
  stream.stop();
  assert.equal(stream.pollTimer, null);
  globalThis.EventSource = saved;
});
