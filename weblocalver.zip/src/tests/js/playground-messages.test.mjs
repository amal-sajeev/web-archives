// Plain-language playground messages (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  checkNotice, friendlyError, noticeHtml, plainProblem, runFailure, runStopped, technicalDetailsHtml,
} from "../../main/static/js/playground/messages.js";

test("plainProblem translates every known server message", () => {
  const cases = [
    ["agent.yaml is missing agent_id.", /no ID/],
    ["agent.yaml is missing name.", /no name/],
    ["Dataset contains no cases.", /no tests yet/],
    ["Dataset contains no metrics.", /No checks are set up/],
    ["Sensitive or repository metadata file should not be included: .env", /Remove \.env\. It may contain private/],
    ["custom_tests.py could not be loaded: SyntaxError: bad", /extra checks file .* has a mistake/],
    ["custom_tests.py overrides an existing scorer: contains", /same name as a built-in check: contains/],
    ["custom_tests.py did not register declared scorer(s): a, b", /named but not set up: a, b/],
    ["Upload exactly one agent configuration folder containing one agent.yaml.", /one folder with one agent\.yaml/],
    ["The selected agent folder does not contain agent.yaml.", /has no agent\.yaml/],
    ["agent.yaml is invalid: line 3", /agent\.yaml has a mistake/],
    ["Configured dataset file is missing: data.json", /test file data\.json named in agent\.yaml is missing/],
    ["Dataset is invalid: bad json", /test file has a mistake/],
    ["Configured metrics stub file is missing: m.json", /file m\.json named in agent\.yaml is missing/],
    ["File is not a zip file", /not a readable \.zip/],
  ];
  for (const [raw, expected] of cases) assert.match(plainProblem(raw), expected, raw);
});

test("plainProblem passes unknown text through and fills blanks", () => {
  assert.equal(plainProblem("Choose at least one test to include."), "Choose at least one test to include.");
  assert.equal(plainProblem(""), "Something is not right with these settings.");
  assert.equal(plainProblem(null), "Something is not right with these settings.");
});

test("friendlyError picks a title per action and keeps the raw text", () => {
  const offline = Object.assign(new Error("The evaluation service could not be reached."), { status: 0 });
  const e1 = friendlyError(offline, "load");
  assert.equal(e1.title, "This file could not be opened");
  assert.match(e1.text, /Check your connection/);
  assert.equal(e1.details, "The evaluation service could not be reached.");

  const e2 = friendlyError(Object.assign(new Error("Dataset is invalid: x"), { status: 400 }), "check");
  assert.equal(e2.title, "The settings could not be checked");
  assert.match(e2.text, /test file has a mistake/);

  assert.equal(friendlyError(new Error("x"), "nope").title, "The evaluation could not start");
  assert.equal(friendlyError("plain string").details, "plain string");
  assert.equal(friendlyError(new Error("x"), "save").title, "The settings could not be downloaded");
  assert.equal(friendlyError(new Error("x"), "stop").title, "The evaluation could not be stopped");
});

test("friendlyError lists problems when the check failed before a run", () => {
  const err = Object.assign(new Error("needs fixing"), { problems: ["Dataset contains no cases."] });
  const out = friendlyError(err, "run");
  assert.equal(out.text, "Please fix these problems first:");
  assert.deepEqual(out.items, ["There are no tests yet. Add at least one test to the test file."]);
  assert.equal(out.details, "Dataset contains no cases.");
});

test("runFailure and runStopped describe the outcome plainly", () => {
  assert.match(runFailure({ detail: "ConnectError: connection refused" }).text, /could not be reached/);
  assert.match(runFailure({ detail: "Request timed out" }).text, /too long/);
  assert.match(runFailure({ detail: "Vertex credentials missing" }).text, /AI reviewer is not available/);
  const other = runFailure({ detail: "KeyError: x" });
  assert.equal(other.text, "Something went wrong while running the tests.");
  assert.equal(other.details, "KeyError: x");
  assert.equal(runFailure(undefined).details, "");
  assert.equal(runStopped({ detail: "Preview run cancelled" }).title, "The evaluation was stopped");
  assert.equal(runStopped().details, "");
});

test("technicalDetailsHtml escapes and hides when empty", () => {
  assert.equal(technicalDetailsHtml(""), "");
  assert.equal(technicalDetailsHtml(null), "");
  const html = technicalDetailsHtml("<b>boom</b>");
  assert.match(html, /<summary>Technical details<\/summary>/);
  assert.match(html, /&lt;b&gt;boom&lt;\/b&gt;/);
});

test("noticeHtml escapes every field and adds the icon", () => {
  const html = noticeHtml({ tone: "bad", title: "<t>", text: "a & b", items: ["<i>"], details: "raw" });
  assert.match(html, /notice notice-bad/);
  assert.match(html, /aria-hidden="true">×</);
  assert.match(html, /&lt;t&gt;/);
  assert.match(html, /a &amp; b/);
  assert.match(html, /<li>&lt;i&gt;<\/li>/);
  assert.match(html, /Technical details/);
  const plain = noticeHtml();
  assert.match(plain, /notice-info/);
  assert.doesNotMatch(plain, /<ul/);
  assert.match(noticeHtml({ tone: "weird" }), />i</);
});

test("checkNotice covers valid, invalid and empty results", () => {
  const ok = checkNotice({ valid: true, errors: [], custom_tests: { loaded_scorers: ["tone"] } });
  assert.equal(ok.tone, "ok");
  assert.match(ok.text, /Extra checks found: tone/);
  assert.doesNotMatch(checkNotice({ valid: true }).text, /Extra/);
  const one = checkNotice({ valid: false, errors: ["Dataset contains no cases."] });
  assert.equal(one.title, "1 problem to fix");
  assert.equal(one.details, "Dataset contains no cases.");
  assert.equal(checkNotice({ valid: false, errors: ["a", "b"] }).title, "2 problems to fix");
  assert.equal(checkNotice({ valid: false }).title, "The check did not pass");
  assert.equal(checkNotice(null).title, "The check did not pass");
});
