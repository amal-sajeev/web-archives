// One evaluation in full on the Runner page, and live progress (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import { progressDetail, progressLabel, progressPercent } from "../../main/static/js/playground/progress-model.js";
import {
  NOT_RECORDED, checkRow, displayValue, durationText, filterTests, formatDuration, observationFacts, runDetailView,
  runHeadline, settingsRows, skippedRow, testDetail,
} from "../../main/static/js/playground/run-detail-model.js";
import { checkRowHtml, runDetailHtml, testDetailHtml, testListHtml } from "../../main/static/js/playground/run-detail.js";
import { PROGRESS_HTML } from "../../main/static/js/playground/run-progress.js";

const NOW = new Date(2026, 8, 28, 12, 0);
const START = new Date(2026, 8, 28, 9, 30, 0);

function sampleEntry(overrides = {}) {
  return {
    id: "e1",
    savedAt: START.getTime(),
    meta: {
      startedAt: START.toISOString(), finishedAt: new Date(START.getTime() + 12500).toISOString(),
      targetUrl: "http://127.0.0.1:4011", customUrl: false, reps: 2, caseIds: ["rw_001", "rw_<2>", "rw_003"], totalCases: 3,
      agentId: "report_writer", agentName: "Report writer",
    },
    run: {
      run_id: "r1", status: "FAIL", weighted_score: 0.62, agent_id: "report_writer", dataset_id: "rw", dataset_version: "3",
      creation_ts: START.toISOString(),
      case_results: [
        {
          case_id: "rw_001", passed: true, weighted_score: 0.9, input: { question: "Summarise Q1" }, golden_output: "Revenue $10M",
          observation: { output: "Revenue was $10M", model: "m-1", latency_ms: 1520, usage: { input_tokens: 10, output_tokens: 5 }, tool_calls: [{ name: "search" }] },
          scores: [{ metric: "contains", score: 0.9, threshold: 0.8, weight: 2, passed: true, rationale: "All terms", evidence: ["$10M"], critical: true }],
          skipped: [],
        },
        {
          case_id: "rw_<2>", passed: false, weighted_score: 0.3, input: {}, observation: { output: { text: "<script>" } },
          scores: [{ metric: "report_quality_rubric", score: 0.3, threshold: 0.7, weight: 1, passed: false, unstable: true }],
          skipped: [{ metric: "faithfulness", reason: "LLM judge unavailable: no credentials", critical: true }],
        },
        { case_id: "rw_003", passed: false, observation: { error: "ConnectError: refused\nfull trace" } },
      ],
    },
    ...overrides,
  };
}

test("displayValue keeps text and indents everything else", () => {
  assert.equal(displayValue("hi"), "hi");
  assert.equal(displayValue({ a: 1 }), '{\n  "a": 1\n}');
  assert.equal(displayValue(null), "");
  assert.equal(displayValue(""), "");
  assert.equal(displayValue(0), "0");
  const loop = {};
  loop.self = loop;
  assert.equal(displayValue(loop), "[object Object]");
});

test("durations read plainly and need both times", () => {
  assert.equal(formatDuration(340), "340 ms");
  assert.equal(formatDuration(1520), "1.5 s");
  assert.equal(formatDuration(75000), "1 min 15 s");
  assert.equal(formatDuration(null), NOT_RECORDED);
  assert.equal(formatDuration(-1), NOT_RECORDED);
  assert.equal(durationText(sampleEntry().meta), "12.5 s");
  assert.equal(durationText({ startedAt: START.toISOString() }), NOT_RECORDED);
  assert.equal(durationText(null), NOT_RECORDED);
});

test("settingsRows lists the address, reviews, tests and ids", () => {
  const rows = Object.fromEntries(settingsRows(sampleEntry()).map((row) => [row.label, row.value]));
  assert.equal(rows["Where the test questions went"], "http://127.0.0.1:4011 (from agent.yaml)");
  assert.equal(rows["Reviews per answer"], "2");
  assert.equal(rows["Tests included"], "rw_001, rw_<2>, rw_003");
  assert.equal(rows["AI assistant"], "Report writer (ID report_writer)");
  assert.equal(rows["Test set"], "rw (version 3)");
  const bare = Object.fromEntries(settingsRows({ run: {} }).map((row) => [row.label, row.value]));
  assert.ok(Object.values(bare).every((value) => value === NOT_RECORDED));
  const custom = settingsRows({ run: { agent_id: "a", dataset_id: "d" }, meta: { targetUrl: "http://x", customUrl: true } });
  assert.equal(custom[0].value, "http://x");
  assert.equal(custom[3].value, "a");
  assert.equal(custom[4].value, "d");
});

test("observationFacts reports model, time, tokens and tool calls", () => {
  const facts = observationFacts(sampleEntry().run.case_results[0].observation).map((fact) => fact.value);
  assert.deepEqual(facts, ["m-1", "1.5 s", "15 (10 in, 5 out)", "1: search"]);
  assert.deepEqual(observationFacts(null).map((fact) => fact.value), [NOT_RECORDED, NOT_RECORDED, NOT_RECORDED, "None"]);
  assert.equal(observationFacts({ usage: { total_tokens: 7 } })[2].value, "7");
  assert.match(observationFacts({ tool_calls: [{ function: { name: "f" } }, {}] })[3].value, /2: f, unnamed tool/);
});

test("checkRow and skippedRow keep every recorded detail", () => {
  const row = checkRow(sampleEntry().run.case_results[0].scores[0]);
  assert.equal(row.score, "90%");
  assert.equal(row.threshold, "80%");
  assert.equal(row.weight, "2");
  assert.equal(row.verdict, "Passed");
  assert.equal(row.critical, true);
  assert.deepEqual(row.evidence, ["$10M"]);
  const empty = checkRow(undefined);
  assert.equal(empty.kind, "fail");
  assert.equal(empty.weight, "—");
  const skip = skippedRow({ metric: "faithfulness", reason: "LLM judge unavailable" });
  assert.match(skip.reason, /AI reviewer was not available/);
  assert.equal(skip.details, "LLM judge unavailable");
  assert.equal(skippedRow(null).details, "");
});

test("testDetail shows input, answer, expected answer and errors in full", () => {
  const [pass, fail, error] = sampleEntry().run.case_results.map(testDetail);
  assert.equal(pass.kind, "pass");
  assert.equal(pass.name, "Rw 001");
  assert.match(pass.input, /Summarise Q1/);
  assert.equal(pass.output, "Revenue was $10M");
  assert.equal(pass.expected, "Revenue $10M");
  assert.match(pass.toolCalls, /search/);
  assert.equal(fail.kind, "fail");
  assert.equal(fail.input, "");
  assert.match(fail.output, /"text"/);
  assert.equal(fail.skipped.length, 1);
  assert.equal(error.kind, "error");
  assert.equal(error.verdict, "Could not finish");
  assert.equal(error.error, "ConnectError: refused\nfull trace");
  assert.equal(testDetail(null).id, "");
});

test("filterTests keeps failed tests or tests with errors", () => {
  const tests = sampleEntry().run.case_results.map(testDetail);
  assert.equal(filterTests(tests, "all").length, 3);
  assert.deepEqual(filterTests(tests, "failed").map((t) => t.id), ["rw_<2>", "rw_003"]);
  assert.deepEqual(filterTests(tests, "errors").map((t) => t.id), ["rw_003"]);
  assert.deepEqual(filterTests(null, "all"), []);
});

test("runDetailView summarises the evaluation", () => {
  const view = runDetailView(sampleEntry(), NOW);
  assert.equal(view.verdict, "Needs attention");
  assert.equal(view.score, "62%");
  assert.equal(view.passed, "1 of 3 tests passed");
  assert.match(view.when, /^Today at /);
  assert.equal(view.duration, "12.5 s");
  assert.deepEqual(view.counts, { all: 3, failed: 2, errors: 1 });
  assert.equal(runDetailView(null), null);
  assert.equal(runDetailView({ run: "x" }), null);
  assert.equal(runDetailView({ run: { status: "ERROR", error_detail: "cancelled" } }).verdict, "Stopped");
});

test("runHeadline gives the short status for the header pill", () => {
  assert.equal(runHeadline({ status: "PASS", weighted_score: 0.82 }), "Passed · 82%");
  assert.equal(runHeadline({ status: "ERROR" }), "Could not finish");
  assert.equal(runHeadline(null), "");
});

test("runDetailHtml escapes data and shows header, settings, filters and tests", () => {
  const html = runDetailHtml(runDetailView(sampleEntry(), NOW));
  assert.match(html, /Needs attention/);
  assert.match(html, /How long it took/);
  assert.match(html, /Settings used/);
  assert.match(html, /name="test-filter" value="failed"/);
  assert.match(html, /Did not pass \(2\)/);
  assert.match(html, /rw_&lt;2&gt;/);
  assert.doesNotMatch(html, /rw_<2>/);
  assert.doesNotMatch(html, /<script>/);
  assert.match(runDetailHtml(null), /No result came back/);
});

test("testDetailHtml puts the answer next to the expected answer and lists every check", () => {
  const [pass, fail, error] = sampleEntry().run.case_results.map(testDetail);
  const html = testDetailHtml(pass, true);
  assert.match(html, /<details class="test-row test-pass" data-test-id="rw_001" open>/);
  assert.match(html, /answer-pair/);
  assert.match(html, /Expected answer/);
  assert.match(html, /Show evidence \(1 item\)/);
  assert.match(html, /Must pass/);
  assert.match(html, /Show tool calls/);
  assert.match(testDetailHtml(fail), /Checks that could not be run \(1\)/);
  assert.match(testDetailHtml(fail), /Reviews disagreed/);
  assert.match(testDetailHtml(fail), /No input was recorded/);
  assert.match(testDetailHtml(error), /could not answer this test/);
  assert.match(testDetailHtml(error), /full trace/);
  assert.match(testDetailHtml(error), /No checks were scored/);
  assert.match(checkRowHtml(checkRow({ metric: "m", passed: false })), /<td class="why"><span class="cell-none">/);
});

test("testListHtml filters and explains empty results", () => {
  const tests = sampleEntry().run.case_results.map(testDetail);
  assert.equal((testListHtml(tests, "errors").match(/<details/g) || []).length, 1);
  assert.match(testListHtml(tests.slice(0, 1), "errors"), /No tests match this filter/);
  assert.match(testListHtml([], "all"), /No tests were run/);
  assert.match(testListHtml(tests, "all", new Set(["rw_003"])), /data-test-id="rw_003" open/);
});

test("progress markup, label, percent and detail", () => {
  assert.match(PROGRESS_HTML, /Evaluation in progress/);
  assert.equal(progressLabel({ total: 5, casesDone: 2 }), "2 of 5 tests done");
  assert.equal(progressLabel({ total: 1, casesDone: 0 }), "0 of 1 test done");
  assert.equal(progressLabel({ total: 0, casesDone: 1 }), "1 test done");
  assert.equal(progressLabel(), "0 tests done");
  assert.equal(progressPercent({ total: 4, casesDone: 1 }), 25);
  assert.equal(progressPercent({ total: 2, casesDone: 5 }), 100);
  assert.equal(progressPercent(), 0);
  assert.equal(progressDetail({ type: "case_started", case_id: "a" }), "Asking the AI assistant: test a");
  assert.equal(progressDetail({ type: "observation", case_id: "a" }), "Answer received for test a");
  assert.match(progressDetail({ type: "metric_started", case_id: "a", metric: "contains" }), /^Checking “.+” on test a$/);
  assert.match(progressDetail({ type: "metric_done", case_id: "a" }), /Checked “a check”/);
  assert.match(progressDetail({ type: "metric_skipped", case_id: "a", metric: "x" }), /Could not check/);
  assert.equal(progressDetail({ type: "case_done", case_id: 7 }), "Finished test 7");
  assert.equal(progressDetail({ type: "note", message: "hi" }), "hi");
  assert.equal(progressDetail(null), "");
});
