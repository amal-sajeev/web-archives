// Playground result view models and markup (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  checkView, neededText, notCheckedView, progressDetail, progressLabel, progressPercent, runHeadline, runView, testView,
} from "../../main/static/js/playground/results-model.js";
import { EMPTY_RESULTS_HTML, PROGRESS_HTML, runHtml, testHtml } from "../../main/static/js/playground/results.js";

const NOW = new Date(2026, 8, 28, 12, 0);

function sampleRun(overrides = {}) {
  return {
    run_id: "r1",
    status: "FAIL",
    weighted_score: 0.62,
    agent_id: "report_writer",
    creation_ts: new Date(2026, 8, 28, 9, 30).toISOString(),
    case_results: [
      {
        case_id: "rw_001",
        passed: true,
        weighted_score: 0.9,
        scores: [{ metric: "contains", score: 0.9, threshold: 0.8, passed: true, rationale: "All terms", evidence: ["$10M"] }],
        skipped: [],
      },
      {
        case_id: "rw_<2>",
        passed: false,
        weighted_score: 0.3,
        scores: [{ metric: "report_quality_rubric", score: 0.3, threshold: 0.7, passed: false }],
        skipped: [{ metric: "faithfulness", reason: "judge unavailable: no credentials" }],
      },
      { case_id: "rw_003", passed: false, observation: { error: "ConnectError" } },
    ],
    ...overrides,
  };
}

test("neededText and checkView use plain words", () => {
  assert.equal(neededText(0.7), "needs 70%");
  assert.equal(neededText(null), "");
  const view = checkView({ metric: "contains", score: 0.5, threshold: 0.8, passed: false, rationale: "Missing", evidence: ["a", "b"] });
  assert.equal(view.kind, "fail");
  assert.equal(view.verdict, "Needs attention");
  assert.equal(view.icon, "!");
  assert.equal(view.score, "50%");
  assert.equal(view.needed, "needs 80%");
  assert.equal(view.evidence, "a\nb");
  assert.ok(view.title.length > 0);
  const empty = checkView(undefined);
  assert.equal(empty.score, "—");
  assert.equal(empty.why, "");
});

test("notCheckedView keeps the raw reason as details", () => {
  const view = notCheckedView({ metric: "faithfulness", reason: "judge unavailable" });
  assert.match(view.reason, /not available/);
  assert.equal(view.details, "judge unavailable");
  assert.equal(notCheckedView(null).details, "");
});

test("testView marks passing, failing and unanswered tests", () => {
  const run = sampleRun();
  const [pass, fail, error] = run.case_results.map(testView);
  assert.equal(pass.kind, "pass");
  assert.equal(pass.open, false);
  assert.equal(fail.kind, "fail");
  assert.equal(fail.open, true);
  assert.equal(fail.notChecked.length, 1);
  assert.equal(error.kind, "error");
  assert.equal(error.verdict, "Could not finish");
  assert.equal(error.error, "ConnectError");
  assert.equal(testView(null).id, "");
});

test("runView summarises the evaluation with verdict, count and date", () => {
  const view = runView(sampleRun(), NOW);
  assert.equal(view.verdict, "Needs attention");
  assert.equal(view.score, "62%");
  assert.equal(view.passed, "1 of 3 tests passed");
  assert.match(view.when, /^Today at /);
  assert.equal(view.assistant, "Report writer");
  assert.equal(runView(null), null);
  assert.equal(runView("x"), null);
  assert.equal(runView({ status: "PASS" }).assistant, "AI assistant");
});

test("runHeadline gives the short status for steps and the pill", () => {
  assert.equal(runHeadline(sampleRun({ status: "PASS", weighted_score: 0.82 })), "Passed · 82%");
  assert.equal(runHeadline({ status: "ERROR" }), "Could not finish");
  assert.equal(runHeadline(null), "");
});

test("runHtml escapes data and shows tests", () => {
  const html = runHtml(sampleRun(), NOW);
  assert.match(html, /Needs attention/);
  assert.match(html, /1 of 3 tests passed/);
  assert.match(html, /Test rw_&lt;2&gt;/);
  assert.doesNotMatch(html, /rw_<2>/);
  assert.match(html, /Show details/);
  assert.match(html, /Not checked/);
  assert.match(html, /could not answer this test/);
  assert.match(runHtml(null), /No result came back/);
  assert.match(runHtml({ status: "PASS", case_results: [] }), /No tests were run/);
});

test("testHtml opens failing tests and handles tests without checks", () => {
  const html = testHtml(testView({ case_id: "x", passed: false }));
  assert.match(html, /<details class="test-row test-fail" open>/);
  assert.match(html, /No checks were recorded/);
});

test("static markup constants read plainly", () => {
  assert.match(EMPTY_RESULTS_HTML, /Run evaluation/);
  assert.match(PROGRESS_HTML, /Evaluation in progress/);
});

test("progress label, percent and detail", () => {
  assert.equal(progressLabel({ total: 5, casesDone: 2 }), "2 of 5 tests done");
  assert.equal(progressLabel({ total: 1, casesDone: 0 }), "0 of 1 test done");
  assert.equal(progressLabel({ total: 0, casesDone: 1 }), "1 test done");
  assert.equal(progressLabel({ casesDone: 3 }), "3 tests done");
  assert.equal(progressLabel(), "0 tests done");
  assert.equal(progressPercent({ total: 4, casesDone: 1 }), 25);
  assert.equal(progressPercent({ total: 2, casesDone: 5 }), 100);
  assert.equal(progressPercent({ total: 0, casesDone: 1 }), 0);
  assert.equal(progressPercent(), 0);
  assert.equal(progressDetail({ type: "case_started", case_id: "a" }), "Asking the AI assistant: test a");
  assert.equal(progressDetail({ type: "observation", case_id: "a" }), "Answer received for test a");
  assert.match(progressDetail({ type: "metric_started", case_id: "a", metric: "contains" }), /^Checking “.+” on test a$/);
  assert.match(progressDetail({ type: "metric_done", case_id: "a" }), /Checked “a check”/);
  assert.match(progressDetail({ type: "metric_skipped", case_id: "a", metric: "x" }), /Could not check/);
  assert.equal(progressDetail({ type: "case_done", case_id: 7 }), "Finished test 7");
  assert.equal(progressDetail({ type: "note", message: "hi" }), "hi");
  assert.equal(progressDetail(null), "");
});
