// API tester reply summaries and request history (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  byteLength, describeResponse, failureSummary, formatDuration, formatMeta, historyStatus, prettyBody,
  responseSummary, statusBand, truncationNotice,
} from "../../main/static/js/apitester/response-model.js";
import {
  EMPTY_HISTORY_HTML, HISTORY_KEY, addToHistory, clearHistory, itemHtml, readHistory,
} from "../../main/static/js/apitester/history.js";

test("prettyBody indents JSON and keeps other text", () => {
  assert.equal(prettyBody('{"a":1}'), '{\n  "a": 1\n}');
  assert.equal(prettyBody("plain"), "plain");
  assert.equal(prettyBody('"str"'), '"str"');
  assert.equal(prettyBody("  "), "  ");
  assert.equal(prettyBody({ a: 1 }), '{\n  "a": 1\n}');
  assert.equal(prettyBody(5), "5");
  assert.equal(prettyBody(null), "");
  assert.equal(byteLength("é"), 2);
  assert.equal(byteLength(undefined), 0);
});

test("describeResponse handles JSON, text and truncation", () => {
  const json = describeResponse({ status: 200, reason: "OK", headers: { a: "1" }, text: "x".repeat(10), json: { ok: true } }, 10);
  assert.equal(json.ok, true);
  assert.equal(json.truncated, false);
  assert.equal(json.rawText, '{"ok":true}');
  const text = describeResponse({ status_code: 500, text: "y".repeat(10), json: null }, 10);
  assert.equal(text.ok, false);
  assert.equal(text.truncated, true);
  assert.equal(text.truncatedAt, 10);
  const empty = describeResponse(null);
  assert.equal(empty.status, 0);
  assert.deepEqual(empty.headers, {});
  assert.equal(empty.ok, false);
});

test("formatDuration, formatMeta and truncationNotice", () => {
  assert.equal(formatDuration(305.4), "305 ms");
  assert.equal(formatDuration(2500), "2.5 seconds");
  assert.equal(formatDuration(-3), "0 ms");
  assert.equal(formatDuration("x"), "0 ms");
  assert.equal(formatMeta({ sizeBytes: 1, truncated: false }), "Size: 1 byte");
  assert.equal(formatMeta({ sizeBytes: 9, truncated: true }), "Size: 9 bytes · only the first part is shown");
  assert.match(truncationNotice({ truncated: true, truncatedAt: 2000 }), /first 2000 characters/);
  assert.equal(truncationNotice({ truncated: false }), "");
});

test("responseSummary gives the plain summary line", () => {
  assert.deepEqual(responseSummary({ status: 200, reason: "OK" }, 305), { tone: "ok", icon: "✓", text: "Success (200 OK) in 305 ms" });
  assert.equal(responseSummary({ status: 302, reason: "" }, 5).text, "Success (redirected) (302) in 5 ms");
  const notFound = responseSummary({ status: 404, reason: "Not Found" }, 20);
  assert.equal(notFound.tone, "warn");
  assert.equal(notFound.icon, "!");
  assert.match(notFound.text, /^Not found\. Check the address \(404 Not Found\)/);
  assert.equal(responseSummary({ status: 503, reason: "Unavailable" }, 1).tone, "bad");
  assert.equal(statusBand(418).label, "The request was refused");
  assert.equal(statusBand(401).label, "Sign-in needed. Check the details under Sign-in");
  assert.equal(statusBand(999).tone, "bad");
});

test("failureSummary explains why there is no reply", () => {
  assert.equal(failureSummary({ status: 0, message: "x" }).text, "The evaluation service could not be reached");
  assert.equal(failureSummary({ status: 504, message: "HTTP request timed out" }).text, "The server took too long to answer");
  const cert = failureSummary({ status: 502, message: "HTTP request failed: [SSL: CERTIFICATE_VERIFY_FAILED]" });
  assert.match(cert.text, /security certificate/);
  const down = failureSummary({ status: 502, message: "HTTP request failed: All connection attempts failed" });
  assert.equal(down.text, "The server could not be reached");
  assert.equal(down.icon, "×");
  assert.match(down.details, /connection attempts/);
  assert.equal(failureSummary({ status: 422, message: "url: Field required" }).text, "The request could not be sent");
  assert.equal(failureSummary(undefined).details, "");
});

test("historyStatus shows a symbol with the code", () => {
  assert.equal(historyStatus("200"), "✓ 200");
  assert.equal(historyStatus(404), "! 404");
  assert.equal(historyStatus(500), "× 500");
  assert.equal(historyStatus("0"), "× No answer");
  assert.equal(historyStatus(undefined), "× No answer");
});

test("history keeps unique method+URL pairs, newest first, max 20", () => {
  const items = Array.from({ length: 20 }, (_, i) => ({ method: "GET", url: `http://h/${i}` }));
  const next = addToHistory(items, { method: "GET", url: "http://h/5" });
  assert.equal(next.length, 20);
  assert.equal(next[0].url, "http://h/5");
  assert.equal(next.filter((x) => x.url === "http://h/5").length, 1);
  assert.equal(addToHistory(items, { method: "POST", url: "http://new" }).length, 20);
});

test("itemHtml escapes and shows the status badge", () => {
  const html = itemHtml({ method: "POST", url: "http://h/<x>", status: "404" }, 3);
  assert.match(html, /data-i="3"/);
  assert.match(html, /http:\/\/h\/&lt;x&gt;/);
  assert.match(html, /! 404/);
  assert.match(EMPTY_HISTORY_HTML, /send them again/);
});

test("readHistory and clearHistory tolerate missing or broken storage", () => {
  const warn = console.warn;
  console.warn = () => {};
  const store = new Map();
  globalThis.localStorage = {
    getItem: (k) => store.get(k) ?? null,
    setItem: (k, v) => store.set(k, v),
    removeItem: (k) => store.delete(k),
  };
  assert.deepEqual(readHistory(), []);
  store.set(HISTORY_KEY, JSON.stringify([{ method: "GET", url: "u" }]));
  assert.equal(readHistory().length, 1);
  store.set(HISTORY_KEY, "{not json");
  assert.deepEqual(readHistory(), []);
  store.set(HISTORY_KEY, JSON.stringify({ a: 1 }));
  assert.deepEqual(readHistory(), []);
  clearHistory();
  assert.equal(store.has(HISTORY_KEY), false);
  globalThis.localStorage = { getItem() { throw new Error("blocked"); }, removeItem() { throw new Error("blocked"); } };
  assert.deepEqual(readHistory(), []);
  clearHistory();
  delete globalThis.localStorage;
  console.warn = warn;
});
