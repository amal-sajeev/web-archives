// The Runner's list of evaluations (run with: node --test src/tests/js).
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  MAX_SELECTED, MODES, entryFromRecord, entryWhen, newEntry, outcome, passCount, reconcileSelection, runListItem,
  selectedEntries, selectionMode, settingsSummary, toggleSelection,
} from "../../main/static/js/playground/runner-list-model.js";
import { NO_RUNS_HTML, runItemHtml } from "../../main/static/js/playground/runner-list.js";

const NOW = new Date(2026, 8, 28, 12, 0);
const RUN = {
  run_id: "r1", status: "FAIL", weighted_score: 0.5, creation_ts: new Date(2026, 8, 28, 9, 0).toISOString(),
  case_results: [
    { case_id: "a", passed: true },
    { case_id: "b", passed: false },
    { case_id: "c", passed: true, observation: { error: "boom" } },
  ],
};
const META = { startedAt: new Date(2026, 8, 28, 10, 5).toISOString(), reps: 2, caseIds: ["a", "b", "c"], totalCases: 3, customUrl: false };

test("entryFromRecord turns stored records into entries", () => {
  const entry = entryFromRecord({ savedAt: 5, run: RUN }, 2);
  assert.deepEqual(entry, { id: "5-r1", savedAt: 5, meta: null, run: RUN });
  assert.equal(entryFromRecord({ savedAt: 5, run: {} }, 3).id, "5-3");
  assert.equal(entryFromRecord({ id: "x", run: RUN, meta: META }).meta, META);
  assert.equal(entryFromRecord({ run: RUN, meta: "bad" }).meta, null);
  assert.equal(entryFromRecord({ savedAt: 1 }), null);
  assert.equal(entryFromRecord(null), null);
  const fresh = newEntry(RUN, META, 99);
  assert.equal(fresh.id, "99-r1");
  assert.equal(fresh.savedAt, 99);
  assert.equal(newEntry({}, null, 7).id, "7-run");
});

test("ticking keeps at most two evaluations, dropping the oldest tick", () => {
  assert.equal(MAX_SELECTED, 2);
  assert.deepEqual(toggleSelection([], "a", true), ["a"]);
  assert.deepEqual(toggleSelection(["a"], "b", true), ["a", "b"]);
  assert.deepEqual(toggleSelection(["a", "b"], "c", true), ["b", "c"]);
  assert.deepEqual(toggleSelection(["a", "b"], "a", false), ["b"]);
  assert.deepEqual(toggleSelection(["a"], "a", true), ["a"]);
  assert.deepEqual(toggleSelection(null, "a", false), []);
});

test("reconcileSelection keeps known ticks or ticks the newest", () => {
  const entries = [{ id: "new" }, { id: "old" }];
  assert.deepEqual(reconcileSelection(["old", "gone"], entries), ["old"]);
  assert.deepEqual(reconcileSelection(["gone"], entries), ["new"]);
  assert.deepEqual(reconcileSelection([], []), []);
  assert.deepEqual(reconcileSelection(["a", "b", "c"], [{ id: "a" }, { id: "b" }, { id: "c" }]), ["b", "c"]);
});

test("selectionMode and selectedEntries", () => {
  assert.equal(selectionMode([]), MODES.none);
  assert.equal(selectionMode(["a"]), MODES.single);
  assert.equal(selectionMode(["a", "b"]), MODES.compare);
  assert.equal(selectionMode(undefined), MODES.none);
  const entries = [{ id: "a" }, { id: "b" }];
  assert.deepEqual(selectedEntries(["b", "a", "x"], entries), [{ id: "b" }, { id: "a" }]);
});

test("passCount does not count tests the AI assistant could not answer", () => {
  assert.deepEqual(passCount(RUN), { passed: 1, total: 3 });
  assert.deepEqual(passCount(null), { passed: 0, total: 0 });
});

test("settingsSummary describes tests, reviews and address", () => {
  assert.equal(settingsSummary(null), "Settings not recorded");
  assert.equal(settingsSummary(META), "All 3 tests · 2 reviews per answer · Address from agent.yaml");
  assert.equal(settingsSummary({ caseIds: ["a"], totalCases: 3, reps: 1, customUrl: true }), "1 of 3 tests · 1 review per answer · Custom address");
  assert.equal(settingsSummary({ caseIds: ["a", "b"] }), "2 tests · 1 review per answer · Address from agent.yaml");
  assert.equal(settingsSummary({ caseIds: ["a"] }), "1 test · 1 review per answer · Address from agent.yaml");
  assert.match(settingsSummary({}), /^All tests/);
});

test("outcome and entryWhen use the shared wording", () => {
  assert.deepEqual(outcome({ status: "PASS" }), { kind: "pass", verdict: "Passed", icon: "✓" });
  assert.equal(outcome({ status: "ERROR", error_detail: "cancelled" }).verdict, "Stopped");
  assert.match(entryWhen({ meta: META, run: RUN }, NOW), /^Today at /);
  assert.equal(entryWhen({}, NOW), "Unknown time");
});

test("runListItem summarises one evaluation", () => {
  const item = runListItem({ id: "e1", meta: META, run: RUN }, ["e1"], NOW);
  assert.equal(item.verdict, "Needs attention");
  assert.equal(item.score, "50%");
  assert.equal(item.passed, "1 of 3 tests passed");
  assert.equal(item.checked, true);
  assert.match(item.when, /^Today at /);
  assert.equal(runListItem({ id: "e2", run: {} }, [], NOW).checked, false);
  assert.equal(runListItem(null).id, "");
});

test("runItemHtml escapes and links the checkbox to its label", () => {
  const html = runItemHtml({ ...runListItem({ id: 'x"<', meta: META, run: RUN }, ['x"<'], NOW) }, 4);
  assert.match(html, /id="run-pick-4"/);
  assert.match(html, /for="run-pick-4"/);
  assert.match(html, /data-run-id="x&quot;&lt;"/);
  assert.match(html, / checked>/);
  assert.match(html, /class="run-item selected"/);
  assert.match(NO_RUNS_HTML, /No evaluations yet/);
});
