"""CloudSqlRepository SQL building, parameter binding and row mapping (no database).

Every call runs against the FakeEngine from ``pg_fakes``; the tests assert on the
statements and bound parameters the repository sends and on how it maps rows.
"""

from __future__ import annotations

import json
from datetime import datetime

import pytest

from pg_fakes import FakeResult, pg_fixture  # noqa: F401
from repository._summary_sql import ITEM_FIELDS
from repository.postgres_repo import CloudSqlRepository

_SET_PATH = 'SET LOCAL search_path TO "monitoring"'


@pytest.fixture
def repo(pg):
    return CloudSqlRepository()


def _last(pg):
    return pg.conn.executed[-1]


def test_every_transaction_scopes_the_search_path(pg, repo):
    repo.get_baseline("a", "d", "1", "m")
    assert pg.statements[0] == _SET_PATH


def test_init_schema_passes_when_tables_exist(pg, repo):
    pg.responder = lambda _sql, _params: FakeResult(scalar=1)
    repo.init_schema()


def test_init_schema_names_missing_tables(pg, repo):
    pg.responder = lambda _sql, _params: FakeResult(scalar=None)
    with pytest.raises(RuntimeError, match="missing tables") as exc_info:
        repo.init_schema()
    assert "eval_execution" in str(exc_info.value)


def test_ping(pg, repo):
    assert repo.ping() is True
    pg.fail = ConnectionError("down")
    assert repo.ping() is False


def test_save_run_upserts_jsonb_detail_and_naive_utc(pg, repo, make_run):
    run = make_run("r1", creation_ts="2026-01-02T03:04:05.678+02:00", cases=[("c1", True, 0.9)])

    repo.save_run(run)

    sql, params = _last(pg)
    assert "ON CONFLICT (eval_execution_id) DO UPDATE" in sql
    assert "CAST(:detail_json AS JSONB)" in sql
    assert params["creation_ts"] == datetime(2026, 1, 2, 1, 4, 5, 678000)
    assert json.loads(params["detail_json"])["case_results"][0]["case_id"] == "c1"
    assert (params["run_id"], params["status"]) == ("r1", "PASS")


@pytest.mark.parametrize("as_text", [True, False])
def test_get_run_accepts_text_or_decoded_json(pg, repo, make_run, as_text):
    detail = make_run("r1").model_dump_json()
    pg.responder = lambda _sql, _params: FakeResult(row=(detail if as_text else json.loads(detail),))

    run = repo.get_run("r1")

    assert run.run_id == "r1"
    assert _last(pg)[1] == {"run_id": "r1"}


def test_get_run_missing_returns_none(pg, repo):
    pg.responder = lambda _sql, _params: FakeResult(row=None)
    assert repo.get_run("nope") is None


def test_list_runs_builds_jsonb_query_and_renders_aware_timestamps(pg, repo):
    row = {field: None for field in ITEM_FIELDS} | {"run_id": "r1", "creation_ts": datetime(2026, 1, 2, 3, 4, 5)}
    pg.responder = lambda _sql, _params: FakeResult(rows=[row])

    rows = repo.list_runs(agent_id="a", limit=5, before="2026-01-03T00:00:00Z", before_id="r9", status="ERROR")

    sql, params = _last(pg)
    assert "jsonb_array_length(detail_json -> 'case_results')" in sql
    assert "(detail_json ->> 'error_detail') AS error_detail" in sql
    assert "status LIKE :status" in sql
    assert params["before_ts"] == datetime(2026, 1, 3)
    assert (params["limit"], params["status"], params["before_id"]) == (5, "ERROR%", "r9")
    assert rows[0]["creation_ts"] == "2026-01-02T03:04:05.000+00:00"


def test_run_summary_single_statement_and_mapping(pg, repo):
    row = {"total": 3, "passed": 1, "failed": 1, "errored": 0, "cancelled": 1, "average_score": 0.5}
    row |= {f"latest_{f}": None for f in ITEM_FIELDS} | {f"previous_{f}": None for f in ITEM_FIELDS}
    row |= {"latest_run_id": "r3", "latest_creation_ts": datetime(2026, 1, 3), "latest_case_count": 2}
    pg.responder = lambda _sql, _params: FakeResult(rows=[row])

    summary = repo.run_summary(agent_id="a", dataset_id="d", since="2026-01-01")

    sql, params = _last(pg)
    assert len(pg.statements) == 2  # search_path + one summary query
    assert sql.startswith("WITH filtered AS")
    assert params["since"] == datetime(2026, 1, 1)
    assert (params["agent_id"], params["dataset_id"], params["cancelled"]) == ("a", "d", "cancelled")
    assert summary["average_score"] == 0.5
    assert summary["latest"]["creation_ts"] == "2026-01-03T00:00:00.000+00:00"
    assert summary["latest"]["case_count"] == 2
    assert summary["previous"] is None


def test_baselines_round_trip_parameters(pg, repo):
    pg.responder = lambda _sql, _params: FakeResult(row=("0.75",))

    value = repo.get_baseline("a", "d", "1", "m")
    repo.set_baseline("a", "d", "1", "m", 0.8, "CI_CD")

    sql, params = _last(pg)
    assert value == 0.75
    assert "ON CONFLICT (agent_id, dataset_id, dataset_version, baseline_metric_name)" in sql
    assert (params["val"], params["created_by"]) == (0.8, "CI_CD")
    assert isinstance(params["created_ts"], datetime) and params["created_ts"].tzinfo is None


def test_get_baseline_missing(pg, repo):
    pg.responder = lambda _sql, _params: FakeResult(row=None)
    assert repo.get_baseline("a", "d", "1", "m") is None


def test_delete_old_runs(pg, repo):
    assert repo.delete_old_runs(0) == 0
    assert pg.statements == []

    pg.responder = lambda _sql, _params: FakeResult(rowcount=4)
    assert repo.delete_old_runs(30) == 4
    assert _last(pg)[0].startswith("DELETE FROM eval_execution WHERE creation_ts < :cutoff")


def test_close_disposes_engine(pg, repo):
    repo.close()
    assert pg.disposed is True
