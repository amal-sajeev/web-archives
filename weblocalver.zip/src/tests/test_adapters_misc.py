"""Adapter pieces not covered elsewhere: templating, request auth/bodies, registry, capture."""

from __future__ import annotations

import base64
import json

import httpx
import pytest

from adapters import capture
from adapters.capture import CaptureMetricsClient, CaptureStore, observation_to_cta_action
from adapters.http_adapter import HttpAdapter
from adapters.http_request import build_headers, build_params
from adapters.registry import get_registered_adapter, register_adapter
from adapters.templating import dotted, resolve_template, resolve_text_map
from core.models import GoldenCase, Observation, TargetSpec
from core_helpers import capture_logs, mock_http_fixture  # noqa: F401

_BASE = "http://localhost:9999"


def _target(**kw) -> TargetSpec:
    return TargetSpec(adapter="http", endpoint="/t", **kw)


class TestTemplating:
    @pytest.mark.parametrize("path", ["items.9", "items.x", "name.deeper"])
    def test_unreachable_paths_are_none(self, path):
        assert dotted({"items": [1], "name": "a"}, path) is None

    def test_lists_are_resolved_recursively(self):
        assert resolve_template(["${input.a}", {"b": "${input.b}"}, 7], {"a": 1, "b": "x"}) == [1, {"b": "x"}, 7]

    def test_text_map_coerces_to_text(self):
        assert resolve_text_map({"n": "${input.n}", "z": "${input.none}"}, {"n": 5}) == {"n": "5", "z": ""}


class TestRequestAuth:
    def test_basic_auth_from_env(self, monkeypatch):
        monkeypatch.setenv("U", "alice")
        monkeypatch.setenv("P", "s3cret")
        headers = build_headers(_target(auth={"type": "basic", "username_env": "U", "password_env": "P"}), {})
        assert headers["Authorization"] == "Basic " + base64.b64encode(b"alice:s3cret").decode()

    def test_basic_auth_with_empty_env_sends_nothing(self, monkeypatch):
        monkeypatch.delenv("U", raising=False)
        auth = {"type": "basic", "username_env": "U", "password_env": "U"}
        assert "Authorization" not in build_headers(_target(auth=auth), {})

    def test_api_key_header_default_and_custom(self, monkeypatch):
        monkeypatch.setenv("K", "key-1")
        assert build_headers(_target(auth={"type": "api_key_header", "token_env": "K"}), {})["X-API-Key"] == "key-1"
        custom = {"type": "api_key_header", "token_env": "K", "header": "X-Token"}
        assert build_headers(_target(auth=custom), {})["X-Token"] == "key-1"

    def test_api_key_query_missing_env_adds_no_param(self, monkeypatch):
        monkeypatch.delenv("K", raising=False)
        assert build_params(_target(auth={"type": "api_key_query", "token_env": "K"}), {}) is None


class TestRequestBodies:
    async def test_form_body_dict_is_urlencoded(self, mock_http):
        seen = mock_http(lambda r: httpx.Response(200, json={}))
        target = _target(body_type="form", body={"q": "${input.q}"})
        await HttpAdapter(_BASE, "/t", target).run_case(GoldenCase(id="c", input={"q": "a b"}))
        assert seen[0].content == b"q=a+b"
        assert seen[0].headers["content-type"] == "application/x-www-form-urlencoded"

    async def test_form_body_string_keeps_explicit_header(self, mock_http):
        seen = mock_http(lambda r: httpx.Response(200, json={}))
        target = _target(body_type="form", body="q=${input.q}", headers={"content-type": "text/x-custom"})
        await HttpAdapter(_BASE, "/t", target).run_case(GoldenCase(id="c", input={"q": "1"}))
        assert seen[0].content == b"q=1"
        assert seen[0].headers["content-type"] == "text/x-custom"

    @pytest.mark.parametrize(("body", "expected"), [("raw ${input.q}", b"raw 1"), ({"a": 1}, b'{"a": 1}')])
    async def test_raw_body(self, mock_http, body, expected):
        seen = mock_http(lambda r: httpx.Response(200, json={}))
        await HttpAdapter(_BASE, "/t", _target(body_type="raw", body=body)).run_case(GoldenCase(id="c", input={"q": 1}))
        assert seen[0].content == expected


class TestAdapterRegistry:
    def test_reregistering_another_class_warns(self):
        @register_adapter("tmp_misc_adapter")
        class First:
            pass

        class Second:
            pass

        with capture_logs("eval_service.adapters") as records:
            register_adapter("tmp_misc_adapter")(Second)
            register_adapter("tmp_misc_adapter")(Second)
        assert get_registered_adapter("tmp_misc_adapter") is Second
        assert len([r for r in records if "re-registered" in r.getMessage()]) == 1
        assert First is not Second


class TestCapture:
    def test_clear_empties_store_and_history(self):
        store = CaptureStore()
        store.put("c1", {"a": 1}, agent_id="x")
        store.clear()
        assert store.history() == []
        assert store.latest() == {}

    def test_confidence_from_metadata_skips_non_numeric(self):
        observation = Observation(target_id="t", metadata={"ai_confidence": "high", "confidence": "0.4"})
        assert capture._confidence(observation) == pytest.approx(0.4)
        assert capture._confidence(Observation(target_id="t", error="boom")) == 0.0

    def test_tool_calls_become_cta_tool_entries(self):
        observation = Observation(
            target_id="agent", latency_ms=50, error="boom",
            tool_calls=[{"name": "lookup", "args": {"id": 1}, "latency_ms": 7}, {"Tool_Id": "legacy"}],
        )
        payload = observation_to_cta_action("c1", observation)["CTA_ACTION"]["payload"]
        first, second = payload["Tool_Calls"]
        assert first["Tool_Id"] == "lookup" and first["Tool_Latency"] == "7"
        assert json.loads(first["Tool_Param"].replace("'", '"')) == {"id": 1}
        assert first["Tool_Errors"] == ["boom"]
        assert second["Tool_Id"] == "legacy" and second["Tool_Param"] == ""
        assert payload["Response_Code"] == "502"

    async def test_fetch_without_observation_reads_existing_capture(self):
        store = CaptureStore()
        client = CaptureMetricsClient(store, agent_id="a")
        assert await client.fetch("c1") == {}
        live = await client.fetch("c1", Observation(target_id="t", latency_ms=10, tool_calls=[{"name": "x"}]))
        assert await client.fetch("c1") == live
