"""Postgres engine plumbing (``repository._pg_engine``) without a database.

``create_engine`` is replaced by a FakeEngine (see ``pg_fakes``); the pg8000 and
Cloud SQL Connector entry points are replaced by recorders.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta, timezone

import google.auth
import pg8000.dbapi
import pytest
from google.cloud.sql import connector as sql_connector

from core.config import Config
from pg_fakes import FakeResult, pg_fixture  # noqa: F401
from repository import _pg_engine
from repository._pg_engine import PgEngine, configured_schema, set_search_path, to_aware_iso, to_naive_utc


class _RecordingConnector:
    instances: list[_RecordingConnector] = []

    def __init__(self, ip_type=None):
        self.ip_type = ip_type
        self.calls: list[tuple] = []
        self.closed = False
        _RecordingConnector.instances.append(self)

    def connect(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        return "connector-conn"

    def close(self):
        self.closed = True


@pytest.fixture
def connector_mode(pg, monkeypatch):
    """Switch the ``pg`` fixture to Cloud SQL Connector mode with ADC available."""
    _RecordingConnector.instances.clear()
    monkeypatch.setattr(Config, "DB_HOST", "")
    monkeypatch.setattr(Config, "DB_INSTANCE_CONNECTION_NAME", "proj:region:inst")
    monkeypatch.setattr(Config, "DB_IP_TYPE", "private")
    monkeypatch.setattr(google.auth, "default", lambda: ("creds", "proj"))
    monkeypatch.setattr(sql_connector, "Connector", _RecordingConnector)
    return pg


@pytest.mark.parametrize(("schema", "expected"), [("", None), ("public", None), ("monitoring", "monitoring")])
def test_configured_schema(monkeypatch, schema, expected):
    monkeypatch.setattr(Config, "DB_SCHEMA", schema)
    assert configured_schema() == expected


def test_configured_schema_rejects_non_identifier(monkeypatch):
    monkeypatch.setattr(Config, "DB_SCHEMA", 'x"; DROP TABLE t; --')
    with pytest.raises(RuntimeError, match="not a valid Postgres identifier"):
        configured_schema()


def test_set_search_path_is_transaction_local(pg):
    set_search_path(pg.conn, "monitoring")
    set_search_path(pg.conn, None)
    assert pg.statements == ['SET LOCAL search_path TO "monitoring"']


def test_engine_configures_pool_and_tcp_driver(pg, monkeypatch):
    seen = {}
    monkeypatch.setattr(pg8000.dbapi, "connect", lambda **kw: seen.update(kw) or "tcp-conn")

    engine = PgEngine()

    assert engine.use_tcp is True
    assert engine.schema == "monitoring"
    assert pg.kwargs["url"] == "postgresql+pg8000://"
    assert (pg.kwargs["pool_size"], pg.kwargs["max_overflow"]) == (_pg_engine.POOL_SIZE, _pg_engine.POOL_MAX_OVERFLOW)
    assert pg.kwargs["pool_pre_ping"] is True
    assert pg.kwargs["creator"]() == "tcp-conn"
    assert seen == {"host": "127.0.0.1", "port": 5432, "user": "runtime_user", "password": "pw", "database": "evaldb"}


def test_engine_requires_db_name(pg, monkeypatch):
    monkeypatch.setattr(Config, "DB_NAME", "")
    with pytest.raises(RuntimeError, match="DB_NAME"):
        PgEngine()


def test_engine_requires_password(pg, monkeypatch):
    monkeypatch.setattr(Config, "DB_PASSWORD", None)
    with pytest.raises(RuntimeError, match="DB_PASSWORD"):
        PgEngine()


def test_connector_mode_uses_private_ip_and_closes_on_dispose(connector_mode):
    engine = PgEngine()
    connector = _RecordingConnector.instances[0]

    assert engine.use_tcp is False
    assert connector.ip_type == sql_connector.IPTypes.PRIVATE
    assert connector_mode.kwargs["creator"]() == "connector-conn"
    assert connector.calls[0] == (
        ("proj:region:inst", "pg8000"), {"user": "runtime_user", "password": "pw", "db": "evaldb"},
    )
    engine.dispose()
    engine.dispose()  # idempotent: the connector is closed once
    assert connector.closed is True
    assert connector_mode.disposed is True


def test_connector_mode_requires_instance_name(connector_mode, monkeypatch):
    monkeypatch.setattr(Config, "DB_INSTANCE_CONNECTION_NAME", "")
    with pytest.raises(RuntimeError, match="DB_INSTANCE_CONNECTION_NAME"):
        PgEngine()


def test_connector_mode_requires_adc(connector_mode, monkeypatch):
    def _no_adc():
        raise google.auth.exceptions.DefaultCredentialsError("none")

    monkeypatch.setattr(google.auth, "default", _no_adc)
    with pytest.raises(RuntimeError, match="Application Default Credentials"):
        PgEngine()


def test_missing_tables_queries_qualified_names(pg):
    pg.responder = lambda sql, params: FakeResult(scalar=None if params and "b" in params["qualified"] else 1)

    missing = PgEngine().missing_tables(("a", "b"))

    assert missing == ["b"]
    assert pg.statements[0] == 'SET LOCAL search_path TO "monitoring"'
    assert pg.conn.executed[1][1] == {"qualified": '"monitoring".a'}


def test_missing_tables_retries_then_succeeds(pg, monkeypatch):
    sleeps = []
    engine = PgEngine()
    pg.fail = ConnectionError("proxy not up yet")

    def _recover(_seconds):
        sleeps.append(_seconds)
        pg.fail = None

    monkeypatch.setattr(_pg_engine.time, "sleep", _recover)
    pg.responder = lambda _sql, _params: FakeResult(scalar=1)

    assert engine.missing_tables(("a",)) == []
    assert sleeps == [_pg_engine.VERIFY_DELAY_SECONDS]


def test_missing_tables_gives_up_after_attempts(pg, monkeypatch):
    monkeypatch.setattr(_pg_engine, "VERIFY_ATTEMPTS_TCP", 2)
    monkeypatch.setattr(_pg_engine.time, "sleep", lambda _s: None)
    engine = PgEngine()
    pg.fail = ConnectionError("down")

    with pytest.raises(RuntimeError, match="Could not verify the CloudSQL schema"):
        engine.missing_tables(("a",))


def test_to_naive_utc_truncates_to_milliseconds():
    value = datetime(2026, 1, 2, 3, 4, 5, 123456, tzinfo=timezone(timedelta(hours=2)))
    assert to_naive_utc(value) == datetime(2026, 1, 2, 1, 4, 5, 123000)
    assert to_naive_utc("2026-01-02T03:04:05Z") == datetime(2026, 1, 2, 3, 4, 5)


def test_to_aware_iso_renders_utc_strings():
    assert to_aware_iso(datetime(2026, 1, 2, 3, 4, 5)) == "2026-01-02T03:04:05.000+00:00"
    assert to_aware_iso(datetime(2026, 1, 2, 3, 4, 5, 1, tzinfo=UTC)) == "2026-01-02T03:04:05.000001+00:00"
    assert to_aware_iso("already-a-string") == "already-a-string"
