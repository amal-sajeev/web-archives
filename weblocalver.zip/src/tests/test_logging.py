"""Structured JSON logging."""

from __future__ import annotations

import json
import logging
from datetime import datetime, UTC

from core.structured_logging import StructuredFormatter, get_logger


def _record(**extra) -> logging.LogRecord:
    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname="", lineno=0, msg="test message", args=None, exc_info=None,
    )
    for key, value in extra.items():
        setattr(record, key, value)
    return record


def test_get_logger_returns_logger():
    log = get_logger("test")
    assert log.name == "test"
    assert log.level <= logging.INFO


def test_structured_formatter_includes_extras():
    parsed = json.loads(StructuredFormatter().format(_record(trace_id="abc123", agent_id="my_agent")))
    assert parsed["msg"] == "test message"
    assert parsed["trace_id"] == "abc123"
    assert parsed["agent_id"] == "my_agent"
    assert parsed["level"] == "INFO"


def test_formatter_keeps_every_extra_field():
    parsed = json.loads(StructuredFormatter().format(_record(error="boom", passed=True, score=0.5, status="PASS")))
    assert parsed["error"] == "boom"
    assert parsed["passed"] is True
    assert parsed["score"] == 0.5
    assert "pathname" not in parsed and "lineno" not in parsed


def test_timestamp_comes_from_record_created():
    record = _record()
    record.created = 0.0
    parsed = json.loads(StructuredFormatter().format(record))
    assert parsed["ts"] == datetime.fromtimestamp(0, UTC).isoformat()


def test_eval_service_logger_does_not_propagate():
    get_logger("eval_service.test")
    assert logging.getLogger("eval_service").propagate is False
