"""Handler tests: evaluation lifecycle (sync, start/async, A/B, streams, cancel)."""

from __future__ import annotations

import asyncio
import importlib
import json
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from fastapi import HTTPException
from fastapi.responses import StreamingResponse

from conftest import FakeRegistry, FakeRunner
from core.models import ABCompareRequest, AsyncEvaluateRequest, EvaluateRequest
from core.run_manager import run_manager
from handlers.evaluate import (
    _drive_run,
    evaluate,
    evaluate_ab,
    evaluate_async,
    evaluate_cancel,
    evaluate_start,
    evaluate_stream,
    evaluate_stream_events,
    evaluate_streams,
)

evaluate_module = importlib.import_module("handlers.evaluate")


def _raising(exc):
    async def _handler(agent_id, progress=None):
        raise exc
    return _handler


async def _hang(agent_id, progress=None):
    await asyncio.Event().wait()


class _DummyRequest:
    async def is_disconnected(self):
        return False


async def _start(runner, agent_id="agent-1"):
    response = await evaluate_start(EvaluateRequest(agent_id=agent_id), runner, FakeRegistry())
    return response, run_manager.get(json.loads(response.body)["stream_id"])


async def test_evaluate_returns_run_dict():
    runner = MagicMock()
    run = MagicMock()
    run.model_dump.return_value = {"run_id": "123"}
    runner.evaluate = AsyncMock(return_value=run)

    result = await evaluate(EvaluateRequest(agent_id="test"), runner)

    assert result == {"run_id": "123"}


@pytest.mark.parametrize(("exc", "status"), [
    (KeyError("Unknown agent 'x'"), 404),
    (ValueError("bad version"), 400),
    (httpx.ConnectError("refused"), 502),
    (RuntimeError("secret internals"), 500),
])
async def test_evaluate_maps_exceptions(make_run, exc, status):
    runner = FakeRunner(make_run)
    runner.handler = _raising(exc)

    with pytest.raises(HTTPException) as exc_info:
        await evaluate(EvaluateRequest(agent_id="agent-1"), runner)

    assert exc_info.value.status_code == status
    if status == 500:
        assert "secret internals" not in exc_info.value.detail
        assert "error_id=" in exc_info.value.detail


async def test_evaluate_start_returns_202_with_location(make_run):
    response, live = await _start(FakeRunner(make_run))
    await live.task

    assert response.status_code == 202
    assert response.headers["location"] == "stream/" + live.stream_id
    assert live.done
    assert live.run_id == "run-agent-1"
    assert live.finished_run.run_id == "run-agent-1"


async def test_evaluate_start_unknown_agent_404(make_run):
    with pytest.raises(HTTPException) as exc_info:
        await _start(FakeRunner(make_run), agent_id="nope")
    assert exc_info.value.status_code == 404


async def test_drive_run_publishes_generic_error_without_traceback(make_run):
    live = run_manager.create("agent-1")
    runner = FakeRunner(make_run)
    runner.handler = _raising(RuntimeError("kaboom"))

    await _drive_run(live, "agent-1", None, 1, "DEVELOPER", runner)

    errors = [e for e in live.events if e.get("type") == "error"]
    assert live.done is True
    assert len(errors) == 1
    assert errors[0]["status"] == 500
    assert errors[0]["error_type"] == "RuntimeError"
    assert errors[0]["error_id"]
    assert "traceback" not in errors[0]
    assert "kaboom" not in errors[0]["detail"]


async def test_drive_run_upstream_error_is_502(make_run):
    live = run_manager.create("agent-1")
    runner = FakeRunner(make_run)
    runner.handler = _raising(httpx.ReadTimeout("slow"))

    await _drive_run(live, "agent-1", None, 1, "DEVELOPER", runner)

    assert live.events[-1]["status"] == 502


async def test_cancel_flow_202_then_run_cancelled(make_run):
    runner = FakeRunner(make_run)
    runner.handler = _hang
    _response, live = await _start(runner)
    await asyncio.sleep(0)  # let the driver start

    result = await evaluate_cancel(live.stream_id)
    with pytest.raises(asyncio.CancelledError):
        await live.task

    types = [e["type"] for e in live.events]
    assert result == {"stream_id": live.stream_id, "status": "cancel_requested"}
    assert live.cancel_requested is True
    assert types[-1] == "run_cancelled"
    assert types.count("run_cancelled") == 1
    assert live.done is True


async def test_cancel_before_task_starts_still_finishes(make_run):
    runner = FakeRunner(make_run)
    runner.handler = _hang
    _response, live = await _start(runner)

    await evaluate_cancel(live.stream_id)  # task has not run yet
    with pytest.raises(asyncio.CancelledError):
        await live.task
    await asyncio.sleep(0)  # done-callbacks run on the next loop iteration

    assert live.done is True
    assert live.events[-1]["type"] == "run_cancelled"


async def test_cancel_finished_run_is_409():
    live = run_manager.create("agent-1")
    live.finish()

    with pytest.raises(HTTPException) as exc_info:
        await evaluate_cancel(live.stream_id)

    assert exc_info.value.status_code == 409


async def test_cancel_unknown_stream_is_404():
    with pytest.raises(HTTPException) as exc_info:
        await evaluate_cancel("missing")
    assert exc_info.value.status_code == 404


async def test_evaluate_async_fires_webhook_on_error(make_run, monkeypatch):
    delivered = []

    async def fake_deliver(url, payload):
        delivered.append((url, payload))

    monkeypatch.setattr(evaluate_module, "_deliver_webhook", fake_deliver)
    runner = FakeRunner(make_run)
    runner.handler = _raising(ValueError("bad"))
    request = AsyncEvaluateRequest(agent_id="agent-1", webhook_url="http://hook.test/x")

    response = await evaluate_async(request, runner, FakeRegistry())
    live = run_manager.get(json.loads(response.body)["stream_id"])
    await live.task
    await asyncio.sleep(0)

    assert response.status_code == 202
    assert len(delivered) == 1
    url, payload = delivered[0]
    assert url == "http://hook.test/x"
    assert payload["status"] == "ERROR"
    assert payload["detail"] == "bad"


async def test_evaluate_async_webhook_gets_run_on_success(make_run, monkeypatch):
    delivered = []

    async def fake_deliver(url, payload):
        delivered.append(payload)

    monkeypatch.setattr(evaluate_module, "_deliver_webhook", fake_deliver)
    request = AsyncEvaluateRequest(agent_id="agent-1", webhook_url="http://hook.test/x")

    response = await evaluate_async(request, FakeRunner(make_run), FakeRegistry())
    await run_manager.get(json.loads(response.body)["stream_id"]).task
    await asyncio.sleep(0)

    assert delivered[0]["run_id"] == "run-agent-1"


async def test_evaluate_ab_compares_and_forwards_created_by(make_run):
    runner = FakeRunner(make_run)
    request = ABCompareRequest(agent_a="agent-1", agent_b="agent-2")

    result = await evaluate_ab(request, runner, FakeRegistry())

    assert {c["agent_id"] for c in runner.calls} == {"agent-1", "agent-2"}
    assert all(c["created_by"] == "DEVELOPER" for c in runner.calls)
    assert result["winner"] == "tie"
    assert result["cases"][0]["case_id"] == "c1"
    assert result["cases"][0]["winner"] == "tie"


@pytest.mark.parametrize(("exc", "status"), [
    (KeyError("x"), 404), (ValueError("x"), 400), (httpx.ConnectError("x"), 502), (RuntimeError("x"), 500),
])
async def test_evaluate_ab_maps_errors(make_run, exc, status):
    runner = FakeRunner(make_run)
    runner.handler = _raising(exc)

    with pytest.raises(HTTPException) as exc_info:
        await evaluate_ab(ABCompareRequest(agent_a="agent-1", agent_b="agent-2"), runner, FakeRegistry())

    assert exc_info.value.status_code == status


async def test_evaluate_ab_unknown_agent_404(make_run):
    with pytest.raises(HTTPException) as exc_info:
        await evaluate_ab(ABCompareRequest(agent_a="agent-1", agent_b="zzz"), FakeRunner(make_run), FakeRegistry())
    assert exc_info.value.status_code == 404


def test_evaluate_streams_lists_runs():
    run_manager.create("agent1")
    run_manager.create("agent2")
    assert len(evaluate_streams()["streams"]) == 2


async def test_evaluate_stream_returns_sse_response():
    live = run_manager.create("test_agent")
    result = await evaluate_stream(live.stream_id, _DummyRequest())
    assert isinstance(result, StreamingResponse)
    assert result.media_type == "text/event-stream"


async def test_evaluate_stream_unknown_404():
    with pytest.raises(HTTPException) as exc_info:
        await evaluate_stream("unknown", _DummyRequest())
    assert exc_info.value.status_code == 404


async def test_evaluate_stream_events_after_and_done():
    live = run_manager.create("test_agent")
    live.publish({"type": "event1"})
    live.publish({"type": "run_done", "run_id": "run-123"})
    live.finish()

    result = await evaluate_stream_events(live.stream_id, after=1)

    assert [e["type"] for e in result["events"]] == ["run_done"]
    assert result["seq"] == 2
    assert result["done"] is True
    assert result["run_id"] == "run-123"
