"""SQLite repository: schema, keyset pagination, counts, retention, migrations."""

from __future__ import annotations

import sqlite3
from contextlib import closing
from datetime import UTC, datetime, timedelta

import pytest

from repository._sql import to_utc_iso
from repository.sqlite_repo import SqliteRepository


def _ts(month: int, day: int) -> str:
    return datetime(2026, month, day, tzinfo=UTC).isoformat()


class TestSchema:
    def test_sqlite_schema_uses_new_eval_keys(self, sqlite_repo):
        with closing(sqlite_repo._connect()) as conn:
            exec_cols = {row["name"]: row for row in conn.execute("PRAGMA table_info(eval_execution)").fetchall()}
            base_cols = {row["name"]: row for row in conn.execute("PRAGMA table_info(eval_baseline)").fetchall()}

        assert "eval_execution_id" in exec_cols
        assert "run_id" not in exec_cols
        assert exec_cols["weighted_score"]["notnull"] == 0
        assert exec_cols["weighted_delta"]["notnull"] == 0
        assert exec_cols["status"]["notnull"] == 1
        assert "eval_baseline_id" in base_cols
        assert base_cols["created_ts"]["type"].upper() == "TIMESTAMP"
        assert base_cols["agent_id"]["notnull"] == 1
        assert base_cols["baseline_metric_name"]["notnull"] == 1

    def test_wal_mode_and_idempotent_init(self, sqlite_repo):
        sqlite_repo.init_schema()
        with closing(sqlite_repo._connect()) as conn:
            assert conn.execute("PRAGMA journal_mode").fetchone()[0].lower() == "wal"

    def test_ping_and_close(self, sqlite_repo):
        assert sqlite_repo.ping() is True
        sqlite_repo.close()


class TestCursorPagination:
    def test_list_runs_with_before_cursor(self, sqlite_repo, make_run):
        for i in range(3):
            sqlite_repo.save_run(make_run(f"run_{i}", score=0.5 + i * 0.1, creation_ts=_ts(1, i + 1)))

        all_runs = sqlite_repo.list_runs(limit=10)
        assert [r["run_id"] for r in all_runs] == ["run_2", "run_1", "run_0"]
        page1 = sqlite_repo.list_runs(limit=2)
        assert [r["run_id"] for r in page1] == ["run_2", "run_1"]
        page2 = sqlite_repo.list_runs(limit=2, before=page1[-1]["creation_ts"])
        assert [r["run_id"] for r in page2] == ["run_0"]

    def test_composite_cursor_breaks_timestamp_ties(self, sqlite_repo, make_run):
        for rid in ("a", "b", "c"):
            sqlite_repo.save_run(make_run(rid, creation_ts=_ts(3, 1)))
        page1 = sqlite_repo.list_runs(limit=2)
        last = page1[-1]
        page2 = sqlite_repo.list_runs(limit=2, before=last["creation_ts"], before_id=last["run_id"])
        assert [r["run_id"] for r in page1] == ["c", "b"]
        assert [r["run_id"] for r in page2] == ["a"]

    def test_case_counts_from_detail_json(self, sqlite_repo, make_run):
        sqlite_repo.save_run(make_run("r1", cases=[("c1", True, 0.9), ("c2", False, 0.2), ("c3", True, 0.7)]))
        sqlite_repo.save_run(make_run("r0", creation_ts=_ts(1, 1)))

        rows = {r["run_id"]: r for r in sqlite_repo.list_runs(limit=10)}

        assert (rows["r1"]["case_count"], rows["r1"]["passed_case_count"]) == (3, 2)
        assert (rows["r0"]["case_count"], rows["r0"]["passed_case_count"]) == (0, 0)

    def test_timestamps_stored_in_one_utc_format(self, sqlite_repo, make_run):
        sqlite_repo.save_run(make_run("r1", creation_ts="2026-01-01T02:00:00+02:00"))
        assert sqlite_repo.list_runs(limit=1)[0]["creation_ts"] == "2026-01-01T00:00:00.000+00:00"

    def test_list_runs_with_status_and_dataset_filters(self, sqlite_repo, make_run):
        entries = [("pass_a", "PASS", "ds1"), ("fail_a", "FAIL", "ds1"), ("err_a", "ERROR", "ds1"),
                   ("pass_b", "PASS", "ds2")]
        for i, (rid, status, dsid) in enumerate(entries):
            sqlite_repo.save_run(make_run(rid, status=status, dataset_id=dsid, creation_ts=_ts(2, i + 1)))

        assert {r["run_id"] for r in sqlite_repo.list_runs(limit=10, status="PASS")} == {"pass_a", "pass_b"}
        assert [r["run_id"] for r in sqlite_repo.list_runs(limit=10, status="ERROR")] == ["err_a"]
        assert {r["run_id"] for r in sqlite_repo.list_runs(limit=10, dataset_id="ds1")} == {"pass_a", "fail_a", "err_a"}
        assert [r["run_id"] for r in sqlite_repo.list_runs(limit=10, dataset_id="ds1", status="PASS")] == ["pass_a"]

    def test_set_baseline_upserts_on_business_key(self, sqlite_repo):
        sqlite_repo.set_baseline("agent1", "ds1", "v1", "faithfulness", 0.8, "DEVELOPER")
        sqlite_repo.set_baseline("agent1", "ds1", "v1", "faithfulness", 0.9, "CI_CD")

        assert sqlite_repo.get_baseline("agent1", "ds1", "v1", "faithfulness") == pytest.approx(0.9)
        with closing(sqlite_repo._connect()) as conn:
            count = conn.execute("SELECT COUNT(*) FROM eval_baseline").fetchone()[0]
            row = conn.execute("SELECT eval_baseline_id, created_by FROM eval_baseline").fetchone()
        assert count == 1
        assert row["eval_baseline_id"]
        assert row["created_by"] == "CI_CD"


class TestDeleteOldRuns:
    def test_delete_old_runs(self, sqlite_repo, make_run):
        now = datetime.now(UTC)
        sqlite_repo.save_run(make_run("old_run", creation_ts=(now - timedelta(days=10)).isoformat()))
        sqlite_repo.save_run(make_run("new_run", creation_ts=(now - timedelta(days=1)).isoformat()))

        assert sqlite_repo.delete_old_runs(5) == 1
        assert [r["run_id"] for r in sqlite_repo.list_runs(limit=10)] == ["new_run"]

    def test_delete_old_runs_zero_days_noop(self, sqlite_repo, make_run):
        sqlite_repo.save_run(make_run("r1"))
        assert sqlite_repo.delete_old_runs(0) == 0
        assert len(sqlite_repo.list_runs(limit=10)) == 1


class TestLegacyMigration:
    def _legacy_db(self, path):
        with closing(sqlite3.connect(path)) as conn, conn:
            conn.execute(
                "CREATE TABLE eval_execution (run_id TEXT PRIMARY KEY, agent_id TEXT, dataset_id TEXT, "
                "dataset_version TEXT, weighted_score REAL, weighted_delta REAL, status TEXT, "
                "creation_ts TEXT, detail_json TEXT)"
            )
            conn.execute(
                "INSERT INTO eval_execution VALUES ('old1','a','d','1',0.5,0.0,'passed','2026-01-02 03:04:05','{}')"
            )

    def test_migrates_legacy_run_table_and_normalises_timestamps(self, tmp_path):
        path = str(tmp_path / "legacy.db")
        self._legacy_db(path)
        repo = SqliteRepository(path)

        repo.init_schema()

        row = repo.list_runs(limit=5)[0]
        assert row["run_id"] == "old1"
        assert row["status"] == "PASS"
        assert row["created_by"] == "DEVELOPER"
        assert row["creation_ts"] == "2026-01-02T03:04:05.000+00:00"
        assert row["case_count"] == 0

    def test_failed_migration_rolls_back(self, tmp_path, monkeypatch):
        path = str(tmp_path / "legacy.db")
        self._legacy_db(path)
        import repository.sqlite_repo as sqlite_module

        def _boom(conn):
            conn.execute("ALTER TABLE eval_execution RENAME TO eval_execution__old")
            raise RuntimeError("midway failure")

        monkeypatch.setattr(sqlite_module, "migrate_legacy_tables", _boom)
        with pytest.raises(RuntimeError):
            SqliteRepository(path).init_schema()

        with closing(sqlite3.connect(path)) as conn:
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert "eval_execution" in tables
        assert "eval_execution__old" not in tables


class TestLegacyBaselineMigration:
    def test_migrates_legacy_baseline_columns(self, tmp_path):
        path = str(tmp_path / "legacy_baseline.db")
        with closing(sqlite3.connect(path)) as conn, conn:
            conn.execute(
                "CREATE TABLE eval_baseline (agent_id TEXT, dataset_version TEXT, metric TEXT, "
                "baseline_value REAL, created_ts TEXT)"
            )
            conn.execute("INSERT INTO eval_baseline VALUES ('a', '1', 'm1', 0.7, '2026-01-01 00:00:00')")
            conn.execute("INSERT INTO eval_baseline VALUES ('a', '1', 'm1', 0.9, '2026-02-01 00:00:00')")

        repo = SqliteRepository(path)
        repo.init_schema()

        # Legacy rows had no dataset_id; the newest value wins the business key.
        assert repo.get_baseline("a", "legacy", "1", "m1") == pytest.approx(0.9)


def test_ping_false_when_database_unreadable(tmp_path, monkeypatch):
    repo = SqliteRepository(str(tmp_path / "x.db"))

    def _broken():
        raise sqlite3.OperationalError("unable to open database file")

    monkeypatch.setattr(repo, "_connect", _broken)
    assert repo.ping() is False


def test_list_runs_includes_error_detail(sqlite_repo, make_run):
    sqlite_repo.save_run(make_run("x", status="ERROR", error_detail="cancelled"))
    sqlite_repo.save_run(make_run("p", status="PASS", creation_ts="2000-01-01T00:00:00+00:00"))

    rows = {r["run_id"]: r for r in sqlite_repo.list_runs()}

    assert rows["x"]["error_detail"] == "cancelled"
    assert rows["p"]["error_detail"] is None


def test_to_utc_iso_handles_naive_and_z():
    assert to_utc_iso("2026-01-01T00:00:00Z") == "2026-01-01T00:00:00.000+00:00"
    assert to_utc_iso("2026-01-01T00:00:00") == "2026-01-01T00:00:00.000+00:00"
