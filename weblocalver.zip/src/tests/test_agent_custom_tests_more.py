"""More per-agent custom scorer and adapter cases (scoping, preliminary research, walkthrough)."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import httpx
import pytest

from core.models import GoldenCase, Observation, ResponseMapping, TargetSpec
from core_helpers import mock_http_fixture  # noqa: F401

_AGENTS = Path(__file__).resolve().parents[1] / "agents"
_TITLES = ("Past Review Analysis", "Policy and Regulatory Analysis", "Broad Scope Direction")


def _load(agent: str):
    path = _AGENTS / agent / "custom_tests.py"
    spec = importlib.util.spec_from_file_location(f"custom_tests_{agent}_more", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def scoping():
    return _load("scoping_summary")


@pytest.fixture(scope="module")
def prelim():
    return _load("preliminary_research_agent")


def _obs(output) -> Observation:
    return Observation(target_id="t", output=output)


def _case(**expected) -> GoldenCase:
    return GoldenCase(id="c", input={}, expected=expected)


def _para(content="Claim text", ids=(1,), rationale="why", start=False, conf=None) -> dict:
    return {"paragraph_id": "p", "content": content, "supporting_chunk_ids": list(ids), "rationale": rationale,
            "metadata": {"is_section_start": start, "section_confidence_score": conf}}


def _bundle(*paras: dict) -> dict:
    return {t: {"report_title": t, "paragraphs": list(paras)} for t in _TITLES}


class TestScopingScorers:
    def test_wrapped_json_string_bundle_is_accepted(self, scoping):
        output = json.dumps({"analysis_report": _bundle(_para())})
        score, rationale, _ = scoping.scoping_reports_present(observation=_obs(output), case=_case())
        assert (score, rationale) == (1.0, "3/3 required reports present")

    @pytest.mark.parametrize("output", ["not json", 42])
    def test_unusable_output_has_no_reports(self, scoping, output):
        assert scoping.scoping_reports_present(observation=_obs(output), case=_case())[0] == 0.0

    def test_titles_from_non_report_values_are_empty(self, scoping):
        bundle = {_TITLES[0]: 7, _TITLES[1]: "no title here", _TITLES[2]: {"report_title": _TITLES[2]}}
        score, _, evidence = scoping.scoping_titles_exact(observation=_obs(bundle), case=_case())
        assert score == pytest.approx(1 / 3)
        assert evidence[0].endswith("-> ''")

    def test_empty_required_lists_pass(self, scoping):
        empty = _case(required_reports=[])
        assert scoping.scoping_reports_present(observation=_obs({}), case=empty)[0] == 1.0
        assert scoping.scoping_titles_exact(observation=_obs({}), case=empty)[0] == 1.0
        assert scoping.scoping_sections_present(observation=_obs({}), case=_case())[1] == "no required_sections configured"

    def test_sections_missing_heading_is_reported(self, scoping):
        case = _case(required_sections={_TITLES[0]: ["Section 1", "Section 9"], _TITLES[1]: []})
        score, _, evidence = scoping.scoping_sections_present(observation=_obs(_bundle(_para("Section 1: x"))), case=case)
        assert score == 0.5
        assert evidence == [f"✗ {_TITLES[0]}: missing 'Section 9'"]
        empty_case = _case(required_sections={_TITLES[0]: []})
        assert scoping.scoping_sections_present(observation=_obs({}), case=empty_case)[0] == 1.0

    def test_grounding_violations(self, scoping):
        paras = [_para(ids=(0, 99)), _para(ids=()), _para(content="", ids=()), _para("Section 2: Scope", ids=())]
        score, _, evidence = scoping.citation_grounding(observation=_obs(_bundle(*paras)), case=_case(max_chunk_id=50))
        assert score == pytest.approx(0.25)
        assert "out-of-range chunk_ids [0, 99] (max 50)" in evidence[0]
        assert evidence[1].endswith("uncited claim: Claim text...")
        assert evidence[2].endswith("uncited claim: (empty)")

    def test_no_paragraphs_scores_zero(self, scoping):
        for fn in (scoping.citation_grounding, scoping.rationale_coverage, scoping.confidence_score_valid):
            assert fn(observation=_obs({}), case=_case())[:2] == (0.0, "no paragraphs found in output")

    def test_confidence_rule(self, scoping):
        paras = [_para(start=True, conf=80), _para(start=True, conf=150), _para(conf=None), _para(conf=5)]
        score, _, evidence = scoping.confidence_score_valid(observation=_obs(_bundle(*paras)), case=_case())
        assert score == 0.5
        assert evidence[0].endswith("missing valid confidence: 150")
        assert evidence[1].endswith("non-section paragraph has confidence 5")

    def test_entities_present(self, scoping):
        observation = _obs(_bundle(_para("Plan 20588 covers R137")))
        assert scoping.scope_entities_present(observation=observation, case=_case())[0] == 1.0
        score, rationale, evidence = scoping.scope_entities_present(
            observation=observation, case=_case(expected_values=["20588", "R999"]))
        assert (score, rationale) == (0.5, "missing: ['R999']")
        assert evidence == ["✓ 20588", "✗ missing R999"]

    def test_repr_paragraph_ids_and_confidence(self, scoping):
        text = ("report_title='Past Review Analysis' paragraphs=[ParagraphCitation(paragraph_id='p1', "
                "content='A claim', supporting_chunk_ids=['3', 4], rationale='r', metadata=Meta("
                "is_section_start=True, section_confidence_score=None))]")
        paragraphs = scoping._paragraphs_of(text)
        assert paragraphs == [{"content": "A claim", "chunk_ids": [3, 4], "rationale": "r",
                               "is_section_start": True, "confidence": None}]
        assert scoping._coerce_ids(["x", True, " 7 "]) == [7]
        assert scoping._coerce_ids("7") == []


class TestPreliminaryResearch:
    def test_no_reports(self, prelim):
        assert prelim.analysis_report_titles_valid(observation=_obs({}), case=_case())[0] == 0.0
        assert prelim.analysis_paragraphs_valid(observation=_obs({}), case=_case())[0] == 0.0

    def test_expected_values_default_and_tuple(self, prelim):
        assert prelim.analysis_expected_values_present(observation=_obs({}), case=_case())[1] == (
            "no expected_values configured")
        assert prelim._as_list(("a", "b")) == ["a", "b"]
        assert prelim._as_list(None) == []


async def _walkthrough_run(mock_http, handler, case_input=None):
    from adapters.http_adapter import get_registered_adapter

    _load("walkthrough_query_agent")
    cls = get_registered_adapter("walkthrough_http")
    target = TargetSpec(adapter="walkthrough_http", endpoint="/qna/chat", response=ResponseMapping(output_path="answer"))
    adapter = cls("http://wt.test", "/qna/chat", target)
    mock_http(handler)
    first = await adapter.run_case(GoldenCase(id="c1", input=case_input or {"question": "q"}))
    second = await adapter.run_case(GoldenCase(id="c2", input={"question": "q2"}))
    return first, second


async def test_walkthrough_upload_happens_once_and_non_dict_reply_uses_default_uri(mock_http):
    uploads: list[int] = []
    chats: list[dict] = []

    def handler(request):
        if request.url.path.endswith("/qna/upload"):
            uploads.append(1)
            return httpx.Response(200, json=["unexpected"])
        chats.append(json.loads(request.content))
        return httpx.Response(200, json={"answer": "a", "source_context": {"from": "agent"}})

    first, _ = await _walkthrough_run(mock_http, handler)
    assert len(uploads) == 1
    assert chats[0]["contextGcsUri"] == "eval/walkthrough_query_agent/source_document.json"
    assert first.source_context == {"from": "agent"}


async def test_walkthrough_upload_failure_is_explained_on_chat_error(mock_http):
    chats: list[dict] = []

    def handler(request):
        if request.url.path.endswith("/qna/upload"):
            raise httpx.ConnectError("refused", request=request)
        chats.append(json.loads(request.content))
        return httpx.Response(500, text="no context")

    first, _ = await _walkthrough_run(mock_http, handler, {"question": "q", "contextGcsUri": "gs://stale"})
    assert "contextGcsUri" not in chats[0]
    assert first.error.startswith("HTTP 500: no context (document upload also failed: Could not connect to the agent.")


def test_prelim_citation_needs_ids_and_citations(prelim):
    assert not prelim._citation_ok({"supporting_chunk_ids": [], "supporting_citations": [{}]})
    assert not prelim._citation_ok({"supporting_chunk_ids": [1], "supporting_citations": [{"chunk_id": 1}]})
