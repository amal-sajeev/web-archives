"""HTTP-level tests through the ASGI app (status codes, validation, routing).

The ``api`` fixture (conftest) overrides the registry/repo/runner dependencies and
never enters the lifespan, so no real agents or databases are touched.
"""

from __future__ import annotations

import io
import json
import zipfile

import httpx
import pytest

import main
from api_routes import build_router
from core.run_manager import run_manager


def _raising(exc):
    async def _handler(agent_id, progress=None):
        raise exc
    return _handler


def test_import_main_has_no_startup_side_effects():
    assert not hasattr(main.app.state, "repo")
    assert not hasattr(main.app.state, "registry")


def test_routes_registered_and_typo_aliases_hidden():
    # Newer FastAPI wraps included routers lazily, so read paths from the router itself.
    paths = {route.path for route in build_router().routes}
    schema_paths = set(main.app.openapi()["paths"])

    assert {"/api/health", "/api/helath", "/livez", "/readyz", "/api/evaluate/start"} <= paths
    assert "/app.js" not in schema_paths
    assert "/api/helath" not in schema_paths
    assert "/helath" not in schema_paths
    assert "/api/health" in schema_paths


async def test_livez_and_readyz(api):
    assert (await api.client.get("/livez")).json() == {"status": "ok"}
    assert (await api.client.get("/readyz")).status_code == 200


async def test_readyz_503_when_repo_down(api, monkeypatch):
    monkeypatch.setattr(api.repo, "ping", lambda: False)
    assert (await api.client.get("/readyz")).status_code == 503


async def test_list_agents(api):
    assert [a["agent_id"] for a in (await api.client.get("/api/agents")).json()["agents"]] == ["agent-1", "agent-2"]


async def test_evaluate_start_202_location_and_events(api):
    response = await api.client.post("/api/evaluate/start", json={"agent_id": "agent-1"})
    stream_id = response.json()["stream_id"]

    assert response.status_code == 202
    assert response.headers["location"] == f"stream/{stream_id}"
    assert (await api.client.get(f"/api/evaluate/stream/{stream_id}/events")).status_code == 200


async def test_evaluate_start_unknown_agent_404(api):
    assert (await api.client.post("/api/evaluate/start", json={"agent_id": "zzz"})).status_code == 404


async def test_evaluate_body_validation_422(api):
    assert (await api.client.post("/api/evaluate", json={"agent_id": "agent-1", "judge_repetitions": 9})).status_code == 422


async def test_evaluate_async_202(api):
    assert (await api.client.post("/api/evaluate/async", json={"agent_id": "agent-1"})).status_code == 202


async def test_stream_events_rejects_negative_after(api):
    live = run_manager.create("agent-1")
    assert (await api.client.get(f"/api/evaluate/stream/{live.stream_id}/events?after=-1")).status_code == 422


async def test_cancel_202_then_409(api):
    live = run_manager.create("agent-1")

    first = await api.client.post(f"/api/evaluate/cancel/{live.stream_id}")
    live.finish()
    second = await api.client.post(f"/api/evaluate/cancel/{live.stream_id}")

    assert first.status_code == 202
    assert first.json()["status"] == "cancel_requested"
    assert second.status_code == 409
    assert (await api.client.post("/api/evaluate/cancel/missing")).status_code == 404


@pytest.mark.parametrize(("exc", "status"), [
    (KeyError("k"), 404), (ValueError("v"), 400), (httpx.ConnectError("c"), 502), (RuntimeError("r"), 500),
])
async def test_evaluate_ab_error_mapping(api, exc, status):
    api.runner.handler = _raising(exc)
    response = await api.client.post("/api/evaluate/ab", json={"agent_a": "agent-1", "agent_b": "agent-2"})
    assert response.status_code == status


async def test_evaluate_ab_success_shape(api):
    body = (await api.client.post("/api/evaluate/ab", json={"agent_a": "agent-1", "agent_b": "agent-2"})).json()
    assert {"a", "b", "score_diff", "winner", "cases"} <= set(body)


async def test_runs_pagination_cursor_and_counts(api, make_run):
    for i in range(3):
        api.repo.save_run(make_run(f"r{i}", creation_ts=f"2026-01-0{i + 1}T00:00:00+00:00",
                                   cases=[("c1", True, 0.9), ("c2", False, 0.1)]))

    page1 = (await api.client.get("/api/runs", params={"limit": 2})).json()
    page2 = (await api.client.get("/api/runs", params={"limit": 2, "before": page1["next_cursor"]})).json()

    assert [r["run_id"] for r in page1["runs"]] == ["r2", "r1"]
    assert page1["runs"][0]["case_count"] == 2
    assert page1["runs"][0]["passed_case_count"] == 1
    assert [r["run_id"] for r in page2["runs"]] == ["r0"]
    assert page2["next_cursor"] is None


@pytest.mark.parametrize("query", ["status=BOGUS", "limit=0", "limit=500"])
async def test_runs_query_validation_422(api, query):
    assert (await api.client.get(f"/api/runs?{query}")).status_code == 422


async def test_runs_status_filter(api, make_run):
    api.repo.save_run(make_run("p", status="PASS"))
    api.repo.save_run(make_run("e", status="ERROR"))
    assert [r["run_id"] for r in (await api.client.get("/api/runs?status=ERROR")).json()["runs"]] == ["e"]


async def test_export_format_validation(api, make_run):
    api.repo.save_run(make_run("r1", cases=[("c1", True, 0.9)]))

    assert (await api.client.get("/api/runs/r1/export?format=xml")).status_code == 422
    assert (await api.client.get("/api/runs/r1/export?format=csv")).headers["content-type"].startswith("text/csv")
    assert (await api.client.get("/api/runs/r1/export?format=pdf")).content.startswith(b"%PDF")
    assert (await api.client.get("/api/runs/missing/export")).status_code == 404


async def test_compare_same_run_400(api):
    assert (await api.client.get("/api/runs/compare?a=x&b=x")).status_code == 400


async def test_add_label_201(api):
    response = await api.client.post("/api/labels", json={"case_id": "c1", "verdict": "pass"})
    assert response.status_code == 201
    assert (await api.client.get("/api/labels/c1")).json()["verdict"] == "pass"


async def test_tls_policy_endpoint(api):
    assert (await api.client.post("/api/settings/tls", json={"enabled": False})).json()["exclude_tls"] is True
    assert (await api.client.post("/api/settings/tls", json={})).status_code == 400
    assert (await api.client.post("/api/settings/tls", json={"enabled": "maybe"})).status_code == 422


async def test_playground_http_missing_url_422(api):
    assert (await api.client.post("/api/playground/http", json={"method": "GET"})).status_code == 422


async def test_playground_export_by_stream_id(api, make_run):
    live = run_manager.create("playground")
    live.finished_run = make_run("pg-run")
    live.finish()

    response = await api.client.post(f"/api/playground/export?stream_id={live.stream_id}")

    assert response.status_code == 200
    assert json.loads(response.content)["run_id"] == "pg-run"


async def test_playground_export_incomplete_run_404(api):
    live = run_manager.create("playground")
    assert (await api.client.post(f"/api/playground/export?stream_id={live.stream_id}")).status_code == 404


async def test_playground_export_bundle(api):
    body = {"root": "demo", "files": [{"path": "agent.yaml", "content": "agent_id: demo\n"}]}
    response = await api.client.post("/api/playground/export", json=body)

    assert response.status_code == 200
    assert zipfile.ZipFile(io.BytesIO(response.content)).namelist()


async def test_unhandled_exception_returns_json_error(api, monkeypatch):
    def _boom(**_kwargs):
        raise RuntimeError("hidden detail")

    monkeypatch.setattr(api.registry, "list_agents", _boom)
    response = await api.client.get("/api/agents")

    assert response.status_code == 500
    assert response.json()["error_type"] == "RuntimeError"
    assert "hidden detail" not in response.json()["detail"]


async def test_ui_pages_served(api):
    response = await api.client.get("/")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/html")


async def test_lifespan_builds_and_closes_services(monkeypatch, tmp_path):
    from conftest import FakeRegistry
    from core.config import Config

    class _LoadedRegistry(FakeRegistry):
        def load(self):
            return self

    closed = []
    monkeypatch.setattr(main, "Registry", _LoadedRegistry)
    monkeypatch.setattr(Config, "DB_URL", f"sqlite:///{(tmp_path / 'life.db').as_posix()}")
    monkeypatch.setattr(Config, "RUN_RETENTION_DAYS", 1)
    app = main.create_app()

    async with main.lifespan(app):
        repo = app.state.repo
        monkeypatch.setattr(repo, "close", lambda: closed.append(True))
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            assert (await client.get("/readyz")).status_code == 200
            assert (await client.get("/api/agents")).json()["agents"][0]["agent_id"] == "agent-1"

    assert type(repo).__name__ == "SqliteRepository"
    assert closed == [True]


async def test_playground_validate_accepts_upload(api):
    files = {"file": ("bad.zip", b"not a zip", "application/zip")}
    response = await api.client.post("/api/playground/validate", files=files)

    assert response.status_code == 200
    assert response.json()["valid"] is False


async def test_playground_start_rejects_bad_repetitions(api):
    files = {"file": ("bad.zip", b"not a zip", "application/zip")}
    response = await api.client.post("/api/playground/start?judge_repetitions=9", files=files)
    assert response.status_code == 422
