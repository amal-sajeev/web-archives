"""Remaining handler paths: SSE streaming, UI pages, the HTTP probe, webhooks,
retention, dependency providers and the shared error helpers."""

from __future__ import annotations

import asyncio
import json
import logging
from types import SimpleNamespace

import httpx
import pytest
from fastapi import HTTPException

import dependencies
import main
from core.config import Config
from core.run_manager import run_manager
from core_helpers import mock_http_fixture  # noqa: F401
from handlers import _common, streams, ui
from handlers.comparison import winner
from handlers.evaluate import _deliver_webhook
from handlers.playground_http import _body_from_raw, playground_http


def _sse_payloads(text: str) -> list[dict]:
    return [json.loads(line[len("data: "):]) for line in text.splitlines() if line.startswith("data: ")]


async def test_sse_replays_history_then_closes(api):
    live = run_manager.create("agent-1")
    live.publish({"type": "case_done", "case_id": "c1"})
    live.publish({"type": "run_done", "run_id": "r1"})
    live.finish()

    response = await api.client.get(f"/api/evaluate/stream/{live.stream_id}")

    assert response.headers["content-type"].startswith("text/event-stream")
    assert response.text.startswith("retry: 1000")
    assert [e["type"] for e in _sse_payloads(response.text)] == ["case_done", "run_done"]
    assert [e["seq"] for e in _sse_payloads(response.text)] == [1, 2]


async def test_sse_sends_keepalive_while_waiting(monkeypatch):
    monkeypatch.setattr(streams, "_KEEPALIVE_SECONDS", 0.01)
    live = run_manager.create("agent-1")
    request = SimpleNamespace(is_disconnected=_never_disconnected)

    async def _finish_later():
        await asyncio.sleep(0.05)
        live.publish({"type": "run_done"})
        live.finish()

    finisher = asyncio.create_task(_finish_later())
    chunks = [chunk async for chunk in streams._sse_events(live, request)]
    await finisher

    assert ": keep-alive\n\n" in chunks
    assert chunks[-1].startswith("data: ")
    assert live._subscribers == set()  # unsubscribed on exit


async def _never_disconnected() -> bool:
    return False


async def test_sse_stops_when_client_disconnects():
    live = run_manager.create("agent-1")

    async def _gone() -> bool:
        return True

    chunks = [chunk async for chunk in streams._sse_events(live, SimpleNamespace(is_disconnected=_gone))]
    assert chunks == ["retry: 1000\n\n"]
    assert live._subscribers == set()


@pytest.mark.parametrize("path", ["/run.html", "/run_detail.html", "/playground.html", "/apitester.html"])
async def test_ui_pages(api, path):
    response = await api.client.get(path)
    assert response.status_code == 200
    assert b"__ASSET_VERSION__" not in response.content


def test_missing_ui_page_is_404(monkeypatch, tmp_path):
    ui._page.cache_clear()
    monkeypatch.setattr(Config, "STATIC_DIR", tmp_path)
    try:
        with pytest.raises(HTTPException) as exc_info:
            ui.index()
    finally:
        ui._page.cache_clear()
    assert exc_info.value.status_code == 404


async def test_playground_http_validation_and_errors(mock_http):
    with pytest.raises(HTTPException) as invalid:
        await playground_http({"url": ""})
    assert invalid.value.status_code == 422

    def _timeout(request):
        raise httpx.ReadTimeout("slow", request=request)

    mock_http(_timeout)
    with pytest.raises(HTTPException) as timed_out:
        await playground_http({"url": "https://slow.test"})
    assert timed_out.value.status_code == 504


async def test_playground_http_connect_error_502(mock_http):
    def _refused(request):
        raise httpx.ConnectError("refused", request=request)

    mock_http(_refused)
    with pytest.raises(HTTPException) as exc_info:
        await playground_http({"url": "https://down.test"})
    assert exc_info.value.status_code == 502


async def test_playground_http_form_and_text_bodies(mock_http):
    seen = mock_http(lambda request: httpx.Response(200, content=b"\x00binary"))

    await playground_http({"method": "post", "url": "https://x.test", "data": {"a": "1"}})
    await playground_http({"method": "POST", "url": "https://x.test", "body": "plain text"})
    response = await playground_http({
        "method": "POST", "url": "https://x.test", "headers": {"content-type": "application/json"}, "body": "{bad",
    })

    assert seen[0].content == b"a=1"
    assert seen[1].content == b"plain text"
    assert seen[2].content == b"{bad"
    assert response["json"] is None


async def test_playground_http_accepts_model_instance(mock_http):
    from handlers.playground_http import PlaygroundHttpRequest

    mock_http(lambda request: httpx.Response(200, json={"ok": True}))
    response = await playground_http(PlaygroundHttpRequest(url="https://x.test"))
    assert response["json"] == {"ok": True}


def test_body_from_raw_variants():
    assert _body_from_raw([1, 2], "") == ([1, 2], None)
    assert _body_from_raw(b"raw", "") == (None, "b'raw'")
    assert _body_from_raw('{"a": 1}', "application/json") == ({"a": 1}, None)


async def test_webhook_delivery_posts_payload(mock_http):
    seen = mock_http(lambda request: httpx.Response(204))
    await _deliver_webhook("https://hook.test/ok", {"run_id": "r1"})
    assert json.loads(seen[0].content) == {"run_id": "r1"}


async def test_webhook_failure_is_logged_not_raised(mock_http):
    def _refused(request):
        raise httpx.ConnectError("refused", request=request)

    seen = mock_http(_refused)
    assert await _deliver_webhook("https://hook.test/down", {"run_id": "r2"}) is None
    assert len(seen) == 1


def test_retention_deletes_and_survives_errors(sqlite_repo, make_run, monkeypatch):
    sqlite_repo.save_run(make_run("old", creation_ts="2000-01-01T00:00:00+00:00"))
    monkeypatch.setattr(Config, "RUN_RETENTION_DAYS", 30)

    main._apply_retention(sqlite_repo)
    assert sqlite_repo.get_run("old") is None

    def _boom(_days):
        raise RuntimeError("disk full")

    monkeypatch.setattr(sqlite_repo, "delete_old_runs", _boom)
    main._apply_retention(sqlite_repo)  # logged, not raised

    monkeypatch.setattr(Config, "RUN_RETENTION_DAYS", 0)
    main._apply_retention(sqlite_repo)


async def test_lifespan_shutdown_cancels_live_runs(monkeypatch, tmp_path):
    from conftest import FakeRegistry

    class _LoadedRegistry(FakeRegistry):
        def load(self):
            return self

    monkeypatch.setattr(main, "Registry", _LoadedRegistry)
    monkeypatch.setattr(Config, "DB_URL", f"sqlite:///{(tmp_path / 'life.db').as_posix()}")
    app = main.create_app()
    async with main.lifespan(app):
        live = run_manager.create("agent-1")
        _common.spawn_run(live, asyncio.sleep(3600))
        await asyncio.sleep(0)

    assert live.task.cancelled()
    assert live.cancel_requested is True


def test_dependency_providers_read_app_state():
    state = SimpleNamespace(registry="reg", repo="repo", runner="runner")
    request = SimpleNamespace(app=SimpleNamespace(state=state))

    assert dependencies.get_registry(request) == "reg"
    assert dependencies.get_repo(request) == "repo"
    assert dependencies.get_runner(request) == "runner"
    assert isinstance(dependencies.get_logger(), logging.Logger)


def test_http_error_passthrough_and_503_retry_after():
    import sqlite3

    original = HTTPException(status_code=418, detail="teapot")
    unavailable = _common.http_error(sqlite3.OperationalError("locked"))

    assert _common.http_error(original) is original
    assert unavailable.status_code == 503
    assert unavailable.headers == {"Retry-After": "5"}


def test_agent_name_edge_cases():
    class _Racy:
        def has(self, _agent_id):
            return True

        def get(self, agent_id):
            raise KeyError(agent_id)  # removed between has() and get()

    assert _common.agent_name(None, "a") is None
    assert _common.agent_name(_Racy(), "a") is None
    assert _common.agent_name(_Racy(), "") is None


def test_winner():
    assert (winner(0.1, 0.2), winner(0.2, 0.1), winner(0.5, 0.5)) == ("b", "a", "tie")


async def test_no_body_statuses_skip_the_json_envelope():
    from starlette.exceptions import HTTPException as StarletteHTTPException

    from error_handlers import http_exception_handler

    request = SimpleNamespace(state=SimpleNamespace())
    response = await http_exception_handler(request, StarletteHTTPException(status_code=304))
    assert response.status_code == 304
    assert response.body == b""


def test_cursor_without_separator_is_treated_as_legacy_timestamp():
    import base64

    from handlers.runs import decode_cursor

    cursor = base64.urlsafe_b64encode(b"no-separator-here").decode().rstrip("=")
    assert decode_cursor(cursor) == (cursor, None)


def test_csv_export_row_for_case_without_scores():
    from handlers.runs import _csv_text

    run = SimpleNamespace(case_results=[SimpleNamespace(
        case_id="c1", passed=False, weighted_score=0.0, weighted_delta=0.0, scores=[])])
    lines = _csv_text(run).splitlines()
    # Old ten columns first (all blank past the case fields), then the four baseline/change columns.
    assert lines[1] == "c1,False,0.0,0.0,,,,,," + ",,,,"


def test_main_entrypoint_runs_uvicorn_with_root_path(monkeypatch):
    import runpy

    import uvicorn

    calls = []
    monkeypatch.setattr(uvicorn, "run", lambda app, **kw: calls.append((app, kw)))
    monkeypatch.setenv("ROOT_PATH", "/eval")

    runpy.run_path(main.__file__, run_name="__main__")

    assert calls[0][1] == {"host": "0.0.0.0", "port": Config.PORT, "root_path": "/eval"}
