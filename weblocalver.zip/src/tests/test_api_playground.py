"""Playground handlers: inspect, environment, start/drive, validate and export."""

from __future__ import annotations

import asyncio
import importlib
import io
import json
import zipfile

import pytest
from fastapi import HTTPException

from core.config import Config
from core.run_manager import run_manager
from handlers import playground as pg

# ``handlers`` re-exports a function named ``playground_validate``; load the module itself.
pv = importlib.import_module("handlers.playground_validate")

_AGENT_YAML = "agent_id: demo\nname: Demo\ndataset_file: dataset.json\nmetrics_stub_file: metrics_stub.json\n"
_DATASET = {
    "dataset_id": "demo-data", "version": "1", "target": {"adapter": "http", "endpoint": "/eval"},
    "metrics": [{"name": "inv", "type": "deterministic", "scorer": "invoice_total"}],
    "cases": [{"id": "case-1", "input": {}, "baseline_metrics": {}}],
}
_CUSTOM = (
    "from scorers import scorer\n"
    "@scorer('invoice_total')\n"
    "def invoice_total(observation, case, metrics, **_):\n"
    "    return (1.0, 'ok', [])\n"
)


def bundle(*, agent=_AGENT_YAML, dataset=None, custom=_CUSTOM, extra=None) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("demo/agent.yaml", agent)
        z.writestr("demo/dataset.json", json.dumps(dataset or _DATASET))
        z.writestr("demo/metrics_stub.json", "{}")
        if custom is not None:
            z.writestr("demo/custom_tests.py", custom)
        for name, content in (extra or {}).items():
            z.writestr(f"demo/{name}", content)
    return buf.getvalue()


def _upload(blob: bytes, name: str = "demo.zip") -> dict:
    return {"file": (name, blob, "application/zip")}


class _FakeRunner:
    """Replaces ``handlers.playground.Runner``; records what the preview asked for."""

    seen: dict = {}
    gate: asyncio.Event | None = None

    def __init__(self, registry, repo):
        _FakeRunner.seen = {"registry": registry, "repo": type(repo).__name__}

    async def evaluate(self, agent_id, **kwargs):
        _FakeRunner.seen.update(agent_id=agent_id, **kwargs)
        _FakeRunner.seen["base_url"] = _FakeRunner.seen["registry"].get(agent_id).config.base_url
        if _FakeRunner.gate is not None:
            await _FakeRunner.gate.wait()
        await kwargs["progress"]({"type": "case_done", "case_id": "case-1"})
        return self._make_run(agent_id)

    @staticmethod
    def _make_run(agent_id):
        from core.models import RunRecord

        return RunRecord(run_id="pg-1", agent_id=agent_id, dataset_id="demo-data", dataset_version="1",
                         weighted_score=1.0, weighted_delta=0.0, status="PASS", creation_ts="2026-01-01T00:00:00Z")


@pytest.fixture
def fake_runner(monkeypatch):
    _FakeRunner.seen = {}
    _FakeRunner.gate = None
    monkeypatch.setattr(pg, "Runner", _FakeRunner)
    return _FakeRunner


async def _wait_done(stream_id: str) -> list[dict]:
    live = run_manager.get(stream_id)
    await asyncio.wait_for(live.task, timeout=5)
    return live.events


async def test_inspect_ok_and_bad_archive(api):
    ok = await api.client.post("/api/playground/inspect", files=_upload(bundle()))
    bad = await api.client.post("/api/playground/inspect", files=_upload(b"not a zip"))

    assert ok.status_code == 200
    assert ok.json()["agent"]["agent_id"] == "demo"
    assert ok.json()["custom_tests"]["declared_scorers"] == ["invoice_total"]
    assert bad.status_code == 400
    assert bad.json()["error_type"] == "bad_request"


@pytest.mark.parametrize(("project", "mode"), [("proj", "vertex"), ("", "developer-api")])
async def test_environment_reports_auth_mode(api, monkeypatch, project, mode):
    monkeypatch.setattr(Config, "PROJECT_NAME", project)
    body = (await api.client.get("/api/playground/environment")).json()
    assert body["auth_mode"] == mode
    assert body["case_concurrency"] == Config.CASE_CONCURRENCY


async def test_start_runs_preview_with_override_and_case_ids(api, fake_runner):
    response = await api.client.post(
        "/api/playground/start?base_url=%20http://agent.test%20&judge_repetitions=2&case_ids_json=%5B%22case-1%22%5D",
        files=_upload(bundle()),
    )
    stream_id = response.json()["stream_id"]
    events = await _wait_done(stream_id)

    assert response.status_code == 202
    assert response.headers["location"] == f"../evaluate/stream/{stream_id}"
    assert [e["type"] for e in events] == ["case_done", "playground_done"]
    assert run_manager.get(stream_id).finished_run.run_id == "pg-1"
    assert fake_runner.seen["base_url"] == "http://agent.test"
    assert (fake_runner.seen["case_ids"], fake_runner.seen["judge_repetitions"]) == (["case-1"], 2)
    assert fake_runner.seen["repo"] == "PreviewRepository"


async def test_start_with_bad_bundle_publishes_one_error(api, fake_runner):
    response = await api.client.post("/api/playground/start", files=_upload(b"not a zip"))
    events = await _wait_done(response.json()["stream_id"])

    assert [e["type"] for e in events] == ["error"]
    assert events[0]["status"] == 400


async def test_cancelled_preview_publishes_run_cancelled(api, fake_runner):
    fake_runner.gate = asyncio.Event()
    response = await api.client.post("/api/playground/start", files=_upload(bundle()))
    stream_id = response.json()["stream_id"]
    live = run_manager.get(stream_id)
    while "agent_id" not in fake_runner.seen:
        await asyncio.sleep(0.01)

    await api.client.post(f"/api/evaluate/cancel/{stream_id}")
    with pytest.raises(asyncio.CancelledError):
        await live.task

    assert live.done is True
    assert live.events[-1]["type"] == "run_cancelled"
    assert live.events[-1]["detail"] == "Preview run cancelled"


@pytest.mark.parametrize(("raw", "message"), [
    ("{not json", "Invalid case_ids_json"),
    ('{"a": 1}', "JSON array of strings"),
    ("[1, 2]", "JSON array of strings"),
])
async def test_start_rejects_bad_case_ids(api, raw, message):
    response = await api.client.post("/api/playground/start", params={"case_ids_json": raw}, files=_upload(bundle()))
    assert response.status_code == 400
    assert message in response.json()["detail"]


async def test_validate_valid_bundle(api):
    body = (await api.client.post("/api/playground/validate", files=_upload(bundle()))).json()

    assert body["valid"] is True
    assert (body["agent"], body["dataset"]) == ("demo", "demo-data")
    assert body["custom_tests"] == {
        "present": True, "declared_scorers": ["invoice_total"], "loaded_scorers": ["invoice_total"], "collisions": [],
    }


async def test_validate_reports_structure_sensitive_files_and_scorer_problems(api):
    custom = _CUSTOM + (
        "@scorer('tool_selection')\ndef clash(observation, case, metrics, **_):\n    return (1.0, '', [])\n"
        "if False:\n    @scorer('never_registered')\n    def ghost(observation, case, metrics, **_):\n        pass\n"
    )
    dataset = {**_DATASET, "metrics": [], "cases": []}
    blob = bundle(dataset=dataset, custom=custom, extra={".env": "SECRET=1"})

    errors = (await api.client.post("/api/playground/validate", files=_upload(blob))).json()["errors"]

    assert "Dataset contains no cases." in errors
    assert "Dataset contains no metrics." in errors
    assert any(".env" in e for e in errors)
    assert "custom_tests.py overrides an existing scorer: tool_selection" in errors
    # A colliding scorer did register (it replaced the built-in), so it is not also "missing".
    assert "custom_tests.py did not register declared scorer(s): never_registered" in errors


async def test_validate_reports_custom_tests_load_failure(api, monkeypatch):
    def _explode(_temp_dir):
        raise ImportError("broken import")

    monkeypatch.setattr(pv, "_load_scoped_registry", _explode)
    body = (await api.client.post("/api/playground/validate", files=_upload(bundle()))).json()

    assert body["valid"] is False
    assert body["errors"] == ["custom_tests.py could not be loaded: ImportError: broken import"]


def test_export_bundle_validation_and_safe_filename():
    with pytest.raises(HTTPException, match="JSON object"):
        pg._export_bundle(["not", "a", "dict"])
    with pytest.raises(HTTPException, match="files must be an array"):
        pg._export_bundle({"files": "x"})
    with pytest.raises(HTTPException) as bad_file:
        pg._export_bundle({"files": [{"path": "../escape", "content": "x"}]})
    assert bad_file.value.status_code == 400

    response = pg._export_bundle({"root": 'we"ird\r\nname', "files": [{"path": "a.txt", "content": "x"}]})
    assert response.headers["content-disposition"] == 'attachment; filename="we_ird_name-config-playground.zip"'


async def test_export_requires_payload_or_stream(api):
    response = await api.client.post("/api/playground/export")
    assert response.status_code == 400
