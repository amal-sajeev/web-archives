"""Runnable sample LangChain agent - an invoice parser that returns structured JSON.

Hostable standalone on :4012. Demonstrates the config-driven ``http`` adapter
with ``content_type: json`` and config-driven JSON scorers
(``json_path``, ``field_match``, ``json_schema_valid``, ``rubric``).

    POST /api/eval/invoice-parser  { "invoice_text": "..." }
    -> { "invoice": { "vendor": ..., "total": ..., "items": [...] }, ... }

Run:  python src/sample_agents/invoice_parser_agent.py
"""

from __future__ import annotations

import re
import time

from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from pydantic import BaseModel, Field

try:
    from sample_agents._common import build_envelope, create_app, estimate_usage, serve
except ModuleNotFoundError:  # run as a plain script without PYTHONPATH=src
    from _common import build_envelope, create_app, estimate_usage, serve

DEFAULT_INVOICE = "acme_q1"
PORT = 4012


@tool
def extract_vendor(text: str) -> str:
    """Extract the vendor name from invoice text."""
    m = re.search(r"(?:From|Vendor|Supplier):\s*(.+)", text, re.I)
    return m.group(1).strip() if m else "Unknown Vendor"


@tool
def extract_total(text: str) -> float:
    """Extract the total amount from invoice text."""
    m = re.search(r"(?:Total|Amount Due|Balance Due):\s*\$?([\d,]+\.?\d*)", text, re.I)
    if m:
        return float(m.group(1).replace(",", ""))
    return 0.0


@tool
def extract_line_items(text: str) -> list[dict]:
    """Extract line items from invoice text."""
    return [
        {"description": m.group(1).strip(), "amount": float(m.group(2).replace(",", ""))}
        for m in re.finditer(r"-\s+(.+?)\s+:\s+\$?([\d,]+\.?\d*)", text)
    ]


@tool
def extract_invoice_number(text: str) -> str:
    """Extract the invoice number."""
    m = re.search(r"(?:Invoice|Inv)\s*(?:#|No\.?|Number)[:\s]*([A-Z0-9-]+)", text, re.I)
    return m.group(1) if m else "UNKNOWN"


TOOLS = {t.name: t for t in (extract_vendor, extract_total, extract_line_items, extract_invoice_number)}


_INVOICES = {
    DEFAULT_INVOICE: """Invoice #INV-2025-001
From: Acme Corp
Date: 2025-01-15

Line Items:
- Cloud Services : $5,000
- Support Package : $2,000
- Training : $1,000

Total: $8,000
""",
    "globex_annual": """Invoice #INV-2025-042
Vendor: Globex Industries
Date: 2025-03-20

Line Items:
- Annual License : $12,000
- Premium Support : $3,500
- Implementation : $4,500

Total: $20,000
""",
    "initech_quarterly": """Invoice No. INV-Q3-009
From: Initech Consulting
Date: 2025-07-01

Line Items:
- Audit Services : $7,500
- Risk Assessment : $3,000
- Remediation : $2,500

Amount Due: $13,000
""",
}


def _agent_fn(payload: dict) -> dict:
    invoice_key = payload.get("invoice_text") or payload.get("invoice_id") or DEFAULT_INVOICE
    # A known invoice id selects a canned invoice; anything else is parsed as raw text.
    text = _INVOICES.get(invoice_key, invoice_key)
    args = {"text": text}

    items = extract_line_items.invoke(args)
    invoice = {
        "vendor": extract_vendor.invoke(args),
        "invoice_number": extract_invoice_number.invoke(args),
        "total": extract_total.invoke(args),
        "currency": "USD",
        "line_items": items,
        "item_count": len(items),
    }
    latencies = {"extract_vendor": 3, "extract_total": 2, "extract_line_items": 5, "extract_invoice_number": 2}
    tool_calls = [{"name": name, "args": args, "latency_ms": ms} for name, ms in latencies.items()]
    return {"invoice": invoice, "tool_calls": tool_calls, "usage": estimate_usage(text, str(invoice))}


agent_runnable = RunnableLambda(_agent_fn)

app = create_app("Sample Invoice Parser Agent", TOOLS)


class InvoiceRequest(BaseModel):
    invoice_text: str = Field(default=DEFAULT_INVOICE, min_length=1)


@app.post("/api/eval/invoice-parser")
def evaluate_invoice(request: InvoiceRequest):
    started = time.perf_counter()
    result = agent_runnable.invoke({"invoice_text": request.invoice_text})
    return build_envelope(
        target_id="invoice_parser",
        output=result["invoice"],
        result=result,
        source_context={"invoice_text": request.invoice_text},
        started=started,
        model="invoice-parser-langchain-v1",
        metadata={"ai_confidence": 0.93},
    )


if __name__ == "__main__":
    serve(app, PORT)
