"""Shared helpers for the runnable sample agents.

Every sample agent returns the same Observation envelope and exposes the same
``/api/health`` route; those pieces live here so the four agents only carry
their own tools and routing logic.
"""

from __future__ import annotations

import time
from collections.abc import Iterable
from typing import Any

import uvicorn
from fastapi import FastAPI

# Rough "characters per token" ratio used for the deterministic usage estimate.
_CHARS_PER_TOKEN = 4
_BIND_ALL_INTERFACES = "0.0.0.0"  # sample agents are local demo servers


def estimate_usage(prompt: str, output: str) -> dict[str, int]:
    """Cheap deterministic token estimate so the capture service has usage data."""
    in_tok = max(1, len(prompt) // _CHARS_PER_TOKEN)
    out_tok = max(1, len(output) // _CHARS_PER_TOKEN)
    return {"input_tokens": in_tok, "output_tokens": out_tok, "total_tokens": in_tok + out_tok}


def build_envelope(
    *,
    target_id: str,
    output: Any,
    result: dict[str, Any],
    source_context: dict[str, Any],
    started: float,
    model: str,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    """Build the standard eval-hook Observation envelope.

    ``result`` must carry ``tool_calls`` and ``usage``; ``started`` is the
    ``time.perf_counter()`` value taken when the request arrived.
    """
    return {
        "target_id": target_id,
        "output": output,
        "tool_calls": result["tool_calls"],
        "stage_trace": [],
        "source_context": source_context,
        "latency_ms": int((time.perf_counter() - started) * 1000),
        "usage": result["usage"],
        "model": model,
        "metadata": metadata,
        "error": None,
    }


def create_app(title: str, tool_names: Iterable[str]) -> FastAPI:
    """Create the FastAPI app with the shared ``/api/health`` route."""
    app = FastAPI(title=title, version="0.1.0")
    names = sorted(tool_names)

    @app.get("/api/health")
    def health() -> dict[str, Any]:
        return {"status": "ok", "tools": names}

    return app


def serve(app: FastAPI, port: int) -> None:
    """Run the sample agent with uvicorn on ``port``."""
    uvicorn.run(app, host=_BIND_ALL_INTERFACES, port=port)
