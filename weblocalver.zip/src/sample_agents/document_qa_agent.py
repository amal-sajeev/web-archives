"""Runnable sample LangChain agent - a document QA agent that returns DOCX and PDF.

Hostable standalone on :4013. Demonstrates the config-driven ``http`` adapter
with ``content_type: docx`` / ``pdf`` and document-structure scorers
(``section_present``, ``docx_table_has``, ``rubric``).

    POST /api/eval/document-qa  { "document_type": "docx"|"pdf", "topic": "..." }
    -> { "document": "<base64-encoded-bytes>", "answer": "...", ... }

The DOCX is generated with python-docx (paragraphs + a table). The PDF is
generated with a minimal stdlib-only PDF writer (no extra dependency).

Run:  python src/sample_agents/document_qa_agent.py
"""

from __future__ import annotations

import base64
import io
import time
from typing import Literal

from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from pydantic import BaseModel, Field

try:
    from sample_agents._common import build_envelope, create_app, estimate_usage, serve
except ModuleNotFoundError:  # run as a plain script without PYTHONPATH=src
    from _common import build_envelope, create_app, estimate_usage, serve

DEFAULT_TOPIC = "Risk Assessment"
PORT = 4013
PDF_ENCODING = "latin-1"
DocumentType = Literal["docx", "pdf"]

# PDF page geometry (US Letter, points).
_PAGE_WIDTH = 612
_PAGE_HEIGHT = 792
_TOP_Y = 750
_LEFT_X = 72
_BOTTOM_MARGIN = 72
_LINE_HEIGHT = 18
_FONT_SIZE = 12
_LINES_PER_PAGE = (_TOP_Y - _BOTTOM_MARGIN) // _LINE_HEIGHT

_TABLE_ROWS = [
    ("Revenue", "$10M", "Above target"),
    ("Expenses", "$4M", "Below budget"),
    ("Net Income", "$6M", "On track"),
]


@tool
def generate_docx(topic: str) -> str:
    """Generate a DOCX report with headings, paragraphs, and a summary table."""
    import docx  # lazy import; python-docx is only needed for DOCX output

    doc = docx.Document()
    doc.add_heading(f"{topic} Report", level=0)
    sections = [
        ("Executive Summary", [f"This document presents the {topic} findings and recommendations."]),
        ("Key Findings", ["The analysis identified three primary areas of concern."]),
        ("Detailed Analysis", [
            "Finding 1: Revenue exceeded expectations by 12%.",
            "Finding 2: Operating costs were 8% below budget.",
            "Finding 3: Customer satisfaction improved by 15 points.",
        ]),
        ("Recommendations", [
            "1. Increase investment in high-performing segments.",
            "2. Review cost allocation across business units.",
        ]),
    ]
    for heading, paragraphs in sections:
        doc.add_heading(heading, level=1)
        for text in paragraphs:
            doc.add_paragraph(text)

    doc.add_heading("Summary Table", level=1)
    table = doc.add_table(rows=len(_TABLE_ROWS) + 1, cols=3)
    table.style = "Table Grid"
    for row, values in zip(table.rows, [("Metric", "Value", "Status"), *_TABLE_ROWS], strict=True):
        for cell, value in zip(row.cells, values, strict=True):
            cell.text = value

    buf = io.BytesIO()
    doc.save(buf)
    return base64.b64encode(buf.getvalue()).decode("ascii")


@tool
def generate_pdf(topic: str) -> str:
    """Generate a minimal PDF report (stdlib-only, no extra dependency)."""
    text_lines = [
        f"{topic} Report",
        "",
        "Executive Summary",
        f"This document presents the {topic} findings.",
        "",
        "Key Findings",
        "Revenue exceeded expectations by 12%.",
        "Operating costs were 8% below budget.",
        "Customer satisfaction improved by 15 points.",
        "",
        "Recommendations",
        "Increase investment in high-performing segments.",
        "Review cost allocation across business units.",
    ]
    return base64.b64encode(build_pdf(text_lines)).decode("ascii")


def _escape_pdf_text(line: str) -> str:
    """Escape a line for a PDF literal string (backslash first, then parens)."""
    return line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _page_content(lines: list[str]) -> bytes:
    parts = ["BT", f"/F1 {_FONT_SIZE} Tf", f"{_LEFT_X} {_TOP_Y} Td"]
    for i, line in enumerate(lines):
        if i > 0:
            parts.append(f"0 -{_LINE_HEIGHT} Td")
        parts.append(f"({_escape_pdf_text(line)}) Tj")
    parts.append("ET")
    return "\n".join(parts).encode(PDF_ENCODING, errors="replace")


def _paginate(text_lines: list[str]) -> list[list[str]]:
    pages = [text_lines[i:i + _LINES_PER_PAGE] for i in range(0, len(text_lines), _LINES_PER_PAGE)]
    return pages or [[]]


def build_pdf(text_lines: list[str]) -> bytes:
    """Build a minimal valid multi-page PDF with text (stdlib only).

    Object layout: 1 catalog, 2 pages, 3 font, then a (page, content) pair per page.
    Characters outside latin-1 are replaced with ``?``.
    """
    pages = _paginate(text_lines)
    page_ids = [4 + 2 * i for i in range(len(pages))]
    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        f"<< /Type /Pages /Kids [{kids}] /Count {len(pages)} >>".encode(PDF_ENCODING),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    for pid, lines in zip(page_ids, pages, strict=True):
        content = _page_content(lines)
        objects.append(
            f"<< /Type /Page /MediaBox [0 0 {_PAGE_WIDTH} {_PAGE_HEIGHT}] /Parent 2 0 R "
            f"/Resources << /Font << /F1 3 0 R >> >> /Contents {pid + 1} 0 R >>".encode(PDF_ENCODING)
        )
        objects.append(
            f"<< /Length {len(content)} >>".encode(PDF_ENCODING) + b"\nstream\n" + content + b"\nendstream"
        )
    return _serialise_pdf(objects)


def _serialise_pdf(objects: list[bytes]) -> bytes:
    pdf = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(pdf))
        pdf += f"{i} 0 obj\n".encode(PDF_ENCODING) + obj + b"\nendobj\n"
    xref_offset = len(pdf)
    pdf += f"xref\n0 {len(objects) + 1}\n".encode(PDF_ENCODING)
    pdf += b"0000000000 65535 f \n"
    for offset in offsets:
        pdf += f"{offset:010d} 00000 n \n".encode(PDF_ENCODING)
    pdf += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_offset}\n%%EOF"
    ).encode(PDF_ENCODING)
    return bytes(pdf)


TOOLS = {t.name: t for t in (generate_docx, generate_pdf)}
_GENERATORS = {"docx": generate_docx, "pdf": generate_pdf}


def _agent_fn(payload: dict) -> dict:
    doc_type = payload.get("document_type", "docx")
    topic = payload.get("topic", DEFAULT_TOPIC)
    generator = _GENERATORS[doc_type]
    document_b64 = generator.invoke({"topic": topic})
    return {
        "document": document_b64,
        "answer": f"Generated a {doc_type.upper()} report for {topic}.",
        "document_type": doc_type,
        "tool_calls": [{"name": generator.name, "args": {"topic": topic}, "latency_ms": 50}],
        "usage": estimate_usage(topic, document_b64),
    }


agent_runnable = RunnableLambda(_agent_fn)

app = create_app("Sample Document QA Agent", TOOLS)


class DocumentQARequest(BaseModel):
    document_type: DocumentType = Field(default="docx")
    topic: str = Field(default=DEFAULT_TOPIC, min_length=1)


@app.post("/api/eval/document-qa")
def evaluate_document(request: DocumentQARequest):
    started = time.perf_counter()
    result = agent_runnable.invoke({"document_type": request.document_type, "topic": request.topic})
    envelope = build_envelope(
        target_id="document_qa",
        output=result["document"],
        result=result,
        source_context={"document_type": request.document_type, "topic": request.topic},
        started=started,
        model="document-qa-langchain-v1",
        metadata={"ai_confidence": 0.88, "document_type": request.document_type},
    )
    envelope["answer"] = result["answer"]
    return envelope


if __name__ == "__main__":
    serve(app, PORT)
