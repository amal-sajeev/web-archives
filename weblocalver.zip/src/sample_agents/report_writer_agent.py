"""Runnable sample LangChain agent - a report writer that returns Markdown.

Hostable standalone on :4011. Demonstrates the config-driven ``http`` adapter
with ``content_type: markdown`` and config-driven scorers
(``section_present``, ``contains``, ``rubric``).

    POST /api/eval/report-writer  { "topic": "..." }
    -> { "output": "# Report ...\\n## Section ...", "model": ..., "tool_calls": [...], "usage": {...} }

Run:  python src/sample_agents/report_writer_agent.py
"""

from __future__ import annotations

import time

from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from pydantic import BaseModel, Field

try:
    from sample_agents._common import build_envelope, create_app, estimate_usage, serve
except ModuleNotFoundError:  # run as a plain script without PYTHONPATH=src
    from _common import build_envelope, create_app, estimate_usage, serve

DEFAULT_TOPIC = "Q1 Financial Summary"
PORT = 4011


@tool
def generate_section(title: str, key_points: list[str]) -> str:
    """Generate a Markdown section with a heading and bullet points."""
    lines = [f"## {title}", ""]
    lines.extend(f"- {point}" for point in key_points)
    return "\n".join(lines)


@tool
def generate_summary(topic: str) -> str:
    """Generate an executive summary heading for a report topic."""
    return f"# {topic}\n\nThis report covers {topic}."


TOOLS = {t.name: t for t in (generate_section, generate_summary)}


# Each report is a list of (section title, bullet points) pairs.
REPORTS: dict[str, list[tuple[str, list[str]]]] = {
    DEFAULT_TOPIC: [
        ("Revenue Analysis", ["Total revenue: $10M", "Growth: 15% YoY", "Top segment: Enterprise"]),
        ("Expense Breakdown", ["Total expenses: $4M", "Operating costs: $2.5M", "Marketing: $1.5M"]),
        ("Net Income", ["Net income: $6M", "Margin: 60%", "Ahead of forecast by 8%"]),
    ],
    "Risk Assessment Report": [
        ("Risk Identification", ["5 risks identified", "2 high priority", "3 medium priority"]),
        ("Mitigation Plan", ["Controls mapped to each risk", "Owner assigned", "Review quarterly"]),
        ("Residual Risk", ["All high risks mitigated", "Medium risks monitored", "No critical gaps"]),
    ],
    "Compliance Review": [
        ("Regulatory Scope", [
            "The compliance scope covers three major regulatory frameworks",
            "Dodd-Frank Act", "MiFID II", "EMIR",
        ]),
        ("Gap Analysis", ["2 gaps identified", "Remediation in progress", "ETA: Q3 2025"]),
        ("Recommendations", ["Enhance monitoring controls", "Update policies", "Staff training"]),
    ],
}


def _agent_fn(payload: dict) -> dict:
    topic = payload.get("topic", DEFAULT_TOPIC)
    sections = REPORTS.get(topic, REPORTS[DEFAULT_TOPIC])

    parts = [generate_summary.invoke({"topic": topic})]
    tool_calls = [{"name": "generate_summary", "args": {"topic": topic}, "latency_ms": 5}]

    for title, points in sections:
        parts.append(generate_section.invoke({"title": title, "key_points": points}))
        tool_calls.append({
            "name": "generate_section",
            "args": {"title": title, "key_points": points},
            "latency_ms": 8,
        })

    output = "\n\n".join(parts)
    return {"output": output, "tool_calls": tool_calls, "usage": estimate_usage(topic, output)}


agent_runnable = RunnableLambda(_agent_fn)

app = create_app("Sample Report Writer Agent", TOOLS)


class ReportRequest(BaseModel):
    topic: str = Field(default=DEFAULT_TOPIC, min_length=1)


@app.post("/api/eval/report-writer")
def evaluate_report(request: ReportRequest):
    started = time.perf_counter()
    result = agent_runnable.invoke({"topic": request.topic})
    return build_envelope(
        target_id="report_writer",
        output=result["output"],
        result=result,
        source_context={"topic": request.topic},
        started=started,
        model="report-writer-langchain-v1",
        metadata={"ai_confidence": 0.90},
    )


if __name__ == "__main__":
    serve(app, PORT)
