"""Route table: binds every API and UI path to its handler.

Handlers receive the registry/repository/runner through the ``Depends`` markers
declared in their signatures (see ``dependencies``), so no wrapper functions are
needed here. Each route is tagged for the OpenAPI docs; its summary is the first
line of the handler docstring and its description the full docstring.

Order matters: ``/api/runs/summary`` and ``/api/runs/compare`` are registered
before ``/api/runs/{run_id}`` so those words are never read as run ids.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from fastapi import APIRouter

import handlers as h
from core.models.api import (
    AgentListResponse,
    ErrorResponse,
    RunDetailResponse,
    RunListResponse,
    RunSummaryResponse,
)

_GET = ["GET"]
_HEAD = ["HEAD"]
_POST = ["POST"]
_ERROR: dict[str, Any] = {"model": ErrorResponse, "description": "Error"}

TAG_HEALTH = "health"
TAG_AGENTS = "agents"
TAG_EVALUATION = "evaluation"
TAG_STREAMS = "streams"
TAG_RUNS = "runs"
TAG_PLAYGROUND = "playground"
TAG_LABELS = "captures & labels"
TAG_SETTINGS = "settings"

OPENAPI_TAGS = [
    {"name": TAG_HEALTH, "description": "Liveness, readiness and configuration probes."},
    {"name": TAG_AGENTS, "description": "Registered agents and their resolved target wiring."},
    {"name": TAG_EVALUATION, "description": "Start evaluations (sync, background, webhook, A/B)."},
    {"name": TAG_STREAMS, "description": "Follow or cancel live runs (SSE and polling)."},
    {"name": TAG_RUNS, "description": "Stored runs: list, summarise, compare, export, promote baselines."},
    {"name": TAG_PLAYGROUND, "description": "Sandbox evaluation of uploaded agent bundles and the HTTP probe."},
    {"name": TAG_LABELS, "description": "Captured case actions and human labels (in memory)."},
    {"name": TAG_SETTINGS, "description": "Runtime toggles."},
]


def _tagged(tag: str) -> dict[str, list[str]]:
    return {"tags": [tag]}


def _errors(*statuses: int) -> dict[int | str, dict[str, Any]]:
    return dict.fromkeys(statuses, _ERROR)


def _summary(handler: Callable[..., Any]) -> str | None:
    doc = (handler.__doc__ or "").strip()
    return doc.splitlines()[0].rstrip(".") if doc else None


def _add(router: APIRouter, path: str, handler: Callable[..., Any], methods: list[str], **kwargs: Any) -> None:
    kwargs.setdefault("summary", _summary(handler))
    router.add_api_route(path, handler, methods=methods, **kwargs)


def _probe(router: APIRouter, path: str, handler: Callable[..., Any], **kwargs: Any) -> None:
    """GET (documented) plus HEAD (hidden, avoids duplicate operation ids) for a probe path."""
    _add(router, path, handler, _GET, **_tagged(TAG_HEALTH), **kwargs)
    _add(router, path, handler, _HEAD, include_in_schema=False)


def _bind_health(router: APIRouter) -> None:
    _probe(router, "/api/health", h.health)
    _probe(router, "/health", h.health)
    # Legacy typo aliases kept for old clients; hidden from the OpenAPI schema.
    _add(router, "/api/helath", h.health, _GET, include_in_schema=False)
    _add(router, "/helath", h.health, _GET, include_in_schema=False)
    _probe(router, "/livez", h.livez)
    _probe(router, "/readyz", h.readyz, responses=_errors(503))


def _bind_evaluation(router: APIRouter) -> None:
    agents = _tagged(TAG_AGENTS)
    _add(router, "/api/agents", h.list_agents, _GET, response_model=AgentListResponse, **agents)
    _add(router, "/api/agents/{agent_id}/target", h.agent_target, _GET, responses=_errors(404), **agents)
    ev = _tagged(TAG_EVALUATION)
    _add(router, "/api/evaluate", h.evaluate, _POST, responses=_errors(400, 404, 500, 502, 503), **ev)
    _add(router, "/api/evaluate/start", h.evaluate_start, _POST, status_code=202, responses=_errors(404), **ev)
    _add(router, "/api/evaluate/async", h.evaluate_async, _POST, status_code=202, responses=_errors(404), **ev)
    _add(router, "/api/evaluate/ab", h.evaluate_ab, _POST, responses=_errors(400, 404, 502, 503), **ev)
    st = _tagged(TAG_STREAMS)
    _add(router, "/api/evaluate/streams", h.evaluate_streams, _GET, **st)
    _add(router, "/api/evaluate/stream/{stream_id}", h.evaluate_stream, _GET, responses=_errors(404), **st)
    _add(router, "/api/evaluate/stream/{stream_id}/events", h.evaluate_stream_events, _GET,
         responses=_errors(404), **st)
    _add(router, "/api/evaluate/cancel/{stream_id}", h.evaluate_cancel, _POST, status_code=202,
         responses=_errors(404, 409), **st)


def _bind_runs(router: APIRouter) -> None:
    runs = _tagged(TAG_RUNS)
    _add(router, "/api/runs", h.list_runs, _GET, response_model=RunListResponse, responses=_errors(503), **runs)
    _add(router, "/api/runs/summary", h.runs_summary, _GET, response_model=RunSummaryResponse,
         responses=_errors(503), **runs)
    _add(router, "/api/runs/compare", h.compare_runs, _GET, responses=_errors(400, 404), **runs)
    # Documented model only: re-validating a full run record per request costs more than it adds.
    _add(router, "/api/runs/{run_id}", h.get_run, _GET,
         responses={200: {"model": RunDetailResponse}, **_errors(404, 503)}, **runs)
    _add(router, "/api/runs/{run_id}/export", h.export_run, _GET, responses=_errors(404), **runs)
    _add(router, "/api/baselines/promote/{run_id}", h.promote_baselines, _POST,
         responses=_errors(404, 409), **runs)


def _bind_playground(router: APIRouter) -> None:
    pg = _tagged(TAG_PLAYGROUND)
    _add(router, "/api/playground/inspect", h.playground_inspect, _POST, responses=_errors(400), **pg)
    _add(router, "/api/playground/validate", h.playground_validate, _POST, **pg)
    _add(router, "/api/playground/environment", h.playground_environment, _GET, **pg)
    _add(router, "/api/playground/http", h.playground_http, _POST, responses=_errors(502, 504), **pg)
    _add(router, "/api/playground/start", h.playground_start, _POST, status_code=202, responses=_errors(400), **pg)
    _add(router, "/api/playground/export", h.playground_export, _POST, responses=_errors(400, 404), **pg)


def _bind_misc(router: APIRouter) -> None:
    lb = _tagged(TAG_LABELS)
    _add(router, "/api/captures", h.list_captures, _GET, **lb)
    _add(router, "/api/captures/{case_id}", h.get_capture, _GET, responses=_errors(404), **lb)
    _add(router, "/api/labels", h.list_labels, _GET, **lb)
    _add(router, "/api/labels/{case_id}", h.get_label, _GET, responses=_errors(404), **lb)
    _add(router, "/api/labels", h.add_label, _POST, status_code=201, **lb)
    settings = _tagged(TAG_SETTINGS)
    _add(router, "/api/settings", h.runtime_settings, _GET, **settings)
    _add(router, "/api/settings/tls", h.set_tls_policy, _POST, responses=_errors(400), **settings)


def _bind_ui(router: APIRouter) -> None:
    _add(router, "/", h.index, _GET, include_in_schema=False)
    _add(router, "/run.html", h.run_html, _GET, include_in_schema=False)
    _add(router, "/run_detail.html", h.run_detail_html, _GET, include_in_schema=False)
    _add(router, "/playground.html", h.playground_html, _GET, include_in_schema=False)
    _add(router, "/apitester.html", h.apitester_html, _GET, include_in_schema=False)


def build_router() -> APIRouter:
    """Return a router with every API and UI route registered."""
    router = APIRouter()
    for bind in (_bind_health, _bind_evaluation, _bind_runs, _bind_playground, _bind_misc, _bind_ui):
        bind(router)
    return router
