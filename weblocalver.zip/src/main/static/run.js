// Live run page — streams progress via SSE and renders a scorecard as checks complete.

const params = new URLSearchParams(location.search);
const agentId = params.get("agent") || params.get("agent_id") || "";
const reps = Number(params.get("reps") || params.get("judge_repetitions") || 1);
let streamId = params.get("stream") || "";

const $ = (s) => document.querySelector(s);
const state = {
  total: 0,
  done: 0,
  metrics: [],
  caseEls: {},
  runId: null,
};

function pill(text, cls) {
  const p = $("#run-pill");
  p.textContent = text;
  p.className = "pill " + (cls || "");
}

function setProgress() {
  const pctDone = state.total ? (state.done / state.total) * 100 : 0;
  $("#progress-bar").style.width = pctDone + "%";
  $("#progress-text").textContent = state.total
    ? `${state.done} / ${state.total} cases complete`
    : "Starting…";
}

function onRunStarted(e) {
  state.total = e.total_cases;
  state.metrics = e.metrics || [];
  $("#m-agent").textContent = e.agent_id;
  $("#m-dataset").textContent = `${e.dataset_id} · v${e.dataset_version}`;
  $("#m-cases").textContent = e.total_cases;
  $("#m-conc").textContent = e.concurrency > 1 ? `${e.concurrency} in parallel` : "Sequential";
  $("#m-reps").textContent = e.judge_repetitions === 1
    ? "1"
    : String(e.judge_repetitions);
  pill("running", "running");
  setProgress();
}

function chipHtml(m) {
  const info = CTNA.metricInfo(m.name);
  const badges = [];
  if (m.judge || info.judge) badges.push(`<span class="badge badge-judge">Model assessment</span>`);
  if (m.critical) badges.push(`<span class="badge badge-critical">Mandatory</span>`);
  return `<div class="mchip queued" data-metric="${CTNA.escapeHtml(m.name)}">
      <div class="mchip-top">
        <span class="mchip-name">${CTNA.escapeHtml(info.title)}</span>
        ${badges.join(" ")}
      </div>
      <p class="mchip-blurb">${CTNA.escapeHtml(info.blurb)}</p>
      <div class="mchip-state"><span class="dot"></span><span class="txt">Queued</span></div>
      <div class="mchip-meter"><span></span></div>
    </div>`;
}

function onCaseStarted(e) {
  const wrap = document.createElement("details");
  wrap.className = "live-case running";
  wrap.open = true;
  wrap.innerHTML = `
    <summary>
      <span class="case-status"><span class="spinner"></span></span>
      <strong>${CTNA.escapeHtml(e.case_id)}</strong>
      <span class="muted">case ${e.index + 1} / ${e.total}</span>
      <span class="case-score muted"></span>
    </summary>
    <div class="live-case-body">
      <div class="observation muted">Invoking the agent…</div>
      <div class="metrics-grid">${state.metrics.map(chipHtml).join("")}</div>
    </div>`;
  $("#live-cases").prepend(wrap);
  const chips = {};
  wrap.querySelectorAll(".mchip").forEach((el) => { chips[el.dataset.metric] = el; });
  state.caseEls[e.case_id] = {
    root: wrap,
    obs: wrap.querySelector(".observation"),
    summary: wrap.querySelector(".case-score"),
    statusEl: wrap.querySelector(".case-status"),
    chips,
  };
}

function onObservation(e) {
  const c = state.caseEls[e.case_id];
  if (!c) return;
  const bits = [];
  if (e.model) bits.push(`model ${CTNA.escapeHtml(e.model)}`);
  bits.push(`${e.tool_calls} tool call${e.tool_calls === 1 ? "" : "s"}`);
  if (e.latency_ms) {
    bits.push(e.latency_ms >= 1000
      ? `${(e.latency_ms / 1000).toFixed(e.latency_ms >= 10000 ? 0 : 1)}s`
      : `${e.latency_ms} ms`);
  }
  if (e.error) bits.push(`<span class="fail">error: ${CTNA.escapeHtml(e.error)}</span>`);
  const preview = e.output_preview
    ? `<div class="obs-output">${CTNA.escapeHtml(e.output_preview)}</div>` : "";
  c.obs.innerHTML = `<div class="obs-line">${bits.join(" · ")}</div>${preview}`;
  c.obs.classList.remove("muted");
}

function onMetricStarted(e) {
  const c = state.caseEls[e.case_id];
  if (!c || !c.chips[e.metric]) return;
  const chip = c.chips[e.metric];
  chip.className = "mchip running";
  chip.querySelector(".mchip-state .txt").textContent = "In progress…";
}

function onMetricDone(e) {
  const c = state.caseEls[e.case_id];
  if (!c || !c.chips[e.metric]) return;
  const chip = c.chips[e.metric];
  chip.className = "mchip " + (e.passed ? "ok" : "bad");
  const pct = Math.max(0, Math.min(1, Number(e.score) || 0)) * 100;
  chip.querySelector(".mchip-meter span").style.width = pct + "%";
  const extra = [];
  const delta = CTNA.formatDeltaPts(e.delta);
  if (delta) extra.push(delta);
  if (e.unstable) extra.push(`<span class="badge badge-warn">Inconsistent assessment</span>`);
  const need = CTNA.formatThreshold(e.threshold);
  chip.querySelector(".mchip-state").innerHTML =
    `<span class="dot"></span><span class="txt">${e.passed ? "Meets requirement" : "Does not meet requirement"} · ${CTNA.formatPercent(e.score)}${need ? " · " + need : ""} ${extra.join(" ")}</span>`;
  if (e.rationale) chip.title = e.rationale;
}

function onMetricSkipped(e) {
  const c = state.caseEls[e.case_id];
  if (!c || !c.chips[e.metric]) return;
  const chip = c.chips[e.metric];
  chip.className = "mchip skipped";
  chip.querySelector(".mchip-state .txt").textContent = "Skipped (unavailable in this environment)";
  chip.title = e.reason || "";
}

function onCaseDone(e) {
  const c = state.caseEls[e.case_id];
  state.done += 1;
  setProgress();
  if (!c) return;
  c.root.className = "live-case " + (e.passed ? "pass" : "fail");
  c.root.open = !e.passed;
  c.statusEl.innerHTML = e.passed
    ? `<span class="pass">✓</span>` : `<span class="fail">✗</span>`;
  const delta = CTNA.formatDeltaPts(e.weighted_delta);
  c.summary.innerHTML =
    `<span class="${e.passed ? "pass" : "fail"}">${e.passed ? "Pass" : "Fail"}</span> · ${CTNA.formatPercent(e.weighted_score)}${delta ? " · " + delta : ""}`;
}

function onRunDone(e) {
  state.runId = e.run_id;
  pill(CTNA.isPassingStatus(e.status) ? "Pass" : "Fail", CTNA.isPassingStatus(e.status) ? "ok" : "bad");
  $("#live-dot").style.display = "none";
  $("#final-panel").hidden = false;
  const delta = CTNA.formatDeltaPts(e.weighted_delta);
  $("#final-banner").innerHTML =
    `<div class="final ${CTNA.isPassingStatus(e.status) ? "pass" : "fail"}">
       ${CTNA.stampHtml(e.status)}
       ${CTNA.scoreRingHtml(e.weighted_score, 96)}
       <div>
         <div class="final-verdict">${CTNA.isPassingStatus(e.status) ? "Pass" : "Fail"}</div>
         <div>Overall score <strong>${CTNA.formatPercent(e.weighted_score)}</strong>${delta ? " · " + delta : ""}</div>
       </div>
     </div>`;
  $("#view-detail").href = `run_detail.html?run=${encodeURIComponent(e.run_id)}`;
}

function onError(e) {
  pill("error", "bad");
  $("#live-dot").style.display = "none";
  $("#final-panel").hidden = false;

  const details = {
    when: new Date().toISOString(),
    page_url: location.href,
    agent_id: agentId,
    reps,
    stream_id: streamId || null,
    run_id: state.runId || null,
    status: e.status || null,
    error_type: e.error_type || null,
    detail: e.detail || null,
    traceback: e.traceback || null,
    raw_event: e,
  };
  console.group("%cEVALUATION RUN ERROR", "color:#f87171;font-weight:bold");
  console.error(details.detail || "run failed");
  if (details.traceback) console.error("Server traceback:\n" + details.traceback);
  console.log("Full error details (copy the JSON below):");
  console.log(JSON.stringify(details, null, 2));
  console.groupEnd();
  window.__lastRunError = details;

  const tb = e.traceback
    ? `<pre class="err-trace">${CTNA.escapeHtml(e.traceback)}</pre>` : "";
  $("#final-banner").innerHTML =
    `<div class="final fail">${CTNA.stampHtml("ERROR")}
       <span class="final-verdict">Evaluation failed ${e.status ? "(" + e.status + ")" : ""}</span>
       <span>${CTNA.escapeHtml(e.detail || "The evaluation could not be completed.")}</span></div>
     ${tb}
     <div class="err-actions">
       <button id="copy-err" class="pill link">Copy error details</button>
       <span class="muted">Full details are also available in the browser console (F12)</span>
     </div>`;
  const btn = $("#copy-err");
  if (btn) btn.addEventListener("click", () => {
    navigator.clipboard.writeText(JSON.stringify(details, null, 2))
      .then(() => { btn.textContent = "Copied"; })
      .catch(() => { btn.textContent = "Copy failed"; });
  });
}

const HANDLERS = {
  run_started: onRunStarted,
  case_started: onCaseStarted,
  observation: onObservation,
  metric_started: onMetricStarted,
  metric_done: onMetricDone,
  metric_skipped: onMetricSkipped,
  case_done: onCaseDone,
  run_done: onRunDone,
  error: onError,
};

function attach(sid) {
  const es = new EventSource(`api/evaluate/stream/${encodeURIComponent(sid)}`);
  es.onmessage = (msg) => {
    let ev;
    try { ev = JSON.parse(msg.data); }
    catch (err) {
      console.error("Could not parse SSE event:", err, "raw:", msg.data);
      return;
    }
    if (ev.type === "error") console.error("[run event] error:", ev);
    else console.debug("[run event]", ev.type, ev);
    const h = HANDLERS[ev.type];
    if (h) h(ev);
    if (ev.type === "run_done" || ev.type === "error") es.close();
  };
  es.onerror = (err) => {
    console.warn("[run stream] EventSource connection error (will auto-retry):",
                 err, "readyState:", es.readyState);
    if (state.runId || !$("#final-panel").hidden) es.close();
  };
}

async function start() {
  if (streamId) {
    attach(streamId);
    return;
  }
  if (!agentId) {
    onError({ status: 400, detail: "No agent specified. Return to the dashboard and start an evaluation." });
    return;
  }
  try {
    const res = await fetch("api/evaluate/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agent_id: agentId, judge_repetitions: reps }),
    });
    if (!res.ok) {
      const detail = await res.text();
      onError({ status: res.status, detail: detail || "failed to start run" });
      return;
    }
    const data = await res.json();
    streamId = data.stream_id;
    const url = new URL(location.href);
    url.searchParams.set("stream", streamId);
    history.replaceState(null, "", url);
    attach(streamId);
  } catch (err) {
    onError({ detail: "The evaluation service could not be reached to start the run." });
  }
}

start();
