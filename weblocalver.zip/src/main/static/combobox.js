// Searchable dropdown. Progressively enhances an existing <select>: the select
// stays in the DOM as the source of truth, so `select.value` reads and `change`
// listeners keep working, and the page still functions if this script fails.
// ES module: import { enhance } from "../../combobox.js".

import { escapeHtml } from "./js/lib/fragments.js";

const OPTION_SELECTOR = ".combobox-option";
const DEFAULT_EMPTY = "No matches";
const CHEVRON_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';

let seq = 0;

function highlight(text, query) {
  const safe = escapeHtml(text);
  if (!query) return safe;
  const at = text.toLowerCase().indexOf(query);
  if (at < 0) return safe;
  return escapeHtml(text.slice(0, at))
    + "<mark>" + escapeHtml(text.slice(at, at + query.length)) + "</mark>"
    + escapeHtml(text.slice(at + query.length));
}

function optionLabel(opt) {
  return opt.dataset.label || opt.textContent.trim();
}

function matches(item, q) {
  if (item.disabled) return false;
  if (!q) return true;
  return [item.label, item.value, item.meta].some((text) => text.toLowerCase().includes(q));
}

function createElement(tag, props, attrs = {}) {
  const el = Object.assign(document.createElement(tag), props);
  Object.entries(attrs).forEach(([name, value]) => el.setAttribute(name, value));
  return el;
}

class Combobox {
  constructor(select, config) {
    this.select = select;
    this.config = config;
    this.id = select.id || `combobox-${++seq}`;
    this.items = [];
    this.shown = [];
    this.activeIndex = -1;
    this.isOpen = false;
    this.build();
    this.labelInput();
    this.bindInput();
    this.bindPointer();
  }

  build() {
    const listId = `${this.id}-listbox`;
    this.element = createElement("div", { className: "combobox" });
    this.input = createElement("input", {
      type: "text", id: `${this.id}-input`, className: "combobox-input", autocomplete: "off", spellcheck: false,
    }, { role: "combobox", "aria-expanded": "false", "aria-controls": listId, "aria-autocomplete": "list" });
    if (this.config.placeholder) this.input.placeholder = this.config.placeholder;
    this.toggle = createElement("button", { type: "button", className: "combobox-toggle", tabIndex: -1, innerHTML: CHEVRON_SVG },
      { "aria-hidden": "true" });
    this.list = createElement("ul", { id: listId, className: "combobox-list", hidden: true }, { role: "listbox" });

    this.select.parentNode.insertBefore(this.element, this.select);
    this.element.appendChild(this.select);
    this.element.append(this.input, this.toggle, this.list);
    this.select.classList.add("combobox-native");
    this.select.tabIndex = -1;
    this.select.setAttribute("aria-hidden", "true");
  }

  // The select precedes the input, so an implicit label would target the hidden
  // select. Point the label (and the listbox name) at the input instead.
  labelInput() {
    const label = this.element.closest("label");
    if (label) {
      if (!label.htmlFor) label.htmlFor = this.input.id;
      if (!label.id) label.id = `${this.id}-label`;
      this.list.setAttribute("aria-labelledby", label.id);
      return;
    }
    const aria = this.select.getAttribute("aria-label");
    if (aria) {
      this.input.setAttribute("aria-label", aria);
      this.list.setAttribute("aria-label", aria);
    }
  }

  bindInput() {
    this.input.addEventListener("focus", () => { this.open(); this.input.select(); });
    this.input.addEventListener("click", () => this.open());
    this.input.addEventListener("input", () => { this.open(); this.render(this.input.value); });
    this.input.addEventListener("keydown", (event) => this.onKeydown(event));
    this.input.addEventListener("blur", () => {
      // A click on an option fires after blur; the list suppresses its own
      // mousedown so focus never leaves while choosing.
      window.setTimeout(() => { if (!this.element.contains(document.activeElement)) this.close(); }, 0);
    });
  }

  bindPointer() {
    this.list.addEventListener("mousedown", (event) => event.preventDefault());
    this.list.addEventListener("click", (event) => {
      const option = event.target.closest(OPTION_SELECTOR);
      if (!option) return;
      this.commit(Number(option.dataset.index));
      this.input.focus();
    });
    this.toggle.addEventListener("mousedown", (event) => event.preventDefault());
    this.toggle.addEventListener("click", () => {
      if (this.isOpen) this.close();
      else this.open();
      this.input.focus();
      if (this.isOpen) this.input.select();
    });
    document.addEventListener("pointerdown", (event) => {
      if (this.isOpen && !this.element.contains(event.target)) this.close();
    });
  }

  // Each handler returns true when it consumed the key (so the default is prevented).
  keyHandlers() {
    const whenOpen = (fn) => () => {
      if (!this.isOpen) return false;
      fn();
      return true;
    };
    return {
      ArrowDown: () => { this.move(1); return true; },
      ArrowUp: () => { this.move(-1); return true; },
      Home: whenOpen(() => this.setActive(0)),
      End: whenOpen(() => this.setActive(this.optionNodes().length - 1)),
      Escape: whenOpen(() => this.close()),
      Enter: () => {
        const item = this.isOpen ? this.shown[this.activeIndex] : null;
        if (item) this.commit(item.index);
        return Boolean(item);
      },
      Tab: () => { this.close(); return false; },
    };
  }

  onKeydown(event) {
    const handler = this.keyHandlers()[event.key];
    if (handler && handler()) event.preventDefault();
  }

  selectedLabel() {
    const opt = this.select.options[this.select.selectedIndex];
    return opt ? optionLabel(opt) : "";
  }

  optionNodes() {
    return this.list.querySelectorAll(OPTION_SELECTOR);
  }

  sync() {
    this.items = Array.from(this.select.options).map((opt, index) => ({
      index,
      value: opt.value,
      label: optionLabel(opt),
      meta: opt.dataset.meta || "",
      disabled: opt.disabled,
    }));
    if (!this.isOpen) this.input.value = this.selectedLabel();
  }

  renderEmpty(query, q) {
    const emptyText = this.config.emptyText || DEFAULT_EMPTY;
    const message = q ? `${escapeHtml(emptyText)} for “${escapeHtml(query.trim())}”` : escapeHtml(emptyText);
    this.list.innerHTML = `<li class="combobox-empty">${message}</li>`;
    this.activeIndex = -1;
    this.input.removeAttribute("aria-activedescendant");
  }

  optionHtml(item, i, q) {
    const current = item.index === this.select.selectedIndex;
    const meta = item.meta ? `<span class="combobox-option-meta">${highlight(item.meta, q)}</span>` : "";
    return `<li class="combobox-option" role="option" id="${this.id}-opt-${i}"
      data-index="${item.index}" aria-selected="${String(current)}">
      <span class="combobox-option-label">${highlight(item.label, q)}</span>${meta}
    </li>`;
  }

  render(query) {
    const q = (query || "").trim().toLowerCase();
    this.shown = this.items.filter((item) => matches(item, q));
    if (!this.shown.length) {
      this.renderEmpty(query || "", q);
      return;
    }
    this.list.innerHTML = this.shown.map((item, i) => this.optionHtml(item, i, q)).join("");
    const current = this.shown.findIndex((item) => item.index === this.select.selectedIndex);
    this.setActive(q ? 0 : Math.max(current, 0));
  }

  setActive(i) {
    this.activeIndex = i;
    const nodes = this.optionNodes();
    nodes.forEach((node, n) => node.classList.toggle("active", n === i));
    const node = nodes[i];
    if (node) {
      this.input.setAttribute("aria-activedescendant", node.id);
      node.scrollIntoView({ block: "nearest" });
    } else {
      this.input.removeAttribute("aria-activedescendant");
    }
  }

  move(step) {
    if (!this.isOpen) {
      this.open();
      return;
    }
    const count = this.optionNodes().length;
    if (count) this.setActive((this.activeIndex + step + count) % count);
  }

  setExpanded(expanded) {
    this.isOpen = expanded;
    this.element.classList.toggle("open", expanded);
    this.list.hidden = !expanded;
    this.input.setAttribute("aria-expanded", String(expanded));
  }

  open() {
    if (this.isOpen) return;
    this.setExpanded(true);
    this.render("");
  }

  close(restore) {
    if (!this.isOpen) return;
    this.setExpanded(false);
    this.input.removeAttribute("aria-activedescendant");
    if (restore !== false) this.input.value = this.selectedLabel();
  }

  commit(optionIndex) {
    const previous = this.select.value;
    this.select.selectedIndex = optionIndex;
    this.close();
    this.input.value = this.selectedLabel();
    if (this.select.value !== previous) {
      this.select.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
}

/** Enhance ``select`` in place; calling again re-syncs the existing combobox. */
export function enhance(select, options) {
  if (!select) return null;
  if (select._ctnaCombobox) {
    select._ctnaCombobox.sync();
    return select._ctnaCombobox;
  }
  const combobox = new Combobox(select, options || {});
  select._ctnaCombobox = combobox;
  combobox.sync();
  return combobox;
}
