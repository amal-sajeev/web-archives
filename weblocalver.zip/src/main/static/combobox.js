// Searchable dropdown. Progressively enhances an existing <select>: the select
// stays in the DOM as the source of truth, so `select.value` reads and `change`
// listeners keep working, and the page still functions if this script fails.

(function () {
  "use strict";

  let seq = 0;

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => (
      { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
    ));
  }

  function highlight(text, query) {
    const safe = escapeHtml(text);
    if (!query) return safe;
    const at = text.toLowerCase().indexOf(query);
    if (at < 0) return safe;
    return escapeHtml(text.slice(0, at))
      + "<mark>" + escapeHtml(text.slice(at, at + query.length)) + "</mark>"
      + escapeHtml(text.slice(at + query.length));
  }

  function enhance(select, options) {
    if (!select) return null;
    if (select._ctnaCombobox) {
      select._ctnaCombobox.sync();
      return select._ctnaCombobox;
    }

    const config = options || {};
    const id = select.id || `combobox-${++seq}`;
    const listId = `${id}-listbox`;

    const wrap = document.createElement("div");
    wrap.className = "combobox";

    const input = document.createElement("input");
    input.type = "text";
    input.id = `${id}-input`;
    input.className = "combobox-input";
    input.autocomplete = "off";
    input.spellcheck = false;
    input.setAttribute("role", "combobox");
    input.setAttribute("aria-expanded", "false");
    input.setAttribute("aria-controls", listId);
    input.setAttribute("aria-autocomplete", "list");
    if (config.placeholder) input.placeholder = config.placeholder;

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "combobox-toggle";
    toggle.tabIndex = -1;
    toggle.setAttribute("aria-hidden", "true");
    toggle.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';

    const list = document.createElement("ul");
    list.id = listId;
    list.className = "combobox-list";
    list.setAttribute("role", "listbox");
    list.hidden = true;

    select.parentNode.insertBefore(wrap, select);
    wrap.appendChild(select);
    wrap.append(input, toggle, list);

    select.classList.add("combobox-native");
    select.tabIndex = -1;
    select.setAttribute("aria-hidden", "true");

    // The select precedes the input, so an implicit label would target the
    // hidden select. Point the label at the input instead.
    const label = wrap.closest("label");
    if (label && !label.htmlFor) {
      label.htmlFor = input.id;
    } else if (!label) {
      const aria = select.getAttribute("aria-label");
      if (aria) input.setAttribute("aria-label", aria);
    }

    let items = [];
    let shown = [];
    let activeIndex = -1;
    let isOpen = false;

    function selectedLabel() {
      const opt = select.options[select.selectedIndex];
      return opt ? (opt.dataset.label || opt.textContent.trim()) : "";
    }

    function sync() {
      items = Array.from(select.options).map((opt, index) => ({
        index,
        value: opt.value,
        label: opt.dataset.label || opt.textContent.trim(),
        meta: opt.dataset.meta || "",
        disabled: opt.disabled,
      }));
      if (!isOpen) input.value = selectedLabel();
    }

    function render(query) {
      const q = (query || "").trim().toLowerCase();
      shown = items.filter((item) => {
        if (item.disabled) return false;
        if (!q) return true;
        return item.label.toLowerCase().includes(q)
          || item.value.toLowerCase().includes(q)
          || item.meta.toLowerCase().includes(q);
      });

      if (!shown.length) {
        const message = q
          ? `${config.emptyText || "No matches"} for “${escapeHtml(query.trim())}”`
          : (config.emptyText || "No matches");
        list.innerHTML = `<li class="combobox-empty">${message}</li>`;
        activeIndex = -1;
        input.removeAttribute("aria-activedescendant");
        return;
      }

      list.innerHTML = shown.map((item, i) => {
        const current = item.index === select.selectedIndex;
        return `<li class="combobox-option" role="option" id="${id}-opt-${i}"
          data-index="${item.index}" aria-selected="${current ? "true" : "false"}">
          <span class="combobox-option-label">${highlight(item.label, q)}</span>
          ${item.meta ? `<span class="combobox-option-meta">${highlight(item.meta, q)}</span>` : ""}
        </li>`;
      }).join("");

      const current = shown.findIndex((item) => item.index === select.selectedIndex);
      setActive(q ? 0 : Math.max(current, 0));
    }

    function setActive(i) {
      activeIndex = i;
      const nodes = list.querySelectorAll(".combobox-option");
      nodes.forEach((node, n) => node.classList.toggle("active", n === i));
      const node = nodes[i];
      if (node) {
        input.setAttribute("aria-activedescendant", node.id);
        node.scrollIntoView({ block: "nearest" });
      } else {
        input.removeAttribute("aria-activedescendant");
      }
    }

    function move(step) {
      if (!isOpen) { open(); return; }
      const count = list.querySelectorAll(".combobox-option").length;
      if (!count) return;
      setActive((activeIndex + step + count) % count);
    }

    function open() {
      if (isOpen) return;
      isOpen = true;
      wrap.classList.add("open");
      list.hidden = false;
      input.setAttribute("aria-expanded", "true");
      render("");
    }

    function close(restore) {
      if (!isOpen) return;
      isOpen = false;
      wrap.classList.remove("open");
      list.hidden = true;
      input.setAttribute("aria-expanded", "false");
      input.removeAttribute("aria-activedescendant");
      if (restore !== false) input.value = selectedLabel();
    }

    function commit(optionIndex) {
      const previous = select.value;
      select.selectedIndex = optionIndex;
      close();
      input.value = selectedLabel();
      if (select.value !== previous) {
        select.dispatchEvent(new Event("change", { bubbles: true }));
      }
    }

    input.addEventListener("focus", () => { open(); input.select(); });
    input.addEventListener("click", () => open());
    input.addEventListener("input", () => {
      if (!isOpen) open();
      render(input.value);
    });

    input.addEventListener("keydown", (event) => {
      switch (event.key) {
        case "ArrowDown": event.preventDefault(); move(1); break;
        case "ArrowUp": event.preventDefault(); move(-1); break;
        case "Home": if (isOpen) { event.preventDefault(); setActive(0); } break;
        case "End":
          if (isOpen) {
            event.preventDefault();
            setActive(list.querySelectorAll(".combobox-option").length - 1);
          }
          break;
        case "Enter":
          if (isOpen && shown[activeIndex]) {
            event.preventDefault();
            commit(shown[activeIndex].index);
          }
          break;
        case "Escape":
          if (isOpen) { event.preventDefault(); close(); }
          break;
        case "Tab": close(); break;
        default: break;
      }
    });

    input.addEventListener("blur", () => {
      // A click on an option fires after blur; the list suppresses its own
      // mousedown so focus never leaves while choosing.
      window.setTimeout(() => { if (!wrap.contains(document.activeElement)) close(); }, 0);
    });

    list.addEventListener("mousedown", (event) => event.preventDefault());
    list.addEventListener("click", (event) => {
      const option = event.target.closest(".combobox-option");
      if (!option) return;
      commit(Number(option.dataset.index));
      input.focus();
    });

    toggle.addEventListener("mousedown", (event) => event.preventDefault());
    toggle.addEventListener("click", () => {
      if (isOpen) { close(); } else { open(); }
      input.focus();
      if (isOpen) input.select();
    });

    document.addEventListener("pointerdown", (event) => {
      if (isOpen && !wrap.contains(event.target)) close();
    });

    const api = { sync, open, close, element: wrap, input };
    select._ctnaCombobox = api;
    sync();
    return api;
  }

  window.CTNACombobox = { enhance };
})();
