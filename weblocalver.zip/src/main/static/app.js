const $ = (sel) => document.querySelector(sel);

function isPassingStatus(status) { return CTNA.isPassingStatus(status); }
function statusClass(status) { return isPassingStatus(status) ? "pass" : "fail"; }

let _allRuns = [];
let _activeQuickFilter = "all";

function escape(value) { return CTNA.escapeHtml(String(value ?? "")); }
function scoreValue(run) { const n = Number(run?.weighted_score); return Number.isFinite(n) ? n : null; }
function deltaValue(run) { const n = Number(run?.weighted_delta); return Number.isFinite(n) ? n : null; }
function runCases(run) {
  if (Number.isFinite(Number(run?.passed_cases)) && Number.isFinite(Number(run?.total_cases))) {
    return `${run.passed_cases}/${run.total_cases}`;
  }
  if (Number.isFinite(Number(run?.case_count)) && Number.isFinite(Number(run?.passed_case_count))) {
    return `${run.passed_case_count}/${run.case_count}`;
  }
  return run?.case_results ? `${run.case_results.filter(c => c.passed).length}/${run.case_results.length}` : "–";
}
function isRegression(run) { const d = deltaValue(run); return d !== null && d < -0.000001; }
function isImprovement(run) { const d = deltaValue(run); return d !== null && d > 0.000001; }
function needsReview(run) { return !isPassingStatus(run?.status) || isRegression(run); }

async function loadHealth() {
  try {
    const h = await (await fetch("api/health")).json();
    const pill = $("#health");
    const reachable = h && h.status && h.status !== "error";
    pill.textContent = reachable ? "Available" : "Unavailable";
    pill.className = "pill " + (h.status === "ok" ? "ok" : reachable ? "ok" : "bad");
    const bits = [`status ${h.status}`];
    if (h.vertex) bits.push(`judge: ${h.vertex}`);
    if (h.credential_class) bits.push(h.credential_class);
    if (h.status === "degraded") bits.push("Automated assessment may be unavailable");
    pill.title = bits.join(" · ");
  } catch (e) {
    const pill = $("#health");
    pill.textContent = "Service unavailable";
    pill.className = "pill bad";
    pill.title = "";
  }
}

function makeSearchable(select, options) {
  if (select && window.CTNACombobox) window.CTNACombobox.enhance(select, options);
}

async function loadAgents() {
  try {
    const { agents } = await (await fetch("api/agents")).json();
    const sel = $("#agent");
    if (sel) {
      sel.innerHTML = `<option value="__all__">All agents</option>` + (agents || []).map((a) => {
        const meta = [a.cases != null ? `${a.cases} case${a.cases === 1 ? "" : "s"}` : null, a.dataset_version ? `v${a.dataset_version}` : null].filter(Boolean).join(" · ");
        return `<option value="${escape(a.agent_id)}" data-meta="${escape(meta)}">${escape(a.name)}</option>`;
      }).join("");
      makeSearchable(sel, { placeholder: "Search agents", emptyText: "No agents found" });
      updateAgentScope();
    }
  } catch (e) {
    const sel = $("#agent");
    if (sel) {
      sel.innerHTML = `<option value="">Unable to load agents</option>`;
      makeSearchable(sel, { placeholder: "Unable to load agents" });
      updateAgentScope();
    }
  }
}

/* The agent control scopes the dashboard and targets new runs. With no agent
   chosen there is nothing to evaluate, so the action is unavailable. */
function updateAgentScope() {
  const agent = $("#agent")?.value || "__all__";
  const scoped = agent && agent !== "__all__";
  const button = $("#run");
  if (button) {
    button.disabled = !scoped;
    button.title = scoped ? "" : "Select an agent to start an evaluation";
  }
  const note = $("#agent-scope-note");
  if (note) {
    note.textContent = scoped
      ? `Dashboard scoped to ${agentLabel(agent)}.`
      : "Showing all agents. Select an agent to scope this dashboard and start an evaluation.";
  }
}

function agentLabel(agentId) {
  const option = Array.from($("#agent")?.options || []).find((o) => o.value === agentId);
  return option ? option.textContent.trim() : agentId;
}

async function loadRuns() {
  try {
    const { runs } = await (await fetch("api/runs")).json();
    _allRuns = Array.isArray(runs) ? runs : [];
    applyDashboardFilters();
  } catch (e) {
    _allRuns = [];
    applyDashboardFilters();
    const count = $("#history-count");
    if (count) count.textContent = "Unable to load evaluation history.";
  }
}

function selectedTimeRuns(runs) {
  const days = Number($("#time-filter")?.value || "0");
  if (!days) return runs;
  const cutoff = Date.now() - days * 86400000;
  return runs.filter(r => {
    const ts = Date.parse(r.creation_ts);
    return Number.isFinite(ts) && ts >= cutoff;
  });
}

function selectedAgentRuns(runs) {
  const selected = $("#agent")?.value || "__all__";
  return selected !== "__all__" ? runs.filter(r => r.agent_id === selected) : runs;
}

function searchRuns(runs) {
  const q = ($("#run-search")?.value || "").trim().toLowerCase();
  if (!q) return runs;
  return runs.filter(r => [r.run_id, r.agent_id, r.dataset_version, r.status].some(v => String(v ?? "").toLowerCase().includes(q)));
}

function quickFilterRuns(runs) {
  switch (_activeQuickFilter) {
    case "fail": return runs.filter(r => !isPassingStatus(r.status));
    case "regressed": return runs.filter(isRegression);
    case "threshold": return runs.filter(r => (scoreValue(r) ?? 1) < 0.90);
    case "improved": return runs.filter(isImprovement);
    default: return runs;
  }
}

function applyDashboardFilters() {
  const base = selectedTimeRuns(selectedAgentRuns(_allRuns));
  renderDashboard(base);
  const filtered = quickFilterRuns(searchRuns(base));
  renderHistory(filtered, base.length);
}

function formatDate(ts) {
  const date = new Date(ts);
  return Number.isFinite(date.getTime()) ? date.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "–";
}

function renderDashboard(runs) {
  const ordered = [...runs].sort((a,b) => new Date(a.creation_ts) - new Date(b.creation_ts));
  const scored = runs.map(scoreValue).filter(v => v !== null);
  const avg = scored.length ? scored.reduce((a,b) => a+b, 0) / scored.length : null;
  const passed = runs.filter(r => isPassingStatus(r.status)).length;
  const regressions = runs.filter(isRegression).length;
  const reviews = runs.filter(needsReview).length;
  const improvements = runs.filter(isImprovement);

  $("#dash-avg-score").textContent = avg === null ? "–" : CTNA.formatPercent(avg);
  $("#dash-score-copy").textContent = runs.length ? `Across ${runs.length} evaluation${runs.length === 1 ? "" : "s"}` : "No evaluations in this scope";
  $("#dash-pass-count").textContent = runs.length ? `${passed}/${runs.length}` : "–";
  $("#dash-pass-copy").textContent = runs.length ? `${CTNA.formatPercent(passed / runs.length)} pass rate` : "No completed evaluations";
  $("#dash-pass-rate").textContent = runs.length ? CTNA.formatPercent(passed / runs.length) : "–";
  $("#dash-regressions").textContent = regressions;
  $("#dash-regression-copy").textContent = regressions ? `${regressions} run${regressions === 1 ? "" : "s"} below baseline` : "No baseline regressions";
  $("#dash-review-count").textContent = reviews;
  $("#dash-review-copy").textContent = reviews ? `${reviews} failed or regressed run${reviews === 1 ? "" : "s"}` : "No runs require review";

  const latest = ordered.at(-1) || null;
  const prior = ordered.at(-2) || null;
  const avgDelta = prior && latest && scoreValue(latest) !== null && scoreValue(prior) !== null ? scoreValue(latest) - scoreValue(prior) : null;
  const avgEl = $("#dash-score-delta");
  avgEl.textContent = avgDelta === null ? "" : (avgDelta > 0 ? `↑ ${Math.abs(Math.round(avgDelta * 100))} pts vs previous` : avgDelta < 0 ? `↓ ${Math.abs(Math.round(avgDelta * 100))} pts vs previous` : "→ 0 vs previous");
  avgEl.className = `stat-trend ${avgDelta > 0 ? "positive" : avgDelta < 0 ? "negative" : "flat"}`;

  renderLatest(latest);
  renderBaselineContext(latest);
  renderAttention(runs);
  renderTrendChart(ordered);
}

function renderLatest(run) {
  const el = $("#latest-evaluation");
  const link = $("#latest-open");
  if (!run) {
    el.innerHTML = `<div class="empty-state compact"><strong>No completed evaluation in this scope</strong><span>Start an evaluation to populate the dashboard.</span><button type="button" class="button-secondary inline-empty-action" onclick="startEvaluation()">Start evaluation</button></div>`;
    link.href = "#";
    link.setAttribute("aria-disabled", "true");
    return;
  }
  link.href = `run_detail.html?run=${encodeURIComponent(run.run_id)}`;
  const score = scoreValue(run);
  const delta = deltaValue(run);
  el.innerHTML = `
    <div class="latest-main">
      <div class="latest-status-line"><span class="status-icon ${isPassingStatus(run.status) ? "pass" : "fail"}" aria-hidden="true">${isPassingStatus(run.status) ? "✓" : "!"}</span><span class="pill ${statusClass(run.status)}">${isPassingStatus(run.status) ? "Pass" : "Fail"}</span></div>
      <div class="latest-score">${score === null ? "–" : CTNA.formatPercent(score)}</div>
      <div class="latest-agent">${escape(run.agent_id)} <span>·</span> <span>${escape(run.dataset_version || "")}</span></div>
    </div>
    <div class="latest-meta">
      <div><span>Cases</span><strong>${escape(runCases(run))}</strong></div>
      <div><span>Baseline</span><strong class="${delta < 0 ? "delta-neg" : delta > 0 ? "delta-pos" : ""}">${delta === null ? "No comparison" : CTNA.formatDeltaPts(delta)}</strong></div>
      <div><span>Evaluated</span><strong>${escape(formatDate(run.creation_ts))}</strong></div>
    </div>`;
}

function renderBaselineContext(run) {
  const el = $("#baseline-context");
  if (!run) {
    el.innerHTML = `<div class="baseline-empty"><strong>No baseline comparison yet</strong><span>Run an evaluation to establish a comparison point.</span></div>`;
    return;
  }
  const score = scoreValue(run);
  const delta = deltaValue(run);
  const baselineScore = score !== null && delta !== null ? score - delta : null;
  el.innerHTML = `
    <div class="baseline-score-row"><div><span class="baseline-label">Comparison baseline</span><strong>${baselineScore === null ? "Not available" : CTNA.formatPercent(baselineScore)}</strong></div><div class="baseline-delta ${delta < 0 ? "negative" : delta > 0 ? "positive" : "flat"}">${delta === null ? "No comparison" : delta === 0 ? "Unchanged" : `${delta > 0 ? "↑" : "↓"} ${CTNA.formatDeltaPts(delta)}`}</div></div>
    <div class="baseline-detail-grid">
      <div><span>Agent</span><strong class="baseline-agent-name">${escape(run.agent_id)}</strong></div>
      <div><span>Dataset</span><strong>${escape(run.dataset_version || "–")}</strong></div>
      <div><span>Latest score</span><strong>${score === null ? "–" : CTNA.formatPercent(score)}</strong></div>
    </div>
    <a class="text-link" href="run_detail.html?run=${encodeURIComponent(run.run_id)}">Inspect baseline movement →</a>`;
}

function renderAttention(runs) {
  const panel = $("#attention-panel");
  const list = $("#attention-list");
  const attention = [...runs].filter(needsReview).sort((a,b) => {
    const af = !isPassingStatus(a.status), bf = !isPassingStatus(b.status);
    if (af !== bf) return bf - af;
    return (deltaValue(a) ?? 0) - (deltaValue(b) ?? 0);
  }).slice(0, 5);
  panel.hidden = false;
  if (!attention.length) {
    list.innerHTML = `<div class="attention-empty"><span class="attention-check">✓</span><div><strong>No evaluations require attention</strong><span>All completed runs in this scope passed without a baseline regression.</span></div></div>`;
    return;
  }
  list.innerHTML = attention.map(r => {
    const delta = deltaValue(r);
    const fail = !isPassingStatus(r.status);
    return `<a class="attention-item" href="run_detail.html?run=${encodeURIComponent(r.run_id)}">
      <span class="attention-icon ${fail ? "fail" : "warn"}">${fail ? "!" : "↓"}</span>
      <span class="attention-copy"><strong>${escape(r.agent_id)} <span class="attention-run">${escape(r.run_id.slice(0,8))}</span></strong><span>${fail ? "Evaluation did not pass" : "Below comparison baseline"} · ${escape(formatDate(r.creation_ts))}</span></span>
      <span class="attention-score">${scoreValue(r) === null ? "–" : CTNA.formatPercent(scoreValue(r))}<small>${delta === null ? "" : CTNA.formatDeltaPts(delta)}</small></span>
      <span class="attention-arrow" aria-hidden="true">→</span>
    </a>`;
  }).join("");
}

function renderTrendChart(runs) {
  const chart = $("#trend-chart");
  const meta = $("#trend-meta");
  const points = runs.filter(r => scoreValue(r) !== null).slice(-30);
  if (!points.length) {
    chart.innerHTML = `<div class="empty-state"><strong>No score history in this scope</strong><span>Completed evaluations will appear here.</span></div>`;
    meta.textContent = "";
    return;
  }
  if (points.length === 1) {
    const score = scoreValue(points[0]);
    chart.innerHTML = `<div class="single-point-chart"><span class="single-point" style="bottom:${Math.max(8, Math.min(92, score * 100))}%"></span><span class="single-point-label">${CTNA.formatPercent(score)}</span></div>`;
    meta.innerHTML = `<span>1 evaluation</span><span>${escape(formatDate(points[0].creation_ts))}</span>`;
    return;
  }
  const width = 900, height = 260, pad = { l: 52, r: 22, t: 18, b: 42 };
  const min = Math.max(0, Math.min(...points.map(r => scoreValue(r))) - 0.02);
  const max = Math.min(1, Math.max(...points.map(r => scoreValue(r))) + 0.02);
  const range = Math.max(max - min, 0.04);
  const x = i => pad.l + (i / (points.length - 1)) * (width - pad.l - pad.r);
  const y = v => pad.t + ((max - v) / range) * (height - pad.t - pad.b);
  const path = points.map((r,i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(scoreValue(r)).toFixed(1)}`).join(" ");
  const area = `${path} L ${x(points.length-1).toFixed(1)},${height-pad.b} L ${x(0).toFixed(1)},${height-pad.b} Z`;
  const ticks = [min, (min+max)/2, max];
  chart.innerHTML = `<svg class="trend-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Score trend over ${points.length} evaluations">
    ${ticks.map(v => `<line x1="${pad.l}" x2="${width-pad.r}" y1="${y(v)}" y2="${y(v)}" class="trend-gridline"/><text x="10" y="${y(v)+4}" class="trend-axis">${CTNA.formatPercent(v)}</text>`).join("")}
    <path d="${area}" class="trend-area"></path><path d="${path}" class="trend-line"></path>
    ${points.map((r,i) => `<circle cx="${x(i)}" cy="${y(scoreValue(r))}" r="4" class="trend-point"><title>${CTNA.formatPercent(scoreValue(r))} · ${formatDate(r.creation_ts)}</title></circle>`).join("")}
    <text x="${pad.l}" y="${height-10}" class="trend-axis">${escape(new Date(points[0].creation_ts).toLocaleDateString(undefined,{month:'short',day:'numeric'}))}</text>
    <text x="${width-pad.r}" y="${height-10}" text-anchor="end" class="trend-axis">${escape(new Date(points.at(-1).creation_ts).toLocaleDateString(undefined,{month:'short',day:'numeric'}))}</text>
  </svg>`;
  const latest = scoreValue(points.at(-1)), first = scoreValue(points[0]);
  const movement = latest - first;
  meta.innerHTML = `<span><strong>${points.length}</strong> evaluations</span><span>Latest <strong>${CTNA.formatPercent(latest)}</strong></span><span class="${movement > 0 ? "delta-pos" : movement < 0 ? "delta-neg" : "delta-flat"}">${movement > 0 ? "↑" : movement < 0 ? "↓" : "→"} ${CTNA.formatDeltaPts(movement)} since first shown</span>`;
}

function renderHistory(runs, totalInScope) {
  const tbody = $("#runs tbody");
  const count = $("#history-count");
  if (count) count.textContent = `${runs.length} shown · ${totalInScope} in current scope`;
  if (!runs.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="empty"><div class="empty-state table-empty"><strong>No evaluations match these filters</strong><span>Clear a filter or change the search term.</span><button type="button" class="button-secondary inline-empty-action" id="clear-run-filters">Clear filters</button></div></td></tr>`;
    $("#clear-run-filters")?.addEventListener("click", clearRunFilters);
    return;
  }
  const rows = [...runs].sort((a,b) => new Date(b.creation_ts) - new Date(a.creation_ts));
  tbody.innerHTML = rows.map(r => {
    const delta = deltaValue(r);
    const status = isPassingStatus(r.status);
    return `<tr data-id="${escape(r.run_id)}">
      <td data-label="Run"><span class="run-link mono">${escape(r.run_id.slice(0,8))}</span></td>
      <td data-label="Agent">${escape(r.agent_id)}</td>
      <td data-label="Dataset">${escape(r.dataset_version || "–")}</td>
      <td data-label="Score"><strong class="table-score">${scoreValue(r) === null ? "–" : CTNA.formatPercent(scoreValue(r))}</strong></td>
      <td data-label="Cases">${escape(runCases(r))}</td>
      <td data-label="Versus baseline" class="${delta < 0 ? "delta-neg" : delta > 0 ? "delta-pos" : "delta-flat"}">${delta === null ? "No comparison" : CTNA.formatDeltaPts(delta)}</td>
      <td data-label="Outcome"><span class="status-label ${status ? "pass" : "fail"}">${status ? "Pass" : "Fail"}</span></td>
      <td data-label="Date">${escape(formatDate(r.creation_ts))}</td>
    </tr>`;
  }).join("");
  tbody.querySelectorAll("tr[data-id]").forEach(tr => tr.addEventListener("click", () => location.href = `run_detail.html?run=${encodeURIComponent(tr.dataset.id)}`));
}

function clearRunFilters() {
  $("#run-search").value = "";
  const agent = $("#agent");
  if (agent) {
    agent.value = "__all__";
    agent._ctnaCombobox?.sync();
    updateAgentScope();
  }
  $("#time-filter").value = "30";
  _activeQuickFilter = "all";
  $("#run-filter-chips")?.querySelectorAll(".filter-chip").forEach(b => b.classList.toggle("active", b.dataset.filter === "all"));
  applyDashboardFilters();
}

function focusRegressions() {
  _activeQuickFilter = "regressed";
  $("#run-filter-chips")?.querySelectorAll(".filter-chip").forEach(b => b.classList.toggle("active", b.dataset.filter === "regressed"));
  $("#history-title")?.scrollIntoView({ behavior: "smooth", block: "start" });
  applyDashboardFilters();
}

function startEvaluation() {
  const agent = $("#agent")?.value;
  const reps = Number($("#reps")?.value) || 1;
  if (!agent || agent === "__all__") {
    focusAgentPicker();
    return;
  }
  location.href = `run.html?agent=${encodeURIComponent(agent)}&reps=${reps}`;
}

function focusAgentPicker() {
  const combobox = $("#agent")?._ctnaCombobox;
  if (combobox) { combobox.input.focus(); } else { $("#agent")?.focus(); }
}

$("#run")?.addEventListener("click", startEvaluation);
$("#hero-run")?.addEventListener("click", () => $("#run")?.click());
$("#view-regressions")?.addEventListener("click", focusRegressions);
$("#run-search")?.addEventListener("input", applyDashboardFilters);
$("#agent")?.addEventListener("change", () => { updateAgentScope(); applyDashboardFilters(); });
$("#time-filter")?.addEventListener("change", applyDashboardFilters);
$("#run-filter-chips")?.querySelectorAll(".filter-chip").forEach(btn => btn.addEventListener("click", () => {
  _activeQuickFilter = btn.dataset.filter;
  $("#run-filter-chips").querySelectorAll(".filter-chip").forEach(b => b.classList.toggle("active", b === btn));
  applyDashboardFilters();
}));

loadHealth();
loadAgents().then(loadRuns);
