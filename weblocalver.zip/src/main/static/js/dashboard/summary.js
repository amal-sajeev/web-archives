// Dashboard summary: stat cards, latest evaluation, baseline context, needs-attention list.

import { formatPercent, formatChange, deltaClass, isPassingStatus, statusKind, statusLabel } from "../lib/format.js";
import { escapeHtml, changeHtml } from "../lib/fragments.js";
import {
  scoreValue, deltaValue, runCases, isRegression, needsReview, formatDate, shortId, runHref, plural, runTime,
} from "./data.js";

const $ = (sel) => document.querySelector(sel);
const SKELETON = '<span class="skeleton skeleton-text" aria-hidden="true">&nbsp;</span>';
const STAT_VALUE_IDS = ["#dash-avg-score", "#dash-pass-count", "#dash-regressions", "#dash-review-count"];
const PILL_BY_KIND = { pass: "ok", fail: "bad", error: "warn", cancelled: "" };
const TREND_BY_SIGN = { 1: "positive", "-1": "negative", 0: "flat" };
const NO_COMPARISON = "No comparison";
const MAX_ATTENTION = 5;

function setText(sel, text) {
  const el = $(sel);
  if (el) el.textContent = text;
}

function scoreText(run) {
  return formatPercent(scoreValue(run));
}

export function renderSummaryLoading() {
  for (const id of STAT_VALUE_IDS) $(id).innerHTML = SKELETON;
  $("#latest-evaluation").innerHTML = `${SKELETON}${SKELETON}${SKELETON}`;
  $("#baseline-context").innerHTML = `${SKELETON}${SKELETON}`;
  $("#attention-list").innerHTML = SKELETON;
}

/** Latest run versus the previous run of the same agent (not across agents). */
function latestMovement(ordered) {
  const latest = ordered.at(-1);
  if (!latest || scoreValue(latest) === null) return null;
  const prior = ordered.slice(0, -1).reverse().find((r) => r.agent_id === latest.agent_id && scoreValue(r) !== null);
  return prior ? scoreValue(latest) - scoreValue(prior) : null;
}

function renderScoreCard(runs, ordered) {
  const scored = runs.map(scoreValue).filter((v) => v !== null);
  const avg = scored.length ? scored.reduce((a, b) => a + b, 0) / scored.length : null;
  setText("#dash-avg-score", formatPercent(avg));
  setText("#dash-score-copy", scored.length ? `Mean across ${plural(scored.length, "completed evaluation")}` : "No completed evaluations in this scope");
  const movement = latestMovement(ordered);
  const trend = $("#dash-score-delta");
  trend.textContent = movement === null ? "" : `Vs previous run: ${formatChange(movement, scoreValue(ordered.at(-1)))}`;
  trend.title = movement === null ? "" : "Latest run compared with the previous run of the same agent";
  const sign = movement === null ? "" : TREND_BY_SIGN[Math.sign(Math.round(movement * 10000))];
  trend.className = `stat-trend stat-trend-line ${sign}`;
}

function renderPassCard(runs) {
  const counts = { pass: 0, fail: 0, error: 0, cancelled: 0 };
  for (const r of runs) counts[statusKind(r.status)] += 1;
  setText("#dash-pass-count", runs.length ? `${counts.pass}/${runs.length}` : "–");
  setText("#dash-pass-rate", runs.length ? formatPercent(counts.pass / runs.length) : "–");
  const notPassed = [];
  if (counts.fail) notPassed.push(`${counts.fail} failed`);
  if (counts.error) notPassed.push(`${counts.error} errored`);
  let copy = "No completed evaluations";
  if (runs.length) copy = notPassed.length ? notPassed.join(" · ") : "All evaluations passed";
  setText("#dash-pass-copy", copy);
}

function renderReviewCards(runs) {
  const regressions = runs.filter(isRegression).length;
  const reviews = runs.filter(needsReview).length;
  setText("#dash-regressions", String(regressions));
  setText("#dash-regression-copy", regressions ? `${plural(regressions, "run")} below baseline` : "No baseline regressions");
  setText("#dash-review-count", String(reviews));
  setText("#dash-review-copy", reviews ? `${plural(reviews, "run")} not passed or regressed` : "No runs require review");
}

export function renderStats(runs, ordered) {
  renderScoreCard(runs, ordered);
  renderPassCard(runs);
  renderReviewCards(runs);
}

function statusIcon(run) {
  const passing = isPassingStatus(run.status);
  const kind = passing ? "pass" : "fail";
  return `<span class="status-icon ${kind}" aria-hidden="true">${passing ? "✓" : "!"}</span>`;
}

function statusPill(run) {
  const cls = PILL_BY_KIND[statusKind(run.status)];
  return `<span class="pill ${cls}">${escapeHtml(statusLabel(run.status))}</span>`;
}

export function renderLatest(run) {
  const el = $("#latest-evaluation");
  const link = $("#latest-open");
  link.hidden = !run;
  if (!run) {
    link.removeAttribute("href");
    el.innerHTML = `<div class="empty-state compact"><strong>No completed evaluation in this scope</strong>
      <span>Start an evaluation to populate the dashboard.</span>
      <button type="button" class="button-secondary inline-empty-action" data-action="start">Start evaluation</button></div>`;
    return;
  }
  link.href = runHref(run.run_id);
  const delta = deltaValue(run);
  const baselineText = delta === null ? NO_COMPARISON : formatChange(delta, scoreValue(run));
  el.innerHTML = `
    <div class="latest-main">
      <div class="latest-status-line">${statusIcon(run)}${statusPill(run)}</div>
      <div class="latest-score">${escapeHtml(scoreText(run))}</div>
      <div class="latest-agent">${escapeHtml(run.agent_id)} <span>·</span> <span>${escapeHtml(run.dataset_version || "")}</span></div>
    </div>
    <div class="latest-meta">
      <div><span>Cases passed</span><strong>${escapeHtml(runCases(run))}</strong></div>
      <div><span>Baseline</span><strong class="${deltaClass(delta)}">${escapeHtml(baselineText)}</strong></div>
      <div><span>Evaluated</span><strong>${escapeHtml(formatDate(run.creation_ts))}</strong></div>
    </div>`;
}

function baselineDeltaText(delta, score) {
  if (delta === null) return NO_COMPARISON;
  return formatChange(delta, score);
}

export function renderBaselineContext(run) {
  const el = $("#baseline-context");
  if (!run) {
    el.innerHTML = `<div class="baseline-empty"><strong>No baseline comparison yet</strong>
      <span>Run an evaluation to establish a comparison point.</span></div>`;
    return;
  }
  const score = scoreValue(run);
  const delta = deltaValue(run);
  const baselineScore = score !== null && delta !== null ? score - delta : null;
  const trend = TREND_BY_SIGN[Math.sign(Math.round((delta ?? 0) * 10000))];
  el.innerHTML = `
    <div class="baseline-score-row">
      <div><span class="baseline-label">Comparison baseline</span><strong>${baselineScore === null ? "Not available" : formatPercent(baselineScore)}</strong></div>
      <div class="baseline-delta ${trend}">${escapeHtml(baselineDeltaText(delta, score))}</div>
    </div>
    <div class="baseline-detail-grid">
      <div><span>Agent</span><strong class="baseline-agent-name">${escapeHtml(run.agent_id)}</strong></div>
      <div><span>Dataset</span><strong>${escapeHtml(run.dataset_version || "–")}</strong></div>
      <div><span>Latest score</span><strong>${escapeHtml(scoreText(run))}</strong></div>
    </div>
    <a class="text-link" href="${runHref(run.run_id)}">Inspect baseline movement →</a>`;
}

function attentionOrder(a, b) {
  const af = isPassingStatus(a.status) ? 0 : 1;
  const bf = isPassingStatus(b.status) ? 0 : 1;
  if (af !== bf) return bf - af;
  const byDelta = (deltaValue(a) ?? 0) - (deltaValue(b) ?? 0);
  return byDelta || runTime(b) - runTime(a);
}

function attentionItem(run) {
  const fail = !isPassingStatus(run.status);
  const reason = fail ? `Outcome: ${statusLabel(run.status)}` : "Below comparison baseline";
  return `<a class="attention-item" href="${runHref(run.run_id)}">
      <span class="attention-icon ${fail ? "fail" : "warn"}" aria-hidden="true">${fail ? "!" : "↓"}</span>
      <span class="attention-copy"><strong>${escapeHtml(run.agent_id)} <span class="attention-run">${escapeHtml(shortId(run.run_id))}</span></strong>
        <span>${escapeHtml(reason)} · ${escapeHtml(formatDate(run.creation_ts))}</span></span>
      <span class="attention-score">${escapeHtml(scoreText(run))}<small>${changeHtml(deltaValue(run), scoreValue(run))}</small></span>
      <span class="attention-arrow" aria-hidden="true">→</span>
    </a>`;
}

export function renderAttention(runs) {
  const list = $("#attention-list");
  const attention = runs.filter(needsReview).sort(attentionOrder).slice(0, MAX_ATTENTION);
  $("#view-regressions").hidden = !runs.some(isRegression);
  if (!attention.length) {
    list.innerHTML = `<div class="attention-empty"><span class="attention-check" aria-hidden="true">✓</span><div>
      <strong>No evaluations require attention</strong>
      <span>All completed runs in this scope passed without a baseline regression.</span></div></div>`;
    return;
  }
  list.innerHTML = attention.map(attentionItem).join("");
}
