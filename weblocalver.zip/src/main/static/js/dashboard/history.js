// Evaluation history table: rows with real report links, quick-filter chips, loading/empty states.

import { formatPercent, deltaClass, changeLabel } from "../lib/format.js";
import { escapeHtml, statusLabelHtml } from "../lib/fragments.js";
import { scoreValue, deltaValue, runCases, formatDate, shortId, runHref, newestFirst } from "./data.js";

const COLUMNS = 8;
const SKELETON_ROWS = 6;
const CHIP_SELECTOR = "#run-filter-chips .filter-chip";

function tbody() {
  return document.querySelector("#runs tbody");
}

function setCount(text) {
  const count = document.getElementById("history-count");
  if (count) count.textContent = text;
}

function rowHtml(run) {
  const delta = deltaValue(run);
  const id = escapeHtml(run.run_id);
  return `<tr class="clickable-row" data-href="${runHref(run.run_id)}">
      <td data-label="Run"><a class="run-link mono" href="${runHref(run.run_id)}" title="${id}">${escapeHtml(shortId(run.run_id))}</a></td>
      <td data-label="Agent">${escapeHtml(run.agent_id)}</td>
      <td data-label="Dataset">${escapeHtml(run.dataset_version || "–")}</td>
      <td data-label="Score"><strong class="table-score">${escapeHtml(formatPercent(scoreValue(run)))}</strong></td>
      <td data-label="Cases passed">${escapeHtml(runCases(run))}</td>
      <td data-label="Versus baseline" class="${deltaClass(delta)}">${escapeHtml(changeLabel(delta, scoreValue(run)))}</td>
      <td data-label="Outcome">${statusLabelHtml(run.status)}</td>
      <td data-label="Date">${escapeHtml(formatDate(run.creation_ts))}</td>
    </tr>`;
}

function emptyRow(title, message, withClear) {
  const action = withClear
    ? '<button type="button" class="button-secondary inline-empty-action" data-action="clear-filters">Clear filters</button>'
    : "";
  return `<tr><td colspan="${COLUMNS}" class="empty"><div class="empty-state table-empty">
    <strong>${escapeHtml(title)}</strong><span>${escapeHtml(message)}</span>${action}</div></td></tr>`;
}

/** `runs` = filtered rows; `totalInScope` = rows before search/quick filters. */
export function renderHistory(runs, totalInScope) {
  const body = tbody();
  body.closest("table").removeAttribute("aria-busy");
  setCount(`${runs.length} shown · ${totalInScope} in current scope`);
  if (!runs.length) {
    body.innerHTML = emptyRow("No evaluations match these filters", "Clear a filter or change the search term.", true);
    return;
  }
  body.innerHTML = newestFirst(runs).map(rowHtml).join("");
}

export function renderHistoryLoading() {
  const body = tbody();
  body.closest("table").setAttribute("aria-busy", "true");
  setCount("Loading evaluation history…");
  const cell = '<td><span class="skeleton skeleton-text" aria-hidden="true">&nbsp;</span></td>';
  body.innerHTML = Array.from({ length: SKELETON_ROWS }, () => `<tr class="skeleton-row">${cell.repeat(COLUMNS)}</tr>`).join("");
}

export function renderHistoryError(message) {
  const body = tbody();
  body.closest("table").removeAttribute("aria-busy");
  setCount("Unable to load evaluation history.");
  body.innerHTML = emptyRow("Evaluation history is unavailable", message, false);
}

/** Whole-row click as an enhancement; the first-cell <a> is the keyboard path. */
export function wireRowClicks(onClearFilters) {
  tbody().addEventListener("click", (event) => {
    if (event.target.closest("[data-action='clear-filters']")) {
      onClearFilters();
      return;
    }
    if (event.target.closest("a, button")) return;
    const row = event.target.closest("tr[data-href]");
    if (!row || window.getSelection()?.toString()) return;
    location.href = row.dataset.href;
  });
}

/** Marks one chip active (class + aria-pressed). */
export function setActiveChip(filter) {
  for (const chip of document.querySelectorAll(CHIP_SELECTOR)) {
    const active = chip.dataset.filter === filter;
    chip.classList.toggle("active", active);
    chip.setAttribute("aria-pressed", String(active));
  }
}

export function wireChips(onSelect) {
  for (const chip of document.querySelectorAll(CHIP_SELECTOR)) {
    chip.addEventListener("click", () => onSelect(chip.dataset.filter));
  }
}
