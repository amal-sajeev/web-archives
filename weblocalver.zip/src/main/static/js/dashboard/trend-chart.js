// Score trend chart (inline SVG, styled by classes in css/pages/dashboard.css).

import { formatPercent, formatChange, deltaClass } from "../lib/format.js";
import { escapeHtml } from "../lib/fragments.js";
import { scoreValue, formatDate } from "./data.js";

const MAX_POINTS = 30;
const WIDTH = 900;
const HEIGHT = 260;
const PAD = { l: 52, r: 22, t: 18, b: 42 };
const SHORT_DATE = { month: "short", day: "numeric" };
const TREND_ARROWS = { 1: "↑", "-1": "↓", 0: "→" };

function shortDate(run) {
  return new Date(run.creation_ts).toLocaleDateString(undefined, SHORT_DATE);
}

function svgOpen(label) {
  return `<svg class="trend-svg" viewBox="0 0 ${WIDTH} ${HEIGHT}" role="img" aria-label="${escapeHtml(label)}">`;
}

function emptyChart() {
  return `<div class="empty-state"><strong>No score history in this scope</strong>
    <span>Completed evaluations will appear here.</span></div>`;
}

/** One run: a single dot positioned with SVG attributes (no inline style). */
function singlePointChart(run) {
  const score = scoreValue(run);
  const plotH = HEIGHT - PAD.t - PAD.b;
  const cy = PAD.t + (1 - Math.max(0, Math.min(1, score))) * plotH;
  const cx = WIDTH / 2;
  const label = formatPercent(score);
  return `${svgOpen(`Score ${label} from 1 evaluation`)}
    <line x1="${PAD.l}" x2="${WIDTH - PAD.r}" y1="${HEIGHT - PAD.b}" y2="${HEIGHT - PAD.b}" class="trend-gridline"/>
    <circle cx="${cx}" cy="${cy.toFixed(1)}" r="14" class="trend-halo"/>
    <circle cx="${cx}" cy="${cy.toFixed(1)}" r="7" class="trend-dot"><title>${escapeHtml(`${label} · ${formatDate(run.creation_ts)}`)}</title></circle>
    <text x="${cx + 20}" y="${(cy + 5).toFixed(1)}" class="trend-point-label">${escapeHtml(label)}</text>
  </svg>`;
}

function scales(points) {
  const values = points.map(scoreValue);
  const min = Math.max(0, Math.min(...values) - 0.02);
  const max = Math.min(1, Math.max(...values) + 0.02);
  const range = Math.max(max - min, 0.04);
  const x = (i) => PAD.l + (i / (points.length - 1)) * (WIDTH - PAD.l - PAD.r);
  const y = (v) => PAD.t + ((max - v) / range) * (HEIGHT - PAD.t - PAD.b);
  return { min, max, x, y };
}

function gridLines({ min, max, y }) {
  return [min, (min + max) / 2, max].map((v) => {
    const yy = y(v).toFixed(1);
    return `<line x1="${PAD.l}" x2="${WIDTH - PAD.r}" y1="${yy}" y2="${yy}" class="trend-gridline"/>
      <text x="10" y="${(y(v) + 4).toFixed(1)}" class="trend-axis">${escapeHtml(formatPercent(v))}</text>`;
  }).join("");
}

function lineChart(points) {
  const s = scales(points);
  const coords = points.map((r, i) => [s.x(i).toFixed(1), s.y(scoreValue(r)).toFixed(1)]);
  const path = coords.map(([cx, cy], i) => `${i ? "L" : "M"}${cx},${cy}`).join(" ");
  const base = HEIGHT - PAD.b;
  const area = `${path} L ${coords.at(-1)[0]},${base} L ${coords[0][0]},${base} Z`;
  const dots = points.map((r, i) => {
    const title = `${formatPercent(scoreValue(r))} · ${r.agent_id} · ${formatDate(r.creation_ts)}`;
    return `<circle cx="${coords[i][0]}" cy="${coords[i][1]}" r="4" class="trend-point"><title>${escapeHtml(title)}</title></circle>`;
  }).join("");
  return `${svgOpen(`Score trend over ${points.length} evaluations`)}
    ${gridLines(s)}
    <path d="${area}" class="trend-area"></path><path d="${path}" class="trend-line"></path>
    ${dots}
    <text x="${PAD.l}" y="${HEIGHT - 10}" class="trend-axis">${escapeHtml(shortDate(points[0]))}</text>
    <text x="${WIDTH - PAD.r}" y="${HEIGHT - 10}" text-anchor="end" class="trend-axis">${escapeHtml(shortDate(points.at(-1)))}</text>
  </svg>`;
}

function trendMeta(points) {
  const latest = scoreValue(points.at(-1));
  if (points.length === 1) {
    return `<span>1 evaluation</span><span>${escapeHtml(formatDate(points[0].creation_ts))}</span>`;
  }
  const movement = latest - scoreValue(points[0]);
  const arrow = TREND_ARROWS[Math.sign(Math.round(movement * 10000))];
  return `<span><strong>${points.length}</strong> most recent evaluations</span>
    <span>Latest <strong>${escapeHtml(formatPercent(latest))}</strong></span>
    <span class="${deltaClass(movement)}">${arrow} ${escapeHtml(formatChange(movement, latest))} since first shown</span>`;
}

/** `ordered` is oldest-first; the last MAX_POINTS scored runs are plotted. */
export function renderTrendChart(ordered) {
  const chart = document.getElementById("trend-chart");
  const meta = document.getElementById("trend-meta");
  const points = ordered.filter((r) => scoreValue(r) !== null).slice(-MAX_POINTS);
  chart.removeAttribute("aria-busy");
  if (!points.length) {
    chart.innerHTML = emptyChart();
    meta.textContent = "";
    return;
  }
  chart.innerHTML = points.length === 1 ? singlePointChart(points[0]) : lineChart(points);
  meta.innerHTML = trendMeta(points);
}

export function renderTrendLoading() {
  const chart = document.getElementById("trend-chart");
  chart.setAttribute("aria-busy", "true");
  chart.innerHTML = '<span class="skeleton skeleton-block trend-skeleton" aria-hidden="true"></span>';
  document.getElementById("trend-meta").textContent = "";
}
