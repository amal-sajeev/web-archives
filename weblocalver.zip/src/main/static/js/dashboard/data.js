// Dashboard data: API loads (with cursor pagination) and pure run helpers/filters.

import { fetchJson } from "../lib/api.js";
import { isPassingStatus, statusKind } from "../lib/format.js";

export const PAGE_SIZE = 200;
export const MAX_RUNS = 2000;
export const LOW_SCORE = 0.9;
export const ALL_AGENTS = "__all__";
const DAY_MS = 86400000;
const EPSILON = 0.000001;
const DATE_FORMAT = { dateStyle: "medium", timeStyle: "short" };
const MISSING = "–";

export function loadHealth() {
  return fetchJson("api/health");
}

export async function loadAgents() {
  const data = await fetchJson("api/agents");
  return Array.isArray(data?.agents) ? data.agents : [];
}

function runsPageUrl(cursor) {
  const params = new URLSearchParams({ limit: String(PAGE_SIZE) });
  if (cursor) params.set("before", cursor);
  return `api/runs?${params}`;
}

/** Follows next_cursor until exhausted or MAX_RUNS is reached. */
export async function loadAllRuns() {
  const runs = [];
  let cursor = null;
  do {
    const page = await fetchJson(runsPageUrl(cursor));
    if (Array.isArray(page?.runs)) runs.push(...page.runs);
    cursor = page?.next_cursor || null;
  } while (cursor && runs.length < MAX_RUNS);
  return { runs: runs.slice(0, MAX_RUNS), capped: Boolean(cursor) };
}

// ---------- Run helpers ----------

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

/** ERROR runs did not complete: their 0 score / 0 delta are placeholders, not results. */
export function isCompleted(run) {
  return statusKind(run?.status) !== "error";
}

export function scoreValue(run) {
  return isCompleted(run) ? finiteOrNull(run?.weighted_score) : null;
}

export function deltaValue(run) {
  return isCompleted(run) ? finiteOrNull(run?.weighted_delta) : null;
}

export function runCases(run) {
  const total = finiteOrNull(run?.case_count);
  const passed = finiteOrNull(run?.passed_case_count);
  if (total === null || passed === null) return MISSING;
  return `${passed}/${total}`;
}

export function isRegression(run) {
  const d = deltaValue(run);
  return d !== null && d < -EPSILON;
}

export function isImprovement(run) {
  const d = deltaValue(run);
  return d !== null && d > EPSILON;
}

export function needsReview(run) {
  return !isPassingStatus(run?.status) || isRegression(run);
}

export function runTime(run) {
  const t = Date.parse(run?.creation_ts);
  return Number.isFinite(t) ? t : 0;
}

export function oldestFirst(runs) {
  return [...runs].sort((a, b) => runTime(a) - runTime(b));
}

export function newestFirst(runs) {
  return [...runs].sort((a, b) => runTime(b) - runTime(a));
}

export function formatDate(ts) {
  const date = new Date(ts);
  return Number.isFinite(date.getTime()) ? date.toLocaleString(undefined, DATE_FORMAT) : MISSING;
}

export function shortId(runId) {
  return String(runId ?? "").slice(0, 8);
}

export function runHref(runId) {
  return `run_detail.html?run=${encodeURIComponent(runId)}`;
}

export function plural(n, noun) {
  return `${n} ${noun}${n === 1 ? "" : "s"}`;
}

// ---------- Filters ----------

/** Scope = agent + time window; drives the stats, trend and history base set. */
export function scopeRuns(runs, { agent, days }) {
  const byAgent = agent && agent !== ALL_AGENTS ? runs.filter((r) => r.agent_id === agent) : runs;
  const span = Number(days);
  if (!Number.isFinite(span) || span <= 0) return byAgent;
  const cutoff = Date.now() - span * DAY_MS;
  return byAgent.filter((r) => runTime(r) >= cutoff);
}

export function searchRuns(runs, query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return runs;
  const fields = (r) => [r.run_id, r.agent_id, r.dataset_id, r.dataset_version, r.status];
  return runs.filter((r) => fields(r).some((v) => String(v ?? "").toLowerCase().includes(q)));
}

const QUICK_FILTERS = {
  fail: (r) => !isPassingStatus(r.status),
  regressed: isRegression,
  threshold: (r) => {
    const s = scoreValue(r);
    return s !== null && s < LOW_SCORE;
  },
  improved: isImprovement,
};

export function quickFilterRuns(runs, key) {
  const predicate = QUICK_FILTERS[key];
  return predicate ? runs.filter(predicate) : runs;
}
