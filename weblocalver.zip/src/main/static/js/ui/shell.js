// Shared page shell: theme toggle, TLS pill and the current primary-nav link.
// Importing this module initialises the shell once per document.

import { initThemeToggle } from "./theme.js";
import { initTlsToggle } from "./tls-toggle.js";

function fileName(path) {
  const last = String(path || "").split("/").pop();
  return last || "index.html";
}

/** Sets aria-current="page" on the nav link for this page, or "true" on its
 *  section link (body[data-nav]) for child pages such as run reports. */
export function markCurrentNav(nav = document.querySelector(".primary-nav")) {
  if (!nav) return;
  const here = fileName(location.pathname);
  const section = document.body.dataset.nav || "";
  for (const link of nav.querySelectorAll("a[href]")) {
    const target = fileName(new URL(link.getAttribute("href"), location.href).pathname);
    link.removeAttribute("aria-current");
    if (target === here) link.setAttribute("aria-current", "page");
    else if (section && link.dataset.nav === section) link.setAttribute("aria-current", "true");
  }
}

/** Idempotent across duplicate module instances (guarded on <html>). */
export function initShell() {
  const root = document.documentElement;
  if (root.dataset.shellReady === "true") return;
  root.dataset.shellReady = "true";
  initThemeToggle();
  initTlsToggle();
  markCurrentNav();
}

initShell();
