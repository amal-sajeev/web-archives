// Appearance toggle. The stored choice is written only when the user clicks;
// with no stored choice the page follows the OS preference, live.

export const THEME_KEY = "ctna-theme";
const LIGHT = "light";
const DARK = "dark";
const LIGHT_QUERY = "(prefers-color-scheme: light)";

function readStored() {
  try {
    const value = localStorage.getItem(THEME_KEY);
    return value === LIGHT || value === DARK ? value : null;
  } catch (err) {
    // Storage blocked (private mode / policy): behave as if nothing is stored.
    return null;
  }
}

function writeStored(theme) {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (err) {
    // Storage blocked: the choice still applies for this page view.
  }
}

function osTheme() {
  return window.matchMedia?.(LIGHT_QUERY).matches ? LIGHT : DARK;
}

/** The theme currently in effect: 'light' | 'dark'. */
export function currentTheme() {
  const attr = document.documentElement.getAttribute("data-theme");
  if (attr === LIGHT || attr === DARK) return attr;
  return osTheme();
}

function labelButton(button) {
  if (!button) return;
  const toLight = currentTheme() !== LIGHT;
  button.setAttribute("aria-label", toLight ? "Switch to light appearance" : "Switch to dark appearance");
  button.title = toLight ? "Light appearance" : "Dark appearance";
  button.dataset.themeNext = toLight ? LIGHT : DARK;
}

/** Applies a theme; persists it only when `persist` is true. */
export function setTheme(theme, { persist = false } = {}) {
  const next = theme === LIGHT ? LIGHT : DARK;
  document.documentElement.setAttribute("data-theme", next);
  if (persist) writeStored(next);
  labelButton(document.getElementById("theme-toggle"));
  document.dispatchEvent(new CustomEvent("theme-changed", { detail: { theme: next } }));
}

/** Wires #theme-toggle (or `button`) and OS-preference tracking. Idempotent. */
export function initThemeToggle(button = document.getElementById("theme-toggle")) {
  if (!button || button.dataset.themeReady === "true") return;
  button.dataset.themeReady = "true";
  labelButton(button);
  button.addEventListener("click", () => {
    setTheme(currentTheme() === LIGHT ? DARK : LIGHT, { persist: true });
  });
  window.matchMedia?.(LIGHT_QUERY).addEventListener?.("change", () => {
    if (readStored()) return;
    document.documentElement.removeAttribute("data-theme");
    labelButton(button);
  });
}
