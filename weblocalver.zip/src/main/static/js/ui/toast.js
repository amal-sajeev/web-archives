// Non-blocking status toasts and promise-based <dialog> replacements for
// alert / confirm / prompt. All text is set with textContent (never HTML).

const REGION_ID = "toast-region";
const DEFAULT_TIMEOUT = 5000;
const ERROR_TIMEOUT = 8000;
const CANCEL = "cancel";
const CONFIRM = "confirm";
let dialogSeq = 0;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function toastRegion() {
  let region = document.getElementById(REGION_ID);
  if (!region) {
    region = el("div", "toast-region");
    region.id = REGION_ID;
    region.setAttribute("role", "status");
    region.setAttribute("aria-live", "polite");
    document.body.appendChild(region);
  }
  return region;
}

/**
 * Shows a toast. kind: 'info' | 'ok' | 'bad' | 'warn'. timeout 0 keeps it until dismissed.
 * @returns {() => void} dismiss function
 */
export function showToast(message, { kind = "info", timeout } = {}) {
  const toast = el("div", `toast ${kind}`);
  if (kind === "bad") toast.setAttribute("role", "alert");
  toast.appendChild(el("span", "toast-message", String(message ?? "")));
  const close = el("button", "toast-close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Dismiss notification");
  toast.appendChild(close);
  const dismiss = () => toast.remove();
  close.addEventListener("click", dismiss);
  toastRegion().appendChild(toast);
  const ms = timeout ?? (kind === "bad" ? ERROR_TIMEOUT : DEFAULT_TIMEOUT);
  if (ms > 0) window.setTimeout(dismiss, ms);
  return dismiss;
}

/** Shorthand for an error toast from an Error or string. */
export function showError(err) {
  return showToast(err?.message || String(err || "Something went wrong."), { kind: "bad" });
}

function buildDialog({ title, message, confirmLabel, cancelLabel, danger }) {
  const dialog = el("dialog", "app-dialog");
  const form = el("form");
  form.method = "dialog";
  const heading = el("h2", "", title);
  dialogSeq += 1;
  heading.id = `app-dialog-title-${dialogSeq}`;
  dialog.setAttribute("aria-labelledby", heading.id);
  form.appendChild(heading);
  if (message) form.appendChild(el("p", "", message));
  const actions = el("div", "dialog-actions");
  const cancel = el("button", "button-secondary", cancelLabel);
  cancel.type = "submit";
  cancel.value = CANCEL;
  const ok = el("button", danger ? "button-danger" : "", confirmLabel);
  ok.type = "submit";
  ok.value = CONFIRM;
  actions.append(cancel, ok);
  form.appendChild(actions);
  dialog.appendChild(form);
  return { dialog, form, actions };
}

function openDialog(dialog, focusTarget, readResult) {
  return new Promise((resolve) => {
    dialog.addEventListener("close", () => {
      const result = readResult(dialog.returnValue === CONFIRM);
      dialog.remove();
      resolve(result);
    }, { once: true });
    document.body.appendChild(dialog);
    dialog.showModal();
    focusTarget?.focus();
    if (typeof focusTarget?.select === "function") focusTarget.select();
  });
}

/** Resolves true when confirmed, false when cancelled or dismissed with Esc. */
export function confirmDialog({
  title = "Are you sure?", message = "", confirmLabel = "Confirm", cancelLabel = "Cancel", danger = false,
} = {}) {
  const { dialog } = buildDialog({ title, message, confirmLabel, cancelLabel, danger });
  const cancelButton = dialog.querySelector(`button[value="${CANCEL}"]`);
  return openDialog(dialog, cancelButton, (confirmed) => confirmed);
}

/** Resolves the entered string when confirmed, or null when cancelled. */
export function promptDialog({
  title = "Enter a value", message = "", label = "Value", value = "", confirmLabel = "OK", cancelLabel = "Cancel",
} = {}) {
  const { dialog, form, actions } = buildDialog({ title, message, confirmLabel, cancelLabel, danger: false });
  const field = el("label", "dialog-field");
  field.appendChild(el("span", "", label));
  const input = el("input");
  input.type = "text";
  input.value = value;
  input.autocomplete = "off";
  input.spellcheck = false;
  field.appendChild(input);
  form.insertBefore(field, actions);
  input.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    dialog.close(CONFIRM);
  });
  return openDialog(dialog, input, (confirmed) => (confirmed ? input.value : null));
}
