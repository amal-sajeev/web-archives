// Header TLS pill: shows and flips outbound TLS certificate verification.
// Dispatches `tls-changed` on document with detail {excludeTls, verify} after a change.

import { fetchJson, postJson } from "../lib/api.js";
import { showError } from "./toast.js";

const SETTINGS_URL = "api/settings";
const TLS_URL = "api/settings/tls";
const UPDATE_FAILED = "Unable to update TLS setting.";

function render(toggle, excludeTls) {
  const verify = !excludeTls;
  toggle.dataset.enabled = String(verify);
  toggle.classList.toggle("off", excludeTls);
  toggle.setAttribute("aria-pressed", String(verify));
  toggle.textContent = verify ? "TLS: Verify" : "TLS: Disabled";
  toggle.title = verify
    ? "TLS verification is enabled for outbound HTTPS calls. Select to disable."
    : "TLS verification is disabled for outbound HTTPS calls. Select to enable.";
  toggle.disabled = false;
}

async function refresh(toggle) {
  try {
    const cfg = await fetchJson(SETTINGS_URL);
    render(toggle, Boolean(cfg?.exclude_tls));
  } catch (err) {
    // Settings endpoint unavailable: assume the safe default (verification on).
    render(toggle, false);
  }
}

async function flip(toggle) {
  const enable = toggle.dataset.enabled !== "true";
  toggle.disabled = true;
  try {
    const data = await postJson(TLS_URL, { enabled: enable });
    const excludeTls = Boolean(data?.exclude_tls);
    render(toggle, excludeTls);
    document.dispatchEvent(new CustomEvent("tls-changed", { detail: { excludeTls, verify: !excludeTls } }));
  } catch (err) {
    toggle.disabled = false;
    showError(err?.message || UPDATE_FAILED);
  }
}

/** Wires #tls-toggle (or `toggle`). Idempotent. */
export function initTlsToggle(toggle = document.getElementById("tls-toggle")) {
  if (!toggle || toggle.dataset.tlsInitialized === "true") return;
  toggle.dataset.tlsInitialized = "true";
  toggle.setAttribute("aria-label", "Verify outbound TLS certificates");
  toggle.addEventListener("click", () => flip(toggle));
  toggle.disabled = true;
  refresh(toggle);
}
