// Live run page entry: starts (or re-attaches to) an evaluation and renders it as events stream in.

import "../ui/shell.js";
import { fetchJson, postJson } from "../lib/api.js";
import { formatPercent, statusKind, STATUS_LABELS } from "../lib/format.js";
import { escapeHtml, scoreRingHtml, stampHtml, changeHtml } from "../lib/fragments.js";
import { showToast, showError, confirmDialog } from "../ui/toast.js";
import { parseReps } from "../lib/reps.js";
import { openRunStream } from "./stream.js";
import { renderErrorPanel, renderCancelledPanel } from "./error.js";
import {
  setProgress, renderRunStarted, renderCaseStarted, renderObservation, renderMetricStarted,
  renderMetricDone, renderMetricSkipped, renderCaseDone, settleRunningCases,
} from "./render.js";

const $ = (sel) => document.querySelector(sel);
const params = new URLSearchParams(location.search);
const APP_NAME = "CTNA Evaluation Service";
const CANCELLED_DETAIL = "cancelled";
const CANCEL_BUTTON = "#cancel-run";
const CANCELLING = "Cancelling…";
const PILL_BY_KIND = { pass: "ok", fail: "bad", error: "warn", cancelled: "" };
const HEADINGS = {
  pass: "Evaluation passed",
  fail: "Evaluation failed",
  error: "Evaluation did not complete",
  cancelled: "Evaluation cancelled",
};
const repsParam = parseReps(params.get("reps") || params.get("judge_repetitions") || 1);
const ctx = {
  agentId: params.get("agent") || params.get("agent_id") || "",
  reps: repsParam.value,
  streamId: params.get("stream") || "",
  runId: null,
  finished: false,
  kind: null,
  runErrorDetail: null,
};

function setPill(text, cls) {
  const pill = $("#run-pill");
  pill.textContent = text;
  pill.className = `pill ${cls || ""}`.trim();
}

// ---------- Final states ----------

function finish(kind) {
  ctx.finished = true;
  ctx.kind = kind;
  setPill(STATUS_LABELS[kind], PILL_BY_KIND[kind]);
  $("#live-dot").hidden = true;
  $(CANCEL_BUTTON).hidden = true;
  settleRunningCases();
  const heading = HEADINGS[kind];
  $("#summary-title").textContent = heading;
  document.querySelector(".tagline").textContent = heading;
  document.title = `${STATUS_LABELS[kind]} · ${ctx.agentId || "Evaluation"} · ${APP_NAME}`;
  const link = $("#view-detail");
  link.hidden = !ctx.runId;
  if (ctx.runId) link.href = `run_detail.html?run=${encodeURIComponent(ctx.runId)}`;
  $("#final-panel").hidden = false;
}

function renderOutcomePanel(run, kind) {
  const delta = changeHtml(run.weighted_delta, run.weighted_score);
  $("#final-banner").innerHTML = `
    <div class="final ${kind}">
      ${stampHtml(run.status)}
      ${scoreRingHtml(run.weighted_score, 96)}
      <div class="final-copy">
        <div class="final-verdict">${STATUS_LABELS[kind]}</div>
        <div>Overall score <strong>${escapeHtml(formatPercent(run.weighted_score))}</strong>${delta ? ` · ${delta}` : ""}</div>
      </div>
    </div>`;
}

/** A run record (run_done event or GET /api/runs/{id}); ERROR + "cancelled" means cancelled. */
function finishWithRun(run) {
  ctx.runId = run.run_id || ctx.runId;
  if (run.agent_id) ctx.agentId = run.agent_id;
  let kind = statusKind(run.status);
  if (kind === "error" && run.error_detail === CANCELLED_DETAIL) kind = "cancelled";
  finish(kind);
  if (kind === "cancelled") renderCancelledPanel(run.error_detail);
  else if (kind === "error") {
    ctx.runErrorDetail = run.error_detail || null;
    renderErrorPanel({ detail: run.error_detail }, ctx);
  }
  else renderOutcomePanel(run, kind);
}

function finishError(e) {
  if (ctx.finished) return;
  finish("error");
  renderErrorPanel(e, ctx);
}

function finishCancelled(e) {
  finish("cancelled");
  renderCancelledPanel(e.detail);
}

/** Stream ended without a terminal event (e.g. run_done was missed). */
async function onStreamEnd({ runId, sawTerminal }) {
  if (sawTerminal || ctx.finished) return;
  if (!runId) {
    finishError({ detail: "The evaluation finished without reporting a result." });
    return;
  }
  try {
    finishWithRun(await fetchJson(`api/runs/${encodeURIComponent(runId)}`));
  } catch (err) {
    ctx.runId = runId;
    finishError({ status: err.status, detail: `The run finished but its result could not be loaded: ${err.message}` });
  }
}

function onStreamFatal(err, { gone }) {
  const detail = gone
    ? "This live evaluation is no longer available (it may have expired). Check the dashboard for its report."
    : `Progress could not be loaded: ${err.message}`;
  finishError({ status: err.status, detail });
}

// ---------- Events ----------

const HANDLERS = {
  run_started: (e) => {
    renderRunStarted(e);
    if (e.agent_id) ctx.agentId = e.agent_id;
    setPill("Running", "running");
  },
  case_started: renderCaseStarted,
  observation: renderObservation,
  metric_started: renderMetricStarted,
  metric_done: renderMetricDone,
  metric_skipped: renderMetricSkipped,
  case_done: renderCaseDone,
  run_cancel_requested: () => setPill(CANCELLING, "warn"),
  run_done: finishWithRun,
  error: finishError,
  run_cancelled: finishCancelled,
};

/**
 * The server may follow an ERROR run_done with `run_cancelled` or `error` (or send those
 * alone). After the final panel is shown, these only reconcile it: cancelled wording
 * wins, and an `error` event adds its reference (error_id/type) to the run's own detail.
 */
const FOLLOW_UPS = {
  run_cancelled: (e) => {
    if (ctx.kind !== "cancelled") finishCancelled(e);
  },
  error: (e) => {
    if (ctx.kind !== "error") return;
    renderErrorPanel({ ...e, detail: ctx.runErrorDetail || e.detail }, ctx);
  },
};

function onEvent(ev) {
  const handler = ctx.finished ? FOLLOW_UPS[ev.type] : HANDLERS[ev.type];
  if (handler) handler(ev);
}

// ---------- Cancel ----------

async function cancelRun() {
  const ok = await confirmDialog({
    title: "Cancel this evaluation?",
    message: "Cases that have not finished are not scored. The run is recorded as cancelled.",
    confirmLabel: "Cancel evaluation",
    cancelLabel: "Keep running",
    danger: true,
  });
  if (!ok || ctx.finished) return;
  const button = $(CANCEL_BUTTON);
  button.disabled = true;
  try {
    await postJson(`api/evaluate/cancel/${encodeURIComponent(ctx.streamId)}`, {});
    setPill(CANCELLING, "warn");
    button.textContent = CANCELLING;
  } catch (err) {
    button.disabled = false;
    if (err.status === 409) showToast("This evaluation has already finished.", { kind: "info" });
    else showError(err);
  }
}

// ---------- Start ----------

function attach(streamId) {
  ctx.streamId = streamId;
  $(CANCEL_BUTTON).hidden = false;
  setPill("Connecting…", "running");
  openRunStream(streamId, { onEvent, onEnd: onStreamEnd, onFatal: onStreamFatal });
}

async function start() {
  setProgress();
  $(CANCEL_BUTTON).addEventListener("click", cancelRun);
  if (ctx.streamId) {
    attach(ctx.streamId);
    return;
  }
  if (!repsParam.valid) {
    showToast(`Independent assessments adjusted to ${ctx.reps} (allowed range 1–5).`, { kind: "warn" });
  }
  if (!ctx.agentId) {
    finishError({ status: 400, detail: "No agent specified. Return to the dashboard and start an evaluation." });
    return;
  }
  try {
    const data = await postJson("api/evaluate/start", { agent_id: ctx.agentId, judge_repetitions: ctx.reps });
    const url = new URL(location.href);
    url.searchParams.set("stream", data.stream_id);
    history.replaceState(null, "", url);
    attach(data.stream_id);
  } catch (err) {
    finishError({ status: err.status, detail: `The evaluation could not be started: ${err.message}` });
  }
}

start();
