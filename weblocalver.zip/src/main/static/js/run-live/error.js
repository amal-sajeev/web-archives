// Live-run failure states: error panel (readable detail + copyable diagnostics) and cancelled panel.

import { stampHtml, escapeHtml } from "../lib/fragments.js";
import { showToast } from "../ui/toast.js";

const $ = (sel) => document.querySelector(sel);
const FALLBACK_DETAIL = "The evaluation could not be completed.";

function diagnostics(e, context) {
  return {
    when: new Date().toISOString(),
    page_url: location.href,
    agent_id: context.agentId || null,
    reps: context.reps,
    stream_id: context.streamId || null,
    run_id: context.runId || null,
    status: e.status ?? null,
    error_type: e.error_type || null,
    error_id: e.error_id || null,
    detail: e.detail || null,
    raw_event: e,
  };
}

async function copyText(text) {
  if (!navigator.clipboard?.writeText) throw new Error("Clipboard access is not available in this browser.");
  await navigator.clipboard.writeText(text);
}

function wireCopy(button, details) {
  button.addEventListener("click", async () => {
    try {
      await copyText(JSON.stringify(details, null, 2));
      showToast("Error details copied to the clipboard.", { kind: "ok" });
    } catch (err) {
      console.warn("[run error] copy failed", err);
      showToast(`Could not copy error details: ${err.message} They are also in the browser console.`, { kind: "warn" });
    }
  });
}

function referenceLine(e) {
  const bits = [];
  if (e.status) bits.push(`HTTP status ${e.status}`);
  if (e.error_type) bits.push(`type ${e.error_type}`);
  if (e.error_id) bits.push(`reference ${e.error_id}`);
  return bits.length ? `<p class="err-ref muted">${escapeHtml(bits.join(" · "))}</p>` : "";
}

/**
 * Error final panel. `e` = {status?, detail?, error_type?, error_id?} from the `error`
 * event, an ERROR run (error_detail) or a failed request (fetchJson message + status).
 */
export function renderErrorPanel(e, context) {
  const details = diagnostics(e, context);
  console.group("EVALUATION RUN ERROR");
  console.error(details.detail || "run failed");
  console.log(JSON.stringify(details, null, 2));
  console.groupEnd();
  $("#final-banner").innerHTML = `
    <div class="final error">
      ${stampHtml("ERROR")}
      <div class="final-copy">
        <div class="final-verdict">Evaluation did not complete</div>
        <p class="final-detail">${escapeHtml(e.detail || FALLBACK_DETAIL)}</p>
        ${referenceLine(e)}
      </div>
    </div>
    <div class="err-actions">
      <button type="button" id="copy-err" class="button-secondary">Copy error details</button>
      <span class="muted">Full details are also in the browser console (F12).</span>
    </div>`;
  wireCopy($("#copy-err"), details);
}

export function renderCancelledPanel(detail) {
  const text = detail && detail !== "cancelled" ? detail : "The evaluation was cancelled before all cases finished.";
  $("#final-banner").innerHTML = `
    <div class="final cancelled">
      ${stampHtml("CANCELLED")}
      <div class="final-copy">
        <div class="final-verdict">Evaluation cancelled</div>
        <p class="final-detail">${escapeHtml(text)}</p>
      </div>
    </div>`;
}
