// Live-run event stream: SSE first, seq-based polling only after an SSE error.
// Both transports share one cursor (event `seq`), so replayed events are applied once.

import { fetchJson } from "../lib/api.js";
import { statusKind } from "../lib/format.js";

export const TERMINAL_TYPES = new Set(["run_done", "error", "run_cancelled"]);
const POLL_INTERVAL_MS = 1500;
const MAX_POLL_FAILURES = 10;

/** An ERROR run_done may be followed by run_cancelled / error with more detail. */
function awaitsFollowUp(ev) {
  return ev.type === "run_done" && statusKind(ev.status) === "error";
}

function streamUrl(streamId) {
  return `api/evaluate/stream/${encodeURIComponent(streamId)}`;
}

class RunStream {
  constructor(streamId, handlers) {
    this.streamId = streamId;
    this.handlers = handlers;
    this.lastSeq = 0;
    this.seen = new Set();
    this.terminal = false;
    this.ended = false;
    this.source = null;
    this.timer = 0;
    this.failures = 0;
    this.runId = null;
  }

  start() {
    if (typeof EventSource !== "function") {
      this.poll();
      return;
    }
    this.source = new EventSource(streamUrl(this.streamId));
    this.source.onmessage = (msg) => this.onMessage(msg);
    this.source.onerror = () => this.onSseError();
  }

  stop() {
    this.source?.close();
    this.source = null;
    window.clearTimeout(this.timer);
    this.timer = 0;
  }

  close() {
    this.ended = true;
    this.stop();
  }

  end(runId) {
    if (this.ended) return;
    this.close();
    this.handlers.onEnd({ runId: runId || this.runId, sawTerminal: this.terminal });
  }

  isDuplicate(ev) {
    const seq = Number(ev.seq);
    if (!Number.isFinite(seq) || seq <= 0) return false;
    if (this.seen.has(seq)) return true;
    this.seen.add(seq);
    this.lastSeq = Math.max(this.lastSeq, seq);
    return false;
  }

  accept(ev) {
    if (this.ended || !ev?.type || this.isDuplicate(ev)) return;
    this.handlers.onEvent(ev);
    if (!TERMINAL_TYPES.has(ev.type)) return;
    this.terminal = true;
    this.runId = ev.run_id || this.runId;
    // Keep listening after an ERROR run_done until the server finishes the stream;
    // any other terminal event ends it straight away.
    if (!awaitsFollowUp(ev)) this.end(this.runId);
  }

  schedulePoll() {
    if (!this.ended) this.timer = window.setTimeout(() => this.poll(), POLL_INTERVAL_MS);
  }

  pollFailed(err) {
    this.failures += 1;
    const gone = err.status === 404;
    if (gone || this.failures >= MAX_POLL_FAILURES) {
      this.close();
      this.handlers.onFatal(err, { gone });
      return;
    }
    console.warn("[run stream] polling failed; retrying", err);
    this.schedulePoll();
  }

  async poll() {
    if (this.ended) return;
    try {
      const data = await fetchJson(`${streamUrl(this.streamId)}/events?after=${this.lastSeq}`);
      this.failures = 0;
      for (const ev of data?.events || []) this.accept(ev);
      if (this.ended) return;
      if (data?.done) this.end(data.run_id);
      else this.schedulePoll();
    } catch (err) {
      this.pollFailed(err);
    }
  }

  onMessage(msg) {
    let ev;
    try {
      ev = JSON.parse(msg.data);
    } catch (err) {
      console.error("[run stream] could not parse SSE event", err, msg.data);
      return;
    }
    this.accept(ev);
  }

  /** Any SSE error (including the server closing a finished stream) hands over to polling,
   *  which also reports `done` and the run id. */
  onSseError() {
    if (this.ended || !this.source) return;
    this.source.close();
    this.source = null;
    if (!this.terminal) console.warn("[run stream] SSE interrupted; switching to polling");
    this.poll();
  }
}

/**
 * Opens the stream for `streamId`.
 * handlers: onEvent(ev) for every new event; onEnd({runId, sawTerminal}) once the run is
 * over (terminal event, or the server reports it finished without one);
 * onFatal(err, {gone}) when progress can no longer be loaded.
 * Returns {close()}.
 */
export function openRunStream(streamId, handlers) {
  const stream = new RunStream(streamId, handlers);
  stream.start();
  return { close: () => stream.close() };
}
