// Live-run rendering: run meta tiles, progress bar, streaming case cards and criterion chips.

import { formatPercent, formatThreshold, skipReason } from "../lib/format.js";
import { metricInfo } from "../lib/metric-catalog.js";
import { escapeHtml, changeHtml } from "../lib/fragments.js";

const $ = (sel) => document.querySelector(sel);
const state = { total: 0, done: 0, metrics: [], cases: new Map() };
const CHIP_STATE = ".mchip-state";

function plural(n, noun) {
  return `${n} ${noun}${n === 1 ? "" : "s"}`;
}

function finite(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

// ---------- Run meta + progress ----------

export function setProgress() {
  const bar = $("#progress");
  const pct = state.total ? Math.round((state.done / state.total) * 100) : 0;
  $("#progress-bar").style.width = `${pct}%`;
  bar.setAttribute("aria-valuenow", String(pct));
  const text = state.total ? `${state.done} of ${plural(state.total, "case")} complete` : "Starting…";
  bar.setAttribute("aria-valuetext", text);
  $("#progress-text").textContent = text;
}

function concurrencyText(e) {
  const cases = finite(e.case_concurrency);
  if (cases === null || cases <= 1) return "Sequential";
  return `${cases} cases in parallel`;
}

export function renderRunStarted(e) {
  state.total = finite(e.total_cases) ?? 0;
  state.metrics = Array.isArray(e.metrics) ? e.metrics : [];
  $("#m-agent").textContent = e.agent_id ?? "–";
  $("#m-dataset").textContent = `${e.dataset_id ?? "–"} · v${e.dataset_version ?? "?"}`;
  $("#m-cases").textContent = String(state.total);
  const conc = $("#m-conc");
  conc.textContent = concurrencyText(e);
  const judges = finite(e.concurrency);
  conc.title = judges === null ? "" : `Up to ${plural(judges, "model assessment")} at a time`;
  $("#m-reps").textContent = String(e.judge_repetitions ?? "–");
  setProgress();
}

// ---------- Case cards ----------

function chipHtml(m) {
  const info = metricInfo(m.name);
  const badges = [];
  if (m.judge || info.judge) badges.push('<span class="badge badge-judge">Model assessment</span>');
  if (m.critical) badges.push('<span class="badge badge-critical">Mandatory</span>');
  return `<div class="mchip queued" data-metric="${escapeHtml(m.name)}">
      <div class="mchip-top"><span class="mchip-name">${escapeHtml(info.title)}</span>${badges.join(" ")}</div>
      <p class="mchip-blurb">${escapeHtml(info.blurb)}</p>
      <div class="mchip-state"><span class="dot" aria-hidden="true"></span><span class="txt">Queued</span></div>
      <div class="mchip-meter" aria-hidden="true"><span></span></div>
      <div class="mchip-note"></div>
    </div>`;
}

export function renderCaseStarted(e) {
  const wrap = document.createElement("details");
  wrap.className = "live-case running";
  wrap.open = true;
  const index = finite(e.index);
  const position = index === null ? "" : `case ${index + 1} / ${e.total ?? state.total}`;
  wrap.innerHTML = `
    <summary>
      <span class="case-status"><span class="spinner" aria-hidden="true"></span><span class="sr-only">Running</span></span>
      <strong>${escapeHtml(e.case_id)}</strong>
      <span class="muted">${escapeHtml(position)}</span>
      <span class="case-score muted"></span>
    </summary>
    <div class="live-case-body">
      <div class="observation muted">Invoking the agent…</div>
      <div class="metrics-grid">${state.metrics.map(chipHtml).join("")}</div>
    </div>`;
  $("#live-cases").prepend(wrap);
  const chips = new Map();
  wrap.querySelectorAll(".mchip").forEach((el) => chips.set(el.dataset.metric, el));
  state.cases.set(e.case_id, {
    root: wrap,
    obs: wrap.querySelector(".observation"),
    summary: wrap.querySelector(".case-score"),
    statusEl: wrap.querySelector(".case-status"),
    chips,
  });
}

function formatLatency(ms) {
  if (ms < 1000) return `${Math.round(ms)} ms`;
  const s = ms / 1000;
  return `${s.toFixed(s >= 10 ? 0 : 1)}s`;
}

export function renderObservation(e) {
  const c = state.cases.get(e.case_id);
  if (!c) return;
  const bits = [];
  if (e.model) bits.push(`model ${escapeHtml(e.model)}`);
  const tools = finite(e.tool_calls);
  if (tools !== null) bits.push(plural(tools, "tool call"));
  const latency = finite(e.latency_ms);
  if (latency) bits.push(formatLatency(latency));
  if (e.error) bits.push(`<span class="fail">error: ${escapeHtml(e.error)}</span>`);
  const preview = e.output_preview ? `<div class="obs-output">${escapeHtml(e.output_preview)}</div>` : "";
  c.obs.innerHTML = `<div class="obs-line">${bits.join(" · ")}</div>${preview}`;
  c.obs.classList.remove("muted");
}

function chipFor(e) {
  return state.cases.get(e.case_id)?.chips.get(e.metric) || null;
}

export function renderMetricStarted(e) {
  const chip = chipFor(e);
  if (!chip) return;
  chip.className = "mchip running";
  chip.querySelector(`${CHIP_STATE} .txt`).textContent = "In progress…";
}

/** Visible explanation (no hover needed): a <details> with the text. */
function noteHtml(summary, text) {
  if (!text) return "";
  return `<details class="mchip-why"><summary>${escapeHtml(summary)}</summary><p>${escapeHtml(text)}</p></details>`;
}

export function renderMetricDone(e) {
  const chip = chipFor(e);
  if (!chip) return;
  chip.className = `mchip ${e.passed ? "ok" : "bad"}`;
  const pct = Math.max(0, Math.min(1, finite(e.score) ?? 0)) * 100;
  chip.querySelector(".mchip-meter span").style.width = `${pct}%`;
  const need = formatThreshold(e.threshold);
  const scoreLine = [`Score ${escapeHtml(formatPercent(e.score))}`, need ? escapeHtml(need) : ""].filter(Boolean).join(" · ");
  const lines = [e.passed ? "Meets requirement" : "Does not meet requirement", scoreLine, changeHtml(e.delta, e.score)];
  const unstable = e.unstable ? '<span class="badge badge-warn">Inconsistent assessment</span>' : "";
  const body = [...lines, unstable].filter(Boolean).map((line) => `<span class="mchip-line">${line}</span>`).join("");
  chip.querySelector(CHIP_STATE).innerHTML = `<span class="dot" aria-hidden="true"></span><span class="txt">${body}</span>`;
  chip.querySelector(".mchip-note").innerHTML = noteHtml("Assessment rationale", e.rationale);
}

export function renderMetricSkipped(e) {
  const chip = chipFor(e);
  if (!chip) return;
  chip.className = "mchip skipped";
  const shown = skipReason(e.reason);
  chip.querySelector(`${CHIP_STATE} .txt`).textContent = `Skipped: ${shown}`;
  const raw = String(e.reason || "");
  chip.querySelector(".mchip-note").innerHTML = raw && raw !== shown ? noteHtml("Technical detail", raw) : "";
}

/** Chips that never started (e.g. the case stopped early) say so instead of "Queued". */
function settleChips(c) {
  for (const chip of c.chips.values()) {
    if (!chip.classList.contains("queued") && !chip.classList.contains("running")) continue;
    chip.className = "mchip not-assessed";
    chip.querySelector(`${CHIP_STATE} .txt`).textContent = "Not assessed";
  }
}

export function renderCaseDone(e) {
  state.done = Math.min(state.total || Infinity, state.done + 1);
  setProgress();
  const c = state.cases.get(e.case_id);
  if (!c) return;
  settleChips(c);
  const kind = e.passed ? "pass" : "fail";
  c.root.className = `live-case ${kind}`;
  c.root.open = !e.passed;
  c.statusEl.innerHTML = e.passed
    ? '<span class="pass" aria-hidden="true">✓</span><span class="sr-only">Passed</span>'
    : '<span class="fail" aria-hidden="true">✗</span><span class="sr-only">Failed</span>';
  const delta = changeHtml(e.weighted_delta, e.weighted_score);
  c.summary.innerHTML =
    `<span class="${kind}">${e.passed ? "Pass" : "Fail"}</span> · ${escapeHtml(formatPercent(e.weighted_score))}${delta ? ` · ${delta}` : ""}`;
}

/** Cases still running when the run ends (cancel/error) stop spinning. */
export function settleRunningCases() {
  for (const c of state.cases.values()) {
    if (!c.root.classList.contains("running")) continue;
    c.root.className = "live-case error";
    c.statusEl.innerHTML = '<span class="status-error" aria-hidden="true">–</span><span class="sr-only">Not completed</span>';
    c.summary.textContent = "Not completed";
    if (c.obs.classList.contains("muted")) c.obs.textContent = "Stopped before the agent responded.";
    settleChips(c);
  }
}
