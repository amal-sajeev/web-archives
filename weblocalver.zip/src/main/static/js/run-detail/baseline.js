// Baseline promotion: confirmation dialog, POST, and a toast with the result.

import { postJson } from "../lib/api.js";
import { formatPercent, isPassingStatus } from "../lib/format.js";
import { showError, showToast } from "../ui/toast.js";

const $ = (selector) => document.querySelector(selector);
const CONFIRM = "confirm";
const PASSING_NOTE = "Future evaluations will use this run as the comparison baseline.";
const FAILING_NOTE = `This evaluation did not pass. Promoting it may weaken subsequent comparisons. ${PASSING_NOTE}`;

let currentRun = null;

function setStatus(text, cls = "muted") {
  const status = $("#baseline-status");
  status.textContent = text;
  status.className = cls;
}

function criteriaCount(n) {
  return `${n} ${n === 1 ? "criterion" : "criteria"}`;
}

async function promote(run) {
  const button = $("#promote-baselines");
  button.disabled = true;
  button.setAttribute("aria-busy", "true");
  setStatus("Promoting baseline…");
  try {
    const payload = await postJson(`api/baselines/promote/${encodeURIComponent(run.run_id)}`);
    const count = Array.isArray(payload?.promoted) ? payload.promoted.length : 0;
    const message = `Baseline promoted. Subsequent evaluations will be compared against ${criteriaCount(count)} from this run.`;
    setStatus(message, "ok");
    showToast(message, { kind: "ok" });
  } catch (err) {
    setStatus(`Baseline promotion failed: ${err.message}`, "fail");
    showError(err);
  } finally {
    button.disabled = false;
    button.removeAttribute("aria-busy");
  }
}

function openDialog() {
  const dialog = $("#baseline-dialog");
  if (!currentRun) return;
  dialog.returnValue = "";
  $("#confirm-runid").textContent = currentRun.run_id;
  $("#confirm-score").textContent = formatPercent(currentRun.weighted_score);
  $("#baseline-confirmation-text").textContent = isPassingStatus(currentRun.status) ? PASSING_NOTE : FAILING_NOTE;
  dialog.showModal();
  dialog.querySelector("[autofocus]")?.focus();
}

/** Wires the promote button and dialog once. */
export function initBaseline() {
  const dialog = $("#baseline-dialog");
  $("#promote-baselines").addEventListener("click", openDialog);
  dialog.querySelector(".dialog-close").addEventListener("click", () => dialog.close("cancel"));
  dialog.addEventListener("close", () => {
    if (dialog.returnValue === CONFIRM && currentRun) promote(currentRun);
  });
}

/** Points the promote action at the loaded run. */
export function setBaselineRun(run) {
  currentRun = run;
  $("#promote-baselines").disabled = !run;
}
