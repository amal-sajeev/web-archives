// Minimal, hardened Markdown renderer for agent output previews.
// Every piece of text is escaped; only http, https and mailto links survive.

import { escapeHtml } from "../lib/fragments.js";

const SAFE_SCHEME = /^(https?:|mailto:)/i;
const FENCE = "```";
const HEADING_SHIFT = 3; // markdown "#" renders as <h4>, keeping the page outline intact
const MAX_HEADING = 6;
const INLINE = /`([^`]+)`|\[([^\]]+)\]\(((?:[^()\s]|\([^()\s]*\))+)\)|\*\*([^*]+)\*\*|\*([^*]+)\*/g;
const HEADING_RE = /^(#{1,6})\s+(.+)$/;
const BULLET_RE = /^\s*[-*+]\s+(.+)$/;
const ORDERED_RE = /^\s*\d+[.)]\s+(.+)$/;

/** True when the raw (unescaped) href uses an allowed scheme. */
export function isSafeHref(href) {
  // Strip whitespace and control characters that browsers ignore inside schemes.
  const compact = Array.from(String(href || ""))
    .filter((ch) => ch.charCodeAt(0) > 32 && ch.charCodeAt(0) !== 127)
    .join("");
  return SAFE_SCHEME.test(compact);
}

function linkHtml(label, href) {
  const text = renderInline(label);
  if (!isSafeHref(href)) return text;
  return `<a href="${escapeHtml(href.trim())}" target="_blank" rel="noopener noreferrer">${text}</a>`;
}

function inlineToken(match) {
  const [, code, label, href, strong, em] = match;
  if (code !== undefined) return `<code>${escapeHtml(code)}</code>`;
  if (label !== undefined) return linkHtml(label, href);
  if (strong !== undefined) return `<strong>${renderInline(strong)}</strong>`;
  return `<em>${renderInline(em)}</em>`;
}

/** Inline markdown (code, links, bold, italic) on raw text -> safe HTML. */
export function renderInline(text) {
  const source = String(text ?? "");
  let html = "";
  let last = 0;
  for (const match of source.matchAll(INLINE)) {
    html += escapeHtml(source.slice(last, match.index)) + inlineToken(match);
    last = match.index + match[0].length;
  }
  return html + escapeHtml(source.slice(last));
}

function createState() {
  return { out: [], list: null, code: null };
}

function closeList(state) {
  if (!state.list) return;
  state.out.push(`</${state.list}>`);
  state.list = null;
}

function openList(state, tag) {
  if (state.list === tag) return;
  closeList(state);
  state.out.push(`<${tag}>`);
  state.list = tag;
}

function flushCode(state) {
  state.out.push(`<pre class="code-block"><code>${escapeHtml(state.code.join("\n"))}</code></pre>`);
  state.code = null;
}

function toggleFence(state) {
  if (state.code) {
    flushCode(state);
    return;
  }
  closeList(state);
  state.code = [];
}

function pushListItem(state, tag, content) {
  openList(state, tag);
  state.out.push(`<li>${renderInline(content)}</li>`);
}

function renderLine(state, line) {
  const heading = HEADING_RE.exec(line);
  if (heading) {
    closeList(state);
    const level = Math.min(MAX_HEADING, heading[1].length + HEADING_SHIFT);
    state.out.push(`<h${level}>${renderInline(heading[2])}</h${level}>`);
    return;
  }
  const bullet = BULLET_RE.exec(line);
  if (bullet) {
    pushListItem(state, "ul", bullet[1]);
    return;
  }
  const ordered = ORDERED_RE.exec(line);
  if (ordered) {
    pushListItem(state, "ol", ordered[1]);
    return;
  }
  closeList(state);
  if (line.trim()) state.out.push(`<p>${renderInline(line)}</p>`);
}

/** Markdown text -> safe HTML string. */
export function markdownToHtml(md) {
  const state = createState();
  for (const line of String(md ?? "").replace(/\r\n?/g, "\n").split("\n")) {
    if (line.trim().startsWith(FENCE)) toggleFence(state);
    else if (state.code) state.code.push(line);
    else renderLine(state, line);
  }
  if (state.code) flushCode(state);
  closeList(state);
  return state.out.join("\n");
}
