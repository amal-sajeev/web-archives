// Agent output preview (markdown, JSON, extracted document text or plain text)
// plus the text conversion shared with the output diff.

import { escapeHtml } from "../lib/fragments.js";
import { markdownToHtml } from "./markdown.js";

const DEFAULT_TYPE = "text";

function paragraphText(report) {
  const paras = report?.paragraphs;
  if (!Array.isArray(paras)) return null;
  return paras
    .map((p) => (p && (p.content ?? p.text ?? p.paragraph)) || "")
    .filter((s) => String(s).trim().length)
    .join("\n\n");
}

/** Report bundles ({paragraphs:[...]} or {key: {paragraphs}}) -> readable prose ("" otherwise). */
export function reportBundleToProse(value) {
  if (!value || typeof value !== "object") return "";
  if (Array.isArray(value.paragraphs)) {
    const body = paragraphText(value);
    if (body === null) return "";
    return value.report_title ? `${value.report_title}\n\n${body}` : body;
  }
  const sections = [];
  for (const [key, report] of Object.entries(value)) {
    const body = report && typeof report === "object" ? paragraphText(report) : null;
    if (body !== null) sections.push(`${report.report_title || key}\n\n${body}`);
  }
  return sections.join("\n\n\n");
}

/** Any output value -> display text. */
export function toText(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  const prose = reportBundleToProse(value);
  if (prose) return prose;
  try {
    return JSON.stringify(value, null, 2);
  } catch (err) {
    console.warn("Output could not be serialised as JSON", err);
    return String(value);
  }
}

/** Reference and agent output text for a case. */
export function caseTexts(c) {
  return { reference: toText(c?.golden_output), agent: toText(c?.observation?.output) };
}

function prettyJson(output) {
  try {
    const parsed = typeof output === "string" ? JSON.parse(output) : output;
    return `<pre class="json-preview">${escapeHtml(JSON.stringify(parsed, null, 2))}</pre>`;
  } catch (err) {
    console.warn("Output labelled JSON could not be parsed", err);
    return `<pre class="text-preview">${escapeHtml(String(output))}</pre>`;
  }
}

function extractedPreview(ctype, text) {
  return `<div class="doc-preview">
    <div class="doc-type-badge">${escapeHtml(ctype.toUpperCase())} (extracted text)</div>
    <pre class="text-preview">${escapeHtml(text)}</pre>
  </div>`;
}

function previewBody(ctype, output, meta) {
  if (ctype === "markdown" && typeof output === "string") {
    return `<div class="doc-preview markdown-body">${markdownToHtml(output)}</div>`;
  }
  if (ctype === "json" || typeof output === "object") return prettyJson(output);
  if (meta.extracted_text) return extractedPreview(ctype, String(meta.extracted_text));
  return `<pre class="text-preview">${escapeHtml(toText(output))}</pre>`;
}

/** Collapsible agent output preview for a case ("" when there is no output). */
export function previewBlock(c) {
  const obs = c?.observation;
  if (!obs?.output) return "";
  const meta = obs.metadata && typeof obs.metadata === "object" ? obs.metadata : {};
  const ctype = String(meta.content_type || DEFAULT_TYPE);
  return `<details class="preview">
    <summary>Agent output (${escapeHtml(ctype)})</summary>
    ${previewBody(ctype, obs.output, meta)}
  </details>`;
}
