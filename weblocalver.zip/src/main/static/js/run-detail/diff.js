// Word-level comparison of the reference (golden) output and the agent output,
// with search and copy controls. Large inputs fall back to plain side-by-side text.

import { escapeHtml } from "../lib/fragments.js";
import { showToast } from "../ui/toast.js";
import { caseTexts } from "./preview.js";

export const MAX_DIFF_TOKENS = 3000;
const EQUAL = "=";
const REMOVED = "-";
const ADDED = "+";
const EMPTY_COL = '<span class="muted">—</span>';
const COPY_RESET_MS = 1200;

function tokenize(text) {
  return text.split(/(\s+)/).filter((t) => t.length);
}

function commonPrefix(a, b) {
  let k = 0;
  while (k < a.length && k < b.length && a[k] === b[k]) k += 1;
  return k;
}

function commonSuffix(a, b, prefix) {
  let k = 0;
  while (k < a.length - prefix && k < b.length - prefix && a[a.length - 1 - k] === b[b.length - 1 - k]) k += 1;
  return k;
}

function lcsTable(a, b) {
  const n = a.length;
  const m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
  for (let i = n - 1; i >= 0; i -= 1) {
    for (let j = m - 1; j >= 0; j -= 1) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  return dp;
}

function walkTable(a, b, dp, ops) {
  let i = 0;
  let j = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      ops.push([EQUAL, a[i]]);
      i += 1;
      j += 1;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      ops.push([REMOVED, a[i]]);
      i += 1;
    } else {
      ops.push([ADDED, b[j]]);
      j += 1;
    }
  }
  for (; i < a.length; i += 1) ops.push([REMOVED, a[i]]);
  for (; j < b.length; j += 1) ops.push([ADDED, b[j]]);
}

/** LCS token diff -> [[op, token]]; common prefix/suffix are trimmed before the table. */
export function diffTokens(a, b) {
  const pre = commonPrefix(a, b);
  const suf = commonSuffix(a, b, pre);
  const midA = a.slice(pre, a.length - suf);
  const midB = b.slice(pre, b.length - suf);
  const ops = a.slice(0, pre).map((t) => [EQUAL, t]);
  walkTable(midA, midB, lcsTable(midA, midB), ops);
  for (const t of a.slice(a.length - suf)) ops.push([EQUAL, t]);
  return ops;
}

/** Both texts -> {gold, agent, capped} column HTML. */
export function renderDiffColumns(goldenText, agentText) {
  const a = tokenize(goldenText);
  const b = tokenize(agentText);
  if (a.length > MAX_DIFF_TOKENS || b.length > MAX_DIFF_TOKENS) {
    return { gold: escapeHtml(goldenText), agent: escapeHtml(agentText), capped: true };
  }
  let gold = "";
  let agent = "";
  for (const [op, tok] of diffTokens(a, b)) {
    const safe = escapeHtml(tok);
    if (op === EQUAL) {
      gold += safe;
      agent += safe;
    } else if (op === REMOVED) {
      gold += `<span class="d-del">${safe}</span>`;
    } else {
      agent += `<span class="d-add">${safe}</span>`;
    }
  }
  return { gold, agent, capped: false };
}

function diffNote(reference, agent, capped) {
  if (!reference || !agent) return "";
  if (reference.trim() === agent.trim()) return '<span class="chip ok-chip">exact match</span>';
  if (capped) return '<span class="chip">plain text · too long to compare word by word</span>';
  return '<span class="chip">word comparison · <span class="d-del">reference only</span> / <span class="d-add">agent only</span></span>';
}

function columns(reference, agent) {
  if (reference && agent) return renderDiffColumns(reference, agent);
  return {
    gold: escapeHtml(reference || "(no reference output on file)"),
    agent: escapeHtml(agent || "(no agent output)"),
    capped: false,
  };
}

function column(title, html) {
  return `<div class="diff-col">
    <div class="diff-head">${title}</div>
    <div class="diff-body">${html || EMPTY_COL}</div>
  </div>`;
}

/** Collapsible comparison block for a case ("" when neither output exists). */
export function diffBlock(c, index) {
  const { reference, agent } = caseTexts(c);
  if (!reference && !agent) return "";
  const cols = columns(reference, agent);
  const cap = cols.capped
    ? `<p class="diff-cap-note small-note">At least one output is longer than ${MAX_DIFF_TOKENS.toLocaleString()} words and spaces, so the texts are shown side by side without highlighting.</p>`
    : "";
  return `<details class="diff">
      <summary>Compare reference and agent output ${diffNote(reference, agent, cols.capped)}</summary>
      <div class="diff-toolbar">
        <label>
          <span class="sr-only">Search comparison</span>
          <input type="search" class="diff-search" data-case-index="${index}" placeholder="Search outputs" />
        </label>
        <span class="diff-search-result muted" aria-live="polite"></span>
        <button type="button" class="button-quiet copy-output" data-case-index="${index}" data-output="reference">Copy reference</button>
        <button type="button" class="button-quiet copy-output" data-case-index="${index}" data-output="agent">Copy agent output</button>
      </div>
      ${cap}
      <div class="diff-grid">${column("Reference output", cols.gold)}${column("Agent output", cols.agent)}</div>
    </details>`;
}

/** Copies text; confirms on the button, or explains in a toast when the clipboard is unavailable. */
export async function copyText(text, button) {
  try {
    if (!navigator.clipboard) throw new Error("Clipboard unavailable");
    await navigator.clipboard.writeText(text);
    const original = button.textContent;
    button.textContent = "Copied";
    window.setTimeout(() => { button.textContent = original; }, COPY_RESET_MS);
  } catch (err) {
    console.warn("Copy failed", err);
    showToast("Could not copy to the clipboard. Select the text and copy it manually.", { kind: "warn" });
  }
}

function countOccurrences(text, query) {
  return text.toLowerCase().split(query).length - 1;
}

/** Wires copy and search controls inside one case body. getCase(index) returns the case. */
export function wireDiffControls(root, getCase) {
  root.querySelectorAll(".copy-output").forEach((button) => {
    button.addEventListener("click", () => {
      const texts = caseTexts(getCase(Number(button.dataset.caseIndex)));
      copyText(button.dataset.output === "reference" ? texts.reference : texts.agent, button);
    });
  });
  root.querySelectorAll(".diff-search").forEach((input) => {
    input.addEventListener("input", () => {
      const status = input.closest(".diff-toolbar").querySelector(".diff-search-result");
      const query = input.value.trim().toLowerCase();
      if (!query) {
        status.textContent = "";
        return;
      }
      const texts = caseTexts(getCase(Number(input.dataset.caseIndex)));
      status.textContent = `${countOccurrences(texts.reference, query)} reference · ${countOccurrences(texts.agent, query)} agent`;
    });
  });
}
