// Run-level report sections: outcome header, run details, reliability prose
// and the criterion roll-up tables.

import {
  DASH, asPercent, formatDrift, formatHumanAgreement, formatMeanQuality,
  formatPassCount, formatPercent, formatChange, importanceLabel, skipReason, statusKind,
} from "../lib/format.js";
import { escapeHtml, scoreRingHtml, stampHtml } from "../lib/fragments.js";
import { metricInfo } from "../lib/metric-catalog.js";

const $ = (selector) => document.querySelector(selector);
const NO_BASELINE = "No baseline comparison";
const SPLIT_ABOVE = 4;
const HERO_TEXT = {
  pass: "This evaluation passed",
  fail: "This evaluation did not meet the required standard",
  error: "This evaluation did not complete",
  cancelled: "This evaluation was cancelled",
};
const PILL_CLASS = { pass: "ok", fail: "bad", error: "bad", cancelled: "warn" };
const PILL_TEXT = { pass: "Pass", fail: "Fail", error: "Error", cancelled: "Cancelled" };

function setText(selector, text) {
  const node = $(selector);
  if (node) node.textContent = text;
}

export function setPill(text, cls) {
  const pill = $("#run-pill");
  pill.textContent = text;
  pill.className = `pill ${cls || ""}`.trim();
}

/** Baseline score implied by score and delta, as "71%" (null when not compared). */
export function baselinePercent(score, delta) {
  if (asPercent(score) === null || delta === null || delta === undefined) return null;
  return formatPercent(Number(score) - Number(delta));
}

/** ISO timestamp -> locale string; the raw value (or a dash) when it is not a valid date. */
export function formatWhen(ts) {
  const date = new Date(ts);
  if (!ts || Number.isNaN(date.getTime())) return ts ? String(ts) : DASH;
  return date.toLocaleString();
}

/** Legacy rows may carry "ERROR: ..." variants; treat them as ERROR. */
export function runStatus(status) {
  return /^ERROR/i.test(String(status ?? "").trim()) ? "ERROR" : status;
}

function renderOutcome(run, kind) {
  const cases = run.case_results || [];
  setPill(PILL_TEXT[kind], PILL_CLASS[kind]);
  $("#stamp").innerHTML = stampHtml(runStatus(run.status));
  $("#quality-ring").innerHTML = scoreRingHtml(run.weighted_score, 112);
  setText("#report-name", `${run.agent_id} · v${run.dataset_version}`);
  setText("#hero-title", HERO_TEXT[kind]);
  setText("#m-score", formatPercent(run.weighted_score));
  setText("#summary-cases", `${cases.filter((c) => c.passed).length} / ${cases.length}`);
  setText("#summary-baseline", baselinePercent(run.weighted_score, run.weighted_delta) || DASH);
  setText("#m-delta", formatChange(run.weighted_delta, run.weighted_score));
  const errorNote = $("#run-error-detail");
  if (errorNote) {
    errorNote.hidden = !run.error_detail;
    errorNote.textContent = run.error_detail || "";
  }
}

function renderRunDetails(run) {
  const baseline = baselinePercent(run.weighted_score, run.weighted_delta);
  setText("#m-agent", run.agent_id);
  setText("#m-dataset", `${run.dataset_id} · v${run.dataset_version}`);
  setText("#m-runid", run.run_id);
  setText("#m-when", formatWhen(run.creation_ts));
  setText("#baseline-run", `${run.agent_id} · ${run.dataset_id} v${run.dataset_version}`);
  setText("#baseline-score", formatPercent(run.weighted_score));
  setText("#baseline-reference", baseline || NO_BASELINE);
  setText("#baseline-delta", baseline ? formatChange(run.weighted_delta, run.weighted_score) : NO_BASELINE);
}

function coverageItem(assessed, skipped) {
  const n = skipped.size;
  const named = [...skipped].map((m) => metricInfo(m).title);
  const list = named.length <= 2 ? ` (${named.join(" and ")})` : "";
  return {
    label: "Assessment coverage",
    value: `${assessed.size} of ${assessed.size + n} criteria were assessed. `
      + `${n} criteri${n === 1 ? "on" : "a"}${list} could not be measured `
      + `and ${n === 1 ? "is" : "are"} excluded from the score, so this result reflects partial coverage.`,
    warn: true,
  };
}

function renderReliability(run) {
  const stats = run.stats;
  const cases = run.case_results || [];
  const assessed = new Set();
  const skipped = new Set();
  for (const c of cases) {
    (c.scores || []).forEach((sc) => assessed.add(sc.metric));
    (c.skipped || []).forEach((sk) => skipped.add(sk.metric));
  }
  const items = [
    { label: "Cases meeting the standard", value: formatPassCount(stats) },
    { label: "Typical case score", value: formatMeanQuality(stats) },
    { label: "Change versus baseline", value: formatDrift(stats) },
  ];
  const agreement = formatHumanAgreement(stats);
  if (agreement) items.push({ label: "Agreement with expert review", value: agreement });
  if (skipped.size) items.push(coverageItem(assessed, skipped));
  $("#reliability").innerHTML = items.map((i) => `
    <div class="reliability-item${i.warn ? " warn" : ""}">
      <dt>${escapeHtml(i.label)}</dt>
      <dd>${escapeHtml(i.value)}</dd>
    </div>`).join("");
}

function emptyRow(metric) {
  return {
    metric, scores: [], passed: 0, assessed: 0, skipped: 0, reasons: new Set(), weight: null, critical: false,
  };
}

function addScore(row, sc) {
  row.assessed += 1;
  if (sc.passed) row.passed += 1;
  if (Number.isFinite(Number(sc.score))) row.scores.push(Number(sc.score));
  if (row.weight === null) row.weight = sc.weight;
  row.critical = row.critical || Boolean(sc.critical);
}

function addSkip(row, sk) {
  row.skipped += 1;
  if (sk.reason) row.reasons.add(sk.reason);
  if (row.weight === null) row.weight = sk.weight;
  row.critical = row.critical || Boolean(sk.critical);
}

function isFailing(row) {
  return row.assessed > 0 && row.passed < row.assessed;
}

function compareRows(a, b) {
  if (isFailing(a) !== isFailing(b)) return isFailing(a) ? -1 : 1;
  if ((a.skipped > 0) !== (b.skipped > 0)) return a.skipped > 0 ? -1 : 1;
  return (b.weight || 0) - (a.weight || 0);
}

/** One row per criterion, aggregated over every case in the run. */
export function criterionRollup(run) {
  const rows = new Map();
  const ensure = (metric) => {
    if (!rows.has(metric)) rows.set(metric, emptyRow(metric));
    return rows.get(metric);
  };
  for (const c of run.case_results || []) {
    (c.scores || []).forEach((sc) => addScore(ensure(sc.metric), sc));
    (c.skipped || []).forEach((sk) => addSkip(ensure(sk.metric), sk));
  }
  const mean = (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
  return [...rows.values()]
    .map((r) => ({ ...r, meanScore: mean(r.scores), info: metricInfo(r.metric) }))
    .sort(compareRows);
}

function criterionName(r) {
  const critical = r.critical
    ? ' <span class="criterion-decorator criterion-decorator-critical" title="Mandatory" aria-label="Mandatory"></span>'
    : "";
  const signal = r.info.informational ? ' <span class="badge badge-muted">Self-reported</span>' : "";
  return `<span class="criterion-name">${escapeHtml(r.info.title)}</span>${critical}${signal}`;
}

function rollupRow(r) {
  const name = criterionName(r);
  if (r.assessed === 0) {
    const raw = [...r.reasons][0] || "";
    return `<tr class="rollup-row skipped">
      <td>${name}</td>
      <td colspan="3" class="rollup-skip" title="${escapeHtml(raw)}">Not assessed — ${escapeHtml(skipReason(raw))}</td>
    </tr>`;
  }
  const met = r.passed === r.assessed;
  const partial = r.skipped > 0 ? `<span class="rollup-partial">${r.skipped} not assessed</span>` : "";
  return `<tr class="rollup-row ${met ? "ok" : "bad"}">
    <td>${name}</td>
    <td><span class="status-label ${met ? "status-pass" : "status-fail"}">${r.passed} of ${r.assessed}</span>${partial}</td>
    <td><strong>${formatPercent(r.meanScore)}</strong></td>
    <td>${escapeHtml(importanceLabel(r.weight))}</td>
  </tr>`;
}

function rollupRows(rows) {
  return rows.map(rollupRow).join("")
    || '<tr><td colspan="4" class="empty">No criteria were recorded for this evaluation.</td></tr>';
}

function renderCriterionRollup(run) {
  const rows = criterionRollup(run);
  const split = rows.length > SPLIT_ABOVE;
  const midpoint = split ? Math.ceil(rows.length / 2) : rows.length;
  $("#criterion-rollup-1 tbody").innerHTML = rollupRows(rows.slice(0, midpoint));
  $("#criterion-rollup-2 tbody").innerHTML = split ? rollupRows(rows.slice(midpoint)) : "";
  $("#criterion-rollup-2-wrapper").hidden = !split;
  const note = $("#coverage-note");
  const missing = rows.some((r) => r.skipped > 0);
  note.hidden = !missing;
  note.textContent = missing
    ? "Criteria shown as not assessed were configured for this evaluation but could not be measured in this environment. They are excluded from the overall score."
    : "";
}

/** Renders every run-level section. */
export function renderSummary(run) {
  const kind = statusKind(runStatus(run.status));
  renderOutcome(run, kind);
  renderRunDetails(run);
  renderReliability(run);
  renderCriterionRollup(run);
}
