// Case overview table and the filterable, lazily populated case detail list.

import { DASH, deltaClass, formatChangeVsBaseline, formatPercent, formatChange } from "../lib/format.js";
import { escapeHtml, statusLabelHtml } from "../lib/fragments.js";
import { metricInfo } from "../lib/metric-catalog.js";
import { caseMetricsHtml } from "./case-metrics.js";
import { diffBlock, wireDiffControls } from "./diff.js";
import { previewBlock } from "./preview.js";
import { baselinePercent } from "./summary.js";

const $ = (selector) => document.querySelector(selector);
const SEARCH_DEBOUNCE_MS = 200;
const NOT_COMPARED = "Not compared";
const DEFAULT_SORT = "score-asc";
const ALL = "all";
const CASE_SELECTOR = "details.case";
const LOADED = "true";

let currentRun = null;
let searchTimer = 0;

const caseAt = (index) => currentRun?.case_results?.[index];

function statusIcon(passed) {
  return `<span class="status-icon ${passed ? "pass" : "fail"}" aria-hidden="true">${passed ? "✓" : "!"}</span>`;
}

function columnCount(table) {
  return table.querySelectorAll("thead th").length || 1;
}

function overviewRow(c, index) {
  const id = escapeHtml(c.case_id);
  return `<tr class="clickable-row case-overview-row" data-case-index="${index}" tabindex="0" aria-label="Open details for ${id}">
    <td>${statusIcon(c.passed)}<span class="mono">${id}</span></td>
    <td><strong>${formatPercent(c.weighted_score)}</strong></td>
    <td><strong>${baselinePercent(c.weighted_score, c.weighted_delta) || DASH}</strong></td>
    <td><span class="${deltaClass(c.weighted_delta) || "delta-flat"}">${escapeHtml(c.weighted_delta === null || c.weighted_delta === undefined ? NOT_COMPARED : formatChange(c.weighted_delta, c.weighted_score))}</span></td>
    <td>${statusLabelHtml(c.passed)}</td>
  </tr>`;
}

function renderOverview(run) {
  const table = $("#case-overview");
  const cases = run.case_results || [];
  table.querySelector("tbody").innerHTML = cases.map(overviewRow).join("")
    || `<tr><td colspan="${columnCount(table)}" class="empty">No cases in this evaluation.</td></tr>`;
}

/** Shows a message row spanning every column of the case overview table. */
export function overviewMessage(message) {
  const table = $("#case-overview");
  table.querySelector("tbody").innerHTML = `<tr><td colspan="${columnCount(table)}" class="empty">${escapeHtml(message)}</td></tr>`;
}

const FILTERS = {
  pass: (c) => c.passed,
  fail: (c) => !c.passed,
  regressed: (c) => Number(c.weighted_delta) < 0,
  improved: (c) => Number(c.weighted_delta) > 0,
  changed: (c) => Math.abs(Number(c.weighted_delta)) > 0,
};

const SORTERS = {
  "score-asc": (a, b) => a.c.weighted_score - b.c.weighted_score,
  "delta-asc": (a, b) => (a.c.weighted_delta ?? 0) - (b.c.weighted_delta ?? 0),
  name: (a, b) => String(a.c.case_id).localeCompare(String(b.c.case_id)),
  status: (a, b) => Number(a.c.passed) - Number(b.c.passed) || a.c.weighted_score - b.c.weighted_score,
};

function visibleCases(run) {
  const query = ($("#case-search").value || "").trim().toLowerCase();
  const filter = FILTERS[$("#case-status-filter").value] || (() => true);
  const sorter = SORTERS[$("#case-sort").value] || SORTERS[DEFAULT_SORT];
  return (run.case_results || [])
    .map((c, index) => ({ c, index }))
    .filter(({ c }) => (!query || String(c.case_id).toLowerCase().includes(query)) && filter(c))
    .sort(sorter);
}

function metricSummary(c) {
  const assessed = (c.scores || []).filter((sc) => !metricInfo(sc.metric).informational);
  const met = assessed.filter((sc) => sc.passed).length;
  const skipped = (c.skipped || []).length;
  const tail = skipped ? ` · ${skipped} not assessed` : "";
  return `${assessed.length} criteria · ${met} met · ${assessed.length - met} not met${tail}`;
}

function caseDetails({ c, index }) {
  const { text, cls } = formatChangeVsBaseline(c.weighted_delta, c.weighted_score);
  const delta = text ? `<span class="case-delta ${cls}">${escapeHtml(text)}</span>` : "";
  return `<details class="case" data-case-id="${escapeHtml(c.case_id)}" data-case-index="${index}">
    <summary>
      ${statusIcon(c.passed)}
      <div class="case-summary-main">
        <div class="case-summary-title-row"><strong>${escapeHtml(c.case_id)}</strong>${delta}</div>
        <div class="case-key-metrics"><span>${escapeHtml(metricSummary(c))}</span></div>
      </div>
      <div class="case-summary-right">
        <strong class="case-summary-score">${formatPercent(c.weighted_score)}</strong>
        ${statusLabelHtml(c.passed)}
      </div>
    </summary>
    <div class="case-body"><p class="muted">Loading diagnostics…</p></div>
  </details>`;
}

function populateCaseBody(details) {
  if (details.dataset.loaded === LOADED) return;
  const index = Number(details.dataset.caseIndex);
  const c = caseAt(index);
  if (!c) return;
  details.querySelector(".case-body").innerHTML = previewBlock(c) + diffBlock(c, index) + caseMetricsHtml(c);
  details.dataset.loaded = LOADED;
  wireDiffControls(details, caseAt);
}

function openIndexes() {
  return new Set([...document.querySelectorAll(`${CASE_SELECTOR}[open]`)].map((d) => d.dataset.caseIndex));
}

/** Re-renders the case list from the current filters, keeping open cases open. */
export function renderCases() {
  if (!currentRun) return;
  const keepOpen = openIndexes();
  const cases = visibleCases(currentRun);
  const total = (currentRun.case_results || []).length;
  $("#case-count").textContent = `Showing ${cases.length} of ${total} cases`;
  const list = $("#cases");
  list.innerHTML = cases.map(caseDetails).join("") || '<p class="empty">No cases match the selected filters.</p>';
  list.querySelectorAll(CASE_SELECTOR).forEach((details) => {
    if (keepOpen.has(details.dataset.caseIndex)) {
      details.open = true;
      populateCaseBody(details);
    }
    details.addEventListener("toggle", () => {
      if (details.open) populateCaseBody(details);
    });
  });
}

function findCase(index) {
  return document.querySelector(`${CASE_SELECTOR}[data-case-index="${Number(index)}"]`);
}

/** Opens and scrolls to a case; clears the filters and retries once if it is hidden. */
export function openCase(index, retried = false) {
  const details = findCase(index);
  if (!details) {
    if (retried) return;
    $("#case-search").value = "";
    $("#case-status-filter").value = ALL;
    renderCases();
    openCase(index, true);
    return;
  }
  details.open = true;
  populateCaseBody(details);
  details.scrollIntoView({ behavior: "smooth", block: "start" });
  details.querySelector("summary").focus({ preventScroll: true });
}

/** Wires filter, sort and overview controls once. */
export function initCaseControls() {
  $("#case-search").addEventListener("input", () => {
    window.clearTimeout(searchTimer);
    searchTimer = window.setTimeout(renderCases, SEARCH_DEBOUNCE_MS);
  });
  $("#case-status-filter").addEventListener("change", renderCases);
  $("#case-sort").addEventListener("change", renderCases);
  const tbody = $("#case-overview tbody");
  const rowOf = (event) => event.target.closest("tr[data-case-index]");
  tbody.addEventListener("click", (event) => {
    const row = rowOf(event);
    if (row) openCase(row.dataset.caseIndex);
  });
  tbody.addEventListener("keydown", (event) => {
    const row = rowOf(event);
    if (!row || (event.key !== "Enter" && event.key !== " ")) return;
    event.preventDefault();
    openCase(row.dataset.caseIndex);
  });
}

/** Renders the overview table and case list for a run. */
export function renderCaseSections(run) {
  currentRun = run;
  renderOverview(run);
  renderCases();
}
