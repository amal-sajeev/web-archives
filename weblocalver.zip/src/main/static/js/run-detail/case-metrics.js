// Per-case criterion tables: one <table> per criterion group plus a
// "Not assessed" table. Rows stack on narrow screens using each cell's data-label.

import {
  DASH, asPercent, changeLabel, deltaClass, formatPercent, formatRaw, importance, importanceLabel, skipReason,
} from "../lib/format.js";
import { escapeHtml } from "../lib/fragments.js";
import { groupScores, metricInfo } from "../lib/metric-catalog.js";

const NOT_SET = "Not set";
const LABEL_REQUIRED = "Required";
const LABEL_WEIGHT = "Weight";
const MANDATORY_BADGE = '<span class="badge badge-critical">Mandatory</span>';
const JUDGE_BADGE = '<span class="badge badge-judge">Model assessment</span>';
const PASS = "pass";
const FAIL = "fail";

function requiredText(threshold) {
  const pct = asPercent(threshold);
  return pct === null ? NOT_SET : `${pct}%`;
}

function badgesHtml(badges) {
  return badges.length ? `<div class="metric-badges">${badges.join("")}</div>` : "";
}

function evidenceDetails(summary, bits) {
  return `<details class="metric-evidence">
    <summary><span class="nerd-caret" aria-hidden="true"></span>${summary}</summary>
    <div class="metric-evidence-body">${bits.join("")}</div>
  </details>`;
}

function labelled(label, bodyHtml, cls = "") {
  return `<div${cls ? ` class="${cls}"` : ""}><div class="evidence-label">${label}</div>${bodyHtml}</div>`;
}

function extraBits(sc) {
  const bits = [];
  if (sc.variance !== null && sc.variance !== undefined && Number.isFinite(Number(sc.variance))) {
    bits.push(labelled("Assessment variance", escapeHtml(Number(sc.variance).toFixed(4))));
  }
  if (sc.response_code !== null && sc.response_code !== undefined) {
    bits.push(labelled("Response code", escapeHtml(sc.response_code)));
  }
  if (sc.position_bias !== null && sc.position_bias !== undefined) {
    bits.push(labelled("Position bias", escapeHtml(sc.position_bias)));
  }
  return bits;
}

function scoreEvidence(sc) {
  const bits = [`<div class="metric-id">${escapeHtml(sc.metric)}</div>`];
  if (sc.rationale) bits.push(labelled("Assessment", escapeHtml(sc.rationale), "evidence-rationale"));
  const evidence = Array.isArray(sc.evidence) ? sc.evidence : [];
  if (evidence.length) {
    const lines = evidence.map((e) => `<div class="evidence-line">${escapeHtml(e)}</div>`).join("");
    bits.push(labelled("Evidence", lines, "details-evidence"));
  }
  const raw = formatRaw(sc.raw_value, sc.unit);
  if (raw) bits.push(labelled("Observed value", escapeHtml(raw)));
  if (sc.baseline !== null && sc.baseline !== undefined) {
    bits.push(labelled("Comparison baseline", formatPercent(sc.baseline)));
  }
  bits.push(...extraBits(sc));
  return evidenceDetails("View supporting evidence", bits);
}

function scoreBadges(sc, info) {
  const badges = [];
  if (sc.critical) badges.push(MANDATORY_BADGE);
  if (info.judge) badges.push(JUDGE_BADGE);
  if (sc.unstable) badges.push('<span class="badge badge-warn">Inconsistent assessment</span>');
  return badges;
}

function mainCell(icon, iconClass, info, badges, extra) {
  return `<th scope="row" class="metric-main">
      <div class="metric-title-line">
        <span class="metric-status-icon ${iconClass}" aria-hidden="true">${icon}</span>
        <span class="metric-title">${escapeHtml(info.title)}</span>
        ${badgesHtml(badges)}
      </div>
      <p class="metric-blurb">${escapeHtml(info.blurb)}</p>
      ${extra}
    </th>`;
}

function factCell(label, valueHtml, cls = "") {
  return `<td class="metric-fact" data-label="${label}"><strong${cls ? ` class="${cls}"` : ""}>${valueHtml}</strong></td>`;
}

function metricRow(sc) {
  const info = metricInfo(sc.metric);
  const status = sc.passed ? PASS : FAIL;
  const emphasis = info.informational ? "informational" : importance(sc.weight);
  return `<tr class="metric-row ${sc.passed ? "ok" : "bad"} emphasis-${emphasis}">
    ${mainCell(sc.passed ? "✓" : "!", status, info, scoreBadges(sc, info), scoreEvidence(sc))}
    <td class="metric-score-cell"><span class="metric-score-pill ${status}">${formatPercent(sc.score)}</span></td>
    ${factCell(LABEL_REQUIRED, escapeHtml(requiredText(sc.threshold)))}
    ${factCell(LABEL_WEIGHT, escapeHtml(importanceLabel(sc.weight)))}
    ${factCell("Vs. baseline", escapeHtml(changeLabel(sc.delta, sc.score)), deltaClass(sc.delta))}
    <td class="metric-status-cell"><span class="status-label status-${status}">${sc.passed ? "Met" : "Not met"}</span></td>
  </tr>`;
}

function skippedRow(sk) {
  const info = metricInfo(sk.metric);
  const badges = [];
  if (sk.critical) badges.push(MANDATORY_BADGE);
  if (sk.judge || info.judge) badges.push(JUDGE_BADGE);
  const technical = sk.reason
    ? evidenceDetails("View technical detail", [`<div class="metric-id">${escapeHtml(sk.metric)}</div>`, `<div>${escapeHtml(sk.reason)}</div>`])
    : "";
  const extra = `<p class="metric-skip-reason">${escapeHtml(skipReason(sk.reason))}</p>${technical}`;
  return `<tr class="metric-row skipped-row">
    ${mainCell("•", "neutral", info, badges, extra)}
    <td class="metric-score-cell"><span class="metric-score-pill neutral">${DASH}</span></td>
    ${factCell(LABEL_REQUIRED, escapeHtml(requiredText(sk.threshold)))}
    ${factCell(LABEL_WEIGHT, escapeHtml(importanceLabel(sk.weight)))}
    ${factCell("Effect", "Excluded", "delta-flat")}
    <td class="metric-status-cell"><span class="status-label status-cancelled">Not assessed</span></td>
  </tr>`;
}

function metricTable(caption, effectLabel, rowsHtml) {
  return `<div class="table-scroll metric-table-scroll"><table class="metric-table">
    <caption class="sr-only">${escapeHtml(caption)}</caption>
    <thead><tr>
      <th scope="col">Criterion</th><th scope="col">Score</th><th scope="col">${LABEL_REQUIRED}</th>
      <th scope="col">${LABEL_WEIGHT}</th><th scope="col">${effectLabel}</th><th scope="col">Status</th>
    </tr></thead>
    <tbody>${rowsHtml}</tbody>
  </table></div>`;
}

function groupSection(g) {
  const note = g.note ? `<p class="group-note">${escapeHtml(g.note)}</p>` : "";
  return `<section class="mgroup mgroup-${escapeHtml(g.id)}">
    <h3 class="group-heading">${escapeHtml(g.label)}</h3>
    ${note}
    ${metricTable(g.label, "Vs. baseline", g.items.map(({ sc }) => metricRow(sc)).join(""))}
  </section>`;
}

function skippedSection(skipped) {
  if (!skipped.length) return "";
  return `<section class="mgroup mgroup-skipped">
    <h3 class="group-heading">Not assessed</h3>
    <p class="group-note">These criteria were configured for this evaluation but could not be measured. They are excluded from the score.</p>
    ${metricTable("Criteria not assessed", "Effect", skipped.map(skippedRow).join(""))}
  </section>`;
}

/** All criterion tables for one case. */
export function caseMetricsHtml(c) {
  const groups = groupScores(c.scores || []).map(groupSection).join("");
  const skipped = skippedSection(c.skipped || []);
  return groups + skipped || '<p class="empty">No criteria were recorded for this case.</p>';
}
