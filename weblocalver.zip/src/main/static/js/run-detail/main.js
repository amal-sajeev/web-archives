// Run report entry point. Reads ?run=<id> (or ?run_id=<id>), loads the run and
// renders the report; a failed load shows a full error state with Retry.

import "../ui/shell.js";
import { fetchJson } from "../lib/api.js";
import { initBaseline, setBaselineRun } from "./baseline.js";
import { initCaseControls, openCase, overviewMessage, renderCaseSections } from "./cases.js";
import { copyText } from "./diff.js";
import { renderSummary, setPill } from "./summary.js";

const $ = (selector) => document.querySelector(selector);
const params = new URLSearchParams(location.search);
const runId = params.get("run") || params.get("run_id") || "";
const EXPORT_FORMATS = ["csv", "pdf"];

let loadedRun = null;

function showReport(visible) {
  $("#report").hidden = !visible;
  $("#load-error").hidden = visible;
}

function showError(title, detail, canRetry) {
  setPill("Unavailable", "bad");
  $("#load-error-title").textContent = title;
  $("#load-error-detail").textContent = detail;
  $("#retry-load").hidden = !canRetry;
  document.title = "Report unavailable · CTNA Evaluation Service";
  overviewMessage(title);
  showReport(false);
  $("#load-error").focus();
}

function errorCopy(err) {
  if (err.status === 404) {
    return { title: "Evaluation not found", detail: `No evaluation with identifier “${runId}” exists. It may have been removed.` };
  }
  if (err.status === 0) return { title: "Service unavailable", detail: err.message };
  return { title: "The report could not be loaded", detail: err.message };
}

function setExportLinks(id) {
  for (const format of EXPORT_FORMATS) {
    const link = $(`#export-${format}`);
    link.href = `api/runs/${encodeURIComponent(id)}/export?format=${format}`;
    link.setAttribute("download", `run_${id.slice(0, 8)}.${format}`);
    link.hidden = false;
  }
}

function wireCopy(run) {
  const button = $("#copy-runid");
  button.hidden = !run.run_id;
  button.onclick = () => copyText(run.run_id, button);
}

function render(run) {
  loadedRun = run;
  const raw = $("#detail");
  raw.dataset.loaded = "";
  raw.textContent = "Select to load the source record.";
  $("#raw-detail").open = false;
  renderSummary(run);
  renderCaseSections(run);
  setBaselineRun(run);
  setExportLinks(run.run_id || runId);
  wireCopy(run);
  document.title = `${run.agent_id} · Evaluation report · CTNA Evaluation Service`;
  showReport(true);
  openLinkedCase(run);
}

/** ?case=<case_id> deep-links to one case's diagnostics. */
function openLinkedCase(run) {
  const caseId = params.get("case");
  const index = caseId ? (run.case_results || []).findIndex((c) => c.case_id === caseId) : -1;
  if (index >= 0) openCase(index);
}

async function load() {
  if (!runId) {
    showError("Run identifier required", "Open a report from the dashboard, or add ?run=<identifier> to the address.", false);
    return;
  }
  setPill("Loading…", "running");
  $("#retry-load").disabled = true;
  try {
    render(await fetchJson(`api/runs/${encodeURIComponent(runId)}`));
  } catch (err) {
    const { title, detail } = errorCopy(err);
    showError(title, detail, err.status !== 404);
  } finally {
    $("#retry-load").disabled = false;
  }
}

function initRawRecord() {
  const details = $("#raw-detail");
  details.addEventListener("toggle", () => {
    const pre = $("#detail");
    if (!details.open || !loadedRun || pre.dataset.loaded === "true") return;
    pre.textContent = JSON.stringify(loadedRun, null, 2);
    pre.dataset.loaded = "true";
  });
}

function init() {
  setBaselineRun(null);
  initBaseline();
  initCaseControls();
  initRawRecord();
  $("#retry-load").addEventListener("click", load);
  load();
}

init();
