// The Runner's evaluation list and the main pane: tick one evaluation to see its
// details, or two to compare them. The rules live in runner-list-model.js.

import { escapeHtml } from "../lib/fragments.js";
import { comparisonHtml } from "./run-compare.js";
import { initRunDetail, renderRunDetail } from "./run-detail.js";
import {
  MODES, reconcileSelection, runListItem, selectedEntries, selectionMode, toggleSelection,
} from "./runner-list-model.js";
import { MAX_RUNS, reportStorageError, saveRun, state } from "./store.js";
import { $ } from "./view.js";
import { renderViewState } from "./views.js";

const LIST = "#run-list";
const VIEW = "#run-view";
const HINT = "#history-hint";

export const NO_RUNS_HTML = '<div class="empty-hint"><p class="empty-hint-title">No evaluations yet</p>'
  + "<p>Choose the tests and press <strong>Run evaluation</strong>. The last "
  + `${MAX_RUNS} results are kept in this browser so you can look back at them and compare them.</p></div>`;
const PICK_HTML = '<div class="empty-hint"><p class="empty-hint-title">Nothing selected</p>'
  + "<p>Tick one evaluation in the list to see its details, or two to compare them.</p></div>";

const HINTS = Object.freeze({
  [MODES.none]: "Tick one evaluation to see its details, or two to compare them.",
  [MODES.single]: "Showing the ticked evaluation. Tick a second one to compare.",
  [MODES.compare]: "Comparing the two ticked evaluations. Untick one to see a single evaluation.",
});

/** One entry in the list: a checkbox and what the evaluation was. */
export function runItemHtml(item, index) {
  const id = `run-pick-${index}`;
  const checked = item.checked ? " checked" : "";
  return `<li class="run-item${item.checked ? " selected" : ""}">`
    + `<input type="checkbox" id="${id}" data-run-id="${escapeHtml(item.id)}"${checked}>`
    + `<label for="${id}" class="run-item-body">`
    + `<span class="run-item-top"><span class="verdict verdict-${escapeHtml(item.kind)}"><span aria-hidden="true">`
    + `${escapeHtml(item.icon)}</span> ${escapeHtml(item.verdict)}</span>`
    + `<strong class="run-item-score">${escapeHtml(item.score)}</strong></span>`
    + `<span class="run-item-when">${escapeHtml(item.when)}</span>`
    + `<span class="run-item-line">${escapeHtml(item.passed)}</span>`
    + `<span class="run-item-line run-item-settings">${escapeHtml(item.settings)}</span></label></li>`;
}

function renderList() {
  const now = new Date();
  $(LIST).innerHTML = state.runs.map((entry, index) => runItemHtml(runListItem(entry, state.selectedRuns, now), index)).join("");
  $(LIST).hidden = !state.runs.length;
  $(HINT).textContent = state.runs.length ? HINTS[selectionMode(state.selectedRuns)] : "";
}

function renderView() {
  const root = $(VIEW);
  const picked = selectedEntries(state.selectedRuns, state.runs);
  const mode = selectionMode(picked.map((entry) => entry.id));
  if (!state.runs.length) root.innerHTML = NO_RUNS_HTML;
  else if (mode === MODES.single) renderRunDetail(root, picked[0]);
  else if (mode === MODES.compare) root.innerHTML = comparisonHtml(picked[0], picked[1]);
  else root.innerHTML = PICK_HTML;
}

/** Re-renders the list and the main pane from state. */
export function renderRunner() {
  state.selectedRuns = reconcileSelection(state.selectedRuns, state.runs);
  renderList();
  renderView();
  renderViewState();
}

/** Adds a finished evaluation at the top of the list, keeps it and selects it. */
export function addRun(entry) {
  if (!entry) return;
  state.runs = [entry, ...state.runs].slice(0, MAX_RUNS);
  state.selectedRuns = [entry.id];
  saveRun(entry).catch(reportStorageError);
  renderRunner();
}

function onPick(event) {
  const box = event.target;
  if (!box.matches("input[data-run-id]")) return;
  state.selectedRuns = toggleSelection(state.selectedRuns, box.dataset.runId, box.checked);
  renderList();
  renderView();
  $(`${LIST} input[data-run-id="${CSS.escape(box.dataset.runId)}"]`)?.focus();
}

export function initRunner() {
  $(LIST).addEventListener("change", onPick);
  initRunDetail($(VIEW));
}
