// View models for playground results and live progress (pure, no DOM).
// Everything is expressed in the app's plain vocabulary: evaluation, test, check,
// AI assistant, AI reviewer, and the four verdicts.

import { asPercent, formatPercent, skipReason, statusKind } from "../lib/format.js";
import { metricInfo } from "../lib/metric-catalog.js";
import { friendlyDate, humanizeId, passedOutOf, verdict, verdictIcon, verdictSentence } from "../lib/wording.js";

function list(value) {
  return Array.isArray(value) ? value : [];
}

function checkTitle(metric) {
  return metricInfo(metric).title || humanizeId(metric) || "Check";
}

/** "Needs 70%" ("" when there is no threshold). */
export function neededText(threshold) {
  const pct = asPercent(threshold);
  return pct === null ? "" : `needs ${pct}%`;
}

/** One scored check -> {title, kind, icon, verdict, score, needed, why, evidence}. */
export function checkView(score) {
  const kind = statusKind(score?.passed) === "pass" ? "pass" : "fail";
  return {
    title: checkTitle(score?.metric),
    kind,
    icon: verdictIcon(kind),
    verdict: verdict(kind),
    score: formatPercent(score?.score),
    needed: neededText(score?.threshold),
    why: String(score?.rationale || ""),
    evidence: list(score?.evidence).map(String).join("\n"),
  };
}

/** One skipped check -> {title, reason, details}. */
export function notCheckedView(skip) {
  return { title: checkTitle(skip?.metric), reason: skipReason(skip?.reason), details: String(skip?.reason || "") };
}

function testKind(result) {
  if (result?.observation?.error) return "error";
  return statusKind(result?.passed) === "pass" ? "pass" : "fail";
}

/** One test result -> view model. Tests that did not pass start expanded. */
export function testView(result) {
  const kind = testKind(result);
  return {
    id: String(result?.case_id ?? ""),
    kind,
    icon: verdictIcon(kind),
    verdict: verdict(kind),
    score: formatPercent(result?.weighted_score),
    open: kind !== "pass",
    error: String(result?.observation?.error || ""),
    checks: list(result?.scores).map(checkView),
    notChecked: list(result?.skipped).map(notCheckedView),
  };
}

function countPassed(tests) {
  return tests.filter((test) => test.kind === "pass").length;
}

/** Completed evaluation -> view model for the results panel (null for no data). */
export function runView(run, now = new Date()) {
  if (!run || typeof run !== "object") return null;
  const kind = statusKind(run.status);
  const tests = list(run.case_results).map(testView);
  return {
    kind,
    icon: verdictIcon(kind),
    verdict: verdict(kind),
    sentence: verdictSentence(kind),
    score: formatPercent(run.weighted_score),
    passed: passedOutOf(countPassed(tests), tests.length),
    when: friendlyDate(run.creation_ts, now),
    assistant: humanizeId(run.agent_id) || "AI assistant",
    tests,
  };
}

/** Short status for the step list and header pill: "Passed · 82%". */
export function runHeadline(run) {
  const view = runView(run);
  if (!view) return "";
  return view.score === "—" ? view.verdict : `${view.verdict} · ${view.score}`;
}

// ---------- Live progress ----------

/** "2 of 5 tests done" (or "2 tests done" before the total is known). */
export function progressLabel({ total = 0, casesDone = 0 } = {}) {
  if (total) return `${casesDone} of ${total} ${total === 1 ? "test" : "tests"} done`;
  return `${casesDone} ${casesDone === 1 ? "test" : "tests"} done`;
}

/** Whole percent of tests finished (0 when the total is unknown). */
export function progressPercent({ total = 0, casesDone = 0 } = {}) {
  if (!total) return 0;
  return Math.max(0, Math.min(100, Math.round((casesDone / total) * 100)));
}

const PROGRESS_TEXT = {
  case_started: (test) => `Asking the AI assistant: test ${test}`,
  observation: (test) => `Answer received for test ${test}`,
  metric_started: (test, check) => `Checking “${check}” on test ${test}`,
  metric_done: (test, check) => `Checked “${check}” on test ${test}`,
  metric_skipped: (test, check) => `Could not check “${check}” on test ${test}`,
  case_done: (test) => `Finished test ${test}`,
};

/** One progress event -> a plain sentence ("" when there is nothing to say). */
export function progressDetail(event) {
  const toText = PROGRESS_TEXT[event?.type];
  if (toText && event.case_id !== undefined) {
    return toText(String(event.case_id), event.metric ? checkTitle(event.metric) : "a check");
  }
  return String(event?.message || "");
}
