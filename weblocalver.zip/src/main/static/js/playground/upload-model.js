// What the Upload view says about the loaded settings (pure, no DOM): the AI
// assistant, the number of tests and checks, the files, and whether there are
// edits that are not in a downloaded copy yet.

import { escapeHtml } from "../lib/fragments.js";
import { fileRole } from "./editor-model.js";
import { sortedPaths } from "./workspace-model.js";

const NONE = "—";

/** 512 -> "512 bytes", 2048 -> "2.0 KB", 3 MB -> "3.0 MB". */
export function formatBytes(size) {
  const n = Math.max(0, Number(size) || 0);
  if (n < 1024) return `${n} ${n === 1 ? "byte" : "bytes"}`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function testSetLabel(dataset) {
  if (!dataset?.dataset_id) return NONE;
  return dataset.version ? `${dataset.dataset_id} (version ${dataset.version})` : dataset.dataset_id;
}

function extraChecks(customTests) {
  if (!customTests?.present) return "None";
  const names = Array.isArray(customTests.declared_scorers) ? customTests.declared_scorers : [];
  if (customTests.syntax_error) return "Has a mistake";
  return names.length ? names.join(", ") : "File found, none named";
}

function fileRows(files, datasetFile) {
  return sortedPaths(files).map((path) => {
    const file = files[path] || {};
    const role = file.kind === "binary" ? "Not a text file" : fileRole(path, datasetFile);
    return { path, role: role || "Other file", size: formatBytes(file.size) };
  });
}

/**
 * Loaded settings -> {assistant, agentId, tests, checks, testSet, extraChecks, address, files, fileCount}.
 * source: {files, agent, dataset, customTests}.
 */
export function bundleSummary(source = {}) {
  const agent = source.agent || {};
  const dataset = source.dataset || {};
  const files = fileRows(source.files || {}, agent.dataset_file);
  return {
    assistant: agent.name || agent.agent_id || "AI assistant",
    agentId: agent.agent_id || NONE,
    tests: String(dataset.cases ?? NONE),
    checks: String(dataset.metrics ?? NONE),
    testSet: testSetLabel(dataset),
    extraChecks: extraChecks(source.customTests),
    address: agent.base_url || "Not set in agent.yaml",
    files,
    fileCount: files.length,
  };
}

function factHtml(label, value) {
  return `<div class="fact"><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`;
}

function fileRowHtml(file) {
  return `<tr><th scope="row"><span class="file-path">${escapeHtml(file.path)}</span></th>`
    + `<td>${escapeHtml(file.role)}</td><td class="num">${escapeHtml(file.size)}</td></tr>`;
}

/** "What's loaded" markup for a bundleSummary() result; every value is escaped. */
export function summaryHtml(summary) {
  const files = summary.files.length
    ? '<div class="table-scroll"><table class="file-table"><caption class="sr-only">Files in these settings</caption>'
      + '<thead><tr><th scope="col">File</th><th scope="col">What it is</th><th scope="col">Size</th></tr></thead>'
      + `<tbody>${summary.files.map(fileRowHtml).join("")}</tbody></table></div>`
    : '<p class="muted-text">There are no files in these settings.</p>';
  return `<p class="loaded-name">${escapeHtml(summary.assistant)}</p>`
    + '<dl class="summary-grid">'
    + factHtml("Tests", summary.tests)
    + factHtml("Checks", summary.checks)
    + factHtml("AI assistant ID", summary.agentId)
    + factHtml("Test set", summary.testSet)
    + factHtml("Extra checks", summary.extraChecks)
    + factHtml("Address in agent.yaml", summary.address)
    + `</dl><h3 class="files-title">Files (${summary.fileCount})</h3>${files}`;
}

/** Note about unsaved edits: {tone, text}, or null when nothing is loaded. */
export function unsavedNote({ loaded, dirty, saved } = {}) {
  if (!loaded) return null;
  if (!dirty) return { tone: "info", text: "No changes since you loaded the file." };
  if (saved) return { tone: "ok", text: "Your changes are in the copy you downloaded." };
  return {
    tone: "warn",
    text: "You have changes that are only kept in this browser. Use “Download current settings” to keep them as a file.",
  };
}
