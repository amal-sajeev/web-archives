// Step 3, "Try it": check, start, follow progress, stop, and record results.

import { showToast } from "../ui/toast.js";
import { cancelRun, startRun, validateBundle } from "./bundle-api.js";
import { showCheckResult } from "./check.js";
import { updateCompareOptions } from "./compare.js";
import { friendlyError, runFailure, runStopped } from "./messages.js";
import { renderBusy, renderNotice, renderProgress, renderRun } from "./results.js";
import { progressLabel, runHeadline } from "./results-model.js";
import { RunStream } from "./run-stream.js";
import { renderSteps } from "./steps.js";
import { MAX_RUNS, reportStorageError, saveRun, state } from "./store.js";
import { $, pillKindForStatus, setStatus } from "./view.js";
import { refreshBundleMetadata } from "./workspace.js";

const RUNNING = "running";
const CANCEL_BUTTON = "#cancel-run";
const STOP_LABEL = "Stop evaluation";
const PROGRESS_EVENTS = new Set(["case_started", "observation", "metric_started"]);

let activeStream = null;
let counters = { total: 0, casesDone: 0 };

function resetCancelButton() {
  const button = $(CANCEL_BUTTON);
  button.disabled = false;
  button.textContent = STOP_LABEL;
}

function showRunning(text = `Running… ${progressLabel(counters)}`) {
  state.runningText = text;
  setStatus(text, RUNNING);
  renderSteps();
}

/** Stops following the current evaluation (closes SSE, clears polling). */
export function stopActiveRun() {
  if (activeStream) activeStream.stop();
  activeStream = null;
  state.stream = null;
  state.runningText = "";
  resetCancelButton();
  renderSteps();
}

function recordRun(run) {
  state.lastRun = run;
  state.runs = [run, ...state.runs].slice(0, MAX_RUNS);
  saveRun(run).catch(reportStorageError);
  updateCompareOptions();
}

function onDone(run) {
  stopActiveRun();
  renderRun(run);
  if (!run) return;
  recordRun(run);
  setStatus(runHeadline(run), pillKindForStatus(run.status));
  renderSteps();
}

function onFailure(notice, statusText, kind) {
  stopActiveRun();
  renderNotice(notice);
  setStatus(statusText, kind);
}

function countProgress(event) {
  renderProgress(counters, event);
}

const HANDLERS = {
  run_started(event) {
    counters.total = Number(event.total_cases) || 0;
    showRunning();
  },
  case_done(event) {
    counters.casesDone += 1;
    showRunning();
    countProgress(event);
  },
  metric_done: countProgress,
  metric_skipped: countProgress,
  playground_done(event) {
    onDone(event.run);
  },
  error(event) {
    onFailure({ tone: "bad", ...runFailure(event) }, "Could not finish", "bad");
  },
  run_cancelled(event) {
    onFailure({ tone: "stopped", ...runStopped(event) }, "Stopped", "warn");
  },
};

function handleEvent(event) {
  const handler = HANDLERS[event?.type];
  if (handler) handler(event);
  else if (PROGRESS_EVENTS.has(event?.type)) countProgress(event);
}

function onLost(err) {
  const notice = { tone: "bad", ...friendlyError(err, "run"), title: "We lost contact with the evaluation" };
  onFailure(notice, "Could not finish", "bad");
}

function follow(streamId) {
  counters = { total: 0, casesDone: 0 };
  state.stream = streamId;
  renderProgress(counters, null);
  showRunning("Running…");
  activeStream = new RunStream(streamId, {
    onEvent: handleEvent,
    onConnection: (mode) => showRunning(mode === "live" ? undefined : "Running… reconnecting"),
    onLost,
  }).start();
}

/** Builds the edited settings and checks them; throws with `.problems` when they need fixing. */
async function checkedBundle() {
  const blob = await refreshBundleMetadata();
  if (!state.selectedCases.length) throw new Error("Choose at least one test to include.");
  const result = (await validateBundle(blob)) || {};
  if (!result.valid) {
    showCheckResult(result);
    const error = new Error("The settings need fixing before they can be tried.");
    error.problems = Array.isArray(result.errors) && result.errors.length ? result.errors : [error.message];
    throw error;
  }
  return blob;
}

export async function runEvaluation() {
  if (state.stream) return;
  $("#test-config").disabled = true;
  setStatus("Getting ready…", RUNNING);
  renderBusy("Checking your settings before running them…");
  try {
    const blob = await checkedBundle();
    const started = await startRun(blob, {
      baseUrl: $("#base-url").value,
      reps: $("#reps").value,
      caseIds: state.selectedCases,
    });
    follow(started.stream_id);
  } catch (err) {
    onFailure({ tone: "bad", ...friendlyError(err, "run") }, "Could not start", "bad");
  }
}

export async function cancelActiveRun() {
  const id = state.stream;
  if (!id) return;
  const button = $(CANCEL_BUTTON);
  button.disabled = true;
  button.textContent = "Stopping…";
  try {
    await cancelRun(id);
  } catch (err) {
    resetCancelButton();
    if (err.status === 409) {
      showToast("The evaluation had already finished.", { kind: "info" });
      return;
    }
    const { title, text } = friendlyError(err, "stop");
    showToast(`${title}. ${text}`, { kind: "bad" });
  }
}
