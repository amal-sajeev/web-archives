// Workspace: summary tiles, extra checks, warnings, the "changed" badge, and the
// summary (AI assistant, tests) that the server derives from the edited files.

import { escapeHtml } from "../lib/fragments.js";
import { exportBundle, inspectBundle } from "./bundle-api.js";
import { reconcileSelection, renderCases } from "./cases.js";
import { plainProblem } from "./messages.js";
import { showFile } from "./editor.js";
import { renderFiles } from "./files.js";
import { renderSteps } from "./steps.js";
import { caseIds, cloneFiles, fileItems, isDirty, persistSoon, sortedPaths, state } from "./store.js";
import { toFiles } from "./workspace-model.js";
import { $ } from "./view.js";

const BASE_URL = "#base-url";

const NONE = "—";
const DEFAULT_TITLE = "AI assistant settings";

function statTile(label, value) {
  return `<div class="pg-stat"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value ?? NONE)}</strong></div>`;
}

function datasetLabel(dataset) {
  if (!dataset?.dataset_id) return NONE;
  return dataset.version ? `${dataset.dataset_id} (${dataset.version})` : dataset.dataset_id;
}

function countText(n, noun) {
  const count = Number(n) || 0;
  return `${count} ${noun}${count === 1 ? "" : "s"}`;
}

export function updateWorkspaceMeta() {
  const agent = state.agent || {};
  const dataset = state.dataset || {};
  $("#workspace-title").textContent = agent.name || agent.agent_id || DEFAULT_TITLE;
  $("#workspace-copy").textContent = `${countText(dataset.cases, "test")} · ${countText(dataset.metrics, "check")}`;
  $("#target-default").textContent = agent.base_url
    ? `Leave empty to use the address in agent.yaml: ${agent.base_url}`
    : "agent.yaml has no address, so please type one here.";
}

function renderWarnings() {
  const messages = [...state.warnings];
  if (state.metadataError) messages.push(`The summary could not be updated after your last change. ${plainProblem(state.metadataError)}`);
  const box = $("#pg-warning");
  const text = messages.join(" ");
  box.hidden = !text;
  if (box.textContent !== text) box.textContent = text;
}

export function renderSummary() {
  const agent = state.agent || {};
  const dataset = state.dataset || {};
  $("#pg-stats").innerHTML = [
    statTile("AI assistant", agent.name || agent.agent_id || NONE),
    statTile("Tests", dataset.cases ?? NONE),
    statTile("Checks", dataset.metrics ?? NONE),
    statTile("Test set", datasetLabel(dataset)),
  ].join("");
  $(BASE_URL).placeholder = agent.base_url || "https://…";
  renderWarnings();
  updateWorkspaceMeta();
}

function customTestRow(name) {
  return `<div class="custom-test-row"><span class="custom-test-check" aria-hidden="true"></span><span>${escapeHtml(name)}</span></div>`;
}

export function renderCustomTests() {
  const info = state.customTests || {};
  const panel = $("#custom-tests-panel");
  panel.hidden = !info.present;
  if (!info.present) return;
  const declared = Array.isArray(info.declared_scorers) ? info.declared_scorers : [];
  $("#custom-tests-count").textContent = countText(declared.length, "extra check");
  const chip = $("#custom-tests-state");
  chip.textContent = info.syntax_error ? "! Has a mistake" : "✓ Found";
  chip.className = info.syntax_error ? "status-chip bad" : "status-chip ok";
  $("#custom-tests-list").innerHTML = declared.length
    ? declared.map(customTestRow).join("")
    : '<p class="muted-text">custom_tests.py is there, but no extra checks are named in it.</p>';
}

export function updateDirtyBadge() {
  $("#dirty-badge").hidden = !isDirty();
  renderSteps();
}

export function selectFile(path) {
  state.selected = path && state.files[path] ? path : null;
  showFile(state.selected);
  renderFiles();
}

/** Re-renders the whole workspace from state and shows it. */
export function showWorkspace() {
  $("#load-panel").hidden = true;
  $("#workspace").hidden = false;
  renderSummary();
  renderCustomTests();
  renderCases();
  const paths = sortedPaths();
  selectFile(state.files[state.selected] ? state.selected : paths[0]);
  updateDirtyBadge();
}

export function showLoadPanel() {
  $("#workspace").hidden = true;
  $("#load-panel").hidden = false;
  renderSteps();
  $("#zip-input").value = "";
  $(BASE_URL).value = "";
}

/** Applies a fresh /inspect result as a newly loaded bundle. */
export function loadInspection(data) {
  state.files = toFiles(data.files);
  state.original = cloneFiles(state.files);
  state.root = data.root || "";
  state.agent = data.agent || null;
  state.dataset = data.dataset || null;
  state.customTests = data.custom_tests || null;
  state.warnings = Array.isArray(data.warnings) ? data.warnings : [];
  state.metadataError = "";
  state.selected = sortedPaths()[0] || null;
  state.selectedCases = caseIds(state.dataset);
}

function mergeInspection(data) {
  state.root = data.root || "";
  state.agent = data.agent || state.agent;
  state.dataset = data.dataset || state.dataset;
  state.customTests = data.custom_tests || state.customTests;
  state.warnings = Array.isArray(data.warnings) ? data.warnings : [];
  state.metadataError = "";
  reconcileSelection();
}

/** Re-derives agent/dataset metadata from the edited files. Resolves the bundle ZIP. */
export async function refreshBundleMetadata() {
  const blob = await exportBundle(fileItems(), "");
  const data = await inspectBundle(blob);
  mergeInspection(data);
  renderSummary();
  renderCustomTests();
  renderCases();
  updateDirtyBadge();
  persistSoon();
  return blob;
}

/** Surfaces a metadata refresh failure next to the run setup (not swallowed). */
export function reportMetadataError(err) {
  state.metadataError = err?.message || String(err);
  renderWarnings();
}
