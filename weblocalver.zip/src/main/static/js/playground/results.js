// Results panel: live progress and the completed evaluation. The *Html functions
// are pure (tested in Node); every interpolated value is escaped.

import { escapeHtml } from "../lib/fragments.js";
import { noticeHtml, technicalDetailsHtml } from "./messages.js";
import { progressDetail, progressLabel, progressPercent, runView } from "./results-model.js";
import { $ } from "./view.js";

const RESULTS = "#results";

export const EMPTY_RESULTS_HTML = '<div class="empty-hint">'
  + '<p class="empty-hint-title">No results yet</p>'
  + "<p>Press <strong>Run evaluation</strong> to try these settings. The result will appear here.</p></div>";

function verdictBadge(kind, icon, text) {
  return `<span class="verdict verdict-${escapeHtml(kind)}"><span aria-hidden="true">${escapeHtml(icon)}</span> ${escapeHtml(text)}</span>`;
}

function checkHtml(check) {
  const needed = check.needed ? ` <span class="muted-text">(${escapeHtml(check.needed)})</span>` : "";
  const why = check.why ? `<p class="check-why">${escapeHtml(check.why)}</p>` : "";
  const evidence = check.evidence
    ? `<details class="tech-note"><summary>Show details</summary><pre>${escapeHtml(check.evidence)}</pre></details>`
    : "";
  return `<li class="check-row">`
    + `<p class="check-line">${verdictBadge(check.kind, check.icon, check.verdict)} `
    + `<strong>${escapeHtml(check.title)}</strong> <span class="check-score">${escapeHtml(check.score)}</span>${needed}</p>`
    + `${why}${evidence}</li>`;
}

function notCheckedHtml(item) {
  return `<li class="check-row check-skipped"><p class="check-line"><span class="verdict verdict-none">Not checked</span> `
    + `<strong>${escapeHtml(item.title)}</strong></p><p class="check-why">${escapeHtml(item.reason)}</p>`
    + `${technicalDetailsHtml(item.details)}</li>`;
}

function testBodyHtml(test) {
  const error = test.error
    ? noticeHtml({ tone: "bad", title: "The AI assistant could not answer this test", details: test.error })
    : "";
  const rows = test.checks.map(checkHtml).join("") + test.notChecked.map(notCheckedHtml).join("");
  const checks = rows ? `<ul class="check-list">${rows}</ul>` : '<p class="muted-text">No checks were recorded for this test.</p>';
  return `<div class="test-body">${error}${checks}</div>`;
}

/** One expandable test row. */
export function testHtml(test) {
  return `<details class="test-row test-${escapeHtml(test.kind)}"${test.open ? " open" : ""}><summary>`
    + `${verdictBadge(test.kind, test.icon, test.verdict)}`
    + `<span class="test-name">Test ${escapeHtml(test.id)}</span>`
    + `<span class="test-score">${escapeHtml(test.score)}</span></summary>${testBodyHtml(test)}</details>`;
}

function heroHtml(view) {
  const when = view.when ? ` · ${escapeHtml(view.when)}` : "";
  return `<div class="result-hero result-${escapeHtml(view.kind)}">`
    + `<p class="result-verdict"><span class="result-icon" aria-hidden="true">${escapeHtml(view.icon)}</span>${escapeHtml(view.verdict)}</p>`
    + `<p class="result-sentence">${escapeHtml(view.sentence)}</p>`
    + `<p class="result-facts"><span class="result-score">${escapeHtml(view.score)}</span> overall score · ${escapeHtml(view.passed)}</p>`
    + `<p class="result-meta">${escapeHtml(view.assistant)}${when}</p></div>`;
}

/** Full results markup for a completed evaluation. */
export function runHtml(run, now = new Date()) {
  const view = runView(run, now);
  if (!view) return noticeHtml({ tone: "warn", title: "No result came back", text: "The evaluation finished but sent no result. Try running it again." });
  const tests = view.tests.length
    ? `<h4 class="tests-title">Tests</h4>${view.tests.map(testHtml).join("")}`
    : '<p class="muted-text">No tests were run.</p>';
  return heroHtml(view) + tests;
}

export function renderRun(run) {
  $(RESULTS).innerHTML = runHtml(run);
}

export function renderEmptyResults() {
  $(RESULTS).innerHTML = EMPTY_RESULTS_HTML;
}

/** Replaces the results with a notice (see messages.js noticeHtml). */
export function renderNotice(options) {
  $(RESULTS).innerHTML = noticeHtml(options);
}

/** Replaces the results with a busy line. */
export function renderBusy(text) {
  $(RESULTS).innerHTML = `<p class="busy-line"><span class="spinner" aria-hidden="true"></span>${escapeHtml(text)}</p>`;
}

// ---------- Progress ----------

export const PROGRESS_HTML = '<div class="run-progress">'
  + '<p class="progress-head"><strong>Evaluation in progress</strong> <span class="progress-label">Starting…</span></p>'
  + '<progress class="pg-progress" max="100" value="0" aria-label="Evaluation progress"></progress>'
  + '<p class="progress-detail">Getting ready…</p></div>';

/** Updates (or creates) the live progress block. counters: {total, casesDone}. */
export function renderProgress(counters, event) {
  const root = $(RESULTS);
  if (!root.querySelector(".run-progress")) root.innerHTML = PROGRESS_HTML;
  const block = root.querySelector(".run-progress");
  block.querySelector(".pg-progress").value = progressPercent(counters);
  block.querySelector(".progress-label").textContent = progressLabel(counters);
  const detail = progressDetail(event);
  if (detail) block.querySelector(".progress-detail").textContent = detail;
}
