// Plain-language messages for the playground (pure, no DOM). Server wording is
// translated into everyday sentences; the raw text is kept for a "Technical details"
// disclosure so nothing is lost for the people who need it.

import { escapeHtml } from "../lib/fragments.js";

const FILE_FIX = "Open it in the Editor and correct it.";

/** [pattern, (match) => plain sentence]. First match wins. */
const PROBLEM_RULES = [
  [/^agent\.yaml is missing agent_id/i, () => "The AI assistant has no ID. Add agent_id to agent.yaml."],
  [/^agent\.yaml is missing name/i, () => "The AI assistant has no name. Add name to agent.yaml."],
  [/^Dataset contains no cases/i, () => "There are no tests yet. Add at least one test to the test file."],
  [/^Dataset contains no metrics/i, () => "No checks are set up. Add at least one check to the test file."],
  [/should not be included: (.+)$/i, (m) => `Remove ${m[1]}. It may contain private information.`],
  [/^custom_tests\.py could not be loaded/i, () => `The extra checks file (custom_tests.py) has a mistake. ${FILE_FIX}`],
  [/overrides an existing scorer: (.+)$/i, (m) => `An extra check uses the same name as a built-in check: ${m[1]}.`],
  [/did not register declared scorer\(s\): (.+)$/i, (m) => `These extra checks are named but not set up: ${m[1]}.`],
  [/^Upload exactly one agent configuration folder/i, () => "The .zip file should hold one folder with one agent.yaml file in it."],
  [/does not contain agent\.yaml/i, () => "The .zip file has no agent.yaml, the file that describes the AI assistant."],
  [/^agent\.yaml is invalid/i, () => `agent.yaml has a mistake and could not be read. ${FILE_FIX}`],
  [/^Configured dataset file is missing: (.+)$/i, (m) => `The test file ${m[1]} named in agent.yaml is missing.`],
  [/^Dataset is invalid/i, () => `The test file has a mistake and could not be read. ${FILE_FIX}`],
  [/^Configured metrics stub file is missing: (.+)$/i, (m) => `The file ${m[1]} named in agent.yaml is missing.`],
  [/zip/i, () => "This is not a readable .zip file."],
];

/** One server problem message -> a plain sentence (unknown messages pass through). */
export function plainProblem(message) {
  const text = String(message ?? "").trim();
  for (const [pattern, toText] of PROBLEM_RULES) {
    const match = pattern.exec(text);
    if (match) return toText(match);
  }
  return text || "Something is not right with these settings.";
}

const ACTION_TITLES = Object.freeze({
  load: "This file could not be opened",
  check: "The settings could not be checked",
  run: "The evaluation could not start",
  save: "The settings could not be downloaded",
  stop: "The evaluation could not be stopped",
});

const UNREACHABLE = "The evaluation service could not be reached. Check your connection and try again.";

/**
 * Error from an API call -> {title, text, details}. `action` is one of
 * load | check | run | save | stop. `details` holds the raw message.
 */
export function friendlyError(err, action = "run") {
  const raw = String(err?.message || err || "").trim();
  const title = ACTION_TITLES[action] || ACTION_TITLES.run;
  if (err?.problems?.length) {
    return { title, text: "Please fix these problems first:", items: err.problems.map(plainProblem), details: err.problems.join("\n") };
  }
  if (err?.status === 0) return { title, text: UNREACHABLE, details: raw };
  return { title, text: plainProblem(raw), details: raw };
}

const RUN_FAILURE_RULES = [
  [/unreachable|connect|refused|resolve|getaddrinfo|No route/i, "The AI assistant could not be reached. Check its address on the Runner page."],
  [/timeout|timed out/i, "The AI assistant took too long to answer."],
  [/credential|Vertex|judge|Application Default/i, "The AI reviewer is not available right now."],
];

/** Run `error` event -> {title, text, details}. */
export function runFailure(event) {
  const raw = String(event?.detail || "").trim();
  const rule = RUN_FAILURE_RULES.find(([pattern]) => pattern.test(raw));
  return {
    title: "The evaluation could not finish",
    text: rule ? rule[1] : "Something went wrong while running the tests.",
    details: raw,
  };
}

/** Run `run_cancelled` event -> {title, text, details}. */
export function runStopped(event) {
  return { title: "The evaluation was stopped", text: "It was stopped before it finished, so there is no result.", details: String(event?.detail || "") };
}

/** Collapsed "Technical details" block ("" when there is nothing to show). */
export function technicalDetailsHtml(details) {
  const text = String(details ?? "").trim();
  if (!text) return "";
  return `<details class="tech-note"><summary>Technical details</summary><pre>${escapeHtml(text)}</pre></details>`;
}

const TONE_ICONS = Object.freeze({ ok: "✓", warn: "!", bad: "×", stopped: "■", info: "i" });

/**
 * Message block: icon + title, a plain sentence, an optional bullet list and the
 * technical details. tone: ok | warn | bad | stopped | info.
 */
export function noticeHtml({ tone = "info", title = "", text = "", items = [], details = "" } = {}) {
  const icon = TONE_ICONS[tone] || TONE_ICONS.info;
  const list = items.length ? `<ul class="notice-list">${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>` : "";
  const body = text ? `<p>${escapeHtml(text)}</p>` : "";
  return `<div class="notice notice-${escapeHtml(tone)}">`
    + `<p class="notice-title"><span class="notice-icon" aria-hidden="true">${icon}</span>${escapeHtml(title)}</p>`
    + `${body}${list}${technicalDetailsHtml(details)}</div>`;
}

/** "Check settings" result -> notice options. result: {valid, errors, custom_tests}. */
export function checkNotice(result) {
  const errors = Array.isArray(result?.errors) ? result.errors : [];
  if (result?.valid) {
    const loaded = result.custom_tests?.loaded_scorers || [];
    const extra = loaded.length ? ` Extra checks found: ${loaded.join(", ")}.` : "";
    return { tone: "ok", title: "No problems found", text: `These settings are ready to try.${extra}` };
  }
  const count = errors.length;
  if (!count) return { tone: "warn", title: "The check did not pass", text: "No reason was given. Try checking again." };
  return {
    tone: "warn",
    title: count === 1 ? "1 problem to fix" : `${count} problems to fix`,
    items: errors.map(plainProblem),
    details: errors.join("\n"),
  };
}
