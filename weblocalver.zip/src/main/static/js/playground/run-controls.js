// Run / Stop buttons on the Runner page: Run shows while nothing is running and
// needs at least one test; Stop shows while an evaluation runs.

import { state } from "./store.js";
import { $ } from "./view.js";

const RUN_BUTTON = "#test-config";
const STOP_BUTTON = "#cancel-run";
const STOP_LABEL = "Stop evaluation";

/** Puts the Stop button back to its normal label. */
export function resetStopButton() {
  const button = $(STOP_BUTTON);
  button.disabled = false;
  button.textContent = STOP_LABEL;
}

/** Shows the Stop button as busy while the stop request is sent. */
export function markStopping() {
  const button = $(STOP_BUTTON);
  button.disabled = true;
  button.textContent = "Stopping…";
}

/** Disables Run while it is getting ready (checking the settings). */
export function markStarting() {
  $(RUN_BUTTON).disabled = true;
}

/** Shows Run or Stop from state. */
export function updateRunControls() {
  const running = Boolean(state.stream);
  const run = $(RUN_BUTTON);
  run.hidden = running;
  run.disabled = state.selectedCases.length === 0;
  $(STOP_BUTTON).hidden = !running;
  const hint = $("#run-hint");
  hint.hidden = running || state.selectedCases.length > 0;
}
