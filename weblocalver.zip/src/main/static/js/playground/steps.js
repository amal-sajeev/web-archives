// Renders the 1-2-3-4 step list and keeps each step's buttons in the right state.
// The step rules live in steps-model.js.

import { runHeadline } from "./results-model.js";
import { stateWord, stepModel } from "./steps-model.js";
import { isDirty, state } from "./store.js";
import { $ } from "./view.js";

/** Current page state -> the flow input for stepModel(). */
export function currentFlow() {
  const loaded = Object.keys(state.files).length > 0;
  return {
    loaded,
    assistant: state.agent?.name || state.agent?.agent_id || "",
    checking: state.checking,
    check: state.check,
    running: Boolean(state.stream),
    runningText: state.runningText,
    noTestsChosen: loaded && state.selectedCases.length === 0,
    lastResult: runHeadline(state.lastRun),
    dirty: loaded && isDirty(),
    saved: state.saved,
  };
}

function renderStep(step) {
  const item = document.querySelector(`[data-step="${step.n}"]`);
  if (!item) return;
  item.dataset.state = step.state;
  item.querySelector(".step-status").textContent = step.status;
  item.querySelector(".step-state").textContent = stateWord(step.state);
  if (step.current) item.setAttribute("aria-current", "step");
  else item.removeAttribute("aria-current");
}

function setVisible(selector, visible) {
  const node = $(selector);
  if (node) node.hidden = !visible;
}

function updateButtons(flow) {
  setVisible("#change-config", flow.loaded);
  setVisible("#reset-config", flow.loaded && flow.dirty);
  setVisible("#validate-config", flow.loaded);
  setVisible("#export-config", flow.loaded);
  $("#validate-config").disabled = !flow.loaded || flow.checking;
  $("#export-config").disabled = !flow.loaded;
  setVisible("#test-config", flow.loaded && !flow.running);
  setVisible("#cancel-run", flow.running);
  $("#test-config").disabled = !flow.loaded || state.selectedCases.length === 0;
}

/** Re-renders the step list and the step buttons from state. */
export function renderSteps() {
  const flow = currentFlow();
  for (const step of stepModel(flow)) renderStep(step);
  updateButtons(flow);
}
