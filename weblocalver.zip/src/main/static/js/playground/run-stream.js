// Live run transport: Server-Sent Events first, polling only after an SSE error.
// Events carry a monotonic `seq`, so both transports share one cursor without
// double-counting. The stream stops itself on a terminal event.

import { fetchFinishedRun, fetchStreamEvents, streamUrl } from "./bundle-api.js";

export const TERMINAL_EVENTS = new Set(["playground_done", "error", "run_cancelled"]);
const POLL_INTERVAL_MS = 1000;

/** Terminal event equivalent to a bare run_done summary (null when there is none). */
export function summaryEvent(runDone) {
  if (!runDone) return null;
  const detail = String(runDone.error_detail || "");
  if (/cancel/i.test(detail)) return { type: "run_cancelled", detail: "The evaluation was cancelled." };
  return { type: "error", detail: detail || `The evaluation ended with status ${runDone.status || "unknown"}.` };
}

export class RunStream {
  /**
   * @param {string} streamId
   * @param {{onEvent: Function, onConnection?: Function, onLost?: Function}} handlers
   *   onEvent(event) for every new event; onConnection('live'|'reconnecting');
   *   onLost(error) when the stream can no longer be followed.
   */
  constructor(streamId, handlers) {
    this.streamId = streamId;
    this.handlers = handlers;
    this.lastSeq = 0;
    this.done = false;
    this.source = null;
    this.pollTimer = null;
    this.polling = false;
    this.runDone = null;
  }

  start() {
    if (typeof EventSource === "undefined") {
      this.startPolling();
      return this;
    }
    const source = new EventSource(streamUrl(this.streamId));
    source.onopen = () => this.onOpen();
    source.onmessage = (message) => this.onMessage(message.data);
    source.onerror = () => this.onSseError();
    this.source = source;
    return this;
  }

  /** Closes the EventSource and clears polling. Safe to call repeatedly. */
  stop() {
    this.done = true;
    if (this.source) this.source.close();
    this.source = null;
    this.stopPolling();
  }

  onOpen() {
    if (this.done) return;
    this.stopPolling();
    this.handlers.onConnection?.("live");
  }

  onMessage(raw) {
    let event;
    try {
      event = JSON.parse(raw);
    } catch (err) {
      console.warn("Ignoring a malformed stream event", err);
      return;
    }
    this.accept(event);
  }

  onSseError() {
    if (this.done) return;
    this.handlers.onConnection?.("reconnecting");
    this.startPolling();
  }

  /** Applies one event unless already seen; stops after a terminal event. */
  accept(event) {
    if (this.done || !event || typeof event !== "object") return;
    const seq = Number(event.seq) || 0;
    if (seq && seq <= this.lastSeq) return;
    this.lastSeq = seq || this.lastSeq + 1;
    if (event.type === "run_done") this.runDone = event;
    this.handlers.onEvent(event);
    if (TERMINAL_EVENTS.has(event.type)) this.stop();
  }

  startPolling() {
    if (this.pollTimer || this.done) return;
    this.pollTimer = window.setInterval(() => this.poll(), POLL_INTERVAL_MS);
    this.poll();
  }

  stopPolling() {
    if (this.pollTimer) window.clearInterval(this.pollTimer);
    this.pollTimer = null;
  }

  /** One polling round; skipped while a previous round is still in flight. */
  async poll() {
    if (this.done || this.polling) return;
    this.polling = true;
    try {
      const data = await fetchStreamEvents(this.streamId, this.lastSeq);
      for (const event of data?.events || []) this.accept(event);
      if (data?.done && !this.done) await this.finishWithoutTerminal();
    } catch (err) {
      this.onPollError(err);
    } finally {
      this.polling = false;
    }
  }

  onPollError(err) {
    if (err?.status === 404) {
      this.stop();
      this.handlers.onLost?.(new Error("The run is no longer available on the server."));
      return;
    }
    console.warn("Polling the run stream failed; retrying", err);
  }

  /**
   * The stream finished without playground_done / error / run_cancelled: fetch the
   * runner's run_done summary when there is one, otherwise fetch the stored run (e.g. a cancelled run
   * ends with run_done {status: "ERROR", error_detail: "cancelled"} and nothing else).
   */
  async finishWithoutTerminal() {
    const summary = summaryEvent(this.runDone);
    if (summary) {
      this.accept(summary);
      return;
    }
    try {
      const run = await fetchFinishedRun(this.streamId);
      this.accept({ type: "playground_done", run });
    } catch (err) {
      this.stop();
      this.handlers.onLost?.(err);
    }
  }
}
