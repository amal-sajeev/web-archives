// "AI reviewer settings" dialog: the non-secret settings this service uses to mark answers.

import { escapeHtml } from "../lib/fragments.js";
import { fetchEnvironment } from "./bundle-api.js";
import { noticeHtml } from "./messages.js";
import { state } from "./store.js";
import { $ } from "./view.js";

const FIELDS = [
  ["AI reviewer model", "judge_model"],
  ["Reviews per answer", "judge_samples"],
  ["Retries if the AI reviewer fails", "judge_retries"],
  ["Answers reviewed at the same time", "judge_concurrency"],
  ["Tests run at the same time", "case_concurrency"],
  ["Text comparison model", "embedding_model"],
  ["Where check settings come from", "metrics_source"],
  ["Cloud region", "project_location"],
  ["Sign-in method", "auth_mode"],
  ["Service version", "service_version"],
];
const AUTH_MODES = { vertex: "Google Cloud (Vertex AI)", "developer-api": "Developer API key" };

function display(key, value) {
  if (value === null || value === undefined || value === "") return "Not set";
  return key === "auth_mode" ? AUTH_MODES[value] || value : value;
}

/** Definition grid for the environment payload. */
export function environmentHtml(env) {
  const rows = FIELDS.map(([label, key]) => `<dt>${escapeHtml(label)}</dt><dd>${escapeHtml(display(key, env?.[key]))}</dd>`);
  return `<dl class="env-grid">${rows.join("")}</dl>`;
}

async function loadEnvironment() {
  const body = $("#environment-details-body");
  try {
    state.environment = await fetchEnvironment();
    body.innerHTML = environmentHtml(state.environment);
  } catch (err) {
    body.innerHTML = noticeHtml({ tone: "warn", title: "The AI reviewer settings could not be loaded", text: "Close this window and try again.", details: err?.message || String(err) });
  }
}

export function initEnvironment() {
  const dialog = $("#environment-dialog");
  $("#environment-details").addEventListener("click", () => {
    dialog.showModal();
    loadEnvironment();
  });
  $("#close-environment").addEventListener("click", () => dialog.close());
}
