// Playground state plus its browser-local persistence (IndexedDB). The data rules
// (what is saved, how edits are detected) live in workspace-model.js. One cached
// connection per page; evaluation history lives in its own object store.

import { showToast } from "../ui/toast.js";
import { entryFromRecord } from "./runner-list-model.js";
import * as model from "./workspace-model.js";

const DB_NAME = "ctna-config-playground";
const DB_VERSION = 2;
const WORKSPACE_STORE = "workspace";
const RUNS_STORE = "runs";
const WORKSPACE_KEY = "current";
const READ_WRITE = "readwrite";
const READ_ONLY = "readonly";
const SAVE_DELAY_MS = 400;
export const MAX_RUNS = 20;

/** The single mutable page state shared by the playground modules. */
export const state = { ...model.emptyWorkspace(), ...model.emptySession() };

export const normalizeState = (target = state) => model.normalizeState(target);
export const snapshot = (source = state) => model.snapshot(source);
export const applySnapshot = (saved, target = state) => model.applySnapshot(saved, target);
export const resetState = (target = state) => model.resetState(target);
export const sortedPaths = (files = state.files) => model.sortedPaths(files);
export const fileItems = (files = state.files) => model.fileItems(files);
export const isDirty = (files = state.files, original = state.original) => model.isDirty(files, original);
export const { caseIds, cloneFiles } = model;

// ---------- IndexedDB ----------

let dbPromise = null;

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function upgrade(db) {
  if (!db.objectStoreNames.contains(WORKSPACE_STORE)) db.createObjectStore(WORKSPACE_STORE);
  if (!db.objectStoreNames.contains(RUNS_STORE)) db.createObjectStore(RUNS_STORE, { autoIncrement: true });
}

/** One cached connection per page; a failed open is retried on the next call. */
function openDb() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => upgrade(request.result);
      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => {
          db.close();
          dbPromise = null;
        };
        resolve(db);
      };
      request.onerror = () => reject(request.error);
    }).catch((err) => {
      dbPromise = null;
      throw err;
    });
  }
  return dbPromise;
}

/** Runs `work(stores)` in one transaction; resolves with its result once committed. */
async function withStores(names, mode, work) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(names, mode);
    const stores = names.map((name) => tx.objectStore(name));
    let result;
    Promise.resolve(work(...stores)).then((value) => { result = value; }, reject);
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export function saveWorkspace() {
  const data = snapshot();
  return withStores([WORKSPACE_STORE], READ_WRITE, (store) => { store.put(data, WORKSPACE_KEY); });
}

/** Loads the saved workspace; migrates the v1 layout that kept runs inside it. */
export async function loadWorkspace() {
  const saved = await withStores([WORKSPACE_STORE], READ_ONLY, (store) => requestResult(store.get(WORKSPACE_KEY)));
  if (saved && Array.isArray(saved.runs) && saved.runs.length) {
    for (const run of [...saved.runs].reverse()) await saveRun({ savedAt: Date.now(), run });
    delete saved.runs;
  }
  return saved || null;
}

/** Appends an evaluation entry ({id, savedAt, meta, run}) and trims the history to MAX_RUNS. */
export function saveRun(entry) {
  const record = JSON.parse(JSON.stringify({ ...entry, savedAt: entry.savedAt || Date.now() }));
  return withStores([RUNS_STORE], READ_WRITE, async (store) => {
    store.add(record);
    const keys = await requestResult(store.getAllKeys());
    keys.slice(0, Math.max(0, keys.length - MAX_RUNS)).forEach((key) => store.delete(key));
  });
}

/** Evaluation history as entries ({id, savedAt, meta, run}), newest first. */
export async function loadRuns() {
  const records = await withStores([RUNS_STORE], READ_ONLY, (store) => requestResult(store.getAll()));
  return (records || []).map(entryFromRecord).filter(Boolean).reverse().slice(0, MAX_RUNS);
}

export function clearStorage() {
  return withStores([WORKSPACE_STORE, RUNS_STORE], READ_WRITE, (workspace, runs) => {
    workspace.clear();
    runs.clear();
  });
}

export function clearRuns() {
  return withStores([RUNS_STORE], READ_WRITE, (store) => { store.clear(); });
}

// ---------- Debounced saving ----------

let saveTimer = null;
let warnedPersist = false;

export function reportStorageError(err) {
  console.warn("Playground browser storage failed", err);
  if (warnedPersist) return;
  warnedPersist = true;
  showToast("Your changes could not be kept in this browser. Use “Download current settings” on the Upload page to keep them.", { kind: "warn" });
}

/** Saves the workspace shortly after the last change (coalesces keystrokes). */
export function persistSoon() {
  window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    saveWorkspace().catch(reportStorageError);
  }, SAVE_DELAY_MS);
}

/** Saves immediately (e.g. after an import), cancelling any pending save. */
export function persistNow() {
  window.clearTimeout(saveTimer);
  return saveWorkspace().catch(reportStorageError);
}

export function cancelPendingSave() {
  window.clearTimeout(saveTimer);
}
