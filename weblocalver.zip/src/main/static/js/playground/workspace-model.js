// Workspace data rules (pure, no DOM or storage): what is saved in the browser,
// how a saved copy is restored, and how edits are detected.
// Only the workspace (files, metadata, test selection) is persisted here; finished
// evaluations live in their own store. The live stream, check result, ticked
// evaluations and evaluator settings are session-only, so a reload never leaves
// the Run button stuck.

export const PERSISTED_KEYS = Object.freeze([
  "files", "root", "agent", "dataset", "customTests", "warnings", "selected", "original", "selectedCases",
]);

export function emptyWorkspace() {
  return {
    files: {}, root: "", agent: null, dataset: null, customTests: null, warnings: [],
    selected: null, original: null, selectedCases: [],
  };
}

export function emptySession() {
  return {
    runs: [], selectedRuns: [], stream: null, environment: null, metadataError: "",
    check: null, checking: false, saved: false, runningText: "",
  };
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

export function cloneFiles(files) {
  return JSON.parse(JSON.stringify(files || {}));
}

export function caseIds(dataset) {
  const items = Array.isArray(dataset?.case_items) ? dataset.case_items : [];
  return items.map((item) => item.id);
}

/** Coerces the collection fields into their expected shapes (in place). */
export function normalizeState(target) {
  target.files = isPlainObject(target.files) ? target.files : {};
  target.selectedCases = Array.isArray(target.selectedCases) ? target.selectedCases : [];
  target.warnings = Array.isArray(target.warnings) ? target.warnings : [];
  target.runs = Array.isArray(target.runs) ? target.runs : [];
  target.selectedRuns = Array.isArray(target.selectedRuns) ? target.selectedRuns : [];
  return target;
}

/** Plain, persistable copy of the workspace (never session fields or runs). */
export function snapshot(source) {
  const out = {};
  for (const key of PERSISTED_KEYS) out[key] = source[key];
  return JSON.parse(JSON.stringify(out));
}

/** Replaces the workspace with a saved snapshot; session fields reset to defaults. */
export function applySnapshot(saved, target) {
  Object.assign(target, emptyWorkspace(), emptySession());
  for (const key of PERSISTED_KEYS) {
    if (saved && saved[key] !== undefined) target[key] = saved[key];
  }
  normalizeState(target);
  if (!isPlainObject(target.original)) target.original = cloneFiles(target.files);
  if (!target.selectedCases.length) target.selectedCases = caseIds(target.dataset);
  return target;
}

/** Clears the workspace and session fields (in place). */
export function resetState(target) {
  Object.assign(target, emptyWorkspace(), emptySession());
  return target;
}

export function sortedPaths(files) {
  return Object.keys(files || {}).sort((a, b) => a.localeCompare(b));
}

/** Files as the export API expects them: [{path, content, encoding, kind, size}]. */
export function fileItems(files) {
  return Object.entries(files || {}).map(([path, file]) => ({ path, ...file }));
}

/** /inspect file list -> {path: {content, encoding, kind, size}}. */
export function toFiles(items) {
  const files = {};
  for (const item of items || []) {
    files[item.path] = { content: item.content, encoding: item.encoding, kind: item.kind, size: item.size };
  }
  return files;
}

function sameFile(a, b) {
  return Boolean(a) && Boolean(b) && a.content === b.content && a.kind === b.kind && a.size === b.size;
}

/** True when the files differ from the originally loaded bundle. */
export function isDirty(files, original) {
  const current = files || {};
  const base = original || {};
  const changed = Object.keys(current).some((path) => !sameFile(current[path], base[path]));
  return changed || Object.keys(base).some((path) => !current[path]);
}

/** Keeps only selected test ids that still exist; selects all when none remain. */
export function reconcileCases(selected, dataset) {
  const ids = caseIds(dataset);
  const known = new Set(ids);
  const kept = (selected || []).filter((id) => known.has(id));
  return kept.length ? kept : ids;
}
