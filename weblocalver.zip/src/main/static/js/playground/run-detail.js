// One evaluation in full on the Runner page. The *Html functions are pure (tested
// in Node); every interpolated value is escaped. The rules live in run-detail-model.js.

import { escapeHtml } from "../lib/fragments.js";
import { noticeHtml, technicalDetailsHtml } from "./messages.js";
import { TEST_FILTERS, filterTests, runDetailView } from "./run-detail-model.js";

const FILTER_LABELS = Object.freeze({ all: "All tests", failed: "Did not pass", errors: "Could not answer" });
const NOTHING = '<span class="cell-none">—</span>';

let filter = "all";
let current = null;
const openTests = new Set();

function badgeHtml(kind, icon, text) {
  return `<span class="verdict verdict-${escapeHtml(kind)}"><span aria-hidden="true">${escapeHtml(icon)}</span> ${escapeHtml(text)}</span>`;
}

function factsHtml(rows, className) {
  const items = rows.map((row) => `<div class="fact"><dt>${escapeHtml(row.label)}</dt><dd>${escapeHtml(row.value)}</dd></div>`);
  return `<dl class="${className}">${items.join("")}</dl>`;
}

function textBlockHtml(title, text, empty) {
  const body = text ? `<pre class="detail-pre">${escapeHtml(text)}</pre>` : `<p class="muted-text">${escapeHtml(empty)}</p>`;
  return `<section class="detail-block"><h4>${escapeHtml(title)}</h4>${body}</section>`;
}

function evidenceHtml(evidence) {
  if (!evidence.length) return NOTHING;
  const items = evidence.map((item) => `<li>${escapeHtml(item)}</li>`).join("");
  const label = evidence.length === 1 ? "1 item" : `${evidence.length} items`;
  return `<details class="tech-note"><summary>Show evidence (${label})</summary><ul class="evidence-list">${items}</ul></details>`;
}

function checkNameHtml(check) {
  const flags = [
    check.critical ? '<span class="check-flag">Must pass</span>' : "",
    check.unstable ? '<span class="check-flag">Reviews disagreed</span>' : "",
  ].join("");
  return `<strong>${escapeHtml(check.title)}</strong><span class="check-id">${escapeHtml(check.metric)}</span>${flags}`;
}

/** One row of the checks table. */
export function checkRowHtml(check) {
  return `<tr class="check-${escapeHtml(check.kind)}"><th scope="row">${checkNameHtml(check)}</th>`
    + `<td>${badgeHtml(check.kind, check.icon, check.verdict)}</td>`
    + `<td class="num">${escapeHtml(check.score)}</td><td class="num">${escapeHtml(check.threshold)}</td>`
    + `<td class="num">${escapeHtml(check.weight)}</td>`
    + `<td class="why">${check.rationale ? escapeHtml(check.rationale) : NOTHING}</td>`
    + `<td>${evidenceHtml(check.evidence)}</td></tr>`;
}

function checksTableHtml(test) {
  if (!test.checks.length) return '<p class="muted-text">No checks were scored for this test.</p>';
  return '<div class="table-scroll"><table class="checks-table">'
    + `<caption class="sr-only">Checks for test ${escapeHtml(test.id)}</caption>`
    + '<thead><tr><th scope="col">Check</th><th scope="col">Result</th><th scope="col">Score</th>'
    + '<th scope="col">Needed</th><th scope="col">Weight</th><th scope="col">Why</th><th scope="col">Evidence</th></tr></thead>'
    + `<tbody>${test.checks.map(checkRowHtml).join("")}</tbody></table></div>`;
}

function skippedHtml(skipped) {
  if (!skipped.length) return "";
  const items = skipped.map((item) => `<li class="skipped-row"><p><strong>${escapeHtml(item.title)}</strong>`
    + `${item.critical ? ' <span class="check-flag">Must pass</span>' : ""}</p>`
    + `<p>${escapeHtml(item.reason)}</p>${technicalDetailsHtml(item.details)}</li>`).join("");
  return `<section class="detail-block"><h4>Checks that could not be run (${skipped.length})</h4><ul class="skipped-list">${items}</ul></section>`;
}

function errorHtml(test) {
  if (!test.error) return "";
  return '<div class="notice notice-bad"><p class="notice-title"><span class="notice-icon" aria-hidden="true">×</span>'
    + `The AI assistant could not answer this test</p><pre class="detail-pre">${escapeHtml(test.error)}</pre></div>`;
}

function reportedHtml(test) {
  const calls = test.toolCalls
    ? `<details class="tech-note"><summary>Show tool calls</summary><pre>${escapeHtml(test.toolCalls)}</pre></details>`
    : "";
  return `<section class="detail-block"><h4>What the AI assistant reported</h4>${factsHtml(test.facts, "fact-grid")}${calls}</section>`;
}

function checksSummary(test) {
  const passed = test.checks.filter((check) => check.kind === "pass").length;
  const total = test.checks.length;
  return total ? `${passed} of ${total} checks passed` : "No checks scored";
}

/** One expandable test with everything that was recorded for it. */
export function testDetailHtml(test, open = false) {
  return `<details class="test-row test-${escapeHtml(test.kind)}" data-test-id="${escapeHtml(test.id)}"${open ? " open" : ""}>`
    + `<summary>${badgeHtml(test.kind, test.icon, test.verdict)}`
    + `<span class="test-name">${escapeHtml(test.name)} <span class="test-id">${escapeHtml(test.id)}</span></span>`
    + `<span class="test-meta">${escapeHtml(checksSummary(test))}</span>`
    + `<span class="test-score">Score ${escapeHtml(test.score)}</span></summary>`
    + `<div class="test-body">${errorHtml(test)}`
    + textBlockHtml("Question sent to the AI assistant", test.input, "No input was recorded.")
    + '<div class="answer-pair">'
    + textBlockHtml("The AI assistant’s answer", test.output, "No answer was recorded.")
    + textBlockHtml("Expected answer", test.expected, "This test has no expected answer.")
    + `</div>${reportedHtml(test)}`
    + `<section class="detail-block"><h4>Checks</h4>${checksTableHtml(test)}</section>`
    + `${skippedHtml(test.skipped)}</div></details>`;
}

function filterHtml(counts, active) {
  const options = TEST_FILTERS.map((name) => `<label class="filter-option"><input type="radio" name="test-filter" value="${name}"`
    + `${name === active ? " checked" : ""}> ${escapeHtml(FILTER_LABELS[name])} (${counts[name]})</label>`).join("");
  return `<fieldset class="test-filter"><legend class="sr-only">Which tests to show</legend>${options}</fieldset>`;
}

/** The test rows for a filter ("" hint when none match). */
export function testListHtml(tests, active, open = new Set()) {
  const shown = filterTests(tests, active);
  if (!shown.length) {
    const text = tests.length ? "No tests match this filter." : "No tests were run.";
    return `<p class="empty-line">${escapeHtml(text)}</p>`;
  }
  return shown.map((test) => testDetailHtml(test, open.has(test.id))).join("");
}

function heroHtml(view) {
  const failure = view.errorDetail
    ? noticeHtml({ tone: "bad", title: "What went wrong", text: "The evaluation reported this problem:", details: view.errorDetail })
    : "";
  return `<header class="detail-hero result-${escapeHtml(view.kind)}">`
    + `<div class="detail-verdict"><h2 id="run-detail-title" class="result-verdict">`
    + `<span class="result-icon" aria-hidden="true">${escapeHtml(view.icon)}</span>${escapeHtml(view.verdict)}</h2>`
    + `<p class="result-sentence">${escapeHtml(view.sentence)}</p></div>`
    + factsHtml([
      { label: "Overall score", value: view.score },
      { label: "Tests passed", value: view.passed },
      { label: "When", value: view.when },
      { label: "How long it took", value: view.duration },
    ], "hero-facts")
    + `${failure}</header>`;
}

/** Full markup for one evaluation. */
export function runDetailHtml(view, active = "all", open = new Set()) {
  if (!view) return noticeHtml({ tone: "warn", title: "No result came back", text: "This evaluation has no result to show." });
  return `<article class="run-detail" aria-labelledby="run-detail-title">${heroHtml(view)}`
    + `<section class="detail-section" aria-labelledby="settings-used-title"><h3 id="settings-used-title">Settings used</h3>`
    + `${factsHtml(view.settings, "settings-grid")}</section>`
    + '<section class="detail-section" aria-labelledby="tests-title"><div class="tests-head">'
    + `<h3 id="tests-title">Tests</h3>${filterHtml(view.counts, active)}</div>`
    + `<div class="test-list" id="test-list">${testListHtml(view.tests, active, open)}</div></section></article>`;
}

/** Renders `entry` into `root`; keeps the filter and open tests while the same run is shown. */
export function renderRunDetail(root, entry) {
  if (current?.id !== entry?.id) {
    openTests.clear();
    filter = "all";
  }
  current = { id: entry?.id, view: runDetailView(entry) };
  root.innerHTML = runDetailHtml(current.view, filter, openTests);
}

function onFilterChange(event) {
  const input = event.target;
  if (!input.matches('input[name="test-filter"]') || !current?.view) return;
  filter = TEST_FILTERS.includes(input.value) ? input.value : "all";
  const listBox = input.closest(".run-detail")?.querySelector("#test-list");
  if (listBox) listBox.innerHTML = testListHtml(current.view.tests, filter, openTests);
}

function onToggle(event) {
  const row = event.target;
  if (!row.matches?.("details.test-row")) return;
  if (row.open) openTests.add(row.dataset.testId);
  else openTests.delete(row.dataset.testId);
}

/** Wires the filter and remembers which tests are expanded. */
export function initRunDetail(root) {
  root.addEventListener("change", onFilterChange);
  root.addEventListener("toggle", onToggle, true);
}
