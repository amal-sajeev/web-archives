// View model for one evaluation on the Runner page (pure, no DOM): the header
// (verdict, score, tests passed, when, how long, settings used) and every test
// with its input, the answer next to the expected answer, what the AI assistant
// reported, the checks table and the checks that could not be run.

import { formatPercent, statusKind } from "../lib/format.js";
import { metricInfo } from "../lib/metric-catalog.js";
import { plainSkipReason } from "../lib/skip-reasons.js";
import {
  VERDICTS, VERDICT_ICONS, VERDICT_SENTENCES, humanizeId, passedOutOf,
} from "../lib/wording.js";
import { entryWhen, outcome, passCount } from "./runner-list-model.js";

export const NOT_RECORDED = "Not recorded";
export const TEST_FILTERS = Object.freeze(["all", "failed", "errors"]);

function list(value) {
  return Array.isArray(value) ? value : [];
}

function hasValue(value) {
  return value !== null && value !== undefined && value !== "";
}

/** Any value as readable text: strings as they are, everything else as indented JSON. */
export function displayValue(value) {
  if (!hasValue(value)) return "";
  if (typeof value === "string") return value;
  try {
    return JSON.stringify(value, null, 2) ?? "";
  } catch (err) {
    console.debug("Value is not serialisable", err);
    return String(value);
  }
}

function checkTitle(metric) {
  return metricInfo(metric).title || humanizeId(metric) || "Check";
}

/** 340 -> "340 ms", 1520 -> "1.5 s", 75000 -> "1 min 15 s". */
export function formatDuration(ms) {
  const n = Number(ms);
  if (!hasValue(ms) || !Number.isFinite(n) || n < 0) return NOT_RECORDED;
  if (n < 1000) return `${Math.round(n)} ms`;
  const seconds = n / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)} s`;
  return `${Math.floor(seconds / 60)} min ${Math.round(seconds % 60)} s`;
}

/** How long the evaluation took, from the recorded start and finish times. */
export function durationText(meta) {
  const start = Date.parse(meta?.startedAt);
  const end = Date.parse(meta?.finishedAt);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return NOT_RECORDED;
  return formatDuration(end - start);
}

function testsUsed(meta) {
  const ids = list(meta?.caseIds);
  return ids.length ? ids.join(", ") : NOT_RECORDED;
}

function versioned(id, version) {
  if (!id) return NOT_RECORDED;
  return version ? `${id} (version ${version})` : id;
}

function assistantText(run, meta) {
  const id = run.agent_id || meta?.agentId;
  if (!id) return NOT_RECORDED;
  return meta?.agentName && meta.agentName !== id ? `${meta.agentName} (ID ${id})` : id;
}

function targetText(meta) {
  if (!meta?.targetUrl) return NOT_RECORDED;
  return meta.customUrl ? meta.targetUrl : `${meta.targetUrl} (from agent.yaml)`;
}

/** Settings used by the run: [{label, value}]. */
export function settingsRows(entry) {
  const run = entry?.run || {};
  const meta = entry?.meta || null;
  return [
    { label: "Where the test questions went", value: targetText(meta) },
    { label: "Reviews per answer", value: meta?.reps ? String(meta.reps) : NOT_RECORDED },
    { label: "Tests included", value: testsUsed(meta) },
    { label: "AI assistant", value: assistantText(run, meta) },
    { label: "Test set", value: versioned(run.dataset_id, run.dataset_version) },
  ];
}

function tokenText(usage) {
  const input = usage?.input_tokens ?? usage?.prompt_tokens;
  const output = usage?.output_tokens ?? usage?.completion_tokens;
  const total = usage?.total_tokens ?? (hasValue(input) && hasValue(output) ? Number(input) + Number(output) : null);
  if (!hasValue(total)) return NOT_RECORDED;
  const parts = hasValue(input) && hasValue(output) ? ` (${input} in, ${output} out)` : "";
  return `${total}${parts}`;
}

function toolName(call) {
  return call?.name || call?.tool || call?.function?.name || "unnamed tool";
}

/** What the AI assistant reported for one test: [{label, value}]. */
export function observationFacts(observation) {
  const obs = observation || {};
  const calls = list(obs.tool_calls);
  return [
    { label: "Model", value: obs.model || NOT_RECORDED },
    { label: "Time to answer", value: formatDuration(obs.latency_ms) },
    { label: "Tokens used", value: tokenText(obs.usage) },
    { label: "Tool calls", value: calls.length ? `${calls.length}: ${calls.map(toolName).join(", ")}` : "None" },
  ];
}

/** One scored check -> a row of the checks table. */
export function checkRow(score) {
  const kind = statusKind(score?.passed) === "pass" ? "pass" : "fail";
  return {
    title: checkTitle(score?.metric),
    metric: String(score?.metric || ""),
    score: formatPercent(score?.score),
    threshold: formatPercent(score?.threshold),
    weight: hasValue(score?.weight) ? String(score.weight) : "—",
    kind,
    verdict: VERDICTS[kind],
    icon: VERDICT_ICONS[kind],
    critical: Boolean(score?.critical),
    unstable: Boolean(score?.unstable),
    rationale: String(score?.rationale || ""),
    evidence: list(score?.evidence).map(String),
  };
}

/** One check that could not be run -> {title, reason, details, critical}. */
export function skippedRow(skip) {
  return {
    title: checkTitle(skip?.metric),
    reason: plainSkipReason(skip?.reason),
    details: String(skip?.reason || ""),
    critical: Boolean(skip?.critical),
  };
}

function testKind(result) {
  if (result?.observation?.error) return "error";
  return statusKind(result?.passed) === "pass" ? "pass" : "fail";
}

/** One test result -> everything the expandable test row shows. */
export function testDetail(result) {
  const kind = testKind(result);
  const id = String(result?.case_id ?? "");
  const input = result?.input && Object.keys(result.input).length ? result.input : null;
  return {
    id,
    name: humanizeId(id) || "Test",
    kind,
    verdict: VERDICTS[kind],
    icon: VERDICT_ICONS[kind],
    score: formatPercent(result?.weighted_score),
    input: displayValue(input),
    output: displayValue(result?.observation?.output),
    expected: displayValue(result?.golden_output),
    error: String(result?.observation?.error || ""),
    facts: observationFacts(result?.observation),
    toolCalls: list(result?.observation?.tool_calls).length ? displayValue(result.observation.tool_calls) : "",
    checks: list(result?.scores).map(checkRow),
    skipped: list(result?.skipped).map(skippedRow),
  };
}

/** Tests shown for a filter: all | failed (did not pass) | errors (the AI assistant could not answer). */
export function filterTests(tests, filter) {
  if (filter === "failed") return list(tests).filter((test) => test.kind !== "pass");
  if (filter === "errors") return list(tests).filter((test) => test.kind === "error");
  return list(tests);
}

/** Entry -> the single-evaluation view model (null when it holds no run). */
export function runDetailView(entry, now = new Date()) {
  const run = entry?.run;
  if (!run || typeof run !== "object") return null;
  const tests = list(run.case_results).map(testDetail);
  const { passed, total } = passCount(run);
  const result = outcome(run);
  return {
    ...result,
    sentence: VERDICT_SENTENCES[result.kind],
    score: formatPercent(run.weighted_score),
    passed: passedOutOf(passed, total),
    when: entryWhen(entry, now),
    duration: durationText(entry.meta),
    errorDetail: String(run.error_detail || ""),
    settings: settingsRows(entry),
    tests,
    counts: { all: tests.length, failed: filterTests(tests, "failed").length, errors: filterTests(tests, "errors").length },
  };
}

/** Short status for the header pill: "Passed · 82%". */
export function runHeadline(run) {
  if (!run || typeof run !== "object") return "";
  const { verdict } = outcome(run);
  const score = formatPercent(run.weighted_score);
  return score === "—" ? verdict : `${verdict} · ${score}`;
}
