// Which full-page view is showing (pure, no DOM): Upload, Editor or Runner.
// The tab bar follows the ARIA tabs pattern: Left/Right move between tabs,
// Home/End jump to the first/last, and the focused tab is also the selected one.

export const VIEWS = Object.freeze(["upload", "editor", "runner"]);
export const DEFAULT_VIEW = "upload";
const LOADED_VIEW = "editor";

const KEY_STEPS = Object.freeze({ ArrowRight: 1, ArrowLeft: -1 });

/** A known view name, or the default (Upload). */
export function normalizeView(name) {
  return VIEWS.includes(name) ? name : DEFAULT_VIEW;
}

/** View to open with: the URL hash when it names a view, else Editor when settings are loaded, else Upload. */
export function initialView(hash, loaded) {
  const name = String(hash || "").replace(/^#/, "");
  if (VIEWS.includes(name)) return name;
  return loaded ? LOADED_VIEW : DEFAULT_VIEW;
}

/** Tab the keyboard moves to from `current` (null for keys the tab bar does not handle). */
export function viewForKey(current, key) {
  if (key === "Home") return VIEWS[0];
  if (key === "End") return VIEWS[VIEWS.length - 1];
  const step = KEY_STEPS[key];
  if (!step) return null;
  const index = VIEWS.indexOf(normalizeView(current));
  return VIEWS[(index + step + VIEWS.length) % VIEWS.length];
}

function plural(count, noun) {
  const n = Number(count) || 0;
  return `${n} ${noun}${n === 1 ? "" : "s"}`;
}

function editorNote({ loaded, dirty, fileCount }) {
  if (!loaded) return "Load settings first";
  return dirty ? "Unsaved changes" : plural(fileCount, "file");
}

function runnerNote({ loaded, running, runningText, runCount }) {
  if (!loaded) return "Load settings first";
  if (running) return runningText || "Running…";
  return runCount ? plural(runCount, "evaluation") : "No evaluations yet";
}

/**
 * Short status line under each tab title.
 * info: {loaded, assistant, dirty, fileCount, running, runningText, runCount}
 */
export function tabNotes(info = {}) {
  return {
    upload: info.loaded ? `${info.assistant || "Settings"} loaded` : "Nothing loaded yet",
    editor: editorNote(info),
    runner: runnerNote(info),
  };
}
