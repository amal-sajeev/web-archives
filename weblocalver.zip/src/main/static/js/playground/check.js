// "Check settings" on the Editor page: asks the server to look for mistakes without
// running anything, and shows the answer in plain words above the editor.

import { exportBundle, validateBundle } from "./bundle-api.js";
import { checkNotice, friendlyError, noticeHtml } from "./messages.js";
import { fileItems, persistSoon, state } from "./store.js";
import { $, setStatus } from "./view.js";
import { renderSummary } from "./workspace.js";

const BOX = "#validation-result";
const BUTTON = "#validate-config";

function syntaxErrorFrom(errors) {
  return errors.find((e) => e.startsWith("custom_tests.py could not be loaded") || e.includes("syntax error")) || null;
}

function applyCustomTests(result, errors) {
  const custom = result.custom_tests;
  if (!custom) return;
  state.customTests = {
    present: custom.present,
    declared_scorers: custom.declared_scorers || [],
    loaded_scorers: custom.loaded_scorers || [],
    syntax_error: syntaxErrorFrom(errors),
  };
  renderSummary();
  persistSoon();
}

function showBox(html) {
  const box = $(BOX);
  box.innerHTML = html;
  box.hidden = false;
}

/** Shows a server check result ({valid, errors, custom_tests}) and records it. */
export function showCheckResult(result) {
  const errors = Array.isArray(result?.errors) ? result.errors : [];
  applyCustomTests(result || {}, errors);
  state.check = { ok: Boolean(result?.valid), count: errors.length };
  showBox(noticeHtml(checkNotice(result)));
  setStatus(result?.valid ? "Ready to try" : "Needs fixing", result?.valid ? "ok" : "warn");
}

/** Hides the check result (after loading new settings or editing them). */
export function clearCheck() {
  const box = $(BOX);
  box.hidden = true;
  box.textContent = "";
  state.check = null;
}

export async function validateConfig() {
  if (state.checking) return;
  state.checking = true;
  $(BUTTON).disabled = true;
  setStatus("Checking…", "running");
  showBox('<p class="busy-line"><span class="spinner" aria-hidden="true"></span>Checking your settings…</p>');
  try {
    const blob = await exportBundle(fileItems(), "");
    showCheckResult((await validateBundle(blob)) || {});
  } catch (err) {
    state.check = null;
    showBox(noticeHtml({ tone: "bad", ...friendlyError(err, "check") }));
    setStatus("Check failed", "bad");
  } finally {
    state.checking = false;
    $(BUTTON).disabled = false;
  }
}
