// Step 2, "Check settings": asks the server to look for mistakes without running
// anything, and shows the answer in plain words under the step list.

import { exportBundle, validateBundle } from "./bundle-api.js";
import { checkNotice, friendlyError, noticeHtml } from "./messages.js";
import { renderSteps } from "./steps.js";
import { fileItems, persistSoon, state } from "./store.js";
import { $, setStatus } from "./view.js";
import { renderCustomTests } from "./workspace.js";

const BOX = "#validation-result";

function syntaxErrorFrom(errors) {
  return errors.find((e) => e.startsWith("custom_tests.py could not be loaded") || e.includes("syntax error")) || null;
}

function applyCustomTests(result, errors) {
  const custom = result.custom_tests;
  if (!custom) return;
  state.customTests = {
    present: custom.present,
    declared_scorers: custom.declared_scorers || [],
    loaded_scorers: custom.loaded_scorers || [],
    syntax_error: syntaxErrorFrom(errors),
  };
  renderCustomTests();
  persistSoon();
}

function showBox(html) {
  const box = $(BOX);
  box.innerHTML = html;
  box.hidden = false;
}

/** Shows a server check result ({valid, errors, custom_tests}) and records it for the steps. */
export function showCheckResult(result) {
  const errors = Array.isArray(result?.errors) ? result.errors : [];
  applyCustomTests(result || {}, errors);
  state.check = { ok: Boolean(result?.valid), count: errors.length };
  showBox(noticeHtml(checkNotice(result)));
  setStatus(result?.valid ? "Ready to try" : "Needs fixing", result?.valid ? "ok" : "warn");
  renderSteps();
}

/** Hides the check result (after loading new settings or editing them). */
export function clearCheck() {
  const box = $(BOX);
  box.hidden = true;
  box.textContent = "";
  state.check = null;
}

export async function validateConfig() {
  if (state.checking) return;
  state.checking = true;
  renderSteps();
  setStatus("Checking…", "running");
  showBox('<p class="busy-line"><span class="spinner" aria-hidden="true"></span>Checking your settings…</p>');
  try {
    const blob = await exportBundle(fileItems(), "");
    showCheckResult((await validateBundle(blob)) || {});
  } catch (err) {
    state.check = null;
    showBox(noticeHtml({ tone: "bad", ...friendlyError(err, "check") }));
    setStatus("Check failed", "bad");
  } finally {
    state.checking = false;
    renderSteps();
  }
}
