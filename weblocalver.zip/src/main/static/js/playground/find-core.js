// Find and replace matching (pure, no DOM). Matching ignores upper/lower case.

/** Next case-insensitive match at or after `from`, wrapping to the top. */
export function findMatch(text, query, from = 0) {
  if (!query) return null;
  const hay = String(text).toLowerCase();
  const needle = String(query).toLowerCase();
  let index = hay.indexOf(needle, Math.max(0, from));
  let wrapped = false;
  if (index < 0) {
    index = hay.indexOf(needle);
    wrapped = index >= 0;
  }
  return index < 0 ? null : { start: index, end: index + needle.length, wrapped };
}

/** Case-insensitive replace-all. Returns {text, count}. */
export function replaceAll(text, query, replacement) {
  const source = String(text);
  if (!query) return { text: source, count: 0 };
  const hay = source.toLowerCase();
  const needle = String(query).toLowerCase();
  let out = "";
  let pos = 0;
  let count = 0;
  let index = hay.indexOf(needle);
  while (index >= 0) {
    out += source.slice(pos, index) + replacement;
    pos = index + needle.length;
    count += 1;
    index = hay.indexOf(needle, pos);
  }
  return { text: out + source.slice(pos), count };
}

/** True when the selected text equals the query, ignoring case. */
export function selectionMatches(text, start, end, query) {
  return Boolean(query) && String(text).slice(start, end).toLowerCase() === String(query).toLowerCase();
}
