// Upload page: load a settings .zip (drop or choose), download the current
// settings, undo all changes, or clear everything. A successful load opens the
// Editor; that is the only time the page switches view by itself.

import { confirmDialog, showToast } from "../ui/toast.js";
import { exportBundle, inspectBundle } from "./bundle-api.js";
import { clearCheck } from "./check.js";
import { cancelMetadataRefresh, markEdited } from "./edits.js";
import { friendlyError, noticeHtml } from "./messages.js";
import { hideLive } from "./run-progress.js";
import { stopActiveRun } from "./run.js";
import {
  cancelPendingSave, clearRuns, clearStorage, cloneFiles, fileItems, isDirty, persistNow, persistSoon,
  reportStorageError, resetState, sortedPaths, state,
} from "./store.js";
import { $, downloadBlob, setStatus } from "./view.js";
import { isLoaded, showView } from "./views.js";
import {
  loadInspection, refreshBundleMetadata, renderWorkspace, reportMetadataError, updateDirtyState,
} from "./workspace.js";

const ZIP_INPUT = "#zip-input";
const DISCARD = "Discard changes";

function showLoadError(err) {
  const box = $("#load-error");
  box.hidden = !err;
  box.innerHTML = err ? noticeHtml({ tone: "bad", ...friendlyError(err, "load") }) : "";
}

async function importZip(file) {
  setStatus("Opening…", "running");
  showLoadError(null);
  const data = await inspectBundle(file);
  stopActiveRun();
  hideLive();
  loadInspection(data);
  state.runs = [];
  state.selectedRuns = [];
  state.saved = false;
  clearRuns().catch(reportStorageError);
  await persistNow();
  clearCheck();
  renderWorkspace();
  setStatus("Settings loaded", "ok");
  showView("editor");
}

function importFailed(err) {
  setStatus("Could not open the file", "bad");
  showLoadError(err);
  $(ZIP_INPUT).value = "";
}

async function discardEditsOk(title) {
  if (!isDirty()) return true;
  return confirmDialog({
    title,
    message: "Your changes will be lost. To keep them, choose “Download current settings” first.",
    confirmLabel: DISCARD,
    danger: true,
  });
}

async function importFile(file) {
  if (!file) return;
  if (isLoaded() && !(await discardEditsOk("Load different settings?"))) {
    $(ZIP_INPUT).value = "";
    return;
  }
  await importZip(file).catch(importFailed);
}

async function exportZip() {
  const blob = await exportBundle(fileItems(), state.root);
  downloadBlob(blob, `${state.agent?.agent_id || "agent"}-config-playground.zip`);
  state.saved = true;
  updateDirtyState();
  showToast("The current settings were saved to your downloads.", { kind: "ok" });
}

function exportFailed(err) {
  const { title, text } = friendlyError(err, "save");
  showToast(`${title}. ${text}`, { kind: "bad" });
}

async function resetConfig() {
  if (!state.original) return;
  const ok = await confirmDialog({
    title: "Undo all your changes?",
    message: "The files go back to how they were when you loaded the .zip file.",
    confirmLabel: "Undo changes",
    danger: true,
  });
  if (!ok) return;
  cancelMetadataRefresh();
  state.files = cloneFiles(state.original);
  state.selected = sortedPaths()[0] || null;
  markEdited();
  persistSoon();
  renderWorkspace();
  refreshBundleMetadata().catch(reportMetadataError);
  setStatus("Changes undone", "ok");
}

async function clearConfig() {
  const ok = await confirmDialog({
    title: "Clear these settings?",
    message: "The files and the list of evaluations are removed from this browser. Download the current settings first if you want to keep them.",
    confirmLabel: "Clear settings",
    danger: true,
  });
  if (!ok) return;
  cancelMetadataRefresh();
  cancelPendingSave();
  stopActiveRun();
  hideLive();
  resetState();
  clearStorage().catch(reportStorageError);
  clearCheck();
  showLoadError(null);
  renderWorkspace();
  setStatus("Nothing loaded yet");
}

function initDropzone() {
  const zone = $("#dropzone");
  const input = $(ZIP_INPUT);
  $("#choose-zip").addEventListener("click", () => input.click());
  input.addEventListener("change", () => importFile(input.files[0]));
  zone.addEventListener("dragover", (event) => {
    event.preventDefault();
    zone.classList.add("drag");
  });
  zone.addEventListener("dragleave", () => zone.classList.remove("drag"));
  zone.addEventListener("drop", (event) => {
    event.preventDefault();
    zone.classList.remove("drag");
    importFile(event.dataTransfer?.files?.[0]);
  });
}

export function initUpload() {
  initDropzone();
  $("#export-config").addEventListener("click", () => exportZip().catch(exportFailed));
  $("#reset-config").addEventListener("click", resetConfig);
  $("#clear-config").addEventListener("click", clearConfig);
}
