// What happens after the files change: the last check and the downloaded copy go
// out of date, and the summary is re-derived shortly after agent.yaml or the
// test file changes.

import { clearCheck } from "./check.js";
import { state } from "./store.js";
import { refreshBundleMetadata, reportMetadataError, selectFile, updateDirtyState } from "./workspace.js";

const METADATA_DELAY_MS = 900;
let metadataTimer = null;

export function scheduleMetadataRefresh() {
  window.clearTimeout(metadataTimer);
  metadataTimer = window.setTimeout(() => {
    refreshBundleMetadata().catch(reportMetadataError);
  }, METADATA_DELAY_MS);
}

export function cancelMetadataRefresh() {
  window.clearTimeout(metadataTimer);
}

/** Any edit makes the last check and the last downloaded copy out of date. */
export function markEdited() {
  if (state.check) clearCheck();
  state.saved = false;
}

/** After typing in the editor. */
export function onEdit(path) {
  markEdited();
  updateDirtyState();
  const datasetFile = state.agent?.dataset_file || "dataset.json";
  if (path === "agent.yaml" || path === datasetFile) scheduleMetadataRefresh();
}

/** After a file was added, renamed or deleted. */
export function onFilesChanged() {
  markEdited();
  selectFile(state.selected);
  updateDirtyState();
  scheduleMetadataRefresh();
}
