// The Upload / Editor / Runner tab bar. One full-page view shows at a time; the
// choice is kept in the URL hash so a reload opens the same view. The rules live
// in views-model.js.

import { isDirty, state } from "./store.js";
import { $ } from "./view.js";
import { VIEWS, initialView, normalizeView, tabNotes, viewForKey } from "./views-model.js";

let active = null;

function tabFor(name) {
  return document.getElementById(`tab-${name}`);
}

function panelFor(name) {
  return document.getElementById(`view-${name}`);
}

function rememberView(name) {
  try {
    history.replaceState(null, "", `#${name}`);
  } catch (err) {
    console.debug("Could not keep the view in the address bar", err);
  }
}

/** Shows one view and marks its tab as selected. */
export function showView(name, { focus = false } = {}) {
  active = normalizeView(name);
  for (const view of VIEWS) {
    const selected = view === active;
    const tab = tabFor(view);
    tab.setAttribute("aria-selected", String(selected));
    tab.tabIndex = selected ? 0 : -1;
    panelFor(view).hidden = !selected;
  }
  if (focus) tabFor(active).focus();
  rememberView(active);
}

export function isLoaded() {
  return Object.keys(state.files).length > 0;
}

function currentInfo(loaded) {
  return {
    loaded,
    assistant: state.agent?.name || state.agent?.agent_id || "",
    dirty: loaded && isDirty(),
    fileCount: Object.keys(state.files).length,
    running: Boolean(state.stream),
    runningText: state.runningText,
    runCount: state.runs.length,
  };
}

/** Shows each view's content or its "load settings first" note, and refreshes the tab notes. */
export function renderViewState() {
  const loaded = isLoaded();
  document.querySelectorAll("[data-needs-settings]").forEach((node) => { node.hidden = !loaded; });
  document.querySelectorAll("[data-no-settings]").forEach((node) => { node.hidden = loaded; });
  const notes = tabNotes(currentInfo(loaded));
  for (const view of VIEWS) {
    const note = document.getElementById(`tab-note-${view}`);
    if (note.textContent !== notes[view]) note.textContent = notes[view];
  }
  tabFor("runner").dataset.running = String(Boolean(state.stream));
}

function onKeydown(event) {
  const next = viewForKey(active, event.key);
  if (!next) return;
  event.preventDefault();
  showView(next, { focus: true });
}

function onClick(event) {
  const tab = event.target.closest('[role="tab"]');
  if (tab) showView(tab.dataset.view);
}

function onGoTo(event) {
  const link = event.target.closest("[data-go-view]");
  if (!link) return;
  event.preventDefault();
  showView(link.dataset.goView, { focus: true });
}

/** Wires the tab bar and opens the first view (from the URL hash, or by what is loaded). */
export function initViews() {
  const bar = $("#view-tabs");
  bar.addEventListener("click", onClick);
  bar.addEventListener("keydown", onKeydown);
  document.addEventListener("click", onGoTo);
  renderViewState();
  showView(initialView(location.hash, isLoaded()));
}
