// Playground HTTP calls. URLs stay relative so an ingress path prefix keeps working.

import { detailMessage, fetchJson } from "../lib/api.js";
import { MAX_REPS, MIN_REPS } from "../lib/reps.js";

const ZIP_TYPE = "application/zip";
const BUNDLE_NAME = "config.zip";
const POST = "POST";

function zipForm(blob, name = BUNDLE_NAME) {
  const form = new FormData();
  form.append("file", blob instanceof File ? blob : new File([blob], name, { type: ZIP_TYPE }));
  return form;
}

async function blobError(res) {
  const text = await res.text();
  let message = "";
  try {
    message = detailMessage(JSON.parse(text)?.detail);
  } catch (err) {
    // Not JSON (e.g. a proxy page): fall back to the short raw text below.
    message = text.length < 300 ? text : "";
    console.debug("Non-JSON error body", err);
  }
  const error = new Error(message || `Request failed (${res.status})`);
  error.status = res.status;
  return error;
}

/** Builds a ZIP of the edited files on the server. */
export async function exportBundle(files, root = "") {
  let res;
  try {
    res = await fetch("api/playground/export", {
      method: POST,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ root, files }),
    });
  } catch (err) {
    const error = new Error("The evaluation service could not be reached.");
    error.status = 0;
    error.cause = err;
    throw error;
  }
  if (!res.ok) throw await blobError(res);
  return res.blob();
}

/** Describes a bundle (agent, dataset, files, custom tests, warnings). */
export function inspectBundle(blobOrFile) {
  return fetchJson("api/playground/inspect", { method: POST, body: zipForm(blobOrFile) });
}

/** {valid, errors, agent, dataset, custom_tests} */
export function validateBundle(blob) {
  return fetchJson("api/playground/validate", { method: POST, body: zipForm(blob) });
}

/** Reviews per answer, clamped to the 1-5 the API accepts. */
export function clampReps(value) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n)) return MIN_REPS;
  return Math.max(MIN_REPS, Math.min(MAX_REPS, n));
}

/** Query string for POST api/playground/start. */
export function startQuery({ baseUrl = "", reps = 1, caseIds = [] } = {}) {
  const params = new URLSearchParams({
    judge_repetitions: String(clampReps(reps)),
    case_ids_json: JSON.stringify(caseIds || []),
  });
  const target = String(baseUrl || "").trim();
  if (target) params.set("base_url", target);
  return params.toString();
}

/** Starts a sandbox evaluation (202); resolves {stream_id, agent_id}. */
export function startRun(blob, options) {
  const form = zipForm(blob, "agent-config-playground.zip");
  return fetchJson(`api/playground/start?${startQuery(options)}`, { method: POST, body: form });
}

export function cancelRun(streamId) {
  return fetchJson(`api/evaluate/cancel/${encodeURIComponent(streamId)}`, { method: POST });
}

export function streamUrl(streamId) {
  return `api/evaluate/stream/${encodeURIComponent(streamId)}`;
}

export function fetchStreamEvents(streamId, after) {
  return fetchJson(`${streamUrl(streamId)}/events?after=${Math.max(0, Number(after) || 0)}`);
}

/** The completed run of a stream (used when polling ends without a terminal event). */
export function fetchFinishedRun(streamId) {
  return fetchJson(`api/playground/export?stream_id=${encodeURIComponent(streamId)}`, { method: POST });
}

export function fetchEnvironment() {
  return fetchJson("api/playground/environment");
}
