// File and editor rules for the playground (pure, no DOM): file types, quick
// format checks, path clean-up and one-line test previews.

const TEXT_FILE = /\.(yaml|yml|json|py|txt|md|toml|ini|cfg|xml|csv|env)$/i;
const LANGUAGES = Object.freeze({ py: "Python", yaml: "YAML", yml: "YAML", json: "JSON" });
const PLAIN_TEXT = "Plain text";
const SUMMARY_LENGTH = 80;

/** Plain explanation shown next to the well-known configuration files. */
const FILE_ROLES = Object.freeze({
  "agent.yaml": "Describes the AI assistant",
  "dataset.json": "The tests and checks",
  "metrics_stub.json": "Check settings",
  "custom_tests.py": "Extra checks",
});

export function languageFor(path) {
  const ext = String(path || "").split(".").pop().toLowerCase();
  return LANGUAGES[ext] || PLAIN_TEXT;
}

/** Short role for a known file name ("" for other files). */
export function fileRole(path, datasetFile = "dataset.json") {
  const name = String(path || "").split("/").pop();
  if (name === datasetFile) return FILE_ROLES["dataset.json"];
  return FILE_ROLES[name] || "";
}

/**
 * Quick local check shown under the editor: {tone, text}.
 * tone is ok | warn | info. Only JSON can be checked in the browser.
 */
export function localValidation(text, language) {
  if (language === "JSON") {
    try {
      JSON.parse(text);
      return { tone: "ok", text: "✓ No formatting problems" };
    } catch (err) {
      return { tone: "warn", text: `! Formatting problem: ${err.message}` };
    }
  }
  if (language === "Python" || language === "YAML") return { tone: "info", text: "Checked when you press “Check settings”" };
  return { tone: "info", text: "" };
}

export function lineCount(text) {
  return String(text ?? "").split("\n").length;
}

/** Normalises a typed file path ("" when unusable). */
export function cleanPath(input) {
  return String(input ?? "").trim().replaceAll("\\", "/").replace(/^\/+/, "");
}

export function isTextPath(path) {
  return TEXT_FILE.test(String(path || ""));
}

function stringify(input) {
  if (typeof input === "string") return input;
  try {
    return JSON.stringify(input) ?? "";
  } catch (err) {
    console.debug("Test input is not serialisable", err);
    return "";
  }
}

/** One-line preview of a test's input (strings as-is, objects as JSON). */
export function summarizeCase(input) {
  const text = stringify(input);
  return text.length > SUMMARY_LENGTH ? `${text.slice(0, SUMMARY_LENGTH)}…` : text;
}

/** "3 of 4 tests selected" */
export function selectionLabel(selected, total) {
  return `${selected} of ${total} ${total === 1 ? "test" : "tests"} selected`;
}

/** UTF-8 byte length of a string. */
export function byteLength(text) {
  return new TextEncoder().encode(String(text ?? "")).length;
}
