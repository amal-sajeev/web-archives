// "Tests to include" checklist on the Runner page. Changing the selection updates
// the Run button, because Run needs at least one test.

import { escapeHtml } from "../lib/fragments.js";
import { selectionLabel, summarizeCase } from "./editor-model.js";
import { updateRunControls } from "./run-controls.js";
import { caseIds, persistSoon, state } from "./store.js";
import { $ } from "./view.js";
import { reconcileCases } from "./workspace-model.js";

function caseItems() {
  return Array.isArray(state.dataset?.case_items) ? state.dataset.case_items : [];
}

function updateCaseCount() {
  const count = $("#case-selection-count");
  if (count) count.textContent = selectionLabel(state.selectedCases.length, caseItems().length);
  updateRunControls();
}

/** One checkbox row: the test name and a short preview of what it asks. */
export function caseRowHtml(item, selected) {
  const id = escapeHtml(item.id);
  const checked = selected.has(item.id) ? " checked" : "";
  const preview = summarizeCase(item.input);
  return `<label class="case-row"><input type="checkbox" data-case-id="${id}"${checked}>`
    + `<span class="case-text"><strong>Test ${id}</strong>`
    + `${preview ? `<span class="case-preview">${escapeHtml(preview)}</span>` : ""}</span></label>`;
}

function onToggle(event) {
  const box = event.target;
  if (!box.matches("input[data-case-id]")) return;
  const id = box.dataset.caseId;
  const others = state.selectedCases.filter((value) => value !== id);
  state.selectedCases = box.checked ? [...others, id] : others;
  updateCaseCount();
  persistSoon();
}

export function renderCases() {
  const list = $("#case-list");
  const items = caseItems();
  if (items.length) {
    const selected = new Set(state.selectedCases);
    list.innerHTML = items.map((item) => caseRowHtml(item, selected)).join("");
  } else {
    list.innerHTML = '<p class="muted-text">There are no tests in the test file yet.</p>';
  }
  updateCaseCount();
}

/** Keeps only selections that still exist; selects everything when none remain. */
export function reconcileSelection() {
  state.selectedCases = reconcileCases(state.selectedCases, state.dataset);
}

function selectCases(ids) {
  state.selectedCases = ids;
  renderCases();
  persistSoon();
}

export function initCases() {
  $("#case-list").addEventListener("change", onToggle);
  $("#select-all-cases").addEventListener("click", () => selectCases(caseIds(state.dataset)));
  $("#clear-cases").addEventListener("click", () => selectCases([]));
}
