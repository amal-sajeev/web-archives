// Small DOM helpers shared by the playground modules.

import { statusKind } from "../lib/format.js";

export const $ = (selector) => document.querySelector(selector);

const PILL_BY_KIND = Object.freeze({ pass: "ok", fail: "bad", error: "bad", cancelled: "warn" });

/** Header status pill. kind: '' | 'ok' | 'bad' | 'warn' | 'running'. */
export function setStatus(text, kind = "") {
  const pill = $("#pg-status");
  if (!pill) return;
  pill.textContent = text;
  pill.className = kind ? `pill ${kind}` : "pill";
}

/** Pill kind for an evaluation status: a result that needs attention is never green. */
export function pillKindForStatus(status) {
  return PILL_BY_KIND[statusKind(status)];
}

/** Triggers a browser download of a Blob. */
export function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
