// Find and replace bar for the code editor. The matching rules live in find-core.js.

import { findMatch, replaceAll, selectionMatches } from "./find-core.js";
import { $ } from "./view.js";

const FIND_INPUT = "#find-input";
const REPLACE_INPUT = "#replace-input";
const FINDBAR = "#findbar";

function editor() {
  return $("#code-editor");
}

function setFindStatus(text) {
  const status = $("#find-status");
  if (status) status.textContent = text;
}

function notifyEdit(ed) {
  ed.dispatchEvent(new Event("input", { bubbles: true }));
}

function findNext() {
  const ed = editor();
  const query = $(FIND_INPUT).value;
  if (!query) {
    setFindStatus("Type the text to look for");
    return false;
  }
  const match = findMatch(ed.value, query, ed.selectionEnd);
  if (!match) {
    setFindStatus("Not found");
    return false;
  }
  ed.focus({ preventScroll: true });
  ed.setSelectionRange(match.start, match.end);
  $(FIND_INPUT).focus();
  setFindStatus(match.wrapped ? "Started again from the top" : "");
  return true;
}

function replaceOne() {
  const ed = editor();
  const query = $(FIND_INPUT).value;
  if (ed.disabled) return;
  if (!selectionMatches(ed.value, ed.selectionStart, ed.selectionEnd, query)) {
    findNext();
    return;
  }
  ed.setRangeText($(REPLACE_INPUT).value, ed.selectionStart, ed.selectionEnd, "end");
  notifyEdit(ed);
  if (!findNext()) setFindStatus("Replaced. No more matches.");
}

function replaceEverywhere() {
  const ed = editor();
  const query = $(FIND_INPUT).value;
  if (ed.disabled || !query) return;
  const result = replaceAll(ed.value, query, $(REPLACE_INPUT).value);
  if (!result.count) {
    setFindStatus("Not found");
    return;
  }
  ed.value = result.text;
  notifyEdit(ed);
  setFindStatus(result.count === 1 ? "1 match replaced" : `${result.count} matches replaced`);
}

export function openFindBar(focusReplace = false) {
  const bar = $(FINDBAR);
  bar.hidden = false;
  setFindStatus("");
  const target = focusReplace ? $(REPLACE_INPUT) : $(FIND_INPUT);
  target.focus();
  target.select();
}

export function closeFindBar() {
  const bar = $(FINDBAR);
  if (bar.hidden) return;
  bar.hidden = true;
  const ed = editor();
  if (!ed.disabled) ed.focus();
}

function onFieldKeydown(event, onEnter) {
  if (event.key === "Enter") {
    event.preventDefault();
    onEnter();
  } else if (event.key === "Escape") {
    event.preventDefault();
    closeFindBar();
  }
}

export function initFindBar() {
  $("#find-button").addEventListener("click", () => {
    if ($(FINDBAR).hidden) openFindBar(false);
    else closeFindBar();
  });
  $("#replace-button").addEventListener("click", () => openFindBar(true));
  $("#close-find").addEventListener("click", closeFindBar);
  $("#find-next").addEventListener("click", findNext);
  $("#replace-one").addEventListener("click", replaceOne);
  $("#replace-all").addEventListener("click", replaceEverywhere);
  $(FIND_INPUT).addEventListener("keydown", (event) => onFieldKeydown(event, findNext));
  $(FIND_INPUT).addEventListener("input", () => setFindStatus(""));
  $(REPLACE_INPUT).addEventListener("keydown", (event) => onFieldKeydown(event, replaceOne));
}
