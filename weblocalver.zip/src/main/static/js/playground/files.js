// Configuration file list: choose, add, upload, rename and delete settings files.

import { confirmDialog, promptDialog, showToast } from "../ui/toast.js";
import { cleanPath, fileRole, isTextPath } from "./editor-model.js";
import { state, persistSoon, sortedPaths } from "./store.js";
import { $ } from "./view.js";

const FILE_INPUT = "#file-input";

const DUPLICATE_PATH = "There is already a file with that name.";
const PATH_LABEL = "File name (you can include a folder, like docs/notes.txt)";

let changeCallback = () => {};
let selectCallback = () => {};

function fileRow(path) {
  const file = state.files[path];
  const button = document.createElement("button");
  button.type = "button";
  button.className = path === state.selected ? "file-row active" : "file-row";
  if (path === state.selected) button.setAttribute("aria-current", "true");
  const name = document.createElement("span");
  name.className = "file-name";
  name.textContent = path;
  button.appendChild(name);
  const role = file.kind === "binary" ? "Not a text file" : fileRole(path, state.agent?.dataset_file);
  if (role) {
    const tag = document.createElement("span");
    tag.className = "file-role";
    tag.textContent = role;
    button.appendChild(tag);
  }
  button.addEventListener("click", () => selectCallback(path));
  return button;
}

export function renderFiles() {
  const list = $("#file-list");
  list.replaceChildren(...sortedPaths().map(fileRow));
  const hasSelection = Boolean(state.selected && state.files[state.selected]);
  $("#rename-file").disabled = !hasSelection;
  $("#delete-file").disabled = !hasSelection;
}

function commit(selected) {
  state.selected = selected;
  persistSoon();
  changeCallback();
}

async function askForPath(title, value, confirmLabel) {
  const answer = await promptDialog({ title, label: PATH_LABEL, value, confirmLabel });
  if (answer === null) return null;
  const path = cleanPath(answer);
  if (!path) {
    showToast("Please type a file name.", { kind: "warn" });
    return null;
  }
  return path;
}

function rejectDuplicate(path) {
  if (!state.files[path]) return false;
  showToast(DUPLICATE_PATH, { kind: "warn" });
  return true;
}

async function newFile() {
  const path = await askForPath("Add a new file", "notes.txt", "Add file");
  if (!path || rejectDuplicate(path)) return;
  state.files[path] = { content: "", encoding: "utf-8", kind: "text", size: 0 };
  commit(path);
}

function toBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function readUpload(file, path) {
  if (isTextPath(path)) {
    return { content: await file.text(), encoding: "utf-8", kind: "text", size: file.size };
  }
  const bytes = new Uint8Array(await file.arrayBuffer());
  return { content: toBase64(bytes), encoding: "base64", kind: "binary", size: file.size };
}

async function uploadChosenFile() {
  const input = $(FILE_INPUT);
  const file = input.files[0];
  input.value = "";
  if (!file) return;
  const path = await askForPath("Add this file to the settings", file.name, "Add file");
  if (!path || rejectDuplicate(path)) return;
  state.files[path] = await readUpload(file, path);
  commit(path);
}

async function renameFile() {
  const current = state.selected;
  if (!current) return;
  const next = await askForPath("Rename file", current, "Rename");
  if (!next || next === current || rejectDuplicate(next)) return;
  state.files[next] = state.files[current];
  delete state.files[current];
  commit(next);
}

async function deleteFile() {
  const current = state.selected;
  if (!current) return;
  const ok = await confirmDialog({
    title: `Delete ${current}?`,
    message: "The file will be removed from these settings. The .zip file on your computer is not changed.",
    confirmLabel: "Delete file",
    danger: true,
  });
  if (!ok) return;
  delete state.files[current];
  commit(sortedPaths()[0] || null);
}

function reportFailure(err) {
  showToast(`That did not work: ${err?.message || "please try again."}`, { kind: "bad" });
}

/** Wires the file controls. onChange: re-render after a mutation; onSelect(path). */
export function initFiles({ onChange, onSelect }) {
  changeCallback = onChange;
  selectCallback = onSelect;
  $("#new-file").addEventListener("click", () => newFile().catch(reportFailure));
  $("#upload-file").addEventListener("click", () => $(FILE_INPUT).click());
  $(FILE_INPUT).addEventListener("change", () => uploadChosenFile().catch(reportFailure));
  $("#rename-file").addEventListener("click", () => renameFile().catch(reportFailure));
  $("#delete-file").addEventListener("click", () => deleteFile().catch(reportFailure));
}
