// Live progress wording for a running evaluation (pure, no DOM).

import { metricInfo } from "../lib/metric-catalog.js";
import { humanizeId } from "../lib/wording.js";

function checkTitle(metric) {
  return metricInfo(metric).title || humanizeId(metric) || "Check";
}

/** "2 of 5 tests done" (or "2 tests done" before the total is known). */
export function progressLabel({ total = 0, casesDone = 0 } = {}) {
  if (total) return `${casesDone} of ${total} ${total === 1 ? "test" : "tests"} done`;
  return `${casesDone} ${casesDone === 1 ? "test" : "tests"} done`;
}

/** Whole percent of tests finished (0 when the total is unknown). */
export function progressPercent({ total = 0, casesDone = 0 } = {}) {
  if (!total) return 0;
  return Math.max(0, Math.min(100, Math.round((casesDone / total) * 100)));
}

const PROGRESS_TEXT = {
  case_started: (test) => `Asking the AI assistant: test ${test}`,
  observation: (test) => `Answer received for test ${test}`,
  metric_started: (test, check) => `Checking “${check}” on test ${test}`,
  metric_done: (test, check) => `Checked “${check}” on test ${test}`,
  metric_skipped: (test, check) => `Could not check “${check}” on test ${test}`,
  case_done: (test) => `Finished test ${test}`,
};

/** One progress event -> a plain sentence ("" when there is nothing to say). */
export function progressDetail(event) {
  const toText = PROGRESS_TEXT[event?.type];
  if (toText && event.case_id !== undefined) {
    return toText(String(event.case_id), event.metric ? checkTitle(event.metric) : "a check");
  }
  return String(event?.message || "");
}
