// Two evaluations side by side on the Runner page (pure markup, tested in Node).
// The rules live in run-compare-model.js; every interpolated value is escaped.

import { escapeHtml } from "../lib/fragments.js";
import { countOf } from "../lib/wording.js";
import { comparisonView } from "./run-compare-model.js";

export const CHOOSE_TWO_HTML = '<div class="empty-hint"><p class="empty-hint-title">Choose two different evaluations</p>'
  + "<p>Tick two evaluations in the list to compare them.</p></div>";

function changeHtml(text, cls) {
  const klass = cls ? `change ${escapeHtml(cls)}` : "change";
  return `<span class="${klass}">${escapeHtml(text)}</span>`;
}

function sideHtml(title, side) {
  return `<section class="compare-side result-${escapeHtml(side.kind)}" aria-label="${escapeHtml(title)}">`
    + `<p class="compare-side-title">${escapeHtml(title)}</p>`
    + `<p class="compare-side-when">${escapeHtml(side.when)}</p>`
    + `<p class="compare-side-score">${escapeHtml(side.score)}</p>`
    + `<p><span class="verdict verdict-${escapeHtml(side.kind)}"><span aria-hidden="true">${escapeHtml(side.icon)}</span> `
    + `${escapeHtml(side.verdict)}</span></p><p>${escapeHtml(side.passed)}</p></section>`;
}

function summaryLine(counts) {
  const parts = [];
  if (counts.regressed) parts.push(`${countOf(counts.regressed, "test")} got worse`);
  if (counts.improved) parts.push(`${countOf(counts.improved, "test")} got better`);
  return parts.length ? `${parts.join(" and ")}.` : "No test got better or worse.";
}

function overallHtml(view) {
  return '<div class="compare-summary">'
    + sideHtml("Earlier evaluation", view.earlier)
    + '<section class="compare-side compare-change" aria-label="Change in overall score">'
    + '<p class="compare-side-title">Change in overall score</p>'
    + `<p class="compare-side-score">${changeHtml(view.overall.change, view.overall.cls)}</p>`
    + `<p>${escapeHtml(summaryLine(view.counts))}</p></section>`
    + sideHtml("Later evaluation", view.later)
    + "</div>";
}

function trendHtml(row) {
  return `<span class="trend-tag trend-${escapeHtml(row.trend)}">${escapeHtml(row.trendLabel)}</span>`;
}

function checkRowsHtml(row) {
  return row.checks.map((check) => `<tr class="compare-check"><th scope="row"><span class="check-indent">${escapeHtml(check.title)}</span></th>`
    + `<td class="num">${escapeHtml(check.before)}</td><td class="num">${escapeHtml(check.after)}</td>`
    + `<td>${changeHtml(check.change, check.cls)}</td><td></td></tr>`).join("");
}

/** One test row followed by a row for each of its checks. */
export function compareRowsHtml(row) {
  return `<tr class="compare-test row-${escapeHtml(row.trend)}"><th scope="row">`
    + `<strong>${escapeHtml(row.name)}</strong> <span class="test-id">${escapeHtml(row.id)}</span></th>`
    + `<td class="num">${escapeHtml(row.before)}</td><td class="num">${escapeHtml(row.after)}</td>`
    + `<td>${changeHtml(row.change, row.cls)}</td><td>${trendHtml(row)}</td></tr>${checkRowsHtml(row)}`;
}

/** Comparison markup for two entries (order does not matter: the earlier one is the starting point). */
export function comparisonHtml(first, second, now = new Date()) {
  const view = comparisonView(first, second, now);
  if (!view) return CHOOSE_TWO_HTML;
  const rows = view.rows.map(compareRowsHtml).join("");
  const table = rows
    ? '<div class="table-scroll"><table class="compare-table">'
      + '<caption class="sr-only">Score for each test and check in the earlier and later evaluation</caption>'
      + '<thead><tr><th scope="col">Test or check</th><th scope="col">Earlier</th><th scope="col">Later</th>'
      + `<th scope="col">Change</th><th scope="col">Result</th></tr></thead><tbody>${rows}</tbody></table></div>`
    : '<p class="empty-line">Neither evaluation ran any tests.</p>';
  return '<article class="run-compare" aria-labelledby="compare-title">'
    + '<h2 id="compare-title">Comparing two evaluations</h2>'
    + '<p class="view-copy">Changes are shown as a percentage of the earlier score.</p>'
    + `${overallHtml(view)}<section class="detail-section" aria-labelledby="compare-tests-title">`
    + `<h3 id="compare-tests-title">Tests and checks</h3>${table}</section></article>`;
}
