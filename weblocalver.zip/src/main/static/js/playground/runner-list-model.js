// The Runner's list of evaluations kept in this browser (pure, no DOM).
// Each entry is {id, savedAt, meta, run}: `run` is the RunRecord the service sent,
// `meta` the settings used (recorded when the run started; missing for older entries).
// Ticking one entry shows its details; ticking two compares them.

import { formatPercent, statusKind } from "../lib/format.js";
import { VERDICTS, VERDICT_ICONS, countOf, friendlyDate, outcomeKind, passedOutOf } from "../lib/wording.js";

export const MAX_SELECTED = 2;
export const MODES = Object.freeze({ none: "none", single: "single", compare: "compare" });

function list(value) {
  return Array.isArray(value) ? value : [];
}

/** Stored record ({savedAt, run, meta?, id?}) -> entry, or null when it holds no run. */
export function entryFromRecord(record, index = 0) {
  if (!record?.run || typeof record.run !== "object") return null;
  const savedAt = Number(record.savedAt) || 0;
  return {
    id: String(record.id || `${savedAt}-${record.run.run_id || index}`),
    savedAt,
    meta: record.meta && typeof record.meta === "object" ? record.meta : null,
    run: record.run,
  };
}

/** A new entry for a finished run. */
export function newEntry(run, meta, now = Date.now()) {
  return entryFromRecord({ id: `${now}-${run?.run_id || "run"}`, savedAt: now, meta: meta || null, run });
}

/** Ticks or unticks `id`; ticking a third entry drops the oldest tick. */
export function toggleSelection(selected, id, checked) {
  const others = list(selected).filter((value) => value !== id);
  if (!checked) return others;
  return [...others, id].slice(-MAX_SELECTED);
}

/** Keeps ticks that still exist; ticks the newest entry when none remain. */
export function reconcileSelection(selected, entries) {
  const known = new Set(list(entries).map((entry) => entry.id));
  const kept = list(selected).filter((id) => known.has(id)).slice(-MAX_SELECTED);
  if (kept.length || !known.size) return kept;
  return [entries[0].id];
}

/** "none" | "single" | "compare" for the number of ticked entries. */
export function selectionMode(selected) {
  const count = list(selected).length;
  if (count >= MAX_SELECTED) return MODES.compare;
  return count === 1 ? MODES.single : MODES.none;
}

function testPassed(result) {
  return !result?.observation?.error && statusKind(result?.passed) === "pass";
}

/** {passed, total} tests of a run record. */
export function passCount(run) {
  const results = list(run?.case_results);
  return { passed: results.filter(testPassed).length, total: results.length };
}

function repsText(reps) {
  const n = Number(reps) || 1;
  return `${n} ${n === 1 ? "review" : "reviews"} per answer`;
}

function testsText(meta) {
  const chosen = list(meta.caseIds).length;
  const total = Number(meta.totalCases) || 0;
  if (!chosen) return "All tests";
  if (total && chosen === total) return `All ${total} tests`;
  if (total) return `${chosen} of ${total} tests`;
  return countOf(chosen, "test");
}

/** One-line summary of the settings used ("Settings not recorded" for older entries). */
export function settingsSummary(meta) {
  if (!meta) return "Settings not recorded";
  const target = meta.customUrl ? "Custom address" : "Address from agent.yaml";
  return `${testsText(meta)} · ${repsText(meta.reps)} · ${target}`;
}

/** Run outcome kind and verdict words: {kind, verdict, icon}. */
export function outcome(run) {
  const kind = outcomeKind(run);
  return { kind, verdict: VERDICTS[kind], icon: VERDICT_ICONS[kind] };
}

/** When the evaluation ran: "Today at 10:12" ("Unknown time" when nothing was recorded). */
export function entryWhen(entry, now = new Date()) {
  return friendlyDate(entry?.meta?.startedAt || entry?.run?.creation_ts || entry?.savedAt, now) || "Unknown time";
}

/** Entry -> row view {id, when, kind, verdict, icon, score, passed, settings, checked}. */
export function runListItem(entry, selected = [], now = new Date()) {
  const run = entry?.run || {};
  const { passed, total } = passCount(run);
  return {
    id: entry?.id || "",
    when: entryWhen(entry, now),
    ...outcome(run),
    score: formatPercent(run.weighted_score),
    passed: passedOutOf(passed, total),
    settings: settingsSummary(entry?.meta),
    checked: list(selected).includes(entry?.id),
  };
}

/** The ticked entries, oldest tick first. */
export function selectedEntries(selected, entries) {
  const byId = new Map(list(entries).map((entry) => [entry.id, entry]));
  return list(selected).map((id) => byId.get(id)).filter(Boolean);
}
