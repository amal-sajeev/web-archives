// Config playground entry point. Three full-page views, switched with the tab bar:
//   Upload  load or download the settings .zip
//   Editor  change the files and check them for mistakes
//   Runner  run evaluations and look at (or compare) the results

import "../ui/shell.js";
import { showToast } from "../ui/toast.js";
import { initCases } from "./cases.js";
import { validateConfig } from "./check.js";
import { initEditor } from "./editor.js";
import { onEdit, onFilesChanged } from "./edits.js";
import { initEnvironment } from "./environment.js";
import { initFiles } from "./files.js";
import { initFindBar } from "./find.js";
import { cancelActiveRun, runEvaluation } from "./run.js";
import { initRunner } from "./runner-list.js";
import { applySnapshot, loadRuns, loadWorkspace, state } from "./store.js";
import { initUpload } from "./upload.js";
import { $, setStatus } from "./view.js";
import { initViews } from "./views.js";
import { renderWorkspace, selectFile } from "./workspace.js";

async function restore() {
  const saved = await loadWorkspace();
  if (!saved?.files || !Object.keys(saved.files).length) return;
  applySnapshot(saved);
  state.runs = await loadRuns();
  renderWorkspace();
  setStatus("Picked up where you left off", "ok");
}

function restoreFailed(err) {
  console.warn("Could not restore the saved playground workspace", err);
  showToast("Your last session could not be restored from this browser.", { kind: "warn" });
}

function bindActions() {
  $("#validate-config").addEventListener("click", validateConfig);
  $("#test-config").addEventListener("click", runEvaluation);
  $("#cancel-run").addEventListener("click", cancelActiveRun);
}

function init() {
  initUpload();
  initEditor({ onEdit });
  initFindBar();
  initFiles({ onChange: onFilesChanged, onSelect: selectFile });
  initCases();
  initEnvironment();
  initRunner();
  bindActions();
  renderWorkspace();
  restore().catch(restoreFailed).finally(initViews);
}

init();
