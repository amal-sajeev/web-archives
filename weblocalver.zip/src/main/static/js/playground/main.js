// Config playground entry point. The page follows four steps:
//   1 Load settings  2 Check settings  3 Try it (run an evaluation)  4 Save a copy

import "../ui/shell.js";
import { confirmDialog, showToast } from "../ui/toast.js";
import { exportBundle, inspectBundle } from "./bundle-api.js";
import { initCases } from "./cases.js";
import { clearCheck, validateConfig } from "./check.js";
import { initCompare, updateCompareOptions } from "./compare.js";
import { initEditor } from "./editor.js";
import { initEnvironment } from "./environment.js";
import { initFiles } from "./files.js";
import { initFindBar } from "./find.js";
import { friendlyError, noticeHtml } from "./messages.js";
import { renderEmptyResults, renderRun } from "./results.js";
import { cancelActiveRun, runEvaluation, stopActiveRun } from "./run.js";
import { renderSteps } from "./steps.js";
import {
  applySnapshot, cancelPendingSave, clearRuns, clearStorage, cloneFiles, fileItems, isDirty,
  loadRuns, loadWorkspace, persistNow, persistSoon, reportStorageError, resetState, sortedPaths, state,
} from "./store.js";
import { $, downloadBlob, setStatus } from "./view.js";
import {
  loadInspection, refreshBundleMetadata, reportMetadataError, selectFile, showLoadPanel,
  showWorkspace, updateDirtyBadge,
} from "./workspace.js";

const LOAD_ERROR = "#load-error";
const METADATA_DELAY_MS = 900;
let metadataTimer = null;

function showLoadError(err) {
  const box = $(LOAD_ERROR);
  box.hidden = !err;
  box.innerHTML = err ? noticeHtml({ tone: "bad", ...friendlyError(err, "load") }) : "";
}

async function importZip(file) {
  setStatus("Opening…", "running");
  showLoadError(null);
  const data = await inspectBundle(file);
  stopActiveRun();
  loadInspection(data);
  state.runs = [];
  clearRuns().catch(reportStorageError);
  await persistNow();
  clearCheck();
  showWorkspace();
  renderEmptyResults();
  updateCompareOptions();
  setStatus("Settings loaded", "ok");
}

function importFailed(err) {
  setStatus("Could not open the file", "bad");
  showLoadError(err);
  $("#zip-input").value = "";
}

function importFile(file) {
  if (file) importZip(file).catch(importFailed);
}

function initLoadPanel() {
  const zone = $("#dropzone");
  const input = $("#zip-input");
  $("#choose-zip").addEventListener("click", () => input.click());
  input.addEventListener("change", () => importFile(input.files[0]));
  zone.addEventListener("dragover", (event) => {
    event.preventDefault();
    zone.classList.add("drag");
  });
  zone.addEventListener("dragleave", () => zone.classList.remove("drag"));
  zone.addEventListener("drop", (event) => {
    event.preventDefault();
    zone.classList.remove("drag");
    importFile(event.dataTransfer?.files?.[0]);
  });
}

function scheduleMetadataRefresh() {
  window.clearTimeout(metadataTimer);
  metadataTimer = window.setTimeout(() => {
    refreshBundleMetadata().catch(reportMetadataError);
  }, METADATA_DELAY_MS);
}

/** Any edit makes the last check and the last saved copy out of date. */
function markEdited() {
  if (state.check) clearCheck();
  state.saved = false;
}

function onEdit(path) {
  markEdited();
  updateDirtyBadge();
  const datasetFile = state.agent?.dataset_file || "dataset.json";
  if (path === "agent.yaml" || path === datasetFile) scheduleMetadataRefresh();
}

async function exportZip() {
  const blob = await exportBundle(fileItems(), state.root);
  downloadBlob(blob, `${state.agent?.agent_id || "agent"}-config-playground.zip`);
  state.saved = true;
  renderSteps();
  showToast("A copy of the settings was saved to your downloads.", { kind: "ok" });
}

function exportFailed(err) {
  const { title, text } = friendlyError(err, "save");
  showToast(`${title}. ${text}`, { kind: "bad" });
}

async function discardEditsOk(title, confirmLabel) {
  if (!isDirty()) return true;
  return confirmDialog({
    title,
    message: "Your changes will be lost. To keep them, choose “Save a copy” first.",
    confirmLabel,
    danger: true,
  });
}

async function changeConfig() {
  if (!(await discardEditsOk("Load different settings?", "Discard changes"))) return;
  window.clearTimeout(metadataTimer);
  cancelPendingSave();
  stopActiveRun();
  resetState();
  clearStorage().catch(reportStorageError);
  clearCheck();
  showLoadError(null);
  renderEmptyResults();
  showLoadPanel();
  setStatus("Nothing loaded yet");
}

async function resetConfig() {
  if (!state.original) return;
  const ok = await confirmDialog({
    title: "Undo all your changes?",
    message: "The settings go back to how they were when you loaded the file.",
    confirmLabel: "Undo changes",
    danger: true,
  });
  if (!ok) return;
  window.clearTimeout(metadataTimer);
  state.files = cloneFiles(state.original);
  state.selected = sortedPaths()[0] || null;
  markEdited();
  persistSoon();
  showWorkspace();
  refreshBundleMetadata().catch(reportMetadataError);
  setStatus("Changes undone", "ok");
}

function bindActions() {
  $("#validate-config").addEventListener("click", validateConfig);
  $("#export-config").addEventListener("click", () => exportZip().catch(exportFailed));
  $("#test-config").addEventListener("click", runEvaluation);
  $("#cancel-run").addEventListener("click", cancelActiveRun);
  $("#change-config").addEventListener("click", changeConfig);
  $("#reset-config").addEventListener("click", resetConfig);
}

async function restore() {
  const saved = await loadWorkspace();
  if (!saved?.files || !Object.keys(saved.files).length) return;
  applySnapshot(saved);
  state.runs = await loadRuns();
  state.lastRun = state.runs[0] || null;
  showWorkspace();
  if (state.runs.length) renderRun(state.runs[0]);
  updateCompareOptions();
  setStatus("Picked up where you left off", "ok");
}

function onFilesChanged() {
  markEdited();
  showWorkspace();
  scheduleMetadataRefresh();
}

function init() {
  initLoadPanel();
  initEditor({ onEdit });
  initFindBar();
  initFiles({ onChange: onFilesChanged, onSelect: selectFile });
  initCases();
  initCompare();
  initEnvironment();
  bindActions();
  renderSteps();
  restore().catch((err) => {
    console.warn("Could not restore the saved playground workspace", err);
    showToast("Your last session could not be restored from this browser.", { kind: "warn" });
  });
}

init();
