// Side-by-side comparison of two evaluations kept in this browser (pure, no DOM).
// Missing scores are shown as "—" and never subtracted.

import { DASH, formatChange, formatPercent } from "../lib/format.js";
import { escapeHtml } from "../lib/fragments.js";
import { metricInfo } from "../lib/metric-catalog.js";
import { friendlyDate, verdict } from "../lib/wording.js";

const EPSILON = 1e-9;
// Changes smaller than this (a hundredth of a percent) count as "same", matching formatChange.
const SAME_EPSILON = 0.0001;
export const NEED_TWO_HTML = '<div class="empty-hint"><p class="empty-hint-title">Nothing to compare yet</p>'
  + "<p>Run at least two evaluations. Each result is kept in this browser so you can compare them here.</p></div>";
export const CHOOSE_TWO_HTML = '<div class="empty-hint"><p>Choose two different evaluations.</p></div>';

function isScore(value) {
  return value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value));
}

/** b - a, or null when either score is missing. */
export function scoreDelta(a, b) {
  return isScore(a) && isScore(b) ? Number(b) - Number(a) : null;
}

/** Change from the first score to `current`: "+33.3%", "Unchanged", or "Only in one". */
export function scoreChange(delta, current) {
  if (delta === null || delta === undefined) return "Only in one";
  return formatChange(delta, current);
}

/** CSS class for a delta: up | down | same | "" (missing). */
export function changeClass(delta) {
  if (delta === null || delta === undefined) return "";
  if (Math.abs(delta) < SAME_EPSILON) return "same";
  return delta > 0 ? "up" : "down";
}

function byCase(run) {
  const results = Array.isArray(run?.case_results) ? run.case_results : [];
  return new Map(results.map((result) => [result.case_id, result]));
}

function byMetric(result) {
  const scores = Array.isArray(result?.scores) ? result.scores : [];
  return new Map(scores.map((score) => [score.metric, score.score]));
}

function union(a, b) {
  return [...new Set([...a.keys(), ...b.keys()])];
}

/** Checks whose score changed between two test results: [{title, delta, current}]. */
export function metricChanges(caseA, caseB) {
  const a = byMetric(caseA);
  const b = byMetric(caseB);
  return union(a, b)
    .map((metric) => ({
      title: metricInfo(metric).title || metric,
      delta: scoreDelta(a.get(metric), b.get(metric)),
      current: b.get(metric),
    }))
    .filter(({ delta }) => delta !== null && Math.abs(delta) > EPSILON);
}

function scoreCell(value) {
  return isScore(value) ? formatPercent(value) : DASH;
}

function changeHtml(delta, current) {
  return `<span class="change ${changeClass(delta)}">${escapeHtml(scoreChange(delta, current))}</span>`;
}

function changesCell(changes) {
  if (!changes.length) return DASH;
  return changes.map(({ title, delta, current }) => `${escapeHtml(title)}: ${changeHtml(delta, current)}`).join("<br>");
}

function caseRowHtml(id, caseA, caseB) {
  const scoreA = caseA?.weighted_score ?? null;
  const scoreB = caseB?.weighted_score ?? null;
  return `<tr><th scope="row">Test ${escapeHtml(id)}</th><td>${scoreCell(scoreA)}</td><td>${scoreCell(scoreB)}</td>`
    + `<td>${changeHtml(scoreDelta(scoreA, scoreB), scoreB)}</td><td>${changesCell(metricChanges(caseA, caseB))}</td></tr>`;
}

function tile(label, value) {
  return `<div class="compare-tile"><span>${escapeHtml(label)}</span><strong>${value}</strong></div>`;
}

function summaryHtml(a, b) {
  const delta = scoreDelta(a.weighted_score, b.weighted_score);
  return '<div class="compare-summary">'
    + tile("First", `${scoreCell(a.weighted_score)} · ${escapeHtml(verdict(a.status))}`)
    + tile("Second", `${scoreCell(b.weighted_score)} · ${escapeHtml(verdict(b.status))}`)
    + tile("Change", changeHtml(delta, b.weighted_score))
    + "</div>";
}

/** Comparison markup for evaluations a (first) and b (second). */
export function comparisonHtml(a, b) {
  if (!a || !b || a === b) return CHOOSE_TWO_HTML;
  const casesA = byCase(a);
  const casesB = byCase(b);
  const rows = union(casesA, casesB).map((id) => caseRowHtml(id, casesA.get(id), casesB.get(id))).join("");
  return `${summaryHtml(a, b)}<div class="table-scroll"><table class="compare-table">`
    + '<caption class="sr-only">Score for each test in the first and second evaluation</caption>'
    + '<thead><tr><th scope="col">Test</th><th scope="col">First</th><th scope="col">Second</th>'
    + `<th scope="col">Change</th><th scope="col">Checks that changed</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

/** Option text: "Today at 10:12 · Passed · 73%". */
export function runOptionLabel(run, now = new Date()) {
  const when = friendlyDate(run?.creation_ts, now) || "Unknown time";
  return `${when} · ${verdict(run?.status)} · ${formatPercent(run?.weighted_score)}`;
}
