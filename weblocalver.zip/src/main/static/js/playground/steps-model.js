// The four-step flow shown at the top of the playground (pure, no DOM):
//   1 Load  ->  2 Check  ->  3 Try it  ->  4 Save
// Each step gets a state (done | current | todo | busy | problem) and a one-line status.

export const STEP_TITLES = Object.freeze(["Load settings", "Check settings", "Try it", "Save a copy"]);

const AFTER_LOADING = "Available after loading settings";

function loadStep(flow) {
  if (flow.loaded) return { state: "done", status: `Loaded: ${flow.assistant || "AI assistant settings"}` };
  return { state: "todo", status: "Choose the .zip file with your settings" };
}

function checkStep(flow) {
  if (!flow.loaded) return { state: "todo", status: AFTER_LOADING };
  if (flow.checking) return { state: "busy", status: "Checking…" };
  if (!flow.check) return { state: "todo", status: "Look for mistakes before you try it" };
  if (flow.check.ok) return { state: "done", status: "No problems found" };
  const count = Number(flow.check.count) || 0;
  return { state: "problem", status: count === 1 ? "1 problem to fix" : `${count} problems to fix` };
}

function tryStep(flow) {
  if (!flow.loaded) return { state: "todo", status: AFTER_LOADING };
  if (flow.running) return { state: "busy", status: flow.runningText || "Running…" };
  if (flow.noTestsChosen) return { state: "problem", status: "Choose at least one test to include" };
  if (flow.lastResult) return { state: "done", status: `Last result: ${flow.lastResult}` };
  return { state: "todo", status: "Run an evaluation to see how it does" };
}

function saveStep(flow) {
  if (!flow.loaded) return { state: "todo", status: AFTER_LOADING };
  if (flow.saved) return { state: "done", status: "Copy saved to your computer" };
  if (flow.dirty) return { state: "todo", status: "You have changes that are not saved to a file" };
  return { state: "todo", status: "Download the settings as a .zip file" };
}

/**
 * flow: {loaded, assistant, checking, check: {ok, count} | null, running, runningText,
 *        noTestsChosen, lastResult, dirty, saved}.
 * Returns [{n, title, state, status, current}] where exactly one step is current
 * (the first one that is not done), or none when every step is done.
 */
export function stepModel(flow = {}) {
  const steps = [loadStep, checkStep, tryStep, saveStep].map((build, index) => ({
    n: index + 1,
    title: STEP_TITLES[index],
    ...build(flow),
    current: false,
  }));
  const next = steps.find((step) => step.state !== "done");
  if (next) {
    next.current = true;
    if (next.state === "todo") next.state = "current";
  }
  return steps;
}

const STATE_WORDS = Object.freeze({
  done: "Done",
  current: "Next",
  todo: "",
  busy: "In progress",
  problem: "Needs attention",
});

/** Word read out for a step state (visible too, so meaning never relies on colour). */
export function stateWord(state) {
  return STATE_WORDS[state] ?? "";
}
