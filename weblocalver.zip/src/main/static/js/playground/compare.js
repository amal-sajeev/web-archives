// Compare dialog: two evaluations kept in this browser, side by side.
// The markup rules live in compare-model.js.

import { escapeHtml } from "../lib/fragments.js";
import { NEED_TWO_HTML, comparisonHtml, runOptionLabel } from "./compare-model.js";
import { state } from "./store.js";
import { $ } from "./view.js";

const FIRST_SELECT = "#compare-a";
const SECOND_SELECT = "#compare-b";
const OUTPUT = "#compare-output";

function renderComparison() {
  const enough = state.runs.length >= 2;
  $("#compare-selects").hidden = !enough;
  if (!enough) {
    $(OUTPUT).innerHTML = NEED_TWO_HTML;
    return;
  }
  const a = state.runs[Number($(FIRST_SELECT).value)];
  const b = state.runs[Number($(SECOND_SELECT).value)];
  $(OUTPUT).innerHTML = comparisonHtml(a, b);
}

/** Refreshes the choices (first = the one before the latest, second = the latest). */
export function updateCompareOptions() {
  const options = state.runs
    .map((run, index) => `<option value="${index}">${escapeHtml(runOptionLabel(run))}</option>`)
    .join("");
  $(FIRST_SELECT).innerHTML = options;
  $(SECOND_SELECT).innerHTML = options;
  if (state.runs.length > 1) {
    $(FIRST_SELECT).value = "1";
    $(SECOND_SELECT).value = "0";
  }
  const count = state.runs.length;
  $("#compare-runs").textContent = count >= 2 ? `Compare evaluations (${count})` : "Compare evaluations";
  renderComparison();
}

export function initCompare() {
  const dialog = $("#compare-dialog");
  $("#compare-runs").addEventListener("click", () => {
    updateCompareOptions();
    dialog.showModal();
  });
  $("#close-compare").addEventListener("click", () => dialog.close());
  $(FIRST_SELECT).addEventListener("change", renderComparison);
  $(SECOND_SELECT).addEventListener("change", renderComparison);
}
