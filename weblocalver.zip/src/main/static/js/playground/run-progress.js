// The live box under the Run button: getting ready, progress while the tests run,
// and a notice when the evaluation could not start or finish.

import { escapeHtml } from "../lib/fragments.js";
import { noticeHtml } from "./messages.js";
import { progressDetail, progressLabel, progressPercent } from "./progress-model.js";
import { $ } from "./view.js";

const LIVE = "#run-live";

export const PROGRESS_HTML = '<div class="run-progress">'
  + '<p class="progress-head"><strong>Evaluation in progress</strong> <span class="progress-label">Starting…</span></p>'
  + '<progress class="pg-progress" max="100" value="0" aria-label="Evaluation progress"></progress>'
  + '<p class="progress-detail">Getting ready…</p></div>';

function show(html) {
  const box = $(LIVE);
  box.innerHTML = html;
  box.hidden = false;
}

/** Hides the live box (after a run finished and its result is in the list). */
export function hideLive() {
  const box = $(LIVE);
  box.hidden = true;
  box.textContent = "";
}

/** Shows a notice (see messages.js noticeHtml). */
export function renderNotice(options) {
  show(noticeHtml(options));
}

/** Shows a busy line. */
export function renderBusy(text) {
  show(`<p class="busy-line"><span class="spinner" aria-hidden="true"></span>${escapeHtml(text)}</p>`);
}

/** Updates (or creates) the progress block. counters: {total, casesDone}. */
export function renderProgress(counters, event) {
  const box = $(LIVE);
  if (!box.querySelector(".run-progress")) show(PROGRESS_HTML);
  const block = box.querySelector(".run-progress");
  block.querySelector(".pg-progress").value = progressPercent(counters);
  block.querySelector(".progress-label").textContent = progressLabel(counters);
  const detail = progressDetail(event);
  if (detail) block.querySelector(".progress-detail").textContent = detail;
}
