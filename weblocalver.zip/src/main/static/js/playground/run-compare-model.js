// Comparison of two evaluations kept in this browser (pure, no DOM). The earlier
// evaluation is the starting point; every change is a relative percentage from
// formatChange ("−18.0%", "+4.2%", "Unchanged", "Up from 0%"). Missing scores are
// shown as "—" and never subtracted.

import { DASH, formatChange, formatPercent, statusKind } from "../lib/format.js";
import { metricInfo } from "../lib/metric-catalog.js";
import { humanizeId, passedOutOf } from "../lib/wording.js";
import { entryWhen, outcome, passCount } from "./runner-list-model.js";

// Changes smaller than this (a hundredth of a percent) count as unchanged, matching formatChange.
const SAME_EPSILON = 0.0001;
export const ONLY_IN_ONE = "Only in one";
export const TREND_LABELS = Object.freeze({
  regressed: "Got worse",
  improved: "Got better",
  same: "Unchanged",
  only: ONLY_IN_ONE,
});

function list(value) {
  return Array.isArray(value) ? value : [];
}

function isScore(value) {
  return value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value));
}

/** b - a, or null when either score is missing. */
export function scoreDelta(a, b) {
  return isScore(a) && isScore(b) ? Number(b) - Number(a) : null;
}

/** Change text from the earlier score to `current`: "+33.3%", "Unchanged", "Only in one". */
export function changeText(delta, current) {
  if (delta === null || delta === undefined) return ONLY_IN_ONE;
  return formatChange(delta, current);
}

/** CSS class for a delta: up | down | same | "" (missing). */
export function changeClass(delta) {
  if (delta === null || delta === undefined) return "";
  if (Math.abs(delta) < SAME_EPSILON) return "same";
  return delta > 0 ? "up" : "down";
}

function passedFlag(result) {
  return !result?.observation?.error && statusKind(result?.passed) === "pass";
}

/** regressed | improved | same | only: by score first, then by a pass/fail flip. */
export function testTrend(before, after) {
  if (!before || !after) return "only";
  const delta = scoreDelta(before.weighted_score, after.weighted_score);
  if (delta !== null && Math.abs(delta) >= SAME_EPSILON) return delta > 0 ? "improved" : "regressed";
  const was = passedFlag(before);
  const now = passedFlag(after);
  if (was === now) return "same";
  return now ? "improved" : "regressed";
}

function cell(value) {
  return isScore(value) ? formatPercent(value) : DASH;
}

function change(before, after) {
  const delta = scoreDelta(before, after);
  return { before: cell(before), after: cell(after), change: changeText(delta, after), cls: changeClass(delta) };
}

function byKey(items, key) {
  return new Map(list(items).map((item) => [item?.[key], item]));
}

function union(a, b) {
  return [...new Set([...a.keys(), ...b.keys()])];
}

/** Per-check rows for one test: [{title, before, after, change, cls}]. */
export function checkChanges(before, after) {
  const a = byKey(before?.scores, "metric");
  const b = byKey(after?.scores, "metric");
  return union(a, b).map((metric) => ({
    title: metricInfo(metric).title || humanizeId(metric),
    ...change(a.get(metric)?.score, b.get(metric)?.score),
  }));
}

function testRow(id, before, after) {
  const trend = testTrend(before, after);
  return {
    id: String(id ?? ""),
    name: humanizeId(id) || "Test",
    ...change(before?.weighted_score, after?.weighted_score),
    trend,
    trendLabel: TREND_LABELS[trend],
    checks: checkChanges(before, after),
  };
}

function entryTime(entry) {
  const time = Date.parse(entry?.meta?.startedAt || entry?.run?.creation_ts || "");
  return Number.isFinite(time) ? time : Number(entry?.savedAt) || 0;
}

/** The two entries ordered [earlier, later]. */
export function orderPair(a, b) {
  return entryTime(a) <= entryTime(b) ? [a, b] : [b, a];
}

function side(entry, now) {
  const run = entry?.run || {};
  const { passed, total } = passCount(run);
  return {
    ...outcome(run),
    when: entryWhen(entry, now),
    score: cell(run.weighted_score),
    passed: passedOutOf(passed, total),
  };
}

function countTrend(rows, trend) {
  return rows.filter((row) => row.trend === trend).length;
}

/** Two entries -> {earlier, later, overall, rows, counts}; null when they are not two different runs. */
export function comparisonView(first, second, now = new Date()) {
  if (!first?.run || !second?.run || first === second) return null;
  const [earlier, later] = orderPair(first, second);
  const casesA = byKey(earlier.run.case_results, "case_id");
  const casesB = byKey(later.run.case_results, "case_id");
  const rows = union(casesA, casesB).map((id) => testRow(id, casesA.get(id), casesB.get(id)));
  return {
    earlier: side(earlier, now),
    later: side(later, now),
    overall: change(earlier.run.weighted_score, later.run.weighted_score),
    rows,
    counts: { regressed: countTrend(rows, "regressed"), improved: countTrend(rows, "improved") },
  };
}
