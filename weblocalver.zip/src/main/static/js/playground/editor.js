// Plain-textarea code editor with a line-number gutter and a quick JSON check.
// Tab inserts two spaces; Escape releases the editor so the next Tab moves focus on.

import { byteLength, fileRole, languageFor, lineCount, localValidation } from "./editor-model.js";
import { openFindBar } from "./find.js";
import { state, persistSoon } from "./store.js";
import { $ } from "./view.js";

const EDITOR = "#code-editor";
const EDITOR_STATE = "#editor-state";
const GUTTER = "#line-numbers";

const INDENT = "  ";
const RELEASE_HINT = "Press Tab to move on from the editor";
const BINARY_NOTE = "This file is not text, so it cannot be edited here. You can rename it, delete it or keep it as it is.";
const CHANGED = "Changed";

let tabReleased = false;
let gutterLines = 0;
let onEditCallback = () => {};

function renderGutter(count) {
  if (count === gutterLines) return;
  gutterLines = count;
  const gutter = $(GUTTER);
  const frag = document.createDocumentFragment();
  for (let i = 1; i <= count; i += 1) {
    const span = document.createElement("span");
    span.textContent = String(i);
    frag.appendChild(span);
  }
  gutter.replaceChildren(frag);
}

function updateChrome() {
  const ed = $(EDITOR);
  renderGutter(lineCount(ed.value));
  $(GUTTER).scrollTop = ed.scrollTop;
  const file = state.selected ? state.files[state.selected] : null;
  const check = file?.kind === "text" ? localValidation(ed.value, languageFor(state.selected)) : { tone: "info", text: "" };
  const box = $("#editor-validation");
  box.textContent = check.text;
  box.dataset.tone = check.tone;
}

function stateLabel(file) {
  if (!file) return "";
  return file.kind === "text" ? "You can edit this file" : "Cannot be edited here";
}

function editorValue(file) {
  if (!file) return "";
  return file.kind === "text" ? file.content : BINARY_NOTE;
}

/** Shows `path` in the editor (read-only for binary files). */
export function showFile(path) {
  const file = path ? state.files[path] : null;
  const ed = $(EDITOR);
  const editable = file?.kind === "text";
  $("#editor-path").textContent = file ? path : "Choose a file from the list";
  $("#editor-language").textContent = file ? fileRole(path, state.agent?.dataset_file) : "";
  $(EDITOR_STATE).textContent = stateLabel(file);
  ed.disabled = !editable;
  ed.value = editorValue(file);
  ed.scrollTop = 0;
  updateChrome();
}

function onInput(event) {
  const path = state.selected;
  const file = path ? state.files[path] : null;
  if (!file || file.kind !== "text") return;
  file.content = event.target.value;
  file.size = byteLength(file.content);
  $(EDITOR_STATE).textContent = CHANGED;
  updateChrome();
  persistSoon();
  onEditCallback(path);
}

function insertIndent(ed) {
  ed.setRangeText(INDENT, ed.selectionStart, ed.selectionEnd, "end");
  ed.dispatchEvent(new Event("input", { bubbles: true }));
}

function onKeydown(event) {
  const ed = event.currentTarget;
  if (event.key === "Escape") {
    tabReleased = true;
    $(EDITOR_STATE).textContent = RELEASE_HINT;
    return;
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "f") {
    event.preventDefault();
    openFindBar(false);
    return;
  }
  if (event.key !== "Tab" || event.shiftKey || event.altKey || event.ctrlKey || event.metaKey) return;
  if (tabReleased) return;
  event.preventDefault();
  insertIndent(ed);
}

/** Wires the editor. `onEdit(path)` runs after every content change. */
export function initEditor({ onEdit } = {}) {
  if (onEdit) onEditCallback = onEdit;
  const ed = $(EDITOR);
  ed.addEventListener("input", onInput);
  ed.addEventListener("keydown", onKeydown);
  ed.addEventListener("focus", () => { tabReleased = false; });
  ed.addEventListener("blur", () => {
    const status = $(EDITOR_STATE);
    if (status.textContent === RELEASE_HINT) status.textContent = stateLabel(state.files[state.selected]);
  });
  ed.addEventListener("scroll", () => { $(GUTTER).scrollTop = ed.scrollTop; });
}
