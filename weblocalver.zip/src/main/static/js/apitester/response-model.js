// Pure interpretation of a /api/playground/http result (no DOM access, unit-testable in Node).

/** The proxy cuts the upstream body text at this many characters (handlers/playground_http.py). */
export const SERVER_PREVIEW_CHARS = 2000;

function tryParseJson(text) {
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch {
    return { ok: false };
  }
}

/** Pretty-prints a body: structured values and JSON-looking strings are indented, other text is kept. */
export function prettyBody(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") {
    const parsed = value.trim() ? tryParseJson(value) : { ok: false };
    return parsed.ok && typeof parsed.value === "object" && parsed.value !== null
      ? JSON.stringify(parsed.value, null, 2)
      : value;
  }
  if (typeof value === "object") return JSON.stringify(value, null, 2);
  return String(value);
}

/** UTF-8 byte length of a string. */
export function byteLength(text) {
  return new TextEncoder().encode(String(text ?? "")).length;
}

function hasJson(result) {
  return result.json !== null && result.json !== undefined;
}

/**
 * Normalises the proxy result.
 * Returns {status, reason, ok, headers, display, rawText, truncated, truncatedAt, sizeBytes}.
 * When the upstream body parsed as JSON the full value is shown; otherwise `text`
 * is a preview and is flagged truncated when it reaches the server's cut-off.
 */
export function describeResponse(result, previewChars = SERVER_PREVIEW_CHARS) {
  const data = result || {};
  const status = Number(data.status ?? data.status_code ?? 0);
  const headers = data.headers && typeof data.headers === "object" ? data.headers : {};
  const text = typeof data.text === "string" ? data.text : "";
  const structured = hasJson(data);
  const cut = text.length >= previewChars;
  // A JSON body arrives whole in `json` even when `text` was cut, so re-serialise only then.
  const rawText = structured && cut ? JSON.stringify(data.json) : text;
  const truncated = !structured && cut;
  return {
    status,
    reason: String(data.reason || ""),
    ok: status > 0 && status < 400,
    headers,
    display: prettyBody(structured ? data.json : text),
    rawText,
    truncated,
    truncatedAt: truncated ? text.length : 0,
    sizeBytes: byteLength(rawText),
  };
}

/** 305 -> "305 ms", 2500 -> "2.5 seconds". */
export function formatDuration(durationMs) {
  const ms = Math.max(0, Number(durationMs) || 0);
  if (ms < 1000) return `${Math.round(ms)} ms`;
  return `${(ms / 1000).toFixed(1)} seconds`;
}

/** "Size: 456 bytes" plus a note when only the first part of the reply arrived. */
export function formatMeta(info) {
  const size = `Size: ${info.sizeBytes} ${info.sizeBytes === 1 ? "byte" : "bytes"}`;
  return info.truncated ? `${size} · only the first part is shown` : size;
}

/** Visible notice for a truncated preview, or "" when the full body was received. */
export function truncationNotice(info) {
  return info.truncated ? `The reply is long, so only the first ${info.truncatedAt} characters are shown.` : "";
}

const SPECIAL_STATUS = Object.freeze({
  401: "Sign-in needed. Check the details under Sign-in",
  403: "Access denied",
  404: "Not found. Check the address",
  408: "The server stopped waiting",
  429: "Too many requests. Wait a moment and try again",
});

const STATUS_BANDS = [
  { below: 300, tone: "ok", label: "Success" },
  { below: 400, tone: "ok", label: "Success (redirected)" },
  { below: 500, tone: "warn", label: "The request was refused" },
  { below: Infinity, tone: "bad", label: "The server had a problem" },
];

const TONE_ICONS = Object.freeze({ ok: "✓", warn: "!", bad: "×", idle: "" });

/** Tone and plain label for an HTTP status. */
export function statusBand(status) {
  const band = STATUS_BANDS.find((item) => status < item.below) || STATUS_BANDS[STATUS_BANDS.length - 1];
  return { tone: band.tone, label: SPECIAL_STATUS[status] || band.label };
}

/** Plain summary line: {tone, icon, text}, e.g. "✓ Success (200 OK) in 305 ms". */
export function responseSummary(info, durationMs) {
  const { tone, label } = statusBand(info.status);
  const code = `${info.status} ${info.reason}`.trim();
  return { tone, icon: TONE_ICONS[tone], text: `${label} (${code}) in ${formatDuration(durationMs)}` };
}

const FAILURE_RULES = [
  { test: (err) => err?.status === 0, text: "The evaluation service could not be reached" },
  { test: (err) => err?.status === 504, text: "The server took too long to answer" },
  { test: (err) => /certificate|ssl|tls/i.test(String(err?.message)), text: "The server’s security certificate could not be checked" },
  { test: (err) => err?.status === 502, text: "The server could not be reached" },
];

/** Summary for a request that got no reply: {tone, icon, text, details}. */
export function failureSummary(err) {
  const rule = FAILURE_RULES.find((item) => item.test(err));
  return {
    tone: "bad",
    icon: TONE_ICONS.bad,
    text: rule ? rule.text : "The request could not be sent",
    details: String(err?.message || err || ""),
  };
}

/** History badge: "✓ 200", "! 404", "× No answer". */
export function historyStatus(status) {
  const code = Number(status);
  if (!Number.isFinite(code) || code <= 0) return `${TONE_ICONS.bad} No answer`;
  return `${TONE_ICONS[statusBand(code).tone]} ${code}`;
}
