// Pure request building for the API tester (no DOM access, unit-testable in Node).
// Produces the body for POST /api/playground/http: {method, url, headers, json, data, body}.

const CONTENT_TYPE = "Content-Type";
const AUTHORIZATION = "Authorization";
const DEFAULT_API_KEY_HEADER = "X-API-Key";
const METHODS_WITHOUT_BODY = new Set(["GET", "HEAD"]);

/** True when the method carries a message body (everything except GET and HEAD). */
export function methodSendsBody(method) {
  return !METHODS_WITHOUT_BODY.has(String(method || "GET").toUpperCase());
}

const BODY_CONTENT_TYPES = Object.freeze({
  json: "application/json",
  form: "application/x-www-form-urlencoded",
  text: "text/plain",
});

/** Rows of [key, value] with a blank key are ignored; keys are trimmed. */
export function cleanRows(rows) {
  return (rows || [])
    .map(([key, value]) => [String(key ?? "").trim(), String(value ?? "")])
    .filter(([key]) => key !== "");
}

const BAD_ADDRESS = "That address does not look right. It should start with http:// or https://";

/** Error with a plain message plus the raw reason for "Technical details". */
export function plainError(message, details = "", cause = undefined) {
  const error = new Error(message, cause ? { cause } : undefined);
  error.details = details;
  return error;
}

/** Appends query parameters (repeated keys are kept, never overwritten). Throws on a bad URL. */
export function buildUrl(rawUrl, paramRows) {
  const text = String(rawUrl ?? "").trim();
  if (!text) throw plainError("Type the address you want to send the request to.");
  let url;
  try {
    url = new URL(text);
  } catch (err) {
    throw plainError(BAD_ADDRESS, `Invalid URL: ${text}`, err);
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") throw plainError(BAD_ADDRESS, `Unsupported scheme: ${url.protocol}`);
  for (const [key, value] of cleanRows(paramRows)) url.searchParams.append(key, value);
  return url.toString();
}

/** Encodes "user:pass" as UTF-8 then base64 (safe for non-ASCII credentials). */
export function basicAuthValue(user, pass) {
  const bytes = new TextEncoder().encode(`${user}:${pass}`);
  let binary = "";
  for (const byte of bytes) binary += String.fromCodePoint(byte);
  return `Basic ${btoa(binary)}`;
}

/** Returns the header entries an auth preset adds. auth: {type, key, value, user, pass}. */
export function authHeaders(auth) {
  const type = auth?.type || "none";
  const value = auth?.value || "";
  const key = String(auth?.key || "").trim();
  if (type === "bearer") return value ? { [AUTHORIZATION]: `Bearer ${value}` } : {};
  if (type === "apikey") return value ? { [key || DEFAULT_API_KEY_HEADER]: value } : {};
  if (type === "custom") return key && value ? { [key]: value } : {};
  if (type === "basic") {
    const user = auth?.user || "";
    const pass = auth?.pass || "";
    return user || pass ? { [AUTHORIZATION]: basicAuthValue(user, pass) } : {};
  }
  return {};
}

/** Parses "key=value" lines into an application/x-www-form-urlencoded string. */
export function encodeFormBody(text) {
  const params = new URLSearchParams();
  for (const line of String(text ?? "").split(/\r?\n/)) {
    const [key, ...rest] = line.split("=");
    if (key.trim()) params.append(key.trim(), rest.join("="));
  }
  return params.toString();
}

function parseJsonBody(text) {
  if (!String(text ?? "").trim()) return null;
  try {
    return JSON.parse(text);
  } catch (err) {
    throw plainError("The message to send is not valid JSON. Check for a missing comma, quote or bracket.", err.message, err);
  }
}

function hasHeader(headers, name) {
  const lower = name.toLowerCase();
  return Object.keys(headers).some((key) => key.toLowerCase() === lower);
}

/** Returns {json, data} for the body type and adds a default Content-Type header. */
export function buildBody(bodyType, bodyText, headers) {
  const type = bodyType in BODY_CONTENT_TYPES ? bodyType : "text";
  if (!hasHeader(headers, CONTENT_TYPE)) headers[CONTENT_TYPE] = BODY_CONTENT_TYPES[type];
  if (type === "json") return { json: parseJsonBody(bodyText), data: null };
  if (type === "form") return { json: null, data: encodeFormBody(bodyText) };
  return { json: null, data: String(bodyText ?? "") };
}

/**
 * Builds the proxy payload from the form state:
 * {method, url, params: [[k, v]], headers: [[k, v]], bodyType, bodyText, auth}.
 * Auth headers are applied last so they win over a same-named manual header.
 */
export function buildRequest(state) {
  const method = String(state.method || "GET").toUpperCase();
  const url = buildUrl(state.url, state.params);
  const headers = Object.fromEntries(cleanRows(state.headers));
  let json = null;
  let data = null;
  if (methodSendsBody(method)) {
    ({ json, data } = buildBody(state.bodyType, state.bodyText, headers));
  }
  Object.assign(headers, authHeaders(state.auth));
  const body = json ?? data;
  return { method, url, headers, json, data, body };
}
