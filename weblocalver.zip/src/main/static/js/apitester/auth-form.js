// Auth tab: shows the fields for the chosen preset and reads them for buildRequest.
// Credentials stay in the page; they are never written to history or storage.

const FIELDS_BY_TYPE = Object.freeze({
  none: [],
  bearer: ["value"],
  apikey: ["key", "value"],
  custom: ["key", "value"],
  basic: ["user", "pass"],
});
const ALL_FIELDS = ["key", "value", "user", "pass"];

export function createAuthForm() {
  const typeSelect = document.getElementById("auth-type");
  const input = (name) => document.getElementById(`auth-${name}`);
  const wrap = (name) => document.getElementById(`auth-${name}-wrap`);

  function update() {
    const visible = FIELDS_BY_TYPE[typeSelect.value] || [];
    for (const name of ALL_FIELDS) wrap(name).hidden = !visible.includes(name);
  }

  /** Returns {type, key, value, user, pass} for request.js authHeaders(). */
  function read() {
    return {
      type: typeSelect.value,
      key: input("key").value,
      value: input("value").value,
      user: input("user").value,
      pass: input("pass").value,
    };
  }

  typeSelect.addEventListener("change", update);
  update();
  return { read };
}
