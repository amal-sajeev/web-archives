// Accessible tabs (WAI-ARIA tabs pattern): aria-selected, roving tabindex,
// ArrowLeft / ArrowRight / Home / End with automatic activation.

function selectTab(tabs, target, { focus = false } = {}) {
  for (const tab of tabs) {
    const on = tab === target;
    tab.classList.toggle("active", on);
    tab.setAttribute("aria-selected", String(on));
    tab.tabIndex = on ? 0 : -1;
    const panel = document.getElementById(tab.getAttribute("aria-controls"));
    if (panel) panel.hidden = !on;
  }
  if (focus) target.focus();
}

function targetIndex(key, current, count) {
  if (key === "ArrowRight") return (current + 1) % count;
  if (key === "ArrowLeft") return (current - 1 + count) % count;
  if (key === "Home") return 0;
  if (key === "End") return count - 1;
  return -1;
}

/** Wires a [role=tablist] element. Returns select(name) to switch tabs by data-tab. */
export function initTabs(tablist) {
  const tabs = [...tablist.querySelectorAll('[role="tab"]')];
  for (const tab of tabs) {
    tab.addEventListener("click", () => selectTab(tabs, tab));
  }
  tablist.addEventListener("keydown", (event) => {
    const current = tabs.indexOf(document.activeElement);
    if (current === -1) return;
    const next = targetIndex(event.key, current, tabs.length);
    if (next === -1) return;
    event.preventDefault();
    selectTab(tabs, tabs[next], { focus: true });
  });
  const initial = tabs.find((tab) => tab.getAttribute("aria-selected") === "true") || tabs[0];
  if (initial) selectTab(tabs, initial);
  return {
    select(name) {
      const tab = tabs.find((t) => t.dataset.tab === name);
      if (tab) selectTab(tabs, tab);
    },
  };
}
