// Key/value row editor used by the Headers and Params tabs.
// Every generated input gets a visually hidden <label>; the remove button has an aria-label.

let rowSeq = 0;

function labelFor(input, text) {
  const label = document.createElement("label");
  label.className = "sr-only";
  label.htmlFor = input.id;
  label.textContent = text;
  return label;
}

function makeInput(kind, noun, value, index) {
  const input = document.createElement("input");
  input.id = `kv-${kind.toLowerCase()}-${index}`;
  input.placeholder = kind;
  input.value = value;
  input.autocomplete = "off";
  input.spellcheck = false;
  input.dataset.part = kind.toLowerCase();
  return { input, label: labelFor(input, `${noun} ${kind.toLowerCase()} ${index}`) };
}

/**
 * Creates an editor bound to a container element.
 * noun is the singular item name used in labels ("Header", "Parameter").
 */
export function createKvEditor(container, noun) {
  function addRow(key = "", value = "") {
    rowSeq += 1;
    const row = document.createElement("div");
    row.className = "kv-row";
    const keyField = makeInput("Name", noun, key, rowSeq);
    const valueField = makeInput("Value", noun, value, rowSeq);
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "button-quiet";
    remove.textContent = "Remove";
    remove.setAttribute("aria-label", `Remove ${noun.toLowerCase()} row`);
    remove.addEventListener("click", () => row.remove());
    // Labels go last so the inputs stay first/second in the grid (tools.css relies on :first-child).
    row.append(keyField.input, valueField.input, remove, keyField.label, valueField.label);
    container.appendChild(row);
    return keyField.input;
  }

  function setRows(rows) {
    container.replaceChildren();
    const list = rows && rows.length > 0 ? rows : [["", ""]];
    for (const [key, value] of list) addRow(key, value);
  }

  function rows() {
    return [...container.querySelectorAll(".kv-row")].map((row) => [
      row.querySelector('[data-part="name"]').value,
      row.querySelector('[data-part="value"]').value,
    ]);
  }

  return { addRow, setRows, rows };
}
