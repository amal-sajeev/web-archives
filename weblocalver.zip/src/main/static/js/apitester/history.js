// Recent-request history in localStorage. Only method, URL (with its query string),
// status and timestamp are stored; headers, bodies and credentials never are.

import { escapeHtml } from "../lib/fragments.js";
import { historyStatus } from "./response-model.js";

export const HISTORY_KEY = "ctna-api-tester-history";
const MAX_ITEMS = 20;

/** Returns the saved items, or [] when storage is unavailable or corrupt. */
export function readHistory() {
  try {
    const parsed = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.warn("API tester: could not read request history.", err);
    return [];
  }
}

function writeHistory(items) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items));
    return true;
  } catch (err) {
    console.warn("API tester: could not save request history.", err);
    return false;
  }
}

/** Moves (or adds) the method+URL pair to the top of the list, keeping MAX_ITEMS. */
export function addToHistory(items, entry) {
  const rest = items.filter((x) => !(x.method === entry.method && x.url === entry.url));
  return [entry, ...rest].slice(0, MAX_ITEMS);
}

export function clearHistory() {
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch (err) {
    console.warn("API tester: could not clear request history.", err);
  }
}

/** One history button; choosing it puts the request back in the form. */
export function itemHtml(item, index) {
  return `<button class="history-item" data-i="${index}" type="button">`
    + `<span class="history-top"><span class="history-method">${escapeHtml(item.method)}</span>`
    + `<span class="history-status">${escapeHtml(historyStatus(item.status))}</span></span>`
    + `<span class="history-url">${escapeHtml(item.url)}</span></button>`;
}

export const EMPTY_HISTORY_HTML = '<p class="field-note">Requests you send will be listed here, so you can send them again.</p>';

/**
 * History sidebar bound to a list element. onPick(item) runs when an entry is chosen.
 * Returns {render, record, clear}.
 */
export function createHistoryView(listEl, onPick) {
  let items = readHistory();

  function render() {
    listEl.innerHTML = items.length > 0
      ? items.map(itemHtml).join("")
      : EMPTY_HISTORY_HTML;
  }

  listEl.addEventListener("click", (event) => {
    const button = event.target.closest(".history-item");
    if (!button) return;
    const item = items[Number(button.dataset.i)];
    if (item) onPick(item);
  });

  function record(entry) {
    items = addToHistory(items, entry);
    writeHistory(items);
    render();
  }

  function clear() {
    items = [];
    clearHistory();
    render();
  }

  render();
  return { render, record, clear };
}
