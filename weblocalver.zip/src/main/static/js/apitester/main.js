// API tester page entry: a simple form (type, address, message) with the extra
// options (headers, sign-in, query) folded away, and a plain reply summary.
// Requests go through the service proxy (POST api/playground/http).

import "../ui/shell.js";
import { postJson } from "../lib/api.js";
import { noticeHtml } from "../playground/messages.js";
import { createAuthForm } from "./auth-form.js";
import { createHistoryView } from "./history.js";
import { createKvEditor } from "./kv-editor.js";
import { buildRequest, methodSendsBody } from "./request.js";
import { describeResponse } from "./response-model.js";
import { createResponseView } from "./response-view.js";
import { initTabs } from "./tabs.js";

const PROXY_URL = "api/playground/http";
const SEND_LABEL = "Send request";

const byId = (id) => document.getElementById(id);
const els = {
  method: byId("method"),
  url: byId("url"),
  send: byId("send"),
  bodyType: byId("body-type"),
  body: byId("body"),
  bodySection: byId("body-section"),
  noBodyNote: byId("no-body-note"),
  error: byId("request-error"),
};

const headersEditor = createKvEditor(byId("headers-list"), "Header");
const paramsEditor = createKvEditor(byId("params-list"), "Query value");
const auth = createAuthForm();
const view = createResponseView();
const historyView = createHistoryView(byId("history-list"), (item) => {
  els.method.value = item.method;
  els.url.value = item.url;
  // The saved URL already carries its query string; clear the rows so a resend does not repeat it.
  paramsEditor.setRows([]);
  showRequestError(null);
  updateBodyVisibility();
  els.url.focus();
});
let inFlight = false;

/** Shows a problem with the form itself (not with the reply). */
function showRequestError(err) {
  els.error.hidden = !err;
  els.error.innerHTML = err
    ? noticeHtml({ tone: "warn", title: err.message, details: err.details || "" })
    : "";
}

function updateBodyVisibility() {
  const sends = methodSendsBody(els.method.value);
  els.bodySection.hidden = !sends;
  els.noBodyNote.hidden = sends;
}

function readState() {
  return {
    method: els.method.value,
    url: els.url.value,
    params: paramsEditor.rows(),
    headers: headersEditor.rows(),
    bodyType: els.bodyType.value,
    bodyText: els.body.value,
    auth: auth.read(),
  };
}

function setBusy(busy) {
  inFlight = busy;
  els.send.disabled = busy;
  els.send.textContent = busy ? "Sending…" : SEND_LABEL;
  els.send.setAttribute("aria-busy", String(busy));
}

async function send() {
  if (inFlight) return;
  showRequestError(null);
  let req;
  try {
    req = buildRequest(readState());
  } catch (err) {
    showRequestError(err);
    return;
  }
  setBusy(true);
  view.showPending();
  const started = performance.now();
  try {
    const result = await postJson(PROXY_URL, req);
    const info = describeResponse(result);
    view.showResult(info, performance.now() - started);
    historyView.record({ method: req.method, url: req.url, status: String(info.status), ts: Date.now() });
  } catch (err) {
    view.showFailure(err);
    historyView.record({ method: req.method, url: req.url, status: "0", ts: Date.now() });
  } finally {
    setBusy(false);
  }
}

initTabs(document.querySelector(".request-tabs"));
headersEditor.setRows([["Accept", "application/json"]]);
paramsEditor.setRows([]);
updateBodyVisibility();

byId("add-header").addEventListener("click", () => headersEditor.addRow().focus());
byId("add-param").addEventListener("click", () => paramsEditor.addRow().focus());
byId("clear-history").addEventListener("click", () => historyView.clear());
els.method.addEventListener("change", updateBodyVisibility);
els.send.addEventListener("click", send);
els.url.addEventListener("keydown", (event) => {
  if (event.key !== "Enter") return;
  event.preventDefault();
  send();
});
