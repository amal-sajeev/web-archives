// Reply panel: a plain summary line first ("✓ Success (200 OK) in 305 ms"), then
// the size, technical details, the raw body and the reply headers.

import { escapeHtml } from "../lib/fragments.js";
import { showToast, showError } from "../ui/toast.js";
import { technicalDetailsHtml } from "../playground/messages.js";
import { failureSummary, formatMeta, responseSummary, truncationNotice } from "./response-model.js";

const IDLE_SUMMARY = { tone: "idle", icon: "", text: "Nothing sent yet" };
const IDLE_META = "Type an address above and press “Send request”. The reply will appear here.";

/** Reply headers as rows ("" when there are none). */
export function headersHtml(headers) {
  const entries = Object.entries(headers || {});
  if (entries.length === 0) return '<p class="field-note">The reply had no headers.</p>';
  return entries.map(([key, value]) => `<div class="response-header-row"><span>${escapeHtml(key)}</span>`
    + `<strong>${escapeHtml(value)}</strong></div>`).join("");
}

function lookupElements() {
  const byId = (id) => document.getElementById(id);
  return {
    summary: byId("response-summary"),
    meta: byId("response-meta"),
    details: byId("response-details"),
    region: byId("response-region"),
    content: byId("response-content"),
    notice: byId("response-truncated"),
    headersBox: byId("response-headers"),
    headersTitle: byId("response-headers-title"),
    headers: byId("response-headers-list"),
    copy: byId("copy-response"),
    clear: byId("clear-response"),
  };
}

function setSummary(els, { tone, icon, text }) {
  els.summary.className = `response-summary tone-${tone}`;
  els.summary.innerHTML = icon
    ? `<span class="summary-icon" aria-hidden="true">${escapeHtml(icon)}</span>${escapeHtml(text)}`
    : escapeHtml(text);
}

function setBody(els, { meta = "", details = "", content = "", notice = "", headers = null }) {
  els.meta.textContent = meta;
  els.details.innerHTML = technicalDetailsHtml(details);
  els.content.textContent = content;
  els.region.hidden = !content;
  els.notice.textContent = notice;
  els.notice.hidden = !notice;
  els.headersBox.hidden = !headers;
  if (headers) {
    els.headersTitle.textContent = `Reply headers (${Object.keys(headers).length})`;
    els.headers.innerHTML = headersHtml(headers);
  }
  els.copy.disabled = !content;
}

async function copyToClipboard(text) {
  if (!text) return;
  try {
    if (!navigator.clipboard) throw new Error("Copying is not available in this browser.");
    await navigator.clipboard.writeText(text);
    showToast("The reply was copied.", { kind: "ok" });
  } catch (err) {
    console.warn("API tester: copy failed.", err);
    showError(err);
  }
}

/** Creates the view. Tracks the text available to Copy. */
export function createResponseView() {
  const els = lookupElements();
  let copyText = "";

  function show(summary, body) {
    setSummary(els, summary);
    setBody(els, body);
    copyText = body.content || "";
  }

  const view = {
    showIdle: () => show(IDLE_SUMMARY, { meta: IDLE_META }),
    showPending() {
      setSummary(els, { tone: "idle", icon: "", text: "Sending…" });
      els.meta.textContent = "Waiting for the reply.";
    },
    showResult: (info, durationMs) => show(responseSummary(info, durationMs), {
      meta: formatMeta(info),
      content: info.display || "(The reply was empty.)",
      notice: truncationNotice(info),
      headers: info.headers,
    }),
    showFailure(err) {
      const summary = failureSummary(err);
      show(summary, { meta: "No reply was received.", details: summary.details });
    },
  };

  els.copy.addEventListener("click", () => copyToClipboard(copyText));
  els.clear.addEventListener("click", view.showIdle);
  view.showIdle();
  return view;
}
