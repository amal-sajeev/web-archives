// Classic script loaded synchronously in <head> on every page to avoid a
// flash of the wrong theme. Applies only an explicit stored choice; with no
// choice the CSS follows prefers-color-scheme.
(function applyStoredTheme() {
  "use strict";
  try {
    const stored = localStorage.getItem("ctna-theme");
    if (stored === "light" || stored === "dark") {
      document.documentElement.setAttribute("data-theme", stored);
    }
  } catch (err) {
    // Storage unavailable: fall back to the OS preference via CSS.
  }
})();
