const $ = (s) => document.querySelector(s);
const esc = (v) => CTNA.escapeHtml(String(v ?? ""));
const api = (path) => `${location.pathname.replace(/[^/]*$/, "")}${path.replace(/^\//, "")}`;
const DB_NAME = "ctna-config-playground";
const STORE = "workspace";
let state = { files: {}, root: "", agent: null, dataset: null, customTests: null, environment: null, selected: null, original: null, stream: null, lastRun: null, runs: [], selectedCases: [] };
function normalizeState() {
  state.files = state.files && typeof state.files === "object" ? state.files : {};
  state.selectedCases = Array.isArray(state.selectedCases) ? state.selectedCases : [];
  state.runs = Array.isArray(state.runs) ? state.runs : [];
}

function setStatus(text, cls="") { const el=$("#pg-status"); el.textContent=text; el.className="pill "+cls; }
function updateDirtyBadge(){ const b=$("#dirty-badge"); if(!b)return; const dirty=Object.keys(state.files).some(k=>{const a=state.files[k],o=state.original?.[k]; return !o || a.content!==o.content || a.kind!==o.kind || a.size!==o.size;}) || Object.keys(state.original||{}).some(k=>!state.files[k]); b.style.display=dirty?"inline-flex":"none"; }
function cloneFiles(files) { return JSON.parse(JSON.stringify(files)); }
function fileItems() { return Object.entries(state.files).map(([path,v]) => ({path, ...v})); }
function selectedFile() { return state.selected ? state.files[state.selected] : null; }

function openDb() { return new Promise((resolve,reject)=>{ const r=indexedDB.open(DB_NAME,1); r.onupgradeneeded=()=>r.result.createObjectStore(STORE); r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error); }); }
async function dbPut(value) { const db=await openDb(); return new Promise((res,rej)=>{ const tx=db.transaction(STORE,"readwrite"); tx.objectStore(STORE).put(value,"current"); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function dbGet() { const db=await openDb(); return new Promise((res,rej)=>{ const tx=db.transaction(STORE,"readonly"); const r=tx.objectStore(STORE).get("current"); r.onsuccess=()=>res(r.result||null); r.onerror=()=>rej(r.error); }); }
async function dbClear() { const db=await openDb(); return new Promise((res,rej)=>{ const tx=db.transaction(STORE,"readwrite"); tx.objectStore(STORE).delete("current"); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
let saveTimer;
function persistSoon() { clearTimeout(saveTimer); saveTimer=setTimeout(()=>dbPut(state).catch(console.warn),180); }

function renderFiles() {
  const list=$("#file-list"); list.innerHTML="";
  Object.keys(state.files).sort().forEach(path=>{
    const f=state.files[path]; const b=document.createElement("button"); b.type="button"; b.className="file-row"+(path===state.selected?" active":"");
    b.innerHTML=`<span class="file-name">${esc(path)}</span>${f.kind==="binary"?'<span class="binary">binary</span>':''}`;
    b.onclick=()=>selectFile(path); list.appendChild(b);
  });
}
function languageFor(path){const ext=(path.split('.').pop()||'').toLowerCase();return ext==='py'?'Python':(['yaml','yml'].includes(ext)?'YAML':ext==='json'?'JSON':'Plain text');}
function highlightCode(text,lang){
  // Keep the preview deliberately conservative. The editable textarea remains the source of truth.
  // The preview is escaped before token markup is added so arbitrary config text cannot become HTML.
  let h=esc(text);
  if(lang==='JSON'){
    h=h.replace(/(&quot;(?:\\.|[^&quot;])*?&quot;)\s*:/g,'<span class="tok-key">$1</span>:')
       .replace(/(&quot;(?:\\.|[^&quot;])*?&quot;)/g,'<span class="tok-string">$1</span>')
       .replace(/\b(-?\d+(?:\.\d+)?)\b/g,'<span class="tok-num">$1</span>')
       .replace(/\b(true|false|null)\b/g,'<span class="tok-atom">$1</span>');
  } else if(lang==='YAML'){
    h=h.replace(/^(\s*)([A-Za-z_][\w.-]*)(:)/gm,'$1<span class="tok-key">$2</span>$3')
       .replace(/(:\s*)(&quot;.*?&quot;|'.*?')/g,'$1<span class="tok-string">$2</span>')
       .replace(/(^|\s)#(.*)$/gm,'$1<span class="tok-comment">#$2</span>');
  } else if(lang==='Python'){
    h=h.replace(/(^|\s)(def|class|return|import|from|if|else|elif|for|while|in|try|except|with|as|async|await|True|False|None)(?=\s|:|\()/gm,'$1<span class="tok-keyword">$2</span>')
       .replace(/(^|\s)(#[^\n]*)/gm,'$1<span class="tok-comment">$2</span>');
  }
  return h || ' ';
}
function updateEditorChrome(){const ed=$("#code-editor"), text=ed.value||"", lines=text.split("\n").length; const gutter=$("#line-numbers"); gutter.innerHTML=Array.from({length:lines},(_,i)=>`<span>${i+1}</span>`).join(""); $("#editor-validation").textContent=validateLocal(ed.value,languageFor($("#editor-path").textContent));}
function validateLocal(text,lang){if(lang==='JSON'){try{JSON.parse(text);return 'JSON ✓'}catch(e){return 'JSON: '+e.message}} if(lang==='Python')return 'Python syntax: server validation'; return lang+' editing';}
function selectFile(path) {
  state.selected=path; const f=state.files[path]; $("#editor-path").textContent=path; $("#editor-language").textContent=languageFor(path);
  const ed=$("#code-editor"); ed.disabled=f.kind!=="text"; ed.value=f.kind==="text"?f.content:"Binary file. Rename, delete, or export this file.";
  $("#editor-state").textContent=f.kind==="text"?"Editable":"Read only"; updateEditorChrome(); renderFiles();
}
function updateWorkspaceMeta(){
  const a=state.agent||{}; const d=state.dataset||{};
  const title=$("#workspace-title"); const copy=$("#workspace-copy"); const target=$("#target-summary");
  if(title) title.textContent=a.name||a.agent_id||"Agent configuration";
  if(copy) copy.textContent=`${a.agent_id||"agent"} · ${d.dataset_id||"dataset"} v${d.version||"?"} · ${d.cases??0} cases`;
  const active=$("#base-url")?.value.trim() || a.base_url || "From agent.yaml";
  if(target) target.textContent=active;
  const def=$("#target-default"); if(def) def.textContent=a.base_url?`Default from agent.yaml: ${a.base_url}`:"No target is defined in agent.yaml";
}

function renderSummary() {
  const d=state.dataset||{}; const a=state.agent||{};
  $("#pg-stats").innerHTML=`<div class="pg-stat"><small>Agent</small><strong>${esc(a.agent_id||"-")}</strong></div><div class="pg-stat"><small>Cases</small><strong>${d.cases??"-"}</strong></div><div class="pg-stat"><small>Metrics</small><strong>${d.metrics??"-"}</strong></div><div class="pg-stat"><small>Dataset</small><strong>${esc(d.version?`${d.dataset_id} v${d.version}`:d.dataset_id||"-")}</strong></div>`;
  const base=$("#base-url"); if(base && !base.value) base.value=a.base_url||"";
  const warnings=(state._warnings||[]); const w=$("#pg-warning"); w.hidden=!warnings.length; w.textContent=warnings.join(" "); updateWorkspaceMeta();
}
function renderCustomTests(info=state.customTests||{}) { const panel=$("#custom-tests-panel"); if(!panel) return; panel.hidden=!info.present; if(!info.present)return; const declared=info.declared_scorers||[]; const list=$("#custom-tests-list"); $("#custom-tests-count").textContent=`${declared.length} scorer${declared.length===1?"":"s"} declared`; const syntax=info.syntax_error; $("#custom-tests-state").textContent=syntax?"Syntax error":"Detected"; $("#custom-tests-state").className=`status-chip ${syntax?"bad":""}`; list.innerHTML=declared.length?declared.map(n=>`<div class="custom-test-row"><span class="custom-test-check"></span><span>${esc(n)}</span></div>`).join(""):`<div class="pg-empty" style="padding:.4rem 0">No @scorer declarations found.</div>`; }

function showWorkspace() { $("#load-panel").hidden=true; $("#workspace").hidden=false; renderFiles(); renderSummary(); renderCustomTests(); renderCases(); if(state.selected && state.files[state.selected]) selectFile(state.selected); else if(Object.keys(state.files).length) selectFile(Object.keys(state.files)[0]); updateDirtyBadge(); }
function renderCases(){ normalizeState(); const list=$("#case-list"); if(!list)return; const cases=state.dataset?.case_items||[]; if(!cases.length){list.innerHTML='<div class="small-note">No dataset cases found.</div>';return;} list.innerHTML=cases.map(c=>`<label class="case-row"><input type="checkbox" data-case-id="${esc(c.id)}" ${(state.selectedCases||[]).includes(c.id)?'checked':''}><code>${esc(c.id)}</code><span>${esc(summarizeCase(c.input))}</span></label>`).join(''); list.querySelectorAll('input').forEach(x=>x.onchange=()=>{const id=x.dataset.caseId;if(x.checked){if(!state.selectedCases.includes(id))state.selectedCases.push(id)}else{state.selectedCases=state.selectedCases.filter(v=>v!==id)};updateCaseCount();persistSoon();}); updateCaseCount(); }
function summarizeCase(input){ try { const s=typeof input==='string'?input:JSON.stringify(input); return s.length>80?s.slice(0,80)+'…':s; } catch { return ''; } }
function updateCaseCount(){const total=state.dataset?.case_items?.length||0;const selected=(state.selectedCases||[]).length;const el=$("#case-selection-count");if(el)el.textContent=`${selected} of ${total} selected`; const run=$("#test-config");if(run)run.disabled=Boolean(state.stream)||selected===0;}


async function importZip(file) {
  setStatus("Importing…","running");
  const fd=new FormData(); fd.append("file",file);
  const r=await fetch(api("api/playground/inspect"),{method:"POST",body:fd});
  if(!r.ok) throw new Error(await r.text());
  const data=await r.json();
  state={...state, files:{}, root:data.root||"", agent:data.agent, dataset:data.dataset, customTests:data.custom_tests||null, environment:state.environment||null, _warnings:data.warnings||[], selected:null, original:null, lastRun:null, runs:[], selectedCases:(data.dataset?.case_items||[]).map(c=>c.id)};
  for(const item of data.files) state.files[item.path]={content:item.content,encoding:item.encoding,kind:item.kind,size:item.size};
  state.original=cloneFiles(state.files); state.selected=Object.keys(state.files).sort()[0];
  normalizeState(); await dbPut(state); showWorkspace(); setStatus("Ready","ok");
}

function downloadBlob(blob,name){ const u=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=u; a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(u),1000); }

async function exportZip() {
  const r=await fetch(api("api/playground/export"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({root:state.root,files:fileItems()})});
  if(!r.ok) throw new Error(await r.text()); downloadBlob(await r.blob(),`${state.agent?.agent_id||"agent"}-config-playground.zip`);
}

function formDataZip(blob){ const fd=new FormData(); fd.append("file",new File([blob],"agent-config-playground.zip",{type:"application/zip"})); const url=$("#base-url").value.trim(); if(url) fd.append("base_url",url); fd.append("judge_repetitions",String(Math.max(1,Math.min(5,Number($("#reps").value)||1)))); fd.append("case_ids_json",JSON.stringify(state.selectedCases||[])); return fd; }

async function refreshBundleMetadata() {
  const er=await fetch(api("api/playground/export"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({root:"",files:fileItems()})});
  if(!er.ok) throw new Error(await er.text());
  const blob=await er.blob();
  const fd=new FormData(); fd.append("file",new File([blob],"config.zip",{type:"application/zip"}));
  const r=await fetch(api("api/playground/inspect"),{method:"POST",body:fd});
  if(!r.ok) throw new Error(await r.text());
  const d=await r.json();
  state.root=d.root||""; state.agent=d.agent||state.agent; state.dataset=d.dataset||state.dataset; state._warnings=d.warnings||[]; state.customTests=d.custom_tests||state.customTests;
  const ids=new Set((state.dataset?.case_items||[]).map(c=>c.id));
  state.selectedCases=(state.selectedCases||[]).filter(id=>ids.has(id));
  renderSummary(); renderCustomTests(); renderCases(); updateDirtyBadge();
  return {blob,data:d};
}

async function testConfig() {
  $("#test-config").disabled=true; setStatus("Preparing test…","running"); $("#results").innerHTML='<div class="pg-empty"><span class="pg-busy"><span class="spinner"></span>Building the edited bundle…</span></div>';
  try {
    const refreshed=await refreshBundleMetadata();
    if(!state.selectedCases.length){throw new Error("Select at least one dataset case before running.");}
    const vfd=new FormData(); vfd.append("file",new File([refreshed.blob],"config.zip",{type:"application/zip"}));
    const vr=await fetch(api("api/playground/validate"),{method:"POST",body:vfd});
    const vd=await vr.json();
    if(!vr.ok || !vd.valid){throw new Error((vd.errors||[]).join("\n") || "Configuration validation failed.");}
    const blob=refreshed.blob;
    const r=await fetch(api("api/playground/start"),{method:"POST",body:formDataZip(blob)});
    if(!r.ok) throw new Error(await r.text());
    const d=await r.json(); state.stream=d.stream_id; const cancel=$("#cancel-run"); if(cancel){cancel.hidden=false;cancel.disabled=false;cancel.textContent="Cancel";} updateCaseCount(); attachStream(d.stream_id); setStatus("Running…","running");
  } catch(e) { showError(e.message||String(e)); $("#test-config").disabled=false; }
}
function applyProgressEvent(e, counters, es){
  if(!e || !e.type) return;
  const total=counters.total;
  if(e.type==="run_started"){ counters.total=Number(e.total_cases)||0; setStatus(counters.total?`Running… 0 / ${counters.total} cases`:"Running…","running"); }
  else if(e.type==="case_started"){ setStatus(counters.total?`Running… ${counters.casesDone} / ${counters.total} cases`:`Running… ${counters.casesDone} cases`,"running"); $("#cancel-run").hidden=false; renderProgress(counters.total,counters.casesDone,counters.metricsDone,e); }
  else if(e.type==="metric_done" || e.type==="metric_skipped"){ counters.metricsDone += 1; renderProgress(counters.total,counters.casesDone,counters.metricsDone,e); }
  else if(e.type==="case_done"){ counters.casesDone += 1; setStatus(counters.total?`Running… ${counters.casesDone} / ${counters.total} cases`:`Running… ${counters.casesDone} cases`,"running"); $("#cancel-run").hidden=false; renderProgress(counters.total,counters.casesDone,counters.metricsDone,e); }
  else if(e.type==="observation" || e.type==="metric_started"){ renderProgress(counters.total,counters.casesDone,counters.metricsDone,e); }
  else if(e.type==="playground_done"){ counters.done=true; renderRun(e.run); es?.close(); if(counters.poll) clearInterval(counters.poll); $("#test-config").disabled=false; $("#cancel-run").hidden=true; state.stream=null; setStatus(e.run.status,"ok"); }
  else if(e.type==="error"){ counters.done=true; showError(e.detail||"Preview failed"); es?.close(); if(counters.poll) clearInterval(counters.poll); $("#test-config").disabled=false; $("#cancel-run").hidden=true; state.stream=null; setStatus("Error","bad"); }
  else if(e.type==="run_cancelled"){ counters.done=true; showError(e.detail||"Preview run cancelled"); es?.close(); if(counters.poll) clearInterval(counters.poll); $("#test-config").disabled=false; $("#cancel-run").hidden=true; state.stream=null; setStatus("Cancelled","bad"); }
}
function attachStream(id) {
  const es=new EventSource(`${location.pathname.replace(/[^/]*$/,"")}api/evaluate/stream/${encodeURIComponent(id)}`); state.stream=id;
  const counters={total:0,casesDone:0,metricsDone:0,done:false,offset:0,poll:null,seen:new Set()};
  es.onopen=()=>setStatus("Running…","running");
  es.onmessage=(msg)=>{ let e; try{e=JSON.parse(msg.data);}catch{return;} if(e.seq && counters.seen.has(e.seq)) return; if(e.seq)counters.seen.add(e.seq); counters.offset=Math.max(counters.offset,e.seq||counters.offset+1); applyProgressEvent(e,counters,es); };
  es.onerror=()=>{ if(!counters.done) setStatus("Running… reconnecting","running"); };
  const poll=async()=>{
    if(counters.done) return;
    try{
      const url=api(`api/evaluate/stream/${encodeURIComponent(id)}/events?after=${counters.offset}`);
      const r=await fetch(url,{cache:"no-store"});
      if(!r.ok) return;
      const d=await r.json();
      for(const e of (d.events||[])){ if(e.seq && counters.seen.has(e.seq)) continue; if(e.seq)counters.seen.add(e.seq); counters.offset=Math.max(counters.offset,e.seq||counters.offset+1); applyProgressEvent(e,counters,es); }
      if(d.done && !counters.done){ counters.done=true; es.close(); if(d.run){ renderRun(d.run); $("#test-config").disabled=false; setStatus(d.run.status,"ok"); } }
    }catch{}
  };
  counters.poll=setInterval(poll,750);
  poll();
}
function renderProgress(total,casesDone,metricsDone,event){
  const root=$("#results");
  if(!root) return;
  if(root.querySelector(".run-progress")){
    const p=root.querySelector(".run-progress");
    const pct=total?Math.round((casesDone/total)*100):0;
    const label=total?`${casesDone} / ${total} cases`:`${casesDone} cases`;
    p.querySelector(".progress-bar-fill").style.width=`${pct}%`;
    p.querySelector(".progress-label").textContent=`${label} · ${metricsDone} metrics`;
    p.querySelector(".progress-detail").textContent=event?.case_id?`${event.type.replaceAll("_"," ")} · ${event.case_id}`:(event?.message||"");
  } else {
    root.innerHTML=`<div class="run-progress"><div class="progress-head"><strong>Evaluation in progress</strong><span class="progress-label">${total?`0 / ${total} cases`:"Starting…"}</span></div><div class="progress-track"><div class="progress-bar-fill" style="width:0%"></div></div><div class="progress-detail">${event?.message||"Preparing evaluation…"}</div></div>`;
  }
}
function showError(text){ $("#results").innerHTML=`<div class="pg-warning">${esc(text)}</div>`; }
function renderRun(run){
  state.lastRun=run; state.runs=state.runs||[]; state.runs.unshift(run); state.runs=state.runs.slice(0,10); persistSoon(); updateCompareOptions();
  const pass=CTNA.isPassingStatus(run.status); let html=`<div class="result-hero"><div class="result-score ${pass?"pass":"fail"}">${CTNA.formatPercent(run.weighted_score)}</div><div><strong class="${pass?"pass":"fail"}">${esc(run.status)}</strong></div><div class="result-meta">${esc(run.agent_id)} · ${esc(run.dataset_id)} v${esc(run.dataset_version)} · ${run.case_results.length} cases</div></div>`;
  for(const c of run.case_results){
    html+=`<details class="result-case" ${c.passed?"":"open"}><summary><strong class="${c.passed?"pass":"fail"}">${c.passed?"PASS":"FAIL"}</strong><span>${esc(c.case_id)}</span><span class="muted">${CTNA.formatPercent(c.weighted_score)}</span></summary><div class="result-case-body">`;
    if(c.observation?.error) html+=`<div class="pg-warning">${esc(c.observation.error)}</div>`;
    for(const s of c.scores){ html+=`<div class="result-metric"><strong class="${s.passed?"pass":"fail"}">${s.passed?"✓":"✗"} ${esc(s.metric)}</strong> · ${CTNA.formatPercent(s.score)} · threshold ${CTNA.formatPercent(s.threshold)}<div>${esc(s.rationale||"")}</div>${s.evidence?.length?`<div class="result-evidence">${esc(s.evidence.join("\n"))}</div>`:""}</div>`; }
    for(const s of (c.skipped||[])) html+=`<div class="result-metric muted">Skipped: ${esc(s.metric)} · ${esc(s.reason)}</div>`;
    html+=`</div></details>`;
  }
  $("#results").innerHTML=html;
}


function changeConfig(){ dbClear().catch(console.warn); state={files:{},root:"",agent:null,dataset:null,customTests:null,environment:null,selected:null,original:null,stream:null,lastRun:null,runs:[],selectedCases:[]}; const cancel=$("#cancel-run"); if(cancel){cancel.hidden=true;cancel.disabled=false;cancel.textContent="Cancel";} $("#workspace").hidden=true; $("#load-panel").hidden=false; $("#zip-input").value=""; setStatus("No config loaded"); }
function resetConfig(){ if(!state.original)return; state.files=cloneFiles(state.original); state.selected=Object.keys(state.files).sort()[0]; persistSoon(); showWorkspace(); updateDirtyBadge(); setStatus("Ready","ok"); }
function newFile(){ const path=prompt("New file path", "notes.txt"); if(!path)return; if(state.files[path])return alert("A file with that path already exists."); state.files[path]={content:"",encoding:"utf-8",kind:"text",size:0}; state.selected=path; persistSoon(); showWorkspace(); updateDirtyBadge(); }
function renameFile(){ if(!state.selected)return; const next=prompt("Rename file",state.selected); if(!next||next===state.selected)return; if(state.files[next])return alert("A file with that path already exists."); state.files[next]=state.files[state.selected]; delete state.files[state.selected]; state.selected=next; persistSoon(); showWorkspace(); updateDirtyBadge(); }
function deleteFile(){ if(!state.selected)return; if(!confirm(`Delete ${state.selected}?`))return; delete state.files[state.selected]; state.selected=Object.keys(state.files).sort()[0]||null; persistSoon(); showWorkspace(); updateDirtyBadge(); }

$("#choose-zip").onclick=()=>$("#zip-input").click(); $("#zip-input").onchange=()=>{const f=$("#zip-input").files[0]; if(f) importZip(f).catch(e=>{setStatus("Import failed","bad");showError(e.message||String(e));});};
$("#dropzone").ondragover=e=>{e.preventDefault();$("#dropzone").classList.add("drag")}; $("#dropzone").ondragleave=()=>$("#dropzone").classList.remove("drag"); $("#dropzone").ondrop=e=>{e.preventDefault();$("#dropzone").classList.remove("drag");const f=e.dataTransfer.files[0];if(f)importZip(f).catch(err=>showError(err.message||String(err)));};
$("#code-editor").addEventListener("input",e=>{if(!state.selected)return;state.files[state.selected].content=e.target.value;state.files[state.selected].size=new TextEncoder().encode(e.target.value).length;$("#editor-state").textContent="Unsaved browser edit";updateDirtyBadge();updateEditorChrome();persistSoon();if(state.selected==="agent.yaml" || state.selected===(state.agent?.dataset_file||"dataset.json")) scheduleMetadataRefresh();});
let metadataTimer;
function scheduleMetadataRefresh(){ clearTimeout(metadataTimer); metadataTimer=setTimeout(()=>refreshBundleMetadata().catch(()=>{}),900); }
$("#code-editor").addEventListener("scroll",()=>{const e=$("#code-editor");$("#line-numbers").scrollTop=e.scrollTop;});
$("#code-editor").addEventListener("keydown",e=>{if(e.key==="Tab"){e.preventDefault();const a=e.target.selectionStart,b=e.target.selectionEnd;e.target.value=e.target.value.slice(0,a)+"  "+e.target.value.slice(b);e.target.selectionStart=e.target.selectionEnd=a+2;e.target.dispatchEvent(new Event("input"));}});
$("#base-url").addEventListener("input",updateWorkspaceMeta); $("#test-config").onclick=()=>testConfig(); $("#export-config").onclick=()=>exportZip().catch(e=>showError(e.message||String(e)));
$("#validate-config").onclick=async()=>{ const box=$("#validation-result"); box.hidden=false; box.className="validation-result"; box.textContent="Validating…"; try{ const blob=await fetch(api("api/playground/export"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({root:"",files:fileItems()})}).then(async r=>{if(!r.ok)throw new Error(await r.text());return r.blob();}); const fd=new FormData(); fd.append("file",new File([blob],"config.zip",{type:"application/zip"})); const r=await fetch(api("api/playground/validate"),{method:"POST",body:fd}); const d=await r.json(); if(!r.ok)throw new Error(d.detail||"Validation failed"); if(d.custom_tests){ state.customTests={present:d.custom_tests.present,declared_scorers:d.custom_tests.declared_scorers||[],syntax_error:(d.errors||[]).find(x=>x.startsWith("custom_tests.py could not be loaded")||x.includes("syntax error"))||null,loaded_scorers:d.custom_tests.loaded_scorers||[]}; renderCustomTests(state.customTests); } box.className=`validation-result ${d.valid?"ok":"bad"}`; if(d.valid){ const custom=d.custom_tests?.loaded_scorers||[]; box.innerHTML=`✓ Configuration is valid and ready to run.${custom.length?`<div>${custom.length} custom scorer${custom.length===1?"":"s"} loaded: ${custom.map(esc).join(", ")}</div>`:""}`; } else { box.innerHTML=`<strong>Fix these issues:</strong><div>${(d.errors||[]).map(esc).join("<br>")}</div>`; } persistSoon(); }catch(e){box.className="validation-result bad";box.textContent=e.message||String(e);} };

$("#upload-file").onclick=()=>$("#file-input").click(); $("#file-input").onchange=async()=>{ const f=$("#file-input").files[0]; if(!f)return; const path=prompt("Path inside agent bundle",f.name); if(!path)return; if(state.files[path])return alert("A file with that path already exists."); if(/\.(yaml|yml|json|py|txt|md|toml|ini|cfg|xml|csv|env)$/i.test(path)){state.files[path]={content:await f.text(),encoding:"utf-8",kind:"text",size:f.size};}else{const b=new Uint8Array(await f.arrayBuffer());let bin="";for(const x of b)bin+=String.fromCharCode(x);state.files[path]={content:btoa(bin),encoding:"base64",kind:"binary",size:f.size};}state.selected=path;persistSoon();showWorkspace();updateDirtyBadge();};
 $("#change-config").onclick=changeConfig; $("#reset-config").onclick=resetConfig; $("#new-file").onclick=newFile; $("#rename-file").onclick=renameFile; $("#delete-file").onclick=deleteFile;
$("#cancel-run")?.addEventListener("click",async()=>{const id=state.stream;if(!id)return;const b=$("#cancel-run");b.disabled=true;b.textContent="Cancelling…";try{const r=await fetch(api(`api/evaluate/cancel/${encodeURIComponent(id)}`),{method:"POST"});if(!r.ok)throw new Error(await r.text());}catch(e){showError(e.message||String(e));b.disabled=false;b.textContent="Cancel";}});

async function loadEnvironment(){ try{ const r=await fetch(api("api/playground/environment")); if(!r.ok) throw new Error(await r.text()); state.environment=await r.json(); const body=$("#environment-details-body"); const e=state.environment; body.innerHTML=`<div class="env-grid"><strong>Service</strong><span>${esc(e.service_version)}</span><strong>Judge model</strong><span>${esc(e.judge_model)}</span><strong>Vertex location</strong><span>${esc(e.project_location)}</span><strong>Metrics source</strong><span>${esc(e.metrics_source)}</span><strong>Embedding model</strong><span>${esc(e.embedding_model)}</span><strong>Judge samples</strong><span>${esc(e.judge_samples)}</span><strong>Judge retries</strong><span>${esc(e.judge_retries)}</span><strong>Judge concurrency</strong><span>${esc(e.judge_concurrency)}</span><strong>Case concurrency</strong><span>${esc(e.case_concurrency)}</span><strong>Credentials</strong><span>${esc(e.auth_mode)}</span></div>`; }catch(e){ $("#environment-details-body").innerHTML=`<div class="pg-warning">${esc(e.message||e)}</div>`; } }

$("#environment-details")?.addEventListener("click",async()=>{ const d=$("#environment-dialog"); await loadEnvironment(); d.showModal(); });
$("#close-environment")?.addEventListener("click",()=>$("#environment-dialog").close());
$("#theme-toggle").onclick=()=>{const next=document.documentElement.getAttribute("data-theme")==="dark"?"light":"dark";document.documentElement.setAttribute("data-theme",next);localStorage.setItem("ctna-theme",next);};

(async()=>{ try{ const saved=await dbGet(); if(saved?.files && Object.keys(saved.files).length){ state={...state,...saved}; normalizeState(); state.original=state.original||cloneFiles(state.files); if(!state.selectedCases.length && state.dataset?.case_items?.length) state.selectedCases=state.dataset.case_items.map(c=>c.id); showWorkspace(); updateDirtyBadge(); setStatus("Restored from browser","ok"); } }catch(e){console.warn(e);} })();

// Case controls
$("#select-all-cases")?.addEventListener("click",()=>{state.selectedCases=(state.dataset?.case_items||[]).map(c=>c.id);renderCases();persistSoon();});
$("#clear-cases")?.addEventListener("click",()=>{state.selectedCases=[];renderCases();persistSoon();});
// Find / replace
$("#find-button")?.addEventListener("click",()=>{const b=$("#findbar");b.hidden=!b.hidden;b.setAttribute("aria-hidden",String(b.hidden));if(!b.hidden)$("#find-input").focus();});
$("#replace-button")?.addEventListener("click",()=>{const b=$("#findbar");b.hidden=false;b.setAttribute("aria-hidden","false");$("#replace-input").focus();});
$("#close-find")?.addEventListener("click",()=>{const b=$("#findbar");b.hidden=true;b.setAttribute("aria-hidden","true");});
$("#find-next")?.addEventListener("click",()=>{const ed=$("#code-editor"),q=$("#find-input").value;if(!q)return;const start=ed.selectionEnd,idx=ed.value.indexOf(q,start);const pos=idx<0?ed.value.indexOf(q):idx;if(pos>=0){ed.focus();ed.setSelectionRange(pos,pos+q.length);}});
$("#replace-one")?.addEventListener("click",()=>{const ed=$("#code-editor"),q=$("#find-input").value,r=$("#replace-input").value;if(q && ed.value.slice(ed.selectionStart,ed.selectionEnd)===q){ed.setRangeText(r,ed.selectionStart,ed.selectionEnd,'end');ed.dispatchEvent(new Event('input'));}});
$("#replace-all")?.addEventListener("click",()=>{const ed=$("#code-editor"),q=$("#find-input").value,r=$("#replace-input").value;if(!q)return;ed.value=ed.value.split(q).join(r);ed.dispatchEvent(new Event('input'));});
// Run comparison
function updateCompareOptions(){const a=$("#compare-a"),b=$("#compare-b");if(!a||!b)return;const runs=state.runs||[];const opts=runs.map((r,i)=>`<option value="${i}">${esc(new Date(r.creation_ts||Date.now()).toLocaleString())} · ${esc(r.weighted_score==null?"—":Number(r.weighted_score).toFixed(3))} · ${esc((r.run_id||"unknown").slice(0,8))}</option>`).join('');a.innerHTML=opts;b.innerHTML=opts;if(runs.length>1){a.value='1';b.value='0';renderComparison();}}
function renderComparison(){const runs=state.runs||[],a=runs[Number($("#compare-a")?.value||0)],b=runs[Number($("#compare-b")?.value||0)],out=$("#compare-output");if(!a||!b||a===b){if(out)out.innerHTML='<div class="pg-empty">Choose two different runs.</div>';return;}const amap=new Map((a.case_results||[]).map(c=>[c.case_id,c])),bmap=new Map((b.case_results||[]).map(c=>[c.case_id,c]));const ids=[...new Set([...amap.keys(),...bmap.keys()])];let html=`<div class="compare-summary"><div class="pg-stat"><small>Run A</small><strong>${CTNA.formatPercent(a.weighted_score)}</strong></div><div class="pg-stat"><small>Run B</small><strong>${CTNA.formatPercent(b.weighted_score)}</strong></div><div class="pg-stat"><small>Change</small><strong class="${b.weighted_score>=a.weighted_score?'pass':'fail'}">${(b.weighted_score-a.weighted_score)>=0?'+':''}${CTNA.formatPercent(b.weighted_score-a.weighted_score)}</strong></div></div><table class="compare-table"><thead><tr><th>Case</th><th>A</th><th>B</th><th>Δ</th><th>Metric changes</th></tr></thead><tbody>`;for(const id of ids){const ca=amap.get(id),cb=bmap.get(id),sa=ca?.weighted_score??null,sb=cb?.weighted_score??null,d=sa!==null&&sb!==null?sb-sa:null;const ma=new Map((ca?.scores||[]).map(x=>[x.metric,x.score]));const mb=new Map((cb?.scores||[]).map(x=>[x.metric,x.score]));const mids=[...new Set([...ma.keys(),...mb.keys()])];const changes=mids.map(m=>{const x=ma.get(m),y=mb.get(m);return x!=null&&y!=null&&Math.abs(y-x)>1e-9?`${esc(m)} ${y-x>=0?'+':''}${CTNA.formatPercent(y-x)}`:''}).filter(Boolean).join('<br>')||'—';html+=`<tr><td>${esc(id)}</td><td>${sa===null?'—':CTNA.formatPercent(sa)}</td><td>${sb===null?'—':CTNA.formatPercent(sb)}</td><td class="${d===null?'':d>=0?'up':'down'}">${d===null?'new/removed':(d>=0?'+':'')+CTNA.formatPercent(d)}</td><td>${changes}</td></tr>`;}html+='</tbody></table>';out.innerHTML=html;}
$("#compare-runs")?.addEventListener("click",()=>{$("#compare-dialog").showModal();updateCompareOptions();renderComparison();});$("#close-compare")?.addEventListener("click",()=>$("#compare-dialog").close());$("#compare-a")?.addEventListener("change",renderComparison);$("#compare-b")?.addEventListener("change",renderComparison);
