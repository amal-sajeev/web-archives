"""Document table scorers (DOCX via python-docx, PDF via pdfplumber).

Scorers:
  - ``docx_table_has`` -- DOCX tables with required headers and minimum rows.
  - ``pdf_table_has``  -- PDF tables with required headers and minimum rows.

Both resolve the document bytes the same way (``_resolve_doc_bytes``) and match
table constraints the same way (``_match_tables``); they differ only in how the
tables are read. A missing optional library skips the metric.
"""

from __future__ import annotations

import base64
import binascii
import importlib
import io
import logging
from typing import Any

from .base import MetricSkipped, scorer
from ._util import config_int, mark, spec_config

logger = logging.getLogger(__name__)

_NO_TABLES = "no table constraints configured"
_MAGIC = {"docx": b"PK", "pdf": b"%PDF"}
_PDF_MODULE = "pdfplumber"
_UTF8 = "utf-8"
_PACKAGES = {"docx": "python-docx", _PDF_MODULE: _PDF_MODULE}

Table = list[list[str]]


def _output_kind(observation, cfg: dict[str, Any]) -> str | None:
    kind = cfg.get("output_kind") or (observation.metadata or {}).get("output_kind")
    return str(kind).lower() if kind else None


def _decode_unknown(raw: str, doc_type: str) -> bytes:
    """No declared output_kind: accept base64 only if it decodes to the doc type."""
    try:
        decoded = base64.b64decode(raw, validate=True)
    except (binascii.Error, ValueError):
        return raw.encode(_UTF8)
    return decoded if decoded.startswith(_MAGIC[doc_type]) else raw.encode(_UTF8)


def _resolve_doc_bytes(observation, cfg: dict[str, Any], doc_type: str) -> bytes:
    """Raw document bytes from metadata.raw_output (or output).

    Strings are base64-decoded only when ``output_kind == "base64"`` (from the
    metric config or observation metadata). Without a declared kind, a string is
    decoded only if the result carries the document's magic header.
    """
    meta = observation.metadata or {}
    raw = meta.get("raw_output")
    if raw is None:
        raw = observation.output
    if isinstance(raw, bytes | bytearray):
        return bytes(raw)
    if not isinstance(raw, str):
        raise MetricSkipped(f"could not resolve {doc_type.upper()} bytes from observation")
    kind = _output_kind(observation, cfg)
    if kind == "url":
        raise MetricSkipped(f"{doc_type.upper()} output is a URL; document bytes unavailable")
    if kind == "base64":
        try:
            return base64.b64decode(raw, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise MetricSkipped(f"output_kind=base64 but output is not valid base64: {exc}") from exc
    if kind is None:
        return _decode_unknown(raw, doc_type)
    return raw.encode(_UTF8)


def _headers(tbl: Table) -> list[str]:
    """Lower-cased first-row cells; empty tables have no headers."""
    return [str(c or "").strip().lower() for c in tbl[0]] if tbl else []


def _table_ok(tbl: Table, required: list[str], min_rows: int) -> bool:
    headers = _headers(tbl)
    return len(tbl) >= min_rows and all(h in headers for h in required)


def _match_tables(tables_spec: list[dict[str, Any]], tables: list[Table]) -> tuple[float, str, list[str]]:
    """Score how many table constraints are met by some table in `tables`."""
    checks, evidence = 0, []
    for i, tspec in enumerate(tables_spec):
        required = [str(h).strip().lower() for h in tspec.get("required_headers", [])]
        min_rows = config_int(tspec, "min_rows", 1)
        found = any(_table_ok(tbl, required, min_rows) for tbl in tables)
        checks += int(found)
        evidence.append(f"{mark(found)} table #{i}: headers={required} min_rows={min_rows}")
    return checks / len(tables_spec), f"{checks}/{len(tables_spec)} table constraints met", evidence


def _docx_tables(doc_bytes: bytes) -> list[Table]:
    import docx

    document = docx.Document(io.BytesIO(doc_bytes))
    return [[[c.text for c in row.cells] for row in tbl.rows] for tbl in document.tables]


def _pdf_tables(doc_bytes: bytes) -> list[Table]:
    import pdfplumber

    tables: list[Table] = []
    with pdfplumber.open(io.BytesIO(doc_bytes)) as pdf:
        for page in pdf.pages:
            tables.extend(page.extract_tables() or [])
    return tables


def _table_scorer(observation, spec, doc_type: str, module: str, reader):
    cfg = spec_config(spec)
    tables_spec = cfg.get("tables", [])
    if not tables_spec:
        return 1.0, _NO_TABLES, []
    try:
        importlib.import_module(module)
    except ImportError as exc:
        raise MetricSkipped(
            f"{_PACKAGES[module]} is not installed; {doc_type}_table_has is skipped. "
            f"Install {_PACKAGES[module]} to enable {doc_type.upper()} table checks."
        ) from exc
    doc_bytes = _resolve_doc_bytes(observation, cfg, doc_type)
    try:
        tables = reader(doc_bytes)
    except Exception as exc:  # corrupt/unsupported document -> a scored failure
        logger.info("%s table parse failed: %s: %s", doc_type, type(exc).__name__, exc)
        return 0.0, f"could not parse {doc_type.upper()} tables: {exc}", []
    return _match_tables(tables_spec, tables)


@scorer("docx_table_has")
def docx_table_has(*, observation, case, spec=None, **_):
    """DOCX tables must contain required headers and minimum rows.

    config:
      tables: [{required_headers: [str, ...], min_rows: int}, ...]
      output_kind: "base64" | "bytes" | "text"  (optional; else from metadata)

    Requires python-docx; skips cleanly if absent.
    """
    return _table_scorer(observation, spec, "docx", "docx", _docx_tables)


@scorer("pdf_table_has")
def pdf_table_has(*, observation, case, spec=None, **_):
    """PDF tables must contain required headers and minimum rows.

    config:
      tables: [{required_headers: [str, ...], min_rows: int}, ...]
      output_kind: "base64" | "bytes" | "text"  (optional; else from metadata)

    Requires ``pdfplumber``; skips cleanly (MetricSkipped) if not installed.
    """
    return _table_scorer(observation, spec, "pdf", _PDF_MODULE, _pdf_tables)
