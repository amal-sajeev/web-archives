"""Backward-compatible shim for the legacy `scorers.configurable` import path.

Config-driven scorers are split across ``configurable_text``,
``configurable_json`` and ``configurable_advanced`` (itself a shim over
``document_structure``, ``document_tables`` and ``rubric``). Older code still
imports ``scorers.configurable``, so the same public surface is re-exported
here. Patch judge factories in ``scorers.rubric``, where they are looked up.
"""

from __future__ import annotations

from . import configurable_advanced, configurable_json, configurable_text
from .configurable_advanced import (
    docx_table_has,
    heading_count,
    pdf_table_has,
    rubric,
    rubric_multi,
    section_present,
)
from .configurable_json import field_match, json_path, json_schema_valid_config
from .configurable_text import contains, keyword_count, length_range, not_contains, not_empty, regex_match
from .vertex import MultiRubricVerdict, build_judge_for

__all__ = [
    "MultiRubricVerdict",
    "build_judge_for",
    "configurable_advanced",
    "configurable_json",
    "configurable_text",
    "contains",
    "docx_table_has",
    "field_match",
    "heading_count",
    "json_path",
    "json_schema_valid_config",
    "keyword_count",
    "length_range",
    "not_contains",
    "not_empty",
    "pdf_table_has",
    "regex_match",
    "rubric",
    "rubric_multi",
    "section_present",
]
