"""Built-in deterministic (objective) scorers.

Each takes keyword args: observation (Observation), case (GoldenCase),
metrics (dict from the metrics API for this case). Returns (score, rationale,
evidence[, extras]). Missing inputs raise MetricSkipped instead of scoring.
"""

from __future__ import annotations

import json
import math
import re

from .base import MetricSkipped, scorer
from ._util import as_list, mark, output_text

_MARKUP_RE = re.compile(r"[*_`#]")


def _norm(text: str) -> str:
    """Strip Markdown emphasis/heading marks and lower-case."""
    return _MARKUP_RE.sub("", str(text)).lower()


def _args_blob(observation) -> str:
    return json.dumps(observation.tool_calls, ensure_ascii=False, default=str).lower()


@scorer("tool_selection")
def tool_selection(*, observation, case, metrics=None, **_) -> tuple[float, str, list[str]]:
    """Did the agent call the expected tool and pass through expected values?"""
    expected_tool = case.expected.get("expected_tool")
    if not expected_tool:
        raise MetricSkipped("tool_selection requires case.expected.expected_tool")
    expected_values = as_list(case.expected.get("expected_values"))
    called = {tc.get("name", "") for tc in observation.tool_calls}
    args_blob = _args_blob(observation)

    checks: list[bool] = [expected_tool in called]
    evidence = [f"called tools: {sorted(called)}", f"expected tool: {expected_tool}"]
    for value in expected_values:
        hit = str(value).lower() in args_blob
        checks.append(hit)
        evidence.append(f"{mark(hit)} value '{value}'")
    return sum(checks) / len(checks), f"{sum(checks)}/{len(checks)} tool-selection checks passed", evidence


@scorer("identifier_passthrough")
def identifier_passthrough(*, observation, case, metrics=None, **_) -> tuple[float, str, list[str]]:
    """Check that every expected identifier appears verbatim in tool-call arguments."""
    expected_values = as_list(case.expected.get("expected_values"))
    if not expected_values:
        return 1.0, "no identifiers to check", []

    args_blob = _args_blob(observation)
    missing = [value for value in expected_values if str(value).lower() not in args_blob]
    evidence = [f"{mark(value not in missing)} {value}" for value in expected_values]
    if missing:
        return 0.0, f"missing: {missing}", evidence
    return 1.0, "all identifiers passed through", evidence


@scorer("assertions")
def assertions(*, observation, case, metrics=None, **_) -> tuple[float, str, list[str]]:
    """Verbatim present/absent assertions from case.expected.spot_checks.

    Output text and search terms get the same normalisation (Markdown marks
    stripped, lower-cased), so ``**Acme**`` matches the term ``Acme``. The
    output is searched as readable text (report bundles as prose, documents as
    extracted text), so JSON keys such as ``content`` never satisfy or break an
    assertion.
    """
    checks = case.expected.get("spot_checks", [])
    if not checks:
        return 1.0, "no assertions defined", []
    text = _norm(output_text(observation))

    passed = 0
    evidence: list[str] = []
    for chk in checks:
        want_present = chk.get("expect", "present") == "present"
        all_of = as_list(chk.get("all_of"))
        terms = [_norm(t) for t in (all_of or as_list(chk.get("any_of")))]
        found = all(t in text for t in terms) if all_of else any(t in text for t in terms)
        ok = found if want_present else not found
        passed += int(ok)
        evidence.append(f"{mark(ok)} {chk.get('id', '?')}")
    return passed / len(checks), f"{passed}/{len(checks)} assertions passed", evidence


def _numeric_metric(metrics: dict | None, name: str | None, source: str) -> float:
    """Fetch a numeric metric or raise MetricSkipped when it is absent/invalid."""
    value = (metrics or {}).get(name) if name else None
    if value is None:
        raise MetricSkipped(f"metric '{name}' missing from {source}")
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise MetricSkipped(f"metric '{name}' not numeric: {value!r}") from exc


def _clamp01(v: float) -> float:
    """Clamp to [0, 1]; NaN maps to 0."""
    if math.isnan(v):
        return 0.0
    return min(max(v, 0.0), 1.0)


@scorer("metric_threshold")
def metric_threshold(*, observation, case, metrics=None, metric_name=None, **_):
    """Pass through a numeric metric supplied by the metrics API.

    The score is the value clamped to [0, 1] (NaN -> 0); the raw value is in
    ``extras.raw_value`` so the runner can normalise it with the spec bounds.
    """
    name = metric_name or case.expected.get("metric_name")
    v = _numeric_metric(metrics, name, "metrics API response")
    if math.isnan(v):
        return 0.0, f"metric '{name}' is NaN", [f"{name}=nan"]
    return _clamp01(v), f"metric '{name}' = {v}", [f"{name}={v}"], {"raw_value": v}


@scorer("ai_confidence")
def ai_confidence(*, observation, case, metrics=None, **_) -> tuple[float, str, list[str]]:
    """Use the model's self-reported AI_Confidence_Score (0..1) as the score."""
    v = _clamp01(_numeric_metric(metrics, "ai_confidence_score", "CTA_ACTION payload"))
    return v, f"AI_Confidence_Score = {v}", [f"ai_confidence_score={v}"]
