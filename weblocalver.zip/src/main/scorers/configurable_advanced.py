"""Backward-compatible shim for the document-structure and LLM rubric scorers.

The implementations now live in:
  - ``document_structure.py`` -- ``section_present``, ``heading_count``.
  - ``document_tables.py``    -- ``docx_table_has``, ``pdf_table_has``.
  - ``rubric.py``             -- ``rubric``, ``rubric_multi``.

Importing this module still registers all of them. Patch judge factories where
they are looked up (``scorers.rubric.build_judge`` / ``build_judge_for``), not here.
"""

from __future__ import annotations

from .document_structure import heading_count, section_present
from .document_tables import docx_table_has, pdf_table_has
from .rubric import rubric, rubric_multi

__all__ = [
    "docx_table_has",
    "heading_count",
    "pdf_table_has",
    "rubric",
    "rubric_multi",
    "section_present",
]
