"""Scorer registry primitives.

Scorer contract
---------------
A scorer is a callable taking keyword arguments (``observation``, ``case``,
``metrics``, ``spec``, ``judge_repetitions`` ... plus ``**_`` for forward
compatibility) and returning a :data:`ScorerResult`:

* ``(score, rationale, evidence)`` or
* ``(score, rationale, evidence, extras)``

``extras`` may carry ``raw_value`` (a raw measurement such as a latency in ms or
a hit count), ``variance``, ``unstable`` and ``position_bias``. The runner
normalises ``extras["raw_value"]`` through the MetricSpec bounds when it is
present, and ``score`` otherwise, so ``score`` should be in [0, 1] whenever no
``raw_value`` is supplied. Because ``raw_value`` replaces the score, scorers
whose score already encodes the verdict (PII found, error count, a length
inside a range...) report audit-only numbers under another key (``measured``,
``response_code``...) unless the MetricSpec opts into normalisation; see
``_util.measurement``.

A scorer that cannot run (missing input, missing credentials, invalid config)
raises :class:`MetricSkipped` rather than inventing a 1.0 or 0.0.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)

ScorerResult = tuple[float, str, list[str]] | tuple[float, str, list[str], dict[str, Any]]
"""A scorer's return value: ``(score, rationale, evidence[, extras])``."""

ScorerFn = Callable[..., ScorerResult]

_REGISTRY: dict[str, ScorerFn] = {}

# Judge-ness travels on the function object so it survives snapshot/restore of
# the registry; `_JUDGE_NAMES` covers callables that refuse attribute writes.
_JUDGE_ATTR = "__scorer_judge__"
_JUDGE_NAMES: set[str] = set()


class MetricSkipped(Exception):
    """Raised by a scorer that cannot run (e.g. no Vertex creds for the judge).

    The runner omits a skipped metric from the weighted score and gate rather
    than failing the whole run, so the service is still exercisable offline.
    """

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def _origin(fn: Any) -> str:
    return f"{getattr(fn, '__module__', '?')}.{getattr(fn, '__qualname__', repr(fn))}"


def _warn_if_override(name: str, fn: ScorerFn) -> None:
    existing = _REGISTRY.get(name)
    if existing is None or existing is fn:
        return
    if _origin(existing) == _origin(fn):
        # Same definition re-imported (module reload, playground re-load).
        logger.debug("scorer '%s' re-registered from %s", name, _origin(fn))
        return
    logger.warning(
        "scorer '%s' registered twice: %s replaces %s", name, _origin(fn), _origin(existing)
    )


def scorer(name: str, *, judge: bool = False) -> Callable[[ScorerFn], ScorerFn]:
    """Decorator registering a scorer under `name`.

    ``judge=True`` marks scorers that call the LLM judge, so the runner can
    throttle them with the judge semaphore (see :func:`is_judge_scorer`).
    """
    def _wrap(fn: ScorerFn) -> ScorerFn:
        _warn_if_override(name, fn)
        try:
            setattr(fn, _JUDGE_ATTR, judge)
        except (AttributeError, TypeError):
            if judge:
                _JUDGE_NAMES.add(name)
            else:
                _JUDGE_NAMES.discard(name)
        _REGISTRY[name] = fn
        return fn
    return _wrap


def is_judge_scorer(name: str) -> bool:
    """True when the scorer registered under `name` calls the LLM judge."""
    fn = _REGISTRY.get(name)
    if fn is None:
        return False
    flag = getattr(fn, _JUDGE_ATTR, None)
    # The attribute wins when present; the name set only covers callables that
    # refused it (a stale name must not make a later plain scorer a judge).
    return name in _JUDGE_NAMES if flag is None else bool(flag)


def get_scorer(name: str) -> ScorerFn:
    """Return the scorer registered under `name`, or raise KeyError."""
    if name not in _REGISTRY:
        raise KeyError(
            f"Unknown scorer '{name}'. Registered: {sorted(_REGISTRY)}. "
            "Add it as a built-in or in the agent's custom_tests.py."
        )
    return _REGISTRY[name]


def all_scorers() -> dict[str, ScorerFn]:
    """Return a copy of the registry (name -> scorer)."""
    return dict(_REGISTRY)


def snapshot_scorers() -> dict[str, ScorerFn]:
    """Capture the process-global scorer registry before a scoped plugin load."""
    return dict(_REGISTRY)


def restore_scorers(snapshot: dict[str, ScorerFn]) -> None:
    """Restore the process-global scorer registry after a scoped plugin load."""
    _REGISTRY.clear()
    _REGISTRY.update(snapshot)
