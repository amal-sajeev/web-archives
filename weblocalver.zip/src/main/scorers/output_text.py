"""Render an agent Observation.output to readable prose for LLM judges.

Agents may return a plain string or a structured bundle. The scoping agent
returns `{ <report>: { report_title, paragraphs: [{ content, ... }] } }`. Judges
must see the same *prose* the golden reference is written in — not a raw JSON
dump — otherwise they compare across formats and, worse, invent format
"instructions" (e.g. "output must be valid JSON") that were never requested and
reward the agent for them. This mirrors the frontend `reportBundleToProse` so
the human diff view and the judge see identical text.
"""

from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

_PARAGRAPHS = "paragraphs"
_UNREADABLE_DOC = "[binary document: text could not be extracted]"


def _paragraph_text(paras: list[Any]) -> str:
    """Join the non-blank paragraph texts (dicts use content/text/paragraph)."""
    parts = []
    for p in paras:
        if isinstance(p, dict):
            val = p.get("content", p.get("text", p.get("paragraph", "")))
        else:
            val = p
        if val is not None and str(val).strip():
            parts.append(str(val))
    return "\n\n".join(parts)


def _is_report(value: Any) -> bool:
    return isinstance(value, dict) and isinstance(value.get(_PARAGRAPHS), list)


def _report_bundle_to_prose(value: Any) -> str:
    """Return prose for a report bundle/single report, else '' to fall back."""
    if not isinstance(value, dict):
        return ""

    # Single report: { report_title, paragraphs: [...] }.
    if _is_report(value):
        body = _paragraph_text(value[_PARAGRAPHS])
        title = value.get("report_title") or ""
        return f"{title}\n\n{body}" if title else body

    # Bundle: { <key>: { report_title, paragraphs }, ... }.
    sections = [
        f"{rep.get('report_title') or key}\n\n{_paragraph_text(rep[_PARAGRAPHS])}"
        for key, rep in value.items()
        if _is_report(rep)
    ]
    return "\n\n\n".join(sections)


def _extract_bytes(raw: bytes) -> str:
    """Best-effort document text; a placeholder instead of raising."""
    from adapters.documents import extract_text

    try:
        return extract_text(raw, "auto")
    except Exception as exc:  # optional parsers missing or a corrupt document
        logger.warning("document text extraction failed: %s: %s", type(exc).__name__, exc)
        return _UNREADABLE_DOC


def render_output_text(value: Any) -> str:
    """Flatten any agent output to prose; JSON-serialise unrecognised shapes.

    The config-driven HTTP adapter pre-extracts document text (PDF/DOCX) and
    stores it as a string in ``observation.output``, so most calls receive text
    already. As a fallback for raw bytes (e.g. a Python adapter returning bytes),
    we attempt on-the-fly text extraction.
    """
    if value is None:
        return ""
    if isinstance(value, bytes | bytearray):
        return _extract_bytes(bytes(value))
    if isinstance(value, str):
        return value
    prose = _report_bundle_to_prose(value)
    if prose:
        return prose
    return json.dumps(value, ensure_ascii=False, default=str)
