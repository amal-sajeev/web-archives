"""Small helpers shared by the built-in scorers.

Kept dependency-free (only ``output_text``) so every scorer module can import it
without creating import cycles.
"""

from __future__ import annotations

import json
from typing import Any

from .base import MetricSkipped
from .output_text import render_output_text

TICK = "✓"
CROSS = "✗"
NO_GOLDEN = "no golden_output to compare"
INVALID_JSON = "output is not valid JSON"

# Type names accepted by the config shortcuts (field_match `type`, json_schema_valid `types`).
CONFIG_TYPE_MAP: dict[str, type | tuple[type, ...]] = {
    "str": str, "string": str,
    "int": int, "integer": int,
    "float": (int, float), "number": (int, float),
    "bool": bool, "boolean": bool,
    "list": list, "array": list,
    "dict": dict, "object": dict,
    "null": type(None), "none": type(None),
}

# JSON Schema `type` keyword values.
SCHEMA_TYPE_MAP: dict[str, type | tuple[type, ...]] = {
    "string": str, "integer": int, "number": (int, float),
    "boolean": bool, "array": list, "object": dict, "null": type(None),
}

_NUMERIC_NAMES = frozenset({"int", "integer", "float", "number"})


def mark(ok: bool) -> str:
    """Evidence prefix: a tick for a pass, a cross for a fail."""
    return TICK if ok else CROSS


def spec_config(spec: Any) -> dict[str, Any]:
    """The MetricSpec's `config` dict (empty when there is no spec/config)."""
    return (getattr(spec, "config", None) if spec else None) or {}


def config_int(cfg: dict[str, Any], key: str, default: int) -> int:
    """A whole-number config value; anything else is a config error (MetricSkipped)."""
    value = cfg.get(key, default)
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise MetricSkipped(f"config error: '{key}' must be a whole number, got {value!r}") from exc


def as_list(value: Any) -> list[Any]:
    """Wrap a scalar (notably a string) in a list; pass lists/tuples/sets through."""
    if value is None:
        return []
    if isinstance(value, list | tuple | set):
        return list(value)
    return [value]


def text_of(value: Any) -> str:
    """A string as-is, anything else JSON-encoded."""
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)


def output_text(observation: Any) -> str:
    """Text form of the observation output (prefers adapter-extracted text)."""
    meta = observation.metadata or {}
    if meta.get("extracted_text"):
        return meta["extracted_text"]
    return render_output_text(observation.output)


def matches_type(value: Any, type_name: str, type_map: dict[str, Any]) -> bool:
    """isinstance check by type name; bools never count as numbers.

    Unknown type names return False (the caller reports them).
    """
    name = str(type_name).lower()
    expected = type_map.get(name)
    if expected is None:
        return False
    if name in _NUMERIC_NAMES and isinstance(value, bool):
        return False
    return isinstance(value, expected)


def range_score(value: float, lo: float, hi: float) -> float:
    """1.0 inside [lo, hi] (hi <= 0 means unbounded), linear falloff outside."""
    if value < lo:
        return max(0.0, value / lo) if lo > 0 else 1.0
    if 0 < hi < value:
        return hi / value
    return 1.0


def range_label(lo: float, hi: float) -> str:
    """Inclusive range text, e.g. ``[2, 10]`` or ``[2, inf)``."""
    return f"[{lo}, {hi}]" if hi > 0 else f"[{lo}, ∞)"


def measurement(spec: Any, value: float) -> dict[str, float]:
    """Extras for a raw measurement (a count, a length...).

    The runner normalises ``extras["raw_value"]`` in place of the score, which is
    only right when the MetricSpec opts into normalisation (``lower_is_better``
    or explicit ``norm_min``/``norm_max``). Otherwise the value is reported as
    audit-only ``measured`` and the scorer's own [0, 1] score is used.
    """
    opted = spec is not None and (
        getattr(spec, "direction", None) == "lower_is_better"
        or getattr(spec, "norm_min", None) is not None
        or getattr(spec, "norm_max", None) is not None
    )
    return {"raw_value": float(value)} if opted else {"measured": float(value)}
