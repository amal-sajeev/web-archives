"""Text/regex scorers -- operate on extracted output text.

Scorers:
  - ``contains``       -- required terms must appear (with min_count).
  - ``not_empty``      -- output must be non-empty.
  - ``not_contains``   -- forbidden terms must not appear.
  - ``regex_match``    -- regex patterns must match.
  - ``length_range``   -- output length within min/max (words or chars).
  - ``keyword_count``  -- keyword occurrences (bounded score + raw count).
"""

from __future__ import annotations

import re
from typing import Any

from .base import MetricSkipped, scorer
from ._util import (
    as_list, config_int, mark, measurement, output_text, range_label, range_score, spec_config,
)

_REGEX_FLAGS = {"i": re.I, "m": re.M, "s": re.S, "x": re.X}
_NOT_EMPTY_OPS = ("not_empty", "non_empty", "nonempty")
_TERMS = "terms"
_CASE_SENSITIVE = "case_sensitive"
_MIN_COUNT = "min_count"


def _output_is_empty(observation) -> tuple[bool, list[str]]:
    """True when the agent produced no usable output."""
    out = observation.output
    if out is None:
        return True, ["output=None"]
    if isinstance(out, str):
        return not out.strip(), [f"chars={len(out.strip())}"]
    if isinstance(out, list | dict | tuple | set):
        return len(out) == 0, [f"len={len(out)}"]
    if isinstance(out, bytes | bytearray):
        return len(out) == 0, [f"bytes={len(out)}"]
    text = str(output_text(observation)).strip()
    return not text, [f"chars={len(text)}"]


def _not_empty_score(observation) -> tuple[float, str, list[str]]:
    empty, evidence = _output_is_empty(observation)
    if empty:
        return 0.0, "output is empty", evidence
    return 1.0, "output is non-empty", evidence


def _counts(text: str, terms: list[Any], case_sensitive: bool) -> list[tuple[str, int]]:
    """(term, occurrences) for each term; non-string terms are stringified."""
    haystack = text if case_sensitive else text.lower()
    out = []
    for term in terms:
        t = str(term)
        out.append((t, haystack.count(t if case_sensitive else t.lower())))
    return out


@scorer("not_empty")
def not_empty(*, observation, case, spec=None, **_):
    """1.0 when the agent output is non-empty (string/JSON/bytes)."""
    return _not_empty_score(observation)


@scorer("contains")
def contains(*, observation, case, spec=None, **_):
    """Required terms must appear in the output text.

    config:
      terms: [str, ...]          -- terms that must be present (a string is one term).
      substring: str             -- optional single-term alias for ``terms``.
      op: str                    -- "contains" (default) | "not_empty".
      case_sensitive: bool       -- default false.
      min_count: int             -- minimum occurrences per term (default 1).
    """
    cfg = spec_config(spec)
    if str(cfg.get("op") or "contains").lower() in _NOT_EMPTY_OPS:
        return _not_empty_score(observation)

    terms = as_list(cfg.get(_TERMS))
    substring = cfg.get("substring")
    if isinstance(substring, str) and substring:
        terms.append(substring)
    if not terms:
        return 1.0, "no terms configured", []
    min_count = config_int(cfg, _MIN_COUNT, 1)

    found, evidence = 0, []
    for term, count in _counts(output_text(observation), terms, bool(cfg.get(_CASE_SENSITIVE, False))):
        ok = count >= min_count
        found += int(ok)
        evidence.append(f"{mark(ok)} '{term}' x{count} (need {min_count})")
    return found / len(terms), f"{found}/{len(terms)} required terms present", evidence


@scorer("not_contains")
def not_contains(*, observation, case, spec=None, **_):
    """Forbidden terms must not appear in the output text.

    config:
      terms: [str, ...]          -- terms that must be absent (alias: forbidden).
      case_sensitive: bool       -- default false.
    """
    cfg = spec_config(spec)
    terms = as_list(cfg.get(_TERMS) or cfg.get("forbidden"))
    if not terms:
        return 1.0, "no forbidden terms configured", []
    absent, evidence = 0, []
    for term, count in _counts(output_text(observation), terms, bool(cfg.get(_CASE_SENSITIVE, False))):
        ok = count == 0
        absent += int(ok)
        evidence.append(f"{mark(ok)} '{term}' x{count} (need 0)")
    return absent / len(terms), f"{absent}/{len(terms)} forbidden terms absent", evidence


def _compile(entry: dict[str, Any]) -> re.Pattern[str]:
    """Compile one configured pattern; config errors become MetricSkipped."""
    pat = str(entry.get("pattern", ""))
    flag_str = str(entry.get("flags", "") or "")
    unknown = sorted(set(flag_str) - set(_REGEX_FLAGS))
    if unknown:
        raise MetricSkipped(f"invalid regex flags {unknown} for /{pat}/ (allowed: i, m, s, x)")
    flags = 0
    for ch in flag_str:
        flags |= _REGEX_FLAGS[ch]
    try:
        return re.compile(pat, flags)
    except re.error as exc:
        raise MetricSkipped(f"invalid regex /{pat}/: {exc}") from exc


@scorer("regex_match")
def regex_match(*, observation, case, spec=None, **_):
    """Regex patterns must match the output text.

    config:
      patterns: [{pattern: str, required: bool, flags: str}, ...]
        - required (default true): if false, the pattern is informational only.
        - flags: any combination of 'i','m','s','x' (regex flags).

    An invalid pattern or flag is a config error: the metric is skipped with an
    "invalid regex" reason before anything is matched.
    """
    entries = [e if isinstance(e, dict) else {"pattern": e} for e in spec_config(spec).get("patterns", []) or []]
    if not entries:
        return 1.0, "no patterns configured", []
    compiled = [(e, _compile(e)) for e in entries]
    text = output_text(observation)
    required_total, matched, evidence = 0, 0, []
    for entry, rx in compiled:
        hit = bool(rx.search(text))
        if entry.get("required", True):
            required_total += 1
            matched += int(hit)
            evidence.append(f"{mark(hit)} /{rx.pattern}/")
        else:
            evidence.append(f"  /{rx.pattern}/ -> {'hit' if hit else 'miss'} (optional)")
    if not required_total:
        return 1.0, f"no required patterns ({len(compiled)} optional checked)", evidence
    return matched / required_total, f"{matched}/{required_total} required patterns matched", evidence


@scorer("length_range")
def length_range(*, observation, case, spec=None, **_):
    """Output length (words or chars) within [min, max] (inclusive).

    config:
      min: int (default 0)
      max: int (default 0 = unlimited)
      unit: "words" | "chars" (default "words")

    Returns a 0..1 score: 1.0 inside the range, linearly decreasing outside.
    The length is reported via ``_util.measurement``: as ``raw_value`` (which the
    runner normalises instead of the score) only when the MetricSpec sets
    ``direction: lower_is_better`` or norm bounds, else as audit-only ``measured``.
    """
    cfg = spec_config(spec)
    lo = config_int(cfg, "min", 0)
    hi = config_int(cfg, "max", 0)
    unit = cfg.get("unit", "words")
    text = output_text(observation)
    length = len(text.split()) if unit == "words" else len(text)
    rationale = f"{unit}={length} vs range {range_label(lo, hi)}"
    return range_score(length, lo, hi), rationale, [f"length={length} {unit}"], measurement(spec, length)


@scorer("keyword_count")
def keyword_count(*, observation, case, spec=None, **_):
    """Count keyword occurrences in the output.

    config:
      terms: [str, ...]     -- keywords to count (a string is one keyword).
      case_sensitive: bool  -- default false.
      min_count: int        -- total hits for a full score (default 1).

    Score is ``min(total / min_count, 1)`` (bounded to [0, 1]). The total count
    is ``extras.raw_value`` when the MetricSpec sets ``direction``/``norm_min``/
    ``norm_max`` (the runner then normalises the count), else ``measured``.
    """
    cfg = spec_config(spec)
    terms = as_list(cfg.get(_TERMS))
    if not terms:
        raise MetricSkipped("keyword_count requires config.terms")
    min_count = max(config_int(cfg, _MIN_COUNT, 1), 0)
    counts = _counts(output_text(observation), terms, bool(cfg.get(_CASE_SENSITIVE, False)))
    total = sum(c for _t, c in counts)
    score = min(total / min_count, 1.0) if min_count else 1.0
    evidence = [f"'{t}': {c}" for t, c in counts]
    return score, f"total keyword hits={total} (need {min_count})", evidence, measurement(spec, total)
