"""Document-structure scorers.

Scorers:
  - ``section_present`` -- required section headings must appear.
  - ``heading_count``   -- number of headings within [min, max].
"""

from __future__ import annotations

from adapters.documents import parse_headings

from .base import scorer
from ._util import config_int, mark, measurement, output_text, range_label, range_score, spec_config


def _heading_keys(observation) -> set[str]:
    """Lower-cased heading texts (Markdown ``#`` headings or title-like lines)."""
    meta = observation.metadata or {}
    return {h.lower() for h in parse_headings(output_text(observation), meta.get("content_type", "auto"))}


@scorer("section_present")
def section_present(*, observation, case, spec=None, **_):
    """Required section headings must appear in the document.

    config:
      sections: [str, ...]   -- heading substrings that must be present.

    Works on Markdown (# headings), extracted PDF/DOCX text, and plain text.
    """
    sections = [str(s) for s in spec_config(spec).get("sections", []) or []]
    if not sections:
        return 1.0, "no sections configured", []

    found_keys = _heading_keys(observation)
    found, evidence = 0, []
    for s in sections:
        hit = any(s.lower() in k for k in found_keys)
        found += int(hit)
        evidence.append(f"{mark(hit)} section '{s}'")
    return found / len(sections), f"{found}/{len(sections)} required sections present", evidence


@scorer("heading_count")
def heading_count(*, observation, case, spec=None, **_):
    """Number of headings within [min, max] (inclusive).

    config:
      min: int (default 0)
      max: int (default 0 = unlimited)

    The count is reported via ``_util.measurement`` (``raw_value`` only when the
    MetricSpec opts into normalisation, else audit-only ``measured``).
    """
    cfg = spec_config(spec)
    lo = config_int(cfg, "min", 0)
    hi = config_int(cfg, "max", 0)
    meta = observation.metadata or {}
    count = len(parse_headings(output_text(observation), meta.get("content_type", "auto")))
    score = range_score(count, lo, hi)
    rationale = f"headings={count} vs range {range_label(lo, hi)}"
    return score, rationale, [f"count={count}"], measurement(spec, count)
