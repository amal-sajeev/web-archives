"""Judge invocation plumbing: response cache, timeout, retry and sampling.

* **Cache**: identical ``(model, prompt, sample index)`` invocations are memoised
  in a bounded LRU (``_CACHE_MAXSIZE`` entries), so repeated samples / re-runs
  don't re-bill Vertex and memory stays bounded in a long-lived process.
  ``reset_cache()`` clears it only when explicitly called (tests, admin); runs
  never need to clear it, and doing so mid-run merely costs extra judge calls.
* **Timeout**: each call is bounded by ``Config.JUDGE_CALL_TIMEOUT`` seconds.
* **Retry**: transient failures (connection drops, timeouts, 429/5xx) are
  retried here and only here (the Vertex client is built with
  ``max_retries=0``), with exponential backoff from ``_BACKOFF_BASE_S`` capped
  at ``_BACKOFF_MAX_S``.
* **Sampling**: ``_run_samples`` draws N samples, returns the mean, and records
  variance / instability / position bias in extras.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from collections import OrderedDict
from collections.abc import Callable
from statistics import pvariance
from typing import Any

from core.config import Config
from service.http_errors import describe_http_error
from .base import MetricSkipped

logger = logging.getLogger(__name__)

_CACHE_MAXSIZE = 512
_MAX_SAMPLES = 5
_BACKOFF_BASE_S = 0.5
_BACKOFF_MAX_S = 4.0
_RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504})
# How the judge is named in plain-language skip reasons.
_JUDGE_SERVICE = "the AI assessment service"
_DISCONNECT_MARKERS = ("disconnected without sending a response", "server disconnected")

_CACHE: OrderedDict[tuple[str, str, int], object] = OrderedDict()
_CACHE_LOCK = threading.Lock()


def reset_cache() -> None:
    """Clear the judge response cache (explicit request only; see module doc)."""
    with _CACHE_LOCK:
        _CACHE.clear()


def _cache_get(key: tuple[str, str, int]) -> object | None:
    with _CACHE_LOCK:
        value = _CACHE.get(key)
        if value is not None:
            _CACHE.move_to_end(key)
        return value


def _cache_put(key: tuple[str, str, int], value: object) -> object:
    with _CACHE_LOCK:
        existing = _CACHE.get(key)
        if existing is not None:
            _CACHE.move_to_end(key)
            return existing
        _CACHE[key] = value
        while len(_CACHE) > _CACHE_MAXSIZE:
            _CACHE.popitem(last=False)
        return value


def judge_or_skip(factory: Callable[..., Any], *args: Any) -> Any:
    """Build a judge via `factory`; a RuntimeError (no Vertex/ADC) skips the metric."""
    try:
        return factory(*args)
    except RuntimeError as exc:
        raise MetricSkipped(f"LLM judge unavailable: {exc}") from exc


def _samples(judge_repetitions: int) -> int:
    n = judge_repetitions if judge_repetitions and judge_repetitions > 1 else Config.JUDGE_SAMPLES
    return max(1, min(int(n), _MAX_SAMPLES))


def _invoke_with_timeout(judge: Any, prompt: str) -> Any:
    timeout = max(0.0, float(Config.JUDGE_CALL_TIMEOUT))
    if timeout <= 0:
        return judge.invoke(prompt)

    result_queue: queue.Queue = queue.Queue(maxsize=1)

    def _target() -> None:
        try:
            result_queue.put((True, judge.invoke(prompt)))
        except Exception as exc:  # handed back to the caller and re-raised there
            result_queue.put((False, exc))

    thread = threading.Thread(target=_target, daemon=True)
    thread.start()
    try:
        ok, value = result_queue.get(timeout=timeout)
    except queue.Empty as exc:
        raise TimeoutError(f"judge invoke timed out after {timeout:.1f}s") from exc
    if ok:
        return value
    raise value


def _transient_types() -> tuple[type[BaseException], ...]:
    import httpx

    return (
        httpx.RemoteProtocolError, httpx.ConnectError, httpx.ReadError, httpx.WriteError,
        httpx.ConnectTimeout, httpx.ReadTimeout, httpx.PoolTimeout, TimeoutError,
    )


def _is_transient(exc: BaseException) -> bool:
    if isinstance(exc, _transient_types()):
        return True
    status = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    if isinstance(status, int) and status in _RETRYABLE_STATUS:
        return True
    msg = str(exc).lower()
    return any(marker in msg for marker in _DISCONNECT_MARKERS)


def _backoff_delay(attempt: int) -> float:
    return min(_BACKOFF_BASE_S * (2 ** attempt), _BACKOFF_MAX_S)


def _invoke_with_retry(judge: Any, prompt: str) -> Any:
    attempts = max(1, int(Config.JUDGE_TRANSIENT_RETRIES))
    for attempt in range(attempts - 1):
        try:
            return _invoke_with_timeout(judge, prompt)
        except Exception as exc:
            if not _is_transient(exc):
                raise
            logger.warning(
                "transient judge failure (attempt %d/%d): %s: %s",
                attempt + 1, attempts, type(exc).__name__, exc,
            )
            time.sleep(_backoff_delay(attempt))
    return _invoke_with_timeout(judge, prompt)  # last attempt: failures propagate


def _invoke_cached(judge: Any, prompt: str, idx: int = 0) -> Any:
    key = (str(Config.JUDGE_MODEL), prompt, idx)
    cached = _cache_get(key)
    if cached is not None:
        return cached
    verdict = _invoke_with_retry(judge, prompt)
    if verdict is None:
        # Structured-output parsing failed; never cache it.
        raise MetricSkipped("LLM judge returned no structured result")
    return _cache_put(key, verdict)


def _invoke_metric(judge: Any, prompt: str, idx: int = 0) -> Any:
    """Invoke the judge; any failure becomes MetricSkipped (never a fake score)."""
    try:
        return _invoke_cached(judge, prompt, idx)
    except MetricSkipped:
        raise
    except Exception as exc:
        raise MetricSkipped(f"LLM judge invocation failed: {describe_http_error(exc, _JUDGE_SERVICE)}") from exc


def sample_extras(values: list[float]) -> dict[str, Any]:
    """Variance of repeated samples, flagged unstable above JUDGE_MAX_VARIANCE."""
    var = pvariance(values) if len(values) > 1 else 0.0
    extras: dict[str, Any] = {"variance": var}
    if var > Config.JUDGE_MAX_VARIANCE:
        extras["unstable"] = True
    return extras


def _position_bias(scores: list[float], swapped: list[bool]) -> float | None:
    normal = [s for s, sw in zip(scores, swapped, strict=True) if not sw]
    flipped = [s for s, sw in zip(scores, swapped, strict=True) if sw]
    if not normal or not flipped:
        return None
    return abs(sum(normal) / len(normal) - sum(flipped) / len(flipped))


def _run_samples(
    judge: Any,
    render: Callable[[bool], str],
    n: int,
    *,
    swap_capable: bool = False,
    adjust: Callable[[float, bool], float] | None = None,
) -> tuple[float, str, list[str], dict[str, Any]]:
    """Draw `n` judge samples of ``render(swap)`` and summarise them.

    With ``swap_capable`` and ``Config.JUDGE_SWAP_ORDER`` odd samples render the
    swapped presentation order; ``adjust(score, swapped)`` maps a raw verdict
    score back to the agent's perspective (e.g. ``1 - p`` for pairwise).
    """
    scores: list[float] = []
    swapped: list[bool] = []
    last = None
    for i in range(n):
        swap = bool(swap_capable and Config.JUDGE_SWAP_ORDER and i % 2 == 1)
        verdict = _invoke_metric(judge, render(swap), i)
        raw = float(verdict.score)
        scores.append(adjust(raw, swap) if adjust else raw)
        swapped.append(swap)
        last = verdict
    avg = sum(scores) / len(scores)
    extras = sample_extras(scores)
    evidence = list(getattr(last, "evidence", []) or [])
    if len(scores) > 1:
        evidence.append(f"samples={scores} mean={avg:.3f} var={extras['variance']:.4f}")
    bias = _position_bias(scores, swapped)
    if bias is not None:
        extras["position_bias"] = bias
    return avg, getattr(last, "rationale", "") or "", evidence, extras
