"""Vertex AI judge model factory.

Reuses the single Vertex pattern from docs/VERTEX_INTEGRATION.md:
`ChatGoogleGenerativeAI(project=...)` selects Vertex; auth is ADC/WIF, no API
key. A fail-fast guard runs before the client is built to avoid the misleading
`'BaseApiClient' object has no attribute '_async_httpx_client'` error.

`google.auth` and `langchain_google_genai` are imported lazily so importing the
scorer package stays cheap and works where the Google SDKs are not installed.
Retries happen in one layer only (`judge_invoke`), so the client is built with
``max_retries=0``.
"""

from __future__ import annotations

import threading
import time

from pydantic import BaseModel, Field

from core.config import Config

# Resolved ADC credentials are re-used for this long before re-resolving, so a
# rotated or revoked credential is noticed without resolving on every call.
_CREDENTIALS_TTL_S = 300.0
_CREDS_LOCK = threading.Lock()
_CREDS_CACHE: dict[str, tuple[float, str]] = {}


class JudgeVerdict(BaseModel):
    """Typed judge output. `passed` is re-applied in code, never trusted here."""
    score: float = Field(ge=0.0, le=1.0)
    passed: bool = False
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)


class PairwiseVerdict(BaseModel):
    """Typed A/B comparison output. `winner` is 'A', 'B', or 'tie'.

    `score` is the preference strength for candidate A: 1.0 = A clearly
    better, 0.5 = tie, 0.0 = B clearly better.
    """
    winner: str = Field(default="tie", description="'A' | 'B' | 'tie'")
    score: float = Field(default=0.5, ge=0.0, le=1.0)
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)


class RubricCriterionScore(BaseModel):
    """One criterion's score in a multi-criteria rubric verdict."""
    criterion: str
    score: float = Field(ge=0.0, le=1.0)
    rationale: str = ""


class MultiRubricVerdict(BaseModel):
    """Typed multi-criteria judge output. Each criterion gets its own score."""
    scores: list[RubricCriterionScore] = Field(default_factory=list)
    overall_rationale: str = ""


def _resolve_credentials() -> str:
    try:
        import google.auth

        creds, _ = google.auth.default()
    except Exception as exc:
        raise RuntimeError(
            "No Application Default Credentials available for Vertex AI. "
            "Locally, run: gcloud auth application-default login. "
            "In GKE, check the Workload Identity Federation credential config is "
            f"mounted and GOOGLE_APPLICATION_CREDENTIALS points at it. ({exc})"
        ) from exc
    return type(creds).__name__


def require_vertex_credentials() -> str:
    """Guard + return the resolved ADC credential class name (for /api/health).

    The resolution is cached for ``_CREDENTIALS_TTL_S`` seconds; failures are
    never cached, so fixing credentials takes effect on the next call.
    """
    if not Config.PROJECT_NAME:
        raise RuntimeError(
            "PROJECT_NAME is not set; the evaluation judge requires Vertex AI. "
            "Set PROJECT_NAME (environment or config file) to your Google Cloud project id."
        )
    now = time.monotonic()
    with _CREDS_LOCK:
        cached = _CREDS_CACHE.get(Config.PROJECT_NAME)
        if cached and now - cached[0] < _CREDENTIALS_TTL_S:
            return cached[1]
    name = _resolve_credentials()
    with _CREDS_LOCK:
        _CREDS_CACHE[Config.PROJECT_NAME] = (now, name)
    return name


def reset_credentials_cache() -> None:
    """Forget cached ADC resolutions (tests / credential rotation)."""
    with _CREDS_LOCK:
        _CREDS_CACHE.clear()


def build_judge():
    """Return a ChatGoogleGenerativeAI bound to structured JudgeVerdict output."""
    return build_judge_for(JudgeVerdict)


# Judge clients are expensive to construct (ADC resolution + client wiring) and
# are safe to share across threads. Under the runner's concurrent per-metric
# dispatch many scorers request a client for the same schema at once, so memoise
# one client per structured-output schema behind a lock.
_JUDGE_CACHE: dict[object, object] = {}
_JUDGE_CACHE_LOCK = threading.Lock()


def _new_client():
    from langchain_google_genai import ChatGoogleGenerativeAI

    timeout = float(Config.JUDGE_CALL_TIMEOUT or 0)
    return ChatGoogleGenerativeAI(
        model=Config.JUDGE_MODEL,
        project=Config.PROJECT_NAME,       # project= is the switch -> Vertex
        location=Config.PROJECT_LOCATION,
        temperature=Config.JUDGE_TEMPERATURE,
        max_retries=0,                     # retries live in judge_invoke only
        timeout=timeout if timeout > 0 else None,
    )


def build_judge_for(schema):
    """Return a Vertex judge bound to an arbitrary structured-output schema."""
    require_vertex_credentials()
    with _JUDGE_CACHE_LOCK:
        client = _JUDGE_CACHE.get(schema)
        if client is None:
            client = _new_client().with_structured_output(schema)
            _JUDGE_CACHE[schema] = client
        return client


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed texts through Vertex (same ADC path as the judge).

    Raises RuntimeError when credentials/model are unavailable so callers can
    convert it to a MetricSkipped and keep offline runs green.
    """
    require_vertex_credentials()
    try:
        from langchain_google_genai import GoogleGenerativeAIEmbeddings

        embedder = GoogleGenerativeAIEmbeddings(
            model=Config.EMBEDDING_MODEL,
            project=Config.PROJECT_NAME,
            location=Config.PROJECT_LOCATION,
        )
        return embedder.embed_documents(texts)
    except Exception as exc:
        raise RuntimeError(f"embedding model unavailable: {exc}") from exc
