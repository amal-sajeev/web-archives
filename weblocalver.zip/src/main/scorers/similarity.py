"""Reference-based scorers: compare the agent output to the golden output.

These catch paraphrase and structural correctness that verbatim substring
checks miss:

- token_overlap_f1     -- multiset (bag-of-tokens) F1 against the golden output;
                          tokens are Unicode word characters, case-folded.
- edit_similarity      -- difflib ``SequenceMatcher`` similarity ratio
                          (2*matches / total length), robust on long texts where
                          a quadratic Levenshtein would stall the worker.
- embedding_similarity -- cosine similarity of Vertex embeddings (skips cleanly
                          when no ADC credentials are present).

JSON checks live in ``configurable_json`` (``json_schema_valid``, ``field_match``).
A case without a golden_output skips these metrics (MetricSkipped).

Scorers return (score, rationale, evidence[, extras]).
"""

from __future__ import annotations

import re
from collections import Counter
from difflib import SequenceMatcher

from .base import MetricSkipped, scorer
from ._util import NO_GOLDEN, text_of
from .output_text import render_output_text
from .vertex import embed_texts

_TOKEN = re.compile(r"\w+")
_EMBED_UNAVAILABLE = "embeddings unavailable"


def _tokens(text: str) -> list[str]:
    return _TOKEN.findall(text.casefold())


def _golden_text(case) -> str:
    if not case.golden_output:
        raise MetricSkipped(NO_GOLDEN)
    return text_of(case.golden_output)


def _cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity clamped to [0, 1]; a zero vector scores 0."""
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    cos = dot / (na * nb) if na and nb else 0.0
    return max(0.0, min(1.0, cos))


@scorer("token_overlap_f1")
def token_overlap_f1(*, observation, case, **_):
    """Bag-of-tokens (multiset) F1 between output and golden_output."""
    golden = _golden_text(case)
    out_tokens = _tokens(render_output_text(observation.output))
    gold_tokens = _tokens(golden)
    if not out_tokens or not gold_tokens:
        return 0.0, "empty output or golden", []

    overlap = sum((Counter(out_tokens) & Counter(gold_tokens)).values())
    if not overlap:
        return 0.0, "no token overlap with golden", []
    precision = overlap / len(out_tokens)
    recall = overlap / len(gold_tokens)
    f1 = 2 * precision * recall / (precision + recall)
    return f1, f"token F1={f1:.3f} (P={precision:.2f} R={recall:.2f})", [f"overlap={overlap}"]


@scorer("edit_similarity")
def edit_similarity(*, observation, case, **_):
    """difflib similarity ratio (0..1) between output and golden_output."""
    golden = _golden_text(case)
    out = render_output_text(observation.output)
    sim = SequenceMatcher(None, out, golden).ratio()
    return sim, f"edit similarity={sim:.3f}", [f"len_output={len(out)} len_golden={len(golden)}"]


@scorer("embedding_similarity")
def embedding_similarity(*, observation, case, **_):
    """Cosine similarity of Vertex embeddings of output vs golden_output.

    Skips (rather than fails) when embeddings are unavailable offline.
    """
    golden = _golden_text(case)
    candidate = render_output_text(observation.output)
    if not candidate.strip():
        return 0.0, "empty output to compare", []
    try:
        vecs = embed_texts([candidate, golden])
    except RuntimeError as exc:
        raise MetricSkipped(f"{_EMBED_UNAVAILABLE}: {exc}") from exc

    if len(vecs or []) < 2:
        raise MetricSkipped(f"{_EMBED_UNAVAILABLE}: fewer than two vectors returned")
    a, b = vecs[0], vecs[1]
    if len(a) != len(b):
        # zip() would silently truncate and report a meaningless cosine.
        raise MetricSkipped(f"{_EMBED_UNAVAILABLE}: vector sizes differ ({len(a)} vs {len(b)})")
    cos = _cosine(a, b)
    return cos, f"embedding cosine={cos:.3f}", []
