"""Scorer registry + built-in scorers.

A scorer is `(observation, case, metrics_by_case) -> ScorerResult` registered by
name (see ``base`` for the full contract). Agents can add bespoke scorers via
`@scorer("name")` in their `custom_tests.py`, which the registry imports at
startup; LLM-judge scorers pass `judge=True` (see ``is_judge_scorer``).

Config-driven scorers (parameterised via `MetricSpec.config`) are split across:
  - `configurable_text.py`: text/regex scorers (contains, regex_match, etc.)
  - `configurable_json.py`: JSON structure validators (json_path, field_match, etc.)
  - `document_structure.py` / `document_tables.py`: document checks.
  - `rubric.py`: config-defined LLM rubric judges.
(`configurable_advanced.py` re-exports the last three for older imports.)
"""

from .base import MetricSkipped, all_scorers, get_scorer, is_judge_scorer, scorer
from . import deterministic          # registers built-ins
from . import similarity             # reference-based
from . import trajectory             # agent trajectory
from . import safety                 # safety & compliance
from . import operational            # SLOs
from . import llm_judge              # judge + rubric dimensions
from . import configurable_text      # text/regex scorers
from . import configurable_json      # JSON scorers
from . import configurable_advanced  # document + LLM rubric scorers

__all__ = [
    "MetricSkipped",
    "all_scorers",
    "configurable_advanced",
    "configurable_json",
    "configurable_text",
    "deterministic",
    "get_scorer",
    "is_judge_scorer",
    "llm_judge",
    "operational",
    "safety",
    "scorer",
    "similarity",
    "trajectory",
]
