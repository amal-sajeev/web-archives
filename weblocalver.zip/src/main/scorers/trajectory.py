"""Trajectory scorers: judge *how* the agent reached its answer, not just the
final text. These use the tool trace on the Observation plus the CTA_ACTION-
derived tool_* metrics.

- tool_order_correct   -- expected tools called in the expected relative order.
- no_redundant_calls   -- penalise duplicate/repeated identical tool calls.
- tool_arg_accuracy    -- expected args present per tool.
- tool_error_free      -- no tool errors (from CTA_ACTION tool_error_count).
- step_efficiency      -- steps taken vs an expected optimal count.

Scorers return (score, rationale, evidence[, extras]).
"""

from __future__ import annotations

import json
import math

from .base import MetricSkipped, scorer
from ._util import as_list, mark, measurement

_EXPECTED_TOOL = "expected_tool"


def _tool_name(tc: dict) -> str:
    return tc.get("name") or tc.get("Tool_Id") or ""


def _tool_names(observation) -> list[str]:
    return [_tool_name(tc) for tc in observation.tool_calls]


def _args_blob(tc: dict) -> str:
    return json.dumps(tc.get("args") or tc.get("Tool_Param") or {}, ensure_ascii=False, default=str).lower()


@scorer("tool_order_correct")
def tool_order_correct(*, observation, case, **_):
    """Were the expected tools invoked in the expected relative order?

    case.expected.expected_tool_sequence = ["tool_a", "tool_b", ...]
    Falls back to expected_tool (single) when a sequence is not provided.
    """
    expected = as_list(case.expected.get("expected_tool_sequence") or case.expected.get(_EXPECTED_TOOL))
    if not expected:
        return 1.0, "no expected tool sequence defined", []

    called = _tool_names(observation)
    # Greedy in-order match: how many expected tools appear in order.
    i = 0
    for name in called:
        if i < len(expected) and name == expected[i]:
            i += 1
    return i / len(expected), f"{i}/{len(expected)} expected tools in order", [f"called={called}"]


@scorer("no_redundant_calls")
def no_redundant_calls(*, observation, case, **_):
    """1.0 when there are no duplicate identical (tool, args) invocations."""
    calls = observation.tool_calls
    if not calls:
        return 1.0, "no tool calls", []
    seen: set[tuple[str, str]] = set()
    duplicates = 0
    for tc in calls:
        key = (_tool_name(tc), _args_blob(tc))
        duplicates += int(key in seen)
        seen.add(key)
    return 1.0 - duplicates / len(calls), f"{duplicates} redundant call(s) of {len(calls)}", [f"unique={len(seen)}"]


def _expected_tool_args(expected: dict) -> dict[str, list]:
    spec_args = expected.get("expected_tool_args")
    if isinstance(spec_args, dict) and spec_args:
        return {tool: as_list(values) for tool, values in spec_args.items()}
    if expected.get(_EXPECTED_TOOL):
        return {expected[_EXPECTED_TOOL]: as_list(expected.get("expected_values"))}
    return {}


@scorer("tool_arg_accuracy")
def tool_arg_accuracy(*, observation, case, **_):
    """Fraction of expected (tool -> values) that appear in that tool's args.

    case.expected.expected_tool_args = {"tool_name": ["value1", "value2"]}
    (a single string value counts as one value). Falls back to
    expected_tool + expected_values.
    """
    spec_args = _expected_tool_args(case.expected)
    checks: list[bool] = []
    evidence: list[str] = []
    for tool_name, values in spec_args.items():
        joined = " ".join(_args_blob(tc) for tc in observation.tool_calls if _tool_name(tc) == tool_name)
        for value in values:
            hit = str(value).lower() in joined
            checks.append(hit)
            evidence.append(f"{mark(hit)} {tool_name}:{value}")
    if not checks:
        return 1.0, "no expected tool args defined", []
    return sum(checks) / len(checks), f"{sum(checks)}/{len(checks)} tool-arg checks passed", evidence


@scorer("tool_error_free")
def tool_error_free(*, observation, case, metrics=None, spec=None, **_):
    """1.0 when no tool errors were recorded (CTA_ACTION tool_error_count)."""
    errors = (metrics or {}).get("tool_error_count")
    if errors is None:
        # Fall back to the observation-level error flag.
        errors = 1 if observation.error else 0
    try:
        count = float(errors)
    except (TypeError, ValueError) as exc:
        raise MetricSkipped(f"tool_error_count not numeric: {errors!r}") from exc
    if math.isnan(count):
        raise MetricSkipped("tool_error_count is NaN")
    return float(count == 0), f"tool_error_count={count:g}", [], measurement(spec, count)


@scorer("step_efficiency")
def step_efficiency(*, observation, case, spec=None, **_):
    """Steps taken vs expected optimal; more steps than optimal lowers the score.

    case.expected.optimal_steps sets the target; defaults to the number of
    expected tools (or 1). ``optimal_steps: 0`` means no tool call is expected:
    no calls scores 1.0, any call scores 0.0.
    """
    optimal = case.expected.get("optimal_steps")
    if optimal is None:
        seq = as_list(case.expected.get("expected_tool_sequence"))
        optimal = len(seq) if seq else 1
    try:
        optimal = max(int(optimal), 0)
    except (TypeError, ValueError) as exc:
        raise MetricSkipped(f"optimal_steps must be a whole number, got {optimal!r}") from exc
    taken = len(observation.tool_calls)
    score = min(1.0, optimal / taken) if taken else 1.0
    return score, f"{taken} steps taken vs {optimal} optimal", [], measurement(spec, taken)
