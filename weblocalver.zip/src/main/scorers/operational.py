"""Operational SLO scorers -- gate on latency, cost, and reliability using the
CTA_ACTION-derived metrics. These are typically `lower_is_better` and use the
MetricSpec norm_min/norm_max bounds to normalise into a 0..1 quality score.

- latency_slo         -- execution_latency_ms (lower better).
- token_cost_budget   -- token_total_count (lower better).
- response_success    -- response_code in 2xx and no observation error (1.0/0.0).
- tool_latency_slo    -- tool_latency_total (lower better).

The SLO scorers return (raw, rationale, evidence, {raw_value: raw}); the runner
normalises ``raw_value``. When a measurement is unavailable the metric is
skipped (MetricSkipped) rather than scored as 0 ms / 0 tokens.
"""

from __future__ import annotations

import math
from typing import Any

from .base import MetricSkipped, scorer


def _raw(metrics: dict | None, name: str) -> float | None:
    """Finite float for `name` in the metrics map, else None."""
    value = (metrics or {}).get(name)
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _usage_total(usage: dict[str, Any] | None) -> float | None:
    usage = usage or {}
    if usage.get("total_tokens") is not None:
        return _raw(usage, "total_tokens")
    parts = [_raw(usage, k) for k in ("input_tokens", "output_tokens")]
    known = [p for p in parts if p is not None]
    return sum(known) if known else None


def _slo(name: str, value: float | None, source: str):
    if value is None:
        raise MetricSkipped(f"{name} unavailable ({source})")
    return value, f"{name}={value:.0f}", [], {"raw_value": value}


@scorer("latency_slo")
def latency_slo(*, observation, case, metrics=None, **_):
    """Execution latency (ms). Normalisation handled by the runner via spec bounds."""
    ms = _raw(metrics, "execution_latency_ms")
    if ms is None and observation.latency_ms:
        ms = float(observation.latency_ms)
    return _slo("execution_latency_ms", ms, "no metric and no observed latency")


@scorer("token_cost_budget")
def token_cost_budget(*, observation, case, metrics=None, **_):
    """Total tokens consumed (proxy for cost). Lower is better."""
    total = _raw(metrics, "token_total_count")
    if total is None:
        total = _usage_total(observation.usage)
    return _slo("token_total_count", total, "no metric and no usage totals")


@scorer("response_success")
def response_success(*, observation, case, metrics=None, **_):
    """1.0 when the response indicates success and the observation has no error.

    Prefers CTA ``response_code`` when present. Without one, an error-free
    observation counts as success. No response code is invented; a real code
    is reported as ``extras.response_code`` (never ``raw_value``, which the
    runner would normalise in place of the verdict).
    """
    code = _raw(metrics, "response_code")
    # Audit-only: a status code must never be fed to the normaliser as raw_value.
    extras = {"response_code": code} if code is not None else {}
    shown = f"{code:.0f}" if code is not None else "n/a"
    if observation.error:
        return 0.0, f"response_code={shown} error={observation.error}", [], extras
    if code is None:
        return 1.0, "no response_code; observation has no error", [], extras
    ok = 200 <= code < 300
    return float(ok), f"response_code={shown} error=False", [], extras


@scorer("tool_latency_slo")
def tool_latency_slo(*, observation, case, metrics=None, **_):
    """Total tool latency (ms). Lower is better."""
    return _slo("tool_latency_total", _raw(metrics, "tool_latency_total"), "no metric")
