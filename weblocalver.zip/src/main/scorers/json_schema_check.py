"""Minimal JSON Schema (draft-07 subset) checker used by ``json_schema_valid``.

Supported keywords: ``type`` (string or list), ``properties``, ``required``,
``additionalProperties`` (false or a schema), ``items`` (single schema),
``enum``, ``const``, ``minimum``, ``maximum``, ``minLength``, ``maxLength``,
``pattern``, ``minItems``, ``maxItems``. Annotation keywords (``title``,
``description``...) are ignored. Any other keyword is reported as a violation
("unsupported schema keyword") rather than silently passing.
"""

from __future__ import annotations

import operator
import re
from collections.abc import Callable
from typing import Any

from ._util import SCHEMA_TYPE_MAP, matches_type

_ANNOTATIONS = frozenset({
    "title", "description", "default", "examples", "$schema", "$id", "$comment", "format",
})
_STRUCTURAL = frozenset({"type", "properties", "required", "additionalProperties", "items"})
_PATTERN = "pattern"
_ENUM = "enum"
_CONST = "const"


def _is_number(value: Any) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _identity(value: Any) -> Any:
    return value


# keyword -> (applies to value?, measured quantity, violated(measured, limit), symbol)
_LIMITS: dict[str, tuple[Callable[[Any], bool], Callable[[Any], Any], Callable[[Any, Any], bool], str]] = {
    "minimum": (_is_number, _identity, operator.lt, "<"),
    "maximum": (_is_number, _identity, operator.gt, ">"),
    "minLength": (lambda v: isinstance(v, str), len, operator.lt, "<"),
    "maxLength": (lambda v: isinstance(v, str), len, operator.gt, ">"),
    "minItems": (lambda v: isinstance(v, list), len, operator.lt, "<"),
    "maxItems": (lambda v: isinstance(v, list), len, operator.gt, ">"),
}
_KNOWN = _STRUCTURAL | _ANNOTATIONS | frozenset(_LIMITS) | {_PATTERN, _ENUM, _CONST}


def _where(path: str) -> str:
    return path or "root"


def _type_ok(value: Any, stype: Any) -> tuple[bool, list[str]]:
    names = [str(t) for t in (stype if isinstance(stype, list) else [stype])]
    unknown = [n for n in names if n not in SCHEMA_TYPE_MAP]
    ok = any(matches_type(value, n, SCHEMA_TYPE_MAP) for n in names if n not in unknown)
    return ok, unknown


def _check_type(value: Any, stype: Any, path: str, errors: list[str]) -> bool:
    """False (with an error recorded) when `value` fails the `type` keyword."""
    if not stype:
        return True
    ok, unknown = _type_ok(value, stype)
    if unknown:
        errors.append(f"{_where(path)}: unsupported schema type {unknown}")
    if not ok:
        errors.append(f"{_where(path)}: expected {stype}, got {type(value).__name__}")
    return ok


def _check_limits(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    for key, (applies, measure, violated, symbol) in _LIMITS.items():
        if key in schema and applies(value) and violated(measure(value), schema[key]):
            errors.append(f"{_where(path)}: {measure(value)} {symbol} {key} {schema[key]}")


def _check_pattern(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    if _PATTERN not in schema or not isinstance(value, str):
        return
    pattern = str(schema[_PATTERN])
    try:
        if not re.search(pattern, value):
            errors.append(f"{_where(path)}: does not match pattern /{pattern}/")
    except re.error as exc:
        errors.append(f"{_where(path)}: invalid schema pattern /{pattern}/: {exc}")


def _json_equal(a: Any, b: Any) -> bool:
    """JSON equality: unlike Python, ``true`` never equals ``1`` (nor ``false`` ``0``)."""
    return isinstance(a, bool) == isinstance(b, bool) and a == b


def _check_values(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    if _ENUM in schema and not any(_json_equal(value, opt) for opt in schema[_ENUM] or []):
        errors.append(f"{_where(path)}: {value!r} not in enum {schema[_ENUM]!r}")
    if _CONST in schema and not _json_equal(value, schema[_CONST]):
        errors.append(f"{_where(path)}: {value!r} != const {schema[_CONST]!r}")


def _check_object(value: dict, schema: dict, path: str, errors: list[str]) -> None:
    for r in schema.get("required", []) or []:
        if r not in value:
            errors.append(f"{path}.{r}: required field missing")
    props = schema.get("properties", {}) or {}
    extra = schema.get("additionalProperties", True)
    for k, v in value.items():
        if k in props:
            check_schema(v, props[k], f"{path}.{k}", errors)
        elif extra is False:
            errors.append(f"{path}.{k}: additional property not allowed")
        elif isinstance(extra, dict):
            check_schema(v, extra, f"{path}.{k}", errors)


def check_schema(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    """Append violations of `schema` by `value` (at `path`) to `errors`."""
    if not isinstance(schema, dict):
        errors.append(f"{_where(path)}: schema must be an object")
        return
    errors.extend(f"{_where(path)}: unsupported schema keyword '{key}'" for key in schema if key not in _KNOWN)
    if not _check_type(value, schema.get("type"), path, errors):
        return
    _check_limits(value, schema, path, errors)
    _check_pattern(value, schema, path, errors)
    _check_values(value, schema, path, errors)
    if isinstance(value, dict):
        _check_object(value, schema, path, errors)
    items_schema = schema.get("items")
    if isinstance(value, list) and items_schema:
        for i, item in enumerate(value):
            check_schema(item, items_schema, f"{path}[{i}]", errors)
