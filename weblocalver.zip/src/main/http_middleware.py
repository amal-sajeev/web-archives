"""Pure-ASGI middleware: request-id correlation and response cache policy.

Both classes wrap ``send`` instead of using ``BaseHTTPMiddleware`` so streaming
responses (SSE) pass through untouched and without extra buffering.

* ``RequestIdMiddleware`` accepts a well-formed inbound ``X-Request-ID`` (or
  mints one), stores it on ``request.state.request_id`` and in a context
  variable read by the log-record factory, and echoes it on every response.
* ``CacheControlMiddleware`` stops API/health JSON from being cached by
  browsers or proxies, lets version-stamped static assets (``?v=``) be cached
  for a day, and makes everything else revalidate.
"""

from __future__ import annotations

import logging
import re
import uuid
from collections.abc import Callable
from contextvars import ContextVar
from typing import Any
from urllib.parse import parse_qs

from starlette.datastructures import MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send

REQUEST_ID_HEADER = "X-Request-ID"
_REQUEST_ID_PATTERN = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
_request_id_var: ContextVar[str | None] = ContextVar("request_id", default=None)

NO_STORE = "no-store"
REVALIDATE = "no-cache"
VERSIONED_ASSET = "public, max-age=86400"
_API_PREFIX = "/api/"
_UNCACHED_PATHS = frozenset({"/health", "/helath", "/livez", "/readyz"})
_ERROR_STATUS = 400


def current_request_id() -> str | None:
    """The request id of the request being handled in this context, if any."""
    return _request_id_var.get()


def _inbound_request_id(scope: Scope) -> str | None:
    for name, value in scope.get("headers", []):
        if name == b"x-request-id":
            candidate = value.decode("latin-1").strip()
            return candidate if _REQUEST_ID_PATTERN.match(candidate) else None
    return None


def _on_response_start(send: Send, apply: Callable[[MutableHeaders, int], None]) -> Send:
    async def _send(message: Message) -> None:
        if message["type"] == "http.response.start":
            apply(MutableHeaders(scope=message), int(message["status"]))
        await send(message)
    return _send


class RequestIdMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        request_id = _inbound_request_id(scope) or uuid.uuid4().hex
        scope.setdefault("state", {})["request_id"] = request_id

        def _apply(headers: MutableHeaders, _status: int) -> None:
            headers[REQUEST_ID_HEADER] = request_id

        token = _request_id_var.set(request_id)
        try:
            await self.app(scope, receive, _on_response_start(send, _apply))
        finally:
            _request_id_var.reset(token)


def cache_policy(path: str, query_string: bytes, status: int) -> str:
    """``Cache-Control`` value for a response that did not set its own."""
    if path.startswith(_API_PREFIX) or path in _UNCACHED_PATHS or status >= _ERROR_STATUS:
        return NO_STORE
    if "v" in parse_qs(query_string.decode("latin-1")):
        return VERSIONED_ASSET
    return REVALIDATE


class CacheControlMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        root_path = scope.get("root_path", "")
        path = scope["path"]
        if root_path and path.startswith(root_path):
            path = path[len(root_path):] or "/"
        query = scope.get("query_string", b"")

        def _apply(headers: MutableHeaders, status: int) -> None:
            if "cache-control" not in headers:
                headers["Cache-Control"] = cache_policy(path, query, status)

        await self.app(scope, receive, _on_response_start(send, _apply))


def install_request_id_logging() -> None:
    """Stamp ``request_id`` on every log record created while a request is handled.

    Idempotent. Records created outside a request are left unchanged, so an
    explicit ``extra={"request_id": ...}`` there never collides.
    """
    previous = logging.getLogRecordFactory()
    if getattr(previous, "adds_request_id", False):
        return

    def _factory(*args: Any, **kwargs: Any) -> logging.LogRecord:
        record = previous(*args, **kwargs)
        request_id = _request_id_var.get()
        if request_id is not None:
            record.request_id = request_id
        return record

    _factory.adds_request_id = True  # type: ignore[attr-defined]
    logging.setLogRecordFactory(_factory)
