"""Ephemeral agent-config playground support.

Uploaded configuration bundles are extracted into a temporary directory for the
life of one evaluation. Nothing is persisted in the evaluation repository.
The browser owns the editable copy and can send the current file set back for
subsequent tests or export.
"""
from __future__ import annotations

import ast
import base64
import importlib
import io
import json
import os
import shutil
import sys
import tempfile
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

import yaml

from models import AgentConfig, Dataset, RunRecord
from registry import Registry
from repository.base import EvaluationRepository

MAX_ZIP_BYTES = 32 * 1024 * 1024
MAX_UNCOMPRESSED_BYTES = 96 * 1024 * 1024
MAX_FILES = 1500


def _declared_custom_scorers(source: str) -> list[str]:
    """Statically discover scorer names declared by @scorer decorators."""
    try:
        tree = ast.parse(source, filename="custom_tests.py")
    except SyntaxError:
        return []
    names: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for decorator in node.decorator_list:
            call = decorator if isinstance(decorator, ast.Call) else None
            if not call or not isinstance(call.func, ast.Name) or call.func.id != "scorer":
                continue
            if call.args and isinstance(call.args[0], ast.Constant) and isinstance(call.args[0].value, str):
                names.append(call.args[0].value)
    return sorted(set(names))


def _load_scoped_registry(temp_dir: Path) -> tuple[Registry, list[str], list[str]]:
    """Load an ephemeral registry and identify scorers introduced by custom_tests.py."""
    from scorers import all_scorers
    from scorers.base import snapshot_scorers
    before = snapshot_scorers()
    modules_before = set(sys.modules)
    registry = Registry(temp_dir).load()
    after = all_scorers()
    custom = sorted(set(after) - set(before))
    collisions = sorted(name for name in set(after) & set(before) if after[name] is not before[name])
    registry._playground_scorer_snapshot = before  # type: ignore[attr-defined]
    registry._playground_modules_before = modules_before  # type: ignore[attr-defined]
    return registry, custom, collisions


def _cleanup_scoped_registry(registry: Registry) -> None:
    from scorers.base import restore_scorers
    snapshot = getattr(registry, "_playground_scorer_snapshot", None)
    if snapshot is not None:
        restore_scorers(snapshot)
    modules_before = getattr(registry, "_playground_modules_before", set())
    for name in list(sys.modules):
        if name not in modules_before and name.startswith("custom_tests_"):
            sys.modules.pop(name, None)
    importlib.invalidate_caches()


class PreviewRepository(EvaluationRepository):
    """Repository for a single preview run. It never touches SQLite/Postgres."""

    def __init__(self) -> None:
        self._runs: dict[str, RunRecord] = {}
        self._baselines: dict[tuple[str, str, str, str], float] = {}

    def init_schema(self) -> None:
        return None

    def save_run(self, run: RunRecord) -> None:
        self._runs[run.run_id] = run

    def get_run(self, run_id: str) -> RunRecord | None:
        return self._runs.get(run_id)

    def list_runs(self, agent_id=None, limit=50, before=None, status=None, dataset_id=None):
        rows = []
        for run in sorted(self._runs.values(), key=lambda r: r.creation_ts, reverse=True):
            if agent_id and run.agent_id != agent_id:
                continue
            if dataset_id and run.dataset_id != dataset_id:
                continue
            if status and (run.status != status and not (status.startswith("ERROR") and run.status.startswith("ERROR"))):
                continue
            if before and run.creation_ts >= before:
                continue
            rows.append({
                "run_id": run.run_id, "agent_id": run.agent_id,
                "dataset_id": run.dataset_id, "dataset_version": run.dataset_version,
                "weighted_score": run.weighted_score, "weighted_delta": run.weighted_delta,
                "status": run.status, "creation_ts": run.creation_ts, "created_by": run.created_by,
            })
        return rows[:limit]

    def get_baseline(self, agent_id, dataset_id, dataset_version, metric):
        return self._baselines.get((agent_id, dataset_id, dataset_version, metric))

    def set_baseline(self, agent_id, dataset_id, dataset_version, metric, value, created_by):
        self._baselines[(agent_id, dataset_id, dataset_version, metric)] = value


def _safe_member(name: str) -> str:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or "" in p.parts:
        raise ValueError(f"Unsafe zip path: {name!r}")
    return p.as_posix()


def _read_zip(blob: bytes) -> dict[str, bytes]:
    if len(blob) > MAX_ZIP_BYTES:
        raise ValueError(f"Configuration ZIP exceeds {MAX_ZIP_BYTES // (1024 * 1024)} MB.")
    try:
        zf = zipfile.ZipFile(io.BytesIO(blob))
    except zipfile.BadZipFile as exc:
        raise ValueError("The uploaded file is not a valid ZIP archive.") from exc
    infos = zf.infolist()
    if len(infos) > MAX_FILES:
        raise ValueError(f"ZIP contains too many files (maximum {MAX_FILES}).")
    total = 0
    out: dict[str, bytes] = {}
    for info in infos:
        name = _safe_member(info.filename)
        if info.is_dir():
            continue
        # Reject symlink entries. They can escape the extraction root.
        if ((info.external_attr >> 16) & 0o170000) == 0o120000:
            raise ValueError(f"Symlinks are not allowed in uploaded bundles: {name}")
        total += info.file_size
        if total > MAX_UNCOMPRESSED_BYTES:
            raise ValueError(f"ZIP expands beyond {MAX_UNCOMPRESSED_BYTES // (1024 * 1024)} MB.")
        out[name] = zf.read(info)
    if not out:
        raise ValueError("The ZIP archive is empty.")
    return out


def _agent_root(files: dict[str, bytes]) -> str:
    manifests = [p for p in files if p.endswith("/agent.yaml") or p == "agent.yaml"]
    if len(manifests) != 1:
        raise ValueError("Upload exactly one agent configuration folder containing one agent.yaml.")
    manifest = manifests[0]
    return manifest.rsplit("/", 1)[0] if "/" in manifest else ""


def _normalise_files(files: dict[str, bytes], root: str) -> dict[str, bytes]:
    prefix = f"{root}/" if root else ""
    normalized: dict[str, bytes] = {}
    for path, data in files.items():
        if not path.startswith(prefix):
            continue
        rel = path[len(prefix):]
        if rel:
            normalized[rel] = data
    if "agent.yaml" not in normalized:
        raise ValueError("The selected agent folder does not contain agent.yaml.")
    return normalized


def _load_config(files: dict[str, bytes]) -> tuple[AgentConfig, Dataset]:
    try:
        cfg_data = yaml.safe_load(files["agent.yaml"].decode("utf-8-sig")) or {}
        config = AgentConfig.model_validate(cfg_data)
    except Exception as exc:
        raise ValueError(f"agent.yaml is invalid: {exc}") from exc
    try:
        dataset_raw = files[config.dataset_file].decode("utf-8-sig")
        dataset = Dataset.model_validate(json.loads(dataset_raw))
    except KeyError as exc:
        raise ValueError(f"Configured dataset file is missing: {config.dataset_file}") from exc
    except Exception as exc:
        raise ValueError(f"Dataset is invalid: {exc}") from exc
    if config.metrics_stub_file not in files and (config.metrics_source or "").lower() == "stub":
        raise ValueError(f"Configured metrics stub file is missing: {config.metrics_stub_file}")
    return config, dataset


def inspect_bundle(blob: bytes) -> dict[str, Any]:
    raw_files = _read_zip(blob)
    root = _agent_root(raw_files)
    files = _normalise_files(raw_files, root)
    config, dataset = _load_config(files)
    text_exts = {".yaml", ".yml", ".json", ".py", ".txt", ".md", ".toml", ".ini", ".cfg", ".xml", ".csv", ".env"}
    items = []
    for path in sorted(files):
        data = files[path]
        suffix = Path(path).suffix.lower()
        is_text = suffix in text_exts
        if is_text:
            try:
                text = data.decode("utf-8-sig")
            except UnicodeDecodeError:
                is_text = False
        item: dict[str, Any] = {"path": path, "size": len(data), "encoding": "utf-8" if is_text else "base64", "kind": "text" if is_text else "binary"}
        if is_text:
            item["content"] = text
        else:
            item["content"] = base64.b64encode(data).decode("ascii")
        items.append(item)
    custom_info = {"present": "custom_tests.py" in files, "declared_scorers": [], "syntax_error": None}
    warnings: list[str] = []
    if "custom_tests.py" in files:
        source = files["custom_tests.py"].decode("utf-8-sig")
        custom_info["declared_scorers"] = _declared_custom_scorers(source)
        try:
            ast.parse(source, filename="custom_tests.py")
        except SyntaxError as exc:
            custom_info["syntax_error"] = f"line {exc.lineno}: {exc.msg}"
        warnings.append("custom_tests.py is executable Python and will run on the evaluation service when present.")
        if custom_info["syntax_error"]:
            warnings.append(f"custom_tests.py syntax error: {custom_info['syntax_error']}")
    return {
        "root": root,
        "agent": config.model_dump(),
        "dataset": {
            "dataset_id": dataset.dataset_id, "version": dataset.version,
            "cases": len(dataset.cases), "metrics": len(dataset.metrics),
            "case_items": [{"id": c.id, "input": c.input} for c in dataset.cases],
            "metric_names": [m.name for m in dataset.metrics],
            "target": dataset.target.model_dump(),
        },
        "custom_tests": custom_info,
        "files": items,
        "warnings": warnings,
    }


def files_to_zip(items: list[dict[str, Any]], root: str = "") -> bytes:
    buf = io.BytesIO()
    total = 0
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        seen: set[str] = set()
        for item in items:
            rel_path = _safe_member(str(item.get("path", "")))
            path = _safe_member(f"{root.strip(chr(47))}/{rel_path}" if root else rel_path)
            if not path or path in seen:
                continue
            seen.add(path)
            if item.get("encoding") == "base64":
                try:
                    data = base64.b64decode(item.get("content", ""), validate=True)
                except Exception as exc:
                    raise ValueError(f"Invalid base64 content for {path}") from exc
            else:
                data = str(item.get("content", "")).encode("utf-8")
            total += len(data)
            if total > MAX_UNCOMPRESSED_BYTES:
                raise ValueError("Edited bundle is too large to export/test.")
            zf.writestr(path, data)
    result = buf.getvalue()
    if len(result) > MAX_ZIP_BYTES:
        raise ValueError("Edited ZIP exceeds the 32 MB upload limit.")
    return result


def extract_to_temp(blob: bytes) -> tuple[Path, str]:
    files = _read_zip(blob)
    root = _agent_root(files)
    normalized = _normalise_files(files, root)
    config, _ = _load_config(normalized)
    temp = Path(tempfile.mkdtemp(prefix="ctna-playground-"))
    for rel, data in normalized.items():
        target = temp / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return temp, config.agent_id
