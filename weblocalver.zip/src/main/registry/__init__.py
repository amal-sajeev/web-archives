"""Agent registry: auto-discovers src/agents/<agent_id>/ folders.

Each agent folder holds:
  agent.yaml          - AgentConfig
  dataset.json        - the golden set (Dataset)
  metrics_stub.json   - stubbed metrics API response
  custom_tests.py     - optional bespoke scorers (imported => self-registers)

Adding an agent requires no core code changes. An agent that fails to load or
validate is logged and skipped so one broken folder cannot take the service
down; the new agent map replaces the old one in a single assignment.
"""

from __future__ import annotations

import importlib.util
import json
import logging
import warnings
from pathlib import Path
from typing import Any

import yaml

from core.config import Config
from core.models import AgentConfig, Dataset

_log = logging.getLogger("eval_service.registry")


class RegisteredAgent:
    def __init__(self, folder: Path, config: AgentConfig, dataset: Dataset):
        self.folder = folder
        self.config = config
        self.dataset = dataset

    @property
    def metrics_stub_path(self) -> Path:
        return self.folder / self.config.metrics_stub_file


def _agent_errors(agent_id: str, agent: RegisteredAgent, known: dict[str, Any]) -> list[str]:
    """Validation problems for one agent (unknown scorers, empty dataset)."""
    errors = [
        f"  agent '{agent_id}' metric '{metric.name}': unknown scorer '{metric.scorer}'"
        for metric in agent.dataset.metrics
        if metric.scorer not in known
    ]
    if not agent.dataset.cases:
        errors.append(f"  agent '{agent_id}': dataset has no cases")
    return errors


def _summary(agent: RegisteredAgent) -> dict[str, Any]:
    return {
        "agent_id": agent.config.agent_id,
        "name": agent.config.name,
        "dataset_id": agent.dataset.dataset_id,
        "dataset_version": agent.dataset.version,
        "cases": len(agent.dataset.cases),
        "metrics": [m.name for m in agent.dataset.metrics],
        "enabled": agent.config.enabled,
    }


def _force_enabled(agent_id: str) -> bool:
    """True when EVAL_ENABLE_AGENTS names this agent (or is "*")."""
    overrides = Config.ENABLE_AGENTS
    return "*" in overrides or agent_id in overrides


def _known_scorers() -> dict[str, Any]:
    from scorers import all_scorers  # lazy: avoid circular import

    return all_scorers()


class Registry:
    def __init__(self, agents_dir: Path | None = None):
        self._dir = agents_dir or Config.AGENTS_DIR
        self._agents: dict[str, RegisteredAgent] = {}

    def load(self) -> Registry:
        """(Re)discover agents; broken folders are logged and skipped."""
        loaded: dict[str, RegisteredAgent] = {}
        folders = sorted(p for p in self._dir.iterdir() if p.is_dir()) if self._dir.exists() else []
        for folder in folders:
            agent = self._load_folder(folder)
            if agent is None:
                continue
            agent_id = agent.config.agent_id
            if agent_id in loaded:
                _log.warning(
                    "duplicate agent_id '%s' in %s; replacing the one from %s",
                    agent_id, folder, loaded[agent_id].folder,
                )
            loaded[agent_id] = agent
        known = _known_scorers()
        for agent_id, agent in list(loaded.items()):
            errors = _agent_errors(agent_id, agent, known)
            if errors:
                _log.error("agent '%s' failed validation and was skipped:\n%s", agent_id, "\n".join(errors))
                del loaded[agent_id]
        self._agents = loaded
        return self

    def _load_folder(self, folder: Path) -> RegisteredAgent | None:
        cfg_file = folder / "agent.yaml"
        if not cfg_file.exists():
            return None
        try:
            config = AgentConfig.model_validate(yaml.safe_load(cfg_file.read_text("utf-8-sig")))
            dataset = Dataset.model_validate(
                json.loads((folder / config.dataset_file).read_text("utf-8-sig"))
            )
            self._import_custom_tests(folder)
        except Exception:
            _log.exception("failed to load agent folder %s; skipping it", folder)
            return None
        if not config.enabled and _force_enabled(config.agent_id):
            config = config.model_copy(update={"enabled": True})
        return RegisteredAgent(folder, config, dataset)

    def validate(self) -> None:
        """Pre-flight: raise ValueError listing every unknown scorer / empty dataset."""
        known = _known_scorers()
        errors = [
            err
            for agent_id, agent in self._agents.items()
            for err in _agent_errors(agent_id, agent, known)
        ]
        if errors:
            raise ValueError("Dataset validation failed:\n" + "\n".join(errors))

    def _import_custom_tests(self, folder: Path) -> None:
        custom = folder / "custom_tests.py"
        if not custom.exists():
            return
        spec = importlib.util.spec_from_file_location(f"custom_tests_{folder.name}", custom)
        if spec is None or spec.loader is None:
            # Skipping silently would surface later as confusing "unknown scorer" errors.
            raise ImportError(f"cannot load {custom} as a Python module")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)  # decorators self-register scorers

    def get(self, agent_id: str) -> RegisteredAgent:
        agents = self._agents
        if agent_id not in agents:
            raise KeyError(f"Unknown agent '{agent_id}'. Known: {sorted(agents)}")
        return agents[agent_id]

    def has(self, agent_id: str) -> bool:
        """True when ``agent_id`` is loaded (enabled or not)."""
        return agent_id in self._agents

    def list_agents(self, include_disabled: bool = False) -> list[dict[str, Any]]:
        """Summaries of the loaded agents, for list endpoints.

        Only enabled agents by default. With ``include_disabled=True`` disabled
        agents are appended after the enabled ones. Every item carries
        ``enabled``.
        """
        agents = sorted(self._agents.values(), key=lambda a: not a.config.enabled)  # stable: enabled first
        return [_summary(a) for a in agents if include_disabled or a.config.enabled]

    def list(self) -> list[dict[str, Any]]:
        """Deprecated alias of :meth:`list_agents`."""
        warnings.warn("Registry.list() is deprecated; use list_agents()", DeprecationWarning, stacklevel=2)
        return self.list_agents()
