"""CTNA Evaluation Service — FastAPI application.

Serves the REST API (used by both the human dashboard and the CI/CD gate) and
the static HTML dashboard.
"""

from __future__ import annotations

import asyncio
import csv
import io
import json
import contextlib
import subprocess
import shutil
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

import httpx
from fastapi import FastAPI, HTTPException, Query, UploadFile, File, Form
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from config import Config
from models import (
    ABCompareRequest, AsyncEvaluateRequest, EvaluateRequest,
    HumanLabel, LabelRequest,
)
from adapters import capture_store
from labels import label_store
from structured_logging import get_logger
from registry import Registry
from repository import build_repository
from run_manager import DONE, LiveRun, run_manager
from runner import Runner
from playground import (
    PreviewRepository, _cleanup_scoped_registry, _load_scoped_registry, extract_to_temp, files_to_zip, inspect_bundle,
)
from scorers.vertex import require_vertex_credentials

_log = get_logger("eval_service.main")


def _load_static_text(filename: str) -> str:
    path = Config.STATIC_DIR / filename
    try:
        return path.read_text(encoding="utf-8")
    except PermissionError:
        repo_root = Path(__file__).resolve().parents[3]
        result = subprocess.run(
            ["git", "show", f"HEAD:dbaware-evaluation-service/src/main/static/{filename}"],
            cwd=str(repo_root),
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        return result.stdout


def _prefix_safe_dashboard_js(src: str) -> str:
    """Convert root-absolute dashboard URLs to relative URLs.

    This keeps the static UI working when the service is mounted behind an
    ingress path prefix (e.g. /eval/) instead of at domain root.
    """
    return (
        src
        .replace('fetch("/api/', 'fetch("api/')
        .replace('fetch(`/api/', 'fetch(`api/')
        .replace(
            'location.href = `/run_detail.html?run=${encodeURIComponent(tr.dataset.id)}`;',
            'location.href = `run_detail.html?run=${encodeURIComponent(tr.dataset.id)}`;',
        )
        .replace(
            'location.href = `/run.html?agent=${encodeURIComponent(agent)}&reps=${reps}`;',
            'location.href = `run.html?agent=${encodeURIComponent(agent)}&reps=${reps}`;',
        )
        .replace(
            'if (id) location.href = `/run_detail.html?run=${encodeURIComponent(id)}`;',
            'if (id) location.href = `run_detail.html?run=${encodeURIComponent(id)}`;',
        )
    )


def _render_static_html(filename: str) -> bytes:
    html = _load_static_text(filename)
    html = html.replace("__ASSET_VERSION__", Config.SERVICE_VERSION)
    return html.encode("utf-8")


_APP_JS = _prefix_safe_dashboard_js(_load_static_text("app.js"))
_INDEX_HTML = _render_static_html("index.html")
_RUN_HTML = _render_static_html("run.html")
_RUN_DETAIL_HTML = _render_static_html("run_detail.html")
_PLAYGROUND_HTML = _render_static_html("playground.html")
_API_TESTER_HTML = _render_static_html("apitester.html")

app = FastAPI(title="CTNA Evaluation Service", version=Config.SERVICE_VERSION)

_PLAYGROUND_SEMAPHORE = asyncio.Semaphore(1)


_registry = Registry().load()
_repo = build_repository()
_runner = Runner(_registry, _repo)

# Run retention: delete old runs on startup.
if Config.RUN_RETENTION_DAYS > 0:
    try:
        deleted = _repo.delete_old_runs(Config.RUN_RETENTION_DAYS)
        if deleted:
            _log.info("run_retention_cleanup", extra={"deleted": deleted, "days": Config.RUN_RETENTION_DAYS})
    except Exception:
        _log.warning("run_retention_failed", extra={"error_type": "retention"})


@app.get("/api/health")
@app.get("/api/helath")
@app.get("/health")
@app.get("/helath")
def health():
    """Config + ADC probe; reports the resolved credential class name."""
    result = {"status": "ok", "project_name": Config.PROJECT_NAME or None,
              "version": Config.SERVICE_VERSION,
              "project_location": Config.PROJECT_LOCATION, "agents": len(_registry.list()),
              "storage_backend": type(_repo).__name__,
              "db_url_scheme": (Config.DB_URL.split(":", 1)[0] if ":" in Config.DB_URL else Config.DB_URL),
              "db_name": Config.DB_NAME,
              "db_schema": Config.DB_SCHEMA,
              "db_host": Config.DB_HOST,
              "db_connection_mode": ("tcp_proxy" if Config.DB_HOST else "cloudsql_connector"),
              "sqlite_fallback_allowed": Config.ALLOW_SQLITE_FALLBACK}
    if not Config.PROJECT_NAME:
        result.update(status="degraded",
                      vertex="PROJECT_NAME unset — judge would fall back to the Developer API")
        return result
    try:
        result["credential_class"] = require_vertex_credentials()
        result["vertex"] = "ok"
    except Exception as exc:
        result.update(status="degraded", vertex=f"{type(exc).__name__}: {exc}")
    return result


@app.get("/api/agents")
def list_agents():
    return {"agents": _registry.list()}


@app.get("/api/agents/{agent_id}/target")
def agent_target(agent_id: str):
    """Show resolved target wiring for one agent (no secrets)."""
    try:
        agent = _registry.get(agent_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    target = agent.dataset.target
    base_url = (agent.config.base_url or Config.AGENT_SERVICE_BASE_URL).rstrip("/")
    endpoint = target.endpoint
    request_url = f"{base_url}{endpoint}"

    return {
        "agent_id": agent.config.agent_id,
        "dataset_id": agent.dataset.dataset_id,
        "dataset_version": agent.dataset.version,
        "adapter": target.adapter,
        "base_url": base_url,
        "endpoint": endpoint,
        "request_url": request_url,
        "method": target.method,
        "trust_env": target.trust_env,
        "timeout": target.timeout,
        "headers_configured": sorted(list((target.headers or {}).keys())),
        "auth_type": (target.auth or {}).get("type"),
        "response_output_path": target.response.output_path,
        "response_error_path": target.response.error_path,
        "walkthrough_upload_url": (f"{base_url}/qna/upload" if target.adapter == "walkthrough_http" else None),
    }


@app.post("/api/evaluate")
async def evaluate(request: EvaluateRequest):
    try:
        run = await _runner.evaluate(
            request.agent_id,
            request.dataset_version,
            request.judge_repetitions,
            request.created_by,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"{type(exc).__name__}: {exc}") from exc
    return run.model_dump()


async def _drive_run(live: LiveRun, agent_id: str,
                     dataset_version: str | None, judge_repetitions: int,
                     created_by: str) -> None:
    """Execute one evaluation, publishing progress to the LiveRun buffer.

    Runs as a background task tied to the app event loop (not to any browser
    connection), so a client disconnecting never cancels the run.
    """
    async def progress(event: dict) -> None:
        live.publish(event)

    try:
        await _runner.evaluate(agent_id, dataset_version, judge_repetitions, created_by, progress)
    except asyncio.CancelledError:
        live.publish({"type": "run_cancelled", "status": 499, "detail": "Run cancelled by request"})
        raise
    except KeyError as exc:
        live.publish({"type": "error", "status": 404, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except ValueError as exc:
        live.publish({"type": "error", "status": 400, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except Exception as exc:
        import traceback
        live.publish({"type": "error", "status": 502,
                      "detail": f"{type(exc).__name__}: {exc}",
                      "error_type": type(exc).__name__,
                      "traceback": traceback.format_exc()})
    finally:
        live.finish()


@app.post("/api/evaluate/start")
async def evaluate_start(request: EvaluateRequest):
    """Start an evaluation as a background run and return a stream id.

    The run keeps going even if the browser tab is closed; reconnect to
    `/api/evaluate/stream/{stream_id}` to replay + tail its progress.
    """
    if request.agent_id not in {a["agent_id"] for a in _registry.list()}:
        raise HTTPException(status_code=404, detail=f"Unknown agent '{request.agent_id}'")
    reps = max(1, min(int(request.judge_repetitions), 5))
    live = run_manager.create(request.agent_id)
    live.task = asyncio.create_task(
        _drive_run(live, request.agent_id, request.dataset_version, reps, request.created_by)
    )
    return {"stream_id": live.stream_id, "agent_id": request.agent_id}


@app.get("/api/evaluate/streams")
def evaluate_streams():
    """List active/recent background run streams and their lifecycle status."""
    return {"streams": run_manager.list_runs()}


@app.post("/api/evaluate/cancel/{stream_id}")
async def evaluate_cancel(stream_id: str):
    """Request cancellation for a background evaluation stream."""
    live = run_manager.get(stream_id)
    if live is None:
        raise HTTPException(status_code=404, detail=f"Run stream '{stream_id}' not found")
    if live.done:
        return {"stream_id": stream_id, "cancel_requested": False, "already_done": True}

    requested = live.request_cancel()
    task = live.task
    if task is not None and not task.done():
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    return {"stream_id": stream_id, "cancel_requested": requested, "already_done": live.done}


@app.get("/api/evaluate/stream/{stream_id}/events")
async def evaluate_stream_events(stream_id: str, after: int = Query(default=0, ge=0)):
    """Poll buffered evaluation events for clients/proxies that do not preserve SSE flushing."""
    live = run_manager.get(stream_id)
    if live is None:
        raise HTTPException(status_code=404, detail=f"Run stream '{stream_id}' not found")
    events = live.events[after:]
    run = None
    for event in reversed(events):
        if event.get("type") == "playground_done":
            run = event.get("run")
            break
    return {"events": events, "next": after + len(events), "done": live.done, "run": run}

@app.get("/api/evaluate/stream/{stream_id}")
async def evaluate_stream(stream_id: str):
    """Attach to a running (or finished) evaluation and stream its progress as SSE.

    Replays the full buffered event history first, then tails live events. The
    underlying run is NOT tied to this connection: closing the tab leaves the run
    running and it still persists; reconnecting replays everything so far.
    """
    live = run_manager.get(stream_id)
    if live is None:
        raise HTTPException(status_code=404, detail=f"Run stream '{stream_id}' not found")

    async def event_source():
        queue = live.subscribe()
        try:
            while True:
                event = await queue.get()
                if event is DONE:
                    break
                yield f"data: {json.dumps(event, default=str)}\n\n"
                # Flush through common reverse proxies between real events.
                yield ": keepalive\n\n"
        finally:
            live.unsubscribe(queue)

    return StreamingResponse(
        event_source(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                 "Connection": "keep-alive"},
    )


@app.get("/api/runs")
def list_runs(
    agent_id: str | None = None,
    limit: int = Query(default=50, ge=1, le=200),
    before: str | None = None,
    status: str | None = Query(default=None, pattern="^(PASS|FAIL|ERROR.*)$"),
    dataset_id: str | None = None,
):
    """List run summaries, newest first.

    ``before`` is a cursor: pass the ``creation_ts`` of the last run in the page
    to get the next page. The response includes ``next_cursor`` for pagination.
    """
    runs = _repo.list_runs(
        agent_id=agent_id,
        limit=limit,
        before=before,
        status=status,
        dataset_id=dataset_id,
    )
    # Add compact case counts to run summaries so dashboards can remain useful
    # without fetching every full run record in the browser.
    for item in runs:
        detail = _repo.get_run(item["run_id"])
        if detail:
            item["case_count"] = len(detail.case_results)
            item["passed_case_count"] = sum(1 for c in detail.case_results if c.passed)
    next_cursor = runs[-1]["creation_ts"] if len(runs) == limit else None
    return {"runs": runs, "next_cursor": next_cursor}


@app.get("/api/runs/compare")
def compare_runs(a: str, b: str):
    """Compare two runs side-by-side: per-case scores, deltas, and pass/fail."""
    run_a = _repo.get_run(a)
    run_b = _repo.get_run(b)
    if not run_a:
        raise HTTPException(status_code=404, detail=f"Run '{a}' not found")
    if not run_b:
        raise HTTPException(status_code=404, detail=f"Run '{b}' not found")

    cases_a = {c.case_id: c for c in run_a.case_results}
    cases_b = {c.case_id: c for c in run_b.case_results}
    all_case_ids = sorted(set(cases_a) | set(cases_b))
    case_comparison = []
    for cid in all_case_ids:
        ca = cases_a.get(cid)
        cb = cases_b.get(cid)
        row = {"case_id": cid}
        if ca and cb:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed, "delta": ca.weighted_delta}
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed, "delta": cb.weighted_delta}
            row["improved"] = cb.weighted_score > ca.weighted_score
        elif ca:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed}
            row["b"] = None
        else:
            row["a"] = None
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed}
        case_comparison.append(row)
    return {
        "a": {"run_id": run_a.run_id, "agent_id": run_a.agent_id,
              "score": run_a.weighted_score, "delta": run_a.weighted_delta, "status": run_a.status},
        "b": {"run_id": run_b.run_id, "agent_id": run_b.agent_id,
              "score": run_b.weighted_score, "delta": run_b.weighted_delta, "status": run_b.status},
        "score_diff": run_b.weighted_score - run_a.weighted_score,
        "cases": case_comparison,
    }


@app.get("/api/runs/{run_id}")
def get_run(run_id: str):
    run = _repo.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    return run.model_dump()


@app.get("/api/runs/{run_id}/export")
def export_run(run_id: str, format: str = "csv"):
    """Export a run's full detail as CSV or PDF."""
    run = _repo.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    if format == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["case_id", "case_status", "weighted_score", "weighted_delta",
                         "metric", "score", "threshold", "passed_metric", "critical",
                         "rationale"])
        for case in run.case_results:
            if not case.scores:
                writer.writerow([case.case_id, case.passed, case.weighted_score,
                                 case.weighted_delta, "", "", "", "", "", ""])
            for s in case.scores:
                writer.writerow([case.case_id, case.passed, case.weighted_score,
                                 case.weighted_delta, s.metric, s.score, s.threshold,
                                 s.passed, s.critical, s.rationale])
        return Response(
            content=buf.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename=run_{run_id[:8]}.csv"},
        )

    if format == "pdf":
        lines = [
            f"Evaluation Run Export: {run.run_id[:8]}",
            f"Agent: {run.agent_id}  Dataset: {run.dataset_id} v{run.dataset_version}",
            f"Score: {run.weighted_score:.3f}  Delta: {run.weighted_delta:+.3f}  Status: {run.status}",
            f"Created: {run.creation_ts} by {run.created_by}",
            "",
        ]
        for case in run.case_results:
            lines.append(f"  {'PASS' if case.passed else 'FAIL'} {case.case_id} "
                         f"(score={case.weighted_score:.3f})")
            for s in case.scores:
                lines.append(f"    {'✓' if s.passed else '✗'} {s.metric}={s.score:.2f} "
                             f"(threshold={s.threshold}) {s.rationale[:80]}")
            lines.append("")
        pdf_bytes = _build_text_pdf(lines)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=run_{run_id[:8]}.pdf"},
        )

    raise HTTPException(status_code=400, detail=f"Unsupported format '{format}'. Use csv or pdf.")


def _build_text_pdf(text_lines: list[str]) -> bytes:
    """Build a minimal valid PDF with text (stdlib only)."""
    content_parts = ["BT", "/F1 10 Tf", "72 750 Td"]
    for i, line in enumerate(text_lines):
        if i > 0:
            content_parts.append("0 -14 Td")
        escaped = line.replace("(", r"\(").replace(")", r"\)")[:200]
        content_parts.append(f"({escaped}) Tj")
    content_parts.append("ET")
    content = "\n".join(content_parts).encode("latin-1", errors="replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /MediaBox [0 0 612 792] /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(content)} >>".encode("latin-1") + b"\nstream\n" + content + b"\nendstream",
    ]
    pdf = b"%PDF-1.4\n"
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(pdf))
        pdf += f"{i} 0 obj\n".encode("latin-1") + obj + b"\nendobj\n"
    xref_offset = len(pdf)
    pdf += f"xref\n0 {len(objects) + 1}\n".encode("latin-1")
    pdf += b"0000000000 65535 f \n"
    for offset in offsets:
        pdf += f"{offset:010d} 00000 n \n".encode("latin-1")
    pdf += (f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF").encode("latin-1")
    return pdf


@app.post("/api/baselines/promote/{run_id}")
def promote_baselines(run_id: str):
    """Promote a run's per-metric mean scores as the new baseline.

    For each metric in the run, the mean score across all cases becomes the
    blessed baseline — used for delta tracking and drift detection on future runs.
    """
    run = _repo.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    promoted: list[dict] = []
    # Collect per-metric scores across all cases.
    metric_scores: dict[str, list[float]] = {}
    for case in run.case_results:
        for s in case.scores:
            metric_scores.setdefault(s.metric, []).append(s.score)
    for metric, scores in metric_scores.items():
        mean = sum(scores) / len(scores)
        _repo.set_baseline(
            run.agent_id,
            run.dataset_id,
            run.dataset_version,
            metric,
            mean,
            run.created_by,
        )
        promoted.append({"metric": metric, "baseline": round(mean, 4), "samples": len(scores)})
    _log.info("baselines_promoted", extra={
        "run_id": run_id, "agent_id": run.agent_id, "metrics": len(promoted)})
    return {
        "run_id": run_id,
        "agent_id": run.agent_id,
        "dataset_version": run.dataset_version,
        "promoted": promoted,
    }


@app.post("/api/evaluate/async")
async def evaluate_async(request: AsyncEvaluateRequest):
    """Start an evaluation in the background; return immediately.

    If ``webhook_url`` is provided, the service POSTs the completed run record
    to that URL when the run finishes. The client can also poll
    ``GET /api/runs/{run_id}`` or attach to the SSE stream.
    """
    if request.agent_id not in {a["agent_id"] for a in _registry.list()}:
        raise HTTPException(status_code=404, detail=f"Unknown agent '{request.agent_id}'")
    reps = max(1, min(int(request.judge_repetitions), 5))
    live = run_manager.create(request.agent_id)
    live.task = asyncio.create_task(
        _drive_run_with_webhook(
            live,
            request.agent_id,
            request.dataset_version,
            reps,
            request.created_by,
            request.webhook_url,
        )
    )
    return {"stream_id": live.stream_id, "agent_id": request.agent_id, "webhook_url": request.webhook_url}


async def _drive_run_with_webhook(
    live: LiveRun, agent_id: str, dataset_version: str | None,
    judge_repetitions: int, created_by: str, webhook_url: str | None,
) -> None:
    """Run an evaluation, publish progress, and fire the webhook on completion."""
    async def progress(event: dict) -> None:
        live.publish(event)

    run = None
    try:
        run = await _runner.evaluate(agent_id, dataset_version, judge_repetitions, created_by, progress)
    except asyncio.CancelledError:
        live.publish({"type": "run_cancelled", "status": 499, "detail": "Run cancelled by request"})
        raise
    except KeyError as exc:
        live.publish({"type": "error", "status": 404, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except ValueError as exc:
        live.publish({"type": "error", "status": 400, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except Exception as exc:
        import traceback
        live.publish({"type": "error", "status": 502,
                      "detail": f"{type(exc).__name__}: {exc}",
                      "error_type": type(exc).__name__,
                      "traceback": traceback.format_exc()})
    finally:
        live.finish()

    if run and webhook_url:
        try:
            async with httpx.AsyncClient(timeout=Config.WEBHOOK_TIMEOUT) as client:
                await client.post(webhook_url, json=run.model_dump())
            _log.info("webhook_delivered", extra={
                "run_id": run.run_id, "webhook_url": webhook_url})
        except Exception as exc:
            _log.warning("webhook_failed", extra={
                "run_id": run.run_id if run else None,
                "webhook_url": webhook_url, "error": str(exc)})


@app.post("/api/evaluate/ab")
async def evaluate_ab(request: ABCompareRequest):
    """Run two agents against the same dataset and return a comparison.

    Both agents must be registered. The comparison includes per-case score
    differences and an overall winner.
    """
    agent_ids = {a["agent_id"] for a in _registry.list()}
    for aid in (request.agent_a, request.agent_b):
        if aid not in agent_ids:
            raise HTTPException(status_code=404, detail=f"Unknown agent '{aid}'")

    reps = max(1, min(int(request.judge_repetitions), 5))
    run_a, run_b = await asyncio.gather(
        _runner.evaluate(request.agent_a, request.dataset_version, reps),
        _runner.evaluate(request.agent_b, request.dataset_version, reps),
    )

    cases_a = {c.case_id: c for c in run_a.case_results}
    cases_b = {c.case_id: c for c in run_b.case_results}
    all_case_ids = sorted(set(cases_a) | set(cases_b))
    case_comparison = []
    for cid in all_case_ids:
        ca = cases_a.get(cid)
        cb = cases_b.get(cid)
        row = {"case_id": cid}
        if ca and cb:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed}
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed}
            row["winner"] = "b" if cb.weighted_score > ca.weighted_score else ("a" if ca.weighted_score > cb.weighted_score else "tie")
        elif ca:
            row["a"] = {"score": ca.weighted_score, "passed": ca.passed}
        else:
            row["b"] = {"score": cb.weighted_score, "passed": cb.passed}
        case_comparison.append(row)
    return {
        "a": {"run_id": run_a.run_id, "agent_id": run_a.agent_id,
              "score": run_a.weighted_score, "status": run_a.status},
        "b": {"run_id": run_b.run_id, "agent_id": run_b.agent_id,
              "score": run_b.weighted_score, "status": run_b.status},
        "winner": "b" if run_b.weighted_score > run_a.weighted_score else ("a" if run_a.weighted_score > run_b.weighted_score else "tie"),
        "score_diff": run_b.weighted_score - run_a.weighted_score,
        "cases": case_comparison,
    }


@app.post("/api/playground/inspect")
async def playground_inspect(file: UploadFile = File(...)):
    """Inspect an uploaded agent-config ZIP without persisting it."""
    blob = await file.read()
    try:
        return inspect_bundle(blob)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


async def _drive_playground_run(
    live: LiveRun,
    blob: bytes,
    base_url_override: str | None,
    judge_repetitions: int,
    case_ids: list[str] | None = None,
) -> None:
    temp_dir: Path | None = None
    try:
        async with _PLAYGROUND_SEMAPHORE:
            temp_dir, agent_id = extract_to_temp(blob)
            registry, _custom_scorers, _collisions = _load_scoped_registry(temp_dir)
            if base_url_override:
                agent = registry.get(agent_id)
                agent.config = agent.config.model_copy(update={"base_url": base_url_override.strip()})
            repo = PreviewRepository()
            runner = Runner(registry, repo)

            async def progress(event: dict) -> None:
                live.publish(event)

            run = await runner.evaluate(
                agent_id,
                judge_repetitions=max(1, min(int(judge_repetitions), 5)),
                created_by="DEVELOPER",
                progress=progress,
                case_ids=case_ids,
            )
            live.publish({"type": "playground_done", "run": run.model_dump()})
    except asyncio.CancelledError:
        live.publish({"type": "run_cancelled", "status": 499, "detail": "Preview run cancelled"})
        raise
    except (KeyError, ValueError) as exc:
        live.publish({"type": "error", "status": 400, "detail": str(exc),
                      "error_type": type(exc).__name__})
    except Exception as exc:
        import traceback
        live.publish({"type": "error", "status": 502,
                      "detail": f"{type(exc).__name__}: {exc}",
                      "error_type": type(exc).__name__,
                      "traceback": traceback.format_exc()})
    finally:
        if "registry" in locals():
            _cleanup_scoped_registry(registry)
        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
        live.finish()


@app.post("/api/playground/validate")
async def playground_validate(file: UploadFile = File(...)):
    """Validate an uploaded/edited configuration without starting an evaluation."""
    blob = await file.read()
    try:
        data = inspect_bundle(blob)
    except ValueError as exc:
        return {"valid": False, "errors": [str(exc)]}
    errors: list[str] = []
    agent = data.get("agent") or {}
    dataset = data.get("dataset") or {}
    files = {item["path"] for item in data.get("files", [])}
    if not agent.get("agent_id"): errors.append("agent.yaml is missing agent_id.")
    if not agent.get("name"): errors.append("agent.yaml is missing name.")
    if not dataset.get("cases"): errors.append("Dataset contains no cases.")
    if not dataset.get("metrics"): errors.append("Dataset contains no metrics.")
    for item in data.get("files", []):
        if item.get("path", "").startswith((".git/", ".env")):
            errors.append(f"Sensitive or repository metadata file should not be included: {item['path']}")
    custom = data.get("custom_tests", {}) or {}
    loaded_custom_scorers: list[str] = []
    collisions: list[str] = []
    temp_dir = None
    registry = None
    try:
        temp_dir, _ = extract_to_temp(blob)
        registry, loaded_custom_scorers, collisions = _load_scoped_registry(temp_dir)
        if collisions:
            errors.extend([f"custom_tests.py overrides an existing scorer: {name}" for name in collisions])
        missing = sorted(set(custom.get("declared_scorers", [])) - set(loaded_custom_scorers))
        if missing:
            errors.append(f"custom_tests.py did not register declared scorer(s): {', '.join(missing)}")
    except Exception as exc:
        errors.append(f"custom_tests.py could not be loaded: {type(exc).__name__}: {exc}")
    finally:
        if registry is not None:
            _cleanup_scoped_registry(registry)
        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
    return {
        "valid": not errors, "errors": errors,
        "agent": agent.get("agent_id"), "dataset": dataset.get("dataset_id"),
        "custom_tests": {
            "present": bool(custom.get("present")),
            "declared_scorers": custom.get("declared_scorers", []),
            "loaded_scorers": loaded_custom_scorers,
            "collisions": collisions,
        },
    }


@app.get("/api/playground/environment")
def playground_environment():
    """Expose non-secret evaluator settings for parity/debugging in the browser."""
    return {
        "service_version": Config.SERVICE_VERSION,
        "judge_model": Config.JUDGE_MODEL,
        "project_location": Config.PROJECT_LOCATION,
        "metrics_source": Config.METRICS_SOURCE,
        "embedding_model": Config.EMBEDDING_MODEL,
        "judge_samples": Config.JUDGE_SAMPLES,
        "judge_retries": Config.JUDGE_TRANSIENT_RETRIES,
        "judge_concurrency": Config.JUDGE_CONCURRENCY,
        "case_concurrency": Config.CASE_CONCURRENCY,
        "auth_mode": "application-default credentials",
    }


@app.post("/api/playground/http")
async def playground_http(request: dict[str, Any]):
    """Proxy one developer API request and return its response for the API Tester.

    This endpoint is intended for a trusted developer environment. It allows
    localhost and private-network targets so local agents can be tested without
    browser CORS restrictions, while blocking common cloud metadata endpoints.
    """
    import ipaddress
    import socket
    from urllib.parse import urlparse

    url = str(request.get("url") or "").strip()
    method = str(request.get("method") or "GET").upper()
    if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}:
        raise HTTPException(status_code=400, detail="Unsupported HTTP method.")
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(status_code=400, detail="URL must be an absolute http:// or https:// URL.")
    host = parsed.hostname.lower()
    blocked_hosts = {"metadata.google.internal", "metadata", "169.254.169.254", "100.100.100.200"}
    if host in blocked_hosts:
        raise HTTPException(status_code=400, detail="Metadata service addresses are blocked.")
    try:
        infos = await asyncio.to_thread(socket.getaddrinfo, host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
        for info in infos:
            addr = ipaddress.ip_address(info[4][0])
            if addr.is_link_local:
                raise HTTPException(status_code=400, detail="Link-local targets are blocked.")
    except HTTPException:
        raise
    except OSError as exc:
        raise HTTPException(status_code=400, detail=f"Unable to resolve host: {exc}") from exc

    headers = request.get("headers") or {}
    if not isinstance(headers, dict):
        raise HTTPException(status_code=400, detail="headers must be an object.")
    body = request.get("body")
    body_type = str(request.get("body_type") or "json")
    content = None
    if method not in {"GET", "HEAD"} and body is not None:
        if body_type == "json":
            content = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers = {**headers, "Content-Type": headers.get("Content-Type", "application/json")}
        elif body_type in {"text", "raw"}:
            content = str(body).encode("utf-8")
        else:
            content = str(body).encode("utf-8")
    timeout = min(max(float(request.get("timeout") or 30), 1), 60)
    try:
        import time
        started = time.perf_counter()
        # Do not follow redirects here. The destination of a redirect must be
        # validated with the same SSRF policy as the original URL. Returning
        # the 3xx lets the developer decide whether to follow it.
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=False, trust_env=False) as client:
            resp = await client.request(method, url, headers={str(k): str(v) for k,v in headers.items()}, content=content)
        raw = resp.content
        if len(raw) > 5 * 1024 * 1024:
            raw = raw[:5 * 1024 * 1024]
        return {"status": resp.status_code, "reason": resp.reason_phrase, "headers": dict(resp.headers), "body": raw.decode("utf-8", errors="replace"), "duration_ms": round((time.perf_counter()-started)*1000), "size_bytes": len(resp.content), "truncated": len(raw) != len(resp.content)}
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"API request failed: {exc}") from exc


@app.post("/api/playground/start")
async def playground_start(
    file: UploadFile = File(...),
    base_url: str | None = Form(default=None),
    judge_repetitions: int = Form(default=1),
    case_ids_json: str = Form(default=""),
):
    """Run an uploaded/edited agent config as an ephemeral evaluation."""
    blob = await file.read()
    try:
        # Validate the bundle before allocating a background run.
        inspect_bundle(blob)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    import json as _json
    try:
        case_ids = _json.loads(case_ids_json) if case_ids_json else None
        if case_ids is not None and not isinstance(case_ids, list):
            raise ValueError("case_ids_json must contain a JSON array.")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid case selection: {exc}") from exc
    live = run_manager.create("playground")
    live.task = asyncio.create_task(
        _drive_playground_run(live, blob, base_url, judge_repetitions, case_ids)
    )
    return {"stream_id": live.stream_id}


@app.post("/api/playground/export")
async def playground_export(payload: dict):
    """Create a ZIP from the browser's current editable file set."""
    items = payload.get("files")
    root = str(payload.get("root") or "")
    if not isinstance(items, list):
        raise HTTPException(status_code=400, detail="files must be an array")
    try:
        blob = files_to_zip(items, root=root)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return Response(
        content=blob,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=agent-config-playground.zip"},
    )


@app.get("/api/captures")
def list_captures():
    """Latest CTA_ACTION captured per case by the live capture service (in-memory)."""
    return {"source": Config.METRICS_SOURCE, "captures": capture_store.latest()}


@app.get("/api/captures/{case_id}")
def get_capture(case_id: str):
    action = capture_store.get(case_id)
    if not action:
        raise HTTPException(status_code=404, detail=f"No capture for case '{case_id}'")
    return action


@app.get("/api/labels")
def list_labels():
    """Expert pass/fail verdicts used to calibrate the gate/judge (in-memory)."""
    return {"labels": [lbl.model_dump() for lbl in label_store.all()]}


@app.get("/api/labels/{case_id}")
def get_label(case_id: str):
    label = label_store.get(case_id)
    if not label:
        raise HTTPException(status_code=404, detail=f"No label for case '{case_id}'")
    return label.model_dump()


@app.post("/api/labels")
def add_label(request: LabelRequest):
    """Record a human verdict; feeds precision/recall/F1/κ on the next run."""
    label = label_store.add(HumanLabel(**request.model_dump()))
    return label.model_dump()


@app.get("/")
def index():
    return Response(content=_INDEX_HTML, media_type="text/html; charset=utf-8")


@app.get("/run.html", include_in_schema=False)
def run_html():
    return Response(content=_RUN_HTML, media_type="text/html; charset=utf-8")


@app.get("/run_detail.html", include_in_schema=False)
def run_detail_html():
    return Response(content=_RUN_DETAIL_HTML, media_type="text/html; charset=utf-8")


@app.get("/playground.html", include_in_schema=False)
def playground_html():
    return Response(content=_PLAYGROUND_HTML, media_type="text/html; charset=utf-8")


@app.get("/apitester.html", include_in_schema=False)
def apitester_html():
    return Response(content=_API_TESTER_HTML, media_type="text/html; charset=utf-8")


@app.get("/app.js", include_in_schema=False)
def app_js():
    return Response(
        content=_APP_JS.encode("utf-8"),
        media_type="application/javascript; charset=utf-8",
    )


app.mount("/", StaticFiles(directory=str(Config.STATIC_DIR)), name="static")
