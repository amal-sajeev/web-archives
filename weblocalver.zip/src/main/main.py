"""CTNA Evaluation Service — FastAPI application entry point.

Importing this module has no side effects beyond building the ``app`` object:
the registry, repository, runner and run-retention cleanup are created in the
FastAPI ``lifespan`` and stored on ``app.state`` (read by ``dependencies``).
Routes are declared in ``api_routes``; business logic lives in ``handlers``;
the error envelope lives in ``error_handlers`` and the request-id / cache /
compression middleware in ``http_middleware``.
"""

from __future__ import annotations

import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from fastapi import FastAPI
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.staticfiles import StaticFiles

from api_routes import OPENAPI_TAGS, build_router
from core.config import Config
from core.run_manager import run_manager
from core.runner import Runner
from core.structured_logging import get_logger
from error_handlers import register_error_handlers
from http_middleware import CacheControlMiddleware, RequestIdMiddleware, install_request_id_logging
from registry import Registry
from repository import build_repository
from repository.base import EvaluationRepository

_log = get_logger("eval_service.main")

# Responses smaller than this are sent uncompressed (gzip overhead outweighs the gain).
GZIP_MINIMUM_BYTES = 1024


def _apply_retention(repo: EvaluationRepository) -> None:
    """Delete runs older than RUN_RETENTION_DAYS (0 disables)."""
    if Config.RUN_RETENTION_DAYS <= 0:
        return
    try:
        deleted = repo.delete_old_runs(Config.RUN_RETENTION_DAYS)
    except Exception as exc:
        _log.warning("run_retention_failed", extra={"error_type": type(exc).__name__, "error": str(exc)})
        return
    if deleted:
        _log.info("run_retention_cleanup", extra={"deleted": deleted, "days": Config.RUN_RETENTION_DAYS})


@asynccontextmanager
async def lifespan(application: FastAPI) -> AsyncIterator[None]:
    """Build the shared services on startup and release them on shutdown."""
    registry = Registry().load()
    repo = build_repository()
    application.state.registry = registry
    application.state.repo = repo
    application.state.runner = Runner(registry, repo)
    _apply_retention(repo)
    try:
        yield
    finally:
        # Cancel live runs first so each can still persist its "cancelled" record.
        cancelled = await run_manager.shutdown()
        if cancelled:
            _log.info("shutdown_cancelled_runs", extra={"cancelled": cancelled})
        repo.close()


def create_app() -> FastAPI:
    install_request_id_logging()
    application = FastAPI(
        title="CTNA Evaluation Service",
        version=Config.SERVICE_VERSION,
        description="Evaluates registered agents against golden datasets and stores the scored runs.",
        openapi_tags=OPENAPI_TAGS,
        lifespan=lifespan,
    )
    register_error_handlers(application)
    # Added innermost first: GZip -> cache policy -> request id (outermost).
    application.add_middleware(GZipMiddleware, minimum_size=GZIP_MINIMUM_BYTES)
    application.add_middleware(CacheControlMiddleware)
    application.add_middleware(RequestIdMiddleware)
    application.include_router(build_router())
    # Everything else (css/, js/, images...) is served straight from static/.
    application.mount("/", StaticFiles(directory=str(Config.STATIC_DIR), check_dir=False), name="static")
    return application


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=Config.PORT, root_path=os.getenv("ROOT_PATH", ""))
