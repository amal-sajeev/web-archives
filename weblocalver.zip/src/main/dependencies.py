"""FastAPI dependency providers.

The lifespan in ``main`` builds the registry, repository and runner once and
stores them on ``app.state``; these providers hand them to route handlers.
Tests swap them with ``app.dependency_overrides``. The ``*Dep`` aliases carry
the ``Depends`` marker inside ``Annotated`` so handlers stay directly callable
with explicit arguments.
"""

from __future__ import annotations

import logging
from typing import Annotated

from fastapi import Depends, Request

from core.runner import Runner
from core.structured_logging import get_logger as _get_logger
from registry import Registry
from repository.base import EvaluationRepository

_API_LOGGER = "eval_service.api"


def get_registry(request: Request) -> Registry:
    return request.app.state.registry


def get_repo(request: Request) -> EvaluationRepository:
    return request.app.state.repo


def get_runner(request: Request) -> Runner:
    return request.app.state.runner


def get_logger() -> logging.Logger:
    return _get_logger(_API_LOGGER)


RegistryDep = Annotated[Registry, Depends(get_registry)]
# Same provider; ``None`` is only ever seen by direct (non-HTTP) callers that omit it.
OptionalRegistryDep = Annotated[Registry | None, Depends(get_registry)]
RepoDep = Annotated[EvaluationRepository, Depends(get_repo)]
RunnerDep = Annotated[Runner, Depends(get_runner)]
LoggerDep = Annotated[logging.Logger, Depends(get_logger)]
