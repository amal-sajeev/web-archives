# Configuration System

The evaluation service uses **YAML-based environment-specific configuration** with no .env dependency.

## Overview

Configuration is driven by the `ENV_NAME` environment variable:

```
ENV_NAME=dev    → loads config/dev/environment.yaml
ENV_NAME=uat    → loads config/uat/environment.yaml
ENV_NAME=prod   → loads config/prod/environment.yaml
```

## Architecture

```
config/
├── app.yaml                    # Template with all config keys
├── dev/
│   └── environment.yaml        # Development values
├── uat/
│   └── environment.yaml        # UAT values
└── prod/
    └── environment.yaml        # Production values
```

## Configuration Precedence

1. **YAML** (primary): `config/{ENV_NAME}/environment.yaml`
2. **Env vars** (override): Direct env vars like `JUDGE_PROJECT_NAME` for testing
3. **Defaults** (fallback): Hardcoded in `core/config.py`

## How It Works

### Startup

1. Kubernetes (or local dev) sets `ENV_NAME=uat` (via ConfigMap or manually)
2. Service starts; `core/config.py` initializes:
   - Calls `_load_yaml_config()` → reads `config/uat/environment.yaml`
   - All `{env_*}` placeholders in `app.yaml` are resolved from the YAML
   - Direct env vars can override any YAML value (for testing/CI)
3. Service runs with fully resolved configuration

### Deployment

**Kubernetes**: ConfigMap/Secret injection sets `ENV_NAME`:

```yaml
env:
  - name: ENV_NAME
    value: uat
  - name: PROJECT_NAME    # Direct env var override (optional)
    valueFrom:
      secretKeyRef:
        name: vertex-config
        key: project-id
```

**Local Development**: Two options:

```bash
# Option 1: Use YAML config
export ENV_NAME=dev
python -m src.main.main

# Option 2: Manual env vars (no YAML needed)
export PROJECT_NAME="my-project"
export PROJECT_LOCATION="us-central1"
python -m src.main.main
```

## Configuration Keys

See [config/app.yaml](app.yaml) for the complete template and [config/dev/environment.yaml](dev/environment.yaml) for an example.

### Judge / Vertex

```yaml
judge:
  project_name: "my-project"        # Vertex project ID
  project_location: "us-central1"    # Vertex region
  model: "gemini-2.5-pro"            # LLM model for evaluation
  temperature: "0"                   # Judge strictness (0=deterministic)
  max_retries: "2"                   # Transient error retries
```

### Database

```yaml
database:
  url: "postgresql://..."            # SQLAlchemy connection string
  instance_connection_name: "..."    # Cloud SQL instance (for Cloud SQL Proxy)
  name: "evaldb"                     # Database name
  schema: "public"                   # Schema name
  user: "monitoring_user"            # Username
  password_secret: "..."             # Google Secret Manager path (or empty)
  allow_sqlite_fallback: "true"      # Fall back to SQLite if Postgres fails
```

**Secrets**: Store sensitive values in Google Secret Manager and reference by path:

```yaml
database:
  password_secret: "projects/my-project/secrets/db-password/versions/latest"
```

The code calls `Config.resolve_secret()` to fetch from Secret Manager at runtime.

### Agent Service Integration

```yaml
agent_service:
  base_url: "http://localhost:4000"  # Target agent endpoint
```

### Metrics Source

```yaml
metrics:
  source: "stub"              # "stub" | "http" | "capture"
  api_base: ""                # For "http" mode: external metrics API
```

### Security

```yaml
security:
  exclude_tls: "false"        # TLS certificate validation
```

## Adding a New Environment

1. Create `config/{env_name}/environment.yaml` (copy from `dev/` or `uat/`)
2. Update values for your environment
3. Set `ENV_NAME={env_name}` at deployment time
4. No code changes needed

## Troubleshooting

### Config not loading

Check logs for:
```
Loaded config from config/uat/environment.yaml
```

If missing, `ENV_NAME` is not set or file doesn't exist.

### Using defaults instead of YAML

Fallback to defaults means either:
- `ENV_NAME` is empty
- `config/{ENV_NAME}/environment.yaml` doesn't exist
- Key not found in YAML → falls back to hardcoded default

### Override for testing

To override a YAML value for a single run:

```bash
export ENV_NAME=dev
export JUDGE_MODEL="gemini-2.0-flash"  # Override from YAML
python -m src.main.main
```

Env var `JUDGE_MODEL` takes precedence over YAML `judge.model`.

## No .env Dependency

- ❌ No `.env` file needed
- ❌ No `python-dotenv` package (removed from requirements.txt)
- ✅ Clean separation: YAML for config, env vars for secrets/overrides
- ✅ Same pattern across all environments (dev/uat/prod)
