"""Run-summary aggregation (``GET /api/runs/summary``) shared by the SQL backends.

One statement returns a single row: the status counts and mean score over the
filtered runs, plus the newest filtered run (``latest_*`` columns) and the run
before it for the same agent (``previous_*`` columns). Only the dialect
fragments differ between SQLite and Postgres (see ``ListRunsDialect``).

``previous`` honours the ``dataset_id`` filter (so the two runs are comparable)
but not ``since``: the run before the window is still the right comparison point.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from core.run_builder import CANCELLED_DETAIL

from ._sql import ERROR_STATUS, ITEM_FIELDS, RUNS_TABLE, ListRunsDialect

LATEST_PREFIX = "latest"
PREVIOUS_PREFIX = "previous"
COUNT_FIELDS = ("total", "passed", "failed", "errored", "cancelled")

_STATUS_PARAMS = {
    "st_pass": "PASS",
    "st_fail": "FAIL",
    "st_error": f"{ERROR_STATUS}%",
    "cancelled": CANCELLED_DETAIL,
}

_TOTALS_SQL = (
    "SELECT COUNT(*) AS total, "
    "COALESCE(SUM(CASE WHEN status = :st_pass THEN 1 ELSE 0 END), 0) AS passed, "
    "COALESCE(SUM(CASE WHEN status = :st_fail THEN 1 ELSE 0 END), 0) AS failed, "
    "COALESCE(SUM(CASE WHEN status LIKE :st_error AND COALESCE(error_detail, '') <> :cancelled "
    "THEN 1 ELSE 0 END), 0) AS errored, "
    "COALESCE(SUM(CASE WHEN status LIKE :st_error AND error_detail = :cancelled THEN 1 ELSE 0 END), 0) AS cancelled, "
    "AVG(CASE WHEN status NOT LIKE :st_error THEN weighted_score END) AS average_score "
    "FROM filtered"
)

_NEWEST_FIRST = "ORDER BY creation_ts DESC, eval_execution_id DESC LIMIT 1"
_OLDER_THAN_LATEST = (
    "agent_id = (SELECT agent_id FROM latest) AND ("
    "creation_ts < (SELECT creation_ts FROM latest) OR ("
    "creation_ts = (SELECT creation_ts FROM latest) AND eval_execution_id < (SELECT run_id FROM latest)))"
)


def _where(conditions: list[str]) -> str:
    return f" WHERE {' AND '.join(conditions)}" if conditions else ""


def _prefixed(alias: str, prefix: str) -> str:
    return ", ".join(f"{alias}.{field} AS {prefix}_{field}" for field in ITEM_FIELDS)


def build_run_summary_query(
    dialect: ListRunsDialect,
    *,
    agent_id: str | None = None,
    dataset_id: str | None = None,
    since: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """Return ``(sql, named_params)`` for the single-row run summary."""
    params: dict[str, Any] = dict(_STATUS_PARAMS)
    window: list[str] = []
    comparable: list[str] = []
    if agent_id:
        window.append("agent_id = :agent_id")
        params["agent_id"] = agent_id
    if dataset_id:
        window.append("dataset_id = :dataset_id")
        comparable.append("dataset_id = :dataset_id")
        params["dataset_id"] = dataset_id
    if since:
        window.append("creation_ts >= :since")
        params["since"] = dialect.ts_bind(since)
    items = dialect.item_columns()
    sql = (
        f"WITH filtered AS (SELECT status, weighted_score, {dialect.error_detail_sql} AS error_detail "  # noqa: S608
        f"FROM {RUNS_TABLE}{_where(window)}), "
        f"totals AS ({_TOTALS_SQL}), "
        f"latest AS (SELECT {items} FROM {RUNS_TABLE}{_where(window)} {_NEWEST_FIRST}), "
        f"previous AS (SELECT {items} FROM {RUNS_TABLE}{_where([*comparable, _OLDER_THAN_LATEST])} {_NEWEST_FIRST}) "
        f"SELECT t.*, {_prefixed('l', LATEST_PREFIX)}, {_prefixed('p', PREVIOUS_PREFIX)} "
        "FROM totals t LEFT JOIN latest l ON 1 = 1 LEFT JOIN previous p ON 1 = 1"
    )
    return sql, params


def _item(row: Mapping[str, Any], prefix: str, convert_ts: Callable[[Any], Any]) -> dict[str, Any] | None:
    if row.get(f"{prefix}_run_id") is None:
        return None
    item = {field: row.get(f"{prefix}_{field}") for field in ITEM_FIELDS}
    item["creation_ts"] = convert_ts(item["creation_ts"])
    return item


def summary_from_row(row: Mapping[str, Any], convert_ts: Callable[[Any], Any] = str) -> dict[str, Any]:
    """Map the summary row onto the response shape (counts are ints, the mean a float or None)."""
    average = row.get("average_score")
    return {
        **{field: int(row.get(field) or 0) for field in COUNT_FIELDS},
        "average_score": float(average) if average is not None else None,
        LATEST_PREFIX: _item(row, LATEST_PREFIX, convert_ts),
        PREVIOUS_PREFIX: _item(row, PREVIOUS_PREFIX, convert_ts),
    }
