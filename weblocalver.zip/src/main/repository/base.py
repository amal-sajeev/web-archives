"""Abstract persistence interface implemented by the SQLite and CloudSQL backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from core.models import CreatedBy, RunRecord

from ._summary_fallback import summarize_repository


class EvaluationRepository(ABC):
    """All backends (SQLite, CloudSQL) implement this identical surface."""

    @abstractmethod
    def init_schema(self) -> None:
        ...

    @abstractmethod
    def save_run(self, run: RunRecord) -> None:
        ...

    @abstractmethod
    def get_run(self, run_id: str) -> RunRecord | None:
        ...

    @abstractmethod
    def list_runs(
        self,
        agent_id: str | None = None,
        limit: int = 50,
        before: str | None = None,
        status: str | None = None,
        dataset_id: str | None = None,
        before_id: str | None = None,
    ) -> list[dict]:
        """List run summaries, newest first (``creation_ts`` DESC, id DESC).

        Keyset pagination: ``before`` is the ``creation_ts`` of the last row of the
        previous page and ``before_id`` its ``run_id``. With only ``before`` the
        page holds runs strictly older than that timestamp. Every row carries
        ``case_count``, ``passed_case_count`` and ``error_detail``.
        """
        ...

    def run_summary(
        self,
        agent_id: str | None = None,
        dataset_id: str | None = None,
        since: str | None = None,
    ) -> dict[str, Any]:
        """Status counts, mean score and the latest/previous run for the filtered runs.

        Returns ``{total, passed, failed, errored, cancelled, average_score,
        latest, previous}``; ``average_score`` ignores ERROR runs and is None when
        there are none, ``latest``/``previous`` are ``list_runs`` rows or None, and
        ``previous`` is the run before ``latest`` for the same agent. SQL backends
        override this with a single query; the default pages through ``list_runs``.
        """
        return summarize_repository(self, agent_id=agent_id, dataset_id=dataset_id, since=since)

    @abstractmethod
    def get_baseline(
        self,
        agent_id: str,
        dataset_id: str,
        dataset_version: str,
        metric: str,
    ) -> float | None:
        ...

    @abstractmethod
    def set_baseline(
        self,
        agent_id: str,
        dataset_id: str,
        dataset_version: str,
        metric: str,
        value: float,
        created_by: CreatedBy,
    ) -> None:
        ...

    def delete_old_runs(self, days: int) -> int:
        """Delete runs older than ``days`` days. Returns the number deleted.

        Default no-op; backends that support it override this.
        """
        return 0

    def ping(self) -> bool:
        """Return True when the backing store answers a trivial query."""
        return True

    def close(self) -> None:
        """Release pooled connections/resources. Default no-op."""
        return None
