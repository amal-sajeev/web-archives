"""Abstract persistence interface — SQLite now, CloudSQL later."""

from __future__ import annotations

from abc import ABC, abstractmethod

from models import CreatedBy, RunRecord


class EvaluationRepository(ABC):
    """All backends (SQLite, CloudSQL) implement this identical surface."""

    @abstractmethod
    def init_schema(self) -> None:
        ...

    @abstractmethod
    def save_run(self, run: RunRecord) -> None:
        ...

    @abstractmethod
    def get_run(self, run_id: str) -> RunRecord | None:
        ...

    @abstractmethod
    def list_runs(
        self,
        agent_id: str | None = None,
        limit: int = 50,
        before: str | None = None,
        status: str | None = None,
        dataset_id: str | None = None,
    ) -> list[dict]:
        """List run summaries, newest first.

        ``before`` is an ISO timestamp cursor: only runs with ``creation_ts``
        strictly less than this value are returned. Pass the ``creation_ts`` of
        the last run in a page to fetch the next page.
        """
        ...

    @abstractmethod
    def get_baseline(
        self,
        agent_id: str,
        dataset_id: str,
        dataset_version: str,
        metric: str,
    ) -> float | None:
        ...

    @abstractmethod
    def set_baseline(
        self,
        agent_id: str,
        dataset_id: str,
        dataset_version: str,
        metric: str,
        value: float,
        created_by: CreatedBy,
    ) -> None:
        ...

    def delete_old_runs(self, days: int) -> int:
        """Delete runs older than ``days`` days. Returns the number deleted.

        Default no-op; backends that support it override this.
        """
        return 0

