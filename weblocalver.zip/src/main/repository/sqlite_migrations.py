"""SQLite DDL and legacy-schema migrations.

All functions take an open connection that is already inside a transaction
(``SqliteRepository.init_schema`` wraps them in ``BEGIN IMMEDIATE`` / ``COMMIT``),
so a failed migration rolls back completely. Only ``conn.execute`` is used here:
``executescript`` would commit the surrounding transaction.
"""

from __future__ import annotations

import sqlite3

from ._sql import BASELINES_TABLE, RUNS_TABLE

_RUNS_DDL = f"""
CREATE TABLE IF NOT EXISTS {RUNS_TABLE} (
    eval_execution_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    weighted_score REAL,
    weighted_delta REAL,
    status VARCHAR(20) NOT NULL,
    creation_ts TIMESTAMP NOT NULL,
    created_by TEXT NOT NULL,
    detail_json TEXT NOT NULL
)"""

_BASELINES_DDL = f"""
CREATE TABLE IF NOT EXISTS {BASELINES_TABLE} (
    eval_baseline_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    baseline_metric_name TEXT NOT NULL,
    baseline_metric_value REAL NOT NULL,
    created_ts TIMESTAMP NOT NULL,
    created_by TEXT NOT NULL,
    UNIQUE (agent_id, dataset_id, dataset_version, baseline_metric_name)
)"""

# Canonical timestamp (see _sql.to_utc_iso): YYYY-MM-DDTHH:MM:SS.mmm+00:00
_CANONICAL_TS_SQL = "strftime('%Y-%m-%dT%H:%M:%f', {col}) || '+00:00'"
_CANONICAL_TS_LIKE = "____-__-__T__:__:__.___+00:00"
_DEFAULT_CREATED_BY = "'DEVELOPER'"


def schema_statements() -> list[str]:
    return [_RUNS_DDL, _BASELINES_DDL]


def _table_columns(conn: sqlite3.Connection, table_name: str) -> dict[str, sqlite3.Row]:
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return {row["name"]: row for row in rows}


def _col_or(cols: dict[str, sqlite3.Row], name: str, fallback: str) -> str:
    return name if name in cols else fallback


def _migrate_eval_execution(conn: sqlite3.Connection) -> None:
    cols = _table_columns(conn, RUNS_TABLE)
    if "eval_execution_id" in cols and "run_id" not in cols:
        return
    id_expr = _col_or(cols, "eval_execution_id", "run_id")
    creation_expr = _col_or(cols, "creation_ts", "CURRENT_TIMESTAMP")
    created_by_expr = _col_or(cols, "created_by", _DEFAULT_CREATED_BY)
    detail_expr = _col_or(cols, "detail_json", "'{}'")
    status_expr = _col_or(cols, "status", "'ERROR'")

    conn.execute(f"ALTER TABLE {RUNS_TABLE} RENAME TO {RUNS_TABLE}__old")
    conn.execute(_RUNS_DDL)
    conn.execute(
        f"""
        INSERT INTO {RUNS_TABLE} (
            eval_execution_id, agent_id, dataset_id, dataset_version,
            weighted_score, weighted_delta, status, creation_ts, created_by, detail_json
        )
        SELECT
            {id_expr}, agent_id, dataset_id, dataset_version, weighted_score, weighted_delta,
            CASE
                WHEN {status_expr} IS NULL OR TRIM({status_expr}) = '' THEN 'ERROR'
                WHEN UPPER({status_expr}) LIKE 'PASS%' THEN 'PASS'
                WHEN UPPER({status_expr}) LIKE 'FAIL%' THEN 'FAIL'
                ELSE 'ERROR'
            END,
            COALESCE(NULLIF(TRIM(CAST({creation_expr} AS TEXT)), ''), CURRENT_TIMESTAMP),
            COALESCE(NULLIF(TRIM(CAST({created_by_expr} AS TEXT)), ''), {_DEFAULT_CREATED_BY}),
            COALESCE({detail_expr}, '{{}}')
        FROM {RUNS_TABLE}__old
        """  # noqa: S608 - identifiers come from PRAGMA table_info, not user input
    )
    conn.execute(f"DROP TABLE {RUNS_TABLE}__old")


def _migrate_eval_baseline(conn: sqlite3.Connection) -> None:
    cols = _table_columns(conn, BASELINES_TABLE)
    if "eval_baseline_id" in cols and str(cols["created_ts"]["type"]).upper() == "TIMESTAMP":
        return
    dataset_expr = _col_or(cols, "dataset_id", "'legacy'")
    metric_expr = _col_or(cols, "baseline_metric_name", "metric")
    value_expr = _col_or(cols, "baseline_metric_value", "baseline_value")
    created_ts_expr = _col_or(cols, "created_ts", "CURRENT_TIMESTAMP")
    created_by_expr = _col_or(cols, "created_by", _DEFAULT_CREATED_BY)

    conn.execute(f"ALTER TABLE {BASELINES_TABLE} RENAME TO {BASELINES_TABLE}__old")
    conn.execute(_BASELINES_DDL)
    conn.execute(
        f"""
        INSERT OR IGNORE INTO {BASELINES_TABLE} (
            eval_baseline_id, agent_id, dataset_id, dataset_version,
            baseline_metric_name, baseline_metric_value, created_ts, created_by
        )
        SELECT
            lower(hex(randomblob(16))),
            agent_id,
            COALESCE(NULLIF(TRIM(CAST({dataset_expr} AS TEXT)), ''), 'legacy'),
            dataset_version,
            {metric_expr},
            {value_expr},
            COALESCE(NULLIF(TRIM(CAST({created_ts_expr} AS TEXT)), ''), CURRENT_TIMESTAMP),
            COALESCE(NULLIF(TRIM(CAST({created_by_expr} AS TEXT)), ''), {_DEFAULT_CREATED_BY})
        FROM {BASELINES_TABLE}__old
        ORDER BY CAST({created_ts_expr} AS TEXT) DESC
        """  # noqa: S608 - identifiers come from PRAGMA table_info, not user input
    )
    conn.execute(f"DROP TABLE {BASELINES_TABLE}__old")


def _normalise_timestamps(conn: sqlite3.Connection, table: str, column: str) -> None:
    """Rewrite any non-canonical (legacy) timestamps into the canonical UTC format."""
    canonical = _CANONICAL_TS_SQL.format(col=column)
    conn.execute(
        f"UPDATE {table} SET {column} = {canonical} "  # noqa: S608 - constant identifiers
        f"WHERE {column} NOT LIKE '{_CANONICAL_TS_LIKE}' AND strftime('%s', {column}) IS NOT NULL"
    )


def migrate_legacy_tables(conn: sqlite3.Connection) -> None:
    _migrate_eval_execution(conn)
    _migrate_eval_baseline(conn)
    _normalise_timestamps(conn, RUNS_TABLE, "creation_ts")
    _normalise_timestamps(conn, BASELINES_TABLE, "created_ts")
