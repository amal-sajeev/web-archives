"""Classify repository failures that mean "the store is unreachable right now".

Connection refusals, locked/busy SQLite files, pool timeouts and dropped
Postgres connections are transient: the API answers them with 503 (and a
``Retry-After``) instead of a generic 500, so clients and load balancers can
retry. Programming errors (bad SQL, integrity violations) are not listed here
and stay 500.
"""

from __future__ import annotations

import sqlite3

from sqlalchemy import exc as sa_exc

UNAVAILABLE_ERRORS: tuple[type[BaseException], ...] = (
    sqlite3.OperationalError,
    sa_exc.OperationalError,
    sa_exc.InterfaceError,
    sa_exc.TimeoutError,
)

UNAVAILABLE_DETAIL = "Run storage is temporarily unavailable; retry shortly."
# Seconds a client should wait before retrying (sent as ``Retry-After``).
RETRY_AFTER_SECONDS = "5"


def is_repository_unavailable(exc: BaseException) -> bool:
    """True when ``exc`` is a transient storage-connectivity failure."""
    return isinstance(exc, UNAVAILABLE_ERRORS)
