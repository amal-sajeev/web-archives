"""CloudSQL (Postgres) implementation of EvaluationRepository.

Mirrors the SQLite backend's surface but talks to Google Cloud SQL via SQLAlchemy
and the pg8000 driver (engine/transport details live in ``_pg_engine``). The
schema itself is owned by Liquibase; ``init_schema`` only verifies it exists.
Writes use ``INSERT ... ON CONFLICT ... DO UPDATE`` (SQLite's ``INSERT OR REPLACE``).
"""

from __future__ import annotations

import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Connection

from core.models import RunRecord
from core.structured_logging import get_logger

from ._pg_engine import PgEngine, set_search_path, to_aware_iso, to_naive_utc
from ._sql import BASELINES_TABLE, RUNS_TABLE, ListRunsDialect, build_list_runs_query
from ._summary_sql import build_run_summary_query, summary_from_row
from .base import EvaluationRepository

_log = get_logger("eval_service.repository.postgres")

_DIALECT = ListRunsDialect(
    case_count_sql="COALESCE(jsonb_array_length(detail_json -> 'case_results'), 0)",
    passed_count_sql=(
        "(SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(detail_json -> 'case_results', '[]'::jsonb)) AS c "
        "WHERE (c ->> 'passed')::boolean)"
    ),
    error_detail_sql="(detail_json ->> 'error_detail')",
    ts_bind=to_naive_utc,
)

_UPSERT_RUN = text(
    f"""INSERT INTO {RUNS_TABLE}
       (eval_execution_id, agent_id, dataset_id, dataset_version,
        weighted_score, weighted_delta, status, creation_ts, created_by, detail_json)
       VALUES (:run_id, :agent_id, :dataset_id, :dataset_version,
               :weighted_score, :weighted_delta, :status, :creation_ts, :created_by,
               CAST(:detail_json AS JSONB))
       ON CONFLICT (eval_execution_id) DO UPDATE SET
           agent_id = EXCLUDED.agent_id,
           dataset_id = EXCLUDED.dataset_id,
           dataset_version = EXCLUDED.dataset_version,
           weighted_score = EXCLUDED.weighted_score,
           weighted_delta = EXCLUDED.weighted_delta,
           status = EXCLUDED.status,
           creation_ts = EXCLUDED.creation_ts,
           created_by = EXCLUDED.created_by,
           detail_json = EXCLUDED.detail_json"""  # noqa: S608 - constant table name
)

_UPSERT_BASELINE = text(
    f"""INSERT INTO {BASELINES_TABLE}
       (eval_baseline_id, agent_id, dataset_id, dataset_version, baseline_metric_name,
        baseline_metric_value, created_ts, created_by)
       VALUES (:id, :a, :d, :v, :m, :val, :created_ts, :created_by)
       ON CONFLICT (agent_id, dataset_id, dataset_version, baseline_metric_name)
       DO UPDATE SET
           baseline_metric_value = EXCLUDED.baseline_metric_value,
           created_ts = EXCLUDED.created_ts,
           created_by = EXCLUDED.created_by"""  # noqa: S608 - constant table name
)


class CloudSqlRepository(EvaluationRepository):
    """Postgres-backed repository (Cloud SQL Connector or Auth Proxy TCP)."""

    def __init__(self) -> None:
        self._pg = PgEngine()

    @contextmanager
    def _tx(self) -> Iterator[Connection]:
        with self._pg.engine.begin() as conn:
            set_search_path(conn, self._pg.schema)
            yield conn

    def init_schema(self) -> None:
        """Verify the Liquibase-owned schema exists (with start-up retries)."""
        missing = self._pg.missing_tables((RUNS_TABLE, BASELINES_TABLE))
        if missing:
            raise RuntimeError(
                "CloudSQL schema is missing tables "
                f"{missing} in schema '{self._pg.schema or 'public'}'. The schema is managed "
                "by Liquibase — apply it before starting the service:\n"
                "  cd dbaware-monitoring-liquibase\n"
                "  mvn -s settings.xml org.liquibase:liquibase-maven-plugin:update "
                "(contexts=DBAWARE_MONITORING; see env_config/ and the CICD workflow)"
            )

    def ping(self) -> bool:
        try:
            with self._tx() as conn:
                conn.execute(text("SELECT 1")).scalar()
        except Exception:
            _log.warning("cloudsql_ping_failed", exc_info=True)
            return False
        return True

    def close(self) -> None:
        self._pg.dispose()

    def save_run(self, run: RunRecord) -> None:
        with self._tx() as conn:
            conn.execute(
                _UPSERT_RUN,
                {
                    "run_id": run.run_id, "agent_id": run.agent_id,
                    "dataset_id": run.dataset_id, "dataset_version": run.dataset_version,
                    "weighted_score": run.weighted_score, "weighted_delta": run.weighted_delta,
                    "status": run.status, "creation_ts": to_naive_utc(run.creation_ts),
                    "created_by": run.created_by,
                    "detail_json": run.model_dump_json(),
                },
            )

    def get_run(self, run_id: str) -> RunRecord | None:
        with self._tx() as conn:
            row = conn.execute(
                text(f"SELECT detail_json FROM {RUNS_TABLE} WHERE eval_execution_id = :run_id"),  # noqa: S608
                {"run_id": run_id},
            ).fetchone()
        if not row:
            return None
        detail = row[0]
        if isinstance(detail, str):
            return RunRecord.model_validate_json(detail)
        return RunRecord.model_validate(detail)

    def list_runs(
        self,
        agent_id: str | None = None,
        limit: int = 50,
        before: str | None = None,
        status: str | None = None,
        dataset_id: str | None = None,
        before_id: str | None = None,
    ) -> list[dict]:
        query, params = build_list_runs_query(
            _DIALECT, agent_id=agent_id, limit=limit, before=before,
            before_id=before_id, status=status, dataset_id=dataset_id,
        )
        with self._tx() as conn:
            rows = conn.execute(text(query), params).mappings().all()
        return [{**dict(r), "creation_ts": to_aware_iso(r["creation_ts"])} for r in rows]

    def run_summary(
        self,
        agent_id: str | None = None,
        dataset_id: str | None = None,
        since: str | None = None,
    ) -> dict[str, Any]:
        query, params = build_run_summary_query(_DIALECT, agent_id=agent_id, dataset_id=dataset_id, since=since)
        with self._tx() as conn:
            row = conn.execute(text(query), params).mappings().one()
        return summary_from_row(dict(row), convert_ts=to_aware_iso)

    def get_baseline(self, agent_id: str, dataset_id: str, dataset_version: str, metric: str) -> float | None:
        with self._tx() as conn:
            row = conn.execute(
                text(
                    f"SELECT baseline_metric_value FROM {BASELINES_TABLE} "  # noqa: S608
                    "WHERE agent_id=:a AND dataset_id=:d AND dataset_version=:v AND baseline_metric_name=:m"
                ),
                {"a": agent_id, "d": dataset_id, "v": dataset_version, "m": metric},
            ).fetchone()
        return float(row[0]) if row else None

    def set_baseline(
        self,
        agent_id: str,
        dataset_id: str,
        dataset_version: str,
        metric: str,
        value: float,
        created_by: str,
    ) -> None:
        with self._tx() as conn:
            conn.execute(
                _UPSERT_BASELINE,
                {
                    "id": uuid.uuid4().hex, "a": agent_id, "d": dataset_id, "v": dataset_version,
                    "m": metric, "val": value, "created_ts": to_naive_utc(datetime.now(UTC)),
                    "created_by": created_by,
                },
            )

    def delete_old_runs(self, days: int) -> int:
        if days <= 0:
            return 0
        cutoff = to_naive_utc(datetime.now(UTC) - timedelta(days=days))
        with self._tx() as conn:
            result = conn.execute(
                text(f"DELETE FROM {RUNS_TABLE} WHERE creation_ts < :cutoff"),  # noqa: S608
                {"cutoff": cutoff},
            )
            return result.rowcount
