"""Engine/connection plumbing for the CloudSQL (Postgres) repository.

Two transports are supported:

* **Cloud SQL Python Connector** (default) - IAM/ADC auth, used in GKE with
  Workload Identity Federation.
* **TCP via the Cloud SQL Auth Proxy** (set ``DB_HOST``) - for local dev behind a
  corporate HTTP proxy; the app connects to the proxy's local listener.

Passwords are never stored in the repo; they come from env or Secret Manager.
"""

from __future__ import annotations

import re
import time
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Connection, Engine

from core.config import Config
from core.structured_logging import get_logger

from ._sql import parse_utc

_log = get_logger("eval_service.repository.postgres")

POOL_SIZE = 5
POOL_MAX_OVERFLOW = 5
POOL_TIMEOUT_SECONDS = 30
POOL_RECYCLE_SECONDS = 1800

VERIFY_ATTEMPTS_TCP = 12
VERIFY_ATTEMPTS_CONNECTOR = 3
VERIFY_DELAY_SECONDS = 5

_SCHEMA_IDENTIFIER = re.compile(r"^[A-Za-z_]\w{0,62}$")
_DEFAULT_SCHEMA = "public"


def configured_schema() -> str | None:
    """Return the validated non-default schema name, or None for ``public``/unset."""
    schema = Config.DB_SCHEMA
    if not schema or schema == _DEFAULT_SCHEMA:
        return None
    if not _SCHEMA_IDENTIFIER.match(schema):
        raise RuntimeError(f"DB_SCHEMA '{schema}' is not a valid Postgres identifier.")
    return schema


def set_search_path(conn: Connection, schema: str | None) -> None:
    """Scope the search_path to the current transaction only."""
    if schema:
        conn.execute(text(f'SET LOCAL search_path TO "{schema}"'))


def _connector_factory() -> Any:
    import google.auth
    from google.cloud.sql.connector import Connector, IPTypes

    if not Config.DB_INSTANCE_CONNECTION_NAME:
        raise RuntimeError(
            "CloudSQL Connector mode requires DB_INSTANCE_CONNECTION_NAME. "
            "Set it, or set DB_HOST to use the Cloud SQL Auth Proxy instead."
        )
    try:
        google.auth.default()
    except Exception as exc:
        raise RuntimeError(
            "No Application Default Credentials available for CloudSQL. "
            "Locally run: gcloud auth application-default login. In GKE, "
            "ensure the Workload Identity Federation credential config is "
            "mounted and GOOGLE_APPLICATION_CREDENTIALS points at it."
        ) from exc
    ip_type = IPTypes.PRIVATE if Config.DB_IP_TYPE.upper() == "PRIVATE" else IPTypes.PUBLIC
    return Connector(ip_type=ip_type)


class PgEngine:
    """Owns the SQLAlchemy engine (and Cloud SQL Connector, if used)."""

    def __init__(self) -> None:
        if not Config.DB_NAME:
            raise RuntimeError("CloudSQL requires DB_NAME. Set it in the environment (see .env.example).")
        self.use_tcp = bool(Config.DB_HOST)
        self.schema = configured_schema()
        self._connector = None if self.use_tcp else _connector_factory()
        self._password = Config.resolve_secret(Config.DB_PASSWORD, Config.DB_PASSWORD_SECRET)
        if not self._password:
            raise RuntimeError(
                "No DB_PASSWORD (or DB_PASSWORD_SECRET) provided for the runtime "
                "CloudSQL user. Passwords must come from env/GSM, never the repo."
            )
        self.engine: Engine = create_engine(
            "postgresql+pg8000://",
            creator=self._connect,
            pool_pre_ping=True,
            pool_size=POOL_SIZE,
            max_overflow=POOL_MAX_OVERFLOW,
            pool_timeout=POOL_TIMEOUT_SECONDS,
            pool_recycle=POOL_RECYCLE_SECONDS,
        )

    def _connect(self) -> Any:
        if self.use_tcp:
            import pg8000.dbapi

            return pg8000.dbapi.connect(
                host=Config.DB_HOST,
                port=Config.DB_PORT,
                user=Config.DB_USER,
                password=self._password,
                database=Config.DB_NAME,
            )
        return self._connector.connect(
            Config.DB_INSTANCE_CONNECTION_NAME,
            "pg8000",
            user=Config.DB_USER,
            password=self._password,
            db=Config.DB_NAME,
        )

    def missing_tables(self, tables: tuple[str, ...]) -> list[str]:
        """Return the tables that do not exist, retrying while the DB comes up."""
        attempts = VERIFY_ATTEMPTS_TCP if self.use_tcp else VERIFY_ATTEMPTS_CONNECTOR
        last_error: Exception | None = None
        for attempt in range(1, attempts + 1):
            if attempt > 1:
                time.sleep(VERIFY_DELAY_SECONDS)
            try:
                return self._check_tables(tables)
            except Exception as exc:
                last_error = exc
                _log.warning("cloudsql_verify_retry", extra={"attempt": attempt, "error_type": type(exc).__name__})
        raise RuntimeError(
            "Could not verify the CloudSQL schema. Ensure the Cloud SQL Auth "
            "Proxy is running and the Liquibase migration has been applied "
            "(see dbaware-evaluation-service-liquibase/). Original error: "
            f"{type(last_error).__name__}: {last_error}"
        ) from last_error

    def _check_tables(self, tables: tuple[str, ...]) -> list[str]:
        with self.engine.begin() as conn:
            set_search_path(conn, self.schema)
            return [
                tbl for tbl in tables
                if conn.execute(
                    text("SELECT to_regclass(:qualified)"),
                    {"qualified": f'"{self.schema}".{tbl}' if self.schema else tbl},
                ).scalar() is None
            ]

    def dispose(self) -> None:
        self.engine.dispose()
        if self._connector is not None:
            self._connector.close()
            self._connector = None


def to_naive_utc(value: str | datetime) -> datetime:
    """Bind value for the ``TIMESTAMP`` (without time zone, UTC) columns, at millisecond precision."""
    dt = parse_utc(value).replace(tzinfo=None)
    return dt.replace(microsecond=dt.microsecond // 1000 * 1000)


def to_aware_iso(value: Any) -> Any:
    """Render a DB timestamp as a tz-aware ISO-8601 UTC string."""
    if isinstance(value, datetime):
        dt = value if value.tzinfo else value.replace(tzinfo=UTC)
        timespec = "microseconds" if dt.microsecond % 1000 else "milliseconds"
        return dt.astimezone(UTC).isoformat(timespec=timespec)
    return value
