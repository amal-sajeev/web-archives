"""Persistence layer for the CTNA Evaluation Service.

`EvaluationRepository` is the swappable interface. `SqliteRepository` is the
local-dev/offline implementation; `CloudSqlRepository` is the CloudSQL (Postgres)
implementation. `build_repository()` selects one from `EVAL_DB_URL` without the
runner or scorers ever knowing which backend is active.
"""


from core.config import Config
from core.structured_logging import get_logger

from .base import EvaluationRepository
from .sqlite_repo import SqliteRepository

__all__ = [
    "EvaluationRepository",
    "SqliteRepository",
    "build_repository",
]

_log = get_logger("eval_service.repository")
_SQLITE_PREFIX = "sqlite:///"


def build_repository() -> EvaluationRepository:
    """Factory: choose a persistence backend from EVAL_DB_URL.

    - `sqlite:///path`         -> local SQLite (default, fully offline)
    - `postgresql[...]://...`  -> CloudSQL Postgres via the Cloud SQL Connector

    The Postgres deps and ADC are only touched on the postgres branch, so the
    offline path never needs them.
    """
    url = Config.DB_URL
    if url.startswith(_SQLITE_PREFIX):
        return _sqlite(url[len(_SQLITE_PREFIX):])
    if url.startswith("postgres"):  # postgresql:// or postgres://
        from .postgres_repo import CloudSqlRepository  # lazy: avoid pg deps offline
        cloud_repo: EvaluationRepository | None = None
        try:
            cloud_repo = CloudSqlRepository()
            cloud_repo.init_schema()
            return cloud_repo
        except Exception as exc:
            if cloud_repo is not None:
                cloud_repo.close()
            if not Config.ALLOW_SQLITE_FALLBACK:
                raise RuntimeError(
                    "CloudSQL repository initialization failed and SQLite fallback is disabled. "
                    "Set EVAL_ALLOW_SQLITE_FALLBACK=1 only for local offline debugging. "
                    f"Original error: {type(exc).__name__}: {exc}"
                ) from exc
            fallback_path = (Config.STATIC_DIR.parent.parent.parent / "eval_service.db").as_posix()
            _log.warning(
                "cloudsql_unavailable_sqlite_fallback",
                extra={"path": fallback_path, "error_type": type(exc).__name__, "error": str(exc)},
            )
            return _sqlite(fallback_path)
    raise NotImplementedError(
        f"Unsupported EVAL_DB_URL '{url}'. Use sqlite:/// for local/offline or "
        "postgresql:// for CloudSQL."
    )


def _sqlite(path: str) -> EvaluationRepository:
    repo = SqliteRepository(path)
    repo.init_schema()
    return repo
