"""Portable run summary built on ``list_runs`` for backends without SQL.

The SQLite and Postgres repositories override ``run_summary`` with one
aggregate query (``_summary_sql``). In-memory backends (the playground preview
repository, test doubles) inherit this version, which pages through
``list_runs`` newest-first and stops at the ``since`` boundary.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import datetime
from typing import TYPE_CHECKING, Any

from core.run_builder import CANCELLED_DETAIL

from ._sql import ERROR_STATUS, ITEM_FIELDS, parse_utc

if TYPE_CHECKING:
    from .base import EvaluationRepository

PAGE_SIZE = 500
_ERROR_DETAIL = "error_detail"


def _item(row: dict[str, Any] | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {field: row.get(field) for field in ITEM_FIELDS}


def _iter_rows(
    repo: EvaluationRepository, agent_id: str | None, dataset_id: str | None, since: datetime | None,
) -> Iterator[dict[str, Any]]:
    before: str | None = None
    before_id: str | None = None
    while True:
        page = repo.list_runs(
            agent_id=agent_id, dataset_id=dataset_id, limit=PAGE_SIZE, before=before, before_id=before_id,
        )
        for row in page:
            if since is not None and parse_utc(str(row["creation_ts"])) < since:
                return
            yield row
        if len(page) < PAGE_SIZE:
            return
        before, before_id = str(page[-1]["creation_ts"]), str(page[-1]["run_id"])


def _with_error_detail(repo: EvaluationRepository, row: dict[str, Any]) -> dict[str, Any]:
    """Fill ``error_detail`` for backends whose ``list_runs`` rows omit it (ERROR rows only)."""
    if _ERROR_DETAIL in row:
        return row
    detail = None
    if str(row.get("status") or "").startswith(ERROR_STATUS):
        run = repo.get_run(str(row["run_id"]))
        detail = run.error_detail if run is not None else None
    return {**row, _ERROR_DETAIL: detail}


def _bucket(row: dict[str, Any]) -> str:
    status = str(row.get("status") or "")
    if status == "PASS":
        return "passed"
    if status == "FAIL":
        return "failed"
    if status.startswith(ERROR_STATUS) and row.get(_ERROR_DETAIL) == CANCELLED_DETAIL:
        return "cancelled"
    return "errored"


def summarize_repository(
    repo: EvaluationRepository,
    agent_id: str | None = None,
    dataset_id: str | None = None,
    since: str | None = None,
) -> dict[str, Any]:
    """Same result shape as ``_summary_sql.summary_from_row``."""
    counts = {"total": 0, "passed": 0, "failed": 0, "errored": 0, "cancelled": 0}
    scores: list[float] = []
    latest: dict[str, Any] | None = None
    for raw in _iter_rows(repo, agent_id, dataset_id, parse_utc(since) if since else None):
        row = _with_error_detail(repo, raw)
        latest = latest or row
        bucket = _bucket(row)
        counts["total"] += 1
        counts[bucket] += 1
        if bucket in ("passed", "failed") and row.get("weighted_score") is not None:
            scores.append(float(row["weighted_score"]))
    previous = None
    if latest is not None:
        older = repo.list_runs(
            agent_id=latest["agent_id"], dataset_id=dataset_id, limit=1,
            before=str(latest["creation_ts"]), before_id=str(latest["run_id"]),
        )
        previous = _with_error_detail(repo, older[0]) if older else None
    return {
        **counts,
        "average_score": sum(scores) / len(scores) if scores else None,
        "latest": _item(latest),
        "previous": _item(previous),
    }
