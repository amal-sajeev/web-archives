"""SQLite implementation of EvaluationRepository (WAL-enabled).

Parses the `EVAL_DB_URL` (sqlite:///path). A CloudSQL implementation would live
alongside this file and be selected by `build_repository` on a postgres:// URL.
"""

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timedelta, UTC
from pathlib import Path

from models import RunRecord
from .base import EvaluationRepository


RUNS_TABLE = "eval_execution"
BASELINES_TABLE = "eval_baseline"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS eval_execution (
    eval_execution_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    weighted_score REAL,
    weighted_delta REAL,
    status VARCHAR(20) NOT NULL,
    creation_ts TIMESTAMP NOT NULL,
    created_by TEXT NOT NULL,
    detail_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS eval_baseline (
    eval_baseline_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    baseline_metric_name TEXT NOT NULL,
    baseline_metric_value REAL NOT NULL,
    created_ts TIMESTAMP NOT NULL,
    created_by TEXT NOT NULL,
    UNIQUE (agent_id, dataset_id, dataset_version, baseline_metric_name)
);
"""


class SqliteRepository(EvaluationRepository):
    def __init__(self, db_path: str):
        self._path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.row_factory = sqlite3.Row
        return conn

    def init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(_SCHEMA)
            self._migrate_eval_execution(conn)
            self._migrate_eval_baseline(conn)

    def _table_columns(self, conn: sqlite3.Connection, table_name: str) -> dict[str, sqlite3.Row]:
        rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
        return {row["name"]: row for row in rows}

    def _migrate_eval_execution(self, conn: sqlite3.Connection) -> None:
        cols = self._table_columns(conn, RUNS_TABLE)
        if "eval_execution_id" in cols and "run_id" not in cols:
            return

        id_expr = "eval_execution_id" if "eval_execution_id" in cols else "run_id"
        creation_expr = "creation_ts" if "creation_ts" in cols else "CURRENT_TIMESTAMP"
        created_by_expr = "created_by" if "created_by" in cols else "'DEVELOPER'"
        detail_expr = "detail_json" if "detail_json" in cols else "'{}'"
        status_expr = "status" if "status" in cols else "'ERROR'"

        conn.execute("ALTER TABLE eval_execution RENAME TO eval_execution__old")
        conn.executescript(_SCHEMA)
        conn.execute(
            f"""
            INSERT INTO eval_execution (
                eval_execution_id, agent_id, dataset_id, dataset_version,
                weighted_score, weighted_delta, status, creation_ts, created_by, detail_json
            )
            SELECT
                {id_expr},
                agent_id,
                dataset_id,
                dataset_version,
                weighted_score,
                weighted_delta,
                CASE
                    WHEN {status_expr} IS NULL OR TRIM({status_expr}) = '' THEN 'ERROR'
                    WHEN UPPER({status_expr}) LIKE 'PASS%' THEN 'PASS'
                    WHEN UPPER({status_expr}) LIKE 'FAIL%' THEN 'FAIL'
                    ELSE 'ERROR'
                END,
                COALESCE(NULLIF(TRIM(CAST({creation_expr} AS TEXT)), ''), CURRENT_TIMESTAMP),
                COALESCE(NULLIF(TRIM(CAST({created_by_expr} AS TEXT)), ''), 'DEVELOPER'),
                COALESCE({detail_expr}, '{{}}')
            FROM eval_execution__old
            """
        )
        conn.execute("DROP TABLE eval_execution__old")

    def _migrate_eval_baseline(self, conn: sqlite3.Connection) -> None:
        cols = self._table_columns(conn, BASELINES_TABLE)
        if "eval_baseline_id" in cols and str(cols["created_ts"]["type"]).upper() == "TIMESTAMP":
            return

        dataset_expr = "dataset_id" if "dataset_id" in cols else "'legacy'"
        metric_expr = "baseline_metric_name" if "baseline_metric_name" in cols else "metric"
        value_expr = "baseline_metric_value" if "baseline_metric_value" in cols else "baseline_value"
        created_ts_expr = "created_ts" if "created_ts" in cols else "CURRENT_TIMESTAMP"
        created_by_expr = "created_by" if "created_by" in cols else "'DEVELOPER'"

        conn.execute("ALTER TABLE eval_baseline RENAME TO eval_baseline__old")
        conn.executescript(_SCHEMA)
        conn.execute(
            f"""
            INSERT OR IGNORE INTO eval_baseline (
                eval_baseline_id,
                agent_id,
                dataset_id,
                dataset_version,
                baseline_metric_name,
                baseline_metric_value,
                created_ts,
                created_by
            )
            SELECT
                lower(hex(randomblob(16))),
                agent_id,
                COALESCE(NULLIF(TRIM(CAST({dataset_expr} AS TEXT)), ''), 'legacy'),
                dataset_version,
                {metric_expr},
                {value_expr},
                COALESCE(NULLIF(TRIM(CAST({created_ts_expr} AS TEXT)), ''), CURRENT_TIMESTAMP),
                COALESCE(NULLIF(TRIM(CAST({created_by_expr} AS TEXT)), ''), 'DEVELOPER')
            FROM eval_baseline__old
            ORDER BY CAST({created_ts_expr} AS TEXT) DESC
            """
        )
        conn.execute("DROP TABLE eval_baseline__old")

    def save_run(self, run: RunRecord) -> None:
        with self._connect() as conn:
            conn.execute(
                     f"""INSERT OR REPLACE INTO {RUNS_TABLE}
                                     (eval_execution_id, agent_id, dataset_id, dataset_version,
                    weighted_score, weighted_delta, status, creation_ts, created_by, detail_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    run.run_id, run.agent_id, run.dataset_id, run.dataset_version,
                    run.weighted_score, run.weighted_delta, run.status,
                    run.creation_ts, run.created_by, run.model_dump_json(),
                ),
            )

    def get_run(self, run_id: str) -> RunRecord | None:
        with self._connect() as conn:
            row = conn.execute(
                f"SELECT detail_json FROM {RUNS_TABLE} WHERE eval_execution_id = ?", (run_id,)
            ).fetchone()
        return RunRecord.model_validate_json(row["detail_json"]) if row else None

    def list_runs(
        self,
        agent_id: str | None = None,
        limit: int = 50,
        before: str | None = None,
        status: str | None = None,
        dataset_id: str | None = None,
    ) -> list[dict]:
        query = (
            "SELECT eval_execution_id AS run_id, agent_id, dataset_id, dataset_version, weighted_score, "
            f"weighted_delta, status, creation_ts, created_by FROM {RUNS_TABLE}"
        )
        params: list = []
        conditions: list[str] = []
        if agent_id:
            conditions.append("agent_id = ?")
            params.append(agent_id)
        if before:
            conditions.append("creation_ts < ?")
            params.append(before)
        if status:
            if status.startswith("ERROR"):
                conditions.append("status LIKE ?")
                params.append("ERROR%")
            else:
                conditions.append("status = ?")
                params.append(status)
        if dataset_id:
            conditions.append("dataset_id = ?")
            params.append(dataset_id)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY creation_ts DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def get_baseline(self, agent_id: str, dataset_id: str, dataset_version: str, metric: str) -> float | None:
        with self._connect() as conn:
            row = conn.execute(
                f"SELECT baseline_metric_value FROM {BASELINES_TABLE} "
                "WHERE agent_id=? AND dataset_id=? AND dataset_version=? AND baseline_metric_name=?",
                (agent_id, dataset_id, dataset_version, metric),
            ).fetchone()
        return float(row["baseline_metric_value"]) if row else None

    def set_baseline(
        self,
        agent_id: str,
        dataset_id: str,
        dataset_version: str,
        metric: str,
        value: float,
        created_by: str,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                f"INSERT INTO {BASELINES_TABLE} "
                "(eval_baseline_id, agent_id, dataset_id, dataset_version, baseline_metric_name, baseline_metric_value, created_ts, created_by) VALUES (?,?,?,?,?,?,?,?) "
                "ON CONFLICT(agent_id, dataset_id, dataset_version, baseline_metric_name) DO UPDATE SET "
                "baseline_metric_value=excluded.baseline_metric_value, created_ts=excluded.created_ts, created_by=excluded.created_by",
                (
                    uuid.uuid4().hex,
                    agent_id,
                    dataset_id,
                    dataset_version,
                    metric,
                    value,
                    datetime.now(UTC).isoformat(),
                    created_by,
                ),
            )

    def delete_old_runs(self, days: int) -> int:
        if days <= 0:
            return 0
        cutoff = (datetime.now(UTC) - timedelta(days=days)).isoformat()
        with self._connect() as conn:
            cursor = conn.execute(f"DELETE FROM {RUNS_TABLE} WHERE creation_ts < ?", (cutoff,))
            return cursor.rowcount
