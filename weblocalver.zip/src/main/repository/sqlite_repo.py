"""SQLite implementation of EvaluationRepository (local/offline backend).

Selected by ``build_repository`` for ``sqlite:///path`` URLs. Every connection is
closed after use, WAL mode is set once in ``init_schema`` (it is persistent in
the database file), and legacy-schema migrations run in a single transaction.
Timestamps are stored in one canonical ISO-8601 UTC format (see ``_sql``).
"""

from __future__ import annotations

import sqlite3
import uuid
from collections.abc import Iterator
from contextlib import closing, contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.models import RunRecord
from core.structured_logging import get_logger

from ._sql import (
    BASELINES_TABLE,
    RUNS_TABLE,
    ListRunsDialect,
    build_list_runs_query,
    now_utc_iso,
    to_utc_iso,
)
from ._summary_sql import build_run_summary_query, summary_from_row
from .base import EvaluationRepository
from .sqlite_migrations import migrate_legacy_tables, schema_statements

_log = get_logger("eval_service.repository.sqlite")

_DIALECT = ListRunsDialect(
    case_count_sql="COALESCE(json_array_length(detail_json, '$.case_results'), 0)",
    passed_count_sql=(
        "(SELECT COUNT(*) FROM json_each(detail_json, '$.case_results') "
        "WHERE json_extract(json_each.value, '$.passed') = 1)"
    ),
    error_detail_sql="json_extract(detail_json, '$.error_detail')",
    ts_bind=to_utc_iso,
)


class SqliteRepository(EvaluationRepository):
    def __init__(self, db_path: str):
        self._path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    def _connect(self) -> sqlite3.Connection:
        """Open a raw connection; callers must close it (see ``_tx``)."""
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        """Connection that commits on success, rolls back on error, and always closes."""
        with closing(self._connect()) as conn, conn:
            yield conn

    def init_schema(self) -> None:
        with closing(self._connect()) as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.isolation_level = None  # explicit transaction control below
            conn.execute("BEGIN IMMEDIATE")
            try:
                for statement in schema_statements():
                    conn.execute(statement)
                migrate_legacy_tables(conn)
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                _log.exception("sqlite_schema_migration_failed", extra={"path": self._path})
                raise

    def ping(self) -> bool:
        try:
            with closing(self._connect()) as conn:
                conn.execute("SELECT 1").fetchone()
        except sqlite3.Error:
            _log.warning("sqlite_ping_failed", exc_info=True)
            return False
        return True

    def save_run(self, run: RunRecord) -> None:
        with self._tx() as conn:
            conn.execute(
                f"""INSERT OR REPLACE INTO {RUNS_TABLE}
                    (eval_execution_id, agent_id, dataset_id, dataset_version,
                     weighted_score, weighted_delta, status, creation_ts, created_by, detail_json)
                    VALUES (?,?,?,?,?,?,?,?,?,?)""",  # noqa: S608 - constant table name
                (
                    run.run_id, run.agent_id, run.dataset_id, run.dataset_version,
                    run.weighted_score, run.weighted_delta, run.status,
                    to_utc_iso(run.creation_ts), run.created_by, run.model_dump_json(),
                ),
            )

    def get_run(self, run_id: str) -> RunRecord | None:
        with self._tx() as conn:
            row = conn.execute(
                f"SELECT detail_json FROM {RUNS_TABLE} WHERE eval_execution_id = ?",  # noqa: S608
                (run_id,),
            ).fetchone()
        return RunRecord.model_validate_json(row["detail_json"]) if row else None

    def list_runs(
        self,
        agent_id: str | None = None,
        limit: int = 50,
        before: str | None = None,
        status: str | None = None,
        dataset_id: str | None = None,
        before_id: str | None = None,
    ) -> list[dict]:
        query, params = build_list_runs_query(
            _DIALECT, agent_id=agent_id, limit=limit, before=before,
            before_id=before_id, status=status, dataset_id=dataset_id,
        )
        with self._tx() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def run_summary(
        self,
        agent_id: str | None = None,
        dataset_id: str | None = None,
        since: str | None = None,
    ) -> dict[str, Any]:
        query, params = build_run_summary_query(_DIALECT, agent_id=agent_id, dataset_id=dataset_id, since=since)
        with self._tx() as conn:
            row = conn.execute(query, params).fetchone()
        return summary_from_row(dict(row))

    def get_baseline(self, agent_id: str, dataset_id: str, dataset_version: str, metric: str) -> float | None:
        with self._tx() as conn:
            row = conn.execute(
                f"SELECT baseline_metric_value FROM {BASELINES_TABLE} "  # noqa: S608
                "WHERE agent_id=? AND dataset_id=? AND dataset_version=? AND baseline_metric_name=?",
                (agent_id, dataset_id, dataset_version, metric),
            ).fetchone()
        return float(row["baseline_metric_value"]) if row else None

    def set_baseline(
        self,
        agent_id: str,
        dataset_id: str,
        dataset_version: str,
        metric: str,
        value: float,
        created_by: str,
    ) -> None:
        with self._tx() as conn:
            conn.execute(
                f"INSERT INTO {BASELINES_TABLE} "  # noqa: S608
                "(eval_baseline_id, agent_id, dataset_id, dataset_version, baseline_metric_name, "
                "baseline_metric_value, created_ts, created_by) VALUES (?,?,?,?,?,?,?,?) "
                "ON CONFLICT(agent_id, dataset_id, dataset_version, baseline_metric_name) DO UPDATE SET "
                "baseline_metric_value=excluded.baseline_metric_value, created_ts=excluded.created_ts, "
                "created_by=excluded.created_by",
                (uuid.uuid4().hex, agent_id, dataset_id, dataset_version, metric, value, now_utc_iso(), created_by),
            )

    def delete_old_runs(self, days: int) -> int:
        if days <= 0:
            return 0
        cutoff = to_utc_iso(datetime.now(UTC) - timedelta(days=days))
        with self._tx() as conn:
            cursor = conn.execute(f"DELETE FROM {RUNS_TABLE} WHERE creation_ts < ?", (cutoff,))  # noqa: S608
            return cursor.rowcount
