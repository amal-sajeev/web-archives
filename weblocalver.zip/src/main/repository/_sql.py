"""Shared SQL helpers for the SQLite and Postgres repositories.

Both backends build the ``list_runs`` query here; only the small dialect
differences (JSON functions, timestamp bind conversion) are passed in.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

RUNS_TABLE = "eval_execution"
BASELINES_TABLE = "eval_baseline"

SUMMARY_COLUMNS = (
    "eval_execution_id AS run_id, agent_id, dataset_id, dataset_version, weighted_score, "
    "weighted_delta, status, creation_ts, created_by"
)

ERROR_STATUS = "ERROR"

# Column names of one run-list item, in the order the list/summary queries select them.
ITEM_FIELDS = (
    "run_id", "agent_id", "dataset_id", "dataset_version", "weighted_score", "weighted_delta",
    "status", "creation_ts", "created_by", "case_count", "passed_case_count", "error_detail",
)


@dataclass(frozen=True)
class ListRunsDialect:
    """Backend-specific SQL fragments used by :func:`build_list_runs_query`."""

    case_count_sql: str
    passed_count_sql: str
    error_detail_sql: str
    ts_bind: Callable[[str], Any]

    def item_columns(self) -> str:
        """SELECT list for one run-list item (see ``ITEM_FIELDS``), read from ``RUNS_TABLE``."""
        return (
            f"{SUMMARY_COLUMNS}, {self.case_count_sql} AS case_count, "
            f"{self.passed_count_sql} AS passed_case_count, {self.error_detail_sql} AS error_detail"
        )


def parse_utc(value: str | datetime) -> datetime:
    """Parse an ISO-8601 string (or datetime) into an aware UTC datetime."""
    dt = value if isinstance(value, datetime) else datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def to_utc_iso(value: str | datetime) -> str:
    """Canonical storage/response format: ``YYYY-MM-DDTHH:MM:SS.mmm+00:00``."""
    return parse_utc(value).isoformat(timespec="milliseconds")


def now_utc_iso() -> str:
    return to_utc_iso(datetime.now(UTC))


def _filters(
    dialect: ListRunsDialect,
    agent_id: str | None,
    before: str | None,
    before_id: str | None,
    status: str | None,
    dataset_id: str | None,
) -> tuple[list[str], dict[str, Any]]:
    conditions: list[str] = []
    params: dict[str, Any] = {}
    if agent_id:
        conditions.append("agent_id = :agent_id")
        params["agent_id"] = agent_id
    if before:
        params["before_ts"] = dialect.ts_bind(before)
        if before_id:
            conditions.append(
                "(creation_ts < :before_ts OR (creation_ts = :before_ts AND eval_execution_id < :before_id))"
            )
            params["before_id"] = before_id
        else:
            conditions.append("creation_ts < :before_ts")
    if status:
        if status.startswith(ERROR_STATUS):
            conditions.append("status LIKE :status")
            params["status"] = f"{ERROR_STATUS}%"
        else:
            conditions.append("status = :status")
            params["status"] = status
    if dataset_id:
        conditions.append("dataset_id = :dataset_id")
        params["dataset_id"] = dataset_id
    return conditions, params


def build_list_runs_query(
    dialect: ListRunsDialect,
    *,
    agent_id: str | None = None,
    limit: int = 50,
    before: str | None = None,
    before_id: str | None = None,
    status: str | None = None,
    dataset_id: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """Return ``(sql, named_params)`` for a newest-first keyset page of run summaries."""
    conditions, params = _filters(dialect, agent_id, before, before_id, status, dataset_id)
    query = f"SELECT {dialect.item_columns()} FROM {RUNS_TABLE}"  # noqa: S608 - fixed names, values are bound
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY creation_ts DESC, eval_execution_id DESC LIMIT :limit"
    params["limit"] = int(limit)
    return query, params
