"""Plain-language descriptions of outbound call failures (agents, the AI judge).

Error text from these helpers ends up in the UI (``Observation.error``, skip
reasons), where "httpx.ConnectError: [Errno 11001] getaddrinfo failed" means
nothing to most readers. :func:`describe_http_error` leads with a sentence a
non-technical user can act on and keeps the technical detail in brackets at
the end for engineers:

    Could not connect to the agent. Check that it is running and that its
    address is correct. (ConnectError: [Errno 11001] getaddrinfo failed)
"""

from __future__ import annotations

import json

import httpx
import pydantic

_CONNECT = "Could not connect to {what}. Check that it is running and that its address is correct."
_TIMEOUT = "{What} did not respond within the time limit."
_CONNECT_TIMEOUT = "{What} did not accept the connection within the time limit."
_DROPPED = "{What} closed the connection unexpectedly."
_BAD_URL = "The address configured for {what} is not a valid URL."
_PROXY = "The network proxy refused the connection to {what}."
_NOT_JSON = "{What} replied, but the reply was not valid JSON."
_BAD_SHAPE = "{What} replied, but not in the expected format."

# Checked in order: subclasses before their parents (ConnectTimeout is a TimeoutException).
_PLAIN: tuple[tuple[type[BaseException], str], ...] = (
    (httpx.ConnectTimeout, _CONNECT_TIMEOUT),
    (httpx.TimeoutException, _TIMEOUT),
    (TimeoutError, _TIMEOUT),
    (httpx.ProxyError, _PROXY),
    (httpx.ConnectError, _CONNECT),
    (httpx.RemoteProtocolError, _DROPPED),
    (httpx.ReadError, _DROPPED),
    (httpx.UnsupportedProtocol, _BAD_URL),
    (httpx.InvalidURL, _BAD_URL),
    (json.JSONDecodeError, _NOT_JSON),
    (pydantic.ValidationError, _BAD_SHAPE),
)


def technical_detail(exc: BaseException) -> str:
    """``Type: message`` (just ``Type`` when the message is empty)."""
    text = str(exc).strip()
    return f"{type(exc).__name__}: {text}" if text else type(exc).__name__


def plain_http_error(exc: BaseException, what: str = "the agent") -> str | None:
    """A plain sentence for a known transport failure, else ``None``."""
    for exc_type, template in _PLAIN:
        if isinstance(exc, exc_type):
            return template.format(what=what, What=what[:1].upper() + what[1:])
    return None


def describe_http_error(exc: BaseException, what: str = "the agent") -> str:
    """Plain sentence plus ``(Type: message)``; unknown errors keep the technical text only."""
    plain = plain_http_error(exc, what)
    detail = technical_detail(exc)
    return f"{plain} ({detail})" if plain else detail
