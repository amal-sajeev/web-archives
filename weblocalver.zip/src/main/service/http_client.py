"""Shared ``httpx.AsyncClient`` construction for every outbound call.

All adapters build their clients through :func:`build_async_client_kwargs` so
the TLS policy (``Config.EXCLUDE_TLS``) is applied in one place.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from core.config import Config

_log = logging.getLogger("eval_service.http_client")


def build_async_client_kwargs(
    *,
    timeout: float | httpx.Timeout,
    trust_env: bool = False,
    follow_redirects: bool = False,
) -> dict[str, Any]:
    """Return keyword arguments for ``httpx.AsyncClient``.

    Args:
        timeout: request timeout in seconds (or an ``httpx.Timeout``).
        trust_env: honour HTTP(S)_PROXY / NO_PROXY env vars. Off by default so
            localhost agents are not routed through a corporate proxy.
        follow_redirects: follow 3xx responses.

    When ``Config.EXCLUDE_TLS`` is on, certificate verification is disabled and
    a warning is logged for each client built.
    """
    kwargs: dict[str, Any] = {
        "timeout": timeout,
        "trust_env": trust_env,
        "follow_redirects": follow_redirects,
    }
    if Config.EXCLUDE_TLS:
        _log.warning("TLS certificate verification is disabled (EXCLUDE_TLS=1)")
        kwargs["verify"] = False
    return kwargs
