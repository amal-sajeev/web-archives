"""Evaluation lifecycle handlers (sync, background start, async+webhook, A/B).

Handlers take their collaborators (runner, registry) as explicit arguments so
they can be called directly; the route layer (``api_routes``) injects them.
Stream/cancel handlers live in ``handlers.streams`` and are re-exported here.
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
from fastapi.responses import JSONResponse

from core.config import Config
from core.models import ABCompareRequest, AsyncEvaluateRequest, EvaluateRequest, RunRecord
from core.run_manager import LiveRun, run_manager
from core.structured_logging import get_logger
from dependencies import RegistryDep, RunnerDep
from service.http_client import build_async_client_kwargs

from ._common import (
    CANCELLED_DETAIL,
    http_error,
    progress_publisher,
    publish_cancelled,
    publish_failure,
    require_agents,
    spawn_run,
)
from .comparison import build_case_comparison
from .streams import (
    evaluate_cancel,
    evaluate_stream,
    evaluate_stream_events,
    evaluate_streams,
)

__all__ = [
    "_drive_run",
    "evaluate",
    "evaluate_ab",
    "evaluate_async",
    "evaluate_cancel",
    "evaluate_start",
    "evaluate_stream",
    "evaluate_stream_events",
    "evaluate_streams",
]

_log = get_logger("eval_service.handlers.evaluate")
_DEFAULT_CREATED_BY = "DEVELOPER"
# Strong references so fire-and-forget webhook tasks are not garbage collected.
_WEBHOOK_TASKS: set[asyncio.Task] = set()


async def evaluate(request: EvaluateRequest, runner: RunnerDep) -> dict:
    """Synchronous evaluation: run to completion and return the RunRecord."""
    try:
        run = await runner.evaluate(
            request.agent_id,
            request.dataset_version,
            request.judge_repetitions,
            request.created_by,
        )
    except Exception as exc:
        raise http_error(exc) from exc
    return run.model_dump()


def _accepted(live: LiveRun, body: dict) -> JSONResponse:
    """202 with a Location (relative to /api/evaluate/*) pointing at the SSE stream."""
    return JSONResponse(
        status_code=202,
        content=body,
        headers={"Location": f"stream/{live.stream_id}"},
    )


async def evaluate_start(request: EvaluateRequest, runner: RunnerDep, registry: RegistryDep) -> JSONResponse:
    """Start an evaluation in the background; returns 202 with the stream_id."""
    require_agents(registry, request.agent_id)
    live = run_manager.create(request.agent_id)
    spawn_run(live, _drive_run(
        live, request.agent_id, request.dataset_version,
        request.judge_repetitions, request.created_by, runner,
    ))
    return _accepted(live, {"stream_id": live.stream_id, "agent_id": request.agent_id})


async def evaluate_async(
    request: AsyncEvaluateRequest, runner: RunnerDep, registry: RegistryDep,
) -> JSONResponse:
    """Start an evaluation that fires ``webhook_url`` on any terminal state; returns 202."""
    require_agents(registry, request.agent_id)
    live = run_manager.create(request.agent_id)
    spawn_run(live, _drive_run(
        live, request.agent_id, request.dataset_version,
        request.judge_repetitions, request.created_by, runner,
        webhook_url=request.webhook_url,
    ))
    return _accepted(live, {
        "stream_id": live.stream_id,
        "agent_id": request.agent_id,
        "webhook_url": request.webhook_url,
    })


async def _drive_run(
    live: LiveRun,
    agent_id: str,
    dataset_version: str | None,
    judge_repetitions: int,
    created_by: str,
    runner: Any,
    webhook_url: str | None = None,
) -> None:
    """Execute an evaluation, publishing progress and exactly one terminal outcome."""
    run: RunRecord | None = None
    try:
        run = await runner.evaluate(
            agent_id, dataset_version, judge_repetitions, created_by,
            progress=progress_publisher(live),
            should_cancel=lambda: live.cancel_requested,
        )
        live.set_finished_run(run)
    except asyncio.CancelledError:
        publish_cancelled(live)
        raise
    except Exception as exc:
        publish_failure(live, exc)
    finally:
        live.finish()
        if webhook_url:
            _schedule_webhook(webhook_url, _webhook_payload(live, run))


def _webhook_payload(live: LiveRun, run: RunRecord | None) -> dict:
    if run is not None:
        return run.model_dump()
    last = live.events[-1] if live.events else {}
    cancelled = live.cancel_requested or last.get("detail") == CANCELLED_DETAIL
    return {
        "stream_id": live.stream_id,
        "agent_id": live.agent_id,
        "run_id": live.run_id,
        "status": "CANCELLED" if cancelled else "ERROR",
        "detail": last.get("detail"),
        "error_type": last.get("error_type"),
    }


def _schedule_webhook(url: str, payload: dict) -> None:
    task = asyncio.get_running_loop().create_task(_deliver_webhook(url, payload))
    _WEBHOOK_TASKS.add(task)
    task.add_done_callback(_WEBHOOK_TASKS.discard)


async def _deliver_webhook(url: str, payload: dict) -> None:
    run_id = payload.get("run_id")
    try:
        kwargs = build_async_client_kwargs(timeout=Config.WEBHOOK_TIMEOUT, trust_env=True)
        async with httpx.AsyncClient(**kwargs) as client:
            await client.post(url, json=payload)
        _log.info("webhook_delivered", extra={"run_id": run_id, "webhook_url": url})
    except httpx.HTTPError as exc:
        _log.warning("webhook_failed", extra={"run_id": run_id, "webhook_url": url, "error": str(exc)})


async def _run_pair(request: ABCompareRequest, runner: Any) -> tuple[RunRecord, RunRecord]:
    """Run both agents concurrently; a failure in one cancels the other."""
    created_by = getattr(request, "created_by", None) or _DEFAULT_CREATED_BY
    async with asyncio.TaskGroup() as group:
        task_a = group.create_task(runner.evaluate(
            request.agent_a, request.dataset_version, request.judge_repetitions, created_by))
        task_b = group.create_task(runner.evaluate(
            request.agent_b, request.dataset_version, request.judge_repetitions, created_by))
    return task_a.result(), task_b.result()


async def evaluate_ab(request: ABCompareRequest, runner: RunnerDep, registry: RegistryDep) -> dict:
    """Run two agents against the same dataset and compare their results."""
    require_agents(registry, request.agent_a, request.agent_b)
    try:
        run_a, run_b = await _run_pair(request, runner)
    except ExceptionGroup as group:
        raise http_error(group.exceptions[0]) from group
    return build_case_comparison(run_a, run_b)
