"""Health, liveness and readiness endpoints."""

from __future__ import annotations

from typing import Any

from fastapi.responses import JSONResponse

from core.config import Config
from dependencies import RegistryDep, RepoDep
from core.structured_logging import get_logger
from scorers.vertex import require_vertex_credentials

_log = get_logger("eval_service.handlers.health")

STATUS_OK = "ok"
STATUS_DEGRADED = "degraded"


def _db_url_scheme() -> str:
    return Config.DB_URL.split(":", 1)[0] if ":" in Config.DB_URL else Config.DB_URL


def health(registry: RegistryDep, repo: RepoDep) -> dict:
    """Config + ADC probe; reports the resolved credential class name."""
    result: dict[str, Any] = {
        "status": STATUS_OK,
        "project_name": Config.PROJECT_NAME or None,
        "version": Config.SERVICE_VERSION,
        "project_location": Config.PROJECT_LOCATION,
        "agents": len(registry.list_agents()),
        "storage_backend": type(repo).__name__,
        "db_url_scheme": _db_url_scheme(),
        "db_name": Config.DB_NAME,
        "db_schema": Config.DB_SCHEMA,
        "db_host": Config.DB_HOST,
        "db_connection_mode": ("tcp_proxy" if Config.DB_HOST else "cloudsql_connector"),
        "sqlite_fallback_allowed": Config.ALLOW_SQLITE_FALLBACK,
        "exclude_tls": Config.EXCLUDE_TLS,
    }
    if not Config.PROJECT_NAME:
        result.update(status=STATUS_DEGRADED, vertex="PROJECT_NAME unset — judge would fall back to the Developer API")
        return result
    try:
        result["credential_class"] = require_vertex_credentials()
        result["vertex"] = STATUS_OK
    except Exception as exc:
        _log.warning("health_vertex_probe_failed", extra={"error_type": type(exc).__name__})
        result.update(status=STATUS_DEGRADED, vertex=f"{type(exc).__name__}: {exc}")
    return result


def livez() -> dict:
    """Liveness: the process is up and serving requests."""
    return {"status": STATUS_OK}


def readyz(repo: RepoDep) -> JSONResponse:
    """Readiness: the repository answers ``SELECT 1``; 503 when it does not."""
    if repo.ping():
        return JSONResponse(status_code=200, content={"status": STATUS_OK, "storage": STATUS_OK})
    return JSONResponse(status_code=503, content={"status": STATUS_DEGRADED, "storage": "unreachable"})
