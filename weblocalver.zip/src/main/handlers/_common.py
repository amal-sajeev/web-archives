"""Helpers shared by the evaluation and playground handlers.

Error classification, terminal-event publishing, background-task spawning and
the common "not found" lookups live here so every lifecycle path behaves the same.
"""

from __future__ import annotations

import asyncio
import uuid
from collections.abc import Awaitable, Callable, Coroutine
from typing import Any

import httpx
from fastapi import HTTPException

from core.run_manager import LiveRun, run_manager
from core.structured_logging import get_logger
from repository.errors import RETRY_AFTER_SECONDS, UNAVAILABLE_DETAIL, is_repository_unavailable

_log = get_logger("eval_service.handlers")

EVENT_RUN_DONE = "run_done"
EVENT_PLAYGROUND_DONE = "playground_done"
EVENT_ERROR = "error"
EVENT_RUN_CANCELLED = "run_cancelled"
# The runner also emits ``run_done`` (status ERROR) on failure/cancel paths, so only an
# explicit failure event may suppress a later ``error``/``run_cancelled`` outcome.
FAILURE_EVENT_TYPES = frozenset({EVENT_ERROR, EVENT_RUN_CANCELLED})

CANCELLED_STATUS = 499
CANCELLED_DETAIL = "Run cancelled by request"
INTERNAL_ERROR_DETAIL = "Internal error during evaluation"
UPSTREAM_ERROR_DETAIL = "Upstream request failed"
SERVICE_UNAVAILABLE_STATUS = 503


def stream_not_found(stream_id: str) -> str:
    return f"Stream '{stream_id}' not found"


def agent_not_found(agent_id: str) -> str:
    return f"Unknown agent '{agent_id}'"


def run_not_found(run_id: str) -> str:
    return f"Run '{run_id}' not found"


def require_live(stream_id: str) -> LiveRun:
    """Return the live run or raise 404."""
    live = run_manager.get(stream_id)
    if not live:
        raise HTTPException(status_code=404, detail=stream_not_found(stream_id))
    return live


def require_agents(registry: Any, *agent_ids: str) -> None:
    """Raise 404 for the first agent id the registry does not know."""
    for agent_id in agent_ids:
        if not registry.has(agent_id):
            raise HTTPException(status_code=404, detail=agent_not_found(agent_id))


def classify_error(exc: BaseException) -> tuple[int, str, str | None]:
    """Map an exception to ``(status, client_detail, error_id)``.

    KeyError -> 404, ValueError -> 400, upstream httpx errors -> 502, an
    unreachable repository -> 503, anything else -> 500 with a generic message.
    For 5xx the details (and traceback) are logged server-side only, keyed by
    the returned ``error_id``.
    """
    if isinstance(exc, KeyError):
        return 404, str(exc.args[0]) if exc.args else str(exc), None
    if isinstance(exc, ValueError):
        return 400, str(exc), None
    error_id = uuid.uuid4().hex[:12]
    _log.error(
        "evaluation_failed",
        exc_info=(type(exc), exc, exc.__traceback__),
        extra={"error_id": error_id, "error_type": type(exc).__name__},
    )
    if isinstance(exc, httpx.HTTPError):
        return 502, f"{UPSTREAM_ERROR_DETAIL}: {type(exc).__name__}: {exc}", error_id
    if is_repository_unavailable(exc):
        return SERVICE_UNAVAILABLE_STATUS, f"{UNAVAILABLE_DETAIL} (error_id={error_id})", error_id
    return 500, f"{INTERNAL_ERROR_DETAIL} (error_id={error_id})", error_id


def http_error(exc: BaseException) -> HTTPException:
    """Translate an evaluation failure into an HTTPException (see ``classify_error``)."""
    if isinstance(exc, HTTPException):
        return exc
    status, detail, _error_id = classify_error(exc)
    headers = {"Retry-After": RETRY_AFTER_SECONDS} if status == SERVICE_UNAVAILABLE_STATUS else None
    return HTTPException(status_code=status, detail=detail, headers=headers)


def query_error(name: str, message: str) -> HTTPException:
    """A 422 in FastAPI's validation-error shape for one query parameter."""
    return HTTPException(
        status_code=422,
        detail=[{"loc": ["query", name], "msg": message, "type": "value_error"}],
    )


def check_range(name: str, value: int, low: int, high: int | None = None) -> None:
    """422 (FastAPI validation-error shape) when a query value is out of range.

    Done in the handler instead of ``Query(ge=..)`` so handlers keep plain defaults
    and stay directly callable, on every supported FastAPI version.
    """
    if value < low or (high is not None and value > high):
        bound = f">= {low}" if high is None else f"between {low} and {high}"
        raise query_error(name, f"Input should be {bound}")


def agent_name(registry: Any, agent_id: str | None) -> str | None:
    """Registry display name (``agent.yaml`` ``name``) or None when unknown/unavailable."""
    if registry is None or not agent_id or not registry.has(agent_id):
        return None
    try:
        return registry.get(agent_id).config.name
    except KeyError:
        return None


def has_failure_event(live: LiveRun) -> bool:
    return any(e.get("type") in FAILURE_EVENT_TYPES for e in live.events)


def publish_failure(live: LiveRun, exc: BaseException) -> None:
    """Publish one ``error`` event (unless a failure event was already published)."""
    status, detail, error_id = classify_error(exc)
    if has_failure_event(live):
        return
    live.publish({
        "type": EVENT_ERROR,
        "status": status,
        "detail": detail,
        "error_type": type(exc).__name__,
        "error_id": error_id,
    })


def publish_cancelled(live: LiveRun, detail: str = CANCELLED_DETAIL) -> None:
    if not has_failure_event(live):
        live.publish({"type": EVENT_RUN_CANCELLED, "status": CANCELLED_STATUS, "detail": detail})


def progress_publisher(live: LiveRun) -> Callable[[dict], Awaitable[None]]:
    async def progress(event: dict) -> None:
        live.publish(event)
    return progress


def _ensure_finished(live: LiveRun, task: asyncio.Task) -> None:
    """Safety net: a task cancelled before it first ran never reaches its ``finally``."""
    if live.done:
        return
    if task.cancelled():
        publish_cancelled(live)
    live.finish()


def spawn_run(live: LiveRun, coro: Coroutine[Any, Any, None]) -> asyncio.Task:
    """Start the background driver for ``live`` and attach it to the LiveRun."""
    task = asyncio.create_task(coro)
    task.add_done_callback(lambda t: _ensure_finished(live, t))
    live.task = task
    return task
