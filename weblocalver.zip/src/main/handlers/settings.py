"""Settings and TLS policy handlers."""

from __future__ import annotations

from typing import Any

from fastapi import HTTPException
from pydantic import BaseModel, ValidationError

from core.config import Config


class TlsPolicyRequest(BaseModel):
    """Body of ``POST /api/settings/tls``: set ``enabled`` (verify TLS) or ``exclude_tls``.

    Pydantic's lax bool parsing accepts true/false, 1/0, yes/no, on/off strings.
    """

    enabled: bool | None = None
    exclude_tls: bool | None = None


def runtime_settings() -> dict:
    """Expose runtime toggles for the dashboard and API tooling."""
    return {
        "exclude_tls": Config.EXCLUDE_TLS,
        "tls_verification_enabled": not Config.EXCLUDE_TLS,
    }


def _coerce(payload: Any) -> TlsPolicyRequest:
    if isinstance(payload, TlsPolicyRequest):
        return payload
    try:
        return TlsPolicyRequest.model_validate(payload or {})
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors(include_url=False)) from exc


def set_tls_policy(payload: TlsPolicyRequest | None = None) -> dict:
    """Set the service-wide TLS verification policy at runtime (direct callers may pass a dict)."""
    body = _coerce(payload)
    if body.enabled is not None:
        exclude_tls = not body.enabled
    elif body.exclude_tls is not None:
        exclude_tls = body.exclude_tls
    else:
        raise HTTPException(status_code=400, detail="Request body must include either 'enabled' or 'exclude_tls'.")
    Config.set_exclude_tls(exclude_tls)
    return runtime_settings()
