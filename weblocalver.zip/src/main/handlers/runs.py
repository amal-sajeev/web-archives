"""Run management handlers (list, summary, compare, get, export, promote baselines).

Handlers take the repository explicitly and keep plain defaults, so direct calls
work without FastAPI; range/format checks raise FastAPI-shaped 422s themselves.
"""

from __future__ import annotations

import base64
import binascii
import csv
import io
import math
from typing import Any, Literal

from fastapi import HTTPException
from fastapi.responses import Response

from dependencies import LoggerDep, OptionalRegistryDep, RepoDep
from repository._sql import parse_utc
from utils import build_text_pdf

from ._common import agent_name, check_range, query_error, run_not_found
from .comparison import build_case_comparison

ExportFormat = Literal["csv", "pdf"]
RunStatus = Literal["PASS", "FAIL", "ERROR"]

MAX_PAGE_SIZE = 200
_CURSOR_SEPARATOR = "|"
_CSV_HEADER = [
    "case_id", "case_status", "weighted_score", "weighted_delta",
    "metric", "score", "threshold", "passed_metric", "critical", "rationale",
    # Raw numbers behind the UI's change wording; appended so positional readers keep working.
    "case_baseline_score", "case_change_pct", "baseline", "change_pct",
]
_PDF_RATIONALE_CHARS = 80
_ERROR_PREFIX = "ERROR"
_AGENT_ID = "agent_id"
_INVALID_TIMESTAMP = "Input should be an ISO-8601 date or datetime"


def encode_cursor(creation_ts: str, run_id: str) -> str:
    """Opaque, URL-safe keyset cursor for ``(creation_ts, run_id)``."""
    raw = f"{creation_ts}{_CURSOR_SEPARATOR}{run_id}".encode()
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def decode_cursor(cursor: str) -> tuple[str, str | None]:
    """Return ``(creation_ts, run_id)``; a legacy bare timestamp yields ``(ts, None)``."""
    padded = cursor + "=" * (-len(cursor) % 4)
    try:
        raw = base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8")
    except (binascii.Error, UnicodeError, ValueError):
        return cursor, None
    ts, sep, run_id = raw.partition(_CURSOR_SEPARATOR)
    if not sep or not ts or not run_id:
        return cursor, None
    return ts, run_id


def _require_run(repo: Any, run_id: str) -> Any:
    run = repo.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=run_not_found(run_id))
    return run


def _require_timestamp(name: str, value: str) -> str:
    """422 unless ``value`` parses as an ISO-8601 date/datetime (before it reaches SQL)."""
    try:
        parse_utc(value)
    except (TypeError, ValueError) as exc:
        raise query_error(name, _INVALID_TIMESTAMP) from exc
    return value


def _named_item(row: dict[str, Any], registry: Any, names: dict[str, str | None]) -> dict[str, Any]:
    agent_id = row.get(_AGENT_ID)
    if agent_id not in names:
        names[agent_id] = agent_name(registry, agent_id)
    return {"error_detail": None, **row, "agent_name": names[agent_id]}


def list_runs(
    repo: RepoDep,
    agent_id: str | None = None,
    limit: int = 50,
    before: str | None = None,
    status: RunStatus | None = None,
    dataset_id: str | None = None,
    registry: OptionalRegistryDep = None,
) -> dict:
    """List run summaries newest first, with case counts, ``error_detail``, ``agent_name`` and a keyset cursor."""
    check_range("limit", limit, 1, MAX_PAGE_SIZE)
    before_ts, before_id = decode_cursor(before) if before else (None, None)
    if before_ts is not None:
        _require_timestamp("before", before_ts)
    rows = repo.list_runs(
        agent_id=agent_id, limit=limit + 1, before=before_ts, status=status,
        dataset_id=dataset_id, before_id=before_id,
    )
    page = rows[:limit]
    has_more = len(rows) > limit and bool(page)
    next_cursor = encode_cursor(str(page[-1]["creation_ts"]), str(page[-1]["run_id"])) if has_more else None
    names: dict[str, str | None] = {}
    return {"runs": [_named_item(row, registry, names) for row in page], "next_cursor": next_cursor}


def runs_summary(
    repo: RepoDep,
    agent_id: str | None = None,
    dataset_id: str | None = None,
    since: str | None = None,
    registry: OptionalRegistryDep = None,
) -> dict:
    """Status counts, mean score and latest/previous run, computed in one repository query."""
    if since:
        _require_timestamp("since", since)
    summary = repo.run_summary(agent_id=agent_id, dataset_id=dataset_id, since=since or None)
    names: dict[str, str | None] = {}
    for key in ("latest", "previous"):
        if summary.get(key) is not None:
            summary[key] = _named_item(summary[key], registry, names)
    return summary


def compare_runs(repo: RepoDep, a: str, b: str) -> dict:
    """Compare two different runs side by side."""
    if a == b:
        raise HTTPException(status_code=400, detail="Choose two different runs to compare.")
    return build_case_comparison(_require_run(repo, a), _require_run(repo, b))


def get_run(repo: RepoDep, run_id: str, registry: OptionalRegistryDep = None) -> dict:
    """Get a full run record, plus the agent's registry display name (``agent_name``)."""
    run = _require_run(repo, run_id)
    return {**run.model_dump(), "agent_name": agent_name(registry, run.agent_id)}


def _blank(value: float | None) -> float | str:
    return "" if value is None else value


def _relative_change_pct(current: float, baseline: float | None) -> float | None:
    """(current - baseline) / baseline x 100, one decimal; None without a (non-zero) baseline."""
    if baseline is None or baseline == 0:
        return None
    return round((current - baseline) / baseline * 100, 1)


def _case_baseline(case: Any) -> float | None:
    """Weighted baseline implied by score - delta, only when a criterion had a stored baseline."""
    if not any(s.baseline is not None for s in case.scores):
        return None
    return round(case.weighted_score - case.weighted_delta, 6)


def _run_baseline(run: Any) -> float | None:
    if not any(_case_baseline(case) is not None for case in run.case_results):
        return None
    return round(run.weighted_score - run.weighted_delta, 6)


def _pct(value: float, decimals: int) -> str:
    scaled = math.floor(min(max(value, 0.0), 1.0) * 100 * 10**decimals + 0.5) / 10**decimals
    return f"{scaled:.{decimals}f}%"


def _change_text(current: float, baseline: float | None) -> str:
    """ASCII form of the UI wording (the PDF font is Latin-1): "-17.7%", "Unchanged" or "Up from 0%"."""
    if baseline is None:
        return "No baseline"
    if _pct(current, 1) == _pct(baseline, 1):
        return "Unchanged"
    relative = _relative_change_pct(current, baseline)
    if relative is None:
        return "Up from 0%"
    size = max(abs(relative), 0.1)
    return f"{'+' if current > baseline else '-'}{size:.1f}%"


def _csv_text(run: Any) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(_CSV_HEADER)
    for case in run.case_results:
        head = [case.case_id, case.passed, case.weighted_score, case.weighted_delta]
        case_base = _case_baseline(case)
        tail = [_blank(case_base), _blank(_relative_change_pct(case.weighted_score, case_base))]
        if not case.scores:
            writer.writerow([*head, "", "", "", "", "", "", *tail, "", ""])
        for s in case.scores:
            change = _relative_change_pct(s.score, s.baseline)
            writer.writerow([
                *head, s.metric, s.score, s.threshold, s.passed, s.critical, s.rationale or "",
                *tail, _blank(s.baseline), _blank(change),
            ])
    return buf.getvalue()


def _pdf_lines(run: Any) -> list[str]:
    lines = [
        f"Evaluation Run Export: {run.run_id[:8]}",
        f"Agent: {run.agent_id}  Dataset: {run.dataset_id} v{run.dataset_version}",
        f"Score: {run.weighted_score:.3f}  Vs baseline: {_change_text(run.weighted_score, _run_baseline(run))}"
        f"  Status: {run.status}",
        f"Created: {run.creation_ts} by {run.created_by}",
        "",
    ]
    for case in run.case_results:
        change = _change_text(case.weighted_score, _case_baseline(case))
        lines.append(f"  {'PASS' if case.passed else 'FAIL'} {case.case_id} (score={case.weighted_score:.3f}, vs baseline: {change})")
        for s in case.scores:
            mark = "✓" if s.passed else "✗"
            rationale = (s.rationale or "")[:_PDF_RATIONALE_CHARS]
            lines.append(f"    {mark} {s.metric}={s.score:.2f} (threshold={s.threshold}) {rationale}")
        lines.append("")
    return lines


def export_run(
    repo: RepoDep, run_id: str, format: ExportFormat = "csv",
) -> Response:
    """Export a run's full detail as CSV or PDF."""
    run = _require_run(repo, run_id)
    filename = f"run_{run_id[:8]}.{format}"
    headers = {"Content-Disposition": f"attachment; filename={filename}"}
    if format == "csv":
        return Response(content=_csv_text(run), media_type="text/csv", headers=headers)
    if format == "pdf":
        return Response(content=build_text_pdf(_pdf_lines(run)), media_type="application/pdf", headers=headers)
    raise HTTPException(status_code=400, detail=f"Unsupported format '{format}'. Use csv or pdf.")


def promote_baselines(repo: RepoDep, run_id: str, log: LoggerDep) -> dict:
    """Promote a run's per-metric mean scores as the new baseline (409 for ERROR/cancelled runs)."""
    run = _require_run(repo, run_id)
    if str(run.status).startswith(_ERROR_PREFIX):
        raise HTTPException(
            status_code=409,
            detail="Cannot promote baselines from an ERROR run: its scores cover only the cases that finished.",
        )
    metric_scores: dict[str, list[float]] = {}
    for case in run.case_results:
        for s in case.scores:
            metric_scores.setdefault(s.metric, []).append(s.score)
    promoted: list[dict] = []
    for metric, scores in metric_scores.items():
        mean = sum(scores) / len(scores)
        repo.set_baseline(run.agent_id, run.dataset_id, run.dataset_version, metric, mean, run.created_by)
        promoted.append({"metric": metric, "baseline": round(mean, 4), "samples": len(scores)})
    log.info("baselines_promoted", extra={"run_id": run_id, _AGENT_ID: run.agent_id, "metrics": len(promoted)})
    return {
        "run_id": run_id,
        _AGENT_ID: run.agent_id,
        "dataset_version": run.dataset_version,
        "promoted": promoted,
    }
