"""UI page handlers.

Pages are read (and version-stamped) lazily on first request and then cached,
so a missing page never breaks import. Every other asset (``css/``, ``js/``,
images...) is served by the StaticFiles mount in ``main``.
"""

from __future__ import annotations

from functools import lru_cache

from fastapi import HTTPException
from fastapi.responses import Response

from utils import render_static_html

HTML_MEDIA_TYPE = "text/html; charset=utf-8"


@lru_cache(maxsize=16)
def _page(filename: str) -> bytes:
    return render_static_html(filename)


def _serve(filename: str) -> Response:
    try:
        content = _page(filename)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=f"Page '{filename}' not found") from exc
    return Response(content=content, media_type=HTML_MEDIA_TYPE)


def index() -> Response:
    """Serve the main dashboard HTML."""
    return _serve("index.html")


def run_html() -> Response:
    """Serve the live run page."""
    return _serve("run.html")


def run_detail_html() -> Response:
    """Serve the run detail page."""
    return _serve("run_detail.html")


def playground_html() -> Response:
    """Serve the playground editor page."""
    return _serve("playground.html")


def apitester_html() -> Response:
    """Serve the API testing page."""
    return _serve("apitester.html")
