"""One run-vs-run comparison shape, shared by ``/api/runs/compare`` and ``/api/evaluate/ab``."""

from __future__ import annotations

from typing import Any, Literal

Winner = Literal["a", "b", "tie"]


def winner(score_a: float, score_b: float) -> Winner:
    if score_b > score_a:
        return "b"
    if score_a > score_b:
        return "a"
    return "tie"


def _run_summary(run: Any) -> dict:
    return {
        "run_id": run.run_id,
        "agent_id": run.agent_id,
        "score": run.weighted_score,
        "delta": run.weighted_delta,
        "status": run.status,
    }


def _case_summary(case: Any | None) -> dict | None:
    if case is None:
        return None
    return {"score": case.weighted_score, "passed": case.passed, "delta": case.weighted_delta}


def _case_row(case_id: str, case_a: Any | None, case_b: Any | None) -> dict:
    both = case_a is not None and case_b is not None
    return {
        "case_id": case_id,
        "a": _case_summary(case_a),
        "b": _case_summary(case_b),
        "improved": (case_b.weighted_score > case_a.weighted_score) if both else None,
        "winner": winner(case_a.weighted_score, case_b.weighted_score) if both else None,
    }


def build_case_comparison(run_a: Any, run_b: Any) -> dict:
    """Compare two runs overall and per case.

    Shape::

        {"a": RunSummary, "b": RunSummary, "score_diff": float, "winner": "a"|"b"|"tie",
         "cases": [{"case_id", "a": CaseSummary|None, "b": CaseSummary|None,
                    "improved": bool|None, "winner": "a"|"b"|"tie"|None}]}
    """
    cases_a = {c.case_id: c for c in run_a.case_results}
    cases_b = {c.case_id: c for c in run_b.case_results}
    return {
        "a": _run_summary(run_a),
        "b": _run_summary(run_b),
        "score_diff": run_b.weighted_score - run_a.weighted_score,
        "winner": winner(run_a.weighted_score, run_b.weighted_score),
        "cases": [
            _case_row(cid, cases_a.get(cid), cases_b.get(cid))
            for cid in sorted(set(cases_a) | set(cases_b))
        ],
    }
