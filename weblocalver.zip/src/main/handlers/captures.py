"""Capture and label handlers.

The list endpoints page with ``limit``/``offset`` and report the unpaged
``total``; the defaults return up to ``DEFAULT_PAGE_SIZE`` items, which covers
the stores' typical contents without letting one call serialise all of them.
"""

from __future__ import annotations

from typing import Any

from fastapi import HTTPException

from adapters import capture_store
from core.labels import label_store
from core.models import HumanLabel, LabelRequest

from ._common import check_range

DEFAULT_PAGE_SIZE = 1000
MAX_PAGE_SIZE = 5000


def _page(items: list[Any], limit: int, offset: int) -> tuple[list[Any], int]:
    check_range("limit", limit, 1, MAX_PAGE_SIZE)
    check_range("offset", offset, 0)
    return items[offset:offset + limit], len(items)


def list_captures(agent_id: str | None = None, limit: int = DEFAULT_PAGE_SIZE, offset: int = 0) -> dict:
    """Return the latest derived capture payloads retained in memory (optionally for one agent)."""
    items = list(capture_store.latest(agent_id=agent_id).items())
    page, total = _page(items, limit, offset)
    return {"captures": [{"case_id": cid, "payload": payload} for cid, payload in page], "total": total}


def get_capture(case_id: str, agent_id: str | None = None) -> dict:
    """Fetch one captured case action payload by case id (scoped to ``agent_id`` when given)."""
    payload = capture_store.get(case_id, agent_id=agent_id)
    if payload is None:
        raise HTTPException(status_code=404, detail=f"Capture for case '{case_id}' not found")
    return {"case_id": case_id, "payload": payload}


def list_labels(agent_id: str | None = None, limit: int = DEFAULT_PAGE_SIZE, offset: int = 0) -> dict:
    """Return human labels newest first, optionally scoped to one agent."""
    page, total = _page(label_store.all(agent_id=agent_id), limit, offset)
    return {"labels": [label.model_dump() for label in page], "total": total}


def get_label(case_id: str, agent_id: str | None = None) -> dict:
    """Fetch the latest label for a case id (scoped to ``agent_id`` when given)."""
    label = label_store.get(case_id, agent_id=agent_id)
    if label is None:
        raise HTTPException(status_code=404, detail=f"Label for case '{case_id}' not found")
    return label.model_dump()


async def add_label(request: LabelRequest) -> dict:
    """Persist a human verdict for a case to the in-memory label store (201 at the route)."""
    stored = label_store.add(HumanLabel(**request.model_dump()))
    return stored.model_dump()
