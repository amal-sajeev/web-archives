"""HTTP probe helper used by the API tester (``POST /api/playground/http``)."""

from __future__ import annotations

import json
from typing import Any

import httpx
from fastapi import HTTPException
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from service.http_client import build_async_client_kwargs

_PREVIEW_CHARS = 2000
_DEFAULT_TIMEOUT_SECONDS = 15.0


class PlaygroundHttpRequest(BaseModel):
    """Request to proxy. ``json``/``data``/``body`` mirror httpx semantics; ``body``
    is interpreted as JSON when it is structured or the Content-Type says JSON."""

    model_config = ConfigDict(populate_by_name=True)

    method: str = "GET"
    url: str = Field(min_length=1)
    headers: dict[str, Any] = Field(default_factory=dict)
    timeout: float = Field(default=_DEFAULT_TIMEOUT_SECONDS, gt=0)
    params: dict[str, Any] | None = None
    json_body: Any = Field(default=None, alias="json")
    data: Any = None
    body: Any = None


def _coerce(payload: Any) -> PlaygroundHttpRequest:
    if isinstance(payload, PlaygroundHttpRequest):
        return payload
    try:
        return PlaygroundHttpRequest.model_validate(payload or {})
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors(include_url=False)) from exc


def _content_type(headers: dict[str, Any]) -> str:
    return str(headers.get("Content-Type") or headers.get("content-type") or "").lower()


def _body_from_raw(raw_body: Any, content_type: str) -> tuple[Any, Any]:
    """Return ``(json_data, form_data)`` for a free-form ``body`` value."""
    if isinstance(raw_body, dict | list | int | float | bool):
        return raw_body, None
    if not isinstance(raw_body, str):
        return None, str(raw_body)
    if "json" not in content_type:
        return None, raw_body
    try:
        return json.loads(raw_body), None
    except ValueError:
        return None, raw_body


def _resolve_body(req: PlaygroundHttpRequest) -> tuple[Any, Any]:
    json_data = req.json_body
    form_data = req.data if not json_data else None
    if json_data is None and form_data is None and req.body is not None:
        return _body_from_raw(req.body, _content_type(req.headers))
    return json_data, form_data


def _response_dict(response: httpx.Response) -> dict:
    text = response.text
    try:
        payload_obj = response.json()
    except ValueError:
        payload_obj = None
    preview = text[:_PREVIEW_CHARS]
    return {
        "status": response.status_code,
        "status_code": response.status_code,
        "reason": response.reason_phrase,
        "headers": dict(response.headers),
        "text": preview,
        "body": payload_obj if payload_obj is not None else preview,
        "json": payload_obj,
    }


async def playground_http(payload: PlaygroundHttpRequest) -> dict:
    """Send one HTTP request and return status, headers and a body preview.

    Direct callers may pass a plain dict; it is validated the same way (422 on error).
    """
    req = _coerce(payload)
    json_data, form_data = _resolve_body(req)
    try:
        async with httpx.AsyncClient(**build_async_client_kwargs(timeout=req.timeout, trust_env=True)) as client:
            response = await client.request(
                req.method.upper(),
                req.url,
                headers={k: str(v) for k, v in req.headers.items()},
                params=req.params,
                json=json_data,
                data=form_data,
            )
            return _response_dict(response)
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504, detail="HTTP request timed out") from exc
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"HTTP request failed: {exc}") from exc
