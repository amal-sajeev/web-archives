"""Playground (sandbox evaluation) handlers: inspect, validate, run, export.

The HTTP probe helper lives in ``handlers.playground_http`` and is re-exported.
"""

from __future__ import annotations

import asyncio
import json
import re
import shutil
from pathlib import Path
from typing import Any

from fastapi import HTTPException, UploadFile
from fastapi.responses import JSONResponse, Response

from core.config import Config
from core.playground import (
    PreviewRepository,
    _cleanup_scoped_registry,
    _load_scoped_registry,
    extract_to_temp,
    files_to_zip,
    inspect_bundle,
)
from core.run_manager import LiveRun, run_manager
from core.runner import Runner

from ._common import (
    EVENT_PLAYGROUND_DONE,
    check_range,
    progress_publisher,
    publish_cancelled,
    publish_failure,
    require_live,
    spawn_run,
)
from .playground_http import PlaygroundHttpRequest, playground_http
from .playground_validate import playground_validate

__all__ = [
    "PlaygroundHttpRequest",
    "_drive_playground_run",
    "playground_environment",
    "playground_export",
    "playground_http",
    "playground_inspect",
    "playground_start",
    "playground_validate",
]

_PLAYGROUND_SEMAPHORE = asyncio.Semaphore(1)
PLAYGROUND_AGENT_ID = "playground"
MAX_JUDGE_REPETITIONS = 5
_PREVIEW_CANCELLED_DETAIL = "Preview run cancelled"
_INVALID_CASE_IDS = "Invalid case_ids_json"
# Characters allowed in a download filename; anything else becomes "_" so a
# user-supplied bundle root can never break (or inject into) the header.
_UNSAFE_FILENAME_CHARS = re.compile(r"[^A-Za-z0-9._-]+")


async def playground_inspect(file: UploadFile) -> dict:
    """Inspect an uploaded agent-config ZIP without persisting it."""
    blob = await file.read()
    try:
        return inspect_bundle(blob, filename=file.filename)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


def playground_environment() -> dict:
    """Expose the active runtime config used by the playground/editor UI."""
    return {
        "service_version": Config.SERVICE_VERSION,
        "judge_model": Config.JUDGE_MODEL,
        "project_location": Config.PROJECT_LOCATION,
        "metrics_source": Config.METRICS_SOURCE,
        "embedding_model": Config.EMBEDDING_MODEL,
        "judge_samples": Config.JUDGE_SAMPLES,
        "judge_retries": Config.JUDGE_MAX_RETRIES,
        "judge_concurrency": Config.JUDGE_CONCURRENCY,
        "case_concurrency": Config.CASE_CONCURRENCY,
        "auth_mode": "vertex" if Config.PROJECT_NAME else "developer-api",
        "exclude_tls": Config.EXCLUDE_TLS,
    }


def _parse_case_ids(case_ids_json: str | None) -> list[str] | None:
    if not case_ids_json:
        return None
    try:
        parsed = json.loads(case_ids_json)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"{_INVALID_CASE_IDS}: {exc}") from exc
    if not isinstance(parsed, list) or not all(isinstance(item, str) for item in parsed):
        raise HTTPException(status_code=400, detail=f"{_INVALID_CASE_IDS}: must be a JSON array of strings")
    return parsed


async def playground_start(
    file: UploadFile,
    base_url: str | None = None,
    judge_repetitions: int = 1,
    case_ids_json: str | None = None,
) -> JSONResponse:
    """Start a playground (sandbox) evaluation; 202 with the stream_id."""
    check_range("judge_repetitions", judge_repetitions, 1, MAX_JUDGE_REPETITIONS)
    blob = await file.read()
    case_ids = _parse_case_ids(case_ids_json)
    live = run_manager.create(PLAYGROUND_AGENT_ID)
    override = base_url.strip() if isinstance(base_url, str) and base_url.strip() else None
    spawn_run(live, _drive_playground_run(live, blob, file.filename, override, judge_repetitions, case_ids))
    return JSONResponse(
        status_code=202,
        content={"stream_id": live.stream_id, "agent_id": PLAYGROUND_AGENT_ID},
        headers={"Location": f"../evaluate/stream/{live.stream_id}"},
    )


async def _execute_preview(
    live: LiveRun,
    registry: Any,
    agent_id: str,
    base_url_override: str | None,
    judge_repetitions: int,
    case_ids: list[str] | None,
) -> None:
    if base_url_override:
        agent = registry.get(agent_id)
        agent.config = agent.config.model_copy(update={"base_url": base_url_override})
    runner = Runner(registry, PreviewRepository())
    run = await runner.evaluate(
        agent_id,
        judge_repetitions=judge_repetitions,
        created_by="DEVELOPER",
        progress=progress_publisher(live),
        case_ids=case_ids,
    )
    live.set_finished_run(run)
    live.publish({"type": EVENT_PLAYGROUND_DONE, "run": run.model_dump()})


async def _drive_playground_run(
    live: LiveRun,
    blob: bytes,
    filename: str | None,
    base_url_override: str | None,
    judge_repetitions: int,
    case_ids: list[str] | None = None,
) -> None:
    """Execute a playground evaluation and publish progress plus one terminal event."""
    temp_dir: Path | None = None
    registry = None
    try:
        async with _PLAYGROUND_SEMAPHORE:
            temp_dir, agent_id = extract_to_temp(blob, filename=filename)
            registry, _custom_scorers, _collisions = _load_scoped_registry(temp_dir)
            await _execute_preview(live, registry, agent_id, base_url_override, judge_repetitions, case_ids)
    except asyncio.CancelledError:
        publish_cancelled(live, _PREVIEW_CANCELLED_DETAIL)
        raise
    except Exception as exc:
        publish_failure(live, exc)
    finally:
        if registry is not None:
            _cleanup_scoped_registry(registry)
        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
        live.finish()


def _export_bundle(payload: Any) -> Response:
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Request body must be a JSON object.")
    root = str(payload.get("root") or "")
    files = payload.get("files") or []
    if not isinstance(files, list):
        raise HTTPException(status_code=400, detail="files must be an array.")
    try:
        zip_bytes = files_to_zip(files, root=root)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    name_root = _UNSAFE_FILENAME_CHARS.sub("_", root.strip("/")).strip("._") or "agent"
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{name_root}-config-playground.zip"'},
    )


def _export_run(stream_id: str) -> Response:
    live = require_live(stream_id)
    run = live.finished_run
    if run is None:
        raise HTTPException(status_code=404, detail="Playground run not found or not completed")
    return Response(
        content=json.dumps(run.model_dump(), default=str).encode("utf-8"),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="playground_run_{live.stream_id[:8]}.json"'},
    )


async def playground_export(payload: dict[str, Any] | None = None, stream_id: str | None = None) -> Response:
    """Export the edited playground bundle (JSON body), or a completed run (``?stream_id=``)."""
    if payload is not None:
        return _export_bundle(payload)
    if stream_id:
        return _export_run(stream_id)
    raise HTTPException(status_code=400, detail="stream_id or edited bundle payload required for export")
