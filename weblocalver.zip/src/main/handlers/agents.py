"""Agent discovery and configuration handlers."""

from __future__ import annotations

from fastapi import HTTPException

from core.config import Config
from dependencies import RegistryDep

def list_agents(registry: RegistryDep, include_disabled: bool = False) -> dict:
    """List registered agents: enabled ones by default, disabled too with ``include_disabled=true``."""
    return {"agents": registry.list_agents(include_disabled=include_disabled)}


def agent_target(agent_id: str, registry: RegistryDep) -> dict:
    """Show resolved target wiring for one agent (no secrets)."""
    try:
        agent = registry.get(agent_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc.args[0]) if exc.args else str(exc)) from exc

    target = agent.dataset.target
    base_url = (Config.resolve_agent_base_url(agent_id, agent.config.base_url) or "").rstrip("/")
    endpoint = target.endpoint
    return {
        "agent_id": agent.config.agent_id,
        "dataset_id": agent.dataset.dataset_id,
        "dataset_version": agent.dataset.version,
        "adapter": target.adapter,
        "base_url": base_url,
        "endpoint": endpoint,
        "request_url": f"{base_url}{endpoint}",
        "method": target.method,
        "trust_env": target.trust_env,
        "timeout": target.timeout,
        "headers_configured": sorted((target.headers or {}).keys()),
        "auth_type": (target.auth or {}).get("type"),
        "response_output_path": target.response.output_path,
        "response_error_path": target.response.error_path,
        "walkthrough_upload_url": (f"{base_url}/qna/upload" if target.adapter == "walkthrough_http" else None),
    }
