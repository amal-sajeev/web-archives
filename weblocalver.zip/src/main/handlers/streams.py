"""Live-run stream handlers: list, SSE stream, polling events, cancel."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator

from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse

from core.run_manager import DONE, LiveRun, run_manager

from ._common import check_range, require_live

_KEEPALIVE_SECONDS = 15.0
_SSE_HEADERS = {
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}
ALREADY_FINISHED_DETAIL = "Run already finished"
CANCEL_REQUESTED = "cancel_requested"


def evaluate_streams() -> dict:
    """List active and recently finished evaluation streams."""
    return {"streams": run_manager.list_runs()}


async def evaluate_cancel(stream_id: str) -> dict:
    """Request cancellation of an in-flight run (202). 409 if it already finished.

    The run's own task publishes ``run_cancelled`` and finishes the stream.
    """
    live = require_live(stream_id)
    if live.done:
        raise HTTPException(status_code=409, detail=ALREADY_FINISHED_DETAIL)
    live.request_cancel()
    if live.task and not live.task.done():
        live.task.cancel()
    return {"stream_id": stream_id, "status": CANCEL_REQUESTED}


async def evaluate_stream_events(stream_id: str, after: int = 0) -> dict:
    """Polling fallback: events published after index ``after`` (0-based, >= 0)."""
    check_range("after", after, 0)
    live = require_live(stream_id)
    return {
        "stream_id": stream_id,
        "events": live.events[after:],
        "seq": len(live.events),
        "done": live.done,
        "run_id": live.run_id,
    }


async def _sse_events(live: LiveRun, request: Request) -> AsyncIterator[str]:
    subscriber = live.subscribe()
    try:
        yield "retry: 1000\n\n"
        while not await request.is_disconnected():
            try:
                event = await asyncio.wait_for(subscriber.get(), timeout=_KEEPALIVE_SECONDS)
            except TimeoutError:
                yield ": keep-alive\n\n"
                continue
            if event is DONE:
                break
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
    finally:
        live.unsubscribe(subscriber)


async def evaluate_stream(stream_id: str, request: Request) -> StreamingResponse:
    """Stream evaluation progress as Server-Sent Events (replays history first)."""
    live = require_live(stream_id)
    return StreamingResponse(_sse_events(live, request), media_type="text/event-stream", headers=_SSE_HEADERS)
