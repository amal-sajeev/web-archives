"""``POST /api/playground/validate``: check a bundle without starting an evaluation."""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from typing import Any

from fastapi import UploadFile

from core.playground import _cleanup_scoped_registry, _load_scoped_registry, extract_to_temp, inspect_bundle
from core.structured_logging import get_logger

_log = get_logger("eval_service.handlers.playground")
_SENSITIVE_PREFIXES = (".git/", ".env")


@dataclass
class _CustomTestsCheck:
    loaded: list[str] = field(default_factory=list)
    collisions: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def _structure_errors(data: dict) -> list[str]:
    agent = data.get("agent") or {}
    dataset = data.get("dataset") or {}
    checks = [
        (agent.get("agent_id"), "agent.yaml is missing agent_id."),
        (agent.get("name"), "agent.yaml is missing name."),
        (dataset.get("cases"), "Dataset contains no cases."),
        (dataset.get("metrics"), "Dataset contains no metrics."),
    ]
    errors = [message for present, message in checks if not present]
    errors.extend(
        f"Sensitive or repository metadata file should not be included: {item['path']}"
        for item in data.get("files", [])
        if item.get("path", "").startswith(_SENSITIVE_PREFIXES)
    )
    return errors


def _check_custom_tests(blob: bytes, filename: str | None, declared: list[str]) -> _CustomTestsCheck:
    """Load custom_tests.py in a scoped registry and report collisions / missing scorers."""
    result = _CustomTestsCheck()
    temp_dir = None
    registry = None
    try:
        temp_dir, _ = extract_to_temp(blob, filename=filename)
        registry, result.loaded, result.collisions = _load_scoped_registry(temp_dir)
    except Exception as exc:
        _log.info("playground_custom_tests_load_failed", extra={"error_type": type(exc).__name__})
        result.errors.append(f"custom_tests.py could not be loaded: {type(exc).__name__}: {exc}")
        return result
    finally:
        if registry is not None:
            _cleanup_scoped_registry(registry)
        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
    result.errors.extend(f"custom_tests.py overrides an existing scorer: {name}" for name in result.collisions)
    # A collision did register (it replaced a built-in), so it is reported once, above.
    missing = sorted(set(declared) - set(result.loaded) - set(result.collisions))
    if missing:
        result.errors.append(f"custom_tests.py did not register declared scorer(s): {', '.join(missing)}")
    return result


async def playground_validate(file: UploadFile) -> dict[str, Any]:
    """Validate an uploaded/edited configuration without starting an evaluation."""
    blob = await file.read()
    try:
        data = inspect_bundle(blob, filename=file.filename)
    except ValueError as exc:
        return {"valid": False, "errors": [str(exc)]}
    custom = data.get("custom_tests", {}) or {}
    declared = custom.get("declared_scorers", [])
    check = _check_custom_tests(blob, file.filename, declared)
    errors = _structure_errors(data) + check.errors
    return {
        "valid": not errors,
        "errors": errors,
        "agent": (data.get("agent") or {}).get("agent_id"),
        "dataset": (data.get("dataset") or {}).get("dataset_id"),
        "custom_tests": {
            "present": bool(custom.get("present")),
            "declared_scorers": declared,
            "loaded_scorers": check.loaded,
            "collisions": check.collisions,
        },
    }
