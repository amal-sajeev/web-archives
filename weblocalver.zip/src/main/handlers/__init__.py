"""Request handlers organized by functional domain.

Every handler is a plain (async) function that takes its collaborators as
explicit arguments; ``api_routes`` registers them and FastAPI injects the
collaborators through the ``Annotated[..., Depends(...)]`` markers.
"""

from .agents import agent_target, list_agents
from .captures import add_label, get_capture, get_label, list_captures, list_labels
from .evaluate import (
    _drive_run,
    evaluate,
    evaluate_ab,
    evaluate_async,
    evaluate_cancel,
    evaluate_start,
    evaluate_stream,
    evaluate_stream_events,
    evaluate_streams,
)
from .health import health, livez, readyz
from .playground import (
    _drive_playground_run,
    playground_environment,
    playground_export,
    playground_http,
    playground_inspect,
    playground_start,
    playground_validate,
)
from .runs import compare_runs, export_run, get_run, list_runs, promote_baselines, runs_summary
from .settings import runtime_settings, set_tls_policy
from .ui import apitester_html, index, playground_html, run_detail_html, run_html

__all__ = [
    "_drive_playground_run",
    "_drive_run",
    "add_label",
    "agent_target",
    "apitester_html",
    "compare_runs",
    "evaluate",
    "evaluate_ab",
    "evaluate_async",
    "evaluate_cancel",
    "evaluate_start",
    "evaluate_stream",
    "evaluate_stream_events",
    "evaluate_streams",
    "export_run",
    "get_capture",
    "get_label",
    "get_run",
    "health",
    "index",
    "list_agents",
    "list_captures",
    "list_labels",
    "list_runs",
    "livez",
    "playground_environment",
    "playground_export",
    "playground_html",
    "playground_http",
    "playground_inspect",
    "playground_start",
    "playground_validate",
    "promote_baselines",
    "readyz",
    "run_detail_html",
    "run_html",
    "runs_summary",
    "runtime_settings",
    "set_tls_policy",
]
