"""Utility functions for static content loading and minimal PDF output."""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from core.config import Config

_GIT_TIMEOUT_SECONDS = 10

# Minimal PDF layout: US Letter, Helvetica 10pt, 14pt leading.
_PAGE_WIDTH, _PAGE_HEIGHT = 612, 792
_TOP_Y, _LEADING = 750, 14
_LINES_PER_PAGE = 48
_MAX_LINE_CHARS = 200


def load_static_text(filename: str) -> str:
    """Load a static file from disk, falling back to ``git show`` when unreadable."""
    path = Config.STATIC_DIR / filename
    try:
        return path.read_text(encoding="utf-8")
    except PermissionError:
        git = shutil.which("git")
        if git is None:
            raise
        repo_root = Path(__file__).resolve().parents[3]
        result = subprocess.run(  # noqa: S603 - fixed argv, resolved git path
            [git, "show", f"HEAD:dbaware-evaluation-service/src/main/static/{filename}"],
            cwd=str(repo_root),
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=_GIT_TIMEOUT_SECONDS,
        )
        return result.stdout


def render_static_html(filename: str) -> bytes:
    """Load and version-stamp static HTML files."""
    html = load_static_text(filename)
    html = html.replace("__ASSET_VERSION__", Config.SERVICE_VERSION)
    return html.encode("utf-8")


def _pdf_escape(line: str) -> str:
    """Truncate, then escape a line for a PDF literal string (backslash first)."""
    text = line[:_MAX_LINE_CHARS]
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _page_stream(lines: list[str]) -> bytes:
    parts = ["BT", "/F1 10 Tf", f"72 {_TOP_Y} Td"]
    for i, line in enumerate(lines):
        if i > 0:
            parts.append(f"0 -{_LEADING} Td")
        parts.append(f"({_pdf_escape(line)}) Tj")
    parts.append("ET")
    return "\n".join(parts).encode("latin-1", errors="replace")


def _paginate(text_lines: list[str]) -> list[list[str]]:
    pages = [text_lines[i:i + _LINES_PER_PAGE] for i in range(0, len(text_lines), _LINES_PER_PAGE)]
    return pages or [[]]


def _pdf_objects(pages: list[list[str]]) -> list[bytes]:
    """Catalog, Pages, Font, then one (Page, Contents) pair per page."""
    n = len(pages)
    kids = " ".join(f"{4 + 2 * i} 0 R" for i in range(n))
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        f"<< /Type /Pages /Kids [{kids}] /Count {n} >>".encode("latin-1"),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    for i, page in enumerate(pages):
        content = _page_stream(page)
        objects.append(
            f"<< /Type /Page /MediaBox [0 0 {_PAGE_WIDTH} {_PAGE_HEIGHT}] /Parent 2 0 R "
            f"/Resources << /Font << /F1 3 0 R >> >> /Contents {5 + 2 * i} 0 R >>".encode("latin-1")
        )
        objects.append(
            f"<< /Length {len(content)} >>".encode("latin-1") + b"\nstream\n" + content + b"\nendstream"
        )
    return objects


def build_text_pdf(text_lines: list[str] | str) -> bytes:
    """Build a minimal valid multi-page PDF with text (stdlib only).

    A plain string is split into lines; iterating it directly would put every
    character on its own line.
    """
    if isinstance(text_lines, str):
        text_lines = text_lines.splitlines()
    objects = _pdf_objects(_paginate(text_lines))
    pdf = b"%PDF-1.4\n"
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(pdf))
        pdf += f"{i} 0 obj\n".encode("latin-1") + obj + b"\nendobj\n"
    xref_offset = len(pdf)
    pdf += f"xref\n0 {len(objects) + 1}\n".encode("latin-1")
    pdf += b"0000000000 65535 f \n"
    for offset in offsets:
        pdf += f"{offset:010d} 00000 n \n".encode("latin-1")
    pdf += (f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF").encode("latin-1")
    return pdf
