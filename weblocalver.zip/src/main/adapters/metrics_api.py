"""Metrics adapter.

`MetricsClient.fetch(case_id) -> {metric_name: value}`. Two implementations:
- StubMetricsClient reads an agent's metrics_stub.json (default until the real
  metrics API is available).
- HttpMetricsClient hits the real API when METRICS_API_BASE is configured.
Swapping is one config flag; scorers never change.

The metrics API speaks in `CTA_ACTION` records — a logged AI action with a rich
`payload` (model config, confidence, tokens, tool calls, execution times). This
adapter flattens one CTA_ACTION into the flat numeric metric map the scorers and
gate consume, deriving latency/tool aggregates from the raw fields.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, UTC
from pathlib import Path
from typing import Any

import httpx

from core.config import Config
from core.models import Observation
from service.http_client import build_async_client_kwargs

_log = logging.getLogger("eval_service.adapters.metrics")

VALID_SOURCES = frozenset({"capture", "http", "stub"})
_HTTP_TIMEOUT = 30.0

# Timestamp formats seen on Execution_Start_Time / Execution_End_Time.
_TS_FORMATS = (
    "%Y-%m-%d %H:%M:%S:%f",
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S.%f%z",
    "%Y-%m-%dT%H:%M:%S%z",
)


def _num(value: Any) -> float | None:
    """Coerce a possibly-stringy numeric field to float; blanks -> None."""
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_ts(value: Any) -> datetime | None:
    """Parse a timestamp; aware values are converted to UTC, naive ones are taken as UTC."""
    if not value:
        return None
    for fmt in _TS_FORMATS:
        try:
            parsed = datetime.strptime(str(value), fmt)
        except ValueError:
            continue
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=UTC)
        return parsed.astimezone(UTC)
    return None


def _tool_aggregates(tool_calls: Any) -> dict[str, float]:
    call_count = latency_total = error_count = 0.0
    for call in tool_calls if isinstance(tool_calls, list) else []:
        if not isinstance(call, dict):
            continue
        call_count += _num(call.get("Call_Count")) or 0.0
        latency_total += _num(call.get("Tool_Latency")) or 0.0
        error_count += len([e for e in (call.get("Tool_Errors") or []) if e])
    return {
        "tool_call_count": call_count,
        "tool_latency_total": latency_total,
        "tool_error_count": error_count,
    }


def derive_metrics(action: dict[str, Any]) -> dict[str, float]:
    """Flatten a single CTA_ACTION into the numeric metric map used downstream.

    Shared by the stub, HTTP and capture clients so scorers see identical keys.
    """
    payload = action.get("payload") if isinstance(action, dict) else None
    payload = payload if isinstance(payload, dict) else {}
    direct = {
        "ai_confidence_score": _num(payload.get("AI_Confidence_Score")),
        "token_input_count": _num(payload.get("Token_Input_Count")),
        "token_output_count": _num(payload.get("Token_Output_Count")),
        "response_code": _num(payload.get("Response_Code")),
    }
    metrics = {k: v for k, v in direct.items() if v is not None}
    tin, tout = metrics.get("token_input_count"), metrics.get("token_output_count")
    if tin is not None and tout is not None:
        metrics["token_total_count"] = tin + tout
    start = _parse_ts(payload.get("Execution_Start_Time"))
    end = _parse_ts(payload.get("Execution_End_Time"))
    if start and end:
        metrics["execution_latency_ms"] = (end - start).total_seconds() * 1000.0
    metrics.update(_tool_aggregates(payload.get("Tool_Calls")))
    return metrics


def extract_action(entry: Any) -> dict[str, Any]:
    """Accept a CTA_ACTION envelope, a bare record, or a single nested wrapper.

    Supported shapes:
      {"CTA_ACTION": {...}}
      {"payload": {...}, ...}
      {"<agent_id>": {"payload": {...}}}   # walkthrough-style stub
    """
    if not isinstance(entry, dict):
        return {}
    if isinstance(entry.get("CTA_ACTION"), dict):
        return entry["CTA_ACTION"]
    if "payload" in entry:
        return entry
    if len(entry) == 1:
        inner = next(iter(entry.values()))
        if isinstance(inner, dict):
            return extract_action(inner)
    return entry


_extract_action = extract_action  # backward-compatible name


class StubMetricsClient:
    def __init__(self, stub_path: Path | None):
        self._by_case: dict[str, Any] = {}
        if stub_path is None or not stub_path.exists():
            return
        try:
            data = json.loads(stub_path.read_text(encoding="utf-8"))
        except ValueError as exc:  # corrupt JSON or not UTF-8: same as an unusable stub
            _log.warning("metrics stub %s is not valid JSON (%s); ignoring it", stub_path, exc)
            return
        if not isinstance(data, dict):
            _log.warning("metrics stub %s is not a JSON object; ignoring it", stub_path)
            return
        # stub file: {"cases": {case_id: <CTA_ACTION envelope or record>}}
        cases = data.get("cases", data)
        self._by_case = cases if isinstance(cases, dict) else {}

    async def fetch(self, case_id: str, observation: Observation | None = None) -> dict[str, float]:
        entry = self._by_case.get(case_id)
        if not entry:
            return {}
        return derive_metrics(extract_action(entry))


class HttpMetricsClient:
    def __init__(self, base_url: str):
        self._base = base_url.rstrip("/")

    async def fetch(self, case_id: str, observation: Observation | None = None) -> dict[str, float]:
        """Fetch metrics for one case; failures are logged and yield ``{}``."""
        kwargs = build_async_client_kwargs(timeout=_HTTP_TIMEOUT, trust_env=True)
        try:
            async with httpx.AsyncClient(**kwargs) as client:
                resp = await client.get(f"{self._base}/metrics", params={"case_id": case_id})
                resp.raise_for_status()
                return derive_metrics(extract_action(resp.json()))
        except (httpx.HTTPError, ValueError) as exc:
            _log.warning("metrics_fetch_failed", extra={"case_id": case_id, "error": str(exc)})
            return {}


def resolve_source(source_override: str | None = None) -> str:
    """Return the effective metrics source, validating it."""
    source = (source_override or Config.METRICS_SOURCE or "").strip().lower()
    if not source:
        return "http" if Config.METRICS_API_BASE else "stub"
    if source not in VALID_SOURCES:
        raise ValueError(
            f"Invalid metrics source '{source}'; expected one of {sorted(VALID_SOURCES)}."
        )
    return source


def build_metrics_client(
    stub_path: Path | None,
    source_override: str | None = None,
    agent_id: str | None = None,
) -> Any:
    """Select the metrics source: capture (live) | http | stub.

    - capture: derive a CTA_ACTION from each live agent Observation.
    - http: the real CTA_ACTION metrics API (METRICS_API_BASE).
    - stub: the agent's metrics_stub.json.

    ``source_override`` (from agent.yaml) takes precedence over METRICS_SOURCE.
    ``agent_id`` scopes captured records so agents never share a case entry.
    """
    source = resolve_source(source_override)
    if source == "capture":
        from .capture import CaptureMetricsClient, capture_store

        return CaptureMetricsClient(capture_store, agent_id=agent_id)
    if source == "http":
        if not Config.METRICS_API_BASE:
            raise RuntimeError("METRICS_SOURCE=http requires METRICS_API_BASE to be set.")
        return HttpMetricsClient(Config.METRICS_API_BASE)
    return StubMetricsClient(stub_path)
