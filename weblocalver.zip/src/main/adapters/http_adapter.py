"""Config-driven HTTP target adapter.

Describes the HTTP request and response mapping entirely from ``TargetSpec``
config (in ``dataset.json``), so an engineer can wire up a call to any agent
service without writing Python. Supports:

- Any HTTP method (GET/POST/PUT/PATCH/DELETE).
- Headers (static or templated from env/input).
- Auth (bearer / basic / api_key_header / api_key_query) — secrets from env only.
- Query params and body templated from ``case.input`` and env vars.
- Response mapping via dotted paths into JSON (or raw text) into the
  ``Observation`` envelope.
- Document content types (pdf/docx/markdown/json) with automatic text
  extraction so all scorers work on documents out of the box.

Template syntax: ``${env.VAR_NAME}`` and ``${input.dotted.path}``. The pieces
live in ``templating``, ``http_request``, ``http_response`` and ``registry``;
this module keeps the historical import names working.
"""

from __future__ import annotations

import logging
import time

import httpx

from core.models import GoldenCase, Observation, TargetSpec
from service.http_client import build_async_client_kwargs
from .http_request import build_headers, build_params, build_request_kwargs
from .http_response import error_observation, map_response
from .registry import get_registered_adapter, register_adapter
from .templating import dotted, path_parts, resolve_template

_DEFAULT_TIMEOUT = 120.0
_log = logging.getLogger("eval_service.adapters.http")

# Backward-compatible aliases (custom_tests.py and older tests import these).
_resolve_template = resolve_template
_dotted = dotted
_path_parts = path_parts
_build_headers = build_headers
_build_params = build_params

__all__ = [
    "HttpAdapter",
    "get_registered_adapter",
    "register_adapter",
]


def _elapsed_ms(start: float) -> int:
    return int((time.perf_counter() - start) * 1000)


class HttpAdapter:
    """Config-driven HTTP adapter — calls any agent HTTP endpoint.

    Selected by ``dataset.target.adapter: "http"``. All request/response
    details come from the ``TargetSpec`` in ``dataset.json``.
    """

    adapter_id = "http"

    def __init__(self, base_url: str, endpoint: str, target: TargetSpec | None = None):
        self._base_url = base_url.rstrip("/")
        self._endpoint = endpoint
        self._target = target or TargetSpec(adapter="http", endpoint=endpoint)

    async def run_case(self, case: GoldenCase) -> Observation:
        target = self._target
        url = f"{self._base_url}{self._endpoint}"
        client_kwargs = build_async_client_kwargs(
            timeout=target.timeout or _DEFAULT_TIMEOUT, trust_env=target.trust_env
        )
        start = time.perf_counter()
        try:
            request_kwargs = build_request_kwargs(target, case.input or {})
            async with httpx.AsyncClient(**client_kwargs) as client:
                resp = await client.request(target.method.upper(), url, **request_kwargs)
                resp.raise_for_status()
            return map_response(resp, case, target.response, _elapsed_ms(start))
        except Exception as exc:  # every failure becomes an error Observation
            _log.warning("http_target_failed", extra={"case_id": case.id, "error_type": type(exc).__name__})
            return error_observation(case.id, exc, _elapsed_ms(start))
