"""Target adapter: replays a golden input against the agent's production API.

The default adapter talks to a hosted agent-service `/api/eval/*` hook
(non-mutating), which returns the standard Observation envelope. New agents
can register alternative adapters via ``@register_adapter`` without touching
the runner.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import httpx

from core.config import Config
from core.models import Dataset, GoldenCase, Observation, TargetSpec
from service.http_client import build_async_client_kwargs
from .http_response import error_observation
from .registry import get_registered_adapter

_log = logging.getLogger("eval_service.adapters.target")

_EVAL_HOOK_TIMEOUT = 120.0
# The summary agent runs several Gemini generations over large plan payloads.
_SCOPING_TIMEOUT = 600.0
_SCOPING_MODEL = "gemini-2.5-pro"


class _JsonPostAdapter:
    """Shared plumbing: POST a JSON payload, honouring TargetSpec timeout/trust_env."""

    adapter_id = ""
    default_timeout = _EVAL_HOOK_TIMEOUT

    def __init__(self, base_url: str, endpoint: str, target: TargetSpec | None = None):
        self._base_url = base_url.rstrip("/")
        self._endpoint = endpoint
        self._target = target or TargetSpec(adapter=self.adapter_id, endpoint=endpoint)

    def _client_kwargs(self) -> dict[str, Any]:
        # trust_env defaults to False so a corporate HTTP(S)_PROXY does not
        # intercept calls to localhost agents.
        return build_async_client_kwargs(
            timeout=self._target.timeout or self.default_timeout,
            trust_env=self._target.trust_env,
        )

    async def _post(self, payload: Any) -> Any:
        url = f"{self._base_url}{self._endpoint}"
        async with httpx.AsyncClient(**self._client_kwargs()) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            return resp.json()


def _failed(case: GoldenCase, exc: Exception, start: float) -> Observation:
    _log.warning("target_call_failed", extra={"case_id": case.id, "error_type": type(exc).__name__})
    return error_observation(case.id, exc, int((time.perf_counter() - start) * 1000))


class AgentEvalHookAdapter(_JsonPostAdapter):
    """Calls a POST /api/eval/* endpoint on the agent service."""

    adapter_id = "agent_eval_hook"

    async def run_case(self, case: GoldenCase) -> Observation:
        start = time.perf_counter()
        try:
            return Observation.model_validate(await self._post(case.input))
        except Exception as exc:
            return _failed(case, exc, start)


def _report_tool_calls(report: Any) -> list[dict[str, Any]]:
    """One synthetic "generate_report" tool call per report in the bundle."""
    if not isinstance(report, dict):
        return []
    calls = []
    for key, rep in report.items():
        rep_dict = rep if isinstance(rep, dict) else {}
        paras = rep_dict.get("paragraphs")
        calls.append({
            "name": "generate_report",
            "args": {"report": key, "title": rep_dict.get("report_title")},
            "paragraphs": len(paras) if isinstance(paras, list) else None,
        })
    return calls


class ScopingAnalyticsAdapter(_JsonPostAdapter):
    """Adapter for the Scoping Analytics / Summary agent.

    That agent exposes `POST /run-analytics-agent` taking `{planNumber, planName}`
    and returns `{plan_number, plan_name, session_id, analysis_report: {...}}`
    where each report is `{report_title, paragraphs:[…]}`. The report bundle
    becomes ``observation.output``.
    """

    adapter_id = "scoping_analytics"
    default_timeout = _SCOPING_TIMEOUT

    async def run_case(self, case: GoldenCase) -> Observation:
        inp = case.input or {}
        payload = {
            "planNumber": inp.get("planNumber") or inp.get("plan_number"),
            "planName": inp.get("planName") or inp.get("plan_name"),
        }
        start = time.perf_counter()
        try:
            data = await self._post(payload)
        except Exception as exc:
            return _failed(case, exc, start)
        latency_ms = int((time.perf_counter() - start) * 1000)
        body = data if isinstance(data, dict) else {}
        report = body.get("analysis_report", data) if body else data
        tool_calls = _report_tool_calls(report)
        return Observation(
            target_id=case.id,
            output=report,
            tool_calls=tool_calls,
            latency_ms=latency_ms,
            model=_SCOPING_MODEL,
            metadata={
                "plan_number": body.get("plan_number"),
                "plan_name": body.get("plan_name"),
                "session_id": body.get("session_id"),
                "report_count": len(tool_calls),
            },
        )


# Built-in adapters keyed by `adapter_id`; checked before custom registrations.
_BUILTIN_ADAPTERS: dict[str, type] = {
    AgentEvalHookAdapter.adapter_id: AgentEvalHookAdapter,
    ScopingAnalyticsAdapter.adapter_id: ScopingAnalyticsAdapter,
}


def _adapter_class(adapter_id: str) -> type:
    if adapter_id == "http":
        from .http_adapter import HttpAdapter  # lazy: keeps the module patchable

        return HttpAdapter
    cls = _BUILTIN_ADAPTERS.get(adapter_id) or get_registered_adapter(adapter_id)
    if cls is None:
        known = sorted({"http", *_BUILTIN_ADAPTERS})
        raise ValueError(
            f"Unknown target adapter '{adapter_id}'. Built-ins: {known}; "
            "custom adapters must be registered with @register_adapter."
        )
    return cls


def build_target_adapter(dataset: Dataset, base_url: str | None = None) -> Any:
    """Select and construct the target adapter from ``dataset.target``.

    Order: ``http`` and the built-in Python adapters first, then adapters
    registered via ``@register_adapter`` in an agent's ``custom_tests.py``.
    Raises ``ValueError`` for an unknown adapter id or a missing base URL.
    """
    target = dataset.target
    cls = _adapter_class(target.adapter)
    base = base_url or Config.AGENT_SERVICE_BASE_URL
    if not base:
        raise ValueError(
            f"No base URL for dataset '{dataset.dataset_id}': set base_url in agent.yaml "
            "or AGENT_SERVICE_BASE_URL."
        )
    return cls(base, target.endpoint, target)
