"""Request building for the config-driven HTTP adapter (headers, auth, params, body)."""

from __future__ import annotations

import base64
import json
import logging
import os
from typing import Any

from core.models import AuthSpec, TargetSpec
from .templating import resolve_template, resolve_text_map

_log = logging.getLogger("eval_service.adapters.http")

_BODY_METHODS = frozenset({"POST", "PUT", "PATCH"})
_CONTENT_TYPE = "Content-Type"
_AUTHORIZATION = "Authorization"
_SUPPORTED_AUTH = frozenset({"bearer", "basic", "api_key_header", "api_key_query"})


def _env(name: str) -> str:
    return os.environ.get(name, "") if name else ""


def _auth_token(auth: AuthSpec) -> str | None:
    """Return the auth token from env, warning when it is missing."""
    token = _env(auth.token_env)
    if not token:
        _log.warning("auth type '%s' configured but env var '%s' is empty", auth.type, auth.token_env)
        return None
    return token


def _check_auth(auth: AuthSpec | None) -> AuthSpec | None:
    if auth is None:
        return None
    if auth.type not in _SUPPORTED_AUTH:
        _log.warning("unsupported or empty auth type %r; no auth applied", auth.type)
        return None
    return auth


def _basic_header(auth: AuthSpec) -> str | None:
    user, pwd = _env(auth.username_env), _env(auth.password_env)
    if not user and not pwd:
        _log.warning("basic auth configured but username/password env vars are empty")
        return None
    cred = base64.b64encode(f"{user}:{pwd}".encode()).decode()
    return f"Basic {cred}"


def build_headers(target: TargetSpec, case_input: dict[str, Any]) -> dict[str, str]:
    """Templated headers plus header-based auth (bearer / basic / api_key_header)."""
    headers = resolve_text_map(target.headers, case_input)
    auth = _check_auth(target.auth)
    if auth is None or auth.type == "api_key_query":
        return headers
    if auth.type == "basic":
        value = _basic_header(auth)
        if value:
            headers[_AUTHORIZATION] = value
        return headers
    token = _auth_token(auth)
    if token and auth.type == "bearer":
        headers[_AUTHORIZATION] = f"Bearer {token}"
    elif token:
        headers[auth.header or "X-API-Key"] = token
    return headers


def build_params(target: TargetSpec, case_input: dict[str, Any]) -> dict[str, str] | None:
    """Templated query params plus the ``api_key_query`` auth parameter."""
    params = resolve_text_map(target.params, case_input) if target.params else {}
    auth = _check_auth(target.auth)
    if auth is not None and auth.type == "api_key_query":
        token = _auth_token(auth)
        if token:
            params[auth.param or "api_key"] = token
    return params or None


def _text(value: Any) -> str:
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)


def _body_kwargs(target: TargetSpec, case_input: dict[str, Any]) -> tuple[dict[str, Any], str | None]:
    """Return (httpx body kwargs, explicit Content-Type or None)."""
    if target.body is None:
        return {"json": case_input}, None
    body = resolve_template(target.body, case_input)
    btype = target.body_type
    if btype == "form":
        if isinstance(body, dict):
            return {"data": body}, None
        return {"content": _text(body)}, "application/x-www-form-urlencoded"
    if btype == "text":
        return {"content": _text(body)}, "text/plain"
    if btype == "raw":
        raw = body if isinstance(body, bytes | str) else _text(body)
        return {"content": raw}, None
    return {"json": body}, None


def _has_header(headers: dict[str, str], name: str) -> bool:
    lowered = name.lower()
    return any(k.lower() == lowered for k in headers)


def build_request_kwargs(target: TargetSpec, case_input: dict[str, Any]) -> dict[str, Any]:
    """Build ``client.request`` kwargs. Bodyless methods get no body or Content-Type."""
    headers = build_headers(target, case_input)
    kwargs: dict[str, Any] = {"headers": headers, "params": build_params(target, case_input)}
    if target.method.upper() not in _BODY_METHODS:
        return kwargs
    body_kwargs, content_type = _body_kwargs(target, case_input)
    kwargs.update(body_kwargs)
    if content_type and not _has_header(headers, _CONTENT_TYPE):
        headers[_CONTENT_TYPE] = content_type
    return kwargs
