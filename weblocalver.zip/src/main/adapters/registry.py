"""Adapter registry — the Python escape hatch for non-HTTP agents."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TypeVar

_log = logging.getLogger("eval_service.adapters")

_ADAPTER_REGISTRY: dict[str, type] = {}

T = TypeVar("T", bound=type)


def _origin(cls: type) -> str:
    return f"{cls.__module__}.{cls.__qualname__}"


def register_adapter(adapter_id: str) -> Callable[[T], T]:
    """Decorator: register a custom Python target adapter.

    Used in an agent's ``custom_tests.py`` to add an adapter that can't be
    described by the config-driven ``http`` adapter — e.g. a direct SDK call,
    gRPC, or a local function.

    The adapter class must accept ``(base_url, endpoint, target)`` and implement
    ``async def run_case(self, case: GoldenCase) -> Observation``.
    """

    def _wrap(cls: T) -> T:
        existing = _ADAPTER_REGISTRY.get(adapter_id)
        if existing is not None and _origin(existing) != _origin(cls):
            _log.warning("adapter '%s' re-registered: %s replaces %s", adapter_id, cls, existing)
        _ADAPTER_REGISTRY[adapter_id] = cls
        return cls

    return _wrap


def get_registered_adapter(adapter_id: str) -> type | None:
    return _ADAPTER_REGISTRY.get(adapter_id)
