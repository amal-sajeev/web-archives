"""Document text-extraction layer.

Agents may return documents (PDF, DOCX, Markdown, JSON) rather than plain text.
This module extracts readable text from each supported kind so that the existing
scorers (token overlap, edit/embedding similarity, every LLM judge) and the new
configurable scorers operate on the *content*, not on raw base64/bytes.

Extraction is done **once** when the observation is received; the result is stored
in ``observation.metadata["extracted_text"]`` so every downstream scorer reuses
the same text without re-parsing.

PDF support uses ``pypdf`` and DOCX support uses ``python-docx``. Both are
imported lazily; if the library is absent the caller raises ``MetricSkipped``
(clean omit, matching the Vertex-offline contract) — text/markdown/json always
work with no extra dependency.
"""

from __future__ import annotations

import base64
import binascii
import io
import json
import logging
import re
from typing import Any

_log = logging.getLogger("eval_service.adapters.documents")

# Sniffing heuristics for ``content_type == "auto"``.
_MAGIC_PDF = b"%PDF"
_MAGIC_PK = b"PK"  # docx (and other zip-based OOXML)


def detect_content_type(value: Any, output_kind: str = "text") -> str:
    """Best-effort detection of the content kind from the raw value."""
    if value is None:
        return "text"
    if isinstance(value, dict | list):
        return "json"
    if isinstance(value, str):
        s = value.lstrip()
        if s.startswith(("{", "[")):
            return "json"
        if s.startswith("%PDF"):
            return "pdf"
        if output_kind in ("base64", "bytes"):
            return _detect_b64_or_bytes(value)
        if s.startswith(("# ", "## ")):
            return "markdown"
        return "text"
    if isinstance(value, bytes | bytearray):
        return _detect_bytes(value)
    return "text"


def _detect_b64_or_bytes(value: str) -> str:
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError):
        return "text"
    return _detect_bytes(raw)


def _detect_bytes(raw: bytes) -> str:
    if raw[:4] == _MAGIC_PDF:
        return "pdf"
    if raw[:2] == _MAGIC_PK:
        return "docx"
    return "text"


class DocUnavailable(Exception):
    """Raised when a document-parsing library is missing.

    The adapter/scorer catches this and converts it to ``MetricSkipped`` so
    document metrics are omitted (not failed) when the lib is absent.
    """


class _ExtractionFailed(Exception):
    """A document could not be decoded or parsed."""


def try_extract_text(
    value: Any,
    content_type: str = "auto",
    *,
    output_kind: str = "text",
    http_client: Any = None,
) -> tuple[str, str | None]:
    """Like :func:`extract_text` but returns ``(text, error)`` instead of hiding failures.

    ``error`` is None on success; on a decode/parse failure the text is ``""``
    and the failure is logged. A missing parser library still raises
    ``DocUnavailable``.
    """
    try:
        return _extract(value, content_type, output_kind, http_client), None
    except _ExtractionFailed as exc:
        _log.warning("document extraction failed (%s): %s", content_type, exc)
        return "", str(exc)


def extract_text(
    value: Any,
    content_type: str = "auto",
    *,
    output_kind: str = "text",
    http_client: Any = None,
) -> str:
    """Extract readable text from an agent output of any supported kind.

    - text / markdown  -> passthrough / syntax stripped.
    - json             -> pretty-printed JSON.
    - pdf              -> pypdf (lazy; text only).
    - docx             -> python-docx (lazy; paragraphs + tables).

    ``output_kind`` describes how ``value`` is encoded: ``text``, ``json``,
    ``base64``, ``bytes``, or ``url`` (fetched via the optional ``http_client``).
    Decode/parse failures are logged and return ``""``.
    """
    text, _ = try_extract_text(value, content_type, output_kind=output_kind, http_client=http_client)
    return text


def _extract(value: Any, content_type: str, output_kind: str, http_client: Any) -> str:
    if value is None:
        return ""
    if content_type == "auto":
        content_type = detect_content_type(value, output_kind)
    if content_type == "pdf":
        return _extract_pdf(value, output_kind, http_client)
    if content_type == "docx":
        return _extract_docx(value, output_kind, http_client)
    value = _as_text(value, output_kind)
    if content_type == "text":
        return str(value)
    if content_type == "markdown":
        return _markdown_to_text(str(value))
    return _json_to_text(value)


def _as_text(value: Any, output_kind: str) -> Any:
    """Decode raw bytes / base64 strings so text-like kinds see characters, not ``b'...'`` or base64."""
    if isinstance(value, bytes | bytearray):
        return bytes(value).decode("utf-8", errors="replace")
    if output_kind == "base64" and isinstance(value, str):
        return _decode_base64(value).decode("utf-8", errors="replace")
    return value


# --------------------------------------------------------------------------- #
# Per-kind extractors
# --------------------------------------------------------------------------- #

def _json_to_text(value: Any) -> str:
    if isinstance(value, dict | list):
        return json.dumps(value, ensure_ascii=False, indent=2, default=str)
    if isinstance(value, str):
        try:
            return json.dumps(json.loads(value), ensure_ascii=False, indent=2)
        except (TypeError, ValueError):
            return value
    return str(value)


def _markdown_to_text(text: str) -> str:
    # Strip common Markdown syntax for cleaner token-overlap/judge comparison.
    text = re.sub(r"```[^\n]*\n?", "", text)  # fenced code blocks
    text = re.sub(r"`([^`]+)`", r"\1", text)  # inline code
    text = re.sub(r"^#{1,6}\s*", "", text, flags=re.M)  # headings -> plain
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)  # bold
    text = re.sub(r"\*([^*]+)\*", r"\1", text)  # italic
    text = re.sub(r"^[-*+]\s+", "", text, flags=re.M)  # bullet markers
    text = re.sub(r"^\d+\.\s+", "", text, flags=re.M)  # numbered list markers
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)  # links -> label
    return text.strip()


def _decode_base64(value: Any) -> bytes:
    if not isinstance(value, str):
        raise _ExtractionFailed("base64 output is not a string")
    try:
        return base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise _ExtractionFailed(f"invalid base64: {exc}") from exc


def _to_bytes(value: Any, output_kind: str, http_client: Any) -> bytes:
    """Resolve ``value`` to raw bytes given its ``output_kind``."""
    if output_kind == "base64":
        return _decode_base64(value)
    if output_kind == "url":
        return _fetch_url(value, http_client)
    if isinstance(value, bytes | bytearray):
        return bytes(value)
    if isinstance(value, str) and output_kind != "bytes":
        return value.encode("utf-8")
    raise _ExtractionFailed(f"cannot read a document from {type(value).__name__} ({output_kind})")


def _fetch_url(url: Any, http_client: Any) -> bytes:
    if not isinstance(url, str) or not http_client:
        raise _ExtractionFailed("url output needs a string URL and an HTTP client")
    try:
        resp = http_client.get(url, follow_redirects=True, timeout=60.0)
        resp.raise_for_status()
    except Exception as exc:
        raise _ExtractionFailed(f"could not fetch {url}: {exc}") from exc
    return resp.content


def _extract_pdf(value: Any, output_kind: str, http_client: Any) -> str:
    raw = _to_bytes(value, output_kind, http_client)
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise DocUnavailable(
            "pypdf is not installed; PDF scorers will be skipped. "
            "Install pypdf to enable PDF support."
        ) from exc
    try:
        pages = [page.extract_text() or "" for page in PdfReader(io_from_bytes(raw)).pages]
    except Exception as exc:
        raise _ExtractionFailed(f"PDF could not be parsed: {exc}") from exc
    return "\n\n".join(p for p in pages if p.strip())


def _docx_parts(document: Any) -> list[str]:
    parts = [para.text for para in document.paragraphs if para.text.strip()]
    for table in document.tables:
        for row in table.rows:
            parts.append("\t".join(c.text.strip() for c in row.cells))
    return parts


def _extract_docx(value: Any, output_kind: str, http_client: Any) -> str:
    raw = _to_bytes(value, output_kind, http_client)
    try:
        import docx
    except ImportError as exc:
        raise DocUnavailable(
            "python-docx is not installed; DOCX scorers will be skipped. "
            "Install python-docx to enable DOCX support."
        ) from exc
    try:
        return "\n\n".join(_docx_parts(docx.Document(io_from_bytes(raw))))
    except Exception as exc:
        raise _ExtractionFailed(f"DOCX could not be parsed: {exc}") from exc


def io_from_bytes(raw: bytes) -> io.BytesIO:
    """Wrap raw bytes in a seekable buffer."""
    return io.BytesIO(raw)


# --------------------------------------------------------------------------- #
# Structural accessors for the document-aware scorers (heading/table checks)
# --------------------------------------------------------------------------- #

def parse_headings(text: str, content_type: str = "auto") -> list[str]:
    """Return heading texts from a document.

    Markdown ``# Heading`` lines yield the heading text; for other content,
    short title-like lines are treated as headings.
    """
    if content_type == "auto":
        content_type = detect_content_type(text, "text")
    if content_type == "markdown":
        return [m.group(2).strip() for m in re.finditer(r"^(#{1,6})\s+(.+)$", text, flags=re.M)]
    # For text/other, treat lines that look like short title lines as headings.
    return re.findall(r"^(#{1,6}\s+.+|[A-Z][A-Za-z0-9 .\-]{2,80})$", text, flags=re.M)


def parse_markdown_sections(text: str) -> dict[str, str]:
    """Split markdown into ``{heading: body}`` by ``#`` headings."""
    sections: dict[str, str] = {}
    current, body = None, []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if m:
            if current is not None:
                sections[current] = "\n".join(body).strip()
            current = m.group(2).strip()
            body = []
        elif current is not None:
            body.append(line)
    if current is not None:
        sections[current] = "\n".join(body).strip()
    return sections
