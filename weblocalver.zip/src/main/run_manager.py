"""In-memory live-run manager: decouples an evaluation run from the browser.

A run is started as a background asyncio task tied to the app event loop, not to
the SSE response generator, so closing the browser tab does NOT cancel it — the
run finishes and still persists to the repository. Every progress event is
buffered on the LiveRun, so a client can (re)connect at any time and replay the
full history before tailing new events. Offline-safe and schema-independent,
mirroring capture_store / label_store.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from typing import Any

# Sentinel pushed to each subscriber queue when a run has finished, so the SSE
# generator can close cleanly.
DONE = object()

# Completed runs are retained this long so a late reconnect can still replay the
# final events, then pruned to bound memory.
_RETAIN_SECONDS = 3600.0


class LiveRun:
    """One evaluation run: a buffer of events + a set of live subscriber queues."""

    def __init__(self, stream_id: str, agent_id: str):
        self.stream_id = stream_id
        self.agent_id = agent_id
        self.events: list[dict[str, Any]] = []
        self.done = False
        self.cancel_requested = False
        self.run_id: str | None = None
        self.finished_at: float | None = None
        self.task: asyncio.Task | None = None
        self._subscribers: set[asyncio.Queue] = set()

    def publish(self, event: dict[str, Any]) -> None:
        """Buffer an event with a monotonic sequence number and fan it out."""
        # A sequence number lets SSE and the polling fallback share one cursor
        # without double-counting events when both transports overlap.
        event = {**event, "seq": len(self.events) + 1}
        self.events.append(event)
        if event.get("type") in {"run_done", "playground_done"}:
            self.run_id = event.get("run_id") or (event.get("run") or {}).get("run_id")
        for q in list(self._subscribers):
            q.put_nowait(event)

    def finish(self) -> None:
        self.done = True
        self.finished_at = time.monotonic()
        for q in list(self._subscribers):
            q.put_nowait(DONE)

    def request_cancel(self) -> bool:
        """Mark cancellation requested and fan out a lifecycle event once."""
        if self.done or self.cancel_requested:
            return False
        self.cancel_requested = True
        self.publish({"type": "run_cancel_requested", "stream_id": self.stream_id})
        return True

    def subscribe(self) -> asyncio.Queue:
        """Return a queue pre-loaded with the buffered history; tails new events."""
        q: asyncio.Queue = asyncio.Queue()
        for event in self.events:
            q.put_nowait(event)
        if self.done:
            q.put_nowait(DONE)
        else:
            self._subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subscribers.discard(q)


class RunManager:
    def __init__(self):
        self._runs: dict[str, LiveRun] = {}

    def create(self, agent_id: str) -> LiveRun:
        self._prune()
        stream_id = uuid.uuid4().hex
        run = LiveRun(stream_id, agent_id)
        self._runs[stream_id] = run
        return run

    def get(self, stream_id: str) -> LiveRun | None:
        self._prune()
        return self._runs.get(stream_id)

    def list_runs(self) -> list[dict[str, Any]]:
        """Return lightweight lifecycle summaries for active/recent streams."""
        self._prune()
        out: list[dict[str, Any]] = []
        for run in self._runs.values():
            out.append(
                {
                    "stream_id": run.stream_id,
                    "agent_id": run.agent_id,
                    "run_id": run.run_id,
                    "done": run.done,
                    "cancel_requested": run.cancel_requested,
                    "event_count": len(run.events),
                    "finished_at": run.finished_at,
                }
            )
        return out

    def _prune(self) -> None:
        now = time.monotonic()
        stale = [
            sid for sid, r in self._runs.items()
            if r.done and r.finished_at is not None and (now - r.finished_at) > _RETAIN_SECONDS
        ]
        for sid in stale:
            self._runs.pop(sid, None)


# Module-level singleton, mirroring capture_store / label_store.
run_manager = RunManager()
