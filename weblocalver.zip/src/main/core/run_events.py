"""Progress events published while a run executes (the SSE / polling payloads)."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any

from core.config import Config
from core.models import CaseResult, Dataset, MetricSpec, Observation, RunRecord, Score
from scorers.base import is_judge_scorer
from scorers.output_text import render_output_text

ProgressFn = Callable[[dict[str, Any]], Awaitable[None]]

# Maximum characters of agent output shown in the live "observation" event.
_PREVIEW_LEN = 600

_log = logging.getLogger("eval_service.runner")


class Emitter:
    """Awaitable wrapper around an optional progress callback."""

    def __init__(self, progress: ProgressFn | None) -> None:
        self._progress = progress

    async def __call__(self, event: dict[str, Any]) -> None:
        if self._progress is not None:
            await self._progress(event)


def output_preview(output: Any) -> str:
    """Readable, truncated rendering of an agent output for the live view."""
    try:
        text = render_output_text(output)
    except Exception:
        _log.warning("output_preview_failed", exc_info=True)
        text = str(output)
    return text if len(text) <= _PREVIEW_LEN else text[:_PREVIEW_LEN] + "…"


def _metric_summary(spec: MetricSpec) -> dict[str, Any]:
    return {
        "name": spec.name,
        "type": spec.type,
        "weight": spec.weight,
        "threshold": spec.threshold,
        "critical": spec.critical,
        "judge": is_judge_scorer(spec.scorer),
    }


def run_started(agent_id: str, dataset: Dataset, total_cases: int, judge_repetitions: int) -> dict[str, Any]:
    return {
        "type": "run_started",
        "agent_id": agent_id,
        "dataset_id": dataset.dataset_id,
        "dataset_version": dataset.version,
        "total_cases": total_cases,
        "concurrency": Config.JUDGE_CONCURRENCY,
        "case_concurrency": Config.CASE_CONCURRENCY,
        "judge_repetitions": judge_repetitions,
        "metrics": [_metric_summary(m) for m in dataset.metrics],
    }


def case_started(case_id: str, index: int, total: int, metric_count: int) -> dict[str, Any]:
    return {
        "type": "case_started",
        "case_id": case_id,
        "index": index,
        "total": total,
        "metric_count": metric_count,
    }


def observation(case_id: str, obs: Observation) -> dict[str, Any]:
    return {
        "type": "observation",
        "case_id": case_id,
        "latency_ms": obs.latency_ms,
        "model": obs.model,
        "tool_calls": len(obs.tool_calls),
        "error": obs.error,
        "output_preview": output_preview(obs.output),
    }


def metric_started(case_id: str, metric: str, judge: bool) -> dict[str, Any]:
    return {"type": "metric_started", "case_id": case_id, "metric": metric, "judge": judge}


def metric_skipped(case_id: str, metric: str, reason: str) -> dict[str, Any]:
    return {"type": "metric_skipped", "case_id": case_id, "metric": metric, "reason": reason}


def metric_done(case_id: str, score: Score, judge: bool) -> dict[str, Any]:
    return {
        "type": "metric_done",
        "case_id": case_id,
        "metric": score.metric,
        "score": score.score,
        "passed": score.passed,
        "threshold": score.threshold,
        "weight": score.weight,
        "critical": score.critical,
        "delta": score.delta,
        "variance": score.variance,
        "unstable": score.unstable,
        "raw_value": score.raw_value,
        "unit": score.unit,
        "rationale": score.rationale,
        "evidence": score.evidence,
        "judge": judge,
    }


def case_done(result: CaseResult, index: int, total: int) -> dict[str, Any]:
    return {
        "type": "case_done",
        "case_id": result.case_id,
        "index": index,
        "total": total,
        "passed": result.passed,
        "weighted_score": result.weighted_score,
        "weighted_delta": result.weighted_delta,
    }


def run_done(run: RunRecord) -> dict[str, Any]:
    return {
        "type": "run_done",
        "run_id": run.run_id,
        "status": run.status,
        "weighted_score": run.weighted_score,
        "weighted_delta": run.weighted_delta,
        "error_detail": run.error_detail,
    }
