"""In-memory live-run manager: decouples an evaluation run from the browser.

A run is started as a background asyncio task tied to the app event loop, not to
the SSE response generator, so closing the browser tab does NOT cancel it — the
run finishes and still persists to the repository. Every progress event is
buffered on the LiveRun, so a client can (re)connect at any time and replay the
full history before tailing new events.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
import uuid
from typing import Any

from core.models import RunRecord
from core.structured_logging import get_logger

# Sentinel pushed to each subscriber queue when a run has finished, so the SSE
# generator can close cleanly.
DONE = object()

# Completed runs are retained this long so a late reconnect can still replay the
# final events, then pruned to bound memory.
_RETAIN_SECONDS = 3600.0

# Extra head-room per subscriber queue beyond the replayed history. A slow
# subscriber loses its oldest undelivered events rather than growing unbounded;
# it can catch up through the seq-based polling endpoint.
_SUBSCRIBER_QUEUE_MAX = 1000

_COMPLETION_EVENTS = frozenset({"run_done", "playground_done"})

# How long application shutdown waits for cancelled runs to persist their
# ERROR ("cancelled") records before the repository is closed.
SHUTDOWN_GRACE_SECONDS = 10.0

_log = get_logger("eval_service.run_manager")


def _offer(q: asyncio.Queue, item: object) -> None:
    """Put without blocking; drop the oldest queued item when the queue is full."""
    try:
        q.put_nowait(item)
    except asyncio.QueueFull:
        with contextlib.suppress(asyncio.QueueEmpty):
            q.get_nowait()
        _log.warning("subscriber_queue_full", extra={"dropped": 1})
        q.put_nowait(item)


class LiveRun:
    """One evaluation run: a buffer of events + a set of live subscriber queues."""

    def __init__(self, stream_id: str, agent_id: str):
        self.stream_id = stream_id
        self.agent_id = agent_id
        self.events: list[dict[str, Any]] = []
        self.done = False
        self.run_id: str | None = None
        self.finished_run: RunRecord | None = None
        self.finished_at: float | None = None
        self.task: asyncio.Task | None = None
        self._cancel_requested = False
        self._subscribers: set[asyncio.Queue] = set()

    @property
    def cancel_requested(self) -> bool:
        """True once a cancel was requested; the runner checks it between cases."""
        return self._cancel_requested

    def set_finished_run(self, run: RunRecord | dict[str, Any] | None) -> None:
        """Remember the completed run (accepts a RunRecord or its dict dump)."""
        if run is None:
            return
        record = run if isinstance(run, RunRecord) else RunRecord.model_validate(run)
        self.finished_run = record
        self.run_id = record.run_id

    def publish(self, event: dict[str, Any]) -> None:
        """Buffer an event with a monotonic sequence number and fan it out."""
        # A sequence number lets SSE and the polling fallback share one cursor
        # without double-counting events when both transports overlap.
        event = {**event, "seq": len(self.events) + 1}
        self.events.append(event)
        if event.get("type") in _COMPLETION_EVENTS:
            self._record_completion(event)
        for q in list(self._subscribers):
            _offer(q, event)

    def _record_completion(self, event: dict[str, Any]) -> None:
        run = event.get("run")
        if run is not None:
            try:
                self.set_finished_run(run)
            except ValueError:
                _log.warning("finished_run_invalid", extra={"stream_id": self.stream_id}, exc_info=True)
        run_id = event.get("run_id") or (run.get("run_id") if isinstance(run, dict) else None)
        if run_id:
            self.run_id = run_id

    def finish(self) -> None:
        self.done = True
        self.finished_at = time.monotonic()
        for q in list(self._subscribers):
            _offer(q, DONE)

    def request_cancel(self) -> bool:
        """Mark cancellation requested and fan out a lifecycle event once."""
        if self.done or self._cancel_requested:
            return False
        self._cancel_requested = True
        self.publish({"type": "run_cancel_requested", "stream_id": self.stream_id})
        return True

    def subscribe(self) -> asyncio.Queue:
        """Return a queue pre-loaded with the buffered history; tails new events."""
        q: asyncio.Queue = asyncio.Queue(maxsize=len(self.events) + _SUBSCRIBER_QUEUE_MAX)
        for event in self.events:
            q.put_nowait(event)
        if self.done:
            q.put_nowait(DONE)
        else:
            self._subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subscribers.discard(q)


class RunManager:
    def __init__(self) -> None:
        self._runs: dict[str, LiveRun] = {}

    def create(self, agent_id: str) -> LiveRun:
        self._prune()
        stream_id = uuid.uuid4().hex
        run = LiveRun(stream_id, agent_id)
        self._runs[stream_id] = run
        return run

    def get(self, stream_id: str) -> LiveRun | None:
        self._prune()
        return self._runs.get(stream_id)

    def list_runs(self) -> list[dict[str, Any]]:
        """Return lightweight lifecycle summaries for active/recent streams."""
        self._prune()
        return [
            {
                "stream_id": run.stream_id,
                "agent_id": run.agent_id,
                "run_id": run.run_id,
                "done": run.done,
                "cancel_requested": run.cancel_requested,
                "event_count": len(run.events),
                "finished_at": run.finished_at,
            }
            for run in self._runs.values()
        ]

    def clear(self) -> None:
        self._runs.clear()

    async def shutdown(self, timeout: float = SHUTDOWN_GRACE_SECONDS) -> int:
        """Cancel every in-flight run and wait (bounded) for the tasks to finish.

        Each run's own cancellation path persists an ERROR ("cancelled") record
        and publishes ``run_cancelled``, so no run is silently lost when the
        process stops. Returns the number of runs that were cancelled.
        """
        tasks: list[asyncio.Task] = []
        for run in self._runs.values():
            if run.task is None or run.task.done():
                continue
            run.request_cancel()
            run.task.cancel()
            tasks.append(run.task)
        if tasks:
            _done, pending = await asyncio.wait(tasks, timeout=timeout)
            if pending:
                _log.warning("shutdown_runs_still_pending", extra={"pending": len(pending)})
        return len(tasks)

    def _prune(self) -> None:
        now = time.monotonic()
        stale = [
            sid for sid, r in self._runs.items()
            if r.done and r.finished_at is not None and (now - r.finished_at) > _RETAIN_SECONDS
        ]
        for sid in stale:
            self._runs.pop(sid, None)


# Module-level singleton, mirroring capture_store / label_store.
run_manager = RunManager()
