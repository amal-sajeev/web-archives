"""Assemble the persisted RunRecord from per-case results."""

from __future__ import annotations

import uuid
from datetime import datetime, UTC

from core import aggregation
from core.labels import label_store
from core.models import CaseResult, CreatedBy, Dataset, RunRecord

_MAX_ERROR_DETAIL_LEN = 4000

# error_detail recorded when a run is cancelled (by request or task cancel).
CANCELLED_DETAIL = "cancelled"


def compose_status(run_passed: bool, error_detail: str | None) -> str:
    if error_detail:
        return "ERROR"
    return "PASS" if run_passed else "FAIL"


def clean_error_detail(error_detail: str | None) -> str | None:
    """Collapse whitespace and cap the length of an error message."""
    if not error_detail:
        return None
    cleaned = " ".join(str(error_detail).split())
    return cleaned[:_MAX_ERROR_DETAIL_LEN]


def describe_error(exc: BaseException) -> str:
    return f"{type(exc).__name__}: {exc}"


def build_run(
    agent_id: str,
    dataset: Dataset,
    case_results: list[CaseResult],
    created_by: CreatedBy,
    error_detail: str | None = None,
) -> RunRecord:
    """Aggregate case results; calibration uses only this agent's human labels."""
    n = len(case_results) or 1
    run_score = sum(c.weighted_score for c in case_results) / n
    run_delta = sum(c.weighted_delta for c in case_results) / n
    run_passed = bool(case_results) and all(c.passed for c in case_results)
    stats = aggregation.run_statistics(case_results, label_store.verdict_map(agent_id=agent_id))
    return RunRecord(
        run_id=uuid.uuid4().hex,
        agent_id=agent_id,
        dataset_id=dataset.dataset_id,
        dataset_version=dataset.version,
        weighted_score=run_score,
        weighted_delta=run_delta,
        status=compose_status(run_passed, error_detail),
        creation_ts=datetime.now(UTC).isoformat(),
        created_by=created_by,
        error_detail=clean_error_detail(error_detail),
        case_results=case_results,
        stats=stats,
    )
