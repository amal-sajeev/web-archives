"""Score one metric for one case: call the scorer, normalise, attach the baseline.

A scorer that raises ``MetricSkipped`` (or fails, or returns a malformed
result) yields a ``SkippedMetric``; the gate treats a skipped *critical* metric
as a failure. Only judge scorers are throttled by the shared judge semaphore.
"""

from __future__ import annotations

import asyncio
import functools
import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from core import aggregation, run_events
from core.models import Dataset, GoldenCase, MetricSpec, Observation, Score, SkippedMetric
from core.run_events import Emitter
from core.structured_logging import get_logger
from scorers import get_scorer
from scorers.base import MetricSkipped, is_judge_scorer

if TYPE_CHECKING:
    from repository import EvaluationRepository

_log = get_logger("eval_service.runner")

_ERROR_MSG_LEN = 200
_BASE_ARITY, _EXTRAS_ARITY = 3, 4  # (score, rationale, evidence[, extras])
_SCORER_ERROR = "Scorer error: "
_DISPLAY_KEYS = ("raw_value", "measured", "response_code")


@dataclass
class ScoringContext:
    """Per-run state shared by every metric evaluation."""

    agent_id: str
    dataset: Dataset
    repo: EvaluationRepository
    emit: Emitter
    judge_sem: asyncio.Semaphore
    judge_repetitions: int
    trace_id: str


@dataclass
class ScorerOutput:
    """A validated scorer result."""

    score: float
    rationale: str
    evidence: list[str]
    raw_value: float | None
    display_value: float | None
    variance: float | None
    unstable: bool


def _optional_float(value: Any, field: str) -> float | None:
    if value is None:
        return None
    number = float(value)
    if math.isnan(number):
        raise ValueError(f"extras.{field} is NaN")
    return number


def _display_value(extras: dict[str, Any]) -> float | None:
    """Audit number shown on the Score: raw_value, else measured, else response_code."""
    for key in _DISPLAY_KEYS:
        value = extras.get(key)
        if value is None:
            continue
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    return None


def parse_result(result: Any) -> ScorerOutput:
    """Validate ``(score, rationale, evidence[, extras])``; raise ValueError/TypeError if malformed."""
    if not isinstance(result, tuple | list) or len(result) not in (_BASE_ARITY, _EXTRAS_ARITY):
        raise ValueError(f"scorer must return a 3- or 4-tuple, got {type(result).__name__}")
    extras = result[3] if len(result) == _EXTRAS_ARITY else {}
    if not isinstance(extras, dict):
        raise TypeError("scorer extras must be a dict")
    evidence = result[2]
    if not isinstance(evidence, list | tuple):
        raise TypeError("scorer evidence must be a list")
    return ScorerOutput(
        score=float(result[0]),
        rationale="" if result[1] is None else str(result[1]),
        evidence=[str(e) for e in evidence],
        raw_value=_optional_float(extras.get("raw_value"), "raw_value"),
        display_value=_display_value(extras),
        variance=_optional_float(extras.get("variance"), "variance"),
        unstable=bool(extras.get("unstable", False)),
    )


def baseline_quality(value: float, spec: MetricSpec) -> float:
    """Put a baseline on the same 0..1 scale as the scores.

    Stored (promoted) and dataset baselines are recorded as quality scores, so a
    value inside [0, 1] is used as-is; a value outside it is a raw measurement
    (e.g. a latency in ms) and goes through the same ``normalise`` as the score.
    """
    number = float(value)
    if 0.0 <= number <= 1.0:
        return number
    return aggregation.normalise(number, spec)


async def _call_scorer(
    ctx: ScoringContext, spec: MetricSpec, case: GoldenCase, obs: Observation, metrics: dict[str, Any]
) -> ScorerOutput:
    call = functools.partial(
        get_scorer(spec.scorer),
        observation=obs,
        case=case,
        metrics=metrics,
        metric_name=spec.name,
        spec=spec,
        judge_repetitions=ctx.judge_repetitions,
    )
    if is_judge_scorer(spec.scorer):
        async with ctx.judge_sem:
            return parse_result(await asyncio.to_thread(call))
    return parse_result(await asyncio.to_thread(call))


async def _resolve_baseline(ctx: ScoringContext, spec: MetricSpec, case: GoldenCase) -> float | None:
    """Prefer a stored blessed baseline, else the case's baseline_metrics."""
    ds = ctx.dataset
    stored = await asyncio.to_thread(
        ctx.repo.get_baseline, ctx.agent_id, ds.dataset_id, ds.version, spec.name
    )
    value = stored if stored is not None else case.baseline_metrics.get(spec.name)
    return None if value is None else baseline_quality(value, spec)


async def _skip(ctx: ScoringContext, spec: MetricSpec, case_id: str, reason: str) -> SkippedMetric:
    await ctx.emit(run_events.metric_skipped(case_id, spec.name, reason))
    return SkippedMetric(
        metric=spec.name,
        reason=reason,
        weight=spec.weight,
        threshold=spec.threshold,
        critical=spec.critical,
        judge=is_judge_scorer(spec.scorer),
    )


async def score_metric(
    ctx: ScoringContext, spec: MetricSpec, case: GoldenCase, obs: Observation, metrics: dict[str, Any]
) -> Score | SkippedMetric:
    """Evaluate one metric; never raises for scorer-side problems."""
    judge = is_judge_scorer(spec.scorer)
    await ctx.emit(run_events.metric_started(case.id, spec.name, judge))
    try:
        out = await _call_scorer(ctx, spec, case, obs, metrics)
        # The runner normalises raw_value when the scorer reports one, else the score.
        quality = aggregation.normalise(out.raw_value if out.raw_value is not None else out.score, spec)
    except MetricSkipped as skip:
        return await _skip(ctx, spec, case.id, str(skip))
    except Exception as err:
        error_msg = f"{type(err).__name__}: {str(err)[:_ERROR_MSG_LEN]}"
        _log.warning("metric_error", extra={
            "trace_id": ctx.trace_id, "case_id": case.id, "metric": spec.name, "error": error_msg,
        })
        # Same "Scorer error: " prefix in the stored reason and the live event, so
        # the report can tell a crashed scorer from an ordinary skip.
        return await _skip(ctx, spec, case.id, f"{_SCORER_ERROR}{error_msg}")

    baseline = await _resolve_baseline(ctx, spec, case)
    score = Score(
        metric=spec.name,
        score=quality,
        passed=quality >= spec.threshold,
        threshold=spec.threshold,
        weight=spec.weight,
        baseline=baseline,
        delta=(quality - baseline) if baseline is not None else None,
        rationale=out.rationale,
        evidence=out.evidence,
        critical=spec.critical,
        raw_value=out.display_value if out.display_value is not None else out.score,
        variance=out.variance,
        unstable=out.unstable,
        unit=spec.unit,
    )
    await ctx.emit(run_events.metric_done(case.id, score, judge))
    return score
