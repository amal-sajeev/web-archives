"""Core application package for the evaluation service."""
