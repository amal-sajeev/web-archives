"""Human-in-the-loop label store (in-memory, schema-independent).

Experts post a pass/fail verdict per case; the runner uses these as ground
truth to calibrate the automated gate/judge (precision/recall/F1, Cohen's kappa
in `aggregation.run_statistics`). Labels are keyed by ``(agent_id, case_id)``
so two agents that share a case id never calibrate against each other's
verdicts. The store is bounded; the oldest labels are evicted first.
"""

from __future__ import annotations

from collections import OrderedDict
from datetime import datetime, UTC

from core.models import HumanLabel

_MAX_LABELS = 10_000

LabelKey = tuple[str | None, str]


class LabelStore:
    def __init__(self, max_labels: int = _MAX_LABELS) -> None:
        # (agent_id, case_id) -> latest HumanLabel (the most recent verdict wins).
        self._by_key: OrderedDict[LabelKey, HumanLabel] = OrderedDict()
        self._max = max(1, max_labels)

    def add(self, label: HumanLabel) -> HumanLabel:
        if not label.created_at:
            label.created_at = datetime.now(UTC).isoformat()
        key = (label.agent_id, label.case_id)
        self._by_key.pop(key, None)
        self._by_key[key] = label
        while len(self._by_key) > self._max:
            self._by_key.popitem(last=False)
        return label

    def get(self, case_id: str, *, agent_id: str | None = None) -> HumanLabel | None:
        """Latest label for a case; scoped to ``agent_id`` when one is given."""
        if agent_id is not None:
            return self._by_key.get((agent_id, case_id))
        matches = [lbl for (_, cid), lbl in self._by_key.items() if cid == case_id]
        return max(matches, key=lambda x: x.created_at) if matches else None

    def all(self, *, agent_id: str | None = None) -> list[HumanLabel]:
        labels = [
            lbl for (aid, _), lbl in self._by_key.items()
            if agent_id is None or aid == agent_id
        ]
        return sorted(labels, key=lambda x: x.created_at, reverse=True)

    def verdict_map(self, *, agent_id: str | None = None) -> dict[str, str]:
        """case_id -> 'pass'/'fail' ground truth; only ``agent_id``'s labels when given."""
        return {
            cid: lbl.verdict.lower()
            for (aid, cid), lbl in self._by_key.items()
            if agent_id is None or aid == agent_id
        }

    def clear(self) -> None:
        self._by_key.clear()


# Module-level singleton (mirrors the capture_store pattern).
label_store = LabelStore()
