"""Aggregation & Gate: weighted score, weighted delta, and the pass/fail gate.

  weighted score  S = sum(s_i * w_i) / sum(w_i)
  weighted delta  D = sum((s_i - b_i) * w_i) / sum(w_i)     (drift vs baseline)
  gate: no critical metric fails
        AND all metrics >= threshold
        AND S >= dataset_threshold
        AND D >= -tolerance

Banking-grade additions:
  * critical metrics (e.g. safety/compliance) act as hard vetoes.
  * lower-is-better / unbounded metrics (latency, cost, error rate) are
    normalised to a 0..1 quality score before they enter the weighted mean.
"""

from __future__ import annotations

import math
from collections import Counter
from statistics import NormalDist, mean, stdev

from core.config import Config
from core.models import CaseResult, MetricSpec, RunStats, Score, SkippedMetric
from scorers.base import MetricSkipped

# Significance level for the two-sided drift test.
_ALPHA = 0.05
# Smallest mean per-case delta (in score points, 0..1) treated as a material
# regression. Statistically "significant" drops smaller than this are noise
# for a gate decision.
_MIN_DRIFT_EFFECT = 0.01


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def normalise(value: float, spec: MetricSpec) -> float:
    """Map a raw metric measurement to a 0..1 quality score.

    - The result is always clamped to [0, 1]; NaN maps to 0.
    - higher_is_better: with [norm_min, norm_max] bounds the value is scaled
      linearly, otherwise it is treated as a ratio.
    - lower_is_better: value <= norm_min -> 1.0 (best), value >= norm_max -> 0.0
      (worst), linear in between. ``norm_max`` is required; without it the
      metric cannot be scored and ``MetricSkipped`` is raised.
    """
    value = float(value)
    if math.isnan(value):
        return 0.0
    if spec.direction == "lower_is_better":
        if spec.norm_max is None:
            raise MetricSkipped(
                f"metric '{spec.name}' is lower_is_better but has no norm_max; cannot normalise"
            )
        lo = spec.norm_min if spec.norm_min is not None else 0.0
        hi = spec.norm_max
        if hi <= lo:
            return 1.0 if value <= lo else 0.0
        return _clamp01((hi - value) / (hi - lo))
    if spec.norm_min is not None and spec.norm_max is not None and spec.norm_max > spec.norm_min:
        return _clamp01((value - spec.norm_min) / (spec.norm_max - spec.norm_min))
    return _clamp01(value)


def weighted_score(scores: list[Score]) -> float:
    total_w = sum(s.weight for s in scores)
    if total_w == 0:
        return 0.0
    return sum(s.score * s.weight for s in scores) / total_w


def weighted_delta(scores: list[Score]) -> float:
    """Sum((score - baseline) * wt) / sum(wt); metrics with no baseline contribute 0 delta."""
    total_w = sum(s.weight for s in scores)
    if total_w == 0:
        return 0.0
    acc = sum((s.score - s.baseline) * s.weight for s in scores if s.baseline is not None)
    return acc / total_w


def critical_failures(
    scores: list[Score], skipped: list[SkippedMetric] | None = None
) -> list[str]:
    """Names of critical metrics that failed or could not be measured (vetoes)."""
    failed = [s.metric for s in scores if s.critical and not s.passed]
    unmeasured = [s.metric for s in (skipped or []) if s.critical]
    return failed + unmeasured


def gate(
    scores: list[Score],
    *,
    skipped: list[SkippedMetric] | None = None,
    dataset_threshold: float | None = None,
    regression_tolerance: float | None = None,
) -> tuple[bool, float, float]:
    """Return (passed, weighted_score, weighted_delta).

    A case fails when it has no scores at all, when a critical metric fails or
    was skipped/errored (the banking-grade veto), when any metric misses its
    threshold, or when the weighted score / delta miss the dataset limits.
    Defaults come from ``Config`` at call time.
    """
    threshold = Config.DATASET_THRESHOLD if dataset_threshold is None else dataset_threshold
    tolerance = Config.REGRESSION_TOLERANCE if regression_tolerance is None else regression_tolerance
    s = weighted_score(scores)
    d = weighted_delta(scores)
    passed = (
        bool(scores)
        and not critical_failures(scores, skipped)
        and all(sc.passed for sc in scores)
        and s >= threshold
        and d >= -tolerance
    )
    return passed, s, d


# --- Dataset-level statistics (rigor across all cases in a run) ---------------

_Z95 = 1.959963984540054  # standard-normal quantile for a two-sided 95% CI


def mean_confidence_interval(values: list[float], z: float = _Z95) -> tuple[float, float, float, float]:
    """Return (mean, stdev, ci_low, ci_high) for the sample mean (z-approx).

    Uses the sample standard deviation and the standard error mean/√n. For a
    single observation the interval collapses to the point estimate.
    """
    n = len(values)
    if n == 0:
        return 0.0, 0.0, 0.0, 0.0
    m = mean(values)
    if n == 1:
        return m, 0.0, m, m
    sd = stdev(values)
    se = sd / math.sqrt(n)
    return m, sd, m - z * se, m + z * se


def drift_significance(deltas: list[float]) -> tuple[float, float | None, bool]:
    """Two-sided z-test that the mean per-case delta differs from zero.

    Returns (mean_delta, p_value, significant_regression). `significant` is True
    only for a real, material *drop*: mean_delta < 0, p < ``_ALPHA`` and
    |mean_delta| >= ``_MIN_DRIFT_EFFECT``. Uses the sample standard deviation.
    """
    n = len(deltas)
    if n == 0:
        return 0.0, None, False
    md = mean(deltas)
    if n < 2:
        return md, None, False
    sd = stdev(deltas)
    if sd == 0.0:
        # No variance: any non-zero mean is a deterministic shift.
        p = 0.0 if md != 0.0 else 1.0
    else:
        z = md / (sd / math.sqrt(n))
        p = 2.0 * (1.0 - NormalDist().cdf(abs(z)))
    significant = md < 0.0 and p < _ALPHA and abs(md) >= _MIN_DRIFT_EFFECT
    return md, p, significant


def classification_stats(
    predictions: list[bool], truths: list[bool]
) -> dict[str, float]:
    """Confusion-derived precision/recall/F1 + Cohen's κ for gate-vs-human.

    prediction = the automated gate's pass decision; truth = the human label.
    """
    pairs = Counter(zip(map(bool, predictions), map(bool, truths), strict=True))
    tp, fp = pairs[(True, True)], pairs[(True, False)]
    fn, tn = pairs[(False, True)], pairs[(False, False)]
    n = tp + fp + fn + tn
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    # Cohen's kappa: agreement corrected for chance.
    po = (tp + tn) / n if n else 0.0
    p_pred_pos = (tp + fp) / n if n else 0.0
    p_true_pos = (tp + fn) / n if n else 0.0
    pe = p_pred_pos * p_true_pos + (1 - p_pred_pos) * (1 - p_true_pos)
    kappa = (po - pe) / (1 - pe) if (1 - pe) else 1.0
    return {"precision": precision, "recall": recall, "f1": f1, "cohens_kappa": kappa}


def run_statistics(
    case_results: list[CaseResult],
    labels: dict[str, str] | None = None,
) -> RunStats:
    """Compute dataset-level statistics for a completed run.

    `labels` maps case_id -> 'pass'/'fail' expert ground truth; when present the
    judge-vs-human calibration fields (precision/recall/F1/κ) are populated.
    """
    n = len(case_results)
    if n == 0:
        return RunStats()

    scores = [c.weighted_score for c in case_results]
    deltas = [c.weighted_delta for c in case_results]
    m, sd, lo, hi = mean_confidence_interval(scores)
    md, p, significant = drift_significance(deltas)
    pass_rate = sum(1 for c in case_results if c.passed) / n

    stats = RunStats(
        n_cases=n,
        pass_rate=pass_rate,
        mean_score=m,
        score_stdev=sd,
        ci95_low=lo,
        ci95_high=hi,
        mean_delta=md,
        drift_p_value=p,
        drift_significant=significant,
    )

    labels = labels or {}
    matched = [(c.passed, str(labels[c.case_id]).strip().lower() == "pass")
               for c in case_results if c.case_id in labels]
    if matched:
        preds = [p for p, _ in matched]
        truths = [t for _, t in matched]
        cls = classification_stats(preds, truths)
        stats.labeled_cases = len(matched)
        stats.precision = cls["precision"]
        stats.recall = cls["recall"]
        stats.f1 = cls["f1"]
        stats.cohens_kappa = cls["cohens_kappa"]
    return stats
