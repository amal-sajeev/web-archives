"""Structured logging with per-run trace IDs.

Every evaluation run gets a trace_id. All log messages emitted during that run
carry the same trace_id so they can be correlated in the log output.

Usage:
    from core.structured_logging import get_logger
    log = get_logger(__name__)
    log.info("case_started", extra={"trace_id": run_id, "case_id": case_id})

The ``eval_service`` logger tree gets one JSON-lines handler on stderr and does
not propagate to the root logger, so records are not printed twice.
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, UTC

_CONFIGURED = False
_ROOT_LOGGER = "eval_service"

# Attributes every LogRecord has; anything else was passed via ``extra=``.
_STANDARD_ATTRS = frozenset(
    vars(logging.LogRecord("", logging.INFO, "", 0, "", None, None)).keys()
) | {"message", "asctime", "taskName"}


class StructuredFormatter(logging.Formatter):
    """Emit log records as JSON lines: timestamp, level, logger, message + all extras."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, object] = {
            "ts": datetime.fromtimestamp(record.created, UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key, val in vars(record).items():
            if key not in _STANDARD_ATTRS and not key.startswith("_") and val is not None:
                payload[key] = val
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


def _configure_logging() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(StructuredFormatter())
    root = logging.getLogger(_ROOT_LOGGER)
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    root.propagate = False
    _CONFIGURED = True


def get_logger(name: str = _ROOT_LOGGER) -> logging.Logger:
    _configure_logging()
    return logging.getLogger(name)
