"""Reading and writing playground configuration archives (ZIP and 7z)."""

from __future__ import annotations

import base64
import binascii
import io
import logging
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

MAX_ZIP_BYTES = 32 * 1024 * 1024
MAX_UNCOMPRESSED_BYTES = 96 * 1024 * 1024
MAX_FILES = 1500
_SEVEN_ZIP_MAGIC = b"7z\xbc\xaf'\x1c"
_MB = 1024 * 1024
_S_IFMT, _S_IFLNK = 0o170000, 0o120000
_NOT_7Z = "The uploaded file is not a valid 7z archive, or it is damaged. Try creating the archive again."
_log = logging.getLogger("eval_service.playground.archive")


def _safe_member(name: str) -> str:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or "" in p.parts:
        raise ValueError(f"Unsafe zip path: {name!r}")
    return p.as_posix()


def _archive_kind(blob: bytes, filename: str | None = None) -> str:
    lowered = (filename or "").lower()
    if lowered.endswith((".7z", ".7zip")) or blob.startswith(_SEVEN_ZIP_MAGIC):
        return "7z"
    return "zip"


def _check_blob_size(blob: bytes, label: str) -> None:
    if len(blob) > MAX_ZIP_BYTES:
        raise ValueError(f"Configuration {label} exceeds {MAX_ZIP_BYTES // _MB} MB.")


def _too_big(label: str) -> ValueError:
    return ValueError(f"{label} expands beyond {MAX_UNCOMPRESSED_BYTES // _MB} MB.")


def _read_zip_members(zf: zipfile.ZipFile) -> dict[str, bytes]:
    infos = zf.infolist()
    if len(infos) > MAX_FILES:
        raise ValueError(f"ZIP contains too many files (maximum {MAX_FILES}).")
    for info in infos:
        _safe_member(info.filename)
    files = [i for i in infos if not i.is_dir()]
    for info in files:
        # Reject symlink entries. They can escape the extraction root.
        if ((info.external_attr >> 16) & _S_IFMT) == _S_IFLNK:
            raise ValueError(f"Symlinks are not allowed in uploaded bundles: {info.filename}")
    if sum(i.file_size for i in files) > MAX_UNCOMPRESSED_BYTES:
        raise _too_big("ZIP")
    return {_safe_member(i.filename): zf.read(i) for i in files}


def _read_zip(blob: bytes) -> dict[str, bytes]:
    _check_blob_size(blob, "ZIP")
    try:
        zf = zipfile.ZipFile(io.BytesIO(blob))
    except zipfile.BadZipFile as exc:
        raise ValueError(
            "The uploaded file is not a valid ZIP archive, or it is damaged. "
            "Upload a .zip or .7z file that contains your agent folder."
        ) from exc
    with zf:
        out = _read_zip_members(zf)
    if not out:
        raise ValueError("The ZIP archive is empty.")
    return out


def _check_7z_listing(archive: Any) -> None:
    """Reject oversized 7z archives from their listing, before decompressing."""
    infos = list(archive.list())
    if len(infos) > MAX_FILES:
        raise ValueError(f"7z contains too many files (maximum {MAX_FILES}).")
    if sum(int(getattr(i, "uncompressed", 0) or 0) for i in infos) > MAX_UNCOMPRESSED_BYTES:
        raise _too_big("7z")


def _7z_payloads(archive: Any) -> dict[str, bytes]:
    """Decompress every member.

    py7zr 1.0 removed ``readall()``; the dependency is unpinned, so fall back to
    extracting into a private temporary directory when it is not available.
    """
    if hasattr(archive, "readall"):
        return {str(name): payload.read() for name, payload in (archive.readall() or {}).items()}
    with tempfile.TemporaryDirectory(prefix="ctna-7z-") as tmp:
        archive.extractall(path=tmp)
        root = Path(tmp)
        return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*") if p.is_file()}


def _collect_7z(extracted: dict[str, bytes]) -> dict[str, bytes]:
    out: dict[str, bytes] = {}
    total = 0
    for name, data in extracted.items():
        normalized = _safe_member(name.replace("\\", "/"))
        total += len(data)
        if total > MAX_UNCOMPRESSED_BYTES:
            raise _too_big("7z")
        out[normalized] = data
    return out


def _invalid_7z(exc: Exception) -> ValueError:
    _log.info("7z archive rejected: %s: %s", type(exc).__name__, exc)
    return ValueError(_NOT_7Z)


def _read_7z(blob: bytes) -> dict[str, bytes]:
    _check_blob_size(blob, "7z archive")
    try:
        import py7zr
    except ImportError as exc:
        raise ValueError(
            "7z archives are not supported on this server (the py7zr package is not installed). "
            "Upload a .zip file instead."
        ) from exc
    try:
        archive = py7zr.SevenZipFile(io.BytesIO(blob), mode="r")
    except Exception as exc:
        raise _invalid_7z(exc) from exc
    with archive:
        _check_7z_listing(archive)
        try:
            extracted = _7z_payloads(archive)
        except Exception as exc:
            raise _invalid_7z(exc) from exc
    out = _collect_7z(extracted)
    if not out:
        raise ValueError("The 7z archive is empty.")
    return out


def _read_archive(blob: bytes, filename: str | None = None) -> tuple[dict[str, bytes], str]:
    kind = _archive_kind(blob, filename)
    if kind == "7z":
        return _read_7z(blob), kind
    return _read_zip(blob), kind


def _item_bytes(item: dict[str, Any], path: str) -> bytes:
    if item.get("encoding") != "base64":
        return str(item.get("content", "")).encode("utf-8")
    try:
        return base64.b64decode(item.get("content", ""), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError(f"Invalid base64 content for {path}") from exc


def files_to_zip(items: list[dict[str, Any]], root: str = "") -> bytes:
    """Pack edited file items (``{path, content, encoding}``) into a ZIP under ``root``."""
    buf = io.BytesIO()
    total = 0
    prefix = root.strip("/")
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        seen: set[str] = set()
        for item in items:
            rel_path = _safe_member(str(item.get("path", "")))
            path = _safe_member(f"{prefix}/{rel_path}" if prefix else rel_path)
            if path in seen:
                continue
            seen.add(path)
            data = _item_bytes(item, path)
            total += len(data)
            if total > MAX_UNCOMPRESSED_BYTES:
                raise ValueError("Edited bundle is too large to export/test.")
            zf.writestr(path, data)
    result = buf.getvalue()
    if len(result) > MAX_ZIP_BYTES:
        raise ValueError(f"Edited ZIP exceeds the {MAX_ZIP_BYTES // _MB} MB upload limit.")
    return result
