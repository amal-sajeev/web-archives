"""Load an uploaded agent into an ephemeral Registry and undo its scorer registrations."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from registry import Registry


@dataclass
class ScopedRegistry:
    """An ephemeral registry plus what is needed to restore the global scorers."""

    registry: Registry
    custom_scorers: list[str] = field(default_factory=list)
    collisions: list[str] = field(default_factory=list)
    scorer_snapshot: dict[str, Any] = field(default_factory=dict)

    def cleanup(self) -> None:
        """Restore the process-global scorer registry to its pre-load state."""
        from scorers.base import restore_scorers

        restore_scorers(self.scorer_snapshot)


def load_scoped_registry(temp_dir: Path) -> ScopedRegistry:
    """Load ``temp_dir`` as a registry; report scorers added or replaced by custom_tests.py."""
    from scorers import all_scorers
    from scorers.base import snapshot_scorers

    before = snapshot_scorers()
    registry = Registry(temp_dir).load()
    after = all_scorers()
    custom = sorted(set(after) - set(before))
    collisions = sorted(name for name in set(after) & set(before) if after[name] is not before[name])
    return ScopedRegistry(registry, custom, collisions, before)


# --- Backward-compatible tuple API used by handlers/playground.py -------------

_ACTIVE: dict[int, ScopedRegistry] = {}


def _load_scoped_registry(temp_dir: Path) -> tuple[Registry, list[str], list[str]]:
    """Deprecated: prefer :func:`load_scoped_registry` + ``ScopedRegistry.cleanup()``."""
    scoped = load_scoped_registry(temp_dir)
    _ACTIVE[id(scoped.registry)] = scoped
    return scoped.registry, scoped.custom_scorers, scoped.collisions


def _cleanup_scoped_registry(registry: Registry | ScopedRegistry) -> None:
    """Deprecated counterpart of :func:`_load_scoped_registry`."""
    scoped = registry if isinstance(registry, ScopedRegistry) else _ACTIVE.pop(id(registry), None)
    if scoped is not None:
        scoped.cleanup()
