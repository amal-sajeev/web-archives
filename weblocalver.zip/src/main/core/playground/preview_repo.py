"""In-memory repository for a single playground (preview) run."""

from __future__ import annotations

from typing import Any

from core.models import CreatedBy, RunRecord
from repository.base import EvaluationRepository

_ERROR_PREFIX = "ERROR"


def _status_matches(run_status: str, wanted: str | None) -> bool:
    if not wanted:
        return True
    if wanted.startswith(_ERROR_PREFIX):
        return run_status.startswith(_ERROR_PREFIX)
    return run_status == wanted


def _summary(run: RunRecord) -> dict[str, Any]:
    return {
        "run_id": run.run_id, "agent_id": run.agent_id,
        "dataset_id": run.dataset_id, "dataset_version": run.dataset_version,
        "weighted_score": run.weighted_score, "weighted_delta": run.weighted_delta,
        "status": run.status, "creation_ts": run.creation_ts, "created_by": run.created_by,
        "case_count": len(run.case_results),
        "passed_case_count": sum(1 for c in run.case_results if c.passed),
        "error_detail": run.error_detail,
    }


class PreviewRepository(EvaluationRepository):
    """Repository for a single preview run. It never touches SQLite/Postgres."""

    def __init__(self) -> None:
        self._runs: dict[str, RunRecord] = {}
        self._baselines: dict[tuple[str, str, str, str], float] = {}

    def init_schema(self) -> None:
        return None

    def save_run(self, run: RunRecord) -> None:
        self._runs[run.run_id] = run

    def get_run(self, run_id: str) -> RunRecord | None:
        return self._runs.get(run_id)

    def list_runs(
        self,
        agent_id: str | None = None,
        limit: int = 50,
        before: str | None = None,
        status: str | None = None,
        dataset_id: str | None = None,
        before_id: str | None = None,
    ) -> list[dict[str, Any]]:
        runs = sorted(self._runs.values(), key=lambda r: (r.creation_ts, r.run_id), reverse=True)
        rows = [
            _summary(run) for run in runs
            if (not agent_id or run.agent_id == agent_id)
            and (not dataset_id or run.dataset_id == dataset_id)
            and _status_matches(run.status, status)
            and _before_cursor(run, before, before_id)
        ]
        return rows[:limit]

    def get_baseline(self, agent_id: str, dataset_id: str, dataset_version: str, metric: str) -> float | None:
        return self._baselines.get((agent_id, dataset_id, dataset_version, metric))

    def set_baseline(
        self, agent_id: str, dataset_id: str, dataset_version: str, metric: str,
        value: float, created_by: CreatedBy,
    ) -> None:
        self._baselines[(agent_id, dataset_id, dataset_version, metric)] = value


def _before_cursor(run: RunRecord, before: str | None, before_id: str | None) -> bool:
    if not before:
        return True
    if before_id is None:
        return run.creation_ts < before
    return (run.creation_ts, run.run_id) < (before, before_id)
