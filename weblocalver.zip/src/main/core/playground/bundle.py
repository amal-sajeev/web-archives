"""Inspect an uploaded agent-config bundle and extract it to a temp directory."""

from __future__ import annotations

import ast
import base64
import json
import tempfile
from pathlib import Path, PurePosixPath
from typing import Any

import yaml
from pydantic import ValidationError

from core.models import AgentConfig, Dataset
from .archive import _read_archive

_AGENT_YAML = "agent.yaml"
_CUSTOM_TESTS = "custom_tests.py"
_SCORER_DECORATOR = "scorer"
_TEXT_EXTS = frozenset({
    ".yaml", ".yml", ".json", ".py", ".txt", ".md", ".toml", ".ini", ".cfg", ".xml", ".csv", ".env",
})


def _describe_error(exc: Exception) -> str:
    """Turn a parse/validation error into one short line a non-developer can act on."""
    if isinstance(exc, ValidationError):
        parts = []
        for err in exc.errors():
            where = ".".join(str(p) for p in err["loc"])
            parts.append(f"{where}: {err['msg']}" if where else err["msg"])
        return "; ".join(parts)
    if isinstance(exc, UnicodeDecodeError):
        return "the file is not UTF-8 text"
    if isinstance(exc, json.JSONDecodeError):
        return f"line {exc.lineno}: {exc.msg}"
    mark = getattr(exc, "problem_mark", None)
    if isinstance(exc, yaml.YAMLError) and mark is not None:
        return f"line {mark.line + 1}: {getattr(exc, 'problem', None) or exc}"
    return str(exc)


def _decorator_scorer_name(call: ast.expr) -> str | None:
    """Return ``name`` from ``@scorer("name")``, ``@scorer(name="name")`` or ``@x.scorer(...)``."""
    if not isinstance(call, ast.Call):
        return None
    func = call.func
    func_name = func.id if isinstance(func, ast.Name) else getattr(func, "attr", None)
    if func_name != _SCORER_DECORATOR:
        return None
    first = call.args[0] if call.args else next((k.value for k in call.keywords if k.arg == "name"), None)
    if isinstance(first, ast.Constant) and isinstance(first.value, str):
        return first.value
    return None


def _declared_custom_scorers(tree: ast.AST) -> list[str]:
    """Statically discover scorer names declared by ``@scorer`` decorators."""
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            names.update(n for n in map(_decorator_scorer_name, node.decorator_list) if n)
    return sorted(names)


def _agent_root(files: dict[str, bytes]) -> str:
    manifests = sorted(p for p in files if p.endswith(f"/{_AGENT_YAML}") or p == _AGENT_YAML)
    if not manifests:
        raise ValueError(
            "No agent.yaml was found in the upload. The archive must contain one agent folder with an agent.yaml file."
        )
    if len(manifests) > 1:
        raise ValueError(
            f"The upload contains {len(manifests)} agent.yaml files ({', '.join(manifests)}). "
            "Upload one agent folder at a time."
        )
    manifest = manifests[0]
    return manifest.rsplit("/", 1)[0] if "/" in manifest else ""


def _normalise_files(files: dict[str, bytes], root: str) -> dict[str, bytes]:
    prefix = f"{root}/" if root else ""
    return {
        path[len(prefix):]: data
        for path, data in files.items()
        if path.startswith(prefix) and path[len(prefix):]
    }


def _bundle_path(path: str) -> str:
    """Normalise a path from agent.yaml (``./dataset.json`` -> ``dataset.json``)."""
    return PurePosixPath(path.replace("\\", "/")).as_posix()


def _load_config(files: dict[str, bytes]) -> tuple[AgentConfig, Dataset]:
    try:
        cfg_data = yaml.safe_load(files[_AGENT_YAML].decode("utf-8-sig")) or {}
        config = AgentConfig.model_validate(cfg_data)
    except (ValueError, yaml.YAMLError) as exc:
        raise ValueError(f"agent.yaml is invalid: {_describe_error(exc)}") from exc
    dataset_path = _bundle_path(config.dataset_file)
    if dataset_path not in files:
        raise ValueError(f"Configured dataset file is missing: {config.dataset_file}")
    try:
        dataset = Dataset.model_validate(json.loads(files[dataset_path].decode("utf-8-sig")))
    except ValueError as exc:
        raise ValueError(f"Dataset is invalid: {_describe_error(exc)}") from exc
    stub_missing = _bundle_path(config.metrics_stub_file) not in files
    if stub_missing and (config.metrics_source or "").lower() == "stub":
        raise ValueError(f"Configured metrics stub file is missing: {config.metrics_stub_file}")
    return config, dataset


def _read_bundle(blob: bytes, filename: str | None) -> tuple[str, dict[str, bytes], str]:
    raw_files, kind = _read_archive(blob, filename)
    root = _agent_root(raw_files)
    return root, _normalise_files(raw_files, root), kind


def _file_item(path: str, data: bytes) -> dict[str, Any]:
    text: str | None = None
    if Path(path).suffix.lower() in _TEXT_EXTS:
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = None
    if text is None:
        content, encoding, kind = base64.b64encode(data).decode("ascii"), "base64", "binary"
    else:
        content, encoding, kind = text, "utf-8", "text"
    return {"path": path, "size": len(data), "encoding": encoding, "kind": kind, "content": content}


def _custom_tests_info(files: dict[str, bytes]) -> tuple[dict[str, Any], list[str]]:
    info: dict[str, Any] = {"present": _CUSTOM_TESTS in files, "declared_scorers": [], "syntax_error": None}
    if _CUSTOM_TESTS not in files:
        return info, []
    warnings = ["custom_tests.py is executable Python and will run on the evaluation service when present."]
    try:
        tree = ast.parse(files[_CUSTOM_TESTS].decode("utf-8-sig"), filename=_CUSTOM_TESTS)
    except SyntaxError as exc:
        info["syntax_error"] = f"line {exc.lineno}: {exc.msg}"
    except UnicodeDecodeError:
        info["syntax_error"] = "the file is not UTF-8 text"
    else:
        info["declared_scorers"] = _declared_custom_scorers(tree)
    if info["syntax_error"]:
        warnings.append(f"custom_tests.py syntax error: {info['syntax_error']}")
    return info, warnings


def _dataset_summary(dataset: Dataset) -> dict[str, Any]:
    return {
        "dataset_id": dataset.dataset_id,
        "version": dataset.version,
        "cases": len(dataset.cases),
        "metrics": len(dataset.metrics),
        "case_items": [{"id": c.id, "input": c.input} for c in dataset.cases],
        "metric_names": [m.name for m in dataset.metrics],
        "target": dataset.target.model_dump(),
    }


def inspect_bundle(blob: bytes, filename: str | None = None) -> dict[str, Any]:
    """Describe an uploaded bundle (agent, dataset, files, custom tests) without running it."""
    root, files, kind = _read_bundle(blob, filename)
    config, dataset = _load_config(files)
    custom_info, warnings = _custom_tests_info(files)
    return {
        "root": root,
        "agent": config.model_dump(),
        "dataset": _dataset_summary(dataset),
        "custom_tests": custom_info,
        "files": [_file_item(path, files[path]) for path in sorted(files)],
        "warnings": warnings,
        "archive_kind": kind,
    }


def extract_to_temp(blob: bytes, filename: str | None = None) -> tuple[Path, str]:
    """Write the bundle's agent folder to a new temp dir; return (temp_dir, agent_id).

    The agent folder is always a *direct* child of ``temp_dir`` because the
    Registry only scans one level deep; a nested root such as
    ``bundle/agents/demo`` is written to ``temp_dir/demo``.
    """
    root, files, _ = _read_bundle(blob, filename)
    config, _ = _load_config(files)
    temp = Path(tempfile.mkdtemp(prefix="ctna-playground-"))
    agent_folder = temp / (PurePosixPath(root).name or config.agent_id)
    agent_folder.mkdir(parents=True, exist_ok=True)
    for rel, data in files.items():
        target = agent_folder / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return temp, config.agent_id
