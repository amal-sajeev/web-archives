"""API request bodies and the response models published in the OpenAPI schema.

Response models that describe list items allow extra fields, so a backend that
returns an additional column never has it silently dropped from the response.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .results import VERDICT_PATTERN, CreatedBy, RunRecord

_MAX_REPS = 5
_MAX_ID_CHARS = 256
_MAX_NAME_CHARS = 128
_MAX_NOTE_CHARS = 4000


class EvaluateRequest(BaseModel):
    agent_id: str = Field(min_length=1, max_length=_MAX_ID_CHARS)
    dataset_version: str | None = None
    judge_repetitions: int = Field(default=1, ge=1, le=_MAX_REPS)
    created_by: CreatedBy = "DEVELOPER"


class AsyncEvaluateRequest(EvaluateRequest):
    webhook_url: str | None = None


class LabelRequest(BaseModel):
    case_id: str = Field(min_length=1, max_length=_MAX_ID_CHARS)
    verdict: str = Field(pattern=VERDICT_PATTERN)
    score: float | None = Field(default=None, ge=0.0, le=1.0)
    labeler: str = Field(default="anonymous", max_length=_MAX_NAME_CHARS)
    note: str = Field(default="", max_length=_MAX_NOTE_CHARS)
    run_id: str | None = Field(default=None, max_length=_MAX_ID_CHARS)
    agent_id: str | None = Field(default=None, max_length=_MAX_ID_CHARS)


class ABCompareRequest(BaseModel):
    agent_a: str = Field(min_length=1, max_length=_MAX_ID_CHARS)
    agent_b: str = Field(min_length=1, max_length=_MAX_ID_CHARS)
    dataset_version: str | None = None
    judge_repetitions: int = Field(default=1, ge=1, le=_MAX_REPS)
    created_by: CreatedBy | None = None


# --------------------------------------------------------------------------- #
# Responses
# --------------------------------------------------------------------------- #

class ErrorResponse(BaseModel):
    """Error envelope returned by every non-2xx JSON response."""

    detail: Any = Field(description="Human-readable message, or the validation error list for 422.")
    error_type: str | None = Field(default=None, description="Stable machine-readable error category.")
    request_id: str | None = Field(default=None, description="Echo of the X-Request-ID correlation header.")


class AgentSummary(BaseModel):
    model_config = ConfigDict(extra="allow")

    agent_id: str
    name: str | None = None
    dataset_id: str | None = None
    dataset_version: str | None = None
    cases: int | None = None
    metrics: list[str] = Field(default_factory=list)
    enabled: bool = True


class AgentListResponse(BaseModel):
    agents: list[AgentSummary]


class RunListItem(BaseModel):
    model_config = ConfigDict(extra="allow")

    run_id: str
    agent_id: str
    agent_name: str | None = Field(default=None, description="Registry display name; null for unknown agents.")
    dataset_id: str
    dataset_version: str
    weighted_score: float | None = None
    weighted_delta: float | None = None
    status: str
    creation_ts: str
    created_by: str
    case_count: int = 0
    passed_case_count: int = 0
    error_detail: str | None = Field(default=None, description="Why the run errored; 'cancelled' when cancelled.")


class RunListResponse(BaseModel):
    runs: list[RunListItem]
    next_cursor: str | None = None


class RunDetailResponse(RunRecord):
    agent_name: str | None = Field(default=None, description="Registry display name; null for unknown agents.")


class RunSummaryResponse(BaseModel):
    total: int
    passed: int
    failed: int
    errored: int
    cancelled: int
    average_score: float | None = Field(description="Mean weighted score over non-ERROR runs; null if none.")
    latest: RunListItem | None = None
    previous: RunListItem | None = Field(default=None, description="The run before `latest` for the same agent.")
