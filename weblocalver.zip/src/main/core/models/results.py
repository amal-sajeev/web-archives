"""Run-time result models: observations, scores, case/run records, labels."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

CreatedBy = Literal["CI_CD", "DEVELOPER"]
VERDICT_PATTERN = "^(pass|fail)$"


class Observation(BaseModel):
    target_id: str
    output: Any = None
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    stage_trace: list[dict[str, Any]] = Field(default_factory=list)
    source_context: Any = None
    latency_ms: int | float = 0
    usage: dict[str, Any] = Field(default_factory=dict)
    model: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None


class Score(BaseModel):
    metric: str
    score: float
    passed: bool
    threshold: float
    weight: float
    baseline: float | None = None
    delta: float | None = None
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)
    # Banking-grade audit + gating metadata.
    critical: bool = False
    raw_value: float | None = Field(
        default=None,
        description="Pre-normalisation measurement (e.g. latency ms, token count).",
    )
    variance: float | None = Field(
        default=None,
        description="Sample variance across judge repetitions (self-consistency).",
    )
    unstable: bool = Field(
        default=False,
        description="Judge self-consistency variance exceeded EVAL_JUDGE_MAX_VARIANCE.",
    )
    unit: str = "ratio"


class SkippedMetric(BaseModel):
    """A metric that could not be assessed for a case.

    Retained on the run record so the report shows what was *not* measured
    instead of silently omitting it, which would overstate coverage. A skipped
    ``critical`` metric fails the case.
    """

    metric: str
    reason: str = ""
    weight: float = 1.0
    threshold: float = 0.0
    critical: bool = False
    judge: bool = False


class CaseResult(BaseModel):
    case_id: str
    scores: list[Score]
    skipped: list[SkippedMetric] = Field(default_factory=list)
    weighted_score: float
    weighted_delta: float
    passed: bool
    observation: Observation
    # Self-contained review context (case input + golden reference) so a run's
    # detail page does not depend on the since-changed dataset.
    input: dict[str, Any] = Field(default_factory=dict)
    golden_output: str | None = None


class RunStats(BaseModel):
    """Dataset-level statistics computed across all cases in a run.

    Confidence intervals and the drift test use a normal (z) approximation so
    the service stays dependency-free; for small n treat them as indicative.
    """

    n_cases: int = 0
    pass_rate: float = 0.0
    mean_score: float = 0.0
    score_stdev: float = 0.0
    ci95_low: float = 0.0
    ci95_high: float = 0.0
    # Drift vs baseline: `drift_significant` flags a statistically real and
    # material regression (mean_delta < 0, p < alpha, |mean_delta| >= min effect).
    mean_delta: float = 0.0
    drift_p_value: float | None = None
    drift_significant: bool = False
    # Judge-vs-human calibration (populated only when human labels exist).
    labeled_cases: int = 0
    precision: float | None = None
    recall: float | None = None
    f1: float | None = None
    cohens_kappa: float | None = None


class RunRecord(BaseModel):
    run_id: str
    agent_id: str
    dataset_id: str
    dataset_version: str
    weighted_score: float
    weighted_delta: float
    # Kept as ``str``: legacy rows may carry "ERROR..." variants.
    status: str = Field(description="PASS | FAIL | ERROR")
    creation_ts: str
    created_by: CreatedBy = "DEVELOPER"
    error_detail: str | None = None
    case_results: list[CaseResult] = Field(default_factory=list)
    stats: RunStats | None = None


class HumanLabel(BaseModel):
    """An expert verdict on a case, used to calibrate the automated gate/judge."""

    case_id: str
    verdict: str = Field(pattern=VERDICT_PATTERN, description="'pass' or 'fail'")
    score: float | None = Field(default=None, description="Optional human quality score 0..1")
    labeler: str = "anonymous"
    note: str = ""
    run_id: str | None = None
    agent_id: str | None = None
    created_at: str = ""
