"""Custom scorers for preliminary_research_agent.

The endpoint returns a top-level plan_number and an analysis_report bundle with
three report objects (for example additionalProp1..3). This module validates
that the response is structural, citation-backed, and not merely a schema
placeholder filled with literal "string" values.

The registry loads this file by path, so helpers are kept local (a sibling
module import would not resolve).
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from typing import Any

from scorers.base import scorer

logger = logging.getLogger(__name__)

CHECK_MARK = "✓"
CROSS_MARK = "✗"
PLACEHOLDER = "string"
MISSING_ID = "<missing>"
NO_REPORTS = "no analysis reports found"
NO_PARAGRAPHS = "no paragraphs found"
DEFAULT_REPORT_COUNT = 3
MAX_CONFIDENCE = 100

_PARAGRAPH_KEYS = (
    "paragraph_id", "content", "supporting_chunk_ids", "supporting_citations", "rationale", "metadata",
)
_PARAGRAPH_TEXT_KEYS = ("paragraph_id", "content", "rationale")
_CITATION_KEYS = ("chunk_id", "page_number", "gs_uri", "document_name", "content_type")

ScoreResult = tuple[float, str, list[str]]


# --------------------------------------------------------------------------- #
# Normalisation helpers
# --------------------------------------------------------------------------- #

def _output(observation) -> dict[str, Any]:
    out = observation.output
    if isinstance(out, str):
        try:
            out = json.loads(out)
        except ValueError:
            logger.debug("preliminary_research output is not JSON")
            return {}
    return out if isinstance(out, dict) else {}


def _reports(observation) -> list[dict[str, Any]]:
    bundle = _output(observation).get("analysis_report")
    if not isinstance(bundle, dict):
        return []
    return [value for value in bundle.values() if isinstance(value, dict)]


def _not_placeholder(value: Any) -> bool:
    """True for a non-empty string/number that is not the literal schema placeholder."""
    if value is None or isinstance(value, bool) or not isinstance(value, str | int | float):
        return False
    text = str(value).strip()
    return bool(text) and text.lower() != PLACEHOLDER


def _is_number(value: Any) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _as_list(value: Any) -> list[Any]:
    """Wrap a scalar (notably a string) in a list; None becomes empty."""
    if value is None:
        return []
    if isinstance(value, list | tuple):
        return list(value)
    return [value]


def _paragraphs(report: dict[str, Any]) -> list[dict[str, Any]]:
    paragraphs = report.get("paragraphs")
    if not isinstance(paragraphs, list):
        return []
    return [item for item in paragraphs if isinstance(item, dict)]


def _all_paragraphs(observation) -> list[dict[str, Any]]:
    return [paragraph for report in _reports(observation) for paragraph in _paragraphs(report)]


def _mark(good: bool) -> str:
    return CHECK_MARK if good else CROSS_MARK


def _pid(paragraph: dict[str, Any]) -> str:
    return repr(paragraph.get("paragraph_id", MISSING_ID))


def _score_paragraphs(
    observation, check: Callable[[dict[str, Any]], bool], summary: str, failure: str,
) -> ScoreResult:
    """Score the fraction of paragraphs passing ``check``; evidence lists failures."""
    paragraphs = _all_paragraphs(observation)
    if not paragraphs:
        return 0.0, NO_PARAGRAPHS, []
    evidence = [f"{CROSS_MARK} {failure} {_pid(p)}" for p in paragraphs if not check(p)]
    valid = len(paragraphs) - len(evidence)
    return valid / len(paragraphs), f"{valid}/{len(paragraphs)} {summary}", evidence


# --------------------------------------------------------------------------- #
# Paragraph predicates
# --------------------------------------------------------------------------- #

def _structure_ok(paragraph: dict[str, Any]) -> bool:
    return (
        all(key in paragraph for key in _PARAGRAPH_KEYS)
        and all(_not_placeholder(paragraph.get(key)) for key in _PARAGRAPH_TEXT_KEYS)
        and isinstance(paragraph.get("supporting_chunk_ids"), list)
        and isinstance(paragraph.get("supporting_citations"), list)
    )


def _citation_ok(paragraph: dict[str, Any]) -> bool:
    chunk_ids = paragraph.get("supporting_chunk_ids")
    citations = paragraph.get("supporting_citations")
    if not (isinstance(chunk_ids, list) and chunk_ids and isinstance(citations, list) and citations):
        return False
    return all(
        isinstance(citation, dict) and all(key in citation for key in _CITATION_KEYS)
        for citation in citations
    )


def _metadata_ok(paragraph: dict[str, Any]) -> bool:
    metadata = paragraph.get("metadata")
    if not isinstance(metadata, dict):
        return False
    conf = metadata.get("section_confidence_score")
    return (
        isinstance(metadata.get("is_section_start"), bool)
        and _is_number(conf)
        and 0 <= conf <= MAX_CONFIDENCE
    )


def _rationale_ok(paragraph: dict[str, Any]) -> bool:
    rationale = paragraph.get("rationale")
    return isinstance(rationale, str) and _not_placeholder(rationale)


# --------------------------------------------------------------------------- #
# Scorers
# --------------------------------------------------------------------------- #

def _expected(case) -> dict[str, Any]:
    expected = case.expected
    return expected if isinstance(expected, dict) else {}


def _expected_report_count(case) -> int:
    raw = _expected(case).get("report_count", DEFAULT_REPORT_COUNT)
    return raw if _is_number(raw) and raw >= 0 else DEFAULT_REPORT_COUNT


@scorer("analysis_bundle_present")
def analysis_bundle_present(*, observation, case, **_) -> ScoreResult:
    found = len(_reports(observation))
    expected_count = int(_expected_report_count(case))
    score = min(found, expected_count) / expected_count if expected_count else 1.0
    evidence = [f"reports={found} expected={expected_count}"]
    return score, f"{found}/{expected_count} analysis reports present", evidence


@scorer("analysis_report_titles_valid")
def analysis_report_titles_valid(*, observation, case, **_) -> ScoreResult:
    reports = _reports(observation)
    if not reports:
        return 0.0, NO_REPORTS, []
    evidence = []
    valid = 0
    for report in reports:
        title = report.get("report_title")
        good = isinstance(title, str) and _not_placeholder(title)
        valid += int(good)
        evidence.append(f"{_mark(good)} {title!r}")
    return valid / len(reports), f"{valid}/{len(reports)} report titles valid", evidence


@scorer("analysis_paragraphs_valid")
def analysis_paragraphs_valid(*, observation, case, **_) -> ScoreResult:
    reports = _reports(observation)
    if not reports:
        return 0.0, NO_REPORTS, []
    counts = [len(_paragraphs(report)) for report in reports]
    valid = sum(1 for count in counts if count)
    evidence = [f"{_mark(bool(count))} paragraphs={count}" for count in counts]
    return valid / len(reports), f"{valid}/{len(reports)} reports have paragraphs", evidence


@scorer("analysis_paragraph_structure_valid")
def analysis_paragraph_structure_valid(*, observation, case, **_) -> ScoreResult:
    return _score_paragraphs(observation, _structure_ok, "paragraphs structurally valid", "invalid paragraph")


@scorer("analysis_citation_grounding")
def analysis_citation_grounding(*, observation, case, **_) -> ScoreResult:
    return _score_paragraphs(observation, _citation_ok, "paragraphs citation-grounded", "citation gap in")


@scorer("analysis_metadata_valid")
def analysis_metadata_valid(*, observation, case, **_) -> ScoreResult:
    return _score_paragraphs(observation, _metadata_ok, "paragraphs have valid metadata", "invalid metadata in")


@scorer("analysis_rationale_valid")
def analysis_rationale_valid(*, observation, case, **_) -> ScoreResult:
    return _score_paragraphs(observation, _rationale_ok, "paragraphs have rationale", "empty rationale in")


@scorer("plan_number_valid")
def plan_number_valid(*, observation, case, **_) -> ScoreResult:
    raw = _output(observation).get("plan_number")
    observed = str(raw) if _not_placeholder(raw) else ""
    case_input = case.input if isinstance(case.input, dict) else {}
    expected = str(case_input.get("planNumber", ""))
    good = bool(observed) and observed == expected
    evidence = [f"observed={observed!r}", f"expected={expected!r}"]
    rationale = "plan number matches input" if good else "plan number mismatch"
    return float(good), rationale, evidence


@scorer("analysis_expected_values_present")
def analysis_expected_values_present(*, observation, case, **_) -> ScoreResult:
    expected_values = _as_list(_expected(case).get("expected_values"))
    if not expected_values:
        return 1.0, "no expected_values configured", []
    text = json.dumps(_output(observation), ensure_ascii=False).lower()
    hits = [str(value).lower() in text for value in expected_values]
    evidence = [f"{_mark(hit)} {value}" for value, hit in zip(expected_values, hits, strict=True)]
    present = sum(hits)
    return present / len(expected_values), f"{present}/{len(expected_values)} expected values present", evidence
