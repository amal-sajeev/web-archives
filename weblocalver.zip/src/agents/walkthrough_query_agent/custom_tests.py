"""Walkthrough Q&A adapter: seed the hosted agent with the eval document.

The production `/qna/chat` API loads context from GCS (or an in-memory session
warmed by another UI panel). Eval cases therefore:

1. Upload ``source_document.json`` once via ``POST /qna/upload``.
2. Send every chat request with that ``contextGcsUri`` *and* the document as
   ``researchSections`` (newer agents seed the session inline; older ones
   autoload from the URI).
3. Attach the document as ``observation.source_context`` so groundedness
   judges the answer against the same walkthrough, not an empty context.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

import httpx

# No public header builder exists yet; http_adapter keeps re-exporting this helper.
from adapters.http_adapter import HttpAdapter, _build_headers, register_adapter
from core.models import GoldenCase, Observation
from service.http_client import build_async_client_kwargs
from service.http_errors import describe_http_error

logger = logging.getLogger(__name__)

_DOC_NAME = "source_document.json"
_DOC_PATH = Path(__file__).resolve().parent / _DOC_NAME
_UPLOAD_BLOB = "eval/walkthrough_query_agent/source_document.json"
_UPLOAD_PATH = "/qna/upload"
_DEFAULT_UPLOAD_TIMEOUT_S = 180.0


def _load_source_document() -> dict[str, Any]:
    return json.loads(_DOC_PATH.read_text(encoding="utf-8"))


@register_adapter("walkthrough_http")
class WalkthroughHttpAdapter(HttpAdapter):
    """HTTP adapter that publishes the walkthrough document before chatting."""

    adapter_id = "walkthrough_http"

    def __init__(self, base_url, endpoint, target=None):
        super().__init__(base_url, endpoint, target)
        self._doc_cache: dict[str, Any] | None = None
        self._gcs_uri: str | None = None
        self._upload_lock = asyncio.Lock()

    @property
    def _doc(self) -> dict[str, Any]:
        """The source document, read from disk on first use."""
        if self._doc_cache is None:
            self._doc_cache = _load_source_document()
        return self._doc_cache

    async def _upload_document(self) -> str:
        timeout = self._target.timeout or _DEFAULT_UPLOAD_TIMEOUT_S
        files = {
            "file": (
                _DOC_NAME,
                json.dumps(self._doc, ensure_ascii=False).encode("utf-8"),
                "application/json",
            )
        }
        headers = _build_headers(self._target, {})
        # For multipart/form-data, let httpx set the boundary/content-type.
        headers.pop("Content-Type", None)
        client_kwargs = build_async_client_kwargs(timeout=timeout, trust_env=self._target.trust_env)
        async with httpx.AsyncClient(**client_kwargs) as client:
            resp = await client.post(
                f"{self._base_url}{_UPLOAD_PATH}",
                files=files,
                data={"dest_blob_path": _UPLOAD_BLOB},
                headers=headers,
            )
            resp.raise_for_status()
            body = resp.json() if resp.content else {}
        if not isinstance(body, dict):
            body = {}
        return body.get("gcs_uri") or body.get("gcs_blob_path") or _UPLOAD_BLOB

    async def _ensure_document_uri(self) -> str:
        """Upload the document once per adapter; concurrent cases share the result."""
        async with self._upload_lock:
            if self._gcs_uri is None:
                self._gcs_uri = await self._upload_document()
            return self._gcs_uri

    def _chat_input(self, case: GoldenCase, gcs_uri: str | None) -> dict[str, Any]:
        inp = dict(case.input or {})
        inp["researchSections"] = inp.get("researchSections") or self._doc
        if gcs_uri:
            inp["contextGcsUri"] = gcs_uri
        else:
            inp.pop("contextGcsUri", None)
        return inp

    async def run_case(self, case: GoldenCase) -> Observation:
        gcs_uri = None
        upload_error = None
        try:
            gcs_uri = await self._ensure_document_uri()
        except (httpx.HTTPError, ValueError, OSError) as exc:
            upload_error = describe_http_error(exc)
            logger.warning("walkthrough document upload failed for case %s: %s", case.id, upload_error)

        patched = case.model_copy(deep=True)
        patched.input = self._chat_input(case, gcs_uri)
        observation = await super().run_case(patched)
        if not observation.source_context:
            observation.source_context = self._doc
        if observation.error and upload_error:
            observation.error = f"{observation.error} (document upload also failed: {upload_error})"
        return observation
