#!/usr/bin/env python3
"""Validate the walkthrough_query_agent configuration.

Parses ``agent.yaml`` and ``dataset.json`` with the service's own pydantic
models (``core.models.AgentConfig`` / ``Dataset``), checks the walkthrough
specific contract (endpoint, adapter, golden fields), confirms every metric's
scorer is registered, and loads the agent through the real ``Registry``.

Run:  python src/agents/walkthrough_query_agent/validate_config.py
Exit code is 0 when there are no errors, 1 otherwise. Warnings are always shown.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

AGENT_DIR = Path(__file__).resolve().parent
_MAIN_DIR = AGENT_DIR.parents[1] / "main"
if str(_MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(_MAIN_DIR))

import yaml
from pydantic import ValidationError

from core.models import AgentConfig, Dataset

AGENT_ID = "walkthrough_query_agent"
EXPECTED_ENDPOINT = "/qna/chat"
ALLOWED_ADAPTERS = ("http", "walkthrough_http")
RULE = "=" * 60


@dataclass
class Report:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    info: list[str] = field(default_factory=list)


def _out(line: str = "") -> None:
    sys.stdout.write(f"{line}\n")


def _read_text(path: Path, report: Report) -> str | None:
    if not path.is_file():
        report.errors.append(f"{path.name} not found")
        return None
    return path.read_text(encoding="utf-8-sig")


def load_agent_config(report: Report) -> AgentConfig | None:
    text = _read_text(AGENT_DIR / "agent.yaml", report)
    if text is None:
        return None
    try:
        config = AgentConfig.model_validate(yaml.safe_load(text) or {})
    except (yaml.YAMLError, ValidationError) as exc:
        report.errors.append(f"agent.yaml invalid: {exc}")
        return None
    if config.agent_id != AGENT_ID:
        report.errors.append(f"agent.yaml agent_id mismatch: {config.agent_id!r}")
    if not config.base_url:
        report.warnings.append("agent.yaml has no base_url (falls back to AGENT_SERVICE_BASE_URL)")
    return config


def load_dataset(config: AgentConfig | None, report: Report) -> Dataset | None:
    dataset_file = config.dataset_file if config else "dataset.json"
    text = _read_text(AGENT_DIR / dataset_file, report)
    if text is None:
        return None
    try:
        return Dataset.model_validate(json.loads(text))
    except (ValueError, ValidationError) as exc:
        report.errors.append(f"{dataset_file} invalid: {exc}")
        return None


def check_target(dataset: Dataset, report: Report) -> None:
    target = dataset.target
    if target.endpoint != EXPECTED_ENDPOINT:
        report.errors.append(f"target.endpoint should be {EXPECTED_ENDPOINT!r}, got {target.endpoint!r}")
    if target.adapter not in ALLOWED_ADAPTERS:
        report.errors.append(f"target.adapter should be one of {ALLOWED_ADAPTERS}, got {target.adapter!r}")


def check_metrics(dataset: Dataset, report: Report) -> None:
    if not dataset.metrics:
        report.errors.append("metrics list is empty")
        return
    report.info.append(f"{len(dataset.metrics)} metrics defined")
    names = [m.name for m in dataset.metrics]
    duplicates = sorted({n for n in names if names.count(n) > 1})
    if duplicates:
        report.errors.append(f"duplicate metric names: {duplicates}")


def check_cases(dataset: Dataset, report: Report) -> None:
    if not dataset.cases:
        report.errors.append("cases list is empty")
        return
    report.info.append(f"{len(dataset.cases)} golden test cases defined")
    for case in dataset.cases:
        if not case.golden_output and not case.golden_file:
            report.errors.append(f"case {case.id!r} has no golden_output")
        if not case.baseline_metrics:
            report.warnings.append(f"case {case.id!r} has no baseline_metrics")


def check_scorers(dataset: Dataset, report: Report) -> None:
    """Every metric's scorer must be registered (built-ins plus custom_tests.py)."""
    try:
        from registry import Registry
        from scorers import all_scorers

        registry = Registry(AGENT_DIR.parent).load()
        registry.get(AGENT_ID)
    except (KeyError, ValueError, ImportError, OSError) as exc:
        report.errors.append(f"registry load failed: {exc}")
        return
    known = all_scorers()
    for metric in dataset.metrics:
        if metric.scorer not in known:
            report.errors.append(f"metric {metric.name!r}: unknown scorer {metric.scorer!r}")


def check_metrics_stub(config: AgentConfig | None, dataset: Dataset, report: Report) -> None:
    stub_file = config.metrics_stub_file if config else "metrics_stub.json"
    path = AGENT_DIR / stub_file
    if not path.is_file():
        report.warnings.append(f"{stub_file} not found (optional)")
        return
    try:
        stub: Any = json.loads(path.read_text(encoding="utf-8-sig"))
    except ValueError as exc:
        report.errors.append(f"{stub_file} JSON parse error: {exc}")
        return
    stub_cases = stub.get("cases", {}) if isinstance(stub, dict) else {}
    report.info.append(f"{stub_file} has {len(stub_cases)} case stubs")
    missing = sorted({c.id for c in dataset.cases} - set(stub_cases))
    if missing:
        report.warnings.append(f"{stub_file} has no stub for cases: {missing}")


def validate() -> tuple[Report, AgentConfig | None, Dataset | None]:
    report = Report()
    config = load_agent_config(report)
    dataset = load_dataset(config, report)
    if dataset is not None:
        check_target(dataset, report)
        check_metrics(dataset, report)
        check_cases(dataset, report)
        check_scorers(dataset, report)
        check_metrics_stub(config, dataset, report)
    return report, config, dataset


def _print_section(title: str, lines: list[str]) -> None:
    if not lines:
        return
    _out(f"\n{title} ({len(lines)}):")
    for line in lines:
        _out(f"  - {line}")


def print_report(report: Report, config: AgentConfig | None, dataset: Dataset | None) -> None:
    for line in report.info:
        _out(f"[ok] {line}")
    _out()
    _out(RULE)
    _out("Configuration Validation Results")
    _out(RULE)
    _print_section("ERRORS", report.errors)
    _print_section("WARNINGS", report.warnings)
    if not report.errors:
        _out("\nAll validations passed.")
    if config and dataset:
        _out("\nConfiguration Summary:")
        _out(f"  Agent ID: {config.agent_id}")
        _out(f"  Endpoint: {dataset.target.endpoint} ({dataset.target.method})")
        _out(f"  Adapter: {dataset.target.adapter}")
        _out(f"  Golden Cases: {len(dataset.cases)}")
        _out(f"  Metrics: {len(dataset.metrics)}")


def main() -> int:
    report, config, dataset = validate()
    print_report(report, config, dataset)
    return 1 if report.errors else 0


if __name__ == "__main__":
    sys.exit(main())
