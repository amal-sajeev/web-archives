"""Agent-specific (custom) scorers for the scoping_summary agent.

Auto-imported by the registry (by file path, so helpers stay local); each
@scorer self-registers under a name that dataset.json references. The agent
returns an `analysis_report` bundle of three `ScopingReport = {report_title,
paragraphs:[{paragraph_id, content, supporting_chunk_ids[], rationale,
metadata:{is_section_start, section_confidence_score}}]}`. Over HTTP each report
is a JSON dict; the persisted GCS copy stringifies the pydantic repr. The
helpers normalise BOTH shapes so the scorers work live and on stored samples.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from scorers.base import scorer

logger = logging.getLogger(__name__)

CHECK_MARK = "✓"
CROSS_MARK = "✗"
PLACEHOLDER = "string"
NO_PARAGRAPHS = "no paragraphs found in output"
MAX_CONFIDENCE = 100
HEADING_MAX_CHARS = 80
SNIPPET_CHARS = 50

# The three reports the bundle must contain, each keyed by its exact title.
_REQUIRED_REPORTS = (
    "Past Review Analysis",
    "Policy and Regulatory Analysis",
    "Broad Scope Direction",
)

# A bare section heading paragraph (e.g. "Section 3: ...") legitimately carries
# no citations; used to avoid penalising headings in citation_grounding.
_HEADING_RE = re.compile(r"^\s*(section\s+\d+|broad scope direction)\b", re.I)

ScoreResult = tuple[float, str, list[str]]


def _is_number(value: Any) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _as_list(value: Any) -> list[Any]:
    """Wrap a scalar (notably a string) in a list; None becomes empty."""
    if value is None:
        return []
    if isinstance(value, list | tuple):
        return list(value)
    return [value]


def _not_placeholder(text: str) -> bool:
    stripped = text.strip()
    return bool(stripped) and stripped.lower() != PLACEHOLDER


def _expected(case) -> dict[str, Any]:
    expected = case.expected
    return expected if isinstance(expected, dict) else {}


def _required_reports(case) -> list[str]:
    return [str(r) for r in _as_list(_expected(case).get("required_reports", list(_REQUIRED_REPORTS)))]


def _mark(good: bool) -> str:
    return CHECK_MARK if good else CROSS_MARK


def _reports_bundle(observation) -> dict[str, Any]:
    """Return {report_name: dict-or-repr-string} from output (a dict or its JSON string)."""
    out = observation.output
    if isinstance(out, str):
        try:
            out = json.loads(out)
        except ValueError:
            logger.debug("scoping_summary output is not JSON")
            return {}
    if not isinstance(out, dict):
        return {}
    # Either already the bundle, or wrapped as {analysis_report: {...}}.
    wrapped = out.get("analysis_report")
    return wrapped if isinstance(wrapped, dict) else out


def _title_of(report_value: Any) -> str:
    if isinstance(report_value, dict):
        return str(report_value.get("report_title", ""))
    if isinstance(report_value, str):
        m = re.search(r"report_title=['\"](.*?)['\"]", report_value)
        return m.group(1) if m else ""
    return ""


def _coerce_ids(ids: Any) -> list[int]:
    out: list[int] = []
    if not isinstance(ids, list | tuple):
        return out
    for v in ids:
        if isinstance(v, bool):
            continue
        try:
            out.append(int(str(v).strip().strip("'\"")))
        except (TypeError, ValueError):
            continue
    return out


def _dict_paragraph(p: dict[str, Any]) -> dict[str, Any]:
    meta = p.get("metadata")
    if not isinstance(meta, dict):
        meta = {}
    return {
        "content": str(p.get("content") or ""),
        "chunk_ids": _coerce_ids(p.get("supporting_chunk_ids")),
        "rationale": str(p.get("rationale") or ""),
        "is_section_start": meta.get("is_section_start") is True,
        "confidence": meta.get("section_confidence_score"),
    }


def _paragraphs_of(report_value: Any) -> list[dict]:
    """Normalise a report into paragraph dicts (content, chunk_ids, rationale, is_section_start, confidence)."""
    if isinstance(report_value, dict):
        raw = report_value.get("paragraphs")
        items = raw if isinstance(raw, list) else []
        return [_dict_paragraph(p) for p in items if isinstance(p, dict)]
    if isinstance(report_value, str):
        return _parse_repr_paragraphs(report_value)
    return []


def _repr_segment(seg: str) -> dict[str, Any]:
    content_m = re.search(r"content=(['\"])(.*?)\1,\s*supporting_chunk_ids", seg, re.S)
    ids_m = re.search(r"supporting_chunk_ids=\[([^\]]*)\]", seg)
    rat_m = re.search(r"rationale=(['\"])(.*?)\1,\s*metadata", seg, re.S)
    start_m = re.search(r"is_section_start=(True|False)", seg)
    conf_m = re.search(r"section_confidence_score=(\d+|None)", seg)
    has_conf = bool(conf_m) and conf_m.group(1) != "None"
    return {
        "content": content_m.group(2) if content_m else "",
        "chunk_ids": [int(x) for x in re.findall(r"\d+", ids_m.group(1))] if ids_m else [],
        "rationale": rat_m.group(2) if rat_m else "",
        "is_section_start": bool(start_m) and start_m.group(1) == "True",
        "confidence": int(conf_m.group(1)) if has_conf else None,
    }


def _parse_repr_paragraphs(text: str) -> list[dict]:
    """Best-effort parse of the persisted `ParagraphCitation(...)` repr, segmented on `paragraph_id=`."""
    starts = [m.start() for m in re.finditer(r"paragraph_id=", text)]
    ends = [*starts[1:], len(text)]
    return [_repr_segment(text[s:e]) for s, e in zip(starts, ends, strict=True)]


def _all_paragraphs(observation) -> list[dict]:
    return [p for value in _reports_bundle(observation).values() for p in _paragraphs_of(value)]


def _bundle_text(observation) -> str:
    """Flat lowercase text of all report content, for substring assertions."""
    return " ".join(p["content"] for p in _all_paragraphs(observation)).lower()


def _is_heading_only(p: dict) -> bool:
    c = p["content"].strip()
    return bool(_HEADING_RE.match(c)) and len(c) <= HEADING_MAX_CHARS


def _confidence_violation(p: dict) -> str | None:
    """Return an evidence line if the paragraph breaks the confidence rule."""
    conf = p["confidence"]
    if p["is_section_start"]:
        if _is_number(conf) and 0 <= conf <= MAX_CONFIDENCE:
            return None
        return f"{CROSS_MARK} section-start missing valid confidence: {conf}"
    if conf is None:
        return None
    return f"{CROSS_MARK} non-section paragraph has confidence {conf}"


def _grounding_violation(p: dict, max_id: int) -> str | None:
    ids = p["chunk_ids"]
    bad = [i for i in ids if i < 1 or (max_id and i > max_id)]
    if bad:
        return f"{CROSS_MARK} out-of-range chunk_ids {bad} (max {max_id})"
    if not ids and not _is_heading_only(p):
        content = p["content"]
        snippet = f"{content[:SNIPPET_CHARS]}..." if content else "(empty)"
        return f"{CROSS_MARK} uncited claim: {snippet}"
    return None


@scorer("scoping_reports_present")
def scoping_reports_present(*, observation, case, **_) -> ScoreResult:
    """All three required reports must be present (with paragraphs) in the bundle."""
    required = _required_reports(case)
    bundle = _reports_bundle(observation)
    present = [r for r in required if _paragraphs_of(bundle.get(r))]
    evidence = [f"{_mark(r in present)} {r}" for r in required]
    score = len(present) / len(required) if required else 1.0
    return score, f"{len(present)}/{len(required)} required reports present", evidence


@scorer("scoping_titles_exact")
def scoping_titles_exact(*, observation, case, **_) -> ScoreResult:
    """Each report's report_title must equal its required title verbatim."""
    required = _required_reports(case)
    bundle = _reports_bundle(observation)
    ok, evidence = 0, []
    for name in required:
        title = _title_of(bundle.get(name))
        good = title == name
        ok += int(good)
        evidence.append(f"{_mark(good)} {name!r} -> {title!r}")
    score = ok / len(required) if required else 1.0
    return score, f"{ok}/{len(required)} titles exact", evidence


@scorer("scoping_sections_present")
def scoping_sections_present(*, observation, case, **_) -> ScoreResult:
    """Every heading in expected.required_sections = {report_name: [headings]} appears in that report."""
    required = _expected(case).get("required_sections")
    if not isinstance(required, dict) or not required:
        return 1.0, "no required_sections configured", []
    bundle = _reports_bundle(observation)
    total, found, evidence = 0, 0, []
    for report_name, headings in required.items():
        text = " ".join(p["content"] for p in _paragraphs_of(bundle.get(report_name))).lower()
        for h in _as_list(headings):
            total += 1
            hit = str(h).lower() in text
            found += int(hit)
            if not hit:
                evidence.append(f"{CROSS_MARK} {report_name}: missing '{h}'")
    score = found / total if total else 1.0
    rationale = f"{found}/{total} required sections present"
    return score, rationale, evidence or [rationale]


@scorer("citation_grounding")
def citation_grounding(*, observation, case, **_) -> ScoreResult:
    """Traceability: cited ids lie in 1..expected.max_chunk_id and every non-heading paragraph cites a chunk.

    Score = 1 - violations / paragraphs.
    """
    raw_max = _expected(case).get("max_chunk_id")
    max_id = int(raw_max) if _is_number(raw_max) else 0
    paras = _all_paragraphs(observation)
    if not paras:
        return 0.0, NO_PARAGRAPHS, []
    evidence = [v for v in (_grounding_violation(p, max_id) for p in paras) if v]
    score = max(0.0, 1.0 - len(evidence) / len(paras))
    rationale = f"{len(paras) - len(evidence)}/{len(paras)} paragraphs properly grounded"
    return score, rationale, evidence or [rationale]


@scorer("rationale_coverage")
def rationale_coverage(*, observation, case, **_) -> ScoreResult:
    """Every paragraph must carry a non-empty, non-placeholder generation rationale."""
    paras = _all_paragraphs(observation)
    if not paras:
        return 0.0, NO_PARAGRAPHS, []
    with_rat = sum(1 for p in paras if _not_placeholder(p["rationale"]))
    return with_rat / len(paras), f"{with_rat}/{len(paras)} paragraphs have a rationale", []


@scorer("confidence_score_valid")
def confidence_score_valid(*, observation, case, **_) -> ScoreResult:
    """section_confidence_score (0..100) is required exactly when is_section_start is true."""
    paras = _all_paragraphs(observation)
    if not paras:
        return 0.0, NO_PARAGRAPHS, []
    evidence = [v for v in (_confidence_violation(p) for p in paras) if v]
    ok = len(paras) - len(evidence)
    return ok / len(paras), f"{ok}/{len(paras)} paragraphs obey the confidence rule", evidence


@scorer("scope_entities_present")
def scope_entities_present(*, observation, case, **_) -> ScoreResult:
    """Key identifiers (expected.expected_values, e.g. "20588", "R137") appear verbatim; score = fraction present."""
    expected_values = _as_list(_expected(case).get("expected_values"))
    if not expected_values:
        return 1.0, "no expected_values to check", []
    text = _bundle_text(observation)
    missing = [v for v in expected_values if str(v).lower() not in text]
    evidence = [f"{CROSS_MARK} missing {v}" if v in missing else f"{CHECK_MARK} {v}" for v in expected_values]
    score = (len(expected_values) - len(missing)) / len(expected_values)
    rationale = f"missing: {missing}" if missing else "all key entities present"
    return score, rationale, evidence
