# Pull Request Description: `scoping-lrrextraction-agent`

## Summary
Migrates `scoping-lrrextraction-agent` LLM calls to the Google OAuth / AI Access Layer setup, persists enriched LRR mandates into `dbaware_scoping.review_data_extraction`, and ensures full test compatibility.

## What Changed
- **AI Access Layer Authentication & Config Cleanup**
  - `src/main/runtime/google_oauth_token_provider.py` *(new)*: Adds `GoogleOAuthTokenProvider` and `configure_certificate_once` for corporate CA bundle and Google OAuth token refresh.
  - `src/main/config/settings.py`, `src/main/config/app.yml`, & `src/main/runtime/llm_provider.py`: Uses `api_key` + `base_url` via `AI_ACCESS_LAYER_BASE_URL` / `GENAI_BASE_URL` with `ChatGoogleGenerativeAI`; removes vestigial `temperature`, `top_p`, `top_k`, `generation_seed`, `google_genai_use_vertexai`, commented-out lines, and duplicate `source_host_aliases` definition.
- **LRR Metadata Persistence in `review_data_extraction`**
  - `src/main/clients/postgres_client.py` *(new)*: Builds structured `lrr` metadata (`build_lrr_metadata_payload`) containing `internet_search_data_enriched.json`, `storage_uri`, `status`, `excluded`, and one `sections[]` entry per mandate (`section_id`, `section_title`, `node_id: "lrr:mandate:<idx>"`, `risk_name`, `citation`, `issuing_authority`, `source_urls`, `status`, `excluded`) and persists it to `dbaware_scoping.review_data_extraction`.
  - `src/main/risk_context/phase_3_mandate_generation.py`: Calls `upsert_lrr_data_extraction_metadata(...)` after saving `internet_search_data_enriched.json` to GCS.
- **API & Runtime Fixes**
  - `src/main/routes/lrr.py`: Uses `list[UploadFile] = File(default=[], ...)` so FastAPI/Pydantic multipart uploads validate cleanly.
  - `src/main/runtime/runner.py`: Fixes event emission state handling during graph execution.
- **Tests**
  - Added tests for `postgres_client`, `google_oauth_token_provider`, `llm_provider`, `lrr` routes, and Phase 3 persistence.

## Why
Brings LRR extraction into the same `review_data_extraction` metadata model so users can soft-exclude or restore individual LRR mandates via the query agent and regenerate the Preliminary Research `policy_regulation` and `broad_scope` sections.

## Testing & Coverage
- Command: `PYTHONPATH="src/main;src" pytest src/tests --cov=src/main --cov-report=term-missing --cov-fail-under=80`
- Result: **273 passed, 0 failed** (**80.09% statement coverage**)
