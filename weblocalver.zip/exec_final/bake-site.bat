@echo off
setlocal EnableExtensions
title Trade Collections - Process Cases and Bake Static Site
cd /d "%~dp0"

rem Rebuild every case through the processing pipeline, then replace .\site
rem with a fresh, fully rendered static snapshot. No server is started.
set "VENV=.venv"
set "VPY=%VENV%\Scripts\python.exe"
set "PY="

 echo.
echo   Trade Collections - Process Cases and Bake Static Site
echo   =====================================================
echo.
echo   This will process all sample cases and replace the existing site folder.
echo   Keep this window open until the build finishes.
echo.

rem Find a working Python 3.10+ installation.
for %%C in (python.exe py.exe python3.exe) do (
  if not defined PY (
    if "%%~$PATH:C"=="" (
      rem Continue searching PATH.
    ) else (
      "%%~$PATH:C" --version >nul 2>&1
      if not errorlevel 1 set "PY=%%~$PATH:C"
    )
  )
)
if not defined PY (
  py -3 --version >nul 2>&1 && set "PY=py -3"
)
if not defined PY (
  echo ERROR: Python 3.10 or newer was not found.
  echo Install Python from https://www.python.org/downloads/ and enable PATH access.
  pause
  exit /b 1
)

if not exist "%VPY%" (
  echo Creating the local Python environment...
  %PY% -m venv "%VENV%"
  if errorlevel 1 goto :error
)

"%VPY%" -c "import fastapi, uvicorn, jinja2, pydantic" >nul 2>&1
if errorlevel 1 (
  echo Installing required packages...
  "%VPY%" -m pip install --upgrade pip --disable-pip-version-check
  if errorlevel 1 goto :error
  "%VPY%" -m pip install -r requirements.txt --disable-pip-version-check
  if errorlevel 1 goto :error
)

echo.
echo [1/2] Processing all cases and rendering pages...
echo.
"%VPY%" tools\freeze.py --out "%CD%\site"
if errorlevel 1 goto :error

echo.
echo [2/2] Static site rebuilt successfully.
echo.
echo Output folder: %CD%\site
echo Open: %CD%\site\index.html
echo.
pause
exit /b 0

:error
echo.
echo ERROR: The processing or static-site build failed.
echo The existing site is only replaced when the freeze script reaches its write stage.
echo Review the error above, then run bake-site.bat again.
echo.
pause
exit /b 1
