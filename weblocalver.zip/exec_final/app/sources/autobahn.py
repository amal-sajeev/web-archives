"""Autobahn / OEMS — the per-client pricing text.

Stands in for the Products tab of a client in Autobahn, where the approved
pricing lives in a free-format text box. It is prose written by relationship
managers over several years, so the job here is to read it, not to look it up:

    "INR 350 PER TRANSACTION FOR IMPORT PAYMENTS, AGENCY COMMISSION..."
    "Import Payment: INR 450 per document"
    "Commission - INR 1000 per import doc and not at BOE level"

The parser reports what it found *and* how sure it is. Anything it cannot read
confidently is handed to the maker rather than guessed at, and a client with no
instruction on file stops the case — there is no approved price to charge.
"""

from __future__ import annotations

import re

from ._data import load, normalise_name
from ..text import n

# "INR 350 PER TRANSACTION", "INR 1000 per import doc", "INR 450 per document"
_AMOUNT = re.compile(
    r"(?:INR|RS\.?)\s*([\d,]+(?:\.\d+)?)\s*(?:/-)?\s*(?:PER|P\.?A\.?|EACH)\s+([A-Z ]{3,30})",
    re.IGNORECASE)

_BASIS = [
    (r"\bIMPORT\s+DOC", "per_document", "per import document"),
    (r"\bDOCUMENT\b|\bDOC\b", "per_document", "per document"),
    (r"\bTRANSACTION\b|\bTXN\b", "per_transaction", "per transaction"),
    (r"\bBILL\s+OF\s+ENTRY\b|\bBOE\b", "per_boe", "per Bill of Entry"),
    (r"\bREMITTANCE\b", "per_remittance", "per remittance"),
]


def is_sample() -> bool:
    """True when the file holds a sample of clients rather than the full book."""
    return bool(load("autobahn").get("isSample"))


def coverage(importers: list[str] | None = None) -> dict:
    """Which clients have pricing on file, and which were never supplied.

    The distinction matters. A client absent from a *sample* has simply not been
    given to us; concluding that it has no approved pricing would be inventing a
    fact about the customer.
    """
    entries = load("autobahn").get("clients", [])
    supplied = [e["client"] for e in entries]
    missing = [i for i in (importers or []) if instruction_for(i) is None]
    unused = [c for c in supplied
              if not any(instruction_for(i) and instruction_for(i)["client"] == c
                         for i in (importers or []))]
    return {
        "isSample": is_sample(),
        "suppliedFor": supplied,
        "notSuppliedFor": missing,
        "suppliedButUnused": unused,
        "note": ("The Autobahn pages supplied cover "
                 f"{n(len(supplied), 'client')}. Pricing for a client that is not "
                 "among them has not been supplied, which is not the same as "
                 "the client having none."),
    }


def instruction_for(client: str) -> dict | None:
    """The raw processing text held against a client, if there is one."""
    want = normalise_name(client)
    for entry in load("autobahn").get("clients", []):
        if normalise_name(entry["client"]) == want:
            return entry
        for alias in entry.get("matches", []):
            if normalise_name(alias) and normalise_name(alias) in want:
                return entry
    return None


def parse(text: str) -> dict:
    """Pull an amount and a charging basis out of the processing text."""
    if not text or not text.strip():
        return {"found": False, "confidence": 0.0,
                "message": "The processing text is empty."}

    match = _AMOUNT.search(text)
    if not match:
        return {"found": False, "confidence": 0.0,
                "message": "No 'INR <amount> per <basis>' phrasing could be found in "
                           "the processing text. A maker needs to read it."}

    amount = float(match.group(1).replace(",", ""))
    tail = match.group(2).upper()

    basis, basis_label = None, None
    for pattern, key, label in _BASIS:
        if re.search(pattern, tail, re.IGNORECASE):
            basis, basis_label = key, label
            break
    if basis is None:
        # the basis may sit further along the sentence than the capture reached
        window = text[match.end(): match.end() + 80].upper()
        for pattern, key, label in _BASIS:
            if re.search(pattern, window, re.IGNORECASE):
                basis, basis_label = key, label
                break

    # the line it came from, so a maker can see the evidence
    evidence = next((ln.strip() for ln in text.splitlines()
                     if match.group(0).split()[1] in ln), match.group(0)).strip()

    confidence = 0.95 if basis else 0.55
    notes = []
    if re.search(r"NOT\s+AT\s+BOE\s+LEVEL", text, re.IGNORECASE):
        notes.append("Charged per document, explicitly not at Bill of Entry level.")
    if re.search(r"REMITTANCE\s+LEVEL", text, re.IGNORECASE):
        notes.append("Pricing to be levied at remittance level.")
    if len(_AMOUNT.findall(text)) > 1:
        confidence = min(confidence, 0.5)
        notes.append("The text quotes more than one amount; a maker should confirm "
                     "which one applies.")

    return {
        "found": True,
        "amountInr": amount,
        "basis": basis or "unknown",
        "basisLabel": basis_label or "basis not stated",
        "confidence": round(confidence, 2),
        "evidence": evidence,
        "notes": notes,
        "message": None if basis else
                   "An amount was found but the charging basis is not stated plainly.",
    }


def quote(client: str, *, documents: int = 1, gross_inr: float = 0.0) -> dict:
    """What to charge: commission, the forex conversion fee, and GST.

    Per the written procedure, the commission comes from the client's OEMS text.
    The forex conversion fee follows its own bracketed clause; 18% GST applies
    to commission only.
    """
    entry = instruction_for(client)
    if entry is None:
        return {
            "status": "awaiting_pricing" if is_sample() else "no_instruction",
            "client": client,
            "message": (f"Autobahn pricing for {client} has not been supplied. The "
                        "sample covers other clients, so there is nothing here to "
                        "read — this does not mean the client is unpriced."
                        if is_sample() else
                        f"No approved pricing is held in Autobahn for {client}. "
                        "Nothing can be charged until one is recorded."),
            "lines": [], "totalInr": 0.0,
        }

    reading = parse(entry["processingText"])
    if not reading["found"]:
        return {
            "status": "unreadable",
            "client": entry["client"],
            "processingText": entry["processingText"],
            "reading": reading,
            "message": reading["message"],
            "lines": [], "totalInr": 0.0,
        }

    units = documents if reading["basis"] in ("per_document", "per_remittance") else 1
    commission = reading["amountInr"] * units
    fx_fee = forex_conversion_fee(gross_inr)
    gst_rate = load("fx")["forexConversionClause"]["gstPercent"] / 100.0
    gst = round(commission * gst_rate, 2)

    lines = [
        {"code": "COMM", "label": "Commission",
         "basis": f"INR {reading['amountInr']:,.0f} {reading['basisLabel']}"
                  + (f" x {units} documents" if units > 1 else ""),
         "amountInr": round(commission, 2)},
        {"code": "FXCONV", "label": "Forex conversion",
         "basis": fx_fee["basis"], "amountInr": fx_fee["amountInr"]},
        {"code": "GST", "label": "GST",
         "basis": f"{gst_rate * 100:.0f}% on commission only",
         "amountInr": gst},
    ]
    return {
        "status": "quoted" if reading["confidence"] >= 0.9 else "needs_confirmation",
        "client": entry["client"],
        "processingText": entry["processingText"],
        "reading": reading,
        "documents": documents,
        "grossInr": round(gross_inr, 2),
        "lines": lines,
        "totalInr": round(sum(l["amountInr"] for l in lines), 2),
        "message": None if reading["confidence"] >= 0.9 else reading["message"],
    }


def forex_conversion_fee(gross_inr: float) -> dict:
    """The forex conversion clause, charged marginally.

    "0.18% up to INR 1 lakh, minimum INR 45; INR 180 + 0.09% above INR 1 lakh
    and up to INR 10 lakh; INR 990 + 0.018% above INR 10 lakh, capped at INR
    10,800, as specified in Forex Conversion.xlsx."

    The percentage applies to the amount *above* the tier's lower bound. The
    fixed figures are what make that unambiguous: 1% of one lakh is exactly
    1,000, and 1,000 + 0.5% of nine lakh is exactly 5,500, so each tier's fixed
    part is the cumulative charge at the bound below it. Charging the
    percentage on the whole gross would bill the lower band twice.
    """
    clause = load("fx")["forexConversionClause"]
    gross = max(float(gross_inr or 0.0), 0.0)
    if gross <= 0:
        return {"amountInr": 0.0, "basis": "no amount exchanged"}

    for tier in clause["tiers"]:
        cap = tier.get("upToInr")
        if cap is None or gross <= cap:
            floor = float(tier.get("fromInr", 0) or 0)
            excess = max(gross - floor, 0.0)
            fee = tier["fixedInr"] + excess * tier["percent"] / 100.0
            if tier.get("minimumInr"):
                fee = max(fee, tier["minimumInr"])
            if tier.get("maximumInr"):
                fee = min(fee, tier["maximumInr"])

            pct, fixed = tier["percent"], tier["fixedInr"]
            if not fixed:
                basis = f"{pct}% of INR {gross:,.2f}"
            else:
                basis = (f"INR {fixed:,.0f} + {pct}% of INR {excess:,.2f}, "
                         f"the amount above INR {floor:,.0f}")
            if tier.get("minimumInr") and fee <= tier["minimumInr"]:
                basis += f" (the INR {tier['minimumInr']:,.0f} minimum applies)"
            if tier.get("maximumInr") and fee >= tier["maximumInr"]:
                basis += f" (capped at INR {tier['maximumInr']:,.0f})"
            return {"amountInr": round(fee, 2), "basis": basis}
    return {"amountInr": 0.0, "basis": "outside the quoted clause"}


def clients() -> list[dict]:
    """Every client with pricing on file, and what the parser makes of it."""
    out = []
    for entry in load("autobahn").get("clients", []):
        out.append({**entry, "reading": parse(entry["processingText"])})
    return out
