"""Domain schemas for the Trade Collections maker workbench.

Every field here comes from a file the bank supplied. Nothing is invented: no
service levels, no priorities, no pre-assigned owners. The only state the
application adds is the state a person creates by using it — what has been
checked, what a maker decided, and what was posted to TF3.
"""

from __future__ import annotations

import re
from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field

from .text import n


class CaseStatus(str, Enum):
    RECEIVED = "received"           # pulled from IDPMS, nothing run yet
    AI_PROCESSING = "ai_processing"  # checks and charges running
    NEEDS_ATTENTION = "needs_attention"
    READY_FOR_REVIEW = "ready_for_review"
    IN_CHECKER_QUEUE = "checker_queue"
    COMPLETED = "completed"
    RETURNED = "returned"


STATUS_LABELS: dict[str, str] = {
    "received": "Not yet run",
    "ai_processing": "Running",
    "needs_attention": "Needs attention",
    "ready_for_review": "Ready for review",
    "checker_queue": "With checker",
    "completed": "Posted to TF3",
    "returned": "Returned to maker",
}

STATUS_TONES: dict[str, str] = {
    "received": "quiet",
    "ai_processing": "info",
    "needs_attention": "warn",
    "ready_for_review": "ok",
    "checker_queue": "info",
    "completed": "ok",
    "returned": "bad",
}

CheckStatus = Literal["pass", "fail", "warn", "pending", "resolved", "blocked"]


# ---------------------------------------------------------------------------
# the pieces of a consignment
# ---------------------------------------------------------------------------

class InvoiceLine(BaseModel):
    """One invoice under a Bill of Entry, as IDPMS supplies it."""

    record_id: str
    invoice_no: str | None = None
    invoice_date: str | None = None
    amount: float | None = None
    currency: str | None = None
    terms: str | None = None
    supplier_name: str | None = None
    supplier_address: str | None = None
    supplier_country: str | None = None
    freight_amount: float | None = None
    freight_currency: str | None = None
    insurance_amount: float | None = None
    insurance_currency: str | None = None
    misc_amount: float | None = None
    misc_currency: str | None = None
    shipment_date: str | None = None
    transport_document: str | None = None


class PortRef(BaseModel):
    """A port code and whatever the directory made of it."""

    role: Literal["loading", "discharge"]
    code: str | None = None
    searched_as: str | None = None
    prefix_applied: bool = False
    name: str | None = None
    city: str | None = None
    country: str | None = None
    status: str = "directory_unavailable"
    message: str | None = None
    entered_by_maker: bool = False

    @property
    def where(self) -> str:
        """The port as it should read: the facility, its town, its country.

        The directory's name is sometimes the town itself (Shanghai) and
        sometimes a facility inside one (Air Cargo Complex Sahar, Mumbai), so
        the town is only added when the name does not already contain it.
        Repeating it would give "Gurgaon ICD, Gurgaon, India".
        """
        if not self.name:
            return ""
        parts = [self.name]
        if self.city and self.city.lower() not in self.name.lower():
            parts.append(self.city)
        if self.country:
            parts.append(self.country)
        return ", ".join(parts)

    @property
    def resolved(self) -> bool:
        return bool(self.name)

    @property
    def display(self) -> str:
        return self.where or self.code or "—"


class ThirdParty(BaseModel):
    name: str
    address: str | None = None
    country: str | None = None
    role: str = "third party"


class ComparedField(BaseModel):
    field: str
    tradePay: str
    idpms: str
    idpms_details: list[str] = []

    @property
    def matches(self) -> bool:
        return self.tradePay.strip().upper() == self.idpms.strip().upper()


class RunStep(BaseModel):
    """One step of a run, as the case page shows it happening.

    The pipeline writes these as it goes, so what the panel shows is the work
    that was actually done rather than a canned animation. ``detail`` is the
    one line a maker needs: what was compared, against what, and the answer.
    """

    id: str
    label: str
    status: Literal["running", "done"] = "running"
    detail: str = ""
    tone: Literal["", "ok", "warn", "bad", "info"] = ""
    # For a step that is one of the consistency checks: its verdict in the same
    # words the rest of the screen uses. Empty on every other kind of step.
    result: str = ""
    at: datetime | None = None


class Check(BaseModel):
    id: str
    label: str
    status: CheckStatus
    detail: str
    source: str = ""
    compared: list[ComparedField] = Field(default_factory=list)
    resolution: str | None = None
    resolved_by: str | None = None
    resolved_at: datetime | None = None

    @property
    def blocking(self) -> bool:
        return self.status in ("fail", "warn", "blocked")


# What a charge is levied on. A client's pricing is written against one of
# these and the bank bills at that level, so the figure has to be shown at
# that level too: an invoice fee repeated down a table of invoices, a
# bill-of-entry fee once per consignment, a remittance fee once for the whole
# TF3. Adding them up and showing one number hides which of the three a
# maker would have to argue about.
CHARGE_LEVELS = {
    "per_document":    ("invoice", "per invoice"),
    "per_invoice":     ("invoice", "per invoice"),
    "per_boe":         ("transaction", "per bill of entry"),
    "per_transaction": ("transaction", "per transaction"),
    "per_remittance":  ("tf3", "per remittance"),
    "flat":            ("tf3", "flat"),
}
LEVEL_NAMES = {"invoice": "invoice", "transaction": "transaction", "tf3": "TF3"}


class ChargeLine(BaseModel):
    code: str
    label: str
    basis: str
    amount_inr: float
    # "invoice" | "transaction" | "tf3". The forex fee and its GST are worked
    # out on the whole sum exchanged, so they sit at TF3 whatever the
    # commission is charged on.
    level: str = "tf3"
    level_basis: str = ""

    @property
    def level_name(self) -> str:
        return LEVEL_NAMES.get(self.level, self.level)


class Charges(BaseModel):
    status: Literal["quoted", "needs_confirmation", "awaiting_pricing",
                    "no_instruction", "unreadable", "pending"] = "pending"
    client: str | None = None
    processing_text: str | None = None
    reading: dict[str, Any] = Field(default_factory=dict)
    # How the pricing agent got here: the prompt, the provider, its reasoning
    # steps with the words each relied on, and the arithmetic re-done. Opened
    # from the charges card.
    agent_trace: dict[str, Any] = Field(default_factory=dict)
    documents: int = 1
    gross_inr: float = 0.0
    lines: list[ChargeLine] = Field(default_factory=list)
    message: str | None = None

    @property
    def total(self) -> float:
        return round(sum(line.amount_inr for line in self.lines), 2)

    @property
    def priced(self) -> bool:
        return self.status in ("quoted", "needs_confirmation") and bool(self.lines)

    @property
    def awaiting_source(self) -> bool:
        """Held because a source was never supplied, not because of the case."""
        return self.status == "awaiting_pricing"


class Query(BaseModel):
    query_id: str
    check_id: str | None = None
    recipient: str
    reason: str
    raised_by: str
    raised_at: datetime
    status: Literal["open", "answered", "closed"] = "open"
    response: str | None = None


class AuditEntry(BaseModel):
    at: datetime
    actor: str
    role: Literal["System", "Pipeline", "Maker", "Checker"]
    action: str
    detail: str


# ---------------------------------------------------------------------------
# the case
# ---------------------------------------------------------------------------

class CollectionCase(BaseModel):
    case_id: str
    bill_of_entry: str
    bill_of_entry_date: str | None = None
    # The TF3 reference TradePay files this consignment under, and the TII
    # behind it. One TF3 reference carries several Bills of Entry and each of
    # those several invoices; payment is processed against the TF3, so that
    # is the unit the worklist is indexed on. Distinct from tf3_reference
    # below, which is what comes back once the bank posts.
    tf3: str | None = None
    tii: str | None = None
    importer: str
    importer_code: str | None = None
    importer_pan: str | None = None
    importer_address: str | None = None
    ad_code: str | None = None

    ports: list[PortRef] = Field(default_factory=list)
    invoice_lines: list[InvoiceLine] = Field(default_factory=list)
    third_parties: list[ThirdParty] = Field(default_factory=list)
    latest_shipment_date: str | None = None
    duplicate_lines_removed: int = 0
    shares_boe_with_another_importer: bool = False

    tradepay: dict[str, Any] | None = None
    deal: dict[str, Any] | None = None

    status: CaseStatus = CaseStatus.RECEIVED
    checks: list[Check] = Field(default_factory=list)
    charges: Charges = Field(default_factory=Charges)
    queries: list[Query] = Field(default_factory=list)
    audit: list[AuditEntry] = Field(default_factory=list)

    tf3_reference: str | None = None
    returned_reason: str | None = None
    processing_started: datetime | None = None
    processing_seconds: float = 6.0
    run_steps: list[RunStep] = Field(default_factory=list)

    # -- money -------------------------------------------------------------
    @property
    def currency(self) -> str:
        for line in self.invoice_lines:
            if line.currency:
                return line.currency
        return ""

    @property
    def total_amount(self) -> float:
        return round(sum(l.amount or 0.0 for l in self.invoice_lines), 2)

    @property
    def amount_display(self) -> str:
        return f"{self.currency} {self.total_amount:,.2f}" if self.currency else "—"

    @property
    def gross_inr(self) -> float:
        return round(self.charges.gross_inr, 2)

    # -- presentation ------------------------------------------------------
    @property
    def status_label(self) -> str:
        return STATUS_LABELS[self.status.value]

    @property
    def status_tone(self) -> str:
        return STATUS_TONES[self.status.value]

    @property
    def supplier(self) -> str:
        for line in self.invoice_lines:
            if line.supplier_name:
                return line.supplier_name
        return "—"

    @property
    def supplier_country(self) -> str:
        for line in self.invoice_lines:
            if line.supplier_country:
                return line.supplier_country
        return ""

    def port(self, role: str) -> PortRef | None:
        return next((p for p in self.ports if p.role == role), None)

    @property
    def terms(self) -> str:
        """Payment terms, as IDPMS records them against the invoice."""
        for line in self.invoice_lines:
            if line.terms:
                return line.terms
        return "—"

    @property
    def source_label(self) -> str:
        """Which systems this case was built from."""
        return "IDPMS + TradePay" if self.tradepay else "IDPMS"

    @property
    def transport_documents(self) -> list[str]:
        seen: list[str] = []
        for line in self.invoice_lines:
            if line.transport_document and line.transport_document not in seen:
                seen.append(line.transport_document)
        return seen

    @property
    def invoice_display(self) -> str:
        n = len(self.invoice_lines)
        if n == 1 and self.invoice_lines[0].invoice_no:
            return self.invoice_lines[0].invoice_no
        return f"{n} invoices"

    @property
    def names_one_invoice(self) -> bool:
        """Whether ``invoice_display`` is a number or a count.

        The case header labels it, and a label in front of a count reads
        "Invoice 6 invoices".
        """
        return (len(self.invoice_lines) == 1
                and bool(self.invoice_lines[0].invoice_no))

    # -- what stands in the way --------------------------------------------
    @property
    def open_checks(self) -> list[Check]:
        return [c for c in self.checks if c.blocking]

    @property
    def unresolved_ports(self) -> list[PortRef]:
        return [p for p in self.ports if not p.resolved]

    @property
    def open_queries(self) -> list[Query]:
        return [q for q in self.queries if q.status == "open"]

    @property
    def checks_passed(self) -> int:
        return sum(1 for c in self.checks if c.status in ("pass", "resolved"))

    @property
    def checks_total(self) -> int:
        return len(self.checks)

    @property
    def action_items(self) -> list[dict[str, str]]:
        """What a maker has to deal with, in plain words."""
        items: list[dict[str, str]] = []
        for port in self.unresolved_ports:
            items.append({
                "kind": "port",
                "id": f"port_{port.role}",
                "title": f"Port of {port.role} has no full name yet.",
                "detail": port.message or "",
            })
        # Several checks often fail for one reason — when TradePay holds no
        # record, the drawer, country and currency checks are all blocked by
        # the same fact. Say it once, and name the checks it settles.
        grouped: dict[str, dict[str, str]] = {}
        for check in self.open_checks:
            if check.id.startswith("PORT_"):
                continue  # already covered by the port item
            parts = re.split(r"\.\s+(?=[A-Z])", check.detail.strip(), maxsplit=1)
            title = parts[0].rstrip(".") + "." if parts[0] else check.label
            entry = grouped.setdefault(title, {
                "kind": "check", "title": title,
                "detail": parts[1] if len(parts) > 1 else "",
                "ids": [], "labels": [],
            })
            entry["ids"].append(check.id)
            entry["labels"].append(check.label)

        for entry in grouped.values():
            labels = entry.pop("labels")
            if len(labels) > 1:
                named = ", ".join(labels[:-1]) + " and " + labels[-1]
                entry["detail"] = ((entry["detail"] + " ") if entry["detail"] else "") +                     f"Settling this clears {len(labels)} checks: {named.lower()}."
                entry["rule"] = named
            else:
                entry["rule"] = labels[0]
            entry["id"] = ",".join(entry["ids"])
            items.append(entry)
        if self.status not in (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING) \
                and not self.charges.priced:
            items.append({
                "kind": "source" if self.charges.awaiting_source else "charges",
                "id": "charges",
                "title": self.charges.message or "Charges could not be worked out.",
                "detail": ("Nothing on this case disagrees. The charge is the one "
                           "thing outstanding, and it waits on the client's "
                           "approved pricing rather than on anything in the "
                           "transaction."
                           if self.charges.awaiting_source else ""),
            })
        return items

    @property
    def waiting_on_source(self) -> bool:
        """Every check passed; the only hold is data that was never given to us."""
        return (not self.open_checks and not self.unresolved_ports
                and self.charges.awaiting_source)

    @property
    def needs_maker(self) -> bool:
        if self.waiting_on_source:
            return False
        return bool(self.action_items) and self.status not in (
            CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING,
            CaseStatus.IN_CHECKER_QUEUE, CaseStatus.COMPLETED)

    @property
    def blockers(self) -> list[str]:
        out: list[str] = []
        if self.unresolved_ports:
            out.append(f"{n(len(self.unresolved_ports), 'port')} without a full name")
        others = [c for c in self.open_checks if not c.id.startswith("PORT_")]
        if others:
            out.append(f"{n(len(others), 'check')} outstanding")
        if not self.charges.priced:
            out.append("the client's Autobahn pricing has not been supplied"
                       if self.charges.awaiting_source else "charges not settled")
        return out

    @property
    def ready_to_validate(self) -> bool:
        return (self.status in (CaseStatus.READY_FOR_REVIEW,
                                CaseStatus.NEEDS_ATTENTION,
                                CaseStatus.RETURNED)
                and not self.blockers)

    @property
    def headline(self) -> str:
        if self.status is CaseStatus.RECEIVED:
            return "Pulled from IDPMS, checks not run yet"
        if self.status is CaseStatus.AI_PROCESSING:
            return "Running the checks"
        if self.status is CaseStatus.IN_CHECKER_QUEUE:
            return "With the checker"
        if self.status is CaseStatus.COMPLETED:
            return f"Posted to TF3 as {self.tf3_reference}"
        if self.status is CaseStatus.RETURNED:
            return f"Sent back: {self.returned_reason or 'see the activity'}"
        if self.waiting_on_source:
            return ("Every check passed. Waiting on this client's Autobahn "
                    "pricing, which has not been supplied.")
        items = self.action_items
        if not items:
            return "Everything agreed — ready to post"
        first = items[0]["title"]
        if len(items) > 1:
            return f"{first.rstrip('.')}, and {len(items) - 1} more."
        return first

    @property
    def checked_summary(self) -> str:
        return (f"{n(len(self.invoice_lines), 'invoice line')} "
                f"· {self.checks_passed} of {self.checks_total} checks passed")


# ---------------------------------------------------------------------------
# request payloads
# ---------------------------------------------------------------------------

class PortEntry(BaseModel):
    name: str
    note: str | None = None


class CheckResolution(BaseModel):
    resolution: str


class QueryCreate(BaseModel):
    check_id: str | None = None
    reason: str
    recipient: str = "Branch operations"


class ValidationRequest(BaseModel):
    source_reviewed: bool = False
    exceptions_resolved: bool = False
    maker_note: str | None = None


class ActionResult(BaseModel):
    ok: bool
    message: str
    case_id: str
    status: str | None = None
    status_label: str | None = None
    status_tone: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)
