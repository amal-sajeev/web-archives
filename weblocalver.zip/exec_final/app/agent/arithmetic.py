"""Every figure on a charge, worked out a second time by a different route.

The pricing agent reads an instruction written in English and decides *what* to
charge: which rate applies, what it is charged per, and how many of them there
are. That is a reading problem and a model is good at it. Multiplying the rate
by the count is not a reading problem, and a model that is fluent about money is
not thereby accurate about it - it will produce a confident "INR 450 x 3 =
INR 1,250" and carry it through to a total without flinching.

So the split is: the agent reads, and every number is computed here. That alone
is not enough, because the code that computes can be wrong too - the forex fee
in this file was recomputed for months by calling the very function that
produced it, which is a check that cannot fail. Everything below is therefore
derived a second time, from the published clause and the transaction's own
figures, by code that shares nothing with the first route:

  * the rupee value exchanged, from the booked deal or the rate card;
  * each charge, from its rate and the units the case actually has;
  * the forex conversion fee, by walking the clause's bands one at a time
    rather than looking up a tier;
  * GST, on a base that must exclude GST;
  * the total, against the sum of the lines and against its three parts;
  * and the invariants that catch a figure which is arithmetically fine and
    still obviously wrong - negative money, unrounded paise, a charge larger
    than the remittance it is levied on.

Each returns a line a maker can read, and any failure pulls the quote back to
"needs confirmation" rather than being filed in a log nobody opens.
"""

from __future__ import annotations

import math
import re
from typing import Any

PAISE = 0.01


def _ok(label: str, detail: str, kind: str = "arithmetic") -> dict:
    return {"label": label, "ok": True, "detail": detail, "kind": kind}


def _bad(label: str, detail: str, kind: str = "arithmetic") -> dict:
    return {"label": label, "ok": False, "detail": detail, "kind": kind}


def _agree(label: str, expected: float, given: float, detail: str,
           kind: str = "arithmetic") -> dict:
    """One recomputation against the figure the quote carries."""
    if abs(expected - given) < PAISE:
        return _ok(label, detail, kind)
    return _bad(label, f"{detail} The quote carries INR {given:,.2f}, which is "
                       f"INR {abs(expected - given):,.2f} out.", kind)


# ---------------------------------------------------------------------------
# the rupee value exchanged
# ---------------------------------------------------------------------------

def gross_exchanged(*, amount: float, currency: str, deal: dict | None,
                    fx: dict) -> dict:
    """What was actually exchanged, in rupees, and how that was arrived at.

    A booked deal is the best evidence there is, but it is evidence of a *rate*
    first and of a total second. One deal often settles a whole shipment: Rothe
    Erde's covers CNY 4,027,521 across two Bills of Entry, so taking its INR
    total for either case on its own bills the forex clause on the whole
    shipment twice. The deal's rate applies to this transaction; its total only
    applies when the deal is for this transaction and nothing else.
    """
    amount = float(amount or 0.0)
    checks: list[dict] = []
    rate = _numeric(deal.get("rate")) if deal else None
    deal_amount = _numeric(deal.get("amount")) if deal else None
    deal_inr = _numeric(deal.get("inrAmount")) if deal else None
    same_currency = bool(deal) and deal.get("currency") == currency

    if deal and not same_currency:
        checks.append(_bad(
            "The booked deal is in this transaction's currency",
            f"The deal found for this client is in {deal.get('currency') or '—'}, "
            f"not {currency}. It is not used, and the rate card is instead.",
            "source"))

    if deal and same_currency and rate:
        covers_only_this = (deal_amount is not None
                            and abs(deal_amount - amount) < PAISE)
        gross = round(amount * rate, 2)
        if covers_only_this and deal_inr is not None:
            checks.append(_agree(
                "The booked deal's own total",
                deal_inr, gross,
                f"{amount:,.2f} {currency} at {rate:,.6g} is "
                f"INR {gross:,.2f}, and the deal is booked at "
                f"INR {deal_inr:,.2f}.", "source"))
            gross = deal_inr
            basis = (f"the booked deal {deal.get('reference') or ''}".strip()
                     + f", {amount:,.2f} {currency} at {rate:,.6g}")
        elif deal_amount is not None and deal_amount > amount + PAISE:
            # One deal, several transactions. Take the rate, not the total.
            share = amount / deal_amount if deal_amount else 0.0
            checks.append(_ok(
                "The booked deal covers more than this transaction",
                f"The deal is for {deal_amount:,.2f} {currency}; this "
                f"transaction is {amount:,.2f}, or {share * 100:,.1f}% of it. "
                f"The deal's rate of {rate:,.6g} is applied to this "
                f"transaction's own amount, not its INR total of "
                f"INR {deal_inr:,.2f}."
                if deal_inr else
                f"The deal is for {deal_amount:,.2f} {currency}; this "
                f"transaction is {amount:,.2f}. The deal's rate of "
                f"{rate:,.6g} is applied to this transaction's own amount.",
                "source"))
            basis = (f"the booked deal rate of {rate:,.6g} per {currency}, "
                     f"applied to this transaction's share of the deal")
        else:
            basis = f"the booked deal rate of {rate:,.6g} per {currency}"
        checks.append(_agree(
            "The rupee value exchanged",
            round(amount * rate, 2) if not (covers_only_this and deal_inr)
            else deal_inr,
            gross,
            f"{amount:,.2f} {currency} × {rate:,.6g} = "
            f"INR {round(amount * rate, 2):,.2f}."))
        return {"amountInr": gross, "basis": basis, "rate": rate,
                "source": "deal", "checks": checks}

    if deal and same_currency and not rate:
        # An EEFC settlement carries no rate because nothing was converted:
        # the client paid out of a foreign-currency account. Saying so is the
        # point - it is the one case where the forex clause should not bite,
        # and silently falling through to a card rate hides that.
        checks.append(_bad(
            "The booked deal carries a rate",
            f"The deal found for this transaction is "
            f"{_an(deal.get('dealType') or 'settlement')} and carries no rate "
            f"({deal.get('rate') or '—'}). Nothing may have been "
            "converted at all. The rate card is used so that a figure exists, "
            "and a maker should confirm whether the forex clause applies.",
            "source"))

    card = (fx.get("cardRates") or {}).get(currency)
    peer = (fx.get("ratesFromDeals") or {}).get(currency)
    rate = card or peer
    if not rate:
        checks.append(_bad(
            "A rate is held for this currency",
            f"No card rate and no booked deal is held for {currency}, so the "
            "rupee value cannot be worked out and the forex clause cannot be "
            "applied.", "source"))
        return {"amountInr": 0.0, "basis": f"no rate held for {currency}",
                "rate": None, "source": "none", "checks": checks}

    gross = round(amount * rate, 2)
    where = ("the card rate" if card else
             "a rate taken from a deal booked on another consignment")
    why = ("The deal booked against it carries no rate."
           if deal and same_currency else
           "No deal is booked against this transaction.")
    checks.append(_ok(
        "The rupee value exchanged",
        f"{amount:,.2f} {currency} × {rate:,.6g} = INR {gross:,.2f}, at "
        f"{where}. {why}"))
    return {"amountInr": gross, "basis": f"{where} of {rate:,.6g} per {currency}",
            "rate": rate, "source": "card" if card else "peer", "checks": checks}


def _an(word: str) -> str:
    return f"{'an' if word[:1].upper() in 'AEIOU' else 'a'} {word}"


def _numeric(v: Any) -> float | None:
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v) if math.isfinite(float(v)) else None
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# the forex conversion fee, walked band by band
# ---------------------------------------------------------------------------

def forex_fee_from_bands(gross: float, clause: dict) -> dict:
    """The clause applied by walking its bands, rather than selecting a tier.

    ``autobahn.forex_conversion_fee`` finds the tier the gross falls in and
    uses that tier's fixed figure as the cumulative charge below it. This takes
    the other road: it charges each band's percentage on the slice of the gross
    that falls inside that band and adds them up. The two agree only if the
    table's fixed figures really are the cumulative totals, so disagreement
    here catches a mis-stated clause as well as a mis-applied one.
    """
    gross = max(float(gross or 0.0), 0.0)
    if gross <= 0:
        return {"amountInr": 0.0, "slices": [], "floor": None, "cap": None}

    tiers = clause["tiers"]
    fee, slices = 0.0, []
    for tier in tiers:
        low = float(tier.get("fromInr") or 0.0)
        high = tier.get("upToInr")
        if gross <= low:
            break
        top = gross if high is None else min(gross, float(high))
        slice_amount = max(top - low, 0.0)
        if slice_amount <= 0:
            continue
        part = slice_amount * float(tier["percent"]) / 100.0
        fee += part
        slices.append(f"{tier['percent']}% of {slice_amount:,.2f}"
                      + (f" above {low:,.0f}" if low else ""))

    # The minimum and maximum belong to the band the gross lands in.
    landed = next((t for t in tiers
                   if t.get("upToInr") is None or gross <= float(t["upToInr"])),
                  tiers[-1])
    floor_, cap = landed.get("minimumInr"), landed.get("maximumInr")
    if floor_:
        fee = max(fee, float(floor_))
    if cap:
        fee = min(fee, float(cap))
    return {"amountInr": round(fee, 2), "slices": slices,
            "floor": floor_, "cap": cap}


def _band_continuity(clause: dict) -> list[dict]:
    """Each band's fixed figure must be the charge accumulated below it.

    This is a check on the clause as published, not on one transaction, and it
    is what makes the band walk above a fair second opinion rather than a
    different answer.
    """
    out: list[dict] = []
    tiers = clause["tiers"]
    running = 0.0
    for i, tier in enumerate(tiers):
        fixed = float(tier.get("fixedInr") or 0.0)
        if abs(fixed - running) >= PAISE:
            out.append(_bad(
                f"The clause's band {i + 1} starts where band {i} ends",
                f"Band {i + 1} opens at a fixed INR {fixed:,.2f}, but the bands "
                f"below it accumulate to INR {running:,.2f}. The published "
                "clause does not join up, so the two readings of it differ.",
                "clause"))
        low = float(tier.get("fromInr") or 0.0)
        high = tier.get("upToInr")
        if high is None:
            break
        running += (float(high) - low) * float(tier["percent"]) / 100.0
    if not out:
        out.append(_ok(
            "The forex clause's bands join up",
            f"Each band's fixed figure is what the bands below it come to: "
            + ", ".join(f"INR {float(t.get('fixedInr') or 0):,.0f} at "
                        f"{float(t.get('fromInr') or 0):,.0f}" for t in tiers)
            + ".", "clause"))
    return out


# ---------------------------------------------------------------------------
# the whole quote
# ---------------------------------------------------------------------------

def recheck(*, charges: list[dict], lines: list[dict], commission: float,
            fx_fee: dict, gst: float, gst_rate: float, total: float,
            clause: dict, gross_inr: float, documents: int,
            processing_text: str, gross_checks: list[dict] | None = None,
            currency: str | None = None,
            foreign_amount: float | None = None) -> list[dict]:
    """Every figure on the quote, re-derived and compared."""
    out: list[dict] = list(gross_checks or [])

    # --- what the agent read, against the words it read it from -----------
    text = re.sub(r"\s+", " ", processing_text or "").upper()
    figures = {f.replace(",", "") for f in
               re.findall(r"\d[\d,]*(?:\.\d+)?", processing_text or "")}

    for c in charges:
        rate, units = float(c["rate_inr"]), float(c["units"])
        out.append(_agree(
            f"{c['label']}: {rate:,.2f} × {units:g}",
            round(rate * units, 2), float(c["amount_inr"]),
            f"INR {round(rate * units, 2):,.2f}."))

        # A unit count the agent invented is an arithmetic error that the
        # multiplication above cannot see, because both sides use it.
        out.append(_units_check(c, documents))

        if c.get("quote"):
            needle = re.sub(r"\s+", " ", c["quote"]).strip().upper()
            found = needle in text
            if not found and len(needle) > 25:
                words = [w for w in re.findall(r"[A-Z0-9.]+", needle) if len(w) > 2]
                found = bool(words) and sum(w in text for w in words) / len(words) > 0.8
            out.append({"label": "The quote appears in the instruction",
                        "ok": found, "kind": "reading",
                        "detail": (f"“{c['quote']}”" if found else
                                   f"“{c['quote']}” is not in the "
                                   "instruction text.")})

        shown = f"{rate:g}"
        in_text = shown in figures or f"{rate:.0f}" in figures
        out.append({"label": f"The rate {shown} is quoted in the instruction",
                    "ok": in_text, "kind": "reading",
                    "detail": "found" if in_text else
                              f"The instruction does not contain the figure {shown}."})

    # --- the forex conversion fee -----------------------------------------
    out.extend(_band_continuity(clause))
    walked = forex_fee_from_bands(gross_inr, clause)
    given = float(fx_fee.get("amountInr") or 0.0)
    note = " + ".join(walked["slices"]) or "nothing exchanged"
    if walked["cap"] and given >= float(walked["cap"]) - PAISE:
        note += f", capped at INR {float(walked['cap']):,.0f}"
    elif walked["floor"] and given <= float(walked["floor"]) + PAISE:
        note += f", lifted to the INR {float(walked['floor']):,.0f} minimum"
    out.append(_agree(
        "Forex conversion fee, charged band by band",
        walked["amountInr"], given,
        f"On INR {gross_inr:,.2f}: {note} = INR {walked['amountInr']:,.2f}."))

    # --- GST ---------------------------------------------------------------
    base = round(commission, 2)
    out.append(_agree(
        f"GST at {gst_rate * 100:.0f}% of {base:,.2f}",
        round(base * gst_rate, 2), float(gst),
        f"INR {round(base * gst_rate, 2):,.2f} on commission of INR {commission:,.2f} only."))

    gst_lines = [l for l in lines if l["code"] == "GST"]
    base_from_lines = round(sum(l["amountInr"] for l in lines
                                if l["code"] != "GST"), 2)
    out.append(_agree(
        "GST is charged on commission only",
        round(commission, 2), base,
        f"Commission comes to INR {commission:,.2f}; forex conversion is excluded "
        f"from the GST base."
        + (f" GST appears on {len(gst_lines)} lines." if len(gst_lines) > 1 else "")))

    # --- the total ---------------------------------------------------------
    summed = round(sum(float(l["amountInr"]) for l in lines), 2)
    added = " + ".join(f"{float(l['amountInr']):,.2f}" for l in lines)
    out.append(_agree("The total is the sum of the lines", summed, float(total),
                      f"{added} = INR {summed:,.2f}." if lines
                      else "There are no lines to add."))
    out.append(_agree(
        "The total is its three parts",
        round(commission + given + float(gst), 2), float(total),
        f"Commission INR {commission:,.2f} + forex INR {given:,.2f} + GST "
        f"INR {float(gst):,.2f} = INR {round(commission + given + float(gst), 2):,.2f}."))

    # --- the invariants ----------------------------------------------------
    out.extend(_invariants(lines, total, gross_inr, currency, foreign_amount))
    return out


def _units_check(charge: dict, documents: int) -> dict:
    """Is the count the agent charged on a count this transaction has?

    The instruction says "per document" or "per transaction" or "at remittance
    level", and the agent picks one. Whichever it picks, the number of them is
    a fact about the case - the invoice lines, or the single remittance - and
    not something to be arrived at. Anything else has been invented.
    """
    units = float(charge["units"])
    allowed = {1.0: "one remittance", float(documents): f"{documents} invoice "
               f"line{'' if documents == 1 else 's'}"}
    if units in allowed:
        return _ok(f"The count of {units:g} is one this transaction has",
                   f"Charged per {charge.get('basis_text') or 'unit'}, "
                   f"{units:g} = {allowed[units]}."
                   + (f" {charge['units_reason']}" if charge.get("units_reason")
                      else ""), "units")
    counts = sorted(allowed)
    return _bad(
        f"The count of {units:g} is one this transaction has",
        f"This transaction is one remittance covering {documents} invoice "
        f"line{'' if documents == 1 else 's'}, so "
        + (f"the only count it can be charged on is {counts[0]:g}"
           if len(counts) == 1 else
           f"the only counts it can be charged on are "
           + " or ".join(f"{c:g}" for c in counts))
        + f". The agent charged on {units:g}.", "units")


def _invariants(lines: list[dict], total: float, gross_inr: float,
                currency: str | None, foreign_amount: float | None) -> list[dict]:
    """Figures that are arithmetically consistent and still obviously wrong."""
    out: list[dict] = []

    odd = [l for l in lines
           if not math.isfinite(float(l["amountInr"])) or float(l["amountInr"]) < 0
           or abs(round(float(l["amountInr"]), 2) - float(l["amountInr"])) > 1e-9]
    out.append({
        "label": "Every line is a real amount of money", "ok": not odd,
        "kind": "sanity",
        "detail": "Each is positive, finite and in whole paise."
                  if not odd else
                  "These are not: "
                  + ", ".join(f"{l['label']} ({l['amountInr']})" for l in odd) + "."})

    # A charge is a fee on a remittance. One that approaches the remittance
    # itself has almost always been read off the wrong line of the instruction.
    if gross_inr > 0:
        share = total / gross_inr
        out.append({
            "label": "The charge is a plausible fraction of the remittance",
            "ok": share <= 0.10, "kind": "sanity",
            "detail": (f"INR {total:,.2f} on INR {gross_inr:,.2f} exchanged is "
                       f"{share * 100:,.2f}%.") if share <= 0.10 else
                      (f"INR {total:,.2f} on INR {gross_inr:,.2f} exchanged is "
                       f"{share * 100:,.1f}% of the remittance. A collection "
                       "charge above 10% is almost always a figure read off "
                       "the wrong line.")})
    return out


def summarise(checks: list[dict]) -> dict:
    """One line for the run panel: how many agreed, and what did not."""
    failed = [c for c in checks if not c["ok"]]
    return {
        "total": len(checks),
        "passed": len(checks) - len(failed),
        "failed": failed,
        "ok": not failed,
    }
