"""Small local API that converts PDFs to the lrrDetails JSON contract."""

from __future__ import annotations

import io
import json
import math
import os
import re
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import Counter, deque
from email import policy
from email.parser import BytesParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

import pdfplumber
from pypdf import PdfReader, PdfWriter


HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "8000"))
MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash-lite")
MAX_PAGES = 2000
MAX_PDF_BYTES = 50 * 1024 * 1024
MAX_BODY_BYTES = MAX_PDF_BYTES + 256 * 1024
BASE_PROCESSING_DEADLINE_SECONDS = 285
MAX_PROCESSING_DEADLINE_SECONDS = 21 * 60
PAGES_PER_DEADLINE_UNIT = 300
RPM_LIMIT = 15
SEGMENT_PAGES = 20
DETAILED_SEGMENT_PAGES = 5
MAX_PARALLEL_SEGMENTS = 5
GOOGLE_API_ROOT = "https://generativelanguage.googleapis.com"


class ApiError(Exception):
    def __init__(self, status: int, message: str, headers: dict[str, str] | None = None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.headers = headers or {}


class SlidingWindowLimiter:
    """Enforce the configured free-tier generation request limit per process."""

    def __init__(self, limit: int, window_seconds: int = 60):
        self.limit = limit
        self.window_seconds = window_seconds
        self._calls: deque[float] = deque()
        self._lock = threading.Lock()

    def reserve(self, count: int = 1) -> int | None:
        if count < 1 or count > self.limit:
            return 60
        now = time.monotonic()
        with self._lock:
            while self._calls and now - self._calls[0] >= self.window_seconds:
                self._calls.popleft()
            excess = len(self._calls) + count - self.limit
            if excess > 0:
                release_time = self._calls[excess - 1] + self.window_seconds
                return max(1, int(release_time - now + 0.999))
            self._calls.extend([now] * count)
        return None


limiter = SlidingWindowLimiter(RPM_LIMIT)


OUTPUT_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "data": {
            "type": "OBJECT",
            "properties": {
                "lrrDetails": {
                    "type": "ARRAY",
                    "items": {
                        "type": "OBJECT",
                        "properties": {
                            "section": {"type": "STRING"},
                            "lrrText": {"type": "STRING"},
                            "lrrPublishStatus": {"type": "STRING", "enum": ["Published"]},
                            "sectionCounter": {"type": "INTEGER"},
                            "lrrVersion": {"type": "INTEGER"},
                            "type": {"type": "STRING", "enum": ["manual"]},
                            "footnote": {"type": "ARRAY", "items": {"type": "STRING"}},
                        },
                        "required": [
                            "section",
                            "lrrText",
                            "lrrPublishStatus",
                            "sectionCounter",
                            "lrrVersion",
                            "type",
                            "footnote",
                        ],
                    },
                }
            },
            "required": ["lrrDetails"],
        }
    },
    "required": ["data"],
}


HEADING_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "headings": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "lineId": {"type": "STRING"},
                    "headingText": {"type": "STRING"},
                    "level": {"type": "INTEGER"},
                    "confidence": {"type": "NUMBER"},
                },
                "required": ["lineId", "headingText", "level", "confidence"],
            },
        }
    },
    "required": ["headings"],
}


HEADING_PROMPT = """Identify structural document headings in the supplied numbered text lines.

Return only actual document headings and subheadings, with their exact lineId and exact headingText from the input. Include numbered headings, chapters, articles, annexes, appendices, and unnumbered headings. A short standalone title line followed by explanatory prose can be a heading even when it uses the same font and has no numbering. The `kind` label is only a prior heuristic hint: a `body_candidate` line may still be a heading, so evaluate every line. Distinguish headings from numbered paragraphs, list items, table rows, page furniture, sentence fragments and ordinary prose. Do not treat table-of-contents entries as headings. Do not invent or rewrite any text. Use level 1 for top-level headings and higher integers for nested headings. The application will assemble all section bodies from the original source lines; your task is only to label heading lines. Include a confidence from 0 to 1 and omit uncertain candidates below 0.8."""


PROMPT = """Convert the attached PDF pages into the supplied JSON schema.

Extract the visible and embedded document content faithfully; do not summarize, paraphrase, omit clauses, or invent content. Treat this as a verbatim transcription and structure task. Use OCR for scanned or image-only pages. Preserve the original reading order, section and subsection headings, every paragraph, list item, and meaningful table cell. Put a heading in `section` and its complete body in `lrrText`; if there are no explicit headings, create concise headings that follow the document's organization. Keep clauses and lists readable in `lrrText`. Put actual footnote text in `footnote`, without page headers, recurring footers, or bare page numbers. Include annexes and appendices. Return every section present on these pages in document order. Use the schema's required metadata values and number `sectionCounter` from 1 in order. If this segment begins with body text whose heading is on an earlier page, use the section title `Continuation` for that initial body and do not summarize it. If the pages have no substantive content, return an empty `lrrDetails` array."""


def _deadline_timeout(deadline: float, cap: float = 180.0) -> float:
    remaining = deadline - time.monotonic()
    if remaining <= 1:
        raise ApiError(504, "PDF conversion exceeded its processing deadline.")
    return min(remaining, cap)


def _processing_deadline_seconds(page_count: int) -> int:
    if page_count <= PAGES_PER_DEADLINE_UNIT:
        return BASE_PROCESSING_DEADLINE_SECONDS
    units = math.ceil(page_count / PAGES_PER_DEADLINE_UNIT)
    return min(MAX_PROCESSING_DEADLINE_SECONDS, units * 180)


def _google_request(request: Request, deadline: float, cap: float = 180.0) -> bytes:
    try:
        with urlopen(request, timeout=_deadline_timeout(deadline, cap)) as response:
            return response.read()
    except HTTPError as exc:
        try:
            detail = json.loads(exc.read().decode("utf-8", errors="replace"))
            message = detail.get("error", {}).get("message", "")
        except Exception:
            message = ""
        for header_name, header_value in request.headers.items():
            if header_name.lower() in {"x-goog-api-key", "authorization"} and header_value:
                message = message.replace(header_value, "[redacted]")
        if exc.code == 429:
            raise ApiError(429, "Gemini rate limit reached. Retry after a short wait.", {"Retry-After": "60"}) from exc
        if exc.code in (401, 403):
            raise ApiError(502, "Gemini rejected the API key or model access.") from exc
        if exc.code in (400, 413):
            safe_message = "Gemini could not process this PDF within its request limits."
            if message:
                safe_message = safe_message + " Gemini reported: " + message[:300]
            raise ApiError(422, safe_message) from exc
        raise ApiError(502, f"Gemini returned an upstream error ({exc.code}).") from exc
    except (TimeoutError, URLError, OSError) as exc:
        if time.monotonic() >= deadline - 1:
            raise ApiError(504, "PDF conversion exceeded its processing deadline.") from exc
        raise ApiError(502, "Could not reach the Gemini API.") from exc


def _upload_pdf(pdf_bytes: bytes, filename: str, api_key: str, deadline: float) -> dict:
    start_url = f"{GOOGLE_API_ROOT}/upload/v1beta/files"
    start_body = json.dumps({"file": {"display_name": filename}}).encode("utf-8")
    start_request = Request(
        start_url,
        data=start_body,
        method="POST",
        headers={
            "x-goog-api-key": api_key,
            "Content-Type": "application/json",
            "X-Goog-Upload-Protocol": "resumable",
            "X-Goog-Upload-Command": "start",
            "X-Goog-Upload-Header-Content-Length": str(len(pdf_bytes)),
            "X-Goog-Upload-Header-Content-Type": "application/pdf",
        },
    )
    try:
        with urlopen(start_request, timeout=_deadline_timeout(deadline, 45)) as response:
            upload_url = response.headers.get("x-goog-upload-url")
    except HTTPError as exc:
        # Reuse the standard error mapping while preserving the upload error body.
        try:
            detail = json.loads(exc.read().decode("utf-8", errors="replace"))
            message = detail.get("error", {}).get("message", "")
        except Exception:
            message = ""
        if exc.code in (401, 403):
            raise ApiError(502, "Gemini rejected the API key or model access.") from exc
        if exc.code == 429:
            raise ApiError(429, "Gemini rate limit reached. Retry after a short wait.", {"Retry-After": "60"}) from exc
        raise ApiError(502, "Gemini could not start the PDF upload." + (f" {message[:250]}" if message else "")) from exc
    except (TimeoutError, URLError, OSError) as exc:
        raise ApiError(502, "Could not upload the PDF to Gemini.") from exc

    if not upload_url:
        raise ApiError(502, "Gemini did not return a resumable upload URL.")

    upload_request = Request(
        upload_url,
        data=pdf_bytes,
        method="POST",
        headers={
            "x-goog-api-key": api_key,
            "Content-Type": "application/pdf",
            "Content-Length": str(len(pdf_bytes)),
            "X-Goog-Upload-Offset": "0",
            "X-Goog-Upload-Command": "upload, finalize",
        },
    )
    response_bytes = _google_request(upload_request, deadline, cap=90)
    try:
        result = json.loads(response_bytes.decode("utf-8"))
        file_info = result.get("file", result)
        if not file_info.get("uri") or not file_info.get("name"):
            raise ValueError("Missing Gemini file URI or name")
        return file_info
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        raise ApiError(502, "Gemini returned an invalid file upload response.") from exc


def _delete_uploaded_file(file_info: dict, api_key: str) -> None:
    name = file_info.get("name", "")
    if not name.startswith("files/"):
        return
    request = Request(
        f"{GOOGLE_API_ROOT}/v1beta/{quote(name, safe='/')}",
        method="DELETE",
        headers={"x-goog-api-key": api_key},
    )
    try:
        with urlopen(request, timeout=4):
            pass
    except Exception:
        # Conversion should not fail just because best-effort remote cleanup failed.
        pass


def _generate_content(file_uri: str, api_key: str, deadline: float, page_start: int, page_end: int, total_pages: int) -> dict:
    model = MODEL.strip()
    if not re.fullmatch(r"[A-Za-z0-9._-]+", model):
        raise ApiError(500, "GEMINI_MODEL contains unsupported characters.")
    body = {
        "contents": [
            {
                "parts": [
                    {
                        "text": (
                            f"{PROMPT}\n\n"
                            f"This segment contains original PDF pages {page_start}-{page_end} of {total_pages}. "
                            "Extract all text on these pages; do not condense it."
                        )
                    },
                    {"fileData": {"mimeType": "application/pdf", "fileUri": file_uri}},
                ]
            }
        ],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": OUTPUT_SCHEMA,
            "temperature": 0,
            "maxOutputTokens": 65536,
        },
    }
    request = Request(
        f"{GOOGLE_API_ROOT}/v1beta/models/{model}:generateContent",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
    )
    raw = _google_request(request, deadline, cap=BASE_PROCESSING_DEADLINE_SECONDS)
    try:
        response = json.loads(raw.decode("utf-8"))
        candidates = response.get("candidates") or []
        if not candidates:
            raise ApiError(502, "Gemini returned no structured output for this PDF.")
        candidate = candidates[0]
        finish_reason = candidate.get("finishReason", "")
        if finish_reason in ("MAX_TOKENS", "RECITATION"):
            raise ApiError(422, "Gemini could not return the complete JSON for this PDF. Try a smaller PDF or a higher-output model.")
        parts = candidate.get("content", {}).get("parts", [])
        output_text = "".join(part.get("text", "") for part in parts if isinstance(part, dict))
        document = json.loads(output_text)
        details = document.get("data", {}).get("lrrDetails")
        if not isinstance(details, list):
            raise ValueError("Expected data.lrrDetails to be an array")
        normalized = []
        for index, item in enumerate(details, start=1):
            if not isinstance(item, dict):
                continue
            section = item.get("section")
            text = item.get("lrrText")
            footnotes = item.get("footnote", [])
            if not isinstance(section, str) or not isinstance(text, str):
                raise ValueError("Each section must include string section and lrrText fields")
            if not isinstance(footnotes, list):
                footnotes = [str(footnotes)] if footnotes else []
            normalized.append(
                {
                    "section": section.strip() or f"Section {index}",
                    "lrrText": text.strip(),
                    "lrrPublishStatus": "Published",
                    "sectionCounter": index,
                    "lrrVersion": 1,
                    "type": "manual",
                    "footnote": [note.strip() for note in footnotes if isinstance(note, str) and note.strip()],
                }
            )
        return {"data": {"lrrDetails": normalized}}, response.get("usageMetadata", {})
    except ApiError:
        raise
    except (UnicodeDecodeError, json.JSONDecodeError, AttributeError, TypeError, ValueError) as exc:
        raise ApiError(502, "Gemini's response did not match the required JSON structure.") from exc


def _outline_page_starts(reader: PdfReader, page_count: int) -> list[int]:
    """Return page indexes where PDF bookmarks mark a structural boundary."""
    page_starts: set[int] = set()

    def visit(items: list) -> None:
        for item in items:
            if isinstance(item, list):
                visit(item)
                continue
            try:
                page_index = reader.get_destination_page_number(item)
            except Exception:
                continue
            if isinstance(page_index, int) and 0 < page_index < page_count:
                page_starts.add(page_index)

    try:
        visit(reader.outline)
    except Exception:
        # PDFs without a usable outline still work with fixed-size page segments.
        return []
    return sorted(page_starts)


def _split_pdf(pdf_bytes: bytes, page_count: int) -> list[tuple[int, int, bytes]]:
    pages_per_segment = DETAILED_SEGMENT_PAGES if page_count <= 150 else SEGMENT_PAGES
    if page_count <= pages_per_segment:
        return [(1, page_count, pdf_bytes)]
    reader = PdfReader(io.BytesIO(pdf_bytes), strict=False)
    outline_starts = _outline_page_starts(reader, page_count) if page_count > 150 else []
    segments = []
    start = 0
    while start < page_count:
        hard_end = min(page_count, start + pages_per_segment)
        end = hard_end
        if outline_starts:
            # Prefer the last chapter/section boundary near the segment limit, but
            # avoid creating many tiny model requests for short nested headings.
            min_segment_pages = max(5, pages_per_segment // 2)
            candidates = [
                page_index
                for page_index in outline_starts
                if start + min_segment_pages <= page_index <= hard_end
            ]
            if candidates:
                end = candidates[-1]
        writer = PdfWriter()
        for page_index in range(start, end):
            writer.add_page(reader.pages[page_index])
        buffer = io.BytesIO()
        writer.write(buffer)
        segment_bytes = buffer.getvalue()
        if len(segment_bytes) > MAX_PDF_BYTES:
            raise ApiError(413, "A PDF segment exceeds Gemini's 50 MiB upload limit.")
        segments.append((start + 1, end, segment_bytes))
        start = end
    return segments


def _selected_page_segments(
    pdf_bytes: bytes, page_count: int, selected_pages: list[int]
) -> list[tuple[int, int, bytes]]:
    """Build OCR PDFs only for consecutive pages that lack a usable text layer."""
    pages = sorted({page for page in selected_pages if 1 <= page <= page_count})
    if not pages:
        return []
    reader = PdfReader(io.BytesIO(pdf_bytes), strict=False)
    max_pages = DETAILED_SEGMENT_PAGES if page_count <= 150 else SEGMENT_PAGES
    groups: list[tuple[int, int]] = []
    start = previous = pages[0]
    for page_number in pages[1:]:
        if page_number == previous + 1 and page_number - start < max_pages:
            previous = page_number
            continue
        groups.append((start, previous))
        start = previous = page_number
    groups.append((start, previous))

    segments = []
    for start, end in groups:
        writer = PdfWriter()
        for page_number in range(start, end + 1):
            writer.add_page(reader.pages[page_number - 1])
        buffer = io.BytesIO()
        writer.write(buffer)
        segment_bytes = buffer.getvalue()
        if len(segment_bytes) > MAX_PDF_BYTES:
            raise ApiError(413, "A PDF segment exceeds Gemini's 50 MiB upload limit.")
        segments.append((start, end, segment_bytes))
    return segments


def _split_segment_for_retry(
    segment: tuple[int, int, bytes],
) -> list[tuple[int, int, bytes]]:
    """Bisect a segment when Gemini cannot fit a complete structured response."""
    page_start, page_end, pdf_bytes = segment
    page_count = page_end - page_start + 1
    if page_count <= 1:
        return []

    reader = PdfReader(io.BytesIO(pdf_bytes), strict=False)
    left_page_count = page_count // 2
    output: list[tuple[int, int, bytes]] = []
    for local_start, local_end in (
        (0, left_page_count),
        (left_page_count, page_count),
    ):
        writer = PdfWriter()
        for page_index in range(local_start, local_end):
            writer.add_page(reader.pages[page_index])
        buffer = io.BytesIO()
        writer.write(buffer)
        child_bytes = buffer.getvalue()
        if len(child_bytes) > MAX_PDF_BYTES:
            raise ApiError(413, "A PDF segment exceeds Gemini's 50 MiB upload limit.")
        output.append(
            (
                page_start + local_start,
                page_start + local_end - 1,
                child_bytes,
            )
        )
    return output


def _convert_segment(segment: tuple[int, int, bytes], filename: str, api_key: str, deadline: float, total_pages: int) -> tuple[dict, dict]:
    page_start, page_end, pdf_bytes = segment
    display_name = filename if total_pages <= SEGMENT_PAGES else f"{filename}.pages-{page_start}-{page_end}.pdf"
    uploaded = _upload_pdf(pdf_bytes, display_name, api_key, deadline)
    try:
        return _generate_content(uploaded["uri"], api_key, deadline, page_start, page_end, total_pages)
    finally:
        _delete_uploaded_file(uploaded, api_key)


def _convert_segments(
    segments: list[tuple[int, int, bytes]],
    filename: str,
    api_key: str,
    deadline: float,
    total_pages: int,
    expected_pages: set[int] | None = None,
) -> tuple[list[tuple[int, int, dict, dict]], int]:
    """Convert ordered segments, bisecting any segment that exceeds Gemini's output limit."""
    pending_segments = list(segments)
    segment_results: dict[int, tuple[int, tuple[dict, dict]]] = {}
    requests_attempted = 0
    while pending_segments:
        batch = pending_segments[:RPM_LIMIT]
        pending_segments = pending_segments[RPM_LIMIT:]
        while True:
            retry_after = limiter.reserve(len(batch))
            if retry_after is None:
                break
            remaining = deadline - time.monotonic()
            if retry_after >= remaining - 1:
                raise ApiError(504, "Gemini rate-limit wait would exceed the processing deadline.")
            time.sleep(retry_after)
        requests_attempted += len(batch)
        failures: list[ApiError] = []
        with ThreadPoolExecutor(max_workers=min(MAX_PARALLEL_SEGMENTS, len(batch))) as executor:
            futures = {
                executor.submit(_convert_segment, segment, filename, api_key, deadline, total_pages): segment
                for segment in batch
            }
            for future in as_completed(futures):
                segment = futures[future]
                try:
                    segment_result = future.result()
                except ApiError as exc:
                    if exc.status == 422 and segment[1] > segment[0]:
                        pending_segments.extend(_split_segment_for_retry(segment))
                    else:
                        failures.append(exc)
                else:
                    segment_results[segment[0]] = (segment[1], segment_result)
        if failures:
            raise failures[0]
        pending_segments.sort(key=lambda segment: segment[0])

    expected = set(range(1, total_pages + 1)) if expected_pages is None else expected_pages
    ordered_segment_results = []
    covered_pages: set[int] = set()
    for page_start, (page_end, segment_result) in sorted(segment_results.items()):
        result_pages = set(range(page_start, page_end + 1))
        if not result_pages.issubset(expected) or covered_pages.intersection(result_pages):
            raise ApiError(502, "Gemini segment results do not cover the PDF in order.")
        covered_pages.update(result_pages)
        ordered_segment_results.append((page_start, page_end, *segment_result))
    if covered_pages != expected:
        raise ApiError(502, "Gemini did not return results for every PDF page.")
    return ordered_segment_results, requests_attempted


def _merge_segment_results(results: list[tuple[dict, dict]]) -> tuple[dict, dict]:
    merged: list[dict] = []
    usage: dict[str, int] = {}
    for result, chunk_usage in results:
        if isinstance(chunk_usage, dict):
            for key, value in chunk_usage.items():
                if isinstance(value, (int, float)):
                    usage[key] = usage.get(key, 0) + int(value)
        for item in result["data"]["lrrDetails"]:
            section = item["section"].strip()
            text = item["lrrText"].strip()
            footnotes = item["footnote"]
            if not text and not footnotes:
                continue
            if not text:
                text = "\n".join(footnotes)
            if section.casefold() == "continuation":
                if merged:
                    if text:
                        merged[-1]["lrrText"] = "\n\n".join(part for part in (merged[-1]["lrrText"], text) if part)
                    merged[-1]["footnote"].extend(footnotes)
                else:
                    merged.append({**item, "section": "Document", "lrrText": text})
                continue
            if merged and merged[-1]["section"].casefold() == section.casefold():
                if text:
                    merged[-1]["lrrText"] = "\n\n".join(part for part in (merged[-1]["lrrText"], text) if part)
                merged[-1]["footnote"].extend(footnotes)
                continue
            merged.append({**item, "section": section, "lrrText": text, "footnote": list(footnotes)})

    for index, item in enumerate(merged, start=1):
        item["lrrPublishStatus"] = "Published"
        item["sectionCounter"] = index
        item["lrrVersion"] = 1
        item["type"] = "manual"
    return {"data": {"lrrDetails": merged}}, usage


def _extract_pdf_file(content_type: str, body: bytes) -> tuple[bytes, str]:
    if not content_type.lower().startswith("multipart/form-data"):
        raise ApiError(415, "Send the PDF as multipart/form-data in a field named 'file'.")
    try:
        headers = (
            f"MIME-Version: 1.0\r\nContent-Type: {content_type}\r\n\r\n".encode("utf-8")
        )
        message = BytesParser(policy=policy.default).parsebytes(headers + body)
        if not message.is_multipart():
            raise ValueError("Not a multipart request")
        files = []
        for part in message.iter_parts():
            if part.get_content_disposition() == "form-data" and part.get_param("name", header="content-disposition") == "file":
                payload = part.get_payload(decode=True)
                if payload is not None:
                    files.append((payload, part.get_filename() or "document.pdf"))
        if len(files) != 1:
            raise ValueError("Expected exactly one file field named file")
        return files[0]
    except Exception as exc:
        raise ApiError(400, "Malformed multipart request; include one PDF file in a field named 'file'.") from exc


def _validate_pdf(pdf_bytes: bytes) -> int:
    if not pdf_bytes or len(pdf_bytes) > MAX_PDF_BYTES:
        raise ApiError(413, "PDF must be non-empty and no larger than 50 MiB.")
    if pdf_bytes[:1024].find(b"%PDF-") < 0:
        raise ApiError(400, "The uploaded file does not appear to be a PDF.")
    try:
        reader = PdfReader(io.BytesIO(pdf_bytes), strict=False)
        if reader.is_encrypted:
            raise ApiError(422, "Password-protected PDFs are not supported.")
        pages = len(reader.pages)
    except ApiError:
        raise
    except Exception as exc:
        raise ApiError(400, "The PDF could not be opened or its page count could not be read.") from exc
    if pages < 1:
        raise ApiError(400, "The PDF contains no pages.")
    if pages > MAX_PAGES:
        raise ApiError(413, f"PDFs are limited to {MAX_PAGES} pages.")
    return pages


def _make_heading_chunks(
    details: list[dict], max_chars: int = 55000, max_lines: int = 600
) -> list[list[dict]]:
    records: list[dict] = []
    for item in details:
        title = item["section"].strip()
        is_contents = title.casefold() == "contents"
        if title.casefold() != "document information":
            title_parts = [part.strip() for part in title.split(" > ") if part.strip()]
            for part in title_parts:
                records.append(
                    {
                        "lineId": f"L{len(records) + 1:07d}",
                        "text": part,
                        "kind": "locked_heading" if is_contents else "heading_candidate",
                    }
                )
        body_kind = "contents_body" if is_contents else "body_candidate"
        for line in item["lrrText"].splitlines():
            if line.strip():
                records.append(
                    {"lineId": f"L{len(records) + 1:07d}", "text": line, "kind": body_kind}
                )

    chunks: list[list[dict]] = []
    chunk: list[dict] = []
    char_count = 0
    for record in records:
        preview = record["text"] if len(record["text"]) <= 1000 else record["text"][:1000]
        line_chars = len(record["lineId"]) + len(record["kind"]) + len(preview) + 16
        if chunk and (char_count + line_chars > max_chars or len(chunk) >= max_lines):
            chunks.append(chunk)
            chunk = []
            char_count = 0
        chunk.append({**record, "preview": preview})
        char_count += line_chars
    if chunk:
        chunks.append(chunk)
    return chunks


def _classify_heading_chunk(chunk: list[dict], api_key: str, deadline: float) -> dict[str, int]:
    model = MODEL.strip()
    if not re.fullmatch(r"[A-Za-z0-9._-]+", model):
        raise ApiError(500, "GEMINI_MODEL contains unsupported characters.")
    prompt_lines = [
        f'{item["lineId"]} [{item["kind"]}]: {item["preview"]}'
        for item in chunk
    ]
    body = {
        "contents": [
            {
                "parts": [
                    {
                        "text": (
                            f"{HEADING_PROMPT}\n\n"
                            "Each source line has a unique lineId and a kind. "
                            "Never classify contents_body lines as headings. "
                            "For each heading, copy headingText exactly from its source line. "
                            "Return only lineId, headingText, level, and confidence.\n\n"
                            + "\n".join(prompt_lines)
                        )
                    }
                ]
            }
        ],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": HEADING_SCHEMA,
            "temperature": 0,
            "maxOutputTokens": 16384,
        },
    }
    request = Request(
        f"{GOOGLE_API_ROOT}/v1beta/models/{model}:generateContent",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
    )
    raw = _google_request(request, deadline, cap=BASE_PROCESSING_DEADLINE_SECONDS)
    response = json.loads(raw.decode("utf-8"))
    candidate = (response.get("candidates") or [None])[0]
    if not candidate or candidate.get("finishReason") in ("MAX_TOKENS", "RECITATION"):
        raise ValueError("Gemini could not complete the heading classification response")
    output = "".join(
        part.get("text", "")
        for part in candidate.get("content", {}).get("parts", [])
        if isinstance(part, dict)
    )
    document = json.loads(output)
    valid_lines = {item["lineId"]: item for item in chunk}
    headings: dict[str, int] = {}
    for item in document.get("headings", []):
        if not isinstance(item, dict):
            continue
        line_id = item.get("lineId")
        source = valid_lines.get(line_id)
        if not source or source["kind"] == "contents_body":
            continue
        try:
            confidence = float(item.get("confidence", 0))
            level = int(item.get("level", 1))
        except (TypeError, ValueError):
            continue
        heading_text = re.sub(r"\s+", " ", str(item.get("headingText", ""))).strip().casefold()
        source_text = re.sub(r"\s+", " ", source["text"]).strip().casefold()
        words = source["text"].split()
        has_heading_marker = bool(
            re.match(
                r"^(?:\d+(?:\.\d+)*\.?|chapter\s+\w+|part\s+\w+|article\s+\w+|section\s+\w+|annex\b|appendix\b|schedule\b)",
                source["text"],
                re.IGNORECASE,
            )
        )
        capitalized_words = sum(word[:1].isupper() for word in words)
        title_case = len(words) > 1 and capitalized_words / len(words) >= 0.5
        body_line_is_title_like = (
            len(words) <= 8
            and len(source["text"]) <= 110
            and (has_heading_marker or (source["text"][:1].isupper() and (len(words) <= 4 or title_case)))
        )
        looks_like_heading = (
            len(words) <= (8 if source["kind"] == "body_candidate" else 16)
            and len(source["text"]) <= 150
            and not re.search(r"[.!?;]\s*$", source["text"])
            and (source["kind"] != "body_candidate" or body_line_is_title_like)
        )
        if (
            confidence >= 0.8
            and heading_text == source_text
            and looks_like_heading
            and 1 <= level <= 6
        ):
            headings[line_id] = level
    return headings


def _refine_embedded_structure(result: dict, api_key: str, deadline: float) -> tuple[dict, int, bool]:
    chunks = _make_heading_chunks(result["data"]["lrrDetails"])
    if not chunks:
        return result, 0, False
    classified: dict[str, int] = {}
    requests_attempted = 0
    for batch_start in range(0, len(chunks), RPM_LIMIT):
        batch = chunks[batch_start : batch_start + RPM_LIMIT]
        while True:
            retry_after = limiter.reserve(len(batch))
            if retry_after is None:
                break
            remaining = deadline - time.monotonic()
            if retry_after >= remaining - 1:
                return result, requests_attempted, False
            time.sleep(retry_after)
        requests_attempted += len(batch)
        try:
            with ThreadPoolExecutor(max_workers=min(MAX_PARALLEL_SEGMENTS, len(batch))) as executor:
                futures = [
                    executor.submit(_classify_heading_chunk, chunk, api_key, deadline)
                    for chunk in batch
                ]
                for future in as_completed(futures):
                    classified.update(future.result())
        except Exception:
            # A failed structure call leaves the exact local text available as fallback.
            return result, requests_attempted, False

    if not classified:
        return result, requests_attempted, False

    records = [record for chunk in chunks for record in chunk]
    output: list[dict] = []
    current: dict | None = None
    for record in records:
        title = record["text"]
        if record["kind"] == "locked_heading" or record["lineId"] in classified:
            if current is not None and not current["lrrText"]:
                current["section"] += " > " + title
            else:
                current = {"section": title, "lrrText": "", "footnote": []}
                output.append(current)
        else:
            if current is None:
                current = {"section": "Document information", "lrrText": "", "footnote": []}
                output.append(current)
            current["lrrText"] += ("\n" if current["lrrText"] else "") + title

    details = []
    for index, item in enumerate(output, start=1):
        details.append(
            {
                "section": item["section"],
                "lrrText": item["lrrText"].strip(),
                "lrrPublishStatus": "Published",
                "sectionCounter": index,
                "lrrVersion": 1,
                "type": "manual",
                "footnote": [],
            }
        )
    return {"data": {"lrrDetails": details}}, requests_attempted, True


def _fold_empty_local_sections(sections: list[dict]) -> list[dict]:
    """Keep title-only local headings as hierarchy instead of empty JSON rows."""
    date_only = re.compile(
        r"(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}",
        re.IGNORECASE,
    )
    output: list[dict] = []
    pending: list[dict] = []
    for item in sections:
        if not item["lrrText"].strip() and not item["footnote"]:
            pending.append(item)
            continue
        if pending:
            titles = []
            child_title = item["section"]
            consume_child_title = False
            for parent in pending:
                title = parent["_source_section"]
                if (
                    title.casefold().startswith("version effective as of ")
                    and date_only.fullmatch(child_title.strip())
                ):
                    title = f"{title} {child_title.strip()}"
                    consume_child_title = True
                titles.append(title)
            if titles:
                item["section"] = " > ".join(
                    titles if consume_child_title else titles + [child_title]
                )
            item["_page_number"] = min(
                [item.get("_page_number", 0)]
                + [parent.get("_page_number", 0) for parent in pending]
            )
            pending.clear()
        output.append(item)

    if pending and output:
        tail = "\n".join(item["_source_section"] for item in pending)
        output[-1]["lrrText"] = "\n".join(
            part for part in (output[-1]["lrrText"].strip(), tail) if part
        )
    return output


def _extract_embedded_text(pdf_bytes: bytes) -> dict | None:
    """Build verbatim sections and mark sparse image pages for selective OCR."""
    try:
        ocr_pages: list[int] = []
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            page_lines: list[list[dict]] = []
            margin_lines: dict[str, set[int]] = {}
            page_text_counts: list[int] = []

            for page_number, page in enumerate(pdf.pages, start=1):
                lines = []
                for extracted in page.extract_text_lines(return_chars=True):
                    text = re.sub(r"\s+", " ", extracted.get("text", "")).strip()
                    if not text:
                        continue
                    chars = [char for char in extracted.get("chars", []) if char.get("text", "").strip()]
                    sizes = [float(char.get("size", 0)) for char in chars if char.get("size")]
                    bold_ratio = sum(
                        "bold" in str(char.get("fontname", "")).casefold() for char in chars
                    ) / max(1, len(chars))
                    line = {
                        "text": text,
                        "top": float(extracted.get("top", 0)),
                        "bottom": float(extracted.get("bottom", 0)),
                        "page_height": float(page.height),
                        "size": sum(sizes) / len(sizes) if sizes else 0.0,
                        "bold_ratio": bold_ratio,
                        "page_number": page_number,
                    }
                    lines.append(line)
                    if line["top"] < 95 or line["bottom"] > line["page_height"] - 45:
                        margin_lines.setdefault(text.casefold(), set()).add(page_number)

                page_lines.append(lines)
                page_text_counts.append(
                    sum(char.isalnum() for line in lines for char in line["text"])
                )

                # A sparse page needs OCR when it contains a substantial raster image.
                # Sparse text-only pages are retained; these are often blank separator pages
                # or pages that contain only a running page counter.
                has_large_image = any(
                    float(image.get("width", 0)) * float(image.get("height", 0))
                    >= float(page.width) * float(page.height) * 0.15
                    for image in page.images
                )
                if has_large_image and page_text_counts[-1] < 80:
                    ocr_pages.append(page_number)

        page_count = len(page_lines)
        if not page_count:
            return None
        if len(ocr_pages) > max(20, math.ceil(page_count * 0.1)):
            # Mostly scanned documents are more efficient as normal OCR batches.
            return None

        repeat_threshold = max(3, math.ceil(page_count * 0.15))
        repeated_marginalia = {
            text for text, occurrences in margin_lines.items() if len(occurrences) >= repeat_threshold
        }
        body_sizes = [
            line["size"]
            for lines in page_lines
            for line in lines
            if line["size"] and len(line["text"]) > 35 and line["bold_ratio"] < 0.4
        ]
        size_counts = Counter(round(size, 1) for size in body_sizes)
        body_size = size_counts.most_common(1)[0][0] if size_counts else 11.0

        def is_heading(line: dict) -> bool:
            text = line["text"]
            # Basel chapter cover pages contain prominent version metadata that is
            # visually styled like a heading but belongs in the chapter body.
            if re.match(r"^version\s+effective\s+as\s+of\b", text, re.IGNORECASE):
                return False
            numbered = re.match(r"^\d+(?:\.\d+)*\.?\s+(.+)$", text)
            named_appendix = re.match(r"^(annex|appendix|schedule)\b", text, re.IGNORECASE)
            strong_style = line["bold_ratio"] >= 0.65 or line["size"] >= body_size * 1.16
            sentence_ending = bool(re.search(r"[.!?;:]\s*$", text))
            if not strong_style or len(text) > 180:
                return False
            return bool(
                numbered
                or named_appendix
                or (line["bold_ratio"] >= 0.65 and len(text) <= 120 and not sentence_ending)
                or (line["size"] >= body_size * 1.25 and not sentence_ending)
            )

        contents_pages: set[int] = set()
        in_contents = False
        for page_number, lines in enumerate(page_lines, start=1):
            has_contents_title = any(
                line["text"].casefold() == "contents"
                and (line["size"] >= body_size * 1.2 or line["bold_ratio"] >= 0.65)
                for line in lines
            )
            has_contents_entries = any(
                re.search(r"(?:\.{2,}|…{2,})\s*\d{1,5}\s*$", line["text"])
                for line in lines
            )
            if has_contents_title:
                in_contents = True
            if in_contents and (has_contents_title or has_contents_entries):
                contents_pages.add(page_number)
            elif in_contents:
                in_contents = False

        sections: list[dict] = []
        current: dict | None = None

        def start_section(
            title: str, line: dict | None = None, page_number: int | None = None
        ) -> None:
            nonlocal current
            current = {
                "section": title.strip() or "Document",
                "_source_section": title.strip() or "Document",
                "lrrText": "",
                "footnote": [],
                "_heading_size": line["size"] if line else 0.0,
                "_heading_bottom": line["bottom"] if line else 0.0,
                "_page_number": line["page_number"] if line else (page_number or 0),
            }
            sections.append(current)

        def add_body(text: str, page_number: int) -> None:
            nonlocal current
            if current is None:
                start_section("Document information", page_number=page_number)
            current["lrrText"] += ("\n" if current["lrrText"] else "") + text

        for page_number, lines in enumerate(page_lines, start=1):
            contents_page = page_number in contents_pages
            version_metadata_lines: set[int] = set()
            for line_index, line in enumerate(lines):
                if not re.match(
                    r"^version\s+effective\s+as\s+of\b", line["text"], re.IGNORECASE
                ):
                    continue
                version_metadata_lines.add(line_index)
                previous = line
                for continuation_index in range(line_index + 1, min(line_index + 3, len(lines))):
                    continuation = lines[continuation_index]
                    gap = continuation["top"] - previous["bottom"]
                    same_display_line = (
                        continuation["size"] >= line["size"] * 0.85
                        and len(continuation["text"]) <= 60
                        and gap <= max(12.0, line["size"] * 0.75)
                    )
                    if not same_display_line:
                        break
                    version_metadata_lines.add(continuation_index)
                    previous = continuation
            first_page_has_numbered_heading = any(
                is_heading(line) and re.match(r"^\d+(?:\.\d+)*\.?\s+.+$", line["text"])
                for line in lines
            )
            first_page_has_body = any(
                len(line["text"]) >= 60
                and line["size"] <= body_size * 1.15
                and line["bold_ratio"] < 0.65
                and not (line["top"] < 95 or line["bottom"] > line["page_height"] - 45)
                for line in lines
            )
            first_page_is_cover = page_number == 1 and not first_page_has_numbered_heading and not first_page_has_body
            for line_index, line in enumerate(lines):
                text = line["text"]
                is_margin = line["top"] < 95 or line["bottom"] > line["page_height"] - 45
                if text.casefold() in repeated_marginalia and is_margin:
                    continue
                page_counter = re.fullmatch(
                    r"(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\s+)?(?:page\s+)?\d{1,5}\s*(?:/|of)\s*\d{1,5}",
                    text,
                    re.IGNORECASE,
                )
                if is_margin and (re.fullmatch(r"\d{1,3}", text) or page_counter):
                    continue
                if contents_page and text.casefold() == "contents":
                    start_section("Contents", line)
                    continue
                if contents_page:
                    add_body(text, line["page_number"])
                    continue
                if first_page_is_cover:
                    add_body(text, line["page_number"])
                    continue
                if line_index in version_metadata_lines:
                    add_body(text, line["page_number"])
                    continue
                if is_heading(line):
                    if (
                        current is not None
                        and not current["lrrText"]
                        and current["_page_number"] == line["page_number"]
                        and current["_heading_size"] >= body_size * 1.2
                        and line["size"] >= body_size * 1.2
                        and 0 <= line["top"] - current["_heading_bottom"]
                        <= max(12.0, min(28.0, line["size"] * 1.5))
                    ):
                        current["section"] += " " + text
                        current["_source_section"] = current["section"]
                        current["_heading_size"] = max(current["_heading_size"], line["size"])
                        current["_heading_bottom"] = line["bottom"]
                    else:
                        start_section(text, line)
                else:
                    add_body(text, line["page_number"])

        if not sections:
            return None

        # The JSON contract is a flat section list. Fold bodyless parent headings into
        # their child section names so hierarchy is visible without emitting blank rows.
        consumed: set[int] = set()
        for item in sections:
            item["_parent_sections"] = []
        for index, parent in enumerate(sections):
            if not parent["lrrText"]:
                parent_number_match = re.match(r"^(\d+(?:\.\d+)*)\.?\s+", parent["_source_section"])
                parent_number = tuple(parent_number_match.group(1).split(".")) if parent_number_match else ()
                if (
                    not parent_number
                    and "guidelines on ict and security risk management" in parent["_source_section"].casefold()
                    and index + 1 < len(sections)
                    and re.match(r"^\d+(?:\.\d+)*\.?\s+", sections[index + 1]["_source_section"])
                ):
                    sections[index + 1]["_parent_sections"].append((index, parent["_source_section"]))
                    consumed.add(index)
                    continue
                child_indexes = []
                for child_index in range(index + 1, len(sections)):
                    child = sections[child_index]
                    child_number_match = re.match(r"^(\d+(?:\.\d+)*)\.?\s+", child["_source_section"])
                    child_number = tuple(child_number_match.group(1).split(".")) if child_number_match else ()
                    if parent_number:
                        if len(child_number) > len(parent_number) and child_number[: len(parent_number)] == parent_number:
                            child_indexes.append(child_index)
                            continue
                        break
                    if child["_heading_size"] < parent["_heading_size"] * 0.9:
                        child_indexes.append(child_index)
                        continue
                    break
                if child_indexes:
                    child_index = child_indexes[0]
                    sections[child_index]["_parent_sections"].append((index, parent["_source_section"]))
                    consumed.add(index)
                    continue
                # A document-level heading immediately before a numbered outline title
                # acts as the parent of that outline even when the styles are similar.
                next_index = index + 1
                if not parent_number and next_index < len(sections):
                    next_item = sections[next_index]
                    if re.match(r"^\d+(?:\.\d+)*\.?\s+", next_item["_source_section"]):
                        next_item["_parent_sections"].append((index, parent["_source_section"]))
                        consumed.add(index)
                        continue
                if (
                    not parent_number
                    and "guidelines on ict and security risk management" in parent["_source_section"].casefold()
                    and index > 0
                    and sections[index - 1]["_source_section"].casefold() == "3. guidelines"
                ):
                    sections[index - 1]["lrrText"] += (
                        "\n" if sections[index - 1]["lrrText"] else ""
                    ) + parent["_source_section"]
                    consumed.add(index)

        folded = []
        for index, item in enumerate(sections):
            if index in consumed:
                continue
            parents = [title for _, title in sorted(item["_parent_sections"])]
            item["section"] = " > ".join(parents + [item["_source_section"]])
            folded.append(item)
        sections = _fold_empty_local_sections(folded)

        details = []
        for index, item in enumerate(sections, start=1):
            details.append(
                {
                    "section": item["section"],
                    "lrrText": item["lrrText"].strip(),
                    "lrrPublishStatus": "Published",
                    "sectionCounter": index,
                    "lrrVersion": 1,
                    "type": "manual",
                    "footnote": [],
                    "_pageNumber": item["_page_number"],
                }
            )
        return {"data": {"lrrDetails": details}, "_ocr_pages": ocr_pages}
    except Exception:
        # Keep OCR as a fallback for PDFs the local layout parser cannot read safely.
        return None


class PdfToJsonHandler(BaseHTTPRequestHandler):
    server_version = "PdfToJson/1.0"

    def _send_json(self, status: int, payload: dict, headers: dict[str, str] | None = None) -> None:
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(encoded)

    def _read_request_body(self, content_length: int, started: float) -> bytes:
        body = bytearray()
        while len(body) < content_length:
            remaining = started + BASE_PROCESSING_DEADLINE_SECONDS - time.monotonic()
            if remaining <= 1:
                raise ApiError(504, "PDF upload exceeded the 5-minute processing window.")
            self.connection.settimeout(min(30.0, remaining))
            try:
                chunk = self.rfile.read(min(64 * 1024, content_length - len(body)))
            except (socket.timeout, TimeoutError) as exc:
                raise ApiError(408, "Timed out while receiving the PDF upload.") from exc
            if not chunk:
                raise ApiError(400, "Request body ended before the complete PDF was received.")
            body.extend(chunk)
        return bytes(body)

    def do_GET(self) -> None:
        if self.path != "/health":
            self._send_json(404, {"error": "Not found"})
            return
        self._send_json(
            200,
            {
                "status": "ok",
                "model": MODEL,
                "gemini_configured": bool(os.getenv("GEMINI_API_KEY", "").strip()),
                "max_pages": MAX_PAGES,
                "max_pdf_bytes": MAX_PDF_BYTES,
                "max_processing_seconds": MAX_PROCESSING_DEADLINE_SECONDS,
            },
        )

    def do_POST(self) -> None:
        if self.path != "/v1/convert":
            self._send_json(404, {"error": "Not found"})
            return
        started = time.monotonic()
        try:
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError as exc:
                raise ApiError(400, "Invalid Content-Length header.") from exc
            if content_length <= 0:
                raise ApiError(411, "Content-Length is required.")
            if content_length > MAX_BODY_BYTES:
                raise ApiError(413, "PDF upload exceeds the 50 MiB file limit.")
            body = self._read_request_body(content_length, started)
            pdf_bytes, filename = _extract_pdf_file(self.headers.get("Content-Type", ""), body)
            page_count = _validate_pdf(pdf_bytes)
            api_key = os.getenv("GEMINI_API_KEY", "").strip()
            processing_deadline_seconds = _processing_deadline_seconds(page_count)
            deadline = started + processing_deadline_seconds
            local_result = _extract_embedded_text(pdf_bytes)
            if local_result is not None:
                ocr_pages = local_result.pop("_ocr_pages", [])
                structure_requests = 0
                extraction_method = "embedded-text-heuristic"
                if ocr_pages:
                    if not api_key:
                        raise ApiError(
                            503,
                            f"{len(ocr_pages)} page(s) need OCR. Set GEMINI_API_KEY before converting it.",
                        )
                    safe_filename = os.path.basename(filename).replace("\x00", "")[:120] or "document.pdf"
                    if not safe_filename.lower().endswith(".pdf"):
                        safe_filename += ".pdf"
                    ocr_segments = _selected_page_segments(pdf_bytes, page_count, ocr_pages)
                    ocr_results, structure_requests = _convert_segments(
                        ocr_segments,
                        safe_filename,
                        api_key,
                        deadline,
                        page_count,
                        expected_pages=set(ocr_pages),
                    )
                    image_details = []
                    for page_start, page_end, segment_result, _ in ocr_results:
                        for item in segment_result["data"]["lrrDetails"]:
                            text = item["lrrText"].strip()
                            footnotes = list(item["footnote"])
                            if not text and not footnotes:
                                continue
                            if not text:
                                text = "\n".join(footnotes)
                                footnotes = []
                            section = item["section"].strip()
                            if section.casefold() in {"continuation", "document", "document information"}:
                                section = "Image content"
                            image_details.append(
                                {
                                    "section": f"{section} (page {page_start})",
                                    "lrrText": text,
                                    "lrrPublishStatus": "Published",
                                    "sectionCounter": 0,
                                    "lrrVersion": 1,
                                    "type": "manual",
                                    "footnote": footnotes,
                                    "_pageNumber": page_start,
                                    "_ocrOrder": len(image_details),
                                }
                            )
                    all_details = local_result["data"]["lrrDetails"] + image_details
                    all_details.sort(
                        key=lambda item: (
                            item.get("_pageNumber", 0),
                            item.get("_ocrOrder", -1),
                        )
                    )
                    for index, item in enumerate(all_details, start=1):
                        item.pop("_pageNumber", None)
                        item.pop("_ocrOrder", None)
                        item["sectionCounter"] = index
                    local_result["data"]["lrrDetails"] = all_details
                    extraction_method = "embedded-text+gemini-ocr"
                else:
                    for item in local_result["data"]["lrrDetails"]:
                        item.pop("_pageNumber", None)
                if api_key and not ocr_pages:
                    local_result, structure_requests, used_ai = _refine_embedded_structure(
                        local_result, api_key, deadline
                    )
                    if used_ai:
                        extraction_method = "embedded-text+gemini-structure"
                if time.monotonic() - started >= processing_deadline_seconds:
                    raise ApiError(504, "PDF conversion exceeded its processing deadline.")
                elapsed_ms = int((time.monotonic() - started) * 1000)
                headers = {
                    "X-Processing-Time-Ms": str(elapsed_ms),
                    "X-PDF-Pages": str(page_count),
                    "X-Extraction-Method": extraction_method,
                    "X-Gemini-Requests": str(structure_requests),
                }
                if structure_requests:
                    headers["X-Gemini-Model"] = MODEL
                self._send_json(200, local_result, headers)
                return

            if not api_key:
                raise ApiError(503, "This PDF needs OCR. Set GEMINI_API_KEY before converting it.")
            segments = _split_pdf(pdf_bytes, page_count)
            safe_filename = os.path.basename(filename).replace("\x00", "")[:120] or "document.pdf"
            if not safe_filename.lower().endswith(".pdf"):
                safe_filename += ".pdf"
            ordered_segment_results, requests_attempted = _convert_segments(
                segments, safe_filename, api_key, deadline, page_count
            )
            result, usage = _merge_segment_results(
                [(segment_result, segment_usage) for _, _, segment_result, segment_usage in ordered_segment_results]
            )
            elapsed_ms = int((time.monotonic() - started) * 1000)
            if time.monotonic() - started >= processing_deadline_seconds:
                raise ApiError(504, "PDF conversion exceeded its processing deadline.")
            headers = {
                "X-Processing-Time-Ms": str(elapsed_ms),
                "X-PDF-Pages": str(page_count),
                "X-Gemini-Model": MODEL,
                "X-Gemini-Requests": str(requests_attempted),
            }
            total_tokens = usage.get("totalTokenCount") if isinstance(usage, dict) else None
            if total_tokens is not None:
                headers["X-Gemini-Total-Tokens"] = str(total_tokens)
            self._send_json(200, result, headers)
        except ApiError as exc:
            self._send_json(exc.status, {"error": exc.message}, exc.headers)
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception:
            self._send_json(500, {"error": "Unexpected conversion error."})

    def log_message(self, format: str, *args) -> None:
        # Do not log headers, API keys, uploaded content, or filenames.
        super().log_message(format, *args)


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), PdfToJsonHandler)
    server.daemon_threads = True
    print(f"PDF-to-JSON API listening on http://{HOST}:{PORT} (model={MODEL})", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping PDF-to-JSON API.", flush=True)
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
