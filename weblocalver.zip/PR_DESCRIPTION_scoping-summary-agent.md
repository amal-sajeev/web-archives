# Pull Request Description: `scoping-summary-agent`

## Summary
Updates `scoping-summary-agent` to read source paths and soft-exclusion flags directly from `review_data_extraction`, filter excluded LRR mandates and documents before synthesis, preserve unchanged sections during partial regeneration, and authenticate via AI Access Layer.

## What Changed
- **AI Access Layer Migration & Deprecation Cleanup**
  - `src/main/utils/google_oauth_token_provider.py` *(new)*, `src/main/config/config.py`, `src/main/utils/gemini_connection.py`: Configures `ChatGoogleGenerativeAI` using `GoogleOAuthTokenProvider().token` and `AI_ACCESS_LAYER_BASE_URL` / `GENAI_BASE_URL` without `project`/`location` or disallowed sampling parameters; removed vestigial `GENERATION_CONFIG` and `AI_Model_Config_Setting` sampling values in `src/main/agent_helper/action_service.py`.
  - `src/main/persistor/review_data_extraction_repository.py` & `src/main/persistor/review_research_recommendation_repository.py`: Replaced deprecated `datetime.utcnow()` with timezone-aware `datetime.now(timezone.utc).replace(tzinfo=None)` and removed legacy Pydantic v1 `.dict()` handling.
- **Database-Driven Metadata & Soft-Exclusion Filtering**
  - `src/main/utils/data_manager.py`: Maps `"internet_search_data_enriched.json"` to `("lrr", "internet_search_data")`, prefers `internet_search_data_enriched.json` over `internet_search_data.json` when reading LRR data, and adds `_filter_lrr_data_with_table_meta` to exclude soft-excluded LRR risk entries/mandates based on `review_data_extraction` metadata.
  - `src/main/utils/policy_section_builder.py`: Updates `build_regulation_manifest` to check `_is_excluded_document` and skip excluded risk entries and mandates.
- **Partial Regeneration Citation Preservation**
  - `src/main/service/analytics_service.py`: When regenerating specific sections (`previous_report` present), merges new citation entries with existing `citation_mapping.json` (`{**existing_citations, **chunk_id_path_mapping}`) instead of overwriting citations from untouched sections.
- **Tests**
  - Added `src/tests/conftest.py` `httpx.Client` test shim and `src/tests/test_ai_access_layer_and_lrr_filtering.py`.

## Why
Ensures regenerated Preliminary Research reports reflect document, section, GFMS finding, historical plan, and LRR mandate exclusions stored in `review_data_extraction` without losing citations on sections that were not regenerated.

## Testing & Coverage
- Command: `PYTHONPATH="src/main;src" pytest src/tests --cov=src/main --cov-report=term-missing --cov-fail-under=80`
- Result: **155 passed, 0 failed** (**83.43% statement coverage**)
