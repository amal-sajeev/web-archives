# Pull Request Description: `scoping-dataextraction-agent`

## Summary
Updates `scoping-dataextraction-agent` to store structured document/section metadata in `dbaware_scoping.review_data_extraction` for soft include/exclude workflows across all scoping sources, and cleans up Gemini AI Access Layer configuration.

## What Changed
- **Structured `review_data_extraction` Metadata**
  - `src/main/service/rag_retrieval_service.py`: Emits document and section metadata (`filename`, `storage_uri`, `registry_storage_uri`, `status`, `excluded`, and `sections[]` with `section_id`, `section_title`, `node_id`, `status`, `excluded`) for policy sources (`policy`, `kod`, `procedure`).
  - `src/main/service/data_extraction_service.py` & `src/main/persister/gcp_bucket_persister.py`: Builds the same document/section soft-exclusion metadata schema (with `storage_uri`, `status`, `excluded`, and `sections[]`) for `gfms` (`findings_details.json`) and `historical_scoping_document` (`historical_plan.json` + PDF URIs).
  - `src/main/service/plan_data_service.py`: Respects `excluded` and `status` flags when resolving plan data.
- **Database Upsert, Audit & Vestigial Config Cleanup**
  - `src/main/util/db_connector.py`: Upserts `review_data_extraction` rows safely using an `UPDATE ... ELSE INSERT` flow keyed by `(review_scope_instance_id, data_source)`.
  - `src/main/service/action_service.py`: Guards missing `session_data` fields when building audit action records and removes duplicate `"Prompt_Version"` / vestigial sampling keys.
  - `src/main/config/settings.py`, `src/main/util/historical_plan_matcher.py`, `src/main/util/risk_driver_matcher.py`: Removed unused `GENERATION_CONFIG` and vestigial `project`/`location`/`temperature`/`top_p`/`top_k` model parameter dictionaries.
- **AI Access Layer LLM Client**
  - `src/main/util/gemini_connection.py`: Uses `ChatGoogleGenerativeAI` with `GoogleOAuthTokenProvider` (`api_key`) and `AI_ACCESS_LAYER_BASE_URL` / `GENAI_BASE_URL` (`base_url`), without Vertex `project`/`location` or disallowed sampling parameters (`temperature`, `top_p`, `top_k`).
- **Test Compatibility**
  - `src/tests/conftest.py` and expanded unit tests covering Gemini connection, DB connector, and metadata extraction.

## Why
Allows downstream agents (`scoping-summary-agent`, `walkthrough-query-agent`) and the UI to read all source paths, document titles, and section/finding IDs directly from `review_data_extraction` and toggle exclusions without deleting underlying GCS files.

## Testing & Coverage
- Command: `PYTHONPATH="src/main;src" pytest src/tests --cov=src/main --cov-report=term-missing --cov-fail-under=80`
- Result: **251 passed, 0 failed** (**84.00% statement coverage**)
