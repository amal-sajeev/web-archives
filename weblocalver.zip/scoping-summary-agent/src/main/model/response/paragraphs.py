import re
from typing import List, Literal, Optional, Union

from pydantic import BaseModel, Field, field_validator
from pydantic.json_schema import SkipJsonSchema

# "**Section 3: Title** Body..." -> heading on its own line.
_INLINE_SECTION_HEADING = re.compile(r"^(\s*\*\*Section \d+:[^*\n]*\*\*)[ \t]+(?=\S)")


def normalize_model_text(text: str) -> str:
    """Fix model formatting slips: escaped newlines written as a literal backslash-n, and a section
    heading followed by body text on the same line (the renderer then bolds the whole paragraph)."""
    text = text.replace("\\r\\n", "\n").replace("\\n", "\n")
    return _INLINE_SECTION_HEADING.sub(r"\1\n", text)


class ParagraphMetadata(BaseModel):
    """
    Metadata associated with a paragraph, indicating its role within the report structure.
    """
    is_section_start: bool = Field(
        ...,
        description="True if this paragraph is the first in a new report section, False otherwise."
    )
    section_confidence_score: Optional[int] = Field(
        None,
        ge=0,
        le=100,
        description=(
            "The confidence score (0-100%) for the entire section that this paragraph begins. "
            "This field is only populated if 'is_section_start' is True."
        )
    )
    # Set by code only; hidden from the model's JSON schema but kept in serialized reports.
    heading_level: SkipJsonSchema[Optional[int]] = Field(
        None,
        ge=1,
        le=3,
        description="Rendering level of the first line: 1 = section title, 2 = sub-section label, 3 = item.",
    )


class SupportingCitation(BaseModel):
    """Exact supporting citation metadata for a paragraph evidence reference."""

    chunk_id: str = Field(
        ...,
        description="Chunk identifier that links this citation back to the source chunk used in generation.",
    )
    citation_label: Optional[str] = Field(
        None,
        description="Optional concise display label for the citation link, such as 'Section 4.3'.",
    )
    page_number: Optional[int] = Field(
        None,
        ge=1,
        description=(
            "Exact source page number when the evidence came from a paginated document such as a PDF. "
            "Set to null for non-paginated sources."
        ),
    )
    gs_uri: Optional[str] = Field(
        None,
        description=(
            "gs:// URI for the exact source document. This is enriched by the backend from citation mapping data."
        ),
    )
    document_name: Optional[str] = Field(
        None,
        description="Resolved source document name for the citation.",
    )
    content_type: Optional[str] = Field(
        None,
        description="Resolved content type for the citation source, for example application/pdf.",
    )
    url: Optional[str] = Field(
        None,
        description="External web link (e.g. a regulatory text deep link). Enriched by the backend; not set by the model.",
    )


class NarrativeUnit(BaseModel):
    """A sentence or sentence group used as a leaf of report content."""

    content: str = Field(
        ...,
        description="One sentence or a group of sentences, typically rendered as a paragraph.",
    )
    citation_status: Literal["supported", "unsupported", "not_required"] = Field(
        ...,
        description="Whether the content is source-supported, an unsupported conclusion, or citation-free.",
    )
    supporting_chunk_ids: List[str] = Field(
        default_factory=list,
        description="Source chunk identifiers supporting this unit, when applicable.",
    )
    supporting_citations: List[SupportingCitation] = Field(
        default_factory=list,
        description="Exact source citations supporting this unit, when applicable.",
    )

    @field_validator("content")
    @classmethod
    def _normalize_content(cls, value: str) -> str:
        return normalize_model_text(value)


class ParagraphCitation(BaseModel):
    """
    Represents a single paragraph of the generated report along with its
    associated source chunk citations and generation rationale.
    """
    paragraph_id: str = Field(
        ...,
        description="A unique, sequential string identifier for this paragraph (e.g., 'para_1', 'para_2')."
    )
    content: Union[str, List[NarrativeUnit]] = Field(
        ...,
        description=(
            "The synthesized paragraph text, either as legacy text or as ordered narrative units. "
            "Each narrative unit carries its own citation status and supporting evidence."
        )
    )
    supporting_chunk_ids: List[str] = Field(
        default_factory=list,
        description=(
            "An array of unique chunk IDs from the source data that directly support the facts "
            "presented in a legacy string paragraph. New narrative-unit paragraphs should keep this empty."
        )
    )
    supporting_citations: List[SupportingCitation] = Field(
        default_factory=list,
        description=(
            "An optional array of exact evidence references. Each item identifies the supporting chunk and, "
            "when available, the exact page number for PDF-backed evidence. The backend enriches each entry "
            "with the gs:// URI and source metadata from citation mapping data."
        ),
    )
    rationale: Optional[str] = Field(
        None,
        description=(
            "A single, section-level explanation of the core reasoning behind the entire section's content. "
            "Populated ONLY on the first paragraph of a section (when 'is_section_start' is True); null otherwise. "
            "Written as one coherent paragraph covering all paragraphs of that section together. "
            "Explain the core reasoning with data: the key data points used and the analysis performed to reach "
            "the conclusions, not a restatement of the answer. Ground each selection in its source using "
            "descriptive names (e.g., scoping document, current review, past review) rather than 'citation N'. "
            "Do NOT explain, justify, or reference the confidence score — never state why the score is high or low "
            "or how data gaps affect it. "
            "Unless the section is specifically dedicated to identifying gaps, missing evidence, or open validation "
            "questions (such as Research Gap Register or Scope Validation), do NOT mention limitations, data gaps, "
            "missing/null fields, absence of information, or lack of detail; focus strictly on the core reasoning "
            "and the data that WAS used. "
            "Keep it concise: optimally 2-3 lines and no more than 3-4 lines."
        )
    )
    metadata: ParagraphMetadata = Field(
        ...,
        description="Metadata about the paragraph's role in the report's structure."
    )

    @field_validator("content")
    @classmethod
    def _normalize_content(cls, value):
        return normalize_model_text(value) if isinstance(value, str) else value


class ScopingReport(BaseModel):
    """
    The top-level schema for a structured narrative scoping report.
    """
    report_title: str = Field(
        ...,
        description="The exact report title provided in the output format instructions. Use it verbatim; do not rephrase, expand, or synthesize a new title."
    )
    paragraphs: List[ParagraphCitation] = Field(
        ...,
        description="An ordered list of paragraph objects that form the body of the report."
    )
