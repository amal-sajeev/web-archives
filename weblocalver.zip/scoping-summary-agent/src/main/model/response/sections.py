from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator

from model.response.paragraphs import NarrativeUnit, ParagraphCitation, ScopingReport


class BroadScopePartOutput(BaseModel):
    """Output of one Broad Scope source-group call; assembled into the final ScopingReport by code."""

    # Required (no defaults) so the response schema forces all three keys; with optional keys Gemini 3.x
    # can close the JSON right after `section1` and silently drop the boundaries.
    section1: List[ParagraphCitation] = Field(
        ...,
        description="Section 1: Broad Scope Direction paragraphs. Empty unless the task asks for Section 1.",
    )
    in_scope: List[ParagraphCitation] = Field(
        ...,
        description="Indicative in-scope boundary paragraphs derived from this request's data group.",
    )
    out_of_scope: List[ParagraphCitation] = Field(
        ...,
        description="Indicative out-of-scope boundary paragraphs derived from this request's data group.",
    )


class BroadScopeCollationOutput(BaseModel):
    """Collation call output: Section 2 rationale/score and Section 3."""

    section2_rationale: str = Field(
        ...,
        description="One section-level rationale covering the whole of Section 2: Indicative Scope Boundaries.",
    )
    section2_confidence_score: int = Field(
        ...,
        ge=0,
        le=100,
        description="Confidence score (0-100) for the whole of Section 2.",
    )
    section3: List[ParagraphCitation] = Field(
        ...,
        description="Section 3: Scope Validation and Walkthrough Preparation paragraphs.",
    )


class PolicySectionSummary(BaseModel):
    """Model-written summary for one retrieved policy/procedure/KOD section, matched back by key."""

    key: str = Field(..., description="Exact section key copied from the input manifest, e.g. 'POLICY|1|4.5.4'.")
    summary: str = Field(..., description="3-5 line summary of the section drawn only from its source text.")
    applicability: str = Field(
        ...,
        description="One of: Directly Applicable, Partially Applicable.",
    )
    relevance: str = Field(..., description="1-2 lines on how the section relates to the current plan and its impact on scope or testing.")


class PolicyDocumentAssessment(BaseModel):
    """Model-written assessment for one policy/procedure/KOD document, matched back by doc_key."""

    doc_key: str = Field(..., description="Exact document key copied from the input manifest, e.g. 'POLICY|1'.")
    sections: List[PolicySectionSummary] = Field(
        ...,
        description="Exactly one entry for every section key listed for this document in the input manifest.",
    )


class RegulatoryMandateSummary(BaseModel):
    key: str = Field(..., description="Exact mandate key copied from the regulatory input, e.g. 'REG|1|2'.")
    name: str = Field(..., description="Short mandate name (a few words), plain text without bold or numbering.")
    applicability: str = Field(
        ...,
        description="One of: Directly Applicable, Partially Applicable, Not Applicable.",
    )
    content: str = Field(
        ...,
        description=(
            "5-6 line description of the mandate's requirement and its impact on the plan's risks, scope and testing. "
            "Do not repeat the name, applicability, confidence score or rationale."
        ),
    )


class RegulatoryMandatesBlock(BaseModel):
    mandates: List[RegulatoryMandateSummary] = Field(
        default_factory=list,
        description="One entry per regulatory mandate, in input order.",
    )


class PolicySection1Content(BaseModel):
    intro: str = Field(..., description="3-4 line summary of the review context from the current plan data.")
    rationale: str = Field(..., description="Section-level rationale for Section 1.")
    confidence_score: int = Field(..., ge=0, le=100, description="Section-level confidence score for Section 1.")
    document_assessments: List[PolicyDocumentAssessment] = Field(
        default_factory=list,
        description="Left empty by the main policy call; filled in code from the per-source assessment calls.",
    )
    regulatory_mandates: RegulatoryMandatesBlock


class PolicyAssessmentsOutput(BaseModel):
    """Raw model output for one per-source document assessment call."""

    document_assessments: List[PolicyDocumentAssessment]


class PolicyRegulationOutput(BaseModel):
    """Raw model output for the policy section; Section 1 is assembled in code from this."""

    section1: PolicySection1Content
    report: ScopingReport = Field(..., description="Sections 2 to 5 only; Section 1 is assembled separately.")


class PastReviewEvidenceBlock(BaseModel):
    """Evidence-backed narrative units for one past-review assessment component."""

    content: List[NarrativeUnit] = Field(
        ...,
        description="Evidence-backed narrative content for this assessment component.",
    )


class PastReviewAssessment(BaseModel):
    """One required comparison area for a historical review."""

    assessed_area: str = Field(
        ...,
        description="Historical-review comparison area.",
    )
    key_observation: PastReviewEvidenceBlock = Field(
        ...,
        description="Evidence-backed observation about this historical review for the assessed area, with citation metadata.",
    )
    implication_for_current_review: PastReviewEvidenceBlock = Field(
        ...,
        description="Evidence-backed implication for the current review, with citation metadata when source content is referenced.",
    )

    @staticmethod
    def _coerce_evidence_block(value: Any, default_content: str = "") -> PastReviewEvidenceBlock:
        if isinstance(value, PastReviewEvidenceBlock):
            return value
        if isinstance(value, str):
            return PastReviewEvidenceBlock(content=[NarrativeUnit(
                content=value,
                citation_status="not_required",
            )])
        if isinstance(value, dict):
            content = value.get("content") or value.get("text") or default_content
            if isinstance(content, str):
                citations = value.get("supporting_citations") or []
                chunk_ids = value.get("supporting_chunk_ids") or []
                content = [NarrativeUnit(
                    content=content,
                    citation_status="supported" if citations or chunk_ids else "not_required",
                    supporting_chunk_ids=chunk_ids,
                    supporting_citations=citations,
                )]
            return PastReviewEvidenceBlock(
                content=content,
            )
        raise TypeError("Evidence block must be a string or object.")

    @model_validator(mode="before")
    @classmethod
    def normalize_legacy_assessment(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        normalized = dict(data)
        normalized.pop("supporting_chunk_ids", None)
        if "key_observation" in normalized:
            normalized["key_observation"] = cls._coerce_evidence_block(
                normalized["key_observation"],
                default_content=str(normalized.get("key_observation") or ""),
            )
        if "implication_for_current_review" in normalized:
            normalized["implication_for_current_review"] = cls._coerce_evidence_block(
                normalized["implication_for_current_review"],
                default_content=str(normalized.get("implication_for_current_review") or ""),
            )
        return normalized


class HistoricalReviewComparison(BaseModel):
    """Six-area comparison of one historical review against the current review."""

    historical_review_id: str = Field(..., description="Plan or review identifier for the historical review.")
    review_title: Optional[str] = Field(None, description="Historical review title when provided in the evidence.")
    assessments: List[PastReviewAssessment] = Field(
        ...,
        description="Historical-review comparison assessments.",
    )


class PastReviewIntelligenceReport(BaseModel):
    """Structured historical-review comparisons used to render the intelligence table."""

    report_title: str = Field(..., description="Exact report title: Past Review Analysis")
    current_review_id: str = Field(..., description="Identifier of the current review being scoped.")
    similar_review_count: int = Field(..., description="Number of similar historical reviews identified.")
    historical_reviews: List[HistoricalReviewComparison] = Field(
        ...,
        description="Independent comparison of every available historical review against the current review.",
    )


AnalysisReportSection = Union[ScopingReport, PastReviewIntelligenceReport]


class PreliminaryResearchDocument(BaseModel):
    """Persisted preliminary research payload for a plan."""

    plan_number: str = Field(
        ...,
        description="Plan number associated with the preliminary research output.",
    )
    analysis_report: Dict[str, AnalysisReportSection] = Field(
        ...,
        description="Structured analytics report generated by the summary agent.",
    )

    @field_validator("analysis_report", mode="before")
    @classmethod
    def validate_analysis_report(cls, value: Any) -> Dict[str, Any]:
        """Ensure every report section is a JSON object rather than string text."""
        if not isinstance(value, dict):
            raise TypeError("analysis_report must be a dictionary.")

        normalized_report: Dict[str, Any] = {}
        for section_name, section_value in value.items():
            if isinstance(section_value, BaseModel):
                section_value = section_value.model_dump()
            if not isinstance(section_value, dict):
                raise TypeError(
                    f"analysis_report section '{section_name}' must be a dictionary."
                )
            normalized_report[section_name] = section_value

        return normalized_report
