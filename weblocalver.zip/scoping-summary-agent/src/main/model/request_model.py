from typing import Any, Dict, List, Literal, Optional, Union
from model.response_model import AnalysisReportSection
from pydantic import AliasChoices, BaseModel, ConfigDict, Field

SectionKey = Literal["past_review", "policy_regulation", "broad_scope"]

class UserRequest(BaseModel):
    review_scope_instance_id: Optional[str] = Field(None)
    user: Optional[str] = Field(None, max_length=100)
    remarks: Optional[str] = Field(None, max_length=500)

class AnalyticsRequest(BaseModel):
    planNumber: str = Field(..., description="The plan number to analyze.")
    userDetails: UserRequest = Field(..., description="User details for the request.")
    sections: Optional[List[SectionKey]] = Field(
        None,
        description=(
            "Sections to regenerate. Omit or leave empty to regenerate all sections; "
            "remaining sections are taken from the latest stored preliminary research document."
        ),
    )

class GetDocumentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    planNumber: Optional[str] = Field(
        None,
        description="Plan number. Required when requesting by chunk_id.",
    )
    chunk_id: Optional[str] = Field(
        None,
        description="Chunk identifier used to resolve citations from a plan mapping.",
    )
    document_uri: Optional[str] = Field(
        None,
        description="Direct gs:// document URI. When provided, document is fetched directly.",
    )
    page_number: Optional[int] = Field(
        None,
        alias="pageNumber",
        ge=1,
        description="Optional page number for direct document fetches or page-aware viewers.",
    )


class GetPreliminaryResearchRequest(BaseModel):
    planNumber: str = Field(
        ...,
        description="Plan number for retrieving the preliminary research document.",
    )


class EditPreliminaryResearchRequest(BaseModel):
    userDetails: UserRequest = Field(..., description="User details for the request.")
    model_config = ConfigDict(populate_by_name=True)

    plan_number: str = Field(
        ...,
        alias="planNumber",
        description="Plan number for updating the preliminary research document.",
    )
    analysis_report: Dict[str, AnalysisReportSection] = Field(
        ...,
        description="Updated analytics report to persist for the plan.",
    )


class DownloadResearchWalkthroughRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    plan_number: str = Field(
        ...,
        alias="planNumber",
        description="Plan number for generating the walkthrough PDF.",
    )
    plan_name: Optional[str] = Field(
        None,
        alias="planName",
        description="Optional plan display name used in PDF metadata.",
    )
    analysis_report: Optional[Dict[str, Any]] = Field(
        None,
        alias="analysisReport",
        description="(Deprecated) Research walkthrough analysis payload. Now fetched from blob storage.",
    )


class ListAllPlanItemsRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    plan_number: str = Field(
        ...,
        alias="planNumber",
        description="Plan number used to read historical plan details from GCS.",
    )


class HistoricalPlanItem(BaseModel):
    """One historical review: used as the /list-documents response item and the /delete-document request item.

    Also accepts the raw historical_plan_details keys ("Plan Item Number" / "Plan Item Title") on input.
    """

    model_config = ConfigDict(populate_by_name=True)

    plan_item_number: Union[int, str] = Field(
        ...,
        validation_alias=AliasChoices("plan_item_number", "Plan Item Number"),
        description="Plan Item Number of the historical review.",
    )
    plan_item_title: Optional[str] = Field(
        None,
        validation_alias=AliasChoices("plan_item_title", "Plan Item Title"),
        description="Plan Item Title of the historical review.",
    )


class DeleteHistoricalPlanItemRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, coerce_numbers_to_str=True)

    plan_number: str = Field(
        ...,
        alias="planNumber",
        description="Plan number used to locate historical_plan_details.json in GCS.",
    )
    plan_items: List[HistoricalPlanItem] = Field(
        ...,
        min_length=1,
        alias="planItems",
        description="Historical reviews to delete, in the same shape as the /list-documents output.",
    )


class DeleteHistoricalPlanItemResponse(BaseModel):
    plan_number: str
    deleted_count: int
    remaining_count: int
    deleted: List[HistoricalPlanItem] = Field(
        ...,
        description="Deleted historical reviews, in the same shape as the /list-documents output.",
    )
