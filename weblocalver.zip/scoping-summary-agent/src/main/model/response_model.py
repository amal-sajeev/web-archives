from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic.json_schema import SkipJsonSchema



class ParagraphMetadata(BaseModel):
    """
    Metadata associated with a paragraph, indicating its role within the report structure.
    """
    is_section_start: bool = Field(
        ...,
        description="True if this paragraph is the first in a new report section, False otherwise."
    )
    section_confidence_score: Optional[int] = Field(
        None,
        ge=0,
        le=100,
        description=(
            "The confidence score (0-100%) for the entire section that this paragraph begins. "
            "This field is only populated if 'is_section_start' is True."
        )
    )
    # Set by code only; hidden from the model's JSON schema but kept in serialized reports.
    heading_level: SkipJsonSchema[Optional[int]] = Field(
        None,
        ge=1,
        le=3,
        description="Rendering level of the first line: 1 = section title, 2 = sub-section label, 3 = item.",
    )


class SupportingCitation(BaseModel):
    """Exact supporting citation metadata for a paragraph evidence reference."""

    chunk_id: str = Field(
        ...,
        description="Chunk identifier that links this citation back to the source chunk used in generation.",
    )
    citation_label: Optional[str] = Field(
        None,
        description="Optional concise display label for the citation link, such as 'Section 4.3'.",
    )
    page_number: Optional[int] = Field(
        None,
        ge=1,
        description=(
            "Exact source page number when the evidence came from a paginated document such as a PDF. "
            "Set to null for non-paginated sources."
        ),
    )
    gs_uri: Optional[str] = Field(
        None,
        description=(
            "gs:// URI for the exact source document. This is enriched by the backend from citation mapping data."
        ),
    )
    document_name: Optional[str] = Field(
        None,
        description="Resolved source document name for the citation.",
    )
    content_type: Optional[str] = Field(
        None,
        description="Resolved content type for the citation source, for example application/pdf.",
    )
    url: Optional[str] = Field(
        None,
        description="External web link (e.g. a regulatory text deep link). Enriched by the backend; not set by the model.",
    )


class NarrativeUnit(BaseModel):
    """A sentence or sentence group used as a leaf of report content."""

    content: str = Field(
        ...,
        description="One sentence or a group of sentences, typically rendered as a paragraph.",
    )
    citation_status: Literal["supported", "unsupported", "not_required"] = Field(
        ...,
        description="Whether the content is source-supported, an unsupported conclusion, or citation-free.",
    )
    supporting_chunk_ids: List[str] = Field(
        default_factory=list,
        description="Source chunk identifiers supporting this unit, when applicable.",
    )
    supporting_citations: List[SupportingCitation] = Field(
        default_factory=list,
        description="Exact source citations supporting this unit, when applicable.",
    )


class ParagraphCitation(BaseModel):
    """
    Represents a single paragraph of the generated report along with its 
    associated source chunk citations and generation rationale.
    """
    paragraph_id: str = Field(
        ..., 
        description="A unique, sequential string identifier for this paragraph (e.g., 'para_1', 'para_2')."
    )
    content: Union[str, List[NarrativeUnit]] = Field(
        ..., 
        description=(
            "The synthesized paragraph text, either as legacy text or as ordered narrative units. "
            "Each narrative unit carries its own citation status and supporting evidence."
        )
    )
    supporting_chunk_ids: List[str] = Field(
        default_factory=list,
        description=(
            "An array of unique chunk IDs from the source data that directly support the facts "
            "presented in a legacy string paragraph. New narrative-unit paragraphs should keep this empty."
        )
    )
    supporting_citations: List[SupportingCitation] = Field(
        default_factory=list,
        description=(
            "An optional array of exact evidence references. Each item identifies the supporting chunk and, "
            "when available, the exact page number for PDF-backed evidence. The backend enriches each entry "
            "with the gs:// URI and source metadata from citation mapping data."
        ),
    )
    rationale: Optional[str] = Field(
        None,
        description=(
            "A single, section-level explanation of the core reasoning behind the entire section's content. "
            "Populated ONLY on the first paragraph of a section (when 'is_section_start' is True); null otherwise. "
            "Written as one coherent paragraph covering all paragraphs of that section together. "
            "Explain the core reasoning with data: the key data points used and the analysis performed to reach "
            "the conclusions, not a restatement of the answer. Ground each selection in its source using "
            "descriptive names (e.g., scoping document, current review, past review) rather than 'citation N'. "
            "Do NOT explain, justify, or reference the confidence score — never state why the score is high or low "
            "or how data gaps affect it. "
            "Unless the section is specifically dedicated to identifying gaps, missing evidence, or open validation "
            "questions (such as Research Gap Register or Scope Validation), do NOT mention limitations, data gaps, "
            "missing/null fields, absence of information, or lack of detail; focus strictly on the core reasoning "
            "and the data that WAS used. "
            "Keep it concise: optimally 2-3 lines and no more than 3-4 lines."
        )
    )
    metadata: ParagraphMetadata = Field(
        ...,
        description="Metadata about the paragraph's role in the report's structure."
    )

class ScopingReport(BaseModel):
    """
    The top-level schema for a structured narrative scoping report.
    """
    report_title: str = Field(
        ..., 
        description="The exact report title provided in the output format instructions. Use it verbatim; do not rephrase, expand, or synthesize a new title."
    )
    paragraphs: List[ParagraphCitation] = Field(
        ..., 
        description="An ordered list of paragraph objects that form the body of the report."
    )


class BroadScopePartOutput(BaseModel):
    """Output of one Broad Scope source-group call; assembled into the final ScopingReport by code."""

    section1: List[ParagraphCitation] = Field(
        default_factory=list,
        description="Section 1: Broad Scope Direction paragraphs. Empty unless the task asks for Section 1.",
    )
    in_scope: List[ParagraphCitation] = Field(
        default_factory=list,
        description="Indicative in-scope boundary paragraphs derived from this request's data group.",
    )
    out_of_scope: List[ParagraphCitation] = Field(
        default_factory=list,
        description="Indicative out-of-scope boundary paragraphs derived from this request's data group.",
    )


class BroadScopeCollationOutput(BaseModel):
    """Collation call output: Section 2 rationale/score and Section 3."""

    section2_rationale: str = Field(
        ...,
        description="One section-level rationale covering the whole of Section 2: Indicative Scope Boundaries.",
    )
    section2_confidence_score: int = Field(
        ...,
        ge=0,
        le=100,
        description="Confidence score (0-100) for the whole of Section 2.",
    )
    section3: List[ParagraphCitation] = Field(
        ...,
        description="Section 3: Scope Validation and Walkthrough Preparation paragraphs.",
    )


class PolicySectionSummary(BaseModel):
    """Model-written summary for one retrieved policy/procedure/KOD section, matched back by key."""

    key: str = Field(..., description="Exact section key copied from the input manifest, e.g. 'POLICY|1|4.5.4'.")
    summary: str = Field(..., description="3-5 line summary of the section drawn only from its source text.")
    applicability: str = Field(
        ...,
        description="One of: Directly Applicable, Partially Applicable.",
    )
    relevance: str = Field(..., description="1-2 lines on how the section relates to the current plan and its impact on scope or testing.")


class PolicyDocumentAssessment(BaseModel):
    """Model-written assessment for one policy/procedure/KOD document, matched back by doc_key."""

    doc_key: str = Field(..., description="Exact document key copied from the input manifest, e.g. 'POLICY|1'.")
    sections: List[PolicySectionSummary] = Field(
        ...,
        description="Exactly one entry for every section key listed for this document in the input manifest.",
    )


class RegulatoryMandateSummary(BaseModel):
    key: str = Field(..., description="Exact mandate key copied from the regulatory input, e.g. 'REG|1|2'.")
    name: str = Field(..., description="Short mandate name (a few words), plain text without bold or numbering.")
    applicability: str = Field(
        ...,
        description="One of: Directly Applicable, Partially Applicable, Not Applicable.",
    )
    content: str = Field(
        ...,
        description=(
            "5-6 line description of the mandate's requirement and its impact on the plan's risks, scope and testing. "
            "Do not repeat the name, applicability, confidence score or rationale."
        ),
    )


class RegulatoryMandatesBlock(BaseModel):
    mandates: List[RegulatoryMandateSummary] = Field(
        default_factory=list,
        description="One entry per regulatory mandate, in input order.",
    )


class PolicySection1Content(BaseModel):
    intro: str = Field(..., description="3-4 line summary of the review context from the current plan data.")
    rationale: str = Field(..., description="Section-level rationale for Section 1.")
    confidence_score: int = Field(..., ge=0, le=100, description="Section-level confidence score for Section 1.")
    document_assessments: List[PolicyDocumentAssessment] = Field(
        default_factory=list,
        description="Left empty by the main policy call; filled in code from the per-source assessment calls.",
    )
    regulatory_mandates: RegulatoryMandatesBlock


class PolicyAssessmentsOutput(BaseModel):
    """Raw model output for one per-source document assessment call."""

    document_assessments: List[PolicyDocumentAssessment]


class PolicyRegulationOutput(BaseModel):
    """Raw model output for the policy section; Section 1 is assembled in code from this."""

    section1: PolicySection1Content
    report: ScopingReport = Field(..., description="Sections 2 to 5 only; Section 1 is assembled separately.")


class PastReviewEvidenceBlock(BaseModel):
    """Evidence-backed narrative units for one past-review assessment component."""

    content: List[NarrativeUnit] = Field(
        ...,
        description="Evidence-backed narrative content for this assessment component.",
    )


class PastReviewAssessment(BaseModel):
    """One required comparison area for a historical review."""

    assessed_area: str = Field(
        ...,
        description="Historical-review comparison area.",
    )
    key_observation: PastReviewEvidenceBlock = Field(
        ...,
        description="Evidence-backed observation about this historical review for the assessed area, with citation metadata.",
    )
    implication_for_current_review: PastReviewEvidenceBlock = Field(
        ...,
        description="Evidence-backed implication for the current review, with citation metadata when source content is referenced.",
    )

    @staticmethod
    def _coerce_evidence_block(value: Any, default_content: str = "") -> PastReviewEvidenceBlock:
        if isinstance(value, PastReviewEvidenceBlock):
            return value
        if isinstance(value, str):
            return PastReviewEvidenceBlock(content=[NarrativeUnit(
                content=value,
                citation_status="not_required",
            )])
        if isinstance(value, dict):
            content = value.get("content") or value.get("text") or default_content
            if isinstance(content, str):
                citations = value.get("supporting_citations") or []
                chunk_ids = value.get("supporting_chunk_ids") or []
                content = [NarrativeUnit(
                    content=content,
                    citation_status="supported" if citations or chunk_ids else "not_required",
                    supporting_chunk_ids=chunk_ids,
                    supporting_citations=citations,
                )]
            return PastReviewEvidenceBlock(
                content=content,
            )
        raise TypeError("Evidence block must be a string or object.")

    @model_validator(mode="before")
    @classmethod
    def normalize_legacy_assessment(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        normalized = dict(data)
        normalized.pop("supporting_chunk_ids", None)
        if "key_observation" in normalized:
            normalized["key_observation"] = cls._coerce_evidence_block(
                normalized["key_observation"],
                default_content=str(normalized.get("key_observation") or ""),
            )
        if "implication_for_current_review" in normalized:
            normalized["implication_for_current_review"] = cls._coerce_evidence_block(
                normalized["implication_for_current_review"],
                default_content=str(normalized.get("implication_for_current_review") or ""),
            )
        return normalized


class HistoricalReviewComparison(BaseModel):
    """Six-area comparison of one historical review against the current review."""

    historical_review_id: str = Field(..., description="Plan or review identifier for the historical review.")
    review_title: Optional[str] = Field(None, description="Historical review title when provided in the evidence.")
    assessments: List[PastReviewAssessment] = Field(
        ...,
        description="Historical-review comparison assessments.",
    )


class PastReviewIntelligenceReport(BaseModel):
    """Structured historical-review comparisons used to render the intelligence table."""

    report_title: str = Field(..., description="Exact report title: Past Review Analysis")
    current_review_id: str = Field(..., description="Identifier of the current review being scoped.")
    similar_review_count: int = Field(..., description="Number of similar historical reviews identified.")
    historical_reviews: List[HistoricalReviewComparison] = Field(
        ...,
        description="Independent comparison of every available historical review against the current review.",
    )


AnalysisReportSection = Union[ScopingReport, PastReviewIntelligenceReport]


class PreliminaryResearchDocument(BaseModel):
    """Persisted preliminary research payload for a plan."""

    plan_number: str = Field(
        ...,
        description="Plan number associated with the preliminary research output.",
    )
    analysis_report: Dict[str, AnalysisReportSection] = Field(
        ...,
        description="Structured analytics report generated by the summary agent.",
    )

    @field_validator("analysis_report", mode="before")
    @classmethod
    def validate_analysis_report(cls, value: Any) -> Dict[str, Any]:
        """Ensure every report section is a JSON object rather than string text."""
        if not isinstance(value, dict):
            raise TypeError("analysis_report must be a dictionary.")

        normalized_report: Dict[str, Any] = {}
        for section_name, section_value in value.items():
            if isinstance(section_value, BaseModel):
                section_value = section_value.model_dump()
            if not isinstance(section_value, dict):
                raise TypeError(
                    f"analysis_report section '{section_name}' must be a dictionary."
                )
            normalized_report[section_name] = section_value

        return normalized_report
