OUTPUT_FORMAT_INSTRUCTIONS_PROMPT = """
Your entire response MUST be a single, valid JSON object. Do not include any text, explanations, or markdown formatting before or after the JSON structure.

Strictly adhere to the following JSON schema:

{{
  "report_title": "{title}",
  "paragraphs": [
    {{
      "paragraph_id": "A unique, sequential string identifier for this paragraph, for example 'para_1', 'para_2', etc.",
      "content": [
        {{
          "content": "One sentence or tightly connected sentence group sharing evidence and citation status.",
          "citation_status": "supported",
          "supporting_chunk_ids": ["Exact source chunk IDs used for this narrative unit"],
          "supporting_citations": [
            {{
              "chunk_id": "Exact supporting chunk ID",
              "page_number": "Exact page number for paginated evidence, or null"
            }}
          ]
        }}
      ],
      "rationale": "A single, section-level explanation of the reasoning behind the entire section's content. Provide this ONLY when 'is_section_start' is true (i.e., on the first paragraph of the section); otherwise set it to null. It must be written by following the 'RATIONALE GENERATION INSTRUCTIONS' and 'RATIONALE OUTPUT STRUCTURE' below, covering all paragraphs that belong to this section as one coherent explanation.",
      "metadata": {{
        "is_section_start": "A boolean value. Set to true if this paragraph begins a new section of the report (e.g., 'Section 1: ...'), and false if it is a continuation of the previous paragraph's section.",
        "section_confidence_score": "An integer between 0 and 100. Provide this ONLY when 'is_section_start' is true; otherwise set it to null. The score reflects the Evidence Sufficiency and Response Completeness for the entire section, and MUST be consistent with the Gaps identified in the 'report' (more or larger gaps => lower score).
         **Evidence Sufficiency and Response Completeness** : measure how relevant and complete the provided source chunks are, and how fully the section response meets the user prompt requirements. Treat data marked as missing or not available as a gap only when it is essential to required section conclusions. Do not lower confidence just because some plans naturally lack certain fields; base the score on the quality and sufficiency of the evidence available for that specific review.
         **Score Scale:**
            *   **80 - 100:** Evidence is highly relevant and complete; the section fully meets the requirements with no material gaps.
            *   **60 - 79:** Evidence is largely sufficient; only minor gaps that do not affect key conclusions.
            *   **40 - 59:** Partial evidence; notable gaps or missing fields affect some conclusions.
            *   **20 - 39:** Weak evidence; major gaps, with several required fields Data Not Available.
            *   **0 - 19:** Little to no usable evidence for this section.
        "
      }}
    }}
  ]
}}

## KEY RULES FOR COMPLIANCE:

1.  **JSON Format is Mandatory:** The final output must be a raw JSON object and nothing else.
2.  **Paragraph Coherence:** Ensure the `content` of each paragraph flows logically into the next, forming a single, cohesive report.
3.  **Traceability is Critical:** Each source-supported narrative unit must be traceable to one or more exact `chunk_id`s in that unit's `supporting_chunk_ids`. Keep citations on the unit they support; do not put citations only at paragraph level. Use `citation_status: "unsupported"` and empty citation arrays for analytical conclusions that are not directly stated in sources. Use `not_required` only for content that does not require source evidence.
4.  **Exact PDF Citations:** Whenever a narrative unit uses evidence from an attached PDF or another paginated document, populate that unit's `supporting_citations` with the exact `chunk_id` and exact `page_number` used for that unit. For non-paginated sources, set `page_number` to null.
5.  **Explain Your Reasoning:** The `rationale` field is section-level, not paragraph-level. Provide a single `rationale` ONLY on the first paragraph of each section (where `is_section_start` is `true`), covering all paragraphs in that section as one coherent explanation. For every other paragraph, set `rationale` to null.
6.  **Section Metadata:** For each paragraph, you must populate the `metadata` object. Set `is_section_start` to `true` only for the first paragraph of each new section. When `is_section_start` is `true`, you MUST provide a `section_confidence_score` (0-100) that reflects the Evidence Sufficiency and Response Completeness for that entire section and is consistent with the Gaps identified in the `rationale`. When `is_section_start` is `false`, set `section_confidence_score` to null.
7. Bold formatting is restricted to SECTION TITLES and SUB-SECTION TITLES/HEADINGS, following the instructions for the particular section. A bold title is always followed by a newline before any body text.

## RATIONALE GENERATION INSTRUCTIONS:

Generate the `rationale` section-wise: exactly ONE rationale per section, placed only on the paragraph where `is_section_start` is `true`, covering all paragraphs of that section together. The goal is to explain the core logic used to generate that section of the report — the important data points used and the analysis performed — not to re-explain the answer.

Core Principles for Writing the Rationale
1.  **STRICT ADHERENCE TO EVIDENCE:** Rely only on the provided data and evidence. Do not assume or extrapolate anything.
2.  **CORE REASONING WITH DATA:** Present the key data points and the analysis/reasoning done on them. Do not narrate or restate the answer; explain the underlying logic that led to it.
3.  **QUALITY OVER QUANTITY:** Focus only on the most critical objectives of the section; prioritize deep, high-impact reasoning over a high volume of weak associations.
4.  **COVER THE CORE OF THE REASONING:** Within the single paragraph, convey:
        1. State the key finding (the "what").
        2. Justify why that is the conclusion.
        3. Explain how it was identified (from which source/analysis).
        4. Give the reasoning behind any derived or secondary elements.
        5. Ground every selection in its source (e.g., "because it is present in the scoping document / current review / past review").

## RATIONALE OUTPUT STRUCTURE:

The generated `rationale` MUST follow these output rules:
1.  **SECTION-LEVEL, SINGLE PARAGRAPH:** Generate exactly one rationale for the whole section, written as a single coherent paragraph. Do NOT write a separate rationale per paragraph, and do NOT use bullet points, numbered lists, or headers.
2.  **SHORT AND OPTIMAL LENGTH:** Keep the rationale short — optimally 2-3 lines, and no more than 3-4 lines.
3.  **COVER THE FULL SECTION:** The rationale must explain the reasoning across all paragraphs belonging to the section as one unified explanation.
4.  **DO NOT START WITH "This paragraph":** Never begin the rationale with phrases like "This paragraph" or "This Section". Describe the reasoning directly.
5.  **NAME SOURCES DESCRIPTIVELY:** Do NOT refer to sources as "citation 1", "chunk 2", etc. Instead use their descriptive names such as "scoping document", "current review", or "past review".
6. **NO CONFIDENCE SCORE EXPLANATION IN RATIONALE:** Do NOT explain, justify, or reference the confidence score in the rationale — never state why the score is high or low, nor mention how data gaps raise or lower confidence. The rationale must only explain the core reasoning behind the section's content. For example, do NOT write lines like "The lower confidence score reflects the significant data gaps..." or "The data gaps and confidence note are based on missing fields...".
7. **NO LIMITATIONS OR DATA GAPS IN RATIONALE:** Do NOT mention limitations, data gaps, missing/null fields, absence of information, or lack of detail anywhere in the rationale. The rationale must focus strictly on the core reasoning and the data that WAS used to reach the section's conclusions. For example, do NOT write lines like "The limitation regarding the 2024 review is noted due to the absence of detailed data...", "The section highlights the significant lack of detailed coverage information...", or "The absence of this information for the 2024 review is noted as a data gap.".
## GOLD STANDARD EXAMPLES (from Past Review Analysis):

Section 1 example:
"The past review titled "2025 Swap Dealer (CFTC)" (Plan Item 20090) closely matches the current review (Plan Item 20587), and its scoping document offers a high-quality precedent for the current review's objectives, most notably in its treatment of Key Control IRC-CD-1000141. An additional title match was identified in Plan Item 4437, further reinforcing the relevance of prior Swap Dealer coverage to the current scope."

Section 3 example:
"The scope focus is identified as "Client Classification Monitoring" because the 2025 Swap Dealer scoping document explicitly names it as the review's objective, assessing the control's design and operating effectiveness. The testing approach is drawn from the same document, which sets out a DE path and an OE path. These were selected because they appear as the explicit documented methodology in the prior review's scoping evidence."

"""
