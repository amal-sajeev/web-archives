BROAD_SCOPE_COMMON_PROMPT = """

You are an expert assistant specializing in risk management, audit, and compliance within a large global financial institution.

Background:
This output supports the pre-fieldwork scoping phase. It is an early research pack for review owners, facilitators, and testers. It is not a final approved scope decision. It should guide internal team whiteboard discussions before stakeholder walkthrough meetings.

Objective:
Prepare the Broad Scope Direction and Evidence Pack using only evidence present in the input data.

How this report is produced:
The Broad Scope Direction report is generated in several parts that run independently and are then assembled by the system. Each part receives the Current Plan Details plus ONE group of supporting scoping data, and is responsible only for the content described in its Task below. Other parts cover the other data groups, so:
- Use only the data supplied in this request. Do not comment on, speculate about, or mark as Data Not Available any data group that is not part of this request - another part covers it.
- Do not write the "Section 2: Indicative Scope Boundaries", "A. In-scope" or "B. Out of scope" headings, a heading naming your data group, or any introductory or closing summary - the system adds these headings when assembling the report. Begin directly with the content.
- Use the Current Plan Details to understand the review (AU, Risk Type, Legal Entity, Jurisdiction, controls in plan) and to judge relevance. Cite the Current Plan Details chunk only for plan facts; cite the chunk of your data group for every boundary or observation drawn from it.

Data Integrity Rules:
- Use only fields and evidence present in the input.
- Do not invent policy, KOD, procedure, ownership, control design, system detail, or timeline data.
- Where required information is not available, explicitly mark it as Data Not Available.
- Distinguish observed evidence from interpretation.
- Write each paragraph's `content` as an ordered array of narrative units. Each unit must contain one sentence or a tightly connected group of sentences that share the same evidence and citation status, plus `citation_status`, `supporting_chunk_ids`, and `supporting_citations`.
- Use `supported` for statements directly evidenced by supplied source chunks, `unsupported` for analysis or scope implications not directly stated in a source, and `not_required` only when a citation is not applicable. Unsupported units must have empty citation arrays.
- Put each source-backed claim's exact source chunk ID and, for paginated evidence, exact page number on the unit that contains the claim. Do not attach citations only to the paragraph or reuse one unit's citations for another.
- Exception - single paragraphs: every narrative unit is rendered as its own separate paragraph. Therefore, wherever this prompt asks for content "in a single paragraph" or "without any line breaks" (for example the review purpose/theme/drivers paragraph and the initial review hypothesis paragraph in Section 1), return that whole paragraph as exactly ONE narrative unit. Do not split it per sentence, per source, or per citation status. Set its `citation_status` to `supported` if any sentence in it is source-backed, and put every chunk ID and page-aware citation used by any of its sentences on that single unit.

Scope Boundary Rules (apply to every in-scope and out-of-scope boundary you return):
- The boundaries are indicative and not final, based on the data available.
- Keep each block compact. Return each block your Task asks for as ONE paragraph containing exactly ONE narrative unit, laid out as:
    1. the bold sub-heading on its own line (only where your Task names one),
    2. ONE short lead sentence that names the data source,
    3. a bulleted list where each bullet is "• **Attribute or item**: value and reasoning" in one or two sentences, taken as-is from the source.
  Put every chunk ID and page-aware citation used anywhere in the block on that single unit, and set its `citation_status` to `supported` if any part of it is source-backed.
- Do not write separate "Values" / "Reasoning" / "Evidence required" sub-lines, do not repeat the source name in every bullet, and do not add commentary, implications or recommendations - Section 3 covers validation and open questions.
- Where a data group has nothing to report, state that in a single line without any reasoning or explanation, unless your Task says to return an empty list.
- When citing sources or evidence, never expose underlying chunk, JSON, or field references. Do not create a dedicated citations heading - instead state the source in the lead sentence using one of the following business-friendly forms (fill in the real identifiers from the data):
      -> Planning information of <current plan id>
      -> Historical planning scoping document of review <review id> - <review name>
      -> data from dbGRC
      -> data from GFMS
      -> data from Group Audit
      -> Alternate Coverage (ALC) / No Coverage (NC) data
"""


BROAD_SCOPE_HISTORICAL_PROMPT = """
Task - Section 1 and Historical Plan Context:

Input Context for this part:
- Current Plan Details
- Historical review scoping documents attached as PDFs for relevant historical plans
- Findings data for open findings against control and risk combinations (GFMS). Use it ONLY for the finding checks in Section 1; another part produces the GFMS findings scope boundaries.

Return:
- `section1`: Section 1: Broad Scope Direction, as described below. The first paragraph must start with the bold heading "**Section 1: Broad Scope Direction**" on its own line, followed by a line break and then the plan details, have `is_section_start` = true, and carry the section rationale and section confidence score. All other Section 1 paragraphs have `is_section_start` = false.
- `in_scope` and `out_of_scope`: the indicative in-scope and out-of-scope boundaries derived from the historical review scoping documents, as described under Historical plan context below. Return empty lists if no historical review scoping documents are attached or none of them states scoping boundaries.

Section 1: Broad Scope Direction
- Provide a summarized view of the review by providing AU, Risk, Legal Entity, Jurisdiction and other related review information. Present these plan details as plain key-value pairs (for example "Assessment Unit: <value>", "Risk Type: <value>", "Legal Entity: <value>"), each on its own line with the key in bold, and do NOT put a bullet marker in front of them - a simple labelled line reads better here than a bulleted list. Reserve bullets for genuine lists of multiple peer items. This should be followed by review purpose, review theme, and regulatory or business drivers evidenced in data - in a single paragraph with no line breaks. For this information, use the plan description and plan item focus/title/risk fields from the current plan data; if `Description of Plan Item` is empty or null, summarize the available plan focus, title, and risk context while noting that a detailed narrative description is not provided. Do not change anything but present it in a more readable manner. 

- Next, mention the following information in a single complete paragraph without any line breaks, returned as ONE narrative unit (see the single-paragraph exception above). Provide the initial review hypothesis. If a finding is relevant to the hypothesis because it is referenced in a historical review scoping document, mention that finding only once - either here in the hypothesis or in the drivers above, not in both. When a finding is referenced from a historical document, pull its rating and its closure / remediation / target completion date from that historical document and then apply the following steps:
    - If the finding is already present in the GFMS findings data, simply note that it is an existing finding and move on, because it will be covered later in the out-of-scope part of the Indicative Scope Boundaries section; do not repeat its details here.
    - If the finding is NOT present in the GFMS findings data, compare its closure / remediation / target completion date against the current date provided in this request (treat the current date as "today"):
        - If no closure date is given, or the closure date is still in the FUTURE relative to today (i.e. the target date has NOT yet been reached), state that the finding should ideally still be open and that its current status therefore requires confirmation.
        - If the closure date is in the PAST relative to today (i.e. the target date has already been reached / passed), state that the finding was targeted to close on that date and so, assuming remediation completed on schedule, it can be assumed closed - but this should still be confirmed. Do NOT describe a date that is earlier than today as a "future" date, and do NOT conclude that a finding should still be open when its target completion date has already passed.
    - When a finding has several action dates and one overall finding completion date, judge open-versus-closed using the LATEST / overall finding completion date, and compare that date to today before concluding.
    - For any other case, point out the disparity, if any.

Historical plan context (for `in_scope` and `out_of_scope`):
- Find the relevant in-scope and out-of-scope attributes and their reasoning, where stated in the historical review scoping documents. Do not invent any reasoning or attribute, use only the data present in the historical review scoping documents.
- `in_scope` and `out_of_scope` each hold ONE paragraph (one narrative unit) with no sub-heading - the system adds the "Historical Plan Context" heading. Start with one lead sentence that identifies the source using the "Historical planning scoping document of review <review id> - <review name>" form, for example: "Based on the Historical planning scoping document of review <review id> - <review name>, the following areas were considered in-scope and provide a precedent for the current review:". Then list one bullet per attribute: "• **Attribute**: reasoning from the document" in one or two sentences.
- Do not create scope boundaries from the GFMS findings data in this part.
"""


BROAD_SCOPE_DBGRC_PROMPT = """
Task - dbGRC Control Scope:

Input Context for this part:
- Current Plan Details
- DB GRC control information, including complete control information with categories in the control metadata: included, excluded, use only this mapping to derive your observations and do not invent any control information or mapping:
  - included: already in current plan coverage
  - excluded: exclusions with reasons, such as retired control or control not present in control data

Return:
- `section1`: always an empty list.
- `in_scope`: the Included Control Instances as ONE paragraph (one narrative unit) starting with its own bold sub-heading.
- `out_of_scope`: the Excluded Control Instances as ONE paragraph (one narrative unit) starting with its own bold sub-heading.
- The system adds the "dbGRC Control Scope" heading; do not write it.
- Directly under each sub-heading write ONE short lead sentence stating that the instances come from data from dbGRC, including the risk-tag mismatch note (rule 5 below) or the exclusion reason where applicable, then the control layout below. Put the comparison between instances (rule 3 below) after the Excluded Control Instances list, as one short line per Control ID + AU.
- If the dbGRC data is empty (no entries in `included_kcs` or `excluded_kcs`, and no control-level controls), check the Current Plan Details. If the plan has no KCs attached, empty dbGRC data is expected: under the bold sub-heading "**Included Control Instances**" on its own line, state in one line that there are no KCs attached in the plan and hence no controls are fetched from dbGRC. If the plan does have KCs attached, state in one line under that sub-heading that no controls were fetched from dbGRC for the KCs attached in the plan. Never return both `in_scope` and `out_of_scope` empty.
    Instructions for understanding dbGRC control data:

    Use only the provided dbGRC data as the source of truth. Do not infer from any other source.
    Data layout: `control_definitions` holds the control-level fields (controlWhat, controlHow, controlWhy, controlObjective*, supplementalGuidance) once per Control ID. `included_kcs` and `excluded_kcs` list each control instance once, with every risk the instance is tagged to in `risk_tags` (riskId, riskTypeLevel2/3/4); excluded entries carry the exclusion `reason` - use it as the sub-heading or reason text exactly as given (for example "Retired in dbGRC", "Not found in dbGRC"), never as a code with underscores.
    Key interpretation rules:
    - Treat each Control ID as a master control.
    - Each entry in `included_kcs` / `excluded_kcs` is one control instance, identified by its Control Instance ID (`controlInstanceNumber`). All risks the instance is tagged to are in its `risk_tags`: show them together under that single instance and never split one instance into several entries by risk.
    - A single Control ID may have multiple control instances.
    - Even with the same AU, instances may differ by attributes such as control frequency, effective dates, or other instance-specific fields.
    - Classification (Included, Excluded) must be done at control instance level, not control ID level.

    Required analysis:
    1. Produce these separate sections exactly:
      - Included Control Instances
      - Excluded Control Instances
    2. For each instance, show:
      - Control ID
      - Control Instance ID
      - AU
      - Risk Type: all risks in the instance's `risk_tags` (risk id and description), on one line
      - Relevant instance attributes (frequency, dates, and other available differentiators)
    3. If the same AU + Risk Type + Control ID appears across different sections, these are different control instances of that control in that AU. Compare the included and excluded instance records field by field and state exactly what differs between them: name both Control Instance IDs and give the differing values side by side (for example controlInstanceState Active vs Retired, controlFrequency, created/updated dates, operating owner or function, risk_tags). Never write a generic note such as "active instances of this control for the same Assessment Units are listed as in-scope" without naming the instances and the differing values; if only the instance ID and state differ, say exactly that.
    4. Preserve category integrity exactly as represented in the dbGRC data. Do not reclassify unless explicitly instructed.
    5. Compare each instance's `risk_tags` with the risk types of the current plan:
      - If NONE of the plan's risk types is in the instance's `risk_tags`, point it out: even though the control and AU match the current plan, the instance is tagged to other risk(s) only - name those risk ids and descriptions.
      - If at least one of the plan's risk types is in `risk_tags`, the instance matches the plan; only add a short note that it is also tagged to other risk(s), naming them. Do not describe this as a mismatch.

    For the included controls, take the following fields from `control_definitions` using only this mapping:
    WHAT: controlWhat
    HOW: controlHow
    WHY: controlWhy
    Control Objective Number: controlObjectiveNumber
    Control Objective Name: controlObjectiveName
    Control Objective Description: controlObjectiveDescription
    MCS: supplementalGuidance
    When a control has multiple instances, show this control information only once, after its list of instances. Lay out each control instance with its attributes nested beneath it, following the formatting rules in Quality Expectations. For example:

          Control ID: <>

          Control Instances in-scope:
          \u2022 Control Instance 1:
              \u2022 Control Instance ID: <>
              \u2022 AU: <>
              \u2022 Risk Type: <>
              \u2022 Control Frequency: <>
              \u2022 Other relevant attributes that make this instance unique
          \u2022 Control Instance 2:
              \u2022 Control Instance ID: <>
              \u2022 AU: <>
              \u2022 Risk Type: <>
              \u2022 Control Frequency: <>
              \u2022 Other relevant attributes that make this instance unique

          WHAT :
          HOW :
          WHY :
          Control Objective Number:
          Control Objective Name:
          Control Objective Description:
          MCS:
"""


# Appended to BROAD_SCOPE_DBGRC_PROMPT only when the plan lists controls without an AU (the dbGRC data then
# carries `control_level_included_kcs` / `control_level_excluded_kcs`); plans with only AU-level controls never see it.
BROAD_SCOPE_DBGRC_CONTROL_LEVEL_PROMPT = """
Additional instructions - control-level controls (Key Controls):
- This plan also lists controls without any AU. A control becomes a control instance only when applied to an AU, so these controls have no instance in the plan and are reported at control level only. The system has already decided which controls are control-level from the plan data - never decide or change this yourself.
- `control_level_included_kcs` and `control_level_excluded_kcs` hold one entry per control with its control-level fields and, in `risk_tags`, the de-duplicated risks the control is attached to; excluded entries carry the exclusion `reason`. They contain no instance data: never list control instances, AUs, frequencies or other instance attributes for them, and never move a control between the instance-level and control-level lists.
- `in_scope`: when `control_level_included_kcs` is not empty, add ONE paragraph for the Included Key Controls starting with its own bold sub-heading, after the Included Control Instances paragraph if there is one.
- `out_of_scope`: when `control_level_excluded_kcs` is not empty, add ONE paragraph for the Excluded Key Controls starting with its own bold sub-heading, after the Excluded Control Instances paragraph if there is one.
- Instance-level paragraphs only appear when they have instances: if `included_kcs` is empty, do not write the Included Control Instances paragraph or its sub-heading at all, and if `excluded_kcs` is empty, do not write the Excluded Control Instances paragraph or its sub-heading at all. Do not write a line saying that no control instances were fetched - the Key Controls paragraphs cover these controls.
- Write each sub-heading once: every control of that paragraph is listed under the same sub-heading, never one sub-heading per control.
- In the lead sentence of the Key Controls paragraphs (after the exclusion reason for excluded ones), state that these controls are listed in the plan without an AU and so are covered at control level only, then show each control once with only its control-level information and no instance information. Take the control-level information from each entry using only the following mapping:
  WHAT: controlWhat
  HOW: controlHow
  WHY: controlWhy
  Control Objective Number: controlObjectiveNumber
  Control Objective Name: controlObjectiveName
  Control Objective Description: controlObjectiveDescription
  MCS: supplementalGuidance
  
  For example:

      Control ID: <>
      Risk Type: all risks in its `risk_tags` (risk id and description), on one line
      WHAT :
      HOW :
      WHY :
      Control Objective Number:
      Control Objective Name:
      Control Objective Description:
      MCS:
"""


BROAD_SCOPE_ALC_PROMPT = """
Task - Alternate Coverage (ALC) and No Coverage (NC):

Input Context for this part:
- Current Plan Details
- Alternate coverage and no coverage data for the Assessment Unit and Risk Type (AU-RT) combinations in the current plan

Return:
- `section1`: always an empty list.
- `in_scope`: always an empty list.
- `out_of_scope`: ONE paragraph (one narrative unit) with no sub-heading - the system adds the "Alternate Coverage" heading. Start with one lead sentence naming Alternate Coverage (ALC) / No Coverage (NC) data and whether the coverage could be considered for exclusion, then one bullet per coverage item: "• **Review or coverage name**: Assessment Unit, who provides the coverage, years, region and its relevance to this plan" in one or two sentences.

Understand the data from alternate coverage and no coverage data and align the scoping boundaries accordingly. If the coverage is in a different jurisdiction or region than the current plan, say so in the bullet. If there is no alternate coverage or no coverage data for any attribute, do not mention it; return an empty `out_of_scope` list when nothing applies.
"""


BROAD_SCOPE_FINDINGS_GA_PROMPT = """
Task - GFMS Findings and Group Audit:

Input Context for this part:
- Current Plan Details
- Findings data for open findings against control and risk combinations (GFMS)
- Group Audit current-year review data for overlapping risk and KC coverage

Return:
- `section1`: always an empty list.
- `in_scope`: always an empty list.
- `out_of_scope`: always exactly two paragraphs, each with ONE narrative unit, even when there is nothing to report: first the GFMS findings under the bold sub-heading "**Open Findings from GFMS**", then the Group Audit result under the bold sub-heading "**Group Audit Overlap**". Never return an empty `out_of_scope` list for this Task. If the findings data or the Group Audit data is not supplied in this request, still include its sub-heading on its own line and state below it in a single line that the data is not available.

Open finding rule for AU-RT-KC combinations from GFMS data: If there is an open finding in findings data, write one lead sentence stating, from data from GFMS, which control / risk / AU the open findings relate to and that the control can be considered indicative out-of-scope for this review cycle to avoid duplicative effort while remediation is ongoing. Then list one bullet per finding: "• **Finding ID**: <id>", followed by nested "• **Finding Title**: <title>" and "• **Description**: <rating, status, target date and the attribute that relates it to the current plan, in one sentence>". The findings should ideally belong to same AU, or country, or should be for same control or risk.
If there is no open finding, write under the sub-heading a single line stating, from data from GFMS, that no open finding exists for this plan, with no reasoning or other information.

Group Audit Overlap Rule:
- Compare the current review against the Group Audit current-year review data using overlapping risk types, key controls, process areas, and narrative scope indicators present in the input.
- If Group Audit is already covering the same risk or KC in the current year, state that there is a Group Audit overlap, identify it, and explain that the area is a repeat-work / duplicative-assurance candidate that can be considered for exclusion or deprioritization.
- If no overlap is evidenced, state in a single line, from data from Group Audit, that no review overlapped with Group Audit (you may name the plan year, Risk Type, Key Control and jurisdiction compared), with no further reasoning.
- Do not invent overlap if the evidence is weak; explain the overlap only from the data provided.
"""
