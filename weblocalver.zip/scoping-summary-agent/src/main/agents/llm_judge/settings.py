"""Runtime settings for preliminary research review loops."""

import os

from config.config import Config
from .loop import judge_loop_enabled as _env_judge_loop_enabled


def judge_loop_enabled() -> bool:
    env_override = None
    for env_name in ("SUMMARY_AGENT_JUDGE_LOOP", "JUDGE_LOOP", "judge_loop"):
        val = os.getenv(env_name)
        if val is not None:
            normalized = val.strip().lower()
            if normalized in {"1", "true", "yes", "on"}:
                env_override = True
                break
            if normalized in {"0", "false", "no", "off"}:
                env_override = False
                break
    config_flag = getattr(
        Config,
        "SUMMARY_AGENT_JUDGE_LOOP",
        getattr(Config, "JUDGE_LOOP", False),
    )
    if env_override is not None:
        return env_override
    return bool(config_flag)


def review_settings() -> tuple[int, str]:
    return (
        Config.SUMMARY_AGENT_REVIEW_MAX_REVISIONS,
        Config.SUMMARY_AGENT_REVIEW_FAILURE_POLICY,
    )
