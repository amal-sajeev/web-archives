"""Runtime settings for preliminary research review loops."""

from config.config import Config


def review_settings() -> tuple[int, str]:
    return (
        Config.SUMMARY_AGENT_REVIEW_MAX_REVISIONS,
        Config.SUMMARY_AGENT_REVIEW_FAILURE_POLICY,
    )
