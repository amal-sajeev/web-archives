"""Rubric evaluation and deterministic validation for one generated section."""

from collections.abc import Callable
from typing import Any

from .integrity import deterministic_section_integrity, judge_source_chunks
from .models import (
    SectionQualityReview,
    SectionReview,
    SectionReviewResult,
)
from .prompt_catalog import (
    SECTION_QUALITY_REVIEW_PROMPT,
    SECTION_REVIEW_PROMPT,
    SECTION_REVIEW_REQUIREMENTS,
)
from .serialization import model_json


def merge_deterministic_integrity(
    review: SectionReview,
    issues: dict[str, list[str]],
) -> SectionReview:
    if not issues:
        return review
    actions = {
        "citation_validity": (
            "Use only supplied source IDs, align supporting_chunk_ids with rendered citations, "
            "and ensure citation status matches the presence of evidence."
        ),
        "required_content": "Address each missing supplied policy or regulatory manifest entry in the report.",
    }
    merged = []
    for criterion in review.criteria:
        messages = issues.get(criterion.name, [])
        if not messages:
            merged.append(criterion)
            continue
        issue = " ".join(filter(None, [criterion.issue.strip(), *messages]))
        action = " ".join(
            filter(
                None,
                [
                    criterion.action.strip(),
                    actions.get(
                        criterion.name, "Correct the deterministic integrity issue."
                    ),
                ],
            )
        )
        merged.append(
            criterion.model_copy(
                update={"passed": False, "issue": issue, "action": action}
            )
        )
    return review.model_copy(update={"criteria": merged})


def review_section_candidate(
    section_name: str,
    source_chunks: list[dict],
    candidate: Any,
    model: Any,
    prepare_payload: Callable,
    trace: Callable,
) -> SectionReviewResult:
    requirements = SECTION_REVIEW_REQUIREMENTS.get(
        section_name,
        f"Satisfy the required structure and grounding for {section_name}.",
    )
    schema = (
        candidate.model_json_schema()
        if hasattr(candidate, "model_json_schema")
        else {"type": type(candidate).__name__}
    )
    review_prompt = SECTION_REVIEW_PROMPT.format(
        section_requirements=requirements,
        required_schema=model_json(schema),
        candidate=model_json(candidate, exclude_skip_schema_fields=True),
    )
    payload = prepare_payload(
        judge_source_chunks(section_name, source_chunks),
        review_prompt,
        f"Review {section_name}",
        output_format_instructions=(
            "Return a criteria array with exactly one result for evidence_support, citation_validity, "
            "required_content, and schema_compliance. Each result has name, passed, issue, and action."
        ),
    )
    response = model.with_structured_output(SectionReview).invoke(payload)
    trace(f"section:{section_name}", "judge_output", response)
    response = merge_deterministic_integrity(
        response,
        deterministic_section_integrity(section_name, source_chunks, candidate),
    )

    quality_prompt = SECTION_QUALITY_REVIEW_PROMPT.format(
        section_requirements=requirements,
        candidate=model_json(candidate, exclude_skip_schema_fields=True),
    )
    quality_payload = prepare_payload(
        judge_source_chunks(section_name, source_chunks),
        quality_prompt,
        f"Quality review {section_name}",
        output_format_instructions=(
            "Return one criteria array with within_section_consistency, analysis_actionability, "
            "confidence_rationale_alignment, and source_applicability."
        ),
    )
    quality = model.with_structured_output(SectionQualityReview).invoke(quality_payload)
    trace(f"section:{section_name}", "quality_judge_output", quality)
    result = SectionReviewResult(grounding=response, quality=quality)
    trace(f"section:{section_name}", "combined_judge_output", result)
    return result
