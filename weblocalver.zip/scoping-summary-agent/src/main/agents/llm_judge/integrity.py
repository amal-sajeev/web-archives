"""Deterministic citation and evidence-manifest checks for section reviews."""

from typing import Any, Dict, List, Optional

from utils.broad_scope_builder import compact_dbgrc_controls
from utils.policy_section_builder import (
    build_policy_manifest,
    build_regulation_manifest,
    to_model_source_chunks,
)

from .serialization import to_jsonable

BROAD_SCOPE_TITLE = "Broad Scope Direction"
POLICY_SECTION = "Policy, KOD and Regulatory Analysis"


def judge_source_chunks(section_name: str, source_chunks: List[dict]) -> List[dict]:
    if section_name == POLICY_SECTION:
        return to_model_source_chunks(
            source_chunks,
            build_policy_manifest(source_chunks),
            build_regulation_manifest(source_chunks),
        )
    if section_name == BROAD_SCOPE_TITLE:
        transformed = to_model_source_chunks(
            source_chunks,
            build_policy_manifest(source_chunks),
            build_regulation_manifest(source_chunks),
        )
        return [
            {**chunk, "content": compact_dbgrc_controls(chunk.get("content"))}
            if isinstance(chunk, dict) and chunk.get("source_name") == "key_controls"
            else chunk
            for chunk in transformed
        ]
    return source_chunks


def allowed_source_reference_ids(section_name: str, source_chunks: List[dict]) -> set[str]:
    allowed = {
        str(chunk["chunk_id"])
        for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("chunk_id") not in (None, "")
    }
    if section_name not in {POLICY_SECTION, BROAD_SCOPE_TITLE}:
        return allowed
    for entry in build_policy_manifest(source_chunks).values():
        for document in entry["documents"]:
            if document.get("doc_key"):
                allowed.add(str(document["doc_key"]))
            allowed.update(
                str(section["key"])
                for section in document.get("sections", [])
                if section.get("key")
            )
    for mandate in build_regulation_manifest(source_chunks):
        if mandate.get("key"):
            allowed.add(str(mandate["key"]))
        allowed.update(
            str(item["key"])
            for item in mandate.get("evidence", [])
            if item.get("key")
        )
    return allowed


def citation_records(candidate: Any) -> List[tuple[str, Optional[str], List[str], List[str]]]:
    records: List[tuple[str, Optional[str], List[str], List[str]]] = []

    def walk(node: Any, path: str) -> None:
        if isinstance(node, list):
            for index, item in enumerate(node):
                walk(item, f"{path}[{index}]")
            return
        if not isinstance(node, dict):
            return
        if "citation_status" in node:
            _append_citation_record(records, node, path, str(node.get("citation_status")))
            return
        if "paragraph_id" in node and "content" in node:
            paragraph_path = f"{path}/{node.get('paragraph_id')}"
            if isinstance(node["content"], str):
                _append_citation_record(records, node, paragraph_path, None)
            else:
                walk(node["content"], paragraph_path)
            return
        for key, item in node.items():
            walk(item, f"{path}/{key}")

    walk(to_jsonable(candidate), "candidate")
    return records


def _append_citation_record(records, node, path, status):
    ids = [str(item) for item in node.get("supporting_chunk_ids", []) if item not in (None, "")]
    citations = [
        str(item.get("chunk_id"))
        for item in node.get("supporting_citations", [])
        if isinstance(item, dict) and item.get("chunk_id") not in (None, "")
    ]
    records.append((path, status, ids, citations))


def deterministic_section_integrity(
    section_name: str,
    source_chunks: List[dict],
    candidate: Any,
) -> Dict[str, List[str]]:
    allowed = allowed_source_reference_ids(section_name, source_chunks)
    records = citation_records(candidate)
    issues: Dict[str, List[str]] = {"citation_validity": [], "required_content": []}
    for path, status, ids, citations in records:
        references = set(ids) | set(citations)
        unknown = sorted(references - allowed)
        if unknown:
            issues["citation_validity"].append(
                f"{path} references source IDs that were not supplied: {', '.join(unknown)}."
            )
        if status == "supported":
            if not references:
                issues["citation_validity"].append(f"{path} is marked supported but has no source citation.")
            elif not citations:
                issues["citation_validity"].append(
                    f"{path} lists supporting source IDs but has no citation entries for rendering."
                )
        elif status is None and ids and not citations:
            issues["citation_validity"].append(
                f"{path} lists supporting source IDs but has no citation entries for rendering."
            )
        if ids and citations and set(ids) != set(citations):
            issues["citation_validity"].append(
                f"{path} supporting source IDs do not match its rendered citation IDs."
            )
        elif status in {"unsupported", "not_required"} and references:
            issues["citation_validity"].append(f"{path} is marked {status} but still contains source citations.")

    if section_name == POLICY_SECTION:
        expected_keys = {
            str(section["key"])
            for entry in build_policy_manifest(source_chunks).values()
            for document in entry["documents"]
            for section in document.get("sections", [])
            if section.get("key")
        }
        expected_keys.update(
            str(evidence["key"])
            for mandate in build_regulation_manifest(source_chunks)
            for evidence in mandate.get("evidence", [])
            if evidence.get("key") and evidence.get("deep_link")
        )
        cited_ids = {
            reference
            for _path, _status, ids, citations in records
            for reference in (*ids, *citations)
        }
        missing = sorted(expected_keys - cited_ids)
        if missing:
            issues["required_content"].append(
                "The report does not cite all supplied policy/regulatory manifest entries: "
                f"{', '.join(missing[:12])}{' …' if len(missing) > 12 else ''}."
            )
    return {name: messages for name, messages in issues.items() if messages}
