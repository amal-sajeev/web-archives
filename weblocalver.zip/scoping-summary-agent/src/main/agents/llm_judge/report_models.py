"""Cross-section report review models."""

from typing import Literal

from pydantic import BaseModel, Field, model_validator

from .section_models import normalize_section_name


class ReportCriterion(BaseModel):
    name: Literal[
        "section_coverage",
        "cross_section_consistency",
        "review_identifier_consistency",
        "duplication_and_structure",
    ]
    passed: bool = Field(description="Whether this named check passed.")
    issue: str = Field(
        default="", description="Specific report-level defect found, if any."
    )
    action: str = Field(
        default="", description="Concrete correction for this check when it fails."
    )
    affected_sections: list[str] = Field(
        default_factory=list,
        description="Exact report section names that need revision for this failed check.",
    )

    @model_validator(mode="after")
    def populate_missing_failed_field(self):
        if not self.passed:
            issue_text = self.issue.strip()
            action_text = self.action.strip()
            if issue_text and not action_text:
                self.action = f"Resolve the reported {self.name} issue: {issue_text}"
            elif action_text and not issue_text:
                self.issue = action_text
        return self


class ReportRubricReview(BaseModel):
    """Structured response for one focused report-review call."""

    criteria: list[ReportCriterion] = Field(
        description="Only the report-review criteria requested in this focused call."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        names = [criterion.name for criterion in self.criteria]
        if len(names) != len(set(names)):
            raise ValueError("A focused report review cannot repeat a rubric criterion")
        if any(
            not item.passed
            and (
                not item.issue.strip()
                or not item.action.strip()
                or not item.affected_sections
            )
            for item in self.criteria
        ):
            raise ValueError(
                "Each failed report criterion must include an issue, corrective action, and affected section"
            )
        return self


class ReportReview(BaseModel):
    criteria: list[ReportCriterion] = Field(
        description="Exactly one result for each required complete-report review criterion."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        required = {
            "section_coverage",
            "cross_section_consistency",
            "review_identifier_consistency",
            "duplication_and_structure",
        }
        names = [criterion.name for criterion in self.criteria]
        if set(names) != required or len(names) != len(required):
            raise ValueError(
                "Report review must include each rubric criterion exactly once"
            )
        if any(
            not item.passed
            and (
                not item.issue.strip()
                or not item.action.strip()
                or not item.affected_sections
            )
            for item in self.criteria
        ):
            raise ValueError(
                "Each failed report criterion must include an issue, corrective action, and affected section"
            )
        return self

    @property
    def approved(self) -> bool:
        return all(item.passed for item in self.criteria)

    @property
    def feedback_by_section(self) -> dict[str, str]:
        feedback: dict[str, list[str]] = {}
        for item in self.criteria:
            if item.passed:
                continue
            instruction = f"[{item.name}] {item.issue.strip()} Action: {item.action.strip()}".strip()
            for raw_name in item.affected_sections:
                section_name = normalize_section_name(raw_name)
                feedback.setdefault(section_name, []).append(instruction)
        return {
            name: "\n".join(instructions) for name, instructions in feedback.items()
        }
