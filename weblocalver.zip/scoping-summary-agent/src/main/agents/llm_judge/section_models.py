"""Structured review models for the preliminary research report judge."""

from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class SectionCriterion(BaseModel):
    name: Literal[
        "evidence_support",
        "citation_validity",
        "required_content",
        "schema_compliance",
    ]
    passed: bool = Field(description="Whether this named check passed.")
    issue: str = Field(
        default="", description="Specific defect found by this check, if any."
    )
    action: str = Field(
        default="", description="Concrete correction for this check when it fails."
    )

    @model_validator(mode="before")
    @classmethod
    def coerce_legacy_fields(cls, data: Any) -> Any:
        if isinstance(data, dict):
            normalized = dict(data)
            if "name" not in normalized and "criterion" in normalized:
                normalized["name"] = normalized.pop("criterion")
            if "passed" not in normalized and "status" in normalized:
                status = str(normalized.pop("status")).strip().lower()
                normalized["passed"] = status in {
                    "pass",
                    "passed",
                    "true",
                    "ok",
                    "approved",
                }
            return normalized
        return data

    @model_validator(mode="after")
    def populate_missing_failed_field(self):
        if not self.passed:
            issue_text = self.issue.strip()
            action_text = self.action.strip()
            if issue_text and not action_text:
                self.action = f"Resolve the reported {self.name} issue: {issue_text}"
            elif action_text and not issue_text:
                self.issue = action_text
        return self


class SectionReview(BaseModel):
    criteria: list[SectionCriterion] = Field(
        description="Exactly one result for each required section review criterion."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        required = {
            "evidence_support",
            "citation_validity",
            "required_content",
            "schema_compliance",
        }
        names = [criterion.name for criterion in self.criteria]
        if set(names) != required or len(names) != len(required):
            raise ValueError(
                "Section review must include each rubric criterion exactly once"
            )
        if any(
            not item.passed and (not item.issue.strip() or not item.action.strip())
            for item in self.criteria
        ):
            raise ValueError(
                "Each failed section criterion must include an issue and corrective action"
            )
        return self

    @property
    def approved(self) -> bool:
        return all(item.passed for item in self.criteria)

    @property
    def feedback(self) -> str:
        return "\n".join(
            f"[{item.name}] {item.issue.strip()} Action: {item.action.strip()}".strip()
            for item in self.criteria
            if not item.passed
        )


class SectionQualityCriterion(BaseModel):
    name: Literal[
        "within_section_consistency",
        "analysis_actionability",
        "confidence_rationale_alignment",
        "source_applicability",
    ]
    passed: bool = Field(description="Whether this named section-quality check passed.")
    issue: str = Field(
        default="", description="Specific defect found by this check, if any."
    )
    action: str = Field(
        default="", description="Concrete correction for this check when it fails."
    )

    @model_validator(mode="after")
    def populate_missing_failed_field(self):
        if not self.passed:
            issue_text = self.issue.strip()
            action_text = self.action.strip()
            if issue_text and not action_text:
                self.action = f"Resolve the reported {self.name} issue: {issue_text}"
            elif action_text and not issue_text:
                self.issue = action_text
        return self


class SectionQualityReview(BaseModel):
    criteria: list[SectionQualityCriterion] = Field(
        description="Exactly one result for each focused section-quality criterion."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        required = {
            "within_section_consistency",
            "analysis_actionability",
            "confidence_rationale_alignment",
            "source_applicability",
        }
        names = [criterion.name for criterion in self.criteria]
        if set(names) != required or len(names) != len(required):
            raise ValueError(
                "Section quality review must include each criterion exactly once"
            )
        if any(
            not item.passed and (not item.issue.strip() or not item.action.strip())
            for item in self.criteria
        ):
            raise ValueError(
                "Each failed section-quality criterion needs an issue and corrective action"
            )
        return self

    @property
    def approved(self) -> bool:
        return all(item.passed for item in self.criteria)

    @property
    def feedback(self) -> str:
        return "\n".join(
            f"[{item.name}] {item.issue.strip()} Action: {item.action.strip()}".strip()
            for item in self.criteria
            if not item.passed
        )


@dataclass(frozen=True)
class SectionReviewResult:
    grounding: SectionReview
    quality: SectionQualityReview
    deterministic_feedback: str = ""

    @property
    def approved(self) -> bool:
        return (
            self.grounding.approved
            and self.quality.approved
            and not self.deterministic_feedback
        )

    @property
    def feedback(self) -> str:
        return "\n".join(
            item
            for item in (
                self.grounding.feedback,
                self.quality.feedback,
                self.deterministic_feedback,
            )
            if item
        )


_SECTION_NAME_ALIASES: dict[str, str] = {
    "past_review": "Past Review Analysis",
    "past review": "Past Review Analysis",
    "past review analysis": "Past Review Analysis",
    "policy_regulation": "Policy, KOD and Regulatory Analysis",
    "policy regulation": "Policy, KOD and Regulatory Analysis",
    "policy, kod and regulatory analysis": "Policy, KOD and Regulatory Analysis",
    "policy, kod/procedure and regulatory analysis": "Policy, KOD and Regulatory Analysis",
    "broad_scope": "Broad Scope Direction",
    "broad scope": "Broad Scope Direction",
    "broad scope direction": "Broad Scope Direction",
}


def normalize_section_name(name: str, known_names: Any = None) -> str:
    cleaned = str(name or "").strip()
    if known_names and cleaned in known_names:
        return cleaned
    lowered = cleaned.lower()
    if lowered in _SECTION_NAME_ALIASES:
        canonical = _SECTION_NAME_ALIASES[lowered]
        if not known_names or canonical in known_names:
            return canonical
    if known_names:
        for candidate_name in known_names:
            if candidate_name.lower() == lowered:
                return candidate_name
    return cleaned
