"""Structured models exposed by the preliminary research judge."""

from .report_models import ReportCriterion, ReportReview, ReportRubricReview
from .section_models import (
    SectionCriterion,
    SectionQualityCriterion,
    SectionQualityReview,
    SectionReview,
    SectionReviewResult,
    normalize_section_name,
)

__all__ = [
    "ReportCriterion",
    "ReportReview",
    "ReportRubricReview",
    "SectionCriterion",
    "SectionQualityCriterion",
    "SectionQualityReview",
    "SectionReview",
    "SectionReviewResult",
    "normalize_section_name",
]
