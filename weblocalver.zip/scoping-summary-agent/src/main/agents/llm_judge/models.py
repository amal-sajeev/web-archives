"""Structured review models for the preliminary research report judge."""

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, model_validator


class SectionCriterion(BaseModel):
    name: Literal[
        "evidence_support",
        "citation_validity",
        "required_content",
        "schema_compliance",
    ]
    passed: bool = Field(description="Whether this named check passed.")
    issue: str = Field(default="", description="Specific defect found by this check, if any.")
    action: str = Field(default="", description="Concrete correction for this check when it fails.")


class SectionReview(BaseModel):
    criteria: List[SectionCriterion] = Field(
        description="Exactly one result for each required section review criterion."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        required = {
            "evidence_support",
            "citation_validity",
            "required_content",
            "schema_compliance",
        }
        names = [criterion.name for criterion in self.criteria]
        if set(names) != required or len(names) != len(required):
            raise ValueError("Section review must include each rubric criterion exactly once")
        if any(
            not item.passed and (not item.issue.strip() or not item.action.strip())
            for item in self.criteria
        ):
            raise ValueError("Each failed section criterion must include an issue and corrective action")
        return self

    @property
    def approved(self) -> bool:
        return all(item.passed for item in self.criteria)

    @property
    def feedback(self) -> str:
        return "\n".join(
            f"[{item.name}] {item.issue.strip()} Action: {item.action.strip()}".strip()
            for item in self.criteria
            if not item.passed
        )


class SectionQualityCriterion(BaseModel):
    name: Literal[
        "within_section_consistency",
        "analysis_actionability",
        "confidence_rationale_alignment",
        "source_applicability",
    ]
    passed: bool = Field(description="Whether this named section-quality check passed.")
    issue: str = Field(default="", description="Specific defect found by this check, if any.")
    action: str = Field(default="", description="Concrete correction for this check when it fails.")


class SectionQualityReview(BaseModel):
    criteria: List[SectionQualityCriterion] = Field(
        description="Exactly one result for each focused section-quality criterion."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        required = {
            "within_section_consistency",
            "analysis_actionability",
            "confidence_rationale_alignment",
            "source_applicability",
        }
        names = [criterion.name for criterion in self.criteria]
        if set(names) != required or len(names) != len(required):
            raise ValueError("Section quality review must include each criterion exactly once")
        if any(
            not item.passed and (not item.issue.strip() or not item.action.strip())
            for item in self.criteria
        ):
            raise ValueError("Each failed section-quality criterion needs an issue and corrective action")
        return self

    @property
    def approved(self) -> bool:
        return all(item.passed for item in self.criteria)

    @property
    def feedback(self) -> str:
        return "\n".join(
            f"[{item.name}] {item.issue.strip()} Action: {item.action.strip()}".strip()
            for item in self.criteria
            if not item.passed
        )


@dataclass(frozen=True)
class SectionReviewResult:
    grounding: SectionReview
    quality: SectionQualityReview
    deterministic_feedback: str = ""

    @property
    def approved(self) -> bool:
        return self.grounding.approved and self.quality.approved and not self.deterministic_feedback

    @property
    def feedback(self) -> str:
        return "\n".join(
            item
            for item in (
                self.grounding.feedback,
                self.quality.feedback,
                self.deterministic_feedback,
            )
            if item
        )


_SECTION_NAME_ALIASES: Dict[str, str] = {
    "past_review": "Past Review Analysis",
    "past review": "Past Review Analysis",
    "past review analysis": "Past Review Analysis",
    "policy_regulation": "Policy, KOD and Regulatory Analysis",
    "policy regulation": "Policy, KOD and Regulatory Analysis",
    "policy, kod and regulatory analysis": "Policy, KOD and Regulatory Analysis",
    "policy, kod/procedure and regulatory analysis": "Policy, KOD and Regulatory Analysis",
    "broad_scope": "Broad Scope Direction",
    "broad scope": "Broad Scope Direction",
    "broad scope direction": "Broad Scope Direction",
}


def normalize_section_name(name: str, known_names: Any = None) -> str:
    cleaned = str(name or "").strip()
    if known_names and cleaned in known_names:
        return cleaned
    lowered = cleaned.lower()
    if lowered in _SECTION_NAME_ALIASES:
        canonical = _SECTION_NAME_ALIASES[lowered]
        if not known_names or canonical in known_names:
            return canonical
    if known_names:
        for candidate_name in known_names:
            if candidate_name.lower() == lowered:
                return candidate_name
    return cleaned


class ReportCriterion(BaseModel):
    name: Literal[
        "section_coverage",
        "cross_section_consistency",
        "review_identifier_consistency",
        "duplication_and_structure",
    ]
    passed: bool = Field(description="Whether this named check passed.")
    issue: str = Field(default="", description="Specific report-level defect found, if any.")
    action: str = Field(default="", description="Concrete correction for this check when it fails.")
    affected_sections: List[str] = Field(
        default_factory=list,
        description="Exact report section names that need revision for this failed check.",
    )


class ReportRubricReview(BaseModel):
    """Structured response for one focused report-review call."""

    criteria: List[ReportCriterion] = Field(
        description="Only the report-review criteria requested in this focused call."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        names = [criterion.name for criterion in self.criteria]
        if len(names) != len(set(names)):
            raise ValueError("A focused report review cannot repeat a rubric criterion")
        if any(
            not item.passed
            and (not item.issue.strip() or not item.action.strip() or not item.affected_sections)
            for item in self.criteria
        ):
            raise ValueError(
                "Each failed report criterion must include an issue, corrective action, and affected section"
            )
        return self


class ReportReview(BaseModel):
    criteria: List[ReportCriterion] = Field(
        description="Exactly one result for each required complete-report review criterion."
    )

    @model_validator(mode="after")
    def validate_rubric(self):
        required = {
            "section_coverage",
            "cross_section_consistency",
            "review_identifier_consistency",
            "duplication_and_structure",
        }
        names = [criterion.name for criterion in self.criteria]
        if set(names) != required or len(names) != len(required):
            raise ValueError("Report review must include each rubric criterion exactly once")
        if any(
            not item.passed
            and (not item.issue.strip() or not item.action.strip() or not item.affected_sections)
            for item in self.criteria
        ):
            raise ValueError(
                "Each failed report criterion must include an issue, corrective action, and affected section"
            )
        return self

    @property
    def approved(self) -> bool:
        return all(item.passed for item in self.criteria)

    @property
    def feedback_by_section(self) -> Dict[str, str]:
        feedback: Dict[str, List[str]] = {}
        for item in self.criteria:
            if item.passed:
                continue
            instruction = f"[{item.name}] {item.issue.strip()} Action: {item.action.strip()}".strip()
            for raw_name in item.affected_sections:
                section_name = normalize_section_name(raw_name)
                feedback.setdefault(section_name, []).append(instruction)
        return {name: "\n".join(instructions) for name, instructions in feedback.items()}
