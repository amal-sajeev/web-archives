"""Focused report-level rubric evaluation."""

from typing import Any

from .models import ReportCriterion, ReportReview, ReportRubricReview
from .prompt_catalog import REPORT_REVIEW_PROMPT, REPORT_REVIEW_RUBRICS
from .serialization import model_json, summarize_candidate_for_judge

REPORT_RUBRIC_CALLS = (
    ("coverage_and_identifiers", {"section_coverage", "review_identifier_consistency"}),
    ("cross_section_consistency", {"cross_section_consistency"}),
    ("duplication_and_structure", {"duplication_and_structure"}),
)


def review_report_candidate(
    candidate: dict[str, Any],
    model: Any,
    to_human_message,
    trace,
) -> ReportReview:
    candidate_json = model_json(summarize_candidate_for_judge(candidate))
    section_names = "\n".join(f"- {name}" for name in candidate)
    criteria: list[ReportCriterion] = []
    for rubric_name, expected_names in REPORT_RUBRIC_CALLS:
        prompt = REPORT_REVIEW_PROMPT.format(
            rubric_instructions=REPORT_REVIEW_RUBRICS[rubric_name],
            section_names=section_names,
            candidate=candidate_json,
        )
        trace(
            f"complete-report:{rubric_name}",
            "judge_input",
            {"review_prompt": prompt},
        )
        payload = [to_human_message([{"type": "text", "text": prompt}])]
        response: ReportRubricReview = model.with_structured_output(
            ReportRubricReview
        ).invoke(payload)
        actual_names: set[str] = {criterion.name for criterion in response.criteria}
        if actual_names != expected_names or len(response.criteria) != len(
            expected_names
        ):
            raise ValueError(
                f"Report judge rubric '{rubric_name}' returned criteria {sorted(actual_names)}; "
                f"expected {sorted(expected_names)}"
            )
        criteria.extend(response.criteria)
        trace(f"complete-report:{rubric_name}", "judge_output", response)
    review = ReportReview(criteria=criteria)
    trace("complete-report", "judge_output", review)
    return review
