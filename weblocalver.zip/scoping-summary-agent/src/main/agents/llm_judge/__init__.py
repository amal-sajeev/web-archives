"""Preliminary research agent review and revision workflows."""

from .models import (
    ReportCriterion,
    ReportReview,
    ReportRubricReview,
    SectionCriterion,
    SectionQualityCriterion,
    SectionQualityReview,
    SectionReview,
    SectionReviewResult,
)
from .prompt_catalog import (
    PROMPT_CATALOG,
    REPORT_REVIEW_PROMPT,
    REPORT_REVIEW_RUBRICS,
    SECTION_QUALITY_REVIEW_PROMPT,
    SECTION_REVIEW_PROMPT,
    SECTION_REVIEW_REQUIREMENTS,
    load_prompt_catalog,
)
from .report_review import review_report_candidate
from .integrity import deterministic_section_integrity
from .section_review import review_section_candidate
from .settings import review_settings

__all__ = [
    "PROMPT_CATALOG",
    "ReportCriterion",
    "ReportReview",
    "ReportRubricReview",
    "SECTION_QUALITY_REVIEW_PROMPT",
    "SECTION_REVIEW_PROMPT",
    "SECTION_REVIEW_REQUIREMENTS",
    "SectionCriterion",
    "SectionQualityCriterion",
    "SectionQualityReview",
    "SectionReview",
    "SectionReviewResult",
    "REPORT_REVIEW_PROMPT",
    "REPORT_REVIEW_RUBRICS",
    "load_prompt_catalog",
    "review_report_candidate",
    "review_section_candidate",
    "deterministic_section_integrity",
    "review_settings",
]
