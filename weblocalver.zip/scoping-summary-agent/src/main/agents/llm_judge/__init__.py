"""Preliminary research agent review and revision workflows."""

from .integrity import deterministic_section_integrity
from .loop import ReviewLoopError, ReviewLoopResult, review_and_revise
from .models import (
    ReportCriterion,
    ReportReview,
    ReportRubricReview,
    SectionCriterion,
    SectionQualityCriterion,
    SectionQualityReview,
    SectionReview,
    SectionReviewResult,
)
from .prompt_catalog import (
    PROMPT_CATALOG,
    REPORT_REVIEW_PROMPT,
    REPORT_REVIEW_RUBRICS,
    SECTION_QUALITY_REVIEW_PROMPT,
    SECTION_REVIEW_PROMPT,
    SECTION_REVIEW_REQUIREMENTS,
    load_prompt_catalog,
)
from .report_review import review_report_candidate
from .section_review import review_section_candidate
from .settings import review_settings

__all__ = [
    "PROMPT_CATALOG",
    "REPORT_REVIEW_PROMPT",
    "REPORT_REVIEW_RUBRICS",
    "SECTION_QUALITY_REVIEW_PROMPT",
    "SECTION_REVIEW_PROMPT",
    "SECTION_REVIEW_REQUIREMENTS",
    "ReportCriterion",
    "ReportReview",
    "ReportRubricReview",
    "ReviewLoopError",
    "ReviewLoopResult",
    "SectionCriterion",
    "SectionQualityCriterion",
    "SectionQualityReview",
    "SectionReview",
    "SectionReviewResult",
    "deterministic_section_integrity",
    "load_prompt_catalog",
    "review_and_revise",
    "review_report_candidate",
    "review_section_candidate",
    "review_settings",
]
