"""JSON-safe serialization used by judge prompts and revision feedback."""

import json
from typing import Any


ENRICHED_CITATION_FIELDS = (
    "citation_label",
    "gs_uri",
    "document_name",
    "content_type",
    "url",
)


def strip_skip_schema_fields(dumped: Any) -> None:
    if isinstance(dumped, dict):
        if isinstance(dumped.get("metadata"), dict):
            dumped["metadata"].pop("heading_level", None)
        if isinstance(dumped.get("supporting_citations"), list):
            for citation in dumped["supporting_citations"]:
                if isinstance(citation, dict):
                    for field in ENRICHED_CITATION_FIELDS:
                        if citation.get(field) is None:
                            citation.pop(field, None)
        for item in dumped.values():
            strip_skip_schema_fields(item)
    elif isinstance(dumped, list):
        for item in dumped:
            strip_skip_schema_fields(item)


def to_jsonable(value: Any, *, exclude_skip_schema_fields: bool = False) -> Any:
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(mode="json")
        if exclude_skip_schema_fields:
            strip_skip_schema_fields(dumped)
        return dumped
    if isinstance(value, dict):
        dumped = {
            key: to_jsonable(item, exclude_skip_schema_fields=exclude_skip_schema_fields)
            for key, item in value.items()
        }
        if exclude_skip_schema_fields:
            strip_skip_schema_fields(dumped)
        return dumped
    if isinstance(value, (list, tuple)):
        return [
            to_jsonable(item, exclude_skip_schema_fields=exclude_skip_schema_fields)
            for item in value
        ]
    return value


def model_json(value: Any, *, exclude_skip_schema_fields: bool = False) -> str:
    return json.dumps(
        to_jsonable(value, exclude_skip_schema_fields=exclude_skip_schema_fields),
        ensure_ascii=False,
        default=str,
    )


def with_review_feedback(prompt: str, feedback: str | None, previous_candidate: Any = None) -> str:
    if not feedback:
        return prompt
    previous = ""
    if previous_candidate is not None:
        previous = (
            "\n\nPREVIOUS CANDIDATE DRAFT FOR REFERENCE:\n"
            f"{model_json(previous_candidate, exclude_skip_schema_fields=True)}"
        )
    return (
        f"{prompt}{previous}\n\nREVIEW FEEDBACK FOR THIS REVISION:\n{feedback}\n"
        "Address the feedback while preserving the required report schema and source-grounding rules."
    )
