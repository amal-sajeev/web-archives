"""JSON-safe serialization used by judge prompts and revision feedback."""

import json
from typing import Any

ENRICHED_CITATION_FIELDS = (
    "citation_label",
    "gs_uri",
    "document_name",
    "content_type",
    "url",
)

COMPACT_TEXT_FIELDS = ("paragraph", "text", "summary", "rationale", "description")


def strip_skip_schema_fields(dumped: Any) -> None:
    if isinstance(dumped, dict):
        if isinstance(dumped.get("metadata"), dict):
            dumped["metadata"].pop("heading_level", None)
        if isinstance(dumped.get("supporting_citations"), list):
            for citation in dumped["supporting_citations"]:
                if isinstance(citation, dict):
                    for field in ENRICHED_CITATION_FIELDS:
                        if citation.get(field) is None:
                            citation.pop(field, None)
        for item in dumped.values():
            strip_skip_schema_fields(item)
    elif isinstance(dumped, list):
        for item in dumped:
            strip_skip_schema_fields(item)


def summarize_candidate_for_judge(value: Any) -> Any:
    """Compact NarrativeUnit lists into readable paragraph summaries for judge prompts."""
    dumped = to_jsonable(value, exclude_skip_schema_fields=True)
    return _compact_narrative_structure(dumped)


def _compact_narrative_structure(node: Any) -> Any:
    if isinstance(node, list):
        if node and all(
            isinstance(item, dict) and "text" in item and "unit_type" in item
            for item in node
        ):
            lines = []
            for item in node:
                text = str(item.get("text") or "").strip()
                status = item.get("citation_status") or "unknown"
                citations = [
                    c.get("chunk_id")
                    for c in (item.get("supporting_citations") or [])
                    if isinstance(c, dict) and c.get("chunk_id")
                ]
                cite_tag = f" [citations: {', '.join(citations)}]" if citations else ""
                lines.append(f"({status}{cite_tag}) {text}")
            return "\n".join(lines)
        return [_compact_narrative_structure(item) for item in node]
    if isinstance(node, dict):
        compacted = {}
        for key, item in node.items():
            if key in {"supporting_chunk_ids", "supporting_citations", "metadata"}:
                continue
            compacted[key] = _compact_narrative_structure(item)
        return compacted
    return node


def to_jsonable(value: Any, *, exclude_skip_schema_fields: bool = False) -> Any:
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(mode="json")
        if exclude_skip_schema_fields:
            strip_skip_schema_fields(dumped)
        return dumped
    if isinstance(value, dict):
        dumped = {
            key: to_jsonable(
                item, exclude_skip_schema_fields=exclude_skip_schema_fields
            )
            for key, item in value.items()
        }
        if exclude_skip_schema_fields:
            strip_skip_schema_fields(dumped)
        return dumped
    if isinstance(value, (list, tuple)):
        return [
            to_jsonable(item, exclude_skip_schema_fields=exclude_skip_schema_fields)
            for item in value
        ]
    return value


def model_json(value: Any, *, exclude_skip_schema_fields: bool = False) -> str:
    return json.dumps(
        to_jsonable(value, exclude_skip_schema_fields=exclude_skip_schema_fields),
        ensure_ascii=False,
        default=str,
    )


def with_review_feedback(
    prompt: str, feedback: str | None, previous_candidate: Any = None
) -> str:
    if not feedback:
        return prompt
    previous = ""
    if previous_candidate is not None:
        previous = (
            "\n\nPREVIOUS CANDIDATE DRAFT FOR REFERENCE:\n"
            f"{model_json(previous_candidate, exclude_skip_schema_fields=True)}"
        )
    return (
        f"{prompt}{previous}\n\nREVIEW FEEDBACK FOR THIS REVISION:\n{feedback}\n"
        "Address the feedback while preserving the required report schema and source-grounding rules."
    )
