"""Section and complete-report review loops for the analytics agent."""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from .loop import review_and_revise
from .models import ReportReview, normalize_section_name
from .report_review import review_report_candidate
from .section_review import review_section_candidate


def generate_reviewed_section(
    section_name: str,
    section_builder,
    source_chunks: list[dict],
    model: Any,
    max_revisions: int,
    failure_policy: str,
    *,
    call_section_builder,
    has_historical_data,
    trace,
    logger,
    initial_feedback: str | None = None,
    previous_candidate: Any | None = None,
    prepare_payload,
    review_section=None,
) -> Any:
    if getattr(
        section_builder, "__name__", ""
    ) == "past_review_report" and not has_historical_data(source_chunks):
        candidate = section_builder(source_chunks, model)
        trace(f"section:{section_name}", "candidate_before_judge", candidate)
        trace(f"section:{section_name}", "candidate_after_judge", candidate)
        return candidate

    candidate = call_section_builder(
        section_builder,
        source_chunks,
        model,
        review_feedback=initial_feedback,
        previous_candidate=previous_candidate,
    )
    trace(f"section:{section_name}", "candidate_before_judge", candidate)
    section_reviewer = review_section or (
        lambda value: review_section_candidate(
            section_name, source_chunks, value, model, prepare_payload, trace
        )
    )
    result = review_and_revise(
        candidate,
        reviewer=section_reviewer,
        reviser=lambda value, review: call_section_builder(
            section_builder,
            source_chunks,
            model,
            review_feedback=review.feedback,
            previous_candidate=value,
        ),
        approved=lambda review: review.approved,
        has_feedback=lambda review: bool(review.feedback.strip()),
        stage=f"section:{section_name}",
        max_revisions=max_revisions,
        failure_policy=failure_policy,
        log=logger,
    )
    trace(f"section:{section_name}", "candidate_after_judge", result.candidate)
    return result.candidate


async def review_complete_report(
    report: dict[str, Any],
    model: Any,
    section_inputs: dict[str, tuple[Any, list[dict]]],
    max_revisions: int,
    failure_policy: str,
    *,
    logger,
    trace,
    prepare_payload,
    to_human_message,
    call_section_builder,
    has_historical_data,
    review_report=None,
) -> dict[str, Any]:
    def revise_report(
        candidate: dict[str, Any], review: ReportReview
    ) -> dict[str, Any]:
        revised = dict(candidate)
        normalized = {
            normalize_section_name(name, section_inputs): feedback.strip()
            for name, feedback in review.feedback_by_section.items()
            if isinstance(feedback, str) and feedback.strip()
        }
        requested = {
            name: feedback
            for name, feedback in normalized.items()
            if name in section_inputs
        }
        unknown_names = set(normalized) - set(section_inputs)
        if unknown_names:
            logger.warning(
                "Ignoring unknown or non-editable report review sections=%s",
                sorted(unknown_names),
            )
        if not requested:
            return revised

        def revise_one(item: tuple[str, str]) -> tuple[str, Any]:
            section_name, feedback = item
            builder, chunks = section_inputs[section_name]
            return section_name, generate_reviewed_section(
                section_name,
                builder,
                chunks,
                model,
                0,
                failure_policy,
                call_section_builder=call_section_builder,
                has_historical_data=has_historical_data,
                trace=trace,
                logger=logger,
                initial_feedback=feedback,
                previous_candidate=candidate.get(section_name),
                prepare_payload=prepare_payload,
            )

        with ThreadPoolExecutor(max_workers=len(requested)) as pool:
            for section_name, section in pool.map(revise_one, requested.items()):
                revised[section_name] = section
        return revised

    def has_editable_feedback(review: ReportReview) -> bool:
        return any(
            normalize_section_name(name, section_inputs) in section_inputs
            and text.strip()
            for name, text in review.feedback_by_section.items()
        )

    report_reviewer = review_report or (
        lambda value: review_report_candidate(value, model, to_human_message, trace)
    )
    result = await asyncio.to_thread(
        review_and_revise,
        report,
        reviewer=report_reviewer,
        reviser=revise_report,
        approved=lambda review: review.approved,
        has_feedback=has_editable_feedback,
        stage="complete-report",
        max_revisions=max_revisions,
        failure_policy=failure_policy,
        log=logger,
    )
    return result.candidate
