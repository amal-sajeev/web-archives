"""Load dated, versioned judge prompts from JSON."""

import json
import os
from pathlib import Path
from typing import Any

PROMPT_DIRECTORY = Path(__file__).with_name("prompts")
REQUIRED_PROMPT_KEYS = {
    "section_review",
    "section_quality_review",
    "report_review",
    "section_requirements",
    "report_rubrics",
}


def _read_catalog(path: Path) -> dict[str, Any]:
    catalog = json.loads(path.read_text(encoding="utf-8"))
    missing = REQUIRED_PROMPT_KEYS - catalog.keys()
    if missing or not catalog.get("date") or not catalog.get("version"):
        raise ValueError(
            f"Invalid judge prompt catalog {path.name}: missing metadata or prompts"
        )
    return catalog


def load_prompt_catalog(version: str | None = None) -> dict[str, Any]:
    """Load a named version, or the newest dated version when no version is configured."""
    catalogs = [
        _read_catalog(path) for path in PROMPT_DIRECTORY.glob("summary_judge_*.json")
    ]
    if not catalogs:
        raise FileNotFoundError(
            f"No summary judge prompt catalogs found in {PROMPT_DIRECTORY}"
        )

    requested_version = version or os.getenv("SUMMARY_AGENT_JUDGE_PROMPT_VERSION")
    if requested_version:
        for catalog in catalogs:
            if catalog["version"] == requested_version:
                return catalog
        raise ValueError(
            f"Summary judge prompt version {requested_version!r} is unavailable"
        )

    return max(catalogs, key=lambda item: (item["date"], item["version"]))


PROMPT_CATALOG = load_prompt_catalog()
SECTION_REVIEW_PROMPT = PROMPT_CATALOG["section_review"]
SECTION_QUALITY_REVIEW_PROMPT = PROMPT_CATALOG["section_quality_review"]
REPORT_REVIEW_PROMPT = PROMPT_CATALOG["report_review"]
SECTION_REVIEW_REQUIREMENTS = PROMPT_CATALOG["section_requirements"]
REPORT_REVIEW_RUBRICS = PROMPT_CATALOG["report_rubrics"]
