import logging
import asyncio
import base64
import json
import os
import threading
import time
import weakref
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from typing import Any, Callable, Dict, List, Optional

from config.config import Config
from config.prompts import (
    ANALYSE_DATA_PROMPT,
    BROAD_SCOPE_ALC_PROMPT,
    BROAD_SCOPE_COLLATION_OUTPUT_FORMAT_PROMPT,
    BROAD_SCOPE_COLLATION_PROMPT,
    BROAD_SCOPE_COMMON_PROMPT,
    BROAD_SCOPE_DBGRC_PROMPT,
    BROAD_SCOPE_FINDINGS_GA_PROMPT,
    BROAD_SCOPE_HISTORICAL_PROMPT,
    BROAD_SCOPE_PART_OUTPUT_FORMAT_PROMPT,
    BROAD_SCOPE_QUALITY_PROMPT,
    OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    PAST_REVIEW_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    POLICY_ASSESSMENT_OUTPUT_FORMAT_PROMPT,
    POLICY_ASSESSMENT_PROMPT,
    POLICY_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    POLICY_REGULATION_PROMPT,
)
from utils.gemini_connection import initialize_gemini_model
from utils.storage_manager import read_blob_from_uri_as_bytes
from utils.policy_section_builder import (
    assemble_policy_report,
    build_policy_manifest,
    build_regulation_manifest,
    to_model_source_chunks,
)
from utils.broad_scope_builder import (
    BroadScopePart,
    build_section1,
    build_section2,
    cited_chunk_ids,
    compact_dbgrc_controls,
    draft_for_collation,
    finalize_broad_scope_report,
    resolve_draft_refs,
    restrict_citations,
)
from model.response_model import (
    BroadScopeCollationOutput,
    BroadScopePartOutput,
    PastReviewIntelligenceReport,
    PolicyAssessmentsOutput,
    PolicyRegulationOutput,
    ScopingReport,
)
from agents.llm_judge import (
    review_settings as _review_settings,
    review_report_candidate as _judge_review_report_candidate,
    review_section_candidate as _judge_review_section_candidate,
)
from agents.llm_judge.workflow import (
    generate_reviewed_section as _judge_generate_reviewed_section,
    review_complete_report as _judge_review_complete_report,
)
from agents.llm_judge.serialization import (
    with_review_feedback as _with_review_feedback,
)

logger = logging.getLogger(__name__)


ProgressCallback = Optional[Callable[[Dict[str, Any]], None]]


def _structured_output_model(model: Any, schema: Any) -> Any:
    """Bind agent schemas through the Vertex model's standard structured output."""
    return model.with_structured_output(schema)


def _emit_progress(
    progress_callback: ProgressCallback,
    status: str,
    message: str,
    progress: int,
    phase: Optional[str] = None,
    section: Optional[str] = None,
) -> None:
    if progress_callback:
        progress_callback({"status": status, "message": message, "progress": progress, "phase": phase, "section": section})


def _to_human_message(content_parts: list[dict]):
    """Build a HumanMessage when langchain_core is available, otherwise fallback to dict."""
    try:
        from langchain_core.messages import HumanMessage

        return HumanMessage(content=content_parts)
    except Exception:
        return {"role": "user", "content": content_parts}


def _prepare_multimodal_payload(
    source_chunks: List[dict],
    user_prompt: str,
    report_title: str,
    output_format_instructions: Optional[str] = None,
):
    """Build a multimodal payload with source JSON plus historical review PDFs.

    Temporary diagnostic: log payload sizing/timing around historical review PDFs
    so we can assess whether they are causing the Vertex INVALID_ARGUMENT error.
    """
    started_at = time.perf_counter()
    text_chunks: list[dict] = []
    pdf_chunks: list[dict] = []

    for chunk in source_chunks:
        source_name = str(chunk.get("source_name", ""))
        metadata = chunk.get("metadata") or {}
        url = str(metadata.get("url", ""))
        clean_chunk = (
            {k: v for k, v in chunk.items() if k != "_cached_pdf_bytes"}
            if isinstance(chunk, dict) and "_cached_pdf_bytes" in chunk
            else chunk
        )
        if source_name == "historical_review_document" and url.lower().endswith(".pdf"):
            pdf_chunks.append((chunk, clean_chunk))
            continue
        text_chunks.append(clean_chunk)

    payload_json = {
        "user_prompt": user_prompt,
        "output_format_instructions": (
            output_format_instructions
            or OUTPUT_FORMAT_INSTRUCTIONS_PROMPT.format(title=report_title)
        ),
        "source_chunks": text_chunks + [clean for _, clean in pdf_chunks],
    }

    _terminal_trace(
        report_title,
        "judge_input" if report_title.startswith("Review ") else "agent_input",
        payload_json,
    )

    json_text = json.dumps(payload_json, ensure_ascii=False)
    logger.info(
        "TEMP_PAYLOAD_METRICS section=%s total_chunks=%d text_chunks=%d pdf_chunks=%d json_chars=%d",
        report_title,
        len(source_chunks),
        len(text_chunks),
        len(pdf_chunks),
        len(json_text),
    )

    is_judge_call = report_title.startswith("Review ")
    instruction_prefix = (
        "Use the following JSON payload and attached historical review documents to review the candidate section. "
        "Treat each attachment as evidence for the corresponding historical review document chunk in source_chunks.\n\n"
        if is_judge_call
        else "Use the following JSON payload and attached historical review documents to generate the report. "
        "Treat each attachment as evidence for the corresponding historical review document chunk in source_chunks.\n\n"
    )
    content_parts: list[dict] = [
        {
            "type": "text",
            "text": instruction_prefix + f"{json_text}",
        }
    ]

    downloaded_pdf_bytes = 0
    for chunk, _clean_chunk in pdf_chunks:
        metadata = chunk.get("metadata") or {}
        uri = str(metadata.get("url", "")).strip()
        if not uri.startswith("gs://"):
            logger.warning("Skipping historical review document with invalid uri=%s", uri)
            continue

        cached_bytes = chunk.get("_cached_pdf_bytes")
        if cached_bytes is not None:
            pdf_bytes = cached_bytes
        else:
            try:
                pdf_bytes = read_blob_from_uri_as_bytes(uri)
            except Exception:
                logger.exception("Failed to download historical review document uri=%s", uri)
                continue
            chunk["_cached_pdf_bytes"] = pdf_bytes

        downloaded_pdf_bytes += len(pdf_bytes or b"")
        content_parts.append(
            {
                "type": "media",
                "mime_type": "application/pdf",
                "data": base64.b64encode(pdf_bytes).decode("utf-8"),
            }
        )

    elapsed_ms = (time.perf_counter() - started_at) * 1000
    logger.info(
        "TEMP_PAYLOAD_METRICS section=%s elapsed_ms=%.1f downloaded_pdf_bytes=%d total_text_chars=%d total_media_parts=%d",
        report_title,
        elapsed_ms,
        downloaded_pdf_bytes,
        len(json_text),
        len(content_parts),
    )

    return [_to_human_message(content_parts)]


def _call_section_builder(
    section_builder,
    source_chunks: List[dict],
    model: Any,
    review_feedback: Optional[str] = None,
    previous_candidate: Optional[Any] = None,
) -> Any:
    if review_feedback is None:
        return section_builder(source_chunks, model)
    if previous_candidate is not None:
        try:
            return section_builder(
                source_chunks,
                model,
                review_feedback=review_feedback,
                previous_candidate=previous_candidate,
            )
        except TypeError:
            pass
    return section_builder(source_chunks, model, review_feedback=review_feedback)


def past_review_report(
    source_chunks: List[dict],
    model,
    review_feedback: Optional[str] = None,
    previous_candidate: Optional[Any] = None,
) -> PastReviewIntelligenceReport:
    logger.info("Generating past review report with %d source chunks", len(source_chunks))
    report_title = "Past Review Analysis"

    # Without historical data the model only sees the current plan and invents a "historical review" from
    # references in its description (e.g. "last review in 2022"), so return an empty comparison instead.
    if not _has_historical_data(source_chunks):
        logger.info("No historical plan data or documents; skipping past review model call")
        return PastReviewIntelligenceReport(
            report_title=report_title,
            current_review_id=_current_plan_number(source_chunks),
            similar_review_count=0,
            historical_reviews=[],
        )

    structured_model = _structured_output_model(model, PastReviewIntelligenceReport)
    payload = _prepare_multimodal_payload(
        source_chunks,
        _with_review_feedback(ANALYSE_DATA_PROMPT, review_feedback, previous_candidate),
        report_title,
        output_format_instructions=PAST_REVIEW_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    )
    logger.info("Generating past review report")
    response: PastReviewIntelligenceReport = structured_model.invoke(payload)
    # Enforce the exact title; the model tends to synthesize its own otherwise.
    response.report_title = report_title
    _terminal_trace(report_title, "agent_output", response)
    logger.info("Past review report generated")
    return response


_CANDIDATE_CONTEXT_LOCK = threading.Lock()
_CANDIDATE_CONTEXT: List[tuple[weakref.ref[Any], Dict[str, Any]]] = []


def _store_candidate_context(candidate: Any, context: Dict[str, Any]) -> None:
    if candidate is None:
        return
    try:
        ref = weakref.ref(candidate)
    except TypeError:
        return
    with _CANDIDATE_CONTEXT_LOCK:
        _CANDIDATE_CONTEXT[:] = [
            (existing_ref, existing_ctx)
            for existing_ref, existing_ctx in _CANDIDATE_CONTEXT
            if existing_ref() is not None and existing_ref() is not candidate
        ]
        _CANDIDATE_CONTEXT.append((ref, context))


def _get_candidate_context(candidate: Any) -> Optional[Dict[str, Any]]:
    if candidate is None:
        return None
    with _CANDIDATE_CONTEXT_LOCK:
        for existing_ref, existing_ctx in reversed(_CANDIDATE_CONTEXT):
            if existing_ref() is candidate:
                return existing_ctx
    return None


_POLICY_ASSESSMENT_KEYWORDS = (
    "document_assessments",
    "policy|",
    "procedure|",
    "kod|",
    "summary not available",
    "document summary",
    "section summary",
    "applicability:",
    "relevance score",
)


def _should_rerun_policy_assessments(review_feedback: Optional[str]) -> bool:
    if not review_feedback:
        return True
    lowered = review_feedback.lower()
    return any(keyword in lowered for keyword in _POLICY_ASSESSMENT_KEYWORDS)


def _policy_source_assessments(
    source_chunks: List[dict],
    manifest: Dict[str, dict],
    source_name: str,
    model,
    review_feedback: Optional[str] = None,
) -> list:
    """Summarise every document/section of one source (policy, procedure or KOD) in its own model call."""
    if not manifest[source_name]["documents"]:
        return []
    sub_manifest = {source_name: manifest[source_name]}
    sub_chunks = [
        chunk for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") in ("current_plan_item_details", source_name)
    ]
    payload = _prepare_multimodal_payload(
        to_model_source_chunks(sub_chunks, sub_manifest),
        _with_review_feedback(POLICY_ASSESSMENT_PROMPT, review_feedback),
        f"Policy assessment {source_name}",
        output_format_instructions=POLICY_ASSESSMENT_OUTPUT_FORMAT_PROMPT,
    )
    try:
        result: PolicyAssessmentsOutput = _structured_output_model(
            model, PolicyAssessmentsOutput
        ).invoke(payload)
        _terminal_trace(f"Policy assessment {source_name}", "agent_output", result)
    except Exception:
        # Missing keys are rendered as "Summary not available" by assemble_policy_report.
        logger.exception("Policy assessment call failed source=%s", source_name)
        return []
    return list(result.document_assessments)


def policy_regulation(
    source_chunks: List[dict],
    model,
    review_feedback: Optional[str] = None,
    previous_candidate: Optional[Any] = None,
) -> ScopingReport:
    logger.info("Generating policy regulation report with %d source chunks", len(source_chunks))
    report_title = "Policy, KOD and Regulatory Analysis"
    structured_model = _structured_output_model(model, PolicyRegulationOutput)
    manifest = build_policy_manifest(source_chunks)
    model_chunks = to_model_source_chunks(source_chunks, manifest, build_regulation_manifest(source_chunks))
    output_format_instructions = (
        POLICY_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT
        + OUTPUT_FORMAT_INSTRUCTIONS_PROMPT.format(title=report_title)
    )
    prev_context = _get_candidate_context(previous_candidate)
    main_previous_candidate = (
        prev_context["main_output"]
        if prev_context and "main_output" in prev_context
        else previous_candidate
    )
    cached_assessments = (
        prev_context.get("document_assessments")
        if prev_context and review_feedback and not _should_rerun_policy_assessments(review_feedback)
        else None
    )

    payload = _prepare_multimodal_payload(
        model_chunks,
        _with_review_feedback(POLICY_REGULATION_PROMPT, review_feedback, main_previous_candidate),
        report_title,
        output_format_instructions=output_format_instructions,
    )
    logger.info("Generating policy regulation report")
    if cached_assessments is not None:
        logger.info("Reusing cached policy document assessments on revision count=%d", len(cached_assessments))
        output: PolicyRegulationOutput = structured_model.invoke(payload)
        assessments = list(cached_assessments)
    else:
        with ThreadPoolExecutor(max_workers=len(manifest) + 1) as pool:
            main_future = pool.submit(structured_model.invoke, payload)
            assessment_futures = [
                pool.submit(
                    _policy_source_assessments,
                    source_chunks,
                    manifest,
                    source_name,
                    model,
                    review_feedback,
                )
                for source_name in manifest
            ]
            output = main_future.result()
            assessments = [
                assessment for future in assessment_futures for assessment in future.result()
            ]

    main_output_snapshot = output.model_copy(deep=True)
    main_output_snapshot.section1.document_assessments = []
    output.section1.document_assessments = assessments

    # Section 1 is assembled deterministically in code from the merged model output.
    response = assemble_policy_report(output, manifest, source_chunks, report_title)
    _store_candidate_context(
        response,
        {
            "main_output": main_output_snapshot,
            "document_assessments": assessments,
        },
    )
    _terminal_trace(report_title, "agent_output", response)
    logger.info("Policy regulation report generated")

    return response

BROAD_SCOPE_TITLE = "Broad Scope Direction"
CURRENT_PLAN_SOURCE = "current_plan_item_details"

BROAD_SCOPE_GROUPS: List[Dict[str, Any]] = [
    {
        "key": "historical",
        "label": "Historical Plan Context",
        "prompt": BROAD_SCOPE_HISTORICAL_PROMPT,
        "sources": {"historical_review_document", "findings"},
        "always_run": True,
        "unavailable_text": None,
    },
    {
        "key": "dbgrc",
        "label": "dbGRC Control Scope",
        "prompt": BROAD_SCOPE_DBGRC_PROMPT,
        "sources": {"key_controls"},
        "compact": {"key_controls": compact_dbgrc_controls},
        # The prompt always asks for in-scope/out-of-scope blocks, so an empty answer means the call silently failed.
        "require_output": True,
        "unavailable_text": "Data Not Available - no dbGRC control data was retrieved for this plan.",
    },
    {
        "key": "findings_ga",
        "label": None,
        "prompt": BROAD_SCOPE_FINDINGS_GA_PROMPT,
        "sources": {"findings", "group_audit"},
        "unavailable_text": "Data Not Available - no GFMS findings or Group Audit data was retrieved for this plan.",
    },
    {
        "key": "alc_nc",
        "label": "Alternate Coverage",
        "prompt": BROAD_SCOPE_ALC_PROMPT,
        "sources": {"alternate_coverage"},
        "unavailable_text": None,
    },
]

BROAD_SCOPE_LAYOUT: Dict[str, List[str]] = {
    "in_scope": ["dbgrc", "historical"],
    "out_of_scope": ["dbgrc", "findings_ga", "historical", "alc_nc"],
}

BROAD_SCOPE_COLLATION_SOURCES = {
    CURRENT_PLAN_SOURCE,
    "relevant_policy",
    "relevant_procedure",
    "relevant_kod",
    "internet_search",
}


def _broad_scope_prompt(*blocks: str) -> str:
    return "\n".join([*blocks, BROAD_SCOPE_QUALITY_PROMPT, f"Current date (today): {date.today().isoformat()}"])


def _broad_scope_output_format(prefix: str) -> str:
    return prefix + OUTPUT_FORMAT_INSTRUCTIONS_PROMPT.format(title=BROAD_SCOPE_TITLE)


def _log_input_tokens(model, payload, context: str) -> None:
    try:
        message = payload[0]
        content = message["content"] if isinstance(message, dict) else message.content
        tokens = model.get_num_tokens(content[0]["text"])
    except Exception:
        logger.warning("Broad scope token count unavailable part=%s", context, exc_info=True)
        return
    threshold = Config.BROAD_SCOPE_MAX_INPUT_TOKENS
    level = logging.WARNING if tokens > threshold else logging.INFO
    logger.log(level, "Broad scope input tokens part=%s text_tokens=%d threshold=%d", context, tokens, threshold)


def _broad_scope_part(
    source_chunks: List[dict],
    group: Dict[str, Any],
    model,
    review_feedback: Optional[str] = None,
    previous_candidate: Optional[Any] = None,
) -> BroadScopePart:
    part = BroadScopePart(
        key=group["key"],
        label=group["label"],
        unavailable_text=group["unavailable_text"],
    )
    compactors = group.get("compact") or {}
    group_chunks = [
        {**chunk, "content": compactors[chunk["source_name"]](chunk.get("content"))}
        if chunk.get("source_name") in compactors else chunk
        for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") in {CURRENT_PLAN_SOURCE, *group["sources"]}
    ]
    has_group_data = any(chunk.get("source_name") in group["sources"] for chunk in group_chunks)
    if not has_group_data and not group.get("always_run"):
        logger.info("Skipping broad scope part=%s: no source data", group["key"])
        return part

    payload = _prepare_multimodal_payload(
        group_chunks,
        _with_review_feedback(
            _broad_scope_prompt(BROAD_SCOPE_COMMON_PROMPT, group["prompt"]),
            review_feedback,
            previous_candidate,
        ),
        f"{BROAD_SCOPE_TITLE} - {group['key']}",
        output_format_instructions=_broad_scope_output_format(BROAD_SCOPE_PART_OUTPUT_FORMAT_PROMPT),
    )
    _log_input_tokens(model, payload, group["key"])
    try:
        output: BroadScopePartOutput = model.with_structured_output(BroadScopePartOutput).invoke(payload)
        _terminal_trace(f"{BROAD_SCOPE_TITLE} - {group['key']}", "agent_output", output)
    except Exception:
        logger.exception("Broad scope part call failed part=%s", group["key"])
        part.status = "failed"
        return part
    if group.get("require_output") and not output.in_scope and not output.out_of_scope:
        logger.warning("Broad scope part=%s returned no in-scope or out-of-scope boundaries", group["key"])
        part.status = "failed"
        return part

    restrict_citations(
        [*output.section1, *output.in_scope, *output.out_of_scope],
        {str(chunk.get("chunk_id")) for chunk in group_chunks},
        group["key"],
    )
    part.status = "ok"
    part.output = output
    return part


def _broad_scope_collation(
    source_chunks: List[dict],
    draft_paragraphs: list,
    model,
    review_feedback: Optional[str] = None,
    previous_candidate: Optional[Any] = None,
) -> Optional[BroadScopeCollationOutput]:
    context_chunks = [
        chunk for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") in BROAD_SCOPE_COLLATION_SOURCES
    ]
    manifest = build_policy_manifest(context_chunks)
    regulation = build_regulation_manifest(context_chunks)
    draft, draft_refs = draft_for_collation(draft_paragraphs)
    collation_chunks = [
        *to_model_source_chunks(context_chunks, manifest, regulation),
        {"source_name": "broad_scope_draft", "content": draft},
    ]
    payload = _prepare_multimodal_payload(
        collation_chunks,
        _with_review_feedback(
            _broad_scope_prompt(BROAD_SCOPE_COLLATION_PROMPT),
            review_feedback,
            previous_candidate,
        ),
        f"{BROAD_SCOPE_TITLE} - collation",
        output_format_instructions=_broad_scope_output_format(BROAD_SCOPE_COLLATION_OUTPUT_FORMAT_PROMPT),
    )
    _log_input_tokens(model, payload, "collation")
    try:
        output: BroadScopeCollationOutput = model.with_structured_output(BroadScopeCollationOutput).invoke(payload)
        _terminal_trace(f"{BROAD_SCOPE_TITLE} - collation", "agent_output", output)
    except Exception:
        logger.exception("Broad scope collation call failed")
        return None

    resolve_draft_refs(output.section3, draft_refs)
    documents = [doc for entry in manifest.values() for doc in entry["documents"]]
    allowed_ids = (
        cited_chunk_ids(draft_paragraphs)
        | {str(chunk.get("chunk_id")) for chunk in context_chunks if chunk.get("source_name") == CURRENT_PLAN_SOURCE}
        | {doc["doc_key"] for doc in documents}
        | {section["key"] for doc in documents for section in doc["sections"]}
        | {mandate["key"] for mandate in regulation}
        | {evidence["key"] for mandate in regulation for evidence in mandate["evidence"]}
    )
    restrict_citations(output.section3, allowed_ids, "collation")
    return output


def _call_broad_scope_part(
    source_chunks: List[dict],
    group: Dict[str, Any],
    model: Any,
    review_feedback: Optional[str] = None,
    previous_candidate: Optional[Any] = None,
) -> BroadScopePart:
    if previous_candidate is not None:
        try:
            return _broad_scope_part(
                source_chunks,
                group,
                model,
                review_feedback=review_feedback,
                previous_candidate=previous_candidate,
            )
        except TypeError:
            pass
    return _broad_scope_part(
        source_chunks,
        group,
        model,
        review_feedback=review_feedback,
    )


def broad_scope_direction(
    source_chunks: List[dict],
    model,
    review_feedback: Optional[str] = None,
    previous_candidate: Optional[Any] = None,
) -> ScopingReport:
    logger.info("Generating broad scope direction report with %d source chunks", len(source_chunks))
    if review_feedback:
        logger.info("Broad scope direction review feedback supplied length=%d", len(review_feedback))
    prev_context = _get_candidate_context(previous_candidate)
    prev_parts = (prev_context or {}).get("part_outputs") or {}
    prev_collation = (
        prev_context["collation_output"]
        if prev_context and "collation_output" in prev_context
        else previous_candidate
    )
    with ThreadPoolExecutor(max_workers=len(BROAD_SCOPE_GROUPS)) as pool:
        parts = list(
            pool.map(
                lambda group: _call_broad_scope_part(
                    source_chunks,
                    group,
                    model,
                    review_feedback=review_feedback,
                    previous_candidate=prev_parts.get(group["key"]),
                ),
                BROAD_SCOPE_GROUPS,
            )
        )
    logger.info("Broad scope parts status=%s", {part.key: part.status for part in parts})
    if not any(part.status == "ok" for part in parts):
        raise RuntimeError("Broad scope direction generation failed: no source-group part succeeded")

    section1 = build_section1(parts)
    section2 = build_section2(parts, BROAD_SCOPE_LAYOUT)
    collation = _broad_scope_collation(
        source_chunks,
        [*section1, *section2],
        model,
        review_feedback=review_feedback,
        previous_candidate=prev_collation,
    )
    response = finalize_broad_scope_report(section1, section2, collation, BROAD_SCOPE_TITLE)
    _store_candidate_context(
        response,
        {
            "part_outputs": {
                part.key: part.output.model_copy(deep=True)
                for part in parts
                if part.status == "ok" and part.output is not None
            },
            "collation_output": collation.model_copy(deep=True) if collation is not None else None,
        },
    )
    _terminal_trace(BROAD_SCOPE_TITLE, "agent_output", response)

    logger.info("Broad scope direction generated")
    return response

async def _run_section(
    section_builder,
    source_chunks: List[dict],
    model,
):
    response = await asyncio.to_thread(section_builder, source_chunks, model)
    return response


def _generate_reviewed_section(
    section_name,
    section_builder,
    source_chunks,
    model,
    max_revisions,
    failure_policy,
    initial_feedback=None,
    previous_candidate=None,
):
    """Compatibility adapter; judge workflow lives in agents.llm_judge."""
    return _judge_generate_reviewed_section(
        section_name,
        section_builder,
        source_chunks,
        model,
        max_revisions,
        failure_policy,
        call_section_builder=_call_section_builder,
        has_historical_data=_has_historical_data,
        trace=_terminal_trace,
        logger=logger,
        initial_feedback=initial_feedback,
        previous_candidate=previous_candidate,
        prepare_payload=_prepare_multimodal_payload,
    )


def _review_section_candidate(section_name, source_chunks, candidate, model):
    """Compatibility adapter; judge evaluation lives in agents.llm_judge."""
    return _judge_review_section_candidate(
        section_name,
        source_chunks,
        candidate,
        model,
        _prepare_multimodal_payload,
        _terminal_trace,
    )


def _review_report_candidate(candidate, model):
    """Compatibility adapter; report rubrics live in agents.llm_judge."""
    return _judge_review_report_candidate(
        candidate, model, _to_human_message, _terminal_trace
    )


async def _review_complete_report(
    report,
    model,
    section_inputs,
    max_revisions,
    failure_policy,
):
    """Compatibility adapter; judge workflow lives in agents.llm_judge."""
    return await _judge_review_complete_report(
        report,
        model,
        section_inputs,
        max_revisions,
        failure_policy,
        logger=logger,
        trace=_terminal_trace,
        prepare_payload=_prepare_multimodal_payload,
        to_human_message=_to_human_message,
        call_section_builder=_call_section_builder,
        has_historical_data=_has_historical_data,
    )


# Ordered: defines the section order of the consolidated report.
SECTION_REGISTRY: Dict[str, Dict[str, Any]] = {
    "past_review": {
        "title": "Past Review Analysis",
        "builder": past_review_report,
        "data_key": "output1",
        "progress": (30, 40),
    },
    "policy_regulation": {
        "title": "Policy, KOD and Regulatory Analysis",
        "builder": policy_regulation,
        "data_key": "output2",
        "progress": (45, 60),
    },
    "broad_scope": {
        "title": "Broad Scope Direction",
        "builder": broad_scope_direction,
        "data_key": "output3",
        "progress": (65, 80),
    },
}


async def research_report(
    plan_data: Dict[str, Any],
    progress_callback: ProgressCallback = None,
    sections: Optional[List[str]] = None,
    previous_report: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    selected_keys = [key for key in SECTION_REGISTRY if not sections or key in sections]
    logger.info("Building consolidated research report sections=%s", selected_keys)
    _emit_progress(progress_callback, "running", "Preparing the section review.", 25, phase="preparing_sections")
    model = initialize_gemini_model()
    max_revisions, failure_policy = _review_settings()
    section_inputs = {
        SECTION_REGISTRY[key]["title"]: (
            SECTION_REGISTRY[key]["builder"],
            plan_data[SECTION_REGISTRY[key]["data_key"]],
        )
        for key in selected_keys
    }

    async def run_reviewed_section(section_key: str):
        title = SECTION_REGISTRY[section_key]["title"]
        builder = SECTION_REGISTRY[section_key]["builder"]
        source_chunks = plan_data[SECTION_REGISTRY[section_key]["data_key"]]
        return await asyncio.to_thread(
            _generate_reviewed_section,
            title,
            builder,
            source_chunks,
            model,
            max_revisions,
            failure_policy,
        )

    tasks = {
        key: asyncio.create_task(run_reviewed_section(key))
        for key in selected_keys
    }

    generated_sections: Dict[str, Any] = {}
    for key, task in tasks.items():
        title = SECTION_REGISTRY[key]["title"]
        start_progress, end_progress = SECTION_REGISTRY[key]["progress"]
        _emit_progress(
            progress_callback,
            "running",
            f"Generating section {title}.",
            start_progress,
            phase="generating_section",
            section=title,
        )
        generated_sections[title] = await task
        _emit_progress(
            progress_callback,
            "running",
            f"Section {title} is complete.",
            end_progress,
            phase="generating_section",
            section=title,
        )

    if isinstance(previous_report, dict) and previous_report:
        consolidated_report: Dict[str, Any] = {}
        for key, entry in SECTION_REGISTRY.items():
            title = entry["title"]
            if title in generated_sections:
                consolidated_report[title] = generated_sections[title]
            elif title in previous_report:
                consolidated_report[title] = previous_report[title]
    else:
        consolidated_report = dict(generated_sections)

    _emit_progress(progress_callback, "running", "Consolidating the completed sections.", 90, phase="consolidating_sections")
    _terminal_trace("complete-report", "candidate_before_judge", consolidated_report)

    consolidated_report = await _review_complete_report(
        consolidated_report,
        model,
        section_inputs,
        max_revisions,
        failure_policy,
    )

    _terminal_trace("complete-report", "candidate_after_judge", consolidated_report)
    logger.info("Consolidated research report built")
    _emit_progress(progress_callback, "running", "Final touch on the draft report.", 95, phase="final_touch")
    return consolidated_report


async def run_analytics_agent(
    _plan_number: str,
    plan_data: Dict[str, Any],
    progress_callback: ProgressCallback = None,
    sections: Optional[List[str]] = None,
    previous_report: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    logger.info("Running analytics agent")
    if previous_report is not None:
        try:
            return await research_report(
                plan_data,
                progress_callback=progress_callback,
                sections=sections,
                previous_report=previous_report,
            )
        except TypeError:
            pass
    return await research_report(plan_data, progress_callback=progress_callback, sections=sections)


_TRACE_LOCK = threading.Lock()


def _trace_enabled() -> bool:
    for name in ("LLM_JUDGE_DEBUG", "SUMMARY_AGENT_JUDGE_DEBUG"):
        value = os.getenv(name)
        if value is None:
            continue
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return False


def _terminal_trace(stage: str, label: str, _value: Any) -> None:
    if not _trace_enabled():
        return
    with _TRACE_LOCK:
        # Trace markers help locate the review stage without copying report,
        # source, or judge-feedback content into application logs.
        logger.debug("SUMMARY_AGENT_TRACE stage=%s label=%s", stage, label)

def _has_historical_data(source_chunks: List[dict]) -> bool:
    for chunk in source_chunks:
        if not isinstance(chunk, dict):
            continue
        if chunk.get("source_name") == "historical_review_document":
            return True
        if chunk.get("source_name") == "historical_plan_item_details" and chunk.get("content"):
            return True
    return False


def _current_plan_number(source_chunks: List[dict]) -> str:
    for chunk in source_chunks:
        if not isinstance(chunk, dict) or chunk.get("source_name") != CURRENT_PLAN_SOURCE:
            continue
        content = chunk.get("content")
        if isinstance(content, dict):
            return str(content.get("Plan Item Number") or "")
    return ""
