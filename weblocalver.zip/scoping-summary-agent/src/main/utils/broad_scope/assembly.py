"""Assemble the Broad Scope Direction report from per-source-group model outputs."""

import logging
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from model.response_model import (
    BroadScopeCollationOutput,
    ParagraphCitation,
    ParagraphMetadata,
    ScopingReport,
    SupportingCitation,
)
from utils.broad_scope.dbgrc import (
    NO_BOUNDARY_TEXT,
    NOT_GENERATED_TEXT,
    RISK_DRIVERS_TITLE,
    RISK_DRIVERS_UNAVAILABLE_TEXT,
    SECTION1_TITLE,
    SECTION2_INTRO,
    SECTION2_TITLE,
    SECTION3_TITLE,
    SIDE_TITLES,
    BroadScopePart,
)

logger = logging.getLogger(__name__)


def _paragraph(content: str, **metadata: Any) -> ParagraphCitation:
    return ParagraphCitation(
        paragraph_id="",
        content=content,
        supporting_chunk_ids=[],
        supporting_citations=[],
        rationale=metadata.pop("rationale", None),
        metadata=ParagraphMetadata(
            is_section_start=metadata.pop("is_section_start", False),
            section_confidence_score=metadata.pop("section_confidence_score", None),
            heading_level=metadata.pop("heading_level", None),
        ),
    )


def _as_continuation(paragraphs: Iterable[ParagraphCitation]) -> List[ParagraphCitation]:
    """Sub-call paragraphs never start a section; the section heading and rationale are set by code."""
    result = list(paragraphs)
    for paragraph in result:
        paragraph.metadata.is_section_start = False
        paragraph.metadata.section_confidence_score = None
        paragraph.rationale = None
    return result


def _as_section(paragraphs: Iterable[ParagraphCitation]) -> List[ParagraphCitation]:
    """Keep the model's first paragraph as the section start and demote the rest."""
    result = list(paragraphs)
    if result:
        result[0].metadata.is_section_start = True
        _as_continuation(result[1:])
    return result


def _unit_texts(paragraph: ParagraphCitation) -> List[Tuple[str, List[str], list]]:
    if isinstance(paragraph.content, str):
        return [(paragraph.content, paragraph.supporting_chunk_ids, paragraph.supporting_citations)]
    return [(unit.content, unit.supporting_chunk_ids, unit.supporting_citations) for unit in paragraph.content]


def restrict_citations(paragraphs: Iterable[ParagraphCitation], allowed_ids: Set[str], context: str) -> None:
    """Drop chunk IDs a call cited from outside its own input, so every citation stays resolvable."""
    dropped: Set[str] = set()

    def keep_ids(ids: List[str]) -> List[str]:
        kept = []
        for chunk_id in ids:
            if str(chunk_id) in allowed_ids:
                kept.append(str(chunk_id))
            else:
                dropped.add(str(chunk_id))
        return kept

    def keep_citations(citations: list) -> list:
        kept = []
        for citation in citations:
            if str(citation.chunk_id) in allowed_ids:
                kept.append(citation)
            else:
                dropped.add(str(citation.chunk_id))
        return kept

    for paragraph in paragraphs:
        paragraph.supporting_chunk_ids = keep_ids(paragraph.supporting_chunk_ids)
        paragraph.supporting_citations = keep_citations(paragraph.supporting_citations)
        if isinstance(paragraph.content, str):
            continue
        for unit in paragraph.content:
            unit.supporting_chunk_ids = keep_ids(unit.supporting_chunk_ids)
            unit.supporting_citations = keep_citations(unit.supporting_citations)
            if unit.citation_status == "supported" and not unit.supporting_chunk_ids and not unit.supporting_citations:
                unit.citation_status = "unsupported"

    if dropped:
        logger.warning("Broad scope %s cited chunk IDs outside its input; dropped=%s", context, sorted(dropped))


def cited_chunk_ids(paragraphs: Iterable[ParagraphCitation]) -> Set[str]:
    ids: Set[str] = set()
    for paragraph in paragraphs:
        for _text, chunk_ids, citations in _unit_texts(paragraph):
            ids.update(str(chunk_id) for chunk_id in chunk_ids)
            ids.update(str(citation.chunk_id) for citation in citations)
    return ids


DraftRefs = Dict[str, List[SupportingCitation]]


def _unit_citations(chunk_ids: List[str], citations: list) -> List[SupportingCitation]:
    """Page-aware citations of a draft unit, plus a page-less citation for any chunk ID they do not cover."""
    result = [SupportingCitation(chunk_id=str(c.chunk_id), page_number=c.page_number) for c in citations]
    covered = {citation.chunk_id for citation in result}
    result.extend(SupportingCitation(chunk_id=str(chunk_id)) for chunk_id in chunk_ids if str(chunk_id) not in covered)
    return result


def draft_for_collation(paragraphs: Iterable[ParagraphCitation]) -> Tuple[List[Dict[str, Any]], DraftRefs]:
    """Compact view of Sections 1-2 for the collation call.

    Each source-backed unit gets a short `ref` (D1, D2, ...) instead of raw chunk IDs. The model cites the ref of
    the Section 1/2 unit a Section 3 point is based on, and `resolve_draft_refs` swaps it for that unit's original
    data citations, so Section 3 links to the actual source documents and pages.
    """
    draft: List[Dict[str, Any]] = []
    refs: DraftRefs = {}
    for paragraph in paragraphs:
        for text, chunk_ids, citations in _unit_texts(paragraph):
            unit: Dict[str, Any] = {"text": text}
            unit_citations = _unit_citations(chunk_ids, citations)
            if unit_citations:
                ref = f"D{len(refs) + 1}"
                refs[ref] = unit_citations
                unit["ref"] = ref
            draft.append(unit)
    return draft, refs


def _resolve_refs(chunk_ids: List[str], citations: list, refs: DraftRefs) -> List[SupportingCitation]:
    resolved: List[SupportingCitation] = []
    covered: Set[str] = set()
    for citation in citations:
        covered.add(str(citation.chunk_id))
        if str(citation.chunk_id) in refs:
            resolved.extend(refs[str(citation.chunk_id)])
        else:
            resolved.append(citation)
    for chunk_id in chunk_ids:
        if str(chunk_id) in covered:
            continue
        resolved.extend(refs.get(str(chunk_id)) or [SupportingCitation(chunk_id=str(chunk_id))])

    unique: List[SupportingCitation] = []
    seen: Set[Tuple[str, Optional[int]]] = set()
    for citation in resolved:
        key = (str(citation.chunk_id), citation.page_number)
        if key not in seen:
            seen.add(key)
            unique.append(citation.model_copy())
    return unique


def resolve_draft_refs(paragraphs: Iterable[ParagraphCitation], refs: DraftRefs) -> None:
    """Replace draft refs cited by the collation call with the original Section 1/2 data citations."""
    for paragraph in paragraphs:
        targets = [paragraph] if isinstance(paragraph.content, str) else paragraph.content
        for target in targets:
            citations = _resolve_refs(target.supporting_chunk_ids, target.supporting_citations, refs)
            target.supporting_citations = citations
            target.supporting_chunk_ids = list(dict.fromkeys(citation.chunk_id for citation in citations))
            if citations and getattr(target, "citation_status", None) == "unsupported":
                target.citation_status = "supported"


def build_section1(parts: List[BroadScopePart]) -> List[ParagraphCitation]:
    section1 = [
        paragraph
        for part in parts
        if part.status == "ok" and part.output is not None
        for paragraph in part.output.section1
    ]
    if not section1:
        logger.warning("Broad scope Section 1 was not generated")
        return [_paragraph(f"{SECTION1_TITLE}\n{NOT_GENERATED_TEXT}", is_section_start=True)]
    return _as_section(section1)


def _risk_driver_label(driver: Dict[str, Any], risk_id: str) -> str:
    """"R019 - RD2" -> "RD2"; the risk ID is already shown in the Risk Info line."""
    driver_id = str(driver.get("riskDriverId") or "").strip()
    prefix = f"{risk_id} - "
    return driver_id[len(prefix):] if risk_id and driver_id.startswith(prefix) else driver_id


def build_risk_driver_paragraphs(risk_driver_chunk: Optional[Dict[str, Any]]) -> List[ParagraphCitation]:
    """Render dbGRC risk_driver_details.json as-is (no model call): one paragraph per plan risk."""
    title = _paragraph(RISK_DRIVERS_TITLE, heading_level=3)
    risks = (risk_driver_chunk or {}).get("content")
    if not isinstance(risks, list) or not risks:
        return [title, _paragraph(RISK_DRIVERS_UNAVAILABLE_TEXT)]

    chunk_ids = [str(risk_driver_chunk["chunk_id"])] if risk_driver_chunk.get("chunk_id") is not None else []
    paragraphs = [title]
    for risk in risks:
        if not isinstance(risk, dict):
            continue
        risk_id = str(risk.get("riskid") or "").strip()
        drivers = [driver for driver in risk.get("risk_drivers") or [] if isinstance(driver, dict)]
        lines = [f"**Risk Info:** {risk_id} : {risk.get('risk_name') or ''}".rstrip()]
        if not drivers:
            lines.append("**Relevant Risk Driver Info:** No relevant risk drivers identified.")
        else:
            lines.append(f"**Relevant Risk Driver Info:** {len(drivers)} relevant risk driver(s) identified.")
            for driver in drivers:
                lines.append(
                    f"- **{_risk_driver_label(driver, risk_id)}**: {driver.get('riskDrivers') or 'Data Not Available'}"
                )
                lines.append(f"    - **Rationale:** {driver.get('rationale') or 'Data Not Available'}")
        paragraph = _paragraph("\n".join(lines))
        paragraph.supporting_chunk_ids = list(chunk_ids)
        paragraphs.append(paragraph)
    return paragraphs


def _side_paragraphs(part: BroadScopePart, side: str, is_first_side: bool) -> List[ParagraphCitation]:
    if part.status == "ok" and part.output is not None:
        return _as_continuation(getattr(part.output, side))
    # Placeholders appear once, under the first side the group is laid out in.
    if not is_first_side:
        return []
    if part.status == "failed":
        return [_paragraph(NOT_GENERATED_TEXT)]
    if part.unavailable_text:
        return [_paragraph(part.unavailable_text)]
    return []


def build_section2(parts: List[BroadScopePart], layout: Dict[str, List[str]]) -> List[ParagraphCitation]:
    """Section 2 heading, then A. In-scope / B. Out of scope with the group blocks in `layout` order."""
    parts_by_key = {part.key: part for part in parts}
    seen: Set[str] = set()
    paragraphs = [_paragraph(f"{SECTION2_TITLE}\n{SECTION2_INTRO}", is_section_start=True)]
    for side, title in SIDE_TITLES:
        paragraphs.append(_paragraph(title, heading_level=2))
        side_start = len(paragraphs)
        for key in layout.get(side, []):
            part = parts_by_key.get(key)
            if part is None:
                continue
            body = _side_paragraphs(part, side, key not in seen)
            seen.add(key)
            if body:
                if part.label:
                    paragraphs.append(_paragraph(f"**{part.label}**", heading_level=3))
                paragraphs.extend(body)
        if len(paragraphs) == side_start:
            paragraphs.append(_paragraph(NO_BOUNDARY_TEXT))
    return paragraphs


def finalize_broad_scope_report(
    section1: List[ParagraphCitation],
    section2: List[ParagraphCitation],
    collation: Optional[BroadScopeCollationOutput],
    report_title: str,
) -> ScopingReport:
    section3: List[ParagraphCitation] = []
    if collation is not None:
        section2[0].rationale = collation.section2_rationale
        section2[0].metadata.section_confidence_score = collation.section2_confidence_score
        section3 = _as_section(collation.section3)
    if not section3:
        logger.warning("Broad scope Section 3 was not generated")
        section3 = [_paragraph(f"{SECTION3_TITLE}\n{NOT_GENERATED_TEXT}", is_section_start=True)]

    paragraphs = [*section1, *section2, *section3]
    for index, paragraph in enumerate(paragraphs, start=1):
        paragraph.paragraph_id = f"para_{index}"
    return ScopingReport(report_title=report_title, paragraphs=paragraphs)
