"""dbGRC control compaction and Broad Scope part output normalization."""

import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from model.response_model import (
    BroadScopePartOutput,
    NarrativeUnit,
    ParagraphCitation,
    ParagraphMetadata,
    SupportingCitation,
)

SECTION1_TITLE = "**Section 1: Broad Scope Direction**"
SECTION2_TITLE = "**Section 2: Indicative Scope Boundaries**"
SECTION2_INTRO = (
    "The following in-scope and out-of-scope boundaries are indicative, based on the available data from the "
    "current plan, historical reviews, dbGRC, GFMS, Group Audit, and other contextual sources. These proposals are "
    "intended to serve as a starting point for discussion and require confirmation with business stakeholders."
)
SECTION3_TITLE = "**Section 3: Scope Validation and Walkthrough Preparation**"
SIDE_TITLES: Tuple[Tuple[str, str], ...] = (
    ("in_scope", "**A. In-scope**"),
    ("out_of_scope", "**B. Out of scope**"),
)
NOT_GENERATED_TEXT = "This part could not be generated. Please regenerate the Broad Scope Direction section."
NO_BOUNDARY_TEXT = "No indicative boundaries were identified from the available data."
RISK_DRIVERS_TITLE = "**Risk and Risk Driver Information**"
RISK_DRIVERS_UNAVAILABLE_TEXT = "Data Not Available - no risk driver data was retrieved for this plan."


@dataclass
class BroadScopePart:
    key: str
    label: Optional[str]
    status: str = "skipped"  # "ok" | "skipped" | "failed"
    output: Optional[BroadScopePartOutput] = None
    unavailable_text: Optional[str] = None


# dbGRC rows repeat the full control definition/objective once per (instance, risk) pair; send it once per control.
DBGRC_DEFINITION_FIELDS = (
    "controlDefinitionName", "controlDefinitionStatus", "classification", "controlWhat", "controlHow",
    "controlWhy", "description", "controlAutomation", "controlObjectiveNumber", "controlObjectiveName",
    "controlObjectiveDescription", "supplementalGuidance", "mcsRelevant",
)
DBGRC_RISK_FIELDS = ("riskId", "riskTypeLevel2", "riskTypeLevel3", "riskTypeLevel4")
DBGRC_INSTANCE_DROP_FIELDS = {
    "controlWhat", "controlHow", "controlWhy", "controlDescription", "snapshotDate",
    "controlDefSysCreatedOn", "controlDefSysUpdatedOn", "riskStmtSysCreatedOn", "riskStmtSysUpdatedOn",
    *DBGRC_RISK_FIELDS,
}


def _dbgrc_control_id(inventory: Dict[str, Any]) -> str:
    return str(inventory.get("controlDefinitionNumber") or inventory.get("externalReferenceId") or "")


def _plan_au_name(au: Any) -> str:
    """AU name segment of a plan AU-RT-KC `AU` value; the same segment dbGRC extraction matches instances on."""
    parts = str(au or "").split("~")
    return parts[4].strip() if len(parts) > 4 else ""


def control_level_kc_ids(current_plan: Any) -> Set[str]:
    """KCs the plan lists only on AU-RT-KC rows without an AU.

    A control becomes an instance once applied to an AU, so these KCs have no plan instance: they are reported at
    control level only. Decided from the plan data in code, never by the model.
    """
    rows = current_plan.get("AU-RT-KC") if isinstance(current_plan, dict) else None
    aligned: Set[str] = set()
    unaligned: Set[str] = set()
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        kc = str(row.get("KC") or "").strip()
        if kc:
            (aligned if _plan_au_name(row.get("AU")) else unaligned).add(kc)
    return unaligned - aligned


def _definition_fields(record: Dict[str, Any], inventory: Dict[str, Any]) -> Dict[str, Any]:
    source = {**inventory, **(record.get("objective") or {}), **(record.get("definition") or {})}
    return {field: source[field] for field in DBGRC_DEFINITION_FIELDS if source.get(field) is not None}


def _add_risk_tag(risk_tags: List[Dict[str, Any]], inventory: Dict[str, Any]) -> None:
    risk = {field: inventory.get(field) for field in DBGRC_RISK_FIELDS if inventory.get(field) is not None}
    if risk and risk not in risk_tags:
        risk_tags.append(risk)


def compact_dbgrc_controls(content: Any, current_plan: Any = None) -> Any:
    """Shrink dbGRC control_details for the model without changing its included/excluded classification.

    Control definition and objective fields go once into `control_definitions`; each control instance is listed
    once per category with all its risk tags in `risk_tags` (rows are only merged when every instance field matches).
    KCs the plan does not align to any AU (see `control_level_kc_ids`) carry no instance data: they go to
    `control_level_included_kcs` / `control_level_excluded_kcs` with their definition fields and the de-duplicated
    risks of all their dbGRC rows. A control-level KC is excluded only when none of its rows is included.
    """
    if not isinstance(content, dict) or not any(key in content for key in ("included_kcs", "excluded_kcs")):
        return content

    control_level_ids = control_level_kc_ids(current_plan)
    definitions: Dict[str, Dict[str, Any]] = {}
    control_level: Dict[str, Dict[str, Any]] = {}
    control_level_reasons: Dict[str, Any] = {}
    control_level_included: Set[str] = set()

    def add_control_level_row(
        control_id: str,
        record: Dict[str, Any],
        inventory: Dict[str, Any],
        row: Dict[str, Any],
        wrapped: bool,
    ) -> None:
        entry = control_level.setdefault(control_id, {"controlDefinitionNumber": control_id, "risk_tags": []})
        for field, value in _definition_fields(record, inventory).items():
            entry.setdefault(field, value)
        _add_risk_tag(entry["risk_tags"], inventory)
        if wrapped:
            control_level_reasons.setdefault(control_id, row.get("reason"))
        else:
            control_level_included.add(control_id)

    def add_rows(rows: list, wrapped: bool) -> List[Dict[str, Any]]:
        instances: Dict[str, Dict[str, Any]] = {}
        result: List[Dict[str, Any]] = []
        for row in rows or []:
            record = row.get("details") if wrapped else row
            if not isinstance(record, dict):
                result.append(row)  # e.g. MISSING_IN_DBGRC: no dbGRC record, keep as-is
                continue
            inventory = record.get("inventory") or {}
            control_id = _dbgrc_control_id(inventory)
            if control_id in control_level_ids:
                add_control_level_row(control_id, record, inventory, row, wrapped)
                continue
            if control_id not in definitions:
                definitions[control_id] = _definition_fields(record, {})
            instance = {"controlDefinitionNumber": control_id}
            if wrapped:
                instance["reason"] = row.get("reason")
            instance.update({k: v for k, v in inventory.items() if k not in DBGRC_INSTANCE_DROP_FIELDS and v is not None})
            key = json.dumps(instance, sort_keys=True, default=str)
            if key not in instances:
                instances[key] = {**instance, "risk_tags": []}
                result.append(instances[key])
            _add_risk_tag(instances[key]["risk_tags"], inventory)
        return result

    included = add_rows(content.get("included_kcs"), wrapped=False)
    excluded = add_rows(content.get("excluded_kcs"), wrapped=True)
    compacted = {k: v for k, v in content.items() if k not in ("included_kcs", "excluded_kcs")}
    compacted.update({"control_definitions": definitions, "included_kcs": included, "excluded_kcs": excluded})
    if control_level:
        compacted["control_level_included_kcs"] = [
            entry for control_id, entry in control_level.items() if control_id in control_level_included
        ]
        compacted["control_level_excluded_kcs"] = [
            {**entry, "reason": control_level_reasons.get(control_id)}
            for control_id, entry in control_level.items()
            if control_id not in control_level_included
        ]
    return compacted


def has_control_level_kcs(chunks: List[dict]) -> bool:
    return any(
        isinstance(chunk.get("content"), dict)
        and (chunk["content"].get("control_level_included_kcs") or chunk["content"].get("control_level_excluded_kcs"))
        for chunk in chunks
    )


def dbgrc_has_control_instances(group_chunks: List[dict]) -> bool:
    for chunk in group_chunks:
        if not isinstance(chunk, dict) or chunk.get("source_name") != "key_controls":
            continue
        content = chunk.get("content")
        if isinstance(content, dict) and (
            content.get("included_kcs")
            or content.get("excluded_kcs")
            or content.get("control_level_included_kcs")
            or content.get("control_level_excluded_kcs")
        ):
            return True
    return False


def _supported_unit_paragraph(para_id: str, text: str, chunk_ids: List[str]) -> ParagraphCitation:
    return ParagraphCitation(
        paragraph_id=para_id,
        content=[
            NarrativeUnit(
                content=text,
                citation_status="supported" if chunk_ids else "unsupported",
                supporting_chunk_ids=chunk_ids,
                supporting_citations=[
                    SupportingCitation(chunk_id=chunk_id, page_number=None)
                    for chunk_id in chunk_ids
                ],
            )
        ],
        rationale=None,
        supporting_chunk_ids=[],
        supporting_citations=[],
        metadata=ParagraphMetadata(is_section_start=False, section_confidence_score=None),
    )


def empty_dbgrc_fallback_paragraph(
    group_chunks: List[dict],
    current_plan_source: str = "current_plan_item_details",
) -> ParagraphCitation:
    kc_chunk = next(
        (chunk for chunk in group_chunks if isinstance(chunk, dict) and chunk.get("source_name") == "key_controls"),
        None,
    )
    plan_chunk = next(
        (chunk for chunk in group_chunks if isinstance(chunk, dict) and chunk.get("source_name") == current_plan_source),
        None,
    )
    plan_content = plan_chunk.get("content") if isinstance(plan_chunk, dict) else None
    has_plan_kcs = isinstance(plan_content, dict) and bool(
        plan_content.get("Key Controls") or plan_content.get("key_controls")
    )
    if has_plan_kcs:
        text = (
            "Based on data from dbGRC, no control instances were fetched from dbGRC for the key controls "
            "attached in the current plan."
        )
    else:
        text = (
            "Based on data from dbGRC, there are no key controls attached in the current plan and hence "
            "no controls were fetched from dbGRC."
        )
    chunk_ids = [
        str(chunk["chunk_id"])
        for chunk in (plan_chunk, kc_chunk)
        if isinstance(chunk, dict) and chunk.get("chunk_id") not in (None, "")
    ]
    return _supported_unit_paragraph("para_1", text, chunk_ids)


def empty_findings_ga_fallback_paragraphs(group_chunks: List[dict]) -> List[ParagraphCitation]:
    findings_chunk = next(
        (chunk for chunk in group_chunks if isinstance(chunk, dict) and chunk.get("source_name") == "findings"),
        None,
    )
    ga_chunk = next(
        (chunk for chunk in group_chunks if isinstance(chunk, dict) and chunk.get("source_name") == "group_audit"),
        None,
    )

    def _chunk_ids(chunk: Optional[dict]) -> List[str]:
        if isinstance(chunk, dict) and chunk.get("chunk_id") not in (None, ""):
            return [str(chunk["chunk_id"])]
        return []

    return [
        _supported_unit_paragraph(
            "para_1",
            "**Open Findings from GFMS**\nBased on data from GFMS, no open finding exists.",
            _chunk_ids(findings_chunk),
        ),
        _supported_unit_paragraph(
            "para_2",
            "**Group Audit Overlap**\nBased on data from Group Audit, no review overlapped with Group Audit.",
            _chunk_ids(ga_chunk),
        ),
    ]


def _paragraph_has_text(paragraph: ParagraphCitation) -> bool:
    if isinstance(paragraph.content, str):
        return bool(paragraph.content.strip())
    if isinstance(paragraph.content, list):
        return any(
            isinstance(unit, NarrativeUnit) and bool(str(unit.content or "").strip())
            for unit in paragraph.content
        )
    return False


def _drop_empty_paragraphs(paragraphs: Iterable[ParagraphCitation]) -> List[ParagraphCitation]:
    return [paragraph for paragraph in paragraphs if _paragraph_has_text(paragraph)]


def normalize_broad_scope_part_output(
    key: str,
    output: Optional[Any],
    group_chunks: List[dict],
) -> None:
    if output is None:
        return
    output.section1 = _drop_empty_paragraphs(output.section1)
    output.in_scope = _drop_empty_paragraphs(output.in_scope)
    output.out_of_scope = _drop_empty_paragraphs(output.out_of_scope)
    if key in {"findings_ga", "alc_nc"} and not output.out_of_scope and (output.in_scope or output.section1):
        output.out_of_scope = [*output.section1, *output.in_scope]
        output.section1 = []
        output.in_scope = []
    elif key != "historical" and not output.in_scope and not output.out_of_scope and output.section1:
        output.in_scope = list(output.section1)
        output.section1 = []
    if key == "findings_ga" and not output.out_of_scope:
        output.out_of_scope = empty_findings_ga_fallback_paragraphs(group_chunks)
