"""GCS path builders and low-level plan JSON readers."""

import asyncio
import logging
import re
from typing import Any, Dict, Optional

from config.config import Config

logger = logging.getLogger(__name__)


def _dm():
    import utils.data_manager as dm
    return dm


def _base_prefix(plan_number: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number),
    )
    parts = [p.strip("/") for p in [Config.REVIEW_BUCKET_PREFIX, plan_folder, Config.REVIEW_INBOUND_DATA_FOLDER] if p]
    return "/".join(parts)


def _historical_bucket_name() -> str:
    return Config.HISTORICAL_REVIEW_BUCKET_NAME or Config.REVIEW_BUCKET_NAME


def _plan_blob_path(plan_number: str, folder: str, file_name: str) -> str:
    return "/".join([_base_prefix(plan_number), folder, file_name])


def _build_gs_uri(blob_path: str, bucket_name: Optional[str] = None) -> str:
    resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
    return f"gs://{resolved_bucket_name}/{blob_path.lstrip('/')}"


def _historical_documents_prefix(historical_plan_number: str) -> str:
    """Build the prefix that stores historical scoping docs for a historical review id."""
    parts = [
        p.strip("/")
        for p in [
            Config.HISTORICAL_REVIEW_DOCS_PREFIX,
            str(historical_plan_number),
        ]
        if p
    ]
    return "/".join(parts)


def get_plan_output_blob_path(plan_number: str, file_name: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    )
    outbound_folder = (Config.REVIEW_OUTBOUND_DATA_FOLDER).strip("/")

    parts = [
        p.strip("/")
        for p in [
            Config.REVIEW_BUCKET_PREFIX,
            plan_folder,
            outbound_folder,
            file_name,
        ]
        if p
    ]
    return "/".join(parts)


def get_preliminary_research_blob_path(plan_number: str) -> str:
    """Build preliminary research blob path under the plan folder.

    Target format:
    dbaware_review_{plan_number}/processing-data/preliminary-research/preliminary-research.json
    """
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    ).strip("/")
    outbound_folder = Config.REVIEW_OUTBOUND_DATA_FOLDER.strip("/")
    file_name = Config.REVIEW_OUTBOUND_DATA_FILE.strip("/")
    return "/".join([plan_folder, outbound_folder, file_name])


def get_preliminary_research_section_blob_path(plan_number: str, section_key: str) -> str:
    """Build the blob path of a single preliminary research section.

    Target format:
    dbaware_review_{plan_number}/processing-data/preliminary-research/{section_key}.json
    """
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    ).strip("/")
    outbound_folder = Config.REVIEW_OUTBOUND_DATA_FOLDER.strip("/")
    return "/".join([plan_folder, outbound_folder, f"{section_key}.json"])


def read_plan_json(plan_number: str, folder: str, file_name: str) -> Any:
    dm = _dm()
    candidates = [file_name]
    if not file_name.lower().endswith(".json"):
        candidates.append(f"{file_name}.json")
    checked_paths = []

    for candidate in candidates:
        path = dm._plan_blob_path(plan_number, folder, candidate)
        checked_paths.append(path)
        if dm.blob_exists(path):
            logger.info("Reading plan JSON blob path=%s", path)
            return path, dm.read_blob_json(path)

    logger.warning(
        "Plan JSON blob not found plan_number=%s folder=%s file_name=%s bucket=%s checked_paths=%s",
        plan_number,
        folder,
        file_name,
        Config.REVIEW_BUCKET_NAME,
        checked_paths,
    )
    return None, None


def _natural_key(path: str) -> list:
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", path)]


def _relevance(doc: Any) -> float:
    try:
        return float(doc.get("document_relevance_score"))
    except (AttributeError, TypeError, ValueError):
        return float("-inf")


async def read_plan_json_parts_async(plan_number: str, cfg: Dict[str, str]) -> Any:
    """Merge the per-document JSON parts in cfg['parts_folder'] into one list, most relevant first.

    Falls back to the legacy single file when the folder has no parts.
    """
    dm = _dm()
    prefix = dm._plan_blob_path(plan_number, cfg["parts_folder"], "")
    try:
        listed = await asyncio.to_thread(dm.list_blob_paths, prefix)
    except Exception:
        logger.exception("Failed to list parts prefix=%s", prefix)
        listed = []
    # list_blob_paths strips the trailing "/", so the legacy sibling file (relevant_policy.json) also matches.
    paths = sorted(
        (p for p in listed if p.startswith(prefix) and p.lower().endswith(".json")),
        key=_natural_key,
    )
    if not paths:
        logger.info("No parts under prefix=%s, falling back to %s", prefix, cfg["file_name"])
        return await asyncio.to_thread(dm.read_plan_json, plan_number, cfg["folder"], cfg["file_name"])

    contents = await asyncio.gather(*(asyncio.to_thread(dm.read_blob_json, p) for p in paths))

    documents: list = []
    for path, content in zip(paths, contents):
        if isinstance(content, list):
            documents.extend(d for d in content if isinstance(d, dict))
        elif isinstance(content, dict) and isinstance(content.get("documents"), list):
            documents.extend(d for d in content["documents"] if isinstance(d, dict))
        elif isinstance(content, dict):
            documents.append(content)
        else:
            logger.warning("Skipping unreadable part path=%s", path)

    # Stable sort keeps filename order for equal/missing scores.
    documents.sort(key=_relevance, reverse=True)
    logger.info("Merged %s parts into %s documents prefix=%s", len(paths), len(documents), prefix)
    return prefix.rstrip("/"), documents


def read_plan_json_by_path(path: str) -> Any:
    return _dm().read_blob_json(path)


def has_plan_data(plan_number: str) -> bool:
    dm = _dm()
    plan_details_config = Config.REVIEW_DATA_FILES["plan_details"]
    plan_details_path = dm._plan_blob_path(
        plan_number,
        plan_details_config["folder"],
        plan_details_config["file_name"],
    )
    logger.info(
        "Checking for plan data existence plan_number=%s path=%s",
        plan_number,
        plan_details_path,
    )
    exists = dm.blob_exists(plan_details_path)
    logger.info(
        "Plan data existence plan_number=%s path=%s exists=%s",
        plan_number,
        plan_details_path,
        exists,
    )
    return exists
