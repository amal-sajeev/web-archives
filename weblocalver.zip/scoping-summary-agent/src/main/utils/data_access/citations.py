"""Citation mapping construction and document retrieval."""

import base64
import json
import logging
from typing import Any, Dict
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


def _dm():
    import utils.data_manager as dm
    return dm


def read_citation_mapping(plan_number: str) -> Dict[str, str]:
    """Reads the chunk_id to path mapping file from blob storage."""
    dm = _dm()
    file_name = "citation_mapping.json"
    path = dm.get_plan_output_blob_path(plan_number, file_name)
    logger.info("Reading citation mapping from path=%s", path)
    if dm.blob_exists(path):
        return dm.read_blob_json(path)

    logger.warning("Citation mapping not found at path=%s", path)
    raise FileNotFoundError(f"Citation mapping for plan {plan_number} not found at {path}")


def create_citation_mapping(indexed_data: Dict[str, Any]) -> Dict[int, list]:
    """
    Creates a mapping from chunk_id to a list of citation details.

    This function processes indexed data to extract citation information.
    For certain source types (containing 'kod', 'policy', or 'scoping'), it
    attempts to extract detailed citations from the content. Otherwise, it
    falls back to using the metadata URL as the citation source.
    """
    chunk_id_path_mapping = {}
    source_keywords = ["kod", "policy", "scoping"]

    try:
        for key in indexed_data:
            if not isinstance(indexed_data.get(key), list):
                continue

            for chunk in indexed_data[key]:
                try:
                    chunk_id = chunk.get("chunk_id")
                    if not chunk_id:
                        logger.warning("Skipping chunk without chunk_id in key '%s'", key)
                        continue

                    citations_for_chunk = []
                    content = chunk.get("content")
                    source_name = chunk.get("source_name", "")
                    metadata = chunk.get("metadata", {})
                    url = metadata.get("url")

                    # Check if source_name contains keywords and content has 'citations'
                    if (any(keyword in source_name.lower() for keyword in source_keywords) and
                            isinstance(content, dict) and
                            "citations" in content and
                            isinstance(content.get("citations"), list)):

                        for citation in content["citations"]:
                            if isinstance(citation, dict):
                                doc_name = citation.get("document_name", "")
                                gs_uri = citation.get("gs_uri")
                                page_number = citation.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # parsing logic for new policy/kod/scoping structures using a "sources" list
                    if (not citations_for_chunk and
                            isinstance(content, dict) and
                            isinstance(content.get("sources"), list)):

                        for source in content["sources"]:
                            if isinstance(source, dict):
                                doc_name = source.get("document_name", "")
                                gs_uri = source.get("gs_uri")
                                page_number = source.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # Fallback to metadata URL if no content citations were found or applicable
                    if not citations_for_chunk and url:
                        doc_name = url.split("/")[-1]
                        lower_name = doc_name.lower()
                        fallback_content_type = (
                            "application/pdf"
                            if lower_name.endswith(".pdf")
                            else "application/json"
                        )
                        citations_for_chunk.append({
                            "content_type": fallback_content_type,
                            "document_name": doc_name,
                            "access_info": {"uri": url},
                            "location_metadata": {}
                        })

                    chunk_id_path_mapping[str(chunk_id)] = citations_for_chunk
                    logger.info("mapping created for chunk_id = %s, citations = %s", chunk_id, str(citations_for_chunk[0]))

                except Exception as e:
                    logger.error(
                        "Error processing chunk %s for citation mapping: %s",
                        chunk.get("chunk_id", "N/A"), e, exc_info=True
                    )

    except Exception as e:
        logger.error("Failed to create citation mapping. Error: %s", e, exc_info=True)

    return chunk_id_path_mapping


def process_citations(planNumber: str, chunk_id: int) -> Dict[str, Any]:
    """
    Fetches and processes the first citation document for a given chunk_id.
    """
    dm = _dm()
    try:
        logger.info(
            "Processing citation for plan_number=%s  chunk_id=%s",
            planNumber,
            chunk_id,
        )
        mapping = dm.read_citation_mapping(planNumber)  # Can raise FileNotFoundError
        chunk_id_str = str(chunk_id)
        citations = mapping.get(chunk_id_str) or mapping.get(chunk_id)
        logger.info("printing citation mapping ")
        print(mapping)
        if not citations:
            logger.warning("No citations found for chunk_id %s in plan %s", chunk_id, planNumber)
            raise FileNotFoundError(f"Document for chunk_id {chunk_id} not found in mapping for plan {planNumber}")

        # Per requirement, only process the first citation
        first_citation = citations[0]

        content_type = first_citation.get("content_type")
        uri = first_citation.get("access_info", {}).get("uri")

        if not uri:
            logger.error("First citation for chunk_id %s is missing a URI.", chunk_id)
            raise ValueError(f"Citation for chunk_id {chunk_id} is invalid; missing URI.")

        if content_type == "application/json":
            try:
                json_content = dm.read_plan_json_by_path(uri)
                return {"type": "json", "source": first_citation, "content": json_content}
            except FileNotFoundError:
                logger.error("JSON blob not found at path: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        elif content_type == "application/pdf":
            try:
                pdf_bytes = dm.read_blob_from_uri_as_bytes(uri)
                pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
                return {"type": "pdf", "source": first_citation, "content": pdf_base64}
            except FileNotFoundError:
                logger.error("PDF blob not found at URI: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        else:
            logger.warning("Unsupported content_type '%s' for chunk_id %s and uri %s", content_type, chunk_id, uri)
            return {"type": "unsupported", "source": first_citation}
    except FileNotFoundError:
        logger.warning("Citation file or chunk_id not found for plan_number=%s.", planNumber)
        raise
    except ValueError as e:
        logger.error(str(e))
        raise
    except Exception as exc:
        logger.exception("Unexpected error in process_citations. plan_number=%s chunk_id=%s", planNumber, chunk_id)
        raise RuntimeError(f"An unexpected error occurred while processing citations for chunk {chunk_id}.") from exc


def process_document_uri(document_uri: str, page_number: int = 1) -> Dict[str, Any]:
    """Fetches and processes a document directly from a gs:// URI."""
    dm = _dm()
    parsed_uri = urlparse(document_uri)
    if parsed_uri.scheme != "gs":
        raise ValueError("document_uri must use the gs:// scheme.")

    document_name = parsed_uri.path.rsplit("/", 1)[-1] if parsed_uri.path else "document"
    source = {
        "content_type": "application/octet-stream",
        "document_name": document_name,
        "access_info": {"uri": document_uri},
        "location_metadata": {"page_number": page_number},
    }

    if document_name.lower().endswith(".json"):
        raw_bytes = dm.read_blob_from_uri_as_bytes(document_uri)
        raw_text = raw_bytes.decode("utf-8")
        try:
            content = json.loads(raw_text)
        except json.JSONDecodeError:
            content = raw_text
        source["content_type"] = "application/json"
        return {"type": "json", "source": source, "content": content}

    if document_name.lower().endswith(".pdf"):
        pdf_bytes = dm.read_blob_from_uri_as_bytes(document_uri)
        pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
        source["content_type"] = "application/pdf"
        return {"type": "pdf", "source": source, "content": pdf_base64}

    return {"type": "unsupported", "source": source}
