"""Historical plan details and historical review document discovery."""

import logging
from typing import Any, Dict, Optional

from config.config import Config

logger = logging.getLogger(__name__)


def _dm():
    import utils.data_manager as dm
    return dm


def _extract_historical_plan_numbers(node: Any) -> list[str]:
    """Extract historical plan numbers from fixed historical_plan_details format.

    Expected input is a list of objects where each object contains
    "Plan Item Number".
    """
    if not isinstance(node, list):
        return []

    plan_numbers: list[str] = []
    for item in node:
        if not isinstance(item, dict):
            continue
        plan_number = item.get("Plan Item Number")
        if plan_number not in (None, ""):
            plan_numbers.append(str(plan_number).strip())

    deduped = []
    seen = set()
    for item in plan_numbers:
        if item not in seen:
            deduped.append(item)
            seen.add(item)
    return deduped


def _list_historical_review_documents(historical_plan_numbers: list[str]) -> list[Dict[str, Any]]:
    """Discover historical scoping documents for the given historical review ids.

    Expected layout: <historical_docs_prefix>/<historical_review_id>/<files>
    Only PDF files are currently attached to the model payload.
    """
    dm = _dm()
    documents: list[Dict[str, Any]] = []
    bucket_name = dm._historical_bucket_name()
    for historical_plan_number in historical_plan_numbers:
        prefix = dm._historical_documents_prefix(historical_plan_number)

        try:
            blob_paths = dm.list_blob_paths(prefix, bucket_name=bucket_name)
        except Exception:
            logger.exception(
                "Failed to list historical documents historical_plan_number=%s prefix=%s",
                historical_plan_number,
                prefix,
            )
            continue

        for blob_path in blob_paths:
            if blob_path.endswith("/"):
                continue
            if not blob_path.lower().endswith(".pdf"):
                logger.debug("Skipping unsupported historical document blob_path=%s", blob_path)
                continue

            documents.append(
                {
                    "historic_plan_number": str(historical_plan_number),
                    "document_name": blob_path.rsplit("/", 1)[-1],
                    "uri": dm._build_gs_uri(blob_path, bucket_name=bucket_name),
                }
            )

    logger.info(
        "Discovered historical review documents count=%s from_plans=%s",
        len(documents),
        [str(plan_number) for plan_number in historical_plan_numbers],
    )
    return documents


def _build_historical_document_chunk(document: Dict[str, Any]) -> Dict[str, Any]:
    """Build a standard source chunk for a historical review document."""
    return {
        "source_name": "historical_review_document",
        "metadata": {
            "url": document["uri"],
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
        "content": {
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
    }


def read_historical_plan_item_details(plan_number: str) -> list[dict[str, Any]]:
    """Return plan_item_number / plan_item_title rows from historical_plan_details.

    Reads:
    dbaware_review_{plan_number}/inbound-data/dbaware/historical_plan_details.json
    """
    dm = _dm()
    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    path, data = dm.read_plan_json(
        plan_number,
        historical_cfg["folder"],
        historical_cfg["file_name"],
    )

    if not path:
        expected_path = dm._plan_blob_path(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        )
        raise FileNotFoundError(
            f"Historical plan details not found for plan '{plan_number}' at '{expected_path}'."
        )

    if not isinstance(data, list):
        raise ValueError("historical_plan_details.json must contain a list of dictionaries.")

    response: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        if item.get("Plan Item Number") in (None, ""):
            logger.warning("Skipping historical plan row without Plan Item Number plan_number=%s", plan_number)
            continue
        response.append(
            {
                "plan_item_number": item.get("Plan Item Number"),
                "plan_item_title": item.get("Plan Item Title"),
            }
        )

    logger.info(
        "Prepared historical plan item details plan_number=%s rows=%s",
        plan_number,
        len(response),
    )
    return response


def delete_historical_plan_item(
    plan_number: str,
    plan_item_numbers: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Delete entries from historical_plan_details by Plan Item Number.

    Titles are not unique across years, so rows are matched on the number only.

    Reads and writes:
    dbaware_review_{plan_number}/inbound-data/dbaware/historical_plan_details.json
    """
    dm = _dm()
    number_set = {
        str(value).strip()
        for value in (plan_item_numbers or [])
        if str(value).strip()
    }

    if not number_set:
        raise ValueError("At least one Plan Item Number is required.")

    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    path, data = dm.read_plan_json(
        plan_number,
        historical_cfg["folder"],
        historical_cfg["file_name"],
    )

    if not path:
        expected_path = dm._plan_blob_path(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        )
        raise FileNotFoundError(
            f"Historical plan details not found for plan '{plan_number}' at '{expected_path}'."
        )

    if not isinstance(data, list):
        raise ValueError("historical_plan_details.json must contain a list of dictionaries.")

    remaining: list[Any] = []
    deleted: list[dict[str, Any]] = []

    for item in data:
        if not isinstance(item, dict):
            remaining.append(item)
            continue

        item_number = str(item.get("Plan Item Number") or "").strip()

        if item_number in number_set:
            deleted.append(
                {
                    "plan_item_number": item.get("Plan Item Number"),
                    "plan_item_title": item.get("Plan Item Title"),
                }
            )
            continue

        remaining.append(item)

    if not deleted:
        raise LookupError(
            "No matching record found in historical_plan_details.json for provided filter."
        )

    dm.write_blob_json(path, remaining)

    logger.info(
        "Deleted historical plan item details plan_number=%s deleted_count=%s remaining_count=%s",
        plan_number,
        len(deleted),
        len(remaining),
    )
    return {
        "plan_number": str(plan_number),
        "deleted_count": len(deleted),
        "remaining_count": len(remaining),
        "deleted": deleted,
    }
