"""Asynchronous loader and chunk id indexer for scoping plan data."""

import asyncio
import logging
from typing import Any, Dict

from config.config import Config

logger = logging.getLogger(__name__)


def _dm():
    import utils.data_manager as dm
    return dm


async def read_plan_data_async(plan_number: str) -> Dict[str, Any]:
    logger.info("Reading plan data asynchronously plan_number=%s", plan_number)
    return await _dm().get_standard_scoping_data_async(plan_number)


def _unpack_plan_json(result: Any) -> tuple:
    """Normalize the output of read_plan_json into (url, content).

    read_plan_json returns (path, data) when the blob is found, or (None, None) when it
    is missing. This helper safely handles both cases so callers always get a
    (url, content) pair without risking a KeyError/IndexError on missing data.
    """
    if isinstance(result, tuple) and len(result) == 2:
        return result[0], result[1]
    return None, result


async def get_standard_scoping_data_async(plan_number: str) -> Dict[str, Any]:
    dm = _dm()
    logger.debug("Building standard scoping data asynchronously")
    complete_plan_cfg = Config.REVIEW_DATA_FILES["plan_details"]
    internet_cfg = Config.REVIEW_DATA_FILES["internet_search_data"]
    findings_cfg = Config.REVIEW_DATA_FILES["findings_details"]
    group_audit_cfg = Config.REVIEW_DATA_FILES["group_audit_details"]
    controls_cfg = Config.REVIEW_DATA_FILES["control_details"]
    risk_driver_cfg = Config.REVIEW_DATA_FILES["risk_driver_details"]
    relevant_kod = Config.REVIEW_DATA_FILES["relevant_kod"]
    relevant_policy = Config.REVIEW_DATA_FILES["relevant_policy"]
    alternate_cfg = Config.REVIEW_DATA_FILES["alc_nalc_details"]
    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    relevant_procedure = Config.REVIEW_DATA_FILES["relevant_procedure"]

    (
        current_plan_data,
        internet_search_data,
        findings_data,
        group_audit_data,
        controls_data,
        risk_driver_data,
        relevant_kod,
        relevant_policy,
        relevant_procedure,
        alternate_coverage_data,
        historical_data,
    ) = await asyncio.gather(
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            complete_plan_cfg["folder"],
            complete_plan_cfg["file_name"],
        ),
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            internet_cfg["folder"],
            internet_cfg["file_name"],
        ),
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            findings_cfg["folder"],
            findings_cfg["file_name"],
        ),
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            group_audit_cfg["folder"],
            group_audit_cfg["file_name"],
        ),
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            controls_cfg["folder"],
            controls_cfg["file_name"],
        ),
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            risk_driver_cfg["folder"],
            risk_driver_cfg["file_name"],
        ),
        dm.read_plan_json_parts_async(plan_number, relevant_kod),
        dm.read_plan_json_parts_async(plan_number, relevant_policy),
        dm.read_plan_json_parts_async(plan_number, relevant_procedure),
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            alternate_cfg["folder"],
            alternate_cfg["file_name"],
        ),
        asyncio.to_thread(
            dm.read_plan_json,
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        ),
    )

    current_plan_url, current_plan_data = _unpack_plan_json(current_plan_data)
    internet_search_url, internet_search_data = _unpack_plan_json(internet_search_data)
    findings_url, findings_data = _unpack_plan_json(findings_data)
    group_audit_url, group_audit_data = _unpack_plan_json(group_audit_data)
    controls_url, controls_data = _unpack_plan_json(controls_data)
    risk_driver_url, risk_driver_data = _unpack_plan_json(risk_driver_data)
    relevant_kod_url, relevant_kod = _unpack_plan_json(relevant_kod)
    relevant_policy_url, relevant_policy = _unpack_plan_json(relevant_policy)
    relevant_procedure_url, relevant_procedure = _unpack_plan_json(relevant_procedure)
    alternate_coverage_url, alternate_coverage_data = _unpack_plan_json(alternate_coverage_data)
    historical_url, historical_data = _unpack_plan_json(historical_data)
    historical_plan_numbers = dm._extract_historical_plan_numbers(historical_data)
    historical_documents = dm._list_historical_review_documents(historical_plan_numbers)

    output1 = [
        {
            "source_name": "current_plan_item_details",
            "metadata": {"url": current_plan_url},
            "content": current_plan_data,
        },
        {
            "source_name": "historical_plan_item_details",
            "metadata": {"url": historical_url},
            "content": historical_data,
        },
    ]
    # Build independent chunk dicts per output; add_chunk_id mutates in place and
    # sharing objects across outputs would silently overwrite/gap their chunk_id.
    output1.extend(
        dm._build_historical_document_chunk(document)
        for document in historical_documents
    )

    data = {
        "output1": output1,
        "output2": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            },
        ],
        "output3": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "alternate_coverage",
                "metadata": {"url": alternate_coverage_url},
                "content": alternate_coverage_data,
            },
            {
                "source_name": "group_audit",
                "metadata": {"url": group_audit_url},
                "content": group_audit_data,
            },
            {
                "source_name": "key_controls",
                "metadata": {"url": controls_url},
                "content": controls_data,
            },
            {
                "source_name": "risk_drivers",
                "metadata": {"url": risk_driver_url},
                "content": risk_driver_data,
            },
            {
                "source_name": "findings",
                "metadata": {"url": findings_url},
                "content": findings_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            },
            *(
                dm._build_historical_document_chunk(document)
                for document in historical_documents
            ),
        ],
    }

    # A missing configured blob is returned as (None, None). Do not expose it
    # as a numbered prompt chunk: it has no URI that get_document can resolve.
    for output_name, chunks in data.items():
        resolved_chunks = []
        for chunk in chunks:
            metadata = chunk.get("metadata") or {}
            content = chunk.get("content") or {}
            embedded_citations = (
                content.get("citations") or content.get("sources")
                if isinstance(content, dict)
                else None
            )
            has_embedded_uri = (
                isinstance(embedded_citations, list)
                and any(
                    isinstance(citation, dict) and citation.get("gs_uri")
                    for citation in embedded_citations
                )
            )
            if metadata.get("url") or has_embedded_uri:
                resolved_chunks.append(chunk)
                continue
            logger.warning(
                "Skipping unresolved source chunk plan_number=%s output=%s source_name=%s",
                plan_number,
                output_name,
                chunk.get("source_name"),
            )
        data[output_name] = resolved_chunks

    indexed_data = dm.add_chunk_id(data)
    chunk_id_path_mapping = dm.create_citation_mapping(indexed_data)
    return indexed_data, chunk_id_path_mapping


def add_chunk_id(data):
    """Assign chunk ids across all outputs.

    Historical review documents get a stable string id so that adding or removing
    historical reviews never shifts the numeric ids of the other sources.
    """
    chunk_id = 1

    for key in data:
        # Documents of a historical review are numbered per review (HIST|<plan>|<n>), in listing
        # order, so the id is the same in every output and independent of other reviews.
        historical_counts: Dict[str, int] = {}
        for chunk in data[key]:
            if chunk.get("source_name") == "historical_review_document":
                content = chunk.get("content") or {}
                plan = str(content.get("historic_plan_number"))
                historical_counts[plan] = historical_counts.get(plan, 0) + 1
                chunk["chunk_id"] = f"HIST|{plan}|{historical_counts[plan]}"
                continue
            chunk["chunk_id"] = chunk_id
            chunk_id += 1

    return data
