import os
import sys
import logging
from typing import Any
from langchain_google_genai import ChatGoogleGenerativeAI
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.config import Config


logger = logging.getLogger(__name__)


def initialize_gemini_model() -> Any:
    logger.info(
        "Initializing Vertex Gemini model=%s location=%s",
        Config.MODEL_NAME,
        Config.PROJECT_LOCATION,
    )
    return ChatGoogleGenerativeAI(
        model=Config.MODEL_NAME,
        project=Config.PROJECT_NAME,
        location=Config.PROJECT_LOCATION,
        temperature=Config.GENERATION_CONFIG["temperature"],
        top_p=Config.GENERATION_CONFIG["top_p"],
        top_k=Config.GENERATION_CONFIG.get("top_k"),
        max_output_tokens=Config.GENERATION_CONFIG.get("max_output_tokens"),
        safety_settings=Config.SAFETY_CONFIG['safety_settings']
    )
    
