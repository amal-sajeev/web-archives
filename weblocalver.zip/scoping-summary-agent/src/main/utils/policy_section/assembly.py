"""Deterministic assembly of Section 1 (Policy / Procedure / KOD) of the policy report."""

import logging
from typing import Any, Dict, List

from model.response_model import (
    ParagraphCitation,
    ParagraphMetadata,
    PolicyRegulationOutput,
    ScopingReport,
    SupportingCitation,
)
from utils.policy_section.manifest import (
    MISSING_SUMMARY_TEXT,
    POLICY_SOURCES,
    SECTION1_TITLE,
    _format_score,
    _section_heading,
    build_regulation_manifest,
)

logger = logging.getLogger(__name__)


def _render_sections(doc: dict, summaries: Dict[str, Any]) -> List[str]:
    blocks: List[str] = []
    for section in doc["sections"]:
        summary = summaries.get(section["key"])
        if summary is None:
            body = MISSING_SUMMARY_TEXT
        else:
            body = (
                f"{summary.summary.strip()}\n"
                f"Applicability: {summary.applicability.strip()}. {summary.relevance.strip()}"
            )
        heading = _section_heading(section["section_id"], section["section_title"])
        blocks.append(f"<u>{heading}</u>: {body}" if heading else body)
    return blocks


def _render_document(number: int, doc: dict) -> str:
    heading = f"{number}. **{doc['title']}**"
    if doc["applicability"]:
        heading += f" - {doc['applicability']}"

    detail_parts = []
    score = _format_score(doc["relevance_score"])
    if score is not None:
        detail_parts.append(f"Relevance Score: {score}")

    lines = [heading]
    if detail_parts:
        lines.append(" | ".join(detail_parts))
    rationale = str(doc["rationale"] or "").strip()
    if rationale:
        lines.append(rationale)
    return "\n".join(lines)


def _render_mandate(number: int, mandate: dict, summary: Any) -> str:
    """Mandate block laid out like a policy document: heading with applicability, rationale, body."""
    name = (summary.name.strip() if summary is not None else "") or mandate["risk_name"] or "Regulatory Mandate"
    heading = f"{number}. **{name}**"
    if summary is not None and summary.applicability.strip():
        heading += f" - {summary.applicability.strip()}"

    lines = [heading]
    if mandate["rationale"]:
        lines.append(str(mandate["rationale"]).strip())
    body = summary.content.strip() if summary is not None else str(mandate["mandate"] or "").strip()
    if body:
        lines.append(body)
    return "\n".join(lines)


def _section_citation_label(section: dict) -> str:
    section_id = section.get("section_id")
    if section_id:
        return f"Section {section_id}"
    return f"Section {section.get('section_title') or 'source'}"


def _paragraph(content: str, chunk_ids: List[Any], **metadata: Any) -> ParagraphCitation:
    normalized_ids = [str(chunk_id) for chunk_id in chunk_ids if chunk_id not in (None, "")]
    return ParagraphCitation(
        paragraph_id="",
        content=content,
        supporting_chunk_ids=normalized_ids,
        supporting_citations=[SupportingCitation(chunk_id=chunk_id) for chunk_id in normalized_ids],
        rationale=metadata.pop("rationale", None),
        metadata=ParagraphMetadata(
            is_section_start=metadata.pop("is_section_start", False),
            section_confidence_score=metadata.pop("section_confidence_score", None),
            heading_level=metadata.pop("heading_level", None),
        ),
    )


def _leading_text(content: Any) -> str:
    """Return the paragraph's leading text whether content is a string or narrative units."""
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        first = content[0]
        unit_text = getattr(first, "content", None)
        if unit_text is None and isinstance(first, dict):
            unit_text = first.get("content")
        if isinstance(unit_text, str):
            return unit_text
    return ""


def _drop_model_section1(paragraphs: List[ParagraphCitation]) -> List[ParagraphCitation]:
    """Guard against the model emitting its own Section 1 despite being told not to."""
    if not paragraphs or not _leading_text(paragraphs[0].content).lstrip().lower().startswith("section 1"):
        return paragraphs
    logger.warning("Model returned its own Section 1 in policy report paragraphs; discarding it")
    for index, paragraph in enumerate(paragraphs[1:], start=1):
        if paragraph.metadata.is_section_start:
            return paragraphs[index:]
    return []


def assemble_policy_report(
    output: PolicyRegulationOutput,
    manifest: Dict[str, dict],
    source_chunks: List[dict],
    report_title: str,
) -> ScopingReport:
    section1 = output.section1
    assessments = {item.doc_key: item for item in section1.document_assessments}
    summaries = {
        summary.key: summary
        for item in section1.document_assessments
        for summary in item.sections
    }

    expected_doc_keys = {doc["doc_key"] for entry in manifest.values() for doc in entry["documents"]}
    expected_section_keys = {
        section["key"] for entry in manifest.values() for doc in entry["documents"] for section in doc["sections"]
    }
    missing_sections = expected_section_keys - summaries.keys()
    if expected_doc_keys - assessments.keys() or missing_sections:
        logger.warning(
            "Policy report missing model output docs=%s sections=%s",
            sorted(expected_doc_keys - assessments.keys()),
            sorted(missing_sections),
        )
    unknown_keys = (summaries.keys() - expected_section_keys) | (assessments.keys() - expected_doc_keys)
    if unknown_keys:
        logger.warning("Policy report ignoring unknown model keys=%s", sorted(unknown_keys))

    current_plan_ids = [
        chunk.get("chunk_id") for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") == "current_plan_item_details"
    ]
    paragraphs: List[ParagraphCitation] = [
        _paragraph(
            f"{SECTION1_TITLE}\n{section1.intro.strip()}",
            current_plan_ids,
            is_section_start=True,
            section_confidence_score=section1.confidence_score,
            rationale=section1.rationale,
        )
    ]

    mandates = section1.regulatory_mandates
    mandate_summaries = {item.key: item for item in mandates.mandates}
    regulation_mandates = build_regulation_manifest(source_chunks)
    unknown_mandates = mandate_summaries.keys() - {m["key"] for m in regulation_mandates}
    if unknown_mandates:
        logger.warning("Policy report ignoring unknown mandate keys=%s", sorted(unknown_mandates))
    if not regulation_mandates:
        paragraphs.append(_paragraph(
            "**Regulatory Mandates**\nData Not Available - no regulatory mandates were retrieved for this plan.",
            [],
            heading_level=2,
        ))
    else:
        paragraphs.append(_paragraph("**Regulatory Mandates**", [], heading_level=2))
        for number, mandate in enumerate(regulation_mandates, start=1):
            summary = mandate_summaries.get(mandate["key"])
            if summary is None:
                logger.warning("Policy report missing mandate key=%s", mandate["key"])
            # Only evidence with a link has a citation_mapping entry; citing the rest would render dead links.
            linked_keys = [evidence["key"] for evidence in mandate["evidence"] if evidence["deep_link"]]
            paragraphs.append(_paragraph(_render_mandate(number, mandate, summary), linked_keys, heading_level=3))

    for source_name, _prefix, label in POLICY_SOURCES:
        entry = manifest[source_name]
        if not entry["documents"]:
            paragraphs.append(_paragraph(
                f"**{label}**\nData Not Available - no relevant {label} documents were retrieved for this plan.",
                [],
                heading_level=2,
            ))
            continue
        paragraphs.append(_paragraph(f"**{label}**", [], heading_level=2))
        for number, doc in enumerate(entry["documents"], start=1):
            paragraphs.append(_paragraph(
                _render_document(number, doc),
                [],
                heading_level=3,
            ))
            for section, section_text in zip(doc["sections"], _render_sections(doc, summaries)):
                paragraphs.append(_paragraph(section_text, [section["key"]]))

    paragraphs.extend(_drop_model_section1(list(output.report.paragraphs)))
    for index, paragraph in enumerate(paragraphs, start=1):
        paragraph.paragraph_id = f"para_{index}"

    return ScopingReport(report_title=report_title, paragraphs=paragraphs)
