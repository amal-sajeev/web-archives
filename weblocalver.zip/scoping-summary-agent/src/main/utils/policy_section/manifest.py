"""Policy, Procedure, KOD, and Regulatory manifest builders."""

import re
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

# (source_name, key prefix, display label) in the order the sub-sections are rendered.
POLICY_SOURCES = (
    ("relevant_policy", "POLICY", "Policy"),
    ("relevant_procedure", "PROCEDURE", "Procedure"),
    ("relevant_kod", "KOD", "KOD"),
)
SECTION1_TITLE = "Section 1: Policy, KOD/Procedure and Regulatory Analysis"
MISSING_SUMMARY_TEXT = "Summary not available for this section."
VERDICT_APPLICABILITY = {
    "HIGH": "Directly Applicable",
    "MEDIUM": "Partially Applicable",
}
REGULATION_SOURCE = "internet_search"
REGULATION_PREFIX = "REG"

_SECTION_ID_RE = re.compile(r"^(\d+(?:\.\d+)*)(.*)$")


def _documents_from_content(content: Any) -> List[dict]:
    if isinstance(content, list):
        return [doc for doc in content if isinstance(doc, dict)]
    if isinstance(content, dict) and isinstance(content.get("documents"), list):
        return [doc for doc in content["documents"] if isinstance(doc, dict)]
    return []


def _section_sort_key(section_id: Optional[str]) -> tuple:
    """Natural sort: 4.2 < 4.2.1 < 4.2.1(EU) < 4.10; unnumbered pieces go last."""
    if not section_id:
        return (1, (), "")
    match = _SECTION_ID_RE.match(section_id.strip())
    if not match:
        return (1, (), section_id)
    numbers = tuple(int(part) for part in match.group(1).split("."))
    return (0, numbers, match.group(2).strip().lower())


def _pretty_title(title: Any) -> str:
    text = str(title or "").replace("_", " ")
    return re.sub(r"\s+", " ", text).strip()


def _format_score(score: Any) -> Optional[str]:
    try:
        return f"{float(score):.2f}"
    except (TypeError, ValueError):
        return None


def _section_heading(section_id: Optional[str], section_title: Optional[str]) -> str:
    title = (section_title or "").strip()
    if not section_id:
        return title
    # Glossary-style ids such as "5(GBSA)" carry the title "(GBSA)"; avoid repeating it.
    if not title or section_id.endswith(title):
        return f"Section {section_id}"
    return f"Section {section_id} {title}"


def _section_path_list(path: Any) -> List[str]:
    # New part files store section_path as a " > " joined string; older files use a list.
    if isinstance(path, str):
        return [p.strip() for p in path.split(">") if p.strip()]
    return list(path or [])


def _build_document(doc: dict, prefix: str, index: int) -> dict:
    doc_key = f"{prefix}|{index}"
    grouped: Dict[str, dict] = {}
    storage_uri = doc.get("storage_uri")
    for position, node in enumerate(doc.get("nodes") or []):
        if not isinstance(node, dict):
            continue
        storage_uri = storage_uri or node.get("storage_uri")
        section_id = str(node.get("section_id")).strip() if node.get("section_id") else None
        group_id = section_id or f"node:{node.get('node_id') or position}"
        key = f"{doc_key}|{group_id}"
        entry = grouped.get(key)
        if entry is None:
            entry = {
                "key": key,
                "section_id": section_id,
                "section_title": node.get("section_title"),
                "section_path": _section_path_list(node.get("section_path")),
                "page_start": node.get("page_start"),
                "page_end": node.get("page_end"),
                "texts": [],
            }
            grouped[key] = entry
        text = node.get("original_text")
        if text and text not in entry["texts"]:
            entry["texts"].append(text)
        for page_field, pick in (("page_start", min), ("page_end", max)):
            value = node.get(page_field)
            if isinstance(value, int):
                current = entry[page_field]
                entry[page_field] = value if not isinstance(current, int) else pick(current, value)

    sections = sorted(grouped.values(), key=lambda item: _section_sort_key(item["section_id"]))
    return {
        "doc_key": doc_key,
        "title": _pretty_title(doc.get("document_title")),
        "version": doc.get("document_version"),
        "storage_uri": storage_uri,
        "relevance_score": doc.get("document_relevance_score"),
        "rationale": doc.get("rationale"),
        "applicability": VERDICT_APPLICABILITY.get(
            str(doc.get("document_relevance_verdict") or "").strip().upper()
        ),
        "sections": sections,
    }


def build_policy_manifest(source_chunks: List[dict]) -> Dict[str, dict]:
    """Return {source_name: {"chunk_id", "label", "documents": [...]}} for policy, procedure and KOD."""
    chunks_by_source = {chunk.get("source_name"): chunk for chunk in source_chunks if isinstance(chunk, dict)}
    manifest: Dict[str, dict] = {}
    for source_name, prefix, label in POLICY_SOURCES:
        chunk = chunks_by_source.get(source_name) or {}
        documents = _documents_from_content(chunk.get("content"))
        manifest[source_name] = {
            "chunk_id": chunk.get("chunk_id"),
            "label": label,
            "documents": [_build_document(doc, prefix, idx) for idx, doc in enumerate(documents, start=1)],
        }
    return manifest


def _risk_entries(content: Any) -> List[dict]:
    if isinstance(content, dict):
        content = next(
            (value for value in content.values()
             if isinstance(value, list) and any(isinstance(v, dict) and "Mandates" in v for v in value)),
            [],
        )
    if not isinstance(content, list):
        return []
    return [risk for risk in content if isinstance(risk, dict) and isinstance(risk.get("Mandates"), list)]


def _evidence_label(evidence: dict) -> str:
    parsed = urlparse(str(evidence.get("source_url") or evidence.get("deep_link") or ""))
    host = parsed.netloc.removeprefix("www.")
    last_segment = parsed.path.rstrip("/").rsplit("/", 1)[-1]
    return " ".join(part for part in (host, last_segment) if part) or "Source"


def build_regulation_manifest(source_chunks: List[dict]) -> List[dict]:
    """Flatten regulatory risks into keyed mandates; each evidence item becomes a citable deep link."""
    chunk = next(
        (c for c in source_chunks if isinstance(c, dict) and c.get("source_name") == REGULATION_SOURCE),
        {},
    )
    mandates: List[dict] = []
    for risk_index, risk in enumerate(_risk_entries(chunk.get("content")), start=1):
        for mandate_index, mandate in enumerate(risk["Mandates"], start=1):
            if not isinstance(mandate, dict):
                continue
            key = f"{REGULATION_PREFIX}|{risk_index}|{mandate_index}"
            evidence = []
            for evidence_index, item in enumerate(mandate.get("Evidence") or [], start=1):
                if not isinstance(item, dict):
                    continue
                evidence.append({
                    "key": f"{key}|{evidence_index}",
                    "source_url": item.get("source_url"),
                    "deep_link": item.get("deep_link") or item.get("source_url"),
                    "evidence_text": item.get("evidence_text"),
                    "label": _evidence_label(item),
                })
            mandates.append({
                "key": key,
                "risk_name": risk.get("Risk Name"),
                "mandate": mandate.get("Regulatory Mandate"),
                "confidence_score": mandate.get("Confidence Score"),
                "rationale": mandate.get("AI Rationale"),
                "evidence": evidence,
            })
    return mandates


def regulation_citation_mapping(mandates: List[dict]) -> Dict[str, list]:
    """Map mandate and evidence keys to their external source links."""
    mapping: Dict[str, list] = {}
    for mandate in mandates:
        first_link = None
        for evidence in mandate["evidence"]:
            if not evidence["deep_link"]:
                continue
            citation = {
                "content_type": "text/html",
                "document_name": evidence["source_url"] or evidence["deep_link"],
                "access_info": {"uri": evidence["deep_link"]},
                "location_metadata": {},
                "citation_label": evidence["label"],
                "url": evidence["deep_link"],
            }
            mapping[evidence["key"]] = [citation]
            if first_link is None:
                first_link = citation
        if first_link is not None:
            mapping[mandate["key"]] = [first_link]
    return mapping


def to_model_source_chunks(
    source_chunks: List[dict],
    manifest: Dict[str, dict],
    regulation_mandates: Optional[List[dict]] = None,
) -> List[dict]:
    """Replace raw policy/procedure/KOD content with the compact keyed manifest the model must answer against."""
    model_chunks: List[dict] = []
    for chunk in source_chunks:
        source_name = chunk.get("source_name") if isinstance(chunk, dict) else None
        if source_name == REGULATION_SOURCE and regulation_mandates is not None:
            model_chunks.append({
                "chunk_id": chunk.get("chunk_id"),
                "source_name": source_name,
                "content": [
                    {
                        "key": mandate["key"],
                        "risk_name": mandate["risk_name"],
                        "regulatory_mandate": mandate["mandate"],
                        "confidence_score": mandate["confidence_score"],
                        "rationale": mandate["rationale"],
                        "evidence": [
                            {
                                "key": item["key"],
                                "source_url": item["source_url"],
                                "evidence_text": item["evidence_text"],
                                "label": item["label"],
                            }
                            for item in mandate["evidence"]
                        ],
                    }
                    for mandate in regulation_mandates
                ],
            })
            continue
        if source_name not in manifest:
            model_chunks.append(chunk)
            continue
        model_chunks.append({
            "chunk_id": chunk.get("chunk_id"),
            "source_name": source_name,
            "content": [
                {
                    "doc_key": doc["doc_key"],
                    "document_title": doc["title"],
                    "document_version": doc["version"],
                    "rationale": doc["rationale"],
                    "sections": [
                        {
                            "key": section["key"],
                            "section_id": section["section_id"],
                            "section_title": section["section_title"],
                            "section_path": section["section_path"],
                            "text": "\n\n".join(section["texts"]),
                        }
                        for section in doc["sections"]
                    ],
                }
                for doc in manifest[source_name]["documents"]
            ],
        })
    return model_chunks
