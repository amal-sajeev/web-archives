
import asyncio
import logging
from typing import Any, Callable, Dict, List, Optional

from agents.analytics_agent import SECTION_REGISTRY, run_analytics_agent
from config.config import Config
from model.response_model import PreliminaryResearchDocument
from utils.data_manager import (
    get_plan_output_blob_path,
    get_preliminary_research_blob_path,
    get_preliminary_research_section_blob_path,
    read_plan_data_async,
)
from utils.policy_section_builder import (
    _section_citation_label,
    build_policy_manifest,
    build_regulation_manifest,
    regulation_citation_mapping,
)
from utils.storage_manager import read_blob_json, write_blob_json


logger = logging.getLogger(__name__)


ProgressCallback = Optional[Callable[[Dict[str, Any]], None]]


def _add_policy_section_citations(
    plan_data: Dict[str, Any],
    chunk_id_path_mapping: Dict[str, Any],
) -> None:
    manifest = build_policy_manifest(plan_data.get("output2") or [])
    for source in manifest.values():
        for document in source["documents"]:
            document_uri = document.get("storage_uri")
            if not document_uri:
                logger.warning("Policy document has no storage URI doc_key=%s", document["doc_key"])
                continue
            chunk_id_path_mapping[document["doc_key"]] = [{
                "content_type": "application/pdf",
                "document_name": document["title"],
                "access_info": {"uri": document_uri},
                "location_metadata": {},
                "citation_label": "Link",
            }]
            for section in document["sections"]:
                page_number = section.get("page_start")
                if page_number is None:
                    continue
                chunk_id = section["key"]
                chunk_id_path_mapping[chunk_id] = [{
                    "content_type": "application/pdf",
                    "document_name": document["title"],
                    "access_info": {"uri": document_uri},
                    "location_metadata": {"page_number": page_number},
                    "citation_label": _section_citation_label(section),
                }]
    chunk_id_path_mapping.update(
        regulation_citation_mapping(build_regulation_manifest(plan_data.get("output2") or []))
    )


def _emit_progress(
    progress_callback: ProgressCallback,
    status: str,
    message: str,
    progress: int,
    phase: Optional[str] = None,
) -> None:
    if progress_callback:
        progress_callback({"status": status, "message": message, "progress": progress, "phase": phase})


def _build_exact_supporting_citations(
    paragraph: Dict[str, Any],
    chunk_id_path_mapping: Dict[str, Any],
) -> list[Dict[str, Any]]:
    if not isinstance(paragraph, dict):
        return []

    supporting_chunk_ids = paragraph.get("supporting_chunk_ids") or []
    raw_supporting_citations = paragraph.get("supporting_citations") or []

    exact_citations: list[Dict[str, Any]] = []
    seen_keys: set[tuple[Any, ...]] = set()

    citation_candidates: list[Dict[str, Any]] = []
    if isinstance(raw_supporting_citations, list) and raw_supporting_citations:
        for item in raw_supporting_citations:
            if isinstance(item, dict) and item.get("chunk_id") not in (None, ""):
                citation_candidates.append(item)
    else:
        for chunk_id in supporting_chunk_ids:
            citation_candidates.append({"chunk_id": str(chunk_id), "page_number": None})

    for candidate in citation_candidates:
        chunk_id = str(candidate.get("chunk_id"))
        mapping_entries = chunk_id_path_mapping.get(chunk_id) or chunk_id_path_mapping.get(candidate.get("chunk_id")) or []
        first_mapping = mapping_entries[0] if mapping_entries else {}
        access_info = first_mapping.get("access_info") or {}
        location_metadata = first_mapping.get("location_metadata") or {}

        page_number = candidate.get("page_number")
        if first_mapping.get("citation_label") and location_metadata.get("page_number") is not None:
            page_number = location_metadata["page_number"]
        elif page_number in (None, ""):
            page_number = location_metadata.get("page_number")

        entry = {
            "chunk_id": chunk_id,
            "page_number": page_number,
            # Web citations (e.g. regulatory deep links) carry their link in `url`; gs_uri stays storage-only.
            "gs_uri": None if first_mapping.get("url") else access_info.get("uri"),
            "document_name": first_mapping.get("document_name"),
            "content_type": first_mapping.get("content_type"),
        }
        if first_mapping.get("citation_label"):
            entry["citation_label"] = first_mapping["citation_label"]
        if first_mapping.get("url"):
            entry["url"] = first_mapping["url"]
        dedupe_key = (
            entry["chunk_id"],
            entry["page_number"],
            entry["gs_uri"],
            entry["document_name"],
            entry["content_type"],
        )
        if dedupe_key in seen_keys:
            continue
        seen_keys.add(dedupe_key)
        exact_citations.append(entry)

    return exact_citations


def _enrich_evidence_block(block: Any, chunk_id_path_mapping: Dict[str, Any]) -> Dict[str, Any]:
    if hasattr(block, "model_dump"):
        block = block.model_dump()
    if not isinstance(block, dict):
        return {
            "content": str(block or ""),
            "supporting_chunk_ids": [],
            "supporting_citations": [],
        }

    block = dict(block)
    content_units = block.get("content")
    if isinstance(content_units, list):
        enriched_units: list[Any] = []
        for unit in content_units:
            if hasattr(unit, "model_dump"):
                unit = unit.model_dump()
            if not isinstance(unit, dict):
                enriched_units.append(unit)
                continue
            enriched_unit = dict(unit)
            enriched_unit["supporting_chunk_ids"] = enriched_unit.get("supporting_chunk_ids") or []
            enriched_unit["supporting_citations"] = _build_exact_supporting_citations(
                enriched_unit,
                chunk_id_path_mapping,
            )
            enriched_units.append(enriched_unit)
        block["content"] = enriched_units
        return block

    block["supporting_chunk_ids"] = block.get("supporting_chunk_ids") or []
    block["supporting_citations"] = _build_exact_supporting_citations(block, chunk_id_path_mapping)
    if not block.get("content") and isinstance(block.get("text"), str):
        block["content"] = block["text"]
    return block


def _enrich_analysis_report_with_citations(
    analysis_report: Dict[str, Any],
    chunk_id_path_mapping: Dict[str, Any],
) -> Dict[str, Any]:
    if not isinstance(analysis_report, dict):
        return analysis_report

    enriched_report: Dict[str, Any] = {}
    for section_name, section_payload in analysis_report.items():
        if hasattr(section_payload, "model_dump"):
            section_payload = section_payload.model_dump()
        if not isinstance(section_payload, dict):
            enriched_report[section_name] = section_payload
            continue

        enriched_section = dict(section_payload)
        historical_reviews = section_payload.get("historical_reviews")
        if isinstance(historical_reviews, list):
            enriched_reviews: list[Dict[str, Any]] = []
            for historical_review in historical_reviews:
                if not isinstance(historical_review, dict):
                    continue
                enriched_review = dict(historical_review)
                enriched_assessments: list[Dict[str, Any]] = []
                for assessment in historical_review.get("assessments") or []:
                    if not isinstance(assessment, dict):
                        continue
                    enriched_assessment = dict(assessment)
                    enriched_assessment.pop("supporting_chunk_ids", None)
                    for field_name in ("key_observation", "implication_for_current_review"):
                        if field_name in enriched_assessment:
                            enriched_assessment[field_name] = _enrich_evidence_block(
                                enriched_assessment[field_name],
                                chunk_id_path_mapping,
                            )
                    enriched_assessments.append(enriched_assessment)
                enriched_review["assessments"] = enriched_assessments
                enriched_reviews.append(enriched_review)
            enriched_section["historical_reviews"] = enriched_reviews
            enriched_report[section_name] = enriched_section
            continue

        paragraphs = section_payload.get("paragraphs") or []
        enriched_paragraphs: list[Dict[str, Any]] = []
        for paragraph in paragraphs:
            if hasattr(paragraph, "model_dump"):
                paragraph = paragraph.model_dump()
            if not isinstance(paragraph, dict):
                enriched_paragraphs.append(paragraph)
                continue

            enriched_paragraph = dict(paragraph)
            content_units = enriched_paragraph.get("content")
            if isinstance(content_units, list):
                enriched_block = _enrich_evidence_block(
                    {"content": content_units},
                    chunk_id_path_mapping,
                )
                enriched_paragraph["content"] = enriched_block["content"]
            else:
                enriched_paragraph["supporting_citations"] = _build_exact_supporting_citations(
                    enriched_paragraph,
                    chunk_id_path_mapping,
                )
            enriched_paragraphs.append(enriched_paragraph)

        enriched_section["paragraphs"] = enriched_paragraphs
        enriched_report[section_name] = enriched_section

    return enriched_report


async def write_preliminary_research_sections(plan_number: str, analysis_report: Dict[str, Any]) -> List[str]:
    """Store each analysis_report section in its own blob named after its section key (writes run concurrently).

    Blob content is ``{section title: section}`` so combining the blobs restores the report.
    The combined preliminary-research.json is never written.
    """
    key_by_title = {entry["title"]: key for key, entry in SECTION_REGISTRY.items()}
    unknown = [title for title in analysis_report if title not in key_by_title]
    if unknown:
        raise ValueError(f"Unknown preliminary research sections: {unknown}")
    return list(await asyncio.gather(*(
        asyncio.to_thread(
            write_blob_json,
            get_preliminary_research_section_blob_path(plan_number, key_by_title[title]),
            {title: section},
        )
        for title, section in analysis_report.items()
    )))


async def _read_section_blob(plan_number: str, key: str) -> Optional[Dict[str, Any]]:
    """Read one section blob and return the section content; None when the blob does not exist."""
    try:
        payload = await asyncio.to_thread(
            read_blob_json,
            get_preliminary_research_section_blob_path(plan_number, key),
        )
    except FileNotFoundError:
        return None
    title = SECTION_REGISTRY[key]["title"]
    if not isinstance(payload, dict) or not isinstance(payload.get(title), dict):
        raise TypeError(f"Stored preliminary research section '{key}' must be a dictionary.")
    return payload[title]


async def _read_legacy_preliminary_research(plan_number: str) -> Optional[Dict[str, Any]]:
    """Read the old combined preliminary-research.json; None when absent."""
    try:
        payload = await asyncio.to_thread(read_blob_json, get_preliminary_research_blob_path(plan_number))
    except FileNotFoundError:
        return None
    if not isinstance(payload, dict):
        raise TypeError("Stored preliminary research must be a dictionary.")
    # Oldest payloads stored only the report content.
    report = payload.get("analysis_report", payload)
    if not isinstance(report, dict):
        raise TypeError("Stored preliminary research analysis_report must be a dictionary.")
    return report


async def read_preliminary_research_report(plan_number: str) -> Optional[Dict[str, Any]]:
    """Combine the per-section blobs (read concurrently) into one analysis_report in registry order.

    The combined preliminary-research.json is read only when a section blob is missing, and only
    fills those missing sections. Returns None when nothing is stored.
    """
    stored_sections = await asyncio.gather(
        *(_read_section_blob(plan_number, key) for key in SECTION_REGISTRY)
    )
    sections = {
        entry["title"]: section
        for entry, section in zip(SECTION_REGISTRY.values(), stored_sections)
        if section is not None
    }
    if len(sections) == len(SECTION_REGISTRY):
        return sections

    legacy_report = await _read_legacy_preliminary_research(plan_number)
    if legacy_report is None:
        return sections or None
    if not sections:
        return legacy_report
    logger.info("Filling missing preliminary research sections from the combined blob plan_number=%s", plan_number)
    report: Dict[str, Any] = {}
    for entry in SECTION_REGISTRY.values():
        title = entry["title"]
        if title in sections:
            report[title] = sections[title]
        elif isinstance(legacy_report.get(title), dict):
            report[title] = legacy_report[title]
    return report


async def _load_previous_analysis_report(plan_number: str) -> Dict[str, Any]:
    """Read the latest preliminary research analysis_report from the bucket; {} when unavailable."""
    try:
        report = await read_preliminary_research_report(plan_number)
    except Exception:
        logger.exception("Failed to read previous preliminary research plan_number=%s", plan_number)
        return {}
    if not report:
        logger.info("No previous preliminary research found plan_number=%s", plan_number)
        return {}
    return report


async def _resolve_sections_to_generate(
    plan_number: str,
    sections: Optional[List[str]],
) -> tuple[List[str], Dict[str, Any]]:
    """Return (section keys to generate, previous analysis_report used for the retained sections)."""
    all_keys = list(SECTION_REGISTRY)
    requested = {key for key in sections or [] if key in SECTION_REGISTRY}
    if not requested or requested == set(all_keys):
        return all_keys, {}

    previous_report = await _load_previous_analysis_report(plan_number)
    to_generate = [
        key
        for key in all_keys
        if key in requested or not isinstance(previous_report.get(SECTION_REGISTRY[key]["title"]), dict)
    ]
    missing = [key for key in to_generate if key not in requested]
    if missing:
        logger.info(
            "Previous version lacks sections, generating them too plan_number=%s sections=%s",
            plan_number,
            missing,
        )
    return to_generate, previous_report


async def run_analytics_task(
    plan_number: str,
    progress_callback: ProgressCallback = None,
    sections: Optional[List[str]] = None,
) -> Dict[str, Any]:
    logger.info("Analytics task started plan_number=%s sections=%s", plan_number, sections)
    _emit_progress(progress_callback, "running", "Gathering source material.", 10, phase="gathering_data")
    # Full plan data is always loaded: chunk ids are numbered across all outputs.
    (sections_to_generate, previous_report), (plan_data, chunk_id_path_mapping) = await asyncio.gather(
        _resolve_sections_to_generate(plan_number, sections),
        read_plan_data_async(plan_number),
    )
    _add_policy_section_citations(plan_data, chunk_id_path_mapping)
    logger.info("Plan data loaded plan_number=%s", plan_number)

    _emit_progress(progress_callback, "running", "Source material is ready.", 20, phase="gathering_data")
    if previous_report is not None:
        try:
            analysis = await run_analytics_agent(
                plan_number,
                plan_data,
                progress_callback=progress_callback,
                sections=sections_to_generate,
                previous_report=previous_report,
            )
        except TypeError:
            analysis = await run_analytics_agent(
                plan_number,
                plan_data,
                progress_callback=progress_callback,
                sections=sections_to_generate,
            )
    else:
        analysis = await run_analytics_agent(
            plan_number,
            plan_data,
            progress_callback=progress_callback,
            sections=sections_to_generate,
        )
    analysis = _enrich_analysis_report_with_citations(analysis, chunk_id_path_mapping)
    logger.info("Analytics agent completed plan_number=%s sections=%s", plan_number, sections_to_generate)
    if not isinstance(analysis, dict):
        logger.error(
            "Analytics agent returned an invalid report type plan_number=%s type=%s",
            plan_number,
            type(analysis).__name__,
        )
        raise TypeError("Analytics agent must return a dictionary report.")

    if previous_report:
        merged: Dict[str, Any] = {}
        for key, entry in SECTION_REGISTRY.items():
            title = entry["title"]
            merged[title] = analysis[title] if key in sections_to_generate else previous_report[title]
        analysis = merged

    report_model = PreliminaryResearchDocument(
        plan_number=plan_number,
        analysis_report=analysis,
    )
    report: Dict[str, Any] = report_model.model_dump()
    _emit_progress(progress_callback, "running", "Consolidating the report and saving the draft.", 97, phase="consolidating_sections")
    report_paths, citation_path_mapping = await asyncio.gather(
        write_preliminary_research_sections(plan_number, report["analysis_report"]),
        asyncio.to_thread(
            write_blob_json,
            get_plan_output_blob_path(plan_number, "citation_mapping.json"),
            chunk_id_path_mapping,
        ),
    )
    logger.info(
        "Report sections persisted plan_number=%s paths=%s",
        plan_number,
        report_paths,
    )
    logger.info(
        "citation mapping persisted plan_number=%s path=%s",
        plan_number,
        citation_path_mapping,
    )
    _emit_progress(progress_callback, "complete", "Final touch complete. Your report is ready.", 100, phase="final_touch")
    return report
