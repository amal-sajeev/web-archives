import asyncio

from agents import analytics_agent
from agents.llm_judge.models import ReportRubricReview


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {
                "name": name,
                "passed": True,
                "issue": "",
                "action": "",
                "affected_sections": [],
            }
            for name in names
        ]
    }


def test_agent_trace_logs_stage_markers_without_report_contents(monkeypatch, caplog):
    monkeypatch.setenv("SUMMARY_AGENT_JUDGE_DEBUG", "true")
    caplog.set_level("DEBUG")

    analytics_agent._terminal_trace(
        "section:Example",
        "judge_input",
        {"candidate": "sensitive report text", "feedback": "private critique"},
    )

    assert "SUMMARY_AGENT_TRACE stage=section:Example label=judge_input" in caplog.text
    assert "sensitive report text" not in caplog.text
    assert "private critique" not in caplog.text


def test_report_review_revises_only_flagged_section_then_reviews_again():
    builder_calls = {"Past Review Analysis": [], "Broad Scope Direction": []}

    def past_builder(_chunks, _model, review_feedback=None):
        builder_calls["Past Review Analysis"].append(review_feedback)
        return {"section": "past revised"}

    def broad_builder(_chunks, _model, review_feedback=None):
        builder_calls["Broad Scope Direction"].append(review_feedback)
        return {"section": "broad"}

    model = _QueuedModel(
        {
            "ReportRubricReview": [
                _approve_report_rubric(
                    ("section_coverage", "review_identifier_consistency")
                ),
                {
                    "criteria": [
                        {
                            "name": "cross_section_consistency",
                            "passed": False,
                            "issue": "The review purpose differs between sections.",
                            "action": "Label the compliance focus as an inference and clarify that formal purpose is undocumented.",
                            "affected_sections": ["Past Review Analysis"],
                        }
                    ]
                },
                _approve_report_rubric(("duplication_and_structure",)),
                _approve_report_rubric(
                    ("section_coverage", "review_identifier_consistency")
                ),
                _approve_report_rubric(("cross_section_consistency",)),
                _approve_report_rubric(("duplication_and_structure",)),
            ],
            "SectionReview": [_approve_section()],
            "SectionQualityReview": [_approve_section_quality()],
        }
    )

    result = asyncio.run(
        analytics_agent._review_complete_report(
            {
                "Past Review Analysis": {"section": "past original"},
                "Broad Scope Direction": {"section": "broad original"},
            },
            model,
            {
                "Past Review Analysis": (past_builder, []),
                "Broad Scope Direction": (broad_builder, []),
            },
            max_revisions=1,
            failure_policy="fail_open",
        )
    )

    assert result["Past Review Analysis"] == {"section": "past revised"}
    assert result["Broad Scope Direction"] == {"section": "broad original"}
    assert builder_calls["Past Review Analysis"] == [
        (
            "[cross_section_consistency] The review purpose differs between sections. "
            "Action: Label the compliance focus as an inference and clarify that formal purpose is undocumented."
        )
    ]
    assert builder_calls["Broad Scope Direction"] == []


def test_report_review_makes_focused_calls_and_aggregates_logged_failure_patterns():
    class _CaptureModel:
        def __init__(self, responses):
            self.responses = list(responses)
            self.prompts = []
            self.schemas = []

        def with_structured_output(self, schema, **_kwargs):
            self.schemas.append(schema)
            model = self

            class _Runner:
                def invoke(self, payload):
                    message = payload[0]
                    content = (
                        message.content
                        if hasattr(message, "content")
                        else message.get("content", [])
                    )
                    model.prompts.append(
                        "\n".join(part.get("text", "") for part in content)
                    )
                    return schema.model_validate(model.responses.pop(0))

            return _Runner()

    report = {
        "Past Review Analysis": {
            "report_title": "Past Review Analysis",
            "paragraphs": [],
        },
        "Policy, KOD and Regulatory Analysis": {
            "paragraphs": [
                {
                    "paragraph_id": "para_1",
                    "content": "This is a Compliance-focused review.",
                }
            ]
        },
        "Broad Scope Direction": {
            "paragraphs": [
                {
                    "paragraph_id": "para_1",
                    "content": "The review purpose was not provided.",
                },
                {
                    "paragraph_id": "para_6",
                    "content": "No dbGRC control instances were available.",
                },
                {
                    "paragraph_id": "para_9",
                    "content": "No dbGRC control instances were available.",
                },
                {
                    "paragraph_id": "para_15",
                    "content": "No dbGRC control instances were available.",
                },
            ]
        },
    }
    model = _CaptureModel(
        [
            _approve_report_rubric(
                ("section_coverage", "review_identifier_consistency")
            ),
            {
                "criteria": [
                    {
                        "name": "cross_section_consistency",
                        "passed": False,
                        "issue": "The policy section asserts a formal compliance purpose while the broad-scope section says the purpose was not provided.",
                        "action": "Label the compliance focus as an inference or clarify that the formal purpose is undocumented.",
                        "affected_sections": [
                            "Policy, KOD and Regulatory Analysis",
                            "Broad Scope Direction",
                        ],
                    }
                ]
            },
            {
                "criteria": [
                    {
                        "name": "duplication_and_structure",
                        "passed": False,
                        "issue": "The missing dbGRC control-instance finding is repeated in paragraphs 6, 9, and 15 without adding a distinct consequence or action.",
                        "action": "Consolidate the finding and keep only references that serve distinct scope or walkthrough actions.",
                        "affected_sections": ["Broad Scope Direction"],
                    }
                ]
            },
        ]
    )

    review = analytics_agent._review_report_candidate(report, model)

    assert len(model.prompts) == 3
    assert model.schemas == [ReportRubricReview] * 3
    assert {criterion.name for criterion in review.criteria} == {
        "section_coverage",
        "cross_section_consistency",
        "review_identifier_consistency",
        "duplication_and_structure",
    }
    assert not review.approved
    assert set(review.feedback_by_section) == {
        "Policy, KOD and Regulatory Analysis",
        "Broad Scope Direction",
    }
    assert "ONLY when it clearly labels" in model.prompts[1]
    assert "Within the same section, flag repeated statements" in model.prompts[2]
    assert "paragraph_id" in model.prompts[2]
