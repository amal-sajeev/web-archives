
from agents import analytics_agent


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {
                "name": name,
                "passed": True,
                "issue": "",
                "action": "",
                "affected_sections": [],
            }
            for name in names
        ]
    }



def test_report_review_allows_explicit_inference_and_distinct_gap_references():
    class _PassingModel:
        def __init__(self):
            self.prompts = []

        def with_structured_output(self, schema, **_kwargs):
            model = self

            class _Runner:
                def invoke(self, payload):
                    message = payload[0]
                    content = (
                        message.content
                        if hasattr(message, "content")
                        else message.get("content", [])
                    )
                    prompt = "\n".join(part.get("text", "") for part in content)
                    model.prompts.append(prompt)
                    if (
                        "section_coverage" in prompt
                        and "review_identifier_consistency" in prompt
                    ):
                        names = ("section_coverage", "review_identifier_consistency")
                    elif "cross_section_consistency" in prompt:
                        names = ("cross_section_consistency",)
                    else:
                        names = ("duplication_and_structure",)
                    return schema.model_validate(_approve_report_rubric(names))

            return _Runner()

    report = {
        "Past Review Analysis": {
            "report_title": "Past Review Analysis",
            "similar_review_count": 0,
            "historical_reviews": [],
        },
        "Policy, KOD and Regulatory Analysis": {
            "paragraphs": [
                {
                    "paragraph_id": "para_1",
                    "content": "The risk profile suggests an inferred compliance-oriented focus; the plan does not state a formal purpose.",
                }
            ]
        },
        "Broad Scope Direction": {
            "paragraphs": [
                {
                    "paragraph_id": "para_1",
                    "content": "The formal review purpose was not provided.",
                },
                {
                    "paragraph_id": "para_6",
                    "content": "Scope boundary: dbGRC control instances were unavailable.",
                },
                {
                    "paragraph_id": "para_15",
                    "content": "Walkthrough action: ask control owners to identify the control population.",
                },
            ]
        },
    }
    model = _PassingModel()

    review = analytics_agent._review_report_candidate(report, model)

    assert review.approved
    assert len(review.criteria) == 4
    assert "ONLY when it clearly labels" in model.prompts[1]
    assert "each mention serves a distinct purpose" in model.prompts[2]
