import asyncio

import pytest

from agents import analytics_agent
from agents.llm_judge.models import SectionQualityReview, SectionReview


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": "", "affected_sections": []}
            for name in names
        ]
    }


def test_review_settings_default_and_vertex_connection_configuration(monkeypatch):
    from utils import gemini_connection

    captured = {}

    def fake_chat_model(**kwargs):
        captured.update(kwargs)
        return "configured model"

    monkeypatch.setattr(gemini_connection, "ChatGoogleGenerativeAI", fake_chat_model)
    result = gemini_connection.initialize_gemini_model()

    assert result == "configured model"
    assert captured["model"] == gemini_connection.Config.MODEL_NAME
    assert captured["project"] == gemini_connection.Config.PROJECT_NAME
    assert captured["location"] == gemini_connection.Config.PROJECT_LOCATION
    assert captured["max_output_tokens"] == gemini_connection.Config.GENERATION_CONFIG["max_output_tokens"]
    assert analytics_agent._review_settings() == (
        gemini_connection.Config.SUMMARY_AGENT_REVIEW_MAX_REVISIONS,
        gemini_connection.Config.SUMMARY_AGENT_REVIEW_FAILURE_POLICY,
    )


def test_broad_scope_direction_propagates_review_feedback_and_previous_candidate(monkeypatch):
    from utils.broad_scope_builder import BroadScopePart

    part_calls = []
    collation_calls = []

    def fake_part(_chunks, group, _model, review_feedback=None):
        part_calls.append((group["key"], review_feedback))
        part = BroadScopePart(
            key=group["key"],
            label=group["label"],
            unavailable_text=group["unavailable_text"],
            status="ok",
            output=analytics_agent.BroadScopePartOutput(section1=[], in_scope=[], out_of_scope=[]),
        )
        return part

    def fake_collation(_chunks, _draft_paragraphs, _model, review_feedback=None, previous_candidate=None):
        collation_calls.append((review_feedback, previous_candidate))
        return analytics_agent.BroadScopeCollationOutput(
            section2_rationale="Rationale.",
            section2_confidence_score=75,
            section3=[],
        )

    monkeypatch.setattr(analytics_agent, "_broad_scope_part", fake_part)
    monkeypatch.setattr(analytics_agent, "_broad_scope_collation", fake_collation)

    report = analytics_agent.broad_scope_direction(
        [],
        object(),
        review_feedback="[evidence_support] Fix unsupported claim.",
        previous_candidate={"paragraphs": []},
    )

    assert len(part_calls) == len(analytics_agent.BROAD_SCOPE_GROUPS)
    assert all(call[1] == "[evidence_support] Fix unsupported claim." for call in part_calls)
    assert collation_calls == [("[evidence_support] Fix unsupported claim.", {"paragraphs": []})]
    assert len(report.paragraphs) >= 3


def test_review_section_candidate_excludes_skip_schema_heading_level_and_passes_manifest_chunks():
    from model.response_model import ParagraphCitation, ParagraphMetadata, ScopingReport

    captured_payloads = []

    class _CapturingStructuredModel:
        def __init__(self, schema):
            self.schema = schema

        def invoke(self, payload):
            captured_payloads.append(payload)
            if self.schema is SectionReview:
                return self.schema.model_validate(_approve_section())
            if self.schema is SectionQualityReview:
                return self.schema.model_validate(_approve_section_quality())
            raise AssertionError(f"Unexpected schema {self.schema}")

    class _CapturingModel:
        def with_structured_output(self, schema, **_kwargs):
            return _CapturingStructuredModel(schema)

    report = ScopingReport(
        report_title="Policy, KOD and Regulatory Analysis",
        paragraphs=[
            ParagraphCitation(
                paragraph_id="para_1",
                content="Section 1: Overview",
                metadata=ParagraphMetadata(
                    is_section_start=True,
                    citation_status="unsupported",
                    rationale="Section heading.",
                    supporting_chunk_ids=[],
                    supporting_citations=[],
                    confidence_score=100,
                    heading_level=2,
                ),
            )
        ],
    )

    source_chunks = [
        {"chunk_id": "1", "source_name": "current_plan_item_details", "content": {"review_number": "123"}},
        {
            "chunk_id": "4",
            "source_name": "relevant_policy",
            "content": [{"Policy Name": "Test Policy", "Policy ID": "P-1", "Summary": "Details"}],
        },
    ]

    decision = analytics_agent._review_section_candidate(
        "Policy, KOD and Regulatory Analysis",
        source_chunks,
        report,
        _CapturingModel(),
    )

    assert decision.approved is True
    assert len(captured_payloads) == 2
    msg = captured_payloads[0][0]
    content = msg["content"] if isinstance(msg, dict) else msg.content
    text_blocks = [
        item["text"]
        for item in content
        if isinstance(item, dict) and item.get("type") == "text"
    ]
    combined_text = "\n".join(text_blocks)
    assert "heading_level" not in combined_text
    assert "POLICY|" in combined_text
    assert "Section generation requirements:" in combined_text
    quality_msg = captured_payloads[1][0]
    quality_content = quality_msg["content"] if isinstance(quality_msg, dict) else quality_msg.content
    quality_text = "\n".join(
        item["text"]
        for item in quality_content
        if isinstance(item, dict) and item.get("type") == "text"
    )
    assert "within_section_consistency" in quality_text
    assert "analysis_actionability" in quality_text
    assert "confidence_rationale_alignment" in quality_text
    assert "source_applicability" in quality_text


def test_past_review_report_without_historical_data_skips_judge_loop():
    class _FailingJudgeModel:
        def with_structured_output(self, schema, **_kwargs):
            if schema.__name__ == "SectionReview":
                raise AssertionError("SectionReview judge should not be invoked when no historical data exists")
            raise AssertionError(f"Unexpected schema {schema.__name__}")

    source_chunks = [
        {"chunk_id": "1", "source_name": "current_plan_item_details", "content": {"Plan Item Number": "REV-99"}},
        {"chunk_id": "2", "source_name": "historical_plan_item_details", "content": []},
    ]

    result = analytics_agent._generate_reviewed_section(
        "Past Review Analysis",
        analytics_agent.past_review_report,
        source_chunks,
        _FailingJudgeModel(),
        max_revisions=1,
        failure_policy="fail_closed",
    )

    assert result.current_review_id == "REV-99"
    assert result.similar_review_count == 0


