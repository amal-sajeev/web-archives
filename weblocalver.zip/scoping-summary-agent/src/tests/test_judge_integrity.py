from agents.llm_judge.integrity import deterministic_section_integrity


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {
                "name": name,
                "passed": True,
                "issue": "",
                "action": "",
                "affected_sections": [],
            }
            for name in names
        ]
    }


def test_deterministic_section_integrity_checks_citations_and_supplied_manifest_coverage():
    source_chunks = [
        {
            "chunk_id": "plan-1",
            "source_name": "current_plan_item_details",
            "content": {},
        },
        {
            "chunk_id": "policy-1",
            "source_name": "relevant_policy",
            "content": [
                {
                    "document_title": "Test Policy",
                    "nodes": [
                        {"section_id": "1.1", "original_text": "Control requirement."}
                    ],
                }
            ],
        },
    ]
    invalid_candidate = {
        "report_title": "Policy, KOD and Regulatory Analysis",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": [
                    {
                        "content": "A source-backed statement.",
                        "citation_status": "supported",
                        "supporting_chunk_ids": ["invented-id"],
                        "supporting_citations": [{"chunk_id": "invented-id"}],
                    },
                    {
                        "content": "An unsupported implication.",
                        "citation_status": "unsupported",
                        "supporting_chunk_ids": ["plan-1"],
                        "supporting_citations": [{"chunk_id": "plan-1"}],
                    },
                ],
            }
        ],
    }

    issues = deterministic_section_integrity(
        "Policy, KOD and Regulatory Analysis", source_chunks, invalid_candidate
    )

    assert "citation_validity" in issues
    assert any("invented-id" in issue for issue in issues["citation_validity"])
    assert any("marked unsupported" in issue for issue in issues["citation_validity"])
    assert "required_content" in issues
    assert any("POLICY|1|1.1" in issue for issue in issues["required_content"])


def test_deterministic_section_integrity_accepts_valid_citations_and_full_manifest_coverage():
    source_chunks = [
        {
            "chunk_id": "plan-1",
            "source_name": "current_plan_item_details",
            "content": {},
        },
        {
            "chunk_id": "policy-1",
            "source_name": "relevant_policy",
            "content": [
                {
                    "document_title": "Test Policy",
                    "nodes": [
                        {"section_id": "1.1", "original_text": "Control requirement."}
                    ],
                }
            ],
        },
    ]
    candidate = {
        "report_title": "Policy, KOD and Regulatory Analysis",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": [
                    {
                        "content": "The policy requires an approval control.",
                        "citation_status": "supported",
                        "supporting_chunk_ids": ["POLICY|1|1.1"],
                        "supporting_citations": [{"chunk_id": "POLICY|1|1.1"}],
                    }
                ],
            }
        ],
    }

    assert (
        deterministic_section_integrity(
            "Policy, KOD and Regulatory Analysis", source_chunks, candidate
        )
        == {}
    )


def test_deterministic_section_integrity_rejects_mismatched_and_unrendered_citations():
    source_chunks = [
        {
            "chunk_id": "source-1",
            "source_name": "current_plan_item_details",
            "content": {},
        }
    ]
    candidate = {
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": "Legacy text with an unrendered citation.",
                "supporting_chunk_ids": ["source-1"],
                "supporting_citations": [],
            },
            {
                "paragraph_id": "para_2",
                "content": [
                    {
                        "content": "Citation metadata disagrees.",
                        "citation_status": "supported",
                        "supporting_chunk_ids": ["source-1"],
                        "supporting_citations": [{"chunk_id": "different-source"}],
                    }
                ],
            },
        ]
    }

    issues = deterministic_section_integrity("Example", source_chunks, candidate)

    assert "citation_validity" in issues
    assert any(
        "no citation entries for rendering" in issue
        for issue in issues["citation_validity"]
    )
    assert any("do not match" in issue for issue in issues["citation_validity"])
