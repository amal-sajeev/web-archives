from pathlib import Path
from unittest.mock import patch, MagicMock
from fastapi import FastAPI
from fastapi.testclient import TestClient
import pytest

import app as app_module
from app import app as main_app
from router import router as router_module
from model.response_model import PreliminaryResearchDocument

app = FastAPI()
app.include_router(router_module.router)
client = TestClient(app)


def test_root_path_is_configured_by_the_asgi_server():
    assert main_app.root_path == ""
    config = app_module.uvicorn.Config(main_app, root_path=app_module.ASGI_ROOT_PATH)
    assert config.root_path == "/scoping-summary-agent"

    dockerfile = Path(__file__).resolve().parents[2] / "Dockerfile"
    assert '"--root-path", "/scoping-summary-agent"' in dockerfile.read_text()


def test_main_app_registers_each_endpoint_once():
    expected = {
        ("GET", "/health"),
        ("POST", "/list-documents"),
        ("POST", "/delete-document"),
        ("POST", "/run-analytics-agent"),
        ("POST", "/get_document"),
        ("POST", "/get-preliminary-research-document"),
        ("POST", "/edit-preliminary-research-document"),
        ("POST", "/download"),
    }
    def registered_routes(routes):
        for route in routes:
            if hasattr(route, "original_router"):
                yield from registered_routes(route.original_router.routes)
            elif getattr(route, "path", None) in {path for _, path in expected}:
                for method in route.methods:
                    yield method, route.path

    routes = list(registered_routes(main_app.routes))
    for endpoint in expected:
        assert routes.count(endpoint) == 1


def test_router_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


@patch("router.router.read_historical_plan_item_details")
def test_list_all_success(mock_read):
    mock_read.return_value = [
        {"Plan Item Number": 20001, "Plan Item Title": "Payment Processing"},
        {"Plan Item Number": "20002", "Plan Item Title": "AML Controls"},
    ]
    response = client.post("/list-documents", json={"plan_number": "20587"})
    assert response.status_code == 200
    assert response.json() == [
        {"plan_item_number": 20001, "plan_item_title": "Payment Processing"},
        {"plan_item_number": "20002", "plan_item_title": "AML Controls"},
    ]
    mock_read.assert_called_once_with("20587")


@patch("router.router.read_historical_plan_item_details", side_effect=FileNotFoundError("missing"))
def test_list_all_not_found(mock_read):
    response = client.post("/list-documents", json={"plan_number": "20587"})
    assert response.status_code == 404


@patch("router.router.read_historical_plan_item_details", side_effect=ValueError("invalid"))
def test_list_all_bad_data(mock_read):
    response = client.post("/list-documents", json={"plan_number": "20587"})
    assert response.status_code == 400


@patch("router.router.delete_historical_plan_item")
def test_delete_document_by_plan_item_success(mock_delete):
    mock_delete.return_value = {
        "plan_number": "20587",
        "deleted_count": 1,
        "remaining_count": 2,
        "deleted": [{"plan_item_number": "20090", "plan_item_title": "Payments"}],
    }
    response = client.post(
        "/delete-document",
        json={
            "planNumber": "20587",
            "planItems": [{"plan_item_number": "20090", "plan_item_title": "Payments"}],
        },
    )
    assert response.status_code == 200
    assert response.json()["deleted_count"] == 1
    assert response.json()["deleted"] == [{"plan_item_number": "20090", "plan_item_title": "Payments"}]
    mock_delete.assert_called_once_with("20587", ["20090"])


@patch("router.router.delete_historical_plan_item")
def test_delete_document_with_multiple_plan_items_from_list_output(mock_delete):
    mock_delete.return_value = {
        "plan_number": "20587",
        "deleted_count": 2,
        "remaining_count": 1,
        "deleted": [
            {"plan_item_number": "20090", "plan_item_title": "Payments"},
            {"plan_item_number": "20091", "plan_item_title": "AML"},
        ],
    }
    response = client.post(
        "/delete-document",
        json={
            "planNumber": "20587",
            "planItems": [
                {"plan_item_number": 20090, "plan_item_title": "Payments"},
                {"plan_item_number": "20091", "plan_item_title": "AML"},
            ],
        },
    )
    assert response.status_code == 200
    assert response.json()["deleted_count"] == 2
    mock_delete.assert_called_once_with("20587", ["20090", "20091"])


@patch("router.router.delete_historical_plan_item", side_effect=LookupError("No matching record"))
def test_delete_document_not_found(mock_delete):
    response = client.post(
        "/delete-document",
        json={"planNumber": "20587", "planItems": [{"plan_item_number": "1", "plan_item_title": "Unknown"}]},
    )
    assert response.status_code == 404


@pytest.mark.parametrize(
    "body",
    [
        {"planNumber": "20587"},
        {"planNumber": "20587", "planItems": []},
        {"planNumber": "20587", "planItems": [{"plan_item_title": "No number"}]},
    ],
)
def test_delete_document_rejects_invalid_body(body):
    response = client.post("/delete-document", json=body)
    assert response.status_code == 422


@patch("router.router.delete_historical_plan_item")
@patch("router.router.read_historical_plan_item_details")
def test_list_output_can_be_sent_unchanged_to_delete(mock_read, mock_delete):
    mock_read.return_value = [
        {"Plan Item Number": 4365, "Plan Item Title": "Branch Inspection"},
        {"Plan Item Number": 4180, "Plan Item Title": "Branch Review"},
    ]
    mock_delete.return_value = {"plan_number": "20587", "deleted_count": 2, "remaining_count": 0, "deleted": []}

    listed = client.post("/list-documents", json={"planNumber": "20587"}).json()
    response = client.post("/delete-document", json={"planNumber": "20587", "planItems": listed})

    assert response.status_code == 200
    mock_delete.assert_called_once_with("20587", ["4365", "4180"])


@patch("agent_helper.action_service.construct_ai_actor_record")
@patch("agent_helper.action_service.construct_human_actor_record")
@patch("router.router.persist_review_research_recommendation", return_value=101)
@patch("router.router.has_plan_data", return_value=True)
@patch("router.router.run_analytics_task")
def test_run_analytics_agent_success(mock_task, mock_has_data, mock_persist, mock_human_rec, mock_ai_rec):
    mock_task.return_value = PreliminaryResearchDocument(
        plan_number="20587",
        analysis_report={"Past Review Analysis": {"report_title": "Baseline", "paragraphs": []}},
    )
    response = client.post(
        "/run-analytics-agent",
        json={
            "planNumber": "20587",
            "userDetails": {
                "review_scope_instance_id": "55",
                "user": "jdoe",
                "remarks": "note",
            },
        },
    )
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"
    assert mock_human_rec.called
    assert mock_ai_rec.called
    # Persistence invoked with values sourced from userDetails.
    mock_persist.assert_called_once()
    _, kwargs = mock_persist.call_args
    assert kwargs["review_scope_instance_id"] == "55"
    assert kwargs["created_by"] == "jdoe"
    assert kwargs["remarks"] == "note"
    assert kwargs["report_type"] == "PRELIMINARY_RESEARCH"
    mock_task.assert_called_once_with("20587", sections=None)


@patch("agent_helper.action_service.construct_ai_actor_record")
@patch("agent_helper.action_service.construct_human_actor_record")
@patch("router.router.persist_review_research_recommendation", return_value=102)
@patch("router.router.has_plan_data", return_value=True)
@patch("router.router.run_analytics_task")
def test_run_analytics_agent_forwards_sections(mock_task, mock_has_data, mock_persist, mock_human_rec, mock_ai_rec):
    mock_task.return_value = PreliminaryResearchDocument(
        plan_number="20587",
        analysis_report={"Broad Scope Direction": {"report_title": "Broad Scope Direction", "paragraphs": []}},
    )
    response = client.post(
        "/run-analytics-agent",
        json={
            "planNumber": "20587",
            "userDetails": {"review_scope_instance_id": "55", "user": "jdoe"},
            "sections": ["broad_scope"],
        },
    )
    assert response.status_code == 200
    mock_task.assert_called_once_with("20587", sections=["broad_scope"])
    # Every run is stored as a new version row.
    mock_persist.assert_called_once()


@patch("router.router.has_plan_data", return_value=True)
def test_run_analytics_agent_rejects_unknown_section(mock_has_data):
    response = client.post(
        "/run-analytics-agent",
        json={"planNumber": "20587", "userDetails": {"user": "jdoe"}, "sections": ["unknown"]},
    )
    assert response.status_code == 422

@patch("router.router.persist_review_research_recommendation", return_value=101)
@patch("router.router.has_plan_data", return_value=False)
def test_run_analytics_agent_not_found(mock_has_data, mock_persist):
    response = client.post(
        "/run-analytics-agent",
        json={"planNumber": "missing", "userDetails": {"user": "jdoe"}},
    )
    assert response.status_code == 404


@patch("agent_helper.action_service.construct_ai_actor_record")
@patch("agent_helper.action_service.construct_human_actor_record")
@patch("router.router.persist_review_research_recommendation", side_effect=RuntimeError("db down"))
@patch("router.router.has_plan_data", return_value=True)
@patch("router.router.run_analytics_task")
def test_run_analytics_agent_persist_failure_does_not_break_response(
    mock_task, mock_has_data, mock_persist, mock_human_rec, mock_ai_rec
):
    """Persistence is best-effort: a DB failure must not fail the analytics response."""
    mock_task.return_value = PreliminaryResearchDocument(
        plan_number="20587",
        analysis_report={"Past Review Analysis": {"report_title": "Baseline", "paragraphs": []}},
    )
    response = client.post(
        "/run-analytics-agent",
        json={"planNumber": "20587", "userDetails": {"user": "jdoe"}},
    )
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"
    mock_persist.assert_called_once()


@patch("router.router.has_plan_data", return_value=True)
def test_run_analytics_agent_missing_user_details(mock_has_data):
    """userDetails is required; omitting it yields a 422 validation error."""
    response = client.post("/run-analytics-agent", json={"planNumber": "20587"})
    assert response.status_code == 422


@patch("router.router.process_document_uri")
def test_get_document_direct_uri(mock_proc):
    mock_proc.return_value = {"type": "pdf", "text": "Extracted"}
    response = client.post("/get_document", json={"document_uri": "gs://bucket/file.pdf"})
    assert response.status_code == 200
    assert response.json()["text"] == "Extracted"


@patch("router.router.process_document_uri")
def test_get_document_unsupported_type(mock_proc):
    mock_proc.return_value = {"type": "unsupported"}
    response = client.post("/get_document", json={"document_uri": "gs://bucket/file.xyz"})
    assert response.status_code == 415


@patch("router.router.process_citations")
def test_get_document_citation_success(mock_proc):
    mock_proc.return_value = {"type": "success", "content": "Evidence"}
    response = client.post("/get_document", json={"planNumber": "20587", "chunk_id": "chunk_1"})
    assert response.status_code == 200
    assert response.json()["content"] == "Evidence"


@patch("router.router.process_citations")
def test_get_document_citation_error_status(mock_proc):
    mock_proc.return_value = {"type": "error", "message": "Chunk not found"}
    response = client.post("/get_document", json={"planNumber": "20587", "chunk_id": "invalid"})
    assert response.status_code == 404


def test_get_document_missing_parameters():
    response = client.post("/get_document", json={})
    assert response.status_code == 400


@patch("router.router.read_preliminary_research_report")
def test_get_preliminary_research_document_success(mock_read):
    mock_read.return_value = {
        "Past Review Analysis": {"report_title": "Scope data", "paragraphs": []},
        "Broad Scope Direction": {"report_title": "Broad", "paragraphs": []},
    }
    response = client.post("/get-preliminary-research-document", json={"planNumber": "20587"})
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"
    assert list(response.json()["analysis_report"]) == ["Past Review Analysis", "Broad Scope Direction"]
    mock_read.assert_called_once_with("20587")


@patch("router.router.read_preliminary_research_report", return_value=None)
def test_get_preliminary_research_document_not_found(mock_read):
    response = client.post("/get-preliminary-research-document", json={"planNumber": "20587"})
    assert response.status_code == 404


@patch("router.router.read_preliminary_research_report")
def test_get_preliminary_research_document_invalid_blob(mock_read):
    mock_read.side_effect = TypeError("Stored preliminary research must be a dictionary.")
    response = client.post("/get-preliminary-research-document", json={"planNumber": "20587"})
    assert response.status_code == 500
    assert "Stored preliminary research must be a dictionary" in response.json()["detail"]


@patch("agent_helper.action_service.construct_human_update_record")
@patch("router.router.update_review_research_recommendation", return_value=101)
@patch("router.router.write_preliminary_research_sections")
def test_edit_preliminary_research_document(mock_write, mock_update, mock_update_rec):
    payload = {
        "plan_number": "20587",
        "analysis_report": {"Past Review Analysis": {"report_title": "Updated", "paragraphs": []}},
        "userDetails": {"review_scope_instance_id": "55", "user": "jdoe"},
    }
    response = client.post("/edit-preliminary-research-document", json=payload)
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"
    mock_write.assert_called_once()
    write_args = mock_write.call_args.args
    assert write_args[0] == "20587"
    assert list(write_args[1]) == ["Past Review Analysis"]
    assert mock_update_rec.called
    # DB update invoked with updated_by/metadata sourced from userDetails + document.
    mock_update.assert_called_once()
    _, kwargs = mock_update.call_args
    assert kwargs["review_scope_instance_id"] == "55"
    assert kwargs["updated_by"] == "jdoe"


@patch("agent_helper.action_service.construct_human_update_record")
@patch("router.router.update_review_research_recommendation")
@patch("router.router.write_preliminary_research_sections")
def test_edit_preliminary_research_document_unknown_section(mock_write, mock_update, mock_update_rec):
    mock_write.side_effect = ValueError("Unknown preliminary research sections: ['Draft']")
    payload = {
        "plan_number": "20587",
        "analysis_report": {"Draft": {"report_title": "Updated", "paragraphs": []}},
        "userDetails": {"review_scope_instance_id": "55", "user": "jdoe"},
    }
    response = client.post("/edit-preliminary-research-document", json=payload)
    assert response.status_code == 400
    mock_update.assert_not_called()


@patch("router.router.read_preliminary_research_report")
@patch("router.router.download_research_walkthrough_pdf")
def test_download_success(mock_download, mock_read):
    mock_read.return_value = {"Past Review Analysis": {"report_title": "Report", "paragraphs": []}}
    mock_download.return_value = (
        b"%PDF-report",
        {"Content-Disposition": 'attachment; filename="report.pdf"'},
    )
    payload = {"plan_number": "20587"}
    response = client.post("/download", json=payload)
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content == b"%PDF-report"
    mock_read.assert_called_once_with("20587")
    assert mock_download.call_args.kwargs["analysis_report"] == mock_read.return_value


@patch("router.router.read_preliminary_research_report", return_value={})
@patch("router.router.download_research_walkthrough_pdf")
def test_download_value_error(mock_download, mock_read):
    mock_download.side_effect = ValueError("Bad PDF data")
    payload = {"plan_number": "20587"}
    response = client.post("/download", json=payload)
    assert response.status_code == 400


@patch("router.router.read_preliminary_research_report", return_value=None)
@patch("router.router.download_research_walkthrough_pdf")
def test_download_not_found(mock_download, mock_read):
    payload = {"plan_number": "20587"}
    response = client.post("/download", json=payload)
    assert response.status_code == 404
    mock_download.assert_not_called()


@patch("router.router.read_preliminary_research_report")
@patch("router.router.download_research_walkthrough_pdf")
def test_main_app_download_passes_plan_name(mock_download, mock_read):
    mock_read.return_value = {"Past Review Analysis": {"report_title": "Report", "paragraphs": []}}
    mock_download.return_value = (b"%PDF-report", {})
    response = TestClient(main_app).post("/download", json={
        "plan_number": "20587",
        "plan_name": "Current Plan Item",
    })
    assert response.status_code == 200
    assert mock_download.call_args.kwargs["plan_name"] == "Current Plan Item"
