import asyncio

import pytest

from agents import analytics_agent


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": "", "affected_sections": []}
            for name in names
        ]
    }


def test_section_review_revises_with_feedback_and_stops_after_approval():
    generated_feedback = []
    model = _QueuedModel({
        "SectionReview": [
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "The conclusion is not supported.",
                        "action": "Add supporting evidence or remove the conclusion.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
            _approve_section(),
        ],
        "SectionQualityReview": [_approve_section_quality(), _approve_section_quality()],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example",
        builder,
        [{"chunk_id": "source-1", "content": "Evidence."}],
        model,
        max_revisions=1,
        failure_policy="fail_open",
    )

    assert result == "draft-2"
    assert generated_feedback == [
        None,
        "[evidence_support] The conclusion is not supported. Action: Add supporting evidence or remove the conclusion.",
    ]


def test_section_review_returns_latest_valid_draft_when_revision_limit_is_reached():
    generated_feedback = []
    model = _QueuedModel({
        "SectionReview": [
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "First issue.",
                        "action": "First correction.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "Still unsupported.",
                        "action": "Still needs work.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
        ],
        "SectionQualityReview": [_approve_section_quality(), _approve_section_quality()],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example", builder, [], model, max_revisions=1, failure_policy="fail_open"
    )

    assert result == "draft-2"
    assert len(generated_feedback) == 2


def test_section_quality_critique_is_forwarded_to_the_revision_and_rechecked():
    generated_feedback = []
    failed_quality = _approve_section_quality()
    failed_quality["criteria"][1] = {
        "name": "analysis_actionability",
        "passed": False,
        "issue": "The recommendation does not identify a validation target.",
        "action": "Name the control owner and evidence to validate.",
    }
    model = _QueuedModel({
        "SectionReview": [_approve_section(), _approve_section()],
        "SectionQualityReview": [failed_quality, _approve_section_quality()],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example",
        builder,
        [],
        model,
        max_revisions=1,
        failure_policy="fail_open",
    )

    assert result == "draft-2"
    assert generated_feedback == [
        None,
        "[analysis_actionability] The recommendation does not identify a validation target. "
        "Action: Name the control owner and evidence to validate.",
    ]


def test_section_review_failure_policy_can_fail_open_or_closed():
    model = _QueuedModel({"SectionReview": [RuntimeError("judge unavailable")]})
    builder = lambda _chunks, _model, review_feedback=None: "valid draft"

    result = analytics_agent._generate_reviewed_section(
        "Example", builder, [], model, max_revisions=1, failure_policy="fail_open"
    )
    assert result == "valid draft"

    model = _QueuedModel({"SectionReview": [RuntimeError("judge unavailable")]})
    with pytest.raises(RuntimeError, match="LLM review failed"):
        analytics_agent._generate_reviewed_section(
            "Example", builder, [], model, max_revisions=1, failure_policy="fail_closed"
        )


def test_section_quality_judge_failure_obeys_configured_failure_policy():
    builder = lambda _chunks, _model, review_feedback=None: "valid draft"
    responses = {
        "SectionReview": [_approve_section()],
        "SectionQualityReview": [RuntimeError("quality judge unavailable")],
    }
    result = analytics_agent._generate_reviewed_section(
        "Example",
        builder,
        [],
        _QueuedModel(responses),
        max_revisions=1,
        failure_policy="fail_open",
    )
    assert result == "valid draft"

    responses = {
        "SectionReview": [_approve_section()],
        "SectionQualityReview": [RuntimeError("quality judge unavailable")],
    }
    with pytest.raises(RuntimeError, match="LLM review failed"):
        analytics_agent._generate_reviewed_section(
            "Example",
            builder,
            [],
            _QueuedModel(responses),
            max_revisions=1,
            failure_policy="fail_closed",
        )


