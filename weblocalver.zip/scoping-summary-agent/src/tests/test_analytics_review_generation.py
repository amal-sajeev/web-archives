import asyncio

import pytest

from agents import analytics_agent
from agents.llm_judge.models import SectionQualityReview, SectionReview


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": "", "affected_sections": []}
            for name in names
        ]
    }


def test_prepare_multimodal_payload_caches_pdf_bytes(monkeypatch):
    download_calls = []

    def fake_read_blob(uri):
        download_calls.append(uri)
        return b"%PDF-1.4 fake bytes"

    monkeypatch.setattr(analytics_agent, "read_blob_from_uri_as_bytes", fake_read_blob)
    chunks = [
        {
            "chunk_id": "2",
            "source_name": "historical_review_document",
            "metadata": {"url": "gs://bucket/doc1.pdf"},
            "content": "text",
        }
    ]

    analytics_agent._prepare_multimodal_payload(chunks, "Prompt 1", "Past Review Analysis")
    payload_2 = analytics_agent._prepare_multimodal_payload(chunks, "Prompt 2", "Past Review Analysis")

    assert download_calls == ["gs://bucket/doc1.pdf"]
    msg = payload_2[0]
    content = msg["content"] if isinstance(msg, dict) else msg.content
    text_blocks = [
        item["text"]
        for item in content
        if isinstance(item, dict) and item.get("type") == "text"
    ]
    assert "_cached_pdf_bytes" not in "\n".join(text_blocks)
    assert "to generate the report." in "\n".join(text_blocks)

    judge_payload = analytics_agent._prepare_multimodal_payload(chunks, "Judge Prompt", "Review Past Review Analysis")
    judge_msg = judge_payload[0]
    judge_content = judge_msg["content"] if isinstance(judge_msg, dict) else judge_msg.content
    judge_text = "\n".join(
        item["text"]
        for item in judge_content
        if isinstance(item, dict) and item.get("type") == "text"
    )
    assert "to review the candidate section." in judge_text


def test_policy_regulation_caches_source_assessments_on_revision_unless_flagged(monkeypatch):
    from model.response_model import PolicyDocumentAssessment, PolicyRegulationOutput, ScopingReport

    assessment_calls = []
    captured_prompts = []

    class _PolicyModel:
        def with_structured_output(self, schema, **_kwargs):
            assert schema is PolicyRegulationOutput

            class _Runner:
                def invoke(self, payload):
                    msg = payload[0]
                    content = msg["content"] if isinstance(msg, dict) else msg.content
                    captured_prompts.append(content[0]["text"])
                    return PolicyRegulationOutput.model_validate({
                        "section1": {
                            "intro": "Intro text.",
                            "rationale": "Rationale.",
                            "confidence_score": 80,
                            "document_assessments": [],
                            "regulatory_mandates": {"mandates": []},
                        },
                        "report": ScopingReport(
                            report_title="Policy, KOD and Regulatory Analysis",
                            paragraphs=[],
                        ).model_dump(),
                    })

            return _Runner()

    def fake_assessments(_chunks, _manifest, source_name, _model, review_feedback=None):
        assessment_calls.append((source_name, review_feedback))
        if source_name == "relevant_policy":
            return [
                PolicyDocumentAssessment(
                    doc_key="POLICY|1",
                    sections=[],
                )
            ]
        return []

    monkeypatch.setattr(analytics_agent, "_policy_source_assessments", fake_assessments)
    source_chunks = [
        {"chunk_id": "1", "source_name": "current_plan_item_details", "content": {"Plan Item Number": "101"}},
        {
            "chunk_id": "2",
            "source_name": "relevant_policy",
            "content": [{"document_title": "Policy A", "nodes": [{"section_id": "1.1", "original_text": "Rule"}]}],
        },
    ]

    first_report = analytics_agent.policy_regulation(source_chunks, _PolicyModel())
    assert len(assessment_calls) == 3

    # Revision that does NOT flag document assessments should reuse cached assessments
    # and pass PolicyRegulationOutput (not assembled ScopingReport) as previous_candidate
    second_report = analytics_agent.policy_regulation(
        source_chunks,
        _PolicyModel(),
        review_feedback="[evidence_support] Update Section 5 Source Evidence Log.",
        previous_candidate=first_report,
    )
    assert len(assessment_calls) == 3
    assert "PREVIOUS CANDIDATE DRAFT FOR REFERENCE" in captured_prompts[-1]
    assert "regulatory_mandates" in captured_prompts[-1]

    # Revision that explicitly mentions POLICY| or document_assessments re-runs assessments
    analytics_agent.policy_regulation(
        source_chunks,
        _PolicyModel(),
        review_feedback="[required_content] Missing summary for POLICY|1|1.1.",
        previous_candidate=second_report,
    )
    assert len(assessment_calls) == 6


def test_research_report_evaluates_merged_report_on_partial_regeneration(monkeypatch):
    reviewed_reports = []
    revised_sections = []

    class _PartialModel:
        def __init__(self):
            self.report_call_index = 0

        def with_structured_output(self, schema, **_kwargs):
            model = self

            class _Runner:
                def invoke(self, _payload):
                    if schema.__name__ == "SectionReview":
                        return SectionReview.model_validate(_approve_section())
                    if schema.__name__ == "SectionQualityReview":
                        return SectionQualityReview.model_validate(_approve_section_quality())
                    if schema.__name__ == "ReportRubricReview":
                        rubric_responses = [
                            _approve_report_rubric(("section_coverage", "review_identifier_consistency")),
                            _approve_report_rubric(("cross_section_consistency",)),
                            _approve_report_rubric(("duplication_and_structure",)),
                        ]
                        result = schema.model_validate(rubric_responses[model.report_call_index])
                        model.report_call_index += 1
                        return result
                    raise AssertionError(f"Unexpected schema {schema}")

            return _Runner()

    orig_review_report = analytics_agent._review_report_candidate

    def spy_review_report(candidate, model):
        reviewed_reports.append(dict(candidate))
        return orig_review_report(candidate, model)

    def fake_past_builder(_chunks, _model, review_feedback=None, previous_candidate=None):
        revised_sections.append(("past_review", review_feedback))
        return {"report_title": "Past Review Analysis", "paragraphs": []}

    def fake_broad_builder(_chunks, _model, review_feedback=None, previous_candidate=None):
        revised_sections.append(("broad_scope", review_feedback))
        return {"report_title": "Broad Scope Direction", "paragraphs": [{"paragraph_id": "para_1"}]}

    monkeypatch.setattr(analytics_agent, "initialize_gemini_model", lambda: _PartialModel())
    monkeypatch.setattr(analytics_agent, "_review_report_candidate", spy_review_report)
    monkeypatch.setitem(analytics_agent.SECTION_REGISTRY["past_review"], "builder", fake_past_builder)
    monkeypatch.setitem(analytics_agent.SECTION_REGISTRY["broad_scope"], "builder", fake_broad_builder)

    previous_report = {
        "Past Review Analysis": {"report_title": "Old Past", "paragraphs": []},
        "Policy, KOD and Regulatory Analysis": {"report_title": "Old Policy", "paragraphs": []},
        "Broad Scope Direction": {"report_title": "Old Broad", "paragraphs": []},
    }
    plan_data = {"output1": [{"chunk_id": "1", "source_name": "historical_review_document"}], "output2": [], "output3": []}

    result = asyncio.run(
        analytics_agent.research_report(
            plan_data,
            sections=["broad_scope"],
            previous_report=previous_report,
        )
    )

    assert len(reviewed_reports) == 1
    assert list(reviewed_reports[0].keys()) == [
        "Past Review Analysis",
        "Policy, KOD and Regulatory Analysis",
        "Broad Scope Direction",
    ]
    assert reviewed_reports[0]["Past Review Analysis"]["report_title"] == "Old Past"
    assert reviewed_reports[0]["Broad Scope Direction"]["report_title"] == "Broad Scope Direction"
    assert result["Policy, KOD and Regulatory Analysis"]["report_title"] == "Old Policy"
    assert revised_sections == [("broad_scope", None)]


