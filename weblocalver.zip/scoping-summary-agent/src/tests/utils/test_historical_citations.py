from unittest.mock import patch

import pytest

from model.request_model import DeleteHistoricalPlanItemRequest
from utils import data_manager


def _hist(plan_number: str) -> dict:
    return {
        "source_name": "historical_review_document",
        "metadata": {"url": f"gs://b/{plan_number}.pdf"},
        "content": {"historic_plan_number": plan_number, "document_name": f"{plan_number}.pdf"},
    }


def _plain(name: str) -> dict:
    return {"source_name": name, "metadata": {"url": f"gs://b/{name}"}, "content": {}}


def _build(historical_plans: list[str]) -> dict:
    data = {
        "output1": [_plain("current"), _plain("historical_json"), *(_hist(p) for p in historical_plans)],
        "output2": [_plain("kod"), _plain("policy")],
        "output3": [_plain("current"), _plain("findings"), *(_hist(p) for p in historical_plans)],
    }
    return data_manager.add_chunk_id(data)


@pytest.mark.parametrize("plans", [[], ["1"], ["1", "2", "3"]])
def test_non_historical_chunk_ids_do_not_depend_on_historical_reviews(plans):
    data = _build(plans)
    assert [c["chunk_id"] for c in data["output1"][:2]] == [1, 2]
    assert [c["chunk_id"] for c in data["output2"]] == [3, 4]
    assert [c["chunk_id"] for c in data["output3"][:2]] == [5, 6]


def test_historical_chunks_get_stable_string_ids_in_both_outputs():
    data = _build(["10", "20"])
    assert [c["chunk_id"] for c in data["output1"][2:]] == ["HIST|10|1", "HIST|20|1"]
    assert [c["chunk_id"] for c in data["output3"][2:]] == ["HIST|10|1", "HIST|20|1"]
    mapping = data_manager.create_citation_mapping(data)
    assert mapping["HIST|10|1"][0]["access_info"]["uri"] == "gs://b/10.pdf"


def _history_rows():
    return [
        {"Plan Item Number": 1, "Plan Item Title": "Same Title"},
        {"Plan Item Number": 2, "Plan Item Title": "Same Title"},
        {"Plan Item Number": 3, "Plan Item Title": "Other"},
    ]


def test_delete_by_number_does_not_delete_rows_sharing_the_title():
    with patch.object(data_manager, "read_plan_json", return_value=("path", _history_rows())), \
            patch.object(data_manager, "write_blob_json") as write:
        result = data_manager.delete_historical_plan_item("100", ["1"])

    assert result["deleted_count"] == 1
    assert "blob_path" not in result
    assert [r["Plan Item Number"] for r in write.call_args[0][1]] == [2, 3]


def test_delete_requires_a_plan_item_number():
    with pytest.raises(ValueError):
        data_manager.delete_historical_plan_item("100", [])


def test_delete_request_accepts_list_documents_output_with_numeric_values():
    request = DeleteHistoricalPlanItemRequest.model_validate(
        {
            "planNumber": 100,
            "planItems": [
                {"plan_item_number": 1, "plan_item_title": "Same Title"},
                {"Plan Item Number": "2", "Plan Item Title": None},
            ],
        }
    )
    assert request.plan_number == "100"
    assert [i.plan_item_number for i in request.plan_items] == [1, "2"]
    assert request.plan_items[0].plan_item_title == "Same Title"
