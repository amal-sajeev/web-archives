import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

# Ensure src/main is prioritized on sys.path during pytest runs
src_main = Path(__file__).resolve().parents[1] / "main"
if str(src_main) not in sys.path:
    sys.path.insert(0, str(src_main))

# Extend the config namespace package so config.config and prompts resolve
agent_config_dir = str(src_main / "config")
try:
    import config
    if hasattr(config, "__path__"):
        if not isinstance(config.__path__, list):
            config.__path__ = list(config.__path__)
        if agent_config_dir not in config.__path__:
            config.__path__.insert(0, agent_config_dir)
except Exception:
    pass

# Stub ActionServiceClt if the external network/PubSub dependencies are not reachable in test runs
if "action_client" not in sys.modules:
    mock_action_client = MagicMock()
    mock_clt_instance = MagicMock()
    mock_clt_instance.persist_action = lambda func: func
    mock_action_client.ActionServiceClt.return_value = mock_clt_instance
    sys.modules["action_client"] = mock_action_client

# Set test fallback environment variables for Google Cloud dependencies
os.environ.setdefault("PROJECT_NAME", "db-dev-46jr-mp-cta-analytics")
os.environ.setdefault("PROJECT_LOCATION", "europe-west1")
os.environ.setdefault("DBAWARE_REVIEW_BUCKET_NAME", "db-dev-euwe3-gcs-155081-dbaware_review")
os.environ.setdefault("bucket_name", "db-dev-euwe3-gcs-155081-dbaware_review")
os.environ.setdefault("GCP_MODEL_NAME", "gemini-2.5-pro")
