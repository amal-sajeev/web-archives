from agents import analytics_agent


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {
                "name": name,
                "passed": True,
                "issue": "",
                "action": "",
                "affected_sections": [],
            }
            for name in names
        ]
    }



def test_section_review_autofills_missing_action_when_issue_is_provided():
    generated_feedback = []
    model = _QueuedModel(
        {
            "SectionReview": [
                {
                    "criteria": [
                        {
                            "name": "required_content",
                            "passed": False,
                            "issue": "Section 2 is missing dbGRC Control Scope.",
                            "action": "",
                        },
                        *[
                            {"name": name, "passed": True, "issue": "", "action": ""}
                            for name in (
                                "evidence_support",
                                "citation_validity",
                                "schema_compliance",
                            )
                        ],
                    ]
                },
                _approve_section(),
            ],
            "SectionQualityReview": [
                _approve_section_quality(),
                _approve_section_quality(),
            ],
        }
    )

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Broad Scope Direction",
        builder,
        [],
        model,
        max_revisions=1,
        failure_policy="fail_closed",
    )

    assert result == "draft-2"
    assert generated_feedback[1].startswith(
        "[required_content] Section 2 is missing dbGRC Control Scope. Action: Resolve the reported required_content issue:"
    )
