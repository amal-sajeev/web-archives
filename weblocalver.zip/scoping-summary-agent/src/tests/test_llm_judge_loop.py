from contextlib import redirect_stdout
from io import StringIO

import pytest
from agents.llm_judge import ReviewLoopError, review_and_revise


def _rejected(candidate):
    return {"approved": False, "feedback": f"Fix {candidate}"}


def test_zero_revisions_reviews_once_and_returns_candidate():
    calls = []
    result = review_and_revise(
        "draft-1",
        reviewer=lambda candidate: calls.append(candidate) or _rejected(candidate),
        reviser=lambda candidate, _review: f"revised-{candidate}",
        approved=lambda review: review["approved"],
        has_feedback=lambda review: bool(review["feedback"]),
        stage="example",
        max_revisions=0,
    )

    assert calls == ["draft-1"]
    assert result.candidate == "draft-1"
    assert result.revisions == 0
    assert result.outcome == "revision_limit"


def test_revision_failure_keeps_latest_candidate_or_raises_by_policy():
    common = {
        "candidate": "draft-1",
        "reviewer": _rejected,
        "reviser": lambda _candidate, _review: (_ for _ in ()).throw(ValueError("private details")),
        "approved": lambda review: review["approved"],
        "has_feedback": lambda review: bool(review["feedback"]),
        "stage": "example",
        "max_revisions": 1,
    }
    result = review_and_revise(**common, failure_policy="fail_open")
    assert result.candidate == "draft-1"
    assert result.outcome == "revision_failure"

    with pytest.raises(ReviewLoopError, match="LLM revision failed"):
        review_and_revise(**common, failure_policy="fail_closed")


def test_validation_callback_failure_uses_review_failure_policy():
    args = {
        "candidate": "draft-1",
        "reviewer": lambda _candidate: object(),
        "reviser": lambda candidate, _review: candidate,
        "approved": lambda _review: (_ for _ in ()).throw(ValueError("private details")),
        "has_feedback": lambda _review: True,
        "stage": "example",
    }
    assert review_and_revise(**args, failure_policy="fail_open").outcome == "review_failure"
    with pytest.raises(ReviewLoopError, match="LLM review failed"):
        review_and_revise(**args, failure_policy="fail_closed")


def test_judge_debug_output_is_toggleable_and_content_free(monkeypatch, caplog):
    monkeypatch.delenv("LLM_JUDGE_DEBUG", raising=False)
    monkeypatch.delenv("SUMMARY_AGENT_JUDGE_DEBUG", raising=False)
    caplog.set_level("DEBUG")

    buf = StringIO()
    with redirect_stdout(buf):
        review_and_revise(
            "draft-1",
            reviewer=lambda candidate: _rejected(candidate),
            reviser=lambda candidate, _review: f"revised-{candidate}",
            approved=lambda review: review["approved"],
            has_feedback=lambda review: bool(review["feedback"]),
            stage="example",
            max_revisions=1,
        )
    output = buf.getvalue()
    assert "LLM JUDGE DEBUG" not in output
    assert "draft-1" not in output
    assert "draft-1" not in caplog.text

    monkeypatch.setenv("LLM_JUDGE_DEBUG", "true")
    buf = StringIO()
    with redirect_stdout(buf):
        review_and_revise(
            "draft-1",
            reviewer=lambda candidate: _rejected(candidate),
            reviser=lambda candidate, _review: f"revised-{candidate}",
            approved=lambda review: review["approved"],
            has_feedback=lambda review: bool(review["feedback"]),
            stage="example",
            max_revisions=1,
        )
    output = buf.getvalue()
    assert "LLM JUDGE DEBUG" in output
    assert "stage=example" in output
    assert "event=initial_candidate" in output
    assert "draft-1" not in output
    assert "Fix draft-1" not in output
    assert "draft-1" not in caplog.text

    monkeypatch.setenv("LLM_JUDGE_DEBUG", "false")
    buf = StringIO()
    with redirect_stdout(buf):
        review_and_revise(
            "draft-2",
            reviewer=lambda candidate: {"approved": True, "feedback": ""},
            reviser=lambda candidate, _review: f"revised-{candidate}",
            approved=lambda review: review["approved"],
            has_feedback=lambda review: bool(review["feedback"]),
            stage="example",
            max_revisions=1,
        )
    output = buf.getvalue()
    assert "LLM JUDGE DEBUG" not in output
    assert "draft-2" not in output


def test_verify_final_revision_false_skips_redundant_post_revision_judge():
    reviewer_calls = []
    result = review_and_revise(
        "draft-1",
        reviewer=lambda candidate: reviewer_calls.append(candidate) or _rejected(candidate),
        reviser=lambda candidate, _review: f"revised-{candidate}",
        approved=lambda review: review["approved"],
        has_feedback=lambda review: bool(review["feedback"]),
        stage="example",
        max_revisions=1,
        verify_final_revision=False,
    )

    assert reviewer_calls == ["draft-1"]
    assert result.candidate == "revised-draft-1"
    assert result.revisions == 1
    assert result.outcome == "revision_limit"

