import asyncio

from agents import analytics_agent


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {
                "name": name,
                "passed": True,
                "issue": "",
                "action": "",
                "affected_sections": [],
            }
            for name in names
        ]
    }


def test_report_review_normalizes_section_aliases_and_avoids_nested_revision_loops():
    builder_calls = []

    def broad_builder(_chunks, _model, review_feedback=None, previous_candidate=None):
        builder_calls.append((review_feedback, previous_candidate))
        return {"section": f"broad-call-{len(builder_calls)}"}

    model = _QueuedModel(
        {
            "ReportRubricReview": [
                _approve_report_rubric(
                    ("section_coverage", "review_identifier_consistency")
                ),
                {
                    "criteria": [
                        {
                            "name": "cross_section_consistency",
                            "passed": False,
                            "issue": "Inconsistent scope description.",
                            "action": "Align Broad Scope with Policy section.",
                            "affected_sections": ["broad_scope"],
                        }
                    ]
                },
                _approve_report_rubric(("duplication_and_structure",)),
                _approve_report_rubric(
                    ("section_coverage", "review_identifier_consistency")
                ),
                _approve_report_rubric(("cross_section_consistency",)),
                _approve_report_rubric(("duplication_and_structure",)),
            ],
            # Even if SectionReview rejects during complete-report revision, max_revisions=0
            # inside _review_complete_report ensures no nested revision loop occurs.
            "SectionReview": [
                {
                    "criteria": [
                        {
                            "name": "evidence_support",
                            "passed": False,
                            "issue": "Nested section judge complaint.",
                            "action": "Would trigger nested revision if max_revisions > 0.",
                        },
                        *[
                            {"name": name, "passed": True, "issue": "", "action": ""}
                            for name in (
                                "citation_validity",
                                "required_content",
                                "schema_compliance",
                            )
                        ],
                    ]
                }
            ],
            "SectionQualityReview": [_approve_section_quality()],
        }
    )

    result = asyncio.run(
        analytics_agent._review_complete_report(
            {"Broad Scope Direction": {"section": "broad-original"}},
            model,
            {"Broad Scope Direction": (broad_builder, [])},
            max_revisions=2,
            failure_policy="fail_open",
        )
    )

    assert len(builder_calls) == 1
    assert result["Broad Scope Direction"] == {"section": "broad-call-1"}
