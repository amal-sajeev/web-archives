from model.response_model import PolicyRegulationOutput
from utils.policy_section_builder import (
    MISSING_SUMMARY_TEXT,
    assemble_policy_report,
    build_policy_manifest,
    build_regulation_manifest,
    regulation_citation_mapping,
    to_model_source_chunks,
)

RATIONALE = "Highly relevant because Section 4.5.4 mandates quarterly reviews.\nSecond line kept as-is."


def _node(section_id, title, path, text, page):
    return {
        "section_id": section_id,
        "section_title": title,
        "section_path": path,
        "original_text": text,
        "page_start": page,
        "page_end": page,
        "node_id": f"1:section:{section_id}",
    }


def _source_chunks():
    policy_doc = {
        "document_id": "1",
        "document_title": "German_Bank_Separation_Act__GBSA__-_Global",
        "document_version": "1.0",
        "storage_uri": "gs://bucket/gbsa.pdf",
        "document_relevance_score": 57.736,
        "document_relevance_verdict": "HIGH",
        "rationale": RATIONALE,
        "nodes": [
            _node("4.10", "Late", ["Section 4 Trading"], "text 4.10", 60),
            _node("4.5.4", "Detective Controls", ["Section 4 Trading", "Section 4.5 Governance"], "text 4.5.4", 50),
            _node("2.3", "Governance", ["Section 2 Prop"], "text 2.3 a", 19),
            _node("4.5", "Governance", ["Section 4 Trading"], "text 4.5", 48),
            _node("2.3", "Governance", ["Section 2 Prop"], "text 2.3 b", 20),
            _node("5(GBSA)", "(GBSA)", ["Section 5 Glossary"], "text gbsa", 52),
        ],
    }
    kod_doc = {
        "document_id": "1",
        "document_title": "KOD_One",
        "document_version": "2.0",
        "document_relevance_score": 3.14159,
        "document_relevance_verdict": "medium",
        "rationale": "Brief KOD rationale.",
        "nodes": [_node("1.1", "Intro", [], "kod text", 1)],
    }
    return [
        {"chunk_id": 1, "source_name": "current_plan_item_details", "content": {"plan": "x"}},
        {"chunk_id": 2, "source_name": "relevant_kod", "content": [kod_doc]},
        {"chunk_id": 3, "source_name": "relevant_procedure", "content": {}},
        {"chunk_id": 4, "source_name": "relevant_policy", "content": [policy_doc]},
        {"chunk_id": 5, "source_name": "internet_search", "content": [{
            "Risk Name": "R032 - Employee Licensing",
            "Mandates": [{
                "Regulatory Mandate": "Designate a registered principal.",
                "Confidence Score": 1.0,
                "AI Rationale": "Maps to R032.",
                "Evidence": [{
                    "source_url": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110",
                    "evidence_text": "(2) The designation...",
                    "deep_link": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110#:~:text=The%20designation",
                }],
            }, {
                "Regulatory Mandate": "Second mandate.",
                "AI Rationale": "Verbatim AI rationale.",
                "Evidence": [{"evidence_text": "Evidence with neither deep_link nor source_url."}],
            }],
        }]},
    ]


def _section(key, text="Summary.", applicability="Directly Applicable"):
    return {"key": key, "summary": text, "applicability": applicability, "relevance": "Impacts testing."}


def _model_output(policy_sections, extra_paragraphs=None):
    paragraphs = extra_paragraphs or []
    paragraphs.append({
        "paragraph_id": "x",
        "content": "Section 2: Obligation to Process and Control Traceability\nBody.",
        "supporting_chunk_ids": ["4"],
        "metadata": {"is_section_start": True, "section_confidence_score": 60},
    })
    return PolicyRegulationOutput.model_validate({
        "section1": {
            "intro": "Review intro.",
            "rationale": "Section rationale.",
            "confidence_score": 75,
            "document_assessments": [
                {"doc_key": "POLICY|1", "sections": policy_sections},
                {"doc_key": "KOD|1", "sections": [_section("KOD|1|1.1")]},
                {"doc_key": "POLICY|99", "sections": []},
            ],
            "regulatory_mandates": {"mandates": [
                {"key": "REG|1|1", "name": "FINRA 3110 Principal Designation",
                 "applicability": "Directly Applicable", "content": "Requires a registered principal."},
                {"key": "REG|9|9", "name": "Unknown", "applicability": "Not Applicable", "content": "Unknown."},
            ]},
        },
        "report": {"report_title": "ignored", "paragraphs": paragraphs},
    })


def test_manifest_uses_unique_keys_merges_duplicates_and_sorts_naturally():
    manifest = build_policy_manifest(_source_chunks())

    policy_doc = manifest["relevant_policy"]["documents"][0]
    assert policy_doc["doc_key"] == "POLICY|1"
    assert policy_doc["storage_uri"] == "gs://bucket/gbsa.pdf"
    assert [s["section_id"] for s in policy_doc["sections"]] == ["2.3", "4.5", "4.5.4", "4.10", "5(GBSA)"]
    merged = policy_doc["sections"][0]
    assert merged["texts"] == ["text 2.3 a", "text 2.3 b"]
    assert (merged["page_start"], merged["page_end"]) == (19, 20)
    # Same document_id "1" in another file must not collide.
    assert manifest["relevant_kod"]["documents"][0]["sections"][0]["key"] == "KOD|1|1.1"
    assert manifest["relevant_procedure"]["documents"] == []

    model_chunks = to_model_source_chunks(_source_chunks(), manifest)
    policy_chunk = next(c for c in model_chunks if c["source_name"] == "relevant_policy")
    assert policy_chunk["chunk_id"] == 4
    assert policy_chunk["content"][0]["sections"][0]["text"] == "text 2.3 a\n\ntext 2.3 b"
    reg_chunk = next(c for c in model_chunks if c["source_name"] == "internet_search")
    assert reg_chunk["content"] == _source_chunks()[4]["content"]

    with_reg = to_model_source_chunks(_source_chunks(), manifest, build_regulation_manifest(_source_chunks()))
    reg_content = next(c for c in with_reg if c["source_name"] == "internet_search")["content"]
    assert [m["key"] for m in reg_content] == ["REG|1|1", "REG|1|2"]

    assert "deep_link" not in reg_content[0]["evidence"][0]


def test_regulation_citation_mapping_uses_deep_link():
    mapping = regulation_citation_mapping(build_regulation_manifest(_source_chunks()))

    entry = mapping["REG|1|1|1"][0]
    assert entry["url"].endswith("#:~:text=The%20designation")
    assert entry["citation_label"] == "finra.org 3110"
    


def test_assemble_builds_section1_from_source_and_matches_by_key():
    source_chunks = _source_chunks()
    manifest = build_policy_manifest(source_chunks)
    # Model returns sections out of order and omits 4.10.
    output = _model_output(
        [_section("POLICY|1|5(GBSA)"), _section("POLICY|1|4.5.4", "Detective summary."),
         _section("POLICY|1|2.3"), _section("POLICY|1|4.5")],
        extra_paragraphs=[{
            "paragraph_id": "y",
            "content": "Section 1: Policy, KOD/Procedure and Regulatory Analysis\nModel-written.",
            "supporting_chunk_ids": [],
            "metadata": {"is_section_start": True, "section_confidence_score": 50},
        }],
    )

    report = assemble_policy_report(output, manifest, source_chunks, "Policy, KOD and Regulatory Analysis")
    contents = [p.content for p in report.paragraphs]

    assert report.report_title == "Policy, KOD and Regulatory Analysis"
    assert [p.paragraph_id for p in report.paragraphs] == [f"para_{i}" for i in range(1, len(contents) + 1)]
    assert contents[0] == "Section 1: Policy, KOD/Procedure and Regulatory Analysis\nReview intro."
    assert report.paragraphs[0].metadata.is_section_start
    assert report.paragraphs[0].supporting_chunk_ids == ["1"]
    assert report.paragraphs[0].rationale == "Section rationale."
    assert report.paragraphs[0].metadata.heading_level is None

    assert contents[1] == "**Regulatory Mandates**"
    assert report.paragraphs[1].metadata.heading_level == 2
    # Applicability sits on the heading line; rationale comes verbatim from the source JSON.
    assert contents[2] == (
        "1. **FINRA 3110 Principal Designation** - Directly Applicable\n"
        "Maps to R032.\n"
        "Requires a registered principal."
    )
    assert report.paragraphs[2].metadata.heading_level == 3
    assert report.paragraphs[2].supporting_chunk_ids == ["REG|1|1|1"]
    # Missing model output falls back to the risk name and source mandate text, without applicability.
    assert contents[3] == "2. **R032 - Employee Licensing**\nVerbatim AI rationale.\nSecond mandate."
    assert report.paragraphs[3].supporting_chunk_ids == []
    assert report.paragraphs[4].metadata.heading_level == 2
    assert report.paragraphs[5].metadata.heading_level == 3
    assert report.paragraphs[6].metadata.heading_level is None
    del contents[1:4]
    contents.insert(1, "regulatory")
    paragraphs = report.paragraphs[:1] + [None] + report.paragraphs[4:]

    assert contents[2] == "**Policy**"
    policy_header = contents[3]
    assert policy_header == (
        "1. **German Bank Separation Act GBSA - Global** - Directly Applicable\n"
        "Relevance Score: 57.74\n"
        f"{RATIONALE}"
    )
    assert "Version" not in policy_header and "Rationale:" not in policy_header
    policy_sections = contents[4:9]
    assert [paragraph.supporting_chunk_ids for paragraph in paragraphs[4:9]] == [
        ["POLICY|1|2.3"], ["POLICY|1|4.5"], ["POLICY|1|4.5.4"],
        ["POLICY|1|4.10"], ["POLICY|1|5(GBSA)"],
    ]
    order = [policy_sections.index(next(text for text in policy_sections if marker in text)) for marker in (
        "<u>Section 2.3 Governance</u>",
        "<u>Section 4.5 Governance</u>",
        "<u>Section 4.5.4 Detective Controls</u>: Detective summary.",
        "<u>Section 4.10 Late</u>",
        "<u>Section 5(GBSA)</u>",
    )]
    assert order == sorted(order)
    # Parent headings from section_path are not rendered.
    for parent in ("Section 2 Prop", "Section 4 Trading", "Section 5 Glossary"):
        assert all(parent not in text for text in policy_sections)
    assert f"<u>Section 4.10 Late</u>: {MISSING_SUMMARY_TEXT}" in policy_sections[3]
    assert "Applicability: Directly Applicable. Impacts testing." in policy_sections[0]

    assert contents[9].startswith("**Procedure**\nData Not Available")
    assert contents[10] == "**KOD**"
    assert contents[11].startswith("1. **KOD One** - Partially Applicable\nRelevance Score: 3.14\nBrief KOD rationale.")
    assert "KOD rationale." not in contents[11].replace("Brief KOD rationale.", "")
    assert paragraphs[12].supporting_chunk_ids == ["KOD|1|1.1"]
    # Model's own Section 1 is discarded; Section 2 follows the assembled Section 1.
    assert contents[13].startswith("Section 2:")
    assert len(contents) == 14
