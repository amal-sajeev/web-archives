from model.response_model import (
    BroadScopeCollationOutput,
    BroadScopePartOutput,
    NarrativeUnit,
    ParagraphCitation,
    ParagraphMetadata,
    SupportingCitation,
    normalize_model_text,
)
from utils.broad_scope_builder import (
    NOT_GENERATED_TEXT,
    RISK_DRIVERS_TITLE,
    RISK_DRIVERS_UNAVAILABLE_TEXT,
    BroadScopePart,
    build_risk_driver_paragraphs,
    build_section1,
    build_section2,
    cited_chunk_ids,
    compact_dbgrc_controls,
    control_level_kc_ids,
    dbgrc_has_control_instances,
    draft_for_collation,
    empty_dbgrc_fallback_paragraph,
    empty_findings_ga_fallback_paragraphs,
    finalize_broad_scope_report,
    has_control_level_kcs,
    normalize_broad_scope_part_output,
    resolve_draft_refs,
    restrict_citations,
)


def _para(text, chunk_ids=(), page=None, section_start=False, rationale=None):
    return ParagraphCitation(
        paragraph_id="x",
        content=[
            NarrativeUnit(
                content=text,
                citation_status="supported" if chunk_ids else "unsupported",
                supporting_chunk_ids=list(chunk_ids),
                supporting_citations=[SupportingCitation(chunk_id=c, page_number=page) for c in chunk_ids],
            )
        ],
        rationale=rationale,
        metadata=ParagraphMetadata(
            is_section_start=section_start,
            section_confidence_score=70 if section_start else None,
        ),
    )


def _text(paragraph):
    return paragraph.content if isinstance(paragraph.content, str) else paragraph.content[0].content


def test_model_text_literal_newlines_and_inline_section_heading_are_fixed():
    assert normalize_model_text("**Section 4: Gaps**\\n**Gap 1**\\n- Item") == "**Section 4: Gaps**\n**Gap 1**\n- Item"
    assert normalize_model_text("**Section 3: Walkthrough** To finalize.") == "**Section 3: Walkthrough**\nTo finalize."
    # Inline bold labels are left alone.
    assert normalize_model_text("**Risk Info:** R014 : Suitability") == "**Risk Info:** R014 : Suitability"
    assert _text(_para("**Monitor only**\\n- Item")) == "**Monitor only**\n- Item"


LAYOUT = {
    "in_scope": ["dbgrc", "historical"],
    "out_of_scope": ["dbgrc", "findings_ga", "historical", "alc_nc"],
}


def _parts():
    historical = BroadScopePart(
        key="historical",
        label="Historical Plan Context",
        status="ok",
        output=BroadScopePartOutput(
            section1=[
                _para("**Section 1: Broad Scope Direction**\nPlan", ["1"], section_start=True, rationale="S1"),
                _para("Hypothesis", ["10"], page=3, section_start=True, rationale="wrong"),
            ],
            in_scope=[_para("Hist in", ["10"], page=4, section_start=True, rationale="drop")],
            out_of_scope=[_para("Hist out", ["10"], page=2)],
        ),
    )
    dbgrc = BroadScopePart(
        key="dbgrc",
        label="dbGRC Control Scope",
        status="skipped",
        unavailable_text="Data Not Available - dbGRC",
    )
    alc = BroadScopePart(key="alc_nc", label="Alternate Coverage", status="skipped")
    findings = BroadScopePart(key="findings_ga", label=None, status="failed")
    return [historical, dbgrc, alc, findings]


def test_sections_1_and_2_are_assembled_in_layout_order_with_placeholders():
    parts = _parts()
    section1 = build_section1(parts)
    section2 = build_section2(parts, LAYOUT)

    assert [p.metadata.is_section_start for p in section1] == [True, False]
    assert section1[0].rationale == "S1"
    assert section1[1].rationale is None

    assert [_text(p) for p in section2] == [
        section2[0].content,
        "**A. In-scope**",
        "**dbGRC Control Scope**",
        "Data Not Available - dbGRC",
        "**Historical Plan Context**",
        "Hist in",
        "**B. Out of scope**",
        NOT_GENERATED_TEXT,
        "**Historical Plan Context**",
        "Hist out",
    ]
    assert section2[0].metadata.is_section_start
    assert all(not p.metadata.is_section_start and p.rationale is None for p in section2[1:])


def test_finalize_appends_collation_and_renumbers():
    parts = _parts()
    section1 = build_section1(parts)
    section2 = build_section2(parts, LAYOUT)
    collation = BroadScopeCollationOutput(
        section2_rationale="S2",
        section2_confidence_score=55,
        section3=[
            _para("**Section 3: Scope Validation and Walkthrough Preparation**\nQ", section_start=True, rationale="S3"),
            _para("**Assumptions and Boundaries for Confirmation**", section_start=True, rationale="drop"),
        ],
    )

    report = finalize_broad_scope_report(section1, section2, collation, "Broad Scope Direction")

    starts = [p for p in report.paragraphs if p.metadata.is_section_start]
    assert [p.rationale for p in starts] == ["S1", "S2", "S3"]
    assert starts[1].metadata.section_confidence_score == 55
    texts = [_text(p) for p in report.paragraphs]
    assert texts[-1] == "**Assumptions and Boundaries for Confirmation**"
    assert [p.paragraph_id for p in report.paragraphs] == [f"para_{i}" for i in range(1, len(texts) + 1)]


def test_finalize_without_collation_adds_section3_placeholder():
    parts = _parts()
    report = finalize_broad_scope_report(
        build_section1(parts), build_section2(parts, LAYOUT), None, "Broad Scope Direction"
    )

    last = report.paragraphs[-1]
    assert last.metadata.is_section_start
    assert last.content.startswith("**Section 3: Scope Validation and Walkthrough Preparation**")


def test_risk_driver_paragraphs_render_source_data_as_is():
    chunk = {
        "chunk_id": 7,
        "source_name": "risk_drivers",
        "content": [
            {"riskid": "R014", "risk_name": "Suitability", "risk_drivers": []},
            {
                "riskid": "R029",
                "risk_name": "Personal Trading",
                "risk_drivers": [
                    {"riskDriverId": "R029 - RD16", "riskDrivers": "Fails to disclose PIT.", "rationale": "Plan tests PIT."},
                    {"riskDriverId": "R029 - RD3", "riskDrivers": "Trades without pre-clearance.", "rationale": "Plan tests PAD."},
                ],
            },
        ],
    }

    paragraphs = build_risk_driver_paragraphs(chunk)

    assert paragraphs[0].content == RISK_DRIVERS_TITLE
    assert paragraphs[0].metadata.heading_level == 3
    assert paragraphs[1].content == (
        "**Risk Info:** R014 : Suitability\n"
        "**Relevant Risk Driver Info:** No relevant risk drivers identified."
    )
    assert paragraphs[2].content == (
        "**Risk Info:** R029 : Personal Trading\n"
        "**Relevant Risk Driver Info:** 2 relevant risk driver(s) identified.\n"
        "- **RD16**: Fails to disclose PIT.\n"
        "    - **Rationale:** Plan tests PIT.\n"
        "- **RD3**: Trades without pre-clearance.\n"
        "    - **Rationale:** Plan tests PAD."
    )
    assert all(p.supporting_chunk_ids == ["7"] for p in paragraphs[1:])
    assert not any(p.metadata.is_section_start for p in paragraphs)


def test_risk_driver_paragraphs_without_data():
    assert [_text(p) for p in build_risk_driver_paragraphs(None)] == [RISK_DRIVERS_TITLE, RISK_DRIVERS_UNAVAILABLE_TEXT]


def test_restrict_citations_drops_foreign_chunk_ids():
    paragraph = _para("Claim", ["2", "99"], page=5)
    only_foreign = _para("Other", ["99"])

    restrict_citations([paragraph, only_foreign], {"1", "2"}, "dbgrc")

    unit = paragraph.content[0]
    assert unit.supporting_chunk_ids == ["2"]
    assert [c.chunk_id for c in unit.supporting_citations] == ["2"]
    assert unit.citation_status == "supported"
    foreign_unit = only_foreign.content[0]
    assert foreign_unit.supporting_chunk_ids == []
    assert foreign_unit.supporting_citations == []
    assert foreign_unit.citation_status == "unsupported"


def test_draft_for_collation_gives_refs_only_to_cited_units():
    paragraphs = [_para("Fact", ["10"], page=3), _para("Heading")]

    draft, refs = draft_for_collation(paragraphs)

    assert draft == [{"text": "Fact", "ref": "D1"}, {"text": "Heading"}]
    assert [(c.chunk_id, c.page_number) for c in refs["D1"]] == [("10", 3)]
    assert cited_chunk_ids(paragraphs) == {"10"}


def test_resolve_draft_refs_swaps_refs_for_original_citations():
    _draft, refs = draft_for_collation([_para("Hist fact", ["10"], page=4), _para("Plan fact", ["1"])])
    bullet = ParagraphCitation(
        paragraph_id="p",
        content=[
            NarrativeUnit(
                content="• Assumption.",
                citation_status="unsupported",
                supporting_chunk_ids=["D1", "POLICY|1|4.3", "D2"],
                supporting_citations=[SupportingCitation(chunk_id="POLICY|1|4.3", page_number=46)],
            )
        ],
        metadata=ParagraphMetadata(is_section_start=False),
    )

    resolve_draft_refs([bullet], refs)

    unit = bullet.content[0]
    assert [(c.chunk_id, c.page_number) for c in unit.supporting_citations] == [
        ("POLICY|1|4.3", 46),
        ("10", 4),
        ("1", None),
    ]
    assert unit.supporting_chunk_ids == ["POLICY|1|4.3", "10", "1"]
    assert unit.citation_status == "supported"


AU_ROW = "2617 - Q1 2026~~Private Bank~Private Bank International~PB Europe International~~UK and Ireland~UK~DB UK"
PLAN = {
    "AU-RT-KC": [
        {"RT": "R150", "AU": AU_ROW, "KC": ""},
        {"RT": "R154", "AU": AU_ROW, "KC": "KC-AU"},
        {"RT": "", "AU": "~~~~~~~~", "KC": "KC-AU"},
        {"RT": "", "AU": "~~~~~~~~", "KC": "KC-CTRL"},
        {"RT": "", "AU": "~~~~~~~~", "KC": "KC-RETIRED"},
    ]
}


def _dbgrc_row(control_id, instance, au, risk, state="Active"):
    return {
        "inventory": {
            "controlDefinitionNumber": control_id,
            "controlInstanceNumber": instance,
            "assessmentUnitDer": au,
            "controlInstanceState": state,
            "controlFrequency": "Daily",
            "riskId": risk,
            "riskTypeLevel2": f"{risk} name",
        },
        "definition": {"controlWhat": f"{control_id} what", "controlWhy": f"{control_id} why"},
        "objective": {
            "controlObjectiveNumber": "CO1",
            "controlObjectiveName": "Objective",
            "controlObjectiveDescription": "Objective description",
            "supplementalGuidance": "MCS text",
        },
    }


def test_control_level_kcs_come_from_plan_rows_without_au():
    assert control_level_kc_ids(PLAN) == {"KC-CTRL", "KC-RETIRED"}
    assert control_level_kc_ids(None) == set()


def test_compact_dbgrc_reports_unaligned_controls_at_control_level():
    content = {
        "included_kcs": [
            _dbgrc_row("KC-AU", "CTRL1", "PB Europe International", "R154"),
            _dbgrc_row("KC-CTRL", "CTRL2", "AU A", "R154"),
            _dbgrc_row("KC-CTRL", "CTRL3", "AU B", "R154"),
            _dbgrc_row("KC-CTRL", "CTRL4", "AU C", "R150"),
        ],
        "excluded_kcs": [
            {"controlIdentifier": "KC-CTRL", "reason": "RETIRED_IN_DBGRC",
             "details": _dbgrc_row("KC-CTRL", "CTRL5", "AU D", "R155", "Retired")},
            {"controlIdentifier": "KC-RETIRED", "reason": "RETIRED_IN_DBGRC",
             "details": _dbgrc_row("KC-RETIRED", "CTRL6", "AU E", "R151", "Retired")},
            {"controlIdentifier": "KC-MISSING", "reason": "MISSING_IN_DBGRC", "details": "No match"},
        ],
    }

    compacted = compact_dbgrc_controls(content, PLAN)

    assert [row["controlInstanceNumber"] for row in compacted["included_kcs"]] == ["CTRL1"]
    assert compacted["excluded_kcs"] == [content["excluded_kcs"][2]]
    assert set(compacted["control_definitions"]) == {"KC-AU"}
    assert compacted["control_level_included_kcs"] == [{
        "controlDefinitionNumber": "KC-CTRL",
        "risk_tags": [
            {"riskId": "R154", "riskTypeLevel2": "R154 name"},
            {"riskId": "R150", "riskTypeLevel2": "R150 name"},
            {"riskId": "R155", "riskTypeLevel2": "R155 name"},
        ],
        "controlWhat": "KC-CTRL what",
        "controlWhy": "KC-CTRL why",
        "controlObjectiveNumber": "CO1",
        "controlObjectiveName": "Objective",
        "controlObjectiveDescription": "Objective description",
        "supplementalGuidance": "MCS text",
    }]
    [retired] = compacted["control_level_excluded_kcs"]
    assert retired["controlDefinitionNumber"] == "KC-RETIRED"
    assert retired["reason"] == "RETIRED_IN_DBGRC"
    assert "controlInstanceNumber" not in retired


def test_compact_dbgrc_without_plan_keeps_instance_level():
    content = {"included_kcs": [_dbgrc_row("KC-CTRL", "CTRL2", "AU A", "R154")], "excluded_kcs": []}
    compacted = compact_dbgrc_controls(content)
    assert [row["controlInstanceNumber"] for row in compacted["included_kcs"]] == ["CTRL2"]
    assert "control_level_included_kcs" not in compacted


def test_compact_dbgrc_instance_definitions_come_only_from_definition_and_objective():
    row = _dbgrc_row("KC-AU", "CTRL1", "PB Europe International", "R154")
    row["inventory"]["controlDefinitionName"] = "Name only in inventory"
    later = _dbgrc_row("KC-AU", "CTRL9", "PB Europe International", "R154")
    later["definition"] = {"controlWhat": "later row what", "controlHow": "later row how"}

    compacted = compact_dbgrc_controls({"included_kcs": [row, later], "excluded_kcs": []}, PLAN)

    assert compacted["control_definitions"]["KC-AU"] == {
        "controlWhat": "KC-AU what",
        "controlWhy": "KC-AU why",
        "controlObjectiveNumber": "CO1",
        "controlObjectiveName": "Objective",
        "controlObjectiveDescription": "Objective description",
        "supplementalGuidance": "MCS text",
    }


def test_empty_dbgrc_and_findings_ga_fallbacks_and_normalization():
    chunks = [
        {"chunk_id": "1", "source_name": "current_plan_item_details", "content": {"Plan Item Number": "20086"}},
        {"chunk_id": "2", "source_name": "key_controls", "content": {"included_kcs": [], "excluded_kcs": []}},
        {"chunk_id": "3", "source_name": "findings", "content": []},
        {"chunk_id": "4", "source_name": "group_audit", "content": []},
    ]
    assert not dbgrc_has_control_instances(chunks)
    assert not has_control_level_kcs(chunks)

    dbgrc_para = empty_dbgrc_fallback_paragraph(chunks, "current_plan_item_details")
    assert "no controls were fetched from dbGRC" in dbgrc_para.content[0].content
    assert dbgrc_para.content[0].supporting_chunk_ids == ["1", "2"]

    findings_out = BroadScopePartOutput(section1=[], in_scope=[], out_of_scope=[])
    normalize_broad_scope_part_output("findings_ga", findings_out, chunks)
    assert len(findings_out.out_of_scope) == 2
    assert "Open Findings from GFMS" in findings_out.out_of_scope[0].content[0].content
    assert "Group Audit Overlap" in findings_out.out_of_scope[1].content[0].content

    misplaced_dbgrc = BroadScopePartOutput(section1=[_para("Misplaced control scope", ["2"])], in_scope=[], out_of_scope=[])
    normalize_broad_scope_part_output("dbgrc", misplaced_dbgrc, chunks)
    assert len(misplaced_dbgrc.in_scope) == 1
    assert misplaced_dbgrc.section1 == []

    empty_alc_nc = BroadScopePartOutput(
        section1=[],
        in_scope=[],
        out_of_scope=[ParagraphCitation(paragraph_id="para_1", content=[], metadata=ParagraphMetadata(is_section_start=False))],
    )
    normalize_broad_scope_part_output("alc_nc", empty_alc_nc, chunks)
    assert empty_alc_nc.out_of_scope == []


