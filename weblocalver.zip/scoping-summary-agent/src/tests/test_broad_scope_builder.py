from model.response_model import (
    BroadScopeCollationOutput,
    BroadScopePartOutput,
    NarrativeUnit,
    ParagraphCitation,
    ParagraphMetadata,
    SupportingCitation,
)
from utils.broad_scope_builder import (
    NOT_GENERATED_TEXT,
    BroadScopePart,
    build_section1,
    build_section2,
    cited_chunk_ids,
    draft_for_collation,
    finalize_broad_scope_report,
    resolve_draft_refs,
    restrict_citations,
)


def _para(text, chunk_ids=(), page=None, section_start=False, rationale=None):
    return ParagraphCitation(
        paragraph_id="x",
        content=[
            NarrativeUnit(
                content=text,
                citation_status="supported" if chunk_ids else "unsupported",
                supporting_chunk_ids=list(chunk_ids),
                supporting_citations=[SupportingCitation(chunk_id=c, page_number=page) for c in chunk_ids],
            )
        ],
        rationale=rationale,
        metadata=ParagraphMetadata(
            is_section_start=section_start,
            section_confidence_score=70 if section_start else None,
        ),
    )


def _text(paragraph):
    return paragraph.content if isinstance(paragraph.content, str) else paragraph.content[0].content


LAYOUT = {
    "in_scope": ["dbgrc", "historical"],
    "out_of_scope": ["dbgrc", "findings_ga", "historical", "alc_nc"],
}


def _parts():
    historical = BroadScopePart(
        key="historical",
        label="Historical Plan Context",
        status="ok",
        output=BroadScopePartOutput(
            section1=[
                _para("**Section 1: Broad Scope Direction**\nPlan", ["1"], section_start=True, rationale="S1"),
                _para("Hypothesis", ["10"], page=3, section_start=True, rationale="wrong"),
            ],
            in_scope=[_para("Hist in", ["10"], page=4, section_start=True, rationale="drop")],
            out_of_scope=[_para("Hist out", ["10"], page=2)],
        ),
    )
    dbgrc = BroadScopePart(
        key="dbgrc",
        label="dbGRC Control Scope",
        status="skipped",
        unavailable_text="Data Not Available - dbGRC",
    )
    alc = BroadScopePart(key="alc_nc", label="Alternate Coverage", status="skipped")
    findings = BroadScopePart(key="findings_ga", label=None, status="failed")
    return [historical, dbgrc, alc, findings]


def test_sections_1_and_2_are_assembled_in_layout_order_with_placeholders():
    parts = _parts()
    section1 = build_section1(parts)
    section2 = build_section2(parts, LAYOUT)

    assert [p.metadata.is_section_start for p in section1] == [True, False]
    assert section1[0].rationale == "S1"
    assert section1[1].rationale is None

    assert [_text(p) for p in section2] == [
        section2[0].content,
        "**A. In-scope**",
        "**dbGRC Control Scope**",
        "Data Not Available - dbGRC",
        "**Historical Plan Context**",
        "Hist in",
        "**B. Out of scope**",
        NOT_GENERATED_TEXT,
        "**Historical Plan Context**",
        "Hist out",
    ]
    assert section2[0].metadata.is_section_start
    assert all(not p.metadata.is_section_start and p.rationale is None for p in section2[1:])


def test_finalize_appends_collation_and_renumbers():
    parts = _parts()
    section1 = build_section1(parts)
    section2 = build_section2(parts, LAYOUT)
    collation = BroadScopeCollationOutput(
        section2_rationale="S2",
        section2_confidence_score=55,
        section3=[
            _para("**Section 3: Scope Validation and Walkthrough Preparation**\nQ", section_start=True, rationale="S3"),
            _para("**Assumptions and Boundaries for Confirmation**", section_start=True, rationale="drop"),
        ],
    )

    report = finalize_broad_scope_report(section1, section2, collation, "Broad Scope Direction")

    starts = [p for p in report.paragraphs if p.metadata.is_section_start]
    assert [p.rationale for p in starts] == ["S1", "S2", "S3"]
    assert starts[1].metadata.section_confidence_score == 55
    texts = [_text(p) for p in report.paragraphs]
    assert texts[-1] == "**Assumptions and Boundaries for Confirmation**"
    assert [p.paragraph_id for p in report.paragraphs] == [f"para_{i}" for i in range(1, len(texts) + 1)]


def test_finalize_without_collation_adds_section3_placeholder():
    parts = _parts()
    report = finalize_broad_scope_report(
        build_section1(parts), build_section2(parts, LAYOUT), None, "Broad Scope Direction"
    )

    last = report.paragraphs[-1]
    assert last.metadata.is_section_start
    assert last.content.startswith("**Section 3: Scope Validation and Walkthrough Preparation**")


def test_restrict_citations_drops_foreign_chunk_ids():
    paragraph = _para("Claim", ["2", "99"], page=5)
    only_foreign = _para("Other", ["99"])

    restrict_citations([paragraph, only_foreign], {"1", "2"}, "dbgrc")

    unit = paragraph.content[0]
    assert unit.supporting_chunk_ids == ["2"]
    assert [c.chunk_id for c in unit.supporting_citations] == ["2"]
    assert unit.citation_status == "supported"
    foreign_unit = only_foreign.content[0]
    assert foreign_unit.supporting_chunk_ids == []
    assert foreign_unit.supporting_citations == []
    assert foreign_unit.citation_status == "unsupported"


def test_draft_for_collation_gives_refs_only_to_cited_units():
    paragraphs = [_para("Fact", ["10"], page=3), _para("Heading")]

    draft, refs = draft_for_collation(paragraphs)

    assert draft == [{"text": "Fact", "ref": "D1"}, {"text": "Heading"}]
    assert [(c.chunk_id, c.page_number) for c in refs["D1"]] == [("10", 3)]
    assert cited_chunk_ids(paragraphs) == {"10"}


def test_resolve_draft_refs_swaps_refs_for_original_citations():
    _draft, refs = draft_for_collation([_para("Hist fact", ["10"], page=4), _para("Plan fact", ["1"])])
    bullet = ParagraphCitation(
        paragraph_id="p",
        content=[
            NarrativeUnit(
                content="• Assumption.",
                citation_status="unsupported",
                supporting_chunk_ids=["D1", "POLICY|1|4.3", "D2"],
                supporting_citations=[SupportingCitation(chunk_id="POLICY|1|4.3", page_number=46)],
            )
        ],
        metadata=ParagraphMetadata(is_section_start=False),
    )

    resolve_draft_refs([bullet], refs)

    unit = bullet.content[0]
    assert [(c.chunk_id, c.page_number) for c in unit.supporting_citations] == [
        ("POLICY|1|4.3", 46),
        ("10", 4),
        ("1", None),
    ]
    assert unit.supporting_chunk_ids == ["POLICY|1|4.3", "10", "1"]
    assert unit.citation_status == "supported"
