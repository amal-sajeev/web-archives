"""HTTP client used by ``ci_gate.py`` to drive one evaluation run.

Flow against the evaluation service:

1. ``POST /api/evaluate/start``                     -> ``{"stream_id": ...}`` (any 2xx)
2. ``GET  /api/evaluate/stream/{id}/events?after=N`` -> poll until ``done`` is true
3. take ``run_id`` from the events response
4. ``GET  /api/runs/{run_id}``                       -> the persisted RunRecord
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

import httpx

HEALTH_PATH = "/api/health"
START_PATH = "/api/evaluate/start"
EVENTS_PATH = "/api/evaluate/stream/{stream_id}/events"
RUN_PATH = "/api/runs/{run_id}"

REQUEST_TIMEOUT_S = 30.0
HEALTH_TIMEOUT_S = 5.0
FAILURE_EVENTS = frozenset({"run_failed", "run_cancelled"})

Logger = Callable[[str], None]


class GateError(RuntimeError):
    """The run could not be started, finished, or fetched (infrastructure failure)."""


def _noop(_msg: str) -> None:
    return None


def _json(resp: httpx.Response) -> dict[str, Any]:
    resp.raise_for_status()
    try:
        body = resp.json()
    except ValueError as exc:
        raise GateError(f"response from {resp.request.url} is not JSON: {resp.text[:200]!r}") from exc
    if not isinstance(body, dict):
        raise GateError(f"unexpected response from {resp.request.url}: {body!r}")
    return body


def _failure_message(events: list[dict[str, Any]]) -> str:
    """Describe why a stream finished without a run_id."""
    for event in reversed(events):
        if event.get("type") in FAILURE_EVENTS:
            parts = [event.get("detail") or event.get("message") or ""]
            if event.get("error_type"):
                parts.append(f"error_type={event['error_type']}")
            if event.get("error_id"):
                parts.append(f"error_id={event['error_id']}")
            detail = " ".join(p for p in parts if p)
            return f"{event['type']}: {detail}" if detail else str(event["type"])
    return "stream finished without a run_id"


class EvalClient:
    """Thin synchronous client for the evaluation service API."""

    def __init__(
        self,
        base_url: str,
        *,
        poll_interval: float = 5.0,
        log: Logger = _noop,
        client: httpx.Client | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._poll_interval = max(0.0, poll_interval)  # time.sleep rejects negatives
        self._log = log
        self._client = client or httpx.Client(base_url=self._base_url, timeout=REQUEST_TIMEOUT_S)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> EvalClient:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def check_health(self) -> dict[str, Any]:
        try:
            return _json(self._client.get(HEALTH_PATH, timeout=HEALTH_TIMEOUT_S))
        except httpx.HTTPStatusError as exc:
            raise GateError(
                f"eval service at {self._base_url} answered the health check with HTTP "
                f"{exc.response.status_code}; is --eval-url pointing at the evaluation service?"
            ) from exc
        except httpx.HTTPError as exc:
            raise GateError(f"eval service unreachable at {self._base_url}: {exc}") from exc

    def start(self, agent_id: str, judge_reps: int) -> str:
        """Start a run in the background and return its stream id."""
        payload = {"agent_id": agent_id, "judge_repetitions": judge_reps, "created_by": "CI_CD"}
        try:
            body = _json(self._client.post(START_PATH, json=payload))
        except httpx.HTTPStatusError as exc:
            raise GateError(f"start failed: HTTP {exc.response.status_code} {exc.response.text[:300]}") from exc
        except httpx.HTTPError as exc:
            raise GateError(f"start failed: {exc}") from exc
        stream_id = body.get("stream_id")
        if not stream_id:
            raise GateError(f"start response has no stream_id: {body!r}")
        return str(stream_id)

    def _poll_once(self, stream_id: str, after: int) -> dict[str, Any] | None:
        """One events poll; transient transport errors return None so the caller retries."""
        url = EVENTS_PATH.format(stream_id=stream_id)
        try:
            return _json(self._client.get(url, params={"after": after}))
        except httpx.HTTPStatusError as exc:
            raise GateError(f"events poll failed: HTTP {exc.response.status_code}") from exc
        except httpx.TransportError as exc:
            self._log(f"poll error (retrying): {exc}")
            return None

    def wait_for_run_id(self, stream_id: str, timeout: float) -> str:
        """Poll the stream's events until it is done and return the run id."""
        deadline = time.monotonic() + timeout
        after = 0
        events: list[dict[str, Any]] = []
        while time.monotonic() < deadline:
            body = self._poll_once(stream_id, after)
            if body is not None:
                new_events = [e for e in body.get("events") or [] if isinstance(e, dict)]
                events.extend(new_events)
                seq = body.get("seq")
                after = seq if isinstance(seq, int) else after + len(new_events)
                for event in new_events:
                    self._log(f"event: {event.get('type')}")
                if body.get("done"):
                    run_id = body.get("run_id")
                    if not run_id:
                        raise GateError(_failure_message(events))
                    return str(run_id)
            time.sleep(self._poll_interval)
        raise GateError(f"evaluation timed out after {timeout:.0f}s (stream {stream_id})")

    def get_run(self, run_id: str) -> dict[str, Any]:
        try:
            return _json(self._client.get(RUN_PATH.format(run_id=run_id)))
        except httpx.HTTPError as exc:
            raise GateError(f"could not fetch run {run_id}: {exc}") from exc

    def run_to_completion(self, agent_id: str, judge_reps: int, timeout: float) -> dict[str, Any]:
        """Start a run, wait for it, and return the persisted RunRecord."""
        stream_id = self.start(agent_id, judge_reps)
        self._log(f"evaluation started: stream_id={stream_id}")
        started = time.monotonic()
        run_id = self.wait_for_run_id(stream_id, timeout)
        self._log(f"evaluation finished in {time.monotonic() - started:.0f}s: run_id={run_id}")
        return self.get_run(run_id)
