import re
import json
from pathlib import Path

root = Path(r'C:\Users\sanjama\Documents\llmjudge')
log_path = root / 'live-judge-iterations.log'
out_path = root / 'agent-judge-live-trace.json'

text = log_path.read_text(encoding='utf-8', errors='replace')
pattern = re.compile(r"=== LLM JUDGE DEBUG \[(.*?)\] ===\r?\n(.*?)(?:\r?\n=== END LLM JUDGE DEBUG ===)", re.S)
blocks = []
for tag, body in pattern.findall(text):
    stage = tag.strip()
    body = body.strip()
    if not body:
        continue
    blocks.append({
        'stage': stage,
        'content': body,
    })

out_path.write_text(json.dumps(blocks, indent=2, ensure_ascii=False), encoding='utf-8')
print(f'WROTE {len(blocks)} entries to {out_path}')
