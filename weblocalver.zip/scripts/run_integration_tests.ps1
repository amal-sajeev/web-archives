<#
.SYNOPSIS
    Integration test script for the dbaware Evaluation Service.
    Tests every API endpoint and feature offline (no Vertex, no CloudSQL).

.DESCRIPTION
    Starts all 4 sample agents + the eval service (src\main\main.py), then exercises:
      - Unit tests (pytest) and ruff lint
      - Health / agents list
      - Synchronous evaluate (all 4 agents: markdown, JSON, DOCX, PDF, text)
      - Document extraction (PDF/DOCX/Markdown) and scorer coverage
      - Run listing + keyset cursor pagination, run detail, run comparison
      - Baseline promotion
      - Async evaluate, polled through /api/evaluate/stream/{id}/events
      - A/B comparison
      - Run export (CSV + PDF)
      - Captures (capture mode) and human labels
      - Static dashboard

    Helpers live in scripts\integration\*.ps1 (dot-sourced). Patched agent.yaml
    files are always restored, even when a step throws.

    Prerequisites:
      - Python with the project deps installed (pip install -r requirements.txt)
      - pypdf + python-docx installed for document tests
      - No WIF/Auth Proxy needed (uses SQLite + capture mode)

.PARAMETER Port
    Port for the eval service (default 4002).

.PARAMETER AgentPortBase
    Base port for sample agents (default 4010). Agents use base, base+1, base+2, base+3.

.PARAMETER NoCleanup
    Don't kill the agents/eval service at the end (useful for debugging).

.EXAMPLE
    .\scripts\run_integration_tests.ps1
    .\scripts\run_integration_tests.ps1 -Port 4200 -AgentPortBase 4100
#>

param(
    [int]$Port = 4002,
    [int]$AgentPortBase = 4010,
    [switch]$NoCleanup
)

$ErrorActionPreference = "Stop"
$script:Root = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent $script:Root
$script:Py = Join-Path $script:Root ".venv\Scripts\python.exe"
if (-not (Test-Path $script:Py)) { $script:Py = Join-Path $repoRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $script:Py)) { $script:Py = "python" }

$script:Port = $Port
$script:AgentPortBase = $AgentPortBase
$script:NoCleanup = [bool]$NoCleanup
$script:BaseUrl = "http://127.0.0.1:$Port"
$script:RunIds = @{}

$integrationDir = Join-Path $PSScriptRoot "integration"
. (Join-Path $integrationDir "helpers.ps1")
. (Join-Path $integrationDir "setup.ps1")
. (Join-Path $integrationDir "checks_eval.ps1")
. (Join-Path $integrationDir "checks_api.ps1")

# Offline configuration shared by pytest and the eval service.
$testDb = Join-Path $script:Root "eval_test.db"
$env:EVAL_DB_URL = "sqlite:///$($testDb -replace '\\', '/')"
$env:METRICS_SOURCE = "capture"
$env:PROJECT_NAME = ""
$env:EVAL_SERVICE_PORT = $Port
Remove-Item -Path "$testDb*" -ErrorAction SilentlyContinue

try {
    Invoke-UnitTests
    Invoke-RuffCheck
    Start-SampleAgents
    Remove-Item -Path "$testDb*" -ErrorAction SilentlyContinue
    $health = Start-EvalService
    if ($health) {
        Test-HealthAndAgents $health
        Invoke-SyncEvaluations
        Test-DocumentExtraction
        Test-RunListing
        Test-RunDetail
        Test-RunComparison
        Test-BaselinePromotion
        Test-AsyncEvaluate
        Test-ABComparison
        Test-RunExport
        Test-Captures
        Test-Labels
        Test-Dashboard
    }
} catch {
    Test-Result "integration run aborted" $false $_.Exception.Message
} finally {
    Stop-ManagedProcesses
    Restore-AgentYamls
    if (-not $script:NoCleanup) { Remove-Item -Path "$testDb*" -ErrorAction SilentlyContinue }
}

Write-Summary
if ($script:Fail -eq 0) { exit 0 } else { exit 1 }
