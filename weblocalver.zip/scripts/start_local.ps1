# Starts the evaluation service locally on http://127.0.0.1:4002 using a SQLite database.
#
#   .\scripts\start_local.ps1                 # service only, eval_service.db in the service folder
#   .\scripts\start_local.ps1 -Open           # also open the dashboard in the browser
#   .\scripts\start_local.ps1 -Port 4100 -Db C:\temp\scratch.db
#
# To start the sample agents as well, use scripts\start_local_all.ps1.
# First time on a machine: run scripts\setup_local.ps1.
param(
    [int]$Port = 4002,
    [string]$Db = "",
    [switch]$Open
)
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "local\common.ps1")

Set-LocalDatabase $Db
Start-EvalService -Port $Port -Open:$Open
