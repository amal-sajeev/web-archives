# Starts the CTNA Evaluation Service on EVAL_SERVICE_PORT (default 4002).
# Run from the module root (dbaware-evaluation-service). The .venv may live in
# this module or one level up at the scope-eval repo root.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent $root
$py = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = Join-Path $repoRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $py)) { $py = "python" }

# Local WIF convenience defaults (can be overridden by caller/.env values).
$defaultWifCreds = "C:\Users\sanjama\Downloads\wif_new\dbgarda\config\wif-file-based.json"
$defaultWifCa = "C:\Users\sanjama\Downloads\wif_new\dbgarda\config\cacert.crt"

if (-not $env:GOOGLE_APPLICATION_CREDENTIALS -and (Test-Path $defaultWifCreds)) {
	$env:GOOGLE_APPLICATION_CREDENTIALS = $defaultWifCreds
}
if (-not $env:SSL_CERT_FILE -and (Test-Path $defaultWifCa)) {
	$env:SSL_CERT_FILE = $defaultWifCa
}
if (-not $env:REQUESTS_CA_BUNDLE -and (Test-Path $defaultWifCa)) {
	$env:REQUESTS_CA_BUNDLE = $defaultWifCa
}

if (-not $env:HTTPS_PROXY) { $env:HTTPS_PROXY = "http://sdod3-proxy.intranet.db.com:8080" }
if (-not $env:HTTP_PROXY) { $env:HTTP_PROXY = $env:HTTPS_PROXY }
if (-not $env:NO_PROXY) { $env:NO_PROXY = "*.db.com,localhost,127.0.0.1,10.*" }
if (-not $env:no_proxy) { $env:no_proxy = $env:NO_PROXY }

# Default the offline target + metrics source so a fresh shell targets the local
# sample agent (scripts/run_sample_agent.ps1 on :4010) instead of the unrunning
# real agent-service on :4000. Override either to point at a hosted deployment.
if (-not $env:AGENT_SERVICE_BASE_URL) { $env:AGENT_SERVICE_BASE_URL = "http://127.0.0.1:4010" }
if (-not $env:METRICS_SOURCE) { $env:METRICS_SOURCE = "capture" }

# Default local persistence to SQLite so the service starts for developers
# without CloudSQL access (file: <module root>\eval_service.db). An explicit
# EVAL_DB_URL from the caller still wins, e.g. $env:EVAL_DB_URL = "postgresql://"
# for CloudSQL.
if (-not $env:EVAL_DB_URL) {
	$sqlitePath = (Join-Path $root "eval_service.db") -replace '\\', '/'
	$env:EVAL_DB_URL = "sqlite:///$sqlitePath"
}

$listenPort = 4002
if ($env:EVAL_SERVICE_PORT) { $listenPort = [int]$env:EVAL_SERVICE_PORT }
$existing = Get-NetTCPConnection -LocalPort $listenPort -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($existing) {
	Write-Host "Evaluation service already appears to be running on port $listenPort."
	Write-Host "Health: http://127.0.0.1:$listenPort/api/health"
	exit 0
}

$env:PYTHONPATH = Join-Path $root "src\main"
& $py (Join-Path $root "src\main\main.py")
