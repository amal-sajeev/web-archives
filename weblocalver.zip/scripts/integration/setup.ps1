# Setup steps for run_integration_tests.ps1: unit tests, lint, and starting the
# sample agents + eval service. Dot-sourced after helpers.ps1.

function Invoke-UnitTests {
    Test-Name "Unit Tests (pytest)"
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    Push-Location $script:Root
    try {
        $out = & $script:Py -m pytest -p no:cacheprovider -q --tb=short 2>&1
        $summary = ($out | Select-String "\d+ (passed|failed)" | Select-Object -Last 1)
        $detail = if ($summary) { $summary.Line } else { ($out | Select-Object -Last 5 | Out-String) }
        Test-Result "pytest suite" ($LASTEXITCODE -eq 0) $detail
    } finally {
        Pop-Location
        $ErrorActionPreference = $prevEAP
    }
}

function Invoke-RuffCheck {
    Test-Name "Ruff Lint Check"
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $out = & $script:Py -m ruff check --no-cache "$($script:Root)\src" "$($script:Root)\scripts" 2>&1
        $detail = if ($LASTEXITCODE -eq 0) { "0 errors" } else { ($out | Select-Object -Last 3 | Out-String) }
        Test-Result "ruff check" ($LASTEXITCODE -eq 0) $detail
    } finally {
        $ErrorActionPreference = $prevEAP
    }
}

function Start-SampleAgents {
    Test-Name "Start Sample Agents"
    $base = $script:AgentPortBase
    $agentDefs = @(
        @{ Name = "data_extraction"; Module = "sample_agents.data_extraction_agent:app"; Port = $base }
        @{ Name = "report_writer";   Module = "sample_agents.report_writer_agent:app";   Port = $base + 1 }
        @{ Name = "invoice_parser";  Module = "sample_agents.invoice_parser_agent:app";  Port = $base + 2 }
        @{ Name = "document_qa";     Module = "sample_agents.document_qa_agent:app";     Port = $base + 3 }
    )
    # Point the agent configs at the chosen ports; restored in the main script's finally.
    Set-AgentYamlPorts (Join-Path $script:Root "src\agents") @{
        "scope_extraction" = $base
        "report_writer"    = $base + 1
        "invoice_parser"   = $base + 2
        "document_qa"      = $base + 3
        "scoping_summary"  = $base
    }
    $env:PYTHONPATH = Join-Path $script:Root "src"
    foreach ($agent in $agentDefs) {
        $null = Start-ManagedProcess $agent.Name @("-m", "uvicorn", $agent.Module, "--port", $agent.Port, "--host", "127.0.0.1")
    }
    $allUp = $true
    foreach ($agent in $agentDefs) {
        $r = Wait-HttpOk "http://127.0.0.1:$($agent.Port)/api/health" 30
        if ($r) {
            Write-Host "  $($agent.Name) on :$($agent.Port) -> $($r.status)"
        } else {
            $allUp = $false
            Write-Host "  $($agent.Name) on :$($agent.Port) -> FAILED" -ForegroundColor Red
        }
    }
    Test-Result "All sample agents started" $allUp
}

function Start-EvalService {
    # Returns the health payload, or $null when the service did not come up.
    Test-Name "Start Eval Service"
    $env:PYTHONPATH = Join-Path $script:Root "src\main"
    $env:AGENT_SERVICE_BASE_URL = "http://127.0.0.1:$($script:AgentPortBase)"
    $null = Start-ManagedProcess "eval_svc" @((Join-Path $script:Root "src\main\main.py"))
    $live = Wait-HttpOk "$($script:BaseUrl)/livez" 60
    $health = if ($live) { Invoke-Json "/api/health" } else { $null }
    if ($health) {
        Test-Result "Eval service started" $true "status=$($health.status) agents=$($health.agents)"
    } else {
        Test-Result "Eval service started" $false "no response from $($script:BaseUrl)/livez (see $env:TEMP\eval_svc_err.log)"
    }
    return $health
}

function Test-HealthAndAgents($health) {
    Test-Name "GET /api/health"
    Test-Result "health endpoint" ($health.status -in @("ok", "degraded")) "status=$($health.status) vertex=$($health.vertex)"

    Test-Name "GET /readyz"
    try {
        $ready = Invoke-Json "/readyz"
        Test-Result "readiness probe" ($ready.status -eq "ok") "status=$($ready.status) storage=$($ready.storage)"
    } catch {
        Test-Result "readiness probe" $false $_.Exception.Message
    }

    Test-Name "GET /api/agents + /api/agents/{id}/target"
    $agentsResp = Invoke-Json "/api/agents"
    $listed = @($agentsResp.agents | ForEach-Object { $_.agent_id })
    Test-Result "enabled agents listed" ($listed.Count -gt 0) "listed: $($listed -join ', ')"
    # The sample-agent configs ship with enabled: false (hidden from the UI list),
    # so check registration through the target endpoint instead.
    $expected = @("scope_extraction", "report_writer", "invoice_parser", "document_qa")
    $registered = @($expected | Where-Object { (Invoke-WithStatus "/api/agents/$_/target").Status -eq 200 })
    Test-Result "sample agents registered" ($registered.Count -eq $expected.Count) "registered: $($registered -join ', ')"
}
