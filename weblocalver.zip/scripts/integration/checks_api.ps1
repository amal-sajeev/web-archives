# Run/API checks for run_integration_tests.ps1. Dot-sourced after helpers.ps1;
# reads $script:RunIds filled by Invoke-SyncEvaluations.

function Test-RunListing {
    Test-Name "GET /api/runs + Pagination"
    $page1 = Invoke-Json "/api/runs?limit=3"
    $ids1 = @($page1.runs | ForEach-Object { $_.run_id })
    Test-Result "list runs" ($ids1.Count -gt 0) "$($ids1.Count) runs returned"
    $hasCursor = $null -ne $page1.next_cursor
    Test-Result "pagination cursor present" $hasCursor "next_cursor=$($page1.next_cursor)"
    if (-not $hasCursor) { return }
    # next_cursor is opaque (URL-safe base64): pass it back unchanged as `before`.
    $page2 = Invoke-Json "/api/runs?limit=3$($script:Amp)before=$([uri]::EscapeDataString($page1.next_cursor))"
    $ids2 = @($page2.runs | ForEach-Object { $_.run_id })
    $overlap = @($ids2 | Where-Object { $_ -in $ids1 })
    Test-Result "pagination page 2" ($ids2.Count -gt 0 -and $overlap.Count -eq 0) "$($ids2.Count) runs on page 2, $($overlap.Count) repeated"
}

function Test-RunDetail {
    Test-Name "GET /api/runs/{id}"
    $runId = $script:RunIds["report_writer"]
    if (-not $runId) { Test-Result "run detail" $false "no report_writer run"; return }
    $run = Invoke-Json "/api/runs/$runId"
    Test-Result "run detail" ($run.run_id -eq $runId) "agent=$($run.agent_id) cases=$($run.case_results.Count)"
    Test-Result "run has stats" ($null -ne $run.stats) "n_cases=$($run.stats.n_cases) pass_rate=$($run.stats.pass_rate)"
    Test-Result "run has creation_ts" ([bool]$run.creation_ts) "creation_ts=$($run.creation_ts)"
}

function Test-RunComparison {
    Test-Name "GET /api/runs/compare"
    $a = $script:RunIds["report_writer"]
    $b = $script:RunIds["invoice_parser"]
    if (-not ($a -and $b)) { Test-Result "run comparison" $false "need report_writer and invoice_parser runs"; return }
    try {
        $compare = Invoke-Json "/api/runs/compare?a=$a$($script:Amp)b=$b"
        $shapeOk = $compare.a.run_id -eq $a -and $compare.b.run_id -eq $b -and $compare.winner -in @("a", "b", "tie")
        Test-Result "run comparison" $shapeOk "winner=$($compare.winner) diff=$($compare.score_diff)"
        Test-Result "comparison has cases" ($compare.cases.Count -gt 0) "$($compare.cases.Count) cases compared"
    } catch {
        Test-Result "run comparison" $false $_.Exception.Message
    }
}

function Test-BaselinePromotion {
    Test-Name "POST /api/baselines/promote/{run_id}"
    $runId = $script:RunIds["report_writer"]
    if (-not $runId) { Test-Result "baseline promotion" $false "no report_writer run"; return }
    try {
        $promote = Invoke-Json "/api/baselines/promote/$runId" "Post"
        Test-Result "baseline promotion" ($promote.promoted.Count -gt 0) "$($promote.promoted.Count) metrics promoted"
        $promote.promoted | ForEach-Object { Write-Host "    $($_.metric) = $($_.baseline)" -ForegroundColor DarkGray }
    } catch {
        Test-Result "baseline promotion" $false $_.Exception.Message
    }
}

function Test-AsyncEvaluate {
    Test-Name "POST /api/evaluate/async + polling /events"
    try {
        $resp = Invoke-WithStatus "/api/evaluate/async" "Post" @{ agent_id = "report_writer"; judge_repetitions = 1 }
        $started = $resp.Body
        Test-Result "async evaluate accepted (202)" ($resp.Status -eq 202 -and $started.stream_id) "status=$($resp.Status) stream_id=$($started.stream_id)"
        $final = Wait-StreamDone $started.stream_id 180
        Test-Result "async run finished with run_id" ([bool]$final.run_id) "run_id=$($final.run_id) events=$($final.seq)"
        $cancel = Invoke-WithStatus "/api/evaluate/cancel/$($started.stream_id)" "Post"
        Test-Result "cancel after finish returns 409" ($cancel.Status -eq 409) "status=$($cancel.Status)"
        if ($final.run_id) {
            $run = Invoke-Json "/api/runs/$($final.run_id)"
            Test-Result "async run persisted" ($run.status -in @("PASS", "FAIL")) "status=$($run.status)"
        }
    } catch {
        Test-Result "async evaluate" $false $_.Exception.Message
    }
}

function Test-ABComparison {
    Test-Name "POST /api/evaluate/ab"
    try {
        $body = @{ agent_a = "report_writer"; agent_b = "invoice_parser"; judge_repetitions = 1 }
        $ab = Invoke-Json "/api/evaluate/ab" "Post" $body 120
        $shapeOk = $ab.a.agent_id -eq "report_writer" -and $ab.b.agent_id -eq "invoice_parser" -and $ab.winner -in @("a", "b", "tie")
        Test-Result "A/B comparison" ($shapeOk -and $null -ne $ab.cases) "winner=$($ab.winner) diff=$($ab.score_diff)"
    } catch {
        Test-Result "A/B comparison" $false $_.Exception.Message
    }
}

function Test-RunExport {
    Test-Name "GET /api/runs/{id}/export"
    $runId = $script:RunIds["report_writer"]
    if (-not $runId) { Test-Result "export" $false "no report_writer run"; return }
    foreach ($format in @("csv", "pdf")) {
        try {
            $resp = Invoke-WebRequest "$($script:BaseUrl)/api/runs/$runId/export?format=$format" -TimeoutSec 10 -UseBasicParsing
            $ok = $resp.StatusCode -eq 200 -and $resp.RawContentLength -gt 0
            Test-Result "export $format" $ok "status=$($resp.StatusCode) bytes=$($resp.RawContentLength)"
        } catch {
            Test-Result "export $format" $false $_.Exception.Message
        }
    }
}

function Test-Captures {
    Test-Name "GET /api/captures"
    try {
        $captures = Invoke-Json "/api/captures"
        $count = @($captures.captures).Count
        Test-Result "captures endpoint" ($count -gt 0) "count=$count (capture mode records each case)"
    } catch {
        Test-Result "captures endpoint" $false $_.Exception.Message
    }
}

function Test-Labels {
    Test-Name "POST /api/labels + GET /api/labels"
    try {
        $body = @{ case_id = "q1_financial_summary"; verdict = "pass"; score = 0.9; labeler = "integration_test" }
        $resp = Invoke-WithStatus "/api/labels" "Post" $body
        $label = $resp.Body
        $ok = $resp.Status -eq 201 -and $label.case_id -eq "q1_financial_summary"
        Test-Result "post label (201)" $ok "status=$($resp.Status) verdict=$($label.verdict) labeler=$($label.labeler)"
        $labels = Invoke-Json "/api/labels"
        $mine = @($labels.labels | Where-Object { $_.labeler -eq "integration_test" })
        Test-Result "get labels" ($mine.Count -gt 0) "$(@($labels.labels).Count) labels, $($mine.Count) from this run"
    } catch {
        Test-Result "labels" $false $_.Exception.Message
    }
}

function Test-Dashboard {
    Test-Name "GET / (dashboard)"
    try {
        $resp = Invoke-WebRequest "$($script:BaseUrl)/" -TimeoutSec 5 -UseBasicParsing
        Test-Result "dashboard serves" ($resp.StatusCode -eq 200) "status=$($resp.StatusCode) bytes=$($resp.RawContentLength)"
    } catch {
        Test-Result "dashboard serves" $false $_.Exception.Message
    }
}
