# Evaluation checks for run_integration_tests.ps1: synchronous runs for every
# sample agent and verification of document/JSON/Markdown handling.
# Dot-sourced after helpers.ps1; fills $script:RunIds.

function Invoke-SyncEvaluations {
    foreach ($agentId in @("scope_extraction", "report_writer", "invoice_parser", "document_qa")) {
        Test-Name "POST /api/evaluate - $agentId"
        try {
            $run = Invoke-Json "/api/evaluate" "Post" @{ agent_id = $agentId; judge_repetitions = 1 } 120
            $script:RunIds[$agentId] = $run.run_id
            $score = [math]::Round($run.weighted_score, 3)
            $okStatus = $run.status -in @("PASS", "FAIL")
            Test-Result "evaluate $agentId" $okStatus "run=$($run.run_id) status=$($run.status) score=$score cases=$($run.case_results.Count)"
            $scored = @($run.case_results | Where-Object { $_.scores.Count -gt 0 })
            Test-Result "$agentId has scored metrics" ($scored.Count -gt 0) "$($scored.Count)/$($run.case_results.Count) cases have scores"
        } catch {
            Test-Result "evaluate $agentId" $false $_.Exception.Message
        }
    }
}

function Find-Score($case, $metric) {
    return $case.scores | Where-Object { $_.metric -eq $metric } | Select-Object -First 1
}

function Test-MetricScored($label, $case, $metric) {
    $s = Find-Score $case $metric
    Test-Result $label ($null -ne $s) "score=$($s.score) passed=$($s.passed)"
}

function Test-ReportWriterOutput {
    $run = Invoke-Json "/api/runs/$($script:RunIds['report_writer'])"
    $firstCase = $run.case_results[0]
    $output = [string]$firstCase.observation.output
    $preview = $output.Substring(0, [math]::Min(80, $output.Length))
    Test-Result "report_writer markdown output" ($output -match "^#") "output starts with: $preview"
    Test-MetricScored "report_writer section_present scorer" $firstCase "report_sections_present"
    Test-MetricScored "report_writer contains scorer" $firstCase "key_figures_present"
}

function Test-InvoiceParserOutput {
    $run = Invoke-Json "/api/runs/$($script:RunIds['invoice_parser'])"
    $firstCase = $run.case_results[0]
    $output = $firstCase.observation.output
    Test-Result "invoice_parser JSON output" ($null -ne $output.vendor) "vendor=$($output.vendor) total=$($output.total)"
    Test-MetricScored "invoice_parser json_path scorer" $firstCase "total_correct"
    Test-MetricScored "invoice_parser field_match scorer" $firstCase "vendor_extracted"
    Test-MetricScored "invoice_parser json_schema_valid scorer" $firstCase "invoice_schema_valid"
}

function Test-DocumentQaOutput {
    $run = Invoke-Json "/api/runs/$($script:RunIds['document_qa'])"
    foreach ($case in $run.case_results) {
        $ctype = $case.observation.metadata.content_type
        if (-not $ctype) { $ctype = "(none)" }
        $hasText = [bool]$case.observation.metadata.extracted_text
        Test-Result "document_qa [$($case.case_id)] content_type=$ctype" ($ctype -in @("docx", "pdf")) "type=$ctype extracted=$hasText"
        Test-MetricScored "document_qa [$($case.case_id)] section_present" $case "doc_sections_present"
        if ($ctype -eq "docx") {
            Test-MetricScored "document_qa [$($case.case_id)] docx_table_has" $case "docx_table_present"
        }
    }
}

function Test-DocumentExtraction {
    Test-Name "Document Extraction Verification"
    $checks = @(
        @{ Agent = "report_writer"; Check = { Test-ReportWriterOutput } }
        @{ Agent = "invoice_parser"; Check = { Test-InvoiceParserOutput } }
        @{ Agent = "document_qa"; Check = { Test-DocumentQaOutput } }
    )
    foreach ($item in $checks) {
        if (-not $script:RunIds[$item.Agent]) {
            Test-Result "$($item.Agent) output checks" $false "no run to inspect (evaluate failed)"
            continue
        }
        try {
            & $item.Check
        } catch {
            Test-Result "$($item.Agent) output checks" $false $_.Exception.Message
        }
    }
}
