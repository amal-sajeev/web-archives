# Shared helpers for run_integration_tests.ps1 (dot-sourced; runs in the caller's
# script scope, so $script: variables below belong to the main script).

$script:Amp = [char]38  # ampersand - PS 5.1 does not allow a literal one in strings
$script:Pids = @()
$script:Pass = 0
$script:Fail = 0
$script:Tests = @()
$script:PatchedYamls = @{}
$script:Utf8NoBom = [System.Text.UTF8Encoding]::new($false)

function Test-Name($name) {
    Write-Host ""
    Write-Host "=== $name ===" -ForegroundColor Cyan
}

function Test-Result($name, $passed, $detail = "") {
    $ok = [bool]$passed
    $script:Tests += [PSCustomObject]@{ Test = $name; Passed = $ok; Detail = $detail }
    if ($ok) {
        $script:Pass++
        Write-Host "  PASS: $name" -ForegroundColor Green
        if ($detail) { Write-Host "        $detail" -ForegroundColor DarkGray }
    } else {
        $script:Fail++
        Write-Host "  FAIL: $name" -ForegroundColor Red
        if ($detail) { Write-Host "        $detail" -ForegroundColor Yellow }
    }
}

function Invoke-Json($path, $method = "Get", $body = $null, $timeoutSec = 10) {
    $params = @{ Uri = "$($script:BaseUrl)$path"; Method = $method; TimeoutSec = $timeoutSec }
    if ($null -ne $body) {
        $params.Body = ($body | ConvertTo-Json -Depth 10)
        $params.ContentType = "application/json"
    }
    return Invoke-RestMethod @params
}

function Invoke-WithStatus($path, $method = "Get", $body = $null, $timeoutSec = 10) {
    # Returns @{ Status = <int>; Body = <parsed JSON or $null> } without throwing on 4xx/5xx.
    $params = @{ Uri = "$($script:BaseUrl)$path"; Method = $method; TimeoutSec = $timeoutSec; UseBasicParsing = $true }
    if ($null -ne $body) {
        $params.Body = ($body | ConvertTo-Json -Depth 10)
        $params.ContentType = "application/json"
    }
    try {
        $resp = Invoke-WebRequest @params
        $parsed = if ($resp.Content) { $resp.Content | ConvertFrom-Json } else { $null }
        return @{ Status = [int]$resp.StatusCode; Body = $parsed }
    } catch {
        $response = $_.Exception.Response
        if ($null -eq $response) { throw }
        return @{ Status = [int]$response.StatusCode; Body = $null }
    }
}

function Wait-HttpOk($url, $timeoutSec = 30) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)
    while ((Get-Date) -lt $deadline) {
        try {
            return Invoke-RestMethod $url -TimeoutSec 5
        } catch {
            Start-Sleep -Milliseconds 500
        }
    }
    return $null
}

function Wait-StreamDone($streamId, $timeoutSec = 180) {
    # Polls /api/evaluate/stream/{id}/events until done; returns the final poll body.
    $after = 0
    $deadline = (Get-Date).AddSeconds($timeoutSec)
    while ((Get-Date) -lt $deadline) {
        $poll = Invoke-Json "/api/evaluate/stream/$streamId/events?after=$after"
        $after = [int]$poll.seq
        if ($poll.done) { return $poll }
        Start-Sleep -Seconds 1
    }
    throw "stream $streamId did not finish within $timeoutSec s"
}

function Set-AgentYamlPorts($agentsDir, $portMap) {
    # Rewrites localhost base_url ports; originals are kept for Restore-AgentYamls.
    foreach ($agentName in $portMap.Keys) {
        $ymlPath = Join-Path $agentsDir "$agentName\agent.yaml"
        if (-not (Test-Path $ymlPath)) { continue }
        $original = [System.IO.File]::ReadAllText($ymlPath)
        $agentPort = $portMap[$agentName]
        $patched = $original -replace "base_url:\s*http://(127\.0\.0\.1|localhost):\d+", "base_url: http://127.0.0.1:$agentPort"
        if ($patched -ne $original) {
            $script:PatchedYamls[$ymlPath] = $original
            [System.IO.File]::WriteAllText($ymlPath, $patched, $script:Utf8NoBom)
            Write-Host "  Patched $agentName agent.yaml -> port $agentPort" -ForegroundColor DarkGray
        }
    }
}

function Restore-AgentYamls {
    foreach ($f in $script:PatchedYamls.Keys) {
        [System.IO.File]::WriteAllText($f, $script:PatchedYamls[$f], $script:Utf8NoBom)
    }
    if ($script:PatchedYamls.Count -gt 0) { Write-Host "Patched YAML files restored." -ForegroundColor DarkGray }
    $script:PatchedYamls = @{}
}

function Start-ManagedProcess($name, $arguments) {
    $p = Start-Process -FilePath $script:Py -ArgumentList $arguments -NoNewWindow -PassThru `
        -RedirectStandardOutput "$env:TEMP\$($name)_out.log" `
        -RedirectStandardError "$env:TEMP\$($name)_err.log"
    $script:Pids += $p.Id
    return $p
}

function Stop-ManagedProcesses {
    if ($script:NoCleanup) {
        Write-Host "`nProcesses left running (NoCleanup): $($script:Pids -join ', ')" -ForegroundColor Yellow
        return
    }
    Write-Host "`nCleaning up processes..." -ForegroundColor DarkGray
    foreach ($procId in $script:Pids) {
        Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
    }
    $script:Pids = @()
}

function Write-Summary {
    $color = if ($script:Fail -eq 0) { "Green" } else { "Red" }
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Cyan
    Write-Host "  INTEGRATION TEST RESULTS" -ForegroundColor Cyan
    Write-Host "=========================================" -ForegroundColor Cyan
    Write-Host "  Passed: $script:Pass" -ForegroundColor Green
    Write-Host "  Failed: $script:Fail" -ForegroundColor $color
    Write-Host "  Total:  $($script:Pass + $script:Fail)" -ForegroundColor Cyan
    Write-Host "=========================================" -ForegroundColor Cyan
    if ($script:Fail -gt 0) {
        Write-Host "`nFailed tests:" -ForegroundColor Red
        $script:Tests | Where-Object { -not $_.Passed } | ForEach-Object {
            Write-Host "  FAIL: $($_.Test)" -ForegroundColor Red
            if ($_.Detail) { Write-Host "        $($_.Detail)" -ForegroundColor Yellow }
        }
        Write-Host "`n$($script:Fail) test(s) failed." -ForegroundColor Red
    } else {
        Write-Host "`nAll integration tests passed!" -ForegroundColor Green
    }
}
