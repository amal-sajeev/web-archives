"""Repository connection smoke test (SQLite or CloudSQL).

It:
  1. for a postgres ``EVAL_DB_URL``, checks ADC is resolvable (google.auth.default)
     and reports the credential class (Credentials = gcloud user,
     IdentityPoolCredentials/ExternalAccountCredentials = WIF),
  2. builds the repository with ``build_repository()`` (which runs
     ``init_schema()`` exactly once),
  3. writes a throwaway RunRecord with ``save_run`` and reads it back with
     ``get_run``.

The throwaway run uses agent_id ``db_smoke`` so it is easy to find and delete.

Secrets are read from the environment only; nothing is committed. For CloudSQL:
  EVAL_DB_URL=postgresql://
  DB_INSTANCE_CONNECTION_NAME, DB_NAME, DB_USER, DB_PASSWORD
  (optional) DB_OWNER_USER, DB_OWNER_PASSWORD, DB_SCHEMA
Run ``gcloud auth application-default login`` first.

For a local check:
  $env:EVAL_DB_URL="sqlite:///eval_service_smoke.db"; python scripts/db_smoke.py

Exit codes: 0 success, 2 ADC missing, 3 repository build failed, 5 read-back
mismatch, 6 write/read raised.
"""

from __future__ import annotations

import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

# Make src/main importable when run from the repo root.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src" / "main"))

if TYPE_CHECKING:
    from core.models import RunRecord
    from repository import EvaluationRepository

SMOKE_AGENT_ID = "db_smoke"
EXIT_OK = 0
EXIT_NO_ADC = 2
EXIT_BUILD_FAILED = 3
EXIT_MISMATCH = 5
EXIT_IO_FAILED = 6


def check_adc() -> bool:
    """Only needed for the CloudSQL backend.

    Reads the same resolved ``Config.DB_URL`` that ``build_repository()`` uses, so a
    postgres URL set in the YAML config (not only via EVAL_DB_URL) is checked too.
    """
    from core.config import Config

    if not Config.DB_URL.startswith("postgres"):
        print("[skip] ADC check (not a postgres EVAL_DB_URL)")
        return True
    try:
        import google.auth

        creds, project = google.auth.default()
    except Exception as exc:  # any auth/transport failure means "ADC not usable"
        print(f"[FAIL] ADC not available: {exc}")
        print("       Run: gcloud auth application-default login (with proxy env set)")
        return False
    print(f"[ok] ADC resolved: {type(creds).__name__} (project={project})")
    return True


def build_smoke_run() -> RunRecord:
    from core.models import RunRecord

    now = datetime.now(UTC)
    return RunRecord(
        run_id=f"smoke_{now.strftime('%Y%m%d%H%M%S%f')}",
        agent_id=SMOKE_AGENT_ID,
        dataset_id=SMOKE_AGENT_ID,
        dataset_version="smoke",
        weighted_score=1.0,
        weighted_delta=0.0,
        status="PASS",
        creation_ts=now.isoformat(),
        created_by="DEVELOPER",
    )


def round_trip(repo: EvaluationRepository) -> int:
    run = build_smoke_run()
    try:
        repo.save_run(run)
        loaded = repo.get_run(run.run_id)
    except Exception as exc:  # report any driver/DB error with its type
        print(f"[FAIL] write/read failed: {exc!r}")
        return EXIT_IO_FAILED
    if loaded is None or loaded.run_id != run.run_id or loaded.status != run.status:
        print(f"[FAIL] wrote run {run.run_id} but could not read it back")
        return EXIT_MISMATCH
    print(f"[ok] round-trip write/read verified (run_id={run.run_id})")
    return EXIT_OK


def fell_back_to_sqlite(repo: EvaluationRepository) -> bool:
    """True when a postgres URL was configured but build_repository() fell back to SQLite
    (EVAL_ALLOW_SQLITE_FALLBACK=1). A CloudSQL smoke test must not report that as success."""
    from core.config import Config
    from repository import SqliteRepository

    return Config.DB_URL.startswith("postgres") and isinstance(repo, SqliteRepository)


def main() -> int:
    print("== Repository smoke test ==")
    if not check_adc():
        return EXIT_NO_ADC
    try:
        from repository import build_repository

        repo = build_repository()  # runs init_schema() once
    except Exception as exc:  # connector/driver/schema errors vary by backend
        print(f"[FAIL] could not build repository: {exc!r}")
        return EXIT_BUILD_FAILED
    if fell_back_to_sqlite(repo):
        print("[FAIL] CloudSQL was configured but could not be reached; the repository fell back to SQLite")
        repo.close()
        return EXIT_BUILD_FAILED
    print(f"[ok] repository built and schema initialised: {type(repo).__name__}")
    try:
        code = round_trip(repo)
    finally:
        repo.close()
    if code == EXIT_OK:
        print("\nSUCCESS - the evaluation service repository is live.")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
