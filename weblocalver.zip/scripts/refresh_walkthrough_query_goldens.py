#!/usr/bin/env python3
"""Replay walkthrough query cases against the live agent and capture outputs.

The walkthrough agent requires a document upload before chat. This script:

1. Loads the agent dataset from ``src/agents/walkthrough_query_agent/dataset.json``.
2. Uploads ``source_document.json`` to ``POST /qna/upload``.
3. Sends each case to ``POST /qna/chat`` with ``contextGcsUri`` and inline
   ``researchSections``.
4. Writes the captured answers to JSON so they can be reviewed and promoted
   into the dataset goldens.

TLS verification is disabled by default because the provided endpoint has a
broken certificate chain.
"""

from __future__ import annotations

import argparse
import copy
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import httpx


ROOT = Path(__file__).resolve().parents[1]
AGENT_DIR = ROOT / "src" / "agents" / "walkthrough_query_agent"
DATASET_PATH = AGENT_DIR / "dataset.json"
SOURCE_DOCUMENT_PATH = AGENT_DIR / "source_document.json"
UPLOAD_BLOB_PATH = "eval/walkthrough_query_agent/source_document.json"
EXIT_OK = 0
EXIT_FAILED = 1
EXIT_NO_CASES = 2


@dataclass(slots=True)
class ReplayResult:
    case_id: str
    question: str
    answer: str
    request: dict[str, Any]
    response: dict[str, Any]


class ReplayError(RuntimeError):
    """An input file or an agent response could not be used."""


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ReplayError(f"cannot read {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ReplayError(f"{path} must contain a JSON object, got {type(data).__name__}")
    return data


def _json_body(resp: httpx.Response) -> dict[str, Any]:
    """Raise on HTTP errors; return the JSON object body ({} for an empty body)."""
    resp.raise_for_status()
    if not resp.content:
        return {}
    try:
        payload = resp.json()
    except ValueError as exc:
        raise ReplayError(f"{resp.request.url} returned non-JSON: {resp.text[:200]!r}") from exc
    if not isinstance(payload, dict):
        raise ReplayError(f"{resp.request.url} returned {type(payload).__name__}, expected a JSON object")
    return payload


def build_chat_body(case: dict[str, Any], source_document: dict[str, Any], gcs_uri: str) -> dict[str, Any]:
    body = copy.deepcopy(case.get("input", {}))
    body["researchSections"] = body.get("researchSections") or source_document
    body["contextGcsUri"] = gcs_uri
    return body


def upload_document(client: httpx.Client, base_url: str, source_document: dict[str, Any]) -> dict[str, Any]:
    resp = client.post(
        f"{base_url}/qna/upload",
        files={
            "file": (
                "source_document.json",
                json.dumps(source_document, ensure_ascii=False).encode("utf-8"),
                "application/json",
            )
        },
        data={"dest_blob_path": UPLOAD_BLOB_PATH},
    )
    payload = _json_body(resp)
    gcs_uri = payload.get("gcs_uri") or payload.get("gcs_blob_path") or UPLOAD_BLOB_PATH
    return {"request": {"dest_blob_path": UPLOAD_BLOB_PATH}, "response": payload, "gcs_uri": gcs_uri}


def replay_case(
    client: httpx.Client,
    base_url: str,
    case: dict[str, Any],
    source_document: dict[str, Any],
    gcs_uri: str,
) -> ReplayResult:
    request_body = build_chat_body(case, source_document, gcs_uri)
    payload = _json_body(client.post(f"{base_url}/qna/chat", json=request_body))
    answer = payload.get("answer")
    if not isinstance(answer, str):
        raise ReplayError(f"Case {case.get('id')} returned no string answer: {payload}")
    return ReplayResult(
        case_id=str(case.get("id", "")),
        question=case.get("input", {}).get("question", ""),
        answer=answer,
        request=request_body,
        response=payload,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-url",
        default="https://ct1-cta.dbaware.dev.gcp.db.com/query-service",
        help="Base URL for the walkthrough agent service.",
    )
    parser.add_argument(
        "--dataset",
        type=Path,
        default=DATASET_PATH,
        help="Path to the walkthrough dataset JSON.",
    )
    parser.add_argument(
        "--source-document",
        type=Path,
        default=SOURCE_DOCUMENT_PATH,
        help="Path to source_document.json.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "scripts" / "walkthrough_query_agent_live_outputs.json",
        help="Where to write captured outputs.",
    )
    parser.add_argument(
        "--verify-tls",
        action="store_true",
        help="Enable TLS certificate verification.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=180.0,
        help="HTTP timeout in seconds.",
    )
    return parser


def replay_all(args: argparse.Namespace, cases: list[dict[str, Any]], source_document: dict[str, Any]) -> dict[str, Any]:
    """Upload the document, replay every case, and return the output document."""
    base_url = args.base_url.rstrip("/")
    results: list[dict[str, Any]] = []
    with httpx.Client(
        verify=args.verify_tls,
        timeout=args.timeout,
        trust_env=False,
        follow_redirects=True,
    ) as client:
        upload_result = upload_document(client, base_url, source_document)
        gcs_uri = upload_result["gcs_uri"]
        for case in cases:
            replayed = replay_case(client, base_url, case, source_document, gcs_uri)
            results.append(asdict(replayed))
            print(f"[{replayed.case_id}] {replayed.answer}")
    return {
        "base_url": args.base_url,
        "dataset": str(args.dataset),
        "source_document": str(args.source_document),
        "verify_tls": bool(args.verify_tls),
        "upload": upload_result,
        "results": results,
    }


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        dataset = load_json(args.dataset)
        source_document = load_json(args.source_document)
        cases = [c for c in dataset.get("cases") or [] if isinstance(c, dict)]
        if not cases:
            print(f"No cases found in {args.dataset}", file=sys.stderr)
            return EXIT_NO_CASES
        output = replay_all(args, cases, source_document)
    except httpx.HTTPStatusError as exc:
        print(f"ERROR: {exc.request.url} answered HTTP {exc.response.status_code}", file=sys.stderr)
        return EXIT_FAILED
    except httpx.HTTPError as exc:
        print(f"ERROR: could not reach the agent at {args.base_url}: {exc}", file=sys.stderr)
        return EXIT_FAILED
    except ReplayError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return EXIT_FAILED
    args.output.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"\nWrote captured outputs to {args.output}")
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
