# One-time setup on a new machine: creates .venv in the service folder and installs the
# pinned requirements (including test tools). Re-run it after pulling new requirements.
#
#   .\scripts\setup_local.ps1
#   .\scripts\setup_local.ps1 -Python "C:\Python311\python.exe"   # pick a specific interpreter
#
# Needs Python 3.11 or newer.
param([string]$Python = "python")
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$venv = Join-Path $root ".venv"
$venvPython = Join-Path $venv "Scripts\python.exe"

$version = & $Python -c "import sys; print('%d.%d' % sys.version_info[:2])"
if ([version]$version -lt [version]"3.11") {
    Write-Host "Python $version found at '$Python'; 3.11 or newer is required." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $venvPython)) {
    Write-Host "Creating virtual environment in $venv (Python $version)..."
    & $Python -m venv $venv
}
Write-Host "Installing requirements..."
& $venvPython -m pip install --upgrade pip --quiet
& $venvPython -m pip install -r (Join-Path $root "requirements.txt") -c (Join-Path $root "constraints.txt")
if ($LASTEXITCODE -ne 0) {
    Write-Host "Installing the requirements failed (see the output above)." -ForegroundColor Red
    exit $LASTEXITCODE
}
Write-Host ""
Write-Host "Done. Start the service with scripts\start_local.ps1, or everything with scripts\start_local_all.ps1." -ForegroundColor Green
