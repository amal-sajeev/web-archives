import asyncio
import json
import sys

root = r'C:\Users\sanjama\Documents\llmjudge'
sys.path.insert(0, root + r'\shared')
sys.path.insert(0, root + r'\scoping-summary-agent\src\main')

from agents import analytics_agent


class FakeStructured:
    def __init__(self, schema):
        self.schema = schema

    def invoke(self, payload):
        if self.schema is analytics_agent.SectionReview:
            return analytics_agent.SectionReview(
                criteria=[
                    analytics_agent.SectionCriterion(name='evidence_support', passed=True, issue='', action=''),
                    analytics_agent.SectionCriterion(name='citation_validity', passed=True, issue='', action=''),
                    analytics_agent.SectionCriterion(name='required_content', passed=True, issue='', action=''),
                    analytics_agent.SectionCriterion(name='schema_compliance', passed=True, issue='', action=''),
                ]
            )
        if self.schema is analytics_agent.ReportReview:
            return analytics_agent.ReportReview(
                criteria=[
                    analytics_agent.ReportCriterion(name='section_coverage', passed=True, issue='', action='', affected_sections=[]),
                    analytics_agent.ReportCriterion(name='cross_section_consistency', passed=True, issue='', action='', affected_sections=[]),
                    analytics_agent.ReportCriterion(name='review_identifier_consistency', passed=True, issue='', action='', affected_sections=[]),
                    analytics_agent.ReportCriterion(name='duplication_and_structure', passed=True, issue='', action='', affected_sections=[]),
                ]
            )
        raise TypeError(f'Unexpected schema: {self.schema}')


class FakeModel:
    def with_structured_output(self, schema, **kwargs):
        return FakeStructured(schema)


analytics_agent.initialize_gemini_model = lambda: FakeModel()
analytics_agent.past_review_report = lambda source_chunks, model, review_feedback=None: {'section': 'Past Review Analysis', 'summary': 'ok'}
analytics_agent.policy_regulation = lambda source_chunks, model, review_feedback=None: {'section': 'Policy, KOD and Regulatory Analysis', 'summary': 'ok'}
analytics_agent.broad_scope_direction = lambda source_chunks, model, review_feedback=None: {'section': 'Broad Scope Direction', 'summary': 'ok'}


async def main():
    plan_data = {
        'output1': [{'source_name': 'past_review', 'content': 'past content', 'metadata': {'url': 'gs://example/past.txt'}}],
        'output2': [{'source_name': 'policy', 'content': 'policy content', 'metadata': {'url': 'gs://example/policy.txt'}}],
        'output3': [{'source_name': 'broad_scope', 'content': 'scope content', 'metadata': {'url': 'gs://example/broad.txt'}}],
    }
    result = await analytics_agent.research_report(plan_data)
    print('FINAL_REPORT_KEYS=', sorted(result.keys()))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())
