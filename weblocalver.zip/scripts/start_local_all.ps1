# Starts the four sample agents in the background, then the evaluation service in this window,
# with the sample agents shown in the dashboard so you can run evaluations against them.
#
#   .\scripts\start_local_all.ps1             # agents on :4010-4013, service on :4002
#   .\scripts\start_local_all.ps1 -Open       # also open the dashboard in the browser
#   .\scripts\start_local_all.ps1 -Db C:\temp\scratch.db   # keep test runs out of eval_service.db
#
# Press Ctrl+C to stop the service; the agents this script started are stopped too.
# Agent logs: %TEMP%\dbaware-eval-local\<agent_id>.log
#
# The sample agents ship with "enabled: false" in their agent.yaml (so they stay hidden in
# real deployments). This script shows them by setting EVAL_ENABLE_AGENTS for this run only;
# the agent.yaml files are not modified.
param(
    [int]$Port = 4002,
    [string]$Db = "",
    [switch]$Open
)
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "local\common.ps1")

$python = Get-ServicePython
Write-Host "Starting sample agents..."
$started = @()
foreach ($agent in $script:SampleAgents) {
    $process = Start-SampleAgent $agent $python
    if ($process) { $started += $process }
}

$env:EVAL_ENABLE_AGENTS = ($script:SampleAgents | ForEach-Object { $_.AgentId }) -join ","
Set-LocalDatabase $Db
try {
    Start-EvalService -Port $Port -Open:$Open
} finally {
    if ($started.Count -gt 0) {
        Write-Host "Stopping the sample agents started by this script..."
        Stop-StartedProcesses $started
    }
}
