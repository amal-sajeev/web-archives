# Stops anything still listening on the local evaluation service and sample-agent ports
# (4002 and 4010-4013 by default). Use it if a window was closed without Ctrl+C.
#
#   .\scripts\stop_local.ps1
#   .\scripts\stop_local.ps1 -Port 4100       # if the service was started with -Port 4100
param([int]$Port = 4002)
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "local\common.ps1")

$ports = @($Port) + ($script:SampleAgents | ForEach-Object { $_.Port })
$stopped = 0
foreach ($p in $ports) {
    $owners = Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue |
        Select-Object -ExpandProperty OwningProcess -Unique
    foreach ($owner in $owners) {
        $name = (Get-Process -Id $owner -ErrorAction SilentlyContinue).ProcessName
        Stop-Process -Id $owner -Force -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host "Stopped $name (pid $owner) on :$p"
        $stopped++
    }
}
if ($stopped -eq 0) { Write-Host "Nothing was running on ports $($ports -join ', ')." }
