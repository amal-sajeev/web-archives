#!/usr/bin/env python3
"""Evaluation gate for CI/CD pipelines.

Starts an evaluation run for one agent, polls the run's event stream until it
finishes, fetches the persisted run record, and exits:

    0  every gate passed (run status == "PASS" plus any optional thresholds)
    1  a gate failed
    2  infrastructure error (service unreachable, run failed/cancelled, timeout)

Usage:
    python scripts/ci_gate.py [AGENT_ID] [--agent AGENT_ID] [--eval-url URL]
                              [--timeout SECONDS] [--poll-interval SECONDS]
                              [--score MIN] [--delta MIN] [--pass-rate MIN]
                              [--judge-reps N] [--output FILE] [-v]

    The agent may be given positionally, with --agent, or via AGENT_ID.

Environment variables (defaults for the flags above):
    EVAL_SERVICE_URL        Base URL of the eval service (default http://localhost:4002)
    AGENT_ID                Agent to evaluate when none is given on the command line
    EVAL_TIMEOUT_SECONDS    Overall wait timeout (default 1500)
    EVAL_MIN_SCORE          Minimum weighted_score (default 0 = not checked)
    EVAL_MAX_DELTA_REGRESS  Lowest allowed weighted_delta (default -0.1)
    EVAL_MIN_PASS_RATE      Minimum stats.pass_rate (default 0 = not checked)
    EVAL_JUDGE_REPS         Judge repetitions 1-5 (default 1)

Examples:
    python scripts/ci_gate.py --agent scope_extraction
    python scripts/ci_gate.py scope_extraction --timeout 1200 --score 0.85 --delta -0.05
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ci_gate_client import EvalClient, GateError

EXIT_PASS = 0
EXIT_GATE_FAILED = 1
EXIT_INFRA_ERROR = 2
MIN_JUDGE_REPS = 1
MAX_JUDGE_REPS = 5
GATE_OK_STATUS = "PASS"
RULE = "=" * 60
SUMMARY_FIELDS = (
    "run_id", "agent_id", "dataset_id", "dataset_version", "creation_ts", "created_by",
    "status", "weighted_score", "weighted_delta", "error_detail", "stats",
)


@dataclass(frozen=True)
class Thresholds:
    min_score: float = 0.0
    max_delta_regress: float = -0.1
    min_pass_rate: float = 0.0


def _num(value: Any, default: float = 0.0) -> float:
    return float(value) if isinstance(value, int | float) and not isinstance(value, bool) else default


def _status_gate(run: dict[str, Any]) -> tuple[bool, str]:
    status = run.get("status")
    return status == GATE_OK_STATUS, f"run status: {status}"


def _score_gate(run: dict[str, Any], minimum: float) -> tuple[bool, str] | None:
    if minimum <= 0:
        return None
    score = _num(run.get("weighted_score"))
    return score >= minimum, f"weighted_score {score:.3f} (min {minimum:.3f})"


def _delta_gate(run: dict[str, Any], lowest: float) -> tuple[bool, str]:
    delta = _num(run.get("weighted_delta"))
    return delta >= lowest, f"weighted_delta {delta:+.3f} (lowest allowed {lowest:+.3f})"


def _pass_rate_gate(run: dict[str, Any], minimum: float) -> tuple[bool, str] | None:
    if minimum <= 0:
        return None
    stats = run.get("stats") if isinstance(run.get("stats"), dict) else {}
    rate = _num(stats.get("pass_rate"))
    return rate >= minimum, f"pass_rate {rate:.1%} (min {minimum:.1%})"


def evaluate_gates(run: dict[str, Any], thresholds: Thresholds) -> list[tuple[bool, str]]:
    """Return (passed, description) for every applicable gate."""
    gates = [
        _status_gate(run),
        _score_gate(run, thresholds.min_score),
        _delta_gate(run, thresholds.max_delta_regress),
        _pass_rate_gate(run, thresholds.min_pass_rate),
    ]
    return [gate for gate in gates if gate is not None]


def summarise(run: dict[str, Any]) -> dict[str, Any]:
    return {key: run.get(key) for key in SUMMARY_FIELDS}


def export_summary(summary: dict[str, Any], output: str | None) -> None:
    text = json.dumps(summary, indent=2)
    if output:
        Path(output).write_text(text + "\n", encoding="utf-8")
        print(f"Results exported to {output}")
    else:
        print("\n=== Evaluation Results ===")
        print(text)


def report_gates(results: list[tuple[bool, str]]) -> bool:
    print("\n=== Gates ===")
    for passed, description in results:
        print(f"[{'PASS' if passed else 'FAIL'}] {description}")
    all_passed = all(passed for passed, _ in results)
    print(f"\n{'ALL GATES PASSED' if all_passed else 'GATES FAILED'}")
    return all_passed


def _env_default(name: str, default: str) -> str:
    """Env-var default as a string: argparse applies ``type=`` to it, so a bad value
    becomes a clean usage error ("argument --timeout: invalid float value") instead
    of a traceback while the parser is being built."""
    return os.getenv(name) or default


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("agent_id", nargs="?", help="agent to evaluate (or --agent / AGENT_ID)")
    parser.add_argument("--agent", dest="agent_flag", help="agent to evaluate")
    parser.add_argument("--eval-url", default=_env_default("EVAL_SERVICE_URL", "http://localhost:4002"))
    parser.add_argument("--timeout", type=float, default=_env_default("EVAL_TIMEOUT_SECONDS", "1500"))
    parser.add_argument("--poll-interval", type=float, default=5.0)
    parser.add_argument("--score", type=float, default=_env_default("EVAL_MIN_SCORE", "0"))
    parser.add_argument("--delta", type=float, default=_env_default("EVAL_MAX_DELTA_REGRESS", "-0.1"))
    parser.add_argument("--pass-rate", type=float, default=_env_default("EVAL_MIN_PASS_RATE", "0"))
    parser.add_argument("--judge-reps", type=int, default=_env_default("EVAL_JUDGE_REPS", "1"))
    parser.add_argument("--output", help="write the run summary JSON to this file")
    parser.add_argument("-v", "--verbose", action="store_true", help="log progress events")
    return parser


def resolve_agent(args: argparse.Namespace) -> str:
    """The agent to evaluate; ValueError when none is given or two different ones are."""
    if args.agent_id and args.agent_flag and args.agent_id != args.agent_flag:
        raise ValueError(
            f"two different agent ids given: '{args.agent_id}' (positional) and '{args.agent_flag}' (--agent)"
        )
    agent_id = args.agent_flag or args.agent_id or os.getenv("AGENT_ID")
    if not agent_id:
        raise ValueError("give one agent id (positional, --agent, or AGENT_ID)")
    return agent_id


def run_gate(args: argparse.Namespace, agent_id: str) -> int:
    def log(msg: str) -> None:
        if args.verbose:
            print(f"[INFO] {msg}")

    judge_reps = max(MIN_JUDGE_REPS, min(MAX_JUDGE_REPS, args.judge_reps))
    thresholds = Thresholds(args.score, args.delta, args.pass_rate)
    print(f"{RULE}\nEvaluation gate for agent: {agent_id}\nEval service: {args.eval_url}\n{RULE}")
    try:
        with EvalClient(args.eval_url, poll_interval=args.poll_interval, log=log) as client:
            client.check_health()
            run = client.run_to_completion(agent_id, judge_reps, args.timeout)
    except GateError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return EXIT_INFRA_ERROR
    passed = report_gates(evaluate_gates(run, thresholds))
    export_summary(summarise(run), args.output)
    return EXIT_PASS if passed else EXIT_GATE_FAILED


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        agent_id = resolve_agent(args)
    except ValueError as exc:
        parser.print_usage(sys.stderr)
        print(f"ERROR: {exc}", file=sys.stderr)
        return EXIT_INFRA_ERROR
    try:
        return run_gate(args, agent_id)
    except Exception as exc:  # top-level guard: report and fail the pipeline step
        print(f"[ERROR] unexpected failure: {type(exc).__name__}: {exc}", file=sys.stderr)
        return EXIT_INFRA_ERROR


if __name__ == "__main__":
    sys.exit(main())
