# WIF / Vertex setup for this project

This project uses Google Workload Identity Federation (WIF) through ADC. The evaluation service is configured to use Vertex via `PROJECT_NAME` and `GOOGLE_APPLICATION_CREDENTIALS`, not a Gemini API key.

## What works

Validated working values for this repo:

- `PROJECT_NAME=db-dev-46jr-mp-cta-analytics`
- `PROJECT_LOCATION=us-central1`
- `GOOGLE_APPLICATION_CREDENTIALS=C:\Users\sanjama\Downloads\wif_new\dbgarda\config\wif-file-based.json`
- `HTTPS_PROXY=http://sdod3-proxy.intranet.db.com:8080`
- `HTTP_PROXY=http://sdod3-proxy.intranet.db.com:8080`
- `NO_PROXY=*.db.com,localhost,127.0.0.1,10.*`
- `SSL_CERT_FILE=C:\Users\sanjama\Downloads\wif_new\dbgarda\config\cacert.crt`
- `REQUESTS_CA_BUNDLE=C:\Users\sanjama\Downloads\wif_new\dbgarda\config\cacert.crt`

These values are also set in `dbaware-evaluation-service/.env` and loaded by the process before startup.

## How to refresh the WIF token

The WIF JSON points to an Azure-backed external account and reads a JWT file. If the token expires, regenerate it before a judge run:

```powershell
java "-Dspring.config.location=C:/Users/sanjama/Downloads/wif_new/dbgarda/config/application.properties" -jar "C:/Users/sanjama/Downloads/wif_new/dbgarda/gcp-wif.jar"
```

This refreshes `jwtResponse.json` and the external-account flow can then obtain fresh credentials again.

## Quick validation

From the repo root, run:

```powershell
& ".venv\Scripts\python.exe" -c "import os, google.auth; from langchain_google_genai import ChatGoogleGenerativeAI; os.environ['PROJECT_NAME'] = 'db-dev-46jr-mp-cta-analytics'; os.environ['PROJECT_LOCATION'] = 'us-central1'; creds, project = google.auth.default(); print('ADC_CLASS=', type(creds).__name__); print('ADC_PROJECT=', project); llm = ChatGoogleGenerativeAI(model='gemini-2.5-pro', project='db-dev-46jr-mp-cta-analytics', location='us-central1', temperature=0, max_retries=0, timeout=60); print(llm.invoke('Reply with exactly: WIF_OK').content)"
```

Expected outcome:

- `ADC_CLASS= Credentials`
- output contains `WIF_OK`

## Important nuance

`google.auth.default()` may return `project=None` when using WIF. That is normal. The service still works because the actual Vertex client is created with explicit `project='db-dev-46jr-mp-cta-analytics'`, which is the switch that routes the model call to Vertex.

## If it fails

Check in this order:

1. `GOOGLE_APPLICATION_CREDENTIALS` points to the WIF JSON file.
2. The Azure JWT file exists and has not expired.
3. Proxy env vars are present and `cacert.crt` is in place.
4. `PROJECT_NAME` is set to the GCP project ID.
5. The WIF impersonated service account is still allowed to call Vertex in that project.

If any of those are missing or stale, the service will fall back to a degraded/no-Vertex state instead of crashing.
