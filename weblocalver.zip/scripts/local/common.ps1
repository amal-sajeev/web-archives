﻿# Shared helpers for the local launch scripts (dot-source this file; do not run it directly).
# Everything here is Windows PowerShell 5.1 compatible.

$script:ServiceRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$script:LogDir = Join-Path $env:TEMP "dbaware-eval-local"

# The four sample agents and the agent ids (src/agents/<id>/agent.yaml) that point at them.
$script:SampleAgents = @(
    @{ Name = "Data extraction"; AgentId = "scope_extraction"; File = "data_extraction_agent.py"; Port = 4010 }
    @{ Name = "Report writer";   AgentId = "report_writer";    File = "report_writer_agent.py";   Port = 4011 }
    @{ Name = "Invoice parser";  AgentId = "invoice_parser";   File = "invoice_parser_agent.py";  Port = 4012 }
    @{ Name = "Document QA";     AgentId = "document_qa";      File = "document_qa_agent.py";     Port = 4013 }
)

function Get-ServicePython {
    $venvPython = Join-Path $script:ServiceRoot ".venv\Scripts\python.exe"
    if (Test-Path $venvPython) { return $venvPython }
    Write-Host "No virtual environment found at $venvPython" -ForegroundColor Red
    Write-Host "Run scripts\setup_local.ps1 first to create it and install the requirements." -ForegroundColor Yellow
    exit 1
}

function Test-PortInUse([int]$Port) {
    return [bool](Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
}

function Wait-HttpOk([string]$Url, [int]$TimeoutSeconds = 30) {
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        try {
            $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 3
            if ($response.StatusCode -eq 200) { return $true }
        } catch {
            Start-Sleep -Milliseconds 500
        }
    }
    return $false
}

function Set-LocalDatabase([string]$DbPath) {
    # An EVAL_DB_URL already set by the caller wins (e.g. postgresql:// for CloudSQL).
    if ($env:EVAL_DB_URL) {
        Write-Host "Using EVAL_DB_URL from the environment: $env:EVAL_DB_URL"
        return
    }
    if (-not $DbPath) { $DbPath = Join-Path $script:ServiceRoot "eval_service.db" }
    $env:EVAL_DB_URL = "sqlite:///" + ([System.IO.Path]::GetFullPath($DbPath) -replace '\\', '/')
    Write-Host "Database: $DbPath"
}

function Start-SampleAgent($Agent, [string]$Python) {
    if (Test-PortInUse $Agent.Port) {
        Write-Host ("  {0,-16} already running on :{1} (reusing it)" -f $Agent.Name, $Agent.Port)
        return $null
    }
    New-Item -ItemType Directory -Force $script:LogDir | Out-Null
    $log = Join-Path $script:LogDir ($Agent.AgentId + ".log")
    $agentFile = Join-Path $script:ServiceRoot ("src\sample_agents\" + $Agent.File)
    $env:PYTHONPATH = Join-Path $script:ServiceRoot "src"
    $process = Start-Process -FilePath $Python -ArgumentList "`"$agentFile`"" -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput $log -RedirectStandardError ($log + ".err")
    if (Wait-HttpOk "http://127.0.0.1:$($Agent.Port)/api/health" 30) {
        Write-Host ("  {0,-16} started on :{1}" -f $Agent.Name, $Agent.Port)
    } else {
        Write-Host ("  {0,-16} did not start on :{1} - see {2}.err" -f $Agent.Name, $Agent.Port, $log) -ForegroundColor Red
    }
    return $process
}

function Stop-StartedProcesses($Processes) {
    foreach ($process in $Processes) {
        if ($process -and -not $process.HasExited) {
            Stop-Process -Id $process.Id -Force -Confirm:$false -ErrorAction SilentlyContinue
        }
    }
}

function Start-EvalService([int]$Port, [switch]$Open) {
    $python = Get-ServicePython
    if (Test-PortInUse $Port) {
        Write-Host "Port $Port is already in use. Stop the process using it (scripts\stop_local.ps1) or pass -Port." -ForegroundColor Red
        return
    }
    $url = "http://127.0.0.1:$Port/"
    Write-Host ""
    Write-Host "Evaluation service: $url   (press Ctrl+C to stop)" -ForegroundColor Green
    if ($Open) {
        # Open the browser once the service answers, without blocking the foreground server.
        Start-Job -ScriptBlock {
            param($HealthUrl, $PageUrl)
            for ($i = 0; $i -lt 60; $i++) {
                try { Invoke-WebRequest -Uri $HealthUrl -UseBasicParsing -TimeoutSec 2 | Out-Null; Start-Process $PageUrl; return } catch { Start-Sleep -Milliseconds 500 }
            }
        } -ArgumentList ("http://127.0.0.1:$Port/livez"), $url | Out-Null
    }
    $env:PYTHONPATH = Join-Path $script:ServiceRoot "src\main"
    Push-Location (Join-Path $script:ServiceRoot "src\main")
    try {
        & $python -m uvicorn main:app --host 127.0.0.1 --port $Port
    } finally {
        Pop-Location
    }
}
