# dbaware-query-service

A repository hosting AI-powered query agents that provide conversational Q&A capabilities over structured documents, backed by Google Gemini models on GCP Vertex AI.

Currently included module:

- [`walkthrough-query-agent`](./walkthrough-query-agent) — A FastAPI-based session-aware Q&A intelligence service for walkthrough / structural document summaries.

---

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [Tech Stack](#tech-stack)
- [Prerequisites](#prerequisites)
- [Local Development](#local-development)
- [Configuration](#configuration)
- [API Endpoints](#api-endpoints)

---

## Overview

The `walkthrough-query-agent` is a stateful Q&A engine that:

- Accepts natural-language questions about a document/plan context stored in GCS.
- Maintains per-session (per plan-number) conversation history to support follow-up questions.
- Uses **Gemini** (via `langchain-google-genai` on Vertex AI) as the primary answering model.
- Runs an **LLM-as-a-judge** evaluation loop (groundedness, citation coverage, contradictions, faithfulness, relevance) and iteratively refines the answer until quality thresholds are met.
- Emits an **agent card** for every invocation to record activity, metrics, and correlation IDs for observability.

## Architecture

```
┌──────────────┐       ┌─────────────────────────────┐       ┌──────────────────┐
│  Client / UI │──────▶│  FastAPI (walkthrough-agent)│──────▶│  Gemini (Vertex) │
└──────────────┘       │  ├─ /qna/chat               │       └──────────────────┘
                       │  ├─ /qna/upload             │              ▲
                       │  └─ /qna/close-session      │              │
                       │                             │       ┌──────────────────┐
                       │  Agent  ──▶  Judge (LLM)    │──────▶│   GCS (context)  │
                       └─────────────────────────────┘       └──────────────────┘
```

## Project Structure

```
dbaware-query-service/
├── .github/workflows/           # GitHub Actions CI/CD pipelines
├── gke/                         # GKE environment config (ct1, dev1)
├── walkthrough-query-agent/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── pom.xml                  # Maven wrapper for build/deploy tooling
│   ├── helm-chart/              # Helm chart (values-*.yaml + templates)
│   └── src/
│       ├── main/
│       │   ├── app.py           # FastAPI entrypoint
│       │   ├── agent/           # Gemini agent + LLM judge
│       │   ├── agent_helper/    # Env config, prompt builder, agent card, utils
│       │   ├── config/          # Configuration module
│       │   ├── etc/prompts/     # System / evaluator / QnA prompts
│       │   ├── resources/       # Sample document(s)
│       │   └── service/         # Router, request/response models, QnA logic
│       └── tests/               # Pytest suite (unit + service tests)
└── README.md
```

## Tech Stack

- **Language:** Python 3.11
- **Framework:** FastAPI + Uvicorn
- **LLM:** Google Gemini (`gemini-2.5-pro`, judge on `gemini-2.5-flash`) via `langchain-google-genai`
- **Cloud:** GCP (Vertex AI, GCS)
- **Packaging:** Docker, Helm, Maven (for CI orchestration)
- **Testing:** pytest, pytest-asyncio, pytest-cov

## Prerequisites

- Python 3.11
- Access to a GCP project with Vertex AI + GCS enabled
- `GOOGLE_APPLICATION_CREDENTIALS` pointing at a valid service account key (or Workload Identity Federation config)
- Docker (optional, for containerized runs)

## Local Development

```bash
# 1. Clone
git clone https://github.com/ntbv-ifbn/dbaware-query-service.git
cd dbaware-query-service/walkthrough-query-agent

# 2. Create a virtual env
python3.11 -m venv .venv
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the FastAPI app
cd src/main
python app.py
```

The service starts on `http://127.0.0.1:8010` with root path `/query-service`. Interactive docs at:

- Swagger UI: http://127.0.0.1:8010/query-service/docs
- OpenAPI JSON: http://127.0.0.1:8010/query-service/openapi.json

## Configuration

All configuration is managed via environment variables, which are injected during deployment. Environment-specific values are configured via Helm charts (`values-dev1.yaml`, `values-uat1.yaml`, `values-ct1.yaml`, etc.) during container deployment.

**Key configuration variables:**

| Variable | Description |
|---|---|
| `GCP_PROJECT_ID` | GCP project hosting Vertex AI |
| `GCP_REGION` | Vertex AI region |
| `GCP_MODEL_NAME` | Primary Gemini model (answering) |
| `LLM_JUDGE_MODEL_NAME` | Gemini model used by the evaluator |
| `GCS_BUCKET_NAME` | GCS bucket for document storage |
| `MODEL_TEMPERATURE` | LLM temperature setting (0.0-1.0) |
| `MODEL_TOP_P` | LLM top_p setting |
| `MODEL_TOP_K` | LLM top_k setting |
| `LLM_JUDGE_THRESHOLD` | Judge confidence threshold |
| `LLM_JUDGE_MAX_ITERATIONS` | Judge maximum iterations |

These variables are read from the `Config` class (`walkthrough-query-agent/src/main/config/config.py`) which retrieves them directly from the environment using `os.getenv()`.

| `GCS_BUCKET_NAME` | Bucket for document/context storage |
| `MODEL_TEMPERATURE` / `MODEL_TOP_P` / `MODEL_TOP_K` | Generation params |
| `LLM_JUDGE_THRESHOLD` | Minimum quality score before returning |
| `LLM_JUDGE_MAX_ITERATIONS` | Max refinement loops |
| `HTTPS_PROXY` / `SSL_CERT_FILE` | Optional corporate network settings |

For non-local environments, values are supplied via Helm (`values-<env>.yaml`) and mounted as a ConfigMap.

## API Endpoints

Base path: `/query-service/qna`

| Method | Path | Description |
|---|---|---|
| `POST` | `/chat` | Ask a question against the cached document context for a given `plan_number`. Supports follow-ups via session state. |
| `POST` | `/upload` | Upload a local `.json` document to the configured GCS bucket. |
| `POST` | `/close-session` | Terminate an active plan session and free cached context. |

### Sample `POST /qna/chat` request

```json
{
  "question": "What are the key risks identified in section 3?",
  "plan_number": "PLAN-12345",
  "plan_name": "Q3 Walkthrough",
  "research_sections": ["risk", "controls"],
  "context_type": "walkthrough_summary",
  "context_gcs_uri": "gs://my-bucket/plans/PLAN-12345.json"
}
```

Response includes the answer plus LLM-judge metrics: `groundedness_score`, `citation_coverage`, `unsupported_claim_count`, `contradiction_score`, `context_faithfulness`, `answer_relevance`, and `evaluation_reasoning`.



