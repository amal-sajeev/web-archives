import json
import logging
import re
from typing import List, Dict, Any, Optional, Tuple, Set

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from google.api_core.exceptions import NotFound

from service import document_service_helpers as doc_helpers

logger = logging.getLogger(__name__)


# Public re-export aliases for compatibility with existing imports.
AmbiguousDeleteRequestError = doc_helpers.AmbiguousDeleteRequestError
DocumentManagementError = doc_helpers.DocumentManagementError
DocumentNotFoundError = doc_helpers.DocumentNotFoundError
InvalidDocumentTypeError = doc_helpers.InvalidDocumentTypeError
MultipleDocumentMatchesError = doc_helpers.MultipleDocumentMatchesError
PartialDeleteFailureError = doc_helpers.PartialDeleteFailureError
ReportRegenerationError = doc_helpers.ReportRegenerationError
VALID_DOCUMENT_TYPES = doc_helpers.VALID_DOCUMENT_TYPES
REGISTRY_FILES = doc_helpers.REGISTRY_FILES
PRELIMINARY_RESEARCH_PREFIX = doc_helpers.PRELIMINARY_RESEARCH_PREFIX


def _normalize_document_type(document_type: Optional[str]) -> str:
    return doc_helpers._normalize_document_type(document_type)


def _normalize_text_for_match(value: Optional[str]) -> str:
    return doc_helpers._normalize_text_for_match(value)


def _title_similarity_score(query: str, candidate: str) -> float:
    return doc_helpers._title_similarity_score(query, candidate)


def _normalize_title(title: Optional[str]) -> str:
    return doc_helpers._normalize_title(title)


def _registry_blob_path(plan_number: str, document_type: str) -> str:
    return doc_helpers._registry_blob_path(plan_number, document_type)


async def _read_json_blob(gcs_utils: GCSUtils, blob_path: str) -> Any:
    return await doc_helpers._read_json_blob(gcs_utils, blob_path)


def _extract_title_from_command(command: str, document_type: Optional[str] = None) -> str:
    return doc_helpers._extract_title_from_command(command, document_type)


async def parse_document_removal_intent(
    user_command: str,
    plan_number: Optional[str] = None,
    document_type: Optional[str] = None,
    title: Optional[str] = None,
    env_config: Optional[EnvironmentConfig] = None,
) -> Dict[str, Any]:
    return await doc_helpers.parse_document_removal_intent(
        user_command=user_command,
        plan_number=plan_number,
        document_type=document_type,
        title=title,
        env_config=env_config,
    )


def _validate_removal_intent_payload(intent_payload: Dict[str, Any]) -> Dict[str, Any]:
    return doc_helpers._validate_removal_intent_payload(intent_payload)


async def manage_document_removal(
    plan_number: str,
    document_type: str,
    title: str,
    env_config: EnvironmentConfig,
    scope: str = "all_related",
) -> Dict[str, Any]:
    return await doc_helpers.manage_document_removal(plan_number, document_type, title, env_config, scope)


def _value_mentions_excluded_title(value: Any, excluded_titles: Set[str]) -> bool:
    return doc_helpers._value_mentions_excluded_title(value, excluded_titles)


def _filter_excluded_content(payload: Any, excluded_titles: Set[str]) -> Any:
    return doc_helpers._filter_excluded_content(payload, excluded_titles)


async def _load_excluded_titles_for_plan(plan_number: str, gcs_utils: GCSUtils) -> Set[str]:
    return await doc_helpers._load_excluded_titles_for_plan(plan_number, gcs_utils)


async def _mark_registry_document_removed(plan_number: str, document_type: str, target_title: str, gcs_utils: GCSUtils) -> Dict[str, Any]:
    return await doc_helpers._mark_registry_document_removed(plan_number, document_type, target_title, gcs_utils)


def _extract_inclusion_title_from_command(command: str, document_type: Optional[str] = None) -> str:
    return doc_helpers._extract_inclusion_title_from_command(command, document_type)


async def parse_document_inclusion_intent(
    user_command: str,
    plan_number: Optional[str] = None,
    document_type: Optional[str] = None,
    title: Optional[str] = None,
    content: Optional[Any] = None,
    section_title: Optional[str] = None,
    document_id: Optional[Any] = None,
    env_config: Optional[EnvironmentConfig] = None,
) -> Dict[str, Any]:
    return await doc_helpers.parse_document_inclusion_intent(
        user_command=user_command,
        plan_number=plan_number,
        document_type=document_type,
        title=title,
        content=content,
        section_title=section_title,
        document_id=document_id,
        env_config=env_config,
    )


def _validate_inclusion_intent_payload(intent_payload: Dict[str, Any]) -> Dict[str, Any]:
    return doc_helpers._validate_inclusion_intent_payload(intent_payload)


async def manage_document_inclusion(
    plan_number: str,
    document_type: str,
    title: str,
    env_config: EnvironmentConfig,
    content: Optional[Any] = None,
    document_id: Optional[Any] = None,
    section_title: Optional[str] = None,
    scope: str = "all_related",
) -> Dict[str, Any]:
    return await doc_helpers.manage_document_inclusion(
        plan_number=plan_number,
        document_type=document_type,
        title=title,
        env_config=env_config,
        content=content,
        document_id=document_id,
        section_title=section_title,
        scope=scope,
    )


async def _mark_registry_document_included(
    plan_number: str,
    document_type: str,
    target_title: str,
    gcs_utils: GCSUtils,
    document_entry: Optional[Dict[str, Any]] = None,
    blob_path: Optional[str] = None,
) -> Dict[str, Any]:
    return await doc_helpers._mark_registry_document_included(
        plan_number=plan_number,
        document_type=document_type,
        target_title=target_title,
        gcs_utils=gcs_utils,
        document_entry=document_entry,
        blob_path=blob_path,
    )


async def _load_included_documents_for_plan(plan_number: str, gcs_utils: GCSUtils) -> List[Dict[str, Any]]:
    return await doc_helpers._load_included_documents_for_plan(plan_number, gcs_utils)


def _merge_included_content(payload: Any, included_documents: List[Dict[str, Any]]) -> Any:
    return doc_helpers._merge_included_content(payload, included_documents)


async def _refresh_preliminary_research(plan_number: str, gcs_utils: GCSUtils) -> str:
    return await doc_helpers._refresh_preliminary_research(plan_number, gcs_utils)


async def list_all_documents(plan_number: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """
    Lists all documents (policy, kod, procedure) for a plan in one call.
    """
    try:
        document_types = ["policy", "kod", "procedure"]
        document_groups = []
        total_count = 0
        for doc_type in document_types:
            result = await list_documents_from_bucket(plan_number, doc_type, env_config)
            document_groups.append({
                "document_type": doc_type,
                "documents": result.get("documents", []),
                "total_count": result.get("total_count", 0),
            })
            total_count += result.get("total_count", 0)

        return {
            "plan_number": plan_number,
            "document_groups": document_groups,
            "total_count": total_count,
            "message": f"Successfully retrieved all documents for plan {plan_number}",
            "source": "gcs",
        }
    except Exception as e:
        logger.error(f"Error listing all documents: {str(e)}", exc_info=True)
        raise


async def list_documents_from_bucket(plan_number: str, document_type: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Lists documents from GCS bucket."""
    try:
        return await _list_from_gcs(plan_number, document_type, env_config)
    except Exception as e:
        logger.error(f"Error listing documents: {str(e)}", exc_info=True)
        raise


async def _list_from_gcs(plan_number: str, document_type: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Lists documents from GCS bucket and extracts metadata from JSON."""
    try:
        gcs_utils = GCSUtils(env_config)
        bucket_name = gcs_utils.bucket_name
        bucket_path = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/"

        logger.info(f"Listing documents from GCS: gs://{bucket_name}/{bucket_path}")
        bucket = gcs_utils.get_bucket()
        blobs = bucket.list_blobs(prefix=bucket_path)

        documents = []
        for blob in blobs:
            filename = blob.name.replace(bucket_path, "")
            if not filename:
                continue
            try:
                json_content = gcs_utils.read_blob_json(blob.name)
                if isinstance(json_content, dict):
                    document_title = json_content.get("document_title", filename)
                    document_id = json_content.get("document_id", filename)
                    documents.append({
                        "file_name": filename,
                        "document_title": document_title,
                        "document_id": document_id,
                    })
                else:
                    documents.append({
                        "file_name": filename,
                        "document_title": filename,
                        "document_id": filename,
                    })
            except Exception as e:
                logger.warning(f"Failed to read metadata from {blob.name}: {str(e)}, using filename as fallback")
                documents.append({
                    "file_name": filename,
                    "document_title": filename,
                    "document_id": filename,
                })

        logger.info(f"Found {len(documents)} documents of type '{document_type}' for plan {plan_number} in GCS")
        return {
            "plan_number": plan_number,
            "document_type": document_type,
            "bucket_path": f"gs://{bucket_name}/{bucket_path}",
            "documents": sorted(documents, key=lambda x: x["file_name"]),
            "total_count": len(documents),
            "message": f"Successfully retrieved {len(documents)} document(s) of type '{document_type}' for plan {plan_number}",
            "source": "gcs",
        }
    except NotFound as e:
        logger.warning(f"GCS bucket path not found: {str(e)}")
        return {
            "plan_number": plan_number,
            "document_type": document_type,
            "bucket_path": f"gs://{GCSUtils(env_config).bucket_name}/dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/",
            "files": [],
            "total_count": 0,
            "message": f"No documents found for plan {plan_number} and type '{document_type}'",
            "source": "gcs",
        }
    except Exception as e:
        logger.error(f"Error listing documents from GCS: {str(e)}", exc_info=True)
        raise


async def delete_documents(plan_number: str, document_type: str, files: List[str], env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Deletes documents from GCS bucket."""
    try:
        return await _delete_from_gcs(plan_number, document_type, files, env_config)
    except Exception as e:
        logger.error(f"Error deleting documents: {str(e)}", exc_info=True)
        raise


async def delete_documents_bulk(plan_number: str, document_groups: List[Dict[str, Any]], env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Deletes multiple document groups in one call, each with its own document type and item list with metadata."""
    results = []
    total_requested = 0
    total_deleted = 0

    for group in document_groups:
        document_type = group.get("document_type")
        items = group.get("items", [])
        if not document_type or not isinstance(items, list):
            results.append({
                "document_type": document_type or "unknown",
                "files_requested": 0,
                "files_deleted": [],
                "files_failed": [],
                "total_deleted": 0,
                "message": "Invalid document group payload.",
                "source": "gcs",
            })
            continue

        files = [item.get("file_name") for item in items if item.get("file_name")]
        logger.info(f"Extracted {len(files)} file names from {len(items)} items for deletion: {files}")
        result = await delete_documents(plan_number, document_type, files, env_config)
        results.append(result)
        total_requested += result.get("files_requested", 0)
        total_deleted += result.get("total_deleted", 0)

    return {
        "plan_number": plan_number,
        "total_requested": total_requested,
        "total_deleted": total_deleted,
        "message": f"Delete completed for {len(results)} document type(s).",
        "results": results,
    }


async def _delete_from_gcs(plan_number: str, document_type: str, files: List[str], env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Deletes documents from GCS bucket."""
    deleted = []
    failed = []
    try:
        gcs_utils = GCSUtils(env_config)
        bucket = gcs_utils.get_bucket()
        base_path = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/"

        logger.info(f"Deleting {len(files)} documents from GCS: {base_path}")
        for filename in files:
            try:
                blob_path = base_path + filename
                blob = bucket.blob(blob_path)
                if blob.exists():
                    blob.delete()
                    if not blob.exists():
                        logger.info(f"Successfully deleted GCS blob: {blob_path}")
                        deleted.append(filename)
                    else:
                        logger.warning(f"Blob still exists after delete attempt: {blob_path}")
                        failed.append(filename)
                else:
                    logger.warning(f"Blob not found in GCS: {blob_path}")
                    failed.append(filename)
            except Exception as e:
                logger.error(f"Failed to delete GCS blob {filename}: {str(e)}")
                failed.append(filename)

        if len(deleted) == len(files):
            message = f"Successfully deleted all {len(deleted)} document(s) from GCS"
        elif len(deleted) == 0:
            message = f"Failed to delete any documents - 0 out of {len(files)} deleted from GCS"
        else:
            message = f"Partially deleted {len(deleted)} out of {len(files)} documents from GCS ({len(failed)} failed)"

        return {
            "plan_number": plan_number,
            "document_type": document_type,
            "files_requested": len(files),
            "files_deleted": deleted,
            "files_failed": failed,
            "total_deleted": len(deleted),
            "message": message,
            "source": "gcs",
        }
    except Exception as e:
        logger.error(f"Error deleting documents from GCS: {str(e)}", exc_info=True)
        raise


async def upload_documents(
    plan_number: str,
    document_type: str,
    items: List[Dict[str, Any]],
    env_config: EnvironmentConfig,
) -> Dict[str, Any]:
    """Uploads documents/sections to the GCS bucket and updates the plan registry (sister to delete_documents)."""
    try:
        return await _upload_to_gcs(plan_number, document_type, items, env_config)
    except Exception as e:
        logger.error(f"Error uploading documents: {str(e)}", exc_info=True)
        raise


async def upload_documents_bulk(
    plan_number: str,
    document_groups: List[Dict[str, Any]],
    env_config: EnvironmentConfig,
) -> Dict[str, Any]:
    """Uploads multiple document groups in one call across policy, kod, and procedure (sister to delete_documents_bulk)."""
    results = []
    total_requested = 0
    total_uploaded = 0

    for group in document_groups:
        document_type = group.get("document_type")
        items = group.get("items", [])
        if not document_type or not isinstance(items, list):
            results.append({
                "document_type": document_type or "unknown",
                "files_requested": 0,
                "files_uploaded": [],
                "files_failed": [],
                "total_uploaded": 0,
                "message": "Invalid document group payload.",
                "source": "gcs",
            })
            continue

        normalized_items = [
            item.model_dump(mode="json") if hasattr(item, "model_dump")
            else item.dict() if hasattr(item, "dict")
            else dict(item)
            for item in items
            if isinstance(item, dict) or hasattr(item, "dict") or hasattr(item, "model_dump")
        ]
        result = await upload_documents(plan_number, document_type, normalized_items, env_config)
        results.append(result)
        total_requested += result.get("files_requested", 0)
        total_uploaded += result.get("total_uploaded", 0)

    return {
        "plan_number": plan_number,
        "total_requested": total_requested,
        "total_uploaded": total_uploaded,
        "message": f"Upload completed for {len(results)} document type(s).",
        "results": results,
    }


async def _upload_to_gcs(
    plan_number: str,
    document_type: str,
    items: List[Dict[str, Any]],
    env_config: EnvironmentConfig,
) -> Dict[str, Any]:
    """Writes uploaded document/section JSON files to GCS and registers them in relevant_{document_type}.json."""
    uploaded: List[str] = []
    failed: List[str] = []
    try:
        normalized_type = _normalize_document_type(document_type)
        gcs_utils = GCSUtils(env_config)
        base_path = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{normalized_type}/"

        logger.info(f"Uploading {len(items)} document(s) to GCS: {base_path}")
        for idx, item in enumerate(items, start=1):
            if not isinstance(item, dict):
                failed.append(f"item_{idx}")
                continue
            doc_title = str(item.get("document_title") or item.get("title") or f"{normalized_type}_{idx}").strip()
            doc_id = str(item.get("document_id") or item.get("id") or doc_helpers._slugify_title(doc_title) or f"{normalized_type}_{idx}")
            filename = str(item.get("file_name") or "").strip()
            if not filename:
                slug = doc_helpers._slugify_title(doc_title) or f"{normalized_type}_{doc_id}"
                filename = f"{slug}.json"
            elif not filename.endswith(".json"):
                filename = f"{filename}.json"

            try:
                blob_path = base_path + filename
                doc_payload: Dict[str, Any] = {
                    "document_id": doc_id,
                    "document_title": doc_title,
                    "document_type": normalized_type,
                    "status": "active",
                    "excluded": False,
                }
                if item.get("section_id") is not None:
                    doc_payload["section_id"] = item.get("section_id")
                if item.get("section_title") is not None:
                    doc_payload["section_title"] = item.get("section_title")
                if item.get("content") is not None:
                    doc_payload["content"] = item.get("content")
                if item.get("paragraphs") is not None:
                    doc_payload["paragraphs"] = item.get("paragraphs")
                elif item.get("content") is not None:
                    doc_payload["paragraphs"] = [
                        {
                            "section_id": item.get("section_id") or "1",
                            "section_title": item.get("section_title") or doc_title,
                            "text": item.get("content") if isinstance(item.get("content"), str) else json.dumps(item.get("content")),
                        }
                    ]

                gcs_utils.write_blob_json(blob_path, doc_payload)
                await _mark_registry_document_included(
                    plan_number=plan_number,
                    document_type=normalized_type,
                    target_title=doc_title,
                    gcs_utils=gcs_utils,
                    document_entry=doc_payload,
                )
                logger.info(f"Successfully uploaded GCS blob and updated registry: {blob_path}")
                uploaded.append(filename)
            except Exception as e:
                logger.error(f"Failed to upload GCS blob {filename}: {str(e)}")
                failed.append(filename)

        if len(uploaded) == len(items):
            message = f"Successfully uploaded all {len(uploaded)} document(s) to GCS"
        elif len(uploaded) == 0:
            message = f"Failed to upload any documents - 0 out of {len(items)} uploaded to GCS"
        else:
            message = f"Partially uploaded {len(uploaded)} out of {len(items)} documents to GCS ({len(failed)} failed)"

        return {
            "plan_number": plan_number,
            "document_type": normalized_type,
            "files_requested": len(items),
            "files_uploaded": uploaded,
            "files_failed": failed,
            "total_uploaded": len(uploaded),
            "message": message,
            "source": "gcs",
        }
    except Exception as e:
        logger.error(f"Error uploading documents to GCS: {str(e)}", exc_info=True)
        raise

