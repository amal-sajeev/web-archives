import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

try:
    import google.auth
except ModuleNotFoundError:  # pragma: no cover - optional in local/test environments
    google = None

try:
    import sqlalchemy
except ModuleNotFoundError:  # pragma: no cover - optional in bare test environments
    sqlalchemy = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

SCHEMA_NAME = "dbaware_scoping"
REVIEW_SCOPE_TABLE = f"{SCHEMA_NAME}.review_scope"
DATA_EXTRACTION_TABLE = f"{SCHEMA_NAME}.review_data_extraction"
REVIEW_DOCUMENTS_TABLE = f"{SCHEMA_NAME}.dbaware_review_documents"
RESEARCH_RECOMMENDATION_TABLE = f"{SCHEMA_NAME}.review_research_recommendation"

# Process-local mock/fallback store keyed by plan/instance ID so table PKs and mutations
# work deterministically when MOCK_SCOPING_DB=true or PostgreSQL is unreachable.
_MOCK_DATA_EXTRACTION_STORE: Dict[str, Dict[str, Dict[str, Any]]] = {}
_MOCK_REVIEW_DOCUMENTS_STORE: Dict[str, List[Dict[str, Any]]] = {}
_MOCK_RESEARCH_RECOMMENDATION_STORE: Dict[str, Dict[str, Dict[str, Any]]] = {}


def _load_runtime_env() -> None:
    base = Path(__file__).resolve()
    for parent in (base.parents[0], base.parents[1], base.parents[2], base.parents[3]):
        env_file = parent / ".env"
        if env_file.exists():
            load_dotenv(env_file, override=False)


_load_runtime_env()


class DatabaseConnector:
    """Factory for PostgreSQL connections used by DB-aware services."""

    def __init__(self):
        self.project_id = os.getenv("project_name") or os.getenv("GCP_PROJECT_ID")
        self.db_host = os.getenv("db_host") or os.getenv("DB_HOST", "localhost")
        self.db_user = os.getenv("db_user") or os.getenv("DB_USER")
        self.db_pass = os.getenv("scoping_db_pass") or os.getenv("db_password") or ""
        self.db_name = os.getenv("db_name") or os.getenv("DB_NAME")
        self.db_port = int(os.getenv("db_port") or os.getenv("DB_PORT", "5432"))
        self.credentials = None
        if google is not None:
            try:
                self.credentials, _ = google.auth.default()
            except Exception:
                logger.warning(
                    "Unable to initialize Google auth credentials for DB connector",
                    exc_info=True,
                )
                self.credentials = None

    def connect_to_database(self) -> Any:
        engine = sqlalchemy.create_engine(
            sqlalchemy.engine.url.URL.create(
                drivername="postgresql+pg8000",
                username=self.db_user,
                password=self.db_pass,
                host=self.db_host,
                port=self.db_port,
                database=self.db_name,
            ),
            pool_pre_ping=True,
        )
        logger.info(
            "Database engine created for host=%s db=%s", self.db_host, self.db_name
        )
        return engine

    def check_connection(self) -> bool:
        try:
            with self.connect_to_database().connect() as connection:
                connection.execute(sqlalchemy.text("SELECT 1"))
            return True
        except Exception:
            logger.exception("Database connectivity check failed")
            return False

    def get_document_ids_for_scope_instance(self, instance_id: int) -> Dict[str, List[int]]:
        """Queries scoping-db to get mapped document IDs grouped by policy, kod, and procedure."""
        # Pre-configured mock data mapped by review_scope_instance_id
        mock_instance_docs: Dict[int, Dict[str, List[int]]] = {
            1: {"policy": [1, 2, 3], "kod": [121, 43, 27], "procedure": [13, 17, 194]},
        }
        default_mock_docs: Dict[str, List[int]] = {
            "policy": [1, 2, 3],
            "kod": [121, 43, 27],
            "procedure": [13, 17, 194],
        }

        # If MOCK_SCOPING_DB is enabled (defaulting to True until DB connectivity is available)
        if os.getenv("MOCK_SCOPING_DB", "true").lower() in ("true", "1", "yes"):
            resolved_mock = mock_instance_docs.get(instance_id, default_mock_docs)
            logger.info(
                "🧪 [MOCK MODE] Serving mock document IDs for review_scope_instance_id=%s: %s",
                instance_id,
                resolved_mock,
            )
            return {k: list(v) for k, v in resolved_mock.items()}

        doc_ids_by_type: Dict[str, List[int]] = {"policy": [], "kod": [], "procedure": []}
        query = sqlalchemy.text("""
            SELECT document_id
            FROM dbaware_scoping.dbaware_review_documents
            WHERE review_scope_instance_id = :instance_id;
        """)
        try:
            with self.connect_to_database().connect() as connection:
                results = connection.execute(query, {"instance_id": str(instance_id)})
                extracted_ids = [int(row[0]) for row in results if row[0] is not None]
                logger.info(
                    "🔌 Found %d document_id(s) in dbaware_scoping.dbaware_review_documents for review_scope_instance_id=%s: %s",
                    len(extracted_ids), instance_id, extracted_ids
                )
                # Map all retrieved document IDs across governance types for vector search
                for doc_type in doc_ids_by_type:
                    doc_ids_by_type[doc_type] = list(extracted_ids)
            return doc_ids_by_type
        except Exception as e:
            logger.warning(
                "⚠️ Database query failed for instance %s (%s). Falling back to mock scoping data.",
                instance_id,
                str(e),
            )
            fallback = mock_instance_docs.get(instance_id, default_mock_docs)
            return {k: list(v) for k, v in fallback.items()}

    # ------------------------------------------------------------------
    # Liquibase table helpers for document context verification & mutation
    #   - dbaware_scoping.review_scope (PK: review_scope_instance_id VARCHAR(100))
    #   - dbaware_scoping.review_data_extraction (PK: review_scope_dataext_id INTEGER)
    #   - dbaware_scoping.dbaware_review_documents (PK: review_document_instance_id INTEGER)
    #   - dbaware_scoping.review_research_recommendation (PK: review_rr_id INTEGER)
    # ------------------------------------------------------------------

    def _is_mock_mode(self) -> bool:
        if sqlalchemy is None:
            return True
        if os.getenv("MOCK_SCOPING_DB", "true").lower() in ("true", "1", "yes"):
            return True
        return not (self.db_host and self.db_user and self.db_name)

    @staticmethod
    def _default_dataext_pk(instance_id: str, data_source: str) -> int:
        offset = {"policy": 1, "kod": 2, "procedure": 3, "rag_document_metadata": 4}.get(data_source, 9)
        digits = "".join(ch for ch in str(instance_id) if ch.isdigit())
        base = int(digits) * 10 if digits else 1000
        return base + offset

    def _ensure_mock_plan_seeded(self, instance_id: str) -> None:
        inst = str(instance_id).strip()
        if inst not in _MOCK_DATA_EXTRACTION_STORE:
            _MOCK_DATA_EXTRACTION_STORE[inst] = {}
            for ds in ("policy", "kod", "procedure", "rag_document_metadata"):
                pk = self._default_dataext_pk(inst, ds)
                _MOCK_DATA_EXTRACTION_STORE[inst][ds] = {
                    "review_scope_dataext_id": pk,
                    "review_scope_instance_id": inst,
                    "data_source": ds,
                    "metadata": {
                        "context_file": (
                            f"dbaware_review_{inst}/inbound-data/{ds}/relevant_{ds}.json"
                            if ds in ("policy", "kod", "procedure")
                            else f"dbaware_review_{inst}/inbound-data/policy"
                        ),
                        "documents": [],
                    },
                    "table": DATA_EXTRACTION_TABLE,
                }
        if inst not in _MOCK_REVIEW_DOCUMENTS_STORE:
            default_ids = [1, 2, 3, 121, 43, 27, 13, 17, 194]
            base_pk = (int(inst) * 100) if inst.isdigit() else 10000
            _MOCK_REVIEW_DOCUMENTS_STORE[inst] = [
                {
                    "review_document_instance_id": base_pk + idx,
                    "review_scope_instance_id": inst,
                    "document_id": doc_id,
                    "table": REVIEW_DOCUMENTS_TABLE,
                }
                for idx, doc_id in enumerate(default_ids, start=1)
            ]

    def resolve_scope_instance_id(
        self,
        plan_number: str,
        explicit_instance_id: Optional[Any] = None,
    ) -> str:
        """
        Resolves `review_scope_instance_id` (VARCHAR(100) PK on `dbaware_scoping.review_scope`)
        for a given `plan_number` (`review_plan_id` or `review_scope_instance_id`).
        """
        if explicit_instance_id not in (None, ""):
            return str(explicit_instance_id).strip()
        clean_plan = str(plan_number or "").strip()
        if not clean_plan or self._is_mock_mode():
            return clean_plan

        try:
            with self.connect_to_database().connect() as connection:
                if clean_plan.isdigit():
                    row = connection.execute(
                        sqlalchemy.text(
                            f"""
                            SELECT review_scope_instance_id
                            FROM {REVIEW_SCOPE_TABLE}
                            WHERE review_scope_instance_id = :plan_str
                               OR review_plan_id = :plan_int
                            ORDER BY created_on DESC NULLS LAST
                            LIMIT 1
                            """
                        ),
                        {"plan_str": clean_plan, "plan_int": int(clean_plan)},
                    ).first()
                else:
                    row = connection.execute(
                        sqlalchemy.text(
                            f"""
                            SELECT review_scope_instance_id
                            FROM {REVIEW_SCOPE_TABLE}
                            WHERE review_scope_instance_id = :plan_str
                            ORDER BY created_on DESC NULLS LAST
                            LIMIT 1
                            """
                        ),
                        {"plan_str": clean_plan},
                    ).first()
                if row and row[0] is not None:
                    return str(row[0]).strip()
        except Exception as exc:
            logger.debug("Could not resolve review_scope_instance_id from %s for plan %s: %s", REVIEW_SCOPE_TABLE, clean_plan, exc)
        return clean_plan

    def get_data_extraction_rows_for_plan(
        self,
        plan_number: str,
        data_sources: Optional[List[str]] = None,
        review_scope_instance_id: Optional[Any] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Queries `dbaware_scoping.review_data_extraction` for the given plan/scope instance and
        returns a dict keyed by `data_source` ('policy', 'kod', 'procedure', 'rag_document_metadata')
        with the row primary key `review_scope_dataext_id` and `metadata` JSONB.
        """
        sources = list(data_sources or ("policy", "kod", "procedure", "rag_document_metadata"))
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        self._ensure_mock_plan_seeded(instance_id)

        if self._is_mock_mode():
            store = _MOCK_DATA_EXTRACTION_STORE.get(instance_id, {})
            return {ds: dict(store[ds]) for ds in sources if ds in store}

        rows_by_source: Dict[str, Dict[str, Any]] = {}
        try:
            with self.connect_to_database().connect() as connection:
                for ds in sources:
                    row = connection.execute(
                        sqlalchemy.text(
                            f"""
                            SELECT review_scope_dataext_id, review_scope_instance_id, data_source, metadata
                            FROM {DATA_EXTRACTION_TABLE}
                            WHERE review_scope_instance_id = :instance_id
                              AND data_source = :data_source
                            ORDER BY review_scope_dataext_id DESC
                            LIMIT 1
                            """
                        ),
                        {"instance_id": instance_id, "data_source": ds},
                    ).first()
                    if row is not None:
                        meta = row[3]
                        if isinstance(meta, str):
                            try:
                                meta = json.loads(meta)
                            except Exception:
                                pass
                        rows_by_source[ds] = {
                            "review_scope_dataext_id": row[0],
                            "review_scope_instance_id": str(row[1]),
                            "data_source": str(row[2]),
                            "metadata": meta,
                            "table": DATA_EXTRACTION_TABLE,
                        }
            if rows_by_source:
                return rows_by_source
        except Exception as exc:
            logger.warning(
                "Could not query %s for instance %s (%s); using fallback row mapping.",
                DATA_EXTRACTION_TABLE,
                instance_id,
                exc,
            )

        store = _MOCK_DATA_EXTRACTION_STORE.get(instance_id, {})
        return {ds: dict(store[ds]) for ds in sources if ds in store}

    def get_review_document_rows_for_plan(
        self,
        plan_number: str,
        review_scope_instance_id: Optional[Any] = None,
    ) -> List[Dict[str, Any]]:
        """
        Queries `dbaware_scoping.dbaware_review_documents` and returns rows with
        `review_document_instance_id` (PK), `review_scope_instance_id`, and `document_id`.
        """
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        self._ensure_mock_plan_seeded(instance_id)

        if self._is_mock_mode():
            return [dict(r) for r in _MOCK_REVIEW_DOCUMENTS_STORE.get(instance_id, [])]

        try:
            with self.connect_to_database().connect() as connection:
                result = connection.execute(
                    sqlalchemy.text(
                        f"""
                        SELECT review_document_instance_id, review_scope_instance_id, document_id
                        FROM {REVIEW_DOCUMENTS_TABLE}
                        WHERE review_scope_instance_id = :instance_id
                        ORDER BY review_document_instance_id ASC
                        """
                    ),
                    {"instance_id": instance_id},
                )
                return [
                    {
                        "review_document_instance_id": int(r[0]) if r[0] is not None else None,
                        "review_scope_instance_id": str(r[1]),
                        "document_id": int(r[2]) if r[2] is not None else None,
                        "table": REVIEW_DOCUMENTS_TABLE,
                    }
                    for r in result
                ]
        except Exception as exc:
            logger.warning(
                "Could not query %s for instance %s (%s); using fallback rows.",
                REVIEW_DOCUMENTS_TABLE,
                instance_id,
                exc,
            )
            return [dict(r) for r in _MOCK_REVIEW_DOCUMENTS_STORE.get(instance_id, [])]

    def update_data_extraction_row_by_pk(
        self,
        review_scope_dataext_id: Optional[Any],
        plan_number: str,
        data_source: str,
        metadata: Any,
        updated_by: Optional[str] = None,
        remarks: Optional[str] = None,
        review_scope_instance_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Updates (or inserts) the context JSON metadata row in `dbaware_scoping.review_data_extraction`
        by its primary key `review_scope_dataext_id` (or `(review_scope_instance_id, data_source)`).
        """
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        self._ensure_mock_plan_seeded(instance_id)
        pk_int = (
            int(review_scope_dataext_id)
            if review_scope_dataext_id is not None and str(review_scope_dataext_id).isdigit()
            else None
        )

        # Always keep the in-memory fallback store synchronized
        existing_mock = _MOCK_DATA_EXTRACTION_STORE[instance_id].get(data_source) or {}
        resolved_mock_pk = pk_int or existing_mock.get("review_scope_dataext_id") or self._default_dataext_pk(instance_id, data_source)
        _MOCK_DATA_EXTRACTION_STORE[instance_id][data_source] = {
            "review_scope_dataext_id": resolved_mock_pk,
            "review_scope_instance_id": instance_id,
            "data_source": data_source,
            "metadata": metadata,
            "updated_by": updated_by,
            "remarks": remarks,
            "table": DATA_EXTRACTION_TABLE,
        }

        if self._is_mock_mode():
            return {
                "table": DATA_EXTRACTION_TABLE,
                "review_scope_dataext_id": str(resolved_mock_pk),
                "review_scope_instance_id": instance_id,
                "data_source": data_source,
                "operation": "updated",
                "mode": "mock",
            }

        metadata_json = json.dumps(metadata, ensure_ascii=False, default=str)
        try:
            with self.connect_to_database().begin() as connection:
                rowcount = 0
                if pk_int is not None:
                    res = connection.execute(
                        sqlalchemy.text(
                            f"""
                            UPDATE {DATA_EXTRACTION_TABLE}
                            SET metadata = CAST(:metadata AS JSONB),
                                updated_by = :updated_by,
                                updated_on = CURRENT_TIMESTAMP,
                                remarks = COALESCE(:remarks, remarks)
                            WHERE review_scope_dataext_id = :pk
                            """
                        ),
                        {
                            "pk": pk_int,
                            "metadata": metadata_json,
                            "updated_by": updated_by,
                            "remarks": remarks,
                        },
                    )
                    rowcount = int(res.rowcount or 0)

                if rowcount == 0:
                    res = connection.execute(
                        sqlalchemy.text(
                            f"""
                            UPDATE {DATA_EXTRACTION_TABLE}
                            SET metadata = CAST(:metadata AS JSONB),
                                updated_by = :updated_by,
                                updated_on = CURRENT_TIMESTAMP,
                                remarks = COALESCE(:remarks, remarks)
                            WHERE review_scope_instance_id = :instance_id
                              AND data_source = :data_source
                            """
                        ),
                        {
                            "instance_id": instance_id,
                            "data_source": data_source,
                            "metadata": metadata_json,
                            "updated_by": updated_by,
                            "remarks": remarks,
                        },
                    )
                    rowcount = int(res.rowcount or 0)

                if rowcount == 0:
                    ins = connection.execute(
                        sqlalchemy.text(
                            f"""
                            INSERT INTO {DATA_EXTRACTION_TABLE} (
                                review_scope_instance_id,
                                data_source,
                                metadata,
                                created_by,
                                created_on,
                                remarks
                            ) VALUES (
                                :instance_id,
                                :data_source,
                                CAST(:metadata AS JSONB),
                                :created_by,
                                CURRENT_TIMESTAMP,
                                :remarks
                            )
                            RETURNING review_scope_dataext_id
                            """
                        ),
                        {
                            "instance_id": instance_id,
                            "data_source": data_source,
                            "metadata": metadata_json,
                            "created_by": updated_by,
                            "remarks": remarks,
                        },
                    ).first()
                    if ins and ins[0] is not None:
                        pk_int = int(ins[0])
                    operation = "inserted"
                else:
                    operation = "updated"

            return {
                "table": DATA_EXTRACTION_TABLE,
                "review_scope_dataext_id": str(pk_int or resolved_mock_pk),
                "review_scope_instance_id": instance_id,
                "data_source": data_source,
                "operation": operation,
                "mode": "db",
            }
        except Exception as exc:
            logger.warning("Failed to update %s for instance=%s source=%s: %s", DATA_EXTRACTION_TABLE, instance_id, data_source, exc)
            return {
                "table": DATA_EXTRACTION_TABLE,
                "review_scope_dataext_id": str(resolved_mock_pk),
                "review_scope_instance_id": instance_id,
                "data_source": data_source,
                "operation": "fallback_mock",
                "error": str(exc),
            }

    def sync_review_document_reference(
        self,
        plan_number: str,
        action: str,
        document_id: Optional[Any] = None,
        review_scope_instance_id: Optional[Any] = None,
        review_document_instance_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Synchronizes `dbaware_scoping.dbaware_review_documents` when a document is included or excluded:
          - action == 'include': inserts `(review_scope_instance_id, document_id)` if not present
          - action == 'exclude': deletes matching row by `review_document_instance_id` or `(review_scope_instance_id, document_id)`
        """
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        self._ensure_mock_plan_seeded(instance_id)
        norm_action = "exclude" if str(action or "").lower() in {"exclude", "remove", "delete"} else "include"
        doc_id_int = int(document_id) if document_id is not None and str(document_id).lstrip("-").isdigit() else None
        row_pk_int = (
            int(review_document_instance_id)
            if review_document_instance_id is not None and str(review_document_instance_id).isdigit()
            else None
        )

        # Update mock store
        mock_rows = _MOCK_REVIEW_DOCUMENTS_STORE.setdefault(instance_id, [])
        if norm_action == "exclude":
            before = len(mock_rows)
            mock_rows[:] = [
                r for r in mock_rows
                if not (
                    (row_pk_int is not None and r.get("review_document_instance_id") == row_pk_int)
                    or (doc_id_int is not None and r.get("document_id") == doc_id_int)
                )
            ]
            removed_count = before - len(mock_rows)
            mock_result = {
                "table": REVIEW_DOCUMENTS_TABLE,
                "review_scope_instance_id": instance_id,
                "document_id": doc_id_int,
                "review_document_instance_id": row_pk_int,
                "operation": "deleted" if removed_count else "noop",
            }
        else:
            existing = next((r for r in mock_rows if doc_id_int is not None and r.get("document_id") == doc_id_int), None)
            if existing is None and doc_id_int is not None:
                next_pk = max((int(r.get("review_document_instance_id") or 0) for r in mock_rows), default=10000) + 1
                existing = {
                    "review_document_instance_id": next_pk,
                    "review_scope_instance_id": instance_id,
                    "document_id": doc_id_int,
                    "table": REVIEW_DOCUMENTS_TABLE,
                }
                mock_rows.append(existing)
                op = "inserted"
            else:
                op = "exists" if existing else "skipped"
            mock_result = {
                "table": REVIEW_DOCUMENTS_TABLE,
                "review_scope_instance_id": instance_id,
                "document_id": doc_id_int,
                "review_document_instance_id": existing.get("review_document_instance_id") if existing else row_pk_int,
                "operation": op,
            }

        if self._is_mock_mode() or (doc_id_int is None and row_pk_int is None):
            return mock_result

        try:
            with self.connect_to_database().begin() as connection:
                if norm_action == "exclude":
                    if row_pk_int is not None:
                        connection.execute(
                            sqlalchemy.text(
                                f"DELETE FROM {REVIEW_DOCUMENTS_TABLE} WHERE review_document_instance_id = :pk"
                            ),
                            {"pk": row_pk_int},
                        )
                    elif doc_id_int is not None:
                        connection.execute(
                            sqlalchemy.text(
                                f"""
                                DELETE FROM {REVIEW_DOCUMENTS_TABLE}
                                WHERE review_scope_instance_id = :instance_id
                                  AND document_id = :doc_id
                                """
                            ),
                            {"instance_id": instance_id, "doc_id": doc_id_int},
                        )
                    return {**mock_result, "mode": "db"}
                else:
                    if doc_id_int is not None:
                        row = connection.execute(
                            sqlalchemy.text(
                                f"""
                                INSERT INTO {REVIEW_DOCUMENTS_TABLE} (review_scope_instance_id, document_id)
                                SELECT :instance_id, :doc_id
                                WHERE NOT EXISTS (
                                    SELECT 1 FROM {REVIEW_DOCUMENTS_TABLE}
                                    WHERE review_scope_instance_id = :instance_id
                                      AND document_id = :doc_id
                                )
                                RETURNING review_document_instance_id
                                """
                            ),
                            {"instance_id": instance_id, "doc_id": doc_id_int},
                        ).first()
                        if row and row[0] is not None:
                            mock_result["review_document_instance_id"] = int(row[0])
                            mock_result["operation"] = "inserted"
                    return {**mock_result, "mode": "db"}
        except Exception as exc:
            logger.warning("Failed to sync %s for instance=%s action=%s: %s", REVIEW_DOCUMENTS_TABLE, instance_id, norm_action, exc)
            return {**mock_result, "error": str(exc)}

    def upsert_research_recommendation(
        self,
        plan_number: str,
        metadata: Dict[str, Any],
        report_type: str = "preliminary_research",
        updated_by: Optional[str] = None,
        remarks: Optional[str] = None,
        review_scope_instance_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Updates or inserts a row in `dbaware_scoping.review_research_recommendation` (PK: `review_rr_id`)
        when preliminary research or stage recommendations are regenerated.
        """
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        plan_store = _MOCK_RESEARCH_RECOMMENDATION_STORE.setdefault(instance_id, {})
        existing = plan_store.get(report_type)
        rr_id = existing.get("review_rr_id") if existing else (int(instance_id) * 10 + 1 if instance_id.isdigit() else 5001)
        plan_store[report_type] = {
            "review_rr_id": rr_id,
            "review_scope_instance_id": instance_id,
            "report_type": report_type,
            "metadata": metadata,
            "updated_by": updated_by,
            "remarks": remarks,
            "table": RESEARCH_RECOMMENDATION_TABLE,
        }

        if self._is_mock_mode():
            return {
                "table": RESEARCH_RECOMMENDATION_TABLE,
                "review_rr_id": rr_id,
                "review_scope_instance_id": instance_id,
                "report_type": report_type,
                "operation": "updated" if existing else "inserted",
                "mode": "mock",
            }

        metadata_json = json.dumps(metadata, ensure_ascii=False, default=str)
        try:
            with self.connect_to_database().begin() as connection:
                res = connection.execute(
                    sqlalchemy.text(
                        f"""
                        UPDATE {RESEARCH_RECOMMENDATION_TABLE}
                        SET metadata = CAST(:metadata AS JSONB),
                            updated_by = :updated_by,
                            updated_on = CURRENT_TIMESTAMP,
                            remarks = COALESCE(:remarks, remarks)
                        WHERE review_scope_instance_id = :instance_id
                          AND (report_type = :report_type OR report_type IS NULL)
                        """
                    ),
                    {
                        "instance_id": instance_id,
                        "report_type": report_type,
                        "metadata": metadata_json,
                        "updated_by": updated_by,
                        "remarks": remarks,
                    },
                )
                if not res.rowcount:
                    ins = connection.execute(
                        sqlalchemy.text(
                            f"""
                            INSERT INTO {RESEARCH_RECOMMENDATION_TABLE} (
                                review_scope_instance_id,
                                metadata,
                                report_type,
                                created_by,
                                created_on,
                                remarks
                            ) VALUES (
                                :instance_id,
                                CAST(:metadata AS JSONB),
                                :report_type,
                                :created_by,
                                CURRENT_TIMESTAMP,
                                :remarks
                            )
                            RETURNING review_rr_id
                            """
                        ),
                        {
                            "instance_id": instance_id,
                            "report_type": report_type,
                            "metadata": metadata_json,
                            "created_by": updated_by,
                            "remarks": remarks,
                        },
                    ).first()
                    if ins and ins[0] is not None:
                        rr_id = int(ins[0])
                    op = "inserted"
                else:
                    op = "updated"
            return {
                "table": RESEARCH_RECOMMENDATION_TABLE,
                "review_rr_id": rr_id,
                "review_scope_instance_id": instance_id,
                "report_type": report_type,
                "operation": op,
                "mode": "db",
            }
        except Exception as exc:
            logger.warning("Failed to upsert %s for instance=%s: %s", RESEARCH_RECOMMENDATION_TABLE, instance_id, exc)
            return {
                "table": RESEARCH_RECOMMENDATION_TABLE,
                "review_rr_id": rr_id,
                "review_scope_instance_id": instance_id,
                "report_type": report_type,
                "operation": "fallback_mock",
                "error": str(exc),
            }
