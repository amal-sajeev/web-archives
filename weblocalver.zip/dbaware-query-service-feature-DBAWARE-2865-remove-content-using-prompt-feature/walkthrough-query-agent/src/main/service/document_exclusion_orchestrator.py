from typing import Awaitable, Callable, Dict, Optional
import json
import logging
from fastapi import HTTPException
from langchain_core.messages import HumanMessage, SystemMessage

from agent.agent import initialize_gemini_model
from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from service.document_service import _refresh_preliminary_research, _title_similarity_score
from service.request import (
    DocumentCandidate,
    DocumentExclusionPlanAction,
    DocumentExclusionPlanRequest,
    DocumentExclusionPlanResponse,
    DocumentExecutionAction,
    DocumentExecutionRequest,
    DocumentExecutionResponse,
    DocumentExclusionWorkflowRequest,
    DocumentImpactAnalysis,
    DocumentIntentAnalysis,
    DocumentPreliminaryResearchRegenerationRequest,
    DocumentPreliminaryResearchRegenerationResponse,
    DocumentVerificationRequest,
    DocumentVerificationResponse,
    DocumentVerificationResult,
)

logger = logging.getLogger(__name__)

PRIMARY_KEY_FIELDS = ("row_primary_key", "id", "document_id", "review_scope_dataext_id", "record_id")


def _entry_primary_key(entry: dict) -> Optional[str]:
    """Primary key of a registry row, resolved in the same order the verification step uses."""
    if not isinstance(entry, dict):
        return None
    for key in PRIMARY_KEY_FIELDS:
        value = entry.get(key)
        if value is not None:
            return str(value)
    return None


def _resolve_registry_blob_candidates(plan_number: str, document_type: str):
    normalized_type = (document_type or "").strip().lower()
    return [
        f"dbaware_review_{plan_number}/inbound-data/{normalized_type}/relevant_{normalized_type}.json",
        f"dbaware_review_{plan_number}/processing-data/relevant_{normalized_type}.json",
    ]


def _is_valid_registry_payload(payload: object) -> bool:
    if isinstance(payload, list):
        return all(isinstance(item, dict) for item in payload)
    return isinstance(payload, dict) and isinstance(payload.get("documents"), list)


def _resolve_existing_registry_blob(gcs_utils: GCSUtils, plan_number: str, document_type: str) -> str:
    candidates = _resolve_registry_blob_candidates(plan_number, document_type)
    for blob in candidates:
        if not gcs_utils.blob_exists(blob):
            continue
        try:
            payload = gcs_utils.read_blob_json(blob)
            if _is_valid_registry_payload(payload):
                return blob
        except Exception:
            continue
    return candidates[0]


async def verify_document_context_logic(request: DocumentVerificationRequest):
    """Verify candidate documents exist in the active plan context and collect metadata before approval."""
    try:
        logger.info("Verifying candidate documents for plan: %s, candidates=%s", request.plan_number, len(request.candidates))
        env_config = EnvironmentConfig()
        gcs_utils = GCSUtils(env_config)

        verified = []
        unmatched = []

        for candidate in request.candidates:
            doc_type = candidate.document_type or ""
            doc_title = candidate.title or ""
            if not doc_type or doc_title == "":
                unmatched.append(DocumentVerificationResult(
                    document_type=doc_type or None,
                    title=doc_title or None,
                    matched=False,
                    status="invalid_type",
                    reason="Document type or title missing."
                ))
                continue

            normalized_type = doc_type.strip().lower()
            if normalized_type not in {"policy", "kod", "procedure"}:
                unmatched.append(DocumentVerificationResult(
                    document_type=normalized_type,
                    title=doc_title,
                    matched=False,
                    status="invalid_type",
                    reason=f"Unsupported document type '{normalized_type}'."
                ))
                continue

            registry_blob = _resolve_existing_registry_blob(gcs_utils, request.plan_number, normalized_type)
            if not gcs_utils.blob_exists(registry_blob):
                unmatched.append(DocumentVerificationResult(
                    document_type=normalized_type,
                    title=doc_title,
                    matched=False,
                    status="not_found",
                    context_file=registry_blob,
                    reason="Context JSON not found for this plan and document type."
                ))
                continue

            payload = gcs_utils.read_blob_json(registry_blob)
            entries = payload.get("documents", []) if isinstance(payload, dict) else payload if isinstance(payload, list) else []
            if not _is_valid_registry_payload(payload):
                unmatched.append(DocumentVerificationResult(
                    document_type=normalized_type,
                    title=doc_title,
                    matched=False,
                    status="not_found",
                    context_file=registry_blob,
                    reason="Context blob exists but does not contain a valid document registry payload."
                ))
                continue

            matches = []
            target = doc_title.strip()
            for item in entries:
                if not isinstance(item, dict):
                    continue
                values = [
                    str(item.get("document_title", "")),
                    str(item.get("title", "")),
                    str(item.get("document_name", "")),
                    str(item.get("name", "")),
                    str(item.get("document_id", "")),
                ]
                best_score = 0.0
                for value in values:
                    if not value:
                        continue
                    score = _title_similarity_score(target, value)
                    if score > best_score:
                        best_score = score
                if best_score >= 0.55:
                    matches.append({"item": item, "score": best_score})

            if len(matches) == 0:
                best_suggestion = None
                best_suggestion_score = 0.0
                for item in entries:
                    if not isinstance(item, dict):
                        continue
                    values = [
                        str(item.get("document_title", "")),
                        str(item.get("title", "")),
                        str(item.get("document_name", "")),
                        str(item.get("name", "")),
                        str(item.get("document_id", "")),
                    ]
                    for value in values:
                        if not value:
                            continue
                        score = _title_similarity_score(target, value)
                        if score > best_suggestion_score:
                            best_suggestion_score = score
                            best_suggestion = value

                unmatched.append(DocumentVerificationResult(
                    document_type=normalized_type,
                    title=doc_title,
                    matched=False,
                    status="not_found",
                    context_file=registry_blob,
                    reason=(f"Document not found in active context JSON. Closest match: {best_suggestion}" if best_suggestion else "Document not found in active context JSON.")
                ))
                continue

            matches = sorted(matches, key=lambda x: x["score"], reverse=True)
            selected = matches[0]["item"]
            primary_key = None
            for key in ("row_primary_key", "id", "document_id", "review_scope_dataext_id", "record_id"):
                value = selected.get(key)
                if value is not None:
                    primary_key = str(value)
                    break

            verified.append(DocumentVerificationResult(
                document_type=normalized_type,
                title=str(selected.get("document_title") or selected.get("title") or selected.get("name") or doc_title),
                matched=True,
                status="verified",
                context_file=registry_blob,
                row_primary_key=primary_key,
                reason=f"Matched active context registry entry using natural-language similarity (score={matches[0]['score']})."
            ))

        return DocumentVerificationResponse(
            plan_number=request.plan_number,
            action=request.action,
            verified_documents=verified,
            unmatched_documents=unmatched,
            message="Verification completed against active plan context.",
        )
    except Exception as exc:
        logger.exception("Document context verification failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(exc)}")


def build_intent_analysis(request: DocumentExclusionWorkflowRequest) -> DocumentIntentAnalysis:
    """Create the lightweight LLM-style intent analysis for the workflow."""
    candidate = request.candidates[0] if request.candidates else None
    return DocumentIntentAnalysis(
        action=request.action or "exclude",
        document_type=getattr(candidate, "document_type", None) if candidate else None,
        title=getattr(candidate, "title", None) if candidate else None,
        plan_number=request.plan_number,
        scope="all_related",
        reasoning=(
            "Natural-language intent was inferred by the orchestration layer. "
            "Backend verification will confirm the exact runtime document and metadata before mutation."
        ),
        impact_analysis=DocumentImpactAnalysis(
            affected_artifacts=[
                f"dbaware_review_{request.plan_number}/inbound-data",
                f"dbaware_review_{request.plan_number}/processing-data/preliminary-research",
            ],
            downstream_jobs=["preliminary_research_refresh", "dependent_review_jobs"],
            reasoning=(
                "Removing a document changes the active plan registry and any derived research summary "
                "that was generated from that registry."
            ),
            confidence=0.9,
        ),
        requires_approval=True,
    )


async def build_document_exclusion_plan_logic(request: DocumentExclusionPlanRequest):
    """Create the user-facing plan of approved exclusion actions based on verified context."""
    try:
        actions = []
        for item in request.verified_documents:
            if not item.matched or not item.document_type or not item.title:
                continue
            actions.append(DocumentExclusionPlanAction(
                action=request.action,
                document_type=item.document_type,
                title=item.title,
                context_file=item.context_file,
                row_primary_key=item.row_primary_key,
                scope="all_related",
            ))

        if not actions:
            raise HTTPException(status_code=400, detail="No verified actions available to build a plan.")

        return DocumentExclusionPlanResponse(
            plan_number=request.plan_number,
            action=request.action,
            actions=actions,
            message="Action plan was generated from the verified active context.",
            requires_approval=True,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Exclusion plan creation failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Plan creation failed: {str(exc)}")


async def execute_document_exclusion_plan_logic(request: DocumentExecutionRequest):
    """Run the approved action plan against the active runtime context and regenerate the PR via LLM-first flow."""
    try:
        logger.info("Executing approved exclusion plan for plan: %s, actions=%s", request.plan_number, len(request.actions))

        env_config = EnvironmentConfig()
        gcs_utils = GCSUtils(env_config)
        executed = []
        registry_updated = False
        report_refreshed = False
        refresh_error = None

        for action in request.actions:
            if not action.document_type or not action.title:
                continue
            normalized_type = action.document_type.strip().lower()
            if normalized_type not in {"policy", "kod", "procedure"}:
                continue

            registry_blob = _resolve_existing_registry_blob(gcs_utils, request.plan_number, normalized_type)
            if gcs_utils.blob_exists(registry_blob):
                payload = gcs_utils.read_blob_json(registry_blob)
                entries = payload.get("documents", []) if isinstance(payload, dict) else payload if isinstance(payload, list) else []
                if _is_valid_registry_payload(payload):
                    updated_entries = []
                    mutated = False
                    for entry in entries:
                        if not isinstance(entry, dict):
                            updated_entries.append(entry)
                            continue
                        current_title = str(entry.get("document_title") or entry.get("title") or entry.get("name") or "")
                        entry_pk = _entry_primary_key(entry)
                        pk_match = bool(action.row_primary_key) and entry_pk is not None and entry_pk == str(action.row_primary_key)
                        if pk_match or current_title.lower() == action.title.strip().lower():
                            entry_copy = dict(entry)
                            entry_copy["status"] = "removed"
                            entry_copy["excluded"] = True
                            entry_copy["removed_at"] = "approved_execution"
                            entry_copy["removed_by"] = request.approved_by or "approved_plan"
                            updated_entries.append(entry_copy)
                            mutated = True
                        else:
                            updated_entries.append(entry)
                    if mutated:
                        if isinstance(payload, dict):
                            payload["documents"] = updated_entries
                            gcs_utils.write_blob_json(registry_blob, payload)
                        elif isinstance(payload, list):
                            gcs_utils.write_blob_json(registry_blob, updated_entries)
                        registry_updated = True

            if request.trigger_preliminary_research:
                try:
                    llm_generated = await _generate_and_persist_preliminary_research(
                        request.plan_number,
                        [{"document_type": action.document_type, "title": action.title}],
                        reason=f"Document excluded: {action.title}",
                    )
                    report_refreshed = bool(llm_generated.get("report_path"))
                    logger.info("LLM generated preliminary research artifact for plan=%s at %s", request.plan_number, llm_generated.get("report_path"))
                except Exception as exc:
                    refresh_error = str(exc)
                    logger.exception("LLM preliminary research regeneration failed for plan=%s after exclusion execution", request.plan_number)
                    try:
                        refreshed_dir = await _refresh_preliminary_research(request.plan_number, gcs_utils)
                        report_refreshed = bool(refreshed_dir)
                    except Exception as fallback_exc:
                        refresh_error = f"{exc}; fallback_error={fallback_exc}"
                        report_refreshed = False
            else:
                report_refreshed = False

            executed.append(action)

        if not executed:
            return DocumentExecutionResponse(
                plan_number=request.plan_number,
                status="error",
                message="No valid actions were executed.",
                executed=[],
                registry_updated=False,
                report_refreshed=False,
                audit={
                    "approved_by": request.approved_by,
                    "total_actions": 0,
                    "registry_blob_prefix": f"dbaware_review_{request.plan_number}/inbound-data",
                    "report_refresh_error": refresh_error,
                },
            )

        status_value = "success"
        message = "Approved exclusion plan executed against active context."
        if registry_updated is False:
            status_value = "error"
            message = "Approved exclusion plan was processed, but no registry entries were updated."
        elif report_refreshed is False:
            status_value = "partial_failure"
            message = "Approved exclusion plan executed, but preliminary research refresh failed."

        return DocumentExecutionResponse(
            plan_number=request.plan_number,
            status=status_value,
            message=message,
            executed=executed,
            registry_updated=registry_updated,
            report_refreshed=report_refreshed,
            audit={
                "approved_by": request.approved_by,
                "total_actions": len(executed),
                "registry_blob_prefix": f"dbaware_review_{request.plan_number}/inbound-data/{request.actions[0].document_type if request.actions else 'unknown'}",
                "report_refresh_error": refresh_error,
            },
        )
    except Exception as exc:
        logger.exception("Approved exclusion execution failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Execution failed: {str(exc)}")


def _extract_response_text(response) -> str:
    text_attr = getattr(response, "text", None)
    if isinstance(text_attr, str) and text_attr.strip():
        return text_attr
    content = getattr(response, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and "text" in item:
                parts.append(str(item["text"]))
            elif hasattr(item, "text") and isinstance(item.text, str):
                parts.append(item.text)
            else:
                parts.append(str(item))
        return "".join(parts)
    return str(content) if content is not None else ""


async def _llm_generate_preliminary_research(plan_number: str, removed_documents: list, reason: str = "document exclusion") -> dict:
    env_config = EnvironmentConfig()
    llm = initialize_gemini_model(env_config)
    removed_summary = "\n".join(
        f"- {item.get('document_type', 'unknown')}: {item.get('title', 'unknown')}" if isinstance(item, dict) else str(item)
        for item in removed_documents
    ) or "- none"

    prompt = f"""
You are generating the refreshed preliminary research artifact for plan {plan_number} after document exclusions.

Business rule:
- The output must be valid JSON only.
- The JSON must contain a top-level object with keys: plan_number, status, last_refreshed_at, metadata, sections.
- The sections key must contain at least: past_review, policy_regulation, broad_scope.
- The document removal reason is: {reason}
- Removed documents:
{removed_summary}

Instruction:
- Keep the content relevant to the active plan after removing the listed documents.
- Do not include markdown fences, comments, or prose outside JSON.
- Keep the JSON structure concise but realistic and usable by downstream systems.
- Generate a safe, valid preliminary research object that reflects the post-removal state.
"""

    messages = [
        SystemMessage(content="You are a document-research orchestrator that returns strict JSON only."),
        HumanMessage(content=prompt),
    ]
    response = llm.invoke(messages)
    content = _extract_response_text(response).strip()
    if not content:
        raise ValueError("LLM returned empty response for preliminary research regeneration.")

    try:
        cleaned = content.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`\n ")
            if cleaned.lower().startswith("json"):
                cleaned = cleaned[4:].lstrip()
        payload = json.loads(cleaned)
    except Exception as exc:
        raise ValueError(f"LLM preliminary research regeneration did not return valid JSON: {exc}") from exc

    if not isinstance(payload, dict):
        raise ValueError("LLM preliminary research regeneration payload must be a JSON object.")

    payload.setdefault("plan_number", plan_number)
    payload.setdefault("status", "refreshed")
    payload.setdefault("last_refreshed_at", "llm_generated_refresh")
    payload.setdefault("metadata", {})
    payload["metadata"].setdefault("plan_number", plan_number)
    payload["metadata"].setdefault("refresh_reason", reason)
    payload.setdefault("sections", {})
    for key in ["past_review", "policy_regulation", "broad_scope"]:
        payload["sections"].setdefault(key, {"summary": f"Updated {key} section after exclusion."})
    return payload


async def _persist_llm_generated_preliminary_research(plan_number: str, payload: dict) -> str:
    env_config = EnvironmentConfig()
    gcs_utils = GCSUtils(env_config)
    prelim_dir = f"dbaware_review_{plan_number}/processing-data/preliminary-research"
    report_path = f"{prelim_dir}/preliminary-research.json"
    gcs_utils.write_blob_json(report_path, payload)
    return report_path


async def _generate_and_persist_preliminary_research(plan_number: str, removed_documents: list, reason: str = "document exclusion") -> dict:
    generated_payload = await _llm_generate_preliminary_research(plan_number, removed_documents, reason)
    report_path = await _persist_llm_generated_preliminary_research(plan_number, generated_payload)
    generated_payload["report_path"] = report_path
    generated_payload["source"] = "llm_generated"
    return generated_payload


async def regenerate_preliminary_research_logic(request: DocumentPreliminaryResearchRegenerationRequest):
    """LLM-first regeneration of the preliminary research artifact for the plan."""
    try:
        generated_payload = await _llm_generate_preliminary_research(
            request.plan_number,
            [{"document_type": request.action, "title": request.reason or request.action}],
            reason=request.reason or request.action,
        )
        report_path = await _persist_llm_generated_preliminary_research(request.plan_number, generated_payload)
        generated_payload["report_path"] = report_path
        generated_payload["source"] = "llm_generated"
        return DocumentPreliminaryResearchRegenerationResponse(
            plan_number=request.plan_number,
            status="success",
            message="Preliminary research artifact was regenerated by the LLM-first orchestrator.",
            report_path=report_path,
            refreshed=True,
            files_updated=[report_path],
        )
    except Exception as exc:
        logger.exception("Preliminary research regeneration failed for plan=%s: %s", request.plan_number, exc)
        raise HTTPException(status_code=500, detail=f"Preliminary research regeneration failed: {str(exc)}")


async def orchestrate_document_exclusion_workflow(
    request: DocumentExclusionWorkflowRequest,
    verify_fn: Optional[Callable[..., Awaitable[object]]] = None,
    plan_fn: Optional[Callable[..., Awaitable[object]]] = None,
    execute_fn: Optional[Callable[..., Awaitable[object]]] = None,
) -> Dict[str, object]:
    """Simple orchestrator: intent -> verify -> plan -> execute.

    This keeps the workflow readable and avoids scattering orchestration logic in the router.
    """
    verify_fn = verify_fn or (lambda req: None)
    plan_fn = plan_fn or (lambda req: None)
    execute_fn = execute_fn or (lambda req: None)

    parsed_intent = build_intent_analysis(request)

    candidates = request.candidates
    if not candidates and request.user_text:
        candidates = [DocumentCandidate(document_type="policy", title=request.user_text)]

    verification_req = DocumentVerificationRequest(
        plan_number=request.plan_number,
        action=request.action,
        candidates=candidates,
        user_text=request.user_text,
        approved_by=request.approved_by,
        approved=request.approved,
    )
    verification = await verify_fn(verification_req)

    plan_req = DocumentExclusionPlanRequest(
        plan_number=request.plan_number,
        user_text=request.user_text or "document exclusion request",
        action=request.action,
        verified_documents=verification.verified_documents,
    )
    plan = await plan_fn(plan_req)

    if not plan.actions:
        return {
            "plan_number": request.plan_number,
            "status": "approval_required",
            "requires_approval": True,
            "message": "No verified documents were found for approval.",
            "intent": parsed_intent.model_dump(mode="json"),
            "verification": verification.model_dump(mode="json"),
            "plan": plan.model_dump(mode="json"),
        }

    if not request.approved and not request.approved_by:
        return {
            "plan_number": request.plan_number,
            "status": "approval_required",
            "requires_approval": True,
            "message": "Approval is required before backend execution.",
            "intent": parsed_intent.model_dump(mode="json"),
            "verification": verification.model_dump(mode="json"),
            "plan": plan.model_dump(mode="json"),
        }

    execution_actions = [
        DocumentExecutionAction(
            action=item.action,
            document_type=item.document_type,
            title=item.title,
            context_file=item.context_file,
            row_primary_key=item.row_primary_key,
            scope=item.scope,
        )
        for item in plan.actions
    ]

    execution_req = DocumentExecutionRequest(
        plan_number=request.plan_number,
        actions=execution_actions,
        approved_by=request.approved_by or "llm_orchestrator",
        trigger_preliminary_research=True,
    )
    execution = await execute_fn(execution_req)

    return {
        "plan_number": request.plan_number,
        "status": "success",
        "requires_approval": False,
        "message": "Intent understood, impact assessed, and the staged workflow completed successfully.",
        "intent": parsed_intent.model_dump(mode="json"),
        "verification": verification.model_dump(mode="json"),
        "plan": plan.model_dump(mode="json"),
        "execution": execution.model_dump(mode="json"),
    }
