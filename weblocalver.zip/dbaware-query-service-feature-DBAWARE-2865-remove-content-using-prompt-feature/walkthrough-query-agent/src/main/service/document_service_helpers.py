import json
import logging
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from google.api_core.exceptions import NotFound

logger = logging.getLogger(__name__)

VALID_DOCUMENT_TYPES = {"policy", "kod", "procedure"}
REGISTRY_FILES = {
    "policy": "relevant_policy.json",
    "kod": "relevant_kod.json",
    "procedure": "relevant_procedure.json",
}
PRELIMINARY_RESEARCH_PREFIX = "dbaware_review_{plan_number}/processing-data/preliminary-research"


class DocumentManagementError(Exception):
    """Base exception for document-management failures."""


class InvalidDocumentTypeError(DocumentManagementError):
    """Raised when a requested document type is unsupported or malformed."""


class DocumentNotFoundError(DocumentManagementError):
    """Raised when a registry entry or blob cannot be located."""


class AmbiguousDeleteRequestError(DocumentManagementError):
    """Raised when a removal request matches multiple documents."""


class MultipleDocumentMatchesError(DocumentManagementError):
    """Raised when a natural-language request resolves to multiple candidate documents."""


class PartialDeleteFailureError(DocumentManagementError):
    """Raised when a delete succeeds in registry but downstream mutation fails."""


class ReportRegenerationError(DocumentManagementError):
    """Raised when runtime report artifacts cannot be refreshed."""


def _normalize_document_type(document_type: Optional[str]) -> str:
    normalized = (document_type or "").strip().lower()
    if normalized not in VALID_DOCUMENT_TYPES:
        raise InvalidDocumentTypeError(f"Unsupported document_type '{document_type}'. Expected one of: {sorted(VALID_DOCUMENT_TYPES)}")
    return normalized


def _normalize_text_for_match(value: Optional[str]) -> str:
    if value is None:
        return ""
    text = str(value)
    text = text.replace("_", " ").replace("-", " ").replace("/", " ")
    text = text.replace("@", " ")
    text = re.sub(r"[^a-zA-Z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text.lower()).strip()
    return text


def _tokenize_for_match(value: Optional[str]) -> List[str]:
    text = _normalize_text_for_match(value)
    if not text:
        return []
    stop_words = {
        "a", "an", "and", "as", "at", "be", "by", "for", "from", "in", "is", "it",
        "of", "on", "or", "that", "the", "this", "to", "was", "were", "with", "within",
        "remove", "delete", "exclude", "omit", "discard", "add", "include", "upload",
        "attach", "insert", "restore", "policy", "kod", "procedure",
        "document", "documents", "manual", "compliance", "report", "review", "global", "act"
    }
    return [token for token in text.split() if token and token not in stop_words]


def _title_similarity_score(query: str, candidate: str) -> float:
    query_norm = _normalize_text_for_match(query)
    candidate_norm = _normalize_text_for_match(candidate)
    if not query_norm or not candidate_norm:
        return 0.0

    if query_norm == candidate_norm:
        return 1.0

    if query_norm in candidate_norm or candidate_norm in query_norm:
        return 0.9

    query_tokens = _tokenize_for_match(query_norm)
    candidate_tokens = _tokenize_for_match(candidate_norm)
    if not query_tokens or not candidate_tokens:
        return 0.0

    overlap = set(query_tokens) & set(candidate_tokens)
    if not overlap:
        for q in query_tokens:
            if q in candidate_norm:
                overlap.add(q)

    if not overlap:
        return 0.0

    overlap_ratio = len(overlap) / max(1, min(len(query_tokens), len(candidate_tokens)))
    coverage = len(overlap) / max(1, len(query_tokens))
    if len(overlap) >= 2 and (overlap_ratio >= 0.5 or coverage >= 0.7):
        return round(max(overlap_ratio, coverage), 3)

    if len(query_tokens) <= 2 and overlap:
        return round(min(0.8, max(overlap_ratio, coverage)), 3)

    return 0.0


def _normalize_title(title: Optional[str]) -> str:
    if not title:
        return ""
    return re.sub(r"\s+", " ", title).strip()


def _slugify_title(value: str) -> str:
    if not value:
        return ""
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip())
    return cleaned.strip("_").lower()


def _registry_blob_path(plan_number: str, document_type: str) -> str:
    return f"dbaware_review_{plan_number}/inbound-data/{document_type}/relevant_{document_type}.json"


def _registry_blob_candidates(plan_number: str, document_type: str) -> List[str]:
    normalized_type = _normalize_document_type(document_type)
    return [
        f"dbaware_review_{plan_number}/inbound-data/{normalized_type}/relevant_{normalized_type}.json",
        f"dbaware_review_{plan_number}/processing-data/relevant_{normalized_type}.json",
    ]


async def _read_json_blob(gcs_utils: GCSUtils, blob_path: str) -> Any:
    if not gcs_utils.blob_exists(blob_path):
        raise FileNotFoundError(f"Blob not found: {blob_path}")
    data = gcs_utils.read_blob_json(blob_path)
    if isinstance(data, str):
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return {"raw": data}
    return data


def _match_document_entries(entries: List[Dict[str, Any]], target_title: str) -> List[Dict[str, Any]]:
    if not isinstance(entries, list):
        return []

    normalized_target = _normalize_title(target_title)
    if not normalized_target:
        return []

    target_query = _normalize_text_for_match(normalized_target)
    matches = []
    for item in entries:
        if not isinstance(item, dict):
            continue
        candidate_values = [
            str(item.get("document_title", "")),
            str(item.get("title", "")),
            str(item.get("document_name", "")),
            str(item.get("name", "")),
            str(item.get("id", "")),
            str(item.get("document_id", "")),
        ]
        for value in candidate_values:
            score = _title_similarity_score(target_query, value)
            if score >= 0.55:
                matches.append(item)
                break

    return matches


def _find_registry_document(registry_payload: Any, title: str) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]], str]:
    if isinstance(registry_payload, dict):
        entries = registry_payload.get("documents", []) if isinstance(registry_payload.get("documents", []), list) else []
    elif isinstance(registry_payload, list):
        entries = registry_payload
    else:
        entries = []

    matches = _match_document_entries(entries, title)
    if not matches:
        return None, entries, "no_match"
    if len(matches) > 1:
        return None, matches, "ambiguous"
    return matches[0], matches, "exact"


async def _mark_registry_document_removed(plan_number: str, document_type: str, target_title: str, gcs_utils: GCSUtils) -> Dict[str, Any]:
    blob_path = _registry_blob_path(plan_number, document_type)
    registry_payload = await _read_json_blob(gcs_utils, blob_path)

    if isinstance(registry_payload, dict):
        document_entries = registry_payload.get("documents", []) if isinstance(registry_payload.get("documents", []), list) else []
        active_payload = registry_payload
    elif isinstance(registry_payload, list):
        document_entries = registry_payload
        active_payload = {"documents": registry_payload}
    else:
        raise DocumentNotFoundError(f"Registry payload for plan {plan_number} type {document_type} is not a supported list or dictionary")

    item, matches, state = _find_registry_document(registry_payload, target_title)

    if state == "no_match":
        raise DocumentNotFoundError(f"Document '{target_title}' not found in active {document_type} registry for plan {plan_number}")
    if state == "ambiguous":
        suggestions = [str(m.get("document_title") or m.get("title") or m.get("document_name") or m.get("name") or m.get("id", "")) for m in matches if isinstance(m, dict)]
        raise AmbiguousDeleteRequestError(f"Multiple matches found for '{target_title}' in {document_type} registry. Please confirm one of: {suggestions}")

    item_id = item.get("document_id") or item.get("id") or _slugify_title(str(item.get("document_title") or item.get("title") or item.get("name") or target_title))
    updated_entries = []
    for entry in document_entries:
        if not isinstance(entry, dict):
            updated_entries.append(entry)
            continue
        current_id = entry.get("document_id") or entry.get("id") or _slugify_title(str(entry.get("document_title") or entry.get("title") or entry.get("name") or ""))
        if current_id == item_id:
            entry_copy = dict(entry)
            entry_copy["status"] = "removed"
            entry_copy["excluded"] = True
            entry_copy["removed_at"] = "soft-delete"
            entry_copy["removed_by"] = "document_management"
            updated_entries.append(entry_copy)
        else:
            updated_entries.append(entry)

    if not updated_entries and isinstance(document_entries, list):
        raise DocumentNotFoundError(f"Document '{target_title}' was not found in the registry payload for plan {plan_number}")

    if isinstance(active_payload, dict):
        active_payload["documents"] = updated_entries
        gcs_utils.write_blob_json(blob_path, active_payload)
    else:
        gcs_utils.write_blob_json(blob_path, updated_entries)

    return {
        "blob_path": blob_path,
        "plan_number": plan_number,
        "document_type": document_type,
        "matched_title": str(item.get("document_title") or item.get("title") or item.get("name") or target_title),
        "document_id": item_id,
    }


async def _refresh_preliminary_research(plan_number: str, gcs_utils: GCSUtils) -> str:
    prelim_dir = PRELIMINARY_RESEARCH_PREFIX.format(plan_number=plan_number)
    candidates = [
        "past_review.json",
        "policy_regulation.json",
        "broad_scope.json",
        "preliminary-research.json",
    ]

    existing = []
    collected_payloads: Dict[str, Any] = {}
    for filename in candidates:
        blob_path = f"{prelim_dir}/{filename}"
        if gcs_utils.blob_exists(blob_path):
            existing.append(blob_path)
            try:
                payload = gcs_utils.read_blob_json(blob_path)
                collected_payloads[filename] = payload
            except Exception:
                continue

    excluded_titles = await _load_excluded_titles_for_plan(plan_number, gcs_utils)
    if not existing:
        raise ReportRegenerationError(f"No preliminary research artifacts found for plan {plan_number} to refresh.")

    for blob_path in existing:
        payload = gcs_utils.read_blob_json(blob_path)
        filtered_payload = _filter_excluded_content(payload, excluded_titles)
        if isinstance(filtered_payload, dict):
            payload = filtered_payload
            payload["status"] = payload.get("status", "refreshed")
            payload["last_refreshed_at"] = "document_management_refresh"
            payload["metadata"] = {**payload.get("metadata", {}), "plan_number": plan_number, "refresh_reason": "document_removed"}
        else:
            payload = {
                "data": filtered_payload,
                "status": "refreshed",
                "last_refreshed_at": "document_management_refresh",
                "metadata": {"plan_number": plan_number, "refresh_reason": "document_removed"},
            }
        gcs_utils.write_blob_json(blob_path, payload)

    combined_payload: Dict[str, Any] = {
        "plan_number": plan_number,
        "status": "refreshed",
        "last_refreshed_at": "document_management_refresh",
        "metadata": {"plan_number": plan_number, "refresh_reason": "document_removed"},
        "sections": {},
    }

    for filename, payload in collected_payloads.items():
        filtered_payload = _filter_excluded_content(payload, excluded_titles)
        if filename == "preliminary-research.json":
            if isinstance(filtered_payload, dict):
                combined_payload.update(filtered_payload)
                if "sections" in filtered_payload and isinstance(filtered_payload["sections"], dict):
                    combined_payload["sections"].update(filtered_payload["sections"])
            continue
        normalized_name = filename.replace(".json", "")
        combined_payload["sections"][normalized_name] = filtered_payload
        combined_payload[normalized_name] = filtered_payload

    legacy_path = f"{prelim_dir}/preliminary-research.json"
    existing_legacy_payload = None
    if gcs_utils.blob_exists(legacy_path):
        try:
            existing_legacy_payload = gcs_utils.read_blob_json(legacy_path)
        except Exception:
            existing_legacy_payload = None

    if isinstance(existing_legacy_payload, dict):
        existing_legacy_payload.update(combined_payload)
        gcs_utils.write_blob_json(legacy_path, existing_legacy_payload)
    else:
        gcs_utils.write_blob_json(legacy_path, combined_payload)

    return prelim_dir


def _extract_title_from_command(command: str, document_type: Optional[str] = None) -> str:
    """Extract a clean document title from a natural-language removal request."""
    text = re.sub(r"\s+", " ", (command or "").strip())
    if not text:
        return ""

    lowered = text.lower()
    if "@" in text:
        text = text.split("@", 1)[1].strip()

    if document_type:
        doc_keyword = document_type.lower()
        if doc_keyword in lowered:
            idx = lowered.find(doc_keyword)
            text = text[idx + len(doc_keyword):].strip()

    text = re.sub(
        r"^(?:remove|delete|exclude|omit|withdraw|discard|take\s+out)\b\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )
    text = text.replace("-", " ")
    text = re.sub(r"^(for|from|of|on|the|this|that)\b", "", text, flags=re.IGNORECASE)
    text = re.sub(r"[\t\n\r]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip(" ,;:.-")
    return text


async def parse_document_removal_intent(
    user_command: str,
    plan_number: Optional[str] = None,
    document_type: Optional[str] = None,
    title: Optional[str] = None,
    env_config: Optional[EnvironmentConfig] = None,
) -> Dict[str, Any]:
    """Parse a natural language deletion request into a structured plan/type/title payload."""
    normalized_command = (user_command or "").strip()
    normalized_title = _normalize_title(title)
    parsed_type = (document_type or "").strip().lower() if document_type else None

    if not normalized_command and not normalized_title:
        raise ValueError("Document removal request requires a command or document title.")

    if parsed_type:
        try:
            parsed_type = _normalize_document_type(parsed_type)
        except InvalidDocumentTypeError:
            parsed_type = None

    lowered_command = normalized_command.lower()
    if not parsed_type:
        for dtype in ("policy", "kod", "procedure"):
            if dtype in lowered_command:
                parsed_type = dtype
                break

    if parsed_type is None:
        raise InvalidDocumentTypeError("Could not infer a valid document_type from the request. Use policy, kod, or procedure.")

    extracted_title = normalized_title or _extract_title_from_command(normalized_command, parsed_type)
    if not extracted_title:
        raise ValueError("Unable to extract a meaningful document title from the removal request.")

    final_plan_number = str(plan_number).strip() if plan_number else None
    if not final_plan_number and "plan" in lowered_command:
        match = re.search(r"plan\s*[:#-]?\s*(\d+)", normalized_command, flags=re.IGNORECASE)
        if match:
            final_plan_number = match.group(1)

    return {
        "action": "remove",
        "document_type": parsed_type,
        "title": extracted_title,
        "plan_number": final_plan_number,
        "scope": "all_related",
    }


def _validate_removal_intent_payload(intent_payload: Dict[str, Any]) -> Dict[str, Any]:
    """Validate and normalize a structured LLM intent payload before executing backend mutation."""
    if not isinstance(intent_payload, dict):
        raise ValueError("Document removal intent must be a JSON object.")

    if intent_payload.get("status") == "error":
        raise ValueError(intent_payload.get("reason") or "Document removal request rejected by the model.")

    action = (intent_payload.get("action") or "").strip().lower()
    if action != "remove":
        raise InvalidDocumentTypeError(f"Unsupported action '{action}'. Only 'remove' is permitted.")

    document_type = (intent_payload.get("document_type") or "").strip().lower()
    try:
        normalized_type = _normalize_document_type(document_type)
    except InvalidDocumentTypeError as exc:
        raise InvalidDocumentTypeError(f"Invalid document type in intent payload: {document_type}") from exc

    title = _normalize_title(intent_payload.get("title"))
    if not title:
        raise ValueError("Document title is required in the intent payload.")

    plan_number = str(intent_payload.get("plan_number") or "").strip()
    if not plan_number:
        raise ValueError("Plan number is required in the intent payload.")

    return {
        "action": "remove",
        "document_type": normalized_type,
        "title": title,
        "plan_number": plan_number,
        "scope": "all_related",
    }


def _value_mentions_excluded_title(value: Any, excluded_titles: Set[str]) -> bool:
    if not excluded_titles or value is None:
        return False
    if isinstance(value, str):
        text = _normalize_text_for_match(value)
        for title in excluded_titles:
            normalized_title = _normalize_text_for_match(title)
            if not normalized_title:
                continue
            if normalized_title in text or text in normalized_title:
                return True
            if _title_similarity_score(text, normalized_title) >= 0.75:
                return True
        return False
    if isinstance(value, list):
        return any(_value_mentions_excluded_title(item, excluded_titles) for item in value)
    if isinstance(value, dict):
        return any(_value_mentions_excluded_title(item, excluded_titles) for item in value.values())
    return False


def _filter_excluded_content(payload: Any, excluded_titles: Set[str]) -> Any:
    if not excluded_titles:
        return payload

    if isinstance(payload, list):
        filtered = []
        for item in payload:
            if _value_mentions_excluded_title(item, excluded_titles):
                continue
            filtered.append(_filter_excluded_content(item, excluded_titles))
        return filtered

    if isinstance(payload, dict):
        filtered_dict = {}
        for key, value in payload.items():
            if isinstance(value, (dict, list)):
                filtered_value = _filter_excluded_content(value, excluded_titles)
            else:
                filtered_value = value
            if key in {"paragraphs", "items", "documents", "sections", "supporting_citations", "historical_reviews"} and isinstance(filtered_value, list):
                if key == "paragraphs":
                    filtered_dict[key] = [
                        item for item in filtered_value if not _value_mentions_excluded_title(item, excluded_titles)
                    ]
                    continue
                filtered_dict[key] = filtered_value
                continue
            filtered_dict[key] = filtered_value
        return filtered_dict

    return payload


async def _load_excluded_titles_for_plan(plan_number: str, gcs_utils: GCSUtils) -> Set[str]:
    excluded_titles: Set[str] = set()
    for document_type in sorted(VALID_DOCUMENT_TYPES):
        registry_path = _registry_blob_path(plan_number, document_type)
        try:
            payload = await _read_json_blob(gcs_utils, registry_path)
        except FileNotFoundError:
            continue
        except Exception:
            continue

        entries = []
        if isinstance(payload, dict):
            entries = payload.get("documents", []) if isinstance(payload.get("documents", []), list) else []
        elif isinstance(payload, list):
            entries = payload

        for entry in entries:
            if not isinstance(entry, dict):
                continue
            if entry.get("status") == "removed" or entry.get("excluded") is True:
                title = str(entry.get("document_title") or entry.get("title") or entry.get("document_name") or entry.get("name") or "").strip()
                if title:
                    excluded_titles.add(title)
    return excluded_titles


async def manage_document_removal(
    plan_number: str,
    document_type: str,
    title: str,
    env_config: EnvironmentConfig,
    scope: str = "all_related",
) -> Dict[str, Any]:
    """Marks a document as removed in the plan registry and refreshes preliminary research artifacts."""
    normalized_type = _normalize_document_type(document_type)
    clean_title = _normalize_title(title)
    if not clean_title:
        raise ValueError("Document title is required for removal.")

    gcs_utils = GCSUtils(env_config)
    registry_result = await _mark_registry_document_removed(
        plan_number=plan_number,
        document_type=normalized_type,
        target_title=clean_title,
        gcs_utils=gcs_utils,
    )
    report_refreshed = False
    refresh_error = None
    try:
        await _refresh_preliminary_research(plan_number, gcs_utils)
        report_refreshed = True
    except Exception as exc:
        refresh_error = str(exc)
        logger.warning("Preliminary research refresh failed after document removal for plan %s: %s", plan_number, exc)

    return {
        "status": "success" if report_refreshed else "partial_failure",
        "message": (
            f"Document '{registry_result['matched_title']}' removed and preliminary research refreshed."
            if report_refreshed
            else f"Document '{registry_result['matched_title']}' marked as removed in registry, but preliminary research refresh failed."
        ),
        "plan_number": plan_number,
        "document_type": normalized_type,
        "title": registry_result["matched_title"],
        "removed": True,
        "registry_updated": True,
        "report_refreshed": report_refreshed,
        "audit": {
            "scope": scope,
            "blob_path": registry_result["blob_path"],
            "document_id": registry_result["document_id"],
            "refresh_error": refresh_error,
        },
        "source": "registry+runtime-refresh",
    }


# ====================================================================
# Sister Functions for Document & Section Inclusion / Upload
# ====================================================================

def _extract_inclusion_title_from_command(command: str, document_type: Optional[str] = None) -> str:
    """Extract a clean document or section title from a natural-language inclusion/upload request."""
    text = re.sub(r"\s+", " ", (command or "").strip())
    if not text:
        return ""

    lowered = text.lower()
    if "@" in text:
        text = text.split("@", 1)[1].strip()
    else:
        if document_type:
            doc_keyword = document_type.lower()
            if doc_keyword in lowered:
                idx = lowered.find(doc_keyword)
                text = text[idx + len(doc_keyword):].strip()

    text = re.sub(
        r"^(?:add|include|upload|insert|attach|restore|incorporate|bring\s+in)\b\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(r"^(?:policy|kod|procedure|document|section)\b\s*", "", text, flags=re.IGNORECASE)
    text = text.replace("-", " ")
    text = re.sub(r"^(for|from|of|on|to|into|in|the|this|that)\b", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\b(?:to|into|in)\s+(?:context|plan(?:\s*\d+)?)\s*$", "", text, flags=re.IGNORECASE)
    text = re.sub(r"[\t\n\r]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip(" ,;:.-")
    return text


async def parse_document_inclusion_intent(
    user_command: str,
    plan_number: Optional[str] = None,
    document_type: Optional[str] = None,
    title: Optional[str] = None,
    content: Optional[Any] = None,
    section_title: Optional[str] = None,
    document_id: Optional[Any] = None,
    env_config: Optional[EnvironmentConfig] = None,
) -> Dict[str, Any]:
    """Parse a natural-language inclusion/upload request into a structured plan/type/title payload (sister to parse_document_removal_intent)."""
    normalized_command = (user_command or "").strip()
    normalized_title = _normalize_title(title)
    parsed_type = (document_type or "").strip().lower() if document_type else None

    if not normalized_command and not normalized_title:
        raise ValueError("Document inclusion request requires a command or document title.")

    if parsed_type:
        try:
            parsed_type = _normalize_document_type(parsed_type)
        except InvalidDocumentTypeError:
            parsed_type = None

    lowered_command = normalized_command.lower()
    if not parsed_type:
        for dtype in ("policy", "kod", "procedure"):
            if dtype in lowered_command:
                parsed_type = dtype
                break

    if parsed_type is None:
        raise InvalidDocumentTypeError("Could not infer a valid document_type from the request. Use policy, kod, or procedure.")

    extracted_title = normalized_title or _extract_inclusion_title_from_command(normalized_command, parsed_type)
    if not extracted_title:
        raise ValueError("Unable to extract a meaningful document title from the inclusion request.")

    final_plan_number = str(plan_number).strip() if plan_number else None
    if not final_plan_number and "plan" in lowered_command:
        match = re.search(r"plan\s*[:#-]?\s*(\d+)", normalized_command, flags=re.IGNORECASE)
        if match:
            final_plan_number = match.group(1)

    return {
        "action": "include",
        "document_type": parsed_type,
        "title": extracted_title,
        "plan_number": final_plan_number,
        "content": content,
        "section_title": _normalize_title(section_title) if section_title else None,
        "document_id": str(document_id) if document_id is not None else None,
        "scope": "all_related",
    }


def _validate_inclusion_intent_payload(intent_payload: Dict[str, Any]) -> Dict[str, Any]:
    """Validate and normalize a structured LLM inclusion intent payload before executing backend mutation."""
    if not isinstance(intent_payload, dict):
        raise ValueError("Document inclusion intent must be a JSON object.")

    if intent_payload.get("status") == "error":
        raise ValueError(intent_payload.get("reason") or "Document inclusion request rejected by the model.")

    action = (intent_payload.get("action") or "").strip().lower()
    if action not in {"include", "add", "upload"}:
        raise InvalidDocumentTypeError(f"Unsupported action '{action}'. Expected 'include', 'add', or 'upload'.")

    document_type = (intent_payload.get("document_type") or "").strip().lower()
    try:
        normalized_type = _normalize_document_type(document_type)
    except InvalidDocumentTypeError as exc:
        raise InvalidDocumentTypeError(f"Invalid document type in intent payload: {document_type}") from exc

    title = _normalize_title(intent_payload.get("title"))
    if not title:
        raise ValueError("Document title is required in the inclusion intent payload.")

    plan_number = str(intent_payload.get("plan_number") or "").strip()
    if not plan_number:
        raise ValueError("Plan number is required in the inclusion intent payload.")

    return {
        "action": "include",
        "document_type": normalized_type,
        "title": title,
        "plan_number": plan_number,
        "document_id": intent_payload.get("document_id"),
        "section_title": intent_payload.get("section_title"),
        "content": intent_payload.get("content"),
        "scope": intent_payload.get("scope") or "all_related",
    }


async def _mark_registry_document_included(
    plan_number: str,
    document_type: str,
    target_title: str,
    gcs_utils: GCSUtils,
    document_entry: Optional[Dict[str, Any]] = None,
    blob_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Sister to _mark_registry_document_removed.
    Restores a previously excluded/removed document or adds a new document/section entry
    into `dbaware_review_{plan_number}/inbound-data/{document_type}/relevant_{document_type}.json`
    (or into an explicitly verified `blob_path` that belongs to the same plan).
    """
    normalized_type = _normalize_document_type(document_type)
    plan_prefix = f"dbaware_review_{plan_number}/"
    if blob_path and str(blob_path).startswith(plan_prefix) and str(blob_path).endswith(".json"):
        blob_path = str(blob_path)
    else:
        blob_path = _registry_blob_path(plan_number, normalized_type)
    extra_entry = dict(document_entry or {})

    if gcs_utils.blob_exists(blob_path):
        registry_payload = await _read_json_blob(gcs_utils, blob_path)
    else:
        registry_payload = {"documents": []}

    if isinstance(registry_payload, dict):
        document_entries = (
            list(registry_payload.get("documents", []))
            if isinstance(registry_payload.get("documents", []), list)
            else []
        )
        active_payload: Any = registry_payload
    elif isinstance(registry_payload, list):
        document_entries = list(registry_payload)
        active_payload = document_entries
    else:
        document_entries = []
        active_payload = {"documents": document_entries}

    clean_title = _normalize_title(target_title) or _normalize_title(extra_entry.get("document_title") or extra_entry.get("title"))
    if not clean_title:
        raise ValueError("Document title is required to include a document in the registry.")

    matched_item, matches, state = _find_registry_document(document_entries, clean_title)
    if state == "ambiguous" and matches:
        # Prefer exact title match if present, otherwise pick the first match
        exact_matches = [
            m for m in matches
            if _normalize_text_for_match(m.get("document_title") or m.get("title") or m.get("name"))
            == _normalize_text_for_match(clean_title)
        ]
        matched_item = exact_matches[0] if exact_matches else matches[0]

    if matched_item is not None:
        item_id = (
            matched_item.get("document_id")
            or matched_item.get("id")
            or _slugify_title(str(matched_item.get("document_title") or matched_item.get("title") or clean_title))
        )
        matched_title = str(matched_item.get("document_title") or matched_item.get("title") or matched_item.get("name") or clean_title)
        # Identity keys of an existing row must never be overwritten by the caller payload.
        protected_keys = {"sections", "paragraphs", "id", "document_id", "row_primary_key", "document_title", "title"}
        updated_entries = []
        for entry in document_entries:
            if not isinstance(entry, dict):
                updated_entries.append(entry)
                continue
            if entry is matched_item:
                entry_copy = dict(entry)
                for k, v in extra_entry.items():
                    if v is not None and k not in protected_keys:
                        entry_copy[k] = v
                if extra_entry.get("paragraphs"):
                    existing_paras = entry_copy.get("paragraphs") if isinstance(entry_copy.get("paragraphs"), list) else []
                    new_paras = extra_entry["paragraphs"] if isinstance(extra_entry["paragraphs"], list) else [extra_entry["paragraphs"]]
                    entry_copy["paragraphs"] = existing_paras + new_paras
                if extra_entry.get("sections"):
                    existing_secs = entry_copy.get("sections") if isinstance(entry_copy.get("sections"), list) else []
                    new_secs = extra_entry["sections"] if isinstance(extra_entry["sections"], list) else [extra_entry["sections"]]
                    entry_copy["sections"] = existing_secs + new_secs
                if extra_entry.get("section_title") or extra_entry.get("content") is not None:
                    sec_list = entry_copy.get("sections") if isinstance(entry_copy.get("sections"), list) else []
                    sec_list.append({
                        "section_id": extra_entry.get("section_id") or _slugify_title(str(extra_entry.get("section_title") or "added_section")),
                        "section_title": extra_entry.get("section_title") or "Added Section",
                        "content": extra_entry.get("content"),
                    })
                    entry_copy["sections"] = sec_list
                entry_copy["status"] = "active"
                entry_copy["excluded"] = False
                entry_copy.pop("removed_at", None)
                entry_copy.pop("removed_by", None)
                entry_copy["included_at"] = extra_entry.get("included_at", "document_management")
                entry_copy["included_by"] = extra_entry.get("included_by", "document_management")
                updated_entries.append(entry_copy)
            else:
                updated_entries.append(entry)
    else:
        item_id = str(
            extra_entry.get("document_id")
            or extra_entry.get("id")
            or _slugify_title(clean_title)
            or f"{normalized_type}_{len(document_entries) + 1}"
        )
        matched_title = clean_title
        new_entry: Dict[str, Any] = {
            "id": item_id,
            "document_id": item_id,
            "document_title": clean_title,
            "title": clean_title,
            "document_type": normalized_type,
            "status": "active",
            "excluded": False,
            "included_at": extra_entry.get("included_at", "document_management"),
            "included_by": extra_entry.get("included_by", "document_management"),
        }
        for k, v in extra_entry.items():
            if v is not None:
                new_entry[k] = v
        if extra_entry.get("section_title") and "sections" not in new_entry:
            new_entry["sections"] = [
                {
                    "section_id": extra_entry.get("section_id") or _slugify_title(str(extra_entry.get("section_title"))),
                    "section_title": extra_entry.get("section_title"),
                    "content": extra_entry.get("content"),
                }
            ]
        updated_entries = list(document_entries) + [new_entry]

    if isinstance(active_payload, dict):
        active_payload["documents"] = updated_entries
        gcs_utils.write_blob_json(blob_path, active_payload)
    else:
        gcs_utils.write_blob_json(blob_path, updated_entries)

    return {
        "blob_path": blob_path,
        "plan_number": plan_number,
        "document_type": normalized_type,
        "matched_title": matched_title,
        "document_id": str(item_id),
        "created": matched_item is None,
    }


async def _load_included_documents_for_plan(plan_number: str, gcs_utils: GCSUtils) -> List[Dict[str, Any]]:
    """Loads all active/included documents from the plan's registries."""
    included_docs: List[Dict[str, Any]] = []
    for document_type in sorted(VALID_DOCUMENT_TYPES):
        registry_path = _registry_blob_path(plan_number, document_type)
        try:
            payload = await _read_json_blob(gcs_utils, registry_path)
        except Exception:
            continue

        entries = []
        if isinstance(payload, dict):
            entries = payload.get("documents", []) if isinstance(payload.get("documents", []), list) else []
        elif isinstance(payload, list):
            entries = payload

        for entry in entries:
            if not isinstance(entry, dict):
                continue
            if entry.get("status") == "removed" or entry.get("excluded") is True:
                continue
            if entry.get("included_at") or entry.get("status") == "active":
                included_docs.append(entry)
    return included_docs


def _merge_included_content(payload: Any, included_documents: List[Dict[str, Any]]) -> Any:
    """Merges included document entries into preliminary research JSON payloads without duplicating existing titles."""
    if not included_documents or not isinstance(payload, dict):
        return payload

    updated = dict(payload)
    existing_docs = updated.get("included_documents")
    if not isinstance(existing_docs, list):
        existing_docs = []
    else:
        existing_docs = list(existing_docs)

    seen_titles = {
        _normalize_text_for_match(d.get("document_title") or d.get("title"))
        for d in existing_docs
        if isinstance(d, dict)
    }

    for doc in included_documents:
        if not isinstance(doc, dict):
            continue
        title = str(doc.get("document_title") or doc.get("title") or "").strip()
        norm_title = _normalize_text_for_match(title)
        if not norm_title or norm_title in seen_titles:
            continue
        seen_titles.add(norm_title)
        existing_docs.append({
            "document_id": doc.get("document_id") or doc.get("id"),
            "document_title": title,
            "document_type": doc.get("document_type", "policy"),
            "sections": doc.get("sections", []),
            "content": doc.get("content"),
        })

    if existing_docs:
        updated["included_documents"] = existing_docs
    return updated


async def manage_document_inclusion(
    plan_number: str,
    document_type: str,
    title: str,
    env_config: EnvironmentConfig,
    content: Optional[Any] = None,
    document_id: Optional[Any] = None,
    section_title: Optional[str] = None,
    scope: str = "all_related",
) -> Dict[str, Any]:
    """Sister to manage_document_removal: includes/adds a document or section in the plan registry and refreshes preliminary research."""
    normalized_type = _normalize_document_type(document_type)
    clean_title = _normalize_title(title)
    if not clean_title:
        raise ValueError("Document title is required for inclusion.")

    gcs_utils = GCSUtils(env_config)
    entry_payload: Dict[str, Any] = {
        "document_title": clean_title,
        "title": clean_title,
        "document_type": normalized_type,
        "content": content,
        "section_title": section_title,
        "document_id": str(document_id) if document_id is not None else None,
    }
    registry_result = await _mark_registry_document_included(
        plan_number=plan_number,
        document_type=normalized_type,
        target_title=clean_title,
        gcs_utils=gcs_utils,
        document_entry=entry_payload,
    )

    report_refreshed = False
    refresh_error = None
    try:
        await _refresh_preliminary_research(plan_number, gcs_utils)
        report_refreshed = True
    except Exception as exc:
        refresh_error = str(exc)
        logger.warning("Preliminary research refresh failed after document inclusion for plan %s: %s", plan_number, exc)

    return {
        "status": "success" if report_refreshed else "partial_failure",
        "message": (
            f"Document '{registry_result['matched_title']}' included and preliminary research refreshed."
            if report_refreshed
            else f"Document '{registry_result['matched_title']}' included in registry, but preliminary research refresh failed."
        ),
        "plan_number": plan_number,
        "document_type": normalized_type,
        "title": registry_result["matched_title"],
        "included": True,
        "registry_updated": True,
        "report_refreshed": report_refreshed,
        "audit": {
            "scope": scope,
            "blob_path": registry_result["blob_path"],
            "document_id": registry_result["document_id"],
            "created": registry_result.get("created", False),
            "refresh_error": refresh_error,
        },
        "source": "registry+runtime-refresh",
    }

