"""Trade Collections — Maker Workbench.

Two screens: a queue that tells you what needs doing, and a case you can
decide in one pass.

Run with:  uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

import inspect
from pathlib import Path
from urllib.parse import quote_plus

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .api import router as api_router
from .models import CaseStatus
from .store import CaseStore, get_store

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title="Trade Collections — Maker Workbench",
    description="WFMS and TradePay intake, automated checks and charges, maker and checker "
                "control, TF3 hand-off. Illustrative data.",
    version="2.0.0",
)
app.include_router(api_router)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))



THEMES = {"desk", "corp"}
DEFAULT_THEME = "desk"


def pick_theme(request: Request, v: str | None) -> str:
    """Which of the two house styles to render.

    ``?v=desk`` or ``?v=corp`` switches and sticks via a cookie, so links
    stay shareable and navigation keeps whichever view you chose.
    """
    if v in THEMES:
        return v
    cookie = request.cookies.get("view")
    return cookie if cookie in THEMES else DEFAULT_THEME


# Starlette moved to TemplateResponse(request, name, context); older releases
# only accept (name, context). Pick the right call once, so the app runs on
# whatever the machine happens to have installed.
_TEMPLATE_WANTS_REQUEST = "request" in inspect.signature(
    Jinja2Templates.TemplateResponse).parameters


def render(theme: str, name: str, ctx: dict) -> HTMLResponse:
    path = f"{theme}/{name}"
    if _TEMPLATE_WANTS_REQUEST:
        response = templates.TemplateResponse(request=ctx["request"], name=path, context=ctx)
    else:
        response = templates.TemplateResponse(path, ctx)
    response.set_cookie("view", theme, max_age=60 * 60 * 24 * 30, samesite="lax")
    return response


def _shell(request: Request, store: CaseStore, active: str, theme: str) -> dict:
    cases = store.all_cases()
    checker = store.session.role == "Checker"
    todo = (sum(1 for c in cases if c.status is CaseStatus.IN_CHECKER_QUEUE) if checker
            else sum(1 for c in cases if c.needs_maker))
    return {
        "request": request,
        "session": store.session,
        "active": active,
        "counts": {"todo": todo},
    }


def _qs(q: str | None, path: str, filters: dict | None) -> str:
    """Base for sort links, so sorting keeps the search, filters and page."""
    parts = [f"q={quote_plus(q or '')}"]
    for key, val in (filters or {}).items():
        if val and val != "all":
            parts.append(f"{key}={quote_plus(val)}")
    return f"{path}?" + "&".join(parts)


# what the sort control offers, in the order it offers it
SORT_LABELS = {
    "sla":        "Deadline",
    "received":   "Arrival time",
    "principal":  "Collection value",
    "charges":    "Charges",
    "exceptions": "Things outstanding",
    "checks":     "Checks passed",
    "priority":   "Priority",
    "customer":   "Customer",
    "assignee":   "Owner",
    "source":     "Source",
    "collection": "Collection type",
    "currency":   "Currency",
    "boe":        "Bill of Entry",
    "case_id":    "Case number",
    "status":     "Status",
}

# the handful a maker reaches for most, shown inline on the desk
DESK_SORTS = ["sla", "principal", "exceptions", "priority", "customer", "received"]


def _queue_groups(store: CaseStore, q: str | None, sort: str | None,
                  direction: str, filters: dict) -> tuple[list, list, list]:
    """Split the open book into: needs you, ready to send, still working.

    With no explicit sort the groups fall into deadline order, which is how a
    maker works them. An explicit sort is applied by the store and preserved
    here rather than being overwritten.
    """
    kw = {"search": q, **{k: v for k, v in filters.items() if v and v != "all"}}
    if sort:
        kw |= {"sort": sort, "direction": direction}
    if store.session.role == "Checker":
        return store.list_cases(view="checker", **kw), [], []

    rows = store.list_cases(view="all", **kw)
    todo = [c for c in rows if c.needs_maker or c.status is CaseStatus.RETURNED]
    ready = [c for c in rows if c.status is CaseStatus.READY_FOR_REVIEW and not c.needs_maker]
    waiting = [c for c in rows if c.status in (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING)]
    if not sort:
        todo.sort(key=lambda c: c.sla_due or c.received_at)
        ready.sort(key=lambda c: c.sla_due or c.received_at)
    return todo, ready, waiting


@app.get("/", response_class=HTMLResponse)
def queue(request: Request, q: str | None = None, v: str | None = None,
          sort: str | None = None, direction: str = "asc",
          source: str = "all", status: str = "all", priority: str = "all",
          store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    if sort not in SORT_LABELS:
        sort = None
    direction = "desc" if direction == "desc" else "asc"
    filters = {"source": source, "status": status, "priority": priority}
    todo, ready, waiting = _queue_groups(store, q, sort, direction, filters)
    checker = store.session.role == "Checker"

    formal = theme == "corp"
    total = len(todo) + len(ready)

    if checker:
        greeting = (f"{len(todo)} awaiting control" if todo else "No cases awaiting control")
        summary = ("Each has been validated by a maker and is held for checker control."
                   if todo else
                   "Validated cases are released to this queue by the maker desk.")
    elif total:
        greeting = (f"{total} collections open" if formal
                    else f"{total} on the desk")
        parts = []
        if todo:
            parts.append(f"{len(todo)} " + ("require action" if formal else "need a decision"))
        if ready:
            parts.append(f"{len(ready)} " + ("cleared for validation" if formal else "already clear"))
        summary = " and ".join(parts) + "."
        summary = summary[0].upper() + summary[1:]
    else:
        greeting = "Queue is clear" if formal else "Your desk is clear"
        summary = ("No open collections." if formal else "Nothing is waiting.")

    ctx = _shell(request, store, "queue", theme)
    ctx.update({
        "todo": todo, "ready": ready, "waiting": waiting, "q": q or "",
        "greeting": greeting, "summary": summary,
        "progress": {c.case_id: store.progress(c) for c in waiting},
        "sort": sort, "direction": direction, "sort_labels": SORT_LABELS,
        "desk_sorts": DESK_SORTS,
        "filters": filters, "filtered": any(x != "all" for x in filters.values()),
        "base_qs": _qs(q, "/", filters),
        # the corporate worklist is one table: an explicit sort orders the whole
        # thing, otherwise cases needing action stay on top
        "rows": (store.list_cases(view="checker" if checker else "all", search=q,
                                  sort=sort, direction=direction,
                                  **{k: val for k, val in filters.items() if val != "all"})
                 if sort else todo + ready + waiting),
    })
    return render(theme, "queue.html", ctx)


@app.get("/done", response_class=HTMLResponse)
def done(request: Request, q: str | None = None, v: str | None = None,
         sort: str | None = None, direction: str = "asc",
         store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    if sort not in SORT_LABELS:
        sort = None
    direction = "desc" if direction == "desc" else "asc"
    kw = {"search": q} | ({"sort": sort, "direction": direction} if sort else {})
    rows = store.list_cases(view="completed", **kw)
    sent = store.list_cases(view="checker", **kw)
    ctx = _shell(request, store, "done", theme)
    ctx.update({
        "todo": [], "ready": [], "waiting": [], "q": q or "",
        "greeting": "Finished",
        "summary": f"{len(sent)} with the checker, {len(rows)} closed.",
        "progress": {},
        "sort": sort, "direction": direction, "sort_labels": SORT_LABELS,
        "desk_sorts": DESK_SORTS,
        "filters": {"source": "all", "status": "all", "priority": "all"}, "filtered": False,
        "base_qs": _qs(q, "/done", None),
        "rows": sent + rows,
    })
    # reuse the queue layout: "with the checker" reads as ready, closed as quiet
    ctx["ready"] = sent
    ctx["waiting"] = rows
    return render(theme, "queue.html", ctx)


@app.get("/cases/{case_id}", response_class=HTMLResponse)
def case_detail(request: Request, case_id: str, v: str | None = None,
                store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    case = store.get(case_id)
    if case is None:
        raise HTTPException(status_code=404, detail=f"Case {case_id} not found")

    # "next in queue" follows the maker's working order: deadline first
    todo, ready, _ = _queue_groups(store, None, None, "asc",
                                   {"source": "all", "status": "all", "priority": "all"})
    queue = [c for c in todo + ready if c.case_id != case.case_id]

    ctx = _shell(request, store, "queue", theme)
    ctx["case"] = case
    ctx["next_case"] = queue[0] if queue else None
    return render(theme, "case.html", ctx)


# --------------------------------------------------------------------------
# reference — linked from the footer, not in the main navigation
# --------------------------------------------------------------------------

@app.get("/ports", response_class=HTMLResponse)
def ports(request: Request, q: str = "", v: str | None = None,
          store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "ports", "title": "Port directory", "rows": store.ports(q or None), "q": q,
                "blurb": "Transport documents carry the short code; the full name is what goes to "
                         "TF3. You can search this from any case."})
    return render(theme, "reference.html", ctx)


@app.get("/tariffs", response_class=HTMLResponse)
def tariffs(request: Request, v: str | None = None,
            store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "tariffs", "title": "Client tariffs", "rows": store.tariffs(), "q": "",
                "blurb": "Commission and service charges per client, from the OEMS processing "
                         "instructions. These drive every charge figure."})
    return render(theme, "reference.html", ctx)


@app.get("/rules", response_class=HTMLResponse)
def rules(request: Request, v: str | None = None,
          store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "rules", "title": "Rule sets", "rows": store.rule_sets(), "q": "",
                "blurb": "The bank-approved rules, versioned. Every check records the version "
                         "that produced its outcome."})
    return render(theme, "reference.html", ctx)
