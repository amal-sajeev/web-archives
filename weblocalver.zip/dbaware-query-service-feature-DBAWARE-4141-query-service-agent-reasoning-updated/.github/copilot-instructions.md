# System & Workspace Starter Manual (`llmjudge`)

## 1. Local Machine & Tooling Paths (Windows)
- **Workspace Root**: `c:\Users\sanjama\Documents\llmjudge`
- **Python (venv)**: `c:\Users\sanjama\Documents\llmjudge\.venv\Scripts\python.exe`
- **Pytest**: `c:\Users\sanjama\Documents\llmjudge\.venv\Scripts\pytest.exe`
- **Git**: `git` (via PATH; remote `origin` = `https://github.com/ntbv-ifbn/dbaware-scoping-service.git`)
- **GCloud / Kubectl**:
  - `gcloud`: `C:\Users\sanjama\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.cmd`
  - `kubectl`: `C:\Users\sanjama\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin\kubectl.exe`
- **Corporate Proxy (required for external HTTPS / Vertex AI / GCS from local machine)**:
  - `HTTPS_PROXY=http://sdod3-proxy.intranet.db.com:8080`
  - `HTTP_PROXY=http://sdod3-proxy.intranet.db.com:8080`
  - `NO_PROXY=localhost,127.0.0.1`

## 2. GCP, Vertex AI & GKE (`ct1`)
- **Auth**: Use active `gcloud` login (`amal.sanjeev@db.com`). Do **NOT** use WIF (`external_account` JSON) unless explicitly asked. If `GOOGLE_APPLICATION_CREDENTIALS` is set to a WIF file, clear it so ADC uses the user's `gcloud` credentials.
- **GCP Project**: `db-dev-46jr-mp-cta-analytics`
- **GCS Bucket**: `db-dev-euwe3-gcs-155081-dbaware_review`
- **Vertex AI Model & Region**:
  - Default model: `gemini-3.5-flash` -> **MUST use `europe-west3`** (`404 NOT_FOUND` in `us-central1` and `europe-west1`).
  - `gemini-2.5-pro` / `gemini-2.5-flash` -> `europe-west1` or `us-central1`.
- **GKE Cluster (`ct1`)**:
  - Cluster: `db-dev-46jr-gke-155081-cta-01` (region `europe-west3`), Namespace: `155081-1-cta-ct1`
  - **Rule**: Do **NOT** mutate GKE resources (`kubectl set`/`patch`/`apply`) to deploy changes. Push to the GitHub branch to trigger CI/CD deployment. Use `kubectl logs` / `kubectl get` read-only for debugging.
- **Live CT1 Endpoints**:
  - Summary Agent: `https://ct1-cta.dbaware.dev.gcp.db.com/scoping-summary-agent/`
  - Procedure Agent: `https://ct1-cta.dbaware.dev.gcp.db.com/scoping-procedure-agent/`

## 3. Repository Structure & PYTHONPATH
This monorepo contains multiple services sharing `shared/llm_judge`:
1. **`scoping-summary-agent`**:
   - Source: `scoping-summary-agent/src/main` | Tests: `scoping-summary-agent/src/tests`
   - Run tests: `$env:PYTHONPATH="scoping-summary-agent/src/main;."; .\.venv\Scripts\pytest.exe scoping-summary-agent/src/tests`
2. **`scoping-procedure-agent`**:
   - Source: `scoping-procedure-agent/src/main` | Tests: `scoping-procedure-agent/src/tests`
   - Run tests: `$env:PYTHONPATH="scoping-procedure-agent/src/main;."; .\.venv\Scripts\pytest.exe scoping-procedure-agent/src/tests`
3. **`shared/llm_judge`**:
   - Shared review-and-revise loop (`shared/llm_judge/loop.py`).
   - Enable verbose judge output with `LLM_JUDGE_DEBUG=1` (and `SUMMARY_AGENT_JUDGE_DEBUG=1`).

## 4. Common Pitfalls & Conventions
- **File Encoding**: Always write log files (e.g., `scripts/loggo.log`) in `utf-8` (avoid PowerShell `>` default `UTF-16LE`).
- **DB Foreign Key on `run-analytics-agent`**: Never pass `"review_scope_instance_id": 0` (Swagger default); use `1` so `dbaware_scoping.review_research_recommendation` FK constraint succeeds.
- **Test Plans**:
  - `20086`: Small/fast plan (no historical PDFs; `past_review` short-circuits; `policy_regulation` + `broad_scope` run LLM + Judge in ~2-3 min).
  - `20090`: Full plan with historical PDFs (larger payload).
- **Git Discipline**: Keep branches scoped to the target service (e.g., `feature/DBAWARE-4141-llm-judge-summary-agent` is strictly for `scoping-summary-agent` + `shared/llm_judge`).