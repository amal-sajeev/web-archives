import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from dotenv import load_dotenv

try:
    import google.auth
except ModuleNotFoundError:  # pragma: no cover - optional in local/test environments
    google = None

try:
    import sqlalchemy
except ModuleNotFoundError:  # pragma: no cover - optional in bare test environments
    sqlalchemy = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

SCHEMA_NAME = "dbaware_scoping"
REVIEW_SCOPE_TABLE = f"{SCHEMA_NAME}.review_scope"
DATA_EXTRACTION_TABLE = f"{SCHEMA_NAME}.review_data_extraction"
REVIEW_DOCUMENTS_TABLE = f"{SCHEMA_NAME}.dbaware_review_documents"

SCOPING_SOURCES = (
    "policy",
    "kod",
    "procedure",
    "gfms",
    "historical_scoping_document",
    "lrr",
)

SOURCE_ALIASES: Dict[str, str] = {
    "policy": "policy",
    "policies": "policy",
    "policy_policy": "policy",
    "policy policy": "policy",
    "kod": "kod",
    "kods": "kod",
    "policy_kod": "kod",
    "policy kod": "kod",
    "key_operating_document": "kod",
    "procedure": "procedure",
    "procedures": "procedure",
    "policy_procedure": "procedure",
    "policy procedure": "procedure",
    "gfms": "gfms",
    "gfms_data": "gfms",
    "gfms data": "gfms",
    "findings_details": "gfms",
    "finding_details": "gfms",
    "finding": "gfms",
    "findings": "gfms",
    "historical_scoping_document": "historical_scoping_document",
    "historical_scoping_documents": "historical_scoping_document",
    "historical scoping document": "historical_scoping_document",
    "historical scoping documents": "historical_scoping_document",
    "historical_plan_details": "historical_scoping_document",
    "historical_plan": "historical_scoping_document",
    "historical plan": "historical_scoping_document",
    "historical": "historical_scoping_document",
    "historical_document": "historical_scoping_document",
    "lrr": "lrr",
    "laws rules and regulations": "lrr",
    "laws, rules, and regulations": "lrr",
    "regulations": "lrr",
    "regulatory": "lrr",
    "regulatory mandates": "lrr",
    "internet_search_data": "lrr",
    "internet_search_data_enriched": "lrr",
}

SOURCE_TO_DB_DATA_SOURCE: Dict[str, str] = {
    "policy": "policy",
    "kod": "kod",
    "procedure": "procedure",
    "gfms": "findings_details",
    "findings_details": "findings_details",
    "historical_scoping_document": "historical_plan_details",
    "historical_plan_details": "historical_plan_details",
    "lrr": "lrr",
    "internet_search_data": "lrr",
    "internet_search_data_enriched": "lrr",
}

PRELIMINARY_RESEARCH_SECTION_ORDER = ("past_review", "policy_regulation", "broad_scope")

SOURCE_TO_AFFECTED_SECTIONS: Dict[str, tuple[str, ...]] = {
    "historical_scoping_document": ("past_review", "broad_scope"),
    "policy": ("policy_regulation", "broad_scope"),
    "kod": ("policy_regulation", "broad_scope"),
    "procedure": ("policy_regulation", "broad_scope"),
    "lrr": ("policy_regulation", "broad_scope"),
    "gfms": ("broad_scope",),
}


def compute_affected_preliminary_research_sections(
    sources: Optional[Iterable[Optional[str]]],
) -> List[str]:
    """Map mutated scoping source keys to the ordered Preliminary Research report section keys."""
    affected: set[str] = set()
    for src in sources or []:
        canonical = normalize_scoping_source(src) or str(src or "").strip().lower()
        for section_key in SOURCE_TO_AFFECTED_SECTIONS.get(canonical, ()):
            affected.add(section_key)
    return [sec for sec in PRELIMINARY_RESEARCH_SECTION_ORDER if sec in affected]


def normalize_scoping_source(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    cleaned = str(value).strip().lower()
    return SOURCE_ALIASES.get(cleaned)


def source_to_db_data_source(value: Optional[str]) -> str:
    canonical = normalize_scoping_source(value) or str(value or "policy").strip().lower()
    return SOURCE_TO_DB_DATA_SOURCE.get(canonical, canonical)


# Process-local fixtures for explicitly opted-in local/test mode only.
_MOCK_DATA_EXTRACTION_STORE: Dict[str, Dict[str, Dict[str, Any]]] = {}
_MOCK_REVIEW_DOCUMENTS_STORE: Dict[str, List[Dict[str, Any]]] = {}


def _load_runtime_env() -> None:
    base = Path(__file__).resolve()
    for parent in list(base.parents)[:4]:
        env_file = parent / ".env"
        if env_file.exists():
            load_dotenv(env_file, override=False)


_load_runtime_env()


class DatabaseConnector:
    """Factory for PostgreSQL connections used by DB-aware services."""

    def __init__(self, env_config: Optional[Any] = None):
        self.env_config = env_config
        self.project_id = os.getenv("project_name") or os.getenv("GCP_PROJECT_ID")
        self.db_host = os.getenv("db_host") or os.getenv("DB_HOST")
        self.db_user = os.getenv("db_user") or os.getenv("DB_USER")
        self.db_pass = (
            os.getenv("db_pass")
            or os.getenv("DB_PASS")
            or os.getenv("scoping_db_pass")
            or os.getenv("SCOPING_DB_PASS")
            or ""
        )
        self.db_name = os.getenv("db_name") or os.getenv("DB_NAME")
        self.db_port = int(os.getenv("db_port") or os.getenv("DB_PORT", "5432"))
        self.credentials = None
        if google is not None:
            try:
                self.credentials, _ = google.auth.default()
            except Exception:
                logger.warning(
                    "Unable to initialize Google auth credentials for DB connector",
                    exc_info=True,
                )
                self.credentials = None

    def connect_to_database(self) -> Any:
        engine = sqlalchemy.create_engine(
            sqlalchemy.engine.url.URL.create(
                drivername="postgresql+pg8000",
                username=self.db_user,
                password=self.db_pass,
                host=self.db_host,
                port=self.db_port,
                database=self.db_name,
            ),
            pool_pre_ping=True,
        )
        logger.info(
            "Database engine created for host=%s db=%s", self.db_host, self.db_name
        )
        return engine

    def check_connection(self) -> bool:
        try:
            with self.connect_to_database().connect() as connection:
                connection.execute(sqlalchemy.text("SELECT 1"))
            return True
        except Exception:
            logger.exception("Database connectivity check failed")
            return False

    def get_document_ids_for_scope_instance(self, instance_id: int) -> Dict[str, List[int]]:
        """Queries scoping-db to get mapped document IDs grouped by policy, kod, and procedure."""
        # Pre-configured mock data mapped by review_scope_instance_id
        mock_instance_docs: Dict[int, Dict[str, List[int]]] = {
            1: {"policy": [1, 2, 3], "kod": [121, 43, 27], "procedure": [13, 17, 194]},
        }
        default_mock_docs: Dict[str, List[int]] = {
            "policy": [1, 2, 3],
            "kod": [121, 43, 27],
            "procedure": [13, 17, 194],
        }

        # Mock IDs are available only when explicitly requested for local tests.
        if self._is_mock_mode():
            resolved_mock = mock_instance_docs.get(instance_id, default_mock_docs)
            logger.info(
                "🧪 [MOCK MODE] Serving mock document IDs for review_scope_instance_id=%s: %s",
                instance_id,
                resolved_mock,
            )
            return {k: list(v) for k, v in resolved_mock.items()}

        doc_ids_by_type: Dict[str, List[int]] = {"policy": [], "kod": [], "procedure": []}
        query_by_instance_id = sqlalchemy.text("""
            SELECT document_id
            FROM dbaware_scoping.dbaware_review_documents
            WHERE review_scope_instance_id = :instance_id;
        """)
        query_by_scope_id = sqlalchemy.text("""
            SELECT document_id
            FROM dbaware_scoping.dbaware_review_documents
            WHERE review_scope_id = :scope_id;
        """)
        try:
            with self.connect_to_database().connect() as connection:
                column = self._scope_column(connection, "dbaware_review_documents")
                if column == "review_scope_id":
                    scope_id_val = self._coerce_scope_int(instance_id)
                    results = connection.execute(query_by_scope_id, {"scope_id": scope_id_val})
                else:
                    results = connection.execute(query_by_instance_id, {"instance_id": str(instance_id)})
                extracted_ids = [int(row[0]) for row in results if row[0] is not None]
                logger.info(
                    "🔌 Found %d document_id(s) in dbaware_scoping.dbaware_review_documents for review_scope_instance_id=%s: %s",
                    len(extracted_ids), instance_id, extracted_ids
                )
                # Map all retrieved document IDs across governance types for vector search
                for doc_type in doc_ids_by_type:
                    doc_ids_by_type[doc_type] = list(extracted_ids)
            return doc_ids_by_type
        except Exception as e:
            logger.warning(
                "⚠️ Database query failed for instance %s (%s). Falling back to mock scoping data.",
                instance_id,
                str(e),
            )
            return doc_ids_by_type

    # ------------------------------------------------------------------
    # Liquibase table helpers for document context verification & mutation
    #   - dbaware_scoping.review_scope (PK: review_scope_instance_id VARCHAR(100) or review_scope_id INTEGER)
    #   - dbaware_scoping.review_data_extraction (PK: review_scope_dataext_id INTEGER)
    #   - dbaware_scoping.dbaware_review_documents (PK: review_document_instance_id INTEGER)
    # ------------------------------------------------------------------

    @staticmethod
    def _coerce_scope_int(value: Optional[Any]) -> Optional[int]:
        if value is None or isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        cleaned = str(value).strip()
        if cleaned.lstrip("-").isdigit():
            return int(cleaned)
        return None

    def _is_mock_mode(self) -> bool:
        return os.getenv("MOCK_SCOPING_DB", "false").strip().lower() in ("true", "1", "yes")

    @staticmethod
    def _scope_column(connection: Any, table_name: str) -> str:
        """Detect the deployed Liquibase FK name before issuing a write transaction.

        The column name is selected from a fixed whitelist, never interpolated from input.
        """
        result = connection.execute(
            sqlalchemy.text("""
                SELECT column_name FROM information_schema.columns
                WHERE table_schema = :schema AND table_name = :table
                  AND column_name IN ('review_scope_id', 'review_scope_instance_id')
                ORDER BY CASE column_name WHEN 'review_scope_id' THEN 0 ELSE 1 END
                LIMIT 1
            """),
            {"schema": SCHEMA_NAME, "table": table_name},
        ).first()
        if result and result[0] in ("review_scope_id", "review_scope_instance_id"):
            return result[0]
        raise RuntimeError(f"No review scope foreign key column found in {SCHEMA_NAME}.{table_name}")

    @staticmethod
    def _ensure_review_scope_exists(
        connection: Any,
        scope_column: str,
        scope_value: Any,
        plan_number: Any = None,
        created_by: Optional[str] = None,
        remarks: Optional[str] = None,
    ) -> None:
        """Ensure parent row exists in `dbaware_scoping.review_scope` before child FK inserts."""
        try:
            if scope_column == "review_scope_id":
                plan_int = DatabaseConnector._coerce_scope_int(plan_number) or scope_value
                stmt = sqlalchemy.text(f"""
                    INSERT INTO {REVIEW_SCOPE_TABLE} (
                        review_scope_id, review_plan_id, created_by, created_on, remarks
                    )
                    SELECT :scope_val, :plan_int, :created_by, CURRENT_TIMESTAMP, :remarks
                    WHERE NOT EXISTS (
                        SELECT 1 FROM {REVIEW_SCOPE_TABLE} WHERE review_scope_id = :scope_val
                    )
                """)
                params = {
                    "scope_val": scope_value,
                    "plan_int": plan_int,
                    "created_by": created_by,
                    "remarks": remarks,
                }
                if hasattr(connection, "begin_nested"):
                    with connection.begin_nested():
                        connection.execute(stmt, params)
                else:
                    connection.execute(stmt, params)
        except Exception as exc:
            logger.debug("Could not ensure parent review_scope row (%s=%s): %s", scope_column, scope_value, exc)

    @staticmethod
    def _default_dataext_pk(instance_id: str, data_source: str) -> int:
        offset = {
            "policy": 1,
            "kod": 2,
            "procedure": 3,
            "rag_document_metadata": 4,
            "findings_details": 5,
            "historical_plan_details": 6,
            "lrr": 7,
        }.get(data_source, 9)
        digits = "".join(ch for ch in str(instance_id) if ch.isdigit())
        base = int(digits) * 10 if digits else 1000
        return base + offset

    def _ensure_mock_plan_seeded(self, instance_id: str) -> None:
        inst = str(instance_id).strip()
        if inst not in _MOCK_DATA_EXTRACTION_STORE:
            _MOCK_DATA_EXTRACTION_STORE[inst] = {}
            for ds in (
                "policy",
                "kod",
                "procedure",
                "findings_details",
                "historical_plan_details",
                "lrr",
                "rag_document_metadata",
            ):
                pk = self._default_dataext_pk(inst, ds)
                if ds in ("policy", "kod", "procedure"):
                    context_file = f"dbaware_review_{inst}/inbound-data/policy/relevant_{ds}.json"
                elif ds == "findings_details":
                    context_file = f"dbaware_review_{inst}/inbound-data/gfms/findings_details.json"
                elif ds == "historical_plan_details":
                    context_file = f"dbaware_review_{inst}/inbound-data/dbaware/historical_plan_details.json"
                elif ds == "lrr":
                    context_file = f"dbaware_review_{inst}/inbound-data/lrr/internet_search_data_enriched.json"
                else:
                    context_file = f"dbaware_review_{inst}/inbound-data/policy"
                _MOCK_DATA_EXTRACTION_STORE[inst][ds] = {
                    "review_scope_dataext_id": pk,
                    "review_scope_instance_id": inst,
                    "data_source": ds,
                    "metadata": {
                        "source_type": ds,
                        "context_file": context_file,
                        "documents": [],
                    },
                    "table": DATA_EXTRACTION_TABLE,
                }
        if inst not in _MOCK_REVIEW_DOCUMENTS_STORE:
            default_ids = [1, 2, 3, 121, 43, 27, 13, 17, 194]
            base_pk = (int(inst) * 100) if inst.isdigit() else 10000
            _MOCK_REVIEW_DOCUMENTS_STORE[inst] = [
                {
                    "review_document_instance_id": base_pk + idx,
                    "review_scope_instance_id": inst,
                    "document_id": doc_id,
                    "table": REVIEW_DOCUMENTS_TABLE,
                }
                for idx, doc_id in enumerate(default_ids, start=1)
            ]

    def resolve_scope_instance_id(
        self,
        plan_number: str,
        explicit_instance_id: Optional[Any] = None,
    ) -> str:
        """
        Resolves `review_scope_instance_id` (VARCHAR(100) PK on `dbaware_scoping.review_scope`)
        or `review_scope_id` (INTEGER PK in rebuilt Liquibase schema) for a given `plan_number`
        (`review_plan_id` or `review_scope_instance_id` / `review_scope_id`).
        """
        if explicit_instance_id not in (None, ""):
            return str(explicit_instance_id).strip()
        clean_plan = str(plan_number or "").strip()
        if not clean_plan or self._is_mock_mode():
            return clean_plan

        try:
            with self.connect_to_database().connect() as connection:
                column = self._scope_column(connection, "review_scope")
                plan_int = self._coerce_scope_int(clean_plan)
                row = connection.execute(
                    sqlalchemy.text(f"""
                        SELECT {column} FROM {REVIEW_SCOPE_TABLE}
                        WHERE CAST({column} AS VARCHAR) = :plan_str
                           OR (:plan_int IS NOT NULL AND review_plan_id = :plan_int)
                        ORDER BY created_on DESC NULLS LAST LIMIT 1
                    """),
                    {"plan_str": clean_plan, "plan_int": plan_int},
                ).first()
                if row and row[0] is not None:
                    return str(row[0]).strip()
        except Exception as exc:
            logger.warning("Could not resolve review_scope_instance_id from %s for plan %s: %s", REVIEW_SCOPE_TABLE, clean_plan, exc)
        return clean_plan

    def get_data_extraction_rows_for_plan(
        self,
        plan_number: str,
        data_sources: Optional[List[str]] = None,
        review_scope_instance_id: Optional[Any] = None,
        require_db: bool = False,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Queries `dbaware_scoping.review_data_extraction` for the given plan/scope instance and
        returns a dict keyed by `data_source` ('policy', 'kod', 'procedure', 'findings_details',
        'historical_plan_details', 'rag_document_metadata') with the row primary key
        `review_scope_dataext_id` and `metadata` JSONB.
        """
        sources = list(
            data_sources
            or (
                "policy",
                "kod",
                "procedure",
                "findings_details",
                "historical_plan_details",
                "lrr",
                "rag_document_metadata",
            )
        )
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        if self._is_mock_mode():
            self._ensure_mock_plan_seeded(instance_id)
            store = _MOCK_DATA_EXTRACTION_STORE.get(instance_id, {})
            return {ds: dict(store[ds]) for ds in sources if ds in store}

        rows_by_source: Dict[str, Dict[str, Any]] = {}
        try:
            with self.connect_to_database().connect() as connection:
                column = self._scope_column(connection, "review_data_extraction")
                active_filter = " AND COALESCE(status, 1) != 0" if column == "review_scope_id" else ""
                scoped_val = (
                    self._coerce_scope_int(instance_id)
                    if column == "review_scope_id"
                    else instance_id
                )
                for ds in sources:
                    row = connection.execute(
                        sqlalchemy.text(f"""
                            SELECT review_scope_dataext_id, {column}, data_source, metadata
                            FROM {DATA_EXTRACTION_TABLE}
                            WHERE {column} = :instance_id AND data_source = :data_source{active_filter}
                            ORDER BY review_scope_dataext_id DESC LIMIT 1
                        """),
                        {"instance_id": scoped_val, "data_source": ds},
                    ).first()
                    if row is not None:
                        meta = row[3]
                        if isinstance(meta, str):
                            try:
                                meta = json.loads(meta)
                            except Exception:
                                pass
                        rows_by_source[ds] = {
                            "review_scope_dataext_id": row[0],
                            "review_scope_id": row[1],
                            "review_scope_instance_id": str(row[1]),
                            "data_source": str(row[2]),
                            "metadata": meta,
                            "table": DATA_EXTRACTION_TABLE,
                        }
            if rows_by_source:
                return rows_by_source
        except Exception as exc:
            logger.warning(
                "Could not query %s for instance %s (%s); using fallback row mapping.",
                DATA_EXTRACTION_TABLE,
                instance_id,
                exc,
            )
            if require_db:
                raise

        return {}

    def get_review_document_rows_for_plan(
        self,
        plan_number: str,
        review_scope_instance_id: Optional[Any] = None,
    ) -> List[Dict[str, Any]]:
        """
        Queries `dbaware_scoping.dbaware_review_documents` and returns rows with
        `review_document_instance_id` (PK), `review_scope_instance_id`, and `document_id`.
        """
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        if self._is_mock_mode():
            self._ensure_mock_plan_seeded(instance_id)
            return [dict(r) for r in _MOCK_REVIEW_DOCUMENTS_STORE.get(instance_id, [])]

        try:
            with self.connect_to_database().connect() as connection:
                column = self._scope_column(connection, "dbaware_review_documents")
                result = connection.execute(
                    sqlalchemy.text(f"""
                        SELECT review_document_instance_id, {column}, document_id
                        FROM {REVIEW_DOCUMENTS_TABLE}
                        WHERE {column} = :instance_id ORDER BY review_document_instance_id ASC
                    """),
                    {"instance_id": (self._coerce_scope_int(instance_id)
                                     if column == "review_scope_id" else instance_id)},
                )
                return [
                    {
                        "review_document_instance_id": int(r[0]) if r[0] is not None else None,
                        "review_scope_instance_id": str(r[1]),
                        "document_id": int(r[2]) if r[2] is not None else None,
                        "table": REVIEW_DOCUMENTS_TABLE,
                    }
                    for r in result
                ]
        except Exception as exc:
            logger.warning(
                "Could not query %s for instance %s (%s); using fallback rows.",
                REVIEW_DOCUMENTS_TABLE,
                instance_id,
                exc,
            )
            return []

    def update_data_extraction_row_by_pk(
        self,
        review_scope_dataext_id: Optional[Any],
        plan_number: str,
        data_source: str,
        metadata: Any,
        updated_by: Optional[str] = None,
        remarks: Optional[str] = None,
        review_scope_instance_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Updates (or inserts) the context JSON metadata row in `dbaware_scoping.review_data_extraction`
        by its primary key `review_scope_dataext_id` (or `(review_scope_instance_id, data_source)`).
        """
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        pk_int = (
            int(review_scope_dataext_id)
            if review_scope_dataext_id is not None and str(review_scope_dataext_id).isdigit()
            else None
        )

        if self._is_mock_mode():
            self._ensure_mock_plan_seeded(instance_id)
            existing_mock = _MOCK_DATA_EXTRACTION_STORE[instance_id].get(data_source) or {}
            resolved_mock_pk = pk_int or existing_mock.get("review_scope_dataext_id") or self._default_dataext_pk(instance_id, data_source)
            _MOCK_DATA_EXTRACTION_STORE[instance_id][data_source] = {
                "review_scope_dataext_id": resolved_mock_pk,
                "review_scope_instance_id": instance_id,
                "data_source": data_source,
                "metadata": metadata,
                "updated_by": updated_by,
                "remarks": remarks,
                "table": DATA_EXTRACTION_TABLE,
            }
            return {
                "table": DATA_EXTRACTION_TABLE,
                "review_scope_dataext_id": str(resolved_mock_pk),
                "review_scope_instance_id": instance_id,
                "data_source": data_source,
                "operation": "updated",
                "mode": "mock",
            }

        metadata_json = json.dumps(metadata, ensure_ascii=False, default=str)
        try:
            with self.connect_to_database().begin() as connection:
                column = self._scope_column(connection, "review_data_extraction")
                scope_value = self._coerce_scope_int(instance_id) if column == "review_scope_id" else instance_id
                if scope_value is None:
                    raise ValueError(f"Invalid integer review_scope_id: {instance_id!r}")
                rowcount = 0
                status_set = ", status = 1" if column == "review_scope_id" else ""
                if pk_int is not None:
                    res = connection.execute(
                        sqlalchemy.text(
                            f"""
                            UPDATE {DATA_EXTRACTION_TABLE}
                            SET metadata = CAST(:metadata AS JSONB),
                                updated_by = :updated_by,
                                updated_on = CURRENT_TIMESTAMP,
                                remarks = COALESCE(:remarks, remarks){status_set}
                                                        WHERE review_scope_dataext_id = :pk AND {column} = :instance_id
                                                            AND data_source = :data_source
                            """
                        ),
                        {
                            "pk": pk_int,
                            "instance_id": scope_value,
                            "data_source": data_source,
                            "metadata": metadata_json,
                            "updated_by": updated_by,
                            "remarks": remarks,
                        },
                    )
                    rowcount = int(res.rowcount or 0)

                if rowcount == 0:
                    res = connection.execute(
                        sqlalchemy.text(f"""
                            UPDATE {DATA_EXTRACTION_TABLE}
                            SET metadata = CAST(:metadata AS JSONB), updated_by = :updated_by,
                                updated_on = CURRENT_TIMESTAMP, remarks = COALESCE(:remarks, remarks){status_set}
                            WHERE {column} = :instance_id AND data_source = :data_source
                        """),
                        {"instance_id": scope_value, "data_source": data_source,
                         "metadata": metadata_json, "updated_by": updated_by, "remarks": remarks},
                    )
                    rowcount = int(res.rowcount or 0)

                if rowcount == 0:
                    self._ensure_review_scope_exists(
                        connection,
                        column,
                        scope_value,
                        plan_number=plan_number,
                        created_by=updated_by,
                        remarks=remarks,
                    )
                    status_col = ", status" if column == "review_scope_id" else ""
                    status_val = ", 1" if column == "review_scope_id" else ""
                    ins = connection.execute(
                        sqlalchemy.text(f"""
                            INSERT INTO {DATA_EXTRACTION_TABLE} (
                                {column}, data_source, metadata{status_col}, created_by, created_on, remarks
                            ) VALUES (
                                :instance_id, :data_source, CAST(:metadata AS JSONB){status_val},
                                :created_by, CURRENT_TIMESTAMP, :remarks
                            ) RETURNING review_scope_dataext_id
                        """),
                        {"instance_id": scope_value, "data_source": data_source,
                         "metadata": metadata_json, "created_by": updated_by, "remarks": remarks},
                    ).first()
                    if ins and ins[0] is not None:
                        pk_int = int(ins[0])
                    operation = "inserted"
                else:
                    operation = "updated"

            return {
                "table": DATA_EXTRACTION_TABLE,
                "review_scope_dataext_id": str(pk_int) if pk_int else None,
                "review_scope_instance_id": instance_id,
                "data_source": data_source,
                "operation": operation,
                "mode": "db",
            }
        except Exception as exc:
            logger.error("Failed to update %s for instance=%s source=%s: %s", DATA_EXTRACTION_TABLE, instance_id, data_source, exc, exc_info=True)
            return {
                "table": DATA_EXTRACTION_TABLE,
                "review_scope_dataext_id": str(pk_int) if pk_int else None,
                "review_scope_instance_id": instance_id,
                "data_source": data_source,
                "operation": "error",
                "mode": "db",
                "error": str(exc),
                "exception_type": type(exc).__name__,
                "db_host": self.db_host,
                "db_name": self.db_name,
                "db_port": self.db_port,
                "db_user": self.db_user,
            }

    def sync_review_document_reference(
        self,
        plan_number: str,
        action: str,
        document_id: Optional[Any] = None,
        review_scope_instance_id: Optional[Any] = None,
        review_document_instance_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Synchronizes `dbaware_scoping.dbaware_review_documents` when a document is included or excluded:
          - action == 'include': inserts `(review_scope_instance_id, document_id)` if not present
          - action == 'exclude': deletes matching row by `review_document_instance_id` or `(review_scope_instance_id, document_id)`
        """
        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        if self._is_mock_mode():
            self._ensure_mock_plan_seeded(instance_id)
        norm_action = "exclude" if str(action or "").lower() in {"exclude", "remove", "delete"} else "include"
        doc_id_int = int(document_id) if document_id is not None and str(document_id).lstrip("-").isdigit() else None
        row_pk_int = (
            int(review_document_instance_id)
            if review_document_instance_id is not None and str(review_document_instance_id).isdigit()
            else None
        )

        # Update mock store
        mock_rows = _MOCK_REVIEW_DOCUMENTS_STORE.setdefault(instance_id, [])
        if norm_action == "exclude":
            before = len(mock_rows)
            mock_rows[:] = [
                r for r in mock_rows
                if not (
                    (row_pk_int is not None and r.get("review_document_instance_id") == row_pk_int)
                    or (doc_id_int is not None and r.get("document_id") == doc_id_int)
                )
            ]
            removed_count = before - len(mock_rows)
            mock_result = {
                "table": REVIEW_DOCUMENTS_TABLE,
                "review_scope_instance_id": instance_id,
                "document_id": doc_id_int,
                "review_document_instance_id": row_pk_int,
                "operation": "deleted" if removed_count else "noop",
            }
        else:
            existing = next((r for r in mock_rows if doc_id_int is not None and r.get("document_id") == doc_id_int), None)
            if existing is None and doc_id_int is not None:
                next_pk = max((int(r.get("review_document_instance_id") or 0) for r in mock_rows), default=10000) + 1
                existing = {
                    "review_document_instance_id": next_pk,
                    "review_scope_instance_id": instance_id,
                    "document_id": doc_id_int,
                    "table": REVIEW_DOCUMENTS_TABLE,
                }
                mock_rows.append(existing)
                op = "inserted"
            else:
                op = "exists" if existing else "skipped"
            mock_result = {
                "table": REVIEW_DOCUMENTS_TABLE,
                "review_scope_instance_id": instance_id,
                "document_id": doc_id_int,
                "review_document_instance_id": existing.get("review_document_instance_id") if existing else row_pk_int,
                "operation": op,
            }

        if self._is_mock_mode():
            return mock_result
        if doc_id_int is None and row_pk_int is None:
            return {**mock_result, "operation": "skipped", "mode": "db"}

        try:
            with self.connect_to_database().begin() as connection:
                column = self._scope_column(connection, "dbaware_review_documents")
                scope_value = self._coerce_scope_int(instance_id) if column == "review_scope_id" else instance_id
                if scope_value is None:
                    raise ValueError(f"Invalid integer review_scope_id: {instance_id!r}")
                if norm_action == "exclude":
                    if row_pk_int is not None:
                        connection.execute(
                            sqlalchemy.text(
                                f"DELETE FROM {REVIEW_DOCUMENTS_TABLE} WHERE review_document_instance_id = :pk"
                            ),
                            {"pk": row_pk_int},
                        )
                    elif doc_id_int is not None:
                        connection.execute(
                            sqlalchemy.text(f"""
                                DELETE FROM {REVIEW_DOCUMENTS_TABLE}
                                WHERE {column} = :instance_id AND document_id = :doc_id
                            """),
                            {"instance_id": scope_value, "doc_id": doc_id_int},
                        )
                    return {**mock_result, "mode": "db"}
                else:
                    if doc_id_int is not None:
                        self._ensure_review_scope_exists(
                            connection,
                            column,
                            scope_value,
                            plan_number=plan_number,
                        )
                        row = connection.execute(
                            sqlalchemy.text(f"""
                                INSERT INTO {REVIEW_DOCUMENTS_TABLE} ({column}, document_id)
                                SELECT :instance_id, :doc_id WHERE NOT EXISTS (
                                    SELECT 1 FROM {REVIEW_DOCUMENTS_TABLE}
                                    WHERE {column} = :instance_id AND document_id = :doc_id
                                ) RETURNING review_document_instance_id
                            """),
                            {"instance_id": scope_value, "doc_id": doc_id_int},
                        ).first()
                        if row and row[0] is not None:
                            mock_result["review_document_instance_id"] = int(row[0])
                            mock_result["operation"] = "inserted"
                    return {**mock_result, "mode": "db"}
        except Exception as exc:
            logger.warning("Failed to sync %s for instance=%s action=%s: %s", REVIEW_DOCUMENTS_TABLE, instance_id, norm_action, exc)
            return {**mock_result, "operation": "error", "mode": "db", "error": str(exc)}

    def mutate_data_extraction_metadata(
        self,
        plan_number: str,
        document_type: str,
        action: str,
        *,
        filename: Optional[str] = None,
        storage_uri: Optional[str] = None,
        document_id: Optional[Any] = None,
        title: Optional[str] = None,
        section_id: Optional[Any] = None,
        section_title: Optional[str] = None,
        node_id: Optional[str] = None,
        sections: Optional[List[Dict[str, Any]]] = None,
        updated_by: Optional[str] = None,
        actor: Optional[str] = None,
        remarks: Optional[str] = None,
        review_scope_instance_id: Optional[Any] = None,
        review_scope_dataext_id: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Mutate the structured `metadata` JSONB on `dbaware_scoping.review_data_extraction`
        to soft-exclude or include an entire document or specific section(s) (`node_id` / `section_id`).
        """
        canonical_type = normalize_scoping_source(document_type) or str(document_type or "policy").strip().lower()
        db_data_source = source_to_db_data_source(canonical_type)
        is_exclude = str(action or "").strip().lower() in {"exclude", "remove", "delete", "excluded", "removed"}
        target_status = "excluded" if is_exclude else "active"

        instance_id = self.resolve_scope_instance_id(plan_number, review_scope_instance_id)
        rows = self.get_data_extraction_rows_for_plan(
            plan_number,
            data_sources=[db_data_source],
            review_scope_instance_id=instance_id,
            require_db=True,
        )
        row = rows.get(db_data_source) or {}
        existing_pk = review_scope_dataext_id or row.get("review_scope_dataext_id")
        raw_meta = row.get("metadata")

        if isinstance(raw_meta, dict):
            meta: Dict[str, Any] = dict(raw_meta)
            docs = list(meta.get("documents")) if isinstance(meta.get("documents"), list) else []
        elif isinstance(raw_meta, list):
            docs = [dict(x) for x in raw_meta if isinstance(x, dict)]
            meta = {"source_type": canonical_type, "documents": docs}
        else:
            docs = []
            meta = {"source_type": canonical_type, "documents": docs}

        bucket_name = (
            os.getenv("GCS_BUCKET_NAME", "").strip()
            or os.getenv("bucket_name", "").strip()
            or os.getenv("BUCKET_NAME", "").strip()
            or "db-dev-euwe3-gcs-155081-dbaware_review"
        )
        doc_id_str = str(document_id).strip() if document_id not in (None, "") else None
        sec_id_str = str(section_id).strip() if section_id not in (None, "") else None
        sec_title_str = str(section_title).strip() if section_title not in (None, "") else None
        node_id_str = str(node_id).strip() if node_id not in (None, "") else None
        title_str = str(title).strip() if title not in (None, "") else None
        had_explicit_file_or_sec = bool(
            filename or storage_uri or sections or sec_id_str or sec_title_str or node_id_str
            or title_str or doc_id_str
        )

        if not filename:
            if canonical_type in ("policy", "kod", "procedure") and doc_id_str:
                filename = f"{canonical_type}{doc_id_str}.json"
            elif canonical_type == "gfms":
                filename = "findings_details.json"
            elif canonical_type == "historical_scoping_document":
                filename = "historical_plan_details.json"
            elif canonical_type == "lrr":
                filename = "internet_search_data_enriched.json"

        if not storage_uri and filename:
            if canonical_type in ("policy", "kod", "procedure"):
                storage_uri = f"gs://{bucket_name}/dbaware_review_{plan_number}/inbound-data/policy/relevant_{canonical_type}/{filename}"
            elif canonical_type == "gfms":
                storage_uri = f"gs://{bucket_name}/dbaware_review_{plan_number}/inbound-data/gfms/{filename}"
            elif canonical_type == "historical_scoping_document":
                storage_uri = f"gs://{bucket_name}/dbaware_review_{plan_number}/inbound-data/dbaware/{filename}"
            elif canonical_type == "lrr":
                storage_uri = f"gs://{bucket_name}/dbaware_review_{plan_number}/inbound-data/lrr/{filename}"

        # Determine if this is a section-level mutation
        is_section_op = bool(sec_id_str or sec_title_str or node_id_str)
        if not is_section_op and canonical_type in ("gfms", "historical_scoping_document", "lrr"):
            # If user specified a specific finding ID, historical plan number, or LRR mandate rather than the whole file
            whole_names = {
                "findings_details.json",
                "findings_details",
                "gfms",
                "gfms data",
                "gfms findings details",
                "historical_plan_details.json",
                "historical_plan_details",
                "historical plan details",
                "historical scoping documents",
                "internet_search_data_enriched.json",
                "internet_search_data.json",
                "lrr",
                "laws rules and regulations",
                "laws, rules, and regulations",
                "regulations",
                "regulatory",
                "regulatory mandates",
            }
            candidate_label = (title_str or doc_id_str or "").lower()
            if candidate_label and candidate_label not in whole_names:
                is_section_op = True
                if not sec_id_str and doc_id_str and doc_id_str.lower() not in whole_names:
                    sec_id_str = doc_id_str
                if not sec_title_str and title_str and title_str.lower() not in whole_names:
                    sec_title_str = title_str

        matched_doc: Optional[Dict[str, Any]] = None
        for d in docs:
            if not isinstance(d, dict):
                continue
            d_fname = str(d.get("filename") or "").strip().lower()
            d_id = str(d.get("document_id") or d.get("id") or "").strip().lower()
            d_title = str(d.get("document_title") or d.get("title") or "").strip().lower()
            if filename and d_fname == filename.strip().lower():
                matched_doc = d
                break
            if doc_id_str and d_id == doc_id_str.lower():
                matched_doc = d
                break
            if title_str and d_title == title_str.lower():
                matched_doc = d
                break
            # Also check if any section inside `d` matches the target section/node
            for s in d.get("sections") or []:
                if not isinstance(s, dict):
                    continue
                if node_id_str and str(s.get("node_id") or "").strip().lower() == node_id_str.lower():
                    matched_doc = d
                    break
                if sec_id_str and str(s.get("section_id") or "").strip().lower() == sec_id_str.lower():
                    matched_doc = d
                    break
                if sec_title_str and str(s.get("section_title") or "").strip().lower() == sec_title_str.lower():
                    matched_doc = d
                    break
            if matched_doc is not None:
                break

        matched_existing_db_doc = matched_doc is not None
        if matched_doc is None:
            if is_exclude and not had_explicit_file_or_sec:
                return {
                    "updated": False,
                    "matched_existing_db_doc": False,
                    "table": DATA_EXTRACTION_TABLE,
                    "data_source": db_data_source,
                    "review_scope_instance_id": instance_id,
                }
            default_doc_id = (
                "findings_details"
                if canonical_type == "gfms"
                else "historical_plan_details"
                if canonical_type == "historical_scoping_document"
                else "lrr_internet_search_data_enriched"
                if canonical_type == "lrr"
                else (doc_id_str or "1")
            )
            default_doc_title = (
                "GFMS Findings Details"
                if canonical_type == "gfms" and is_section_op
                else "Historical Plan Details"
                if canonical_type == "historical_scoping_document" and is_section_op
                else "Regulatory & Internet Search Mandates"
                if canonical_type == "lrr" and is_section_op
                else (title_str or filename or f"{canonical_type}_{default_doc_id}")
            )
            matched_doc = {
                "filename": filename or f"{canonical_type}{default_doc_id}.json",
                "storage_uri": storage_uri or "",
                "document_id": default_doc_id,
                "document_title": default_doc_title,
                "document_type": canonical_type,
                "status": "active" if is_section_op else target_status,
                "excluded": False if is_section_op else is_exclude,
                "sections": list(sections) if isinstance(sections, list) else [],
            }
            docs.append(matched_doc)

        doc_sections = matched_doc.get("sections")
        if not isinstance(doc_sections, list):
            doc_sections = []
            matched_doc["sections"] = doc_sections

        has_any_indexed_sections = any(
            isinstance(d, dict) and isinstance(d.get("sections"), list) and len(d.get("sections") or []) > 0
            for d in docs
        )
        if is_section_op:
            sec_matched = False
            for s in doc_sections:
                if not isinstance(s, dict):
                    continue
                s_id = str(s.get("section_id") or "").strip().lower()
                s_title = str(s.get("section_title") or "").strip().lower()
                s_node = str(s.get("node_id") or "").strip().lower()
                if (
                    (node_id_str and s_node == node_id_str.lower())
                    or (sec_id_str and s_id == sec_id_str.lower())
                    or (sec_title_str and (s_title == sec_title_str.lower() or sec_title_str.lower() in s_title))
                ):
                    s["status"] = target_status
                    s["excluded"] = is_exclude
                    sec_matched = True

            # Sync bidirectional updates across historical_plan_details.json and historical PDF docs
            if canonical_type == "historical_scoping_document":
                target_hist_ids = {
                    str(v).strip().lower()
                    for v in (sec_id_str, doc_id_str)
                    if v and str(v).strip().lower() not in {"historical_plan_details", "historical_plan_details.json"}
                }
                target_hist_title = (sec_title_str or title_str or "").strip().lower()
                if target_hist_title in {"historical_plan_details.json", "historical plan details", "historical_plan_details"}:
                    target_hist_title = ""

                if str(matched_doc.get("filename") or "").strip().lower().endswith(".pdf") and (
                    sec_matched
                    or str(matched_doc.get("document_id") or "").strip().lower() in target_hist_ids
                    or str(matched_doc.get("historic_plan_number") or "").strip().lower() in target_hist_ids
                ):
                    matched_doc["status"] = target_status
                    matched_doc["excluded"] = is_exclude
                    sec_matched = True

                for d in docs:
                    if d is matched_doc or not isinstance(d, dict):
                        continue
                    d_fname = str(d.get("filename") or "").strip().lower()
                    d_id = str(d.get("document_id") or d.get("historic_plan_number") or "").strip().lower()
                    d_title = str(d.get("document_title") or "").strip().lower()
                    is_pdf_doc = d_fname.endswith(".pdf") or d_id in target_hist_ids
                    title_hits_pdf = bool(target_hist_title and d_title and target_hist_title in d_title)
                    if is_pdf_doc and (d_id in target_hist_ids or title_hits_pdf):
                        d["status"] = target_status
                        d["excluded"] = is_exclude
                        for s in d.get("sections") or []:
                            if isinstance(s, dict):
                                s["status"] = target_status
                                s["excluded"] = is_exclude
                        sec_matched = True
                        continue

                    for s in d.get("sections") or []:
                        if not isinstance(s, dict):
                            continue
                        s_id = str(s.get("section_id") or "").strip().lower()
                        s_node = str(s.get("node_id") or "").strip().lower()
                        s_title = str(s.get("section_title") or "").strip().lower()
                        if (
                            (node_id_str and s_node == node_id_str.lower())
                            or (s_id and s_id in target_hist_ids)
                            or any(s_node == f"historical_plan:{hid}" for hid in target_hist_ids)
                            or (target_hist_title and s_title and target_hist_title in s_title)
                        ):
                            s["status"] = target_status
                            s["excluded"] = is_exclude
                            sec_matched = True
                            if not is_exclude:
                                d["excluded"] = False
                                d["status"] = "active"

            if not sec_matched and is_exclude and canonical_type in ("gfms", "historical_scoping_document", "lrr") and (doc_sections or has_any_indexed_sections):
                return {
                    "updated": False,
                    "matched_existing_db_doc": matched_existing_db_doc,
                    "table": DATA_EXTRACTION_TABLE,
                    "data_source": db_data_source,
                    "review_scope_instance_id": instance_id,
                    "reason": f"Target '{sec_id_str or sec_title_str or node_id_str}' not found in {db_data_source}.",
                }

            if not sec_matched:
                eff_sec_id = sec_id_str or doc_id_str or "1"
                eff_sec_title = sec_title_str or title_str or f"Section {eff_sec_id}"
                if canonical_type == "gfms":
                    eff_node_id = node_id_str or f"gfms:finding:{eff_sec_id}"
                elif canonical_type == "historical_scoping_document":
                    eff_node_id = node_id_str or f"historical_plan:{eff_sec_id}"
                elif canonical_type == "lrr":
                    eff_node_id = node_id_str or f"lrr:mandate:{eff_sec_id}"
                else:
                    eff_node_id = node_id_str or f"{matched_doc.get('document_id') or 'doc'}:section:{eff_sec_id}"
                doc_sections.append(
                    {
                        "section_id": eff_sec_id,
                        "section_title": eff_sec_title,
                        "node_id": eff_node_id,
                        "status": target_status,
                        "excluded": is_exclude,
                    }
                )

            if not is_exclude and not str(matched_doc.get("filename") or "").strip().lower().endswith(".pdf"):
                matched_doc["excluded"] = False
                matched_doc["status"] = "active"
        else:
            matched_doc["status"] = target_status
            matched_doc["excluded"] = is_exclude
            for s in doc_sections:
                if isinstance(s, dict):
                    s["status"] = target_status
                    s["excluded"] = is_exclude

        meta["documents"] = docs
        res = self.update_data_extraction_row_by_pk(
            review_scope_dataext_id=existing_pk,
            plan_number=plan_number,
            data_source=db_data_source,
            metadata=meta,
            updated_by=updated_by or actor or "SYSTEM",
            remarks=remarks or f"{action} {canonical_type}: {title_str or filename or doc_id_str}",
            review_scope_instance_id=instance_id,
        )
        res["updated"] = res.get("operation") in {"updated", "inserted"} and res.get("mode") in {"db", "mock"}
        res["matched_existing_db_doc"] = matched_existing_db_doc
        return res

