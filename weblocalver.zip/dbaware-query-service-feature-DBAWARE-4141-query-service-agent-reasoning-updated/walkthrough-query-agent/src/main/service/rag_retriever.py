import asyncio
import logging
import os
import sys
from typing import Any, Dict, List, Optional

import httpx
from agent_helper.env_config import EnvironmentConfig

try:
    from service.database_connector import DatabaseConnector
except Exception:
    DatabaseConnector = None

logger = logging.getLogger(__name__)

env_var = os.getenv("ENV_NAME", "dev")
env_config = EnvironmentConfig(env_var)

# Resolve RAG service configuration from environment config YAML with environment variable fallbacks
RAG_SERVICE_URL = (
    env_config.get_env_config("RAG_SERVICE_URL")
    or os.getenv("RAG_SERVICE_URL", "https://ct1-cta.dbaware.dev.gcp.db.com/dbaware-rag-service-api-dev/query-documents")
)
RAG_BASE_URL = (
    env_config.get_env_config("RAG_BASE_URL")
    or os.getenv("RAG_BASE_URL")
    or (
        RAG_SERVICE_URL.rsplit("/query-documents", 1)[0]
        if "/query-documents" in RAG_SERVICE_URL
        else RAG_SERVICE_URL.rstrip("/")
    )
)
RAG_SERVICE_TIMEOUT = float(
    env_config.get_env_config("RAG_SERVICE_TIMEOUT")
    or os.getenv("RAG_SERVICE_TIMEOUT", "30.0")
)


def _get_rag_base_url() -> str:
    """Resolves the base URL for dbaware-rag-service endpoints."""
    explicit_base = env_config.get_env_config("RAG_BASE_URL") or os.getenv("RAG_BASE_URL")
    if explicit_base:
        return str(explicit_base).rstrip("/")
    service_url = (
        env_config.get_env_config("RAG_SERVICE_URL")
        or os.getenv("RAG_SERVICE_URL")
        or RAG_SERVICE_URL
    )
    if "/query-documents" in service_url:
        return service_url.rsplit("/query-documents", 1)[0].rstrip("/")
    return service_url.rstrip("/")


def _resolve_db_connector():
    """Dynamically resolves DatabaseConnector to support patching across modules in test environments."""
    qna_mod = sys.modules.get("service.qna_service")
    if qna_mod and hasattr(qna_mod, "DatabaseConnector"):
        return getattr(qna_mod, "DatabaseConnector")
    return DatabaseConnector


def extract_plan_document_ids(
    raw_json: Optional[Dict[str, Any]] = None,
    user_details: Optional[Dict[str, Any]] = None,
) -> Dict[str, List[int]]:
    """
    Resolves scoped document IDs supporting both:
      - Option B: Cached plan metadata / stage summary (raw_json)
      - Option A: Scoped instance identifiers from API Gateway userDetails
    """
    doc_ids_by_type: Dict[str, List[int]] = {"policy": [], "kod": [], "procedure": []}

    # Option A: Inspect userDetails injected by API Gateway / caller
    if user_details and isinstance(user_details, dict):
        explicit_docs = user_details.get("document_ids") or user_details.get("documents")
        if isinstance(explicit_docs, dict):
            for doc_type in ["policy", "kod", "procedure"]:
                ids = explicit_docs.get(doc_type) or []
                doc_ids_by_type[doc_type].extend([int(i) for i in ids if str(i).isdigit()])
        elif isinstance(explicit_docs, list):
            for item in explicit_docs:
                if isinstance(item, dict) and "document_id" in item:
                    dtype = str(item.get("document_type", "policy")).lower()
                    if dtype in doc_ids_by_type and str(item["document_id"]).isdigit():
                        doc_ids_by_type[dtype].append(int(item["document_id"]))

    # Option B: Inspect cached plan stage JSON metadata
    if raw_json and isinstance(raw_json, dict):
        dicts_to_inspect = [raw_json]

        def _collect_dicts(item: Any):
            if isinstance(item, dict):
                dicts_to_inspect.append(item)
                for v in item.values():
                    _collect_dicts(v)
            elif isinstance(item, list):
                for elem in item:
                    if isinstance(elem, dict):
                        dicts_to_inspect.append(elem)
                        if "document_id" in elem and "document_type" in elem:
                            dtype = str(elem["document_type"]).lower()
                            if dtype in doc_ids_by_type and str(elem["document_id"]).isdigit():
                                doc_ids_by_type[dtype].append(int(elem["document_id"]))
                        for v in elem.values():
                            _collect_dicts(v)

        for val in list(raw_json.values()):
            _collect_dicts(val)
        for d in dicts_to_inspect:
            for doc_type in ["policy", "kod", "procedure"]:
                candidates = d.get(f"{doc_type}_document_ids") or d.get(f"{doc_type}_ids") or []
                if isinstance(candidates, list):
                    doc_ids_by_type[doc_type].extend([int(i) for i in candidates if str(i).isdigit()])

    # Deduplicate while preserving order
    for doc_type in doc_ids_by_type:
        doc_ids_by_type[doc_type] = list(dict.fromkeys(doc_ids_by_type[doc_type]))

    return doc_ids_by_type


async def fetch_document_ids_from_scoping_db(instance_id: int) -> Dict[str, List[int]]:
    """Queries scoping-db using DatabaseConnector in an async thread to avoid blocking the event loop."""
    empty_defaults: Dict[str, List[int]] = {"policy": [], "kod": [], "procedure": []}
    mock_defaults: Dict[str, List[int]] = {
        "policy": [1, 2, 3],
        "kod": [121, 43, 27],
        "procedure": [13, 17, 194],
    }
    is_mock_mode = os.getenv("MOCK_SCOPING_DB", "").strip().lower() in ("true", "1", "yes")
    connector_cls = _resolve_db_connector()
    if connector_cls is None:
        if is_mock_mode:
            logger.warning("⚠️ DatabaseConnector module unavailable in runtime. Using mock scoping document IDs for instance %s.", instance_id)
            return mock_defaults
        logger.warning("⚠️ DatabaseConnector module unavailable in runtime for instance %s. Returning empty document IDs.", instance_id)
        return empty_defaults
    try:
        def _query():
            connector = connector_cls()
            return connector.get_document_ids_for_scope_instance(instance_id)

        docs = await asyncio.to_thread(_query)
        logger.info("🔌 Resolved %d document IDs from scoping-db for instance %s: %s", sum(len(v) for v in docs.values()), instance_id, docs)
        return docs
    except Exception as e:
        if is_mock_mode:
            logger.warning("⚠️ Could not fetch document IDs from scoping-db for instance %s (%s). Using fallback mock IDs.", instance_id, str(e))
            return mock_defaults
        logger.warning("⚠️ Could not fetch document IDs from scoping-db for instance %s (%s). Returning empty document IDs.", instance_id, str(e))
        return empty_defaults


def extract_rag_ingest_document_ids(payload: Any) -> List[int]:
    """
    Extracts numeric document IDs from dbaware-rag-service `/ingest-documents` and `/ingest-jobs/{job_id}` payloads.
    Supports both top-level `document_ids` and real RAG service `indexed` / `already_indexed` lists.
    """
    candidates: List[Any] = []
    if isinstance(payload, dict):
        for container in (payload, payload.get("data"), payload.get("result"), payload.get("details")):
            if not isinstance(container, dict):
                continue
            for list_key in ("document_ids", "doc_ids", "ids", "policy_ids", "kod_ids", "procedure_ids"):
                raw_list = container.get(list_key)
                if isinstance(raw_list, list):
                    candidates.extend(raw_list)
            for group_key in ("already_indexed", "indexed", "documents", "results", "files", "ingested_documents"):
                group_val = container.get(group_key)
                if isinstance(group_val, list):
                    for entry in group_val:
                        if isinstance(entry, dict):
                            did = entry.get("document_id") if entry.get("document_id") is not None else entry.get("doc_id")
                            if did is None:
                                did = entry.get("id")
                            if did is not None:
                                candidates.append(did)
                        elif isinstance(entry, (int, str)):
                            candidates.append(entry)

    out: List[int] = []
    seen = set()
    for val in candidates:
        if isinstance(val, bool) or val is None:
            continue
        sval = str(val).strip()
        if sval.lstrip("-").isdigit():
            ival = int(sval)
            if ival not in seen:
                seen.add(ival)
                out.append(ival)
    return out


def should_query_rag_service(query: str) -> bool:
    """Checks if the query touches governance, policy, KOD, procedure, or control standards."""
    q = query.lower()
    rag_triggers = [
        "policy", "policies", "kod", "kods", "procedure", "procedures", "manual",
        "standard", "standards", "detective control", "threshold", "venue", "gbsa",
        "german", "order", "feed", "rule", "rules", "governance", "requirement",
        "obligation", "operating instruction", "10gb", "bandwidth",
    ]
    return any(k in q for k in rag_triggers)


async def fetch_rag_document_chunks(
    query: str,
    document_ids_map: Optional[Dict[str, List[int]]] = None,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """Dispatches an HTTP POST query to dbaware-rag-service (/query-documents) on port 5001."""
    doc_ids_map = document_ids_map or {}
    queries_payload = []

    for doc_type in ["policy", "kod", "procedure"]:
        doc_ids = doc_ids_map.get(doc_type, [])
        query_item: Dict[str, Any] = {"document_type": doc_type, "query": query, "top_k": top_k}
        if doc_ids:
            query_item["document_ids"] = doc_ids
        queries_payload.append(query_item)

    request_body = {"queries": queries_payload}
    logger.info("🌐 Calling dbaware-rag-service at %s with %d queries...", RAG_SERVICE_URL, len(queries_payload))

    rag_trust_env = os.getenv("RAG_TRUST_ENV", "false").lower() in ("true", "1", "yes")
    try:
        async with httpx.AsyncClient(
            timeout=RAG_SERVICE_TIMEOUT,
            verify=False,
            trust_env=rag_trust_env,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        ) as client:
            response = await client.post(RAG_SERVICE_URL, json=request_body)
            if response.status_code != 200:
                logger.warning("⚠️ dbaware-rag-service failed with status %d: %s", response.status_code, response.text)
                return []
            data = response.json()
            results = data.get("results", [])
            logger.info("✅ Received %d category result(s) from dbaware-rag-service.", len(results))
            return results
    except httpx.HTTPError as http_err:
        cause = getattr(http_err, "__cause__", None) or http_err
        logger.warning("⚠️ HTTP connection error calling dbaware-rag-service (%s): %r (Cause: %r)", RAG_SERVICE_URL, http_err, cause)
        return []
    except Exception as e:
        logger.warning("⚠️ Unexpected error retrieving chunks from dbaware-rag-service: %r", e, exc_info=True)
        return []


def _normalize_multipart_file_entry(field_name: str, entry: Any) -> Optional[tuple]:
    """Converts a file specification into an httpx multipart file tuple: (field_name, (filename, content, content_type))."""
    if entry is None:
        return None
    if isinstance(entry, tuple):
        if len(entry) == 2 and isinstance(entry[0], str) and isinstance(entry[1], tuple):
            return entry
        if len(entry) >= 2:
            filename = str(entry[0])
            content = entry[1]
            content_type = str(entry[2]) if len(entry) > 2 else "application/octet-stream"
            if isinstance(content, str):
                content = content.encode("utf-8")
            return (field_name, (filename, content, content_type))
    if isinstance(entry, dict):
        filename = str(entry.get("filename") or entry.get("file_name") or "uploaded_document.pdf")
        content = entry.get("content") if entry.get("content") is not None else entry.get("data", b"")
        if isinstance(content, str):
            content = content.encode("utf-8")
        content_type = str(entry.get("content_type") or "application/octet-stream")
        return (field_name, (filename, content, content_type))
    return None


async def ingest_documents_to_rag(
    policy_files: Optional[List[Any]] = None,
    kod_files: Optional[List[Any]] = None,
    procedure_files: Optional[List[Any]] = None,
    files: Optional[List[Any]] = None,
    default_document_type: str = "policy",
) -> Dict[str, Any]:
    """
    Calls POST {RAG_BASE_URL}/ingest-documents using multipart/form-data.
    Supports explicit policy_files, kod_files, procedure_files lists, as well as generic files
    mapped to `{default_document_type}_files` (or per-item `document_type`).
    """
    base_url = _get_rag_base_url()
    ingest_url = f"{base_url}/ingest-documents"

    multipart_files: List[tuple] = []
    field_map = {
        "policy": "policy_files",
        "kod": "kod_files",
        "procedure": "procedure_files",
    }

    for doc_type, entries in (
        ("policy", policy_files or []),
        ("kod", kod_files or []),
        ("procedure", procedure_files or []),
    ):
        field_name = field_map[doc_type]
        for item in entries:
            normalized = _normalize_multipart_file_entry(field_name, item)
            if normalized:
                multipart_files.append(normalized)

    fallback_type = (default_document_type or "policy").strip().lower()
    if fallback_type not in field_map:
        fallback_type = "policy"

    for item in files or []:
        item_type = fallback_type
        if isinstance(item, dict) and item.get("document_type"):
            candidate_type = str(item.get("document_type")).strip().lower()
            if candidate_type in field_map:
                item_type = candidate_type
        normalized = _normalize_multipart_file_entry(field_map[item_type], item)
        if normalized:
            multipart_files.append(normalized)

    if not multipart_files:
        raise ValueError("At least one file must be provided for RAG document ingestion.")

    logger.info("🌐 Calling RAG ingest_documents at %s with %d file(s)...", ingest_url, len(multipart_files))
    rag_trust_env = os.getenv("RAG_TRUST_ENV", "false").lower() in ("true", "1", "yes")
    try:
        async with httpx.AsyncClient(
            timeout=max(RAG_SERVICE_TIMEOUT, 60.0),
            verify=False,
            trust_env=rag_trust_env,
        ) as client:
            response = await client.post(ingest_url, files=multipart_files)
            if response.status_code not in (200, 201, 202):
                logger.warning("⚠️ RAG ingest-documents failed with status %d: %s", response.status_code, response.text)
                return {
                    "status": "error",
                    "status_code": response.status_code,
                    "message": f"RAG ingest-documents failed with status {response.status_code}: {response.text}",
                }
            data = response.json()
            if isinstance(data, dict):
                data.setdefault("status", "accepted")
                extracted_ids = extract_rag_ingest_document_ids(data)
                if extracted_ids and not data.get("document_ids"):
                    data["document_ids"] = extracted_ids
                return data
            return {"status": "accepted", "data": data}
    except Exception as e:
        logger.warning("⚠️ Error calling RAG ingest-documents (%s): %r", ingest_url, e, exc_info=True)
        return {
            "status": "error",
            "message": f"Error calling RAG ingest-documents: {str(e)}",
        }


async def get_rag_ingest_job_status(job_id: str) -> Dict[str, Any]:
    """Calls GET {RAG_BASE_URL}/ingest-jobs/{job_id} to check RAG ingestion job status."""
    clean_job_id = str(job_id or "").strip()
    if not clean_job_id:
        raise ValueError("job_id is required to query RAG ingest job status.")

    base_url = _get_rag_base_url()
    job_url = f"{base_url}/ingest-jobs/{clean_job_id}"
    logger.info("🌐 Polling RAG ingest job status at %s...", job_url)
    rag_trust_env = os.getenv("RAG_TRUST_ENV", "false").lower() in ("true", "1", "yes")
    try:
        async with httpx.AsyncClient(
            timeout=RAG_SERVICE_TIMEOUT,
            verify=False,
            trust_env=rag_trust_env,
            headers={"Accept": "application/json"},
        ) as client:
            response = await client.get(job_url)
            if response.status_code != 200:
                logger.warning("⚠️ RAG get_job_status failed with status %d: %s", response.status_code, response.text)
                return {
                    "job_id": clean_job_id,
                    "status": "error",
                    "status_code": response.status_code,
                    "message": f"RAG ingest job status check failed with status {response.status_code}: {response.text}",
                }
            data = response.json()
            if isinstance(data, dict):
                data.setdefault("job_id", clean_job_id)
                extracted_ids = extract_rag_ingest_document_ids(data)
                if extracted_ids and not data.get("document_ids"):
                    data["document_ids"] = extracted_ids
                return data
            return {"job_id": clean_job_id, "status": "completed", "data": data}
    except Exception as e:
        logger.warning("⚠️ Error calling RAG get_job_status (%s): %r", job_url, e, exc_info=True)
        return {
            "job_id": clean_job_id,
            "status": "error",
            "message": f"Error calling RAG get_job_status: {str(e)}",
        }


async def categorize_rag_document_ids(document_ids: List[int]) -> Dict[str, Any]:
    """Calls POST {RAG_BASE_URL}/categorize-document-ids with {"document_ids": [...]}."""
    normalized_ids = [int(doc_id) for doc_id in (document_ids or []) if str(doc_id).lstrip("-").isdigit()]
    if not normalized_ids:
        raise ValueError("At least one numeric document_id is required for categorization.")

    base_url = _get_rag_base_url()
    categorize_url = f"{base_url}/categorize-document-ids"
    request_body = {"document_ids": normalized_ids}
    logger.info("🌐 Calling RAG categorize-document-ids at %s for IDs %s...", categorize_url, normalized_ids)

    rag_trust_env = os.getenv("RAG_TRUST_ENV", "false").lower() in ("true", "1", "yes")
    try:
        async with httpx.AsyncClient(
            timeout=RAG_SERVICE_TIMEOUT,
            verify=False,
            trust_env=rag_trust_env,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        ) as client:
            response = await client.post(categorize_url, json=request_body)
            if response.status_code != 200:
                logger.warning("⚠️ RAG categorize-document-ids failed with status %d: %s", response.status_code, response.text)
                return {
                    "status": "error",
                    "status_code": response.status_code,
                    "document_ids": normalized_ids,
                    "message": f"RAG categorize-document-ids failed with status {response.status_code}: {response.text}",
                }
            data = response.json()
            if isinstance(data, dict):
                data.setdefault("status", "success")
                return data
            return {"status": "success", "results": data}
    except Exception as e:
        logger.warning("⚠️ Error calling RAG categorize-document-ids (%s): %r", categorize_url, e, exc_info=True)
        return {
            "status": "error",
            "document_ids": normalized_ids,
            "message": f"Error calling RAG categorize-document-ids: {str(e)}",
        }


def build_rag_relevant_data_payload(
    plan_number: str,
    documents: List[Dict[str, Any]],
    overrides: Optional[Dict[str, Any]] = None,
    gcs_utils: Optional[Any] = None,
) -> Dict[str, Any]:
    """
    Constructs the request payload for POST /get-relevant-data-for-documents.
    Automatically enriches plan and control details from GCS inbound data when available,
    and merges any explicit caller overrides.
    """
    overrides = dict(overrides or {})
    clean_plan = str(plan_number or overrides.get("review_id") or "0").strip()
    review_id = str(overrides.get("review_id") if overrides.get("review_id") is not None else clean_plan).strip() or "0"

    plan_data: Dict[str, Any] = {}
    control_records: List[Dict[str, Any]] = []

    if gcs_utils is not None and clean_plan:
        plan_blob = f"dbaware_review_{clean_plan}/inbound-data/dbaware/plan_details.json"
        control_blob = f"dbaware_review_{clean_plan}/inbound-data/dbgrc/control_details.json"
        try:
            if gcs_utils.blob_exists(plan_blob):
                raw_plan = gcs_utils.read_blob_json(plan_blob)
                if isinstance(raw_plan, list) and raw_plan and isinstance(raw_plan[0], dict):
                    plan_data = raw_plan[0]
                elif isinstance(raw_plan, dict):
                    plan_data = raw_plan
        except Exception as e:
            logger.debug("Could not load plan_details.json for plan %s: %s", clean_plan, e)

        try:
            if gcs_utils.blob_exists(control_blob):
                raw_ctrl = gcs_utils.read_blob_json(control_blob)
                if isinstance(raw_ctrl, list):
                    control_records = [r for r in raw_ctrl if isinstance(r, dict)]
                elif isinstance(raw_ctrl, dict):
                    if isinstance(raw_ctrl.get("included_kcs"), list):
                        control_records = [r for r in raw_ctrl["included_kcs"] if isinstance(r, dict)]
                    else:
                        control_records = [raw_ctrl]
        except Exception as e:
            logger.debug("Could not load control_details.json for plan %s: %s", clean_plan, e)

    def _as_str_list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, (list, tuple, set)):
            return [str(v).strip() for v in value if str(v).strip()]
        text_val = str(value)
        sep = ";" if ";" in text_val else ","
        return [part.strip() for part in text_val.split(sep) if part.strip()]

    raw_region = (
        overrides.get("region")
        if overrides.get("region") is not None
        else (plan_data.get("UoT Regions") or plan_data.get("plan_item_Applicable_Region") or "")
    )
    if isinstance(raw_region, (list, tuple, set)):
        region = ", ".join(str(v).strip() for v in raw_region if str(v).strip())
    else:
        region = str(raw_region or "").strip()

    au_countries = _as_str_list(
        overrides.get("au_countries")
        or plan_data.get("UoT Countries")
        or plan_data.get("assessable_unit_Countires")
    )

    au_list_raw = overrides.get("au_list")
    if au_list_raw is None:
        au_str = str(plan_data.get("assessable_unit_List") or "")
        if au_str:
            au_list = [s.strip() for s in au_str.split("),") if s.strip()]
        else:
            au_list = []
            for row in (plan_data.get("AU-RT-KC") or []) if isinstance(plan_data.get("AU-RT-KC"), list) else []:
                if isinstance(row, dict) and row.get("AU"):
                    au_parts = [p.strip() for p in str(row["AU"]).split("~")]
                    au_list.append(au_parts[4] if len(au_parts) > 4 and au_parts[4] else str(row["AU"]).strip())
    else:
        au_list = [str(v).strip() for v in (au_list_raw if isinstance(au_list_raw, list) else [au_list_raw]) if str(v).strip()]

    rt_list_raw = overrides.get("rt_list")
    if rt_list_raw is None:
        rt_str = str(plan_data.get("risk_themes_List") or plan_data.get("UoT Risk Type") or "").strip()
        rt_list = [s.strip() for s in rt_str.split("),") if s.strip()] if rt_str else []
    else:
        rt_list = [str(v).strip() for v in (rt_list_raw if isinstance(rt_list_raw, list) else [rt_list_raw]) if str(v).strip()]

    kc_list_raw = overrides.get("kc_list")
    if kc_list_raw is None:
        kc_str = str(plan_data.get("key_control_List") or plan_data.get("UoT KCs") or "").strip()
        sep = ";" if ";" in kc_str else "), "
        kc_list = [s.strip() for s in kc_str.split(sep) if s.strip()] if kc_str else []
    else:
        kc_list = [str(v).strip() for v in (kc_list_raw if isinstance(kc_list_raw, list) else [kc_list_raw]) if str(v).strip()]

    def _collect_control_field(field_key: str, override_key: str) -> List[str]:
        if override_key in overrides and overrides[override_key] is not None:
            val = overrides[override_key]
            return [str(v).strip() for v in (val if isinstance(val, list) else [val]) if str(v).strip()]
        seen: Dict[str, None] = {}
        for rec in control_records:
            val = rec.get(field_key)
            if not val:
                inv = rec.get("inventory") if isinstance(rec.get("inventory"), dict) else {}
                det = rec.get("details") if isinstance(rec.get("details"), dict) else {}
                if override_key == "control_name":
                    val = inv.get("controlDefinitionNumber") or inv.get("externalReferenceId") or det.get("control_name") or det.get("name") or rec.get("controlIdentifier")
                elif override_key == "control_how":
                    val = det.get("control_how") or det.get("how") or det.get("description") or inv.get("controlHow") or inv.get("controlDescription")
                elif override_key == "control_what":
                    val = det.get("control_what") or det.get("what") or inv.get("controlWhat")
                elif override_key == "control_why":
                    val = det.get("control_why") or det.get("why") or inv.get("controlWhy")
            if val and isinstance(val, str) and val.strip():
                seen[val.strip()] = None
        return list(seen.keys())

    normalized_docs: List[Dict[str, Any]] = []
    for doc_spec in documents or []:
        if not isinstance(doc_spec, dict):
            continue
        dtype = str(doc_spec.get("document_type") or "policy").strip().lower()
        raw_ids = doc_spec.get("document_ids") or []
        doc_ids = [int(i) for i in raw_ids if str(i).lstrip("-").isdigit()]
        top_k = int(doc_spec.get("top_k", 5) or 5)
        normalized_docs.append({
            "document_type": dtype,
            "document_ids": doc_ids,
            "top_k": top_k,
        })

    return {
        "review_id": review_id,
        "region": region,
        "au_countries": au_countries,
        "plan_item_title": str(
            overrides.get("plan_item_title")
            or plan_data.get("Plan Item Title")
            or plan_data.get("plan_item_Name")
            or ""
        ).strip(),
        "plan_item_description": str(
            overrides.get("plan_item_description")
            or plan_data.get("Description of Plan Item")
            or plan_data.get("plan_item_Description")
            or ""
        ).strip(),
        "au_list": au_list,
        "rt_list": rt_list,
        "kc_list": kc_list,
        "control_name": _collect_control_field("control_Name", "control_name"),
        "control_how": _collect_control_field("control_How", "control_how"),
        "control_what": _collect_control_field("control_What", "control_what"),
        "control_why": _collect_control_field("control_Why", "control_why"),
        "documents": normalized_docs,
    }


async def get_relevant_data_for_documents_from_rag(
    plan_number: str,
    documents: List[Dict[str, Any]],
    overrides: Optional[Dict[str, Any]] = None,
    gcs_utils: Optional[Any] = None,
) -> Dict[str, Any]:
    """
    Calls POST {RAG_BASE_URL}/get-relevant-data-for-documents to retrieve relevant sections/paragraphs
    for the specified policy, KOD, or procedure document IDs.
    """
    base_url = _get_rag_base_url()
    relevant_url = f"{base_url}/get-relevant-data-for-documents"
    payload = build_rag_relevant_data_payload(
        plan_number=plan_number,
        documents=documents,
        overrides=overrides,
        gcs_utils=gcs_utils,
    )
    logger.info(
        "🌐 Calling RAG get-relevant-data-for-documents at %s for review_id=%s (%d document group(s))...",
        relevant_url,
        payload.get("review_id"),
        len(payload.get("documents", [])),
    )

    rag_trust_env = os.getenv("RAG_TRUST_ENV", "false").lower() in ("true", "1", "yes")
    try:
        async with httpx.AsyncClient(
            timeout=max(RAG_SERVICE_TIMEOUT, 60.0),
            verify=False,
            trust_env=rag_trust_env,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        ) as client:
            response = await client.post(relevant_url, json=payload)
            if response.status_code != 200:
                logger.warning(
                    "⚠️ RAG get-relevant-data-for-documents failed with status %d: %s",
                    response.status_code,
                    response.text,
                )
                return {
                    "status": "error",
                    "status_code": response.status_code,
                    "review_id": payload.get("review_id"),
                    "results": [],
                    "message": f"RAG get-relevant-data-for-documents failed with status {response.status_code}: {response.text}",
                }
            data = response.json()
            if isinstance(data, dict):
                data.setdefault("status", "success")
                data.setdefault("review_id", payload.get("review_id"))
                return data
            return {"status": "success", "review_id": payload.get("review_id"), "results": data}
    except Exception as e:
        logger.warning("⚠️ Error calling RAG get-relevant-data-for-documents (%s): %r", relevant_url, e, exc_info=True)
        return {
            "status": "error",
            "review_id": payload.get("review_id"),
            "results": [],
            "message": f"Error calling RAG get-relevant-data-for-documents: {str(e)}",
        }
