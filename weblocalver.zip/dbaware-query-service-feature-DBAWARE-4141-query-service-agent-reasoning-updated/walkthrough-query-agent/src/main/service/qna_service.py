import logging
import os
from typing import Any, Dict, List, Optional

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from agent_helper.prompt_utils import PromptBuilder
from agent.agent import initialize_gemini_model
from service.llm_judge import run_llm_judge, JudgeEvaluation
from service.context_builder import (
    PLAN_INBOUND_CACHE,
    _load_optional_blob_markdown,
    _load_preliminary_research_context,
    compact_inbound_json,
    load_and_cache_all_inbound_data,
    classify_query_inbound_category,
)
from service.rag_retriever import (
    extract_plan_document_ids,
    fetch_document_ids_from_scoping_db,
    should_query_rag_service,
    fetch_rag_document_chunks,
    DatabaseConnector,
)
from service.session_manager import (
    SESSION_CACHE,
    DEFAULT_BUCKET,
    DEFAULT_SESSION_ID,
    MAX_TOTAL_CONTEXT_CHARS,
    start_session_logic,
    upload_json_logic,
    close_session_logic,
    add_context_to_session_logic,
)
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

logger = logging.getLogger(__name__)

# Initialize global environment config
env_var = os.getenv('ENV_NAME', 'dev')

env_config = EnvironmentConfig(env_var)

# ----------------------------------------------------
# Helper: Safe LLM Text Content Extraction
# ----------------------------------------------------
def _extract_response_text(response: Any) -> str:
    """Safely extracts text content across str, blocks, and test MagicMock objects."""
    text_attr = getattr(response, "text", None)
    if isinstance(text_attr, str) and text_attr.strip():
        return text_attr
    content = getattr(response, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and "text" in item:
                parts.append(str(item["text"]))
            elif hasattr(item, "text") and isinstance(item.text, str):
                parts.append(item.text)
            else:
                parts.append(str(item))
        return "".join(parts)
    return str(content) if content is not None else ""

# ----------------------------------------------------
# Helper: On-The-Fly JSON to Markdown Parser
# ----------------------------------------------------
def convert_json_to_markdown(data: Any, depth: int = 1) -> str:
    """
    Recursively translates nested dicts and lists into beautifully formatted 
    human-readable Markdown headers, lists, and metadata blocks.
    """
    markdown_parts = []
    header_prefix = "#" * min(depth, 6)

    if isinstance(data, dict):
        for key, value in data.items():
            formatted_key = str(key).replace("_", " ").title()
            if isinstance(value, (dict, list)):
                markdown_parts.append(f"\n{header_prefix} {formatted_key}")
                markdown_parts.append(convert_json_to_markdown(value, depth + 1))
            else:
                markdown_parts.append(f"* **{formatted_key}**: {value}")
    elif isinstance(data, list):
        for index, item in enumerate(data):
            if isinstance(item, (dict, list)):
                markdown_parts.append(f"\n{header_prefix} Item {index + 1}")
                markdown_parts.append(convert_json_to_markdown(item, depth + 1))
            else:
                markdown_parts.append(f"* {item}")
    else:
        markdown_parts.append(str(data))

    return "\n".join(markdown_parts)

def format_rag_chunks_to_markdown(rag_results: List[Dict[str, Any]]) -> str:
    """Formats dense vector chunks returned by dbaware-rag-service into clean Markdown."""
    sections = []
    for res in rag_results:
        doc_type = str(res.get("document_type", "POLICY")).upper()
        chunks = res.get("chunks", [])
        if not chunks:
            continue
        for chunk in chunks:
            doc_title = chunk.get("document_title", "Document")
            sec_id = chunk.get("section_id", "")
            sec_title = chunk.get("section_title", "")
            score = chunk.get("score", 0.0)
            text = str(chunk.get("text", "")).strip()
            header = f"### [{doc_type}] {doc_title}"
            if sec_id or sec_title:
                header += f" (Section {sec_id}: {sec_title})"
            if score:
                header += f" [Relevance: {score:.2f}]"
            sections.append(f"{header}\n{text}")

    if sections:
        return "## RETRIEVED GOVERNANCE & POLICY EVIDENCE (RAG SERVICE)\n" + "\n\n".join(sections)
    return ""

async def chat_logic(
    session_id: str, 
    user_query: str, 
    plan_name: Optional[str] = None,
    research_sections: Optional[Dict[str, Any]] = None,
    context_type: str = "Preliminary Research Walkthrough",
    context_gcs_uri: Optional[str] = None,
    user_details: Optional[Dict[str, Any]] = None,
    additional_context: Optional[Any] = None,
    uploaded_documents: Optional[List[Dict[str, Any]]] = None,
) -> tuple:
    """Applies human query and conversation state to the cached session."""
    logger.info("================================================================================")
    logger.info("⚡ Q&A TRANSACTION TRIGGERED | Context/Stage: '%s' | Plan/Session: %s", context_type, session_id)
    logger.info("================================================================================")

    cache_key = f"{session_id}_{context_type}"
    if cache_key not in SESSION_CACHE:
        normalized_context_gcs_uri = (context_gcs_uri or "").strip()
        placeholder_values = {"string", "none", "null", "undefined", "n/a", "na"}
        is_placeholder_uri = normalized_context_gcs_uri.lower() in placeholder_values
        is_uri_like = normalized_context_gcs_uri.startswith("gs://") or "/" in normalized_context_gcs_uri

        if normalized_context_gcs_uri and (not is_placeholder_uri) and is_uri_like:
            dynamic_gcs_path = normalized_context_gcs_uri
        else:
            if normalized_context_gcs_uri:
                logger.warning(
                    "Ignoring invalid context_gcs_uri override '%s' for plan/session %s and context '%s'. Falling back to default mapped GCS path.",
                    normalized_context_gcs_uri,
                    session_id,
                    context_type
                )
            bucket_name = os.getenv("bucket_name", "db-dev-euwe3-gcs-155081-dbaware_review")
            file_mapping = {
                "Preliminary Research Walkthrough": "processing-data/preliminary-research/past_review.json",
                "preliminary_research": "processing-data/preliminary-research/past_review.json",
                "preliminary research": "processing-data/preliminary-research/past_review.json",
                "Discovery Walkthrough": "processing-data/scoping/discovery_walkthrough.json",
                "discovery_walkthrough": "processing-data/scoping/discovery_walkthrough.json",
                "Scope Recommendation": "processing-data/procedure/outscope.json",
                "scope_recommendation": "processing-data/procedure/outscope.json",
                "Test Steps": "processing-data/procedure/test-steps.json",
                "test_steps": "processing-data/procedure/test-steps.json",
            }
            normalized_ctx = str(context_type or "").strip()
            sub_path = (
                file_mapping.get(normalized_ctx)
                or file_mapping.get(normalized_ctx.lower())
                or "processing-data/scoping/discovery_walkthrough.json"
            )
            dynamic_gcs_path = f"gs://{bucket_name}/dbaware_review_{session_id}/{sub_path}"
        
        logger.info("Session key '%s' not found in cache. Autoloading context dynamically from GCS path: %s", cache_key, dynamic_gcs_path)
        try:
            await start_session_logic(dynamic_gcs_path, session_id=session_id, context_type=context_type)
        except Exception as e:
            logger.error("Failed to dynamically load session from %s: %s", dynamic_gcs_path, str(e))
            raise KeyError(
                f"The Q&A document for plan '{session_id}' ({context_type}) is not ready. Please trigger the corresponding agent in the UI to generate the source document first."
            )

    session_data = SESSION_CACHE[cache_key]
    # Retrieve persistent correlation ID from session cache
    correlation_id = session_data.get("correlation_id")

    # If the caller supplied additional context or uploaded documents in the chat request, merge into session context
    if additional_context or uploaded_documents:
        inline_sections = []
        inline_text = None
        if isinstance(additional_context, str):
            inline_text = additional_context
        elif isinstance(additional_context, dict):
            for sec_title, sec_content in additional_context.items():
                inline_sections.append({"section_title": str(sec_title), "content": sec_content})
        elif isinstance(additional_context, list):
            for item in additional_context:
                if isinstance(item, dict):
                    inline_sections.append(item)
                elif item is not None:
                    inline_sections.append({"section_title": "Additional Context", "content": str(item)})

        await add_context_to_session_logic(
            session_id=session_id,
            plan_number=str(session_id).strip(),
            context_type=context_type,
            user_text=inline_text,
            sections=inline_sections,
            documents=uploaded_documents,
            persist_to_gcs=bool(uploaded_documents),
        )
        session_data = SESSION_CACHE[cache_key]

    # Query categorization: inject ONLY the matching operational category
    plan_number = str(session_id).strip()
    gcs_utils = GCSUtils(env_config)
    inbound_cache = load_and_cache_all_inbound_data(gcs_utils, plan_number)
    target_categories = classify_query_inbound_category(user_query, list(inbound_cache.keys()))
    logger.info("🏷️ Query Inbound Categorization: matched %s for query: '%s'", target_categories, user_query[:50])

    active_context = session_data["markdown_context"]
    for cat in target_categories:
        if cat in inbound_cache and inbound_cache[cat]:
            cat_title = cat.replace("_", " ").upper()
            active_context += f"\n\n## OPERATIONAL INBOUND DATA: {cat_title}\n{inbound_cache[cat]}"
            logger.info("📎 Injected %d characters from inbound category '%s' into prompt.", len(inbound_cache[cat]), cat)

    # Endgame RAG Retrieval: Check and query dbaware-rag-service for policies, KODs, and procedures
    if should_query_rag_service(user_query):
        logger.info("🔍 Received user_details in chat_logic: %s", user_details)
        logger.info("🎯 Query identified as governance/policy relevant. Resolving document IDs (Option A + B)...")
        doc_ids_map = extract_plan_document_ids(
            raw_json=session_data.get("raw_json"),
            user_details=user_details
        )
        instance_id = None
        if user_details and isinstance(user_details, dict):
            instance_id = user_details.get("review_scope_instance_id")
        # If document IDs not found in payload/json, resolve via scoping-db (or mock)
        if not any(doc_ids_map.values()):
            target_instance = int(instance_id) if instance_id is not None and str(instance_id).isdigit() and int(instance_id) > 0 else 1
            logger.info("🔍 Resolving document IDs from scoping-db for review_scope_instance_id=%s...", target_instance)
            db_docs = await fetch_document_ids_from_scoping_db(target_instance)
            for dtype, ids in db_docs.items():
                doc_ids_map.setdefault(dtype, []).extend(ids)
                doc_ids_map[dtype] = list(dict.fromkeys(doc_ids_map[dtype]))

        # Exclude soft-removed policy/kod/procedure document IDs and sections before/after querying RAG
        excluded_doc_ids_by_type: Dict[str, set] = {}
        excluded_doc_titles_by_type: Dict[str, set] = {}
        excluded_sec_ids_by_type: Dict[str, set] = {}
        excluded_sec_titles_by_type: Dict[str, set] = {}
        try:
            meta_rows = DatabaseConnector().get_data_extraction_rows_for_plan(plan_number)
            for dtype in ("policy", "kod", "procedure"):
                meta_blob = (meta_rows.get(dtype) or {}).get("metadata") or {}
                if not isinstance(meta_blob, dict):
                    continue
                ex_ids = set()
                ex_titles = set()
                ex_sec_ids = set()
                ex_sec_titles = set()
                for d in (meta_blob.get("documents") or []):
                    if not isinstance(d, dict):
                        continue
                    doc_excluded = d.get("excluded") is True or str(d.get("status") or "").lower() in ("excluded", "removed")
                    if doc_excluded:
                        if str(d.get("document_id") or "").isdigit():
                            ex_ids.add(int(d["document_id"]))
                        dtitle = str(d.get("document_title") or d.get("title") or "").strip().lower()
                        if dtitle:
                            ex_titles.add(dtitle)
                    for s in (d.get("sections") or []):
                        if not isinstance(s, dict):
                            continue
                        if doc_excluded or s.get("excluded") is True or str(s.get("status") or "").lower() in ("excluded", "removed"):
                            sid = str(s.get("section_id") or "").strip().lower()
                            stitle = str(s.get("section_title") or "").strip().lower()
                            if sid:
                                ex_sec_ids.add(sid)
                            if stitle:
                                ex_sec_titles.add(stitle)
                excluded_doc_ids_by_type[dtype] = ex_ids
                excluded_doc_titles_by_type[dtype] = ex_titles
                excluded_sec_ids_by_type[dtype] = ex_sec_ids
                excluded_sec_titles_by_type[dtype] = ex_sec_titles
                if ex_ids and doc_ids_map.get(dtype):
                    doc_ids_map[dtype] = [i for i in doc_ids_map[dtype] if i not in ex_ids]
        except Exception as filter_exc:
            logger.debug("Skipping RAG excluded-id filter for plan %s: %s", plan_number, filter_exc)

        logger.info("📋 Resolved scoped document IDs: %s", doc_ids_map)
        rag_results = await fetch_rag_document_chunks(user_query, document_ids_map=doc_ids_map, top_k=5)
        if rag_results and any(
            excluded_doc_ids_by_type.get(t) or excluded_doc_titles_by_type.get(t)
            or excluded_sec_ids_by_type.get(t) or excluded_sec_titles_by_type.get(t)
            for t in ("policy", "kod", "procedure")
        ):
            filtered_rag_results = []
            for res in rag_results:
                if not isinstance(res, dict):
                    continue
                dtype = str(res.get("document_type") or "policy").strip().lower()
                ex_ids = excluded_doc_ids_by_type.get(dtype, set())
                ex_titles = excluded_doc_titles_by_type.get(dtype, set())
                ex_sec_ids = excluded_sec_ids_by_type.get(dtype, set())
                ex_sec_titles = excluded_sec_titles_by_type.get(dtype, set())
                kept_chunks = []
                for chunk in (res.get("chunks") or []):
                    if not isinstance(chunk, dict):
                        continue
                    cid = chunk.get("document_id")
                    ctitle = str(chunk.get("document_title") or "").strip().lower()
                    csid = str(chunk.get("section_id") or "").strip().lower()
                    cstitle = str(chunk.get("section_title") or "").strip().lower()
                    if (cid is not None and str(cid).isdigit() and int(cid) in ex_ids) or (ctitle and ctitle in ex_titles):
                        continue
                    if (csid and csid in ex_sec_ids) or (cstitle and cstitle in ex_sec_titles):
                        continue
                    kept_chunks.append(chunk)
                filtered_rag_results.append({**res, "chunks": kept_chunks})
            rag_results = filtered_rag_results
        rag_markdown = format_rag_chunks_to_markdown(rag_results)
        if rag_markdown:
            active_context += f"\n\n{rag_markdown}"
            logger.info("📎 Injected %d characters of RAG policy/KOD/procedure evidence into prompt.", len(rag_markdown))

    prompt_builder = PromptBuilder(prompt_file_name="qna_prompt.json")
    system_instruction = prompt_builder.build_prompt(document_context=active_context)

    messages = [SystemMessage(content=system_instruction)]
    messages.extend(session_data["chat_history"])
    messages.append(HumanMessage(content=user_query))

    llm = initialize_gemini_model(env_config)
    clean_query = user_query.replace("\n", " ").strip()
    if len(clean_query) > 40:
        clean_query = clean_query[:37] + "..."

    # Pre-flight token calculation using model API
    try:
        input_tokens = int(llm.get_num_tokens_from_messages(messages))
    except Exception as te:
        logger.debug("Failed to calculate token count via LLM: %s", te)
        total_chars = sum(len(str(m.content)) for m in messages)
        input_tokens = total_chars // 4

    logger.info(
        "================================================================================\n"
        "📊 TOKEN PRE-FLIGHT AUDIT | Plan: %s | Stage: '%s'\n"
        "   - Input Tokens:       %d\n"
        "   - Max Limit Allowed:  1,048,576\n"
        "   - Total Chars:        %d\n"
        "================================================================================",
        session_id, context_type, input_tokens, len(session_data["markdown_context"])
    )

    if input_tokens > 1048576:
        overflow_tokens = input_tokens - 1048576
        logger.error(
            "================================================================================\n"
            "🚨 CRITICAL TOKEN OVERFLOW EVIDENCE REPORT\n"
            "   - Plan / Session ID:  %s\n"
            "   - Walkthrough Stage:  %s\n"
            "   - Input Tokens:       %d\n"
            "   - Max Limit Allowed:  1,048,576\n"
            "   - Over Limit By:      +%d tokens\n"
            "   - Context Chars:      %d characters\n"
            "================================================================================",
            session_id, context_type, input_tokens, overflow_tokens, len(session_data["markdown_context"])
        )

    max_attempts = int(env_config.get_env_config("LLM_JUDGE_MAX_ITERATIONS", 3))
    judge_threshold = float(env_config.get_env_config("LLM_JUDGE_THRESHOLD", 0.99))
    final_answer = ""
    passed_evaluation = False
    final_metrics: Optional[JudgeEvaluation] = None

    # Copy the message trace so we can safely inject critiques during iterations
    loop_messages = list(messages)
    token_usage = {
        "input_tokens": input_tokens,
        "output_tokens": 0,
        "total_tokens": input_tokens
    }

    for attempt in range(max_attempts):
        logger.info("Invoking Gemini conversational model (Attempt %d/%d)...", attempt + 1, max_attempts)
        response = llm.invoke(loop_messages)
        final_answer = _extract_response_text(response)

        # Extract exact token telemetry from Gemini response
        usage_meta = getattr(response, "usage_metadata", {}) or {}
        actual_input_tokens = int(usage_meta.get("input_tokens") or usage_meta.get("prompt_token_count") or input_tokens)
        actual_output_tokens = int(usage_meta.get("output_tokens") or usage_meta.get("candidates_token_count") or 0)
        actual_total_tokens = int(usage_meta.get("total_tokens") or usage_meta.get("total_token_count") or (actual_input_tokens + actual_output_tokens))

        token_usage = {
            "input_tokens": actual_input_tokens,
            "output_tokens": actual_output_tokens,
            "total_tokens": actual_total_tokens
        }
        logger.info(
            "📊 TOKEN CONSUMPTION REPORT (Attempt %d) | Input Tokens: %d | Output Tokens: %d | Total Tokens: %d",
            attempt + 1, actual_input_tokens, actual_output_tokens, actual_total_tokens
        )

        # Check for standard compliance refusal template
        clean_ans = final_answer.strip().rstrip(".")
        if clean_ans == "I cannot confirm this from walkthrough documentation":
            logger.info("Standard compliance refusal template detected. Bypassing LLM Judge retries.")
            passed_evaluation = True
            final_metrics = JudgeEvaluation(
                groundedness_score=1.0,
                citation_coverage=1.0,
                unsupported_claim_count=0,
                contradiction_score=0.0,
                context_faithfulness=1.0,
                answer_relevance=1.0,
                verdict="PASS",
                reasoning="Standard compliance refusal template detected. Automatically passed."
            )
            break

        logger.info("Running LLM-as-a-judge factual correctness verification...")
        evaluation_results = await run_llm_judge(
            active_context, 
            user_query, 
            final_answer,
            env_config
        )

        groundedness = evaluation_results.groundedness_score
        unsupported_claims = evaluation_results.unsupported_claim_count
        contradiction = evaluation_results.contradiction_score
        faithfulness = evaluation_results.context_faithfulness
        relevance = evaluation_results.answer_relevance
        reasoning = evaluation_results.reasoning

        logger.info(
            "Attempt %d/%d Evaluation for Query ['%s']: Groundedness: %.2f, Unsupported Claims: %d, Contradiction: %.2f, Faithfulness: %.2f, Relevance: %.2f",
            attempt + 1, max_attempts, clean_query, groundedness, unsupported_claims, contradiction, faithfulness, relevance
        )

        reasoning_lower = reasoning.lower()
        is_conversational = (
            "conversational exception" in reasoning_lower or 
            "casual greeting" in reasoning_lower or 
            "capability explanation" in reasoning_lower or
            "polite conversational" in reasoning_lower
        )

        # Threshold pass policy: Pass if conversational exception or groundedness >= judge_threshold
        if is_conversational or groundedness >= judge_threshold:
            logger.info("Answer PASSED the %.2f accuracy threshold on attempt %d.", judge_threshold, attempt + 1)
            passed_evaluation = True
            final_metrics = evaluation_results
            break
        else:
            logger.warning("Answer FAILED the %.2f accuracy threshold on attempt %d. Retrying...", judge_threshold, attempt + 1)
            final_metrics = evaluation_results
            # Append failed generation and the auditor's critique to the iteration trace
            loop_messages.append(AIMessage(content=final_answer))
            feedback_msg = (
                f"CRITIQUE FROM AUDITOR: Your previous answer failed validation with a groundedness score of {groundedness:.2f}.\n"
                f"Reasoning / Corrections Required: {reasoning}\n"
                f"Please regenerate the answer, strictly correcting these issues. "
                f"If the auditor indicates that the information is indeed present, locate and use it. "
                f"If the information is completely missing, respond with: 'I cannot confirm this from walkthrough documentation.'"
            )
            loop_messages.append(HumanMessage(content=feedback_msg))

    if not passed_evaluation:
        logger.warning("Answer failed to pass the %.2f accuracy threshold after %d attempts. Returning the last iteration output.", judge_threshold, max_attempts)

    session_data["chat_history"].append(HumanMessage(content=user_query))
    session_data["chat_history"].append(AIMessage(content=final_answer))

    raw_reasoning = final_metrics.reasoning if final_metrics else ""
    clean_critique = raw_reasoning.replace("\n", " ").strip()
    if len(clean_critique) > 120:
        clean_critique = clean_critique[:117] + "..."

    logger.info(
        "LLM Judge Result for session %s, Query ['%s'] => Groundedness: %.2f, Citation Coverage: %.2f, Unsupported Claims: %d, Contradiction: %.2f, Faithfulness: %.2f, Relevance: %.2f, Critique: %s",
        session_id,
        clean_query,
        final_metrics.groundedness_score if final_metrics else 0.0,
        final_metrics.citation_coverage if final_metrics else 0.0,
        final_metrics.unsupported_claim_count if final_metrics else 0,
        final_metrics.contradiction_score if final_metrics else 0.0,
        final_metrics.context_faithfulness if final_metrics else 0.0,
        final_metrics.answer_relevance if final_metrics else 0.0,
        clean_critique
    )

    return final_answer, len(session_data["chat_history"]), final_metrics, correlation_id, token_usage

async def stateless_chat_logic(
    plan_number: Optional[str] = None,
    plan_name: Optional[str] = None,
    research_sections: Optional[dict] = None,
    user_query: str = ""
) -> str:
    """Compiles dynamic walkthrough context and generates an answer statelessly using Gemini."""
    logger.info("Building stateless context blocks for Plan: %s", plan_number)
    
    # Compile the active walkthrough sections into a unified markdown context block
    context_parts = []
    if plan_number or plan_name:
        context_parts.append(f"# Plan: {plan_number or ''} - {plan_name or ''}".strip())
    
    if research_sections:
        for title, content in research_sections.items():
            context_parts.append(f"## {title}\n{content}")
    compiled_context = "\n\n".join(context_parts)

    prompt_builder = PromptBuilder(prompt_file_name="qna_prompt.json")
    system_instruction = prompt_builder.build_prompt(document_context=compiled_context)

    messages = [
        SystemMessage(content=system_instruction),
        HumanMessage(content=user_query)
    ]

    llm = initialize_gemini_model(env_config)
    logger.info("Invoking Gemini conversational model statelessly...")
    response = llm.invoke(messages)
    return _extract_response_text(response)
