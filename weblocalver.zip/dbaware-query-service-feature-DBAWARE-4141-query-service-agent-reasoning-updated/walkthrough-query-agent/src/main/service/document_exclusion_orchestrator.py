from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple
import logging
import re
from fastapi import HTTPException

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from service.document_service import _title_similarity_score
from service.request import (
    DocumentCandidate,
    DocumentExclusionPlanAction,
    DocumentExclusionPlanRequest,
    DocumentExclusionPlanResponse,
    DocumentExecutionAction,
    DocumentExecutionRequest,
    DocumentExecutionResponse,
    DocumentExclusionWorkflowRequest,
    DocumentImpactAnalysis,
    DocumentIntentAnalysis,
    DocumentVerificationRequest,
    DocumentVerificationResponse,
    DocumentVerificationResult,
)

try:
    from service.database_connector import (
        SCOPING_SOURCES,
        DatabaseConnector,
        compute_affected_preliminary_research_sections,
        normalize_scoping_source,
        source_to_db_data_source,
    )
except Exception:  # pragma: no cover
    DatabaseConnector = None  # type: ignore[assignment]
    SCOPING_SOURCES = ("policy", "kod", "procedure", "gfms", "historical_scoping_document", "lrr")

    def normalize_scoping_source(value: Optional[str]) -> Optional[str]:
        v = (value or "").strip().lower()
        return v if v in {"policy", "kod", "procedure", "gfms", "historical_scoping_document", "lrr"} else None

    def source_to_db_data_source(value: Optional[str]) -> str:
        return str(value or "policy").strip().lower()

    def compute_affected_preliminary_research_sections(sources) -> List[str]:
        return []

logger = logging.getLogger(__name__)

PRIMARY_KEY_FIELDS = (
    "row_primary_key",
    "id",
    "document_id",
    "findingId",
    "Plan Item Number",
    "review_scope_dataext_id",
    "record_id",
)
SUPPORTED_SCOPING_TYPES = {
    "policy",
    "kod",
    "procedure",
    "gfms",
    "historical_scoping_document",
    "lrr",
}


def _entry_primary_key(entry: dict) -> Optional[str]:
    """Primary key of a registry row, resolved in the same order the verification step uses."""
    if not isinstance(entry, dict):
        return None
    for key in PRIMARY_KEY_FIELDS:
        value = entry.get(key)
        if value not in (None, ""):
            return str(value)
    return None


def _blob_path_from_uri(uri_or_path: Optional[str]) -> Optional[str]:
    if not uri_or_path:
        return None
    text = str(uri_or_path).strip()
    if text.startswith("gs://"):
        parts = text[5:].split("/", 1)
        return parts[1] if len(parts) == 2 else None
    return text


def _resolve_registry_blob_candidates(plan_number: str, document_type: str) -> List[str]:
    canonical = normalize_scoping_source(document_type) or (document_type or "").strip().lower()
    if canonical == "gfms":
        return [
            f"dbaware_review_{plan_number}/inbound-data/gfms/findings_details.json",
            f"dbaware_review_{plan_number}/processing-data/findings_details.json",
        ]
    if canonical == "historical_scoping_document":
        return [
            f"dbaware_review_{plan_number}/inbound-data/dbaware/historical_plan_details.json",
            f"dbaware_review_{plan_number}/processing-data/historical_plan_details.json",
        ]
    if canonical == "lrr":
        return [
            f"dbaware_review_{plan_number}/inbound-data/lrr/internet_search_data_enriched.json",
            f"dbaware_review_{plan_number}/inbound-data/lrr/internet_search_data.json",
            f"dbaware_review_{plan_number}/processing-data/internet_search_data_enriched.json",
        ]
    if canonical in {"policy", "kod", "procedure"}:
        candidates = [
            f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{canonical}.json",
        ]
        if canonical != "policy":
            candidates.append(
                f"dbaware_review_{plan_number}/inbound-data/{canonical}/relevant_{canonical}.json"
            )
        candidates.append(
            f"dbaware_review_{plan_number}/processing-data/relevant_{canonical}.json"
        )
        return candidates
    return [
        f"dbaware_review_{plan_number}/inbound-data/{canonical}/relevant_{canonical}.json",
        f"dbaware_review_{plan_number}/processing-data/relevant_{canonical}.json",
    ]


def _is_valid_registry_payload(payload: object) -> bool:
    if isinstance(payload, list):
        return all(isinstance(item, dict) for item in payload)
    if isinstance(payload, dict):
        if isinstance(payload.get("documents"), list):
            return True
        if isinstance(payload.get("referenced_documents"), list):
            return True
        if isinstance(payload.get("sources"), list):
            return True
        if isinstance(payload.get("nodes"), list) and payload.get("document_id") is not None:
            return True
        if isinstance(payload.get("responsePayload"), list) or isinstance(payload.get("findings"), list) or isinstance(payload.get("Mandates"), list):
            return True
    return False


def _normalize_sections_from_entry(entry: Dict[str, Any], doc_id_str: str = "") -> List[Dict[str, Any]]:
    raw_sections = entry.get("sections")
    if not isinstance(raw_sections, list):
        raw_sections = entry.get("nodes") if isinstance(entry.get("nodes"), list) else []
    normalized_secs: List[Dict[str, Any]] = []
    for idx, sec in enumerate(raw_sections, start=1):
        if not isinstance(sec, dict):
            continue
        sec_id = sec.get("section_id")
        sec_id_str = str(sec_id) if sec_id not in (None, "") else str(idx)
        sec_title = str(
            sec.get("section_title")
            or sec.get("title")
            or sec.get("section_path")
            or f"Section {sec_id_str}"
        ).strip()
        node_id = str(
            sec.get("node_id") or f"{doc_id_str or 'doc'}:section:{sec_id_str}"
        ).strip()
        excluded = bool(sec.get("excluded", False)) or (
            str(sec.get("status") or "").strip().lower() in {"removed", "excluded", "deleted", "inactive"}
        )
        status = "excluded" if excluded else str(sec.get("status") or "active")
        normalized_secs.append(
            {
                **sec,
                "section_id": sec_id_str,
                "section_title": sec_title,
                "node_id": node_id,
                "status": status,
                "excluded": excluded,
            }
        )
    return normalized_secs


def _extract_normalized_registry_entries(
    payload: Any,
    document_type: str = "policy",
    context_file: Optional[str] = None,
) -> List[Dict[str, Any]]:
    if not _is_valid_registry_payload(payload):
        return []

    canonical = normalize_scoping_source(document_type) or (document_type or "policy").strip().lower()

    # 1. Dict with documents or referenced_documents
    if isinstance(payload, dict):
        if isinstance(payload.get("documents"), list):
            raw_list = payload["documents"]
        elif isinstance(payload.get("referenced_documents"), list):
            raw_list = payload["referenced_documents"]
        elif isinstance(payload.get("nodes"), list) and payload.get("document_id") is not None:
            raw_list = [payload]
        elif isinstance(payload.get("responsePayload"), list) or isinstance(payload.get("findings"), list):
            raw_list = [payload]
        else:
            raw_list = []
    elif isinstance(payload, list):
        raw_list = payload
    else:
        raw_list = []

    # Check if raw_list is GFMS envelope list or raw findings list
    if canonical == "gfms" or any(
        isinstance(x, dict)
        and (
            isinstance(x.get("responsePayload"), list)
            or "findingId" in x
            or "findingTitle" in x
        )
        for x in raw_list
        if isinstance(x, dict)
    ):
        # If already in review_data_extraction format (filename == findings_details.json with sections)
        if any(
            isinstance(x, dict)
            and isinstance(x.get("sections"), list)
            and str(x.get("filename") or "").endswith("findings_details.json")
            for x in raw_list
        ):
            entries: List[Dict[str, Any]] = []
            for doc in raw_list:
                if not isinstance(doc, dict):
                    continue
                doc_copy = dict(doc)
                doc_copy["sections"] = _normalize_sections_from_entry(
                    doc_copy, str(doc_copy.get("document_id") or "findings_details")
                )
                entries.append(doc_copy)
            return entries

        findings: List[Dict[str, Any]] = []
        for item in raw_list:
            if not isinstance(item, dict):
                continue
            if isinstance(item.get("responsePayload"), list):
                findings.extend(f for f in item["responsePayload"] if isinstance(f, dict))
            elif isinstance(item.get("findings"), list):
                findings.extend(f for f in item["findings"] if isinstance(f, dict))
            elif any(k in item for k in ("findingId", "finding_id", "findingTitle", "auditNumber", "document_title", "title")):
                findings.append(item)

        sections: List[Dict[str, Any]] = []
        finding_entries: List[Dict[str, Any]] = []
        for idx, f in enumerate(findings, start=1):
            f_id = str(f.get("findingId") or f.get("finding_id") or f.get("document_id") or f.get("id") or idx).strip()
            f_title = str(f.get("findingTitle") or f.get("title") or f.get("document_title") or f.get("auditName") or f"Finding {f_id}").strip()
            excluded = bool(f.get("excluded", False)) or (
                str(f.get("status") or "").strip().lower() in {"removed", "excluded", "deleted", "inactive"}
            )
            status = "removed" if excluded else "active"
            sec = {
                "section_id": f_id,
                "section_title": f_title,
                "node_id": str(f.get("node_id") or f"gfms:finding:{f_id}"),
                "audit_number": f.get("auditNumber") or f.get("audit_number"),
                "audit_name": f.get("auditName") or f.get("audit_name"),
                "rating": f.get("rating"),
                "status": "excluded" if excluded else "active",
                "excluded": excluded,
            }
            sections.append(sec)
            finding_entries.append(
                {
                    **f,
                    "id": f_id,
                    "document_id": f_id,
                    "document_title": f_title,
                    "title": f_title,
                    "filename": "findings_details.json",
                    "section_id": f_id,
                    "section_title": f_title,
                    "node_id": sec["node_id"],
                    "status": status,
                    "excluded": excluded,
                }
            )
        parent_doc = {
            "id": "findings_details",
            "document_id": "findings_details",
            "document_title": "GFMS Findings Details",
            "title": "GFMS Findings Details",
            "filename": "findings_details.json",
            "status": "active",
            "excluded": False,
            "sections": sections,
        }
        return [parent_doc, *finding_entries]

    # Check if raw_list is historical_plan_details.json
    if canonical == "historical_scoping_document" or any(
        isinstance(x, dict) and ("Plan Item Number" in x or "Plan Item Title" in x)
        for x in raw_list
    ):
        if any(
            isinstance(x, dict)
            and isinstance(x.get("sections"), list)
            and str(x.get("filename") or "").endswith(("historical_plan_details.json", ".pdf"))
            for x in raw_list
        ):
            entries = []
            for doc in raw_list:
                if not isinstance(doc, dict):
                    continue
                doc_copy = dict(doc)
                doc_copy["sections"] = _normalize_sections_from_entry(
                    doc_copy, str(doc_copy.get("document_id") or "historical_plan_details")
                )
                entries.append(doc_copy)
            return entries

        hist_sections: List[Dict[str, Any]] = []
        hist_entries: List[Dict[str, Any]] = []
        for idx, item in enumerate(raw_list, start=1):
            if not isinstance(item, dict):
                continue
            p_num = str(
                item.get("Plan Item Number")
                or item.get("plan_item_number")
                or item.get("document_id")
                or item.get("id")
                or idx
            ).strip()
            p_title = str(
                item.get("Plan Item Title")
                or item.get("plan_item_title")
                or item.get("document_title")
                or item.get("title")
                or f"Historical Plan {p_num}"
            ).strip()
            excluded = bool(item.get("excluded", False)) or (
                str(item.get("status") or "").strip().lower() in {"removed", "excluded", "deleted", "inactive"}
            )
            status = "removed" if excluded else "active"
            node_id = str(item.get("node_id") or f"historical_plan:{p_num}")
            sec = {
                "section_id": p_num,
                "section_title": p_title,
                "node_id": node_id,
                "report_number": item.get("Report Number"),
                "plan_year": item.get("Plan Year"),
                "status": "excluded" if excluded else "active",
                "excluded": excluded,
            }
            hist_sections.append(sec)
            hist_entries.append(
                {
                    **item,
                    "id": p_num,
                    "document_id": p_num,
                    "document_title": p_title,
                    "title": p_title,
                    "filename": item.get("filename") or "historical_plan_details.json",
                    "section_id": p_num,
                    "section_title": p_title,
                    "node_id": node_id,
                    "status": status,
                    "excluded": excluded,
                }
            )
        parent_hist = {
            "id": "historical_plan_details",
            "document_id": "historical_plan_details",
            "document_title": "Historical Plan Details",
            "title": "Historical Plan Details",
            "filename": "historical_plan_details.json",
            "status": "active",
            "excluded": False,
            "sections": hist_sections,
        }
        return [parent_hist, *hist_entries]

    # Check if raw_list is LRR enriched mandates [{"Risk Name": ..., "Mandates": [...]}]
    if canonical == "lrr" or any(
        isinstance(x, dict) and isinstance(x.get("Mandates"), list)
        for x in raw_list
    ):
        if any(
            isinstance(x, dict)
            and isinstance(x.get("sections"), list)
            and str(x.get("filename") or "").endswith(("internet_search_data_enriched.json", "internet_search_data.json"))
            for x in raw_list
        ):
            entries = []
            for doc in raw_list:
                if not isinstance(doc, dict):
                    continue
                doc_copy = dict(doc)
                doc_copy["sections"] = _normalize_sections_from_entry(
                    doc_copy, str(doc_copy.get("document_id") or "lrr_internet_search_data_enriched")
                )
                entries.append(doc_copy)
            return entries

        lrr_sections: List[Dict[str, Any]] = []
        lrr_entries: List[Dict[str, Any]] = []
        idx = 0
        for risk in raw_list:
            if not isinstance(risk, dict):
                continue
            risk_name = str(risk.get("Risk Name") or risk.get("risk_name") or "").strip()
            for mandate in risk.get("Mandates") or []:
                if not isinstance(mandate, dict):
                    continue
                idx += 1
                m_title = str(
                    mandate.get("Regulatory Mandate")
                    or mandate.get("mandate")
                    or mandate.get("Citation")
                    or f"{risk_name} - Mandate {idx}"
                ).strip()
                excluded = bool(mandate.get("excluded", False)) or (
                    str(mandate.get("status") or "").strip().lower() in {"removed", "excluded", "deleted", "inactive"}
                )
                node_id = str(mandate.get("node_id") or f"lrr:mandate:{idx}")
                sec = {
                    "section_id": str(idx),
                    "section_title": m_title,
                    "node_id": node_id,
                    "risk_name": risk_name,
                    "status": "excluded" if excluded else "active",
                    "excluded": excluded,
                }
                lrr_sections.append(sec)
                lrr_entries.append(
                    {
                        **mandate,
                        "id": str(idx),
                        "document_id": str(idx),
                        "document_title": m_title,
                        "title": m_title,
                        "filename": "internet_search_data_enriched.json",
                        "section_id": str(idx),
                        "section_title": m_title,
                        "node_id": node_id,
                        "status": "removed" if excluded else "active",
                        "excluded": excluded,
                    }
                )
        parent_lrr = {
            "id": "lrr_internet_search_data_enriched",
            "document_id": "lrr_internet_search_data_enriched",
            "document_title": "Regulatory & Internet Search Mandates",
            "title": "Regulatory & Internet Search Mandates",
            "filename": "internet_search_data_enriched.json",
            "status": "active",
            "excluded": False,
            "sections": lrr_sections,
        }
        return [parent_lrr, *lrr_entries]

    # Standard RAG / registry documents (policy, kod, procedure)
    raw_sources = (
        payload.get("sources")
        if isinstance(payload, dict) and isinstance(payload.get("sources"), list) and canonical in {"policy", "kod", "procedure"}
        else []
    )
    sources_by_uri: Dict[str, List[Dict[str, Any]]] = {}
    sources_by_name: Dict[str, List[Dict[str, Any]]] = {}
    synthesized_docs_by_key: Dict[str, Dict[str, Any]] = {}
    for s_idx, src in enumerate(raw_sources, start=1):
        if not isinstance(src, dict):
            continue
        s_uri = str(src.get("gs_uri") or src.get("storage_uri") or "").strip()
        s_name = str(src.get("document_name") or src.get("document_title") or "").strip()
        doc_key = (s_uri or s_name or canonical).rsplit("/", 1)[-1]
        sid_raw = src.get("section_id")
        if sid_raw in (None, ""):
            sid_raw = src.get("source_index")
        sid_val = str(sid_raw if sid_raw not in (None, "") else s_idx)
        page_num = src.get("page_number")
        sec_title = str(
            src.get("section_title")
            or src.get("control_area")
            or (f"Page {page_num}" if page_num is not None else f"Section {sid_val}")
        ).strip()
        node_id = str(
            src.get("node_id")
            or (f"{doc_key}:page:{page_num}" if page_num is not None else f"{doc_key}:source:{sid_val}")
        )
        sec_excluded = bool(src.get("excluded", False)) or (
            str(src.get("status") or "").strip().lower() in {"removed", "excluded", "deleted", "inactive"}
        )
        sec_entry: Dict[str, Any] = {
            "section_id": sid_val,
            "section_title": sec_title,
            "node_id": node_id,
            "status": "excluded" if sec_excluded else str(src.get("status") or "active"),
            "excluded": sec_excluded,
        }
        if page_num is not None:
            sec_entry["page_number"] = page_num
        if s_uri:
            sources_by_uri.setdefault(s_uri.lower(), []).append(sec_entry)
        if s_name:
            sources_by_name.setdefault(s_name.lower(), []).append(sec_entry)

        synth_key = (s_uri or s_name or f"source_{s_idx}").lower()
        if not raw_list and synth_key not in synthesized_docs_by_key:
            fname_val = s_uri.rsplit("/", 1)[-1] if s_uri else (s_name or f"{canonical}_{s_idx}.json")
            synthesized_docs_by_key[synth_key] = {
                "document_name": s_name or fname_val,
                "document_title": s_name or fname_val,
                "filename": fname_val,
                "storage_uri": s_uri or None,
                "gs_uri": s_uri or None,
                "status": "active",
                "excluded": False,
            }

    if not raw_list and synthesized_docs_by_key:
        raw_list = list(synthesized_docs_by_key.values())

    normalized_entries: List[Dict[str, Any]] = []
    for item in raw_list:
        if not isinstance(item, dict):
            continue
        item_copy = dict(item)
        if not item_copy.get("storage_uri") and item_copy.get("gs_uri"):
            item_copy["storage_uri"] = item_copy["gs_uri"]
        if not item_copy.get("document_title") and item_copy.get("document_name"):
            item_copy["document_title"] = item_copy["document_name"]
        doc_id = str(item_copy.get("document_id") or item_copy.get("id") or "").strip()
        if not item_copy.get("filename"):
            if doc_id and canonical in {"policy", "kod", "procedure"}:
                item_copy["filename"] = f"{canonical}{doc_id}.json"
            elif item_copy.get("document_name"):
                item_copy["filename"] = str(item_copy["document_name"]).strip()
            elif item_copy.get("storage_uri"):
                item_copy["filename"] = str(item_copy["storage_uri"]).strip().rsplit("/", 1)[-1]
        doc_sec_prefix = doc_id or str(item_copy.get("filename") or item_copy.get("document_title") or "doc")
        item_copy["sections"] = _normalize_sections_from_entry(item_copy, doc_sec_prefix)
        if not item_copy["sections"] and (sources_by_uri or sources_by_name):
            uri_k = str(item_copy.get("storage_uri") or item_copy.get("gs_uri") or "").strip().lower()
            name_k = str(item_copy.get("document_name") or item_copy.get("document_title") or item_copy.get("filename") or "").strip().lower()
            matched_srcs = sources_by_uri.get(uri_k) or sources_by_name.get(name_k) or []
            if matched_srcs:
                item_copy["sections"] = [dict(s) for s in matched_srcs]
        normalized_entries.append(item_copy)
    return normalized_entries


def _resolve_existing_registry_blob(gcs_utils: GCSUtils, plan_number: str, document_type: str) -> str:
    canonical = normalize_scoping_source(document_type) or (document_type or "").strip().lower()
    candidates = _resolve_registry_blob_candidates(plan_number, canonical)

    # Check if review_data_extraction has a storage_uri or registry_storage_uri that exists in gcs_utils
    if DatabaseConnector is not None:
        try:
            db_conn = DatabaseConnector()
            db_ds = source_to_db_data_source(canonical)
            rows = db_conn.get_data_extraction_rows_for_plan(plan_number, data_sources=[db_ds])
            meta = (rows.get(db_ds) or {}).get("metadata")
            if isinstance(meta, dict):
                for uri_key in ("registry_storage_uri", "storage_uri", "context_file"):
                    blob_candidate = _blob_path_from_uri(meta.get(uri_key))
                    if blob_candidate and blob_candidate not in candidates:
                        candidates.insert(0, blob_candidate)
        except Exception:
            pass

    for blob in candidates:
        if not gcs_utils.blob_exists(blob):
            continue
        try:
            payload = gcs_utils.read_blob_json(blob)
            if _is_valid_registry_payload(payload):
                return blob
        except Exception:
            continue
    return candidates[0]


def _load_combined_context_entries(
    gcs_utils: GCSUtils,
    plan_number: str,
    document_type: str,
) -> Tuple[List[Dict[str, Any]], str, bool]:
    """
    Loads and merges document + section entries from both `review_data_extraction.metadata`
    and the GCS context JSON blob (`relevant_{type}.json`, `kod20.json`, `findings_details.json`,
    `historical_plan_details.json`).
    Returns (entries, context_file_blob, source_exists).
    """
    canonical = normalize_scoping_source(document_type) or (document_type or "").strip().lower()
    registry_blob = _resolve_existing_registry_blob(gcs_utils, plan_number, canonical)
    blob_exists = gcs_utils.blob_exists(registry_blob)
    entries: List[Dict[str, Any]] = []
    valid_gcs_payload = False

    def _hydrate_item_sections(item: Dict[str, Any]) -> None:
        if item.get("sections"):
            return
        part_candidates: List[str] = []
        uri_blob = _blob_path_from_uri(item.get("storage_uri"))
        if uri_blob and uri_blob.lower().endswith(".json"):
            part_candidates.append(uri_blob)
        fname = str(item.get("filename") or "").strip()
        if fname.lower().endswith(".json"):
            part_candidates.append(f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{canonical}/{fname}")
        for part_blob in part_candidates:
            if not part_blob or not gcs_utils.blob_exists(part_blob):
                continue
            try:
                part_payload = gcs_utils.read_blob_json(part_blob)
                if isinstance(part_payload, dict):
                    item["sections"] = _normalize_sections_from_entry(
                        part_payload, str(item.get("document_id") or "")
                    )
                    if item["sections"]:
                        return
            except Exception:
                continue

    if blob_exists:
        try:
            payload = gcs_utils.read_blob_json(registry_blob)
            if _is_valid_registry_payload(payload):
                valid_gcs_payload = True
                entries = _extract_normalized_registry_entries(payload, canonical, registry_blob)
                for entry_item in entries:
                    if isinstance(entry_item, dict):
                        _hydrate_item_sections(entry_item)
        except Exception:
            valid_gcs_payload = False

    # Also check review_data_extraction.metadata for structured documents/sections
    db_docs: List[Dict[str, Any]] = []
    if DatabaseConnector is not None:
        try:
            db_conn = DatabaseConnector()
            db_ds = source_to_db_data_source(canonical)
            rows = db_conn.get_data_extraction_rows_for_plan(plan_number, data_sources=[db_ds])
            meta = (rows.get(db_ds) or {}).get("metadata")
            if isinstance(meta, (dict, list)) and _is_valid_registry_payload(meta):
                raw_db_docs = meta.get("documents", []) if isinstance(meta, dict) else meta
                if raw_db_docs:
                    db_docs = _extract_normalized_registry_entries(meta, canonical, registry_blob)
        except Exception:
            db_docs = []

    if db_docs:
        # Merge db_docs into entries, enriching or adding documents/sections from DB metadata
        by_key: Dict[str, Dict[str, Any]] = {}
        for item in entries:
            key = str(
                item.get("filename")
                or item.get("document_id")
                or item.get("id")
                or item.get("document_title")
                or item.get("title")
                or ""
            ).strip().lower()
            # Prefer parent entries that own a `sections` list over flattened child entries sharing `filename`
            if key and (key not in by_key or isinstance(item.get("sections"), list)):
                by_key[key] = item
        for db_doc in db_docs:
            _hydrate_item_sections(db_doc)
            key = str(
                db_doc.get("filename")
                or db_doc.get("document_id")
                or db_doc.get("id")
                or db_doc.get("document_title")
                or db_doc.get("title")
                or ""
            ).strip().lower()
            if key and key in by_key:
                target_item = by_key[key]
                base_sections = list(target_item.get("sections") or [])
                overlay_sections = list(db_doc.get("sections") or [])
                target_item.update(db_doc)
                if base_sections and overlay_sections:
                    merged_sections = [dict(s) if isinstance(s, dict) else s for s in base_sections]
                    for db_sec in overlay_sections:
                        if not isinstance(db_sec, dict):
                            continue
                        db_nid = str(db_sec.get("node_id") or "").strip().lower()
                        db_sid = str(db_sec.get("section_id") or "").strip().lower()
                        db_stitle = str(db_sec.get("section_title") or "").strip().lower()
                        matched_base = False
                        for base_sec in merged_sections:
                            if not isinstance(base_sec, dict):
                                continue
                            b_nid = str(base_sec.get("node_id") or "").strip().lower()
                            b_sid = str(base_sec.get("section_id") or "").strip().lower()
                            b_stitle = str(base_sec.get("section_title") or "").strip().lower()
                            if (
                                (db_nid and b_nid and db_nid == b_nid)
                                or (db_sid and b_sid and db_sid == b_sid)
                                or (db_stitle and b_stitle and db_stitle == b_stitle)
                            ):
                                base_sec.update(db_sec)
                                matched_base = True
                        if not matched_base:
                            merged_sections.append(dict(db_sec))
                    if db_doc.get("excluded") is True or str(db_doc.get("status") or "").lower() in ("excluded", "removed"):
                        for base_sec in merged_sections:
                            if isinstance(base_sec, dict):
                                base_sec["excluded"] = True
                                base_sec["status"] = "excluded"
                    target_item["sections"] = merged_sections
                elif overlay_sections or base_sections:
                    target_item["sections"] = overlay_sections or base_sections

                # Also sync flattened child entries (GFMS findings, historical items, LRR mandates)
                doc_is_excluded = bool(target_item.get("excluded")) or str(target_item.get("status") or "").lower() in ("excluded", "removed")
                sec_lookup = [s for s in (target_item.get("sections") or []) if isinstance(s, dict)]
                for child in entries:
                    if child is target_item or not isinstance(child, dict) or isinstance(child.get("sections"), list):
                        continue
                    if str(child.get("filename") or "").strip().lower() != str(target_item.get("filename") or "").strip().lower():
                        continue
                    if doc_is_excluded:
                        child["excluded"] = True
                        child["status"] = "removed"
                        continue
                    c_nid = str(child.get("node_id") or "").strip().lower()
                    c_sid = str(child.get("section_id") or child.get("document_id") or "").strip().lower()
                    c_stitle = str(child.get("section_title") or child.get("title") or "").strip().lower()
                    for sec in sec_lookup:
                        s_nid = str(sec.get("node_id") or "").strip().lower()
                        s_sid = str(sec.get("section_id") or "").strip().lower()
                        s_stitle = str(sec.get("section_title") or "").strip().lower()
                        if (
                            (c_nid and s_nid and c_nid == s_nid)
                            or (c_sid and s_sid and c_sid == s_sid)
                            or (c_stitle and s_stitle and c_stitle == s_stitle)
                        ):
                            sec_ex = bool(sec.get("excluded")) or str(sec.get("status") or "").lower() in ("excluded", "removed")
                            child["excluded"] = sec_ex
                            child["status"] = "removed" if sec_ex else "active"
                            break
            else:
                entries.append(db_doc)
                if key:
                    by_key[key] = db_doc

    source_exists = valid_gcs_payload or bool(db_docs)
    return entries, registry_blob, source_exists


_COLLECTION_PARENT_FILES = {
    "historical_plan_details.json",
    "findings_details.json",
    "internet_search_data_enriched.json",
    "internet_search_data.json",
}
_COLLECTION_SOURCES = {"gfms", "historical_scoping_document", "lrr"}


def _match_candidate_against_entries(
    candidate: Any,
    entries: List[Dict[str, Any]],
    document_type: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    """
    Matches a candidate document or section against normalized entries (and their `sections` arrays).
    Returns (sorted_matches, best_suggestion).
    Each match dict is {"item": doc_dict, "section": optional_section_dict, "score": float}.
    """
    matches: List[Dict[str, Any]] = []
    best_suggestion: Optional[str] = None
    best_suggestion_score = 0.0
    target = str(getattr(candidate, "title", None) or "").strip()
    doc_id_val = getattr(candidate, "document_id", None)
    doc_id_str = str(doc_id_val).strip() if doc_id_val is not None and str(doc_id_val).strip() else None
    filename_str = str(getattr(candidate, "filename", None) or "").strip() or None
    sec_id_val = getattr(candidate, "section_id", None)
    section_id_str = str(sec_id_val).strip() if sec_id_val is not None and str(sec_id_val).strip() else None
    section_title_str = str(getattr(candidate, "section_title", None) or "").strip() or None
    node_id_str = str(getattr(candidate, "node_id", None) or "").strip() or None
    canonical_dtype = normalize_scoping_source(document_type or getattr(candidate, "document_type", None)) or ""
    is_collection_source = canonical_dtype in _COLLECTION_SOURCES
    target_norm_tokens = set(re.sub(r"[^a-z0-9]+", " ", target.lower()).split()) if target else set()

    for item in entries:
        if not isinstance(item, dict):
            continue
        item_doc_id = str(item.get("document_id") or item.get("id") or "").strip()
        item_fname = str(item.get("filename") or "").strip()
        item_title = str(
            item.get("document_title")
            or item.get("title")
            or item.get("document_name")
            or item.get("name")
            or ""
        ).strip()

        doc_score = 0.0
        if doc_id_str and item_doc_id and item_doc_id.lower() == doc_id_str.lower():
            doc_score = 1.0
        elif filename_str and item_fname and item_fname.lower() == filename_str.lower():
            doc_score = 1.0
        elif target and item_fname and target.lower() == item_fname.lower():
            doc_score = 1.0
        else:
            values = [item_title, item_fname, item_doc_id]
            for val in values:
                if not val:
                    continue
                sc = _title_similarity_score(target, val)
                if sc > doc_score:
                    doc_score = sc
                if sc > best_suggestion_score:
                    best_suggestion_score = sc
                    best_suggestion = val

        # Check section-level matches inside item["sections"]
        matched_section: Optional[Dict[str, Any]] = None
        sec_score = 0.0
        has_explicit_section_query = bool(section_id_str or section_title_str or node_id_str)
        item_sections = item.get("sections") or []
        for sec in item_sections:
            if not isinstance(sec, dict):
                continue
            s_id = str(sec.get("section_id") or "").strip()
            s_title = str(sec.get("section_title") or "").strip()
            s_node = str(sec.get("node_id") or "").strip()
            s_audit = str(sec.get("audit_number") or "").strip()
            s_report = str(sec.get("report_number") or "").strip()

            cur_sec_score = 0.0
            if node_id_str and s_node and s_node.lower() == node_id_str.lower():
                cur_sec_score = 1.0
            elif section_id_str and s_id:
                if s_id.lower() == section_id_str.lower():
                    cur_sec_score = 1.0
                elif (
                    not is_collection_source
                    and ("." in s_id or "." in section_id_str)
                    and (
                        s_id.lower().startswith(f"{section_id_str.lower()}.")
                        or section_id_str.lower().startswith(f"{s_id.lower()}.")
                    )
                ):
                    cur_sec_score = 0.85
            elif section_title_str and s_title:
                cur_sec_score = _title_similarity_score(section_title_str, s_title)
            elif not has_explicit_section_query and target and doc_score < 0.55:
                # Allow matching a section directly when user asks to exclude/include a finding ID,
                # historical plan number, or section title directly.
                if s_id and any(ch.isdigit() for ch in s_id) and s_id.lower() in target_norm_tokens:
                    cur_sec_score = 1.0
                else:
                    for candidate_val in (s_id, s_title, s_node, s_audit, s_report):
                        if not candidate_val:
                            continue
                        if target.lower() == candidate_val.lower():
                            cur_sec_score = 1.0
                            break
                        sc = _title_similarity_score(target, candidate_val)
                        if sc > cur_sec_score:
                            cur_sec_score = sc
                        if sc > best_suggestion_score:
                            best_suggestion_score = sc
                            best_suggestion = candidate_val

            if cur_sec_score >= 0.55 and cur_sec_score > sec_score:
                sec_score = cur_sec_score
                matched_section = sec

        if has_explicit_section_query:
            if matched_section is not None:
                if doc_score >= 0.55:
                    matches.append(
                        {
                            "item": item,
                            "section": matched_section,
                            "score": round((doc_score + sec_score) / 2.0, 3),
                        }
                    )
                elif not target or is_collection_source or sec_score >= 0.85:
                    matches.append({"item": item, "section": matched_section, "score": sec_score})
        else:
            if doc_score >= 0.55:
                matches.append({"item": item, "section": None, "score": doc_score})
            elif matched_section is not None and sec_score >= 0.55:
                matches.append({"item": item, "section": matched_section, "score": sec_score})

    prefer_pdf = bool(
        (filename_str and filename_str.lower().endswith(".pdf"))
        or (target and target.lower().endswith(".pdf"))
    )

    def _sort_key(entry_match: Dict[str, Any]) -> Tuple[float, int]:
        fname_lower = str(entry_match["item"].get("filename") or "").strip().lower()
        is_parent_collection = (
            is_collection_source
            and not prefer_pdf
            and entry_match.get("section") is not None
            and fname_lower in _COLLECTION_PARENT_FILES
        )
        return (float(entry_match["score"]), 1 if is_parent_collection else 0)

    matches.sort(key=_sort_key, reverse=True)
    return matches, best_suggestion



def _strip_gs_bucket_prefix(storage_uri: Optional[str]) -> Optional[str]:
    if not storage_uri:
        return None
    uri = str(storage_uri).strip()
    if uri.startswith("gs://"):
        parts = uri[5:].split("/", 1)
        if len(parts) == 2 and parts[1]:
            return parts[1]
        return None
    return uri or None


def _apply_mutation_to_gcs_payload(
    payload: Any,
    action: Any,
    is_exclude: bool,
    actor: str = "approved_plan",
) -> Tuple[Any, bool]:
    """Mutate a GCS registry, part JSON, GFMS findings JSON, or historical plan JSON."""
    status_doc = "removed" if is_exclude else "active"
    status_sec = "excluded" if is_exclude else "active"

    target_title = str(getattr(action, "title", None) or "").strip()
    target_filename = str(getattr(action, "filename", None) or "").strip()
    target_doc_id = str(getattr(action, "document_id", None) or "").strip()
    target_pk = str(getattr(action, "row_primary_key", None) or "").strip()
    target_sec_id = getattr(action, "section_id", None)
    target_sec_title = str(getattr(action, "section_title", None) or "").strip()
    target_node_id = str(getattr(action, "node_id", None) or "").strip()
    has_section_target = bool(target_sec_id is not None or target_sec_title or target_node_id)

    def _matches_section_dict(sec: Dict[str, Any], idx_1based: Optional[int] = None) -> bool:
        sec_nid = str(sec.get("node_id") or "").strip()
        sec_id_val = sec.get("section_id")
        if sec_id_val is None and idx_1based is not None:
            sec_id_val = idx_1based
        sec_title_val = str(
            sec.get("section_title") or sec.get("title") or sec.get("header_path") or ""
        ).strip()
        if target_node_id and sec_nid and sec_nid.lower() == target_node_id.lower():
            return True
        if target_sec_id is not None and sec_id_val is not None and str(sec_id_val).strip() == str(target_sec_id).strip():
            return True
        if target_sec_title and sec_title_val:
            if sec_title_val.lower() == target_sec_title.lower() or _title_similarity_score(target_sec_title, sec_title_val) >= 0.7:
                return True
        return False

    # Case 1: Part JSON with {"nodes": [...]}
    if isinstance(payload, dict) and isinstance(payload.get("nodes"), list) and "documents" not in payload:
        payload_copy = dict(payload)
        nodes = list(payload_copy.get("nodes") or [])
        mutated = False
        if has_section_target:
            new_nodes = []
            for idx, node in enumerate(nodes, start=1):
                if isinstance(node, dict) and _matches_section_dict(node, idx_1based=idx):
                    nc = dict(node)
                    nc["excluded"] = is_exclude
                    nc["status"] = status_sec
                    new_nodes.append(nc)
                    mutated = True
                else:
                    new_nodes.append(node)
            if mutated:
                payload_copy["nodes"] = new_nodes
                return payload_copy, True
        else:
            payload_copy["excluded"] = is_exclude
            payload_copy["status"] = status_doc
            new_nodes = []
            for node in nodes:
                if isinstance(node, dict):
                    nc = dict(node)
                    nc["excluded"] = is_exclude
                    nc["status"] = status_sec
                    new_nodes.append(nc)
                else:
                    new_nodes.append(node)
            payload_copy["nodes"] = new_nodes
            return payload_copy, True
        return payload, False

    # Case 2: GFMS findings payload [{"responsePayload": [...]}]
    if (
        isinstance(payload, list)
        and payload
        and isinstance(payload[0], dict)
        and isinstance(payload[0].get("responsePayload"), list)
    ):
        updated_list = []
        mutated = False
        is_whole_file = (
            not has_section_target
            and target_filename.lower() == "findings_details.json"
            and target_title.lower() in {"findings_details.json", "gfms", "gfms data", ""}
        )
        for wrapper in payload:
            if not isinstance(wrapper, dict):
                updated_list.append(wrapper)
                continue
            w_copy = dict(wrapper)
            if is_whole_file:
                w_copy["excluded"] = is_exclude
                w_copy["status"] = status_doc
                mutated = True
            findings = w_copy.get("responsePayload")
            if isinstance(findings, list):
                new_findings = []
                for idx, f in enumerate(findings, start=1):
                    if not isinstance(f, dict):
                        new_findings.append(f)
                        continue
                    fid = str(f.get("findingId") or f.get("id") or idx)
                    ftitle = str(f.get("findingTitle") or f.get("title") or f"Finding {fid}")
                    fnode = f"gfms:finding:{fid}"
                    match_f = is_whole_file
                    if not match_f:
                        if target_node_id and target_node_id.lower() == fnode.lower():
                            match_f = True
                        elif target_sec_id is not None and str(target_sec_id).strip() == fid:
                            match_f = True
                        elif target_pk and target_pk == fid:
                            match_f = True
                        elif target_doc_id and target_doc_id == fid:
                            match_f = True
                        elif target_sec_title and _title_similarity_score(target_sec_title, ftitle) >= 0.65:
                            match_f = True
                        elif target_title and (target_title == fid or _title_similarity_score(target_title, ftitle) >= 0.65):
                            match_f = True
                    if match_f:
                        fc = dict(f)
                        fc["excluded"] = is_exclude
                        fc["status"] = status_sec
                        new_findings.append(fc)
                        mutated = True
                    else:
                        new_findings.append(f)
                w_copy["responsePayload"] = new_findings
            updated_list.append(w_copy)
        return (updated_list if mutated else payload), mutated

    # Case 3: Historical plan details list [{"Plan Item Number": ..., "Plan Item Title": ...}]
    if (
        isinstance(payload, list)
        and payload
        and isinstance(payload[0], dict)
        and ("Plan Item Number" in payload[0] or "Plan Item Title" in payload[0])
    ):
        updated_items = []
        mutated = False
        is_whole_file = (
            not has_section_target
            and target_filename.lower() == "historical_plan_details.json"
            and target_title.lower() in {"historical_plan_details.json", "historical scoping document", ""}
        )
        for idx, item in enumerate(payload, start=1):
            if not isinstance(item, dict):
                updated_items.append(item)
                continue
            plan_num = str(item.get("Plan Item Number") or item.get("plan_item_number") or idx)
            plan_title = str(item.get("Plan Item Title") or item.get("title") or f"Historical Plan {plan_num}")
            pnode = f"historical_plan:{plan_num}"
            match_p = is_whole_file
            if not match_p:
                if target_node_id and target_node_id.lower() == pnode.lower():
                    match_p = True
                elif target_sec_id is not None and str(target_sec_id).strip() == plan_num:
                    match_p = True
                elif target_pk and target_pk == plan_num:
                    match_p = True
                elif target_doc_id and target_doc_id == plan_num:
                    match_p = True
                elif target_sec_title and (target_sec_title == plan_num or _title_similarity_score(target_sec_title, plan_title) >= 0.65):
                    match_p = True
                elif target_title and (target_title == plan_num or _title_similarity_score(target_title, plan_title) >= 0.65):
                    match_p = True
            if match_p:
                ic = dict(item)
                ic["excluded"] = is_exclude
                ic["status"] = status_doc
                updated_items.append(ic)
                mutated = True
            else:
                updated_items.append(item)
        return (updated_items if mutated else payload), mutated

    # Case 3b: LRR enriched mandates [{"Risk Name": ..., "Mandates": [...]}]
    if (
        isinstance(payload, list)
        and payload
        and isinstance(payload[0], dict)
        and isinstance(payload[0].get("Mandates"), list)
    ):
        updated_risks = []
        mutated = False
        is_whole_file = (
            not has_section_target
            and target_filename.lower() in {"internet_search_data_enriched.json", "internet_search_data.json"}
            and target_title.lower() in {
                "internet_search_data_enriched.json",
                "internet_search_data.json",
                "lrr",
                "regulatory & internet search mandates",
                "",
            }
        )
        m_idx = 0
        for risk in payload:
            if not isinstance(risk, dict):
                updated_risks.append(risk)
                continue
            r_copy = dict(risk)
            if is_whole_file:
                r_copy["excluded"] = is_exclude
                r_copy["status"] = status_doc
                mutated = True
            new_mandates = []
            for mandate in r_copy.get("Mandates") or []:
                if not isinstance(mandate, dict):
                    new_mandates.append(mandate)
                    continue
                m_idx += 1
                m_title = str(
                    mandate.get("Regulatory Mandate")
                    or mandate.get("mandate")
                    or mandate.get("Citation")
                    or ""
                )
                mnode = f"lrr:mandate:{m_idx}"
                match_m = is_whole_file
                if not match_m:
                    if target_node_id and target_node_id.lower() == mnode.lower():
                        match_m = True
                    elif target_sec_id is not None and str(target_sec_id).strip() == str(m_idx):
                        match_m = True
                    elif target_pk and target_pk == str(m_idx):
                        match_m = True
                    elif target_doc_id and target_doc_id == str(m_idx):
                        match_m = True
                    elif target_sec_title and (
                        target_sec_title.lower() == m_title.lower()
                        or _title_similarity_score(target_sec_title, m_title) >= 0.65
                    ):
                        match_m = True
                    elif target_title and (
                        target_title == str(m_idx)
                        or _title_similarity_score(target_title, m_title) >= 0.65
                    ):
                        match_m = True
                if match_m:
                    mc = dict(mandate)
                    mc["excluded"] = is_exclude
                    mc["status"] = status_sec
                    new_mandates.append(mc)
                    mutated = True
                else:
                    new_mandates.append(mandate)
            r_copy["Mandates"] = new_mandates
            updated_risks.append(r_copy)
        return (updated_risks if mutated else payload), mutated

    # Case 4: Standard registry dict {"documents": [...]} or list of document dicts
    entries = payload.get("documents", []) if isinstance(payload, dict) else payload if isinstance(payload, list) else []
    if not isinstance(entries, list):
        return payload, False

    updated_entries = []
    mutated = False
    for entry in entries:
        if not isinstance(entry, dict):
            updated_entries.append(entry)
            continue
        current_title = str(entry.get("document_title") or entry.get("title") or entry.get("name") or "")
        current_filename = str(entry.get("filename") or "")
        current_doc_id = str(entry.get("document_id") or entry.get("id") or "")
        entry_pk = _entry_primary_key(entry)

        pk_match = bool(target_pk) and entry_pk is not None and entry_pk == target_pk
        doc_id_match = bool(target_doc_id) and current_doc_id and current_doc_id == target_doc_id
        fname_match = bool(target_filename) and current_filename and current_filename.lower() == target_filename.lower()
        title_match = bool(target_title) and (
            current_title.lower() == target_title.lower()
            or (current_filename and current_filename.lower() == target_title.lower())
            or _title_similarity_score(target_title, current_title) >= 0.75
        )
        doc_matched = pk_match or doc_id_match or fname_match or title_match

        if doc_matched:
            entry_copy = dict(entry)
            if has_section_target:
                sec_mutated = False
                if isinstance(entry_copy.get("sections"), list) and entry_copy["sections"]:
                    new_secs = []
                    for idx, sec in enumerate(entry_copy["sections"], start=1):
                        if isinstance(sec, dict) and _matches_section_dict(sec, idx_1based=idx):
                            sc = dict(sec)
                            sc["excluded"] = is_exclude
                            sc["status"] = status_sec
                            new_secs.append(sc)
                            sec_mutated = True
                        else:
                            new_secs.append(sec)
                    entry_copy["sections"] = new_secs
                if isinstance(entry_copy.get("nodes"), list) and entry_copy["nodes"]:
                    new_nodes = []
                    for idx, node in enumerate(entry_copy["nodes"], start=1):
                        if isinstance(node, dict) and _matches_section_dict(node, idx_1based=idx):
                            nc = dict(node)
                            nc["excluded"] = is_exclude
                            nc["status"] = status_sec
                            new_nodes.append(nc)
                            sec_mutated = True
                        else:
                            new_nodes.append(node)
                    entry_copy["nodes"] = new_nodes
                if not sec_mutated:
                    existing_secs = list(entry_copy.get("sections") or [])
                    existing_secs.append(
                        {
                            "section_id": target_sec_id if target_sec_id is not None else len(existing_secs) + 1,
                            "section_title": target_sec_title or target_node_id or "Section",
                            "node_id": target_node_id or None,
                            "status": status_sec,
                            "excluded": is_exclude,
                        }
                    )
                    entry_copy["sections"] = existing_secs
                    sec_mutated = True
                if sec_mutated:
                    if not is_exclude:
                        entry_copy["excluded"] = False
                        entry_copy["status"] = "active"
                    mutated = True
            else:
                entry_copy["status"] = status_doc
                entry_copy["excluded"] = is_exclude
                if is_exclude:
                    entry_copy["removed_at"] = "approved_execution"
                    entry_copy["removed_by"] = actor
                else:
                    entry_copy["included_at"] = "approved_execution"
                    entry_copy["included_by"] = actor
                if isinstance(entry_copy.get("sections"), list):
                    entry_copy["sections"] = [
                        {**s, "excluded": is_exclude, "status": status_sec} if isinstance(s, dict) else s
                        for s in entry_copy["sections"]
                    ]
                mutated = True
            updated_entries.append(entry_copy)
        else:
            updated_entries.append(entry)

    if not mutated:
        return payload, False
    if isinstance(payload, dict):
        payload_copy = dict(payload)
        payload_copy["documents"] = updated_entries
        return payload_copy, True
    return updated_entries, True


async def verify_document_context_logic(request: DocumentVerificationRequest):
    """Verify candidate documents/sections exist in the active plan context and collect metadata before approval."""
    try:
        logger.info("Verifying candidate documents for plan: %s, candidates=%s", request.plan_number, len(request.candidates))
        env_config = EnvironmentConfig()
        gcs_utils = GCSUtils(env_config)

        verified = []
        unmatched = []

        for candidate in request.candidates:
            doc_type = candidate.document_type or ""
            doc_title = (
                candidate.title
                or candidate.filename
                or (str(candidate.document_id) if candidate.document_id is not None else "")
                or candidate.section_title
                or candidate.node_id
                or ""
            )
            has_target = bool(
                doc_title
                or candidate.section_id is not None
                or candidate.section_title
                or candidate.node_id
            )
            if not doc_type or not has_target:
                unmatched.append(DocumentVerificationResult(
                    document_type=doc_type or None,
                    title=doc_title or None,
                    matched=False,
                    status="invalid_type",
                    reason="Document type or title missing."
                ))
                continue

            normalized_type = normalize_scoping_source(doc_type)
            if not normalized_type or normalized_type not in SCOPING_SOURCES:
                unmatched.append(DocumentVerificationResult(
                    document_type=doc_type.strip().lower(),
                    title=doc_title,
                    matched=False,
                    status="invalid_type",
                    reason=f"Unsupported document type '{doc_type.strip().lower()}'."
                ))
                continue

            entries, registry_blob, source_exists = _load_combined_context_entries(
                gcs_utils, request.plan_number, normalized_type
            )
            if not source_exists:
                if not gcs_utils.blob_exists(registry_blob):
                    unmatched.append(DocumentVerificationResult(
                        document_type=normalized_type,
                        title=doc_title,
                        matched=False,
                        status="not_found",
                        context_file=registry_blob,
                        reason="Context JSON not found for this plan and document type."
                    ))
                else:
                    unmatched.append(DocumentVerificationResult(
                        document_type=normalized_type,
                        title=doc_title,
                        matched=False,
                        status="not_found",
                        context_file=registry_blob,
                        reason="Context blob exists but does not contain a valid document registry payload."
                    ))
                continue

            matches, best_suggestion = _match_candidate_against_entries(
                candidate, entries, document_type=normalized_type
            )
            if len(matches) == 0:
                unmatched.append(DocumentVerificationResult(
                    document_type=normalized_type,
                    title=doc_title,
                    filename=candidate.filename,
                    section_id=candidate.section_id,
                    section_title=candidate.section_title,
                    node_id=candidate.node_id,
                    matched=False,
                    status="not_found",
                    context_file=registry_blob,
                    reason=(
                        f"Document not found in active context JSON. Closest match: {best_suggestion}"
                        if best_suggestion
                        else "Document not found in active context JSON."
                    ),
                ))
                continue

            selected = matches[0]["item"]
            matched_section = matches[0].get("section")
            primary_key = _entry_primary_key(selected)
            resolved_doc_id = selected.get("document_id") or selected.get("id") or candidate.document_id

            verified.append(DocumentVerificationResult(
                document_type=normalized_type,
                title=str(selected.get("document_title") or selected.get("title") or selected.get("name") or doc_title),
                filename=str(selected.get("filename") or "") or candidate.filename,
                storage_uri=str(selected.get("storage_uri") or "") or candidate.storage_uri,
                document_id=str(resolved_doc_id) if resolved_doc_id is not None else None,
                section_id=matched_section.get("section_id") if matched_section else candidate.section_id,
                section_title=(
                    str(matched_section.get("section_title") or "")
                    if matched_section and matched_section.get("section_title")
                    else candidate.section_title
                ),
                node_id=(
                    str(matched_section.get("node_id") or "")
                    if matched_section and matched_section.get("node_id")
                    else candidate.node_id
                ),
                matched=True,
                status="verified",
                context_file=registry_blob,
                row_primary_key=primary_key,
                reason=f"Matched active context registry entry using natural-language similarity (score={matches[0]['score']})."
            ))

        return DocumentVerificationResponse(
            plan_number=request.plan_number,
            action=request.action,
            verified_documents=verified,
            unmatched_documents=unmatched,
            message="Verification completed against active plan context.",
        )
    except Exception as exc:
        logger.exception("Document context verification failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(exc)}")


def build_intent_analysis(request: DocumentExclusionWorkflowRequest) -> DocumentIntentAnalysis:
    """Create the lightweight LLM-style intent analysis for the workflow."""
    candidate = request.candidates[0] if request.candidates else None
    return DocumentIntentAnalysis(
        action=request.action or "exclude",
        document_type=getattr(candidate, "document_type", None) if candidate else None,
        title=getattr(candidate, "title", None) if candidate else None,
        plan_number=request.plan_number,
        scope="all_related",
        reasoning=(
            "Natural-language intent was inferred by the orchestration layer. "
            "Backend verification will confirm the exact runtime document and metadata before mutation."
        ),
        impact_analysis=DocumentImpactAnalysis(
            affected_artifacts=[
                f"dbaware_review_{request.plan_number}/inbound-data",
            ],
            downstream_jobs=["qna_session_context_refresh"],
            reasoning=(
                "Removing a document updates the active plan registry. "
                "Downstream stage reports can be re-run manually when ready."
            ),
            confidence=0.9,
        ),
        requires_approval=True,
    )


async def build_document_exclusion_plan_logic(request: DocumentExclusionPlanRequest):
    """Create the user-facing plan of approved exclusion actions based on verified context."""
    try:
        actions = []
        for item in request.verified_documents:
            if not item.matched or not item.document_type or not item.title:
                continue
            has_sec = bool(item.section_id is not None or item.section_title or item.node_id)
            actions.append(DocumentExclusionPlanAction(
                action=request.action,
                document_type=item.document_type,
                title=item.title,
                filename=item.filename,
                storage_uri=item.storage_uri,
                document_id=item.document_id,
                section_id=item.section_id,
                section_title=item.section_title,
                node_id=item.node_id,
                context_file=item.context_file,
                row_primary_key=item.row_primary_key,
                scope="section_only" if has_sec else "all_related",
            ))

        if not actions:
            raise HTTPException(status_code=400, detail="No verified actions available to build a plan.")

        return DocumentExclusionPlanResponse(
            plan_number=request.plan_number,
            action=request.action,
            actions=actions,
            message="Action plan was generated from the verified active context.",
            requires_approval=True,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Exclusion plan creation failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Plan creation failed: {str(exc)}")


async def execute_document_exclusion_plan_logic(request: DocumentExecutionRequest):
    """Run the approved action plan against the active runtime context."""
    try:
        logger.info("Executing approved exclusion plan for plan: %s, actions=%s", request.plan_number, len(request.actions))

        env_config = EnvironmentConfig()
        gcs_utils = GCSUtils(env_config)
        db_conn = DatabaseConnector(env_config)
        executed = []
        registry_updated = False

        for action in request.actions:
            if not action.document_type or not (action.title or action.filename or action.node_id or action.section_title):
                continue
            normalized_type = normalize_scoping_source(action.document_type)
            if not normalized_type or normalized_type not in SCOPING_SOURCES:
                continue

            actor = request.approved_by or "approved_plan"
            try:
                db_res = db_conn.mutate_data_extraction_metadata(
                    plan_number=request.plan_number,
                    document_type=normalized_type,
                    action="exclude",
                    title=action.title,
                    filename=action.filename,
                    storage_uri=action.storage_uri,
                    document_id=action.document_id or action.row_primary_key,
                    section_id=action.section_id,
                    section_title=action.section_title,
                    node_id=action.node_id,
                    actor=actor,
                )
                if db_res.get("updated"):
                    registry_updated = True
                    executed.append(action)
                else:
                    logger.warning("Exclusion metadata update failed: %s", db_res)
            except Exception as exc:
                logger.warning("DB metadata mutation failed in exclusion execution: %s", exc)

        if not executed:
            return DocumentExecutionResponse(
                plan_number=request.plan_number,
                status="error",
                message="No valid actions were executed.",
                executed=[],
                registry_updated=False,
                audit={
                    "approved_by": request.approved_by,
                    "total_actions": 0,
                    "registry_blob_prefix": f"dbaware_review_{request.plan_number}/inbound-data",
                },
            )

        status_value = "success"
        message = "Approved exclusion plan executed against active context."
        if registry_updated is False:
            status_value = "error"
            message = "Approved exclusion plan was processed, but no registry entries were updated."
        else:
            try:
                from service.context_builder import PLAN_INBOUND_CACHE
                from service.session_manager import SESSION_CACHE
                clean_plan = str(request.plan_number).strip()
                PLAN_INBOUND_CACHE.pop(clean_plan, None)
                prefix = f"{clean_plan}_"
                for cache_k in [k for k in SESSION_CACHE if k.startswith(prefix)]:
                    SESSION_CACHE.pop(cache_k, None)
            except Exception:
                pass

        return DocumentExecutionResponse(
            plan_number=request.plan_number,
            status=status_value,
            message=message,
            executed=executed,
            registry_updated=registry_updated,
            affected_sections=(
                compute_affected_preliminary_research_sections([a.document_type for a in executed])
                if registry_updated
                else []
            ),
            audit={
                "approved_by": request.approved_by,
                "total_actions": len(executed),
                "registry_blob_prefix": f"dbaware_review_{request.plan_number}/inbound-data/{request.actions[0].document_type if request.actions else 'unknown'}",
            },
        )
    except Exception as exc:
        logger.exception("Approved exclusion execution failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Execution failed: {str(exc)}")


async def orchestrate_document_exclusion_workflow(
    request: DocumentExclusionWorkflowRequest,
    verify_fn: Optional[Callable[..., Awaitable[object]]] = None,
    plan_fn: Optional[Callable[..., Awaitable[object]]] = None,
    execute_fn: Optional[Callable[..., Awaitable[object]]] = None,
) -> Dict[str, object]:
    """Simple orchestrator: intent -> verify -> plan -> execute.

    This keeps the workflow readable and avoids scattering orchestration logic in the router.
    """
    verify_fn = verify_fn or (lambda req: None)
    plan_fn = plan_fn or (lambda req: None)
    execute_fn = execute_fn or (lambda req: None)

    parsed_intent = build_intent_analysis(request)

    candidates = request.candidates
    if not candidates and request.user_text:
        candidates = [DocumentCandidate(document_type="policy", title=request.user_text)]

    verification_req = DocumentVerificationRequest(
        plan_number=request.plan_number,
        action=request.action,
        candidates=candidates,
        user_text=request.user_text,
        approved_by=request.approved_by,
        approved=request.approved,
    )
    verification = await verify_fn(verification_req)

    plan_req = DocumentExclusionPlanRequest(
        plan_number=request.plan_number,
        user_text=request.user_text or "document exclusion request",
        action=request.action,
        verified_documents=verification.verified_documents,
    )
    plan = await plan_fn(plan_req)

    if not plan.actions:
        return {
            "plan_number": request.plan_number,
            "status": "approval_required",
            "requires_approval": True,
            "message": "No verified documents were found for approval.",
            "intent": parsed_intent.model_dump(mode="json"),
            "verification": verification.model_dump(mode="json"),
            "plan": plan.model_dump(mode="json"),
        }

    if not request.approved and not request.approved_by:
        return {
            "plan_number": request.plan_number,
            "status": "approval_required",
            "requires_approval": True,
            "message": "Approval is required before backend execution.",
            "intent": parsed_intent.model_dump(mode="json"),
            "verification": verification.model_dump(mode="json"),
            "plan": plan.model_dump(mode="json"),
        }

    execution_actions = [
        DocumentExecutionAction(
            action=item.action,
            document_type=item.document_type,
            title=item.title,
            filename=item.filename,
            storage_uri=item.storage_uri,
            document_id=item.document_id,
            section_id=item.section_id,
            section_title=item.section_title,
            node_id=item.node_id,
            context_file=item.context_file,
            row_primary_key=item.row_primary_key,
            scope=item.scope,
        )
        for item in plan.actions
    ]

    execution_req = DocumentExecutionRequest(
        plan_number=request.plan_number,
        actions=execution_actions,
        approved_by=request.approved_by or "llm_orchestrator",
    )
    execution = await execute_fn(execution_req)

    return {
        "plan_number": request.plan_number,
        "status": "success",
        "requires_approval": False,
        "message": "Intent understood, impact assessed, and the staged workflow completed successfully.",
        "intent": parsed_intent.model_dump(mode="json"),
        "verification": verification.model_dump(mode="json"),
        "plan": plan.model_dump(mode="json"),
        "execution": execution.model_dump(mode="json"),
    }
