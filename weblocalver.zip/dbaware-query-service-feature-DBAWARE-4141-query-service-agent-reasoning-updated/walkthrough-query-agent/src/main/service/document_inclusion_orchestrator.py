from typing import Any, Awaitable, Callable, Dict, List, Optional
import logging
from fastapi import HTTPException

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from service.context_builder import PLAN_INBOUND_CACHE
from service.database_connector import (
    SCOPING_SOURCES,
    DatabaseConnector,
    compute_affected_preliminary_research_sections,
    normalize_scoping_source,
    source_to_db_data_source,
)
from service.document_exclusion_orchestrator import (
    _apply_mutation_to_gcs_payload,
    _entry_primary_key,
    _is_valid_registry_payload,
    _load_combined_context_entries,
    _match_candidate_against_entries,
    _resolve_existing_registry_blob,
    _strip_gs_bucket_prefix,
)
from service.document_service import (
    _mark_registry_document_included,
    _title_similarity_score,
    upload_documents,
)
from service.rag_retriever import (
    categorize_rag_document_ids,
    get_relevant_data_for_documents_from_rag,
)
from service.request import (
    DocumentCandidate,
    DocumentImpactAnalysis,
    DocumentInclusionExecutionAction,
    DocumentInclusionExecutionRequest,
    DocumentInclusionExecutionResponse,
    DocumentInclusionPlanAction,
    DocumentInclusionPlanRequest,
    DocumentInclusionPlanResponse,
    DocumentInclusionWorkflowRequest,
    DocumentIntentAnalysis,
    DocumentVerificationRequest,
    DocumentVerificationResponse,
    DocumentVerificationResult,
)

logger = logging.getLogger(__name__)


def _extract_categorized_type_map(categorize_response: Dict[str, Any]) -> Dict[str, str]:
    """Extracts a mapping of str(document_id) -> document_type ('policy'|'kod'|'procedure') from RAG categorize response."""
    id_to_type: Dict[str, str] = {}
    if not isinstance(categorize_response, dict):
        return id_to_type

    for doc_type in ("policy", "kod", "procedure"):
        type_list = (
            categorize_response.get(doc_type)
            or categorize_response.get(f"{doc_type}_ids")
            or categorize_response.get(f"{doc_type}_document_ids")
        )
        if isinstance(type_list, list):
            for doc_id in type_list:
                id_to_type[str(doc_id)] = doc_type

    categories_dict = categorize_response.get("categories") or categorize_response.get("categorized_documents") or categorize_response.get("results")
    if isinstance(categories_dict, dict):
        for k, v in categories_dict.items():
            k_lower = str(k).strip().lower()
            if k_lower in {"policy", "kod", "procedure"} and isinstance(v, list):
                for doc_id in v:
                    id_to_type[str(doc_id)] = k_lower
            elif isinstance(v, str) and v.strip().lower() in {"policy", "kod", "procedure"}:
                id_to_type[str(k)] = v.strip().lower()
            elif isinstance(v, dict) and str(v.get("document_type", "")).strip().lower() in {"policy", "kod", "procedure"}:
                id_to_type[str(k)] = str(v.get("document_type")).strip().lower()
    elif isinstance(categories_dict, list):
        for item in categories_dict:
            if isinstance(item, dict) and item.get("document_id") is not None:
                dtype = str(item.get("document_type") or item.get("category") or "policy").strip().lower()
                if dtype in {"policy", "kod", "procedure"}:
                    id_to_type[str(item["document_id"])] = dtype

    return id_to_type


async def verify_document_inclusion_context_logic(request: DocumentVerificationRequest) -> DocumentVerificationResponse:
    """
    Sister to verify_document_context_logic.
    Verifies candidate documents or sections to be included/added into the active plan context.
    Supports both:
      - Re-including / updating existing or previously soft-deleted entries in relevant_{type}.json
      - Adding brand-new uploaded documents, RAG document IDs, or chat context sections
    """
    try:
        logger.info(
            "Verifying candidate documents for inclusion in plan: %s, candidates=%s",
            request.plan_number,
            len(request.candidates),
        )
        env_config = EnvironmentConfig()
        gcs_utils = GCSUtils(env_config)

        verified: List[DocumentVerificationResult] = []
        unmatched: List[DocumentVerificationResult] = []

        # Pre-categorize any candidates that have a document_id but no document_type
        missing_type_ids = [
            int(c.document_id)
            for c in request.candidates
            if not c.document_type and c.document_id is not None and str(c.document_id).lstrip("-").isdigit()
        ]
        categorized_map: Dict[str, str] = {}
        if missing_type_ids:
            try:
                cat_resp = await categorize_rag_document_ids(missing_type_ids)
                categorized_map = _extract_categorized_type_map(cat_resp)
            except Exception as cat_err:
                logger.debug("Optional RAG categorization skipped during verification: %s", cat_err)

        for candidate in request.candidates:
            doc_id_str = str(candidate.document_id).strip() if candidate.document_id is not None else None
            raw_type = (candidate.document_type or "").strip().lower()
            if not raw_type and doc_id_str and doc_id_str in categorized_map:
                raw_type = categorized_map[doc_id_str]
            doc_type = normalize_scoping_source(raw_type) or raw_type

            doc_title = (
                candidate.title
                or candidate.filename
                or candidate.section_title
                or candidate.node_id
                or ""
            ).strip()
            if not doc_title and doc_id_str:
                doc_title = f"{doc_type or 'policy'}_document_{doc_id_str}"

            if not doc_type or not doc_title:
                unmatched.append(
                    DocumentVerificationResult(
                        candidate=candidate,
                        document_type=doc_type or None,
                        title=doc_title or None,
                        filename=candidate.filename,
                        storage_uri=candidate.storage_uri,
                        document_id=doc_id_str,
                        section_id=candidate.section_id,
                        section_title=candidate.section_title,
                        node_id=candidate.node_id,
                        content=candidate.content,
                        matched=False,
                        status="invalid_type",
                        reason="Document type or title missing for inclusion.",
                    )
                )
                continue

            if doc_type not in SCOPING_SOURCES:
                unmatched.append(
                    DocumentVerificationResult(
                        candidate=candidate,
                        document_type=doc_type,
                        title=doc_title,
                        filename=candidate.filename,
                        storage_uri=candidate.storage_uri,
                        document_id=doc_id_str,
                        section_id=candidate.section_id,
                        section_title=candidate.section_title,
                        node_id=candidate.node_id,
                        content=candidate.content,
                        matched=False,
                        status="invalid_type",
                        reason=f"Unsupported document type '{doc_type}'.",
                    )
                )
                continue

            entries, registry_blob, _ = _load_combined_context_entries(
                gcs_utils, request.plan_number, doc_type
            )
            matches, _ = _match_candidate_against_entries(candidate, entries, document_type=doc_type)

            if matches:
                selected = matches[0]["item"]
                matched_section = matches[0].get("section")
                primary_key = doc_id_str or _entry_primary_key(selected)

                resolved_title = str(
                    selected.get("document_title")
                    or selected.get("title")
                    or selected.get("name")
                    or doc_title
                )
                verified.append(
                    DocumentVerificationResult(
                        candidate=candidate,
                        document_type=doc_type,
                        title=resolved_title,
                        filename=str(selected.get("filename") or "") or candidate.filename,
                        storage_uri=str(selected.get("storage_uri") or "") or candidate.storage_uri,
                        document_id=primary_key,
                        section_id=matched_section.get("section_id") if matched_section else candidate.section_id,
                        section_title=(
                            str(matched_section.get("section_title") or "")
                            if matched_section and matched_section.get("section_title")
                            else candidate.section_title
                        ),
                        node_id=(
                            str(matched_section.get("node_id") or "")
                            if matched_section and matched_section.get("node_id")
                            else candidate.node_id
                        ),
                        content=candidate.content,
                        matched=True,
                        status="verified",
                        context_file=registry_blob,
                        row_primary_key=primary_key,
                        reason=f"Matched existing registry entry for inclusion/restoration (score={matches[0]['score']}).",
                    )
                )
            else:
                has_new_doc_payload = (
                    doc_type in {"policy", "kod", "procedure"}
                    and (
                        candidate.content is not None
                        or (doc_id_str is not None and doc_id_str.lstrip("-").isdigit())
                    )
                )
                if has_new_doc_payload:
                    primary_key = doc_id_str or str(len(entries) + len(verified) + 1)
                    verified.append(
                        DocumentVerificationResult(
                            candidate=candidate,
                            document_type=doc_type,
                            title=doc_title,
                            filename=candidate.filename,
                            storage_uri=candidate.storage_uri,
                            document_id=doc_id_str or primary_key,
                            section_id=candidate.section_id,
                            section_title=candidate.section_title,
                            node_id=candidate.node_id,
                            content=candidate.content,
                            matched=True,
                            status="ready_to_add",
                            context_file=registry_blob,
                            row_primary_key=primary_key,
                            reason="Verified new document/section candidate ready to be added to active context JSON.",
                        )
                    )
                else:
                    reason_msg = (
                        f"Cannot restore/include non-existent item in '{doc_type}': no matching entry exists in plan context."
                        if doc_type in {"gfms", "historical_scoping_document", "lrr"}
                        else "Document not found in plan context. Upload a file, provide content, or supply a RAG document ID to add a new document."
                    )
                    unmatched.append(
                        DocumentVerificationResult(
                            candidate=candidate,
                            document_type=doc_type,
                            title=doc_title,
                            filename=candidate.filename,
                            storage_uri=candidate.storage_uri,
                            document_id=doc_id_str,
                            section_id=candidate.section_id,
                            section_title=candidate.section_title,
                            node_id=candidate.node_id,
                            content=candidate.content,
                            matched=False,
                            status="not_found",
                            context_file=registry_blob,
                            reason=reason_msg,
                        )
                    )

        return DocumentVerificationResponse(
            plan_number=request.plan_number,
            action=request.action or "include",
            verified_documents=verified,
            unmatched_documents=unmatched,
            message="Inclusion verification completed against active plan context.",
        )
    except Exception as exc:
        logger.exception("Document inclusion context verification failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Inclusion verification failed: {str(exc)}")


def build_inclusion_intent_analysis(request: DocumentInclusionWorkflowRequest) -> DocumentIntentAnalysis:
    """Create the LLM-style intent analysis for the document/section inclusion workflow."""
    candidate = request.candidates[0] if request.candidates else None
    return DocumentIntentAnalysis(
        action=request.action or "include",
        document_type=getattr(candidate, "document_type", None) if candidate else None,
        title=getattr(candidate, "title", None) if candidate else None,
        plan_number=request.plan_number,
        scope="all_related",
        reasoning=(
            "Natural-language inclusion intent was inferred by the orchestration layer. "
            "Backend verification confirms target context files, document IDs, and metadata before mutation."
        ),
        impact_analysis=DocumentImpactAnalysis(
            affected_artifacts=[
                f"dbaware_review_{request.plan_number}/inbound-data",
            ],
            downstream_jobs=["rag_relevant_data_sync", "qna_session_context_refresh"],
            reasoning=(
                "Including a document or section updates the active plan registry and enriches Q&A session context. "
                "Downstream stage reports can be re-run manually when ready."
            ),
            confidence=0.9,
        ),
        requires_approval=True,
    )


async def build_document_inclusion_plan_logic(request: DocumentInclusionPlanRequest) -> DocumentInclusionPlanResponse:
    """Create the user-facing plan of approved inclusion actions based on verified context."""
    try:
        actions: List[DocumentInclusionPlanAction] = []
        for item in request.verified_documents:
            if not item.matched or not item.document_type or not item.title:
                continue
            has_sec = bool(item.section_id is not None or item.section_title or item.node_id)
            actions.append(
                DocumentInclusionPlanAction(
                    action=request.action or "include",
                    document_type=item.document_type,
                    title=item.title,
                    filename=item.filename,
                    storage_uri=item.storage_uri,
                    document_id=item.document_id or item.row_primary_key,
                    section_id=item.section_id,
                    section_title=item.section_title,
                    node_id=item.node_id,
                    content=item.content,
                    context_file=item.context_file,
                    row_primary_key=item.row_primary_key,
                    scope="section_only" if has_sec else "all_related",
                )
            )

        if not actions:
            raise HTTPException(status_code=400, detail="No verified inclusion actions available to build a plan.")

        return DocumentInclusionPlanResponse(
            plan_number=request.plan_number,
            action=request.action or "include",
            actions=actions,
            message="Inclusion action plan was generated from the verified context.",
            requires_approval=True,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Inclusion plan creation failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Inclusion plan creation failed: {str(exc)}")


async def persist_rag_relevant_data_to_context(
    plan_number: str,
    rag_response: Dict[str, Any],
    default_document_type: str = "policy",
    env_config: Optional[EnvironmentConfig] = None,
) -> Dict[str, Any]:
    """
    Persists relevant document sections returned by `get_relevant_data_for_documents_from_rag`
    into GCS (`inbound-data/policy/relevant_{type}/` and `inbound-data/policy/relevant_{type}.json`)
    and invalidates the in-memory plan inbound cache.
    """
    env_cfg = env_config or EnvironmentConfig()
    gcs_utils = GCSUtils(env_cfg)
    db_conn = DatabaseConnector(env_cfg)
    persisted_files: List[str] = []
    registry_updated = False

    results = rag_response.get("results") or rag_response.get("documents") or []
    if isinstance(results, dict):
        # Support {"policy": [...], "kod": [...], "procedure": [...]}
        flattened = []
        for dtype, items in results.items():
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict):
                        item_copy = dict(item)
                        item_copy.setdefault("document_type", dtype)
                        flattened.append(item_copy)
        results = flattened

    if not isinstance(results, list):
        results = []

    for idx, entry in enumerate(results, start=1):
        if not isinstance(entry, dict):
            continue
        doc_type = str(entry.get("document_type") or default_document_type or "policy").strip().lower()
        if doc_type not in {"policy", "kod", "procedure"}:
            doc_type = "policy"

        # A result group may itself contain a nested `documents` or `chunks` list
        nested_docs = entry.get("documents") if isinstance(entry.get("documents"), list) else [entry]
        for doc_item in nested_docs:
            if not isinstance(doc_item, dict):
                continue
            doc_id = str(doc_item.get("document_id") or doc_item.get("id") or idx)
            doc_title = str(
                doc_item.get("document_title")
                or doc_item.get("title")
                or doc_item.get("name")
                or f"{doc_type}_{doc_id}"
            ).strip()
            file_name = f"{doc_type}{doc_id}.json" if doc_id.isdigit() else f"{doc_type}_{doc_id}.json"
            upload_res = await upload_documents(
                plan_number=plan_number,
                document_type=doc_type,
                items=[
                    {
                        "file_name": f"{doc_type}_{doc_id}.json",
                        "document_id": doc_id,
                        "document_title": doc_title,
                        "content": doc_item.get("content") or doc_item.get("chunks") or doc_item.get("relevant_sections"),
                        "paragraphs": doc_item.get("paragraphs") or doc_item.get("chunks") or doc_item.get("relevant_sections"),
                    }
                ],
                env_config=env_cfg,
            )
            if upload_res.get("files_uploaded"):
                for fname in upload_res["files_uploaded"]:
                    file_name = fname
                    persisted_files.append(
                        f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{doc_type}/{fname}"
                    )
                registry_updated = True
            else:
                reg_res = await _mark_registry_document_included(
                    plan_number=plan_number,
                    document_type=doc_type,
                    target_title=doc_title,
                    gcs_utils=gcs_utils,
                    document_entry=doc_item,
                )
                persisted_files.append(reg_res["blob_path"])
                registry_updated = True

            try:
                raw_sec_list = (
                    doc_item.get("sections")
                    or doc_item.get("relevant_sections")
                    or doc_item.get("chunks")
                    or []
                )
                normalized_secs = []
                if isinstance(raw_sec_list, list):
                    for s_idx, sec in enumerate(raw_sec_list, start=1):
                        if not isinstance(sec, dict):
                            continue
                        sid = str(sec.get("section_id") or sec.get("id") or s_idx)
                        normalized_secs.append(
                            {
                                "section_id": sid,
                                "section_title": str(sec.get("section_title") or sec.get("title") or f"Section {sid}"),
                                "node_id": str(sec.get("node_id") or f"{doc_id}:section:{sid}"),
                                "status": "active",
                                "excluded": False,
                            }
                        )
                storage_uri = f"gs://{gcs_utils.bucket_name}/dbaware_review_{plan_number}/inbound-data/policy/relevant_{doc_type}/{file_name}"
                db_conn.mutate_data_extraction_metadata(
                    plan_number=plan_number,
                    document_type=doc_type,
                    action="include",
                    title=doc_title,
                    filename=file_name,
                    storage_uri=storage_uri,
                    document_id=doc_id,
                    sections=normalized_secs or None,
                    actor="rag_sync",
                )
            except Exception as db_err:
                logger.debug("DB metadata update skipped in persist_rag_relevant_data: %s", db_err)

    if str(plan_number) in PLAN_INBOUND_CACHE:
        del PLAN_INBOUND_CACHE[str(plan_number)]

    return {
        "persisted_files": persisted_files,
        "registry_updated": registry_updated,
    }


async def execute_document_inclusion_plan_logic(request: DocumentInclusionExecutionRequest) -> DocumentInclusionExecutionResponse:
    """
    Sister to execute_document_exclusion_plan_logic.
    Executes the approved inclusion action plan against the active runtime context, fetches RAG relevant
    sections when numeric document IDs are provided, and updates GCS registries and review_data_extraction.metadata.
    """
    try:
        logger.info(
            "Executing approved inclusion plan for plan: %s, actions=%s",
            request.plan_number,
            len(request.actions),
        )

        env_config = EnvironmentConfig()
        gcs_utils = GCSUtils(env_config)
        db_conn = DatabaseConnector(env_config)
        executed: List[DocumentInclusionExecutionAction] = []
        failures: List[Dict[str, Any]] = []
        db_results: List[Dict[str, Any]] = []
        registry_updated = False

        for action in request.actions:
            if not action.document_type or not (action.title or action.filename or action.node_id or action.section_title):
                continue
            normalized_type = normalize_scoping_source(action.document_type)
            if not normalized_type or normalized_type not in SCOPING_SOURCES:
                continue

            actor = request.approved_by or "approved_plan"
            doc_id = action.document_id or action.row_primary_key
            # Restoring existing material is a metadata toggle, not a rewrite of
            # extracted inbound JSON. New content/RAG imports still use GCS below.
            db_ds = source_to_db_data_source(normalized_type)
            try:
                existing_rows = db_conn.get_data_extraction_rows_for_plan(
                    request.plan_number, data_sources=[db_ds], require_db=True
                )
            except Exception as exc:
                logger.error("DB lookup failed in inclusion execution for %s: %s", action.title or action.filename, exc, exc_info=True)
                failures.append(
                    {
                        "action": "include",
                        "document_type": normalized_type,
                        "title": action.title,
                        "filename": action.filename,
                        "section_id": action.section_id,
                        "error": str(exc),
                        "exception_type": type(exc).__name__,
                        "db_target": {
                            "db_host": getattr(db_conn, "db_host", None),
                            "db_name": getattr(db_conn, "db_name", None),
                            "db_port": getattr(db_conn, "db_port", None),
                            "db_user": getattr(db_conn, "db_user", None),
                        },
                    }
                )
                continue
            existing_meta = (existing_rows.get(db_ds) or {}).get("metadata")
            existing_docs = existing_meta.get("documents", []) if isinstance(existing_meta, dict) else []
            is_existing = any(
                isinstance(d, dict) and (
                    (action.filename and str(d.get("filename") or "").lower() == action.filename.lower())
                    or (doc_id and str(d.get("document_id") or "") == str(doc_id))
                    or str(d.get("document_title") or "").lower() == action.title.strip().lower()
                )
                for d in existing_docs
            )
            if action.content is None and (is_existing or action.section_id or action.section_title or action.node_id):
                try:
                    db_res = db_conn.mutate_data_extraction_metadata(
                        plan_number=request.plan_number, document_type=normalized_type,
                        action="include", title=action.title, filename=action.filename,
                        storage_uri=action.storage_uri, document_id=str(doc_id) if doc_id is not None else None,
                        section_id=action.section_id, section_title=action.section_title,
                        node_id=action.node_id, actor=actor,
                    )
                    if db_res.get("updated"):
                        registry_updated = True
                        executed.append(action)
                        db_results.append(db_res)
                    else:
                        err_msg = db_res.get("error") or db_res.get("reason") or "Database row was not updated."
                        logger.error("Inclusion metadata update failed for %s: %s", action.title or action.filename, db_res)
                        failures.append(
                            {
                                "action": "include",
                                "document_type": normalized_type,
                                "title": action.title,
                                "filename": action.filename,
                                "section_id": action.section_id,
                                "error": err_msg,
                                "db_result": db_res,
                            }
                        )
                except Exception as exc:
                    logger.error("DB metadata mutation failed in inclusion execution: %s", exc, exc_info=True)
                    failures.append(
                        {
                            "action": "include",
                            "document_type": normalized_type,
                            "title": action.title,
                            "filename": action.filename,
                            "section_id": action.section_id,
                            "error": str(exc),
                            "exception_type": type(exc).__name__,
                            "db_target": {
                                "db_host": getattr(db_conn, "db_host", None),
                                "db_name": getattr(db_conn, "db_name", None),
                                "db_port": getattr(db_conn, "db_port", None),
                                "db_user": getattr(db_conn, "db_user", None),
                            },
                        }
                    )
                continue
            rag_chunks = None
            if (
                normalized_type in {"policy", "kod", "procedure"}
                and doc_id
                and str(doc_id).lstrip("-").isdigit()
                and action.content is None
            ):
                try:
                    rag_resp = await get_relevant_data_for_documents_from_rag(
                        plan_number=request.plan_number,
                        documents=[{"document_type": normalized_type, "document_ids": [int(doc_id)], "top_k": 5}],
                        gcs_utils=gcs_utils,
                    )
                    if isinstance(rag_resp, dict) and rag_resp.get("results"):
                        rag_chunks = rag_resp.get("results")
                except Exception as rag_err:
                    logger.debug("Optional RAG relevant-data fetch during inclusion execution skipped: %s", rag_err)

            registry_blob = action.context_file or _resolve_existing_registry_blob(
                gcs_utils, request.plan_number, normalized_type
            )
            if normalized_type in {"policy", "kod", "procedure"}:
                has_sec = bool(action.section_id is not None or action.section_title or action.node_id)
                mutated_sec = False
                if has_sec and gcs_utils.blob_exists(registry_blob):
                    payload = gcs_utils.read_blob_json(registry_blob)
                    updated_payload, mutated_sec = _apply_mutation_to_gcs_payload(
                        payload, action, is_exclude=False, actor=actor
                    )
                    if mutated_sec:
                        gcs_utils.write_blob_json(registry_blob, updated_payload)
                        registry_updated = True
                if not mutated_sec:
                    entry_payload: Dict[str, Any] = {
                        "document_id": str(doc_id) if doc_id is not None else None,
                        "document_title": action.title.strip(),
                        "title": action.title.strip(),
                        "filename": action.filename,
                        "storage_uri": action.storage_uri,
                        "document_type": normalized_type,
                        "section_id": action.section_id,
                        "section_title": action.section_title,
                        "node_id": action.node_id,
                        "content": action.content if action.content is not None else rag_chunks,
                        "included_at": "approved_execution",
                        "included_by": actor,
                    }
                    await _mark_registry_document_included(
                        plan_number=request.plan_number,
                        document_type=normalized_type,
                        target_title=action.title.strip(),
                        gcs_utils=gcs_utils,
                        document_entry=entry_payload,
                        blob_path=action.context_file,
                    )
                    registry_updated = True
            else:
                if gcs_utils.blob_exists(registry_blob):
                    payload = gcs_utils.read_blob_json(registry_blob)
                    updated_payload, mutated = _apply_mutation_to_gcs_payload(
                        payload, action, is_exclude=False, actor=actor
                    )
                    if mutated:
                        gcs_utils.write_blob_json(registry_blob, updated_payload)
                        registry_updated = True

            # Also mutate part JSON in GCS if storage_uri or filename points to a part blob
            part_blob = _strip_gs_bucket_prefix(action.storage_uri)
            if not part_blob and action.filename and normalized_type in {"policy", "kod", "procedure"}:
                part_blob = (
                    f"dbaware_review_{request.plan_number}/inbound-data/policy/"
                    f"relevant_{normalized_type}/{action.filename}"
                )
            if part_blob and part_blob != registry_blob and gcs_utils.blob_exists(part_blob):
                try:
                    part_payload = gcs_utils.read_blob_json(part_blob)
                    updated_part, part_mutated = _apply_mutation_to_gcs_payload(
                        part_payload, action, is_exclude=False, actor=actor
                    )
                    if part_mutated:
                        gcs_utils.write_blob_json(part_blob, updated_part)
                        registry_updated = True
                except Exception as exc:
                    logger.debug("Skipping part blob mutation during inclusion for %s: %s", part_blob, exc)

            # Mutate structured metadata in dbaware_scoping.review_data_extraction
            db_ok = False
            try:
                db_res = db_conn.mutate_data_extraction_metadata(
                    plan_number=request.plan_number,
                    document_type=normalized_type,
                    action="include",
                    title=action.title,
                    filename=action.filename,
                    storage_uri=action.storage_uri,
                    document_id=str(doc_id) if doc_id is not None else None,
                    section_id=action.section_id,
                    section_title=action.section_title,
                    node_id=action.node_id,
                    actor=actor,
                )
                if db_res.get("updated"):
                    registry_updated = True
                    db_ok = True
                    db_results.append(db_res)
                else:
                    err_msg = db_res.get("error") or db_res.get("reason") or "Database row was not updated."
                    logger.error("Inclusion DB metadata update failed for %s: %s", action.title or action.filename, db_res)
                    failures.append(
                        {
                            "action": "include",
                            "document_type": normalized_type,
                            "title": action.title,
                            "filename": action.filename,
                            "section_id": action.section_id,
                            "error": err_msg,
                            "db_result": db_res,
                        }
                    )
            except Exception as exc:
                logger.error("DB metadata mutation failed in inclusion execution: %s", exc, exc_info=True)
                failures.append(
                    {
                        "action": "include",
                        "document_type": normalized_type,
                        "title": action.title,
                        "filename": action.filename,
                        "section_id": action.section_id,
                        "error": str(exc),
                        "exception_type": type(exc).__name__,
                        "db_target": {
                            "db_host": getattr(db_conn, "db_host", None),
                            "db_name": getattr(db_conn, "db_name", None),
                            "db_port": getattr(db_conn, "db_port", None),
                            "db_user": getattr(db_conn, "db_user", None),
                        },
                    }
                )

            if db_ok:
                executed.append(action)

        if str(request.plan_number) in PLAN_INBOUND_CACHE:
            del PLAN_INBOUND_CACHE[str(request.plan_number)]

        detail_summary = "; ".join(
            f"{f.get('title') or f.get('filename') or f.get('document_type')}: {f.get('error')}"
            for f in failures
        )

        if not executed:
            return DocumentInclusionExecutionResponse(
                plan_number=request.plan_number,
                status="error",
                message=f"Inclusion failed: {detail_summary}" if detail_summary else "No valid inclusion actions were executed.",
                executed=[],
                registry_updated=False,
                audit={
                    "approved_by": request.approved_by,
                    "total_actions": 0,
                    "failures": failures,
                    "db_results": db_results,
                    "registry_blob_prefix": f"dbaware_review_{request.plan_number}/inbound-data",
                },
            )

        status_value = "partial_failure" if failures else "success"
        message = (
            f"Partially executed ({len(executed)} succeeded, {len(failures)} failed): {detail_summary}"
            if failures
            else "Approved inclusion plan executed against active context."
        )
        if not registry_updated:
            status_value = "error"
            message = f"Inclusion failed: {detail_summary}" if detail_summary else "Approved inclusion plan was processed, but no registry entries were updated."

        return DocumentInclusionExecutionResponse(
            plan_number=request.plan_number,
            status=status_value,
            message=message,
            executed=executed,
            registry_updated=registry_updated,
            affected_sections=(
                compute_affected_preliminary_research_sections([a.document_type for a in executed])
                if registry_updated
                else []
            ),
            audit={
                "approved_by": request.approved_by,
                "total_actions": len(executed),
                "failures": failures,
                "db_results": db_results,
                "registry_blob_prefix": f"dbaware_review_{request.plan_number}/inbound-data/{executed[0].document_type}",
            },
        )
    except Exception as exc:
        logger.exception("Approved inclusion execution failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Inclusion execution failed: {str(exc)}")


async def orchestrate_document_inclusion_workflow(
    request: DocumentInclusionWorkflowRequest,
    verify_fn: Optional[Callable[..., Awaitable[object]]] = None,
    plan_fn: Optional[Callable[..., Awaitable[object]]] = None,
    execute_fn: Optional[Callable[..., Awaitable[object]]] = None,
) -> Dict[str, object]:
    """
    Sister to orchestrate_document_exclusion_workflow:
    intent -> verify -> plan -> approval gate -> execute.
    """
    verify_fn = verify_fn or verify_document_inclusion_context_logic
    plan_fn = plan_fn or build_document_inclusion_plan_logic
    execute_fn = execute_fn or execute_document_inclusion_plan_logic

    candidates = list(request.candidates or [])
    if request.document_ids:
        cat_map: Dict[str, str] = {}
        try:
            cat_resp = await categorize_rag_document_ids(request.document_ids)
            cat_map = _extract_categorized_type_map(cat_resp)
        except Exception as e:
            logger.debug("Categorization fallback triggered in inclusion workflow: %s", e)

        existing_ids = {str(c.document_id) for c in candidates if c.document_id is not None}
        for doc_id in request.document_ids:
            if str(doc_id) in existing_ids:
                continue
            dtype = cat_map.get(str(doc_id), "policy")
            candidates.append(
                DocumentCandidate(
                    document_type=dtype,
                    title=f"{dtype}_document_{doc_id}",
                    document_id=doc_id,
                )
            )

    if not candidates and request.user_text:
        candidates = [DocumentCandidate(document_type="policy", title=request.user_text)]

    request_with_candidates = request.model_copy(update={"candidates": candidates})
    parsed_intent = build_inclusion_intent_analysis(request_with_candidates)

    verification_req = DocumentVerificationRequest(
        plan_number=request.plan_number,
        action=request.action or "include",
        candidates=candidates,
        user_text=request.user_text,
        approved_by=request.approved_by,
        approved=request.approved,
    )
    verification = await verify_fn(verification_req)

    plan_req = DocumentInclusionPlanRequest(
        plan_number=request.plan_number,
        user_text=request.user_text or "document inclusion request",
        action=request.action or "include",
        verified_documents=verification.verified_documents,
    )
    plan = await plan_fn(plan_req)

    if not plan.actions:
        return {
            "plan_number": request.plan_number,
            "status": "approval_required",
            "requires_approval": True,
            "message": "No verified documents were found for inclusion approval.",
            "intent": parsed_intent.model_dump(mode="json"),
            "verification": verification.model_dump(mode="json"),
            "plan": plan.model_dump(mode="json"),
        }

    if not request.approved and not request.approved_by:
        return {
            "plan_number": request.plan_number,
            "status": "approval_required",
            "requires_approval": True,
            "message": "Approval is required before backend inclusion execution.",
            "intent": parsed_intent.model_dump(mode="json"),
            "verification": verification.model_dump(mode="json"),
            "plan": plan.model_dump(mode="json"),
        }

    execution_actions = [
        DocumentInclusionExecutionAction(
            action=item.action,
            document_type=item.document_type,
            title=item.title,
            filename=item.filename,
            storage_uri=item.storage_uri,
            document_id=item.document_id,
            section_id=item.section_id,
            section_title=item.section_title,
            node_id=item.node_id,
            content=item.content,
            context_file=item.context_file,
            row_primary_key=item.row_primary_key,
            scope=item.scope,
        )
        for item in plan.actions
    ]

    execution_req = DocumentInclusionExecutionRequest(
        plan_number=request.plan_number,
        actions=execution_actions,
        approved_by=request.approved_by or "llm_orchestrator",
    )
    execution = await execute_fn(execution_req)

    return {
        "plan_number": request.plan_number,
        "status": "success",
        "requires_approval": False,
        "message": "Inclusion intent understood, impact assessed, and the staged workflow completed successfully.",
        "intent": parsed_intent.model_dump(mode="json"),
        "verification": verification.model_dump(mode="json"),
        "plan": plan.model_dump(mode="json"),
        "execution": execution.model_dump(mode="json"),
    }
