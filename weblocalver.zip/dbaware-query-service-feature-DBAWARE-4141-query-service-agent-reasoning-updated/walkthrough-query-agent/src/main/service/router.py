from fastapi import APIRouter, HTTPException, status, File, UploadFile, Form
from typing import Optional, Dict, List
import os
from agent_helper.env_config import EnvironmentConfig
import logging
from datetime import datetime, timezone
from service.request import (
    ChatResponse,
    UploadJsonResponse,
    CloseSessionRequest,
    CloseSessionResponse,
    StreamlitChatRequest,
    PolicyManagementRequest,
    PolicyManagementResponse,
    DocumentListRequest,
    DocumentListResponse,
    DocumentListAllRequest,
    DocumentListAllResponse,
    BulkDocumentDeleteRequest,
    BulkDocumentDeleteResponse,
    BulkDocumentUploadRequest,
    BulkDocumentUploadResponse,
    RagDocumentIngestResponse,
    RagJobStatusResponse,
    CategorizeDocumentsRequest,
    CategorizeDocumentsResponse,
    RelevantDataForDocumentsRequest,
    RelevantDataForDocumentsResponse,
    ChatAddContextRequest,
    ChatAddContextResponse,
    DocumentVerificationRequest,
    DocumentVerificationResponse,
    DocumentExclusionPlanRequest,
    DocumentExclusionPlanResponse,
    DocumentExecutionRequest,
    DocumentExecutionResponse,
    DocumentExclusionWorkflowRequest,
    DocumentInclusionPlanRequest,
    DocumentInclusionPlanResponse,
    DocumentInclusionExecutionRequest,
    DocumentInclusionExecutionResponse,
    DocumentInclusionWorkflowRequest,
    DocumentActionExtractionRequest,
    DocumentActionExtractionResponse,
    DocumentActionVerificationRequest,
    DocumentActionVerificationResponse,
    DocumentActionPlanRequest,
    DocumentActionPlanResponse,
    DocumentActionDecisionRequest,
    DocumentActionDecisionResponse,
    DocumentActionExecutionRequest,
    DocumentActionExecutionResponse,
)
from service.qna_service import (
    chat_logic,
    upload_json_logic,
    close_session_logic,
    add_context_to_session_logic,
    DEFAULT_SESSION_ID,
)
from service.policy_service import manage_policies
from service.document_service import (
    list_documents_from_bucket,
    list_all_documents,
    delete_documents_bulk,
    upload_documents_bulk,
)
from service.rag_retriever import (
    ingest_documents_to_rag,
    get_rag_ingest_job_status,
    categorize_rag_document_ids,
    get_relevant_data_for_documents_from_rag,
)
from agent_helper.agent_card import build_agent_card
from agent_helper.action_service import construct_human_actor_record, construct_ai_actor_record, resolve_activity_details
from agent_helper.utils import GCSUtils
from service.document_exclusion_orchestrator import (
    orchestrate_document_exclusion_workflow,
    verify_document_context_logic,
    build_document_exclusion_plan_logic,
    execute_document_exclusion_plan_logic,
)
from service.document_inclusion_orchestrator import (
    orchestrate_document_inclusion_workflow,
    verify_document_inclusion_context_logic,
    build_document_inclusion_plan_logic,
    execute_document_inclusion_plan_logic,
    persist_rag_relevant_data_to_context,
)
from service.document_chat_workflow import (
    extract_document_actions,
    verify_document_actions,
    propose_document_action_plan,
    decide_document_action_plan,
    execute_document_actions,
    handle_document_chat_turn,
)


env_var = os.getenv('ENV_NAME', 'dev')
env_config = EnvironmentConfig(env_var)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/qna", tags=["Q&A Intelligence"])


@router.post(
    "/chat",
    response_model=ChatResponse,
    summary="Executes conversational query loop supporting follow-up questions against the cached document"
)
async def chat_with_document(request: StreamlitChatRequest):
    start_time = datetime.now(timezone.utc)
    total_input_token = 0
    total_output_token = 0
    query = request.question
    plan_number = request.plan_number
    context_type = request.context_type

    session_id = plan_number if plan_number else DEFAULT_SESSION_ID
    correlation_id = None  # Initialize here to handle exceptions
    activity_id, activity_type = resolve_activity_details(context_type)
    agent_card = build_agent_card(
        activity_id=activity_id,
        activity_type=activity_type,
        query=query,
        plan_item_number=plan_number
    )
    logger.info(f"***** in router AGENT_CARD = {agent_card}")
    if plan_number and not (plan_number.startswith("eval") or plan_number.startswith("unknown")):
        construct_human_actor_record(agent_card, query, activity_type)
    try:
        plan_name = request.plan_name
        research_sections = request.research_sections

        context_gcs_uri = request.context_gcs_uri
        logger.info("Handling stateful auto-initializing Streamlit request query for plan: %s, page/stage: %s", plan_number, context_type)

        # Route conversation to the stateful session matching the selected plan number
        session_id = plan_number if plan_number else DEFAULT_SESSION_ID

        # Safely extract userDetails if present in request (supports dict or Pydantic model)
        raw_user_details = getattr(request, "user_details", None) or getattr(request, "userDetails", None)
        if raw_user_details and hasattr(raw_user_details, "model_dump"):
            user_details_dict = raw_user_details.model_dump(by_alias=True)
        else:
            user_details_dict = raw_user_details if isinstance(raw_user_details, dict) else None

        if plan_number:
            approved_by_user = (
                (user_details_dict or {}).get("user")
                or (user_details_dict or {}).get("username")
                or (user_details_dict or {}).get("email")
            )
            workflow_turn = await handle_document_chat_turn(
                plan_number=plan_number,
                user_text=query,
                context_type=context_type,
                approved_by=approved_by_user,
            )
            if workflow_turn is not None:
                end_time = datetime.now(timezone.utc)
                answer = workflow_turn.get("answer", "")
                reasoning = f"Handled by document action workflow (stage={workflow_turn.get('stage')})."
                wf_input_tokens = int(workflow_turn.get("input_tokens") or 0)
                wf_output_tokens = int(workflow_turn.get("output_tokens") or 0)
                wf_total_tokens = int(workflow_turn.get("total_tokens") or (wf_input_tokens + wf_output_tokens))
                if plan_number and not (plan_number.startswith("eval") or plan_number.startswith("unknown")):
                    construct_ai_actor_record(
                        agent_card=agent_card,
                        env_config=env_config,
                        total_input_tokens=wf_input_tokens,
                        total_output_tokens=wf_output_tokens,
                        final_answer=answer,
                        start_time=start_time,
                        end_time=end_time,
                        score=1.0,
                        reasoning=reasoning,
                        context_type=activity_type,
                        response_code=200,
                    )
                return ChatResponse(
                    session_id=session_id,
                    answer=answer,
                    history_length=1,
                    groundedness_score=1.0,
                    citation_coverage=1.0,
                    unsupported_claim_count=0,
                    contradiction_score=0.0,
                    context_faithfulness=1.0,
                    answer_relevance=1.0,
                    evaluation_reasoning=reasoning,
                    input_tokens=wf_input_tokens,
                    output_tokens=wf_output_tokens,
                    total_tokens=wf_total_tokens,
                    document_workflow=workflow_turn,
                )

        chat_kwargs = {
            "session_id": session_id,
            "user_query": query,
            "plan_name": plan_name,
            "research_sections": research_sections,
            "context_type": context_type,
            "context_gcs_uri": context_gcs_uri,
            "user_details": user_details_dict,
        }
        if getattr(request, "additional_context", None) is not None:
            chat_kwargs["additional_context"] = request.additional_context
        if getattr(request, "uploaded_documents", None) is not None:
            chat_kwargs["uploaded_documents"] = request.uploaded_documents

        chat_result = await chat_logic(**chat_kwargs)

        if len(chat_result) == 6:
            answer, history_length, final_metrics, correlation_id, total_input_token, total_output_token = chat_result
            total_tokens = total_input_token + total_output_token
        else:
            answer, history_length, final_metrics, correlation_id, token_meta = chat_result
            total_input_token = token_meta.get("input_tokens", 0) if isinstance(token_meta, dict) else 0
            total_output_token = token_meta.get("output_tokens", 0) if isinstance(token_meta, dict) else 0
            total_tokens = token_meta.get("total_tokens", total_input_token + total_output_token) if isinstance(token_meta, dict) else (total_input_token + total_output_token)

        end_time = datetime.now(timezone.utc)

        if plan_number and not (plan_number.startswith("eval") or plan_number.startswith("unknown")):
            score = None
            reasoning = None
            if final_metrics:
                score = final_metrics.groundedness_score
                reasoning = final_metrics.reasoning

            construct_ai_actor_record(agent_card=agent_card, env_config=env_config, total_input_tokens=total_input_token,
                                      total_output_tokens=total_output_token, final_answer=answer, start_time=start_time, end_time=end_time,
                                      score=score, reasoning=reasoning, context_type=activity_type, response_code=200)

        return ChatResponse(
            session_id=session_id,
            answer=answer,
            history_length=history_length,
            groundedness_score=final_metrics.groundedness_score if final_metrics else 0.0,
            citation_coverage=final_metrics.citation_coverage if final_metrics else 0.0,
            unsupported_claim_count=final_metrics.unsupported_claim_count if final_metrics else 0,
            contradiction_score=final_metrics.contradiction_score if final_metrics else 0.0,
            context_faithfulness=final_metrics.context_faithfulness if final_metrics else 0.0,
            answer_relevance=final_metrics.answer_relevance if final_metrics else 0.0,
            evaluation_reasoning=final_metrics.reasoning if final_metrics else "",
            input_tokens=total_input_token,
            output_tokens=total_output_token,
            total_tokens=total_tokens
        )
    except (KeyError, Exception) as e:
        end_time = datetime.now(timezone.utc)

        if isinstance(e, KeyError) and e.args:
            error_message = str(e.args[0])
        else:
            error_message = str(e)
        if isinstance(e, KeyError):
            logger.warning(error_message)
            if plan_number and not (plan_number.startswith("eval") or plan_number.startswith("unknown")):
                construct_ai_actor_record(agent_card=agent_card, env_config=env_config, total_input_tokens=total_input_token,
                                          total_output_tokens=total_output_token, final_answer=None, start_time=start_time,
                                          end_time=end_time,
                                          score=0, reasoning=None, context_type=context_type, response_code=404)

            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=error_message
            )
        else:
            logger.error("An error occurred while generating conversational answer: %s", error_message, exc_info=True)
            if plan_number and not (plan_number.startswith("eval") or plan_number.startswith("unknown")):
                construct_ai_actor_record(agent_card=agent_card, env_config=env_config, total_input_tokens=total_input_token,
                                          total_output_tokens=total_output_token, final_answer=None, start_time=start_time,
                                          end_time=end_time,
                                          score=0, reasoning=None, context_type=context_type, response_code=500)

            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"An error occurred while generating conversational answer: {error_message}"
            )

@router.post(
    "/upload",
    response_model=UploadJsonResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Uploads a local JSON file directly into the configured GCS bucket"
)
async def upload_json_to_gcs(
    file: UploadFile = File(...),
    dest_blob_path: Optional[str] = Form(None)
):
    if not file.filename.endswith(".json"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only .json files are supported for upload."
        )
    try:
        logger.info("Uploading local file %s to GCS...", file.filename)
        file_bytes = await file.read()
        target_path, uri = await upload_json_logic(file_bytes, file.filename, dest_blob_path)
        return UploadJsonResponse(
            gcs_blob_path=target_path,
            gcs_uri=uri,
            message="JSON file successfully uploaded and verified on GCS."
        )
    except ValueError as ve:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(ve)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to upload JSON file to GCS: {str(e)}"
        )

@router.post(
    "/session/close",
    response_model=CloseSessionResponse,
    summary="Closes and evicts a session state from the in-memory cache"
)
async def close_qna_session(request: CloseSessionRequest):
    try:
        logger.info("Incoming request to close session: %s", request.session_id)
        message = await close_session_logic(request.session_id)
        return CloseSessionResponse(message=message)
    except KeyError as ke:
        logger.warning(str(ke))
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(ke)
        )
    except Exception as e:
        logger.critical("Failed to close session: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to close session: {str(e)}"
        )

@router.post(
    "/policies/manage",
    response_model=PolicyManagementResponse,
    summary="Manages policies via natural language commands - Include/Exclude/Keep/Remove policies"
)
async def manage_policy_documents(request: PolicyManagementRequest):
    """
    Policy Management Endpoint
    
    Accepts natural language commands to manage policy documents:
    - Examples: "exclude policy 1,2,3", "keep policy 2,3", "remove policy 3,4,5"
    
    Flow:
    1. Parse user command via LLM
    2. Extract policy IDs to remove
    3. Delete policy files from policy_docs folder
    4. Return results with LLM reasoning
    """
    start_time = datetime.now()
    try:
        logger.info("Incoming policy management request: %s", request.command)
        env_config = EnvironmentConfig()
        
        # Execute policy management flow
        result = await manage_policies(request.command, env_config)
        
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        
        # Log activity card
        build_agent_card(
            activity_type="policy_management",
            query=request.command,
            status="SUCCESS",
            duration_ms=duration_ms,
            metadata={
                "policies_removed": result.get("policies_removed", []),
                "available_policies": result.get("available_policies", []),
                "action": result.get("action", "")
            }
        )
        
        if result["status"] == "error":
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result["message"]
            )
        
        return PolicyManagementResponse(
            message=result["message"],
            policies_removed=result["policies_removed"],
            llm_decision_reasoning=result["llm_decision_reasoning"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        error_message = str(e)
        
        logger.error("An error occurred during policy management: %s", error_message, exc_info=True)
        
        build_agent_card(
            activity_type="policy_management",
            query=request.command,
            status="FAILURE",
            duration_ms=duration_ms,
            error_message=error_message
        )
        
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Policy management failed: {error_message}"
        )

@router.post(
    "/documents/list",
    response_model=DocumentListResponse,
    summary="Lists documents from GCS bucket by plan number and document type"
)
async def list_documents(request: DocumentListRequest):
    """
    Lists documents from GCS bucket.
    
    Path: gs://{bucket}/dbaware_review_{plan_number}/inbound-data/{document_type}/
    
    Example:
    - plan_number: "20440"
    - document_type: "policy" or "kod"
    """
    start_time = datetime.now()
    try:
        logger.info("Listing documents for plan: %s, type: %s", request.plan_number, request.document_type)
        env_config = EnvironmentConfig()
        
        # Get documents from bucket
        result = await list_documents_from_bucket(request.plan_number, request.document_type, env_config)
        
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        
        # Log activity
        build_agent_card(
            activity_type="document_list",
            query=f"plan:{request.plan_number}, type:{request.document_type}",
            status="SUCCESS",
            duration_ms=duration_ms,
            metadata={
                "plan_number": request.plan_number,
                "document_type": request.document_type,
                "file_count": result["total_count"]
            }
        )
        
        return DocumentListResponse(
            plan_number=result["plan_number"],
            document_type=result["document_type"],
            bucket_path=result["bucket_path"],
            documents=result["documents"],
            total_count=result["total_count"],
            message=result["message"],
            source=result["source"]
        )
        
    except Exception as e:
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        error_message = str(e)
        
        logger.error("An error occurred while listing documents: %s", error_message, exc_info=True)
        
        build_agent_card(
            activity_type="document_list",
            query=f"plan:{request.plan_number}, type:{request.document_type}",
            status="FAILURE",
            duration_ms=duration_ms,
            error_message=error_message
        )
        
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list documents: {error_message}"
        )

@router.post(
    "/documents/list-all",
    response_model=DocumentListAllResponse,
    summary="Lists all documents (policy, kod, procedure) grouped by type for a plan"
)
async def list_all_documents_endpoint(request: DocumentListAllRequest):
    """
    Lists all documents for a plan in one call, grouped by type.
    
    Example:
    - plan_number: "20440"
    
    Returns documents grouped by type with metadata (title, id).
    """
    start_time = datetime.now()
    try:
        logger.info("Listing all documents for plan: %s", request.plan_number)
        env_config = EnvironmentConfig()
        
        result = await list_all_documents(request.plan_number, env_config)
        
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        
        build_agent_card(
            activity_type="document_list_all",
            query=f"plan:{request.plan_number}",
            status="SUCCESS",
            duration_ms=duration_ms,
            metadata={
                "plan_number": request.plan_number,
                "total_count": result["total_count"],
                "groups_count": len(result["document_groups"])
            }
        )
        
        return DocumentListAllResponse(
            plan_number=result["plan_number"],
            document_groups=result["document_groups"],
            total_count=result["total_count"],
            message=result["message"],
            source=result["source"]
        )
        
    except Exception as e:
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        error_message = str(e)
        
        logger.error("An error occurred while listing all documents: %s", error_message, exc_info=True)
        
        build_agent_card(
            activity_type="document_list_all",
            query=f"plan:{request.plan_number}",
            status="FAILURE",
            duration_ms=duration_ms,
            error_message=error_message
        )
        
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list all documents: {error_message}"
        )

@router.post(
    "/documents/delete",
    response_model=BulkDocumentDeleteResponse,
    summary="Deletes selected documents for all document types in one request"
)
async def delete_documents_endpoint(request: BulkDocumentDeleteRequest):
    """
    Deletes documents from GCS bucket.
    
    Example:
    - plan_number: "20440"
    - document_type: "policy" or "kod" or "procedure"
    - files: ["file1.json", "file2.json"]
    """
    start_time = datetime.now()
    try:
        logger.info("Deleting documents for plan: %s, groups: %d", request.plan_number, len(request.documents))
        env_config = EnvironmentConfig()

        document_groups = [
            {"document_type": group.document_type, "items": [item.model_dump() for item in group.items]}
            for group in request.documents
        ]

        result = await delete_documents_bulk(request.plan_number, document_groups, env_config)

        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)

        build_agent_card(
            activity_type="document_delete",
            query=f"plan:{request.plan_number}, groups:{len(request.documents)}",
            status="SUCCESS",
            duration_ms=duration_ms,
            metadata={
                "plan_number": request.plan_number,
                "document_count": result["total_requested"],
                "source": "gcs"
            }
        )

        return BulkDocumentDeleteResponse(
            plan_number=result["plan_number"],
            total_requested=result["total_requested"],
            total_deleted=result["total_deleted"],
            message=result["message"],
            results=result["results"],
            affected_sections=result.get("affected_sections", []),
        )

    except Exception as e:
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        error_message = str(e)

        logger.error("An error occurred while deleting documents: %s", error_message, exc_info=True)

        build_agent_card(
            activity_type="document_delete",
            query=f"plan:{request.plan_number}",
            status="FAILURE",
            duration_ms=duration_ms,
            error_message=error_message
        )

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete documents: {error_message}"
        )

@router.post(
    "/documents/exclusion/verify-context",
    response_model=DocumentVerificationResponse,
    summary="Verifies document candidates against active context JSON and resolves owning row PK references when available"
)
async def verify_document_context(request: DocumentVerificationRequest):
    """Thin route wrapper around the orchestrator verification logic."""
    return await verify_document_context_logic(request)


@router.post(
    "/documents/exclusion-plan",
    response_model=DocumentExclusionPlanResponse,
    summary="Builds an approval plan from the user request and verified context results"
)
async def build_document_exclusion_plan(request: DocumentExclusionPlanRequest):
    """Thin route wrapper around the exclusion plan builder in the orchestrator."""
    return await build_document_exclusion_plan_logic(request)


@router.post(
    "/documents/exclusion/execute",
    response_model=DocumentExecutionResponse,
    summary="Executes the approved exclusion plan using the exact context file references and row PKs"
)
async def execute_document_exclusion_plan(request: DocumentExecutionRequest):
    """Thin route wrapper around the execution logic in the orchestrator."""
    return await execute_document_exclusion_plan_logic(request)


@router.post(
    "/documents/exclusion/workflow",
    response_model=Dict[str, object],
    summary="Single public API for the full document exclusion workflow: verify -> plan -> execute"
)
async def exclusion_workflow(request: DocumentExclusionWorkflowRequest):
    """Public API that delegates to the orchestrator for the entire exclusion lifecycle."""
    return await orchestrate_document_exclusion_workflow(
        request,
        verify_fn=verify_document_context_logic,
        plan_fn=build_document_exclusion_plan_logic,
        execute_fn=execute_document_exclusion_plan_logic,
    )


# ====================================================================
# Sister Endpoints for Document Upload, RAG Inclusion & Chat Context
# ====================================================================

@router.post(
    "/documents/upload",
    response_model=BulkDocumentUploadResponse,
    summary="Uploads and includes selected documents or sections across document types in one request (sister to /documents/delete)"
)
async def upload_documents_endpoint(request: BulkDocumentUploadRequest):
    """
    Uploads documents/sections to the GCS bucket and updates the plan registry.
    Sister endpoint to POST /qna/documents/delete.
    """
    start_time = datetime.now()
    try:
        logger.info("Uploading documents for plan: %s, groups: %d", request.plan_number, len(request.documents))
        env_cfg = EnvironmentConfig()

        document_groups = [
            {
                "document_type": group.document_type,
                "items": [
                    item.model_dump(mode="json")
                    for item in group.items
                ],
            }
            for group in request.documents
        ]

        result = await upload_documents_bulk(request.plan_number, document_groups, env_cfg)

        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)

        build_agent_card(
            activity_type="document_upload",
            query=f"plan:{request.plan_number}, groups:{len(request.documents)}",
            status="SUCCESS",
            duration_ms=duration_ms,
            metadata={
                "plan_number": request.plan_number,
                "document_count": result["total_requested"],
                "source": "gcs",
            },
        )

        return BulkDocumentUploadResponse(
            plan_number=result["plan_number"],
            total_requested=result["total_requested"],
            total_uploaded=result["total_uploaded"],
            message=result["message"],
            results=result["results"],
        )
    except Exception as e:
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        error_message = str(e)
        logger.error("An error occurred while uploading documents: %s", error_message, exc_info=True)
        build_agent_card(
            activity_type="document_upload",
            query=f"plan:{request.plan_number}",
            status="FAILURE",
            duration_ms=duration_ms,
            error_message=error_message,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to upload documents: {error_message}",
        )


@router.post(
    "/documents/ingest",
    response_model=RagDocumentIngestResponse,
    summary="Ingests uploaded policy, KOD, and/or procedure files into dbaware-rag-service (/ingest-documents)"
)
async def ingest_documents_endpoint(
    files: List[UploadFile] = File(default=[]),
    policy_files: List[UploadFile] = File(default=[]),
    kod_files: List[UploadFile] = File(default=[]),
    procedure_files: List[UploadFile] = File(default=[]),
    plan_number: Optional[str] = Form(None),
    planNumber: Optional[str] = Form(None),
    document_type: str = Form("policy"),
):
    """
    Accepts multipart/form-data file uploads (via `policy_files`, `kod_files`, `procedure_files`, or `files`)
    and forwards them to the RAG ingestion endpoint (`POST /ingest-documents`).
    """
    resolved_plan = plan_number or planNumber
    try:
        async def _read_uploads(upload_list: Optional[List[UploadFile]]) -> List[Dict[str, object]]:
            if not upload_list:
                return []
            items: List[Dict[str, object]] = []
            for up in upload_list:
                content = await up.read()
                items.append({
                    "filename": up.filename or "uploaded_document.pdf",
                    "content": content,
                    "content_type": up.content_type or "application/pdf",
                })
            return items

        policy_payload = await _read_uploads(policy_files)
        kod_payload = await _read_uploads(kod_files)
        procedure_payload = await _read_uploads(procedure_files)
        generic_payload = await _read_uploads(files)

        if not (policy_payload or kod_payload or procedure_payload or generic_payload):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="At least one file must be uploaded in policy_files, kod_files, procedure_files, or files.",
            )

        rag_result = await ingest_documents_to_rag(
            policy_files=policy_payload,
            kod_files=kod_payload,
            procedure_files=procedure_payload,
            files=generic_payload,
            default_document_type=document_type,
        )
        if rag_result.get("status") == "error":
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=rag_result.get("message", "RAG document ingestion failed."),
            )

        raw_doc_ids = rag_result.get("document_ids") or []
        doc_ids = [int(i) for i in raw_doc_ids if str(i).lstrip("-").isdigit()] if isinstance(raw_doc_ids, list) else []

        return RagDocumentIngestResponse(
            status=str(rag_result.get("status", "accepted")),
            job_id=str(rag_result["job_id"]) if rag_result.get("job_id") is not None else None,
            document_ids=doc_ids,
            plan_number=resolved_plan,
            message=str(rag_result.get("message") or "Documents submitted to RAG service for ingestion."),
            details=rag_result if isinstance(rag_result, dict) else {"result": rag_result},
        )
    except HTTPException:
        raise
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except Exception as e:
        logger.error("Error ingesting documents into RAG service: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to ingest documents: {str(e)}",
        )


@router.get(
    "/documents/ingest-jobs/{job_id}",
    response_model=RagJobStatusResponse,
    summary="Checks the status of a RAG document ingestion job (/ingest-jobs/{job_id})"
)
async def get_ingest_job_status_endpoint(job_id: str, plan_number: Optional[str] = None):
    """Polls dbaware-rag-service for the status of an ingestion job."""
    try:
        job_result = await get_rag_ingest_job_status(job_id)
        if job_result.get("status") == "error":
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=job_result.get("message", f"Failed to retrieve status for job {job_id}."),
            )
        raw_doc_ids = job_result.get("document_ids") or []
        doc_ids = [int(i) for i in raw_doc_ids if str(i).lstrip("-").isdigit()] if isinstance(raw_doc_ids, list) else []
        return RagJobStatusResponse(
            job_id=str(job_result.get("job_id") or job_id),
            status=str(job_result.get("status", "completed")),
            document_ids=doc_ids,
            message=job_result.get("message"),
            details=job_result,
        )
    except HTTPException:
        raise
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except Exception as e:
        logger.error("Error checking RAG ingestion job status for %s: %s", job_id, e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve ingestion job status: {str(e)}",
        )


@router.post(
    "/documents/categorize",
    response_model=CategorizeDocumentsResponse,
    summary="Categorizes document IDs across policy, kod, and procedure via dbaware-rag-service (/categorize-document-ids)"
)
async def categorize_documents_endpoint(request: CategorizeDocumentsRequest):
    """Calls RAG `/categorize-document-ids` for a list of document IDs."""
    try:
        cat_result = await categorize_rag_document_ids(request.document_ids)
        if cat_result.get("status") == "error":
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=cat_result.get("message", "Failed to categorize document IDs."),
            )
        return CategorizeDocumentsResponse(
            status=str(cat_result.get("status", "success")),
            document_ids=request.document_ids,
            categorized_documents=cat_result,
            message=str(cat_result.get("message") or "Successfully categorized document IDs."),
        )
    except HTTPException:
        raise
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except Exception as e:
        logger.error("Error categorizing document IDs: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to categorize documents: {str(e)}",
        )


@router.post(
    "/documents/relevant-data",
    response_model=RelevantDataForDocumentsResponse,
    summary="Retrieves relevant sections for documents from dbaware-rag-service (/get-relevant-data-for-documents) and optionally persists to plan context"
)
async def get_relevant_data_for_documents_endpoint(request: RelevantDataForDocumentsRequest):
    """
    Calls RAG `/get-relevant-data-for-documents` using plan/control metadata (from request overrides or GCS inbound data)
    and optionally persists the retrieved relevant sections into the plan's GCS context and registry.
    """
    try:
        env_cfg = EnvironmentConfig()
        gcs_utils = GCSUtils(env_cfg)
        plan_num = str(request.plan_number or request.review_id or "").strip()

        overrides = {
            k: v
            for k, v in {
                "review_id": request.review_id,
                "region": request.region,
                "au_countries": request.au_countries,
                "plan_item_title": request.plan_item_title,
                "plan_item_description": request.plan_item_description,
                "au_list": request.au_list,
                "rt_list": request.rt_list,
                "kc_list": request.kc_list,
                "control_name": request.control_name,
                "control_how": request.control_how,
                "control_what": request.control_what,
                "control_why": request.control_why,
            }.items()
            if v is not None
        }
        doc_specs = [
            spec.model_dump(mode="json")
            for spec in request.documents
        ]

        rag_response = await get_relevant_data_for_documents_from_rag(
            plan_number=plan_num,
            documents=doc_specs,
            overrides=overrides,
            gcs_utils=gcs_utils if plan_num else None,
        )
        if rag_response.get("status") == "error":
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=rag_response.get("message", "Failed to retrieve relevant data for documents from RAG."),
            )

        persisted_files: List[str] = []
        registry_updated = False
        if request.persist_to_context and plan_num:
            persist_info = await persist_rag_relevant_data_to_context(
                plan_number=plan_num,
                rag_response=rag_response,
                env_config=env_cfg,
            )
            persisted_files = persist_info.get("persisted_files", [])
            registry_updated = bool(persist_info.get("registry_updated"))

        return RelevantDataForDocumentsResponse(
            plan_number=plan_num or None,
            review_id=rag_response.get("review_id"),
            status="success",
            results=rag_response.get("results", rag_response),
            persisted_files=persisted_files,
            registry_updated=registry_updated,
            message="Successfully retrieved relevant document data from RAG service.",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error retrieving relevant data for documents: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve relevant data for documents: {str(e)}",
        )


@router.post(
    "/chat/context/add",
    response_model=ChatAddContextResponse,
    summary="Adds user-uploaded documents, RAG document IDs, or chat sections directly into the active Q&A session and plan context"
)
async def add_chat_context_endpoint(request: ChatAddContextRequest):
    """Allows users to upload documents and add sections/context through the chat window."""
    try:
        result = await add_context_to_session_logic(
            session_id=request.session_id,
            plan_number=request.plan_number,
            context_type=request.context_type,
            user_text=request.user_text,
            sections=request.sections,
            documents=request.documents,
            document_ids=request.document_ids,
            persist_to_gcs=request.persist_to_gcs,
        )
        return ChatAddContextResponse(**result)
    except Exception as e:
        logger.error("Error adding context to chat session: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to add context to chat session: {str(e)}",
        )


@router.post(
    "/documents/inclusion/verify-context",
    response_model=DocumentVerificationResponse,
    summary="Verifies document/section inclusion candidates against active context JSON and resolves owning row PK references (sister to /documents/exclusion/verify-context)"
)
async def verify_document_inclusion_context(request: DocumentVerificationRequest):
    """Thin route wrapper around the orchestrator inclusion verification logic."""
    return await verify_document_inclusion_context_logic(request)


@router.post(
    "/documents/inclusion-plan",
    response_model=DocumentInclusionPlanResponse,
    summary="Builds an approval plan for document/section inclusion from the user request and verified context results (sister to /documents/exclusion-plan)"
)
async def build_document_inclusion_plan(request: DocumentInclusionPlanRequest):
    """Thin route wrapper around the inclusion plan builder in the orchestrator."""
    return await build_document_inclusion_plan_logic(request)


@router.post(
    "/documents/inclusion/execute",
    response_model=DocumentInclusionExecutionResponse,
    summary="Executes the approved inclusion plan using the exact context file references, document IDs, and row PKs (sister to /documents/exclusion/execute)"
)
async def execute_document_inclusion_plan(request: DocumentInclusionExecutionRequest):
    """Thin route wrapper around the inclusion execution logic in the orchestrator."""
    return await execute_document_inclusion_plan_logic(request)


@router.post(
    "/documents/inclusion/workflow",
    response_model=Dict[str, object],
    summary="Single public API for the full document inclusion workflow: verify -> plan -> execute (sister to /documents/exclusion/workflow)"
)
async def inclusion_workflow(request: DocumentInclusionWorkflowRequest):
    """Public API that delegates to the orchestrator for the entire inclusion lifecycle."""
    return await orchestrate_document_inclusion_workflow(
        request,
        verify_fn=verify_document_inclusion_context_logic,
        plan_fn=build_document_inclusion_plan_logic,
        execute_fn=execute_document_inclusion_plan_logic,
    )


@router.post(
    "/documents/actions/extract",
    response_model=DocumentActionExtractionResponse,
    summary="Stage 1: Extract candidate document include/exclude actions from user chat input"
)
async def extract_document_actions_endpoint(request: DocumentActionExtractionRequest):
    """Stage 1 of the chat-driven document add/remove workflow."""
    return await extract_document_actions(
        plan_number=request.plan_number,
        user_text=request.user_text,
    )


@router.post(
    "/documents/actions/verify",
    response_model=DocumentActionVerificationResponse,
    summary="Stage 2: Verify candidate document actions against context JSONs and Liquibase DB tables (row PKs)"
)
async def verify_document_actions_endpoint(request: DocumentActionVerificationRequest):
    """Stage 2 of the chat-driven document add/remove workflow."""
    return await verify_document_actions(
        plan_number=request.plan_number,
        actions=request.actions,
    )


@router.post(
    "/documents/actions/plan",
    response_model=DocumentActionPlanResponse,
    summary="Stages 1-4: Extract, verify, and build a pending approval plan for document changes"
)
async def plan_document_actions_endpoint(request: DocumentActionPlanRequest):
    """Stages 1-4 of the chat-driven document add/remove workflow."""
    return await propose_document_action_plan(
        plan_number=request.plan_number,
        user_text=request.user_text,
        context_type=request.context_type,
        extracted_actions=request.extracted_actions,
        verification=request.verification,
    )


@router.post(
    "/documents/actions/decision",
    response_model=DocumentActionDecisionResponse,
    summary="Stages 4-6: Approve or reject a pending document change plan, translating to execution JSON and mutating context + DB"
)
async def decide_document_actions_endpoint(request: DocumentActionDecisionRequest):
    """Stages 4-6 of the chat-driven document add/remove workflow."""
    return await decide_document_action_plan(
        plan_number=request.plan_number,
        decision=request.decision,
        plan_id=request.plan_id,
        approved_by=request.approved_by,
    )


@router.post(
    "/documents/actions/execute",
    response_model=DocumentActionExecutionResponse,
    summary="Stage 6: Execute approved document actions against GCS context JSONs and Liquibase DB tables"
)
async def execute_document_actions_endpoint(request: DocumentActionExecutionRequest):
    """Stage 6 of the chat-driven document add/remove workflow."""
    return await execute_document_actions(request)

