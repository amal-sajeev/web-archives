from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, Dict, Any, List, Union

class ChatRequest(BaseModel):
    """Incoming conversation schema containing the session key and user query."""
    session_id: str
    query: str

class UserDetails(BaseModel):
    """API Gateway and caller identity / scoping details."""
    review_scope_instance_id: Optional[int] = Field(None, description="The scoped review ID from scoping-db")
    user: Optional[str] = Field(None, description="Calling user identity")
    remarks: Optional[str] = Field(None, description="Execution notes / remarks")
    model_config = ConfigDict(extra="allow", populate_by_name=True)

class StreamlitChatRequest(BaseModel):
    question: str = Field(..., description="The query asked by the compliance/scoping user")
    plan_number: Optional[str] = Field(None, alias="planNumber", description="The active scoping plan identifier")
    plan_name: Optional[str] = Field(None, alias="planName", description="The target plan name")
    context_type: str = Field("Preliminary Research Walkthrough", alias="contextType", description="The active scoping page stage")
    context_gcs_uri: Optional[str] = Field(None, alias="contextGcsUri", description="The dynamic GCS URI for stage context")
    research_sections: Optional[Dict[str, Any]] = Field(
        default_factory=dict, 
        alias="researchSections",
        description="Contextual preliminary research walkthrough chapters parsed by the frontend"
    )
    additional_context: Optional[Union[str, Dict[str, Any], List[Dict[str, Any]]]] = Field(
        default=None,
        alias="additionalContext",
        description="Optional user-supplied context text or sections to add into the active session"
    )
    uploaded_documents: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        alias="uploadedDocuments",
        description="Optional uploaded documents or sections to add into the active plan context"
    )
    user_details: Optional[UserDetails] = Field(None, alias="userDetails", description="Caller user & document scoping details")

    model_config = ConfigDict(populate_by_name=True, extra="allow")

class ChatResponse(BaseModel):
    """Outgoing response schema containing LLM synthesis details."""
    session_id: str
    answer: str
    history_length: int
    groundedness_score: Optional[float] = Field(None, description="Groundedness score (0.0 to 1.0)")
    citation_coverage: Optional[float] = Field(None, description="Citation coverage (0.0 to 1.0)")
    unsupported_claim_count: Optional[int] = Field(None, description="Count of unsupported claims")
    contradiction_score: Optional[float] = Field(None, description="Contradiction score (0.0 to 1.0)")
    context_faithfulness: Optional[float] = Field(None, description="Context faithfulness (0.0 to 1.0)")
    answer_relevance: Optional[float] = Field(None, description="Answer relevance (0.0 to 1.0)")
    evaluation_reasoning: Optional[str] = Field(None, description="Detailed critique reasoning from the LLM Judge")
    input_tokens: Optional[int] = Field(None, description="Total input/prompt tokens")
    output_tokens: Optional[int] = Field(None, description="Total output/completion tokens")
    total_tokens: Optional[int] = Field(None, description="Total combined tokens consumed")
    document_workflow: Optional[Dict[str, Any]] = Field(
        None,
        description="Populated when the chat turn was handled by the document add/remove approval workflow "
                    "(pending plan awaiting approval, rejection, or execution result)."
    )

class UploadJsonResponse(BaseModel):
    """Outgoing schema confirming successful GCS upload and returning file coordinates."""
    gcs_blob_path: str
    gcs_uri: str
    message: str

class CloseSessionRequest(BaseModel):
    """Incoming schema to close and evict an active session from memory."""
    session_id: str

class CloseSessionResponse(BaseModel):
    """Outgoing schema confirming session eviction and cache cleanup."""
    message: str

class DocumentListRequest(BaseModel):
    """Request schema to list documents from GCS/DB by plan and scoping source type."""
    plan_number: str = Field(..., description="Plan number (e.g., '20440')")
    document_type: str = Field(..., description="Scoping source type (policy, kod, procedure, gfms, historical_scoping_document, or lrr)")

class DocumentMetadata(BaseModel):
    """Metadata for a single document including title, ID, and sections from review_data_extraction."""
    file_name: str = Field(description="File name (e.g., 'policy_1.json')")
    document_title: str = Field(description="Display title from document_title field in JSON")
    document_id: str = Field(description="Unique ID from document_id field in JSON")
    storage_uri: Optional[str] = Field(None, description="GCS storage URI from review_data_extraction metadata")
    status: Optional[str] = Field(None, description="Document status ('active' or 'excluded')")
    excluded: Optional[bool] = Field(None, description="Soft-exclusion flag")
    sections: List[Dict[str, Any]] = Field(default_factory=list, description="Section-level metadata entries")

class DocumentListResponse(BaseModel):
    """Response schema containing list of documents with metadata from GCS bucket."""
    plan_number: str
    document_type: str
    bucket_path: str
    documents: list[DocumentMetadata] = Field(description="List of documents with title and ID")
    total_count: int = Field(description="Total number of files found")
    message: str
    source: str = Field(description="Source of documents: 'gcs'")

class DocumentDeleteItemDetail(BaseModel):
    """Delete / soft-exclusion item with full document or section details."""
    file_name: str = Field(..., description="File name to soft-exclude/restore (e.g., 'policy_1.json')")
    document_title: str = Field("", description="Display title of the document")
    document_id: str = Field("", description="Unique ID of the document")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section_id for section-level mutation")
    section_title: Optional[str] = Field(None, description="Optional section_title")
    node_id: Optional[str] = Field(None, description="Optional node_id")
    action: Optional[str] = Field(None, description="Optional override ('exclude' or 'include')")
    sections: Optional[List[Dict[str, Any]]] = Field(None, description="Optional section list to exclude/include")

class DocumentDeleteItem(BaseModel):
    """Single document-type delete group with full item details."""
    document_type: str = Field(..., description="Scoping source type (policy, kod, procedure, gfms, historical_scoping_document, lrr)")
    items: list[DocumentDeleteItemDetail] = Field(..., description="List of documents/sections to exclude or restore for this type")

class DocumentDeleteRequest(BaseModel):
    """Legacy single-type delete request schema (deprecated)."""
    plan_number: str = Field(..., description="Plan number (e.g., '20440')")
    document_type: str = Field(..., description="Document type (e.g., 'policy', 'kod', 'procedure')")
    files: Optional[list[str]] = Field(None, description="List of file names to delete")
    items: Optional[list[DocumentDeleteItemDetail]] = Field(None, description="Alternative: full item details")

class DocumentTypeDeleteResult(BaseModel):
    """Delete result for one document type in a bulk delete request."""
    document_type: str
    files_requested: int
    files_deleted: list[str] = Field(description="List of files successfully deleted")
    files_failed: list[str] = Field(description="List of files that failed to delete")
    total_deleted: int
    message: str
    source: str = Field(description="Source: 'gcs'")
    affected_sections: List[str] = Field(default_factory=list, description="Preliminary research section keys affected")

class BulkDocumentDeleteRequest(BaseModel):
    """Bulk multi-document delete request with full item details across all scoping sources."""
    plan_number: str = Field(..., description="Plan number (e.g., '20440')")
    documents: list[DocumentDeleteItem] = Field(..., description="List of document groups with items to delete")

class BulkDocumentDeleteResponse(BaseModel):
    """Aggregated response for a single bulk delete request across multiple document types."""
    plan_number: str
    total_requested: int
    total_deleted: int
    message: str
    results: list[DocumentTypeDeleteResult] = Field(description="Delete result per document type")
    affected_sections: List[str] = Field(default_factory=list, description="Preliminary research section keys affected")

class DocumentDeleteResponse(BaseModel):
    """Legacy response schema for document deletion results."""
    plan_number: str
    document_type: str
    files_requested: int
    files_deleted: list[str] = Field(description="List of files successfully deleted")
    files_failed: list[str] = Field(description="List of files that failed to delete")
    total_deleted: int
    message: str
    source: str = Field(description="Source: 'gcs'")

class DocumentListAllRequest(BaseModel):
    """Request to list all scoping documents (policy, kod, procedure, gfms, historical_scoping_document, lrr) for a plan."""
    plan_number: str = Field(..., description="Plan number (e.g., '20440')")

class DocumentTypeGroup(BaseModel):
    """Group of documents for a single type."""
    document_type: str
    documents: list[DocumentMetadata]
    total_count: int

class DocumentListAllResponse(BaseModel):
    """Response containing all documents grouped by type for a plan."""
    plan_number: str
    document_groups: list[DocumentTypeGroup] = Field(description="Documents grouped by type (policy, kod, procedure, gfms, historical_scoping_document, lrr)")
    total_count: int = Field(description="Total count across all types")
    message: str
    source: str = Field(description="Source: 'gcs'")

class PolicyManagementRequest(BaseModel):
    """Incoming schema for natural language policy management commands."""
    command: str = Field(..., description="Natural language command like 'exclude policy 1,2,3' or 'keep policy 2,3' or 'remove policy 3,4,5'")

class PolicyManagementResponse(BaseModel):
    """Outgoing schema confirming policy management operation results."""
    message: str
    policies_removed: list[int] = Field(description="List of policy IDs that were removed")
    llm_decision_reasoning: str = Field(description="LLM's reasoning for the policy decision")

class DocumentCandidate(BaseModel):
    """A candidate document or section to verify against active runtime context or RAG catalog."""
    document_type: Optional[str] = Field(None, description="Document type: policy, kod, procedure, gfms, or historical_scoping_document")
    title: Optional[str] = Field(None, description="Exact document title to verify")
    document_id: Optional[Union[int, str]] = Field(None, description="Optional document ID for inclusion/verification")
    file_name: Optional[str] = Field(None, description="Optional file name for document upload/inclusion")
    filename: Optional[str] = Field(None, description="Optional file name in review_data_extraction metadata (e.g., 'kod20.json')")
    storage_uri: Optional[str] = Field(None, description="Optional GCS storage URI from review_data_extraction metadata")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section identifier when targeting a specific section")
    section_title: Optional[str] = Field(None, description="Optional section title when targeting a specific section")
    node_id: Optional[str] = Field(None, description="Optional node_id for parts parsing when targeting a specific section")
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = Field(None, description="Optional inline document or section content")
    reason: Optional[str] = Field(None, description="Optional reason or context for the candidate")

class DocumentVerificationRequest(BaseModel):
    """Request model for verifying candidate documents against the active plan context."""
    plan_number: str = Field(..., description="Target plan number")
    action: str = Field("exclude", description="Action under evaluation, typically exclude or include")
    candidates: List[DocumentCandidate] = Field(default_factory=list, description="Documents to verify against the active context")
    user_text: Optional[str] = Field(None, description="Optional user instruction used for context")
    approved_by: Optional[str] = Field(None, description="User or system who approves the staged workflow")
    approved: bool = Field(False, description="Whether the plan has been approved for execution")

class DocumentVerificationResult(BaseModel):
    """Verification outcome for a candidate document against the active plan context.

    This model is intentionally backward-compatible:
    - strict workflow fields: document_type, title, matched, status, context_file, row_primary_key, reason
    - legacy fields: candidate, approved
    """
    candidate: Optional[DocumentCandidate] = Field(None, description="Legacy candidate document under verification")
    document_type: Optional[str] = Field(None, description="Document type: policy, kod, procedure, gfms, or historical_scoping_document")
    title: Optional[str] = Field(None, description="Exact document title")
    document_id: Optional[str] = Field(None, description="Resolved document ID when available")
    filename: Optional[str] = Field(None, description="Resolved filename in review_data_extraction metadata")
    storage_uri: Optional[str] = Field(None, description="Resolved GCS storage_uri in review_data_extraction metadata")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section ID for section-level context operations")
    section_title: Optional[str] = Field(None, description="Optional section title for section-level context operations")
    node_id: Optional[str] = Field(None, description="Optional node_id for section-level parts parsing")
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = Field(None, description="Optional content payload to include")
    matched: bool = Field(False, description="Whether the document was found/verified")
    status: str = Field("verified", description="Verification status: verified, ready_to_add, not_found, ambiguous, invalid_type")
    context_file: Optional[str] = Field(None, description="Runtime context file owning the verified document")
    row_primary_key: Optional[str] = Field(None, description="Primary key of the row in the active context source")
    reason: Optional[str] = Field(None, description="Verification reasoning")
    approved: bool = Field(False, description="Legacy compatibility flag; may be used by UI/orchestrator control flow")

class DocumentVerificationResponse(BaseModel):
    """Response model for verification of candidate documents against active context."""
    plan_number: str
    action: str
    verified_documents: List[DocumentVerificationResult] = Field(default_factory=list)
    unmatched_documents: List[DocumentVerificationResult] = Field(default_factory=list)
    message: str
    source: str = "runtime-context-verification"

class DocumentExclusionWorkflowRequest(BaseModel):
    """Convenience request model for the staged approval workflow."""
    plan_number: str = Field(..., description="Target plan number")
    action: str = Field("exclude", description="Action under evaluation, typically exclude")
    candidates: List[DocumentCandidate] = Field(default_factory=list, description="Documents to verify against the active context")
    user_text: Optional[str] = Field(None, description="Original natural-language request")
    approved_by: Optional[str] = Field(None, description="User or system approving the final execution")
    approved: bool = Field(False, description="Whether the action plan has been approved")

class DocumentExclusionPlanAction(BaseModel):
    """Single action in the approval plan generated before execution."""
    action: str = Field(..., description="Action to execute, e.g. exclude")
    document_type: str = Field(..., description="Document type: policy, kod, procedure, gfms, or historical_scoping_document")
    title: str = Field(..., description="Exact document title")
    document_id: Optional[str] = Field(None, description="Optional document ID")
    filename: Optional[str] = Field(None, description="Optional filename in review_data_extraction metadata")
    storage_uri: Optional[str] = Field(None, description="Optional storage_uri in review_data_extraction metadata")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section ID when excluding a specific section")
    section_title: Optional[str] = Field(None, description="Optional section title when excluding a specific section")
    node_id: Optional[str] = Field(None, description="Optional node_id for parts parsing")
    context_file: Optional[str] = Field(None, description="Runtime context file owning the document")
    row_primary_key: Optional[str] = Field(None, description="PK of the row that owns the document context JSON")
    scope: str = Field("all_related", description="Execution scope")

class DocumentExclusionPlanRequest(BaseModel):
    """Request model for producing an action plan from user intent plus verification result."""
    plan_number: str = Field(..., description="Target plan number")
    user_text: str = Field(..., description="Original natural-language request")
    action: str = Field("exclude", description="Action being planned")
    verified_documents: List[DocumentVerificationResult] = Field(default_factory=list, description="Verified candidate set")

class DocumentExclusionPlanResponse(BaseModel):
    """Structured execution plan shown to the user for approval."""
    plan_number: str
    action: str
    actions: List[DocumentExclusionPlanAction] = Field(default_factory=list)
    message: str
    requires_approval: bool = True

class DocumentExecutionAction(BaseModel):
    """Single execution item for the final approved action JSON."""
    action: str = Field(..., description="Action to execute, e.g. exclude")
    document_type: str = Field(..., description="Document type: policy, kod, procedure, gfms, or historical_scoping_document")
    title: str = Field(..., description="Exact document title")
    document_id: Optional[str] = Field(None, description="Optional document ID")
    filename: Optional[str] = Field(None, description="Optional filename in review_data_extraction metadata")
    storage_uri: Optional[str] = Field(None, description="Optional storage_uri in review_data_extraction metadata")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section ID when excluding a specific section")
    section_title: Optional[str] = Field(None, description="Optional section title when excluding a specific section")
    node_id: Optional[str] = Field(None, description="Optional node_id for parts parsing")
    context_file: Optional[str] = Field(None, description="Runtime context file that owns the document")
    row_primary_key: Optional[str] = Field(None, description="PK of the owning row for the document context JSON")
    scope: str = Field("all_related", description="Execution scope")

class DocumentExecutionRequest(BaseModel):
    """Final approved execution payload that contains row PK references meant for backend mutation."""
    plan_number: str = Field(..., description="Target plan number")
    actions: List[DocumentExecutionAction] = Field(default_factory=list, description="Approved actions to execute")
    approved_by: Optional[str] = Field(None, description="User or system that approved the plan")

class DocumentExecutionResponse(BaseModel):
    """Response from the execution API after applying the approved plan."""
    plan_number: str
    status: str = Field(description="success, partial_failure, error")
    message: str
    executed: List[DocumentExecutionAction] = Field(default_factory=list)
    registry_updated: bool = False
    audit: Dict[str, Any] = Field(default_factory=dict)
    source: str = "approved-execution"
    affected_sections: List[str] = Field(default_factory=list, description="Preliminary research section keys affected")

class DocumentImpactAnalysis(BaseModel):
    """LLM-generated impact analysis for a document exclusion request."""
    affected_artifacts: List[str] = Field(default_factory=list, description="Artifacts affected by the document removal")
    downstream_jobs: List[str] = Field(default_factory=list, description="Follow-on jobs or tasks impacted by the change")
    reasoning: str = Field(default="", description="LLM reasoning about why the downstream impact exists")
    confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Confidence score for the analysis")


class DocumentIntentAnalysis(BaseModel):
    """Structured natural-language intent analysis returned by the LLM orchestrator."""
    action: str = Field(default="exclude", description="Action inferred from the user request")
    document_type: Optional[str] = Field(None, description="Inferred document type: policy, kod, or procedure")
    title: Optional[str] = Field(None, description="Inferred runtime document title")
    plan_number: Optional[str] = Field(None, description="Plan number inferred from the request")
    scope: str = Field("all_related", description="Scope for the downstream mutation")
    reasoning: str = Field(default="", description="LLM reasoning for the inferred action")
    impact_analysis: DocumentImpactAnalysis = Field(default_factory=DocumentImpactAnalysis, description="Impact analysis for downstream artifacts and execution")
    requires_approval: bool = Field(True, description="Whether the intended action requires an approval gate before execution")


# ====================================================================
# Sister Schemas for Document Upload, RAG Inclusion & Chat Context Add
# ====================================================================

class DocumentUploadItemDetail(BaseModel):
    """Upload item with document and/or section details to add to plan context."""
    file_name: Optional[str] = Field(None, description="File name to write (e.g., 'policy_10.json')")
    document_title: str = Field(..., description="Display title of the document")
    document_id: Optional[str] = Field(None, description="Unique ID of the document")
    section_id: Optional[str] = Field(None, description="Optional section identifier")
    section_title: Optional[str] = Field(None, description="Optional section title")
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = Field(None, description="Inline document or section content")
    paragraphs: Optional[List[Any]] = Field(None, description="Structured paragraphs/chunks for the document")


class DocumentUploadItem(BaseModel):
    """Single document-type upload group with item details."""
    document_type: str = Field(..., description="Document type (e.g., 'policy', 'kod', 'procedure')")
    items: list[DocumentUploadItemDetail] = Field(..., description="List of documents/sections to upload for this type")


class DocumentUploadRequest(BaseModel):
    """Single-type document upload request schema."""
    plan_number: str = Field(..., description="Plan number (e.g., '20440')")
    document_type: str = Field(..., description="Document type (e.g., 'policy', 'kod', 'procedure')")
    items: list[DocumentUploadItemDetail] = Field(..., description="Document items to upload")


class DocumentTypeUploadResult(BaseModel):
    """Upload result for one document type in a bulk upload request."""
    document_type: str
    files_requested: int
    files_uploaded: list[str] = Field(default_factory=list, description="List of files successfully uploaded")
    files_failed: list[str] = Field(default_factory=list, description="List of files that failed to upload")
    total_uploaded: int
    message: str
    source: str = Field(default="gcs", description="Source: 'gcs'")


class BulkDocumentUploadRequest(BaseModel):
    """Bulk multi-document upload request across policy, kod, and procedure (sister to BulkDocumentDeleteRequest)."""
    plan_number: str = Field(..., description="Plan number (e.g., '20440')")
    documents: list[DocumentUploadItem] = Field(..., description="List of document groups with items to upload/add")


class BulkDocumentUploadResponse(BaseModel):
    """Aggregated response for a bulk document upload request across multiple document types."""
    plan_number: str
    total_requested: int
    total_uploaded: int
    message: str
    results: list[DocumentTypeUploadResult] = Field(default_factory=list, description="Upload result per document type")


class DocumentUploadResponse(BaseModel):
    """Single-type response schema for document upload results."""
    plan_number: str
    document_type: str
    files_requested: int
    files_uploaded: list[str] = Field(default_factory=list, description="List of files successfully uploaded")
    files_failed: list[str] = Field(default_factory=list, description="List of files that failed to upload")
    total_uploaded: int
    message: str
    source: str = Field(default="gcs", description="Source: 'gcs'")


class RagDocumentIngestResponse(BaseModel):
    """Response schema for RAG multipart document ingestion (/documents/ingest)."""
    status: str = Field(default="accepted", description="Ingestion status: accepted, completed, error")
    job_id: Optional[str] = Field(None, description="Job identifier returned by dbaware-rag-service")
    document_ids: List[int] = Field(default_factory=list, description="Ingested document IDs when available immediately")
    plan_number: Optional[str] = Field(None, description="Optional target plan number associated with ingestion")
    message: str = Field(default="", description="Status message")
    details: Dict[str, Any] = Field(default_factory=dict, description="Raw payload returned by RAG service")


class RagJobStatusResponse(BaseModel):
    """Response schema for RAG ingestion job status (/documents/ingest-jobs/{job_id})."""
    job_id: str = Field(..., description="RAG ingestion job ID")
    status: str = Field(default="unknown", description="Job status from RAG service")
    document_ids: List[int] = Field(default_factory=list, description="Document IDs produced by the ingestion job")
    message: Optional[str] = Field(None, description="Optional status message")
    details: Dict[str, Any] = Field(default_factory=dict, description="Full job status payload from RAG service")


class CategorizeDocumentsRequest(BaseModel):
    """Request schema for categorizing document IDs via RAG (/documents/categorize)."""
    plan_number: Optional[str] = Field(None, description="Optional plan number")
    document_ids: List[int] = Field(..., description="List of document IDs to categorize")


class CategorizeDocumentsResponse(BaseModel):
    """Response schema for categorizing document IDs via RAG."""
    status: str = Field(default="success")
    document_ids: List[int] = Field(default_factory=list)
    categorized_documents: Dict[str, Any] = Field(default_factory=dict, description="Categorization result from RAG service")
    message: str = Field(default="")


class RelevantDocumentSpec(BaseModel):
    """Document specification entry for get-relevant-data-for-documents."""
    document_type: str = Field(..., description="Document type: policy, kod, or procedure")
    document_ids: List[int] = Field(..., description="Document IDs for this document type")
    top_k: int = Field(5, description="Number of top relevant sections/chunks to retrieve")


class RelevantDataForDocumentsRequest(BaseModel):
    """Request schema for retrieving relevant data for documents from RAG and optionally persisting to plan context."""
    plan_number: Optional[str] = Field(None, description="Plan number (e.g., '20440')")
    review_id: Optional[Union[str, int]] = Field(None, description="Review ID (defaults to str(plan_number))")
    region: Optional[Union[str, List[str]]] = Field(None, description="Applicable regions")
    au_countries: Optional[List[str]] = Field(None, description="Assessable unit countries")
    plan_item_title: Optional[str] = Field(None, description="Plan item title")
    plan_item_description: Optional[str] = Field(None, description="Plan item description")
    au_list: Optional[List[str]] = Field(None, description="Assessable unit list")
    rt_list: Optional[List[str]] = Field(None, description="Risk themes list")
    kc_list: Optional[List[str]] = Field(None, description="Key controls list")
    control_name: Optional[List[str]] = Field(None, description="Control names")
    control_how: Optional[List[str]] = Field(None, description="Control how descriptions")
    control_what: Optional[List[str]] = Field(None, description="Control what descriptions")
    control_why: Optional[List[str]] = Field(None, description="Control why descriptions")
    documents: List[RelevantDocumentSpec] = Field(..., description="Document groups to retrieve relevant data for")
    persist_to_context: bool = Field(True, description="Whether to persist retrieved document data into the plan's GCS context and session")


class RelevantDataForDocumentsResponse(BaseModel):
    """Response schema after retrieving relevant data for documents from RAG."""
    plan_number: Optional[str] = None
    review_id: Optional[Union[str, int]] = None
    status: str = Field(default="success")
    results: Any = Field(default_factory=list, description="Relevant document sections returned by RAG service")
    persisted_files: List[str] = Field(default_factory=list, description="GCS blob paths persisted for the plan")
    registry_updated: bool = False
    message: str = Field(default="")


class ChatContextSectionItem(BaseModel):
    """A section or document snippet added to context via the chat window."""
    section_title: str = Field(..., description="Title of the section or context block")
    content: Union[str, Dict[str, Any], List[Any]] = Field(..., description="Text or structured content to add")
    document_type: Optional[str] = Field("policy", description="Optional document category: policy, kod, or procedure")
    document_title: Optional[str] = Field(None, description="Optional parent document title")
    document_id: Optional[str] = Field(None, description="Optional document ID")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section ID")


class ChatAddContextRequest(BaseModel):
    """Request schema to add documents, sections, or free-form context through the chat window."""
    plan_number: Optional[str] = Field(None, alias="planNumber", description="Active plan number")
    session_id: Optional[str] = Field(None, alias="sessionId", description="Active session ID (defaults to plan_number)")
    context_type: str = Field("Preliminary Research Walkthrough", alias="contextType", description="Active walkthrough stage")
    user_text: Optional[str] = Field(None, alias="userText", description="Natural-language instruction or raw context text from chat")
    sections: List[ChatContextSectionItem] = Field(default_factory=list, description="Structured sections to add to context")
    documents: List[DocumentUploadItem] = Field(default_factory=list, description="Structured document groups to upload and add to context")
    document_ids: List[int] = Field(default_factory=list, alias="documentIds", description="RAG document IDs to categorize, fetch relevant data for, and include")
    persist_to_gcs: bool = Field(True, alias="persistToGcs", description="Whether to persist added documents/sections into GCS registry")

    model_config = ConfigDict(populate_by_name=True, extra="allow")


class ChatAddContextResponse(BaseModel):
    """Response schema confirming documents/sections were added to chat session and plan context."""
    session_id: str
    plan_number: Optional[str] = None
    context_type: str
    status: str = Field(default="success")
    sections_added: int = 0
    documents_added: int = 0
    persisted_files: List[str] = Field(default_factory=list)
    registry_updated: bool = False
    message: str


class DocumentInclusionWorkflowRequest(BaseModel):
    """Convenience request model for the staged document/section inclusion workflow (sister to DocumentExclusionWorkflowRequest)."""
    plan_number: str = Field(..., description="Target plan number")
    action: str = Field("include", description="Action under evaluation, typically include or add")
    candidates: List[DocumentCandidate] = Field(default_factory=list, description="Documents or sections to verify and include in the active context")
    document_ids: List[int] = Field(default_factory=list, description="Optional RAG document IDs to categorize and include")
    user_text: Optional[str] = Field(None, description="Original natural-language request")
    approved_by: Optional[str] = Field(None, description="User or system approving the final execution")
    approved: bool = Field(False, description="Whether the action plan has been approved")


class DocumentInclusionPlanAction(BaseModel):
    """Single action in the approval plan generated before executing document/section inclusion."""
    action: str = Field(default="include", description="Action to execute, e.g. include or add")
    document_type: str = Field(..., description="Document type: policy, kod, procedure, gfms, or historical_scoping_document")
    title: str = Field(..., description="Exact document title")
    document_id: Optional[str] = Field(None, description="Document ID if known")
    filename: Optional[str] = Field(None, description="Optional filename in review_data_extraction metadata")
    storage_uri: Optional[str] = Field(None, description="Optional storage_uri in review_data_extraction metadata")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section ID")
    section_title: Optional[str] = Field(None, description="Optional section title")
    node_id: Optional[str] = Field(None, description="Optional node_id for parts parsing")
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = Field(None, description="Optional inline content to include")
    context_file: Optional[str] = Field(None, description="Runtime context file that will store the document")
    row_primary_key: Optional[str] = Field(None, description="PK of the row that owns the document context JSON")
    scope: str = Field("all_related", description="Execution scope")


class DocumentInclusionPlanRequest(BaseModel):
    """Request model for producing an inclusion action plan from user intent plus verification result."""
    plan_number: str = Field(..., description="Target plan number")
    user_text: str = Field(..., description="Original natural-language request")
    action: str = Field("include", description="Action being planned")
    verified_documents: List[DocumentVerificationResult] = Field(default_factory=list, description="Verified candidate set")


class DocumentInclusionPlanResponse(BaseModel):
    """Structured inclusion execution plan shown to the user for approval."""
    plan_number: str
    action: str
    actions: List[DocumentInclusionPlanAction] = Field(default_factory=list)
    message: str
    requires_approval: bool = True


class DocumentInclusionExecutionAction(BaseModel):
    """Single execution item for the final approved inclusion action JSON."""
    action: str = Field(default="include", description="Action to execute, e.g. include or add")
    document_type: str = Field(..., description="Document type: policy, kod, procedure, gfms, or historical_scoping_document")
    title: str = Field(..., description="Exact document title")
    document_id: Optional[str] = Field(None, description="Optional document ID for RAG retrieval or registry")
    filename: Optional[str] = Field(None, description="Optional filename in review_data_extraction metadata")
    storage_uri: Optional[str] = Field(None, description="Optional storage_uri in review_data_extraction metadata")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section ID")
    section_title: Optional[str] = Field(None, description="Optional section title")
    node_id: Optional[str] = Field(None, description="Optional node_id for parts parsing")
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = Field(None, description="Optional inline content to include")
    context_file: Optional[str] = Field(None, description="Runtime context file that owns the document")
    row_primary_key: Optional[str] = Field(None, description="PK of the owning row for the document context JSON")
    scope: str = Field("all_related", description="Execution scope")


class DocumentInclusionExecutionRequest(BaseModel):
    """Final approved inclusion execution payload that mutates backend context."""
    plan_number: str = Field(..., description="Target plan number")
    actions: List[DocumentInclusionExecutionAction] = Field(default_factory=list, description="Approved inclusion actions to execute")
    approved_by: Optional[str] = Field(None, description="User or system that approved the plan")


class DocumentInclusionExecutionResponse(BaseModel):
    """Response from the inclusion execution API after applying the approved plan."""
    plan_number: str
    status: str = Field(description="success, partial_failure, error")
    message: str
    executed: List[DocumentInclusionExecutionAction] = Field(default_factory=list)
    registry_updated: bool = False
    audit: Dict[str, Any] = Field(default_factory=dict)
    source: str = "approved-inclusion-execution"
    affected_sections: List[str] = Field(default_factory=list, description="Preliminary research section keys affected")



# ====================================================================
# Chat-driven Document Action Workflow (add / remove with approval)
#
#   1. user text -> LLM -> candidate actions               (/documents/actions/extract)
#   2. candidates -> verify against context JSONs + PKs    (/documents/actions/verify)
#   3. user text + actions + verification -> LLM -> plan   (/documents/actions/plan)
#   4. plan shown to user, awaiting approval               (pending plan store)
#   5. approval -> LLM -> execution JSON                   (/documents/actions/decision)
#   6. execution JSON -> backend mutation API              (/documents/actions/execute)
# ====================================================================

class DocumentActionItem(BaseModel):
    """A single candidate add/remove action extracted from the user's message."""
    action: str = Field(..., description="'exclude' (remove) or 'include' (add)")
    document_type: Optional[str] = Field(None, description="policy, kod, procedure, gfms, or historical_scoping_document")
    title: Optional[str] = Field(None, description="Document title as referenced by the user")
    document_id: Optional[str] = Field(None, description="Optional document ID referenced by the user")
    filename: Optional[str] = Field(None, description="Optional filename in review_data_extraction metadata")
    storage_uri: Optional[str] = Field(None, description="Optional storage_uri in review_data_extraction metadata")
    section_id: Optional[Union[int, str]] = Field(None, description="Optional section ID (section-level include/exclude)")
    section_title: Optional[str] = Field(None, description="Optional section title (section-level include/exclude)")
    node_id: Optional[str] = Field(None, description="Optional node_id for parts parsing")
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = Field(None, description="Optional inline content to add")
    reason: Optional[str] = Field(None, description="Why the user wants this change, if stated")


class DocumentActionExtractionRequest(BaseModel):
    """Stage 1 input: raw user text."""
    plan_number: str = Field(..., description="Target plan number")
    user_text: str = Field(..., description="Natural-language request from the chat window")


class DocumentActionExtractionResponse(BaseModel):
    """Stage 1 output: actions to take plus the list of documents whose existence must be verified."""
    plan_number: str
    is_document_request: bool = False
    actions: List[DocumentActionItem] = Field(default_factory=list)
    reasoning: str = ""
    source: str = Field("llm", description="'llm' or 'heuristic' (deterministic fallback)")


class DocumentActionVerificationRequest(BaseModel):
    """Stage 2 input: candidate actions to verify against the plan's context JSON files."""
    plan_number: str = Field(..., description="Target plan number")
    actions: List[DocumentActionItem] = Field(default_factory=list)


class VerifiedDocumentAction(BaseModel):
    """Stage 2 result row: a candidate resolved against a context JSON, with the owning row PK."""
    action: str
    document_type: Optional[str] = None
    title: Optional[str] = None
    requested_title: Optional[str] = Field(None, description="Title as the user wrote it")
    document_id: Optional[str] = None
    filename: Optional[str] = None
    storage_uri: Optional[str] = None
    section_id: Optional[Union[int, str]] = None
    section_title: Optional[str] = None
    node_id: Optional[str] = None
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = None
    matched: bool = False
    status: str = Field("verified", description="verified, ready_to_add, already_excluded, already_active, not_found, invalid_type")
    context_file: Optional[str] = Field(None, description="Context JSON that contains (or will contain) the document")
    row_primary_key: Optional[str] = Field(None, description="Primary key of the row in the context JSON / table")
    review_scope_dataext_id: Optional[str] = Field(None, description="PK of the row in dbaware_scoping.review_data_extraction")
    review_document_instance_id: Optional[str] = Field(None, description="PK of the row in dbaware_scoping.dbaware_review_documents")
    review_scope_instance_id: Optional[str] = Field(None, description="PK/FK in dbaware_scoping.review_scope")
    table_name: Optional[str] = Field(None, description="Liquibase table that owns the context JSON metadata")
    reason: Optional[str] = None


class DocumentActionVerificationResponse(BaseModel):
    """Stage 2 output: verified files with row primary keys, plus anything that could not be verified."""
    plan_number: str
    verified: List[VerifiedDocumentAction] = Field(default_factory=list)
    unmatched: List[VerifiedDocumentAction] = Field(default_factory=list)
    message: str = ""


class DocumentActionPlanStep(BaseModel):
    """One step of the approval plan shown to the user."""
    step: int
    action: str
    document_type: str
    title: str
    document_id: Optional[str] = None
    filename: Optional[str] = None
    storage_uri: Optional[str] = None
    section_id: Optional[Union[int, str]] = None
    section_title: Optional[str] = None
    node_id: Optional[str] = None
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = None
    context_file: Optional[str] = None
    row_primary_key: Optional[str] = None
    review_scope_dataext_id: Optional[str] = None
    review_document_instance_id: Optional[str] = None
    review_scope_instance_id: Optional[str] = None
    table_name: Optional[str] = None
    rationale: str = ""


class DocumentActionPlanRequest(BaseModel):
    """Stage 3 input. If extracted_actions / verification are omitted, stages 1-2 are run first."""
    plan_number: str = Field(..., description="Target plan number")
    user_text: str = Field(..., description="Original natural-language request")
    context_type: str = Field("Preliminary Research Walkthrough", description="Active chat stage")
    extracted_actions: Optional[List[DocumentActionItem]] = None
    verification: Optional[DocumentActionVerificationResponse] = None


class DocumentActionPlanResponse(BaseModel):
    """Stage 3/4 output: plan awaiting user approval."""
    plan_id: Optional[str] = None
    plan_number: str
    status: str = Field("pending_approval", description="pending_approval, no_verified_actions, not_document_request")
    summary: str = ""
    steps: List[DocumentActionPlanStep] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    extracted_actions: List[DocumentActionItem] = Field(default_factory=list)
    verification: Optional[DocumentActionVerificationResponse] = None
    requires_approval: bool = True
    message: str = Field("", description="Markdown rendering of the plan for the chat window")
    source: str = Field("llm", description="'llm' or 'deterministic' plan generation")


class DocumentActionExecutionItem(BaseModel):
    """Stage 5 output row: action, document title, and PKs of the rows pointing at the JSONs to edit."""
    action: str = Field(..., description="'exclude' or 'include'")
    document_type: str
    title: str
    row_primary_keys: List[str] = Field(default_factory=list)
    context_file: Optional[str] = None
    document_id: Optional[str] = None
    filename: Optional[str] = None
    storage_uri: Optional[str] = None
    review_scope_dataext_id: Optional[str] = None
    review_document_instance_id: Optional[str] = None
    review_scope_instance_id: Optional[str] = None
    table_name: Optional[str] = None
    section_id: Optional[Union[int, str]] = None
    section_title: Optional[str] = None
    node_id: Optional[str] = None
    content: Optional[Union[str, Dict[str, Any], List[Any]]] = None


class DocumentActionExecutionRequest(BaseModel):
    """Stage 6 input: the final execution JSON."""
    plan_number: str = Field(..., description="Target plan number")
    actions: List[DocumentActionExecutionItem] = Field(default_factory=list)
    approved_by: Optional[str] = None
    plan_id: Optional[str] = None


class DocumentActionExecutionResponse(BaseModel):
    """Stage 6 output."""
    plan_number: str
    status: str = Field(description="success, partial_failure, error")
    message: str
    executed: List[DocumentActionExecutionItem] = Field(default_factory=list)
    failed: List[Dict[str, Any]] = Field(default_factory=list)
    registry_updated: bool = False
    audit: Dict[str, Any] = Field(default_factory=dict)
    affected_sections: List[str] = Field(default_factory=list, description="Preliminary research section keys affected")


class DocumentActionDecisionRequest(BaseModel):
    """Stage 4->5 input: the user's approve/reject decision on a pending plan."""
    plan_number: str = Field(..., description="Target plan number")
    plan_id: Optional[str] = Field(None, description="Pending plan ID; defaults to the latest pending plan for the plan number")
    decision: str = Field(..., description="'approve' or 'reject'")
    approved_by: Optional[str] = None


class DocumentActionDecisionResponse(BaseModel):
    """Outcome of an approve/reject decision."""
    plan_id: Optional[str] = None
    plan_number: str
    status: str = Field(description="executed, partial_failure, rejected, not_found, error")
    message: str
    execution_json: Optional[DocumentActionExecutionRequest] = None
    execution: Optional[DocumentActionExecutionResponse] = None
    affected_sections: List[str] = Field(default_factory=list, description="Preliminary research section keys affected")
