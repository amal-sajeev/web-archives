import inspect
import json
import logging
from typing import List, Dict, Any, Optional

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from google.api_core.exceptions import NotFound

from service import document_service_helpers as doc_helpers

try:
    from service.database_connector import (
        DatabaseConnector,
        compute_affected_preliminary_research_sections,
        normalize_scoping_source,
        source_to_db_data_source,
    )
except Exception:  # pragma: no cover
    DatabaseConnector = None  # type: ignore[assignment]
    compute_affected_preliminary_research_sections = lambda sources: []  # type: ignore[assignment]
    normalize_scoping_source = lambda v: (v or "").strip().lower() or None  # type: ignore[assignment]
    source_to_db_data_source = lambda v: (v or "").strip().lower()  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# Public re-export aliases for compatibility with existing imports.
AmbiguousDeleteRequestError = doc_helpers.AmbiguousDeleteRequestError
DocumentManagementError = doc_helpers.DocumentManagementError
DocumentNotFoundError = doc_helpers.DocumentNotFoundError
InvalidDocumentTypeError = doc_helpers.InvalidDocumentTypeError
MultipleDocumentMatchesError = doc_helpers.MultipleDocumentMatchesError
PartialDeleteFailureError = doc_helpers.PartialDeleteFailureError
VALID_DOCUMENT_TYPES = doc_helpers.VALID_DOCUMENT_TYPES
REGISTRY_FILES = doc_helpers.REGISTRY_FILES


def _normalize_document_type(document_type: Optional[str]) -> str:
    return doc_helpers._normalize_document_type(document_type)


def _normalize_text_for_match(value: Optional[str]) -> str:
    return doc_helpers._normalize_text_for_match(value)


def _title_similarity_score(query: str, candidate: str) -> float:
    return doc_helpers._title_similarity_score(query, candidate)


def _normalize_title(title: Optional[str]) -> str:
    return doc_helpers._normalize_title(title)


def _registry_blob_path(plan_number: str, document_type: str) -> str:
    return doc_helpers._registry_blob_path(plan_number, document_type)


async def _read_json_blob(gcs_utils: GCSUtils, blob_path: str) -> Any:
    return await doc_helpers._read_json_blob(gcs_utils, blob_path)


def _extract_title_from_command(command: str, document_type: Optional[str] = None) -> str:
    return doc_helpers._extract_title_from_command(command, document_type)


async def parse_document_removal_intent(
    user_command: str,
    plan_number: Optional[str] = None,
    document_type: Optional[str] = None,
    title: Optional[str] = None,
    env_config: Optional[EnvironmentConfig] = None,
) -> Dict[str, Any]:
    return await doc_helpers.parse_document_removal_intent(
        user_command=user_command,
        plan_number=plan_number,
        document_type=document_type,
        title=title,
        env_config=env_config,
    )


def _validate_removal_intent_payload(intent_payload: Dict[str, Any]) -> Dict[str, Any]:
    return doc_helpers._validate_removal_intent_payload(intent_payload)


async def manage_document_removal(
    plan_number: str,
    document_type: str,
    title: str,
    env_config: EnvironmentConfig,
    scope: str = "all_related",
) -> Dict[str, Any]:
    return await doc_helpers.manage_document_removal(plan_number, document_type, title, env_config, scope)


async def _mark_registry_document_removed(plan_number: str, document_type: str, target_title: str, gcs_utils: GCSUtils) -> Dict[str, Any]:
    return await doc_helpers._mark_registry_document_removed(plan_number, document_type, target_title, gcs_utils)


def _extract_inclusion_title_from_command(command: str, document_type: Optional[str] = None) -> str:
    return doc_helpers._extract_inclusion_title_from_command(command, document_type)


async def parse_document_inclusion_intent(
    user_command: str,
    plan_number: Optional[str] = None,
    document_type: Optional[str] = None,
    title: Optional[str] = None,
    content: Optional[Any] = None,
    section_title: Optional[str] = None,
    document_id: Optional[Any] = None,
    env_config: Optional[EnvironmentConfig] = None,
) -> Dict[str, Any]:
    return await doc_helpers.parse_document_inclusion_intent(
        user_command=user_command,
        plan_number=plan_number,
        document_type=document_type,
        title=title,
        content=content,
        section_title=section_title,
        document_id=document_id,
        env_config=env_config,
    )


def _validate_inclusion_intent_payload(intent_payload: Dict[str, Any]) -> Dict[str, Any]:
    return doc_helpers._validate_inclusion_intent_payload(intent_payload)


async def manage_document_inclusion(
    plan_number: str,
    document_type: str,
    title: str,
    env_config: EnvironmentConfig,
    content: Optional[Any] = None,
    document_id: Optional[Any] = None,
    section_title: Optional[str] = None,
    scope: str = "all_related",
) -> Dict[str, Any]:
    return await doc_helpers.manage_document_inclusion(
        plan_number=plan_number,
        document_type=document_type,
        title=title,
        env_config=env_config,
        content=content,
        document_id=document_id,
        section_title=section_title,
        scope=scope,
    )


async def _mark_registry_document_included(
    plan_number: str,
    document_type: str,
    target_title: str,
    gcs_utils: GCSUtils,
    document_entry: Optional[Dict[str, Any]] = None,
    blob_path: Optional[str] = None,
) -> Dict[str, Any]:
    return await doc_helpers._mark_registry_document_included(
        plan_number=plan_number,
        document_type=document_type,
        target_title=target_title,
        gcs_utils=gcs_utils,
        document_entry=document_entry,
        blob_path=blob_path,
    )


_EXCLUDED_STATUSES = {"removed", "excluded", "deleted", "inactive"}
ALL_SCOPING_DOCUMENT_TYPES = ["policy", "kod", "procedure", "gfms", "historical_scoping_document", "lrr"]


def _source_folder_prefix(plan_number: str, canonical_type: str) -> str:
    if canonical_type in ("policy", "kod", "procedure"):
        return f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{canonical_type}/"
    if canonical_type == "gfms":
        return f"dbaware_review_{plan_number}/inbound-data/gfms/"
    if canonical_type == "historical_scoping_document":
        return f"dbaware_review_{plan_number}/inbound-data/dbaware/"
    if canonical_type == "lrr":
        return f"dbaware_review_{plan_number}/inbound-data/lrr/"
    return f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{canonical_type}/"


def _is_allowed_gcs_fallback_blob(canonical_type: str, filename: str) -> bool:
    clean = (filename or "").strip()
    if not clean or clean.endswith("/"):
        return False
    low = clean.lower()
    if canonical_type == "gfms":
        return low == "findings_details.json"
    if canonical_type == "historical_scoping_document":
        return low == "historical_plan_details.json" or low.endswith(".pdf")
    if canonical_type == "lrr":
        return low in {"internet_search_data_enriched.json", "internet_search_data.json"}
    return True


def _normalize_sections_list(raw_sections: Any, default_prefix: str) -> List[Dict[str, Any]]:
    if not isinstance(raw_sections, list):
        return []
    normalized: List[Dict[str, Any]] = []
    for idx, sec in enumerate(raw_sections, start=1):
        if not isinstance(sec, dict):
            continue
        sid = sec.get("section_id")
        if sid in (None, ""):
            sid = sec.get("source_index")
        sid_val: Any = sid if sid not in (None, "") else idx
        excluded = bool(sec.get("excluded", False)) or (
            str(sec.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
        )
        page_label = f"Page {sec['page_number']}" if sec.get("page_number") is not None else None
        normalized.append(
            {
                "section_id": sid_val,
                "section_title": str(
                    sec.get("section_title")
                    or sec.get("title")
                    or sec.get("section_path")
                    or page_label
                    or f"Section {sid_val}"
                ).strip(),
                "node_id": str(sec.get("node_id") or f"{default_prefix}:section:{sid_val}"),
                "status": "excluded" if excluded else str(sec.get("status") or "active"),
                "excluded": excluded,
            }
        )
    return normalized


def _extract_sections_from_json_payload(canonical_type: str, payload: Any, doc_id: str) -> List[Dict[str, Any]]:
    if isinstance(payload, dict):
        if isinstance(payload.get("sections"), list):
            return _normalize_sections_list(payload["sections"], doc_id)
        if isinstance(payload.get("nodes"), list):
            return _normalize_sections_list(payload["nodes"], doc_id)
        if isinstance(payload.get("sources"), list):
            return _normalize_sections_list(payload["sources"], doc_id)
        return []
    if isinstance(payload, list):
        if canonical_type == "gfms":
            sections: List[Dict[str, Any]] = []
            for w in payload:
                if not isinstance(w, dict):
                    continue
                for idx, f in enumerate(w.get("responsePayload") or [w], start=1):
                    if not isinstance(f, dict):
                        continue
                    fid = str(f.get("findingId") or f.get("id") or idx)
                    excluded = bool(f.get("excluded", False)) or (
                        str(f.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
                    )
                    sections.append(
                        {
                            "section_id": fid,
                            "section_title": str(f.get("findingTitle") or f.get("title") or f"Finding {fid}"),
                            "node_id": str(f.get("node_id") or f"gfms:finding:{fid}"),
                            "status": "excluded" if excluded else "active",
                            "excluded": excluded,
                        }
                    )
            return sections
        if canonical_type == "historical_scoping_document":
            sections = []
            for idx, item in enumerate(payload, start=1):
                if not isinstance(item, dict):
                    continue
                pnum = str(item.get("Plan Item Number") or item.get("plan_item_number") or idx)
                excluded = bool(item.get("excluded", False)) or (
                    str(item.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
                )
                sections.append(
                    {
                        "section_id": pnum,
                        "section_title": str(item.get("Plan Item Title") or item.get("title") or f"Historical Plan {pnum}"),
                        "node_id": str(item.get("node_id") or f"historical_plan:{pnum}"),
                        "status": "excluded" if excluded else "active",
                        "excluded": excluded,
                    }
                )
            return sections
        if canonical_type == "lrr":
            sections = []
            m_idx = 0
            for idx, item in enumerate(payload, start=1):
                if not isinstance(item, dict):
                    continue
                if isinstance(item.get("Mandates"), list):
                    risk_name = str(item.get("Risk Name") or item.get("risk_name") or "").strip()
                    for mandate in item["Mandates"]:
                        if not isinstance(mandate, dict):
                            continue
                        m_idx += 1
                        mtitle = str(
                            mandate.get("Regulatory Mandate")
                            or mandate.get("mandate")
                            or mandate.get("Citation")
                            or f"{risk_name} - Mandate {m_idx}"
                        ).strip()
                        excluded = bool(mandate.get("excluded", False)) or (
                            str(mandate.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
                        )
                        sections.append(
                            {
                                "section_id": m_idx,
                                "section_title": mtitle,
                                "node_id": str(mandate.get("node_id") or f"lrr:mandate:{m_idx}"),
                                "status": "excluded" if excluded else "active",
                                "excluded": excluded,
                            }
                        )
                else:
                    m_idx += 1
                    mtitle = str(
                        item.get("Regulatory Mandate")
                        or item.get("title")
                        or item.get("plan_item_title")
                        or f"LRR Entry {m_idx}"
                    ).strip()
                    excluded = bool(item.get("excluded", False)) or (
                        str(item.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
                    )
                    sections.append(
                        {
                            "section_id": m_idx,
                            "section_title": mtitle,
                            "node_id": str(item.get("node_id") or f"lrr:mandate:{m_idx}"),
                            "status": "excluded" if excluded else "active",
                            "excluded": excluded,
                        }
                    )
            return sections
    return []


def _read_db_documents_for_type(
    plan_number: str,
    canonical_type: str,
    env_config: EnvironmentConfig,
    bucket_name: str,
) -> List[Dict[str, Any]]:
    """Read document and section metadata from dbaware_scoping.review_data_extraction."""
    if DatabaseConnector is None:
        return []
    try:
        db_conn = DatabaseConnector(env_config)
        db_ds = source_to_db_data_source(canonical_type)
        rows = db_conn.get_data_extraction_rows_for_plan(plan_number, data_sources=[db_ds])
        meta = (rows.get(db_ds) or {}).get("metadata")
    except Exception as exc:
        logger.debug("Skipping DB metadata lookup during listing (%s): %s", canonical_type, exc)
        return []

    raw_docs = meta.get("documents") if isinstance(meta, dict) else meta if isinstance(meta, list) else []
    if not isinstance(raw_docs, list):
        return []

    prefix = _source_folder_prefix(plan_number, canonical_type)
    docs: List[Dict[str, Any]] = []
    for idx, d in enumerate(raw_docs, start=1):
        if not isinstance(d, dict):
            continue
        fname = str(d.get("filename") or d.get("file_name") or "").strip()
        storage_uri = str(d.get("storage_uri") or d.get("uri") or "").strip()
        if not fname and storage_uri:
            fname = storage_uri.rsplit("/", 1)[-1]
        if not fname:
            fname = doc_helpers.REGISTRY_FILES.get(canonical_type, f"{canonical_type}_{idx}.json")
        if not storage_uri:
            storage_uri = f"gs://{bucket_name}/{prefix}{fname}"
        doc_id = str(d.get("document_id") or d.get("id") or fname)
        doc_title = str(d.get("document_title") or d.get("title") or d.get("document_name") or fname).strip()
        excluded = bool(d.get("excluded", False)) or (
            str(d.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
        )
        sections = _normalize_sections_list(d.get("sections"), doc_id)
        docs.append(
            {
                "file_name": fname,
                "document_title": doc_title,
                "document_id": doc_id,
                "storage_uri": storage_uri,
                "status": "excluded" if excluded else str(d.get("status") or "active"),
                "excluded": excluded,
                "sections": sections,
            }
        )
    return docs


async def list_all_documents(plan_number: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """
    Lists all documents across all 6 scoping sources (policy, kod, procedure, gfms, historical_scoping_document, lrr)
    for a plan in one call, using `review_data_extraction` metadata with GCS fallback.
    """
    try:
        document_groups = []
        total_count = 0
        for doc_type in ALL_SCOPING_DOCUMENT_TYPES:
            result = await list_documents_from_bucket(plan_number, doc_type, env_config)
            document_groups.append({
                "document_type": doc_type,
                "documents": result.get("documents", []),
                "total_count": result.get("total_count", 0),
            })
            total_count += result.get("total_count", 0)

        return {
            "plan_number": plan_number,
            "document_groups": document_groups,
            "total_count": total_count,
            "message": f"Successfully retrieved all documents for plan {plan_number}",
            "source": "gcs",
        }
    except Exception as e:
        logger.error(f"Error listing all documents: {str(e)}", exc_info=True)
        raise


async def list_documents_from_bucket(plan_number: str, document_type: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Lists documents from review_data_extraction metadata and/or GCS bucket."""
    try:
        return await _list_from_gcs(plan_number, document_type, env_config)
    except Exception as e:
        logger.error(f"Error listing documents: {str(e)}", exc_info=True)
        raise


async def _list_from_gcs(plan_number: str, document_type: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Lists documents from review_data_extraction first, falling back to GCS blobs for unindexed files."""
    canonical_type = _normalize_document_type(document_type)
    gcs_utils = GCSUtils(env_config)
    bucket_name = gcs_utils.bucket_name
    bucket_path = _source_folder_prefix(plan_number, canonical_type)

    db_docs = _read_db_documents_for_type(plan_number, canonical_type, env_config, bucket_name)
    docs_by_file: Dict[str, Dict[str, Any]] = {
        str(d.get("file_name") or "").lower(): d for d in db_docs if d.get("file_name")
    }

    try:
        logger.info("Listing documents from GCS: gs://%s/%s", bucket_name, bucket_path)
        bucket = gcs_utils.get_bucket()
        blobs = bucket.list_blobs(prefix=bucket_path)
        for blob in blobs:
            filename = blob.name.replace(bucket_path, "", 1) if blob.name.startswith(bucket_path) else blob.name.rsplit("/", 1)[-1]
            if not _is_allowed_gcs_fallback_blob(canonical_type, filename):
                continue
            key = filename.lower()

            doc_title = filename
            doc_id = filename
            excluded = False
            status = "active"
            sections: List[Dict[str, Any]] = []
            try:
                if filename.lower().endswith(".json"):
                    json_content = gcs_utils.read_blob_json(blob.name)
                    if isinstance(json_content, dict):
                        doc_title = str(json_content.get("document_title", filename))
                        doc_id = str(json_content.get("document_id", filename))
                        excluded = bool(json_content.get("excluded", False)) or (
                            str(json_content.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
                        )
                        status = "excluded" if excluded else str(json_content.get("status") or "active")
                    elif canonical_type == "gfms":
                        doc_title = "GFMS Findings Details"
                        doc_id = "findings_details"
                    elif canonical_type == "historical_scoping_document":
                        doc_title = "Historical Plan Details"
                        doc_id = "historical_plan_details"
                    elif canonical_type == "lrr":
                        doc_title = "Regulatory & Internet Search Mandates"
                        doc_id = "lrr_internet_search_data_enriched"
                    sections = _extract_sections_from_json_payload(canonical_type, json_content, doc_id)
            except Exception as e:
                logger.warning("Failed to read metadata from %s: %s, using filename as fallback", blob.name, str(e))

            if key in docs_by_file:
                existing_secs = docs_by_file[key].get("sections") or []
                if not existing_secs and sections:
                    if docs_by_file[key].get("excluded") is True:
                        sections = [{**s, "excluded": True, "status": "excluded"} for s in sections]
                    docs_by_file[key]["sections"] = sections
                elif existing_secs and sections:
                    merged_secs = [dict(s) for s in sections]
                    for db_sec in existing_secs:
                        if not isinstance(db_sec, dict):
                            continue
                        db_nid = str(db_sec.get("node_id") or "").strip().lower()
                        db_sid = str(db_sec.get("section_id") or "").strip().lower()
                        db_stitle = str(db_sec.get("section_title") or "").strip().lower()
                        matched_sec = False
                        for base_sec in merged_secs:
                            b_nid = str(base_sec.get("node_id") or "").strip().lower()
                            b_sid = str(base_sec.get("section_id") or "").strip().lower()
                            b_stitle = str(base_sec.get("section_title") or "").strip().lower()
                            if (
                                (db_nid and b_nid and db_nid == b_nid)
                                or (db_sid and b_sid and db_sid == b_sid)
                                or (db_stitle and b_stitle and db_stitle == b_stitle)
                            ):
                                base_sec["excluded"] = bool(db_sec.get("excluded", False))
                                base_sec["status"] = str(db_sec.get("status") or ("excluded" if base_sec["excluded"] else "active"))
                                matched_sec = True
                        if not matched_sec:
                            merged_secs.append(dict(db_sec))
                    if docs_by_file[key].get("excluded") is True:
                        for base_sec in merged_secs:
                            base_sec["excluded"] = True
                            base_sec["status"] = "excluded"
                    docs_by_file[key]["sections"] = merged_secs
            else:
                docs_by_file[key] = {
                    "file_name": filename,
                    "document_title": doc_title,
                    "document_id": doc_id,
                    "storage_uri": f"gs://{bucket_name}/{blob.name}",
                    "status": status,
                    "excluded": excluded,
                    "sections": sections,
                }
    except NotFound as e:
        logger.warning("GCS bucket path not found: %s", str(e))
        if not docs_by_file:
            return {
                "plan_number": plan_number,
                "document_type": canonical_type,
                "bucket_path": f"gs://{bucket_name}/{bucket_path}",
                "documents": [],
                "total_count": 0,
                "message": f"No documents found for plan {plan_number} and type '{canonical_type}'",
                "source": "gcs",
            }
    except Exception as e:
        if not docs_by_file:
            logger.error("Error listing documents from GCS: %s", str(e), exc_info=True)
            raise
        logger.debug("GCS fallback skipped after DB metadata load for %s: %s", canonical_type, e)

    if not docs_by_file and canonical_type in ("policy", "kod", "procedure"):
        registry_blob = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{canonical_type}.json"
        try:
            if gcs_utils.blob_exists(registry_blob):
                reg_payload = gcs_utils.read_blob_json(registry_blob)
                raw_sources = []
                if isinstance(reg_payload, dict):
                    raw_sources = (
                        reg_payload.get("documents")
                        or reg_payload.get("referenced_documents")
                        or reg_payload.get("sources")
                        or []
                    )
                elif isinstance(reg_payload, list):
                    raw_sources = reg_payload
                grouped: Dict[str, Dict[str, Any]] = {}
                for idx, item in enumerate(raw_sources, start=1):
                    if not isinstance(item, dict):
                        continue
                    title = str(
                        item.get("document_title")
                        or item.get("document_name")
                        or item.get("title")
                        or f"{canonical_type}_{idx}"
                    ).strip()
                    uri = str(item.get("storage_uri") or item.get("gs_uri") or "").strip()
                    key_name = (uri or title).lower()
                    if key_name not in grouped:
                        ex = bool(item.get("excluded", False)) or (
                            str(item.get("status") or "").strip().lower() in _EXCLUDED_STATUSES
                        )
                        grouped[key_name] = {
                            "file_name": str(item.get("filename") or f"relevant_{canonical_type}.json"),
                            "document_title": title,
                            "document_id": str(item.get("document_id") or idx),
                            "storage_uri": uri or f"gs://{bucket_name}/{registry_blob}",
                            "status": "excluded" if ex else str(item.get("status") or "active"),
                            "excluded": ex,
                            "sections": [],
                        }
                    if item.get("page_number") is not None or item.get("section_title"):
                        grouped[key_name]["sections"].extend(
                            _normalize_sections_list([item], grouped[key_name]["document_id"])
                        )
                for g_idx, entry in enumerate(grouped.values(), start=1):
                    docs_by_file[f"{entry['file_name'].lower()}::{g_idx}"] = entry
        except Exception as exc:
            logger.debug("Aggregate registry fallback failed for %s: %s", canonical_type, exc)

    documents = sorted(docs_by_file.values(), key=lambda x: str(x.get("file_name") or ""))
    return {
        "plan_number": plan_number,
        "document_type": canonical_type,
        "bucket_path": f"gs://{bucket_name}/{bucket_path}",
        "documents": documents,
        "total_count": len(documents),
        "message": f"Successfully retrieved {len(documents)} document(s) of type '{canonical_type}' for plan {plan_number}",
        "source": "gcs",
    }


async def delete_documents(
    plan_number: str,
    document_type: str,
    files: List[str],
    env_config: EnvironmentConfig,
    items: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Soft-excludes (or restores when action='include') documents/sections instead of hard-deleting blobs."""
    try:
        return await _delete_from_gcs(plan_number, document_type, files, env_config, items=items)
    except Exception as e:
        logger.error("Error soft-excluding documents: %s", str(e), exc_info=True)
        raise


async def delete_documents_bulk(plan_number: str, document_groups: List[Dict[str, Any]], env_config: EnvironmentConfig) -> Dict[str, Any]:
    """Soft-excludes or restores multiple document groups across scoping sources and returns affected research sections."""
    results = []
    total_requested = 0
    total_deleted = 0
    mutated_types: List[str] = []
    supports_items_kw = "items" in inspect.signature(delete_documents).parameters

    for group in document_groups:
        document_type = group.get("document_type")
        items = group.get("items", [])
        if not document_type or not isinstance(items, list):
            results.append({
                "document_type": document_type or "unknown",
                "files_requested": 0,
                "files_deleted": [],
                "files_failed": [],
                "total_deleted": 0,
                "message": "Invalid document group payload.",
                "source": "gcs",
                "affected_sections": [],
            })
            continue

        normalized_items = [
            item.model_dump(mode="json") if hasattr(item, "model_dump")
            else dict(item)
            for item in items
            if isinstance(item, dict) or hasattr(item, "model_dump")
        ]
        files = [item.get("file_name") for item in normalized_items if item.get("file_name")]
        if supports_items_kw:
            result = await delete_documents(plan_number, document_type, files, env_config, items=normalized_items)
        else:
            result = await delete_documents(plan_number, document_type, files, env_config)
        if result.get("total_deleted", 0) > 0 and "affected_sections" not in result:
            result["affected_sections"] = compute_affected_preliminary_research_sections([document_type])
        elif "affected_sections" not in result:
            result["affected_sections"] = []
        if result.get("total_deleted", 0) > 0:
            mutated_types.append(str(document_type))
        results.append(result)
        total_requested += result.get("files_requested", 0)
        total_deleted += result.get("total_deleted", 0)

    return {
        "plan_number": plan_number,
        "total_requested": total_requested,
        "total_deleted": total_deleted,
        "message": f"Soft-exclusion update completed for {len(results)} document type(s).",
        "results": results,
        "affected_sections": compute_affected_preliminary_research_sections(mutated_types) if total_deleted > 0 else [],
    }


def _soft_mark_json_payload(payload: Any, is_exclude: bool, section_targets: List[Dict[str, Any]]) -> Any:
    target_status = "excluded" if is_exclude else "active"
    target_sids = {str(t.get("section_id")).strip().lower() for t in section_targets if t.get("section_id") is not None}
    target_nids = {str(t.get("node_id")).strip().lower() for t in section_targets if t.get("node_id")}
    target_titles = {str(t.get("section_title")).strip().lower() for t in section_targets if t.get("section_title")}

    def _matches_sec(sec: dict, idx: int) -> bool:
        sid = str(sec.get("section_id") or sec.get("findingId") or sec.get("Plan Item Number") or idx).strip().lower()
        nid = str(sec.get("node_id") or f"lrr:mandate:{idx}").strip().lower()
        stitle = str(
            sec.get("section_title")
            or sec.get("title")
            or sec.get("findingTitle")
            or sec.get("Plan Item Title")
            or sec.get("Regulatory Mandate")
            or sec.get("mandate")
            or ""
        ).strip().lower()
        return (sid in target_sids) or (nid and nid in target_nids) or (stitle and stitle in target_titles)

    if isinstance(payload, dict):
        copy_p = dict(payload)
        if section_targets and isinstance(copy_p.get("nodes"), list):
            new_nodes = []
            for idx, node in enumerate(copy_p["nodes"], start=1):
                if isinstance(node, dict) and _matches_sec(node, idx):
                    nc = dict(node)
                    nc["excluded"] = is_exclude
                    nc["status"] = target_status
                    new_nodes.append(nc)
                else:
                    new_nodes.append(node)
            copy_p["nodes"] = new_nodes
            return copy_p
        copy_p["excluded"] = is_exclude
        copy_p["status"] = target_status
        return copy_p

    if isinstance(payload, list):
        updated = []
        m_counter = 0
        for idx, entry in enumerate(payload, start=1):
            if not isinstance(entry, dict):
                updated.append(entry)
                continue
            ec = dict(entry)
            if isinstance(ec.get("responsePayload"), list):
                new_findings = []
                for f_idx, f in enumerate(ec["responsePayload"], start=1):
                    if isinstance(f, dict) and (not section_targets or _matches_sec(f, f_idx)):
                        fc = dict(f)
                        fc["excluded"] = is_exclude
                        fc["status"] = target_status
                        new_findings.append(fc)
                    else:
                        new_findings.append(f)
                ec["responsePayload"] = new_findings
                if not section_targets:
                    ec["excluded"] = is_exclude
                    ec["status"] = target_status
            elif isinstance(ec.get("Mandates"), list):
                new_mandates = []
                for m in ec["Mandates"]:
                    if not isinstance(m, dict):
                        new_mandates.append(m)
                        continue
                    m_counter += 1
                    if not section_targets or _matches_sec(m, m_counter):
                        mc = dict(m)
                        mc["excluded"] = is_exclude
                        mc["status"] = target_status
                        new_mandates.append(mc)
                    else:
                        new_mandates.append(m)
                ec["Mandates"] = new_mandates
                if not section_targets:
                    ec["excluded"] = is_exclude
                    ec["status"] = target_status
            elif not section_targets or _matches_sec(ec, idx):
                ec["excluded"] = is_exclude
                ec["status"] = target_status
            updated.append(ec)
        return updated
    return payload


async def _delete_from_gcs(
    plan_number: str,
    document_type: str,
    files: List[str],
    env_config: EnvironmentConfig,
    items: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Toggle exclusion in review_data_extraction metadata; inbound GCS is read-only."""
    canonical_type = _normalize_document_type(document_type)
    deleted: List[str] = []
    failed: List[str] = []

    try:
        gcs_utils = GCSUtils(env_config)
        bucket = gcs_utils.get_bucket()
        base_path = _source_folder_prefix(plan_number, canonical_type)
        db_docs = _read_db_documents_for_type(plan_number, canonical_type, env_config, gcs_utils.bucket_name)
        db_by_file = {str(d.get("file_name") or "").lower(): d for d in db_docs if d.get("file_name")}

        item_by_file: Dict[str, Dict[str, Any]] = {}
        for it in items or []:
            if isinstance(it, dict) and it.get("file_name"):
                item_by_file[str(it["file_name"]).strip().lower()] = it

        target_names = list(files or [it["file_name"] for it in (items or []) if isinstance(it, dict) and it.get("file_name")])

        for filename in target_names:
            item = item_by_file.get(str(filename).strip().lower(), {})
            target_action = str(item.get("action") or "exclude").strip().lower()
            is_exclude = target_action != "include"
            section_targets: List[Dict[str, Any]] = []
            if isinstance(item.get("sections"), list) and item["sections"]:
                section_targets.extend(s for s in item["sections"] if isinstance(s, dict))
            elif item.get("section_id") is not None or item.get("section_title") or item.get("node_id"):
                section_targets.append(
                    {
                        "section_id": item.get("section_id"),
                        "section_title": item.get("section_title"),
                        "node_id": item.get("node_id"),
                    }
                )

            try:
                blob_path = base_path + filename
                blob = bucket.blob(blob_path)
                db_doc = db_by_file.get(str(filename).strip().lower())
                exists_in_gcs = bool(blob.exists()) or bool(gcs_utils.blob_exists(blob_path))
                if not exists_in_gcs and db_doc is None:
                    logger.warning("Document not found in DB or GCS for soft-exclusion: %s", blob_path)
                    failed.append(filename)
                    continue

                if DatabaseConnector is None:
                    raise RuntimeError("Database connector unavailable")
                db_conn = DatabaseConnector(env_config)
                storage_uri = (db_doc or {}).get("storage_uri") or f"gs://{gcs_utils.bucket_name}/{blob_path}"
                doc_title = str(item.get("document_title") or (db_doc or {}).get("document_title") or filename)
                doc_id = str(item.get("document_id") or (db_doc or {}).get("document_id") or "")
                targets = section_targets or [None]
                for sec in targets:
                    result = db_conn.mutate_data_extraction_metadata(
                        plan_number=plan_number,
                        document_type=canonical_type,
                        action=target_action,
                        title=doc_title,
                        filename=filename,
                        storage_uri=storage_uri,
                        document_id=doc_id or None,
                        section_id=sec.get("section_id") if sec else None,
                        section_title=sec.get("section_title") if sec else None,
                        node_id=sec.get("node_id") if sec else None,
                        actor="ui_action",
                    )
                    if not result.get("updated"):
                        raise RuntimeError(f"DB exclusion metadata not persisted: {result}")

                from service.context_builder import PLAN_INBOUND_CACHE
                PLAN_INBOUND_CACHE.pop(str(plan_number).strip(), None)
                deleted.append(filename)
            except Exception as e:
                logger.error("Failed to soft-exclude document %s: %s", filename, str(e))
                failed.append(filename)

        verb = "updated" if any(isinstance(i, dict) and i.get("action") == "include" for i in (items or [])) else "soft-excluded"
        if len(deleted) == len(target_names):
            message = f"Successfully {verb} all {len(deleted)} document(s)"
        elif len(deleted) == 0:
            message = f"Failed to process any documents - 0 out of {len(target_names)} updated"
        else:
            message = f"Partially {verb} {len(deleted)} out of {len(target_names)} documents ({len(failed)} failed)"

        return {
            "plan_number": plan_number,
            "document_type": canonical_type,
            "files_requested": len(target_names),
            "files_deleted": deleted,
            "files_failed": failed,
            "total_deleted": len(deleted),
            "message": message,
            "source": "gcs",
            "affected_sections": compute_affected_preliminary_research_sections([canonical_type]) if deleted else [],
        }
    except Exception as e:
        logger.error("Error soft-excluding documents: %s", str(e), exc_info=True)
        raise


async def upload_documents(
    plan_number: str,
    document_type: str,
    items: List[Dict[str, Any]],
    env_config: EnvironmentConfig,
) -> Dict[str, Any]:
    """Uploads documents/sections to the GCS bucket and updates the plan registry (sister to delete_documents)."""
    try:
        return await _upload_to_gcs(plan_number, document_type, items, env_config)
    except Exception as e:
        logger.error(f"Error uploading documents: {str(e)}", exc_info=True)
        raise


async def upload_documents_bulk(
    plan_number: str,
    document_groups: List[Dict[str, Any]],
    env_config: EnvironmentConfig,
) -> Dict[str, Any]:
    """Uploads multiple document groups in one call across policy, kod, and procedure (sister to delete_documents_bulk)."""
    results = []
    total_requested = 0
    total_uploaded = 0

    for group in document_groups:
        document_type = group.get("document_type")
        items = group.get("items", [])
        if not document_type or not isinstance(items, list):
            results.append({
                "document_type": document_type or "unknown",
                "files_requested": 0,
                "files_uploaded": [],
                "files_failed": [],
                "total_uploaded": 0,
                "message": "Invalid document group payload.",
                "source": "gcs",
            })
            continue

        normalized_items = [
            item.model_dump(mode="json") if hasattr(item, "model_dump")
            else dict(item)
            for item in items
            if isinstance(item, dict) or hasattr(item, "model_dump")
        ]
        result = await upload_documents(plan_number, document_type, normalized_items, env_config)
        results.append(result)
        total_requested += result.get("files_requested", 0)
        total_uploaded += result.get("total_uploaded", 0)

    return {
        "plan_number": plan_number,
        "total_requested": total_requested,
        "total_uploaded": total_uploaded,
        "message": f"Upload completed for {len(results)} document type(s).",
        "results": results,
    }


async def _upload_to_gcs(
    plan_number: str,
    document_type: str,
    items: List[Dict[str, Any]],
    env_config: EnvironmentConfig,
) -> Dict[str, Any]:
    """Writes uploaded document/section JSON files to GCS and registers them in relevant_{document_type}.json."""
    uploaded: List[str] = []
    failed: List[str] = []
    try:
        normalized_type = _normalize_document_type(document_type)
        gcs_utils = GCSUtils(env_config)
        base_path = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{normalized_type}/"

        logger.info(f"Uploading {len(items)} document(s) to GCS: {base_path}")
        for idx, item in enumerate(items, start=1):
            if not isinstance(item, dict):
                failed.append(f"item_{idx}")
                continue
            doc_title = str(item.get("document_title") or item.get("title") or f"{normalized_type}_{idx}").strip()
            doc_id = str(item.get("document_id") or item.get("id") or doc_helpers._slugify_title(doc_title) or f"{normalized_type}_{idx}")
            filename = str(item.get("file_name") or "").strip()
            if not filename:
                slug = doc_helpers._slugify_title(doc_title) or f"{normalized_type}_{doc_id}"
                filename = f"{slug}.json"
            elif not filename.endswith(".json"):
                filename = f"{filename}.json"

            try:
                blob_path = base_path + filename
                doc_payload: Dict[str, Any] = {
                    "document_id": doc_id,
                    "document_title": doc_title,
                    "document_type": normalized_type,
                    "status": "active",
                    "excluded": False,
                }
                if item.get("section_id") is not None:
                    doc_payload["section_id"] = item.get("section_id")
                if item.get("section_title") is not None:
                    doc_payload["section_title"] = item.get("section_title")
                if item.get("content") is not None:
                    doc_payload["content"] = item.get("content")
                if item.get("paragraphs") is not None:
                    doc_payload["paragraphs"] = item.get("paragraphs")
                elif item.get("content") is not None:
                    doc_payload["paragraphs"] = [
                        {
                            "section_id": item.get("section_id") or "1",
                            "section_title": item.get("section_title") or doc_title,
                            "text": item.get("content") if isinstance(item.get("content"), str) else json.dumps(item.get("content")),
                        }
                    ]

                storage_uri = gcs_utils.write_blob_json(blob_path, doc_payload)
                await _mark_registry_document_included(
                    plan_number=plan_number,
                    document_type=normalized_type,
                    target_title=doc_title,
                    gcs_utils=gcs_utils,
                    document_entry=doc_payload,
                )
                if DatabaseConnector is not None:
                    try:
                        db_conn = DatabaseConnector(env_config)
                        sections_meta = _normalize_sections_list(
                            item.get("sections") or doc_payload.get("paragraphs"),
                            doc_id,
                        )
                        db_conn.mutate_data_extraction_metadata(
                            plan_number=plan_number,
                            document_type=normalized_type,
                            action="include",
                            title=doc_title,
                            filename=filename,
                            storage_uri=storage_uri or f"gs://{gcs_utils.bucket_name}/{blob_path}",
                            document_id=doc_id,
                            sections=sections_meta or None,
                            section_id=item.get("section_id"),
                            section_title=item.get("section_title"),
                            actor="upload",
                        )
                    except Exception as db_exc:
                        logger.debug("DB sync skipped on upload for %s: %s", filename, db_exc)
                logger.info(f"Successfully uploaded GCS blob and updated registry: {blob_path}")
                uploaded.append(filename)
            except Exception as e:
                logger.error(f"Failed to upload GCS blob {filename}: {str(e)}")
                failed.append(filename)

        if len(uploaded) == len(items):
            message = f"Successfully uploaded all {len(uploaded)} document(s) to GCS"
        elif len(uploaded) == 0:
            message = f"Failed to upload any documents - 0 out of {len(items)} uploaded to GCS"
        else:
            message = f"Partially uploaded {len(uploaded)} out of {len(items)} documents to GCS ({len(failed)} failed)"

        return {
            "plan_number": plan_number,
            "document_type": normalized_type,
            "files_requested": len(items),
            "files_uploaded": uploaded,
            "files_failed": failed,
            "total_uploaded": len(uploaded),
            "message": message,
            "source": "gcs",
        }
    except Exception as e:
        logger.error(f"Error uploading documents to GCS: {str(e)}", exc_info=True)
        raise

