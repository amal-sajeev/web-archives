"""
Additional-context file management for Preliminary Research regeneration.

Files are stored per plan under:
    dbaware_review_{plan_number}/inbound-data/additional-context/preliminary-research/{file_id}/{file_name}

`file_id` is the SHA-256 hash of the file content, which gives a stable identifier for
removal and content-based de-duplication without any additional persistence.
"""

import asyncio
import hashlib
import logging
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from google.api_core.exceptions import PreconditionFailed

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils

logger = logging.getLogger(__name__)

ADDITIONAL_CONTEXT_SUBPATH = "inbound-data/additional-context/preliminary-research"
DEFAULT_CONTENT_TYPE = "application/octet-stream"
DEFAULT_FILE_NAME = "uploaded_file"
MAX_FILE_NAME_LENGTH = 200

_PLAN_NUMBER_RE = re.compile(r"^[A-Za-z0-9_-]+$")
_FILE_ID_RE = re.compile(r"^[a-f0-9]{64}$")
_UNSAFE_FILE_NAME_CHARS_RE = re.compile(r"[^A-Za-z0-9._ -]")


def _validate_plan_number(plan_number: Optional[str]) -> str:
    value = (plan_number or "").strip()
    if not value or not _PLAN_NUMBER_RE.match(value):
        raise ValueError("A valid plan_number is required (letters, digits, '-' or '_').")
    return value


def _validate_file_id(file_id: str) -> str:
    value = (file_id or "").strip().lower()
    if not _FILE_ID_RE.match(value):
        raise ValueError(f"Invalid file_id: {file_id!r}")
    return value


def _safe_file_name(file_name: Optional[str]) -> str:
    base = os.path.basename((file_name or "").replace("\\", "/"))
    cleaned = _UNSAFE_FILE_NAME_CHARS_RE.sub("_", base).strip().lstrip(".")
    if not cleaned:
        return DEFAULT_FILE_NAME
    return cleaned[-MAX_FILE_NAME_LENGTH:]


def _prefix(plan_number: str) -> str:
    return f"dbaware_review_{plan_number}/{ADDITIONAL_CONTEXT_SUBPATH}/"


def _blob_to_file(blob: Any, bucket_name: str, prefix: str, duplicate: bool = False) -> Optional[Dict[str, Any]]:
    relative = blob.name[len(prefix):]
    parts = relative.split("/", 1)
    if len(parts) != 2 or not _FILE_ID_RE.match(parts[0]) or not parts[1]:
        return None
    metadata = blob.metadata or {}
    uploaded_at = metadata.get("uploaded_at")
    if not uploaded_at and getattr(blob, "time_created", None):
        uploaded_at = blob.time_created.isoformat()
    return {
        "file_id": parts[0],
        "file_name": metadata.get("original_filename") or parts[1],
        "blob_path": blob.name,
        "gcs_uri": f"gs://{bucket_name}/{blob.name}",
        "size_bytes": blob.size,
        "content_type": blob.content_type,
        "uploaded_at": uploaded_at,
        "duplicate": duplicate,
    }


def _find_existing(bucket: Any, bucket_name: str, prefix: str, file_id: str) -> Optional[Dict[str, Any]]:
    for blob in bucket.list_blobs(prefix=f"{prefix}{file_id}/", max_results=1):
        return _blob_to_file(blob, bucket_name, prefix, duplicate=True)
    return None


def _upload_sync(plan_number: str, files: List[Dict[str, Any]], env_config: EnvironmentConfig) -> List[Dict[str, Any]]:
    gcs_utils = GCSUtils(env_config)
    bucket = gcs_utils.get_bucket()
    bucket_name = gcs_utils.bucket_name
    prefix = _prefix(plan_number)

    results: List[Dict[str, Any]] = []
    seen_in_batch: Dict[str, Dict[str, Any]] = {}

    for item in files:
        content: bytes = item.get("content") or b""
        if not content:
            raise ValueError(f"File '{item.get('filename')}' is empty.")

        file_id = hashlib.sha256(content).hexdigest()

        if file_id in seen_in_batch:
            results.append({**seen_in_batch[file_id], "duplicate": True})
            continue

        existing = _find_existing(bucket, bucket_name, prefix, file_id)
        if existing:
            logger.info("Additional-context file already exists plan=%s file_id=%s", plan_number, file_id)
            seen_in_batch[file_id] = existing
            results.append(existing)
            continue

        file_name = _safe_file_name(item.get("filename"))
        content_type = item.get("content_type") or DEFAULT_CONTENT_TYPE
        blob_path = f"{prefix}{file_id}/{file_name}"
        uploaded_at = datetime.now(timezone.utc).isoformat()

        blob = bucket.blob(blob_path)
        blob.metadata = {
            "original_filename": file_name,
            "sha256": file_id,
            "uploaded_at": uploaded_at,
        }
        try:
            # if_generation_match=0 -> only create; never overwrite a concurrently written blob.
            blob.upload_from_string(content, content_type=content_type, if_generation_match=0)
        except PreconditionFailed:
            existing = _find_existing(bucket, bucket_name, prefix, file_id)
            if existing:
                seen_in_batch[file_id] = existing
                results.append(existing)
                continue
            raise

        uploaded = {
            "file_id": file_id,
            "file_name": file_name,
            "blob_path": blob_path,
            "gcs_uri": f"gs://{bucket_name}/{blob_path}",
            "size_bytes": len(content),
            "content_type": content_type,
            "uploaded_at": uploaded_at,
            "duplicate": False,
        }
        logger.info("Uploaded additional-context file plan=%s file_id=%s uri=%s", plan_number, file_id, uploaded["gcs_uri"])
        seen_in_batch[file_id] = uploaded
        results.append(uploaded)

    return results


def _remove_sync(plan_number: str, file_ids: List[str], env_config: EnvironmentConfig) -> Dict[str, List[str]]:
    gcs_utils = GCSUtils(env_config)
    bucket = gcs_utils.get_bucket()
    prefix = _prefix(plan_number)

    removed: List[str] = []
    not_found: List[str] = []
    for file_id in dict.fromkeys(file_ids):
        blobs = list(bucket.list_blobs(prefix=f"{prefix}{file_id}/"))
        if not blobs:
            not_found.append(file_id)
            continue
        for blob in blobs:
            blob.delete()
        logger.info("Removed additional-context file plan=%s file_id=%s", plan_number, file_id)
        removed.append(file_id)
    return {"removed": removed, "not_found": not_found}


def _list_sync(plan_number: str, env_config: EnvironmentConfig) -> List[Dict[str, Any]]:
    gcs_utils = GCSUtils(env_config)
    bucket = gcs_utils.get_bucket()
    bucket_name = gcs_utils.bucket_name
    prefix = _prefix(plan_number)

    files: List[Dict[str, Any]] = []
    for blob in bucket.list_blobs(prefix=prefix):
        parsed = _blob_to_file(blob, bucket_name, prefix)
        if parsed:
            files.append(parsed)
    return files


async def upload_additional_context_files(
    plan_number: Optional[str],
    files: List[Dict[str, Any]],
    env_config: EnvironmentConfig,
) -> List[Dict[str, Any]]:
    """
    Uploads files (each `{filename, content, content_type}`) to the plan's additional-context folder.
    Files whose content already exists for the plan are not re-uploaded; the existing entry is
    returned with `duplicate=True`.
    """
    plan = _validate_plan_number(plan_number)
    if not files:
        raise ValueError("At least one file must be uploaded.")
    return await asyncio.to_thread(_upload_sync, plan, files, env_config)


async def remove_additional_context_files(
    plan_number: Optional[str],
    file_ids: List[str],
    env_config: EnvironmentConfig,
) -> Dict[str, List[str]]:
    """Deletes the given file IDs from the plan's additional-context folder."""
    plan = _validate_plan_number(plan_number)
    validated_ids = [_validate_file_id(fid) for fid in file_ids]
    if not validated_ids:
        raise ValueError("At least one file_id is required.")
    return await asyncio.to_thread(_remove_sync, plan, validated_ids, env_config)


async def list_additional_context_files(
    plan_number: Optional[str],
    env_config: EnvironmentConfig,
) -> List[Dict[str, Any]]:
    """Lists additional-context files currently stored for the plan."""
    plan = _validate_plan_number(plan_number)
    return await asyncio.to_thread(_list_sync, plan, env_config)
