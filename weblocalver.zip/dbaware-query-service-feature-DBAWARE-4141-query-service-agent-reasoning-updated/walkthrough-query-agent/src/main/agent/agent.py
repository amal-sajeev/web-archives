import os
import ssl
import logging
import tempfile
import certifi
from google.auth import default
import google.auth.transport.requests
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import SystemMessage, HumanMessage
from agent_helper.prompt_utils import PromptBuilder

logger = logging.getLogger(__name__)

AI_ACCESS_LAYER_BASE_URL = os.getenv("AI_ACCESS_LAYER_BASE_URL") or os.getenv("GENAI_BASE_URL")
_CERTIFICATE_CONFIGURED = False
_ORIG_CERTIFI_WHERE = certifi.where


def _is_local_cert_auth_enabled() -> bool:
    """
    Enables custom certificate auth only when explicitly turned on.
    Intended for local development.
    """
    raw_value = str(os.getenv("ENABLE_LOCAL_CERT_AUTH", "")).strip().lower()
    return raw_value == "true"


def _is_local_runtime() -> bool:
    """
    Treat Kubernetes runtime as non-local; everything else defaults to local.
    """
    return not bool(os.getenv("KUBERNETES_SERVICE_HOST"))


def _set_ssl_bundle_env(path: str) -> None:
    """
    Set SSL bundle environment variables without overriding pre-existing values.
    """
    os.environ.setdefault("REQUESTS_CA_BUNDLE", path)
    os.environ.setdefault("SSL_CERT_FILE", path)
    os.environ.setdefault("GRPC_DEFAULT_SSL_ROOTS_FILE_PATH", path)


def configure_certificate(custom_cert_paths: list[str]) -> str:
    """
    Combines certifi's default CA bundle with one or more custom certificates
    and sets the required environment variables.
    """
    if not custom_cert_paths:
        raise ValueError("No custom certificate paths are set")

    with open(_ORIG_CERTIFI_WHERE(), "r", encoding="utf-8") as f:
        ca_bundle = f.read()

    custom_certs: list[str] = []
    for custom_cert_path in custom_cert_paths:
        if not os.path.exists(custom_cert_path):
            raise FileNotFoundError(f"Certificate file not found: {custom_cert_path}")

        with open(custom_cert_path, "r", encoding="utf-8") as f:
            custom_cert = f.read()

        if "-----BEGIN CERTIFICATE-----" not in custom_cert:
            raise ValueError(f"Certificate file is not PEM format: {custom_cert_path}")
        custom_certs.append(custom_cert)

    combined_path = os.path.join(os.path.dirname(custom_cert_paths[0]), "combined-ca-bundle.pem")
    try:
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)
    except OSError:
        combined_path = os.path.join(tempfile.gettempdir(), "combined-ca-bundle.pem")
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)

    os.environ["REQUESTS_CA_BUNDLE"] = combined_path
    os.environ["SSL_CERT_FILE"] = combined_path
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = combined_path
    os.environ["CURL_CA_BUNDLE"] = combined_path
    certifi.where = lambda: combined_path
    try:
        orig_create_default_context = ssl.create_default_context
        def custom_create_default_context(*args, **kwargs):
            ctx = orig_create_default_context(*args, **kwargs)
            try:
                ctx.load_verify_locations(cafile=combined_path)
            except Exception:
                pass
            return ctx
        ssl.create_default_context = custom_create_default_context
    except Exception as ssl_err:
        logger.warning("Could not patch ssl.create_default_context: %s", ssl_err)
    return combined_path


def _configure_certificate_once() -> None:
    global _CERTIFICATE_CONFIGURED
    if _CERTIFICATE_CONFIGURED:
        return

    if _is_local_runtime() and _is_local_cert_auth_enabled():
        custom_paths = str(os.getenv("CUSTOM_CERT_PATHS") or "").strip()
        if custom_paths:
            cert_paths = [p.strip() for p in custom_paths.split(",") if p.strip()]
        else:
            legacy_path = str(os.getenv("CUSTOM_CERT_PATH") or "").strip()
            cert_paths = [legacy_path] if legacy_path else []

        if cert_paths:
            combined_path = configure_certificate(cert_paths)
            logger.info("Custom certificate bundle configured at: %s", combined_path)
            _CERTIFICATE_CONFIGURED = True
            return

    configured_path = (
        str(os.getenv("CA_BUNDLE_PATH", "")).strip()
        or str(os.getenv("SSL_CERT_FILE", "")).strip()
    )
    if configured_path and os.path.exists(configured_path):
        _set_ssl_bundle_env(configured_path)
        logger.info("Configured SSL CA bundle from CA_BUNDLE_PATH: %s", configured_path)
        _CERTIFICATE_CONFIGURED = True
        return
    if configured_path and not os.path.exists(configured_path):
        logger.warning(
            "CA_BUNDLE_PATH '%s' does not exist; ignoring it and falling back to the default trust store.",
            configured_path,
        )

    if not _is_local_runtime():
        logger.info("CA_BUNDLE_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    if not _is_local_cert_auth_enabled():
        logger.info("Local certificate auth is disabled; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    logger.info("CUSTOM_CERT_PATH is not set; using default trust store")
    _CERTIFICATE_CONFIGURED = True


class GoogleOAuthTokenProvider:
    def __init__(self):
        _configure_certificate_once()
        self.credentials, _ = default(
            scopes=[
                "https://www.googleapis.com/auth/cloud-platform",
                "https://www.googleapis.com/auth/userinfo.email",
            ]
        )
        self.request = google.auth.transport.requests.Request()

    @property
    def token(self):
        if not self.credentials.valid:
            _configure_certificate_once()
            self.credentials.refresh(self.request)
        return self.credentials.token


def initialize_gemini_model(env_config=None) -> ChatGoogleGenerativeAI:
    """
    Initializes the ChatGoogleGenerativeAI (Gemini) model via the AI Access Layer gateway.
    """
    if env_config is None:
        from agent_helper.env_config import EnvironmentConfig
        env_config = EnvironmentConfig()

    _configure_certificate_once()
    provider = GoogleOAuthTokenProvider()

    model_name = (
        os.getenv("GENAI_MODEL_NAME")
        or env_config.get_env_config("GENAI_MODEL_NAME")
        or "gemini-3.5-flash-europe-west3"
    )
    base_url = (
        os.getenv("AI_ACCESS_LAYER_BASE_URL")
        or os.getenv("GENAI_BASE_URL")
        or env_config.get_env_config("AI_ACCESS_LAYER_BASE_URL")
        or AI_ACCESS_LAYER_BASE_URL
    )

    logger.info("Initializing ChatGoogleGenerativeAI model model=%s base_url=%s", model_name, base_url)
    return ChatGoogleGenerativeAI(
        model=model_name,
        api_key=provider.token,
        base_url=base_url,
    )

def _extract_response_text(response) -> str:
    """Safely extracts text content across str, blocks, and test MagicMock objects."""
    text_attr = getattr(response, "text", None)
    if isinstance(text_attr, str) and text_attr.strip():
        return text_attr
    content = getattr(response, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and "text" in item:
                parts.append(str(item["text"]))
            elif hasattr(item, "text") and isinstance(item.text, str):
                parts.append(item.text)
            else:
                parts.append(str(item))
        return "".join(parts)
    return str(content) if content is not None else ""

def run_agent(query: str, env_config) -> str:
    """
    Executes a query through the configured Gemini model.
    """
    # Initialize LLM strictly matching the scoping-summary-agent pattern
    llm = initialize_gemini_model(env_config)

    # Build prompt systematically using the structured JSON assets
    logger.info("Compiling agent prompts using PromptBuilder...")
    prompt_builder = PromptBuilder(prompt_file_name="agent_prompt.json")
    compiled_prompt = prompt_builder.build_prompt(query_input=query)

    messages = [
        SystemMessage(content=compiled_prompt),
        HumanMessage(content=query)
    ]

    logger.info("Sending call request to GCP Gemini via LangChain ChatGoogleGenerativeAI...")
    response = llm.invoke(messages)
    return _extract_response_text(response)