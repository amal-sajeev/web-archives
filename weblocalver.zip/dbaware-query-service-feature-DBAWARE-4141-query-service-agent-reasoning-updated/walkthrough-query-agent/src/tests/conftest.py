import asyncio
import inspect
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

# Ensure src/main is discoverable
main_dir = Path(__file__).resolve().parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

src_dir = Path(__file__).resolve().parent.parent
if str(src_dir) not in sys.path:
    sys.path.insert(0, str(src_dir))

# Remove invalid / expired credentials in CI to avoid DefaultCredentialsError during test collection
creds_file = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
if creds_file and not os.path.exists(creds_file):
    del os.environ["GOOGLE_APPLICATION_CREDENTIALS"]

# Fallback test environment flags
os.environ.setdefault("ENV_NAME", "dev")
os.environ.setdefault("bucket_name", "db-dev-euwe3-gcs-155081-dbaware_review")
os.environ.setdefault("BUCKET_NAME", "db-dev-euwe3-gcs-155081-dbaware_review")
os.environ.setdefault("MOCK_SCOPING_DB", "true")  # local tests only; production defaults to false

# Mock Google PubSub and Auth clients during test collection to avoid missing credentials error
try:
    from google.cloud import pubsub_v1
    pubsub_v1.PublisherClient = MagicMock()
except ImportError:
    pass

try:
    import google.auth
    google.auth.default = MagicMock(return_value=(MagicMock(), "test-project"))
except ImportError:
    pass

def pytest_configure(config):
    """Configure pytest-asyncio for auto mode (with fallback when plugin is absent)."""
    config.addinivalue_line("markers", "asyncio: mark test as an asyncio coroutine")
    config.option.asyncio_mode = "auto"
    config.option.asyncio_default_fixture_loop_scope = "function"


def pytest_pyfunc_call(pyfuncitem):
    """Fallback async test runner when pytest-asyncio is not installed in the active venv."""
    if pyfuncitem.config.pluginmanager.hasplugin("asyncio"):
        return None
    testfunction = pyfuncitem.obj
    if inspect.iscoroutinefunction(testfunction):
        funcargs = pyfuncitem.funcargs
        testargs = {arg: funcargs[arg] for arg in pyfuncitem._fixtureinfo.argnames}
        asyncio.run(testfunction(**testargs))
        return True
    return None


import httpx

if "app" not in inspect.signature(httpx.Client.__init__).parameters:
    _orig_httpx_client_init = httpx.Client.__init__

    def _compat_httpx_client_init(self, *args, **kwargs):
        kwargs.pop("app", None)
        return _orig_httpx_client_init(self, *args, **kwargs)

    httpx.Client.__init__ = _compat_httpx_client_init


@pytest.fixture(autouse=True)
def _reset_in_memory_test_state():
    """Prevent module-level mock DB and pending-plan state from leaking across tests."""
    for mod_name in ("service.database_connector", "main.service.database_connector"):
        mod = sys.modules.get(mod_name)
        if mod is not None:
            getattr(mod, "_MOCK_DATA_EXTRACTION_STORE", {}).clear()
            getattr(mod, "_MOCK_REVIEW_DOCUMENTS_STORE", {}).clear()
    for mod_name in ("service.document_chat_workflow", "main.service.document_chat_workflow"):
        mod = sys.modules.get(mod_name)
        if mod is not None:
            getattr(mod, "PENDING_DOCUMENT_PLANS", {}).clear()
    yield
