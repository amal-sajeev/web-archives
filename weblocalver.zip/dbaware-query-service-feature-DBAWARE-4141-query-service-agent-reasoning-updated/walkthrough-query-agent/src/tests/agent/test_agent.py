import sys
from pathlib import Path
from unittest.mock import MagicMock, patch
from agent.agent import initialize_gemini_model
# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from unittest.mock import MagicMock, patch
from agent.agent import initialize_gemini_model, run_agent


def test_initialize_gemini_model():
    """Verify that initialize_gemini_model initializes ChatGoogleGenerativeAI with AI Access Layer base_url and OAuth token without temperature/top_p/top_k."""
    mock_env_config = MagicMock()
    
    config_mapping = {
        "GENAI_MODEL_NAME": "gemini-3.5-flash-europe-west3",
        "AI_ACCESS_LAYER_BASE_URL": "https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com",
    }
    mock_env_config.get_env_config.side_effect = lambda key, default=None: config_mapping.get(key, default)

    with patch("agent.agent._configure_certificate_once"), \
         patch("agent.agent.GoogleOAuthTokenProvider") as mock_provider_cls, \
         patch("agent.agent.ChatGoogleGenerativeAI") as mock_chat_class:
        mock_provider = MagicMock()
        mock_provider.token = "mock-oauth-token"
        mock_provider_cls.return_value = mock_provider

        initialize_gemini_model(mock_env_config)
        
        mock_chat_class.assert_called_once_with(
            model="gemini-3.5-flash-europe-west3",
            api_key="mock-oauth-token",
            base_url="https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com",
        )
        # Ensure no generation config parameters that break Vertex calls are passed
        call_kwargs = mock_chat_class.call_args[1]
        assert "temperature" not in call_kwargs
        assert "top_p" not in call_kwargs
        assert "top_k" not in call_kwargs
        assert "project" not in call_kwargs
        assert "location" not in call_kwargs

@patch("agent.agent.initialize_gemini_model")
@patch("agent.agent.PromptBuilder")
def test_run_agent(mock_prompt_builder_class, mock_init_model):
    """Verify run_agent compiles the prompt systematically and invokes the initialized LLM with structured message types."""
    mock_env_config = MagicMock()
    
    # Mock LLM and response
    mock_llm = MagicMock()
    mock_response = MagicMock()
    mock_response.content = "Mocked Agent Response"
    mock_llm.invoke.return_value = mock_response
    mock_init_model.return_value = mock_llm
    
    # Mock PromptBuilder
    mock_prompt_builder = MagicMock()
    mock_prompt_builder.build_prompt.return_value = "System Instruction Content"
    mock_prompt_builder_class.return_value = mock_prompt_builder

    # Run target method
    result = run_agent("What are the key controls?", mock_env_config)

    # Asserts
    assert result == "Mocked Agent Response"
    mock_init_model.assert_called_once_with(mock_env_config)
    mock_prompt_builder_class.assert_called_once_with(prompt_file_name="agent_prompt.json")
    mock_prompt_builder.build_prompt.assert_called_once_with(query_input="What are the key controls?")
    mock_llm.invoke.assert_called_once()