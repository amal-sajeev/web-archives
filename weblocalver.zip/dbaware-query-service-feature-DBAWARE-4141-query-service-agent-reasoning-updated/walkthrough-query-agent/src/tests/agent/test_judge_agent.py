import sys
from pathlib import Path
from unittest.mock import MagicMock, patch
from agent.judge_agent import initialize_judge_model
# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from unittest.mock import MagicMock, patch
from agent.judge_agent import initialize_judge_model


def test_initialize_judge_model():
    """Verify that initialize_judge_model initializes ChatGoogleGenerativeAI with AI Access Layer base_url and OAuth token without temperature/top_p."""
    mock_env_config = MagicMock()
    
    config_mapping = {
        "LLM_JUDGE_MODEL_NAME": "gemini-3.5-flash-europe-west3",
        "AI_ACCESS_LAYER_BASE_URL": "https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com",
    }
    mock_env_config.get_env_config.side_effect = lambda key, default=None: config_mapping.get(key, default)

    with patch("agent.judge_agent._configure_certificate_once"), \
         patch("agent.judge_agent.GoogleOAuthTokenProvider") as mock_provider_cls, \
         patch("agent.judge_agent.ChatGoogleGenerativeAI") as mock_chat_class:
        mock_provider = MagicMock()
        mock_provider.token = "mock-judge-oauth-token"
        mock_provider_cls.return_value = mock_provider

        initialize_judge_model(mock_env_config)
        
        mock_chat_class.assert_called_once_with(
            model="gemini-3.5-flash-europe-west3",
            api_key="mock-judge-oauth-token",
            base_url="https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com",
        )
        call_kwargs = mock_chat_class.call_args[1]
        assert "temperature" not in call_kwargs
        assert "top_p" not in call_kwargs
        assert "top_k" not in call_kwargs
        assert "project" not in call_kwargs
        assert "location" not in call_kwargs


def test_judge_configure_certificate_tempfile_fallback(tmp_path, monkeypatch):
    import agent.judge_agent as judge_mod

    cert_file = tmp_path / "judge_custom.crt"
    cert_file.write_text("-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----\n", encoding="utf-8")

    orig_open = open
    calls = {"failed_once": False}

    def flaky_open(file, mode="r", *args, **kwargs):
        if "w" in mode and str(file).startswith(str(tmp_path)) and not calls["failed_once"]:
            calls["failed_once"] = True
            raise OSError("OneDrive folder locked")
        return orig_open(file, mode, *args, **kwargs)

    monkeypatch.setattr("builtins.open", flaky_open)
    monkeypatch.setattr(judge_mod.tempfile, "gettempdir", lambda: str(tmp_path / "fallback"))
    (tmp_path / "fallback").mkdir(exist_ok=True)

    monkeypatch.setattr(judge_mod, "_CERTIFICATE_CONFIGURED", False)
    monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
    monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "true")
    monkeypatch.setenv("CUSTOM_CERT_PATHS", str(cert_file))

    judge_mod._configure_certificate_once()
    assert judge_mod._CERTIFICATE_CONFIGURED is True
    assert calls["failed_once"] is True
    judge_mod.certifi.where = judge_mod._ORIG_CERTIFI_WHERE

        