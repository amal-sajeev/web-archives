
# Model Hyperparameters and Architecture
GCP_MODEL_NAME: "gemini-2.5-pro"
LLM_JUDGE_MODEL_NAME: "gemini-2.5-flash"

# LLM-as-a-Judge Evaluation Policies
LLM_JUDGE_THRESHOLD: 0.85
LLM_JUDGE_MAX_ITERATIONS: 3