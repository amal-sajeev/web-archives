import sys

from pathlib import Path

# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from fastapi import FastAPI, status
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, patch
from service.router import router
from service import document_service
from agent_helper.env_config import EnvironmentConfig

app = FastAPI()
app.include_router(router)
client = TestClient(app)

@patch("service.router.chat_logic", new_callable=AsyncMock)
def test_chat_endpoint_success(mock_chat_logic):
    """Verify POST /chat responds with the compiled dynamic payload schema."""
    mock_chat_logic.return_value = (
        "Parsed Answer Output", 4, None, "test-corr-id",
        {"input_tokens": 500, "output_tokens": 100, "total_tokens": 600}
    )
    
    payload = {
        "question": "Identify potential critical risks.",
        "plan_number": "20090"
    }
    response = client.post("/qna/chat", json=payload)
    assert response.status_code == status.HTTP_200_OK
    
    data = response.json()
    assert "answer" in data
    assert data["answer"] == "Parsed Answer Output"
    assert data["history_length"] == 4
    assert data["input_tokens"] == 500
    assert data["output_tokens"] == 100
    assert data["total_tokens"] == 600

def test_chat_endpoint_malformed_pydantic_payload():
    """Verify endpoint rejects requests with a 422 Unprocessable Entity if required fields are missing."""
    payload = {
        "plan_number": "20583"  # Omitted required "question" parameter
    }
    response = client.post("/qna/chat", json=payload)
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

@patch("service.router.close_session_logic", new_callable=AsyncMock)
def test_close_session_endpoint_success(mock_close_session_logic):
    """Verify POST /session/close executes successfully."""
    mock_close_session_logic.return_value = "Cached eviction successful."
    
    payload = {"session_id": "ABC123"}
    response = client.post("/qna/session/close", json=payload)
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["message"] == "Cached eviction successful."


@patch("service.router.close_session_logic", new_callable=AsyncMock)
def test_close_session_endpoint_not_found(mock_close_session_logic):
    """Verify POST /session/close raises a 404 error if key does not exist."""
    mock_close_session_logic.side_effect = KeyError("Session expired.")
    
    payload = {"session_id": "invalid_id"}
    response = client.post("/qna/session/close", json=payload)
    assert response.status_code == status.HTTP_404_NOT_FOUND

@patch("service.router.list_documents_from_bucket", new_callable=AsyncMock)
def test_list_documents_endpoint_success(mock_list_documents):
    """Verify POST /documents/list returns the metadata payload for a single document type."""
    mock_list_documents.return_value = {
        "plan_number": "20440",
        "document_type": "policy",
        "bucket_path": "gs://test-bucket/dbaware_review_20440/inbound-data/policy/relevant_policy/",
        "documents": [{
            "file_name": "policy_1.json",
            "document_title": "Policy 1",
            "document_id": "POL-1"
        }],
        "total_count": 1,
        "message": "ok",
        "source": "gcs"
    }

    response = client.post("/qna/documents/list", json={"plan_number": "20440", "document_type": "policy"})

    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["plan_number"] == "20440"
    assert payload["document_type"] == "policy"
    assert payload["documents"][0]["file_name"] == "policy_1.json"
    assert payload["total_count"] == 1


@patch("service.router.list_all_documents", new_callable=AsyncMock)
def test_list_all_documents_endpoint_success(mock_list_all):
    """Verify POST /documents/list-all returns grouped document results."""
    mock_list_all.return_value = {
        "plan_number": "20440",
        "document_groups": [
            {
                "document_type": "policy",
                "documents": [{"file_name": "policy_1.json", "document_title": "Policy 1", "document_id": "POL-1"}],
                "total_count": 1
            },
            {
                "document_type": "kod",
                "documents": [],
                "total_count": 0
            }
        ],
        "total_count": 1,
        "message": "ok",
        "source": "gcs"
    }

    response = client.post("/qna/documents/list-all", json={"plan_number": "20440"})

    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["plan_number"] == "20440"
    assert payload["total_count"] == 1
    assert payload["document_groups"][0]["document_type"] == "policy"


@patch("service.router.delete_documents_bulk", new_callable=AsyncMock)
def test_delete_documents_endpoint_success(mock_delete_documents_bulk):
    """Verify POST /documents/delete accepts grouped deletions and returns an aggregate summary."""
    mock_delete_documents_bulk.return_value = {
        "plan_number": "20440",
        "total_requested": 2,
        "total_deleted": 2,
        "message": "Delete completed for 2 document type(s).",
        "results": [
            {
                "document_type": "policy",
                "files_requested": 1,
                "files_deleted": ["policy_1.json"],
                "files_failed": [],
                "total_deleted": 1,
                "message": "Successfully deleted all 1 document(s) from GCS",
                "source": "gcs"
            },
            {
                "document_type": "procedure",
                "files_requested": 1,
                "files_deleted": ["procedure_1.json"],
                "files_failed": [],
                "total_deleted": 1,
                "message": "Successfully deleted all 1 document(s) from GCS",
                "source": "gcs"
            }
        ]
    }

    response = client.post(
        "/qna/documents/delete",
        json={
            "plan_number": "20440",
            "documents": [
                {
                    "document_type": "policy",
                    "items": [{"file_name": "policy_1.json", "document_title": "Policy 1", "document_id": "POL-1"}]
                },
                {
                    "document_type": "procedure",
                    "items": [{"file_name": "procedure_1.json", "document_title": "Procedure 1", "document_id": "PROC-1"}]
                }
            ]
        }
    )

    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["plan_number"] == "20440"
    assert payload["total_deleted"] == 2
    assert payload["results"][0]["document_type"] == "policy"


@pytest.mark.asyncio
async def test_list_all_documents_aggregates_gcs_results(monkeypatch):
    """Verify list_all_documents aggregates all document types and reports source as gcs."""
    mock_results = {
        "policy": {
            "plan_number": "20440",
            "document_type": "policy",
            "bucket_path": "gs://test/policy",
            "documents": [{"file_name": "policy_1.json", "document_title": "Policy One", "document_id": "POL-1"}],
            "total_count": 1,
            "message": "ok",
            "source": "gcs"
        },
        "kod": {
            "plan_number": "20440",
            "document_type": "kod",
            "bucket_path": "gs://test/kod",
            "documents": [{"file_name": "kod_1.json", "document_title": "Kod One", "document_id": "KOD-1"}],
            "total_count": 1,
            "message": "ok",
            "source": "gcs"
        },
        "procedure": {
            "plan_number": "20440",
            "document_type": "procedure",
            "bucket_path": "gs://test/procedure",
            "documents": [{"file_name": "procedure_1.json", "document_title": "Procedure One", "document_id": "PROC-1"}],
            "total_count": 1,
            "message": "ok",
            "source": "gcs"
        },
        "gfms": {
            "plan_number": "20440",
            "document_type": "gfms",
            "bucket_path": "gs://test/gfms",
            "documents": [{"file_name": "findings_details.json", "document_title": "GFMS Findings Details", "document_id": "findings_details"}],
            "total_count": 1,
            "message": "ok",
            "source": "gcs"
        },
        "historical_scoping_document": {
            "plan_number": "20440",
            "document_type": "historical_scoping_document",
            "bucket_path": "gs://test/dbaware",
            "documents": [{"file_name": "historical_plan_details.json", "document_title": "Historical Plan Details", "document_id": "historical_plan_details"}],
            "total_count": 1,
            "message": "ok",
            "source": "gcs"
        },
        "lrr": {
            "plan_number": "20440",
            "document_type": "lrr",
            "bucket_path": "gs://test/lrr",
            "documents": [{"file_name": "internet_search_data.json", "document_title": "Internet Search Data", "document_id": "lrr_internet_search"}],
            "total_count": 1,
            "message": "ok",
            "source": "gcs"
        },
    }

    async def fake_list(plan_number, document_type, _env_config):
        return mock_results[document_type]

    monkeypatch.setattr(document_service, "list_documents_from_bucket", fake_list)

    result = await document_service.list_all_documents("20440", EnvironmentConfig())

    assert result["plan_number"] == "20440"
    assert result["source"] == "gcs"
    assert result["total_count"] == 6
    assert len(result["document_groups"]) == 6


@pytest.mark.asyncio
async def test_delete_documents_bulk_aggregates_gcs_delete_results(monkeypatch):
    """Verify bulk delete aggregates per-document-type delete results for GCS flow."""

    async def fake_delete(plan_number, document_type, files, _env_config):
        return {
            "plan_number": plan_number,
            "document_type": document_type,
            "files_requested": len(files),
            "files_deleted": files,
            "files_failed": [],
            "total_deleted": len(files),
            "message": "Successfully deleted all documents from GCS",
            "source": "gcs"
        }

    monkeypatch.setattr(document_service, "delete_documents", fake_delete)

    result = await document_service.delete_documents_bulk(
        "20440",
        [
            {
                "document_type": "policy",
                "items": [{"file_name": "policy_1.json", "document_title": "Policy One", "document_id": "POL-1"}]
            },
            {
                "document_type": "procedure",
                "items": [{"file_name": "procedure_1.json", "document_title": "Procedure One", "document_id": "PROC-1"}]
            }
        ],
        env_config=EnvironmentConfig()
    )

    assert result["total_requested"] == 2
    assert result["total_deleted"] == 2
    assert result["results"][0]["source"] == "gcs"
    assert result["results"][1]["files_deleted"] == ["procedure_1.json"]


@patch("service.router.upload_documents_bulk", new_callable=AsyncMock)
def test_upload_documents_endpoint_success(mock_upload_documents_bulk):
    """Verify POST /documents/upload accepts grouped uploads and returns an aggregate summary."""
    mock_upload_documents_bulk.return_value = {
        "plan_number": "20440",
        "total_requested": 2,
        "total_uploaded": 2,
        "message": "Upload completed for 2 document type(s).",
        "results": [
            {
                "document_type": "policy",
                "files_requested": 1,
                "files_uploaded": ["policy_10.json"],
                "files_failed": [],
                "total_uploaded": 1,
                "message": "Successfully uploaded all 1 document(s) to GCS",
                "source": "gcs",
            },
            {
                "document_type": "kod",
                "files_requested": 1,
                "files_uploaded": ["kod_20.json"],
                "files_failed": [],
                "total_uploaded": 1,
                "message": "Successfully uploaded all 1 document(s) to GCS",
                "source": "gcs",
            },
        ],
    }

    response = client.post(
        "/qna/documents/upload",
        json={
            "plan_number": "20440",
            "documents": [
                {
                    "document_type": "policy",
                    "items": [
                        {
                            "file_name": "policy_10.json",
                            "document_title": "Policy 10",
                            "document_id": "10",
                            "content": "Policy 10 text",
                        }
                    ],
                },
                {
                    "document_type": "kod",
                    "items": [
                        {
                            "file_name": "kod_20.json",
                            "document_title": "KOD 20",
                            "document_id": "20",
                            "content": "KOD 20 text",
                        }
                    ],
                },
            ],
        },
    )

    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["plan_number"] == "20440"
    assert payload["total_uploaded"] == 2
    assert payload["results"][0]["files_uploaded"] == ["policy_10.json"]


@pytest.mark.asyncio
async def test_upload_documents_bulk_aggregates_gcs_upload_results(monkeypatch):
    """Verify bulk upload aggregates per-document-type upload results for GCS flow."""

    async def fake_upload(plan_number, document_type, items, _env_config):
        files = [item.get("file_name") or "uploaded.json" for item in items]
        return {
            "plan_number": plan_number,
            "document_type": document_type,
            "files_requested": len(files),
            "files_uploaded": files,
            "files_failed": [],
            "total_uploaded": len(files),
            "message": "Successfully uploaded all documents to GCS",
            "source": "gcs",
        }

    monkeypatch.setattr(document_service, "upload_documents", fake_upload)

    result = await document_service.upload_documents_bulk(
        "20440",
        [
            {
                "document_type": "policy",
                "items": [{"file_name": "policy_10.json", "document_title": "Policy Ten", "document_id": "10"}],
            },
            {
                "document_type": "procedure",
                "items": [{"file_name": "procedure_20.json", "document_title": "Procedure Twenty", "document_id": "20"}],
            },
        ],
        env_config=EnvironmentConfig(),
    )

    assert result["total_requested"] == 2
    assert result["total_uploaded"] == 2
    assert result["results"][0]["source"] == "gcs"
    assert result["results"][1]["files_uploaded"] == ["procedure_20.json"]


@patch("service.router.ingest_documents_to_rag", new_callable=AsyncMock)
def test_ingest_documents_endpoint_success(mock_ingest):
    """Verify POST /documents/ingest forwards uploaded files to RAG service."""
    mock_ingest.return_value = {
        "status": "accepted",
        "job_id": "job-12345",
        "document_ids": [101, 102],
        "message": "Ingestion started",
    }

    response = client.post(
        "/qna/documents/ingest",
        data={"plan_number": "20440", "document_type": "policy"},
        files=[("policy_files", ("new_policy.pdf", b"%PDF-1.4 dummy", "application/pdf"))],
    )

    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["job_id"] == "job-12345"
    assert payload["document_ids"] == [101, 102]
    assert payload["plan_number"] == "20440"


@patch("service.router.get_rag_ingest_job_status", new_callable=AsyncMock)
def test_get_ingest_job_status_endpoint_success(mock_job_status):
    """Verify GET /documents/ingest-jobs/{job_id} returns job status and document IDs."""
    mock_job_status.return_value = {
        "job_id": "job-12345",
        "status": "completed",
        "document_ids": [101, 102],
        "message": "Ingestion finished",
    }

    response = client.get("/qna/documents/ingest-jobs/job-12345")
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["job_id"] == "job-12345"
    assert payload["status"] == "completed"
    assert payload["document_ids"] == [101, 102]


@patch("service.router.categorize_rag_document_ids", new_callable=AsyncMock)
def test_categorize_documents_endpoint_success(mock_categorize):
    """Verify POST /documents/categorize categorizes document IDs via RAG."""
    mock_categorize.return_value = {
        "status": "success",
        "policy": [1, 2],
        "kod": [3],
        "procedure": [4, 5],
    }

    response = client.post(
        "/qna/documents/categorize",
        json={"plan_number": "20440", "document_ids": [1, 2, 3, 4, 5]},
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["status"] == "success"
    assert payload["document_ids"] == [1, 2, 3, 4, 5]
    assert payload["categorized_documents"]["policy"] == [1, 2]


@patch("service.router.persist_rag_relevant_data_to_context", new_callable=AsyncMock)
@patch("service.router.get_relevant_data_for_documents_from_rag", new_callable=AsyncMock)
def test_get_relevant_data_for_documents_endpoint_success(mock_get_rel, mock_persist):
    """Verify POST /documents/relevant-data calls RAG and persists retrieved sections to context."""
    mock_get_rel.return_value = {
        "status": "success",
        "review_id": 20440,
        "results": [
            {
                "document_type": "policy",
                "document_id": 1,
                "document_title": "Electronic Communications Policy",
                "paragraphs": [{"section_id": "1.1", "text": "Retention required"}],
            }
        ],
    }
    mock_persist.return_value = {
        "persisted_files": ["dbaware_review_20440/inbound-data/policy/relevant_policy/policy_1.json"],
        "registry_updated": True,
    }

    response = client.post(
        "/qna/documents/relevant-data",
        json={
            "plan_number": "20440",
            "review_id": 20440,
            "documents": [{"document_type": "policy", "document_ids": [1], "top_k": 5}],
            "persist_to_context": True,
        },
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["status"] == "success"
    assert payload["registry_updated"] is True
    assert len(payload["persisted_files"]) == 1


@patch("service.router.add_context_to_session_logic", new_callable=AsyncMock)
def test_add_chat_context_endpoint_success(mock_add_ctx):
    """Verify POST /chat/context/add adds sections/documents to the active chat session."""
    mock_add_ctx.return_value = {
        "session_id": "20440",
        "plan_number": "20440",
        "context_type": "Preliminary Research Walkthrough",
        "status": "success",
        "sections_added": 1,
        "documents_added": 0,
        "persisted_files": ["dbaware_review_20440/inbound-data/policy/relevant_policy.json"],
        "registry_updated": True,
        "message": "Successfully added 0 document(s) and 1 section(s) to session '20440'.",
    }

    response = client.post(
        "/qna/chat/context/add",
        json={
            "plan_number": "20440",
            "sections": [
                {
                    "section_title": "Section 4.2 Escalation",
                    "content": "Escalation must happen within 24 hours.",
                    "document_type": "policy",
                    "document_title": "Escalation Policy",
                }
            ],
        },
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["status"] == "success"
    assert payload["sections_added"] == 1
    assert payload["registry_updated"] is True


@patch("service.router.orchestrate_document_inclusion_workflow", new_callable=AsyncMock)
def test_inclusion_workflow_endpoint_success(mock_inclusion_workflow):
    """Verify POST /documents/inclusion/workflow delegates to the inclusion orchestrator."""
    mock_inclusion_workflow.return_value = {
        "plan_number": "20440",
        "status": "approval_required",
        "requires_approval": True,
        "message": "Approval is required before backend inclusion execution.",
    }

    response = client.post(
        "/qna/documents/inclusion/workflow",
        json={
            "plan_number": "20440",
            "action": "include",
            "candidates": [{"document_type": "policy", "title": "Global Trade Surveillance Policy"}],
            "user_text": "include policy Global Trade Surveillance Policy",
            "approved": False,
        },
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["plan_number"] == "20440"
    assert payload["requires_approval"] is True


@patch("service.router.extract_document_actions", new_callable=AsyncMock)
def test_extract_document_actions_endpoint_success(mock_extract):
    """Verify POST /documents/actions/extract returns Stage 1 extracted actions."""
    mock_extract.return_value = {
        "plan_number": "20440",
        "is_document_request": True,
        "actions": [{"action": "exclude", "document_type": "policy", "title": "Policy 1"}],
        "reasoning": "User requested removal of Policy 1",
        "source": "deterministic",
    }

    response = client.post(
        "/qna/documents/actions/extract",
        json={"plan_number": "20440", "user_text": "remove policy @Policy 1"},
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["is_document_request"] is True
    assert payload["actions"][0]["action"] == "exclude"


@patch("service.router.verify_document_actions", new_callable=AsyncMock)
def test_verify_document_actions_endpoint_success(mock_verify):
    """Verify POST /documents/actions/verify returns Stage 2 verified rows and Liquibase PKs."""
    mock_verify.return_value = {
        "plan_number": "20440",
        "verified": [
            {
                "action": "exclude",
                "document_type": "policy",
                "title": "Policy 1",
                "matched": True,
                "status": "verified",
                "context_file": "dbaware_review_20440/inbound-data/policy/relevant_policy.json",
                "row_primary_key": "1",
                "review_scope_dataext_id": "2044001",
                "review_document_instance_id": "204401001",
                "review_scope_instance_id": "20440",
                "table_name": "dbaware_scoping.review_data_extraction",
            }
        ],
        "unmatched": [],
        "message": "Verified 1 of 1 requested document action(s).",
    }

    response = client.post(
        "/qna/documents/actions/verify",
        json={
            "plan_number": "20440",
            "actions": [{"action": "exclude", "document_type": "policy", "title": "Policy 1"}],
        },
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert len(payload["verified"]) == 1
    assert payload["verified"][0]["review_scope_dataext_id"] == "2044001"


@patch("service.router.propose_document_action_plan", new_callable=AsyncMock)
def test_plan_document_actions_endpoint_success(mock_plan):
    """Verify POST /documents/actions/plan returns Stage 3/4 pending approval plan."""
    mock_plan.return_value = {
        "plan_number": "20440",
        "plan_id": "plan-uuid-1",
        "status": "pending_approval",
        "summary": "1 document(s) will be removed and 0 added in the plan context.",
        "steps": [
            {
                "step": 1,
                "action": "exclude",
                "document_type": "policy",
                "title": "Policy 1",
                "context_file": "dbaware_review_20440/inbound-data/policy/relevant_policy.json",
                "row_primary_key": "1",
                "review_scope_dataext_id": "2044001",
                "rationale": "Matched Policy 1",
            }
        ],
        "warnings": [],
        "requires_approval": True,
        "message": "Reply approve to apply these changes, or reject to cancel.",
        "source": "deterministic",
    }

    response = client.post(
        "/qna/documents/actions/plan",
        json={"plan_number": "20440", "user_text": "remove policy @Policy 1"},
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["status"] == "pending_approval"
    assert payload["requires_approval"] is True
    assert payload["steps"][0]["review_scope_dataext_id"] == "2044001"


@patch("service.router.decide_document_action_plan", new_callable=AsyncMock)
def test_decide_document_actions_endpoint_success(mock_decide):
    """Verify POST /documents/actions/decision executes Stages 5-6 on approval."""
    mock_decide.return_value = {
        "plan_number": "20440",
        "plan_id": "plan-uuid-1",
        "status": "executed",
        "message": "Applied 1 document change(s).",
    }

    response = client.post(
        "/qna/documents/actions/decision",
        json={"plan_number": "20440", "decision": "approve", "approved_by": "auditor"},
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["status"] == "executed"


@patch("service.router.execute_document_actions", new_callable=AsyncMock)
def test_execute_document_actions_endpoint_success(mock_execute):
    """Verify POST /documents/actions/execute applies Stage 6 mutations."""
    mock_execute.return_value = {
        "plan_number": "20440",
        "status": "success",
        "message": "Applied 1 document change(s).",
        "executed": [
            {
                "action": "exclude",
                "document_type": "policy",
                "title": "Policy 1",
                "row_primary_keys": ["1", "2044001"],
                "review_scope_dataext_id": "2044001",
            }
        ],
        "failed": [],
        "registry_updated": True,
        "audit": {},
    }

    response = client.post(
        "/qna/documents/actions/execute",
        json={
            "plan_number": "20440",
            "actions": [
                {
                    "action": "exclude",
                    "document_type": "policy",
                    "title": "Policy 1",
                    "row_primary_keys": ["1", "2044001"],
                    "review_scope_dataext_id": "2044001",
                }
            ],
        },
    )
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["status"] == "success"
    assert payload["registry_updated"] is True


@patch("service.router.upload_json_logic", new_callable=AsyncMock)
def test_upload_json_endpoint_success(mock_upload_json):
    """Verify POST /upload uploads a JSON file to GCS."""
    mock_upload_json.return_value = (
        "dbaware_review_20440/inbound-data/test.json",
        "gs://test-bucket/dbaware_review_20440/inbound-data/test.json",
    )
    response = client.post(
        "/qna/upload",
        data={"dest_blob_path": "dbaware_review_20440/inbound-data/test.json"},
        files={"file": ("test.json", b'{"hello": "world"}', "application/json")},
    )
    assert response.status_code == status.HTTP_201_CREATED
    payload = response.json()
    assert payload["gcs_blob_path"] == "dbaware_review_20440/inbound-data/test.json"


@patch("service.router.manage_policies", new_callable=AsyncMock)
def test_manage_policies_endpoint_success(mock_manage_policies):
    """Verify POST /policies/manage processes natural language policy command."""
    mock_manage_policies.return_value = {
        "status": "success",
        "message": "Removed policy 1",
        "policies_removed": [1],
        "available_policies": [1, 2],
        "action": "exclude",
        "llm_decision_reasoning": "User asked to exclude policy 1",
    }
    response = client.post("/qna/policies/manage", json={"command": "exclude policy 1"})
    assert response.status_code == status.HTTP_200_OK
    payload = response.json()
    assert payload["policies_removed"] == [1]


@patch("service.router.verify_document_context_logic", new_callable=AsyncMock)
def test_exclusion_verify_context_endpoint_success(mock_verify_ctx):
    """Verify POST /documents/exclusion/verify-context delegates to orchestrator."""
    mock_verify_ctx.return_value = {
        "plan_number": "20440",
        "action": "exclude",
        "verified_documents": [
            {
                "document_type": "policy",
                "title": "Policy 1",
                "matched": True,
                "status": "verified",
                "context_file": "dbaware_review_20440/inbound-data/policy/relevant_policy.json",
                "row_primary_key": "1",
            }
        ],
        "unmatched_documents": [],
        "message": "Verified 1 document.",
        "source": "runtime-context-verification",
    }
    response = client.post(
        "/qna/documents/exclusion/verify-context",
        json={
            "plan_number": "20440",
            "action": "exclude",
            "candidates": [{"document_type": "policy", "title": "Policy 1"}],
        },
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["verified_documents"][0]["matched"] is True


@patch("service.router.build_document_exclusion_plan_logic", new_callable=AsyncMock)
def test_exclusion_plan_endpoint_success(mock_build_plan):
    """Verify POST /documents/exclusion-plan builds an exclusion approval plan."""
    mock_build_plan.return_value = {
        "plan_number": "20440",
        "action": "exclude",
        "actions": [
            {
                "action": "exclude",
                "document_type": "policy",
                "title": "Policy 1",
                "context_file": "dbaware_review_20440/inbound-data/policy/relevant_policy.json",
                "row_primary_key": "1",
                "scope": "all_related",
            }
        ],
        "message": "Approval required.",
        "requires_approval": True,
    }
    response = client.post(
        "/qna/documents/exclusion-plan",
        json={
            "plan_number": "20440",
            "user_text": "exclude policy Policy 1",
            "action": "exclude",
            "verified_documents": [
                {
                    "document_type": "policy",
                    "title": "Policy 1",
                    "matched": True,
                    "status": "verified",
                }
            ],
        },
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["requires_approval"] is True


@patch("service.router.execute_document_exclusion_plan_logic", new_callable=AsyncMock)
def test_exclusion_execute_endpoint_success(mock_exec_plan):
    """Verify POST /documents/exclusion/execute executes the approved exclusion plan."""
    mock_exec_plan.return_value = {
        "plan_number": "20440",
        "status": "success",
        "message": "Executed 1 exclusion.",
        "executed": [
            {
                "action": "exclude",
                "document_type": "policy",
                "title": "Policy 1",
                "scope": "all_related",
            }
        ],
        "registry_updated": True,
        "audit": {},
        "source": "approved-execution",
    }
    response = client.post(
        "/qna/documents/exclusion/execute",
        json={
            "plan_number": "20440",
            "actions": [{"action": "exclude", "document_type": "policy", "title": "Policy 1"}],
            "approved_by": "tester",
        },
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["status"] == "success"


@patch("service.router.orchestrate_document_exclusion_workflow", new_callable=AsyncMock)
def test_exclusion_workflow_endpoint_success(mock_excl_workflow):
    """Verify POST /documents/exclusion/workflow delegates to the exclusion orchestrator."""
    mock_excl_workflow.return_value = {
        "plan_number": "20440",
        "status": "approval_required",
        "requires_approval": True,
        "message": "Approval required before execution.",
    }
    response = client.post(
        "/qna/documents/exclusion/workflow",
        json={
            "plan_number": "20440",
            "action": "exclude",
            "candidates": [{"document_type": "policy", "title": "Policy 1"}],
            "approved": False,
        },
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["requires_approval"] is True


@patch("service.router.verify_document_inclusion_context_logic", new_callable=AsyncMock)
def test_inclusion_verify_context_endpoint_success(mock_inc_verify):
    """Verify POST /documents/inclusion/verify-context delegates to inclusion verification."""
    mock_inc_verify.return_value = {
        "plan_number": "20440",
        "action": "include",
        "verified_documents": [
            {
                "document_type": "policy",
                "title": "New Policy",
                "matched": True,
                "status": "ready_to_add",
            }
        ],
        "unmatched_documents": [],
        "message": "Verified 1 candidate for inclusion.",
        "source": "runtime-context-verification",
    }
    response = client.post(
        "/qna/documents/inclusion/verify-context",
        json={
            "plan_number": "20440",
            "action": "include",
            "candidates": [{"document_type": "policy", "title": "New Policy"}],
        },
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["verified_documents"][0]["status"] == "ready_to_add"


@patch("service.router.build_document_inclusion_plan_logic", new_callable=AsyncMock)
def test_inclusion_plan_endpoint_success(mock_inc_plan):
    """Verify POST /documents/inclusion-plan builds an inclusion approval plan."""
    mock_inc_plan.return_value = {
        "plan_number": "20440",
        "action": "include",
        "actions": [
            {
                "action": "include",
                "document_type": "policy",
                "title": "New Policy",
                "scope": "all_related",
            }
        ],
        "message": "Approval required for inclusion.",
        "requires_approval": True,
    }
    response = client.post(
        "/qna/documents/inclusion-plan",
        json={
            "plan_number": "20440",
            "user_text": "include policy New Policy",
            "action": "include",
            "verified_documents": [
                {
                    "document_type": "policy",
                    "title": "New Policy",
                    "matched": True,
                    "status": "ready_to_add",
                }
            ],
        },
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["requires_approval"] is True


@patch("service.router.execute_document_inclusion_plan_logic", new_callable=AsyncMock)
def test_inclusion_execute_endpoint_success(mock_inc_exec):
    """Verify POST /documents/inclusion/execute executes approved inclusion actions."""
    mock_inc_exec.return_value = {
        "plan_number": "20440",
        "status": "success",
        "message": "Executed 1 inclusion.",
        "executed": [
            {
                "action": "include",
                "document_type": "policy",
                "title": "New Policy",
                "scope": "all_related",
            }
        ],
        "registry_updated": True,
        "audit": {},
        "source": "approved-inclusion-execution",
    }
    response = client.post(
        "/qna/documents/inclusion/execute",
        json={
            "plan_number": "20440",
            "actions": [{"action": "include", "document_type": "policy", "title": "New Policy"}],
            "approved_by": "tester",
        },
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["status"] == "success"


@pytest.mark.asyncio
async def test_scope_context_persists_across_chat_propose_approve_and_rest_routes(monkeypatch):
    from service import document_chat_workflow as dcw
    from service.database_connector import get_request_scope_context
    from service.request import (
        DocumentActionDecisionResponse,
        DocumentActionExecutionResponse,
        DocumentActionPlanResponse,
    )

    dcw.PENDING_DOCUMENT_PLANS.clear()
    seen_contexts = []

    async def _fake_extract(plan_number, user_text, gcs_utils=None):
        seen_contexts.append(("extract", get_request_scope_context()))
        from service.request import DocumentActionExtractionResponse, DocumentActionItem
        return DocumentActionExtractionResponse(
            plan_number=plan_number,
            is_document_request=True,
            actions=[DocumentActionItem(action="exclude", document_type="policy", title="Policy One")],
            source="heuristic",
        )

    async def _fake_verify(plan_number, actions, gcs_utils=None):
        from service.request import DocumentActionVerificationResponse, VerifiedDocumentAction
        return DocumentActionVerificationResponse(
            plan_number=plan_number,
            verified=[
                VerifiedDocumentAction(
                    action="exclude",
                    document_type="policy",
                    title="Policy One",
                    matched=True,
                    status="verified",
                )
            ],
        )

    async def _fake_execute(exec_req):
        seen_contexts.append(("execute", get_request_scope_context()))
        return DocumentActionExecutionResponse(
            plan_number=exec_req.plan_number,
            status="success",
            message="Executed",
            registry_updated=True,
        )

    monkeypatch.setattr(dcw, "extract_document_actions", _fake_extract)
    monkeypatch.setattr(dcw, "verify_document_actions", _fake_verify)
    monkeypatch.setattr(dcw, "execute_document_actions", _fake_execute)
    monkeypatch.setattr(dcw, "_invoke_llm_json", AsyncMock(side_effect=RuntimeError("offline")))
    monkeypatch.setattr("service.router.construct_human_actor_record", lambda *a, **kw: None)
    monkeypatch.setattr("service.router.construct_ai_actor_record", lambda *a, **kw: None)

    resp1 = client.post(
        "/qna/chat",
        json={
            "question": "exclude policy Policy One",
            "planNumber": "20440",
            "userDetails": {"processInstanceId": "proc-turn-1", "taskId": "task-turn-1", "user": "auditor@db.com"},
        },
    )
    assert resp1.status_code == status.HTTP_200_OK
    assert resp1.json()["document_workflow"]["stage"] == "pending_approval"

    # Second turn omits userDetails; pending plan should still carry forward saved scope_context
    resp2 = client.post(
        "/qna/chat",
        json={"question": "approve", "planNumber": "20440"},
    )
    assert resp2.status_code == status.HTTP_200_OK
    assert resp2.json()["document_workflow"]["stage"] == "executed"

    assert seen_contexts[0] == (
        "extract",
        {"process_instance_id": "proc-turn-1", "task_id": "task-turn-1", "user": "auditor@db.com"},
    )
    assert seen_contexts[1] == (
        "execute",
        {"process_instance_id": "proc-turn-1", "task_id": "task-turn-1", "user": "auditor@db.com"},
    )

    # Also verify /documents/list-all pushes scoped context to downstream service
    list_ctxs = []

    async def _fake_list_all(plan_number, env_cfg):
        list_ctxs.append(get_request_scope_context())
        return {
            "plan_number": plan_number,
            "document_groups": [],
            "total_count": 0,
            "message": "ok",
            "source": "gcs",
        }

    with patch("service.router.list_all_documents", side_effect=_fake_list_all):
        list_resp = client.post(
            "/qna/documents/list-all",
            json={
                "plan_number": "20440",
                "userDetails": {"processInstanceId": "proc-list-9", "taskId": "task-list-2"},
            },
        )
    assert list_resp.status_code == status.HTTP_200_OK
    assert list_ctxs == [{"process_instance_id": "proc-list-9", "task_id": "task-list-2"}]
    assert get_request_scope_context() == {}



