import sys
import hashlib
from pathlib import Path

main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from unittest.mock import MagicMock, patch
from google.api_core.exceptions import PreconditionFailed

from service.additional_context_service import (
    upload_additional_context_files,
    remove_additional_context_files,
    list_additional_context_files,
    _safe_file_name,
)

BUCKET = "test-bucket"
PLAN = "20440"
PREFIX = f"dbaware_review_{PLAN}/inbound-data/additional-context/preliminary-research/"


def _sha(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _blob(name, size=10, content_type="application/pdf", metadata=None):
    b = MagicMock()
    b.name = name
    b.size = size
    b.content_type = content_type
    b.metadata = metadata
    b.time_created = None
    return b


@pytest.fixture
def env_config():
    return MagicMock()


@pytest.fixture
def bucket():
    with patch("service.additional_context_service.GCSUtils") as mock_cls:
        mock_gcs = MagicMock()
        mock_gcs.bucket_name = BUCKET
        mock_bucket = MagicMock()
        mock_bucket.list_blobs.return_value = []
        mock_gcs.get_bucket.return_value = mock_bucket
        mock_cls.return_value = mock_gcs
        yield mock_bucket


async def test_upload_new_file(bucket, env_config):
    content = b"hello world"
    file_id = _sha(content)

    result = await upload_additional_context_files(
        PLAN, [{"filename": "notes.pdf", "content": content, "content_type": "application/pdf"}], env_config
    )

    assert len(result) == 1
    item = result[0]
    assert item["file_id"] == file_id
    assert item["duplicate"] is False
    assert item["blob_path"] == f"{PREFIX}{file_id}/notes.pdf"
    assert item["gcs_uri"] == f"gs://{BUCKET}/{PREFIX}{file_id}/notes.pdf"
    bucket.blob.assert_called_once_with(f"{PREFIX}{file_id}/notes.pdf")
    bucket.blob.return_value.upload_from_string.assert_called_once_with(
        content, content_type="application/pdf", if_generation_match=0
    )


async def test_upload_existing_file_returns_duplicate(bucket, env_config):
    content = b"same content"
    file_id = _sha(content)
    bucket.list_blobs.return_value = [
        _blob(f"{PREFIX}{file_id}/original.pdf", metadata={"original_filename": "original.pdf", "uploaded_at": "t"})
    ]

    result = await upload_additional_context_files(
        PLAN, [{"filename": "renamed.pdf", "content": content}], env_config
    )

    assert result[0]["duplicate"] is True
    assert result[0]["file_id"] == file_id
    assert result[0]["file_name"] == "original.pdf"
    bucket.blob.assert_not_called()


async def test_upload_duplicate_within_batch(bucket, env_config):
    content = b"twice"

    result = await upload_additional_context_files(
        PLAN,
        [{"filename": "a.txt", "content": content}, {"filename": "b.txt", "content": content}],
        env_config,
    )

    assert [r["duplicate"] for r in result] == [False, True]
    assert result[0]["file_id"] == result[1]["file_id"]
    bucket.blob.return_value.upload_from_string.assert_called_once()


async def test_upload_precondition_failed_treated_as_duplicate(bucket, env_config):
    content = b"race"
    file_id = _sha(content)
    bucket.list_blobs.side_effect = [[], [_blob(f"{PREFIX}{file_id}/race.txt")]]
    bucket.blob.return_value.upload_from_string.side_effect = PreconditionFailed("exists")

    result = await upload_additional_context_files(PLAN, [{"filename": "race.txt", "content": content}], env_config)

    assert result[0]["duplicate"] is True
    assert result[0]["file_id"] == file_id


@pytest.mark.parametrize("plan", ["", None, "../other", "20440/x", "a b"])
async def test_upload_invalid_plan_number(bucket, env_config, plan):
    with pytest.raises(ValueError):
        await upload_additional_context_files(plan, [{"filename": "a.txt", "content": b"x"}], env_config)


async def test_upload_empty_file_rejected(bucket, env_config):
    with pytest.raises(ValueError):
        await upload_additional_context_files(PLAN, [{"filename": "a.txt", "content": b""}], env_config)


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("../../etc/passwd", "passwd"),
        ("..\\..\\evil.pdf", "evil.pdf"),
        ("my file (1).pdf", "my file _1_.pdf"),
        ("", "uploaded_file"),
        (None, "uploaded_file"),
        ("...", "uploaded_file"),
    ],
)
def test_safe_file_name(raw, expected):
    assert _safe_file_name(raw) == expected


async def test_remove_found_and_not_found(bucket, env_config):
    found_id = _sha(b"found")
    missing_id = _sha(b"missing")
    found_blob = _blob(f"{PREFIX}{found_id}/f.pdf")

    def _list(prefix, **_):
        return [found_blob] if prefix == f"{PREFIX}{found_id}/" else []

    bucket.list_blobs.side_effect = _list

    result = await remove_additional_context_files(PLAN, [found_id, missing_id], env_config)

    assert result == {"removed": [found_id], "not_found": [missing_id]}
    found_blob.delete.assert_called_once()


async def test_remove_invalid_file_id(bucket, env_config):
    with pytest.raises(ValueError):
        await remove_additional_context_files(PLAN, ["../secret"], env_config)


async def test_list_files(bucket, env_config):
    fid = _sha(b"one")
    bucket.list_blobs.return_value = [
        _blob(f"{PREFIX}{fid}/one.pdf", metadata={"original_filename": "one.pdf", "uploaded_at": "2026-11-23"}),
        _blob(f"{PREFIX}stray.txt"),
        _blob(f"{PREFIX}manifest.json", content_type="application/json"),
    ]

    files = await list_additional_context_files(PLAN, env_config)

    assert len(files) == 1
    assert files[0]["file_id"] == fid
    assert files[0]["file_name"] == "one.pdf"
    assert files[0]["uploaded_at"] == "2026-11-23"
    bucket.list_blobs.assert_called_once_with(prefix=PREFIX)
