import sys
import os
from pathlib import Path

# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from service.qna_service import (
    convert_json_to_markdown,
    _extract_response_text,
    _load_optional_blob_markdown,
    _load_preliminary_research_context,
    compact_inbound_json,
    classify_query_inbound_category,
    load_and_cache_all_inbound_data,
    extract_plan_document_ids,
    fetch_document_ids_from_scoping_db,
    should_query_rag_service,
    fetch_rag_document_chunks,
    format_rag_chunks_to_markdown,
    start_session_logic,
    chat_logic,
    close_session_logic,
    stateless_chat_logic,
    upload_json_logic,
    SESSION_CACHE,
    PLAN_INBOUND_CACHE
)
def test_convert_json_to_markdown_basic():
    """Verify JSON dictionary structured formatting maps to Markdown headers & lists recursively."""
    test_data = {
        "plan_number": "20583",
        "findings": ["Gap 1", "Gap 2"],
        "nested": {
            "property": "value"
        }
    }
    md = convert_json_to_markdown(test_data)
    assert "* **Plan Number**: 20583" in md
    assert "# Findings" in md
    assert "# Nested" in md
    assert "* **Property**: value" in md

@pytest.mark.asyncio
@patch("service.qna_service.GCSUtils")
async def test_start_session_logic(mock_gcs_class):
    """Verify start_session_logic successfully fetches raw JSON from GCS and builds session state cache."""
    mock_gcs = MagicMock()
    mock_gcs.blob_exists.return_value = True
    mock_gcs.read_blob_json.return_value = {"compliance_plan_id": 20583}
    mock_gcs_class.return_value = mock_gcs

    session, preview = await start_session_logic("gs://mock-bucket/test_report.json", session_id="test_key_abc")
    assert session == "test_key_abc"
    cache_key = "test_key_abc_Preliminary Research Walkthrough"
    assert cache_key in SESSION_CACHE
    assert SESSION_CACHE[cache_key]["raw_json"] == {
        "past_review": {"compliance_plan_id": 20583},
        "policy_regulation": {"compliance_plan_id": 20583},
        "broad_scope": {"compliance_plan_id": 20583}
    }
    assert "Compliance Plan Id" in SESSION_CACHE[cache_key]["markdown_context"]
    assert "correlation_id" in SESSION_CACHE[cache_key]  # Verify correlation_id is stored

@pytest.mark.asyncio
@patch("service.qna_service.GCSUtils")
async def test_start_session_logic_test_steps_stage(mock_gcs_class):
    """Verify Test Steps stage compiles inscope, outscope, and preliminary research."""
    mock_gcs = MagicMock()
    mock_gcs.blob_exists.return_value = True
    mock_gcs.read_blob_json.side_effect = lambda path: {"source_file": path}
    mock_gcs_class.return_value = mock_gcs

    session_id, _ = await start_session_logic(session_id="20090", context_type="Test Steps")
    cache_key = "20090_Test Steps"

    assert cache_key in SESSION_CACHE
    context = SESSION_CACHE[cache_key]["markdown_context"]
    assert "STAGE CONTEXT: TEST STEPS" in context
    assert "SCOPE RECOMMENDATION: OUT OF SCOPE" in context
    assert "SCOPE RECOMMENDATION: IN SCOPE" in context
    assert "PAST REVIEW RESEARCH" in context

def test_compact_inbound_json_nodes():
    """Verify compact_inbound_json extracts structured sections from node-based documents."""
    data = {
        "document_title": "Control_Doc",
        "nodes": [
            {"section_id": "1.0", "section_title": "Overview", "original_text": "Control text here."}
        ]
    }
    compacted = compact_inbound_json(data, "test.json")
    assert "### Document: Control_Doc" in compacted
    assert "#### Section 1.0: Overview" in compacted
    assert "Control text here." in compacted

def test_classify_query_inbound_category():
    """Verify classify_query_inbound_category maps queries to operational inbound categories."""
    categories = ["dbaware", "dbgrc", "gfms", "group_audit", "lrr"]
    assert classify_query_inbound_category("What are the historical plan details and alc?", categories) == ["dbaware"]
    assert classify_query_inbound_category("Tell me about the control details in dbgrc", categories) == ["dbgrc"]
    assert classify_query_inbound_category("What are the open findings from GFMS?", categories) == ["gfms"]
    assert classify_query_inbound_category("What did group audit report in their review?", categories) == ["group_audit"]
    assert classify_query_inbound_category("What did internet search data reveal about rules?", categories) == ["lrr"]
    assert classify_query_inbound_category("Give me all inbound information", categories) == categories

def test_extract_plan_document_ids_options_a_and_b():
    """Verify document IDs are cleanly extracted from raw_json metadata and userDetails passthroughs."""
    # Option B source (supports root-level and nested modular files e.g. policy_regulation.json)
    raw_json = {
        "policy_regulation": {
            "policy_document_ids": [1, 2],
            "kod_ids": [121, 43]
        },
        "procedure_ids": [13]
    }
    # Option A source (API Gateway metadata: supports userDetails document list)
    user_details = {
        "review_scope_instance_id": 1,
        "user": "Shreya",
        "remarks": "Send pass 1",
        "documents": [
            {"document_type": "policy", "document_id": 3},
            {"document_type": "procedure", "document_id": 194}
        ]
    }
    combined = extract_plan_document_ids(raw_json=raw_json, user_details=user_details)
    assert 3 in combined["policy"]
    assert 1 in combined["policy"]
    assert 2 in combined["policy"]
    assert combined["kod"] == [121, 43]
    assert 194 in combined["procedure"]
    assert 13 in combined["procedure"]

    # Dict format for document_ids
    alt_user_details = {"document_ids": {"policy": [9], "kod": [8], "procedure": [7]}}
    alt_combined = extract_plan_document_ids(raw_json={}, user_details=alt_user_details)
    assert alt_combined == {"policy": [9], "kod": [8], "procedure": [7]}

def test_should_query_rag_service():
    """Verify should_query_rag_service detects policy and control keywords."""
    assert should_query_rag_service("Tell me about Detective control checking 10GB lines to German venues") is True
    assert should_query_rag_service("What are the procedure requirements?") is True
    assert should_query_rag_service("Hello how are you?") is False

@pytest.mark.asyncio
@patch("httpx.AsyncClient.post")
async def test_fetch_rag_document_chunks(mock_post):
    """Verify HTTP call dispatch to dbaware-rag-service."""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "results": [
            {
                "document_type": "policy",
                "chunks": [
                    {"document_title": "GBSA Policy", "section_id": "4.5.4", "section_title": "Detective Controls", "score": 0.72, "text": "Quarterly automated control report."}
                ]
            }
        ]
    }
    mock_response.raise_for_status = MagicMock()
    mock_post.return_value = mock_response

    results = await fetch_rag_document_chunks("Detective control 10GB", document_ids_map={"policy": [1, 2, 3]})
    assert len(results) == 1
    assert results[0]["document_type"] == "policy"
    assert len(results[0]["chunks"]) == 1

@pytest.mark.asyncio
@patch("httpx.AsyncClient.post")
async def test_fetch_rag_document_chunks_error_paths(mock_post):
    """Verify HTTP status errors and exceptions are caught safely."""
    import httpx
    # 1. Non-200 HTTP status response
    mock_err_resp = MagicMock()
    mock_err_resp.status_code = 500
    mock_err_resp.text = "Internal Server Error"
    mock_post.return_value = mock_err_resp
    res_500 = await fetch_rag_document_chunks("query")
    assert res_500 == []

    # 2. HTTPError exception
    mock_post.side_effect = httpx.ConnectError("Failed connection")
    res_err = await fetch_rag_document_chunks("query")
    assert res_err == []

def test_format_rag_chunks_to_markdown():
    """Verify converting RAG chunks to Markdown structure."""
    mock_results = [{
        "document_type": "policy",
        "chunks": [{"document_title": "GBSA Manual", "section_id": "4.5.4", "section_title": "Controls", "score": 0.85, "text": "Control details here."}]
    }]
    md = format_rag_chunks_to_markdown(mock_results)
    assert "## RETRIEVED GOVERNANCE & POLICY EVIDENCE (RAG SERVICE)" in md
    assert "### [POLICY] GBSA Manual (Section 4.5.4: Controls)" in md
    assert "Control details here." in md
    assert format_rag_chunks_to_markdown([]) == ""

def test_compact_inbound_json_non_dict_and_plain_dict():
    """Verify compact_inbound_json handles non-dict payloads and dicts without nodes."""
    res_list = compact_inbound_json(["item1", "item2"], "test.json")
    assert "* item1" in res_list

    res_plain = compact_inbound_json({"key": "value"}, "plain.json")
    assert "### Document: plain.json" in res_plain
    assert "* **Key**: value" in res_plain

def test_load_optional_blob_markdown():
    """Verify _load_optional_blob_markdown returns None when missing or upon read exception."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"
    # Blob does not exist
    mock_gcs.blob_exists.return_value = False
    assert _load_optional_blob_markdown(mock_gcs, "missing.json", "Title") is None

    # Read throws exception
    mock_gcs.blob_exists.return_value = True
    mock_gcs.read_blob_json.side_effect = RuntimeError("Disk failure")
    assert _load_optional_blob_markdown(mock_gcs, "broken.json", "Title") is None

def test_load_preliminary_research_context_legacy_fallback():
    """Verify fallback to legacy preliminary-research.json when modular files are absent."""
    mock_gcs = MagicMock()
    def exists_side_effect(path):
        return path.endswith("preliminary-research.json")

    mock_gcs.blob_exists.side_effect = exists_side_effect
    mock_gcs.read_blob_json.return_value = {"legacy_key": "legacy_val"}

    raw_json, doc_blocks = _load_preliminary_research_context(mock_gcs, "20090")
    assert "legacy_key" in raw_json
    assert len(doc_blocks) == 1
    assert "preliminary-research.json" in doc_blocks[0]

@pytest.mark.asyncio
@patch("service.qna_service.DatabaseConnector")
async def test_fetch_document_ids_from_scoping_db(mock_connector_class):
    """Verify fetch_document_ids_from_scoping_db delegates to DatabaseConnector."""
    mock_instance = MagicMock()
    mock_instance.get_document_ids_for_scope_instance.return_value = {
        "policy": [1, 2], "kod": [3], "procedure": [4]
    }
    mock_connector_class.return_value = mock_instance

    docs = await fetch_document_ids_from_scoping_db(1)
    assert docs["policy"] == [1, 2]
    assert docs["kod"] == [3]
    assert docs["procedure"] == [4]

@pytest.mark.asyncio
@patch("service.qna_service.DatabaseConnector", None)
async def test_fetch_document_ids_from_scoping_db_none():
    """Verify fetch_document_ids_from_scoping_db returns mock defaults when connector is unavailable."""
    docs = await fetch_document_ids_from_scoping_db(1)
    assert docs == {
        "policy": [1, 2, 3],
        "kod": [121, 43, 27],
        "procedure": [13, 17, 194]
    }

@pytest.mark.asyncio
@patch("service.qna_service.run_llm_judge")
@patch("service.qna_service.initialize_gemini_model")
@patch("service.qna_service.PromptBuilder")
@patch("service.qna_service.fetch_rag_document_chunks")
async def test_chat_logic_with_rag_and_refusal_template(mock_rag_fetch, mock_pb, mock_llm_init, mock_judge):
    """Verify chat_logic triggers RAG integration and bypasses judge on refusal template."""
    mock_rag_fetch.return_value = [{
        "document_type": "policy",
        "chunks": [{"document_title": "Test Policy", "section_id": "1", "section_title": "Scope", "score": 0.9, "text": "Must comply."}]
    }]
    mock_builder = MagicMock()
    mock_builder.build_prompt.return_value = "System Instruction"
    mock_pb.return_value = mock_builder

    mock_llm = MagicMock()
    mock_response = MagicMock()
    mock_response.content = "I cannot confirm this from walkthrough documentation."
    mock_response.usage_metadata = {"input_tokens": 50, "output_tokens": 10, "total_tokens": 60}
    mock_llm.invoke.return_value = mock_response
    mock_llm.get_num_tokens_from_messages.return_value = 50
    mock_llm_init.return_value = mock_llm

    SESSION_CACHE["rag_plan_Preliminary Research Walkthrough"] = {
        "raw_json": {},
        "markdown_context": "Base Context",
        "chat_history": [],
        "correlation_id": "corr-123"
    }
    PLAN_INBOUND_CACHE["rag_plan"] = {}

    answer, _, metrics, _, _ = await chat_logic(
        session_id="rag_plan",
        user_query="What is the policy threshold?",
        user_details={"review_scope_instance_id": 1}
    )
    assert answer == "I cannot confirm this from walkthrough documentation."
    assert metrics.verdict == "PASS"
    assert mock_judge.call_count == 0  # Bypassed judge due to refusal shortcut

@pytest.mark.asyncio
@patch("service.qna_service.GCSUtils")
async def test_start_session_logic_operational_inbound(mock_gcs_class):
    """Verify start_session_logic pre-caches operational inbound categories without throwing."""
    mock_gcs = MagicMock()
    mock_gcs.blob_exists.return_value = True
    mock_gcs.read_blob_json.return_value = {"compliance_plan_id": 20440}
    mock_gcs.get_bucket.return_value.list_blobs.return_value = []
    mock_gcs_class.return_value = mock_gcs
    session_id, _ = await start_session_logic(session_id="20440", context_type="Preliminary Research Walkthrough")
    assert session_id == "20440"

@pytest.mark.asyncio
@patch("service.qna_service.run_llm_judge")
@patch("service.qna_service.initialize_gemini_model")
@patch("service.qna_service.PromptBuilder")
async def test_chat_logic_stateful_run(mock_pb, mock_llm_initializer, mock_run_llm_judge):
    """Verify dynamic stateful prompt generation and chat history state enrichment."""
    from service.llm_judge import JudgeEvaluation
    mock_run_llm_judge.return_value = JudgeEvaluation(
        groundedness_score=1.0,
        citation_coverage=1.0,
        unsupported_claim_count=0,
        contradiction_score=0.0,
        context_faithfulness=1.0,
        answer_relevance=1.0,
        verdict="PASS",
        reasoning="Test Pass"
    )
    # Mock PromptBuilder
    mock_builder = MagicMock()
    mock_builder.build_prompt.return_value = "Constructed System Guideline Instruction"
    mock_pb.return_value = mock_builder

    # Mock Gemini invocation
    mock_llm = MagicMock()
    mock_response = MagicMock()
    mock_response.content = "Calculated Gemini Answer text"
    mock_response.usage_metadata = {"input_tokens": 120, "output_tokens": 30, "total_tokens": 150}
    mock_llm.get_num_tokens_from_messages.return_value = 120
    mock_llm.invoke.return_value = mock_response
    mock_llm_initializer.return_value = mock_llm

    # Inject fake warm session context
    cache_key = "chat_state_session_Preliminary Research Walkthrough"
    SESSION_CACHE[cache_key] = {
        "raw_json": {},
        "markdown_context": "Markdown Content Context",
        "chat_history": [],
        "correlation_id": "test-corr-id-123"
    }
    PLAN_INBOUND_CACHE["chat_state_session"] = {}

    answer, hist_len, final_metrics, correlation_id, token_usage = await chat_logic("chat_state_session", "What is the key control?")
    assert answer == "Calculated Gemini Answer text"
    assert hist_len == 2  # Includes 1 Human message and 1 AI message
    assert correlation_id == "test-corr-id-123"
    assert len(SESSION_CACHE[cache_key]["chat_history"]) == 2
    assert token_usage["input_tokens"] == 120
    assert token_usage["output_tokens"] == 30
    assert token_usage["total_tokens"] == 150

@pytest.mark.asyncio
async def test_close_session_logic():
    """Verify active session evictions from internal cached dictionaries."""
    SESSION_CACHE["temp_evict_key"] = {"raw_json": {}, "markdown_context": "", "chat_history": []}
    assert "temp_evict_key" in SESSION_CACHE
    msg = await close_session_logic("temp_evict_key")
    assert "temp_evict_key" not in SESSION_CACHE
    assert "Successfully closed" in msg

@pytest.mark.asyncio
@patch("service.qna_service.initialize_gemini_model")
@patch("service.qna_service.PromptBuilder")
async def test_stateless_chat_logic_success(mock_pb, mock_llm_initializer):
    """Verify stateless chat works end-to-end with mock dependencies."""
    mock_builder = MagicMock()
    mock_builder.build_prompt.return_value = "System Instructions"
    mock_pb.return_value = mock_builder

    mock_llm = MagicMock()
    mock_response = MagicMock()
    mock_response.content = "Mocked stateless response"
    mock_llm.invoke.return_value = mock_response
    mock_llm_initializer.return_value = mock_llm

    result = await stateless_chat_logic(
        plan_number="123",
        plan_name="Test Plan",
        research_sections={"Summary": "This is a test section"},
        user_query="What is the plan?"
    )
    assert result == "Mocked stateless response"

@pytest.mark.asyncio
@patch("service.qna_service.GCSUtils")
async def test_start_session_file_not_found(mock_gcs_class):
    """Verify FileNotFoundError is raised if a GCS blob is missing."""
    mock_gcs = MagicMock()
    mock_gcs.blob_exists.return_value = False
    mock_gcs_class.return_value = mock_gcs

    with pytest.raises(FileNotFoundError):
        await start_session_logic("gs://some-bucket/nonexistent.json")

@pytest.mark.asyncio
@patch("service.qna_service.GCSUtils")
async def test_chat_logic_invalid_session_raises_key_error(mock_gcs_class):
    """Verify accessing an invalid session ID raises a KeyError."""
    mock_gcs = MagicMock()
    mock_gcs.blob_exists.return_value = False
    mock_gcs_class.return_value = mock_gcs
    with pytest.raises(KeyError):
        await chat_logic("invalid_session_id_xyz", "Hello?", plan_name="Test Plan")

@pytest.mark.asyncio
async def test_upload_json_logic_invalid_bytes():
    """Verify ValueError is raised when decoding malformed JSON bytes."""
    with pytest.raises(ValueError):
        await upload_json_logic(b"{invalid_json", "test.json")

@pytest.mark.asyncio
@patch("service.qna_service.GCSUtils")
async def test_upload_json_logic_success(mock_gcs_class):
    """Verify successful JSON upload path."""
    mock_gcs = MagicMock()
    mock_gcs.write_blob_json.return_value = "gs://mock-bucket/test.json"
    mock_gcs_class.return_value = mock_gcs

    target_path, uri = await upload_json_logic(b'{"key": "value"}', "test.json")
    assert target_path.endswith("test.json")
    assert uri == "gs://mock-bucket/test.json"

@pytest.mark.asyncio
async def test_close_session_invalid_raises_key_error():
    """Verify evicting an untracked session raises a KeyError."""
    with pytest.raises(KeyError):
        await close_session_logic("non_existent_session_to_close")

def test_load_and_cache_all_inbound_data():
    """Verify operational inbound categories are scanned, parsed, and cached."""
    mock_gcs = MagicMock()
    mock_bucket = MagicMock()
    blob1 = MagicMock()
    blob1.name = "dbaware_review_1111/inbound-data/gfms/findings.json"
    blob_policy = MagicMock()
    blob_policy.name = "dbaware_review_1111/inbound-data/policy/policy.json"

    mock_bucket.list_blobs.return_value = [blob1, blob_policy]
    mock_gcs.get_bucket.return_value = mock_bucket
    mock_gcs.read_blob_json.return_value = {"document_title": "GFMS Report", "nodes": []}

    cached = load_and_cache_all_inbound_data(mock_gcs, "1111")
    assert "gfms" in cached
    assert "policy" not in cached
    cached_again = load_and_cache_all_inbound_data(mock_gcs, "1111")
    assert cached_again == cached

def test_inbound_chat_context_uses_db_exclusions(monkeypatch):
    from service.context_builder import PLAN_INBOUND_CACHE
    from service.database_connector import DatabaseConnector

    PLAN_INBOUND_CACHE.pop("metadata-overlay", None)
    original = [
        {"responsePayload": [
            {"findingId": "F1", "findingTitle": "Hidden finding", "detail": "sensitive finding"},
            {"findingId": "F2", "findingTitle": "Visible finding", "detail": "public finding"},
        ]},
    ]
    mock_gcs = MagicMock()
    blob = MagicMock()
    blob.name = "dbaware_review_metadata-overlay/inbound-data/gfms/findings_details.json"
    mock_gcs.get_bucket.return_value.list_blobs.return_value = [blob]
    mock_gcs.read_blob_json.return_value = original
    metadata = {"documents": [{"filename": "findings_details.json", "sections": [
        {"section_id": "F1", "status": "excluded", "excluded": True},
    ]}]}
    monkeypatch.setattr(DatabaseConnector, "get_data_extraction_rows_for_plan", lambda self, *a, **k: {
        "findings_details": {"metadata": metadata}
    })

    cached = load_and_cache_all_inbound_data(mock_gcs, "metadata-overlay")
    assert "sensitive finding" not in cached["gfms"]
    assert "public finding" in cached["gfms"]
    assert len(original[0]["responsePayload"]) == 2
    assert not blob.name.endswith("policy.json")
    mock_gcs.write_blob_json.assert_not_called()
    PLAN_INBOUND_CACHE.pop("metadata-overlay", None)


def test_inbound_chat_context_db_outage_fails_closed(monkeypatch):
    from service.database_connector import DatabaseConnector

    mock_gcs = MagicMock()
    mock_gcs.get_bucket.return_value.list_blobs.return_value = []
    def unavailable(self, *args, **kwargs):
        raise ConnectionError("DB unavailable")
    monkeypatch.setattr(DatabaseConnector, "get_data_extraction_rows_for_plan", unavailable)
    assert load_and_cache_all_inbound_data(mock_gcs, "db-outage-chat") == {}
    assert "db-outage-chat" not in PLAN_INBOUND_CACHE

def test_database_connector_mock_mode(monkeypatch):
    """Verify DatabaseConnector returns mock document IDs when MOCK_SCOPING_DB is enabled."""
    from service.database_connector import DatabaseConnector
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    connector = DatabaseConnector()
    docs = connector.get_document_ids_for_scope_instance(1)
    assert docs["policy"] == [1, 2, 3]
    assert docs["kod"] == [121, 43, 27]
    assert docs["procedure"] == [13, 17, 194]

def test_database_connector_query_success(monkeypatch):
    """Verify DatabaseConnector live query extracts document_id list from dbaware_scoping.dbaware_review_documents."""
    from service.database_connector import DatabaseConnector
    monkeypatch.setenv("MOCK_SCOPING_DB", "false")
    connector = DatabaseConnector()

    mock_engine = MagicMock()
    mock_conn = MagicMock()
    mock_result = [(101,), (102,)]
    mock_conn.execute.return_value = mock_result
    mock_engine.connect.return_value.__enter__.return_value = mock_conn
    monkeypatch.setattr(connector, "_scope_column", lambda connection, table: "review_scope_instance_id")

    with patch.object(connector, "connect_to_database", return_value=mock_engine):
        docs = connector.get_document_ids_for_scope_instance(1)
        assert docs["policy"] == [101, 102]
        assert docs["kod"] == [101, 102]
        assert docs["procedure"] == [101, 102]

def test_database_connector_query_failure_fallback(monkeypatch):
    """Verify DatabaseConnector does not invent document IDs if the live DB fails."""
    from service.database_connector import DatabaseConnector
    monkeypatch.setenv("MOCK_SCOPING_DB", "false")
    connector = DatabaseConnector()

    mock_engine = MagicMock()
    mock_engine.connect.side_effect = RuntimeError("DB connection timeout")

    with patch.object(connector, "connect_to_database", return_value=mock_engine):
        docs = connector.get_document_ids_for_scope_instance(1)
        assert docs == {"policy": [], "kod": [], "procedure": []}

def test_database_connector_check_connection():
    """Verify check_connection returns True on success and False on failure."""
    from service.database_connector import DatabaseConnector
    connector = DatabaseConnector()
    mock_engine = MagicMock()
    mock_conn = MagicMock()
    mock_engine.connect.return_value.__enter__.return_value = mock_conn
    with patch.object(connector, "connect_to_database", return_value=mock_engine):
        assert connector.check_connection() is True
    mock_engine_err = MagicMock()
    mock_engine_err.connect.side_effect = RuntimeError("Failed")
    with patch.object(connector, "connect_to_database", return_value=mock_engine_err):
        assert connector.check_connection() is False




def test_agent_environment_and_runtime_helpers(monkeypatch):
    """Verify certificate auth and runtime detection helpers in agent and judge_agent."""
    import agent.agent as ag
    import agent.judge_agent as ja

    for mod in [ag, ja]:
        monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "true")
        assert mod._is_local_cert_auth_enabled() is True
        monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "false")
        assert mod._is_local_cert_auth_enabled() is False

        monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        assert mod._is_local_runtime() is False
        monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
        assert mod._is_local_runtime() is True

        mod._set_ssl_bundle_env("/tmp/test-ca-bundle.pem")
        assert os.environ.get("REQUESTS_CA_BUNDLE") is not None


def test_configure_certificate_validation_and_creation(tmp_path):
    """Verify configure_certificate error handling and bundle assembly."""
    import agent.agent as ag
    import agent.judge_agent as ja

    for mod in [ag, ja]:
        with pytest.raises(ValueError, match="No custom certificate paths"):
            mod.configure_certificate([])

        with pytest.raises(FileNotFoundError):
            mod.configure_certificate([str(tmp_path / "non_existent.pem")])

        bad_cert = tmp_path / f"bad_cert_{mod.__name__}.txt"
        bad_cert.write_text("INVALID NON-PEM CONTENT", encoding="utf-8")
        with pytest.raises(ValueError, match="Certificate file is not PEM format"):
            mod.configure_certificate([str(bad_cert)])

        good_cert = tmp_path / f"valid_cert_{mod.__name__}.crt"
        good_cert.write_text("-----BEGIN CERTIFICATE-----\nABC123==\n-----END CERTIFICATE-----", encoding="utf-8")
        bundle_path = mod.configure_certificate([str(good_cert)])
        assert os.path.exists(bundle_path)
        assert "combined-ca-bundle.pem" in bundle_path


def test_configure_certificate_once_paths(monkeypatch, tmp_path):
    """Verify _configure_certificate_once handles Kubernetes and local development branches."""
    import agent.agent as ag
    import agent.judge_agent as ja

    for mod in [ag, ja]:
        # 1. Already configured branch
        mod._CERTIFICATE_CONFIGURED = True
        mod._configure_certificate_once()

        # 2. Kubernetes runtime with CA_BUNDLE_PATH
        mod._CERTIFICATE_CONFIGURED = False
        monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        monkeypatch.setenv("CA_BUNDLE_PATH", "/etc/ssl/certs/ca-certificates.crt")
        mod._configure_certificate_once()
        assert mod._CERTIFICATE_CONFIGURED is True

        # 3. Kubernetes runtime without CA_BUNDLE_PATH
        mod._CERTIFICATE_CONFIGURED = False
        monkeypatch.delenv("CA_BUNDLE_PATH", raising=False)
        mod._configure_certificate_once()
        assert mod._CERTIFICATE_CONFIGURED is True

        # 4. Local runtime with cert auth disabled
        mod._CERTIFICATE_CONFIGURED = False
        monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
        monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "false")
        mod._configure_certificate_once()
        assert mod._CERTIFICATE_CONFIGURED is True

        # 5. Local runtime, cert auth enabled, no cert path provided
        mod._CERTIFICATE_CONFIGURED = False
        monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "true")
        monkeypatch.delenv("CUSTOM_CERT_PATHS", raising=False)
        monkeypatch.delenv("CUSTOM_CERT_PATH", raising=False)
        mod._configure_certificate_once()
        assert mod._CERTIFICATE_CONFIGURED is True

        # 6. Local runtime, cert auth enabled, valid cert provided
        mod._CERTIFICATE_CONFIGURED = False
        valid_cert = tmp_path / f"cert_once_{mod.__name__}.crt"
        valid_cert.write_text("-----BEGIN CERTIFICATE-----\nXYZ987==\n-----END CERTIFICATE-----", encoding="utf-8")
        monkeypatch.setenv("CUSTOM_CERT_PATHS", str(valid_cert))
        mod._configure_certificate_once()
        assert mod._CERTIFICATE_CONFIGURED is True


def test_google_oauth_token_provider():
    """Verify GoogleOAuthTokenProvider refreshes invalid credentials and returns bearer token."""
    from agent.agent import GoogleOAuthTokenProvider
    with patch("agent.agent.default") as mock_default, patch("agent.agent.google.auth.transport.requests.Request"):
        mock_creds = MagicMock()
        mock_creds.valid = False
        mock_creds.token = "mock-refreshed-oauth-token"
        mock_default.return_value = (mock_creds, "mock-project-id")

        provider = GoogleOAuthTokenProvider()
        token = provider.token
        assert token == "mock-refreshed-oauth-token"
        assert mock_creds.refresh.called


@patch("agent.agent.initialize_gemini_model")
@patch("agent.agent.PromptBuilder")
def test_run_agent_pipeline(mock_pb, mock_init_gemini):
    """Verify run_agent compiles prompts and returns extracted response text."""
    from agent.agent import run_agent
    mock_builder = MagicMock()
    mock_builder.build_prompt.return_value = "System Instruction Content"
    mock_pb.return_value = mock_builder

    mock_llm = MagicMock()
    mock_resp = MagicMock()
    mock_resp.text = "Generated Agent Response"
    mock_llm.invoke.return_value = mock_resp
    mock_init_gemini.return_value = mock_llm

    mock_env = MagicMock()
    result = run_agent("test query", mock_env)
    assert result == "Generated Agent Response"