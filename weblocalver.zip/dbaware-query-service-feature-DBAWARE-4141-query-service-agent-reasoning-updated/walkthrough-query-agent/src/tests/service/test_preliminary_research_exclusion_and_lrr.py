import pytest
from google.api_core.exceptions import NotFound

from agent_helper.env_config import EnvironmentConfig
from service import database_connector as dbc
from service import document_chat_workflow as dcw
from service import document_exclusion_orchestrator as deo
from service import document_inclusion_orchestrator as dio
from service import document_service as ds
from service.request import (
    DocumentActionDecisionRequest,
    DocumentActionExecutionItem,
    DocumentActionExecutionRequest,
    DocumentActionPlanResponse,
    DocumentActionPlanStep,
    DocumentExecutionAction,
    DocumentExecutionRequest,
    DocumentInclusionExecutionAction,
    DocumentInclusionExecutionRequest,
)


def _reset_mock_db(plan_number: str):
    dbc._MOCK_DATA_EXTRACTION_STORE.pop(str(plan_number), None)
    dbc._MOCK_REVIEW_DOCUMENTS_STORE.pop(str(plan_number), None)


def test_lrr_aliases_and_affected_sections_computation():
    assert dbc.normalize_scoping_source("Laws, Rules, and Regulations") == "lrr"
    assert dbc.normalize_scoping_source("internet_search_data_enriched") == "lrr"
    assert dbc.source_to_db_data_source("lrr") == "lrr"

    assert dbc.compute_affected_preliminary_research_sections(["gfms"]) == ["broad_scope"]
    assert dbc.compute_affected_preliminary_research_sections(["historical_scoping_document"]) == [
        "past_review",
        "broad_scope",
    ]
    assert dbc.compute_affected_preliminary_research_sections(["policy", "lrr"]) == [
        "policy_regulation",
        "broad_scope",
    ]
    assert dbc.compute_affected_preliminary_research_sections(["historical_scoping_document", "lrr", "gfms"]) == [
        "past_review",
        "policy_regulation",
        "broad_scope",
    ]
    assert dbc.compute_affected_preliminary_research_sections([]) == []


def test_mutate_review_data_extraction_for_lrr_mandates(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99001"
    _reset_mock_db(plan)
    db = dbc.DatabaseConnector(EnvironmentConfig())

    res = db.mutate_data_extraction_metadata(
        plan_number=plan,
        document_type="lrr",
        action="exclude",
        title="FINRA Rule 3110",
        section_id="2",
        section_title="FINRA Rule 3110",
        actor="tester",
    )
    assert res["updated"] is True
    assert res["data_source"] == "lrr"
    row = db.get_data_extraction_rows_for_plan(plan, data_sources=["lrr"])["lrr"]
    doc = row["metadata"]["documents"][0]
    assert doc["filename"] == "internet_search_data_enriched.json"
    assert doc["sections"][0]["node_id"] == "lrr:mandate:2"
    assert doc["sections"][0]["excluded"] is True
    assert doc["sections"][0]["status"] == "excluded"

    res_inc = db.mutate_data_extraction_metadata(
        plan_number=plan,
        document_type="lrr",
        action="include",
        title="FINRA Rule 3110",
        node_id="lrr:mandate:2",
        actor="tester",
    )
    assert res_inc["updated"] is True
    row_after = db.get_data_extraction_rows_for_plan(plan, data_sources=["lrr"])["lrr"]
    assert row_after["metadata"]["documents"][0]["sections"][0]["excluded"] is False
    assert row_after["metadata"]["documents"][0]["sections"][0]["status"] == "active"


@pytest.mark.asyncio
async def test_list_documents_db_first_with_sections_and_gcs_fallback(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99002"
    _reset_mock_db(plan)
    db = dbc.DatabaseConnector(EnvironmentConfig())
    db.mutate_data_extraction_metadata(
        plan_number=plan,
        document_type="gfms",
        action="include",
        title="GFMS Findings Details",
        filename="findings_details.json",
        sections=[
            {
                "section_id": "F-100",
                "section_title": "Trade Surveillance Finding",
                "node_id": "gfms:finding:F-100",
                "status": "active",
                "excluded": False,
            }
        ],
    )

    class _FakeBlob:
        def __init__(self, name, exists=True):
            self.name = name
            self._exists = exists

        def exists(self):
            return self._exists

    class _FakeBucket:
        def list_blobs(self, prefix=""):
            if "dbaware/" in prefix:
                return [
                    _FakeBlob(f"dbaware_review_{plan}/inbound-data/dbaware/plan_details.json"),
                    _FakeBlob(f"dbaware_review_{plan}/inbound-data/dbaware/historical_plan_details.json"),
                ]
            if "lrr/" in prefix:
                return [_FakeBlob(f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json")]
            if "policy/relevant_kod/" in prefix:
                raise NotFound("missing kod folder")
            return []

        def blob(self, path):
            return _FakeBlob(path, exists=False)

    class _FakeGCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            return _FakeBucket()

        def blob_exists(self, path):
            return False

        def read_blob_json(self, path):
            if path.endswith("historical_plan_details.json"):
                return [{"Plan Item Number": "2022-01", "Plan Item Title": "Prior Equity Swap Review"}]
            return []

        def write_blob_json(self, path, payload):
            return f"gs://{self.bucket_name}/{path}"

    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: _FakeGCS())

    all_res = await ds.list_all_documents(plan, EnvironmentConfig())
    assert len(all_res["document_groups"]) == 5

    gfms_group = next(g for g in all_res["document_groups"] if g["document_type"] == "gfms")
    assert gfms_group["total_count"] == 1
    assert gfms_group["documents"][0]["file_name"] == "findings_details.json"
    assert gfms_group["documents"][0]["sections"][0]["node_id"] == "gfms:finding:F-100"

    hist_group = next(g for g in all_res["document_groups"] if g["document_type"] == "historical_scoping_document")
    # plan_details.json must be excluded by _is_allowed_gcs_fallback_blob
    assert [d["file_name"] for d in hist_group["documents"]] == ["historical_plan_details.json"]
    assert hist_group["documents"][0]["sections"][0]["node_id"] == "historical_plan:2022-01"

    # NotFound on missing folder returns empty documents list cleanly
    kod_group = next(g for g in all_res["document_groups"] if g["document_type"] == "kod")
    assert kod_group["documents"] == []

    # Direct LRR listing works
    lrr_res = await ds.list_documents_from_bucket(plan, "lrr", EnvironmentConfig())
    assert lrr_res["documents"][0]["file_name"] == "internet_search_data_enriched.json"


@pytest.mark.asyncio
async def test_soft_exclude_restore_bulk_and_affected_sections(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99003"
    _reset_mock_db(plan)

    blob_deleted_called = []

    class _Blob:
        def __init__(self, name, exists=True):
            self.name = name
            self._exists = exists

        def exists(self):
            return self._exists

        def delete(self):
            blob_deleted_called.append(self.name)
            self._exists = False

    blobs = {
        f"dbaware_review_{plan}/inbound-data/policy/relevant_kod/kod20.json": {
            "document_id": "20",
            "document_title": "KOD 20",
            "nodes": [{"section_id": "2.1", "title": "Scope", "node_id": "20:sec:2.1"}],
        },
        f"dbaware_review_{plan}/inbound-data/gfms/findings_details.json": [
            {"responsePayload": [{"findingId": "F-1", "findingTitle": "Finding One"}]}
        ],
    }

    class _FakeGCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            class _B:
                def blob(self, path):
                    return _Blob(path, exists=(path in blobs))

                def list_blobs(self, prefix=""):
                    return [_Blob(p, True) for p in blobs if p.startswith(prefix)]

            return _B()

        def blob_exists(self, path):
            return path in blobs

        def read_blob_json(self, path):
            return blobs[path]

        def write_blob_json(self, path, payload):
            blobs[path] = payload
            return f"gs://{self.bucket_name}/{path}"

    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: _FakeGCS())

    bulk_res = await ds.delete_documents_bulk(
        plan,
        [
            {
                "document_type": "kod",
                "items": [
                    {
                        "file_name": "kod20.json",
                        "document_title": "KOD 20",
                        "document_id": "20",
                        "section_id": "2.1",
                        "section_title": "Scope",
                        "node_id": "20:sec:2.1",
                        "action": "exclude",
                    }
                ],
            },
            {
                "document_type": "gfms",
                "items": [
                    {
                        "file_name": "findings_details.json",
                        "document_title": "GFMS Findings Details",
                        "document_id": "findings_details",
                        "sections": [
                            {"section_id": "F-1", "section_title": "Finding One", "node_id": "gfms:finding:F-1"}
                        ],
                    }
                ],
            },
        ],
        EnvironmentConfig(),
    )

    assert blob_deleted_called == []
    assert bulk_res["total_deleted"] == 2
    assert bulk_res["affected_sections"] == ["policy_regulation", "broad_scope"]
    assert blobs[f"dbaware_review_{plan}/inbound-data/policy/relevant_kod/kod20.json"]["nodes"][0]["excluded"] is True
    assert blobs[f"dbaware_review_{plan}/inbound-data/gfms/findings_details.json"][0]["responsePayload"][0]["excluded"] is True

    # Restore via action='include'
    restore_res = await ds.delete_documents_bulk(
        plan,
        [
            {
                "document_type": "kod",
                "items": [
                    {
                        "file_name": "kod20.json",
                        "document_title": "KOD 20",
                        "document_id": "20",
                        "section_id": "2.1",
                        "node_id": "20:sec:2.1",
                        "action": "include",
                    }
                ],
            }
        ],
        EnvironmentConfig(),
    )
    assert restore_res["total_deleted"] == 1
    assert blobs[f"dbaware_review_{plan}/inbound-data/policy/relevant_kod/kod20.json"]["nodes"][0]["excluded"] is False


@pytest.mark.asyncio
async def test_lrr_orchestrator_and_workflow_execution_return_affected_sections(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99004"
    _reset_mock_db(plan)

    blobs = {
        f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json": [
            {
                "Risk Name": "Regulatory Risk",
                "Mandates": [
                    {"Regulatory Mandate": "FINRA 3110", "Evidence": []},
                    {"Regulatory Mandate": "SEC 17a-4", "Evidence": []},
                ],
            }
        ]
    }

    class _FakeGCS:
        bucket_name = "test-bucket"

        def blob_exists(self, path):
            return path in blobs

        def read_blob_json(self, path):
            return blobs[path]

        def write_blob_json(self, path, payload):
            blobs[path] = payload
            return f"gs://{self.bucket_name}/{path}"

    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: _FakeGCS())
    monkeypatch.setattr(dio, "GCSUtils", lambda _cfg=None: _FakeGCS())
    monkeypatch.setattr(dcw, "GCSUtils", lambda _cfg=None: _FakeGCS())

    entries = deo._extract_normalized_registry_entries(
        blobs[f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json"],
        document_type="lrr",
    )
    assert len(entries) == 3
    assert entries[0]["sections"][1]["node_id"] == "lrr:mandate:2"

    ex_resp = await deo.execute_document_exclusion_plan_logic(
        DocumentExecutionRequest(
            plan_number=plan,
            actions=[
                DocumentExecutionAction(
                    action="exclude",
                    document_type="lrr",
                    title="SEC 17a-4",
                    section_id="2",
                    node_id="lrr:mandate:2",
                )
            ],
            approved_by="auditor",
        )
    )
    assert ex_resp.registry_updated is True
    assert ex_resp.affected_sections == ["policy_regulation", "broad_scope"]
    assert blobs[f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json"][0]["Mandates"][1]["excluded"] is True

    inc_resp = await dio.execute_document_inclusion_plan_logic(
        DocumentInclusionExecutionRequest(
            plan_number=plan,
            actions=[
                DocumentInclusionExecutionAction(
                    action="include",
                    document_type="lrr",
                    title="SEC 17a-4",
                    section_id="2",
                    node_id="lrr:mandate:2",
                )
            ],
            approved_by="auditor",
        )
    )
    assert inc_resp.registry_updated is True
    assert inc_resp.affected_sections == ["policy_regulation", "broad_scope"]
    assert blobs[f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json"][0]["Mandates"][1]["excluded"] is False

    # Chat workflow heuristic extract for LRR & decision response affected_sections
    heuristic = dcw._heuristic_extract("exclude regulation SEC 17a-4", {})
    assert heuristic and heuristic[0].document_type == "lrr"

    async def _fake_translate(plan_obj, approved_by=None):
        return DocumentActionExecutionRequest(
            plan_number=plan,
            plan_id="p1",
            approved_by=approved_by,
            actions=[
                DocumentActionExecutionItem(
                    action="exclude",
                    document_type="lrr",
                    title="SEC 17a-4",
                    section_id="2",
                    node_id="lrr:mandate:2",
                )
            ],
        )

    monkeypatch.setattr(dcw, "translate_plan_to_execution_json", _fake_translate)
    plan_obj = DocumentActionPlanResponse(
        plan_id="p1",
        plan_number=plan,
        steps=[DocumentActionPlanStep(step=1, action="exclude", document_type="lrr", title="SEC 17a-4")],
    )
    stored_plan_id = dcw.store_pending_plan(plan_obj, "exclude regulation SEC 17a-4")
    decision = await dcw.decide_document_action_plan(plan, "approve", stored_plan_id, approved_by="auditor")
    assert decision.status == "executed"
    assert decision.affected_sections == ["policy_regulation", "broad_scope"]


def test_heuristic_extract_parses_at_mention_annotations():
    snapshot = {
        "policy": [
            {
                "title": "Access Control Policy",
                "filename": "policy_1.json",
                "document_id": "1",
                "status": "active",
                "sections": [
                    {
                        "section_id": "2.1",
                        "section_title": "Password Rules",
                        "node_id": "1:sec:2.1",
                        "status": "active",
                    }
                ],
            }
        ],
        "gfms": [
            {
                "title": "Finding F-10",
                "filename": "findings_details.json",
                "document_id": "F-10",
                "status": "active",
                "sections": [],
            }
        ],
    }

    assert dcw.looks_like_document_request("Exclude @[Policies: Access Control Policy]") is True
    assert dcw.looks_like_document_request("What does @[Policies: Access Control Policy] say?") is False

    whole_doc = dcw._heuristic_extract("Exclude @[Policies: Access Control Policy]", snapshot)
    assert len(whole_doc) == 1
    assert whole_doc[0].action == "exclude"
    assert whole_doc[0].document_type == "policy"
    assert whole_doc[0].title == "Access Control Policy"
    assert whole_doc[0].section_id is None

    multi = dcw._heuristic_extract(
        "Remove @[GFMS Data: Finding F-10] and @[Policies: Access Control Policy > Section 2.1: Password Rules]",
        snapshot,
    )
    assert len(multi) == 2
    assert multi[0].document_type == "gfms"
    assert multi[0].title == "Finding F-10"
    assert multi[1].document_type == "policy"
    assert multi[1].title == "Access Control Policy"
    assert multi[1].section_id == "2.1"
    assert multi[1].section_title == "Password Rules"
    assert multi[1].node_id == "1:sec:2.1"

    shorthand = dcw._heuristic_extract("Include @Policy: Information Security Policy", snapshot)
    assert len(shorthand) == 1
    assert shorthand[0].action == "include"
    assert shorthand[0].document_type == "policy"
    assert shorthand[0].title == "Information Security Policy"
