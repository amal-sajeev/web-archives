import pytest
from google.api_core.exceptions import NotFound

from agent_helper.env_config import EnvironmentConfig
from service import database_connector as dbc
from service import document_chat_workflow as dcw
from service import document_exclusion_orchestrator as deo
from service import document_inclusion_orchestrator as dio
from service import document_service as ds
from service.request import (
    DocumentActionDecisionRequest,
    DocumentActionExecutionItem,
    DocumentActionExecutionRequest,
    DocumentActionPlanResponse,
    DocumentActionPlanStep,
    DocumentExecutionAction,
    DocumentExecutionRequest,
    DocumentInclusionExecutionAction,
    DocumentInclusionExecutionRequest,
)


def _reset_mock_db(plan_number: str):
    dbc._MOCK_DATA_EXTRACTION_STORE.pop(str(plan_number), None)
    dbc._MOCK_REVIEW_DOCUMENTS_STORE.pop(str(plan_number), None)


def test_lrr_aliases_and_affected_sections_computation():
    assert dbc.normalize_scoping_source("Laws, Rules, and Regulations") == "lrr"
    assert dbc.normalize_scoping_source("internet_search_data_enriched") == "lrr"
    assert dbc.source_to_db_data_source("lrr") == "lrr"

    assert dbc.compute_affected_preliminary_research_sections(["gfms"]) == ["broad_scope"]
    assert dbc.compute_affected_preliminary_research_sections(["historical_scoping_document"]) == [
        "past_review",
        "broad_scope",
    ]
    assert dbc.compute_affected_preliminary_research_sections(["policy", "lrr"]) == [
        "policy_regulation",
        "broad_scope",
    ]
    assert dbc.compute_affected_preliminary_research_sections(["historical_scoping_document", "lrr", "gfms"]) == [
        "past_review",
        "policy_regulation",
        "broad_scope",
    ]
    assert dbc.compute_affected_preliminary_research_sections([]) == []


def test_mutate_review_data_extraction_for_lrr_mandates(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99001"
    _reset_mock_db(plan)
    db = dbc.DatabaseConnector(EnvironmentConfig())

    res = db.mutate_data_extraction_metadata(
        plan_number=plan,
        document_type="lrr",
        action="exclude",
        title="FINRA Rule 3110",
        section_id="2",
        section_title="FINRA Rule 3110",
        actor="tester",
    )
    assert res["updated"] is True
    assert res["data_source"] == "lrr"
    row = db.get_data_extraction_rows_for_plan(plan, data_sources=["lrr"])["lrr"]
    doc = row["metadata"]["documents"][0]
    assert doc["filename"] == "internet_search_data_enriched.json"
    assert doc["sections"][0]["node_id"] == "lrr:mandate:2"
    assert doc["sections"][0]["excluded"] is True
    assert doc["sections"][0]["status"] == "excluded"

    res_inc = db.mutate_data_extraction_metadata(
        plan_number=plan,
        document_type="lrr",
        action="include",
        title="FINRA Rule 3110",
        node_id="lrr:mandate:2",
        actor="tester",
    )
    assert res_inc["updated"] is True
    row_after = db.get_data_extraction_rows_for_plan(plan, data_sources=["lrr"])["lrr"]
    assert row_after["metadata"]["documents"][0]["sections"][0]["excluded"] is False
    assert row_after["metadata"]["documents"][0]["sections"][0]["status"] == "active"


@pytest.mark.asyncio
async def test_list_documents_db_first_with_sections_and_gcs_fallback(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99002"
    _reset_mock_db(plan)
    db = dbc.DatabaseConnector(EnvironmentConfig())
    db.mutate_data_extraction_metadata(
        plan_number=plan,
        document_type="gfms",
        action="include",
        title="GFMS Findings Details",
        filename="findings_details.json",
        sections=[
            {
                "section_id": "F-100",
                "section_title": "Trade Surveillance Finding",
                "node_id": "gfms:finding:F-100",
                "status": "active",
                "excluded": False,
            }
        ],
    )

    class _FakeBlob:
        def __init__(self, name, exists=True):
            self.name = name
            self._exists = exists

        def exists(self):
            return self._exists

    class _FakeBucket:
        def list_blobs(self, prefix=""):
            if "dbaware/" in prefix:
                return [
                    _FakeBlob(f"dbaware_review_{plan}/inbound-data/dbaware/plan_details.json"),
                    _FakeBlob(f"dbaware_review_{plan}/inbound-data/dbaware/historical_plan_details.json"),
                ]
            if "lrr/" in prefix:
                return [_FakeBlob(f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json")]
            if "policy/relevant_kod/" in prefix:
                raise NotFound("missing kod folder")
            return []

        def blob(self, path):
            return _FakeBlob(path, exists=False)

    class _FakeGCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            return _FakeBucket()

        def blob_exists(self, path):
            return False

        def read_blob_json(self, path):
            if path.endswith("historical_plan_details.json"):
                return [{"Plan Item Number": "2022-01", "Plan Item Title": "Prior Equity Swap Review"}]
            return []

        def write_blob_json(self, path, payload):
            return f"gs://{self.bucket_name}/{path}"

    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: _FakeGCS())

    all_res = await ds.list_all_documents(plan, EnvironmentConfig())
    assert len(all_res["document_groups"]) == 6
    assert any(g["document_type"] == "lrr" for g in all_res["document_groups"])

    gfms_group = next(g for g in all_res["document_groups"] if g["document_type"] == "gfms")
    assert gfms_group["total_count"] == 1
    assert gfms_group["documents"][0]["file_name"] == "findings_details.json"
    assert gfms_group["documents"][0]["sections"][0]["node_id"] == "gfms:finding:F-100"

    hist_group = next(g for g in all_res["document_groups"] if g["document_type"] == "historical_scoping_document")
    # plan_details.json must be excluded by _is_allowed_gcs_fallback_blob
    assert [d["file_name"] for d in hist_group["documents"]] == ["historical_plan_details.json"]
    assert hist_group["documents"][0]["sections"][0]["node_id"] == "historical_plan:2022-01"

    # NotFound on missing folder returns empty documents list cleanly
    kod_group = next(g for g in all_res["document_groups"] if g["document_type"] == "kod")
    assert kod_group["documents"] == []

    # Direct LRR listing works
    lrr_res = await ds.list_documents_from_bucket(plan, "lrr", EnvironmentConfig())
    assert lrr_res["documents"][0]["file_name"] == "internet_search_data_enriched.json"


@pytest.mark.asyncio
async def test_soft_exclude_restore_bulk_and_affected_sections(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99003"
    _reset_mock_db(plan)

    blob_deleted_called = []

    class _Blob:
        def __init__(self, name, exists=True):
            self.name = name
            self._exists = exists

        def exists(self):
            return self._exists

        def delete(self):
            blob_deleted_called.append(self.name)
            self._exists = False

    blobs = {
        f"dbaware_review_{plan}/inbound-data/policy/relevant_kod/kod20.json": {
            "document_id": "20",
            "document_title": "KOD 20",
            "nodes": [{"section_id": "2.1", "title": "Scope", "node_id": "20:sec:2.1"}],
        },
        f"dbaware_review_{plan}/inbound-data/gfms/findings_details.json": [
            {"responsePayload": [{"findingId": "F-1", "findingTitle": "Finding One"}]}
        ],
    }

    class _FakeGCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            class _B:
                def blob(self, path):
                    return _Blob(path, exists=(path in blobs))

                def list_blobs(self, prefix=""):
                    return [_Blob(p, True) for p in blobs if p.startswith(prefix)]

            return _B()

        def blob_exists(self, path):
            return path in blobs

        def read_blob_json(self, path):
            return blobs[path]

        def write_blob_json(self, path, payload):
            blobs[path] = payload
            return f"gs://{self.bucket_name}/{path}"

    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: _FakeGCS())

    bulk_res = await ds.delete_documents_bulk(
        plan,
        [
            {
                "document_type": "kod",
                "items": [
                    {
                        "file_name": "kod20.json",
                        "document_title": "KOD 20",
                        "document_id": "20",
                        "section_id": "2.1",
                        "section_title": "Scope",
                        "node_id": "20:sec:2.1",
                        "action": "exclude",
                    }
                ],
            },
            {
                "document_type": "gfms",
                "items": [
                    {
                        "file_name": "findings_details.json",
                        "document_title": "GFMS Findings Details",
                        "document_id": "findings_details",
                        "sections": [
                            {"section_id": "F-1", "section_title": "Finding One", "node_id": "gfms:finding:F-1"}
                        ],
                    }
                ],
            },
        ],
        EnvironmentConfig(),
    )

    assert blob_deleted_called == []
    assert bulk_res["total_deleted"] == 2
    assert bulk_res["affected_sections"] == ["policy_regulation", "broad_scope"]
    assert "excluded" not in blobs[f"dbaware_review_{plan}/inbound-data/policy/relevant_kod/kod20.json"]["nodes"][0]
    assert "excluded" not in blobs[f"dbaware_review_{plan}/inbound-data/gfms/findings_details.json"][0]["responsePayload"][0]
    db = dbc.DatabaseConnector(EnvironmentConfig())
    assert db.get_data_extraction_rows_for_plan(plan, ["kod"])["kod"]["metadata"]["documents"][0]["sections"][0]["excluded"] is True
    assert db.get_data_extraction_rows_for_plan(plan, ["findings_details"])["findings_details"]["metadata"]["documents"][0]["sections"][0]["excluded"] is True

    # Restore via action='include'
    restore_res = await ds.delete_documents_bulk(
        plan,
        [
            {
                "document_type": "kod",
                "items": [
                    {
                        "file_name": "kod20.json",
                        "document_title": "KOD 20",
                        "document_id": "20",
                        "section_id": "2.1",
                        "node_id": "20:sec:2.1",
                        "action": "include",
                    }
                ],
            }
        ],
        EnvironmentConfig(),
    )
    assert restore_res["total_deleted"] == 1
    assert "excluded" not in blobs[f"dbaware_review_{plan}/inbound-data/policy/relevant_kod/kod20.json"]["nodes"][0]
    assert db.get_data_extraction_rows_for_plan(plan, ["kod"])["kod"]["metadata"]["documents"][0]["sections"][0]["excluded"] is False


@pytest.mark.asyncio
async def test_exclusion_db_failure_does_not_change_raw_gcs_or_report_success(monkeypatch):
    plan = "99006"
    path = f"dbaware_review_{plan}/inbound-data/gfms/findings_details.json"
    writes = []

    class Blob:
        def exists(self):
            return True

    class GCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            return self

        def blob(self, path):
            return Blob()

        def list_blobs(self, prefix=""):
            return []

        def blob_exists(self, blob_path):
            return blob_path == path

        def read_blob_json(self, path):
            return [{"findingId": "F1"}]

        def write_blob_json(self, path, payload):
            writes.append(path)

    class BrokenDB:
        def __init__(self, *args):
            pass

        def get_data_extraction_rows_for_plan(self, *args, **kwargs):
            return {}

        def mutate_data_extraction_metadata(self, *args, **kwargs):
            raise RuntimeError("DB offline")

    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: GCS())
    monkeypatch.setattr(ds, "DatabaseConnector", BrokenDB)
    result = await ds.delete_documents(plan, "gfms", ["findings_details.json"], EnvironmentConfig())
    assert result["files_failed"] == ["findings_details.json"]
    assert result["total_deleted"] == 0
    assert writes == []

    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: GCS())
    monkeypatch.setattr(deo, "DatabaseConnector", BrokenDB)
    approved = await deo.execute_document_exclusion_plan_logic(
        DocumentExecutionRequest(
            plan_number=plan, approved_by="auditor",
            actions=[DocumentExecutionAction(action="exclude", document_type="gfms", title="F1", section_id="F1")],
        )
    )
    assert approved.status == "error"
    assert approved.registry_updated is False
    assert writes == []


@pytest.mark.asyncio
async def test_lrr_orchestrator_and_workflow_execution_return_affected_sections(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    plan = "99004"
    _reset_mock_db(plan)

    blobs = {
        f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json": [
            {
                "Risk Name": "Regulatory Risk",
                "Mandates": [
                    {"Regulatory Mandate": "FINRA 3110", "Evidence": []},
                    {"Regulatory Mandate": "SEC 17a-4", "Evidence": []},
                ],
            }
        ]
    }

    class _FakeGCS:
        bucket_name = "test-bucket"

        def blob_exists(self, path):
            return path in blobs

        def read_blob_json(self, path):
            return blobs[path]

        def write_blob_json(self, path, payload):
            blobs[path] = payload
            return f"gs://{self.bucket_name}/{path}"

    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: _FakeGCS())
    monkeypatch.setattr(dio, "GCSUtils", lambda _cfg=None: _FakeGCS())
    monkeypatch.setattr(dcw, "GCSUtils", lambda _cfg=None: _FakeGCS())

    entries = deo._extract_normalized_registry_entries(
        blobs[f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json"],
        document_type="lrr",
    )
    assert len(entries) == 3
    assert entries[0]["sections"][1]["node_id"] == "lrr:mandate:2"

    ex_resp = await deo.execute_document_exclusion_plan_logic(
        DocumentExecutionRequest(
            plan_number=plan,
            actions=[
                DocumentExecutionAction(
                    action="exclude",
                    document_type="lrr",
                    title="SEC 17a-4",
                    section_id="2",
                    node_id="lrr:mandate:2",
                )
            ],
            approved_by="auditor",
        )
    )
    assert ex_resp.registry_updated is True
    assert ex_resp.affected_sections == ["policy_regulation", "broad_scope"]
    assert "excluded" not in blobs[f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json"][0]["Mandates"][1]
    db = dbc.DatabaseConnector(EnvironmentConfig())
    assert db.get_data_extraction_rows_for_plan(plan, ["lrr"])["lrr"]["metadata"]["documents"][0]["sections"][0]["excluded"] is True

    inc_resp = await dio.execute_document_inclusion_plan_logic(
        DocumentInclusionExecutionRequest(
            plan_number=plan,
            actions=[
                DocumentInclusionExecutionAction(
                    action="include",
                    document_type="lrr",
                    title="SEC 17a-4",
                    section_id="2",
                    node_id="lrr:mandate:2",
                )
            ],
            approved_by="auditor",
        )
    )
    assert inc_resp.registry_updated is True
    assert inc_resp.affected_sections == ["policy_regulation", "broad_scope"]
    assert "excluded" not in blobs[f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json"][0]["Mandates"][1]
    assert db.get_data_extraction_rows_for_plan(plan, ["lrr"])["lrr"]["metadata"]["documents"][0]["sections"][0]["excluded"] is False

    # Chat workflow heuristic extract for LRR & decision response affected_sections
    heuristic = dcw._heuristic_extract("exclude regulation SEC 17a-4", {})
    assert heuristic and heuristic[0].document_type == "lrr"

    async def _fake_translate(plan_obj, approved_by=None):
        return DocumentActionExecutionRequest(
            plan_number=plan,
            plan_id="p1",
            approved_by=approved_by,
            actions=[
                DocumentActionExecutionItem(
                    action="exclude",
                    document_type="lrr",
                    title="SEC 17a-4",
                    section_id="2",
                    node_id="lrr:mandate:2",
                )
            ],
        )

    monkeypatch.setattr(dcw, "translate_plan_to_execution_json", _fake_translate)
    plan_obj = DocumentActionPlanResponse(
        plan_id="p1",
        plan_number=plan,
        steps=[DocumentActionPlanStep(step=1, action="exclude", document_type="lrr", title="SEC 17a-4")],
    )
    stored_plan_id = dcw.store_pending_plan(plan_obj, "exclude regulation SEC 17a-4")
    decision = await dcw.decide_document_action_plan(plan, "approve", stored_plan_id, approved_by="auditor")
    assert decision.status == "executed"
    assert decision.affected_sections == ["policy_regulation", "broad_scope"]


def test_heuristic_extract_parses_at_mention_annotations():
    snapshot = {
        "policy": [
            {
                "title": "Access Control Policy",
                "filename": "policy_1.json",
                "document_id": "1",
                "status": "active",
                "sections": [
                    {
                        "section_id": "2.1",
                        "section_title": "Password Rules",
                        "node_id": "1:sec:2.1",
                        "status": "active",
                    }
                ],
            }
        ],
        "gfms": [
            {
                "title": "Finding F-10",
                "filename": "findings_details.json",
                "document_id": "F-10",
                "status": "active",
                "sections": [],
            }
        ],
    }

    assert dcw.looks_like_document_request("Exclude @[Policies: Access Control Policy]") is True
    assert dcw.looks_like_document_request("What does @[Policies: Access Control Policy] say?") is False

    whole_doc = dcw._heuristic_extract("Exclude @[Policies: Access Control Policy]", snapshot)
    assert len(whole_doc) == 1
    assert whole_doc[0].action == "exclude"
    assert whole_doc[0].document_type == "policy"
    assert whole_doc[0].title == "Access Control Policy"
    assert whole_doc[0].section_id is None

    multi = dcw._heuristic_extract(
        "Remove @[GFMS Data: Finding F-10] and @[Policies: Access Control Policy > Section 2.1: Password Rules]",
        snapshot,
    )
    assert len(multi) == 2
    assert multi[0].document_type == "gfms"
    assert multi[0].title == "Finding F-10"
    assert multi[1].document_type == "policy"
    assert multi[1].title == "Access Control Policy"
    assert multi[1].section_id == "2.1"
    assert multi[1].section_title == "Password Rules"
    assert multi[1].node_id == "1:sec:2.1"

    shorthand = dcw._heuristic_extract("Include @Policy: Information Security Policy", snapshot)
    assert len(shorthand) == 1
    assert shorthand[0].action == "include"
    assert shorthand[0].document_type == "policy"
    assert shorthand[0].title == "Information Security Policy"


@pytest.mark.asyncio
async def test_list_documents_uses_sources_aggregate_fallback_and_ensures_scope_row(monkeypatch):
    from unittest.mock import MagicMock

    plan = "99009"
    reg_blob = f"dbaware_review_{plan}/inbound-data/policy/relevant_policy.json"

    class _EmptyBucket:
        def list_blobs(self, prefix=""):
            return []

    class _RegGCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            return _EmptyBucket()

        def blob_exists(self, path):
            return path == reg_blob

        def read_blob_json(self, path):
            return {
                "document_type": "policy",
                "sources": [
                    {
                        "source_index": 1,
                        "document_name": "GBSA Manual.pdf",
                        "gs_uri": "gs://docs/gbsa.pdf",
                        "page_number": 50,
                    }
                ],
            }

    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: _RegGCS())
    monkeypatch.setattr(ds, "_read_db_documents_for_type", lambda *a, **kw: [])
    res = await ds.list_documents_from_bucket(plan, "policy", EnvironmentConfig())
    assert res["total_count"] == 1
    assert res["documents"][0]["document_title"] == "GBSA Manual.pdf"
    assert res["documents"][0]["sections"][0]["section_title"] == "Page 50"

    # Also verify _ensure_review_scope_exists issues INSERT when review_scope_id column is active
    fake_conn = MagicMock()
    db_conn = ds.DatabaseConnector()
    db_conn._ensure_review_scope_exists(fake_conn, "review_scope_id", 99009, plan_number=99009, created_by="tester")
    fake_conn.execute.assert_called_once()
    assert fake_conn.execute.call_args[0][1]["scope_val"] == 99009


def test_apply_mutation_and_soft_mark_across_all_gcs_payload_shapes():
    from types import SimpleNamespace
    import service.document_exclusion_orchestrator as deo

    # 1. Nodes part payload: section exclude + whole doc restore
    part_payload = {
        "document_id": "10",
        "nodes": [
            {"section_id": "1", "title": "Intro", "node_id": "10:sec:1"},
            {"section_id": "2", "title": "Scope", "node_id": "10:sec:2"},
        ],
    }
    act_sec = SimpleNamespace(
        title="Policy 10", filename="policy10.json", document_id="10",
        row_primary_key=None, section_id="2", section_title="Scope", node_id="10:sec:2",
    )
    mutated, changed = deo._apply_mutation_to_gcs_payload(part_payload, act_sec, is_exclude=True)
    assert changed is True
    assert mutated["nodes"][1]["excluded"] is True
    assert mutated["nodes"][0].get("excluded") is not True

    act_whole = SimpleNamespace(
        title="Policy 10", filename="policy10.json", document_id="10",
        row_primary_key=None, section_id=None, section_title=None, node_id=None,
    )
    restored, changed = deo._apply_mutation_to_gcs_payload(mutated, act_whole, is_exclude=False)
    assert changed is True and restored["status"] == "active"

    # 2. GFMS findings wrapper
    gfms_payload = [{"responsePayload": [{"findingId": "F-1", "findingTitle": "Access Issue"}]}]
    gfms_act = SimpleNamespace(
        title="findings_details.json", filename="findings_details.json", document_id="findings_details",
        row_primary_key="F-1", section_id="F-1", section_title="Access Issue", node_id="gfms:finding:F-1",
    )
    gm, changed = deo._apply_mutation_to_gcs_payload(gfms_payload, gfms_act, is_exclude=True)
    assert changed is True and gm[0]["responsePayload"][0]["excluded"] is True
    gm_whole, changed = deo._apply_mutation_to_gcs_payload(
        gfms_payload,
        SimpleNamespace(title="gfms", filename="findings_details.json", document_id="findings_details", row_primary_key=None, section_id=None, section_title=None, node_id=None),
        is_exclude=True,
    )
    assert changed is True and gm_whole[0]["excluded"] is True

    # 3. Historical plan list
    hist_payload = [{"Plan Item Number": "19001", "Plan Item Title": "Prior Audit"}]
    hist_act = SimpleNamespace(
        title="Prior Audit", filename="historical_plan_details.json", document_id="19001",
        row_primary_key="19001", section_id="19001", section_title="Prior Audit", node_id="historical_plan:19001",
    )
    hm, changed = deo._apply_mutation_to_gcs_payload(hist_payload, hist_act, is_exclude=True)
    assert changed is True and hm[0]["excluded"] is True

    # 4. LRR enriched mandates
    lrr_payload = [{"Risk Name": "AML", "Mandates": [{"Regulatory Mandate": "BSA Rule", "Citation": "31 CFR"}]}]
    lrr_act = SimpleNamespace(
        title="BSA Rule", filename="internet_search_data_enriched.json", document_id="1",
        row_primary_key="1", section_id=1, section_title="BSA Rule", node_id="lrr:mandate:1",
    )
    lm, changed = deo._apply_mutation_to_gcs_payload(lrr_payload, lrr_act, is_exclude=True)
    assert changed is True and lm[0]["Mandates"][0]["excluded"] is True

    # 5. Registry {"documents": [...]} section + whole doc
    reg_payload = {
        "documents": [
            {
                "document_id": "10",
                "document_title": "Policy 10",
                "filename": "policy10.json",
                "sections": [{"section_id": "1", "section_title": "Intro", "node_id": "10:sec:1"}],
                "nodes": [{"section_id": "1", "title": "Intro", "node_id": "10:sec:1"}],
            }
        ]
    }
    rm, changed = deo._apply_mutation_to_gcs_payload(reg_payload, SimpleNamespace(
        title="Policy 10", filename="policy10.json", document_id="10",
        row_primary_key=None, section_id="1", section_title="Intro", node_id="10:sec:1",
    ), is_exclude=True)
    assert changed is True and rm["documents"][0]["sections"][0]["excluded"] is True
    rm2, changed = deo._apply_mutation_to_gcs_payload(rm, act_whole, is_exclude=False)
    assert changed is True and rm2["documents"][0]["status"] == "active"

    # 6. document_service soft-mark and section extraction across GFMS, historical, LRR
    assert len(ds._extract_sections_from_json_payload("gfms", gfms_payload, "gfms")) == 1
    assert len(ds._extract_sections_from_json_payload("historical_scoping_document", hist_payload, "hist")) == 1
    assert len(ds._extract_sections_from_json_payload("lrr", lrr_payload, "lrr")) == 1
    assert len(ds._extract_sections_from_json_payload("lrr", [{"title": "Direct LRR"}], "lrr")) == 1
    assert ds._soft_mark_json_payload(gfms_payload, True, [{"section_id": "F-1"}])[0]["responsePayload"][0]["excluded"] is True
    assert ds._soft_mark_json_payload(gfms_payload, False, [])[0]["status"] == "active"
    assert ds._soft_mark_json_payload(lrr_payload, True, [{"section_id": "1", "node_id": "lrr:mandate:1"}])[0]["Mandates"][0]["excluded"] is True
    assert ds._soft_mark_json_payload(lrr_payload, False, [])[0]["status"] == "active"
    assert ds._soft_mark_json_payload(part_payload, True, [{"section_id": "2"}])["nodes"][1]["excluded"] is True
    assert ds._soft_mark_json_payload(part_payload, True, [])["excluded"] is True
    assert ds._soft_mark_json_payload(hist_payload, True, [])[0]["excluded"] is True


def test_context_builder_db_fallback_enriched_lrr_and_mandate_filtering(monkeypatch):
    from service import context_builder as cb
    from types import SimpleNamespace

    filtered = cb._filter_excluded_inbound_payload([
        {
            "Risk Name": "R034",
            "Mandates": [
                {"Regulatory Mandate": "Excluded Mandate", "excluded": True},
                {"Regulatory Mandate": "Active Mandate", "excluded": False},
            ],
        }
    ])
    assert [m["Regulatory Mandate"] for m in filtered[0]["Mandates"]] == ["Active Mandate"]

    plan = "99123"
    cb.PLAN_INBOUND_CACHE.pop(plan, None)

    class _FakeGCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            class _B:
                def list_blobs(self, prefix=""):
                    return [
                        SimpleNamespace(name=f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data.json"),
                        SimpleNamespace(name=f"dbaware_review_{plan}/inbound-data/lrr/internet_search_data_enriched.json"),
                    ]

            return _B()

        def read_blob_json(self, path):
            if path.endswith("internet_search_data.json"):
                return [{"Risk Name": "STALE_RAW"}]
            return filtered

    import service.database_connector as db_mod

    monkeypatch.setattr(
        db_mod.DatabaseConnector,
        "get_data_extraction_rows_for_plan",
        lambda self, p, require_db=False: (_ for _ in ()).throw(RuntimeError("db offline")),
    )
    loaded = cb.load_and_cache_all_inbound_data(_FakeGCS(), plan)
    assert "lrr" in loaded
    assert "Active Mandate" in loaded["lrr"]
    assert "Excluded Mandate" not in loaded["lrr"]
    assert "STALE_RAW" not in loaded["lrr"]
    cb.PLAN_INBOUND_CACHE.pop(plan, None)


def test_database_connector_sets_status_1_on_review_scope_id(monkeypatch):
    from unittest.mock import MagicMock

    monkeypatch.setenv("MOCK_SCOPING_DB", "false")
    connector = ds.DatabaseConnector()
    monkeypatch.setattr(connector, "resolve_scope_instance_id", lambda plan, inst=None: "20440")
    monkeypatch.setattr(connector, "_scope_column", lambda conn, tbl: "review_scope_id")
    monkeypatch.setattr(connector, "_ensure_review_scope_exists", lambda *a, **kw: None)

    fake_conn = MagicMock()
    res_zero = MagicMock()
    res_zero.rowcount = 0
    ins_res = MagicMock()
    ins_res.first.return_value = (123,)
    fake_conn.execute.side_effect = [res_zero, ins_res]
    fake_engine = MagicMock()
    fake_engine.begin.return_value.__enter__.return_value = fake_conn
    monkeypatch.setattr(connector, "connect_to_database", lambda: fake_engine)

    out = connector.update_data_extraction_row_by_pk(None, "20440", "policy", {"documents": []}, updated_by="tester")
    assert out["operation"] == "inserted"
    assert out["review_scope_dataext_id"] == "123"
    insert_sql = str(fake_conn.execute.call_args_list[1][0][0])
    assert "status" in insert_sql.lower()


@pytest.mark.asyncio
async def test_partial_section_overlay_merges_with_gcs_sections(monkeypatch):
    from types import SimpleNamespace
    import service.document_exclusion_orchestrator as deo

    plan = "99321"
    _reset_mock_db(plan)
    gfms_blob = f"dbaware_review_{plan}/inbound-data/gfms/findings_details.json"
    store = {
        gfms_blob: [
            {
                "responsePayload": [
                    {"findingId": "F-1", "findingTitle": "Finding One"},
                    {"findingId": "F-2", "findingTitle": "Finding Two"},
                ]
            }
        ]
    }

    class _OverlayGCS:
        bucket_name = "test-bucket"

        def get_bucket(self):
            class _B:
                def list_blobs(self, prefix=""):
                    return [SimpleNamespace(name=k) for k in store if k.startswith(prefix)]

            return _B()

        def blob_exists(self, path):
            return path in store

        def read_blob_json(self, path):
            return store[path]

    gcs = _OverlayGCS()
    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: gcs)
    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: gcs)

    db_conn = ds.DatabaseConnector()
    # Exclude only F-1 when DB metadata starts empty (creates a 1-section overlay in DB metadata)
    db_conn.mutate_data_extraction_metadata(
        plan, "gfms", "exclude", filename="findings_details.json", section_id="F-1", section_title="Finding One"
    )

    listed = await ds.list_documents_from_bucket(plan, "gfms", EnvironmentConfig())
    secs = listed["documents"][0]["sections"]
    assert len(secs) == 2
    by_id = {str(s["section_id"]): s for s in secs}
    assert by_id["F-1"]["excluded"] is True
    assert by_id["F-2"]["excluded"] is False

    combined, _, _ = deo._load_combined_context_entries(gcs, plan, "gfms")
    c_secs = combined[0]["sections"]
    assert len(c_secs) == 2
    c_by_id = {str(s["section_id"]): s for s in c_secs}
    assert c_by_id["F-1"]["excluded"] is True
    assert c_by_id["F-2"]["excluded"] is False

