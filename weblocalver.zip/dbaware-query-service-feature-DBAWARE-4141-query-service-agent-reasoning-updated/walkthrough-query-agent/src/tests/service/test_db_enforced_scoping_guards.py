from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from agent_helper.env_config import EnvironmentConfig
from service import database_connector as dbc
from service import document_chat_workflow as dcw
from service import document_exclusion_orchestrator as deo
from service import document_service as ds
from service import qna_service as qs
from service import rag_retriever as rr
from service.request import (
    DocumentCandidate,
    DocumentExecutionAction,
    DocumentExecutionRequest,
    DocumentVerificationRequest,
)


class _InMemoryBlob:
    def __init__(self, name: str, store: dict):
        self.name = name
        self._store = store

    def exists(self) -> bool:
        return self.name in self._store


class _InMemoryBucket:
    def __init__(self, store: dict):
        self._store = store

    def blob(self, blob_name: str):
        return _InMemoryBlob(blob_name, self._store)

    def list_blobs(self, prefix: str = ""):
        return [_InMemoryBlob(k, self._store) for k in sorted(self._store) if k.startswith(prefix)]


class _InMemoryGCS:
    def __init__(self, initial: dict):
        self.store = dict(initial)
        self.bucket_name = "test-bucket"

    def get_bucket(self):
        return _InMemoryBucket(self.store)

    def blob_exists(self, blob_name: str) -> bool:
        return blob_name in self.store

    def read_blob_json(self, blob_name: str):
        return self.store[blob_name]

    def write_blob_json(self, blob_name: str, payload) -> None:
        self.store[blob_name] = payload


class _FakeResult:
    def __init__(self, rows):
        self._rows = list(rows)

    def first(self):
        return self._rows[0] if self._rows else None

    def fetchall(self):
        return list(self._rows)

    def __iter__(self):
        return iter(self._rows)


class _FakeConnection:
    def __init__(self, executed_sql: list):
        self.executed_sql = executed_sql

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def execute(self, statement, params=None):
        sql = str(statement)
        self.executed_sql.append((sql, dict(params or {})))
        if "information_schema.columns" in sql:
            return _FakeResult([("review_scope_id",)])
        return _FakeResult([])


class _FakeEngine:
    def __init__(self, executed_sql: list):
        self.executed_sql = executed_sql

    def connect(self):
        return _FakeConnection(self.executed_sql)

    def begin(self):
        return _FakeConnection(self.executed_sql)


@pytest.mark.asyncio
async def test_db_enforced_rejects_missing_data_extraction_entries_and_removals(monkeypatch):
    monkeypatch.setenv("db_host", "sql-test-host")
    monkeypatch.setenv("db_user", "db-user")
    monkeypatch.setenv("db_pass", "db-pass")
    monkeypatch.setenv("db_name", "db-name")
    monkeypatch.setenv("MOCK_SCOPING_DB", "false")

    executed_sql: list = []
    fake_engine = _FakeEngine(executed_sql)
    monkeypatch.setattr(dbc.DatabaseConnector, "connect_to_database", lambda self: fake_engine)

    plan_no = "99901"
    gcs = _InMemoryGCS({
        f"dbaware_review_{plan_no}/inbound-data/policy/relevant_policy/policy1.json": {
            "document_id": "101",
            "document_title": "Orphan Policy",
            "sections": [{"section_id": "1", "section_title": "Overview", "content": "Details"}],
        },
        f"dbaware_review_{plan_no}/inbound-data/policy/relevant_policy.json": {
            "documents": [{"document_id": "101", "document_title": "Orphan Policy", "filename": "policy1.json"}]
        },
    })
    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: gcs)
    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: gcs)
    monkeypatch.setattr(dcw, "GCSUtils", lambda _cfg=None: gcs)

    listed = await ds.list_all_documents(plan_no, EnvironmentConfig())
    assert listed["total_count"] == 0
    assert all(group.get("documents", []) == [] for group in listed["document_groups"])

    entries, _, exists = deo._load_combined_context_entries(gcs, plan_no, "policy")
    assert entries == []
    assert exists is False

    verify_res = await deo.verify_document_context_logic(
        DocumentVerificationRequest(
            plan_number=plan_no,
            action="exclude",
            candidates=[DocumentCandidate(document_type="policy", title="Orphan Policy")],
        )
    )
    assert verify_res.verified_documents == []
    assert len(verify_res.unmatched_documents) == 1

    conn = dbc.DatabaseConnector(EnvironmentConfig())
    with pytest.raises(LookupError):
        conn.mutate_data_extraction_metadata(
            plan_number=plan_no,
            document_type="policy",
            action="exclude",
            title="Orphan Policy",
            filename="policy1.json",
            actor="ui_action",
        )
    monkeypatch.setattr(conn, "_call_resolve_scope", lambda *_a, **_kw: "55")
    mut_res = conn.mutate_data_extraction_metadata(
        plan_number=plan_no,
        document_type="policy",
        action="exclude",
        title="Orphan Policy",
        filename="policy1.json",
        actor="ui_action",
    )
    assert mut_res["updated"] is False
    assert not any("INSERT INTO dbaware_scoping.review_data_extraction" in sql for sql, _ in executed_sql)

    exec_res = await deo.execute_document_exclusion_plan_logic(
        DocumentExecutionRequest(
            plan_number=plan_no,
            approved_by="auditor@db.com",
            actions=[
                DocumentExecutionAction(
                    action="exclude",
                    document_type="policy",
                    title="Orphan Policy",
                    filename="policy1.json",
                )
            ],
        )
    )
    assert exec_res.status == "error"
    assert exec_res.registry_updated is False
    assert exec_res.executed == []

    monkeypatch.setattr(dcw, "_invoke_llm_json", AsyncMock(side_effect=RuntimeError("no llm")))
    turn = await dcw.handle_document_add_remove_turn(
        plan_no,
        "exclude @[Policy: Orphan Policy]",
        approved_by="auditor@db.com",
    )
    assert turn is not None
    assert turn["stage"] not in {"pending_approval", "executed"}


def test_resolve_scope_instance_id_bounds_proc_and_task_to_plan(monkeypatch):
    monkeypatch.setenv("db_host", "sql-test-host")
    monkeypatch.setenv("db_user", "db-user")
    monkeypatch.setenv("db_pass", "db-pass")
    monkeypatch.setenv("db_name", "db-name")
    monkeypatch.setenv("MOCK_SCOPING_DB", "false")

    executed_sql: list = []
    monkeypatch.setattr(dbc.DatabaseConnector, "connect_to_database", lambda self: _FakeEngine(executed_sql))

    conn = dbc.DatabaseConnector(EnvironmentConfig())
    with dbc.scoped_request_context({"process_instance_id": "shared-proc-1", "task_id": "shared-task-1"}):
        with pytest.raises(LookupError):
            conn.resolve_scope_instance_id("20583", require_existing=True, prefer_data_extraction=True)

    proc_queries = [sql for sql, _ in executed_sql if "process_instance_id = :proc_id" in sql]
    task_queries = [sql for sql, _ in executed_sql if "task_id = :task_id" in sql]
    assert proc_queries and all("review_plan_id = :plan_int" in q for q in proc_queries)
    assert task_queries and all("review_plan_id = :plan_int" in q for q in task_queries)


@pytest.mark.asyncio
async def test_rag_and_qna_do_not_default_to_plan_20440_scope_1(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "false")

    class _ExplodingConnector:
        def get_document_ids_for_scope_instance(self, instance_id):
            raise RuntimeError("db error")

    monkeypatch.setattr(qs, "DatabaseConnector", _ExplodingConnector)
    docs = await rr.fetch_document_ids_from_scoping_db(55)
    assert docs == {"policy": [], "kod": [], "procedure": []}

    called_instances = []

    async def _fake_fetch_ids(instance_id: int):
        called_instances.append(instance_id)
        return {"policy": [], "kod": [], "procedure": []}

    class _EmptyConnector:
        def __init__(self, *_a, **_kw):
            pass

        def resolve_scope_instance_id(self, *_a, **_kw):
            return None

        def get_data_extraction_rows_for_plan(self, *_a, **_kw):
            return {}

    monkeypatch.setattr(qs, "DatabaseConnector", _EmptyConnector)
    monkeypatch.setattr(qs, "fetch_document_ids_from_scoping_db", _fake_fetch_ids)
    monkeypatch.setattr(qs, "load_and_cache_all_inbound_data", lambda *_a, **_kw: {})
    monkeypatch.setattr(qs, "fetch_rag_document_chunks", AsyncMock(return_value=[]))
    monkeypatch.setattr(qs, "GCSUtils", lambda *_a, **_kw: _InMemoryGCS({}))
    monkeypatch.setattr(qs, "_load_preliminary_research_context", lambda *_a, **_kw: ({}, []))
    monkeypatch.setattr(qs, "initialize_gemini_model", lambda *_a, **_kw: SimpleNamespace(invoke=lambda *_a, **_kw: SimpleNamespace(content="No policy docs found.", usage_metadata={})))
    monkeypatch.setattr(qs, "PromptBuilder", lambda *_a, **_kw: SimpleNamespace(build_prompt=lambda **_k: "prompt"))
    monkeypatch.setattr(
        qs,
        "run_llm_judge",
        AsyncMock(
            return_value=qs.JudgeEvaluation(
                groundedness_score=1.0,
                citation_coverage=1.0,
                unsupported_claim_count=0,
                contradiction_score=0.0,
                context_faithfulness=1.0,
                answer_relevance=1.0,
                verdict="PASS",
                reasoning="ok",
            )
        ),
    )
    qs.SESSION_CACHE["20583_Preliminary Research Walkthrough"] = {
        "markdown_context": "Plan 20583 baseline",
        "raw_json": {},
        "chat_history": [],
    }

    try:
        await qs.chat_logic(
            session_id="20583",
            user_query="What policy rules apply?",
            context_type="Preliminary Research Walkthrough",
            user_details={},
        )
    finally:
        qs.SESSION_CACHE.pop("20583_Preliminary Research Walkthrough", None)
    assert called_instances == []
