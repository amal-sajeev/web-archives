#!/usr/bin/env python3
"""
Comprehensive Live Endpoint Verification Suite for `walkthrough-query-agent`.

Usage:
    # Against a live CT1 / DEV1 / local endpoint:
    python scripts/test_live_endpoints.py --base-url "https://ct1-cta.dbaware.dev.gcp.db.com/query-service" --plan-number 20086

    # Or set LIVE_ENDPOINT at the top of this file / via env var:
    $env:LIVE_ENDPOINT="https://ct1-cta.dbaware.dev.gcp.db.com/query-service"
    python scripts/test_live_endpoints.py

    # Dry-run / self-test against the local FastAPI app in-process:
    python scripts/test_live_endpoints.py --in-process
"""

from __future__ import annotations

import argparse
import io
import json
import os
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import httpx

# ============================================================================
# CONFIGURE DEFAULT LIVE ENDPOINT HERE (or pass --base-url / $env:LIVE_ENDPOINT)
# ============================================================================
LIVE_ENDPOINT: str = os.getenv(
    "LIVE_ENDPOINT",
    os.getenv(
        "QUERY_SERVICE_URL",
        "https://ct1-cta.dbaware.dev.gcp.db.com/query-service",
    ),
)
DEFAULT_PLAN_NUMBER: str = os.getenv("TEST_PLAN_NUMBER", "20086")
DEFAULT_TIMEOUT_SECONDS: float = float(os.getenv("TEST_TIMEOUT_SECONDS", "120"))

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
LOG_FILE = SCRIPT_DIR / "loggo.log"
REPORT_FILE = SCRIPT_DIR / "live_endpoint_test_report.json"


@dataclass
class EndpointTestResult:
    index: int
    name: str
    method: str
    path: str
    url: str
    status_code: Optional[int]
    passed: bool
    duration_ms: float
    expected_statuses: List[int] = field(default_factory=list)
    response_preview: str = ""
    error: Optional[str] = None


def normalize_urls(raw_base_url: str) -> Tuple[str, str]:
    """
    Given any base URL format:
      - https://host/query-service
      - https://host/query-service/docs
      - https://host/query-service/openapi.json
      - https://host/query-service/qna
      - http://127.0.0.1:8010
    Returns (service_root_url, qna_prefix_url).
    """
    cleaned = raw_base_url.strip().rstrip("/")
    for suffix in ("/docs", "/redoc", "/openapi.json"):
        if cleaned.endswith(suffix):
            cleaned = cleaned[: -len(suffix)].rstrip("/")
            break
    if cleaned.endswith("/qna"):
        service_root = cleaned[: -len("/qna")]
        qna_root = cleaned
    else:
        service_root = cleaned
        qna_root = f"{cleaned}/qna"
    return service_root, qna_root


def build_test_cases(
    service_root: str,
    qna_root: str,
    plan_number: str,
    state: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    Returns ordered test specifications covering every single endpoint in walkthrough-query-agent.
    Uses non-existent/synthetic scratch filenames for delete/upload tests so real plan documents
    are never destructively removed.
    """
    scratch_file = f"_live_smoke_test_{plan_number}.json"
    scratch_title = f"Live Smoke Test Policy ({plan_number})"
    scratch_doc_id = "999991"
    scratch_blob_path = (
        f"dbaware_review_{plan_number}/inbound-data/policy/relevant_policy/{scratch_file}"
    )

    return [
        # ------------------------------------------------------------------
        # 0. OpenAPI & Docs Health Checks
        # ------------------------------------------------------------------
        {
            "name": "OpenAPI Spec",
            "method": "GET",
            "path": "/openapi.json",
            "url": f"{service_root}/openapi.json",
            "expected": [200],
            "request_kwargs": {},
            "on_response": lambda resp, st: st.update(
                {"openapi_paths": list((resp.json() or {}).get("paths", {}).keys())}
            )
            if resp.status_code == 200
            else None,
        },
        {
            "name": "Swagger UI Docs",
            "method": "GET",
            "path": "/docs",
            "url": f"{service_root}/docs",
            "expected": [200],
            "request_kwargs": {},
        },
        # ------------------------------------------------------------------
        # 1. Document Listing Endpoints
        # ------------------------------------------------------------------
        {
            "name": "List Documents by Type (policy)",
            "method": "POST",
            "path": "/qna/documents/list",
            "url": f"{qna_root}/documents/list",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "document_type": "policy",
                }
            },
            "on_response": lambda resp, st: st.update(
                {
                    "existing_policy_docs": (resp.json() or {}).get("documents", [])
                    if resp.status_code == 200
                    else []
                }
            ),
        },
        {
            "name": "List All Documents (policy, kod, procedure)",
            "method": "POST",
            "path": "/qna/documents/list-all",
            "url": f"{qna_root}/documents/list-all",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                }
            },
        },
        # ------------------------------------------------------------------
        # 2. Direct GCS Upload & Bulk Document Upload / Delete Endpoints
        # ------------------------------------------------------------------
        {
            "name": "Upload Raw JSON File to GCS (/qna/upload)",
            "method": "POST",
            "path": "/qna/upload",
            "url": f"{qna_root}/upload",
            "expected": [200, 201],
            "request_kwargs": lambda st: {
                "data": {"dest_blob_path": scratch_blob_path},
                "files": {
                    "file": (
                        scratch_file,
                        io.BytesIO(
                            json.dumps(
                                {
                                    "document_id": scratch_doc_id,
                                    "document_title": scratch_title,
                                    "document_type": "policy",
                                    "paragraphs": [
                                        {
                                            "section_id": "1.1",
                                            "section_title": "Smoke Test Section",
                                            "text": "Temporary smoke test policy content.",
                                        }
                                    ],
                                }
                            ).encode("utf-8")
                        ),
                        "application/json",
                    )
                },
            },
        },
        {
            "name": "Bulk Upload Documents (/qna/documents/upload)",
            "method": "POST",
            "path": "/qna/documents/upload",
            "url": f"{qna_root}/documents/upload",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "documents": [
                        {
                            "document_type": "policy",
                            "items": [
                                {
                                    "file_name": scratch_file,
                                    "document_title": scratch_title,
                                    "document_id": scratch_doc_id,
                                    "section_id": "1.1",
                                    "section_title": "Smoke Test Section",
                                    "content": "Temporary smoke test policy content.",
                                }
                            ],
                        }
                    ],
                }
            },
        },
        # ------------------------------------------------------------------
        # 3. Document Inclusion Staged Endpoints (Verify -> Plan -> Execute -> Workflow)
        # ------------------------------------------------------------------
        {
            "name": "Inclusion Verify Context (/qna/documents/inclusion/verify-context)",
            "method": "POST",
            "path": "/qna/documents/inclusion/verify-context",
            "url": f"{qna_root}/documents/inclusion/verify-context",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "action": "include",
                    "candidates": [
                        {
                            "document_type": "policy",
                            "title": scratch_title,
                            "document_id": scratch_doc_id,
                            "file_name": scratch_file,
                            "section_id": "1.2",
                            "section_title": "Additional Smoke Section",
                            "content": "Additional section content for inclusion verification.",
                        }
                    ],
                    "user_text": f"include policy @{scratch_title}",
                }
            },
            "on_response": lambda resp, st: st.update(
                {
                    "inclusion_verified_docs": (resp.json() or {}).get(
                        "verified_documents", []
                    )
                    if resp.status_code == 200
                    else []
                }
            ),
        },
        {
            "name": "Inclusion Build Plan (/qna/documents/inclusion-plan)",
            "method": "POST",
            "path": "/qna/documents/inclusion-plan",
            "url": f"{qna_root}/documents/inclusion-plan",
            "expected": [200],
            "request_kwargs": lambda st: {
                "json": {
                    "plan_number": plan_number,
                    "user_text": f"include policy @{scratch_title}",
                    "action": "include",
                    "verified_documents": st.get("inclusion_verified_docs")
                    or [
                        {
                            "document_type": "policy",
                            "title": scratch_title,
                            "document_id": scratch_doc_id,
                            "matched": True,
                            "status": "ready_to_add",
                            "content": "Temporary smoke test policy content.",
                        }
                    ],
                }
            },
        },
        {
            "name": "Inclusion Execute Plan (/qna/documents/inclusion/execute)",
            "method": "POST",
            "path": "/qna/documents/inclusion/execute",
            "url": f"{qna_root}/documents/inclusion/execute",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "actions": [
                        {
                            "action": "include",
                            "document_type": "policy",
                            "title": scratch_title,
                            "document_id": scratch_doc_id,
                            "section_id": "1.2",
                            "section_title": "Additional Smoke Section",
                            "content": "Additional section content for inclusion execution.",
                            "scope": "all_related",
                        }
                    ],
                    "approved_by": "live-endpoint-tester",
                }
            },
        },
        {
            "name": "Inclusion Full Workflow (/qna/documents/inclusion/workflow - approval gate)",
            "method": "POST",
            "path": "/qna/documents/inclusion/workflow",
            "url": f"{qna_root}/documents/inclusion/workflow",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "action": "include",
                    "candidates": [
                        {
                            "document_type": "policy",
                            "title": scratch_title,
                            "document_id": scratch_doc_id,
                            "content": "Workflow inclusion test content.",
                        }
                    ],
                    "user_text": f"include policy @{scratch_title}",
                    "approved": False,
                }
            },
        },
        # ------------------------------------------------------------------
        # 4. Document Exclusion Staged Endpoints (Verify -> Plan -> Execute -> Workflow)
        # ------------------------------------------------------------------
        {
            "name": "Exclusion Verify Context (/qna/documents/exclusion/verify-context)",
            "method": "POST",
            "path": "/qna/documents/exclusion/verify-context",
            "url": f"{qna_root}/documents/exclusion/verify-context",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "action": "exclude",
                    "candidates": [
                        {
                            "document_type": "policy",
                            "title": scratch_title,
                        }
                    ],
                    "user_text": f"exclude policy @{scratch_title}",
                }
            },
            "on_response": lambda resp, st: st.update(
                {
                    "exclusion_verified_docs": (resp.json() or {}).get(
                        "verified_documents", []
                    )
                    if resp.status_code == 200
                    else []
                }
            ),
        },
        {
            "name": "Exclusion Build Plan (/qna/documents/exclusion-plan)",
            "method": "POST",
            "path": "/qna/documents/exclusion-plan",
            "url": f"{qna_root}/documents/exclusion-plan",
            "expected": [200],
            "request_kwargs": lambda st: {
                "json": {
                    "plan_number": plan_number,
                    "user_text": f"exclude policy @{scratch_title}",
                    "action": "exclude",
                    "verified_documents": st.get("exclusion_verified_docs")
                    or [
                        {
                            "document_type": "policy",
                            "title": scratch_title,
                            "matched": True,
                            "status": "verified",
                        }
                    ],
                }
            },
        },
        {
            "name": "Exclusion Full Workflow (/qna/documents/exclusion/workflow - approval gate)",
            "method": "POST",
            "path": "/qna/documents/exclusion/workflow",
            "url": f"{qna_root}/documents/exclusion/workflow",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "action": "exclude",
                    "candidates": [
                        {
                            "document_type": "policy",
                            "title": scratch_title,
                        }
                    ],
                    "user_text": f"exclude policy @{scratch_title}",
                    "approved": False,
                }
            },
        },
        {
            "name": "Exclusion Execute Plan (/qna/documents/exclusion/execute)",
            "method": "POST",
            "path": "/qna/documents/exclusion/execute",
            "url": f"{qna_root}/documents/exclusion/execute",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "actions": [
                        {
                            "action": "exclude",
                            "document_type": "policy",
                            "title": scratch_title,
                            "scope": "all_related",
                        }
                    ],
                    "approved_by": "live-endpoint-tester",
                }
            },
        },
        # ------------------------------------------------------------------
        # 5. Chat-Driven 6-Stage Document Action Endpoints (/qna/documents/actions/*)
        # ------------------------------------------------------------------
        {
            "name": "Stage 1: Extract Document Actions (/qna/documents/actions/extract)",
            "method": "POST",
            "path": "/qna/documents/actions/extract",
            "url": f"{qna_root}/documents/actions/extract",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "user_text": f'add policy "{scratch_title}" with content: Smoke test policy rule.',
                }
            },
            "on_response": lambda resp, st: st.update(
                {"extracted_actions": (resp.json() or {}).get("actions", [])}
                if resp.status_code == 200
                else {}
            ),
        },
        {
            "name": "Stage 2: Verify Document Actions (/qna/documents/actions/verify)",
            "method": "POST",
            "path": "/qna/documents/actions/verify",
            "url": f"{qna_root}/documents/actions/verify",
            "expected": [200],
            "request_kwargs": lambda st: {
                "json": {
                    "plan_number": plan_number,
                    "actions": st.get("extracted_actions")
                    or [
                        {
                            "action": "include",
                            "document_type": "policy",
                            "title": scratch_title,
                            "content": "Smoke test policy rule.",
                        }
                    ],
                }
            },
        },
        {
            "name": "Stages 1-4: Propose Document Action Plan (/qna/documents/actions/plan)",
            "method": "POST",
            "path": "/qna/documents/actions/plan",
            "url": f"{qna_root}/documents/actions/plan",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "user_text": f'add policy "{scratch_title}" with content: Smoke test policy rule.',
                    "context_type": "Preliminary Research Walkthrough",
                }
            },
            "on_response": lambda resp, st: st.update(
                {"pending_plan_id": (resp.json() or {}).get("plan_id")}
                if resp.status_code == 200
                else {}
            ),
        },
        {
            "name": "Stages 4-6: Decide Document Action Plan - Reject (/qna/documents/actions/decision)",
            "method": "POST",
            "path": "/qna/documents/actions/decision",
            "url": f"{qna_root}/documents/actions/decision",
            "expected": [200],
            "request_kwargs": lambda st: {
                "json": {
                    "plan_number": plan_number,
                    "plan_id": st.get("pending_plan_id"),
                    "decision": "reject",
                    "approved_by": "live-endpoint-tester",
                }
            },
        },
        {
            "name": "Stage 6: Execute Document Actions (/qna/documents/actions/execute)",
            "method": "POST",
            "path": "/qna/documents/actions/execute",
            "url": f"{qna_root}/documents/actions/execute",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "actions": [
                        {
                            "action": "exclude",
                            "document_type": "policy",
                            "title": scratch_title,
                            "row_primary_keys": [scratch_doc_id],
                        }
                    ],
                    "approved_by": "live-endpoint-tester",
                }
            },
        },
        # ------------------------------------------------------------------
        # 6. Cleanup Scratch Document via Bulk Delete (/qna/documents/delete)
        # ------------------------------------------------------------------
        {
            "name": "Bulk Delete Scratch Document (/qna/documents/delete)",
            "method": "POST",
            "path": "/qna/documents/delete",
            "url": f"{qna_root}/documents/delete",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "documents": [
                        {
                            "document_type": "policy",
                            "items": [
                                {
                                    "file_name": scratch_file,
                                    "document_title": scratch_title,
                                    "document_id": scratch_doc_id,
                                }
                            ],
                        }
                    ],
                }
            },
        },
        # ------------------------------------------------------------------
        # 7. Policy Management Endpoint
        # ------------------------------------------------------------------
        {
            "name": "Manage Policies via Natural Language (/qna/policies/manage)",
            "method": "POST",
            "path": "/qna/policies/manage",
            "url": f"{qna_root}/policies/manage",
            "expected": [200, 500],  # 200 when policy_docs dir exists, 500 if local policy_docs folder is absent
            "request_kwargs": {
                "json": {
                    "command": "keep all policies",
                }
            },
        },
        # ------------------------------------------------------------------
        # 8. Chat, Chat Context Add, and Session Close Endpoints
        # ------------------------------------------------------------------
        {
            "name": "Add Context to Chat Session (/qna/chat/context/add)",
            "method": "POST",
            "path": "/qna/chat/context/add",
            "url": f"{qna_root}/chat/context/add",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "plan_number": plan_number,
                    "session_id": plan_number,
                    "context_type": "Preliminary Research Walkthrough",
                    "sections": [
                        {
                            "section_title": "Smoke Test Context Note",
                            "content": "Smoke test verification note for Q&A session.",
                            "document_type": "policy",
                            "document_title": scratch_title,
                        }
                    ],
                    "persist_to_gcs": False,
                }
            },
        },
        {
            "name": "Conversational Q&A Chat (/qna/chat)",
            "method": "POST",
            "path": "/qna/chat",
            "url": f"{qna_root}/chat",
            "expected": [200],
            "request_kwargs": {
                "json": {
                    "question": "Summarize the key scope and policy considerations for this plan in 2 sentences.",
                    "plan_number": plan_number,
                    "context_type": "Preliminary Research Walkthrough",
                    "userDetails": {
                        "review_scope_instance_id": 1,
                        "user": "live-endpoint-tester",
                        "remarks": "Automated live endpoint verification",
                    },
                }
            },
        },
        {
            "name": "Close Q&A Session (/qna/session/close)",
            "method": "POST",
            "path": "/qna/session/close",
            "url": f"{qna_root}/session/close",
            "expected": [200, 404],
            "request_kwargs": {
                "json": {
                    "session_id": plan_number,
                }
            },
        },
        # ------------------------------------------------------------------
        # 9. RAG Service Proxy Endpoints (/ingest, /ingest-jobs/{id}, /categorize, /relevant-data)
        # ------------------------------------------------------------------
        {
            "name": "Ingest Document to RAG (/qna/documents/ingest)",
            "method": "POST",
            "path": "/qna/documents/ingest",
            "url": f"{qna_root}/documents/ingest",
            "expected": [200, 502],  # 200 when RAG upstream is reachable, 502 if RAG upstream is unreachable
            "request_kwargs": lambda st: {
                "data": {"plan_number": plan_number, "document_type": "policy"},
                "files": [
                    (
                        "policy_files",
                        (
                            "smoke_test_policy.pdf",
                            io.BytesIO(b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF"),
                            "application/pdf",
                        ),
                    )
                ],
            },
            "on_response": lambda resp, st: st.update(
                {
                    "ingest_job_id": (resp.json() or {}).get("job_id") or "smoke-job-id",
                    "ingested_doc_ids": (resp.json() or {}).get("document_ids") or [1],
                }
            )
            if resp.status_code == 200
            else st.update({"ingest_job_id": "smoke-job-id", "ingested_doc_ids": [1]}),
        },
        {
            "name": "Get RAG Ingest Job Status (/qna/documents/ingest-jobs/{job_id})",
            "method": "GET",
            "path": "/qna/documents/ingest-jobs/{job_id}",
            "url": lambda st: f"{qna_root}/documents/ingest-jobs/{st.get('ingest_job_id', 'smoke-job-id')}",
            "expected": [200, 502],
            "request_kwargs": {"params": {"plan_number": plan_number}},
        },
        {
            "name": "Categorize RAG Document IDs (/qna/documents/categorize)",
            "method": "POST",
            "path": "/qna/documents/categorize",
            "url": f"{qna_root}/documents/categorize",
            "expected": [200, 502],
            "request_kwargs": lambda st: {
                "json": {
                    "plan_number": plan_number,
                    "document_ids": st.get("ingested_doc_ids") or [1],
                }
            },
        },
        {
            "name": "Get Relevant Data for Documents from RAG (/qna/documents/relevant-data)",
            "method": "POST",
            "path": "/qna/documents/relevant-data",
            "url": f"{qna_root}/documents/relevant-data",
            "expected": [200, 502],
            "request_kwargs": lambda st: {
                "json": {
                    "plan_number": plan_number,
                    "review_id": int(plan_number) if plan_number.isdigit() else 20086,
                    "documents": [
                        {
                            "document_type": "policy",
                            "document_ids": st.get("ingested_doc_ids") or [1],
                            "top_k": 3,
                        }
                    ],
                    "persist_to_context": False,
                }
            },
        },
    ]


def run_suite(
    base_url: str,
    plan_number: str,
    timeout: float,
    verify_ssl: bool = False,
    in_process: bool = False,
) -> Tuple[List[EndpointTestResult], Dict[str, Any]]:
    service_root, qna_root = normalize_urls(base_url)
    state: Dict[str, Any] = {}
    results: List[EndpointTestResult] = []

    if in_process:
        main_dir = REPO_ROOT / "walkthrough-query-agent" / "src" / "main"
        if str(main_dir) not in sys.path:
            sys.path.insert(0, str(main_dir))
        from fastapi.testclient import TestClient
        import app as fastapi_app_module

        # TestClient uses root paths directly
        service_root = ""
        qna_root = "/qna"
        client_ctx = TestClient(fastapi_app_module.app, raise_server_exceptions=False)
    else:
        client_ctx = httpx.Client(timeout=timeout, verify=verify_ssl, follow_redirects=True)

    cases = build_test_cases(service_root, qna_root, plan_number, state)

    with client_ctx as client:
        for idx, case in enumerate(cases, start=1):
            name = case["name"]
            method = case["method"].upper()
            path = case["path"]
            url = case["url"](state) if callable(case["url"]) else case["url"]
            expected: List[int] = case["expected"]
            req_kwargs: Dict[str, Any] = (
                case["request_kwargs"](state)
                if callable(case["request_kwargs"])
                else dict(case["request_kwargs"])
            )

            t0 = time.perf_counter()
            status_code: Optional[int] = None
            passed = False
            preview = ""
            err_msg: Optional[str] = None

            try:
                resp = client.request(method, url, **req_kwargs)
                duration_ms = round((time.perf_counter() - t0) * 1000, 1)
                status_code = resp.status_code
                passed = status_code in expected
                raw_text = resp.text or ""
                preview = raw_text[:300].replace("\n", " ")

                if not passed:
                    err_msg = f"Expected HTTP {expected}, got {status_code}: {preview}"

                on_resp: Optional[Callable[[Any, Dict[str, Any]], None]] = case.get("on_response")
                if on_resp is not None:
                    try:
                        on_resp(resp, state)
                    except Exception as cb_err:
                        err_msg = f"Post-response callback warning: {cb_err}"
            except Exception as exc:
                duration_ms = round((time.perf_counter() - t0) * 1000, 1)
                err_msg = f"{type(exc).__name__}: {exc}"

            res = EndpointTestResult(
                index=idx,
                name=name,
                method=method,
                path=path,
                url=url,
                status_code=status_code,
                passed=passed,
                duration_ms=duration_ms,
                expected_statuses=expected,
                response_preview=preview,
                error=err_msg,
            )
            results.append(res)

            badge = "PASS" if passed else "FAIL"
            code_str = str(status_code) if status_code is not None else "ERR"
            print(
                f"[{idx:02d}/{len(cases):02d}] {badge:4s} | HTTP {code_str:3s} | {duration_ms:8.1f} ms | {method:4s} {path} ({name})"
            )
            if err_msg and not passed:
                print(f"       -> {err_msg}")

    summary = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "base_url": base_url,
        "service_root": service_root,
        "qna_root": qna_root,
        "plan_number": plan_number,
        "in_process": in_process,
        "total_endpoints_tested": len(results),
        "passed": sum(1 for r in results if r.passed),
        "failed": sum(1 for r in results if not r.passed),
        "results": [asdict(r) for r in results],
    }
    return results, summary


def write_reports(summary: Dict[str, Any]) -> None:
    SCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_FILE.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    lines = [
        "=" * 96,
        f"WALKTHROUGH-QUERY-AGENT LIVE ENDPOINT TEST REPORT ({summary['timestamp_utc']})",
        f"Base URL   : {summary['base_url']}",
        f"Plan Number: {summary['plan_number']}",
        f"Result     : {summary['passed']}/{summary['total_endpoints_tested']} PASSED ({summary['failed']} FAILED)",
        "=" * 96,
    ]
    for item in summary["results"]:
        badge = "PASS" if item["passed"] else "FAIL"
        code_str = str(item["status_code"]) if item["status_code"] is not None else "ERR"
        lines.append(
            f"[{item['index']:02d}] {badge:4s} | HTTP {code_str:3s} | {item['duration_ms']:8.1f} ms | {item['method']:4s} {item['path']} - {item['name']}"
        )
        if item.get("error"):
            lines.append(f"     ERROR: {item['error']}")
        if item.get("response_preview"):
            lines.append(f"     BODY : {item['response_preview']}")
    lines.append("=" * 96)
    LOG_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run a complete end-to-end verification across every endpoint of walkthrough-query-agent."
    )
    parser.add_argument(
        "--base-url",
        default=LIVE_ENDPOINT,
        help=f"Base URL of the deployed query service (default: {LIVE_ENDPOINT})",
    )
    parser.add_argument(
        "--plan-number",
        default=DEFAULT_PLAN_NUMBER,
        help=f"Scoping plan number to use for test payloads (default: {DEFAULT_PLAN_NUMBER})",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=DEFAULT_TIMEOUT_SECONDS,
        help=f"Per-request timeout in seconds (default: {DEFAULT_TIMEOUT_SECONDS})",
    )
    parser.add_argument(
        "--verify-ssl",
        action="store_true",
        default=False,
        help="Enable TLS certificate verification (disabled by default for internal dev/ct1 endpoints)",
    )
    parser.add_argument(
        "--in-process",
        action="store_true",
        default=False,
        help="Run all endpoint checks in-process against the local FastAPI app using TestClient",
    )
    args = parser.parse_args()

    print("=" * 96)
    print("WALKTHROUGH-QUERY-AGENT COMPLETE ENDPOINT TEST SUITE")
    print(f"Target Endpoint : {'<in-process FastAPI TestClient>' if args.in_process else args.base_url}")
    print(f"Plan Number     : {args.plan_number}")
    print(f"Timeout         : {args.timeout}s")
    print("=" * 96)

    _, summary = run_suite(
        base_url=args.base_url,
        plan_number=args.plan_number,
        timeout=args.timeout,
        verify_ssl=args.verify_ssl,
        in_process=args.in_process,
    )
    write_reports(summary)

    print("-" * 96)
    print(
        f"SUMMARY: {summary['passed']}/{summary['total_endpoints_tested']} endpoints passed, "
        f"{summary['failed']} failed."
    )
    print(f"JSON Report : {REPORT_FILE}")
    print(f"UTF-8 Log   : {LOG_FILE}")
    print("-" * 96)
    return 0 if summary["failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
