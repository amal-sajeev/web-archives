# Agentic Document Inclusion & Exclusion via the Query Agent
### A Visual Walkthrough for the Scoping Platform

> **Audience:** Product, QA, and engineering stakeholders.
> **Scope:** How `walkthrough-query-agent` (the **Query Agent** / `query-service`) lets auditors add or remove
> documents from a scoping review safely, with human approval, keeping **GCS**, **PostgreSQL**, and
> **downstream scoping stages** in sync.

> 💡 **Tip:** The diagrams below are written in **Mermaid**. GitHub, VS Code (with the *Markdown Preview Mermaid*
> extension), and most wikis render them automatically. Use **VS Code → Open Preview (Ctrl+Shift+V)** during the meeting.

---

## 1. The Problem in One Sentence

> Auditors need to say *"exclude the Global Trade Surveillance Policy"* or *"add the Operational Risk Management Policy"*
> in plain language, and have the review's document set update **safely, with approval, and in sync** everywhere —
> so that the Preliminary Research, Discovery, Scope, and Test Steps stages all use the correct document set.

---

## 2. Where the Query Agent Sits in the Platform

Everything the UI does is routed through the **Scoping Master Agent**. The Query Agent is one of the subagents
it delegates to.

```mermaid
flowchart TB
    UI["🖥️ UI / API Gateway"]
    MASTER["🎛️ Scoping Master Agent<br/>POST /trigger-scoping-master"]

    subgraph SUBS["Specialised Subagents"]
        QUERY["🤖 Query Agent<br/>(query-service / qna)<br/><b>Inclusion & Exclusion</b>"]
        DATAX["📥 Data Extraction Agent"]
        SUMMARY["📝 Summary Agent<br/>(Preliminary Research)"]
        PROC["📋 Procedure Agent<br/>(Discovery / Scope / Test Steps)"]
    end

    GCS["🗄️ Google Cloud Storage<br/>dbaware_review_&lt;plan&gt;"]
    DB["🐘 PostgreSQL<br/>dbaware_scoping.*"]
    RAG["🔎 RAG Service<br/>(policy/KOD/procedure chunks)"]

    UI --> MASTER
    MASTER --> QUERY
    MASTER --> DATAX
    MASTER --> SUMMARY
    MASTER --> PROC

    QUERY <--> GCS
    QUERY <--> DB
    QUERY <--> RAG
    SUMMARY <--> GCS
    PROC <--> GCS

    classDef agent fill:#e3f2fd,stroke:#1565c0,color:#0d47a1;
    classDef store fill:#f1f8e9,stroke:#558b2f,color:#33691e;
    classDef entry fill:#fff3e0,stroke:#e65100,color:#bf360c;
    class QUERY,DATAX,SUMMARY,PROC agent;
    class GCS,DB,RAG store;
    class UI,MASTER entry;
```

**Key rule:** The UI never calls `query-service` directly — it always goes through the Master Agent. The Master Agent
knows the Query Agent's in-cluster address (`qnaBaseURL`) and forwards the request.

---

## 3. The Heart of the Design: A 6-Stage, Human-in-the-Loop Workflow

Nothing is ever written until the auditor **explicitly approves**. Here is the full journey of a request.

```mermaid
flowchart TD
    START(["👤 Auditor: 'exclude Global Trade Surveillance Policy'"])

    S1["**Stage 1 — Extract**<br/>LLM parses the message into<br/>structured actions<br/>(include/exclude · type · title)"]
    S2["**Stage 2 — Verify**<br/>Match against GCS registry + DB<br/>Attach exact primary keys<br/>(read-only)"]
    S3["**Stage 3 — Plan**<br/>Build a readable plan<br/>with a plan_id<br/>status = pending_approval"]
    GATE{"**Stage 4 — Approval Gate**<br/>Auditor decides"}
    S5["**Stage 5 — Translate**<br/>Convert approved plan into<br/>a deterministic execution payload"]
    S6["**Stage 6 — Execute & Sync**<br/>Write to GCS + PostgreSQL<br/>Evict cached sessions"]

    REJECT(["❌ Rejected — nothing changes"])
    DONE(["✅ Executed — document set updated"])

    START --> S1 --> S2 --> S3 --> GATE
    GATE -->|approve| S5 --> S6 --> DONE
    GATE -->|reject| REJECT

    classDef readonly fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20;
    classDef write fill:#ffebee,stroke:#c62828,color:#b71c1c;
    classDef gate fill:#fff8e1,stroke:#f9a825,color:#f57f17;
    class S1,S2,S3,S5 readonly;
    class S6 write;
    class GATE gate;
```

| Stage | What Happens | Writes Data? |
|------:|--------------|:------------:|
| **1. Extract** | LLM turns the sentence into structured actions; disambiguates using the plan's current documents. | No |
| **2. Verify** | Checks each action against the GCS registry **and** the database; attaches exact primary keys. | No (read-only) |
| **3. Plan** | Produces a human-readable plan with a `plan_id`, status `pending_approval`. | No |
| **4. Decision** | Auditor approves or rejects. Rejection stops everything. | No |
| **5. Translate** | Converts the approved plan into an execution payload using the verified keys. | No |
| **6. Execute** | Applies all changes to GCS + PostgreSQL, then clears cached sessions. | **Yes** |

> **Talking point:** Because keys are resolved in Stage 2 and reused in Stage 6, execution never "guesses" from a title.
> This makes the operation deterministic and auditable.

---

## 4. What Stage 6 Actually Changes

When the auditor approves, the Query Agent updates **three places** and then clears its cache.

```mermaid
flowchart LR
    EXEC["⚙️ Stage 6<br/>Execute & Sync"]

    subgraph GCS["🗄️ Google Cloud Storage"]
        REG["relevant_policy.json<br/>relevant_kod.json<br/>relevant_procedure.json"]
        BLOBS["Individual document<br/>JSON blobs"]
    end

    subgraph DB["🐘 PostgreSQL (dbaware_scoping)"]
        T1["review_data_extraction<br/>(metadata JSONB by PK)"]
        T2["dbaware_review_documents<br/>(plan ↔ document link)"]
    end

    CACHE["🧹 In-memory<br/>session cache"]

    EXEC --> REG
    EXEC --> BLOBS
    EXEC --> T1
    EXEC --> T2
    EXEC --> CACHE

    classDef w fill:#ffebee,stroke:#c62828,color:#b71c1c;
    class EXEC w;
```

1. **GCS registry** (`inbound-data/policy/relevant_{policy,kod,procedure}.json`)
   - **Exclude** → `"status": "removed"`, `"excluded": true` (a **soft delete** — auditable and reversible)
   - **Include** → `"status": "active"`, `"excluded": false`, plus merged sections and RAG chunks
2. **`review_data_extraction`** → `metadata` JSONB updated **by primary key** so PostgreSQL mirrors the GCS registry exactly.
3. **`dbaware_review_documents`** → **insert** the plan-to-document link on include; **delete** it on exclude.
4. **Session cache** → evict cached sessions for the plan so the next chat sees the new document set.

> `review_scope_instance` is only **read**, to map a `plan_number` to its internal `review_scope_instance_id`.

---

## 4a. Sample Data From the Tables (Plan `20086`)

Below are representative rows for plan **`20086`**, showing exactly what changes when a user **excludes** a
document (e.g. document `3`, *"Record Retention Standard"*). These samples follow the real schema and primary-key
derivation used by the service.

### 🔑 How the keys are derived
| Key | Rule | Example (plan `20086`) |
|-----|------|------------------------|
| `review_scope_instance_id` | Maps from `plan_number` via `review_scope` | `"20086"` |
| `review_scope_dataext_id` | `instance × 10 + offset` (policy=+1, kod=+2, procedure=+3) | policy → `200861` |
| `review_document_instance_id` | `instance × 100 + row index` | `2008601 … 2008609` |

---

### Table 1 — `dbaware_scoping.review_scope` *(read-only lookup)*

| review_scope_instance_id | review_plan_id | created_on |
|:---:|:---:|:---:|
| `20086` | `20086` | `2026-11-10 09:14:02` |

> Used only to translate the human `plan_number` into the internal instance id. The Query Agent never writes here.

---

### Table 2 — `dbaware_scoping.review_data_extraction`

One row **per data source** (`policy`, `kod`, `procedure`, `rag_document_metadata`). The `metadata` JSONB mirrors the
GCS registry file. **This is the row whose `metadata` gets rewritten in Stage 6.**

**BEFORE exclusion** — the `policy` row (PK `200861`):
```jsonc
{
  "review_scope_dataext_id": 200861,
  "review_scope_instance_id": "20086",
  "data_source": "policy",
  "metadata": {
    "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
    "documents": [
      { "document_id": "1", "document_title": "Global Trade Surveillance Policy", "status": "active",  "excluded": false },
      { "document_id": "2", "document_title": "Operational Risk Management Policy", "status": "active", "excluded": false },
      { "document_id": "3", "document_title": "Record Retention Standard",         "status": "active",  "excluded": false }
    ]
  },
  "updated_by": "auditor@db.com",
  "updated_on": "2026-11-12 16:40:11"
}
```

**AFTER excluding document `3`** — same row/PK, only the `metadata` changed (soft delete):
```jsonc
{
  "review_scope_dataext_id": 200861,                         // ← same primary key (UPDATE, not INSERT)
  "review_scope_instance_id": "20086",
  "data_source": "policy",
  "metadata": {
    "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
    "documents": [
      { "document_id": "1", "document_title": "Global Trade Surveillance Policy", "status": "active",  "excluded": false },
      { "document_id": "2", "document_title": "Operational Risk Management Policy", "status": "active", "excluded": false },
      { "document_id": "3", "document_title": "Record Retention Standard",         "status": "removed", "excluded": true }  // ← flipped
    ]
  },
  "updated_by": "auditor@db.com",
  "updated_on": "2026-11-13 11:02:55",                        // ← refreshed timestamp
  "remarks": "Excluded via query-agent approval plan"
}
```

> **Talking point:** The row is located by its **primary key** (`200861`) resolved back in Stage 2 — so it is a precise
> `UPDATE`, never a blind rewrite. The document is flagged, not deleted (soft delete).

---

### Table 3 — `dbaware_scoping.dbaware_review_documents`

The plan-to-document link table — **one row per attached document**.

**BEFORE exclusion** (documents `1`, `2`, `3` all linked):

| review_document_instance_id | review_scope_instance_id | document_id |
|:---:|:---:|:---:|
| `2008601` | `20086` | `1` |
| `2008602` | `20086` | `2` |
| `2008603` | `20086` | `3` |

**AFTER excluding document `3`** — the link row is **deleted**:

| review_document_instance_id | review_scope_instance_id | document_id |
|:---:|:---:|:---:|
| `2008601` | `20086` | `1` |
| `2008602` | `20086` | `2` |
| ~~`2008603`~~ | ~~`20086`~~ | ~~`3`~~ · *row deleted* |

> **Contrast with Table 2:** In `review_data_extraction` we keep the document but flag it (`excluded: true`);
> in `dbaware_review_documents` we remove the link row entirely. Re-including the document re-inserts this link
> (with a **new** `review_document_instance_id`) and flips the flags in Table 2 back to `active` / `false`.

---

### At-a-glance: what each table does on include vs. exclude

| Table | On **Include** | On **Exclude** |
|-------|----------------|----------------|
| `review_scope` | read-only | read-only |
| `review_data_extraction` | set `status: active`, `excluded: false` (UPDATE metadata) | set `status: removed`, `excluded: true` (UPDATE metadata) |
| `dbaware_review_documents` | **INSERT** link row (new PK) | **DELETE** link row |

---

## 5. Include vs. Exclude — Side by Side

```mermaid
flowchart TB
    subgraph INC["➕ INCLUDE a document"]
        direction TB
        I1["Mark registry entry:<br/>status = active<br/>excluded = false"]
        I2["Fetch relevant chunks from RAG<br/>(if document_id supplied)"]
        I3["Merge sections into registry"]
        I4["INSERT link row in<br/>dbaware_review_documents"]
        I1 --> I2 --> I3 --> I4
    end

    subgraph EXC["➖ EXCLUDE a document"]
        direction TB
        E1["Mark registry entry:<br/>status = removed<br/>excluded = true"]
        E2["Keep the blob<br/>(soft delete, reversible)"]
        E3["DELETE link row from<br/>dbaware_review_documents"]
        E1 --> E2 --> E3
    end

    classDef inc fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20;
    classDef exc fill:#ffebee,stroke:#c62828,color:#b71c1c;
    class I1,I2,I3,I4 inc;
    class E1,E2,E3 exc;
```

**Why soft-delete on exclude?** The document stays in storage but is flagged. That makes the action **auditable**
(you can see what was removed and when) and **reversible** (re-including simply flips the flags back).

---

## 6. A Deliberate Decision: The Query Agent Does **Not** Regenerate Stage Reports

Originally the Query Agent tried to regenerate the Preliminary Research report itself with a local LLM prompt.
**We removed that.** It bypassed the real Summary Agent pipeline (section builders, citations, and the LLM Judge),
creating a second, lower-quality source of truth.

```mermaid
flowchart LR
    subgraph BEFORE["❌ Before (removed)"]
        direction TB
        B1["Query Agent excludes a doc"]
        B2["Query Agent regenerates<br/>preliminary-research.json<br/>with its own LLM prompt"]
        B1 --> B2
    end

    subgraph AFTER["✅ After (current)"]
        direction TB
        A1["Query Agent updates<br/>only the document set"]
        A2["Auditor clicks 'Re-run'<br/>in the UI"]
        A3["Summary Agent regenerates<br/>its own report properly"]
        A1 --> A2 --> A3
    end

    classDef bad fill:#ffebee,stroke:#c62828,color:#b71c1c;
    classDef good fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20;
    class B1,B2 bad;
    class A1,A2,A3 good;
```

**Benefits of the new approach:**
- **Single source of truth** — each stage owns and regenerates its own report.
- **Faster** — execution now completes in ~400–600 ms instead of blocking on report regeneration.
- **Cleaner** — roughly **1,080 lines** of redundant code removed.

> ⚠️ **Important dependency for downstream agents:** When the Summary and Procedure agents re-run, they **must filter out**
> documents marked `"excluded": true` / `"status": "removed"`. Otherwise excluded documents would reappear in the reports.
> This is the one cross-team item to confirm.

---

## 7. Onboarding a Brand-New Document (RAG Pipeline)

When an auditor uploads a **new PDF** that isn't in the review yet, it flows through RAG first, then into the
inclusion workflow.

```mermaid
flowchart LR
    U["📄 Upload PDF"]
    ING["/documents/ingest<br/>→ job_id"]
    POLL["/documents/ingest-jobs/{job_id}<br/>→ poll until completed"]
    CAT["/documents/categorize<br/>→ policy / KOD / procedure"]
    REL["/documents/relevant-data<br/>→ pull relevant chunks"]
    WF["Inclusion workflow<br/>(Stages 1–6 with approval)"]

    U --> ING --> POLL --> CAT --> REL --> WF

    classDef step fill:#e3f2fd,stroke:#1565c0,color:#0d47a1;
    class U,ING,POLL,CAT,REL,WF step;
```

---

## 8. The Ways the UI Can Trigger It

```mermaid
flowchart TB
    subgraph OPT["Three Integration Options"]
        direction TB
        A["**A. Pure Chat**<br/>POST /qna/chat<br/>User types request, then 'approve'/'reject'<br/><i>Zero extra UI needed</i>"]
        B["**B. Step-by-Step Modal**<br/>/documents/actions/{extract,verify,plan,decision,execute}<br/><i>Full UI control of each stage</i>"]
        C["**C. Dedicated Orchestrators**<br/>/documents/inclusion/* · /documents/exclusion/*<br/><i>One-call workflow with approval gate</i>"]
    end

    classDef opt fill:#ede7f6,stroke:#5e35b1,color:#311b92;
    class A,B,C opt;
```

All three reach the **same 6-stage engine** underneath — they simply expose it at different levels of granularity.

---

## 9. Quality & Validation

| Area | Result |
|------|--------|
| **Live endpoint smoke test (CT1)** | ✅ **28 / 28** endpoints returned `200` / `201` |
| **Unit test coverage** | Raised from ~45% to **~81%** (107 tests; CI gate is 70%) |
| **RAG contract fix** | `review_id` & `region` now sent as strings (fixed a `422`) |
| **Policy management fix** | Added missing `policy_prompt.json`; robust parsing of the model's response |
| **Code cleanup** | ~1,080 lines of redundant report-mutation code removed |

> A gitignored live-test runner (`scripts/test_live_endpoints.py`) exercises every endpoint on CT1 with scratch
> documents and cleans up afterwards, so we can re-verify the full surface on demand.

---

## 10. One-Line Pitch

> **"Auditors change the scoping document set in natural language. The Query Agent verifies the change, gets explicit
> approval, and syncs GCS and the database by primary key. Each stage's own agent then regenerates its report when the
> auditor re-runs it — all routed through the Scoping Master Agent."**

---

## Appendix: Glossary

| Term | Meaning |
|------|---------|
| **Query Agent / `query-service`** | The `walkthrough-query-agent` service that powers Q&A + inclusion/exclusion. |
| **Registry** | The `relevant_{policy,kod,procedure}.json` file listing the review's active documents. |
| **Soft delete** | Marking a document `excluded: true` instead of deleting it — reversible and auditable. |
| **`review_data_extraction`** | DB table whose `metadata` JSONB mirrors the GCS registry. |
| **`dbaware_review_documents`** | DB link table mapping a review to its document IDs. |
| **Stage report** | The output of a scoping stage (Preliminary Research, Discovery, Scope, Test Steps). |
| **Scoping Master Agent** | The single entry point that routes all UI requests to the right subagent. |
