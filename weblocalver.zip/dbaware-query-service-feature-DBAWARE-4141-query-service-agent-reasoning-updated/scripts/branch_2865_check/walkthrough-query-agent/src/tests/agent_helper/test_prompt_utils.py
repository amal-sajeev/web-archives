import sys
from pathlib import Path

# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from unittest.mock import patch, mock_open
from agent_helper.prompt_utils import PromptBuilder

MOCK_PROMPT_JSON = """
{
  "persona": {"title": "Q&A Persona", "content": "You are a validating agent."},
  "principles": {"title": "Core Rules", "content": ["Do not speculate."]},
  "instructions": {"title": "Execution instructions", "content": ["Draft answer."]},
  "output_format": {"title": "Form", "content": ["Use Markdown."]},
  "analysis_section": {"title": "Context", "content": ["{document_context}"]}
}
"""

@pytest.fixture
def mocked_builder():
    with patch("builtins.open", mock_open(read_data=MOCK_PROMPT_JSON)):
        with patch("agent_helper.prompt_utils.Path.exists", return_value=True):
            yield PromptBuilder(prompt_file_name="qna_prompt.json")

def test_prompt_assembly_structure(mocked_builder):
    """Verify that PromptBuilder reads the JSON and generates a single structured markdown prompt."""
    template_str = mocked_builder._full_template_string
    assert "# Q&A Persona" in template_str
    assert "## Core Rules" in template_str
    assert "{document_context}" in template_str

def test_build_prompt_with_formatting(mocked_builder):
    """Verify dynamic placeholders are correctly substituted inside templates."""
    dynamic_prompt = mocked_builder.build_prompt(document_context="Pre-parsed Compliance File Details")
    assert "Pre-parsed Compliance File Details" in dynamic_prompt
    assert "{document_context}" not in dynamic_prompt

def test_build_prompt_missing_placeholder_raises_error(mocked_builder):
    """Verify formatting errors raise structured ValueErrors on template key mismatches."""
    with pytest.raises(ValueError) as excinfo:
        mocked_builder.build_prompt()  # Omit document_context keyword
    assert "Missing placeholder" in str(excinfo.value)