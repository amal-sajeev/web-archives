
# Model Hyperparameters and Architecture
GCP_MODEL_NAME: "gemini-2.5-pro"
LLM_JUDGE_MODEL_NAME: "gemini-2.5-flash"
MODEL_TEMPERATURE: 0.2
MODEL_TOP_P: 0.95
MODEL_TOP_K: 40

# LLM-as-a-Judge Evaluation Policies
LLM_JUDGE_THRESHOLD: 0.85
LLM_JUDGE_MAX_ITERATIONS: 3