import sys
from pathlib import Path

# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))
from fastapi.testclient import TestClient
from app import app

def test_app_metadata_spec():
    """Verify standard core app configuration attributes and metadata loading."""
    assert app.title == "Q&A Intelligence Service"
    assert app.version == "1.0.0"

def test_app_lifespan_routing():
    """Verify standard system router registration hooks are mounted on endpoint handlers."""
    with TestClient(app) as client:
        # Call mounted endpoint with empty payload to verify Pydantic evaluation
        response = client.post("/qna/chat", json={})
        assert response.status_code == 422  # Validation Error confirms path is mapped and intercepted