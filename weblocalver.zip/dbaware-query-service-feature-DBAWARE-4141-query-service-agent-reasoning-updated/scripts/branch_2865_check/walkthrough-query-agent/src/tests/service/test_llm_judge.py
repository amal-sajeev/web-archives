import sys
from pathlib import Path

# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from unittest.mock import MagicMock, patch
from service.llm_judge import run_llm_judge, JudgeEvaluation

@pytest.mark.asyncio
@patch("service.llm_judge.initialize_judge_model")
@patch("service.llm_judge.PromptBuilder")
async def test_run_llm_judge_success_clean_json(mock_prompt_builder_class, mock_init_judge):
    """Verify run_llm_judge parses a clean JSON response successfully into JudgeEvaluation."""
    mock_env_config = MagicMock()
    
    # Mock PromptBuilder
    mock_prompt_builder = MagicMock()
    mock_prompt_builder.build_prompt.return_value = "Mocked System Prompt"
    mock_prompt_builder_class.return_value = mock_prompt_builder

    # Mock LLM response with clean JSON
    mock_llm = MagicMock()
    mock_response = MagicMock()
    mock_response.content = (
        '{"groundedness_score": 1.0, "citation_coverage": 1.0, "unsupported_claim_count": 0, '
        '"contradiction_score": 0.0, "context_faithfulness": 1.0, "answer_relevance": 1.0, '
        '"verdict": "PASS", "reasoning": "Every claim is fully grounded."}'
    )
    mock_llm.invoke.return_value = mock_response
    mock_init_judge.return_value = mock_llm

    result = await run_llm_judge("Context", "Query", "Answer", mock_env_config)

    assert isinstance(result, JudgeEvaluation)
    assert result.groundedness_score == 1.0
    assert result.verdict == "PASS"
    assert result.unsupported_claim_count == 0
    assert result.reasoning == "Every claim is fully grounded."

@pytest.mark.asyncio
@patch("service.llm_judge.initialize_judge_model")
@patch("service.llm_judge.PromptBuilder")
async def test_run_llm_judge_strips_markdown_codeblocks(mock_prompt_builder_class, mock_init_judge):
    """Verify that any triple backtick markdown wrapper is successfully sanitized and parsed."""
    mock_env_config = MagicMock()
    mock_init_judge.return_value = MagicMock()
    
    # Mock raw LLM content wrapped in markdown block
    mock_response = MagicMock()
    mock_response.content = """```json
    {
        "groundedness_score": 0.9,
        "citation_coverage": 0.8,
        "unsupported_claim_count": 0,
        "contradiction_score": 0.0,
        "context_faithfulness": 0.9,
        "answer_relevance": 1.0,
        "verdict": "PASS",
        "reasoning": "Minor citation gaps but grounded."
    }
    ```"""
    mock_init_judge.return_value.invoke.return_value = mock_response

    result = await run_llm_judge("Context", "Query", "Answer", mock_env_config)
    assert result.groundedness_score == 0.9
    assert result.verdict == "PASS"

@pytest.mark.asyncio
@patch("service.llm_judge.initialize_judge_model")
@patch("service.llm_judge.PromptBuilder")
async def test_run_llm_judge_dynamic_verdict_calculation(mock_prompt_builder_class, mock_init_judge):
    """Verify that when the LLM omits the 'verdict' key, it is injected based on config thresholds."""
    mock_env_config = MagicMock()
    # Configure dynamic environment threshold to 0.85
    mock_env_config.get_env_config.side_effect = lambda key, default=None: 0.85 if key == "LLM_JUDGE_THRESHOLD" else default

    # Mock response missing the 'verdict' key
    mock_response = MagicMock()
    mock_response.content = (
        '{"groundedness_score": 0.80, "citation_coverage": 0.9, "unsupported_claim_count": 0, '
        '"contradiction_score": 0.0, "context_faithfulness": 0.8, "answer_relevance": 1.0, '
        '"reasoning": "Slightly below threshold."}'
    )
    mock_init_judge.return_value.invoke.return_value = mock_response

    # Since 0.80 < 0.85, verdict should be computed as FAIL
    result = await run_llm_judge("Context", "Query", "Answer", mock_env_config)
    assert result.verdict == "FAIL"

@pytest.mark.asyncio
@patch("service.llm_judge.initialize_judge_model")
@patch("service.llm_judge.PromptBuilder")
async def test_run_llm_judge_exception_fallback(mock_prompt_builder_class, mock_init_judge):
    """Verify run_llm_judge catches parser errors or network crashes and returns the conservative failure model."""
    mock_env_config = MagicMock()
    
    # Force an exception during invoke
    mock_llm = MagicMock()
    mock_llm.invoke.side_effect = Exception("API Connection Timeout")
    mock_init_judge.return_value = mock_llm

    result = await run_llm_judge("Context", "Query", "Answer", mock_env_config)

    assert isinstance(result, JudgeEvaluation)
    assert result.verdict == "FAIL"
    assert result.groundedness_score == 0.0
    assert result.citation_coverage == 0.0
    assert result.unsupported_claim_count == 1
    assert "Internal evaluator failure" in result.reasoning
    assert "API Connection Timeout" in result.reasoning