from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agent_helper.env_config import EnvironmentConfig
from google.api_core.exceptions import NotFound
from service import document_service as ds
from service import document_service_helpers as dsh


class FakeGCS:
    def __init__(self, blobs=None):
        self.blobs = dict(blobs or {})
        self.bucket_name = "test-bucket"

    def blob_exists(self, path: str) -> bool:
        return path in self.blobs

    def read_blob_json(self, path: str):
        if path not in self.blobs:
            raise FileNotFoundError(path)
        return self.blobs[path]

    def write_blob_json(self, path: str, payload):
        self.blobs[path] = payload
        return f"gs://{self.bucket_name}/{path}"


def test_normalize_and_similarity_helpers():
    assert ds._normalize_document_type(" POLICY ") == "policy"
    assert ds._normalize_document_type("kod") == "kod"
    assert ds._normalize_document_type("procedure") == "procedure"
    with pytest.raises(ds.InvalidDocumentTypeError):
        ds._normalize_document_type("unknown")

    assert ds._normalize_text_for_match(None) == ""
    assert ds._normalize_text_for_match("@German_Bank-Policy/2026!") == "german bank policy 2026"
    assert dsh._tokenize_for_match("") == []
    assert "german" in dsh._tokenize_for_match("remove policy German Bank Separation Act")

    assert ds._title_similarity_score("", "Policy") == 0.0
    assert ds._title_similarity_score("Policy One", "Policy One") == 1.0
    assert ds._title_similarity_score("Electronic Communications", "Electronic Communications Retention Policy") >= 0.8
    assert ds._title_similarity_score("Alpha Beta Gamma", "Alpha Beta Delta") >= 0.5
    assert ds._title_similarity_score("Completely Unrelated", "Xyz Qwe") == 0.0

    assert ds._normalize_title(None) == ""
    assert ds._normalize_title("  Hello   World ") == "Hello World"
    assert dsh._slugify_title("") == ""
    assert dsh._slugify_title("Hello World 123!") == "hello_world_123"
    assert "relevant_policy.json" in ds._registry_blob_path("20086", "policy")
    assert len(dsh._registry_blob_candidates("20086", "policy")) == 2


@pytest.mark.asyncio
async def test_read_json_blob_and_matching():
    gcs = FakeGCS({
        "valid.json": {"a": 1},
        "str_json.json": '{"b": 2}',
        "str_raw.json": "not-json",
    })
    assert await ds._read_json_blob(gcs, "valid.json") == {"a": 1}
    assert await ds._read_json_blob(gcs, "str_json.json") == {"b": 2}
    assert await ds._read_json_blob(gcs, "str_raw.json") == {"raw": "not-json"}
    with pytest.raises(FileNotFoundError):
        await ds._read_json_blob(gcs, "missing.json")

    entries = [
        {"document_id": "1", "document_title": "Global Trade Surveillance Policy"},
        {"document_id": "2", "document_title": "Global Trade Conduct Policy"},
        "invalid_entry",
    ]
    assert dsh._match_document_entries("not_a_list", "Trade") == []
    assert dsh._match_document_entries(entries, "") == []
    item, matches, state = dsh._find_registry_document({"documents": entries}, "Global Trade Surveillance Policy")
    assert state in {"exact", "ambiguous"}
    item_none, _, state_none = dsh._find_registry_document([], "Nonexistent")
    assert item_none is None and state_none == "no_match"


@pytest.mark.asyncio
async def test_mark_registry_document_removed_and_included():
    reg_path = ds._registry_blob_path("20086", "policy")
    gcs = FakeGCS({
        reg_path: {
            "documents": [
                {"document_id": "10", "document_title": "Electronic Communications Policy"},
                {"document_id": "20", "document_title": "Market Abuse Policy"},
            ]
        }
    })

    rem = await ds._mark_registry_document_removed("20086", "policy", "Electronic Communications Policy", gcs)
    assert rem["document_id"] == "10"
    assert gcs.blobs[reg_path]["documents"][0]["excluded"] is True

    with pytest.raises(ds.DocumentNotFoundError):
        await ds._mark_registry_document_removed("20086", "policy", "Nonexistent Document", gcs)

    # Ambiguous match error
    gcs_amb = FakeGCS({
        reg_path: [
            {"document_id": "1", "document_title": "Alpha Trading Control Standard"},
            {"document_id": "2", "document_title": "Alpha Trading Governance Standard"},
        ]
    })
    with pytest.raises(ds.AmbiguousDeleteRequestError):
        await ds._mark_registry_document_removed("20086", "policy", "Alpha Trading", gcs_amb)

    # Restore existing removed document and add section/paragraphs
    inc_existing = await ds._mark_registry_document_included(
        "20086",
        "policy",
        "Electronic Communications Policy",
        gcs,
        document_entry={
            "section_title": "Section 2.1",
            "content": "Updated retention rule",
            "paragraphs": [{"text": "Para 1"}],
            "sections": [{"section_title": "Sec 0"}],
        },
    )
    assert inc_existing["created"] is False
    doc0 = gcs.blobs[reg_path]["documents"][0]
    assert doc0["status"] == "active"
    assert doc0["excluded"] is False

    # Include brand new document
    inc_new = await ds._mark_registry_document_included(
        "20086",
        "policy",
        "Brand New Policy Manual",
        gcs,
        document_entry={"document_id": "99", "section_title": "Intro", "content": "Hello"},
    )
    assert inc_new["created"] is True
    assert inc_new["document_id"] == "99"


@pytest.mark.asyncio
async def test_parse_and_validate_removal_and_inclusion_intents():
    rem = await ds.parse_document_removal_intent(
        "remove policy @Global Trade Policy for plan 20086"
    )
    assert rem["action"] == "remove"
    assert rem["document_type"] == "policy"
    assert rem["plan_number"] == "20086"

    with pytest.raises(ValueError):
        await ds.parse_document_removal_intent("")
    with pytest.raises(ds.InvalidDocumentTypeError):
        await ds.parse_document_removal_intent("remove something unknown")

    validated_rem = ds._validate_removal_intent_payload({
        "action": "remove",
        "document_type": "kod",
        "title": "KOD One",
        "plan_number": "20086",
    })
    assert validated_rem["document_type"] == "kod"

    with pytest.raises(ValueError):
        ds._validate_removal_intent_payload({"status": "error", "reason": "bad"})
    with pytest.raises(ds.InvalidDocumentTypeError):
        ds._validate_removal_intent_payload({"action": "keep", "document_type": "policy", "title": "T", "plan_number": "1"})

    inc = await ds.parse_document_inclusion_intent(
        "include procedure @Onboarding Procedure in plan 20086",
        content="Step 1",
        section_title="Sec 1",
        document_id=42,
    )
    assert inc["action"] == "include"
    assert inc["document_type"] == "procedure"
    assert inc["plan_number"] == "20086"
    assert inc["document_id"] == "42"

    validated_inc = ds._validate_inclusion_intent_payload({
        "action": "include",
        "document_type": "policy",
        "title": "Policy X",
        "plan_number": "20086",
    })
    assert validated_inc["action"] == "include"
    with pytest.raises(ds.InvalidDocumentTypeError):
        ds._validate_inclusion_intent_payload({"action": "delete", "document_type": "policy", "title": "X", "plan_number": "1"})


@pytest.mark.asyncio
async def test_manage_document_removal_and_inclusion(monkeypatch):
    reg_path = ds._registry_blob_path("20086", "policy")
    fake_gcs = FakeGCS({
        reg_path: {"documents": [{"document_id": "1", "document_title": "Target Policy"}]},
    })
    monkeypatch.setattr(dsh, "GCSUtils", lambda _cfg: fake_gcs)

    res_rem = await ds.manage_document_removal("20086", "policy", "Target Policy", EnvironmentConfig())
    assert res_rem["status"] == "success"
    assert res_rem["removed"] is True

    res_inc = await ds.manage_document_inclusion(
        "20086", "policy", "New Included Policy", EnvironmentConfig(), content="Body", document_id="77"
    )
    assert res_inc["status"] == "success"
    assert res_inc["included"] is True


@pytest.mark.asyncio
async def test_list_delete_and_upload_gcs_operations(monkeypatch):
    class FakeBlob:
        def __init__(self, name, exists=True):
            self.name = name
            self._exists = exists

        def exists(self):
            return self._exists

        def delete(self):
            self._exists = False

    class FakeBucket:
        def __init__(self):
            self.blobs_map = {
                "dbaware_review_20086/inbound-data/policy/relevant_policy/policy_1.json": FakeBlob(
                    "dbaware_review_20086/inbound-data/policy/relevant_policy/policy_1.json", True
                ),
                "dbaware_review_20086/inbound-data/policy/relevant_policy/": FakeBlob(
                    "dbaware_review_20086/inbound-data/policy/relevant_policy/", True
                ),
            }

        def list_blobs(self, prefix=""):
            return [b for k, b in self.blobs_map.items() if k.startswith(prefix)]

        def blob(self, path):
            return self.blobs_map.get(path, FakeBlob(path, exists=False))

    class FakeGCSAdapter:
        def __init__(self, _cfg=None):
            self.bucket_name = "test-bucket"
            self._bucket = FakeBucket()
            self.written = {}

        def get_bucket(self):
            return self._bucket

        def blob_exists(self, path):
            return path in self.written

        def read_blob_json(self, path):
            if path.endswith("policy_1.json"):
                return {"document_title": "Policy One", "document_id": "1"}
            return self.written.get(path, {"documents": []})

        def write_blob_json(self, path, payload):
            self.written[path] = payload
            return f"gs://{self.bucket_name}/{path}"

    adapter = FakeGCSAdapter()
    monkeypatch.setattr(ds, "GCSUtils", lambda _cfg=None: adapter)
    monkeypatch.setattr(dsh, "GCSUtils", lambda _cfg=None: adapter)

    listed = await ds.list_documents_from_bucket("20086", "policy", EnvironmentConfig())
    assert listed["total_count"] == 1
    assert listed["documents"][0]["document_title"] == "Policy One"

    del_res = await ds.delete_documents("20086", "policy", ["policy_1.json", "missing.json"], EnvironmentConfig())
    assert del_res["total_deleted"] == 1
    assert "missing.json" in del_res["files_failed"]

    up_res = await ds.upload_documents(
        "20086",
        "policy",
        [{"document_title": "Uploaded Policy", "document_id": "55", "content": "Rule text"}],
        EnvironmentConfig(),
    )
    assert up_res["total_uploaded"] == 1
