import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import HTTPException

from service import document_chat_workflow as dcw
from service import document_exclusion_orchestrator as deo
from service import document_inclusion_orchestrator as dio
from service.request import (
    DocumentActionExecutionItem,
    DocumentActionExecutionRequest,
    DocumentActionItem,
    DocumentActionVerificationResponse,
    DocumentCandidate,
    DocumentExclusionPlanRequest,
    DocumentExclusionWorkflowRequest,
    DocumentExecutionAction,
    DocumentExecutionRequest,
    DocumentInclusionExecutionAction,
    DocumentInclusionExecutionRequest,
    DocumentInclusionPlanRequest,
    DocumentInclusionWorkflowRequest,
    DocumentVerificationRequest,
    DocumentVerificationResult,
    VerifiedDocumentAction,
)


class InMemoryGCS:
    def __init__(self, initial=None):
        self.store = dict(initial or {})
        self.bucket_name = "test-bucket"

    def blob_exists(self, path: str) -> bool:
        return path in self.store

    def read_blob_json(self, path: str):
        if path not in self.store:
            raise FileNotFoundError(path)
        return self.store[path]

    def write_blob_json(self, path: str, payload):
        self.store[path] = payload
        return f"gs://{self.bucket_name}/{path}"


@pytest.mark.asyncio
async def test_exclusion_orchestrator_full_lifecycle(monkeypatch):
    reg_blob = "dbaware_review_20086/inbound-data/policy/relevant_policy.json"
    gcs = InMemoryGCS({
        reg_blob: {
            "documents": [
                {"id": "101", "document_id": "101", "document_title": "Global Trade Surveillance Policy"},
                {"id": "102", "document_id": "102", "document_title": "Record Retention Standard"},
            ]
        },
    })
    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: gcs)

    # 1. Verify context (valid, invalid_type, missing, not_found)
    v_req = DocumentVerificationRequest(
        plan_number="20086",
        action="exclude",
        candidates=[
            DocumentCandidate(document_type="policy", title="Global Trade Surveillance Policy"),
            DocumentCandidate(document_type="", title="Missing Type"),
            DocumentCandidate(document_type="invalid_doc_type", title="Bad Type"),
            DocumentCandidate(document_type="kod", title="Missing Registry Blob"),
            DocumentCandidate(document_type="policy", title="Nonexistent Policy XYZ"),
        ],
    )
    v_resp = await deo.verify_document_context_logic(v_req)
    assert len(v_resp.verified_documents) == 1
    assert v_resp.verified_documents[0].row_primary_key == "101"
    assert len(v_resp.unmatched_documents) == 4

    # 2. Build exclusion plan
    p_req = DocumentExclusionPlanRequest(
        plan_number="20086",
        user_text="exclude Global Trade Surveillance Policy",
        action="exclude",
        verified_documents=v_resp.verified_documents,
    )
    p_resp = await deo.build_document_exclusion_plan_logic(p_req)
    assert p_resp.requires_approval is True
    assert len(p_resp.actions) == 1

    with pytest.raises(HTTPException):
        await deo.build_document_exclusion_plan_logic(
            DocumentExclusionPlanRequest(plan_number="20086", user_text="x", verified_documents=[])
        )

    # 3. Execute exclusion plan
    e_req = DocumentExecutionRequest(
        plan_number="20086",
        actions=[
            DocumentExecutionAction(
                action="exclude",
                document_type="policy",
                title="Global Trade Surveillance Policy",
                context_file=reg_blob,
                row_primary_key="101",
            )
        ],
        approved_by="auditor",
    )
    e_resp = await deo.execute_document_exclusion_plan_logic(e_req)
    assert e_resp.status == "success"
    assert e_resp.registry_updated is True

    # 4. Full workflow (unapproved vs approved)
    wf_unapproved = await deo.orchestrate_document_exclusion_workflow(
        DocumentExclusionWorkflowRequest(
            plan_number="20086",
            action="exclude",
            candidates=[DocumentCandidate(document_type="policy", title="Record Retention Standard")],
            approved=False,
        ),
        verify_fn=deo.verify_document_context_logic,
        plan_fn=deo.build_document_exclusion_plan_logic,
        execute_fn=deo.execute_document_exclusion_plan_logic,
    )
    assert wf_unapproved["requires_approval"] is True

    wf_approved = await deo.orchestrate_document_exclusion_workflow(
        DocumentExclusionWorkflowRequest(
            plan_number="20086",
            action="exclude",
            candidates=[DocumentCandidate(document_type="policy", title="Record Retention Standard")],
            approved=True,
            approved_by="auditor",
        ),
        verify_fn=deo.verify_document_context_logic,
        plan_fn=deo.build_document_exclusion_plan_logic,
        execute_fn=deo.execute_document_exclusion_plan_logic,
    )
    assert wf_approved["status"] == "success"


@pytest.mark.asyncio
async def test_inclusion_orchestrator_full_lifecycle(monkeypatch):
    reg_blob = "dbaware_review_20086/inbound-data/policy/relevant_policy.json"
    gcs = InMemoryGCS({
        reg_blob: {
            "documents": [
                {"id": "101", "document_id": "101", "document_title": "Existing Policy", "status": "removed", "excluded": True}
            ]
        },
    })
    monkeypatch.setattr(dio, "GCSUtils", lambda _cfg=None: gcs)
    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: gcs)
    from service import document_service_helpers as dsh
    monkeypatch.setattr(dsh, "GCSUtils", lambda _cfg=None: gcs)

    monkeypatch.setattr(
        dio,
        "categorize_rag_document_ids",
        AsyncMock(return_value={"policy": [501], "kod": [502], "categories": {"procedure": [503]}}),
    )
    monkeypatch.setattr(
        dio,
        "get_relevant_data_for_documents_from_rag",
        AsyncMock(return_value={"status": "success", "results": [{"section_id": "1", "text": "Chunk"}]}),
    )
    monkeypatch.setattr(
        dio,
        "upload_documents",
        AsyncMock(return_value={"files_uploaded": ["policy_501.json"], "total_uploaded": 1}),
    )

    cat_map = dio._extract_categorized_type_map({
        "policy": [1],
        "categories": {"2": "kod", "3": {"document_type": "procedure"}},
    })
    assert cat_map["1"] == "policy" and cat_map["2"] == "kod" and cat_map["3"] == "procedure"

    # Verify inclusion candidates (existing match, new ready_to_add, auto-categorized by doc_id, invalid)
    v_resp = await dio.verify_document_inclusion_context_logic(
        DocumentVerificationRequest(
            plan_number="20086",
            action="include",
            candidates=[
                DocumentCandidate(document_type="policy", title="Existing Policy"),
                DocumentCandidate(document_type="policy", title="Brand New Policy", content="New text"),
                DocumentCandidate(document_id=501),
                DocumentCandidate(document_type="invalid_type", title="Bad"),
                DocumentCandidate(document_type="", title=""),
            ],
        )
    )
    assert len(v_resp.verified_documents) == 3
    assert len(v_resp.unmatched_documents) == 2

    # Build inclusion plan
    p_resp = await dio.build_document_inclusion_plan_logic(
        DocumentInclusionPlanRequest(
            plan_number="20086",
            user_text="include policies",
            action="include",
            verified_documents=v_resp.verified_documents,
        )
    )
    assert len(p_resp.actions) == 3

    # Persist RAG relevant data to context
    persist_res = await dio.persist_rag_relevant_data_to_context(
        plan_number="20086",
        rag_response={
            "results": {
                "policy": [{"document_id": 501, "document_title": "RAG Policy 501", "chunks": ["c1"]}]
            }
        },
    )
    assert persist_res["registry_updated"] is True

    # Execute inclusion plan
    exec_resp = await dio.execute_document_inclusion_plan_logic(
        DocumentInclusionExecutionRequest(
            plan_number="20086",
            actions=[
                DocumentInclusionExecutionAction(
                    action="include",
                    document_type="policy",
                    title="Brand New Policy",
                    document_id="501",
                    context_file=reg_blob,
                )
            ],
            approved_by="auditor",
        )
    )
    assert exec_resp.status == "success"
    assert exec_resp.registry_updated is True

    # Workflow unapproved and approved
    wf_unapproved = await dio.orchestrate_document_inclusion_workflow(
        DocumentInclusionWorkflowRequest(
            plan_number="20086",
            action="include",
            document_ids=[501],
            approved=False,
        )
    )
    assert wf_unapproved["requires_approval"] is True

    wf_approved = await dio.orchestrate_document_inclusion_workflow(
        DocumentInclusionWorkflowRequest(
            plan_number="20086",
            action="include",
            candidates=[DocumentCandidate(document_type="policy", title="Brand New Policy", content="Text")],
            approved=True,
            approved_by="auditor",
        )
    )
    assert wf_approved["status"] == "success"


@pytest.mark.asyncio
async def test_document_chat_workflow_all_6_stages(monkeypatch):
    reg_blob = "dbaware_review_20086/inbound-data/policy/relevant_policy.json"
    gcs = InMemoryGCS({
        reg_blob: {
            "documents": [
                {"id": "1", "document_id": "1", "document_title": "Policy Alpha", "status": "active", "excluded": False},
                {"id": "2", "document_id": "2", "document_title": "Policy Beta", "status": "removed", "excluded": True},
            ]
        },
    })
    monkeypatch.setattr(dcw, "GCSUtils", lambda _cfg=None: gcs)
    monkeypatch.setattr(deo, "GCSUtils", lambda _cfg=None: gcs)
    monkeypatch.setattr(dio, "GCSUtils", lambda _cfg=None: gcs)
    from service import document_service_helpers as dsh
    monkeypatch.setattr(dsh, "GCSUtils", lambda _cfg=None: gcs)

    # Helpers & heuristic extraction
    assert dcw._normalize_action("remove") == "exclude"
    assert dcw._normalize_action("upload") == "include"
    assert dcw._normalize_action("other") is None
    assert dcw._normalize_type("policies") == "policy"
    assert dcw._parse_json_object('```json\n{"a": 1}\n```') == {"a": 1}
    assert dcw.looks_like_document_request("please remove policy Policy Alpha") is True
    assert dcw.looks_like_document_request("what does Policy Alpha say about retention?") is False

    # Stage 1: LLM fallback to heuristic when LLM raises
    monkeypatch.setattr(dcw, "_invoke_llm_json", AsyncMock(side_effect=RuntimeError("LLM offline")))
    ext_heur = await dcw.extract_document_actions(
        "20086", "please remove policy Policy Alpha and add policy Policy Gamma", gcs_utils=gcs
    )
    assert ext_heur.source == "heuristic"
    assert ext_heur.is_document_request is True
    assert len(ext_heur.actions) == 2

    # Stage 1: LLM extraction success
    monkeypatch.setattr(
        dcw,
        "_invoke_llm_json",
        AsyncMock(
            return_value={
                "is_document_request": True,
                "actions": [
                    {"action": "exclude", "document_type": "policy", "title": "Policy Alpha"},
                    {"action": "exclude", "document_type": "policy", "title": "Policy Beta"},
                    {"action": "include", "document_type": "policy", "title": "Policy Gamma", "content": "Gamma rules"},
                ],
                "reasoning": "Extracted 3 actions",
            }
        ),
    )
    ext_llm = await dcw.extract_document_actions("20086", "remove Policy Alpha, Policy Beta and add Policy Gamma", gcs_utils=gcs)
    assert ext_llm.source == "llm"
    assert len(ext_llm.actions) == 3

    # Stage 2: Verify actions (Policy Alpha -> verified, Policy Beta -> already_excluded, Policy Gamma -> ready_to_add)
    ver_resp = await dcw.verify_document_actions("20086", ext_llm.actions, gcs_utils=gcs)
    assert len(ver_resp.verified) == 2
    assert any(u.status == "already_excluded" for u in ver_resp.unmatched)
    assert all(v.review_scope_dataext_id is not None for v in ver_resp.verified)

    # Stage 3 & 4: Build plan (deterministic fallback when LLM returns empty steps) & store pending plan
    monkeypatch.setattr(dcw, "_invoke_llm_json", AsyncMock(return_value={"steps": []}))
    plan_resp = await dcw.propose_document_action_plan(
        plan_number="20086",
        user_text="remove Policy Alpha and add Policy Gamma",
        extracted_actions=ext_llm.actions,
        verification=ver_resp,
    )
    assert plan_resp.status == "pending_approval"
    assert plan_resp.plan_id is not None
    assert len(plan_resp.steps) == 2

    # Stage 4 -> 5 -> 6 via chat turn: test reject first, then re-propose and approve
    turn_reject = await dcw.handle_document_chat_turn("20086", "reject", approved_by="auditor")
    assert turn_reject["stage"] == "rejected"

    # Re-propose via handle_document_chat_turn
    monkeypatch.setattr(dcw, "_invoke_llm_json", AsyncMock(side_effect=RuntimeError("use deterministic")))
    turn_plan = await dcw.handle_document_chat_turn(
        "20086", "please remove policy Policy Alpha", approved_by="auditor"
    )
    assert turn_plan["stage"] == "pending_approval"

    turn_approve = await dcw.handle_document_chat_turn("20086", "approve", approved_by="auditor")
    assert turn_approve["stage"] == "executed"
    assert turn_approve["execution"]["registry_updated"] is True
