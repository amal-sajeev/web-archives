import sys
from pathlib import Path

# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import pytest
from unittest.mock import MagicMock, patch
from service.gcs_helper import (
    upload_file_to_bucket,
    download_file_from_bucket,
    upload_batch_files,
    download_batch_files
)


@pytest.fixture
def env_config():
    return MagicMock()


# ==========================================
# upload_file_to_bucket Tests
# ==========================================

@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_upload_file_to_bucket_success(mock_gcs_class, tmp_path, env_config):
    """Verify upload_file_to_bucket successfully uploads an existing file."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"
    mock_gcs.upload_file.return_value = "gs://test-bucket/path/test.json"
    mock_gcs_class.return_value = mock_gcs

    test_file = tmp_path / "test.json"
    test_file.write_text('{"title": "Test Policy"}')

    result = await upload_file_to_bucket("20440", "policy", str(test_file), env_config)

    assert result["status"] == "success"
    assert result["gcs_uri"] == "gs://test-bucket/path/test.json"
    assert "test.json" in result["blob_path"]
    mock_gcs.upload_file.assert_called_once()


@pytest.mark.asyncio
async def test_upload_file_to_bucket_file_not_found(env_config):
    """Verify upload_file_to_bucket handles missing files gracefully with error status."""
    non_existent = "non_existent_file_xyz.json"
    result = await upload_file_to_bucket("20440", "policy", non_existent, env_config)

    assert result["status"] == "error"
    assert "File not found" in result["message"]


@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_upload_file_to_bucket_exception(mock_gcs_class, tmp_path, env_config):
    """Verify upload_file_to_bucket catches GCS upload exceptions."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"
    mock_gcs.upload_file.side_effect = Exception("GCS Connection Timeout")
    mock_gcs_class.return_value = mock_gcs

    test_file = tmp_path / "test_err.json"
    test_file.write_text('{"content": "data"}')

    result = await upload_file_to_bucket("20440", "policy", str(test_file), env_config)

    assert result["status"] == "error"
    assert "Upload failed" in result["message"]


# ==========================================
# download_file_from_bucket Tests
# ==========================================

@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_download_file_from_bucket_success(mock_gcs_class, tmp_path, env_config):
    """Verify download_file_from_bucket successfully invokes download_file."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"
    mock_gcs_class.return_value = mock_gcs

    dest_path = tmp_path / "downloads" / "downloaded.json"

    result = await download_file_from_bucket("20440", "policy", "source.json", str(dest_path), env_config)

    assert result["status"] == "success"
    assert result["local_path"] == str(dest_path)
    mock_gcs.download_file.assert_called_once()


@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_download_file_from_bucket_exception(mock_gcs_class, tmp_path, env_config):
    """Verify download_file_from_bucket catches download exceptions."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"
    mock_gcs.download_file.side_effect = Exception("GCS Blob Missing")
    mock_gcs_class.return_value = mock_gcs

    dest_path = tmp_path / "downloads" / "downloaded.json"

    result = await download_file_from_bucket("20440", "policy", "source.json", str(dest_path), env_config)

    assert result["status"] == "error"
    assert "Download failed" in result["message"]


# ==========================================
# upload_batch_files Tests
# ==========================================

@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_upload_batch_files_success(mock_gcs_class, tmp_path, env_config):
    """Verify upload_batch_files uploads all files in a directory."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"
    mock_gcs.upload_file.side_effect = lambda src, dst: f"gs://test-bucket/{dst}"
    mock_gcs_class.return_value = mock_gcs

    upload_dir = tmp_path / "batch_dir"
    upload_dir.mkdir()
    (upload_dir / "policy_1.json").write_text('{"id": 1}')
    (upload_dir / "policy_2.json").write_text('{"id": 2}')

    result = await upload_batch_files("20440", "policy", str(upload_dir), env_config)

    assert result["status"] == "success"
    assert result["total_files"] == 2
    assert len(result["uploaded"]) == 2
    assert len(result["failed"]) == 0


@pytest.mark.asyncio
async def test_upload_batch_files_directory_not_found(env_config):
    """Verify upload_batch_files returns error when local directory does not exist."""
    result = await upload_batch_files("20440", "policy", "non_existent_dir_xyz", env_config)
    assert result["status"] == "error"
    assert "Batch upload failed" in result["message"]


@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_upload_batch_files_partial_failure(mock_gcs_class, tmp_path, env_config):
    """Verify upload_batch_files records partial failures when individual uploads fail."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"

    def upload_side_effect(src, dst):
        if "fail" in src:
            raise Exception("Upload failed for this file")
        return f"gs://test-bucket/{dst}"

    mock_gcs.upload_file.side_effect = upload_side_effect
    mock_gcs_class.return_value = mock_gcs

    upload_dir = tmp_path / "partial_dir"
    upload_dir.mkdir()
    (upload_dir / "pass.json").write_text('{"id": 1}')
    (upload_dir / "fail.json").write_text('{"id": 2}')

    result = await upload_batch_files("20440", "policy", str(upload_dir), env_config)

    assert result["status"] == "partial"
    assert len(result["uploaded"]) == 1
    assert len(result["failed"]) == 1


# ==========================================
# download_batch_files Tests
# ==========================================

@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_download_batch_files_success(mock_gcs_class, tmp_path, env_config):
    """Verify download_batch_files lists and downloads blobs, skipping empty prefix entries."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"

    prefix_blob = MagicMock()
    prefix_blob.name = "dbaware_review_20440/inbound-data/policy/relevant_policy/"

    valid_blob = MagicMock()
    valid_blob.name = "dbaware_review_20440/inbound-data/policy/relevant_policy/policy_1.json"

    mock_bucket = MagicMock()
    mock_bucket.list_blobs.return_value = [prefix_blob, valid_blob]
    mock_gcs.get_bucket.return_value = mock_bucket
    mock_gcs_class.return_value = mock_gcs

    dest_dir = tmp_path / "dest_dir"

    result = await download_batch_files("20440", "policy", str(dest_dir), env_config)

    assert result["status"] == "success"
    assert result["total_downloaded"] == 1
    assert len(result["downloaded"]) == 1
    valid_blob.download_to_filename.assert_called_once()


@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_download_batch_files_partial_failure(mock_gcs_class, tmp_path, env_config):
    """Verify download_batch_files records failed downloads gracefully."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"

    blob_ok = MagicMock()
    blob_ok.name = "dbaware_review_20440/inbound-data/policy/relevant_policy/file_ok.json"

    blob_fail = MagicMock()
    blob_fail.name = "dbaware_review_20440/inbound-data/policy/relevant_policy/file_fail.json"
    blob_fail.download_to_filename.side_effect = Exception("Read error from GCS")

    mock_bucket = MagicMock()
    mock_bucket.list_blobs.return_value = [blob_ok, blob_fail]
    mock_gcs.get_bucket.return_value = mock_bucket
    mock_gcs_class.return_value = mock_gcs

    dest_dir = tmp_path / "dest_partial"

    result = await download_batch_files("20440", "policy", str(dest_dir), env_config)

    assert result["status"] == "partial"
    assert result["total_downloaded"] == 1
    assert len(result["failed"]) == 1


@pytest.mark.asyncio
@patch("service.gcs_helper.GCSUtils")
async def test_download_batch_files_exception(mock_gcs_class, tmp_path, env_config):
    """Verify download_batch_files catches top-level GCS listing exceptions."""
    mock_gcs = MagicMock()
    mock_gcs.bucket_name = "test-bucket"
    mock_gcs.get_bucket.side_effect = Exception("GCS Bucket Unavailable")
    mock_gcs_class.return_value = mock_gcs

    dest_dir = tmp_path / "dest_err"

    result = await download_batch_files("20440", "policy", str(dest_dir), env_config)

    assert result["status"] == "error"
    assert "Batch download failed" in result["message"]