from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agent import agent as agent_mod
from agent import judge_agent as judge_mod
from agent_helper.env_config import EnvironmentConfig
from service import database_connector as dbc
from service import policy_service as ps
from service import rag_retriever as rr
from service import session_manager as sm


def test_database_connector_liquibase_methods(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "true")
    conn = dbc.DatabaseConnector()

    scope_id = conn.resolve_scope_instance_id("20086")
    assert scope_id == "20086"
    assert conn.resolve_scope_instance_id("20086", explicit_instance_id="99") == "99"

    de_rows = conn.get_data_extraction_rows_for_plan("20086")
    assert "policy" in de_rows
    assert de_rows["policy"]["review_scope_dataext_id"] == 200861

    doc_rows = conn.get_review_document_rows_for_plan("20086")
    assert len(doc_rows) > 0

    up_de = conn.update_data_extraction_row_by_pk(
        review_scope_dataext_id=200861,
        plan_number="20086",
        data_source="policy",
        metadata={"documents": [{"document_id": "1", "status": "removed"}]},
        updated_by="tester",
        remarks="unit test",
    )
    assert up_de["operation"] == "updated"

    sync_inc = conn.sync_review_document_reference(
        plan_number="20086",
        action="include",
        document_id=777,
    )
    assert sync_inc["operation"] == "inserted"

    sync_exc = conn.sync_review_document_reference(
        plan_number="20086",
        action="exclude",
        document_id=777,
    )
    assert sync_exc["operation"] == "deleted"


def test_database_connector_sql_mode_with_mock_engine(monkeypatch):
    monkeypatch.setenv("MOCK_SCOPING_DB", "false")
    monkeypatch.setenv("DB_HOST", "localhost")
    monkeypatch.setenv("DB_USER", "postgres")
    monkeypatch.setenv("DB_NAME", "dbaware")

    conn = dbc.DatabaseConnector()

    mock_result = MagicMock()
    mock_result.first.return_value = (555, "20086", "policy", '{"documents": []}')
    mock_result.rowcount = 1
    mock_result.__iter__.return_value = iter([(1001, "20086", 1)])

    mock_connection = MagicMock()
    mock_connection.__enter__.return_value = mock_connection
    mock_connection.__exit__.return_value = False
    mock_connection.execute.return_value = mock_result

    mock_engine = MagicMock()
    mock_engine.connect.return_value = mock_connection
    mock_engine.begin.return_value = mock_connection
    monkeypatch.setattr(conn, "connect_to_database", lambda: mock_engine)

    assert conn.resolve_scope_instance_id("20086") == "555"
    de = conn.get_data_extraction_rows_for_plan("20086", data_sources=["policy"])
    assert "policy" in de
    docs = conn.get_review_document_rows_for_plan("20086")
    assert len(docs) == 1
    up = conn.update_data_extraction_row_by_pk(555, "20086", "policy", {"documents": []})
    assert up["mode"] == "db"
    s_ex = conn.sync_review_document_reference("20086", "exclude", document_id=1, review_document_instance_id=1001)
    assert s_ex["mode"] == "db"
    s_in = conn.sync_review_document_reference("20086", "include", document_id=2)
    assert s_in["mode"] == "db"


@pytest.mark.asyncio
async def test_rag_retriever_ingest_status_categorize_and_relevant_data(monkeypatch):
    assert rr._normalize_multipart_file_entry("policy_files", None) is None
    t1 = rr._normalize_multipart_file_entry("policy_files", ("a.pdf", "text-body", "application/pdf"))
    assert t1[0] == "policy_files" and isinstance(t1[1][1], bytes)
    t2 = rr._normalize_multipart_file_entry(
        "kod_files", {"filename": "b.pdf", "content": "hello", "content_type": "application/pdf"}
    )
    assert t2[0] == "kod_files"

    fake_gcs = MagicMock()
    fake_gcs.blob_exists.return_value = True
    fake_gcs.read_blob_json.side_effect = [
        [{"plan_item_Applicable_Region": "EU, US", "assessable_unit_Countires": ["DE"], "plan_item_Name": "Plan Title", "plan_item_Description": "Desc", "assessable_unit_List": "AU1), AU2", "risk_themes_List": "RT1", "key_control_List": "KC1"}],
        [{"control_Name": "C1", "control_How": "How1", "control_What": "What1", "control_Why": "Why1"}],
    ]
    payload = rr.build_rag_relevant_data_payload(
        plan_number="20086",
        documents=[{"document_type": "policy", "document_ids": [1, 2], "top_k": 4}],
        gcs_utils=fake_gcs,
    )
    assert payload["review_id"] == "20086"
    assert payload["region"] == "EU, US"
    assert payload["plan_item_title"] == "Plan Title"
    assert payload["control_name"] == ["C1"]

    class FakeAsyncClient:
        def __init__(self, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def post(self, url, json=None, files=None):
            if url.endswith("/ingest-documents"):
                return SimpleNamespace(status_code=200, json=lambda: {"job_id": "job-1", "document_ids": [10]}, text="ok")
            if url.endswith("/categorize-document-ids"):
                return SimpleNamespace(status_code=200, json=lambda: {"policy": [10]}, text="ok")
            if url.endswith("/get-relevant-data-for-documents"):
                return SimpleNamespace(status_code=200, json=lambda: {"results": [{"document_id": 10}]}, text="ok")
            return SimpleNamespace(status_code=500, json=lambda: {}, text="err")

        async def get(self, url):
            return SimpleNamespace(status_code=200, json=lambda: {"job_id": "job-1", "status": "completed"}, text="ok")

    monkeypatch.setattr(rr.httpx, "AsyncClient", FakeAsyncClient)

    ing = await rr.ingest_documents_to_rag(
        policy_files=[{"filename": "p.pdf", "content": b"123"}],
        files=[{"filename": "k.pdf", "content": b"456", "document_type": "kod"}],
    )
    assert ing["job_id"] == "job-1"

    st = await rr.get_rag_ingest_job_status("job-1")
    assert st["status"] == "completed"

    cat = await rr.categorize_rag_document_ids([10])
    assert cat["policy"] == [10]

    rel = await rr.get_relevant_data_for_documents_from_rag(
        plan_number="20086",
        documents=[{"document_type": "policy", "document_ids": [10]}],
    )
    assert rel["status"] == "success"

    with pytest.raises(ValueError):
        await rr.ingest_documents_to_rag()
    with pytest.raises(ValueError):
        await rr.get_rag_ingest_job_status("")
    with pytest.raises(ValueError):
        await rr.categorize_rag_document_ids([])


@pytest.mark.asyncio
async def test_session_manager_add_context_to_session(monkeypatch):
    sm.SESSION_CACHE.clear()
    monkeypatch.setattr(
        "service.document_service.upload_documents_bulk",
        AsyncMock(return_value={"total_uploaded": 1, "results": [{"document_type": "policy", "files_uploaded": ["policy_1.json"]}]}),
    )
    monkeypatch.setattr(
        "service.document_service._mark_registry_document_included",
        AsyncMock(return_value={"blob_path": "dbaware_review_20086/inbound-data/policy/relevant_policy.json"}),
    )
    monkeypatch.setattr(
        "service.rag_retriever.categorize_rag_document_ids",
        AsyncMock(return_value={"policy": [11]}),
    )
    monkeypatch.setattr(
        "service.rag_retriever.get_relevant_data_for_documents_from_rag",
        AsyncMock(return_value={"results": [{"document_id": 11, "text": "RAG text"}]}),
    )
    monkeypatch.setattr(
        "service.document_inclusion_orchestrator.persist_rag_relevant_data_to_context",
        AsyncMock(return_value={"persisted_files": ["f1.json"], "registry_updated": True}),
    )

    res = await sm.add_context_to_session_logic(
        session_id="20086",
        plan_number="20086",
        context_type="Preliminary Research Walkthrough",
        user_text="Extra auditor note",
        sections=[{"section_title": "Sec A", "content": "Sec body", "document_type": "policy", "document_title": "Doc A"}],
        documents=[{"document_type": "policy", "items": [{"document_title": "Doc B", "content": "Doc B body"}]}],
        document_ids=[11],
        persist_to_gcs=True,
    )
    assert res["status"] == "success"
    assert res["sections_added"] == 1
    assert res["documents_added"] == 2
    assert res["registry_updated"] is True


@pytest.mark.asyncio
async def test_policy_service_operations(monkeypatch, tmp_path):
    monkeypatch.setattr(ps, "POLICY_DOCS_BASE_PATH", tmp_path)
    (tmp_path / "doc_1_alpha.json").write_text('{"id": 1}', encoding="utf-8")
    (tmp_path / "doc_2_beta.json").write_text('{"id": 2}', encoding="utf-8")

    avail = ps.get_available_policies()
    assert avail == [1, 2]

    fake_llm = MagicMock()
    fake_llm.invoke.return_value = SimpleNamespace(
        content='```json\n{"action": "REMOVE", "policy_ids_to_remove": [1], "reasoning": "Remove 1"}\n```'
    )
    monkeypatch.setattr(ps, "initialize_gemini_model", lambda _cfg: fake_llm)

    res_remove = await ps.manage_policies("remove policy 1", EnvironmentConfig())
    assert res_remove["status"] == "success"
    assert res_remove["policies_removed"] == [1]

    fake_llm.invoke.return_value = SimpleNamespace(
        content='{"action": "INCLUDE", "policy_ids_to_include": [3], "reasoning": "Include 3"}'
    )
    res_inc = await ps.manage_policies("include policy 3", EnvironmentConfig())
    assert res_inc["status"] == "success"
    assert 3 in res_inc["policies_included"]

    fake_llm.invoke.return_value = SimpleNamespace(
        content='{"action": "KEEP", "policy_ids_to_remove": [3], "reasoning": "Keep only 3"}'
    )
    res_keep = await ps.manage_policies("keep policy 3", EnvironmentConfig())
    assert res_keep["status"] == "success"


def test_agent_and_judge_certificate_helpers(monkeypatch, tmp_path):
    pem_file = tmp_path / "custom.pem"
    pem_file.write_text("-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----\n", encoding="utf-8")

    combined = agent_mod.configure_certificate([str(pem_file)])
    assert Path(combined).exists()

    combined_judge = judge_mod.configure_certificate([str(pem_file)])
    assert Path(combined_judge).exists()

    assert agent_mod._extract_response_text(SimpleNamespace(text="hello")) == "hello"
    assert agent_mod._extract_response_text(SimpleNamespace(text="", content=[{"text": "a"}, "b"])) == "ab"
