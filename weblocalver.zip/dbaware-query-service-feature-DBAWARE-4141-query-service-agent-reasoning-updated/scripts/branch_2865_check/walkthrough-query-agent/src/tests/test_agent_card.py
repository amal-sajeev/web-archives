import unittest
from unittest.mock import patch
from datetime import datetime
from agent_helper.agent_card import build_agent_card

class TestAgentCard(unittest.TestCase):

    @patch('agent_helper.agent_card.datetime')
    @patch('agent_helper.agent_card.uuid.uuid4')
    def test_build_agent_card_success(self, mock_uuid, mock_datetime):
        mock_uuid.return_value = 'mock-uuid'
        mock_datetime.utcnow.return_value = datetime(2024, 1, 1, 12, 0, 0)

        agent_card = build_agent_card(
            activity_type="test_activity",
            query="test query",
            plan_item_number="123",
            activity_id="query-execution",
            status="SUCCESS",
            duration_ms=100,
            metadata={"test_key": "test_value"}
        )

        expected_card = {
            "ACTOR_ID": "query-agent",
            "ACTIVITY_ID": "query-execution",
            "ENTITY_ID": agent_card["ENTITY_ID"],
            "PARENT_ENTITY_TYPE": "SCOPING",
            "PARENT_ENTITY_ID": "123",
            "ACTIVITY_TYPE": "TEST_ACTIVITY",
            "ENTITY_TYPE": "QUESTION_AND_ANSWER",
            "QUERY": "test query",
            "STATUS": "SUCCESS",
            "TIMESTAMP": "2024-01-01T12:00:00Z",
            "ENVIRONMENT": "dev",
            "SERVICE_VERSION": agent_card["SERVICE_VERSION"],
            "CORRELATION_ID": agent_card["CORRELATION_ID"],
            "DURATION_MS": 100,
            "METADATA": {"test_key": "test_value"}
        }

        self.assertEqual(agent_card, expected_card)

    @patch('agent_helper.agent_card.datetime')
    @patch('agent_helper.agent_card.uuid.uuid4')
    def test_build_agent_card_failure(self, mock_uuid, mock_datetime):
        mock_uuid.return_value = 'mock-uuid'
        mock_datetime.utcnow.return_value = datetime(2024, 1, 1, 12, 0, 0)

        agent_card = build_agent_card(
            activity_type="test_activity",
            query="test query",
            plan_item_number="123",
            activity_id="query-execution",
            status="FAILURE",
            duration_ms=100,
            error_message="test error"
        )

        expected_card = {
            "ACTOR_ID": "query-agent",
            "ACTIVITY_ID": "query-execution",
            "ENTITY_ID": agent_card["ENTITY_ID"],
            "PARENT_ENTITY_TYPE": "SCOPING",
            "PARENT_ENTITY_ID": "123",
            "ACTIVITY_TYPE": "TEST_ACTIVITY",
            "ENTITY_TYPE": "QUESTION_AND_ANSWER",
            "QUERY": "test query",
            "STATUS": "FAILURE",
            "TIMESTAMP": "2024-01-01T12:00:00Z",
            "ENVIRONMENT": "dev",
            "SERVICE_VERSION": agent_card["SERVICE_VERSION"],
            "CORRELATION_ID": agent_card["CORRELATION_ID"],
            "DURATION_MS": 100,
            "ERROR_MESSAGE": "test error"
        }

        self.assertEqual(agent_card, expected_card)

if __name__ == '__main__':
    unittest.main()