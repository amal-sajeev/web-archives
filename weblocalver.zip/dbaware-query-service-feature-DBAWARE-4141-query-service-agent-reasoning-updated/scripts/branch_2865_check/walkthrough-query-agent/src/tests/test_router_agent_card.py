import sys
from pathlib import Path

# Add the src/main directory to sys.path programmatically
main_dir = Path(__file__).resolve().parent.parent / "main"
if str(main_dir) not in sys.path:
    sys.path.insert(0, str(main_dir))

import unittest
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi.testclient import TestClient
from app import app

class TestRouter(unittest.TestCase):

    def setUp(self):
        self.client = TestClient(app)

    @patch('service.router.construct_human_actor_record')
    @patch('service.router.construct_ai_actor_record')
    @patch('service.router.chat_logic', new_callable=AsyncMock)
    @patch('service.router.build_agent_card')
    def test_chat_with_document_success(self, mock_build_agent_card, mock_chat_logic, mock_ai_record, mock_human_record):
        # Arrange
        mock_build_agent_card.return_value = {
            "ENTITY_ID": "test-entity-id",
            "PARENT_ENTITY_ID": "123",
            "PARENT_ENTITY_TYPE": "SCOPING",
            "ACTOR_ID": "query-agent",
            "STATUS": "SUCCESS"
        }
        mock_chat_logic.return_value = (
            "test answer", 1, None, "test-corr-id-123",
            100, 50
        )

        
        request_data = {
            "question": "test question",
            "planNumber": "123",
            "planName": "test plan",
            "researchSections": {},
            "contextType": "test_context",
            "contextGcsUri": "gcs://test"
        }

        # Act
        response = self.client.post("/qna/chat", json=request_data)

        # Assert
        self.assertEqual(response.status_code, 200)
        mock_chat_logic.assert_called_once()
        mock_build_agent_card.assert_called_once()

    @patch('service.router.construct_human_actor_record')
    @patch('service.router.construct_ai_actor_record')
    @patch('service.router.chat_logic', new_callable=AsyncMock)
    @patch('service.router.build_agent_card')
    def test_chat_with_document_key_error(self, mock_build_agent_card, mock_chat_logic, mock_ai_record, mock_human_record):
        # Arrange
        mock_build_agent_card.return_value = {
            "ENTITY_ID": "test-entity-id",
            "PARENT_ENTITY_ID": "123",
            "PARENT_ENTITY_TYPE": "SCOPING",
            "ACTOR_ID": "query-agent",
            "STATUS": "SUCCESS"
        }
        mock_chat_logic.side_effect = KeyError("test key error")

        request_data = {
            "question": "test question",
            "planNumber": "123",
            "planName": "test plan",
            "researchSections": {},
            "contextType": "test_context",
            "contextGcsUri": "gcs://test"
        }

        # Act
        response = self.client.post("/qna/chat", json=request_data)

        # Assert
        self.assertEqual(response.status_code, 404)
        mock_chat_logic.assert_called_once()
        mock_build_agent_card.assert_called_once()

    @patch('service.router.construct_human_actor_record')
    @patch('service.router.construct_ai_actor_record')
    @patch('service.router.chat_logic', new_callable=AsyncMock)
    @patch('service.router.build_agent_card')
    def test_chat_with_document_exception(self, mock_build_agent_card, mock_chat_logic, mock_ai_record, mock_human_record):
        # Arrange
        mock_build_agent_card.return_value = {
            "ENTITY_ID": "test-entity-id",
            "PARENT_ENTITY_ID": "123",
            "PARENT_ENTITY_TYPE": "SCOPING",
            "ACTOR_ID": "query-agent",
            "STATUS": "SUCCESS"
        }
        mock_chat_logic.side_effect = Exception("test exception")

        request_data = {
            "question": "test question",
            "planNumber": "123",
            "planName": "test plan",
            "researchSections": {},
            "contextType": "test_context",
            "contextGcsUri": "gcs://test"
        }

        # Act
        response = self.client.post("/qna/chat", json=request_data)

        # Assert
        self.assertEqual(response.status_code, 500)
        mock_chat_logic.assert_called_once()
        mock_build_agent_card.assert_called_once()

if __name__ == '__main__':
    unittest.main()