import json
import logging
import os
import sys
import uuid
from typing import Any, Dict, Optional, Tuple

from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils
from service.context_builder import (
    PLAN_INBOUND_CACHE,
    _load_optional_blob_markdown,
    _load_preliminary_research_context,
    load_and_cache_all_inbound_data,
)

logger = logging.getLogger(__name__)

# Thread-safe in-memory session store
# Structure: { session_id: { "markdown_context": str, "chat_history": List[Message], "raw_json": dict } }
SESSION_CACHE: Dict[str, Dict[str, Any]] = {}
DEFAULT_BUCKET = os.getenv("bucket_name", "db-dev-euwe3-gcs-155081-dbaware_review")
DEFAULT_SESSION_ID = "20583"

# Context size budget aligned with Gemini's maximum input token ceiling (1,048,576 tokens ~ 4,000,000 chars)
MAX_TOTAL_CONTEXT_CHARS = int(os.getenv("MAX_TOTAL_CONTEXT_CHARS", "4000000"))

# Initialize global environment config
env_var = os.getenv("ENV_NAME", "dev")
env_config = EnvironmentConfig(env_var)


def _resolve_gcs_utils():
    """Dynamically resolves GCSUtils to support unittest patches on service.qna_service.GCSUtils."""
    qna = sys.modules.get("service.qna_service")
    if qna and hasattr(qna, "GCSUtils"):
        return getattr(qna, "GCSUtils")
    return GCSUtils


async def start_session_logic(
    gcs_blob_path: Optional[str] = None,
    session_id: Optional[str] = None,
    context_type: str = "Preliminary Research Walkthrough",
) -> Tuple[str, str]:
    """
    Loads stage summaries and referenced inputs from GCS to establish an auditable session state.
    """
    from service.qna_service import convert_json_to_markdown

    gcs_utils_cls = _resolve_gcs_utils()
    gcs_utils = gcs_utils_cls(env_config)
    plan_number = str(session_id or DEFAULT_SESSION_ID).strip()
    logger.info("================================================================================")
    logger.info("🚀 INITIALIZING SESSION STATE | Stage: '%s' | Plan: %s", context_type, plan_number)
    logger.info("================================================================================")

    # Canonical stage file definitions relative to plan
    discovery_summary_path = f"dbaware_review_{plan_number}/processing-data/scoping/discovery_walkthrough.json"
    outscope_summary_path = f"dbaware_review_{plan_number}/processing-data/procedure/outscope.json"
    inscope_summary_path = f"dbaware_review_{plan_number}/processing-data/procedure/inscope.json"
    test_steps_summary_path = f"dbaware_review_{plan_number}/processing-data/procedure/test-steps.json"
    meeting_notes_path = f"dbaware_review_{plan_number}/processing-data/preliminary-research/preliminary-research-user-feedback-summary.json"

    context_blocks = [f"# STAGE CONTEXT: {context_type.upper()}"]
    raw_json_data: Dict[str, Any] = {}

    if context_type == "Preliminary Research Walkthrough":
        raw_json_data, prelim_blocks = _load_preliminary_research_context(gcs_utils, plan_number)
        if not prelim_blocks:
            logger.error("❌ No preliminary research JSON files found for plan: %s", plan_number)
            raise FileNotFoundError(
                f"No preliminary research files (past_review.json, policy_regulation.json, broad_scope.json) found for plan {plan_number}."
            )
        context_blocks.extend(prelim_blocks)
    else:
        stage_defaults = {
            "Discovery Walkthrough": discovery_summary_path,
            "Scope Recommendation": outscope_summary_path,
            "Test Steps": test_steps_summary_path,
        }
        primary_blob_path = stage_defaults.get(context_type, discovery_summary_path)
        if gcs_blob_path and not gcs_blob_path.endswith("preliminary-research.json"):
            primary_blob_path = (
                gcs_blob_path[5:].split("/", 1)[1]
                if gcs_blob_path.startswith("gs://")
                else gcs_blob_path
            )

        logger.info("🎯 Primary stage summary blob resolved to: %s", primary_blob_path)
        if not gcs_utils.blob_exists(primary_blob_path):
            logger.error("❌ Primary GCS summary blob NOT found: %s", primary_blob_path)
            raise FileNotFoundError(f"The primary GCS summary blob was not found: {primary_blob_path}")

        logger.info("📥 Downloading primary stage summary JSON: %s", primary_blob_path)
        raw_json_data = gcs_utils.read_blob_json(primary_blob_path)
        stage_summary_md = convert_json_to_markdown(raw_json_data)
        context_blocks.append(f"\n## PRIMARY STAGE SUMMARY ({primary_blob_path.split('/')[-1]})\n{stage_summary_md}")

    # Assemble cross-stage dependencies
    if context_type == "Discovery Walkthrough":
        logger.info("📦 [STAGE: Discovery Walkthrough] Loading upstream Preliminary Research summary...")
        _, upstream_blocks = _load_preliminary_research_context(gcs_utils, plan_number)
        if upstream_blocks:
            context_blocks.extend(upstream_blocks)
            logger.info("📎 Appended %d preliminary research blocks to context.", len(upstream_blocks))

    elif context_type == "Scope Recommendation":
        logger.info("📦 [STAGE: Scope Recommendation] Loading upstream Preliminary Research and Meeting Notes...")
        _, upstream_blocks = _load_preliminary_research_context(gcs_utils, plan_number)
        if upstream_blocks:
            context_blocks.extend(upstream_blocks)
        meeting_md = _load_optional_blob_markdown(gcs_utils, meeting_notes_path, "MEETING NOTES & USER FEEDBACK SUMMARY")
        if meeting_md:
            context_blocks.append(meeting_md)

    elif context_type == "Test Steps":
        logger.info("📦 [STAGE: Test Steps] Loading upstream summaries (Preliminary Research, Meeting Notes, Outscope, Inscope)...")
        _, upstream_blocks = _load_preliminary_research_context(gcs_utils, plan_number)
        if upstream_blocks:
            context_blocks.extend(upstream_blocks)
        meeting_md = _load_optional_blob_markdown(gcs_utils, meeting_notes_path, "MEETING NOTES & USER FEEDBACK SUMMARY")
        if meeting_md:
            context_blocks.append(meeting_md)
        outscope_md = _load_optional_blob_markdown(gcs_utils, outscope_summary_path, "SCOPE RECOMMENDATION: OUT OF SCOPE (outscope.json)")
        if outscope_md:
            context_blocks.append(outscope_md)
        inscope_md = _load_optional_blob_markdown(gcs_utils, inscope_summary_path, "SCOPE RECOMMENDATION: IN SCOPE (inscope.json)")
        if inscope_md:
            context_blocks.append(inscope_md)

    # Pre-cache operational inbound documents
    logger.info("📦 Pre-loading operational inbound data into plan cache for plan %s...", plan_number)
    load_and_cache_all_inbound_data(gcs_utils, plan_number)

    compiled_markdown = "\n\n".join(context_blocks)

    if len(compiled_markdown) > MAX_TOTAL_CONTEXT_CHARS:
        logger.warning(
            "⚠️ Assembled context (%d chars) exceeds MAX_TOTAL_CONTEXT_CHARS (%d chars).",
            len(compiled_markdown),
            MAX_TOTAL_CONTEXT_CHARS,
        )
    logger.info("📊 Context Assembly Completed: %d blocks merged, %d total characters.", len(context_blocks), len(compiled_markdown))

    if not session_id:
        session_id = str(uuid.uuid4())
    cache_key = f"{session_id}_{context_type}"
    correlation_id = str(uuid.uuid4())
    SESSION_CACHE[cache_key] = {
        "raw_json": raw_json_data,
        "markdown_context": compiled_markdown,
        "chat_history": [],
        "correlation_id": correlation_id,
    }

    logger.info("🎉 Session '%s' established and ready in SESSION_CACHE (Correlation ID: %s).", cache_key, correlation_id)
    preview = compiled_markdown[:150] + "..." if len(compiled_markdown) > 150 else compiled_markdown
    return session_id, preview


async def upload_json_logic(file_bytes: bytes, filename: str, dest_blob_path: Optional[str] = None) -> Tuple[str, str]:
    """Validates the uploaded bytes as JSON, then pushes to GCS."""
    try:
        payload = json.loads(file_bytes.decode("utf-8"))
    except Exception as e:
        raise ValueError(f"Invalid JSON file format: {str(e)}")

    target_path = dest_blob_path or f"dbaware_review_20583_Suitability and Appropriateness Review - Global - CB/{filename}"
    if not target_path.endswith(".json"):
        target_path += ".json"

    gcs_utils_cls = _resolve_gcs_utils()
    return target_path, gcs_utils_cls(env_config).write_blob_json(target_path, payload)


async def close_session_logic(session_id: str) -> str:
    """Closes and evicts stage-specific Q&A sessions for a given plan/session ID."""
    clean_id = str(session_id).strip()
    evicted_keys = []
    for key in list(SESSION_CACHE.keys()):
        if key == clean_id or key.startswith(f"{clean_id}_"):
            del SESSION_CACHE[key]
            evicted_keys.append(key)

    if clean_id in PLAN_INBOUND_CACHE:
        del PLAN_INBOUND_CACHE[clean_id]
        logger.info("Evicted plan inbound cache for plan: %s", clean_id)

    if not evicted_keys:
        raise KeyError(f"No active Q&A sessions found for ID: {clean_id}")

    logger.info("Evicted stage session keys: %s", evicted_keys)
    return f"Successfully closed and cleared {len(evicted_keys)} cached stage session(s) from server memory."


async def add_context_to_session_logic(
    session_id: Optional[str] = None,
    plan_number: Optional[str] = None,
    context_type: str = "Preliminary Research Walkthrough",
    user_text: Optional[str] = None,
    sections: Optional[list] = None,
    documents: Optional[list] = None,
    document_ids: Optional[list] = None,
    persist_to_gcs: bool = True,
) -> Dict[str, Any]:
    """
    Adds user-uploaded documents, RAG document IDs, or chat-supplied sections into the active
    Q&A session context and (when persist_to_gcs=True) persists them into the plan's GCS context.
    """
    from service.qna_service import convert_json_to_markdown
    from service.document_service import (
        _mark_registry_document_included,
        upload_documents_bulk,
    )
    from service.rag_retriever import (
        categorize_rag_document_ids,
        get_relevant_data_for_documents_from_rag,
    )
    from service.document_inclusion_orchestrator import (
        _extract_categorized_type_map,
        persist_rag_relevant_data_to_context,
    )

    resolved_plan = str(plan_number or session_id or DEFAULT_SESSION_ID).strip()
    resolved_session = str(session_id or resolved_plan).strip()
    cache_key = f"{resolved_session}_{context_type}"

    gcs_utils_cls = _resolve_gcs_utils()
    gcs_utils = gcs_utils_cls(env_config)

    persisted_files: list[str] = []
    registry_updated = False
    sections_added = 0
    documents_added = 0
    markdown_additions: list[str] = []

    # 1. Handle structured document groups (upload_documents_bulk)
    if documents:
        normalized_groups = []
        for grp in documents:
            if hasattr(grp, "model_dump"):
                grp_dict = grp.model_dump(mode="json")
            elif hasattr(grp, "dict"):
                grp_dict = grp.dict()
            elif isinstance(grp, dict):
                grp_dict = dict(grp)
            else:
                continue
            normalized_groups.append(grp_dict)
            for item in grp_dict.get("items", []):
                if isinstance(item, dict):
                    title = item.get("document_title") or item.get("title") or "Uploaded Document"
                    dtype = str(grp_dict.get("document_type", "policy")).upper()
                    content = item.get("content") or item.get("paragraphs") or ""
                    content_md = convert_json_to_markdown(content) if isinstance(content, (dict, list)) else str(content)
                    markdown_additions.append(f"### [{dtype}] {title}\n{content_md}".strip())
                    documents_added += 1

        if persist_to_gcs and normalized_groups:
            try:
                bulk_res = await upload_documents_bulk(resolved_plan, normalized_groups, env_config)
                for res in bulk_res.get("results", []):
                    dtype = res.get("document_type", "policy")
                    for fname in res.get("files_uploaded", []):
                        persisted_files.append(
                            f"dbaware_review_{resolved_plan}/inbound-data/policy/relevant_{dtype}/{fname}"
                        )
                if bulk_res.get("total_uploaded", 0) > 0:
                    registry_updated = True
            except Exception as e:
                logger.warning("Could not persist uploaded documents to GCS for plan %s: %s", resolved_plan, e)

    # 2. Handle RAG document_ids (categorize -> get-relevant-data-for-documents -> persist)
    if document_ids:
        clean_ids = [int(i) for i in document_ids if str(i).lstrip("-").isdigit()]
        if clean_ids:
            cat_map: Dict[str, str] = {}
            try:
                cat_resp = await categorize_rag_document_ids(clean_ids)
                cat_map = _extract_categorized_type_map(cat_resp)
            except Exception as e:
                logger.debug("Categorization fallback during add_context_to_session_logic: %s", e)

            grouped_ids: Dict[str, list[int]] = {}
            for doc_id in clean_ids:
                dtype = cat_map.get(str(doc_id), "policy")
                grouped_ids.setdefault(dtype, []).append(doc_id)

            doc_specs = [
                {"document_type": dtype, "document_ids": ids, "top_k": 5}
                for dtype, ids in grouped_ids.items()
            ]
            try:
                rag_data = await get_relevant_data_for_documents_from_rag(
                    plan_number=resolved_plan,
                    documents=doc_specs,
                    gcs_utils=gcs_utils,
                )
                if persist_to_gcs and isinstance(rag_data, dict):
                    persist_res = await persist_rag_relevant_data_to_context(
                        plan_number=resolved_plan,
                        rag_response=rag_data,
                        env_config=env_config,
                    )
                    persisted_files.extend(persist_res.get("persisted_files", []))
                    if persist_res.get("registry_updated"):
                        registry_updated = True
                rag_md = convert_json_to_markdown(rag_data.get("results", rag_data))
                if rag_md:
                    markdown_additions.append(f"### RAG INCLUDED DOCUMENTS ({clean_ids})\n{rag_md}")
                documents_added += len(clean_ids)
            except Exception as e:
                logger.warning("RAG relevant data retrieval failed during chat context addition: %s", e)

    # 3. Handle structured sections added through chat
    for sec in sections or []:
        if hasattr(sec, "model_dump"):
            sec_dict = sec.model_dump(mode="json")
        elif hasattr(sec, "dict"):
            sec_dict = sec.dict()
        elif isinstance(sec, dict):
            sec_dict = dict(sec)
        else:
            continue

        sec_title = str(sec_dict.get("section_title") or sec_dict.get("title") or "Added Section").strip()
        doc_title = str(sec_dict.get("document_title") or sec_title).strip()
        doc_type = str(sec_dict.get("document_type") or "policy").strip().lower()
        if doc_type not in {"policy", "kod", "procedure"}:
            doc_type = "policy"
        raw_content = sec_dict.get("content", "")
        content_md = convert_json_to_markdown(raw_content) if isinstance(raw_content, (dict, list)) else str(raw_content)
        markdown_additions.append(f"### [{doc_type.upper()}] {doc_title} - {sec_title}\n{content_md}".strip())
        sections_added += 1

        if persist_to_gcs:
            try:
                reg_res = await _mark_registry_document_included(
                    plan_number=resolved_plan,
                    document_type=doc_type,
                    target_title=doc_title,
                    gcs_utils=gcs_utils,
                    document_entry={
                        "document_id": sec_dict.get("document_id"),
                        "document_title": doc_title,
                        "section_id": sec_dict.get("section_id"),
                        "section_title": sec_title,
                        "content": raw_content,
                        "included_by": "chat_context_add",
                    },
                )
                persisted_files.append(reg_res["blob_path"])
                registry_updated = True
            except Exception as e:
                logger.warning("Could not persist section '%s' to GCS registry: %s", sec_title, e)

    # 4. Handle free-form user_text context addition
    if user_text and str(user_text).strip():
        clean_text = str(user_text).strip()
        markdown_additions.append(f"### USER CHAT CONTEXT NOTE\n{clean_text}")
        if not sections and not documents and not document_ids:
            sections_added += 1

    # 5. Update or initialize SESSION_CACHE entry
    addition_block = "\n\n## USER-ADDED CONTEXT & SECTIONS\n" + "\n\n".join(markdown_additions) if markdown_additions else ""
    if cache_key not in SESSION_CACHE:
        SESSION_CACHE[cache_key] = {
            "raw_json": {"plan_number": resolved_plan, "added_sections": sections_added, "added_documents": documents_added},
            "markdown_context": f"# STAGE CONTEXT: {context_type.upper()}{addition_block}",
            "chat_history": [],
            "correlation_id": str(uuid.uuid4()),
        }
    else:
        if addition_block:
            SESSION_CACHE[cache_key]["markdown_context"] = (
                SESSION_CACHE[cache_key].get("markdown_context", "") + addition_block
            )

    if resolved_plan in PLAN_INBOUND_CACHE:
        del PLAN_INBOUND_CACHE[resolved_plan]

    return {
        "session_id": resolved_session,
        "plan_number": resolved_plan,
        "context_type": context_type,
        "status": "success",
        "sections_added": sections_added,
        "documents_added": documents_added,
        "persisted_files": list(dict.fromkeys(persisted_files)),
        "registry_updated": registry_updated,
        "message": (
            f"Successfully added {documents_added} document(s) and {sections_added} section(s) "
            f"to session '{resolved_session}' ({context_type})."
        ),
    }
