"""
GCS Bucket Helper Utilities

Provides helper functions to upload and download files from GCS bucket for testing purposes.
"""

import logging
from pathlib import Path
from typing import List, Dict, Any
from agent_helper.env_config import EnvironmentConfig
from agent_helper.utils import GCSUtils

logger = logging.getLogger(__name__)


async def upload_file_to_bucket(
    plan_number: str,
    document_type: str,
    local_file_path: str,
    env_config: EnvironmentConfig
) -> Dict[str, Any]:
    """
    Uploads a local file to GCS bucket.
    
    Args:
        plan_number: Plan number (e.g., "20440")
        document_type: Document type (e.g., "policy", "kod", "procedure")
        local_file_path: Path to local file to upload
        env_config: Environment configuration
    
    Returns:
        Dict with upload status and GCS URI
    """
    try:
        local_path = Path(local_file_path)
        if not local_path.exists():
            raise FileNotFoundError(f"Local file not found: {local_file_path}")
        
        gcs_utils = GCSUtils(env_config)
        bucket_name = gcs_utils.bucket_name
        
        # Construct GCS blob path
        blob_path = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/{local_path.name}"
        
        logger.info(f"Uploading file {local_file_path} to gs://{bucket_name}/{blob_path}")
        
        # Upload file
        uri = gcs_utils.upload_file(local_file_path, blob_path)
        
        return {
            "status": "success",
            "message": f"File uploaded successfully",
            "local_file": str(local_path),
            "gcs_uri": uri,
            "blob_path": blob_path
        }
        
    except FileNotFoundError as e:
        logger.error(f"File not found: {str(e)}")
        return {
            "status": "error",
            "message": f"File not found: {str(e)}",
            "local_file": local_file_path
        }
    except Exception as e:
        logger.error(f"Error uploading file to GCS: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "message": f"Upload failed: {str(e)}",
            "local_file": local_file_path
        }


async def download_file_from_bucket(
    plan_number: str,
    document_type: str,
    file_name: str,
    local_dest_path: str,
    env_config: EnvironmentConfig
) -> Dict[str, Any]:
    """
    Downloads a file from GCS bucket to local filesystem.
    
    Args:
        plan_number: Plan number (e.g., "20440")
        document_type: Document type (e.g., "policy", "kod", "procedure")
        file_name: Name of file to download
        local_dest_path: Path where to save downloaded file
        env_config: Environment configuration
    
    Returns:
        Dict with download status
    """
    try:
        gcs_utils = GCSUtils(env_config)
        bucket_name = gcs_utils.bucket_name
        
        # Construct GCS blob path
        blob_path = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/{file_name}"
        
        logger.info(f"Downloading gs://{bucket_name}/{blob_path} to {local_dest_path}")
        
        # Create parent directory if it doesn't exist
        Path(local_dest_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Download file
        gcs_utils.download_file(blob_path, local_dest_path)
        
        return {
            "status": "success",
            "message": f"File downloaded successfully",
            "gcs_uri": f"gs://{bucket_name}/{blob_path}",
            "local_path": local_dest_path
        }
        
    except Exception as e:
        logger.error(f"Error downloading file from GCS: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "message": f"Download failed: {str(e)}",
            "gcs_uri": f"gs://{bucket_name}/dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/{file_name}"
        }


async def upload_batch_files(
    plan_number: str,
    document_type: str,
    local_dir_path: str,
    env_config: EnvironmentConfig
) -> Dict[str, Any]:
    """
    Uploads all files from a local directory to GCS bucket.
    
    Args:
        plan_number: Plan number (e.g., "20440")
        document_type: Document type (e.g., "policy", "kod", "procedure")
        local_dir_path: Path to local directory containing files to upload
        env_config: Environment configuration
    
    Returns:
        Dict with batch upload results
    """
    try:
        local_dir = Path(local_dir_path)
        if not local_dir.exists() or not local_dir.is_dir():
            raise FileNotFoundError(f"Local directory not found: {local_dir_path}")
        
        gcs_utils = GCSUtils(env_config)
        bucket_name = gcs_utils.bucket_name
        
        uploaded = []
        failed = []
        
        # Get all files in directory
        files = [f for f in local_dir.iterdir() if f.is_file()]
        
        logger.info(f"Uploading {len(files)} files from {local_dir_path} to GCS")
        
        for file_path in files:
            try:
                blob_path = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/{file_path.name}"
                uri = gcs_utils.upload_file(str(file_path), blob_path)
                
                uploaded.append({
                    "file_name": file_path.name,
                    "gcs_uri": uri
                })
                logger.info(f"Uploaded: {file_path.name} → {uri}")
                
            except Exception as e:
                logger.error(f"Failed to upload {file_path.name}: {str(e)}")
                failed.append({
                    "file_name": file_path.name,
                    "error": str(e)
                })
        
        return {
            "status": "success" if len(failed) == 0 else "partial",
            "message": f"Uploaded {len(uploaded)} out of {len(files)} file(s)",
            "total_files": len(files),
            "uploaded": uploaded,
            "failed": failed,
            "bucket": bucket_name,
            "plan_number": plan_number,
            "document_type": document_type
        }
        
    except Exception as e:
        logger.error(f"Error in batch upload: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "message": f"Batch upload failed: {str(e)}",
            "local_dir": local_dir_path
        }


async def download_batch_files(
    plan_number: str,
    document_type: str,
    local_dest_dir: str,
    env_config: EnvironmentConfig
) -> Dict[str, Any]:
    """
    Downloads all files for a plan and document type from GCS bucket to local directory.
    
    Args:
        plan_number: Plan number (e.g., "20440")
        document_type: Document type (e.g., "policy", "kod", "procedure")
        local_dest_dir: Path to local directory to save files
        env_config: Environment configuration
    
    Returns:
        Dict with batch download results
    """
    try:
        gcs_utils = GCSUtils(env_config)
        bucket_name = gcs_utils.bucket_name
        bucket = gcs_utils.get_bucket()
        
        # Construct blob path prefix
        blob_prefix = f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/"
        
        logger.info(f"Downloading files from gs://{bucket_name}/{blob_prefix} to {local_dest_dir}")
        
        # Create destination directory
        dest_dir = Path(local_dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)
        
        # List and download all blobs
        blobs = bucket.list_blobs(prefix=blob_prefix)
        
        downloaded = []
        failed = []
        
        for blob in blobs:
            try:
                # Get just the filename
                file_name = blob.name.replace(blob_prefix, "")
                if not file_name:  # Skip the prefix itself
                    continue
                
                local_path = dest_dir / file_name
                blob.download_to_filename(str(local_path))
                
                downloaded.append({
                    "file_name": file_name,
                    "local_path": str(local_path)
                })
                logger.info(f"Downloaded: {file_name} → {local_path}")
                
            except Exception as e:
                logger.error(f"Failed to download {blob.name}: {str(e)}")
                failed.append({
                    "blob_path": blob.name,
                    "error": str(e)
                })
        
        return {
            "status": "success" if len(failed) == 0 else "partial",
            "message": f"Downloaded {len(downloaded)} file(s)",
            "total_downloaded": len(downloaded),
            "downloaded": downloaded,
            "failed": failed,
            "destination_dir": str(dest_dir),
            "bucket": bucket_name,
            "plan_number": plan_number,
            "document_type": document_type
        }
        
    except Exception as e:
        logger.error(f"Error in batch download: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "message": f"Batch download failed: {str(e)}",
            "destination_dir": local_dest_dir
        }
