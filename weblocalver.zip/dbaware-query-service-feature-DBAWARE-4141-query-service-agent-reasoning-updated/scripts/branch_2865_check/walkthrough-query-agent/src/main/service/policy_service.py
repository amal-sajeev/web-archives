"""
Policy Management Service

Handles natural language policy removal commands by:
1. Parsing user intent via LLM
2. Extracting policy IDs to remove
3. Deleting policy files from the policy_docs folder
"""

import json
import os
import logging
from typing import List, Dict, Any
from pathlib import Path
from agent.agent import initialize_gemini_model, _extract_response_text
from agent_helper.env_config import EnvironmentConfig
from agent_helper.prompt_utils import PromptBuilder
from langchain_core.messages import HumanMessage

logger = logging.getLogger(__name__)

# Policy docs base path
POLICY_DOCS_BASE_PATH = Path(__file__).parent.parent / "policy_docs"


def get_available_policies() -> List[int]:
    """
    Scans the policy_docs folder and returns available policy IDs.
    Policy files are expected to be named like: doc_1_*.json, doc_2_*.json, etc.
    """
    if not POLICY_DOCS_BASE_PATH.exists():
        logger.warning(f"Policy docs folder does not exist at {POLICY_DOCS_BASE_PATH}")
        return []
    
    available_policies = []
    for file in POLICY_DOCS_BASE_PATH.iterdir():
        if file.is_file() and file.name.startswith("doc_") and file.name.endswith(".json"):
            try:
                # Extract policy ID from filename: doc_1_*.json -> 1
                parts = file.name.split("_")
                if len(parts) >= 2:
                    policy_id = int(parts[1])
                    available_policies.append(policy_id)
            except ValueError:
                logger.debug(f"Skipping file with non-numeric policy ID: {file.name}")
    
    return sorted(available_policies)


async def parse_policy_command(user_command: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """
    Uses LLM to parse natural language policy management commands.
    
    Args:
        user_command: Natural language command like "exclude policy 1,2,3"
        env_config: Environment configuration for LLM access
    
    Returns:
        Dict with keys:
            - action: "REMOVE" or "KEEP"
            - policy_ids_to_remove: List of policy IDs to remove
            - reasoning: LLM's decision reasoning
    """
    try:
        # Build prompt using the policy management template
        prompt_builder = PromptBuilder(prompt_file_name="policy_prompt.json")
        system_prompt = prompt_builder.build_prompt(user_command=user_command)
        
        # Initialize LLM
        llm = initialize_gemini_model(env_config)
        
        messages = [
            HumanMessage(content=system_prompt)
        ]
        
        logger.info("Invoking LLM to parse policy management command: %s", user_command)
        response = llm.invoke(messages)
        raw_content = _extract_response_text(response).strip()
        
        # Sanitize markdown formatting if present
        if raw_content.startswith("```json"):
            raw_content = raw_content[7:]
        elif raw_content.startswith("```"):
            raw_content = raw_content[3:]
        if raw_content.endswith("```"):
            raw_content = raw_content[:-3]
        raw_content = raw_content.strip()
        
        # Parse JSON response
        llm_decision = json.loads(raw_content)
        
        logger.info("LLM decision: %s", llm_decision)
        return llm_decision
        
    except json.JSONDecodeError as e:
        logger.error("Failed to parse LLM response as JSON: %s", str(e))
        raise ValueError(f"LLM returned invalid JSON: {str(e)}")
    except Exception as e:
        logger.error("Error parsing policy command via LLM: %s", str(e), exc_info=True)
        raise


async def execute_policy_removal(policies_to_remove: List[int]) -> Dict[str, Any]:
    """
    Removes policy files from the policy_docs folder.
    Handles files named doc_X_*.json where X is the policy ID.
    
    Args:
        policies_to_remove: List of policy IDs to remove
    
    Returns:
        Dict with:
            - removed_count: Number of policies successfully removed
            - removed_policies: List of policy IDs that were removed
            - failed_policies: List of policy IDs that failed to remove
    """
    removed = []
    failed = []
    
    for policy_id in policies_to_remove:
        try:
            # Find files matching doc_{policy_id}_*.json pattern
            pattern = f"doc_{policy_id}_*.json"
            matching_files = list(POLICY_DOCS_BASE_PATH.glob(pattern))
            
            if matching_files:
                for policy_file in matching_files:
                    policy_file.unlink()
                    logger.info(f"Removed policy file: {policy_file}")
                removed.append(policy_id)
            else:
                logger.warning(f"Policy file not found for ID {policy_id}")
                failed.append(policy_id)
        except Exception as e:
            logger.error(f"Failed to remove policy {policy_id}: {str(e)}")
            failed.append(policy_id)
    
    return {
        "removed_count": len(removed),
        "removed_policies": removed,
        "failed_policies": failed
    }


async def execute_policy_inclusion(
    policies_to_include: List[int],
    policy_payloads: Dict[int, Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    """
    Sister function to execute_policy_removal.
    Adds or restores policy files in the policy_docs folder (doc_{policy_id}_*.json).
    """
    POLICY_DOCS_BASE_PATH.mkdir(parents=True, exist_ok=True)
    included = []
    failed = []
    payload_map = policy_payloads or {}

    for policy_id in policies_to_include:
        try:
            pattern = f"doc_{policy_id}_*.json"
            matching_files = list(POLICY_DOCS_BASE_PATH.glob(pattern))
            if matching_files:
                included.append(policy_id)
                continue

            target_file = POLICY_DOCS_BASE_PATH / f"doc_{policy_id}_included.json"
            doc_data = payload_map.get(policy_id) or {
                "document_id": str(policy_id),
                "document_title": f"Policy Document {policy_id}",
                "document_type": "policy",
                "status": "active",
                "excluded": False,
            }
            target_file.write_text(json.dumps(doc_data, indent=2), encoding="utf-8")
            logger.info(f"Included policy file: {target_file}")
            included.append(policy_id)
        except Exception as e:
            logger.error(f"Failed to include policy {policy_id}: {str(e)}")
            failed.append(policy_id)

    return {
        "included_count": len(included),
        "included_policies": included,
        "failed_policies": failed,
    }


async def manage_policies(user_command: str, env_config: EnvironmentConfig) -> Dict[str, Any]:
    """
    Main orchestration function for policy management.
    
    Flow:
    1. Parse user command via LLM
    2. Get available policies
    3. Determine which policies to remove based on LLM decision
    4. Execute removal
    5. Return results
    
    Args:
        user_command: Natural language policy management command
        env_config: Environment configuration
    
    Returns:
        Dict with operation results and status
    """
    try:
        # Step 1: Parse command via LLM
        llm_decision = await parse_policy_command(user_command, env_config)
        
        # Step 2: Get available policies
        available_policies = get_available_policies()
        logger.info(f"Available policies: {available_policies}")
        
        # Step 3: Determine policies to remove or include
        action = llm_decision.get("action", "REMOVE").upper()
        extracted_ids = llm_decision.get("policy_ids_to_remove") or llm_decision.get("policy_ids_to_include") or []
        reasoning = llm_decision.get("reasoning", "No reasoning provided")

        if action in {"INCLUDE", "ADD"}:
            inclusion_result = await execute_policy_inclusion(extracted_ids)
            return {
                "status": "success",
                "message": f"Policy management completed. Included {inclusion_result['included_count']} policies.",
                "policies_removed": [],
                "policies_included": inclusion_result["included_policies"],
                "failed_inclusions": inclusion_result["failed_policies"],
                "llm_decision_reasoning": reasoning,
                "action": action,
                "available_policies": get_available_policies(),
                "requested_inclusion_count": len(extracted_ids),
            }
        
        if action == "KEEP":
            # If action is KEEP, remove everything NOT in the list
            policies_to_remove = [p for p in available_policies if p not in extracted_ids]
            logger.info(f"KEEP action: Will remove policies not in the keep list: {policies_to_remove}")
        else:
            # REMOVE action: remove what's in the list
            policies_to_remove = extracted_ids
            logger.info(f"REMOVE action: Will remove policies: {policies_to_remove}")
        
        # Step 4: Validate extracted IDs are available
        invalid_ids = [p for p in policies_to_remove if p not in available_policies]
        if invalid_ids:
            logger.warning(f"Some policies to remove do not exist: {invalid_ids}")
        
        valid_policies_to_remove = [p for p in policies_to_remove if p in available_policies]
        
        # Step 5: Execute removal
        removal_result = await execute_policy_removal(valid_policies_to_remove)
        
        return {
            "status": "success",
            "message": f"Policy management completed. Removed {removal_result['removed_count']} policies.",
            "policies_removed": removal_result["removed_policies"],
            "failed_removals": removal_result["failed_policies"],
            "llm_decision_reasoning": reasoning,
            "action": action,
            "available_policies": available_policies,
            "requested_removal_count": len(policies_to_remove)
        }
        
    except Exception as e:
        logger.error(f"Error in policy management flow: {str(e)}", exc_info=True)
        return {
            "status": "error",
            "message": f"Policy management failed: {str(e)}",
            "policies_removed": [],
            "failed_removals": [],
            "llm_decision_reasoning": ""
        }
