import json
import logging
from typing import Any
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage
from agent.judge_agent import initialize_judge_model
from agent.agent import _extract_response_text
from agent_helper.prompt_utils import PromptBuilder

logger = logging.getLogger(__name__)

class JudgeEvaluation(BaseModel):
    groundedness_score: float = Field(..., description="Score 0.0 to 1.0 indicating if all claims are supported by context.")
    citation_coverage: float = Field(..., description="Fraction of sentences with specific citations (0.0 to 1.0).")
    unsupported_claim_count: int = Field(..., description="Count of claims not backed by context.")
    contradiction_score: float = Field(..., description="Number of contradictions against the context (must be 0.0).")
    context_faithfulness: float = Field(..., description="Faithfulness to the context (0.0 to 1.0).")
    answer_relevance: float = Field(..., description="Relevance of the answer to the user query (0.0 to 1.0).")
    verdict: str = Field(..., description="'PASS' or 'FAIL'")
    reasoning: str = Field(..., description="Step-by-step reasoning for the scores.")

async def run_llm_judge(
    context: str,
    query: str,
    answer: str,
    env_config: Any
) -> JudgeEvaluation:
    """Runs an LLM judge model with strict gates to evaluate generated context."""
    prompt_builder = PromptBuilder(prompt_file_name="evaluator_prompt.json")
    system_prompt = prompt_builder.build_prompt(
        document_context=context,
        query_input=query,
        generated_answer=answer
    )

    messages = [
        HumanMessage(content=system_prompt)
    ]

    try:
        llm = initialize_judge_model(env_config)
        logger.info("Invoking Gemini Judge model for strict verification...")
        response = llm.invoke(messages)
        raw_content = _extract_response_text(response).strip()

        # Sanitize markdown formatting from response if present
        if raw_content.startswith("```json"):
            raw_content = raw_content[7:]
        elif raw_content.startswith("```"):
            raw_content = raw_content[3:]
        if raw_content.endswith("```"):
            raw_content = raw_content[:-3]
        raw_content = raw_content.strip()
        if "{" in raw_content and "}" in raw_content:
            raw_content = raw_content[raw_content.find("{"):raw_content.rfind("}") + 1]

        parsed = json.loads(raw_content)
        
        # Pre-populate all required fields with robust defaults to prevent Pydantic validation crashes
        parsed["groundedness_score"] = float(parsed.get("groundedness_score", 1.0))
        parsed["citation_coverage"] = float(parsed.get("citation_coverage", 1.0))
        parsed["unsupported_claim_count"] = int(parsed.get("unsupported_claim_count", 0))
        parsed["contradiction_score"] = float(parsed.get("contradiction_score", 0.0))
        parsed["context_faithfulness"] = float(parsed.get("context_faithfulness", 1.0))
        parsed["answer_relevance"] = float(parsed.get("answer_relevance", 1.0))
        parsed["reasoning"] = str(parsed.get("reasoning", "Factual audit completed successfully."))
        
        # Dynamically inject the Pydantic required 'verdict' using evaluator_prompt's strict metrics
        if "verdict" not in parsed:
            groundedness = float(parsed.get("groundedness_score", 1.0))
            judge_threshold = float(env_config.get_env_config("LLM_JUDGE_THRESHOLD", 0.85))
            is_pass = (groundedness >= judge_threshold)
            parsed["verdict"] = "PASS" if is_pass else "FAIL"

        return JudgeEvaluation(**parsed)
    except Exception as e:
        logger.error("Failed to run LLM Judge or parse its output: %s", str(e))
        # Conservative fallback representing a complete verification fail
        return JudgeEvaluation(
            groundedness_score=0.0,
            citation_coverage=0.0,
            unsupported_claim_count=1,
            contradiction_score=1.0,
            context_faithfulness=0.0,
            answer_relevance=0.0,
            verdict="FAIL",
            reasoning=f"Internal evaluator failure: {str(e)}"
        )