import logging
from typing import Any, Dict, List, Optional

from agent_helper.utils import GCSUtils

logger = logging.getLogger(__name__)

# In-memory cache for plan-level operational inbound documents: { plan_number: { category_name: markdown_str } }
PLAN_INBOUND_CACHE: Dict[str, Dict[str, str]] = {}


def _load_optional_blob_markdown(gcs_utils: GCSUtils, blob_path: str, section_title: str) -> Optional[str]:
    """Helper to check blob existence, read JSON, and return formatted markdown with detailed logging."""
    from service.qna_service import convert_json_to_markdown

    logger.info("🔍 Checking existence of optional artifact: gs://%s/%s", gcs_utils.bucket_name, blob_path)
    if not gcs_utils.blob_exists(blob_path):
        logger.info("⏭️ Optional artifact NOT found at %s. Skipping.", blob_path)
        return None
    try:
        logger.info("📥 Downloading and parsing optional artifact: %s", blob_path)
        data = gcs_utils.read_blob_json(blob_path)
        data_type = type(data).__name__
        data_size = len(data) if isinstance(data, (dict, list)) else 1
        md_content = convert_json_to_markdown(data)
        logger.info("✅ Successfully loaded '%s' (%s with %d elements, %d chars markdown)", section_title, data_type, data_size, len(md_content))
        return f"\n\n## {section_title}\n{md_content}"
    except Exception as e:
        logger.warning("⚠️ Failed to load optional artifact at %s: %s", blob_path, str(e))
        return None


def _load_preliminary_research_context(gcs_utils: GCSUtils, plan_number: str) -> tuple[Dict[str, Any], List[str]]:
    """
    Loads modular preliminary research files: past_review.json, policy_regulation.json, broad_scope.json.
    Falls back to legacy preliminary-research.json if new files are not present.
    """
    from service.qna_service import convert_json_to_markdown

    prelim_dir = f"dbaware_review_{plan_number}/processing-data/preliminary-research"
    target_files = [
        ("past_review.json", "PAST REVIEW RESEARCH"),
        ("policy_regulation.json", "POLICY & REGULATION RESEARCH"),
        ("broad_scope.json", "BROAD SCOPE RESEARCH"),
    ]

    combined_raw: Dict[str, Any] = {}
    doc_blocks: List[str] = []

    for filename, display_title in target_files:
        blob_path = f"{prelim_dir}/{filename}"
        if gcs_utils.blob_exists(blob_path):
            try:
                payload = gcs_utils.read_blob_json(blob_path)
                combined_raw[filename.replace(".json", "")] = payload
                md = convert_json_to_markdown(payload)
                doc_blocks.append(f"\n## {display_title} ({filename})\n{md}")
                logger.info("✅ Loaded preliminary research artifact: %s (%d chars)", filename, len(md))
            except Exception as e:
                logger.warning("⚠️ Failed reading preliminary artifact %s: %s", blob_path, str(e))

    if not doc_blocks:
        legacy_path = f"{prelim_dir}/preliminary-research.json"
        if gcs_utils.blob_exists(legacy_path):
            try:
                payload = gcs_utils.read_blob_json(legacy_path)
                combined_raw = payload if isinstance(payload, dict) else {"legacy": payload}
                md = convert_json_to_markdown(payload)
                doc_blocks.append(f"\n## PRIMARY STAGE SUMMARY (preliminary-research.json)\n{md}")
                logger.info("✅ Loaded legacy preliminary-research.json (%d chars)", len(md))
            except Exception as e:
                logger.warning("⚠️ Failed reading legacy preliminary-research.json: %s", str(e))

    return combined_raw, doc_blocks


def compact_inbound_json(data: Any, file_name: str) -> str:
    """Extracts essential text content and strips out scoring or search metadata."""
    from service.qna_service import convert_json_to_markdown

    if not isinstance(data, dict):
        return convert_json_to_markdown(data, depth=3)
    doc_title = data.get("document_title", file_name)
    if "nodes" in data and isinstance(data["nodes"], list):
        sections = [f"### Document: {doc_title}"]
        for node in data["nodes"]:
            sec_id = node.get("section_id", "")
            sec_title = node.get("section_title", "")
            orig_text = str(node.get("original_text", "")).strip()
            header = f"#### Section {sec_id}: {sec_title}".strip()
            if header != "####":
                sections.append(header)
            if orig_text:
                sections.append(orig_text)
        return "\n\n".join(sections)
    return f"### Document: {doc_title}\n" + convert_json_to_markdown(data, depth=3)


def load_and_cache_all_inbound_data(gcs_utils: GCSUtils, plan_number: str) -> Dict[str, str]:
    """
    Pre-ingests and caches operational files under inbound-data/ (dbaware, dbgrc, gfms, group_audit, lrr).
    Explicitly excludes 'policy/' to protect token limits.
    """
    if plan_number in PLAN_INBOUND_CACHE:
        logger.info("⚡ Serving operational inbound data from plan cache for plan %s (%d categories).", plan_number, len(PLAN_INBOUND_CACHE[plan_number]))
        return PLAN_INBOUND_CACHE[plan_number]

    inbound_prefix = f"dbaware_review_{plan_number}/inbound-data/"
    categorized_docs: Dict[str, str] = {}
    allowed_categories = {"dbaware", "dbgrc", "gfms", "group_audit", "lrr", "llr"}

    try:
        bucket = gcs_utils.get_bucket()
        blobs = list(bucket.list_blobs(prefix=inbound_prefix))
    except Exception as e:
        logger.warning("Could not access GCS bucket to scan inbound data for plan %s: %s", plan_number, str(e))
        return categorized_docs

    folder_blobs: Dict[str, List[Any]] = {}
    for blob in blobs:
        if blob.name.endswith("/") or not blob.name.endswith(".json"):
            continue
        rel_path = blob.name[len(inbound_prefix):]
        parts = rel_path.split("/")
        category_key = parts[0].lower() if len(parts) > 1 else "general"

        # Exclude policy directory (reserved for RAG)
        if category_key == "policy" or "policy" in parts:
            continue

        if category_key in allowed_categories or category_key == "general":
            folder_blobs.setdefault(category_key, []).append(blob)

    logger.info("📂 Discovered %d operational inbound category(ies) for plan %s: %s", len(folder_blobs), plan_number, list(folder_blobs.keys()))

    for cat_key, blob_list in folder_blobs.items():
        cat_sections = []
        for b in blob_list:
            file_name = b.name.split("/")[-1]
            try:
                payload = gcs_utils.read_blob_json(b.name)
                compact_text = compact_inbound_json(payload, file_name)
                cat_sections.append(compact_text)
                logger.info("✅ Cached inbound artifact [%s] %s (%d chars)", cat_key, file_name, len(compact_text))
            except Exception as read_err:
                logger.warning("Failed reading inbound blob %s: %s", b.name, str(read_err))
        if cat_sections:
            categorized_docs[cat_key] = "\n\n".join(cat_sections)

    PLAN_INBOUND_CACHE[plan_number] = categorized_docs
    return categorized_docs


def classify_query_inbound_category(query: str, available_categories: List[str]) -> List[str]:
    """Classifies user query to determine which operational category to inject into prompt."""
    q = query.lower()
    matched = []
    for cat in available_categories:
        clean_cat = cat.lower().replace("_", " ")
        if any(token in q for token in clean_cat.split() if len(token) > 2):
            matched.append(cat)

    if not matched:
        if any(k in q for k in ["alc", "nalc", "historical plan", "old scoping", "plan details", "scoping"]):
            matched = [c for c in available_categories if c == "dbaware"]
        elif any(k in q for k in ["control", "dbgrc", "operating owner", "design owner", "irc-cd"]):
            matched = [c for c in available_categories if c == "dbgrc"]
        elif any(k in q for k in ["finding", "gfms", "remediation", "action plan", "issue"]):
            matched = [c for c in available_categories if c == "gfms"]
        elif any(k in q for k in ["group audit", "audit details", "internal audit"]):
            matched = [c for c in available_categories if c == "group_audit"]
        elif any(k in q for k in ["internet search", "external research", "lrr", "llr", "statutory", "regulation"]):
            matched = [c for c in available_categories if c in ("lrr", "llr")]

    if not matched and any(k in q for k in ["all", "inbound", "operational data", "everything"]):
        return available_categories

    return matched