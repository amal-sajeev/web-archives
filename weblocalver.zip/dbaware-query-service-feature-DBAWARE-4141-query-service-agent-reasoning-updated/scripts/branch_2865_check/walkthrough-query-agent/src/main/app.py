import sys
from pathlib import Path
from contextlib import asynccontextmanager
import os

# Dynamic path adjustments to support clean internal sourcing
project_root = Path(__file__).resolve().parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging
from agent_helper.env_config import EnvironmentConfig

env_var = os.getenv('ENV_NAME', 'dev')
env_config = EnvironmentConfig(env_var)

from service.router import router as qna_router

logging.basicConfig(level=logging.INFO, format='%(asctime)s : %(levelname)s [%(name)s] => %(message)s', stream=sys.stdout)

logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing configurations on FastAPI server startup...")
    # Load local configurations and map network proxies & CA certs
    env_config = EnvironmentConfig(env_var)
    yield

app = FastAPI(
    title="Q&A Intelligence Service",
    description="High-performance session-based Q&A engine for structural document summaries using Gemini 2.5 Flash",
    version="1.0.0",
    lifespan=lifespan,
    root_path="/query-service"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8080",
        "http://127.0.0.1:8080",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register the Q&A Endpoint router module
app.include_router(qna_router)

if __name__ == "__main__":
    port = 8010
    logger.info(f"Starting Policy Mapping server on http://127.0.0.1:{port}")
    uvicorn.run("app:app", host="127.0.0.1", port=port, reload=True)