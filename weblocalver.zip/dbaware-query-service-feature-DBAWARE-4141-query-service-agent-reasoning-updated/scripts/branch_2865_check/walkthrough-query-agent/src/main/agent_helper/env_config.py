import os
import yaml
import logging
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class EnvironmentConfig:
    """
    Manages hierarchical environment properties loaded from:
      1. Base common constants in 'app.yaml'
      2. Environment-specific overrides in '{env_name}/env.yaml'
      3. System OS environment variables (highest priority)
    """
    def __init__(self, env_name: Optional[str] = None):
        self.env_name = env_name or os.getenv("ENV_NAME") or "dev"
        self._env_config_data: Dict[str, Any] = {}
        self._app_config_data: Dict[str, Any] = {}
        self._load_config()

    def _resolve_config_dir(self) -> Path:
        """Resolves the configuration directory across local and containerized execution paths."""
        # 1. Standard module path: src/main/config
        config_dir = Path(__file__).resolve().parent.parent / "config"
        if config_dir.exists() and config_dir.is_dir():
            return config_dir

        # 2. Project root path fallback
        config_dir = Path(__file__).resolve().parent.parent.parent.parent / "config"
        if config_dir.exists() and config_dir.is_dir():
            return config_dir

        # 3. Sibling fallback
        return Path(__file__).resolve().parent / "config"

    def _load_config(self):
        """Loads and merges app.yaml and {env_name}/env.yaml."""
        config_dir = self._resolve_config_dir()

        # 1. Load common base application settings (app.yaml)
        app_yaml_path = config_dir / "app.yaml"
        if app_yaml_path.exists():
            try:
                with open(app_yaml_path, "r", encoding="utf-8") as f:
                    loaded_app = yaml.safe_load(f) or {}
                    if isinstance(loaded_app, dict):
                        self._app_config_data = loaded_app
                        self._env_config_data.update(loaded_app)
                logger.info(f"Loaded common base configurations from {app_yaml_path}")
            except Exception as e:
                logger.error(f"Failed to load base app.yaml from {app_yaml_path}: {e}", exc_info=True)

        # 2. Load environment-specific overrides ({env_name}/env.yaml)
        if self.env_name:
            env_yaml_path = config_dir / self.env_name / "env.yaml"
            if env_yaml_path.exists():
                try:
                    with open(env_yaml_path, "r", encoding="utf-8") as f:
                        env_data = yaml.safe_load(f) or {}
                        if isinstance(env_data, dict):
                            self._env_config_data.update(env_data)
                    logger.info(f"Loaded configurations for environment '{self.env_name}' from {env_yaml_path}")
                    return
                except Exception as e:
                    logger.error(f"Failed to load environment YAML from {env_yaml_path}: {e}", exc_info=True)

        # 3. Fallback: check legacy flat config/env.yaml keyed by environment name
        legacy_yaml_path = config_dir / "env.yaml"
        if legacy_yaml_path.exists():
            try:
                with open(legacy_yaml_path, "r", encoding="utf-8") as f:
                    all_data = yaml.safe_load(f) or {}
                    legacy_env_data = all_data.get(self.env_name, {})
                    if isinstance(legacy_env_data, dict):
                        self._env_config_data.update(legacy_env_data)
                logger.info(f"Loaded legacy fallback configurations for environment '{self.env_name}' from {legacy_yaml_path}")
            except Exception as e:
                logger.error(f"Failed to load legacy environment YAML: {e}", exc_info=True)
        else:
            logger.warning(f"No environment config found for '{self.env_name}'. Relying on base YAML and system environment variables.")

    @staticmethod
    def _cast_value_like(raw_val: str, reference: Any) -> Any:
        """Casts string OS environment variable to match the type of the target reference value."""
        if reference is None:
            return raw_val
        if isinstance(reference, bool):
            return raw_val.strip().lower() in ("true", "1", "yes")
        if isinstance(reference, int) and not isinstance(reference, bool):
            try:
                return int(raw_val)
            except ValueError:
                return raw_val
        if isinstance(reference, float):
            try:
                return float(raw_val)
            except ValueError:
                return raw_val
        return raw_val

    def get_env_config(self, key: str, default: Any = None) -> Any:
        """
        Gets configuration value from the merged config dataset.
        Honors system OS environment variables first, falling back to merged YAML data,
        and finally to the provided default.
        """
        if key in os.environ:
            raw_val = os.environ[key]
            yaml_val = self._env_config_data.get(key, default)
            return self._cast_value_like(raw_val, yaml_val)
        return self._env_config_data.get(key, default)

    def get_app_config(self, key: str, default: Any = None) -> Any:
        """
        Fetches non-environmental, business-logic related application configurations.
        """
        if key in os.environ:
            raw_val = os.environ[key]
            ref_val = self._app_config_data.get(key, self._env_config_data.get(key, default))
            return self._cast_value_like(raw_val, ref_val)

        if key in self._app_config_data:
            return self._app_config_data[key]

        app_section = self._env_config_data.get("APP_CONFIG", {})
        if isinstance(app_section, dict):
            return app_section.get(key, default)

        return self._env_config_data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        val = self.get_env_config(key)
        if val is None:
            raise KeyError(f"Configuration key '{key}' not found.")
        return val
