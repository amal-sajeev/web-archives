import os
import uuid
import logging
from datetime import datetime
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


DEFAULT_ACTOR_ID = "query-agent"
DEFAULT_PARENT_ENTITY_TYPE = "SCOPING"
DEFAULT_ACTION_TYPE = "QUERY"
DEFAULT_ENTITY_TYPE = "QUESTION_AND_ANSWER"
DEFAULT_ACTIVITY_TYPE = "EMAIL"
DEFAULT_ACTOR_TYPE = "AI_AGENT"

HUMAN_ACTOR_TYPE="HUMAN"
HUMAN_ACTOR_ID="dbaware@db.com"
def _resolve_actor_id() -> str:
    return os.getenv("ACTOR_ID") or "query-agent"


def _resolve_environment() -> str:
    return os.getenv("ENVIRONMENT") or os.getenv("ENV") or "dev"


def _resolve_service_version() -> str:
    return os.getenv("SERVICE_VERSION") or "unknown"


def _to_screaming_snake_case(value: str | None) -> str:
    if not value:
        return ""
    return str(value).strip().replace(" ", "_").replace("-", "_").upper()


def build_agent_card(
        plan_item_number: Optional[str] = None,
        activity_type: str | None=None,
        query: str| None=None,
        activity_id: str = "qna-preliminary-research",
        parent_entity_type: str | None = None,
        parent_entity_id: str | None = None,
        status: str = "SUCCESS",
        correlation_id: str | None = None,
        duration_ms: int | None = None,
        error_message: str | None = None,
        metadata: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    actor_id = _resolve_actor_id()
    resolved_parent_entity_type = _to_screaming_snake_case(parent_entity_type or DEFAULT_PARENT_ENTITY_TYPE)
    resolved_parent_entity_id = parent_entity_id or (str(plan_item_number) if plan_item_number else "query-service")
    resolved_correlation_id = correlation_id or str(uuid.uuid4())
    timestamp = datetime.utcnow().isoformat() + "Z"
    environment = _resolve_environment()
    service_version = _resolve_service_version()

    agent_card = {
        "ACTOR_ID": actor_id,
        "ACTIVITY_ID": activity_id,
        "ENTITY_ID": str(uuid.uuid5(uuid.NAMESPACE_DNS, str(plan_item_number))),
        "PARENT_ENTITY_TYPE": resolved_parent_entity_type,
        "PARENT_ENTITY_ID": resolved_parent_entity_id,
        "ACTIVITY_TYPE": _to_screaming_snake_case(activity_type),
        "ENTITY_TYPE": DEFAULT_ENTITY_TYPE,
        "QUERY": query,
        "STATUS": status,
        "TIMESTAMP": timestamp,
        "ENVIRONMENT": environment,
        "SERVICE_VERSION": service_version,
        "CORRELATION_ID": resolved_correlation_id
    }

    # Add optional fields only if provided
    if duration_ms is not None:
        agent_card["DURATION_MS"] = duration_ms
    if error_message and status != "SUCCESS":
        agent_card["ERROR_MESSAGE"] = error_message

    # Add metadata for technical details (model, hyperparameters, etc.)
    if metadata:
        agent_card["METADATA"] = metadata

    logger.info("=== AGENT CARD GENERATED ===")
    for key, value in agent_card.items():
        if key != "METADATA":
            logger.info(f"{key}: {value}")
        else:
            logger.info(f"{key}: {value}")
    logger.info("============================+")

    return agent_card
