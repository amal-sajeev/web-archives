import json
import logging
from pathlib import Path
from typing import Any
from google.api_core.exceptions import NotFound
from google.cloud import storage


logger = logging.getLogger(__name__)

class GCSUtils:
    """
    Utility handler for interacting with Google Cloud Storage bucket.
    Integrates with ABC's EnvironmentConfig system.
    """
    def __init__(self, env_config):
        self.config = env_config
        self.project_id = self.config.get_env_config("GCP_PROJECT_ID")
        self.bucket_name = self.config.get_env_config("GCS_BUCKET_NAME")
        self._client = None

    @property
    def client(self) -> storage.Client:
        if self._client is None:
            logger.debug("Initializing GCS storage client project=%s", self.project_id)
            self._client = storage.Client(project=self.project_id)
        return self._client

    def get_bucket(self) -> storage.Bucket:
        bucket = self.client.bucket(self.bucket_name)
        logger.debug("Using GCS bucket name=%s", self.bucket_name)
        return bucket

    def blob_exists(self, blob_path: str) -> bool:
        bucket = self.get_bucket()
        exists = bucket.blob(blob_path).exists()
        logger.debug("Blob exists check path=%s exists=%s", blob_path, exists)
        return exists

    def read_blob_text(self, blob_path: str) -> str:
        bucket = self.get_bucket()
        blob = bucket.blob(blob_path)
        try:
            data = blob.download_as_text(encoding="utf-8")
        except NotFound as exc:
            raise FileNotFoundError(f"Blob not found: gs://{self.bucket_name}/{blob_path}") from exc
        logger.info("Read blob path=%s size=%s", blob_path, len(data))
        return data

    def read_blob_json(self, blob_path: str) -> Any:
        raw = self.read_blob_text(blob_path)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Blob is not valid JSON path=%s", blob_path)
            return raw

    def write_blob_json(self, blob_path: str, payload: Any) -> str:
        bucket = self.get_bucket()
        blob = bucket.blob(blob_path)
        body = json.dumps(payload, indent=2, ensure_ascii=False, default=str)
        blob.upload_from_string(body, content_type="application/json")
        uri = f"gs://{self.bucket_name}/{blob_path}"
        logger.info("Wrote JSON blob uri=%s", uri)
        return uri

    def upload_file(self, local_file_path: str, dest_blob_path: str, content_type: str = "application/octet-stream") -> str:
        """Uploads a local file directly to a GCS blob."""
        bucket = self.get_bucket()
        blob = bucket.blob(dest_blob_path)
        blob.upload_from_filename(local_file_path, content_type=content_type)
        uri = f"gs://{self.bucket_name}/{dest_blob_path}"
        logger.info("Uploaded local file '%s' to GCS blob '%s'", local_file_path, uri)
        return uri

    def download_file(self, blob_path: str, dest_local_path: str):
        """Downloads a GCS blob directly to a local path."""
        bucket = self.get_bucket()
        blob = bucket.blob(blob_path)
        try:
            blob.download_to_filename(dest_local_path)
            logger.info("Downloaded GCS blob 'gs://%s/%s' to '%s'", self.bucket_name, blob_path, dest_local_path)
        except NotFound as exc:
            raise FileNotFoundError(f"Blob not found: gs://{self.bucket_name}/{blob_path}") from exc