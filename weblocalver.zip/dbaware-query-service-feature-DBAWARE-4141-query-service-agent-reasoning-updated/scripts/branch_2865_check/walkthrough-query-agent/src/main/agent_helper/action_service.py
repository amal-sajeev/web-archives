from datetime import datetime, timezone
from typing import Optional, Dict, Any
import logging
import os
import json
import uuid
from agent_helper.env_config import EnvironmentConfig
from constant.query_constant import QueryActionConstant
import site
import sys

logger = logging.getLogger(__name__)

# Initialize global environment config
env_var = os.getenv('ENV_NAME', 'dev')
env_config = EnvironmentConfig(env_var)


# Stash any already imported local 'config' modules so ActionServiceClt can load
# the wheel's config.dev package from dependencies without collision.
_stashed_config_modules = {
    name: mod for name, mod in list(sys.modules.items())
    if name == "config" or name.startswith("config.")
}
for name in _stashed_config_modules:
    sys.modules.pop(name, None)

_site_packages = site.getsitepackages() if hasattr(site, "getsitepackages") else []
if hasattr(site, "getusersitepackages"):
    user_site = site.getusersitepackages()
    if isinstance(user_site, str):
        _site_packages.append(user_site)
    elif isinstance(user_site, (list, tuple)):
        _site_packages.extend(user_site)
_sys_site_packages = [p for p in sys.path if "site-packages" in p or "dist-packages" in p]
# Support custom container dependency paths like /opt/python-deps or PYTHONPATH entries
_custom_dep_paths = [
    path for path in [
        "/opt/python-deps",
        *os.getenv("PYTHONPATH", "").split(os.pathsep)
    ]
    if path and os.path.isdir(path)
]
_target_dep_paths = [
    p for p in list(dict.fromkeys(_custom_dep_paths + _sys_site_packages + _site_packages))
    if os.path.isdir(p)
]

_saved_sys_path = list(sys.path)

try:
    # Put dependency directories at the top of sys.path for action client initialization
    for sp in reversed(_target_dep_paths):
        while sp in sys.path:
            sys.path.remove(sp)
        sys.path.insert(0, sp)

    try:
        from action_client import ActionServiceClt

        env = os.getenv("ENV_NAME", "dev")
        action_clt = ActionServiceClt()
    except Exception as ex:
        logger.warning(
            "Could not initialize ActionServiceClt (%s). Falling back to dummy action client.",
            ex,
        )

        class _DummyActionClient:
            def persist_action(self, fn):
                return fn

        action_clt = _DummyActionClient()
finally:
    # Restore sys.path and restore local config module cache
    sys.path[:] = _saved_sys_path
    # Retain the loaded config.dev subpackage if present
    dev_submod = sys.modules.get("config.dev")
    sys.modules.update(_stashed_config_modules)
    if dev_submod is not None:
        sys.modules["config.dev"] = dev_submod
        if "config" in sys.modules and hasattr(sys.modules["config"], "__path__"):
            for sp in _target_dep_paths:
                candidate = os.path.join(sp, "config")
                if os.path.isdir(candidate) and candidate not in sys.modules["config"].__path__:
                    sys.modules["config"].__path__.append(candidate)


def _get_prompt_version(filename: str = "qna_prompt.json") -> str:
    """Helper to read prompt version dynamically from prompts directory."""
    try:
        # Resolves path relative to service file down to main/etc/prompts/
        base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        prompt_path = os.path.join(base_path, "etc", "prompts", filename)
        if os.path.exists(prompt_path):
            with open(prompt_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return str(data.get("version", "0.1"))
    except FileNotFoundError:
        logger.warning("Prompt file not found: %s", filename)
    except json.JSONDecodeError as e:
        logger.warning("Failed to parse JSON from %s: %s", filename, e)
    except Exception as e:
        logger.warning("An unexpected error occurred while parsing prompt version from %s: %s", filename, e)
    return "0.1"


qna_prompt_version = _get_prompt_version("qna_prompt.json")
evaluator_prompt = _get_prompt_version("evaluator_prompt.json")
agent_prompt = _get_prompt_version("agent_prompt.json")

STAGE_ACTIVITY_CONFIG = {
    "preliminary research walkthrough": ("qna-preliminary-research", "PRELIMINARY_RESEARCH"),
    "preliminary research": ("qna-preliminary-research", "PRELIMINARY_RESEARCH"),
    "preliminary": ("qna-preliminary-research", "PRELIMINARY_RESEARCH_WALKTHROUGH"),
    "discovery walkthrough": ("qna-discovery-walkthrough", "DISCOVERY_WALKTHROUGH"),
    "discovery": ("qna-discovery-walkthrough", "DISCOVERY_WALKTHROUGH"),
    "scope recommendation": ("qna-scope-recommendation", "SCOPE_RECOMMENDATION"),
    "outscope": ("qna-scope-recommendation", "SCOPE_RECOMMENDATION"),
    "test steps": ("qna-test-steps", "TEST_STEPS"),
    "test-steps": ("qna-test-steps", "TEST_STEPS"),
}


def resolve_activity_details(context_type: Optional[str]) -> tuple[str, str]:
    if not context_type:
        return "qna-preliminary-research", "PRELIMINARY_RESEARCH_WALKTHROUGH"

    normalized = context_type.strip().lower()
    if normalized in STAGE_ACTIVITY_CONFIG:
        return STAGE_ACTIVITY_CONFIG[normalized]

    slug = normalized.replace(" ", "-").replace("_", "-")
    activity_id = f"qna-{slug}"
    activity_type = context_type.strip().replace(" ", "_").replace("-", "_").upper()
    return activity_id, activity_type


def _to_screaming_snake_case(value: str | None) -> str:
    if not value:
        return ""
    return str(value).strip().replace(" ", "_").replace("-", "_").upper()


@action_clt.persist_action
def call_to_action_service(json_data):

    logger.info(f'********* in call_to_action_service json data = {json_data}')
    return json_data


def construct_cta_action_record(agent_card, action_type: str, actor_type: str, actor_id: str, activity_type: str, payload: Dict[str,str]):
    logger.info(f"inside construct_cta_action_record agent_card = {agent_card}, action_type = {action_type}, "
                f" actor_type = {actor_type}, actor_id= {actor_id}, activity_type = {activity_type} ")

    now_utc = datetime.now(timezone.utc)
    create_ts = now_utc.isoformat()
    plan_number = agent_card.get('PARENT_ENTITY_ID', 0)

    if actor_id is None:
        actor_id = agent_card.get('ACTOR_ID', "notification-noir-agent")
    json_data = {
        "CTA_ACTION": {
            QueryActionConstant.ActionHistoryFields.action_id.value: None,
            QueryActionConstant.ActionHistoryFields.entity_id.value: agent_card.get('ENTITY_ID', str(uuid.uuid5(uuid.NAMESPACE_DNS, plan_number))),
            QueryActionConstant.ActionHistoryFields.entity_type.value: _to_screaming_snake_case(agent_card.get('ENTITY_TYPE', "QUESTION_AND_ANSWER")),
            QueryActionConstant.ActionHistoryFields.create_ts.value: create_ts,
            QueryActionConstant.ActionHistoryFields.insert_ts.value: None,
            QueryActionConstant.ActionHistoryFields.actor_type.value: actor_type,
            QueryActionConstant.ActionHistoryFields.actor_id.value: actor_id,
            QueryActionConstant.ActionHistoryFields.action_type.value: action_type,
            QueryActionConstant.ActionHistoryFields.parent_entity_type.value: _to_screaming_snake_case(agent_card.get("PARENT_ENTITY_TYPE", "SCOPING")),
            QueryActionConstant.ActionHistoryFields.parent_entity_id.value: agent_card.get("PARENT_ENTITY_ID", plan_number),
            QueryActionConstant.ActionHistoryFields.activity_type.value: _to_screaming_snake_case(activity_type),
            "payload": payload
        }
    }
    logger.info(f"ACTION_TYPE={action_type}")
    return json_data


def construct_human_actor_record(agent_card, query, context_type):
    logger.info(f"in construct_human_actor_record agent_card = {agent_card} query = {query}, context_type = {context_type}")
    payload = {
        QueryActionConstant.Payload.Human_Notes.value: query,
        QueryActionConstant.Payload.Remarks.value: "",
     }

    json_data = construct_cta_action_record(agent_card=agent_card,
                                            action_type="QUERY",
                                            actor_type="HUMAN",
                                            actor_id=getattr(QueryActionConstant.HUMAN_ACTOR_ID, "value", QueryActionConstant.HUMAN_ACTOR_ID),
                                            activity_type=context_type,
                                            payload=payload)
    call_to_action_service(json_data)


def construct_ai_actor_record(agent_card,
                              env_config,
                              total_input_tokens,
                              total_output_tokens,
                              final_answer,
                              start_time,
                              end_time, score, reasoning, context_type, response_code):

    logger.info(f" INSIDE construct_ai_actor_record agent_card= {agent_card} total_input_tokens = {total_input_tokens},"
                f" total_output_tokens = {total_output_tokens}, final_answer = {final_answer}, start_time = {start_time},"
                f" end_time = {end_time}, score = {score}, reasoning = {reasoning}, context_type={context_type}, response_code = {response_code}")

    model_name = env_config.get_env_config("GCP_MODEL_NAME", "gemini-2.5-pro")
    model_version = model_name.split('-', 1)[1]

    payload = {
        QueryActionConstant.Payload.Agent_Name.value: 'query_agent',
        QueryActionConstant.Payload.Action_type.value: 'RESPONSE',
        QueryActionConstant.Payload.AI_Model_Name.value: model_name,
        QueryActionConstant.Payload.AI_Model_Version.value: model_version,
        QueryActionConstant.Payload.AI_Model_Config_Setting.value:
            {
                QueryActionConstant.Payload.model_temperature.value: env_config.get_env_config("MODEL_TEMPERATURE", 0.0),
                QueryActionConstant.Payload.model_top_p.value: env_config.get_env_config("MODEL_TOP_P", 0.0),
                QueryActionConstant.Payload.model_top_k.value: env_config.get_env_config("MODEL_TOP_K", 0),
                QueryActionConstant.Payload.seed.value: "",
                QueryActionConstant.Payload.thinking_budget.value: ""
            },
        QueryActionConstant.Payload.Prompt_Version.value: {
                "qna_prompt": qna_prompt_version,
                "evaluator_prompt": evaluator_prompt,
                "agent_prompt": agent_prompt
            },
        QueryActionConstant.Payload.AI_Rationale.value: reasoning,
        QueryActionConstant.Payload.AI_Confidence_Score.value:  score,
        QueryActionConstant.Payload.Token_Input_Count.value: total_input_tokens if total_input_tokens > 0 else 0,
        QueryActionConstant.Payload.Token_Output_Count.value: total_output_tokens if total_output_tokens > 0 else 0,
        QueryActionConstant.Payload.Response_Code.value: response_code,
        QueryActionConstant.Payload.Response_Text.value: final_answer,
        QueryActionConstant.Payload.Execution_Start_Time.value: str(start_time),
        QueryActionConstant.Payload.Execution_End_Time.value: str(end_time),
        QueryActionConstant.Payload.Remarks.value: ""
        }

    json_data = construct_cta_action_record(agent_card=agent_card,
                                            action_type="RESPONSE",
                                            actor_type="AI_AGENT",
                                            actor_id=getattr(QueryActionConstant.DEFAULT_ACTOR_ID, "value", QueryActionConstant.DEFAULT_ACTOR_ID),
                                            activity_type=context_type,
                                            payload=payload)
    # calling call_to_action_service
    call_to_action_service(json_data)
