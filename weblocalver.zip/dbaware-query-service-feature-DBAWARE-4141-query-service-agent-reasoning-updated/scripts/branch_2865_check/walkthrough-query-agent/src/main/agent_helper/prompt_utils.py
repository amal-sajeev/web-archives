import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
import logging

logger = logging.getLogger(__name__)

class PromptBuilder:
    """
    A class to build dynamic prompts for LLM interaction by loading a flattened template
    from a JSON file and filling in dynamic placeholders.
    """
    
    def __init__(self, prompt_file_name: str = "agent_prompt.json"):
        """
        Initializes the PromptBuilder by loading the prompt template from the specified JSON file.
        """
        self.prompt_file_name = prompt_file_name
        self._full_template_string: str = self._load_and_prepare_template()
    
    def _load_raw_prompt_data(self) -> Dict[str, Any]:
        """
        Loads and parses the raw JSON prompt file.
        """
        try:
            prompt_file_path = Path(__file__).parent.parent / "etc" / "prompts" / self.prompt_file_name
            with open(prompt_file_path, 'r', encoding='utf-8') as f:
                prompt_data = json.load(f)
            return prompt_data
        except FileNotFoundError:
            logger.error(f"Prompt file not found at: {prompt_file_path}")
            raise ValueError(f"Prompt file not found at: {prompt_file_path}")
        except json.JSONDecodeError as e:
            with open(prompt_file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            offending_line = lines[e.lineno - 1].strip() if e.lineno <= len(lines) else "N/A"
            logger.error(f"Error decoding JSON from prompt file '{prompt_file_path}' at line {e.lineno}, col {e.colno}: {e.msg}")
            logger.error(f"Offending JSON line snippet: '{offending_line}'")
            raise ValueError(f"Invalid JSON format in prompt file: {e}")
        except Exception as e:
            logger.error(f"Failed to load raw prompt data: {e}", exc_info=True)
            raise ValueError(f"Prompt data could not be loaded: {e}") from e

    def _assemble_structured_prompt_to_string(self, prompt_data: Dict[str, Any]) -> str:
        prompt_parts = []

        def _append_section(title: Optional[str], content: Union[str, List[str], None], level: int):
            if title:
                prompt_parts.append(f"{'#' * level} {title}")
            if content is not None:
                if isinstance(content, list):
                    prompt_parts.extend(content)
                else: # Must be a string
                    prompt_parts.append(content)
            prompt_parts.append("") # Add a blank line after each section

        # Persona
        persona = prompt_data.get("persona", {})
        _append_section(persona.get("title"), persona.get("content"), 1)

        # Principles
        principles = prompt_data.get("principles", {})
        _append_section(principles.get("title"), principles.get("content"), 2)

        # Instructions
        instructions = prompt_data.get("instructions", {})
        _append_section(instructions.get("title"), instructions.get("content"), 2)

        # Output Format
        output_format = prompt_data.get("output_format", {})
        _append_section(output_format.get("title"), output_format.get("content"), 2)

        # Analysis Section (Input Data)
        analysis_section = prompt_data.get("analysis_section", {})
        if analysis_section.get("title"):
            prompt_parts.append(f"## {analysis_section['title']}")
            prompt_parts.append("")
        if analysis_section.get("content"):
            prompt_parts.extend(analysis_section["content"])
            prompt_parts.append("")

        return "\n".join(part for part in prompt_parts if part is not None).strip()

    def _load_and_prepare_template(self) -> str:
        """
        Loads the raw prompt data and assembles it into a single template string.
        """
        raw_prompt_data = self._load_raw_prompt_data()
        return self._assemble_structured_prompt_to_string(raw_prompt_data)

    def build_prompt(self, **kwargs) -> str:
        """
        Builds the final prompt string by formatting the loaded template with provided arguments.
        
        Args:
            **kwargs: Dynamic keyword arguments that will be used to format the prompt template.

        Returns:
            str: The fully formatted prompt string.

        Raises:
            ValueError: If a required placeholder in the template is not provided.
        """
        try:
            # Safely escape brackets inside internal templates if needed, 
            # or assume keywords map directly to the kwargs provided.
            final_prompt = self._full_template_string.format(**kwargs)
            return final_prompt
        except KeyError as e:
            logger.error(f"Missing expected placeholder in prompt template: '{e}'. Ensure all placeholders in '{self.prompt_file_name}' are provided to build_prompt.")
            raise ValueError(f"Prompt template formatting error: Missing placeholder '{e}'") from e
        except Exception as e:
            logger.error(f"Failed to format final prompt string: {e}", exc_info=True)
            raise ValueError(f"Final prompt string could not be formatted: {e}") from e