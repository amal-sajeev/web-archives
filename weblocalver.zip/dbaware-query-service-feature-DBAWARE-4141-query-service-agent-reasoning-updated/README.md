# dbaware-query-service (`walkthrough-query-agent`)

An AI-powered conversational Q&A and agentic document inclusion/exclusion service for DBAware audit scoping plans, backed by Google Gemini on GCP Vertex AI, Google Cloud Storage (GCS), `dbaware-rag-service`, and the `dbaware_scoping` PostgreSQL database.

- **Live CT1 Swagger UI:** `https://ct1-cta.dbaware.dev.gcp.db.com/query-service/docs`
- **Live CT1 OpenAPI JSON:** `https://ct1-cta.dbaware.dev.gcp.db.com/query-service/openapi.json`
- **Base API Prefix:** `/query-service/qna`

---

## Table of Contents

1. [Overview & Key Capabilities](#1-overview--key-capabilities)
2. [Architecture & 6-Stage Agentic Workflow](#2-architecture--6-stage-agentic-workflow)
3. [Quick Integration Guide for UI Developers](#3-quick-integration-guide-for-ui-developers)
4. [Complete API Reference (All 26 `/qna` Endpoints)](#4-complete-api-reference-all-26-qna-endpoints)
   - [4.1 Conversational Q&A & Session Management](#41-conversational-qa--session-management)
   - [4.2 6-Stage Chat-Driven Document Action Workflow](#42-6-stage-chat-driven-document-action-workflow)
   - [4.3 Document Inclusion Orchestrator Endpoints](#43-document-inclusion-orchestrator-endpoints)
   - [4.4 Document Exclusion Orchestrator Endpoints](#44-document-exclusion-orchestrator-endpoints)
   - [4.5 RAG Service Integration Endpoints](#45-rag-service-integration-endpoints)
   - [4.6 GCS Document CRUD & Policy Management](#46-gcs-document-crud--policy-management)
5. [Database & GCS Synchronization Reference](#5-database--gcs-synchronization-reference)
6. [QA & Tester Guide (Running Unit & Live Tests)](#6-qa--tester-guide-running-unit--live-tests)
7. [Local Development & Configuration](#7-local-development--configuration)

---

## 1. Overview & Key Capabilities

`walkthrough-query-agent` powers both conversational Q&A and agentic document management across all audit scoping stages:

1. **Multi-Stage Stateful Q&A (`/qna/chat`)**:
   - Answers questions grounded in GCS plan artifacts (`Preliminary Research Walkthrough`, `Discovery Walkthrough`, `Scope Recommendation`, `Test Steps`).
   - Automatically queries `dbaware-rag-service` for deep policy/KOD/procedure chunks when needed.
   - Evaluates and refines answers through an **LLM-as-a-Judge** loop (`groundedness`, `citation_coverage`, `contradiction_score`, `context_faithfulness`, `answer_relevance`).
2. **6-Stage Agentic Document Inclusion & Exclusion Workflow**:
   - **Stage 1 (Extract):** Detects whether a user's chat message is a request to include/add or exclude/remove policies, KODs, or procedures.
   - **Stage 2 (Verify):** Verifies candidate documents against the active GCS registries (`relevant_policy.json`, `relevant_kod.json`, `relevant_procedure.json`) and Liquibase DB primary keys (`review_scope_dataext_id`, `review_document_instance_id`).
   - **Stage 3 (Plan):** Builds a human-readable Markdown plan + structured step list.
   - **Stage 4 (Approval Gate):** Holds the plan in `pending_approval` until the user approves (`approve` / `yes`) or rejects (`reject` / `no`).
   - **Stage 5 (Translate):** Converts the approved plan into a deterministic execution payload.
   - **Stage 6 (Execute & Sync):** Mutates the GCS registry JSON (`relevant_{policy,kod,procedure}.json`), updates the Liquibase tables (`review_data_extraction`, `dbaware_review_documents`), and evicts cached sessions for the plan across all stages. Stage reports (Preliminary Research, Discovery, Scope Recommendation, Test Steps) are not directly mutated by `walkthrough-query-agent`; the user triggers stage re-runs manually via UI buttons.
3. **End-to-End RAG Document Onboarding**:
   - Upload new PDFs/files to RAG (`/qna/documents/ingest`), poll indexing status (`/qna/documents/ingest-jobs/{job_id}`), auto-categorize document IDs into `policy` / `kod` / `procedure` (`/qna/documents/categorize`), and pull relevant chunks into the plan context (`/qna/documents/relevant-data`).

---

## 2. Architecture & 6-Stage Agentic Workflow

```text
┌──────────────┐       ┌──────────────────────────────────────────────┐       ┌────────────────────────┐
│  UI / Caller │──────▶│  walkthrough-query-agent (FastAPI)           │──────▶│  Vertex AI (Gemini)    │
└──────────────┘       │                                              │       │  Agent + LLM Judge     │
                       │  ├─ /qna/chat (Q&A + Auto-Intent Routing)    │       └────────────────────────┘
                       │  ├─ /qna/chat/context/add                    │                   ▲
                       │  ├─ /qna/documents/actions/* (Stages 1-6)    │                   │
                       │  ├─ /qna/documents/inclusion/*               │       ┌────────────────────────┐
                       │  ├─ /qna/documents/exclusion/*               │──────▶│  GCS Plan Context      │
                       │  └─ /qna/documents/{ingest,categorize,...}   │       │  dbaware_review_<plan> │
                       └──────────────────────┬───────────────────────┘       └────────────────────────┘
                                              │
                        ┌─────────────────────┴─────────────────────┐
                        ▼                                           ▼
         ┌─────────────────────────────┐             ┌─────────────────────────────┐
         │  dbaware-rag-service        │             │  PostgreSQL (Liquibase DB)  │
         │  - /ingest-documents        │             │  - review_data_extraction   │
         │  - /ingest-jobs/{job_id}    │             │  - dbaware_review_documents │
         │  - /categorize-document-ids │             └─────────────────────────────┘
         │  - /get-relevant-data-...   │
         └─────────────────────────────┘
```

---

## 3. Quick Integration Guide for UI Developers

The UI can integrate with document inclusion/exclusion and RAG in **three ways**, depending on how much UI control you want:

### Option A: Pure Chat-Window Flow (Zero extra UI buttons needed)
Send everything to `POST /qna/chat`:
1. User types: `"Please exclude policy Global Trade Surveillance Policy and include policy Record Retention Standard"`
2. `POST /qna/chat` automatically detects the document request, runs Stages 1–4, and returns a Markdown confirmation card in `answer` plus structured metadata in `document_workflow` (`stage: "pending_approval"`, `plan_id`, `steps`).
3. User replies `"approve"` (or `"reject"`) in `POST /qna/chat` (or clicks an Approve/Reject button calling `POST /qna/documents/actions/decision`).
4. Backend executes Stage 6, updates GCS registries + DB, evicts cached sessions, and returns `"stage": "executed"`. The user can then click the UI button to re-run Preliminary Research or any other scoping stage as needed.

### Option B: Explicit Step-by-Step Action Modal Flow
If the UI renders a dedicated confirmation modal with checkboxes/steps:
1. Call `POST /qna/documents/actions/plan` with `plan_number` and `user_text` (or explicit `actions`).
2. Render `response.steps` and `response.markdown_plan` in the UI modal.
3. When the user clicks **Approve** or **Reject**, call `POST /qna/documents/actions/decision` with `{ "plan_number": "20086", "plan_id": "<plan_id>", "decision": "approve", "approved_by": "<username>" }`.

### Option C: Uploading New PDFs via Chat / File Picker -> RAG -> Plan Context
When a user attaches new PDFs or selects RAG document IDs to include in a plan:
1. **Upload PDF(s) to RAG:** `POST /qna/documents/ingest` (`multipart/form-data` with `files` or `policy_files` / `kod_files` / `procedure_files`). Returns `job_id` and `document_ids`.
2. **Poll Job Status:** `GET /qna/documents/ingest-jobs/{job_id}` until `status == "completed"`.
3. **Include into Plan:** Pass the resulting `document_ids` to either:
   - `POST /qna/chat/context/add` (immediately categorizes, fetches relevant chunks from RAG, and adds to session/GCS), **or**
   - `POST /qna/documents/inclusion/workflow` with `document_ids: [101, 102]` and `approved: true`.

---

## 4. Complete API Reference (All 26 `/qna` Endpoints)

All endpoints below are prefixed with `/query-service/qna` on GKE (e.g., `https://ct1-cta.dbaware.dev.gcp.db.com/query-service/qna/...`).

---

### 4.1 Conversational Q&A & Session Management

#### 1. `POST /qna/chat`
Executes a conversational Q&A turn **or** automatically routes natural-language document inclusion/exclusion requests through the 6-stage approval workflow.

**Request (`ChatCombinedRequest`):**
```json
{
  "planNumber": "20086",
  "contextType": "Preliminary Research Walkthrough",
  "userText": "What are the key regulatory requirements in Section 1?",
  "chat_type": "stateful",
  "enable_document_workflow": true,
  "approved_by": "auditor@db.com"
}
```
> **Supported `contextType` values:**
> - `"Preliminary Research Walkthrough"` (default)
> - `"Discovery Walkthrough"`
> - `"Scope Recommendation"`
> - `"Test Steps"`

**Response (`ChatResponse`):**
```json
{
  "session_id": "20086",
  "answer": "Based on Section 1 of the Preliminary Research...",
  "document_workflow": null
}
```
*(When `userText` is a document inclusion/exclusion command or `"approve"`/`"reject"`, `document_workflow` is populated with `{ "handled": true, "stage": "pending_approval" | "executed" | "rejected", "plan": {...}, "execution": {...} }`.)*

---

#### 2. `POST /qna/chat/context/add`
Adds structured sections, uploaded document JSONs, free-form auditor notes, or RAG `document_ids` directly into the active chat session and GCS plan context.

**Request (`ChatAddContextRequest`):**
```json
{
  "planNumber": "20086",
  "sessionId": "20086",
  "contextType": "Preliminary Research Walkthrough",
  "userText": "Include supplemental onboarding control note for Q4.",
  "sections": [
    {
      "section_title": "Section 4.2 Onboarding Controls",
      "content": "All institutional clients must complete enhanced KYC.",
      "document_type": "policy",
      "document_title": "Client Onboarding Policy",
      "document_id": "402",
      "section_id": "4.2"
    }
  ],
  "documentIds": [1],
  "persistToGcs": true
}
```

**Response (`ChatAddContextResponse`):**
```json
{
  "session_id": "20086",
  "plan_number": "20086",
  "context_type": "Preliminary Research Walkthrough",
  "status": "success",
  "sections_added": 1,
  "documents_added": 1,
  "persisted_files": [
    "dbaware_review_20086/inbound-data/policy/relevant_policy/policy_1.json"
  ],
  "registry_updated": true,
  "message": "Successfully added 1 document(s) and 1 section(s) to session '20086'."
}
```

---

#### 3. `POST /qna/session/close`
Closes and clears all cached stage sessions for a plan from server memory.

**Request (`CloseSessionRequest`):**
```json
{
  "session_id": "20086"
}
```

**Response:**
```json
{
  "message": "Successfully closed and cleared 1 cached stage session(s) from server memory."
}
```

---

### 4.2 6-Stage Chat-Driven Document Action Workflow

These 5 endpoints expose each stage of the unified inclusion/exclusion workflow individually for fine-grained UI control.

#### 4. `POST /qna/documents/actions/extract` (Stage 1)
Extracts structured `include` / `exclude` actions from natural language using Gemini (with deterministic regex/heuristic fallback).

**Request (`DocumentActionExtractRequest`):**
```json
{
  "plan_number": "20086",
  "user_text": "Exclude policy Global Trade Surveillance Policy and add policy Record Retention Standard"
}
```

**Response (`DocumentActionExtractResponse`):**
```json
{
  "plan_number": "20086",
  "is_document_request": true,
  "actions": [
    {
      "action": "exclude",
      "document_type": "policy",
      "title": "Global Trade Surveillance Policy",
      "document_id": null,
      "section_title": null,
      "content": null,
      "reason": null
    },
    {
      "action": "include",
      "document_type": "policy",
      "title": "Record Retention Standard",
      "document_id": null,
      "section_title": null,
      "content": null,
      "reason": null
    }
  ],
  "reasoning": "Extracted 2 document actions from user command.",
  "source": "llm"
}
```

---

#### 5. `POST /qna/documents/actions/verify` (Stage 2)
Verifies extracted actions against the plan's GCS registries (`relevant_policy.json`, `relevant_kod.json`, `relevant_procedure.json`) and resolves Liquibase DB primary keys (`review_scope_dataext_id`, `review_document_instance_id`).

**Request (`DocumentActionVerifyRequest`):**
```json
{
  "plan_number": "20086",
  "user_text": "Exclude policy Global Trade Surveillance Policy",
  "actions": [
    {
      "action": "exclude",
      "document_type": "policy",
      "title": "Global Trade Surveillance Policy"
    }
  ]
}
```

**Response (`DocumentActionVerificationResponse`):**
```json
{
  "plan_number": "20086",
  "verified": [
    {
      "action": "exclude",
      "document_type": "policy",
      "title": "Global Trade Surveillance Policy",
      "requested_title": "Global Trade Surveillance Policy",
      "document_id": "101",
      "matched": true,
      "status": "verified",
      "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
      "row_primary_keys": ["101"],
      "review_scope_dataext_id": 200861,
      "review_document_instance_id": 2008601
    }
  ],
  "unmatched": [],
  "message": "Verified 1 action(s); 0 unmatched."
}
```

---

#### 6. `POST /qna/documents/actions/plan` (Stages 1–4)
Runs extraction + verification + plan building in one call, stores the plan in `pending_approval` state, and returns a `plan_id` and `markdown_plan`.

**Request (`DocumentActionPlanBuildRequest`):**
```json
{
  "plan_number": "20086",
  "user_text": "Include policy Operational Risk Management Policy with content 'Annual RCSAs are mandatory.'"
}
```

**Response (`DocumentActionPlanResponse`):**
```json
{
  "plan_id": "274b3ac9-5189-4f6e-8ce6-6c8ba488240a",
  "plan_number": "20086",
  "status": "pending_approval",
  "summary": "Add 'Operational Risk Management Policy' to the audit plan.",
  "steps": [
    {
      "step": 1,
      "action": "include",
      "document_type": "policy",
      "title": "Operational Risk Management Policy",
      "document_id": null,
      "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
      "row_primary_keys": [],
      "review_scope_dataext_id": 200861,
      "rationale": "Include new policy into active plan registry."
    }
  ],
  "warnings": [],
  "markdown_plan": "### Proposed Document Action Plan (Plan `20086`)...",
  "requires_approval": true
}
```

---

#### 7. `POST /qna/documents/actions/decision` (Stages 4–6)
Approves or rejects a pending `plan_id`. On `"approve"`, translates the plan (Stage 5) and executes all GCS registry + Liquibase DB updates and evicts cached plan sessions (Stage 6).

**Request (`DocumentActionDecisionRequest`):**
```json
{
  "plan_number": "20086",
  "plan_id": "274b3ac9-5189-4f6e-8ce6-6c8ba488240a",
  "decision": "approve",
  "approved_by": "auditor@db.com"
}
```

**Response (`DocumentActionDecisionResponse`):**
```json
{
  "plan_id": "274b3ac9-5189-4f6e-8ce6-6c8ba488240a",
  "plan_number": "20086",
  "status": "executed",
  "message": "Approved plan executed: Applied 1 document change(s).",
  "execution_json": { ... },
  "execution": {
    "plan_number": "20086",
    "status": "success",
    "registry_updated": true,
    "session_cache_evicted": true
  }
}
```

---

#### 8. `POST /qna/documents/actions/execute` (Stage 6 Direct Execution)
Directly executes a list of verified `include`/`exclude` items without waiting for a `plan_id`.

**Request (`DocumentActionExecutionRequest`):**
```json
{
  "plan_number": "20086",
  "approved_by": "auditor@db.com",
  "actions": [
    {
      "action": "exclude",
      "document_type": "policy",
      "title": "Operational Risk Management Policy",
      "row_primary_keys": ["1"],
      "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json"
    }
  ]
}
```

---

### 4.3 Document Inclusion Orchestrator Endpoints

Dedicated endpoints for adding/restoring documents or sections (including automatic RAG retrieval by `document_ids`).

#### 9. `POST /qna/documents/inclusion/verify-context`
Verifies candidate documents or `document_ids` for inclusion. If only `document_id` is supplied, automatically calls RAG `/categorize-document-ids` to resolve `policy` / `kod` / `procedure`.

```json
{
  "plan_number": "20086",
  "action": "include",
  "candidates": [
    {
      "document_type": "policy",
      "title": "Global Record Retention Policy",
      "document_id": "501",
      "section_id": "2.1",
      "section_title": "Retention Schedule",
      "content": "Records must be retained for 7 years."
    }
  ]
}
```

#### 10. `POST /qna/documents/inclusion-plan`
Builds an approval-ready inclusion plan from `verified_documents`.

```json
{
  "plan_number": "20086",
  "user_text": "Include Global Record Retention Policy",
  "action": "include",
  "verified_documents": [
    {
      "document_type": "policy",
      "title": "Global Record Retention Policy",
      "document_id": "501",
      "matched": true,
      "status": "ready_to_add",
      "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
      "row_primary_key": "501"
    }
  ]
}
```

#### 11. `POST /qna/documents/inclusion/execute`
Executes an approved inclusion plan: updates GCS registry and fetches/persists RAG sections if `document_id` is present.

```json
{
  "plan_number": "20086",
  "approved_by": "auditor@db.com",
  "actions": [
    {
      "action": "include",
      "document_type": "policy",
      "title": "Global Record Retention Policy",
      "document_id": "501",
      "section_id": "2.1",
      "section_title": "Retention Schedule",
      "content": "Records must be retained for 7 years.",
      "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
      "row_primary_key": "501"
    }
  ]
}
```

#### 12. `POST /qna/documents/inclusion/workflow`
Single-endpoint orchestrator for inclusion. Set `"approved": false` to get the preview plan, or `"approved": true` to execute immediately.

```json
{
  "plan_number": "20086",
  "user_text": "Include policy Global Record Retention Policy",
  "action": "include",
  "document_ids": [1],
  "approved": false,
  "approved_by": "auditor@db.com"
}
```

---

### 4.4 Document Exclusion Orchestrator Endpoints

Dedicated endpoints for excluding/removing documents from active plan context.

#### 13. `POST /qna/documents/exclusion/verify-context`
Verifies that candidate documents exist in the plan's GCS registry (`relevant_policy.json`, `relevant_kod.json`, or `relevant_procedure.json`) and resolves `row_primary_key`.

```json
{
  "plan_number": "20086",
  "action": "exclude",
  "candidates": [
    {
      "document_type": "policy",
      "title": "Global Record Retention Policy"
    }
  ]
}
```

#### 14. `POST /qna/documents/exclusion-plan`
Builds an approval-ready exclusion plan from `verified_documents`.

```json
{
  "plan_number": "20086",
  "user_text": "Exclude Global Record Retention Policy",
  "action": "exclude",
  "verified_documents": [
    {
      "document_type": "policy",
      "title": "Global Record Retention Policy",
      "matched": true,
      "status": "verified",
      "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
      "row_primary_key": "501"
    }
  ]
}
```

#### 15. `POST /qna/documents/exclusion/execute`
Executes an approved exclusion plan, marking the document excluded in the GCS registry.

```json
{
  "plan_number": "20086",
  "approved_by": "auditor@db.com",
  "actions": [
    {
      "action": "exclude",
      "document_type": "policy",
      "title": "Global Record Retention Policy",
      "context_file": "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
      "row_primary_key": "501",
      "scope": "all_related"
    }
  ]
}
```

#### 16. `POST /qna/documents/exclusion/workflow`
Single-endpoint orchestrator for exclusion (`"approved": false` for preview plan; `"approved": true` to execute).

```json
{
  "plan_number": "20086",
  "user_text": "Exclude policy Global Record Retention Policy",
  "action": "exclude",
  "candidates": [
    {
      "document_type": "policy",
      "title": "Global Record Retention Policy"
    }
  ],
  "approved": false,
  "approved_by": "auditor@db.com"
}
```

---

### 4.5 RAG Service Integration Endpoints

These endpoints proxy and orchestrate `dbaware-rag-service` for document ingestion, status polling, categorization, and relevant chunk extraction.

#### 17. `POST /qna/documents/ingest` (`multipart/form-data`)
Uploads one or more PDF/document files to `dbaware-rag-service` (`/ingest-documents`).

**Form Fields:**
- `plan_number` *(optional, string)*: e.g. `"20086"`
- `default_document_type` *(optional, string)*: `"policy"` (default), `"kod"`, or `"procedure"`
- `policy_files` / `kod_files` / `procedure_files` / `files` *(file upload(s))*: One or more files.

**Example `curl`:**
```bash
curl -X POST "https://ct1-cta.dbaware.dev.gcp.db.com/query-service/qna/documents/ingest" \
  -F "plan_number=20086" \
  -F "default_document_type=policy" \
  -F "files=@/path/to/policy_document.pdf"
```

**Response (`RAGIngestDocumentsResponse`):**
```json
{
  "status": "completed",
  "job_id": "35373ba596754d3e91b6cd79b967499b",
  "document_ids": [105],
  "plan_number": "20086",
  "message": "Documents submitted to RAG service for ingestion.",
  "details": { ... }
}
```

---

#### 18. `GET /qna/documents/ingest-jobs/{job_id}`
Polls the status of a RAG ingestion job (`/ingest-jobs/{job_id}`).

**Response (`RAGJobStatusResponse`):**
```json
{
  "job_id": "35373ba596754d3e91b6cd79b967499b",
  "status": "completed",
  "document_ids": [105],
  "message": null,
  "details": { ... }
}
```

---

#### 19. `POST /qna/documents/categorize`
Categorizes a list of numeric RAG `document_ids` into `policy`, `kod`, or `procedure` (`/categorize-document-ids`).

**Request (`CategorizeDocumentsRequest`):**
```json
{
  "document_ids": [1, 42, 105]
}
```

**Response (`CategorizeDocumentsResponse`):**
```json
{
  "status": "success",
  "document_ids": [1],
  "categorized_documents": {
    "policy_ids": [1],
    "kod_ids": [],
    "procedure_ids": [],
    "not_found_ids": [],
    "status": "success"
  },
  "message": "Successfully categorized document IDs."
}
```

---

#### 20. `POST /qna/documents/relevant-data`
Calls RAG `/get-relevant-data-for-documents` (auto-populating plan & control metadata from GCS `plan_details.json` and `control_details.json` when not overridden) and optionally persists the retrieved sections into the plan's GCS context.

**Request (`RelevantDataForDocumentsRequest`):**
```json
{
  "plan_number": "20086",
  "documents": [
    {
      "document_type": "policy",
      "document_ids": [1],
      "top_k": 3
    }
  ],
  "persist_to_context": true
}
```

**Response (`RelevantDataForDocumentsResponse`):**
```json
{
  "plan_number": "20086",
  "review_id": "20086",
  "status": "success",
  "results": [
    {
      "document_type": "policy",
      "top_k": 3,
      "requested_document_ids": [1],
      "status": "success",
      "documents": [
        {
          "document_id": "1",
          "document_title": "Operational_Risk_Management_Policy",
          "document_version": 7,
          "storage_uri": "gs://...",
          "nodes": [ ... ]
        }
      ]
    }
  ],
  "persisted_files": [
    "dbaware_review_20086/inbound-data/policy/relevant_policy/policy_1.json"
  ],
  "registry_updated": true,
  "message": "Successfully retrieved relevant document data from RAG service."
}
```

---

### 4.6 GCS Document CRUD & Policy Management

#### 21. `POST /qna/documents/list`
Lists documents for a single `document_type` (`policy`, `kod`, or `procedure`) from GCS `dbaware_review_<plan>/inbound-data/policy/relevant_<type>/`.

```json
{
  "plan_number": "20086",
  "document_type": "policy"
}
```

#### 22. `POST /qna/documents/list-all`
Lists all documents across `policy`, `kod`, and `procedure` for a plan in a single call.

```json
{
  "plan_number": "20086"
}
```

#### 23. `POST /qna/documents/upload`
Bulk uploads JSON document definitions into `relevant_<type>/` on GCS and registers them in `relevant_<type>.json`.

```json
{
  "plan_number": "20086",
  "documents": [
    {
      "document_type": "policy",
      "items": [
        {
          "file_name": "custom_policy_1.json",
          "document_id": "9001",
          "document_title": "Custom Audit Policy",
          "section_id": "1.1",
          "section_title": "Scope",
          "content": "Applies to all EU branches."
        }
      ]
    }
  ]
}
```

#### 24. `POST /qna/documents/delete`
Bulk deletes specified JSON files from `relevant_<type>/` on GCS.

```json
{
  "plan_number": "20086",
  "documents": [
    {
      "document_type": "policy",
      "file_names": ["custom_policy_1.json"]
    }
  ]
}
```

#### 25. `POST /qna/upload` (`multipart/form-data`)
Uploads a raw `.json` file directly to a specified `gcs_blob_path`.

- Form fields: `file` (`.json` file), `gcs_blob_path` (e.g. `"dbaware_review_20086/inbound-data/policy/relevant_policy/custom.json"`).

#### 26. `POST /qna/policies/manage`
Natural-language policy management helper for local `policy_docs` (`REMOVE` / `KEEP` / `INCLUDE` by numeric policy ID).

```json
{
  "command": "exclude policy 1, 2"
}
```

---

## 5. Database & GCS Synchronization Reference

When Stage 6 (`execute_document_actions`) runs after user approval, the backend keeps **GCS**, **PostgreSQL (`dbaware_scoping`)**, and **in-memory sessions** in sync without directly mutating stage reports (the user re-runs Preliminary Research or other stages manually via UI buttons):

| Target | Location / Table | What Gets Updated |
|---|---|---|
| **GCS Registry JSON** | `dbaware_review_<plan>/inbound-data/policy/relevant_{policy,kod,procedure}.json` | Marks excluded docs (`"status": "removed"`, `"excluded": true`) or appends/restores included docs & sections (`"status": "active"`, `"excluded": false`). |
| **Liquibase Table 1** | `dbaware_scoping.review_data_extraction` | Updates `metadata` JSONB by primary key `review_scope_dataext_id` for `data_source` (`policy`, `kod`, `procedure`). |
| **Liquibase Table 2** | `dbaware_scoping.dbaware_review_documents` | Inserts a row on `include` or deletes by `review_document_instance_id` / `(review_scope_instance_id, document_id)` on `exclude`. |
| **Session Cache** | `SESSION_CACHE` (in-memory) | Evicts all cached stage sessions for `plan_number` so subsequent `/qna/chat` turns immediately reflect the updated context across all stages. |

---

## 6. QA & Tester Guide (Running Unit & Live Tests)

### Running the Unit Test Suite with Coverage (CI Gate >= 70%)

```powershell
cd walkthrough-query-agent
$env:PYTHONPATH="src/main;."
pytest src/tests --cov=src/main --cov-fail-under=70 -v
```
- Current test count: **107 passed**
- Current coverage: **~81%** (CI enforces `--cov-fail-under=70`)

### Running the Full 28-Endpoint Live Smoke Test (`scripts/test_live_endpoints.py`)

If you have the local `scripts/test_live_endpoints.py` runner, you can test every single endpoint (including `/openapi.json`, `/docs`, and all 26 `/qna/*` routes) against CT1, DEV1, or a local server:

```powershell
# Against Live CT1:
$env:NO_PROXY="localhost,127.0.0.1,.db.com"
python scripts/test_live_endpoints.py --base-url "https://ct1-cta.dbaware.dev.gcp.db.com/query-service" --plan-number "20086" --timeout 90

# Or in-process (mocked dry run without network):
python scripts/test_live_endpoints.py --in-process
```

---

## 7. Local Development & Configuration

### Running Locally

```bash
cd walkthrough-query-agent
python3.11 -m venv .venv
source .venv/bin/activate  # On Windows: .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

cd src/main
python app.py
```
- Local Swagger UI: `http://127.0.0.1:8010/query-service/docs`
- Local OpenAPI Spec: `http://127.0.0.1:8010/query-service/openapi.json`

### Key Environment Variables

| Variable | Default / Example | Description |
|---|---|---|
| `GCP_PROJECT_ID` | `db-dev-46jr-mp-cta-analytics` | GCP project ID for Vertex AI & GCS |
| `GCP_LOCATION` / `GCP_REGION` | `europe-west3` | Vertex AI region (`europe-west3` required for `gemini-2.5-flash` / `gemini-2.5-pro` in CT1) |
| `MODEL_NAME` | `gemini-2.5-flash` | Primary Gemini model for Q&A and workflow orchestration |
| `JUDGE_MODEL_NAME` | `gemini-2.5-flash` | Gemini model for the LLM-as-a-Judge evaluation loop |
| `GCS_BUCKET_NAME` | `db-dev-euwe3-gcs-155081-dbaware_review` | GCS bucket storing `dbaware_review_<plan>` artifacts |
| `RAG_SERVICE_BASE_URL` | `https://ct1-cta.dbaware.dev.gcp.db.com/rag-service` | Base URL for `dbaware-rag-service` |
| `RAG_SERVICE_TIMEOUT` | `30.0` | Timeout (seconds) for RAG HTTP calls |
| `DB_HOST` / `DB_PORT` / `DB_NAME` | `localhost` / `5432` / `dbaware` | PostgreSQL connection settings for `dbaware_scoping` |
| `DB_USER` / `DB_PASSWORD` | — | PostgreSQL credentials |
| `MOCK_SCOPING_DB` | `false` (`true` when `DB_HOST` is unset) | Enables in-memory mock fallback for Liquibase tables during local/unit testing |
| `ENABLE_JUDGE` | `true` | Enables/disables the LLM Judge evaluation loop on `/qna/chat` |
| `MAX_REVISION_ATTEMPTS` | `2` | Maximum LLM Judge revision iterations |




