#!/usr/bin/env python3
"""
qro.py — Split a file into QR codes and export them as a grid, video, or HTML viewer.

Usage:
    python qro.py input_file [output] [--chunk-size N] [--cols N] [--tovid | --tohtml]

Each QR encodes: index|total|base64_chunk
To reassemble: scan each code, sort by index, base64-decode, concatenate.
"""

import io
import math
import base64
import argparse
from pathlib import Path
import cv2
import numpy as np
import qrcode
from PIL import Image


def chunk_file(path, chunk_size):
    with open(path, "rb") as f:
        data = f.read()
    return [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)] or [b""]


def make_qr_image(text, box_size=6, border=2):
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,
                        box_size=box_size, border=border)
    qr.add_data(text)
    qr.make(fit=True)
    return qr.make_image(fill_color="black", back_color="white").convert("RGB")


def build_grid(images, cols, padding=10, bg=(255, 255, 255)):
    rows = math.ceil(len(images) / cols)
    cw, ch = max(im.width for im in images), max(im.height for im in images)
    grid = Image.new("RGB", (cols * cw + (cols + 1) * padding,
                              rows * ch + (rows + 1) * padding), bg)
    for i, im in enumerate(images):
        r, c = divmod(i, cols)
        grid.paste(im, (padding + c * (cw + padding), padding + r * (ch + padding)))
    return grid


def pad_to(im, size, bg=(255, 255, 255)):
    """Centre im on a bg canvas of `size` so every frame shares one geometry."""
    if im.size == size:
        return im
    canvas = Image.new("RGB", size, bg)
    canvas.paste(im, ((size[0] - im.width) // 2, (size[1] - im.height) // 2))
    return canvas


def build_video(images, output, fps=2):
    size = (max(im.width for im in images), max(im.height for im in images))
    writer = cv2.VideoWriter(str(output), cv2.VideoWriter_fourcc(*"mp4v"), fps, size)
    if not writer.isOpened():
        raise RuntimeError(f"could not open {output} for writing")
    for im in images:
        writer.write(cv2.cvtColor(np.asarray(pad_to(im, size)), cv2.COLOR_RGB2BGR))
    writer.release()


def png_data_uri(im):
    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


HTML_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; height: 100%; overflow: hidden; background: #111; color: #eee;
               font: 14px/1.4 system-ui, -apple-system, Segoe UI, sans-serif; }
  #stage { position: absolute; inset: 0 0 56px 0; background: #fff;
           display: grid; place-items: center; touch-action: none; user-select: none; }
  /* Every warmed frame is already in the DOM and already decoded, so switching is
     a pure opacity flip with no blank gap while the browser loads or decodes. */
  #stage img { position: absolute; max-width: 94%; max-height: 94%;
               image-rendering: pixelated; opacity: 0; }
  #stage img.current { opacity: 1; }
  #hud { position: absolute; left: 0; right: 0; bottom: 0; height: 56px;
         display: flex; align-items: center; gap: 8px; padding: 0 12px;
         border-top: 1px solid #333; }
  button, input { font: inherit; color: #eee; background: #222;
                  border: 1px solid #444; border-radius: 6px; padding: 6px 12px; }
  button { cursor: pointer; }
  button:hover { background: #2c2c2c; }
  button:active { background: #383838; }
  button[aria-pressed="true"] { background: #2d4a2d; border-color: #3c3; }
  #counter { font-variant-numeric: tabular-nums; min-width: 92px; text-align: center; }
  #jump { width: 74px; padding: 6px 8px; }
  #status { margin-left: auto; font-size: 12px; opacity: .65;
            font-variant-numeric: tabular-nums; }
  @media (max-width: 560px) { #jump { display: none; } }
</style>
</head>
<body>
<div id="stage" title="Click the right half for next, the left half for previous"></div>
<div id="hud">
  <button id="prev" type="button" aria-label="Previous code">&#9664;</button>
  <span id="counter">&nbsp;</span>
  <button id="next" type="button" aria-label="Next code">&#9654;</button>
  <input id="jump" type="number" min="1" step="1" aria-label="Jump to code">
  <button id="play" type="button" aria-pressed="false">Auto</button>
  <span id="status"></span>
</div>
<script>
"use strict";
const FRAMES = [
__FRAMES__
];
// How far either side of the current code to keep mounted and decoded.
const AHEAD = __AHEAD__, BEHIND = __BEHIND__;
// Slack beyond the warm window before frames are thrown away, so jittering back
// and forth across one boundary never re-decodes anything.
const EVICT = Math.max(AHEAD, BEHIND) + 8;

const stage = document.getElementById("stage");
const counter = document.getElementById("counter");
const statusEl = document.getElementById("status");
const jump = document.getElementById("jump");
const play = document.getElementById("play");

const mounted = new Map();   // index -> <img>, decoded or decoding
let cur = 0, curImg = null, timer = null;

function mount(i) {
  if (i < 0 || i >= FRAMES.length) return null;
  const have = mounted.get(i);
  if (have) return have;
  const img = new Image();
  img.decoding = "sync";
  img.alt = "QR code " + (i + 1) + " of " + FRAMES.length;
  img.dataset.ready = "0";
  img.src = FRAMES[i];
  mounted.set(i, img);
  stage.appendChild(img);
  const done = () => { img.dataset.ready = "1"; paintStatus(); };
  if (img.decode) img.decode().then(done, done);
  else img.onload = done;
  return img;
}

function warm(center) {
  mount(center);
  // Forward first: that is the direction you are most likely to move next.
  for (let d = 1; d <= AHEAD; d++) mount(center + d);
  for (let d = 1; d <= BEHIND; d++) mount(center - d);
  for (const [i, img] of mounted) {
    if (Math.abs(i - center) > EVICT) { img.remove(); mounted.delete(i); }
  }
  paintStatus();
}

function paintStatus() {
  let ready = 0, total = 0;
  for (let d = -BEHIND; d <= AHEAD; d++) {
    const i = cur + d;
    if (i < 0 || i >= FRAMES.length) continue;
    total++;
    const img = mounted.get(i);
    if (img && img.dataset.ready === "1") ready++;
  }
  statusEl.textContent = "buffered " + ready + "/" + total +
                         "  ·  ← → space  ·  f fullscreen";
}

function show(i) {
  i = Math.max(0, Math.min(FRAMES.length - 1, i));
  const img = mount(i);
  if (curImg && curImg !== img) curImg.classList.remove("current");
  img.classList.add("current");
  curImg = img;
  cur = i;
  counter.textContent = (i + 1) + " / " + FRAMES.length;
  if (document.activeElement !== jump) jump.value = String(i + 1);
  // Extend the warm window only after this frame is on screen, so a burst of fast
  // key presses is never made to wait on decode work for the codes ahead.
  requestAnimationFrame(() => warm(i));
}

const step = d => show(cur + d);

function setAuto(on) {
  clearInterval(timer);
  timer = on ? setInterval(() => {
    if (cur >= FRAMES.length - 1) setAuto(false); else step(1);
  }, 1200) : null;
  play.setAttribute("aria-pressed", on ? "true" : "false");
}

document.getElementById("prev").addEventListener("click", () => step(-1));
document.getElementById("next").addEventListener("click", () => step(1));
play.addEventListener("click", () => setAuto(timer === null));
jump.addEventListener("input", () => {
  const n = parseInt(jump.value, 10);
  if (Number.isFinite(n)) show(n - 1);
});

addEventListener("keydown", e => {
  if (e.target === jump || e.metaKey || e.ctrlKey || e.altKey) return;
  const k = e.key;
  if (k === "ArrowRight" || k === "ArrowDown" || k === " " || k === "PageDown" || k === "j") step(1);
  else if (k === "ArrowLeft" || k === "ArrowUp" || k === "PageUp" || k === "k") step(-1);
  else if (k === "Home") show(0);
  else if (k === "End") show(FRAMES.length - 1);
  else if (k === "f") { document.fullscreenElement ? document.exitFullscreen()
                                                   : document.documentElement.requestFullscreen(); }
  else if (k === "p") setAuto(timer === null);
  else return;
  e.preventDefault();
});

stage.addEventListener("click", e => {
  step(e.clientX < stage.getBoundingClientRect().width / 2 ? -1 : 1);
});

let touchX = null;
stage.addEventListener("touchstart", e => { touchX = e.changedTouches[0].clientX; }, { passive: true });
stage.addEventListener("touchend", e => {
  if (touchX === null) return;
  const dx = e.changedTouches[0].clientX - touchX;
  touchX = null;
  if (Math.abs(dx) > 30) step(dx < 0 ? 1 : -1);
});

jump.max = String(FRAMES.length);
show(0);
</script>
</body>
</html>
"""


def build_html(images, output, title, ahead, behind):
    frames = ",\n".join('"%s"' % png_data_uri(im) for im in images)
    html = (HTML_TEMPLATE
            .replace("__TITLE__", title)
            .replace("__AHEAD__", str(ahead))
            .replace("__BEHIND__", str(behind))
            .replace("__FRAMES__", frames))
    Path(output).write_text(html, encoding="utf-8")
    return len(html.encode())


def main():
    p = argparse.ArgumentParser(description="Convert a file into QR codes.")
    p.add_argument("input_file")
    p.add_argument("output", nargs="?")
    p.add_argument("--chunk-size", type=int, default=300,
                    help="Raw bytes per QR code before base64 (default: 300)")
    p.add_argument("--cols", type=int, default=0, help="Grid columns (default: auto)")
    p.add_argument("--box-size", type=int, default=6,
                    help="QR module size in px (default: 6)")
    p.add_argument("--fps", type=float, default=2, help="Video frame rate (default: 2)")
    p.add_argument("--preload", type=int, default=4, metavar="N",
                    help="HTML viewer: codes kept decoded ahead of the current one (default: 4)")
    p.add_argument("--preload-behind", type=int, default=2, metavar="N",
                    help="HTML viewer: codes kept decoded behind the current one (default: 2)")
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--tovid", action="store_true", help="Write an mp4 instead of a grid")
    mode.add_argument("--tohtml", action="store_true",
                      help="Write a self-contained HTML viewer")
    args = p.parse_args()

    chunks = chunk_file(args.input_file, args.chunk_size)
    total = len(chunks)

    images = [make_qr_image(f"{i}|{total}|{base64.b64encode(c).decode()}", args.box_size)
              for i, c in enumerate(chunks)]

    default = "qr_codes.mp4" if args.tovid else "qr_codes.html" if args.tohtml else "qr_grid.png"
    output = args.output or default

    size = sum(len(c) for c in chunks)
    print(f"File size: {size} bytes")
    print(f"Chunks: {total} (chunk_size={args.chunk_size} bytes raw)")

    if args.tovid:
        build_video(images, output, args.fps)
        print(f"Video: {total} frames @ {args.fps} fps -> {output}")
    elif args.tohtml:
        nbytes = build_html(images, output, Path(args.input_file).name,
                            max(0, args.preload), max(0, args.preload_behind))
        print(f"HTML viewer: {total} codes, preloading {args.preload} ahead / "
              f"{args.preload_behind} behind -> {output} ({nbytes / 1048576:.1f} MiB)")
    else:
        cols = args.cols or max(1, math.ceil(math.sqrt(total)))
        build_grid(images, cols).save(output)
        print(f"Grid: {cols} cols x {math.ceil(total / cols)} rows -> {output}")
        if total > 40:
            print("Note: at this many chunks, individual codes will be small in the "
                  "grid image — fine for reference/printing, but a phone camera may "
                  "not resolve them from a single photo. Consider a larger --chunk-size "
                  "or fewer, bigger codes if you need to scan directly from the grid.")


if __name__ == "__main__":
    main()
