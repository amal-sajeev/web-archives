/* The case screen.

   Every action posts to the JSON API and the page reloads from the server, so
   what you see is always what is stored. Reloading keeps this file small and
   the behaviour obvious — there is no client-side copy of the case to drift. */

(function () {
  "use strict";
  const { api, toast, openModal, closeModals } = window.App;

  const root = document.querySelector("[data-case]");
  if (!root) return;
  const caseId = root.dataset.case;
  const url = p => "/api/cases/" + caseId + p;

  function after(message, title, action) {
    toast("ok", title || "Saved", message, action);
    setTimeout(() => location.reload(), action ? 2600 : 850);
  }

  /* When a fix clears the last thing standing in the way, say so and offer the
     next step. The action only takes you to the decision; it does not validate,
     because the attestation is a control and must stay deliberate. */
  function onward(res) {
    const d = res.data || {};
    if (d.ready_to_validate) {
      try { sessionStorage.setItem("tc:focus-decision:" + caseId, "1"); } catch (e) {}
      after(res.message, "Nothing else outstanding", {
        label: "Review and send",
        onClick: () => location.reload()
      });
    } else {
      after(res.message);
    }
  }

  function fail(err) { toast("bad", "Didn't work", err.message); }

  /* A workflow transition stays reversible for a short window. Hold on the page
     until that window closes, then move on. */
  function offerUndo(title, res, nextHref) {
    const token = res.data && res.data.undo_token;
    if (!token) {
      toast("ok", title, res.message);
      setTimeout(() => { location.href = nextHref; }, 950);
      return;
    }
    let moved = false;
    toast("ok", title, res.message, {
      label: "Undo",
      seconds: 15,
      onClick: async () => {
        moved = true;
        try {
          const u = await api("POST", url("/undo"), { token: token });
          toast("info", "Undone", u.message);
          setTimeout(() => location.reload(), 900);
        } catch (err) { toast("bad", "Could not undo", err.message); }
      }
    });
    setTimeout(() => { if (!moved) location.href = nextHref; }, 15500);
  }

  /* Any control can open a named dialog. The corporate view reaches the
     documents this way, as the deck does. */
  document.querySelectorAll("[data-open]").forEach(b =>
    b.addEventListener("click", () => openModal(b.dataset.open)));


  /* ---------------------------------------------------- draft autosave --
     Typing a resolution or a query is real work. Keep it per case and field so
     dismissing a dialog by accident does not throw it away. Storage can be
     unavailable (private mode), so every call is guarded. */

  const DRAFT_FIELDS = ["resolve-text", "q-reason", "edit-value", "edit-note", "text-value"];
  const draftKey = id => "tc:draft:" + caseId + ":" + id;

  function readDraft(id) {
    try { return localStorage.getItem(draftKey(id)) || ""; } catch (e) { return ""; }
  }
  function writeDraft(id, value) {
    try {
      if (value) localStorage.setItem(draftKey(id), value);
      else localStorage.removeItem(draftKey(id));
    } catch (e) { /* storage unavailable */ }
  }
  function clearDrafts(ids) { ids.forEach(id => writeDraft(id, "")); }
  function restoreDrafts(ids) {
    ids.forEach(id => {
      const el = document.getElementById(id);
      const saved = readDraft(id);
      if (el && saved && !el.value) el.value = saved;
    });
  }

  DRAFT_FIELDS.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    let t;
    el.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(() => writeDraft(id, el.value), 300);
    });
  });

  /* ------------------------------------------------- document viewer -- */

  const tabs = document.querySelectorAll(".tab");
  const pages = document.querySelectorAll(".paper");

  function showDoc(id) {
    tabs.forEach(t => t.setAttribute("aria-selected", String(t.dataset.doc === id)));
    pages.forEach(p => p.classList.toggle("is-hidden", p.dataset.doc !== id));
  }
  tabs.forEach(t => t.addEventListener("click", () => showDoc(t.dataset.doc)));

  function clearLit() {
    document.querySelectorAll("mark.is-lit").forEach(m => m.classList.remove("is-lit"));
    document.querySelectorAll(".ledger__r.is-lit").forEach(r => r.classList.remove("is-lit"));
  }

  function light(anchor, docId) {
    clearLit();
    // in the corporate view the documents sit in a dialog, so bring it up first
    const host = document.querySelector('.paper[data-doc="' + docId + '"]');
    const dialog = host && host.closest(".sheet-over");
    if (dialog && !dialog.classList.contains("is-open")) dialog.classList.add("is-open");
    if (docId) showDoc(docId);
    const row = document.querySelector('.ledger__r[data-anchor="' + anchor + '"]');
    if (row) row.classList.add("is-lit");
    const page = docId ? document.querySelector('.paper[data-doc="' + docId + '"]') : document;
    const marks = page ? page.querySelectorAll('mark[data-anchor="' + anchor + '"]') : [];
    marks.forEach(m => m.classList.add("is-lit"));
    if (marks[0]) marks[0].scrollIntoView({ block: "center", behavior: "smooth" });
  }

  document.querySelectorAll(".ledger__r[data-anchor]").forEach(row => {
    const show = () => light(row.dataset.anchor, row.dataset.doc);
    row.addEventListener("click", show);
    row.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); show(); }
    });
  });

  document.querySelectorAll("mark[data-anchor]").forEach(m =>
    m.addEventListener("click", () => {
      const row = document.querySelector('.ledger__r[data-anchor="' + m.dataset.anchor + '"]');
      if (row) {
        const holder = row.closest("details");
        if (holder) holder.open = true;
        clearLit();
        row.classList.add("is-lit");
        document.querySelectorAll('mark[data-anchor="' + m.dataset.anchor + '"]')
          .forEach(x => x.classList.add("is-lit"));
        row.scrollIntoView({ block: "center", behavior: "smooth" });
      }
    }));

  /* ------------------------------------------------------- type a value */

  let editKey = null;

  document.querySelectorAll("[data-edit]").forEach(btn =>
    btn.addEventListener("click", () => {
      editKey = btn.dataset.edit;
      const todo = btn.closest("[data-todo]");
      document.getElementById("edit-label").textContent =
        todo ? todo.querySelector("h3").textContent : "Type the value";
      document.getElementById("edit-hint").textContent =
        todo ? todo.querySelector("p").textContent : "";
      document.getElementById("edit-value").value = "";
      document.getElementById("edit-note").value = "";
      restoreDrafts(["edit-value", "edit-note"]);
      openModal("m-edit");
    }));

  const editSave = document.getElementById("edit-save");
  if (editSave) {
    editSave.addEventListener("click", async () => {
      const value = document.getElementById("edit-value").value.trim();
      if (!value) { toast("bad", "Needs a value", "Type what the document says."); return; }
      try {
        const res = await api("PATCH", url("/fields/" + editKey), {
          value, note: document.getElementById("edit-note").value.trim() || null
        });
        clearDrafts(["edit-value", "edit-note"]);
        onward(res);
      } catch (err) { fail(err); }
    });
  }

  /* --------------------------------------------------------- port lookup */

  let portKey = null;
  const portQ = document.getElementById("port-q");
  const portHits = document.getElementById("port-results");

  document.querySelectorAll("[data-portlookup]").forEach(btn =>
    btn.addEventListener("click", () => {
      portKey = btn.dataset.portlookup;
      portQ.value = "";
      openModal("m-port");
      findPorts();
    }));

  let portTimer;
  function findPorts() {
    clearTimeout(portTimer);
    portTimer = setTimeout(async () => {
      try {
        const data = await api("GET", "/api/ports?q=" + encodeURIComponent(portQ.value || ""));
        portHits.innerHTML = "";
        if (!data.ports.length) {
          portHits.innerHTML =
            '<div style="padding:20px;text-align:center;color:var(--muted)">Nothing matches that.</div>';
          return;
        }
        data.ports.slice(0, 40).forEach(p => {
          const b = document.createElement("button");
          b.innerHTML = "<code></code><span></span><em></em>";
          b.querySelector("code").textContent = p.code;
          b.querySelector("span").textContent = p.name;
          b.querySelector("em").textContent = p.country;
          b.addEventListener("click", async () => {
            try {
              const res = await api("POST", url("/fields/" + portKey + "/resolve-port"), { code: p.code });
              onward(res);
            } catch (err) { fail(err); }
          });
          portHits.appendChild(b);
        });
      } catch (_) { /* transient */ }
    }, 120);
  }
  if (portQ) portQ.addEventListener("input", findPorts);

  /* ------------------------------------------------------- resolve a check */

  let resolveId = null;

  document.querySelectorAll("[data-resolve]").forEach(btn =>
    btn.addEventListener("click", () => {
      resolveId = btn.dataset.resolve;
      const todo = btn.closest("[data-todo]");
      document.getElementById("resolve-check").textContent =
        todo ? todo.querySelector("p").textContent : "";
      document.getElementById("resolve-text").value = "";
      restoreDrafts(["resolve-text"]);
      openModal("m-resolve");
    }));

  const resolveSave = document.getElementById("resolve-save");
  if (resolveSave) {
    resolveSave.addEventListener("click", async () => {
      const text = document.getElementById("resolve-text").value.trim();
      if (!text) { toast("bad", "Needs a reason", "A line is enough — the checker reads it."); return; }
      try {
        const res = await api("POST", url("/checks/" + resolveId + "/resolve"), { resolution: text });
        clearDrafts(["resolve-text"]);
        onward(res);
      } catch (err) { fail(err); }
    });
  }

  /* --------------------------------------------------------- ask the branch */

  document.querySelectorAll("[data-query]").forEach(btn =>
    btn.addEventListener("click", () => {
      document.getElementById("q-check").value = btn.dataset.query || "";
      document.getElementById("q-reason").value = "";
      restoreDrafts(["q-reason"]);
      openModal("m-query");
    }));

  const qSend = document.getElementById("q-send");
  if (qSend) {
    qSend.addEventListener("click", async () => {
      const reason = document.getElementById("q-reason").value.trim();
      if (!reason) { toast("bad", "Needs a question", "Say what they need to confirm."); return; }
      try {
        const res = await api("POST", url("/queries"), {
          check_id: document.getElementById("q-check").value || null,
          recipient: document.getElementById("q-to").value || "Branch operations",
          reason
        });
        clearDrafts(["q-reason"]);
        after(res.message, "Sent");
      } catch (err) { fail(err); }
    });
  }

  /* ------------------------------------------------------ small text dialog */

  let textHandler = null;
  function textModal(title, label, handler) {
    document.getElementById("text-title").textContent = title;
    document.getElementById("text-label").textContent = label;
    document.getElementById("text-value").value = "";
    textHandler = handler;
    openModal("m-text");
  }

  const textSave = document.getElementById("text-save");
  if (textSave) {
    textSave.addEventListener("click", async () => {
      const text = document.getElementById("text-value").value.trim();
      if (!text) { toast("bad", "Needs a note", "Add a line before confirming."); return; }
      try { await textHandler(text); closeModals(); } catch (err) { fail(err); }
    });
  }

  document.querySelectorAll("[data-answer]").forEach(btn =>
    btn.addEventListener("click", () =>
      textModal("Record the reply", "What did the branch say?", async text => {
        const res = await api("POST", url("/queries/" + btn.dataset.answer + "/answer"),
                              { response: text });
        after(res.message);
      })));

  /* -------------------------------------------------------------- decide */

  const agrees = Array.from(document.querySelectorAll("#agree, #agree2"));
  const validate = document.getElementById("validate-btn");
  const gated = validate && !validate.disabled && agrees.length;

  function sync() {
    if (gated) validate.disabled = !agrees.every(a => a.checked);
  }
  if (gated) { validate.disabled = true; agrees.forEach(a => a.addEventListener("change", sync)); }

  if (validate) {
    validate.addEventListener("click", async () => {
      validate.disabled = true;
      try {
        const res = await api("POST", url("/validate"), {
          source_reviewed: true, exceptions_resolved: true
        });
        if (!res.ok) { toast("bad", "Not sent", res.message); validate.disabled = false; return; }
        offerUndo("Sent to the checker", res, res.data.next || "/");
      } catch (err) { fail(err); validate.disabled = false; }
    });
  }

  const approve = document.querySelector("[data-approve]");
  if (approve) {
    approve.addEventListener("click", async () => {
      try {
        const res = await api("POST", url("/approve"), {});
        offerUndo("Approved and closed", res, "/");
      } catch (err) { fail(err); }
    });
  }

  const sendBack = document.querySelector("[data-return]");
  if (sendBack) {
    sendBack.addEventListener("click", () =>
      textModal("Send back to the maker", "What needs doing?", async text => {
        const res = await api("POST", url("/return"), { reason: text });
        offerUndo("Returned to the maker", res, "/");
      }));
  }

  const start = document.querySelector("[data-start]");
  if (start) {
    start.addEventListener("click", async () => {
      start.disabled = true;
      try {
        const res = await api("POST", url("/start"), {});
        after(res.message, "Processing");
      } catch (err) { fail(err); start.disabled = false; }
    });
  }

  /* after a chained fix, land on the decision rather than the top of the page */
  try {
    if (sessionStorage.getItem("tc:focus-decision:" + caseId)) {
      sessionStorage.removeItem("tc:focus-decision:" + caseId);
      const first = document.getElementById("agree");
      if (first) {
        first.closest("label").scrollIntoView({ block: "center", behavior: "smooth" });
        setTimeout(() => first.focus(), 400);
      }
    }
  } catch (e) { /* storage unavailable */ }

  /* ------------------------------------------------------- live progress */

  if (root.dataset.status === "ai_processing") {
    const poll = setInterval(async () => {
      try {
        const res = await api("GET", url("/state"));
        if (res.status !== "ai_processing") {
          clearInterval(poll);
          location.reload();
        }
      } catch (_) { /* transient */ }
    }, 2000);
  }
})();
