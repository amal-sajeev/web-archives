---
title: "3110. Supervision"
publisher: "FINRA"
jurisdiction: "United States"
identifier: "3110"
document_type: "Rule"
source_url: "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110"
canonical_url: "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110"
retrieved_at: "2026-10-14T11:33:27.067223+00:00"
source_format: "html"
source_sha256: "5c7b11d41efd8df72f22a947d7322eabda7ad372e22efb439430e34ee3436d59"
authority_confidence: 0.85
extraction_warnings: []
---
# 3110. Supervision

**(a) Supervisory System**

Each member shall establish and maintain a system to supervise the activities of each associated person that is reasonably designed to achieve compliance with applicable securities laws and regulations, and with applicable FINRA rules. Final responsibility for proper supervision shall rest with the member. A member's supervisory system shall provide, at a minimum, for the following:

(1) The establishment and maintenance of written procedures as required by this Rule.

(2) The designation, where applicable, of an appropriately registered principal(s) with authority to carry out the supervisory responsibilities of the member for each type of business in which it engages for which registration as a broker-dealer is required.

(3) The registration and designation as a branch office or an office of supervisory jurisdiction (OSJ) of each location, including the main office, that meets the definitions contained in paragraph (f) of this Rule.

(4) The designation of one or more appropriately registered principals in each OSJ and one or more appropriately registered representatives or principals in each non-OSJ branch office with authority to carry out the supervisory responsibilities assigned to that office by the member.

(5) The assignment of each registered person to an appropriately registered representative(s) or principal(s) who shall be responsible for supervising that person's activities.

(6) The use of reasonable efforts to determine that all supervisory personnel are qualified, either by virtue of experience or training, to carry out their assigned responsibilities.

(7) The participation of each registered representative and registered principal, either individually or collectively, no less than annually, in an interview or meeting conducted by persons designated by the member at which compliance matters relevant to the activities of the representative(s) and principal(s) are discussed. Such interview or meeting may occur in conjunction with the discussion of other matters and may be conducted at a central or regional location or at the representative's(') or principal's(') place of business.

**(b) Written Procedures**

**(1) General Requirements**

Each member shall establish, maintain, and enforce written procedures to supervise the types of business in which it engages and the activities of its associated persons that are reasonably designed to achieve compliance with applicable securities laws and regulations, and with applicable FINRA rules.

**(2) Review of Member's Investment Banking and Securities Business**

The supervisory procedures required by this paragraph (b) shall include procedures for the review by a registered principal, evidenced in writing, of all transactions relating to the investment banking or securities business of the member.

**(3) Reserved.**

**(4) Review of Correspondence and Internal Communications**

The supervisory procedures required by this paragraph (b) shall include procedures for the review of incoming and outgoing written (including electronic) correspondence and internal communications relating to the member's investment banking or securities business. The supervisory procedures must be appropriate for the member's business, size, structure, and customers. The supervisory procedures must require the member's review of:

(A) incoming and outgoing written (including electronic) correspondence to properly identify and handle in accordance with firm procedures, customer complaints, instructions, funds and securities, and communications that are of a subject matter that require review under FINRA rules and federal securities laws.

(B) internal communications to properly identify those communications that are of a subject matter that require review under FINRA rules and federal securities laws.

Reviews of correspondence and internal communications must be conducted by a registered principal and must be evidenced in writing, either electronically or on paper.

**(5) Review of Customer Complaints**

The supervisory procedures required by this paragraph (b) shall include procedures to capture, acknowledge, and respond to all written (including electronic) customer complaints.

**(6) Documentation and Supervision of Supervisory Personnel**

The supervisory procedures required by this paragraph (b) shall set forth the supervisory system established by the member pursuant to paragraph (a) above, and shall include:

(A) the titles, registration status, and locations of the required supervisory personnel and the responsibilities of each supervisory person as these relate to the types of business engaged in, applicable securities laws and regulations, and FINRA rules.

(B) a record, preserved by the member for a period of not less than three years, the first two years in an easily accessible place, of the names of all persons who are designated as supervisory personnel and the dates for which such designation is or was effective.

(C) procedures prohibiting associated persons who perform a supervisory function from:

(i) supervising their own activities; and

(ii) reporting to, or having their compensation or continued employment determined by, a person or persons they are supervising.

a. If a member determines, with respect to any of its supervisory personnel, that compliance with subparagraph (i) or (ii) above is not possible because of the member's size or a supervisory personnel's position within the firm, the member must document:

1. the factors the member used to reach such determination; and

2. how the supervisory arrangement with respect to such supervisory personnel otherwise complies with paragraph (a) of this Rule.

(D) procedures reasonably designed to prevent the supervisory system required pursuant to paragraph (a) of this Rule from being compromised due to the conflicts of interest that may be present with respect to the associated person being supervised, including the position of such person, the revenue such person generates for the firm, or any compensation that the associated person conducting the supervision may derive from the associated person being supervised.

**(7) Maintenance of Written Supervisory Procedures**

A copy of a member's written supervisory procedures, or the relevant portions thereof, shall be kept and maintained in each OSJ and at each location where supervisory activities are conducted on behalf of the member. Each member shall promptly amend its written supervisory procedures to reflect changes in applicable securities laws or regulations, including FINRA rules, and as changes occur in its supervisory system. Each member is responsible for promptly communicating its written supervisory procedures and amendments to all associated persons to whom such written supervisory procedures and amendments are relevant based on their activities and responsibilities.

**(c) Internal Inspections**

(1) Each member shall conduct a review, at least annually (on a calendar-year basis), of the businesses in which it engages. The review shall be reasonably designed to assist the member in detecting and preventing violations of, and achieving compliance with, applicable securities laws and regulations, and with applicable FINRA rules. Each member shall review the activities of each office, which shall include the periodic examination of customer accounts to detect and prevent irregularities or abuses. Each member shall also retain a written record of the date upon which each review and inspection is conducted.

(A) Each member shall inspect at least annually (on a calendar-year basis) every OSJ and any branch office that supervises one or more non-branch locations.

(B) Each member shall inspect at least every three years every branch office that does not supervise one or more non-branch locations. In establishing how often to inspect each non-supervisory branch office, the member shall consider whether the nature and complexity of the securities activities for which the location is responsible, the volume of business done at the location, and the number of associated persons assigned to the location require the non-supervisory branch office to be inspected more frequently than every three years. If a member establishes a more frequent inspection cycle, the member must ensure that at least every three years, the inspection requirements enumerated in paragraph (c)(2) have been met. The member's written supervisory and inspection procedures shall set forth the non-supervisory branch office examination cycle, an explanation of the factors the member used in determining the frequency of the examinations in the cycle, and the manner in which a member will comply with paragraph (c)(2) if using more frequent inspections than every three years.

(C) Each member shall inspect on a regular periodic schedule every non-branch location. In establishing such schedule, the member shall consider the nature and complexity of the securities activities for which the location is responsible and the nature and extent of contact with customers. The member's written supervisory and inspection procedures shall set forth the schedule and an explanation regarding how the member determined the frequency of the examination.

(2) An inspection and review by a member pursuant to paragraph (c)(1) must be reduced to a written report and kept on file by the member for a minimum of three years, unless the inspection is being conducted pursuant to paragraph (c)(1)(C) and the regular periodic schedule is longer than a three-year cycle, in which case the report must be kept on file at least until the next inspection report has been written.

(A) If applicable to the location being inspected, that location's written inspection report must include, without limitation, the testing and verification of the member's policies and procedures, including supervisory policies and procedures in the following areas:

(i) safeguarding of customer funds and securities;

(ii) maintaining books and records;

(iii) supervision of supervisory personnel;

(iv) transmittals of funds (e.g., wires or checks, etc.) or securities from customers to third party accounts; from customer accounts to outside entities (e.g., banks, investment companies, etc.); from customer accounts to locations other than a customer's primary residence (e.g., post office box, "in care of" accounts, alternate address, etc.); and between customers and registered representatives, including the hand-delivery of checks; and

(v) changes of customer account information, including address and investment objectives changes and validation of such changes.

(B) The policies and procedures required by paragraph (c)(2)(A)(iv) must include a means or method of customer confirmation, notification, or follow-up that can be documented. Members may use reasonable risk-based criteria to determine the authenticity of the transmittal instructions.

(C) The policies and procedures required by paragraph (c)(2)(A)(v) must include, for each change processed, a means or method of customer confirmation, notification, or follow-up that can be documented and that complies with SEA Rules 17a-3(a)(17)(i)(B)(2) and 17a-3(a)(17)(i)(B)(3).

(D) If a member does not engage in all of the activities enumerated in paragraphs (c)(2)(A)(i) through (c)(2)(A)(v) at the location being inspected, the member must identify those activities in the member's written supervisory procedures or the location's written inspection report and document in the member's written supervisory procedures or the location's written inspection report that supervisory policies and procedures for such activities must be in place at that location before the member can engage in them.

(3) For each inspection conducted pursuant to paragraph (c), a member must:

(A) have procedures reasonably designed to prevent the effectiveness of the inspections required pursuant to paragraph (c)(1) of this Rule from being compromised due to the conflicts of interest that may be present with respect to the location being inspected, including but not limited to, economic, commercial, or financial interests in the associated persons and businesses being inspected; and

(B) ensure that the person conducting an inspection pursuant to paragraph (c)(1) is not an associated person assigned to the location or is not directly or indirectly supervised by, or otherwise reporting to, an associated person assigned to the location.

(C) If a member determines that compliance with paragraph (c)(3)(B) is not possible either because of a member's size or its business model, the member must document in the inspection report both the factors the member used to make its determination and how the inspection otherwise complies with paragraph (c)(1).

**(d) Transaction Review and Investigation**

(1) Each member shall include in its supervisory procedures a process for the review of securities transactions that are reasonably designed to identify trades that may violate the provisions of the Exchange Act, the rules thereunder, or FINRA rules prohibiting insider trading and manipulative and deceptive device that are effected for the:

(A) accounts of the member;

(B) accounts introduced or carried by the member in which a person associated with the member has a beneficial interest or the authority to make investment decisions;

(C) accounts of a person associated with the member that are disclosed to the member pursuant to [Rule 3210](/rules-guidance/rulebooks/finra-rules/3210); and

(D) covered accounts.

(2) Each member must conduct promptly an internal investigation into any such trade to determine whether a violation of those laws or rules has occurred.

(3) A member engaging in investment banking services must file with FINRA, written reports, signed by a senior officer of the member, at such times and, without limitation, including such content, as follows:

(A) within ten business days of the end of each calendar quarter, a written report describing each internal investigation initiated in the previous calendar quarter pursuant to paragraph (d)(2), including the identity of the member, the date each internal investigation commenced, the status of each open internal investigation, the resolution of any internal investigation reached during the previous calendar quarter, and, with respect to each internal investigation, the identity of the security, trades, accounts, associated persons of the member, or associated person of the member's family members holding a covered account, under review, and that includes a copy of the member's policies and procedures required by paragraph (d)(1).

(B) within five business days of completion of an internal investigation pursuant to paragraph (d)(2) in which it was determined that a violation of the provisions of the Exchange Act, the rules thereunder, or FINRA rules prohibiting insider trading and manipulative and deceptive devices had occurred, a written report detailing the completion of the investigation, including the results of the investigation, any internal disciplinary action taken, and any referral of the matter to FINRA, another self-regulatory organization, the SEC, or any other federal, state, or international regulatory authority.

(4) Definitions

For purposes of this Rule:

(A) The term "covered account" shall include any account introduced or carried by the member that is held by:

(i) the spouse of a person associated with the member;

(ii) a child of the person associated with the member or such person's spouse, provided that the child resides in the same household as or is financially dependent upon the person associated with the member;

(iii) any other related individual over whose account the person associated with the member has control; or

(iv) any other individual over whose account the associated person of the member has control and to whose financial support such person materially contributes.

(B) The term "investment banking services" shall include, without limitation, acting as an underwriter, participating in a selling group in an offering for the issuer, or otherwise acting in furtherance of a public offering of the issuer; acting as a financial adviser in a merger or acquisition; providing venture capital or equity lines of credit or serving as placement agent for the issuer or otherwise acting in furtherance of a private offering of the issuer.

**(e) Responsibility of Member to Investigate Applicants for Registration**

Each member shall ascertain by investigation the good character, business reputation, qualifications and experience of an applicant before the member applies to register that applicant with FINRA and before making a representation to that effect on the application for registration.

If the applicant previously has been registered with FINRA or another self-regulatory organization, the member shall review a copy of the applicant's most recent Form U5, including any amendments thereto, within 60 days of the filing date of an application for registration, or demonstrate to FINRA that it has made reasonable efforts to do so. In conducting its review of the Form U5, the member shall take such action as may be deemed appropriate.

The member shall also review an applicant's employment experience to determine if the applicant has been recently employed by a Futures Commission Merchant or an Introducing Broker that is notice-registered with the SEC pursuant to Section 15(b)(11) of the Exchange Act. In such a case, the member shall also review a copy of the applicant's most recent CFTC Form 8-T, including any amendments thereto, within 60 days of the filing date of an application for registration, or demonstrate to FINRA that it has made reasonable efforts to do so. In conducting its review of a Form 8-T, the member shall take such action as may be deemed appropriate.

In addition, each member shall establish and implement written procedures reasonably designed to verify the accuracy and completeness of the information contained in an applicant's initial or transfer Form U4 no later than 30 calendar days after the form is filed with FINRA. Such procedures shall, at a minimum, provide for a search of reasonably available public records to be conducted by the member, or a third-party service provider, to verify the accuracy and completeness of the information contained in the applicant's initial or transfer Form U4.

**(f) Definitions**

(1) "Office of Supervisory Jurisdiction" means any office of a member at which any one or more of the following functions take place:

(A) order execution or market making;

(B) structuring of public offerings or private placements;

(C) maintaining custody of customers' funds or securities;

(D) final acceptance (approval) of new accounts on behalf of the member;

(E) review and endorsement of customer orders, pursuant to paragraph (b)(2) above;

(F) final approval of retail communications for use by persons associated with the member, pursuant to [Rule 2210](/rules-guidance/rulebooks/finra-rules/2210)(b)(1), except for an office that solely conducts final approval of research reports; or

(G) responsibility for supervising the activities of persons associated with the member at one or more other branch offices of the member.

(2)

(A) A "branch office" is any location where one or more associated persons of a member regularly conducts the business of effecting any transactions in, or inducing or attempting to induce the purchase or sale of, any security, or is held out as such, excluding:

(i) Any location that is established solely for customer service or back office type functions where no sales activities are conducted and that is not held out to the public as a branch office;

(ii) Any location that is the associated person's primary residence; provided that

a. Only one associated person, or multiple associated persons who reside at that location and are members of the same immediate family, conduct business at the location;

b. The location is not held out to the public as an office and the associated person does not meet with customers at the location;

c. Neither customer funds nor securities are handled at that location;

d. The associated person is assigned to a designated branch office, and such designated branch office is reflected on all business cards, stationery, retail communications and other communications to the public by such associated person;

e. The associated person's correspondence and communications with the public are subject to the firm's supervision in accordance with this Rule;

f. Electronic communications (e.g., e-mail) are made through the member's electronic system;

g. All orders are entered through the designated branch office or an electronic system established by the member that is reviewable at the branch office;

h. Written supervisory procedures pertaining to supervision of sales activities conducted at the residence are maintained by the member; and

i. A list of the residence locations is maintained by the member;

(iii) Any location, other than a primary residence, that is used for securities business for less than 30 business days in any one calendar year, provided the member complies with the provisions of subparagraphs (2)(A)(ii)a. through h. above;

(iv) Any office of convenience, where associated persons occasionally and exclusively by appointment meet with customers, which is not held out to the public as an office; \*

(v) Any location that is used primarily to engage in non-securities activities and from which the associated person(s) effects no more than 25 securities transactions in any one calendar year; provided that any retail communication identifying such location also sets forth the address and telephone number of the location from which the associated person(s) conducting business at the non-branch locations are directly supervised;

(vi) The Floor of a registered national securities exchange where a member conducts a direct access business with public customers; or

(vii) A temporary location established in response to the implementation of a business continuity plan.

(B) Notwithstanding the exclusions in subparagraph (2)(A), any location that is responsible for supervising the activities of persons associated with the member at one or more non-branch locations of the member is considered to be a branch office.

(C) The term "business day" as used in paragraph (f)(2)(A) of this Rule shall not include any partial business day provided that the associated person spends at least four hours on such business day at his or her designated branch office during the hours that such office is normally open for business.

---

**• • • Supplementary Material: --------------**

**.01 Registration of Main Office.** A member's main office location is required to be registered and designated as a branch office or OSJ if it meets the definitions of a "branch office" or "office of supervisory jurisdiction" as set forth in Rule 3110(f). In general, the nature of activities conducted at a main office will satisfy the requirements of such terms.

**.02 Designation of Additional OSJs.** In addition to the locations that meet the definition of OSJ in Rule 3110(f), each member shall also register and designate other offices as OSJs as is necessary to supervise its associated persons in accordance with the standards set forth in Rule 3110. In making a determination as to whether to designate a location as an OSJ, the member should consider the following factors:

(a) whether registered persons at the location engage in retail sales or other activities involving regular contact with public customers;

(b) whether a substantial number of registered persons conduct securities activities at, or are otherwise supervised from, such location;

(c) whether the location is geographically distant from another OSJ of the firm;

(d) whether the member's registered persons are geographically dispersed; and

(e) whether the securities activities at such location are diverse or complex.

**.03 Supervision of Multiple OSJs by a Single Principal.** Rule 3110(a)(4) requires a member to designate one or more appropriately registered principals in each OSJ with the authority to carry out the supervisory responsibilities assigned to that office ("on-site principal"). The designated on-site principal for each OSJ must have a physical presence, on a regular and routine basis, at each OSJ for which the principal has supervisory responsibilities. Consequently, there is a general presumption that a principal will not be designated and assigned to be the on-site principal pursuant to Rule 3110(a)(4) to supervise more than one OSJ. If a member determines it is necessary to designate and assign one appropriately registered principal to be the on-site principal pursuant to Rule 3110(a)(4) to supervise two or more OSJs, the member must take into consideration, among others, the following factors:

(a) whether the on-site principal is qualified by virtue of experience and training to supervise the activities and associated persons in each location;

(b) whether the on-site principal has the capacity and time to supervise the activities and associated persons in each location;

(c) whether the on-site principal is a producing registered representative;

(d) whether the OSJ locations are in sufficiently close proximity to ensure that the on-site principal is physically present at each location on a regular and routine basis; and

(e) the nature of activities at each location, including size and number of associated persons, scope of business activities, nature and complexity of products and services offered, volume of business done, the disciplinary history of persons assigned to such locations, and any other indicators of irregularities or misconduct.

The member must establish, maintain, and enforce written supervisory procedures regarding the supervision of all OSJs. In all cases where a member designates and assigns one on-site principal to supervise more than one OSJ, the member must document in the member's written supervisory and inspection procedures the factors used to determine why the member considers such supervisory structure to be reasonable and the determination by the member will be subject to scrutiny.

**.04 Annual Compliance Meeting.** A member is not required to conduct in-person meetings with each registered person or group of registered persons to comply with the annual compliance meeting (or interview) required by Rule 3110(a)(7). A member that chooses to conduct compliance meetings using other methods (e.g., on-demand webcast or course, video conference, interactive classroom setting, telephone, or other electronic means) must ensure, at a minimum, that each registered person attends the entire meeting (e.g., an on-demand annual compliance webcast would require each registered person to use a unique user ID and password to gain access and use a technology platform to track the time spent on the webcast, provide click-as-you go confirmation, and have an attestation of completion at the end of a webcast) and is able to ask questions regarding the presentation and receive answers in a timely fashion (e.g., an on-demand annual compliance webcast that allows registered persons to ask questions via an email to a presenter or a centralized address or via a telephone hotline and receive timely responses directly or view such responses on the member's intranet site).

**.05 Risk-based Review of Member's Investment Banking and Securities Business.** A member may use a risk-based review system to comply with Rule 3110(b)(2)'s requirement that a registered principal review, all transactions relating to the investment banking or securities business of the member. A member is not required to conduct detailed reviews of each transaction if a member is using a reasonably designed risk-based review system that provides a member with sufficient information that permits the member to focus on the areas that pose the greatest numbers and risks of violation.

**.06 Risk-based Review of Correspondence and Internal Communications.** By employing risk-based principles, a member must decide the extent to which additional policies and procedures for the review of:

(a) incoming and outgoing written (including electronic) correspondence that fall outside of the subject matters listed in Rule 3110(b)(4) are necessary for its business and structure. If a member's procedures do not require that all correspondence be reviewed before use or distribution, the procedures must provide for:

(1) the education and training of associated persons regarding the firm's procedures governing correspondence;

(2) the documentation of such education and training; and

(3) surveillance and follow-up to ensure that such procedures are implemented and followed.

(b) internal communications that are not of a subject matter that require review under FINRA rules and federal securities laws are necessary for its business and structure.

**.07 Evidence of Review of Correspondence and Internal Communications.** The evidence of review required in Rule 3110(b)(4) must be chronicled either electronically or on paper and must clearly identify the reviewer, the internal communication or correspondence that was reviewed, the date of review, and the actions taken by the member as a result of any significant regulatory issues identified during the review. Merely opening a communication is not sufficient review.

**.08 Delegation of Correspondence and Internal Communication Review Functions.** In the course of the supervision and review of correspondence and internal communications required by Rule 3110(b)(4), a supervisor/principal may delegate certain functions to persons who need not be registered. However, the supervisor/principal remains ultimately responsible for the performance of all necessary supervisory reviews, irrespective of whether he or she delegates functions related to the review. Accordingly, supervisors/principals must take reasonable and appropriate action to ensure delegated functions are properly executed and should evidence performance of their procedures sufficiently to demonstrate overall supervisory control.

**.09 Retention of Correspondence and Internal Communications.** Each member shall retain the internal communications and correspondence of associated persons relating to the member's investment banking or securities business for the period of time and accessibility specified in SEA Rule 17a-4(b). The names of the persons who prepared outgoing correspondence and who reviewed the correspondence shall be ascertainable from the retained records, and the retained records shall be readily available to FINRA, upon request.

**.10 Supervision of Supervisory Personnel.** A member's determination that it is not possible to comply with paragraphs (b)(6)(C)(i) or (b)(6)(C)(ii) of Rule 3110 prohibiting supervisory personnel from supervising their own activities and from reporting to, or otherwise having compensation or continued employment determined by, a person or persons they are supervising generally will arise in instances where:

(a) the member is a sole proprietor in a single-person firm;

(b) a registered person is the member's most senior executive officer (or similar position); or

(c) a registered person is one of several of the member's most senior executive officers (or similar positions).

**.11 Use of Electronic Media to Communicate Written Supervisory Procedures.** A member may use electronic media to satisfy its obligation to communicate its written supervisory procedures, and any amendment thereto, pursuant to Rule 3110(b)(7), provided that: (1) the written supervisory procedures have been promptly communicated to, and are readily accessible by, all associated persons to whom such supervisory procedures apply based on their activities and responsibilities through, for example, the member's intranet system; (2) all amendments to the written supervisory procedures are promptly posted to the member's electronic media; (3) associated persons are notified that amendments relevant to their activities and responsibilities have been made to the written supervisory procedures; (4) the member has reasonable procedures to monitor and maintain the security of the material posted to ensure that it cannot be altered by unauthorized persons; and (5) the member retains current and prior versions of its written supervisory procedures in compliance with the applicable record retention requirements of SEA Rule 17a-4(e)(7).

**.12 Standards for Reasonable Review.** In fulfilling its obligations under Rule 3110(c), each member must conduct a review, at least annually, of the businesses in which it engages. The review must be reasonably designed to assist in detecting and preventing violations of and achieving compliance with applicable securities laws and regulations and with FINRA rules. Each member shall establish and maintain supervisory procedures that must take into consideration, among other things, the firm's size, organizational structure, scope of business activities, number and location of the firm's offices, the nature and complexity of the products and services offered by the firm, the volume of business done, the number of associated persons assigned to a location, the disciplinary history of registered representatives or associated persons, and any indicators of irregularities or misconduct (i.e., "red flags"), etc. The procedures established and reviews conducted must provide that the quality of supervision at remote locations is sufficient to ensure compliance with applicable securities laws and regulations and with FINRA rules. A member must be especially diligent in establishing procedures and conducting reasonable reviews with respect to a non-branch location where a registered representative engages in securities activities. Based on the factors outlined above, members may need to impose reasonably designed supervisory procedures for certain locations or may need to provide for more frequent reviews of certain locations.

**.13 General Presumption of Three-Year Limit for Periodic Inspection Schedules.** Rule 3110(c)(1)(C) requires a member to inspect on a regular periodic schedule every non-branch location. In establishing a non-branch location inspection schedule, there is a general presumption that a non-branch location will be inspected at least every three years, even in the absence of any indicators of irregularities or misconduct (i.e., "red flags"). If a member establishes a longer periodic inspection schedule, the member must document in its written supervisory and inspection procedures the factors used in determining that a longer periodic inspection cycle is appropriate.

**.14 Exception to Persons Prohibited from Conducting Inspections.** A member's determination that it is not possible to comply with Rule 3110(c)(3)(B) with respect to who is not allowed to conduct a location's inspection will generally arise in instances where:

(a) the member has only one office; or

(b) the member has a business model where small or single-person offices report directly to an OSJ manager who is also considered the offices' branch office manager.

**.15 Temporary Program to Address Underreported Form U4 Information.** FINRA is establishing a temporary program that will issue a refund to members of Late Disclosure Fees assessed for the late filing of responses to Form U4 Question 14M (unsatisfied judgments or liens) if the Form U4 amendment is filed between April 24, 2014 and December 1, 2015 and one of the following conditions is met: (1) the judgment or lien has been satisfied, and at the time it was unsatisfied, it was under $5,000 and the date the judgment or lien was filed with a court (as reported on Form U4 Judgment/Lien DRP, Question 4.A.) was on or before August 13, 2012; or (2) the unsatisfied judgment or lien was satisfied within 30 days after the individual learned of the judgment or lien (as reported on Form U4 Judgment/Lien DRP, Question 4.B.). This program has a retroactive effective date of April 24, 2014, and it will automatically sunset on December 1, 2015. Members will not be able to use the program after December 1, 2015.

**.16 Temporary Extension of Time to Complete Office Inspections.** Each member obligated to complete an inspection of an office of supervisory jurisdiction, branch office or non-branch location in calendar year 2020 pursuant to, as applicable, paragraphs (c)(1)(A), (B) and (C) under Rule 3110, shall be deemed to have satisfied such obligation if the applicable inspection is completed on or before March 31, 2021.

**.17 Temporary Relief to Allow Remote Inspections for Calendar Year 2020 and Calendar Year 2021**

**(a) Use of Remote Inspections.** Each member obligated to conduct an inspection of an office of supervisory jurisdiction, branch office or non-branch location in calendar year 2020 and calendar year 2021 pursuant to, as applicable, paragraphs (c)(1)(A), (B) and (C) under Rule 3110 may, subject to the requirements of this Rule 3110.17, satisfy such obligation by conducting the applicable inspection remotely, without an on-site visit to the office or location. In accordance with Rule 3110.16, inspections for calendar year 2020 must be completed on or before March 31, 2021 and inspections for calendar year 2021 must be completed on or before December 31, 2021. Notwithstanding Rule 3110.17, a member shall remain subject to the other requirements of Rule 3110(c).

**(b) Written Supervisory Procedures for Remote Inspections.** Consistent with a member’s obligation under Rule 3110(b)(1), a member that elects to conduct each of its calendar year 2020 or calendar year 2021 inspections remotely must amend or supplement its written supervisory procedures to provide for remote inspections that are reasonably designed to assist in detecting and preventing violations of and achieving compliance with applicable securities laws and regulations, and with applicable FINRA rules. Reasonably designed procedures for conducting remote inspections of offices or locations should include, among other things: (1) a description of the methodology, including technologies permitted by the member, that may be used to conduct remote inspections; and (2) the use of other risk-based systems employed generally by the member firm to identify and prioritize for review those areas that pose the greatest risk of potential violations of applicable securities laws and regulations, and of applicable FINRA rules.

**(c) Effective Supervisory System.** The requirement to conduct inspections of offices and locations is one part of the member’s overall obligation to have an effective supervisory system and therefore, the member must continue with its ongoing review of the activities and functions occurring at all offices and locations, whether or not the member conducts inspections remotely. A member’s use of a remote inspection of an office or location will be held to the same standards for review as set forth under Rule 3110.12. Where a member’s remote inspection of an office or location identifies any indicators of irregularities or misconduct (i.e., “red flags”), the member may need to impose additional supervisory procedures for that office or location or may need to provide for more frequent monitoring of that office or location, including potentially a subsequent physical, on-site visit on an announced or unannounced basis when the member’s operational difficulties associated with COVID-19 abate, nationally or locally as relevant, and the challenges a member is facing in light of the public health and safety concerns make such on-site visits feasible using reasonable best efforts. The temporary relief provided by this Rule 3110.17 does not extend to a member’s inspection requirements beyond calendar year 2021 and such inspections must be conducted in compliance with Rule 3110(c).

**(d) Documentation Requirement.** A member must maintain and preserve a centralized record for each of calendar year 2020 and calendar year 2021 that separately identifies: (1) all offices or locations that had inspections that were conducted remotely; and (2) any offices or locations for which the member determined to impose additional supervisory procedures or more frequent monitoring, as provided in Rule 3110.17(c). A member’s documentation of the results of a remote inspection for an office or location must identify any additional supervisory procedures or more frequent monitoring for that office or location that were imposed as a result of the remote inspection.

---

\* Where such office of convenience is located on bank premises, signage necessary to comply with applicable federal and state laws, rules and regulations and applicable rules and regulations of other self-regulatory organizations, and securities and banking regulators may be displayed and shall not be deemed “holding out” for purposes of this section.


Amended by SR-FINRA-2020-040 eff. Nov. 6, 2020. Amended by SR-FINRA-2020-019 eff. June 19, 2020. Amended by SR-FINRA-2017-004 eff. April 3, 2017. Amended by SR-FINRA-2015-005 eff. July 31, 2015. Amended by SR-FINRA-2014-038 eff. July 1, 2015. Amended by SR-FINRA-2013-025 eff. Dec. 1, 2014. Amended by SR-FINRA-2014-038 eff. April 24, 2014. Amended by SR-FINRA-2013-001 eff. Feb. 4, 2013. Amended by SR-FINRA-2007-008 eff. Dec. 19, 2007. Amended by SR-NASD-2006-037 eff. July 3, 2006. Amended by SR-NASD-2005-033 eff. Aug. 1, 2005. Amended by SR-NASD-2005-004 eff. July 25, 2005 Amended by SR-NASD-2002-162 and SR-NASD-2004-116 eff. Jan. 31, 2005. Amended by SR-NASD-2002-40 eff. Oct. 15, 2002. Amended by SR-NASD-2002-04 eff. Oct. 14, 2002. Amended by SR-NASD-99-28 eff. Aug. 16, 1999. Amended by SR-NASD-98-52 eff. March 15, 1999. Amended by SR-NASD-98-86 eff. Nov. 19, 1998. Amended by SR-NASD-97-69 eff. August 17, 1998. Amended by SR-NASD-98-45 postponed eff. date of provision in Notice to Members 98-11. Amended by SR-NASD-98-31 eff. Apr. 7, 1998, postponed eff. date of provision in Notice to Members. Amended by SR-NASD-98-10 postponed eff. date. Amended by SR-NASD-97-24 eff. Feb. 15, 1998. Amended by SR-NASD-97-41 eff. Sept. 4, 1997. Amended by SR-NASD-91-42 eff. Apr. 30, 1992. Amended by SR-NASD-88-31 eff. June 12, 1989.  **Selected Notices to Members:** [86-65](/rules-guidance/notices/86-65), [87-41](/rules-guidance/notices/87-41), [88-11](/rules-guidance/notices/88-11), [88-44](/rules-guidance/notices/88-44), [88-68](/rules-guidance/notices/88-68), [88-84](/rules-guidance/notices/88-84), [89-23](/rules-guidance/notices/89-23), [89-34](/rules-guidance/notices/89-34), [89-57](/rules-guidance/notices/89-57), [91-48](/rules-guidance/notices/91-48), [92-18](/rules-guidance/notices/92-18), [96-33](/rules-guidance/notices/96-33), [96-59](/rules-guidance/notices/96-59), [96-82](/rules-guidance/notices/96-82), [98-11](/rules-guidance/notices/98-11), [98-18](/rules-guidance/notices/98-18), [98-38](/rules-guidance/notices/98-38), [98-52](/rules-guidance/notices/98-52), [98-96](/rules-guidance/notices/98-96), [99-03](/rules-guidance/notices/99-03), [99-45](/rules-guidance/notices/99-45), [04-71](/rules-guidance/notices/04-71), [05-67](/rules-guidance/notices/05-67), [06-13](/rules-guidance/notices/06-13), [07-64](/rules-guidance/notices/07-64), [14-10](/rules-guidance/notices/14-10), [24-02](/rules-guidance/notices/24-02).

- **Regulatory Notice 24-02**

  [FINRA Adopts FINRA Rule 3110.19 (Residential Supervisory Location) and FINRA Rule 3110.18 (Remote Inspections Pilot Program), and Announces End of Temporary Relief Related to Updates of Office Information on Forms U4 and BR](/rules-guidance/notices/24-02)

  *January 23, 2024*
- **Regulatory Notice 19-34**

  [Annual Compliance Meetings: Retrospective Rule Review Report and Guidance](/rules-guidance/notices/19-34)

  *October 18, 2019*
- **Regulatory Notice 18-25**

  [FINRA Reminds Alternative Trading Systems of Their Obligations to Supervise Activity on Their Platforms](/rules-guidance/notices/18-25)

  *August 13, 2018*
- **Regulatory Notice 18-16**

  [FINRA Requests Comment on FINRA Rule Amendments Relating to High-Risk Brokers and the Firms That Employ Them](/rules-guidance/notices/18-16)

  *April 30, 2018*
- **Regulatory Notice 18-15**

  [Guidance on Implementing Effective Heightened Supervisory Procedures for Associated Persons With a History of Past Misconduct](/rules-guidance/notices/18-15)

  *April 30, 2018*
- **Regulatory Notice 18-14**

  [FINRA Requests Comment on the Effectiveness and Efficiency of Its Rule on the Annual Compliance Meeting](/rules-guidance/notices/18-14)

  *April 24, 2018*
- **Regulatory Notice 17-38**

  [FINRA Requests Comment on a Proposal to Amend Rule 3110 (Supervision) to Provide Firms the Option to Conduct Remote Inspections of Offices and Locations That Meet Specified Criteria](/rules-guidance/notices/17-38)

  *November 13, 2017*
- **Regulatory Notice 17-32**

  [FINRA Reminds Firms of Sales Practice Obligations for Volatility-Linked Exchange-Traded Products](/rules-guidance/notices/17-32)

  *October 16, 2017*
- **Regulatory Notice 17-13**

  [FINRA’s NAC Revises the Sanction Guidelines](/rules-guidance/notices/17-13)

  *April 10, 2017*
- **Regulatory Notice 17-06**

  [FINRA Requests Comment on Proposed Amendments to Rules Governing Communications with the Public](/rules-guidance/notices/17-06)

  *February 10, 2017*
- **Regulatory Notice 16-22**

  [SEC Approves Consolidated FINRA Rule 3210 (Accounts At Other Broker-Dealers and Financial Institutions)](/rules-guidance/notices/16-22)

  *June 30, 2016*
- **Regulatory Notice 16-21**

  [SEC Approves Rule to Require Registration of Associated Persons Involved in the Design, Development or Significant Modification of Algorithmic Trading Strategies](/rules-guidance/notices/16-21)

  *June 06, 2016*
- **Regulatory Notice 16-12**

  [FINRA Provides Guidance on Firm Responsibilities for Sales of Pension Income Stream Products](/rules-guidance/notices/16-12)

  *April 18, 2016*
- **Regulatory Notice 16-10**

  [Direct Purchases and Bank Loans as Alternatives to Public Financing in the Municipal Securities Market](/rules-guidance/notices/16-10)

  *April 04, 2016*
- **Regulatory Notice 16-06**

  [SEC Approval of FINRA Funding Portal Rules and Related Forms](/rules-guidance/notices/16-06)

  *January 29, 2016*

- [Supervision Frequently Asked Questions (FAQ)](/rules-guidance/key-topics/supervision/faq)
