# CELEX_32017R0565_EN_TXT

Source File: CELEX_32017R0565_EN_TXT.pdf
Page Count: 83
Warnings: none

<!-- source-page: 1 -->

II
(Non-legislative acts)
REGULATIONS
COMMISSION DELEGATED REGULATION (EU) 2017/565
of 25 April 2016
supplementing Directive 2014/65/EU of the European Parliament and of the Council as regards
organisational requirements and operating conditions for investment firms and defined terms for
the purposes of that Directive
(Text with EEA relevance)
THE EUROPEAN COMMISSION,
Having regard to the Treaty on the Functioning of the European Union,
Having regard to Directive 2014/65/EU of the European Parliament and of the Council of 15 May 2014 on markets in
financial instruments and amending Directive 2002/92/EC and Directive 2011/61/EU (1), and in particular Article 2(3),
the second subparagraph of Article 4(1)(2), and Articles 4(2), 16(12), 23(4), 24(13), 25(8), 27(9), 28(3), 30(5), 31(4),
32(4), 33(8), 52(4), 54(4), 58(6), 64(7), 65(7) and 79(8) thereof,
Whereas:
(1)
Directive 2014/65/EU establishes the framework for a regulatory regime for financial markets in the Union,
governing operating conditions relating to the performance by investment firms of investment services and,
where appropriate, ancillary services and investment activities; organisational requirements for investment firms
performing such services and activities, for regulated markets and data reporting services providers; reporting
requirements in respect of transactions in financial instruments; position limits and position management
controls in commodity derivatives; transparency requirements in respect of transactions in financial instruments.
(2)
Directive 2014/65/EU empowers the Commission to adopt a number of delegated acts. It is important that all
the detailed supplementing rules regarding the authorisation, ongoing operation, market transparency and
integrity, which are inextricably-linked aspects inherent to the taking up and pursuit of the services and activities
covered by Directive 2014/65/EU, begin to apply at the same time as Directive 2014/65/EU so that the new
requirements can operate effectively. To ensure coherence and to facilitate a comprehensive view and compact
access to the provisions by persons subject to those obligations as well as by investors, it is desirable to include
the delegated acts related to the above-mentioned rules in this Regulation.
(3)
It is necessary to further specify the criteria to determine under what circumstances contracts in relation to
wholesale energy products must be physically settled for the purposes of the limitation of scope set out in
Section C(6) of Annex I to Directive 2014/65/EU. In order to ensure that the scope of this exemption is limited
to avoid loopholes it is necessary that such contracts require that both buyer and seller should have proportionate
arrangements in place to make or receive delivery of the underlying commodity upon the expiry of the contract.
In order to avoid loopholes in case of balancing agreements with the Transmission System Operator in the areas
31.3.2017
L 87/1
Official Journal of the European Union
EN
(1) OJ L 173, 12.6.2014, p. 349.

<!-- source-page: 2 -->

of electricity and gas, such balancing arrangements should only be considered as a proportionate arrangement if
the parties to the arrangement have the obligation to physically deliver electricity or gas. Contracts should also
establish clear obligations for physical delivery which cannot be offset whilst recognising that forms of
operational netting as defined in Regulation (EU) No 1227/2011 of the European Parliament and of the
Council (1) or national law should not considered as offsetting. Contracts which must be physically settled should
be permitted to deliver in a variety of methods however all methods should involve a form of transfer of right of
an ownership nature of the relevant underlying commodity or a relevant quantity thereof.
(4)
In order to clarify when a contract in relation to wholesale energy product must be physically settled, it is
necessary to further specify when certain circumstances such as force majeure or bona fide inability to settle
provisions are present, and which should not alter the characterisation of those contracts as ‘must be physically
settled’. It is important to also clarify how oil and coal energy derivatives should be understood for the purposes
of Section C(6) of Annex I to Directive 2014/65/EU. In this context, contracts related to oil shale should not be
understood to be coal energy derivatives.
(5)
A derivative contract should only be considered to be a financial instrument under Section C(7) of Annex I to
Directive 2014/65/EU if it relates to a commodity and meets a set of criteria for determining whether a contract
should be considered as having the characteristics of other derivative financial instruments and as not being for
commercial purposes. This should include contracts which are standardised and traded on venues, or contracts
equivalent thereof where all the terms of such contracts are equivalent to contracts traded on venues. In this case,
terms of these contracts should also be understood to include provisions such as quality of the commodity or
place of delivery.
(6)
In order to provide clarity on the definitions of contracts relating to underlying variables set out in Section C(10)
of Directive 2014/65/EU, criteria should be provided relating to their terms and underlying variables in those
contracts. The inclusion of actuarial statistics in the list of underlyings should not be understood as extending the
scope of those contracts to insurance and reinsurance.
(7)
Directive 2014/65/EU establishes the general framework for a regulatory regime for financial markets in the
Union, setting out in Section C of Annex I the list of financial instruments covered. Section C(4) of Annex I to
Directive 2014/65/EU includes financial instruments relating to a currency which are therefore under the scope
of this Directive.
(8)
In order to ensure the uniform application of Directive 2014/65/EU, it is necessary to clarify the definitions laid
down in Section C(4) of Annex I to Directive 2014/65/EU for other derivative contracts relating to currencies
and to clarify that spot contracts relating to currencies are not other derivative instruments for the purposes of
Section C(4) of Annex I to Directive 2014/65/EU.
(9)
The settlement period for a spot contract is generally accepted in most main currencies as taking place within
2 days or less, but where this is not market practice it is necessary to make provision to allow settlement to take
place in accordance with normal market practice. In such cases, physical settlement does not require the use of
paper money and can include electronic settlement.
(10)
Foreign exchange contracts may also be used for the purpose of effecting payment and those contracts should
not be considered financial instruments provided they are not traded on a trading venue. Therefore it is
appropriate to consider as spot contracts those foreign exchange contracts that are used to effect payment for
financial instruments where the settlement period for those contracts is more than 2 trading days and less than
5 trading days. It is also appropriate to consider as means of payments those foreign exchange contracts that are
entered into for the purpose of achieving certainty about the level of payments for goods, services and real
investment. This will result in excluding from the definition of financial instruments foreign exchange contracts
entered into by non-financial firms receiving payments in foreign currency for exports of identifiable goods and
services and non-financial firms making payments in foreign currency to import specific goods and services.
31.3.2017
L 87/2
Official Journal of the European Union
EN
(1) Regulation (EU) No 1227/2011 of the European Parliament and of the Council of 25 October 2011 on wholesale energy market
integrity and transparency (OJ L 326, 8.12.2011, p. 1).

<!-- source-page: 3 -->

(11)
Payment netting is essential to the effective and efficient operation of currency settlement systems and therefore
the classification of a foreign currency contract as a spot transaction should not require that each foreign
currency spot contract is settled independently.
(12)
Non deliverable forwards are contracts for the difference between an exchange rate agreed before and the actual
spot rate at maturity and therefore should not be considered to be spot contracts, regardless of their settlement
period.
(13)
A contract for the exchange of one currency against another currency should be understood as relating to
a direct and unconditional exchange of those currencies. In the case of a contract with multiple exchanges, each
exchange should be considered separately. However an option or a swap on a currency should not be considered
a contract for the sale or exchange of a currency and therefore could not constitute either a spot contract or
means of payment regardless of the duration of the swap or option and regardless of whether it is traded on
a trading venue or not.
(14)
Advice about financial instruments addressed to the general public should not be considered as a personal
recommendation for the purposes of the definition of ‘investment advice’ in Directive 2014/65/EU. In view of
the growing number of intermediaries providing personal recommendations through the use of distribution
channels, it should be clarified that a recommendation issued, even exclusively, through distribution channels,
such as internet, could qualify as a personal recommendation. Therefore, situations in which, for instance, email
correspondence is used to provide personal recommendations to a specific person, rather than to address
information to the public in general, may amount to investment advice.
(15)
Generic advice about a type of financial instrument is not considered investment advice for the purposes of
Directive 2014/65/EU. However, if an investment firm provides generic advice to a client about a type of
financial instrument which it presents as suitable for, or based on a consideration of the circumstances of, that
client, and that advice is not in fact suitable for the client, or is not based on a consideration of his circumstances,
the firm is likely to be acting in contravention of Article 24(1) or (3) of Directive 2014/65/EU In particular,
a firm which gives a client such advice would be likely to contravene the requirement of Article 24(1) to act
honestly, fairly and professionally in accordance with the best interests of its clients. Similarly or alternatively,
such advice would be likely to contravene the requirement of Article 24(3) that information addressed by a firm
to a client should be fair, clear and not misleading.
(16)
Acts carried out by an investment firm that are preparatory to the provision of an investment service or carrying
out an investment activity should be considered as an integral part of that service or activity. This would include,
for example, the provision of generic advice by an investment firm to clients or potential clients prior to or in
the course of the provision of investment advice or any other investment service or activity.
(17)
The provision of a general recommendation about a transaction in a financial instrument or a type of financial
instrument constitutes the provision of an ancillary service within Section B(5) of Annex I to Directive
2014/65/EU, and consequently Directive 2014/65/EU and its protections apply to the provision of that
recommendation.
(18)
In order to ensure the objective and effective application of the definition of systematic internalisers in the Union
in accordance with Article 4(1)(20) of Directive 2014/65/EU, further specifications should be provided on the
applicable pre-set limits for the purposes of what constitutes frequent systematic and substantial over the counter
(OTC) trading. Pre-set limits should be set at an appropriate level to ensure that OTC trading of such a size that it
had a material effect on price formation is within scope while at the same time excluding OTC trading of such
a small size that it would be disproportionate to require the obligation to comply with the requirements
applicable to systematic internalisers.
(19)
Pursuant to Directive 2014/65/EU, a systematic internaliser should not be allowed to bring together third party
buying and selling interests in functionally the same way as a trading venue. A systematic internaliser should not
consist of an internal matching system which executes client orders on a multilateral basis, an activity which
31.3.2017
L 87/3
Official Journal of the European Union
EN

<!-- source-page: 4 -->

requires authorisation as a multilateral trading facility (MTF). An internal matching system in this context is
a system for matching client orders which results in the investment firm undertaking matched principal
transactions on a regular and not occasional basis.
(20)
For reasons of clarity and legal certainty and to ensure a uniform application, it is appropriate to provide supple­
mentary provisions in relation to the definitions in relation to algorithmic trading, high frequency algorithmic
trading techniques and direct electronic access. In automated trading, various technical arrangements are
deployed. It is essential to clarify how those arrangements are to be categorised in relation to the definitions of
algorithmic trading and direct electronic access. The trading processes based on direct electronic access are not
mutually exclusive to those involving algorithmic trading or its sub-segment high frequency algorithmic trading
technique. The trading of a person having direct electronic access may therefore also fall under the algorithmic
trading including the high frequency algorithmic trading technique definition.
(21)
Algorithmic trading in accordance with Article 4(1)(39) of Directive 2014/65/EU should include arrangements
where the system makes decisions, other than only determining the trading venue or venues on which the order
should be submitted, at any stage of the trading processes including at the stage of initiating, generating, routing
or executing orders. Therefore, it should be clarified that algorithmic trading, which encompasses trading with no
or limited human intervention, should refer not only to the automatic generation of orders but also to the
optimisation of order-execution processes by automated means.
(22)
Algorithmic trading should encompass smart order routers (SORs) where such devices use algorithms for
optimisation of order execution processes that determine parameters of the order other than the venue or venues
where the order should be submitted. Algorithmic trading should not encompass automated order routers (AOR)
where, although using algorithms, such devices only determine the trading venue or venues where the order
should be submitted without changing any other parameter of the order.
(23)
High frequency algorithmic trading technique in accordance with Article 4(1)(40) of Directive 2014/65/EU,
which is a subset of algorithmic trading, should be further specified through the establishment of criteria to
define high message intraday rates which constitutes orders quotes or modifications or cancellations thereof.
Using absolute quantitative thresholds on the basis of messaging rates provides legal certainty by allowing firms
and competent authorities to assess the individual trading activity of firms. The level and scope of these
thresholds should be sufficiently broad to cover trading which constitute high frequency trading technique,
including those in relation to single instruments and multiple instruments.
(24)
Since the use of high frequency algorithmic trading technique is predominantly common in liquid instruments,
only instruments for which there is a liquid market should be included in the calculation of high intraday
message rate. Also, given that high frequency algorithmic trading technique is a subset of algorithmic trading,
messages introduced for the purpose of trading that fulfil the criteria in Article 17(4) of Directive 2014/65/EU
should be included in the calculation of intraday message rates. In order not to capture trading activity other than
high frequency algorithmic trading techniques, having regard to the characteristics of such trading as set out in
recital 61 of Directive 2014/65/EU, in particular that such trading is typically done by traders using their own
capital to implement more traditional trading strategies such as market making or arbitrage through the use of
sophisticated technology, only messages introduced for the purposes of dealing on own account, and not those
introduced for the purposes of receiving and transmitting orders or executing orders of behalf of clients, should
be included in the calculation of high intraday message rates. However, messages introduced through other
techniques than those relying on trading on own account should be included in the calculation of high intraday
message rate where, viewed as a whole and taking into account all circumstances, the execution of the technique
is structured in such a way as to avoid the execution taking place on own account, such as through the
transmission of orders between entities within the same group. In order to take into account, when determining
what constitutes high message intra-day rates, the identity of the client ultimately behind the activity, messages
which were originated by clients of DEA providers should be excluded from the calculation of high intraday
message rate in relation to such providers.
(25)
The definition of direct electronic access should be further specified. The definition of direct electronic access
should not encompass any other activity beyond the provision of direct market access and sponsored access.
Therefore, arrangements where client orders are intermediated through electronic means by members or
participants of a trading venue such as online brokerage and arrangements where clients have direct electronic
access to a trading venue should be distinguished.
31.3.2017
L 87/4
Official Journal of the European Union
EN

<!-- source-page: 5 -->

(26)
In case of order intermediation, submitters of orders do not have sufficient control over the parameters of the
arrangement for market access and should therefore not fall within scope of direct electronic access. Therefore,
arrangements that allow clients to transmit orders to an investment firm in an electronic format, such as online
brokerage, should be not be considered direct electronic access provided that clients do not have the ability to
determine the fraction of a second of order entry and the life time of orders within that time frame.
(27)
Arrangements where the client of a member or participant of a trading venue, including the client of a direct
clients of organised trading facilities (OTFs), submit their orders through arrangements for optimisation of order
execution processes that determine parameters of the order other than the venue or venues where the order
should be submitted through SORs embedded into the provider's infrastructure and not on the client's
infrastructure should be excluded from the scope of direct electronic access since the client of the provider does
not have control over the time of submission of the order and its lifetime. The characterisation of direct
electronic access when deploying smart order routers should therefore be dependent on whether the smart order
router is embedded in the clients' systems and not in that of the provider.
(28)
The rules for the implementation of the regime governing organisational requirements for investment firms
performing investment services and, where appropriate, ancillary services and investment activities on
a professional basis, for regulated markets, and data reporting services providers should be consistent with the
aim of Directive 2014/65/EU. They should be designed to ensure a high level of integrity, competence and
soundness among investment firms and entities that operate regulated markets, MTFs or OTFs, and to be applied
in a uniform manner.
(29)
It is necessary to specify concrete organisational requirements and procedures for investment firms performing
such services or activities. In particular, rigorous procedures should be provided for with regard to matters such
as compliance, risk management, complaints handling, personal transactions, outsourcing and the identification,
management and disclosure of conflicts of interest.
(30)
The organisational requirements and conditions for authorisation for investment firms should be set out in the
form of a set of rules that ensures the uniform application of the relevant provisions of Directive 2014/65/EU.
This is necessary in order to ensure that investment firms have equal access on equivalent terms to all markets in
the Union and to eliminate obstacles, linked to authorisation procedures, to cross-border activities in the field of
investment services.
(31)
The rules for the implementation of the regime governing operating conditions for the performance of
investment and ancillary services and investment activities should reflect the aim underlying that regime. They
should be designed to ensure a high level of investor protection to be applied in a uniform manner through the
introduction of clear standards and requirements governing the relationship between an investment firm and its
client. On the other hand, as regards investor protection, and in particular the provision of investors with
information or the seeking of information from investors, the retail or professional nature of the client or
potential client concerned should be taken into account.
(32)
In order to ensure the uniform application of the various relevant provisions of Directive 2014/65/EU, it is
necessary to establish a harmonised set of organisational requirements and operating conditions for investment
firms.
(33)
Investment firms vary widely in their size, their structure and the nature of their business. A regulatory regime
should be adapted to that diversity while imposing certain fundamental regulatory requirements which are
appropriate for all firms. Regulated entities should comply with their high level obligations and design and adopt
measures that are best suited to their particular nature and circumstances.
(34)
It is appropriate to set out common criteria for assessing whether an investment service is provided by a person
in an incidental manner in the course of a professional activity, in order to ensure a harmonised and strict
implementation of the exemption granted by Directive 2014/65/EU. The exemption should only apply if the
investment service has an intrinsic connection to the main area of the professional activity and is subordinated
thereto.
(35)
The organisational requirements established under Directive 2014/65/EU should be without prejudice to systems
established by national law for the registration or monitoring by competent authorities or firms of individuals
working within investment firms.
31.3.2017
L 87/5
Official Journal of the European Union
EN

<!-- source-page: 6 -->

(36)
For the purposes of requiring an investment firm to establish, implement and maintain an adequate risk
management policy, the risks relating to the firm's activities, processes and systems should include the risks
associated with the outsourcing of critical or important functions. Those risks should include those associated
with the firm's relationship with the service provider, and the potential risks posed where the outsourced
functions of multiple investment firms or other regulated entities are concentrated within a limited number of
service providers.
(37)
The fact that risk management and compliance functions are performed by the same person does not necessarily
jeopardise the independent functioning of each function. The conditions that persons involved in the compliance
function should not also be involved in the performance of the functions that they monitor, and that the method
of determining the remuneration of such persons should not be likely to compromise their objectivity, may not
be proportionate in the case of small investment firms. However, they would only be disproportionate for larger
firms in exceptional circumstances.
(38)
Clients or potential clients should be enabled to express their dissatisfaction with investment services provided by
investment firms in the interests of investor protection as well as strengthening investment firms' compliance
with their obligations. Clients' or potential clients' complaints should be handled effectively and in an
independent manner by a complaints management function. In line with the principle of proportionality, that
function could be carried out by the compliance function.
(39)
Investment firms are required to collect and maintain information relating to clients and services provided to
clients. Where those requirements involve the collection and processing of personal data, the respect of the right
to the protection of personal data in accordance with Directive 95/46/EC of the European Parliament and of the
Council (1) and Directive 2002/58/EC of the European Parliament and of the Council (2) which govern the
processing of personal data carried out in application of this Directive should be ensured. Processing of personal
data by the European Securities and Markets Authority (ESMA) in the application of this Regulation is subject to
Regulation (EC) No 45/2001 of the European Parliament and of the Council (3).
(40)
A definition of remuneration should be introduced in order to ensure the efficient and consistent application of
the conflicts of interest and conduct of business requirements in the area of remuneration and should include all
forms of financial or non-financial benefits or payments provided directly or indirectly by firms to relevant
persons in the provision of investment or ancillary services to clients, such as cash, shares, options, cancellations
of loans to relevant persons at dismissal, pension contributions, remuneration by third parties for instance
through carried interest models, wage increases or promotions, health insurance, discounts or special allowances,
generous expense accounts or seminars in exotic destinations.
(41)
In order to ensure that clients' interests are not impaired, investment firms should design and implement
remuneration policies to all persons who could have an impact on the service provided or corporate behaviour of
the firm, including persons who are front-office staff, sales force staff or other staff indirectly involved in the
provision of investment or ancillary services. Persons overseeing the sales forces, such as line managers, who may
be incentivised to pressure sales staff, or financial analysts whose literature may be used by sales staff to entice
clients to make investment decisions or persons involved in complaints-handling or in product design and
development should also be included in the scope of relevant persons concerned by remuneration rules. Relevant
persons should also include tied agents. When determining the remuneration for tied agents, firms should take
the tied agents' special status and the respective national specificities into consideration. However, in such cases,
firms' remuneration policies and practices should still define appropriate criteria to be used to assess the
performance of relevant persons, including qualitative criteria encouraging the relevant persons to act in the best
interests of the client.
(42)
Where successive personal transactions are carried out on behalf of a person in accordance with prior
instructions given by that person, obligations relating to personal transactions should not apply separately to
31.3.2017
L 87/6
Official Journal of the European Union
EN
(1) Directive 95/46/EC of the European Parliament and of the Council of 24 October 1995 on the protection of individuals with regard to
the processing of personal data and on the free movement of such data (OJ L 281, 23.11.1995, p. 31).
(2) Directive 2002/58/EC of the European Parliament and of the Council of 12 July 2002 concerning the processing of personal data and
the protection of privacy in the electronic communications sector (OJ L 201, 31.7.2002, p. 37).
(3) Regulation (EC) No 45/2001 of the European Parliament and of the Council of 18 December 2000 on the protection of individuals with
regard to the processing of personal data by the Community institutions and bodies and on the free movement of such data (OJ L 8,
12.1.2001, p. 1).

<!-- source-page: 7 -->

each such successive transaction if those instructions remain in force and unchanged. Similarly, those obligations
should not apply to the termination or withdrawal of such instructions, provided that any financial instruments
which had previously been acquired pursuant to the instructions are not disposed of at the same time as the
instructions terminate or are withdrawn. However, those obligations should apply in relation to a personal
transaction, or the commencement of successive personal transactions, carried out on behalf of the same person
if those instructions are changed or if new instructions are issued.
(43)
Competent authorities should not make the authorisation to provide investment services or activities subject to
a general prohibition on the outsourcing of one or more critical or important functions. Investment firms should
be allowed to outsource such functions if the outsourcing arrangements established by the firm comply with
certain conditions.
(44)
The outsourcing of investment services or activities or critical and important functions is capable of constituting
a material change of the conditions for the authorisation of the investment firm, as referred to in Article 21(2) of
Directive 2014/65/EU. If such outsourcing arrangements are to be put in place after the investment firm has
obtained an authorisation according to Chapter I of Title II of Directive 2014/65/EU, those arrangements should
be notified to the competent authority where required by Article 21(2) of that Directive.
(45)
The circumstances which should be treated as giving rise to a conflict of interest should cover cases where there
is a conflict between the interests of the firm or certain persons connected to the firm or the firm's group and
the duty the firm owes to a client; or between the differing interests of two or more of its clients, to each of
whom the firm owes a duty. It is not enough that the firm may gain a benefit if there is not also a possible
disadvantage to a client, or that one client to whom the firm owes a duty may make a gain or avoid a loss
without there being a concomitant possible loss to another such client.
(46)
Conflicts of interest should be regulated only where an investment service or ancillary service is provided by an
investment firm. The status of the client to whom the service is provided — as either retail, professional or
eligible counterparty — should be irrelevant for that purpose.
(47)
In complying with its obligation to draw up a conflict of interest policy under Directive 2014/65/EU which
identifies circumstances which constitute or may give rise to a conflict of interest, the investment firm should
pay special attention to the activities of investment research and advice, proprietary trading, portfolio
management and corporate finance business, including underwriting or selling in an offering of securities and
advising on mergers and acquisitions. In particular, such special attention is appropriate where the firm or
a person directly or indirectly linked by control to the firm performs a combination of two or more of those
activities.
(48)
Investment firms should aim to identify and prevent or manage the conflicts of interest arising in relation to
their various business lines and their group's activities under a comprehensive conflicts of interest policy. While
disclosure of specific conflicts of interest is required by Article 23(2) of Directive 2014/65/EU, it should be
a measure of last resort to be used only where the organisational and administrative arrangements established by
the investment firm to prevent or manage its conflicts of interest in accordance with Article 23(1) of Directive
2014/65/EU are not sufficient to ensure, with reasonable confidence, that the risks of damage to the interests of
the client are prevented. Over-reliance on disclosure without adequate consideration as to how conflicts may
appropriately be prevented or managed should not be permitted. The disclosure of conflicts of interest by an
investment firm should not exempt it from the obligation to maintain and operate the effective organisational
and administrative arrangements required under Article 16(3) of Directive 2014/65/EU.
(49)
Firms should always comply with the inducements rules under Article 24 of Directive 2014/65/EU, including
when providing placing services. In particular, fees received by investment firms placing the financial instruments
issued to its investment clients should comply with these provisions and laddering and spinning should be
considered as abusive practices.
(50)
Investment research should be a sub-category of the type of information defined as a recommendation in
Regulation (EU) No 596/2014 of the European Parliament and of the Council (1) (market abuse).
31.3.2017
L 87/7
Official Journal of the European Union
EN
(1) Regulation (EU) No 596/2014 of the European Parliament and of the Council of 16 April 2014 on market abuse (market abuse
Regulation) and repealing Directive 2003/6/EC of the European Parliament and of the Council and Commission Directives
2003/124/EC, 2003/125/EC and 2004/72/EC (OJ L 173, 12.6.2014, p. 1).

<!-- source-page: 8 -->

(51)
The measures and arrangements adopted by an investment firm to manage the conflicts of interests that might
arise from the production and dissemination of material that is presented as investment research should be
appropriate to protect the objectivity and independence of financial analysts and of the investment research they
produce. Those measures and arrangements should ensure that financial analysts enjoy an adequate degree of
independence from the interests of persons whose responsibilities or business interests may reasonably be
considered to conflict with the interests of the persons to whom the investment research is disseminated.
(52)
Persons whose responsibilities or business interests may reasonably be considered to conflict with the interests of
the persons to whom investment research is disseminated should include corporate finance personnel and
persons involved in sales and trading on behalf of clients or the firm.
(53)
Exceptional circumstances in which financial analysts and other persons connected with the investment firm who
are involved in the production of investment research may, with prior written approval, undertake personal
transactions in instruments to which the research relates should include those circumstances where, for personal
reasons relating to financial hardship, the financial analyst or other person is required to liquidate a position.
(54)
Fees, commissions, monetary or non-monetary benefits received by the firm providing investment research from
any third party should only be acceptable when they are provided in accordance with requirements specified in
Article 24(9) of Directive 2014/65/EU and Article 13 of Commission Delegated Directive (EU) 2017/593 (1).
(55)
The concept of dissemination of investment research to clients or the public should not include dissemination
exclusively to persons within the group of the investment firm. Current recommendations should be considered
to be those recommendations contained in investment research which have not been withdrawn and which have
not lapsed. The substantial alteration of investment research produced by a third party should be governed by the
same requirements as the production of research.
(56)
Financial analysts should not engage in activities other than the preparation of investment research where
engaging in such activities are inconsistent with the maintenance of that person's objectivity. These include
participating in investment banking activities such as corporate finance business and underwriting, participating
in ‘pitches’ for new business or ‘road shows’ for new issues of financial instruments; or being otherwise involved
in the preparation of issuer marketing.
(57)
Given the specificities of underwriting and placing services and the potential for conflicts of interest to arise in
relation to such services, more detailed and tailored requirements should be specified in this Regulation. In
particular, such requirements should ensure that the underwriting and placing process is managed in a way
which respects the interests of different actors. Investment firms should ensure that their own interests or
interests of their other clients do not improperly influence the quality of services provided to the issuer client.
Such arrangements should be explained to that client, along with other relevant information about the offering
process, before the firm accepts to undertake the offering.
(58)
Investment firms engaged in underwriting or placing activities should have appropriate arrangements in place to
ensure that the pricing process, including book-building, is not detrimental to the issuer's interests.
(59)
The placing process involves the exercise of judgement by an investment firm as to the allocation of an issue, and
is based on the particular facts and circumstances of the arrangements, which raises conflicts of interest
concerns. The firm should have in place effective organisational requirements to ensure that allocations made as
part of the placing process do not result in the firm's interest being placed ahead of the interests of the issuer
client, or the interests of one investment client over those of another investment client. In particular, firms
should clearly set out the process for developing allocation recommendations in an allocation policy.
(60)
Requirements imposed by this Regulation, including those relating to personal transactions, to dealing with
knowledge of investment research and to the production or dissemination of investment research, should apply
without prejudice to requirements of Directive 2014/65/EU and Regulation (EU) No 596/2014 and their
respective implementing measures.
31.3.2017
L 87/8
Official Journal of the European Union
EN
(1) Commission Delegated Directive (EU) 2017/593 of 7 April 2016 supplementing Directive 2014/65/EU of the European Parliament and
of the Council with regard to safeguarding of financial instruments and funds belonging to clients, product governance obligations and
the rules applicable to the provision or reception of fees, commissions or any monetary or non-monetary benefits (see page 500 of this
Official Journal).

<!-- source-page: 9 -->

(61)
This Regulation sets out requirements regarding information addressed to clients or potential clients, including
marketing communications, in order to ensure that such information be fair, clear and not misleading in
accordance with Article 24(3) of Directive 2014/65/EU.
(62)
Nothing in this Regulation requires competent authorities to approve the content and form of marketing
communications. However, neither does it prevent them from doing so, insofar as any such pre-approval is based
only on compliance with the obligation in Directive 2014/65/EU that information to clients or potential clients,
including marketing communications, should be fair, clear and not misleading.
(63)
Information requirements should be established which take account of the status of a client as either retail,
professional or eligible counterparty. An objective of Directive 2014/65/EU is to ensure a proportionate balance
between investor protection and the disclosure obligations which apply to investment firms. To this end, it is
appropriate to establish less stringent specific information requirements with respect to professional clients than
to retail clients.
(64)
Investment firms should provide clients or potential clients with the necessary information on the nature of
financial instruments and the risks associated with investing in them so that their clients are properly informed
The level of detail of the information to be provided may vary according to whether the client is a retail client or
a professional client and the nature and risk profile of the financial instruments that are being offered, but should
always include any essential elements. Member States may specify the precise terms, or the contents, of the
description of risks required under this Regulation, taking into account the information requirements set out in
Regulation (EU) No 1286/2014 of the European Parliament and of the Council (1).
(65)
The conditions with which information addressed by investment firms to clients and potential clients must
comply in order to be fair, clear and not misleading should apply to communications intended for retail or
professional clients in a way that is appropriate and proportionate, taking into account, for example, the means
of communication, and the information that the communication is intended to convey to the clients or potential
clients. In particular, it would not be appropriate to apply such conditions to marketing communications which
consist only of one or more of the following: the name of the firm, a logo or other image associated with the
firm, a contact point, a reference to the types of investment services provided by the firm.
(66)
In order to improve the consistency of information received by investors, investment firms should ensure that the
information provided to each client is consistently presented in the same language throughout all forms of
information and marketing material provided to that client. However, this should not imply a requirement for
firms to translate prospectuses, prepared in accordance with Directive 2003/71/EC of the European Parliament
and of the Council (2) or Directive 2009/65/EC of the European Parliament and of the Council (3), provided to
clients.
(67)
In order to provide a fair and balanced presentation of benefits and risks, investment firms should always give
a clear and prominent indication of any relevant risks, including drawbacks and weaknesses, when referencing
any potential benefits of a service or financial instrument.
(68)
Information should be considered to be misleading if it has a tendency to mislead the person or persons to
whom it is addressed or by whom it is likely to be received, regardless of whether the person who provides the
information considers or intends it to be misleading.
(69)
In cases where an investment firm is required to provide information to a client before the provision of a service,
each transaction in respect of the same type of financial instrument should not be considered as the provision of
a new or different service.
(70)
Detailed information on whether investment advice is provided on an independent basis, on the broad or
restricted analysis of different types of instruments and on the selection process used should help clients assess
the scope of the advice provided. Sufficient details on the number of financial instruments analysed by the firms
31.3.2017
L 87/9
Official Journal of the European Union
EN
(1) Regulation (EU) No 1286/2014 of the European Parliament and of the Council of 26 November 2014 on key information documents for
packaged retail and insurance-based investment products (PRIIPs) (OJ L 352, 9.12.2014, p. 1).
(2) Directive 2003/71/EC of the European Parliament and of the Council of 4 November 2003 on the prospectus to be published when
securities are offered to the public or admitted to trading and amending Directive 2001/34/EC (OJ L 345, 31.12.2003, p. 64).
(3) Directive 2009/65/EC of the European Parliament and of the Council of 13 July 2009 on the coordination of laws, regulations and
administrative provisions relating to undertakings for collective investment in transferable securities (UCITS) (OJ L 302, 17.11.2009,
p. 32).

<!-- source-page: 10 -->

should be provided to clients. The number and variety of financial instruments to be considered, other than the
ones provided by the investment firm or entities close to the firm, should be proportionate to the scope of the
advice to be given, client preferences and needs. However, irrespective of the scope of services offered, all
assessments should be based on an adequate number of financial instruments available on the market to allow an
appropriate consideration of what the market offers as alternatives.
(71)
The scope of the advice given by investment firms on an independent basis could range from broad and general
to specialist and specific. In order to ensure that the scope of the advice allows for a fair and appropriate
comparison between different financial instruments, investment advisers specialising in certain categories of
financial instruments and focusing on criteria that are not based on the technical structure of the instrument per
se, such as ‘green’ or ‘ethical’ investments, should comply with certain conditions if they present themselves as
independent advisers.
(72)
Enabling the same adviser to provide both independent and non-independent advice could create confusion for
the client. In order to ensure clients' understanding of the nature and basis of investment advice provided, certain
organisational requirements should also be established.
(73)
The provision by an investment firm to a client of a copy of a prospectus that has been drawn up and published
in accordance with Directive 2003/71/EC should not be treated as the provision by the firm of information to
a client for the purposes of the operating conditions under Directive 2014/65/EU which relate to the quality and
contents of such information, if the firm is not responsible under that Directive for the information given in the
prospectus.
(74)
Directive 2014/65/EU strengthens investment firms' obligations to disclose information on all costs and charges
and extends these obligations to relationships with professional clients and eligible counterparties. In order to
ensure that all categories of clients benefit from such increased transparency on costs and charges, investment
firms should be allowed, in certain situations, when providing investment services to professional clients or
eligible counterparties, to agree with these clients to limit the detailed requirements set out in this Regulation.
This however should never lead to disapplying the obligations imposed on investment firms pursuant to
Article 24(4) of Directive 2014/65/EU. In this respect, investment firms should inform professional clients about
all costs and charges as set out in this Regulation, when the services of investment advice or portfolio
management are provided or when, irrespective of the investment service provided, the financial instruments
concerned embed a derivative. Investment firms should also inform eligible counterparties about all costs and
charges as set out in this Regulation when, irrespective of the investment service provided, the financial
instrument concerned embeds a derivative and intends to be distributed to their clients. However, in other cases,
when providing investment services to professional clients or eligible counterparties, investment firms may agree,
for instance, at the request of the client concerned, not to provide the illustration showing the cumulative effect
of costs on return or an indication of the currency involved and the applicable conversion rates and costs where
any part of the total costs and charges is expressed in foreign currency.
(75)
Taking into account the overarching obligation to act in accordance with the best interest of clients and the
importance of informing clients, on an ex-ante basis, of all costs and charges to be incurred, the reference to
financial instruments recommended or marketed should include in particular investment firms providing
investment advice or portfolio management services, firms providing general recommendation concerning
financial instruments or promoting certain financial instruments in the provision of investment and ancillary
services to clients. This would for instance be the case for investment firms that have entered into distribution or
placement agreements with a product manufacturer or issuer.
(76)
In accordance with the overarching obligation to act in accordance with the best interest of clients and taking
into account the obligations resulting from specific Union legislation regulating certain financial instruments (in
particular, units in collective investment undertakings and packaged retail and insurance-based investment
products (PRIIPs) investment firms should disclose and aggregate all costs and charges, including the costs of the
financial instrument, in all cases where investment firms are obliged to provide the client with information about
the costs of a financial instrument in accordance with Union legislation.
(77)
Where investment firms have not marketed or recommended a financial instrument or are not required under
Union law to provide clients with information about costs of a financial instrument, they may not be in the
position to take into account all the costs associated with that financial instrument. Even in these residual
instances, investment firms should inform clients, on an ex-ante basis, about all costs and charges associated to
31.3.2017
L 87/10
Official Journal of the European Union
EN

<!-- source-page: 11 -->

the investment service and the price of acquiring the relevant financial instrument. Furthermore, investment
firms should comply with any other obligations to provide appropriate information about the risks of the
relevant financial instrument in accordance with Article 24(4)(b) of Directive 2014/65/EU or to provide clients,
on an ex-post basis, with adequate reports on the services provided in accordance with Article 25(6) of Directive
2014/65/EU, including cost elements.
(78)
In order to ensure clients' awareness of all costs and charges to be incurred as well as evaluation of such
information and comparison with different financial instruments and investment services, investment firms
should provide clients with clear and comprehensible information on all costs and charges in good time before
the provision of services. Ex-ante information about the costs related to the financial instrument or ancillary
service can be provided based on an assumed investment amount. However, the costs and charges disclosed
should represent the costs the client would actually incur based on that assumed investment amount. For
example, if an investment firm offers a range of ongoing services with different charges associated with each
service, the firm should disclose the costs associated with the service the client subscribed to. For ex-post
disclosures, information related to costs and charges should reflect the client's actual investment amount at the
time the disclosure is produced.
(79)
In order to ensure investors receive information about all costs and charges pursuant to Article 24(4) of Directive
2014/65/EU, the underlying market risk should be understood as relating only to movements in the value of
capital invested caused directly by movements in the value of underlying assets. Transactions costs and ongoing
charges on financial instruments should therefore also be included in the required aggregation of costs and
charges and should be estimated using reasonable assumptions, accompanied by an explanation that such
estimations are based on assumptions and may deviate from costs and charges that will actually be incurred.
Following the same objective of full disclosure, practices where there is ‘netting’ of costs should not be excluded
from the obligation to provide information on costs and charges. The costs and charges disclosure is
underpinned by the principle that every difference between the price of a position for the firm and the respective
price for the client should be disclosed, including mark-ups and mark-downs.
(80)
While investment firms should aggregate all costs and charges in accordance with Article 24(4) of Directive
2014/65/EU and provide clients with the overall costs expressed both as a monetary amount and as a percentage,
investment firms should, in addition, be allowed to provide clients or prospective clients with separate figures
comprising aggregated initial costs and charges, aggregated on-going costs and charges and aggregated exit costs.
(81)
Investment firms distributing financial instruments, in relation to which information on costs and charges is
insufficient, should additionally inform their clients about those costs as well as all the other costs and associated
charges relating to the provision of investment services in relation to those financial instruments in order to
safeguard clients' rights to full disclosure of costs and charges. This would be the case for investment firms
distributing units in collective investment undertakings for which transaction costs have not been provided by for
example units in UCITS management company. In such cases, the investment firms should liaise with UCITS
management companies to obtain the relevant information.
(82)
In order to improve transparency for clients on the associated costs of their investments and the performance of
their investments against the relevant costs and charges over time, periodic ex-post disclosure should also be
provided where the investment firms have or have had an ongoing relationship with the client during the year.
Ex-post disclosure on all the relevant costs and charges should be provided on a personalised basis. The ex-post
periodic disclosure may be made by building on existing reporting obligations, such as obligations for firms
providing execution of orders other than portfolio management, portfolio management or holding client financial
instruments or funds.
(83)
The information which an investment firm is required to give to clients concerning costs and associated charges
includes information about the arrangements for payment or performance of the agreement for the provision of
investment services and any other agreement relating to a financial instrument that is being offered. For this
purpose, arrangements for payment will generally be relevant where a financial instrument contract is terminated
by cash settlement. Arrangements for performance will generally be relevant where, upon termination, a financial
instrument requires the delivery of shares, bonds, a warrant, bullion or another instrument or commodity.
31.3.2017
L 87/11
Official Journal of the European Union
EN

<!-- source-page: 12 -->

(84)
It is necessary to introduce different requirements for the application of the suitability assessment set out in
Article 25(2) of Directive 2014/65/EU and the appropriateness assessment set out in Article 25(3) of that
Directive. These tests are different in scope with regards to the investment services to which they relate, and have
different functions and characteristics.
(85)
Investment firms should include in the suitability report and draw clients' attention to information on whether
the recommended services or instruments are likely to require the retail client to seek a periodic review of their
arrangements. This includes situations where a client is likely to need to seek advice to bring a portfolio of
investments back in line with the original recommended allocation where there is a probability that the portfolio
could deviate from the target asset allocation.
(86)
In order to take market developments into account and ensure the same level of investor protection, it should be
clarified that investment firms should remain responsible for undertaking suitability assessments where
investment advice or portfolio management services are provided in whole or in part through an automated or
semi-automated system.
(87)
In accordance with the suitability assessment requirement under Article 25(2) of Directive 2014/65/EU, it should
also be clarified that investment firms should undertake a suitability assessment not only in relation to
recommendations to buy a financial instrument are made but for all decisions whether to trade including
whether or not to buy, hold or sell an investment.
(88)
For the purposes of Article 25(2) of Directive 2014/65/EU, a transaction may be unsuitable for the client or
potential client due to the risks of the associated financial instruments, the type of transaction, the characteristics
of the order or the frequency of the trading. A series of transactions, each of which are suitable when viewed in
isolation may be unsuitable if the recommendation or the decisions to trade are made with a frequency that is
not in the best interests of the client. In the case of portfolio management, a transaction might also be unsuitable
if it would result in an unsuitable portfolio.
(89)
A recommendation or request made, or advice given, by a portfolio manager to a client to the effect that the
client should give or alter a mandate to the portfolio manager that defines the limits of the portfolio manager's
discretion should be considered a recommendation as referred to in of Article 25(2) of Directive 2014/65/EU.
(90)
In order to provide legal certainty and enable clients to better understand the nature of the services provided,
investment firms that provide investment or ancillary services to clients should enter into a written basic
agreement with the client, setting out the essential rights and obligations of the firm and the client.
(91)
This Regulation should not require competent authorities to approve the content of the basic agreement between
an investment firm and its clients. Nor should it prevent them from doing so, insofar as any such approval is
based only on the firm's compliance with its obligations under Directive 2014/65/EU to act honestly, fairly and
professionally in accordance with the best interests of its clients, and to establish a record that sets out the rights
and obligations of investment firms and their clients, and the other terms on which firms will provide services to
their clients.
(92)
The records an investment firm is required to keep should be adapted to the type of business and the range of
investment services and activities performed, provided that the record-keeping obligations set out in Directive
2014/65/EU, Regulation (EU) No 600/2014 of the European Parliament and of the Council (1), Regulation (EU)
No 596/2014, Directive 2014/57/EU of the European Parliament and of the Council (2) and this Regulation are
fulfilled and that competent authorities are able to fulfil their supervisory tasks and perform enforcement actions
in view of ensuring both investor protection and market integrity.
(93)
In light of the importance of reports and periodic communications for all clients, and the extension of
Article 25(6) of Directive 2014/65/EU to the relationship to eligible counterparties, the reporting requirements
set in this Regulation should apply to all categories of clients. Taking into account the nature of the interactions
with eligible counterparties, investment firms should be allowed to enter into agreements determining the specific
content and timing of reporting different from the ones applicable for retail and professional clients.
31.3.2017
L 87/12
Official Journal of the European Union
EN
(1) Regulation (EU) No 600/2014 of the European Parliament and of the Council of 15 May 2014 on markets in financial instruments and
amending Regulation (EU) No 648/2012 (OJ L 173, 12.6.2014, p. 84).
(2) Directive 2014/57/EU of the European Parliament and of the Council of 16 April 2014 on criminal sanctions for market abuse (market
abuse directive) (OJ L 173, 12.6.2014, p. 179).

<!-- source-page: 13 -->

(94)
In cases where an investment firm providing portfolio management services is required to provide clients or
potential clients with information on the types of financial instruments that may be included in the client
portfolio and the types of transactions that may be carried out in such instruments, such information should
state separately whether the investment firm will be mandated to invest in financial instruments not admitted to
trading on a regulated market, in derivatives, or in illiquid or highly volatile instruments; or to undertake short
sales, purchases with borrowed funds, securities financing transactions, or any transactions involving margin
payments, deposit of collateral or foreign exchange risk.
(95)
Clients should be informed of the performance of their portfolio and depreciations of their initial investments. In
the case of portfolio management, this trigger should be set at the depreciation of 10 %, and thereafter at
multiples of 10 %, of the overall value of the overall portfolio and should not apply to individual holdings.
(96)
For the purposes of the reporting obligations in respect of portfolio management, a contingent liability
transaction should involve any actual or potential liability for the client that exceeds the cost of acquiring the
instrument.
(97)
For the purposes of the provisions on reporting to clients, a reference to the type of the order should be
understood as referring to its status as a limit order, market order, or other specific type of order.
(98)
For the purposes of the provisions on reporting to clients, a reference to the nature of the order should be
understood as referring to orders to subscribe for securities, or to exercise an option, or similar client order.
(99)
When establishing its execution policy in accordance with Article 27(4) of Directive 2014/65/EU, an investment
firm should determine the relative importance of the factors mentioned in Article 27(1) of that Directive, or at
least establish the process by which it determines the relative importance of these factors, so that it can deliver
the best possible result to its clients. In order to give effect to that policy, an investment firm should select the
execution venues that enable it to obtain on a consistent basis the best possible result for the execution of client
orders. In order to comply with the legal obligation of best execution, investment firms, when applying the
criteria for best execution for professional clients, will typically not use the same execution venues for securities
financing transactions (SFTs) and other transactions. This is because the SFTs are used as a source of funding
subject to a commitment that the borrower will return equivalent securities on a future date and the terms of
SFTs are typically defined bilaterally between the counterparties ahead of the execution. Therefore, the choice of
execution venues for SFTs is more limited than in the case of other transactions, given that it depends on the
particular terms defined in advance between the counterparties and on whether there is a specific demand on
those execution venues for the financial instruments involved. As a result, the order execution policy established
by investment firms should take into account the particular characteristics of SFTs and it should list separately
execution venues used for SFTs. An investment firm should apply its execution policy to each client order that it
executes with a view to obtaining the best possible result for the client in accordance with that policy.
(100)  In order to ensure that investment firms who transmit or place clients' orders with other entities for execution
act in the best interest of their clients in accordance with Article 24(1) of Directive 2014/65/EU and with
Article 24(4) of Directive 2014/65/EU to provide appropriate information to clients on the firm and its services,
investment firms should provide clients with appropriate information on the top five entities for each class of
financial instruments to which they transmit or place clients' orders and provide clients with information on the
execution quality, in accordance with Article 27(6) of Directive 2014/65/EU and respective implementing
measures. Investment firms transmitting or placing orders with other entities for execution may select a single
entity for execution only where they are able to show that this allows them to obtain the best possible result for
their clients on a consistent basis and where they can reasonably expect that the selected entity will enable them
to obtain results for clients that are at least as good as the results that they reasonably could expect from using
alternative entities for execution. This reasonable expectation should be supported by relevant data published in
accordance with Article 27 of Directive 2014/65/EU or by internal analysis conducted by these investment firms.
(101)  For the purposes of ensuring that an investment firm obtains the best possible result for the client when
executing a retail client order in the absence of specific client instructions, the firm should take into consideration
all factors that will allow it to deliver the best possible result in terms of the total consideration, representing the
price of the financial instrument and the costs related to execution. Speed, likelihood of execution and settlement,
31.3.2017
L 87/13
Official Journal of the European Union
EN

<!-- source-page: 14 -->

the size and nature of the order, market impact and any other implicit transaction costs may be given precedence
over the immediate price and cost consideration only insofar as they are instrumental in delivering the best
possible result in terms of the total consideration to the retail client.
(102)  When an investment firm executes an order following specific instructions from the client, it should be treated as
having satisfied its best execution obligations only in respect of the part or aspect of the order to which the client
instructions relate. The fact that the client has given specific instructions which cover one part or aspect of the
order should not be treated as releasing the investment firm from its best execution obligations in respect of any
other parts or aspects of the client order that are not covered by such instructions. An investment firm should
not induce a client to instruct it to execute an order in a particular way, by expressly indicating or implicitly
suggesting the content of the instruction to the client, when the firm ought reasonably to know that an
instruction to that effect is likely to prevent it from obtaining the best possible result for that client. However,
this should not prevent a firm inviting a client to choose between two or more specified trading venues, provided
that those venues are consistent with the execution policy of the firm.
(103)  Dealing on own account with clients by an investment firm should be considered as the execution of client
orders, and therefore subject to the requirements under Directive 2014/65/EU and this Regulation and, in
particular, those obligations in relation to best execution. However, if an investment firm provides a quote to
a client and that quote would meet the investment firm's obligations under Article 27(1) of Directive
2014/65/EU if the firm executed that quote at the time the quote was provided, then the firm should meet those
same obligations if it executes its quote after the client accepts it, provided that, taking into account the changing
market conditions and the time elapsed between the offer and acceptance of the quote, the quote is not
manifestly out of date.
(104)  The obligation to deliver the best possible result when executing client orders applies in relation to all types of
financial instruments. However, given the differences in market structures or the structure of financial
instruments, it may be difficult to identify and apply a uniform standard of and procedure for best execution that
would be valid and effective for all classes of instrument. Best execution obligations should therefore be applied
in a manner that takes into account the different circumstances associated with the execution of orders related to
particular types of financial instruments. For example, transactions involving a customised OTC financial
instrument that involve a unique contractual relationship tailored to the circumstances of the client and the
investment firm may not be comparable for best execution purposes with transactions involving shares traded on
centralised execution venues. As best execution obligations apply to all financial instruments, irrespective of
whether they are traded on trading venues or OTC, investment firms should gather relevant market data in order
to check whether the OTC price offered for a client is fair and delivers on best execution obligation.
(105)  The provisions of this Regulation as to execution policy should be without prejudice to the general obligation of
an investment firm under Article 27(7) of Directive 2014/65/EU to monitor the effectiveness of its order
execution arrangements and policy and assess the venues in its execution policy on a regular basis.
(106)  This Regulation should not require a duplication of effort as to best execution between an investment firm which
provides the service of reception and transmission of order or portfolio management and any investment firm to
which that investment firm transmits its orders for execution.
(107)  The best execution obligation under Directive 2014/65/EU requires investment firms to take all sufficient steps to
obtain the best possible result for their clients. The quality of execution, which includes aspects such as the speed
and likelihood of execution such as fill rate) and the availability and incidence of price improvement, is an
important factor in the delivery of best execution. Availability, comparability and consolidation of data related to
execution quality provided by the various execution venues is crucial in enabling investment firms and investors
to identify those execution venues that deliver the highest quality of execution for their clients. In order to obtain
best execution result for a client, investment firms should compare and analyse relevant data including that made
public in accordance with Article 27(3) of Directive 2014/65/EU and respective implementing measures.
(108)  Investment firms executing orders should be able to include a single execution venue in their policy only where
they are able to show that this allows them to obtain best execution for their clients on a consistent basis.
Investment firms should select a single execution venue only where they can reasonably expect that the selected
execution venue will enable them to obtain results for clients that are at least as good as the results that they
31.3.2017
L 87/14
Official Journal of the European Union
EN

<!-- source-page: 15 -->

reasonably could expect from using alternative execution venues. This reasonable expectation must be supported
by relevant data published in accordance with Article 27 of Directive 2014/65/EU or by other internal analyses
conducts by the firms.
(109)  The reallocation of transactions should be considered as detrimental to a client if, as an effect of that reallocation,
unfair precedence is given to the investment firm or to any particular client.
(110)  Without prejudice to Regulation (EU) No 596/2014, for the purposes of the provisions of this Regulation
concerning client order handling, client orders should not be treated as otherwise comparable if they are received
by different media and it would not be practicable for them to be treated sequentially. Any use by an investment
firm of information relating to a pending client order in order to deal on own account in the financial
instruments to which the client order relates, or in related financial instruments, should be considered a misuse
of that information. However, the mere fact that market makers or bodies authorised to act as counterparties
confine themselves to pursuing their legitimate business of buying and selling financial instruments, or that
persons authorised to execute orders on behalf of third parties confine themselves to carrying out an order
dutifully, should not in itself be deemed to constitute a misuse of information.
(111)  When assessing whether a market fulfils the requirement laid down in point (a) of Article 33(3) of Directive
2014/65/EU that at least 50 % of the issuers admitted to trading on that market are small and medium-size
enterprises (SMEs), a flexible approach should be taken by competent authorities with regard to markets with no
previous operating history, newly created SMEs whose financial instruments have been admitted to trading for
less than three years and issuers exclusively of non-equity financial instruments.
(112)  Given the diversity in operating models of existing MTFs with a focus on SMEs in the Union, and to ensure the
success of the new category of SME growth market, it is appropriate to grant SME growth markets an
appropriate degree of flexibility in evaluating the appropriateness of issuers for admission on their venue. In any
case, an SME growth market should not have rules that impose greater burdens on issuers than those applicable
to issuers on regulated markets.
(113)  With regard to the content of the admission document which an issuer is required to produce upon initial
admission to trading of its securities on an SME growth market, where the requirement to publish a prospectus
pursuant to Directive 2003/71/EC does not apply, it is appropriate that competent authorities retain discretion to
assess whether the rules set out by the operator of the SME growth market achieve the proper information of
investors. While full responsibility for the information featured in the admission document should lie with the
issuer, it should be for the operator of an SME growth market to define how the admission document should be
appropriately reviewed. This should not necessarily involve a formal approval by the competent authority or the
operator.
(114)  The publication by issuers of annual and half-yearly financial reports represents an appropriate minimum
standard of transparency which is coherent with the prevailing best practice in existing markets focusing on
SMEs. As to the content of financial reports, the operator of an SME growth market should be free to prescribe
the use of International Financial Reporting Standards or financial reporting standards permitted by local laws
and regulations, or both, by issuers whose financial instruments are traded on its venue. Deadlines for publishing
financial reports should be less onerous than those prescribed by Directive 2004/109/EC of the European
Parliament and of the Council (1) as less stringent timeframes appear better suited to the needs and circumstances
of SMEs.
(115)  Since the rules on dissemination of information about issuers on regulated markets under Directive 2004/109/EC
would be too burdensome for issuers on SME growth markets, it is appropriate that the website of the operator
of the SME growth market becomes the point of convergence for investors seeking information on the issuers
traded on that venue. A publication on the website of the operator of the SME growth market can also be
effected by providing a direct link to the website of the issuer in case the information is published there, if the
link goes directly to the relevant part of the website of the issuer where the regulatory information can be easily
found by investors.
31.3.2017
L 87/15
Official Journal of the European Union
EN
(1) Directive 2004/109/EC of the European Parliament and of the Council of 15 December 2004 on the harmonisation of transparency
requirements in relation to information about issuers whose securities are admitted to trading on a regulated market and amending
Directive 2001/34/EC (OJ L 390, 31.12.2004, p. 38).

<!-- source-page: 16 -->

(116)  It is necessary to further specify when a suspension or a removal from trading of a financial instrument is likely
to cause significant damages to the investor's interest or to the orderly functioning of the market. Convergence in
that field is necessary to ensure that market participants in a Member State where trading in financial instruments
has been suspended or financial instruments have been removed are not disadvantaged in comparison to market
participants in another Member State, where trading is still ongoing.
(117)  To ensure the necessary level of convergence, it is appropriate to specify a list of circumstances constituting
significant damage to investors' interests and the orderly functioning of the market which could be the basis of
a decision by a national competent authority, a market operator operating a regulated market or an investment
firm or a market operator operating an MTF or an OTF not to demand the suspension or removal of a financial
instrument from trading, or not to follow a notification thereto. It is appropriate for such a list to be
non-exhaustive as it will thus provide national competent authorities with a framework for the exercise of their
judgement and will leave them a necessary degree of flexibility in the assessment of individual cases.
(118)  Articles 31(2) and 54(2) of Directive 2014/65/EU respectively require investment firms and market operators
operating an MTF or an OTF, and market operators of regulated markets to immediately inform their national
competent authorities under certain circumstances. This requirement is intended to ensure that national
competent authorities can fulfil their regulatory tasks and are informed in a timely manner about relevant
incidents which may have a negative impact on the functioning and integrity of the markets. The information
received from operators of trading venues should enable national competent authorities to identify and assess the
risks for the markets and their participants as well as to react efficiently and to take action if necessary.
(119)  It is appropriate to set up a non-exhaustive list of high-level circumstances where significant infringements of the
rules of a trading venue, disorderly trading conditions or system disruptions in relation to a financial instrument
may be assumed, thus triggering the obligation for the operators of trading venues to immediately inform their
competent authorities as set out in Articles 31(2) and 54(2) of Directive 2014/65/EU. For that purpose, reference
to the ‘rules of a trading venue’ should be understood in a broad sense and should comprise all rules, rulings,
orders as well as general terms and conditions of contractual agreements between the trading venue and its
participants which contain the conditions for trading and admission to the trading venue.
(120)  With regard to conduct that may indicate abusive behaviour within the scope of Regulation (EU) No 596/2014, it
is also appropriate to set up a non-exhaustive list of signals of insider dealing and market manipulation which
should be taken into account by the operator of a trading venue when examining transactions or orders to trade
in order to determine whether the obligation to inform the relevant national competent authority applies, as set
out in Articles 31(2) and 54(2) of Directive 2014/65/EU. For that purpose, reference to ‘order to trade’ should
encompass all types of orders, including initial orders, modifications, updates and cancellations of orders,
irrespective of whether or not they have been executed and irrespective of the means used to access the trading
venue.
(121)  The list of signals of insider dealing and market manipulation should be neither exhaustive nor determinative of
market abuse or attempts of market abuse, as each of the signals may not necessarily constitute market abuse or
attempts of market abuse per se. Transactions or orders to trade meeting one or more signals may be conducted
for legitimate reasons or in compliance with the rules of the trading venue.
(122) In order to provide transparency to market stakeholders whilst preventing market abuse and preserving confiden­
tiality of the identities of position holders, the publication of aggregate weekly position reports on positions
referred to in Article 58(1)(a) of Directive 2014/65/EU should only apply to contracts that are traded by a certain
number of persons, above certain sizes as specified in this Regulation.
(123)  In order to ensure that market data is provided on a reasonable commercial basis in a uniform manner in the
Union, this Regulation specifies the conditions that APAs and CTPs must fulfil. These conditions are based on the
objective to ensure that the obligation to provide market data on a reasonable commercial basis is sufficiently
clear to allow for an effective and uniform application whilst taking into account different operating models and
costs structures of data providers.
31.3.2017
L 87/16
Official Journal of the European Union
EN

<!-- source-page: 17 -->

(124)  To ensure that fees for market data are set at a reasonable level, the fulfilment of the obligation to provide market
data on a reasonable commercial basis requires that prices be based on a reasonable relationship to the cost of
producing and disseminating that data. Therefore, without prejudice to the application of competition rules, data
providers should determine their fees on the basis of their costs whilst being allowed to obtain a reasonable
margin, based on factors such as the operating profit margin, the return on costs, the return on operating assets
and the return on capital. Where data providers incur joint costs for data provision and the provision of other
services, costs of data provision may include an appropriate share of costs arising from any other relevant service
provided. Since specifying the exact cost is very complex, cost allocation and cost apportionment methodologies
should be specified instead, leaving the specification of those costs to the discretion of market data providers.
(125)  Market data should be provided on a non-discriminatory basis, which requires that the same price and other
terms and conditions should be offered to all customers who are in the same category according to published
objective criteria.
(126)  To allow data users to obtain market data without having to buy other services, market data should be offered
unbundled from other services. To avoid that data users are charged more than once for the same market data
when buying data from different market data distributors, market data should be offered on a per user basis
unless doing so would be disproportionate to the cost of such way of offering that data in respect of the scale
and the scope of the market data provided by the APA and the CTP.
(127)  In order to allow for data users and competent authorities to effectively assess whether market data is provided
on a reasonable commercial basis, it is necessary that all the essential conditions for its provision are disclosed to
the public. Data providers should therefore disclose information about their fees and the content of the market
data As well as the cost accounting methodologies used to determine their costs without having to disclose their
actual costs.
(128)  It is appropriate to set the criteria for determining when the operations of a regulated market, an MTF or an OTF
are of substantial importance in a host Member State so as to avoid creating an obligation on a trading venue to
deal with or be made subject to the supervision of more than one competent authority where this would not be
necessary according to Directive 2014/65/EU. For MTFs and OTFs, it is appropriate that only MTFs and OTFs
with a significant market share be considered as being of substantial importance, so that not any relocation or
acquisition of an economically insignificant MTF or OTF automatically triggers the establishment of the
cooperation arrangements set out in Article 79(2) of Directive 2014/65/EU.
(129)  This Regulation respects the fundamental rights and observes the principles recognised in the Charter of
Fundamental Rights of the European Union (Charter). Accordingly, this Regulation should be interpreted and
applied in accordance with those rights and principles in particular the right to protection of personal data, the
freedom to conduct business, the right to consumer protection, the right to effective remedy and to a fair trial.
Any processing of personal data under this Regulation should respect fundamental rights, including the right to
respect for private and family life and the right to protection of personal data under Articles 7 and 8 of the
Charter of Fundamental Rights of the European Union and must be in compliance with the Directive 95/46/EC
and Regulation (EC) No 45/2001.
(130)  ESMA, established by Regulation (EU) No 1095/2010 of the European Parliament and of the Council (1) has been
consulted for technical advice.
(131)  In order to allow competent authorities and investment firms to adapt to the new requirements contained in this
Regulation so that they can be applied in an efficient and effective manner, the starting date of application of this
Regulation should be aligned with the entry into application date of Directive 2014/65/EU,
31.3.2017
L 87/17
Official Journal of the European Union
EN
(1) Regulation (EU) No 1095/2010 of the European Parliament and of the Council of 24 November 2010 establishing a European
Supervisory Authority (European Securities and Markets Authority), amending Decision No 716/2009/EC and repealing Commission
Decision 2009/77/EC (OJ L 331, 15.12.2010, p. 84).

<!-- source-page: 18 -->

HAS ADOPTED THIS REGULATION:
CHAPTER I
SCOPE AND DEFINITIONS
Article 1
Subject-matter and scope
1.
Chapter II, and Sections 1 to 4, Articles 59(4) and 60 and Sections 6 and 8 of Chapter III and, to the extent they
relate to those provisions, Chapter I and Section 9 of Chapter III and Chapter IV of this Regulation shall apply to
management companies in accordance with Article 6(4) of Directive 2009/65/EC and Article 6(6) of Directive
2011/61/EU of the European Parliament and of the Council (1).
2.
References to investment firms shall encompass credit institutions and references to financial instruments shall
encompass structured deposits in relation to all the requirements referred to in Article 1(3) and 1(4) of Directive
2014/65/EU and their implementing provisions as set out under this Regulation.
Article 2
Definitions
For the purposes of this Regulation, the following definitions shall apply:
(1)  ‘relevant person’ in relation to an investment firm, means any of the following:
(a)  a director, partner or equivalent, manager or tied agent of the firm;
(b)  a director, partner or equivalent, or manager of any tied agent of the firm;
(c)  an employee of the firm or of a tied agent of the firm, as well as any other natural person whose services are
placed at the disposal and under the control of the firm or a tied agent of the firm and who is involved in the
provision by the firm of investment services and activities;
(d)  a natural person who is directly involved in the provision of services to the investment firm or to its tied agent
under an outsourcing arrangement for the purpose of the provision by the firm of investment services and
activities;
(2)  ‘financial analyst’ means a relevant person who produces the substance of investment research;
(3)  ‘outsourcing’ means an arrangement of any form between an investment firm and a service provider by which that
service provider performs a process, a service or an activity which would otherwise be undertaken by the
investment firm itself;
(3a)  ‘person with whom a relevant person has a family relationship’ means any of the following:
(a)  the spouse of the relevant person or any partner of that person considered by national law as equivalent to
a spouse;
(b)  a dependent child or stepchild of the relevant person;
(c)  any other relative of the relevant person who has shared the same household as that person for at least one
year on the date of the personal transaction concerned;
(4)  ‘securities financing transaction’ means security financing transaction as defined in Article 3(11) of Regulation (EU)
2015/2365 of the European Parliament and of the Council (2).
(5)  ‘remuneration’ means all forms of payments or financial or non-financial benefits provided directly or indirectly by
firms to relevant persons in the provision of investment or ancillary services to clients;
(6)  ‘commodity’ means any goods of a fungible nature that are capable of being delivered, including metals and their
ores and alloys, agricultural products, and energy such as electricity.
31.3.2017
L 87/18
Official Journal of the European Union
EN
(1) Directive 2011/61/EU of the European Parliament and of the Council of 8 June 2011 on Alternative Investment Fund Managers and
amending Directives 2003/41/EC and 2009/65/EC and Regulations (EC) No 1060/2009 and (EU) No 1095/2010 (OJ L 174, 1.7.2011,
p. 1).
(2) Regulation (EU) 2015/2365 of the European Parliament and of the Council of 25 November 2015 on transparency of securities
financing transactions and of reuse and amending Regulation (EU) No 648/2012 (OJ L 337, 23.12.2015, p. 1).

<!-- source-page: 19 -->

Article 3
Conditions applying to the provision of information
1.
Where, for the purposes of this Regulation, information is required to be provided in a durable medium as defined
in Article 4(1) point 62 of Directive 2014/65/EU investment firms shall have the right to provide that information in
a durable medium other than on paper only if:
(a)  the provision of that information in that medium is appropriate to the context in which the business between the
firm and the client is, or is to be, carried on; and
(b)  the person to whom the information is to be provided, when offered the choice between information on paper or in
that other durable medium, specifically chooses the provision of the information in that other medium.
2.
Where, pursuant to Article 46, 47, 48, 49, 50 or 66(3) of this Regulation, an investment firm provides
information to a client by means of a website and that information is not addressed personally to the client, investment
firms shall ensure that the following conditions are satisfied:
(a)  the provision of that information in that medium is appropriate to the context in which the business between the
firm and the client is, or is to be, carried on;
(b)  the client must specifically consent to the provision of that information in that form;
(c)  the client must be notified electronically of the address of the website, and the place on the website where the
information may be accessed;
(d)  the information must be up to date;
(e)  the information must be accessible continuously by means of that website for such period of time as the client may
reasonably need to inspect it.
3.
For the purposes of this Article, the provision of information by means of electronic communications shall be
treated as appropriate to the context in which the business between the firm and the client is, or is to be, carried on
where there is evidence that the client has regular access to the internet. The provision by the client of an e-mail address
for the purposes of the carrying on of that business shall be treated as such evidence.
Article 4
Provision of investment service in an incidental manner
(Article 2(1) of Directive 2014/65/EU)
For the purpose of the exemption in point (c) of Article 2(1) of Directive 2014/65/EU, an investment service shall be
deemed to be provided in an incidental manner in the course of a professional activity where the following conditions
are satisfied:
(a)  a close and factual connection exists between the professional activity and the provision of the investment service to
the same client, such that the investment service can be regarded as accessory to the main professional activity;
(b)  the provision of investment services to the clients of the main professional activity does not aim to provide
a systematic source of income to the person providing the professional activity; and
(c)  the person providing the professional activity does not market or otherwise promote his ability to provide
investment services, except where these are disclosed to clients as being accessory to the main professional activity.
Article 5
Wholesale energy products that must be physically settled
(Article 4(1)(2) of Directive 2014/65/EU)
1.
For the purposes of Section C(6) of Annex I to Directive 2014/65/EU, a wholesale energy product must be
physically settled where all the following conditions are satisfied:
(a)  it contains provisions which ensure that parties to the contract have proportionate arrangements in place to be able
to make or take delivery of the underlying commodity; a balancing agreement with the Transmission System
Operator in the area of electricity and gas shall be considered a proportionate arrangement where the parties to the
agreement have to ensure physical delivery of electricity or gas.
31.3.2017
L 87/19
Official Journal of the European Union
EN

<!-- source-page: 20 -->

(b)  it establishes unconditional, unrestricted and enforceable obligations of the parties to the contract to deliver and take
delivery of the underlying commodity;
(c)  it does not allow either party to replace physical delivery with cash settlement;
(d)  the obligations under the contract cannot be offset against obligations from other contracts between the parties
concerned, without prejudice to the rights of the parties to the contract, to net their cash payment obligations.
For the purposes of point (d), operational netting in power and gas markets shall not be considered as offsetting of
obligations under a contract against obligations from other contracts.
2.
Operational netting shall be understood as any nomination of quantities of power and gas to be fed into
a gridwork upon being so required by the rules or requests of a Transmission System Operator as defined in Article 2(4)
of Directive 2009/72/EC of the European Parliament and of the Council (1) for an entity performing an equivalent
function to a Transmission System Operator at the national level. Any nomination of quantities based on operational
netting shall not be at the discretion of the parties to the contract.
3.
For the purposes of Section C(6) of Annex I to Directive 2014/65/EU, force majeure shall include any exceptional
event or a set of circumstances which are outside the control of the parties to the contract, which the parties to the
contract could not have reasonably foreseen or avoided by the exercise of appropriate and reasonable due diligence and
which prevent one or both parties to the contract from fulfilling their contractual obligations.
4.
For the purposes of Section C(6) of Annex I to Directive 2014/65/EU bona fide inability to settle shall include any
event or set of circumstances, not qualifying as force majeure as referred to in paragraph 3, which are objectively and
expressly defined in the contract terms, for one or both parties to the contract, acting in good faith, not to fulfil their
contractual obligations.
5.
The existence of force majeure or bona fide inability to settle provisions shall not prevent a contract from being
considered as ‘physically settled’ for the purposes of Section C(6) of Annex I to Directive 2014/65/EU.
6.
The existence of default clauses providing that a party is entitled to financial compensation in the case of non- or
defective performance of the contract shall not prevent the contract from being considered as ‘physically settled’ within
the meaning of Section C(6) of Annex I to Directive 2014/65/EU.
7.
The delivery methods for the contracts being considered as ‘physically settled’ within the meaning of Section C(6)
of Annex I to Directive 2014/65/EU shall include at least:
(a)  physical delivery of the relevant commodities themselves;
(b)  delivery of a document giving rights of an ownership nature to the relevant commodities or the relevant quantity of
the commodities concerned;
(c)  other methods of bringing about the transfer of rights of an ownership nature in relation to the relevant quantity of
goods without physically delivering them, including notification, scheduling or nomination to the operator of an
energy supply network, that entitles the recipient to the relevant quantity of the goods.
Article 6
Energy derivative contracts relating to oil and coal and wholesale energy products
(Article 4(1)(2) of Directive 2014/65/EU)
1.
For the purposes of Section C(6) of Annex I to Directive 2014/65/EU, energy derivative contracts relating to oil
shall be contracts with mineral oil, of any description and petroleum gases, whether in liquid or vapour form, including
products, components and derivatives of oil and oil transport fuels, including those with biofuel additives, as an
underlying.
31.3.2017
L 87/20
Official Journal of the European Union
EN
(1) Directive 2009/72/EC of the European Parliament and of the Council of 13 July 2009 concerning common rules for the internal market
in electricity and repealing Directive 2003/54/EC (OJ L 211, 14.8.2009, p. 55).

<!-- source-page: 21 -->

2.
For the purposes of Section C(6) of Annex I to Directive 2014/65/EU, energy derivative contracts relating to coal
shall be contracts with coal, defined as a black or dark-brown combustible mineral substance consisting of carbonised
vegetable matter, used as a fuel, as an underlying.
3.
For the purposes of Section C(6) of Annex I to Directive 2014/65/EU derivative contracts that have the character­
istics of wholesale energy products as defined in Article 2(4) of Regulation (EU) No 1227/2011 shall be derivatives with
electricity or natural gas as an underlying, in accordance with points (b) and (d) of Article 2(4) of that Regulation.
Article 7
Other derivative financial instruments
(Article 4(1)(2) of Directive 2014/65/EU)
1.
For the purposes of Section C(7) of Annex I to Directive 2014/65/EU, a contract which is not a spot contract in
accordance with paragraph 2 and which is not for commercial purposes as laid down in paragraph 4 shall be considered
as having the characteristics of other derivative financial instruments where it satisfies the following conditions:
(a)  it meets one of the following criteria:
(i)  it is traded on a third country trading venue that performs a similar function to a regulated market, an MTF or
an OTF;
(ii)  it is expressly stated to be traded on, or is subject to the rules of, a regulated market, an MTF, an OTF or such
a third country trading venue;
(iii)  it is equivalent to a contract traded on a regulated market, MTF, an OTF or such a third country trading venue,
with regards to the price, the lot, the delivery date and other contractual terms;
(b)  it is standardised so that the price, the lot, the delivery date and other terms are determined principally by reference
to regularly published prices, standard lots or standard delivery dates.
2.
A spot contract for the purposes of paragraph 1 shall be a contract for the sale of a commodity, asset or right,
under the terms of which delivery is scheduled to be made within the longer of the following periods:
(a)  2 trading days;
(b)  the period generally accepted in the market for that commodity, asset or right as the standard delivery period.
A contract shall not be considered a spot contract where, irrespective of its explicit terms, there is an understanding
between the parties to the contract that delivery of the underlying is to be postponed and not to be performed within
the period referred to in paragraph 2.
3.
For the purposes of Section C(10) of Annex I to Directive 2004/39/EC of the European Parliament and of the
Council (1), a derivative contract relating to an underlying referred to in that Section or in Article 8 of this Regulation
shall be considered to have the characteristics of other derivative financial instruments where one of the following
conditions is satisfied:
(a)  it is settled in cash or may be settled in cash at the option of one or more of the parties, otherwise than by reason
of a default or other termination event;
(b)  it is traded on a regulated market, an MTF, an OTF, or a third country trading venue that performs a similar
function to a regulated market, MTF or an OTF;
(c)  the conditions laid down in paragraph 1 are satisfied in relation to that contract.
31.3.2017
L 87/21
Official Journal of the European Union
EN
(1) Directive 2004/39/EC of the European Parliament and of the Council of 21 April 2004 on markets in financial instruments amending
Council Directives 85/611/EEC and 93/6/EEC and Directive 2000/12/EC of the European Parliament and of the Council and repealing
Council Directive 93/22/EEC (OJ L 145, 30.4.2004, p. 1).

<!-- source-page: 22 -->

4.
A contract shall be considered to be for commercial purposes for the purposes of Section C(7) of Annex I to
Directive 2014/65/EU, and as not having the characteristics of other derivative financial instruments for the purposes of
Sections C(7) and (10) of that Annex, where the following conditions are both met:
(a)  it is entered into with or by an operator or administrator of an energy transmission grid, energy balancing
mechanism or pipeline network,
(b)  it is necessary to keep in balance the supplies and uses of energy at a given time, including the case when the
reserve capacity contracted by an electricity transmission system operator as defined in Article 2(4) of Directive
2009/72/EC is being transferred from one prequalified balancing service provider to another prequalified balancing
service provider with the consent of the relevant transmission system operator.
Article 8
Derivatives under Section C(10) of Annex I to Directive 2014/65/EU
(Article 4(1)(2) of Directive 2014/65/EU)
In addition to derivative contracts expressly referred to in Section C(10) of Annex I to Directive 2014/65/EU,
a derivative contract shall be subject to the provisions in that Section where it meets the criteria set out in that Section
and in Article 7(3) of this Regulation and it relates to any of the following:
(a)  telecommunications bandwidth;
(b)  commodity storage capacity;
(c)  transmission or transportation capacity relating to commodities, whether cable, pipeline or other means with the
exception of transmission rights related to electricity transmission cross zonal capacities when they are, on the
primary market, entered into with or by a transmission system operator or any persons acting as service providers
on their behalf and in order to allocate the transmission capacity;
(d)  an allowance, credit, permit, right or similar asset which is directly linked to the supply, distribution or consumption
of energy derived from renewable resources, except where the contract is already within the scope of Section C of
Annex I to Directive 2014/65/EU;
(e)  a geological, environmental or other physical variable, except if the contract is relating to any units recognised for
compliance with the requirements of Directive 2003/87/EC of the European Parliament and of the Council (1);
(f)  any other asset or right of a fungible nature, other than a right to receive a service, that is capable of being
transferred;
(g)  an index or measure related to the price or value of, or volume of transactions in any asset, right, service or
obligation;
(h)  an index or measure based on actuarial statistics.
Article 9
Investment advice
(Article 4(1)(4) of Directive 2014/65/EU)
For the purposes of the definition of ‘investment advice’ in Article 4(1)(4) of Directive 2014/65/EU, a personal
recommendation shall be considered a recommendation that is made to a person in his capacity as an investor or
potential investor, or in his capacity as an agent for an investor or potential investor.
That recommendation shall be presented as suitable for that person, or shall be based on a consideration of the circum­
stances of that person, and shall constitute a recommendation to take one of the following sets of steps:
(a)  to buy, sell, subscribe for, exchange, redeem, hold or underwrite a particular financial instrument;
31.3.2017
L 87/22
Official Journal of the European Union
EN
(1) Directive 2003/87/EC of the European Parliament and of the Council of 13 October 2003 establishing a scheme for greenhouse gas
emission allowance trading within the Community and amending Council Directive 96/61/EC (OJ L 275, 25.10.2003, p. 32).

<!-- source-page: 23 -->

(b)  to exercise or not to exercise any right conferred by a particular financial instrument to buy, sell, subscribe for,
exchange, or redeem a financial instrument.
A recommendation shall not be considered a personal recommendation if it is issued exclusively to the public.
Article 10
Characteristics of other derivative contracts relating to currencies
1.
For the purposes of Section C(4) of Annex I to Directive 2014/65/EU, other derivative contracts relating to
a currency shall not be a financial instrument where the contract is one of the following:
(a)  a spot contract within the meaning of paragraph 2 of this Article,
(b)  a means of payment that:
(i)  must be settled physically otherwise than by reason of a default or other termination event;
(ii)  is entered into by at least a person which is not a financial counterparty within the meaning of Article 2(8) of
Regulation (EU) No 648/2012 of the European Parliament and of the Council (1);
(iii)  is entered into in order to facilitate payment for identifiable goods, services or direct investment; and
(iv)  is not traded on a trading venue.
2.
A spot contract for the purposes of paragraph 1 shall be a contract for the exchange of one currency against
another currency, under the terms of which delivery is scheduled to be made within the longer of the following periods:
(a)  2 trading days in respect of any pair of the major currencies set out in paragraph 3;
(b)  for any pair of currencies where at least one currency is not a major currency, the longer of 2 trading days or the
period generally accepted in the market for that currency pair as the standard delivery period;
(c)  where the contract for the exchange of those currencies is used for the main purpose of the sale or purchase of
a transferable security or a unit in a collective investment undertaking, the period generally accepted in the market
for the settlement of that transferable security or a unit in a collective investment undertaking as the standard
delivery period or 5 trading days, whichever is shorter.
A contract shall not be considered a spot contract where, irrespective of its explicit terms, there is an understanding
between the parties to the contract that delivery of the currency is to be postponed and not to be performed within the
period set out in the first subparagraph.
3.
The major currencies for the purposes of paragraph 2 shall only include the US dollar, Euro, Japanese yen, Pound
sterling, Australian dollar, Swiss franc, Canadian dollar, Hong Kong dollar, Swedish krona, New Zealand dollar,
Singapore dollar, Norwegian krone, Mexican peso, Croatian kuna, Bulgarian lev, Czech koruna, Danish krone, Hungarian
forint, Polish złoty and Romanian leu.
4.
For the purposes of paragraph 2, a trading day shall mean any day of normal trading in the jurisdiction of both
the currencies that are exchanged pursuant to the contract for the exchange of those currencies and in the jurisdiction
of a third currency where any of the following conditions are met:
(a)  the exchange of those currencies involves converting them through that third currency for the purposes of liquidity;
(b)  the standard delivery period for the exchange of those currencies references the jurisdiction of that third currency.
31.3.2017
L 87/23
Official Journal of the European Union
EN
(1) Regulation (EU) No 648/2012 of the European Parliament and of the Council of 4 July 2012 on OTC derivatives, central counterparties
and trade repositories (OJ L 201, 27.7.2012, p. 1).

<!-- source-page: 24 -->

Article 11
Money-market instruments
(Article 4(1)(17) of Directive 2014/65/EU)
Money-market instruments in accordance with Article 4(1)(17) of Directive 2014/65/EU, shall include treasury bills,
certificates of deposits, commercial papers and other instruments with substantively equivalent features where they have
the following characteristics:
(a)  they have a value that can be determined at any time;
(b)  they are not derivatives;
(c)  they have a maturity at issuance of 397 days or less.
Article 12
Systematic internalisers for shares, depositary receipts, ETFs, certificates and other similar
financial instruments
(Article 4(1)(20) of Directive 2014/65/EU)
An investment firm shall be considered to be a systematic internaliser in accordance with Article 4(1)(20) of Directive
2014/65/EU in respect of each share, depositary receipt, exchange traded fund (ETF), certificate and other similar
financial instrument where it internalises according to the following criteria:
(a)  on a frequent and systematic basis in the financial instrument for which there is a liquid market as defined in
Article 2(1)(17)(b) of Regulation (EU) No 600/2014 where during the past 6 months:
(i)  the number of OTC transactions carried out by it on own account when executing client orders is equal to or
larger than 0,4 % of the total number of transactions in the relevant financial instrument executed in the Union
on any trading venue or OTC during the same period;
(ii)  the OTC transactions carried out by it on own account when executing client orders in the relevant financial
instrument take place on average on a daily basis;
(b)  on a frequent and systematic basis in the financial instrument for which there is not a liquid market as defined in
Article 2(1)(17)(b) of Regulation (EU) No 600/2014 where during the past 6 months the OTC transactions carried
out by it on own account when executing client orders takes place on average on a daily basis;
(c)  on a substantial basis in the financial instrument where the size of OTC trading carried out by it on own account
when executing client orders is, during the past 6 months, equal to or larger than either:
(i)  15 % of the total turnover in that financial instrument executed by the investment firm on own account or on
behalf of clients and executed on a trading venue or OTC;
(ii)  0,4 % of the total turnover in that financial instrument executed in the Union on a trading venue or OTC.
Article 13
Systematic internalisers for bonds
(Article 4(1)(20) of Directive 2014/65/EU)
An investment firm shall be considered to be a systematic internaliser in accordance with Article 4(1)(20) of Directive
2014/65/EU in respect of all bonds belonging to a class of bonds issued by the same entity or by any entity within the
same group where, in relation to any such bond, it internalises according to the following criteria:
(a)  on a frequent and systematic basis in a bond for which there is a liquid market as defined in Article 2(1)(17)(a) of
Regulation (EU) No 600/2014 where during the past 6 months:
(i)  the number of OTC transactions carried out by it on own account when executing client orders is equal to or
larger than 2,5 % of the total number of transactions in the relevant bond executed in the Union on any trading
venue or OTC during the same period;
31.3.2017
L 87/24
Official Journal of the European Union
EN

<!-- source-page: 25 -->

(ii)  the OTC transactions carried out by it on own account when executing client orders in the relevant financial
instrument take place on average once a week;
(b)  on a frequent and systematic basis in a bond for which there is not a liquid market as defined in Article 2(1)(17)(a)
of Regulation (EU) No 600/2014 where during the past 6 months the OTC transactions carried out by it on own
account when executing client orders take place on average once a week;
(c)  on a substantial basis in a bond where the size of OTC trading carried out by it on own account when executing
client orders is, during the past 6 months, equal to or larger than any of the following:
(i)  25 % of the total turnover in that bond executed by the investment firm on own account or on behalf of clients
and executed on a trading venue or OTC;
(ii)  1 % of the total turnover in that bond executed in the Union on a trading venue or OTC.
Article 14
Systematic internalisers for structured finance products
(Article 4(1)(20) of Directive 2014/65/EU)
An investment firm shall be considered to be a systematic internaliser in accordance with Article 4(1)(20) of Directive
2014/65/EU in respect of all structured finance products belonging to a class of structured finance products issued by
the same entity or by any entity within the same group where, in relation to any such structured finance product, it
internalises according to the following criteria:
(a)  on a frequent and systematic basis in a structured finance product for which there is a liquid market as defined in
Article 2(1)(17)(a) of Regulation (EU) No 600/2014 where during the past 6 months:
(i)  the number of OTC transactions carried out by it on own account when executing client orders is equal to or
larger than 4 % of the total number of transactions in the relevant structured finance product executed in the
Union on any trading venue or OTC during the same period;
(ii)  the OTC transactions carried out by it on own account when executing client orders in the relevant financial
instrument take place on average once a week;
(b)  on a frequent and systematic basis in a structured finance product for which there is not a liquid market as defined
in Article 2(1)(17)(a) of Regulation (EU) No 600/2014 where during the past 6 months the OTC transactions carried
out by it on own account when executing client orders take place on average once a week;
(c)  on a substantial basis in a structured finance product where the size of OTC trading carried out by it on own
account when executing client orders is, during the past 6 months, equal to or larger than any of the following:
(i)  30 % of the total turnover in that structured finance product executed by the investment firm on own account
or on behalf of clients and executed on a trading venue or OTC;
(ii)  2,25 % of the total turnover in that structured finance product executed in the Union on a trading venue or
OTC.
Article 15
Systematic internalisers for derivatives
(Article 4(1)(20) of Directive 2014/65/EU)
An investment firm shall be considered to be a systematic internaliser in accordance with Article 4(1)(20) of Directive
2014/65/EU in respect of all derivatives belonging to a class of derivatives where, in relation to any such derivative, it
internalises according to the following criteria:
(a)  on a frequent and systematic basis in a derivative for which there is a liquid market as defined in Article 2(1)(17)(a)
of Regulation (EU) No 600/2014 where during the past 6 months:
(i)  the number of OTC transactions carried out by it on own account when executing client orders is equal to or
larger than 2,5 % of the total number of transactions in the relevant class of derivatives executed in the Union
on any trading venue or OTC during the same period;
31.3.2017
L 87/25
Official Journal of the European Union
EN

<!-- source-page: 26 -->

(ii)  the OTC transactions carried out by it on own account when executing client orders in this class of derivatives
take place on average once a week;
(b)  on a frequent and systematic basis in a derivative for which there is not a liquid market as defined in
Article 2(1)(17)(a) of Regulation (EU) No 600/2014 where during the past 6 months the OTC transactions carried
out by it on own account in the relevant class of derivative when executing client orders takes place on average once
a week;
(c)  on a substantial basis in a derivative where the size of OTC trading carried out by it on own account when
executing client orders is, during the past 6 months, equal to or larger than any of the following:
(i)  25 % of the total turnover in that class of derivatives executed by the investment firm on own account or on
behalf of clients and executed on a trading venue or OTC; or
(ii)  1 % of the total turnover in that class of derivatives executed in the Union on a trading venue or OTC.
Article 16
Systematic internalisers for emission allowances
(Article 4(1)(20) of Directive 2014/65/EU)
An investment firm shall be considered to be a systematic internaliser in accordance with Article 4(1)(20) of Directive
2014/65/EU in respect of emission allowances where, in relation to any such instrument, it internalises according to the
following criteria:
(a)  on a frequent and systematic basis in an emission allowance for which there is a liquid market as defined in
Article 2(1)(17)(a) of Regulation (EU) No 600/2014 where during the past 6 months:
(i)  the number of OTC transactions carried out by it on own account when executing client orders is equal to or
larger than 4 % of the total number of transactions in the relevant type of emission allowances executed in the
Union on any trading venue or OTC during the same period;
(ii)  the OTC transactions carried out by it on own account when executing client orders in this type of emission
allowances take place on average once a week;
(b)  on a frequent and systematic basis in an emission allowance for which there is not a liquid market as defined in
Article 2(1)(17)(a) of Regulation (EU) No 600/2014 where during the past 6 months the OTC transactions carried
out by it on own account in the relevant type of emission allowances when executing client orders takes place on
average once a week;
(c)  on a substantial basis in an emission allowance where the size of OTC trading carried out by it on own account
when executing client orders is, during the past 6 months, equal to or larger than any of the following:
(i)  30 % of the total turnover in that type of emission allowances executed by the investment firm on own account
or on behalf of clients and executed on a trading venue or OTC;
(ii)  2,25 % of the total turnover in that type of emission allowance executed in the Union on a trading venue or
OTC.
Article 17
Relevant assessment periods
(Article 4(1)(20) of Directive 2014/65/EU)
The conditions set out in Articles 12 to 16 shall be assessed on a quarterly basis on the basis of data from the past
6 months. The assessment period shall start on the first working day of the months of January, April, July and October.
31.3.2017
L 87/26
Official Journal of the European Union
EN

<!-- source-page: 27 -->

Newly issued instruments shall only be considered in the assessment when historical data covers a period of at least
three months in the case of shares, depositary receipts, ETFs, certificates and other similar financial instruments, and six
weeks in the case of bonds, structured finance products and derivatives.
Article 18
Algorithmic trading
(Article 4(1)(39) of Directive 2014/65/EU)
For the purposes of further specifying the definition of algorithmic trading in accordance with Article 4(1)(39) of
Directive 2014/65/EU, a system shall be considered as having no or limited human intervention where, for any order or
quote generation process or any process to optimise order-execution, an automated system makes decisions at any of
the stages of initiating, generating, routing or executing orders or quotes according to pre-determined parameters.
Article 19
High frequency algorithmic trading technique
(Article 4(1)(40) of Directive 2014/65/EU)
1.
A high message intraday rate in accordance with Article 4(1)(40) of Directive 2014/65/EU shall consist of the
submission on average of any of the following:
(a)  at least 2 messages per second with respect to any single financial instrument traded on a trading venue;
(b)  at least 4 messages per second with respect to all financial instruments traded on a trading venue.
2.
For the purposes of paragraph 1, messages concerning financial instruments for which there is a liquid market in
accordance with Article 2(1)(17) of Regulation (EU) No 600/2014 shall be included in the calculation. Messages
introduced for the purpose of trading that fulfil the criteria in Article 17(4) of Directive 2014/65/EU shall be included in
the calculation.
3.
For the purposes of paragraph 1, messages introduced for the purpose of dealing on own account shall be
included in the calculation. Messages introduced through other trading techniques than those relying on dealing on own
account shall be included in the calculation where the firm's execution technique is structured in such a way as to avoid
that the execution takes place on own account.
4.
For the purposes of paragraph 1, for the calculation of high message intraday rate in relation to DEA providers,
messages submitted by their DEA clients shall be excluded from the calculations.
5.
For the purposes of paragraph 1, trading venues shall make available to the firms concerned, on request, estimates
of the average number of messages per second on a monthly basis two weeks after the end of each calendar month,
thereby taking into account all messages submitted during the preceding 12 months.
Article 20
Direct electronic access
(Article 4(1)(41) of Directive 2014/65/EU)
1.
A person shall be considered not capable of electronically transmitting orders relating to a financial instrument
directly to a trading venue in accordance with Article 4(1)(41) of Directive 2014/65/EU where that person cannot
exercise discretion regarding the exact fraction of a second of order entry and the lifetime of the order within that
timeframe.
2.
A person shall be considered not capable of such direct electronic order transmission where it takes place through
arrangements for optimisation of order execution processes that determine the parameters of the order other than the
venue or venues where the order should be submitted, unless these arrangements are embedded into the clients' systems
and not into those of the member or participant of a regulated market or of an MTF or a client of an OTF.
31.3.2017
L 87/27
Official Journal of the European Union
EN

<!-- source-page: 28 -->

CHAPTER II
ORGANISATIONAL REQUIREMENTS
SECTION 1
Organisation
Article 21
General organisational requirements
(Article 16(2) to (10) of Directive 2014/65/EU)
1.
Investment firms shall comply with the following organisational requirements:
(a)  establish, implement and maintain decision-making procedures and an organisational structure which clearly and in
documented manner specifies reporting lines and allocates functions and responsibilities;
(b)  ensure that their relevant persons are aware of the procedures which must be followed for the proper discharge of
their responsibilities;
(c)  establish, implement and maintain adequate internal control mechanisms designed to secure compliance with
decisions and procedures at all levels of the investment firm;
(d)  employ personnel with the skills, knowledge and expertise necessary for the discharge of the responsibilities
allocated to them;
(e)  establish, implement and maintain effective internal reporting and communication of information at all relevant
levels of the investment firm;
(f)  maintain adequate and orderly records of their business and internal organisation;
(g)  ensure that the performance of multiple functions by their relevant persons does not and is not likely to prevent
those persons from discharging any particular function soundly, honestly, and professionally.
When complying with the requirements set out in the this paragraph, investment firms shall take into account the
nature, scale and complexity of the business of the firm, and the nature and range of investment services and activities
undertaken in the course of that business.
2.
Investment firms shall establish, implement and maintain systems and procedures that are adequate to safeguard
the security, integrity and confidentiality of information, taking into account the nature of the information in question.
3.
Investment firms shall establish, implement and maintain an adequate business continuity policy aimed at
ensuring, in the case of an interruption to their systems and procedures, the preservation of essential data and functions,
and the maintenance of investment services and activities, or, where that is not possible, the timely recovery of such
data and functions and the timely resumption of their investment services and activities.
4.
Investment firms shall establish, implement and maintain accounting policies and procedures that enable them, at
the request of the competent authority, to deliver in a timely manner to the competent authority financial reports which
reflect a true and fair view of their financial position and which comply with all applicable accounting standards and
rules.
5.
Investment firms shall monitor and, on a regular basis, evaluate the adequacy and effectiveness of their systems,
internal control mechanisms and arrangements established in accordance with paragraphs 1 to 4, and take appropriate
measures to address any deficiencies.
Article 22
Compliance
(Article 16(2) of Directive 2014/65/EU)
1.
Investment firms shall establish, implement and maintain adequate policies and procedures designed to detect any
risk of failure by the firm to comply with its obligations under Directive 2014/65/EU, as well as the associated risks, and
put in place adequate measures and procedures designed to minimise such risk and to enable the competent authorities
to exercise their powers effectively under that Directive.
31.3.2017
L 87/28
Official Journal of the European Union
EN

<!-- source-page: 29 -->

Investment firms shall take into account the nature, scale and complexity of the business of the firm, and the nature and
range of investment services and activities undertaken in the course of that business.
2.
Investment firms shall establish and maintain a permanent and effective compliance function which operates
independently and which has the following responsibilities:
(a)  to monitor on a permanent basis and to assess, on a regular basis, the adequacy and effectiveness of the measures,
policies and procedures put in place in accordance with the first subparagraph of paragraph 1, and the actions taken
to address any deficiencies in the firm's compliance with its obligations;
(b)  to advise and assist the relevant persons responsible for carrying out investment services and activities to comply
with the firm's obligations under Directive 2014/65/EU;
(c)  to report to the management body, on at least an annual basis, on the implementation and effectiveness of the
overall control environment for investment services and activities, on the risks that have been identified and on the
complaints-handling reporting as well as remedies undertaken or to be undertaken;
(d)  to monitor the operations of the complaints-handling process and consider complaints as a source of relevant
information in the context of its general monitoring responsibilities.
In order to comply with points (a) and (b) of this paragraph, the compliance function shall conduct an assessment on
the basis of which it shall establish a risk-based monitoring programme that takes into consideration all areas of the
investment firm's investment services, activities and any relevant ancillary services, including relevant information
gathered in relation to the monitoring of complaints handling. The monitoring programme shall establish priorities
determined by the compliance risk assessment ensuring that compliance risk is comprehensively monitored.
3.
In order to enable the compliance function referred to in paragraph 2 to discharge its responsibilities properly and
independently, investment firms shall ensure that the following conditions are satisfied:
(a)  the compliance function has the necessary authority, resources, expertise and access to all relevant information;
(b)  a compliance officer is appointed and replaced by the management body and is responsible for the compliance
function and for any reporting as to compliance required by Directive 2014/65/EU and Article 25(2) of this
Regulation;
(c)  the compliance function reports on an ad-hoc basis directly to the management body where it detects a significant
risk of failure by the firm to comply with its obligations under Directive 2014/65/EU;
(d)  the relevant persons involved in the compliance function are not involved in the performance of services or
activities they monitor;
(e)  the method of determining the remuneration of the relevant persons involved in the compliance function does not
compromise their objectivity and is not likely to do so.
4.
An investment firm shall not be required to comply with point (d) or point (e) of paragraph 3 where it is able to
demonstrate that in view of the nature, scale and complexity of its business, and the nature and range of investment
services and activities, the requirements under point (d) or (e) are not proportionate and that its compliance function
continues to be effective. In that case, the investment firm shall assess whether the effectiveness of the compliance
function is compromised. The assessment shall be reviewed on a regular basis.
Article 23
Risk management
(Article 16(5) of Directive 2014/65/EU)
1.
Investment firms shall take the following actions relating to risk management:
(a)  establish, implement and maintain adequate risk management policies and procedures which identify the risks
relating to the firm's activities, processes and systems, and where appropriate, set the level of risk tolerated by the
firm;
31.3.2017
L 87/29
Official Journal of the European Union
EN

<!-- source-page: 30 -->

(b)  adopt effective arrangements, processes and mechanisms to manage the risks relating to the firm's activities,
processes and systems, in light of that level of risk tolerance;
(c)  monitor the following:
(i)  the adequacy and effectiveness of the investment firm's risk management policies and procedures;
(ii)  the level of compliance by the investment firm and its relevant persons with the arrangements, processes and
mechanisms adopted in accordance with point (b);
(iii)  the adequacy and effectiveness of measures taken to address any deficiencies in those policies, procedures,
arrangements, processes and mechanisms, including failures by the relevant persons to comply with such
arrangements, processes and mechanisms or follow such policies and procedures.
2.
Investment firms shall, where appropriate and proportionate in view of the nature, scale and complexity of their
business and the nature and range of the investment services and activities undertaken in the course of that business,
establish and maintain a risk management function that operates independently and carries out the following tasks:
(a)  implementation of the policy and procedures referred to in paragraph 1;
(b)  provision of reports and advice to senior management in accordance with Article 25(2).
Where an investment firm does not establish and maintain a risk management function under the first sub-paragraph, it
shall be able to demonstrate upon request that the policies and procedures which it is has adopted in accordance with
paragraph 1 satisfy the requirements therein.
Article 24
Internal audit
(Article 16(5) of Directive 2014/65/EU)
Investment firms shall, where appropriate and proportionate in view of the nature, scale and complexity of their
business and the nature and range of investment services and activities undertaken in the course of that business,
establish and maintain an internal audit function which is separate and independent from the other functions and
activities of the investment firm and which has the following responsibilities:
(a)  establish, implement and maintain an audit plan to examine and evaluate the adequacy and effectiveness of the
investment firm's systems, internal control mechanisms and arrangements;
(b)  issue recommendations based on the result of work carried out in accordance with point (a) and verify compliance
with those recommendations;
(c)  report in relation to internal audit matters in accordance with Article 25(2).
Article 25
Responsibility of senior management
(Article 16(2) of Directive 2014/65/EU)
1.
Investment firms shall, when allocating functions internally, ensure that senior management, and, where
applicable, the supervisory function, are responsible for ensuring that the firm complies with its obligations under
Directive 2014/65/EU. In particular, senior management and, where applicable, the supervisory function shall be
required to assess and periodically review the effectiveness of the policies, arrangements and procedures put in place to
comply with the obligations under Directive 2014/65/EU and to take appropriate measures to address any deficiencies.
The allocation of significant functions among senior managers shall clearly establish who is responsible for overseeing
and maintaining the firm's organisational requirements. Records of the allocation of significant functions shall be kept
up-to-date.
2.
Investment firms shall ensure that their senior management receive on a frequent basis, and at least annually,
written reports on the matters covered by Articles 22, 23 and 24 indicating in particular whether the appropriate
remedial measures have been taken in the event of any deficiencies.
31.3.2017
L 87/30
Official Journal of the European Union
EN

<!-- source-page: 31 -->

3.
Investment firms shall ensure that where there is a supervisory function, it receives written reports on the matters
covered by Articles 22, 23 and 24 on a regular basis.
4.
For the purposes of this Article, the supervisory function shall be the function within an investment firm
responsible for the supervision of its senior management.
Article 26
Complaints handling
(Article 16(2) of Directive 2014/65/EU)
1.
Investment firms shall establish, implement and maintain effective and transparent complaints management
policies and procedures for the prompt handling of clients' or potential clients' complaints. Investment firms shall keep
a record of the complaints received and the measures taken for their resolution.
The complaints management policy shall provide clear, accurate and up-to-date information about the complaints-
handling process. This policy shall be endorsed by the firm's management body.
2.
Investment firms shall publish the details of the process to be followed when handling a complaint. Such details
shall include information about the complaints management policy and the contact details of the complaints
management function. The information shall be provided to clients or potential clients, on request, or when
acknowledging a complaint. Investment firms shall enable clients and potential clients to submit complaints free of
charge.
3.
Investment firms shall establish a complaints management function responsible for the investigation of complaints.
This function may be carried out by the compliance function.
4.
When handling a complaint, investment firms shall communicate with clients or potential clients clearly, in plain
language that is easy to understand and shall reply to the complaint without undue delay.
5.
Investment firms shall communicate the firm's position on the complaint to clients or potential clients and inform
the clients or potential clients about their options, including that they may be able to refer the complaint to an
alternative dispute resolution entity, as defined in Article 4(h) of Directive 2013/11/EU of the European Parliament and
the Council (1) on consumer ADR or that the client may be able to take civil action.
6.
Investment firms shall provide information on complaints and complaints-handling to the relevant competent
authorities and, where applicable under national law, to an alternative dispute resolution (ADR) entity.
7.
Investment firms' compliance function shall analyse complaints and complaints-handling data to ensure that they
identify and address any risks or issues.
Article 27
Remuneration policies and practices
(Articles 16, 23 and 24 of Directive 2014/65/EU)
1.
Investment firms shall define and implement remuneration policies and practices under appropriate internal
procedures taking into account the interests of all the clients of the firm, with a view to ensuring that clients are treated
fairly and their interests are not impaired by the remuneration practices adopted by the firm in the short, medium or
long term.
Remuneration policies and practices shall be designed in such a way so as not to create a conflict of interest or incentive
that may lead relevant persons to favour their own interests or the firm's interests to the potential detriment of any
client.
31.3.2017
L 87/31
Official Journal of the European Union
EN
(1) Directive 2013/11/EU of the European Parliament and the Council of 21 May 2013 on alternative dispute resolution for consumer
disputes and amending Regulation (EC) No 2006/2004 and Directive 2009/22/EC (Directive on consumer ADR) (OJ L 165, 18.6.2013,
p. 63).

<!-- source-page: 32 -->

2.
Investment firms shall ensure that their remuneration policies and practices apply to all relevant persons with an
impact, directly or indirectly, on investment and ancillary services provided by the investment firm or on its corporate
behaviour, regardless of the type of clients, to the extent that the remuneration of such persons and similar incentives
may create a conflict of interest that encourages them to act against the interests of any of the firm's clients.
3.
The management body of the investment firm shall approve, after taking advice from the compliance function, the
firm's remuneration policy. The senior management of the investment firm shall be responsible for the day-to-day
implementation of the remuneration policy and the monitoring of compliance risks related to the policy.
4.
Remuneration and similar incentives shall not be solely or predominantly based on quantitative commercial
criteria, and shall take fully into account appropriate qualitative criteria reflecting compliance with the applicable
regulations, the fair treatment of clients and the quality of services provided to clients.
A balance between fixed and variable components of remuneration shall be maintained at all times, so that the
remuneration structure does not favour the interests of the investment firm or its relevant persons against the interests
of any client.
Article 28
Scope of personal transactions
(Article 16(2) of Directive 2014/65/EU)
For the purposes of Article 29 and Article 37, a personal transaction shall be a trade in a financial instrument effected
by or on behalf of a relevant person, where at least one of the following criteria are met:
(a)  the relevant person is acting outside the scope of the activities he carries out in his professional capacity;
(b)  the trade is carried out for the account of any of the following persons:
(i)  the relevant person;
(ii)  any person with whom he has a family relationship, or with whom he has close links;
(iii)  a person in respect of whom the relevant person has a direct or indirect material interest in the outcome of the
trade, other than obtaining a fee or commission for the execution of the trade.
Article 29
Personal transactions
(Article 16(2) of Directive 2014/65/EU)
1.
Investment firms shall establish, implement and maintain adequate arrangements aimed at preventing the activities
set out in paragraphs 2, 3 and 4 in the case of any relevant person who is involved in activities that may give rise to
a conflict of interest, or who has access to inside information within the meaning of Article 7(1) of Regulation (EU)
No 596/2014 or to other confidential information relating to clients or transactions with or for clients by virtue of an
activity carried out by him on behalf of the firm.
2.
Investment firms shall ensure that relevant persons do not enter into a personal transaction which meets at least
one of the following criteria:
(a)  that person is prohibited from entering into it under Regulation (EU) No 596/2014;
(b)  it involves the misuse or improper disclosure of that confidential information;
(c)  it conflicts or is likely to conflict with an obligation of the investment firm under Directive 2014/65/EU.
3.
Investment firms shall ensure that relevant persons do not advise or recommend, other than in the proper course
of employment or contract for services, any other person to enter into a transaction in financial instruments which, if it
were a personal transaction of the relevant person, would be covered by paragraph 2 or Article 37(2)(a) or (b) or
Article 67(3).
31.3.2017
L 87/32
Official Journal of the European Union
EN

<!-- source-page: 33 -->

4.
Without prejudice to Article 10(1) of Regulation (EU) No 596/2014, investment firms shall ensure that relevant
persons do not disclose, other than in the normal course of his employment or contract for services, any information or
opinion to any other person where the relevant person knows, or reasonably ought to know, that as a result of that
disclosure that other person will or would be likely to take either of the following steps:
(a)  to enter into a transaction in financial instruments which, if it were a personal transaction of the relevant person,
would be covered by paragraphs 2 or 3 or Article 37(2)(a) or (b) or Article 67(3);
(b)  to advise or procure another person to enter into such a transaction.
5.
The arrangements required under paragraph 1 shall be designed to ensure that:
(a)  each relevant person covered by paragraphs 1, 2, 3 and 4 is aware of the restrictions on personal transactions, and
of the measures established by the investment firm in connection with personal transactions and disclosure, in
accordance with paragraphs 1, 2,3 and 4.
(b)  the firm is informed promptly of any personal transaction entered into by a relevant person, either by notification of
that transaction or by other procedures enabling the firm to identify such transactions;
(c)  a record is kept of the personal transaction notified to the firm or identified by it, including any authorisation or
prohibition in connection with such a transaction.
In the case of outsourcing arrangements, the investment firm shall ensure that the firm to which the activity is
outsourced maintains a record of personal transactions entered into by any relevant person and provides that
information to the investment firm promptly on request.
6.
Paragraphs 1 to 5 shall not apply to the following personal transactions:
(a) personal transactions effected under a discretionary portfolio management service where there is no prior communi­
cation in connection with the transaction between the portfolio manager and the relevant person or other person
for whose account the transaction is executed;
(b)  personal transactions in undertakings for collective investments in transferable securities (UCITS) or AIFs that are
subject to supervision under the law of a Member State which requires an equivalent level of risk spreading in their
assets, where the relevant person and any other person for whose account the transactions are effected are not
involved in the management of that undertaking.
SECTION 2
Outsourcing
Article 30
Scope of critical and important operational functions
(Article 16(2) and first subparagraph of Article 16(5) of Directive 2014/65/EU)
1.
For the purposes of the first subparagraph of Article 16(5) of Directive 2014/65/EU, an operational function shall
be regarded as critical or important where a defect or failure in its performance would materially impair the continuing
compliance of an investment firm with the conditions and obligations of its authorisation or its other obligations under
Directive 2014/65/EU, or its financial performance, or the soundness or the continuity of its investment services and
activities.
2.
Without prejudice to the status of any other function, the following functions shall not be considered as critical or
important for the purposes of paragraph 1:
(a)  the provision to the firm of advisory services, and other services which do not form part of the investment business
of the firm, including the provision of legal advice to the firm, the training of personnel of the firm, billing services
and the security of the firm's premises and personnel;
(b)  the purchase of standardised services, including market information services and the provision of price feeds.
31.3.2017
L 87/33
Official Journal of the European Union
EN

<!-- source-page: 34 -->

Article 31
Outsourcing critical or important operational functions
(Article 16(2) and of Article 16(5) first subparagraph of Directive 2014/65/EU)
1.
Investment firms outsourcing critical or important operational functions shall remain fully responsible for
discharging all of their obligations under Directive 2014/65/EU and shall comply with the following conditions:
(a)  the outsourcing does not result in the delegation by senior management of its responsibility;
(b)  the relationship and obligations of the investment firm towards its clients under the terms of Directive 2014/65/EU
is not altered;
(c)  the conditions with which the investment firm must comply in order to be authorised in accordance with Article 5
of Directive 2014/65/EU, and to remain so, are not undermined;
(d)  none of the other conditions subject to which the firm's authorisation was granted is removed or modified.
2.
Investment firms shall exercise due skill, care and diligence when entering into, managing or terminating any
arrangement for the outsourcing to a service provider of critical or important operational functions and shall take the
necessary steps to ensure that the following conditions are satisfied:
(a)  the service provider has the ability, capacity, sufficient resources, appropriate organisational structure supporting the
performance of the outsourced functions, and any authorisation required by law to perform the outsourced
functions, reliably and professionally;
(b)  the service provider carries out the outsourced services effectively and in compliance with applicable law and
regulatory requirements, and to this end the firm has established methods and procedures for assessing the standard
of performance of the service provider and for reviewing on an ongoing basis the services provided by the service
provider;
(c)  the service provider properly supervises the carrying out of the outsourced functions, and adequately manage the
risks associated with the outsourcing;
(d)  appropriate action is taken where it appears that the service provider may not be carrying out the functions
effectively or in compliance with applicable laws and regulatory requirements;
(e)  the investment firm effectively supervises the outsourced functions or services and manage the risks associated with
the outsourcing and to this end the firm retains the necessary expertise and resources to supervise the outsourced
functions effectively and manage those risks;
(f)  the service provider has disclosed to the investment firm any development that may have a material impact on its
ability to carry out the outsourced functions effectively and in compliance with applicable laws and regulatory
requirements;
(g)  the investment firm is able to terminate the arrangement for outsourcing where necessary, with immediate effect
when this is in the interests of its clients, without detriment to the continuity and quality of its provision of services
to clients;
(h)  the service provider cooperates with the competent authorities of the investment firm in connection with the
outsourced functions;
(i)  the investment firm, its auditors and the relevant competent authorities have effective access to data related to the
outsourced functions, as well as to the relevant business premises of the service provider, where necessary for the
purpose of effective oversight in accordance with this article, and the competent authorities are able to exercise
those rights of access;
31.3.2017
L 87/34
Official Journal of the European Union
EN

<!-- source-page: 35 -->

(j)  the service provider protects any confidential information relating to the investment firm and its clients;
(k)  the investment firm and the service provider have established, implemented and maintained a contingency plan for
disaster recovery and periodic testing of backup facilities, where that is necessary having regard to the function,
service or activity that has been outsourced;
(l)  the investment firm has ensured that the continuity and quality of the outsourced functions or services are
maintained also in the event of termination of the outsourcing either by transferring the outsourced functions or
services to another third party or by performing them itself.
3.
The respective rights and obligations of the investment firms and of the service provider shall be clearly allocated
and set out in a written agreement. In particular, the investment firm shall keep its instruction and termination rights, its
rights of information, and its right to inspections and access to books and premises. The agreement shall ensure that
outsourcing by the service provider only takes place with the consent, in writing, of the investment firm.
4.
Where the investment firm and the service provider are members of the same group, the investment firm may, for
the purposes of complying with this Article and Article 32, take into account the extent to which the firm controls the
service provider or has the ability to influence its actions.
5.
Investment firms shall make available on request to the competent authority all information necessary to enable
the authority to supervise the compliance of the performance of the outsourced functions with the requirements of
Directive 2014/65/EU and its implementing measures.
Article 32
Service providers located in third countries
(Article 16(2) and first subparagraph of Article 16(5) of Directive 2014/65/EU)
1.
In addition to the requirements set out in Article 31, where an investment firm outsources functions related to the
investment service of portfolio management provided to clients to a service provider located in a third country, that
investment firm ensures that the following conditions are satisfied:
(a)  the service provider is authorised or registered in its home country to provide that service and is effectively
supervised by a competent authority in that third country;
(b)  there is an appropriate cooperation agreement between the competent authority of the investment firm and the
supervisory authority of the service provider.
2.
The cooperation agreement referred to in point (b) of paragraph 1 shall ensure that the competent authorities of
the investment firm are able, at least, to:
(a)  obtain on request the information necessary to carry out their supervisory tasks pursuant to Directive 2014/65/EU
and Regulation (EU) No 600/2014;
(b)  obtain access to the documents relevant for the performance of their supervisory duties maintained in the third
country;
(c)  receive information from the supervisory authority in the third country as soon as possible for the purpose of
investigating apparent breaches of the requirements of Directive 2014/65/EU and its implementing measures and
Regulation (EU) No 600/2014;
(d)  cooperate with regard to enforcement, in accordance with the national and international law applicable to the
supervisory authority of the third country and the competent authorities in the Union in cases of breach of the
requirements of Directive 2014/65/EU and its implementing measures and relevant national law.
3.
Competent authorities shall publish on their website a list of the supervisory authorities in third countries with
which they have a cooperation agreement referred to in point (b) of paragraph 1.
Competent authorities shall update cooperation agreements concluded before the date of entry into application of this
Regulation within six months from that date.
31.3.2017
L 87/35
Official Journal of the European Union
EN

<!-- source-page: 36 -->

SECTION 3
Conflicts of interest
Article 33
Conflicts of interest potentially detrimental to a client
(Articles 16(3) and 23 of Directive 2014/65/EU)
For the purposes of identifying the types of conflict of interest that arise in the course of providing investment and
ancillary services or a combination thereof and whose existence may damage the interests of a client, investment firms
shall take into account, by way of minimum criteria, whether the investment firm or a relevant person, or a person
directly or indirectly linked by control to the firm, is in any of the following situations, whether as a result of providing
investment or ancillary services or investment activities or otherwise:
(a)  the firm or that person is likely to make a financial gain, or avoid a financial loss, at the expense of the client;
(b)  the firm or that person has an interest in the outcome of a service provided to the client or of a transaction carried
out on behalf of the client, which is distinct from the client's interest in that outcome;
(c)  the firm or that person has a financial or other incentive to favour the interest of another client or group of clients
over the interests of the client;
(d)  the firm or that person carries on the same business as the client;
(e)  the firm or that person receives or will receive from a person other than the client an inducement in relation to
a service provided to the client, in the form of monetary or non-monetary benefits or services.
Article 34
Conflicts of interest policy
(Articles 16(3) and 23 of Directive 2014/65/EU)
1.
Investment firms shall establish, implement and maintain an effective conflicts of interest policy set out in writing
and appropriate to the size and organisation of the firm and the nature, scale and complexity of its business.
Where the firm is a member of a group, the policy shall also take into account any circumstances, of which the firm is
or should be aware, which may give rise to a conflict of interest arising as a result of the structure and business
activities of other members of the group.
2.
The conflicts of interest policy established in accordance with paragraph 1 shall include the following content:
(a)  it must identify, with reference to the specific investment services and activities and ancillary services carried out by
or on behalf of the investment firm, the circumstances which constitute or may give rise to a conflict of interest
entailing a risk of damage to the interests of one or more clients;
(b)  it must specify procedures to be followed and measures to be adopted in order to prevent or manage such conflicts.
3.
The procedures and measures referred to in paragraph 2(b) shall be designed to ensure that relevant persons
engaged in different business activities involving a conflict of interest of the kind specified in paragraph 2(a) carry on
those activities at a level of independence appropriate to the size and activities of the investment firm and of the group
to which it belongs, and to the risk of damage to the interests of clients.
For the purposes of paragraph 2(b), the procedures to be followed and measures to be adopted shall include at least
those items in the following list that are necessary for the firm to ensure the requisite degree of independence:
(a)  effective procedures to prevent or control the exchange of information between relevant persons engaged in
activities involving a risk of a conflict of interest where the exchange of that information may harm the interests of
one or more clients;
31.3.2017
L 87/36
Official Journal of the European Union
EN

<!-- source-page: 37 -->

(b)  the separate supervision of relevant persons whose principal functions involve carrying out activities on behalf of, or
providing services to, clients whose interests may conflict, or who otherwise represent different interests that may
conflict, including those of the firm;
(c)  the removal of any direct link between the remuneration of relevant persons principally engaged in one activity and
the remuneration of, or revenues generated by, different relevant persons principally engaged in another activity,
where a conflict of interest may arise in relation to those activities;
(d)  measures to prevent or limit any person from exercising inappropriate influence over the way in which a relevant
person carries out investment or ancillary services or activities;
(e)  measures to prevent or control the simultaneous or sequential involvement of a relevant person in separate
investment or ancillary services or activities where such involvement may impair the proper management of
conflicts of interest.
4.
Investment firms shall ensure that disclosure to clients, pursuant to Article 23(2) of Directive 2014/65/EU, is
a measure of last resort that shall be used only where the effective organisational and administrative arrangements
established by the investment firm to prevent or manage its conflicts of interest in accordance with Article 23 of
Directive 2014/65/EU are not sufficient to ensure, with reasonable confidence, that risks of damage to the interests of
the client will be prevented.
The disclosure shall clearly state that the organisational and administrative arrangements established by the investment
firm to prevent or manage that conflict are not sufficient to ensure, with reasonable confidence, that the risks of damage
to the interests of the client will be prevented. The disclosure shall include specific description of the conflicts of interest
that arise in the provision of investment and/or ancillary services, taking into account the nature of the client to whom
the disclosure is being made. The description shall explain the general nature and sources of conflicts of interest, as well
as the risks to the client that arise as a result of the conflicts of interest and the steps undertaken to mitigate these risks,
in sufficient detail to enable that client to take an informed decision with respect to the investment or ancillary service
in the context of which the conflicts of interest arise.
5.
Investment firms shall assess and periodically review, on an at least annual basis, the conflicts of interest policy
established in accordance with paragraphs 1 to 4 and shall take all appropriate measures to address any deficiencies.
Over-reliance on disclosure of conflicts of interest shall be considered a deficiency in the investment firm's conflicts of
interest policy.
Article 35
Record of services or activities giving rise to detrimental conflict of interest
(Article 16(6) of Directive 2014/65/EU)
Investment firms shall keep and regularly update a record of the kinds of investment or ancillary service or investment
activity carried out by or on behalf of the firm in which a conflict of interest entailing a risk of damage to the interests
of one or more clients has arisen or, in the case of an ongoing service or activity, may arise.
Senior management shall receive on a frequent basis, and at least annually, written reports on situations referred to in
this Article.
Article 36
Investment research and marketing communications
(Article 24(3) of Directive 2014/65/EU)
1.
For the purposes of Article 37 investment research shall be research or other information recommending or
suggesting an investment strategy, explicitly or implicitly, concerning one or several financial instruments or the issuers
of financial instruments, including any opinion as to the present or future value or price of such instruments, intended
for distribution channels or for the public, and in relation to which the following conditions are met:
(a)  the research or information is labelled or described as investment research or in similar terms, or is otherwise
presented as an objective or independent explanation of the matters contained in the recommendation;
31.3.2017
L 87/37
Official Journal of the European Union
EN

<!-- source-page: 38 -->

(b)  if the recommendation in question were made by an investment firm to a client, it would not constitute the
provision of investment advice for the purposes of Directive 2014/65/EU.
2.
A recommendation of the type covered by point (35) of Article 3(1) of Regulation (EU) No 596/2014 that does
not meet the conditions set out in paragraph 1 shall be treated as a marketing communication for the purposes of
Directive 2014/65/EU and investment firms that produce or disseminate that recommendation shall ensure that it is
clearly identified as such.
Additionally, firms shall ensure that any such recommendation contains a clear and prominent statement that (or, in the
case of an oral recommendation, to the effect that) it has not been prepared in accordance with legal requirements
designed to promote the independence of investment research, and that it is not subject to any prohibition on dealing
ahead of the dissemination of investment research.
Article 37
Additional organisational requirements in relation to investment research or marketing communi­
cations
(Article 16(3) of Directive 2014/65/EU)
1.
Investment firms which produce, or arrange for the production of, investment research that is intended or likely to
be subsequently disseminated to clients of the firm or to the public, under their own responsibility or that of a member
of their group, shall ensure the implementation of all the measures set out in Article 34(3) in relation to the financial
analysts involved in the production of the investment research and other relevant persons whose responsibilities or
business interests may conflict with the interests of the persons to whom the investment research is disseminated.
The obligations in the first subparagraph shall also apply in relation to recommendations referred to in Article 36(2).
2.
Investment firms referred to in the first subparagraph of paragraph 1 shall have in place arrangements designed to
ensure that the following conditions are satisfied:
(a)  financial analysts and other relevant persons do not undertake personal transactions or trade, other than as market
makers acting in good faith and in the ordinary course of market making or in the execution of an unsolicited client
order, on behalf of any other person, including the investment firm, in financial instruments to which investment
research relates, or in any related financial instruments, with knowledge of the likely timing or content of that
investment research which is not publicly available or available to clients and cannot readily be inferred from
information that is so available, until the recipients of the investment research have had a reasonable opportunity to
act on it;
(b)  in circumstances not covered by point (a), financial analysts and any other relevant persons involved in the
production of investment research do not undertake personal transactions in financial instruments to which the
investment research relates, or in any related financial instruments, contrary to current recommendations, except in
exceptional circumstances and with the prior approval of a member of the firm's legal or compliance function;
(c)  a physical separation exists between the financial analysts involved in the production of investment research and
other relevant persons whose responsibilities or business interests may conflict with the interests of the persons to
whom the investment research is disseminated or, when considered not appropriate to the size and organisation of
the firm as well as the nature, scale and complexity of its business, the establishment and implementation of
appropriate alternative information barriers;
(d)  the investment firms themselves, financial analysts, and other relevant persons involved in the production of the
investment research do not accept inducements from those with a material interest in the subject-matter of the
investment research;
(e)  the investment firms themselves, financial analysts, and other relevant persons involved in the production of the
investment research do not promise issuers favourable research coverage;
31.3.2017
L 87/38
Official Journal of the European Union
EN

<!-- source-page: 39 -->

(f)  before the dissemination of investment research issuers, relevant persons other than financial analysts, and any other
persons are not permitted to review a draft of the investment research for the purpose of verifying the accuracy of
factual statements made in that research, or for any purpose other than verifying compliance with the firm's legal
obligations, where the draft includes a recommendation or a target price.
For the purposes of this paragraph, ‘related financial instrument’ shall be any financial instrument the price of which is
closely affected by price movements in another financial instrument which is the subject of investment research, and
includes a derivative on that other financial instrument.
3.
Investment firms which disseminate investment research produced by another person to the public or to clients
shall be exempt from complying with paragraph 1 if the following criteria are met:
(a)  the person that produces the investment research is not a member of the group to which the investment firm
belongs;
(b)  the investment firm does not substantially alter the recommendations within the investment research;
(c)  the investment firm does not present the investment research as having been produced by it;
(d)  the investment firm verifies that the producer of the research is subject to requirements equivalent to the
requirements under this Regulation in relation to the production of that research, or has established a policy setting
such requirements.
Article 38
Additional general requirements in relation to underwriting or placing
(Articles 16(3), 23 and 24 of Directive 2014/65/EU)
1.
Investment firms which provide advice on corporate finance strategy, as set out in Section B(3) of Annex I, and
provide the service of underwriting or placing of financial instruments, shall, before accepting a mandate to manage the
offering, have arrangements in place to inform the issuer client of the following:
(a)  the various financing alternatives available with the firm, and an indication of the amount of transaction fees
associated with each alternative;
(b)  the timing and the process with regard to the corporate finance advice on pricing of the offer;
(c)  the timing and the process with regard to the corporate finance advice on placing of the offering;
(d)  details of the targeted investors, to whom the firm intends to offer the financial instruments;
(e)  the job titles and departments of the relevant individuals involved in the provision of corporate finance advice on
the price and allotment of financial instruments; and
(f)  firm's arrangements to prevent or manage conflicts of interest that may arise where the firm places the relevant
financial instruments with its investment clients or with its own proprietary book.
2.
Investment firms shall have in place a centralised process to identify all underwriting and placing operations of the
firm and record such information, including the date on which the firm was informed of potential underwriting and
placing operations. Firms shall identify all potential conflicts of interest arising from other activities of the investment
firm, or group, and implement appropriate management procedures. In cases where an investment firm cannot manage
a conflict of interest by way of implementing appropriate procedures, the investment firm shall not engage in the
operation.
3.
Investment firms providing execution and research services as well as carrying out underwriting and placing
activities shall ensure adequate controls are in place to manage any potential conflicts of interest between these activities
and between their different clients receiving those services.
31.3.2017
L 87/39
Official Journal of the European Union
EN

<!-- source-page: 40 -->

Article 39
Additional requirements in relation to pricing of offerings in relation to issuance of financial
instruments
(Articles 16(3), 23 and 24 of Directive 2014/65/EU)
1.
Investment firms shall have in place systems, controls and procedures to identify and prevent or manage conflicts
of interest that arise in relation to possible under-pricing or over-pricing of an issue or involvement of relevant parties
in the process. In particular, investment firms shall as a minimum requirement establish, implement and maintain
internal arrangements to ensure both of the following:
(a)  that the pricing of the offer does not promote the interests of other clients or firm's own interests, in a way that
may conflict with the issuer client's interests; and
(b)  the prevention or management of a situation where persons responsible for providing services to the firm's
investment clients are directly involved in decisions about corporate finance advice on pricing to the issuer client.
2.
Investment firms shall provide clients with information about how the recommendation as to the price of the
offering and the timings involved is determined. In particular, the firm shall inform and engage with the issuer client
about any hedging or stabilisation strategies it intends to undertake with respect to the offering, including how these
strategies may impact the issuer clients' interests. During the offering process, firms shall also take all reasonable steps to
keep the issuer client informed about developments with respect to the pricing of the issue.
Article 40
Additional requirements in relation to placing
(Articles 16(3), 23 and 24 of Directive 2014/65/EU)
1.
Investment firms placing financial instruments shall establish, implement and maintain effective arrangements to
prevent recommendations on placing from being inappropriately influenced by any existing or future relationships.
2.
Investment firms shall establish, implement and maintain effective internal arrangements to prevent or manage
conflicts of interests that arise where persons responsible for providing services to the firm's investment clients are
directly involved in decisions about recommendations to the issuer client on allocation.
3.
Investment firms shall not accept any third-party payments or benefits unless such payments or benefits comply
with the inducements requirements laid down in Article 24 of Directive 2014/65/EU. In particular, the following
practices shall be considered not compliant with those requirements and shall therefore be considered not acceptable:
(a)  an allocation made to incentivise the payment of disproportionately high fees for unrelated services provided by the
investment firm (‘laddering’), such as disproportionately high fees or commissions paid by an investment client, or
disproportionately high volumes of business at normal levels of commission provided by the investment client as
a compensation for receiving an allocation of the issue;
(b) an allocation made to a senior executive or a corporate officer of an existing or potential issuer client, in considera­
tion for the future or past award of corporate finance business (‘spinning’);
(c)  an allocation that is expressly or implicitly conditional on the receipt of future orders or the purchase of any other
service from the investment firm by an investment client, or any entity of which the investor is a corporate officer.
4.
Investment firms shall establish, implement and maintain an allocation policy that sets out the process for
developing allocation recommendations. The allocation policy shall be provided to the issuer client before agreeing to
undertake any placing services. The policy shall set out relevant information that is available at that stage, about the
proposed allocation methodology for the issue.
5.
Investment firms shall involve the issuer client in discussions about the placing process in order for the firm to be
able to understand and take into account the client's interests and objectives. The investment firm shall obtain the issuer
client's agreement to its proposed allocation per type of client for the transaction in accordance with the allocation
policy.
31.3.2017
L 87/40
Official Journal of the European Union
EN

<!-- source-page: 41 -->

Article 41
Additional requirements in relation to advice, distribution and self-placement
(Articles 16(3), 23 and 24 of Directive 2014/65/EU)
1.
Investment firms shall have in place systems, controls and procedures to identify and manage the conflicts of
interest that arise when providing investment service to an investment client to participate in a new issue, where the
investment firm receives commissions, fees or any monetary or non-monetary benefits in relation to arranging the
issuance. Any commissions, fees or monetary or non-monetary benefits shall comply with the requirements in
Article 24(7), 24(8) and 24(9) of Directive 2014/65/EU and be documented in the investment firm's conflicts of interest
policies and reflected in the firm's inducements arrangements.
2.
Investment firms engaging in the placement of financial instruments issued by themselves or by entities within the
same group, to their own clients, including their existing depositor clients in the case of credit institutions, or
investment funds managed by entities of their group, shall establish, implement and maintain clear and effective
arrangements for the identification, prevention or management of the potential conflicts of interest that arise in relation
to this type of activity. Such arrangements shall include consideration of refraining from engaging in the activity, where
conflicts of interest cannot be appropriately managed so as to prevent any adverse effects on clients.
3.
When disclosure of conflicts of interest is required, investment firms shall comply with the requirements in
Article 34(4), including an explanation of the nature and source of the conflicts of interest inherent to this type of
activity, providing details about the specific risks related to such practices in order to enable clients to make an informed
investment decision.
4.
Investment firms which offer financial instruments issued that are by themselves or other group entities to their
clients and that are included in the calculation of prudential requirements specified in Regulation (EU) No 575/2013 of
the European Parliament and of the Council (1), Directive 2013/36/EU of the European Parliament and of the Council (2)
or Directive 2014/59/EU of the European Parliament and of the Council (3), shall provide those clients with additional
information explaining the differences between the financial instrument and bank deposits in terms of yield, risk,
liquidity and any protection provided in accordance with Directive 2014/49/EU of the European Parliament and of the
Council (4).
Article 42
Additional requirements in relation to lending or provision of credit in the context of
underwriting or placement
(Articles 16(3), 23 and 24 of Directive 2014/65/EU)
1.
Where any previous lending or credit to the issuer client by an investment firm, or an entity within the same
group, may be repaid with the proceeds of an issue, the investment firm shall have arrangements in place to identify and
prevent or manage any conflicts of interest that may arise as a result.
2.
Where the arrangements taken to manage conflicts of interest prove insufficient to ensure that the risk of damage
to the issuer client would be prevented, investment firms shall disclose to the issuer client the specific conflicts of
interest that have arisen in relation to their, or group entities', activities in a capacity of credit provider, and their
activities related to the securities offering.
31.3.2017
L 87/41
Official Journal of the European Union
EN
(1) Regulation (EU) No 575/2013 of the European Parliament and of the Council of 26 June 2013 on prudential requirements for credit
institutions and investment firms and amending Regulation (EU) No 648/2012 (OJ L 176, 27.6.2013, p. 1).
(2) Directive 2013/36/EU of the European Parliament and of the Council of 26 June 2013 on access to the activity of credit institutions and
the prudential supervision of credit institutions and investment firms, amending Directive 2002/87/EC and repealing Directives
2006/48/EC and 2006/49/EC (OJ L 176, 27.6.2013, p. 338).
(3) Directive 2014/59/EU of the European Parliament and of the Council of 15 May 2014 establishing a framework for the recovery and
resolution of credit institutions and investment firms and amending Council Directive 82/891/EEC, and Directives 2001/24/EC,
2002/47/EC, 2004/25/EC, 2005/56/EC, 2007/36/EC, 2011/35/EU, 2012/30/EU and 2013/36/EU, and Regulations (EU)
No 1093/2010 and (EU) No 648/2012, of the European Parliament and of the Council (OJ L 173, 12.6.2014, p. 190).
(4) Directive 2014/49/EU of the European Parliament and of the Council of 16 April 2014 on deposit guarantee schemes (OJ L 173,
12.6.2014, p. 149).

<!-- source-page: 42 -->

3.
Investment firms' conflict of interest policy shall require the sharing of information about the issuer's financial
situation with group entities acting as credit providers, provided this would not breach information barriers set up by
the firm to protect the interests of a client.
Article 43
Record keeping in relation to underwriting or placing
(Articles 16(3), 23 and 24 of Directive 2014/65/EU)
Investment firms shall keep records of the content and timing of instructions received from clients. A record of the
allocation decisions taken for each operation shall be kept to provide for a complete audit trail between the movements
registered in clients' accounts and the instructions received by the investment firm. In particular, the final allocation
made to each investment client shall be clearly justified and recorded. The complete audit trail of the material steps in
the underwriting and placing process shall be made available to competent authorities upon request.
CHAPTER III
OPERATING CONDITIONS FOR INVESTMENT FIRMS
SECTION 1
Information to clients and potential clients
Article 44
Fair, clear and not misleading information requirements
(Article 24(3) of Directive 2014/65/EU)
1.
Investment firms shall ensure that all information they address to, or disseminate in such a way that it is likely to
be received by, retail or professional clients or potential retail or professional clients, including marketing communi­
cations, satisfies the conditions laid down in paragraphs 2 to 8.
2.
Investment firm shall ensure that the information referred to in paragraph 1 complies with the following
conditions:
(a)  the information includes the name of the investment firm,
(b)  the information is accurate and always gives a fair and prominent indication of any relevant risks when referencing
any potential benefits of an investment service or financial instrument,
(c)  the information uses a font size in the indication of relevant risks that is at least equal to the predominant font size
used throughout the information provided, as well as a layout ensuring such indication is prominent,
(d)  the information is sufficient for, and presented in a way that is likely to be understood by, the average member of
the group to whom it is directed, or by whom it is likely to be received,
(e)  the information does not disguise, diminish or obscure important items, statements or warnings,
(f)  the information is consistently presented in the same language throughout all forms of information and marketing
materials that are provided to each client, unless the client has accepted to receive information in more than one
language,
(g)  the information is up-to-date and relevant to the means of communication used.
3.
Where the information compares investment or ancillary services, financial instruments, or persons providing
investment or ancillary services, investment firms shall ensure that the following conditions are satisfied:
(a)  the comparison is meaningful and presented in a fair and balanced way;
(b)  the sources of the information used for the comparison are specified;
(c)  the key facts and assumptions used to make the comparison are included.
31.3.2017
L 87/42
Official Journal of the European Union
EN

<!-- source-page: 43 -->

4.
Where the information contains an indication of past performance of a financial instrument, a financial index or
an investment service, investment firms shall ensure that the following conditions are satisfied:
(a)  that indication is not the most prominent feature of the communication;
(b)  the information must include appropriate performance information which covers the preceding 5 years, or the
whole period for which the financial instrument has been offered, the financial index has been established, or the
investment service has been provided where less than five years, or such longer period as the firm may decide, and
in every case that performance information is based on complete 12-month periods;
(c)  the reference period and the source of information is clearly stated;
(d)  the information contains a prominent warning that the figures refer to the past and that past performance is not
a reliable indicator of future results;
(e)  where the indication relies on figures denominated in a currency other than that of the Member State in which the
retail client or potential retail client is resident, the currency is clearly stated, together with a warning that the return
may increase or decrease as a result of currency fluctuations;
(f)  where the indication is based on gross performance, the effect of commissions, fees or other charges are disclosed.
5.
Where the information includes or refers to simulated past performance, investment firms shall ensure that the
information relates to a financial instrument or a financial index, and the following conditions are satisfied:
(a)  the simulated past performance is based on the actual past performance of one or more financial instruments or
financial indices which are the same as, or substantially the same as, or underlie, the financial instrument concerned;
(b)  in respect of the actual past performance referred to in point (a), the conditions set out in points (a) to (c), (e) and (f)
of paragraph 4 are satisfied;
(c)  the information contains a prominent warning that the figures refer to simulated past performance and that past
performance is not a reliable indicator of future performance.
6.
Where the information contains information on future performance, investment firms shall ensure that the
following conditions are satisfied:
(a)  the information is not based on or refer to simulated past performance;
(b)  the information is based on reasonable assumptions supported by objective data;
(c)  where the information is based on gross performance, the effect of commissions, fees or other charges is disclosed;
(d)  the information is based on performance scenarios in different market conditions (both negative and positive
scenarios), and reflects the nature and risks of the specific types of instruments included in the analysis;
(e)  the information contains a prominent warning that such forecasts are not a reliable indicator of future performance.
7.
Where the information refers to a particular tax treatment, it shall prominently state that the tax treatment
depends on the individual circumstances of each client and may be subject to change in the future.
8.
The information shall not use the name of any competent authority in such a way that would indicate or suggest
endorsement or approval by that authority of the products or services of the investment firm.
Article 45
Information concerning client categorisation
(Article 24(4) of Directive 2014/65/EU)
1.
Investment firms shall notify new clients, and existing clients that the investment firm has newly categorised as
required by Directive 2014/65/EU, of their categorisation as a retail client, a professional client or an eligible
counterparty in accordance with that Directive.
31.3.2017
L 87/43
Official Journal of the European Union
EN

<!-- source-page: 44 -->

2.
Investment firms shall inform clients in a durable medium about any right that client has to request a different
categorisation and about any limitations to the level of client protection that a different categorisation would entail.
3.
Investment firms may, either on their own initiative or at the request of the client concerned treat a client in the
following manner:
(a)  as a professional or retail client where that client might otherwise be classified as an eligible counterparty pursuant
to Article 30(2) of Directive 2014/65/EU;
(b)  a retail client where that client that is considered a professional client pursuant to Section I of Annex II to Directive
2014/65/EU.
Article 46
General requirements for information to clients
(Article 24(4) of Directive 2014/65/EU)
1.
Investment firms shall, in good time before a client or potential client is bound by any agreement for the provision
of investment services or ancillary services or before the provision of those services, whichever is the earlier to provide
that client or potential client with the following information:
(a)  the terms of any such agreement;
(b)  the information required by Article 47 relating to that agreement or to those investment or ancillary services.
2.
Investment firms shall, in good time before the provision of investment services or ancillary services to clients or
potential clients, to provide the information required under Articles 47 to 50.
3.
The information referred to in paragraphs 1 and 2 shall be provided in a durable medium or by means of
a website (where it does not constitute a durable medium) provided that the conditions specified in Article 3(2) are
satisfied.
4.
Investment firms shall notify a client in good time about any material change to the information provided under
Articles 47 to 50 which is relevant to a service that the firm is providing to that client. That notification shall be given
in a durable medium if the information to which it relates is given in a durable medium.
5.
Investment firms shall ensure that information contained in a marketing communication is consistent with any
information the firm provides to clients in the course of carrying on investment and ancillary services.
6.
Marketing communications containing an offer or invitation of the following nature and specifying the manner of
response or including a form by which any response may be made, shall include such of the information referred to in
Articles 47 to 50 as is relevant to that offer or invitation:
(a)  an offer to enter into an agreement in relation to a financial instrument or investment service or ancillary service
with any person who responds to the communication;
(b)  an invitation to any person who responds to the communication to make an offer to enter into an agreement in
relation to a financial instrument or investment service or ancillary service.
However, the first subparagraph shall not apply if, in order to respond to an offer or invitation contained in the
marketing communication, the potential client must refer to another document or documents, which, alone or in
combination, contain that information.
Article 47
Information about the investment firm and its services for clients and potential clients
(Article 24(4) of Directive 2014/65/EU)
1.
Investment firms shall provide clients or potential clients with the following general information, where relevant:
(a)  the name and address of the investment firm, and the contact details necessary to enable clients to communicate
effectively with the firm;
(b)  the languages in which the client may communicate with the investment firm, and receive documents and other
information from the firm;
31.3.2017
L 87/44
Official Journal of the European Union
EN

<!-- source-page: 45 -->

(c)  the methods of communication to be used between the investment firm and the client including, where relevant,
those for the sending and reception of orders;
(d)  a statement of the fact that the investment firm is authorised and the name and contact address of the competent
authority that has authorised it;
(e)  where the investment firm is acting through a tied agent, a statement of this fact specifying the Member State in
which that agent is registered;
(f)  the nature, frequency and timing of the reports on the performance of the service to be provided by the investment
firm to the client in accordance with Article 25(6) of Directive 2014/65/EU;
(g)  where the investment firm holds client financial instruments or client funds, a summary description of the steps
which it takes to ensure their protection, including summary details of any relevant investor compensation or
deposit guarantee scheme which applies to the firm by virtue of its activities in a Member State;
(h)  a description, which may be provided in summary form, of the conflicts of interest policy maintained by the firm in
accordance with Article 34;
(i)  at the request of the client, further details of that conflicts of interest policy in a durable medium or by means of
a website (where that does not constitute a durable medium) provided that the conditions set out Article 3(2) are
satisfied.
The information listed in points (a) to (i) shall be provided in good time before the provision of investment services or
ancillary services to clients or potential clients.
2.
When providing the service of portfolio management, investment firms shall establish an appropriate method of
evaluation and comparison such as a meaningful benchmark, based on the investment objectives of the client and the
types of financial instruments included in the client portfolio, so as to enable the client for whom the service is provided
to assess the firm's performance.
3.
Where investment firms propose to provide portfolio management services to a client or potential client, they
shall provide the client, in addition to the information required under paragraph 1, with such of the following
information as is applicable:
(a)  information on the method and frequency of valuation of the financial instruments in the client portfolio;
(b)  details of any delegation of the discretionary management of all or part of the financial instruments or funds in the
client portfolio;
(c)  a specification of any benchmark against which the performance of the client portfolio will be compared;
(d)  the types of financial instrument that may be included in the client portfolio and types of transaction that may be
carried out in such instruments, including any limits;
(e)  the management objectives, the level of risk to be reflected in the manager's exercise of discretion, and any specific
constraints on that discretion.
The information listed in points (a) to (e) shall be provided in good time before the provision of investment services or
ancillary services to clients or potential clients.
Article 48
Information about financial instruments
(Article 24(4) of Directive 2014/65/EU)
1.
Investment firms shall provide clients or potential clients in good time before the provision of investment services
or ancillary services to clients or potential clients with a general description of the nature and risks of financial
instruments, taking into account, in particular, the client's categorisation as either a retail client, professional client or
eligible counterparty. That description shall explain the nature of the specific type of instrument concerned, the
functioning and performance of the financial instrument in different market conditions, including both positive and
negative conditions, as well as the risks particular to that specific type of instrument in sufficient detail to enable the
client to take investment decisions on an informed basis.
31.3.2017
L 87/45
Official Journal of the European Union
EN

<!-- source-page: 46 -->

2.
The description of risks referred to in paragraph 1 shall include, where relevant to the specific type of instrument
concerned and the status and level of knowledge of the client, the following elements:
(a)  the risks associated with that type of financial instrument including an explanation of leverage and its effects and the
risk of losing the entire investment including the risks associated with insolvency of the issuer or related events,
such as bail in;
(b)  the volatility of the price of such instruments and any limitations on the available market for such instruments;
(c)  information on impediments or restrictions for disinvestment, for example as may be the case for illiquid financial
instruments or financial instruments with a fixed investment term, including an illustration of the possible exit
methods and consequences of any exit, possible constraints and the estimated time frame for the sale of the financial
instrument before recovering the initial costs of the transaction in that type of financial instruments;
(d)  the fact that an investor might assume, as a result of transactions in such instruments, financial commitments and
other additional obligations, including contingent liabilities, additional to the cost of acquiring the instruments;
(e)  any margin requirements or similar obligations, applicable to instruments of that type.
3.
Where an investment firm provides a retail client or potential retail client with information about a financial
instrument that is the subject of a current offer to the public and a prospectus has been published in connection with
that offer in accordance with Directive 2003/71/EC, that firm shall in good time before the provision of investment
services or ancillary services to clients or potential clients inform the client or potential client where that prospectus is
made available to the public.
4.
Where a financial instrument is composed of two or more different financial instruments or services, the
investment firm shall provide an adequate description of the legal nature of the financial instrument, the components of
that instrument and the way in which the interaction between the components affects the risks of the investment.
5.
In the case of financial instruments that incorporate a guarantee or capital protection, the investment firm shall
provide a client or a potential client with information about the scope and nature of such guarantee or capital
protection. When the guarantee is provided by a third party, information about the guarantee shall include sufficient
detail about the guarantor and the guarantee to enable the client or potential client to make a fair assessment of the
guarantee.
Article 49
Information concerning safeguarding of client financial instruments or client funds
(Article 24(4) of Directive 2014/65/EU)
1.
Investment firms holding financial instruments or funds belonging to clients shall provide those clients or
potential clients with the information specified in paragraphs 2 to 7 where relevant.
2.
The investment firm shall inform the client or potential client where the financial instruments or funds of that
client may be held by a third party on behalf of the investment firm and of the responsibility of the investment firm
under the applicable national law for any acts or omissions of the third party and the consequences for the client of the
insolvency of the third party.
3.
Where financial instruments of the client or potential client may, if permitted by national law, be held in an
omnibus account by a third party, the investment firm shall inform the client of this fact and shall provide a prominent
warning of the resulting risks.
4.
The investment firm shall inform the client or potential client where it is not possible under national law for client
financial instruments held with a third party to be separately identifiable from the proprietary financial instruments of
that third party or of the investment firm and shall provide a prominent warning of the resulting risks.
5.
The investment firm shall inform the client or potential client where accounts that contain financial instruments
or funds belonging to that client or potential client are or will be subject to the law of a jurisdiction other than that of
a Member State and shall indicate that the rights of the client or potential client relating to those financial instruments
or funds may differ accordingly.
31.3.2017
L 87/46
Official Journal of the European Union
EN

<!-- source-page: 47 -->

6.
An investment firm shall inform the client about the existence and the terms of any security interest or lien which
the firm has or may have over the client's financial instruments or funds, or any right of set-off it holds in relation to
those instruments or funds. Where applicable, it shall also inform the client of the fact that a depository may have
a security interest or lien over, or right of set-off in relation to those instruments or funds.
7.
An investment firm, before entering into securities financing transactions in relation to financial instruments held
by it on behalf of a client, or before otherwise using such financial instruments for its own account or the account of
another client shall in good time before the use of those instruments provide the client, in a durable medium, with clear,
full and accurate information on the obligations and responsibilities of the investment firm with respect to the use of
those financial instruments, including the terms for their restitution, and on the risks involved.
Article 50
Information on costs and associated charges
(Article 24(4) of Directive 2014/65/EU)
1.
For the purposes of providing information to clients on all costs and charges pursuant to Article 24(4) of Directive
2014/65/EU, investment firms shall comply with the detailed requirements in paragraphs 2 to 10.
Without prejudice to the obligations set out in Article 24(4) of Directive 2014/65/EU, investment firms providing
investment services to professional clients shall have the right to agree to a limited application of the detailed
requirements set out in this Article with these clients. Investment firms shall not be allowed to agree such limitations
when the services of investment advice or portfolio management are provided or when, irrespective of the investment
service provided, the financial instruments concerned embed a derivative.
Without prejudice to the obligations set out in Article 24(4) of Directive 2014/65/EU, investment firms providing
investment services to eligible counterparties shall have the right to agree to a limited application of the detailed
requirements set out in this Article, except when, irrespective of the investment service provided, the financial
instruments concerned embed a derivative and the eligible counterparty intends to offer them to its clients.
2.
For ex-ante and ex-post disclosure of information on costs and charges to clients, investment firms shall aggregate
the following:
(a)  all costs and associated charges charged by the investment firm or other parties where the client has been directed to
such other parties, for the investment services(s) and/or ancillary services provided to the client; and
(b)  all costs and associated charges associated with the manufacturing and managing of the financial instruments.
Costs referred to in points (a) and (b) are listed in Annex II to this Regulation. For the purposes of point (a), third party
payments received by investment firms in connection with the investment service provided to a client shall be itemised
separately and the aggregated costs and charges shall be totalled and expressed both as a cash amount and as
a percentage.
3.
Where any part of the total costs and charges is to be paid in or represents an amount of foreign currency,
investment firms shall provide an indication of the currency involved and the applicable currency conversion rates and
costs. Investments firms shall also inform about the arrangements for payment or other performance.
4.
In relation to the disclosure of product costs and charges that are not included in the UCITS KIID, the investment
firms shall calculate and disclose these costs, for example, by liaising with UCITS management companies to obtain the
relevant information.
5.
The obligation to provide in good time a full ex-ante disclosure of information about the aggregated costs and
charges related to the financial instrument and to the investment or ancillary service provided shall apply to investment
firms in the following situations:
(a)  where the investment firm recommends or markets financial instruments to clients; or
31.3.2017
L 87/47
Official Journal of the European Union
EN

<!-- source-page: 48 -->

(b)  where the investment firm providing any investment services is required to provide clients with a UCITS KIID or
PRIIPs KID in relation to the relevant financial instruments, in accordance with relevant Union legislation.
6.
Investment firms that do not recommend or market a financial instrument to the client or are not obliged to
provide the client with a KID/KIID in accordance with relevant Union legislation shall inform their clients about all costs
and charges relating to the investment and/or ancillary service provided.
7.
Where more than one investment firm provides investment or ancillary services to the client, each investment firm
shall provide information about the costs of the investment or ancillary services it provides. An investment firm that
recommends or markets to its clients the services provided by another firm, shall aggregate the cost and charges of its
services together with the cost and charges of the services provided by the other firm. An investment firm shall take
into account the costs and charges associated to the provision of other investment or ancillary services by other firms
where it has directed the client to these other firms.
8.
Where calculating costs and charges on an ex-ante basis, investment firms shall use actually incurred costs as
a proxy for the expected costs and charges. Where actual costs are not available, the investment firm shall make
reasonable estimations of these costs. Investment firms shall review ex-ante assumptions based on the ex-post
experience and shall make adjustment to these assumptions, where necessary.
9.
Investment firms shall provide annual ex-post information about all costs and charges related to both the financial
instrument(s) and investment and ancillary service(s) where they have recommended or marketed the financial
instrument(s) or where they have provided the client with the KID/KIID in relation to the financial instrument(s) and
they have or have had an ongoing relationship with the client during the year. Such information shall be based on costs
incurred and shall be provided on a personalised basis.
Investment firms may choose to provide such aggregated information on costs and charges of the investment services
and the financial instruments together with any existing periodic reporting to clients.
10.
Investment firms shall provide their clients with an illustration showing the cumulative effect of costs on return
when providing investment services. Such an illustration shall be provided both on an ex-ante and ex-post basis.
Investment firms shall ensure that the illustration meets the following requirements:
(a)  the illustration shows the effect of the overall costs and charges on the return of the investment;
(b)  the illustration shows any anticipated spikes or fluctuations in the costs; and
(c)  the illustration is accompanied by a description of the illustration.
Article 51
Information provided in accordance with Directive 2009/65/EU and Regulation (EU) No 1286/2014
(Article 24(4) of Directive 2014/65/EU)
Investment firms distributing units in collective investment undertakings or PRIIPs shall additionally inform their clients
about any other costs and associated charges related to the product which may have not been included in the UCITS
KID or PRIIPs KID and about the costs and charges relating to their provision of investment services in relation to that
financial instrument.
SECTION 2
Investment advice
Article 52
Information about investment advice
(Article 24(4) of Directive 2014/65/EU)
1.
Investment firms shall explain in a clear and concise way whether and why investment advice qualifies as
independent or non-independent and the type and nature of the restrictions that apply, including, when providing
investment advice on an independent basis, the prohibition to receive and retain inducements.
31.3.2017
L 87/48
Official Journal of the European Union
EN

<!-- source-page: 49 -->

Where advice is offered or provided to the same client on both an independent and non-independent basis, investment
firms shall explain the scope of both services to allow investors to understand the differences between them and not
present itself f as an independent investment adviser for the overall activity. Firms shall not give undue prominence to
their independent investment advice services over non-independent investment services in their communications with
clients.
2.
Investment firms providing investment advice, on an independent or non-independent basis, shall explain to the
client the range of financial instruments that may be recommended, including the firm's relationship with the issuers or
providers of the instruments.
3.
Investment firms shall provide a description of the types of financial instruments considered, the range of financial
instruments and providers analysed per each type of instrument according to the scope of the service, and, when
providing independent advice, how the service provided satisfies the conditions for the provision of investment advice
on an independent basis and the factors taken into consideration in the selection process used by the investment firm to
recommend financial instruments, such as risks, costs and complexity of the financial instruments.
4.
When the range of financial instruments assessed by the investment firm providing investment advice on an
independent basis includes the investment firm's own financial instruments or those issued or provided by entities
having close links or any other close legal or economic relationship with the investment firm as well as other issuers or
providers which are not linked or related, the investment firm shall distinguish, for each type of financial instrument, the
range of the financial instruments issued or provided by entities not having any links with the investment firm.
5.
Investments firms providing a periodic assessment of the suitability of the recommendations provided pursuant to
Article 54(12) shall disclose all of the following:
(a)  the frequency and extent of the periodic suitability assessment and where relevant, the conditions that trigger that
assessment;
(b)  the extent to which the information previously collected will be subject to reassessment; and
(c)  the way in which an updated recommendation will be communicated to the client.
Article 53
Investment advice on an independent basis
(Article 24(4) and 24(7) of Directive 2014/65/EU)
1.
Investment firms providing investment advice on an independent basis shall define and implement a selection
process to assess and compare a sufficient range of financial instruments available on the market in accordance with
Article 24(7)(a) of Directive 2014/65/EU. The selection process shall include the following elements:
(a)  the number and variety of financial instruments considered is proportionate to the scope of investment advice
services offered by the independent investment adviser;
(b)  the number and variety of financial instruments considered is adequately representative of financial instruments
available on the market;
(c)  the quantity of financial instruments issued by the investment firm itself or by entities closely linked to the
investment firm itself is proportionate to the total amount of financial instruments considered; and
(d)  the criteria for selecting the various financial instruments shall include all relevant aspects such as risks, costs and
complexity as well as the characteristics of the investment firm's clients, and shall ensure that the selection of the
instruments that may be recommended is not biased.
Where such a comparison is not possible due to the business model or the specific scope of the service provided, the
investment firm providing investment advice shall not present itself as independent.
2.
An investment firm that provides investment advice on an independent basis and that focuses on certain categories
or a specified range of financial instruments shall comply with the following requirements:
(a)  the firm shall market itself in a way that is intended only to attract clients with a preference for those categories or
range of financial instruments;
31.3.2017
L 87/49
Official Journal of the European Union
EN

<!-- source-page: 50 -->

(b)  the firm shall require clients to indicate that they are only interested in investing in the specified category or range
of financial instruments; and
(c)  prior to the provision of the service, the firm shall ensure that its service is appropriate for each new client on the
basis that its business model matches the client's needs and objectives, and the range of financial instruments that
are suitable for the client. Where this is not the case the firm shall not provide such a service to the client.
3.
An investment firm offering investment advice on both an independent basis and on a non-independent basis shall
comply with the following obligations:
(a)  in good time before the provision of its services, the investment firm has informed its clients, in a durable medium,
whether the advice will be independent or non-independent in accordance with Article 24(4)(a) of Directive
2014/65/EU and the relevant implementing measures;
(b)  the investment firm has presented itself as independent for the services for which it provides investment advice on
an independent basis;
(c)  the investment firms has adequate organisational requirements and controls in place to ensure that both types of
advice services and advisers are clearly separated from each other and that clients are not likely to be confused about
the type of advice that they are receiving and are given the type of advice that is appropriate for them. The
investment firm shall not allow a natural person to provide both independent and non-independent advice.
SECTION 3
Assessment of suitability and appropriateness
Article 54
Assessment of suitability and suitability reports
(Article 25(2) of Directive 2014/65/EU)
1.
Investment firms shall not create any ambiguity or confusion about their responsibilities in the process when
assessing the suitability of investment services or financial instruments in accordance with Article 25(2) of Directive
2014/65/EU. When undertaking the suitability assessment, the firm shall inform clients or potential clients, clearly and
simply, that the reason for assessing suitability is to enable the firm to act in the client's best interest.
Where investment advice or portfolio management services are provided in whole or in part through an automated or
semi-automated system, the responsibility to undertake the suitability assessment shall lie with the investment firm
providing the service and shall not be reduced by the use of an electronic system in making the personal recommen­
dation or decision to trade.
2.
Investment firms shall determine the extent of the information to be collected from clients in light of all the
features of the investment advice or portfolio management services to be provided to those clients. Investment firms
shall obtain from clients or potential clients such information as is necessary for the firm to understand the essential
facts about the client and to have a reasonable basis for determining, giving due consideration to the nature and extent
of the service provided, that the specific transaction to be recommended, or entered into in the course of providing
a portfolio management service, satisfies the following criteria:
(a)  it meets the investment objectives of the client in question, including client's risk tolerance;
(b)  it is such that the client is able financially to bear any related investment risks consistent with his investment
objectives;
(c)  it is such that the client has the necessary experience and knowledge in order to understand the risks involved in the
transaction or in the management of his portfolio.
3.
Where an investment firm provides an investment service to a professional client it shall be entitled to assume that
in relation to the products, transactions and services for which it is so classified, the client has the necessary level of
experience and knowledge for the purposes of point (c) of paragraph 2.
Where that investment service consists in the provision of investment advice to a professional client covered by
Section 1 of Annex II to Directive 2014/65/EU, the investment firm shall be entitled to assume for the purposes of
point (b) of paragraph 2 that the client is able financially to bear any related investment risks consistent with the
investment objectives of that client.
31.3.2017
L 87/50
Official Journal of the European Union
EN

<!-- source-page: 51 -->

4.
The information regarding the financial situation of the client or potential client shall include, where relevant,
information on the source and extent of his regular income, his assets, including liquid assets, investments and real
property, and his regular financial commitments.
5.
The information regarding the investment objectives of the client or potential client shall include, where relevant,
information on the length of time for which the client wishes to hold the investment, his preferences regarding risk
taking, his risk profile, and the purposes of the investment.
6.
Where a client is a legal person or a group of two or more natural persons or where one or more natural persons
are represented by another natural person, the investment firm shall establish and implement policy as to who should
be subject to the suitability assessment and how this assessment will be done in practice, including from whom
information about knowledge and experience, financial situation and investment objectives should be collected. The
investment firm shall record this policy.
Where a natural person is represented by another natural person or where a legal person having requested treatment as
professional client in accordance with Section 2 of Annex II to Directive 2014/65/EU is to be considered for the
suitability assessment, the financial situation and investment objectives shall be those of the legal person or, in relation
to the natural person, the underlying client rather than of the representative. The knowledge and experience shall be that
of the representative of the natural person or the person authorised to carry out transactions on behalf of the
underlying client.
7.
Investment firms shall take reasonable steps to ensure that the information collected about their clients or
potential clients is reliable. This shall include, but shall not be limited to, the following:
(a)  ensuring clients are aware of the importance of providing accurate and up-to-date information;
(b)  ensuring all tools, such as risk assessment profiling tools or tools to assess a client's knowledge and experience,
employed in the suitability assessment process are fit-for-purpose and are appropriately designed for use with their
clients, with any limitations identified and actively mitigated through the suitability assessment process;
(c)  ensuring questions used in the process are likely to be understood by clients, capture an accurate reflection of the
client's objectives and needs, and the information necessary to undertake the suitability assessment; and
(d)  taking steps, as appropriate, to ensure the consistency of client information, such as by considering whether there
are obvious inaccuracies in the information provided by clients.
Investment firms having an on-going relationship with the client, such as by providing an ongoing advice or portfolio
management service, shall have, and be able to demonstrate, appropriate policies and procedures to maintain adequate
and up-to-date information about clients to the extent necessary to fulfil the requirements under paragraph 2.
8.
Where, when providing the investment service of investment advice or portfolio management, an investment firm
does not obtain the information required under Article 25(2) of Directive 2014/65/EU, the firm shall not recommend
investment services or financial instruments to the client or potential client.
9.
Investment firms shall have, and be able to demonstrate, adequate policies and procedures in place to ensure that
they understand the nature, features, including costs and risks of investment services and financial instruments selected
for their clients and that they assess, while taking into account cost and complexity, whether equivalent investment
services or financial instruments can meet their client's profile.
10.
When providing the investment service of investment advice or portfolio management, an investment firm shall
not recommend or decide to trade where none of the services or instruments are suitable for the client.
11.
When providing investment advice or portfolio management services that involve switching investments, either
by selling an instrument and buying another or by exercising a right to make a change in regard to an existing
instrument, investment firms shall collect the necessary information on the client's existing investments and the
recommended new investments and shall undertake an analysis of the costs and benefits of the switch, such that they
are reasonably able to demonstrate that the benefits of switching are greater than the costs.
31.3.2017
L 87/51
Official Journal of the European Union
EN

<!-- source-page: 52 -->

12.
When providing investment advice, investment firms shall provide a report to the retail client that includes an
outline of the advice given and how the recommendation provided is suitable for the retail client, including how it
meets the client's objectives and personal circumstances with reference to the investment term required, client's
knowledge and experience and client's attitude to risk and capacity for loss.
Investment firms shall draw clients' attention to and shall include in the suitability report information on whether the
recommended services or instruments are likely to require the retail client to seek a periodic review of their
arrangements.
Where an investment firm provides a service that involves periodic suitability assessments and reports, the subsequent
reports after the initial service is established may only cover changes in the services or instruments involved and/or the
circumstances of the client and may not need to repeat all the details of the first report.
13.
Investment firms providing a periodic suitability assessment shall review, in order to enhance the service, the
suitability of the recommendations given at least annually. The frequency of this assessment shall be increased
depending on the risk profile of the client and the type of financial instruments recommended.
Article 55
Provisions common to the assessment of suitability or appropriateness
(Article 25(2) and 25(3) of Directive 2014/65/EU)
1.
Investment firms shall ensure that the information regarding a client's or potential client's knowledge and
experience in the investment field includes the following, to the extent appropriate to the nature of the client, the nature
and extent of the service to be provided and the type of product or transaction envisaged, including their complexity
and the risks involved:
(a)  the types of service, transaction and financial instrument with which the client is familiar;
(b)  the nature, volume, and frequency of the client's transactions in financial instruments and the period over which
they have been carried out;
(c)  the level of education, and profession or relevant former profession of the client or potential client.
2.
An investment firm shall not discourage a client or potential client from providing information required for the
purposes of Article 25(2) and (3) of Directive 2014/65/EU.
3.
An investment firm shall be entitled to rely on the information provided by its clients or potential clients unless it
is aware or ought to be aware that the information is manifestly out of date, inaccurate or incomplete.
Article 56
Assessment of appropriateness and related record-keeping obligations
(Article 25(3) and 25(5) of Directive 2014/65/EU)
1.
Investment firms, shall determine whether that client has the necessary experience and knowledge in order to
understand the risks involved in relation to the product or investment service offered or demanded when assessing
whether an investment service as referred to in Article 25(3) of Directive 2014/65/EU is appropriate for a client.
An investment firm shall be entitled to assume that a professional client has the necessary experience and knowledge in
order to understand the risks involved in relation to those particular investment services or transactions, or types of
transaction or product, for which the client is classified as a professional client.
2.
Investment firms shall maintain records of the appropriateness assessments undertaken which shall include the
following:
(a)  the result of the appropriateness assessment;
31.3.2017
L 87/52
Official Journal of the European Union
EN

<!-- source-page: 53 -->

(b)  any warning given to the client where the investment service or product purchase was assessed as potentially
inappropriate for the client, whether the client asked to proceed with the transaction despite the warning and, where
applicable, whether the firm accepted the client's request to proceed with the transaction;
(c)  any warning given to the client where the client did not provide sufficient information to enable the firm to
undertake an appropriateness assessment, whether the client asked to proceed with the transaction despite this
warning and, where applicable, whether the firm accepted the client's request to proceed with the transaction.
Article 57
Provision of services in non-complex instruments
(Article 25(4) of Directive 2014/65/EU)
A financial instrument which is not explicitly specified in Article 25(4)(a) of Directive 2014/65/EU shall be considered
as non-complex for the purposes of Article 25(4)(a)(vi) of Directive 2014/65/EU if it satisfies the following criteria:
(a)  it does not fall within Article 4(1)(44)(c) of, or points (4) to (11) of Section C of Annex I to Directive 2014/65/EU;
(b)  there are frequent opportunities to dispose of, redeem, or otherwise realise that instrument at prices that are
publicly available to market participants and that are either market prices or prices made available, or validated, by
valuation systems independent of the issuer;
(c)  it does not involve any actual or potential liability for the client that exceeds the cost of acquiring the instrument;
(d)  it does not incorporate a clause, condition or trigger that could fundamentally alter the nature or risk of the
investment or pay out profile, such as investments that incorporate a right to convert the instrument into a different
investment;
(e)  it does not include any explicit or implicit exit charges that have the effect of making the investment illiquid even
though there are technically frequent opportunities to dispose of, redeem or otherwise realise it;
(f)  adequately comprehensive information on its characteristics is publicly available and is likely to be readily
understood so as to enable the average retail client to make an informed judgment as to whether to enter into
a transaction in that instrument.
Article 58
Retail and Professional Client agreements
(Article 24(1) and 25(5) of Directive 2014/65/EU)
Investment firms providing any investment service or the ancillary service referred to in Section B(1) of Annex I to
Directive 2014/65/EU to a client after the date of application of this Regulation shall enter into a written basic
agreement with the client, in paper or another durable medium, with the client setting out the essential rights and
obligations of the firm and the client. Investment firms providing investment advice shall comply with this obligation
only where a periodic assessment of the suitability of the financial instruments or services recommended is performed.
The written agreement shall set out the essential rights and obligations of the parties, and shall include the following:
(a)  a description of the services, and where relevant the nature and extent of the investment advice, to be provided;
(b)  in case of portfolio management services, the types of financial instruments that may be purchased and sold and the
types of transactions that may be undertaken on behalf of the client, as well as any instruments or transactions
prohibited; and
(c)  a description of the main features of any services referred to in Section B(1) of Annex I to Directive 2014/65/EU to
be provided, including where applicable the role of the firm with respect to corporate actions relating to client
instruments and the terms on which securities financing transactions involving client securities will generate a return
for the client.
31.3.2017
L 87/53
Official Journal of the European Union
EN

<!-- source-page: 54 -->

SECTION 4
Reporting to clients
Article 59
Reporting obligations in respect of execution of orders other than for portfolio management
(Article 25(6) of Directive 2014/65/EU)
1.
Investment firms having carried out an order on behalf of a client, other than for portfolio management, shall, in
respect of that order:
(a)  promptly provide the client, in a durable medium, with the essential information concerning the execution of that
order;
(b)  send a notice to the client in a durable medium confirming execution of the order as soon as possible and no later
than the first business day following execution or, where the confirmation is received by the investment firm from
a third party, no later than the first business day following receipt of the confirmation from the third party.
Point (b) shall not apply where the confirmation would contain the same information as a confirmation that is to be
promptly dispatched to the client by another person.
Points (a) and (b) shall not apply where orders executed on behalf of clients relate to bonds funding mortgage loan
agreements with the said clients, in which case the report on the transaction shall be made at the same time as the
terms of the mortgage loan are communicated, but no later than one month after the execution of the order.
2.
In addition to the requirements under paragraph 1, investment firms shall supply the client, on request, with
information about the status of his order.
3.
In the case of client orders relating to units or shares in a collective investment undertaking which are executed
periodically, investment firms shall either take the action specified in point (b) of paragraph 1 or provide the client, at
least once every six months, with the information listed in paragraph 4 in respect of those transactions.
4.
The notice referred to in point (b) of paragraph 1 shall include such of the following information as is applicable
and, where relevant, in accordance with the regulatory technical standards on reporting obligations adopted in
accordance with Article 26 of Regulation (EU) No 600/2014:
(a)  the reporting firm identification;
(b)  the name or other designation of the client;
(c)  the trading day;
(d)  the trading time;
(e)  the type of the order;
(f)  the venue identification;
(g)  the instrument identification;
(h)  the buy/sell indicator;
(i)  the nature of the order if other than buy/sell;
(j)  the quantity;
(k)  the unit price;
(l)  the total consideration;
(m)  a total sum of the commissions and expenses charged and, where the client so requests, an itemised breakdown
including, where relevant, the amount of any mark-up or mark-down imposed where the transaction was executed
by an investment firm when dealing on own account, and the investment firm owes a duty of best execution to the
client;
31.3.2017
L 87/54
Official Journal of the European Union
EN

<!-- source-page: 55 -->

(n)  the rate of exchange obtained where the transaction involves a conversion of currency;
(o)  the client's responsibilities in relation to the settlement of the transaction, including the time limit for payment or
delivery as well as the appropriate account details where these details and responsibilities have not previously been
notified to the client;
(p)  where the client's counterparty was the investment firm itself or any person in the investment firm's group or
another client of the investment firm, the fact that this was the case unless the order was executed through
a trading system that facilitates anonymous trading.
For the purposes of point (k), where the order is executed in tranches, the investment firm may supply the client with
information about the price of each tranche or the average price. Where the average price is provided, the investment
firm shall supply the client with information about the price of each tranche upon request.
5.
The investment firm may provide the client with the information referred to in paragraph 4 using standard codes
if it also provides an explanation of the codes used.
Article 60
Reporting obligations in respect of portfolio management
(Article 25(6) of Directive 2014/65/EU)
1.
Investments firms which provide the service of portfolio management to clients shall provide each such client with
a periodic statement in a durable medium of the portfolio management activities carried out on behalf of that client
unless such a statement is provided by another person.
2.
The periodic statement required under paragraph 1 shall provide a fair and balanced review of the activities
undertaken and of the performance of the portfolio during the reporting period and shall include, where relevant, the
following information:
(a)  the name of the investment firm;
(b)  the name or other designation of the client's account;
(c)  a statement of the contents and the valuation of the portfolio, including details of each financial instrument held, its
market value, or fair value if market value is unavailable and the cash balance at the beginning and at the end of the
reporting period, and the performance of the portfolio during the reporting period;
(d)  the total amount of fees and charges incurred during the reporting period, itemising at least total management fees
and total costs associated with execution, and including, where relevant, a statement that a more detailed breakdown
will be provided on request;
(e)  a comparison of performance during the period covered by the statement with the investment performance
benchmark (if any) agreed between the investment firm and the client;
(f)  the total amount of dividends, interest and other payments received during the reporting period in relation to the
client's portfolio;
(g)  information about other corporate actions giving rights in relation to financial instruments held in the portfolio;
(h)  for each transaction executed during the period, the information referred to in Article 59(4)(c) to (l) where relevant,
unless the client elects to receive information about executed transactions on a transaction-by-transaction basis, in
which case paragraph 4 of this Article shall apply.
3.
The periodic statement referred to in paragraph 1 shall be provided once every three months, except in the
following cases:
(a)  where the investment firm provides its clients with access to an online system, which qualifies as a durable medium,
where up-to-date valuations of the client's portfolio can be accessed and where the client can easily access the
information required by Article 63(2) and the firm has evidence that the client has accessed a valuation of their
portfolio at least once during the relevant quarter;
31.3.2017
L 87/55
Official Journal of the European Union
EN

<!-- source-page: 56 -->

(b)  in cases where paragraph 4 applies, the periodic statement must be provided at least once every 12 months;
(c)  where the agreement between an investment firm and a client for a portfolio management service authorises
a leveraged portfolio, the periodic statement must be provided at least once a month.
The exception provided for in point (b) shall not apply in the case of transactions in financial instruments covered by
Article 4(1)(44)(c) of, or any of points 4 to 11 of Section C in Annex I to Directive 2014/65/EU.
4.
Investment firms, in cases where the client elects to receive information about executed transactions on
a transaction-by-transaction basis, shall provide promptly to the client, on the execution of a transaction by the portfolio
manager, the essential information concerning that transaction in a durable medium.
The investment firm shall send the client a notice confirming the transaction and containing the information referred to
in Article 59(4) no later than the first business day following that execution or, where the confirmation is received by
the investment firm from a third party, no later than the first business day following receipt of the confirmation from
the third party.
The second subparagraph shall not apply where the confirmation would contain the same information as
a confirmation that is to be promptly dispatched to the client by another person.
Article 61
Reporting obligations in respect of eligible counterparties
(Article 24(4) and Article 25(6) of Directive 2014/65/EU)
The requirements applicable to reports for retail and professional clients under Articles 49 and 59 shall apply unless
investment firms enter into agreements with eligible counterparties to determine content and timing of reporting.
Article 62
Additional reporting obligations for portfolio management or contingent liability transactions
(Article 25(6) of Directive 2014/65/EU)
1.
Investment firms providing the service of portfolio management shall inform the client where the overall value of
the portfolio, as evaluated at the beginning of each reporting period, depreciates by 10 % and thereafter at multiples of
10 %, no later than the end of the business day in which the threshold is exceeded or, in a case where the threshold is
exceeded on a non-business day, the close of the next business day.
2.
Investment firms that hold a retail client account that includes positions in leveraged financial instruments or
contingent liability transactions shall inform the client, where the initial value of each instrument depreciates by 10 %
and thereafter at multiples of 10 %. Reporting under this paragraph should be on an instrument-by-instrument basis,
unless otherwise agreed with the client, and shall take place no later than the end of the business day in which the
threshold is exceeded or, in a case where the threshold is exceeded on a non-business day, the close of the next business
day.
Article 63
Statements of client financial instruments or client funds
(Article 25(6) of Directive 2014/65/EU)
1.
Investment firms that hold client financial instruments or client funds shall send at least on a quarterly basis, to
each client for whom they hold financial instruments or funds, a statement in a durable medium of those financial
instruments or funds unless such a statement has been provided in any other periodic statement. Upon client request,
firms shall provide such statement more frequently at a commercial cost.
The first subparagraph shall not apply to a credit institution authorised under Directive 2000/12/EC of the European
Parliament and of the Council (1) in respect of deposits within the meaning of that Directive held by that institution.
31.3.2017
L 87/56
Official Journal of the European Union
EN
(1) Directive 2000/12/EC of the European Parliament and of the Council of 20 March 2000 relating to the taking up and pursuit of the
business of credit institutions (OJ L 126, 26.5.2000, p. 1).

<!-- source-page: 57 -->

2.
The statement of client assets referred to in paragraph 1 shall include the following information:
(a)  details of all the financial instruments or funds held by the investment firm for the client at the end of the period
covered by the statement;
(b)  the extent to which any client financial instruments or client funds have been the subject of securities financing
transactions;
(c)  the extent of any benefit that has accrued to the client by virtue of participation in any securities financing
transactions, and the basis on which that benefit has accrued;
(d)  a clear indication of the assets or funds which are subject to the rules of Directive 2014/65/EU and its implementing
measures and those that are not, such as those that are subject to Title Transfer Collateral Agreement;
(e)  a clear indication of which assets are affected by some peculiarities in their ownership status, for instance due to
a security interest;
(f)  the market or estimated value, when the market value is not available, of the financial instruments included in the
statement with a clear indication of the fact that the absence of a market price is likely to be indicative of a lack of
liquidity. The evaluation of the estimated value shall be performed by the firm on a best effort basis.
In cases where the portfolio of a client includes the proceeds of one or more unsettled transactions, the information
referred to in point (a) may be based either on the trade date or the settlement date, provided that the same basis is
applied consistently to all such information in the statement.
The periodic statement of client assets referred to in paragraph 1 shall not be provided where the investment firm
provides its clients with access to an online system, which qualifies as a durable medium, where up-to-date statements of
client's financial instruments or funds can be easily accessed by the client and the firm has evidence that the client has
accessed this statement at least once during the relevant quarter.
3.
Investment firms which hold financial instruments or funds and which carry out the service of portfolio
management for a client may include the statement of client assets referred to in paragraph 1 in the periodic statement
it provides to that client pursuant to Article 60(1).
SECTION 5
Best execution
Article 64
Best execution criteria
(Articles 27(1) and 24(1) of Directive 2014/65/EU)
1.
When executing client orders, investment firms shall take into account the following criteria for determining the
relative importance of the factors referred to in Article 27(1) of Directive 2014/65/EU:
(a)  the characteristics of the client including the categorisation of the client as retail or professional;
(b)  the characteristics of the client order, including where the order involves a securities financing transaction (SFT);
(c)  the characteristics of financial instruments that are the subject of that order;
(d)  the characteristics of the execution venues to which that order can be directed.
For the purposes of this Article and Articles 65 and 66, ‘execution venue’ includes a regulated market, an MTF, an OTF,
a systematic internaliser, or a market maker or other liquidity provider or an entity that performs a similar function in
a third country to the functions performed by any of the foregoing.
2.
An investment firm satisfies its obligation under Article 27(1) of Directive 2014/65/EU to take all sufficient steps
to obtain the best possible result for a client to the extent that it executes an order or a specific aspect of an order
following specific instructions from the client relating to the order or the specific aspect of the order.
31.3.2017
L 87/57
Official Journal of the European Union
EN

<!-- source-page: 58 -->

3.
Investment firms shall not structure or charge their commissions in such a way as to discriminate unfairly between
execution venues.
4.
When executing orders or taking decision to deal in OTC products including bespoke products, the investment
firm shall check the fairness of the price proposed to the client, by gathering market data used in the estimation of the
price of such product and, where possible, by comparing with similar or comparable products.
Article 65
Duty of investment firms carrying out portfolio management and reception and transmission of
orders to act in the best interests of the client
(Article 24(1) and 24(4) of Directive 2014/65/EU)
1.
Investment firms, when providing portfolio management, shall comply with the obligation under Article 24(1) of
Directive 2014/65/EU to act in accordance with the best interests of their clients when placing orders with other entities
for execution that result from decisions by the investment firm to deal in financial instruments on behalf of its client.
2.
Investment firms, when providing the service of reception and transmission of orders, shall comply with the
obligation under Article 24(1) of Directive 2014/65/EU to act in accordance with the best interests of their clients when
transmitting client orders to other entities for execution.
3.
In order to comply with paragraphs 1 or 2, investment firms shall comply with paragraphs 4 to 7 of this Article
and Article 64(4).
4.
Investment firms shall take all sufficient steps to obtain the best possible result for their clients taking into account
the factors referred to in Article 27(1) of Directive 2014/65/EU. The relative importance of these factors shall be
determined by reference to the criteria set out in Article 64(1) and, for retail clients, to the requirement under
Article 27(1) of Directive 2014/65/EU.
An investment firm satisfies its obligations under paragraph 1 or 2, and is not required to take the steps mentioned in
this paragraph, to the extent that it follows specific instructions from its client when placing an order with, or
transmitting an order to, another entity for execution.
5.
Investment firms shall establish and implement a policy that enables them to comply with the obligation in
paragraph 4. The policy shall identify, in respect of each class of instruments, the entities with which the orders are
placed or to which the investment firm transmits orders for execution. The entities identified shall have execution
arrangements that enable the investment firm to comply with its obligations under this Article when it places or
transmits orders to that entity for execution.
6.
Investment firms shall provide information to their clients on the policy established in accordance with
paragraph 5 and paragraphs 2 to 9 of Article 66. Investment firms shall provide clients with appropriate information
about the firm and its services and the entities chosen for execution. In particular, when the investment firm select other
firms to provide order execution services, it shall summarise and make public, on an annual basis, for each class
of financial instruments, the top five investment firms in terms of trading volumes where it transmitted or placed client
orders for execution in the preceding year and information on the quality of execution obtained. The information
shall be consistent with the information published in accordance with the technical standards developed under
Article 27(10)(b) of Directive 2014/65/EU.
Upon reasonable request from a client, investment firms shall provide its clients or potential clients with information
about entities where the orders are transmitted or placed for execution.
7.
Investment firms shall monitor on a regular basis the effectiveness of the policy established in accordance with
paragraph 5 and, in particular, shall monitor the execution quality of the entities identified in that policy and, where
appropriate, correct any deficiencies.
Investment firms shall review the policy and arrangements at least annually. Such a review shall also be carried out
whenever a material change occurs that affects the firm's ability to continue to obtain the best possible result for their
clients.
31.3.2017
L 87/58
Official Journal of the European Union
EN

<!-- source-page: 59 -->

Investment firms shall assess whether a material change has occurred and shall consider making changes to the
execution venues or entities on which they place significant reliance in meeting the overarching best execution
requirement.
A material change shall be a significant event that could impact parameters of best execution such as cost, price, speed,
likelihood of execution and settlement, size, nature or any other consideration relevant to the execution of the order.
8.
This Article shall not apply where the investment firm that provides the service of portfolio management or
reception and transmission of orders also executes the orders received or the decisions to deal on behalf of its client's
portfolio. In those cases Article 27 of Directive 2014/65/EU shall apply.
Article 66
Execution policy
(Article 27(5) and (7) of Directive 2014/65/EU)
1.
Investment firms shall review, at least on an annual basis execution policy established pursuant to Article 27(4) of
Directive 2014/65/EU, as well as their order execution arrangements.
Such a review shall also be carried out whenever a material change as defined in Article 65(7) occurs that affects the
firm's ability to continue to obtain the best possible result for the execution of its client orders on a consistent basis
using the venues included in its execution policy. An investment firm shall assess whether a material change has
occurred and shall consider making changes to the relative importance of the best execution factors in meeting the
overarching best execution requirement.
2.
The information on the execution policy shall be customised depending on the class of financial instrument and
type of the service provided and shall include information set out in paragraphs 3 to 9.
3.
Investment firms shall provide clients with the following details on their execution policy in good time prior to the
provision of the service:
(a)  an account of the relative importance the investment firm assigns, in accordance with the criteria specified in
Article 59(1), to the factors referred to in Article 27(1) of Directive 2014/65/EU, or the process by which the firm
determines the relative importance of those factors.
(b)  a list of the execution venues on which the firm places significant reliance in meeting its obligation to take all
reasonable steps to obtain on a consistent basis the best possible result for the execution of client orders and
specifying which execution venues are used for each class of financial instruments, for retail client orders,
professional client orders and SFTs;
(c)  a list of factors used to select an execution venue, including qualitative factors such as clearing schemes, circuit
breakers, scheduled actions, or any other relevant consideration, and the relative importance of each factor; The
information about the factors used to select an execution venue for execution shall be consistent with the controls
used by the firm to demonstrate to clients that best execution has been achieved in a consistent basis when
reviewing the adequacy of its policy and arrangements;
(d)  how the execution factors of price costs, speed, likelihood of execution and any other relevant factors are considered
as part of all sufficient steps to obtain the best possible result for the client;
(e)  where applicable, information that the firm executes orders outside a trading venue, the consequences, for example
counterparty risk arising from execution outside a trading venue, and upon client request, additional information
about the consequences of this means of execution;
(f)  a clear and prominent warning that any specific instructions from a client may prevent the firm from taking the
steps that it has designed and implemented in its execution policy to obtain the best possible result for the execution
of those orders in respect of the elements covered by those instructions;
31.3.2017
L 87/59
Official Journal of the European Union
EN

<!-- source-page: 60 -->

(g)  a summary of the selection process for execution venues, execution strategies employed, the procedures and process
used to analyse the quality of execution obtained and how the firms monitor and verify that the best possible results
were obtained for clients.
That information shall be provided in a durable medium, or by means of a website (where that does not constitute
a durable medium) provided that the conditions specified in Article 3(2) are satisfied.
4.
Where investment firms apply different fees depending on the execution venue, the firm shall explain these
differences in sufficient detail in order to allow the client to understand the advantages and the disadvantages of the
choice of a single execution venue.
5.
Where investment firms invite clients to choose an execution venue, fair, clear and not misleading information
shall be provided to prevent the client from choosing one execution venue rather than another on the sole basis of the
price policy applied by the firm.
6.
Investment firms shall only receive third-party payments that comply with Article 24(9) of Directive 2014/65/EU
and shall inform clients about the inducements that the firm may receive from the execution venues. The information
shall specify the fees charged by the investment firm to all counterparties involved in the transaction, and where the fees
vary depending on the client, the information shall indicate the maximum fees or range of the fees that may be payable.
7.
Where an investment firm charges more than one participant in a transaction, in compliance with Article 24(9) of
Directive 2014/65/EU and its implementing measures, the firm shall inform its clients of the value of any monetary or
non-monetary benefits received by the firm.
8.
Where a client makes reasonable and proportionate requests for information about its policies or arrangements
and how they are reviewed to an investment firm, that investment firm shall answer clearly and within a reasonable
time.
9.
Where an investment firm executes orders for retail clients, it shall provide those clients with a summary of the
relevant policy, focused on the total costs they incur. The summary shall also provide a link to the most recent
execution quality data published in accordance with Article 27(3) of Directive 2014/65/EU for each execution venue
listed by the investment firm in its execution policy.
SECTION 6
Client order handling
Article 67
General principles
(Articles 28(1) and 24(1) of Directive 2014/65/EU)
1.
Investment firms shall satisfy the following conditions when carrying out client orders:
(a)  ensure that orders executed on behalf of clients are promptly and accurately recorded and allocated;
(b)  carry out otherwise comparable client orders sequentially and promptly unless the characteristics of the order or
prevailing market conditions make this impracticable, or the interests of the client require otherwise;
(c)  inform a retail client about any material difficulty relevant to the proper carrying out of orders promptly upon
becoming aware of the difficulty.
2.
Where an investment firm is responsible for overseeing or arranging the settlement of an executed order, it shall
take all reasonable steps to ensure that any client financial instruments or client funds received in settlement of that
executed order are promptly and correctly delivered to the account of the appropriate client.
3.
An investment firm shall not misuse information relating to pending client orders, and shall take all reasonable
steps to prevent the misuse of such information by any of its relevant persons.
31.3.2017
L 87/60
Official Journal of the European Union
EN

<!-- source-page: 61 -->

Article 68
Aggregation and allocation of orders
(Articles 28(1) and 24(1) of Directive 2014/65/EU)
1.
Investment firms shall not carry out a client order or a transaction for own account in aggregation with another
client order unless the following conditions are met:
(a)  it is unlikely that the aggregation of orders and transactions will work overall to the disadvantage of any client
whose order is to be aggregated;
(b)  it is disclosed to each client whose order is to be aggregated that the effect of aggregation may work to its
disadvantage in relation to a particular order;
(c)  an order allocation policy is established and effectively implemented, providing for the fair allocation of aggregated
orders and transactions, including how the volume and price of orders determines allocations and the treatment of
partial executions.
2.
Where an investment firm aggregates an order with one or more other client orders and the aggregated order is
partially executed, it shall allocate the related trades in accordance with its order allocation policy.
Article 69
Aggregation and allocation of transactions for own account
(Articles 28(1) and 24(1) of Directive 2014/65/EU)
1.
Investment firms which have aggregated transactions for own account with one or more client orders shall not
allocate the related trades in a way that is detrimental to a client.
2.
Where an investment firm aggregates a client order with a transaction for own account and the aggregated order is
partially executed, it shall allocate the related trades to the client in priority to the firm.
Where an investment firm is able to demonstrate on reasonable grounds that without the combination it would not
have been able to carry out the order on such advantageous terms, or at all, it may allocate the transaction for own
account proportionally, in accordance with its order allocation policy referred to in Article 68(1)(c).
3.
As part of the order allocation policy referred to in Article 68(1)(c), investment firms shall put in place procedures
designed to prevent the reallocation, in a way that is detrimental to the client, of transactions for own account which are
executed in combination with client orders.
Article 70
Prompt fair and expeditious execution of client orders and publication of unexecuted client limit
orders for shares traded on a trading venue
(Article 28 of Directive 2014/65/EU)
1.
A client limit order in respect of shares admitted to trading on a regulated market or traded on a trading venue
which have not been immediately executed under prevailing market conditions as referred to in Article 28(2) of
Directive 2014/65/EU shall be considered available to the public when the investment firm has submitted the order for
execution to a regulated market or a MTF or the order has been published by a data reporting services provider located
in one Member State and can be easily executed as soon as market conditions allow.
2.
Regulated markets and MTFs shall be prioritised according to the firm's execution policy to ensure execution as
soon as market conditions allow.
31.3.2017
L 87/61
Official Journal of the European Union
EN

<!-- source-page: 62 -->

SECTION 7
Eligible counterparties
Article 71
Eligible counterparties
(Article 30 of Directive 2014/65/EU)
1.
In addition to the categories which are explicitly set out in Article 30(2) of Directive 2014/65/EU, Member States
may recognise as eligible counterparty, in accordance with Article 30(3) of that Directive, an undertaking falling within
a category of clients who are to be considered professional clients in accordance with paragraphs 1, 2 and 3 of Section I
of Annex II to that Directive.
2.
Where, pursuant to the second subparagraph of Article 30(2) of Directive 2014/65/EU, an eligible counterparty
requests treatment as a client whose business with an investment firm is subject to Articles 24, 25, 27 and 28 of that
Directive, the request should be made in writing, and shall indicate whether the treatment as retail client or professional
client refers to one or more investment services or transactions, or one or more types of transaction or product.
3.
Where an eligible counterparty requests treatment as a client whose business with an investment firm is subject to
Articles 24, 25, 27 and 28 of Directive 2014/65/EU, but does not expressly request treatment as a retail client, the firm
shall treat that eligible counterparty as a professional client.
4.
Where the eligible counterparty expressly requests treatment as a retail client, the investment firm shall treat the
eligible counterparty as a retail client, applying the provisions in respect of requests of non-professional treatment
specified in the second, third and fourth sub-paragraphs of Section I of Annex II to Directive 2014/65/EU.
5.
Where a client requests to be treated as an eligible counterparty, in accordance with Article 30(3) of Directive
2014/65/EU, the following procedure shall be followed:
(a)  the investment firm shall provide the client with a clear written warning of the consequences for the client of such
a request, including the protections they may lose;
(b)  the client shall confirm in writing the request to be treated as an eligible counterparty either generally or in respect
of one or more investment services or a transaction or type of transaction or product and that they are aware of the
consequences of the protection they may lose as a result of the request.
SECTION 8
Record-keeping
Article 72
Retention of records
(Article 16(6) of Directive 2014/65/EU)
1.
The records shall be retained in a medium that allows the storage of information in a way accessible for future
reference by the competent authority, and in such a form and manner that the following conditions are met:
(a)  the competent authority is able to access them readily and to reconstitute each key stage of the processing of each
transaction;
(b)  it is possible for any corrections or other amendments, and the contents of the records prior to such corrections or
amendments, to be easily ascertained;
(c)  it is not possible for the records otherwise to be manipulated or altered;
(d)  it allows IT or any other efficient exploitation when the analysis of the data cannot be easily carried out due to the
volume and the nature of the data; and
(e)  the firm's arrangements comply with the record keeping requirements irrespective of the technology used.
31.3.2017
L 87/62
Official Journal of the European Union
EN

<!-- source-page: 63 -->

2.
Investment firms shall keep at least the records identified in Annex I to this Regulation depending upon the nature
of their activities.
The list of records identified in Annex I to this Regulation is without prejudice to any other record-keeping obligations
arising from other legislation.
3.
Investment firms shall also keep records of any policies and procedures they are required to maintain pursuant to
Directive 2014/65/EU, Regulation (EU) No 600/2014, Directive 2014/57/EU and Regulation (EU) No 596/2014 and
their respective implementing measures in writing.
Competent authorities may require investment firms to keep additional records to the list identified in Annex I to this
Regulation.
Article 73
Record keeping of rights and obligations of the investment firm and the client
(Article 25(5) of Directive 2014/65/EU)
Records which set out the respective rights and obligations of the investment firm and the client under an agreement to
provide services, or the terms on which the firm provides services to the client, shall be retained for at least the duration
of the relationship with the client.
Article 74
Record keeping of client orders and decision to deal
(Article 16(6) of Directive 2014/65/EU)
An investment firm shall, in relation to every initial order received from a client and in relation to every initial decision
to deal taken, immediately record and keep at the disposal of the competent authority at least the details set out in
Section 1 of Annex IV to this Regulation to the extent they are applicable to the order or decision to deal in question.
Where the details set out in Section 1 of Annex IV to this Regulation are also prescribed under Articles 25 and 26 of
Regulation (EU) No 600/2014, these details should be maintained in a consistent way and according to the same
standards prescribed under Articles 25 and 26 of Regulation (EU) No 600/2014.
Article 75
Record keeping of transactions and order processing
(Article 16(6) of Directive 2014/65/EU)
Investment firms shall, immediately after receiving a client order or making a decision to deal to the extent they are
applicable to the order or decision to deal in question, record and keep at the disposal of the competent authority at
least the details set out in Section 2 of Annex IV.
Where the details set out in Section 2 of Annex IV are also prescribed under Articles 25 and 26 of Regulation (EU)
No 600/2014, they shall be maintained in a consistent way and according to the same standards prescribed under
Articles 25 and 26 of Regulation (EU) No 600/2014.
Article 76
Recording of telephone conversations or electronic communications
(Article 16(7) of Directive 2014/65/EU)
1.
Investment firms shall establish, implement and maintain an effective recording of telephone conversations and
electronic communications policy, set out in writing, and appropriate to the size and organisation of the firm, and the
nature, scale and complexity of its business. The policy shall include the following content:
(a)  the identification of the telephone conversations and electronic communications, including relevant internal
telephone conversations and electronic communications, that are subject to the recording requirements in
accordance with Article 16(7) of Directive 2014/65/EU; and
31.3.2017
L 87/63
Official Journal of the European Union
EN

<!-- source-page: 64 -->

(b)  the specification of the procedures to be followed and measures to be adopted to ensure the firm's compliance with
the third and eighth subparagraphs of Article 16(7) of Directive 2014/65/EU where exceptional circumstances arise
and the firm is unable to record the conversation/communication on devices issued, accepted or permitted by the
firm. Evidence of such circumstances shall be retained and shall be accessible to competent authorities.
2.
Investment firms shall ensure that the management body has effective oversight and control over the policies and
procedures relating to the firm's recording of telephone conversations and electronic communications.
3.
Investment firms shall ensure that the arrangements to comply with recording requirements are technology-
neutral. Firms shall periodically evaluate the effectiveness of the firm's policies and procedures and adopt any such
alternative or additional measures and procedures as are necessary and appropriate. At a minimum, such adoption of
alternative or additional measures shall occur when a new medium of communication is accepted or permitted for use
by the firm.
4.
Investment firms shall keep and regularly update a record of those individuals who have firm devices or privately
owned devices that have been approved for use by the firm.
5.
Investment firms shall educate and train employees in procedures governing the requirements in Article 16(7) of
Directive 2014/65/EU.
6.
To monitor compliance with the recording and record-keeping requirements in accordance with Article 16(7) of
Directive 2014/65/EU, investment firms shall periodically monitor the records of transactions and orders subject to
these requirements, including relevant conversations. Such monitoring shall be risk based and proportionate.
7.
Investment firms shall demonstrate the policies, procedures and management oversight of the recording rules to
the relevant competent authorities upon request.
8.
Before investment firms provide investment services and activities relating to the reception, transmission and
execution of orders to new and existing clients, firms shall inform the client of the following:
(a)  that the conversations and communications are being recorded; and
(b)  that a copy of the recording of such conversations with the client and communications with the client will be
available on request for a period of five years and, where requested by the competent authority, for a period of up to
seven years.
The information referred to in the first sub-paragraph shall be presented in the same language(s) as that used to provide
investment services to clients.
9.
Investment firms shall record in a durable medium all relevant information related to relevant face-to-face conver­
sations with clients. The information recorded shall include at least the following:
(a)  date and time of meetings;
(b)  location of meetings;
(c)  identity of the attendees;
(d)  initiator of the meetings; and
(e)  relevant information about the client order including the price, volume, type of order and when it shall be
transmitted or executed.
10.
Records shall be stored in a durable medium, which allows them to be replayed or copied and must be retained
in a format that does not allow the original record to be altered or deleted.
Records shall be stored in a medium so that they are readily accessible and available to clients on request.
Firms shall ensure the quality, accuracy and completeness of the records of all telephone recordings and electronic
communications.
11.
The period of time for the retention of a record shall begin on the date when the record is created.
31.3.2017
L 87/64
Official Journal of the European Union
EN

<!-- source-page: 65 -->

SECTION 9
SME growth markets
Article 77
Qualification as an SME
(Article 4(1)(13) of Directive 2014/65/EU)
1.
An issuer whose shares have been admitted to trading for less than three years shall be deemed an SME for the
purpose of point (a) of Article 33(3) of Directive 2014/65/EU where its market capitalisation is below EUR 200 million
based on any of the following:
(a)  the closing share price of the first day of trading, if its shares have been admitted to trading for less than one year;
(b)  the last closing share price of the first year of trading, if its shares have been admitted to trading for more than one
year but less than two years;
(c)  the average of the last closing share prices of each of the first two years of trading, if its shares have been admitted
to trading for more than two years but less than three years.
2.
An issuer which has no equity instrument traded on any trading venue shall be deemed an SME for the purpose of
Article 4(1)(13) of Directive 2014/65/EU if, according to its last annual or consolidated accounts, it meets at least two of
the following three criteria: an average number of employees during the financial year of less than 250, a total balance
sheet not exceeding EUR 43 000 000 and an annual net turnover not exceeding EUR 50 000 000.
Article 78
Registration as an SME growth market
(Article 33(3) of Directive 2014/65/EU)
1.
When determining whether at least 50 % of the issuers admitted to trading on an MTF are SMEs for the purposes
of registration as an SME growth market in accordance with point (a) of Article 33(3) of Directive 2014/65/EU, the
competent authority of the home Member State of the operator of an MTF shall calculate the average ratio of SMEs over
the total number of issuers whose financial instruments are admitted to trading on that market. The average ratio shall
be calculated on 31 December of the previous calendar year as the average of the twelve end-of-month ratios of that
calendar year.
Without prejudice to the other conditions for registration specified in points (b) to (g) of Article 33(3) of Directive
2014/65/EU, the competent authority shall register as an SME growth market an applicant with no previous operating
history and, after three calendar years have elapsed, shall verify that it complies with the minimum proportion of SMEs,
as determined in accordance with the first subparagraph.
2.
With regard to the criteria laid out in points (b), (c), (d) and (f) of Article 33(3) of Directive 2014/65/EU, the
competent authority of the home Member State of the operator of an MTF shall not register the MTF as an SME growth
market unless it is satisfied that the MTF:
(a)  has established and applies rules providing for objective and transparent criteria for the initial and ongoing
admission to trading of issuers on its venue;
(b)  has an operating model which is appropriate for the performance of its functions and ensures the maintenance of
fair and orderly trading in the financial instruments admitted to trading on its venue;
(c)  has established and applies rules that require an issuer seeking admission of its financial instruments to trading on
the MTF, to publish, in cases where Directive 2003/71/EC does not apply, an appropriate admission document,
drawn up under the responsibility of the issuer and clearly stating whether or not it has been approved or reviewed
and by whom;
(d)  has established and applies rules that define the minimum content of the admission document referred to under
point (c), in such a way that sufficient information is provided to investors to enable them to make an informed
assessment of the financial position and prospects of the issuer, and the rights attaching to its securities;
31.3.2017
L 87/65
Official Journal of the European Union
EN

<!-- source-page: 66 -->

(e)  requires the issuer to state, in the admission document referred to under point (c), whether or not, in its opinion, its
working capital is sufficient for its present requirements or, if not, how it proposes to provide the additional
working capital needed;
(f)  has made arrangements for the admission document referred to under point (c) to be subject to an appropriate
review of its completeness, consistency and comprehensibility;
(g)  requires the issuers whose securities are traded on its venue to publish annual financial reports within 6 months
after the end of each financial year, and half yearly financial reports within 4 months after the end of the first
6 months of each financial year;
(h)  ensures dissemination to the public of prospectuses drawn up in accordance with Directive 2003/71/EC, admission
documents referred to under point (c), financial reports referred to under point (g) and information defined in
Article 7(1) of Regulation (EU) No 596/2014 publicly disclosed by the issuers whose securities are traded on its
venue, by publishing them on its website, or providing thereon a direct link to the page of the website of the issuers
where such documents, reports and information are published;
(i)  ensures that the regulatory information referred to under point (h) and direct links remain available on its website
for a period of at least five years.
Article 79
Deregistration as an SME growth market
(Article 33(3) of Directive 2014/65/EU)
1.
With regard to the proportion of SMEs, and without prejudice to the other conditions specified in points (b) to (g)
of Article 33(3) of Directive 2014/65/EU and in Article 78(2) of this Regulation, an SME growth market shall only be
deregistered by the competent authority of its home Member State where the proportion of SMEs, as determined in
accordance with the first subparagraph of Article 78(1) of this Regulation, falls below 50 % for three consecutive
calendar years.
2.
With regard to the conditions specified in points (b) to (g) of Article 33(3) of Directive 2014/65/EU and in
Article 78(2) of this Regulation, the operator of an SME growth market shall be deregistered by the competent authority
of its home Member State where such conditions are no longer satisfied.
CHAPTER IV
OPERATING OBLIGATIONS FOR TRADING VENUES
Article 80
Circumstances constituting significant damage to investors' interests and the orderly functioning
of the market
(Articles 32(1), 32(2), 52(1) and 52(2) of Directive 2014/65/EU)
1.
For the purpose of Articles 32(1), 32(2), 52(1) and 52(2) of Directive 2014/65/EU, a suspension or a removal
from trading of a financial instrument shall be deemed likely to cause significant damage to investors' interests or the
orderly functioning of the market at least in the following circumstances:
(a)  where it would create a systemic risk undermining financial stability, such as where the need exists to unwind
a dominant market position, or where settlement obligations would not be met in a significant volume;
(b)  where the continuation of trading on the market is necessary to perform critical post-trade risk management
functions when there is a need for the liquidation of financial instruments due to the default of a clearing member
under the default procedures of a CCP and a CCP would be exposed to unacceptable risks as a result of an inability
to calculate margin requirements;
(c)  where the financial viability of the issuer would be threatened, such as where it is involved in a corporate
transaction or capital raising.
31.3.2017
L 87/66
Official Journal of the European Union
EN

<!-- source-page: 67 -->

2.
For the purpose of determining whether a suspension or a removal is likely to cause significant damage to the
investors' interest or the orderly functioning of the markets in any particular case, the national competent authority,
a market operator operating a regulated market or an investment firm or a market operator operating an MTF or an
OTF shall consider all relevant factors, including:
(a)  the relevance of the market in terms of liquidity where the consequences of the actions are likely to be more
significant where those markets are more relevant in terms of liquidity than in other markets;
(b)  the nature of the envisaged action where actions with a sustained or lasting impact on the ability of investors to
trade a financial instrument on trading venues, such as removals, are likely to have a greater impact on investors
than other actions;
(c)  the knock-on effects of a suspension or removal of sufficiently related derivatives, indices or benchmarks for which
the removed or suspended instrument serves as an underlying or constituent;
(d)  the effects of a suspension on the interests of market end users who are not financial counterparties, such as entities
trading in financial instruments to hedge commercial risks.
3.
The factors set out in paragraph 2 shall also be taken into consideration where a national competent authority,
a market operator operating a regulated market or an investment firm or a market operator operating an MTF or an
OTF decides not to suspend or remove a financial instrument on the basis of circumstances not covered by the list of
paragraph 1.
Article 81
Circumstances where significant infringements of the rules of a trading venue or disorderly
trading conditions or system disruptions in relation to a financial instrument may be assumed
(Articles 31(2) and 54(2) of Directive 2014/65/EU)
1.
When assessing whether the requirement to immediately inform their competent authorities of significant infringe­
ments of the rules of their trading venue or disorderly trading conditions or system disruptions in relation to a financial
instrument applies, operators of trading venues shall consider the signals listed in Section A of Annex III to this
Regulation.
2.
Information shall only be required in cases of significant events which have the potential to jeopardise the role and
function of trading venues as part of the financial market infrastructure.
Article 82
Circumstances where a conduct indicating behaviour that is prohibited under Regulation (EU)
No 596/2014 may be assumed
(Articles 31(2) and 54(2) of Directive 2014/65/EU)
1.
When assessing whether the requirement to immediately inform their competent authorities of conduct that may
indicate behaviour that is prohibited under Regulation (EU) No 596/2014 applies, operators of trading venues shall
consider the signals listed in Section B of Annex III to this Regulation.
2.
The operator of one or several trading venues where a financial instrument and/or related financial instrument are
traded shall apply a proportionate approach and shall exercise judgment on the signals triggered, including any relevant
signals not specifically included in Section B of Annex III to this Regulation, before informing the relevant national
competent authority, taking into account the following:
(a)  the deviations from the usual trading pattern of the financial instruments admitted to trading or traded on its
trading venue; and
(b)  the information available or accessible to the operator, whether that be internally as part of the operations of the
trading venue or publicly available.
31.3.2017
L 87/67
Official Journal of the European Union
EN

<!-- source-page: 68 -->

3.
The operator of one or several trading venues shall take into account front running behaviours, which consist in
a market member or participant trading, for its own account, ahead of its client, and shall use for that purpose the order
book data required to be recorded by the trading venue pursuant to Article 25 of Regulation (EU) No 600/2014, in
particular those relating to the way the member or participant conducts its trading activity.
CHAPTER V
POSITION REPORTING IN COMMODITY DERIVATIVES
Article 83
Position reporting
(Article 58(1) of Directive 2014/65/EU)
1.
For the purpose of the weekly reports referred to in Art 58(1)(a) of Directive 2014/65/EU, the obligation for
a trading venue to make public such a report shall apply when both of the following two thresholds are met:
(a)  20 open position holders exist in a given contract on a given trading venue; and
(b)  the absolute amount of the gross long or short volume of total open interest, expressed in the number of lots of the
relevant commodity derivative, exceeds a level of four times the deliverable supply in the same commodity
derivative, expressed in number of lots.
Where the commodity derivative does not have a physically deliverable underlying asset and for emission allowances
and derivatives thereof, point (b) shall not apply.
2.
The threshold set out in point (a) of paragraph 1 shall apply in aggregate on the basis of all of the categories of
persons regardless of the numbers of position holders in any single category of persons.
3.
For contracts where there are less than five position holders active in a given category of persons, the number of
position holders in that category shall not be published.
4.
For contracts that meet the conditions set out in points (a) and (b) of paragraph 1 for the first time, trading venues
shall publish the contracts first weekly report as soon as it is feasibly practical, and in any event no later than 3 weeks
from the date on which the thresholds are first triggered.
5.
Where the conditions set out in points (a) and (b) of paragraph 1 are no longer met, trading venues shall continue
to publish the weekly reports for a period of three months. The obligation to publish the weekly report no longer
applies where the conditions set out in points (a) and (b) of paragraph 1 have not been met continuously upon expiry of
that period.
CHAPTER VI
DATA PROVISION OBLIGATIONS FOR DATA REPORTING SERVICE PROVIDERS
Article 84
Obligation to provide market data on a reasonable commercial basis
(Article 64(1) and 65(1) of Directive 2014/65/EU)
1.
For the purposes of making market data containing the information set out in Articles 6, 20 and 21 of Regulation
(EU) No 600/2014 available to the public on a reasonable commercial basis in accordance with Articles 64(1) and 65(1)
of Directive 2014/65/EU, approved publication arrangements (APAs) and consolidated tape providers (CTPs) shall
comply with the obligations set out in Articles 85 to 89.
2.
Articles 85, 86(2), 87, 88(2) and 89 shall not apply to APAs or CTPs that make market data available to the public
free of charge.
31.3.2017
L 87/68
Official Journal of the European Union
EN

<!-- source-page: 69 -->

Article 85
Provision of market data on the basis of cost
(Article 64(1) and 65(1) of Directive 2014/65/EU)
1.
The price of market data shall be based on the cost of producing and disseminating such data and may include
a reasonable margin.
2.
The costs of producing and disseminating market data may include an appropriate share of joint costs for other
service provided by APAs and CTPs.
Article 86
Obligation to provide market data on a non-discriminatory basis
(Article 64(1) and 65(1) of Directive 2014/65/EU)
1.
APAs and CTPs shall make market data available at the same price and on the same terms and conditions to all
customers falling within the same category in accordance with published objective criteria.
2.
Any differentials in prices charged to different categories of customers shall be proportionate to the value which
the market data represent to those customers, taking into account:
(a)  the scope and scale of the market data including the number of financial instruments covered and trading volume;
(b)  the use made by the customer of the market data, including whether it is used for the customer's own trading
activities, for resale or for data aggregation.
3.
For the purposes of paragraph 1, APAs and CTPs shall have scalable capacities in place to ensure that customers
can obtain timely access to market data at all times on a non-discriminatory basis.
Article 87
Per user fees
(Article 64(1) and 65(1) of Directive 2014/65/EU)
1.
APAs and CTPs shall charge for the use of market data on the basis of the use made by individual end-users of the
market data (‘per user basis’). APAs and CTPs shall have arrangements in place to ensure that each individual use of
market data is charged only once.
2.
By way of derogation from paragraph 1, APAs and CTPs may decide not to make market data available on a per
user basis where to charge on a per user basis is disproportionate to the cost of making market data available, having
regard to the scale and scope of the market data.
3.
APAs or CTPs shall provide grounds for the refusal to make market data available on a per user basis and shall
publish those grounds on their webpage.
Article 88
Unbundling and disaggregating market data
(Article 64(1) and 65(1) of Directive 2014/65/EU)
1.
APAs and CTPs shall make market data available without being bundled with other services.
31.3.2017
L 87/69
Official Journal of the European Union
EN

<!-- source-page: 70 -->

2.
Prices for market data shall be charged on the basis of the level of market data disaggregation provided for in
Article 12(1) of Regulation (EU) No 600/2014 as further specified in Articles of Commission Delegated Regulation (EU)
2017/572 (1).
Article 89
Transparency obligation
(Article 64(1) and 65(1) of Directive 2014/65/EU)
1.
APAs and CTPs shall disclose and make easily available to the public the price and other terms and conditions for
the provision of the market data in a manner which is easily accessible.
2.
The disclosure shall include the following:
(a)  current price lists, including the following information:
(i)
fees per display user;
(ii)  non-display fees;
(iii)  discount policies;
(iv)  fees associated with licence conditions;
(v)  fees for pre-trade and for post-trade market data;
(vi)  fees for other subsets of information, including those required in accordance with the regulatory technical
standards pursuant to Article 12(2) of Regulation (EU) No 600/2014;
(vii)  other contractual terms and conditions;
(b)  advance disclosure with a minimum of 90 days' notice of future price changes;
(c)  information on the content of the market data including the following information:
(i)  the number of instruments covered;
(ii)  the total turnover of instruments covered;
(iii)  pre-trade and post-trade market data ratio;
(iv)  information on any data provided in addition to market data;
(v)  the date of the last licence fee adaption for market data provided;
(d)  revenue obtained from making market data available and the proportion of that revenue compared to total revenue
of the APA or CTP;
(e)  information on how the price was set, including the cost accounting methodologies used and information about the
specific principles according to which direct and variable joint costs are allocated and fixed joint costs are
apportioned, between the production and dissemination of market data and other services provided by APAs and
CTPs.
CHAPTER VII
COMPETENT AUTHORITIES AND FINAL PROVISIONS
Article 90
Determination of the substantial importance of the operations of a trading venue in a host
Member State
(Article 79(2) of Directive 2014/65/EU)
1.
The operations of a regulated market in a host Member State shall be considered to be of substantial importance
for the functioning of the securities markets and the protection of investors in that host Member State where at least
one of the following criteria is met:
(a)  the host Member State has formerly been the home Member State of the regulated market in question;
31.3.2017
L 87/70
Official Journal of the European Union
EN
(1) Commission Delegated Regulation (EU) 2017/572 of 2 June 2016 supplementing Regulation (EU) No 600/2014 of the European
Parliament and of the Council with regard to regulatory technical standards on the specification of the offering of pre-and post-trade data
and the level of disaggregation of data (see page 142 of this Official Journal).

<!-- source-page: 71 -->

(b)  the regulated market in question has acquired through merger, takeover, or any other form of transfer of the whole
or part of the business of a regulated market which was previously operated by a market operator which had its
registered office or head office in the host Member State.
2.
The operations of an MTF or OTF in a host Member State shall be considered to be of substantial importance for
the functioning of the securities markets and the protection of investors in that host Member State where at least one of
the criteria laid down in paragraph 1 is met in regard to that MTF or OTF and at least one of the following additional
criteria is met:
(a)  before one of the situations set out in paragraph 1 occurred in regard to the MTF or OTF, the trading venue had
a market share of at least 10 % of trading in terms of total turnover in monetary terms in on-venue trading and
systematic internaliser trading in the host Member State in at least one asset class subject to the transparency
obligations of Regulation (EU) No 600/2014;
(b)  the MTF or OTF is registered as an SME growth market.
CHAPTER VIII
FINAL PROVISIONS
Article 91
Entry into force and application
This Regulation shall enter into force on the twentieth day following that of its publication in the Official Journal of the
European Union.
It shall apply from the date that appears first in the second subparagraph of Article 93(1) of Directive 2014/65/EU.
This Regulation shall be binding in its entirety and directly applicable in all Member States.
Done at Brussels, 25 April 2016.
For the Commission
The President
Jean-Claude JUNCKER
31.3.2017
L 87/71
Official Journal of the European Union
EN

<!-- source-page: 72 -->

ANNEX I
Record-keeping
Minimum list of records to be kept by investment firms depending upon the nature of their activities
Nature of
obligation
Type of record
Summary of content
Legislative reference
Client assessment
Information to clients
Content as provided for under Article 24(4) of
Directive 2014/65/EU and Articles 39 to 45 of
this Regulation
Article 24(4) MIFID II
Articles 39 to 45 of this Regulation
Client agreements
Records as provided for under Article 25(5) of
Directive 2014/65/EU
Article 25(5) MIFID II
Article 53 of this Regulation
Assessment of suitability
and appropriateness
Content as provided for under Article 25(2)
and (3) of Directive 2014/65/EU and Article 50
of this Regulation
Article 25(2) and (3) of Directive
2014/65/EU
Articles 35, 36 and 37 of this Regu­
lation
Order handling
Client order-handling —
Aggregated transactions
Records as provided for under Articles 63 to
66 of this Regulation
Articles 24(1) and 28(1) of Directive
2014/65/EU
Articles 63 to 66 of this Regulation
Aggregation and alloca­
tion of trans-actions for
own account
Records as provided for under Article 65 of
this Regulation
Articles 28(1) and 24(1) of Directive
2014/65/EU
Article 65 of this Regulation
Client Orders and transactions
Record keeping of client
orders or decision to deal
Records as provided for under Article 69 of
this Regulation
Article 16(6) of Directive 2014/65/EU
Article 69 of this Regulation
Record keeping of trans­
actions and order pro­
cessing
Records as provided for under Article 70 of
this Regulation
Article 16(6) of Directive 2014/65/EU
Article 70 of this Regulation
Reporting to clients
Obligation in respect
of services provided to
clients
Contents as provided for under Articles 53
to 58 of this Regulation
Article 24(1) and (6) and Article 25(1)
and (6) of Directive 2014/65/EU
Articles 53 to 58 of this Regulation
Safeguarding of client assets
Client financial instru­
ments held by an invest­
ment firm
Records as provided for under Article 16(8)
of Directive 2014/65/EU and under Article 2
of
Commission
Delegated
Directive
(EU)
2017/593
Article 16(8) of Directive 2014/65/EU
Article 2 of Delegated Directive (EU)
2017/593
31.3.2017
L 87/72
Official Journal of the European Union
EN

<!-- source-page: 73 -->

Nature of
obligation
Type of record
Summary of content
Legislative reference
Client funds held by an
investment firm
Records as provided for under Article 16(9) of
Directive 2014/65/EU and under Article 2 of
Delegated Directive (EU) 2017/593
Article 16(9) of Directive 2014/65/EU
Article 2 of Delegated Directive (EU)
2017/593
Use of client financial
instruments
Records provided for under Article 5 of
Delegated Directive (EU) 2017/593
Article 16(8) to (10) of Directive
2014/65/EU
Article 5 of Delegated Directive (EU)
2017/593
Communication with clients
Information about Costs
and associated charges
Contents as provided for under Article 45 of
this Regulation
Article 24(4)(c) of Directive 2014/65/EU
Article 45 of this Regulation
Information about the
investment firm and its
services, financial instru­
ments and safe-guarding
of client assets
Content as provided for under Articles 45 and
46 of this Regulation
Article 24(4) of Directive 2014/65/EU
Articles 45 and 46 of this Regulation
Information to clients
Records of communication
Article 24(3) of Directive 2014/65/EU
Article 39 of this Regulation
Marketing communica­
tions (except in oral form)
Each marketing communication issued by the
investment firm (except in oral form) as
provided under Articles 36 and 37 of this
Regulation
Article 24(3) of Directive 2014/65/EU
Articles 36 and 37 of this Regulation
Investment advice to
retail clients
(i) The fact, time and date that investment
advice was rendered and (ii) the financial instru­
ment that was recommended (iii) the suitability
report provided to the client
Article 25(6) of Directive 2014/65/EU
Article 54 of this Regulation
Investment research
Each item of investment research issued by the
investment firm in a durable medium
Article 24(3) of Directive 2014/65/EU
Articles 36 and 37 of this Regulation
Organisational requirements
The firm's business and
internal organisation
Records as provided for under Article 21(1)(h)
of this Regulation
Article 16(2) to (10) of Directive
2014/65/EU
Article 21(1)(h) of this Regulation
Compliance reports
Each compliance report to management body
Article 16(2) of Directive 2014/65/EU
Article 22(2)(b) and Article 25(2) of this
Regulation
Conflict of Interest record
Records as provided for under Article 35 of
this Regulation
Article 16(3) of Directive 2014/65/EU
Article 35 of this Regulation
31.3.2017
L 87/73
Official Journal of the European Union
EN

<!-- source-page: 74 -->

Nature of
obligation
Type of record
Summary of content
Legislative reference
Inducements
The information dis-closed to clients under
Article 24(9) of Directive 2014/65/EU
Article 24(9) of Directive 2014/65/EU
Article 11 of Delegated Directive (EU)
2017/593
Risk management reports
Each risk
management
report
to
senior
management
Article 16(5) of Directive 2014/65/EU
Article 23(1)(b) and Article 25(2) of this
Regulation
Internal audit reports
Each internal audit report to senior manage­
ment
Article 16(5) of Directive 2014/65/EU
Article 24 and Article 25(2) of this
Regulation
Complaints-handling
records
Each complaint and the complaint handling
measures taken to address the complaint
Article 16(2) of Directive 2014/65/EU
Article 26 of this Regulation
Records of personal trans­
actions
Records as provided for under Article 29(2)(c)
of this Regulation
Article 16(2) of Directive 2014/65/EU
Article 29(2)(c) of this Regulation
31.3.2017
L 87/74
Official Journal of the European Union
EN

<!-- source-page: 75 -->

ANNEX II
Costs and charges
Identified costs that should form part of the costs to be disclosed to the clients (1)
Table 1 — All costs and associated charges charged for the investment service(s) and/or ancillary services provided to the
client that should form part of the amount to be disclosed
Cost items to be disclosed
Examples:
One-off charges related to
the provision of an invest­
ment service
All costs and charges paid to the invest­
ment firm at the beginning or at the end
of the provided investment service(s).
Deposit fees, termination fees and switching
costs (1).
Ongoing charges related
to the provision of an
investment service
All ongoing costs and charges paid to
investment firms for their services pro­
vided to the client.
Management fees, advisory fees, custodian
fees.
All costs related to trans­
actions initiated in the
course of the provision of
an investment service
All costs and charges that are related to
transactions performed by the investment
firm or other parties.
Broker commissions (2), entry- and exit-
charges paid to the fund manager, platform
fees, mark ups (embedded in the transaction
price), stamp duty, transactions tax and
foreign exchange costs.
Any charges that are re­
lated to ancillary services
Any costs and charges that are related to
ancillary services that are not included in
the costs mentioned above.
Research costs.
Custody costs.
Incidental costs
Performance fees
(1)  Switching costs should be understood as costs (if any) that are incurred by investors by switching from one investment firm to
another investment firm.
(2)  Broker commissions should be understood as costs that are charged by investment firms for the execution of orders.
Table 2 — All costs and associated charges related to the financial instrument that should form part of the amount to be
disclosed
Cost items to be disclosed
Examples:
One-off charges
All costs and charges (included in the price
or in addition to the price of the financial
instrument) paid to product suppliers at
the beginning or at the end of the invest­
ment in the financial instrument.
Front-loaded management fee, structuring
fee (1), distribution fee.
Ongoing charges
All ongoing costs and charges related to
the management of the financial product
that are deducted from the value of the
financial instrument during the investment
in the financial instrument.
Management fees, service costs, swap fees,
securities lending costs and taxes, financing
costs.
31.3.2017
L 87/75
Official Journal of the European Union
EN
(1) It should be noted that certain cost items appear in both tables but are not duplicative since they respectively refer to costs of the product
and costs of the service. Examples are the management fees (in table 1, this refers to management fees charged by an investment firm
providing the service of portfolio management to its clients while in Table 2 it refers to management fees charged by an investment fund
manager to its investor) and broker commissions (in Table 1, they refer to commissions incurred by the investment firm when trading on
behalf of its clients while in Table 2 they refer to commissions paid by investment funds when trading on behalf of the fund).

<!-- source-page: 76 -->

Cost items to be disclosed
Examples:
All costs related to the
transactions
All costs and charges that incurred as a
result of the acquisition and disposal of
investments.
Broker commissions, entry- and exit-charges
paid by the fund, mark ups embedded in
the transaction price, stamp duty, transac­
tions tax and foreign exchange costs.
Incidental costs
Performance fees
(1)  Structuring fees should be understood as fees charged by manufacturers of structured investment products for structuring the
products. They may cover a broader range of services provided by the manufacturer.
31.3.2017
L 87/76
Official Journal of the European Union
EN

<!-- source-page: 77 -->

ANNEX III
Requirement for operators of trading venues to immediately inform their national competent
authority
SECTION A
Signals that may indicate significant infringements of the rules of a trading venue or disorderly trading
conditions or system disruptions in relation to a financial instrument
Significant infringements of the rules of a trading venue
1.  Market participants infringe rules of the trading venue which aim to protect the market integrity, the orderly
functioning of the market or the significant interests of the other market participants; and
2.  A trading venue considers that an infringement is of sufficient severity or impact to justify consideration of
disciplinary action.
Disorderly trading conditions
3.  The price discovery process is interfered with over a significant period of time;
4.  The capacities of the trading systems are reached or exceeded;
5.  Market makers/liquidity providers repeatedly claim mis-trades; or
6.  Breakdown or failure of critical mechanisms under Article 48 of Directive 2014/65/EU and its implementing
measures which are designed to protect the trading venue against the risks of algorithmic trading.
System disruptions
7.  Any major malfunction or breakdown of the system for market access that results in participants losing their ability
to enter, adjust or cancel their orders;
8.  Any major malfunction or breakdown of the system for the matching of transactions, that results in participants
losing certainty over the status of completed transactions or live orders as well as unavailability of information
indispensable for trading (e.g., index value dissemination for trading certain derivatives on that index);
9.  Any major malfunction or breakdown of the systems for the dissemination of pre- and post-trade transparency and
other relevant data published by trading venues in accordance with their obligations under Directive 2014/65/EU
and Regulation (EU) No 600/2014;
10.  Any major malfunction or breakdown of the systems of the trading venue to monitor and control the trading
activities of the market participants; and any major malfunction or breakdown in the sphere of other interrelated
services providers, in particular CCPs and CSDs, that has repercussions on the trading system.
SECTION B
Signals that may indicate abusive behaviour under Regulation (EU) No 596/2014
Signals of possible insider dealing or market manipulation
1.  Unusual concentration of transactions and/or orders to trade in a particular financial instrument with one
member/participant or between certain members/participants.
2.  Unusual repetition of a transaction among a small number of members/participants over a certain period of time.
31.3.2017
L 87/77
Official Journal of the European Union
EN

<!-- source-page: 78 -->

Signals of possible insider dealing
3.  Unusual and significant trading or submission of orders to trade in the financial instruments of a company by certain
members/participants before the announcement of important corporate events or of price sensitive information
relating to the company; orders to trade/transactions resulting in sudden and unusual changes in the volume of
orders/transactions and/or prices before public announcements regarding the financial instrument in question.
4.  Whether orders to trade are given or transactions are undertaken by a market member/participant before or
immediately after that member/participant or persons publicly known as linked to that member/participant produce
or disseminate research or investment recommendations that are made publicly available.
Signals of possible market manipulation
The signals described below in points 18 to 23 are particularly relevant in an automated trading environment.
5.  Orders to trade given or transactions undertaken which represent a significant proportion of the daily volume of
transactions in the relevant financial instrument on the trading venue concerned, in particular when these activities
lead to a significant change in the price of the financial instruments.
6.  Orders to trade given or transactions undertaken by a member/participant with a significant buying or selling
interest in a financial instrument which lead to significant changes in the price of the financial instrument on
a trading venue.
7.  Orders to trade given or transactions undertaken which are concentrated within a short time span in the trading
session and lead to a price change which is subsequently reversed.
8.  Orders to trade given which change the representation of the best bid or offer prices in a financial instrument
admitted to trading or traded on a trading venue, or more generally the representation of the order book available
to market participants, and are removed before they are executed.
9.  Transactions or orders to trade by a market/participant with no other apparent justification than to
increase/decrease the price or value of, or to have a significant impact on the supply of or demand for a financial
instrument, namely near the reference point during the trading day, e.g. at the opening or near the close.
10.  Buying or selling of a financial instrument at the reference time of the trading session (e.g. opening, closing,
settlement) in an effort to increase, to decrease or to maintain the reference price (e.g. opening price, closing price,
settlement price) at a specific level (usually known as marking the close).
11.  Transactions or orders to trade which have the effect of, or are likely to have the effect of increasing/decreasing the
weighted average price of the day or of a period during the session.
12.  Transactions or orders to trade which have the effect of, or are likely to have the effect of, setting a market price
when the liquidity of the financial instrument or the depth of the order book is not sufficient to fix a price within
the session.
13.  Execution of a transaction, changing the bid-offer prices when this spread is a factor in the determination of the
price of another transaction whether or not on the same trading venue.
14.  Entering orders representing significant volumes in the central order book of the trading system a few minutes
before the price determination phase of the auction and cancelling these orders a few seconds before the order
book is frozen for computing the auction price so that the theoretical opening price might look higher or lower
than it otherwise would do.
15.  Engaging in a transaction or series of transactions which are shown on a public display facility to give the
impression of activity or price movement in a financial instrument (usually known as painting the tape).
31.3.2017
L 87/78
Official Journal of the European Union
EN

<!-- source-page: 79 -->

16.  Transactions carried out as a result of the entering of buy and sell orders to trade at or nearly at the same time,
with the very similar quantity and similar price by the same or different but colluding market members/participants
(usually known as improper matched orders).
17.  Transactions or orders to trade which have the effect of, or are likely to have the effect of bypassing the trading
safeguards of the market (e.g. as regards volume limits; price limits; bid/offer spread parameters; etc.).
18.  Entering of orders to trade or a series of orders to trade, executing transactions or series of transactions likely to
start or exacerbate a trend and to encourage other participants to accelerate or extend the trend in order to create
an opportunity to close out/open a position at a favourable price (usually know as momentum ignition).
19.  Submitting multiple or large orders to trade often away from the touch on one side of the order book in order to
execute a trade on the other side of the order book. Once that trade has taken place, the manipulative orders will be
removed (usually known as layering and spoofing).
20.  Entry of small orders to trade in order to ascertain the level of hidden orders and particularly used to assess what is
resting on a dark platform (usually know as ping order).
21.  Entry of large numbers of orders to trade and/or cancellations and/or updates to orders to trade so as to create
uncertainty for other participants, slowing down their process and to camouflage their own strategy (usually known
as quote stuffing).
22.  Posting of orders to trade, to attract other market members/participants employing traditional trading techniques
(‘slow traders’), that are then rapidly revised onto less generous terms, hoping to execute profitably against the
incoming flow of ‘slow traders’ orders to trade (usually known as smoking).
23.  Executing orders to trade or a series of orders to trade, in order to uncover orders of other participants, and then
entering an order to trade to take advantage of the information obtained (usually known as phishing).
24.  The extent to which, to the best knowledge of the operator of a trading venue, orders to trade given or transactions
undertaken show evidence of position reversals in a short period and represent a significant proportion of the daily
volume of transactions in the relevant financial instrument on the trading venue concerned, and might be
associated with significant changes in the price of a financial instrument admitted to trading or traded on the
trading venue.
Signals for cross-product market manipulation, including across different trading venues
The signals described below should be particularly considered by the operator of a trading venue where both a financial
instrument and related financial instruments are admitted to trading or traded or where the above mentioned
instruments are traded on several trading venues operated by the same operator.
25.  Transactions or orders to trade which have the effect of, or are likely to have the effect of increasing/decreasing/
maintaining the price of a financial instrument during the days preceding the issue, optional redemption or expiry
of a related derivative or convertible;
26.  Transactions or orders to trade which have the effect of, or are likely to have the effect of maintaining the price of
the underlying financial instrument below or above the strike price, or other element used to determine the pay-out
(e.g. barrier), of a related derivative at expiration date;
27.  Transactions which have the effect of, or are likely to have the effect of modifying the price of the underlying
financial instrument so that it surpasses/not reaches the strike price, or other element used to determine the pay-out
(e.g. barrier), of a related derivative at expiration date;
28.  Transactions which have the effect of, or are likely to have the effect of modifying the settlement price of a financial
instrument when this price is used as a reference/determinant, namely, in the calculation of margins requirements;
29.  Orders to trade given or transactions undertaken by a member/participant with a significant buying or selling
interest in a financial instrument which lead to significant changes in the price of the related derivative or
underlying asset admitted to trading on a trading venue;
31.3.2017
L 87/79
Official Journal of the European Union
EN

<!-- source-page: 80 -->

30.  Undertaking trading or entering orders to trade in one trading venue or outside a trading venue (including entering
indications of interest) with a view to improperly influencing the price of a related financial instrument in another
or in the same trading venue or outside a trading venue (usually known as cross-product manipulation (trading on
financial instrument to improperly position the price of a related financial instrument in another or in the same
trading venue or outside a trading venue)).
31.  Creating or enhancing arbitrage possibilities between a financial instrument and another related financial instrument
by influencing reference prices of one of the financial instruments can be carried out with different financial
instruments (like rights/shares, cash markets/derivatives markets, warrants/shares, …). In the context of rights issues,
it could be achieved by influencing the (theoretical) opening or (theoretical) closing price of the rights.
31.3.2017
L 87/80
Official Journal of the European Union
EN

<!-- source-page: 81 -->

ANNEX IV
SECTION 1
Record keeping of client orders and decision to deal
1.  Name and designation of the client
2.  Name and designation of any relevant person acting on behalf of the client
3.  A designation to identify the trader (Trader ID) responsible within the investment firm for the investment decision
4.  A designation to identify the algorithm (Algo ID) responsible within the investment firm for the investment
decision;
5.  B/S indicator;
6.  Instrument identification
7.  Unit price and price notation;
8.  Price
9.  Price multiplier
10.  Currency 1
11.  Currency 2
12.  Initial quantity and quantity notation;
13.  Validity period
14.  Type of the order;
15.  Any other details, conditions and particular instructions from the client;
16.  The date and exact time of the receipt of the order or the date and exact time of when the decision to deal was
made. The exact time must be measured according to the methodology prescribed under the standards on clock
synchronisation under Article 50(2) of Directive 2014/65/EU.
SECTION 2
Record keeping of transactions and order processing
1.  name and designation of the client;
2.  name and designation of any relevant person acting on behalf of the client;
3.  a designation to identify the trader (Trader ID) responsible within the investment firm for the investment decision;
4.  a designation to identify the Algo (Ago ID) responsible within the investment firm for the investment decision
5.  Transaction reference number
6.  a designation to identify the order (Order ID)
7.  the identification code of the order assigned by the trading venue upon receipt of the order;
8.  a unique identification for each group of aggregated clients' orders (which will be subsequently placed as one block
order on a given trading venue). This identification should indicated ‘aggregated_X’ with X representing the number
of clients whose orders have been aggregated.
9.  the segment MIC code of the trading venue to which the order has been submitted.
31.3.2017
L 87/81
Official Journal of the European Union
EN

<!-- source-page: 82 -->

10.  the name and other designation of the person to whom the order was transmitted
11.  designation to identify the Seller & the Buyer
12.  the trading capacity
13.  a designation to identify the Trader (Trader ID) responsible for the execution
14.  a designation to identify the Algo (Algo ID) responsible for the execution
15.  B/S indicator;
16.  instrument identification
17.  ultimate underlying
18.  Put/Call identifier
19.  Strike price
20.  Up-front payment
21.  Delivery type
22.  Option style
23.  Maturity date
24.  unit price and price notation;
25.  price
26.  price multiplier
27.  Currency 1
28.  Currency 2
29.  remaining quantity
30.  modified quantity
31.  executed quantity
32.  the date and exact time of submission of the order or decision to deal. The exact time must be measured according
to the methodology prescribed under the standards on clock synchronisation under Article 50(2) of Directive
2014/65/EU
33.  the date and exact time of any message that is transmitted to and received from the trading venue in relation to any
events affecting an order. The exact time must be measured according to the methodology prescribed under
Commission Delegated Regulation (EU) 2017/574 (1)
34.  the date and exact time any message that is transmitted to and received from another investment firm in relation to
any events affecting an order. The exact time must be measured according to the methodology prescribed under the
standards on clock synchronisation under Article 50(2) of Directive 2014/65/EU
35.  Any message that is transmitted to and received from the trading venue in relation to orders placed by the
investment firm;
36.  Any other details and conditions that was submitted to and received from another investment firm in relation with
the order;
31.3.2017
L 87/82
Official Journal of the European Union
EN
(1) Commission Delegated Regulation (EU) 2017/574 of 7 June 2016 supplementing Directive 2014/65/EU of the European Parliament and
of the Council with regard to regulatory technical standards for the level of accuracy of business clocks (see page 148 of this Official
Journal).

<!-- source-page: 83 -->

37.  Each placed order's sequences in order to reflect the chronology of every event affecting it, including but not limited
to modifications, cancellations and execution;
38.  Short selling flag
39.  SSR exemption flag;
40.  Waiver flag
31.3.2017
L 87/83
Official Journal of the European Union
EN

---

# OJ_JOL_2014_173_R_0009_EN_TXT

Source File: OJ_JOL_2014_173_R_0009_EN_TXT.pdf
Page Count: 148
Warnings: none

<!-- source-page: 1 -->

DIRECTIVE 2014/65/EU OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL
of 15 May 2014
on markets in financial instruments and amending Directive 2002/92/EC and Directive 2011/61/EU
(recast)
(Text with EEA relevance)
THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,
Having regard to the Treaty on the Functioning of the European Union, and in particular Article 53(1) thereof,
Having regard to the proposal from the European Commission,
After transmission of the draft legislative act to the national parliaments,
Having regard to the opinion of the European Central Bank ( 1 ),
Having regard to the opinion of the European Economic and Social Committee ( 2 ),
Acting in accordance with the ordinary legislative procedure ( 3 ),
Whereas:
(1)
Directive 2004/39/EC of the European Parliament and of the Council ( 4 ) has been substantially amended several
times ( 5 ). Since further amendments are to be made, it should be recast in the interests of clarity.
(2)
Council Directive 93/22/EEC ( 6 ) sought to establish the conditions under which authorised investment firms and
banks could provide specified services or establish branches in other Member States on the basis of home country
authorisation and supervision. To that end, that Directive aimed to harmonise the initial authorisation and
operating requirements for investment firms including conduct of business rules. It also provided for the harmon­
isation of some conditions governing the operation of regulated markets.
(3)
In recent years more investors have become active in the financial markets and are offered an even more complex
wide-ranging set of services and instruments. In view of those developments the legal framework of the Union
should encompass the full range of investor-oriented activities. To that end, it is necessary to provide for the degree
of harmonisation needed to offer investors a high level of protection and to allow investment firms to provide
services throughout the Union, being an internal market, on the basis of home country supervision. Directive
93/22/EEC was therefore replaced by Directive 2004/39/EC.
(4)
The financial crisis has exposed weaknesses in the functioning and in the transparency of financial markets. The
evolution of financial markets has exposed the need to strengthen the framework for the regulation of markets in
financial instruments, including where trading in such markets takes place over-the-counter (OTC), in order to
increase transparency, better protect investors, reinforce confidence, address unregulated areas, and ensure that
supervisors are granted adequate powers to fulfil their tasks.
EN
12.6.2014
Official Journal of the European Union
L 173/349
( 1 ) OJ C 161, 7.6.2012, p. 3.
( 2 ) OJ C 191, 29.6.2012, p. 80.
( 3 ) Position of the European Parliament of 15 April 2014 (not yet published in the Official Journal) and decision of the Council of
13 May 2014.
( 4 ) Directive 2004/39/EC of the European Parliament and of the Council of 21 April 2004 on markets in financial instruments
amending Council Directives 85/611/EEC and 93/6/EEC and Directive 2000/12/EC of the European Parliament and of the
Council and repealing Council Directive 93/22/EEC (OJ L 145, 30.4.2004, p. 1).
( 5 ) See Annex III, Part A.
( 6 ) Council Directive 93/22/EEC of 10 May 1993 on investment services in the securities field (OJ L 141, 11.6.1993, p. 27).

<!-- source-page: 2 -->

(5)
There is agreement among regulatory bodies at international level that weaknesses in corporate governance in a
number of financial institutions, including the absence of effective checks and balances within them, have been a
contributory factor to the financial crisis. Excessive and imprudent risk taking may lead to the failure of individual
financial institutions and systemic problems in Member States and globally. Incorrect conduct of firms providing
services to clients may lead to investor detriment and loss of investor confidence. In order to address the poten­
tially detrimental effect of those weaknesses in corporate governance arrangements, Directive 2004/39/EC should
be supplemented by more detailed principles and minimum standards. Those principles and standards should apply
taking into account the nature, scale and complexity of investment firms.
(6)
The High-Level Group on Financial Supervision in the EU invited the Union to develop a more harmonised set of
financial regulation. In the context of the future European supervision architecture, the European Council of 18
and 19 June 2009 also stressed the need to establish a European single rulebook applicable to all financial
institutions in the internal market.
(7)
Directive 2004/39/EC should therefore now partly be recast as this Directive and partly replaced by Regulation
(EU) No 600/2014 of the European Parliament and the Council ( 1 ). Together, both legal instruments should form
the legal framework governing the requirements applicable to investment firms, regulated markets, data reporting
services providers and third country firms providing investment services or activities in the Union. This Directive
should therefore be read together with that Regulation. This Directive should contain the provisions governing the
authorisation of the business, the acquisition of qualifying holding, the exercise of the freedom of establishment
and of the freedom to provide services, the operating conditions for investment firms to ensure investor
protection, the powers of supervisory authorities of home and host Member States and the regime for
imposing sanctions. Since the main objective and subject-matter of this Directive is to harmonise national
provisions concerning the areas referred to, it should be based on Article 53(1) of the Treaty on the Functioning
of the European Union (TFEU). The form of a Directive is appropriate in order to enable the implementing
provisions in the areas covered by this Directive, when necessary, to be adjusted to any existing specificities of
the particular market and legal system in each Member State.
(8)
It is appropriate to include in the list of financial instruments commodity derivatives and others which are
constituted and traded in such a manner as to give rise to regulatory issues comparable to traditional financial
instruments.
(9)
The scope of financial instruments will include physically settled energy contracts traded on an organised trading
facility (OTF), except for those already regulated under Regulation (EU) No 1227/2011 of the European Parliament
and the Council ( 2 ). Several measures have been taken to mitigate the impact of such an inclusion on firms trading
those products. Those firms are today exempt from own funds requirements under Regulation (EU) No 575/2013
of the European Parliament and of the Council ( 3 ) and that exemption will be the subject of a review under
Article 493(1) of that Regulation before it expires at the latest at the end of 2017. Those contracts being financial
instruments, financial markets law requirements would apply from the onset, thus position limits, transaction
reporting and market abuse requirements would apply as from the date of entry into application of this Directive
and of Regulation (EU) No 600/2014. However a phasing-in period of 42 months is provided for the application
of the clearing obligation and the margining requirements set out in Regulation (EU) No 648/2012 of the
European Parliament and of the Council ( 4 ).
(10)
The limitation of the scope concerning commodity derivatives traded on an OTF and physically settled should be
limited to avoid a loophole that may lead to regulatory arbitrage. It is therefore necessary to provide for a
delegated act to further specify the meaning of the expression ‘must be physically settled’ taking into account
at least the creation of an enforceable and binding obligation to physically deliver, which cannot be unwound and
with no right to cash settle or offset transactions except in the case of force majeure, default or other bona fide
inability to perform.
EN
L 173/350
Official Journal of the European Union
12.6.2014
( 1 ) Regulation (EU) No 600/2014 of the European Parliament and the Council of 15 May 2014 on markets in financial instruments and
amending Regulation (EU) No 648/2012 (see page 84 of this Official Journal).
( 2 ) Regulation (EU) No 1227/2011 of the European Parliament and of the Council of 25 October 2011 on wholesale energy market
integrity and transparency (OJ L 326, 8.12.2011, p. 1).
( 3 ) Regulation (EU) No 575/2013 of the European Parliament and of the Council of 26 June 2013 on prudential requirements for credit
institutions and investment firms and amending Regulation (EU) No 648/2012 (OJ L 176, 27.6.2013, p. 1).
( 4 ) Regulation (EU) No 648/2012 of the European Parliament and of the Council of 4 July 2012 on OTC derivatives, central counter­
parties and trade repositories (OJ L 201, 27.7.2012, p. 1).

<!-- source-page: 3 -->

(11)
A range of fraudulent practices have occurred in spot secondary markets in emission allowances (EUA) which
could undermine trust in the emissions trading scheme, set up by Directive 2003/87/EC of the European
Parliament and of the Council ( 1 ), and measures are being taken to strengthen the system of EUA registries and
conditions for opening an account to trade EUAs. In order to reinforce the integrity and safeguard the efficient
functioning of those markets, including comprehensive supervision of trading activity, it is appropriate to
complement measures taken under Directive 2003/87/EC by bringing emission allowances fully into the scope
of this Directive and of Regulation (EU) No 600/2014 of the European Parliament and of the Council ( 2 ), by
classifying them as financial instruments.
(12)
The purpose of this Directive is to cover undertakings the regular occupation or business of which is to provide
investment services and/or perform investment activities on a professional basis. Its scope should therefore not
cover any person with a different professional activity.
(13)
It is necessary to establish a comprehensive regulatory regime governing the execution of transactions in financial
instruments irrespective of the trading methods used to conclude those transactions so as to ensure a high quality
of execution of investor transactions and to uphold the integrity and overall efficiency of the financial system. A
coherent and risk-sensitive framework for regulating the main types of order-execution arrangement currently
active in the European financial marketplace should be provided for. It is necessary to recognise the emergence of a
new generation of organised trading systems alongside regulated markets which should be subjected to obligations
designed to preserve the efficient and orderly functioning of financial markets and to ensure that such organised
trading systems do not benefit from regulatory loopholes.
(14)
All trading venues, namely regulated markets, multilateral trading facilities (MTFs), and OTFs, should lay down
transparent and non-discriminatory rules governing access to the facility. However, while regulated markets and
MTFs should continue to be subject to similar requirements regarding whom they may admit as members or
participants, OTFs should be able to determine and restrict access based, inter alia, on the role and obligations
which they have in relation to their clients. In that regard, trading venues should be able to specify parameters
governing the system such as minimum latency provided that that is done in an open and transparent manner and
does not involve discrimination by the platform operator.
(15)
A central counterparty (CCP) is defined in Regulation (EU) No 648/2012 as a legal person that interposes itself
between the parties to the contracts traded on one or more financial markets, becoming the buyer to every seller
and the seller to every buyer. CCPs are not covered by the term OTF as defined in this Directive.
(16)
Persons having access to regulated markets or MTFs are referred to as members or participants. Both terms may be
used interchangeably. Those terms do not include users who only access the trading venues via direct electronic
access.
(17)
Systematic internalisers should be defined as investment firms which, on an organised, frequent, systematic and
substantial basis, deal on own account when executing client orders outside a regulated market, an MTF or an OTF.
In order to ensure the objective and effective application of that definition to investment firms, any bilateral
trading carried out with clients should be relevant and criteria should be developed for the identification of
investment firms required to register as systematic internalisers. While trading venues are facilities in which
multiple third party buying and selling interests interact in the system, a systematic internaliser should not be
allowed to bring together third party buying and selling interests in functionally the same way as a trading venue.
(18)
Persons administering their own assets and undertakings, who do not provide investment services or perform
investment activities other than dealing on own account in financial instruments which are not commodity
derivatives, emission allowances or derivatives thereof, should not be covered by the scope of this Directive
unless they are market makers, members or participants of a regulated market or an MTF or have direct electronic
access to a trading venue, apply a high-frequency algorithmic trading technique, or deal on own account when
executing client orders.
EN
12.6.2014
Official Journal of the European Union
L 173/351
( 1 ) Directive 2003/87/EC of the European Parliament and of the Council of 13 October 2003 establishing a scheme for greenhouse gas
emission allowance trading within the Community and amending Council Directive 96/61/EC (OJ L 275, 25.10.2003, p. 32).
( 2 ) Regulation (EU) No 596/2014 of the European Parliament and of the Council of 16 April 2014 on market abuse (market abuse
Regulation) and repealing Directive 2003/6/EC of the European Parliament and of the Council and Commission Directives
2003/124/EC, 2003/125/EC and 2004/72/EC (see page 1 of this Official Journal).

<!-- source-page: 4 -->

(19)
The communiqué of the G20 finance ministers and central bank governors of 15 April 2011 states that
participants on commodity derivatives markets should be subject to appropriate regulation and supervision and
therefore certain exemptions from Directive 2004/39/EC are to be modified.
(20)
Persons who deal on own account, including market makers, in commodity derivatives, emission allowances or
derivatives thereof, excluding persons who deal on own account when executing client orders, or who provide
investment services in commodity derivatives or emission allowances or derivatives thereof to the customers or
suppliers of their main business should not be covered by the scope of this Directive, provided that that activity is
an ancillary activity to their main business on a group basis, and that main business is neither the provision of
investment services within the meaning of this Directive nor of banking activities within the meaning of Directive
2013/36/EU of the European Parliament and of the Council ( 1 ), nor market making in commodity derivatives, and
those persons do not apply a high-frequency algorithmic trading technique. Technical criteria for when an activity
is ancillary to such a main business should be clarified in regulatory technical standards, taking into account the
criteria specified in this Directive.
Those criteria should ensure that non-financial firms dealing in financial instruments in a disproportionate manner
compared with the level of investment in the main business are covered by the scope of this Directive. In doing so,
those criteria should take at least into consideration, the need for ancillary activities to constitute a minority of
activities at group level and the size of their trading activity compared to the overall market trading activity in that
asset class. It is appropriate that where the obligation to provide liquidity on a venue is required by regulatory
authorities in accordance with Union or national laws, regulations and administrative provisions or by trading
venues, the transactions entered into to meet such an obligation should be excluded in the assessment of whether
the activity is ancillary.
(21)
For the purposes of this Directive and of Regulation (EU) No 600/2014, which regulate both OTC and exchange-
traded derivatives within the meaning of Regulation (EU) No 600/2014, activities that are deemed to be objectively
measurable as reducing risks directly relating to the commercial activity or treasury financing activity and
intragroup transactions should be considered in a consistent way with Regulation (EU) No 648/2012.
(22)
Persons that deal in commodity derivatives, emission allowance and derivatives thereof may also deal in other
financial instruments as part of their commercial treasury risk management activities to protect themselves against
risks, such as exchange rate risks. Therefore, it is important to clarify that exemptions apply cumulatively. For
example, the exemption in point (j) of Article 2(1) can be used in conjunction with the exemption in point (d) of
Article 2(1).
(23)
However, in order to avoid any potential misuse of exemptions, market makers in financial instruments, other than
market makers in commodity derivatives, emission allowances or derivatives thereof provided that their market
making activity is ancillary to their main business considered on a group basis and provided that they do not apply
a high-frequency algorithmic trading technique, should be covered by the scope of this Directive and should not
benefit from any exemption. Persons dealing on own account when executing client orders or applying a high-
frequency algorithmic trading technique should also be covered by the scope of this Directive and should not
benefit from any exemption.
(24)
Dealing on own account when executing client orders should include firms executing orders from different clients
by matching them on a matched principal basis (back-to-back trading), which should be regarded as acting as
principal and should be subject to the provisions of this Directive covering both the execution of orders on behalf
of clients and dealing on own account.
(25)
The execution of orders in financial instruments as an ancillary activity between two persons whose main business,
on a group basis, is neither the provision of investment services within the meaning of this Directive nor of
banking activities within the meaning of Directive 2013/36/EU should not be considered to be dealing on own
account when executing client orders.
EN
L 173/352
Official Journal of the European Union
12.6.2014
( 1 ) Directive 2013/36/EU of the European Parliament and of the Council of 26 June 2013 on access to the activity of credit institutions
and prudential supervision of credit institutions and investment firms, amending Directive 2002/87/EC and repealing Directives
2006/48/EC and 2006/49/EC (OJ L 176, 27.6.2013, p. 338).

<!-- source-page: 5 -->

(26)
References in the text to persons should be understood as including both natural and legal persons.
(27)
Insurance or assurance undertakings the activities of which are subject to appropriate monitoring by the competent
prudential-supervision authorities and which are subject to Directive 2009/138/EC of the European Parliament and
of the Council ( 1 ) should be excluded from the scope of this Directive when carrying out the activities referred to in
that Directive.
(28)
Persons who do not provide services for third parties but whose business consists in providing investment services
solely for their parent undertakings, for their subsidiaries, or for other subsidiaries of their parent undertakings
should not be covered by this Directive.
(29)
Some local energy utilities and some operators of industrial installations covered by the EU Emissions Trading
Scheme bundle and out-source their trading activities for hedging commercial risks to non-consolidated subsidi­
aries. Those joint venture companies do not provide any other services and perform exactly the same function as
the persons referred to in Recital 28. In order to ensure a level playing field, it should also be possible to exclude
joint venture companies from the scope of this Directive if they are jointly held by local energy utilities or
operators falling within point (f) of Article 3 of Directive 2003/87/EC who do not provide any services other
than investment services for local energy utilities or operators falling within point (f) of Article 3 of Directive
2003/87/EC, and provided that those local energy utilities or those operators will be exempt under point (j) of
Article 2(1) should they carry out those investment services themselves. However, in order to ensure that the
appropriate safeguards are in place and that investors are adequately protected, Member States that choose to
exempt such joint ventures should subject them to requirements at least analogous to the ones laid down in this
Directive, in particular during the phase of authorisation, in the assessment of their reputation and experience and
of the suitability of any shareholders, in the review of the conditions for initial authorisation and on-going
supervision as well as on conduct of business obligations.
(30)
Persons who provide investment services only on an incidental basis in the course of professional activity should
also be excluded from the scope of this Directive, provided that that activity is regulated and the relevant rules do
not prohibit the provision, on an incidental basis, of investment services.
(31)
Persons who provide investment services consisting exclusively in the administration of employee-participation
schemes and who therefore do not provide investment services for third parties should not be covered by this
Directive.
(32)
It is necessary to exclude from the scope of this Directive central banks and other bodies performing similar
functions as well as public bodies charged with or intervening in the management of public debt, which concept
covers the investment thereof, with the exception of bodies that are partly or wholly state-owned the role of which
is commercial or linked to the acquisition of holdings.
(33)
In order to clarify the regime of exemptions for the European System of Central Banks (ESCB), other national
bodies performing similar functions and bodies intervening in the management of public debt, it is appropriate to
limit such exemptions to the bodies and institutions performing their functions in accordance with the law of one
Member State or in accordance with the Union law, as well as to international bodies of which two or more
Member States are members and which have the purpose of mobilising funding and providing financial assistance
to the benefit of their members that are experiencing or threatened by severe financing problems, such as the
European Stability Mechanism.
(34)
It is necessary to exclude from the scope of this Directive collective investment undertakings and pension funds
whether or not coordinated at Union level, and the depositaries or managers of such undertakings, since they are
subject to specific rules directly adapted to their activities.
EN
12.6.2014
Official Journal of the European Union
L 173/353
( 1 ) Directive 2009/138/EC of the European Parliament and of the Council of 25 November 2009 on the taking-up and pursuit of the
business of Insurance and Reinsurance (Solvency II) (OJ L 335, 17.12.2009, p. 1).

<!-- source-page: 6 -->

(35)
It is necessary to exclude from the scope of this Directive transmission system operators as defined in Article 2(4)
of Directive 2009/72/EC of the European Parliament and of the Council ( 1 ) or Article 2(4) of Directive 2009/73/EC
of the European Parliament and of the Council ( 2 ) when carrying out their tasks under those Directives, under
Regulation (EC) No 714/2009 of the European Parliament and of the Council ( 3 ), under Regulation (EC)
No 715/2009 of the European Parliament and of the Council ( 4 ) or under network codes or guidelines adopted
pursuant to those legislative acts. In accordance with those legislative acts, transmission system operators have
specific obligations and responsibilities, are subject to specific certification and are supervised by sector specific
competent authorities. Transmission system operators should also benefit from such an exemption where they use
other persons acting as service providers on their behalf to carry out their task under those legislative acts or under
network codes or guidelines adopted pursuant to those Regulations. Transmission system operators should not be
able to benefit from such an exemption when providing investment services or activities in financial instruments,
including when operating a platform for secondary trading in financial transmission rights.
(36)
In order to benefit from the exemptions from this Directive, the person concerned should comply on a continuous
basis with the conditions laid down for such exemptions. In particular, if a person provides investment services or
performs investment activities and is exempt from this Directive because such services or activities are ancillary to
that person’s main business, when considered on a group basis, that person should no longer be covered by the
exemption relating to ancillary services where the provision of those services or activities ceases to be ancillary to
that person’s main business.
(37)
Persons who provide the investment services and/or perform investment activities covered by this Directive should
be subject to authorisation by their home Member States in order to protect investors and the stability of the
financial system.
(38)
Credit institutions that are authorised under Directive 2013/36/EU should not need another authorisation under
this Directive in order to provide investment services or perform investment activities. When a credit institution
decides to provide investment services or perform investment activities the competent authorities, before granting
an authorisation under Directive 2013/36/EU, should verify that it complies with the relevant provisions of this
Directive.
(39)
Structured deposits have emerged as a form of investment product but are not covered under any legislative act for
the protection of investors at Union level, while other structured investments are covered by such legislative acts. It
is therefore appropriate to strengthen the confidence of investors and to make regulatory treatment concerning the
distribution of different packaged retail investment products more uniform in order to ensure an adequate level of
investor protection across the Union. For that reason, it is appropriate to include in the scope of this Directive
structured deposits. In this regard, it is necessary to clarify that since structured deposits are a form of investment
product, they do not include deposits linked solely to interest rates, such as Euribor or Libor, regardless of whether
or not the interest rates are predetermined, or whether they are fixed or variable. Such deposits should therefore be
excluded from the scope of this Directive.
(40)
The application of this Directive to investment firms and credit institutions when selling or advising clients in
relation to structured deposits, should be understood as when acting as intermediaries for those products issued by
credit institutions that can take deposits in accordance with Directive 2013/36/EU.
(41)
Central securities depositaries (CSDs) are systemically important institutions for financial markets that ensure the
initial recording of securities, the maintenance of the accounts containing the securities issued and the settlement
of virtually all trades of securities. CSDs are to be specifically regulated under Union law and subject, in particular,
to authorisation and certain operating conditions. However, CSDs might, in addition to the core services referred
to in other Union law, provide investment services and activities which are regulated under this Directive.
EN
L 173/354
Official Journal of the European Union
12.6.2014
( 1 ) Directive 2009/72/EC of the European Parliament and of the Council of 13 July 2009 concerning common rules for the internal
market in electricity and repealing Directive 2003/54/EC (OJ L 211, 14.8.2009, p. 55).
( 2 ) Directive 2009/73/EC of the European Parliament and of the Council of 13 July 2009 concerning common rules for the internal
market in natural gas and repealing Directive 2003/55/EC (OJ L 211, 14.8.2009, p. 94).
( 3 ) Regulation (EC) No 714/2009 of the European Parliament and of the Council of 13 July 2009 on conditions for access to the
network for cross-border exchanges in electricity and repealing Regulation (EC) No 1228/2003 (OJ L 211, 14.8.2009, p. 15).
( 4 ) Regulation (EC) No 715/2009 of the European Parliament and of the Council of 13 July 2009 on conditions for access to the natural
gas transmission networks and repealing Regulation (EC) No 1775/2005 (OJ L 211, 14.8.2009, p. 36).

<!-- source-page: 7 -->

In order to ensure that any entities providing investment services and activities are subject to the same regulatory
framework, it is appropriate to ensure that such CSDs are not subject to the requirements of this Directive relating
to authorisation and certain operating conditions but that Union law regulating CSDs as such should ensure that
they are subject to the provisions of this Directive when they provide investment services or perform investment
activities in addition to the services specified in that Union law.
(42)
In order to strengthen the protection of investors in the Union, it is appropriate to limit the conditions under
which Member States may exclude the application of this Directive to persons providing investment services to
clients who, as a result, are not protected under this Directive. In particular, it is appropriate to require Member
States to apply requirements at least analogous to the ones laid down in this Directive to those persons, in
particular during the phase of authorisation, in the assessment of their reputation and experience and of the
suitability of any shareholders, in the review of the conditions for initial authorisation and on-going supervision as
well as on conduct of business obligations.
In addition, persons excluded from the application of this Directive should be covered under an investor compen­
sation scheme recognised in accordance with Directive 97/9/EC of the European Parliament and of the Council ( 1 )
or professional indemnity insurance ensuring equivalent protection to their clients in the situations covered under
that Directive.
(43)
Where an investment firm provides one or more investment services not covered by its authorisation, or performs
one or more investment activities not covered by its authorisation, on a non-regular basis it should not need an
additional authorisation under this Directive.
(44)
For the purposes of this Directive, the business of reception and transmission of orders should also include
bringing together two or more investors, thereby bringing about a transaction between those investors.
(45)
Investment firms and credit institutions distributing financial instruments they issue themselves should be subject
to this Directive when they provide investment advice to their clients. In order to eliminate uncertainty and
strengthen investor protection, it is appropriate to provide for the application of this Directive when, in the
primary market, investment firms and credit institutions distribute financial instruments issued by them without
providing any advice. To that end, the definition of the service of execution of orders on behalf of clients should
be extended.
(46)
The principles of mutual recognition and of home Member State supervision require that the Member States’
competent authorities should not grant or should withdraw authorisation where factors such as the content of
programmes of operations, the geographical distribution or the activities actually carried on indicate clearly that an
investment firm has opted for the legal system of one Member State for the purpose of evading the stricter
standards in force in another Member State within the territory of which it intends to carry out or does carry out
the greater part of its activities. An investment firm which is a legal person should be authorised in the Member
State in which it has its registered office. An investment firm which is not a legal person should be authorised in
the Member State in which it has its head office. In addition, Member States should require that an investment
firm’s head office is always situated in its home Member State and that it actually operates there.
(47)
Directive 2007/44/EC of the European Parliament and of the Council ( 2 ) has provided for detailed criteria for the
prudential assessment of proposed acquisitions in an investment firm and for a procedure for their application. In
order to provide legal certainty, clarity and predictability with regard to the assessment process, as well as to the
result thereof, it is appropriate to confirm the criteria and the process of prudential assessment laid down in that
Directive.
EN
12.6.2014
Official Journal of the European Union
L 173/355
( 1 ) Directive 97/9/EC of the European Parliament and of the Council of 3 March 1997 on investor-compensation schemes (OJ L 84,
26.3.1997, p. 22).
( 2 ) Directive 2007/44/EC of the European Parliament and of the Council of 5 September 2007 amending Council Directive 92/49/EEC
and Directives 2002/83/EC, 2004/39/EC, 2005/68/EC and 2006/48/EC as regards procedural rules and evaluation criteria for the
prudential assessment of acquisitions and increase of holdings in the financial sector (OJ L 247, 21.9.2007, p. 1).

<!-- source-page: 8 -->

In particular, competent authorities should appraise the suitability of the proposed acquirer and the financial
soundness of the proposed acquisition against all of the following criteria: the reputation of the proposed
acquirer; the reputation and experience of any person who will direct the business of the investment firm as a
result of the proposed acquisition; the financial soundness of the proposed acquirer; whether the investment firm
will be able to comply with the prudential requirements based on this Directive and on other Directives, in
particular, on Directives 2002/87/EC of the European Parliament and of the Council ( 1 ) and 2013/36/EU; whether
there are reasonable grounds to suspect that money laundering or terrorist financing within the meaning of
Article 1 of Directive 2005/60/EC of the European Parliament and of the Council ( 2 ) is being or has been
committed or attempted, or that the proposed acquisition could increase the risk thereof.
(48)
An investment firm authorised in its home Member State should be entitled to provide investment services or
perform investment activities throughout the Union without the need to seek a separate authorisation from the
competent authority in the Member State in which it wishes to provide such services or perform such activities.
(49)
Since certain investment firms are exempt from certain obligations imposed by Directive 2013/36/EU, they should
be obliged to hold either a minimum amount of capital or professional indemnity insurance or a combination of
both. The adjustments of the amounts of that insurance should take into account adjustments made in the
framework of Directive 2002/92/EC of the European Parliament and of the Council ( 3 ). That particular
treatment for the purposes of capital adequacy should be without prejudice to any decisions regarding the
appropriate treatment of those firms under future changes to Union law on capital adequacy.
(50)
Since the scope of prudential regulation should be limited to those entities which, by virtue of running a trading
book on a professional basis, represent a source of a counterparty risk to other market participants, entities which
deal on own account in financial instruments other than commodity derivatives, emission allowances or derivatives
thereof, should be excluded from the scope of this Directive provided that they are not market makers, do not deal
on own account when executing client orders, are not members or participants of a regulated market or MTF, do
not have direct electronic access to a trading venue and do not apply a high-frequency algorithmic trading
technique.
(51)
In order to protect an investor’s ownership and other similar rights in respect of securities and the investor’s rights
in respect of funds entrusted to a firm, those rights should in particular be kept distinct from those of the firm.
This principle should not, however, prevent a firm from doing business in its name but on behalf of the investor,
where that is required by the very nature of the transaction and the investor is in agreement, for example stock
lending.
(52)
The requirements concerning the protection of client assets are a crucial tool for the protection of clients in the
provision of services and activities. Those requirements can be excluded when full ownership of funds and financial
instrument is transferred to an investment firm to cover any present or future, actual or contingent or prospective
obligations. That broad possibility may create uncertainty and jeopardise the effectiveness of the requirements
concerning the safeguard of client assets. Thus, at least when retail client assets are involved, it is appropriate to
limit the possibility of investment firms to conclude title transfer financial collateral arrangements as defined under
Directive 2002/47/EC of the European Parliament and of the Council ( 4 ), for the purpose of securing or otherwise
covering their obligations.
(53)
It is necessary to strengthen the role of management bodies of investment firms, regulated markets and data
reporting services providers in ensuring sound and prudent management of the firms, the promotion of the
integrity of the market and the interest of investors. The management body of an investment firm, regulated
markets and data reporting services providers should at all times commit sufficient time and possess adequate
EN
L 173/356
Official Journal of the European Union
12.6.2014
( 1 ) Directive 2002/87/EC of the European Parliament and of the Council of 16 December 2002 on the supplementary supervision of
credit institutions, insurance undertakings and investment firms in a financial conglomerate and amending Council Directives
73/239/EEC, 79/267/EEC, 92/49/EEC, 92/96/EEC, 93/6/EEC and 93/22/EEC, and Directives 98/78/EC and 2000/12/EC of the
European Parliament and of the Council (OJ L 35, 11.2.2003, p. 1).
( 2 ) Directive 2005/60/EC of the European Parliament and of the Council of 26 October 2005 on the prevention of the use of financial
system for the purpose of money laundering and terrorist financing (OJ L 309, 25.11.2005, p. 15).
( 3 ) Directive 2002/92/EC of the European Parliament and of the Council of 9 December 2002 on insurance mediation (OJ L 9,
15.1.2003, p. 3).
( 4 ) Directive 2002/47/EC of the European Parliament and of the Council of 6 June 2002 on financial collateral arrangements (OJ L 168,
27.6.2002, p. 43).

<!-- source-page: 9 -->

collective knowledge, skills and experience to be able to understand the firm’s activities including the main risks.
To avoid group thinking and facilitate independent opinions and critical challenge, management bodies should
therefore be sufficiently diverse as regards age, gender, geographic provenance and educational and professional
background to present a variety of views and experiences. Employee representation in management bodies could
also, by adding a key perspective and genuine knowledge of the internal workings of firms, be seen as a positive
way of enhancing diversity. Therefore, diversity should be one of the criteria for the composition of management
bodies. Diversity should also be addressed in firms’ recruitment policy more generally. That policy should, for
instance, encourage firms to select candidates from shortlists including both genders. In the interests of a coherent
approach to corporate governance it is desirable to align the requirements for investment firms as far as possible to
those included in Directive 2013/36/EU.
(54)
In order to have an effective oversight and control over the activities of investment firms, regulated markets and
data reporting services providers, the management body should be responsible and accountable for the overall
strategy of the firm, taking into account the firm’s business and risk profile. The management body should assume
clear responsibilities across the business cycle of the firm, in the areas of the identification and definition of the
strategic objectives, risk strategy and internal governance of the firm, of the approval of its internal organisation,
including criteria for selection and training of personnel, of effective oversight of senior management, of the
definition of the overall policies governing the provision of services and activities, including the remuneration of
sales staff and the approval of new products for distribution to clients. Periodic monitoring and assessment of the
strategic objectives of firms, their internal organisation and their policies for the provision of services and activities
should ensure their continuous ability to deliver sound and prudent management, in the interest of the integrity of
the markets and the protection of investors. Combining too high a number of directorships would preclude a
member of the management body from spending adequate time on the performance of that oversight role.
Therefore, it is necessary to limit the number of directorships a member of the management body of an institution
may hold at the same time in different entities. However, directorships in organisations which do not pursue
predominantly commercial objectives, such as not-for-profit or charitable organisations, should not be taken into
account for the purposes of applying such a limit.
(55)
Different governance structures are used across Member States. In most cases a unitary or a dual board structure is
used. The definitions used in this Directive are intended to embrace all existing structures without advocating any
particular structure. They are purely functional for the purpose of setting out rules aiming to achieve a particular
outcome irrespective of the national company law applicable to an institution in each Member State. The
definitions should therefore not interfere with the general allocation of competences in accordance with
national company law.
(56)
The expanding range of activities that many investment firms undertake simultaneously has increased potential for
conflicts of interest between those different activities and the interests of their clients. It is therefore necessary to
provide for rules to ensure that such conflicts do not adversely affect the interests of their clients. Firms have a
duty to take effective steps to identify and prevent or manage conflicts of interest and mitigate the potential impact
of those risks as far as possible. Where some residual risk of detriment to the client’s interests nonetheless remains,
clear disclosure to the client of the general nature and/or sources of conflicts of interest to the client and the steps
taken to mitigate those risks should be made before undertaking business on its behalf.
(57)
Commission Directive 2006/73/EC ( 1 ) allows Member States to require, in the context of organisational
requirements for investment firms, the recording of telephone conversations or electronic communications
involving client orders. Recording of telephone conversations or electronic communications involving client
orders is compatible with the Charter of Fundamental Rights of the European Union (the Charter) and is
justified in order to strengthen investor protection, to improve market surveillance and increase legal certainty
in the interest of investment firms and their clients. The importance of such records is also referred to in the
technical advice to the Commission, released by the Committee of European Securities Regulators on 29 July
2010. Such records should ensure that there is evidence to prove the terms of any orders given by clients and its
correspondence with transactions executed by the investment firms, as well as to detect any behaviour that may
have relevance in terms of market abuse, including when firms deal on own account.
EN
12.6.2014
Official Journal of the European Union
L 173/357
( 1 ) Commission Directive 2006/73/EC of 10 August 2006 implementing Directive 2004/39/EC of the European Parliament and of the
Council as regards organisational requirements and operating conditions for investment firms and defined terms for the purposes of
that Directive (OJ L 241, 2.9.2006, p. 26).

<!-- source-page: 10 -->

To that end records are needed for all conversations involving a firm’s representatives when dealing, or intending
to deal, on own account. Where orders are communicated by clients through other channels than by telephone,
such communications should be made in a durable medium such as mails, faxes, emails, documentation of client
orders made at meetings. For example, the content of relevant face-to-face conversations with a client could be
recorded by using written minutes or notes. Such orders should be considered to be equivalent to orders received
by telephone. Where minutes are taken of face-to-face conversations with clients, Member States should ensure
that appropriate safeguards are in place to ensure that the client does not lose out as a result of the minutes
inaccurately recording the communication between the parties. Such safeguards should not imply any assumption
of liability by the client.
In order to provide legal certainty regarding the scope of the obligation, it is appropriate to apply it to all
equipment provided by the firm or permitted to be used by the investment firm and to require the investment
firms to take reasonable steps to ensure that no privately owned equipment is used in relation to transactions.
Those records should be available to competent authorities in the fulfilment of their supervisory tasks and in the
performance of enforcement actions under this Directive and under Regulation (EU) No 600/2014, Regulation (EU)
No 596/2014 and Directive 2014/57/EU of the European Parliament and of the Council ( 1 ) in order to help
competent authorities identify behaviours which are not compliant with the legal framework regulating the activity
of investment firms. Those records should also be available to investment firms and to clients to demonstrate the
development of their relationship with regard to orders transmitted by clients and transaction carried out by firms.
For those reasons, it is appropriate to provide in this Directive for the principles of a general regime concerning the
recording of telephone conversations or electronic communications involving client orders.
(58)
In line with Council conclusions on strengthening European financial supervision of June 2009, and in order to
contribute to the establishment of a single rulebook for Union financial markets, to help further develop a level
playing field for Member States and market participants, to enhance investor protection and to improve super­
vision and enforcement, the Union is committed to minimising, where appropriate, discretions available to
Member States across Union financial services law. In addition to the introduction in this Directive of a
common regime for the recording of telephone conversations or electronic communications involving client
orders, it is appropriate to reduce the possibility of competent authorities to delegate supervisory tasks in
certain cases, to limit discretions in the requirements applicable to tied agents and to the reporting from branches.
(59)
The use of trading technology has evolved significantly in the past decade and is now extensively used by market
participants. Many market participants now make use of algorithmic trading where a computer algorithm auto­
matically determines aspects of an order with minimal or no human intervention. Risks arising from algorithmic
trading should be regulated. However, the use of algorithms in post-trade processing of executed transactions does
not constitute algorithmic trading. An investment firm that engages in algorithmic trading pursuing a market
making strategy should carry out that market making continuously during a specified proportion of the trading
venue’s trading hours. Regulatory technical standards should clarify what constitutes specified proportion of the
trading venue’s trading hours by ensuring that such specified proportion is significant in comparison to the total
trading hours, taking into account the liquidity, scale and nature of the specific market and the characteristics of
the financial instrument traded.
(60)
Investment firms that engage in algorithmic trading pursuing a market making strategy should have in place
appropriate systems and controls for that activity. Such an activity should be understood in a way specific to its
context and purpose. The definition of such an activity is therefore independent from definitions such as that of
‘market making activities’ in Regulation (EU) No 236/2012 of the European Parliament and of the Council ( 2 ).
(61)
A specific subset of algorithmic trading is high-frequency algorithmic trading where a trading system analyses data
or signals from the market at high speed and then sends or updates large numbers of orders within a very short
time period in response to that analysis. In particular, high-frequency algorithmic trading may contain elements
such as order initiation, generating, routing and execution which are determined by the system without human
intervention for each individual trade or order, short time-frame for establishing and liquidating positions, high
daily portfolio turnover, high order-to-trade ratio intraday and ending the trading day at or close to a flat position.
High-frequency algorithmic trading is characterised, among others, by high message intra-day rates which
EN
L 173/358
Official Journal of the European Union
12.6.2014
( 1 ) Directive 2014/57/EU of the European Parliament and of the Council of 16 April 2014 on criminal sanctions for market abuse
(market abuse Directive) (see page 179 of this Official Journal).
( 2 ) Regulation (EU) No 236/2012 of the European Parliament and of the Council of 14 March 2012 on short selling and certain aspects
of credit default swaps (OJ L 86, 24.3.2012, p. 1).

<!-- source-page: 11 -->

constitute orders, quotes or cancellations. In determining what constitutes high message intra-day rates, the identity
of the client ultimately behind the activity, the length of the observation period, the comparison with the overall
market activity during that period and the relative concentration or fragmentation of activity should be taken into
account. High-frequency algorithmic trading is typically done by the traders using their own capital to trade and
rather than being a strategy in itself is usually the use of sophisticated technology to implement more traditional
trading strategies such as market making or arbitrage.
(62)
Technical advances have enabled high-frequency trading and an evolution of business models. High-frequency
trading is facilitated by the co-location of market participants’ facilities in close physical proximity to a trading
venue’s matching engine. In order to ensure orderly and fair trading conditions, it is essential to require trading
venues to provide such co-location services on a non-discriminatory, fair and transparent basis. The use of trading
technology has increased the speed, capacity and complexity of how investors trade. It has also enabled market
participants to facilitate direct electronic access by their clients to markets through the use of their trading facilities,
through direct market access or sponsored access. Trading technology has provided benefits to the market and
market participants generally such as wider participation in markets, increased liquidity, narrower spreads, reduced
short term volatility and the means to obtain better execution of orders for clients. Yet that trading technology also
gives rise to a number of potential risks such as an increased risk of the overloading of the systems of trading
venues due to large volumes of orders, risks of algorithmic trading generating duplicative or erroneous orders or
otherwise malfunctioning in a way that may create a disorderly market.
In addition, there is the risk of algorithmic trading systems overreacting to other market events which can
exacerbate volatility if there is a pre-existing market problem. Finally, algorithmic trading or high-frequency
algorithmic trading techniques can, like any other form of trading, lend themselves to certain forms of
behaviour which is prohibited under Regulation (EU) No 596/2014. High-frequency trading may also, because
of the information advantage provided to high-frequency traders, prompt investors to choose to execute trades in
venues where they can avoid interaction with high-frequency traders. It is appropriate to subject high-frequency
algorithmic trading techniques which rely on certain specified characteristics to particular regulatory scrutiny.
While those are predominantly techniques which rely on trading on own account such scrutiny should also
apply where the execution of the technique is structured in such a way as to avoid the execution taking place
on own account.
(63)
Those potential risks from increased use of technology are best mitigated by a combination of measures and
specific risk controls directed at firms that engage in algorithmic trading or high-frequency algorithmic trading
techniques, those that provide direct electronic access, and other measures directed at operators of trading venues
that are accessed by such firms. In order to strengthen the resilience of markets in the light of technological
developments, those measures should reflect and build on the technical guidelines issued by the European
Supervisory Authority (European Securities and Markets Authority) (‘ESMA’), established by Regulation (EU)
No 1095/2010 of the European Parliament and of the Council ( 1 ) in February 2012 on systems and controls in
an automated trading environment for trading platforms, investment firms and competent authorities
(ESMA/2012/122). It is desirable to ensure that all high-frequency algorithmic trading firms be authorised. Such
authorisation should ensure those firms are subject to organisational requirements under this Directive and that
they are properly supervised. However, entities which are authorised and supervised under Union law regulating
the financial sector and are exempt from this Directive, but which engage in algorithmic trading or high-frequency
algorithmic trading techniques, should not be required to obtain an authorisation under this Directive and should
only be subject to the measures and controls aiming to tackle the specific risk arising from those types of trading.
In that respect, ESMA should play an important coordinating role by defining appropriate tick sizes in order to
ensure orderly markets at Union level.
(64)
Both investment firms and trading venues should ensure robust measures are in place to ensure that algorithmic
trading or high-frequency algorithmic trading techniques do not create a disorderly market and cannot be used for
abusive purposes. Trading venues should also ensure their trading systems are resilient and properly tested to deal
with increased order flows or market stresses and that circuit breakers are in place on trading venues to
temporarily halt trading or constrain it if there are sudden unexpected price movements.
(65)
It is also necessary to ensure that the fee structures of trading venues are transparent, non-discriminatory and fair
and that they are not structured in such a way as to promote disorderly market conditions. It is therefore
EN
12.6.2014
Official Journal of the European Union
L 173/359
( 1 ) Regulation (EU) No 1095/2010 of the European Parliament and of the Council of 24 November 2010 establishing a European
Supervisory Authority (European Securities and Markets Authority), amending Decision No 716/2009/EC and repealing Commission
Decision 2009/77/EC (OJ L 331, 15.12.2010, p. 84).

<!-- source-page: 12 -->

appropriate to allow for trading venues to adjust their fees for cancelled orders according to the length of time for
which the order was maintained and to calibrate the fees to each financial instrument to which they apply.
Member States should also be able to allow trading venues to impose higher fees for placing orders that are
subsequently cancelled or on participants placing a high ratio of cancelled orders and on those operating a high-
frequency algorithmic trading technique in order to reflect the additional burden on system capacity without
necessarily benefitting other market participants.
(66)
In addition to measures relating to algorithmic and high-frequency algorithmic trading techniques it is appropriate
to ban the provision of direct electronic access to markets by investment firms for their clients where such access
is not subject to proper systems and controls. Irrespective of the form of the direct electronic access provided,
firms providing such access should assess and review the suitability of clients using that service and ensure that risk
controls are imposed on the use of the service and that those firms retain responsibility for trading submitted by
their clients through the use of their systems or using their trading codes. It is appropriate that detailed organi­
sational requirements regarding those new forms of trading should be prescribed in more detail in regulatory
technical standards. This should ensure that requirements can be amended where necessary to deal with further
innovation and developments in that area.
(67)
In order to ensure effective supervision and in order to enable the competent authorities to take appropriate
measures against defective or rogue algorithmic strategies in due time it is necessary to flag all orders generated by
algorithmic trading. By means of flagging, competent authorities should be enabled to identify and distinguish
orders originating from different algorithms and to reconstruct efficiently and evaluate the strategies that algo­
rithmic traders employ. This should mitigate the risk that orders are not unambiguously attributed to an algo­
rithmic strategy and a trader. The flagging permits the competent authorities to react efficiently and effectively
against algorithmic trading strategies that behave in an abusive manner or pose risks to the orderly functioning of
the market.
(68)
In order to ensure that market integrity is maintained in the light of technological developments in financial
markets, ESMA should regularly seek input from national experts on developments relating to trading technology
including high-frequency trading and new practices which could constitute market abuse, so as to identify and
promote effective strategies for preventing and addressing such abuse.
(69)
There is a multitude of trading venues currently operating in the Union, among which a number are trading
identical financial instruments. In order to address potential risks to the interests of investors it is necessary to
formalise and further coordinate the processes on the consequences for trading on other trading venues if an
investment firm or a market operator operating a trading venue decides to suspend or remove a financial
instrument from trading. In the interest of legal certainty and to adequately address conflicts of interests when
deciding to suspend or to remove financial instruments from trading, it should be ensured that if an investment
firm or a market operator operating a trading venue stops trading due to non-compliance with their rules, the
others follow that decision if it is decided so by their competent authorities unless continuing trading may be
justified due to exceptional circumstances. In addition, it is necessary to formalise and improve the exchange of
information and the cooperation between the competent authorities in relation to suspension and removal of
financial instruments from trading on a trading venue. Those arrangements should be applied in such a way as to
prevent trading venues using information transmitted in the context of a suspension or removal of a financial
instrument from trading for commercial purposes.
(70)
More investors have become active in the financial markets and are offered a more complex wide-ranging set of
services and instruments and, in view of those developments, it is necessary to provide for a degree of harmon­
isation to offer investors a high level of protection across the Union. When Directive 2004/39/EC was adopted, the
increasing dependence of investors on personal recommendations required to include the provision of investment
advice as an investment service subject to authorisation and to specific conduct of business obligations. The
continuous relevance of personal recommendations for clients and the increasing complexity of services and
instruments require enhancing the conduct of business obligations in order to strengthen the protection of
investors.
(71)
Member States should ensure that investment firms act in accordance with the best interests of their clients and are
able to comply with their obligations under this Directive. Investment firms should accordingly understand the
features of the financial instruments offered or recommended and establish and review effective policies and
EN
L 173/360
Official Journal of the European Union
12.6.2014

<!-- source-page: 13 -->

arrangements to identify the category of clients to whom products and services are to be provided. Member States
should ensure that the investment firms which manufacture financial instruments ensure that those products are
manufactured to meet the needs of an identified target market of end clients within the relevant category of clients,
take reasonable steps to ensure that the financial instruments are distributed to the identified target market and
periodically review the identification of the target market of and the performance of the products they offer.
Investment firms that offer or recommend to clients financial instruments not manufactured by them should also
have appropriate arrangements in place to obtain and understand the relevant information concerning the product
approval process, including the identified target market and the characteristics of the product they offer or
recommend. That obligation should apply without prejudice to any assessment of appropriateness or suitability
to be subsequently carried out by the investment firm in the provision of investment services to each client, on the
basis of their personal needs, characteristics and objectives.
In order to ensure that financial instruments will be offered or recommended only when in the interest of the
client, investment firms offering or recommending the product manufactured by firms which are not subject to the
product governance requirements set out in this Directive or manufactured by third-country firms should also have
appropriate arrangements to obtain sufficient information about the financial instruments.
(72)
In order to give all relevant information to investors, it is appropriate to require investment firms providing
investment advice to disclose the cost of the advice, to clarify the basis of the advice they provide, in particular the
range of products they consider in providing personal recommendations to clients, whether they provide
investment advice on an independent basis and whether they provide the clients with the periodic assessment
of the suitability of the financial instruments recommended to them. It is also appropriate to require investment
firms to explain to their clients the reasons for the advice provided to them.
(73)
In order to further establish the regulatory framework for the provision of investment advice, while at the same
time leaving choice to investment firms and clients, it is appropriate to establish the conditions for the provisions
of that service when firms inform clients that the service is provided on an independent basis. When advice is
provided on an independent basis a sufficient range of different product providers’ products should be assessed
prior to making a personal recommendation. It is not necessary for the advisor to assess investment products
available on the market by all product providers or issuers, but the range of financial instruments should not be
limited to financial instruments issued or provided by entities with close links with the investment firm or with
other legal or economic relationships, such as a contractual relationship, that are so close as to put at risk the
independent basis of the advice provided.
(74)
In order to strengthen the protection of investors and increase clarity to clients as to the service they receive, it is
also appropriate to further restrict the possibility for firms providing the service of investment advice on an
independent basis and the service of portfolio management to accept and retain fees, commissions or any
monetary and non-monetary benefits from third parties, and particularly from issuers or product providers.
This implies that all fees, commissions and any monetary benefits paid or provided by a third party must be
returned in full to the client as soon as possible after receipt of those payments by the firm and the firm should
not be allowed to offset any third-party payments from the fees due by the client to the firm. The client should be
accurately and, where relevant, periodically, informed about all fees, commissions and benefits the firm has
received in connection with the investment service provided to the client and transferred to him. Firms
providing independent advice or portfolio management should also set up a policy, as part of their organisational
requirements, to ensure that third party payments received are allocated and transferred to the clients. Only minor
non-monetary benefits should be allowed, provided that they are clearly disclosed to the client, that they are
capable of enhancing the quality of the service provided and that they could not be judged to impair the ability of
investment firms to act in the best interest of their clients.
(75)
When providing the service of investment advice on an independent basis and the service of portfolio
management, fees, commissions or non-monetary benefits paid or provided by a person on behalf of the client
should be allowed only as far as the person is aware that such payments have been made on that person’s behalf
and that the amount and frequency of any payment is agreed between the client and the investment firm and not
determined by a third party. Cases which would satisfy that requirement include where a client pays a firm’s
invoice directly or it is paid by an independent third party who has no connection with the investment firm
regarding the investment service provided to the client and is acting only on the instructions of the client and cases
where the client negotiates a fee for a service provided by an investment firm and pays that fee. This would
generally be the case for accountants or lawyers acting under a clear payment instruction from the client or where
a person is acting as a mere conduit for the payment.
EN
12.6.2014
Official Journal of the European Union
L 173/361

<!-- source-page: 14 -->

(76)
This Directive provides for conditions and procedures for Member States to comply with when planning to impose
additional requirements. Such requirements may include prohibiting or further restricting the offer or acceptance of
fees, commissions or any monetary or non-monetary benefits paid or provided by any third party or a person
acting on behalf of a third party in relation to the provision of service to clients.
(77)
To further protect consumers, it is also appropriate to ensure that investment firms do not remunerate or assess
the performance of their own staff in a way that conflicts with the firm’s duty to act in the best interests of their
clients, for example through remuneration, sales targets or otherwise which provide an incentive for recom­
mending or selling a particular financial instrument when another product may better meet the client’s needs.
(78)
Where sufficient information in relation to the costs and associated charges or to the risks in respect of the
financial instrument itself is provided in accordance with other Union law that information should be regarded as
appropriate for the purposes of providing information to clients under this Directive. However, investment firms or
credit institutions distributing that financial instrument should additionally inform their clients about all the other
costs and associated charges relating to their provision of investment services in relation to that financial
instrument.
(79)
Given the complexity of investment products and the continuous innovation in their design, it is also important to
ensure that staff who advise on or sell investment products to retail clients possess an appropriate level of
knowledge and competence in relation to the products offered. Investment firms should allow their staff sufficient
time and resources to achieve that knowledge and competence and to apply it in providing services to clients.
(80)
Investment firms are allowed to provide investment services that consist only of execution and/or of the reception
and transmission of client orders, without the need to obtain information regarding the knowledge and experience
of the client in order to assess the appropriateness of the service or the financial instrument for the client. Since
those services entail a relevant reduction of client protection, it is appropriate to improve the conditions for their
provision. In particular, it is appropriate to exclude the possibility to provide those services in conjunction with the
ancillary service consisting of granting credits or loans to investors to allow them to carry out a transaction in
which the investment firm is involved, since this increases the complexity of the transaction and makes more
difficult the understanding of the risk involved. It is also appropriate to better define the criteria for the selection of
the financial instruments to which those services should relate in order to exclude certain financial instruments,
including those which embed a derivative or incorporate a structure which makes it difficult for the client to
understand the risk involved, shares in undertakings that are not undertakings for collective investment in trans­
ferable securities (UCITS) (non-UCITS collective investment undertakings) and structured UCITS as referred to in
the second subparagraph of Article 36(1) of Commission Regulation (EU) No 583/2010 ( 1 ). The treatment of
certain UCITS as complex products should be without prejudice to future Union law defining the scope of and the
rules applicable to such products.
(81)
Cross-selling practices are a common strategy for retail financial service providers throughout the Union. They can
provide benefits to retail clients but can also represent practices where the interest of the client is not adequately
considered. For instance, certain forms of cross-selling practices, namely tying practices where two or more
financial services are sold together in a package and at least one of those services is not available separately,
can distort competition and negatively affect client mobility and their ability to make informed choices. An
example of tying practices can be the necessary opening of current accounts when an investment service is
provided to a retail client. While practices of bundling, where two or more financial services are sold together
in a package, but each of the services can also be purchased separately, may also distort competition and negatively
affect customer mobility and the ability of clients to make informed choices, they at least leave choice to the client
and may therefore pose less risk to the compliance of investment firms with their obligations under this Directive.
The use of such practices should be carefully assessed in order to promote competition and consumer choice.
(82)
When providing investment advice, the investment firm should specify in a written statement on suitability how
the advice given meets the preferences, needs and other characteristics of the retail client. The statement should be
provided in a durable medium including in an electronic form. The responsibility to undertake the suitability
EN
L 173/362
Official Journal of the European Union
12.6.2014
( 1 ) Commission Regulation (EU) No 583/2010 of 1 July 2010 implementing Directive 2009/65/EC of the European Parliament and of
the Council as regards key investor information and conditions to be met when providing key investor information or the prospectus
in a durable medium other than paper or by means of a website (OJ L 176, 10.7.2010, p. 1).

<!-- source-page: 15 -->

assessment and to provide an accurate suitability report to the client lies with the investment firm and appropriate
safeguards should be in place to ensure that the client does not incur a loss out as a result of the report presenting
in an inaccurate or unfair manner the personal recommendation, including how the recommendation provided is
suitable for the client and the disadvantages of the recommended course of action.
(83)
In determining what constitutes the provision of information in good time before a time specified in this Directive,
an investment firm should take into account, having regard to the urgency of the situation, the client’s need for
sufficient time to read and understand it before taking an investment decision. A client is likely to require more
time to review information given on a complex or unfamiliar product or service, or a product or service a client
has no experience with than a client considering a simpler or more familiar product or service, or where the client
has relevant prior experience.
(84)
Nothing in this Directive should oblige investment firms to provide all required information about the investment
firm, financial instruments, costs and associated charges, or concerning the safeguarding of client financial
instruments or client funds immediately and at the same time, provided that they comply with the general
obligation to provide the relevant information in good time before the time specified in this Directive.
Provided that the information is communicated to the client in good time before the provision of the service,
nothing in this Directive obliges firms to provide it either separately or by incorporating the information in a client
agreement.
(85)
A service should be considered to be provided at the initiative of a client unless the client demands it in response
to a personalised communication from or on behalf of the firm to that particular client, which contains an
invitation or is intended to influence the client in respect of a specific financial instrument or specific transaction.
A service can be considered to be provided at the initiative of the client notwithstanding that the client demands it
on the basis of any communication containing a promotion or offer of financial instruments made by any means
that by its very nature is general and addressed to the public or a larger group or category of clients or potential
clients.
(86)
One of the objectives of this Directive is to protect investors. Measures to protect investors should be adapted to
the particularities of each category of investors (retail, professional and counterparties). However, in order to
enhance the regulatory framework applicable to the provision of services irrespective of the categories of clients
concerned, it is appropriate to make it clear that principles to act honestly, fairly and professionally and the
obligation to be fair, clear and not misleading apply to the relationship with any clients.
(87)
Investments that involve contracts of insurance are often made available to customers as potential alternatives or
substitutes to financial instruments subject to this Directive. To deliver consistent protection for retail clients and
ensure a level playing field between similar products, it is important that insurance-based investment products are
subject to appropriate requirements. Whereas the investor protection requirements in this Directive should
therefore be applied equally to those investments packaged under insurance contracts, their different market
structures and product characteristics make it more appropriate that detailed requirements are set out in the
ongoing review of Directive 2002/92/EC rather than setting them in this Directive. Future Union law regulating
the activities of insurance intermediaries and insurance undertakings should thus appropriately ensure a consistent
regulatory approach concerning the distribution of different financial products which satisfy similar investor needs
and therefore raise comparable investor protection challenges. The European Supervisory Authority (European
Investment and Occupational Pensions Authority) (‘EIOPA’), established by Regulation (EU) No 1094/2010 of the
European Parliament and of the Council ( 1 ) and ESMA should work together to achieve as much consistency as
possible in the conduct of business standards for those investment products. Those new requirements for
insurance-based investment products should be laid down in Directive 2002/92/EC.
(88)
In order to align the rules pertaining to conflicts of interests, general principles and information to customers and
to allow Member States to place restrictions on the remuneration of insurance intermediaries, Directive
2002/92/EC should be amended accordingly.
EN
12.6.2014
Official Journal of the European Union
L 173/363
( 1 ) Regulation (EU) No 1094/2010 of the European Parliament and of the Council of 24 November 2010 establishing a European
Supervisory Authority (European Investment and Occupational Pensions Authority), amending Decision No 716/2009/EC and
repealing Commission Decision 2009/79/EC (OJ L 331, 15.12.2010, p. 48).

<!-- source-page: 16 -->

(89)
Insurance-based investment products that do not offer investment opportunities and deposits solely exposed to
interest rates should be excluded from the scope of this Directive. Individual and occupational pension products,
having the primary purpose of providing the investor an income in retirement, should be excluded from the scope
of this Directive, in consideration of their particularities and objectives.
(90)
By way of derogation from the principle of home Member State authorisation, supervision and enforcement of
obligations in respect of the operation of branches, it is appropriate for the competent authority of the host
Member State to assume responsibility for enforcing certain obligations specified in this Directive in relation to
business conducted through a branch within the territory where the branch is located, since that authority is
closest to the branch, and is better placed to detect and intervene in respect of infringements of rules governing the
operations of the branch.
(91)
It is necessary to impose an effective ‘best execution’ obligation to ensure that investment firms execute client
orders on terms that are most favourable to the client. That obligation should apply where a firm owes contractual
or agency obligations to the client.
(92)
Given that a wider range of execution venues are now available in the Union, it is appropriate to enhance the best
execution framework for retail investors. Advances in technology for monitoring best execution should be
considered when applying the best execution framework in accordance with the second and third subparagraph
of Article 27(1).
(93)
For the purposes of determining best execution when executing retail client orders, the costs relating to execution
should include an investment firm’s own commissions or fees charged to the client for limited purposes, where
more than one venue listed in the firm’s execution policy is capable of executing a particular order. In such cases,
the firm’s own commissions and costs for executing the order on each of the eligible execution venues should be
taken into account in order to assess and compare the results for the client that would be achieved by executing
the order on each such venue. However, it is not intended to require a firm to compare the results that would be
achieved for its client on the basis of its own execution policy and its own commissions and fees, with results that
might be achieved for the same client by any other investment firm on the basis of a different execution policy or
a different structure of commissions or fees. Nor is it intended to require a firm to compare the differences in its
own commissions which are attributable to differences in the nature of the services that the firm provides to
clients.
(94)
The provisions of this Directive that provide that costs of execution should include an investment firm’s own
commissions or fees charged to the client for the provision of an investment service should not apply for the
purpose of determining what execution venues should be included in the firm’s execution policy for the purposes
of Article 27(5) of this Directive.
(95)
An investment firm should be considered to be structuring or charging its commissions in a way which
discriminates unfairly between execution venues if it charges a different commission or spread to clients for
execution on different execution venues and that difference does not reflect actual differences in the cost to the
firm of executing on those venues.
(96)
In order to enhance the conditions under which investment firms comply with their obligation to execute orders
on terms most favourable to their clients in accordance with this Directive, it is appropriate to require that for
financial instruments subject to the trading obligation in Articles 23 and 28 of Regulation (EU) No 600/2014 that
each trading venue and systematic internaliser and for other financial instruments that each execution venue to
make available to the public data relating to the quality of execution of transactions on each venue.
(97)
Information provided by investment firms to clients in relation to their execution policy often are generic and
standard and do not allow clients to understand how an order will be executed and to verify firms’ compliance
with their obligation to execute orders on term most favourable to their clients. In order to enhance investor
protection it is appropriate to specify the principles concerning the information given by investment firms to their
clients on the execution policy and to require firms to make public, on an annual basis, for each class of financial
instruments, the top five execution venues where they executed client orders in the preceding year and to take
account of that information and information published by execution venues on execution quality in their policies
on best execution.
EN
L 173/364
Official Journal of the European Union
12.6.2014

<!-- source-page: 17 -->

(98)
When establishing the business relationship with the client the investment firm might ask the client or potential
client to consent at the same time to the execution policy as well as to the possibility that that person’s orders may
be executed outside a trading venue.
(99)
Persons who provide investment services on behalf of more than one investment firm should not be considered to
be tied agents but as investment firms when they fall under the definition provided in this Directive, with the
exception of certain persons who may be exempt.
(100) This Directive should be without prejudice to the right of tied agents to undertake activities covered by other
Directives and related activities in respect of financial services or products not covered by this Directive, including
on behalf of parts of the same financial group.
(101) The conditions for conducting activities outside the premises of the investment firm (door-to-door selling) should
not be covered by this Directive.
(102) Member States’ competent authorities should not register or should withdraw the registration where the activities
actually carried on indicate clearly that a tied agent has opted for the legal system of one Member State for the
purpose of evading the stricter standards in force in another Member State within the territory of which it intends
to carry out or does carry out the greater part of its activities.
(103) For the purposes of this Directive eligible counterparties should be considered to be acting as clients.
(104) The financial crisis has shown limits in the ability of non-retail clients to appreciate the risk of their investments.
While it should be confirmed that conduct of business rules should be enforced in respect of those investors most
in need of protection, it is appropriate to better calibrate the requirements applicable to different categories of
clients. To that extent, it is appropriate to extend some information and reporting requirements to the relationship
with eligible counterparties. In particular, the relevant requirements should relate to the safeguarding of client
financial instruments and funds as well as information and reporting requirements concerning more complex
financial instruments and transactions. In order to better define the classification of municipalities and local public
authorities, it is appropriate to clearly exclude them from the list of eligible counterparties and of clients who are
considered to be professionals while still allowing those clients to ask for treatment as professional clients on
request.
(105) In respect of transactions executed between eligible counterparties, the obligation to disclose client limit orders
should only apply where the counterparty is explicitly sending a limit order to an investment firm for its execution.
(106) Member States should ensure the respect of the right to the protection of personal data in accordance with
Directive 95/46/EC of the European Parliament and of the Council ( 1 ) and Directive 2002/58/EC of the
European Parliament and of the Council ( 2 ) which govern the processing of personal data carried out in application
of this Directive. Processing of personal data by ESMA in the application of this Directive is subject to Regulation
(EU) No 45/2001 of the European Parliament and of the Council ( 3 ).
(107) Investment firms should all have the same opportunities of joining or having access to regulated markets
throughout the Union. Regardless of the manner in which transactions are at present organised in the Member
States, it is important to abolish the technical and legal restrictions on access to regulated markets.
EN
12.6.2014
Official Journal of the European Union
L 173/365
( 1 ) Directive 95/46/EC of the European Parliament and of the Council of 24 October 1995 on the protection of individuals with regard
to the processing of personal data and on the free movement of such data (OJ L 281, 23.11.1995, p. 31).
( 2 ) Directive 2002/58/EC of the European Parliament and of the Council of 12 July 2002 concerning the processing of personal data
and the protection of privacy in the electronic communications sector (Directive on privacy and electronic communications)
(OJ L 201, 31.7.2002, p. 37).
( 3 ) Regulation (EC) No 45/2001 of the European Parliament and of the Council of 18 December 2000 on the protection of individuals
with regard to the processing of personal data by the Community institutions and bodies and on the free movement of such data
(OJ L 8, 12.1.2001, p. 1).

<!-- source-page: 18 -->

(108) In order to facilitate the finalisation of cross-border transactions, it is appropriate to provide for access to clearing
and settlement systems throughout the Union by investment firms, irrespective of whether transactions have been
concluded through regulated markets in the Member State concerned. Investment firms which wish to participate
directly in other Member States’ settlement systems should comply with the relevant operational and commercial
requirements for membership and the prudential measures to uphold the smooth and orderly functioning of the
financial markets.
(109) The provision of services by third country firms in the Union is subject to national regimes and requirements.
Firms authorised in accordance with them do not enjoy the freedom to provide services and the right of
establishment in Member States other than the one where they are established. Where a Member State
considers that the appropriate level of protection for its retail clients or retail clients who have requested to be
treated as professional clients can be achieved by the establishment of a branch by the third-country firm it is
appropriate to introduce a minimum common regulatory framework at Union level with respect to the
requirements applicable to those branches and in light of the principle that third-country firms should not be
treated in a more favourable way than Union firms.
(110) When implementing the provisions of this Directive, Member States should take due account of the recommen­
dations by the Financial Action Task Force (FATF) on jurisdictions that have strategic anti-money laundering and
countering the financing of terrorism deficiencies and to which counter-measures apply or jurisdictions with
strategic anti-money laundering and countering the financing of terrorism deficiencies that have not made
sufficient progress in addressing the deficiencies or have not committed to an action plan developed with the
FATF to address the deficiencies.
(111) The provision of this Directive regulating the provision of investment services or activities by third-country firms
in the Union should not affect the possibility for persons established in the Union to receive investment services by
a third country firm at their own exclusive initiative. Where a third-country firm provides services at the own
exclusive initiative of a person established in the Union, the services should not be deemed as provided in the
territory of the Union. Where a third-country firm solicits clients or potential clients in the Union or promotes or
advertises investment services or activities together with ancillary services in the Union, it should not be deemed as
a service provided at the own exclusive initiative of the client.
(112) The authorisation to operate a regulated market should extend to all activities which are directly relating to the
display, processing, execution, confirmation and reporting of orders from the point at which such orders are
received by the regulated market to the point at which they are transmitted for subsequent finalisation, and to
activities relating to the admission of financial instruments to trading. This should also include transactions
concluded through the medium of designated market makers appointed by the regulated market which are
undertaken under its systems and in accordance with the rules that govern those systems. Not all transactions
concluded by members or participants of the regulated market, MTF or OTF are to be considered to be concluded
within the systems of a regulated market, MTF or OTF. Transactions which members or participants conclude on a
bilateral basis and which do not comply with all the obligations established for a regulated market, an MTF or an
OTF under this Directive should be considered to be transactions concluded outside a regulated market, an MTF or
an OTF for the purposes of the definition of systematic internaliser. In such a case the obligation for investment
firms to make public firm quotes should apply if the conditions established by this Directive and by Regulation
(EU) No 600/2014 are met.
(113) Given the importance of liquidity provision to the orderly and efficient functioning of markets, investment firms
that engage in algorithmic trading to pursue a market making strategy should have written agreements in place
with trading venues clarifying their obligations to provide liquidity to the market.
(114) Nothing in this Directive should require competent authorities to approve or examine the content of the written
agreement between the regulated market and the investment firm that is required from the participation in a
market making scheme. However, neither does it prevent them from doing so, insofar as any such approval or
examination is based only on the regulated markets’ compliance with their obligations under Article 48.
EN
L 173/366
Official Journal of the European Union
12.6.2014

<!-- source-page: 19 -->

(115) The provision of core market data services which are pivotal for users to be able to obtain a desired overview of
trading activity across Union financial markets and for competent authorities to receive accurate and compre­
hensive information on relevant transactions should be subject to authorisation and regulation to ensure the
necessary level of quality.
(116) The introduction of approved publication arrangements (APAs) should improve the quality of trade transparency
information published in the OTC space and contribute significantly to ensuring that such data is published in a
way facilitating its consolidation with data published by trading venues.
(117) Now that a market structure is in place which allows for competition between multiple trading venues it is
essential that an effective and comprehensive consolidated tape is in operation as soon as possible. The intro­
duction of a commercial solution for a consolidated tape for equities and equity-like financial instruments should
contribute to creating a more integrated European market and make it easier for market participants to gain access
to a consolidated view of trade transparency information that is available. The envisaged solution is based on an
authorisation of providers working along pre-defined and supervised parameters which are in competition with
each other in order to achieve technically highly sophisticated and innovative solutions, serving the market to the
greatest extent possible and ensuring that consistent and accurate market data is made available. By requiring all
consolidated tape providers (CTPs) to consolidate data from all APAs and trading venues it will be assured that
competition will take place on the basis of quality of service to clients rather than breadth of data covered.
Nevertheless it is appropriate to make provision now for a consolidated tape to be put in place through a public
procurement process if the mechanism envisaged does not lead to the timely delivery of an effective and compre­
hensive consolidated tape for equities and equity-like financial instruments.
(118) The establishment of a consolidated tape for non-equity financial instruments is deemed to be more difficult to
implement than the consolidated tape for equity financial instruments and potential providers should be able to
gain experience with the latter before constructing it. In order to facilitate the proper establishment of the
consolidated tape for non-equity financial instruments, it is therefore appropriate to provide for an extended
date of application of the national measures transposing the relevant provision. Nevertheless it is appropriate to
make provision now for a consolidated tape to be put in place through a public procurement process if the
mechanism envisaged does not lead to the timely delivery of an effective and comprehensive consolidated tape for
non-equity financial instruments.
(119) When determining, as regards non-equity financial instruments, the trading venues and APAs which need to be
included in the post-trade information to be disseminated by CTPs, ESMA should ensure that the objective of the
establishment of an integrated Union market for those financial instruments will be achieved and should ensure
non-discriminatory treatment of APAs and trading venues.
(120) Union law on own funds requirements should fix the minimum capital requirements with which regulated markets
should comply in order to be authorised, and in so doing should take into account the specific nature of the risks
associated with such markets.
(121) Operators of a regulated market should also be able to operate an MTF or an OTF in accordance with the relevant
provisions of this Directive.
(122) The provisions of this Directive concerning the admission of financial instruments to trading under the rules
enforced by the regulated market should be without prejudice to the application of Directive 2001/34/EC of the
European Parliament and of the Council ( 1 ) and of Directive 2003/71/EC of the European Parliament and of the
Council ( 2 ). A regulated market should not be prevented from applying more stringent requirements in respect of
the issuers of financial instruments which it is considering for admission to trading than are imposed pursuant to
this Directive.
EN
12.6.2014
Official Journal of the European Union
L 173/367
( 1 ) Directive 2001/34/EC of the European Parliament and of the Council of 28 May 2001 on the admission of securities to official stock
exchange listing and on information to be published on those securities (OJ L 184, 6.7.2001, p. 1).
( 2 ) Directive 2003/71/EC of the European Parliament and of the Council of 4 November 2003 on the prospectus to be published when
securities are offered to the public or admitted to trading (OJ L 345, 31.12.2003, p. 64).

<!-- source-page: 20 -->

(123) Member States should be able to designate different competent authorities to enforce the wide-ranging obligations
laid down in this Directive. Such authorities should be of a public nature guaranteeing their independence from
economic actors and avoiding conflicts of interest. In accordance with national law, Member States should ensure
appropriate financing of the competent authority. The designation of public authorities should not exclude
delegation under the responsibility of the competent authority.
(124) In order to ensure that the communication between competent authorities of suspensions, removals, disruptions,
disorderly trading conditions and circumstances that may indicate market abuse is achieved in an efficient and
timely way, an effective communication and coordination process between national competent authorities is
necessary, which will be achieved via arrangements developed by ESMA.
(125) The G20 summit in Pittsburgh on 25 September 2009 agreed to improve the regulation, functioning and trans­
parency of financial and commodity markets to address excessive commodity price volatility. The Commission
Communications of 28 October 2009 on ‘A Better Functioning Food Supply Chain in Europe’, and of 2 February
2011 on ‘Tackling the Challenges in Commodity Markets and Raw Materials’ outlined measures that fall to be
taken in the context of the review of Directive 2004/39/EC. In September 2011, the International Organization of
Securities Commissions published Principles for the Regulation and Supervision of Commodity Derivatives
Markets. Those principles were endorsed by the G20 summit in Cannes on 4 November 2011 which called for
market regulators to have formal position management powers, including the power to set ex ante position limits
as appropriate.
(126) The powers made available to competent authorities should be complemented with explicit powers to obtain
information from any person regarding the size and purpose of a position in derivative contracts relating to
commodities and to request the person to take steps to reduce the size of the position in the derivative contracts.
(127) A harmonised position limits regime is needed to ensure greater coordination and consistency in the application of
the G20 agreement, especially for contracts that are traded across the Union. Therefore, explicit powers should be
granted to competent authorities to establish limits, on the basis of a methodology determined by ESMA, on the
positions any person can hold, at an aggregate group level, in a derivative contract in relation to a commodity at
all times in order to prevent market abuse, including cornering the market, and to support orderly pricing and
settlement conditions including the prevention of market distorting positions. Such limits should promote integrity
of the market for the derivative and the underlying commodity without prejudice to price discovery on the market
for the underlying commodity and should not apply to positions which objectively reduce risks directly relating to
commercial activities in relation to the commodity. The distinction between spot contracts for commodities and
commodity derivative contracts should also be clarified. In order to achieve the harmonised regime, it is also
appropriate for ESMA to monitor the implementation of the position limits and for competent authorities to put
in place cooperation arrangements, including exchange of relevant data with each other and to enable the
monitoring and enforcement of the limits.
(128) All venues which offer trading in commodity derivatives should have in place appropriate position management
controls, providing the necessary powers at least to monitor and access information about commodity derivative
positions, to require the reduction or termination of such positions and to require that liquidity is provided back
on the market to mitigate the effects of a large or dominant position. ESMA should maintain and publish a list
containing summaries of all position limits and position management controls in force. Those limits and
arrangements should be applied in a consistent manner and take account of the specific characteristics of the
market in question. They should be clearly spelled out as regards to how they apply and to the relevant
quantitative thresholds which constitute the limits or which may trigger other obligations.
(129) Trading venues should publish an aggregated weekly breakdown of the positions held by different categories of
persons for the different commodity derivative contracts, emission allowances and derivatives thereof traded on
their platforms. A comprehensive and detailed breakdown of the positions held by all persons should be made
available to the competent authority at least daily. Arrangement for reporting under this Directive should take into
account, where applicable, reporting requirements already imposed under Article 8 of Regulation (EU)
No 1227/2011.
EN
L 173/368
Official Journal of the European Union
12.6.2014

<!-- source-page: 21 -->

(130) While the methodology used for calculation of position limits should not create barriers to the development of
new commodity derivatives, ESMA should ensure when determining the methodology for calculation that the
development of new commodity derivatives cannot be used to circumvent the position limits regime.
(131) Position limits should be set for each individual commodity derivative contract. In order to avoid circumvention of
the position limits regime through the ongoing development of new commodity derivative contracts, ESMA should
ensure that the methodology for calculation prevents any circumvention by taking into account the overall open
interest in other commodity derivatives with the same underlying commodity.
(132) It is desirable to facilitate access to capital for smaller and medium-sized enterprises (SMEs) and to facilitate the
further development of specialist markets that aim to cater for the needs of smaller and medium-sized issuers.
Those markets which are usually operated under this Directive as MTFs are commonly known as SME growth
markets, growth markets or junior markets. The creation within the MTF category of a new sub category of SME
growth market and the registration of those markets should raise their visibility and profile and aid the devel­
opment of common regulatory standards in the Union for those markets. Attention should be focused on how
future regulation should further foster and promote the use of that market so as to make it attractive for investors,
and provide a lessening of administrative burdens and further incentives for SMEs to access capital markets
through SME growth markets.
(133) The requirements applying to that new category of markets need to provide sufficient flexibility to be able to take
into account the current range of successful market models that exist across Europe. They also need to strike the
correct balance between maintaining high levels of investor protection, which are essential to fostering investor
confidence in issuers on those markets, while reducing unnecessary administrative burdens for issuers on those
markets. It is proposed that more details about SME growth market requirements such as those relating to criteria
for admission to trading on such a market would be further prescribed in delegated acts or technical standards.
(134) Given the importance of not adversely affecting existing successful markets the option should remain for operators
of markets aimed at smaller and medium-sized issuers to choose to continue to operate such a market in
accordance with the requirements under this Directive without seeking registration as an SME growth market.
An issuer that is an SME should not be obliged to apply to have its financial instruments admitted to trading on an
SME growth market.
(135) In order for that new category of markets to benefit SMEs, at least 50 % of the issuers whose financial instruments
are traded on a SME growth market should be SMEs. That assessment should be made on an annual basis. That
50 % criterion should be implemented in a flexible way. A temporary failure to meet that criterion should not
mean that the trading venue will have to be immediately deregistered or refused to be registered as an SME growth
market if it has a reasonable prospect of meeting the 50 % criterion from the subsequent year. With respect to the
assessment to determine whether an issuer is an SME enterprise, it should be made based on the market
capitalisation of the previous three calendar years. This should ensure a smoother transition for those issuers
from those specialist markets to the main markets.
(136) Any confidential information received by the contact point of one Member State through the contact point of
another Member State should not be regarded as purely domestic.
(137) It is necessary to enhance convergence of powers at the disposal of competent authorities so as to pave the way
towards an equivalent intensity of enforcement across the integrated financial market. A common minimum set of
powers coupled with adequate resources should guarantee supervisory effectiveness. This Directive should therefore
provide for a minimum set of supervisory and investigative powers competent authorities of Member States should
be entrusted with in accordance with national law. Those powers should be exercised, where the national law so
requires, by application to the competent judicial authorities. When exercising their powers under this Directive,
competent authorities should act objectively and impartially and remain autonomous in their decision making.
(138) While this Directive specifies a minimum set of powers competent authorities should have, those powers are to be
exercised within a complete system of national law which guarantees the respect for fundamental rights, including
the right to privacy. For the exercise of those powers, which may amount to serious interferences with the right to
EN
12.6.2014
Official Journal of the European Union
L 173/369

<!-- source-page: 22 -->

respect private and family life, home and communications, Member States should have in place adequate and
effective safeguards against any abuse, for instance, where appropriate prior authorisation from the judicial auth­
orities of a Member State concerned. Member States should allow the possibility for competent authorities to
exercise such intrusive powers to the extent necessary for the proper investigation of serious cases where there are
no equivalent means for effectively achieving the same result.
(139) No action taken by any competent authority or ESMA in the performance of their duties should directly or
indirectly discriminate against any Member State or group of Member States as a venue for the provision of
investment services and activities in any currency.
(140) In view of the significant impact and market share acquired by various MTFs, it is appropriate to ensure that
adequate cooperation arrangements are established between the competent authority of the MTF and that of the
jurisdiction in which the MTF is providing services. In order to anticipate any similar developments, this should be
extended to OTFs.
(141) In order to ensure compliance by investment firms, market operators authorised to operate an MTF or OTF,
regulated markets, APAs, CTPs or approved reporting mechanisms (ARMs), those who effectively control their
business and the members of the investment firms and regulated markets’ management body with the obligations
deriving from this Directive and from Regulation (EU) No 600/2014 and to ensure that they are subject to similar
treatment across the Union, Member States should be required to provide for sanctions and measures which are
effective, proportionate and dissuasive. Administrative sanctions and measures set out by Member States should
satisfy certain essential requirements in relation to addressees, criteria to be taken into account when applying a
sanction or measure, publication, key powers to impose sanctions and levels of administrative fines.
(142) In particular, competent authorities should be empowered to impose fines which are sufficiently high to offset the
benefits that can be expected and to be dissuasive even for larger institutions and their managers.
(143) It is also necessary for competent authorities to have, in accordance with national law and with the Charter, the
ability to access the premises of natural and legal persons. Access to such premises is necessary when there is
reasonable suspicion that documents and other data relating to the subject matter of an investigation exist and may
be relevant to prove an infringement of this Directive or of Regulation (EU) No 600/2014. Additionally, access to
such premises is necessary where the person to whom a demand for information has already been made, fails to
comply with such demand wholly or in part; or where there are reasonable grounds for believing that if a demand
were to be made, it would not be complied with, or that the documents or information to which the information
requirement relates, would be removed, tampered with or destroyed. If prior authorisation is needed from the
judicial authority of the Member State concerned, in accordance with national law, such power for access into
premises should be used after having obtained that prior judicial authorisation.
(144) Existing recordings of telephone conversations and data traffic records from investment firms executing and
documenting the executions of transactions, as well as existing telephone and data traffic records from tele­
communications operators constitute crucial, and sometimes the only, evidence to detect and prove the
existence of market abuse as well as verify compliance by firms with investor protection and other requirements
set out in this Directive or in Regulation (EU) No 600/2014. Therefore, competent authorities should be able to
require existing recordings of telephone conversations, electronic communications and data traffic records held by
an investment firm or credit. Access to data and telephone records is necessary for the detection and penalising of
market abuse or of infringements of requirements set out in this Directive or in Regulation (EU) No 600/2014.
In order to introduce a level playing field in the Union in relation to the access to telephone and existing data
traffic records held by a telecommunication operator or the existing recordings of telephone conversations and
data traffic held by an investment firm, competent authorities should, in accordance with national law, be able to
require existing telephone and existing data traffic records held by a telecommunication operator insofar as
permitted under national law and existing recordings of telephone conversations as well as data traffic held by
an investment firm, in those cases where a reasonable suspicion exists that such records relating to the subject-
matter of the inspection or investigation may be relevant to prove behaviour that is prohibited under Regulation
(EU) No 596/2014 or infringements of the requirements of this Directive or of Regulation (EU) No 600/2014.
Access to telephone and data traffic records held by a telecommunications operator should not encompass the
content of voice communications by telephone.
EN
L 173/370
Official Journal of the European Union
12.6.2014

<!-- source-page: 23 -->

(145) In order to ensure a consistent application of sanctions across the Union, Member States should be required to
ensure that when determining the type of administrative sanctions or measures and the level of administrative
fines, the competent authorities take into account all relevant circumstances.
(146) In order to ensure that decisions made by competent authorities have a dissuasive effect on the public at large, they
should normally be published. The publication of decisions is also an important tool for competent authorities to
inform market participants of what behaviour is considered to infringe this Directive and to promote wider good
behaviour amongst market participants. If such publication causes disproportionate damage to the persons
involved, jeopardises the stability of financial markets or an ongoing investigation the competent authority
should publish the sanctions and measures on an anonymous basis in a manner which complies with national
law or delay the publication.
Competent authorities should have the option not to publish sanctions where anonymous or delayed publication is
considered to be insufficient to ensure that the stability of financial markets will not be jeopardised. Competent
authorities should not be required to publish measures which are deemed to be of a minor nature where
publication would be disproportionate. It is appropriate to provide a mechanism for reporting unpublished
sanctions to ESMA so that competent authorities can take them into account in their ongoing supervision.
This Directive does not require but should not prevent the publication of criminal sanctions imposed for
infringements of this Directive or of Regulation (EU) No 600/2014.
(147) In order to detect potential infringements, competent authorities should have the necessary investigatory powers,
and should establish effective and reliable mechanisms to encourage reporting of potential or actual infringements,
including protection of employees reporting infringements within their own institution. Those mechanisms should
be without prejudice to adequate safeguards for accused persons. Appropriate procedures should be established to
ensure appropriate protection of an accused person, particularly with regard to the right to the protection of
personal data of that person and procedures to ensure the right of the accused person of defence and to be heard
before the adoption of a decision concerning him as well as the right to seek effective remedy before a court
against a decision concerning him.
(148) This Directive should refer to sanctions and measures in order to cover all actions applied after an infringement,
and which are intended to prevent further infringements, irrespective of their qualification as a sanction or a
measure under national law.
(149) This Directive should be without prejudice to any provisions in the law of Member States relating to criminal
sanctions.
(150) Even though nothing prevents Member States from laying down rules for administrative and criminal sanctions for
the same infringements, Member States should not be required to lay down rules for administrative sanctions for
the infringements of this Directive or of Regulation (EU) No 600/2014 which are subject to national criminal law.
In accordance with national law, Member States are not obliged to impose both administrative and criminal
sanctions for the same offence, but they should be able to do so if their national law so permits. However, the
maintenance of criminal sanctions instead of administrative sanctions for infringements of this Directive or of
Regulation (EU) No 600/2014 should not reduce or otherwise affect the ability of competent authorities to
cooperate, access and exchange information in a timely way with competent authorities in other Member
States for the purposes of this Directive and of Regulation (EU) No 600/2014, including after any referral of
the relevant infringements to the competent judicial authorities for criminal prosecution.
(151) With a view to protecting clients and without prejudice to the right of customers to bring their action before the
courts, it is appropriate that Member States ensure that public or private bodies are established with a view to
settling disputes out-of-court, to cooperate in resolving cross-border disputes, taking into account Commission
Recommendation 98/257/EC ( 1 ) and Commission Recommendation 2001/310/EC ( 2 ). When implementing
provisions on complaints and redress procedures for out-of-court settlements, Member States should be
encouraged to use existing cross-border cooperation mechanisms, in particular the Financial Services Complaints
Network (FIN-Net).
EN
12.6.2014
Official Journal of the European Union
L 173/371
( 1 ) Commission Recommendation 98/257/EC of 30 March 1998 on the principles applicable to the bodies responsible for out-of-court
settlement of consumer disputes (OJ L 115, 17.4.1998, p. 31).
( 2 ) Commission Recommendation 2001/310/EC of 4 April 2001 on the principles for out-of-court bodies involved in the consensual
resolution of consumer disputes (OJ L 109, 19.4.2001, p 56).

<!-- source-page: 24 -->

(152) Any exchange or transmission of information between competent authorities, other authorities, bodies or persons
should be in accordance with the rules on transfer of personal data to third countries as laid down in Directive
95/46/EC. Any exchange or transmission of personal data by ESMA with third countries should be in accordance
with the rules on the transfer of personal data as laid down in Regulation (EC) No 45/2001.
(153) It is necessary to reinforce provisions on exchange of information between national competent authorities and to
strengthen the duties of assistance and cooperation which they owe to each other. Due to increasing cross-border
activity, competent authorities should provide each other with the relevant information for the exercise of their
functions, so as to ensure the effective enforcement of this Directive, including in situations where infringements or
suspected infringements may be of concern to authorities in two or more Member States. In the exchange of
information, strict professional secrecy is needed to ensure the smooth transmission of that information and the
protection of particular rights.
(154) Where the operation of a trading venue that has established arrangements in a host Member State has become of
substantial importance for the functioning of the securities markets and the protection of the investors in that host
Member State, the proportionate cooperation arrangements to be put in place should take the appropriate form
amongst possible cooperation modalities between the competent authorities of the home and host Member States,
proportionate to the needs for cross-border supervisory cooperation in particular resulting from the nature and
scale of the impact on the securities markets and the investor protection in the host Member State, such as ad hoc
or periodic information sharing, consultation and assistance.
(155) In order to attain the objectives set out in this Directive, the power to adopt acts in accordance with Article 290
TFEU should be delegated to the Commission in respect of details concerning exemptions, the clarification of
definitions, the criteria for the assessment of proposed acquisitions of an investment firm, the organisational
requirements for investment firms, APAs and CTPs, the management of conflicts of interest, conduct of
business obligations in the provision of investment services, the execution of orders on terms most favourable
to the client, the handling of client orders, the transactions with eligible counterparties, the circumstances that
trigger an information requirement for investment firms or market operators operating an MTF or an OTF and
operators of a regulated market, the circumstances constituting significant damage to the investors’ interests and
the orderly functioning of the market for the purposes of the suspension and removal of financial instruments
from trading on an MTF, an OTF or a regulated market, the SME growth markets, the thresholds above which the
position reporting obligations apply and the criteria under which the operations of a trading venue in a host
Member State could be considered as of substantial importance for the functioning of the securities markets and
the protection of the investors. It is of particular importance that the Commission carry out appropriate consul­
tations during its preparatory work, including at expert level. The Commission, when preparing and drawing up
delegated acts, should ensure a simultaneous, timely and appropriate transmission of relevant documents to the
European Parliament and to the Council.
(156) Technical standards in financial services should ensure consistent harmonisation and adequate protection of
investors, including those investing in structured deposits, and consumers across the Union. As a body with
highly specialised expertise, it would be efficient and appropriate to entrust ESMA, with the elaboration of draft
regulatory and implementing technical standards which do not involve policy choices, for submission to the
Commission. To ensure consistent investor and consumer protection across financial services sectors, ESMA
should carry out its tasks, to the extent possible, in close cooperation with the European Supervisory Authority
(European Banking Authority) (‘EBA’), established by Regulation (EC) No 1093/2010 of the European Parliament
and of the Council ( 1 ) and with EIOPA.
(157) The Commission should adopt the draft regulatory technical standards developed by ESMA regarding exemptions
that relate to activities considered to be ancillary to the main business, regarding the information to be provided
and certain requirements in the context of procedures for granting and refusing requests for authorisation of
investment firms, regarding acquisition of the qualifying holding, regarding algorithmic trading, regarding
obligation to execute orders on terms most favourable to clients, regarding the suspension and removal of
financial instruments from trading on a regulated market, on an MTF or an OTF, regarding freedom to provide
investment services and activities, regarding establishment of a branch, regarding systems resilience, circuit breakers
and electronic trading, regarding tick sizes, regarding synchronisation of business clocks, regarding admission of
EN
L 173/372
Official Journal of the European Union
12.6.2014
( 1 ) Regulation (EU) No 1093/2010 of the European Parliament and of the Council of 24 November 2010 establishing a European
Supervisory Authority (European Banking Authority), amending Decision No 716/2009/EC and repealing Commission Decision
2009/78/EC (OJ L 331, 15.12.2010, p. 12).

<!-- source-page: 25 -->

financial instruments to trading, regarding the position limits and position management controls in commodity
derivatives, regarding procedures for granting and refusing requests for authorisation of data reporting services
providers, regarding organisational requirements for APAs, CTPs and ARMs and regarding cooperation among
competent authorities. The Commission should adopt those draft regulatory technical standards by means of
delegated acts pursuant to Article 290 TFEU and in accordance with Articles 10 to 14 of Regulation (EU)
No 1093/2010.
(158) The Commission should also be empowered to adopt implementing technical standards by means of implementing
acts pursuant to Article 291 TFEU and in accordance with Article 15 of Regulation (EU) No 1095/2010. ESMA
should be entrusted with drafting implementing technical standards for submission to the Commission regarding
procedures for granting and refusing requests for authorisation of investment firms, regarding the acquisition of a
qualifying holding, regarding trading process on finalisation of transactions in MTFs and OTFs, regarding
suspension and removal of financial instruments from trading, regarding freedom to provide investment
services and activities, regarding establishment of a branch, regarding position reporting by categories of
position holders, regarding procedures for granting and refusing requests for authorisation, regarding the
procedures and forms for submitting information in relation to the publication of decisions, regarding obligation
to cooperate, regarding cooperation among competent authorities, regarding exchange of information and
regarding consultation prior to authorisation of an investment firm.
(159) The Commission should submit a report to the European Parliament and the Council assessing the functioning of
OTFs, the functioning of the regime for SME growth markets, the impact of requirements regarding automated and
high-frequency trading, the experience with the mechanism for banning certain products or practices and the
impact of the measures regarding commodity derivatives markets.
(160) By 1 January 2018, the Commission should prepare a report assessing the potential impact on energy prices and
the functioning of the energy market of the expiry of the transitional period provided for the application of the
clearing obligation and the margining requirements set out in Regulation (EU) No 648/2012. If appropriate, the
Commission should submit a legislative proposal to establish or amend the relevant law, including specific sectoral
legislation such as Regulation (EU) No 1227/2011.
(161) Directive 2011/61/EU of the European Parliament and of the Council ( 1 ) allows Member States to authorise
alternative investment fund managers (AIFMs) to provide certain investment services in addition to the collective
management of alternative investment funds (AIFs), including services of management of portfolios of investments,
investment advice, safe-keeping and administration in relation to shares or units of collective investment under­
takings, as well as reception and transmission of orders in relation to financial instruments. Since the requirements
governing the provision of those services are harmonised within the Union, AIFMs authorised by their home
competent authorities to provide those services should not be subject to any additional authorisation in host
Member States nor to any other measure having the same effect.
(162) Under the current legal framework, AIFMs authorised to provide those investment services and intending to
provide them in Member States other than their home Member State are to comply with additional national
requirements, including the establishment of a separate legal entity. In order to eliminate obstacles in the cross-
border provision of harmonised investment services and to ensure a level playing field between entities providing
the same investment services under the same legal requirements, an AIFM authorised to provide those services
should be able to provide them on a cross-border basis, subject to appropriate notification requirements, under the
authorisation granted by the competent authorities of their home Member State.
(163) Directive 2011/61/EU should therefore be amended accordingly.
(164) Since the objective of this Directive, namely creating an integrated financial market in which investors are effec­
tively protected and the efficiency and integrity of the overall market are safeguarded, requires the establishment of
common regulatory requirements relating to investment firms wherever they are authorised in the Union and
EN
12.6.2014
Official Journal of the European Union
L 173/373
( 1 ) Directive 2011/61/EU of the European Parliament and of the Council of 8 June 2011 on Alternative Investment Fund Managers and
amending Directives 2003/41/EC and 2009/65/EC and Regulations (EC) No 1060/2009 and (EU) No 1095/2010 (OJ L 174,
1.7.2011, p. 1).

<!-- source-page: 26 -->

governing the functioning of regulated markets and other trading systems so as to prevent opacity or disruption
on one market from undermining the efficient operation of the Union financial system as a whole which cannot
be sufficiently achieved by the Member States but can rather, by reason of the scale and effects of this Directive, be
better achieved at Union level, the Union may adopt measures in accordance with the principle of subsidiarity as
set out in Article 5 of the Treaty on European Union. In accordance with the principle of proportionality, as set
out in that Article, this Directive does not go beyond what is necessary in order to achieve that objective.
(165) Given the increase of tasks conferred on ESMA by this Directive and by Regulation (EU) No 600/2014, the
European Parliament, the Council and the Commission should ensure that adequate human and financial resources
are made available.
(166) This Directive respects the fundamental rights and observes the principles recognised in the Charter, in particular
the right to the protection of personal data, the freedom to conduct a business, the right to consumer protection,
the right to an effective remedy and to a fair trial, the right not to be tried or punished twice for the same offence
and has to be implemented in accordance with those rights and principles.
(167) The European Data Protection Supervisor has been consulted in accordance with Article 28(2) of Regulation (EC)
No 45/2001 and delivered an opinion on 10 February 2012 ( 1 ).
(168) In accordance with the Joint Political Declaration of Member States and the Commission on explanatory
documents of 28 September 2011 ( 2 ), Member States have undertaken to accompany, in justified cases, the
notification of their transposition measures with one or more documents explaining the relationship between
the components of a directive and the corresponding parts of national transposition instruments. With regard to
this Directive, the legislator considers the transmission of such documents to be justified.
(169) The obligation to transpose this Directive into national law should be confined to those provisions which represent
a substantive amendment as compared to the earlier Directives. The obligation to transpose the provisions which
are unchanged arises under the earlier Directives.
(170) This Directive should be without prejudice to the obligations of the Member States relating to the time-limits for
the transposition into national law and the dates of application of the Directives set out in Annex III, Part B,
HAVE ADOPTED THIS DIRECTIVE:
TITLE I
SCOPE AND DEFINITIONS
Article 1
Scope
1.
This Directive shall apply to investment firms, market operators, data reporting services providers, and third-country
firms providing investment services or performing investment activities through the establishment of a branch in the
Union.
2.
This Directive establishes requirements in relation to the following:
(a) authorisation and operating conditions for investment firms;
(b) provision of investment services or activities by third-country firms through the establishment of a branch;
EN
L 173/374
Official Journal of the European Union
12.6.2014
( 1 ) OJ C 147, 25.5.2012, p. 1.
( 2 ) OJ C 369, 17.12.2011, p. 14.

<!-- source-page: 27 -->

(c) authorisation and operation of regulated markets;
(d) authorisation and operation of data reporting services providers; and
(e) supervision, cooperation and enforcement by competent authorities.
3.
The following provisions shall also apply to credit institutions authorised under Directive 2013/36/EU, when
providing one or more investment services and/or performing investment activities:
(a) Article 2(2), Article 9(3) and Articles 14 and 16 to 20,
(b) Chapter II of Title II excluding second subparagraph of Article 29(2),
(c) Chapter III of Title II excluding Article 34(2) and (3) and Article 35(2) to (6) and (9),
(d) Articles 67 to 75 and Articles 80, 85 and 86.
4.
The following provisions shall also apply to investment firms and to credit institutions authorised under Directive
2013/36/EU when selling or advising clients in relation to structured deposits:
(a) Article 9(3), Article 14, and Article 16(2), (3) and (6);
(b) Articles 23 to 26, Article 28 and Article 29, excluding the second subparagraph of paragraph 2 thereof, and
Article 30; and
(c) Articles 67 to 75.
5.
Article 17(1) to (6) shall also apply to members or participants of regulated markets and MTFs who are not required
to be authorised under this Directive pursuant to points (a), (e), (i) and (j) of Article 2(1).
6.
Articles 57 and 58 shall also apply to persons exempt under Article 2.
7.
All multilateral systems in financial instruments shall operate either in accordance with the provisions of Title II
concerning MTFs or OTFs or the provisions of Title III concerning regulated markets.
Any investment firms which, on an organised, frequent, systematic and substantial basis, deal on own account when
executing client orders outside a regulated market, an MTF or an OTF shall operate in accordance with Title III of
Regulation (EU) No 600/2014.
Without prejudice to Articles 23 and 28 of Regulation (EU) No 600/2014, all transactions in financial instruments as
referred to in the first and the second subparagraphs which are not concluded on multilateral systems or systematic
internalisers shall comply with the relevant provisions of Title III of Regulation (EU) No 600/2014.
EN
12.6.2014
Official Journal of the European Union
L 173/375

<!-- source-page: 28 -->

Article 2
Exemptions
1.
This Directive shall not apply to:
(a) insurance undertakings or undertakings carrying out the reinsurance and retrocession activities referred to in
Directive 2009/138/EC when carrying out the activities referred to in that Directive;
(b) persons providing investment services exclusively for their parent undertakings, for their subsidiaries or for other
subsidiaries of their parent undertakings;
(c) persons providing an investment service where that service is provided in an incidental manner in the course of a
professional activity and that activity is regulated by legal or regulatory provisions or a code of ethics governing the
profession which do not exclude the provision of that service;
(d) persons dealing on own account in financial instruments other than commodity derivatives or emission allowances
or derivatives thereof and not providing any other investment services or performing any other investment activities
in financial instruments other than commodity derivatives or emission allowances or derivatives thereof unless such
persons:
(i) are market makers;
(ii) are members of or participants in a regulated market or an MTF or have direct electronic access to a trading
venue;
(iii) apply a high-frequency algorithmic trading technique; or
(iv) deal on own account when executing client orders;
Persons exempt under points (a), (i) or (j) are not required to meet the conditions laid down in this point in order to
be exempt.
(e) operators with compliance obligations under Directive 2003/87/EC who, when dealing in emission allowances, do
not execute client orders and who do not provide any investment services or perform any investment activities other
than dealing on own account, provided that those persons do not apply a high-frequency algorithmic trading
technique;
(f)
persons providing investment services consisting exclusively in the administration of employee-participation schemes;
(g) persons providing investment services which only involve both the administration of employee-participation schemes
and the provision of investment services exclusively for their parent undertakings, for their subsidiaries or for other
subsidiaries of their parent undertakings;
(h) the members of the ESCB and other national bodies performing similar functions in the Union, other public bodies
charged with or intervening in the management of the public debt in the Union and international financial
institutions established by two or more Member States which have the purpose of mobilising funding and
providing financial assistance to the benefit of their members that are experiencing or threatened by severe
financing problems;
EN
L 173/376
Official Journal of the European Union
12.6.2014

<!-- source-page: 29 -->

(i)
collective investment undertakings and pension funds whether coordinated at Union level or not and the depositaries
and managers of such undertakings;
(j)
persons:
(i) dealing on own account, including market makers, in commodity derivatives or emission allowances or
derivatives thereof, excluding persons who deal on own account when executing client orders; or
(ii) providing investment services, other than dealing on own account, in commodity derivatives or emission
allowances or derivatives thereof to the customers or suppliers of their main business;
provided that:
— for each of those cases individually and on an aggregate basis this is an ancillary activity to their main business,
when considered on a group basis, and that main business is not the provision of investment services within the
meaning of this Directive or banking activities under Directive 2013/36/EU, or acting as a market-maker in
relation to commodity derivatives,
— those persons do not apply a high-frequency algorithmic trading technique; and
— those persons notify annually the relevant competent authority that they make use of this exemption and upon
request report to the competent authority the basis on which they consider that their activity under points (i) and
(ii) is ancillary to their main business;
(k) persons providing investment advice in the course of providing another professional activity not covered by this
Directive provided that the provision of such advice is not specifically remunerated;
(l)
associations set up by Danish and Finnish pension funds with the sole aim of managing the assets of pension funds
that are members of those associations;
(m) ‘agenti di cambio’ whose activities and functions are governed by Article 201 of Italian Legislative Decree No 58 of
24 February 1998;
(n) transmission system operators as defined in Article 2(4) of Directive 2009/72/EC or Article 2(4) of Directive
2009/73/EC when carrying out their tasks under those Directives, under Regulation (EC) No 714/2009, under
Regulation (EC) No 715/2009 or under network codes or guidelines adopted pursuant to those Regulations, any
persons acting as service providers on their behalf to carry out their task under those legislative acts or under
network codes or guidelines adopted pursuant to those Regulations, and any operator or administrator of an energy
balancing mechanism, pipeline network or system to keep in balance the supplies and uses of energy when carrying
out such tasks.
That exemption shall apply to persons engaged in the activities set out in this point only where they perform
investment activities or provide investment services relating to commodity derivatives in order to carry out those
activities. That exemption shall not apply with regard to the operation of a secondary market, including a platform
for secondary trading in financial transmission rights;
(o) CSDs that are regulated as such under Union law, to the extent that they are regulated under that Union law.
EN
12.6.2014
Official Journal of the European Union
L 173/377

<!-- source-page: 30 -->

2.
The rights conferred by this Directive shall not extend to the provision of services as counterparty in transactions
carried out by public bodies dealing with public debt or by members of the ESCB performing their tasks as provided for
by the TFEU and by Protocol No 4 on the Statute of the European System of Central Banks and of the European Central
Bank or performing equivalent functions under national provisions.
3.
The Commission shall adopt delegated acts in accordance with Article 89 to clarify for the purposes of point (c) of
paragraph 1 when an activity is provided in an incidental manner.
4.
ESMA shall develop draft regulatory technical standards to specify, for the purposes of point (j) of paragraph 1, the
criteria for establishing when an activity is to be considered to be ancillary to the main business at a group level.
Those criteria shall take into account at least the following elements:
(a) the need for ancillary activities to constitute a minority of activities at a group level;
(b) the size of their trading activity compared to the overall market trading activity in that asset class.
In determining the extent to which ancillary activities constitute a minority of activities at a group level ESMA may
determine that the capital employed for carrying out the ancillary activity relative to the capital employed for carrying out
the main business is to be considered. However, that factor shall in no case be sufficient to demonstrate that the activity
is ancillary to the main business of the group.
The activities referred to in this paragraph shall be considered at a group level.
The elements referred to in the second and third subparagraphs shall exclude:
(a) intra-group transactions as referred to in Article 3 of Regulation (EU) No 648/2012 that serve group-wide liquidity or
risk management purposes;
(b) transactions in derivatives which are objectively measurable as reducing risks directly relating to the commercial
activity or treasury financing activity;
(c) transactions in commodity derivatives and emission allowances entered into to fulfil obligations to provide liquidity
on a trading venue, where such obligations are required by regulatory authorities in accordance with Union law or
with national laws, regulations and administrative provisions, or by trading venues.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
Article 3
Optional exemptions
1.
Member States may choose not to apply this Directive to any persons for which they are the home Member State,
provided that the activities of those persons are authorised and regulated at national level and those persons:
(a) are not allowed to hold client funds or client securities and which for that reason are not allowed at any time to place
themselves in debit with their clients;
EN
L 173/378
Official Journal of the European Union
12.6.2014

<!-- source-page: 31 -->

(b) are not allowed to provide any investment service except the reception and transmission of orders in transferable
securities and units in collective investment undertakings and/or the provision of investment advice in relation to such
financial instruments; and
(c) in the course of providing that service, are allowed to transmit orders only to:
(i) investment firms authorised in accordance with this Directive;
(ii) credit institutions authorised in accordance with Directive 2013/36/EU;
(iii) branches of investment firms or of credit institutions authorised in a third country and which are subject to and
comply with prudential rules considered by the competent authorities to be at least as stringent as those laid
down in this Directive, in Regulation (EU) No 575/2013 or in Directive 2013/36/EU;
(iv) collective investment undertakings authorised under the law of a Member State to market units to the public and
to the managers of such undertakings; or
(v) investment companies with fixed capital, as defined in Article 17(7) of Directive 2012/30/EU of the European
Parliament and of the Council ( 1 ) the securities of which are listed or dealt in on a regulated market in a Member
State; or
(d) provide investment services exclusively in commodities, emission allowances and/or derivatives thereof for the sole
purpose of hedging the commercial risks of their clients, where those clients are exclusively local electricity under­
takings as defined in Article 2(35) of Directive 2009/72/EC and/or natural gas undertakings as defined in Article 2(1)
of Directive 2009/73/EC, and provided that those clients jointly hold 100 % of the capital or of the voting rights of
those persons, exercise joint control and are exempt under point (j) of Article 2(1) of this Directive if they carry out
those investment services themselves; or
(e) provide investment services exclusively in emission allowances and/or derivatives thereof for the sole purpose of
hedging the commercial risks of their clients, where those clients are exclusively operators as defined in point (f) of
Article 3 of Directive 2003/87/EC, and provided that those clients jointly hold 100 % of the capital or voting rights
of those persons, exercise joint control and are exempt under point (j) of Article 2(1) of this Directive if they carry
out those investment services themselves.
2.
Member States’ regimes shall submit the persons referred to in paragraph 1 to requirements which are at least
analogous to the following requirements under this Directive:
(a) conditions and procedures for authorisation and on-going supervision as established in Article 5(1) and (3), Articles 7
to 10, 21, 22 and 23 and the corresponding delegated acts adopted by the Commission in accordance with
Article 89;
(b) conduct of business obligations as established in Article 24(1), (3), (4), (5), (7) and (10), Article 25(2), (5) and (6), and,
where the national regime allows those persons to appoint tied agents, Article 29, and the respective implementing
measures;
EN
12.6.2014
Official Journal of the European Union
L 173/379
( 1 ) Directive 2012/30/EU of the European Parliament and of the Council of 25 October 2012 on coordination of safeguards which, for
the protection of the interests of members and others, are required by Member States of companies within the meaning of the second
paragraph of Article 54 of the Treaty on the Functioning of the European Union, in respect of the formation of public limited
liability companies and the maintenance and alteration of their capital, with a view to making such safeguards equivalent (OJ L 315,
14.11.2012, p. 74).

<!-- source-page: 32 -->

(c) organisational requirements as laid down in the first, sixth and seventh subparagraph of Article 16(3) and in
Article 16(6) and (7) and the corresponding delegated acts adopted by the Commission in accordance with Article 89.
Member States shall require persons exempt from this Directive pursuant to paragraph 1 of this Article to be covered by
an investor-compensation scheme recognised in accordance with Directive 97/9/EC. Member States may allow investment
firms not to be covered by such a scheme provided they hold professional indemnity insurance where, taking into
account the size, risk profile and legal nature of the persons exempt in accordance with paragraph 1 of this Article,
equivalent protection to their clients is ensured.
By way of derogation from the second subparagraph of this paragraph, Member States that already have in place such
laws, regulations or administrative provisions before 2 July 2014 may until 3 July 2019 require that where the persons
exempt from this Directive pursuant to paragraph 1 of this Article provide the investment services of the reception and
transmission of orders and/or of the provision of investment advice in units in collective investment undertakings and act
as an intermediary with a management company as defined in Directive 2009/65/EC, those persons are jointly and
severally liable with the management company for any damages incurred by the client in relation to those services.
3.
Persons exempt from this Directive pursuant to paragraph 1 shall not benefit from the freedom to provide services
or to perform activities or to establish branches as provided for in Articles 34 and 35 respectively.
4.
Member States shall notify the Commission and ESMA of the exercise of the option under this Article and shall
ensure that each authorisation granted in accordance with paragraph 1 mentions that it is granted in accordance with this
Article.
5.
Member States shall communicate to ESMA the provisions of national law analogous to the requirements of this
Directive listed in paragraph 2.
Article 4
Definitions
1.
For the purposes of this Directive, the following definitions apply:
(1) ‘investment firm’ means any legal person whose regular occupation or business is the provision of one or more
investment services to third parties and/or the performance of one or more investment activities on a professional
basis.
Member States may include in the definition of investment firms undertakings which are not legal persons, provided
that:
(a) their legal status ensures a level of protection for third parties’ interests equivalent to that afforded by legal
persons; and
(b) they are subject to equivalent prudential supervision appropriate to their legal form.
However, where a natural person provides services involving the holding of third party funds or transferable
securities, that person may be considered to be an investment firm for the purposes of this Directive and of
Regulation (EU) No 600/2014 only if, without prejudice to the other requirements imposed in this Directive, in
Regulation (EU) No 600/2014, and in Directive 2013/36/EU, that person complies with the following conditions:
(a) the ownership rights of third parties in instruments and funds must be safeguarded, especially in the event of the
insolvency of the firm or of its proprietors, seizure, set-off or any other action by creditors of the firm or of its
proprietors;
EN
L 173/380
Official Journal of the European Union
12.6.2014

<!-- source-page: 33 -->

(b) the firm must be subject to rules designed to monitor the firm’s solvency and that of its proprietors;
(c) the firm’s annual accounts must be audited by one or more persons empowered, under national law, to audit
accounts;
(d) where the firm has only one proprietor, that person must make provision for the protection of investors in the
event of the firm’s cessation of business following the proprietor’s death or incapacity or any other such event;
(2) ‘investment services and activities’ means any of the services and activities listed in Section A of Annex I relating to
any of the instruments listed in Section C of Annex I.
The Commission shall adopt delegated acts in accordance with Article 89 measures specifying:
(a) the derivative contracts referred to in Section C.6 of Annex I that have the characteristics of wholesale energy
products that must be physically settled and C.6 energy derivative contracts;
(b) the derivative contracts referred to in Section C.7 of Annex I that have the characteristics of other derivative
financial instruments;
(c) the derivative contracts referred to in Section C.10 of Annex I that have the characteristics of other derivative
financial instruments, having regard to whether, inter alia, they are traded on a regulated market, an MTF or an
OTF;
(3) ‘ancillary services’ means any of the services listed in Section B of Annex I;
(4) ‘investment advice’ means the provision of personal recommendations to a client, either upon its request or at the
initiative of the investment firm, in respect of one or more transactions relating to financial instruments;
(5) ‘execution of orders on behalf of clients’ means acting to conclude agreements to buy or sell one or more financial
instruments on behalf of clients and includes the conclusion of agreements to sell financial instruments issued by an
investment firm or a credit institution at the moment of their issuance;
(6) ‘dealing on own account’ means trading against proprietary capital resulting in the conclusion of transactions in one
or more financial instruments;
(7) ‘market maker’ means a person who holds himself out on the financial markets on a continuous basis as being
willing to deal on own account by buying and selling financial instruments against that person’s proprietary capital
at prices defined by that person;
(8) ‘portfolio management’ means managing portfolios in accordance with mandates given by clients on a discretionary
client-by-client basis where such portfolios include one or more financial instruments;
(9) ‘client’ means any natural or legal person to whom an investment firm provides investment or ancillary services;
(10) ‘professional client’ means a client meeting the criteria laid down in Annex II;
(11) ‘retail client’ means a client who is not a professional client;
EN
12.6.2014
Official Journal of the European Union
L 173/381

<!-- source-page: 34 -->

(12) ‘SME growth market’ means a MTF that is registered as an SME growth market in accordance with Article 33;
(13) ‘small and medium-sized enterprises’ for the purposes of this Directive, means companies that had an average
market capitalisation of less than EUR 200 000 000 on the basis of end-year quotes for the previous three calendar
years;
(14) ‘limit order’ means an order to buy or sell a financial instrument at its specified price limit or better and for a
specified size;
(15) ‘financial instrument’ means those instruments specified in Section C of Annex I;
(16) ‘C6 energy derivative contracts’ means options, futures, swaps, and any other derivative contracts mentioned in
Section C.6 of Annex I relating to coal or oil that are traded on an OTF and must be physically settled;
(17) ‘money-market instruments’ means those classes of instruments which are normally dealt in on the money market,
such as treasury bills, certificates of deposit and commercial papers and excluding instruments of payment;
(18) ‘market operator’ means a person or persons who manages and/or operates the business of a regulated market and
may be the regulated market itself;
(19) ‘multilateral system’ means any system or facility in which multiple third-party buying and selling trading interests in
financial instruments are able to interact in the system;
(20) ‘systematic internaliser’ means an investment firm which, on an organised, frequent systematic and substantial basis,
deals on own account when executing client orders outside a regulated market, an MTF or an OTF without
operating a multilateral system;
The frequent and systematic basis shall be measured by the number of OTC trades in the financial instrument
carried out by the investment firm on own account when executing client orders. The substantial basis shall be
measured either by the size of the OTC trading carried out by the investment firm in relation to the total trading of
the investment firm in a specific financial instrument or by the size of the OTC trading carried out by the
investment firm in relation to the total trading in the Union in a specific financial instrument. The definition of
a systematic internaliser shall apply only where the pre-set limits for a frequent and systematic basis and for a
substantial basis are both crossed or where an investment firm chooses to opt-in under the systematic internaliser
regime;
(21) ‘regulated market’ means a multilateral system operated and/or managed by a market operator, which brings
together or facilitates the bringing together of multiple third-party buying and selling interests in financial
instruments – in the system and in accordance with its non-discretionary rules – in a way that results in a
contract, in respect of the financial instruments admitted to trading under its rules and/or systems, and which is
authorised and functions regularly and in accordance with Title III of this Directive;
(22) ‘multilateral trading facility’ or ‘MTF’ means a multilateral system, operated by an investment firm or a market
operator, which brings together multiple third-party buying and selling interests in financial instruments – in the
system and in accordance with non-discretionary rules – in a way that results in a contract in accordance with Title
II of this Directive;
(23) ‘organised trading facility’ or ‘OTF’ means a multilateral system which is not a regulated market or an MTF and in
which multiple third-party buying and selling interests in bonds, structured finance products, emission allowances or
derivatives are able to interact in the system in a way that results in a contract in accordance with Title II of this
Directive;
EN
L 173/382
Official Journal of the European Union
12.6.2014

<!-- source-page: 35 -->

(24) ‘trading venue’ means a regulated market, an MTF or an OTF;
(25) ‘liquid market’ means a market for a financial instrument or a class of financial instruments, where there are ready
and willing buyers and sellers on a continuous basis, assessed in accordance with the following criteria, taking into
consideration the specific market structures of the particular financial instrument or of the particular class of
financial instruments:
(a) the average frequency and size of transactions over a range of market conditions, having regard to the nature
and life cycle of products within the class of financial instrument;
(b) the number and type of market participants, including the ratio of market participants to traded instruments in a
particular product;
(c) the average size of spreads, where available;
(26) ‘competent authority’ means the authority, designated by each Member State in accordance with Article 67, unless
otherwise specified in this Directive;
(27) ‘credit institution’ means a credit institution as defined in point (1) of Article 4(1) of Regulation (EU) No 575/2013;
(28) ‘UCITS management company’ means a management company as defined in point (b) of Article 2(1) of Directive
2009/65/EC of the European Parliament and of the Council ( 1 );
(29) ‘tied agent’ means a natural or legal person who, under the full and unconditional responsibility of only one
investment firm on whose behalf it acts, promotes investment and/or ancillary services to clients or prospective
clients, receives and transmits instructions or orders from the client in respect of investment services or financial
instruments, places financial instruments or provides advice to clients or prospective clients in respect of those
financial instruments or services;
(30) ‘branch’ means a place of business other than the head office which is a part of an investment firm, which has no
legal personality and which provides investment services and/or activities and which may also perform ancillary
services for which the investment firm has been authorised; all the places of business set up in the same Member
State by an investment firm with headquarters in another Member State shall be regarded as a single branch;
(31) ‘qualifying holding’ means a direct or indirect holding in an investment firm which represents 10 % or more of the
capital or of the voting rights, as set out in Articles 9 and 10 of Directive 2004/109/EC of the European Parliament
and of the Council ( 2 ), taking into account the conditions regarding aggregation thereof laid down in Article 12(4)
and (5) of that Directive, or which makes it possible to exercise a significant influence over the management of the
investment firm in which that holding subsists;
(32) ‘parent undertaking’ means a parent undertaking within the meaning of Article 2(9) and 22 of Directive
2013/34/EU of the European Parliament and of the Council ( 3 );
EN
12.6.2014
Official Journal of the European Union
L 173/383
( 1 ) Directive 2009/65/EC of the European Parliament and of the Council of 13 July 2009 on the coordination of laws, regulations and
administrative provisions relating to undertakings for collective investment in transferable securities (UCITS) (OJ L 302, 17.11.2009,
p. 32).
( 2 ) Directive 2004/109/EC of the European Parliament and of the Council of 15 December 2004 on the harmonisation of transparency
requirements in relation to information about issuers whose securities are admitted to trading on a regulated market and amending
Directive 2001/34/EC (OJ L 390, 31.12.2004, p. 38).
( 3 ) Directive 2013/34/EU of the European Parliament and of the Council of 26 June 2013 on the annual financial statements,
consolidated financial statements and related reports of certain types of undertakings, amending Directive 2006/43/EC of the
European Parliament and of the Council and repealing Council Directives 78/660/EEC and 83/349/EEC (OJ L 182, 29.6.2013, p. 19).

<!-- source-page: 36 -->

(33) ‘subsidiary’ means a subsidiary undertaking within the meaning of Articles 2(10) and 22 of Directive 2013/34/EU,
including any subsidiary of a subsidiary undertaking of an ultimate parent undertaking;
(34) ‘group’ means a group as defined in Article 2(11) of Directive 2013/34/EU;
(35) ‘close links’ means a situation in which two or more natural or legal persons are linked by:
(a) participation in the form of ownership, direct or by way of control, of 20 % or more of the voting rights or
capital of an undertaking;
(b) ‘control’ which means the relationship between a parent undertaking and a subsidiary, in all the cases referred to
in Article 22(1) and (2) of Directive 2013/34/EU, or a similar relationship between any natural or legal person
and an undertaking, any subsidiary undertaking of a subsidiary undertaking also being considered to be a
subsidiary of the parent undertaking which is at the head of those undertakings;
(c) a permanent link of both or all of them to the same person by a control relationship;
(36) ‘management body’ means the body or bodies of an investment firm, market operator or data reporting services
provider, which are appointed in accordance with national law, which are empowered to set the entity’s strategy,
objectives and overall direction, and which oversee and monitor management decision-making and include persons
who effectively direct the business of the entity.
Where this Directive refers to the management body and, pursuant to national law, the managerial and supervisory
functions of the management body are assigned to different bodies or different members within one body, the
Member State shall identify the bodies or members of the management body responsible in accordance with its
national law, unless otherwise specified by this Directive;
(37) ‘senior management’ means natural persons who exercise executive functions within an investment firm, a market
operator or a data reporting services provider and who are responsible, and accountable to the management body,
for the day-to-day management of the entity, including for the implementation of the policies concerning the
distribution of services and products to clients by the firm and its personnel;
(38) ‘matched principal trading’ means a transaction where the facilitator interposes itself between the buyer and the
seller to the transaction in such a way that it is never exposed to market risk throughout the execution of the
transaction, with both sides executed simultaneously, and where the transaction is concluded at a price where the
facilitator makes no profit or loss, other than a previously disclosed commission, fee or charge for the transaction;
(39) ‘algorithmic trading’ means trading in financial instruments where a computer algorithm automatically determines
individual parameters of orders such as whether to initiate the order, the timing, price or quantity of the order or
how to manage the order after its submission, with limited or no human intervention, and does not include any
system that is only used for the purpose of routing orders to one or more trading venues or for the processing of
orders involving no determination of any trading parameters or for the confirmation of orders or the post-trade
processing of executed transactions;
(40) ‘high-frequency algorithmic trading technique’ means an algorithmic trading technique characterised by:
(a) infrastructure intended to minimise network and other types of latencies, including at least one of the following
facilities for algorithmic order entry: co-location, proximity hosting or high-speed direct electronic access;
EN
L 173/384
Official Journal of the European Union
12.6.2014

<!-- source-page: 37 -->

(b) system-determination of order initiation, generation, routing or execution without human intervention for
individual trades or orders; and
(c) high message intraday rates which constitute orders, quotes or cancellations;
(41) ‘direct electronic access’ means an arrangement where a member or participant or client of a trading venue permits a
person to use its trading code so the person can electronically transmit orders relating to a financial instrument
directly to the trading venue and includes arrangements which involve the use by a person of the infrastructure of
the member or participant or client, or any connecting system provided by the member or participant or client, to
transmit the orders (direct market access) and arrangements where such an infrastructure is not used by a person
(sponsored access);
(42) ‘cross-selling practice’ means the offering of an investment service together with another service or product as part
of a package or as a condition for the same agreement or package;
(43) ‘structured deposit’ means a deposit as defined in point (c) of Article 2(1) of Directive 2014/49/EU of the European
Parliament and of the Council ( 1 ), which is fully repayable at maturity on terms under which interest or a premium
will be paid or is at risk, according to a formula involving factors such as:
(a) an index or combination of indices, excluding variable rate deposits whose return is directly linked to an interest
rate index such as Euribor or Libor;
(b) a financial instrument or combination of financial instruments;
(c) a commodity or combination of commodities or other physical or non-physical non-fungible assets; or
(d) a foreign exchange rate or combination of foreign exchange rates;
(44) ‘transferable securities’ means those classes of securities which are negotiable on the capital market, with the
exception of instruments of payment, such as:
(a) shares in companies and other securities equivalent to shares in companies, partnerships or other entities, and
depositary receipts in respect of shares;
(b) bonds or other forms of securitised debt, including depositary receipts in respect of such securities;
(c) any other securities giving the right to acquire or sell any such transferable securities or giving rise to a cash
settlement determined by reference to transferable securities, currencies, interest rates or yields, commodities or
other indices or measures;
(45) ‘depositary receipts’ means those securities which are negotiable on the capital market and which represent
ownership of the securities of a non-domiciled issuer while being able to be admitted to trading on a regulated
market and traded independently of the securities of the non-domiciled issuer;
EN
12.6.2014
Official Journal of the European Union
L 173/385
( 1 ) Directive 2014/49/EU of the European Parliament and of the Council of 16 April 2014 on deposit guarantee schemes (see page 149
of this Official Journal).

<!-- source-page: 38 -->

(46) ‘exchange-traded fund’ means a fund of which at least one unit or share class is traded throughout the day on at
least one trading venue and with at least one market maker which takes action to ensure that the price of its units
or shares on the trading venue does not vary significantly from its net asset value and, where applicable, from its
indicative net asset value;
(47) ‘certificates’ means certificates as defined in Article 2(1)(27) of Regulation (EU) No 600/2014;
(48) ‘structured finance products’ means structured finance products as defined in Article 2(1)(28) of Regulation (EU)
No 600/2014;
(49) ‘derivatives’ means derivatives as defined in Article 2(1)(29) of Regulation (EU) No 600/2014;
(50) ‘commodity derivatives’ means commodity derivatives as defined in Article 2(1)(30) of Regulation (EU) No
600/2014;
(51) ‘CCP’ means a CCP as defined in Article 2(1) of Regulation (EU) No 648/2012;
(52) ‘approved publication arrangement’ or ‘APA’ means a person authorised under this Directive to provide the service
of publishing trade reports on behalf of investment firms pursuant to Articles 20 and 21 of Regulation (EU)
No 600/2014;
(53) ‘consolidated tape provider’ or ‘CTP’ means a person authorised under this Directive to provide the service of
collecting trade reports for financial instruments listed in Articles 6, 7, 10, 12 and 13, 20 and 21 of Regulation
(EU) No 600/2014 from regulated markets, MTFs, OTFs and APAs and consolidating them into a continuous
electronic live data stream providing price and volume data per financial instrument;
(54) ‘approved reporting mechanism’ or ‘ARM’ means a person authorised under this Directive to provide the service of
reporting details of transactions to competent authorities or to ESMA on behalf of investment firms;
(55) ‘home Member State’ means:
(a) in the case of investment firms:
(i) if the investment firm is a natural person, the Member State in which its head office is situated;
(ii) if the investment firm is a legal person, the Member State in which its registered office is situated;
(iii) if the investment firm has, under its national law, no registered office, the Member State in which its head
office is situated;
(b) in the case of a regulated market, the Member State in which the regulated market is registered or, if under the
law of that Member State it has no registered office, the Member State in which the head office of the regulated
market is situated;
(c) in the case of an APA, a CTP or an ARM:
(i) if the APA, CTP or ARM is a natural person, the Member State in which its head office is situated;
EN
L 173/386
Official Journal of the European Union
12.6.2014

<!-- source-page: 39 -->

(ii) if the APA, CTP or ARM is a legal person, the Member State in which its registered office is situated;
(iii) if the APA, CTP or ARM has, under its national law, no registered office, the Member State in which its
head office is situated;
(56) ‘host Member State’ means the Member State, other than the home Member State, in which an investment firm has
a branch or provides investment services and/or activities, or the Member State in which a regulated market provides
appropriate arrangements so as to facilitate access to trading on its system by remote members or participants
established in that same Member State;
(57) ‘third-country firm’ means a firm that would be a credit institution providing investment services or performing
investment activities or an investment firm if its head office or registered office were located within the Union;
(58) ‘wholesale energy product’ means wholesale energy products as defined in point (4) of Article 2 of Regulation (EU)
No 1227/2011;
(59) ‘agricultural commodity derivatives’ means derivative contracts relating to products listed in Article 1 of, and Annex
I, Parts I to XX and XXIV/1, to, Regulation (EU) No 1308/2013 of the European Parliament and of the Council ( 1 );
(60) ‘sovereign issuer’ means any of the following that issues debt instruments:
(i) the Union;
(ii) a Member State, including a government department, an agency, or a special purpose vehicle of the Member
State;
(iii) in the case of a federal Member State, a member of the federation;
(iv) a special purpose vehicle for several Member States;
(v) an international financial institution established by two or more Member States which has the purpose of
mobilising funding and provide financial assistance to the benefit of its members that are experiencing or
threatened by severe financing problems; or
(vi) the European Investment Bank;
(61) ‘sovereign debt’ means a debt instrument issued by a sovereign issuer;
(62) ‘durable medium’ means any instrument which:
(a) enables a client to store information addressed personally to that client in a way accessible for future reference
and for a period of time adequate for the purposes of the information; and
(b) allows the unchanged reproduction of the information stored;
EN
12.6.2014
Official Journal of the European Union
L 173/387
( 1 ) Regulation (EU) No 1308/2013 of the European Parliament and of the Council of 17 December 2013 establishing a common
organisation of the markets in agricultural products and repealing Council Regulations (EEC) No 922/72, (EEC) No 234/79, (EC)
No 1037/2001 and (EC) No 1234/2007 (OJ L 347, 20.12.2013, p. 671).

<!-- source-page: 40 -->

(63) ‘data reporting services provider’ means an APA, a CTP or an ARM.
2.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to specify some
technical elements of the definitions laid down in paragraph 1, to adjust them to market developments, technological
developments and experience of behaviour that is prohibited under Regulation (EU) No 596/2014 and to ensure the
uniform application of this Directive.
TITLE II
AUTHORISATION AND OPERATING CONDITIONS FOR INVESTMENT FIRMS
CHAPTER I
Conditions and procedures for authorisation
Article 5
Requirement for authorisation
1.
Each Member State shall require that the provision of investment services and/or the performance of investment
activities as a regular occupation or business on a professional basis be subject to prior authorisation in accordance with
this Chapter. Such authorisation shall be granted by the home Member State competent authority designated in
accordance with Article 67.
2.
By way of derogation from paragraph 1, Member States shall authorise any market operator to operate an MTF or
an OTF, subject to the prior verification of their compliance with this Chapter.
3.
Member States shall register all investment firms. The register shall be publicly accessible and shall contain
information on the services or activities for which the investment firm is authorised. It shall be updated on a regular
basis. Every authorisation shall be notified to ESMA.
ESMA shall establish a list of all investment firms in the Union. That list shall contain information on the services or
activities for which each investment firm is authorised and it shall be updated on a regular basis. ESMA shall publish and
keep up-to-date that list on its website.
Where a competent authority has withdrawn an authorisation in accordance with points (b), (c) and (d) of Article 8, that
withdrawal shall be published on the list for a period of five years.
4.
Each Member State shall require that:
(a) any investment firm which is a legal person have its head office in the same Member State as its registered office;
(b) any investment firm which is not a legal person or any investment firm which is a legal person but under its national
law has no registered office, have its head office in the Member State in which it actually carries out its business.
Article 6
Scope of authorisation
1.
The home Member State shall ensure that the authorisation specifies the investment services or activities which the
investment firm is authorised to provide. The authorisation may cover one or more of the ancillary services set out in
Section B of Annex I. Authorisation shall in no case be granted solely for the provision of ancillary services.
2.
An investment firm seeking authorisation to extend its business to additional investment services or activities or
ancillary services not foreseen at the time of initial authorisation shall submit a request for extension of its authorisation.
EN
L 173/388
Official Journal of the European Union
12.6.2014

<!-- source-page: 41 -->

3.
The authorisation shall be valid for the entire Union and shall allow an investment firm to provide the services or
perform the activities, for which it has been authorised, throughout the Union, either through the right of establishment,
including through a branch, or through the freedom to provide services.
Article 7
Procedures for granting and refusing requests for authorisation
1.
The competent authority shall not grant authorisation unless and until such time as it is fully satisfied that the
applicant complies with all requirements under the provisions adopted pursuant to this Directive.
2.
The investment firm shall provide all information, including a programme of operations setting out, inter alia, the
types of business envisaged and the organisational structure, necessary to enable the competent authority to satisfy itself
that the investment firm has established, at the time of initial authorisation, all the necessary arrangements to meet its
obligations under this Chapter.
3.
An applicant shall be informed, within six months of the submission of a complete application, whether or not
authorisation has been granted.
4.
ESMA shall develop draft regulatory technical standards to specify:
(a) the information to be provided to the competent authorities under paragraph 2 of this Article including the
programme of operations;
(b) the requirements applicable to the management of investment firms under Article 9(6) and the information for the
notifications under Article 9(5);
(c) the requirements applicable to shareholders and members with qualifying holdings, as well as obstacles which may
prevent effective exercise of the supervisory functions of the competent authority, under Article 10(1) and (2).
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
5.
ESMA shall develop draft implementing technical standards to determine standard forms, templates and procedures
for the notification or provision of information provided for in paragraph 2 of this Article and in Article 9(5).
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 8
Withdrawal of authorisations
The competent authority may withdraw the authorisation issued to an investment firm where such an investment firm:
(a) does not make use of the authorisation within 12 months, expressly renounces the authorisation or has provided no
investment services or performed no investment activity for the preceding six months, unless the Member State
concerned has provided for authorisation to lapse in such cases;
EN
12.6.2014
Official Journal of the European Union
L 173/389

<!-- source-page: 42 -->

(b) has obtained the authorisation by making false statements or by any other irregular means;
(c) no longer meets the conditions under which authorisation was granted, such as compliance with the conditions set
out in Regulation (EU) No 575/2013;
(d) has seriously and systematically infringed the provisions adopted pursuant to this Directive or Regulation (EU)
No 600/2014 governing the operating conditions for investment firms;
(e) falls within any of the cases where national law, in respect of matters outside the scope of this Directive, provides for
withdrawal.
Every withdrawal of authorisation shall be notified to ESMA.
Article 9
Management body
1.
Competent authorities granting the authorisation in accordance with Article 5 shall ensure that investment firms
and their management bodies comply with Article 88 and Article 91 of Directive 2013/36/EU.
ESMA and EBA shall adopt, jointly, guidelines on the elements listed in Article 91(12) of Directive 2013/36/EU.
2.
When granting the authorisation in accordance with Article 5, competent authorities may authorise members of the
management body to hold one additional non-executive directorship than allowed in accordance with Article 91(3) of
Directive 2013/36/EU. Competent authorities shall regularly inform ESMA of such authorisations.
EBA and ESMA shall coordinate the collection of information provided for under the first subparagraph of this paragraph
and under Article 91(6) of Directive 2013/36/EU in relation to investment firms.
3.
Member States shall ensure that the management body of an investment firm defines, oversees and is accountable
for the implementation of the governance arrangements that ensure effective and prudent management of the investment
firm including the segregation of duties in the investment firm and the prevention of conflicts of interest, and in a
manner that promotes the integrity of the market and the interest of clients.
Without prejudice to the requirements established in Article 88(1) of Directive 2013/36/EU, those arrangements shall also
ensure that the management body define, approve and oversee:
(a) the organisation of the firm for the provision of investment services and activities and ancillary services, including the
skills, knowledge and expertise required by personnel, the resources, the procedures and the arrangements for the
provision of services and activities, taking into account the nature, scale and complexity of its business and all the
requirements the firm has to comply with;
(b) a policy as to services, activities, products and operations offered or provided, in accordance with the risk tolerance of
the firm and the characteristics and needs of the clients of the firm to whom they will be offered or provided,
including carrying out appropriate stress testing, where appropriate;
(c) a remuneration policy of persons involved in the provision of services to clients aiming to encourage responsible
business conduct, fair treatment of clients as well as avoiding conflict of interest in the relationships with clients.
EN
L 173/390
Official Journal of the European Union
12.6.2014

<!-- source-page: 43 -->

The management body shall monitor and periodically assess the adequacy and the implementation of the firm’s strategic
objectives in the provision of investment services and activities and ancillary services, the effectiveness of the investment
firm’s governance arrangements and the adequacy of the policies relating to the provision of services to clients and take
appropriate steps to address any deficiencies.
Members of the management body shall have adequate access to information and documents which are needed to oversee
and monitor management decision-making.
4.
The competent authority shall refuse authorisation if it is not satisfied that the members of the management body
of the investment firm are of sufficiently good repute, possess sufficient knowledge, skills and experience and commit
sufficient time to perform their functions in the investment firm, or if there are objective and demonstrable grounds for
believing that the management body of the firm may pose a threat to its effective, sound and prudent management and
to the adequate consideration of the interest of its clients and the integrity of the market.
5.
Member States shall require the investment firm to notify the competent authority of all members of its
management body and of any changes to its membership, along with all information needed to assess whether the
firm complies with paragraphs 1, 2 and 3.
6.
Member States shall require that at least two persons meeting the requirements laid down in paragraph 1 effectively
direct the business of the applicant investment firm.
By way of derogation from the first subparagraph, Member States may grant authorisation to investment firms that are
natural persons or to investment firms that are legal persons managed by a single natural person in accordance with their
constitutive rules and national laws. Member States shall nevertheless require that:
(a) alternative arrangements be in place which ensure the sound and prudent management of such investment firms and
the adequate consideration of the interest of clients and the integrity of the market;
(b) the natural persons concerned are of sufficiently good repute, possess sufficient knowledge, skills and experience and
commit sufficient time to perform their duties.
Article 10
Shareholders and members with qualifying holdings
1.
The competent authorities shall not authorise the provision of investment services or performance of investment
activities by an investment firm until they have been informed of the identities of the shareholders or members, whether
direct or indirect, natural or legal persons, that have qualifying holdings and the amounts of those holdings.
The competent authorities shall refuse authorisation if, taking into account the need to ensure the sound and prudent
management of an investment firm, they are not satisfied as to the suitability of the shareholders or members that have
qualifying holdings.
Where close links exist between the investment firm and other natural or legal persons, the competent authority shall
grant authorisation only if those links do not prevent the effective exercise of the supervisory functions of the competent
authority.
2.
The competent authority shall refuse authorisation if the laws, regulations or administrative provisions of a third
country governing one or more natural or legal persons with which the undertaking has close links, or difficulties
involved in their enforcement, prevent the effective exercise of its supervisory functions.
EN
12.6.2014
Official Journal of the European Union
L 173/391

<!-- source-page: 44 -->

3.
Member States shall require that, where the influence exercised by the persons referred to in the first subparagraph
of paragraph 1 is likely to be prejudicial to the sound and prudent management of an investment firm, the competent
authority take appropriate measures to put an end to that situation.
Such measures may include applications for judicial orders or the imposition of sanctions against directors and those
responsible for management, or suspension of the exercise of the voting rights attaching to the shares held by the
shareholders or members in question.
Article 11
Notification of proposed acquisitions
1.
Member States shall require any natural or legal person or such persons acting in concert (the ‘proposed acquirer’),
who have taken a decision either to acquire, directly or indirectly, a qualifying holding in an investment firm or to further
increase, directly or indirectly, such a qualifying holding in an investment firm as a result of which the proportion of the
voting rights or of the capital held would reach or exceed 20 %, 30 % or 50 % or so that the investment firm would
become its subsidiary (the ‘proposed acquisition’), first to notify in writing the competent authorities of the investment
firm in which they are seeking to acquire or increase a qualifying holding, indicating the size of the intended holding and
relevant information, as referred to in Article 13(4).
Member States shall require any natural or legal person who has taken a decision to dispose, directly or indirectly, of a
qualifying holding in an investment firm first to notify in writing the competent authorities, indicating the size of the
intended holding. Such a person shall likewise notify the competent authorities if he has taken a decision to reduce his
qualifying holding so that the proportion of the voting rights or of the capital held would fall below 20 %, 30 % or 50 %
or so that the investment firm would cease to be his subsidiary.
Member States need not apply the 30 % threshold where, in accordance with point (a) of Article 9(3) of Directive
2004/109/EC, they apply a threshold of one-third.
In determining whether the criteria for a qualifying holding referred to in Article 10 and in this Article are fulfilled,
Member States shall not take into account voting rights or shares which investment firms or credit institutions may hold
as a result of providing the underwriting of financial instruments and/or placing of financial instruments on a firm
commitment basis included under point 6 of Section A of Annex I, provided that those rights are, on the one hand, not
exercised or otherwise used to intervene in the management of the issuer and, on the other, disposed of within one year
of acquisition.
2.
The relevant competent authorities shall work in full consultation with each other when carrying out the assessment
provided for in Article 13(1) (the ‘assessment’) if the proposed acquirer is one of the following:
(a) a credit institution, assurance undertaking, insurance undertaking, reinsurance undertaking, investment firm or UCITS
management company authorised in another Member State or in a sector other than that in which the acquisition is
proposed;
(b) the parent undertaking of a credit institution, assurance undertaking, insurance undertaking, reinsurance undertaking,
investment firm or UCITS management company authorised in another Member State or in a sector other than that
in which the acquisition is proposed; or
(c) a natural or legal person controlling a credit institution, assurance undertaking, insurance undertaking, reinsurance
undertaking, investment firm or UCITS management company authorised in another Member State or in a sector
other than that in which the acquisition is proposed.
EN
L 173/392
Official Journal of the European Union
12.6.2014

<!-- source-page: 45 -->

The competent authorities shall, without undue delay, provide each other with any information which is essential or
relevant for the assessment. In that regard, the competent authorities shall communicate to each other upon request all
relevant information and shall communicate on their own initiative all essential information. A decision by the competent
authority that has authorised the investment firm in which the acquisition is proposed shall indicate any views or
reservations expressed by the competent authority responsible for the proposed acquirer.
3.
Member States shall require that, if an investment firm becomes aware of any acquisitions or disposals of holdings
in its capital that cause holdings to exceed or fall below any of the thresholds referred to in the first subparagraph of
paragraph 1, that investment firm is to inform the competent authority without delay.
At least once a year, investment firms shall also inform the competent authority of the names of shareholders and
members possessing qualifying holdings and the sizes of such holdings as shown, for example, by the information
received at annual general meetings of shareholders and members or as a result of compliance with the regulations
applicable to companies whose transferable securities are admitted to trading on a regulated market.
4.
Member States shall require that competent authorities take measures similar to those referred to in Article 10(3) in
respect of persons who fail to comply with the obligation to provide prior information in relation to the acquisition or
increase of a qualifying holding. If a holding is acquired despite the opposition of the competent authorities, the Member
States shall, regardless of any other sanctions to be adopted, provide either for exercise of the corresponding voting rights
to be suspended, for the nullity of the votes cast or for the possibility of their annulment.
Article 12
Assessment period
1.
The competent authorities shall, promptly and in any event within two working days following receipt of the
notification required under the first subparagraph of Article 11(1), as well as following the possible subsequent receipt of
the information referred to in paragraph 2 of this Article, acknowledge receipt thereof in writing to the proposed
acquirer.
The competent authorities shall have a maximum of sixty working days as from the date of the written acknowledgement
of receipt of the notification and all documents required by the Member State to be attached to the notification on the
basis of the list referred to in Article 13(4) (the ‘assessment period’), to carry out the assessment.
The competent authorities shall inform the proposed acquirer of the date of the expiry of the assessment period at the
time of acknowledging receipt.
2.
The competent authorities may, during the assessment period, if necessary, and no later than on the 50th working
day of the assessment period, request any further information that is necessary to complete the assessment. Such request
shall be made in writing and shall specify the additional information needed.
For the period between the date of request for information by the competent authorities and the receipt of a response
thereto by the proposed acquirer, the assessment period shall be interrupted. The interruption shall not exceed
20 working days. Any further requests by the competent authorities for completion or clarification of the information
shall be at their discretion but may not result in an interruption of the assessment period.
3.
The competent authorities may extend the interruption referred to in the second subparagraph of paragraph 2 up to
30 working days if the proposed acquirer is one of the following:
(a) a natural or legal person situated or regulated outside the Union;
EN
12.6.2014
Official Journal of the European Union
L 173/393

<!-- source-page: 46 -->

(b) a natural or legal person not subject to supervision under this Directive or Directives 2009/65/EC, 2009/138/EC or
2013/36/EU.
4.
If the competent authorities, upon completion of the assessment, decide to oppose the proposed acquisition, they
shall, within two working days, and not exceeding the assessment period, inform the proposed acquirer in writing and
provide the reasons for that decision. Subject to national law, an appropriate statement of the reasons for the decision
may be made accessible to the public at the request of the proposed acquirer. This shall not prevent a Member State from
allowing the competent authority to make such disclosure in the absence of a request by the proposed acquirer.
5.
If the competent authorities do not oppose the proposed acquisition within the assessment period in writing, it shall
be deemed to be approved.
6.
The competent authorities may fix a maximum period for concluding the proposed acquisition and extend it where
appropriate.
7.
Member States may not impose requirements for the notification to and approval by the competent authorities of
direct or indirect acquisitions of voting rights or capital that are more stringent than those set out in this Directive.
8.
ESMA shall develop draft regulatory technical standards to establish an exhaustive list of information, referred to in
Article 13(4) to be included by proposed acquirers in their notification, without prejudice to paragraph 2 of this Article.
ESMA shall submit those draft regulatory technical standards to the Commission by 1 January 2014.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
9.
ESMA shall develop draft implementing technical standards to determine standard forms, templates and procedures
for the modalities of the consultation process between the relevant competent authorities as referred to in Article 11(2).
ESMA shall submit those draft implementing technical standards to the Commission by 1 January 2014.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 13
Assessment
1.
In assessing the notification provided for in Article 11(1) and the information referred to in Article 12(2), the
competent authorities shall, in order to ensure the sound and prudent management of the investment firm in which an
acquisition is proposed, and having regard to the likely influence of the proposed acquirer on the investment firm,
appraise the suitability of the proposed acquirer and the financial soundness of the proposed acquisition against all of the
following criteria:
(a) the reputation of the proposed acquirer;
(b) the reputation and experience of any person who will direct the business of the investment firm as a result of the
proposed acquisition;
(c) the financial soundness of the proposed acquirer, in particular in relation to the type of business pursued and
envisaged in the investment firm in which the acquisition is proposed;
EN
L 173/394
Official Journal of the European Union
12.6.2014

<!-- source-page: 47 -->

(d) whether the investment firm will be able to comply and continue to comply with the prudential requirements based
on this Directive and, where applicable, other Directives, in particular Directives 2002/87/EC and 2013/36/EU, in
particular, whether the group of which it will become a part has a structure that makes it possible to exercise effective
supervision, effectively exchange information among the competent authorities and determine the allocation of
responsibilities among the competent authorities;
(e) whether there are reasonable grounds to suspect that, in connection with the proposed acquisition, money laundering
or terrorist financing within the meaning of Article 1 of Directive 2005/60/EC is being or has been committed or
attempted, or that the proposed acquisition could increase the risk thereof.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 which adjust the criteria set
out in the first subparagraph of this paragraph.
2.
The competent authorities may oppose the proposed acquisition only if there are reasonable grounds for doing so
on the basis of the criteria set out in paragraph 1 or if the information provided by the proposed acquirer is incomplete.
3.
Member States shall neither impose any prior conditions in respect of the level of holding that must be acquired
nor allow their competent authorities to examine the proposed acquisition in terms of the economic needs of the market.
4.
Member States shall make publicly available a list specifying the information that is necessary to carry out the
assessment and that must be provided to the competent authorities at the time of notification referred to in Article 11(1).
The information required shall be proportionate and adapted to the nature of the proposed acquirer and the proposed
acquisition. Member States shall not require information that is not relevant for a prudential assessment.
5.
Notwithstanding Article 12(1), (2) and (3), where two or more proposals to acquire or increase qualifying holdings
in the same investment firm have been notified to the competent authority, the latter shall treat the proposed acquirers in
a non-discriminatory manner.
Article 14
Membership of an authorised investor compensation scheme
The competent authority shall verify that any entity seeking authorisation as an investment firm meets its obligations
under Directive 97/9/EC at the time of authorisation.
The obligation laid down in the first paragraph shall be met in relation to structured deposits where the structured
deposit is issued by a credit institution which is a member of a deposit guarantee scheme recognised under Directive
2014/49/EU.
Article 15
Initial capital endowment
Member States shall ensure that the competent authorities do not grant authorisation unless the investment firm has
sufficient initial capital in accordance with the requirements of Regulation (EU) No 575/2013 having regard to the nature
of the investment service or activity in question.
Article 16
Organisational requirements
1.
The home Member State shall require that investment firms comply with the organisational requirements laid down
in paragraphs 2 to 10 of this Article and in Article 17.
EN
12.6.2014
Official Journal of the European Union
L 173/395

<!-- source-page: 48 -->

2.
An investment firm shall establish adequate policies and procedures sufficient to ensure compliance of the firm
including its managers, employees and tied agents with its obligations under this Directive as well as appropriate rules
governing personal transactions by such persons.
3.
An investment firm shall maintain and operate effective organisational and administrative arrangements with a view
to taking all reasonable steps designed to prevent conflicts of interest as defined in Article 23 from adversely affecting the
interests of its clients.
An investment firm which manufactures financial instruments for sale to clients shall maintain, operate and review a
process for the approval of each financial instrument and significant adaptations of existing financial instruments before it
is marketed or distributed to clients.
The product approval process shall specify an identified target market of end clients within the relevant category of clients
for each financial instrument and shall ensure that all relevant risks to such identified target market are assessed and that
the intended distribution strategy is consistent with the identified target market.
An investment firm shall also regularly review financial instruments it offers or markets, taking into account any event
that could materially affect the potential risk to the identified target market, to assess at least whether the financial
instrument remains consistent with the needs of the identified target market and whether the intended distribution
strategy remains appropriate.
An investment firm which manufactures financial instruments shall make available to any distributor all appropriate
information on the financial instrument and the product approval process, including the identified target market of the
financial instrument.
Where an investment firm offers or recommends financial instruments which it does not manufacture, it shall have in
place adequate arrangements to obtain the information referred to in the fifth subparagraph and to understand the
characteristics and identified target market of each financial instrument.
The policies, processes and arrangements referred to in this paragraph shall be without prejudice to all other requirements
under this Directive and Regulation (EU) No 600/2014, including those relating to disclosure, suitability or appropri­
ateness, identification and management of conflicts of interests, and inducements.
4.
An investment firm shall take reasonable steps to ensure continuity and regularity in the performance of investment
services and activities. To that end the investment firm shall employ appropriate and proportionate systems, resources and
procedures.
5.
An investment firm shall ensure, when relying on a third party for the performance of operational functions which
are critical for the provision of continuous and satisfactory service to clients and the performance of investment activities
on a continuous and satisfactory basis, that it takes reasonable steps to avoid undue additional operational risk.
Outsourcing of important operational functions may not be undertaken in such a way as to impair materially the
quality of its internal control and the ability of the supervisor to monitor the firm’s compliance with all obligations.
An investment firm shall have sound administrative and accounting procedures, internal control mechanisms, effective
procedures for risk assessment, and effective control and safeguard arrangements for information processing systems.
Without prejudice to the ability of competent authorities to require access to communications in accordance with this
Directive and Regulation (EU) No 600/2014, an investment firm shall have sound security mechanisms in place to
guarantee the security and authentication of the means of transfer of information, minimise the risk of data corruption
and unauthorised access and to prevent information leakage maintaining the confidentiality of the data at all times.
EN
L 173/396
Official Journal of the European Union
12.6.2014

<!-- source-page: 49 -->

6.
An investment firm shall arrange for records to be kept of all services, activities and transactions undertaken by it
which shall be sufficient to enable the competent authority to fulfil its supervisory tasks and to perform the enforcement
actions under this Directive, Regulation (EU) No 600/2014, Directive 2014/57/EU and Regulation (EU) No 596/2014,
and in particular to ascertain that the investment firm has complied with all obligations including those with respect to
clients or potential clients and to the integrity of the market.
7.
Records shall include the recording of telephone conversations or electronic communications relating to, at least,
transactions concluded when dealing on own account and the provision of client order services that relate to the
reception, transmission and execution of client orders.
Such telephone conversations and electronic communications shall also include those that are intended to result in
transactions concluded when dealing on own account or in the provision of client order services that relate to the
reception, transmission and execution of client orders, even if those conversations or communications do not result in the
conclusion of such transactions or in the provision of client order services.
For those purposes, an investment firm shall take all reasonable steps to record relevant telephone conversations and
electronic communications, made with, sent from or received by equipment provided by the investment firm to an
employee or contractor or the use of which by an employee or contractor has been accepted or permitted by the
investment firm.
An investment firm shall notify new and existing clients that telephone communications or conversations between the
investment firm and its clients that result or may result in transactions will be recorded.
Such a notification may be made once, before the provision of investment services to new and existing clients.
An investment firm shall not provide, by telephone, investment services and activities to clients who have not been
notified in advance about the recording of their telephone communications or conversations, where such investment
services and activities relate to the reception, transmission and execution of client orders.
Orders may be placed by clients through other channels, however such communications must be made in a durable
medium such as mails, faxes, emails or documentation of client orders made at meetings. In particular, the content of
relevant face-to-face conversations with a client may be recorded by using written minutes or notes. Such orders shall be
considered equivalent to orders received by telephone.
An investment firm shall take all reasonable steps to prevent an employee or contractor from making, sending or
receiving relevant telephone conversations and electronic communications on privately-owned equipment which the
investment firm is unable to record or copy.
The records kept in accordance with this paragraph shall be provided to the client involved upon request and shall be
kept for a period of five years and, where requested by the competent authority, for a period of up to seven years.
8.
An investment firm shall, when holding financial instruments belonging to clients, make adequate arrangements so
as to safeguard the ownership rights of clients, especially in the event of the investment firm’s insolvency, and to prevent
the use of a client’s financial instruments on own account except with the client’s express consent.
9.
An investment firm shall, when holding funds belonging to clients, make adequate arrangements to safeguard the
rights of clients and, except in the case of credit institutions, prevent the use of client funds for its own account.
EN
12.6.2014
Official Journal of the European Union
L 173/397

<!-- source-page: 50 -->

10.
An investment firm shall not conclude title transfer financial collateral arrangements with retail clients for the
purpose of securing or covering present or future, actual or contingent or prospective obligations of clients.
11.
In the case of branches of investment firms, the competent authority of the Member State in which the branch is
located shall, without prejudice to the possibility of the competent authority of the home Member State of the investment
firm to have direct access to those records, enforce the obligation laid down in paragraphs 6 and 7 with regard to
transactions undertaken by the branch.
Member States may, in exceptional circumstances, impose requirements on investment firms concerning the safeguarding
of client assets additional to the provisions set out in paragraphs 8, 9 and 10 and the respective delegated acts as referred
to in paragraph 12. Such requirements must be objectively justified and proportionate so as to address, where investment
firms safeguard client assets and client funds, specific risks to investor protection or to market integrity which are of
particular importance in the circumstances of the market structure of that Member State.
Member States shall notify, without undue delay, the Commission of any requirement which they intend to impose in
accordance with this paragraph and at least two months before the date appointed for that requirement to come into
force. The notification shall include a justification for that requirement. Any such additional requirements shall not restrict
or otherwise affect the rights of investment firms under Articles 34 and 35.
The Commission shall within two months of the notification referred to in the third subparagraph provide its opinion on
the proportionality of and justification for the additional requirements.
Member States may retain additional requirements provided that they were notified to the Commission in accordance
with Article 4 of Directive 2006/73/EC before 2 July 2014 and that the conditions laid down in that Article are met.
The Commission shall communicate to Member States and make public on its website the additional requirements
imposed in accordance with this paragraph.
12.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to specify the concrete
organisational requirements laid down in paragraphs 2 to 10 of this Article to be imposed on investment firms and on
branches of third-country firms authorised in accordance with Article 41 performing different investment services and/or
activities and ancillary services or combinations thereof.
Article 17
Algorithmic trading
1.
An investment firm that engages in algorithmic trading shall have in place effective systems and risk controls
suitable to the business it operates to ensure that its trading systems are resilient and have sufficient capacity, are subject
to appropriate trading thresholds and limits and prevent the sending of erroneous orders or the systems otherwise
functioning in a way that may create or contribute to a disorderly market. Such a firm shall also have in place effective
systems and risk controls to ensure the trading systems cannot be used for any purpose that is contrary to Regulation
(EU) No 596/2014 or to the rules of a trading venue to which it is connected. The investment firm shall have in place
effective business continuity arrangements to deal with any failure of its trading systems and shall ensure its systems are
fully tested and properly monitored to ensure that they meet the requirements laid down in this paragraph.
2.
An investment firm that engages in algorithmic trading in a Member State shall notify this to the competent
authorities of its home Member State and of the trading venue at which the investment firm engages in algorithmic
trading as a member or participant of the trading venue.
EN
L 173/398
Official Journal of the European Union
12.6.2014

<!-- source-page: 51 -->

The competent authority of the home Member State of the investment firm may require the investment firm to provide,
on a regular or ad-hoc basis, a description of the nature of its algorithmic trading strategies, details of the trading
parameters or limits to which the system is subject, the key compliance and risk controls that it has in place to ensure the
conditions laid down in paragraph 1 are satisfied and details of the testing of its systems. The competent authority of the
home Member State of the investment firm may, at any time, request further information from an investment firm about
its algorithmic trading and the systems used for that trading.
The competent authority of the home Member State of the investment firm shall, on the request of a competent authority
of a trading venue at which the investment firm as a member or participant of the trading venue is engaged in
algorithmic trading and without undue delay, communicate the information referred to in the second subparagraph
that it receives from the investment firm that engages in algorithmic trading.
The investment firm shall arrange for records to be kept in relation to the matters referred to in this paragraph and shall
ensure that those records be sufficient to enable its competent authority to monitor compliance with the requirements of
this Directive.
An investment firm that engages in a high-frequency algorithmic trading technique shall store in an approved form
accurate and time sequenced records of all its placed orders, including cancellations of orders, executed orders and
quotations on trading venues and shall make them available to the competent authority upon request.
3.
An investment firm that engages in algorithmic trading to pursue a market making strategy shall, taking into
account the liquidity, scale and nature of the specific market and the characteristics of the instrument traded:
(a) carry out this market making continuously during a specified proportion of the trading venue’s trading hours, except
under exceptional circumstances, with the result of providing liquidity on a regular and predictable basis to the
trading venue;
(b) enter into a binding written agreement with the trading venue which shall at least specify the obligations of the
investment firm in accordance with point (a); and
(c) have in place effective systems and controls to ensure that it fulfils its obligations under the agreement referred to in
point (b) at all times.
4.
For the purposes of this Article and of Article 48 of this Directive, an investment firm that engages in algorithmic
trading shall be considered to be pursuing a market making strategy when, as a member or participant of one or more
trading venues, its strategy, when dealing on own account, involves posting firm, simultaneous two-way quotes of
comparable size and at competitive prices relating to one or more financial instruments on a single trading venue or
across different trading venues, with the result of providing liquidity on a regular and frequent basis to the overall market.
5.
An investment firm that provides direct electronic access to a trading venue shall have in place effective systems and
controls which ensure a proper assessment and review of the suitability of clients using the service, that clients using the
service are prevented from exceeding appropriate pre-set trading and credit thresholds, that trading by clients using the
service is properly monitored and that appropriate risk controls prevent trading that may create risks to the investment
firm itself or that could create or contribute to a disorderly market or could be contrary to Regulation (EU) No 596/2014
or the rules of the trading venue. Direct electronic access without such controls is prohibited.
An investment firm that provides direct electronic access shall be responsible for ensuring that clients using that service
comply with the requirements of this Directive and the rules of the trading venue. The investment firm shall monitor the
transactions in order to identify infringements of those rules, disorderly trading conditions or conduct that may involve
market abuse and that is to be reported to the competent authority. The investment firm shall ensure that there is a
binding written agreement between the investment firm and the client regarding the essential rights and obligations
arising from the provision of the service and that under the agreement the investment firm retains responsibility under
this Directive.
EN
12.6.2014
Official Journal of the European Union
L 173/399

<!-- source-page: 52 -->

An investment firm that provides direct electronic access to a trading venue shall notify the competent authorities of its
home Member State and of the trading venue at which the investment firm provides direct electronic access accordingly.
The competent authority of the home Member State of the investment firm may require the investment firm to provide,
on a regular or ad-hoc basis, a description of the systems and controls referred to in first subparagraph and evidence that
those have been applied.
The competent authority of the home Member State of the investment firm shall, on the request of a competent authority
of a trading venue in relation to which the investment firm provides direct electronic access, communicate without undue
delay the information referred to in the fourth subparagraph that it receives from the investment firm.
The investment firm shall arrange for records to be kept in relation to the matters referred to in this paragraph and shall
ensure that those records be sufficient to enable its competent authority to monitor compliance with the requirements of
this Directive.
6.
An investment firm that acts as a general clearing member for other persons shall have in place effective systems
and controls to ensure clearing services are only applied to persons who are suitable and meet clear criteria and that
appropriate requirements are imposed on those persons to reduce risks to the investment firm and to the market. The
investment firm shall ensure that there is a binding written agreement between the investment firm and the person
regarding the essential rights and obligations arising from the provision of that service.
7.
ESMA shall develop draft regulatory technical standards to specify the following:
(a) the details of organisational requirements laid down in paragraphs 1 to 6 to be imposed on investment firms
providing different investment services and/or activities and ancillary services or combinations thereof, whereby
the specifications in relation to the organisational requirements laid down in paragraph 5 shall set out specific
requirements for direct market access and for sponsored access in such a way as to ensure that the controls
applied to sponsored access are at least equivalent to those applied to direct market access;
(b) the circumstances in which an investment firm would be obliged to enter into the market making agreement referred
to in point (b) of paragraph 3 and the content of such agreements, including the proportion of the trading venue’s
trading hours laid down in paragraph 3;
(c) the situations constituting exceptional circumstances referred to in paragraph 3, including circumstances of extreme
volatility, political and macroeconomic issues, system and operational matters, and circumstances which contradict
the investment firm’s ability to maintain prudent risk management practices as laid down in paragraph 1;
(d) the content and format of the approved form referred to in the fifth subparagraph of paragraph 2 and the length of
time for which such records must be kept by the investment firm.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
EN
L 173/400
Official Journal of the European Union
12.6.2014

<!-- source-page: 53 -->

Article 18
Trading process and finalisation of transactions in an MTF and an OTF
1.
Member States shall require that investment firms and market operators operating an MTF or an OTF, in addition to
meeting the organisational requirements laid down in Article 16, establish transparent rules and procedures for fair and
orderly trading and establish objective criteria for the efficient execution of orders. They shall have arrangements for the
sound management of the technical operations of the facility, including the establishment of effective contingency
arrangements to cope with risks of systems disruption.
2.
Member States shall require that investment firms and market operators operating an MTF or an OTF establish
transparent rules regarding the criteria for determining the financial instruments that can be traded under its systems.
Member States shall require that, where applicable, investment firms and market operators operating an MTF or an OTF
provide, or are satisfied that there is access to, sufficient publicly available information to enable its users to form an
investment judgement, taking into account both the nature of the users and the types of instruments traded.
3.
Member States shall require that investment firms and market operators operating an MTF or an OTF establish,
publish and maintain and implement transparent and non-discriminatory rules, based on objective criteria, governing
access to its facility.
4.
Member States shall require that investment firms and market operators operating an MTF or an OTF have
arrangements to identify clearly and manage the potential adverse consequences for the operation of the MTF or OTF,
or for the members or participants and users, of any conflict of interest between the interest of the MTF, the OTF, their
owners or the investment firm or market operator operating the MTF or OTF and the sound functioning of the MTF or
OTF.
5.
Member States shall require that investment firms and market operators operating an MTF or OTF comply with
Articles 48 and 49 and have in place all the necessary effective systems, procedures and arrangements to do so.
6.
Member States shall require that investment firms and market operators operating an MTF or an OTF clearly inform
its members or participants of their respective responsibilities for the settlement of the transactions executed in that
facility. Member States shall require that investment firms and market operators operating an MTF or an OTF have put in
place the necessary arrangements to facilitate the efficient settlement of the transactions concluded under the systems of
that MTF or OTF.
7.
Member States shall require that MTFs and OTFs have at least three materially active members or users, each having
the opportunity to interact with all the others in respect to price formation.
8.
Where a transferable security that has been admitted to trading on a regulated market is also traded on an MTF or
an OTF without the consent of the issuer, the issuer shall not be subject to any obligation relating to initial, ongoing or
ad hoc financial disclosure with regard to that MTF or an OTF.
9.
Member States shall require that any investment firm and market operator operating an MTF or an OTF comply
immediately with any instruction from its competent authority pursuant to Article 69(2) to suspend or remove a financial
instrument from trading.
10.
Member States shall require that investment firms and market operators operating an MTF or an OTF provide the
competent authority with a detailed description of the functioning of the MTF or OTF, including, without prejudice to
Article 20(1), (4) and (5), any links to or participation by a regulated market, an MTF, an OTF or a systematic internaliser
owned by the same investment firm or market operator, and a list of their members, participants and/or users.
Competent authorities shall make that information available to ESMA on request. Every authorisation to an investment
firm or market operator as an MTF and an OTF shall be notified to ESMA. ESMA shall establish a list of all MTFs and
OTFs in the Union. The list shall contain information on the services an MTF or an OTF provides and entail the unique
code identifying the MTF and the OTF for use in reports in accordance with Articles 6, 10 and 26 of Regulation (EU)
No 600/2014. It shall be updated on a regular basis. ESMA shall publish and keep up-to-date that list on its website.
EN
12.6.2014
Official Journal of the European Union
L 173/401

<!-- source-page: 54 -->

11.
ESMA shall develop draft implementing technical standards to determine the content and format of the description
and notification referred to in paragraph 10.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 19
Specific requirements for MTFs
1.
Member States shall require that investment firms and market operators operating an MTF, in addition to meeting
the requirements laid down in Articles 16 and 18, shall establish and implement non-discretionary rules for the execution
of orders in the system.
2.
Member States shall require that the rules referred to in Article 18(3) governing access to an MTF comply with the
conditions established in Article 53(3).
3.
Member States shall require that investment firms and market operators operating an MTF to have arrangements:
(a) to be adequately equipped to manage the risks to which it is exposed, to implement appropriate arrangements and
systems to identify all significant risks to its operation, and to put in place effective measures to mitigate those risks;
(b) to have effective arrangements to facilitate the efficient and timely finalisation of the transactions executed under its
systems; and
(c) to have available, at the time of authorisation and on an ongoing basis, sufficient financial resources to facilitate its
orderly functioning, having regard to the nature and extent of the transactions concluded on the market and the
range and degree of the risks to which it is exposed.
4.
Member States shall ensure that Articles 24, 25, Article 27(1), (2) and (4) to (10) and Article 28 are not applicable
to the transactions concluded under the rules governing an MTF between its members or participants or between the MTF
and its members or participants in relation to the use of the MTF. However, the members of or participants in the MTF
shall comply with the obligations provided for in Articles 24, 25, 27 and 28 with respect to their clients when, acting on
behalf of their clients, they execute their orders through the systems of an MTF.
5.
Member States shall not allow investment firms or market operators operating an MTF to execute client orders
against proprietary capital, or to engage in matched principal trading.
Article 20
Specific requirements for OTFs
1.
Member States shall require that an investment firm and a market operator operating an OTF establishes
arrangements preventing the execution of client orders in an OTF against the proprietary capital of the investment
firm or market operator operating the OTF or from any entity that is part of the same group or legal person as the
investment firm or market operator.
2.
Member States shall permit an investment firm or market operator operating an OTF to engage in matched
principal trading in bonds, structured finance products, emission allowances and certain derivatives only where the
client has consented to the process.
EN
L 173/402
Official Journal of the European Union
12.6.2014

<!-- source-page: 55 -->

An investment firm or market operator operating an OTF shall not use matched principal trading to execute client orders
in an OTF in derivatives pertaining to a class of derivatives that has been declared subject to the clearing obligation in
accordance with Article 5 of Regulation (EU) No 648/2012.
An investment firm or market operator operating an OTF shall establish arrangements ensuring compliance with the
definition of matched principal trading in point (38) of Article 4(1).
3.
Member States shall permit an investment firm or market operator operating an OTF to engage in dealing on own
account other than matched principal trading only with regard to sovereign debt instruments for which there is not a
liquid market.
4.
Member States shall not allow the operation of an OTF and of a systematic internaliser to take place within the
same legal entity. An OTF shall not connect with a systematic internaliser in a way which enables orders in an OTF and
orders or quotes in a systematic internaliser to interact. An OTF shall not connect with another OTF in a way which
enables orders in different OTFs to interact.
5.
Member States shall not prevent an investment firm or a market operator operating an OTF from engaging another
investment firm to carry out market making on that OTF on an independent basis.
For the purposes of this Article, an investment firm shall not be deemed to be carrying out market making on an OTF on
an independent basis if it has close links with the investment firm or market operator operating the OTF.
6.
Member States shall require that the execution of orders on an OTF is carried out on a discretionary basis.
An investment firm or market operator operating an OTF shall exercise discretion only in either or both of the following
circumstances:
(a) when deciding to place or retract an order on the OTF they operate;
(b) when deciding not to match a specific client order with other orders available in the systems at a given time, provided
it is in compliance with specific instructions received from a client and with its obligations in accordance with
Article 27.
For the system that crosses client orders the investment firm or market operator operating the OTF may decide if, when
and how much of two or more orders it wants to match within the system. In accordance with paragraphs 1, 2, 4 and 5
and without prejudice to paragraph 3, with regard to a system that arranges transactions in non-equities, the investment
firm or market operator operating the OTF may facilitate negotiation between clients so as to bring together two or more
potentially compatible trading interest in a transaction.
That obligation shall be without prejudice to Articles 18 and 27.
7.
The competent authority may require, either when an investment firm or market operator requests to be authorised
for the operation of an OTF or on ad-hoc basis, a detailed explanation why the system does not correspond to and
cannot operate as a regulated market, MTF, or systematic internaliser, a detailed description as to how discretion will be
exercised, in particular when an order to the OTF may be retracted and when and how two or more client orders will be
matched within the OTF. In addition, the investment firm or market operator of an OTF shall provide the competent
authority with information explaining its use of matched principal trading. The competent authority shall monitor an
investment firm’s or market operator’s engagement in matched principal trading to ensure that it continues to fall within
the definition of such trading and that its engagement in matched principal trading does not give rise to conflicts of
interest between the investment firm or market operator and its clients.
EN
12.6.2014
Official Journal of the European Union
L 173/403

<!-- source-page: 56 -->

8.
Member States shall ensure that Articles 24, 25, 27 and 28 are applied to the transactions concluded on an OTF.
CHAPTER II
Operating conditions for investment firms
S e c t i o n 1
G e n e r a l p r o v i s i o n s
Article 21
Regular review of conditions for initial authorisation
1.
Member States shall require that an investment firm authorised in their territory comply at all times with the
conditions for initial authorisation established in Chapter I.
2.
Member States shall require competent authorities to establish the appropriate methods to monitor that investment
firms comply with their obligation under paragraph 1. They shall require investment firms to notify the competent
authorities of any material changes to the conditions for initial authorisation.
ESMA may develop guidelines regarding the monitoring methods referred to in this paragraph.
Article 22
General obligation in respect of on-going supervision
Member States shall ensure that the competent authorities monitor the activities of investment firms so as to assess
compliance with the operating conditions provided for in this Directive. Member States shall ensure that the appropriate
measures are in place to enable the competent authorities to obtain the information needed to assess the compliance of
investment firms with those obligations.
Article 23
Conflicts of interest
1.
Member States shall require investment firms to take all appropriate steps to identify and to prevent or manage
conflicts of interest between themselves, including their managers, employees and tied agents, or any person directly or
indirectly linked to them by control and their clients or between one client and another that arise in the course of
providing any investment and ancillary services, or combinations thereof, including those caused by the receipt of
inducements from third parties or by the investment firm’s own remuneration and other incentive structures.
2.
Where organisational or administrative arrangements made by the investment firm in accordance with Article 16(3)
to prevent conflicts of interest from adversely affecting the interest of its client are not sufficient to ensure, with
reasonable confidence, that risks of damage to client interests will be prevented, the investment firm shall clearly
disclose to the client the general nature and/or sources of conflicts of interest and the steps taken to mitigate those
risks before undertaking business on its behalf.
3.
The disclosure referred to in paragraph 2 shall:
(a) be made in a durable medium; and
(b) include sufficient detail, taking into account the nature of the client, to enable that client to take an informed decision
with respect to the service in the context of which the conflict of interest arises.
EN
L 173/404
Official Journal of the European Union
12.6.2014

<!-- source-page: 57 -->

4.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to:
(a) define the steps that investment firms might reasonably be expected to take to identify, prevent, manage and disclose
conflicts of interest when providing various investment and ancillary services and combinations thereof;
(b) establish appropriate criteria for determining the types of conflict of interest whose existence may damage the
interests of the clients or potential clients of the investment firm.
S e c t i o n 2
P r o v i s i o n s t o e n s u r e i n v e s t o r p r o t e c t i o n
Article 24
General principles and information to clients
1.
Member States shall require that, when providing investment services or, where appropriate, ancillary services to
clients, an investment firm act honestly, fairly and professionally in accordance with the best interests of its clients and
comply, in particular, with the principles set out in this Article and in Article 25.
2.
Investment firms which manufacture financial instruments for sale to clients shall ensure that those financial
instruments are designed to meet the needs of an identified target market of end clients within the relevant category
of clients, the strategy for distribution of the financial instruments is compatible with the identified target market, and the
investment firm takes reasonable steps to ensure that the financial instrument is distributed to the identified target
market.
An investment firm shall understand the financial instruments they offer or recommend, assess the compatibility of the
financial instruments with the needs of the clients to whom it provides investment services, also taking account of the
identified target market of end clients as referred to in Article 16(3), and ensure that financial instruments are offered or
recommended only when this is in the interest of the client.
3.
All information, including marketing communications, addressed by the investment firm to clients or potential
clients shall be fair, clear and not misleading. Marketing communications shall be clearly identifiable as such.
4.
Appropriate information shall be provided in good time to clients or potential clients with regard to the investment
firm and its services, the financial instruments and proposed investment strategies, execution venues and all costs and
related charges. That information shall include the following:
(a) when investment advice is provided, the investment firm must, in good time before it provides investment advice,
inform the client:
(i) whether or not the advice is provided on an independent basis;
(ii) whether the advice is based on a broad or on a more restricted analysis of different types of financial instruments
and, in particular, whether the range is limited to financial instruments issued or provided by entities having close
links with the investment firm or any other legal or economic relationships, such as contractual relationships, so
close as to pose a risk of impairing the independent basis of the advice provided;
(iii) whether the investment firm will provide the client with a periodic assessment of the suitability of the financial
instruments recommended to that client;
EN
12.6.2014
Official Journal of the European Union
L 173/405

<!-- source-page: 58 -->

(b) the information on financial instruments and proposed investment strategies must include appropriate guidance on
and warnings of the risks associated with investments in those instruments or in respect of particular investment
strategies and whether the financial instrument is intended for retail or professional clients, taking account of the
identified target market in accordance with paragraph 2;
(c) the information on all costs and associated charges must include information relating to both investment and
ancillary services, including the cost of advice, where relevant, the cost of the financial instrument recommended
or marketed to the client and how the client may pay for it, also encompassing any third-party payments.
The information about all costs and charges, including costs and charges in connection with the investment service and
the financial instrument, which are not caused by the occurrence of underlying market risk, shall be aggregated to allow
the client to understand the overall cost as well as the cumulative effect on return of the investment, and where the client
so requests, an itemised breakdown shall be provided. Where applicable, such information shall be provided to the client
on a regular basis, at least annually, during the life of the investment.
5.
The information referred to in paragraphs 4 and 9 shall be provided in a comprehensible form in such a manner
that clients or potential clients are reasonably able to understand the nature and risks of the investment service and of the
specific type of financial instrument that is being offered and, consequently, to take investment decisions on an informed
basis. Member States may allow that information to be provided in a standardised format.
6.
Where an investment service is offered as part of a financial product which is already subject to other provisions of
Union law relating to credit institutions and consumer credits with respect to information requirements, that service shall
not be additionally subject to the obligations set out in paragraphs 3, 4 and 5.
7.
Where an investment firm informs the client that investment advice is provided on an independent basis, that
investment firm shall:
(a) assess a sufficient range of financial instruments available on the market which must be sufficiently diverse with
regard to their type and issuers or product providers to ensure that the client’s investment objectives can be suitably
met and must not be limited to financial instruments issued or provided by:
(i) the investment firm itself or by entities having close links with the investment firm; or
(ii) other entities with which the investment firm has such close legal or economic relationships, such as contractual
relationships, as to pose a risk of impairing the independent basis of the advice provided;
(b) not accept and retain fees, commissions or any monetary or non-monetary benefits paid or provided by any third
party or a person acting on behalf of a third party in relation to the provision of the service to clients. Minor non-
monetary benefits that are capable of enhancing the quality of service provided to a client and are of a scale and
nature such that they could not be judged to impair compliance with the investment firm’s duty to act in the best
interest of the client must be clearly disclosed and are excluded from this point.
8.
When providing portfolio management the investment firm shall not accept and retain fees, commissions or any
monetary or non-monetary benefits paid or provided by any third party or a person acting on behalf of a third party in
relation to the provision of the service to clients. Minor non-monetary benefits that are capable of enhancing the quality
of service provided to a client and are of a scale and nature such that they could not be judged to impair compliance with
the investment firm’s duty to act in the best interest of the client shall be clearly disclosed and are excluded from this
paragraph.
EN
L 173/406
Official Journal of the European Union
12.6.2014

<!-- source-page: 59 -->

9.
Member States shall ensure that investment firms are regarded as not fulfilling their obligations under Article 23 or
under paragraph 1 of this Article where they pay or are paid any fee or commission, or provide or are provided with any
non-monetary benefit in connection with the provision of an investment service or an ancillary service, to or by any
party except the client or a person on behalf of the client, other than where the payment or benefit:
(a) is designed to enhance the quality of the relevant service to the client; and
(b) does not impair compliance with the investment firm’s duty to act honestly, fairly and professionally in accordance
with the best interest of its clients.
The existence, nature and amount of the payment or benefit referred to in the first subparagraph, or, where the amount
cannot be ascertained, the method of calculating that amount, must be clearly disclosed to the client, in a manner that is
comprehensive, accurate and understandable, prior to the provision of the relevant investment or ancillary service. Where
applicable, the investment firm shall also inform the client on mechanisms for transferring to the client the fee,
commission, monetary or non-monetary benefit received in relation to the provision of the investment or ancillary
service.
The payment or benefit which enables or is necessary for the provision of investment services, such as custody costs,
settlement and exchange fees, regulatory levies or legal fees, and which by its nature cannot give rise to conflicts with the
investment firm’s duties to act honestly, fairly and professionally in accordance with the best interests of its clients, is not
subject to the requirements set out in the first subparagraph.
10.
An investment firm which provides investment services to clients shall ensure that it does not remunerate or assess
the performance of its staff in a way that conflicts with its duty to act in the best interests of its clients. In particular, it
shall not make any arrangement by way of remuneration, sales targets or otherwise that could provide an incentive to its
staff to recommend a particular financial instrument to a retail client when the investment firm could offer a different
financial instrument which would better meet that client’s needs.
11.
When an investment service is offered together with another service or product as part of a package or as a
condition for the same agreement or package, the investment firm shall inform the client whether it is possible to buy the
different components separately and shall provide for a separate evidence of the costs and charges of each component.
Where the risks resulting from such an agreement or package offered to a retail client are likely to be different from the
risks associated with the components taken separately, the investment firm shall provide an adequate description of the
different components of the agreement or package and the way in which its interaction modifies the risks.
ESMA, in cooperation with EBA and EIOPA, shall develop by 3 January 2016, and update periodically, guidelines for the
assessment and the supervision of cross-selling practices indicating, in particular, situations in which cross-selling practices
are not compliant with obligations laid down in paragraph 1.
12.
Member States may, in exceptional cases, impose additional requirements on investment firms in respect of the
matters covered by this Article. Such requirements must be objectively justified and proportionate so as to address specific
risks to investor protection or to market integrity which are of particular importance in the circumstances of the market
structure of that Member State.
Member States shall notify the Commission of any requirement which they intend to impose in accordance with this
paragraph without undue delay and at least two months before the date appointed for that requirement to come into
force. The notification shall include a justification for that requirement. Any such additional requirements shall not restrict
or otherwise affect the rights of investment firms under Articles 34 and 35 of this Directive.
EN
12.6.2014
Official Journal of the European Union
L 173/407

<!-- source-page: 60 -->

The Commission shall within two months from the notification referred to in the second subparagraph provide its
opinion on the proportionality of and justification for the additional requirements.
The Commission shall communicate to Member States and make public on its website the additional requirements
imposed in accordance with this paragraph.
Member States may retain additional requirements that were notified to the Commission in accordance with Article 4 of
Directive 2006/73/EC before 2 July 2014 provided that the conditions laid down in that Article are met.
13.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to ensure that
investment firms comply with the principles set out in this Article when providing investment or ancillary services to
their clients, including:
(a) the conditions with which the information must comply in order to be fair, clear and not misleading;
(b) the details about content and format of information to clients in relation to client categorisation, investment firms
and their services, financial instruments, costs and charges;
(c) the criteria for the assessment of a range of financial instruments available on the market;
(d) the criteria to assess compliance of firms receiving inducements with the obligation to act honestly, fairly and
professionally in accordance with the best interest of the client.
In formulating the requirements for information on financial instruments in relation to point b of paragraph 4
information on the structure of the product shall be included, where applicable, taking into account any relevant
standardized information required under Union law.
14.
The delegated acts referred to in paragraph 13 shall take into account:
(a) the nature of the service(s) offered or provided to the client or potential client, taking into account the type, object,
size and frequency of the transactions;
(b) the nature and range of products being offered or considered including different types of financial instruments;
(c) the retail or professional nature of the client or potential clients or, in the case of paragraphs 4 and 5, their
classification as eligible counterparties.
Article 25
Assessment of suitability and appropriateness and reporting to clients
1.
Member States shall require investment firms to ensure and demonstrate to competent authorities on request that
natural persons giving investment advice or information about financial instruments, investment services or ancillary
services to clients on behalf of the investment firm possess the necessary knowledge and competence to fulfil their
obligations under Article 24 and this Article. Member States shall publish the criteria to be used for assessing such
knowledge and competence.
EN
L 173/408
Official Journal of the European Union
12.6.2014

<!-- source-page: 61 -->

2.
When providing investment advice or portfolio management the investment firm shall obtain the necessary
information regarding the client’s or potential client’s knowledge and experience in the investment field relevant to
the specific type of product or service, that person’s financial situation including his ability to bear losses, and his
investment objectives including his risk tolerance so as to enable the investment firm to recommend to the client or
potential client the investment services and financial instruments that are suitable for him and, in particular, are in
accordance with his risk tolerance and ability to bear losses.
Member States shall ensure that where an investment firm provides investment advice recommending a package of
services or products bundled pursuant to Article 24(11), the overall bundled package is suitable.
3.
Member States shall ensure that investment firms, when providing investment services other than those referred to
in paragraph 2, ask the client or potential client to provide information regarding that person’s knowledge and experience
in the investment field relevant to the specific type of product or service offered or demanded so as to enable the
investment firm to assess whether the investment service or product envisaged is appropriate for the client. Where a
bundle of services or products is envisaged pursuant to Article 24(11), the assessment shall consider whether the overall
bundled package is appropriate.
Where the investment firm considers, on the basis of the information received under the first subparagraph, that the
product or service is not appropriate to the client or potential client, the investment firm shall warn the client or potential
client. That warning may be provided in a standardised format.
Where clients or potential clients do not provide the information referred to under the first subparagraph, or where they
provide insufficient information regarding their knowledge and experience, the investment firm shall warn them that the
investment firm is not in a position to determine whether the service or product envisaged is appropriate for them. That
warning may be provided in a standardised format.
4.
Member States shall allow investment firms when providing investment services that only consist of execution or
reception and transmission of client orders with or without ancillary services, excluding the granting of credits or loans as
specified in Section B.1 of Annex I that do not comprise of existing credit limits of loans, current accounts and overdraft
facilities of clients, to provide those investment services to their clients without the need to obtain the information or
make the determination provided for in paragraph 3 where all the following conditions are met:
(a) the services relate to any of the following financial instruments:
(i) shares admitted to trading on a regulated market or on an equivalent third-country market or on a MTF, where
those are shares in companies, and excluding shares in non-UCITS collective investment undertakings and shares
that embed a derivative;
(ii) bonds or other forms of securitised debt admitted to trading on a regulated market or on an equivalent third
country market or on a MTF, excluding those that embed a derivative or incorporate a structure which makes it
difficult for the client to understand the risk involved;
(iii) money-market instruments, excluding those that embed a derivative or incorporate a structure which makes it
difficult for the client to understand the risk involved;
(iv) shares or units in UCITS, excluding structured UCITS as referred to in the second subparagraph of Article 36(1)
of Regulation (EU) No 583/2010;
EN
12.6.2014
Official Journal of the European Union
L 173/409

<!-- source-page: 62 -->

(v) structured deposits, excluding those that incorporate a structure which makes it difficult for the client to
understand the risk of return or the cost of exiting the product before term;
(vi) other non-complex financial instruments for the purpose of this paragraph.
For the purpose of this point, if the requirements and the procedure laid down under the third and the fourth
subparagraphs of Article 4(1) of Directive 2003/71/EC are fulfilled, a third-country market shall be considered to be
equivalent to a regulated market.
(b) the service is provided at the initiative of the client or potential client;
(c) the client or potential client has been clearly informed that in the provision of that service the investment firm is not
required to assess the appropriateness of the financial instrument or service provided or offered and that therefore he
does not benefit from the corresponding protection of the relevant conduct of business rules. Such a warning may be
provided in a standardised format;
(d) the investment firm complies with its obligations under Article 23.
5.
The investment firm shall establish a record that includes the document or documents agreed between the
investment firm and the client that set out the rights and obligations of the parties, and the other terms on which
the investment firm will provide services to the client. The rights and duties of the parties to the contract may be
incorporated by reference to other documents or legal texts.
6.
The investment firm shall provide the client with adequate reports on the service provided in a durable medium.
Those reports shall include periodic communications to clients, taking into account the type and the complexity of
financial instruments involved and the nature of the service provided to the client and shall include, where applicable, the
costs associated with the transactions and services undertaken on behalf of the client.
When providing investment advice, the investment firm shall, before the transaction is made, provide the client with a
statement on suitability in a durable medium specifying the advice given and how that advice meets the preferences,
objectives and other characteristics of the retail client.
Where the agreement to buy or sell a financial instrument is concluded using a means of distance communication which
prevents the prior delivery of the suitability statement, the investment firm may provide the written statement on
suitability in a durable medium immediately after the client is bound by any agreement, provided both the following
conditions are met:
(a) the client has consented to receiving the suitability statement without undue delay after the conclusion of the
transaction; and
(b) the investment firm has given the client the option of delaying the transaction in order to receive the statement on
suitability in advance.
Where an investment firm provides portfolio management or has informed the client that it will carry out a periodic
assessment of suitability, the periodic report shall contain an updated statement of how the investment meets the client’s
preferences, objectives and other characteristics of the retail client.
EN
L 173/410
Official Journal of the European Union
12.6.2014

<!-- source-page: 63 -->

7.
If a credit agreement relating to residential immovable property, which is subject to the provisions concerning
creditworthiness assessment of consumers laid down in Directive 2014/17/EU of the European Parliament and the
Council ( 1 ), has as a prerequisite the provision to that same consumer of an investment service in relation to
mortgage bonds specifically issued to secure the financing of and having identical terms as the credit agreement
relating to residential immovable property, in order for the loan to be payable, refinanced or redeemed, that service
shall not be subject to the obligations set out in this Article.
8.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to ensure that
investment firms comply with the principles set out in paragraphs 2 to 6 of this Article when providing investment
or ancillary services to their clients, including information to obtain when assessing the suitability or appropriateness of
the services and financial instruments for their clients, criteria to assess non-complex financial instruments for the
purposes of point (a)(vi) of paragraph 4 of this Article, the content and the format of records and agreements for the
provision of services to clients and of periodic reports to clients on the services provided. Those delegated acts shall take
into account:
(a) the nature of the service(s) offered or provided to the client or potential client, having regard to the type, object, size
and frequency of the transactions;
(b) the nature of the products being offered or considered, including different types of financial instruments;
(c) the retail or professional nature of the client or potential clients or, in the case of paragraph 6, their classification as
eligible counterparties.
9.
ESMA shall adopt by 3 January 2016 guidelines specifying criteria for the assessment of knowledge and competence
required under paragraph 1.
10.
ESMA shall develop by 3 January 2016, and update periodically, guidelines for the assessment of:
(a) financial instruments incorporating a structure which makes it difficult for the client to understand the risk involved
in accordance with points (a)(ii) and (a)(iii) of paragraph 4;
(b) structured deposits incorporating a structure which makes it difficult for the client to understand the risk of return or
the cost of exiting the product before term, in accordance with point (a)(v) of paragraph 4.
11.
ESMA may develop guidelines, and update them periodically, for the assessment of financial instruments being
classified as non-complex for the purpose of point (a)(vi) of paragraph 4, taking into account the delegated acts adopted
under paragraph 8.
Article 26
Provision of services through the medium of another investment firm
Member States shall allow an investment firm receiving an instruction to provide investment or ancillary services on
behalf of a client through the medium of another investment firm to rely on client information transmitted by the latter
investment firm. The investment firm which mediates the instructions will remain responsible for the completeness and
accuracy of the information transmitted.
EN
12.6.2014
Official Journal of the European Union
L 173/411
( 1 ) Directive 2014/17/EU of the European Parliament and of the Council of 4 February 2014 on credit agreements for consumers
relating to residential immovable property and amending Directives 2008/48/EC and 2013/36/EU and Regulation (EU)
No 1093/2010 (OJ L 60, 28.2.2014, p. 34).

<!-- source-page: 64 -->

The investment firm which receives an instruction to undertake services on behalf of a client in that way shall also be
able to rely on any recommendations in respect of the service or transaction that have been provided to the client by
another investment firm. The investment firm which mediates the instructions will remain responsible for the suitability
for the client of the recommendations or advice provided.
The investment firm which receives client instructions or orders through the medium of another investment firm shall
remain responsible for concluding the service or transaction, based on any such information or recommendations, in
accordance with the relevant provisions of this Title.
Article 27
Obligation to execute orders on terms most favourable to the client
1.
Member States shall require that investment firms take all sufficient steps to obtain, when executing orders, the best
possible result for their clients taking into account price, costs, speed, likelihood of execution and settlement, size, nature
or any other consideration relevant to the execution of the order. Nevertheless, where there is a specific instruction from
the client the investment firm shall execute the order following the specific instruction.
Where an investment firm executes an order on behalf of a retail client, the best possible result shall be determined in
terms of the total consideration, representing the price of the financial instrument and the costs relating to execution,
which shall include all expenses incurred by the client which are directly relating to the execution of the order, including
execution venue fees, clearing and settlement fees and any other fees paid to third parties involved in the execution of the
order.
For the purposes of delivering best possible result in accordance with the first subparagraph where there is more than one
competing venue to execute an order for a financial instrument, in order to assess and compare the results for the client
that would be achieved by executing the order on each of the execution venues listed in the investment firm’s order
execution policy that is capable of executing that order, the investment firm’s own commissions and the costs for
executing the order on each of the eligible execution venues shall be taken into account in that assessment.
2.
An investment firm shall not receive any remuneration, discount or non-monetary benefit for routing client orders
to a particular trading venue or execution venue which would infringe the requirements on conflicts of interest or
inducements set out in paragraph 1 of this Article and Article 16(3) and Articles 23 and 24.
3.
Member States shall require that for financial instruments subject to the trading obligation in Articles 23 and 28
Regulation (EU) No 600/2014 each trading venue and systematic internaliser and for other financial instruments each
execution venue makes available to the public, without any charges, data relating to the quality of execution of trans­
actions on that venue on at least an annual basis and that following execution of a transaction on behalf of a client the
investment firm shall inform the client where the order was executed. Periodic reports shall include details about price,
costs, speed and likelihood of execution for individual financial instruments.
4.
Member States shall require investment firms to establish and implement effective arrangements for complying with
paragraph 1. In particular, Member States shall require investment firms to establish and implement an order execution
policy to allow them to obtain, for their client orders, the best possible result in accordance with paragraph 1.
5.
The order execution policy shall include, in respect of each class of financial instruments, information on the
different venues where the investment firm executes its client orders and the factors affecting the choice of execution
venue. It shall at least include those venues that enable the investment firm to obtain on a consistent basis the best
possible result for the execution of client orders.
Member States shall require that investment firms provide appropriate information to their clients on their order
execution policy. That information shall explain clearly, in sufficient detail and in a way that can be easily understood
by clients, how orders will be executed by the investment firm for the client. Member States shall require that investment
firms obtain the prior consent of their clients to the order execution policy.
EN
L 173/412
Official Journal of the European Union
12.6.2014

<!-- source-page: 65 -->

Member States shall require that, where the order execution policy provides for the possibility that client orders may be
executed outside a trading venue, the investment firm shall, in particular, inform its clients about that possibility. Member
States shall require that investment firms obtain the prior express consent of their clients before proceeding to execute
their orders outside a trading venue. Investment firms may obtain such consent either in the form of a general agreement
or in respect of individual transactions.
6.
Member States shall require investment firms who execute client orders to summarise and make public on an
annual basis, for each class of financial instruments, the top five execution venues in terms of trading volumes where they
executed client orders in the preceding year and information on the quality of execution obtained.
7.
Member States shall require investment firms who execute client orders to monitor the effectiveness of their order
execution arrangements and execution policy in order to identify and, where appropriate, correct any deficiencies. In
particular, they shall assess, on a regular basis, whether the execution venues included in the order execution policy
provide for the best possible result for the client or whether they need to make changes to their execution arrangements,
taking account of, inter alia, the information published under paragraphs 3 and 6. Member States shall require investment
firms to notify clients with whom they have an ongoing client relationship of any material changes to their order
execution arrangements or execution policy.
8.
Member States shall require investment firms to be able to demonstrate to their clients, at their request, that they
have executed their orders in accordance with the investment firm’s execution policy and to demonstrate to the
competent authority, at its request, their compliance with this Article.
9.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 concerning:
(a) the criteria for determining the relative importance of the different factors that, pursuant to paragraph 1, may be
taken into account for determining the best possible result taking into account the size and type of order and the
retail or professional nature of the client;
(b) factors that may be taken into account by an investment firm when reviewing its execution arrangements and the
circumstances under which changes to such arrangements may be appropriate. In particular, the factors for deter­
mining which venues enable investment firms to obtain on a consistent basis the best possible result for executing the
client orders;
(c) the nature and extent of the information to be provided to clients on their execution policies, pursuant to
paragraph 5.
10.
ESMA shall develop draft regulatory technical standards to determine:
(a) the specific content, the format and the periodicity of data relating to the quality of execution to be published in
accordance with paragraph 3, taking into account the type of execution venue and the type of financial instrument
concerned;
(b) the content and the format of information to be published by investment firms in accordance with paragraph 6.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
EN
12.6.2014
Official Journal of the European Union
L 173/413

<!-- source-page: 66 -->

Article 28
Client order handling rules
1.
Member States shall require that investment firms authorised to execute orders on behalf of clients implement
procedures and arrangements which provide for the prompt, fair and expeditious execution of client orders, relative to
other client orders or the trading interests of the investment firm.
Those procedures or arrangements shall allow for the execution of otherwise comparable client orders in accordance with
the time of their reception by the investment firm.
2.
Member States shall require that, in the case of a client limit order in respect of shares admitted to trading on a
regulated market or traded on a trading venue which are not immediately executed under prevailing market conditions,
investment firms are, unless the client expressly instructs otherwise, to take measures to facilitate the earliest possible
execution of that order by making public immediately that client limit order in a manner which is easily accessible to
other market participants. Member States may decide that investment firms comply with that obligation by transmitting
the client limit order to a trading venue. Member States shall provide that the competent authorities may waive the
obligation to make public a limit order that is large in scale compared with normal market size as determined under
Article 4 of Regulation (EU) No 600/2014.
3.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to define:
(a) the conditions and nature of the procedures and arrangements which result in the prompt, fair and expeditious
execution of client orders and the situations in which or types of transaction for which investment firms may
reasonably deviate from prompt execution so as to obtain more favourable terms for clients;
(b) the different methods through which an investment firm can be deemed to have met its obligation to disclose not
immediately executable client limit orders to the market.
Article 29
Obligations of investment firms when appointing tied agents
1.
Member States shall allow an investment firm to appoint tied agents for the purposes of promoting the services of
the investment firm, soliciting business or receiving orders from clients or potential clients and transmitting them, placing
financial instruments and providing advice in respect of such financial instruments and services offered by that investment
firm.
2.
Member States shall require that where an investment firm decides to appoint a tied agent it remains fully and
unconditionally responsible for any action or omission on the part of the tied agent when acting on behalf of the
investment firm. Member States shall require the investment firm to ensure that a tied agent discloses the capacity in
which he is acting and the investment firm which he is representing when contacting or before dealing with any client or
potential client.
Member States may allow, in accordance with Article 16(6), (8) and (9), tied agents registered in their territory to hold
money and/or financial instruments of clients on behalf and under the full responsibility of the investment firm for which
they are acting within their territory or, in the case of a cross border operation, in the territory of a Member State which
allows a tied agent to hold client money.
Member States shall require the investment firms to monitor the activities of their tied agents so as to ensure that they
continue to comply with this Directive when acting through tied agents.
3.
Tied agents shall be registered in the public register in the Member State where they are established. ESMA shall
publish on its website references or hyperlinks to the public registers established under this Article by the Member States
that decide to allow investment firms to appoint tied agents.
EN
L 173/414
Official Journal of the European Union
12.6.2014

<!-- source-page: 67 -->

Member States shall ensure that tied agents are only admitted to the public register if it has been established that they are
of sufficiently good repute and that they possess the appropriate general, commercial and professional knowledge and
competence so as to be able to deliver the investment service or ancillary service and to communicate accurately all
relevant information regarding the proposed service to the client or potential client.
Member States may decide that, subject to appropriate control, investment firms can verify whether the tied agents which
they have appointed are of sufficiently good repute and possess the knowledge and competence referred to in the second
subparagraph.
The register shall be updated on a regular basis. It shall be publicly available for consultation.
4.
Member States shall require that investment firms appointing tied agents take adequate measures in order to avoid
any negative impact that the activities of the tied agent not covered by the scope of this Directive could have on the
activities carried out by the tied agent on behalf of the investment firm.
Member States may allow competent authorities to collaborate with investment firms and credit institutions, their
associations and other entities in registering tied agents and in monitoring compliance of tied agents with the
requirements of paragraph 3. In particular, tied agents may be registered by an investment firm, credit institution or
their associations and other entities under the supervision of the competent authority.
5.
Member States shall require that investment firms appoint only tied agents entered in the public registers referred to
in paragraph 3.
6.
Member States may adopt or retain provisions that are more stringent than those set out in this Article or add
further requirements for tied agents registered within their jurisdiction.
Article 30
Transactions executed with eligible counterparties
1.
Member States shall ensure that investment firms authorised to execute orders on behalf of clients and/or to deal on
own account and/or to receive and transmit orders, may bring about or enter into transactions with eligible counter­
parties without being obliged to comply with the obligations under Article 24, with the exception of paragraphs 4 and 5,
Article 25, with the exception of paragraph 6, Article 27 and Article 28(1) in respect of those transactions or in respect
of any ancillary service directly relating to those transactions.
Member States shall ensure that, in their relationship with eligible counterparties, investment firms act honestly, fairly and
professionally and communicate in a way which is fair, clear and not misleading, taking into account the nature of the
eligible counterparty and of its business.
2.
Member States shall recognise as eligible counterparties for the purposes of this Article investment firms, credit
institutions, insurance companies, UCITS and their management companies, pension funds and their management
companies, other financial institutions authorised or regulated under Union law or under the national law of a
Member State, national governments and their corresponding offices including public bodies that deal with public
debt at national level, central banks and supranational organisations.
Classification as an eligible counterparty under the first subparagraph shall be without prejudice to the right of such
entities to request, either on a general form or on a trade-by-trade basis, treatment as clients whose business with the
investment firm is subject to Articles 24, 25, 27 and 28.
EN
12.6.2014
Official Journal of the European Union
L 173/415

<!-- source-page: 68 -->

3.
Member States may also recognise as eligible counterparties other undertakings meeting pre-determined propor­
tionate requirements, including quantitative thresholds. In the event of a transaction where the prospective counterparties
are located in different jurisdictions, the investment firm shall defer to the status of the other undertaking as determined
by the law or measures of the Member State in which that undertaking is established.
Member States shall ensure that the investment firm, when it enters into transactions in accordance with paragraph 1
with such undertakings, obtains the express confirmation from the prospective counterparty that it agrees to be treated as
an eligible counterparty. Member States shall allow the investment firm to obtain that confirmation either in the form of
a general agreement or in respect of each individual transaction.
4.
Member States may recognise as eligible counterparties third country entities equivalent to those categories of
entities referred to in paragraph 2.
Member States may also recognise as eligible counterparties third country undertakings such as those referred to in
paragraph 3 on the same conditions and subject to the same requirements as those laid down in paragraph 3.
5.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to specify:
(a) the procedures for requesting treatment as clients under paragraph 2;
(b) the procedures for obtaining the express confirmation from prospective counterparties under paragraph 3;
(c) the pre-determined proportionate requirements, including quantitative thresholds that would allow an undertaking to
be considered to be an eligible counterparty under paragraph 3.
S e c t i o n 3
M a r k e t t r a n s p a r e n c y a n d i n t e g r i t y
Article 31
Monitoring of compliance with the rules of the MTF or the OTF and with other legal obligations
1.
Member States shall require that investment firms and market operators operating an MTF or OTF establish and
maintain effective arrangements and procedures, relevant to the MTF or OTF, for the regular monitoring of the
compliance by its members or participants or users with its rules. Investment firms and market operators operating
an MTF or an OTF shall monitor the orders sent, including cancellations and the transactions undertaken by their
members or participants or users under their systems, in order to identify infringements of those rules, disorderly
trading conditions, conduct that may indicate behaviour that is prohibited under Regulation (EU) No 596/2014 or
system disruptions in relation to a financial instrument and shall deploy the resource necessary to ensure that such
monitoring is effective.
2.
Member States shall require investment firms and market operators operating an MTF or an OTF to inform its
competent authority immediately of significant infringements of its rules or disorderly trading conditions or conduct that
may indicate behaviour that is prohibited under Regulation (EU) No 596/2014 or system disruptions in relation to a
financial instrument.
The competent authorities of the investment firms and market operators operating an MTF or an OTF shall communicate
to ESMA and to the competent authorities of the other Member States the information referred to in the first subpara­
graph.
In relation to conduct that may indicate behaviour that is prohibited under Regulation (EU) No 596/2014, a competent
authority must be convinced that such behaviour is being or has been carried out before it notifies the competent
authorities of the other Member States and ESMA.
EN
L 173/416
Official Journal of the European Union
12.6.2014

<!-- source-page: 69 -->

3.
Member States shall also require investment firms and market operators operating an MTF or an OTF to also supply
without undue delay the information referred to in paragraph 2 to the authority competent for the investigation and
prosecution of market abuse and to provide full assistance to the latter in investigating and prosecuting market abuse
occurring on or through its systems.
4.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to determine circum­
stances that trigger an information requirement as referred to in paragraph 2 of this Article.
Article 32
Suspension and removal of financial instruments from trading on an MTF or an OTF
1.
Without prejudice to the right of the competent authority under Article 69(2) to demand suspension or removal of
a financial instrument from trading, an investment firm or a market operator operating an MTF or an OTF may suspend
or remove from trading a financial instrument which no longer complies with the rules of the MTF or an OTF unless
such suspension or removal would be likely to cause significant damage to the investors’ interests or the orderly
functioning of the market.
2.
Member States shall require that an investment firm or a market operator operating an MTF or an OTF that
suspends or removes from trading a financial instrument also suspends or removes derivatives referred to in points (4) to
(10) of Section C of Annex I that relate or are referenced to that financial instrument where necessary to support the
objectives of the suspension or removal of the underlying financial instrument. The investment firm or market operator
operating an MTF or an OTF shall make public its decision on the suspension or removal of the financial instrument and
of any related derivative and communicate the relevant decisions to its competent authority.
The competent authority, in whose jurisdiction the suspension or removal originated, shall require that regulated markets,
other MTFs, other OTFs and systematic internalisers, which fall under its jurisdiction and trade the same financial
instrument or derivatives referred to in points (4) to (10) of Section C of Annex I to this Directive that relate or are
referenced to that financial instrument, also suspend or remove that financial instrument or derivatives from trading,
where the suspension or removal is due to suspected market abuse, a take-over bid or the non-disclosure of inside
information about the issuer or financial instrument infringing Articles 7 and 17 of Regulation (EU) No 596/2014 except
where such suspension or removal could cause significant damage to the investors’ interests or the orderly functioning of
the market.
The competent authority shall immediately make public and communicate to ESMA and the competent authorities of the
other Member States such a decision.
The notified competent authorities of the other Member States shall require that regulated markets, other MTFs, other
OTFs and systematic internalisers, which fall under their jurisdiction and trade the same financial instrument or
derivatives referred to in points (4) to (10) of Section C of Annex I that relate or are referenced to that financial
instrument, also suspend or remove that financial instrument or derivatives from trading, where the suspension or
removal is due to suspected market abuse, a take-over bid or the non-disclosure of inside information about the
issuer or financial instrument infringing Articles 7 and 17 of Regulation (EU) No 596/2014 except where such
suspension or removal could cause significant damage to the investors’ interests or the orderly functioning of the market.
Each notified competent authority shall communicate its decision to ESMA and other competent authorities, including an
explanation if the decision was not to suspend or remove from trading the financial instrument or derivatives referred to
in points (4) to (10) of Section C of Annex I that relate or are referenced to that financial instrument.
This paragraph also applies when the suspension from trading of a financial instrument or derivatives referred to in
points (4) to (10) of Section C of Annex I that relate or are referenced to that financial instrument is lifted.
EN
12.6.2014
Official Journal of the European Union
L 173/417

<!-- source-page: 70 -->

The notification procedure referred to in this paragraph shall also apply in the case where the decision to suspend or
remove from trading a financial instrument or derivatives referred to in points (4) to (10) of Section C of Annex I that
relate or are referenced to that financial instrument is taken by the competent authority pursuant to points (m) and (n) of
Article 69(2).
In order to ensure that the obligation to suspend or remove from trading such derivatives is applied proportionately,
ESMA shall develop draft regulatory technical standards to further specify the cases in which the connection between a
derivative as referred to in points (4) to (10) of Section C of Annex I relating or referenced to a financial instrument
suspended or removed from trading and the original financial instrument implies that the derivative is also to be
suspended or removed from trading, in order to achieve the objective of the suspension or removal of the underlying
financial instrument.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
3.
ESMA shall develop draft implementing technical standards to determine the format and timing of the communi­
cations and the publication referred to in paragraph 2.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
4.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to list situations
constituting significant damage to the investors’ interests and the orderly functioning of the market referred to in
paragraphs 1 and 2 of this Article.
S e c t i o n 4
S M E g r o w t h m a r k e t s
Article 33
SME growth markets
1.
Member States shall provide that the operator of a MTF may apply to its home competent authority to have the
MTF registered as an SME growth market.
2.
Member States shall provide that the home competent authority may register the MTF as an SME growth market if
the competent authority receives an application referred to in paragraph 1 and is satisfied that the requirements in
paragraph 3 are complied with in relation to the MTF.
3.
Member States shall ensure that MTFs are subject to effective rules, systems and procedures which ensure that the
following is complied with:
(a) at least 50 % of the issuers whose financial instruments are admitted to trading on the MTF are SMEs at the time
when the MTF is registered as an SME growth market and in any calendar year thereafter;
EN
L 173/418
Official Journal of the European Union
12.6.2014

<!-- source-page: 71 -->

(b) appropriate criteria are set for initial and ongoing admission to trading of financial instruments of issuers on the
market;
(c) on initial admission to trading of financial instruments on the market there is sufficient information published to
enable investors to make an informed judgment about whether or not to invest in the financial instruments, either an
appropriate admission document or a prospectus if the requirements laid down in Directive 2003/71/EC are
applicable in respect of a public offer being made in conjunction with the initial admission to trading of the
financial instrument on the MTF;
(d) there is appropriate ongoing periodic financial reporting by or on behalf of an issuer on the market, for example
audited annual reports;
(e) issuers on the market as defined in point (21) of Article 3(1) of Regulation (EU) No 596/2014, persons discharging
managerial responsibilities as defined in point (25) of Article 3(1) of Regulation (EU) No 596/2014 and persons
closely associated with them as defined in point (26) of Article 3(1) of Regulation (EU) No 596/2014 comply with
relevant requirements applicable to them under Regulation (EU) No 596/2014;
(f) regulatory information concerning the issuers on the market is stored and disseminated to the public;
(g) there are effective systems and controls aiming to prevent and detect market abuse on that market as required under
the Regulation (EU) No 596/2014.
4.
The criteria in paragraph 3 are without prejudice to compliance by the investment firm or market operator
operating the MTF with other obligations under this Directive relevant to the operation of MTFs. They also do not
prevent the investment firm or market operator operating the MTF from imposing additional requirements to those
specified in that paragraph.
5.
Member States shall provide that the home competent authority may deregister a MTF as an SME growth market in
any of the following cases:
(a) the investment firm or market operator operating the market applies for its deregistration;
(b) the requirements in paragraph 3 are no longer complied with in relation to the MTF.
6.
Members States shall require that if a home competent authority registers or deregisters an MTF as an SME growth
market under this Article it shall as soon as possible notify ESMA of that registration or deregistration. ESMA shall
publish on its website a list of SME growth markets and shall keep that list up to date.
7.
Member States shall require that where a financial instrument of an issuer is admitted to trading on one SME
growth market, the financial instrument may also be traded on another SME growth market only where the issuer has
been informed and has not objected. In such a case however, the issuer shall not be subject to any obligation relating to
corporate governance or initial, ongoing or ad hoc disclosure with regard to the latter SME growth market.
8.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 further specifying the
requirements laid down in paragraph 3 of this Article. The measures shall take into account the need for the requirements
to maintain high levels of investor protection to promote investor confidence in those markets while minimising the
administrative burdens for issuers on the market and that de-registrations do not occur nor shall registrations be refused
as a result of a merely temporary failure to meet the conditions set out in point (a) of paragraph 3 of this Article.
EN
12.6.2014
Official Journal of the European Union
L 173/419

<!-- source-page: 72 -->

CHAPTER III
Rights of investment firms
Article 34
Freedom to provide investment services and activities
1.
Member States shall ensure that any investment firm authorised and supervised by the competent authorities of
another Member State in accordance with this Directive, and in respect of credit institutions in accordance with Directive
2013/36/EU, may freely provide investment services and/or perform investment activities as well as ancillary services
within their territories, provided that such services and activities are covered by its authorisation. Ancillary services may
only be provided together with an investment service and/or activity.
Member States shall not impose any additional requirements on such an investment firm or credit institution in respect of
the matters covered by this Directive.
2.
Any investment firm wishing to provide services or activities within the territory of another Member State for the
first time, or which wishes to change the range of services or activities so provided, shall communicate the following
information to the competent authorities of its home Member State:
(a) the Member State in which it intends to operate;
(b) a programme of operations stating in particular the investment services and/or activities as well as ancillary services
which it intends to provide in the territory of that Member State and whether it intends to do so through the use of
tied agents, established in its home Member State. Where an investment firm intends to use tied agents, the
investment firm shall communicate to the competent authority of its home Member State the identity of those
tied agents.
Where an investment firm intends to use tied agents established in its home Member State, in the territory of the Member
States in which it intends to provide services the competent authority of the home Member State of the investment firm
shall, within one month from receipt of all the information, communicate to the competent authority of the host
Member State designated as contact point in accordance with Article 79(1) the identity of the tied agents that the
investment firm intends to use to provide investment services and activities in that Member State. The host Member State
shall publish such information. ESMA may request access to that information in accordance with the procedure and
under the conditions set out in Article 35 of Regulation (EU) No 1095/2010.
3.
The competent authority of the home Member State shall, within one month of receiving the information, forward
it to the competent authority of the host Member State designated as contact point in accordance with Article 79(1). The
investment firm may then start to provide the investment services and activities concerned in the host Member State.
4.
In the event of a change in any of the particulars communicated in accordance with paragraph 2, an investment
firm shall give written notice of that change to the competent authority of the home Member State at least one month
before implementing the change. The competent authority of the home Member State shall inform the competent
authority of the host Member State of that change.
5.
Any credit institution wishing to provide investment services or activities as well as ancillary services in accordance
with paragraph 1 through tied agents shall communicate to the competent authority of its home Member State the
identity of those tied agents.
Where the credit institution intends to use tied agents established in its home Member State in the territory of the
Member States in which it intends to provide services, the competent authority of the home Member State of the credit
institution shall, within one month from the receipt of all the information, communicate to the competent authority of
the host Member State designated as contact point in accordance with Article 79(1) the identity of the tied agents that the
credit institution intends to use to provide services in that Member State. The host Member State shall publish such
information.
EN
L 173/420
Official Journal of the European Union
12.6.2014

<!-- source-page: 73 -->

6.
Member States shall, without further legal or administrative requirement, allow investment firms and market
operators operating MTFs and OTFs from other Member States to provide appropriate arrangements on their territory
so as to facilitate access to and trading on those markets by remote users, members or participants established in their
territory.
7.
The investment firm or the market operator operating an MTF or an OTF shall communicate to the competent
authority of its home Member State the Member State in which it intends to provide such arrangements. The competent
authority of the home Member State shall communicate, within one month, that information to the competent authority
of the Member State in which the MTF or the OTF intends to provide such arrangements.
The competent authority of the home Member State of the MTF shall, on the request of the competent authority of the
host Member State of the MTF and without undue delay, communicate the identity of the remote members or
participants of the MTF established in that Member State.
8.
ESMA shall develop draft regulatory technical standards to specify the information to be notified in accordance with
paragraphs 2, 4, 5 and 7.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
9.
ESMA shall develop draft implementing technical standards to establish standard forms, templates and procedures
for the transmission of information in accordance with paragraphs 3, 4, 5 and 7.
ESMA shall submit those draft implementing technical standards to the Commission by 31 December 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 35
Establishment of a branch
1.
Member States shall ensure that investment services and/or activities as well as ancillary services may be provided
within their territories in accordance with this Directive and with Directive 2013/36/EU through the right of estab­
lishment, whether by the establishment of a branch or by the use of a tied agent established in a Member State outside its
home Member State, provided that those services and activities are covered by the authorisation granted to the investment
firm or the credit institution in the home Member State. Ancillary services may only be provided together with an
investment service and/or activity.
Member States shall not impose any additional requirements save those allowed under paragraph 8, on the organisation
and operation of the branch in respect of the matters covered by this Directive.
2.
Member States shall require any investment firm wishing to establish a branch within the territory of another
Member State or to use tied agents established in another Member State in which it has not established a branch, first to
notify the competent authority of its home Member State and to provide it with the following information:
(a) the Member States within the territory of which it plans to establish a branch or the Member States in which it has
not established a branch but plans to use tied agents established there;
EN
12.6.2014
Official Journal of the European Union
L 173/421

<!-- source-page: 74 -->

(b) a programme of operations setting out, inter alia, the investment services and/or activities as well as the ancillary
services to be offered;
(c) where established, the organisational structure of the branch and indicating whether the branch intends to use tied
agents and the identity of those tied agents;
(d) where tied agents are to be used in a Member State in which an investment firm has not established a branch, a
description of the intended use of the tied agent(s) and an organisational structure, including reporting lines,
indicating how the agent(s) fit into the corporate structure of the investment firm;
(e) the address in the host Member State from which documents may be obtained;
(f) the names of those responsible for the management of the branch or of the tied agent.
Where an investment firm uses a tied agent established in a Member State outside its home Member State, such tied agent
shall be assimilated to the branch, where one is established, and shall in any event be subject to the provisions of this
Directive relating to branches.
3.
Unless the competent authority of the home Member State has reason to doubt the adequacy of the administrative
structure or the financial situation of an investment firm, taking into account the activities envisaged, it shall, within three
months of receiving all the information, communicate that information to the competent authority of the host Member
State designated as contact point in accordance with Article 79(1) and inform the investment firm concerned accordingly.
4.
In addition to the information referred to in paragraph 2, the competent authority of the home Member State shall
communicate details of the accredited compensation scheme of which the investment firm is a member in accordance
with Directive 97/9/EC to the competent authority of the host Member State. In the event of a change in the particulars,
the competent authority of the home Member State shall inform the competent authority of the host Member State
accordingly.
5.
Where the competent authority of the home Member State refuses to communicate the information to the
competent authority of the host Member State, it shall give reasons for its refusal to the investment firm concerned
within three months of receiving all the information.
6.
On receipt of a communication from the competent authority of the host Member State, or failing such communi­
cation from the latter at the latest after two months from the date of transmission of the communication by the
competent authority of the home Member State, the branch may be established and commence business.
7.
Any credit institution wishing to use a tied agent established in a Member State outside its home Member State to
provide investment services and/or activities as well as ancillary services in accordance with this Directive shall notify the
competent authority of its home Member State and provide it with the information referred to in paragraph 2.
Unless the competent authority of the home Member State has reason to doubt the adequacy of the administrative
structure or the financial situation of a credit institution, it shall, within three months of receiving all the information,
communicate that information to the competent authority of the host Member State designated as contact point in
accordance with Article 79(1) and inform the credit institution concerned accordingly.
Where the competent authority of the home Member State refuses to communicate the information to the competent
authority of the host Member State, it shall give reasons for its refusal to the credit institution concerned within three
months of receiving all the information.
EN
L 173/422
Official Journal of the European Union
12.6.2014

<!-- source-page: 75 -->

On receipt of a communication from the competent authority of the host Member State, or failing such communication
from the latter at the latest after two months from the date of transmission of the communication by the competent
authority of the home Member State, the tied agent can commence business. Such tied agent shall be subject to the
provisions of this Directive relating to branches.
8.
The competent authority of the Member State in which the branch is located shall assume responsibility for
ensuring that the services provided by the branch within its territory comply with the obligations laid down in
Articles 24, 25, 27, 28, of this Directive and Articles 14 to 26 of Regulation (EU) No 600/2014 and the measures
adopted pursuant thereto by the host Member State where allowed in accordance with Article 24(12).
The competent authority of the Member State in which the branch is located shall have the right to examine branch
arrangements and to request such changes as are strictly needed to enable the competent authority to enforce the
obligations under Articles 24, 25, 27, 28 of this Directive and Articles 14 to 26 of Regulation (EU) No 600/2014
and measures adopted pursuant thereto with respect to the services and/or activities provided by the branch within its
territory.
9.
Each Member State shall provide that, where an investment firm authorised in another Member State has established
a branch within its territory, the competent authority of the home Member State of the investment firm, in the exercise of
its responsibilities and after informing the competent authority of the host Member State, may carry out on-site
inspections in that branch.
10.
In the event of a change in any of the information communicated in accordance with paragraph 2, an investment
firm shall give written notice of that change to the competent authority of the home Member State at least one month
before implementing the change. The competent authority of the host Member State shall also be informed of that
change by the competent authority of the home Member State.
11.
ESMA shall develop draft regulatory technical standards to specify the information to be notified in accordance
with paragraphs 2, 4, 7 and 10.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
12.
ESMA shall develop draft implementing technical standards to establish standard forms, templates and procedures
for the transmission of information in accordance with paragraphs 3, 4, 7 and 10.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 36
Access to regulated markets
1.
Member States shall require that investment firms from other Member States which are authorised to execute client
orders or to deal on own account have the right of membership or have access to regulated markets established in their
territory by means of any of the following arrangements:
(a) directly, by setting up branches in the host Member States;
EN
12.6.2014
Official Journal of the European Union
L 173/423

<!-- source-page: 76 -->

(b) by becoming remote members of or having remote access to the regulated market without having to be established in
the home Member State of the regulated market, where the trading procedures and systems of the market in question
do not require a physical presence for conclusion of transactions on the market.
2.
Member States shall not impose any additional regulatory or administrative requirements, in respect of matters
covered by this Directive, on investment firms exercising the right conferred by paragraph 1.
Article 37
Access to CCP, clearing and settlement facilities and right to designate settlement system
1.
Without prejudice to Titles III, IV or V of Regulation (EU) No 648/2012, Member States shall require that
investment firms from other Member States have the right of direct and indirect access to CCP, clearing and settlement
systems in their territory for the purposes of finalising or arranging the finalisation of transactions in financial instru­
ments.
Member States shall require that direct and indirect access of those investment firms to such facilities be subject to the
same non-discriminatory, transparent and objective criteria as apply to local members or participants. Member States shall
not restrict the use of those facilities to the clearing and settlement of transactions in financial instruments undertaken on
a trading venue in their territory.
2.
Member States shall require that regulated markets in their territory offer all their members or participants the right
to designate the system for the settlement of transactions in financial instruments undertaken on that regulated market,
subject to the following conditions:
(a) such links and arrangements between the designated settlement system and any other system or facility as are
necessary to ensure the efficient and economic settlement of the transaction in question;
(b) agreement by the competent authority responsible for the supervision of the regulated market that technical
conditions for settlement of transactions concluded on the regulated market through a settlement system other
than that designated by the regulated market are such as to allow the smooth and orderly functioning of financial
markets.
That assessment of the competent authority of the regulated market shall be without prejudice to the competencies of the
national central banks as overseers of settlement systems or other supervisory authorities with competence in relation to
such systems. The competent authority shall take into account the oversight/supervision already exercised by those
institutions in order to avoid undue duplication of control.
Article 38
Provisions regarding CCPs, clearing and settlement arrangements in respect of MTFs
1.
Member States shall not prevent investment firms and market operators operating an MTF from entering into
appropriate arrangements with a CCP or clearing house and a settlement system of another Member State with a view to
providing for the clearing and/or settlement of some or all trades concluded by the members or participants under their
systems.
2.
The competent authority of investment firms and market operators operating an MTF may not oppose the use of
CCP, clearing houses and/or settlement systems in another Member State except where demonstrably necessary in order
to maintain the orderly functioning of that MTF and taking into account the conditions for settlement systems established
in Article 37(2).
In order to avoid undue duplication of control, the competent authority shall take into account the oversight and
supervision of the clearing and settlement system already exercised by the central banks as overseers of clearing and
settlement systems or by other supervisory authorities with competence in relation to such systems.
EN
L 173/424
Official Journal of the European Union
12.6.2014

<!-- source-page: 77 -->

CHAPTER IV
Provision of investment services and activities by third country firms
S e c t i o n 1
P r o v i s i o n o f s e r v i c e s o r p e r f o r m a n c e o f a c t i v i t i e s t h r o u g h t h e e s t a b l i s h m e n t o f
a b r a n c h
Article 39
Establishment of a branch
1.
A Member State may require that a third-country firm intending to provide investment services or perform
investment activities with or without any ancillary services to retail clients or to professional clients within the
meaning of Section II of Annex II in its territory establish a branch in that Member State.
2.
Where a Member State requires that a third-country firm intending to provide investment services or to perform
investment activities with or without any ancillary services in its territory establish a branch, the branch shall acquire a
prior authorisation by the competent authorities of that Member State in accordance with the following conditions:
(a) the provision of services for which the third-country firm requests authorisation is subject to authorisation and
supervision in the third country where the firm is established and the requesting firm is properly authorised, whereby
the competent authority pays due regard to any FATF recommendations in the context of anti-money laundering and
countering the financing of terrorism;
(b) cooperation arrangements, that include provisions regulating the exchange of information for the purpose of
preserving the integrity of the market and protecting investors, are in place between the competent authorities in
the Member State where the branch is to be established and competent supervisory authorities of the third country
where the firm is established;
(c) sufficient initial capital is at free disposal of the branch;
(d) one or more persons are appointed to be responsible for the management of the branch and they all comply with the
requirement laid down in Article 9(1);
(e) the third country where the third-country firm is established has signed an agreement with the Member State where
the branch is to be established, which fully comply with the standards laid down in Article 26 of the OECD Model
Tax Convention on Income and on Capital and ensures an effective exchange of information in tax matters, including,
if any, multilateral tax agreements;
(f) the firm belongs to an investor-compensation scheme authorised or recognised in accordance with Directive 97/9/EC.
3.
The third-country firm referred to in paragraph 1 shall submit its application to the competent authority of the
Member State where it intends to establish a branch.
Article 40
Obligation to provide information
A third-country firm intending to obtain authorisation for the provision of any investment services or the performance of
investment activities with or without any ancillary services in the territory of a Member State through a branch shall
provide the competent authority of that Member State with the following:
(a) the name of the authority responsible for its supervision in the third country concerned. When more than one
authority is responsible for supervision, the details of the respective areas of competence shall be provided;
EN
12.6.2014
Official Journal of the European Union
L 173/425

<!-- source-page: 78 -->

(b) all relevant details of the firm (name, legal form, registered office and address, members of the management body,
relevant shareholders) and a programme of operations setting out the investment services and/or activities as well as
the ancillary services to be provided and the organisational structure of the branch, including a description of any
outsourcing to third parties of essential operating functions;
(c) the name of the persons responsible for the management of the branch and the relevant documents to demonstrate
compliance with requirements laid down in Article 9(1);
(d) information about the initial capital at free disposal of the branch.
Article 41
Granting of the authorisation
1.
The competent authority of the Member State where the third-country firm has established or intends to establish
its branch shall only grant authorisation when the competent authority is satisfied that:
(a) the conditions under Article 39 are fulfilled; and
(b) the branch of the third-country firm will be able to comply with the provisions referred to in paragraph 2.
The competent authority shall inform the third-country firm, within six months of submission of a complete application,
whether or not the authorisation has been granted.
2.
The branch of the third-country firm authorised in accordance with paragraph 1, shall comply with the obligations
laid down in Articles 16 to 20, 23, 24, 25 and 27, Article 28(1), and Articles 30, 31 and 32 of this Directive and in
Articles 3 to 26 of Regulation (EU) No 600/2014 and the measures adopted pursuant thereto and shall be subject to the
supervision of the competent authority in the Member State where the authorisation was granted.
Member States shall not impose any additional requirements on the organisation and operation of the branch in respect
of the matters covered by this Directive and shall not treat any branch of third-country firms more favourably than Union
firms.
Article 42
Provision of services at the exclusive initiative of the client
Member States shall ensure that where a retail client or professional client within the meaning of Section II of Annex II
established or situated in the Union initiates at its own exclusive initiative the provision of an investment service or
activity by a third-country firm, the requirement for authorisation under Article 39 shall not apply to the provision of
that service or activity by the third country firm to that person including a relationship specifically relating to the
provision of that service or activity. An initiative by such clients shall not entitle the third-country firm to market
otherwise than through the branch, where one is required in accordance with national law, new categories of investment
products or investment services to that client.
S e c t i o n 2
W i t h d r a w a l o f a u t h o r i s a t i o n s
Article 43
Withdrawal of authorisations
The competent authority which granted an authorisation under Articles 41 may withdraw the authorisation issued to a
third country firm where such a firm:
EN
L 173/426
Official Journal of the European Union
12.6.2014

<!-- source-page: 79 -->

(a) does not make use of the authorisation within 12 months, expressly renounces the authorisation or has provided no
investment services or performed no investment activity for the preceding six months, unless the Member State
concerned has provided for the authorisation to lapse in such cases;
(b) has obtained the authorisation by making false statements or by any other irregular means;
(c) no longer meets the conditions under which authorisation was granted;
(d) has seriously and systematically infringed the provisions adopted pursuant to this Directive governing the operating
conditions for investment firms and applicable to third-country firms;
(e) falls within any of the cases where national law, in respect of matters outside the scope of this Directive, provides for
withdrawal.
TITLE III
REGULATED MARKETS
Article 44
Authorisation and applicable law
1.
Member States shall reserve authorisation as a regulated market to those systems which comply with this Title.
Authorisation as a regulated market shall be granted only where the competent authority is satisfied that both the market
operator and the systems of the regulated market comply at least with the requirements laid down in this Title.
In the case of a regulated market that is a legal person and that is managed or operated by a market operator other than
the regulated market itself, Member States shall establish how the different obligations imposed on the market operator
under this Directive are to be allocated between the regulated market and the market operator.
The market operator shall provide all information, including a programme of operations setting out, inter alia, the types
of business envisaged and the organisational structure, necessary to enable the competent authority to satisfy itself that
the regulated market has established, at the time of initial authorisation, all the necessary arrangements to meet its
obligations under this Title.
2.
Member States shall require the market operator to perform tasks relating to the organisation and operation of the
regulated market under the supervision of the competent authority. Member States shall ensure that competent authorities
keep under regular review the compliance of regulated markets with this Title. They shall also ensure that competent
authorities monitor that regulated markets comply at all times with the conditions for initial authorisation established
under this Title.
3.
Member States shall ensure that the market operator is responsible for ensuring that the regulated market that it
manages complies with the requirements laid down in this Title.
Member States shall also ensure that the market operator is entitled to exercise the rights that correspond to the regulated
market that it manages by virtue of this Directive.
4.
Without prejudice to any relevant provisions of Regulation (EU) No 596/2014 or of Directive 2014/57/EU, the
public law governing the trading conducted under the systems of the regulated market shall be that of the home Member
State of the regulated market.
EN
12.6.2014
Official Journal of the European Union
L 173/427

<!-- source-page: 80 -->

5.
The competent authority may withdraw the authorisation issued to a regulated market, where it:
(a) does not make use of the authorisation within 12 months, expressly renounces the authorisation or has not operated
for the preceding six months, unless the Member State concerned has provided for authorisation to lapse in such
cases;
(b) has obtained the authorisation by making false statements or by any other irregular means;
(c) no longer meets the conditions under which authorisation was granted;
(d) has seriously and systematically infringed the provisions adopted pursuant to this Directive or Regulation (EU)
No 600/2014;
(e) falls within any of the cases where national law provides for withdrawal.
6.
ESMA shall be notified of any withdrawal of authorisation.
Article 45
Requirements for the management body of a market operator
1.
Member States shall require that all members of the management body of any market operator shall at all times be
of sufficiently good repute, possess sufficient knowledge, skills and experience to perform their duties. The overall
composition of the management body shall reflect an adequately broad range of experience.
2.
Members of the management body shall, in particular, fulfil the following requirements:
(a) All members of the management body shall commit sufficient time to perform their functions in the market operator.
The number of directorships a member of the management body can hold, in any legal entity, at the same time shall
take into account individual circumstances and the nature, scale and complexity of the market operator’s activities.
Unless representing the Member State, members of the management body of market operators that are significant in
terms of their size, internal organisation and the nature, the scope and the complexity of their activities shall not at
the same time hold positions exceeding more than one of the following combinations:
(i) one executive directorship with two non-executive directorships;
(ii) four non-executive directorships.
Executive or non-executive directorships held within the same group or undertakings where the market operator
owns a qualifying holding shall be considered to be one single directorship.
Competent authorities may authorise members of the management body to hold one additional non-executive
directorship. Competent authorities shall regularly inform ESMA of such authorisations.
Directorships in organisations which do not pursue predominantly commercial objectives shall be exempt from the
limitation on the number of directorships a member of a management body can hold.
EN
L 173/428
Official Journal of the European Union
12.6.2014

<!-- source-page: 81 -->

(b) The management body shall possess adequate collective knowledge, skills and experience to be able to understand the
market operator’s activities, including the main risks.
(c) Each member of the management body shall act with honesty, integrity and independence of mind to effectively
assess and challenge the decisions of the senior management where necessary and to effectively oversee and monitor
decision-making.
3.
Market operators shall devote adequate human and financial resources to the induction and training of members of
the management body.
4.
Member States shall ensure that market operators which are significant in terms of their size, internal organisation
and the nature, scope and complexity of their activities establish a nomination committee composed of members of the
management body who do not perform any executive function in the market operator concerned.
The nomination committee shall carry out the following:
(a) identify and recommend, for the approval of the management body or for approval of the general meeting, candidates
to fill management body vacancies. In doing so, the nomination committee shall evaluate the balance of knowledge,
skills, diversity and experience of the management body. Further, the committee shall prepare a description of the
roles and capabilities for a particular appointment, and assess the time commitment expected. Furthermore, the
nomination committee shall decide on a target for the representation of the underrepresented gender in the
management body and prepare a policy on how to increase the number of the underrepresented gender in the
management body in order to meet that target;
(b) periodically, and at least annually, assess the structure, size, composition and performance of the management body,
and make recommendations to the management body with regard to any changes;
(c) periodically, and at least annually, assess the knowledge, skills and experience of individual members of the
management body and of the management body collectively, and report to the management body accordingly;
(d) periodically review the policy of the management body for selection and appointment of senior management and
make recommendations to the management body.
In performing its duties, the nomination committee shall, to the extent possible and on an ongoing basis, take account of
the need to ensure that the management body’s decision making is not dominated by any one individual or small group
of individuals in a manner that is detrimental to the interests of the market operator as a whole.
In performing its duties, the nomination committee shall be able to use any forms of resources it deems appropriate,
including external advice.
Where, under national law, the management body does not have any competence in the process of selection and
appointment of any of its members, this paragraph shall not apply.
5.
Member States or competent authorities shall require market operators and their respective nomination committees
to engage a broad set of qualities and competences when recruiting members to the management body and for that
purpose to put in place a policy promoting diversity on the management body.
EN
12.6.2014
Official Journal of the European Union
L 173/429

<!-- source-page: 82 -->

6.
Member States shall ensure that the management body of a market operator defines and oversees the implemen­
tation of the governance arrangements that ensure effective and prudent management of an organisation, including the
segregation of duties in the organisation and the prevention of conflicts of interest, and in a manner that promotes the
integrity of the market.
Member States shall ensure that the management body monitors and periodically assesses the effectiveness of the market
operator’s governance arrangements and takes appropriate steps to address any deficiencies.
Members of the management body shall have adequate access to information and documents which are needed to oversee
and monitor management decision-making.
7.
The competent authority shall refuse authorisation if it is not satisfied that the members of the management body
of the market operator are of sufficiently good repute, possess sufficient knowledge, skills and experience and commit
sufficient time to perform their functions, or if there are objective and demonstrable grounds for believing that the
management body of the market operator may pose a threat to its effective, sound and prudent management and to the
adequate consideration of the integrity of the market.
Member States shall ensure that, in the process of authorisation of a regulated market, the person or persons who
effectively direct the business and the operations of an already authorised regulated market in accordance with this
Directive are deemed to comply with the requirements laid down in paragraph 1.
8.
Member States shall require the market operator to notify the competent authority of the identity of all members of
its management body and of any changes to its membership, along with all information needed to assess whether the
market operator complies with paragraphs 1 to 5.
9.
ESMA shall issue guidelines on the following:
(a) the notion of sufficient time commitment of a member of the management body to perform that member’s functions,
in relation to the individual circumstances and the nature, scale and complexity of activities of the market operator;
(b) the notion of adequate collective knowledge, skills and experience of the management body as referred to in point (b)
of paragraph 2;
(c) the notions of honesty, integrity and independence of mind of a member of the management body as referred to in
point (c) of paragraph 2;
(d) the notion of adequate human and financial resources devoted to the induction and training of members of the
management body as referred to in paragraph 3;
(e) the notion of diversity to be taken into account for the selection of members of the management body as referred to
in paragraph 5.
ESMA shall issue those guidelines by 3 January 2016.
Article 46
Requirements relating to persons exercising significant influence over the management of the regulated market
1.
Member States shall require the persons who are in a position to exercise, directly or indirectly, significant influence
over the management of the regulated market to be suitable.
EN
L 173/430
Official Journal of the European Union
12.6.2014

<!-- source-page: 83 -->

2.
Member States shall require the market operator of the regulated market:
(a) to provide the competent authority with, and to make public, information regarding the ownership of the regulated
market and/or the market operator, and in particular, the identity and scale of interests of any parties in a position to
exercise significant influence over the management;
(b) to inform the competent authority of and to make public any transfer of ownership which gives rise to a change in
the identity of the persons exercising significant influence over the operation of the regulated market.
3.
The competent authority shall refuse to approve proposed changes to the controlling interests of the regulated
market and/or the market operator where there are objective and demonstrable grounds for believing that they would
pose a threat to the sound and prudent management of the regulated market.
Article 47
Organisational requirements
1.
Member States shall require the regulated market:
(a) to have arrangements to identify clearly and manage the potential adverse consequences, for the operation of the
regulated market or for its members or participants, of any conflict of interest between the interest of the regulated
market, its owners or its market operator and the sound functioning of the regulated market, and in particular where
such conflicts of interest might prove prejudicial to the accomplishment of any functions delegated to the regulated
market by the competent authority;
(b) to be adequately equipped to manage the risks to which it is exposed, to implement appropriate arrangements and
systems to identify all significant risks to its operation, and to put in place effective measures to mitigate those risks;
(c) to have arrangements for the sound management of the technical operations of the system, including the estab­
lishment of effective contingency arrangements to cope with risks of systems disruptions;
(d) to have transparent and non-discretionary rules and procedures that provide for fair and orderly trading and establish
objective criteria for the efficient execution of orders;
(e) to have effective arrangements to facilitate the efficient and timely finalisation of the transactions executed under its
systems;
(f) to have available, at the time of authorisation and on an ongoing basis, sufficient financial resources to facilitate its
orderly functioning, having regard to the nature and extent of the transactions concluded on the market and the
range and degree of the risks to which it is exposed.
2.
Member States shall not allow market operators to execute client orders against proprietary capital, or to engage in
matched principal trading on any of the regulated markets they operate.
Article 48
Systems resilience, circuit breakers and electronic trading
1.
Member States shall require a regulated market to have in place effective systems, procedures and arrangements to
ensure its trading systems are resilient, have sufficient capacity to deal with peak order and message volumes, are able to
ensure orderly trading under conditions of severe market stress, are fully tested to ensure such conditions are met and are
subject to effective business continuity arrangements to ensure continuity of its services if there is any failure of its
trading systems.
EN
12.6.2014
Official Journal of the European Union
L 173/431

<!-- source-page: 84 -->

2.
Member States shall require a regulated market to have in place:
(a) written agreements with all investment firms pursuing a market making strategy on the regulated market;
(b) schemes to ensure that a sufficient number of investment firms participate in such agreements which require them to
post firm quotes at competitive prices with the result of providing liquidity to the market on a regular and predictable
basis, where such a requirement is appropriate to the nature and scale of the trading on that regulated market.
3.
The written agreement referred to in paragraph 2 shall at least specify:
(a) the obligations of the investment firm in relation to the provision of liquidity and where applicable any other
obligation arising from participation in the scheme referred to in paragraph 2(b);
(b) any incentives in terms of rebates or otherwise offered by the regulated market to an investment firm so as to provide
liquidity to the market on a regular and predictable basis and, where applicable, any other rights accruing to the
investment firm as a result of participation in the scheme referred to in paragraph 2(b).
The regulated market shall monitor and enforce compliance by investment firms with the requirements of such binding
written agreements. The regulated market shall inform the competent authority about the content of the binding written
agreement and shall, upon request, provide all further information to the competent authority necessary to enable the
competent authority to satisfy itself of compliance by the regulated market with this paragraph.
4.
Member States shall require a regulated market to have in place effective systems, procedures and arrangements to
reject orders that exceed pre-determined volume and price thresholds or are clearly erroneous.
5.
Member States shall require a regulated market to be able to temporarily halt or constrain trading if there is a
significant price movement in a financial instrument on that market or a related market during a short period and, in
exceptional cases, to be able to cancel, vary or correct any transaction. Member States shall require a regulated market to
ensure that the parameters for halting trading are appropriately calibrated in a way which takes into account the liquidity
of different asset classes and sub-classes, the nature of the market model and types of users and is sufficient to avoid
significant disruptions to the orderliness of trading.
Member States shall ensure that a regulated market reports the parameters for halting trading and any material changes to
those parameters to the competent authority in a consistent and comparable manner, and that the competent authority
shall in turn report them to ESMA. Member States shall require that where a regulated market which is material in terms
of liquidity in that financial instrument halts trading, in any Member State, that trading venue has the necessary systems
and procedures in place to ensure that it will notify competent authorities in order for them to coordinate a market-wide
response and determine whether it is appropriate to halt trading on other venues on which the financial instrument is
traded until trading resumes on the original market.
6.
Member States shall require a regulated market to have in place effective systems, procedures and arrangements,
including requiring members or participants to carry out appropriate testing of algorithms and providing environments to
facilitate such testing, to ensure that algorithmic trading systems cannot create or contribute to disorderly trading
conditions on the market and to manage any disorderly trading conditions which do arise from such algorithmic
trading systems, including systems to limit the ratio of unexecuted orders to transactions that may be entered into
the system by a member or participant, to be able to slow down the flow of orders if there is a risk of its system capacity
being reached and to limit and enforce the minimum tick size that may be executed on the market.
7.
Member States shall require a regulated market that permits direct electronic access to have in place effective
systems procedures and arrangements to ensure that members or participants are only permitted to provide such services
if they are investment firms authorised under this Directive or credit institutions authorised under Directive 2013/36/EU,
EN
L 173/432
Official Journal of the European Union
12.6.2014

<!-- source-page: 85 -->

that appropriate criteria are set and applied regarding the suitability of persons to whom such access may be provided
and that the member or participant retains responsibility for orders and trades executed using that service in relation to
the requirements of this Directive.
Member States shall also require that the regulated market set appropriate standards regarding risk controls and
thresholds on trading through such access and is able to distinguish and if necessary to stop orders or trading by a
person using direct electronic access separately from other orders or trading by the member or participant.
The regulated market shall have arrangements in place to suspend or terminate the provision of direct electronic access
by a member or participant to a client in the case of non-compliance with this paragraph.
8.
Member States shall require a regulated market to ensure that its rules on co-location services are transparent, fair
and non-discriminatory.
9.
Member States shall require that a regulated market ensure that its fee structures including execution fees, ancillary
fees and any rebates are transparent, fair and non-discriminatory and that they do not create incentives to place, modify
or cancel orders or to execute transactions in a way which contributes to disorderly trading conditions or market abuse.
In particular, Member States shall require a regulated market to impose market making obligations in individual shares or
a suitable basket of shares in exchange for any rebates that are granted.
Member States shall allow a regulated market to adjust its fees for cancelled orders according to the length of time for
which the order was maintained and to calibrate the fees to each financial instrument to which they apply.
Member States may allow a regulated market to impose a higher fee for placing an order that is subsequently cancelled
than an order which is executed and to impose a higher fee on participants placing a high ratio of cancelled orders to
executed orders and on those operating a high-frequency algorithmic trading technique in order to reflect the additional
burden on system capacity.
10.
Member States shall require a regulated market to be able to identify, by means of flagging from members or
participants, orders generated by algorithmic trading, the different algorithms used for the creation of orders and the
relevant persons initiating those orders. That information shall be available to competent authorities upon request.
11.
Member States shall require that upon request by the competent authority of the home Member State of a
regulated market, regulated markets make available to the competent authority data relating to the order book or give
the competent authority access to the order book so that it is able to monitor trading.
12.
ESMA shall develop draft regulatory technical standards further specifying:
(a) the requirements to ensure trading systems of regulated markets are resilient and have adequate capacity;
(b) the ratio referred to in paragraph 6, taking into account factors such as the value of unexecuted orders in relation to
the value of executed transactions;
(c) the controls concerning direct electronic access in such a way as to ensure that the controls applied to sponsored
access are at least equivalent to those applied to direct market access;
(d) the requirements to ensure that co-location services and fee structures are fair and non-discriminatory and that fee
structures do not create incentives for disorderly trading conditions or market abuse;
EN
12.6.2014
Official Journal of the European Union
L 173/433

<!-- source-page: 86 -->

(e) the determination of where a regulated market is material in terms of liquidity in that financial instrument;
(f) the requirements to ensure that market making schemes are fair and non-discriminatory and to establish minimum
market making obligations that regulated markets must provide for when designing a market making scheme and the
conditions under which the requirement to have in place a market making scheme is not appropriate, taking into
account the nature and scale of the trading on that regulated market, including whether the regulated market allows
for or enables algorithmic trading to take place through its systems;
(g) the requirements to ensure appropriate testing of algorithms so as to ensure that algorithmic trading systems
including high-frequency algorithmic trading systems cannot create or contribute to disorderly trading conditions
on the market.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
13.
ESMA shall, by 3 January 2016, develop guidelines on the appropriate calibration of trading halts under paragraph
5, taking into account the factors referred to in that paragraph.
Article 49
Tick sizes
1.
Member States shall require regulated markets to adopt tick size regimes in shares, depositary receipts, exchange-
traded funds, certificates and other similar financial instruments and in any other financial instrument for which
regulatory technical standards are developed in accordance with paragraph 4.
2.
The tick size regimes referred to in paragraph 1 shall:
(a) be calibrated to reflect the liquidity profile of the financial instrument in different markets and the average bid-ask
spread, taking into account the desirability of enabling reasonably stable prices without unduly constraining further
narrowing of spreads;
(b) adapt the tick size for each financial instrument appropriately.
3.
ESMA shall develop draft regulatory technical standards to specify minimum tick sizes or tick size regimes for
specific shares, depositary receipts, exchange-traded funds, certificates, and other similar financial instruments where
necessary to ensure the orderly functioning of markets, in accordance with the factors in paragraph 2 and the price,
spreads and depth of liquidity of the financial instruments.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
EN
L 173/434
Official Journal of the European Union
12.6.2014

<!-- source-page: 87 -->

4.
ESMA may develop draft regulatory technical standards to specify minimum tick sizes or tick size regimes for
specific financial instruments other than those listed in paragraph 3 where necessary to ensure the orderly functioning of
markets, in accordance with the factors in paragraph 2 and the price, spreads and depth of liquidity of the financial
instruments.
ESMA shall submit any such draft regulatory technical standards to the Commission by 3 January 2016.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
Article 50
Synchronisation of business clocks
1.
Member States shall require that all trading venues and their members or participants synchronise the business
clocks they use to record the date and time of any reportable event.
2.
ESMA shall develop draft regulatory technical standards to specify the level of accuracy to which clocks are to be
synchronised in accordance with international standards.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
Article 51
Admission of financial instruments to trading
1.
Member States shall require that regulated markets have clear and transparent rules regarding the admission of
financial instruments to trading.
Those rules shall ensure that any financial instruments admitted to trading on a regulated market are capable of being
traded in a fair, orderly and efficient manner and, in the case of transferable securities, are freely negotiable.
2.
In the case of derivatives, the rules referred to in paragraph 1 shall ensure in particular that the design of the
derivative contract allows for its orderly pricing as well as for the existence of effective settlement conditions.
3.
In addition to the obligations set out in paragraphs 1 and 2, Member States shall require the regulated market to
establish and maintain effective arrangements to verify that issuers of transferable securities that are admitted to trading
on the regulated market comply with their obligations under Union law in respect of initial, ongoing or ad hoc disclosure
obligations.
Member States shall ensure that the regulated market establishes arrangements which facilitate its members or participants
in obtaining access to information which has been made public under Union law.
4.
Member States shall ensure that regulated markets have established the necessary arrangements to review regularly
the compliance with the admission requirements of the financial instruments which they admit to trading.
EN
12.6.2014
Official Journal of the European Union
L 173/435

<!-- source-page: 88 -->

5.
A transferable security that has been admitted to trading on a regulated market can subsequently be admitted to
trading on other regulated markets, even without the consent of the issuer and in compliance with the relevant provisions
of Directive 2003/71/EC. The issuer shall be informed by the regulated market of the fact that its securities are traded on
that regulated market. The issuer shall not be subject to any obligation to provide information required under paragraph
3 directly to any regulated market which has admitted the issuer’s securities to trading without its consent.
6.
ESMA shall develop draft regulatory technical standards which:
(a) specify the characteristics of different classes of financial instruments to be taken into account by the regulated market
when assessing whether a financial instrument is issued in a manner consistent with the conditions laid down in the
second subparagraph of paragraph 1 for admission to trading on the different market segments which it operates;
(b) clarify the arrangements that the regulated market is required to implement so as to be considered to have fulfilled its
obligation to verify that the issuer of a transferable security complies with its obligations under Union law in respect
of initial, ongoing or ad hoc disclosure obligations;
(c) clarify the arrangements that the regulated market has to establish pursuant to paragraph 3 in order to facilitate its
members or participants in obtaining access to information which has been made public under the conditions
established by Union law.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
Article 52
Suspension and removal of financial instruments from trading on a regulated market
1.
Without prejudice to the right of the competent authority under Article 69(2) to demand suspension or removal of
a financial instrument from trading, a market operator may suspend or remove from trading a financial instrument which
no longer complies with the rules of the regulated market unless such suspension or removal would be likely to cause
significant damage to the investors’ interests or the orderly functioning of the market.
2.
Member States shall require that a market operator that suspends or removes from trading a financial instrument
also suspends or removes the derivatives as referred to in points (4) to (10) of Section C of Annex I that relate or are
referenced to that financial instrument where necessary to support the objectives of the suspension or removal of the
underlying financial instrument. The market operator shall make public its decision on the suspension or removal of the
financial instrument and of any related derivative and communicate the relevant decisions to its competent authority.
The competent authority, in whose jurisdiction the suspension or removal originated, shall require that other regulated
markets, MTFs, OTFs and systematic internalisers, which fall under its jurisdiction and trade the same financial instrument
or derivatives as referred to in points (4) to (10) of Section C of Annex I to this Directive that relate or are referenced to
that financial instrument, also suspend or remove that financial instrument or derivatives from trading, where the
suspension or removal is due to suspected market abuse, a take-over bid or the non-disclosure of inside information
about the issuer or financial instrument infringing Articles 7 and 17 of Regulation (EU) No. 596/2014 except where such
suspension or removal could cause significant damage to the investors’ interests or the orderly functioning of the market.
Each notified competent authority shall communicate its decision to ESMA and other competent authorities, including an
explanation if the decision was not to suspend or remove from trading the financial instrument or derivatives as referred
to in points (4) to (10) of Section C of Annex I that relate or are referenced to that financial instrument.
EN
L 173/436
Official Journal of the European Union
12.6.2014

<!-- source-page: 89 -->

The competent authority shall immediately make public and communicate to ESMA and the competent authorities of the
other Member States such a decision.
The notified competent authorities of the other Member States shall require that regulated markets, other MTFs, other
OTFs and systematic internalisers, which fall under their jurisdiction and trade the same financial instrument or
derivatives referred to in points (4) to (10) of Section C of Annex I to this Directive that relate or are referenced to
that financial instrument, also suspend or remove that financial instrument or derivatives from trading, where the
suspension or removal is due to suspected market abuse, a take-over bid or the non-disclosure of inside information
about the issuer or financial instrument infringing Articles 7 and 17 of Regulation (EU) No 596/2014 except where such
suspension or removal could cause significant damage to the investors’ interests or the orderly functioning of the market.
This paragraph applies also when the suspension from trading of a financial instrument or derivatives as referred to in
points (4) to (10) of Section C of Annex I that relate or are referenced to that financial instrument is lifted.
The notification procedure referred to in this paragraph shall also apply in the case where the decision to suspend or
remove from trading a financial instrument or derivatives as referred to in points (4) to (10) of Section C of Annex I that
relate or are referenced to that financial instrument is taken by the competent authority pursuant to points (m) and (n) of
Article 69(2).
In order to ensure that the obligation to suspend or remove from trading such derivatives is applied proportionately,
ESMA shall develop draft regulatory technical standards to further specify the cases in which the connection between a
derivative relating or referenced to a financial instrument suspended or removed from trading and the original financial
instrument implies that the derivative are also to be suspended or removed from trading, in order to achieve the objective
of the suspension or removal of the underlying financial instrument.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
3.
ESMA shall develop draft implementing technical standards to determine the format and timing of the communi­
cations and publications referred to in paragraph 2.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
4.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to specify the list of
circumstances constituting significant damage to the investors’ interests and the orderly functioning of the market referred
to in paragraphs 1 and 2.
Article 53
Access to a regulated market
1.
Member States shall require a regulated market to establish, implement and maintain transparent and non-discrimi­
natory rules, based on objective criteria, governing access to or membership of the regulated market.
EN
12.6.2014
Official Journal of the European Union
L 173/437

<!-- source-page: 90 -->

2.
The rules referred to in paragraph 1 shall specify any obligations for the members or participants arising from:
(a) the constitution and administration of the regulated market;
(b) rules relating to transactions on the market;
(c) professional standards imposed on the staff of the investment firms or credit institutions that are operating on the
market;
(d) the conditions established, for members or participants other than investment firms and credit institutions, under
paragraph 3;
(e) the rules and procedures for the clearing and settlement of transactions concluded on the regulated market.
3.
Regulated markets may admit as members or participants investment firms, credit institutions authorised under
Directive 2013/36/EU and other persons who:
(a) are of sufficient good repute;
(b) have a sufficient level of trading ability, competence and experience;
(c) have, where applicable, adequate organisational arrangements;
(d) have sufficient resources for the role they are to perform, taking into account the different financial arrangements that
the regulated market may have established in order to guarantee the adequate settlement of transactions.
4.
Member States shall ensure that, for the transactions concluded on a regulated market, members and participants
are not obliged to apply to each other the obligations laid down in Articles 24, 25, 27 and 28. However, the members or
participants of the regulated market shall apply the obligations provided for in Articles 24, 25, 27 and 28 with respect to
their clients when they, acting on behalf of their clients, execute their orders on a regulated market.
5.
Member States shall ensure that the rules on access to or membership of or participation in the regulated market
provide for the direct or remote participation of investment firms and credit institutions.
6.
Member States shall, without further legal or administrative requirements, allow regulated markets from other
Member States to provide appropriate arrangements on their territory so as to facilitate access to and trading on
those markets by remote members or participants established in their territory.
The regulated market shall communicate to the competent authority of its home Member State the Member State in
which it intends to provide such arrangements. The competent authority of the home Member State shall communicate
that information to the Member State in which the regulated market intends to provide such arrangements within 1
month. ESMA may request access to that information in accordance with the procedure and under the conditions set out
in Article 35 of Regulation (EU) No 1095/2010.
EN
L 173/438
Official Journal of the European Union
12.6.2014

<!-- source-page: 91 -->

The competent authority of the home Member State of the regulated market shall, on the request of the competent
authority of the host Member State and, without undue delay, communicate the identity of the members or participants
of the regulated market established in that Member State.
7.
Member States shall require the market operator to communicate, on a regular basis, the list of the members or
participants of the regulated market to the competent authority of the regulated market.
Article 54
Monitoring of compliance with the rules of the regulated market and with other legal obligations
1.
Member States shall require that regulated markets establish and maintain effective arrangements and procedures
including the necessary resource for the regular monitoring of the compliance by their members or participants with their
rules. Regulated markets shall monitor orders sent including cancellations and the transactions undertaken by their
members or participants under their systems in order to identify infringements of those rules, disorderly trading
conditions or conduct that may indicate behaviour that is prohibited under Regulation (EU) No 596/2014 or system
disruptions in relation to a financial instrument.
2.
Member States shall require the market operators of the regulated markets to immediately inform their competent
authorities of significant infringements of their rules or disorderly trading conditions or conduct that may indicate
behaviour that is prohibited under Regulation (EU) No 596/2014 or system disruptions in relation to a financial
instrument.
The competent authorities of the regulated markets shall communicate to ESMA and to the competent authorities of the
other Member States the information referred to in the first subparagraph.
In relation to conduct that may indicate behaviour that is prohibited under Regulation (EU) No 596/2014, a competent
authority shall be convinced that such behaviour is being or has been carried out before it notifies the competent
authorities of the other Member States and ESMA.
3.
Member States shall require the market operator to supply the relevant information without undue delay to the
authority competent for the investigation and prosecution of market abuse on the regulated market and to provide full
assistance to the latter in investigating and prosecuting market abuse occurring on or through the systems of the
regulated market.
4.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to determine circum­
stances that trigger an information requirement as referred to in paragraph 2 of this Article.
Article 55
Provisions regarding CCP and clearing and settlement arrangements
1.
Without prejudice to Titles III, IV or V of Regulation (EU) No 648/2012, Member States shall not prevent regulated
markets from entering into appropriate arrangements with a CCP or clearing house and a settlement system of another
Member State with a view to providing for the clearing and/or settlement of some or all trades concluded by market
participants under their systems.
2.
Without prejudice to Titles III, IV or V of Regulation (EU) No 648/2012, the competent authority of a regulated
market may not oppose the use of CCP, clearing houses and/or settlement systems in another Member State except where
demonstrably necessary in order to maintain the orderly functioning of that regulated market and taking into account the
conditions for settlement systems established in Article 37(2) of this Directive.
In order to avoid undue duplication of control, the competent authority shall take into account the oversight/supervision
of the clearing and settlement system already exercised by the central banks as overseers of clearing and settlement
systems or by other supervisory authorities with competence in relation to such systems.
EN
12.6.2014
Official Journal of the European Union
L 173/439

<!-- source-page: 92 -->

Article 56
List of regulated markets
Each Member State shall draw up a list of the regulated markets for which it is the home Member State and shall forward
that list to the other Member States and ESMA. A similar communication shall be effected in respect of each change to
that list. ESMA shall publish and keep up-to-date a list of all regulated markets on its website. That list shall contain the
unique code established by ESMA in accordance with Article 65(6) identifying the regulated markets for use in reports in
accordance with point (g) of Article 65(1) and point (g) of Article 65(2) of this Directive and with Articles 6, 10 and 26
of Regulation (EU) No 600/2014.
TITLE IV
POSITION LIMITS AND POSITION MANAGEMENT CONTROLS IN COMMODITY DERIVATIVES AND REPORTING
Article 57
Position limits and position management controls in commodity derivatives
1.
Member States shall ensure that competent authorities, in line with the methodology for calculation determined by
ESMA, establish and apply position limits on the size of a net position which a person can hold at all times in
commodity derivatives traded on trading venues and economically equivalent OTC contracts. The limits shall be set
on the basis of all positions held by a person and those held on its behalf at an aggregate group level in order to:
(a) prevent market abuse;
(b) support orderly pricing and settlement conditions, including preventing market distorting positions, and ensuring, in
particular, convergence between prices of derivatives in the delivery month and spot prices for the underlying
commodity, without prejudice to price discovery on the market for the underlying commodity.
Position limits shall not apply to positions held by or on behalf of a non-financial entity and which are objectively
measurable as reducing risks directly relating to the commercial activity of that non-financial entity.
2.
Position limits shall specify clear quantitative thresholds for the maximum size of a position in a commodity
derivative that persons can hold.
3.
ESMA shall develop draft regulatory technical standards to determine the methodology for calculation that
competent authorities are to apply in establishing the spot month position limits and other months’ position limits
for physically settled and cash settled commodity derivatives based on the characteristics of the relevant derivative. The
methodology for calculation shall take into account at least the following factors:
(a) the maturity of the commodity derivative contracts;
(b) the deliverable supply in the underlying commodity;
(c) the overall open interest in that contract and the overall open interest in other financial instruments with the same
underlying commodity;
(d) the volatility of the relevant markets, including substitute derivatives and the underlying commodity markets;
(e) the number and size of the market participants;
EN
L 173/440
Official Journal of the European Union
12.6.2014

<!-- source-page: 93 -->

(f) the characteristics of the underlying commodity market, including patterns of production, consumption and trans­
portation to market;
(g) the development of new contracts.
ESMA shall take into account experience regarding the position limits of investment firms or market operators operating
a trading venue and of other jurisdictions.
ESMA shall submit those draft regulatory technical standards referred to in the first subparagraph to the Commission by
3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
4.
A competent authority shall set limits for each contract in commodity derivatives traded on trading venues based
on the methodology for calculation determined by ESMA in accordance with paragraph 3. That position limit shall
include economically equivalent OTC contracts.
A competent authority shall review position limits where there is a significant change in deliverable supply or open
interest or any other significant change on the market, based on its determination of deliverable supply and open interest
and reset the position limit in accordance with the methodology for calculation developed by ESMA.
5.
Competent authorities shall notify ESMA of the exact position limits they intend to set in accordance with the
methodology for calculation established by ESMA under paragraph 3. Within two months following receipt of the
notification, ESMA shall issue an opinion to the competent authority concerned assessing the compatibility of
position limits with the objectives of paragraph 1 and with the methodology for calculation established by ESMA
under paragraph 3. ESMA shall publish the opinion on its website. The competent authority concerned shall modify
the position limits in accordance with ESMA’s opinion, or provide ESMA with justification why the change is considered
to be unnecessary. Where a competent authority imposes limits contrary to an ESMA opinion, it shall immediately
publish on its website a notice fully explaining its reasons for doing so.
Where ESMA determines that a position limit is not in line with the methodology for calculation in paragraph 3, it shall
take action in accordance with its powers under Article 17 of Regulation (EU) No 1095/2010.
6.
Where the same commodity derivative is traded in significant volumes on trading venues in more than one
jurisdiction, the competent authority of the trading venue where the largest volume of trading takes place (the central
competent authority) shall set the single position limit to be applied on all trading in that contract. The central competent
authority shall consult the competent authorities of other trading venues on which that derivative is traded in significant
volumes on the single position limit to be applied and any revisions to that single position limit. Where competent
authorities do not agree, they shall state in writing the full and detailed reasons why they consider that the requirements
laid down in paragraph 1 are not met. ESMA shall settle any dispute arising from a disagreement between competent
authorities in accordance with its powers under Article 19 of Regulation (EU) No 1095/2010.
The competent authorities of the trading venues where the same commodity derivative is traded and the competent
authorities of position holders in that commodity derivative shall put in place cooperation arrangements including
exchange of relevant data with each other in order to enable the monitoring and enforcement of the single position limit.
EN
12.6.2014
Official Journal of the European Union
L 173/441

<!-- source-page: 94 -->

7.
ESMA shall monitor at least once a year the way competent authorities have implemented the position limits set in
accordance with the methodology for calculation established by ESMA under paragraph 3. In doing so, ESMA shall
ensure that a single position limit effectively applies to the same contract irrespective of where it is traded in line with
paragraph 6.
8.
Member States shall ensure that an investment firm or a market operator operating a trading venue which trades
commodity derivatives apply position management controls. Those controls shall include at least, the powers for the
trading venue to:
(a) monitor the open interest positions of persons;
(b) access information, including all relevant documentation, from persons about the size and purpose of a position or
exposure entered into, information about beneficial or underlying owners, any concert arrangements, and any related
assets or liabilities in the underlying market;
(c) require a person to terminate or reduce a position, on a temporary or permanent basis as the specific case may
require and to unilaterally take appropriate action to ensure the termination or reduction if the person does not
comply; and
(d) where appropriate, require a person to provide liquidity back into the market at an agreed price and volume on a
temporary basis with the express intent of mitigating the effects of a large or dominant position.
9.
The position limits and position management controls shall be transparent and non-discriminatory, specifying how
they apply to persons and taking account of the nature and composition of market participants and of the use they make
of the contracts submitted to trading.
10.
The investment firm or market operator operating the trading venue shall inform the competent authority of the
details of position management controls.
The competent authority shall communicate the same information as well as the details of the position limits it has
established to ESMA, which shall publish and maintain on its website a database with summaries of the position limits
and position management controls.
11.
The position limits of paragraph 1 shall be imposed by competent authorities pursuant to point (p) of
Article 69(2).
12.
ESMA shall develop draft regulatory technical standards to determine:
(a) the criteria and methods for determining whether a position qualifies as reducing risks directly relating to commercial
activities;
(b) the methods to determine when positions of a person are to be aggregated within a group;
(c) the criteria for determining whether a contract is an economically equivalent OTC contract to that traded on a trading
venue, referred to in paragraph 1, in a way that facilitates the reporting of positions taken in equivalent OTC
contracts to the relevant competent authority as determined in Article 58(2);
EN
L 173/442
Official Journal of the European Union
12.6.2014

<!-- source-page: 95 -->

(d) the definition of what constitutes the same commodity derivative and significant volumes under paragraph 6 of this
Article;
(e) the methodology for aggregating and netting OTC and on-venue commodity derivatives positions to establish the net
position for purposes of assessing compliance with the limits. Such methodologies shall establish criteria to determine
which positions may be netted against one another and shall not facilitate the build-up of positions in a manner
inconsistent with the objectives set out in paragraph 1 of this Article;
(f) the procedure setting out how persons may apply for the exemption under the second subparagraph of paragraph 1
of this Article and how the relevant competent authority will approve such applications;
(g) the method for calculation to determine the venue where the largest volume of trading in a commodity derivative
takes place and significant volumes under paragraph 6 of this Article.
ESMA shall submit those draft regulatory technical standards referred to in the first subparagraph to the Commission by
3 July 2015.
Power shall be delegated to the Commission to adopt the regulatory technical standards referred to in the first
subparagraph in accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
13.
Competent authorities shall not impose limits which are more restrictive than those adopted pursuant to
paragraph 1 except in exceptional cases where they are objectively justified and proportionate taking into account the
liquidity of the specific market and the orderly functioning of that market. Competent authorities shall publish on their
website the details of the more restrictive position limits they decide to impose, which shall be valid for an initial period
not exceeding six months from the date of their publication on the website. The more restrictive position limits may be
renewed for further periods not exceeding six months at a time if the grounds for the restriction continue to be
applicable. If not renewed after that six-month period, they shall automatically expire.
Where competent authorities decide to impose more restrictive position limits, they shall notify ESMA. The notification
shall include a justification for the more restrictive position limits. ESMA shall, within 24 hours, issue an opinion on
whether it considers that the more restrictive position limits are necessary to address the exceptional case. The opinion
shall be published on ESMA’s website.
Where a competent authority imposes limits contrary to an ESMA opinion, it shall immediately publish on its website a
notice fully explaining its reasons for doing so.
14.
Member States shall provide that competent authorities can apply their powers to impose sanctions under this
Directive for the infringements of position limits set in accordance with this Article to:
(a) positions held by persons situated or operating in its territory or abroad which exceed the limits on commodity
derivative contracts the competent authority has set in relation to contracts on trading venues situated or operating in
its territory or economically equivalent OTC contracts;
(b) positions held by persons situated or operating in its territory which exceed the limits on commodity derivative
contracts set by competent authorities in other Member States.
EN
12.6.2014
Official Journal of the European Union
L 173/443

<!-- source-page: 96 -->

Article 58
Position reporting by categories of position holders
1.
Member States shall ensure that an investment firm or a market operator operating a trading venue which trades
commodity derivatives or emission allowances or derivatives thereof:
(a) make public a weekly report with the aggregate positions held by the different categories of persons for the different
commodity derivatives or emission allowances or derivatives thereof traded on their trading venue, specifying the
number of long and short positions by such categories, changes thereto since the previous report, the percentage of
the total open interest represented by each category and the number of persons holding a position in each category in
accordance with paragraph 4 and communicate that report to the competent authority and to ESMA; ESMA shall
proceed to a centralised publication of the information included in those reports;
(b) provide the competent authority with a complete breakdown of the positions held by all persons, including the
members or participants and the clients thereof, on that trading venue, at least on a daily basis.
The obligation laid down in point (a) shall only apply when both the number of persons and their open positions exceed
minimum thresholds.
2.
Member States shall ensure that investment firms trading in commodity derivatives or emission allowances or
derivatives thereof outside a trading venue provide the competent authority of the trading venue where the commodity
derivatives or emission allowances or derivatives thereof are traded or the central competent authority where the
commodity derivatives or emission allowances or derivatives thereof are traded in significant volumes on trading
venues in more than one jurisdiction at least on a daily basis with a complete breakdown of their positions taken in
commodity derivatives or emission allowances or derivatives thereof traded on a trading venue and economically
equivalent OTC contracts, as well as of those of their clients and the clients of those clients until the end client is
reached, in accordance with Article 26 of Regulation (EU) No 600/2014 and, where applicable, of Article 8 of Regulation
(EU) No 1227/2011.
3.
In order to enable monitoring of compliance with Article 57(1), Member States shall require members or
participants of regulated markets, MTFs and clients of OTFs to report to the investment firm or market operator
operating that trading venue the details of their own positions held through contracts traded on that trading venue at
least on a daily basis, as well as those of their clients and the clients of those clients until the end client is reached.
4.
Persons holding positions in a commodity derivative or emission allowance or derivative thereof shall be classified
by the investment firm or market operator operating that trading venue according to the nature of their main business,
taking account of any applicable authorisation, as either:
(a) investment firms or credit institutions;
(b) investment funds, either an undertaking for collective investments in transferable securities (UCITS) as defined in
Directive 2009/65/EC, or an alternative investment fund manager as defined in Directive 2011/61/EC;
(c) other financial institutions, including insurance undertakings and reinsurance undertakings as defined in Directive
2009/138/EC, and institutions for occupational retirement provision as defined in Directive 2003/41/EC;
(d) commercial undertakings;
EN
L 173/444
Official Journal of the European Union
12.6.2014

<!-- source-page: 97 -->

(e) in the case of emission allowances or derivatives thereof, operators with compliance obligations under Directive
2003/87/EC.
The reports referred to in point (a) of paragraph 1 shall specify the number of long and short positions by category of
persons, any changes thereto since the previous report, percent of total open interest represented by each category, and
the number of persons in each category.
The reports referred to in point (a) of paragraph 1 and the breakdowns referred to in paragraph 2 shall differentiate
between:
(a) positions identified as positions which in an objectively measurable way reduce risks directly relating to commercial
activities; and
(b) other positions.
5.
ESMA shall develop draft implementing technical standards to determine the format of the reports referred to in
point (a) of paragraph 1 and of the breakdowns referred to in paragraph 2.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
In the case of emission allowances or derivatives thereof, the reporting shall not prejudice the compliance obligations
under Directive 2003/87/EC.
6.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to specify the
thresholds referred to in the second subparagraph of paragraph 1 of this Article, having regard to the total number
of open positions and their size and the total number of persons holding a position.
7.
ESMA shall develop draft implementing technical standards to specify the measures to require all reports referred to
in point (a) of paragraph 1 to be sent to ESMA at a specified weekly time, for their centralised publication by the latter.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
TITLE V
DATA REPORTING SERVICES
S e c t i o n 1
A u t h o r i s a t i o n p r o c e d u r e s f o r d a t a r e p o r t i n g s e r v i c e s p r o v i d e r s
Article 59
Requirement for authorisation
1.
Member States shall require that the provision of data reporting services described in Annex I, Section D as a
regular occupation or business be subject to prior authorisation in accordance with this Section. Such authorisation shall
be granted by the home Member State competent authority designated in accordance with Article 67.
EN
12.6.2014
Official Journal of the European Union
L 173/445

<!-- source-page: 98 -->

2.
By way of derogation from paragraph 1, Member States shall allow an investment firm or a market operator
operating a trading venue to operate the data reporting services of an APA, a CTP and an ARM, subject to the prior
verification of their compliance with this Title. Such a service shall be included in their authorisation.
3.
Member States shall register all data reporting services providers. The register shall be publicly accessible and shall
contain information on the services for which the data reporting services provider is authorised. It shall be updated on a
regular basis. Every authorisation shall be notified to ESMA.
ESMA shall establish a list of all data reporting services providers in the Union. The list shall contain information on the
services for which the data reporting services provider is authorised and it shall be updated on a regular basis. ESMA shall
publish and keep up-to-date that list on its website.
Where a competent authority has withdrawn an authorisation in accordance with Article 62, that withdrawal shall be
published on the list for a period of 5 years.
4.
Member States shall require data reporting services providers to provide their services under the supervision of the
competent authority. Member States shall ensure that competent authorities keep under regular review the compliance of
data reporting services providers with this Title. They shall also ensure that competent authorities monitor that data
reporting services providers comply at all times with the conditions for initial authorisation established under this Title.
Article 60
Scope of authorisation
1.
The home Member State shall ensure that the authorisation specifies the data reporting service which the data
reporting services provider is authorised to provide. A data reporting services provider seeking to extend its business to
additional data reporting services shall submit a request for extension of its authorisation.
2.
The authorisation shall be valid for the entire Union and shall allow a data reporting services provider to provide
the services, for which it has been authorised, throughout the Union.
Article 61
Procedures for granting and refusing requests for authorisation
1.
The competent authority shall not grant authorisation unless and until such time as it is fully satisfied that the
applicant complies with all requirements under the provisions adopted pursuant to this Directive.
2.
The data reporting services provider shall provide all information, including a programme of operations setting out,
inter alia, the types of services envisaged and the organisational structure, necessary to enable the competent authority to
satisfy itself that the data reporting services provider has established, at the time of initial authorisation, all the necessary
arrangements to meet its obligations under the provisions of this Title.
3.
An applicant shall be informed, within six months of the submission of a complete application, whether or not
authorisation has been granted.
4.
ESMA shall develop draft regulatory technical standards to determine:
(a) the information to be provided to the competent authorities under paragraph 2, including the programme of
operations;
EN
L 173/446
Official Journal of the European Union
12.6.2014

<!-- source-page: 99 -->

(b) the information included in the notifications under Article 63(3).
ESMA shall submit the draft regulatory technical standards referred to in the first subparagraph to the Commission by
3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
5.
ESMA shall develop draft implementing technical standards to determine standard forms, templates and procedures
for the notification or provision of information provided for in paragraph 2 of this Article and in Article 63(4).
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 62
Withdrawal of authorisations
The competent authority may withdraw the authorisation issued to a data reporting services provider where the provider:
(a) does not make use of the authorisation within 12 months, expressly renounces the authorisation or has provided no
data reporting services for the preceding six months, unless the Member State concerned has provided for auth­
orisation to lapse in such cases;
(b) has obtained the authorisation by making false statements or by any other irregular means;
(c) no longer meets the conditions under which authorisation was granted;
(d) has seriously and systematically infringed the provisions of this Directive or of Regulation (EU) No 600/2014.
Article 63
Requirements for the management body of a data reporting services provider
1.
Member States shall require that all members of the management body of a data reporting services provider shall at
all times be of sufficiently good repute, possess sufficient knowledge, skills and experience and commit sufficient time to
perform their duties.
The management body shall possess adequate collective knowledge, skills and experience to be able to understand the
activities of the data reporting services provider. Each member of the management body shall act with honesty, integrity
and independence of mind to effectively challenge the decisions of the senior management where necessary and to
effectively oversee and monitor management decision-making where necessary.
Where a market operator seeks authorisation to operate an APA, a CTP or an ARM and the members of the management
body of the APA, the CTP or the ARM are the same as the members of the management body of the regulated market,
those persons are deemed to comply with the requirement laid down in the first subparagraph.
EN
12.6.2014
Official Journal of the European Union
L 173/447

<!-- source-page: 100 -->

2.
ESMA shall, by 3 January 2016, develop guidelines for the assessment of the suitability of the members of the
management body described in paragraph 1, taking into account different roles and functions carried out by them and
the need to avoid conflicts of interest between members of the management body and users of the APA, CTP or ARM.
3.
Member States shall require the data reporting services provider to notify the competent authority of all members of
its management body and of any changes to its membership, along with all information needed to assess whether the
entity complies with paragraph 1.
4.
Member States shall ensure that the management body of a data reporting services provider defines and oversees the
implementation of the governance arrangements that ensure effective and prudent management of an organisation
including the segregation of duties in the organisation and the prevention of conflicts of interest, and in a manner
that promotes the integrity of the market and the interest of its clients.
5.
The competent authority shall refuse authorisation if it is not satisfied that the person or the persons who shall
effectively direct the business of the data reporting services provider are of sufficiently good repute, or if there are
objective and demonstrable grounds for believing that proposed changes to the management of the provider pose a threat
to its sound and prudent management and to the adequate consideration of the interest of its clients and the integrity of
the market.
S e c t i o n 2
C o n d i t i o n s f o r A P A s
Article 64
Organisational requirements
1.
The home Member State shall require an APA to have adequate policies and arrangements in place to make public
the information required under Articles 20 and 21 of Regulation (EU) No 600/2014 as close to real time as is technically
possible, on a reasonable commercial basis. The information shall be made available free of charge 15 minutes after the
APA has published it. The home Member State shall require the APA to be able to efficiently and consistently disseminate
such information in a way that ensures fast access to the information, on a non-discriminatory basis and in a format that
facilitates the consolidation of the information with similar data from other sources.
2.
The information made public by an APA in accordance with paragraph 1 shall include, at least, the following
details:
(a) the identifier of the financial instrument;
(b) the price at which the transaction was concluded;
(c) the volume of the transaction;
(d) the time of the transaction;
(e) the time the transaction was reported;
(f) the price notation of the transaction;
EN
L 173/448
Official Journal of the European Union
12.6.2014

<!-- source-page: 101 -->

(g) the code for the trading venue the transaction was executed on, or where the transaction was executed via a
systematic internaliser the code ‘SI’ or otherwise the code ‘OTC’;
(h) if applicable, an indicator that the transaction was subject to specific conditions.
3.
The home Member State shall require the APA to operate and maintain effective administrative arrangements
designed to prevent conflicts of interest with its clients. In particular, an APA who is also a market operator or
investment firm shall treat all information collected in a non-discriminatory fashion and shall operate and maintain
appropriate arrangements to separate different business functions.
4.
The home Member State shall require the APA to have sound security mechanisms in place designed to guarantee
the security of the means of transfer of information, minimise the risk of data corruption and unauthorised access and to
prevent information leakage before publication. The APA shall maintain adequate resources and have back-up facilities in
place in order to offer and maintain its services at all times.
5.
The home Member State shall require the APA to have systems in place that can effectively check trade reports for
completeness, identify omissions and obvious errors and request re-transmission of any such erroneous reports.
6.
ESMA shall develop draft regulatory technical standards to determine common formats, data standards and technical
arrangements facilitating the consolidation of information as referred to in paragraph 1.
ESMA shall submit the draft regulatory technical standards referred to in the first subparagraph to the Commission by
3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
7.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 clarifying what
constitutes a reasonable commercial basis to make information public as referred to in paragraph 1 of this Article.
8.
ESMA shall develop draft regulatory technical standards specifying:
(a) the means by which an APA may comply with the information obligation referred to in paragraph 1;
(b) the content of the information published under paragraph 1, including at least the information referred to in
paragraph 2 in such a way as to enable the publication of information required under Article 64;
(c) the concrete organisational requirements laid down in paragraphs 3, 4 and 5.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
EN
12.6.2014
Official Journal of the European Union
L 173/449

<!-- source-page: 102 -->

S e c t i o n 3
C o n d i t i o n s f o r C T P s
Article 65
Organisational requirements
1.
The home Member State shall require a CTP to have adequate policies and arrangements in place to collect the
information made public in accordance with Articles 6 and 20 of Regulation (EU) No 600/2014, consolidate it into a
continuous electronic data stream and make the information available to the public as close to real time as is technically
possible, on a reasonable commercial basis.
That information shall include, at least, the following details:
(a) the identifier of the financial instrument;
(b) the price at which the transaction was concluded;
(c) the volume of the transaction;
(d) the time of the transaction;
(e) the time the transaction was reported;
(f) the price notation of the transaction;
(g) the code for the trading venue the transaction was executed on, or where the transaction was executed via a
systematic internaliser the code ‘SI’ or otherwise the code ‘OTC’;
(h) where applicable, the fact that a computer algorithm within the investment firm was responsible for the investment
decision and the execution of the transaction;
(i) if applicable, an indicator that the transaction was subject to specific conditions;
(j) if the obligation to make public the information referred to in Article 3(1) of Regulation (EU) No 600/2014 was
waived in accordance with point (a) or (b) of Article 4(1) of that Regulation, a flag to indicate which of those waivers
the transaction was subject to.
The information shall be made available free of charge 15 minutes after the CTP has published it. The home Member
State shall require the CTP to be able to efficiently and consistently disseminate such information in a way that ensures
fast access to the information, on a non-discriminatory basis and in formats that are easily accessible and utilisable for
market participants.
2.
The home Member State shall require a CTP to have adequate policies and arrangements in place to collect the
information made public in accordance with Articles 10 and 21 of Regulation (EU) No 600/2014, consolidate it into a
continuous electronic data stream and make following information available to the public as close to real time as is
technically possible, on a reasonable commercial basis including, at least, the following details:
(a) the identifier or identifying features of the financial instrument;
EN
L 173/450
Official Journal of the European Union
12.6.2014

<!-- source-page: 103 -->

(b) the price at which the transaction was concluded;
(c) the volume of the transaction;
(d) the time of the transaction;
(e) the time the transaction was reported;
(f) the price notation of the transaction;
(g) the code for the trading venue the transaction was executed on, or where the transaction was executed via a
systematic internaliser the code ‘SI’ or otherwise the code ‘OTC’;
(h) if applicable, an indicator that the transaction was subject to specific conditions.
The information shall be made available free of charge 15 minutes after the CTP has published it. The home Member
State shall require the CTP to be able to efficiently and consistently disseminate such information in a way that ensures
fast access to the information, on a non-discriminatory basis and in generally accepted formats that are interoperable and
easily accessible and utilisable for market participants.
3.
The home Member State shall require the CTP to ensure that the data provided is consolidated from all the
regulated markets, MTFs, OTFs and APAs and for the financial instruments specified by regulatory technical standards
under point (c) of paragraph 8.
4.
The home Member State shall require the CTP to operate and maintain effective administrative arrangements
designed to prevent conflicts of interest. In particular, a market operator or an APA, who also operate a consolidated
tape, shall treat all information collected in a non-discriminatory fashion and shall operate and maintain appropriate
arrangements to separate different business functions.
5.
The home Member State shall require the CTP to have sound security mechanisms in place designed to guarantee
the security of the means of transfer of information and to minimise the risk of data corruption and unauthorised access.
The home Member State shall require the CTP to maintain adequate resources and have back-up facilities in place in order
to offer and maintain its services at all times.
6.
ESMA shall develop draft regulatory technical standards to determine data standards and formats for the
information to be published in accordance with Articles 6, 10, 20 and 21 of Regulation (EU) No 600/2014,
including financial instrument identifier, price, quantity, time, price notation, venue identifier and indicators for
specific conditions the transactions was subject to as well as technical arrangements promoting an efficient and consistent
dissemination of information in a way ensuring for it to be easily accessible and utilisable for market participants as
referred to in paragraphs 1 and 2, including identifying additional services the CTP could perform which increase the
efficiency of the market.
ESMA shall submit the draft regulatory technical standards referred to in the first subparagraph to the Commission by
3 July 2015 in respect of information published in accordance with Articles 6 and 20 of Regulation (EU) No 600/2014
and by 3 July 2015 in respect of information published in accordance with Articles 10 and 21 of Regulation (EU) No
600/2014.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
EN
12.6.2014
Official Journal of the European Union
L 173/451

<!-- source-page: 104 -->

7.
The Commission shall adopt delegated acts in accordance with Article 89 clarifying what constitutes a reasonable
commercial basis to provide access to data streams as referred to in paragraphs 1 and 2 of this Article.
8.
ESMA shall develop draft regulatory technical standards specifying:
(a) the means by which the CTP may comply with the information obligation referred to in paragraphs 1 and 2;
(b) the content of the information published under paragraphs 1 and 2;
(c) the financial instruments data of which must be provided in the data stream and for non-equity instruments the
trading venues and APAs which need to be included;
(d) other means to ensure that the data published by different CTPs is consistent and allows for comprehensive mapping
and cross-referencing against similar data from other sources, and is capable of being aggregated at Union level;
(e) the concrete organisational requirements laid down in paragraphs 4 and 5.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
S e c t i o n 4
C o n d i t i o n s f o r A R M s
Article 66
Organisational requirements
1.
The home Member State shall require an ARM to have adequate policies and arrangements in place to report the
information required under Article 26 of Regulation (EU) No 600/2014 as quickly as possible, and no later than the close
of the working day following the day upon which the transaction took place. Such information shall be reported in
accordance with the requirements laid down in Article 26 of Regulation (EU) No 600/2014.
2.
The home Member State shall require the ARM to operate and maintain effective administrative arrangements
designed to prevent conflicts of interest with its clients. In particular, an ARM that is also a market operator or
investment firm shall treat all information collected in a non-discriminatory fashion and shall operate and maintain
appropriate arrangements to separate different business functions.
3.
The home Member State shall require the ARM to have sound security mechanisms in place designed to guarantee
the security and authentication of the means of transfer of information, minimise the risk of data corruption and
unauthorised access and to prevent information leakage, maintaining the confidentiality of the data at all times. The
home Member State shall require the ARM to maintain adequate resources and have back-up facilities in place in order to
offer and maintain its services at all times.
4.
The home Member State shall require the ARM to have systems in place that can effectively check transaction
reports for completeness, identify omissions and obvious errors caused by the investment firm and where such error or
omission occurs, to communicate details of the error or omission to the investment firm and request re-transmission of
any such erroneous reports.
EN
L 173/452
Official Journal of the European Union
12.6.2014

<!-- source-page: 105 -->

The home Member State shall also require the ARM to have systems in place to enable the ARM to detect errors or
omissions caused by the ARM itself and to enable the ARM to correct and transmit, or re-transmit as the case may be,
correct and complete transaction reports to the competent authority.
5.
ESMA shall develop draft regulatory technical standards specifying:
(a) the means by which the ARM may comply with the information obligation referred to in paragraph 1; and
(b) the concrete organisational requirements laid down in paragraphs 2, 3 and 4.
ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation (EU) No 1095/2010.
TITLE VI
COMPETENT AUTHORITIES
CHAPTER I
Designation, powers and redress procedures
Article 67
Designation of competent authorities
1.
Each Member State shall designate the competent authorities which are to carry out each of the duties provided for
under the different provisions of Regulation (EU) No 600/2014 and of this Directive. Member States shall inform the
Commission, ESMA and the competent authorities of other Member States of the identity of the competent authorities
responsible for enforcement of each of those duties, and of any division of those duties.
2.
The competent authorities referred to in paragraph 1 shall be public authorities, without prejudice to the possibility
of delegating tasks to other entities where that is expressly provided for in Article 29(4).
Any delegation of tasks to entities other than the authorities referred to in paragraph 1 may not involve either the
exercise of public authority or the use of discretionary powers of judgement. Member States shall require that, prior to
delegation, competent authorities take all reasonable steps to ensure that the entity to which tasks are to be delegated has
the capacity and resources to effectively execute all tasks and that the delegation takes place only if a clearly defined and
documented framework for the exercise of any delegated tasks has been established stating the tasks to be undertaken and
the conditions under which they are to be carried out. Those conditions shall include a clause obliging the entity in
question to act and be organised in such a manner as to avoid conflict of interest and so that information obtained from
carrying out the delegated tasks is not used unfairly or to prevent competition. The final responsibility for supervising
compliance with this Directive and with its implementing measures shall lie with the competent authority or authorities
designated in accordance with paragraph 1.
Member States shall inform the Commission, ESMA and the competent authorities of other Member States of any
arrangements entered into with regard to delegation of tasks, including the precise conditions regulating such delegation.
3.
ESMA shall publish and keep up-to-date a list of the competent authorities referred to in paragraphs 1 and 2 on its
website.
EN
12.6.2014
Official Journal of the European Union
L 173/453

<!-- source-page: 106 -->

Article 68
Cooperation between authorities in the same Member State
If a Member State designates more than one competent authority to enforce a provision of this Directive or of Regulation
(EU) No 600/2014, their respective roles shall be clearly defined and they shall cooperate closely.
Each Member State shall require that such cooperation also take place between the competent authorities for the purposes
of this Directive or of Regulation (EU) No 600/2014 and the competent authorities responsible in that Member State for
the supervision of credit and other financial institutions, pension funds, UCITS, insurance and reinsurance intermediaries
and insurance undertakings.
Member States shall require that competent authorities exchange any information which is essential or relevant to the
exercise of their functions and duties.
Article 69
Supervisory powers
1.
Competent authorities shall be given all supervisory powers, including investigatory powers and powers to impose
remedies, necessary to fulfil their duties under this Directive and under Regulation (EU) No 600/2014.
2.
The powers referred to in paragraph 1 shall include, at least, the following powers to:
(a) have access to any document or other data in any form which the competent authority considers could be relevant
for the performance of its duties and receive or take a copy of it;
(b) require or demand the provision of information from any person and if necessary to summon and question a person
with a view to obtaining information;
(c) carry out on-site inspections or investigations;
(d) require existing recordings of telephone conversations or electronic communications or other data traffic records held
by an investment firm, a credit institution, or any other entity regulated by this Directive or by Regulation (EU)
No 600/2014;
(e) require the freezing or the sequestration of assets, or both;
(f)
require the temporary prohibition of professional activity;
(g) require the auditors of authorised investment firms, regulated markets and data reporting services providers to
provide information;
(h) refer matters for criminal prosecution;
(i)
allow auditors or experts to carry out verifications or investigations;
(j)
require or demand the provision of information including all relevant documentation from any person regarding the
size and purpose of a position or exposure entered into via a commodity derivative, and any assets or liabilities in
the underlying market;
EN
L 173/454
Official Journal of the European Union
12.6.2014

<!-- source-page: 107 -->

(k) require the temporary or permanent cessation of any practice or conduct that the competent authority considers to
be contrary to the provisions of Regulation (EU) No 600/2014 and the provisions adopted in the implementation of
this Directive and prevent repetition of that practice or conduct;
(l)
adopt any type of measure to ensure that investment firms, regulated markets and other persons to whom this
Directive or Regulation (EU) No 600/2014 applies, continue to comply with legal requirements;
(m) require the suspension of trading in a financial instrument;
(n) require the removal of a financial instrument from trading, whether on a regulated market or under other trading
arrangements;
(o) request any person to take steps to reduce the size of the position or exposure;
(p) limit the ability of any person from entering into a commodity derivative, including by introducing limits on the size
of a position any person can hold at all times in accordance with Article 57 of this Directive;
(q) issue public notices;
(r) require, in so far as permitted by national law, existing data traffic records held by a telecommunication operator,
where there is a reasonable suspicion of an infringement and where such records may be relevant to an investigation
into infringements of this Directive or of Regulation (EU) No 600/2014;
(s) suspend the marketing or sale of financial instruments or structured deposits where the conditions of Articles 40, 41
or 42 of Regulation (EU) No 600/2014 are met;
(t)
suspend the marketing or sale of financial instruments or structured deposits where the investment firm has not
developed or applied an effective product approval process or otherwise failed to comply with Article 16(3) of this
Directive;
(u) require the removal of a natural person from the management board of an investment firm or market operator.
By 3 July 2016, the Member States shall notify the laws, regulations and administrative provisions transposing paragraphs
1 and 2 to the Commission and ESMA. They shall notify the Commission and ESMA without undue delay of any
subsequent amendment thereto.
Member States shall ensure that mechanisms are in place to ensure that compensation may be paid or other remedial
action be taken in accordance with national law for any financial loss or damage suffered as a result of an infringement of
this Directive or of Regulation (EU) No 600/2014.
Article 70
Sanctions for infringements
1.
Without prejudice to the supervisory powers including investigatory powers and powers to impose remedies of
competent authorities in accordance with Article 69 and the right for Member States to provide for and impose criminal
sanctions, Member States shall lay down rules on and ensure that their competent authorities may impose administrative
sanctions and measures applicable to all infringements of this Directive or of Regulation (EU) No 600/2014 and the
national provisions adopted in the implementation of this Directive and of Regulation (EU) No 600/2014, and shall take
all measures necessary to ensure that they are implemented. Such sanctions and measures shall be effective, proportionate
and dissuasive and shall apply to infringements even where they are not specifically referred to in paragraphs 3, 4 and 5.
EN
12.6.2014
Official Journal of the European Union
L 173/455

<!-- source-page: 108 -->

Member States may decide not to lay down rules for administrative sanctions for infringements which are subject to
criminal sanctions under their national law. In that case, Member States shall communicate to the Commission the
relevant criminal law provisions.
By 3 July 2016 Member States shall notify the laws, regulations and administrative provisions transposing this Article,
including any relevant criminal law provisions, to the Commission and ESMA. Member States shall notify the
Commission and ESMA without undue delay of any subsequent amendments thereto.
2.
Member States shall ensure that where obligations apply to investment firms, market operators, data reporting
services providers, credit institutions in relation to investment services or investment activities and ancillary services, and
branches of third-country firms in the case of an infringement, sanctions and measures can be applied, subject to the
conditions laid down in national law in areas not harmonised by this Directive, to the members of the investment firms’
and market operators’ management body, and any other natural or legal persons who, under national law, are responsible
for an infringement.
3.
Member States shall ensure that at least an infringement of the following provisions of this Directive or of
Regulation (EU) No. 600/2014 shall be regarded as an infringement of this Directive or of Regulation (EU) No.
600/2014:
(a) with regard to this Directive:
(i) point (b) of Article 8;
(ii) Article 9(1) to (6);
(iii) Article 11(1) and (3);
(iv) Article 16(1) to (11);
(v) Article 17(1) to (6);
(vi) Article 18(1) to (9) and the first sentence of Article 18(10);
(vii) Articles 19 and 20;
(viii) Article 21(1);
(ix) Article 23(1), (2) and (3);
(x) Article 24(1) to (5) and (7) to (10) and the first and second subparagraphs of Article 24(11);
(xi) Article 25(1) to (6);
(xii) the second sentence of Article 26(1) and Article 26(2) and (3);
(xiii) Article 27(1) to (8);
EN
L 173/456
Official Journal of the European Union
12.6.2014

<!-- source-page: 109 -->

(xiv) Article 28(1) and (2);
(xv) the first subparagraph of Article 29(2), the third subparagraph of Article 29(2), the first sentence of
Article 29(3), the first subparagraph of Article 29(4), and Article 29(5);
(xvi) the second subparagraph of Article 30(1), the first sentence of the second subparagraph of Article 30(3);
(xvii) Article 31(1), the first subparagraph of Article 31(2) and Article 31(3);
(xviii) Article 32(1), the first, second and fourth subparagraphs of Article 32(2);
(xix) Article 33(3);
(xx) Article 34(2), the first sentence of Article 34(4), the first sentence of Article 34(5), the first sentence of
Article 34(7);
(xxi) Article 35(2), the first subparagraph of Article 35(7), the first sentence of Article 35(10);
(xxii) Article 36(1);
(xxiii) the first subparagraph and the first sentence of the second subparagraph of Article 37(1), and the first
subparagraph of Article 37(2);
(xxiv) the fourth subparagraph of Article 44(1), the first sentence of Article 44(2), the first subparagraph of
Article 44(3) and point (b) of Article 44(5);
(xxv) Article 45(1) to (6) and (8);
(xxvi) Article 46(1), points (a) and (b) of Article 46(2);
(xxvii) Article 47;
(xxviii) Article 48(1) to (11);
(xxix) Article 49(1);
(xxx) Article 50(1);
(xxxi) Article 51(1) to (4) and the second sentence of Article 51(5);
(xxxii) Article 52(1), the first, second and fifth subparagraphs of Article 52(2);
(xxxiii) Article 53(1), (2) and (3) and the first sentence of the second subparagraph of Article 53(6), Article 53(7);
EN
12.6.2014
Official Journal of the European Union
L 173/457

<!-- source-page: 110 -->

(xxxiv) Article 54(1), the first subparagraph of Article 54(2) and Article 54(3);
(xxxv) Article 57(1) and (2), Article 57(8) and the first subparagraph of Article 57(10);
(xxxvi) Article 58(1) to (4);
(xxxvii) Article 63(1), (3) and (4);
(xxxviii) Article 64(1) to (5);
(xxxix) Article 65(1) to (5);
(xxxx) Article 66(1) to (4); and
(b) with regard to Regulation (EU) No 600/2014:
(i) Articles 3(1) and (3);
(ii) the first subparagraph of Article 4(3);
(iii) Article 6;
(iv) the first sentence of third subparagraph of Article 7(1);
(v) Article 8(1), (3) and, (4);
(vi) Article 10;
(vii) the first sentence of third subparagraph of Article 11(1) and the third subparagraph of Article 11(3);
(viii) Article 12(1);
(ix) Article 13(1);
(x) Article 14(1), the first sentence of Article 14(2) and the second, third and fourth sentence of Article 14(3);
(xi) the first subparagraph and the first and third sentences of second subparagraph of Article 15(1), Article 15(2)
and the second sentence of Article 15(4);
(xii) the second sentence of Article 17(1);
(xiii) Article 18(1) and (2), first sentence of Article 18(4), first sentence of Article 18(5), the first subparagraph of
Article 18(6), Article 18(8) and (9);
EN
L 173/458
Official Journal of the European Union
12.6.2014

<!-- source-page: 111 -->

(xiv) Article 20(1) and the first sentence of Article 20(2);
(xv) Article 21(1), (2) and (3);
(xvi) Article 22(2);
(xvii) Article 23(1) and (2);
(xviii) Article 25(1) and (2);
(xix) the first subparagraph of Article 26(1), Article 26(2) to (5), the first subparagraph of Article 26(6), the first to
fifth and eighth subparagraph of Article 26(7);
(xx) Article 27(1);
(xxi) Article 28(1) and the first subparagraph of Article 28(2);
(xxii) Article 29(1) and (2);
(xxiii) Article 30(1);
(xxiv) Article 31(2) and (3);
(xxv) Article 35(1), (2) and (3);
(xxvi) Article 36(1), (2) and (3);
(xxvii) Article 37(1) and (3);
(xxviii) Articles 40, 41 and 42.
4.
Providing investment services or performing investment activities without the required authorisation or approval in
accordance with the following provisions of this Directive or of Regulation (EU) No 600/2014 shall also be considered to
be an infringement of this Directive or of Regulation (EU) No 600/2014:
(a) Article 5 or Article 6(2) or Articles 34, 35, 39, 44 or 59 of this Directive; or
(b) the third sentence of Article 7(1) or Article 11(1) of Regulation (EU) No 600/2014.
5.
Failure to cooperate or comply in an investigation or with an inspection or request covered by Article 69 shall also
be regarded as an infringement of this Directive.
EN
12.6.2014
Official Journal of the European Union
L 173/459

<!-- source-page: 112 -->

6.
In the cases of infringements referred to in paragraphs 3, 4 and 5, Member States shall, in conformity with national
law, provide that competent authorities have the power to take and impose at least the following administrative sanctions
and measures:
(a) a public statement, which indicates the natural or legal person and the nature of the infringement in accordance with
Article 71;
(b) an order requiring the natural or legal person to cease the conduct and to desist from a repetition of that conduct;
(c) in the case of an investment firm, a market operator authorised to operate an MTF or OTF, a regulated market, an
APA, a CTP and an ARM, withdrawal or suspension of the authorisation of the institution in accordance with Articles
8, 43 and 65;
(d) a temporary or, for repeated serious infringements a permanent ban against any member of the investment firm’s
management body or any other natural person, who is held responsible, to exercise management functions in
investment firms;
(e) a temporary ban on any investment firm being a member of or participant in regulated markets or MTFs or any client
of OTFs;
(f) in the case of a legal person, maximum administrative fines of at least EUR 5 000 000, or in the Member States
whose currency is not the euro, the corresponding value in the national currency on 2 July 2014, or of up to 10 % of
the total annual turnover of the legal person according to the last available accounts approved by the management
body; where the legal person is a parent undertaking or a subsidiary of the parent undertaking which has to prepare
consolidated financial accounts in accordance with Directive 2013/34/EU, the relevant total annual turnover shall be
the total annual turnover or the corresponding type of income in accordance with the relevant accounting legislative
acts according to the last available consolidated accounts approved by the management body of the ultimate parent
undertaking;
(g) in the case of a natural person, maximum administrative fines of at least EUR 5 000 000, or in the Member States
whose currency is not the euro, the corresponding value in the national currency on 2 July 2014;
(h) maximum administrative fines of at least twice the amount of the benefit derived from the infringement where that
benefit can be determined, even if that exceeds the maximum amounts in points (f) and (g).
7.
Member States may empower competent authorities to impose types of sanction in addition to those referred to in
paragraph 6 or to impose fines exceeding the amounts referred to in points (f), (g) and (h) of paragraph 6.
Article 71
Publication of decisions
1.
Member States shall provide that competent authorities publish any decision imposing an administrative sanction or
measure for infringements of Regulation (EU) No 600/2014 or of the national provisions adopted in the implementation
of this Directive on their official websites without undue delay after the person on whom the sanction was imposed has
been informed of that decision. The publication shall include at least information on the type and nature of the
infringement and the identity of the persons responsible. That obligation does not apply to decisions imposing
measures that are of an investigatory nature.
However, where the publication of the identity of the legal persons or of the personal data of the natural persons is
considered by the competent authority to be disproportionate following a case-by-case assessment conducted on the
proportionality of the publication of such data, or where publication jeopardises the stability of financial markets or an
on-going investigation, Member States shall ensure that competent authorities shall either:
EN
L 173/460
Official Journal of the European Union
12.6.2014

<!-- source-page: 113 -->

(a) defer the publication of the decision to impose the sanction or measure until the moment where the reasons for non-
publication cease to exist;
(b) publish the decision to impose the sanction or measure on an anonymous basis in a manner which complies with
national law, if such anonymous publication ensures an effective protection of the personal data concerned;
(c) not publish the decision to impose a sanction or measure at all in the event that the options set out in points (a) and
(b) are considered to be insufficient to ensure:
(i) that the stability of financial markets would not be put in jeopardy;
(ii) the proportionality of the publication of such decisions with regard to measures which are deemed to be of a
minor nature.
In the case of a decision to publish a sanction or measure on an anonymous basis, the publication of the relevant data
may be postponed for a reasonable period of time if it is envisaged that within that period the reasons for anonymous
publication shall cease to exist.
2.
Where the decision to impose a sanction or measure is subject to appeal before the relevant judicial or other
authorities, competent authorities shall also publish, immediately, on their official website such information and any
subsequent information on the outcome of such appeal. Moreover, any decision annulling a previous decision to impose
a sanction or a measure shall also be published.
3.
Competent authorities shall ensure that any publication in accordance with this Article shall remain on their official
website for a period of at least five years after its publication. Personal data contained in the publication shall only be
kept on the official website of the competent authority for the period which is necessary in accordance with the
applicable data protection rules.
Competent authorities shall inform ESMA of all administrative sanctions imposed but not published in accordance with
point (c) of paragraph 1 including any appeal in relation thereto and the outcome thereof. Member States shall ensure
that competent authorities receive information and the final judgement in relation to any criminal sanction imposed and
submit it to ESMA. ESMA shall maintain a central database of sanctions communicated to it solely for the purposes of
exchanging information between competent authorities. That database shall be accessible to competent authorities only
and it shall be updated on the basis of the information provided by the competent authorities.
4.
Member States shall provide ESMA annually with aggregated information regarding all sanctions and measures
imposed in accordance with paragraphs 1 and 2. That obligation does not apply to measures of an investigatory nature.
ESMA shall publish that information in an annual report.
Where Member States have chosen, in accordance with Article 70, to lay down criminal sanctions for infringements of
the provisions referred to in that Article, their competent authorities shall provide ESMA annually with anonymised and
aggregated data regarding all criminal investigations undertaken and criminal sanctions imposed. ESMA shall publish data
on criminal sanctions imposed in an annual report.
5.
Where the competent authority has disclosed an administrative measure, sanction or criminal sanction to the public,
it shall, at the same time, report that fact to ESMA.
EN
12.6.2014
Official Journal of the European Union
L 173/461

<!-- source-page: 114 -->

6.
Where a published criminal or administrative sanction relates to an investment firm, market operator, data
reporting services provider, credit institution in relation to investment services and activities or ancillary services, or a
branch of third-country firms authorised in accordance with this Directive, ESMA shall add a reference to the published
sanction in the relevant register.
7.
ESMA shall develop draft implementing technical standards concerning the procedures and forms for submitting
information as referred to in this Article.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 72
Exercise of supervisory powers and powers to impose sanctions
1.
Competent authorities shall exercise the supervisory powers including, investigatory powers and powers to impose
remedies, referred to in Article 69 and the powers to impose sanctions referred to in Article 70 in accordance with their
national legal frameworks:
(a) directly;
(b) in collaboration with other authorities;
(c) under their responsibility by delegation to entities to which tasks have been delegated pursuant to Article 67(2); or
(d) by application to the competent judicial authorities.
2.
Member States shall ensure that competent authorities, when determining the type and level of an administrative
sanction or measure imposed under the exercise of powers to impose sanctions in Article 70, take into account all
relevant circumstances, including, where appropriate:
(a) the gravity and the duration of the infringement;
(b) the degree of responsibility of the natural or legal person responsible for the infringement;
(c) the financial strength of the responsible natural or legal person, as indicated in particular by the total turnover of the
responsible legal person or the annual income and net assets of the responsible natural person;
(d) the importance of profits gained or losses avoided by the responsible natural or legal person, insofar as they can be
determined;
(e) the losses for third parties caused by the infringement, insofar as they can be determined;
(f) the level of cooperation of the responsible natural or legal person with the competent authority, without prejudice to
the need to ensure disgorgement of profits gained or losses avoided by that person;
EN
L 173/462
Official Journal of the European Union
12.6.2014

<!-- source-page: 115 -->

(g) previous infringements by the responsible natural or legal person.
Competent authorities may take into account additional factors to those referred to in the first subparagraph when
determining the type and level of administrative sanctions and measures.
Article 73
Reporting of infringements
1.
Member States shall ensure that competent authorities establish effective mechanisms to enable reporting of
potential or actual infringements of the provisions of Regulation (EU) No 600/2014 and of the national provisions
adopted in the implementation of this Directive to competent authorities.
The mechanisms referred to in the first subparagraph shall include at least:
(a) specific procedures for the receipt of reports on potential or actual infringements and their follow-up, including the
establishment of secure communication channels for such reports;
(b) appropriate protection for employees of financial institutions who report infringements committed within the
financial institution at least against retaliation, discrimination or other types of unfair treatment;
(c) protection of the identity of both the person who reports the infringements and the natural person who is allegedly
responsible for an infringement, at all stages of the procedures unless such disclosure is required by national law in
the context of further investigation or subsequent administrative or judicial proceedings.
2.
Member States shall require investment firms, market operators, data reporting services providers, credit institutions
in relation to investment services or activities and ancillary services, and branches of third-country firms to have in place
appropriate procedures for their employees to report potential or actual infringements internally through a specific,
independent and autonomous channel.
Article 74
Right of appeal
1.
Member States shall ensure that any decision taken under the provisions of Regulation (EU) No 600/2014 or under
laws, regulations or administrative provisions adopted in accordance with this Directive is properly reasoned and is
subject to the right of appeal before a tribunal. The right of appeal before a tribunal shall also apply where, in respect of
an application for authorisation which provides all the information required, no decision is taken within six months of its
submission.
2.
Member States shall provide that one or more of the following bodies, as determined by national law, also may, in
the interests of consumers and in accordance with national law, take action before the courts or competent administrative
bodies to ensure that Regulation (EU) No 600/2014 and the national provisions adopted in the implementation of this
Directive are applied:
(a) public bodies or their representatives;
(b) consumer organisations having a legitimate interest in protecting consumers;
(c) professional organisations having a legitimate interest in acting to protect their members.
EN
12.6.2014
Official Journal of the European Union
L 173/463

<!-- source-page: 116 -->

Article 75
Extra-judicial mechanism for consumers complaints
1.
Member States shall ensure the setting-up of efficient and effective complaints and redress procedures for the
out-of-court settlement of consumer disputes concerning the provision of investment and ancillary services provided
by investment firms, using existing bodies where appropriate. Member States shall further ensure that all investment firms
adhere to one or more such bodies implementing such complaint and redress procedures.
2.
Member States shall ensure that those bodies actively cooperate with their counterparts in other Member States in
the resolution of cross-border disputes.
3.
The competent authorities shall notify ESMA of the complaint and redress procedures referred to in paragraph 1
which are available under its jurisdictions.
ESMA shall publish and keep up-to-date a list of all extra-judicial mechanisms on its website.
Article 76
Professional secrecy
1.
Member States shall ensure that competent authorities, all persons who work or who have worked for the
competent authorities or entities to whom tasks are delegated pursuant to Article 67(2), as well as auditors and
experts instructed by the competent authorities, are bound by the obligation of professional secrecy. They shall not
divulge any confidential information which they may receive in the course of their duties, save in summary or aggregate
form such that individual investment firms, market operators, regulated markets or any other person cannot be identified,
without prejudice to requirements of national criminal or taxation law or the other provisions of this Directive or of
Regulation (EU) No 600/2014.
2.
Where an investment firm, market operator or regulated market has been declared bankrupt or is being compul­
sorily wound up, confidential information which does not concern third parties may be divulged in civil or commercial
proceedings if necessary for carrying out the proceeding.
3.
Without prejudice to requirements of national criminal or taxation law, the competent authorities, bodies or natural
or legal persons other than competent authorities which receive confidential information pursuant to this Directive or to
Regulation (EU) No 600/2014 may use it only in the performance of their duties and for the exercise of their functions,
in the case of the competent authorities, within the scope of this Directive or of Regulation (EU) No 600/2014 or, in the
case of other authorities, bodies or natural or legal persons, for the purpose for which such information was provided to
them and/or in the context of administrative or judicial proceedings specifically relating to the exercise of those functions.
However, where the competent authority or other authority, body or person communicating information consents
thereto, the authority receiving the information may use it for other purposes.
4.
Any confidential information received, exchanged or transmitted pursuant to this Directive or to Regulation (EU)
No 600/2014 shall be subject to the conditions of professional secrecy laid down in this Article. Nevertheless, this Article
shall not prevent the competent authorities from exchanging or transmitting confidential information in accordance with
this Directive or with Regulation (EU) No 600/2014 and with other Directives or Regulations applicable to investment
firms, credit institutions, pension funds, UCITS, AIFs, insurance and reinsurance intermediaries, insurance undertakings,
regulated markets or market operators, CCPs, CSDs, or otherwise with the consent of the competent authority or other
authority or body or natural or legal person that communicated the information.
5.
This Article shall not prevent the competent authorities from exchanging or transmitting in accordance with
national law, confidential information that has not been received from a competent authority of another Member State.
EN
L 173/464
Official Journal of the European Union
12.6.2014

<!-- source-page: 117 -->

Article 77
Relations with auditors
1.
Member States shall provide, at least, that any person authorised within the meaning of Directive 2006/43/EC of the
European Parliament and of the Council ( 1 ), performing in an investment firm, a regulated market or a data reporting
services provider the task described in Article 34 of Directive 2013/34/EU or Article 73 of Directive 2009/65/EC or any
other task prescribed by law, shall have a duty to report promptly to the competent authorities any fact or decision
concerning that undertaking of which that person has become aware while carrying out that task and which is liable to:
(a) constitute a material infringement of the laws, regulations or administrative provisions which lay down the conditions
governing authorisation or which specifically govern pursuit of the activities of investment firms;
(b) affect the continuous functioning of the investment firm;
(c) lead to refusal to certify the accounts or to the expression of reservations.
That person shall also have a duty to report any facts and decisions of which the person becomes aware in the course of
carrying out one of the tasks referred to in the first subparagraph in an undertaking having close links with the
investment firm within which he is carrying out that task.
2.
The disclosure in good faith to the competent authorities, by persons authorised within the meaning of Directive
2006/43/EC, of any fact or decision referred to in paragraph 1 shall not constitute a breach of any contractual or legal
restriction on disclosure of information and shall not involve such persons in liability of any kind.
Article 78
Data protection
The processing of personal data collected in or for the exercise of the supervisory powers including investigatory powers
in accordance with this Directive shall be carried out in accordance with national law implementing Directive 95/46/EC
and with Regulation (EC) No 45/2001 where applicable.
CHAPTER II
Cooperation between the competent authorities of the Member States and with ESMA
Article 79
Obligation to cooperate
1.
Competent authorities of different Member States shall cooperate with each other where necessary for the purpose
of carrying out their duties under this Directive or under Regulation (EU) No 600/2014, making use of their powers
whether set out in this Directive or in Regulation (EU) No 600/2014 or in national law.
Where Member States have chosen, in accordance with Article 70, to lay down criminal sanctions for infringements of
the provisions referred to in that Article, they shall ensure that appropriate measures are in place so that competent
authorities have all the necessary powers to liaise with judicial authorities within their jurisdiction to receive specific
information relating to criminal investigations or proceedings commenced for possible infringements of this Directive and
of Regulation (EU) No 600/2014 and provide the same to other competent authorities and ESMA to fulfil their obligation
to cooperate with each other and ESMA for the purposes of this Directive and of Regulation (EU) No 600/2014.
EN
12.6.2014
Official Journal of the European Union
L 173/465
( 1 ) Directive 2006/43/EC of the European Parliament and of the Council of 17 May 2006 on statutory audits of annual accounts and
consolidated accounts, amending Council Directives 78/660/EEC and 83/349/EEC and repealing Council Directive 84/253/EEC
(OJ L 157, 9.6.2006, p. 87).

<!-- source-page: 118 -->

Competent authorities shall render assistance to competent authorities of the other Member States. In particular, they
shall exchange information and cooperate in any investigation or supervisory activities.
Competent authorities may also cooperate with competent authorities of other Member States with respect to facilitating
the recovery of fines.
In order to facilitate and accelerate cooperation, and more particularly exchange of information, Member States shall
designate a single competent authority as a contact point for the purposes of this Directive and of Regulation (EU)
No 600/2014. Member States shall communicate to the Commission, ESMA and to the other Member States the names
of the authorities which are designated to receive requests for exchange of information or cooperation pursuant to this
paragraph. ESMA shall publish and keep up-to-date a list of those authorities on its website.
2.
When, taking into account the situation of the securities markets in the host Member State, the operations of a
trading venue that has established arrangements in a host Member State have become of substantial importance for the
functioning of the securities markets and the protection of the investors in that host Member State, the home and host
competent authorities of the trading venue shall establish proportionate cooperation arrangements.
3.
Member States shall take the necessary administrative and organisational measures to facilitate the assistance
provided for in paragraph 1
Competent authorities may use their powers for the purpose of cooperation, even where the conduct under investigation
does not constitute an infringement of any regulation in force in that Member State.
4.
Where a competent authority has good reasons to suspect that acts contrary to the provisions of this Directive or of
Regulation (EU) No 600/2014, carried out by entities not subject to its supervision, are being or have been carried out on
the territory of another Member State, it shall notify the competent authority of the other Member State and ESMA in as
specific a manner as possible. The notified competent authority shall take appropriate action. It shall inform the notifying
competent authority and ESMA of the outcome of the action and, to the extent possible, of significant interim devel­
opments. This paragraph shall be without prejudice to the competence of the notifying competent authority.
5.
Without prejudice to paragraphs 1 and 4, competent authorities shall notify ESMA and other competent authorities
of the details of:
(a) any requests to reduce the size of a position or exposure pursuant to point (o) of Article 69(2);
(b) any limits on the ability of persons to enter into a commodity derivative pursuant to point (p) of Article 69(2).
The notification shall include, where relevant, the details of the request or the demand pursuant to point (j) of
Article 69(2) including the identity of the person or persons to whom it was addressed and the reasons therefor, as
well as the scope of the limits introduced pursuant to point (p) of Article 69(2) including the person concerned, the
applicable financial instruments, any limits on the size of positions the person can hold at all times, any exemptions
thereto granted in accordance with Article 57, and the reasons therefor.
The notifications shall be made not less than 24 hours before the actions or measures are intended to take effect. In
exceptional circumstances, a competent authority may make the notification less than 24 hours before the measure is
intended to take effect where it is not possible to give 24 hours’ notice.
A competent authority of a Member State that receives notification under this paragraph may take measures in
accordance with point (o) or (p) of Article 69(2) where it is satisfied that the measure is necessary to achieve the
objective of the other competent authority. The competent authority shall also give notice in accordance with this
paragraph where it proposes to take measures.
EN
L 173/466
Official Journal of the European Union
12.6.2014

<!-- source-page: 119 -->

When an action under points (a) or (b) of the first subparagraph of this paragraph relates to wholesale energy products,
the competent authority shall also notify the Agency for the Cooperation of Energy Regulators (ACER) established under
Regulation (EC) No 713/2009.
6.
In relation to emission allowances, competent authorities shall cooperate with public bodies competent for the
oversight of spot and auction markets and competent authorities, registry administrators and other public bodies charged
with the supervision of compliance under Directive 2003/87/EC in order to ensure that they can acquire a consolidated
overview of emission allowances markets.
7.
In relation to agricultural commodity derivatives, competent authorities shall report to and cooperate with public
bodies competent for the oversight, administration and regulation of physical agricultural markets under Regulation (EU)
No 1308/2013.
8.
The Commission shall be empowered to adopt delegated acts in accordance with Article 89 to establish the criteria
under which the operations of a trading venue in a host Member State could be considered to be of substantial
importance for the functioning of the securities markets and the protection of the investors in that host Member State.
9.
ESMA shall develop draft implementing technical standards to establish standard forms, templates and procedures
for the cooperation arrangements referred to in paragraph 2.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 80
Cooperation between competent authorities in supervisory activities, for on-site verifications or investigations
1.
A competent authority of one Member State may request the cooperation of the competent authority of another
Member State in a supervisory activity or for an on-the-spot verification or in an investigation. In the case of investment
firms that are remote members or participants of a regulated market the competent authority of the regulated market
may choose to address them directly, in which case it shall inform the competent authority of the home Member State of
the remote member or participant accordingly.
Where a competent authority receives a request with respect to an on-the-spot verification or an investigation, it shall,
within the framework of its powers:
(a) carry out the verifications or investigations itself;
(b) allow the requesting authority to carry out the verification or investigation;
(c) allow auditors or experts to carry out the verification or investigation.
2.
With the objective of converging supervisory practices, ESMA may participate in the activities of the colleges of
supervisors, including on-site verifications or investigations, carried out jointly by two or more competent authorities in
accordance with Article 21 of Regulation (EU) No 1095/2010.
3.
ESMA shall develop draft regulatory technical standards to specify the information to be exchanged between
competent authorities when cooperating in supervisory activities, on-the-spot-verifications, and investigations.
EN
12.6.2014
Official Journal of the European Union
L 173/467

<!-- source-page: 120 -->

ESMA shall submit those draft regulatory technical standards to the Commission by 3 July 2015.
Power is delegated to the Commission to adopt the regulatory technical standards referred to in the first subparagraph in
accordance with Articles 10 to 14 of Regulation. (EU) No 1095/2010.
4.
ESMA shall develop draft implementing technical standards to establish standard forms, templates and procedures
for competent authorities to cooperate in supervisory activities, on-site verifications, and investigations.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 81
Exchange of information
1.
Competent authorities of Member States having been designated as contact points for the purposes of this Directive
and of Regulation (EU) No 600/2014 in accordance with Article 79(1) of this Directive shall immediately supply one
another with the information required for the purposes of carrying out the duties of the competent authorities, designated
in accordance to Article 67(1) of this Directive, set out in the provisions adopted pursuant to this Directive or Regulation
(EU) No 600/2014.
Competent authorities exchanging information with other competent authorities under this Directive or Regulation (EU)
No 600/2014 may indicate at the time of communication that such information must not be disclosed without their
express agreement, in which case such information may be exchanged solely for the purposes for which those authorities
gave their agreement.
2.
The competent authority having been designated as the contact point in accordance with Article 79(1) may transmit
the information received under paragraph 1 of this Article and under Articles 77 and 88 to the authorities referred to in
Article 67(1). They shall not transmit it to other bodies or natural or legal persons without the express agreement of the
competent authorities which disclosed it and solely for the purposes for which those authorities gave their agreement,
except in duly justified circumstances. In this last case, the contact point shall immediately inform the contact point that
sent the information.
3.
Authorities as referred to in Article 71 as well as other bodies or natural and legal persons receiving confidential
information under paragraph 1 of this Article or under Articles 77 and 88 may use it only in the course of their duties,
in particular:
(a) to check that the conditions governing the taking-up of the business of investment firms are met and to facilitate the
monitoring, on a non-consolidated or consolidated basis, of the conduct of that business, especially with regard to the
capital adequacy requirements imposed by Directive 2013/36/EU, administrative and accounting procedures and
internal-control mechanisms;
(b) to monitor the proper functioning of trading venues;
(c) to impose sanctions;
(d) in administrative appeals against decisions by the competent authorities;
(e) in court proceedings initiated under Article 74;
EN
L 173/468
Official Journal of the European Union
12.6.2014

<!-- source-page: 121 -->

(f) in the extra-judicial mechanism for investors’ complaints provided for in Article 75.
4.
ESMA shall develop draft implementing technical standards to establish standard forms, templates and procedures
for the exchange of information.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
5.
Neither this Article nor Article 76 or 88 shall prevent a competent authority from transmitting to ESMA, the
European Systemic Risk Board, central banks, the ESCB and the ECB, in their capacity as monetary authorities, and, where
appropriate, to other public authorities responsible for overseeing payment and settlement systems, confidential
information intended for the performance of their tasks. Likewise such authorities or bodies shall not be prevented
from communicating to the competent authorities such information as they may need for the purpose of performing
their functions provided for in this Directive or in Regulation (EU) No 600/2014.
Article 82
Binding mediation
1.
The competent authorities may refer to ESMA situations where a request relating to one of the following has been
rejected or has not been acted upon within a reasonable time:
(a) to carry out a supervisory activity, an on-the-spot verification, or an investigation, as provided for in Article 80; or
(b) to exchange information as provided for in Article 81.
2.
In the situations referred to in paragraph 1, ESMA may act in accordance with Article 19 of Regulation (EU)
No 1095/2010, without prejudice to the possibilities for refusing to act on a request for information provided for in
Article 83 of this Directive and to the possibility of ESMA acting in accordance with Article 17 of Regulation (EU)
No 1095/2010.
Article 83
Refusal to cooperate
A competent authority may refuse to act on a request for cooperation in carrying out an investigation, on-the-spot
verification or supervisory activity as provided for in Article 84 or to exchange information as provided for in Article 81
only where:
(a) judicial proceedings have already been initiated in respect of the same actions and the same persons before the
authorities of the Member State addressed;
(b) final judgment has already been delivered in the Member State addressed in respect of the same persons and the same
actions.
In the case of such a refusal, the competent authority shall notify the requesting competent authority and ESMA
accordingly, providing as detailed information as possible.
EN
12.6.2014
Official Journal of the European Union
L 173/469

<!-- source-page: 122 -->

Article 84
Consultation prior to authorisation
1.
The competent authorities of the other Member State involved shall be consulted prior to granting authorisation to
an investment firm which is any of the following:
(a) a subsidiary of an investment firm or market operator or credit institution authorised in another Member State;
(b) a subsidiary of the parent undertaking of an investment firm or credit institution authorised in another Member State;
(c) controlled by the same natural or legal persons who control an investment firm or credit institution authorised in
another Member State.
2.
The competent authority of the Member State responsible for the supervision of credit institutions or insurance
undertakings shall be consulted prior to granting an authorisation to an investment firm or market operator which is any
of the following:
(a) a subsidiary of a credit institution or insurance undertaking authorised in the Union;
(b) a subsidiary of the parent undertaking of a credit institution or insurance undertaking authorised in the Union;
(c) controlled by the same person, whether natural or legal, who controls a credit institution or insurance undertaking
authorised in the Union.
3.
The relevant competent authorities referred to in paragraphs 1 and 2 shall in particular consult each other when
assessing the suitability of the shareholders or members and the reputation and experience of persons who effectively
direct the business involved in the management of another entity of the same group. They shall exchange all information
regarding the suitability of shareholders or members and the reputation and experience of persons who effectively direct
the business that is of relevance to the other competent authorities involved, for the granting of an authorisation as well
as for the ongoing assessment of compliance with operating conditions.
4.
ESMA shall develop draft implementing technical standards to establish standard forms, templates and procedures
for the consultation of other competent authorities prior to granting an authorisation.
ESMA shall submit those draft implementing technical standards to the Commission by 3 January 2016.
Power is conferred on the Commission to adopt the implementing technical standards referred to in the first
subparagraph in accordance with Article 15 of Regulation (EU) No 1095/2010.
Article 85
Powers for host Member States
1.
Host Member States shall provide that the competent authority may, for statistical purposes, require all investment
firms with branches within their territories to report to them periodically on the activities of those branches.
EN
L 173/470
Official Journal of the European Union
12.6.2014

<!-- source-page: 123 -->

2.
In discharging their responsibilities under this Directive, host Member States shall provide that the competent
authority may require branches of investment firms to provide the information necessary for the monitoring of their
compliance with the standards set by the host Member State that apply to them for the cases provided for in Article 35(8).
Those requirements may not be more stringent than those which the same Member State imposes on established firms
for the monitoring of their compliance with the same standards.
Article 86
Precautionary measures to be taken by host Member States
1.
Where the competent authority of the host Member State has clear and demonstrable grounds for believing that an
investment firm acting within its territory under the freedom to provide services infringes the obligations arising from the
provisions adopted pursuant to this Directive or that an investment firm that has a branch within its territory infringes
the obligations arising from the provisions adopted pursuant to this Directive which do not confer powers on the
competent authority of the host Member State, it shall refer those findings to the competent authority of the home
Member State.
If, despite the measures taken by the competent authority of the home Member State or because such measures prove
inadequate, the investment firm persists in acting in a manner that is clearly prejudicial to the interests of host Member
State investors or the orderly functioning of markets, the following shall apply:
(a) after informing the competent authority of the home Member State, the competent authority of the host Member
State shall take all the appropriate measures needed in order to protect investors and the proper functioning of the
markets, which shall include the possibility of preventing offending investment firms from initiating any further
transactions within their territories. The Commission and ESMA shall be informed of such measures without undue
delay; and
(b) the competent authority of the host Member State may refer the matter to ESMA, which may act in accordance with
the powers conferred on it under Article 19 of Regulation (EU) No 1095/2010.
2.
Where the competent authorities of a host Member State ascertain that an investment firm that has a branch within
its territory infringes the legal or regulatory provisions adopted in that Member State pursuant to those provisions of this
Directive which confer powers on the host Member State’s competent authorities, those authorities shall require the
investment firm concerned to put an end to its irregular situation.
If the investment firm concerned fails to take the necessary steps, the competent authorities of the host Member State
shall take all appropriate measures to ensure that the investment firm concerned puts an end to its irregular situation. The
nature of those measures shall be communicated to the competent authorities of the home Member State.
Where, despite the measures taken by the host Member State, the investment firm persists in infringing the legal or
regulatory provisions referred to in the first subparagraph in force in the host Member State, the competent authority of
the host Member State shall, after informing the competent authority of the home Member State, take all the appropriate
measures needed in order to protect investors and the proper functioning of the markets. The Commission and ESMA
shall be informed of such measures without undue delay.
In addition, the competent authority of the host Member State may refer the matter to ESMA, which may act in
accordance with the powers conferred on it under Article 19 of Regulation (EU) No 1095/2010.
3.
Where the competent authority of the host Member State of a regulated market, an MTF or OTF has clear and
demonstrable grounds for believing that such regulated market, MTF or OTF infringes the obligations arising from the
provisions adopted pursuant to this Directive, it shall refer those findings to the competent authority of the home
Member State of the regulated market or the MTF or OTF.
EN
12.6.2014
Official Journal of the European Union
L 173/471

<!-- source-page: 124 -->

Where, despite the measures taken by the competent authority of the home Member State or because such measures
prove inadequate, that regulated market or the MTF or OTF persists in acting in a manner that is clearly prejudicial to the
interests of host Member State investors or the orderly functioning of markets, the competent authority of the host
Member State shall, after informing the competent authority of the home Member State, take all the appropriate measures
needed in order to protect investors and the proper functioning of the markets, which shall include the possibility of
preventing that regulated market or the MTF or OTF from making their arrangements available to remote members or
participants established in the host Member State. The Commission and ESMA shall be informed of such measures
without undue delay.
In addition, the competent authority of the host Member State may refer the matter to ESMA, which may act in
accordance with the powers conferred on it under Article 19 of Regulation (EU) No 1095/2010.
4.
Any measure adopted pursuant to paragraphs 1, 2 or 3 involving sanctions or restrictions on the activities of an
investment firm or of a regulated market shall be properly justified and communicated to the investment firm or to the
regulated market concerned.
Article 87
Cooperation and exchange of information with ESMA
1.
The competent authorities shall cooperate with ESMA for the purposes of this Directive, in accordance with
Regulation (EU) No 1095/2010.
2.
The competent authorities shall, without undue delay, provide ESMA with all information necessary to carry out its
duties under this Directive and under Regulation (EU) No 600/2014 and in accordance with Articles 35 and 36 of
Regulation (EU) No 1095/2010.
CHAPTER III
Cooperation with third countries
Article 88
Exchange of information with third countries
1.
Member States and in accordance with Article 33 of Regulation (EU) No 1095/2010, ESMA, may conclude
cooperation agreements providing for the exchange of information with the competent authorities of third countries
only if the information disclosed is subject to guarantees of professional secrecy at least equivalent to those required
under Article 76. Such exchange of information must be intended for the performance of the tasks of those competent
authorities.
Transfer of personal data to a third country by a Member State shall be in accordance with Chapter IV of Directive
95/46/EC.
Transfers of personal data to a third country by ESMA shall be in accordance with Article 9 of Regulation (EU)
No 45/2001.
Member States and ESMA may also conclude cooperation agreements providing for the exchange of information with
third country authorities, bodies and natural or legal persons responsible for one or more of the following:
(a) the supervision of credit institutions, other financial institutions, insurance undertakings and the supervision of
financial markets;
(b) the liquidation and bankruptcy of investment firms and other similar procedures;
EN
L 173/472
Official Journal of the European Union
12.6.2014

<!-- source-page: 125 -->

(c) the carrying out of statutory audits of the accounts of investment firms and other financial institutions, credit
institutions and insurance undertakings, in the performance of their supervisory functions, or which administer
compensation schemes, in the performance of their functions;
(d) oversight of the bodies involved in the liquidation and bankruptcy of investment firms and other similar procedures;
(e) oversight of persons charged with carrying out statutory audits of the accounts of insurance undertakings, credit
institutions, investment firms and other financial institutions;
(f) oversight of persons active on emission allowance markets for the purpose of ensuring a consolidated overview of
financial and spot markets;
(g) oversight of persons active on agricultural commodity derivatives markets for the purpose of ensuring a consolidated
overview of financial and spot markets.
The cooperation agreements referred to in the third subparagraph may be concluded only where the information
disclosed is subject to guarantees of professional secrecy at least equivalent to those required under Article 76. Such
exchange of information shall be intended for the performance of the tasks of those authorities or bodies or natural or
legal persons. Where a cooperation agreement involves the transfer of personal data by a Member State, it shall comply
with Chapter IV of Directive 95/46/EC and with Regulation (EC) No 45/2001 in the case ESMA is involved in the
transfer.
2.
Where the information originates in another Member State, it may not be disclosed without the express agreement
of the competent authorities which have transmitted it and, where appropriate, solely for the purposes for which those
authorities gave their agreement. The same provision applies to information provided by third country competent
authorities.
TITLE VII
DELEGATED ACTS
Article 89
Exercise of the delegation
1.
The power to adopt delegated acts is conferred on the Commission subject to the conditions laid down in this
Article.
2.
The delegation of power referred to in Article 2(3), second subparagraph of Article 4(1)(2), Article 4(2),
Article 13(1), Article 16(12), Article 23(4), Article 24(13), Article 25(8), Article 27(9), Article 28(3), Article 30(5),
Article 31(4), Article 32(4), Article 33(8), Article 52(4), Article 54(4), Article 58(6), Article 64(7), Article 65(7) and
Article 79(8) shall be conferred on the Commission for an indeterminate period of time from 2 July 2014.
3.
The delegation of powers referred to in Article 2(3), second subparagraph of Article 4(1)(2), Article 4(2),
Article 13(1), Article 16(12), Article 23(4), Article 24(13), Article 25(8), Article 27(9), Article 28(3), Article 30(5),
Article 31(4), Article 32(4), Article 33(8), Article 52(4) Article 54(4), Article 58(6), Article 64(7), Article 65(7) and
Article 79(8) may be revoked at any time by the European Parliament or by the Council. A decision to revoke shall put
an end to the delegation of the power specified in that decision. It shall take effect the day following the publication of
the decision in the Official Journal of the European Union or at a later date specified therein. It shall not affect the validity of
any delegated acts already in force.
4.
As soon as it adopts a delegated act, the Commission shall notify it simultaneously to the European Parliament and
to the Council.
EN
12.6.2014
Official Journal of the European Union
L 173/473

<!-- source-page: 126 -->

5.
A delegated act adopted pursuant to Article 2(3), second subparagraph of Article 4(1)(2), Article 4(2), Article 13(1),
Article 16(12), Article 23(4), Article 24(13), Article 25(8), Article 27(9), Article 28(3), Article 30(5), Article 31(4),
Article 32(4), Article 33(8), Article 52(4), Article 54(4), Article 58(6), Article 64(7), Article 65(7) and Article 79(8)
shall enter into force only if no objection has been expressed either by the European Parliament or the Council within a
period of three months of notification of that act to the European Parliament and the Council or if, before the expiry of
that period, the European Parliament and the Council have both informed the Commission that they will not object. That
period shall be extended by three months at the initiative of the European Parliament or the Council.
FINAL PROVISIONS
Article 90
Reports and review
1.
Before 3 March 2019 the Commission shall, after consulting ESMA, present a report to the European Parliament
and the Council on:
(a) the functioning of OTFs, including their specific use of matched principal trading, taking into account supervisory
experience acquired by competent authorities, the number of OTFs authorised in the Union and their market share
and in particular examining whether any adjustments are needed to the definition of an OTF and whether the range
of financial instruments covered by the OTF category remains appropriate;
(b) the functioning of the regime for SME growth markets, taking into account the number of MTFs registered as SME
growth markets, numbers of issuers present thereon, and relevant trading volumes;
In particular, the report shall assess whether the threshold in point (a) of Article 33(3) remains an appropriate
minimum to pursue the objectives for SME growth markets as stated in this Directive;
(c) the impact of requirements regarding algorithmic trading including high-frequency algorithmic trading;
(d) the experience with the mechanism for banning certain products or practices, taking into account the number of
times the mechanisms have been triggered and their effects;
(e) the application of the administrative and criminal sanctions and in particular the need to further harmonise the
administrative sanctions set out for the infringement of the requirements set out in this Directive and in Regulation
(EU) No 600/2014;
(f) the impact of the application of position limits and position management on liquidity, market abuse and orderly
pricing and settlement conditions in commodity derivatives markets;
(g) the development in prices for pre and post trade transparency data from regulated markets, MTFs, OTFs and APAs;
(h) the impact of the requirement to disclose any fees, commissions and non-monetary benefits in connection with the
provision of an investment service or an ancillary service to the client in accordance with Article 24(9), including its
impact on the proper functioning of the internal market on cross-border investment advice.
2.
The Commission shall, after consulting ESMA, present reports to the European Parliament and the Council on the
functioning of the consolidated tape established in accordance with Title V. The report relating to Article 65(1) shall be
presented by 3 September 2018. The report relating to Article 65(2) shall be presented by 3 September 2020.
EN
L 173/474
Official Journal of the European Union
12.6.2014

<!-- source-page: 127 -->

The reports referred to in the first subparagraph shall assess the functioning of the consolidated tape against the following
criteria:
(a) the availability and timeliness of post trade information in a consolidated format capturing all transactions irrespective
of whether they are carried out on trading venues or not;
(b) the availability and timeliness of full and partial post trade information that is of a high quality, in formats that are
easily accessible and usable for market participants and available on a reasonable commercial basis.
Where the Commission concludes that the CTPs have failed to provide information in a way that meets the criteria set
out in the second subparagraph, the Commission shall accompany its report by a request to ESMA to launch a negotiated
procedure for the appointment though a public procurement process run by ESMA of a commercial entity operating a
consolidated tape. ESMA shall launch the procedure after receiving the request from the Commission on the conditions
specified in the Commission’s request and in accordance with Regulation (EU, Euratom) No 966/2012 of the European
Parliament and of the Council ( 1 ).
3.
The Commission shall, where the procedure outlined in paragraph 2 is initiated, be empowered to adopt delegated
acts in accordance with Article 89 amending Articles 59 to 65 and Section D of Annex I of this Directive and point (19)
of Article 2(1) of Regulation (EU) No 600/2014, by specifying measures in order to:
(a) provide for the contract duration of the commercial entity operating a consolidated tape and the process and
conditions for renewing the contract and the launching of new public procurement;
(b) provide that the commercial entity operating a consolidated tape shall do so on an exclusive basis and that no other
entity shall be authorised as a CTP in accordance with Article 59;
(c) empower ESMA to ensure adherence with tender conditions by the commercial entity operating a consolidated tape
appointed through a public procurement;
(d) ensure that the post-trade information provided by the commercial entity operating a consolidated tape is of a high
quality, in formats that are easily accessible and usable for market participants and in a consolidated format capturing
the entire market;
(e) ensure that the post trade information is provided on a reasonable commercial basis, on both a consolidated and
unconsolidated basis, and meets the needs of the users of that information across the Union;
(f) ensure that trading venues and APAs shall make their trade data available to the commercial entity operating a
consolidated tape appointed through a public procurement process run by ESMA at a reasonable cost;
(g) specify arrangements applicable where the commercial entity operating a consolidated tape appointed through a
public procurement fails to fulfil the tender conditions;
(h) specify arrangements under which CTPs authorised under Article 59 may continue to operate a consolidated tape
where the empowerment provided for in point (b) of this paragraph is not used or, where no entity is appointed
through the public procurement, until such time as a new public procurement is completed and a commercial entity
is appointed to operate a consolidated tape.
EN
12.6.2014
Official Journal of the European Union
L 173/475
( 1 ) Regulation (EU, Euratom) No 966/2012 of the European Parliament and of the Council of 25 October 2012 on the financial rules
applicable to the general budget of the Union and repealing Council Regulation (EC, Euratom) No 1605/2002 (OJ L 298,
26.10.2012, p. 1).

<!-- source-page: 128 -->

4.
By 1 January 2018 the Commission shall prepare a report, after consulting ESMA and ACER, assessing the potential
impact on energy prices and on the functioning of the energy market as well as the feasibility and the benefits in terms of
reducing counterparty and systemic risks and the direct costs of C6 energy derivative contracts being made subject to the
clearing obligation set out in Article 4 of Regulation (EU) No 648/2012, the risk mitigation techniques set out in
Article 11(3) thereof and their inclusion in calculating the clearing threshold pursuant to Article 10 thereof.
If the Commission considers that it would not be feasible and beneficial to include those contracts, it shall submit, if
appropriate, a legislative proposal to the European Parliament and the Council. The Commission shall be empowered to
adopt delegated acts in accordance with Article 89 of this Directive to extend the 42-month period referred to in
Article 95(1) of this Directive once by two years and a further time by one year.
Article 91
Amendments to Directive 2002/92/EC
Directive 2002/92/EC is hereby amended as follows:
(1) Article 2 is amended as follows:
(a) in point 3, the second paragraph is replaced by the following:
‘With the exception of Chapter III A of this Directive, those activities, when undertaken by an insurance under­
taking or an employee of an insurance undertaking who is acting under the responsibility of the insurance
undertaking shall not be considered to be insurance mediation or insurance distribution’;
(b) the following point is added:
‘(13) For the purposes of Chapter IIIA, ‘insurance-based investment product’ means an insurance product which
offers a maturity or surrender value and where that maturity or surrender value is wholly or partially
exposed, directly or indirectly, to market fluctuations and shall not include:
(a) non-life insurance products as listed in Annex I of Directive 2009/138/EC (Classes of Non-life Insur­
ance);
(b) life insurance contracts where the benefits under the contract are payable only on death or in respect of
incapacity due to injury, sickness or infirmity;
(c) pension products which, under national law, are recognised as having the primary purpose of providing
the investor with an income in retirement, and which entitles the investor to certain benefits;
(d) officially recognised occupational pension schemes falling under the scope of Directive 2003/41/EC or
Directive 2009/138/EC;
(e) individual pension products for which a financial contribution from the employer is required by
national law and where the employer or the employee has no choice as to the pension product or
provider.’;
EN
L 173/476
Official Journal of the European Union
12.6.2014

<!-- source-page: 129 -->

(2) the following chapter is inserted:
‘CHAPTER IIIA
Additional customer protection requirements in relation to insurance-Based investment products
Article 13a
Scope
Subject to the exception in the second subparagraph of Article 2(3), this Chapter lays down additional requirements
on insurance mediation activities and to direct sales carried out by insurance undertakings when they are carried out
in relation to the sale of insurance-based investment products. Those activities shall be referred to as insurance
distribution activities.
Article 13b
Prevention of conflicts of interest
An insurance intermediary or insurance undertaking shall maintain and operate effective organisational and adminis­
trative arrangements with a view to taking all reasonable steps designed to prevent conflicts of interest, as determined
in Article 13c, from adversely affecting the interests of its customers.
Article 13c
Conflicts of interests
1.
Member States shall require insurance intermediaries and insurance undertakings to take all appropriate steps to
identify conflicts of interest between themselves, including their managers, employees and tied insurance intermedi­
aries, or any person directly or indirectly linked to them by control and their customers or between one customer and
another that arise in the course of carrying out any insurance distribution activities.
2.
Where organisational or administrative arrangements made by the insurance intermediary or insurance under­
taking in accordance with Article 13b to manage conflicts of interest are not sufficient to ensure, with reasonable
confidence, that risks of damage to customer interests will be prevented, the insurance intermediary or insurance
undertaking shall clearly disclose to the customer the general nature and/or sources of conflicts of interest before
undertaking business on its behalf.
3.
The Commission shall be empowered to adopt delegated acts in accordance with Article 13e to:
(a) define the steps that insurance intermediaries or insurance undertakings might reasonably be expected to take to
identify, prevent, manage and disclose conflicts of interest when carrying out insurance distribution activities;
(b) establish appropriate criteria for determining the types of conflict of interest whose existence may damage the
interests of the customers or potential customers of the insurance intermediary or insurance undertaking.
Article 13d
General principles and information to customers
1.
Member States shall ensure that, when carrying out insurance distribution activities, an insurance intermediary
or insurance undertaking acts honestly, fairly and professionally in accordance with the best interests of its customers.
2.
All information, including marketing communications, addressed by the insurance intermediary or insurance
undertaking to customers or potential customers shall be fair, clear and not misleading. Marketing communications
shall be clearly identifiable as such.
EN
12.6.2014
Official Journal of the European Union
L 173/477

<!-- source-page: 130 -->

3.
Member States may prohibit the acceptance or receipt of fees, commissions or any monetary benefits paid or
provided to insurance intermediaries or insurance undertakings, by any third party or a person acting on behalf of a
third party in relation to the distribution of insurance-based investment products to customers.
Article 13e
Exercise of the delegation
1.
The power to adopt a delegated act is conferred on the Commission subject to the conditions laid down in this
Article.
2.
The power to adopt a delegated act referred to in Article 13c shall be conferred on the Commission for an
indeterminate period of time from 2 July 2014.
3.
The delegation of powers referred to in Article 13c may be revoked at any time by the European Parliament or
by the Council. A decision of revocation shall put an end to the delegation of the power specified in that decision. It
shall take effect the day following the publication of the decision in the Official Journal of the European Union or at a
later date specified therein. It shall not affect the validity of any delegated acts already in force.
4.
As soon as it adopts a delegated act, the Commission shall notify it simultaneously to the European Parliament
and to the Council.
5.
A delegated act adopted pursuant to Article 13c shall enter into force only if no objection has been expressed
either by the European Parliament or the Council within a period of three months of notification of that act to the
European Parliament and the Council or if, before the expiry of that period, the European Parliament and the Council
have both informed the Commission that they will not object. That period shall be extended by three months at the
initiative of the European Parliament or the Council.’.
Article 92
Amendments to Directive 2011/61/EU
Directive 2011/61/EU is amended as follows:
(1) in point (r) of Article 4(1), the following point is added:
‘(vii) a Member State, other than the home Member State, in which an EU AIFM provides the services referred to in
Article 6(4);’;
(2) Article 33 is amended as follows:
(a) the title is replaced by the following:
‘Conditions for managing EU AIFs established in other Member States and for providing services in other Member
States’;
(b) paragraphs 1 and 2 are replaced by the following:
‘1.
Member States shall ensure that an authorised EU AIFM may, directly or by establishing a branch:
(a) manage EU AIFs established in another Member State, provided that the AIFM is authorised to manage that
type of AIF;
(b) provide in another Member State the services referred to in Article 6(4) for which it has been authorised.
EN
L 173/478
Official Journal of the European Union
12.6.2014

<!-- source-page: 131 -->

2.
An AIFM intending to provide the activities and services referred to in paragraph 1 for the first time shall
communicate the following information to the competent authorities of its home Member State:
(a) the Member State in which it intends to manage AIFs directly or to establish a branch, and/or to provide the
services referred to in Article 6(4);
(b) a programme of operations stating in particular the services which it intends to perform and/or identifying the
AIFs that it intends to manage.’.
Article 93
Transposition
1.
Member States shall adopt and publish, by 3 July 2016, the laws, regulations and administrative provisions
necessary to comply with this Directive. They shall forthwith communicate to the Commission the text of those
measures.
Members States shall apply those measures from 3 January 2017 except for the provisions transposing Article 65(2)
which shall apply from 3 September 2018.
When Member States adopt those measures, they shall contain a reference to this Directive or be accompanied by such a
reference on the occasion of their official publication. Member States shall determine how such reference is to be made.
They shall also include a statement that references in existing laws, regulations and administrative provisions to the
directives repealed by this Directive shall be construed as references to this Directive. Member States shall determine how
such reference is to be made and how that statement is to be formulated.
2.
Member States shall apply the measures referred to in Article 92 from 3 July 2015.
3.
Member States shall communicate to the Commission and to ESMA the text of the main provisions of national law
which they adopt in the field covered by this Directive.
Article 94
Repeal
Directive 2004/39/EC, as amended by the acts listed in Annex III, Part A of this Directive, is repealed with effect from
3 January 2017, without prejudice to the obligations of the Member States relating to the time-limits for transposition
into national law of the Directives set out in Annex III, Part B of this Directive.
References to Directive 2004/39/EC or to Directive 93/22/EEC shall be construed as references to this Directive or to
Regulation (EU) No 600/2014 and shall be read in accordance with the correlation table set out in Annex IV of this
Directive.
References to terms defined in, or Articles of, Directive 2004/39/EC or Directive 93/22/EEC shall be construed as
references to the equivalent term defined in, or Article of, this Directive.
Article 95
Transitional provisions
1.
Until 3 July 2020:
(a) the clearing obligation set out in Article 4 of Regulation (EU) No 648/2012 and the risk mitigation techniques set out
in Article 11(3) thereof shall not apply to C6 energy derivative contracts entered into by non-financial counterparties
that meet the conditions in Article 10(1) of Regulation (EU) No 648/2012 or by non-financial counterparties that
shall be authorised for the first time as investment firms as from 3 January 2017; and
EN
12.6.2014
Official Journal of the European Union
L 173/479

<!-- source-page: 132 -->

(b) such C6 energy derivative contracts shall not be considered to be OTC derivative contracts for the purposes of the
clearing threshold set out in Article 10 of Regulation (EU) No 648/2012.
C6 energy derivative contracts benefiting from the transitional regime set out in the first subparagraph shall be subject to
all other requirements laid down in Regulation (EU) No 648/2012.
2.
The exemption referred to in paragraph 1 shall be granted by the relevant competent authority. The competent
authority shall notify ESMA of the C6 energy derivative contracts which have been granted an exemption in accordance
with paragraph 1 and ESMA shall publish on its website a list of those C6 energy derivative contracts.
Article 96
Entry into force
This Directive shall enter into force on the twentieth day following that of its publication in the Official Journal of the
European Union.
Article 97
Addressees
This Directive is addressed to the Member States.
Done at Brussels, 15 May 2014.
For the European Parliament
The President
M. SCHULZ
For the Council
The President
D. KOURKOULAS
EN
L 173/480
Official Journal of the European Union
12.6.2014

<!-- source-page: 133 -->

ANNEX I
LISTS OF SERVICES AND ACTIVITIES AND FINANCIAL INSTRUMENTS
SECTION A
Investment services and activities
(1) Reception and transmission of orders in relation to one or more financial instruments;
(2) Execution of orders on behalf of clients;
(3) Dealing on own account;
(4) Portfolio management;
(5) Investment advice;
(6) Underwriting of financial instruments and/or placing of financial instruments on a firm commitment basis;
(7) Placing of financial instruments without a firm commitment basis;
(8) Operation of an MTF;
(9) Operation of an OTF.
SECTION B
Ancillary services
(1) Safekeeping and administration of financial instruments for the account of clients, including custodianship and related
services such as cash/collateral management and excluding maintaining securities accounts at the top tier level;
(2) Granting credits or loans to an investor to allow him to carry out a transaction in one or more financial instruments,
where the firm granting the credit or loan is involved in the transaction;
(3) Advice to undertakings on capital structure, industrial strategy and related matters and advice and services relating to
mergers and the purchase of undertakings;
(4) Foreign exchange services where these are connected to the provision of investment services;
(5) Investment research and financial analysis or other forms of general recommendation relating to transactions in
financial instruments;
(6) Services related to underwriting.
(7) Investment services and activities as well as ancillary services of the type included under Section A or B of Annex 1
related to the underlying of the derivatives included under points (5), (6), (7) and (10) of Section C where these are
connected to the provision of investment or ancillary services.
SECTION C
Financial instruments
(1) Transferable securities;
(2) Money-market instruments;
EN
12.6.2014
Official Journal of the European Union
L 173/481

<!-- source-page: 134 -->

(3) Units in collective investment undertakings;
(4) Options, futures, swaps, forward rate agreements and any other derivative contracts relating to securities, currencies,
interest rates or yields, emission allowances or other derivatives instruments, financial indices or financial measures
which may be settled physically or in cash;
(5) Options, futures, swaps, forwards and any other derivative contracts relating to commodities that must be settled in
cash or may be settled in cash at the option of one of the parties other than by reason of default or other
termination event;
(6) Options, futures, swaps, and any other derivative contract relating to commodities that can be physically settled
provided that they are traded on a regulated market, a MTF, or an OTF, except for wholesale energy products traded
on an OTF that must be physically settled;
(7) Options, futures, swaps, forwards and any other derivative contracts relating to commodities, that can be physically
settled not otherwise mentioned in point 6 of this Section and not being for commercial purposes, which have the
characteristics of other derivative financial instruments;
(8) Derivative instruments for the transfer of credit risk;
(9) Financial contracts for differences;
(10) Options, futures, swaps, forward rate agreements and any other derivative contracts relating to climatic variables,
freight rates or inflation rates or other official economic statistics that must be settled in cash or may be settled in
cash at the option of one of the parties other than by reason of default or other termination event, as well as any
other derivative contracts relating to assets, rights, obligations, indices and measures not otherwise mentioned in this
Section, which have the characteristics of other derivative financial instruments, having regard to whether, inter alia,
they are traded on a regulated market, OTF, or an MTF;
(11) Emission allowances consisting of any units recognised for compliance with the requirements of Directive
2003/87/EC (Emissions Trading Scheme).
SECTION D
Data reporting services
(1) Operating an APA;
(2) Operating a CTP;
(3) Operating an ARM.
EN
L 173/482
Official Journal of the European Union
12.6.2014

<!-- source-page: 135 -->

ANNEX II
PROFESSIONAL CLIENTS FOR THE PURPOSE OF THIS DIRECTIVE
Professional client is a client who possesses the experience, knowledge and expertise to make its own investment
decisions and properly assess the risks that it incurs. In order to be considered to be professional client, the client
must comply with the following criteria:
I.
CATEGORIES OF CLIENT WHO ARE CONSIDERED TO BE PROFESSIONALS
The following shall all be regarded as professionals in all investment services and activities and financial instruments for
the purposes of the Directive.
(1) Entities which are required to be authorised or regulated to operate in the financial markets. The list below shall be
understood as including all authorised entities carrying out the characteristic activities of the entities mentioned:
entities authorised by a Member State under a Directive, entities authorised or regulated by a Member State without
reference to a Directive, and entities authorised or regulated by a third country:
(a) Credit institutions;
(b) Investment firms;
(c) Other authorised or regulated financial institutions;
(d) Insurance companies;
(e) Collective investment schemes and management companies of such schemes;
(f) Pension funds and management companies of such funds;
(g) Commodity and commodity derivatives dealers;
(h) Locals;
(i) Other institutional investors;
(2) Large undertakings meeting two of the following size requirements on a company basis:
— balance sheet total: EUR 20 000 000
— net turnover: EUR 40 000 000
— own funds: EUR 2 000 000
(3) National and regional governments, including public bodies that manage public debt at national or regional level,
Central Banks, international and supranational institutions such as the World Bank, the IMF, the ECB, the EIB and
other similar international organisations.
(4) Other institutional investors whose main activity is to invest in financial instruments, including entities dedicated to
the securitisation of assets or other financing transactions.
EN
12.6.2014
Official Journal of the European Union
L 173/483

<!-- source-page: 136 -->

The entities referred to above are considered to be professionals. They must however be allowed to request non-
professional treatment and investment firms may agree to provide a higher level of protection. Where the client of an
investment firm is an undertaking referred to above, the investment firm must inform it prior to any provision of
services that, on the basis of the information available to the investment firm, the client is deemed to be a
professional client, and will be treated as such unless the investment firm and the client agree otherwise. The
investment firm must also inform the customer that he can request a variation of the terms of the agreement in
order to secure a higher degree of protection.
It is the responsibility of the client, considered to be a professional client, to ask for a higher level of protection when
it deems it is unable to properly assess or manage the risks involved.
This higher level of protection will be provided when a client who is considered to be a professional enters into a
written agreement with the investment firm to the effect that it shall not be treated as a professional for the purposes
of the applicable conduct of business regime. Such agreement shall specify whether this applies to one or more
particular services or transactions, or to one or more types of product or transaction.
II.
CLIENTS WHO MAY BE TREATED AS PROFESSIONALS ON REQUEST
II.1. Identification criteria
Clients other than those mentioned in section I, including public sector bodies, local public authorities, municipalities and
private individual investors, may also be allowed to waive some of the protections afforded by the conduct of business
rules.
Investment firms shall therefore be allowed to treat any of those clients as professionals provided the relevant criteria and
procedure mentioned below are fulfilled. Those clients shall not, however, be presumed to possess market knowledge and
experience comparable to that of the categories listed in Section I.
Any such waiver of the protection afforded by the standard conduct of business regime shall be considered to be valid
only if an adequate assessment of the expertise, experience and knowledge of the client, undertaken by the investment
firm, gives reasonable assurance, in light of the nature of the transactions or services envisaged, that the client is capable
of making investment decisions and understanding the risks involved.
The fitness test applied to managers and directors of entities licensed under Directives in the financial field could be
regarded as an example of the assessment of expertise and knowledge. In the case of small entities, the person subject to
that assessment shall be the person authorised to carry out transactions on behalf of the entity.
In the course of that assessment, as a minimum, two of the following criteria shall be satisfied:
— the client has carried out transactions, in significant size, on the relevant market at an average frequency of 10 per
quarter over the previous four quarters,
— the size of the client’s financial instrument portfolio, defined as including cash deposits and financial instruments
exceeds EUR 500 000,
— the client works or has worked in the financial sector for at least one year in a professional position, which requires
knowledge of the transactions or services envisaged.
Member States may adopt specific criteria for the assessment of the expertise and knowledge of municipalities and local
public authorities requesting to be treated as professional clients. Those criteria can be alternative or additional to those
listed in the fifth paragraph.
EN
L 173/484
Official Journal of the European Union
12.6.2014

<!-- source-page: 137 -->

II.2. Procedure
Those clients may waive the benefit of the detailed rules of conduct only where the following procedure is followed:
— they must state in writing to the investment firm that they wish to be treated as a professional client, either generally
or in respect of a particular investment service or transaction, or type of transaction or product,
— the investment firm must give them a clear written warning of the protections and investor compensation rights they
may lose,
— they must state in writing, in a separate document from the contract, that they are aware of the consequences of
losing such protections.
Before deciding to accept any request for waiver, investment firms must be required to take all reasonable steps to ensure
that the client requesting to be treated as a professional client meets the relevant requirements stated in Section II.1.
However, if clients have already been categorised as professionals under parameters and procedures similar to those
referred to above, it is not intended that their relationships with investment firms shall be affected by any new rules
adopted pursuant to this Annex.
Firms must implement appropriate written internal policies and procedures to categorise clients. Professional clients are
responsible for keeping the investment firm informed about any change, which could affect their current categorisation.
Should the investment firm become aware however that the client no longer fulfils the initial conditions, which made him
eligible for a professional treatment, the investment firm shall take appropriate action.
EN
12.6.2014
Official Journal of the European Union
L 173/485

<!-- source-page: 138 -->

ANNEX III
PART A
Repealed Directive with list of its successive amendments
(referred to in Article 94)
Directive 2004/39/EC of the European Parliament and of the Council (OJ L 145, 30.4.2004, p. 1).
Directive 2006/31/EC of the European Parliament and of the Council (OJ L 114, 27.4.2006, p. 60).
Directive 2007/44/EC of the European Parliament and of the Council (OJ L 247, 21.9.2007, p. 1).
Directive 2008/10/EC of the European Parliament and of the Council (OJ L 76, 19.3.2008, p. 33).
Directive 2010/78/EC of the European Parliament and of the Council (OJ L 331, 15.12.2010, p. 120).
PART B
List of time-limits for transposition into national law
(referred to in Article 94)
Directive 2004/39/EC
Transposition period
31 January 2007
Implementation period
1 November 2007
Directive 2006/31/EC
Transposition period
31 January 2007
Implementation period
1 November 2007
Directive 2007/44/EC
Transposition period
21 March 2009
Directive 2010/78/EC
Transposition period
31 December 2011
EN
L 173/486
Official Journal of the European Union
12.6.2014

<!-- source-page: 139 -->

ANNEX IV
Correlation table referred in Article 94
Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 1(1)
Article 1(1)
Article 1(2)
Article 1(3)
Article 2(1)(a)
Article 2(1)(a)
Article 2(1)(b)
Article 2(1)(b)
Article 2(1)(c)
Article 2(1)(c)
Article 2(1)(d)
Article 2(1)(d)
Article 2(1)(e)
Article 2(1)(f)
Article 2(1)(f)
Article 2(1)(g)
Article 2(1)(g)
Article 2(1)(h)
Article 2(1)(h)
Article 2(1)(i)
Article 2(1)(i)
Article 2(1)(j)
Article 2(1)(j)
Article 2(1)(k)
Article 2(1)(k)
Article 2(1)(i)
Article 2(1)(l)
—
Article 2(1)(m)
Article 2(1)(l)
Article 2(1)(n)
Article 2(1)(m)
Article 2(2)
Article 2(2)
Article 2(3)
Article 2(4)
Article 3(1)
Article 3(1)
Article 3(2)
Article 3(3)
Article 4(1)(1)
Article 4(1)(1)
Article 4(1)(2)
Article 4(1)(2)
Article 4(1)(3)
Article 4(1)(3)
Article 4(1)(4)
Article 4(1)(4)
Article 4(1)(5)
Article 4(1)(5)
Article 4(1)(6)
Article 4(1)(6)
Article 4(1)(7)
Article 4(1)(20)
Article 4(1)(8)
Article 4(1)(7)
Article 4(1)(9)
Article 4(1)(8)
EN
12.6.2014
Official Journal of the European Union
L 173/487

<!-- source-page: 140 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 4(1)(10)
Article 4(1)(9)
Article 4(1)(11)
Article 4(1)(10)
Article 4(1)(12)
Article 4(1)(11)
Article 4(1)(13)
Article 4(1)(18)
Article 4(1)(14)
Article 4(1)(21)
Article 4(1)(15)
Article 4(1)(22)
Article 4(1)(16)
Article 4(1)(14)
Article 4(1)(17)
Article 4(1)(15)
Article 4(1)(18)
Article 4(1)(44)
Article 4(1)(19)
Article 4(1)(17)
Article 4(1)(20)
Article 4(1)(55)
Article 4(1)(21)
Article 4(1)(56)
Article 4(1)(22)
Article 4(1)(26)
Article 4(1)(23)
Article 4(1)(27)
Article 4(1)(24)
Article 4(1)(28)
Article 4(1)(25)
Article 4(1)(29)
Article 4(1)(26)
Article 4(1)(30)
Article 4(1)(27)
Article 4(1)(31)
Article 4(1)(28)
Article 4(1)(32)
Article 4(1)(29)
Article 4(1)(33)
Article 4(1)(30)
Article 4(1)(35)(b)
Article 4(1)(31)
Article 4(1)(35)
Article 4(2)
Article 4(2)
Article 5(1)
Article 5(1)
Article 5(2)
Article 5(2)
Article 5(3)
Article 5(3)
Article 5(4)
Article 5(4)
Article 5(5)
—
Article 6(1)
Article 6(1)
Article 6(2)
Article 6(2)
Article 6(3)
Article 6(3)
Article 7(1)
Article 7(1)
EN
L 173/488
Official Journal of the European Union
12.6.2014

<!-- source-page: 141 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 7(2)
Article 7(2)
Article 7(3)
Article 7(3)
Article 7(4)
Article 7(4) and (5)
Article 8(a)
Article 8(a)
Article 8(b)
Article 8(b)
Article 8(c)
Article 8(c)
Article 8(d)
Article 8(d)
Article 8(e)
Article 8(e)
Article 9(1)
Article 9(1) and (3)
Article 9(2)
Article 9(5)
Article 9(3)
Article 9(4)
Article 9(4)
Article 9(6)
Article 10(1)
Article 10(1)
Article 10(2)
Article 10(2)
Article 10(3)
Article 11(1)
Article 10(4)
Article 11(2)
Article 10(5)
Article 11(3)
Article 10(6)
Article 10(3), 11(4)
Article 10a(1)
Article 12(1)
Article 10a(2)
Article 12(2)
Article 10a(3)
Article 12(3)
Article 10a(4)
Article 12(4)
Article 10a(5)
Article 12(5)
Article 10a(6)
Article 12(6)
Article 10a(7)
Article 12(7)
Article 10a(8)
Article 12(8) and (9)
Article 10b(1)
Article 13(1)
Article 10b(2)
Article 13(2)
Article 10b(3)
Article 13(3)
Article 10b(4)
Article 13(4)
Article 10b(5)
Article 13(5)
Article 11
Article 14
EN
12.6.2014
Official Journal of the European Union
L 173/489

<!-- source-page: 142 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 12
Article 15
Article 13(1)
Article 16(1)
Article 13(2)
Article 16(2)
Article 13(3)
Article 16(3)
Article 13(4)
Article 16(4)
Article 13(5)
Article 16(5)
Article 13(6)
Article 16(6)
Article 13(7)
Article 16(8)
Article 13(8)
Article 16(9)
Article 13(9)
Article 16(11)
Article 13(10)
Article 16(12)
Article 14(1)
Article 18(1), Article 19(1)
Article 14(2)
Article 18(2)
Article 14(3)
Article 19(4)
Article 14(4)
Article 18(3), Article 19(2)
Article 14(5)
Article 18(6), Article 19(3)
Article 14(6)
Article 18(8)
Article 14(7)
Article 18(9)
Article 15
—
Article 16(1)
Article 21(1)
Article 16(2)
Article 21(2)
Article 16(3)
—
Article 17(1)
Article 22
Article 17(2)
—
Article 18(1)
Article 23(1)
Article 18(2)
Article 23(2)
Article 18(3)
Article 23(4)
Article 19(1)
Article 24(1)
Article 19(2)
Article 24(3)
Article 19(3)
Article 24(4)
Article 19(4)
Article 25(2)
Article 19(5)
Article 25(3)
EN
L 173/490
Official Journal of the European Union
12.6.2014

<!-- source-page: 143 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 19(6)
Article 25(4)
Article 19(7)
Article 25(5)
Article 19(8)
Article 25(6)
Article 19(9)
Article 24(6), Article 25(7)
Article 19(10)
Article 24(13), Article 24(14),
Article 25(8)
Article 20
Article 26
Article 21(1)
Article 27(1)
Article 21(2)
Article 27(4)
Article 21(3)
Article 27(5)
Article 21(4)
Article 27(7)
Article 21(5)
Article 27(8)
Article 21(6)
Article 27(9)
Article 22(1)
Article 28(1)
Article 22(2)
Article 28(2)
Article 22(3)
Article 28(3)
Article 23(1)
Article 29(1)
Article 23(2)
Article 29(2)
Article 23(3)
Article 29(3)
Article 23(4)
Article 29(4)
Article 23(5)
Article 29(5)
Article 23(6)
Article 29(6)
Article 24(1)
Article 30(1)
Article 24(2)
Article 30(2)
Article 24(3)
Article 30(3)
Article 24(4)
Article 30(4)
Article 24(5)
Article 30(5)
Article 25(1)
Article 24
Article 25(2)
Article 25(1)
Article 25(3)
Article 26(1) and (2)
Article 25(4)
Article 26(3)
Article 25(5)
Article 26(7)
Article 25(6)
Article 26(8)
EN
12.6.2014
Official Journal of the European Union
L 173/491

<!-- source-page: 144 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 25(7)
Article 26(9)
Article 26(1)
Article 31(1)
Article 26(2)
Article 31(2) and (3)
Article 27(1)
Article 14(1) to (5)
Article 27(2)
Article 14(6)
Article 27(3)
Article 15(1) to (4)
Article 27(4)
Article 16
Article 27(5)
Article 17(1)
Article 27(6)
Article 17(2)
Article 27(7)
Article 17(3)
Article 28(1)
Article 20(1)
Article 28(2)
Article 20(2)
Article 28(3)
Article 20(3)
Article 29(1)
Article 3(1), (2) and (3)
Article 29(2)
Article 4(1), (2) and (3)
Article 29(3)
Article 4(6)
Article 30(1)
Article 6(1) and (2)
Article 30(2)
Article 7(1)
Article 30(3)
Article 7(2)
Article 31(1)
Article 34(1)
Article 31(2)
Article 34(2)
Article 31(3)
Article 34(3)
Article 31(4)
Article 34(4)
Article 31(5)
Article 34(6)
Article 31(6)
Article 34(7)
Article 31(7)
Article 34(8) and (9)
Article 32(1)
Article 35(1)
Article 32(2)
Article 35(2)
Article 32(3)
Article 35(3)
Article 32(4)
Article 35(4)
Article 32(5)
Article 35(5)
Article 32(6)
Article 35(6)
EN
L 173/492
Official Journal of the European Union
12.6.2014

<!-- source-page: 145 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 32(7)
Article 35(8)
Article 32(8)
Article 35(9)
Article 32(9)
Article 35(10)
Article 32(10)
Article 35(11) and (12)
Article 33(1)
Article 36(1)
Article 33(2)
Article 36(2)
Article 34(1)
Article 37(1)
Article 34(2)
Article 37(2)
Article 34(3)
—
Article 35(1)
Article 38(1)
Article 35(2)
Article 38(2)
Article 36(1)
Article 44(1)
Article 36(2)
Article 44(2)
Article 36(3)
Article 44(3)
Article 36(4)
Article 44(4)
Article 36(5)
Article 44(5)
Article 36(6)
Article 44(6)
Article 37(1)
Article 45(1) and (8)
Article 37(2)
Article 45(7) second subparagraph
Article 38(1)
Article 46(1)
Article 38(2)
Article 46(2)
Article 38(3)
Article 46(3)
Article 39
Article 47(1)
Article 40(1)
Article 51(1)
Article 40(2)
Article 51(2)
Article 40(3)
Article 51(3)
Article 40(4)
Article 51(4)
Article 40(5)
Article 51(5)
Article 40(6)
Article 51(6)
Article 41(1)
Article 52(1)
Article 41(2)
Article 52(2)
Article 42(1)
Article 53(1)
EN
12.6.2014
Official Journal of the European Union
L 173/493

<!-- source-page: 146 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 42(2)
Article 53(2)
Article 42(3)
Article 53(3)
Article 42(4)
Article 53(4)
Article 42(5)
Article 53(5)
Article 42(6)
Article 53(6)
Article 42(7)
Article 53(7)
Article 43(1)
Article 54(1)
Article 43(2)
Article 54(2) and (3)
Article 44(1)
Article 3(1), (2) and (3)
Article 44(2)
Article 4(1), (2) and (3)
Article 44(3)
Article 4(6)
Article 45(1)
Article 6(1) and (2)
Article 45(2)
Article 7(1)
Article 45(3)
Article 7(2)
Article 46(1)
Article 55(1)
Article 46(2)
Article 55(2)
Article 47
Article 56
Article 48(1)
Article 67(1)
Article 48(2)
Article 67(2)
Article 48(3)
Article 67(3)
Article 49
Article 68
Article 50(1)
Article 69(1), 72(1)
Article 50(2)
Article 69(2)
Article 51(1)
Article 70(1) and (2)
Article 51(2)
Article 70(5)
Article 51(3)
Article 71(1)
Article 51(4)
Article 71(4)
Article 51(5)
Article 71(5)
Article 51(6)
Article 71(6)
Article 52(1)
Article 74(1)
Article 52(2)
Article 74(2)
Article 53(1)
Article 75(1)
EN
L 173/494
Official Journal of the European Union
12.6.2014

<!-- source-page: 147 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 53(2)
Article 75(2)
Article 53(3)
Article 75(3)
Article 54(1)
Article 76(1)
Article 54(2)
Article 76(2)
Article 54(3)
Article 76(3)
Article 54(4)
Article 76(4)
Article 54(5)
Article 76(5)
Article 55(1)
Article 77(1)
Article 55(2)
Article 77(2)
Article 56(1)
Article 79(1)
Article 56(2)
Article 79(2)
Article 56(3)
Article 79(3)
Article 56(4)
Article 79(4)
Article 56(5)
Article 79(8)
Article 56(6)
Article 79(9)
Article 57(1)
Article 80(1)
Article 57(2)
Article 80(2)
Article 57(3)
Article 80(3) and (4)
Article 58(1)
Article 81(1)
Article 58(2)
Article 81(2)
Article 58(3)
Article 81(3)
Article 58(4)
Article 81(4)
Article 58(5)
Article 81(5)
Article 58a
Article 82
Article 59
Article 83
Article 60(1)
Article 84(1)
Article 60(2)
Article 84(2)
Article 60(3)
Article 84(3)
Article 60(4)
Article 84(4)
Article 61(1)
Article 85(1)
Article 61(2)
Article 85(2)
Article 62(1)
Article 86(1)
EN
12.6.2014
Official Journal of the European Union
L 173/495

<!-- source-page: 148 -->

Directive 2004/39/EC
Directive 2014/65/EU
Regulation (EU) No 600/2014
Article 62(2)
Article 86(2)
Article 62(3)
Article 86(3)
Article 62(4)
Article 86(4)
Article 62a(1)
Article 87(1)
Article 62a(2)
Article 87(2)
Article 63(1)
Article 88(1)
Article 63(2)
Article 88(2)
Article 64
—
—
Article 64a
—
—
Article 65
—
—
Article 66
—
—
Article 67
—
—
Article 68
—
—
Article 69
—
—
Article 70
—
—
Article 71
—
—
Article 72
—
—
Article 73
—
—
Annex I
Annex I
Annex II
Annex II
EN
L 173/496
Official Journal of the European Union
12.6.2014
