#!/usr/bin/env python3
"""Trade Collections - Maker Workbench
Demo launcher.

Run it with:

    python run_demo.py            (serves on port 8000)
    python run_demo.py 8080       (or any other port)

What this does, in order:
  1. Makes sure a local virtual environment exists (./.venv), creating one
     the first time this is run.
  2. Installs the handful of packages the app needs, if they are not already
     there (see requirements.txt).
  3. Starts the server and opens your browser to it.

No cloud credentials, API keys or network access are required to run the
demo itself. Every pricing figure the pricing agent would otherwise compute
live is already committed in app/data/pricing_cache.json, produced ahead of
time by a real run of the agent — so this machine answers every case with
the same reasoning and figures without ever calling out to a model provider.

Press Ctrl+C to stop the server once it is running.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
REQUIREMENTS = ROOT / "requirements.txt"


def _banner() -> None:
    print()
    print("  Trade Collections - Maker Workbench")
    print("  ===================================")
    print()


def _venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def _find_system_python() -> str:
    """A Python 3.10+ interpreter to build the venv with.

    sys.executable — this script's own interpreter — already satisfies the
    version requirement by construction, so it is tried first; the others
    are a fallback for the (rare) case this file is run with something odd.
    """
    candidates = [sys.executable, "python3", "python", "py"]
    seen = set()
    for exe in candidates:
        if not exe or exe in seen:
            continue
        seen.add(exe)
        try:
            out = subprocess.run(
                [exe, "-c", "import sys; print('%d.%d' % sys.version_info[:2])"],
                capture_output=True, text=True, timeout=10)
        except (OSError, subprocess.SubprocessError):
            continue
        if out.returncode != 0:
            continue
        try:
            major, minor = (int(p) for p in out.stdout.strip().split("."))
        except ValueError:
            continue
        if (major, minor) >= (3, 10):
            return exe
    print("  No usable Python 3.10+ was found.")
    print()
    print("  Install Python from https://www.python.org/downloads/")
    print("  and make sure it is on PATH, then run this again.")
    sys.exit(1)


def _ensure_venv() -> Path:
    vpy = _venv_python()
    if vpy.exists():
        return vpy
    print("  Setting up a local environment. This happens once and takes a minute.")
    system_py = _find_system_python()
    result = subprocess.run([system_py, "-m", "venv", str(VENV)])
    if result.returncode != 0 or not vpy.exists():
        print()
        print("  Could not create the virtual environment. Try running:")
        print(f"      {system_py} -m venv .venv")
        sys.exit(1)
    return vpy


def _ensure_deps(vpy: Path) -> None:
    check = subprocess.run(
        [str(vpy), "-c", "import fastapi, uvicorn, jinja2, pydantic"],
        capture_output=True)
    if check.returncode == 0:
        return
    print("  Installing dependencies...")
    subprocess.run([str(vpy), "-m", "pip", "install", "--upgrade", "pip",
                    "--quiet", "--disable-pip-version-check"])
    result = subprocess.run(
        [str(vpy), "-m", "pip", "install", "-r", str(REQUIREMENTS),
         "--quiet", "--disable-pip-version-check"])
    if result.returncode != 0:
        print()
        print("  Could not install the dependencies. Check the internet")
        print("  connection, or run this by hand to see the error:")
        print()
        print(f'      "{vpy}" -m pip install -r requirements.txt')
        sys.exit(1)


def _port_in_use(port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _wait_and_open_browser(port: int) -> None:
    url = f"http://127.0.0.1:{port}/?v=corp"
    for _ in range(40):
        time.sleep(1)
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=1)
        except Exception:
            continue
        webbrowser.open(url)
        return


def main() -> int:
    os.chdir(ROOT)
    _banner()

    port = 8000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print(f"  Not a port number: {sys.argv[1]!r}")
            return 1

    if _port_in_use(port):
        print(f"  Port {port} is already in use - the demo may already be running.")
        print()
        print(f"  Open  http://127.0.0.1:{port}/   or pick another port:")
        print()
        print(f"      python run_demo.py 8080")
        return 1

    vpy = _ensure_venv()
    print(f"  Python environment ready ({vpy})")
    _ensure_deps(vpy)
    print("  Ready.")
    print()
    print(f"  Running at http://127.0.0.1:{port}/")
    print()
    print("    ?v=corp    corporate view  - Material 3, follows the project deck")
    print("    ?v=desk    desk view       - the collections-desk alternative")
    print()
    print("  Pricing is answered from the committed cache in")
    print("  app/data/pricing_cache.json — no cloud credentials needed.")
    print()
    print("  Press Ctrl+C to stop.")
    print()

    threading.Thread(target=_wait_and_open_browser, args=(port,), daemon=True).start()

    try:
        subprocess.run([str(vpy), "-m", "uvicorn", "app.main:app",
                        "--host", "127.0.0.1", "--port", str(port)])
    except KeyboardInterrupt:
        pass
    print()
    print("  Server stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
