# Pull Request Description: `walkthrough-query-agent`

## Summary
Updates `walkthrough-query-agent` to manage soft include/exclude mutations across all Preliminary Research scoping sources (including `gfms`, `historical_scoping_document`, and `lrr`), read/write structured metadata in `review_data_extraction`, avoid hard-deleting GCS blobs, and return `affected_sections` for partial Preliminary Research regeneration.

## What Changed
- **Full Scoping Source & LRR Mandate Support**
  - `src/main/service/database_connector.py` & `src/main/service/document_service_helpers.py`: Added `"lrr"` alongside `policy`, `kod`, `procedure`, `gfms`, and `historical_scoping_document` across `SCOPING_SOURCES`, `SOURCE_ALIASES`, `REGISTRY_FILES`, and `mutate_data_extraction_metadata`.
  - `src/main/service/database_connector.py`: Added `compute_affected_preliminary_research_sections(...)` mapping mutated source types to affected Preliminary Research sections (`policy_regulation`, `findings_analysis`, `historical_plan`, `broad_scope`).
- **Soft-Exclude / Include Without Deleting GCS Blobs**
  - `src/main/service/document_service.py`:
    - `list_all_documents` now covers all 5 sources (`policy`, `kod`, `procedure`, `gfms`, `historical_scoping_document`).
    - `_list_from_gcs` / `_read_db_documents_for_type` reads document and `sections[]` metadata (`storage_uri`, `status`, `excluded`) from `review_data_extraction` first, with safe GCS fallback.
    - `delete_documents` / `delete_documents_bulk` / `_delete_from_gcs` performs soft-exclusion or restoration (`action: "exclude" | "include"`) at document or section level (`_soft_mark_json_payload` + `mutate_data_extraction_metadata`) without calling `blob.delete()`.
    - `_upload_to_gcs` syncs uploaded files and extracted sections into `review_data_extraction`.
- **Orchestrators, Chat Workflow & API Schemas**
  - `src/main/service/request.py`: Added `storage_uri`, `status`, `excluded`, `sections` on `DocumentMetadata`, section/action fields on `DocumentDeleteItemDetail`, and `affected_sections` on delete/exclusion/inclusion/workflow response models.
  - `src/main/service/document_exclusion_orchestrator.py`, `document_inclusion_orchestrator.py`, and `document_chat_workflow.py`: Added `"lrr"` extraction/verification/execution support, DB metadata sync on upload/inclusion, deterministic `@` mention parsing (`_extract_mentions_from_clause` for `@[Category: Document > Section ID: Title]` and `@Category: Title`) plus updated LLM extraction rules, and `affected_sections` propagation.
  - `src/main/service/router.py`: Forwards `affected_sections` in bulk delete responses, uses `List[UploadFile] = File(default=[])` on `/qna/documents/ingest`, and standardizes on Pydantic v2 `.model_dump()`.
- **Package Version & Vestigial Config Cleanup**
  - `src/main/config/app.yaml`, `src/main/agent_helper/action_service.py`, `src/main/constant/query_constant.py`: Removed vestigial `MODEL_TEMPERATURE`, `MODEL_TOP_P`, `MODEL_TOP_K`, `seed`, and `thinking_budget` config/payload constants.
  - `src/main/agent_helper/agent_card.py`: Replaced deprecated `datetime.utcnow()` with timezone-aware `datetime.now(timezone.utc)`.
  - `src/main/service/document_service.py` & `src/main/service/session_manager.py`: Removed legacy Pydantic v1 `.dict()` fallbacks in favor of Pydantic v2 `.model_dump(mode="json")`.
- **Tests**
  - Updated `src/tests/service/test_router.py`, `src/tests/test_agent_card.py`, `src/tests/agent_helper/test_env_config.py`, and added `src/tests/service/test_preliminary_research_exclusion_and_lrr.py`.

## Why
Enables natural-language and `@`-annotated chat requests as well as UI actions to soft-exclude or restore documents, sections, findings, historical plans, and LRR mandates safely while telling the UI which Preliminary Research sections need regeneration.

## Testing & Coverage
- Command: `PYTHONPATH="src/main;src" pytest src/tests --cov=src/main --cov-report=term-missing --cov-fail-under=80`
- Result: **114 passed, 0 failed** (**80.26% statement coverage**)
