"""Tests for the CT1 Live Demo UI proxy server & resilient CT1 fallbacks."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, List, Tuple

import httpx
import pytest

import server

SAMPLES_PATH = Path(server.__file__).resolve().with_name("CT1_ENDPOINTS_AND_JSON_SAMPLES.json")


class _FakeResponse:
    def __init__(self, status_code: int, payload: Any):
        self.status_code = status_code
        self._payload = payload
        self.text = payload if isinstance(payload, str) else (json.dumps(payload) if payload is not None else "")

    def json(self) -> Any:
        if isinstance(self._payload, str):
            raise ValueError("not json")
        return self._payload


def _load_sample_map() -> dict[str, dict[str, Any]]:
    raw = json.loads(SAMPLES_PATH.read_text(encoding="utf-8"))
    by_artifact: dict[str, dict[str, Any]] = {}
    for call in raw.get("calls") or []:
        url = str(call.get("url") or "")
        if "/getdata/20440/" in url and call.get("status_code") == 200:
            aid = url.rsplit("/", 1)[-1]
            by_artifact[aid] = call["response_json"]
    return by_artifact


class _FakeAsyncClient:
    def __init__(self, recorder: List[Tuple[str, str, Any]], *, query_service_503: bool = True):
        self.recorder = recorder
        self.query_service_503 = query_service_503
        self.samples = _load_sample_map()

    async def __aenter__(self) -> "_FakeAsyncClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def get(self, url: str) -> _FakeResponse:
        self.recorder.append(("GET", url, None))
        for aid, payload in self.samples.items():
            if url.endswith(f"/getdata/20440/{aid}"):
                return _FakeResponse(200, payload)
        if url.endswith("/status"):
            return _FakeResponse(200, {"session_id": "sess-1", "status": "completed"})
        return _FakeResponse(404, {"detail": "Not found"})

    async def post(
        self,
        url: str,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        timeout: Any = None,
    ) -> _FakeResponse:
        self.recorder.append(("POST", url, json or data or files))
        if self.query_service_503 and (
            "/query-service/" in url
            or "/dbaware-api-gateway/" in url
            or "/scoping-master-agent/" in url
        ):
            return _FakeResponse(503, "no healthy upstream")
        if url.endswith("/documents/list-all"):
            return _FakeResponse(
                200,
                {
                    "plan_number": "20440",
                    "document_groups": [
                        {
                            "document_type": "policy",
                            "documents": [{"document_id": "1", "document_title": "Live Policy One"}],
                        }
                    ],
                },
            )
        if url.endswith("/qna/chat"):
            return _FakeResponse(
                200,
                {
                    "answer": "Executed live exclude.",
                    "document_workflow": {
                        "stage": "executed",
                        "actions": [{"action": "exclude", "document_type": "policy", "title": "Live Policy One"}],
                    },
                },
            )
        if url.endswith("/data-extraction"):
            return _FakeResponse(200, {"session_id": "sess-1", "status": "queued"})
        if url.endswith("/documents/ingest"):
            return _FakeResponse(200, {"status": "accepted", "job_id": "job-42", "message": "Queued"})
        return _FakeResponse(404, {"detail": "Unknown POST"})

    async def request(self, method: str, url: str, json: Any = None) -> _FakeResponse:
        if method == "GET":
            return await self.get(url)
        return await self.post(url, json=json)


class _OfflineAsyncClient(_FakeAsyncClient):
    async def get(self, url: str) -> _FakeResponse:
        raise httpx.ConnectError("DNS lookup failed offline")

    async def post(self, url: str, json: Any = None, data: Any = None, files: Any = None, timeout: Any = None) -> _FakeResponse:
        raise httpx.ConnectError("DNS lookup failed offline")


def _asgi_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url="http://testserver")


@pytest.fixture(autouse=True)
def _clear_state():
    server._PLAN_STATE.clear()
    yield
    server._PLAN_STATE.clear()


@pytest.mark.asyncio
async def test_index_and_config():
    async with _asgi_client() as client:
        resp = await client.get("/")
        assert resp.status_code == 200
        assert "Reset Demo" in resp.text

        cfg = await client.get("/api/config")
        assert cfg.status_code == 200
        body = cfg.json()
        assert body["cta_host"] == server.CTA_HOST
        assert len(body["artifacts"]) == 9


@pytest.mark.asyncio
async def test_bootstrap_recovers_from_query_503_with_captured_ct1_samples(monkeypatch):
    calls: List[Tuple[str, str, Any]] = []
    monkeypatch.setattr(server, "create_async_client", lambda: _FakeAsyncClient(calls, query_service_503=True))

    async with _asgi_client() as client:
        resp = await client.get("/api/ct1/plan/20440/bootstrap")
    assert resp.status_code == 200
    payload = resp.json()

    assert payload["query_mode"] == "ct1_artifacts_fallback"
    assert len(payload["artifacts"]["policy"]["data"]["referenced_documents"]) >= 2
    assert payload["artifacts"]["findings_details"]["data"]["findings_details"][0]["responsePayload"][0]["findingId"] == "04147/2026"
    assert payload["artifacts"]["current_details"]["data"]["plan_details"]["Plan Item Number"] == 20440
    assert len(payload["artifacts"]["control_details"]["data"]["control_details"]["included_kcs"]) == 2

    groups = {g["document_type"]: g["documents"] for g in payload["catalog"]["document_groups"]}
    assert "policy" in groups and len(groups["policy"]) >= 2
    assert any(d["document_id"] == "04147/2026" for d in groups["gfms"])


@pytest.mark.asyncio
async def test_exclude_approve_restore_ingest_and_reset_fallback_workflow(monkeypatch):
    calls: List[Tuple[str, str, Any]] = []
    monkeypatch.setattr(server, "create_async_client", lambda: _FakeAsyncClient(calls, query_service_503=True))

    async with _asgi_client() as client:
        # 1. Propose exclusion via @ mention
        prop = await client.post(
            "/api/ct1/query/chat",
            json={
                "question": "Exclude @[Policies: Operational_Risk_Management_Policy]",
                "plan_number": "20440",
            },
        )
        assert prop.status_code == 200
        assert prop.json()["document_workflow"]["stage"] == "awaiting_approval"

        # 2. Approve exclusion
        approved = await client.post(
            "/api/ct1/query/chat",
            json={"question": "approve", "plan_number": "20440"},
        )
        assert approved.status_code == 200
        assert approved.json()["document_workflow"]["stage"] == "executed"

        # Verify policy artifact no longer includes excluded document, while catalog marks it excluded
        pol_after = await client.get("/api/ct1/dataextraction/20440/policy")
        assert pol_after.status_code == 200
        names = [d["document_name"] for d in pol_after.json()["data"]["referenced_documents"]]
        assert "Operational_Risk_Management_Policy" not in names

        # 3. Restore via Include @ mention + approve
        inc_prop = await client.post(
            "/api/ct1/query/chat",
            json={"question": "Include @[Policies: Operational_Risk_Management_Policy]", "plan_number": "20440"},
        )
        assert inc_prop.json()["document_workflow"]["stage"] == "awaiting_approval"
        inc_exec = await client.post(
            "/api/ct1/query/chat",
            json={"question": "approve", "plan_number": "20440"},
        )
        assert inc_exec.json()["document_workflow"]["stage"] == "executed"

        pol_restored = await client.get("/api/ct1/dataextraction/20440/policy")
        restored_names = [d["document_name"] for d in pol_restored.json()["data"]["referenced_documents"]]
        assert "Operational_Risk_Management_Policy" in restored_names

        # 4. General Q&A fallback over active CT1 artifacts
        qa = await client.post(
            "/api/ct1/query/chat",
            json={"question": "Summarize plan risks and findings", "plan_number": "20440"},
        )
        assert qa.status_code == 200
        assert "High-Frequency Trading (GBSA) Review" in qa.json()["answer"]

        # 5. Resilient ingest fallback registers file into active policy artifact
        ing = await client.post(
            "/api/ct1/query/ingest",
            data={"plan_number": "20440", "document_type": "policy"},
            files={"files": ("New_Compliance_Addendum.pdf", b"%PDF-1.4", "application/pdf")},
        )
        assert ing.status_code == 200
        assert ing.json()["status"] == "ingested_fallback"
        pol_uploaded = await client.get("/api/ct1/dataextraction/20440/policy")
        assert any(
            d["document_name"] == "New_Compliance_Addendum"
            for d in pol_uploaded.json()["data"]["referenced_documents"]
        )

        # 6. Reset clears uploaded/excluded overrides
        reset = await client.post("/api/ct1/plan/20440/reset")
        assert reset.status_code == 200 and reset.json()["status"] == "reset"
        pol_reset = await client.get("/api/ct1/dataextraction/20440/policy")
        assert not any(
            d["document_name"] == "New_Compliance_Addendum"
            for d in pol_reset.json()["data"]["referenced_documents"]
        )


@pytest.mark.asyncio
async def test_live_query_service_passthrough_and_offline_sample_fallback(monkeypatch):
    calls: List[Tuple[str, str, Any]] = []
    monkeypatch.setattr(server, "create_async_client", lambda: _FakeAsyncClient(calls, query_service_503=False))

    async with _asgi_client() as client:
        boot = await client.get("/api/ct1/plan/20440/bootstrap")
        assert boot.status_code == 200
        assert boot.json()["query_mode"] == "query_service"

        chat = await client.post("/api/ct1/query/chat", json={"question": "Exclude Live Policy One", "plan_number": "20440"})
        assert chat.status_code == 200
        assert chat.json()["document_workflow"]["stage"] == "executed"

        run_resp = await client.post("/api/ct1/dataextraction/run", json={"planNumber": "20440"})
        assert run_resp.status_code == 200 and run_resp.json()["session_id"] == "sess-1"

        st_resp = await client.get("/api/ct1/dataextraction/status/sess-1")
        assert st_resp.status_code == 200 and st_resp.json()["status"] == "completed"

        ing = await client.post(
            "/api/ct1/query/ingest",
            data={"plan_number": "20440", "document_type": "kod"},
            files={"files": ("doc.json", b'{"document_title":"Custom KOD"}', "application/json")},
        )
        assert ing.status_code == 200 and ing.json()["job_id"] == "job-42"

    # Completely offline DNS -> falls back to CT1_ENDPOINTS_AND_JSON_SAMPLES.json cleanly
    monkeypatch.setattr(server, "create_async_client", lambda: _OfflineAsyncClient(calls))
    async with _asgi_client() as client:
        offline_boot = await client.get("/api/ct1/plan/20440/bootstrap")
    assert offline_boot.status_code == 200
    assert offline_boot.json()["artifacts"]["current_details"]["data"]["plan_details"]["Plan Item Number"] == 20440
