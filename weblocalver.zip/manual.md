# Query Agent: Ingestion, Inclusion and Exclusion

Focused API gateway reference for connecting uploaded source documents to a plan's Preliminary Research and managing their inclusion. Examples use plan `20429`. The local ct1-demo fixture includes `Governance_Policy_1` with section ID `1`, titled `Section 1 of Policy 1`; production titles and IDs must come from the selected plan's live catalog.

The ct1-demo upload screen posts file bytes as browser multipart data to its server proxy, which calls RAG and Query Service directly. This manual maps those processing stages to API gateway actions. For gateway uploads, send each file as base64 in `payload.files[*].content_base64`; the gateway decodes it before building the downstream multipart request.

All calls use the gateway action endpoint:

```http
POST /dbaware-api-gateway/api/v1/actions
Content-Type: application/json
```

Wrap each action in this request shape. The gateway forwards `planNumber` to the downstream service as the action's plan-number field and returns the downstream payload under `response`. Payload field names follow the downstream action schema: Query Agent JSON actions that accept caller context use `user_details`; multipart ingestion accepts its scope fields at the top of `payload`; Preliminary Research generation requires `userDetails`; fetching the report needs no additional payload fields. Use live workflow values and do not hard-code example IDs.

```json
{
  "planNumber": "20429",
  "action": "<ACTION_NAME>",
  "payload": {}
}
```

## 1. Ingestion and inclusion

Uploading a file is the inclusion workflow for a new source. Choose the upload path based on the file format — **the RAG ingestion endpoint only accepts `.pdf` files**.

### Supported file formats and upload paths

| File format | Action / Endpoint | Behavior & requirements |
| :--- | :--- | :--- |
| **`.pdf`** (Policy, KOD, or Procedure) | `QNA_INGEST_DOCUMENTS` (`POST /qna/documents/ingest` → RAG `/ingest-documents`) | Strictly `.pdf` only (`%PDF-` magic header, ≤ 50 MB). RAG validates a hierarchical Table of Contents (`1`, `1.1`, …) within the first 5 pages and a last-page metadata table containing all 16 required fields (including `Category` matching `Policy`, `Key Operating Document` / `KOD`, or `Procedure`). Non-PDF files are rejected with `Filename must end with .pdf`. |
| **`.json`** (pre-structured document/sections) | `QNA_UPLOAD_DOCUMENTS` (`POST /qna/documents/upload`) or `QNA_UPLOAD_FILE` (`POST /qna/upload`) | Skips RAG PDF parsing. Use `QNA_UPLOAD_DOCUMENTS` (JSON body with `documents[]` groups) to write structured documents/sections directly into GCS + `review_data_extraction.metadata`, or `QNA_UPLOAD_FILE` (multipart single `.json` file under field `file`) to upload a raw `.json` file directly to GCS. |
| **`.docx`, `.txt`, `.xlsx`, `.csv`, and other formats** | Direct Query Service: `POST /qna/preliminary-research/additional-context/upload` | Not supported by RAG `/ingest-documents`. Either export/convert Policy/KOD/Procedure files to a valid `.pdf` for `QNA_INGEST_DOCUMENTS`, or upload supplementary files via `/qna/preliminary-research/additional-context/upload` (accepts any format and stores under `inbound-data/additional-context/preliminary-research/` for Preliminary Research regeneration). |

### 1.1 Upload a PDF source (RAG ingestion)

Send each `.pdf` file in `payload.files` (or typed `policy_files`, `kod_files`, `procedure_files` arrays). Set `content_base64` to the file's base64-encoded bytes, and set `content_type` to `"application/pdf"`. The master agent decodes `content_base64` (stripping any optional `data:...;base64,` prefix) and sends the raw binary PDF bytes downstream as `multipart/form-data`. If `content` is also present for compatibility with an existing client, `content_base64` takes precedence.

```json
{
  "planNumber": "20429",
  "action": "QNA_INGEST_DOCUMENTS",
  "payload": {
    "files": [
      {
        "filename": "New_Compliance_Policy.pdf",
        "content_base64": "<base64 PDF bytes>",
        "content_type": "application/pdf"
      }
    ],
    "document_type": "policy",
    "review_scope_id": "<resolved review scope id>",
    "process_instance_id": "<resolved process instance id>",
    "task_id": "<resolved task id>",
    "review_scope_stage": "<resolved stage>"
  }
}
```

For upload smoke tests (with `document_type: "policy"`):
- Plan `20429`: [sample-access-control-policy-plan-20429.pdf](sample-access-control-policy-plan-20429.pdf)
- Plan `20440` (built from Plan 20440 relevant policy extracts — GBSA High-Frequency Trading, Trading Markets, Operational Risk, Risk Appetite, and Supervision): [sample-gbsa-trading-policy-plan-20440.pdf](sample-gbsa-trading-policy-plan-20440.pdf)

The result may return `document_ids` immediately. If it returns `status: "accepted"` with a `job_id` and no IDs, poll until IDs are available. In this gateway request, the file part defaults to the Query Agent's generic `files` field; `document_type` is forwarded as multipart form data.

### 1.1b Upload pre-structured `.json` documents (skip RAG)

If you already have a structured JSON document (such as a `policy*.json`, `kod*.json`, or `procedure*.json` part file) instead of a source PDF, **do not** send it to `QNA_INGEST_DOCUMENTS`. Use one of the JSON upload actions instead:

- **Structured plan-context upload (`QNA_UPLOAD_DOCUMENTS` → `POST /qna/documents/upload`):**

```json
{
  "planNumber": "20440",
  "action": "QNA_UPLOAD_DOCUMENTS",
  "payload": {
    "documents": [
      {
        "document_type": "policy",
        "items": [
          {
            "file_name": "policy_custom_1.json",
            "document_title": "Custom Policy Title",
            "document_id": "999",
            "content": "<section text or structured nodes>"
          }
        ]
      }
    ],
    "user_details": {
      "review_scope_id": "<resolved review scope id>",
      "process_instance_id": "<resolved process instance id>",
      "task_id": "<resolved task id>",
      "review_scope_stage": "<resolved stage>",
      "user": "<signed-in user>"
    }
  }
}
```

- **Raw `.json` file upload to GCS (`QNA_UPLOAD_FILE` → `POST /qna/upload`):**

```json
{
  "planNumber": "20440",
  "action": "QNA_UPLOAD_FILE",
  "payload": {
    "files": [
      {
        "filename": "policy_custom_1.json",
        "content_base64": "<base64 JSON bytes>",
        "content_type": "application/json"
      }
    ],
    "dest_blob_path": "dbaware_review_20440/inbound-data/policy/relevant_policy/policy_custom_1.json"
  }
}
```

> Note: `QNA_UPLOAD_FILE` only accepts filenames ending in `.json`; the master agent decodes `content_base64` and forwards the file under the singular multipart field `file`.

### 1.2 Poll an accepted ingest job

```json
{
  "planNumber": "20429",
  "action": "QNA_GET_INGEST_JOB_STATUS",
  "payload": {
    "job_id": "<job_id from the ingest response>"
  }
}
```

Continue while the job is queued or processing. When the job reaches a successful terminal status (`completed`, `done`, `success`, `succeeded`, or `partial_success`), proceed only if it includes `document_ids`. Treat a terminal result without IDs as an ingest failure. Stop and surface the failure if the status is `failed` or `error`.

### 1.3 Categorize the new document IDs

Use the IDs from the ingest result or completed job. Categorization maps each ID to its document type, which is needed to request the relevant sections.

```json
{
  "planNumber": "20429",
  "action": "QNA_CATEGORIZE_DOCUMENTS",
  "payload": {
    "document_ids": [501]
  }
}
```

Read the type-to-ID mapping in `response.categorized_documents` (for example, `policy: [501]`). If the user selected an explicit document type, use that selection; otherwise use the returned categorization.

### 1.4 Retrieve relevant sections and persist to the plan

Group IDs by document type. `QNA_GET_RELEVANT_DATA` retrieves relevant sections and, with `persist_to_context: true` (the default), writes the retrieved material into the plan's GCS context and document registry. Include the applicable workflow context in `user_details`.

```json
{
  "planNumber": "20429",
  "action": "QNA_GET_RELEVANT_DATA",
  "payload": {
    "review_id": "20429",
    "documents": [
      {
        "document_type": "policy",
        "document_ids": [501],
        "top_k": 5
      }
    ],
    "persist_to_context": true,
    "user_details": {
      "review_scope_id": "<resolved review scope id>",
      "process_instance_id": "<resolved process instance id>",
      "task_id": "<resolved task id>",
      "review_scope_stage": "<resolved stage>",
      "user": "<signed-in user>"
    }
  }
}
```

Proceed when the response reports success and `registry_updated: true`. The `results` contain the retrieved sections; `persisted_files` shows the saved plan-context files. If persistence fails or `registry_updated` is false, surface the error and do not report the upload as included in Preliminary Research. The demo currently attempts its optional registry sync and then refreshes/regenerates even if that sync fails; gating on this flag is a reliability requirement for the gateway flow.

### 1.5 Refresh the document catalog

Call `QNA_LIST_DOCUMENTS` after persistence so the new document and its sections appear in the selected plan's catalog. Use live IDs and titles from the response for subsequent UI mentions; never construct IDs from filenames or titles.

```json
{
  "planNumber": "20429",
  "action": "QNA_LIST_DOCUMENTS",
  "payload": {
    "user_details": {
      "review_scope_id": "<resolved review scope id>",
      "process_instance_id": "<resolved process instance id>",
      "task_id": "<resolved task id>",
      "review_scope_stage": "<resolved stage>",
      "user": "<signed-in user>"
    }
  }
}
```

The fixture's mention for the example section is:

```text
@[Policies: Governance_Policy_1 > Section 1 of Policy 1]
```

Use the returned `document_groups`, document and section IDs, titles, and exclusion state to build suggestions and badges. Category labels used by ct1-demo are `Policies` (`policy`), `KOD` (`kod`), `Procedures` (`procedure`), `GFMS Data` (`gfms`), `Historical Scoping` (`historical_scoping_document`), and `LRR Mandates` (`lrr`). A section is unavailable when it or its parent document is excluded.

### 1.6 Regenerate the affected Preliminary Research sections

After persistence, mark the affected sections stale. The ct1-demo upload flow regenerates `policy_regulation` and `broad_scope` for a new upload. This RAG upload path handles `policy`, `kod`, and `procedure` documents; each affects those two Preliminary Research sections.

When automatic regeneration is enabled, call `RUN_ANALYTICS` with the affected section keys in `sections`:

```json
{
  "planNumber": "20429",
  "action": "RUN_ANALYTICS",
  "payload": {
    "sections": ["policy_regulation", "broad_scope"],
    "userDetails": {
      "review_scope_id": "<resolved review scope id>",
      "process_instance_id": "<resolved process instance id>",
      "task_id": "<resolved task id>",
      "review_scope_stage": "<resolved stage>",
      "user": "<signed-in user>"
    }
  }
}
```

Then fetch and display the updated Preliminary Research document:

```json
{
  "planNumber": "20429",
  "action": "GET_PRELIMINARY_RESEARCH_DOCUMENT",
  "payload": {}
}
```

If automatic regeneration is off, leave the affected sections marked stale and let the user start regeneration. Do not treat an RAG upload alone as completion: the relevant sections must be persisted to the plan context before they can inform the connected Preliminary Research.

## 2. Exclusion and re-inclusion

Exclusion and re-inclusion are plan document actions. Re-inclusion restores an existing excluded document or section; it does not upload the source again.

### 2.1 Build the request from the live catalog

Use the exact mention token from `QNA_LIST_DOCUMENTS`. The local plan 20429 fixture examples are:

```text
Exclude @[Policies: Governance_Policy_1]
```

```text
Exclude @[Policies: Governance_Policy_1 > Section 1 of Policy 1]
```

```text
Re-include @[Policies: Governance_Policy_1 > Section 1 of Policy 1]
```

Use explicit action wording and show the proposed changes before execution.

### 2.2 Create the pending action plan

Send the user's request in `user_text`. When `extracted_actions` and `verification` are omitted, the Query Agent extracts the requested changes, verifies them against the plan's documents, and returns a proposal for review.

```json
{
  "planNumber": "20429",
  "action": "QNA_PLAN_DOCUMENT_ACTIONS",
  "payload": {
    "user_text": "Exclude @[Policies: Governance_Policy_1 > Section 1 of Policy 1]",
    "context_type": "Preliminary Research Walkthrough",
    "user_details": {
      "review_scope_id": "<resolved review scope id>",
      "process_instance_id": "<resolved process instance id>",
      "task_id": "<resolved task id>",
      "review_scope_stage": "<resolved stage>",
      "user": "<signed-in user>"
    }
  }
}
```

A proposal that needs approval returns `status: "pending_approval"`, `plan_id`, a summary, proposed `steps`, and `requires_approval: true`. Show these in the approval UI. If the result is `no_verified_actions` or `not_document_request`, there is no executable proposal to approve.

### 2.3 Apply or reject the proposal

When the user approves or rejects, send the returned `plan_id`. Approve maps to `decision: "approve"`; reject/cancel maps to `decision: "reject"`.

```json
{
  "planNumber": "20429",
  "action": "QNA_DECIDE_DOCUMENT_ACTIONS",
  "payload": {
    "plan_id": "<plan_id from QNA_PLAN_DOCUMENT_ACTIONS>",
    "decision": "approve",
    "approved_by": "<signed-in user>",
    "user_details": {
      "review_scope_id": "<resolved review scope id>",
      "process_instance_id": "<resolved process instance id>",
      "task_id": "<resolved task id>",
      "review_scope_stage": "<resolved stage>",
      "user": "<signed-in user>"
    }
  }
}
```

The response reports the result status and, when changes execute, `affected_sections`. Do not update the catalog for a proposed or rejected change.

### 2.4 Refresh after an executed change

After an approved change succeeds:

1. Call `QNA_LIST_DOCUMENTS` and refresh document and section inclusion states.
2. If `affected_sections` is non-empty, call `RUN_ANALYTICS` with the returned values in `sections`.
3. Call `GET_PRELIMINARY_RESEARCH_DOCUMENT` and refresh the displayed report.

Do not regenerate for a rejected proposal. If execution is partial or fails, show the returned status, refresh the catalog to reflect the applied state, and let the user correct or retry the remaining action.
