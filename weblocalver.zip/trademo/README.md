# Trade Collections — Maker Workbench

An import-collections maker workbench for the IDPMS / TradePay → TF3 flow,
served in **two house styles off one API**. Same data, same routes, same
behaviour — only the presentation differs.

The cases are the **real sample transactions** the bank supplied: 22 IDPMS
invoice lines, the matching TradePay records, the booked deals, the FX card
rates and the Autobahn charge instructions, all converted to JSON under
`app/data/`. Nothing is invented — no service levels, no priorities, no
pre-assigned owners. The only state the application adds is the state a person
creates by using it.

The charge instructions are free-format prose, and they are read by an
**AI pricing agent** whose reasoning opens from the case. See
[docs/pricing-agent.md](docs/pricing-agent.md).

## Run

Double-click **`run.bat`**. The first run builds a local `.venv`, installs what
it needs and opens the browser; after that it starts in a couple of seconds.
Pass a port if 8000 is busy:

```
run.bat 8080
```

By hand, if you prefer:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m uvicorn app.main:app --port 8000
```

| Link | View |
| --- | --- |
| `http://127.0.0.1:8000/?v=desk` | **Desk** — the collections-desk interpretation |
| `http://127.0.0.1:8000/?v=corp` | **Corporate** — the project deck's house style |

Either link is shareable and the choice sticks via a cookie. Both carry a
switch link in the top bar.

## The flow

1. **Cases are built from IDPMS**, grouped by Bill of Entry *and importer* —
   because BoE 9152082 is genuinely held by two importers in the sample data,
   which is the duplicate-BoE case from the meeting notes. Repeated invoice
   lines are deduplicated, keeping the latest shipment date.
2. **TradePay is matched** on Bill of Entry *and* the consignment's own invoice
   numbers — never the Bill of Entry alone. BoE 9152082 carries four TradePay
   rows that all belong to Rothe Erde, so matching on the number alone would
   hand Hella's case somebody else's drawer, country and currency. Where nothing
   matches, the checks say there is no record rather than comparing the wrong
   one.
3. **The three specified consistency checks run** — drawer name, drawer country,
   currency. The procedure writes each as
   `Trade Pay ↔ IDPMS / Trade Pay Documents / WFMS`, so the reference value is a
   **cascade**: IDPMS first, then the supporting documents attached in TradePay,
   then WFMS. Only IDPMS has been supplied; the other two report themselves
   unavailable rather than being skipped, and a check that needs them says which
   one it is waiting on. Names are normalised so `TWINTECH(S) PTE LTD` matches
   `TWINTECH S PTE LTD`, countries so `PEOPLES REP OF CHINA` matches `CHINA`
   (Hong Kong is deliberately kept separate — that difference is real), and
   references so `INV2606/12999` matches `INV260612999`.
4. **The ports are resolved.** A five-digit code is searched as it stands, a
   three-digit code with its two-letter country prefix (`SIN` → `SGSIN`). Every
   code in the sample data resolves. Where a code is not in the directory, the
   case blocks and the maker types the name in — recorded as theirs.
5. **The charges are read** by the pricing agent out of the client's Autobahn
   processing text, with the forex conversion clause and GST computed from the
   published tiers.
6. **The maker validates**, the checker approves, and the case is posted to TF3.

Checks beyond the specified three are labelled as such rather than presented as
requirements — an invoice-amount difference, a shared Bill of Entry, an
unresolved port.

## The pricing agent

The charge instruction held against a client is prose, and it contradicts
itself. Hella's reads `INR 450 per document` on one line and
`Pricing to be levied at remittance level` on the next; on a remittance covering
three invoices those are INR 1,350 and INR 450. A regex picks one silently.

The agent reads it, prices the lower figure, says what the other reading would
cost, and marks the case for a human. Its reasoning opens from the charges card:
the instruction, the numbered argument, the exact words behind each decision,
what it deliberately did not charge, and every figure re-computed independently.

It runs on **Gemini via Vertex AI with Workload Identity Federation** in the
bank's environment, falls back to the Anthropic API, then to the local `claude`
CLI for testing, then to pattern matching — which it labels as such on every
case rather than passing off as reasoning. `GET /api/agent/status` says which
one is live.

> On its first run against real data the agent objected that the forex
> conversion fee applied 0.5% to the whole gross when the clause charges it only
> on the amount above one lakh. It was right, and the calculation was fixed.

## Where the real systems plug in

Each external system is mocked in its own module under `app/sources/`, and
mounted read-only under `/api/mock`. Replacing a mock with a real integration
means changing that one module; `store.py` does not care where the data came
from.

| Module | Real source |
| --- | --- |
| `sources/idpms.py` | IDPMS — the Bills of Entry and their invoice lines |
| `sources/tradepay.py` | The TradePay portal's outward remittance records |
| `sources/ports.py` | The port directory (volza.com/ports) |
| `sources/autobahn.py` | Autobahn / OEMS, Products tab, the *Processing* field |
| `sources/checks.py` | The specified consistency checks |
| `sources/tf3.py` | TF3 — the posting of the final data and charges |
| `agent/providers.py` | Vertex AI, the Anthropic API, the `claude` CLI |

The JSONs under `app/data/` are regenerated from the supplied workbooks with:

```powershell
.venv\Scripts\python tools\build_mock_data.py
```

A port directory is loaded with:

```powershell
.venv\Scripts\python tools\load_ports.py <the-directory>.json
```

It takes a JSON array of `{code, name, country, unlocode}`, checks it against
the codes the sample data actually uses, and refuses to write if any are missing
— so a truncated file cannot half-load. Entries marked `"confident": false` are
recorded under `"unverified"` in `ports.json` rather than silently trusted.

## Taking it to another environment

Copy `.env.example` to `.env` and fill in the Vertex settings. It is read at
start-up, and a real environment variable always beats the file, so pinning a
provider on the command line still works:

```powershell
copy .env.example .env
.venv\Scripts\python -m uvicorn app.main:app --port 8000
```

`.env` is gitignored and excluded from the distribution zip — only
`.env.example` travels.

`GET /api/agent/status` is the first thing to check once it is up: it names the
provider that answered and, for Vertex, the credential class, which is what
tells you whether Workload Identity Federation is really in play or whether you
are on somebody's gcloud login.

## Making a Vertex-only build

The agent carries two development backends besides Vertex so it can be worked on
without a cloud project. Neither is usable in a deployed environment. To produce
a copy with only Vertex and the no-model fallback:

```powershell
.venv\Scripts\python toolsertex_only.py ..	rademo-vertex
```

It rewrites the source, the dependencies, the configuration and the
documentation, then **verifies its own output** — if one mention survives
anywhere in the copy it reports the file and line and exits non-zero. It also
imports the result and prints the remaining providers, so a copy that does not
run never passes silently.

The original is untouched, so local development keeps working.

## Resetting between demo runs

**Reset the demo** sits in the footer of every page. It discards every maker and
checker action — settled checks, typed port names, queries, validations,
approvals and TF3 postings — re-reads `app/data/*.json` and puts all twelve
cases back through the pipeline, leaving the queue exactly as it opens.

It is immediate, because the pricing agent'"'"'s readings are cached on (client,
document count) and survive a reset; they do not depend on anything a maker did.
A server restart clears that cache, so the first run afterwards costs one model
call per priced client.

`POST /api/demo/reset {"run": false}` does the same but leaves the cases unrun,
if you would rather show the pipeline working live.

## API

Full reference at `/docs`. The screens use exactly these routes.

```
GET   /api/cases              ?view= &search= &importer= &currency= &status= &sort= &direction=
GET   /api/cases/counts | /live
GET   /api/cases/{id}         | /state
GET   /api/agent/status       which model is reading the charge instructions
GET   /api/checks/sources     the IDPMS / TradePay documents / WFMS cascade

POST  /api/cases/{id}/ports/{loading|discharge}      {name, note}
POST  /api/cases/{id}/checks/{cid}/resolve           {resolution}
POST  /api/cases/{id}/charges/recalculate            re-reads, bypassing the cache
POST  /api/cases/{id}/queries                        {reason, recipient, check_id}
POST  /api/cases/{id}/queries/{qid}/answer           {response}
POST  /api/cases/{id}/start | /validate | /approve | /return | /undo
POST  /api/cases/run-all
POST  /api/demo/reset                                {run}  put the demo back
POST  /api/session/role                              {role}
```

The mocked external systems, so they can be exercised on their own:

```
GET   /api/mock/idpms | /idpms/consignments | /tradepay
GET   /api/mock/ports/{code} | /ports/status
GET   /api/mock/autobahn/{client} | /autobahn/{client}/quote
GET   /api/mock/checks/{boe}
GET   /api/mock/tf3                 everything posted so far
POST  /api/mock/reload              re-read app/data/*.json from disk
```

## Layout

```
app/
  main.py            page routes + theme resolution
  api.py             the application's own JSON API
  store.py           cases, the pipeline, undo
  models.py          Pydantic schemas (the UI contract)
  agent/
    pricing.py       the pricing agent: prompt, parsing, verification
    providers.py     Vertex / Anthropic / claude CLI / rules
  sources/           one module per mocked external system
  data/              the sample data as JSON
  templates/desk/    base, queue, case, reference, partials/
  templates/corp/    the same screens in the deck's house style
  static/css/        desk.css, corp.css
  static/js/         app.js, queue.js, case.js — one script drives both views
tools/
  build_mock_data.py rebuilds app/data/*.json from the supplied workbooks
docs/
  pricing-agent.md   the agent, and the Vertex / WIF setup
```

## Still outstanding

- **`INGHR6` is unverified.** The loaded directory names it Garhi Harsaru
  Inland Container Depot, but whoever produced it was not sure. It is listed
  under `"unverified"` in `app/data/ports.json` and should be confirmed against
  the real directory before this is used in anger.
- **Only 3 of the 12 importers have pricing on file in Autobahn.** That is what
  the sample data contains, so the other cases correctly report that there is
  nothing to charge rather than inventing a rate.
- **Five genuine discrepancies remain, and should.** Putzmeister's invoice
  `2025XYW65` reads `15,255.93 EUR` in TradePay and `486 USD` in IDPMS; Sigma
  Aldrich's drawer is in Hong Kong per IDPMS and the Peoples Rep of China per
  TradePay, and is named `Leap Chem Co Ltd` against `LEAP LABCHEM CO.,LTD.`
  These are what the checks exist to find.
- **Some portal columns are cut off** in the screenshots the sample data was
  transcribed from. Where the legible part agrees with IDPMS the check passes
  and says so; where a column is not visible at all the check reports that there
  is nothing to compare. Neither is reported as a mismatch.
- **Live credentials for Vertex.** The WIF path is built and configurable but
  has not been exercised against a real project; the agent was tested on the
  `claude` CLI backend.
