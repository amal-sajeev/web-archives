/* Shared bits: fetch, toasts, dialogs, role switch. */

window.App = (function () {
  "use strict";

  async function api(method, url, body) {
    const opts = { method, headers: {} };
    if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || data.message || "Something went wrong");
    return data;
  }

  /* toast(tone, title, message, action?)
     action = { label, onClick, seconds } — `seconds` counts down in the label
     and dismisses the toast when it reaches zero, which is how the undo window
     is surfaced. */
  function toast(tone, title, message, action) {
    const host = document.getElementById("toasts");
    if (!host) return;

    const el = document.createElement("div");
    el.className = "notice notice--" + tone;
    const text = document.createElement("div");
    text.innerHTML = "<b></b><span></span>";
    text.querySelector("b").textContent = title;
    text.querySelector("span").textContent = message || "";
    el.appendChild(text);

    let life = (action && action.seconds) ? action.seconds * 1000 : 4200;
    let timer, tick;

    const close = () => {
      clearTimeout(timer); clearInterval(tick);
      el.style.transition = "opacity .3s, transform .3s";
      el.style.opacity = "0";
      el.style.transform = "translateY(6px)";
      setTimeout(() => el.remove(), 320);
    };

    if (action) {
      const btn = document.createElement("button");
      btn.className = "notice__do";
      let left = action.seconds || 0;
      const label = () => btn.textContent = left ? `${action.label} ${left}s` : action.label;
      label();
      if (left) tick = setInterval(() => { left -= 1; label(); if (left <= 0) clearInterval(tick); }, 1000);
      btn.addEventListener("click", () => { close(); action.onClick(); });
      el.appendChild(btn);
    }

    host.appendChild(el);
    timer = setTimeout(close, life);
  }

  function openModal(id) {
    const m = document.getElementById(id);
    if (!m) return null;
    m.classList.add("is-open");
    const f = m.querySelector("input:not([type=hidden]), textarea");
    if (f) setTimeout(() => f.focus(), 40);
    return m;
  }

  function closeModals() {
    document.querySelectorAll(".sheet-over.is-open").forEach(m => m.classList.remove("is-open"));
  }

  document.addEventListener("click", e => {
    if (e.target.closest("[data-close]")) closeModals();
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") closeModals();
  });

  document.querySelectorAll("[data-switch-role]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const next = document.body.dataset.role === "Checker" ? "Maker" : "Checker";
      try {
        await api("POST", "/api/session/role", { role: next });
        location.href = "/";
      } catch (err) { toast("bad", "Could not switch", err.message); }
    });
  });

  /* ----------------------------------------------- put the demo back ---- */
  /* Discards every maker and checker action and rebuilds the cases from the
     data files. Destructive, so it asks first — a mis-click during a demo is
     exactly when you least want to lose the state you set up. */
  document.querySelectorAll("[data-reset]").forEach(btn => {
    btn.addEventListener("click", async () => {
      if (!window.confirm(
        "Reset the demo?\n\n" +
        "This discards every validation, approval, settled check, typed port " +
        "name and query, and puts all cases back through the checks.")) return;

      const was = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Resetting\u2026";
      try {
        const res = await api("POST", "/api/demo/reset", { run: true });
        btn.textContent = "Ready";
        toast("ok", "Demo reset", res.message || "Cases rebuilt.");
        setTimeout(() => { location.href = "/"; }, 600);
      } catch (err) {
        btn.disabled = false;
        btn.textContent = was;
        toast("bad", "Could not reset", err.message);
      }
    });
  });

  return { api, toast, openModal, closeModals };
})();
