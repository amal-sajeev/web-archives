"""The case store, built from the mocked external systems.

Everything here comes out of ``app/sources``. Replacing a mock with a real
integration means changing that module; this file does not care where the data
came from.
"""

from __future__ import annotations

import re
import secrets
import threading
from datetime import datetime, timedelta

from .models import (
    AuditEntry,
    CaseStatus,
    ChargeLine,
    Charges,
    Check,
    CollectionCase,
    ComparedField,
    InvoiceLine,
    PortRef,
    Query,
    ThirdParty,
)
from .agent import price as agent_price
from .sources import autobahn, checks as check_rules, idpms, ports, tf3, tradepay
from .sources._data import load, normalise_name, reload as load_sources

# Only dimensions that exist in the supplied data.
SORTABLE = {
    "boe_date":   lambda c: c.bill_of_entry_date or "",
    "boe":        lambda c: c.bill_of_entry,
    "importer":   lambda c: c.importer.lower(),
    "supplier":   lambda c: c.supplier.lower(),
    "amount":     lambda c: c.total_amount,
    "currency":   lambda c: (c.currency, -c.total_amount),
    "charges":    lambda c: c.charges.total if c.charges.priced else -1.0,
    "outstanding": lambda c: len(c.action_items),
    "checks":     lambda c: (c.checks_passed / c.checks_total) if c.checks_total else 0.0,
    "invoices":   lambda c: len(c.invoice_lines),
    "shipment":   lambda c: c.latest_shipment_date or "",
    "status":     lambda c: c.status.value,
    "port":       lambda c: (c.port("discharge").code or "") if c.port("discharge") else "",
}

VIEWS: dict[str, dict] = {
    "all": {"label": "All open", "statuses": None},
    "attention": {"label": "Needs attention", "statuses": [CaseStatus.NEEDS_ATTENTION]},
    "ready": {"label": "Ready", "statuses": [CaseStatus.READY_FOR_REVIEW]},
    "processing": {"label": "Running", "statuses": [CaseStatus.RECEIVED,
                                                    CaseStatus.AI_PROCESSING]},
    "checker": {"label": "With checker", "statuses": [CaseStatus.IN_CHECKER_QUEUE]},
    "completed": {"label": "Posted", "statuses": [CaseStatus.COMPLETED]},
}

OPEN_STATUSES = (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING,
                 CaseStatus.NEEDS_ATTENTION, CaseStatus.READY_FOR_REVIEW,
                 CaseStatus.RETURNED)


class Session:
    """Who is driving. A real deployment reads this from SSO."""

    def __init__(self) -> None:
        self.name = "Maker"
        self.initials = "MK"
        self.role = "Maker"
        self.desk = "Trade Finance Ops"

    def switch(self, role: str) -> None:
        self.role = "Checker" if role.lower() == "checker" else "Maker"
        self.name = self.role
        self.initials = "CK" if self.role == "Checker" else "MK"


# ---------------------------------------------------------------------------
# building a case out of the sources
# ---------------------------------------------------------------------------

def _case_id(consignment: dict, shared: bool) -> str:
    boe = consignment["billOfEntryNumber"]
    if not shared:
        return boe
    word = re.sub(r"[^A-Z]", "", (consignment["importer"] or "").upper().split()[0])
    return f"{boe}-{word[:6]}"


def _invoice_lines(consignment: dict) -> list[InvoiceLine]:
    out = []
    for r in consignment["invoiceLines"]:
        out.append(InvoiceLine(
            record_id=r["recordId"],
            invoice_no=_text(r.get("invoiceNo")),
            invoice_date=r.get("invoiceDate"),
            amount=_num(r.get("invoiceAmount")),
            currency=r.get("invoiceCurrency"),
            terms=_text(r.get("termsOfInvoice")),
            supplier_name=r.get("supplierName"),
            supplier_address=r.get("supplierAddress"),
            supplier_country=r.get("supplierCountry"),
            freight_amount=_num(r.get("freightAmount")),
            freight_currency=r.get("freightCurrencyCode"),
            insurance_amount=_num(r.get("insuranceAmount")),
            insurance_currency=r.get("insuranceCurrencyCode"),
            misc_amount=_num(r.get("miscellaneousCharges")),
            misc_currency=r.get("miscellaneousCurrency"),
            shipment_date=r.get("HAWB-HBLDate") or r.get("MAWB-MBLDate"),
            transport_document=_text(r.get("HAWB-HBLNumber") or r.get("MAWB-MBLNumber")),
        ))
    return out


def _text(v) -> str | None:
    """IDPMS returns codes as numbers where they happen to look numeric."""
    return None if v is None or v == "" else str(v)


def _num(v) -> float | None:
    try:
        return float(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


def _port_refs(consignment: dict) -> list[PortRef]:
    out = []
    for role, key in (("loading", "portOfShipment"), ("discharge", "portOfDischarge")):
        code = consignment.get(key)
        hint = consignment.get("supplierCountryIso2") if role == "loading" else "IN"
        r = ports.resolve(code, hint)
        out.append(PortRef(
            role=role, code=r["code"] or None, searched_as=r["searchedAs"],
            prefix_applied=r["prefixApplied"], name=r.get("name"),
            country=r.get("country"), status=r["status"], message=r.get("message"),
        ))
    return out


_PRICE_CACHE: dict[tuple, dict] = {}
_PRICE_LOCK = threading.Lock()


def _price(case: CollectionCase, *, fresh: bool = False) -> Charges:
    """Charges for one case, read out of the client's instruction by the agent.

    A model call takes seconds, and the decision the agent makes depends only on
    the instruction text and how many documents the remittance covers - not on
    the rupee value, which only feeds the forex clause and is computed here. So
    the reading is cached on (client, documents) and the money is worked out per
    case. ``fresh`` skips the cache, which is what the recalculate button does.
    """
    gross = _gross_inr(case, case.deal)
    key = (normalise_name(case.importer), len(case.invoice_lines))

    with _PRICE_LOCK:
        cached = None if fresh else _PRICE_CACHE.get(key)

    if cached is None:
        quote = agent_price(
            case.importer,
            documents=len(case.invoice_lines),
            gross_inr=gross,
            importer=case.importer,
            supplier=case.supplier,
            bill_of_entry=case.bill_of_entry,
            currency=case.currency,
            amount=case.total_amount,
            invoice_numbers=[l.invoice_no for l in case.invoice_lines if l.invoice_no],
            rate_basis=_rate_basis(case),
            shares_boe=case.shares_boe_with_another_importer,
        )
        with _PRICE_LOCK:
            _PRICE_CACHE[key] = quote
    else:
        # Same reading, this case's money.
        quote = _restate(cached, gross)

    trace = dict(quote.get("trace") or {})
    trace["reusedReading"] = cached is not None
    trace["grossInr"] = round(gross, 2)

    return Charges(
        status=quote["status"],
        client=quote.get("client"),
        processing_text=quote.get("processingText"),
        reading=quote.get("reading", {}),
        agent_trace=trace,
        documents=quote.get("documents", len(case.invoice_lines)),
        gross_inr=gross,
        message=quote.get("message"),
        lines=[ChargeLine(code=l["code"], label=l["label"], basis=l["basis"],
                          amount_inr=l["amountInr"]) for l in quote.get("lines", [])],
    )


def _restate(quote: dict, gross: float) -> dict:
    """A cached reading, with the forex fee and GST redone for this case."""
    if not quote.get("lines"):
        return quote

    clause = load("fx")["forexConversionClause"]
    gst_rate = clause["gstPercent"] / 100.0
    own = [l for l in quote["lines"] if l["code"] not in ("FXCONV", "GST")]
    fx = autobahn.forex_conversion_fee(gross)
    commission = round(sum(l["amountInr"] for l in own), 2)
    gst = round((commission + fx["amountInr"]) * gst_rate, 2)

    lines = own + [
        {"code": "FXCONV", "label": "Forex conversion",
         "basis": fx["basis"], "amountInr": fx["amountInr"]},
        {"code": "GST", "label": "GST",
         "basis": f"{clause['gstPercent']:.0f}% on the charges above, excluding GST",
         "amountInr": gst},
    ]
    restated = dict(quote)
    restated["lines"] = lines
    restated["totalInr"] = round(sum(l["amountInr"] for l in lines), 2)
    restated["grossInr"] = round(gross, 2)
    return restated


def _rate_basis(case: CollectionCase) -> str | None:
    """How the rupee value was arrived at, for the agent's context."""
    if case.deal and case.deal.get("inrAmount"):
        rate = case.deal.get("rate") or case.deal.get("dealRate")
        return f"the booked deal rate{f' of {rate}' if rate else ''}"
    fx = load("fx")
    if case.currency in fx.get("cardRates", {}):
        return f"the card rate of {fx['cardRates'][case.currency]} per {case.currency}"
    if case.currency in fx.get("ratesFromDeals", {}):
        return (f"{fx['ratesFromDeals'][case.currency]} per {case.currency}, "
                "taken from a deal booked on another consignment")
    return None


def _gross_inr(case: CollectionCase, deal: dict | None) -> float:
    """What was actually exchanged, in rupees.

    The booked deal carries it outright. Without one, convert at the card rate,
    falling back to the rate the deal for that currency used.
    """
    if deal and isinstance(deal.get("inrAmount"), (int, float)) and deal["inrAmount"]:
        return float(deal["inrAmount"])
    fx = load("fx")
    rate = fx["cardRates"].get(case.currency) or fx.get("ratesFromDeals", {}).get(case.currency)
    return round(case.total_amount * rate, 2) if rate else 0.0


def _deal_for(importer: str, currency: str) -> dict | None:
    want = normalise_name(importer)
    best = None
    for d in load("deals").get("records", []):
        if normalise_name(d.get("client")) and normalise_name(d["client"]) in want:
            if d.get("currency") == currency:
                return d
            best = best or d
    return best


def build_cases() -> list[CollectionCase]:
    cases: list[CollectionCase] = []
    for consignment in idpms.consignments():
        shared = consignment["sharesBoeWithAnotherImporter"]
        case = CollectionCase(
            case_id=_case_id(consignment, shared),
            bill_of_entry=consignment["billOfEntryNumber"],
            bill_of_entry_date=consignment["billOfEntryDate"],
            importer=consignment["importer"],
            importer_code=_text(consignment.get("importerCode")),
            importer_pan=_text(consignment.get("importerPan")),
            importer_address=_text(consignment.get("importerAddress")),
            ad_code=_text(consignment.get("adCode")),
            ports=_port_refs(consignment),
            invoice_lines=_invoice_lines(consignment),
            third_parties=[ThirdParty(**t) for t in consignment.get("thirdParties", [])],
            latest_shipment_date=consignment.get("latestShipmentDate"),
            duplicate_lines_removed=consignment.get("duplicateLinesRemoved", 0),
            shares_boe_with_another_importer=shared,
        )
        # Match on Bill of Entry *and* the consignment's own invoice numbers.
        # A shared Bill of Entry otherwise picks up the other importer's record.
        case.tradepay = tradepay.for_consignment(
            case.bill_of_entry,
            [l.get("invoiceNo") for l in consignment["invoiceLines"]])
        case.deal = _deal_for(case.importer, case.currency)
        case.audit.append(AuditEntry(
            at=datetime.now(), actor="IDPMS", role="System", action="Transaction received",
            detail=f"Bill of Entry {case.bill_of_entry}, {len(case.invoice_lines)} invoice "
                   f"line(s)" + (f", {case.duplicate_lines_removed} duplicate line(s) removed"
                                 if case.duplicate_lines_removed else "") + "."))
        cases.append(case)
    return cases


# ---------------------------------------------------------------------------

class CaseStore:
    UNDO_TTL = timedelta(seconds=90)

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._cases: dict[str, CollectionCase] = {c.case_id: c for c in build_cases()}
        self._query_seq = 1000
        self._undo: dict[str, tuple[str, CollectionCase, datetime]] = {}
        self.session = Session()

    # --------------------------------------------------------------- reset
    def reset(self, *, run: bool = True, reload_data: bool = True) -> dict:
        """Put the demo back to a known state.

        Everything a person did — settled checks, typed port names, queries,
        validations, approvals and TF3 postings — is discarded and the cases are
        rebuilt from the source data. The pricing agent's readings are kept,
        because they depend on the instruction text rather than on anything a
        maker did, and re-reading them costs a model call apiece.

        ``run`` puts every case straight back through the pipeline, which is the
        state a demo usually wants to open on. Pass false to show the pipeline
        running live instead.
        """
        with self._lock:
            if reload_data:
                load_sources()           # pick up edits to app/data/*.json
            tf3.reset()                  # nothing has been posted
            self._cases = {c.case_id: c for c in build_cases()}
            self._undo.clear()
            self._query_seq = 1000
            self.session.switch("Maker")
            ran = 0
            if run:
                for case in self._cases.values():
                    if case.status is CaseStatus.RECEIVED:
                        self.run_pipeline(case)
                        ran += 1
        return {"cases": len(self._cases), "ran": ran,
                "message": (f"{len(self._cases)} case(s) rebuilt"
                            + (f" and put through the checks." if ran
                               else ", none run yet."))}

    # ------------------------------------------------------------ pipeline
    def run_pipeline(self, case: CollectionCase) -> None:
        """Run the checks and price the charges.

        Ports are resolved when the case is built; re-resolving here picks up a
        port directory that was dropped in since.
        """
        consignment = next((c for c in idpms.consignments()
                            if c["billOfEntryNumber"] == case.bill_of_entry
                            and c["importer"] == case.importer), None)
        if consignment is None:
            return

        for fresh, existing in zip(_port_refs(consignment), case.ports):
            if not existing.entered_by_maker:
                existing.name = fresh.name
                existing.status = fresh.status
                existing.message = fresh.message
                existing.searched_as = fresh.searched_as
                existing.prefix_applied = fresh.prefix_applied
                existing.country = fresh.country

        results = check_rules.run(consignment, case.tradepay)
        case.checks = [Check(
            id=r["id"], label=r["label"], status=r["status"], detail=r["detail"],
            source=r.get("source", ""),
            compared=[ComparedField(**c) for c in r.get("compared", [])],
        ) for r in results]

        case.charges = _price(case)

        case.audit.append(AuditEntry(
            at=datetime.now(), actor="Pipeline", role="Pipeline", action="Checks run",
            detail=f"{case.checks_passed} of {case.checks_total} checks passed; "
                   + (f"charges INR {case.charges.total:,.2f}." if case.charges.priced
                      else (case.charges.message or "charges not settled."))))
        case.status = (CaseStatus.NEEDS_ATTENTION if case.blockers
                       else CaseStatus.READY_FOR_REVIEW)
        case.processing_started = None

    def _tick(self) -> None:
        now = datetime.now()
        for case in self._cases.values():
            if case.status is CaseStatus.AI_PROCESSING and case.processing_started:
                if (now - case.processing_started).total_seconds() >= case.processing_seconds:
                    self.run_pipeline(case)

    def progress(self, case: CollectionCase) -> int:
        if case.status is not CaseStatus.AI_PROCESSING or not case.processing_started:
            return 0 if case.status is CaseStatus.RECEIVED else 100
        elapsed = (datetime.now() - case.processing_started).total_seconds()
        return max(5, min(97, int(elapsed / case.processing_seconds * 100)))

    def start_processing(self, case: CollectionCase) -> None:
        case.status = CaseStatus.AI_PROCESSING
        case.processing_started = datetime.now()
        case.audit.append(AuditEntry(
            at=datetime.now(), actor=self.session.name, role="Maker",
            action="Sent for checking",
            detail="Released to the pipeline for port lookup, consistency checks and charges."))

    def run_all(self) -> int:
        """Run every case that has not been through the pipeline."""
        n = 0
        with self._lock:
            for case in self._cases.values():
                if case.status is CaseStatus.RECEIVED:
                    self.run_pipeline(case)
                    n += 1
        return n

    # ---------------------------------------------------------------- read
    def all_cases(self) -> list[CollectionCase]:
        with self._lock:
            self._tick()
            return list(self._cases.values())

    def get(self, case_id: str) -> CollectionCase | None:
        with self._lock:
            self._tick()
            return self._cases.get(case_id)

    def list_cases(self, *, view: str = "all", search: str | None = None,
                   importer: str | None = None, currency: str | None = None,
                   status: str | None = None, sort: str | None = None,
                   direction: str = "asc") -> list[CollectionCase]:
        rows = self.all_cases()
        spec = VIEWS.get(view, VIEWS["all"])
        if spec.get("statuses"):
            rows = [c for c in rows if c.status in spec["statuses"]]
        elif view == "all":
            rows = [c for c in rows if c.status in OPEN_STATUSES]

        if importer and importer != "all":
            rows = [c for c in rows if c.importer == importer]
        if currency and currency != "all":
            rows = [c for c in rows if c.currency == currency]
        if status and status != "all":
            rows = [c for c in rows if c.status.value == status]
        if search:
            n = search.strip().lower()
            rows = [c for c in rows if n in c.case_id.lower()
                    or n in c.importer.lower() or n in c.bill_of_entry.lower()
                    or n in c.supplier.lower()
                    or any(n in (l.invoice_no or "").lower() for l in c.invoice_lines)]

        key = SORTABLE.get(sort or "", SORTABLE["boe_date"])
        rows.sort(key=key, reverse=(direction == "desc"))
        return rows

    def counts(self) -> dict[str, int]:
        rows = self.all_cases()
        return {
            "all": sum(1 for c in rows if c.status in OPEN_STATUSES),
            # What a maker can actually act on — not every case whose status
            # happens to be NEEDS_ATTENTION. A case held for a source nobody
            # supplied is counted separately, because there is nothing to do.
            "attention": sum(1 for c in rows if c.needs_maker),
            "held": sum(1 for c in rows if c.waiting_on_source),
            "ready": sum(1 for c in rows if c.status is CaseStatus.READY_FOR_REVIEW
                         and not c.needs_maker),
            "processing": sum(1 for c in rows if c.status in
                              (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING)),
            "checker": sum(1 for c in rows if c.status is CaseStatus.IN_CHECKER_QUEUE),
            "completed": sum(1 for c in rows if c.status is CaseStatus.COMPLETED),
            "queries": sum(len(c.open_queries) for c in rows),
        }

    def importers(self) -> list[str]:
        return sorted({c.importer for c in self.all_cases()})

    def currencies(self) -> list[str]:
        return sorted({c.currency for c in self.all_cases() if c.currency})

    # ------------------------------------------------------------ mutations
    def _log(self, case, action, detail, role=None):
        case.audit.append(AuditEntry(at=datetime.now(), actor=self.session.name,
                                     role=role or self.session.role,
                                     action=action, detail=detail))

    def set_port(self, case: CollectionCase, role: str, name: str,
                 note: str | None = None) -> PortRef | None:
        port = case.port(role)
        if port is None:
            return None
        port.name = name
        port.status = "resolved"
        port.entered_by_maker = True
        port.message = note
        self._log(case, "Port named",
                  f"Port of {role} ({port.code}) set to {name}."
                  + (f" {note}" if note else ""))
        self._revalidate(case)
        return port

    def resolve_check(self, case: CollectionCase, check_id: str,
                      resolution: str) -> Check | None:
        """Settle one check, or the several that share a cause.

        Where checks were grouped into a single thing for the maker to deal
        with, ``check_id`` arrives as their ids joined by commas, and one
        reason settles all of them.
        """
        wanted = [c.strip() for c in str(check_id).split(",") if c.strip()]
        settled = [c for c in case.checks if c.id in wanted and c.blocking]
        if not settled:
            return None
        for check in settled:
            check.status = "resolved"
            check.resolution = resolution
            check.resolved_by = self.session.name
            check.resolved_at = datetime.now()
        labels = ", ".join(c.label for c in settled)
        self._log(case, "Check settled" if len(settled) == 1 else "Checks settled",
                  f"{labels}: {resolution}")
        self._revalidate(case)
        return settled[0]

    def _revalidate(self, case: CollectionCase) -> None:
        if case.status in (CaseStatus.IN_CHECKER_QUEUE, CaseStatus.COMPLETED):
            return
        # a port named by the maker clears the port check it was blocking
        for check in case.checks:
            if check.id.startswith("PORT_") and check.blocking:
                role = "loading" if check.id.endswith("LOADING") else "discharge"
                port = case.port(role)
                if port and port.resolved:
                    check.status = "resolved"
                    check.resolution = f"Named by the maker as {port.name}."
                    check.resolved_by = self.session.name
                    check.resolved_at = datetime.now()
        case.status = (CaseStatus.NEEDS_ATTENTION if case.blockers
                       else CaseStatus.READY_FOR_REVIEW)

    def reprice(self, case: CollectionCase, *, fresh: bool = True) -> Charges:
        """Ask the agent again. ``fresh`` makes it re-read rather than reuse."""
        case.charges = _price(case, fresh=fresh)
        trace = case.charges.agent_trace
        by = (f"{trace.get('provider')} / {trace.get('model')}"
              if trace.get("provider") else "the charge rules")
        self._log(case, "Charges recalculated",
                  (f"INR {case.charges.total:,.2f}, read by {by}."
                   if case.charges.priced
                   else (case.charges.message or "Still not settled.")))
        return case.charges

    def raise_query(self, case, reason, recipient, check_id) -> Query:
        self._query_seq += 1
        q = Query(query_id=f"QRY-{self._query_seq}", check_id=check_id, recipient=recipient,
                  reason=reason, raised_by=self.session.name, raised_at=datetime.now())
        case.queries.append(q)
        case.status = CaseStatus.NEEDS_ATTENTION
        self._log(case, "Query raised", f"{q.query_id} to {recipient}: {reason}")
        return q

    def close_query(self, case, query_id, response) -> Query | None:
        q = next((x for x in case.queries if x.query_id == query_id), None)
        if q is None:
            return None
        q.status = "answered"
        q.response = response
        self._log(case, "Query answered", f"{q.query_id}: {response}")
        self._revalidate(case)
        return q

    # ----------------------------------------------------------- transitions
    def _snapshot(self, case) -> str:
        now = datetime.now()
        for stale in [t for t, (_, _, at) in self._undo.items()
                      if now - at > self.UNDO_TTL]:
            self._undo.pop(stale, None)
        token = secrets.token_urlsafe(9)
        self._undo[token] = (case.case_id, case.model_copy(deep=True), now)
        return token

    def undo(self, token: str) -> CollectionCase | None:
        entry = self._undo.pop(token, None)
        if entry is None:
            return None
        case_id, snapshot, at = entry
        if datetime.now() - at > self.UNDO_TTL:
            return None
        self._cases[case_id] = snapshot
        return snapshot

    def validate(self, case, note) -> tuple[bool, str, str | None]:
        if case.blockers:
            return False, "Settle these first: " + "; ".join(case.blockers) + ".", None
        token = self._snapshot(case)
        case.status = CaseStatus.IN_CHECKER_QUEUE
        self._log(case, "Validated",
                  note or "Checked against IDPMS and TradePay; sent for checker control.")
        return True, f"{case.case_id} is with the checker.", token

    def approve(self, case, note) -> tuple[bool, str, str | None]:
        """Checker approval posts the record to TF3."""
        if case.status is not CaseStatus.IN_CHECKER_QUEUE:
            return False, f"{case.case_id} is not with the checker.", None
        token = self._snapshot(case)
        loading, discharge = case.port("loading"), case.port("discharge")
        result = tf3.post({
            "billOfEntryNumber": case.bill_of_entry,
            "billOfEntryDate": case.bill_of_entry_date,
            "importer": case.importer,
            "importerCode": case.importer_code,
            "adCode": case.ad_code,
            "portOfLoading": loading.name if loading else None,
            "portOfLoadingCode": loading.code if loading else None,
            "portOfDischarge": discharge.name if discharge else None,
            "portOfDischargeCode": discharge.code if discharge else None,
            "thirdParties": [t.model_dump() for t in case.third_parties],
            "invoices": [{"invoiceNo": l.invoice_no, "date": l.invoice_date,
                          "amount": l.amount, "currency": l.currency}
                         for l in case.invoice_lines],
            "charges": {"totalInr": case.charges.total,
                        "lines": [l.model_dump() for l in case.charges.lines]},
            "approvedBy": self.session.name,
        })
        if not result["accepted"]:
            self._undo.pop(token, None)
            return False, result["message"], None

        case.status = CaseStatus.COMPLETED
        case.tf3_reference = result["tf3Reference"]
        self._log(case, "Approved", note or "Checker control complete.", role="Checker")
        case.audit.append(AuditEntry(
            at=datetime.now(), actor="TF3", role="System", action="Posted to TF3",
            detail=result["message"]))
        return True, result["message"], token

    def return_to_maker(self, case, reason) -> tuple[bool, str, str | None]:
        if case.status is not CaseStatus.IN_CHECKER_QUEUE:
            return False, f"{case.case_id} is not with the checker.", None
        token = self._snapshot(case)
        case.status = CaseStatus.RETURNED
        case.returned_reason = reason
        self._log(case, "Returned to maker", reason, role="Checker")
        return True, f"{case.case_id} went back to the maker.", token



store = CaseStore()


def get_store() -> CaseStore:
    return store
