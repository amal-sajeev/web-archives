"""The consistency checks between IDPMS and TradePay.

Three checks are specified: drawer name, drawer country and currency. Each
compares what TradePay holds against a reference value, and the reference is a
cascade, not a single system — IDPMS first, then the supporting documents
attached in TradePay, then WFMS. ``fallback.resolve`` walks it and says which
source answered, or which one the case is waiting on.

Their definitions live in ``app/data/checks.json`` so they can be changed
without touching code.

Further checks come out of the data itself rather than the written list, and
are reported separately as such: an amount that does not reconcile, a Bill of
Entry shared with another importer, and a port that could not be resolved.
"""

from __future__ import annotations

from . import fallback, idpms, ports, tradepay
from ._data import (load, longest_common_run, normalise_country,
                    normalise_name)


def definitions() -> list[dict]:
    return load("checks").get("checks", [])


def _compare(mode: str, left, right) -> bool:
    if left is None or right is None:
        return False
    if mode == "name":
        return normalise_name(left) == normalise_name(right)
    if mode == "country":
        return normalise_country(left) == normalise_country(right)
    return str(left).strip().upper() == str(right).strip().upper()


def _paid_lines(consignment: dict, tradepay_record: dict) -> list[dict]:
    """The IDPMS lines the TradePay record actually covers.

    A remittance need not cover every invoice under the Bill of Entry. Rothe
    Erde's nine portal rows leave out two IDPMS invoices; Bosch Rexroth's row
    covers one of two. Reconciling against all of them invents a difference.
    """
    from ._data import normalise_ref

    paid = {normalise_ref(n) for n in
            str(tradepay_record.get("invoiceNo") or "").split(",") if n.strip()}
    if not paid:
        return consignment["invoiceLines"]
    lines = [l for l in consignment["invoiceLines"]
             if normalise_ref(l.get("invoiceNo")) in paid]
    return lines or consignment["invoiceLines"]


def _reconcile_amount(head: dict, consignment: dict, tp_amount: float,
                      lines: list[dict] | None = None) -> dict:
    """Does the TradePay figure reconcile with the IDPMS invoice line(s)?

    The portal pays the invoice plus whatever charges are billed in the same
    currency. Symrise is the worked example: IDPMS holds 11,619.72 SGD with
    80 SGD of miscellaneous charges, and TradePay pays 11,699.72. Comparing the
    invoice alone would report a difference that is not one.
    """
    currency = head.get("invoiceCurrency")
    lines = lines if lines is not None else consignment.get("invoiceLines", [])

    invoice_total = sum(float(l.get("invoiceAmount") or 0) for l in lines)
    extras: list[tuple[str, float]] = []
    for label, amount_key, ccy_key in (
        ("miscellaneous charges", "miscellaneousCharges", "miscellaneousCurrency"),
        ("agency commission", "agencyCommission", "agencyCurrency"),
        ("freight", "freightAmount", "freightCurrencyCode"),
        ("insurance", "insuranceAmount", "insuranceCurrencyCode"),
    ):
        total = sum(float(l.get(amount_key) or 0) for l in lines
                    if l.get(ccy_key) == currency)
        if total:
            extras.append((label, round(total, 2)))

    if abs(tp_amount - invoice_total) < 0.01:
        return {"ok": True, "basis": "the invoice amount",
                "expected": round(invoice_total, 2), "extras": []}

    running = invoice_total
    used: list[tuple[str, float]] = []
    for label, amount in extras:
        running += amount
        used.append((label, amount))
        if abs(tp_amount - running) < 0.01:
            parts = " plus ".join(f"{a:,.2f} of {lbl}" for lbl, a in used)
            return {"ok": True, "basis": f"the invoice amount plus {parts}",
                    "expected": round(running, 2), "extras": used}

    return {"ok": False, "basis": None,
            "expected": round(invoice_total, 2), "extras": extras}


def run(consignment: dict, tradepay_record: dict | None) -> list[dict]:
    """Every check for one consignment, in the order a maker would read them."""
    results: list[dict] = []
    head = consignment["invoiceLines"][0]
    boe = consignment["billOfEntryNumber"]
    invoice_nos = [l.get("invoiceNo") for l in consignment["invoiceLines"]]

    # --- the three specified checks ---------------------------------------
    for spec in definitions():
        reference = fallback.resolve(spec["idpmsField"], head, consignment)

        if tradepay_record is None:
            results.append({
                "id": spec["id"], "label": spec["label"], "status": "blocked",
                "detail": (tradepay.why_no_match(boe, invoice_nos) or
                           "There is no TradePay record for this consignment, so "
                           "nothing can be compared against it."),
                "source": "TradePay", "compared": [],
            })
            continue

        if reference["status"] != "found":
            results.append({
                "id": spec["id"], "label": spec["label"], "status": "blocked",
                "detail": reference["message"],
                "source": " / ".join(reference["consulted"]), "compared": [],
            })
            continue

        left = tradepay_record.get(spec["tradePayField"])
        right = reference["value"]

        # The sample data is transcribed from screenshots of the portal, and
        # some columns are scrolled out of frame. A value that was never
        # legible cannot be compared, and must not be reported as a difference.
        field = spec["tradePayField"]
        if left in (None, "") and tradepay_record.get(f"{field}NotCaptured"):
            results.append({
                "id": spec["id"], "label": spec["label"], "status": "blocked",
                "detail": f"The TradePay record carries no {spec['label'].lower()}, "
                          "so there is nothing to compare. The column was not "
                          "captured in the sample data; a live TradePay "
                          "connection supplies it.",
                "source": "TradePay", "compared": [],
            })
            continue

        truncated = bool(tradepay_record.get(f"{field}Truncated"))
        ok = _compare(spec["compare"], left, right)
        if not ok and truncated and left and right:
            # The portal column is cut off. If what is legible appears in the
            # reference, that is agreement as far as it can be checked.
            a, b = normalise_name(left), normalise_name(right)
            shared = longest_common_run(a.replace(" ", ""), b.replace(" ", ""))
            if a and (a in b or b in a or shared >= 8):
                results.append({
                    "id": spec["id"], "label": spec["label"], "status": "pass",
                    "detail": f"{spec['label']} agrees as far as it can be read. "
                              f"The portal column is cut off in the source "
                              f"screenshot at \u201c{left}\u201d, which is part of "
                              f"\u201c{right}\u201d in {reference['source']}.",
                    "source": f"TradePay \u2194 {reference['source']}",
                    "compared": [{"field": spec["label"],
                                  "tradePay": f"{left} (cut off)",
                                  "idpms": str(right)}],
                })
                continue

        results.append({
            "id": spec["id"],
            "label": spec["label"],
            "status": "pass" if ok else "fail",
            "detail": spec["detail"] if ok else
                      f"{spec['label']} differs. TradePay holds "
                      f"“{left or '—'}”; {reference['source']} holds "
                      f"“{right or '—'}”.",
            "source": f"TradePay ↔ {reference['source']}",
            "compared": [{"field": spec["label"],
                          "tradePay": str(left or "—"),
                          "idpms": str(right or "—")}],
        })

    # --- checks the data forces, beyond the written three ------------------
    if tradepay_record is not None:
        tp_amount = tradepay_record.get("invoiceAmount")
        if isinstance(tp_amount, (int, float)):
            paid = _paid_lines(consignment, tradepay_record)
            r = _reconcile_amount(head, consignment, float(tp_amount), paid)
            covered = (f" across the {len(paid)} invoice line(s) it covers"
                       if len(paid) != len(consignment["invoiceLines"]) else "")
            idpms_total = r["expected"]
            results.append({
                "id": "INVOICE_AMOUNT",
                "label": "Amount reconciles",
                "status": "pass" if r["ok"] else "fail",
                "detail": (f"TradePay pays {tp_amount:,.2f}, which is "
                           f"{r['basis']} in IDPMS{covered}."
                           if r["ok"] else
                           f"TradePay holds {tp_amount:,.2f}; IDPMS adds up to "
                           f"{idpms_total:,.2f}{covered}"
                           + (" even after the charges billed in the same "
                              "currency are added" if r["extras"] else "")
                           + ". Not one of the three specified checks, but the "
                             "difference is material and nothing in the record "
                             "explains it."),
                "source": "TradePay ↔ IDPMS",
                "compared": [{"field": "Amount",
                              "tradePay": f"{tp_amount:,.2f}",
                              "idpms": f"{idpms_total:,.2f}"}],
            })

    if consignment.get("sharesBoeWithAnotherImporter"):
        others = sorted({
            r.get("IEName") for r in idpms.all_lines()
            if r["billOfEntryNumber"] == boe and r.get("IEName") != consignment["importer"]
        })
        results.append({
            "id": "DUPLICATE_BOE",
            "label": "Bill of Entry uniqueness",
            "status": "warn",
            "detail": f"Bill of Entry {boe} is also held by "
                      f"{', '.join(o for o in others if o)}. The two consignments "
                      "are kept apart on invoice number; check the drawee, drawer "
                      "and ports before going further.",
            "source": "IDPMS",
            "compared": [],
        })

    for role, code in (("Port of loading", consignment.get("portOfShipment")),
                       ("Port of discharge", consignment.get("portOfDischarge"))):
        resolved = ports.resolve(code, consignment.get("supplierCountryIso2"))
        check_id = f"PORT_{role.split()[-1].upper()}"
        if resolved["status"] == "resolved":
            results.append({
                "id": check_id, "label": role, "status": "pass",
                "detail": f"{code} resolves to {resolved['name']}.",
                "source": "Port directory", "compared": [],
            })
        else:
            results.append({
                "id": check_id, "label": role,
                "status": "blocked" if resolved["status"] == "directory_unavailable" else "fail",
                "detail": resolved["message"] + (
                    f" Searched as {resolved['searchedAs']}."
                    if resolved.get("prefixApplied") else ""),
                "source": "Port directory", "compared": [],
            })

    return results


def summary(results: list[dict]) -> dict:
    passed = sum(1 for r in results if r["status"] == "pass")
    open_items = [r for r in results if r["status"] in ("fail", "warn", "blocked")]
    return {
        "passed": passed,
        "total": len(results),
        "open": len(open_items),
        "clear": not open_items,
    }
