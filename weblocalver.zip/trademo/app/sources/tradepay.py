"""TradePay — the payment and invoice portal.

Stands in for the per-entity TradePay domains (cnsymrisetrade.ap and the rest).

Matching is the delicate part. The procedure says to match on Bill of Entry,
and where TradePay holds several Bills of Entry, on Bill of Entry *and* invoice
number together. That second clause is not decoration: Bill of Entry 9152082 is
held by Hella and by Rothe Erde, and TradePay carries four invoice rows against
it that all belong to Rothe Erde. Matching on the Bill of Entry alone would
hand Hella's case somebody else's drawer, country and currency, and the
consistency checks would then "fail" against a record that was never Hella's.

So where a Bill of Entry carries more than one row, this returns only the rows
whose invoice number is one of the consignment's own. If none is, it returns
nothing, and the checks report that there is no record to compare rather than
comparing the wrong one.
"""

from __future__ import annotations

from ._data import normalise_name, normalise_ref, records


def all_records() -> list[dict]:
    return records("tradepay")


def rows_for_bill_of_entry(boe: str) -> list[dict]:
    return [r for r in all_records()
            if str(r.get("billOfEntryNumber")) == str(boe)]


def for_consignment(boe: str, invoice_nos: list[str] | None = None) -> dict | None:
    """The TradePay record for one consignment, or None if it cannot be told.

    ``invoice_nos`` are the consignment's own invoice numbers, from IDPMS.
    Punctuation differs between the two systems — IDPMS holds INV2606/12999
    where the portal shows INV260612999 — so they are compared normalised.
    """
    rows = rows_for_bill_of_entry(boe)
    if not rows:
        return None

    wanted = {normalise_ref(n) for n in (invoice_nos or []) if n}
    matched = [r for r in rows if normalise_ref(r.get("invoiceNo")) in wanted] \
        if wanted else []

    if matched:
        head = dict(matched[0])
        if len(matched) > 1:
            # Several invoice rows under one remittance: the party and currency
            # are the record's, the amount is the sum of the rows matched.
            total = sum(float(r.get("invoiceAmount") or 0) for r in matched)
            head["invoiceAmount"] = round(total, 2)
            head["invoiceNo"] = ", ".join(str(r.get("invoiceNo")) for r in matched)
            head["matchedInvoiceCount"] = len(matched)
        return head

    if len(rows) == 1 and not wanted:
        # One row and nothing to tie it to: the Bill of Entry is unambiguous.
        return dict(rows[0])

    if len(rows) == 1 and wanted:
        # One row, but it answers to none of this consignment's invoices. Say so
        # rather than matching it anyway.
        return None

    return None


def why_no_match(boe: str, invoice_nos: list[str] | None = None) -> str | None:
    """A sentence explaining a failed match, for the maker."""
    rows = rows_for_bill_of_entry(boe)
    if not rows:
        return (f"TradePay holds no record against Bill of Entry {boe}.")
    others = sorted({str(r.get("invoiceNo")) for r in rows})
    return (f"TradePay holds {len(rows)} row(s) against Bill of Entry {boe}, but "
            f"none of them carries an invoice number from this consignment. The "
            f"rows are for {', '.join(others[:5])}"
            f"{', and others' if len(others) > 5 else ''}, which belong to a "
            "different consignment under the same Bill of Entry.")


def for_bill_of_entry(boe: str, invoice_no: str | None = None) -> dict | None:
    """Kept for the mock API, which looks a Bill of Entry up on its own."""
    return for_consignment(boe, [invoice_no] if invoice_no else None) \
        or (rows_for_bill_of_entry(boe) or [None])[0]


def for_importer(name: str) -> list[dict]:
    want = normalise_name(name)
    return [r for r in all_records() if normalise_name(r.get("entity")) == want]
