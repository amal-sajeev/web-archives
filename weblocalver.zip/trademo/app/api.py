"""The application's own JSON API.

The screens are server-rendered from the same store these routes read, so the
pages work without JavaScript; every change a maker makes goes through here.

The external systems are mocked separately under /api/mock.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel

from .models import (
    ActionResult,
    CaseStatus,
    CheckResolution,
    CollectionCase,
    PortEntry,
    QueryCreate,
    ValidationRequest,
)
from .store import CaseStore, get_store

router = APIRouter(prefix="/api", tags=["collections"])


def _case(store: CaseStore, case_id: str) -> CollectionCase:
    case = store.get(case_id)
    if case is None:
        raise HTTPException(404, f"Case {case_id} not found")
    return case


def _next_href(store: CaseStore, current: CollectionCase) -> str:
    queue = [c for c in store.list_cases(view="all")
             if c.case_id != current.case_id
             and (c.needs_maker or c.status is CaseStatus.READY_FOR_REVIEW)]
    return f"/cases/{queue[0].case_id}" if queue else "/"


def _snapshot(case: CollectionCase) -> dict[str, Any]:
    return {
        "case_id": case.case_id,
        "status": case.status.value,
        "status_label": case.status_label,
        "status_tone": case.status_tone,
        "blockers": case.blockers,
        "ready_to_validate": case.ready_to_validate,
        "checks_passed": case.checks_passed,
        "checks_total": case.checks_total,
        "charges_total": case.charges.total,
        "charges_status": case.charges.status,
        "open_queries": len(case.open_queries),
        "audit": [{"at": e.at.strftime("%d %b %H:%M"), "actor": e.actor,
                   "role": e.role, "action": e.action, "detail": e.detail}
                  for e in case.audit],
    }


def _ok(case: CollectionCase, message: str, store: CaseStore | None = None,
        **extra: Any) -> ActionResult:
    data = _snapshot(case)
    if store is not None:
        data["next"] = _next_href(store, case)
    data.update(extra)
    return ActionResult(ok=True, message=message, case_id=case.case_id,
                        status=case.status.value, status_label=case.status_label,
                        status_tone=case.status_tone, data=data)


# ------------------------------------------------------------------ session

class RoleSwitch(BaseModel):
    role: str


@router.post("/session/role")
def switch_role(body: RoleSwitch, store: CaseStore = Depends(get_store)) -> dict[str, str]:
    store.session.switch(body.role)
    return {"role": store.session.role, "name": store.session.name}


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "trade-collections-maker-workbench"}


@router.get("/checks/sources")
def check_sources() -> dict[str, Any]:
    """The cascade each consistency check reads its reference value from.

    The procedure writes every check as
    "Trade Pay <-> IDPMS / Trade Pay Documents / WFMS", so the reference is
    three systems deep. Only IDPMS is connected; the other two report
    themselves unavailable rather than being silently skipped.
    """
    from .sources import fallback
    return fallback.status()


class DemoReset(BaseModel):
    run: bool = True


@router.post("/demo/reset")
def reset_demo(body: DemoReset = DemoReset(),
               store: CaseStore = Depends(get_store)) -> dict[str, Any]:
    """Put the demo back to a known state.

    Discards every maker and checker action, re-reads app/data/*.json and
    rebuilds the cases. With ``run`` true (the default) the pipeline is run
    again so the queue opens the way a demo wants it; with it false the cases
    sit unrun so the pipeline can be shown working.
    """
    result = store.reset(run=body.run)
    return {"ok": True, **result, "role": store.session.role}


@router.get("/agent/status")
def agent_status() -> dict[str, Any]:
    """Which model backend the pricing agent would use, and why not the others.

    Vertex first, because that is the deployment target; then the Anthropic API;
    then the claude CLI, which carries its own authentication and is what makes
    the agent runnable on a laptop. With none of them the charge instruction is
    matched by pattern instead of read, and the case says so.
    """
    from .agent import AGENT_VERSION, provider_status
    rows = provider_status()
    live = next((r for r in rows if r["available"]), None)
    return {
        "agentVersion": AGENT_VERSION,
        "active": live["provider"] if live else None,
        "activeModel": live["model"] if live else None,
        "degraded": live is None,
        "note": (f"The agent is reading charge instructions with {live['model']} "
                 f"by way of {live['provider']}." if live else
                 "No model backend is reachable, so charge instructions are matched "
                 "by pattern rather than read. Every case says so on its charges."),
        "providers": rows,
    }


# -------------------------------------------------------------------- reads

@router.get("/cases", response_model=list[CollectionCase])
def list_cases(view: str = "all", search: str | None = None,
               importer: str | None = None, currency: str | None = None,
               status: str | None = None, sort: str | None = None,
               direction: str = "asc",
               store: CaseStore = Depends(get_store)) -> list[CollectionCase]:
    return store.list_cases(view=view, search=search, importer=importer,
                            currency=currency, status=status, sort=sort,
                            direction=direction)


@router.get("/cases/counts")
def counts(store: CaseStore = Depends(get_store)) -> dict[str, int]:
    return store.counts()


@router.get("/cases/live")
def live(store: CaseStore = Depends(get_store)) -> dict[str, Any]:
    return {"cases": [{"case_id": c.case_id, "status": c.status.value,
                       "status_label": c.status_label, "progress": store.progress(c),
                       "checks_passed": c.checks_passed, "checks_total": c.checks_total}
                      for c in store.all_cases()]}


@router.get("/cases/{case_id}", response_model=CollectionCase)
def get_case(case_id: str, store: CaseStore = Depends(get_store)) -> CollectionCase:
    return _case(store, case_id)


@router.get("/cases/{case_id}/state")
def case_state(case_id: str, store: CaseStore = Depends(get_store)) -> dict[str, Any]:
    case = _case(store, case_id)
    data = _snapshot(case)
    data["progress"] = store.progress(case)
    return data


# ---------------------------------------------------------------- mutations

@router.post("/cases/{case_id}/ports/{role}", response_model=ActionResult)
def set_port(case_id: str, role: str, body: PortEntry,
             store: CaseStore = Depends(get_store)) -> ActionResult:
    """Name a port by hand, for use until the directory is available."""
    if role not in ("loading", "discharge"):
        raise HTTPException(400, "role must be 'loading' or 'discharge'")
    case = _case(store, case_id)
    port = store.set_port(case, role, body.name.strip(), body.note)
    if port is None:
        raise HTTPException(404, f"No port of {role} on {case_id}")
    return _ok(case, f"Port of {role} set to {port.name}.", port=port.model_dump())


@router.post("/cases/{case_id}/checks/{check_id}/resolve", response_model=ActionResult)
def resolve_check(case_id: str, check_id: str, body: CheckResolution,
                  store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    check = store.resolve_check(case, check_id, body.resolution)
    if check is None:
        raise HTTPException(400, f"{check_id} is not an open check on {case_id}")
    n = len([c for c in check_id.split(",") if c.strip()])
    message = (f"{check.label} settled." if n == 1
               else f"{n} checks settled on the one reason.")
    return _ok(case, message, check=check.model_dump())


@router.post("/cases/{case_id}/charges/recalculate", response_model=ActionResult)
def recalculate(case_id: str, store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    charges = store.reprice(case)
    return _ok(case, (f"INR {charges.total:,.2f}." if charges.priced
                      else charges.message or "Charges still not settled."),
               charges=charges.model_dump() | {"total": charges.total})


@router.post("/cases/{case_id}/queries", response_model=ActionResult)
def raise_query(case_id: str, body: QueryCreate,
                store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    q = store.raise_query(case, body.reason, body.recipient, body.check_id)
    return _ok(case, f"{q.query_id} sent to {q.recipient}.", query=q.model_dump())


class QueryAnswer(BaseModel):
    response: str


@router.post("/cases/{case_id}/queries/{query_id}/answer", response_model=ActionResult)
def answer_query(case_id: str, query_id: str, body: QueryAnswer,
                 store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    q = store.close_query(case, query_id, body.response)
    if q is None:
        raise HTTPException(404, f"{query_id} not found on {case_id}")
    return _ok(case, f"{q.query_id} answered.", query=q.model_dump())


# ----------------------------------------------------------------- workflow

@router.post("/cases/{case_id}/start", response_model=ActionResult)
def start(case_id: str, store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    if case.status is not CaseStatus.RECEIVED:
        raise HTTPException(400, "Only a case that has not been run can be sent through")
    store.start_processing(case)
    return _ok(case, "Running the port lookups, the checks and the charges.")


@router.post("/cases/run-all", response_model=dict)
def run_all(store: CaseStore = Depends(get_store)) -> dict:
    n = store.run_all()
    return {"ran": n, "message": f"{n} case(s) put through the checks."}


@router.post("/cases/{case_id}/validate", response_model=ActionResult)
def validate(case_id: str, body: ValidationRequest,
             store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    if not (body.source_reviewed and body.exceptions_resolved):
        return ActionResult(ok=False, case_id=case.case_id, data=_snapshot(case),
                            message="Confirm both attestations before validating.")
    ok, message, token = store.validate(case, body.maker_note)
    if not ok:
        return ActionResult(ok=False, case_id=case.case_id, data=_snapshot(case),
                            message=message)
    return _ok(case, message, store=store, undo_token=token)


@router.post("/cases/{case_id}/approve", response_model=ActionResult)
def approve(case_id: str, note: dict = Body(default={}),
            store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    ok, message, token = store.approve(case, note.get("note"))
    if not ok:
        raise HTTPException(400, message)
    return _ok(case, message, undo_token=token, tf3_reference=case.tf3_reference)


class ReturnReason(BaseModel):
    reason: str


@router.post("/cases/{case_id}/return", response_model=ActionResult)
def return_case(case_id: str, body: ReturnReason,
                store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    ok, message, token = store.return_to_maker(case, body.reason)
    if not ok:
        raise HTTPException(400, message)
    return _ok(case, message, undo_token=token)


class UndoRequest(BaseModel):
    token: str


@router.post("/cases/{case_id}/undo", response_model=ActionResult)
def undo(case_id: str, body: UndoRequest,
         store: CaseStore = Depends(get_store)) -> ActionResult:
    case = store.undo(body.token)
    if case is None:
        raise HTTPException(410, "That can no longer be undone.")
    return _ok(case, f"{case.case_id} is back to {case.status_label.lower()}.")
