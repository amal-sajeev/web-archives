"""Config-driven HTTP target adapter.

Describes the HTTP request and response mapping entirely from ``TargetSpec``
config (in ``dataset.json``), so an engineer can wire up a call to any agent
service without writing Python. Supports:

- Any HTTP method (GET/POST/PUT/PATCH/DELETE).
- Headers (static or templated from env/input).
- Auth (bearer / basic / api_key_header / api_key_query) — secrets from env only.
- Query params and body templated from ``case.input`` and env vars.
- Response mapping via dotted paths into JSON (or raw text) into the
  ``Observation`` envelope.
- Document content types (pdf/docx/markdown/json) with automatic text
  extraction so all scorers work on documents out of the box.

Template syntax: ``${env.VAR_NAME}`` and ``${input.dotted.path}``. The pieces
live in ``templating``, ``http_request``, ``http_response`` and ``registry``;
this module keeps the historical import names working.
"""

from __future__ import annotations

import asyncio
import logging
import time

import httpx

from core.models import GoldenCase, Observation, TargetSpec
from service.http_client import build_async_client_kwargs
from .http_request import build_headers, build_params, build_request_kwargs
from .http_response import error_observation, map_response
from .registry import get_registered_adapter, register_adapter
from .templating import dotted, path_parts, resolve_template

_DEFAULT_TIMEOUT = 120.0
# target.retries re-sends only on a transient failure: a connection/read error,
# or a 429/5xx from the agent. A 4xx is the agent's considered answer and is
# never retried, nor is a bad response mapping.
_RETRY_STATUS = frozenset({429, 500, 502, 503, 504})
_RETRY_BACKOFF_BASE_S = 0.5
_RETRY_BACKOFF_MAX_S = 4.0
_MAX_RETRIES = 5
_log = logging.getLogger("eval_service.adapters.http")

# Backward-compatible aliases (custom_tests.py and older tests import these).
_resolve_template = resolve_template
_dotted = dotted
_path_parts = path_parts
_build_headers = build_headers
_build_params = build_params

__all__ = [
    "HttpAdapter",
    "get_registered_adapter",
    "register_adapter",
]


def _elapsed_ms(start: float) -> int:
    return int((time.perf_counter() - start) * 1000)


def _is_transient(exc: BaseException) -> bool:
    """True for a failure worth re-sending the same request for."""
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in _RETRY_STATUS
    return isinstance(exc, httpx.TransportError)


def _retry_delay(attempt: int) -> float:
    return min(_RETRY_BACKOFF_BASE_S * (2 ** attempt), _RETRY_BACKOFF_MAX_S)


class HttpAdapter:
    """Config-driven HTTP adapter — calls any agent HTTP endpoint.

    Selected by ``dataset.target.adapter: "http"``. All request/response
    details come from the ``TargetSpec`` in ``dataset.json``.
    """

    adapter_id = "http"

    def __init__(self, base_url: str, endpoint: str, target: TargetSpec | None = None):
        self._base_url = base_url.rstrip("/")
        self._endpoint = endpoint
        self._target = target or TargetSpec(adapter="http", endpoint=endpoint)

    async def run_case(self, case: GoldenCase) -> Observation:
        """Call the agent, re-sending up to ``target.retries`` times on a
        transient failure. The latency reported covers the whole attempt
        sequence, so a case that needed retries is visibly slower.

        Shaped like ``judge_invoke._invoke_with_retry``: the retryable attempts
        run in the loop and the final one happens after it, so every failure has
        exactly one path to an error Observation.
        """
        target = self._target
        url = f"{self._base_url}{resolve_template(self._endpoint, case.input or {})}"
        client_kwargs = build_async_client_kwargs(
            timeout=target.timeout or _DEFAULT_TIMEOUT, trust_env=target.trust_env
        )
        attempts = 1 + min(max(int(target.retries or 0), 0), _MAX_RETRIES)
        start = time.perf_counter()
        for attempt in range(attempts - 1):
            try:
                return await self._send(case, url, client_kwargs, start)
            except Exception as exc:
                if not _is_transient(exc):
                    return self._failed(case, exc, start, attempt + 1)
                _log.warning("http_target_retrying", extra={
                    "case_id": case.id, "error_type": type(exc).__name__,
                    "attempt": attempt + 1, "attempts": attempts,
                })
                await asyncio.sleep(_retry_delay(attempt))
        try:  # last attempt: a failure here is the result
            return await self._send(case, url, client_kwargs, start)
        except Exception as exc:
            return self._failed(case, exc, start, attempts)

    async def _send(self, case: GoldenCase, url: str, client_kwargs: dict, start: float) -> Observation:
        target = self._target
        request_kwargs = build_request_kwargs(target, case.input or {})
        async with httpx.AsyncClient(**client_kwargs) as client:
            resp = await client.request(target.method.upper(), url, **request_kwargs)
            resp.raise_for_status()
        return map_response(resp, case, target.response, _elapsed_ms(start))

    def _failed(self, case: GoldenCase, exc: Exception, start: float, attempts: int) -> Observation:
        """Every failure becomes an error Observation, never an exception."""
        _log.warning("http_target_failed", extra={
            "case_id": case.id, "error_type": type(exc).__name__, "attempts": attempts,
        })
        return error_observation(case.id, exc, _elapsed_ms(start))
