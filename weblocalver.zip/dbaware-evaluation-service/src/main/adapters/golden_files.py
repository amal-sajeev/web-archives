"""Resolve a GoldenCase.golden_file reference (relative path or data URL) to text."""

from __future__ import annotations

import base64
import binascii
import re
from pathlib import Path

from .documents import try_extract_text

_DOC_KINDS = ("pdf", "docx")


def _decode_document(raw: bytes, kind: str, label: str) -> str:
    if kind not in _DOC_KINDS:
        return raw.decode("utf-8", errors="replace")
    text, error = try_extract_text(raw, kind, output_kind="bytes")
    if error:
        # An unreadable golden must not silently become "" (every comparison would score 0).
        raise ValueError(f"golden_file {label} could not be read as {kind.upper()}: {error}")
    return text


def _kind_from_ctype(ctype: str) -> str:
    if "pdf" in ctype:
        return "pdf"
    # Only Word documents: other Office types (xlsx, pptx) are not DOCX and cannot be parsed as one.
    if "wordprocessingml" in ctype or "msword" in ctype:
        return "docx"
    return "text"


def _decode_data_url(data_url: str) -> str:
    m = re.match(r"data:([^;,]+)(?:;[^;,]+)*;base64,(.+)", data_url, re.S)
    if not m:
        raise ValueError("golden_file data URL must be data:<content-type>;base64,<payload>")
    try:
        raw = base64.b64decode(m.group(2), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("golden_file data URL has an invalid base64 payload") from exc
    return _decode_document(raw, _kind_from_ctype(m.group(1).lower()), "data URL")


def load_golden_file(path_or_data_url: str, agent_folder: Path) -> str:
    """Resolve a golden_file reference to text.

    Accepts a path relative to the agent folder, or a ``data:<ctype>;base64,...``
    data URL. A missing file raises ``FileNotFoundError``; an unreadable PDF/DOCX
    or malformed data URL raises ``ValueError``.
    """
    if path_or_data_url.startswith("data:"):
        return _decode_data_url(path_or_data_url)
    root = agent_folder.resolve()
    p = (root / path_or_data_url).resolve()
    if not p.is_relative_to(root):
        raise ValueError("golden_file path must stay within the agent folder")
    if not p.is_file():
        raise FileNotFoundError(f"golden_file not found: {p}")
    suffix = p.suffix.lower().lstrip(".")
    return _decode_document(p.read_bytes(), suffix if suffix in _DOC_KINDS else "text", path_or_data_url)
