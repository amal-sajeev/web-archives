"""Capture service: turns each live agent run into a CTA_ACTION.

Instead of reading a stub file or calling an external metrics database/API, this
derives a CTA_ACTION record from the Observation the target adapter already
returns (tool calls, token usage, latency, model, error/confidence). The derived
records are held in an in-memory store — so the sample agents can be run and the
evaluation service exercised end-to-end with no database connection.

The derived metric map is produced by the *same* `derive_metrics` flattening the
stub/HTTP clients use, so scorers and the gate are identical across sources.
"""

from __future__ import annotations

import logging
from collections import OrderedDict, deque
from datetime import datetime, timedelta, UTC
from typing import Any

from core.models import Observation
from .metrics_api import derive_metrics

_log = logging.getLogger("eval_service.adapters.capture")

_TS_FMT = "%Y-%m-%d %H:%M:%S:%f"
# These records are synthesized by the evaluation service from an observed run,
# not emitted by the agent's own pipeline, so they carry a neutral activity
# type rather than borrowing one agent's (e.g. "Preliminary_Research").
_ACTIVITY_TYPE = "Agent_Evaluation"
_MAX_HISTORY = 500
_MAX_ENTRIES = 5_000

CaptureKey = tuple[str | None, str]


class CaptureStore:
    """In-memory store of captured CTA_ACTION records, keyed by (agent_id, case_id).

    Both the latest-per-case map and the history are bounded; the oldest
    entries are evicted first.
    """

    def __init__(self, max_entries: int = _MAX_ENTRIES, max_history: int = _MAX_HISTORY) -> None:
        self._by_key: OrderedDict[CaptureKey, dict[str, Any]] = OrderedDict()
        self._history: deque[dict[str, Any]] = deque(maxlen=max(1, max_history))
        self._max_entries = max(1, max_entries)

    def put(self, case_id: str, action: dict[str, Any], *, agent_id: str | None = None) -> None:
        key = (agent_id, case_id)
        self._by_key.pop(key, None)
        self._by_key[key] = action
        while len(self._by_key) > self._max_entries:
            self._by_key.popitem(last=False)
        self._history.append(action)

    def get(self, case_id: str, *, agent_id: str | None = None) -> dict[str, Any] | None:
        """Latest action for a case; scoped to ``agent_id`` when one is given."""
        if agent_id is not None:
            return self._by_key.get((agent_id, case_id))
        for (_, cid), action in reversed(self._by_key.items()):
            if cid == case_id:
                return action
        return None

    def latest(self, *, agent_id: str | None = None) -> dict[str, dict[str, Any]]:
        """case_id -> most recent action (optionally for one agent only)."""
        out: dict[str, dict[str, Any]] = {}
        for (aid, cid), action in self._by_key.items():
            if agent_id is None or aid == agent_id:
                out[cid] = action
        return out

    def history(self) -> list[dict[str, Any]]:
        return list(self._history)

    def clear(self) -> None:
        self._by_key.clear()
        self._history.clear()


# Module-level singleton so the FastAPI app can expose the captured records.
capture_store = CaptureStore()


def _confidence(observation: Observation) -> float:
    """Confidence the agent reported, else infer from success/error."""
    meta = observation.metadata or {}
    for key in ("ai_confidence", "confidence", "AI_Confidence_Score"):
        if key in meta:
            try:
                return float(meta[key])
            except (TypeError, ValueError):
                _log.debug("non-numeric confidence %r in metadata[%s]", meta[key], key)
    return 0.0 if observation.error else 1.0


def observation_to_cta_action(
    case_id: str, observation: Observation, *, agent_id: str | None = None
) -> dict[str, Any]:
    """Synthesize a CTA_ACTION envelope from a live agent Observation.

    ``agent_id`` names the agent under test. ``observation.target_id`` is the
    *case* id, so without an explicit ``agent_id`` the record would label the
    acting agent with a case name -- wrong in an audit trail.
    """
    usage = observation.usage or {}
    start = datetime.now(UTC)
    end = start + timedelta(milliseconds=observation.latency_ms or 0)

    tool_calls: list[dict[str, Any]] = []
    for call in observation.tool_calls:
        tool_calls.append(
            {
                "Tool_Id": call.get("name") or call.get("Tool_Id") or "",
                "Call_Count": "1",
                "Tool_Param": str(call.get("args") or call.get("Tool_Param") or ""),
                "Tool_Latency": str(call.get("latency_ms", "")),
                "Tool_Errors": [observation.error] if observation.error else [""],
            }
        )

    return {
        "CTA_ACTION": {
            "action_id": f"capture-{case_id}",
            "plan_review_item_id": case_id,
            "timestamp": start.strftime(_TS_FMT),
            "actor_type": "AI_AGENT",
            "actor_email": "",
            "action_type": "AGENT_RUN",
            "target_entity_type": "case",
            "target_entity_id": case_id,
            "payload": {
                "Agent_Name": agent_id or "",
                "Activity_Type": _ACTIVITY_TYPE,
                "AI_Model_Name": observation.model or "",
                "AI_Rationale": "",
                "AI_Confidence_Score": _confidence(observation),
                "Token_Input_Count": str(usage.get("input_tokens", "")),
                "Token_Output_Count": str(usage.get("output_tokens", "")),
                "Tool_Calls": tool_calls,
                "Response_Code": "502" if observation.error else "200",
                "Response_Text": observation.error or "OK",
                "Execution_Start_Time": start.strftime(_TS_FMT),
                "Execution_End_Time": end.strftime(_TS_FMT),
                "Remarks": "captured from live agent run",
            },
        }
    }


class CaptureMetricsClient:
    """Derives metrics from the live Observation and records the CTA_ACTION."""

    def __init__(self, store: CaptureStore, agent_id: str | None = None):
        self._store = store
        self._agent_id = agent_id

    async def fetch(self, case_id: str, observation: Observation | None = None) -> dict[str, float]:
        if observation is None:
            existing = self._store.get(case_id, agent_id=self._agent_id)
            return derive_metrics(existing["CTA_ACTION"]) if existing else {}
        action = observation_to_cta_action(case_id, observation, agent_id=self._agent_id)
        self._store.put(case_id, action, agent_id=self._agent_id)
        return derive_metrics(action["CTA_ACTION"])
