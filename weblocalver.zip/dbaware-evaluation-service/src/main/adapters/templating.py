"""``${env.VAR}`` / ``${input.path}`` templating and dotted-path lookups.

Shared by the HTTP adapter (request templating, response mapping) and any
scorer that needs the same ``data.items[0].id`` path syntax.

Rules:
- A string that is *exactly* one placeholder keeps the resolved value's type
  (``"${input.count}"`` -> ``3``, a dict stays a dict).
- A placeholder embedded in a longer string is replaced by text: missing values
  become ``""``, strings are inserted as-is, anything else is JSON-encoded.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any

_TEMPLATE_RE = re.compile(r"\$\{(env|input)\.([a-zA-Z0-9_.\[\]]+)\}")
_BRACKET_RE = re.compile(r"\[(\d+)\]")


class _Missing:
    """Sentinel for "the path is not present", distinct from a present ``None``."""

    __slots__ = ()

    def __repr__(self) -> str:
        return "<missing>"

    def __bool__(self) -> bool:
        return False


MISSING = _Missing()
"""Returned by :func:`lookup_strict` when a path segment does not exist."""


def path_parts(path: str | None) -> list[str]:
    """Split ``data.items[0].id`` or ``data.items.0.id`` into path segments."""
    normalized = _BRACKET_RE.sub(r".\1", path or "")
    return [p for p in normalized.split(".") if p]


def _step(cur: Any, part: str) -> tuple[bool, Any]:
    if isinstance(cur, dict):
        return part in cur, cur.get(part)
    if isinstance(cur, list):
        try:
            return True, cur[int(part)]
        except (ValueError, IndexError):
            return False, None
    return False, None


def lookup_strict(obj: Any, path: str | None) -> Any:
    """Look up a dotted/bracket path; :data:`MISSING` when a segment is absent.

    Use this wherever "key absent" must be told apart from "key present but
    null" -- an existence check, or an output mapping that should report a
    missing path but accept an explicit null.
    """
    cur: Any = obj
    for part in path_parts(path):
        found, cur = _step(cur, part)
        if not found:
            return MISSING
    return cur


def dotted(obj: Any, path: str | None) -> Any:
    """Look up a dotted/bracket path in nested dicts/lists; None if missing."""
    value = lookup_strict(obj, path)
    return None if value is MISSING else value


def _lookup(scope: str, path: str, case_input: dict[str, Any]) -> Any:
    if scope == "env":
        return os.environ.get(path, "")
    return dotted(case_input, path)


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=str)


def _resolve_string(value: str, case_input: dict[str, Any]) -> Any:
    whole = _TEMPLATE_RE.fullmatch(value)
    if whole:
        resolved = _lookup(whole.group(1), whole.group(2), case_input)
        return "" if resolved is None else resolved
    return _TEMPLATE_RE.sub(
        lambda m: _as_text(_lookup(m.group(1), m.group(2), case_input)), value
    )


def resolve_template(value: Any, case_input: dict[str, Any]) -> Any:
    """Recursively substitute ``${env.VAR}`` / ``${input.path}`` in strings, dicts and lists."""
    if isinstance(value, str):
        return _resolve_string(value, case_input)
    if isinstance(value, dict):
        return {k: resolve_template(v, case_input) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_template(v, case_input) for v in value]
    return value


def resolve_text_map(values: dict[str, str], case_input: dict[str, Any]) -> dict[str, str]:
    """Resolve a header/param map; every resolved value is coerced to text."""
    return {k: _as_text(resolve_template(v, case_input)) for k, v in values.items()}
