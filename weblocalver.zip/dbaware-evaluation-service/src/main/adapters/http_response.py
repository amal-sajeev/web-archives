"""Response mapping for the config-driven HTTP adapter.

Turns an ``httpx.Response`` into an ``Observation`` using the dotted paths in
``ResponseMapping``; sanitises the mapped values so a malformed agent response
produces an Observation with ``error`` set instead of an exception.
"""

from __future__ import annotations

import json
import logging
import math
from dataclasses import dataclass
from typing import Any

import httpx

from core.models import GoldenCase, Observation, ResponseMapping
from service.http_errors import describe_http_error
from .documents import DocUnavailable, detect_content_type, try_extract_text
from .templating import MISSING, dotted, lookup_strict

_log = logging.getLogger("eval_service.adapters.http")

_ERROR_BODY_LEN = 500
_DOC_TYPES = frozenset({"pdf", "docx"})
_BINARY_KINDS = frozenset({"base64", "bytes", "url"})
# Content-Type header fragment -> content type, checked in order.
_HEADER_TYPES = (("pdf", "pdf"), ("msword", "docx"), ("officedocument", "docx"),
                 ("markdown", "markdown"), ("json", "json"))


def error_observation(case_id: str, exc: BaseException, latency_ms: int | float = 0) -> Observation:
    """Shared exception -> Observation mapping for every target adapter.

    HTTP status errors keep the ``HTTP <code>: <body>`` form. Transport failures
    lead with a plain sentence (see ``service.http_errors``), for example
    "Could not connect to the agent. ... (ConnectError: ...)".
    """
    if isinstance(exc, httpx.HTTPStatusError):
        text = exc.response.text[:_ERROR_BODY_LEN].strip() or exc.response.reason_phrase
        message = f"HTTP {exc.response.status_code}: {text}"
    else:
        message = describe_http_error(exc)
    return Observation(target_id=case_id, error=message, latency_ms=latency_ms)


@dataclass
class _Parsed:
    body: Any
    is_json: bool
    raw: bytes
    header_type: str

    def lookup(self, path: str | None) -> Any:
        if not path or not self.is_json:
            return None
        return dotted(self.body, path)

    def lookup_strict(self, path: str) -> Any:
        """Like :meth:`lookup` but returns ``MISSING`` for an absent path."""
        return lookup_strict(self.body, path) if self.is_json else MISSING


def _parse(resp: httpx.Response) -> _Parsed:
    ct_hdr = resp.headers.get("content-type", "").lower()
    header_type = next((kind for frag, kind in _HEADER_TYPES if frag in ct_hdr), "")
    if header_type in _DOC_TYPES:
        return _Parsed(resp.content, False, resp.content, header_type)
    try:
        return _Parsed(resp.json(), True, resp.content, header_type)
    except ValueError:
        return _Parsed(resp.text, False, resp.content, header_type)


def _sanitise_usage(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _sanitise_tool_calls(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [c if isinstance(c, dict) else {"name": str(c)} for c in value]


def _sanitise_latency(value: Any, measured: int | float) -> int | float:
    if value is None or isinstance(value, bool):
        return measured
    try:
        latency = float(value)
    except (TypeError, ValueError):
        return measured
    return latency if math.isfinite(latency) and latency >= 0 else measured


def _sanitise_error(value: Any) -> str | None:
    if value is None or value == "" or value is False:
        return None
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)


def _resolve_output(rm: ResponseMapping, parsed: _Parsed) -> tuple[Any, str | None]:
    """Return (output, mapping_error).

    An absent ``output_path`` is a mapping error; a path that is present but
    holds JSON ``null`` is not -- the agent answered, it just answered with
    nothing, which the scorers report as an empty output.
    """
    if not rm.output_path:
        return parsed.body, None
    if not parsed.is_json:
        return parsed.body, f"output_path '{rm.output_path}' set but the response is not JSON"
    output = parsed.lookup_strict(rm.output_path)
    if output is MISSING:
        return None, f"output_path '{rm.output_path}' not found in response"
    return output, None


def _content_type(rm: ResponseMapping, parsed: _Parsed, output: Any) -> str:
    if rm.content_type != "auto":
        return rm.content_type
    if not rm.output_path and parsed.header_type:
        return parsed.header_type
    return detect_content_type(output, rm.output_kind)


def _extract_document(output: Any, content_type: str, output_kind: str, meta: dict[str, Any]) -> Any:
    """For pdf/docx outputs keep the raw value and replace output with its text."""
    if content_type not in _DOC_TYPES:
        return output
    is_binary = isinstance(output, bytes | bytearray)
    if output_kind not in _BINARY_KINDS and not is_binary:
        return output  # already text-extracted by the agent itself
    kind = "bytes" if is_binary and output_kind not in _BINARY_KINDS else output_kind
    meta["raw_output"] = output
    try:
        text, error = try_extract_text(output, content_type, output_kind=kind)
    except DocUnavailable as exc:
        _log.warning("document extraction unavailable: %s", exc)
        meta["extraction_error"] = str(exc)
        return output
    if error:
        meta["extraction_error"] = error
    meta["extracted_text"] = text
    return text


def _source_context(rm: ResponseMapping, parsed: _Parsed) -> Any:
    if rm.source_context_path:
        return parsed.lookup(rm.source_context_path)
    if parsed.is_json and isinstance(parsed.body, dict):
        return parsed.body.get("source_context")
    return None


def map_response(
    resp: httpx.Response, case: GoldenCase, rm: ResponseMapping, latency_ms: int | float
) -> Observation:
    """Map an HTTP response into an Observation using ``rm``."""
    parsed = _parse(resp)
    output, mapping_error = _resolve_output(rm, parsed)
    content_type = _content_type(rm, parsed, output)
    metadata = parsed.lookup(rm.metadata_path)
    meta = dict(metadata) if isinstance(metadata, dict) else {}
    meta["content_type"] = content_type
    meta["output_kind"] = rm.output_kind
    output = _extract_document(output, content_type, rm.output_kind, meta)
    model = parsed.lookup(rm.model_path)
    return Observation(
        target_id=case.id,
        output=output,
        tool_calls=_sanitise_tool_calls(parsed.lookup(rm.tool_calls_path)),
        usage=_sanitise_usage(parsed.lookup(rm.usage_path)),
        model=model if isinstance(model, str) else None,
        latency_ms=_sanitise_latency(parsed.lookup(rm.latency_path), latency_ms),
        metadata=meta,
        error=_sanitise_error(parsed.lookup(rm.error_path)) or mapping_error,
        source_context=_source_context(rm, parsed),
    )
