"""AI Access Layer / Vertex AI judge model factory.

Supports routing through the Deutsche Bank AI Access Layer Gateway when
``AI_ACCESS_LAYER_BASE_URL`` is configured (using ``GoogleOAuthTokenProvider``
with ``cloud-platform`` + ``userinfo.email`` scopes and CA bundle configuration),
while preserving fallback compatibility with direct Vertex AI (`project=...`).

`google.auth` and `langchain_google_genai` are imported lazily so importing the
scorer package stays cheap and works where the Google SDKs are not installed.
Retries happen in one layer only (`judge_invoke`), so the client is built with
``max_retries=0``.
"""

from __future__ import annotations

import logging
import os
import tempfile
import threading
import time
from typing import Any

from pydantic import BaseModel, Field

from core.config import Config

logger = logging.getLogger(__name__)

# Resolved ADC credentials are re-used for this long before re-resolving, so a
# rotated or revoked credential is noticed without resolving on every call.
_CREDENTIALS_TTL_S = 300.0
_CREDS_LOCK = threading.Lock()
_CREDS_CACHE: dict[str, tuple[float, str]] = {}

_CERTIFICATE_CONFIGURED = False
_OAUTH_SCOPES = [
    "https://www.googleapis.com/auth/cloud-platform",
    "https://www.googleapis.com/auth/userinfo.email",
]


def _ai_access_layer_base_url() -> str | None:
    raw = os.getenv("AI_ACCESS_LAYER_BASE_URL") or getattr(Config, "AI_ACCESS_LAYER_BASE_URL", None)
    cleaned = str(raw or "").strip()
    return cleaned or None


def _is_local_cert_auth_enabled() -> bool:
    """Enables custom certificate auth only when explicitly turned on (local dev)."""
    raw_value = str(os.getenv("ENABLE_LOCAL_CERT_AUTH", "")).strip().lower()
    return raw_value == "true"


def _is_local_runtime() -> bool:
    """Treat Kubernetes runtime as non-local; everything else defaults to local."""
    return not bool(os.getenv("KUBERNETES_SERVICE_HOST"))


def _set_ssl_bundle_env(path: str) -> None:
    """Set SSL bundle environment variables without overriding pre-existing values."""
    os.environ.setdefault("REQUESTS_CA_BUNDLE", path)
    os.environ.setdefault("SSL_CERT_FILE", path)
    os.environ.setdefault("GRPC_DEFAULT_SSL_ROOTS_FILE_PATH", path)


def configure_certificate(custom_cert_paths: list[str]) -> str:
    """Combines certifi's default CA bundle with one or more custom certificates
    and sets the required environment variables.
    """
    if not custom_cert_paths:
        raise ValueError("No custom certificate paths are set")

    import certifi

    with open(certifi.where(), "r", encoding="utf-8") as f:
        ca_bundle = f.read()

    custom_certs: list[str] = []
    for custom_cert_path in custom_cert_paths:
        if not os.path.exists(custom_cert_path):
            raise FileNotFoundError(f"Certificate file not found: {custom_cert_path}")

        with open(custom_cert_path, "r", encoding="utf-8") as f:
            custom_cert = f.read()

        if "-----BEGIN CERTIFICATE-----" not in custom_cert:
            raise ValueError(f"Certificate file is not PEM format: {custom_cert_path}")
        custom_certs.append(custom_cert)

    # Create a combined bundle file in the same directory as the custom cert,
    # falling back to tempfile if the folder is OneDrive-protected or read-only.
    combined_path = os.path.join(os.path.dirname(custom_cert_paths[0]), "combined-ca-bundle.pem")
    try:
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)
    except OSError:
        combined_path = os.path.join(tempfile.gettempdir(), "combined-ca-bundle.pem")
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)

    os.environ["REQUESTS_CA_BUNDLE"] = combined_path
    os.environ["SSL_CERT_FILE"] = combined_path
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = combined_path
    return combined_path


def _configure_certificate_once() -> None:
    global _CERTIFICATE_CONFIGURED
    if _CERTIFICATE_CONFIGURED:
        return

    if not _is_local_runtime():
        configured_path = (os.getenv("CA_BUNDLE_PATH") or getattr(Config, "CA_BUNDLE_PATH", "") or "").strip()
        if configured_path:
            _set_ssl_bundle_env(configured_path)
            logger.info("Configured SSL CA bundle from CA_BUNDLE_PATH: %s", configured_path)
        else:
            logger.info("CA_BUNDLE_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    if not _is_local_cert_auth_enabled():
        logger.info("Local certificate auth is disabled; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    custom_paths = str(os.getenv("CUSTOM_CERT_PATHS") or "").strip()
    if custom_paths:
        cert_paths = [p.strip() for p in custom_paths.split(",") if p.strip()]
    else:
        legacy_path = str(os.getenv("CUSTOM_CERT_PATH") or "").strip()
        cert_paths = [legacy_path] if legacy_path else []

    if not cert_paths:
        logger.info("CUSTOM_CERT_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    combined_path = configure_certificate(cert_paths)
    logger.info("Custom certificate bundle configured at: %s", combined_path)
    _CERTIFICATE_CONFIGURED = True


class GoogleOAuthTokenProvider:
    def __init__(self) -> None:
        import google.auth
        import google.auth.transport.requests

        try:
            self.credentials, _ = google.auth.default(scopes=_OAUTH_SCOPES)
        except TypeError:
            self.credentials, _ = google.auth.default()
        self.request = google.auth.transport.requests.Request()

    @property
    def token(self) -> str | None:
        if not getattr(self.credentials, "valid", False):
            refresh = getattr(self.credentials, "refresh", None)
            if callable(refresh):
                refresh(self.request)
        return getattr(self.credentials, "token", None)


class JudgeVerdict(BaseModel):
    """Typed judge output. `passed` is re-applied in code, never trusted here."""
    score: float = Field(ge=0.0, le=1.0)
    passed: bool = False
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)


class PairwiseVerdict(BaseModel):
    """Typed A/B comparison output. `winner` is 'A', 'B', or 'tie'.

    `score` is the preference strength for candidate A: 1.0 = A clearly
    better, 0.5 = tie, 0.0 = B clearly better.
    """
    winner: str = Field(default="tie", description="'A' | 'B' | 'tie'")
    score: float = Field(default=0.5, ge=0.0, le=1.0)
    rationale: str = ""
    evidence: list[str] = Field(default_factory=list)


class RubricCriterionScore(BaseModel):
    """One criterion's score in a multi-criteria rubric verdict."""
    criterion: str
    score: float = Field(ge=0.0, le=1.0)
    rationale: str = ""


class MultiRubricVerdict(BaseModel):
    """Typed multi-criteria judge output. Each criterion gets its own score."""
    scores: list[RubricCriterionScore] = Field(default_factory=list)
    overall_rationale: str = ""


def _resolve_credentials() -> str:
    try:
        _configure_certificate_once()
        import google.auth

        try:
            creds, _ = google.auth.default(scopes=_OAUTH_SCOPES)
        except TypeError:
            creds, _ = google.auth.default()
    except Exception as exc:
        raise RuntimeError(
            "No Application Default Credentials available for Vertex AI. "
            "Locally, run: gcloud auth application-default login. "
            "In GKE, check the Workload Identity Federation credential config is "
            f"mounted and GOOGLE_APPLICATION_CREDENTIALS points at it. ({exc})"
        ) from exc
    return type(creds).__name__


def require_vertex_credentials() -> str:
    """Guard + return the resolved ADC credential class name (for /api/health).

    The resolution is cached for ``_CREDENTIALS_TTL_S`` seconds; failures are
    never cached, so fixing credentials takes effect on the next call.
    """
    if not Config.PROJECT_NAME:
        raise RuntimeError(
            "PROJECT_NAME is not set; the evaluation judge requires Vertex AI. "
            "Set PROJECT_NAME (environment or config file) to your Google Cloud project id."
        )
    now = time.monotonic()
    with _CREDS_LOCK:
        cached = _CREDS_CACHE.get(Config.PROJECT_NAME)
        if cached and now - cached[0] < _CREDENTIALS_TTL_S:
            return cached[1]
    name = _resolve_credentials()
    with _CREDS_LOCK:
        _CREDS_CACHE[Config.PROJECT_NAME] = (now, name)
    return name


def reset_credentials_cache() -> None:
    """Forget cached ADC resolutions (tests / credential rotation)."""
    global _CERTIFICATE_CONFIGURED
    with _CREDS_LOCK:
        _CREDS_CACHE.clear()
        _CERTIFICATE_CONFIGURED = False


def build_judge():
    """Return a ChatGoogleGenerativeAI bound to structured JudgeVerdict output."""
    return build_judge_for(JudgeVerdict)


# Judge clients are expensive to construct (ADC resolution + client wiring) and
# are safe to share across threads. Under the runner's concurrent per-metric
# dispatch many scorers request a client for the same schema at once, so memoise
# one client per structured-output schema behind a lock.
_JUDGE_CACHE: dict[object, object] = {}
_JUDGE_CACHE_LOCK = threading.Lock()


def _new_client():
    from langchain_google_genai import ChatGoogleGenerativeAI

    _configure_certificate_once()
    timeout = float(Config.JUDGE_CALL_TIMEOUT or 0)
    base_url = _ai_access_layer_base_url()
    if base_url:
        provider = GoogleOAuthTokenProvider()
        return ChatGoogleGenerativeAI(
            model=Config.JUDGE_MODEL,
            api_key=provider.token,
            base_url=base_url,
            temperature=Config.JUDGE_TEMPERATURE,
            max_retries=0,                     # retries live in judge_invoke only
            timeout=timeout if timeout > 0 else None,
        )
    return ChatGoogleGenerativeAI(
        model=Config.JUDGE_MODEL,
        project=Config.PROJECT_NAME,       # project= is the switch -> Vertex
        location=Config.PROJECT_LOCATION,
        temperature=Config.JUDGE_TEMPERATURE,
        max_retries=0,                     # retries live in judge_invoke only
        timeout=timeout if timeout > 0 else None,
    )


def initialize_gemini_model() -> Any:
    """Initialize a ChatGoogleGenerativeAI model instance via the AI Access Layer or Vertex."""
    require_vertex_credentials()
    return _new_client()


def build_judge_for(schema):
    """Return a Vertex / AI Access Layer judge bound to an arbitrary structured-output schema."""
    require_vertex_credentials()
    with _JUDGE_CACHE_LOCK:
        client = _JUDGE_CACHE.get(schema)
        if client is None:
            client = _new_client().with_structured_output(schema)
            _JUDGE_CACHE[schema] = client
        return client


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed texts through the AI Access Layer or Vertex (same ADC path as the judge).

    Raises RuntimeError when credentials/model are unavailable so callers can
    convert it to a MetricSkipped and keep offline runs green.
    """
    require_vertex_credentials()
    try:
        from langchain_google_genai import GoogleGenerativeAIEmbeddings

        _configure_certificate_once()
        base_url = _ai_access_layer_base_url()
        if base_url:
            provider = GoogleOAuthTokenProvider()
            embedder = GoogleGenerativeAIEmbeddings(
                model=Config.EMBEDDING_MODEL,
                google_api_key=provider.token,
                base_url=base_url,
            )
        else:
            embedder = GoogleGenerativeAIEmbeddings(
                model=Config.EMBEDDING_MODEL,
                project=Config.PROJECT_NAME,
                location=Config.PROJECT_LOCATION,
            )
        return embedder.embed_documents(texts)
    except Exception as exc:
        raise RuntimeError(f"embedding model unavailable: {exc}") from exc
