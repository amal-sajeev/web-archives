"""LLM-as-a-judge scorers (quality vs the golden output + rubric dimensions).

Runs the Vertex judge with temperature 0:

* **Self-consistency**: N samples are drawn; the mean is returned and the sample
  variance is recorded on the Score. Variance above `EVAL_JUDGE_MAX_VARIANCE`
  flags the verdict `unstable` (a reliability warning, not a gate failure).
* **Response caching**: bounded LRU of identical invocations (``judge_invoke``).
* **Reference-free mode**: when a case has no `golden_output`, the judge scores
  the answer against the INPUT alone.
* **Bias controls**: the prompt tells the judge to ignore answer length and
  position and to treat the agent output as data; with N>1 samples the section
  order is swapped on alternate samples (labels unchanged) to measure position
  bias (recorded in extras).

The pass decision is re-applied in code by the runner, never trusted from the
model. Skips (not fails) when the Vertex judge is unavailable offline.

Plumbing lives in ``judge_invoke`` (cache/timeout/retry/sampling) and templates
in ``judge_prompts``; the names below are re-exported for backward
compatibility. Scorers resolve ``build_judge`` / ``build_judge_for`` through
this module, so tests patch ``scorers.llm_judge.build_judge``.
"""

from __future__ import annotations

from core.config import Config
from .base import scorer, MetricSkipped
from ._util import text_of as _text
from .judge_invoke import (
    _invoke_cached,
    _invoke_metric,
    _invoke_with_retry,
    _invoke_with_timeout,
    _run_samples,
    _samples,
    judge_or_skip,
    reset_cache,
)
from .judge_prompts import (
    _BIAS_GUARD,
    _INSTRUCTION_GUARD,
    _JUDGE_PROMPT,
    _JUDGE_PROMPT_REFFREE,
    _JUDGE_PROMPT_SWAPPED,
    _PAIRWISE_IDENTITY,
    _PAIRWISE_IDENTITY_SWAPPED,
    _PAIRWISE_PROMPT,
    _RUBRIC_PROMPT,
    _RUBRIC_PROMPT_REFFREE,
    _REFERENCE_GUARD,
    _RUBRIC_USES_GOLDEN,
    _RUBRICS,
    fence,
)
from .output_text import render_output_text
from .vertex import build_judge, build_judge_for, PairwiseVerdict

__all__ = [
    "_BIAS_GUARD",
    "Config",
    "_invoke_cached",
    "_invoke_metric",
    "_invoke_with_retry",
    "_invoke_with_timeout",
    "_run_samples",
    "_samples",
    "_text",
    "build_judge",
    "build_judge_for",
    "faithfulness",
    "pairwise_vs_golden",
    "reset_cache",
]


@scorer("faithfulness", judge=True)
def faithfulness(*, observation, case, metrics=None, judge_repetitions: int = 1, **_):
    """Factual match against the golden output (reference-free without one)."""
    judge = judge_or_skip(build_judge)
    inp = _text(case.input)
    out = fence(render_output_text(observation.output))
    if case.golden_output:
        golden = _text(case.golden_output)

        def render(swap: bool) -> str:
            template = _JUDGE_PROMPT_SWAPPED if swap else _JUDGE_PROMPT
            return template.format(
                bias=_BIAS_GUARD, reference=_REFERENCE_GUARD,
                input=inp, golden=golden, output=out,
            )

        return _run_samples(judge, render, _samples(judge_repetitions), swap_capable=True)

    def render_ref_free(_swap: bool) -> str:
        return _JUDGE_PROMPT_REFFREE.format(bias=_BIAS_GUARD, input=inp, output=out)

    return _run_samples(judge, render_ref_free, _samples(judge_repetitions))


def _make_rubric_scorer(dimension: str, criterion: str):
    uses_golden = dimension in _RUBRIC_USES_GOLDEN
    extra = _INSTRUCTION_GUARD if dimension == "instruction_following" else ""

    def _rubric(*, observation, case, metrics=None, judge_repetitions: int = 1, **_):
        judge = judge_or_skip(build_judge)
        if uses_golden and not case.golden_output:
            raise MetricSkipped(f"{dimension} requires a golden_output reference")
        fields = {
            "dimension": dimension, "criterion": criterion, "bias": _BIAS_GUARD,
            "extra": extra, "input": _text(case.input),
            "output": fence(render_output_text(observation.output)),
        }
        if uses_golden:
            fields["golden"] = _text(case.golden_output)
            # Without this the dimension marks an agent down for exceeding the reference.
            fields["extra"] = "\n".join(part for part in (extra, _REFERENCE_GUARD) if part)
        template = _RUBRIC_PROMPT if uses_golden else _RUBRIC_PROMPT_REFFREE

        def render(_swap: bool) -> str:
            return template.format(**fields)

        return _run_samples(judge, render, _samples(judge_repetitions))

    _rubric.__name__ = _rubric.__qualname__ = f"rubric_{dimension}"
    return scorer(dimension, judge=True)(_rubric)


for _dim, _crit in _RUBRICS.items():
    _make_rubric_scorer(_dim, _crit)


def _pairwise_adjust(pref: float, swapped: bool) -> float:
    """Preference for A -> preference for the agent answer."""
    return 1.0 - pref if swapped else pref


@scorer("pairwise_vs_golden", judge=True)
def pairwise_vs_golden(*, observation, case, metrics=None, judge_repetitions: int = 1, **_):
    """A/B preference of the agent answer over the golden reference (0.5 = tie)."""
    if not case.golden_output:
        raise MetricSkipped("pairwise_vs_golden requires a golden_output reference")
    judge = judge_or_skip(build_judge_for, PairwiseVerdict)
    inp = _text(case.input)
    agent = fence(render_output_text(observation.output))
    golden = _text(case.golden_output)

    def render(swap: bool) -> str:
        a, b = (golden, agent) if swap else (agent, golden)
        identity = _PAIRWISE_IDENTITY_SWAPPED if swap else _PAIRWISE_IDENTITY
        return _PAIRWISE_PROMPT.format(identity=identity, bias=_BIAS_GUARD, input=inp, a=a, b=b)

    return _run_samples(
        judge, render, _samples(judge_repetitions), swap_capable=True, adjust=_pairwise_adjust
    )
