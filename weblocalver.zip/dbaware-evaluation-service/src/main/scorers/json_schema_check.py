"""Minimal JSON Schema (draft-07 subset) checker used by ``json_schema_valid``.

Supported keywords: ``type`` (string or list), ``properties``, ``required``,
``additionalProperties`` (false or a schema), ``items`` (single schema),
``enum``, ``const``, ``minimum``, ``maximum``, ``minLength``, ``maxLength``,
``pattern``, ``minItems``, ``maxItems``. Annotation keywords (``title``,
``description``...) are ignored. Any other keyword is reported as a violation
("unsupported schema keyword") rather than silently passing.
"""

from __future__ import annotations

import operator
import re
from collections.abc import Callable
from typing import Any

from ._util import SCHEMA_TYPE_MAP, matches_type

_ANNOTATIONS = frozenset({
    "title", "description", "default", "examples", "$schema", "$id", "$comment", "format",
})
_STRUCTURAL = frozenset({"type", "properties", "required", "additionalProperties", "items"})
_PATTERN = "pattern"
_ENUM = "enum"
_CONST = "const"


def _is_number(value: Any) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _identity(value: Any) -> Any:
    return value


def _is_non_negative_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


# keyword -> (applies to value?, measured quantity, violated(measured, limit), symbol, valid limit?, expected type)
_LIMITS: dict[
    str,
    tuple[
        Callable[[Any], bool],
        Callable[[Any], Any],
        Callable[[Any, Any], bool],
        str,
        Callable[[Any], bool],
        str,
    ],
] = {
    "minimum": (_is_number, _identity, operator.lt, "<", _is_number, "number"),
    "maximum": (_is_number, _identity, operator.gt, ">", _is_number, "number"),
    "minLength": (lambda v: isinstance(v, str), len, operator.lt, "<", _is_non_negative_int, "non-negative integer"),
    "maxLength": (lambda v: isinstance(v, str), len, operator.gt, ">", _is_non_negative_int, "non-negative integer"),
    "minItems": (lambda v: isinstance(v, list), len, operator.lt, "<", _is_non_negative_int, "non-negative integer"),
    "maxItems": (lambda v: isinstance(v, list), len, operator.gt, ">", _is_non_negative_int, "non-negative integer"),
}
_KNOWN = _STRUCTURAL | _ANNOTATIONS | frozenset(_LIMITS) | {_PATTERN, _ENUM, _CONST}


def _where(path: str) -> str:
    return path or "root"


def _type_ok(value: Any, stype: Any) -> tuple[bool, list[str]]:
    names = [str(t) for t in (stype if isinstance(stype, list) else [stype])]
    unknown = [n for n in names if n not in SCHEMA_TYPE_MAP]
    ok = any(matches_type(value, n, SCHEMA_TYPE_MAP) for n in names if n not in unknown)
    return ok, unknown


def _check_type(value: Any, stype: Any, path: str, errors: list[str]) -> bool:
    """False (with an error recorded) when `value` fails the `type` keyword."""
    if not stype:
        return True
    ok, unknown = _type_ok(value, stype)
    if unknown:
        errors.append(f"{_where(path)}: unsupported schema type {unknown}")
    if not ok:
        errors.append(f"{_where(path)}: expected {stype}, got {type(value).__name__}")
    return ok


def _check_limits(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    for key, (applies, measure, violated, symbol, valid_limit, expected_type) in _LIMITS.items():
        if key not in schema:
            continue
        limit_val = schema[key]
        if not valid_limit(limit_val):
            errors.append(
                f"{_where(path)}: schema keyword '{key}' must be a {expected_type}, got {type(limit_val).__name__}"
            )
            continue
        if applies(value) and violated(measure(value), limit_val):
            errors.append(f"{_where(path)}: {measure(value)} {symbol} {key} {limit_val}")


def _check_pattern(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    if _PATTERN not in schema or not isinstance(value, str):
        return
    pattern = schema[_PATTERN]
    if not isinstance(pattern, str):
        errors.append(f"{_where(path)}: schema keyword '{_PATTERN}' must be a string, got {type(pattern).__name__}")
        return
    try:
        if not re.search(pattern, value):
            errors.append(f"{_where(path)}: does not match pattern /{pattern}/")
    except re.error as exc:
        errors.append(f"{_where(path)}: invalid schema pattern /{pattern}/: {exc}")


def _json_equal(a: Any, b: Any) -> bool:
    """JSON equality: unlike Python, ``true`` never equals ``1`` (nor ``false`` ``0``)."""
    return isinstance(a, bool) == isinstance(b, bool) and a == b


def _check_values(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    if _ENUM in schema:
        enum_val = schema[_ENUM]
        if not isinstance(enum_val, list):
            errors.append(f"{_where(path)}: schema keyword '{_ENUM}' must be an array, got {type(enum_val).__name__}")
        elif not any(_json_equal(value, opt) for opt in enum_val):
            errors.append(f"{_where(path)}: {value!r} not in enum {enum_val!r}")
    if _CONST in schema and not _json_equal(value, schema[_CONST]):
        errors.append(f"{_where(path)}: {value!r} != const {schema[_CONST]!r}")


def _check_object(value: dict, schema: dict, path: str, errors: list[str]) -> None:
    required_keys = schema.get("required")
    if required_keys is not None:
        if not isinstance(required_keys, list):
            errors.append(
                f"{_where(path)}: schema keyword 'required' must be an array, got {type(required_keys).__name__}"
            )
        else:
            for r in required_keys:
                if not isinstance(r, str):
                    errors.append(
                        f"{_where(path)}: elements of schema keyword 'required' must be strings, "
                        f"got {type(r).__name__} in {r!r}"
                    )
                elif r not in value:
                    errors.append(f"{path}.{r}: required field missing")
    props = schema.get("properties")
    if props is not None and not isinstance(props, dict):
        errors.append(f"{_where(path)}: schema keyword 'properties' must be an object, got {type(props).__name__}")
        props = {}
    else:
        props = props or {}
    extra = schema.get("additionalProperties", True)
    if not isinstance(extra, bool | dict):
        errors.append(
            f"{_where(path)}: schema keyword 'additionalProperties' must be a boolean or an object, "
            f"got {type(extra).__name__}"
        )
        extra = True
    for k, v in value.items():
        if k in props:
            check_schema(v, props[k], f"{path}.{k}", errors)
        elif extra is False:
            errors.append(f"{path}.{k}: additional property not allowed")
        elif isinstance(extra, dict):
            check_schema(v, extra, f"{path}.{k}", errors)


def check_schema(value: Any, schema: dict, path: str, errors: list[str]) -> None:
    """Append violations of `schema` by `value` (at `path`) to `errors`."""
    if not isinstance(schema, dict):
        errors.append(f"{_where(path)}: schema must be an object")
        return
    errors.extend(f"{_where(path)}: unsupported schema keyword '{key}'" for key in schema if key not in _KNOWN)
    if not _check_type(value, schema.get("type"), path, errors):
        return
    _check_limits(value, schema, path, errors)
    _check_pattern(value, schema, path, errors)
    _check_values(value, schema, path, errors)
    if isinstance(value, dict):
        _check_object(value, schema, path, errors)
    items_schema = schema.get("items")
    if isinstance(value, list) and items_schema:
        for i, item in enumerate(value):
            check_schema(item, items_schema, f"{path}[{i}]", errors)
