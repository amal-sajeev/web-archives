"""Reference-based scorers: compare the agent output to the golden output.

These catch paraphrase and structural correctness that verbatim substring
checks miss:

- token_overlap_f1     -- multiset (bag-of-tokens) F1 against the golden output;
                          tokens are Unicode word characters, case-folded.
- edit_similarity      -- difflib ``SequenceMatcher`` similarity ratio
                          (2*matches / total length) over word tokens, bounded
                          so a long pair cannot stall the worker.
- embedding_similarity -- cosine similarity of Vertex embeddings (skips cleanly
                          when no ADC credentials are present).

JSON checks live in ``configurable_json`` (``json_schema_valid``, ``field_match``).
A case without a golden_output skips these metrics (MetricSkipped).

Scorers return (score, rationale, evidence[, extras]).
"""

from __future__ import annotations

import re
from collections import Counter
from difflib import SequenceMatcher

from .base import MetricSkipped, scorer
from ._util import NO_GOLDEN, spec_config, text_of
from .output_text import render_output_text
from .vertex import embed_texts

_TOKEN = re.compile(r"\w+")
# SequenceMatcher is quadratic, so edit_similarity bounds the work it does.
# Measured worst case with autojunk disabled (see edit_similarity): 2000
# characters ~0.3s and 3000 ~1.0s; 2000 word tokens ~0.9s and 4000 ~13s.
# Up to _EDIT_MAX_CHARS the comparison stays character-level (sensitive to a
# single-letter difference); above it, word tokens keep the cost bounded.
_EDIT_MAX_CHARS = 2000
_EDIT_MAX_TOKENS = 2000
_EDIT_TOKEN = re.compile(r"\w+|[^\w\s]")
_EMBED_UNAVAILABLE = "embeddings unavailable"

# How token_overlap_f1 combines precision and recall; see that scorer's docstring.
_OVERLAP_MODES = {
    "f1": lambda p, r: 2 * p * r / (p + r),
    "recall": lambda _p, r: r,
    "precision": lambda p, _r: p,
}


def _tokens(text: str) -> list[str]:
    return _TOKEN.findall(text.casefold())


def _golden_text(case) -> str:
    if not case.golden_output:
        raise MetricSkipped(NO_GOLDEN)
    return text_of(case.golden_output)


def _cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity clamped to [0, 1]; a zero vector scores 0."""
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    cos = dot / (na * nb) if na and nb else 0.0
    return max(0.0, min(1.0, cos))


@scorer("token_overlap_f1")
def token_overlap_f1(*, observation, case, spec=None, **_):
    """Bag-of-tokens (multiset) overlap between output and golden_output.

    config:
      mode: "f1" (default) | "recall" | "precision"

    ``f1`` balances both sides, so it falls as the output grows even when the
    output still contains everything in the golden: with full recall it is
    ``2P/(1+P)``, which drops below a 0.2 threshold once the output is about
    nine times the golden's length. Use ``recall`` where the golden is a floor
    ("does the output cover the reference content?") rather than an exact
    target -- that measure is insensitive to extra content, so an agent that
    improves by saying more is not marked down, while one that omits reference
    content still fails. ``precision`` is the mirror (penalise padding).
    """
    mode = str(spec_config(spec).get("mode", "f1")).lower()
    if mode not in _OVERLAP_MODES:
        raise MetricSkipped(
            f"config error: unknown mode '{mode}' (allowed: {sorted(_OVERLAP_MODES)})"
        )
    golden = _golden_text(case)
    out_tokens = _tokens(render_output_text(observation.output))
    gold_tokens = _tokens(golden)
    if not out_tokens or not gold_tokens:
        return 0.0, "empty output or golden", []

    overlap = sum((Counter(out_tokens) & Counter(gold_tokens)).values())
    if not overlap:
        return 0.0, "no token overlap with golden", []
    precision = overlap / len(out_tokens)
    recall = overlap / len(gold_tokens)
    score = _OVERLAP_MODES[mode](precision, recall)
    label = {"f1": "token F1", "recall": "golden coverage", "precision": "token precision"}[mode]
    return (
        score,
        f"{label}={score:.3f} (P={precision:.2f} R={recall:.2f})",
        [f"overlap={overlap}", f"tokens_output={len(out_tokens)} tokens_golden={len(gold_tokens)}"],
    )


@scorer("edit_similarity")
def edit_similarity(*, observation, case, **_):
    """difflib similarity ratio (0..1) between output and golden_output.

    Compared with ``autojunk=False``, unlike difflib's default. ``autojunk``
    discards any element occurring in more than 1% of a sequence longer than
    200 elements; at
    character level that is almost every letter, which collapsed the ratio to
    0.0 for *any* pair of texts over a few hundred characters that was not
    nearly identical -- two reasonable paraphrases scored 0.00 instead of
    ~0.30, and the result jumped discontinuously at 200 characters.

    Short inputs (up to ``_EDIT_MAX_CHARS`` on both sides) are still compared
    character by character, so a one-letter difference still registers. Longer
    ones switch to word tokens capped at ``_EDIT_MAX_TOKENS``, because the
    match is quadratic. The evidence always names the unit compared, so a
    bounded comparison is never mistaken for a whole-document one.
    """
    golden = _golden_text(case)
    out = render_output_text(observation.output)
    evidence = [f"len_output={len(out)} len_golden={len(golden)}"]
    if max(len(out), len(golden)) <= _EDIT_MAX_CHARS:
        left, right, unit = list(out), list(golden), "characters"
    else:
        left = _EDIT_TOKEN.findall(out)[:_EDIT_MAX_TOKENS]
        right = _EDIT_TOKEN.findall(golden)[:_EDIT_MAX_TOKENS]
        unit = f"the first {_EDIT_MAX_TOKENS} word tokens"
    sim = SequenceMatcher(None, left, right, autojunk=False).ratio()
    evidence.append(f"compared {unit}")
    return sim, f"edit similarity={sim:.3f}", evidence


@scorer("embedding_similarity")
def embedding_similarity(*, observation, case, **_):
    """Cosine similarity of Vertex embeddings of output vs golden_output.

    Skips (rather than fails) when embeddings are unavailable offline.
    """
    golden = _golden_text(case)
    candidate = render_output_text(observation.output)
    if not candidate.strip():
        return 0.0, "empty output to compare", []
    try:
        vecs = embed_texts([candidate, golden])
    except RuntimeError as exc:
        raise MetricSkipped(f"{_EMBED_UNAVAILABLE}: {exc}") from exc

    if len(vecs or []) < 2:
        raise MetricSkipped(f"{_EMBED_UNAVAILABLE}: fewer than two vectors returned")
    a, b = vecs[0], vecs[1]
    if len(a) != len(b):
        # zip() would silently truncate and report a meaningless cosine.
        raise MetricSkipped(f"{_EMBED_UNAVAILABLE}: vector sizes differ ({len(a)} vs {len(b)})")
    cos = _cosine(a, b)
    return cos, f"embedding cosine={cos:.3f}", []
