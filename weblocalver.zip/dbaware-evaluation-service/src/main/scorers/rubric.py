"""Custom LLM rubric judges configured per metric.

Scorers:
  - ``rubric``        -- one engineer-defined criterion, scored by the judge.
  - ``rubric_multi``  -- several criteria scored in ONE judge call.

The judge factories are looked up in this module (tests patch
``scorers.rubric.build_judge`` / ``scorers.rubric.build_judge_for``).
"""

from __future__ import annotations

from typing import Any

from .base import MetricSkipped, scorer
from ._util import spec_config, text_of
from .judge_invoke import _invoke_metric, _run_samples, _samples, judge_or_skip, sample_extras
from .judge_prompts import (
    _BIAS_GUARD,
    _DATA_GUARD,
    _MULTI_RUBRIC_PROMPT,
    _REFERENCE_GUARD,
    _RUBRIC_PROMPT_CUSTOM,
    fence,
)
from .output_text import render_output_text
from .vertex import MultiRubricVerdict, build_judge, build_judge_for

_RUBRIC = "rubric"


def _golden_block(cfg: dict[str, Any], case, scorer_name: str) -> str:
    """The GOLDEN OUTPUT section, with the guard that keeps it a floor not a ceiling."""
    if not cfg.get("uses_golden", False):
        return ""
    if not case.golden_output:
        raise MetricSkipped(f"{scorer_name} uses_golden=true but no golden_output provided")
    return f"{_REFERENCE_GUARD}\n\nGOLDEN OUTPUT:\n{text_of(case.golden_output)}\n"


def _bias(cfg: dict[str, Any]) -> str:
    # The data guard stays even when the bias guard is switched off.
    return _BIAS_GUARD if cfg.get("bias_guard", True) else _DATA_GUARD


@scorer(_RUBRIC, judge=True)
def rubric(*, observation, case, spec=None, metrics=None, judge_repetitions: int = 1, **_):
    """Custom LLM rubric judge -- the rubric text comes from config.

    config:
      rubric: str          -- the evaluation criterion text (what to judge).
      uses_golden: bool    -- include the golden_output in the prompt
                              (default false; skips if golden is missing).
      bias_guard: bool     -- add the standard bias guard (default true).
      examples: str        -- optional few-shot examples appended to the prompt.

    Self-consistency via judge_repetitions. Skips cleanly when Vertex is
    unavailable (offline).
    """
    cfg = spec_config(spec, case)
    rubric_text = cfg.get(_RUBRIC, "")
    if not rubric_text:
        raise MetricSkipped("rubric scorer requires config.rubric text")
    judge = judge_or_skip(build_judge)
    examples = cfg.get("examples", "")
    prompt = _RUBRIC_PROMPT_CUSTOM.format(
        rubric=rubric_text,
        bias=_bias(cfg),
        input=text_of(case.input),
        golden_block=_golden_block(cfg, case, _RUBRIC),
        output=fence(render_output_text(observation.output)),
    ) + (f"\nExamples:\n{examples}" if examples else "")

    def render(_swap: bool) -> str:
        return prompt

    return _run_samples(judge, render, _samples(judge_repetitions))


def _criterion_names(criteria: list[Any]) -> list[tuple[str, str]]:
    """(name, rubric) pairs; unnamed criteria become ``criterion_{i+1}``."""
    pairs = []
    for i, c in enumerate(criteria):
        entry = c if isinstance(c, dict) else {_RUBRIC: str(c)}
        name = str(entry.get("name") or f"criterion_{i + 1}").strip()
        pairs.append((name, str(entry.get(_RUBRIC, ""))))
    return pairs


def _sample_scores(verdict, names: list[str]) -> dict[str, float | None]:
    """Configured name -> judge score (None when the judge omitted it)."""
    by_name = {str(cs.criterion).strip().lower(): float(cs.score) for cs in verdict.scores}
    return {name: by_name.get(name.lower()) for name in names}


def _criteria_evidence(per_name: dict[str, list[float | None]], last_verdict) -> list[str]:
    evidence = []
    for name, vals in per_name.items():
        got = [v for v in vals if v is not None]
        missing = len(vals) - len(got)
        mean = sum(v or 0.0 for v in vals) / len(vals)
        suffix = f", missing in {missing} sample(s) -> 0" if missing else ""
        evidence.append(f"{name}: {mean:.3f} ({len(vals)} samples{suffix})")
    if last_verdict is not None and last_verdict.overall_rationale:
        evidence.append(f"overall: {last_verdict.overall_rationale}")
    return evidence


@scorer("rubric_multi", judge=True)
def rubric_multi(*, observation, case, spec=None, metrics=None, judge_repetitions: int = 1, **_):
    """Multi-criteria LLM rubric judge -- scores N criteria in ONE Vertex call.

    The score is the mean over the *configured* criteria: a criterion the judge
    did not report scores 0, and extra criteria it invents are ignored. Per-
    criterion means are in the evidence; high sample variance flags `unstable`.

    config:
      criteria: [{name: str, rubric: str}, ...]  -- the criteria to evaluate
      uses_golden: bool                          -- include golden_output in prompt
      bias_guard: bool                           -- add the standard bias guard
    """
    cfg = spec_config(spec, case)
    criteria = _criterion_names(cfg.get("criteria") or [])
    if not criteria:
        raise MetricSkipped("rubric_multi requires config.criteria (list of {name, rubric})")
    judge = judge_or_skip(build_judge_for, MultiRubricVerdict)
    names = list(dict.fromkeys(name for name, _r in criteria))  # de-duplicated, ordered
    prompt = _MULTI_RUBRIC_PROMPT.format(
        bias=_bias(cfg),
        input=text_of(case.input),
        golden_block=_golden_block(cfg, case, "rubric_multi"),
        output=fence(render_output_text(observation.output)),
        criteria_list="\n".join(f"{i + 1}. {n}: {r}" for i, (n, r) in enumerate(criteria)),
    )

    per_name: dict[str, list[float | None]] = {name: [] for name in names}
    sample_means: list[float] = []
    last_verdict = None
    for i in range(_samples(judge_repetitions)):
        last_verdict = _invoke_metric(judge, prompt, i)
        got = _sample_scores(last_verdict, names)
        for name, value in got.items():
            per_name[name].append(value)
        sample_means.append(sum(v or 0.0 for v in got.values()) / len(names))

    overall = sum(sample_means) / len(sample_means)
    evidence = _criteria_evidence(per_name, last_verdict)
    return overall, f"mean of {len(names)} criteria", evidence, sample_extras(sample_means)
