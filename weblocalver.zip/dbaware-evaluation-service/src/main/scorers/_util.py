"""Small helpers shared by the built-in scorers.

Kept dependency-free (only ``output_text``) so every scorer module can import it
without creating import cycles.
"""

from __future__ import annotations

import json
import re
from typing import Any

from .base import MetricSkipped
from .output_text import render_output_text

TICK = "✓"
CROSS = "✗"
NO_GOLDEN = "no golden_output to compare"
INVALID_JSON = "output is not valid JSON"

# Type names accepted by the config shortcuts (field_match `type`, json_schema_valid `types`).
CONFIG_TYPE_MAP: dict[str, type | tuple[type, ...]] = {
    "str": str, "string": str,
    "int": int, "integer": int,
    "float": (int, float), "number": (int, float),
    "bool": bool, "boolean": bool,
    "list": list, "array": list,
    "dict": dict, "object": dict,
    "null": type(None), "none": type(None),
}

# JSON Schema `type` keyword values.
SCHEMA_TYPE_MAP: dict[str, type | tuple[type, ...]] = {
    "string": str, "integer": int, "number": (int, float),
    "boolean": bool, "array": list, "object": dict, "null": type(None),
}

_NUMERIC_NAMES = frozenset({"int", "integer", "float", "number"})


def mark(ok: bool) -> str:
    """Evidence prefix: a tick for a pass, a cross for a fail."""
    return TICK if ok else CROSS


def spec_config(spec: Any, case: Any = None) -> dict[str, Any]:
    """The MetricSpec's ``config`` dict (empty when there is no spec/config).

    With ``case``, any ``"${expected.path}"`` / ``"${input.path}"`` string in the
    config is replaced by that value from the case -- see :func:`resolve_case_refs`.
    """
    config = (getattr(spec, "config", None) if spec else None) or {}
    return resolve_case_refs(config, case) if case is not None else config


_CASE_REF_RE = re.compile(r"\A\$\{(expected|input)\.([A-Za-z0-9_.\[\]]+)\}\Z")
_CASE_SCOPES = ("expected", "input")


def _case_ref(scope: str, path: str, case: Any) -> Any:
    from adapters.templating import MISSING, lookup_strict

    source = getattr(case, scope, None) or {}
    value = lookup_strict(source, path)
    if value is MISSING:
        raise MetricSkipped(
            f"config error: '${{{scope}.{path}}}' is not present in case.{scope} "
            f"(has: {sorted(source)[:8] if isinstance(source, dict) else type(source).__name__})"
        )
    return value


def resolve_case_refs(value: Any, case: Any) -> Any:
    """Replace ``"${expected.path}"`` / ``"${input.path}"`` strings with case values.

    A metric config that pins one case's literal -- ``{"path": "total", "op":
    "equals", "value": 8000}`` -- can never pass on the dataset's other cases,
    and has to be re-edited whenever the data moves. Referencing the case
    instead (``"value": "${expected.expected_total}"``) makes the same assertion
    per-case and keeps it correct as the cases grow.

    Only whole strings are substituted, so the resolved value keeps its type (a
    list stays a list); a ``${...}`` inside a longer string is left alone, which
    keeps regex patterns and rubric prose intact. A reference the case does not
    define is a config error and skips the metric rather than silently comparing
    against ``None``.

    Only ``case.expected`` and ``case.input`` are in scope. Request templating
    (``adapters.templating``) deliberately cannot see ``expected``: that holds
    the answer, which must never be templated into a call to the agent.
    """
    if isinstance(value, str):
        match = _CASE_REF_RE.match(value)
        return _case_ref(match.group(1), match.group(2), case) if match else value
    if isinstance(value, dict):
        return {k: resolve_case_refs(v, case) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_case_refs(v, case) for v in value]
    return value


def config_int(cfg: dict[str, Any], key: str, default: int) -> int:
    """A whole-number config value; anything else is a config error (MetricSkipped)."""
    value = cfg.get(key, default)
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise MetricSkipped(f"config error: '{key}' must be a whole number, got {value!r}") from exc


def as_list(value: Any) -> list[Any]:
    """Wrap a scalar (notably a string) in a list; pass lists/tuples/sets through."""
    if value is None:
        return []
    if isinstance(value, list | tuple | set):
        return list(value)
    return [value]


def text_of(value: Any) -> str:
    """A string as-is, anything else JSON-encoded."""
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)


def output_text(observation: Any) -> str:
    """Text form of the observation output (prefers adapter-extracted text)."""
    meta = observation.metadata or {}
    if meta.get("extracted_text"):
        return meta["extracted_text"]
    return render_output_text(observation.output)


def matches_type(value: Any, type_name: str, type_map: dict[str, Any]) -> bool:
    """isinstance check by type name; bools never count as numbers.

    Unknown type names return False (the caller reports them).
    """
    name = str(type_name).lower()
    expected = type_map.get(name)
    if expected is None:
        return False
    if name in _NUMERIC_NAMES and isinstance(value, bool):
        return False
    return isinstance(value, expected)


def range_score(value: float, lo: float, hi: float) -> float:
    """1.0 inside [lo, hi] (hi <= 0 means unbounded), linear falloff outside."""
    if value < lo:
        return max(0.0, value / lo) if lo > 0 else 1.0
    if 0 < hi < value:
        return hi / value
    return 1.0


def range_label(lo: float, hi: float) -> str:
    """Inclusive range text, e.g. ``[2, 10]`` or ``[2, inf)``."""
    return f"[{lo}, {hi}]" if hi > 0 else f"[{lo}, ∞)"


def measurement(spec: Any, value: float) -> dict[str, float]:
    """Extras for a raw measurement (a count, a length...).

    The runner normalises ``extras["raw_value"]`` in place of the score, which is
    only right when the MetricSpec opts into normalisation (``lower_is_better``
    or explicit ``norm_min``/``norm_max``). Otherwise the value is reported as
    audit-only ``measured`` and the scorer's own [0, 1] score is used.
    """
    opted = spec is not None and (
        getattr(spec, "direction", None) == "lower_is_better"
        or getattr(spec, "norm_min", None) is not None
        or getattr(spec, "norm_max", None) is not None
    )
    return {"raw_value": float(value)} if opted else {"measured": float(value)}
