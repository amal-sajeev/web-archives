"""JSON structure scorers -- operate on parsed JSON output.

Scorers:
  - ``json_path``         -- dotted-path value check (equals/contains/exists/regex).
  - ``field_match``       -- required fields with value operators (==/contains/regex/in...).
  - ``json_schema_valid`` -- output matches a JSON schema (or required/types shortcut).

An unknown operator is a configuration error and is reported as such in the
rationale/evidence (the check fails). Config that is *absent* -- no path, no
fields, no schema -- means the check cannot run at all, so the metric is skipped
(see the scorer contract in ``scorers.base``); scoring 1.0 there would hand a
critical gate a free pass whenever a config key is misspelt.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from typing import Any

from adapters.templating import MISSING as _MISSING, lookup_strict as _lookup

from .base import MetricSkipped, ScorerResult, scorer
from ._util import CONFIG_TYPE_MAP, INVALID_JSON, mark, matches_type, spec_config
from .json_schema_check import check_schema

_OP_EXISTS = "exists"
_OP_CONTAINS = "contains"
_OP_REGEX = "regex"


def _output_json(observation) -> Any:
    """Parse the observation output as JSON (dict/list), or raise ValueError."""
    raw = observation.output
    if isinstance(raw, dict | list):
        return raw
    if isinstance(raw, str):
        return json.loads(raw)
    raise ValueError("output is not JSON")


def _parse_output(observation) -> tuple[Any, ScorerResult | None]:
    """``(parsed JSON, None)``, or ``(None, failing result)`` when it is not JSON."""
    try:
        return _output_json(observation), None
    except (TypeError, ValueError) as exc:
        return None, (0.0, f"{INVALID_JSON}: {exc}", [])


# --------------------------------------------------------------------------- #
# Operators: (present value, configured value) -> bool. Only called when present.
# --------------------------------------------------------------------------- #

def _op_contains(val: Any, value: Any) -> bool:
    try:
        return value in val
    except TypeError:
        return False


def _op_regex(val: Any, value: Any) -> bool:
    try:
        return bool(re.search(str(value), str(val)))
    except re.error:
        return False


def _op_in(val: Any, value: Any) -> bool:
    return val in (value if isinstance(value, list | tuple | set) else [value])


_FIELD_OPS: dict[str, Callable[[Any, Any], bool]] = {
    _OP_EXISTS: lambda _val, _value: True,
    "==": lambda val, value: val == value,
    "!=": lambda val, value: val != value,
    _OP_CONTAINS: _op_contains,
    _OP_REGEX: _op_regex,
    "in": _op_in,
    "type": lambda val, value: matches_type(val, str(value), CONFIG_TYPE_MAP),
}

_PATH_OPS: dict[str, str] = {
    _OP_EXISTS: _OP_EXISTS, "equals": "==", _OP_CONTAINS: _OP_CONTAINS, _OP_REGEX: _OP_REGEX,
}


def _unknown_op(op: Any, allowed) -> str:
    return f"config error: unknown op '{op}' (allowed: {sorted(allowed)})"


@scorer("json_path")
def json_path(*, observation, case, spec=None, **_):
    """Check a dotted-path value in the JSON output.

    config:
      path: str   -- dotted/bracket path ("data.items.0.id" or "data.items[0].id").
      op: str     -- "equals" | "contains" | "exists" | "regex" (default "exists").
      value: Any  -- comparison value for equals/contains/regex.

    ``exists`` is true for any present key, including one whose value is null.
    Without a ``path`` there is nothing to check, so the metric is skipped.
    """
    cfg = spec_config(spec, case)
    path = cfg.get("path", "")
    op = cfg.get("op", _OP_EXISTS)
    expected = cfg.get("value")
    if not path:
        raise MetricSkipped("config error: 'path' is required for json_path")
    if op not in _PATH_OPS:
        return 0.0, _unknown_op(op, _PATH_OPS), []
    obj, failure = _parse_output(observation)
    if failure:
        return failure

    looked = _lookup(obj, path)
    present = looked is not _MISSING
    ok = present and _FIELD_OPS[_PATH_OPS[op]](looked, expected)
    if op == _OP_EXISTS:
        state = "present" if present else "absent"
        return float(ok), f"path '{path}' {'exists' if ok else 'missing'}", [f"{path}={state}"]
    # "absent" rather than None, so a missing path is not reported the same way
    # as a path that is present and holds null.
    shown = f"{path}={looked!r}" if present else f"{path}=absent"
    return float(ok), f"{path} {op} {expected!r}: {ok}", [shown]


def _field_check(obj: Any, f: dict[str, Any]) -> tuple[bool, str]:
    name = f.get("name", "")
    op = f.get("op", _OP_EXISTS)
    value = f.get("value")
    fn = _FIELD_OPS.get(op)
    if fn is None:
        return False, f"{mark(False)} {name}: {_unknown_op(op, _FIELD_OPS)}"
    looked = _lookup(obj, name) if name else _MISSING
    present = looked is not _MISSING
    ok = present and fn(looked, value)
    ev = f"{mark(ok)} {name} {op} {value!r}"
    return ok, ev + (f" (got {looked!r})" if present else "")


@scorer("field_match")
def field_match(*, observation, case, spec=None, **_):
    """Required JSON fields with value operators.

    config:
      fields: [{name: str, op: str, value: Any, required: bool}, ...]
        name: top-level key or dotted/bracket path (e.g. "line_items.0.amount")
        op: "==" | "!=" | "contains" | "regex" | "in" | "exists" | "type"
        required: default true (optional fields are reported, not scored)

    Without ``fields`` there is nothing to check, so the metric is skipped.
    """
    fields = spec_config(spec, case).get("fields", [])
    if not fields:
        raise MetricSkipped("config error: 'fields' is required for field_match")
    obj, failure = _parse_output(observation)
    if failure:
        return failure

    required_total, passed, evidence = 0, 0, []
    for f in fields:
        ok, ev = _field_check(obj, f)
        evidence.append(ev)
        if f.get("required", True):
            required_total += 1
            passed += int(ok)
    if not required_total:
        return 1.0, f"no required fields ({len(fields)} optional checked)", evidence
    return passed / required_total, f"{passed}/{required_total} field checks passed", evidence


def _validate_schema(observation, schema: dict) -> tuple[float, str, list[str]]:
    obj, failure = _parse_output(observation)
    if failure:
        return failure
    errors: list[str] = []
    check_schema(obj, schema, "", errors)
    if not errors:
        return 1.0, "output matches schema", ["schema valid"]
    return 0.0, f"{len(errors)} schema violations", errors[:20]


def _shortcut_checks(obj: dict, required: list[str], types: dict[str, str]) -> ScorerResult:
    """Required keys must be present; a key listed in ``types`` must have that type.

    A typed key that is not required is only checked when it is present.
    """
    checks: list[bool] = []
    evidence: list[str] = []
    for field in dict.fromkeys([*required, *types]):
        present = field in obj
        if field in required:
            checks.append(present)
        elif not present:
            evidence.append(f"- {field} (optional, absent)")
            continue
        ok_type = True
        if present and field in types:
            ok_type = matches_type(obj[field], types[field], CONFIG_TYPE_MAP)
            checks.append(ok_type)
        evidence.append(f"{mark(present and ok_type)} {field}")
    if not checks:
        return 1.0, "no schema checks applied", evidence
    return sum(checks) / len(checks), f"{sum(checks)}/{len(checks)} schema checks passed", evidence


@scorer("json_schema_valid")
def json_schema_valid_config(*, observation, case, spec=None, **_):
    """Output matches a JSON schema from config.

    config:
      schema: dict              -- a JSON Schema subset (see json_schema_check).
      required: [str, ...]      -- shortcut: required keys (if no schema).
      types: {field: type_str}  -- shortcut: per-field type check.

    One of ``schema``, ``required`` or ``types`` must be configured; with none
    of them there is nothing to validate against, so the metric is skipped.
    """
    cfg = spec_config(spec, case)
    schema = cfg.get("schema")
    if schema:
        return _validate_schema(observation, schema)
    required = cfg.get("required", [])
    types = cfg.get("types", {}) or {}
    if not required and not types:
        raise MetricSkipped(
            "config error: json_schema_valid needs one of 'schema', 'required' or 'types'"
        )
    obj, failure = _parse_output(observation)
    if failure:
        return failure
    if not isinstance(obj, dict):
        return 0.0, "expected JSON object", []
    return _shortcut_checks(obj, required, types)
