"""``POST /api/playground/validate``: statically check a bundle without executing it."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from fastapi import UploadFile

from core.playground import inspect_bundle
from core.structured_logging import get_logger

_log = get_logger("eval_service.handlers.playground")
_SENSITIVE_PREFIXES = (".git/", ".env")


@dataclass
class _CustomTestsCheck:
    loaded: list[str] = field(default_factory=list)
    collisions: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def _structure_errors(data: dict) -> list[str]:
    agent = data.get("agent") or {}
    dataset = data.get("dataset") or {}
    checks = [
        (agent.get("agent_id"), "agent.yaml is missing agent_id."),
        (agent.get("name"), "agent.yaml is missing name."),
        (dataset.get("cases"), "Dataset contains no cases."),
        (dataset.get("metrics"), "Dataset contains no metrics."),
    ]
    errors = [message for present, message in checks if not present]
    errors.extend(
        f"Sensitive or repository metadata file should not be included: {item['path']}"
        for item in data.get("files", [])
        if item.get("path", "").startswith(_SENSITIVE_PREFIXES)
    )
    return errors


def _check_custom_tests(blob: bytes, filename: str | None, declared: list[str]) -> _CustomTestsCheck:
    """Report declared custom scorers without executing uploaded Python."""
    result = _CustomTestsCheck()
    if declared:
        _log.info(
            "playground_custom_tests_static_validation",
            extra={"declared_scorers": declared, "bundle_filename": filename or ""},
        )
    return result


async def playground_validate(file: UploadFile) -> dict[str, Any]:
    """Validate an uploaded/edited configuration without starting an evaluation."""
    blob = await file.read()
    try:
        data = inspect_bundle(blob, filename=file.filename)
    except ValueError as exc:
        return {"valid": False, "errors": [str(exc)]}
    custom = data.get("custom_tests", {}) or {}
    declared = custom.get("declared_scorers", [])
    check = _check_custom_tests(blob, file.filename, declared)
    errors = _structure_errors(data) + check.errors
    if custom.get("syntax_error"):
        errors.append(f"custom_tests.py syntax error: {custom['syntax_error']}")
    return {
        "valid": not errors,
        "errors": errors,
        "agent": (data.get("agent") or {}).get("agent_id"),
        "dataset": (data.get("dataset") or {}).get("dataset_id"),
        "custom_tests": {
            "present": bool(custom.get("present")),
            "declared_scorers": declared,
            "loaded_scorers": check.loaded,
            "collisions": check.collisions,
        },
    }
