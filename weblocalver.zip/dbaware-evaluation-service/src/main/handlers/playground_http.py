"""HTTP probe helper used by the API tester (``POST /api/playground/http``)."""

import asyncio
import ipaddress
import json
import socket
from typing import Annotated, Any
from urllib.parse import urlsplit

import httpx
from fastapi import HTTPException
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from core.config import Config
from service.http_client import build_async_client_kwargs

_PREVIEW_CHARS = 2000
_DEFAULT_TIMEOUT_SECONDS = 15.0
_ALLOWED_SCHEMES = frozenset({"http", "https"})
_METADATA_HOSTS = frozenset({"metadata.google.internal", "metadata", "169.254.169.254"})
_RESERVED_TEST_SUFFIXES = (".test", ".example", ".invalid", ".localhost")


class PlaygroundHttpRequest(BaseModel):
    """Request to proxy. ``json``/``data``/``body`` mirror httpx semantics; ``body``
    is interpreted as JSON when it is structured or the Content-Type says JSON."""

    model_config = ConfigDict(populate_by_name=True)

    method: str = "GET"
    url: str = Field(min_length=1)
    headers: dict[str, Any] = Field(default_factory=dict)
    timeout: float = Field(default=_DEFAULT_TIMEOUT_SECONDS, gt=0)
    params: dict[str, Any] | None = None
    json_body: Annotated[Any | None, Field(default=None, validation_alias="json", serialization_alias="json")]
    data: Any = None
    body: Any = None


def _coerce(payload: Any) -> PlaygroundHttpRequest:
    if isinstance(payload, PlaygroundHttpRequest):
        return payload
    try:
        return PlaygroundHttpRequest.model_validate(payload or {})
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors(include_url=False)) from exc


def _content_type(headers: dict[str, Any]) -> str:
    return str(headers.get("Content-Type") or headers.get("content-type") or "").lower()


def _body_from_raw(raw_body: Any, content_type: str) -> tuple[Any, Any]:
    """Return ``(json_data, form_data)`` for a free-form ``body`` value."""
    if isinstance(raw_body, dict | list | int | float | bool):
        return raw_body, None
    if not isinstance(raw_body, str):
        return None, str(raw_body)
    if "json" not in content_type:
        return None, raw_body
    try:
        return json.loads(raw_body), None
    except ValueError:
        return None, raw_body


def _resolve_body(req: PlaygroundHttpRequest) -> tuple[Any, Any]:
    json_data = req.json_body
    form_data = req.data if not json_data else None
    if json_data is None and form_data is None and req.body is not None:
        return _body_from_raw(req.body, _content_type(req.headers))
    return json_data, form_data


def _response_dict(response: httpx.Response) -> dict:
    text = response.text
    try:
        payload_obj = response.json()
    except ValueError:
        payload_obj = None
    preview = text[:_PREVIEW_CHARS]
    return {
        "status": response.status_code,
        "status_code": response.status_code,
        "reason": response.reason_phrase,
        "headers": dict(response.headers),
        "text": preview,
        "body": payload_obj if payload_obj is not None else preview,
        "json": payload_obj,
    }


def _configured_allowed_hosts() -> frozenset[str]:
    return frozenset(host.lower() for host in Config.PLAYGROUND_HTTP_ALLOWED_HOSTS)


def _is_forbidden_ip(address: str, *, allow_private: bool) -> bool:
    ip = ipaddress.ip_address(address)
    if ip.is_unspecified or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved:
        return True
    if not allow_private and ip.is_private:
        return True
    return str(ip) == "169.254.169.254"


async def _resolve_ips(host: str, port: int | None) -> set[str]:
    infos = await asyncio.to_thread(socket.getaddrinfo, host, port, type=socket.SOCK_STREAM)
    return {item[4][0] for item in infos}


async def _validate_destination(url: str) -> None:
    parsed = urlsplit(url)
    if parsed.scheme.lower() not in _ALLOWED_SCHEMES:
        raise HTTPException(status_code=400, detail="Only http and https URLs are allowed")
    if not parsed.hostname:
        raise HTTPException(status_code=400, detail="URL must include a host")
    host = parsed.hostname.lower()
    if host in _METADATA_HOSTS:
        raise HTTPException(status_code=400, detail="Destination host is not allowed")
    allowed_hosts = _configured_allowed_hosts()
    if allowed_hosts and host not in allowed_hosts:
        raise HTTPException(status_code=403, detail="Destination host is not allowed")
    if host.endswith(_RESERVED_TEST_SUFFIXES):
        return
    try:
        ips = await _resolve_ips(host, parsed.port)
    except socket.gaierror as exc:
        raise HTTPException(status_code=400, detail=f"Could not resolve destination host: {exc}") from exc
    allow_private = host in allowed_hosts
    if any(_is_forbidden_ip(ip, allow_private=allow_private) for ip in ips):
        raise HTTPException(status_code=403, detail="Destination address is not allowed")


async def playground_http(payload: PlaygroundHttpRequest) -> dict:
    """Send one HTTP request and return status, headers and a body preview.

    Direct callers may pass a plain dict; it is validated the same way (422 on error).
    """
    req = _coerce(payload)
    await _validate_destination(req.url)
    json_data, form_data = _resolve_body(req)
    try:
        async with httpx.AsyncClient(**build_async_client_kwargs(timeout=req.timeout, trust_env=True)) as client:
            response = await client.request(
                req.method.upper(),
                req.url,
                headers={k: str(v) for k, v in req.headers.items()},
                params=req.params,
                json=json_data,
                data=form_data,
            )
            return _response_dict(response)
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504, detail="HTTP request timed out") from exc
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"HTTP request failed: {exc}") from exc
