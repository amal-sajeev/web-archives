// Shared scorecard copy + formatters + theme toggle.
// No /api/ URLs — safe behind an ingress path prefix.

const CTNA = window.CTNA = window.CTNA || {};

const THEME_KEY = "ctna-theme";

const GROUPS = [
  { id: "safety", label: "Safety and compliance" },
  { id: "quality", label: "Output quality" },
  { id: "job", label: "Task completeness" },
  { id: "ops", label: "Operational performance" },
  {
    id: "signal",
    label: "Self-reported signals",
    note: "Values declared by the system itself. These are recorded for reference and are not independent assessments of output quality.",
  },
];

const JUDGE_METRICS = new Set([
  "faithfulness", "relevance", "completeness", "coherence",
  "conciseness", "instruction_following", "pairwise_vs_golden",
  "groundedness", "rubric", "rubric_multi",
  "walkthrough_factual_accuracy", "extraction_quality_rubric",
  "document_quality_rubric", "report_quality_rubric",
]);

const METRICS = {
  no_pii_leakage: {
    title: "No personal data disclosed",
    blurb: "The output does not contain personal identifiers such as names, email addresses, or account numbers.",
    group: "safety",
  },
  prompt_injection_safe: {
    title: "Resistant to instruction override",
    blurb: "Attempts to override system instructions or inject unauthorised commands were not followed.",
    group: "safety",
  },
  refusal_appropriate: {
    title: "Appropriate refusal",
    blurb: "Requests that should not be fulfilled were declined.",
    group: "safety",
  },
  groundedness: {
    title: "Grounded in source material",
    blurb: "Statements are supported by the supplied documents and do not introduce unsupported facts.",
    group: "safety",
  },
  citation_grounding: {
    title: "Citations are valid",
    blurb: "Cited references correspond to material present in the source.",
    group: "safety",
  },
  faithfulness: {
    title: "Factual fidelity",
    blurb: "The output remains consistent with the source and does not introduce unsupported claims.",
    group: "quality",
  },
  relevance: {
    title: "Relevance to the request",
    blurb: "The output addresses the question that was asked.",
    group: "quality",
  },
  completeness: {
    title: "Completeness",
    blurb: "Material elements expected in the reference output are present.",
    group: "quality",
  },
  coherence: {
    title: "Coherence",
    blurb: "The output is logically organised and readily understood.",
    group: "quality",
  },
  conciseness: {
    title: "Conciseness",
    blurb: "The output is complete without unnecessary length.",
    group: "quality",
  },
  instruction_following: {
    title: "Instruction adherence",
    blurb: "The output follows the requested task and format.",
    group: "quality",
  },
  pairwise_vs_golden: {
    title: "Comparison with reference output",
    blurb: "An automated assessment compared this output with the reference answer.",
    group: "quality",
  },
  token_overlap_f1: {
    title: "Lexical alignment with reference",
    blurb: "Wording overlaps substantially with the reference output.",
    group: "quality",
  },
  token_overlap_with_golden: {
    title: "Lexical alignment with reference",
    blurb: "Wording overlaps substantially with the reference output.",
    group: "quality",
  },
  edit_similarity: {
    title: "Wording proximity to reference",
    blurb: "The output differs from the reference primarily in minor wording.",
    group: "quality",
  },
  embedding_similarity: {
    title: "Semantic alignment with reference",
    blurb: "The meaning is consistent with the reference output, even where wording differs.",
    group: "quality",
  },
  answer_relevance_embedding: {
    title: "Semantic alignment with reference",
    blurb: "The meaning is consistent with the reference output, even where wording differs.",
    group: "quality",
  },
  walkthrough_factual_accuracy: {
    title: "Factual accuracy against the walkthrough",
    blurb: "Plan identifiers, dates, and controls match the research report. Unsupported facts are not introduced.",
    group: "quality",
  },
  extraction_quality_rubric: {
    title: "Invoice extraction accuracy",
    blurb: "Vendor, totals, and line items match the source invoice.",
    group: "quality",
  },
  document_quality_rubric: {
    title: "Document quality",
    blurb: "The document is structured with clear headings, substantiated findings, and actionable recommendations.",
    group: "quality",
  },
  report_quality_rubric: {
    title: "Report quality",
    blurb: "The report is structured with clear headings, accurate figures, and a professional presentation.",
    group: "quality",
  },
  rubric: {
    title: "Qualitative assessment",
    blurb: "An automated assessment scored the output against a defined quality rubric.",
    group: "quality",
  },
  rubric_multi: {
    title: "Qualitative assessment (multiple criteria)",
    blurb: "An automated assessment scored several quality criteria in a single review.",
    group: "quality",
  },
  ai_confidence: {
    title: "Reported confidence",
    blurb: "The system’s own confidence score meets the required minimum.",
    group: "signal",
    informational: true,
  },
  confidence_score_valid: {
    title: "Valid confidence score",
    blurb: "A well-formed confidence value was reported.",
    group: "signal",
    informational: true,
  },
  response_success: {
    title: "Successful response",
    blurb: "The system returned a successful response rather than an error.",
    group: "job",
  },
  answer_not_empty: {
    title: "Non-empty output",
    blurb: "The system returned a response.",
    group: "job",
  },
  not_empty: {
    title: "Non-empty output",
    blurb: "The system returned a response.",
    group: "job",
  },
  spot_checks: {
    title: "Required content checks",
    blurb: "Specified phrases are present or absent as required by the case.",
    group: "job",
  },
  assertions: {
    title: "Required content checks",
    blurb: "Specified phrases are present or absent as required by the case.",
    group: "job",
  },
  answer_length_reasonable: {
    title: "Output length within range",
    blurb: "The response length falls within the expected bounds.",
    group: "job",
  },
  tool_selection: {
    title: "Correct tool selection",
    blurb: "The expected tool was invoked with the required values.",
    group: "job",
  },
  identifier_passthrough: {
    title: "Identifiers preserved",
    blurb: "Provided identifiers were passed through without omission or alteration.",
    group: "job",
  },
  tool_order_correct: {
    title: "Correct tool sequence",
    blurb: "Tools were invoked in the required order.",
    group: "job",
  },
  no_redundant_calls: {
    title: "No redundant tool calls",
    blurb: "The same tool was not invoked repeatedly without cause.",
    group: "job",
  },
  tool_arg_accuracy: {
    title: "Accurate tool arguments",
    blurb: "Tool invocations used the expected arguments.",
    group: "job",
  },
  tool_error_free: {
    title: "Tool calls completed without error",
    blurb: "Invoked tools completed successfully.",
    group: "job",
  },
  step_efficiency: {
    title: "Efficient execution path",
    blurb: "The task was completed without unnecessary additional calls.",
    group: "job",
  },
  scoping_reports_present: {
    title: "Required reports present",
    blurb: "All expected scoping reports were returned.",
    group: "job",
  },
  scoping_titles_exact: {
    title: "Exact report titles",
    blurb: "Official report titles were used without paraphrase.",
    group: "job",
  },
  scoping_sections_present: {
    title: "Required report sections present",
    blurb: "Each report includes the sections specified for this case.",
    group: "job",
  },
  rationale_coverage: {
    title: "Rationale provided",
    blurb: "A rationale is included where the case requires one.",
    group: "job",
  },
  scope_entities_present: {
    title: "Required entities named",
    blurb: "People, systems, or organisations required by the scope are identified.",
    group: "job",
  },
  vendor_extracted: {
    title: "Vendor and invoice fields extracted",
    blurb: "Vendor, invoice number, total, and currency were extracted.",
    group: "job",
  },
  total_correct: {
    title: "Invoice total correct",
    blurb: "The extracted total matches the source invoice.",
    group: "job",
  },
  item_count_correct: {
    title: "Line-item count correct",
    blurb: "The number of line items matches the invoice.",
    group: "job",
  },
  invoice_schema_valid: {
    title: "Invoice record well formed",
    blurb: "The extracted record contains the required fields in the expected structure.",
    group: "job",
  },
  line_items_have_amounts: {
    title: "Line items include amounts",
    blurb: "Each line item includes a monetary amount.",
    group: "job",
  },
  doc_sections_present: {
    title: "Required document sections present",
    blurb: "Expected headings, such as summary and recommendations, are present.",
    group: "job",
  },
  doc_heading_count: {
    title: "Heading count within range",
    blurb: "The document uses a number of headings within the expected bounds.",
    group: "job",
  },
  doc_has_findings: {
    title: "Key findings present",
    blurb: "Expected topics such as revenue, expenses, or recommendations are covered.",
    group: "job",
  },
  docx_table_present: {
    title: "Required table present",
    blurb: "The document contains a table with the required headers and rows.",
    group: "job",
  },
  report_sections_present: {
    title: "Required report sections present",
    blurb: "Expected sections are present in the report.",
    group: "job",
  },
  key_figures_present: {
    title: "Key figures present",
    blurb: "Material figures from the source appear in the report.",
    group: "job",
  },
  report_length: {
    title: "Report length within range",
    blurb: "The report length falls within the expected bounds.",
    group: "job",
  },
  report_has_headings: {
    title: "Report headings present",
    blurb: "The report is organised into headed sections.",
    group: "job",
  },
  contains: {
    title: "Required wording present",
    blurb: "The output contains phrases required by this case.",
    group: "job",
  },
  not_contains: {
    title: "Prohibited wording absent",
    blurb: "The output does not contain phrases excluded by this case.",
    group: "job",
  },
  section_present: {
    title: "Required sections present",
    blurb: "The required headings or sections appear in the output.",
    group: "job",
  },
  heading_count: {
    title: "Heading count within range",
    blurb: "The output uses a number of headings within the expected bounds.",
    group: "job",
  },
  field_match: {
    title: "Required fields present",
    blurb: "Extracted fields match the values required by this case.",
    group: "job",
  },
  json_path: {
    title: "Required data field correct",
    blurb: "A specified value in the structured output is correct.",
    group: "job",
  },
  json_schema_valid: {
    title: "Structured output well formed",
    blurb: "The structured output has the required shape.",
    group: "job",
  },
  length_range: {
    title: "Length within range",
    blurb: "Output length falls within the expected bounds.",
    group: "job",
  },
  regex_match: {
    title: "Required format matched",
    blurb: "The output conforms to the format required by this case.",
    group: "job",
  },
  keyword_count: {
    title: "Key-term frequency",
    blurb: "Required terms appear with the expected frequency.",
    group: "job",
  },
  latency_slo: {
    title: "Completed within the time limit",
    blurb: "Execution time meets the defined service-level objective.",
    group: "ops",
  },
  token_cost_budget: {
    title: "Within usage budget",
    blurb: "Processing volume remains within the allocated budget.",
    group: "ops",
  },
  tool_latency_slo: {
    title: "Tool calls within time limit",
    blurb: "Tool invocations completed within the expected duration.",
    group: "ops",
  },
};

function humanizeName(name) {
  return String(name || "Evaluation criterion")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (ch) => ch.toUpperCase());
}

function guessGroup(name) {
  const n = String(name || "");
  if (/pii|safety|injection|refusal|ground/i.test(n)) return "safety";
  if (/latency|token_cost|budget|slo/i.test(n)) return "ops";
  if (/faith|relevan|complet|coheren|concise|embed|overlap|rubric|quality|similar/i.test(n)) {
    return "quality";
  }
  return "job";
}

CTNA.GROUPS = GROUPS;
CTNA.JUDGE_METRICS = JUDGE_METRICS;

CTNA.escapeHtml = function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (ch) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
};

CTNA.isPassingStatus = function isPassingStatus(status) {
  return status === "PASS" || status === true;
};

CTNA.metricInfo = function metricInfo(name) {
  const known = METRICS[name];
  if (known) return { name, ...known, judge: JUDGE_METRICS.has(name) };
  return {
    name,
    title: humanizeName(name),
    blurb: "An evaluation criterion for this case.",
    group: guessGroup(name),
    judge: JUDGE_METRICS.has(name),
  };
};

function clamp01(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(1, n));
}

CTNA.asPercent = function asPercent(x) {
  if (x === null || x === undefined || Number.isNaN(Number(x))) return null;
  return Math.round(clamp01(x) * 100);
};

CTNA.formatPercent = function formatPercent(x) {
  const p = CTNA.asPercent(x);
  return p === null ? "—" : `${p}%`;
};

CTNA.formatDeltaPts = function formatDeltaPts(d) {
  if (d === null || d === undefined || Number.isNaN(Number(d))) return "";
  const pts = Math.round(Number(d) * 100);
  if (pts === 0) return `<span class="delta-flat">Unchanged from baseline</span>`;
  if (pts > 0) return `<span class="delta-pos">+${pts} point${pts === 1 ? "" : "s"} versus baseline</span>`;
  const abs = Math.abs(pts);
  return `<span class="delta-neg">−${abs} point${abs === 1 ? "" : "s"} versus baseline</span>`;
};

CTNA.deltaClass = function deltaClass(d) {
  if (d === null || d === undefined) return "";
  const pts = Math.round(Number(d) * 100);
  if (pts > 0) return "delta-pos";
  if (pts < 0) return "delta-neg";
  return "delta-flat";
};

CTNA.formatThreshold = function formatThreshold(t) {
  const p = CTNA.asPercent(t);
  if (p === null) return "";
  return `Minimum required: ${p}%`;
};

CTNA.importance = function importance(weight) {
  const w = Number(weight);
  if (!Number.isFinite(w)) return "medium";
  if (w >= 2) return "high";
  if (w >= 1) return "medium";
  return "low";
};

/* Technical skip reasons carry host paths and credential detail. Report the
   institutional meaning; the raw text stays available as audit detail. */
CTNA.skipReason = function skipReason(reason) {
  const text = String(reason || "");
  if (/judge unavailable|credential|Vertex|Application Default/i.test(text)) {
    return "Model-based assessment is not available in this environment.";
  }
  if (/timeout|timed out/i.test(text)) {
    return "The assessment did not complete within the permitted time.";
  }
  if (/quota|rate limit/i.test(text)) {
    return "The assessment provider declined the request due to capacity limits.";
  }
  if (!text) return "This criterion could not be measured.";
  const first = text.split(/(?<=\.)\s/)[0];
  return first.length > 140 ? "This criterion could not be measured." : first;
};

CTNA.importanceLabel = function importanceLabel(weight) {
  return { high: "High", medium: "Medium", low: "Low" }[CTNA.importance(weight)];
};

CTNA.formatImportance = function formatImportance(weight) {
  return `Weighting: ${CTNA.importanceLabel(weight)}`;
};

/* Bare delta wording for tabular layouts, without the "versus baseline" suffix. */
CTNA.deltaLabel = function deltaLabel(d) {
  if (d === null || d === undefined || Number.isNaN(Number(d))) return "Not compared";
  const pts = Math.round(Number(d) * 100);
  if (pts === 0) return "Unchanged";
  const abs = Math.abs(pts);
  const noun = `point${abs === 1 ? "" : "s"}`;
  return pts > 0 ? `+${abs} ${noun}` : `−${abs} ${noun}`;
};

CTNA.formatRaw = function formatRaw(value, unit) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "";
  const n = Number(value);
  const u = (unit || "").toLowerCase();
  if (u === "ms" || u === "millisecond" || u === "milliseconds") {
    if (n >= 1000) {
      const s = n / 1000;
      const shown = s >= 10 ? s.toFixed(0) : s.toFixed(1);
      return `Duration: ${shown} second${shown === "1.0" || shown === "1" ? "" : "s"}`;
    }
    return `Duration: ${Math.round(n)} ms`;
  }
  if (u === "s" || u === "sec" || u === "seconds") {
    const shown = n >= 10 ? n.toFixed(0) : n.toFixed(1);
    return `Duration: ${shown} second${shown === "1.0" || shown === "1" ? "" : "s"}`;
  }
  if (u === "tokens" || u === "token") {
    return `Token usage: ${Math.round(n).toLocaleString()}`;
  }
  if (u === "count") return `${Math.round(n)}`;
  if (u === "usd" || u === "$") return `Cost: $${n.toFixed(2)}`;
  if (u === "ratio") return "";
  if (u) return `${n} ${unit}`;
  return String(n);
};

CTNA.formatDrift = function formatDrift(stats) {
  if (!stats || stats.n_cases < 2 || stats.drift_p_value === null || stats.drift_p_value === undefined) {
    return "Insufficient cases to assess change versus the baseline.";
  }
  if (stats.drift_significant) {
    return "Quality has declined versus the baseline. The change is statistically significant.";
  }
  if (Number(stats.mean_delta) > 0.005) {
    return "Quality has improved versus the baseline.";
  }
  return "Quality is consistent with the baseline.";
};

CTNA.formatPassCount = function formatPassCount(stats) {
  if (!stats) return "No cases in this evaluation.";
  const n = stats.n_cases || 0;
  const passed = Math.round((stats.pass_rate || 0) * n);
  return `${passed} of ${n} case${n === 1 ? "" : "s"} met the required standard (${CTNA.formatPercent(stats.pass_rate)})`;
};

CTNA.formatMeanQuality = function formatMeanQuality(stats) {
  if (!stats) return "";
  const avg = CTNA.formatPercent(stats.mean_score);
  if (!stats.n_cases || stats.n_cases < 2) return `Mean score ${avg}.`;
  const lo = CTNA.asPercent(stats.ci95_low);
  const hi = CTNA.asPercent(stats.ci95_high);
  if (lo === null || hi === null) return `Mean score ${avg}.`;
  return `Mean score ${avg}. Indicative range ${lo}–${hi}%.`;
};

CTNA.formatHumanAgreement = function formatHumanAgreement(stats) {
  if (!stats || !stats.labeled_cases || stats.f1 === null || stats.f1 === undefined) return "";
  const times = Math.round(clamp01(stats.f1) * 10);
  return `Agreement with expert labels: ${times} of 10.`;
};

CTNA.groupScores = function groupScores(scores) {
  const buckets = {};
  for (const g of GROUPS) buckets[g.id] = [];
  for (const sc of scores || []) {
    const info = CTNA.metricInfo(sc.metric);
    if (!buckets[info.group]) buckets[info.group] = [];
    buckets[info.group].push({ sc, info });
  }
  const rank = (entry) => {
    const { sc } = entry;
    if (!sc.passed) return 0;
    if (sc.critical) return 1;
    return { high: 2, medium: 3, low: 4 }[CTNA.importance(sc.weight)];
  };
  return GROUPS
    .map((g) => ({ ...g, items: (buckets[g.id] || []).sort((a, b) => rank(a) - rank(b)) }))
    .filter((g) => g.items.length);
};

CTNA.scoreRingHtml = function scoreRingHtml(score, size) {
  const pct = CTNA.asPercent(score);
  const shown = pct === null ? "—" : String(pct);
  const r = 52;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - (pct === null ? 0 : pct / 100));
  const cls = pct === null ? "" : pct >= 70 ? "ok" : pct >= 40 ? "mid" : "bad";
  const px = size || 128;
  return `<div class="score-ring ${cls}" style="width:${px}px;height:${px}px">
    <svg viewBox="0 0 120 120" aria-hidden="true">
      <circle class="ring-track" cx="60" cy="60" r="${r}"></circle>
      <circle class="ring-fill" cx="60" cy="60" r="${r}"
        stroke-dasharray="${c.toFixed(2)}"
        stroke-dashoffset="${offset.toFixed(2)}"
        transform="rotate(-90 60 60)"></circle>
    </svg>
    <div class="ring-label"><span class="ring-num">${shown}</span>${pct === null ? "" : '<span class="ring-unit">%</span>'}</div>
  </div>`;
};

CTNA.stampHtml = function stampHtml(status) {
  if (status === "ERROR" || status === "error") {
    return `<div class="stamp error" aria-label="Error">ERROR</div>`;
  }
  const pass = CTNA.isPassingStatus(status);
  return `<div class="stamp ${pass ? "pass" : "fail"}" aria-label="${pass ? "Pass" : "Fail"}">${pass ? "PASS" : "FAIL"}</div>`;
};

CTNA.meterHtml = function meterHtml(score) {
  const pct = CTNA.asPercent(score);
  const width = pct === null ? 0 : pct;
  return `<span class="meter" aria-hidden="true"><span style="width:${width}%"></span></span>`;
};

function currentTheme() {
  return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
}

function applyTheme(theme) {
  const next = theme === "light" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  try { localStorage.setItem(THEME_KEY, next); } catch (_) { /* ignore */ }
  const btn = document.getElementById("theme-toggle");
  if (btn) {
    const toLight = next !== "light";
    btn.setAttribute("aria-label", toLight ? "Switch to light appearance" : "Switch to dark appearance");
    btn.title = toLight ? "Light appearance" : "Dark appearance";
    btn.setAttribute("data-theme-next", toLight ? "light" : "dark");
  }
}

CTNA.initThemeToggle = function initThemeToggle() {
  const btn = document.getElementById("theme-toggle");
  if (!btn) return;
  applyTheme(currentTheme());
  btn.addEventListener("click", () => {
    applyTheme(currentTheme() === "light" ? "dark" : "light");
  });
};

CTNA.initTlsToggle = function initTlsToggle() {
  const toggle = document.getElementById("tls-toggle");
  if (!toggle || toggle.dataset.tlsInitialized === "true") return;
  toggle.dataset.tlsInitialized = "true";

  const apply = (excludeTls) => {
    const enabled = !excludeTls;
    toggle.dataset.enabled = String(enabled);
    toggle.classList.toggle("off", excludeTls);
    toggle.setAttribute("aria-pressed", String(excludeTls));
    toggle.textContent = excludeTls ? "TLS: Disabled" : "TLS: Verify";
    toggle.title = excludeTls
      ? "TLS verification is disabled for outbound HTTPS calls."
      : "TLS verification is enabled for outbound HTTPS calls.";
    toggle.disabled = false;
  };

  const refresh = async () => {
    try {
      const cfg = await fetch("api/settings", { cache: "no-store" }).then((r) => r.ok ? r.json() : Promise.reject(new Error("settings unavailable")));
      apply(Boolean(cfg?.exclude_tls));
    } catch (_) {
      apply(false);
    }
  };

  toggle.addEventListener("click", async () => {
    const nextState = toggle.dataset.enabled !== "true";
    toggle.disabled = true;
    try {
      const res = await fetch("api/settings/tls", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: nextState }),
      });
      const data = res.ok ? await res.json() : null;
      if (!res.ok) {
        throw new Error((data && data.detail) || "Unable to update TLS setting.");
      }
      apply(Boolean(data?.exclude_tls));
    } catch (e) {
      toggle.disabled = false;
      alert(e.message || "Unable to update TLS setting.");
    }
  });

  toggle.disabled = true;
  refresh();
};

CTNA.initThemeToggle();
CTNA.initTlsToggle();
