const $=(s)=>document.querySelector(s);
const esc=(v)=>CTNA.escapeHtml(String(v??""));
const HISTORY_KEY="ctna-api-tester-history";
let responseText="";

function theme(){
  const next=document.documentElement.getAttribute("data-theme")==="dark"?"light":"dark";
  document.documentElement.setAttribute("data-theme",next);localStorage.setItem("ctna-theme",next);
}
function loadTheme(){try{const t=localStorage.getItem("ctna-theme");if(t)document.documentElement.setAttribute("data-theme",t);}catch{}}
function addRow(container,key="",value=""){
  const row=document.createElement("div");row.className="kv-row";
  row.innerHTML=`<input placeholder="Key" value="${esc(key)}"><input placeholder="Value" value="${esc(value)}"><button type="button" class="button-quiet" title="Remove">×</button>`;
  row.querySelector("button").onclick=()=>row.remove();container.appendChild(row);
}
function collectRows(id){return [...document.querySelectorAll(`#${id} .kv-row`)].map(r=>{const i=r.querySelectorAll("input");return [i[0].value.trim(),i[1].value];}).filter(x=>x[0]);}
function setRows(id,rows){const c=$(id);c.innerHTML="";(rows.length?rows:[["",""]]).forEach(r=>addRow(c,r[0],r[1]));}
function setTab(tab){document.querySelectorAll(".request-tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));["headers","params","body","auth"].forEach(x=>$("#tab-"+x).hidden=x!==tab);}
function parseBody(){const type=$("#body-type").value;const raw=$("#body").value;if(type==="json"){if(!raw.trim())return null;return JSON.parse(raw);}return raw;}
function buildRequest(){
  const url=new URL($("#url").value.trim());
  for(const [k,v] of collectRows("params-list"))url.searchParams.set(k,v);
  const headers=Object.fromEntries(collectRows("headers-list"));
  const type=$("#body-type").value; let body=null;
  let json=null;
  let data=null;
  if(!["GET","HEAD"].includes($("#method").value)){
    if(type==="json"){
      body=parseBody();
      json=body;
      headers["Content-Type"]=headers["Content-Type"]||"application/json";
    }
    else if(type==="form"){
      const p=new URLSearchParams();
      for(const parts of $("#body").value.split(/\r?\n/).map(x=>x.split("=")).filter(x=>x[0]?.trim())){
        const [k,...rest]=parts;
        p.set(k.trim(),rest.join("="));
      }
      body=p.toString();
      data=body;
      headers["Content-Type"]=headers["Content-Type"]||"application/x-www-form-urlencoded";
    }
    else {
      body=$("#body").value;
      data=body;
      headers["Content-Type"]=headers["Content-Type"]||"text/plain";
    }
  }
  return {url:url.toString(),method:$("#method").value,headers,body,json,data};
}
function showError(text){const e=$("#request-error");e.textContent=text;e.hidden=!text;}
function pretty(value,ct){
  if(value==null)return "";
  if(typeof value==="string"){
    if((ct||"").includes("json")){try{return JSON.stringify(JSON.parse(value),null,2);}catch{}}
    try{const x=JSON.parse(value);return JSON.stringify(x,null,2);}catch{return value;}
  }
  if(typeof value==="object"){
    try{return JSON.stringify(value,null,2);}catch{return String(value);}
  }
  return String(value);
}
function renderHeaders(headers){const el=$("#response-headers-list");const entries=[...headers.entries()];el.innerHTML=entries.length?entries.map(([k,v])=>`<div class="response-header-row"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join(""):"No response headers.";}
function history(){try{return JSON.parse(localStorage.getItem(HISTORY_KEY)||"[]");}catch{return[];}}
function saveHistory(item){try{const h=history().filter(x=>!(x.method===item.method&&x.url===item.url));h.unshift(item);localStorage.setItem(HISTORY_KEY,JSON.stringify(h.slice(0,20)));renderHistory();}catch{}}
function renderHistory(){const c=$("#history-list"),h=history();c.innerHTML=h.length?h.map((x,i)=>`<button class="history-item" data-i="${i}" type="button"><span class="history-method">${esc(x.method)}</span><span class="history-url">${esc(x.url)}</span><span class="history-status">${esc(x.status||"")}</span></button>`).join(""):"<div class='small-note'>No requests yet.</div>";c.querySelectorAll("button").forEach(b=>b.onclick=()=>loadHistory(h[Number(b.dataset.i)]));}
function loadHistory(item){$("#method").value=item.method;$("#url").value=item.url;showError("");}
async function send(){
  showError("");$("#send").disabled=true;$("#send").textContent="Sending…";
  try{
    const req=buildRequest();
    const t0=performance.now();
    const r=await fetch("api/playground/http",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(req)});
    const d=await r.json();
    const elapsed=Math.round(performance.now()-t0);
    if(!r.ok)throw new Error(d.detail||"Request failed");
    const contentType=d.headers?.["content-type"]||d.headers?.["Content-Type"]||"";
    const responseBody=d.body ?? d.text ?? "";
    const status=Number(d.status ?? d.status_code ?? 0);
    responseText=pretty(responseBody,contentType);$("#response-content").textContent=responseText||"(empty response)";
    $("#response-status").textContent=`${status} ${d.reason||""}`.trim();$("#response-status").className=`response-status ${status<400?"pass":"fail"}`;$("#response-dot").className=`status-dot ${status<400?"ok":"err"}`;$("#response-meta").textContent=`${d.duration_ms??elapsed} ms · ${d.size_bytes??new TextEncoder().encode(responseText||"").length} bytes`;
    renderHeaders(new Headers(d.headers||{}));$("#copy-response").disabled=!responseText;
    saveHistory({method:req.method,url:req.url,status:String(status),ts:Date.now()});
  }catch(e){$("#response-status").textContent="Request error";$("#response-status").className="response-status fail";$("#response-dot").className="status-dot err";$("#response-meta").textContent="";$("#response-content").textContent=e.message||String(e);$("#copy-response").disabled=true;showError(e.message||String(e));}
  finally{$("#send").disabled=false;$("#send").textContent="Send";}
}

$("#theme-toggle").onclick=theme;
$(".request-tabs").querySelectorAll(".request-tab").forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
$("#add-header").onclick=()=>addRow($("#headers-list"));$("#add-param").onclick=()=>addRow($("#params-list"));
$("#send").onclick=send;$("#clear-history").onclick=()=>{localStorage.removeItem(HISTORY_KEY);renderHistory();};
$("#clear-response").onclick=()=>{responseText="";$("#response-content").textContent="No response yet.";$("#response-status").textContent="No response";$("#response-dot").className="status-dot";$("#response-meta").textContent="Send a request to inspect the response.";$("#response-headers-list").textContent="No response yet.";$("#copy-response").disabled=true;};
$("#copy-response").onclick=()=>navigator.clipboard?.writeText(responseText);
$("#url").addEventListener("keydown",e=>{if(e.key==="Enter")send();});
setRows("#headers-list",[["Accept","application/json"]]);setRows("#params-list",[]);loadTheme();renderHistory();

// Authentication presets. Secrets never enter browser history.
function updateAuthFields(){
  const type=$("#auth-type").value;
  const key=type==='apikey'||type==='custom', value=type==='bearer'||type==='apikey'||type==='custom', basic=type==='basic';
  ["#auth-key-wrap","#auth-value-wrap","#auth-user-wrap","#auth-pass-wrap"].forEach(x=>{if($(x))$(x).hidden=true;});
  if(key) $("#auth-key-wrap").hidden=false;
  if(value) $("#auth-value-wrap").hidden=false;
  if(basic){$("#auth-user-wrap").hidden=false;$("#auth-pass-wrap").hidden=false;}
}
function applyAuth(headers){
  const type=$("#auth-type")?.value||'none';
  if(type==='bearer'){const token=$("#auth-value")?.value||'';if(token)headers.Authorization=`Bearer ${token}`;}
  if(type==='apikey'){const name=$("#auth-key")?.value.trim()||'X-API-Key',value=$("#auth-value")?.value||'';if(value)headers[name]=value;}
  if(type==='custom'){const name=$("#auth-key")?.value.trim(),value=$("#auth-value")?.value||'';if(name&&value)headers[name]=value;}
  if(type==='basic'){const u=$("#auth-user")?.value||'',p=$("#auth-pass")?.value||'';if(u||p)headers.Authorization=`Basic ${btoa(unescape(encodeURIComponent(`${u}:${p}`)))}`;}
}
const _originalBuildRequest=buildRequest;
buildRequest=function(){const req=_originalBuildRequest();applyAuth(req.headers);return req;};
$("#auth-type")?.addEventListener("change",updateAuthFields);updateAuthFields();
