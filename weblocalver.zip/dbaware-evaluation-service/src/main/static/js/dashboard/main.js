// Dashboard page entry: loads health, agents and the full run history, then renders.

import "../ui/shell.js";
import { showError, showToast } from "../ui/toast.js";
import { escapeHtml } from "../lib/fragments.js";
import { enhance } from "../../combobox.js";
import {
  loadHealth, loadAgents, loadAllRuns, scopeRuns, searchRuns, quickFilterRuns, oldestFirst, plural, ALL_AGENTS, MAX_RUNS,
} from "./data.js";
import { renderSummaryLoading, renderStats, renderLatest, renderBaselineContext, renderAttention } from "./summary.js";
import { renderTrendChart, renderTrendLoading } from "./trend-chart.js";
import { renderHistory, renderHistoryLoading, renderHistoryError, wireRowClicks, setActiveChip, wireChips } from "./history.js";
import { parseReps, REPS_MESSAGE, MIN_REPS, MAX_REPS } from "../lib/reps.js";

const $ = (sel) => document.querySelector(sel);
const SEARCH_DEBOUNCE_MS = 200;
const DEFAULT_DAYS = "30";
const SEARCH = "#run-search";
const TIME_FILTER = "#time-filter";
const state = { runs: [], scoped: [], quickFilter: "all", searchTimer: 0 };

// ---------- Health ----------

const HEALTH_VIEWS = {
  ok: { text: "Available", cls: "ok" },
  degraded: { text: "Degraded", cls: "warn" },
};

async function refreshHealth() {
  const pill = $("#health");
  const versionDisplay = $("#version-display");
  try {
    const h = await loadHealth();
    const view = HEALTH_VIEWS[h?.status] || { text: "Unavailable", cls: "bad" };
    pill.textContent = view.text;
    pill.className = `pill ${view.cls}`;
    const bits = [`status ${h?.status ?? "unknown"}`];
    if (h?.vertex) bits.push(`judge: ${h.vertex}`);
    if (h?.credential_class) bits.push(h.credential_class);
    if (h?.status === "degraded") bits.push("Automated (model-based) assessment may be unavailable");
    pill.title = bits.join(" · ");
    if (h?.version) {
      versionDisplay.textContent = `Version: ${h.version}`;
    } else {
      versionDisplay.textContent = "Version: unknown";
    }
  } catch (err) {
    pill.textContent = "Service unavailable";
    pill.className = "pill bad";
    pill.title = err.message;
    versionDisplay.textContent = "Version: unavailable";
  }
}

// ---------- Agents ----------

function agentOption(agent) {
  const meta = [];
  if (agent.cases !== null && agent.cases !== undefined) meta.push(plural(agent.cases, "case"));
  // active_metrics are the metrics a case actually evaluates; dataset.metrics
  // may declare more than that (the registry logs any such gap at startup).
  if (agent.active_metrics) meta.push(plural(agent.active_metrics.length, "metric"));
  if (agent.dataset_version) meta.push(`v${agent.dataset_version}`);
  return `<option value="${escapeHtml(agent.agent_id)}" data-meta="${escapeHtml(meta.join(" · "))}">${escapeHtml(agent.name || agent.agent_id)}</option>`;
}

async function populateAgents() {
  const select = $("#agent");
  try {
    const agents = await loadAgents();
    select.innerHTML = `<option value="${ALL_AGENTS}">All agents</option>${agents.map(agentOption).join("")}`;
    enhance(select, { placeholder: "Search agents", emptyText: "No agents found" });
  } catch (err) {
    select.innerHTML = `<option value="${ALL_AGENTS}">All agents (agent list unavailable)</option>`;
    enhance(select, { placeholder: "Unable to load agents" });
    showError(`Unable to load agents: ${err.message}`);
  }
  updateAgentScope();
}

function selectedAgent() {
  return $("#agent").value || ALL_AGENTS;
}

function agentLabel(agentId) {
  const option = Array.from($("#agent").options).find((o) => o.value === agentId);
  return option ? option.textContent.trim() : agentId;
}

/** The agent control scopes the dashboard and targets new runs. */
function updateAgentScope() {
  const agent = selectedAgent();
  const scoped = agent !== ALL_AGENTS;
  const button = $("#run");
  button.disabled = !scoped;
  button.title = scoped ? "" : "Select an agent to start an evaluation";
  $("#agent-scope-note").textContent = scoped
    ? `Dashboard scoped to ${agentLabel(agent)}.`
    : "Showing all agents. Select an agent to scope this dashboard and start an evaluation.";
}

// ---------- Runs ----------

async function populateRuns() {
  try {
    const { runs, capped } = await loadAllRuns();
    state.runs = runs;
    $("#runs-cap-note").hidden = !capped;
    $("#runs-cap-note").textContent = capped
      ? `Showing the ${MAX_RUNS} most recent evaluations. Older runs are not included in these figures.`
      : "";
    applyScope();
  } catch (err) {
    state.runs = [];
    applyScope();
    renderHistoryError(err.message);
    showError(`Unable to load evaluation history: ${err.message}`);
  }
}

function renderHistoryOnly() {
  const query = $(SEARCH).value;
  renderHistory(quickFilterRuns(searchRuns(state.scoped, query), state.quickFilter), state.scoped.length);
}

function applyScope() {
  state.scoped = scopeRuns(state.runs, { agent: selectedAgent(), days: $(TIME_FILTER).value });
  const ordered = oldestFirst(state.scoped);
  $(".dashboard-stats").removeAttribute("aria-busy");
  renderStats(state.scoped, ordered);
  renderLatest(ordered.at(-1) || null);
  renderBaselineContext(ordered.at(-1) || null);
  renderAttention(state.scoped);
  renderTrendChart(ordered);
  renderHistoryOnly();
}

function selectQuickFilter(filter) {
  state.quickFilter = filter;
  setActiveChip(filter);
  renderHistoryOnly();
}

function clearRunFilters() {
  $(SEARCH).value = "";
  const agent = $("#agent");
  agent.value = ALL_AGENTS;
  agent._ctnaCombobox?.sync();
  updateAgentScope();
  $(TIME_FILTER).value = DEFAULT_DAYS;
  state.quickFilter = "all";
  setActiveChip("all");
  applyScope();
}

function focusRegressions() {
  selectQuickFilter("regressed");
  $("#history-title").scrollIntoView({ behavior: "smooth", block: "start" });
}

// ---------- New evaluation ----------

function focusAgentPicker() {
  const combobox = $("#agent")._ctnaCombobox;
  if (combobox) combobox.input.focus();
  else $("#agent").focus();
}

function validateReps({ clamp }) {
  const input = $("#reps");
  const { value, valid } = parseReps(input.value);
  input.setCustomValidity(valid ? "" : REPS_MESSAGE);
  input.setAttribute("aria-invalid", String(!valid));
  if (!valid && clamp) {
    input.value = String(value);
    input.setCustomValidity("");
    input.setAttribute("aria-invalid", "false");
    showToast(`Assessments set to ${value}. Allowed range is ${MIN_REPS}–${MAX_REPS}.`, { kind: "warn" });
  }
  return { value, valid };
}

function startEvaluation() {
  const agent = selectedAgent();
  if (agent === ALL_AGENTS) {
    focusAgentPicker();
    return;
  }
  const { value, valid } = validateReps({ clamp: false });
  if (!valid) {
    $("#reps").reportValidity();
    $("#reps").focus();
    return;
  }
  location.href = `run.html?agent=${encodeURIComponent(agent)}&reps=${value}`;
}

// ---------- Wiring ----------

function wireEvents() {
  $("#run").addEventListener("click", startEvaluation);
  $("#view-regressions").addEventListener("click", focusRegressions);
  $("#latest-evaluation").addEventListener("click", (event) => {
    if (event.target.closest("[data-action='start']")) startEvaluation();
  });
  $("#reps").addEventListener("input", () => validateReps({ clamp: false }));
  $("#reps").addEventListener("change", () => validateReps({ clamp: true }));
  $(SEARCH).addEventListener("input", () => {
    window.clearTimeout(state.searchTimer);
    state.searchTimer = window.setTimeout(renderHistoryOnly, SEARCH_DEBOUNCE_MS);
  });
  $("#agent").addEventListener("change", () => {
    updateAgentScope();
    applyScope();
  });
  $(TIME_FILTER).addEventListener("change", applyScope);
  wireChips(selectQuickFilter);
  wireRowClicks(clearRunFilters);
  document.addEventListener("tls-changed", refreshHealth);
}

function init() {
  $(".dashboard-stats").setAttribute("aria-busy", "true");
  renderSummaryLoading();
  renderTrendLoading();
  renderHistoryLoading();
  setActiveChip(state.quickFilter);
  wireEvents();
  refreshHealth();
  Promise.all([populateAgents(), populateRuns()]).catch(showError);
}

init();
