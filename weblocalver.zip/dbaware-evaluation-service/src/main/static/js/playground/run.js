// Runner page: check the settings, start an evaluation, follow its progress, stop
// it, and add the finished result (with the settings used) to the list.

import { showToast } from "../ui/toast.js";
import { cancelRun, clampReps, startRun, validateBundle } from "./bundle-api.js";
import { showCheckResult } from "./check.js";
import { friendlyError, runFailure, runStopped } from "./messages.js";
import { progressLabel } from "./progress-model.js";
import { runHeadline } from "./run-detail-model.js";
import { hideLive, renderBusy, renderNotice, renderProgress } from "./run-progress.js";
import { markStarting, markStopping, resetStopButton, updateRunControls } from "./run-controls.js";
import { RunStream } from "./run-stream.js";
import { addRun } from "./runner-list.js";
import { newEntry } from "./runner-list-model.js";
import { renderSteps } from "./steps.js";
import { caseIds, state } from "./store.js";
import { $, pillKindForStatus, setStatus } from "./view.js";
import { renderViewState } from "./views.js";
import { refreshBundleMetadata } from "./workspace.js";

const RUNNING = "running";
const PROGRESS_EVENTS = new Set(["case_started", "observation", "metric_started"]);

let activeStream = null;
let activeMeta = null;
let counters = { total: 0, casesDone: 0 };

function showRunning(text = `Running… ${progressLabel(counters)}`) {
  state.runningText = text;
  setStatus(text, RUNNING);
  renderViewState();
  renderSteps();
}

/** Stops following the current evaluation (closes SSE, clears polling). */
export function stopActiveRun() {
  if (activeStream) activeStream.stop();
  activeStream = null;
  state.stream = null;
  state.runningText = "";
  resetStopButton();
  updateRunControls();
  renderViewState();
  renderSteps();
}

function onDone(run) {
  const meta = activeMeta ? { ...activeMeta, finishedAt: new Date().toISOString() } : null;
  stopActiveRun();
  if (!run) {
    renderNotice({ tone: "warn", title: "No result came back", text: "The evaluation finished but sent no result. Try running it again." });
    return;
  }
  hideLive();
  addRun(newEntry(run, meta));
  setStatus(runHeadline(run), pillKindForStatus(run.status));
  renderSteps();
}

function onFailure(notice, statusText, kind) {
  stopActiveRun();
  renderNotice(notice);
  setStatus(statusText, kind);
  renderSteps();
}

function countProgress(event) {
  renderProgress(counters, event);
}

const HANDLERS = {
  run_started(event) {
    counters.total = Number(event.total_cases) || 0;
    showRunning();
  },
  case_done(event) {
    counters.casesDone += 1;
    showRunning();
    countProgress(event);
  },
  metric_done: countProgress,
  metric_skipped: countProgress,
  playground_done(event) {
    onDone(event.run);
  },
  error(event) {
    onFailure({ tone: "bad", ...runFailure(event) }, "Could not finish", "bad");
  },
  run_cancelled(event) {
    onFailure({ tone: "stopped", ...runStopped(event) }, "Stopped", "warn");
  },
};

function handleEvent(event) {
  const handler = HANDLERS[event?.type];
  if (handler) handler(event);
  else if (PROGRESS_EVENTS.has(event?.type)) countProgress(event);
}

function onLost(err) {
  const notice = { tone: "bad", ...friendlyError(err, "run"), title: "We lost contact with the evaluation" };
  onFailure(notice, "Could not finish", "bad");
}

function follow(streamId) {
  counters = { total: 0, casesDone: 0 };
  state.stream = streamId;
  updateRunControls();
  renderProgress(counters, null);
  showRunning("Running…");
  activeStream = new RunStream(streamId, {
    onEvent: handleEvent,
    onConnection: (mode) => showRunning(mode === "live" ? undefined : "Running… reconnecting"),
    onLost,
  }).start();
}

/** Builds the edited settings and checks them; throws with `.problems` when they need fixing. */
async function checkedBundle() {
  const blob = await refreshBundleMetadata();
  if (!state.selectedCases.length) throw new Error("Choose at least one test to include.");
  const result = (await validateBundle(blob)) || {};
  if (!result.valid) {
    showCheckResult(result);
    const error = new Error("The settings need fixing before they can be tried.");
    error.problems = Array.isArray(result.errors) && result.errors.length ? result.errors : [error.message];
    throw error;
  }
  return blob;
}

/** The settings this run uses, kept with its result. */
function runSettings() {
  const custom = $("#base-url").value.trim();
  return {
    startedAt: new Date().toISOString(),
    targetUrl: custom || state.agent?.base_url || "",
    customUrl: Boolean(custom),
    reps: clampReps($("#reps").value),
    caseIds: [...state.selectedCases],
    totalCases: caseIds(state.dataset).length,
    agentId: state.agent?.agent_id || "",
    agentName: state.agent?.name || "",
  };
}

export async function runEvaluation() {
  if (state.stream) return;
  markStarting();
  setStatus("Getting ready…", RUNNING);
  renderBusy("Checking your settings before running them…");
  try {
    const blob = await checkedBundle();
    const meta = runSettings();
    const started = await startRun(blob, { baseUrl: meta.customUrl ? meta.targetUrl : "", reps: meta.reps, caseIds: meta.caseIds });
    activeMeta = meta;
    follow(started.stream_id);
  } catch (err) {
    onFailure({ tone: "bad", ...friendlyError(err, "run") }, "Could not start", "bad");
  }
}

export async function cancelActiveRun() {
  const id = state.stream;
  if (!id) return;
  markStopping();
  try {
    await cancelRun(id);
  } catch (err) {
    resetStopButton();
    if (err.status === 409) {
      showToast("The evaluation had already finished.", { kind: "info" });
      return;
    }
    const { title, text } = friendlyError(err, "stop");
    showToast(`${title}. ${text}`, { kind: "bad" });
  }
}
