// Workspace rendering shared by the three views: what is loaded (Upload), the
// unsaved-changes note and badge, the file shown in the editor, and the summary
// (AI assistant, tests) that the server derives from the edited files.

import { exportBundle, inspectBundle } from "./bundle-api.js";
import { reconcileSelection, renderCases } from "./cases.js";
import { showFile } from "./editor.js";
import { renderFiles } from "./files.js";
import { plainProblem } from "./messages.js";
import { renderRunner } from "./runner-list.js";
import { renderSteps } from "./steps.js";
import { caseIds, cloneFiles, fileItems, isDirty, persistSoon, sortedPaths, state } from "./store.js";
import { bundleSummary, summaryHtml, unsavedNote } from "./upload-model.js";
import { $ } from "./view.js";
import { isLoaded, renderViewState } from "./views.js";
import { toFiles } from "./workspace-model.js";

function countText(n, noun) {
  const count = Number(n) || 0;
  return `${count} ${noun}${count === 1 ? "" : "s"}`;
}

function renderWarnings() {
  const messages = [...state.warnings];
  if (state.metadataError) messages.push(`The summary could not be updated after your last change. ${plainProblem(state.metadataError)}`);
  const text = messages.join(" ");
  document.querySelectorAll("[data-warning]").forEach((box) => {
    box.hidden = !text;
    if (box.textContent !== text) box.textContent = text;
  });
}

/** Refreshes every place that shows the AI assistant, its tests and checks. */
export function renderSummary() {
  const agent = state.agent || {};
  const dataset = state.dataset || {};
  const summary = bundleSummary(state);
  $("#loaded-summary").innerHTML = summaryHtml(summary);
  $("#editor-copy").textContent = `${summary.assistant} · ${countText(dataset.cases, "test")} · ${countText(dataset.metrics, "check")}`;
  $("#runner-copy").textContent = `Try the settings of ${summary.assistant} and look back at earlier evaluations.`;
  $("#base-url").placeholder = agent.base_url || "https://…";
  $("#target-default").textContent = agent.base_url
    ? `Leave empty to use the address in agent.yaml: ${agent.base_url}`
    : "agent.yaml has no address, so please type one here.";
  renderWarnings();
}

/** Unsaved-changes badge (Editor), note and Reset button (Upload), and the tab notes. */
export function updateDirtyState() {
  const loaded = isLoaded();
  const dirty = loaded && isDirty();
  $("#dirty-badge").hidden = !dirty;
  $("#reset-config").disabled = !dirty;
  const note = unsavedNote({ loaded, dirty, saved: state.saved });
  const box = $("#unsaved-note");
  box.hidden = !note;
  if (note) {
    box.textContent = note.text;
    box.dataset.tone = note.tone;
  }
  renderViewState();
  renderSteps();
}

export function selectFile(path) {
  state.selected = path && state.files[path] ? path : null;
  showFile(state.selected);
  renderFiles();
}

/** Re-renders all three views from state. */
export function renderWorkspace() {
  renderViewState();
  if (isLoaded()) {
    renderSummary();
    renderCases();
    selectFile(state.files[state.selected] ? state.selected : sortedPaths()[0]);
  } else {
    $("#zip-input").value = "";
    $("#base-url").value = "";
  }
  updateDirtyState();
  renderRunner();
  renderSteps();
}

/** Applies a fresh /inspect result as a newly loaded bundle. */
export function loadInspection(data) {
  state.files = toFiles(data.files);
  state.original = cloneFiles(state.files);
  state.root = data.root || "";
  state.agent = data.agent || null;
  state.dataset = data.dataset || null;
  state.customTests = data.custom_tests || null;
  state.warnings = Array.isArray(data.warnings) ? data.warnings : [];
  state.metadataError = "";
  state.selected = sortedPaths()[0] || null;
  state.selectedCases = caseIds(state.dataset);
}

function mergeInspection(data) {
  state.root = data.root || "";
  state.agent = data.agent || state.agent;
  state.dataset = data.dataset || state.dataset;
  state.customTests = data.custom_tests || state.customTests;
  state.warnings = Array.isArray(data.warnings) ? data.warnings : [];
  state.metadataError = "";
  reconcileSelection();
}

/** Re-derives agent/dataset metadata from the edited files. Resolves the bundle ZIP. */
export async function refreshBundleMetadata() {
  const blob = await exportBundle(fileItems(), "");
  const data = await inspectBundle(blob);
  mergeInspection(data);
  renderSummary();
  renderCases();
  updateDirtyState();
  persistSoon();
  return blob;
}

/** Surfaces a metadata refresh failure next to the settings (not swallowed). */
export function reportMetadataError(err) {
  state.metadataError = err?.message || String(err);
  renderWarnings();
}
