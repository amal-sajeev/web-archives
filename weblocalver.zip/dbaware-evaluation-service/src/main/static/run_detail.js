// Standalone run scorecard. Reads ?run=<uuid> and renders a plain-English report.

const runId = new URLSearchParams(location.search).get("run");

const $ = (s) => document.querySelector(s);
let currentRun = null;

function pill(text, cls) {
  const p = $("#run-pill");
  p.textContent = text;
  p.className = "pill " + (cls || "");
}
function statusClass(status) { return CTNA.isPassingStatus(status) ? "ok" : "bad"; }

function setBaselineStatus(text, cls = "") {
  const el = $("#baseline-status");
  if (!el) return;
  el.textContent = text;
  el.className = cls ? cls : "muted";
}

function setBaselineResult(payload) {
  const pre = $("#baseline-result");
  const detail = $("#baseline-result-detail");
  if (!pre) return;
  if (!payload) {
    if (detail) detail.hidden = true;
    pre.textContent = "";
    return;
  }
  if (detail) detail.hidden = false;
  pre.textContent = JSON.stringify(payload, null, 2);
}

async function promoteBaselines(run) {
  if (!run || !run.run_id) return;
  const button = $("#promote-baselines");
  if (button) button.disabled = true;

  setBaselineStatus("Promoting baseline…", "muted");
  setBaselineResult(null);

  try {
    const res = await fetch(`api/baselines/promote/${encodeURIComponent(run.run_id)}`, {
      method: "POST",
    });
    const payload = await res.json();
    if (!res.ok) {
      setBaselineStatus(`Baseline promotion failed (${res.status}).`, "fail");
      setBaselineResult(payload);
      return;
    }
    const count = Array.isArray(payload.promoted) ? payload.promoted.length : 0;
    setBaselineStatus(`Baseline promoted. Subsequent evaluations will be compared against ${count} criteria from this run.`, "ok");
    setBaselineResult(payload);
  } catch (e) {
    setBaselineStatus("Baseline promotion failed: the service is unavailable.", "fail");
  } finally {
    if (button) button.disabled = false;
  }
}

function requestBaselinePromotion(run) {
  const dialog = $("#baseline-dialog");
  if (!dialog || !run) return;
  dialog.returnValue = "";
  $("#confirm-runid").textContent = run.run_id;
  $("#confirm-score").textContent = CTNA.formatPercent(run.weighted_score);
  $("#baseline-confirmation-text").textContent = run.status === "PASS"
    ? "Future evaluations will use this run as the comparison baseline."
    : "This evaluation did not pass. Promoting it may weaken subsequent comparisons. Future evaluations will use this run as the comparison baseline.";
  dialog.showModal();
}

function copyText(text, button) {
  navigator.clipboard.writeText(text).then(() => {
    const original = button.textContent;
    button.textContent = "Copied";
    window.setTimeout(() => { button.textContent = original; }, 1200);
  });
}

function toText(v) {
  if (v === null || v === undefined) return "";
  if (typeof v === "string") return v;
  const prose = reportBundleToProse(v);
  if (prose) return prose;
  try { return JSON.stringify(v, null, 2); } catch (_) { return String(v); }
}

function markdownToHtml(md) {
  const lines = CTNA.escapeHtml(md).split("\n");
  const html = [];
  let inList = false;
  let inCode = false;
  for (let line of lines) {
    if (line.trim().startsWith("```")) { inCode = !inCode; continue; }
    if (inCode) { html.push(`<pre class="code-block">${line}</pre>`); continue; }
    let m;
    if ((m = line.match(/^(#{1,6})\s+(.+)$/))) {
      if (inList) { html.push("</ul>"); inList = false; }
      html.push(`<h${m[1].length}>${m[2]}</h${m[1].length}>`);
    } else if ((m = line.match(/^[-*+]\s+(.+)$/))) {
      if (!inList) { html.push("<ul>"); inList = true; }
      html.push(`<li>${m[1]}</li>`);
    } else if ((m = line.match(/^\d+\.\s+(.+)$/))) {
      if (!inList) { html.push("<ol>"); inList = true; }
      html.push(`<li>${m[1]}</li>`);
    } else if (line.trim() === "") {
      if (inList) { html.push("</ul>"); inList = false; }
      html.push("");
    } else {
      if (inList) { html.push("</ul>"); inList = false; }
      let processed = line
        .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
        .replace(/\*([^*]+)\*/g, "<em>$1</em>")
        .replace(/`([^`]+)`/g, "<code>$1</code>")
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
      html.push(`<p>${processed}</p>`);
    }
  }
  if (inList) html.push("</ul>");
  return html.join("\n");
}

function previewBlock(c) {
  const obs = c.observation;
  if (!obs || !obs.output) return "";
  const meta = obs.metadata || {};
  const ctype = meta.content_type || "text";
  const output = obs.output;
  let preview = "";

  if (ctype === "markdown" && typeof output === "string") {
    preview = `<div class="doc-preview markdown-body">${markdownToHtml(output)}</div>`;
  } else if (ctype === "json" || typeof output === "object") {
    try {
      const json = typeof output === "string" ? JSON.stringify(JSON.parse(output), null, 2) : JSON.stringify(output, null, 2);
      preview = `<pre class="json-preview">${CTNA.escapeHtml(json)}</pre>`;
    } catch (_) {
      preview = `<pre class="text-preview">${CTNA.escapeHtml(String(output))}</pre>`;
    }
  } else if (meta.extracted_text) {
    preview = `<div class="doc-preview"><div class="doc-type-badge">${ctype.toUpperCase()} (extracted text)</div><pre class="text-preview">${CTNA.escapeHtml(meta.extracted_text)}</pre></div>`;
  } else {
    preview = `<pre class="text-preview">${CTNA.escapeHtml(toText(output))}</pre>`;
  }
  return `<details class="preview">
    <summary>Agent output (${CTNA.escapeHtml(ctype)})</summary>
    ${preview}
  </details>`;
}

function reportBundleToProse(v) {
  if (!v || typeof v !== "object") return "";

  const paragraphText = (rep) => {
    const paras = rep && rep.paragraphs;
    if (!Array.isArray(paras)) return null;
    return paras
      .map((p) => (p && (p.content ?? p.text ?? p.paragraph)) || "")
      .filter((s) => String(s).trim().length)
      .join("\n\n");
  };

  if (Array.isArray(v.paragraphs)) {
    const body = paragraphText(v);
    if (body === null) return "";
    const title = v.report_title || "";
    return (title ? `${title}\n\n` : "") + body;
  }

  const sections = [];
  for (const [key, rep] of Object.entries(v)) {
    if (rep && typeof rep === "object" && Array.isArray(rep.paragraphs)) {
      const body = paragraphText(rep);
      if (body === null) continue;
      const title = rep.report_title || key;
      sections.push(`${title}\n\n${body}`);
    }
  }
  return sections.length ? sections.join("\n\n\n") : "";
}

function tokenize(s) {
  return s.split(/(\s+)/).filter((t) => t.length);
}

function diffTokens(a, b) {
  const n = a.length, m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
  for (let i = n - 1; i >= 0; i--)
    for (let j = m - 1; j >= 0; j--)
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  const ops = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { ops.push(["=", a[i]]); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { ops.push(["-", a[i]]); i++; }
    else { ops.push(["+", b[j]]); j++; }
  }
  while (i < n) { ops.push(["-", a[i]]); i++; }
  while (j < m) { ops.push(["+", b[j]]); j++; }
  return ops;
}

function renderDiffColumns(goldenText, agentText) {
  const ops = diffTokens(tokenize(goldenText), tokenize(agentText));
  let gold = "", agent = "";
  for (const [op, tok] of ops) {
    const safe = CTNA.escapeHtml(tok);
    if (op === "=") { gold += safe; agent += safe; }
    else if (op === "-") { gold += `<span class="d-del">${safe}</span>`; }
    else { agent += `<span class="d-add">${safe}</span>`; }
  }
  return { gold, agent };
}

function diffBlock(c, index) {
  const golden = toText(c.golden_output);
  const agent = toText(c.observation && c.observation.output);
  if (!golden && !agent) return "";
  const identical = golden && agent && golden.trim() === agent.trim();
  let goldHtml, agentHtml;
  if (golden && agent) {
    const cols = renderDiffColumns(golden, agent);
    goldHtml = cols.gold; agentHtml = cols.agent;
  } else {
    goldHtml = CTNA.escapeHtml(golden || "(no reference output on file)");
    agentHtml = CTNA.escapeHtml(agent || "(no agent output)");
  }
  const note = identical
    ? `<span class="chip ok-chip">exact match</span>`
    : (golden && agent ? `<span class="chip">word comparison · <span class="d-del">reference only</span> / <span class="d-add">agent only</span></span>` : "");
  return `
    <details class="diff">
      <summary>Compare reference and agent output ${note}</summary>
      <div class="diff-toolbar">
        <label>
          <span class="sr-only">Search comparison</span>
          <input type="search" class="diff-search" data-case-index="${index}" placeholder="Search outputs" />
        </label>
        <span class="diff-search-result muted" aria-live="polite"></span>
        <button type="button" class="button-quiet copy-output" data-case-index="${index}" data-output="reference">Copy reference</button>
        <button type="button" class="button-quiet copy-output" data-case-index="${index}" data-output="agent">Copy agent output</button>
      </div>
      <div class="diff-grid">
        <div class="diff-col">
          <div class="diff-head">Reference output</div>
          <div class="diff-body">${goldHtml || "<span class='muted'>—</span>"}</div>
        </div>
        <div class="diff-col">
          <div class="diff-head">Agent output</div>
          <div class="diff-body">${agentHtml || "<span class='muted'>—</span>"}</div>
        </div>
      </div>
    </details>`;
}

function caseScoreRange(cases) {
  const scores = (cases || []).map((c) => Number(c.weighted_score)).filter(Number.isFinite);
  if (!scores.length) return "—";
  const low = Math.min(...scores);
  const high = Math.max(...scores);
  return low === high
    ? CTNA.formatPercent(low)
    : `${CTNA.formatPercent(low)}–${CTNA.formatPercent(high)}`;
}

function scorePoints(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return null;
  return Math.round(Number(value) * 100);
}

function formatPoints(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "—";
  return `${Math.round(Number(value))}%`;
}

function formatContribution(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "—";
  const pts = Math.round(Number(value));
  return `${pts} point${pts === 1 ? "" : "s"}`;
}

function shortCaseName(caseId) {
  const text = String(caseId || "");
  if (text.length <= 24) return text;
  return `${text.slice(0, 21)}…`;
}

function allocateCaseContributionPoints(cases, totalPoints) {
  if (!Array.isArray(cases) || !cases.length || totalPoints === null) return [];
  const raw = cases.map((c) => Math.max(0, Number(c.weighted_score) || 0) * 100 / cases.length);
  const base = raw.map((value) => Math.floor(value));
  let remaining = totalPoints - base.reduce((sum, value) => sum + value, 0);
  const ranked = raw
    .map((value, index) => ({ index, remainder: value - base[index] }))
    .sort((a, b) => b.remainder - a.remainder || a.index - b.index);
  const result = [...base];
  for (let i = 0; i < ranked.length && remaining > 0; i += 1, remaining -= 1) {
    result[ranked[i].index] += 1;
  }
  return result;
}

function scoreCompositionRows(run) {
  const cases = run.case_results || [];
  const totalPoints = scorePoints(run.weighted_score);
  const contributions = allocateCaseContributionPoints(cases, totalPoints);
  return cases.map((c, index) => ({
    ...c,
    contributionPoints: contributions[index] ?? 0,
    scorePoints: scorePoints(c.weighted_score) ?? 0,
    originalIndex: index,
  }));
}

function focusSummary(cases) {
  const ranked = [...(cases || [])].sort((a, b) => {
    if (a.passed !== b.passed) return a.passed ? 1 : -1;
    return Number(a.weighted_score) - Number(b.weighted_score);
  });
  const focus = ranked.slice(0, 2);
  if (!focus.length) return "—";
  return focus.map((c) => `${shortCaseName(c.case_id)} ${CTNA.formatPercent(c.weighted_score)}`).join(" · ");
}





function renderOutcome(run) {
  const cases = run.case_results || [];
  const passed = cases.filter((c) => c.passed).length;
  $("#summary-cases").textContent = `${passed} / ${cases.length}`;
  
  const currentPoints = scorePoints(run.weighted_score);
  const deltaPoints = run.weighted_delta === null || run.weighted_delta === undefined || Number.isNaN(Number(run.weighted_delta))
    ? null
    : Math.round(Number(run.weighted_delta) * 100);
  
  if (currentPoints !== null && deltaPoints !== null) {
    const baselinePoints = currentPoints - deltaPoints;
    $("#summary-baseline").textContent = `${baselinePoints}%`;
  } else {
    $("#summary-baseline").textContent = "–";
  }
  
  $("#report-name").textContent = `${run.agent_id} · v${run.dataset_version}`;
}

/* Run-level interpretation: what the headline score is worth, in prose. */
function renderReliability(run) {
  const el = $("#reliability");
  if (!el) return;
  const stats = run.stats;
  const cases = run.case_results || [];
  const skippedTotal = cases.reduce((n, c) => n + (c.skipped || []).length, 0);
  const assessed = new Set();
  cases.forEach((c) => (c.scores || []).forEach((sc) => assessed.add(sc.metric)));

  const items = [
    { label: "Cases meeting the standard", value: CTNA.formatPassCount(stats) },
    { label: "Typical case score", value: CTNA.formatMeanQuality(stats) },
    { label: "Change versus baseline", value: CTNA.formatDrift(stats) },
  ];

  const agreement = CTNA.formatHumanAgreement(stats);
  if (agreement) {
    items.push({ label: "Agreement with expert review", value: agreement });
  }

  const skippedNames = new Set();
  cases.forEach((c) => (c.skipped || []).forEach((sk) => skippedNames.add(sk.metric)));
  if (skippedNames.size > 0) {
    const configured = assessed.size + skippedNames.size;
    const named = [...skippedNames].map((m) => CTNA.metricInfo(m).title);
    const list = named.length <= 2 ? ` (${named.join(" and ")})` : "";
    items.push({
      label: "Assessment coverage",
      value: `${assessed.size} of ${configured} criteria were assessed. `
        + `${skippedNames.size} criteri${skippedNames.size === 1 ? "on" : "a"}${list} could not be measured `
        + `and ${skippedNames.size === 1 ? "is" : "are"} excluded from the score, `
        + "so this result reflects partial coverage.",
      warn: true,
    });
  }

  el.innerHTML = items.map((i) => `
    <div class="reliability-item${i.warn ? " warn" : ""}">
      <dt>${CTNA.escapeHtml(i.label)}</dt>
      <dd>${CTNA.escapeHtml(i.value)}</dd>
    </div>`).join("");
}

/* One row per criterion, aggregated over every case in the run. */
function criterionRollup(run) {
  const cases = run.case_results || [];
  const rows = new Map();
  const ensure = (metric) => {
    if (!rows.has(metric)) {
      rows.set(metric, {
        metric, scores: [], deltas: [], passed: 0, assessed: 0,
        skipped: 0, reasons: new Set(), weight: null, critical: false,
      });
    }
    return rows.get(metric);
  };

  cases.forEach((c) => {
    (c.scores || []).forEach((sc) => {
      const row = ensure(sc.metric);
      row.assessed += 1;
      if (sc.passed) row.passed += 1;
      if (Number.isFinite(Number(sc.score))) row.scores.push(Number(sc.score));
      if (sc.delta !== null && sc.delta !== undefined) row.deltas.push(Number(sc.delta));
      if (row.weight === null) row.weight = sc.weight;
      row.critical = row.critical || !!sc.critical;
    });
    (c.skipped || []).forEach((sk) => {
      const row = ensure(sk.metric);
      row.skipped += 1;
      if (sk.reason) row.reasons.add(sk.reason);
      if (row.weight === null) row.weight = sk.weight;
      row.critical = row.critical || !!sk.critical;
    });
  });

  const mean = (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
  return [...rows.values()].map((r) => ({
    ...r,
    meanScore: mean(r.scores),
    meanDelta: r.deltas.length ? mean(r.deltas) : null,
    info: CTNA.metricInfo(r.metric),
  })).sort((a, b) => {
    const failed = (r) => r.assessed > 0 && r.passed < r.assessed;
    if (failed(a) !== failed(b)) return failed(a) ? -1 : 1;
    if ((a.skipped > 0) !== (b.skipped > 0)) return a.skipped > 0 ? -1 : 1;
    return (b.weight || 0) - (a.weight || 0);
  });
}

function renderCriterionRollup(run) {
  const rows = criterionRollup(run);
  const midpoint = Math.ceil(rows.length / 2);
  const shouldSplit = rows.length > 4;
  
  const renderRows = (rowList) => rowList.map((r) => {
    const name = `<span class="criterion-name">${CTNA.escapeHtml(r.info.title)}</span>`
      + (r.critical ? ` <span class="criterion-decorator criterion-decorator-critical" title="Mandatory" aria-label="Mandatory"></span>` : "")
      + (r.info.informational ? ` <span class="badge badge-muted">Self-reported</span>` : "");

    if (r.assessed === 0) {
      const raw = [...r.reasons][0] || "";
      return `<tr class="rollup-row skipped">
        <td>${name}</td>
        <td colspan="3" class="rollup-skip" title="${CTNA.escapeHtml(raw)}">Not assessed — ${CTNA.escapeHtml(CTNA.skipReason(raw))}</td>
      </tr>`;
    }

    const met = r.passed === r.assessed;
    const partial = r.skipped > 0
      ? `<span class="rollup-partial">${r.skipped} not assessed</span>`
      : "";
    return `<tr class="rollup-row ${met ? "ok" : "bad"}">
      <td>${name}</td>
      <td><span class="status-label ${met ? "pass" : "fail"}">${r.passed} of ${r.assessed}</span>${partial}</td>
      <td><strong>${CTNA.formatPercent(r.meanScore)}</strong></td>
      <td>${CTNA.escapeHtml(CTNA.importanceLabel(r.weight))}</td>
    </tr>`;
  }).join("") || '<tr><td colspan="4" class="empty">No criteria were recorded for this evaluation.</td></tr>';
  
  const tbody1 = $("#criterion-rollup-1 tbody");
  const tbody2 = $("#criterion-rollup-2 tbody");
  const wrapper2 = $("#criterion-rollup-2-wrapper");
  
  if (!tbody1) return;
  
  if (shouldSplit) {
    const part1 = rows.slice(0, midpoint);
    const part2 = rows.slice(midpoint);
    tbody1.innerHTML = renderRows(part1);
    if (tbody2 && wrapper2) {
      tbody2.innerHTML = renderRows(part2);
      wrapper2.style.display = "block";
    }
  } else {
    tbody1.innerHTML = renderRows(rows);
    if (wrapper2) wrapper2.style.display = "none";
  }

  const note = $("#coverage-note");
  if (note) {
    const missing = rows.filter((r) => r.skipped > 0);
    if (missing.length) {
      note.hidden = false;
      note.textContent = "Criteria shown as not assessed were configured for this evaluation but could not be "
        + "measured in this environment. They are excluded from the overall score.";
    } else {
      note.hidden = true;
    }
  }
}

function renderCaseOverview(run) {
  const tbody = $("#case-overview tbody");
  const cases = run.case_results || [];
  tbody.innerHTML = cases.map((c) => {
    const delta = CTNA.formatDeltaPts(c.weighted_delta) || '<span class="delta-flat">No baseline</span>';
    const caseBaselinePoints = c.weighted_delta === null || c.weighted_delta === undefined || Number.isNaN(Number(c.weighted_delta))
      ? null
      : Math.round(Number(c.weighted_score) * 100) - Math.round(Number(c.weighted_delta) * 100);
    const baselineScore = caseBaselinePoints !== null ? `${caseBaselinePoints}%` : '–';
    return `<tr class="case-overview-row" data-case-id="${CTNA.escapeHtml(c.case_id)}" tabindex="0"
        aria-label="Open details for ${CTNA.escapeHtml(c.case_id)}">
      <td><span class="status-icon ${c.passed ? "pass" : "fail"}" aria-hidden="true">${c.passed ? "✓" : "!"}</span>
          <span class="mono">${CTNA.escapeHtml(c.case_id)}</span></td>
      <td><strong>${CTNA.formatPercent(c.weighted_score)}</strong></td>
      <td><strong>${baselineScore}</strong></td>
      <td>${delta}</td>
      <td><span class="status-label ${c.passed ? "pass" : "fail"}">${c.passed ? "Pass" : "Fail"}</span></td>
    </tr>`;
  }).join("") || '<tr><td colspan="5" class="empty">No cases in this evaluation.</td></tr>';

  tbody.querySelectorAll(".case-overview-row").forEach((row) => {
    const open = () => openCase(row.dataset.caseId);
    row.addEventListener("click", open);
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        open();
      }
    });
  });
}

function openCase(caseId) {
  const details = [...document.querySelectorAll(".case")].find((el) => el.dataset.caseId === caseId);
  if (!details) {
    $("#case-search").value = "";
    $("#case-status-filter").value = "all";
    renderCases(currentRun);
    return window.setTimeout(() => openCase(caseId), 0);
  }
  details.open = true;
  details.scrollIntoView({ behavior: "smooth", block: "start" });
  details.querySelector("summary").focus();
}

function metricCard(sc) {
  const info = CTNA.metricInfo(sc.metric);
  const badges = [];
  if (sc.critical) badges.push(`<span class="badge badge-critical">Mandatory</span>`);
  if (info.judge || CTNA.JUDGE_METRICS.has(sc.metric)) {
    badges.push(`<span class="badge badge-judge">Model assessment</span>`);
  }
  if (sc.unstable) badges.push(`<span class="badge badge-warn">Inconsistent assessment</span>`);

  const raw = CTNA.formatRaw(sc.raw_value, sc.unit);
  const nerdBits = [`<div class="metric-id">${CTNA.escapeHtml(sc.metric)}</div>`];
  if (sc.rationale) {
    nerdBits.push(`<div class="evidence-rationale"><div class="evidence-label">Assessment</div>${CTNA.escapeHtml(sc.rationale)}</div>`);
  }
  if ((sc.evidence || []).length) {
    nerdBits.push(`<div class="details-evidence"><div class="evidence-label">Evidence</div>${sc.evidence.map((e) => `<div class="evidence-line">${CTNA.escapeHtml(e)}</div>`).join("")}</div>`);
  }
  if (raw) {
    nerdBits.push(`<div><div class="evidence-label">Observed value</div>${CTNA.escapeHtml(raw)}</div>`);
  }
  if (sc.baseline !== null && sc.baseline !== undefined) {
    nerdBits.push(`<div><div class="evidence-label">Comparison baseline</div>${CTNA.formatPercent(sc.baseline)}</div>`);
  }

  const evidence = nerdBits.length
    ? `<details class="metric-evidence"><summary><span class="nerd-caret" aria-hidden="true"></span>View supporting evidence</summary><div class="metric-evidence-body">${nerdBits.join("")}</div></details>`
    : "";

  const thresholdPct = CTNA.asPercent(sc.threshold);
  const required = thresholdPct === null ? "Not set" : `${thresholdPct}%`;
  const weighting = CTNA.importanceLabel(sc.weight);
  const delta = CTNA.deltaLabel(sc.delta);
  const deltaClass = CTNA.deltaClass(sc.delta);
  const emphasis = info.informational ? "informational" : CTNA.importance(sc.weight);
  const status = sc.passed ? "MET" : "NOT MET";
  const statusClass = sc.passed ? "pass" : "fail";

  return `<article class="metric-row ${sc.passed ? "ok" : "bad"} emphasis-${emphasis}" role="row">
    <div class="metric-main" role="cell">
      <div class="metric-title-line">
        <span class="metric-status-icon ${statusClass}" aria-hidden="true">${sc.passed ? "✓" : "!"}</span>
        <h3>${CTNA.escapeHtml(info.title)}</h3>
        ${badges.length ? `<div class="metric-badges">${badges.join("")}</div>` : ""}
      </div>
      <p class="metric-blurb">${CTNA.escapeHtml(info.blurb)}</p>
      ${evidence}
    </div>
    <div class="metric-score-cell" role="cell">
      <span class="metric-score-pill ${statusClass}">${CTNA.formatPercent(sc.score)}</span>
    </div>
    <div class="metric-fact" role="cell" data-label="Required">
      <span class="metric-fact-label">Required</span>
      <strong>${CTNA.escapeHtml(required)}</strong>
    </div>
    <div class="metric-fact" role="cell" data-label="Weight">
      <span class="metric-fact-label">Weight</span>
      <strong>${CTNA.escapeHtml(weighting)}</strong>
    </div>
    <div class="metric-fact" role="cell" data-label="Baseline">
      <span class="metric-fact-label">Vs. baseline</span>
      <strong class="${deltaClass}">${CTNA.escapeHtml(delta)}</strong>
    </div>
    <div class="metric-status-cell" role="cell">
      <span class="status-label ${statusClass}">${status}</span>
    </div>
  </article>`;
}
function skippedCard(sk) {
  const info = CTNA.metricInfo(sk.metric);
  const badges = [];
  if (sk.critical) badges.push(`<span class="badge badge-critical">Mandatory</span>`);
  if (sk.judge) badges.push(`<span class="badge badge-judge">Model assessment</span>`);
  const threshold = CTNA.asPercent(sk.threshold);
  const technical = sk.reason ? `<details class="metric-evidence"><summary><span class="nerd-caret" aria-hidden="true"></span>View technical detail</summary><div class="metric-evidence-body"><div class="metric-id">${CTNA.escapeHtml(sk.metric)}</div><div>${CTNA.escapeHtml(sk.reason)}</div></div></details>` : "";
  return `<article class="metric-row skipped-row" role="row">
    <div class="metric-main" role="cell">
      <div class="metric-title-line">
        <span class="metric-status-icon neutral" aria-hidden="true">•</span>
        <h3>${CTNA.escapeHtml(info.title)}</h3>
        ${badges.length ? `<div class="metric-badges">${badges.join("")}</div>` : ""}
      </div>
      <p class="metric-blurb">${CTNA.escapeHtml(info.blurb)}</p>
      <p class="metric-skip-reason">${CTNA.escapeHtml(CTNA.skipReason(sk.reason))}</p>
      ${technical}
    </div>
    <div class="metric-score-cell" role="cell"><span class="metric-score-pill neutral">—</span></div>
    <div class="metric-fact" role="cell" data-label="Required"><span class="metric-fact-label">Required</span><strong>${threshold === null ? "Not set" : threshold + "%"}</strong></div>
    <div class="metric-fact" role="cell" data-label="Weight"><span class="metric-fact-label">Weight</span><strong>${CTNA.escapeHtml(CTNA.importanceLabel(sk.weight))}</strong></div>
    <div class="metric-fact" role="cell" data-label="Baseline"><span class="metric-fact-label">Effect</span><strong class="delta-flat">Excluded</strong></div>
    <div class="metric-status-cell" role="cell"><span class="status-label neutral">NOT ASSESSED</span></div>
  </article>`;
}
function renderCases(run) {
  const el = $("#cases");
  if (!run) return;
  const query = ($("#case-search")?.value || "").trim().toLowerCase();
  const filter = $("#case-status-filter")?.value || "all";
  const sort = $("#case-sort")?.value || "score-asc";
  let cases = [...(run.case_results || [])].filter((c) => {
    if (query && !String(c.case_id).toLowerCase().includes(query)) return false;
    if (filter === "pass" && !c.passed) return false;
    if (filter === "fail" && c.passed) return false;
    if (filter === "regressed" && !(Number(c.weighted_delta) < 0)) return false;
    if (filter === "improved" && !(Number(c.weighted_delta) > 0)) return false;
    if (filter === "changed" && !(Math.abs(Number(c.weighted_delta)) > 0)) return false;
    return true;
  });
  const sorters = {
    "score-asc": (a, b) => a.weighted_score - b.weighted_score,
    "delta-asc": (a, b) => (a.weighted_delta ?? 0) - (b.weighted_delta ?? 0),
    name: (a, b) => String(a.case_id).localeCompare(String(b.case_id)),
    status: (a, b) => Number(a.passed) - Number(b.passed) || a.weighted_score - b.weighted_score,
  };
  cases.sort(sorters[sort] || sorters["score-asc"]);
  $("#case-count").textContent = `Showing ${cases.length} of ${(run.case_results || []).length} cases`;

  el.innerHTML = cases.map((c) => {
    const index = (run.case_results || []).indexOf(c);
    const delta = CTNA.formatDeltaPts(c.weighted_delta);
    const assessed = (c.scores || []).filter((sc) => !CTNA.metricInfo(sc.metric).informational);
    const passedCount = assessed.filter((sc) => sc.passed).length;
    const failedCount = assessed.length - passedCount;
    const skippedCount = (c.skipped || []).length;
    const metricSummary = `${assessed.length} criteria · ${passedCount} met · ${failedCount} not met${skippedCount ? ` · ${skippedCount} not assessed` : ""}`;
    return `
    <details class="case" data-case-id="${CTNA.escapeHtml(c.case_id)}" data-case-index="${index}">
      <summary>
        <span class="status-icon ${c.passed ? "pass" : "fail"}" aria-hidden="true">${c.passed ? "✓" : "!"}</span>
        <div class="case-summary-main">
          <div class="case-summary-title-row">
            <strong>${CTNA.escapeHtml(c.case_id)}</strong>
            ${delta ? `<span class="case-delta">${delta}</span>` : ""}
          </div>
          <div class="case-key-metrics"><span>${CTNA.escapeHtml(metricSummary)}</span></div>
        </div>
        <div class="case-summary-right">
          <strong class="case-summary-score">${CTNA.formatPercent(c.weighted_score)}</strong>
          <span class="status-label ${c.passed ? "pass" : "fail"}">${c.passed ? "Pass" : "Fail"}</span>
        </div>
      </summary>
      <div class="case-body"><p class="muted">Select the case to load diagnostics.</p></div>
    </details>`;
  }).join("") || `<p class="empty">No cases match the selected filters.</p>`;

  document.querySelectorAll(".case").forEach((details) => {
    details.addEventListener("toggle", () => {
      if (details.open) populateCaseBody(details);
    });
  });
}

function populateCaseBody(details) {
  if (details.dataset.loaded === "true") return;
  const index = Number(details.dataset.caseIndex);
  const c = currentRun.case_results[index];
  const groups = CTNA.groupScores(c.scores).map((g) =>
    `<section class="mgroup mgroup-${g.id}">
       <h3 class="group-heading">${g.label}</h3>
       ${g.note ? `<p class="group-note">${CTNA.escapeHtml(g.note)}</p>` : ""}
       <div class="metric-table" role="table" aria-label="Evaluation criteria">
         <div class="metric-table-head" role="row" aria-hidden="true">
           <span>Criterion</span><span>Score</span><span>Required</span><span>Weight</span><span>Vs. baseline</span><span>Status</span>
         </div>
         ${g.items.map(({ sc }) => metricCard(sc)).join("")}
       </div>
     </section>`
  ).join("");
  const skipped = (c.skipped || []).length ? `
    <section class="mgroup mgroup-skipped">
      <h3 class="group-heading">Not assessed</h3>
      <p class="group-note">These criteria were configured for this evaluation but could not be measured. They are excluded from the score.</p>
      <div class="metric-table" role="table" aria-label="Criteria not assessed">
        <div class="metric-table-head" role="row" aria-hidden="true">
          <span>Criterion</span><span>Score</span><span>Required</span><span>Weight</span><span>Effect</span><span>Status</span>
        </div>
        ${(c.skipped || []).map(skippedCard).join("")}
      </div>
    </section>` : "";
  details.querySelector(".case-body").innerHTML = `
    ${previewBlock(c)}
    ${diffBlock(c, index)}
    ${groups}
    ${skipped}`;
  details.dataset.loaded = "true";
  wireDiagnosticControls(details);
}

function wireDiagnosticControls(root = document) {
  root.querySelectorAll(".copy-output").forEach((button) => {
    button.addEventListener("click", () => {
      const c = currentRun.case_results[Number(button.dataset.caseIndex)];
      const value = button.dataset.output === "reference"
        ? toText(c.golden_output)
        : toText(c.observation && c.observation.output);
      copyText(value, button);
    });
  });
  root.querySelectorAll(".diff-search").forEach((input) => {
    input.addEventListener("input", () => {
      const c = currentRun.case_results[Number(input.dataset.caseIndex)];
      const query = input.value.trim().toLowerCase();
      const status = input.closest(".diff-toolbar").querySelector(".diff-search-result");
      if (!query) {
        status.textContent = "";
        return;
      }
      const referenceCount = toText(c.golden_output).toLowerCase().split(query).length - 1;
      const agentCount = toText(c.observation && c.observation.output).toLowerCase().split(query).length - 1;
      status.textContent = `${referenceCount} reference · ${agentCount} agent`;
    });
  });
}

async function load() {
  if (!runId) {
    pill("Run identifier required", "bad");
    $("#case-overview tbody").innerHTML = `<tr><td colspan="4" class="empty">A run identifier is required in the address.</td></tr>`;
    return;
  }
  let run;
  try {
    const res = await fetch(`api/runs/${encodeURIComponent(runId)}`);
    if (!res.ok) {
      pill("Not found", "bad");
      $("#case-overview tbody").innerHTML = `<tr><td colspan="4" class="empty">Evaluation ‘${CTNA.escapeHtml(runId)}’ was not found.</td></tr>`;
      return;
    }
    run = await res.json();
  } catch (e) {
    pill("Service unavailable", "bad");
    return;
  }
  currentRun = run;

  const passed = CTNA.isPassingStatus(run.status);
  const errored = run.status === "ERROR";
  const currentPoints = scorePoints(run.weighted_score);
  const deltaPoints = run.weighted_delta === null || run.weighted_delta === undefined || Number.isNaN(Number(run.weighted_delta))
    ? null
    : Math.round(Number(run.weighted_delta) * 100);
  pill(errored ? "Error" : (passed ? "Pass" : "Fail"), statusClass(run.status));
  $("#stamp").innerHTML = CTNA.stampHtml(run.status);
  $("#quality-ring").innerHTML = CTNA.scoreRingHtml(run.weighted_score, 112);
  $("#hero-title").textContent = errored
    ? "This evaluation did not complete"
    : (passed ? "This evaluation passed" : "This evaluation did not meet the required standard");
  $("#m-agent").textContent = run.agent_id;
  $("#m-dataset").textContent = `${run.dataset_id} · v${run.dataset_version}`;
  $("#m-runid").textContent = run.run_id;
  $("#m-score").textContent = CTNA.formatPercent(run.weighted_score);
  $("#m-delta").textContent = deltaPoints === null
    ? "—"
    : `${deltaPoints > 0 ? "+" : ""}${deltaPoints}%`;
  $("#m-when").textContent = new Date(run.creation_ts).toLocaleString();
  $("#baseline-run").textContent = `${run.agent_id} · ${run.dataset_id} v${run.dataset_version}`;
  $("#baseline-score").textContent = CTNA.formatPercent(run.weighted_score);
  const baselineReferencePoints = currentPoints !== null && deltaPoints !== null
    ? currentPoints - deltaPoints
    : null;
  const baselineDeltaText = deltaPoints === null
    ? "No baseline comparison"
    : `${deltaPoints > 0 ? "+" : ""}${deltaPoints}%`;
  $("#baseline-reference").textContent = baselineReferencePoints === null ? "No baseline comparison" : formatPoints(baselineReferencePoints);
  $("#baseline-delta").textContent = baselineDeltaText;

  const copyBtn = $("#copy-runid");
  if (copyBtn && run.run_id) {
    copyBtn.hidden = false;
    copyBtn.onclick = () => copyText(run.run_id, copyBtn);
  }

  renderOutcome(run);
  renderReliability(run);
  renderCriterionRollup(run);
  renderCaseOverview(run);
  renderCases(run);

  const promote = $("#promote-baselines");
  if (promote) promote.onclick = () => requestBaselinePromotion(run);

  const dialog = $("#baseline-dialog");
  if (dialog) {
    dialog.addEventListener("close", () => {
      if (dialog.returnValue === "confirm") promoteBaselines(run);
    });
  }

  ["#case-search", "#case-status-filter", "#case-sort"].forEach((selector) => {
    $(selector)?.addEventListener("input", () => renderCases(run));
  });

  const rawDetail = $("#raw-detail");
  rawDetail?.addEventListener("toggle", () => {
    if (rawDetail.open && $("#detail").dataset.loaded !== "true") {
      $("#detail").textContent = JSON.stringify(run, null, 2);
      $("#detail").dataset.loaded = "true";
    }
  });
}

load();
