"""Shared limits for uploaded playground configuration bundles."""

_MB = 1024 * 1024
MAX_ZIP_BYTES = 32 * _MB
MAX_UNCOMPRESSED_BYTES = 96 * _MB
MAX_FILES = 1500
