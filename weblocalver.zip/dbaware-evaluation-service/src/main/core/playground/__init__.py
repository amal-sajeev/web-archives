"""Ephemeral agent-config playground support.

Uploaded configuration bundles are extracted into a temporary directory for the
life of one evaluation. Nothing is persisted in the evaluation repository.
The browser owns the editable copy and can send the current file set back for
subsequent tests or export.
"""

from .archive import MAX_FILES, MAX_UNCOMPRESSED_BYTES, MAX_ZIP_BYTES, files_to_zip
from .bundle import extract_to_temp, inspect_bundle
from .preview_repo import PreviewRepository
from .scoped_registry import (
    REGISTRY_SCOPE,
    RegistryScope,
    ScopedRegistry,
    _cleanup_scoped_registry,
    _load_scoped_registry,
    load_scoped_registry,
)

__all__ = [
    "MAX_FILES",
    "MAX_UNCOMPRESSED_BYTES",
    "MAX_ZIP_BYTES",
    "REGISTRY_SCOPE",
    "PreviewRepository",
    "RegistryScope",
    "ScopedRegistry",
    "_cleanup_scoped_registry",
    "_load_scoped_registry",
    "extract_to_temp",
    "files_to_zip",
    "inspect_bundle",
    "load_scoped_registry",
]
