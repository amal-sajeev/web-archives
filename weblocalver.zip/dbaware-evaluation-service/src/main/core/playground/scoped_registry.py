"""Load an uploaded agent into an ephemeral Registry and undo its global registrations."""

from __future__ import annotations

import asyncio
import weakref
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from registry import Registry


class RegistryScope:
    """Reader/writer lock protecting the process-global scorer/adapter registries.

    An ordinary evaluation only *reads* the registries, so any number of runs
    may hold the lock :meth:`shared` at once -- which is the whole point: a
    single mutex here would serialise every evaluation in the process, and a
    second ``/api/evaluate/start`` would sit silently behind the first.

    Loading a playground bundle *mutates* the registries (``custom_tests.py``
    self-registers scorers, which are then restored), so it takes the lock
    :meth:`exclusive`: new readers queue behind it and it waits for in-flight
    runs to drain. Readers queue on the same turnstile the writer holds, so a
    steady stream of runs cannot starve a pending playground load.
    """

    def __init__(self) -> None:
        # Writers hold the turnstile for their whole critical section; readers
        # only pass through it, so they never block each other.
        self._turnstile = asyncio.Lock()
        self._count_lock = asyncio.Lock()
        self._readers = 0
        self._idle = asyncio.Event()
        self._idle.set()

    @property
    def readers(self) -> int:
        """Number of runs currently holding the lock shared (diagnostics/tests)."""
        return self._readers

    @asynccontextmanager
    async def shared(self) -> AsyncIterator[None]:
        """Hold the registries stable for reading; concurrent with other readers."""
        async with self._turnstile:
            async with self._count_lock:
                self._readers += 1
                self._idle.clear()
        try:
            yield
        finally:
            async with self._count_lock:
                self._readers -= 1
                if self._readers == 0:
                    self._idle.set()

    @asynccontextmanager
    async def exclusive(self) -> AsyncIterator[None]:
        """Sole access to the registries, for a load that mutates them."""
        async with self._turnstile:
            # Readers leave via _count_lock only, so waiting here cannot deadlock.
            await self._idle.wait()
            yield


REGISTRY_SCOPE = RegistryScope()


@dataclass
class ScopedRegistry:
    """An ephemeral registry plus what is needed to restore the global registries."""

    registry: Registry
    custom_scorers: list[str] = field(default_factory=list)
    collisions: list[str] = field(default_factory=list)
    scorer_snapshot: dict[str, Any] = field(default_factory=dict)
    adapter_snapshot: dict[str, type] = field(default_factory=dict)

    def cleanup(self) -> None:
        """Restore the process-global scorer and adapter registries to pre-load state."""
        from adapters.registry import restore_adapters
        from scorers.base import restore_scorers

        restore_scorers(self.scorer_snapshot)
        restore_adapters(self.adapter_snapshot)


def load_scoped_registry(temp_dir: Path) -> ScopedRegistry:
    """Load ``temp_dir`` as a registry; report scorers added or replaced by custom_tests.py."""
    from adapters.registry import snapshot_adapters
    from scorers import all_scorers
    from scorers.base import snapshot_scorers

    before = snapshot_scorers()
    adapters_before = snapshot_adapters()
    registry = Registry(temp_dir).load()
    after = all_scorers()
    custom = sorted(set(after) - set(before))
    collisions = sorted(name for name in set(after) & set(before) if after[name] is not before[name])
    return ScopedRegistry(registry, custom, collisions, before, adapters_before)


# --- Backward-compatible tuple API used by handlers/playground.py -------------

# Keyed by the Registry object itself: an id()-keyed dict leaks entries whose
# registry was never cleaned up, and a recycled id() would hand back the wrong
# snapshot after garbage collection.
_ACTIVE: weakref.WeakKeyDictionary[Registry, ScopedRegistry] = weakref.WeakKeyDictionary()


def _load_scoped_registry(temp_dir: Path) -> tuple[Registry, list[str], list[str]]:
    """Deprecated: prefer :func:`load_scoped_registry` + ``ScopedRegistry.cleanup()``."""
    scoped = load_scoped_registry(temp_dir)
    _ACTIVE[scoped.registry] = scoped
    return scoped.registry, scoped.custom_scorers, scoped.collisions


def _cleanup_scoped_registry(registry: Registry | ScopedRegistry) -> None:
    """Deprecated counterpart of :func:`_load_scoped_registry`."""
    scoped = registry if isinstance(registry, ScopedRegistry) else _ACTIVE.pop(registry, None)
    if scoped is not None:
        scoped.cleanup()
