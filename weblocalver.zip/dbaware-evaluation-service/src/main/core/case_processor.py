"""Process one golden case: replay it, fetch metrics, score, gate."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

from core import aggregation, run_events
from core.metric_scoring import ScoringContext, score_metric
from core.models import CaseResult, Dataset, GoldenCase, MetricSpec, Observation, Score, SkippedMetric
from core.structured_logging import get_logger

_log = get_logger("eval_service.runner")

CancelCheck = Callable[[], bool]


class RunCancelled(Exception):
    """Raised inside the case task group when a cancel was requested."""


def metric_specs_for_case(dataset: Dataset, case: GoldenCase) -> list[MetricSpec]:
    """Metrics enabled for a case: those named in its ``baseline_metrics`` map.

    A metric the case does not name is not evaluated for it. That is how a case
    opts out of a metric that does not apply to it; ``Registry.load`` warns
    about a metric that *no* case names, which is an oversight rather than a
    choice.
    """
    enabled = set((case.baseline_metrics or {}).keys())
    return [spec for spec in dataset.metrics if spec.name in enabled]


def build_case_result(
    case: GoldenCase,
    obs: Observation,
    outcomes: list[Score | SkippedMetric],
    dataset: Dataset | None = None,
) -> CaseResult:
    """Assemble a CaseResult and apply the gate using ``dataset``'s own limits."""
    scores = [o for o in outcomes if isinstance(o, Score)]
    skipped = [o for o in outcomes if isinstance(o, SkippedMetric)]
    passed, wscore, wdelta = aggregation.gate(
        scores,
        skipped=skipped,
        dataset_threshold=getattr(dataset, "threshold", None),
        regression_tolerance=getattr(dataset, "regression_tolerance", None),
    )
    return CaseResult(
        case_id=case.id,
        scores=scores,
        skipped=skipped,
        weighted_score=wscore,
        weighted_delta=wdelta,
        passed=passed,
        observation=obs,
        input=case.input,
        golden_output=case.golden_output,
    )


class CaseProcessor:
    """Runs cases (bounded by ``case_sem``) and collects results in index order."""

    def __init__(
        self,
        ctx: ScoringContext,
        target: Any,
        metrics_client: Any,
        *,
        total: int,
        case_sem: asyncio.Semaphore,
        should_cancel: CancelCheck | None = None,
    ) -> None:
        self._ctx = ctx
        self._target = target
        self._metrics = metrics_client
        self._total = total
        self._case_sem = case_sem
        self._should_cancel = should_cancel
        self._results: list[CaseResult | None] = [None] * total

    def completed(self) -> list[CaseResult]:
        """Results of the cases that finished, in dataset order."""
        return [r for r in self._results if r is not None]

    def _check_cancel(self) -> None:
        if self._should_cancel is not None and self._should_cancel():
            raise RunCancelled("cancel requested")

    async def run(self, index: int, case: GoldenCase) -> None:
        async with self._case_sem:
            self._check_cancel()
            await self._process(index, case)

    async def _observe(self, case: GoldenCase) -> tuple[Observation, dict[str, Any]]:
        ctx = self._ctx
        obs = await self._target.run_case(case)
        metrics = await self._metrics.fetch(case.id, obs)
        if obs.error:
            _log.warning("observation_error", extra={
                "trace_id": ctx.trace_id, "case_id": case.id, "error": obs.error})
        await ctx.emit(run_events.observation(case.id, obs))
        return obs, metrics

    async def _process(self, index: int, case: GoldenCase) -> None:
        ctx = self._ctx
        specs = metric_specs_for_case(ctx.dataset, case)
        await ctx.emit(run_events.case_started(case.id, index, self._total, len(specs)))
        _log.info("case_started", extra={
            "trace_id": ctx.trace_id, "agent_id": ctx.agent_id, "case_id": case.id})
        obs, metrics = await self._observe(case)
        outcomes = await asyncio.gather(*(score_metric(ctx, spec, case, obs, metrics) for spec in specs))
        result = build_case_result(case, obs, list(outcomes), ctx.dataset)
        self._results[index] = result
        _log.info("case_done", extra={
            "trace_id": ctx.trace_id, "case_id": case.id,
            "passed": result.passed, "score": round(result.weighted_score, 3)})
        await ctx.emit(run_events.case_done(result, index, self._total))
