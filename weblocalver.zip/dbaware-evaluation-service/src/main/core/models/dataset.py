"""Golden-set / registry models: metrics, targets, cases, datasets, agents."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

MetricType = Literal["deterministic", "llm_judge", "reference", "trajectory", "safety", "operational"]
Direction = Literal["higher_is_better", "lower_is_better"]
BodyType = Literal["json", "form", "text", "raw"]
ContentType = Literal["auto", "text", "json", "markdown", "pdf", "docx"]
OutputKind = Literal["text", "json", "base64", "bytes", "url"]


class MetricSpec(BaseModel):
    name: str
    type: MetricType = Field(
        description="deterministic | llm_judge | reference | trajectory | safety | operational",
    )
    scorer: str = Field(description="registered scorer name")
    weight: float = 1.0
    threshold: float = 0.0
    # Banking-grade controls.
    critical: bool = Field(
        default=False,
        description="If true, a failure (or a skipped/errored measurement) vetoes the case.",
    )
    direction: Direction = Field(
        default="higher_is_better",
        description="higher_is_better or lower_is_better (e.g. latency, cost, error rate).",
    )
    unit: str = Field(default="ratio", description="ratio | ms | tokens | count | usd ...")
    # Normalisation bounds. For lower_is_better metrics `norm_max` is required:
    # value at/above `norm_max` scores 0, at/below `norm_min` scores 1.
    norm_min: float | None = None
    norm_max: float | None = None
    # Optional config passed through to the scorer (rubric text, schema, budgets).
    config: dict[str, Any] = Field(default_factory=dict)


class AuthSpec(BaseModel):
    """Auth helper for the HTTP adapter. Secrets come from env vars only.

    ``type`` is one of ``bearer``, ``basic``, ``api_key_header`` or
    ``api_key_query``; unknown types are ignored with a warning.
    """

    model_config = ConfigDict(extra="allow")

    type: str = ""
    token_env: str = ""
    header: str = "X-API-Key"
    param: str = "api_key"
    username_env: str = ""
    password_env: str = ""


class ResponseMapping(BaseModel):
    """Maps an HTTP response into the standard Observation envelope.

    Each ``*_path`` is a dotted path into the parsed JSON body (e.g.
    ``"data.output"``). ``None`` means "not mapped"; the Observation keeps its
    default for that field. ``content_type`` and ``output_kind`` tell the
    document-extraction layer how to interpret ``output_path``.
    """

    output_path: str | None = None
    tool_calls_path: str | None = None
    usage_path: str | None = None
    model_path: str | None = None
    latency_path: str | None = None
    error_path: str | None = None
    metadata_path: str | None = None
    # Dotted path to retrieved context for groundedness. If omitted, the HTTP
    # adapter also picks up a top-level ``source_context`` response field.
    source_context_path: str | None = None
    content_type: ContentType = "auto"
    output_kind: OutputKind = "text"


class TargetSpec(BaseModel):
    """How to reach the agent under test.

    Two families:
    - Python adapters selected by ``adapter`` (``agent_eval_hook``,
      ``scoping_analytics``, or one registered with ``@register_adapter``).
    - The config-driven ``http`` adapter: the fields below describe the HTTP
      request and response mapping entirely from config.
    """

    adapter: str = "agent_eval_hook"
    endpoint: str = "/api/eval/data-extraction-agent"

    # --- Config-driven HTTP adapter (adapter == "http") ---
    method: str = "POST"
    # Static or env-templated headers, e.g. {"Authorization": "Bearer ${env.TOKEN}"}.
    headers: dict[str, str] = Field(default_factory=dict)
    auth: AuthSpec | None = None
    # Query-param templates resolved from case.input dotted paths, e.g. {"q": "${input.query}"}.
    params: dict[str, str] = Field(default_factory=dict)
    # Body template (${...} substitution from case.input/env); absent =>
    # send case.input verbatim as JSON (backward-compatible default).
    body: Any = None
    body_type: BodyType = "json"
    response: ResponseMapping = Field(default_factory=ResponseMapping)

    # Per-adapter overrides (also honoured by the Python adapters when set).
    timeout: float | None = None
    # trust_env=False keeps localhost calls off the corporate proxy (default).
    trust_env: bool = False
    # Extra attempts after a *transient* failure (connection/read error, or a
    # 429/5xx from the agent); a 4xx is the agent's answer and is never retried.
    # Honoured by the http adapter; capped at 5.
    retries: int = Field(default=0, ge=0)


class GoldenCase(BaseModel):
    id: str
    input: dict[str, Any]
    golden_output: str | None = None
    # Optional document golden reference: a path relative to the agent folder,
    # or a base64 data URL ("data:<ctype>;base64,...").
    golden_file: str | None = None
    # Optional hint for how the agent output should be interpreted.
    content_type: ContentType = "auto"
    expected: dict[str, Any] = Field(default_factory=dict)
    # Doubles as this case's metric selector: ONLY metrics named here are
    # evaluated for the case (see core.case_processor.metric_specs_for_case), so
    # a metric left out is silently not measured. Use that deliberately -- e.g.
    # a refusal case omits reference-comparison metrics -- but a metric no case
    # names never runs at all, which the registry reports as a load warning.
    baseline_metrics: dict[str, float] = Field(default_factory=dict)


class Dataset(BaseModel):
    dataset_id: str
    version: str
    description: str = ""
    target: TargetSpec = Field(default_factory=TargetSpec)
    metrics: list[MetricSpec] = Field(default_factory=list)
    cases: list[GoldenCase] = Field(default_factory=list)
    # Gate limits for this dataset; ``None`` falls back to Config.DATASET_THRESHOLD
    # / Config.REGRESSION_TOLERANCE.
    threshold: float | None = Field(default=None, ge=0.0, le=1.0)
    regression_tolerance: float | None = Field(default=None, ge=0.0, le=1.0)


class AgentConfig(BaseModel):
    agent_id: str
    name: str
    # Documentation fields surfaced in the agent list; several agent.yaml files
    # already set them, so they are declared rather than silently dropped.
    version: str = ""
    description: str = ""
    base_url: str | None = None
    dataset_file: str = "dataset.json"
    metrics_stub_file: str = "metrics_stub.json"
    # Per-agent override for the metrics source (capture | http | stub). Takes
    # precedence over the global METRICS_SOURCE setting.
    metrics_source: str | None = None
    # If false, the agent is loaded but hidden from list endpoints.
    enabled: bool = True
