"""Evaluation Runner: orchestrates one evaluation run.

For each golden case: replay input against the target, fetch metrics, run each
metric's scorer, apply the per-metric threshold, then aggregate the weighted
score, weighted delta, and gate. Persists a RunRecord.

Case-level concurrency is controlled by ``EVAL_CASE_CONCURRENCY`` (default 1 =
serial). Cases run in an ``asyncio.TaskGroup``: one failing or cancelled case
stops its siblings. The judge semaphore (``EVAL_JUDGE_CONCURRENCY``) is shared
by all cases and applies to judge scorers only.

Failure handling: any error — including cancellation — persists an ERROR run
with the cases completed so far, then re-raises the original exception
(cancellation re-raises ``asyncio.CancelledError``).
"""

from __future__ import annotations

import asyncio
import uuid
from typing import TYPE_CHECKING

from adapters import build_metrics_client, build_target_adapter
from core import run_events
from core.case_processor import CancelCheck, CaseProcessor, RunCancelled
from core.config import Config
from core.metric_scoring import ScoringContext
from core.models import CreatedBy, Dataset, GoldenCase, RunRecord
from core.run_builder import CANCELLED_DETAIL, build_run, clean_error_detail, compose_status, describe_error
from core.run_events import Emitter, ProgressFn
from core.structured_logging import get_logger

if TYPE_CHECKING:
    from registry import RegisteredAgent, Registry
    from repository import EvaluationRepository

_log = get_logger("eval_service.runner")

__all__ = ["ProgressFn", "Runner"]


def _select_cases(dataset: Dataset, case_ids: list[str] | None) -> list[GoldenCase]:
    cases = list(dataset.cases)
    if case_ids is None:
        return cases
    wanted = {str(x) for x in case_ids}
    unknown = sorted(wanted - {c.id for c in cases})
    if unknown:
        raise ValueError(f"Unknown case id(s): {', '.join(unknown)}")
    selected = [c for c in cases if c.id in wanted]
    if not selected:
        raise ValueError("At least one case must be selected.")
    return selected


def _check_version(agent_id: str, dataset: Dataset, dataset_version: str | None) -> None:
    if dataset_version and dataset_version != dataset.version:
        raise ValueError(
            f"Dataset version '{dataset_version}' not loaded for '{agent_id}' "
            f"(current: '{dataset.version}')."
        )


def _first_leaf(group: BaseExceptionGroup) -> BaseException:
    exc: BaseException = group
    while isinstance(exc, BaseExceptionGroup):
        exc = exc.exceptions[0]
    return exc


class Runner:
    # Kept as static methods for callers/tests that use the historical names.
    _compose_status = staticmethod(compose_status)
    _clean_error_detail = staticmethod(clean_error_detail)

    def __init__(self, registry: Registry, repo: EvaluationRepository):
        self._registry = registry
        self._repo = repo

    async def evaluate(
        self,
        agent_id: str,
        dataset_version: str | None = None,
        judge_repetitions: int = 1,
        created_by: CreatedBy = "DEVELOPER",
        case_ids: list[str] | None = None,
        progress: ProgressFn | None = None,
        should_cancel: CancelCheck | None = None,
    ) -> RunRecord:
        """Run the evaluation. ``should_cancel`` is polled before each case starts."""
        agent = self._registry.get(agent_id)
        dataset = agent.dataset
        cases = _select_cases(dataset, case_ids)
        _check_version(agent_id, dataset, dataset_version)
        ctx = ScoringContext(
            agent_id=agent_id,
            dataset=dataset,
            repo=self._repo,
            emit=Emitter(progress),
            judge_sem=asyncio.Semaphore(Config.JUDGE_CONCURRENCY),
            judge_repetitions=judge_repetitions,
            trace_id=uuid.uuid4().hex,
        )
        processor: CaseProcessor | None = None
        try:
            processor = self._make_processor(ctx, agent, len(cases), should_cancel)
            await self._run_cases(ctx, processor, cases)
        except asyncio.CancelledError:
            await self._persist_failure(ctx, processor, created_by, CANCELLED_DETAIL)
            raise
        except BaseExceptionGroup as group:
            leaf = _first_leaf(group)
            cancelled = isinstance(leaf, RunCancelled)
            detail = CANCELLED_DETAIL if cancelled else describe_error(leaf)
            await self._persist_failure(ctx, processor, created_by, detail)
            if cancelled:
                raise asyncio.CancelledError(CANCELLED_DETAIL) from None
            raise leaf from None
        except Exception as exc:
            await self._persist_failure(ctx, processor, created_by, describe_error(exc))
            raise
        return await self._finish(ctx, processor, created_by)

    def _make_processor(
        self, ctx: ScoringContext, agent: RegisteredAgent, total: int, should_cancel: CancelCheck | None
    ) -> CaseProcessor:
        target = build_target_adapter(
            ctx.dataset, Config.resolve_agent_base_url(ctx.agent_id, agent.config.base_url)
        )
        metrics_client = build_metrics_client(
            agent.metrics_stub_path,
            source_override=agent.config.metrics_source,
            agent_id=ctx.agent_id,
        )
        return CaseProcessor(
            ctx, target, metrics_client,
            total=total,
            case_sem=asyncio.Semaphore(Config.CASE_CONCURRENCY),
            should_cancel=should_cancel,
        )

    @staticmethod
    async def _run_cases(ctx: ScoringContext, processor: CaseProcessor, cases: list[GoldenCase]) -> None:
        _log.info("run_started", extra={"trace_id": ctx.trace_id, "agent_id": ctx.agent_id,
                                        "dataset_id": ctx.dataset.dataset_id, "cases": len(cases)})
        await ctx.emit(run_events.run_started(
            ctx.agent_id, ctx.dataset, len(cases), ctx.judge_repetitions, cases))
        async with asyncio.TaskGroup() as tg:
            for index, case in enumerate(cases):
                tg.create_task(processor.run(index, case))

    async def _finish(self, ctx: ScoringContext, processor: CaseProcessor, created_by: CreatedBy) -> RunRecord:
        run = build_run(ctx.agent_id, ctx.dataset, processor.completed(), created_by)
        await asyncio.to_thread(self._repo.save_run, run)
        _log.info("run_done", extra={"trace_id": ctx.trace_id, "run_id": run.run_id,
                                     "status": run.status, "score": round(run.weighted_score, 3)})
        await ctx.emit(run_events.run_done(run))
        return run

    async def _persist_failure(
        self, ctx: ScoringContext, processor: CaseProcessor | None, created_by: CreatedBy, detail: str
    ) -> None:
        """Save + announce an ERROR run. Never raises, so the original error survives."""
        results = processor.completed() if processor is not None else []
        run = build_run(ctx.agent_id, ctx.dataset, results, created_by, error_detail=detail)
        try:
            await asyncio.shield(asyncio.to_thread(self._repo.save_run, run))
        except Exception:
            _log.exception("run_save_failed", extra={"trace_id": ctx.trace_id, "run_id": run.run_id})
        _log.error("run_failed", extra={"trace_id": ctx.trace_id, "run_id": run.run_id,
                                        "status": run.status, "error": run.error_detail})
        try:
            await ctx.emit(run_events.run_done(run))
        except Exception:
            _log.exception("run_done_emit_failed", extra={"trace_id": ctx.trace_id, "run_id": run.run_id})
