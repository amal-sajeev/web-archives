"""Central configuration for the CTNA Evaluation Service.

**YAML-based configuration (no .env dependency)**:

  1. Set ENV_NAME env var to "dev", "uat", "prod", etc.
  2. Config loads config/{ENV_NAME}/environment.yaml at startup.

**Precedence** (in order):
    1. Direct env vars (for CI/testing/deployment overrides). An env var that
       is set but empty counts as unset.
    2. YAML config: config/{ENV_NAME}/environment.yaml
    3. Hardcoded defaults

Mirrors the Vertex/env conventions in docs/VERTEX_INTEGRATION.md: the code path
that reaches Vertex uses PROJECT_NAME / PROJECT_LOCATION.
"""

from __future__ import annotations

import logging
import os
import re
from collections.abc import Callable
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlsplit
from typing import Any, TypeVar

import yaml

_log = logging.getLogger("eval_service.config")

_no_proxy = "localhost,127.0.0.1,::1"
os.environ.setdefault("no_proxy", _no_proxy)
os.environ.setdefault("NO_PROXY", _no_proxy)

_PKG = Path(__file__).resolve().parent
_MAIN = _PKG.parent
_SRC = _MAIN.parent
_ROOT = _SRC.parent
_CONFIG_DIR = _MAIN / "config"

_TRUE_VALUES = frozenset({"1", "true", "yes", "on"})
# Hosts that mean "this pod", i.e. never a real agent service in a cluster.
_LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1", "::1", "0.0.0.0"})
_ENV_TEMPLATE_RE = re.compile(r"^\$\{env\.([A-Za-z0-9_]+)\}$")

T = TypeVar("T")

# Env-var aliases per (section, key), checked after "<SECTION>_<KEY>".
_ALIASES: dict[tuple[str, str], tuple[str, ...]] = {
    ("judge", "project_name"): ("PROJECT_NAME",),
    ("judge", "project_location"): ("PROJECT_LOCATION",),
    ("judge", "model"): ("JUDGE_MODEL", "EVAL_JUDGE_MODEL"),
    ("judge", "temperature"): ("JUDGE_TEMPERATURE", "EVAL_JUDGE_TEMPERATURE"),
    ("judge", "max_retries"): ("JUDGE_MAX_RETRIES", "EVAL_JUDGE_MAX_RETRIES"),
    ("service", "port"): ("EVAL_SERVICE_PORT",),
    ("database", "url"): ("EVAL_DB_URL", "DB_URL"),
    ("database", "instance_connection_name"): ("DB_INSTANCE_CONNECTION_NAME",),
    ("database", "name"): ("DB_NAME",),
    ("database", "schema"): ("DB_SCHEMA",),
    ("database", "ip_type"): ("DB_IP_TYPE",),
    ("database", "host"): ("DB_HOST",),
    ("database", "port"): ("DB_PORT",),
    ("database", "user"): ("DB_USER",),
    ("database", "password_secret"): ("DB_PASSWORD_SECRET",),
    ("database", "owner_user"): ("DB_OWNER_USER",),
    ("database", "owner_password_secret"): ("DB_OWNER_PASSWORD_SECRET",),
    ("database", "allow_sqlite_fallback"): ("EVAL_ALLOW_SQLITE_FALLBACK", "ALLOW_SQLITE_FALLBACK"),
    ("agent_service", "base_url"): ("AGENT_SERVICE_BASE_URL",),
    ("metrics", "source"): ("METRICS_SOURCE",),
    ("metrics", "api_base"): ("METRICS_API_BASE",),
    ("security", "exclude_tls"): ("EVAL_EXCLUDE_TLS", "SECURITY_EXCLUDE_TLS"),
}


def parse_bool(value: object, default: bool = False) -> bool:
    """The one boolean parser: accepts bools, None and truthy strings."""
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, str):
        text = value.strip().lower()
        return default if not text else text in _TRUE_VALUES
    return bool(value)


def env_value(name: str) -> str | None:
    """Return a stripped env var, treating an empty value as unset."""
    raw = os.getenv(name)
    if raw is None:
        return None
    stripped = raw.strip()
    return stripped or None


def cast_value(name: str, value: Any, caster: Callable[[Any], T]) -> T:
    """Cast a config value, failing with a message that names the setting."""
    try:
        return caster(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid value for config setting {name}: {value!r} ({exc})") from exc


def _resolve_service_version() -> str:
    env_version = env_value("EVAL_SERVICE_VERSION")
    if env_version:
        return env_version
    version_file = _ROOT / "VERSION"
    if version_file.exists():
        value = version_file.read_text(encoding="utf-8").strip()
        if value:
            return value
    return "0.0.0-local"


@lru_cache(maxsize=8)
def _load_yaml_for(env_name: str) -> dict[str, Any]:
    env_file = _CONFIG_DIR / env_name / "environment.yaml"
    if not env_file.exists():
        _log.warning(
            "ENV_NAME=%s but config/%s/environment.yaml not found; using env vars / defaults only",
            env_name, env_name,
        )
        return {}
    try:
        config = yaml.safe_load(env_file.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        # Fail fast at startup, but say which file is broken.
        raise ValueError(f"config/{env_name}/environment.yaml is not valid YAML: {exc}") from exc
    _log.info("Loaded config from config/%s/environment.yaml", env_name)
    return config if isinstance(config, dict) else {}


def _load_yaml_config() -> dict[str, Any]:
    """Load environment-specific config from YAML based on ENV_NAME (cached)."""
    env_name = env_value("ENV_NAME")
    return _load_yaml_for(env_name) if env_name else {}


def _get_config_value(section: str, key: str, default: Any = None) -> Any:
    """Get a config value with precedence: env var override -> YAML -> default."""
    candidates = (f"{section.upper()}_{key.upper()}", *_ALIASES.get((section, key), ()))
    for name in candidates:
        value = env_value(name)
        if value is not None:
            return value
    section_cfg = _load_yaml_config().get(section)
    if isinstance(section_cfg, dict):
        yaml_value = section_cfg.get(key)
        if yaml_value not in (None, ""):
            return yaml_value
    return default


def _get_str(section: str, key: str, default: str | None = None) -> str | None:
    value = _get_config_value(section, key, default)
    return None if value is None else str(value)


def _get_typed(section: str, key: str, default: Any, caster: Callable[[Any], T]) -> T:
    return cast_value(f"{section}.{key}", _get_config_value(section, key, default), caster)


def _env_typed(name: str, default: Any, caster: Callable[[Any], T]) -> T:
    value = env_value(name)
    return cast_value(name, default if value is None else value, caster)


def _env_str(name: str, default: str) -> str:
    return env_value(name) or default


def _env_set(name: str) -> frozenset[str]:
    """Comma-separated env value as a set of trimmed, non-empty items (empty when unset)."""
    return frozenset(item.strip() for item in (env_value(name) or "").split(",") if item.strip())


def _expand_env_template(value: str | None) -> str | None:
    """Resolve a whole-string ``${env.NAME}`` placeholder (e.g. agent.yaml base_url)."""
    if not value:
        return None
    match = _ENV_TEMPLATE_RE.match(value.strip())
    if match:
        return env_value(match.group(1))
    return value.strip()


class Config:
    SERVICE_VERSION = _resolve_service_version()

    # Judge / Vertex configuration
    PROJECT_NAME = _get_str("judge", "project_name")
    PROJECT_LOCATION = _get_str("judge", "project_location", "us-central1")
    JUDGE_MODEL = _get_str("judge", "model", "gemini-2.5-pro")
    JUDGE_TEMPERATURE = _get_typed("judge", "temperature", "0", float)
    # Attempts for a transient judge failure (connection drop, timeout, 429/5xx).
    # Configured as judge.max_retries / JUDGE_MAX_RETRIES; the retry loop itself
    # lives in scorers.judge_invoke (the Vertex client is built with max_retries=0).
    JUDGE_MAX_RETRIES = _get_typed("judge", "max_retries", "4", int)

    # Service port
    PORT = _get_typed("service", "port", "4002", int)

    # Database configuration
    DB_URL = _get_str("database", "url", f"sqlite:///{(_ROOT / 'eval_service.db').as_posix()}")
    DB_INSTANCE_CONNECTION_NAME = _get_str("database", "instance_connection_name", "")
    DB_NAME = _get_str("database", "name", "evaldb")
    DB_SCHEMA = _get_str("database", "schema", "public")
    DB_IP_TYPE = _get_str("database", "ip_type", "PUBLIC")
    DB_HOST = _get_str("database", "host", "")
    DB_PORT = _get_typed("database", "port", "5432", int)
    DB_USER = _get_str("database", "user", "monitoring_user")
    DB_PASSWORD = env_value("DB_PASSWORD")  # secrets come from env, never YAML
    DB_PASSWORD_SECRET = _get_str("database", "password_secret")
    DB_OWNER_USER = _get_str("database", "owner_user", "monitoring_owner")
    DB_OWNER_PASSWORD = env_value("DB_OWNER_PASSWORD")
    DB_OWNER_PASSWORD_SECRET = _get_str("database", "owner_password_secret")
    ALLOW_SQLITE_FALLBACK = parse_bool(_get_config_value("database", "allow_sqlite_fallback", "1"))

    @staticmethod
    def resolve_secret(direct: str | None, secret_name: str | None) -> str | None:
        if direct:
            return direct
        if not secret_name:
            return None
        from google.cloud import secretmanager

        client = secretmanager.SecretManagerServiceClient()
        return client.access_secret_version(name=secret_name).payload.data.decode("utf-8")

    # Agent integration
    AGENT_SERVICE_BASE_URL = _get_str("agent_service", "base_url")

    # CT1 ConfigMap env vars that override the per-agent base_url.
    _AGENT_BASE_URL_ENV_MAP: dict[str, str] = {
        "discovery_walkthrough_agent": "SCOPING_PROCEDURE_AGENT_URL",
        "scope_extraction": "SCOPE_EXTRACTION_AGENT_URL",
        "scope_test_step_agent": "SCOPING_PROCEDURE_AGENT_URL",
        "scope_recommendation_agent": "SCOPING_PROCEDURE_AGENT_URL",
        "scoping_summary": "SCOPING_SUMMARY_AGENT_URL",
        "preliminary_research_agent": "SCOPING_SUMMARY_AGENT_URL",
        "notification_noir_agent": "NOTIFICATION_NOIR_AGENT_URL",
        "notification_nor_agent": "NOTIFICATION_NOR_AGENT_URL",
        "walkthrough_query_agent": "WALKTHROUGH_QUERY_AGENT_URL",
    }

    @classmethod
    def agent_base_url_env(cls, agent_id: str) -> str | None:
        """The ConfigMap env var that sets this agent's base URL, if it has one."""
        normalized_id = (agent_id or "").strip().lower().replace("-", "_")
        candidates = [agent_id, normalized_id]
        if normalized_id.endswith("_agent"):
            candidates.append(normalized_id.removesuffix("_agent"))
        for candidate in candidates:
            env_name = cls._AGENT_BASE_URL_ENV_MAP.get(candidate)
            if env_name:
                return env_name
        return None

    @classmethod
    def resolve_agent_base_url(cls, agent_id: str, fallback: str | None = None) -> str | None:
        """Resolve the target base URL for a given agent.

        Precedence:
          1. agent-specific env var from the ConfigMap (per environment)
          2. Per-agent base_url from agent.yaml (``${env.NAME}`` is expanded)
          3. Shared AGENT_SERVICE_BASE_URL
        Returns None when nothing is configured.
        """
        env_name = cls.agent_base_url_env(agent_id)
        if env_name:
            env_url = env_value(env_name)
            if env_url:
                return env_url
        return _expand_env_template(fallback) or cls.AGENT_SERVICE_BASE_URL

    @staticmethod
    def in_cluster() -> bool:
        """True when running inside Kubernetes (the kubelet always sets this)."""
        return env_value("KUBERNETES_SERVICE_HOST") is not None

    @classmethod
    def loopback_target(cls, url: str | None) -> bool:
        """True when ``url`` points back at this pod rather than at an agent service."""
        if not url:
            return True
        host = urlsplit(url if "//" in url else f"//{url}").hostname or ""
        return host.lower() in _LOOPBACK_HOSTS

    # Metrics configuration
    METRICS_API_BASE = _get_str("metrics", "api_base") or None
    # Left empty when unset so adapters.metrics_api.resolve_source() can apply
    # the documented default: "http" when METRICS_API_BASE is configured, else
    # "stub". A non-empty default here would make that branch unreachable.
    METRICS_SOURCE = (_get_str("metrics", "source", "") or "").lower()

    # Security
    EXCLUDE_TLS = parse_bool(_get_config_value("security", "exclude_tls", "0"))
    PLAYGROUND_HTTP_ALLOWED_HOSTS = frozenset(
        item.lower() for item in _env_set("EVAL_PLAYGROUND_HTTP_ALLOWED_HOSTS")
    )

    @classmethod
    def set_exclude_tls(cls, enabled: bool) -> bool:
        cls.EXCLUDE_TLS = parse_bool(enabled, default=False)
        os.environ["SECURITY_EXCLUDE_TLS"] = "1" if cls.EXCLUDE_TLS else "0"
        return cls.EXCLUDE_TLS

    # Paths
    AGENTS_DIR = _SRC / "agents"
    STATIC_DIR = _MAIN / "static"

    # Tuning parameters (rarely overridden; env vars only)
    REGRESSION_TOLERANCE = _env_typed("EVAL_REGRESSION_TOLERANCE", "0.05", float)
    DATASET_THRESHOLD = _env_typed("EVAL_DATASET_THRESHOLD", "0.8", float)
    JUDGE_SAMPLES = _env_typed("EVAL_JUDGE_SAMPLES", "1", int)
    EMBEDDING_MODEL = _env_str("EVAL_EMBEDDING_MODEL", "text-embedding-004")
    JUDGE_CONCURRENCY = max(1, _env_typed("EVAL_JUDGE_CONCURRENCY", "6", int))
    CASE_CONCURRENCY = max(1, _env_typed("EVAL_CASE_CONCURRENCY", "1", int))
    # Alias kept for the EVAL_-prefixed override; defaults to judge.max_retries
    # so the documented YAML key actually takes effect.
    JUDGE_TRANSIENT_RETRIES = max(1, _env_typed("EVAL_JUDGE_TRANSIENT_RETRIES", JUDGE_MAX_RETRIES, int))
    JUDGE_CALL_TIMEOUT = _env_typed("EVAL_JUDGE_CALL_TIMEOUT", "45", float)
    JUDGE_MAX_VARIANCE = _env_typed("EVAL_JUDGE_MAX_VARIANCE", "0.05", float)
    JUDGE_SWAP_ORDER = parse_bool(env_value("EVAL_JUDGE_SWAP_ORDER"), default=True)
    RUN_RETENTION_DAYS = _env_typed("EVAL_RUN_RETENTION_DAYS", "0", int)
    # Agent ids to treat as enabled regardless of agent.yaml ("*" = all), e.g. the local
    # sample agents when started by scripts/start_local_all.ps1. Empty by default.
    ENABLE_AGENTS = _env_set("EVAL_ENABLE_AGENTS")
    WEBHOOK_TIMEOUT = _env_typed("EVAL_WEBHOOK_TIMEOUT", "30", float)
