# Configuration System

The evaluation service uses **YAML-based environment-specific configuration** with no .env dependency.

## Overview

Configuration is driven by the `ENV_NAME` environment variable:

```
ENV_NAME=dev    → loads config/dev/environment.yaml
ENV_NAME=uat    → loads config/uat/environment.yaml
ENV_NAME=prod   → loads config/prod/environment.yaml
```

With `ENV_NAME` unset, no YAML is read at all and every setting comes from env
vars or its hardcoded default.

## Architecture

```
config/
├── dev/
│   └── environment.yaml        # Development values
├── uat/
│   └── environment.yaml        # UAT values
└── prod/
    └── environment.yaml        # Production values
```

There is no template file: `core/config.py` is the single list of settings, each
with its own default. An environment YAML only needs the keys it overrides.

## Configuration Precedence

Highest wins:

1. **Env vars** — `<SECTION>_<KEY>` (e.g. `JUDGE_MODEL`, `DATABASE_URL`) plus the
   aliases in `core/config.py` (`PROJECT_NAME`, `EVAL_DB_URL`, …). An env var
   that is set but empty counts as unset.
2. **YAML** — `config/{ENV_NAME}/environment.yaml`.
3. **Defaults** — hardcoded in `core/config.py`.

## How It Works

### Startup

1. Kubernetes (or local dev) sets `ENV_NAME=uat` (via ConfigMap or manually).
2. Service starts; `core/config.py` initialises:
   - `_load_yaml_config()` reads `config/uat/environment.yaml` once (cached).
   - Each `Config` attribute resolves through `_get_config_value(section, key,
     default)`, which checks env vars, then that YAML section, then the default.
3. Service runs with fully resolved configuration.

`Config` reads its values at **class definition time**, i.e. at import. Changing
an env var after the first import of `core.config` has no effect (the one
exception is `Config.set_exclude_tls()`, used by the runtime TLS toggle).

### Deployment

**Kubernetes**: ConfigMap/Secret injection sets `ENV_NAME`:

```yaml
env:
  - name: ENV_NAME
    value: uat
  - name: PROJECT_NAME    # Direct env var override (optional)
    valueFrom:
      secretKeyRef:
        name: vertex-config
        key: project-id
```

**Local Development**: Two options:

```bash
# Option 1: Use YAML config
export ENV_NAME=dev
python -m src.main.main

# Option 2: Manual env vars (no YAML needed)
export PROJECT_NAME="my-project"
export PROJECT_LOCATION="us-central1"
python -m src.main.main
```

## Configuration Keys

See [config/dev/environment.yaml](dev/environment.yaml) for a complete example.
Every key below is optional; the default is in brackets.

### Judge / Vertex

```yaml
judge:
  project_name: "my-project"         # Vertex project ID [unset → judge metrics skip]
  project_location: "us-central1"    # Vertex region [us-central1]
  model: "gemini-2.5-pro"            # LLM model for evaluation [gemini-2.5-pro]
  temperature: "0"                   # Judge strictness (0=deterministic) [0]
  max_retries: "4"                   # Attempts on a transient judge failure [4]
```

`max_retries` is the retry budget in `scorers/judge_invoke.py` (connection
drops, timeouts, 429/5xx), with exponential backoff. The Vertex client itself is
built with `max_retries=0` so retries happen in exactly one place.
`EVAL_JUDGE_TRANSIENT_RETRIES` overrides it.

### Service

```yaml
service:
  version: "1.0.0"                   # [contents of the VERSION file, else 0.0.0-local]
  port: "4002"                       # [4002]
```

### Database

```yaml
database:
  url: "postgresql://..."            # SQLAlchemy connection string
  instance_connection_name: "..."    # Cloud SQL instance (for Cloud SQL Proxy)
  name: "evaldb"                     # Database name
  schema: "public"                   # Schema name
  user: "monitoring_user"            # Username
  password_secret: "..."             # Google Secret Manager path (or empty)
  allow_sqlite_fallback: "true"      # Fall back to SQLite if Postgres fails
```

**Secrets**: Store sensitive values in Google Secret Manager and reference by path:

```yaml
database:
  password_secret: "projects/my-project/secrets/db-password/versions/latest"
```

The code calls `Config.resolve_secret()` to fetch from Secret Manager at runtime.

### Agent Service Integration

```yaml
agent_service:
  base_url: "http://localhost:4000"  # Shared fallback when an agent.yaml sets no base_url
```

### Metrics Source

```yaml
metrics:
  source: "stub"              # "stub" | "http" | "capture"
  api_base: ""                # For "http" mode: external metrics API
```

Leaving `source` empty (or unset) selects `http` when `api_base` is configured
and `stub` otherwise. An agent.yaml `metrics_source` overrides this per agent.

### Security

```yaml
security:
  exclude_tls: "false"        # "true" disables TLS certificate validation
```

## Adding a New Environment

1. Create `config/{env_name}/environment.yaml` (copy from `dev/` or `uat/`)
2. Update values for your environment
3. Set `ENV_NAME={env_name}` at deployment time
4. No code changes needed

## Troubleshooting

### Config not loading

Check logs for:
```
Loaded config from config/uat/environment.yaml
```

If missing, `ENV_NAME` is not set or the file doesn't exist (which is logged as a
warning naming the path it looked for).

### Using defaults instead of YAML

Fallback to defaults means either:
- `ENV_NAME` is empty
- `config/{ENV_NAME}/environment.yaml` doesn't exist
- Key not found in YAML → falls back to hardcoded default
- The key is present but empty (`""`), which is treated as unset

### Override for testing

To override a YAML value for a single run:

```bash
export ENV_NAME=dev
export JUDGE_MODEL="gemini-2.0-flash"  # Override from YAML
python -m src.main.main
```

Env var `JUDGE_MODEL` takes precedence over YAML `judge.model`.

## No .env Dependency

- ❌ No `.env` file needed
- ❌ No `python-dotenv` package (removed from requirements.txt)
- ✅ Clean separation: YAML for config, env vars for secrets/overrides
- ✅ Same pattern across all environments (dev/uat/prod)
