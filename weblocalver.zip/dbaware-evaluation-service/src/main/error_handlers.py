"""Exception handlers: one JSON error envelope for every failure.

Every error body keeps FastAPI's ``detail`` (a string, or the validation error
list for 422) and adds ``error_type`` (a stable category such as ``not_found``)
and ``request_id`` (the ``X-Request-ID`` value, also sent as a header), so a
client can report an id that matches the server log line.

Unhandled exceptions keep their existing contract: ``error_type`` is the
exception class name and ``detail`` carries only an ``error_id``.
"""

from __future__ import annotations

import sqlite3
import uuid
from typing import Any

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from starlette.exceptions import HTTPException as StarletteHTTPException

from core.structured_logging import get_logger
from http_middleware import REQUEST_ID_HEADER, current_request_id
from repository.errors import RETRY_AFTER_SECONDS, UNAVAILABLE_DETAIL, UNAVAILABLE_ERRORS, is_repository_unavailable

_log = get_logger("eval_service.errors")

VALIDATION_ERROR = "validation_error"
SERVICE_UNAVAILABLE = "service_unavailable"
_NO_BODY_STATUSES = frozenset({204, 304})
_ERROR_TYPES = {
    400: "bad_request",
    401: "unauthorized",
    403: "forbidden",
    404: "not_found",
    405: "method_not_allowed",
    409: "conflict",
    413: "payload_too_large",
    422: VALIDATION_ERROR,
    500: "internal_error",
    502: "upstream_error",
    503: SERVICE_UNAVAILABLE,
    504: "upstream_timeout",
}


def error_type_for(status: int) -> str:
    """Stable machine-readable category for an HTTP error status."""
    fallback = "server_error" if status >= 500 else "http_error"
    return _ERROR_TYPES.get(status, fallback)


def _request_id(request: Request) -> str | None:
    return getattr(request.state, "request_id", None)


def error_response(
    request: Request, status: int, detail: Any, error_type: str, headers: dict[str, str] | None = None,
) -> JSONResponse:
    request_id = _request_id(request)
    out_headers = dict(headers or {})
    if request_id:
        out_headers[REQUEST_ID_HEADER] = request_id
    return JSONResponse(
        status_code=status,
        content={"detail": detail, "error_type": error_type, "request_id": request_id},
        headers=out_headers,
    )


def _log_extra(request: Request, **fields: Any) -> dict[str, Any]:
    """Log ``extra`` with the path, plus ``request_id`` when the record factory will not add it."""
    extra: dict[str, Any] = {"path": request.url.path, **fields}
    if current_request_id() is None:
        extra["request_id"] = _request_id(request)
    return extra


async def http_exception_handler(request: Request, exc: StarletteHTTPException) -> Response:
    if exc.status_code in _NO_BODY_STATUSES:
        return Response(status_code=exc.status_code, headers=exc.headers)
    return error_response(request, exc.status_code, exc.detail, error_type_for(exc.status_code), exc.headers)


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return error_response(request, 422, jsonable_encoder(exc.errors()), VALIDATION_ERROR)


async def repository_unavailable_handler(request: Request, exc: Exception) -> JSONResponse:
    """Transient storage failures -> 503 + ``Retry-After`` instead of a generic 500."""
    error_id = uuid.uuid4().hex[:12]
    _log.warning(
        "repository_unavailable",
        exc_info=(type(exc), exc, exc.__traceback__),
        extra=_log_extra(request, error_id=error_id, error_type=type(exc).__name__),
    )
    return error_response(
        request, 503, f"{UNAVAILABLE_DETAIL} (error_id={error_id})", SERVICE_UNAVAILABLE,
        {"Retry-After": RETRY_AFTER_SECONDS},
    )


async def sqlite_operational_handler(request: Request, exc: sqlite3.OperationalError) -> JSONResponse:
    """SQLite OperationalError is 503 only for transient availability failures."""
    if is_repository_unavailable(exc):
        return await repository_unavailable_handler(request, exc)
    return await unhandled_exception_handler(request, exc)


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Last-resort JSON error body; details stay in the server log."""
    error_id = uuid.uuid4().hex[:12]
    _log.error(
        "unhandled_exception",
        exc_info=(type(exc), exc, exc.__traceback__),
        extra=_log_extra(request, error_id=error_id, error_type=type(exc).__name__),
    )
    return error_response(request, 500, f"Internal server error (error_id={error_id})", type(exc).__name__)


def register_error_handlers(app: FastAPI) -> None:
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(sqlite3.OperationalError, sqlite_operational_handler)
    for exc_type in UNAVAILABLE_ERRORS:
        app.add_exception_handler(exc_type, repository_unavailable_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)
