"""Bootstrap package for application entry-point wrappers."""
