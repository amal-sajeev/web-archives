"""Agent registry: auto-discovers src/agents/<agent_id>/ folders.

Each agent folder holds:
  agent.yaml          - AgentConfig
  dataset.json        - the golden set (Dataset)
  metrics_stub.json   - stubbed metrics API response
  custom_tests.py     - optional bespoke scorers (imported => self-registers)

Adding an agent requires no core code changes. An agent that fails to load or
validate is logged and skipped so one broken folder cannot take the service
down; the new agent map replaces the old one in a single assignment.
"""

from __future__ import annotations

import importlib.util
import json
import logging
import warnings
from pathlib import Path
from typing import Any

import yaml

from core.config import Config
from core.models import AgentConfig, Dataset

_log = logging.getLogger("eval_service.registry")


class RegisteredAgent:
    def __init__(
        self,
        folder: Path,
        config: AgentConfig,
        dataset: Dataset,
        custom_scorers: frozenset[str] = frozenset(),
    ):
        self.folder = folder
        self.config = config
        self.dataset = dataset
        # Scorer names this folder's custom_tests.py registered. The scorer
        # registry is process-global, so without this an agent could reference a
        # scorer that only another agent's custom_tests.py defines and still
        # validate -- then break the moment it is loaded on its own (playground,
        # a single-agent deployment, a different load order).
        self.custom_scorers = custom_scorers

    @property
    def metrics_stub_path(self) -> Path:
        return self.folder / self.config.metrics_stub_file


def _scorer_error(agent_id: str, agent: RegisteredAgent, metric: Any, known: dict[str, Any]) -> str | None:
    """Why ``metric.scorer`` is not usable by this agent, if it is not."""
    if metric.scorer in builtin_scorer_names() or metric.scorer in agent.custom_scorers:
        return None
    if metric.scorer in known:
        return (
            f"  agent '{agent_id}' metric '{metric.name}': scorer '{metric.scorer}' is defined by "
            f"another agent's custom_tests.py, not by this one and not built in"
        )
    return f"  agent '{agent_id}' metric '{metric.name}': unknown scorer '{metric.scorer}'"


def _agent_errors(agent_id: str, agent: RegisteredAgent, known: dict[str, Any]) -> list[str]:
    """Validation problems for one agent (unknown scorers, empty dataset)."""
    errors = [
        problem
        for metric in agent.dataset.metrics
        if (problem := _scorer_error(agent_id, agent, metric, known)) is not None
    ]
    if not agent.dataset.cases:
        errors.append(f"  agent '{agent_id}': dataset has no cases")
    enabled = enabled_metric_names(agent.dataset)
    declared = {metric.name for metric in agent.dataset.metrics}
    for name in sorted(enabled - declared):
        errors.append(
            f"  agent '{agent_id}': case baseline_metrics names '{name}', "
            f"which is not a metric in this dataset"
        )
    return errors


def enabled_metric_names(dataset: Dataset) -> set[str]:
    """Metric names enabled by at least one case via its ``baseline_metrics``.

    A metric that no case names there is never evaluated (see
    ``core.case_processor.metric_specs_for_case``), so this is what the dataset
    actually measures -- not ``dataset.metrics``.
    """
    return {name for case in dataset.cases for name in (case.baseline_metrics or {})}


def _agent_warnings(agent_id: str, agent: RegisteredAgent) -> list[str]:
    """Non-fatal problems that silently weaken an agent's gate.

    A metric absent from every case's ``baseline_metrics`` never runs, so adding
    one to ``dataset.metrics`` alone is a no-op -- and for a ``critical`` metric
    that is a hole in the gate, not a missing nice-to-have. A metrics stub keyed
    by ids that match no case yields no metrics at all for every case.
    """
    dataset = agent.dataset
    enabled = enabled_metric_names(dataset)
    never_run = [m for m in dataset.metrics if m.name not in enabled]
    warnings_out = []
    critical = [m.name for m in never_run if m.critical]
    if critical:
        warnings_out.append(
            f"  agent '{agent_id}': CRITICAL metric(s) {critical} are declared but named in no "
            f"case's baseline_metrics, so they never run and cannot veto a case"
        )
    other = [m.name for m in never_run if not m.critical]
    if other:
        warnings_out.append(
            f"  agent '{agent_id}': metric(s) {other} are declared but named in no case's "
            f"baseline_metrics, so they never run"
        )
    warnings_out.extend(_stub_warnings(agent_id, agent))
    warnings_out.extend(_target_url_warnings(agent_id, agent))
    return warnings_out


def _target_url_warnings(agent_id: str, agent: RegisteredAgent) -> list[str]:
    """Flag an enabled agent that resolves to a loopback URL inside a cluster.

    In a pod, ``http://localhost:<port>`` is this pod -- never the agent under
    test. It is what the fallback chain produces when the environment's
    ``*_AGENT_URL`` is unset and ``agent.yaml`` carries a local development
    base_url, so a values file that misses a key silently evaluates nothing.
    Harmless locally, which is why the check only applies in-cluster.
    """
    if not agent.config.enabled or not Config.in_cluster():
        return []
    url = Config.resolve_agent_base_url(agent_id, agent.config.base_url)
    if not Config.loopback_target(url):
        return []
    env_name = Config.agent_base_url_env(agent_id)
    hint = (
        f"set {env_name} for this environment"
        if env_name
        else f"no ConfigMap variable maps to '{agent_id}'; add one to Config._AGENT_BASE_URL_ENV_MAP"
    )
    return [
        f"  agent '{agent_id}' is enabled but its target resolves to {url!r}, which in a cluster "
        f"is this pod rather than the agent: {hint}"
    ]


def _stub_warnings(agent_id: str, agent: RegisteredAgent) -> list[str]:
    """Flag a metrics stub whose keys do not line up with the dataset's cases."""
    path = agent.metrics_stub_path
    if agent.config.metrics_source == "capture" or not path.exists():
        return []
    try:
        data = json.loads(path.read_text("utf-8-sig"))
    except (OSError, ValueError) as exc:
        return [f"  agent '{agent_id}': metrics stub {path.name} is unreadable ({exc})"]
    if not isinstance(data, dict):
        return [f"  agent '{agent_id}': metrics stub {path.name} is not a JSON object"]
    cases = data.get("cases", data)
    stub_ids = set(cases) if isinstance(cases, dict) else set()
    case_ids = {case.id for case in agent.dataset.cases}
    missing = sorted(case_ids - stub_ids)
    if missing and not (case_ids & stub_ids):
        return [
            f"  agent '{agent_id}': metrics stub {path.name} has no entry for any case "
            f"({sorted(stub_ids)[:4]} vs {sorted(case_ids)[:4]}), so no case gets metrics"
        ]
    if missing:
        return [f"  agent '{agent_id}': metrics stub {path.name} has no entry for case(s) {missing}"]
    return []


def _summary(agent: RegisteredAgent) -> dict[str, Any]:
    return {
        "agent_id": agent.config.agent_id,
        "name": agent.config.name,
        "version": agent.config.version,
        "description": agent.config.description,
        "dataset_id": agent.dataset.dataset_id,
        "dataset_version": agent.dataset.version,
        "cases": len(agent.dataset.cases),
        "metrics": [m.name for m in agent.dataset.metrics],
        # Metrics any case actually evaluates; the rest never run.
        "active_metrics": sorted(enabled_metric_names(agent.dataset)),
        "enabled": agent.config.enabled,
    }


def _force_enabled(agent_id: str) -> bool:
    """True when EVAL_ENABLE_AGENTS names this agent (or is "*")."""
    overrides = Config.ENABLE_AGENTS
    return "*" in overrides or agent_id in overrides


def _known_scorers() -> dict[str, Any]:
    from scorers import all_scorers  # lazy: avoid circular import

    return all_scorers()


def builtin_scorer_names() -> frozenset[str]:
    from scorers import builtin_scorer_names as names  # lazy: avoid circular import

    return names()


class Registry:
    def __init__(self, agents_dir: Path | None = None):
        self._dir = agents_dir or Config.AGENTS_DIR
        self._agents: dict[str, RegisteredAgent] = {}

    def load(self) -> Registry:
        """(Re)discover agents; broken folders are logged and skipped."""
        builtin_scorer_names()  # import the scorers package before any custom_tests.py
        loaded: dict[str, RegisteredAgent] = {}
        folders = sorted(p for p in self._dir.iterdir() if p.is_dir()) if self._dir.exists() else []
        for folder in folders:
            agent = self._load_folder(folder)
            if agent is None:
                continue
            agent_id = agent.config.agent_id
            if agent_id in loaded:
                _log.warning(
                    "duplicate agent_id '%s' in %s; replacing the one from %s",
                    agent_id, folder, loaded[agent_id].folder,
                )
            loaded[agent_id] = agent
        known = _known_scorers()
        for agent_id, agent in list(loaded.items()):
            errors = _agent_errors(agent_id, agent, known)
            if errors:
                _log.error("agent '%s' failed validation and was skipped:\n%s", agent_id, "\n".join(errors))
                del loaded[agent_id]
                continue
            problems = _agent_warnings(agent_id, agent)
            if problems:
                _log.warning("agent '%s' loaded with gaps:\n%s", agent_id, "\n".join(problems))
        self._agents = loaded
        return self

    def _load_folder(self, folder: Path) -> RegisteredAgent | None:
        cfg_file = folder / "agent.yaml"
        if not cfg_file.exists():
            return None
        try:
            config = AgentConfig.model_validate(yaml.safe_load(cfg_file.read_text("utf-8-sig")))
            dataset = Dataset.model_validate(
                json.loads((folder / config.dataset_file).read_text("utf-8-sig"))
            )
            custom_scorers = self._import_custom_tests(folder)
            self._resolve_golden_files(dataset, folder)
        except Exception:
            _log.exception("failed to load agent folder %s; skipping it", folder)
            return None
        if not config.enabled and _force_enabled(config.agent_id):
            config = config.model_copy(update={"enabled": True})
        return RegisteredAgent(folder, config, dataset, custom_scorers)

    def _resolve_golden_files(self, dataset: Dataset, agent_folder: Path) -> None:
        """Resolve golden_file references to golden_output text for each case."""
        from adapters.golden_files import load_golden_file
        for case in dataset.cases:
            if case.golden_file and not case.golden_output:
                try:
                    case.golden_output = load_golden_file(case.golden_file, agent_folder)
                except (FileNotFoundError, ValueError) as exc:
                    _log.warning("failed to load golden_file for case '%s': %s", case.id, exc)

    def validate(self, *, strict: bool = False) -> None:
        """Pre-flight: raise ValueError listing every unknown scorer / empty dataset.

        With ``strict`` the non-fatal gaps that :meth:`load` only logs -- a
        declared metric no case runs, a metrics stub keyed by unknown case ids --
        are errors too, which is what a CI config check wants.
        """
        known = _known_scorers()
        errors = [
            err
            for agent_id, agent in self._agents.items()
            for err in _agent_errors(agent_id, agent, known)
        ]
        if strict:
            errors += [
                warning
                for agent_id, agent in self._agents.items()
                for warning in _agent_warnings(agent_id, agent)
            ]
        if errors:
            raise ValueError("Dataset validation failed:\n" + "\n".join(errors))

    def warnings(self) -> list[str]:
        """Non-fatal gaps across the loaded agents (same text :meth:`load` logs)."""
        return [
            warning
            for agent_id, agent in self._agents.items()
            for warning in _agent_warnings(agent_id, agent)
        ]

    def _import_custom_tests(self, folder: Path) -> frozenset[str]:
        """Import the folder's custom_tests.py; return the scorer names it registered."""
        custom = folder / "custom_tests.py"
        if not custom.exists():
            return frozenset()
        spec = importlib.util.spec_from_file_location(f"custom_tests_{folder.name}", custom)
        if spec is None or spec.loader is None:
            # Skipping silently would surface later as confusing "unknown scorer" errors.
            raise ImportError(f"cannot load {custom} as a Python module")
        module = importlib.util.module_from_spec(spec)
        before = dict(_known_scorers())
        spec.loader.exec_module(module)  # decorators self-register scorers
        after = _known_scorers()
        # Names this module added, plus names it deliberately overrode.
        return frozenset(
            name for name, fn in after.items() if before.get(name) is not fn
        )

    def get(self, agent_id: str) -> RegisteredAgent:
        agents = self._agents
        if agent_id not in agents:
            raise KeyError(f"Unknown agent '{agent_id}'. Known: {sorted(agents)}")
        return agents[agent_id]

    def has(self, agent_id: str) -> bool:
        """True when ``agent_id`` is loaded (enabled or not)."""
        return agent_id in self._agents

    def list_agents(self, include_disabled: bool = False) -> list[dict[str, Any]]:
        """Summaries of the loaded agents, for list endpoints.

        Only enabled agents by default. With ``include_disabled=True`` disabled
        agents are appended after the enabled ones. Every item carries
        ``enabled``.
        """
        agents = sorted(self._agents.values(), key=lambda a: not a.config.enabled)  # stable: enabled first
        return [_summary(a) for a in agents if include_disabled or a.config.enabled]

    def list(self) -> list[dict[str, Any]]:
        """Deprecated alias of :meth:`list_agents`."""
        warnings.warn("Registry.list() is deprecated; use list_agents()", DeprecationWarning, stacklevel=2)
        return self.list_agents()
