"""Guard tests for the per-agent ``custom_tests.py`` scorers.

The modules are loaded by file path, exactly as the registry does, and fed
malformed agent output (non-dict metadata, ``paragraphs: null``, bool
confidence scores, "string" placeholders, scalar config values) that used to
crash or be mis-scored.
"""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest

from core.models import GoldenCase, Observation
from scorers import all_scorers

_AGENTS = Path(__file__).resolve().parents[1] / "agents"


def _load(agent: str):
    path = _AGENTS / agent / "custom_tests.py"
    spec = importlib.util.spec_from_file_location(f"custom_tests_{agent}_under_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def prelim():
    return _load("preliminary_research_agent")


@pytest.fixture(scope="module")
def scoping():
    return _load("scoping_summary")


def _obs(output) -> Observation:
    return Observation(target_id="t", output=output)


def _case(expected=None, inp=None) -> GoldenCase:
    return GoldenCase(id="c", input=inp or {"planNumber": "20588"}, expected=expected or {})


def _good_paragraph(**overrides) -> dict:
    paragraph = {
        "paragraph_id": "p1",
        "content": "Real content",
        "supporting_chunk_ids": [1],
        "supporting_citations": [{
            "chunk_id": 1, "page_number": 1, "gs_uri": "gs://b/x", "document_name": "d", "content_type": "pdf",
        }],
        "rationale": "because",
        "metadata": {"is_section_start": True, "section_confidence_score": 90},
    }
    paragraph.update(overrides)
    return paragraph


def _prelim_output(*paragraphs, **report_overrides) -> dict:
    report = {"report_title": "Past Review", "paragraphs": list(paragraphs), **report_overrides}
    return {"plan_number": "20588", "analysis_report": {"a": report}}


# --------------------------------------------------------------------------- #
# preliminary_research_agent
# --------------------------------------------------------------------------- #

def test_prelim_good_paragraph_scores_one(prelim):
    obs = _obs(_prelim_output(_good_paragraph()))
    for fn in (prelim.analysis_paragraph_structure_valid, prelim.analysis_citation_grounding,
               prelim.analysis_metadata_valid, prelim.analysis_rationale_valid):
        score, _, evidence = fn(observation=obs, case=_case())
        assert score == 1.0, (fn.__name__, evidence)


@pytest.mark.parametrize("metadata", [None, "oops", ["x"], 5])
def test_prelim_non_dict_metadata_does_not_crash(prelim, metadata):
    obs = _obs(_prelim_output(_good_paragraph(metadata=metadata)))
    score, _, evidence = prelim.analysis_metadata_valid(observation=obs, case=_case())
    assert score == 0.0
    assert evidence


def test_prelim_bool_confidence_is_not_a_number(prelim):
    meta = {"is_section_start": True, "section_confidence_score": True}
    obs = _obs(_prelim_output(_good_paragraph(metadata=meta)))
    score, _, _ = prelim.analysis_metadata_valid(observation=obs, case=_case())
    assert score == 0.0


def test_prelim_null_paragraphs(prelim):
    obs = _obs({"analysis_report": {"a": {"report_title": "T", "paragraphs": None}}})
    score, rationale, _ = prelim.analysis_paragraphs_valid(observation=obs, case=_case())
    assert score == 0.0
    assert "0/1" in rationale
    score, rationale, _ = prelim.analysis_rationale_valid(observation=obs, case=_case())
    assert (score, rationale) == (0.0, prelim.NO_PARAGRAPHS)


@pytest.mark.parametrize("value", ["string", " String ", None, "", True])
def test_prelim_placeholders_rejected(prelim, value):
    obs = _obs(_prelim_output(_good_paragraph(rationale=value, content=value)))
    assert prelim.analysis_rationale_valid(observation=obs, case=_case())[0] == 0.0
    assert prelim.analysis_paragraph_structure_valid(observation=obs, case=_case())[0] == 0.0


def test_prelim_placeholder_title_and_plan_number(prelim):
    output = _prelim_output(_good_paragraph(), report_title="string")
    output["plan_number"] = "string"
    obs = _obs(output)
    assert prelim.analysis_report_titles_valid(observation=obs, case=_case())[0] == 0.0
    assert prelim.plan_number_valid(observation=obs, case=_case(inp={"planNumber": "string"}))[0] == 0.0


def test_prelim_non_json_and_non_dict_output(prelim):
    for output in ("not json", "[1, 2]", 42, None):
        score, _, _ = prelim.analysis_bundle_present(observation=_obs(output), case=_case())
        assert score == 0.0


def test_prelim_string_expected_values_not_split(prelim):
    obs = _obs(_prelim_output(_good_paragraph(content="mentions 20588")))
    score, _, evidence = prelim.analysis_expected_values_present(
        observation=obs, case=_case({"expected_values": "20588"}))
    assert score == 1.0
    assert len(evidence) == 1


def test_prelim_bad_report_count_falls_back(prelim):
    obs = _obs(json.dumps(_prelim_output(_good_paragraph())))
    score, rationale, _ = prelim.analysis_bundle_present(
        observation=obs, case=_case({"report_count": "three"}))
    assert rationale == f"1/{prelim.DEFAULT_REPORT_COUNT} analysis reports present"
    assert score == pytest.approx(1 / prelim.DEFAULT_REPORT_COUNT)


# --------------------------------------------------------------------------- #
# scoping_summary
# --------------------------------------------------------------------------- #

def _scoping_bundle(paragraphs) -> dict:
    return {"analysis_report": {"Past Review Analysis": {
        "report_title": "Past Review Analysis", "paragraphs": paragraphs,
    }}}


def test_scoping_non_dict_metadata_and_null_paragraphs(scoping):
    obs = _obs(_scoping_bundle([{"content": "x", "supporting_chunk_ids": [1], "metadata": "bad"}]))
    score, _, _ = scoping.confidence_score_valid(observation=obs, case=_case())
    assert score == 1.0  # not a section start, no confidence -> rule obeyed
    obs = _obs(_scoping_bundle(None))
    assert scoping.rationale_coverage(observation=obs, case=_case())[:2] == (0.0, scoping.NO_PARAGRAPHS)


def test_scoping_bool_confidence_rejected(scoping):
    meta = {"is_section_start": True, "section_confidence_score": True}
    obs = _obs(_scoping_bundle([{"content": "x", "metadata": meta}]))
    assert scoping.confidence_score_valid(observation=obs, case=_case())[0] == 0.0


def test_scoping_placeholder_rationale_rejected(scoping):
    obs = _obs(_scoping_bundle([{"content": "x", "rationale": "string"}, {"content": "y", "rationale": "ok"}]))
    assert scoping.rationale_coverage(observation=obs, case=_case())[0] == 0.5


def test_scoping_string_headings_not_split(scoping):
    obs = _obs(_scoping_bundle([{"content": "Section 1: Overview"}]))
    case = _case({"required_sections": {"Past Review Analysis": "Section 1"}})
    score, rationale, _ = scoping.scoping_sections_present(observation=obs, case=case)
    assert (score, rationale) == (1.0, "1/1 required sections present")


def test_scoping_bad_max_chunk_id_and_bool_ids(scoping):
    obs = _obs(_scoping_bundle([{"content": "claim", "supporting_chunk_ids": [True, "2"]}]))
    score, _, _ = scoping.citation_grounding(observation=obs, case=_case({"max_chunk_id": None}))
    assert score == 1.0


def test_scoping_reports_present_evidence_matches_score(scoping):
    obs = _obs(_scoping_bundle([]))
    score, _, evidence = scoping.scoping_reports_present(
        observation=obs, case=_case({"required_reports": "Past Review Analysis"}))
    assert score == 0.0
    assert evidence == [f"{scoping.CROSS_MARK} Past Review Analysis"]


def test_scoping_repr_string_report(scoping):
    text = ("report_title='Past Review Analysis' paragraphs=[ParagraphCitation(paragraph_id='1', "
            "content='Section 1: Scope', supporting_chunk_ids=[3], rationale='r', "
            "metadata=Meta(is_section_start=True, section_confidence_score=80))]")
    obs = _obs({"Past Review Analysis": text})
    assert scoping.confidence_score_valid(observation=obs, case=_case())[0] == 1.0
    assert scoping.scoping_titles_exact(
        observation=obs, case=_case({"required_reports": ["Past Review Analysis"]}))[0] == 1.0


# --------------------------------------------------------------------------- #
# scope_extraction must keep its dataset scorers registered, whether the
# identifier passthrough scorer is provided centrally or by agent-local tests.
# --------------------------------------------------------------------------- #

def test_scope_extraction_scorers_all_registered():
    # Load the custom_tests module so artifact scorers are registered
    _load("scope_extraction")
    dataset = json.loads((_AGENTS / "scope_extraction" / "dataset.json").read_text(encoding="utf-8-sig"))
    known = all_scorers()
    assert "identifier_passthrough" in known
    assert all(metric["scorer"] in known for metric in dataset["metrics"])
