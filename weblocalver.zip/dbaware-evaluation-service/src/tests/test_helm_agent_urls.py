"""The agent.yaml -> core/config.py -> helm values chain that decides which URL
each agent is actually called on.

Nothing else checks this chain, and every link fails quietly: a values key the
ConfigMap reads but the file omits renders as an empty string, an empty env var
counts as unset, and the fallback then lands on whatever ``agent.yaml`` says --
a localhost port, or (as it did) another environment's namespace. The result is
a green deployment that evaluates the wrong service, or nothing at all.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest
import yaml

from core.config import Config
from registry import Registry

CHART = Path(__file__).resolve().parents[2] / "helm-chart"
CONFIGMAP = CHART / "templates" / "configmap.yaml"

#: values-<env>.yaml -> the Kubernetes namespace every agent URL must sit in.
ENV_NAMESPACES = {"values-ct1.yaml": "155081-1-cta-ct1", "values-dev1.yaml": "155081-1-cta"}
#: Namespaces that appear in the chart, used to spot a hardcoded one in agent.yaml.
KNOWN_NAMESPACES = tuple(ENV_NAMESPACES.values())
_QUOTED_VALUE_RE = re.compile(r"^\s*([A-Z0-9_]+):\s*\{\{\s*quote\s+\.Values\.([a-zA-Z0-9_]+)\s*\}\}")


def _configmap_keys() -> dict[str, str]:
    """ConfigMap env var -> the values.yaml key it renders."""
    mapping = {}
    for line in CONFIGMAP.read_text(encoding="utf-8").splitlines():
        match = _QUOTED_VALUE_RE.match(line)
        if match:
            mapping[match.group(1)] = match.group(2)
    assert mapping, "parsed no env vars out of the ConfigMap template"
    return mapping


def _values(*names: str) -> dict:
    merged: dict = {}
    for name in names:
        merged.update(yaml.safe_load((CHART / name).read_text(encoding="utf-8")) or {})
    return merged


def _enabled_agents():
    registry = Registry().load()
    return {
        agent_id: agent
        for agent_id, agent in registry._agents.items()
        if agent.config.enabled
    }


# --------------------------------------------------------------------------- #
# values.yaml must declare every key the ConfigMap reads, and no dead ones
# --------------------------------------------------------------------------- #

def test_every_configmap_key_is_declared_in_the_base_values_file():
    """Helm renders a missing value as "", which the service reads as unset and
    silently replaces with an agent.yaml fallback."""
    base = _values("values.yaml")
    missing = {env: key for env, key in _configmap_keys().items() if key not in base}
    assert missing == {}


def test_the_base_values_file_has_no_agent_url_key_the_configmap_ignores():
    """A dead `*_agent_url` key is a trap: setting it changes nothing."""
    used = set(_configmap_keys().values())
    declared = {k for k in _values("values.yaml") if k.endswith("_agent_url")}
    assert declared - used == set()


@pytest.mark.parametrize("env_file", sorted(ENV_NAMESPACES))
def test_each_environment_sets_every_agent_url_the_configmap_reads(env_file):
    values = _values("values.yaml", env_file)
    url_keys = [k for k in _configmap_keys().values() if k.endswith("_agent_url")]
    unset = [k for k in url_keys if not str(values.get(k) or "").strip()]
    # notification_* have no agent folder yet, so they are allowed to be blank.
    assert [k for k in unset if not k.startswith("notification_")] == []


# --------------------------------------------------------------------------- #
# Every enabled agent must be steerable per environment
# --------------------------------------------------------------------------- #

def test_every_enabled_agent_has_a_configmap_variable():
    """Without one, the agent can only ever be reached at its agent.yaml URL,
    so it cannot be pointed at CT1 and dev1 separately."""
    unmapped = [a for a in _enabled_agents() if Config.agent_base_url_env(a) is None]
    assert unmapped == []


def test_no_agent_yaml_hardcodes_a_cluster_namespace():
    """A namespace baked into agent.yaml becomes the fallback for *every*
    environment, so one of them silently calls another one's service."""
    offenders = []
    for path in sorted((CHART.parent / "src" / "agents").glob("*/agent.yaml")):
        text = path.read_text(encoding="utf-8")
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("base_url:") and any(ns in stripped for ns in KNOWN_NAMESPACES):
                offenders.append(f"{path.parent.name}: {stripped}")
    assert offenders == []


# --------------------------------------------------------------------------- #
# Resolution per environment
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("env_file", sorted(ENV_NAMESPACES))
def test_every_enabled_agent_resolves_into_its_own_namespace(env_file, monkeypatch):
    namespace = ENV_NAMESPACES[env_file]
    values = _values("values.yaml", env_file)
    for env_name, values_key in _configmap_keys().items():
        monkeypatch.setenv(env_name, str(values.get(values_key) or ""))

    wrong = []
    for agent_id, agent in _enabled_agents().items():
        url = Config.resolve_agent_base_url(agent_id, agent.config.base_url) or ""
        if f".{namespace}." not in url:
            wrong.append(f"{agent_id} -> {url!r} (expected namespace {namespace})")
        if Config.loopback_target(url):
            wrong.append(f"{agent_id} -> {url!r} is a loopback address")
    assert wrong == []


@pytest.mark.parametrize("env_file", sorted(ENV_NAMESPACES))
def test_no_agent_resolves_into_a_different_environment(env_file, monkeypatch):
    """dev1 must never reach CT1, and vice versa."""
    namespace = ENV_NAMESPACES[env_file]
    others = [ns for ns in KNOWN_NAMESPACES if ns != namespace]
    values = _values("values.yaml", env_file)
    for env_name, values_key in _configmap_keys().items():
        monkeypatch.setenv(env_name, str(values.get(values_key) or ""))

    for agent_id, agent in _enabled_agents().items():
        url = Config.resolve_agent_base_url(agent_id, agent.config.base_url) or ""
        for other in others:
            # "155081-1-cta" is a prefix of "155081-1-cta-ct1", so compare whole labels.
            assert f".{other}." not in url, f"{agent_id} in {namespace} resolves to {other}: {url}"


def test_the_agent_url_env_vars_the_code_reads_all_exist_in_the_configmap():
    configmap = set(_configmap_keys())
    referenced = {Config.agent_base_url_env(a) for a in _enabled_agents()}
    assert {r for r in referenced if r} - configmap == set()


# --------------------------------------------------------------------------- #
# A misconfigured cluster deployment must be loud
# --------------------------------------------------------------------------- #

def test_a_loopback_target_in_a_cluster_is_reported(monkeypatch):
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    for env_name in _configmap_keys():
        monkeypatch.delenv(env_name, raising=False)
    monkeypatch.setattr(Config, "AGENT_SERVICE_BASE_URL", "http://localhost:4000")

    warnings = Registry().load().warnings()
    flagged = {w.split("'")[1] for w in warnings if "resolves to" in w}
    assert flagged == set(_enabled_agents()), flagged
    assert any("set SCOPE_EXTRACTION_AGENT_URL" in w for w in warnings)


def test_a_loopback_target_outside_a_cluster_is_not_reported(monkeypatch):
    """Local development legitimately targets localhost."""
    monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
    for env_name in _configmap_keys():
        monkeypatch.delenv(env_name, raising=False)
    monkeypatch.setattr(Config, "AGENT_SERVICE_BASE_URL", "http://localhost:4000")

    assert [w for w in Registry().load().warnings() if "resolves to" in w] == []


@pytest.mark.parametrize("url", [
    "http://localhost:4010", "http://127.0.0.1:4013", "http://0.0.0.0:4002",
    "localhost:4000", None, "",
])
def test_loopback_detection(url):
    assert Config.loopback_target(url) is True


@pytest.mark.parametrize("url", [
    "http://query-service.155081-1-cta.svc.cluster.local:4001",
    "http://scoping-procedure-agent.155081-1-cta-ct1:8001",
    "https://agent.example.db.com",
])
def test_cluster_urls_are_not_loopback(url):
    assert Config.loopback_target(url) is False
