"""The route table and the process entrypoint.

Both were invisible for a long time: the suite imports handlers directly, and
the coverage config omitted ``bootstrap/app.py``, ``router/__init__.py`` and
``router/routes.py`` outright -- so a route registered against a misspelled
handler, or dropped altogether, failed nothing.

Everything here goes through the built app rather than the ``router`` module.
Two reasons: ``import main`` is ambiguous (``src/main/__init__.py`` makes
``main`` a package, so the name reaches the module ``src/main/main.py`` only
while ``src/main`` precedes ``src`` on ``sys.path``, which ``bootstrap/app.py``
arranges), and this FastAPI version wraps an included router in a private
``_IncludedRouter`` whose routes are not reachable from ``app.routes``.
"""

from __future__ import annotations

import runpy
import sys

import pytest
from fastapi.testclient import TestClient

# Every API path the service documents, with the status a GET should return.
_API_PATHS = [
    "/api/health",
    "/api/agents",
    "/api/runs",
    "/api/runs/summary",
    "/api/settings",
    "/api/captures",
    "/api/playground/environment",
    "/api/evaluate/streams",
    "/api/labels",
]
_UI_PATHS = ["/", "/run.html", "/run_detail.html", "/playground.html", "/apitester.html"]


@pytest.fixture(scope="module")
def app():
    from bootstrap.app import app as built

    return built


@pytest.fixture(scope="module")
def client(app):
    with TestClient(app) as test_client:
        yield test_client


def test_the_openapi_schema_builds_for_every_route(app):
    """Generating the schema validates each handler's signature and response
    model, so a malformed annotation fails here rather than at runtime."""
    schema = app.openapi()
    assert schema["openapi"]
    paths = schema["paths"]
    assert len(paths) >= 30, f"only {len(paths)} documented paths; routes may have been dropped"
    for path, operations in paths.items():
        assert operations, f"{path} is documented with no operations"


def test_every_documented_api_path_is_in_the_schema(app):
    documented = set(app.openapi()["paths"])
    missing = [p for p in _API_PATHS if p not in documented]
    assert missing == []


@pytest.mark.parametrize("path", _API_PATHS)
def test_core_api_routes_answer(client, path):
    assert client.get(path).status_code == 200


@pytest.mark.parametrize("path", _UI_PATHS)
def test_ui_routes_serve_html(client, path):
    response = client.get(path)
    assert response.status_code == 200
    assert response.text.lstrip().lower().startswith("<!doctype html")


def test_the_static_javascript_bundle_is_served(client):
    response = client.get("/app.js")
    assert response.status_code == 200
    assert "javascript" in response.headers["content-type"]


def test_the_health_typo_alias_still_resolves(client):
    """/api/helath shipped as a backward-compatible alias; keep it answering."""
    assert client.get("/api/helath").status_code == client.get("/api/health").status_code


def test_an_unknown_route_is_a_clean_404(client):
    assert client.get("/api/does-not-exist").status_code == 404


def test_import_main_is_ambiguous_and_resolves_by_sys_path_order():
    """Documents the trap in the module docstring so it stays visible."""
    from pathlib import Path

    src = Path(__file__).resolve().parents[1]
    assert (src / "__init__.py").exists()
    assert (src / "main" / "__init__.py").exists(), "src/main is a package ..."
    assert (src / "main" / "main.py").exists(), "... and also contains main.py"


def test_the_entrypoint_starts_uvicorn_with_the_configured_root_path(monkeypatch):
    """bootstrap/app.py only runs as a script, so exercise it as one."""
    started: dict[str, object] = {}
    import uvicorn

    monkeypatch.setattr(uvicorn, "run", lambda application, **kw: started.update(kw, app=application))
    monkeypatch.setenv("ROOT_PATH", "/evaluation-service")
    monkeypatch.delitem(sys.modules, "bootstrap.app", raising=False)
    runpy.run_module("bootstrap.app", run_name="__main__")

    from core.config import Config

    assert started["root_path"] == "/evaluation-service"
    assert started["port"] == Config.PORT
    assert started["host"] == "0.0.0.0"
    assert started["app"] is not None


def test_the_entrypoint_defaults_to_no_root_path(monkeypatch):
    started: dict[str, object] = {}
    import uvicorn

    monkeypatch.setattr(uvicorn, "run", lambda application, **kw: started.update(kw))
    monkeypatch.delenv("ROOT_PATH", raising=False)
    monkeypatch.delitem(sys.modules, "bootstrap.app", raising=False)
    runpy.run_module("bootstrap.app", run_name="__main__")
    assert started["root_path"] == ""
