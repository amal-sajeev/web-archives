"""Regressions for the gaps that let the gate pass, or stall, when it should not.

Each test here pins a behaviour that was previously wrong in a way no existing
test noticed: a config typo scoring 1.0 on a critical metric, a declared metric
that never runs, an export that cannot tell a pass from a failure, every
evaluation serialising behind one mutex, and dead target/retry config.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest

from adapters.capture import CaptureMetricsClient, CaptureStore, observation_to_cta_action
from adapters.http_adapter import HttpAdapter
from adapters.metrics_api import resolve_source
from core import aggregation
from core.case_processor import build_case_result, metric_specs_for_case
from core.config import Config
from core.models import Dataset, GoldenCase, MetricSpec, Observation, ResponseMapping, Score, SkippedMetric, TargetSpec
from core.playground.scoped_registry import RegistryScope
from core.run_events import run_started
from handlers.runs import _csv_text, _pdf_lines
from registry import Registry, enabled_metric_names
from utils import build_text_pdf


# --------------------------------------------------------------------------- #
# A skipped critical metric is a veto -- and the report must say which one
# --------------------------------------------------------------------------- #

def _score(metric: str, score: float, *, critical: bool = False, threshold: float = 0.8) -> Score:
    return Score(metric=metric, score=score, passed=score >= threshold, threshold=threshold,
                 weight=1.0, rationale="ok", critical=critical)


def _case_result(scores: list[Score], skipped: list[SkippedMetric]):
    return build_case_result(
        GoldenCase(id="c1", input={}),
        Observation(target_id="c1", output="x"),
        [*scores, *skipped],
    )


def test_unmeasured_critical_metric_vetoes_an_otherwise_perfect_case():
    result = _case_result(
        [_score("everything_else", 1.0)],
        [SkippedMetric(metric="groundedness", reason="no source context supplied", critical=True)],
    )
    assert result.weighted_score == 1.0
    assert result.passed is False
    assert aggregation.critical_failures(result.scores, result.skipped) == ["groundedness"]


def test_exports_name_the_unmeasured_critical_metric_that_blocked_the_case():
    """A FAIL with every listed metric passing is unreadable without the skip."""
    result = _case_result(
        [_score("everything_else", 1.0)],
        [SkippedMetric(metric="groundedness", reason="no source context supplied", critical=True)],
    )
    run = SimpleNamespace(
        run_id="abcdef123456", agent_id="a", dataset_id="d", dataset_version="1",
        weighted_score=1.0, weighted_delta=0.0, status="FAIL",
        creation_ts="2026-01-01T00:00:00Z", created_by="DEVELOPER", case_results=[result],
    )
    pdf_text = "\n".join(_pdf_lines(run))
    assert "groundedness" in pdf_text
    assert "not measured" in pdf_text
    assert "Critical metrics blocking this case: groundedness" in pdf_text

    csv_rows = _csv_text(run).splitlines()
    assert any(row.startswith("c1,") and "groundedness" in row and row.endswith("skipped") for row in csv_rows)
    assert any(row.endswith("measured") for row in csv_rows[1:])


def test_pdf_export_distinguishes_pass_from_fail_after_latin1_encoding():
    """The PDF font is Latin-1, so a tick and a cross both became "?"."""
    result = _case_result(
        [_score("good", 1.0), _score("bad", 0.1, critical=True)],
        [SkippedMetric(metric="unmeasured", reason="no context", critical=True)],
    )
    run = SimpleNamespace(
        run_id="abcdef123456", agent_id="a", dataset_id="d", dataset_version="1",
        weighted_score=0.55, weighted_delta=0.0, status="FAIL",
        creation_ts="2026-01-01T00:00:00Z", created_by="DEVELOPER", case_results=[result],
    )
    rendered = build_text_pdf(_pdf_lines(run)).decode("latin-1")
    assert "[PASS] good" in rendered
    assert "[FAIL] critical bad" in rendered
    assert "[SKIP] critical unmeasured" in rendered
    # Nothing in the marks survived as the replacement character.
    assert "[?]" not in rendered


# --------------------------------------------------------------------------- #
# A dataset can set its own gate limits
# --------------------------------------------------------------------------- #

def test_dataset_threshold_and_tolerance_reach_the_gate():
    scores = [_score("m", 0.6, threshold=0.5)]
    case = GoldenCase(id="c1", input={})
    obs = Observation(target_id="c1", output="x")

    lenient = Dataset(dataset_id="d", version="1", threshold=0.5)
    assert build_case_result(case, obs, list(scores), lenient).passed is True

    strict = Dataset(dataset_id="d", version="1", threshold=0.9)
    assert build_case_result(case, obs, list(scores), strict).passed is False

    # No dataset limits -> Config defaults (DATASET_THRESHOLD is 0.8).
    assert build_case_result(case, obs, list(scores), None).passed is False


# --------------------------------------------------------------------------- #
# Declared-but-never-run metrics
# --------------------------------------------------------------------------- #

def _write_agent(root: Path, agent_id: str, metrics: list[dict], cases: list[dict], **cfg) -> Path:
    folder = root / agent_id
    folder.mkdir()
    lines = [f"agent_id: {agent_id}", f"name: {agent_id}"]
    lines += [f"{k}: {v}" for k, v in cfg.items()]
    (folder / "agent.yaml").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (folder / "dataset.json").write_text(json.dumps({
        "dataset_id": f"{agent_id}-ds", "version": "1", "metrics": metrics, "cases": cases,
    }), encoding="utf-8")
    return folder


_TERMS = {"terms": ["x"]}


def test_metric_no_case_enables_is_reported_as_a_gap(tmp_path, caplog):
    _write_agent(
        tmp_path, "gappy",
        metrics=[
            {"name": "wired", "type": "deterministic", "scorer": "contains", "config": _TERMS},
            {"name": "orphan", "type": "safety", "scorer": "no_pii_leakage", "critical": True},
        ],
        cases=[{"id": "c1", "input": {}, "baseline_metrics": {"wired": 1.0}}],
    )
    reg = Registry(tmp_path).load()
    assert reg.has("gappy")  # non-fatal: the agent still loads

    gaps = "\n".join(reg.warnings())
    assert "CRITICAL metric(s) ['orphan']" in gaps
    assert "never run and cannot veto" in gaps
    with pytest.raises(ValueError, match=r"CRITICAL metric\(s\) \['orphan'\]"):
        reg.validate(strict=True)
    reg.validate()  # non-strict stays silent about gaps

    agent = reg.get("gappy")
    assert enabled_metric_names(agent.dataset) == {"wired"}
    assert [s.name for s in metric_specs_for_case(agent.dataset, agent.dataset.cases[0])] == ["wired"]


def test_baseline_metrics_naming_an_undeclared_metric_is_an_error(tmp_path):
    _write_agent(
        tmp_path, "typo",
        metrics=[{"name": "wired", "type": "deterministic", "scorer": "contains", "config": _TERMS}],
        cases=[{"id": "c1", "input": {}, "baseline_metrics": {"wired": 1.0, "wried": 1.0}}],
    )
    reg = Registry(tmp_path).load()
    assert not reg.has("typo")  # a baseline for a metric that does not exist is fatal


def test_a_stub_keyed_by_unknown_case_ids_is_reported(tmp_path):
    folder = _write_agent(
        tmp_path, "orphanstub",
        metrics=[{"name": "m", "type": "deterministic", "scorer": "contains", "config": _TERMS}],
        cases=[{"id": "real_case", "input": {}, "baseline_metrics": {"m": 1.0}}],
    )
    (folder / "metrics_stub.json").write_text(
        json.dumps({"cases": {"some_other_case": {"payload": {"Response_Code": "200"}}}}),
        encoding="utf-8",
    )
    gaps = "\n".join(Registry(tmp_path).load().warnings())
    assert "has no entry for any case" in gaps
    assert "so no case gets metrics" in gaps


def test_run_started_lists_only_the_metrics_that_will_report():
    dataset = Dataset(
        dataset_id="d", version="1",
        metrics=[
            MetricSpec(name="wired", type="deterministic", scorer="contains"),
            MetricSpec(name="orphan", type="deterministic", scorer="contains"),
        ],
        cases=[GoldenCase(id="c1", input={}, baseline_metrics={"wired": 1.0})],
    )
    event = run_started("a", dataset, 1, 1, dataset.cases)
    assert [m["name"] for m in event["metrics"]] == ["wired"]
    # Without the case list every declared metric is listed (historical behaviour).
    assert [m["name"] for m in run_started("a", dataset, 1, 1)["metrics"]] == ["wired", "orphan"]


# --------------------------------------------------------------------------- #
# A dataset may only use built-in scorers and its own custom ones
# --------------------------------------------------------------------------- #

def test_an_agent_cannot_borrow_another_agents_custom_scorer(tmp_path):
    owner = _write_agent(
        tmp_path, "owner",
        metrics=[{"name": "m", "type": "deterministic", "scorer": "borrowed_scorer"}],
        cases=[{"id": "c1", "input": {}, "baseline_metrics": {"m": 1.0}}],
    )
    (owner / "custom_tests.py").write_text(
        'from scorers.base import scorer\n\n\n'
        '@scorer("borrowed_scorer")\n'
        'def borrowed_scorer(**_):\n'
        '    return 1.0, "ok", []\n',
        encoding="utf-8",
    )
    _write_agent(
        tmp_path, "thief",
        metrics=[{"name": "m", "type": "deterministic", "scorer": "borrowed_scorer"}],
        cases=[{"id": "c1", "input": {}, "baseline_metrics": {"m": 1.0}}],
    )
    reg = Registry(tmp_path).load()
    assert reg.has("owner")
    assert not reg.has("thief")
    assert reg.get("owner").custom_scorers == frozenset({"borrowed_scorer"})


# --------------------------------------------------------------------------- #
# Evaluations must not serialise behind the playground's registry mutex
# --------------------------------------------------------------------------- #

async def test_shared_registry_scope_lets_runs_overlap():
    scope = RegistryScope()
    peak = 0

    async def run_once():
        nonlocal peak
        async with scope.shared():
            peak = max(peak, scope.readers)
            await asyncio.sleep(0)
            peak = max(peak, scope.readers)

    await asyncio.gather(*(run_once() for _ in range(4)))
    assert peak > 1, "evaluations serialised; a shared scope must allow overlap"
    assert scope.readers == 0


async def test_exclusive_registry_scope_waits_for_in_flight_runs():
    scope = RegistryScope()
    order: list[str] = []
    reader_entered = asyncio.Event()
    release_reader = asyncio.Event()

    async def reader():
        async with scope.shared():
            order.append("reader-in")
            reader_entered.set()
            await release_reader.wait()
            order.append("reader-out")

    async def writer():
        await reader_entered.wait()
        async with scope.exclusive():
            order.append("writer-in")

    async def let_go():
        await reader_entered.wait()
        await asyncio.sleep(0)
        release_reader.set()

    await asyncio.gather(reader(), writer(), let_go())
    assert order == ["reader-in", "reader-out", "writer-in"]


async def test_a_waiting_writer_blocks_new_runs_from_starting():
    scope = RegistryScope()
    order: list[str] = []
    first_in = asyncio.Event()
    release_first = asyncio.Event()

    async def first_reader():
        async with scope.shared():
            first_in.set()
            await release_first.wait()
            order.append("first-out")

    async def writer():
        await first_in.wait()
        async with scope.exclusive():
            order.append("writer")

    async def late_reader():
        await first_in.wait()
        await asyncio.sleep(0)  # let the writer queue on the turnstile first
        release_first.set()
        async with scope.shared():
            order.append("late-reader")

    await asyncio.gather(first_reader(), writer(), late_reader())
    assert order == ["first-out", "writer", "late-reader"], order


# --------------------------------------------------------------------------- #
# target.retries actually retries
# --------------------------------------------------------------------------- #

def _adapter(retries: int, handler) -> tuple[HttpAdapter, list[int], httpx.MockTransport]:
    calls: list[int] = []

    def track(request: httpx.Request) -> httpx.Response:
        calls.append(len(calls) + 1)
        return handler(len(calls))

    target = TargetSpec(
        adapter="http", endpoint="/go", method="GET", retries=retries,
        response=ResponseMapping(output_path="output"),
    )
    adapter = HttpAdapter("http://agent.test", "/go", target)
    transport = httpx.MockTransport(track)
    return adapter, calls, transport


async def _run(adapter, transport, monkeypatch, case):
    real_init = httpx.AsyncClient.__init__

    def patched(self, **kwargs):
        kwargs["transport"] = transport
        real_init(self, **kwargs)

    monkeypatch.setattr(httpx.AsyncClient, "__init__", patched)
    monkeypatch.setattr("adapters.http_adapter._retry_delay", lambda _attempt: 0.0)
    return await adapter.run_case(case)


@pytest.mark.parametrize(("status", "retried"), [(503, True), (429, True), (404, False), (400, False)])
async def test_retries_only_transient_http_failures(monkeypatch, status, retried):
    adapter, calls, transport = _adapter(2, lambda _n: httpx.Response(status, json={"output": "x"}))
    obs = await _run(adapter, transport, monkeypatch, GoldenCase(id="c1", input={}))
    assert len(calls) == (3 if retried else 1)
    assert obs.error is not None and str(status) in obs.error


async def test_a_transient_failure_that_then_succeeds_yields_a_clean_observation(monkeypatch):
    adapter, calls, transport = _adapter(
        2, lambda n: httpx.Response(200, json={"output": "ok"}) if n > 1 else httpx.Response(503),
    )
    obs = await _run(adapter, transport, monkeypatch, GoldenCase(id="c1", input={}))
    assert len(calls) == 2
    assert (obs.output, obs.error) == ("ok", None)


async def test_without_retries_configured_there_is_exactly_one_attempt(monkeypatch):
    adapter, calls, transport = _adapter(0, lambda _n: httpx.Response(503))
    await _run(adapter, transport, monkeypatch, GoldenCase(id="c1", input={}))
    assert len(calls) == 1


# --------------------------------------------------------------------------- #
# Output mapping: an absent path is an error, an explicit null is not
# --------------------------------------------------------------------------- #

async def test_a_null_output_is_not_reported_as_a_missing_path(monkeypatch):
    adapter, _calls, transport = _adapter(0, lambda _n: httpx.Response(200, json={"output": None}))
    obs = await _run(adapter, transport, monkeypatch, GoldenCase(id="c1", input={}))
    assert (obs.output, obs.error) == (None, None)


async def test_a_genuinely_absent_output_path_is_reported(monkeypatch):
    adapter, _calls, transport = _adapter(0, lambda _n: httpx.Response(200, json={"other": 1}))
    obs = await _run(adapter, transport, monkeypatch, GoldenCase(id="c1", input={}))
    assert obs.error == "output_path 'output' not found in response"


# --------------------------------------------------------------------------- #
# Captured audit records must name the agent, not the case
# --------------------------------------------------------------------------- #

async def test_capture_records_name_the_agent_not_the_case():
    observation = Observation(target_id="some_case_id", output="x", latency_ms=5)
    await CaptureMetricsClient(CaptureStore(), agent_id="scope_extraction").fetch("c1", observation)
    action = observation_to_cta_action("c1", observation, agent_id="scope_extraction")["CTA_ACTION"]
    assert action["payload"]["Agent_Name"] == "scope_extraction"
    assert action["target_entity_id"] == "c1"
    assert action["payload"]["Activity_Type"] == "Agent_Evaluation"


# --------------------------------------------------------------------------- #
# METRICS_API_BASE alone selects the live API, as documented
# --------------------------------------------------------------------------- #

def test_metrics_api_base_alone_selects_the_http_source(monkeypatch):
    monkeypatch.setattr(Config, "METRICS_SOURCE", "")
    monkeypatch.setattr(Config, "METRICS_API_BASE", "http://metrics.test/api")
    assert resolve_source() == "http"
    monkeypatch.setattr(Config, "METRICS_API_BASE", None)
    assert resolve_source() == "stub"
    # An explicit setting still wins over the inferred default.
    monkeypatch.setattr(Config, "METRICS_API_BASE", "http://metrics.test/api")
    monkeypatch.setattr(Config, "METRICS_SOURCE", "stub")
    assert resolve_source() == "stub"
    assert resolve_source("capture") == "capture"


def test_judge_retry_count_is_reported_from_the_setting_the_retry_loop_uses():
    from handlers.playground import playground_environment
    from scorers import judge_invoke

    env = playground_environment()
    assert env["judge_retries"] == Config.JUDGE_TRANSIENT_RETRIES
    assert judge_invoke.Config.JUDGE_TRANSIENT_RETRIES == Config.JUDGE_TRANSIENT_RETRIES
    assert env["metrics_source"] == resolve_source()


# --------------------------------------------------------------------------- #
# An exact-match output must pass with the LLM judges unavailable
# --------------------------------------------------------------------------- #

def test_no_shipped_agent_has_a_judge_backed_critical_metric():
    """A judge metric skips wherever Vertex is absent, and a skipped critical
    metric vetoes the case -- so marking one critical makes the gate decide on
    credentials rather than on the agent's output. Every critical metric must
    be one that can always be measured against its target."""
    from scorers.base import is_judge_scorer

    registry = Registry().load()
    offenders = {
        agent_id: sorted(
            m.name for m in agent.dataset.metrics if m.critical and is_judge_scorer(m.scorer)
        )
        for agent_id, agent in registry._agents.items()
    }
    assert {a: names for a, names in offenders.items() if names} == {}


def test_every_shipped_agent_runs_every_metric_it_declares():
    """A metric no case names in baseline_metrics never runs; for a critical one
    that is a hole in the gate rather than a missing nice-to-have."""
    registry = Registry().load()
    gaps = {
        agent_id: sorted({m.name for m in agent.dataset.metrics} - enabled_metric_names(agent.dataset))
        for agent_id, agent in registry._agents.items()
    }
    assert {a: names for a, names in gaps.items() if names} == {}
    assert registry.warnings() == []
    registry.validate(strict=True)


#: Characters a cp1252-then-UTF-8 double decode mangles, written as codepoints
#: so this file stays plain ASCII: en dash, right single quotation mark.
EN_DASH, RSQUO = chr(0x2013), chr(0x2019)
#: What each one turns into once mojibaked (U+00E2 U+20AC U+201C / U+2122).
MOJIBAKED = (chr(0x00E2) + chr(0x20AC),)


def test_scope_extraction_golden_matches_the_recorded_agent_output():
    """The golden must round-trip the agent's own bytes; it previously carried
    cp1252 mojibake and was missing three of the four wrapper keys."""
    agent = Registry().load().get("scope_extraction")
    golden = json.loads(agent.dataset.cases[0].golden_output)
    assert sorted(golden) == ["artifact", "data", "plan_number", "source"]

    details = golden["data"]["plan_details"]
    assert f"Finding Validation {EN_DASH} Finding Ref." in details
    assert f"{RSQUO}s" in details["Plan Change Remarks"]
    blob = json.dumps(golden, ensure_ascii=False)
    for marker in MOJIBAKED:
        assert marker not in blob, f"mojibake marker {marker!r} is back in the golden"


def test_a_case_passes_when_only_non_critical_judge_metrics_are_skipped():
    scores = [_score("deterministic_check", 1.0, critical=True, threshold=1.0)]
    skipped = [
        SkippedMetric(metric=name, reason="LLM judge unavailable: PROJECT_NAME is not set",
                      threshold=0.8, critical=False, judge=True)
        for name in ("relevance", "faithfulness", "completeness")
    ]
    result = _case_result(scores, skipped)
    assert result.passed is True
    assert result.weighted_score == 1.0
    assert aggregation.critical_failures(result.scores, result.skipped) == []
    # The report still shows what was not measured.
    assert len(result.skipped) == 3


# --------------------------------------------------------------------------- #
# Only a critical metric, the weighted score or the delta decides the verdict
# --------------------------------------------------------------------------- #

def test_a_non_critical_metric_below_threshold_does_not_veto_on_its_own():
    """Vetoing on every metric made `weight` and the dataset threshold almost
    irrelevant, and let one brittle low-weight check fail a good run."""
    result = _case_result(
        [
            _score("schema", 1.0, critical=True, threshold=1.0),
            _score("pii", 1.0, critical=True, threshold=1.0),
            Score(metric="conciseness", score=0.0, passed=False, threshold=0.5,
                  weight=0.5, critical=False, rationale="verbose"),
        ],
        [],
    )
    assert result.passed is True
    assert result.weighted_score == pytest.approx(0.9 / 0.98, rel=0.2)
    # It is still recorded as a failure, so the report shows it.
    assert [s.metric for s in result.scores if not s.passed] == ["conciseness"]


def test_enough_non_critical_weight_failing_still_fails_the_case():
    """A metric heavy enough to drag the weighted score under the dataset
    threshold fails the case through the score, which is the point of `weight`."""
    result = _case_result(
        [
            _score("schema", 1.0, critical=True, threshold=1.0),
            Score(metric="quality", score=0.0, passed=False, threshold=0.7,
                  weight=8.0, critical=False, rationale="poor"),
        ],
        [],
    )
    assert result.weighted_score < Config.DATASET_THRESHOLD
    assert result.passed is False


def test_a_critical_metric_below_threshold_still_vetoes_whatever_the_score():
    result = _case_result(
        [
            Score(metric="schema", score=0.0, passed=False, threshold=1.0,
                  weight=0.1, critical=True, rationale="broken"),
            _score("everything_else", 1.0, threshold=0.5),
        ],
        [],
    )
    # The weighted score is comfortably above the gate; the veto decides.
    assert result.weighted_score > Config.DATASET_THRESHOLD
    assert result.passed is False
    assert aggregation.critical_failures(result.scores, result.skipped) == ["schema"]


def test_a_regression_beyond_tolerance_fails_even_with_every_metric_passing():
    scores = [
        Score(metric="m", score=0.9, passed=True, threshold=0.5, weight=1.0,
              baseline=1.0, delta=-0.1, critical=False, rationale=""),
    ]
    result = _case_result(scores, [])
    assert result.weighted_delta == pytest.approx(-0.1)
    assert result.passed is False


def test_a_critical_metric_can_always_be_measured_in_every_shipped_dataset():
    """A critical metric that skips vetoes the case, so one that depends on
    credentials or an optional package would fail on the wrong machine."""
    from scorers.base import is_judge_scorer

    environmental = {"docx_table_has", "pdf_table_has", "embedding_similarity"}
    registry = Registry().load()
    offenders = [
        f"{agent_id}/{m.name} ({m.scorer})"
        for agent_id, agent in registry._agents.items()
        for m in agent.dataset.metrics
        if m.critical and (is_judge_scorer(m.scorer) or m.scorer in environmental)
    ]
    assert offenders == []
