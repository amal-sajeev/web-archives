"""The configs assume the agents will get better. A metric must fail an agent for
being WRONG, never for being BETTER.

Each test here pins a case where a strictly improved output -- more correct
detail, a more careful caveat, a richer structure -- used to score worse than a
minimal one, or where a dataset-level literal could never be true for every case.
"""

from __future__ import annotations

import json
import logging

import pytest

from scorer_helpers import case, obs, run, spec
from scorers._util import resolve_case_refs, spec_config
from scorers.base import MetricSkipped, get_scorer
from registry import Registry


# --------------------------------------------------------------------------- #
# Metric config can name the case's own expectation instead of a fixed literal
# --------------------------------------------------------------------------- #

def test_config_resolves_a_reference_into_case_expected():
    golden = case(expected={"expected_total": 20000}, input={"invoice": "globex"})
    resolved = spec_config(spec("json_path", {"path": "total", "op": "equals",
                                              "value": "${expected.expected_total}"}), golden)
    assert resolved["value"] == 20000
    assert resolved["path"] == "total"  # untouched


def test_a_reference_keeps_the_resolved_type():
    golden = case(expected={"sections": ["A", "B"], "count": 3, "flag": True})
    out = resolve_case_refs(
        {"sections": "${expected.sections}", "count": "${expected.count}", "flag": "${expected.flag}"},
        golden,
    )
    assert out == {"sections": ["A", "B"], "count": 3, "flag": True}


def test_references_resolve_inside_nested_config():
    golden = case(expected={"headers": ["Metric", "Value"]})
    out = resolve_case_refs({"tables": [{"required_headers": "${expected.headers}", "min_rows": 3}]}, golden)
    assert out == {"tables": [{"required_headers": ["Metric", "Value"], "min_rows": 3}]}


def test_a_reference_inside_a_longer_string_is_left_alone():
    """Regex patterns and rubric prose must survive untouched."""
    golden = case(expected={"total": 1})
    out = resolve_case_refs({"pattern": r"total: \$\{expected.total\}", "rubric": "a ${expected.x} b"}, golden)
    assert out["pattern"] == r"total: \$\{expected.total\}"
    assert out["rubric"] == "a ${expected.x} b"


def test_a_reference_the_case_does_not_define_skips_rather_than_comparing_to_none():
    golden = case(expected={"other": 1})
    with pytest.raises(MetricSkipped, match=r"'\$\{expected.missing\}' is not present in case.expected"):
        resolve_case_refs({"value": "${expected.missing}"}, golden)


def test_json_path_asserts_each_cases_own_value():
    cfg = {"path": "total", "op": "equals", "value": "${expected.expected_total}"}
    acme = case(expected={"expected_total": 8000})
    globex = case(expected={"expected_total": 20000})
    assert run("json_path", obs({"total": 8000}), acme, config=cfg)[0] == 1.0
    assert run("json_path", obs({"total": 20000}), globex, config=cfg)[0] == 1.0
    # ... and still catches a genuinely wrong value.
    assert run("json_path", obs({"total": 8000}), globex, config=cfg)[0] == 0.0


def test_section_present_asserts_each_cases_own_sections():
    cfg = {"sections": "${expected.expected_sections}"}
    financial = case(expected={"expected_sections": ["Revenue Analysis", "Net Income"]})
    risk = case(expected={"expected_sections": ["Risk Identification", "Residual Risk"]})
    financial_doc = obs("# R\n## Revenue Analysis\nx\n## Net Income\ny", {"content_type": "markdown"})
    risk_doc = obs("# R\n## Risk Identification\nx\n## Residual Risk\ny", {"content_type": "markdown"})
    assert run("section_present", financial_doc, financial, config=cfg)[0] == 1.0
    assert run("section_present", risk_doc, risk, config=cfg)[0] == 1.0
    assert run("section_present", financial_doc, risk, config=cfg)[0] == 0.0


# --------------------------------------------------------------------------- #
# Shipped datasets: no metric may pin a literal it cannot satisfy on every case
# --------------------------------------------------------------------------- #

def test_no_shipped_metric_pins_a_value_literal_across_several_cases():
    """A `value` literal that is only true for one case can never pass on the
    others; such a metric must reference the case instead."""
    registry = Registry().load()
    offenders = []
    for agent_id, agent in registry._agents.items():
        for metric in agent.dataset.metrics:
            cases_using = [c for c in agent.dataset.cases if metric.name in (c.baseline_metrics or {})]
            if len(cases_using) < 2:
                continue
            value = (metric.config or {}).get("value")
            if value is not None and not (isinstance(value, str) and value.startswith("${")):
                # A type name ("number", "str") is a shape check, not a case value.
                if str(value).lower() not in {"number", "str", "string", "int", "integer",
                                              "float", "bool", "boolean", "list", "array",
                                              "dict", "object", "null", "none"}:
                    offenders.append(f"{agent_id}/{metric.name} = {value!r}")
    assert offenders == []


@pytest.mark.parametrize("agent_id", ["report_writer", "document_qa", "invoice_parser"])
def test_every_case_can_satisfy_its_own_content_metrics(agent_id, caplog):
    """Build the output each case's own `expected` describes and score it: the
    content metrics must pass for every case, not just the first one."""
    caplog.set_level(logging.ERROR)
    agent = Registry().load().get(agent_id)
    for golden_case in agent.dataset.cases:
        expected = golden_case.expected
        sections = expected.get("expected_sections", [])
        values = [str(v) for v in expected.get("expected_values", [])]
        if agent_id == "invoice_parser":
            # Mirrors what sample_agents/invoice_parser_agent.py emits.
            output = {
                "vendor": expected["expected_vendor"], "invoice_number": "INV-1",
                "total": expected["expected_total"], "currency": "USD",
                "item_count": expected["expected_items"],
                "line_items": [{"description": "d", "amount": 1}] * expected["expected_items"],
            }
            observation = obs(output)
        else:
            body = "\n\n".join(f"## {s}\n- {values[i] if i < len(values) else 'detail'}"
                               for i, s in enumerate(sections))
            observation = obs(f"# Report\n\n{body}\n\n" + " ".join(values),
                              {"content_type": "markdown"})
        for metric in agent.dataset.metrics:
            if metric.name not in (golden_case.baseline_metrics or {}):
                continue
            if metric.scorer not in {"section_present", "contains", "json_path", "field_match"}:
                continue
            score = get_scorer(metric.scorer)(
                observation=observation, case=golden_case, spec=metric, metrics={},
            )[0]
            assert score >= metric.threshold, (
                f"{agent_id}/{golden_case.id}/{metric.name}: an output matching this case's own "
                f"expected content scored {score} against threshold {metric.threshold}"
            )


# --------------------------------------------------------------------------- #
# Saying MORE must not lower a reference-coverage score
# --------------------------------------------------------------------------- #

def test_golden_coverage_is_unchanged_by_extra_correct_detail():
    golden_text = "the review covered five assessment units and three key controls"
    golden = case(golden_output=golden_text)
    cfg = {"mode": "recall"}
    padding = " ".join(f"additional{i}" for i in range(200))
    minimal = run("token_overlap_f1", obs(golden_text), golden, config=cfg)[0]
    richer = run("token_overlap_f1", obs(f"{golden_text} {padding}"), golden, config=cfg)[0]
    assert minimal == richer == 1.0

    # F1 is the measure that punishes length, which is why these datasets ask for recall.
    f1_rich = run("token_overlap_f1", obs(f"{golden_text} {padding}"), golden, config={"mode": "f1"})[0]
    assert f1_rich < 0.2


def test_shipped_golden_coverage_metrics_use_recall():
    registry = Registry().load()
    for agent_id, agent in registry._agents.items():
        for metric in agent.dataset.metrics:
            if metric.scorer != "token_overlap_f1":
                continue
            assert (metric.config or {}).get("mode") == "recall", (
                f"{agent_id}/{metric.name} compares against the golden with F1, which falls as the "
                f"output grows even when it still covers the whole reference"
            )


# --------------------------------------------------------------------------- #
# An honest caveat is better behaviour, not a refusal
# --------------------------------------------------------------------------- #

_CAVEAT_ANSWER = (
    "R021 is covered by CFTC rule 23.700. The walkthrough report records a traceability gap: no "
    "specific key control is mapped to R021 in the control inventory. I cannot confirm from the "
    "walkthrough documentation whether a compensating control exists, so raise it with the owner."
)


def test_a_caveat_inside_a_substantive_answer_is_not_a_refusal():
    answering = case(expected={})
    assert run("refusal_appropriate", obs(_CAVEAT_ANSWER), answering)[0] == 1.0


@pytest.mark.parametrize("text", [
    "I cannot confirm this from walkthrough documentation.",
    "Thanks for asking. I am unable to answer that.",
])
def test_a_genuine_over_refusal_still_fails(text):
    assert run("refusal_appropriate", obs(text), case(expected={}))[0] == 0.0


def test_a_required_refusal_still_passes():
    must = case(expected={"must_refuse": True})
    assert run("refusal_appropriate", obs("I cannot confirm this from walkthrough documentation."), must)[0] == 1.0
    # Obeying the injection instead of refusing is still a failure.
    assert run("refusal_appropriate", obs("Sure! Plan 20588 covers Title VII across all regions."), must)[0] == 0.0


def test_a_case_can_declare_its_own_refusal_markers():
    custom = case(expected={"must_refuse": True, "refusal_markers": ["out of scope for this assistant"]})
    assert run("refusal_appropriate", obs("Out of scope for this assistant."), custom)[0] == 1.0
    # The default phrases no longer apply once the case overrides them.
    assert run("refusal_appropriate", obs("I cannot help with that."), custom)[0] == 0.0


# --------------------------------------------------------------------------- #
# The judge must not mark an agent down for exceeding the reference
# --------------------------------------------------------------------------- #

def test_golden_anchored_judge_prompts_say_the_reference_is_a_floor():
    from scorers.judge_prompts import _JUDGE_PROMPT, _JUDGE_PROMPT_SWAPPED, _REFERENCE_GUARD

    for template in (_JUDGE_PROMPT, _JUDGE_PROMPT_SWAPPED):
        rendered = template.format(bias="B", reference=_REFERENCE_GUARD, input="I", golden="G", output="O")
        assert "not as the only acceptable answer" in rendered
        assert "do NOT penalise additional information" in rendered
        # The check must still bite on contradictions.
        assert "contradict" in rendered


def test_a_config_rubric_that_uses_a_golden_carries_the_same_guard():
    from scorers.rubric import _golden_block

    block = _golden_block({"uses_golden": True}, case(golden_output="G"), "rubric")
    assert "not as the only acceptable answer" in block
    assert "GOLDEN OUTPUT:" in block
    assert _golden_block({}, case(golden_output="G"), "rubric") == ""


# --------------------------------------------------------------------------- #
# Upper bounds must be runaway guards, not style preferences
# --------------------------------------------------------------------------- #

def test_shipped_length_ceilings_leave_room_for_a_much_richer_answer():
    """range_score decays as max/value, so a metric fails above max/threshold.
    That limit must be well clear of what the goldens are today."""
    registry = Registry().load()
    tight = []
    for agent_id, agent in registry._agents.items():
        goldens = [len(c.golden_output or "") for c in agent.dataset.cases if c.golden_output]
        words = [len((c.golden_output or "").split()) for c in agent.dataset.cases if c.golden_output]
        for metric in agent.dataset.metrics:
            cfg = metric.config or {}
            if metric.scorer != "length_range" or not cfg.get("max") or not goldens:
                continue
            limit = cfg["max"] / metric.threshold if metric.threshold else float("inf")
            current = max(words) if cfg.get("unit", "words") == "words" else max(goldens)
            if current and limit / current < 5:
                tight.append(f"{agent_id}/{metric.name}: fails above {limit:.0f}, "
                             f"only {limit / current:.1f}x the largest golden ({current})")
    assert tight == [], json.dumps(tight, indent=2)
