"""Shared pytest fixtures for the CTNA Evaluation Service test suite.

The suite never touches Vertex or a database: the LLM judge is replaced by a
scripted fake, and ADC resolution is monkeypatched. This mirrors the offline
design (capture/label stores in memory, SQLite/no-DB) so `pytest` runs anywhere.
"""

from __future__ import annotations

import os
import sys
from datetime import UTC, datetime
from pathlib import Path

# Ensure src/main is on the path regardless of working directory. This file is
# src/tests/conftest.py, so its first parent is src/tests and its second is src;
# the application modules live in src/main beside it.
_src_main = Path(__file__).resolve().parents[1] / "main"
if str(_src_main) not in sys.path:
    sys.path.insert(0, str(_src_main))

import pytest

from core.models import CaseResult, GoldenCase, MetricSpec, Observation, RunRecord, Score
from scorers.vertex import JudgeVerdict

_TLS_ENV_KEYS = ("SECURITY_EXCLUDE_TLS", "EVAL_EXCLUDE_TLS")


@pytest.fixture(autouse=True)
def _reset_judge_cache():
    """Isolate the process-lifetime judge cache between tests."""
    from scorers import llm_judge
    llm_judge.reset_cache()
    yield
    llm_judge.reset_cache()


@pytest.fixture(autouse=True)
def _reset_global_state(monkeypatch):
    """Reset process-wide singletons (live runs, capture/label stores, TLS policy)."""
    from adapters import capture_store
    from core.config import Config
    from core.labels import label_store
    from core.run_manager import run_manager

    for key in _TLS_ENV_KEYS:
        if key in os.environ:
            monkeypatch.setenv(key, os.environ[key])
        else:
            monkeypatch.delenv(key, raising=False)
    monkeypatch.setattr(Config, "EXCLUDE_TLS", Config.EXCLUDE_TLS)
    for singleton in (run_manager, capture_store, label_store):
        singleton.__init__()
    yield
    for singleton in (run_manager, capture_store, label_store):
        singleton.__init__()


@pytest.fixture
def sqlite_repo(tmp_path):
    """A fresh, initialised SQLite repository in a temp directory."""
    from repository.sqlite_repo import SqliteRepository

    repo = SqliteRepository(str(tmp_path / "eval.db"))
    repo.init_schema()
    yield repo
    repo.close()


def _case_result(case_id: str, passed: bool, score: float) -> CaseResult:
    return CaseResult(
        case_id=case_id,
        scores=[Score(metric="m1", score=score, passed=passed, threshold=0.5, weight=1.0, rationale="r")],
        weighted_score=score,
        weighted_delta=0.0,
        passed=passed,
        observation=Observation(target_id=case_id, output="out"),
    )


@pytest.fixture
def make_run():
    """Factory for RunRecord objects; ``cases`` is a list of ``(case_id, passed, score)``."""
    def _factory(run_id="run-1", *, agent_id="agent-1", status="PASS", score=0.8,
                 creation_ts=None, cases=(), dataset_id="ds-1", **extra):
        return RunRecord(
            run_id=run_id,
            agent_id=agent_id,
            dataset_id=dataset_id,
            dataset_version="1",
            weighted_score=score,
            weighted_delta=0.0,
            status=status,
            creation_ts=creation_ts or datetime.now(UTC).isoformat(),
            created_by="DEVELOPER",
            case_results=[_case_result(*c) for c in cases],
            **extra,
        )
    return _factory


class FakeJudge:
    """Stand-in for the object returned by `build_judge()`.

    `.invoke(prompt)` returns the next scripted JudgeVerdict, cycling through the
    supplied scores so self-consistency (variance) can be exercised. Records every
    prompt it saw so tests can assert on caching / order-swap behaviour.
    """

    def __init__(self, scores, rationale="looks good", evidence=None):
        self._scores = list(scores)
        self._i = 0
        self._rationale = rationale
        self._evidence = list(evidence or ["ev-1"])
        self.prompts: list[str] = []

    def invoke(self, prompt):
        self.prompts.append(prompt)
        score = self._scores[self._i % len(self._scores)]
        self._i += 1
        return JudgeVerdict(
            score=float(score),
            passed=False,
            rationale=self._rationale,
            evidence=list(self._evidence),
        )


@pytest.fixture
def make_judge():
    """Factory building a FakeJudge with the given per-invocation scores."""
    def _factory(scores, **kw):
        return FakeJudge(scores, **kw)
    return _factory


@pytest.fixture
def patch_judge(monkeypatch):
    """Patch `build_judge` in llm_judge to return a supplied FakeJudge."""
    def _apply(judge):
        monkeypatch.setattr(
            "scorers.llm_judge.build_judge", lambda: judge
        )
        return judge
    return _apply


@pytest.fixture
def patch_judge_unavailable(monkeypatch):
    """Make `build_judge` raise, simulating missing ADC/Vertex (offline)."""
    def _raise():
        raise RuntimeError("PROJECT_NAME is not set; the evaluation judge requires Vertex AI.")
    monkeypatch.setattr("scorers.llm_judge.build_judge", _raise)


@pytest.fixture
def observation():
    return Observation(
        target_id="data-extraction-agent",
        output="The AppCatalog lookup for AU-10001 under Acme Corp returns the inventory.",
        tool_calls=[{"tool": "get_application_data", "args": "AU-10001;Acme Corp", "error": None}],
        latency_ms=1200,
        usage={"input_tokens": 1800, "output_tokens": 500},
        model="gemini-2.5-pro",
    )


@pytest.fixture
def case():
    return GoldenCase(
        id="app_single_unit",
        input={"query": "Get the AppCatalog data for AU-10001 at Acme Corp."},
        golden_output="The AppCatalog lookup for AU-10001 under Acme Corp returns the inventory.",
        expected={"expected_tool": "get_application_data", "expected_values": ["AU-10001", "Acme Corp"]},
        baseline_metrics={"faithfulness": 0.9},
    )


@pytest.fixture
def make_spec():
    def _factory(name="faithfulness", **kw):
        params = dict(name=name, type="llm_judge", scorer=name, weight=1.0, threshold=0.8)
        params.update(kw)
        return MetricSpec(**params)
    return _factory


# --------------------------------------------------------------------------- #
# HTTP layer: TestClient with dependency overrides (no lifespan side effects)
# --------------------------------------------------------------------------- #

def fake_agent(agent_id, *, name=None, enabled=True, cases=1, metrics=("m1",)):
    """A RegisteredAgent-shaped namespace (``config`` / ``dataset``) for registry fakes."""
    from types import SimpleNamespace

    return SimpleNamespace(
        config=SimpleNamespace(agent_id=agent_id, name=name or f"{agent_id} name", enabled=enabled),
        dataset=SimpleNamespace(
            dataset_id=f"{agent_id}-ds", version="1",
            cases=[object()] * cases, metrics=[SimpleNamespace(name=m) for m in metrics],
        ),
    )


class FakeRegistry:
    """Registry stand-in: ``has`` / ``list_agents`` / ``get`` over ``fake_agent`` objects.

    Mirrors the real Registry: ``list_agents`` summarises the enabled agents, and
    ``include_disabled=True`` appends the disabled ones; every row carries ``enabled``.
    """

    def __init__(self, agent_ids=("agent-1", "agent-2"), disabled=()):
        self._agents = {a: fake_agent(a) for a in agent_ids}
        self._agents.update({a: fake_agent(a, enabled=False) for a in disabled})

    @property
    def agent_ids(self):
        return list(self._agents)

    def has(self, agent_id):
        return agent_id in self._agents

    def list_agents(self, include_disabled=False):
        ordered = sorted(self._agents.values(), key=lambda a: not a.config.enabled)
        return [
            {
                "agent_id": a.config.agent_id, "name": a.config.name,
                "dataset_id": a.dataset.dataset_id, "dataset_version": a.dataset.version,
                "cases": len(a.dataset.cases), "metrics": [m.name for m in a.dataset.metrics],
                "enabled": a.config.enabled,
            }
            for a in ordered
            if include_disabled or a.config.enabled
        ]

    def get(self, agent_id):
        if agent_id not in self._agents:
            raise KeyError(f"Unknown agent '{agent_id}'")
        return self._agents[agent_id]


class FakeRunner:
    """Runner stand-in; ``handler(agent_id, **kw)`` decides the outcome (async)."""

    def __init__(self, make_run):
        self._make_run = make_run
        self.calls = []
        self.handler = None

    async def evaluate(self, agent_id, dataset_version=None, judge_repetitions=1,
                       created_by="DEVELOPER", case_ids=None, progress=None, should_cancel=None):
        self.calls.append({"agent_id": agent_id, "created_by": created_by})
        if self.handler is not None:
            return await self.handler(agent_id, progress=progress)
        run = self._make_run(f"run-{agent_id}", agent_id=agent_id, cases=[("c1", True, 0.9)])
        if progress:
            await progress({"type": "run_done", "run_id": run.run_id, "status": run.status})
        return run


@pytest.fixture
async def api(sqlite_repo, make_run):
    """Async HTTP client over ``main.app`` with registry/repo/runner overridden.

    Uses ``httpx.ASGITransport`` (works with every installed Starlette/httpx pair)
    and never enters the lifespan, so no real agents or databases are touched.
    """
    from types import SimpleNamespace

    import httpx

    import dependencies
    import main

    registry = FakeRegistry()
    runner = FakeRunner(make_run)
    overrides = {
        dependencies.get_registry: lambda: registry,
        dependencies.get_repo: lambda: sqlite_repo,
        dependencies.get_runner: lambda: runner,
    }
    main.app.dependency_overrides.update(overrides)
    transport = httpx.ASGITransport(app=main.app, raise_app_exceptions=False)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        yield SimpleNamespace(client=client, registry=registry, repo=sqlite_repo, runner=runner)
    for key in overrides:
        main.app.dependency_overrides.pop(key, None)
