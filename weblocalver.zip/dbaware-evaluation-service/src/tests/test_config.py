"""Configuration helpers, Config defaults and the shared models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from core import config as config_module
from core.config import Config, cast_value, env_value, parse_bool
from core.models import (
    ABCompareRequest, AgentConfig, AsyncEvaluateRequest, EvaluateRequest, HumanLabel, MetricSpec,
    Observation, TargetSpec,
)


class TestConfigAdditions:
    def test_case_concurrency_default(self):
        assert Config.CASE_CONCURRENCY >= 1

    def test_run_retention_default(self):
        assert Config.RUN_RETENTION_DAYS >= 0

    def test_webhook_timeout_default(self):
        assert Config.WEBHOOK_TIMEOUT > 0

    def test_agent_url_attributes_removed(self):
        assert not hasattr(Config, "SCOPING_PROCEDURE_AGENT_URL")


class TestHelpers:
    @pytest.mark.parametrize("value,expected", [
        ("1", True), ("YES", True), (" on ", True), ("0", False), ("false", False), (True, True), (0, False),
    ])
    def test_parse_bool(self, value, expected):
        assert parse_bool(value) is expected

    def test_env_set_splits_and_trims_comma_lists(self, monkeypatch):
        monkeypatch.setenv("EVAL_TEST_SET", " report_writer, ,document_qa ")
        assert config_module._env_set("EVAL_TEST_SET") == frozenset({"report_writer", "document_qa"})
        monkeypatch.delenv("EVAL_TEST_SET")
        assert config_module._env_set("EVAL_TEST_SET") == frozenset()

    def test_parse_bool_empty_uses_default(self):
        assert parse_bool("", default=True) is True
        assert parse_bool(None, default=True) is True

    def test_empty_env_var_counts_as_unset(self, monkeypatch):
        monkeypatch.setenv("EVAL_TEST_EMPTY", "   ")
        assert env_value("EVAL_TEST_EMPTY") is None
        monkeypatch.setenv("DB_NAME", "")
        assert config_module._get_config_value("database", "name", "fallback") == "fallback"

    def test_cast_error_names_the_setting(self):
        with pytest.raises(ValueError, match="EVAL_CASE_CONCURRENCY"):
            cast_value("EVAL_CASE_CONCURRENCY", "many", int)

    def test_yaml_load_is_cached(self, monkeypatch, tmp_path):
        env_dir = tmp_path / "unit"
        env_dir.mkdir()
        (env_dir / "environment.yaml").write_text("judge:\n  model: yaml-model\n", encoding="utf-8")
        monkeypatch.setattr(config_module, "_CONFIG_DIR", tmp_path)
        monkeypatch.setenv("ENV_NAME", "unit")
        monkeypatch.delenv("JUDGE_MODEL", raising=False)
        monkeypatch.delenv("EVAL_JUDGE_MODEL", raising=False)
        monkeypatch.delenv("JUDGE_JUDGE_MODEL", raising=False)
        config_module._load_yaml_for.cache_clear()
        try:
            assert config_module._get_config_value("judge", "model") == "yaml-model"
            (env_dir / "environment.yaml").write_text("judge:\n  model: changed\n", encoding="utf-8")
            assert config_module._get_config_value("judge", "model") == "yaml-model"
        finally:
            config_module._load_yaml_for.cache_clear()

    def test_base_url_env_template_is_expanded(self, monkeypatch):
        monkeypatch.setenv("WALKTHROUGH_TEST_URL", "http://wt:8080")
        assert Config.resolve_agent_base_url("x_agent", "${env.WALKTHROUGH_TEST_URL}") == "http://wt:8080"
        monkeypatch.delenv("WALKTHROUGH_TEST_URL")
        monkeypatch.setattr(Config, "AGENT_SERVICE_BASE_URL", "http://shared")
        assert Config.resolve_agent_base_url("x_agent", "${env.WALKTHROUGH_TEST_URL}") == "http://shared"


class TestPerAgentMetricsSource:
    def test_agent_config_has_metrics_source(self):
        assert AgentConfig(agent_id="t", name="T", metrics_source="capture").metrics_source == "capture"

    def test_agent_config_metrics_source_defaults_none(self):
        assert AgentConfig(agent_id="t", name="T").metrics_source is None


class TestModels:
    def test_metric_literals_are_validated(self):
        with pytest.raises(ValidationError):
            MetricSpec(name="m", type="deterministic", scorer="s", direction="sideways")
        with pytest.raises(ValidationError):
            MetricSpec(name="m", type="made_up", scorer="s")

    def test_observation_accepts_rich_usage_and_float_latency(self):
        obs = Observation(target_id="t", latency_ms=12.5, usage={"input_tokens": 3, "detail": {"cached": 1}})
        assert obs.latency_ms == 12.5
        assert obs.usage["detail"] == {"cached": 1}

    def test_human_label_verdict_pattern(self):
        with pytest.raises(ValidationError):
            HumanLabel(case_id="c", verdict="maybe")
        assert HumanLabel(case_id="c", verdict="pass", agent_id="a").agent_id == "a"

    def test_request_inheritance_and_created_by(self):
        assert issubclass(AsyncEvaluateRequest, EvaluateRequest)
        assert AsyncEvaluateRequest(agent_id="a", webhook_url="http://hook").judge_repetitions == 1
        assert ABCompareRequest(agent_a="a", agent_b="b").created_by is None

    def test_auth_spec_is_optional_and_parsed(self):
        assert TargetSpec().auth is None
        spec = TargetSpec(auth={"type": "bearer", "token_env": "TOKEN_VAR"})
        assert spec.auth.token_env == "TOKEN_VAR"


@pytest.fixture
def yaml_env(monkeypatch, tmp_path):
    """Point Config at a temp config dir; returns a writer for config/<env>/environment.yaml."""
    monkeypatch.setattr(config_module, "_CONFIG_DIR", tmp_path)
    monkeypatch.setenv("ENV_NAME", "unit")
    config_module._load_yaml_for.cache_clear()

    def _write(text: str) -> None:
        (tmp_path / "unit").mkdir(exist_ok=True)
        (tmp_path / "unit" / "environment.yaml").write_text(text, encoding="utf-8")
        config_module._load_yaml_for.cache_clear()

    yield _write
    config_module._load_yaml_for.cache_clear()


class TestYamlLoading:
    def test_missing_environment_file_means_defaults(self, yaml_env):
        assert config_module._load_yaml_config() == {}
        assert config_module._get_config_value("metrics", "api_base", "dflt") == "dflt"

    def test_non_mapping_yaml_is_ignored(self, yaml_env):
        yaml_env("- just\n- a list\n")
        assert config_module._load_yaml_config() == {}

    def test_blank_yaml_value_falls_back_to_default(self, yaml_env, monkeypatch):
        monkeypatch.delenv("METRICS_API_BASE", raising=False)
        yaml_env("metrics:\n  api_base: ''\n")
        assert config_module._get_config_value("metrics", "api_base", "dflt") == "dflt"

    def test_broken_yaml_names_the_file(self, yaml_env):
        yaml_env("judge: [unclosed\n")
        with pytest.raises(ValueError, match="config/unit/environment.yaml is not valid YAML"):
            config_module._load_yaml_config()


class TestServiceVersion:
    def test_env_var_wins(self, monkeypatch):
        monkeypatch.setenv("EVAL_SERVICE_VERSION", "9.9.9")
        assert config_module._resolve_service_version() == "9.9.9"

    def test_version_file_then_local_fallback(self, monkeypatch, tmp_path):
        monkeypatch.delenv("EVAL_SERVICE_VERSION", raising=False)
        monkeypatch.setattr(config_module, "_ROOT", tmp_path)
        assert config_module._resolve_service_version() == "0.0.0-local"
        (tmp_path / "VERSION").write_text("  \n", encoding="utf-8")
        assert config_module._resolve_service_version() == "0.0.0-local"
        (tmp_path / "VERSION").write_text("1.4.2\n", encoding="utf-8")
        assert config_module._resolve_service_version() == "1.4.2"


class TestSecretsAndUrls:
    def test_direct_secret_and_no_secret(self):
        assert Config.resolve_secret("direct", "projects/p/secrets/s") == "direct"
        assert Config.resolve_secret(None, None) is None

    def test_secret_manager_lookup(self, monkeypatch):
        import sys
        import types

        class _Client:
            def access_secret_version(self, name):
                payload = types.SimpleNamespace(data=f"value-of-{name}".encode())
                return types.SimpleNamespace(payload=payload)

        module = types.ModuleType("google.cloud.secretmanager")
        module.SecretManagerServiceClient = _Client
        cloud = types.ModuleType("google.cloud")
        cloud.secretmanager = module
        monkeypatch.setitem(sys.modules, "google.cloud", cloud)
        monkeypatch.setitem(sys.modules, "google.cloud.secretmanager", module)
        assert Config.resolve_secret(None, "s1") == "value-of-s1"

    def test_agent_specific_env_var_wins(self, monkeypatch):
        monkeypatch.setenv("SCOPING_SUMMARY_AGENT_URL", "http://summary:1")
        assert Config.resolve_agent_base_url("preliminary_research_agent", "http://yaml") == "http://summary:1"
        monkeypatch.delenv("SCOPING_SUMMARY_AGENT_URL")
        assert Config.resolve_agent_base_url("preliminary_research_agent", "http://yaml") == "http://yaml"

    def test_no_fallback_uses_shared_url_and_tls_setter_syncs_env(self, monkeypatch):
        import os

        monkeypatch.setattr(Config, "AGENT_SERVICE_BASE_URL", "http://shared")
        assert Config.resolve_agent_base_url("x_agent") == "http://shared"
        assert Config.set_exclude_tls("yes") is True
        assert os.environ["SECURITY_EXCLUDE_TLS"] == "1"
        assert Config.set_exclude_tls(False) is False
        assert os.environ["SECURITY_EXCLUDE_TLS"] == "0"

    def test_noir_agent_id_aliases_resolve_correct_url(self, monkeypatch):
        monkeypatch.setenv("NOTIFICATION_NOIR_AGENT_URL", "http://notification-noir-agent.155081-1-cta.svc.cluster.local:4004")
        assert Config.resolve_agent_base_url("notification_noir_agent") == "http://notification-noir-agent.155081-1-cta.svc.cluster.local:4004"
        assert Config.resolve_agent_base_url("notification-noir-agent") == "http://notification-noir-agent.155081-1-cta.svc.cluster.local:4004"
        monkeypatch.delenv("NOTIFICATION_NOIR_AGENT_URL", raising=False)

    def test_nor_agent_id_aliases_resolve_correct_url(self, monkeypatch):
        monkeypatch.setenv("NOTIFICATION_NOR_AGENT_URL", "http://notification-nor-agent.155081-1-cta.svc.cluster.local:4005")
        assert Config.resolve_agent_base_url("notification_nor_agent") == "http://notification-nor-agent.155081-1-cta.svc.cluster.local:4005"
        assert Config.resolve_agent_base_url("notification-nor-agent") == "http://notification-nor-agent.155081-1-cta.svc.cluster.local:4005"
        monkeypatch.delenv("NOTIFICATION_NOR_AGENT_URL", raising=False)
