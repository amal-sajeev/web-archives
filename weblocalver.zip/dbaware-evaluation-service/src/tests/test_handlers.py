"""Unit tests for handler modules after refactoring."""

import asyncio
import importlib
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import HTTPException
from fastapi.responses import StreamingResponse

from handlers.agents import agent_target, list_agents
from handlers.captures import get_capture, list_captures
from handlers.evaluate import (
    evaluate, evaluate_stream, evaluate_stream_events,
    evaluate_streams, evaluate_cancel, _drive_run,
)
from handlers.health import health
from handlers.runs import (
    compare_runs, export_run, get_run, list_runs, promote_baselines,
)
from handlers.settings import runtime_settings, set_tls_policy
from core.models import EvaluateRequest
from core.run_manager import run_manager


# ============================================================================
# Health Handler Tests
# ============================================================================

def test_health_returns_ok_status(monkeypatch):
    """Test health check returns ok status."""
    mock_registry = MagicMock()
    mock_repo = MagicMock()
    mock_registry.list.return_value = [{"agent_id": "a1"}]
    health_module = importlib.import_module("handlers.health")
    monkeypatch.setattr(health_module, "require_vertex_credentials", lambda: "Credentials")
    monkeypatch.setattr(health_module.Config, "PROJECT_NAME", "demo-project")

    result = health(mock_registry, mock_repo)

    assert result["status"] == "ok"
    assert "version" in result
    assert "agents" in result


# ============================================================================
# Agents Handler Tests
# ============================================================================

def test_list_agents_returns_agent_list():
    """Test list_agents returns registry agents."""
    mock_registry = MagicMock()
    mock_registry.list_agents.return_value = [
        {"agent_id": "agent1", "name": "Agent 1"},
        {"agent_id": "agent2", "name": "Agent 2"},
    ]

    result = list_agents(mock_registry)

    assert result == {
        "agents": [
            {"agent_id": "agent1", "name": "Agent 1"},
            {"agent_id": "agent2", "name": "Agent 2"},
        ]
    }


def test_agent_target_returns_target_config():
    """Test agent_target returns agent config."""
    mock_registry = MagicMock()
    mock_registry.get.return_value = SimpleNamespace(
        config=SimpleNamespace(agent_id="test_agent", base_url="https://example.test"),
        dataset=SimpleNamespace(
            dataset_id="dataset-1",
            version="v1",
            target=SimpleNamespace(
                adapter="http",
                endpoint="/eval",
                method="POST",
                trust_env=False,
                timeout=30,
                headers={"Content-Type": "application/json"},
                auth={"type": "bearer"},
                response=SimpleNamespace(output_path="data.output", error_path="data.error"),
            ),
        ),
    )

    result = agent_target("test_agent", mock_registry)

    assert result["agent_id"] == "test_agent"
    assert result["adapter"] == "http"
    assert result["request_url"] == "https://example.test/eval"


def test_agent_target_raises_404_for_unknown_agent():
    """Test agent_target raises 404 for unknown agent."""
    mock_registry = MagicMock()
    mock_registry.get.side_effect = KeyError("Unknown agent 'unknown'")

    with pytest.raises(HTTPException) as exc_info:
        agent_target("unknown", mock_registry)

    assert exc_info.value.status_code == 404


# ============================================================================
# Evaluate Handler Tests
# ============================================================================

@pytest.mark.asyncio
async def test_evaluate_returns_run_dict():
    """Test evaluate returns completed run as dict."""
    mock_runner = MagicMock()
    mock_run = MagicMock()
    mock_run.model_dump.return_value = {"run_id": "123", "agent_id": "test"}
    mock_runner.evaluate = AsyncMock(return_value=mock_run)

    request = EvaluateRequest(
        agent_id="test",
        judge_repetitions=1,
        created_by="DEVELOPER"
    )

    result = await evaluate(request, mock_runner)

    assert result["run_id"] == "123"
    assert result["agent_id"] == "test"


def test_evaluate_streams_returns_stream_list():
    """Test evaluate_streams returns list of active streams."""
    # Create test streams
    run_manager._runs.clear()
    live1 = run_manager.create("agent1")
    live2 = run_manager.create("agent2")

    result = evaluate_streams()

    assert "streams" in result
    assert len(result["streams"]) == 2


def test_evaluate_stream_returns_status():
    """Test evaluate_stream returns an SSE response."""
    run_manager._runs.clear()
    live = run_manager.create("test_agent")
    live.publish({"type": "started"})

    class DummyRequest:
        async def is_disconnected(self):
            return False

    result = asyncio.run(evaluate_stream(live.stream_id, DummyRequest()))

    assert isinstance(result, StreamingResponse)
    assert result.media_type == "text/event-stream"


def test_evaluate_stream_raises_404_for_unknown_stream():
    """Test evaluate_stream raises 404 for unknown stream."""
    class DummyRequest:
        async def is_disconnected(self):
            return False

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(evaluate_stream("unknown", DummyRequest()))

    assert exc_info.value.status_code == 404


async def test_evaluate_stream_events_returns_events():
    """Test evaluate_stream_events returns events since index."""
    run_manager._runs.clear()
    live = run_manager.create("test_agent")
    live.publish({"type": "event1", "seq": 1})
    live.publish({"type": "event2", "seq": 2})
    live.publish({"type": "event3", "seq": 3})

    result = await evaluate_stream_events(live.stream_id, after=1)

    assert len(result["events"]) == 2
    assert result["seq"] == 3
    assert result["done"] is False


def test_evaluate_stream_events_includes_done_and_run_id():
    """Finished streams expose done state and final run_id for polling clients."""
    run_manager._runs.clear()
    live = run_manager.create("test_agent")
    live.publish({"type": "run_done", "run_id": "run-123", "status": "FAIL"})
    live.finish()

    result = asyncio.run(evaluate_stream_events(live.stream_id, after=0))

    assert result["done"] is True
    assert result["run_id"] == "run-123"


def test_drive_run_publishes_error_when_runner_fails_before_terminal_event():
    """Background runs should surface handler-level failures to polling clients."""
    run_manager._runs.clear()
    live = run_manager.create("test_agent")

    class BoomRunner:
        async def evaluate(self, *args, **kwargs):
            raise RuntimeError("kaboom")

    asyncio.run(_drive_run(live, "test_agent", None, 1, "DEVELOPER", BoomRunner()))

    assert live.done is True
    assert any(e.get("type") == "error" for e in live.events)
    err = next(e for e in live.events if e.get("type") == "error")
    assert err["status"] == 500
    assert err["error_type"] == "RuntimeError"
    assert "kaboom" not in err["detail"]
    assert "error_id=" in err["detail"]


def test_evaluate_cancel_cancels_task():
    """Test evaluate_cancel cancels running task."""
    run_manager._runs.clear()
    live = run_manager.create("test_agent")
    live.task = MagicMock()
    live.task.done.return_value = False

    result = asyncio.run(evaluate_cancel(live.stream_id))

    assert result["status"] == "cancel_requested"
    live.task.cancel.assert_called_once()


# ============================================================================
# Runs Handler Tests
# ============================================================================

def test_list_runs_returns_runs():
    """Test list_runs returns runs from repo."""
    mock_repo = MagicMock()
    mock_repo.list_runs.return_value = [
        {
            "run_id": "1", "agent_id": "agent1", "creation_ts": "2026-09-22T00:00:00Z",
            "case_count": 2, "passed_case_count": 1,
        },
        {
            "run_id": "2", "agent_id": "agent2", "creation_ts": "2026-09-22T00:00:01Z",
            "case_count": 1, "passed_case_count": 1,
        },
    ]

    result = list_runs(mock_repo)

    assert result["runs"][0]["case_count"] == 2
    assert result["runs"][0]["passed_case_count"] == 1
    assert result["runs"][1]["case_count"] == 1


def test_get_run_returns_run():
    """Test get_run returns single run."""
    mock_repo = MagicMock()
    mock_run = MagicMock()
    mock_run.model_dump.return_value = {"run_id": "123"}
    mock_repo.get_run.return_value = mock_run

    result = get_run(mock_repo, "123")

    assert result["run_id"] == "123"


def test_get_run_raises_404_for_missing_run():
    """Test get_run raises 404 when run not found."""
    mock_repo = MagicMock()
    mock_repo.get_run.return_value = None

    with pytest.raises(HTTPException) as exc_info:
        get_run(mock_repo, "unknown")

    assert exc_info.value.status_code == 404


def test_compare_runs_returns_comparison():
    """Test compare_runs returns comparison of two runs."""
    mock_repo = MagicMock()
    mock_run_a = SimpleNamespace(
        run_id="run_a",
        agent_id="agent1",
        weighted_score=0.8,
        weighted_delta=0.1,
        status="PASS",
        case_results=[SimpleNamespace(case_id="c1", weighted_score=0.8, passed=True, weighted_delta=0.1)],
    )
    mock_run_b = SimpleNamespace(
        run_id="run_b",
        agent_id="agent1",
        weighted_score=0.9,
        weighted_delta=0.2,
        status="PASS",
        case_results=[SimpleNamespace(case_id="c1", weighted_score=0.9, passed=True, weighted_delta=0.2)],
    )
    mock_repo.get_run.side_effect = [mock_run_a, mock_run_b]

    result = compare_runs(mock_repo, "run_a", "run_b")

    assert result["a"]["run_id"] == "run_a"
    assert result["b"]["run_id"] == "run_b"


def test_export_run_csv_returns_csv_content():
    """Test export_run with CSV format."""
    mock_repo = MagicMock()
    mock_run = SimpleNamespace(
        case_results=[
            SimpleNamespace(
                case_id="c1",
                passed=True,
                weighted_score=0.9,
                weighted_delta=0.1,
                scores=[SimpleNamespace(metric="m1", score=0.9, threshold=0.8, passed=True, critical=False, rationale="ok", baseline=0.8)],
            )
        ],
        weighted_score=0.9,
        weighted_delta=0.1,
        status="PASS",
        creation_ts="2026-09-22T00:00:00Z",
        created_by="DEVELOPER",
        agent_id="agent1",
        dataset_id="dataset1",
        dataset_version="v1",
    )
    mock_repo.get_run.return_value = mock_run

    result = export_run(mock_repo, "123", "csv")

    assert result.media_type == "text/csv"


def test_promote_baselines_persists_baseline():
    """Test promote_baselines updates repository."""
    mock_repo = MagicMock()
    mock_run = SimpleNamespace(
        run_id="123",
        agent_id="agent1",
        dataset_id="dataset1",
        dataset_version="v1",
        created_by="DEVELOPER",
        status="PASS",
        case_results=[
            SimpleNamespace(scores=[SimpleNamespace(metric="faithfulness", score=0.8)]),
            SimpleNamespace(scores=[SimpleNamespace(metric="faithfulness", score=1.0)]),
        ],
    )
    mock_repo.get_run.return_value = mock_run
    mock_log = MagicMock()

    result = promote_baselines(mock_repo, "123", mock_log)

    assert result["run_id"] == "123"
    assert result["promoted"][0]["metric"] == "faithfulness"
    mock_repo.set_baseline.assert_called_once()


# ============================================================================
# Captures Handler Tests
# ============================================================================

def test_list_captures_returns_captures():
    """Test list_captures returns all captures, including agent_id when unfiltered."""
    captures_module = importlib.import_module("handlers.captures")
    from collections import OrderedDict
    monkeypatch = pytest.MonkeyPatch()
    # Mock _by_key to simulate store contents: {(agent_id, case_id): payload}
    mock_store = OrderedDict([
        ((None, "c1"), {}),
        (("agent-1", "c2"), {}),
    ])
    monkeypatch.setattr(captures_module.capture_store, "_by_key", mock_store)
    result = list_captures()
    monkeypatch.undo()

    assert len(result["captures"]) == 2
    assert result["captures"][0] == {"agent_id": None, "case_id": "c1", "payload": {}}
    assert result["captures"][1] == {"agent_id": "agent-1", "case_id": "c2", "payload": {}}


def test_get_capture_returns_capture():
    """Test get_capture returns single capture."""
    captures_module = importlib.import_module("handlers.captures")
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(captures_module.capture_store, "get", lambda case_id, agent_id=None: {"data": "test"} if case_id == "c1" else None)
    result = get_capture("c1")
    monkeypatch.undo()

    assert result["case_id"] == "c1"


def test_get_capture_raises_404_for_missing():
    """Test get_capture raises 404 when not found."""
    with pytest.raises(HTTPException) as exc_info:
        get_capture("unknown")

    assert exc_info.value.status_code == 404


# ============================================================================
# Settings Handler Tests
# ============================================================================

def test_runtime_settings_returns_config():
    """Test runtime_settings returns current config."""
    result = runtime_settings()

    assert "exclude_tls" in result
    assert "tls_verification_enabled" in result


def test_set_tls_policy_updates_config():
    """Test set_tls_policy updates TLS setting."""
    result = set_tls_policy({"enabled": True})

    assert result["exclude_tls"] is False
    assert result["tls_verification_enabled"] is True
