"""Agent registry: validation, tolerant loading, lookups."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from core.models import AgentConfig, Dataset, GoldenCase, MetricSpec
from core_helpers import capture_logs
from registry import RegisteredAgent, Registry


def _registry_with(dataset: Dataset) -> Registry:
    reg = Registry()
    reg._agents = {
        "test": RegisteredAgent(folder=Path("."), config=AgentConfig(agent_id="test", name="Test"), dataset=dataset)
    }
    return reg


def _write_agent(root: Path, folder: str, agent_id: str, scorer: str = "contains", cases: int = 1) -> None:
    d = root / folder
    d.mkdir()
    (d / "agent.yaml").write_text(f"agent_id: {agent_id}\nname: {agent_id}\n", encoding="utf-8")
    (d / "dataset.json").write_text(json.dumps({
        "dataset_id": f"{agent_id}-ds", "version": "1",
        "metrics": [{"name": "m", "type": "deterministic", "scorer": scorer}],
        "cases": [{"id": f"c{i}", "input": {}} for i in range(cases)],
    }), encoding="utf-8")


class TestRegistryValidation:
    def test_validate_catches_unknown_scorer(self):
        reg = _registry_with(Dataset(
            dataset_id="test", version="1.0",
            metrics=[MetricSpec(name="m", type="deterministic", scorer="nonexistent_scorer")],
            cases=[GoldenCase(id="c1", input={})],
        ))
        with pytest.raises(ValueError, match="unknown scorer 'nonexistent_scorer'"):
            reg.validate()

    def test_validate_catches_empty_cases(self):
        reg = _registry_with(Dataset(
            dataset_id="test", version="1.0",
            metrics=[MetricSpec(name="m", type="deterministic", scorer="contains")], cases=[],
        ))
        with pytest.raises(ValueError, match="dataset has no cases"):
            reg.validate()

    def test_validate_passes_with_valid_config(self):
        reg = _registry_with(Dataset(
            dataset_id="test", version="1.0",
            metrics=[MetricSpec(name="m", type="deterministic", scorer="contains", config={"terms": ["hello"]})],
            cases=[GoldenCase(id="c1", input={"q": "hello world"})],
        ))
        reg.validate()  # should not raise


class TestRegistryLoading:
    def test_broken_and_invalid_agents_are_skipped(self, tmp_path):
        _write_agent(tmp_path, "good", "good")
        _write_agent(tmp_path, "bad_scorer", "bad_scorer", scorer="nope_scorer")
        broken = tmp_path / "broken"
        broken.mkdir()
        (broken / "agent.yaml").write_text("agent_id: broken\nname: B\n", encoding="utf-8")
        (broken / "dataset.json").write_text("{not json", encoding="utf-8")

        with capture_logs("eval_service.registry") as records:
            reg = Registry(tmp_path).load()

        assert reg.has("good")
        assert not reg.has("broken") and not reg.has("bad_scorer")
        messages = " ".join(r.getMessage() for r in records)
        assert "broken" in messages and "nope_scorer" in messages

    def test_duplicate_agent_id_warns_and_last_wins(self, tmp_path):
        _write_agent(tmp_path, "a_first", "dup", cases=1)
        _write_agent(tmp_path, "b_second", "dup", cases=2)
        with capture_logs("eval_service.registry") as records:
            reg = Registry(tmp_path).load()
        assert len(reg.get("dup").dataset.cases) == 2
        assert any("duplicate agent_id" in r.getMessage() for r in records)

    def test_reload_swaps_the_agent_map(self, tmp_path):
        _write_agent(tmp_path, "one", "one")
        reg = Registry(tmp_path).load()
        before = reg._agents
        _write_agent(tmp_path, "two", "two")
        reg.load()
        assert reg._agents is not before
        assert reg.has("two") and "two" not in before

    def test_missing_agents_dir_loads_empty(self, tmp_path):
        assert Registry(tmp_path / "nope").load().list_agents() == []


class TestRegistryLookups:
    def test_list_agents_hides_disabled_and_list_is_deprecated_alias(self, tmp_path):
        _write_agent(tmp_path, "alpha", "alpha")
        reg = Registry(tmp_path).load()
        reg.get("alpha").config.enabled = False
        assert reg.list_agents() == []
        assert reg.has("alpha")
        reg.get("alpha").config.enabled = True
        with pytest.warns(DeprecationWarning):
            assert reg.list() == reg.list_agents()

    def test_list_agents_include_disabled_puts_them_last(self, tmp_path):
        for folder in ("a_off", "b_on", "c_on"):
            _write_agent(tmp_path, folder, folder)
        reg = Registry(tmp_path).load()
        reg.get("a_off").config.enabled = False
        assert [(a["agent_id"], a["enabled"]) for a in reg.list_agents()] == [("b_on", True), ("c_on", True)]
        rows = reg.list_agents(include_disabled=True)
        assert [(a["agent_id"], a["enabled"]) for a in rows] == [("b_on", True), ("c_on", True), ("a_off", False)]
        assert set(rows[0]) == {
            "agent_id", "name", "version", "description", "dataset_id", "dataset_version",
            "cases", "metrics", "active_metrics", "enabled",
        }

    def test_get_unknown_agent_raises_key_error(self):
        with pytest.raises(KeyError, match="Unknown agent"):
            Registry().get("missing")


class TestFolderLoading:
    def test_folders_without_agent_yaml_are_ignored(self, tmp_path):
        (tmp_path / "notes").mkdir()
        _write_agent(tmp_path, "real", "real_agent")
        reg = Registry(tmp_path).load()
        assert [a["agent_id"] for a in reg.list_agents()] == ["real_agent"]
        assert reg.get("real_agent").metrics_stub_path == tmp_path / "real" / "metrics_stub.json"

    def test_custom_tests_register_scorers(self, tmp_path):
        from scorers.base import restore_scorers, snapshot_scorers

        _write_agent(tmp_path, "custom", "custom_agent", scorer="tmp_registry_custom")
        (tmp_path / "custom" / "custom_tests.py").write_text(
            "from scorers import scorer\n\n"
            "@scorer('tmp_registry_custom')\n"
            "def _s(**_):\n    return 1.0, '', []\n",
            encoding="utf-8",
        )
        snap = snapshot_scorers()
        try:
            assert Registry(tmp_path).load().has("custom_agent")
        finally:
            restore_scorers(snap)

    def test_unloadable_custom_tests_skip_the_agent_with_a_log(self, tmp_path, monkeypatch):
        import importlib.util

        _write_agent(tmp_path, "custom", "custom_agent")
        (tmp_path / "custom" / "custom_tests.py").write_text("x = 1\n", encoding="utf-8")
        monkeypatch.setattr(importlib.util, "spec_from_file_location", lambda *a, **kw: None)
        with capture_logs("eval_service.registry") as records:
            reg = Registry(tmp_path).load()
        assert not reg.has("custom_agent")
        assert any("failed to load agent folder" in r.getMessage() for r in records)


def _write_disabled_agent(root: Path, agent_id: str) -> None:
    _write_agent(root, agent_id, agent_id)
    cfg = root / agent_id / "agent.yaml"
    cfg.write_text(cfg.read_text(encoding="utf-8") + "enabled: false\n", encoding="utf-8")


class TestEnableAgentsOverride:
    def test_named_disabled_agent_is_enabled_without_touching_yaml(self, tmp_path, monkeypatch):
        for agent_id in ("sample_a", "sample_b"):
            _write_disabled_agent(tmp_path, agent_id)
        monkeypatch.setattr("core.config.Config.ENABLE_AGENTS", frozenset({"sample_a"}))

        reg = Registry(tmp_path).load()

        assert [a["agent_id"] for a in reg.list_agents()] == ["sample_a"]
        assert "enabled: false" in (tmp_path / "sample_a" / "agent.yaml").read_text(encoding="utf-8")

    def test_star_enables_every_agent(self, tmp_path, monkeypatch):
        for agent_id in ("sample_a", "sample_b"):
            _write_disabled_agent(tmp_path, agent_id)
        monkeypatch.setattr("core.config.Config.ENABLE_AGENTS", frozenset({"*"}))

        assert {a["agent_id"] for a in Registry(tmp_path).load().list_agents()} == {"sample_a", "sample_b"}

    def test_no_override_keeps_disabled_agents_hidden(self, tmp_path, monkeypatch):
        _write_disabled_agent(tmp_path, "sample_a")
        monkeypatch.setattr("core.config.Config.ENABLE_AGENTS", frozenset())

        assert Registry(tmp_path).load().list_agents() == []
