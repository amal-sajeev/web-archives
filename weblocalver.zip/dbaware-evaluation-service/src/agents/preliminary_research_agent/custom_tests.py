"""Custom scorers for preliminary_research_agent.

The endpoint returns a top-level plan_number and an analysis_report bundle with
three report objects (for example additionalProp1..3). This module validates
that the response is structural, citation-backed, and not merely a schema
placeholder filled with literal "string" values.
"""

from __future__ import annotations

import json
from typing import Any

from scorers.base import scorer

NO_PARAGRAPHS = "no paragraphs found"
DEFAULT_REPORT_COUNT = 3
_CITATION_KEYS = ("chunk_id", "page_number", "gs_uri", "document_name", "content_type")
_EXEMPT_CITATION_STATUSES = {"unsupported", "not_required", "not_applicable", "na", "n/a"}


def _is_number(value: Any) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _as_list(value: Any) -> list[Any]:
    """Wrap a scalar (notably a string) in a list; None becomes empty."""
    if value is None:
        return []
    if isinstance(value, list | tuple):
        return list(value)
    return [value]


def _output(observation) -> Any:
    out = observation.output
    if isinstance(out, str):
        try:
            return json.loads(out)
        except Exception:
            return {}
    return out if isinstance(out, dict) else {}


def _bundle(observation) -> dict[str, Any]:
    out = _output(observation)
    bundle = out.get("analysis_report") if isinstance(out, dict) else None
    return bundle if isinstance(bundle, dict) else {}


def _reports(observation) -> list[dict[str, Any]]:
    return [value for value in _bundle(observation).values() if isinstance(value, dict)]


def _not_placeholder(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    text = value.strip()
    return bool(text) and text.lower() != "string"


def _citation_ok(paragraph: dict[str, Any]) -> bool:
    """A paragraph's citations are consistent: both lists present, both empty, or
    every citation carries the keys a consumer needs to resolve it."""
    chunk_ids = paragraph.get("supporting_chunk_ids")
    citations = paragraph.get("supporting_citations")
    if not isinstance(chunk_ids, list) or not isinstance(citations, list):
        return False
    if not chunk_ids and not citations:
        return True
    if not chunk_ids or not citations:
        return False
    return all(isinstance(c, dict) and all(key in c for key in _CITATION_KEYS) for c in citations)


@scorer("output_not_empty")
def output_not_empty(*, observation, case, **_):
    """Check if output is not empty."""
    out = _output(observation)
    is_empty = not out or (isinstance(out, dict) and len(out) == 0)
    score = 0.0 if is_empty else 1.0
    evidence = ["output is empty" if is_empty else "output contains data"]
    return score, "output not empty" if score == 1.0 else "output is empty", evidence


@scorer("preliminary_research_schema_valid")
def preliminary_research_schema_valid(*, observation, case, **_):
    """Check if output matches preliminary research schema."""
    out = _output(observation)
    
    # Check for required top-level fields
    has_plan_number = "plan_number" in out and isinstance(out.get("plan_number"), str)
    has_analysis_report = "analysis_report" in out and isinstance(out.get("analysis_report"), dict)
    
    if not (has_plan_number and has_analysis_report):
        return 0.0, "missing required fields (plan_number, analysis_report)", [
            f"{'✓' if has_plan_number else '✗'} plan_number present and is string",
            f"{'✓' if has_analysis_report else '✗'} analysis_report present and is dict"
        ]
    
    # Check if analysis_report has report objects with required structure
    analysis_report = out.get("analysis_report", {})
    valid_reports = 0
    evidence = []
    
    for report_key, report_value in analysis_report.items():
        if isinstance(report_value, dict):
            has_title = "report_title" in report_value and isinstance(report_value.get("report_title"), str)
            has_paragraphs = "paragraphs" in report_value and isinstance(report_value.get("paragraphs"), list)
            
            is_valid = has_title and has_paragraphs
            if is_valid:
                valid_reports += 1
                evidence.append(f"✓ {report_key} has valid structure")
            else:
                evidence.append(f"✗ {report_key} missing required fields")
    
    score = valid_reports / max(len(analysis_report), 1) if analysis_report else 0.0
    return score, f"{valid_reports} report(s) with valid schema", evidence


@scorer("response_success")
def response_success(*, observation, case, **_):
    """Check if the agent response was successful (HTTP 200 or equivalent)."""
    # Check if observation has an output (successful execution)
    success = observation.output is not None and observation.output != ""
    score = 1.0 if success else 0.0
    evidence = ["response successful" if success else "response failed or empty"]
    return score, "response successful" if score == 1.0 else "response failed", evidence


def _paragraphs(report: dict[str, Any]) -> list[dict[str, Any]]:
    paragraphs = report.get("paragraphs")
    if not isinstance(paragraphs, list):
        return []
    return [item for item in paragraphs if isinstance(item, dict)]


def _all_paragraphs(observation) -> list[dict[str, Any]]:
    paragraphs: list[dict[str, Any]] = []
    for report in _reports(observation):
        paragraphs.extend(_paragraphs(report))
    return paragraphs


@scorer("analysis_paragraph_structure_valid")
def analysis_paragraph_structure_valid(*, observation, case, **_):
    paragraphs = _all_paragraphs(observation)
    if not paragraphs:
        return 0.0, NO_PARAGRAPHS, []
    valid = 0
    evidence = []
    for paragraph in paragraphs:
        keys = ["paragraph_id", "content", "supporting_chunk_ids", "supporting_citations", "rationale", "metadata"]
        has_keys = all(key in paragraph for key in keys)
        has_strings = all(_not_placeholder(paragraph.get(key)) for key in ["paragraph_id", "content", "rationale"])
        good = has_keys and has_strings and _citation_ok(paragraph)
        valid += 1 if good else 0
        if not good:
            evidence.append(f"✗ invalid paragraph {paragraph.get('paragraph_id', '<missing>')!r}")
    score = valid / len(paragraphs)
    return score, f"{valid}/{len(paragraphs)} paragraphs structurally valid", evidence


@scorer("analysis_citation_grounding")
def analysis_citation_grounding(*, observation, case, **_):
    paragraphs = _all_paragraphs(observation)
    if not paragraphs:
        return 0.0, NO_PARAGRAPHS, []

    valid = 0
    evidence = []
    for paragraph in paragraphs:
        status = str(paragraph.get("citation_status", "")).lower()
        ok = status in _EXEMPT_CITATION_STATUSES or _citation_ok(paragraph)
        valid += 1 if ok else 0
        if not ok:
            evidence.append(f"✗ citation gap in {paragraph.get('paragraph_id', '<missing>')!r}")

    score = valid / len(paragraphs)
    return score, f"{valid}/{len(paragraphs)} paragraphs citation-grounded", evidence


@scorer("analysis_metadata_valid")
def analysis_metadata_valid(*, observation, case, **_):
    paragraphs = _all_paragraphs(observation)
    if not paragraphs:
        return 0.0, NO_PARAGRAPHS, []
    valid = 0
    evidence = []
    for paragraph in paragraphs:
        metadata = paragraph.get("metadata")
        conf = metadata.get("section_confidence_score") if isinstance(metadata, dict) else None
        good = (
            isinstance(metadata, dict)
            and isinstance(metadata.get("is_section_start"), bool)
            and _is_number(conf)
            and 0 <= conf <= 100
        )
        valid += 1 if good else 0
        if not good:
            evidence.append(f"✗ invalid metadata in {paragraph.get('paragraph_id', '<missing>')!r}")
    score = valid / len(paragraphs)
    return score, f"{valid}/{len(paragraphs)} paragraphs have valid metadata", evidence


@scorer("analysis_rationale_valid")
def analysis_rationale_valid(*, observation, case, **_):
    paragraphs = _all_paragraphs(observation)
    if not paragraphs:
        return 0.0, NO_PARAGRAPHS, []
    valid = 0
    evidence = []
    for paragraph in paragraphs:
        rationale = paragraph.get("rationale")
        good = _not_placeholder(rationale)
        valid += 1 if good else 0
        if not good:
            evidence.append(f"✗ empty rationale in {paragraph.get('paragraph_id', '<missing>')!r}")
    score = valid / len(paragraphs)
    return score, f"{valid}/{len(paragraphs)} paragraphs have rationale", evidence


@scorer("plan_number_valid")
def plan_number_valid(*, observation, case, **_):
    out = _output(observation)
    observed = str(out.get("plan_number", "")) if isinstance(out, dict) else ""
    expected = str((case.input or {}).get("planNumber", ""))
    good = observed == expected and _not_placeholder(observed)
    evidence = [f"observed={observed!r}", f"expected={expected!r}"]
    return (1.0 if good else 0.0), "plan number matches input" if good else "plan number mismatch", evidence


@scorer("analysis_expected_values_present")
def analysis_expected_values_present(*, observation, case, **_):
    expected_values = _as_list((case.expected or {}).get("expected_values"))
    if not expected_values:
        return 1.0, "no expected_values configured", []
    text = json.dumps(_output(observation), ensure_ascii=False).lower()
    present = [value for value in expected_values if str(value).lower() in text]
    evidence = [f"{'✓' if value in present else '✗'} {value}" for value in expected_values]
    score = len(present) / len(expected_values)
    return score, f"{len(present)}/{len(expected_values)} expected values present", evidence


@scorer("analysis_bundle_present")
def analysis_bundle_present(*, observation, case, **_):
    """Score how many analysis reports are present against the expected count.

    expected.report_count overrides DEFAULT_REPORT_COUNT; a non-integer value
    (e.g. a typo like "three") falls back to the default rather than crashing.
    """
    bundle = _bundle(observation)
    present = len(bundle) if isinstance(bundle, dict) else 0
    raw_count = (case.expected or {}).get("report_count")
    expected_count = raw_count if isinstance(raw_count, int) and not isinstance(raw_count, bool) else DEFAULT_REPORT_COUNT
    if expected_count <= 0:
        expected_count = DEFAULT_REPORT_COUNT
    score = min(present / expected_count, 1.0)
    evidence = [f"analysis_report bundle has {present} report(s)"]
    return score, f"{present}/{expected_count} analysis reports present", evidence


@scorer("analysis_report_titles_valid")
def analysis_report_titles_valid(*, observation, case, **_):
    """Check if all reports have valid report_title fields."""
    reports = _reports(observation)
    if not reports:
        return 0.0, "no reports found", []
    valid = 0
    evidence = []
    for idx, report in enumerate(reports):
        title = report.get("report_title", "")
        has_valid_title = isinstance(title, str) and _not_placeholder(title)
        if has_valid_title:
            valid += 1
            evidence.append(f"✓ report {idx} has valid title")
        else:
            evidence.append(f"✗ report {idx} missing or placeholder title")
    score = valid / len(reports)
    return score, f"{valid}/{len(reports)} reports have valid titles", evidence


@scorer("analysis_paragraphs_valid")
def analysis_paragraphs_valid(*, observation, case, **_):
    """Check if all reports contain valid paragraph lists."""
    reports = _reports(observation)
    if not reports:
        return 0.0, "no reports found", []
    valid = 0
    evidence = []
    for idx, report in enumerate(reports):
        paragraphs = report.get("paragraphs", [])
        has_valid_paragraphs = isinstance(paragraphs, list) and len(paragraphs) > 0
        if has_valid_paragraphs:
            valid += 1
            evidence.append(f"✓ report {idx} has {len(paragraphs)} paragraph(s)")
        else:
            evidence.append(f"✗ report {idx} missing or empty paragraphs")
    score = valid / len(reports)
    return score, f"{valid}/{len(reports)} reports have valid paragraphs", evidence