"""Agent-specific (custom) scorers for the scope_extraction agent.

Dropped into the agent folder and auto-imported by the registry at startup. The
@scorer decorator registers the function under a name that dataset.json can then
reference. This is the extension point for bespoke, per-agent tests.

Every scorer here reads the plan fields through :func:`_plan_details`, because
the agent returns them nested under ``data.plan_details`` -- never at the root.
"""

from __future__ import annotations

import json

from scorers._util import config_int, spec_config
from scorers.base import MetricSkipped, scorer

# Fields a current_details artifact must carry for downstream scoping to work.
_REQUIRED_FIELDS = (
    "Plan Item Number",
    "Plan Item Title",
    "Plan Item Focus (AFC/CT)",
    "Lead Regional/Functional Head",
    "Plan Year",
    "Mandatory Review",
)
_VALID_STATUSES = ("Completed", "In Progress", "Not Started", "On Hold")
_VALID_FOCUSES = ("Compliance", "Operational Risk", "Strategic")
_MIN_PLAN_YEAR, _MAX_PLAN_YEAR = 2020, 2030
# Default minimum serialized length of a meaningful artifact; dataset.json can
# override it per metric via ``config.min_length``.
_DEFAULT_MIN_LENGTH = 1000
_PLACEHOLDER_MARKERS = ("test", "dummy", "example", "sample", "fake", "lorem", "placeholder", "todo")
_NUMERIC_FIELDS = ("Plan Item Number", "Plan Year")


def _as_dict(value):
    """Parse ``value`` into a dict, accepting a JSON string; ``{}`` otherwise."""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            return {}
    return value if isinstance(value, dict) else {}


def _plan_details(observation):
    """The ``data.plan_details`` map from the agent output.

    Agent output shape::

        {"data": {"plan_details": {...}}, "source": ..., "artifact": ...,
         "plan_number": ...}

    A response that is not JSON, or that carries no ``data.plan_details``,
    cannot be assessed, so the metric is skipped rather than scored 0.0 -- a 0.0
    would read as "the agent returned bad plan data" instead of "the response
    shape is unrecognised".
    """
    output = _as_dict(observation.output)
    if not output:
        raise MetricSkipped("agent output is not a JSON object")
    details = _as_dict(output.get("data")).get("plan_details")
    if not isinstance(details, dict):
        raise MetricSkipped("agent output has no 'data.plan_details' object")
    return details


def _present(value) -> bool:
    """True when a field carries a real value (not absent, empty, or the text "null")."""
    return bool(value is not None and str(value).strip() and str(value).strip().lower() != "null")


def _field_present(observation, field: str, label: str):
    details = _plan_details(observation)
    value = details.get(field)
    ok = _present(value)
    rationale = f"{label} present" if ok else f"missing or empty {field}"
    return (1.0 if ok else 0.0), rationale, [f"{field}={value!r}"]


@scorer("artifact_title_present")
def artifact_title_present(*, observation, case, metrics=None, **_):
    """The extracted artifact must include a meaningful plan title."""
    return _field_present(observation, "Plan Item Title", "plan title")


@scorer("lead_head_present")
def lead_head_present(*, observation, case, metrics=None, **_):
    """The extracted artifact must include a lead regional/functional head."""
    return _field_present(observation, "Lead Regional/Functional Head", "lead owner")


@scorer("focus_present")
def focus_present(*, observation, case, metrics=None, **_):
    """The extracted artifact must include an explicit focus classification."""
    return _field_present(observation, "Plan Item Focus (AFC/CT)", "focus")


@scorer("mandatory_review_field")
def mandatory_review_field(*, observation, case, metrics=None, **_):
    """The extracted artifact must include a Mandatory Review field."""
    return _field_present(observation, "Mandatory Review", "mandatory review field")


@scorer("response_length")
def response_length(*, observation, case, metrics=None, spec=None, **_):
    """Serialized artifact size measured against a floor.

    config:
      min_length: int -- characters expected of a complete artifact (default 1000).

    Scores 1.0 at or above ``min_length`` and degrades linearly to 0.0 for an
    empty response, so a truncated artifact is penalised in proportion to how
    much is missing rather than falling off a fixed cliff.
    """
    minimum = config_int(spec_config(spec), "min_length", _DEFAULT_MIN_LENGTH)
    if minimum <= 0:
        raise MetricSkipped(f"config error: 'min_length' must be positive, got {minimum}")
    output = observation.output
    text = json.dumps(output, ensure_ascii=False, default=str) if isinstance(output, dict) else str(output)
    length = len(text)
    score = min(1.0, length / minimum)
    if score >= 1.0:
        rationale = f"artifact is {length} chars (>= {minimum} expected)"
    else:
        rationale = f"artifact is only {length} chars of the {minimum} expected"
    return score, rationale, [f"content_length={length}", f"min_length={minimum}"]


@scorer("hallucination_detection")
def hallucination_detection(*, observation, case, metrics=None, **_):
    """Flag placeholder or test data standing in for real plan metadata."""
    details = _plan_details(observation)
    title = str(details.get("Plan Item Title") or "")
    plan_num = details.get("Plan Item Number")

    lowered = title.lower()
    suspicious = [f"marker '{m}' in Plan Item Title" for m in _PLACEHOLDER_MARKERS if m in lowered]
    if suspicious:
        return 0.3, "placeholder markers found in plan metadata", suspicious
    if not (_present(title) and _present(plan_num)):
        return 0.5, "plan identity fields too sparse to judge", [
            f"title={title!r}",
            f"plan_number={plan_num!r}",
        ]
    return 1.0, "no placeholder or fabricated-looking plan metadata", []


@scorer("structured_accuracy")
def structured_accuracy(*, observation, case, metrics=None, spec=None, **_):
    """Share of the configured plan_details fields that are present and populated.

    config:
      fields: [str, ...] -- plan_details field names to check (defaults to the
        required-artifact set).
    """
    fields = spec_config(spec).get("fields") or list(_REQUIRED_FIELDS)
    if not isinstance(fields, list) or not all(isinstance(f, str) for f in fields):
        raise MetricSkipped("config error: 'fields' must be a list of field names")
    details = _plan_details(observation)
    evidence, present = [], 0
    for field in fields:
        ok = _present(details.get(field))
        present += int(ok)
        evidence.append(f"{'+' if ok else '-'} {field}={details.get(field)!r}")
    return present / len(fields), f"{present}/{len(fields)} configured fields populated", evidence


def _year_issues(year, status) -> list[str]:
    try:
        year_int = int(year)
    except (TypeError, ValueError):
        return [f"Plan Year is not numeric: {year!r}"]
    if not _MIN_PLAN_YEAR <= year_int <= _MAX_PLAN_YEAR:
        return [f"Plan Year {year_int} outside {_MIN_PLAN_YEAR}-{_MAX_PLAN_YEAR}"]
    if year_int >= 2026 and status == "Completed":
        return [f"Plan Year {year_int} is in the future but status is Completed"]
    return []


@scorer("semantic_consistency")
def semantic_consistency(*, observation, case, metrics=None, **_):
    """Field values must be internally coherent (known status/focus, sane year)."""
    details = _plan_details(observation)
    issues: list[str] = []

    plan_num = details.get("Plan Item Number")
    if _present(plan_num) and len(str(plan_num).strip()) < 2:
        issues.append(f"plan number too short: {plan_num!r}")

    status = details.get("Plan Item Status")
    if _present(status) and status not in _VALID_STATUSES:
        issues.append(f"unexpected status: {status!r}")

    focus = details.get("Plan Item Focus (AFC/CT)")
    if _present(focus) and focus not in _VALID_FOCUSES:
        issues.append(f"unexpected focus: {focus!r}")

    mandatory = details.get("Mandatory Review")
    if _present(mandatory) and str(mandatory) not in ("Yes", "No"):
        issues.append(f"Mandatory Review is not Yes/No: {mandatory!r}")

    year = details.get("Plan Year")
    if _present(year):
        issues.extend(_year_issues(year, status))

    if not _present(details.get("Lead Regional/Functional Head")):
        issues.append("no lead assigned")

    if issues:
        return max(0.0, 1.0 - 0.2 * len(issues)), "; ".join(issues), issues
    return 1.0, "field values are internally consistent", ["consistency_ok"]


@scorer("artifact_schema_valid")
def artifact_schema_valid_custom(*, observation, case, metrics=None, **_):
    """plan_details must carry every required field with a usable scalar type."""
    details = _plan_details(observation)

    missing = [f for f in _REQUIRED_FIELDS if f not in details]
    if missing:
        return 0.0, f"missing required fields: {missing}", [f"missing={missing}"]

    issues: list[str] = []
    for field in _REQUIRED_FIELDS:
        value = details.get(field)
        if value is None:
            continue  # present but null: a schema-valid "unknown"
        allowed = (str, int, float) if field in _NUMERIC_FIELDS else (str,)
        if isinstance(value, bool) or not isinstance(value, allowed):
            names = "/".join(t.__name__ for t in allowed)
            issues.append(f"{field} should be {names}, got {type(value).__name__}")

    if issues:
        return 0.8, "; ".join(issues), issues
    return 1.0, "artifact schema valid", [f"{len(_REQUIRED_FIELDS)} required fields present"]
