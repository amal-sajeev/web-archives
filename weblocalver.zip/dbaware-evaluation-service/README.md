# CTNA Evaluation Service

A separately-hosted **agent evaluation service** (LLM-as-a-judge). It scores
production agents against a versioned **golden set** using both **objective
(deterministic)** checks and **LLM-based** judges, computes a weighted pass/fail
gate plus a **weighted delta** to trend metric drift over time, and persists runs
to SQL. It can be driven directly by a human (browser dashboard) or by a CI/CD
pipeline (one REST call, non-zero exit on failure).

See [docs/EVAL_SERVICE_DESIGN.md](docs/EVAL_SERVICE_DESIGN.md) for the full design
and [docs/VERTEX_INTEGRATION.md](docs/VERTEX_INTEGRATION.md) for the Vertex judge
pattern.

## Layout

```
src/main/              FastAPI app, runner, scorers, adapters, repository, UI
src/tests/             pytest suite (unit + scorer coverage)
src/agents/<id>/       one folder per evaluated agent (config + golden set + tests)
src/sample_agents/     runnable stub agents for offline demos
scripts/               start_local*.ps1 / setup_local.ps1 (local), run_eval_service.ps1, ci_gate.py
```

## Setup

Create a virtual environment and install dependencies:

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r src/main/requirements.txt
```

If your environment requires a private package index, configure `pip` or pass
`--index-url` per your organisation's standards.

Configuration comes from env vars or, with `ENV_NAME` set, from
`src/main/config/{ENV_NAME}/environment.yaml` -- no `.env` file is read (see
[src/main/config/README.md](src/main/config/README.md)). For the LLM judge, set
`PROJECT_NAME` / `PROJECT_LOCATION` and sign in:

```powershell
$env:PROJECT_NAME = "my-vertex-project"
$env:PROJECT_LOCATION = "us-central1"
gcloud auth application-default login
```

Without those, judge-backed checks skip and everything else still runs.

## Run locally (quick start)

On a new machine, set up once (creates `.venv` with the pinned requirements; needs
Python 3.11+):

```powershell
.\scripts\setup_local.ps1
```

Then either:

```powershell
# Service only, on http://127.0.0.1:4002 with SQLite (eval_service.db in this folder)
.\scripts\start_local.ps1 -Open

# Service + all four sample agents (:4010-4013), shown in the dashboard for testing
.\scripts\start_local_all.ps1 -Open
```

- **Stop:** press Ctrl+C. `start_local_all.ps1` also stops the agents it started. If a window was closed without Ctrl+C, run `.\scripts\stop_local.ps1` to free the ports.
- **Options:** `-Port <n>` and `-Db <path>`. Use `-Db` to keep test runs out of `eval_service.db`, e.g. `-Db C:\temp\scratch.db`.
- **Database:** an `EVAL_DB_URL` already set in your shell takes precedence over the local SQLite default.
- **Agent logs:** `%TEMP%\dbaware-eval-local\`.
- **Sample agents:** they ship with `enabled: false` in their `agent.yaml`. `start_local_all.ps1` shows them for that run by setting `EVAL_ENABLE_AGENTS` (a comma-separated list of agent ids, or `*` for all); the YAML files are not changed.
- **AI reviewer:** checks that need it are skipped without Vertex credentials; everything else runs offline.

## Run (corporate network / CloudSQL)

1. Start the evaluation target agent on `:4000`.
2. Start this service:

   ```powershell
   .\scripts\run_eval_service.ps1
   ```

  The launcher defaults `EVAL_DB_URL` to CloudSQL (`postgresql://`). If the
  CloudSQL connection/init fails, the service automatically falls back to local
  SQLite (`eval_service.db`) so local config testing still works.

3. Open http://localhost:4002 for the dashboard, or check wiring:

   ```powershell
   curl http://localhost:4002/api/health
   ```

  The health response includes the current service `version` so you can
  confirm which build is active in a deployed environment.

  The Helm chart `appVersion` should be kept in sync with the service version
  whenever a new commit is deployed.

  Set `EVAL_EXCLUDE_TLS=1` if the eval service needs to reach internal HTTPS
  endpoints with untrusted or broken certificates.

## Run fully offline (sample agent + capture service, no DB, no Vertex)

To exercise the whole pipeline without the production agent, the metrics API, or
Google Cloud credentials, use the bundled **sample LangChain agent** and the
**capture service** (which derives a `CTA_ACTION` from each live agent run and
holds it in memory):

```powershell
# 1. Start the sample agent on :4010
.\scripts\run_sample_agent.ps1

# 2. In another terminal, point the eval service at it in capture mode
$env:AGENT_SERVICE_BASE_URL = "http://localhost:4010"
$env:METRICS_SOURCE = "capture"
.\scripts\run_eval_service.ps1

# 3. Evaluate, then inspect the captured CTA_ACTIONs
Invoke-RestMethod http://localhost:4002/api/evaluate -Method Post `
  -Body '{"agent_id":"scope_extraction"}' -ContentType 'application/json'
Invoke-RestMethod http://localhost:4002/api/captures
```

`METRICS_SOURCE` selects where metrics come from: `capture` (live, in-memory),
`http` (the real `CTA_ACTION` API via `METRICS_API_BASE`), or `stub` (the
agent's `metrics_stub.json`). Left unset it infers `http` when
`METRICS_API_BASE` is configured and `stub` otherwise; an agent.yaml
`metrics_source` overrides it per agent. The LLM judge metric is skipped
automatically when no Vertex credentials are present, so the run still completes
offline.

## How a case passes

A case fails on exactly three things:

1. a **`critical`** metric missed its threshold, or could not be measured at all;
2. the **weighted score** missed the dataset threshold (`EVAL_DATASET_THRESHOLD`,
   default `0.8`, or the dataset's own `threshold`);
3. the **weighted delta** fell below `-tolerance` against the baseline
   (`EVAL_REGRESSION_TOLERANCE`, default `0.05`).

A **non-critical** metric below its threshold is recorded as failed and appears
in the report and the exports, but does not veto on its own: it lowers the
weighted score by its weight's share, and fails the case only if that is enough
to breach the threshold. The three fields divide the work:

| field | what it controls |
|---|---|
| `critical: true` | this metric can fail the case by itself |
| `weight` | how hard this metric pulls the weighted score |
| `threshold` | whether this metric counts as passed — in the report always, at the gate only when it is `critical` |

Two further rules are easy to trip over:

- **A `critical` metric that could not be measured vetoes the case**, exactly
  like one that failed. That is deliberate -- an unmeasured compliance check is
  not a pass -- so only mark a metric `critical` when it can *always* run
  against that target: no LLM judge (skips without Vertex credentials), no
  optional package (`docx_table_has`, `pdf_table_has`), and no `groundedness`
  against a target that returns no retrieved context.
- **A metric runs for a case only if the case's `baseline_metrics` names it.**
  That is how a case opts out of a metric that does not apply to it (a refusal
  case skipping reference comparisons, say). A metric that *no* case names never
  runs at all; the registry logs that at startup as an "agent ... loaded with
  gaps" warning, and `Registry.validate(strict=True)` turns it into an error.

Exports show all of it: a skipped metric appears in the CSV with
`metric_state=skipped` and its reason, and the PDF lists `[SKIP]` rows plus a
"Critical metrics blocking this case" line.

## Writing a metric that survives the agent improving

These golden sets are written on the assumption that the agents get better. A
metric should fail an agent for being *wrong*, never for being *better*, so:

- **Reference the case, not a literal.** Metric config is dataset-wide, so
  `{"path": "total", "op": "equals", "value": 8000}` can never pass on a case
  whose total is different. Write `"value": "${expected.expected_total}"`
  instead: any whole-string `${expected.path}` or `${input.path}` in a metric's
  config is resolved against the case, keeping the resolved type (a list stays a
  list). A reference the case does not define skips the metric with a config
  error rather than silently comparing against `null`. Request templating cannot
  see `expected` -- that holds the answer.
- **Measure coverage, not resemblance.** `token_overlap_f1` takes
  `mode: "f1" | "recall" | "precision"`. F1 falls as the output grows even when
  it still contains everything in the golden (below 0.2 once the output is ~9x
  the golden), so a golden-as-a-floor check wants `mode: "recall"`, which is
  insensitive to extra content but still fails an output that omits reference
  material.
- **Treat the golden as a floor, not a ceiling.** The golden-anchored judges
  (`faithfulness`, `completeness`, a `rubric` with `uses_golden`) are told not
  to penalise different wording or extra correct detail, and to penalise only
  contradictions, unsupported claims and missing golden content.
- **Make an upper bound a runaway guard.** `length_range` / `heading_count`
  decay as `max / value`, so a metric fails above `max / threshold`. Keep that
  limit several times larger than any plausible good answer -- it is there to
  catch a 50x blow-up, not to enforce a word budget.
- **Do not confuse a caveat with a refusal.** `refusal_appropriate` counts a
  response as refusing only when it leads with the refusal or is nothing but a
  refusal, so an answer that adds "I cannot confirm X from the documentation"
  still passes. A case can set `expected.refusal_markers` to define its own.

`src/tests/test_improvement_resilience.py` holds these as executable checks,
including ones that scan every shipped dataset.

## CI/CD gate

```powershell
.venv\Scripts\python.exe scripts\ci_gate.py --agent scope_extraction --eval-url http://localhost:4002
```

The agent can also be passed positionally or via `AGENT_ID`. The gate starts a
run, polls `/api/evaluate/stream/{id}/events` until it finishes, then checks the
run record's `status == "PASS"` (plus optional `--score`, `--delta`,
`--pass-rate` thresholds). Exit code 0 = pass, 1 = gate failed, 2 = service or
run error, failing the pipeline step.

## Add a new agent

Create `src/agents/<agent_id>/` with:

- `agent.yaml` — id, name, version, description, base_url, dataset/metrics
  files, optional `metrics_source` (`capture` | `http` | `stub`)
- `dataset.json` — the golden set (inputs, ideal outputs, baseline metrics)
- `metrics_stub.json` — stubbed metrics-API response (until the real API
  exists); its `cases` keys must be the dataset's case ids, or that case gets no
  metrics. Set `metrics_source: capture` in `agent.yaml` for a live agent and
  the numbers come from the observed run instead.
- `custom_tests.py` — optional bespoke scorers via `@scorer("name")`. A dataset
  may only reference built-in scorers and the ones its *own* `custom_tests.py`
  registers; borrowing another agent's is rejected at load, since it would break
  the moment this agent is loaded on its own.

The registry auto-discovers it at startup — no core code changes. Every case
must list each metric it should run in its `baseline_metrics` (see
[How a case passes](#how-a-case-passes)); golden files must be written as UTF-8.

**Config-driven agent calls**: set `target.adapter: "http"` in `dataset.json`
to call any agent HTTP endpoint (GET/POST/PUT, auth, params, body, response
mapping) without writing Python. Supports document outputs (PDF, DOCX,
Markdown, JSON) with automatic text extraction.

**Config-driven metrics**: 11 scorers parameterised via `MetricSpec.config`
(text/regex: `contains`, `regex_match`, `length_range`, `keyword_count`; JSON:
`json_path`, `field_match`, `json_schema_valid`; document: `section_present`,
`heading_count`, `docx_table_has`; custom LLM: `rubric`). No Python needed.

See [docs/AGENT_CONFIG_GUIDE.md](docs/AGENT_CONFIG_GUIDE.md) for a complete
engineer tutorial and [docs/UPGRADES_AND_CHANGES.md](docs/UPGRADES_AND_CHANGES.md)
for the full changelog.

## Demo agents

Three sample LangChain agents (hostable standalone) demonstrate the upgrades:

```powershell
.\scripts\run_report_writer_agent.ps1    # Markdown reports  (port 4011)
.\scripts\run_invoice_parser_agent.ps1    # JSON invoices    (port 4012)
.\scripts\run_document_qa_agent.ps1      # DOCX + PDF docs  (port 4013)
```

Evaluate any of them:
```powershell
Invoke-RestMethod http://localhost:4002/api/evaluate -Method Post `
  -Body '{"agent_id":"report_writer"}' -ContentType 'application/json'
```

## Notes

- **Persistence:** CloudSQL Postgres is the default (`EVAL_DB_URL=postgresql://`).
  On CloudSQL connection/init failure, the service falls back to local SQLite
  automatically (`eval_service.db`).
- **Metrics API:** stubbed from each agent's `metrics_stub.json`; set
  `METRICS_API_BASE` to switch to the live API with no scorer changes.

## Config Playground

Use `/playground.html` to upload an agent configuration ZIP, edit its files in the browser, run the edited configuration against a target, inspect case-level evaluation results, and export the edited ZIP. Playground workspaces and runs are ephemeral and are not written to the normal evaluation database.
