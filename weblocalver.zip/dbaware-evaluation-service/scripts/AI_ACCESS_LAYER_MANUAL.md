# AI Access Layer Integration & Operations Manual (For AI Agents)

This manual provides complete, copy-paste-ready instructions for AI agents working in this repository (`dbaware-scoping-service`) to:
1. Migrate any Python/LangChain service from direct Vertex AI (`project` + `location`) to the **Deutsche Bank AI Access Layer Gateway**.
2. Connect and test locally on Windows (`sanjama` workstation) using WIF / OAuth tokens and custom PEM/CRT certificates.
3. Deploy, inspect, and test live in GKE (`155081-1-cta-ct1`).

---

## 1. Why the AI Access Layer Is Required

Direct calls to Vertex AI (`ChatGoogleGenerativeAI(model=..., project="db-dev-46jr-mp-cta-analytics", location=...)`) are blocked by the GCP Organization Policy `constraints/vertexai.allowedModels` (`denyAll: true`) on project `db-dev-46jr-mp-cta-analytics` (`227297990942`):
```text
400 FAILED_PRECONDITION: Organization Policy constraint constraints/vertexai.allowedModels violated for `projects/227297990942`
```

All Gemini calls must route through the **AI Access Layer Gateway** using:
- `base_url`: `https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com` (Dev/CT1) or `https://gateway.europe-west3.aiaccesslayer.uat.gcp.db.com` (UAT)
- `model`: `gemini-3.5-flash-europe-west3` (from env var `GENAI_MODEL_NAME`)
- `api_key`: OAuth2 Bearer token from `GoogleOAuthTokenProvider` (`google.auth.default` with `cloud-platform` + `userinfo.email` scopes)

---

## 2. Code Changes Required to Onboard an Agent

### 2.1 `config.py` / `settings.py`
Read the model name from `GENAI_MODEL_NAME` with fallback `"gemini-3.5-flash-europe-west3"`:

```python
MODEL_NAME = os.getenv("GENAI_MODEL_NAME", "gemini-3.5-flash-europe-west3")
```

### 2.2 `gemini_connection.py`
Replace direct Vertex (`project=Config.PROJECT_NAME, location=Config.PROJECT_LOCATION`) with the AI Access Layer certificate + OAuth token configuration:

```python
import os
import sys
import logging
import tempfile
from typing import Any
import certifi
from langchain_google_genai import ChatGoogleGenerativeAI
from google.auth import default
import google.auth.transport.requests

from config.config import Config

logger = logging.getLogger(__name__)

AI_ACCESS_LAYER_BASE_URL = os.getenv("AI_ACCESS_LAYER_BASE_URL")
_CERTIFICATE_CONFIGURED = False


def _is_local_cert_auth_enabled() -> bool:
    """
    Enables custom certificate auth only when explicitly turned on.
    Intended for local development.
    """
    raw_value = str(os.getenv("ENABLE_LOCAL_CERT_AUTH", "")).strip().lower()
    return raw_value == "true"


def _is_local_runtime() -> bool:
    """
    Treat Kubernetes runtime as non-local; everything else defaults to local.
    """
    return not bool(os.getenv("KUBERNETES_SERVICE_HOST"))


def _set_ssl_bundle_env(path: str) -> None:
    """
    Set SSL bundle environment variables without overriding pre-existing values.
    """
    os.environ.setdefault("REQUESTS_CA_BUNDLE", path)
    os.environ.setdefault("SSL_CERT_FILE", path)
    os.environ.setdefault("GRPC_DEFAULT_SSL_ROOTS_FILE_PATH", path)


def configure_certificate(custom_cert_paths: list[str]) -> str:
    """
    Combines certifi's default CA bundle with one or more custom certificates
    and sets the required environment variables.
    """
    if not custom_cert_paths:
        raise ValueError("No custom certificate paths are set")

    with open(certifi.where(), "r", encoding="utf-8") as f:
        ca_bundle = f.read()

    custom_certs: list[str] = []
    for custom_cert_path in custom_cert_paths:
        if not os.path.exists(custom_cert_path):
            raise FileNotFoundError(f"Certificate file not found: {custom_cert_path}")

        with open(custom_cert_path, "r", encoding="utf-8") as f:
            custom_cert = f.read()

        if "-----BEGIN CERTIFICATE-----" not in custom_cert:
            raise ValueError(f"Certificate file is not PEM format: {custom_cert_path}")
        custom_certs.append(custom_cert)

    # Create a combined bundle file in the same directory as the custom cert,
    # falling back to tempfile if the folder is OneDrive-protected or read-only.
    combined_path = os.path.join(os.path.dirname(custom_cert_paths[0]), "combined-ca-bundle.pem")
    try:
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)
    except OSError:
        combined_path = os.path.join(tempfile.gettempdir(), "combined-ca-bundle.pem")
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)

    os.environ["REQUESTS_CA_BUNDLE"] = combined_path
    os.environ["SSL_CERT_FILE"] = combined_path
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = combined_path
    return combined_path


def _configure_certificate_once() -> None:
    global _CERTIFICATE_CONFIGURED
    if _CERTIFICATE_CONFIGURED:
        return

    if not _is_local_runtime():
        configured_path = (os.getenv("CA_BUNDLE_PATH") or "").strip()
        if configured_path:
            _set_ssl_bundle_env(configured_path)
            logger.info("Configured SSL CA bundle from CA_BUNDLE_PATH: %s", configured_path)
        else:
            logger.info("CA_BUNDLE_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    if not _is_local_cert_auth_enabled():
        logger.info("Local certificate auth is disabled; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    custom_paths = str(os.getenv("CUSTOM_CERT_PATHS") or "").strip()
    if custom_paths:
        cert_paths = [p.strip() for p in custom_paths.split(",") if p.strip()]
    else:
        legacy_path = str(os.getenv("CUSTOM_CERT_PATH") or "").strip()
        cert_paths = [legacy_path] if legacy_path else []

    if not cert_paths:
        logger.info("CUSTOM_CERT_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    combined_path = configure_certificate(cert_paths)
    logger.info("Custom certificate bundle configured at: %s", combined_path)
    _CERTIFICATE_CONFIGURED = True


class GoogleOAuthTokenProvider:
    def __init__(self):
        self.credentials, _ = default(
            scopes=[
                "https://www.googleapis.com/auth/cloud-platform",
                "https://www.googleapis.com/auth/userinfo.email",
            ]
        )
        self.request = google.auth.transport.requests.Request()

    @property
    def token(self):
        if not self.credentials.valid:
            self.credentials.refresh(self.request)
        return self.credentials.token


def initialize_gemini_model() -> Any:
    logger.info(
        "Initializing Gemini model model=%s location=%s",
        Config.MODEL_NAME,
        Config.PROJECT_LOCATION,
    )
    provider = GoogleOAuthTokenProvider()
    _configure_certificate_once()
    return ChatGoogleGenerativeAI(
        model=Config.MODEL_NAME,
        api_key=provider.token,
        base_url=AI_ACCESS_LAYER_BASE_URL,
        temperature=Config.GENERATION_CONFIG["temperature"],
        top_p=Config.GENERATION_CONFIG["top_p"],
        top_k=Config.GENERATION_CONFIG.get("top_k"),
        max_output_tokens=Config.GENERATION_CONFIG.get("max_output_tokens"),
        safety_settings=Config.SAFETY_CONFIG["safety_settings"],
    )
```

---

## 3. Helm Chart & Kubernetes Configuration

### 3.1 `helm-chart/values-ct1.yaml` and `helm-chart/values-dev1.yaml`
Add:
```yaml
AI_ACCESS_LAYER_BASE_URL: https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com
GENAI_MODEL_NAME: gemini-3.5-flash-europe-west3
CA_BUNDLE_PATH: "/etc/ssl/certs/ca-certificates.crt"
```

### 3.2 `helm-chart/values-uat1.yaml`
Add:
```yaml
AI_ACCESS_LAYER_BASE_URL: https://gateway.europe-west3.aiaccesslayer.uat.gcp.db.com
GENAI_MODEL_NAME: gemini-3.5-flash-europe-west3
CA_BUNDLE_PATH: "/etc/ssl/certs/ca-certificates.crt"
```

### 3.3 `helm-chart/templates/configmap.yaml`
Add under `data:`:
```yaml
  AI_ACCESS_LAYER_BASE_URL: {{ .Values.AI_ACCESS_LAYER_BASE_URL | quote }}
  GENAI_MODEL_NAME: {{ .Values.GENAI_MODEL_NAME | quote }}
  CA_BUNDLE_PATH: {{ .Values.CA_BUNDLE_PATH | quote }}
```

### 3.4 `helm-chart/templates/deployment.yaml`
Add under the container's `env:`:
```yaml
        - name: AI_ACCESS_LAYER_BASE_URL
          valueFrom:
            configMapKeyRef:
              name: <service-configmap-name>
              key: AI_ACCESS_LAYER_BASE_URL
        - name: GENAI_MODEL_NAME
          valueFrom:
            configMapKeyRef:
              name: <service-configmap-name>
              key: GENAI_MODEL_NAME
        - name: CA_BUNDLE_PATH
          valueFrom:
            configMapKeyRef:
              name: <service-configmap-name>
              key: CA_BUNDLE_PATH
```

---

## 4. Local Certificate & Environment Setup (Workstation Reference)

### 4.1 Certificate File Locations on This Machine
- **Reference PDF:** `C:\Users\sanjama\OneDrive - Deutsche Bank AG\Documents\aiaccess\AI Access Layer Integration_719784e7aa40493094746ab63324b93b-041126-0618-582.pdf`
- **`cert.pem`:** `C:\Users\sanjama\OneDrive - Deutsche Bank AG\Documents\aiaccess\cert.pem`
- **Root Test CA (`.crt`):** `C:\Users\sanjama\OneDrive - Deutsche Bank AG\Documents\aiaccess\db-group-root-test-ca-14.crt`
- **WIF JSON:** `C:\Users\sanjama\Downloads\wif_new\dbgarda\config\wif-file-based.json`
- **WIF CA Cert:** `C:\Users\sanjama\Downloads\wif_new\dbgarda\config\cacert.crt`

> **Windows OneDrive Gotcha:** Writing `combined-ca-bundle.pem` directly into `C:\Users\sanjama\OneDrive - Deutsche Bank AG\Documents\aiaccess\` can fail with `FileNotFoundError` / `PermissionError` due to Windows Controlled Folder Access / OneDrive sync locks. Always keep the `tempfile.gettempdir()` fallback in `configure_certificate()`.

### 4.2 Proxy & `NO_PROXY` Nuances on Windows (`httpx` vs Google OAuth)
- **Google OAuth / GCS (`*.googleapis.com`)** requires the corporate proxy:
  - `HTTPS_PROXY=http://sdod3-proxy.intranet.db.com:8080`
  - `HTTP_PROXY=http://sdod3-proxy.intranet.db.com:8080`
  - *(Note: `http://sp-surf-proxy.intranet.db.com:8080` returns `403 InternetBlockDirectIntranet` on this workstation; use `sdod3-proxy` instead).*
- **AI Access Layer (`gateway.europe-west3.aiaccesslayer.dev.gcp.db.com`)** is an internal `.db.com` host and **must bypass the proxy**.
  - **CRITICAL `httpx` gotcha:** Python's `httpx` (used by `google-genai`) does **not** match wildcard `*.db.com` in `NO_PROXY`; it requires a leading dot `.db.com` (without `*`):
    ```powershell
    $env:NO_PROXY = ".db.com,db.com,localhost,127.0.0.1,10.*"
    $env:no_proxy = ".db.com,db.com,localhost,127.0.0.1,10.*"
    ```
  - If you only set `NO_PROXY="*.db.com"`, `httpx` sends `gateway.europe-west3.aiaccesslayer.dev.gcp.db.com` to the proxy, which fails with `httpx.ProxyError: 502 cannotconnect` or `403 InternetBlockDirectIntranet`.

### 4.3 Authentication Nuances (WIF / Service Account vs User Account)
- The AI Access Layer checks IAM permissions on the Bearer token.
- Personal `gcloud` user tokens (`amal.sanjeev@db.com`) may receive:
  ```text
  403 Forbidden: {'error': {'message': 'Access denied for amal.sanjeev@db.com', 'type': 'auth_error', 'code': '403'}}
  ```
- Instead, authenticate using either:
  1. **Refreshed WIF credentials** (`GOOGLE_APPLICATION_CREDENTIALS=C:\Users\sanjama\Downloads\wif_new\dbgarda\config\wif-file-based.json`), refreshed via:
     ```powershell
     java "-Dspring.config.location=C:/Users/sanjama/Downloads/wif_new/dbgarda/config/application.properties" -jar "C:/Users/sanjama/Downloads/wif_new/dbgarda/gcp-wif.jar"
     ```
  2. **In-cluster Workload Identity token** fetched from a running CT1 pod via `kubectl exec` (when testing from local code against the gateway).

---

## 5. Quick Verification Commands

### 5.1 Verify AI Access Layer Connection Locally
```powershell
$cert1 = 'C:\Users\sanjama\OneDrive - Deutsche Bank AG\Documents\aiaccess\cert.pem'
$cert2 = 'C:\Users\sanjama\OneDrive - Deutsche Bank AG\Documents\aiaccess\db-group-root-test-ca-14.crt'

$env:AI_ACCESS_LAYER_BASE_URL = 'https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com'
$env:GENAI_MODEL_NAME = 'gemini-3.5-flash-europe-west3'
$env:CUSTOM_CERT_PATHS = "$cert1,$cert2"
$env:ENABLE_LOCAL_CERT_AUTH = 'true'
$env:HTTPS_PROXY = 'http://sdod3-proxy.intranet.db.com:8080'
$env:HTTP_PROXY = 'http://sdod3-proxy.intranet.db.com:8080'
$env:NO_PROXY = '.db.com,db.com,localhost,127.0.0.1,10.*'
$env:no_proxy = '.db.com,db.com,localhost,127.0.0.1,10.*'

& "c:\Users\sanjama\Documents\llmjudge\.venv\Scripts\python.exe" -c "
import sys, logging
logging.basicConfig(level=logging.INFO)
sys.path.insert(0, r'c:\Users\sanjama\Documents\llmjudge\scoping-summary-agent\src\main')
from utils.gemini_connection import initialize_gemini_model
model = initialize_gemini_model()
print(model.invoke('Reply with just OK').content)
"
```

Expected log output:
```text
INFO:httpx:HTTP Request: POST https://gateway.europe-west3.aiaccesslayer.dev.gcp.db.com/v1beta/models/gemini-3.5-flash-europe-west3:generateContent "HTTP/1.1 200 OK"
```

### 5.2 Verify Inside the GKE CT1 Pod (`155081-1-cta-ct1`)
> **Important:** Always clear `GOOGLE_APPLICATION_CREDENTIALS` before running `kubectl` so `kubectl` uses the `gcloud` user session rather than an expired WIF file.

```powershell
Remove-Item Env:GOOGLE_APPLICATION_CREDENTIALS -ErrorAction SilentlyContinue
kubectl get pods -n 155081-1-cta-ct1 | Select-String "scoping-summary-agent"
```

### 5.3 Writing Logs to `scripts/loggo.log`
When writing logs to `scripts/loggo.log` for inspection in VS Code on this workstation, always write **UTF-16-LE with BOM** (`b"\xff\xfe" + full_text.encode("utf-16-le")`) so VS Code does not misdetect the encoding.
