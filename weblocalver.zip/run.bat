@echo off
setlocal EnableDelayedExpansion
title Trade Collections - Maker Workbench

rem Launch the demo. Optional first argument is the port, e.g.  run.bat 8080
rem
rem Dependencies go into a local .venv so this never collides with whatever
rem else is installed on the machine.

cd /d "%~dp0"

set "PORT=%~1"
if "%PORT%"=="" set "PORT=8000"
set "VENV=.venv"

echo.
echo   Trade Collections - Maker Workbench
echo   ===================================
echo.

rem --- find a Python -------------------------------------------------------
rem Don't trust "where": Windows ships app-execution aliases that resolve but
rem fail to run. Actually execute each candidate and check the version.
set "PY="
for %%C in ("python" "py -3" "python3") do (
  if not defined PY (
    %%~C -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1 && set "PY=%%~C"
  )
)
if not defined PY (
  echo   No usable Python 3.10+ was found.
  echo.
  echo   Install Python from https://www.python.org/downloads/ and tick
  echo   "Add python.exe to PATH" during setup, then run this again.
  echo.
  pause
  exit /b 1
)
for /f "tokens=2" %%v in ('%PY% --version 2^>^&1') do set "PYVER=%%v"
echo   Python %PYVER%

rem --- is the port already taken? ------------------------------------------
netstat -ano -p tcp 2>nul | findstr /c:"LISTENING" | findstr /c:":%PORT% " >nul 2>&1
if not errorlevel 1 (
  echo   Port %PORT% is already in use - the demo may already be running.
  echo.
  echo   Open  http://127.0.0.1:%PORT%/   or pick another port:
  echo.
  echo       run.bat 8080
  echo.
  pause
  exit /b 1
)

rem --- local environment ---------------------------------------------------
set "VPY=%VENV%\Scripts\python.exe"
if not exist "%VPY%" (
  echo   Setting up a local environment. This happens once and takes a minute.
  %PY% -m venv "%VENV%"
  if errorlevel 1 (
    echo.
    echo   Could not create the environment. Try running:
    echo       %PY% -m venv .venv
    echo.
    pause
    exit /b 1
  )
)

rem Vertex / WIF configuration for the pricing agent.
rem The app uses PROJECT_NAME and GOOGLE_APPLICATION_CREDENTIALS to resolve
rem ADC through the supplied external_account file, not a service key.
set "PROJECT_NAME=db-dev-46jr-mp-cta-analytics"
set "PROJECT_LOCATION=us-central1"
set "GOOGLE_APPLICATION_CREDENTIALS=C:\Users\sanjama\Downloads\wif_new\dbgarda\config\wif-file-based.json"
set "SSL_CERT_FILE=C:\Users\sanjama\Downloads\wif_new\dbgarda\config\cacert.crt"
set "REQUESTS_CA_BUNDLE=C:\Users\sanjama\Downloads\wif_new\dbgarda\config\cacert.crt"
set "HTTP_PROXY=http://sdod3-proxy.intranet.db.com:8080"
set "HTTPS_PROXY=http://sdod3-proxy.intranet.db.com:8080"
set "NO_PROXY=*.db.com;*.de.db.com;*.intranet.db.com;localhost;127.0.0.1"
set "PRICING_AGENT_PROVIDER=vertex"

rem If the WIF config is missing, fail clearly instead of silently drifting to a
rem non-Vertex backend.
if not exist "%GOOGLE_APPLICATION_CREDENTIALS%" (
  echo   WIF credential config not found:
  echo     %GOOGLE_APPLICATION_CREDENTIALS%
  echo.
  echo   Update the path in run.bat or point GOOGLE_APPLICATION_CREDENTIALS at
  echo   the external_account file generated for dbgarda.
  pause
  exit /b 1
)
if not exist "%SSL_CERT_FILE%" (
  echo   Corporate CA bundle not found:
  echo     %SSL_CERT_FILE%
  echo.
  echo   Update the path in run.bat to match the dbgarda bundle.
  pause
  exit /b 1
)

rem Only reach for the network when something is actually missing.
"%VPY%" -c "import fastapi, uvicorn, jinja2, pydantic" >nul 2>&1
if errorlevel 1 (
  echo   Installing dependencies...
  "%VPY%" -m pip install --upgrade pip --quiet --disable-pip-version-check >nul 2>&1
  "%VPY%" -m pip install -r requirements.txt --quiet --disable-pip-version-check
  if errorlevel 1 (
    echo.
    echo   Could not install the dependencies. Check the internet connection,
    echo   or run this by hand to see the error:
    echo.
    echo       "%VPY%" -m pip install -r requirements.txt
    echo.
    pause
    exit /b 1
  )
)
echo   Ready.

rem --- open the browser once the server actually answers --------------------
where curl >nul 2>&1
if errorlevel 1 (
  start "" /b cmd /c "@echo off && timeout /t 4 /nobreak >nul && start "" "http://127.0.0.1:%PORT%/?v=corp""
) else (
  start "" /b cmd /c "@echo off && for /l %%i in (1,1,40) do (timeout /t 1 /nobreak >nul && curl -s -o nul http://127.0.0.1:%PORT%/ && start "" "http://127.0.0.1:%PORT%/?v=corp" && exit)"
)

echo.
echo   Running at http://127.0.0.1:%PORT%/
echo.
echo     ?v=corp    corporate view  - Material 3, follows the project deck
echo     ?v=desk    desk view       - the collections-desk alternative
echo.
echo   Press Ctrl+C to stop.
echo.

"%VPY%" -m uvicorn app.main:app --host 127.0.0.1 --port %PORT%

echo.
echo   Server stopped.
pause
