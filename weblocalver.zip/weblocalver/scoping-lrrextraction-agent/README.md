# LRR Extraction Agent - Regulatory Document Extraction Service

**Production regulatory source extraction service with bounded agentic workflow.**

Extracts regulatory documents from seed URLs using deterministic agentic crawling, validates extracted content, and serves results via REST API.

**Status:** Production Ready | **Coverage:** 70%+ | **Framework:** FastAPI + LangGraph

---

## Entry Points

- **FastAPI Server:** `src/main/app.py` (default port 8765)
- **CLI Tool:** `src/main/cli.py`
- **Config:** `src/main/config/settings.py`

---

## Public API - `/lrr` Routes

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/process` | POST | Start new extraction run |
| `/process/{run_id}/status` | GET | **Poll for progress** (main frontend endpoint) |
| `/runs` | GET | List all runs |
| `/runs/{run_id}` | GET | Get run details/results |

**Frontend Docs:** See `API_SPECIFICATION.md`, `FRONTEND_QUICK_START.md`, `POLLING_GUIDE.md`

---

## Module Overview

| Module | Purpose |
|--------|---------|
| `routes/lrr.py` | REST API endpoints (/lrr routes) |
| `runtime/runner.py` | Run orchestration and state management |
| `graph/` | LangGraph agentic workflow with deterministic guards |
| `services/` | Business logic (data, run, document, query) |
| `storage/` | Persistence (local filesystem or GCS) |
| `tools/` | Utilities (fetch, validation, extraction) |
| `models/` | Pydantic data schemas |
| `retrieval/` | Semantic search over corpus |
| `processing/` | Text processing (markdown, chunking) |
| `schemas/` | API request/response schemas |

---

## Quick Start

**Install:**
```bash
python -m pip install -e .
python -m pip install -e .[dev]
```

**Run API:**
```bash
cd src
python -m uvicorn main.app:app --reload --port 8000
```

**Run Tests:**
```bash
pytest --cov=main --cov-report=term
```

**Build:**
```bash
mvn clean package -DskipTests
```

---

## Configuration

**Key Environment Variables** (see `config/settings.py`):
- `OUTPUT_DIR` - Corpus output directory (default: `corpus/`)
- `SOURCE_ALLOWLIST` - Comma-separated allowed domains
- `SOURCE_HOST_ALIASES` - Host mapping (JSON)
- `GCS_BUCKET` - Google Cloud Storage bucket (optional)
- `RESPECT_ROBOTS_TXT` - Honor robots.txt (default: true)
- `MAX_AGENT_STEPS` - Step budget (default: 40)
- `MAX_DISCOVERY_DEPTH` - Link exploration depth (default: 2)

---

## Workflow

```
POST /lrr/process (with URLs only)
    ↓
Returns run_id
    ↓
Poll GET /lrr/process/{run_id}/status every 3 seconds
    ↓
Status: queued → running → completed
    ↓
GET /lrr/runs/{run_id} for full results
```

---

## Design Principles

✓ Deterministic extraction (no LLM-generated content)  
✓ Bounded agentic crawler (fixed action vocabulary)  
✓ Content validation before acceptance  
✓ Source preservation (exact text extraction)  
✓ Checkpoint/resume capability  
✓ Local + GCS storage  

---

## Critical Paths

| Task | File |
|------|------|
| Start run | `routes/lrr.py` |
| Poll status | `routes/lrr.py` |
| Run management | `runtime/runner.py` |
| Extraction logic | `graph/actions.py` |
| Persistence | `storage/storage.py` |

---

## Docker & Kubernetes

**Docker:**
```bash
docker build -t lrr-agent:latest .
docker run -p 8000:8000 lrr-agent:latest
```

**Kubernetes:** See `helm-chart/` for deployment manifests.

---

## Testing

**Run tests with coverage:**
```bash
pytest --cov=main --cov-report=term
```

**Current coverage:** 70%+

**Main test modules:**
- `tests/routes/test_lrr_routes.py` - API endpoints
- `tests/runtime/test_runner.py` - Run orchestration
- `tests/graph/test_graph_actions.py` - Workflow logic
- `tests/storage/test_storage.py` - Persistence

---

## Output Artifacts

By default written to `./corpus/`:

- `registry.json` - Document registry and version history
- `agent_memory.json` - Prior failures and strategies
- `checkpoints/<run_id>.json` - Resumable run state
- `manifests/<run_id>.json` - Run summary
- `review/<run_id>.json` - Items requiring manual review

**Resume interrupted run:**
```bash
cd src
python -m main cli ingest --url "https://example.com" --resume <run_id>
```