"""URL approval and whitelist validation for regulatory acquisition."""
import yaml
from pathlib import Path
from typing import Optional

from urllib.parse import urlparse


class ApprovedURLValidator:
    """Validates URLs against an approved whitelist."""

    def __init__(self, approved_urls_path: Optional[Path] = None):
        """
        Initialize the validator with approved URLs.

        Args:
            approved_urls_path: Path to url_catalogue.yml. If None, uses default location.
        """
        if approved_urls_path is None:
            approved_urls_path = (
                Path(__file__).parent.parent / "config" / "url_catalogue.yml"
            )

        self.approved_urls_path = approved_urls_path
        self._approved_urls: dict[str, dict] = {}
        self._load_approved_urls()

    def _load_approved_urls(self) -> None:
        """Load approved URLs from YAML file."""
        if not self.approved_urls_path.exists():
            raise FileNotFoundError(f"Approved URLs file not found: {self.approved_urls_path}")

        with open(self.approved_urls_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            self._approved_urls = {
                item["url"]: item for item in data.get("approved_urls", [])
            }

    def is_approved(self, url: str) -> bool:
        """
        Check if a URL is in the approved list.

        Performs exact match against approved URLs.

        Args:
            url: The URL to validate.

        Returns:
            True if URL is approved, False otherwise.
        """
        return url in self._approved_urls

    def get_approval_info(self, url: str) -> Optional[dict]:
        """
        Get approval metadata for an approved URL.

        Args:
            url: The URL to look up.

        Returns:
            Dictionary with regulator and description, or None if not found.
        """
        return self._approved_urls.get(url)

    def validate_urls(self, urls: list[str]) -> tuple[list[str], list[str]]:
        """
        Validate a list of URLs.

        Args:
            urls: List of URLs to validate.

        Returns:
            Tuple of (approved_urls, unapproved_urls).
        """
        approved = [url for url in urls if self.is_approved(url)]
        unapproved = [url for url in urls if not self.is_approved(url)]
        return approved, unapproved

    def get_approved_regulators(self) -> dict[str, list[str]]:
        """
        Get all approved URLs grouped by regulator.

        Returns:
            Dictionary mapping regulator name to list of approved URLs.
        """
        regulators: dict[str, list[str]] = {}
        for url, info in self._approved_urls.items():
            regulator = info.get("regulator", "Unknown")
            if regulator not in regulators:
                regulators[regulator] = []
            regulators[regulator].append(url)
        return regulators

    def list_approved_urls(self) -> list[dict]:
        """
        Get all approved URLs with metadata.

        Returns:
            List of dictionaries with url, regulator, and description.
        """
        return list(self._approved_urls.values())


# Singleton instance
_validator: Optional[ApprovedURLValidator] = None


def get_validator() -> ApprovedURLValidator:
    """Get or create the global URL validator instance."""
    global _validator
    if _validator is None:
        _validator = ApprovedURLValidator()
    return _validator
