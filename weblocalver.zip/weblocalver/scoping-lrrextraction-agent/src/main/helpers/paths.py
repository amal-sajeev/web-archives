from pathlib import Path


def get_repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def get_src_root() -> Path:
    return get_repo_root() / "src"


def get_ui_dir() -> Path:
    return get_repo_root() / "src" / "ui"
