import mimetypes
import logging
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

from google.cloud import storage

from config.settings import Settings

logger = logging.getLogger(__name__)


def _normalize_blob_path(blob_path: str, *, bucket_name: str | None = None) -> str:
    if not blob_path or not str(blob_path).strip():
        raise ValueError("GCS blob path is required")

    value = str(blob_path).strip().replace("\\", "/")
    if value.startswith("gs://"):
        parsed = urlparse(value)
        value = parsed.path.lstrip("/")

    value = value.lstrip("/")
    if bucket_name:
        bucket_prefix = bucket_name.strip().lstrip("/")
        if value.lower().startswith(f"{bucket_prefix}/".lower()):
            value = value[len(bucket_prefix) + 1 :]

    parts = PurePosixPath(value).parts
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError(f"Invalid GCS path: {blob_path!r}")
    return "/".join(parts)


def get_gcs_bucket() -> str:
    settings = Settings()
    bucket = (settings.gcs_bucket or "").strip()
    if not bucket:
        raise ValueError("GCS bucket is not configured as gcs_bucket in app.yml.")
    return bucket


def get_gcs_file_bytes(blob_path: str) -> tuple[bytes, str]:
    bucket_name = get_gcs_bucket()
    normalized = _normalize_blob_path(blob_path, bucket_name=bucket_name)
    client = storage.Client()
    blob = client.bucket(bucket_name).blob(normalized)
    if not blob.exists():
        raise FileNotFoundError(f"GCS object not found: gs://{bucket_name}/{normalized}")
    return blob.download_as_bytes(), normalized


def list_gcs_files(prefix: str = "", suffix: str = "") -> list[str]:
    bucket_name = get_gcs_bucket()
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob_prefix = _normalize_blob_path(prefix, bucket_name=bucket_name) if prefix else ""
    blobs = bucket.list_blobs(prefix=blob_prefix or None)
    results: list[str] = []
    for blob in blobs:
        name = blob.name
        if suffix and not name.endswith(suffix):
            continue
        results.append(name)
    return sorted(results)


def read_gcs_text(blob_path: str) -> str:
    bucket_name = get_gcs_bucket()
    normalized = _normalize_blob_path(blob_path, bucket_name=bucket_name)
    client = storage.Client()
    blob = client.bucket(bucket_name).blob(normalized)
    if not blob.exists():
        raise FileNotFoundError(f"GCS object not found: gs://{bucket_name}/{normalized}")
    return blob.download_as_text()


def download_gcs_file_to_local(blob_path: str, local_dir: str | Path | None = None) -> Path:
    bucket_name = get_gcs_bucket()
    normalized = _normalize_blob_path(blob_path, bucket_name=bucket_name)
    client = storage.Client()
    blob = client.bucket(bucket_name).blob(normalized)
    if not blob.exists():
        raise FileNotFoundError(f"GCS object not found: gs://{bucket_name}/{normalized}")

    target_dir = Path(local_dir) if local_dir is not None else Path.cwd()
    target_dir.mkdir(parents=True, exist_ok=True)
    relative = Path(normalized)
    target_path = (target_dir / relative).resolve()
    target_path.parent.mkdir(parents=True, exist_ok=True)

    blob.download_to_filename(str(target_path))
    return target_path


def upload_text_to_gcs(blob_path: str, content: str, *, content_type: str = "text/plain; charset=utf-8") -> str:
    bucket_name = get_gcs_bucket()
    normalized = _normalize_blob_path(blob_path, bucket_name=bucket_name)
    client = storage.Client()
    blob = client.bucket(bucket_name).blob(normalized)
    logger.info("Uploading text to GCS: gs://%s/%s bytes=%s content_type=%s", bucket_name, normalized, len(content.encode("utf-8")), content_type)
    blob.upload_from_string(content, content_type=content_type)
    gcs_uri = f"gs://{bucket_name}/{normalized}"
    logger.info("Saved text to GCS: %s", gcs_uri)
    return gcs_uri


def blob_exists(blob_path: str) -> bool:
    bucket_name = get_gcs_bucket()
    normalized = _normalize_blob_path(blob_path, bucket_name=bucket_name)
    client = storage.Client()
    return client.bucket(bucket_name).blob(normalized).exists()


def guess_content_type(file_name: str) -> str:
    return mimetypes.guess_type(file_name)[0] or "application/octet-stream"
