from typing import TypedDict


class AdapterConfig(TypedDict, total=False):
    """Configuration for a regulatory adapter."""

    name: str
    domain_patterns: list[str]              # Domains to match (case-insensitive)
    identifier_patterns: dict[str, str]     # Named regex patterns for extracting identifiers
    authority: str                          # SourceAuthority value
    authority_level: str                    # LegalAuthorityLevel value
    operative_text: bool                    # Whether this is operative/binding text
    node_types: dict[str, list[str]]        # Map keywords to node types


# Adapter URL and pattern configurations
ADAPTERS_CONFIG: dict[str, AdapterConfig] = {
    "finra": {
        "name": "finra",
        "domain_patterns": ["finra.org"],
        "identifier_patterns": {
            "rule": r"/finra-rules/(\d+)",
            "amendment": r"(?:SR-FINRA|Regulatory\s+Notice)\s*[-]?\s*(\d+-\d+)",
        },
        "authority": "SRO",
        "authority_level": "DELEGATED",
        "operative_text": True,
        "node_types": {
            "supplementary": ["supplementary", "material"],
            "amendment_history": ["amendment", "history"],
        },
    },
    "ecfr": {
        "name": "ecfr",
        "domain_patterns": ["ecfr.gov"],
        "identifier_patterns": {
            "title": r"/current/title-(\d+)",
            "part": r"/part-(\d+)",
        },
        "authority": "GOVERNMENT",
        "authority_level": "PRIMARY",
        "operative_text": True,
        "node_types": {
            "part": ["part"],
            "subpart": ["subpart"],
            "section": ["section"],
        },
    },
    "rbi": {
        "name": "rbi",
        "domain_patterns": ["rbi.org.in"],
        "identifier_patterns": {
            "master_direction": r"/master-direction",
        },
        "authority": "PRIMARY_REGULATOR",
        "authority_level": None,  # Not applicable
        "operative_text": False,
        "node_types": {
            "chapter": ["chapter"],
            "annex": ["annex"],
            "appendix": ["appendix"],
        },
    },
    "fca": {
        "name": "fca",
        "domain_patterns": ["fca.org.uk"],
        "identifier_patterns": {},
        "authority": "PRIMARY_REGULATOR",
        "authority_level": None,
        "operative_text": True,
        "node_types": {},
    },
}


def get_adapter_config(name: str) -> AdapterConfig | None:
    """Retrieve configuration for a specific adapter."""
    return ADAPTERS_CONFIG.get(name)
