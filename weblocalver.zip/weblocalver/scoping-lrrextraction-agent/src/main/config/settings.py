import yaml
from pathlib import Path
from typing import Any

from pydantic import Field, field_validator, AliasChoices
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict, YamlConfigSettingsSource

from helpers.paths import get_repo_root

def _settings_env_file() -> tuple[str, ...]:
    """
    For LOCAL development only:
        - Loads .env from current directory or repo root
    For KUBERNETES (ct1/dev1/uat1):
        - Ignores .env files
        - Uses environment variables injected by ConfigMap
    """
    repo_root = get_repo_root()
    candidates = [
        Path.cwd() / ".env",      # Priority 1: .env in current directory
        repo_root / ".env",       # Priority 2: .env in repo root
    ]
    return tuple(str(path) for path in candidates if path.exists())

class YamlConfig(YamlConfigSettingsSource):
    def __call__(self) -> dict[str, Any]:
        config_path = get_repo_root() / "src" / "main" / "config" / "app.yml"
        if config_path.exists():
            with open(config_path, "r") as f:
                return yaml.safe_load(f) or {}
        return {}

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=_settings_env_file(),
        extra="ignore",
        case_sensitive=False,
        populate_by_name=True,
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return init_settings, YamlConfig(settings_cls), dotenv_settings, env_settings, file_secret_settings

    # Environment specific configuration (.env or Kubernetes ConfigMap)
    google_cloud_project: str | None = Field(default=None, validation_alias="PROJECT_NAME")
    google_cloud_location: str | None = Field(default=None, validation_alias="PROJECT_LOCATION")
    google_application_credentials: str | None = None
    https_proxy: str | None = None
    http_proxy: str | None = None
    no_proxy: str | None = None
    ssl_cert_file: str | None = None
    requests_ca_bundle: str | None = None
    gcs_bucket: str | None = Field(default=None, validation_alias="BUCKET_NAME")
    gcs_prefix: str | None = Field(default=None, validation_alias="GCS_PREFIX")
    # source_allowlist_file: str | None = Field(default=None, alias="SOURCE_ALLOWLIST_FILE")
    # source_allowlist: str | None = Field(default="*", alias="SOURCE_ALLOWLIST")
    source_allowlist: str | None = Field(default="*", validation_alias=AliasChoices("source_allowlist", "SOURCE_ALLOWLIST"))
    source_host_aliases: str = Field(default="", validation_alias=AliasChoices("source_host_aliases", "SOURCE_HOST_ALIASES"))
    source_allowlist_file: str | None = Field(default=None, validation_alias="SOURCE_ALLOWLIST_FILE")

    # Application specific configuration (defaults from app.yml)
    master_risk_definitions: str
    manifest: str
    mandate_generation_prompt_path: Path
    risk_mapping_prompt_path: Path
    enriched_output_path_json: str
    enriched_output_path_csv: str
    inbound_enriched_output_path_json: str
    inbound_enriched_output_path_csv: str
    google_genai_use_vertexai: bool
    gemini_model: str
    gemini_reasoning_model: str
    temperature: float
    top_p: float
    top_k: int
    generation_seed: int
    llm_retry_attempts: int = 3
    llm_retry_base_delay_seconds: float = 2.0
    llm_retry_max_delay_seconds: float = 30.0
    document_chunk_max_chars: int = 12000
    document_chunk_min_chars: int = 2500
    document_chunk_top_n: int = 20
    document_chunk_relevance_min_score: float = 0.05
    mandate_mapping_batch_size: int = 10
    output_dir: Path = Field(default=Path("./corpus"), alias="OUTPUT_DIR")
    source_host_aliases: str = Field(default="", alias="SOURCE_HOST_ALIASES")
    max_pages: int
    max_bytes: int
    max_discovery_depth: int
    max_candidates_per_page: int
    request_timeout_seconds: float
    max_concurrent_fetches: int
    max_retries: int
    max_redirects: int
    backoff_base_seconds: float
    max_repair_attempts: int
    max_agent_steps: int
    checkpoint_every_step: bool
    min_extracted_chars: int
    min_quality_score: float
    min_authority_confidence: float
    user_agent: str
    respect_robots_txt: bool
    enable_ocr: bool
    ocr_language: str
    ocr_dpi: int
    enable_browser_rendering: bool
    browser_timeout_seconds: float
    enable_source_snapshots: bool
    require_human_review_on_rejection: bool
    log_style: str

    @property
    def allowed_hosts(self) -> set[str]:
        """Extract allowed hosts from source_allowlist, then fall back to the catalog file."""
        if self.source_allowlist and self.source_allowlist.strip():
            hosts: set[str] = set()
            for entry in self.source_allowlist.split(","):
                value = entry.strip().lower()
                if not value:
                    continue
                if value == "*":
                    hosts.add("*")
                    continue
                candidate = value
                if "://" in candidate:
                    from urllib.parse import urlparse
                    candidate = urlparse(candidate).netloc.lower()
                candidate = candidate.split("/", 1)[0].split(":", 1)[0].strip()
                if candidate:
                    hosts.add(candidate)
            return hosts

        hosts = set()
        if self.source_allowlist_file:
            file_path = Path(self.source_allowlist_file)
            if not file_path.is_absolute():
                file_path = get_repo_root() / file_path

            if file_path.exists() and file_path.suffix in {".yml", ".yaml"}:
                try:
                    with open(file_path, "r") as f:
                        catalog = yaml.safe_load(f) or {}
                        for item in catalog.get("approved_urls", []):
                            url = item.get("url", "")
                            if url:
                                from urllib.parse import urlparse
                                host = urlparse(url).netloc.lower()
                                if host:
                                    hosts.add(host)
                except Exception as e:
                    print(f"Warning: Failed to load source_allowlist_file: {e}")

        return hosts

    @property
    def allowlist_open(self) -> bool:
        return "*" in self.allowed_hosts

    @property
    def source_host_alias_map(self) -> dict[str, str]:
        out: dict[str, str] = {}
        if not self.source_host_aliases:
            return out
        for raw in self.source_host_aliases.split(","):
            item = raw.strip()
            if not item or "=" not in item:
                continue
            left, right = item.split("=", 1)
            src = left.strip().lower()
            dst = right.strip().lower()
            if src and dst:
                out[src] = dst
        return out

    @field_validator("output_dir", mode="before")
    @classmethod
    def normalize_output_dir(cls, value):
        if not value:
            return Path("./corpus")
        path = Path(value).expanduser()
        return path if path.is_absolute() else Path(path)

    @field_validator("mandate_generation_prompt_path", "risk_mapping_prompt_path", mode="before")
    @classmethod
    def normalize_prompt_path(cls, value):
        if not value: return None
        path = Path(value)
        return path if path.is_absolute() else get_repo_root() / path

    def require_source_allowlist(self) -> None:
        if not self.allowed_hosts:
            raise ValueError("SOURCE_ALLOWLIST must contain at least one host or '*'")

    def require_llm_config(self) -> None:
        if not self.google_cloud_project:
            raise ValueError(
                "PROJECT_NAME (or GOOGLE_CLOUD_PROJECT) is required for Gemini/Vertex mode"
            )
