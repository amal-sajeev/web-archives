from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Protocol

try:
    from google.api_core.exceptions import NotFound
except ImportError:
    class NotFound(Exception):
        pass

try:
    from google.api_core.exceptions import PreconditionFailed
except ImportError:
    class PreconditionFailed(Exception):
        pass


def _safe_key(key: str) -> str:
    key = key.replace("\\", "/").lstrip("/")
    parts = PurePosixPath(key).parts
    if not key or any(part in {"", ".", ".."} for part in parts):
        raise ValueError("Storage key must be a non-empty relative path without traversal")
    return "/".join(parts)


class Storage(Protocol):
    def write(self, key: str, content: str, *, if_absent: bool = False) -> str: ...
    def read(self, key: str) -> str | None: ...
    def exists(self, key: str) -> bool: ...
    def delete(self, key: str) -> bool: ...
    def list_keys(self, prefix: str = "", suffix: str = "") -> list[str]: ...


class LocalStorage:
    def __init__(self, root: Path):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        safe = _safe_key(key)
        p = (self.root / safe).resolve()
        try:
            p.relative_to(self.root)
        except ValueError as exc:
            raise ValueError("Storage key escapes output directory") from exc
        return p

    def write(self, key: str, content: str, *, if_absent: bool = False) -> str:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        if if_absent and p.exists():
            return str(p)
        tmp = p.with_name(f".{p.name}.tmp-{__import__('time').time_ns()}")
        try:
            with tmp.open("w", encoding="utf-8") as fh:
                fh.write(content)
                fh.flush()
                __import__('os').fsync(fh.fileno())
            tmp.replace(p)
        finally:
            tmp.unlink(missing_ok=True)
        return str(p)

    def read(self, key: str) -> str | None:
        p = self._path(key)
        return p.read_text(encoding="utf-8") if p.exists() else None

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def delete(self, key: str) -> bool:
        p = self._path(key)
        if not p.exists():
            return False
        p.unlink()
        return True

    def list_keys(self, prefix: str = "", suffix: str = "") -> list[str]:
        out: list[str] = []
        base = self.root
        for p in base.rglob("*"):
            if not p.is_file():
                continue
            rel = p.relative_to(base).as_posix()
            if prefix and not rel.startswith(prefix):
                continue
            if suffix and not rel.endswith(suffix):
                continue
            out.append(rel)
        return sorted(out)


class GCSStorage:
    def __init__(self, bucket: str, prefix: str = ""):
        if not bucket.strip():
            raise ValueError("GCS bucket name cannot be empty")
        from google.cloud import storage
        import google.auth
        
        try:
            credentials, project = google.auth.default()
        except Exception:
            # Fallback to default credentials chain if explicit credentials unavailable
            credentials, project = None, None
        
        self.client = storage.Client(credentials=credentials, project=project)
        self.bucket = self.client.bucket(bucket)
        self.prefix = prefix.strip("/")
        if self.prefix and any(part in {".", ".."} for part in PurePosixPath(self.prefix).parts):
            raise ValueError("GCS prefix cannot contain traversal segments")

    def _blob_name(self, key: str) -> str:
        safe = _safe_key(key)
        return f"{self.prefix}/{safe}" if self.prefix else safe

    def write(self, key: str, content: str, *, if_absent: bool = False) -> str:
        blob = self.bucket.blob(self._blob_name(key))
        uri = f"gs://{self.bucket.name}/{blob.name}"
        if if_absent and blob.exists():
            return uri
        kwargs = {"if_generation_match": 0} if if_absent else {}
        try:
            blob.upload_from_string(content, content_type="text/plain; charset=utf-8", **kwargs)
        except PreconditionFailed:
            if if_absent:
                return uri
            raise
        return uri

    def read(self, key: str) -> str | None:
        blob = self.bucket.blob(self._blob_name(key))
        try:
            return blob.download_as_text()
        except NotFound:
            return None

    def exists(self, key: str) -> bool:
        return self.bucket.blob(self._blob_name(key)).exists()

    def delete(self, key: str) -> bool:
        blob = self.bucket.blob(self._blob_name(key))
        if not blob.exists():
            return False
        blob.delete()
        return True

    def list_keys(self, prefix: str = "", suffix: str = "") -> list[str]:
        safe_prefix = _safe_key(prefix) if prefix else ""
        blob_prefix = f"{self.prefix}/{safe_prefix}" if self.prefix and safe_prefix else (self.prefix or safe_prefix)
        out: list[str] = []
        for blob in self.client.list_blobs(self.bucket, prefix=blob_prefix or None):
            name = blob.name
            if self.prefix:
                if not name.startswith(self.prefix + "/"):
                    continue
                rel = name[len(self.prefix) + 1 :]
            else:
                rel = name
            if safe_prefix and not rel.startswith(safe_prefix):
                continue
            if suffix and not rel.endswith(suffix):
                continue
            out.append(rel)
        return sorted(out)


def make_storage(settings) -> Storage:
    if settings.gcs_bucket:
        return GCSStorage(settings.gcs_bucket, settings.gcs_prefix)
    return LocalStorage(settings.output_dir)
