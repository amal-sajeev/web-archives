import hashlib
import re

from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

from config.settings import Settings
from tools.network import canonicalize, fetch, host

def deterministic_quality(raw: str, md: str) -> dict:
    def norm(s): return re.sub(r"[^a-z0-9]+", " ", s.lower()).split()
    a, b = norm(raw), norm(md)
    if not a or not b:
        return {"score": 0.0, "coverage": 0.0, "length_ratio": 0.0, "missing_tail": True}
    ca, cb = Counter(a), Counter(b)
    overlap = sum(min(v, cb[k]) for k, v in ca.items())
    coverage = overlap / max(1, len(a))
    ratio = len(b) / len(a)
    ratio_score = max(0.0, 1.0 - min(abs(1 - ratio), .8) / .8)
    # Compare the final 5% of normalized source tokens to catch truncation.
    tail = a[max(0, int(len(a) * .95)):]
    tail_hits = sum(1 for t in tail if t in cb) / max(1, len(tail))
    missing_tail = tail_hits < .80
    score = .70 * coverage + .20 * ratio_score + .10 * tail_hits
    return {
        "score": round(score, 4), "coverage": round(coverage, 4),
        "length_ratio": round(ratio, 4), "tail_coverage": round(tail_hits, 4),
        "missing_tail": missing_tail,
    }

def _publisher_matches_host(publisher: str, source_host: str) -> bool:
    words = [w for w in re.findall(r"[a-z]+", publisher.lower()) if len(w) > 2]
    labels = [w for w in source_host.lower().split(".") if w]
    if not words or not labels:
        return False
    if any(word in labels for word in words):
        return True
    acronym = "".join(word[0] for word in words)
    return any(label == acronym or label.startswith(acronym) for label in labels)


def authority_assessment(url: str, identity: dict, settings: Settings) -> tuple[float, list[str]]:
    reasons: list[str] = []
    source_host = host(url)
    h = settings.source_host_alias_map.get(source_host, source_host)
    score = 0.0
    if h != source_host:
        reasons.append(f"authority host mapped from clone host: {source_host} -> {h}")
    allow = set(settings.allowed_hosts)
    if settings.allowlist_open or "*" in allow:
        score += .35
        reasons.append("host accepted under open acquisition policy")
    elif h in allow:
        score += .45; reasons.append("host is explicitly allowlisted")
    elif any(h.endswith("." + x) for x in allow if x != "*"):
        score += .40; reasons.append("host is a subdomain of an allowlisted authority")
    else:
        reasons.append("host is not allowlisted")
    publisher = identity.get("publisher") or ""
    if _publisher_matches_host(publisher, h):
        score += .17; reasons.append("publisher metadata matches source-host naming")
    elif publisher:
        score += .05
    else:
        score += .03
    if identity.get("authority_class") == "instrument":
        score += .25; reasons.append("classifier identified an authoritative instrument")
    elif identity.get("authority_class") == "guidance":
        score += .10; reasons.append("classified as official guidance, not an instrument")
    return round(min(score, 1.0), 4), reasons

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def slugify(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9]+", "-", value.lower()).strip("-")
    return value[:180] or "document"

def bounded_fetch(urls: list[str], settings: Settings) -> list[dict]:
    out: list[dict] = []
    with ThreadPoolExecutor(max_workers=max(1, settings.max_concurrent_fetches)) as ex:
        futures = {ex.submit(fetch, u, settings): u for u in urls}
        for fut in as_completed(futures):
            u = futures[fut]
            try:
                out.append(fut.result())
            except (ValueError, RuntimeError, OSError, TypeError) as e:
                out.append({"requested_url": canonicalize(u), "error": str(e)})
    return out
