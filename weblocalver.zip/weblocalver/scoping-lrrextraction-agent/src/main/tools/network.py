from __future__ import annotations

import time
import re
from datetime import datetime, timezone
from urllib import robotparser
from urllib.parse import urldefrag, urljoin, urlparse
import httpx
try:
    from langchain_core.tools import tool
except ImportError:
    def tool(fn):
        return fn
from runtime.observability import timed
from config.settings import Settings

_ROBOTS_CACHE: dict[str, robotparser.RobotFileParser | None] = {}

def host(url: str) -> str:
    return urlparse(url).netloc.lower().split(":", 1)[0]

def allowed(url: str, settings: Settings) -> bool:
    if urlparse(url).scheme not in {"http", "https"}:
        return False
    # Open mode: no explicit allowlist configured (or SOURCE_ALLOWLIST=*).
    if settings.allowlist_open:
        return True
    allow = set(settings.allowed_hosts)
    if "*" in allow:
        return True
    h = host(url)
    h = settings.source_host_alias_map.get(h, h)
    return any(h == a or h.endswith("." + a) for a in allow if a != "*")

def canonicalize(url: str) -> str:
    url, _ = urldefrag(url.strip())
    p = urlparse(url)
    path = re.sub(r"/{2,}", "/", p.path or "/")
    if path != "/":
        path = path.rstrip("/")
    return p._replace(fragment="", path=path).geturl()

def robots_allowed(url: str, settings: Settings) -> bool:
    if not settings.respect_robots_txt:
        return True
    p = urlparse(url)
    root = f"{p.scheme}://{p.netloc}"
    if root not in _ROBOTS_CACHE:
        rp = robotparser.RobotFileParser()
        robots_url = root + "/robots.txt"
        rp.set_url(robots_url)
        try:
            with httpx.Client(timeout=settings.request_timeout_seconds, headers={"User-Agent": settings.user_agent}) as client:
                resp = client.get(robots_url, follow_redirects=True)
            if resp.status_code >= 400:
                _ROBOTS_CACHE[root] = None
            else:
                rp.parse(resp.text.splitlines())
                _ROBOTS_CACHE[root] = rp
        except (httpx.RequestError, OSError, TimeoutError, ValueError):
            # Unavailable robots.txt is treated as allow, while explicit denial is enforced.
            _ROBOTS_CACHE[root] = None
    rp = _ROBOTS_CACHE[root]
    return True if rp is None else rp.can_fetch(settings.user_agent, url)

def _request(url: str, settings: Settings) -> dict:
    requested = canonicalize(url)
    if not allowed(requested, settings):
        raise ValueError(f"Host is not allowlisted: {host(requested)}")
    if not robots_allowed(requested, settings):
        raise ValueError(f"robots.txt disallows fetch: {requested}")
    last: Exception | None = None
    for attempt in range(settings.max_retries):
        try:
            with httpx.Client(
                follow_redirects=False,
                timeout=settings.request_timeout_seconds,
                headers={"User-Agent": settings.user_agent, "Accept": "text/html,application/pdf;q=0.9,*/*;q=0.5"},
            ) as client:
                current = requested
                for _ in range(settings.max_redirects + 1):
                    if not allowed(current, settings):
                        raise ValueError(f"Redirect target is not allowlisted: {host(current)}")
                    if not robots_allowed(current, settings):
                        raise ValueError(f"robots.txt disallows redirect target: {current}")
                    with client.stream("GET", current) as r:
                        if r.status_code in {301, 302, 303, 307, 308}:
                            location = r.headers.get("location")
                            if not location:
                                raise ValueError("Redirect response has no Location header")
                            current = canonicalize(urljoin(current, location))
                            continue
                        r.raise_for_status()
                        chunks: list[bytes] = []
                        total = 0
                        for chunk in r.iter_bytes():
                            total += len(chunk)
                            if total > settings.max_bytes:
                                raise ValueError(f"Response exceeds MAX_BYTES={settings.max_bytes}")
                            chunks.append(chunk)
                        final_url = canonicalize(str(r.url))
                        return {
                            "requested_url": requested, "final_url": final_url,
                            "content_type": r.headers.get("content-type", ""),
                            "content": b"".join(chunks), "status_code": r.status_code,
                            "headers": dict(r.headers),
                            "retrieved_at": datetime.now(timezone.utc).isoformat(),
                        }
                raise ValueError(f"Too many redirects (>{settings.max_redirects})")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in {408, 425, 429, 500, 502, 503, 504}:
                last = RuntimeError(str(exc))
                if attempt < settings.max_retries - 1:
                    time.sleep(settings.backoff_base_seconds * (2 ** attempt))
            else:
                last = RuntimeError(str(exc))
                break
        except (httpx.RequestError, TimeoutError, OSError) as exc:
            if isinstance(exc, httpx.ProxyError):
                last = RuntimeError(
                    "HTTP proxy authentication failed (407). "
                    "Configure authenticated proxy access for outbound web fetches."
                )
            else:
                last = RuntimeError(str(exc))
            if attempt < settings.max_retries - 1:
                time.sleep(settings.backoff_base_seconds * (2 ** attempt))
    if last:
        raise last
    raise RuntimeError("fetch failed")

def fetch(url: str, settings: Settings) -> dict:
    with timed("fetch", url=canonicalize(url)):
        return _request(url, settings)

def fetch_url(url: str) -> dict:
    """Fetch an approved HTTP(S) source and return JSON-safe metadata plus hex bytes."""
    settings = Settings()
    r = fetch(url, settings)
    return {**{k: v for k, v in r.items() if k != "content"}, "bytes_hex": r["content"].hex()}
