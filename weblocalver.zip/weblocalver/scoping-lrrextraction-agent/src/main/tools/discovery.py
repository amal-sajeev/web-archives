from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from models.base import SourceCandidate
from config.settings import Settings

from .network import allowed, canonicalize

def _regulatory_score(href: str, text: str, terms: list[str] | None = None) -> float:
    low = f"{href} {text}".lower()
    weighted = {
        "master direction": .45, "regulation": .35, "rule": .30, "statute": .35,
        "directive": .25, "code": .20, "part": .15, "article": .15,
        "download": .12, "pdf": .12, "legislation": .30, "supervision": .18,
        "reporting": .18, "disclosure": .18, "amendment": .22, "effective": .15,
    }
    if terms:
        weighted.update({t.lower(): max(weighted.get(t.lower(), 0), .20) for t in terms})
    score = sum(w for term, w in weighted.items() if term in low)
    return min(score, 1.0)

def discover_links(base_url: str, html: str, settings: Settings, terms: list[str] | None = None) -> list[dict]:
    soup = BeautifulSoup(html, "lxml")
    candidates: list[dict] = []
    base = urlparse(base_url)
    base_host = (base.hostname or "").lower()
    mirror_upstream = settings.source_host_alias_map.get(base_host)
    for a in soup.find_all("a", href=True):
        href = canonicalize(urljoin(base_url, a["href"]))
        if mirror_upstream:
            parsed = urlparse(href)
            discovered_host = (parsed.hostname or "").lower()
            if discovered_host == mirror_upstream or discovered_host.endswith("." + mirror_upstream):
                href = canonicalize(parsed._replace(scheme=base.scheme, netloc=base.netloc).geturl())
        if not allowed(href, settings):
            continue
        text = " ".join(a.stripped_strings)
        kind = "pdf" if ("pdf" in text.lower() or href.lower().endswith(".pdf")) else "html"
        score = _regulatory_score(href, text, terms)
        candidates.append(SourceCandidate(
            url=href, title=text or None, kind=kind, relevance=score,
            reason="matched regulatory/download signals", authoritative=True,
        ).model_dump(mode="json"))
    candidates.sort(key=lambda x: (x["relevance"], bool(x["title"])), reverse=True)
    ded: dict[str, dict] = {}
    for c in candidates:
        ded.setdefault(c["url"], c)
    return list(ded.values())[:settings.max_candidates_per_page]
