import re

import pymupdf
import trafilatura
from bs4 import BeautifulSoup
from markdownify import markdownify

from config.settings import Settings
from tools.network import allowed, canonicalize, host, robots_allowed

def _trim_leading_navigation(md: str) -> str:
    heading_match = re.search(r"(?m)^#\s+(?:\d+[A-Za-z0-9.()\- ]*|FINRA Rule \d+[A-Za-z0-9.()\- ]*)$", md)
    if heading_match:
        return md[heading_match.start():]
    return md


def _normalize_finra_artifacts(md: str) -> str:
    md = re.sub(r"/index\.php/", "/", md)
    md = re.sub(r"(?mi)^\s*[•*\-\s]*Supplementary Material:\s*-+\s*$", "## Supplementary Material", md)
    md = re.sub(r"(?mi)^\s*[^\w\r\n]*Supplementary Material:\s*-+\s*$", "## Supplementary Material", md)
    md = re.sub(r"(?mi)^\s*The Rule\s+Notices\s+Guidance\s+News Releases\s+FAQs\s*$", "", md)
    md = re.sub(r"(?mi)^\s{0,3}#{1,6}\s+No Results Found\s*$", "", md)
    # Flatten one-column markdown tables that are usually rendered as prose blocks
    # on FINRA rule pages (e.g., amendment history blocks).
    md = re.sub(
        r"(?ms)^\|\s*([^|\n]+?)\s*\|\n\|\s*[-:]+\s*\|\n((?:\|\s*[^|\n]*\s*\|\n)+)",
        lambda m: m.group(1).strip() + "\n\n" + "\n".join(
            re.sub(r"^\|\s*|\s*\|$", "", row).strip()
            for row in m.group(2).splitlines()
            if row.strip()
        ) + "\n",
        md,
    )
    return _trim_leading_navigation(md)

def extract_html(html: str) -> tuple[str, list[str]]:
    warnings: list[str] = []
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "noscript", "svg", "canvas", "nav", "footer"]):
        tag.decompose()
    # ASP.NET and similar sites wrap the document body in <form>; unwrap instead of dropping content.
    for form in soup.find_all("form"):
        form.unwrap()
    main = soup.find("main") or soup.find("article")
    if main is None:
        extracted = trafilatura.extract(html, include_links=False, include_tables=True, favor_precision=True) if trafilatura else None
        if extracted:
            return clean_markdown(extracted), warnings
        main = soup.body or soup
        warnings.append("No semantic main/article element; used body fallback")
    md = markdownify(str(main), heading_style="ATX", bullets="-")
    md = _normalize_finra_artifacts(md)
    md = clean_markdown(md)
    if len(md) < 500:
        warnings.append("HTML extraction produced unusually little text")
    return md, warnings

def _ocr_pdf(data: bytes, settings: Settings, existing_pages: dict[int, str] | None = None) -> tuple[str, list[str], int]:
    try:
        import pytesseract
        from PIL import Image
        from io import BytesIO
    except ImportError as exc:
        raise RuntimeError("OCR requested but pytesseract/Pillow are not installed") from exc
    doc = pymupdf.open(stream=data, filetype="pdf")
    existing_pages = existing_pages or {}
    parts: list[str] = []
    ocr_pages = 0
    for i, page in enumerate(doc, start=1):
        text = existing_pages.get(i, "").strip()
        if not text:
            pix = page.get_pixmap(dpi=settings.ocr_dpi, alpha=False)
            image = Image.open(BytesIO(pix.tobytes("png")))
            text = pytesseract.image_to_string(image, lang=settings.ocr_language).strip()
            ocr_pages += 1
        parts.append(f"\n<!-- source-page: {i} -->\n\n{text}")
    warnings = [f"OCR applied to {ocr_pages} text-empty PDF pages"] if ocr_pages else []
    return clean_markdown("\n".join(parts)), warnings, doc.page_count

def extract_pdf(data: bytes, settings: Settings | None = None) -> tuple[str, list[str], int]:
    settings = settings or Settings()
    doc = pymupdf.open(stream=data, filetype="pdf")
    parts: list[str] = []
    page_text: dict[int, str] = {}
    text_pages = 0
    for i, page in enumerate(doc, start=1):
        text = page.get_text("text").strip()
        page_text[i] = text
        text_pages += bool(text)
        parts.append(f"\n<!-- source-page: {i} -->\n\n{text}")
    warnings: list[str] = []
    if doc.page_count and text_pages / doc.page_count < .8:
        warnings.append(f"Only {text_pages}/{doc.page_count} PDF pages yielded text")
        if settings.enable_ocr:
            return _ocr_pdf(data, settings, page_text)
        warnings.append("OCR is disabled; scanned pages may be incomplete")
    return clean_markdown("\n".join(parts)), warnings, doc.page_count

def browser_extract(url: str, settings: Settings) -> tuple[str, list[str]]:
    if not settings.enable_browser_rendering:
        raise RuntimeError("Browser rendering is disabled")
    if not allowed(url, settings):
        raise ValueError(f"Browser URL is not allowlisted: {host(url)}")
    if not robots_allowed(url, settings):
        raise ValueError(f"robots.txt disallows browser fetch: {url}")
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("Browser rendering requested but playwright is not installed") from exc
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        try:
            page = browser.new_page(user_agent=settings.user_agent)
            response = page.goto(url, wait_until="networkidle", timeout=int(settings.browser_timeout_seconds * 1000))
            if response is None:
                raise RuntimeError("Browser navigation returned no response")
            final_url = canonicalize(page.url)
            if not allowed(final_url, settings):
                raise ValueError(f"Browser navigation redirected to non-allowlisted host: {host(final_url)}")
            html = page.content()
        finally:
            browser.close()
    text, warnings = extract_html(html)
    warnings.append("HTML obtained using browser rendering")
    return text, warnings

def clean_markdown(text: str) -> str:
    text = _normalize_finra_artifacts(text)
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip() + "\n"
