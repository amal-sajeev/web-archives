import re
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from models.base import SourceCandidate
from config.settings import Settings
from tools.network import allowed, canonicalize, host

_URL_RE = re.compile(r"(?:https?://|/)[^\s'\"<>\\)]+", re.IGNORECASE)


def _candidate(base_url: str, raw_url: str, title: str, reason: str, settings: Settings) -> dict | None:
    href = raw_url.strip()
    if not href or href.lower().startswith(("javascript:", "mailto:", "tel:", "data:")):
        return None
    url = canonicalize(urljoin(base_url, href))
    base = urlparse(base_url)
    base_host = (base.hostname or "").lower()
    mirror_upstream = settings.source_host_alias_map.get(base_host)
    if mirror_upstream:
        parsed = urlparse(url)
        discovered_host = (parsed.hostname or "").lower()
        if discovered_host == mirror_upstream or discovered_host.endswith("." + mirror_upstream):
            url = canonicalize(parsed._replace(scheme=base.scheme, netloc=base.netloc).geturl())
    if not allowed(url, settings):
        return None
    low = f"{url} {title}".lower()
    kind = "pdf" if ".pdf" in low or "pdf" in low else "html"
    score = 0.35 if kind == "pdf" else 0.10
    if any(term in low for term in ("download", "direction", "circular", "notification", "master")):
        score += 0.20
    return SourceCandidate(
        url=url, title=title or None, kind=kind, relevance=min(score, 1.0),
        reason=reason, authoritative=True,
    ).model_dump(mode="json")


def discover_browser_dom(base_url: str, html: str, settings: Settings) -> list[dict]:
    soup = BeautifulSoup(html, "lxml")
    found: list[dict] = []
    for tag in soup.find_all(("a", "iframe", "frame", "object", "embed", "form", "link")):
        attrs = tag.attrs
        for name in ("href", "src", "data", "action"):
            value = attrs.get(name)
            if isinstance(value, str):
                item = _candidate(base_url, value, tag.get_text(" ", strip=True), f"browser DOM {name}", settings)
                if item:
                    found.append(item)
        for name, value in attrs.items():
            if name.startswith("data-") and isinstance(value, str) and ("/" in value or value.lower().startswith("http")):
                item = _candidate(base_url, value, tag.get_text(" ", strip=True), f"browser DOM {name}", settings)
                if item:
                    found.append(item)
    for tag in soup.find_all(("a", "button", "input")):
        onclick = tag.get("onclick") or tag.get("data-url") or tag.get("data-href")
        if not isinstance(onclick, str):
            continue
        for raw in _URL_RE.findall(onclick):
            item = _candidate(base_url, raw.rstrip("\'\""), tag.get_text(" ", strip=True), "browser event URL", settings)
            if item:
                found.append(item)
    for script in soup.find_all("script"):
        body = script.string or script.get_text(" ", strip=True)
        for raw in _URL_RE.findall(body):
            item = _candidate(base_url, raw.rstrip("\'\""), "script resource", "browser script URL", settings)
            if item:
                found.append(item)
    return _dedupe(found)


def _dedupe(items: list[dict]) -> list[dict]:
    best: dict[str, dict] = {}
    for item in items:
        url = item["url"]
        old = best.get(url)
        if old is None or item.get("relevance", 0) > old.get("relevance", 0):
            best[url] = item
    return sorted(best.values(), key=lambda item: (item.get("relevance", 0), item.get("title") is not None), reverse=True)


def discover_browser_resources(url: str, settings: Settings) -> list[dict]:
    if not settings.enable_browser_rendering:
        raise RuntimeError("Browser rendering is disabled")
    if not allowed(url, settings):
        raise ValueError(f"Browser URL is not allowlisted: {host(url)}")
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("Browser resource discovery requested but playwright is not installed") from exc
    network: list[dict] = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        try:
            context = browser.new_context(user_agent=settings.user_agent)
            context.route("**/*", lambda route: route.continue_() if allowed(route.request.url, settings) else route.abort())
            page = context.new_page()
            page.on("response", lambda response: _record_response(response, network, settings))
            response = page.goto(url, wait_until="networkidle", timeout=int(settings.browser_timeout_seconds * 1000))
            if response is None:
                raise RuntimeError("Browser navigation returned no response")
            final_url = canonicalize(page.url)
            if not allowed(final_url, settings):
                raise ValueError(f"Browser navigation redirected to non-allowlisted host: {host(final_url)}")
            dom = discover_browser_dom(final_url, page.content(), settings)
        finally:
            browser.close()
    return _dedupe(dom + network)


def _record_response(response, network: list[dict], settings: Settings) -> None:
    url = canonicalize(response.url)
    if not allowed(url, settings):
        return
    content_type = response.headers.get("content-type", "").lower()
    disposition = response.headers.get("content-disposition", "").lower()
    if "application/pdf" in content_type or ".pdf" in url.lower() or ".pdf" in disposition:
        title = url.rsplit("/", 1)[-1]
        item = _candidate(url, url, title, "browser network PDF response", settings)
        if item:
            network.append(item)
