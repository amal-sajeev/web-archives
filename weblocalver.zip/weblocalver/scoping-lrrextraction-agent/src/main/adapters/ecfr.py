import re
from config.adapters_config import get_adapter_config
from source.classification import classify_source_deterministic
from processing.parser import DocumentIR, build_ir_from_text
from models.domain import LegalAuthorityLevel, SourceAuthority, SourceClassification, SourceRole, SourceSnapshot
from source.versioning import VersionResolution, resolve_version
from adapters.base import register_adapter

_CONFIG = get_adapter_config("ecfr")
_TITLE_RE = re.compile(_CONFIG["identifier_patterns"]["title"], re.I)
_PART_RE = re.compile(_CONFIG["identifier_patterns"]["part"], re.I)


@register_adapter
class EcfrAdapter:
    """Adapter for eCFR (Electronic Code of Federal Regulations)."""

    name = "ecfr"

    def matches(self, source: SourceSnapshot) -> bool:
        return any(
            domain.lower() in source.source_url.lower()
            for domain in _CONFIG["domain_patterns"]
        )

    def classify(self, source: SourceSnapshot) -> SourceClassification:
        c = classify_source_deterministic(source.source_url, source.source_title, source.content_type)
        c.source_authority = SourceAuthority.GOVERNMENT
        c.legal_authority_level = LegalAuthorityLevel.PRIMARY
        c.operative_text = True
        m = _TITLE_RE.search(source.source_url)
        if m:
            c.identifier = f"Title {m.group(1)}"
            c.classification_reasons.append(f"eCFR Title {m.group(1)} identified from URL")
        if _PART_RE.search(source.source_url):
            c.source_role = SourceRole.INSTRUMENT
            c.classification_reasons.append("eCFR Part-level URL -> instrument")
        return c

    def parse_structure(self, raw_text: str, source_url: str, document_id: str) -> DocumentIR:
        ir = build_ir_from_text(document_id, source_url, raw_text)
        for node in ir.nodes:
            low = (node.title or "").lower()
            if "part" in low:
                node.node_type = "part"
            elif "subpart" in low:
                node.node_type = "subpart"
            elif "section" in low:
                node.node_type = "section"
        return ir

    def expected_structure(self) -> list[str]:
        return ["Title", "Chapter", "Part", "Subpart", "Section", "Subsection"]

    def discover_related(self, source: SourceSnapshot, raw_text: str) -> list[dict]:
        return []

    def resolve_version(self, document_id: str, url: str, raw_text: str) -> VersionResolution:
        return resolve_version(document_id, url, raw_text)
