from source.classification import classify_source_deterministic
from processing.parser import DocumentIR, build_ir_from_text
from models.domain import SourceClassification, SourceSnapshot
from source.versioning import VersionResolution, resolve_version


class GenericAdapter:
    """Fallback adapter for unrecognized sources."""

    name = "generic"

    def matches(self, source: SourceSnapshot) -> bool:
        return True

    def classify(self, source: SourceSnapshot) -> SourceClassification:
        return classify_source_deterministic(source.source_url, source.source_title, source.content_type)

    def parse_structure(self, raw_text: str, source_url: str, document_id: str) -> DocumentIR:
        return build_ir_from_text(document_id, source_url, raw_text)

    def expected_structure(self) -> list[str]:
        return ["document root", "sections", "paragraphs"]

    def discover_related(self, source: SourceSnapshot, raw_text: str) -> list[dict]:
        return []

    def resolve_version(self, document_id: str, url: str, raw_text: str) -> VersionResolution:
        return resolve_version(document_id, url, raw_text)

