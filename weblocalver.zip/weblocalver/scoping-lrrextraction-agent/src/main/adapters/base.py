from typing import Protocol, runtime_checkable

from processing.parser import DocumentIR
from models import SourceClassification, SourceSnapshot


@runtime_checkable
class RegulatorAdapter(Protocol):
    name: str

    def matches(self, source: SourceSnapshot) -> bool: ...
    def classify(self, source: SourceSnapshot) -> SourceClassification: ...
    def parse_structure(self, raw_text: str, source_url: str, document_id: str) -> DocumentIR: ...
    def expected_structure(self) -> list[str]: ...
    def discover_related(self, source: SourceSnapshot, raw_text: str) -> list[dict]: ...
    def resolve_version(self, document_id: str, url: str, raw_text: str): ...


_ADAPTERS: list[type] = []


def register_adapter(cls: type) -> type:
    if cls not in _ADAPTERS:
        _ADAPTERS.append(cls)
    return cls


def _ensure_adapters_loaded() -> None:
    from . import generic, finra, rbi, ecfr, fca  # noqa: F401


def get_adapter(source: SourceSnapshot) -> "RegulatorAdapter":
    """Return the best matching adapter for a source, falling back to GenericAdapter."""
    _ensure_adapters_loaded()
    from .generic import GenericAdapter
    for adapter_cls in _ADAPTERS:
        adapter = adapter_cls()
        if adapter.matches(source):
            return adapter
    return GenericAdapter()