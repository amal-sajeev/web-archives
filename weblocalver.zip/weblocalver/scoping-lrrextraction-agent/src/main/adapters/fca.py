import re

from urllib.parse import urljoin
from bs4 import BeautifulSoup

from tools.network import canonicalize
from config.adapters_config import get_adapter_config
from source.classification import classify_source_deterministic
from processing.parser import DocumentIR, build_ir_from_text
from models.domain import LegalAuthorityLevel, SourceAuthority, SourceClassification, SourceRole, SourceSnapshot
from source.versioning import VersionResolution, resolve_version
from adapters.base import register_adapter

_CONFIG = get_adapter_config("fca")
_HANDBOOK_RE = re.compile(r"/handbook", re.I)
_RESOURCES_RE = re.compile(r"/resources", re.I)
_PRM_RE = re.compile(r"/PRM|/Handbook/PRM", re.I)


@register_adapter
class FcaAdapter:
    """Adapter for Financial Conduct Authority sources."""

    name = "fca"

    def matches(self, source: SourceSnapshot) -> bool:
        return any(
            domain.lower() in source.source_url.lower()
            for domain in _CONFIG["domain_patterns"]
        )

    def classify(self, source: SourceSnapshot) -> SourceClassification:
        c = classify_source_deterministic(source.source_url, source.source_title, source.content_type)
        c.source_authority = SourceAuthority.PRIMARY_REGULATOR
        url_lower = source.source_url.lower()
        if _HANDBOOK_RE.search(url_lower) or _PRM_RE.search(url_lower):
            c.source_role = SourceRole.HANDBOOK
            c.legal_authority_level = LegalAuthorityLevel.REGULATORY_GUIDANCE
            c.operative_text = True
            c.classification_reasons.append("FCA Handbook/PRM identified")
        elif _RESOURCES_RE.search(url_lower):
            c.source_role = SourceRole.RESOURCE_HUB
            c.legal_authority_level = LegalAuthorityLevel.CONTEXTUAL
            c.operative_text = False
            c.classification_reasons.append("FCA resource hub identified")
        elif "/news" in url_lower or "press-release" in url_lower:
            c.source_role = SourceRole.TOPIC_PAGE
            c.legal_authority_level = LegalAuthorityLevel.CONTEXTUAL
            c.classification_reasons.append("FCA news/press release identified as topic page")
        elif "consumer" in (source.source_title or "").lower() or "market abuse" in (source.source_title or "").lower():
            c.source_role = SourceRole.TOPIC_PAGE
            c.legal_authority_level = LegalAuthorityLevel.CONTEXTUAL
            c.classification_reasons.append("FCA topic page identified from title")
        return c

    def parse_structure(self, raw_text: str, source_url: str, document_id: str) -> DocumentIR:
        ir = build_ir_from_text(document_id, source_url, raw_text)
        for node in ir.nodes:
            low = (node.title or "").lower()
            if "module" in low:
                node.node_type = "chapter"
            elif "chapter" in low:
                node.node_type = "chapter"
            elif "annex" in low:
                node.node_type = "annex"
        return ir

    def expected_structure(self) -> list[str]:
        return ["module/chapter", "section", "rule/paragraph", "annex/appendix"]

    def discover_related(self, source: SourceSnapshot, raw_text: str) -> list[dict]:
        candidates: list[dict] = []
        soup = BeautifulSoup(raw_text, "lxml")
        for a in soup.find_all("a", href=True):
            href = a.get("href", "")
            text = a.get_text(strip=True)
            if any(k in href.lower() for k in ("legislation", "handbook", "rule", "regulation")):
                candidates.append({
                    "url": canonicalize(urljoin(source.source_url, href)),
                    "title": text,
                    "reason": "linked from FCA page",
                })
        return candidates

    def resolve_version(self, document_id: str, url: str, raw_text: str) -> VersionResolution:
        return resolve_version(document_id, url, raw_text)
