import re
from config.adapters_config import get_adapter_config
from source.classification import classify_source_deterministic
from processing.parser import DocumentIR, build_ir_from_text
from models.domain import LegalAuthorityLevel, SourceAuthority, SourceClassification, SourceRole, SourceSnapshot
from source.versioning import VersionResolution, resolve_version
from adapters.base import register_adapter

_CONFIG = get_adapter_config("finra")
_RULE_RE = re.compile(_CONFIG["identifier_patterns"]["rule"], re.I)
_AMENDMENT_RE = re.compile(_CONFIG["identifier_patterns"]["amendment"], re.I)


@register_adapter
class FinraAdapter:
    """Adapter for FINRA rule pages."""

    name = "finra"

    def matches(self, source: SourceSnapshot) -> bool:
        return any(
            domain.lower() in source.source_url.lower()
            for domain in _CONFIG["domain_patterns"]
        )

    def classify(self, source: SourceSnapshot) -> SourceClassification:
        c = classify_source_deterministic(source.source_url, source.source_title, source.content_type)
        if _RULE_RE.search(source.source_url):
            c.source_role = SourceRole.INSTRUMENT
            c.source_authority = SourceAuthority.SRO
            c.legal_authority_level = LegalAuthorityLevel.DELEGATED
            c.operative_text = True
            m = _RULE_RE.search(source.source_url)
            if m:
                c.identifier = f"FINRA Rule {m.group(1)}"
                c.classification_reasons.append(f"FINRA rule number extracted: {m.group(1)}")
        return c

    def parse_structure(self, raw_text: str, source_url: str, document_id: str) -> DocumentIR:
        ir = build_ir_from_text(document_id, source_url, raw_text)
        # FINRA-specific: mark supplementary material and amendment history nodes
        for node in ir.nodes:
            low = (node.title or "").lower()
            if "supplementary" in low:
                node.node_type = "supplementary_material"
            elif "amendment" in low or "history" in low:
                node.node_type = "amendment_history"
        return ir

    def expected_structure(self) -> list[str]:
        return [
            "rule heading",
            "subsections (a) through (f)",
            "supplementary material",
            "amendment history",
        ]

    def discover_related(self, source: SourceSnapshot, raw_text: str) -> list[dict]:
        candidates: list[dict] = []
        for m in _AMENDMENT_RE.finditer(raw_text):
            candidates.append({
                "url": f"https://www.finra.org/rules-guidance/rulebooks/finra-rules/{m.group(1)}",
                "title": f"SR-FINRA-{m.group(1)}",
                "reason": "amendment notice referenced in rule text",
            })
        return candidates

    def resolve_version(self, document_id: str, url: str, raw_text: str) -> VersionResolution:
        return resolve_version(document_id, url, raw_text)
