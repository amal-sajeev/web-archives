from urllib.parse import urljoin
from bs4 import BeautifulSoup

from tools.network import canonicalize
from config.adapters_config import get_adapter_config
from source.classification import classify_source_deterministic
from processing.parser import DocumentIR, build_ir_from_text
from models.domain import SourceAuthority, SourceClassification, SourceRole, SourceSnapshot
from source.versioning import VersionResolution, resolve_version
from adapters.base import register_adapter

_CONFIG = get_adapter_config("rbi")


@register_adapter
class RbiAdapter:
    """Adapter for Reserve Bank of India Master Directions and indices."""

    name = "rbi"

    def matches(self, source: SourceSnapshot) -> bool:
        return any(
            domain.lower() in source.source_url.lower()
            for domain in _CONFIG["domain_patterns"]
        )

    def classify(self, source: SourceSnapshot) -> SourceClassification:
        c = classify_source_deterministic(source.source_url, source.source_title, source.content_type)
        c.source_authority = SourceAuthority.PRIMARY_REGULATOR
        if "master direction" in (source.source_title or "").lower() or "/master-direction" in source.source_url.lower():
            c.source_role = SourceRole.INDEX
            c.operative_text = False
            c.classification_reasons.append("RBI Master Directions identified as index/catalog")
        return c

    def parse_structure(self, raw_text: str, source_url: str, document_id: str) -> DocumentIR:
        ir = build_ir_from_text(document_id, source_url, raw_text)
        for node in ir.nodes:
            low = (node.title or "").lower()
            if "chapter" in low:
                node.node_type = "chapter"
            elif "annex" in low or "appendix" in low:
                node.node_type = "annex" if "annex" in low else "appendix"
        return ir

    def expected_structure(self) -> list[str]:
        return ["chapter headings", "sections", "paragraphs", "annexes/appendices"]

    def discover_related(self, source: SourceSnapshot, raw_text: str) -> list[dict]:
        candidates: list[dict] = []
        soup = BeautifulSoup(raw_text, "lxml")
        for a in soup.find_all("a", href=True):
            href = a.get("href", "")
            if "master-direction" in href.lower() or "direction" in href.lower():
                candidates.append({
                    "url": canonicalize(urljoin(source.source_url, href)),
                    "title": a.get_text(strip=True),
                    "reason": "linked from RBI Master Directions index",
                })
        return candidates

    def resolve_version(self, document_id: str, url: str, raw_text: str) -> VersionResolution:
        return resolve_version(document_id, url, raw_text)
