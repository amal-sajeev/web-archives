import sys

from adapters.base import RegulatorAdapter, get_adapter
from adapters.ecfr import EcfrAdapter
from adapters.fca import FcaAdapter
from adapters.finra import FinraAdapter
from adapters.generic import GenericAdapter
from adapters.rbi import RbiAdapter

for _name in ("base", "ecfr", "fca", "finra", "generic", "rbi"):
    top_name = f"adapters.{_name}"
    main_name = f"main.adapters.{_name}"
    if top_name in sys.modules:
        sys.modules.setdefault(main_name, sys.modules[top_name])
    if main_name in sys.modules:
        sys.modules.setdefault(top_name, sys.modules[main_name])

__all__ = ["RegulatorAdapter", "get_adapter", "GenericAdapter", "FinraAdapter", "RbiAdapter", "EcfrAdapter", "FcaAdapter"]
