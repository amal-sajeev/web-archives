import re
from typing import Iterable
from uuid import uuid4
import logging

from fastapi import UploadFile

from config.settings import Settings
from tools.extraction import extract_pdf
from utils.gcs_utils import upload_text_to_gcs


def _normalize_request_id(request_id: str | None) -> str:
    if not request_id:
        return uuid4().hex
    normalized = str(request_id).strip()
    if not normalized:
        return uuid4().hex
    if normalized.lower().startswith("dbaware_review_"):
        normalized = normalized[len("dbaware_review_") :]
    return normalized


def _safe_pdf_filename(filename: str) -> str:
    if not filename:
        raise ValueError("Uploaded PDF is missing a filename")
    clean = filename.strip()
    if not clean.lower().endswith(".pdf"):
        raise ValueError(f"Unsupported file type for '{filename}'. Only PDF files are allowed.")
    return clean


def process_pdf_files(files: Iterable[UploadFile], request_id: str | None = None) -> dict:
    uploaded_files = list(files)
    if not uploaded_files:
        raise ValueError("At least one PDF file is required for PDF processing.")

    normalized_request_id = _normalize_request_id(request_id)
    request_folder = f"dbaware_review_{normalized_request_id}"
    output_key = f"{request_folder}/processing-data/llr-extracted/lrr_raw_data_{normalized_request_id}.md"

    logger = logging.getLogger(__name__)
    logger.info("Starting PDF processing: request_id=%s normalized_request_id=%s output_key=%s file_count=%s", request_id, normalized_request_id, output_key, len(uploaded_files))

    markdown_parts: list[str] = []
    warnings: list[str] = []
    settings = Settings()

    for file in uploaded_files:
        original_name = _safe_pdf_filename(file.filename or "")
        pdf_bytes = file.file.read()
        if not pdf_bytes:
            raise ValueError(f"Uploaded PDF '{original_name}' is empty")

        text, file_warnings, _page_count = extract_pdf(pdf_bytes, settings)
        markdown_parts.append(f"\n<!-- source-file: {original_name} -->\n\n{text.strip()}\n")
        if file_warnings:
            warnings.extend(f"{original_name}: {warning}" for warning in file_warnings)

    markdown = "\n".join(markdown_parts).strip() + "\n"
    if not markdown.strip():
        raise ValueError("No readable content was extracted from the uploaded PDF files.")

    uploaded_uri = upload_text_to_gcs(output_key, markdown, content_type="text/markdown; charset=utf-8")
    logger.info("PDF processing complete: request_id=%s output_key=%s gcs_uri=%s", request_id, output_key, uploaded_uri)

    return {
        "status": "success",
        "request_id": normalized_request_id,
        "output_path": output_key,
        "gcs_uri": uploaded_uri,
        "file_count": len(uploaded_files),
        "warnings": warnings,
        "output_format": "markdown",
    }
