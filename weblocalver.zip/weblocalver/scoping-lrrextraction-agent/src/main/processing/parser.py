import hashlib
import re
from models import DocumentIdentity, EvidenceSpan, SectionNode

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$")
_LABEL_RE = re.compile(r"^\(([a-z0-9]+)\)\s*(.*)")
_NUMBERED_RE = re.compile(r"^(\d+)\.\s*(.*)")
_ROMAN_RE = re.compile(r"^\(([ivxlcdm]+)\)\s*(.*)")
_RULE_RE = re.compile(r"^(\d{3,})\.\s*(.*)")

class DocumentIR:
    """Canonical intermediate representation between raw HTML/PDF and rendered output."""

    def __init__(self, document_id: str, source_url: str, raw_text: str, nodes: list[SectionNode] | None = None):
        self.document_id = document_id
        self.source_url = source_url
        self.raw_text = raw_text
        self.nodes: list[SectionNode] = nodes or []
        self.tables: list[str] = []
        self.links: list[dict] = []
        self.footnotes: list[str] = []
        self._index: dict[str, SectionNode] = {n.node_id: n for n in self.nodes}

    def add_node(self, node: SectionNode) -> None:
        self.nodes.append(node)
        self._index[node.node_id] = node
        if node.parent_id and node.parent_id in self._index:
            parent = self._index[node.parent_id]
            if node.node_id not in parent.children:
                parent.children.append(node.node_id)

    def get_node(self, node_id: str) -> SectionNode | None:
        return self._index.get(node_id)

    def root_nodes(self) -> list[SectionNode]:
        return [n for n in self.nodes if n.parent_id is None]

    def children_of(self, node_id: str) -> list[SectionNode]:
        return [self._index[cid] for cid in self._index.get(node_id, SectionNode(node_id="")).children if cid in self._index]

    def ir_sha256(self) -> str:
        payload = "|".join(f"{n.node_id}:{n.node_type}:{n.label or ''}:{n.title or ''}:{n.text[:80]}" for n in self.nodes)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict:
        return {
            "document_id": self.document_id,
            "source_url": self.source_url,
            "ir_sha256": self.ir_sha256(),
            "nodes": [n.model_dump(mode="json") for n in self.nodes],
            "tables": self.tables,
            "links": self.links,
            "footnotes": self.footnotes,
        }

    def render_markdown(self) -> str:
        lines: list[str] = []
        for node in self.root_nodes():
            _render_node(node, self, lines, 0)
        return "\n".join(lines).strip() + "\n"

def _render_node(node: SectionNode, ir: DocumentIR, lines: list[str], depth: int) -> None:
    prefix = "#" * min(depth + 1, 6)
    label_title = " ".join(s for s in [node.label, node.title] if s)
    if label_title:
        lines.append(f"{prefix} {label_title}")
        lines.append("")
    if node.text:
        lines.append(node.text.strip())
        lines.append("")
    for child in ir.children_of(node.node_id):
        _render_node(child, ir, lines, depth + 1)

def build_ir_from_text(document_id: str, source_url: str, raw_text: str) -> DocumentIR:
    """Parse extracted markdown-ish text into a canonical document IR."""
    ir = DocumentIR(document_id, source_url, raw_text)
    lines = raw_text.split("\n")
    stack: list[tuple[str, int]] = []  # (node_id, heading_level)
    seq = 0

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        # Markdown heading
        m = _HEADING_RE.match(stripped)
        if m:
            level = len(m.group(1))
            title = m.group(2).strip()
            seq += 1
            node_id = f"sec-{seq}"
            parent_id = None
            for pid, plvl in reversed(stack):
                if plvl < level:
                    parent_id = pid
                    break
            stack = [(pid, plvl) for pid, plvl in stack if plvl < level]
            stack.append((node_id, level))
            ir.add_node(SectionNode(
                node_id=node_id, parent_id=parent_id, ordinal=seq,
                title=title, node_type=_infer_type(title, level),
            ))
            continue

        # Rule number heading (e.g. "3110. Supervision")
        m = _RULE_RE.match(stripped)
        if m and not stack:
            seq += 1
            node_id = f"sec-{seq}"
            ir.add_node(SectionNode(
                node_id=node_id, parent_id=None, ordinal=seq,
                label=m.group(1), title=m.group(2).strip(),
                node_type="section",
            ))
            stack = [(node_id, 1)]
            continue

        # Labelled paragraph (a), (b), (1), (2), (i), (ii)
        m = _LABEL_RE.match(stripped) or _ROMAN_RE.match(stripped)
        if m and stack:
            seq += 1
            node_id = f"sec-{seq}"
            parent_id = stack[-1][0] if stack else None
            content = m.group(2).strip()
            ir.add_node(SectionNode(
                node_id=node_id, parent_id=parent_id, ordinal=seq,
                label=f"({m.group(1)})", title=None,
                node_type=_label_to_type(m.group(1)),
                text=content,
            ))
            continue

        m = _NUMBERED_RE.match(stripped)
        if m and stack:
            seq += 1
            node_id = f"sec-{seq}"
            parent_id = stack[-1][0] if stack else None
            content = m.group(2).strip()
            ir.add_node(SectionNode(
                node_id=node_id, parent_id=parent_id, ordinal=seq,
                label=f"({m.group(1)})", title=None,
                node_type="paragraph",
                text=content,
            ))
            continue

        # Body text: append to last node
        if stack:
            parent = ir.get_node(stack[-1][0])
            if parent:
                if parent.text:
                    parent.text += "\n" + stripped
                else:
                    parent.text = stripped

    if not ir.nodes:
        seq += 1
        ir.add_node(SectionNode(
            node_id="sec-1", parent_id=None, ordinal=1,
            title="Document", node_type="document", text=raw_text.strip(),
        ))

    return ir

def _infer_type(title: str, level: int) -> str:
    low = title.lower()
    if "supplementary" in low:
        return "supplementary_material"
    if "amendment" in low or "history" in low:
        return "amendment_history"
    if "annex" in low:
        return "annex"
    if "appendix" in low:
        return "appendix"
    if "part" in low:
        return "part"
    if "chapter" in low:
        return "chapter"
    if "subpart" in low:
        return "subpart"
    if level <= 1:
        return "document"
    if level == 2:
        return "section"
    return "subsection"

def _label_to_type(label: str) -> str:
    if re.match(r"^[ivxlcdm]+$", label):
        return "subparagraph"
    if label.isdigit():
        return "paragraph"
    return "subsection"
