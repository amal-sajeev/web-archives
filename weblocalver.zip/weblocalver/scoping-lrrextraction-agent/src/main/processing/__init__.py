from processing.parser import DocumentIR, build_ir_from_text

__all__ = ["DocumentIR", "build_ir_from_text"]
