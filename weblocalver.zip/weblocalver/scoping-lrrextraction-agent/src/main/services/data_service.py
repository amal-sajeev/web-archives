import logging
from live.data import get_live_data
from samples.data import get_sample_data
from config.settings import Settings

logger = logging.getLogger(__name__)


def get_data_snapshot() -> tuple[dict, str]:
    live = get_live_data()
    if live:
        return live, "live"

    logger.debug("No live data available; falling back to sample snapshot.")
    return get_sample_data(), "sample"


def find_record(collection: str, key: str, value: str):
    """Find a record in the current data snapshot."""
    data, data_source = get_data_snapshot()
    record = next((record for record in data.get(collection, []) if record.get(key) == value), None)

    if record and data_source == "sample":
        logger.debug(
            f"Found record in sample data: {collection}/{key}={value}. "
            "This may not reflect actual stored data."
        )

    return record
