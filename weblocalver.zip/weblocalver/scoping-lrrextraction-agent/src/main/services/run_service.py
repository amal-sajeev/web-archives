import asyncio
import logging
import threading

from runtime.runner import RUN_MANAGER
from risk_context.phase_3_mandate_generation import execute_phase_3
from risk_context.phase_4_validation_evaluation import execute_phase_4
from risk_context.rt_resolution import execute_phase_2

logger = logging.getLogger(__name__)


def _run_counts(run_state: dict) -> tuple[int, int]:
    result = run_state.get("result") or {}
    accepted = len(result.get("outputs") or [])
    rejected = len(result.get("errors") or [])
    return accepted, rejected


def _base_live_run_payload(run_state: dict) -> dict:
    accepted, rejected = _run_counts(run_state)
    return {
        "run_id": run_state["run_id"],
        "objective": run_state["objective"],
        "status": run_state["status"],
        "step": run_state["step"],
        "duration_ms": 0,
        "sources": 0,
        "documents": 0,
        "accepted": accepted,
        "review": 0,
        "rejected": rejected,
        "created_at": run_state["created_at"],
        "live": True,
    }


def list_active_runs() -> list[dict]:
    return RUN_MANAGER.list_active()


def get_active_run(run_id: str):
    return RUN_MANAGER.get(run_id)


def start_run(*, seeds: list[str], objective: str | None, resume: str | None, request_id: str | None = None):
    return RUN_MANAGER.start(seeds=seeds, objective=objective, resume=resume, request_id=request_id)


def serialize_live_run_summary(live_run: dict) -> dict:
    return _base_live_run_payload(live_run)


def serialize_live_run_detail(snapshot: dict) -> dict:
    payload = _base_live_run_payload(snapshot)
    payload["error"] = snapshot.get("error")
    payload["seeds"] = snapshot.get("seeds")
    return payload


def serialize_live_events(history: list[dict]) -> list[dict]:
    return [
        {
            "step": event.get("step", index + 1),
            "action": event.get("action") or event.get("event") or event.get("node") or "event",
            "target": event.get("target"),
            "status": "error" if event.get("event") in {"run_error", "agent_action_failed"} else "ok",
            "details": event.get("reason") or event.get("details") or event.get("error") or "",
            "error_type": event.get("error_type"),
            "duration_ms": event.get("duration_ms", 0),
            "issues": [event["error"]] if event.get("error") else [],
            "raw": event,
        }
        for index, event in enumerate(history)
    ]


async def trigger_downstream_phases(request_id: str | None) -> None:
    """Schedule Phase 2/3/4 work in the background without blocking the request response."""
    effective_request_id = (request_id or "").strip()
    if not effective_request_id:
        logger.warning("No request_id available for downstream phase trigger; skipping Phase 2/3/4.")
        return

    async def _runner() -> None:
        try:
            logger.info("Starting downstream phase trigger for request_id=%s", effective_request_id)
            await asyncio.to_thread(execute_phase_2, effective_request_id)
            await asyncio.to_thread(execute_phase_3, effective_request_id)
            await asyncio.to_thread(execute_phase_4, effective_request_id)
        except Exception as exc:
            logger.exception("Downstream phase trigger failed for request_id=%s", effective_request_id)

    asyncio.create_task(_runner())
