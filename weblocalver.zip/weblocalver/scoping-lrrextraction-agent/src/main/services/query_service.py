from live.data import invalidate_live_data
from retrieval.answer import answer_query
from services.data_service import get_data_snapshot


def run_query(query: str, top_k: int) -> dict:
    return answer_query(query, top_k=top_k)


def refresh_cache_snapshot() -> dict:
    invalidate_live_data()
    data, mode = get_data_snapshot()
    return {
        "mode": mode,
        "runs": len(data.get("runs", [])),
        "documents": len(data.get("documents", [])),
        "sources": len(data.get("sources", [])),
    }
