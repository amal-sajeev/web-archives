import re


def build_download_name(title: str | None, fallback: str) -> str:
    base = (title or fallback or "document").strip().lower()
    base = re.sub(r"[^a-z0-9]+", "-", base)
    base = re.sub(r"-{2,}", "-", base).strip("-")
    return f"{base or 'document'}.md"
