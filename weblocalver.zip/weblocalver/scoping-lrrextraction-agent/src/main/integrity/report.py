import re
from collections import Counter
from integrity.structure import validate_structure
from integrity.semantic import validate_semantic_integrity
from models.domain import ValidationReport
from processing.parser import DocumentIR as IR

def build_validation_report(raw_text: str, ir: IR, structural: dict | None = None, semantic: dict | None = None) -> ValidationReport:
    structural = structural or validate_structure(ir)
    semantic = semantic or validate_semantic_integrity(raw_text, ir.render_markdown())
    rendered = ir.render_markdown()

    # Sequence similarity via token overlap
    def norm(s): return re.sub(r"[^a-z0-9]+", " ", s.lower()).split()
    a, b = norm(raw_text), norm(rendered)
    ca, cb = Counter(a), Counter(b)
    overlap = sum(min(v, cb[k]) for k, v in ca.items())
    sequence_similarity = overlap / max(1, len(a)) if a else 0.0

    # Section/heading/paragraph coverage
    headings_raw = [l.strip() for l in raw_text.split("\n") if l.strip().startswith("#")]
    headings_out = [l.strip() for l in rendered.split("\n") if l.strip().startswith("#")]
    heading_coverage = len(set(headings_raw) & set(headings_out)) / max(1, len(set(headings_raw)))

    para_raw = [p.strip() for p in raw_text.split("\n\n") if p.strip()]
    para_out = [p.strip() for p in rendered.split("\n\n") if p.strip()]
    para_set = set(p[:80] for p in para_raw)
    para_out_set = set(p[:80] for p in para_out)
    paragraph_coverage = len(para_set & para_out_set) / max(1, len(para_set))

    section_coverage = len(ir.nodes) / max(1, len(headings_raw) + len([p for p in para_raw if len(p) < 80]))

    # Tail coverage
    tail_raw = norm(raw_text[-500:]) if len(raw_text) > 500 else norm(raw_text)
    tail_out = norm(rendered[-500:]) if len(rendered) > 500 else norm(rendered)
    tail_overlap = sum(1 for t in tail_raw if t in set(tail_out)) / max(1, len(tail_raw))
    tail_coverage = tail_overlap

    # Order preservation
    order_preservation = sequence_similarity  # simplified

    # Duplicate rate
    all_text = [n.text for n in ir.nodes if n.text]
    dup_rate = sum(1 for t, c in Counter(all_text).items() if c > 1) / max(1, len(all_text))

    issues = structural["issues"] + semantic["issues"]

    # Hard rejection gates
    rejection_reasons: list[str] = []
    if structural.get("tail", {}).get("truncated"):
        rejection_reasons.append("EXTRACTION_TRUNCATED")
    if semantic["numeric_fidelity"] < 0.95:
        rejection_reasons.append("NUMERIC_FIDELITY_FAILURE")
    if semantic["date_fidelity"] < 0.95:
        rejection_reasons.append("DATE_FIDELITY_FAILURE")
    if semantic["modal_fidelity"] < 1.0:
        rejection_reasons.append("MODAL_FIDELITY_FAILURE")
    if semantic["negation_fidelity"] < 1.0:
        rejection_reasons.append("NEGATION_FIDELITY_FAILURE")

    if rejection_reasons:
        overall_status = "reject"
    elif any("gap" in i or "orphaned" in i or "missing" in i for i in issues):
        overall_status = "repair"
    elif structural["issues"]:
        overall_status = "repair"
    else:
        overall_status = "accept"

    return ValidationReport(
        overall_status=overall_status,
        rejection_reasons=rejection_reasons,
        sequence_similarity=round(sequence_similarity, 4),
        section_coverage=round(section_coverage, 4),
        paragraph_coverage=round(paragraph_coverage, 4),
        heading_coverage=round(heading_coverage, 4),
        tail_coverage=round(tail_coverage, 4),
        order_preservation=round(order_preservation, 4),
        duplicate_rate=round(dup_rate, 4),
        numeric_fidelity=semantic["numeric_fidelity"],
        date_fidelity=semantic["date_fidelity"],
        modal_fidelity=semantic["modal_fidelity"],
        negation_fidelity=semantic["negation_fidelity"],
        cross_reference_fidelity=semantic["cross_reference_fidelity"],
        issues=issues,
    )
