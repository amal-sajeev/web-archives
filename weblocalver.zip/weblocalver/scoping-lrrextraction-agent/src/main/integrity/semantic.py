from __future__ import annotations

import re

from collections import Counter

_NUM_RE = re.compile(r"\b\d[\d,]*\.?\d*\b")
_DATE_RE = re.compile(r"(?:\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2},?\s+\d{4}\b)", re.I)
_MODAL_WORDS = {"shall", "must", "may", "should", "required", "permitted", "prohibited"}
_NEGATION_WORDS = {"not", "no", "unless", "except", "provided that"}
_CROSS_REF_RE = re.compile(r"\b(?:Rule|Form|Article|Section|Part|Chapter|CFR|§)\s*[\d\w.-]+\b", re.IGNORECASE)

def _extract_numbers(text: str) -> list[str]:
    return _NUM_RE.findall(text)

def _extract_dates(text: str) -> list[str]:
    return _DATE_RE.findall(text)

def _extract_modals(text: str) -> Counter:
    words = re.findall(r"\b\w+\b", text.lower())
    return Counter(w for w in words if w in _MODAL_WORDS)

def _extract_negations(text: str) -> Counter:
    words = re.findall(r"\b\w+\b", text.lower())
    return Counter(w for w in words if w in _NEGATION_WORDS)

def _extract_cross_refs(text: str) -> list[str]:
    return _CROSS_REF_RE.findall(text)

def validate_semantic_integrity(raw_text: str, rendered: str) -> dict:
    """Compare source vs canonical output for regulatory-risk features."""
    issues: list[str] = []
    raw_nums = set(_extract_numbers(raw_text))
    out_nums = set(_extract_numbers(rendered))
    missing_nums = raw_nums - out_nums
    extra_nums = out_nums - raw_nums
    numeric_fidelity = 1.0 if not raw_nums else len(raw_nums & out_nums) / len(raw_nums)
    if missing_nums:
        issues.append(f"missing numbers in output: {sorted(missing_nums)[:10]}")

    raw_dates = set(_extract_dates(raw_text))
    out_dates = set(_extract_dates(rendered))
    date_fidelity = 1.0 if not raw_dates else len(raw_dates & out_dates) / len(raw_dates)
    missing_dates = raw_dates - out_dates
    if missing_dates:
        issues.append(f"missing dates in output: {sorted(missing_dates)[:5]}")

    raw_modals = _extract_modals(raw_text)
    out_modals = _extract_modals(rendered)
    modal_fidelity = 1.0
    for word in _MODAL_WORDS:
        if raw_modals[word] != out_modals[word]:
            issues.append(f"modal word '{word}' count mismatch: source={raw_modals[word]} output={out_modals[word]}")
            modal_fidelity = min(modal_fidelity, 0.0 if raw_modals[word] > 0 else 1.0)

    raw_negs = _extract_negations(raw_text)
    out_negs = _extract_negations(rendered)
    negation_fidelity = 1.0
    for word in _NEGATION_WORDS:
        if raw_negs[word] != out_negs[word]:
            issues.append(f"negation word '{word}' count mismatch: source={raw_negs[word]} output={out_negs[word]}")
            negation_fidelity = min(negation_fidelity, 0.0 if raw_negs[word] > 0 else 1.0)

    raw_refs = set(_extract_cross_refs(raw_text))
    out_refs = set(_extract_cross_refs(rendered))
    cross_ref_fidelity = 1.0 if not raw_refs else len(raw_refs & out_refs) / len(raw_refs)
    missing_refs = raw_refs - out_refs
    if missing_refs:
        issues.append(f"missing cross-references: {sorted(missing_refs)[:5]}")

    return {
        "numeric_fidelity": round(numeric_fidelity, 4),
        "date_fidelity": round(date_fidelity, 4),
        "modal_fidelity": round(modal_fidelity, 4),
        "negation_fidelity": round(negation_fidelity, 4),
        "cross_reference_fidelity": round(cross_ref_fidelity, 4),
        "issues": issues,
    }
