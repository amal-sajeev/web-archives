import re
from collections import Counter

from processing.parser import DocumentIR
from models import SectionNode


def validate_tree_completeness(ir: DocumentIR) -> dict:
    issues: list[str] = []
    node_ids = {n.node_id for n in ir.nodes}
    missing_parents = [n.node_id for n in ir.nodes if n.parent_id and n.parent_id not in node_ids]
    if missing_parents:
        issues.append(f"orphaned nodes with missing parents: {missing_parents[:5]}")
    labels = [n.label for n in ir.nodes if n.label]
    dup_labels = [l for l, c in Counter(labels).items() if c > 1]
    if dup_labels:
        issues.append(f"duplicate section labels: {dup_labels[:5]}")
    empty_leaves = [n.node_id for n in ir.nodes if not n.text and not n.children and n.node_type not in ("document", "part", "chapter", "title")]
    if empty_leaves:
        issues.append(f"leaf nodes with no text: {empty_leaves[:5]}")
    return {"issues": issues, "orphaned": len(missing_parents), "duplicates": len(dup_labels), "empty_leaves": len(empty_leaves)}

def validate_numbering_continuity(ir: DocumentIR, reserved: set[str] | None = None) -> dict:
    """Check numbering gaps in label sequences. Uses adapter-provided reserved provisions."""
    reserved = reserved or set()
    issues: list[str] = []
    by_parent: dict[str | None, list[SectionNode]] = {}
    for n in ir.nodes:
        by_parent.setdefault(n.parent_id, []).append(n)
    for parent_id, siblings in by_parent.items():
        numbered = [s for s in sorted(siblings, key=lambda x: x.ordinal or 0) if s.label and re.match(r"^\((\d+)\)$", s.label)]
        if len(numbered) < 2:
            continue
        nums = [int(re.match(r"^\((\d+)\)$", s.label).group(1)) for s in numbered]
        for i in range(1, len(nums)):
            if nums[i] != nums[i-1] + 1 and f"({nums[i-1]})" not in reserved and f"({nums[i]})" not in reserved:
                issues.append(f"numbering gap: {nums[i-1]} -> {nums[i]} under parent {parent_id}")
        alpha = [s for s in sorted(siblings, key=lambda x: x.ordinal or 0) if s.label and re.match(r"^\([a-z]\)$", s.label)]
        if len(alpha) >= 2:
            letters = [s.label.strip("()") for s in alpha]
            for i in range(1, len(letters)):
                prev_ord = ord(letters[i-1]) if len(letters[i-1]) == 1 else 0
                curr_ord = ord(letters[i]) if len(letters[i]) == 1 else 0
                if curr_ord != prev_ord + 1 and letters[i-1] not in reserved and letters[i] not in reserved:
                    issues.append(f"letter gap: ({letters[i-1]}) -> ({letters[i]}) under parent {parent_id}")
    return {"issues": issues}

def detect_tail_truncation(raw_text: str, ir: DocumentIR) -> dict:
    """Detect if the document ends abruptly."""
    issues: list[str] = []
    if not ir.nodes:
        return {"issues": ["no nodes in IR"], "truncated": True}
    last_nodes = [n for n in ir.nodes if not n.children]
    if not last_nodes:
        issues.append("no leaf nodes found")
    else:
        for n in last_nodes:
            if n.text and len(n.text) < 20 and not n.title:
                issues.append(f"last leaf node {n.node_id} has very short text ({len(n.text)} chars)")
    raw_stripped = raw_text.strip()
    if raw_stripped and not raw_stripped[-1] in ".!?;:\n)]}\"'":
        issues.append("raw text does not end with expected terminal punctuation")
    raw_tail = raw_stripped[-200:] if len(raw_stripped) > 200 else raw_stripped
    ir_tail = ir.render_markdown()[-200:] if ir.nodes else ""
    if raw_tail.strip() and not any(word in ir_tail for word in raw_tail.split()[-5:]):
        issues.append("IR tail does not match raw text tail")
    return {"issues": issues, "truncated": bool(issues)}

def validate_structure(ir: DocumentIR, reserved: set[str] | None = None) -> dict:
    tree = validate_tree_completeness(ir)
    numbering = validate_numbering_continuity(ir, reserved)
    tail = detect_tail_truncation(ir.raw_text, ir)
    all_issues = tree["issues"] + numbering["issues"] + tail["issues"]
    return {
        "issues": all_issues,
        "tree": tree,
        "numbering": numbering,
        "tail": tail,
        "pass": len(all_issues) == 0,
    }
