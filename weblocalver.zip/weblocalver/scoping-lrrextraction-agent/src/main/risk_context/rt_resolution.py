"""Phase 2: Risk Type Context Resolution for the Risk-Mapping Pipeline."""

import json
import logging
import re
from typing import Any, Dict, List, Set

from google.cloud import storage
from google.api_core.exceptions import GoogleAPICallError

from config.settings import Settings
from runtime.observability import event 

# In-Memory Store for Phase 3
PHASE_3_PERSISTED_STORE: Dict[str, Any] = {}

logger = logging.getLogger(__name__)

def _log_info(message: str):
    """Helper to send info logs to our custom phase logger."""
    event("phase_log", message=message)

def _download_gcs_json(bucket_name: str, blob_path: str) -> List[Dict[str, Any]]:
    """Downloads and parses a JSON file from Google Cloud Storage."""
    _log_info(f"Attempting to download from gs://{bucket_name}/{blob_path}")
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(blob_path)
        
        if not blob.exists():
            logger.error(f"GCS file not found: gs://{bucket_name}/{blob_path}")
            raise FileNotFoundError(f"Required GCS file does not exist: {blob_path}")

        data_string = blob.download_as_text()
        return json.loads(data_string)
    except GoogleAPICallError as e:
        logger.error(f"GCS connection error for {blob_path}: {e}")
        raise ConnectionError(f"Failed to connect to GCS: {e}") from e
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse JSON from {blob_path}: {e}")
        raise ValueError(f"Invalid JSON format in {blob_path}") from e

def _build_active_risk_manifest(inbound_data: List[Dict[str, Any]]) -> Set[str]:
    """Extracts unique, active risk codes from the inbound manifest data."""
    active_risk_codes: Set[str] = set()
    risk_code_pattern = re.compile(r"(R\d+)")

    for item in inbound_data:
        try:
            risk_type_str = item["search_combination"]["UoT Risk Type"]
            match = risk_code_pattern.search(risk_type_str)
            if match:
                active_risk_codes.add(match.group(1))
        except KeyError:
            logger.warning(f"Skipping item due to missing key 'search_combination' or 'UoT Risk Type': {item.get('plan_item_number')}")
        except Exception as e:
            logger.error(f"Unexpected error processing item {item.get('plan_item_number')}: {e}")

    _log_info(f"Found {len(active_risk_codes)} unique active risk types in the manifest.")
    _log_info(f"Active Risk Manifest (sorted): {sorted(list(active_risk_codes))}")
    
    return active_risk_codes

def execute_phase_2(request_id: str) -> None:
    """
    Main execution function for Phase 2.

    Args:
        request_id: The unique identifier for the current run, used to construct GCS paths.
    """
    _log_info("\nPHASE 2: RT CONTEXT RESOLUTION START ---")
    settings = Settings()

    if not settings.gcs_bucket:
        logger.critical("GCS_BUCKET setting is not configured. Aborting Phase 2.")
        raise ValueError("GCS bucket not configured in settings.")

    inbound_manifest_path = f"{settings.gcs_prefix}_{request_id}/{settings.manifest}"

    try:
        inbound_data = _download_gcs_json(settings.gcs_bucket, inbound_manifest_path)
        active_risk_manifest = _build_active_risk_manifest(inbound_data)
        master_definitions = _download_gcs_json(settings.gcs_bucket, settings.master_risk_definitions)
        _log_info(f"Successfully processed {len(master_definitions)} master definitions from GCS.")
    except (FileNotFoundError, ConnectionError, ValueError) as e:
        logger.critical(f"Could not build active risk manifest or read master definitions. Aborting Phase 2. Reason: {e}")
        return

    mapped_risk_types: List[str] = []
    risk_code_pattern = re.compile(r"(R\d+)")
    
    for definition in master_definitions:
        try:
            name_str = definition["Name"]
            match = risk_code_pattern.search(name_str)
            if match:
                risk_code = match.group(1)
                if risk_code in active_risk_manifest:
                    PHASE_3_PERSISTED_STORE[risk_code] = definition
                    mapped_risk_types.append(risk_code)
        except KeyError:
            logger.warning(f"Skipping master definition due to missing 'Name' key: {definition}")

    _log_info(f"Successfully mapped {len(mapped_risk_types)} risk types to the runtime store.")
    
    unmapped_risks = active_risk_manifest - set(mapped_risk_types)
    if unmapped_risks:
        logger.warning(f"The following active risk codes were in the manifest but NOT found in the master definitions: {sorted(list(unmapped_risks))}")
    else:
        _log_info("All active risk codes were successfully mapped.")

    _log_info("\nPHASE 2: RT CONTEXT RESOLUTION END")
