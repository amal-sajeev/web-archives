import csv
import io
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import quote

from google.cloud import storage
from google.api_core.exceptions import GoogleAPICallError

from config.settings import Settings
from runtime.llm_provider import build_llm
from risk_context.rt_resolution import PHASE_3_PERSISTED_STORE
from runtime.observability import event 
from risk_context.document_chunking import score_chunk_relevance, select_relevant_chunks, split_markdown_into_chunks
from risk_context.llm_retry import call_with_retry

logger = logging.getLogger(__name__)

def _log_info(message: str, *args: Any):
    """Helper to send info logs to our custom phase logger."""
    if args:
        message = message % args
    event("phase_log", message=message)

def _read_gcs_file(bucket_name: str, blob_path: str) -> str:
    """Reads a text file from GCS."""
    _log_info(f"Reading from gs://{bucket_name}/{blob_path}")
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(blob_path)
        if not blob.exists():
            raise FileNotFoundError(f"Required GCS file does not exist: {blob_path}")
        return blob.download_as_text()
    except GoogleAPICallError as e:
        raise ConnectionError(f"Failed to connect to GCS for {blob_path}: {e}") from e

def _write_gcs_file(bucket_name: str, blob_path: str, data: str, content_type: str):
    """Writes string data to a GCS blob."""
    _log_info(f"Writing to gs://{bucket_name}/{blob_path}")
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(blob_path)
        blob.upload_from_string(data, content_type=content_type)
        _log_info(f"Successfully wrote to gs://{bucket_name}/{blob_path}")
    except GoogleAPICallError as e:
        raise ConnectionError(f"Failed to write to GCS at {blob_path}: {e}") from e

def _load_local_json_prompt(path: Path) -> Dict[str, Any]:
    """Loads a JSON instruction file from a local path."""
    _log_info(f"Loading prompt from: {path}")
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"Prompt file not found at: {path}")
    except json.JSONDecodeError:
        raise ValueError(f"Invalid JSON in prompt file: {path}")

def _clean_llm_json_response(response_content: str) -> str:
    """Cleans the LLM response by removing markdown code fences and extracting the core JSON object."""
    start = response_content.find('{')
    end = response_content.rfind('}')
    if start != -1 and end != -1:
        return response_content[start:end+1]
    return response_content # Fallback

def _clean_output_value(value: Any) -> Any:
    """Convert nullable model output into serializable, CSV-safe values."""
    if value is None:
        return ""
    if isinstance(value, dict):
        return {str(k): _clean_output_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_clean_output_value(v) for v in value]
    if isinstance(value, tuple):
        return [_clean_output_value(v) for v in value]
    if isinstance(value, (str, int, float, bool)):
        return value
    return str(value)

def _flatten_to_csv_data(enriched_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Converts the final, correct nested JSON structure to a flat list for CSV conversion."""
    flat_list = []
    for item in enriched_data:
        risk_name = _clean_output_value(item.get("Risk Name") or "")
        for mandate in item.get("Mandates", []) or []:
            # For each piece of evidence, create a new row
            for evidence in mandate.get("Evidence", []) or []:
                flat_row = {
                    "Risk Name": risk_name,
                    "Regulatory Mandate": _clean_output_value(mandate.get("Regulatory Mandate") or ""),
                    "Confidence Score": _clean_output_value(mandate.get("Confidence Score") or ""),
                    "AI Rationale": _clean_output_value(mandate.get("AI Rationale") or ""),
                    "source_url": _clean_output_value(evidence.get("source_url") or ""),
                    "evidence_text": _clean_output_value(evidence.get("evidence_text") or ""),
                    "deep_link": _clean_output_value(evidence.get("deep_link") or ""),
                }
                flat_list.append(flat_row)
    return flat_list

def _serialize_for_output(data: Any) -> Any:
    """Recursively remove nulls and convert values to a stable JSON-safe structure."""
    if data is None:
        return ""
    if isinstance(data, dict):
        return {str(k): _serialize_for_output(v) for k, v in data.items() if v is not None}
    if isinstance(data, list):
        return [_serialize_for_output(v) for v in data]
    if isinstance(data, tuple):
        return [_serialize_for_output(v) for v in data]
    if isinstance(data, (str, int, float, bool)):
        return data
    return str(data)

def _extract_risk_codes_from_text(value: Any) -> List[str]:
    """Extract all risk codes like R019 from a free-form text value."""
    if not isinstance(value, str):
        return []
    return sorted(set(re.findall(r"R\d+", value)))


def _build_plan_scope_context(inbound_data: List[Dict[str, Any]], active_risk_codes: set[str] | None = None) -> str:
    """Return a single canonical plan scope for the active request.

    The source-processing pipeline remains unchanged: chunking, relevance filtering,
    and mandate-to-risk mapping still happen as before. This only adds the plan-level
    context needed to scope the LLM output to the current plan.
    """
    fallback = json.dumps({
        "plan_item_title": "",
        "description_of_plan_item": "",
        "active_risk_codes": sorted(active_risk_codes or set()),
    }, ensure_ascii=False)

    if not inbound_data:
        return fallback

    candidates: List[Dict[str, Any]] = []
    for item in inbound_data:
        if not isinstance(item, dict):
            continue

        title = (item.get("plan_item_title") or item.get("plan_title") or item.get("title") or "").strip()
        description = (item.get("description_of_plan_item") or item.get("plan_description") or item.get("description") or "").strip()
        if not title and not description:
            continue

        search_combination = item.get("search_combination") or {}
        risk_codes = _extract_risk_codes_from_text(search_combination.get("UoT Risk Type"))
        if not risk_codes:
            risk_codes = _extract_risk_codes_from_text(item.get("UoT Risk Type"))

        if active_risk_codes is not None:
            if not risk_codes:
                continue
            if not set(risk_codes).intersection(active_risk_codes):
                continue

        candidates.append({
            "plan_item_title": title,
            "description_of_plan_item": description,
            "active_risk_codes": sorted(set(risk_codes)),
        })

    if not candidates:
        return fallback

    unique_by_plan: Dict[str, Dict[str, Any]] = {}
    for candidate in candidates:
        key = (candidate.get("plan_item_title") or "", candidate.get("description_of_plan_item") or "")
        if key not in unique_by_plan:
            unique_by_plan[key] = candidate
        else:
            unique_by_plan[key]["active_risk_codes"] = sorted(
                set(unique_by_plan[key].get("active_risk_codes", []) + candidate.get("active_risk_codes", []))
            )

    selected = max(
        unique_by_plan.values(),
        key=lambda item: (
            len(item.get("active_risk_codes", [])),
            bool(item.get("plan_item_title")),
            bool(item.get("description_of_plan_item")),
        ),
    )

    return json.dumps({
        "plan_item_title": selected.get("plan_item_title", ""),
        "description_of_plan_item": selected.get("description_of_plan_item", ""),
        "active_risk_codes": selected.get("active_risk_codes", []),
    }, ensure_ascii=False)


def _log_plan_scope_context(plan_scope_context: str) -> None:
    """Log the single selected plan title and description that are included in the prompt."""
    try:
        parsed = json.loads(plan_scope_context)
        if isinstance(parsed, dict):
            title = parsed.get("plan_item_title") or "<missing plan title>"
            description = parsed.get("description_of_plan_item") or "<missing plan description>"
            _log_info("LLM Plan Scope - Title: %s", title)
            _log_info("LLM Plan Scope - Description: %s", description)
            if parsed.get("active_risk_codes"):
                _log_info("LLM Plan Scope - Active Risk Codes: %s", parsed.get("active_risk_codes"))
        else:
            _log_info("LLM Plan Scope: %s", plan_scope_context)
    except Exception:
        _log_info("LLM Plan Scope: %s", plan_scope_context)

def _render_prompt_from_instructions(prompt_config: Dict[str, Any], *, plan_scope_context: str, risk_context: Dict[str, Dict[str, Any]], source_chunk: str | None = None, mandate_list: List[Dict[str, Any]] | None = None) -> str:
    """Render a prompt string from the JSON prompt configuration with plan and risk context."""
    instructions = prompt_config.get("prompt_instructions", {}) if isinstance(prompt_config, dict) else {}
    sections: List[str] = []

    if isinstance(instructions, dict):
        for key in ("persona", "task_overview", "core_guidelines", "output_specification"):
            block = instructions.get(key)
            if not isinstance(block, dict):
                continue
            title = block.get("title", key.replace("_", " ").title())
            content = block.get("content")
            if isinstance(content, list):
                content_text = "\n".join(str(item) for item in content)
            elif content is None:
                content_text = ""
            else:
                content_text = str(content)
            if content_text:
                sections.append(f"## {title}\n{content_text}")

    if isinstance(prompt_config, dict) and "prompt_template" in prompt_config and prompt_config.get("prompt_template"):
        template = str(prompt_config["prompt_template"])
        if source_chunk is not None:
            template = template.replace("{source_document_content}", source_chunk)
        if mandate_list is not None:
            template = template.replace("{mandate_list}", json.dumps(mandate_list, ensure_ascii=False, indent=2))
        template = template.replace("{plan_scope_context}", plan_scope_context)
        template = template.replace("{risk_context}", json.dumps(risk_context, ensure_ascii=False, indent=2))
        return template

    if source_chunk is not None:
        sections.append(f"## Source Document Content\n{source_chunk}")
    sections.append(f"## Plan Scope Context\n{plan_scope_context}")
    sections.append(f"## Risk Context\n{json.dumps(risk_context, ensure_ascii=False, indent=2)}")

    if mandate_list is not None:
        sections.append(f"## Mandate List\n{json.dumps(mandate_list, ensure_ascii=False, indent=2)}")

    return "\n\n".join(sections)


def _generate_mandates_for_chunk(llm: Any, chunk: str, mandate_prompt: Dict[str, Any], settings: Settings, risk_context: Dict[str, Dict[str, Any]], plan_scope_context: str) -> List[Dict[str, Any]]:
    """Run the mandate-generation LLM for one source chunk while preserving the chunking pipeline."""
    prompt = _render_prompt_from_instructions(
        mandate_prompt,
        plan_scope_context=plan_scope_context,
        risk_context=risk_context,
        source_chunk=chunk,
    )

    try:
        result = call_with_retry(
            lambda: llm.invoke(prompt),
            attempts=getattr(settings, "llm_retry_attempts", 3),
            base_delay_seconds=2.0,
        )
    except Exception as exc:  # pragma: no cover - depends on LLM platform
        logger.error("Failed to generate mandates for a chunk: %s", exc)
        return []

    response_content = getattr(result, "content", str(result))
    cleaned = _clean_llm_json_response(str(response_content))
    if not cleaned:
        return []

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        logger.warning("LLM returned invalid JSON while generating mandates for a chunk.")
        return []

    if isinstance(parsed, list):
        return [item for item in parsed if isinstance(item, dict)]

    if isinstance(parsed, dict):
        mandate_items = []
        for key, data in parsed.items():
            if isinstance(data, dict):
                mandate_items.append(data)
        return mandate_items

    return []


def _map_batch_to_risks(llm: Any, mandate_batch: List[Dict[str, Any]], risk_context: Dict[str, Dict[str, Any]], plan_scope_context: str, risk_mapping_prompt: Dict[str, Any], settings: Settings) -> Dict[str, Dict[str, Any]]:
    """Map a batch of mandates to active risk codes while preserving the existing risk-mapping flow."""
    if not mandate_batch:
        return {}

    prompt = _render_prompt_from_instructions(
        risk_mapping_prompt,
        plan_scope_context=plan_scope_context,
        risk_context=risk_context,
        mandate_list=mandate_batch,
    )

    try:
        result = call_with_retry(
            lambda: llm.invoke(prompt),
            attempts=getattr(settings, "llm_retry_attempts", 3),
            base_delay_seconds=2.0,
        )
    except Exception as exc:  # pragma: no cover - depends on LLM platform
        logger.error("Failed to map mandates to risk types: %s", exc)
        return {}

    response_content = getattr(result, "content", str(result))
    cleaned = _clean_llm_json_response(str(response_content))
    if not cleaned:
        return {}

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        logger.warning("LLM returned invalid JSON while mapping mandates to risk types.")
        return {}

    if not isinstance(parsed, dict):
        return {}
    return parsed


def _map_all_mandates_to_risks(llm: Any, all_mandates: List[Dict[str, Any]], risk_context: Dict[str, Dict[str, Any]], plan_scope_context: str, risk_mapping_prompt: Dict[str, Any], settings: Settings) -> Dict[str, Dict[str, Any]]:
    """Map mandates to active risks in bounded batches; do not send the full list in one pass."""
    safe_batch_size = max(
        1,
        int(getattr(settings, "mandate_mapping_batch_size", getattr(settings, "document_chunk_batch_size", 25))),
    )
    combined: Dict[str, Dict[str, Any]] = {}

    total_batches = (len(all_mandates) + safe_batch_size - 1) // safe_batch_size if all_mandates else 0
    for batch_index, index in enumerate(range(0, len(all_mandates), safe_batch_size), start=1):
        batch = all_mandates[index:index + safe_batch_size]
        batch_start = index + 1
        batch_end = min(index + len(batch), len(all_mandates))
        _log_info("Risk mapping batch %s/%s: mandates [%s to %s/%s]", batch_index, total_batches or 1, batch_start, batch_end, len(all_mandates))

        batch_map = _map_batch_to_risks(llm, batch, risk_context, plan_scope_context, risk_mapping_prompt, settings)
        if not batch_map:
            _log_info("Risk mapping batch %s/%s produced no mapped mandates.", batch_index, total_batches or 1)
            continue

        batch_counts = _summarize_batch_risk_counts(batch_map)
        _log_info("Risk mapping batch %s/%s mapped %s", batch_index, total_batches or 1, batch_counts or "0 mandates")
        for mandate_key, mapping in batch_map.items():
            combined[mandate_key] = mapping

    return combined


def _log_chunk_selection_summary(chunks: List[str], relevant_keywords: List[str], selected_chunks: List[str]) -> None:
    """Log each chunk's semantic relevance score and whether it was selected for LLM processing."""
    selected_set = {chunk for chunk in selected_chunks}
    for idx, chunk in enumerate(chunks, start=1):
        score = score_chunk_relevance(chunk, relevant_keywords)
        selected = "selected" if chunk in selected_set else "skipped"
        _log_info("Chunk %s semantic match score=%.4f (%s)", idx, score, selected)


def _summarize_batch_risk_counts(batch_map: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    """Aggregate risk-code counts for a mapping batch."""
    counts: Dict[str, int] = {}
    for mapping in batch_map.values():
        if not isinstance(mapping, dict):
            continue
        for risk_code in mapping.get("risk_codes", []) or []:
            code = str(risk_code)
            counts[code] = counts.get(code, 0) + 1
    return counts


def execute_phase_3(request_id: str = "20090") -> None:
    """Main execution function for Phase 3."""
    _log_info("\nPHASE 3: MANDATE GENERATION & RISK TYPE MAPPING START")
    settings = Settings()
    llm = build_llm(settings, reasoning=True)

    if not request_id:
        logger.critical("request_id is missing. Aborting Phase 3.")
        return
    if not PHASE_3_PERSISTED_STORE:
        logger.warning("Phase 2 did not populate the in-memory store. Aborting Phase 3.")
        return

    try:
        raw_data_path = f"{settings.gcs_prefix}_{request_id}/processing-data/llr-extracted/lrr_raw_data_{request_id}.md"
        manifest_path = f"{settings.gcs_prefix}_{request_id}/{settings.manifest}"
        _log_info("Attempting to read raw markdown from gs://%s/%s", settings.gcs_bucket, raw_data_path)
        raw_markdown = _read_gcs_file(settings.gcs_bucket, raw_data_path)
        inbound_manifest_raw = _read_gcs_file(settings.gcs_bucket, manifest_path)
        inbound_manifest = json.loads(inbound_manifest_raw)
        mandate_prompt = _load_local_json_prompt(settings.mandate_generation_prompt_path)
        risk_mapping_prompt = _load_local_json_prompt(settings.risk_mapping_prompt_path)
    except (FileNotFoundError, ConnectionError, ValueError) as e:
        logger.critical(f"Failed to load initial data or prompts. Aborting Phase 3. Reason: {e}")
        return

    risk_context = {
        code: {
            "Code": code,
            "Name": risk_def.get("Name", ""),
            "Definition": risk_def.get("Risk Definition", ""),
            "Keywords": risk_def.get("Keywords", ""),
        }
        for code, risk_def in PHASE_3_PERSISTED_STORE.items()
    }
    plan_scope_context = _build_plan_scope_context(inbound_manifest, set(PHASE_3_PERSISTED_STORE.keys()))
    _log_plan_scope_context(plan_scope_context)

    relevant_keywords = []
    for definition in PHASE_3_PERSISTED_STORE.values():
        relevant_keywords.extend(
            [
                definition.get("Name", ""),
                definition.get("Risk Definition", ""),
                definition.get("Keywords", ""),
            ]
        )
        relevant_keywords = [keyword for keyword in relevant_keywords if isinstance(keyword, str) and keyword.strip()]

    _log_info("Starting Step 1: Splitting source document into manageable chunks...")
    chunks = split_markdown_into_chunks(raw_markdown, max_chars=settings.document_chunk_max_chars, min_chars=settings.document_chunk_min_chars)
    _log_info("Document chunking complete. Total chunks=%s", len(chunks))

    all_mandates: List[Dict[str, Any]] = []
    selected_chunks = select_relevant_chunks(
        chunks,
        relevant_keywords,
        top_n=min(settings.document_chunk_top_n, len(chunks) or 1),
        min_score=max(0.0, float(getattr(settings, "document_chunk_relevance_min_score", 0.05))),
    )
    if len(selected_chunks) < len(chunks):
        _log_info("Selected %s high-relevance chunks for LLM processing out of %s total chunks.", len(selected_chunks), len(chunks))
    _log_chunk_selection_summary(chunks, relevant_keywords, selected_chunks)

    try:
        for idx, chunk in enumerate(selected_chunks, start=1):
            _log_info("Generating mandates for chunk %s/%s from selected relevant chunks only", idx, len(selected_chunks))
            chunk_mandates = _generate_mandates_for_chunk(llm, chunk, mandate_prompt, settings, risk_context, plan_scope_context)
            if chunk_mandates:
                all_mandates.extend(chunk_mandates)
                _log_info("Chunk %s generated %s mandates.", idx, len(chunk_mandates))
            else:
                _log_info("Chunk %s produced no mandates.", idx)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse JSON from LLM during mandate generation. Details: {e}.")
        return
    except Exception as e:
        logger.critical(f"A critical error occurred during mandate generation: {e}. Aborting Phase 3.")
        return

    if not all_mandates:
        logger.warning("No mandates were generated from the source document. Cannot proceed to mapping.")
        _log_info("--- Phase 3: Mandate Generation & Risk Type Mapping END ---")
        return

    _log_info("\nStarting Step 2: Mapping generated mandates to active risk types in bounded batches...")
    final_results_map = {risk_code: {"Risk Name": definition["Name"], "Mandates": []} for risk_code, definition in PHASE_3_PERSISTED_STORE.items()}

    try:
        prompt_template = risk_mapping_prompt.get("prompt_template", "")
        if not prompt_template:
            raise ValueError("Missing 'prompt_template' in risktype_mapping.json")

        _log_info("Sending mandates to LLM for mapping in bounded batches...")
        mapping_results = _map_all_mandates_to_risks(llm, all_mandates, risk_context, plan_scope_context, risk_mapping_prompt, settings)

        _log_info("Processing mapped batch results...")
        total_mapped = 0
        for mandate_key, mapping_data in mapping_results.items():
            mandate_idx = int(mandate_key[1:]) - 1
            if mandate_idx < len(all_mandates):
                mandate_from_step1 = all_mandates[mandate_idx]
                relevant_codes = mapping_data.get("risk_codes", [])
                mapping_rationale = mapping_data.get("rationale", "No specific rationale provided.")

                if relevant_codes:
                    total_mapped += 1
                    for code in relevant_codes:
                        if code in final_results_map:
                            final_mandate_object = {
                                "Regulatory Mandate": mandate_from_step1.get("Regulatory Mandate"),
                                "Confidence Score": mandate_from_step1.get("Confidence Score"),
                                "AI Rationale": mapping_rationale,
                                "Evidence": mandate_from_step1.get("Evidence", []),
                            }
                            final_results_map[code]["Mandates"].append(final_mandate_object)
        _log_info(f"Mapping complete. {total_mapped}/{len(all_mandates)} mandates were mapped to at least one risk type.")

    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse JSON response from LLM during mapping. Error: {e}.")
    except Exception as e:
        logger.error(f"An error occurred during mandate mapping: {e}")

    _log_info("\nStarting Step 3: Saving final enriched data...")
    final_enriched_data = [value for value in final_results_map.values() if value["Mandates"]]

    if not final_enriched_data:
        logger.warning("No mandates were successfully mapped to any active risk types. Skipping output file creation.")
        _log_info("--- Phase 3: Mandate Generation & Risk Type Mapping END ---")
        return

    try:
        csv_data = _flatten_to_csv_data(final_enriched_data)
        string_buffer = io.StringIO()
        if csv_data:
            field_names = list(csv_data[0].keys())
            writer = csv.DictWriter(string_buffer, fieldnames=field_names)
            writer.writeheader()
            writer.writerows(csv_data)

        base_path = f"{settings.gcs_prefix}_{request_id}"
        json_path_1 = f"{base_path}/{settings.enriched_output_path_json}"
        csv_path_1 = f"{base_path}/{settings.enriched_output_path_csv}"
        json_path_2 = f"{base_path}/{settings.inbound_enriched_output_path_json}"
        csv_path_2 = f"{base_path}/{settings.inbound_enriched_output_path_csv}"

        _log_info("Saving Phase 3 JSON output to gs://%s/%s", settings.gcs_bucket, json_path_1)
        _write_gcs_file(settings.gcs_bucket, json_path_1, json.dumps(_serialize_for_output(final_enriched_data), indent=2), 'application/json')
        _log_info("Saving Phase 3 CSV output to gs://%s/%s", settings.gcs_bucket, csv_path_1)
        _write_gcs_file(settings.gcs_bucket, csv_path_1, string_buffer.getvalue(), 'text/csv')
        _log_info("Saving inbound JSON output to gs://%s/%s", settings.gcs_bucket, json_path_2)
        _write_gcs_file(settings.gcs_bucket, json_path_2, json.dumps(_serialize_for_output(final_enriched_data), indent=2), 'application/json')
        _log_info("Saving inbound CSV output to gs://%s/%s", settings.gcs_bucket, csv_path_2)
        _write_gcs_file(settings.gcs_bucket, csv_path_2, string_buffer.getvalue(), 'text/csv')

    except Exception as e:
        logger.error(f"An error occurred while saving Phase 3 output: {e}")
        raise

    _log_info("PHASE 3: MANDATE GENERATION & RISK TYPE MAPPING END ")
