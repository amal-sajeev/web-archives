import logging
import time
from typing import Any, Callable, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


def _is_retryable_error(exc: Exception) -> bool:
    msg = str(exc).lower()
    return (
        "429" in msg
        or "resource exhausted" in msg
        or "rate limit" in msg
        or "badgateway" in msg
        or "502" in msg
        or "503" in msg
        or "timeout" in msg
        or "temporarily unavailable" in msg
    )


def call_with_retry(
    fn: Callable[..., T],
    *args: Any,
    attempts: int = 3,
    base_delay_seconds: float = 2.0,
    max_delay_seconds: float = 30.0,
    **kwargs: Any,
) -> T:
    delay = base_delay_seconds
    last_exc: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:  # pragma: no cover - retry logic path
            last_exc = exc
            if not _is_retryable_error(exc) or attempt >= attempts:
                raise
            logger.warning(
                "LLM call retrying after transient error (attempt=%s/%s): %s",
                attempt,
                attempts,
                exc,
            )
            time.sleep(min(delay, max_delay_seconds))
            delay *= 2
    if last_exc is not None:
        raise last_exc
    raise RuntimeError("LLM call retry failed without an exception")
