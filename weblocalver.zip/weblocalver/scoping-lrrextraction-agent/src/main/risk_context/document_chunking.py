import re
from typing import Iterable


def _normalize_markdown(markdown: str) -> str:
    return re.sub(r"\r\n?", "\n", markdown or "").strip()


def _split_blocks(markdown: str) -> list[str]:
    blocks: list[str] = []
    current: list[str] = []
    for line in markdown.splitlines():
        if re.match(r"^#{1,6}\s+", line):
            if current:
                block = "\n".join(current).strip()
                if block:
                    blocks.append(block)
            current = [line]
        else:
            current.append(line)
    if current:
        block = "\n".join(current).strip()
        if block:
            blocks.append(block)
    return blocks


def _split_block_by_paragraphs(block: str, max_chars: int, min_chars: int) -> list[str]:
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n+", block) if p.strip()]
    if not paragraphs:
        return []

    chunks: list[str] = []
    current: list[str] = []
    current_len = 0

    for paragraph in paragraphs:
        paragraph_size = len(paragraph)
        if paragraph_size > max_chars:
            if current:
                chunks.append("\n\n".join(current).strip())
                current = []
                current_len = 0
            sentence_parts = re.split(r"(?<=[.!?])\s+", paragraph)
            sentence_buffer: list[str] = []
            sentence_buffer_len = 0
            for sentence in sentence_parts:
                if not sentence.strip():
                    continue
                candidate = sentence_buffer + [sentence]
                candidate_text = " ".join(candidate).strip()
                if len(candidate_text) <= max_chars:
                    sentence_buffer = candidate
                    sentence_buffer_len = len(candidate_text)
                    continue
                if sentence_buffer:
                    chunks.append(" ".join(sentence_buffer).strip())
                    sentence_buffer = [sentence]
                    sentence_buffer_len = len(sentence)
                else:
                    chunks.append(sentence.strip())
                    sentence_buffer = []
                    sentence_buffer_len = 0
            if sentence_buffer:
                chunks.append(" ".join(sentence_buffer).strip())
            continue

        if current and current_len + paragraph_size + 2 > max_chars:
            chunks.append("\n\n".join(current).strip())
            current = []
            current_len = 0

        current.append(paragraph)
        current_len += paragraph_size + 2

    if current:
        chunks.append("\n\n".join(current).strip())

    merged: list[str] = []
    for chunk in chunks:
        if not chunk:
            continue
        if not merged:
            merged.append(chunk)
            continue
        if len(merged[-1]) < min_chars and len(merged[-1]) + len(chunk) <= max_chars:
            merged[-1] = f"{merged[-1]}\n\n{chunk}".strip()
        else:
            merged.append(chunk)

    return [chunk.strip() for chunk in merged if chunk.strip()]


def split_markdown_into_chunks(markdown: str, max_chars: int = 12000, min_chars: int = 2500) -> list[str]:
    text = _normalize_markdown(markdown)
    if not text:
        return []

    blocks = _split_blocks(text)
    if not blocks:
        return []

    chunks: list[str] = []
    for block in blocks:
        if len(block) <= max_chars:
            chunks.append(block)
            continue
        chunks.extend(_split_block_by_paragraphs(block, max_chars=max_chars, min_chars=min_chars))

    merged: list[str] = []
    current = ""
    for chunk in chunks:
        if not chunk:
            continue
        if not current:
            current = chunk
            continue
        if len(current) + len(chunk) <= max_chars:
            current = f"{current}\n\n{chunk}".strip()
            continue
        merged.append(current)
        current = chunk
    if current:
        merged.append(current)

    final_chunks: list[str] = []
    for chunk in merged:
        if not chunk.strip():
            continue
        if len(chunk) < min_chars and final_chunks:
            final_chunks[-1] = f"{final_chunks[-1]}\n\n{chunk}".strip()
        else:
            final_chunks.append(chunk.strip())
    return final_chunks


def _tokenize_keywords(value: str) -> set[str]:
    return {
        token.strip().lower()
        for token in re.findall(r"[A-Za-z][A-Za-z0-9/.-]{2,}", value or "")
        if len(token.strip()) > 3
    }


def score_chunk_relevance(chunk: str, relevant_keywords: Iterable[str]) -> float:
    chunk_text = re.sub(r"[^A-Za-z0-9\s]", " ", (chunk or "").lower())
    keywords = {str(item).lower().strip() for item in relevant_keywords if str(item).strip()}
    if not keywords:
        return 1.0
    matched = sum(1 for keyword in keywords if keyword in chunk_text)
    if matched == 0:
        return 0.0
    return matched / len(keywords)


def select_relevant_chunks(
    chunks: list[str],
    relevant_keywords: Iterable[str],
    top_n: int = 20,
    min_score: float = 0.05,
) -> list[str]:
    if not chunks:
        return []

    scored = [(score_chunk_relevance(chunk, relevant_keywords), chunk) for chunk in chunks]
    scored.sort(key=lambda item: item[0], reverse=True)

    if not scored:
        return chunks[: max(1, min(top_n, len(chunks)))]

    qualifying = [chunk for score, chunk in scored if score >= min_score]
    if qualifying:
        return qualifying[: max(1, min(top_n, len(qualifying)))]

    fallback = [chunk for _, chunk in scored[: max(1, min(top_n, len(scored)))]]
    return fallback
