def _sample_graph() -> dict:
    return {
        "nodes": {
            "finra-3110": {"label": "FINRA Rule 3110", "type": "instrument", "authority": "sro"},
            "sr-finra-2020-040": {"label": "SR-FINRA-2020-040", "type": "amendment", "authority": "sro"},
            "reg-notice-24-02": {"label": "Regulatory Notice 24-02", "type": "amendment", "authority": "sro"},
            "rule-3210": {"label": "Rule 3210", "type": "instrument", "authority": "sro"},
            "sea-17a-4": {"label": "SEA Rule 17a-4", "type": "instrument", "authority": "government"},
            "rbi-master-directions": {"label": "RBI Master Directions Index", "type": "index", "authority": "primary_regulator"},
            "ecfr-title-17": {"label": "17 CFR Part 17", "type": "instrument", "authority": "government"},
            "fca-consumers": {"label": "FCA Protecting Consumers", "type": "topic", "authority": "primary_regulator"},
            "db-third-party": {"label": "Deutsche Bank Third Party Control", "type": "secondary", "authority": "regulated_entity"},
        },
        "edges": [
            {"from": "finra-3110", "to": "reg-notice-24-02", "relationship": "AMENDED_BY", "evidence": "rule text references notice", "confidence": 0.9},
            {"from": "finra-3110", "to": "sr-finra-2020-040", "relationship": "AMENDED_BY", "evidence": "rule text references filing", "confidence": 0.9},
            {"from": "finra-3110", "to": "rule-3210", "relationship": "REFERENCES", "evidence": "cross-reference in (b)", "confidence": 0.85},
            {"from": "finra-3110", "to": "sea-17a-4", "relationship": "REFERENCES", "evidence": "cross-reference to SEA Rule 17a-4", "confidence": 0.8},
            {"from": "rbi-master-directions", "to": "rbi-master-directions", "relationship": "LISTS", "evidence": "index lists individual directions", "confidence": 1.0},
        ],
    }


def _sample_review_items() -> list[dict]:
    return [
        {
            "id": "review-001",
            "severity": "high",
            "document": "finra-3110",
            "document_title": "FINRA Rule 3110. Supervision",
            "reason": "Version ambiguity",
            "evidence": "No effective date or supersession language found in source text. URL does not contain /current/ path. Cannot establish current regulatory state.",
            "recommended_action": "Retrieve FINRA rule amendment history page and compare dates.",
        },
        {
            "id": "review-002",
            "severity": "medium",
            "document": "fca-market-abuse",
            "document_title": "FCA Market Abuse Regulation",
            "reason": "Version ambiguity",
            "evidence": "Topic page references multiple regulations. Temporal state could not be established from available evidence.",
            "recommended_action": "Identify and fetch the referenced operative legislation directly.",
        },
    ]
