def _sample_runs() -> list[dict]:
    return [
        {
            "run_id": "demo-run-001",
            "objective": "Acquire authoritative regulatory material from 8 diverse sources, classify each correctly, preserve content, validate fidelity, resolve temporal state, and identify items requiring review.",
            "status": "completed",
            "step": 42,
            "duration_ms": 184000,
            "sources": 8,
            "accepted": 5,
            "review": 2,
            "rejected": 1,
            "created_at": "2026-09-07T01:00:00Z",
        },
    ]


def _sample_events() -> dict:
    return {
        "demo-run-001": [
            {"step": 0, "action": "plan", "target": None, "status": "ok", "duration_ms": 2400, "details": "Gemini generated acquisition plan for 8 sources"},
            {"step": 1, "action": "fetch", "target": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110", "status": "ok", "duration_ms": 1076},
            {"step": 2, "action": "classify", "target": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110", "status": "ok", "duration_ms": 890, "details": "classified as INSTRUMENT / SRO / DELEGATED"},
            {"step": 3, "action": "extract", "target": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110", "status": "ok", "duration_ms": 320, "details": "46825 chars extracted, IR built with 24 nodes"},
            {"step": 4, "action": "validate", "target": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110", "status": "review", "duration_ms": 842, "issues": ["VERSION_AMBIGUOUS"]},
            {"step": 5, "action": "fetch", "target": "https://www.rbi.org.in/Scripts/BS_ViewMasterDirections.aspx", "status": "ok", "duration_ms": 2100},
            {"step": 6, "action": "classify", "target": "rbi-master-directions", "status": "ok", "details": "classified as INDEX / PRIMARY_REGULATOR"},
            {"step": 7, "action": "discover", "target": "rbi-master-directions", "status": "ok", "details": "97 entries discovered"},
            {"step": 8, "action": "fetch", "target": "https://www.ecfr.gov/current/title-17", "status": "ok", "duration_ms": 1500},
            {"step": 9, "action": "classify", "target": "ecfr-title-17", "status": "ok", "details": "classified as INSTRUMENT / GOVERNMENT / PRIMARY"},
            {"step": 10, "action": "validate", "target": "ecfr-title-17", "status": "accept", "details": "all fidelity checks passed"},
            {"step": 11, "action": "fetch", "target": "https://www.fca.org.uk/consumers", "status": "ok", "duration_ms": 800},
            {"step": 12, "action": "classify", "target": "fca-consumers", "status": "ok", "details": "classified as TOPIC_PAGE / PRIMARY_REGULATOR / CONTEXTUAL"},
            {"step": 13, "action": "fetch", "target": "https://www.fca.org.uk/handbook/prm/2", "status": "ok"},
            {"step": 14, "action": "classify", "target": "fca-prm-app2", "status": "ok", "details": "classified as HANDBOOK / PRIMARY_REGULATOR / REGULATORY_GUIDANCE"},
            {"step": 15, "action": "fetch", "target": "https://www.fca.org.uk/firms/transaction-reporting-resources", "status": "ok"},
            {"step": 16, "action": "classify", "target": "fca-transaction-reporting", "status": "ok", "details": "classified as RESOURCE_HUB"},
            {"step": 17, "action": "fetch", "target": "deutsche-bank-third-party-control.pdf", "status": "ok", "details": "PDF extracted, 12 pages"},
            {"step": 18, "action": "classify", "target": "db-third-party", "status": "ok", "details": "classified as SECONDARY_CONTROL / REGULATED_ENTITY / INSTITUTIONAL"},
            {"step": 19, "action": "validate", "target": "db-third-party", "status": "accept", "details": "99.4% fidelity, correctly NOT classified as primary regulation"},
            {"step": 20, "action": "fetch", "target": "https://www.fca.org.uk/markets/market-abuse", "status": "ok"},
            {"step": 21, "action": "classify", "target": "fca-market-abuse", "status": "ok", "details": "classified as TOPIC_PAGE, related legislation discovered"},
            {"step": 22, "action": "finish", "target": None, "status": "ok", "details": "deterministic completion gate: 5 accepted, 2 review, 1 rejected"},
        ],
    }
