from samples.documents import _sample_documents
from samples.graph import _sample_graph, _sample_review_items
from samples.runs import _sample_events, _sample_runs
from samples.sources import _sample_sources

_SAMPLE_DATA: dict | None = None


def get_sample_data() -> dict:
    global _SAMPLE_DATA
    if _SAMPLE_DATA is None:
        _SAMPLE_DATA = _build_sample_data()
    return _SAMPLE_DATA


def _build_sample_data() -> dict:
    return {
        "runs": _sample_runs(),
        "events": _sample_events(),
        "sources": _sample_sources(),
        "documents": _sample_documents(),
        "graph": _sample_graph(),
        "review": _sample_review_items(),
    }
