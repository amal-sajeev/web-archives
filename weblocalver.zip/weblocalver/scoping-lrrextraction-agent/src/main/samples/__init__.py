from samples.data import get_sample_data

__all__ = ["get_sample_data"]
