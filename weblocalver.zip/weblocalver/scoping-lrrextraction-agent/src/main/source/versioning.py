from __future__ import annotations

import re
from datetime import datetime
from models.domain import (
    DocumentVersion,
    Relationship,
    SourceClassification,
    TemporalState,
    VersionResolution,
)

_DATE_PATTERNS = [
    re.compile(r"(?:effective|in\s+force)\s+(?:from|on|date)?\s*:?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})", re.I),
    re.compile(r"(?:effective|in\s+force)\s+(?:from|on|date)?\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})", re.I),
    re.compile(r"(?:adopted|issued|published)\s+(?:on|date)?\s*:?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})", re.I),
    re.compile(r"(?:adopted|issued|published)\s+(?:on|date)?\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})", re.I),
    re.compile(r"(?:last\s+updated|amended|revised)\s*:?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})", re.I),
]

_SUPERSEDING_RE = re.compile(r"\bsupersed(?:es|ed|ing)\b|\breplac(?:es|ing|ed)\b|\bin\s+force\s+in\s+place\s+of\b", re.I)
_HISTORICAL_URL_RE = re.compile(r"/(?:history|historical|archive|revised)/", re.I)
_CURRENT_URL_RE = re.compile(r"/current/", re.I)


def extract_dates(text: str) -> dict[str, list[str]]:
    """Extract dates with their semantic labels from text."""
    found: dict[str, list[str]] = {"effective": [], "issue": [], "updated": [], "other": []}
    for pattern in _DATE_PATTERNS:
        for m in pattern.finditer(text):
            date_str = m.group(1).strip()
            label_text = m.group(0).lower()
            if "effective" in label_text or "force" in label_text:
                found["effective"].append(date_str)
            elif "adopted" in label_text or "issued" in label_text or "published" in label_text:
                found["issue"].append(date_str)
            elif "updated" in label_text or "amended" in label_text or "revised" in label_text:
                found["updated"].append(date_str)
            else:
                found["other"].append(date_str)
    for k in found:
        found[k] = list(dict.fromkeys(found[k]))
    return found


def resolve_version(document_id: str, url: str, raw_text: str, classification: SourceClassification | None = None) -> VersionResolution:
    """Resolve temporal state from available evidence."""
    reasons: list[str] = []
    confidence = 0.0

    dates = extract_dates(raw_text)
    effective_dates = dates.get("effective", [])
    issue_dates = dates.get("issue", [])
    updated_dates = dates.get("updated", [])

    # URL-based evidence
    if _CURRENT_URL_RE.search(url):
        reasons.append("URL contains /current/ path segment")
        confidence += 0.3
    if _HISTORICAL_URL_RE.search(url):
        reasons.append("URL contains historical/archive path segment")
        confidence = max(confidence - 0.3, 0.0)

    # Text-based evidence
    if _SUPERSEDING_RE.search(raw_text):
        reasons.append("text contains supersession language")
        return VersionResolution(
            current_version_id=None,
            temporal_state=TemporalState.SUPERSEDED,
            confidence=0.7,
            reasons=reasons,
            ambiguous=False,
        )

    if effective_dates:
        latest_effective = effective_dates[-1]
        reasons.append(f"effective date found: {latest_effective}")
        confidence += 0.2
        try:
            from datetime import datetime as dt
            parsed = dt.strptime(latest_effective[:24].strip(), "%B %d, %Y")
            if parsed > dt.now():
                reasons.append("effective date is in the future")
                return VersionResolution(
                    current_version_id=document_id,
                    temporal_state=TemporalState.FUTURE_EFFECTIVE,
                    confidence=round(min(confidence + 0.2, 1.0), 2),
                    reasons=reasons,
                    ambiguous=False,
                )
        except (ValueError, TypeError):
            pass

    if updated_dates:
        reasons.append(f"last updated: {updated_dates[-1]}")
        confidence += 0.2

    if classification and classification.temporal_state != TemporalState.UNKNOWN:
        reasons.append(f"classification temporal_state={classification.temporal_state.value}")
        confidence += 0.2

    if confidence >= 0.6:
        state = TemporalState.CURRENT
        ambiguous = False
    elif confidence >= 0.3:
        state = TemporalState.UNKNOWN
        ambiguous = True
        reasons.append("insufficient evidence for definitive temporal state")
    else:
        state = TemporalState.UNKNOWN
        ambiguous = True
        reasons.append("no temporal evidence found")

    return VersionResolution(
        current_version_id=document_id if state != TemporalState.UNKNOWN else None,
        temporal_state=state,
        confidence=round(confidence, 2),
        reasons=reasons,
        ambiguous=ambiguous,
    )


def build_version(document_id: str, url: str, raw_text: str, resolution: VersionResolution) -> DocumentVersion:
    dates = extract_dates(raw_text)
    return DocumentVersion(
        version_id=f"{document_id}:{resolution.temporal_state.value}",
        document_id=document_id,
        temporal_state=resolution.temporal_state,
        effective_date=dates.get("effective", [None])[0] if dates.get("effective") else None,
        issue_date=dates.get("issue", [None])[0] if dates.get("issue") else None,
        evidence=resolution.reasons,
        confidence=resolution.confidence,
    )
