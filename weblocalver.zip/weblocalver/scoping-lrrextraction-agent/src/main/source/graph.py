from models.domain import Relationship, RelationshipType


class SourceGraph:
    """Evidence-backed source/document relationship graph."""

    def __init__(self):
        self._nodes: dict[str, dict] = {}
        self._edges: list[Relationship] = []

    def add_node(self, node_id: str, metadata: dict | None = None) -> None:
        self._nodes[node_id] = metadata or {}

    def add_edge(self, from_id: str, to_id: str, rel: RelationshipType, evidence: str = "", confidence: float = 0.0, source_locator: str | None = None) -> None:
        self._edges.append(Relationship(
            from_id=from_id, to_id=to_id, relationship=rel,
            evidence=evidence, confidence=confidence, source_locator=source_locator,
        ))
        self._nodes.setdefault(from_id, {})
        self._nodes.setdefault(to_id, {})

    def nodes(self) -> dict[str, dict]:
        return dict(self._nodes)

    def edges(self) -> list[Relationship]:
        return list(self._edges)

    def edges_from(self, node_id: str) -> list[Relationship]:
        return [e for e in self._edges if e.from_id == node_id]

    def edges_to(self, node_id: str) -> list[Relationship]:
        return [e for e in self._edges if e.to_id == node_id]

    def neighbors(self, node_id: str) -> list[str]:
        direct = [e.to_id for e in self.edges_from(node_id)]
        reverse = [e.from_id for e in self.edges_to(node_id)]
        return list(set(direct + reverse))

    def to_dict(self) -> dict:
        return {
            "nodes": self._nodes,
            "edges": [e.model_dump(mode="json") for e in self._edges],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SourceGraph":
        g = cls()
        g._nodes = data.get("nodes", {})
        g._edges = [Relationship.model_validate(e) for e in data.get("edges", [])]
        return g
