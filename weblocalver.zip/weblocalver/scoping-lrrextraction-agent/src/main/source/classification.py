from __future__ import annotations

import re

from models.domain import LegalAuthorityLevel, SourceAuthority, SourceClassification, SourceRole

_HOST_AUTHORITY: dict[str, SourceAuthority] = {
    "www.finra.org": SourceAuthority.SRO,
    "finra.org": SourceAuthority.SRO,
    "www.fca.org.uk": SourceAuthority.PRIMARY_REGULATOR,
    "fca.org.uk": SourceAuthority.PRIMARY_REGULATOR,
    "www.rbi.org.in": SourceAuthority.PRIMARY_REGULATOR,
    "rbi.org.in": SourceAuthority.PRIMARY_REGULATOR,
    "www.ecfr.gov": SourceAuthority.GOVERNMENT,
    "ecfr.gov": SourceAuthority.GOVERNMENT,
    "www.sec.gov": SourceAuthority.PRIMARY_REGULATOR,
    "www.cftc.gov": SourceAuthority.PRIMARY_REGULATOR,
}

_ROLE_PATTERNS: list[tuple[re.Pattern, SourceRole]] = [
    (re.compile(r"/rulebooks/finra-rules/\d+", re.I), SourceRole.INSTRUMENT),
    (re.compile(r"/current/title-\d+", re.I), SourceRole.INSTRUMENT),
    (re.compile(r"master.direction", re.I), SourceRole.INDEX),
    (re.compile(r"/news/press-releases", re.I), SourceRole.TOPIC_PAGE),
    (re.compile(r"/rules-guidance/rulebooks", re.I), SourceRole.INDEX),
    (re.compile(r"/handbook", re.I), SourceRole.HANDBOOK),
    (re.compile(r"/guidance", re.I), SourceRole.GUIDANCE),
    (re.compile(r"/resources", re.I), SourceRole.RESOURCE_HUB),
    (re.compile(r"/amendment|/notice", re.I), SourceRole.AMENDMENT_NOTICE),
]

_TITLE_ROLE_HINTS: list[tuple[str, SourceRole]] = [
    ("master direction", SourceRole.INDEX),
    ("handbook", SourceRole.HANDBOOK),
    ("guidance", SourceRole.GUIDANCE),
    ("resources", SourceRole.RESOURCE_HUB),
    ("press release", SourceRole.TOPIC_PAGE),
    ("consumer", SourceRole.TOPIC_PAGE),
    ("market abuse", SourceRole.TOPIC_PAGE),
    ("third party", SourceRole.SECONDARY_CONTROL),
    ("control obligation", SourceRole.SECONDARY_CONTROL),
    ("amendment", SourceRole.AMENDMENT_NOTICE),
]

def classify_source_deterministic(url: str, title: str | None = None, content_type: str = "", html_hints: str = "") -> SourceClassification:
    """Classify a source using deterministic evidence first."""
    evidence: dict[str, str | bool] = {}
    reasons: list[str] = []

    # Host authority
    from main.tools import host
    h = host(url)
    authority = _HOST_AUTHORITY.get(h, SourceAuthority.UNKNOWN)
    if authority != SourceAuthority.UNKNOWN:
        evidence["host_authority"] = authority.value
        reasons.append(f"host {h} maps to {authority.value}")

    # Subdomain check
    for allowed_host, auth in _HOST_AUTHORITY.items():
        if h.endswith("." + allowed_host):
            authority = auth
            evidence["host_authority"] = authority.value
            reasons.append(f"host {h} is subdomain of {allowed_host}")

    # URL path role
    role = SourceRole.UNKNOWN
    for pattern, candidate_role in _ROLE_PATTERNS:
        if pattern.search(url):
            role = candidate_role
            evidence["url_pattern"] = pattern.pattern
            reasons.append(f"URL path matches {role.value} pattern")
            break

    # Title hints
    title_lower = (title or "").lower()
    if role == SourceRole.UNKNOWN and title_lower:
        for hint, candidate_role in _TITLE_ROLE_HINTS:
            if hint in title_lower:
                role = candidate_role
                evidence["title_hint"] = hint
                reasons.append(f"title contains '{hint}' -> {role.value}")
                break

    # Content type
    if "pdf" in content_type.lower() or url.lower().endswith(".pdf"):
        evidence["is_pdf"] = True

    # Legal authority level
    legal_level = LegalAuthorityLevel.UNKNOWN
    if role == SourceRole.INSTRUMENT:
        legal_level = LegalAuthorityLevel.PRIMARY
        if authority == SourceAuthority.SRO:
            legal_level = LegalAuthorityLevel.DELEGATED
    elif role == SourceRole.GUIDANCE:
        legal_level = LegalAuthorityLevel.REGULATORY_GUIDANCE
    elif role == SourceRole.TOPIC_PAGE:
        legal_level = LegalAuthorityLevel.CONTEXTUAL
    elif role == SourceRole.SECONDARY_CONTROL:
        legal_level = LegalAuthorityLevel.INSTITUTIONAL
    elif role == SourceRole.HANDBOOK:
        legal_level = LegalAuthorityLevel.REGULATORY_GUIDANCE
    if legal_level != LegalAuthorityLevel.UNKNOWN:
        reasons.append(f"legal authority level: {legal_level.value}")

    operative_text = role == SourceRole.INSTRUMENT or role == SourceRole.HANDBOOK
    confidence = min(1.0, len(reasons) / 3.0)

    return SourceClassification(
        source_authority=authority,
        source_role=role,
        legal_authority_level=legal_level,
        operative_text=operative_text,
        title=title,
        classification_confidence=round(confidence, 2),
        classification_reasons=reasons,
        deterministic_evidence=evidence,
    )
