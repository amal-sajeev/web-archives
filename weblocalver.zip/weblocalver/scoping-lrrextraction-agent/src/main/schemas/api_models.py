from pydantic import BaseModel, Field


class StartRunRequest(BaseModel):
    urls: list[str] = Field(min_length=1)
    resume: str | None = None
    request_id: str | None = None


class QueryRequest(BaseModel):
    query: str = Field(min_length=1)
    top_k: int = Field(default=6, ge=1, le=20)
