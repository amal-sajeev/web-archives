from enum import Enum
from typing import Literal
from pydantic import BaseModel, Field

class SourceAuthority(str, Enum):
    PRIMARY_REGULATOR = "primary_regulator"
    GOVERNMENT = "government"
    SRO = "sro"
    COURT = "court"
    REGULATED_ENTITY = "regulated_entity"
    INDUSTRY_BODY = "industry_body"
    PROFESSIONAL_BODY = "professional_body"
    SECONDARY = "secondary"
    UNKNOWN = "unknown"

class SourceRole(str, Enum):
    INSTRUMENT = "instrument"
    INDEX = "index"
    RESOURCE_HUB = "resource_hub"
    TOPIC_PAGE = "topic_page"
    GUIDANCE = "guidance"
    HANDBOOK = "handbook"
    AMENDMENT_NOTICE = "amendment_notice"
    VERSION_PAGE = "version_page"
    HISTORICAL_VERSION = "historical_version"
    ANNEX = "annex"
    APPENDIX = "appendix"
    SECONDARY_CONTROL = "secondary_control"
    COMMENTARY = "commentary"
    UNKNOWN = "unknown"

class LegalAuthorityLevel(str, Enum):
    PRIMARY = "primary"
    DELEGATED = "delegated"
    REGULATORY_GUIDANCE = "regulatory_guidance"
    CONTEXTUAL = "contextual"
    INSTITUTIONAL = "institutional"
    SECONDARY = "secondary"
    UNKNOWN = "unknown"

class TemporalState(str, Enum):
    CURRENT = "current"
    HISTORICAL = "historical"
    FUTURE_EFFECTIVE = "future_effective"
    PROPOSED = "proposed"
    ADOPTED_PENDING_EFFECTIVE = "adopted_pending_effective"
    SUPERSEDED = "superseded"
    RESCINDED = "rescinded"
    EXPIRED = "expired"
    TEMPORARY = "temporary"
    UNKNOWN = "unknown"

NodeType = Literal[
    "document", "preamble", "part", "chapter", "title", "subpart",
    "section", "subsection", "paragraph", "subparagraph",
    "supplementary_material", "annex", "appendix", "table",
    "footnote", "amendment_history", "reference",
]

RelationshipType = Literal[
    "AMENDS", "AMENDED_BY", "SUPERSEDES", "SUPERSEDED_BY",
    "IMPLEMENTS", "REFERENCES", "REFERENCED_BY", "RELATED_TO",
    "GUIDANCE_FOR", "VERSION_OF", "PART_OF", "LISTS", "DISCOVERS",
]

RejectionReason = Literal[
    "NON_AUTHORITATIVE_FOR_OBJECTIVE", "SOURCE_IDENTITY_UNRESOLVED",
    "DOCUMENT_ROLE_UNRESOLVED", "SOURCE_CORRUPTED", "EXTRACTION_TRUNCATED",
    "STRUCTURE_INCOMPLETE", "SEMANTIC_INTEGRITY_FAILURE",
    "NUMERIC_FIDELITY_FAILURE", "DATE_FIDELITY_FAILURE",
    "MODAL_FIDELITY_FAILURE", "NEGATION_FIDELITY_FAILURE",
    "VERSION_AMBIGUOUS", "CONFLICTING_VERSIONS", "UNSAFE_REDIRECT",
    "ALLOWLIST_VIOLATION", "FETCH_INCOMPLETE", "UNSUPPORTED_FORMAT",
]

class EvidenceSpan(BaseModel):
    source_snapshot_id: str | None = None
    source_url: str
    page: int | None = None
    dom_selector: str | None = None
    anchor: str | None = None
    byte_start: int | None = None
    byte_end: int | None = None
    text_hash: str | None = None

class SectionNode(BaseModel):
    node_id: str
    parent_id: str | None = None
    ordinal: int | None = None
    label: str | None = None
    title: str | None = None
    node_type: NodeType = "section"
    text: str = ""
    source_locator: EvidenceSpan | None = None
    children: list[str] = Field(default_factory=list)

class SourceSnapshot(BaseModel):
    source_url: str
    canonical_url: str
    final_url: str
    redirect_chain: list[str] = Field(default_factory=list)
    retrieved_at: str
    http_status: int
    content_type: str = ""
    content_length: int | None = None
    etag: str | None = None
    last_modified: str | None = None
    sha256_raw: str
    sha256_normalized: str | None = None
    source_title: str | None = None

class SourceClassification(BaseModel):
    publisher: str | None = None
    publisher_class: SourceAuthority = SourceAuthority.UNKNOWN
    source_authority: SourceAuthority = SourceAuthority.UNKNOWN
    source_role: SourceRole = SourceRole.UNKNOWN
    legal_authority_level: LegalAuthorityLevel = LegalAuthorityLevel.UNKNOWN
    operative_text: bool = False
    identifier: str | None = None
    title: str | None = None
    jurisdiction: str | None = None
    issue_date: str | None = None
    effective_date: str | None = None
    last_updated: str | None = None
    temporal_state: TemporalState = TemporalState.UNKNOWN
    classification_confidence: float = Field(0, ge=0, le=1)
    classification_reasons: list[str] = Field(default_factory=list)
    deterministic_evidence: dict[str, str | bool] = Field(default_factory=dict)
    llm_evidence: dict[str, str | bool] = Field(default_factory=dict)

class Relationship(BaseModel):
    from_id: str
    to_id: str
    relationship: RelationshipType
    evidence: str = ""
    confidence: float = Field(0, ge=0, le=1)
    source_locator: str | None = None

class DocumentVersion(BaseModel):
    version_id: str
    document_id: str
    temporal_state: TemporalState = TemporalState.UNKNOWN
    effective_date: str | None = None
    issue_date: str | None = None
    superseded_by: str | None = None
    supersedes: str | None = None
    evidence: list[str] = Field(default_factory=list)
    confidence: float = Field(0, ge=0, le=1)

class VersionResolution(BaseModel):
    current_version_id: str | None = None
    temporal_state: TemporalState = TemporalState.UNKNOWN
    confidence: float = Field(0, ge=0, le=1)
    reasons: list[str] = Field(default_factory=list)
    ambiguous: bool = False

class ValidationReport(BaseModel):
    overall_status: Literal["accept", "repair", "review", "reject"] = "review"
    rejection_reasons: list[RejectionReason] = Field(default_factory=list)
    sequence_similarity: float = Field(0, ge=0, le=1)
    section_coverage: float = Field(0, ge=0, le=1)
    paragraph_coverage: float = Field(0, ge=0, le=1)
    heading_coverage: float = Field(0, ge=0, le=1)
    tail_coverage: float = Field(0, ge=0, le=1)
    order_preservation: float = Field(0, ge=0, le=1)
    duplicate_rate: float = Field(0, ge=0, le=1)
    numeric_fidelity: float = Field(1, ge=0, le=1)
    date_fidelity: float = Field(1, ge=0, le=1)
    modal_fidelity: float = Field(1, ge=0, le=1)
    negation_fidelity: float = Field(1, ge=0, le=1)
    cross_reference_fidelity: float = Field(1, ge=0, le=1)
    table_coverage: float = Field(1, ge=0, le=1)
    link_coverage: float = Field(1, ge=0, le=1)
    footnote_coverage: float = Field(1, ge=0, le=1)
    page_reconciliation: float = Field(1, ge=0, le=1)
    issues: list[str] = Field(default_factory=list)
    missing_sections: list[str] = Field(default_factory=list)

class RagChunk(BaseModel):
    document_id: str
    version_id: str | None = None
    source_snapshot_id: str | None = None
    publisher: str | None = None
    jurisdiction: str | None = None
    source_role: SourceRole = SourceRole.UNKNOWN
    legal_authority_level: LegalAuthorityLevel = LegalAuthorityLevel.UNKNOWN
    temporal_state: TemporalState = TemporalState.UNKNOWN
    section_path: str = ""
    heading: str = ""
    text: str
    source_locator: str | None = None
    effective_date: str | None = None
