from __future__ import annotations

import argparse
import json
import os

from .app import DEFAULT_PORT, run_server
from .graph import build_graph, load_checkpoint
from .runtime import configure_logging


def main() -> None:
    parser = argparse.ArgumentParser(description="Agentic regulatory RAG acquisition agent")
    subparsers = parser.add_subparsers(dest="command", required=True)

    ingest = subparsers.add_parser(
        "ingest",
        help="Run bounded autonomous discovery, acquisition, validation and persistence",
    )
    ingest.add_argument("--url", action="append", required=True)
    ingest.add_argument("--output-dir", default=None)
    ingest.add_argument("--allowlist", default=None)
    ingest.add_argument("--browser", action="store_true")
    ingest.add_argument("--ocr", action="store_true")
    ingest.add_argument("--resume", default=None, help="Resume a persisted checkpoint by run ID")

    serve = subparsers.add_parser("serve", help="Start the demo API and UI server")
    serve.add_argument("--port", type=int, default=DEFAULT_PORT)

    args = parser.parse_args()
    configure_logging()

    if args.command == "ingest":
        if args.output_dir:
            os.environ["OUTPUT_DIR"] = args.output_dir
        if args.allowlist:
            os.environ["SOURCE_ALLOWLIST"] = args.allowlist
        if args.browser:
            os.environ["ENABLE_BROWSER_RENDERING"] = "true"
        if args.ocr:
            os.environ["ENABLE_OCR"] = "true"

        if args.resume:
            result = build_graph().invoke(load_checkpoint(args.resume))
        else:
            result = build_graph().invoke(
                {
                    "seeds": args.url,
                    "objective": "Acquire authoritative regulatory instruments relevant to the supplied seeds and preserve their source text exactly.",
                }
            )

        print(
            json.dumps(
                {
                    "run_id": result.get("run_id"),
                    "outputs": result.get("outputs", []),
                    "completion": result.get("completion"),
                    "errors": result.get("errors", []),
                },
                indent=2,
                default=str,
            )
        )
        return

    run_server(args.port)


if __name__ == "__main__":
    main()
