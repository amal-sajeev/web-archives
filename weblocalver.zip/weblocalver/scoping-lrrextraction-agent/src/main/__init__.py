import sys
from pathlib import Path

_MAIN_DIR = Path(__file__).resolve().parent
if str(_MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(_MAIN_DIR))

__version__ = "3.0.0"

__all__ = ["__version__"]
