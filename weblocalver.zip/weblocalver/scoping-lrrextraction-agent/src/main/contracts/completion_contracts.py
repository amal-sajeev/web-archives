from __future__ import annotations

from main.models import SourceAuthority, SourceClassification, SourceRole, ValidationReport

CONTRACTS: dict[SourceRole, list[str]] = {
    SourceRole.INSTRUMENT: [
        "identity resolved",
        "source authority resolved",
        "document type resolved",
        "structure reconstructed",
        "all expected sections/pages covered",
        "semantic integrity passed",
        "version/temporal state resolved or explicitly escalated",
        "amendment history captured when present",
        "related current version links identified",
    ],
    SourceRole.INDEX: [
        "index itself captured",
        "pagination handled",
        "entries enumerated",
        "entry titles captured",
        "dates captured when available",
        "instrument links resolved",
        "duplicates removed",
        "relevant entries classified",
    ],
    SourceRole.RESOURCE_HUB: [
        "hub captured",
        "outbound resources enumerated",
        "resource roles classified",
        "authoritative resources separated from commentary",
        "relevant resources linked into source graph",
    ],
    SourceRole.TOPIC_PAGE: [
        "page captured",
        "authority classified",
        "operative_text flag resolved",
        "related operative sources discovered",
    ],
    SourceRole.HANDBOOK: [
        "module identity",
        "hierarchy",
        "version/date state",
        "rules/provisions",
        "cross-references",
        "annexes/appendices",
    ],
    SourceRole.SECONDARY_CONTROL: [
        "publisher identity",
        "document identity",
        "document authority correctly classified",
        "full text fidelity",
        "tables/footnotes preserved",
        "version/date metadata",
    ],
    SourceRole.GUIDANCE: [
        "guidance identity",
        "issuing authority",
        "scope",
        "cross-references to operative law",
    ],
    SourceRole.AMENDMENT_NOTICE: [
        "notice identity",
        "amended instrument identified",
        "effective date",
        "scope of amendment",
    ],
}

def get_contract(role: SourceRole) -> list[str]:
    return CONTRACTS.get(role, CONTRACTS.get(SourceRole.INSTRUMENT, []))

def check_completion(role: SourceRole, ir, report: ValidationReport, classification: SourceClassification, version_resolved: bool) -> dict:
    """Check whether all contract requirements for the given role are satisfied."""
    contract = get_contract(role)
    met: list[str] = []
    unmet: list[str] = []

    for req in contract:
        if "identity resolved" in req or "identity" in req:
            if classification.title:
                met.append(req)
            else:
                unmet.append(req)
        elif "authority" in req and "classified" not in req:
            if classification.source_authority != SourceAuthority.UNKNOWN:
                met.append(req)
            else:
                unmet.append(req)
        elif "structure" in req or "hierarchy" in req:
            if ir and ir.nodes:
                met.append(req)
            else:
                unmet.append(req)
        elif "semantic integrity" in req:
            if report.numeric_fidelity >= 0.95 and report.date_fidelity >= 0.95 and report.modal_fidelity >= 1.0:
                met.append(req)
            else:
                unmet.append(req)
        elif "version" in req or "temporal" in req:
            if version_resolved:
                met.append(req)
            else:
                unmet.append(req)
        elif "sections" in req or "pages" in req or "coverage" in req:
            if report.section_coverage >= 0.90:
                met.append(req)
            else:
                unmet.append(req)
        elif "fidelity" in req:
            if report.sequence_similarity >= 0.90:
                met.append(req)
            else:
                unmet.append(req)
        else:
            met.append(req)

    return {
        "role": role.value,
        "total": len(contract),
        "met": met,
        "unmet": unmet,
        "complete": len(unmet) == 0,
    }
