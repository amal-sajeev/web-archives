from retrieval.answer import answer_query
from retrieval.rank import retrieve
from retrieval.rank import retrieve as rank_retrieve
from retrieval.store import _load_documents

load_documents = _load_documents

__all__ = ["answer_query", "load_documents", "rank_retrieve", "retrieve"]
