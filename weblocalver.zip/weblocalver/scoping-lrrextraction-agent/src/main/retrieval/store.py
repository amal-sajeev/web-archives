import json
from pathlib import Path

from config.settings import Settings

def _corpus_dir() -> Path:
    return Path(Settings().output_dir).resolve()

def _load_documents() -> list[dict]:
    corpus = _corpus_dir()
    docs: list[dict] = []
    seen: set[str] = set()

    checkpoints = corpus / "checkpoints"
    if checkpoints.exists():
        for path in sorted(checkpoints.glob("*.json")):
            try:
                ckpt = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError, TypeError):
                continue
            for d in ckpt.get("documents", []):
                url = d.get("canonical_url") or d.get("source_url") or ""
                text = (d.get("raw_text") or "").strip()
                if not url or not text or url in seen:
                    continue
                seen.add(url)
                ident = d.get("identity") or {}
                docs.append({
                    "id": url,
                    "title": ident.get("title") or url,
                    "publisher": ident.get("publisher") or "",
                    "source_url": d.get("source_url") or url,
                    "canonical_url": url,
                    "text": text,
                    "sha256": d.get("raw_sha256", ""),
                })

    for path in sorted(corpus.glob("*.md")):
        try:
            raw = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError, json.JSONDecodeError, TypeError):
            continue
        title = path.stem.replace("_", " ")
        source_url = ""
        body = raw
        if raw.startswith("---"):
            parts = raw.split("---", 2)
            if len(parts) >= 3:
                fm, body = parts[1], parts[2]
                for line in fm.splitlines():
                    if line.strip().startswith("title:"):
                        title = line.split(":", 1)[1].strip().strip('"')
                    if line.strip().startswith("source_url:"):
                        source_url = line.split(":", 1)[1].strip().strip('"')
                    if line.strip().startswith("canonical_url:") and not source_url:
                        source_url = line.split(":", 1)[1].strip().strip('"')
        key = source_url or str(path)
        if key in seen or not body.strip():
            continue
        seen.add(key)
        docs.append({
            "id": key,
            "title": title,
            "publisher": "",
            "source_url": source_url or str(path),
            "canonical_url": source_url or str(path),
            "text": body.strip(),
            "sha256": "",
        })
    return docs
