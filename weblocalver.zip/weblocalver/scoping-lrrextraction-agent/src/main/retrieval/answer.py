from config.settings import Settings
from graph.core import llm

from .rank import retrieve
from .store import _load_documents

def _extractive_answer(query: str, hits: list[dict]) -> str:
    if not hits:
        return (
            "No grounded passages were found in the acquired corpus for this question. "
            "Run an acquisition against the relevant regulator seeds, then ask again."
        )
    best = hits[0]
    return (
        f"Based on acquired source text from {best['title']}:\n\n"
        f"{best['excerpt']}\n\n"
        f"See the retrieved passages below for full grounded evidence."
    )

def _llm_answer(query: str, hits: list[dict]) -> str | None:
    if not hits:
        return None
    try:
        settings = Settings()
        settings.require_llm_config()
    except (ImportError, ValueError, RuntimeError, TypeError, OSError):
        return None
    context = "\n\n".join(
        f"[{i+1}] {h['title']} ({h['source_url']})\n{h['text'][:1800]}"
        for i, h in enumerate(hits[:4])
    )
    prompt = (
        "Answer the regulatory question using ONLY the supplied source passages. "
        "Quote or closely paraphrase the source. If the passages are insufficient, say so. "
        "Do not invent citations or rules.\n\n"
        f"QUESTION:\n{query}\n\nPASSAGES:\n{context}\n\nANSWER:"
    )
    try:
        msg = llm(settings, False).invoke(prompt)
        text = getattr(msg, "content", None) or str(msg)
        if isinstance(text, list):
            text = " ".join(str(x) for x in text)
        text = str(text).strip()
        return text or None
    except (ImportError, ValueError, RuntimeError, TypeError, OSError):
        return None

def answer_query(query: str, top_k: int = 6) -> dict:
    hits = retrieve(query, top_k=top_k)
    synthesized = _llm_answer(query, hits)
    mode = "llm_grounded" if synthesized else "extractive"
    return {
        "query": query,
        "answer": synthesized or _extractive_answer(query, hits),
        "mode": mode,
        "corpus_documents": len(_load_documents()),
        "passages": hits,
    }
