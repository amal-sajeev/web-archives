import math
import re

from config.settings import Settings
from retrieval.store import _load_documents

# Regex for tokenization and set of stop words, which were missing
_TOKEN = re.compile(r"[a-zA-Z0-9']+")
_STOP = frozenset([ # frozenset is a performance optimization
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "as", "at",
    "be", "because", "been", "before", "being", "below", "between", "both", "but", "by", "can", "did", "do",
    "does", "doing", "don", "down", "during", "each", "few", "for", "from", "further", "had", "has", "have",
    "having", "he", "her", "here", "hers", "herself", "him", "himself", "his", "how", "i", "if", "in",
    "into", "is", "it", "its", "itself", "just", "me", "more", "most", "my", "myself", "no", "nor", "not",
    "now", "o", "of", "off", "on", "once", "only", "or", "other", "our", "ours", "ourselves", "out", "over",
    "own", "s", "same", "she", "should", "so", "some", "such", "t", "than", "that", "the", "their", "theirs",
    "them", "themselves", "then", "there", "these", "they", "this", "those", "through", "to", "too", "under",
    "until", "up", "very", "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom",
    "why", "will", "with", "you", "your", "yours", "yourself", "yourselves",
])

def _tokenize(text: str) -> list[str]:
    return [t.lower() for t in _TOKEN.findall(text) if t.lower() not in _STOP and len(t) > 1]

def _chunk_text(text: str, size: int = 900, overlap: int = 120) -> list[str]:
    text = re.sub(r"\r\n?", "\n", text).strip()
    if not text:
        return []
    if len(text) <= size:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + size)
        if end < len(text):
            cut = text.rfind("\n\n", start + size // 2, end)
            if cut == -1:
                cut = text.rfind(". ", start + size // 2, end)
            if cut > start:
                end = cut + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks

def _score(query: str, query_tokens: list[str], chunk: str, title: str) -> float:
    if not query_tokens:
        return 0.0
    chunk_tokens = _tokenize(chunk)
    if not chunk_tokens:
        return 0.0
    tf: dict[str, int] = {}
    for t in chunk_tokens:
        tf[t] = tf.get(t, 0) + 1
    title_l = title.lower()
    chunk_l = chunk.lower()
    score = 0.0
    matched = 0
    for t in query_tokens:
        if t in tf:
            matched += 1
            score += 1.0 + math.log1p(tf[t])
            if t in title_l:
                score += 1.5
        elif t in title_l:
            matched += 1
            score += 1.2
    if matched == 0:
        return 0.0
    coverage = matched / len(set(query_tokens))
    score = score * (0.55 + 0.45 * coverage)
    # Prefer exact multi-word cues and rule identifiers from the question
    q_l = query.lower()
    words = [w for w in re.findall(r"[a-z0-9']+", q_l) if w not in _STOP]
    for n in (4, 3, 2):
        for i in range(len(words) - n + 1):
            phrase = " ".join(words[i : i + n])
            if len(phrase) < 8:
                continue
            if phrase in chunk_l:
                score += 2.5 * n
            if phrase in title_l:
                score += 1.5 * n
    # Keep light connectors so legal phrases like "review of customer complaints" match
    raw_words = re.findall(r"[a-z0-9']+", q_l)
    for n in (5, 4, 3):
        for i in range(len(raw_words) - n + 1):
            phrase = " ".join(raw_words[i : i + n])
            if len(phrase) < 12:
                continue
            if phrase in chunk_l:
                score += 3.0 * n
    for m in re.findall(r"\b\d{3,5}[a-z]?\b", q_l):
        if m in title_l:
            # Prefer the instrument page itself over notices/proposals about the rule
            if any(x in title_l for x in ("notice", "comment", "proposal", "adopts", "amend")):
                score += 1.0
            else:
                score += 5.0
        elif m in chunk_l[:500]:
            score += 1.5
    # Soft-penalize secondary commentary when the question is about the rule itself
    if "notice" not in q_l and any(x in title_l for x in ("notice", "comment", "proposal", "adopts", "pilot")):
        score *= 0.5
    # Penalize link-farm / notice-index chunks that drown out operative text
    linkish = chunk_l.count("](/") + chunk_l.count("](http") + chunk.count("|")
    if linkish >= 8:
        score *= 0.3
    # Strongly prefer passages that jointly mention a queried obligation term on the matching instrument
    rule_nums = re.findall(r"\b\d{3,5}[a-z]?\b", q_l)
    key_terms = [t for t in ("complaint", "complaints", "disclosure", "insider", "transaction") if t in q_l]
    if key_terms and any(t in chunk_l for t in key_terms):
        if (rule_nums and any(n in title_l or n in chunk_l for n in rule_nums)) or not rule_nums:
            score += 18.0
    return score

def retrieve(query: str, top_k: int = 6) -> list[dict]:
    q = (query or "").strip()
    if not q:
        return []
    q_tokens = _tokenize(q)
    hits: list[dict] = []
    for doc in _load_documents():
        for i, chunk in enumerate(_chunk_text(doc["text"])):
            s = _score(q, q_tokens, chunk, doc["title"])
            if s <= 0:
                continue
            hits.append({
                "score": round(s, 4),
                "title": doc["title"],
                "publisher": doc["publisher"],
                "source_url": doc["source_url"],
                "canonical_url": doc["canonical_url"],
                "sha256": doc.get("sha256", ""),
                "chunk_index": i,
                "text": chunk,
                "excerpt": chunk[:420] + ("…" if len(chunk) > 420 else ""),
            })
    hits.sort(key=lambda h: h["score"], reverse=True)
    # Diversify: best chunk per source first, then fill remaining slots
    selected: list[dict] = []
    seen_urls: set[str] = set()
    for h in hits:
        url = h["canonical_url"]
        if url in seen_urls:
            continue
        selected.append(h)
        seen_urls.add(url)
        if len(selected) >= top_k:
            return selected
    for h in hits:
        if h in selected:
            continue
        selected.append(h)
        if len(selected) >= top_k:
            break
    return selected
