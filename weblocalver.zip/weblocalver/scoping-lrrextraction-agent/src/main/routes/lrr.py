import logging
from typing import Annotated

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import Response

from main.processing.pdf_processing import process_pdf_files
from main.schemas.api_models import StartRunRequest
from main.services import data_service, run_service
from main.utils.gcs_utils import get_gcs_file_bytes, guess_content_type

# Keep module-level names pointing at the same objects the tests patch.
start_run = run_service.start_run
list_active_runs = run_service.list_active_runs
get_active_run = run_service.get_active_run
serialize_live_run_summary = run_service.serialize_live_run_summary
serialize_live_run_detail = run_service.serialize_live_run_detail
trigger_downstream_phases = run_service.trigger_downstream_phases

router = APIRouter(prefix="/lrr", tags=["LRR Processing"])
logger = logging.getLogger(__name__)


def _with_lrr_pipeline(payload: dict) -> dict:
    """Add pipeline identifier to response."""
    return {**payload, "pipeline": "lrr"}


@router.get("/download-file")
def download_file_from_gcs(file_path: str):
    """Download any file from GCS directly to the caller as a file response."""
    try:
        content, normalized_path = get_gcs_file_bytes(file_path)
        filename = normalized_path.rsplit("/", 1)[-1]
        media_type = guess_content_type(filename)
        return Response(
            content=content,
            media_type=media_type,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("GCS download failed for path=%s", file_path)
        raise HTTPException(status_code=500, detail=f"Failed to download file from GCS: {exc}") from exc


@router.post("/process-pdf")
async def process_pdf_endpoint(
    request_id: Annotated[str | None, Form()] = None,
    files: Annotated[
        list[UploadFile],
        File(description="One or more PDF files to convert to Markdown and store in GCS."),
    ] = [],
):
    file_names = [file.filename for file in files if getattr(file, "filename", None)]
    logger.info("PDF upload request received: request_id=%s file_names=%s file_count=%s", request_id, file_names, len(files))
    try:
        result = process_pdf_files(files, request_id=request_id)
        effective_request_id = (request_id or result.get("request_id") or "").strip()
        if effective_request_id:
            await trigger_downstream_phases(effective_request_id)
        logger.info(
            "PDF upload resolved: request_id=%s output_path=%s gcs_uri=%s file_count=%s",
            result.get("request_id"),
            result.get("output_path"),
            result.get("gcs_uri"),
            result.get("file_count"),
        )
        return result
    except (ValueError, TypeError, OSError) as exc:
        logger.exception("PDF processing validation failed for request_id=%s file_names=%s", request_id, file_names)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("PDF processing failed for request_id=%s file_names=%s", request_id, file_names)
        raise HTTPException(status_code=500, detail=f"PDF processing failed: {exc}") from exc


@router.get("/process", tags=["LRR Processing"])
def get_process_info():
    """Compatibility endpoint for browser/manual calls. Real processing starts with POST."""
    return {
        "message": "Use POST /lrr/process with a JSON body to start an LRR run.",
        "accepted_methods": ["POST"],
        "required_fields": ["urls"],
        "optional_fields": ["resume", "request_id"],
        "pipeline": "lrr",
    }


@router.post("/process", tags=["LRR Processing"])
def process_lrr(body: StartRunRequest):
    """Start an LRR extraction run."""
    logger.info("LRR process request received: request_id=%s urls=%s", body.request_id, body.urls)
    try:
        objective = (
            "Acquire authoritative regulatory instruments relevant to the supplied seeds "
            "and preserve their source text exactly."
        )
        live_run = start_run(seeds=body.urls, objective=objective, resume=body.resume, request_id=body.request_id)
        logger.info("LRR background run started: run_id=%s request_id=%s status=%s", live_run.run_id, body.request_id, live_run.status)
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        logger.exception("LRR process start failed")
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "run_id": live_run.run_id,
        "request_id": body.request_id or live_run.run_id,
        "status": live_run.status,
        "objective": live_run.objective,
        "seeds": live_run.seeds,
        "pipeline": "lrr",
    }


@router.get("/runs")
def get_lrr_runs():
    """List all LRR runs."""
    data, _ = data_service.get_data_snapshot()
    persisted = list(data["runs"])
    active = {run["run_id"]: run for run in list_active_runs()}
    out: list[dict] = []
    seen: set[str] = set()
    for live_run in active.values():
        out.append(_with_lrr_pipeline(serialize_live_run_summary(live_run)))
        seen.add(live_run["run_id"])
    for run in persisted:
        if run["run_id"] in seen:
            continue
        out.append(_with_lrr_pipeline(run))
    return out


@router.get("/runs/{run_id}")
def get_lrr_run(run_id: str):
    """Get LRR run details."""
    live_run = get_active_run(run_id)
    if live_run:
        return _with_lrr_pipeline(serialize_live_run_detail(live_run.snapshot()))

    run = data_service.find_record("runs", "run_id", run_id)
    if run:
        return _with_lrr_pipeline(run)

    raise HTTPException(status_code=404, detail=f"Run {run_id} not found")


@router.get("/process/{run_id}/status", tags=["LRR Processing"])
def get_process_status(run_id: str):
    """Poll status of an LRR process. Frontend calls this repeatedly to check completion."""
    live_run = get_active_run(run_id)
    if live_run:
        snapshot = live_run.snapshot()
        return {
            "run_id": run_id,
            "status": snapshot.get("status", "unknown"),
            "progress": snapshot.get("progress", 0),
            "total_steps": snapshot.get("total_steps", 0),
            "current_step": snapshot.get("current_step", 0),
            "pipeline": "lrr",
        }

    run = data_service.find_record("runs", "run_id", run_id)
    if run:
        return {
            "run_id": run_id,
            "status": run.get("status", "completed"),
            "progress": 100,
            "total_steps": run.get("total_steps", 0),
            "current_step": run.get("total_steps", 0),
            "pipeline": "lrr",
        }

    raise HTTPException(status_code=404, detail=f"Run {run_id} not found")
