import asyncio
import json
import queue

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from main.schemas.api_models import StartRunRequest
from main.services.data_service import find_record, get_data_snapshot
from main.services.run_service import (
    get_active_run,
    list_active_runs,
    serialize_live_events,
    serialize_live_run_detail,
    serialize_live_run_summary,
    start_run,
)
from main.helpers.url_validator import get_validator

router = APIRouter(prefix="/lrr/system", tags=["Run Lifecycle"])


@router.get("/mode", tags=["Run Lifecycle"])
def get_mode():
    _, mode = get_data_snapshot()
    return {"mode": mode}


@router.get("/runs", tags=["Run Lifecycle"])
def get_runs():
    data, _ = get_data_snapshot()
    persisted = list(data["runs"])
    active = {run["run_id"]: run for run in list_active_runs()}
    out: list[dict] = []
    seen: set[str] = set()
    for live_run in active.values():
        out.append(serialize_live_run_summary(live_run))
        seen.add(live_run["run_id"])
    for run in persisted:
        if run["run_id"] in seen:
            continue
        out.append(run)
    return out


@router.get("/runs/active", tags=["Run Lifecycle"])
def get_active_runs():
    return list_active_runs()


@router.post("/runs", tags=["Run Lifecycle"])
def post_run(body: StartRunRequest):
    seeds = [url.strip() for url in body.urls if url and url.strip()]
    if not seeds:
        raise HTTPException(status_code=400, detail="At least one seed URL is required")

    # Validate URLs against the approved list
    validator = get_validator()
    approved_urls, unapproved_urls = validator.validate_urls(seeds)

    if unapproved_urls:
        error_message = f"The following URLs are not in the approved list: {', '.join(unapproved_urls)}. Please use the approved list of URLs only."
        raise HTTPException(status_code=400, detail=error_message)

    try:
        objective = (
            "Acquire authoritative regulatory instruments relevant to the supplied seeds "
            "and preserve their source text exactly."
        )
        live_run = start_run(
            seeds=approved_urls,
            objective=objective,
            resume=body.resume,
            request_id=body.request_id,
        )
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {
        "run_id": live_run.run_id,
        "status": live_run.status,
        "objective": live_run.objective,
        "seeds": live_run.seeds,
    }


@router.get("/runs/{run_id}", tags=["Run Lifecycle"])
def get_run(run_id: str):
    live_run = get_active_run(run_id)
    if live_run:
        return serialize_live_run_detail(live_run.snapshot())
    run = find_record("runs", "run_id", run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return run


@router.get("/runs/{run_id}/events", tags=["Run Lifecycle"])
def get_run_events(run_id: str):
    live_run = get_active_run(run_id)
    if live_run:
        return serialize_live_events(live_run.history)
    data, _ = get_data_snapshot()
    events = data.get("events", {})
    if run_id not in events:
        raise HTTPException(status_code=404, detail="Run events not found")
    return events[run_id]


@router.get("/runs/{run_id}/live", tags=["Run Lifecycle"])
async def stream_run_live(run_id: str):
    live_run = get_active_run(run_id)
    if not live_run:
        raise HTTPException(
            status_code=404,
            detail="Live run not found — it may have finished before streaming attached. Use /events.",
        )

    subscriber = live_run.attach()

    async def generate():
        try:
            while True:
                try:
                    item = await asyncio.to_thread(subscriber.get, True, 1.0)
                except queue.Empty:
                    yield (
                        f"data: {json.dumps({'event': 'heartbeat', 'run_id': run_id, 'status': live_run.status})}\\n\\n"
                    )
                    if live_run.status in {"completed", "failed"} and subscriber.empty():
                        break
                    continue
                yield f"data: {json.dumps(item, ensure_ascii=False, default=str)}\\n\\n"
                if item.get("event") in {"run_complete", "run_error"}:
                    break
        finally:
            live_run.detach(subscriber)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
