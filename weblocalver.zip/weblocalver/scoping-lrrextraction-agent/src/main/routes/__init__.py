from routes.data import router as data_router
from routes.lrr import router as lrr_router
from routes.pages import router as page_router
from routes.query import router as query_router
from routes.runs import router as run_router

__all__ = ["data_router", "lrr_router", "page_router", "query_router", "run_router"]
