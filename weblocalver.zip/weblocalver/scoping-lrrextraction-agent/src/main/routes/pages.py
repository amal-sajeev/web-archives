from fastapi import APIRouter
from fastapi.responses import FileResponse

from helpers.paths import get_ui_dir

router = APIRouter(prefix="/lrr/ui", tags=["UI"])

_UI_DIR = get_ui_dir()


@router.get("/", tags=["UI"])
@router.get("/index.html", tags=["UI"])
def index():
    return FileResponse(str(_UI_DIR / "index.html"))


@router.get("/run.html", tags=["UI"])
def run_page():
    return FileResponse(str(_UI_DIR / "run.html"))


@router.get("/sources.html", tags=["UI"])
def sources_page():
    return FileResponse(str(_UI_DIR / "sources.html"))


@router.get("/document.html", tags=["UI"])
def document_page():
    return FileResponse(str(_UI_DIR / "document.html"))


@router.get("/validation.html", tags=["UI"])
def validation_page():
    return FileResponse(str(_UI_DIR / "validation.html"))


@router.get("/graph.html", tags=["UI"])
def graph_page():
    return FileResponse(str(_UI_DIR / "graph.html"))


@router.get("/review.html", tags=["UI"])
def review_page():
    return FileResponse(str(_UI_DIR / "review.html"))


@router.get("/query.html", tags=["UI"])
def query_page():
    return FileResponse(str(_UI_DIR / "query.html"))


@router.get("/versions.html", tags=["UI"])
def versions_page():
    return FileResponse(str(_UI_DIR / "versions.html"))
