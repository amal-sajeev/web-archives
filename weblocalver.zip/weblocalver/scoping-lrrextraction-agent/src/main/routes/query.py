from fastapi import APIRouter

from main.schemas.api_models import QueryRequest
from main.services.query_service import refresh_cache_snapshot, run_query

router = APIRouter(prefix="/lrr", tags=["Query & Cache"])


@router.post("/query", tags=["Query & Cache"])
def post_query(body: QueryRequest):
    return run_query(body.query, top_k=body.top_k)


@router.post("/cache/refresh", tags=["Query & Cache"])
def refresh_cache():
    return refresh_cache_snapshot()
