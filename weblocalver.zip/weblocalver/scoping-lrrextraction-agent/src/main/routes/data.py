import json

from fastapi import APIRouter, HTTPException
from fastapi.responses import PlainTextResponse
from google.api_core.exceptions import GoogleAPICallError
from google.cloud import storage

from config.settings import Settings
from main.services.data_service import find_record, get_data_snapshot
from main.services.document_service import build_download_name

router = APIRouter(prefix="/lrr", tags=["Data"])


def _read_gcs_json(bucket_name: str, object_name: str) -> dict | list | None:
    """Read a JSON object from GCS and return the parsed payload."""
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(object_name)

    if not blob.exists():
        raise FileNotFoundError(f"No GCS object found at: {object_name}")

    content = blob.download_as_text()
    try:
        return json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"JSON decode failed for {object_name}") from exc


@router.get("/requests/{request_id}/enriched", tags=["Data"])
def get_request_enriched_output(request_id: str):
    """Return the final enriched output artifacts for a request_id to the UI."""
    settings = Settings()
    if not settings.gcs_bucket or not settings.gcs_prefix:
        raise HTTPException(status_code=500, detail="GCS configuration is missing")

    prefix = f"{settings.gcs_prefix}_{request_id}"
    artifact_map = {
        "processing": f"{prefix}/processing-data/llr-extracted/lrr_internet_search_enriched.json",
        "inbound": f"{prefix}/inbound-data/lrr/internet_search_data_enriched.json",
    }

    loaded: dict[str, dict | list | None] = {}
    try:
        for key, object_name in artifact_map.items():
            try:
                loaded[key] = _read_gcs_json(settings.gcs_bucket, object_name)
            except FileNotFoundError:
                loaded[key] = None
    except (GoogleAPICallError, ValueError) as exc:
        raise HTTPException(status_code=500, detail=f"Unable to read enriched output from GCS: {exc}") from exc

    if all(value is None for value in loaded.values()):
        raise HTTPException(status_code=404, detail=f"No enriched output found for request_id={request_id}")

    return {
        "request_id": request_id,
        "artifacts": loaded,
        "available": {key: value is not None for key, value in loaded.items()},
    }


@router.get("/requests/{request_id}/enriched/{artifact_name}", tags=["Data"])
def get_request_enriched_artifact(request_id: str, artifact_name: str):
    """Return one of the final enriched JSON outputs by name: processing or inbound."""
    allowed = {"processing", "inbound"}
    if artifact_name not in allowed:
        raise HTTPException(status_code=400, detail=f"artifact_name must be one of: {sorted(allowed)}")

    settings = Settings()
    if not settings.gcs_bucket or not settings.gcs_prefix:
        raise HTTPException(status_code=500, detail="GCS configuration is missing")

    object_name = (
        f"{settings.gcs_prefix}_{request_id}/processing-data/llr-extracted/lrr_internet_search_enriched.json"
        if artifact_name == "processing"
        else f"{settings.gcs_prefix}_{request_id}/inbound-data/lrr/internet_search_data_enriched.json"
    )

    try:
        payload = _read_gcs_json(settings.gcs_bucket, object_name)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=f"No {artifact_name} enriched output found for request_id={request_id}") from exc
    except (GoogleAPICallError, ValueError) as exc:
        raise HTTPException(status_code=500, detail=f"Unable to read {artifact_name} enriched output: {exc}") from exc

    return {
        "request_id": request_id,
        "artifact": artifact_name,
        "data": payload,
    }


@router.get("/sources", tags=["Data"])
def get_sources():
    data, _ = get_data_snapshot()
    return data["sources"]


@router.get("/sources/{source_id}", tags=["Data"])
def get_source(source_id: str):
    source = find_record("sources", "id", source_id)
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return source


@router.get("/documents", tags=["Data"])
def get_documents():
    data, _ = get_data_snapshot()
    return [{key: value for key, value in document.items() if key != "text"} for document in data["documents"]]


@router.get("/documents/{document_id}", tags=["Data"])
def get_document(document_id: str):
    document = find_record("documents", "id", document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document


@router.get("/documents/{document_id}/tree", tags=["Data"])
def get_document_tree(document_id: str):
    document = find_record("documents", "id", document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document.get("tree", [])


@router.get("/documents/{document_id}/text", tags=["Data"])
def get_document_text(document_id: str):
    document = find_record("documents", "id", document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return {
        "id": document["id"],
        "title": document.get("title"),
        "source_url": document.get("source_url"),
        "text": document.get("text") or "",
        "chars": document.get("chars", 0),
    }


@router.get("/documents/{document_id}/download", tags=["Data"])
def download_document(document_id: str):
    document = find_record("documents", "id", document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return PlainTextResponse(
        content=document.get("text") or "",
        media_type="text/markdown; charset=utf-8",
        headers={
            "Content-Disposition": (
                f'attachment; filename="{build_download_name(document.get("title"), document_id)}"'
            )
        },
    )


@router.get("/documents/{document_id}/validation", tags=["Data"])
def get_document_validation(document_id: str):
    document = find_record("documents", "id", document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document.get("validation", {})


@router.get("/documents/{document_id}/versions", tags=["Data"])
def get_document_versions(document_id: str):
    document = find_record("documents", "id", document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document.get("versions", [])


@router.get("/graph", tags=["Data"])
def get_graph():
    data, _ = get_data_snapshot()
    return data.get("graph", {})


@router.get("/review", tags=["Data"])
def get_review():
    data, _ = get_data_snapshot()
    return data.get("review", {})
