import json
import re

from graph.core import State, _now, llm
from models import AgentMemory, CompletionAssessment, DocumentIdentity, FailureMemory, ValidationResult
from runtime.prompts import AGENT, CLASSIFIER, QA
from config.settings import Settings
from tools import authority_assessment, bounded_fetch, browser_extract, canonicalize
from tools import discover_browser_resources, discover_links
from tools import extract_html, extract_pdf, sha256_text


def _is_dead_end_reference(url: str | None) -> bool:
    """Reject generic index/catalog pages that are not source instruments and should not be expanded again."""
    if not url:
        return False
    low = canonicalize(url).lower()
    path = low.split("?", 1)[0]
    if not path:
        return False

    dead_end_markers = (
        "/index",
        "/catalog",
        "/catalogs",
        "/rulebooks",
        "/guidance",
        "/guidance/",
        "/notices",
        "/updates",
        "/consolidation",
        "/collections",
        "/resources",
        "/handbook",
        "/handbooks",
    )
    if any(marker in path for marker in dead_end_markers):
        last_segment = path.rstrip("/").split("/")[-1]
        if last_segment and not last_segment.isdigit() and not re.fullmatch(r"[a-z0-9-]+", last_segment):
            return True
        if not last_segment or last_segment in {"rulebooks", "guidance", "notices", "updates", "catalog", "catalogs", "collections", "resources", "handbook", "handbooks", "consolidation", "index"}:
            return True
    return False

def _candidate_score(c: dict) -> float:
    return float(c.get("relevance", 0)) + (0.20 if c.get("kind") == "pdf" else 0) + (0.15 if c.get("authoritative") else 0)

def _all_urls(state: State) -> set[str]:
    vals = {canonicalize(u) for u in state.get("seeds", [])} # canonicalize all URLs.
    for key in ("frontier", "candidates", "fetched", "documents", "outputs"):
        for x in state.get(key, []):
            u = x.get("url") or x.get("source_url") or x.get("canonical_url")
            if u: vals.add(canonicalize(str(u)))
    return vals

def _failure(state: State, action: str, target: str | None, error: str, recovery: str | None = None) -> dict:
    mem = AgentMemory.model_validate(state.get("memory", {}))
    mem.failures.append(FailureMemory(action=action, target=target, error=str(error), recovery=recovery, timestamp=_now()))
    mem.failures = mem.failures[-100:]
    if recovery:
        mem.failed_strategies.append(recovery)
        mem.failed_strategies = list(dict.fromkeys(mem.failed_strategies))[-30:]
    return {"memory": mem.model_dump(), "errors": [*state.get("errors", []), f"{action} {target or ''}: {error}".strip()]}

def _frontier_item(state: State, url: str | None) -> dict | None:
    if not url:
        return None
    cu = canonicalize(url)
    for x in state.get("frontier", []):
        if canonicalize(x["url"]) == cu: return x
    for x in state.get("candidates", []):
        if canonicalize(x["url"]) == cu: return x
    return None

def _repair_check(state: State, action: str, target: str | None) -> dict[str, int]:
    counts = dict(state.get("repair_attempts", {}))
    if not target or action not in ("retry", "extract"):
        return counts
    cu = canonicalize(target)
    already_fetched = any(canonicalize(x.get("final_url", x.get("requested_url", ""))) == cu for x in state.get("fetched", []))
    already_extracted = any(x.get("canonical_url") == cu for x in state.get("documents", []))
    if (action == "retry" and already_fetched) or (action == "extract" and already_extracted):
        counts[cu] = counts.get(cu, 0) + 1
    return counts


def _action_failure_key(action: str, target: str | None) -> str:
    return f"{action}:{canonicalize(target) if target else '<none>'}"


def _failed_action_count(state: State, action: str, target: str | None) -> int:
    return int(state.get("failed_actions", {}).get(_action_failure_key(action, target), 0))


def _record_action_failure(state: State, action: str, target: str | None) -> dict[str, int]:
    counts = dict(state.get("failed_actions", {}))
    key = _action_failure_key(action, target)
    counts[key] = counts.get(key, 0) + 1
    return counts


def _failure_is_permanent(error: str) -> bool:
    lowered = error.lower()
    return any(marker in lowered for marker in (
        "authority gate rejected",
        "host is not allowlisted",
        "redirect target is not allowlisted",
        "robots.txt disallows",
        "unsupported action",
    ))

def _reject_candidate(state: State, target: str) -> list[dict]:
    candidates = [dict(x) for x in state.get("candidates", [])]
    for c in candidates:
        if canonicalize(c.get("url", "")) == target:
            c["status"] = "rejected"
    return candidates


def _is_cosmetic_validation_repair(out: dict, qa: ValidationResult, det: dict, settings: Settings) -> bool:
    if qa.status != "repair":
        return False
    if det.get("missing_tail"):
        return False
    if det.get("coverage", 0.0) < 0.995 or det.get("score", 0.0) < 0.995:
        return False
    if out.get("authority_confidence", 0.0) < settings.min_authority_confidence:
        return False
    issues = [str(item).lower() for item in qa.issues]
    if not issues:
        return False
    allowed_markers = (
        "extraction artifact",
        "no results found",
        "slightly clunky",
        "formatting",
        "supplementary material",
    )
    return all(any(marker in issue for marker in allowed_markers) for issue in issues)

def _fetch_one(url: str, settings: Settings) -> dict:
    return bounded_fetch([url], settings)[0]

def _looks_like_resource_index(item: dict) -> bool:
    content_type = item.get("content_type", "").lower()
    if "html" not in content_type:
        return False
    body = item.get("content", b"").decode("utf-8", errors="ignore").lower()
    pdf_links = body.count(".pdf")
    return pdf_links >= 3 and any(term in body for term in ("master directions", "directions", "circulars", "notifications"))

def discover_page_resources(url: str, html: str, settings: Settings, terms: list[str] | None = None) -> list[dict]:
    links = discover_links(url, html, settings, terms)
    if not settings.enable_browser_rendering:
        return links
    try:
        browser_links = discover_browser_resources(url, settings)
    except (RuntimeError, ValueError, OSError):
        return links
    known = {canonicalize(item["url"]) for item in links}
    for item in browser_links:
        if canonicalize(item["url"]) not in known:
            links.append(item)
            known.add(canonicalize(item["url"]))
    # Sort the combined list of links by URL to ensure deterministic order
    links.sort(key=lambda x: x["url"])
    return links

def _extract_one(item: dict, settings: Settings) -> dict:
    url = item.get("final_url", item.get("requested_url")); content = item["content"]; ct = item.get("content_type", "").lower()
    is_pdf = item.get("kind") == "pdf" or "pdf" in ct or url.lower().endswith(".pdf") or content.startswith(b"%PDF-")
    if is_pdf:
        raw, warns, pages = extract_pdf(content, settings); fmt = "pdf"
    else:
        raw, warns = extract_html(content.decode("utf-8", errors="replace")); pages = None; fmt = "html"
        if len(raw) < settings.min_extracted_chars and settings.enable_browser_rendering:
            raw, bwarns = browser_extract(url, settings); warns.extend(bwarns)
    if len(raw) < settings.min_extracted_chars:
        raise ValueError(f"extraction too short ({len(raw)} chars)")
    ident = llm(settings, False).with_structured_output(DocumentIdentity).invoke(
        CLASSIFIER + f"\nSOURCE URL: {url}\nTITLE HINT: {item.get('title') or url}\nTEXT:\n{raw[:24000]}"
    )
    authority_score, authority_reasons = authority_assessment(url, ident.model_dump(), settings)
    low = raw[:12000].lower()
    authority_score = min(1.0, authority_score + min(.15, sum(t in low for t in ("effective date", "regulation", "rule", "section", "article", "shall", "pursuant")) * .02))
    if ident.authority_class != "instrument" or authority_score < settings.min_authority_confidence:
        raise PermissionError(f"authority gate rejected: {ident.authority_class}, confidence={authority_score:.2f}")
    return {
        "identity": ident.model_dump(), "source_url": url, "canonical_url": canonicalize(url),
        "source_format": fmt, "retrieved_at": item["retrieved_at"], "raw_text": raw,
        "raw_sha256": sha256_text(raw), "page_count": pages, "extraction_warnings": warns,
        "authority_confidence": round(authority_score, 4), "authority_reasons": authority_reasons,
    }

def render_markdown(doc: dict) -> str:
    ident = doc["identity"]
    fm = {"title": ident["title"], "publisher": ident["publisher"], "jurisdiction": ident.get("jurisdiction"), "identifier": ident.get("identifier"), "document_type": ident["document_type"], "effective_date": ident.get("effective_date"), "issue_date": ident.get("issue_date"), "source_url": doc["source_url"], "canonical_url": doc["canonical_url"], "retrieved_at": doc["retrieved_at"], "source_format": doc["source_format"], "source_sha256": doc["raw_sha256"], "authority_confidence": doc.get("authority_confidence"), "extraction_warnings": doc.get("extraction_warnings", [])}
    yaml = ["---"] + [f"{k}: {json.dumps(v, ensure_ascii=False)}" for k, v in fm.items() if v is not None] + ["---", ""]
    return "\n".join(yaml) + doc["raw_text"].strip() + "\n"

def _validate_output(out: dict, prior: dict | None, settings: Settings) -> dict:
    det = out["det_quality"]
    markdown_text = out.get("markdown", "")
    if not markdown_text:
        markdown_text = ""
    prompt = QA + f"\nSOURCE URL: {out['source_url']}\nIDENTITY: {json.dumps(out['identity'], ensure_ascii=False, default=str)}\nDETERMINISTIC QUALITY: {json.dumps(det, ensure_ascii=False, default=str)}\nMARKDOWN:\n{markdown_text[:60000]}"
    try:
        qa = llm(settings, True).with_structured_output(ValidationResult).invoke(prompt)
    except (ValueError, RuntimeError, TypeError, KeyError, OSError) as exc:
        qa = ValidationResult(status="repair", score=0.0, source_fidelity_score=det.get("coverage", 0), issues=[f"LLM QA failed: {exc}"], notes="Cannot auto-accept without QA")
    score = min(qa.score, det.get("score", 0), out.get("authority_confidence", 0))
    status = qa.status
    if det.get("coverage", 0) < .85: status = "reject"
    elif det.get("missing_tail"): status = "repair"
    elif score < settings.min_quality_score: status = "repair" if status != "reject" else status
    elif _is_cosmetic_validation_repair(out, qa, det, settings): status = "accept"
    version_kind = "new" if not prior else ("unchanged" if prior.get("source_sha256") == out.get("raw_sha256") else "changed")
    qa = qa.model_copy(update={"status": status, "score": round(max(0, min(1, score)), 4), "source_fidelity_score": det.get("coverage", 0), "deterministic_checks": {**det, "authority_confidence": out.get("authority_confidence", 0), "version_kind": version_kind}})
    # Don't include previous_version in returned dict to avoid serialization issues; store it separately if needed
    result = {**out, "validation": qa.model_dump(), "version_kind": version_kind}
    if prior:
        # Store a minimal representation to avoid serialization issues
        result["previous_version_sha256"] = prior.get("raw_sha256")
    return result

def _completion(state: State) -> CompletionAssessment:
    settings = Settings()
    accepted = [o for o in state.get("outputs", []) if o.get("validation", {}).get("status") == "accept"]
    pending = len(state.get("frontier", [])) + len([c for c in state.get("candidates", []) if c.get("status") not in {"validated", "rejected"}])
    extractable = len(state.get("documents", []))
    blockers = []
    if not accepted and not state.get("errors") and pending == 0: blockers.append("No authoritative instrument was acquired")
    if state.get("step", 0) >= settings.max_agent_steps: blockers.append("Agent step budget exhausted")
    complete = bool(accepted) or (pending == 0 and bool(state.get("errors")))
    evidence = [f"accepted_documents={len(accepted)}", f"extracted_documents={extractable}", f"pending_targets={pending}"]
    return CompletionAssessment(complete=complete, confidence=1.0 if accepted else .75 if pending == 0 else .2, blockers=blockers, evidence=evidence)

def _decision_context(state: State) -> str:
    settings = Settings()
    compact = {
        "objective": state.get("objective"), "strategy": state.get("strategy"), "plan": state.get("plan", {}),
        "step": state.get("step", 0), "max_steps": settings.max_agent_steps,
        "frontier": state.get("frontier", [])[:20],
        "candidates": [{k: c.get(k) for k in ("url", "title", "kind", "relevance", "depth", "status", "reason")} for c in state.get("candidates", [])[:30]],
        "fetched": [{k: x.get(k) for k in ("requested_url", "final_url", "content_type", "error")} for x in state.get("fetched", [])[-20:]],
        "documents": [{k: x.get(k) for k in ("source_url", "canonical_url", "authority_confidence", "source_format")} for x in state.get("documents", [])],
        "outputs": [{"source_url": x.get("source_url"), "status": x.get("validation", {}).get("status")} for x in state.get("outputs", [])],
        "errors": state.get("errors", [])[-20:], "memory": state.get("memory", {}),
        "history": state.get("history", [])[-12:], "completion": _completion(state).model_dump(),
    }
    return AGENT + "\nSTATE:\n" + json.dumps(compact, ensure_ascii=False, default=str)
