import base64
import json
from datetime import datetime, timezone
from typing import TypedDict
try:
    from langgraph.graph import END, START, StateGraph
except ImportError:
    END = START = StateGraph = None
from models.base import AgentMemory
from config.settings import Settings
from storage.storage import make_storage, GCSStorage
from runtime.llm_provider import build_llm

class State(TypedDict, total=False):
    objective: str
    seeds: list[str]
    plan: dict
    frontier: list[dict]
    candidates: list[dict]
    fetched: list[dict]
    documents: list[dict]
    outputs: list[dict]
    errors: list[str]
    review_candidates: list[dict]
    memory: dict
    decision: dict
    step: int
    run_id: str
    request_id: str | None
    done: bool
    completion: dict
    history: list[dict]
    strategy: str
    repair_attempts: dict[str, int]
    failed_actions: dict[str, int]

def _require_graph_dependencies() -> None:
    if StateGraph is None:
        raise RuntimeError("LangChain/LangGraph dependencies are not installed; run pip install -e .")

def llm(settings: Settings, reasoning: bool = False):
    return build_llm(settings, reasoning)

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _storage(settings: Settings):
    return make_storage(settings)

def _load_registry(storage) -> dict:
    raw = storage.read("registry.json")
    if not raw:
        return {"documents": {}}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {"documents": {}}
    except (json.JSONDecodeError, TypeError):
        return {"documents": {}}


def _load_memory(storage) -> AgentMemory:
    raw = storage.read("agent_memory.json")
    if not raw:
        return AgentMemory()
    try:
        return AgentMemory.model_validate(json.loads(raw))
    except (ValueError, TypeError, KeyError, json.JSONDecodeError):
        return AgentMemory()


def _load_registry_for_settings(settings: Settings) -> dict:
    return _load_registry(_storage(settings))


def _load_memory_for_settings(settings: Settings) -> AgentMemory:
    return _load_memory(_storage(settings))

def _json_safe(value):
    if isinstance(value, bytes):
        return {"__bytes__": base64.b64encode(value).decode("ascii")}
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    return value

def _json_restore(value):
    if isinstance(value, dict):
        if set(value) == {"__bytes__"}:
            return base64.b64decode(value["__bytes__"])
        return {k: _json_restore(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_restore(v) for v in value]
    return value

def _save_checkpoint(state: State, settings: Settings) -> None:
    if not settings.checkpoint_every_step:
        return
    
    storage = _storage(settings)
    request_id = state.get("request_id")

    if request_id and settings.gcs_bucket:
        dynamic_prefix = f"{settings.gcs_prefix}_{request_id}/processing-data/llr-extracted"
        storage = GCSStorage(settings.gcs_bucket, dynamic_prefix)

    payload = _json_safe(dict(state))
    storage.write(f"checkpoints/{state['run_id']}.json", json.dumps(payload, indent=2, ensure_ascii=False, default=str))

def load_checkpoint(run_id: str, settings: Settings | None = None) -> State:
    settings = settings or Settings()
    raw = _storage(settings).read(f"checkpoints/{run_id}.json")
    if not raw:
        raise FileNotFoundError(f"Checkpoint not found: {run_id}")
    data = _json_restore(json.loads(raw))
    if not isinstance(data, dict):
        raise ValueError("Checkpoint is not a state object")
    data["resume"] = True
    return data
