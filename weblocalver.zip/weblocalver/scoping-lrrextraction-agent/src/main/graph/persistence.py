import json
from urllib.parse import urlparse

from graph.core import State, _load_registry, _now, _storage
from graph.fetch_helper import _completion
from runtime.observability import event
from config.settings import Settings
from storage import GCSStorage
from tools import slugify


def _publisher_slug(identity: dict, canonical_url: str) -> str:
    publisher = slugify(identity.get("publisher") or "")
    if publisher:
        return publisher
    host = urlparse(canonical_url).netloc.lower()
    return slugify(host) or "unknown"


def _date_token(identity: dict) -> str:
    for key in ("effective_date", "issue_date"):
        raw = (identity.get(key) or "").strip()
        if raw:
            return slugify(raw[:10])
    return ""


def _build_object_key(out: dict, run_id: str, request_id: str | None) -> tuple[str, str]:
    identity = out["identity"]
    publisher = _publisher_slug(identity, out.get("canonical_url", ""))
    
    if request_id:
        # Use the specific format for raw data when request_id is present
        filename = f"lrr_raw_data_{request_id}.md"
        return filename, filename
    else:
        subject = slugify(identity.get("identifier") or identity.get("title") or "document")
        date_tag = _date_token(identity)
        run_tag = slugify(run_id)[-12:] or "run"
        hash_tag = out.get("raw_sha256", "")[:8] or "content"

        if date_tag:
            filename = f"{subject}__{date_tag}__{run_tag}__{hash_tag}.md"
        else:
            filename = f"{subject}__{run_tag}__{hash_tag}.md"
        return f"{publisher}/{filename}", filename

def persist_node(state: State) -> State:
    settings = Settings(); settings.require_source_allowlist()
    run = state.get("run_id", "run")
    request_id = state.get("request_id")    
    outputs = state.get("outputs", [])
    print(f"[persist_node] Processing {len(outputs)} accepted documents")

    # Default storage
    storage = _storage(settings)
    corpus_storage = storage
    raw_data_storage = storage

    # If GCS and request_id are present, create dynamic storage objects
    if request_id and settings.gcs_bucket:
        corpus_prefix = f"{settings.gcs_prefix}_{request_id}/processing-data/llr-extracted/lrr_corpus"
        raw_data_prefix = f"{settings.gcs_prefix}_{request_id}/processing-data/llr-extracted"
        corpus_storage = GCSStorage(settings.gcs_bucket, corpus_prefix)
        raw_data_storage = GCSStorage(settings.gcs_bucket, raw_data_prefix)

    registry = _load_registry(storage) # Registry is always at the root
    registry.setdefault("documents", {})

    accepted = []
    review = list(state.get("review_candidates", []))
    output_path = str(settings.output_dir)
    if request_id and settings.gcs_bucket:
        output_path = f"gs://{settings.gcs_bucket}/{settings.gcs_prefix}_{request_id}/processing-data/llr-extracted"
    else:
        output_path = str(settings.output_dir)

    # Always ensure the request-scoped raw markdown is written when a request_id exists.
    if request_id and settings.gcs_bucket and outputs:
        raw_key = f"lrr_raw_data_{request_id}.md"
        raw_storage = GCSStorage(settings.gcs_bucket, f"{settings.gcs_prefix}_{request_id}/processing-data/llr-extracted")
        if outputs:
            preferred = outputs[0]
            text = preferred.get("markdown") or preferred.get("raw_text") or ""
            if text:
                raw_path = raw_storage.write(raw_key, text, if_absent=False)
                print(f"[Phase 1] Successfully wrote to {raw_path}")

    manifest = {
        "run_id": run,
        "created_at": _now(),
        "objective": state.get("objective"),
        "strategy": state.get("strategy"),
        "steps": state.get("step", 0),
        "history": state.get("history", []),
        "errors": state.get("errors", []),
        "completion": state.get("completion") or _completion(state).model_dump(),
        "output_dir": output_path,
        "documents": [],
    }

    for out in state.get("outputs", []):
        v = out.get("validation", {})
        ident = out["identity"]
        if v.get("status") != "accept":
            review.append({
                "source_url": out["source_url"],
                "stage": "validation",
                "status": v.get("status"),
                "issues": v.get("issues", []),
                "missing_sections": v.get("missing_sections", []),
                "identity": ident,
            })
            continue

        key, filename = _build_object_key(out, run, request_id)
        active_storage = raw_data_storage if request_id else corpus_storage
        path = active_storage.write(key, out["markdown"], if_absent=False)
        print(f"[Phase 1] Successfully wrote to {path}")
        
        prior = registry["documents"].get(out["canonical_url"])
        now = _now()
        history = list((prior or {}).get("history", []))
        if prior and prior.get("source_sha256") != out["raw_sha256"]:
            history.append({
                "source_sha256": prior.get("source_sha256"),
                "markdown_sha256": prior.get("markdown_sha256"),
                "path": prior.get("path"),
                "seen_at": now,
            })

        registry["documents"][out["canonical_url"]] = {
            "path": path,
            "object_key": key,
            "file_name": filename,
            "source_url": out["source_url"],
            "canonical_url": out["canonical_url"],
            "title": ident["title"],
            "identifier": ident.get("identifier"),
            "effective_date": ident.get("effective_date"),
            "issue_date": ident.get("issue_date"),
            "source_sha256": out["raw_sha256"],
            "markdown_sha256": out["markdown_sha256"],
            "first_seen": (prior or {}).get("first_seen", now),
            "last_seen": now,
            "version_kind": out.get("version_kind", "new"),
            "history": history,
        }

        item = {
            "path": path,
            "object_key": key,
            "file_name": filename,
            "source_url": out["source_url"],
            "sha256": out["markdown_sha256"],
            "source_sha256": out["raw_sha256"],
            "version_kind": out.get("version_kind", "new"),
        }
        if settings.enable_source_snapshots:
            snapshot_key = f"snapshots/{out['raw_sha256']}.md"
            legacy_snapshot_key = f"snapshots/{out['raw_sha256']}.txt"
            snapshot_markdown = (
                f"---\n"
                f"source_url: {json.dumps(out['source_url'], ensure_ascii=False)}\n"
                f"canonical_url: {json.dumps(out['canonical_url'], ensure_ascii=False)}\n"
                f"source_sha256: {json.dumps(out['raw_sha256'], ensure_ascii=False)}\n"
                f"run_id: {json.dumps(run, ensure_ascii=False)}\n"
                f"---\n\n"
                f"{out['raw_text'].strip()}\n"
            )
            # Snapshots go to the main corpus storage
            corpus_storage.write(snapshot_key, snapshot_markdown, if_absent=True)
            corpus_storage.delete(legacy_snapshot_key)
            item["snapshot"] = snapshot_key

        accepted.append(item)
        manifest["documents"].append(item)

    manifest["review"] = review
    # These management files go to the main corpus storage
    registry_key = "registry.json"
    manifest_key = f"manifests/{run}.json"
    memory_key = "agent_memory.json"
    corpus_storage.write(registry_key, json.dumps(registry, indent=2, ensure_ascii=False))
    corpus_storage.write(manifest_key, json.dumps(manifest, indent=2, ensure_ascii=False))
    corpus_storage.write(memory_key, json.dumps(state.get("memory", {}), indent=2, ensure_ascii=False))
    if settings.require_human_review_on_rejection and review:
        corpus_storage.write(f"review/{run}.json", json.dumps(review, indent=2, ensure_ascii=False))

    # Pass the entire state to the event so the logger can get the request_id
    event("run_complete", **state)
    return {"outputs": accepted, "review_candidates": review, "done": True, "completion": manifest["completion"], "output_dir": output_path}
