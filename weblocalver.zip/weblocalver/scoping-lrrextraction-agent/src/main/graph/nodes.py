from datetime import datetime, timezone

from graph.core import State, llm, _load_memory_for_settings
from graph.fetch_helper import _completion, _decision_context
from models import AgentDecision, AgentMemory, Plan
from runtime.observability import configure_logging, timed
from runtime.prompts import PLANNER
from config.settings import Settings
from tools.network import canonicalize, allowed


def _settings() -> Settings:
    return Settings()


def _require_settings() -> Settings:
    settings = _settings()
    settings.require_source_allowlist()
    return settings

def plan_node(state: State) -> State:
    settings = _require_settings(); configure_logging()
    if state.get("resume") and state.get("plan"):
        return state
    memory = _load_memory_for_settings(settings) if state.get("resume") else AgentMemory()
    objective = state.get("objective") or "Acquire authoritative regulatory instruments relevant to the supplied seeds and preserve their source text exactly."
    prompt = PLANNER + f"\nOBJECTIVE:\n{objective}\nSEEDS:\n" + "\n".join(state["seeds"])
    with timed("plan"):
        plan = llm(settings, True).with_structured_output(Plan).invoke(prompt)
    return {"plan": plan.model_dump(), "strategy": plan.strategy, "memory": memory.model_dump(), "history": [], "step": 0, "done": False}

def bootstrap_node(state: State) -> State:
    settings = _require_settings()
    if state.get("resume"):
        # Re-register seed hosts so allowlist checks work after resume.
        return state
    seeds = []
    for u in state.get("seeds", []):
        cu = canonicalize(u)
        if cu not in seeds:
            seeds.append(cu)
    invalid = [u for u in seeds if not allowed(u, settings)]
    if invalid:
        raise ValueError("Seed URL is outside SOURCE_ALLOWLIST: " + ", ".join(invalid))
    frontier = [{"url": u, "depth": 0, "reason": "seed"} for u in seeds]
    return {
        "seeds": seeds,
        "frontier": frontier,
        "candidates": [],
        "fetched": [],
        "documents": [],
        "outputs": [],
        "errors": [],
        "review_candidates": [],
        "run_id": state.get("run_id") or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"),
        "request_id": state.get("request_id") or state.get("run_id") or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"),
        "history": [], "step": 0, "done": False,
        "repair_attempts": {},
        "failed_actions": {},
    }

def agent_decide_node(state: State) -> State:
    settings = _require_settings()
    if state.get("step", 0) >= settings.max_agent_steps:
        decision = AgentDecision(action="finish", reason="Step budget exhausted")
    else:
        completion = _completion(state)
        if completion.complete:
            decision = AgentDecision(action="finish", reason="Deterministic completion gate is satisfied", expected_evidence=completion.evidence)
        else:
            seed_urls = {canonicalize(u) for u in state.get("seeds", [])}
            accepted_seed = next(
                (
                    x for x in state.get("outputs", [])
                    if x.get("validation", {}).get("status") == "accept"
                    and canonicalize(str(x.get("source_url") or x.get("canonical_url") or "")) in seed_urls
                ),
                None,
            )
            if accepted_seed:
                decision = AgentDecision(
                    action="finish",
                    reason="Accepted authoritative seed URL; stop further discovery.",
                    expected_evidence=["accepted_seed_matches_request"],
                )
            else:
                # Deterministically drain extracted documents into validation before asking the
                # LLM to choose more acquisition work. This prevents repeated extract actions
                # from consuming the agent budget on already-extracted sources.
                validated = {canonicalize(x.get("canonical_url", "")) for x in state.get("outputs", [])}
                pending_validation = next(
                    (x for x in state.get("documents", [])
                     if canonicalize(x.get("canonical_url", "")) not in validated),
                    None,
                )
                if pending_validation:
                    decision = AgentDecision(
                        action="validate",
                        target=pending_validation.get("source_url") or pending_validation.get("canonical_url"),
                        reason="Validate an extracted authoritative document before further discovery",
                    )
                else:
                    seed_urls = {canonicalize(u) for u in state.get("seeds", [])}
                    expandable = next(
                        (x for x in state.get("fetched", [])
                         if "html" in str(x.get("content_type", "")).lower()
                         and not x.get("expanded")
                         and canonicalize(str(x.get("final_url") or x.get("requested_url") or "")) not in seed_urls),
                        None,
                    )
                    if expandable:
                        decision = AgentDecision(
                            action="expand",
                            target=expandable.get("final_url") or expandable.get("requested_url"),
                            reason="Expand a fetched HTML source that has not yet been traversed",
                        )
                    else:
                        decision = llm(settings, True).with_structured_output(AgentDecision).invoke(_decision_context(state))
    return {"decision": decision.model_dump()}



def route_after_action(state: State) -> str:
    return "end" if state.get("done") or state.get("step", 0) >= _settings().max_agent_steps else "continue"
