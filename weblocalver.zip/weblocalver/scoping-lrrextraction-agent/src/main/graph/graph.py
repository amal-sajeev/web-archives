from graph.core import END, START, State, StateGraph, _require_graph_dependencies
from graph.nodes import agent_decide_node, bootstrap_node, plan_node, route_after_action
from graph import actions as _graph_actions
from graph.persistence import persist_node


def execute_action_node(state: State) -> State:
    """Delegate execution to the graph action layer."""
    return _graph_actions.execute_action_node(state)


def build_graph():
    _require_graph_dependencies()
    g = StateGraph(State)
    for name, fn in [
        ("bootstrap", bootstrap_node),
        ("plan", plan_node),
        ("agent_decide", agent_decide_node),
        ("execute_action", execute_action_node),
        ("persist", persist_node),
    ]:
        g.add_node(name, fn)

    g.add_edge(START, "bootstrap")
    g.add_edge("bootstrap", "plan")
    g.add_edge("plan", "agent_decide")
    g.add_edge("agent_decide", "execute_action")
    g.add_conditional_edges(
        "execute_action",
        route_after_action,
        {"continue": "agent_decide", "end": "persist"},
    )
    g.add_edge("persist", END)
    return g.compile()
