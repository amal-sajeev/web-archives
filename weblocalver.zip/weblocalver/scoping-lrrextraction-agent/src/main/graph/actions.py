from graph.core import State, _load_registry_for_settings, _save_checkpoint
from graph.fetch_helper import (
    _failure, _failed_action_count, _fetch_one, _frontier_item, _looks_like_resource_index,
    _record_action_failure, _repair_check, _reject_candidate, _validate_output, render_markdown,
    discover_page_resources, _failure_is_permanent, _action_failure_key, _all_urls, _extract_one, _completion,
    _is_dead_end_reference,
)
from models import AgentDecision, AgentMemory
from runtime.observability import event
from config.settings import Settings
from tools import canonicalize, deterministic_quality, sha256_text


def _action_observability_fields(state: State) -> dict[str, int | str | None]:
    errors = state.get("errors", [])
    return {
        "errors": len(errors),
        "frontier_count": len(state.get("frontier", [])),
        "candidate_count": len(state.get("candidates", [])),
        "fetched_count": len(state.get("fetched", [])),
        "document_count": len(state.get("documents", [])),
        "output_count": len(state.get("outputs", [])),
        "last_error": errors[-1] if errors else None,
    }


def _matching_fetched_item(state: State, target: str | None) -> dict | None:
    if not target:
        return None
    normalized = canonicalize(target)
    for item in state.get("fetched", []):
        requested = canonicalize(str(item.get("requested_url", ""))) if item.get("requested_url") else None
        final = canonicalize(str(item.get("final_url", ""))) if item.get("final_url") else None
        if normalized == requested or normalized == final:
            return item
    return None


def _matching_document(state: State, target: str | None) -> dict | None:
    if not target:
        return None
    normalized = canonicalize(target)
    for item in state.get("documents", []):
        source = canonicalize(str(item.get("source_url", ""))) if item.get("source_url") else None
        doc_url = canonicalize(str(item.get("canonical_url", ""))) if item.get("canonical_url") else None
        if normalized == source or normalized == doc_url:
            return item
    return None

def execute_action_node(state: State) -> State:
    settings = Settings(); settings.require_source_allowlist()
    d = AgentDecision.model_validate(state.get("decision", {})); action = d.action; target = canonicalize(d.target) if d.target else None
    action_failed = False
    prior_failures = _failed_action_count(state, action, target)
    if target and prior_failures > 0 and action == "extract":
        last_error = next((e for e in reversed(state.get("errors", [])) if target in e), "")
        if _failure_is_permanent(last_error):
            action = "reconsider"
            target = None
            d = d.model_copy(update={"reason": "Skip permanently rejected extraction target and continue with other candidates."})
    if action == "discover" and target and not _frontier_item(state, target):
        frontier_target = next((x.get("url") for x in state.get("frontier", []) if x.get("url")), None)
        if frontier_target:
            target = canonicalize(frontier_target)
            d = d.model_copy(update={"reason": "Use the concrete frontier URL instead of an invented discovery target."})
    if target:
        fetched_item = _matching_fetched_item(state, target)
        if action == "fetch" and fetched_item and not fetched_item.get("error"):
            action = "extract"
        elif action == "expand" and not fetched_item:
            action = "fetch"
        elif action == "expand" and fetched_item and "html" not in fetched_item.get("content_type", "").lower():
            action = "extract"
        elif action == "extract" and fetched_item and _looks_like_resource_index(fetched_item):
            action = "expand"
    next_state: State = {"step": state.get("step", 0) + 1}
    history = list(state.get("history", [])); history.append({"step": next_state["step"], "action": action, "target": target, "reason": d.reason})
    next_state["history"] = history[-100:]
    next_state["strategy"] = d.strategy_change or state.get("strategy", "")
    try:
        if action == "finish":
            next_state["done"] = True
            next_state["completion"] = _completion(state).model_dump()
        elif action in {"discover", "fetch", "retry"}:
            if not target or not _frontier_item(state, target):
                raise ValueError("target must be a concrete frontier/candidate URL")
            item = _frontier_item(state, target) or {"url": target}
            if action == "retry":
                counts = _repair_check(state, "retry", target)
                next_state["repair_attempts"] = counts
                if counts.get(target, 0) > settings.max_repair_attempts:
                    next_state["candidates"] = _reject_candidate(state, target)
                    raise ValueError(f"repair budget exhausted for {target} after {counts[target]} attempts")
            fetched = _fetch_one(target, settings)
            if "error" in fetched: raise RuntimeError(fetched["error"])
            fetched = {**item, **fetched, "status": "fetched"}
            fs = [x for x in state.get("fetched", []) if canonicalize(x.get("final_url", x.get("requested_url", ""))) != target]
            fs.append(fetched)
            next_state["fetched"] = fs
            candidates = [dict(x) for x in state.get("candidates", [])]
            found = False
            for c in candidates:
                if canonicalize(c["url"]) == target: c.update(fetched); c["status"] = "fetched"; found = True
            if not found: candidates.append(fetched)
            next_state["candidates"] = candidates
            frontier = [x for x in state.get("frontier", []) if canonicalize(x["url"]) != target]
            next_state["frontier"] = frontier
            if action == "discover" and fetched.get("content_type", "").lower().find("html") >= 0:
                links = discover_page_resources(fetched["final_url"], fetched["content"].decode("utf-8", errors="replace"), settings, state.get("plan", {}).get("discovery_terms", []))
                known = _all_urls(state) | {canonicalize(x["url"]) for x in candidates}
                new_depth = int(item.get("depth", 0)) + 1
                for c in links:
                    cu = canonicalize(c["url"])
                    if _is_dead_end_reference(cu):
                        continue
                    if cu not in known and c.get("relevance", 0) >= .10 and new_depth <= settings.max_discovery_depth:
                        frontier.append({"url": cu, "depth": new_depth, "reason": c.get("reason", "discovered"), "title": c.get("title"), "kind": c.get("kind"), "relevance": c.get("relevance", 0)})
                next_state["frontier"] = frontier[:settings.max_pages]
        elif action == "expand":
            if not target: raise ValueError("expand requires a fetched HTML URL")
            item = _matching_fetched_item(state, target)
            if not item: raise ValueError("expand target is not fetched")
            if "html" not in item.get("content_type", "").lower(): raise ValueError("expand target is not HTML")
            links = discover_page_resources(item["final_url"], item["content"].decode("utf-8", errors="replace"), settings, state.get("plan", {}).get("discovery_terms", []))
            known = _all_urls(state); frontier = list(state.get("frontier", []))
            new_depth = int(item.get("depth", 0)) + 1
            for c in links:
                cu = canonicalize(c["url"])
                if _is_dead_end_reference(cu):
                    continue
                if cu not in known and c.get("relevance", 0) >= .10 and new_depth <= settings.max_discovery_depth:
                    frontier.append({"url": cu, "depth": new_depth, "reason": "expanded fetched source", **{k: c.get(k) for k in ("title", "kind", "relevance")}})
                    known.add(cu)
            next_state["frontier"] = frontier[:settings.max_pages]
            fetched = [dict(x) for x in state.get("fetched", [])]
            for fetched_item in fetched:
                if canonicalize(fetched_item.get("final_url", fetched_item.get("requested_url", ""))) == target:
                    fetched_item["expanded"] = True
            next_state["fetched"] = fetched
        elif action == "extract":
            if not target: raise ValueError("extract requires a fetched URL")
            item = _matching_fetched_item(state, target)
            if not item: raise ValueError("extract target is not fetched")
            counts = _repair_check(state, "extract", target)
            next_state["repair_attempts"] = counts
            if counts.get(target, 0) > settings.max_repair_attempts:
                next_state["candidates"] = _reject_candidate(state, target)
                raise ValueError(f"repair budget exhausted for {target} after {counts[target]} attempts")
            doc = _extract_one(item, settings)
            docs = [x for x in state.get("documents", []) if x.get("canonical_url") != doc["canonical_url"]]; docs.append(doc)
            next_state["documents"] = docs
            candidates = [dict(x) for x in state.get("candidates", [])]
            for c in candidates:
                if canonicalize(c["url"]) == target: c["status"] = "extracted"
            next_state["candidates"] = candidates
        elif action == "validate":
            if not target: raise ValueError("validate requires a source URL")
            doc = _matching_document(state, target)
            if not doc: raise ValueError("validate target is not extracted")
            md = render_markdown(doc); det = deterministic_quality(doc["raw_text"], md)
            out = {**doc, "markdown": md, "markdown_sha256": sha256_text(md), "det_quality": det}
            prior = _load_registry_for_settings(settings).get("documents", {}).get(doc["canonical_url"])
            out = _validate_output(out, prior, settings)
            outputs = [x for x in state.get("outputs", []) if x.get("canonical_url") != out["canonical_url"]]; outputs.append(out)
            next_state["outputs"] = outputs
            if out["validation"]["status"] != "accept":
                next_state["review_candidates"] = [*state.get("review_candidates", []), {"source_url": target, "stage": "validation", "status": out["validation"]["status"], "issues": out["validation"].get("issues", [])}]
        elif action == "reconsider":
            mem = AgentMemory.model_validate(state.get("memory", {})); mem.successful_strategies.append(d.strategy_change or d.reason); mem.successful_strategies = list(dict.fromkeys(mem.successful_strategies))[-30:]
            next_state["memory"] = mem.model_dump()
        else:
            raise ValueError(f"Unsupported action: {action}")
    except (ValueError, RuntimeError, OSError, TypeError, KeyError, PermissionError) as exc:
        action_failed = True
        next_state.update(_failure(state, action, target, exc, d.strategy_change))
        failed_actions = _record_action_failure(state, action, target)
        next_state["failed_actions"] = failed_actions
        if target and (_failure_is_permanent(str(exc)) or failed_actions.get(_action_failure_key(action, target), 0) >= settings.max_repair_attempts + 1):
            next_state["candidates"] = _reject_candidate({**state, "candidates": next_state.get("candidates", state.get("candidates", []))}, target)
            next_state["frontier"] = [x for x in state.get("frontier", []) if canonicalize(x.get("url", "")) != target]
            if _is_dead_end_reference(target):
                next_state["frontier"] = [x for x in next_state.get("frontier", []) if not _is_dead_end_reference(x.get("url"))]
        merged = dict(state)
        merged.update(next_state)
        event(
            "agent_action_failed",
            run_id=merged.get("run_id"),
            step=next_state["step"],
            action=action,
            target=target,
            error=str(exc),
            error_type=type(exc).__name__,
            status="error",
            recovery=d.strategy_change,
            permanent=_failure_is_permanent(str(exc)),
            **_action_observability_fields(merged),
        )
    merged = dict(state); merged.update(next_state)
    if next_state.get("step", 0) > 0:
        _save_checkpoint(merged, settings)
    if not action_failed:
        event(
            "agent_action",
            run_id=merged.get("run_id"),
            step=next_state["step"],
            action=action,
            target=target,
            status="ok",
            **_action_observability_fields(merged),
        )
    return next_state

