from pathlib import Path
from live.builder import _build_live_data

_LIVE_DATA: dict | None = None

def invalidate_live_data() -> None:
    global _LIVE_DATA
    _LIVE_DATA = None

def get_live_data() -> dict | None:
    global _LIVE_DATA
    if _LIVE_DATA is None:
        _LIVE_DATA = _build_live_data()
    return _LIVE_DATA

def _corpus_dir() -> Path:
    from main.config.settings import Settings
    return Path(Settings().output_dir).resolve()
