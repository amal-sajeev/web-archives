from urllib.parse import urlparse
from source.classification import classify_source_deterministic
from tools.quality import slugify

def _source_id(url: str) -> str:
    return slugify(url)[-80:] or "unknown"

def _domain(url: str) -> str:
    from urllib.parse import urlparse
    return urlparse(url).netloc.lower()

def _build_source(url: str, content_type: str, status: int, retrieved_at: str) -> dict:
    c = classify_source_deterministic(url)
    fmt = "pdf" if "pdf" in content_type.lower() or url.lower().endswith(".pdf") else "html"
    status_label = "accepted" if status == 200 else "error"
    return {
        "id": _source_id(url),
        "publisher": c.title or _domain(url),
        "domain": _domain(url),
        "source_role": c.source_role.value,
        "source_authority": c.source_authority.value,
        "legal_authority_level": c.legal_authority_level.value,
        "document_type": c.source_role.value,
        "temporal_state": c.temporal_state.value,
        "retrieved_at": retrieved_at,
        "hash": "...",
        "status": status_label,
        "url": url,
        "format": fmt,
    }

def _node_to_dict(n) -> dict:
    return {
        "node_id": n.node_id,
        "parent_id": n.parent_id,
        "label": n.label,
        "title": n.title,
        "node_type": n.node_type,
        "text": n.text[:500] if n.text else "",
        "children": n.children,
    }
