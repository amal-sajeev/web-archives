import json
from config.settings import Settings
from storage.storage import make_storage
from processing.parser import build_ir_from_text
from source.classification import classify_source_deterministic
from source.versioning import resolve_version
from live.source import _build_source, _node_to_dict, _source_id


def _run_id_from_key(key: str) -> str:
    leaf = key.rsplit("/", 1)[-1]
    return leaf[:-5] if leaf.endswith(".json") else leaf


def _load_json_map(storage, prefix: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for key in storage.list_keys(prefix=prefix, suffix=".json"):
        raw = storage.read(key)
        if not raw:
            continue
        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            continue
        if not isinstance(parsed, dict):
            continue
        run_id = str(parsed.get("run_id") or _run_id_from_key(key))
        out[run_id] = parsed
    return out

def _build_live_data() -> dict | None:
    storage = make_storage(Settings())
    manifests_by_run = _load_json_map(storage, "manifests/")
    checkpoints_by_run = _load_json_map(storage, "checkpoints/")
    if not manifests_by_run and not checkpoints_by_run:
        return None

    runs: list[dict] = []
    events: dict[str, list[dict]] = {}
    sources: list[dict] = []
    documents: list[dict] = []
    graph_nodes: dict[str, dict] = {}
    graph_edges: list[dict] = []
    review: list[dict] = []

    for run_id, manifest in sorted(manifests_by_run.items()):
        steps = manifest.get("steps", 0)
        objective = manifest.get("objective", "")
        errors = manifest.get("errors", [])
        history = manifest.get("history", [])

        # Build events from history
        run_events = []
        for h in history:
            run_events.append({
                "step": h.get("step", 0),
                "action": h.get("action", ""),
                "target": h.get("target"),
                "status": "ok" if not h.get("error") else "error",
                "details": h.get("reason", "")[:200],
                "duration_ms": 0,
                "issues": [h["error"]] if h.get("error") else [],
            })
        events[run_id] = run_events

        # Build run summary
        accepted = len(manifest.get("documents", []))
        review_count = len(manifest.get("review", []))
        # Count extracted documents from the corresponding checkpoint
        doc_count = accepted
        ckpt = checkpoints_by_run.get(run_id)
        if ckpt:
            doc_count = len(ckpt.get("documents", []))
        runs.append({
            "run_id": run_id,
            "objective": objective,
            "status": "completed" if manifest.get("completion", {}).get("complete") else "incomplete",
            "step": steps,
            "duration_ms": 0,
            "sources": doc_count + review_count,
            "documents": doc_count,
            "accepted": accepted,
            "review": review_count,
            "rejected": len(errors),
            "created_at": manifest.get("created_at", ""),
        })

    # Build sources and documents from checkpoints
    seen_docs: set[str] = set()
    for run_id, ckpt in sorted(checkpoints_by_run.items()):

        # Sources from fetched items
        for f in ckpt.get("fetched", []):
            url = f.get("final_url") or f.get("requested_url", "")
            if not url or url in seen_docs:
                continue
            source_id = _source_id(url)
            if any(s["id"] == source_id for s in sources):
                continue
            content_type = f.get("content_type", "")
            sources.append(_build_source(url, content_type, f.get("status_code", 200), f.get("retrieved_at", "")))

        # Documents from extracted items
        for d in ckpt.get("documents", []):
            url = d.get("source_url", d.get("canonical_url", ""))
            if not url:
                continue
            doc_id = _source_id(url)
            if doc_id in seen_docs:
                continue
            seen_docs.add(doc_id)
            ident = d.get("identity", {})
            raw_text = d.get("raw_text", "")

            # Build IR for the document tree
            ir = build_ir_from_text(doc_id, url, raw_text)
            tree = [_node_to_dict(n) for n in ir.nodes]

            # Classify the source
            classification = classify_source_deterministic(url, ident.get("title"))

            # Resolve version
            version_res = resolve_version(doc_id, url, raw_text)
            versions = [{
                "version_id": f"{doc_id}:{version_res.temporal_state.value}",
                "temporal_state": version_res.temporal_state.value,
                "confidence": version_res.confidence,
                "reasons": version_res.reasons,
            }]

            # Build validation from the document's quality data if available
            validation = {
                "overall_status": "review",
                "sequence_similarity": 0.0,
                "section_coverage": 0.0,
                "numeric_fidelity": 1.0,
                "date_fidelity": 1.0,
                "modal_fidelity": 1.0,
                "negation_fidelity": 1.0,
                "issues": ["Document was extracted but not validated (agent step budget exhausted)"],
            }

            # Check if this doc was in outputs (validated)
            for out in ckpt.get("outputs", []):
                if out.get("canonical_url") == d.get("canonical_url"):
                    v = out.get("validation", {})
                    validation = {
                        "overall_status": v.get("status", "review"),
                        "sequence_similarity": v.get("score", 0),
                        "section_coverage": v.get("source_fidelity_score", 0),
                        "numeric_fidelity": 1.0,
                        "date_fidelity": 1.0,
                        "modal_fidelity": 1.0,
                        "negation_fidelity": 1.0,
                        "issues": v.get("issues", []),
                    }
                    break

            documents.append({
                "id": doc_id,
                "title": ident.get("title", url),
                "publisher": ident.get("publisher", "Unknown"),
                "source_url": url,
                "source_role": classification.source_role.value,
                "format": d.get("source_format", "html"),
                "chars": len(raw_text),
                "ir_sha256": ir.ir_sha256()[:16] + "...",
                "raw_sha256": d.get("raw_sha256", "")[:16] + "...",
                "tree": tree,
                "validation": validation,
                "versions": versions,
                "text": raw_text[:200_000],
            })

    # Build graph from documents
    for doc in documents:
        graph_nodes[doc["id"]] = {
            "label": doc["title"],
            "type": doc["source_role"],
            "authority": doc.get("publisher", "").lower(),
        }

    # Build review items from errors
    for run in runs:
        run_id = run["run_id"]
        manifest = manifests_by_run.get(run_id)
        if not manifest:
            continue
        for r in manifest.get("review", []):
            review.append({
                "id": f"review-{len(review)+1:03d}",
                "severity": "high" if "error" in str(r.get("issues", "")).lower() else "medium",
                "document": r.get("source_url", ""),
                "document_title": r.get("identity", {}).get("title", r.get("source_url", "")),
                "reason": ", ".join(r.get("issues", [])) or r.get("stage", "review"),
                "evidence": json.dumps(r, default=str)[:500],
                "recommended_action": "Inspect and retry validation",
            })

    if not runs:
        return None

    return {
        "runs": runs,
        "events": events,
        "sources": sources,
        "documents": documents,
        "graph": {"nodes": graph_nodes, "edges": graph_edges},
        "review": review,
    }
