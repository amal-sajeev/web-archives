import logging
import threading
import time
from contextlib import contextmanager
from typing import Callable

from runtime.human_logger import human_logger

logger = logging.getLogger("regulatory_rag_agent")

Subscriber = Callable[[dict], None]

_subscribers: list[Subscriber] = []
_sub_lock = threading.Lock()


def configure_logging():
    if not logger.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(h)
        logger.setLevel(logging.INFO)
    
    # Suppress verbose debug logs from external libraries
    logging.getLogger("google.api_core").setLevel(logging.WARNING)
    logging.getLogger("google.auth").setLevel(logging.WARNING)
    logging.getLogger("google.cloud").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("transformers").setLevel(logging.ERROR)
    logging.getLogger("langgraph").setLevel(logging.WARNING)
    logging.getLogger("langchain").setLevel(logging.WARNING)


def subscribe(fn: Subscriber) -> None:
    with _sub_lock:
        if fn not in _subscribers:
            _subscribers.append(fn)


def unsubscribe(fn: Subscriber) -> None:
    with _sub_lock:
        if fn in _subscribers:
            _subscribers.remove(fn)


def event(name: str, **fields):
    payload = {"event": name, "ts": time.time(), **fields}
    human_logger.log(payload)
    with _sub_lock:
        listeners = list(_subscribers)
    for fn in listeners:
        try:
            fn(payload)
        except (ValueError, TypeError, RuntimeError, OSError):
            logger.exception("event subscriber failed")


@contextmanager
def timed(name: str, **fields):
    started = time.perf_counter()
    try:
        yield
    finally:
        event(name, duration_ms=round((time.perf_counter() - started) * 1000, 1), **fields)
