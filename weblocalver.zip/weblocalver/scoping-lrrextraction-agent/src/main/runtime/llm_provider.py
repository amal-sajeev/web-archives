import os
from typing import Any

import google.auth
from config.settings import Settings


def build_llm(settings: Settings, reasoning: bool = False) -> Any:
    """Create the configured chat model for Gemini/Vertex AI."""
    return _build_gemini(settings, reasoning)


def _build_gemini(settings: Settings, reasoning: bool) -> Any:
    from langchain_google_genai import ChatGoogleGenerativeAI

    settings.require_llm_config()
    _apply_network_env(settings)
    if settings.google_application_credentials:
        os.environ.setdefault(
            "GOOGLE_APPLICATION_CREDENTIALS",
            settings.google_application_credentials,
        )
    try:
        google.auth.default()
    except Exception as exc:
        raise RuntimeError(
            "No Application Default Credentials available for Vertex AI. "
            "Locally, run: gcloud auth application-default login. "
            "For WIF, set GOOGLE_APPLICATION_CREDENTIALS to your external_account "
            f"credential config file. ({exc})"
        ) from exc
    model_name = settings.gemini_reasoning_model if reasoning else settings.gemini_model

    # Pass all parameters directly to the constructor to avoid warnings
    return ChatGoogleGenerativeAI(
        model=model_name,
        project=settings.google_cloud_project,
        location=settings.google_cloud_location,
        vertexai=settings.google_genai_use_vertexai,
        temperature=settings.temperature,
        top_p=settings.top_p,
        top_k=settings.top_k,
        seed=settings.generation_seed,
        max_retries=settings.max_retries,
    )


def _apply_network_env(settings: Settings) -> None:
    if settings.https_proxy:
        os.environ["HTTPS_PROXY"] = settings.https_proxy
        os.environ["https_proxy"] = settings.https_proxy
    if settings.http_proxy:
        os.environ["HTTP_PROXY"] = settings.http_proxy
        os.environ["http_proxy"] = settings.http_proxy
    if settings.no_proxy:
        os.environ["NO_PROXY"] = settings.no_proxy
        os.environ["no_proxy"] = settings.no_proxy
    if settings.ssl_cert_file:
        os.environ["SSL_CERT_FILE"] = settings.ssl_cert_file
    if settings.requests_ca_bundle:
        os.environ["REQUESTS_CA_BUNDLE"] = settings.requests_ca_bundle
