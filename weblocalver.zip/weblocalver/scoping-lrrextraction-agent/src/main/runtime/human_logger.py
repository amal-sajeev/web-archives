import json
from config.settings import Settings

class HumanLogger:
    def __init__(self):
        self._settings: Settings | None = None  # Initialize as None

    @property
    def settings(self) -> Settings:
        """Lazily load the Settings object on first access."""
        if self._settings is None:
            self._settings = Settings()
        return self._settings

    def log(self, payload: dict):
        if self.settings.log_style == "human":
            self._log_human(payload)
        else:
            self._log_json(payload)

    def _log_json(self, payload: dict):
        print(json.dumps(payload, ensure_ascii=False, default=str))

    def _summarize_outputs(self, outputs: list[dict]) -> str:
        if not outputs:
            return "0"
        
        summary = [f"{len(outputs)} document(s):"]
        for i, doc in enumerate(outputs, 1):
            ident = doc.get("identity", {})
            title = ident.get("title", "No Title")
            url = doc.get("source_url", "No URL")
            raw_text = doc.get("raw_text", "")
            truncated_text = (raw_text[:150] + '...') if len(raw_text) > 150 else raw_text
            preview_text = truncated_text.replace('\n', ' ').replace('\r', ' ')
            summary.append(
                f"    {i}. {title}\n"
                f"       URL: {url}\n"
                f"       Text Preview: {preview_text}"
            )
        return "\n".join(summary)

    def _log_human(self, payload: dict):
        event_name = payload.get("event")
        message = self._format_human(event_name, payload)
        if message:
            print(message)

    def _get_output_path(self, payload: dict) -> str:
        request_id = payload.get("request_id")
        if request_id and self.settings.gcs_bucket:
            return f"gs://{self.settings.gcs_bucket}/{self.settings.gcs_prefix}_{request_id}/processing-data/llr-extracted"
        return payload.get("output_dir") or str(self.settings.output_dir)

    def _format_human(self, event_name: str, payload: dict) -> str | None:
        # --- Dedicated handler for Phase 2/3 generic logs ---
        if event_name == "phase_log":
            return payload.get("message")

        # --- Handlers for Phase 1 (Agent Run) ---
        if event_name == "run_started":
            output_path = self._get_output_path(payload)
            return (
                f"\nPHASE 1: REGULATORY CRAWLING & INGESTION START \n"
                f"Agent Run Started\n"
                f"  Run ID: {payload.get('run_id')}\n"
                f"  Objective: {payload.get('objective')}\n"
                f"  Output Path: {output_path}"
            )
        if event_name == "plan":
            return "\nStep: Planning - The agent is creating a plan to achieve its goal."

        if event_name == "agent_action":
            step = payload.get("step")
            action = payload.get("action")
            target = payload.get("target")
            return f"Step {step}: {action.capitalize()} - The agent is performing the action '{action}' on target: {target}"
        
        if event_name == "agent_action_failed":
            step = payload.get("step")
            action = payload.get("action")
            target = payload.get("target")
            error = payload.get("error")
            return f"Step {step}: {action.capitalize()} Failed - The agent failed to perform the action '{action}' on target: {target}. Reason: {error}"

        if event_name == "run_complete":
            output_path = self._get_output_path(payload)
            total_steps = payload.get("step", 0)
            outputs = payload.get("outputs", [])
            return (
                f"\nAgent Run COMPLETE\n"
                f"  Run ID: {payload.get('run_id')}\n"
                f"  Total Steps: {total_steps}\n"
                f"  Accepted Documents: {self._summarize_outputs(outputs)}\n"
                f"  Output Path: {output_path}\n"
                f"PHASE 1: REGULATORY CRAWLING & INGESTION END"
            )
        if event_name == "run_error":
            return (
                f"\nAgent Run FAILED\n"
                f"  Run ID: {payload.get('run_id')}\n"
                f"  Error: {payload.get('error')}"
            )
            
        return None 

human_logger = HumanLogger()
