import logging
import queue
import threading
import traceback
from datetime import datetime, timezone
from typing import Any

from live.data import invalidate_live_data
from config.settings import Settings
from runtime.observability import configure_logging, event, subscribe, unsubscribe
from risk_context.rt_resolution import execute_phase_2
from risk_context.phase_3_mandate_generation import execute_phase_3
from risk_context.phase_4_validation_evaluation import execute_phase_4
from graph import build_graph, load_checkpoint

logger = logging.getLogger("scoping_lrrextraction_agent")


class LiveRun:
    def __init__(self, run_id: str, seeds: list[str], objective: str):
        self.run_id = run_id
        self.seeds = seeds
        self.objective = objective
        self.status = "queued"
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.finished_at: str | None = None
        self.error: str | None = None
        self.step = 0
        self.history: list[dict] = []
        self.result: dict[str, Any] = {}
        self._queues: list[queue.Queue] = []
        self._lock = threading.Lock()

    def attach(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=500)
        with self._lock:
            self._queues.append(q)
            for item in self.history:
                try:
                    q.put_nowait(item)
                except queue.Full:
                    break
        return q

    def detach(self, q: queue.Queue) -> None:
        with self._lock:
            if q in self._queues:
                self._queues.remove(q)

    def publish(self, payload: dict) -> None:
        with self._lock:
            self.history.append(payload)
            self.history = self.history[-400:]
            targets = list(self._queues)
        for q in targets:
            try:
                q.put_nowait(payload)
            except queue.Full:
                pass

    def snapshot(self) -> dict:
        return {
            "run_id": self.run_id,
            "seeds": self.seeds,
            "objective": self.objective,
            "status": self.status,
            "created_at": self.created_at,
            "finished_at": self.finished_at,
            "error": self.error,
            "step": self.step,
            "events": list(self.history),
            "result": self.result,
        }


class RunManager:
    def __init__(self):
        self._runs: dict[str, LiveRun] = {}
        self._lock = threading.Lock()

    def get(self, run_id: str) -> LiveRun | None:
        with self._lock:
            return self._runs.get(run_id)

    def list_active(self) -> list[dict]:
        with self._lock:
            return [r.snapshot() for r in self._runs.values()]

    def start(self, seeds: list[str], objective: str | None = None, resume: str | None = None, request_id: str | None = None) -> LiveRun:
        configure_logging()
        # Prioritize resume, then request_id, then a new timestamp
        run_id = resume or request_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        obj = objective or (
            "Acquire authoritative regulatory instruments relevant to the supplied seeds "
            "and preserve their source text exactly."
        )
        live = LiveRun(run_id, seeds, obj)
        with self._lock:
            self._runs[run_id] = live
        thread = threading.Thread(target=self._execute, args=(live, resume, request_id), daemon=True)
        thread.start()
        return live

    def _execute(self, live: LiveRun, resume: str | None, request_id: str | None) -> None:
        run_id = live.run_id
        settings = Settings()
        logger.info("Background LRR run execution started: run_id=%s request_id=%s seeds=%s", run_id, request_id, live.seeds)

        def _state_summary(state: dict | None = None) -> dict[str, int | str | None]:
            current = state or {}
            errors = current.get("errors", []) if isinstance(current, dict) else []
            return {
                "step": int(current.get("step", live.step)) if isinstance(current, dict) else live.step,
                "errors": len(errors),
                "frontier": len(current.get("frontier", [])) if isinstance(current, dict) else 0,
                "candidates": len(current.get("candidates", [])) if isinstance(current, dict) else 0,
                "fetched": len(current.get("fetched", [])) if isinstance(current, dict) else 0,
                "documents": len(current.get("documents", [])) if isinstance(current, dict) else 0,
                "outputs": len(current.get("outputs", [])) if isinstance(current, dict) else 0,
                "last_error": errors[-1] if errors else None,
            }

        def on_event(payload: dict):
            enriched = {**payload, "run_id": payload.get("run_id") or run_id}
            if enriched.get("event") == "agent_action":
                live.step = int(enriched.get("step") or live.step)
            if enriched.get("event") == "agent_action_failed" and enriched.get("error"):
                live.error = str(enriched.get("error"))
            live.publish(enriched)

        subscribe(on_event)
        live.status = "running"
        event(
            "run_started",
            run_id=run_id,
            request_id=request_id,
            seeds=live.seeds,
            objective=live.objective,
        )
        try:
            graph = build_graph()
            if resume:
                initial = load_checkpoint(resume)
            else:
                initial = {"seeds": live.seeds, "objective": live.objective, "run_id": run_id, "request_id": request_id}

            final_state: dict = {}
            for item in graph.stream(initial, stream_mode="updates"):
                if not isinstance(item, dict):
                    continue
                for node_name, update in item.items():
                    upd = update if isinstance(update, dict) else {}
                    if upd.get("run_id"):
                        pass
                    if "step" in upd:
                        live.step = int(upd["step"] or live.step)
                    if "history" in upd and isinstance(upd["history"], list) and upd["history"]:
                        last = upd["history"][-1]
                        live.publish({
                            "event": "agent_step",
                            "run_id": run_id,
                            "node": node_name,
                            "step": last.get("step", live.step),
                            "action": last.get("action"),
                            "target": last.get("target"),
                            "reason": last.get("reason"),
                            "details": last.get("reason"),
                        })
                    else:
                        live.publish({
                            "event": "node_end",
                            "run_id": run_id,
                            "node": node_name,
                            "step": live.step,
                            "keys": sorted(upd.keys()),
                        })
                    final_state.update(upd)
                    live.publish({
                        "event": "run_progress",
                        "run_id": run_id,
                        "node": node_name,
                        **_state_summary(final_state),
                    })

            live.result = {
                "run_id": final_state.get("run_id", run_id),
                "outputs": final_state.get("outputs", []),
                "completion": final_state.get("completion"),
                "errors": final_state.get("errors", []),
                "step": final_state.get("step", live.step),
            }
            live.status = "completed"
            live.finished_at = datetime.now(timezone.utc).isoformat()
            logger.info("Background LRR run completed: run_id=%s status=%s outputs=%s", run_id, live.status, len(live.result.get("outputs", [])))
            live.publish({"event": "run_complete", "run_id": run_id, "result": live.result, "summary": _state_summary(final_state)})

            # --- Downstream Phases Start Here ---
            if request_id:
                execute_phase_2(request_id=request_id)
                execute_phase_3(request_id=request_id)
                execute_phase_4(request_id=request_id)

        except Exception as exc:
            live.status = "failed"
            live.error = str(exc)
            live.finished_at = datetime.now(timezone.utc).isoformat()
            logger.exception("Background LRR run failed: run_id=%s request_id=%s", run_id, request_id)
            live.publish({
                "event": "run_error",
                "run_id": run_id,
                "error": str(exc),
                "error_type": type(exc).__name__,
                "traceback": traceback.format_exc()[-2000:],
                "step": live.step,
                "summary": _state_summary(final_state if "final_state" in locals() else None),
            })
            event(
                "run_error",
                run_id=run_id,
                error=str(exc),
                error_type=type(exc).__name__,
                step=live.step,
                output_dir=str(settings.output_dir),
                **_state_summary(final_state if "final_state" in locals() else None),
            )
        finally:
            unsubscribe(on_event)
            invalidate_live_data()


RUN_MANAGER = RunManager()
