import json
from pathlib import Path

_PROMPTS_DIR = Path(__file__).resolve().parents[1] / "prompts"


def _load_workflow_prompts() -> dict:
    path = _PROMPTS_DIR / "acquisition_workflow.json"
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


_WORKFLOW = _load_workflow_prompts()

PLANNER = _WORKFLOW["planner"]["prompt"]
CLASSIFIER = _WORKFLOW["source_classifier"]["prompt"]
QA = _WORKFLOW["quality_review"]["prompt"]
AGENT = _WORKFLOW["agent_decision"]["prompt"]
SELECTOR = _WORKFLOW["selector"]["prompt"]
