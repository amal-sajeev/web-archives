import os

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from helpers.paths import get_ui_dir
from routes import data_router, lrr_router, page_router, query_router, run_router
from runtime.observability import configure_logging

configure_logging()

APP_TITLE = "LRR Extraction API"
APP_VERSION = "0.0.1"
DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 8877

_UI_DIR = get_ui_dir()


def create_app() -> FastAPI:
    app = FastAPI(
        title=APP_TITLE,
        version=APP_VERSION,
        root_path="/scoping-lrrextraction-agent",
        servers=[{"url": "/scoping-lrrextraction-agent"}],
        openapi_tags=[
            {"name": "UI", "description": "HTML UI pages served by the app."},
            {"name": "Run Lifecycle", "description": "Start runs, inspect status, and stream live progress."},
            {"name": "LRR Processing", "description": "Process LRR requests and monitor run progress."},
            {"name": "Data", "description": "Sources, documents, graph, and review data."},
            {"name": "Query & Cache", "description": "Query execution and cache refresh operations."},
        ],
    )
    app.include_router(page_router)
    app.include_router(run_router)
    app.include_router(lrr_router)
    app.include_router(data_router)
    app.include_router(query_router)
    if _UI_DIR.exists():
        app.mount(
            "/lrr/ui/assets",
            StaticFiles(directory=str(_UI_DIR / "assets")),
            name="assets",
        )
    return app


app = create_app()


def run_server(port: int = 8765) -> None:
    uvicorn.run(app, host=DEFAULT_HOST, port=port, log_level="info")


def main() -> None:
    port = int(os.getenv("PORT", os.getenv("REG_RAG_PORT", str(DEFAULT_PORT))))
    run_server(port=port)


if __name__ == "__main__":
    main()


__all__ = [
    "APP_TITLE",
    "APP_VERSION",
    "DEFAULT_HOST",
    "DEFAULT_PORT",
    "app",
    "create_app",
    "main",
    "run_server",
]
