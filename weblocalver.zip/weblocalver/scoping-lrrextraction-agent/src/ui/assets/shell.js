function iconFor(key) {
  const icons = {
    overview:'▦', runs:'◷', sources:'⌕', documents:'▤', validation:'✓',
    graph:'◇', review:'!', query:'?', versions:'↺'
  };
  return icons[key] || '·';
}

function renderSidebar(active) {
  const links = [
    ['Overview', '/lrr/ui/index.html', 'overview', '01'],
    ['Live Runs', '/lrr/ui/run.html', 'runs', '02'],
    ['Sources', '/lrr/ui/sources.html', 'sources', '03'],
    ['Documents', '/lrr/ui/document.html', 'documents', '04'],
    ['Validation', '/lrr/ui/validation.html', 'validation', '05'],
    ['Graph', '/lrr/ui/graph.html', 'graph', '06'],
    ['Review Queue', '/lrr/ui/review.html', 'review', '07'],
    ['Retrieve', '/lrr/ui/query.html', 'query', '08'],
    ['Versions', '/lrr/ui/versions.html', 'versions', '09'],
  ];
  return `<aside class="sidebar">
    <div class="brand">
      <div class="brand-mark">RSI</div>
      <div class="brand-text"><strong>Regulatory Source Intelligence</strong><span>Acquisition &amp; Evidence</span></div>
    </div>
    <nav>${links.map(([label, href, key, ico]) =>
      `<a href="${href}" class="${active === key ? 'active' : ''}" title="${label}"><span class="nav-ico">${iconFor(key)}</span><span>${label}</span></a>`
    ).join('')}</nav>
  </aside>`;
}

function pageLabel(active) {
  const labels = {overview:'Overview', runs:'Live Runs', sources:'Sources', documents:'Documents', validation:'Validation', graph:'Graph', review:'Review Queue', query:'Retrieve', versions:'Versions'};
  return labels[active] || 'Workspace';
}

function decorateShell(active) {
  const oldBadge = document.querySelector('body > .mode-badge:not(.shell-topbar .mode-badge)');
  if (oldBadge) oldBadge.remove();
  if (!document.querySelector('.shell-topbar')) {
    const top = document.createElement('header');
    top.className = 'shell-topbar';
    top.innerHTML = `<div class="crumbs"><span>RSI</span><span class="crumb-sep">/</span><span class="current">${pageLabel(active)}</span></div>
      <div class="topbar-right"><div class="system-state"><span class="dot"></span>API connected</div><div id="mode-badge" class="mode-badge demo">DEMO MODE</div></div>`;
    document.body.appendChild(top);
  }
}

function ensureShell(active) {
  const old = document.querySelector('.sidebar');
  if (old) old.outerHTML = renderSidebar(active);
  decorateShell(active);
}

function renderModeBadge() {
  return `<div class="mode-badge demo" id="mode-badge">DEMO MODE</div>`;
}

async function updateModeBadge() {
  const data = await fetchJSONSoft('/lrr/system/mode'); 
  if (data && data.mode) {
    const el = document.getElementById('mode-badge');
    if (el) {
      el.textContent = data.mode === 'live' ? 'LIVE CORPUS' : 'DEMO MODE';
      el.className = 'mode-badge ' + data.mode;
    }
  }
}
