const API = '/scoping-lrrextraction-agent';

async function fetchJSON(path, options) {
  try {
    const res = await fetch(API + path, options);
    if (!res.ok) {
      let detail = `HTTP ${res.status}`;
      try {
        const body = await res.json();
        detail = body.detail || JSON.stringify(body);
      } catch (_) {
        detail = `HTTP ${res.status}`;
      }
      const err = new Error(detail);
      if (options && options.throwOnError) throw err;
      console.error('API error:', err);
      return null;
    }
    return await res.json();
  } catch (e) {
    console.error('API error:', e);
    if (options && options.throwOnError) throw e;
    return null;
  }
}

async function fetchJSONSoft(path) {
  return fetchJSON(path);
}

async function fetchJSONStrict(path, options = {}) {
  return fetchJSON(path, { ...options, throwOnError: true });
}

function badge(text, cls) {
  const c = cls || String(text || '').toLowerCase().replace(/\s+/g, '_');
  return `<span class="badge ${c}">${escapeHtml(text)}</span>`;
}

function escapeHtml(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}
