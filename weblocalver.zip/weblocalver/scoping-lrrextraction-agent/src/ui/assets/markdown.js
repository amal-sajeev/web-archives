


// Lightweight, dependency-free Markdown renderer for acquired regulatory documents.
// Raw HTML is escaped so document text cannot inject UI markup or scripts.
function renderMarkdown(markdown) {
  const src = String(markdown ?? '').replace(/\r\n?/g, '\n');
  const lines = src.split('\n');
  const out = [];
  let i = 0;
  let paragraph = [];
  let listType = null;
  let inCode = false;
  let code = [];
  let codeLang = '';

  const flushParagraph = () => {
    if (!paragraph.length) return;
    const text = paragraph.join(' ').trim();
    if (text) out.push(`<p>${inlineMarkdown(text)}</p>`);
    paragraph = [];
  };
  const closeList = () => {
    if (listType) { out.push(`</${listType}>`); listType = null; }
  };
  const openList = (type) => {
    if (listType === type) return;
    closeList();
    listType = type;
    out.push(`<${type}>`);
  };
  const isTableSeparator = (line) => /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(line);
  const splitTable = (line) => {
    let x = line.trim();
    if (x.startsWith('|')) x = x.slice(1);
    if (x.endsWith('|')) x = x.slice(0, -1);
    return x.split('|').map(v => v.trim());
  };

  while (i < lines.length) {
    const line = lines[i];
    if (inCode) {
      if (/^\s*```/.test(line)) {
        out.push(`<pre><code class="language-${escapeHtml(codeLang)}">${escapeHtml(code.join('\n'))}</code></pre>`);
        inCode = false; code = []; codeLang = '';
      } else code.push(line);
      i++; continue;
    }
    const fence = line.match(/^\s*```\s*([\w+-]*)\s*$/);
    if (fence) { flushParagraph(); closeList(); inCode = true; codeLang = fence[1] || ''; i++; continue; }
    if (!line.trim()) { flushParagraph(); closeList(); i++; continue; }

    // Markdown tables.
    if (i + 1 < lines.length && line.includes('|') && isTableSeparator(lines[i + 1])) {
      flushParagraph(); closeList();
      const headers = splitTable(line);
      i += 2;
      let html = '<div class="md-table-wrap"><table class="md-table"><thead><tr>';
      headers.forEach(h => { html += `<th>${inlineMarkdown(h)}</th>`; });
      html += '</tr></thead><tbody>';
      while (i < lines.length && lines[i].trim() && lines[i].includes('|')) {
        const cells = splitTable(lines[i]);
        html += '<tr>';
        headers.forEach((_, idx) => { html += `<td>${inlineMarkdown(cells[idx] ?? '')}</td>`; });
        html += '</tr>'; i++;
      }
      html += '</tbody></table></div>';
      out.push(html); continue;
    }

    let m = line.match(/^\s*(#{1,6})\s+(.+?)\s*#*\s*$/);
    if (m) { flushParagraph(); closeList(); const level=m[1].length; out.push(`<h${level}>${inlineMarkdown(m[2])}</h${level}>`); i++; continue; }
    if (/^\s*(---+|\*\*\*+)\s*$/.test(line)) { flushParagraph(); closeList(); out.push('<hr>'); i++; continue; }
    m = line.match(/^\s*>\s?(.*)$/);
    if (m) { flushParagraph(); closeList(); out.push(`<blockquote>${inlineMarkdown(m[1])}</blockquote>`); i++; continue; }
    m = line.match(/^\s*[-*+]\s+(.+)$/);
    if (m) { flushParagraph(); openList('ul'); out.push(`<li>${inlineMarkdown(m[1])}</li>`); i++; continue; }
    m = line.match(/^\s*\d+[.)]\s+(.+)$/);
    if (m) { flushParagraph(); openList('ol'); out.push(`<li>${inlineMarkdown(m[1])}</li>`); i++; continue; }
    paragraph.push(line.trim()); i++;
  }
  flushParagraph(); closeList();
  return out.join('') || '<p class="md-empty">No extracted text.</p>';
}

function inlineMarkdown(value) {
  let s = escapeHtml(value);
  const stash = [];
  const hold = (html) => { const token = `\u0000${stash.length}\u0000`; stash.push(html); return token; };
  s = s.replace(/`([^`]+)`/g, (_, x) => hold(`<code>${x}</code>`));
  s = s.replace(/!\[([^\]]*)\]\(([^\s)]+)(?:\s+["']([^"']*)["'])?\)/g, (_, alt, url, title) => {
    if (!/^https?:\/\//i.test(url)) return alt;
    return hold(`<img src="${url}" alt="${alt}"${title ? ` title="${title}"` : ''} loading="lazy">`);
  });
  s = s.replace(/\[([^\]]+)\]\(([^\s)]+)(?:\s+["']([^"']*)["'])?\)/g, (_, label, url, title) => {
    if (!/^(https?:\/\/|mailto:)/i.test(url)) return label;
    return hold(`<a href="${url}" target="_blank" rel="noopener noreferrer"${title ? ` title="${title}"` : ''}>${label}</a>`);
  });
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/__([^_]+)__/g, '<strong>$1</strong>');
  s = s.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  s = s.replace(/_([^_]+)_/g, '<em>$1</em>');
  s = s.replace(/~~([^~]+)~~/g, '<del>$1</del>');
  s = s.replace(/  \n/g, '<br>');
  return s.replace(/\u0000(\d+)\u0000/g, (_, n) => stash[Number(n)]);
}

