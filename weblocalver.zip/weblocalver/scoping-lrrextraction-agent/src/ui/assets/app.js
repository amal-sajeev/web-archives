async function startAcquisition(body) {
  const res = await fetch('/lrr/system/runs', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const error = await res.text();
    throw new Error(error || `HTTP ${res.status}`);
  }
  return await res.json();
}

async function getCorpusStats() {
  return await fetchJSONSoft('/lrr/system/runs');
}
