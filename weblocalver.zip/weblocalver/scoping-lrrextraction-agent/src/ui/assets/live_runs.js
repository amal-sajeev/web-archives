function formatClock(ts) {
  const d = ts ? new Date(ts * 1000) : new Date();
  return d.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function appendConsoleLine(el, evt) {
  if (!el) return;
  const type = evt.event || evt.action || 'event';
  if (type === 'heartbeat') return;
  const line = document.createElement('div');
  const isErr = type === 'run_error' || evt.status === 'error' || !!evt.error;
  line.className = 'line' + (isErr ? ' error' : '');
  const msg = evt.reason || evt.details || evt.error || evt.target || evt.node || JSON.stringify(evt);
  const action = (evt.action || type || '').toString().toUpperCase();
  line.innerHTML = `<span class="ts">${formatClock(evt.ts)}</span><span class="tag">${escapeHtml(action)}</span><span class="msg">${escapeHtml(msg)}</span>`;
  el.appendChild(line);
  el.scrollTop = el.scrollHeight;
}

function appendTimelineEntry(el, evt, live) {
  if (!el) return;
  if ((evt.event || '') === 'heartbeat') return;
  const action = (evt.action || evt.event || evt.node || 'event').toString();
  const target = evt.target ? ` → ${evt.target}` : '';
  const details = evt.reason || evt.details || evt.error || '';
  const div = document.createElement('div');
  const isErr = action === 'run_error' || !!evt.error;
  div.className = 'entry' + (isErr ? ' is-error' : '') + (live ? ' is-live' : '');
  div.innerHTML = `
    <div class="step-num">${evt.step != null ? 'STEP ' + evt.step : 'EVENT'}</div>
    <div class="action">${escapeHtml(action.toUpperCase())}${escapeHtml(target)}</div>
    <div class="details">${escapeHtml(details)}</div>`;
  el.appendChild(div);
  el.scrollTop = el.scrollHeight;
}

class LiveRunClient {
  constructor({ runId, onEvent, onStatus }) {
    this.runId = runId;
    this.onEvent = onEvent;
    this.onStatus = onStatus;
    this.es = null;
    this.closed = false;
  }

  start() {
    this.closed = false;
    if (this.es) this.es.close();
    this.es = new EventSource(`/api/runs/${encodeURIComponent(this.runId)}/live`);
    this.es.onmessage = (msg) => {
      let data;
      try { data = JSON.parse(msg.data); } catch { return; }
      if (this.onEvent) this.onEvent(data);
      if (data.event === 'run_complete') {
        this.stop();
        if (this.onStatus) this.onStatus('completed');
      }
      if (data.event === 'run_error') {
        this.stop();
        if (this.onStatus) this.onStatus('failed');
      }
      if (data.event === 'run_started' && this.onStatus) this.onStatus('running');
    };
    this.es.onerror = async () => {
      if (this.closed) return;
      const run = await fetchJSONSoft(`/api/runs/${encodeURIComponent(this.runId)}`);
      if (!run || !run.live || run.status === 'completed' || run.status === 'failed' || run.status === 'incomplete') {
        this.stop();
        if (this.onStatus) this.onStatus((run && run.status) || 'completed');
        return;
      }
      if (this.onStatus) this.onStatus('reconnecting');
    };
  }

  stop() {
    this.closed = true;
    if (this.es) this.es.close();
    this.es = null;
  }
}

async function startAcquisition({ urls }) {
  return fetchJSONStrict('/api/runs', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ urls }),
  });
}

async function runRetrieval(query, topK = 6) {
  return fetchJSONStrict('/api/query', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, top_k: topK }),
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;
  if (page) ensureShell(page);
  updateModeBadge();
});
