"""Tests for the retrieval answer generation."""

import pytest
from unittest.mock import patch, MagicMock

from main.retrieval.answer import (
    _extractive_answer,
    _llm_answer,
    answer_query,
)

def test_extractive_answer_with_hits():
    """Verify that the extractive answer correctly formats a response when hits are found."""
    hits = [
        {
            "title": "Test Document 1",
            "source_url": "http://example.com/1",
            "excerpt": "This is the most relevant excerpt."
        }
    ]
    answer = _extractive_answer("What is the rule?", hits)
    assert "Based on acquired source text" in answer
    assert "Test Document 1" in answer
    assert "This is the most relevant excerpt" in answer

def test_extractive_answer_with_no_hits():
    """Verify the fallback message when no relevant passages are found."""
    answer = _extractive_answer("What is the rule?", [])
    assert "No grounded passages were found" in answer

@patch("main.retrieval.answer.llm")
def test_llm_answer_success(mock_llm, test_settings):
    """Verify that a successful LLM call returns a synthesized answer."""
    # Arrange
    mock_llm_instance = MagicMock()
    mock_llm_instance.invoke.return_value = "This is a synthesized answer from the LLM."
    mock_llm.return_value = mock_llm_instance
    
    hits = [{"title": "Doc 1", "source_url": "http://a.com", "text": "Some text."}]
    
    with patch("main.retrieval.answer.Settings", return_value=test_settings):
        answer = _llm_answer("What is the rule?", hits)

    # Assert
    assert answer == "This is a synthesized answer from the LLM."
    mock_llm_instance.invoke.assert_called_once()
    # Check that the prompt contains the key components
    prompt_arg = mock_llm_instance.invoke.call_args[0][0]
    assert "QUESTION:" in prompt_arg
    assert "PASSAGES:" in prompt_arg
    assert "Some text." in prompt_arg

@patch("main.retrieval.answer.llm")
def test_llm_answer_handles_llm_failure(mock_llm, test_settings):
    """Verify that if the LLM call fails, the function returns None."""
    mock_llm_instance = MagicMock()
    mock_llm_instance.invoke.side_effect = RuntimeError("LLM is down")
    mock_llm.return_value = mock_llm_instance

    hits = [{"title": "Doc 1", "source_url": "http://a.com", "text": "Some text."}]

    with patch("main.retrieval.answer.Settings", return_value=test_settings):
        answer = _llm_answer("What is the rule?", hits)

    assert answer is None

@patch("main.retrieval.answer._llm_answer")
@patch("main.retrieval.answer.retrieve")
@patch("main.retrieval.answer._load_documents")
def test_answer_query_uses_llm_when_available(mock_load_docs, mock_retrieve, mock_llm_answer):
    """Test that answer_query prefers the LLM answer when it succeeds."""
    mock_retrieve.return_value = [{"title": "Hit 1"}]
    mock_llm_answer.return_value = "Synthesized LLM Answer"
    mock_load_docs.return_value = ["doc1"]

    result = answer_query("test query")

    assert result["answer"] == "Synthesized LLM Answer"
    assert result["mode"] == "llm_grounded"
    assert result["corpus_documents"] == 1

@patch("main.retrieval.answer._llm_answer")
@patch("main.retrieval.answer.retrieve")
@patch("main.retrieval.answer._load_documents")
def test_answer_query_falls_back_to_extractive(mock_load_docs, mock_retrieve, mock_llm_answer):
    """Test that answer_query falls back to an extractive answer when the LLM fails."""
    mock_retrieve.return_value = [{"title": "Hit 1", "excerpt": "Extractive excerpt."}]
    mock_llm_answer.return_value = None  # Simulate LLM failure
    mock_load_docs.return_value = ["doc1"]

    result = answer_query("test query")

    assert "Extractive excerpt" in result["answer"]
    assert result["mode"] == "extractive"
