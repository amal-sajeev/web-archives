"""Tests for retrieval module."""

from main.retrieval.retrieval import *


def test_retrieval_imports():
    """Test that retrieval module imports without error."""
    assert True
