"""Tests for the retrieval ranking and scoring logic."""

import pytest
from unittest.mock import patch

from main.retrieval.rank import (
    _tokenize,
    _chunk_text,
    _score,
    retrieve,
)

def test_tokenize():
    """Verify that tokenization correctly splits, lowercases, and removes stop words."""
    text = "This is a Test of the tokenizer."
    expected = ["test", "tokenizer"]
    assert _tokenize(text) == expected

def test_chunk_text():
    """Verify that text chunking splits text correctly and handles overlaps."""
    long_text = "a" * 1000
    chunks = _chunk_text(long_text, size=200, overlap=50)
    assert len(chunks) > 1
    assert len(chunks[0]) == 200
    # The second chunk should start inside the first one due to overlap
    assert long_text.find(chunks[1]) < 200

def test_score():
    """Verify the scoring logic for a query against a text chunk."""
    query = "customer complaints"
    query_tokens = _tokenize(query)
    
    # A chunk that is a perfect match should have a high score
    perfect_chunk = "This document details the handling of customer complaints."
    title = "Rule 123 - Complaint Handling"
    score1 = _score(query, query_tokens, perfect_chunk, title)
    assert score1 > 20

    # A chunk with no matching terms should have a zero score
    irrelevant_chunk = "This is about something else entirely."
    score2 = _score(query, query_tokens, irrelevant_chunk, "Irrelevant Title")
    assert score2 == 0.0

@patch("main.retrieval.rank._load_documents")
def test_retrieve_finds_and_ranks_documents(mock_load_docs):
    """Verify the end-to-end retrieve function."""
    # Arrange: Create mock documents
    doc1 = {
        "title": "Complaints Rule",
        "text": "This is the official rule on handling customer complaints.",
        "source_url": "http://a.com", "canonical_url": "http://a.com",
        "publisher": "REG"
    }
    doc2 = {
        "title": "Other Document",
        "text": "This document is about a different topic.",
        "source_url": "http://b.com", "canonical_url": "http://b.com",
        "publisher": "REG"
    }
    mock_load_docs.return_value = [doc1, doc2]

    # Act
    hits = retrieve("customer complaints")

    # Assert
    assert len(hits) > 0
    assert hits[0]["title"] == "Complaints Rule" # The more relevant doc should be first
    assert "customer complaints" in hits[0]["text"]

@patch("main.retrieval.rank._load_documents")
def test_retrieve_diversifies_results(mock_load_docs):
    """Verify that the retrieval results are diversified by source URL."""
    # Arrange: Create multiple chunks from the same document
    doc1 = {
        "title": "Big Document",
        "text": "customer complaints. " * 50, # Many chunks will match
        "source_url": "http://a.com", "canonical_url": "http://a.com",
        "publisher": "REG"
    }
    doc2 = {
        "title": "Slightly Less Relevant",
        "text": "A single mention of complaints.",
        "source_url": "http://b.com", "canonical_url": "http://b.com",
        "publisher": "REG"
    }
    mock_load_docs.return_value = [doc1, doc2]

    # Act
    hits = retrieve("customer complaints", top_k=5)

    # Assert: The top hits should not all be from the same document
    urls = {hit["canonical_url"] for hit in hits}
    assert "http://a.com" in urls
    assert "http://b.com" in urls
    # Check that the first hit is from the most relevant doc
    assert hits[0]["canonical_url"] == "http://a.com"
