"""Tests for the retrieval store."""

from main import retrieval
from main.retrieval import store as store_module


def test_load_documents_from_files(tmp_path, monkeypatch):
    """Test that documents are correctly loaded from markdown files."""
    corpus = tmp_path / "corpus"
    corpus.mkdir()
    doc = corpus / "doc1.md"
    doc.write_text("---\ntitle: Test Doc\npublisher: Test Pub\n---\n# Content", encoding="utf-8")
    monkeypatch.setattr(store_module, "_corpus_dir", lambda: corpus)

    documents = store_module._load_documents()
    assert len(documents) == 1
    assert documents[0]["title"] == "Test Doc"
