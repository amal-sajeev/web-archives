"""Tests for the command-line interface."""

from unittest.mock import patch, MagicMock
import pytest

from main import cli

@patch("main.cli.run_server")
def test_cli_serve_command(mock_run_server, monkeypatch):
    """Test that the 'serve' command calls the run_server function."""
    # Simulate passing 'serve' as a command-line argument
    monkeypatch.setattr("sys.argv", ["main", "serve"])
    cli.main()
    # Assert that run_server was called once
    mock_run_server.assert_called_once()

@patch("main.cli.build_graph")
def test_cli_ingest_command(mock_build_graph, monkeypatch):
    """Test that the 'ingest' command correctly invokes the graph."""
    # Create a mock graph that we can make assertions on
    mock_graph_instance = MagicMock()
    mock_build_graph.return_value = mock_graph_instance
    
    # Simulate passing 'ingest' with a URL
    monkeypatch.setattr("sys.argv", ["main", "ingest", "--url", "https://example.com/test"])
    
    cli.main()
    
    # Assert that the graph was built and then its invoke method was called
    mock_build_graph.assert_called_once()
    mock_graph_instance.invoke.assert_called_once()
    
    # Check that the correct initial state was passed to the graph
    invoke_args, _ = mock_graph_instance.invoke.call_args
    initial_state = invoke_args[0]
    assert initial_state["seeds"] == ["https://example.com/test"]
    assert "Acquire authoritative regulatory" in initial_state["objective"]
