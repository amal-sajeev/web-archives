"""Tests for main entry point."""

from main.__main__ import *


def test_main_imports():
    """Test that main module imports without error."""
    assert True
