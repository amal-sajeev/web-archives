"""Tests for the configuration and settings logic."""

from main.config.settings import Settings

# A complete dictionary of default settings to ensure the Settings object can be created.
BASE_TEST_SETTINGS = {
    "master_risk_definitions": "risktype_mapping/Risk_Type_V4.json",
    "manifest": "inbound-data/lrr/internet_search_data.json",
    "google_genai_use_vertexai": True,
    "gemini_model": "gemini-1.5-flash",
    "gemini_reasoning_model": "gemini-1.5-pro",
    "temperature": 0.0,
    "top_p": 0.95,
    "top_k": 40,
    "output_dir": "./corpus",
    "source_host_aliases": "",
    "source_allowlist": "*",
    "max_pages": 10,
    "max_bytes": 60000000,
    "max_discovery_depth": 1,
    "max_candidates_per_page": 100,
    "request_timeout_seconds": 90.0,
    "max_concurrent_fetches": 2,
    "max_retries": 3,
    "max_redirects": 5,
    "backoff_base_seconds": 1.0,
    "max_repair_attempts": 2,
    "max_agent_steps": 40,
    "checkpoint_every_step": True,
    "min_extracted_chars": 300,
    "min_quality_score": 0.90,
    "min_authority_confidence": 0.75,
    "user_agent": "Test Agent",
    "respect_robots_txt": True,
    "enable_ocr": False,
    "ocr_language": "eng",
    "ocr_dpi": 200,
    "enable_browser_rendering": False,
    "browser_timeout_seconds": 60.0,
    "enable_source_snapshots": True,
    "require_human_review_on_rejection": True,
    "log_style": "json",
    "google_cloud_project": "test-project", # Add required env-specific fields
}

def test_settings_computed_properties():
    """Verify that the computed properties of the Settings class work as expected."""

    # --- Test `allowed_hosts` property ---
    # Create a copy and modify it for this specific test case
    host_test_data = BASE_TEST_SETTINGS.copy()
    host_test_data['source_allowlist'] = "  finra.org, , ecfr.gov,  www.example.com  "
    settings_hosts = Settings(**host_test_data)
    
    expected_hosts = {"finra.org", "ecfr.gov", "www.example.com"}
    assert settings_hosts.allowed_hosts == expected_hosts
    assert settings_hosts.allowlist_open is False

    # --- Test `allowlist_open` property ---
    wildcard_test_data = BASE_TEST_SETTINGS.copy()
    wildcard_test_data['source_allowlist'] = "*"
    settings_wildcard = Settings(**wildcard_test_data)
    assert settings_wildcard.allowlist_open is True

    # --- Test `source_host_alias_map` property ---
    alias_test_data = BASE_TEST_SETTINGS.copy()
    alias_test_data['source_host_aliases'] = "127.0.0.1=finra.org, localhost=finra.org"
    settings_aliases = Settings(**alias_test_data)
    
    expected_map = {
        "127.0.0.1": "finra.org",
        "localhost": "finra.org"
    }
    assert settings_aliases.source_host_alias_map == expected_map
