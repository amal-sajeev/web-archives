"""Tests specific to the RBI adapter."""
from main.adapters.rbi import RbiAdapter

def test_rbi_adapter_instantiates():
    """Verify that the RbiAdapter can be created."""
    adapter = RbiAdapter()
    assert adapter.name == "rbi"
