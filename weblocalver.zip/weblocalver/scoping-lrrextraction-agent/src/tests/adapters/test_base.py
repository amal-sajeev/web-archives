import hashlib

from adapters import get_adapter
from main.adapters.base import RegulatorAdapter
from main.adapters.ecfr import EcfrAdapter
from main.adapters.fca import FcaAdapter
from main.adapters.finra import FinraAdapter
from main.adapters.generic import GenericAdapter
from main.adapters.rbi import RbiAdapter
from main.models.domain import SourceSnapshot, SourceClassification
from main.adapters import finra, ecfr, fca, rbi

def _snapshot(url: str, content: str = "") -> SourceSnapshot:
    """Create a valid mock SourceSnapshot for testing."""
    content_bytes = content.encode('utf-8')
    return SourceSnapshot(
        source_url=url,
        canonical_url=url,
        final_url=url,
        retrieved_at="2024-01-01T00:00:00Z",
        http_status=200,
        content_type="text/html",
        sha256_raw=hashlib.sha256(content_bytes).hexdigest(),
    )

def test_get_adapter_selects_correct_adapter_based_on_url():
    """Test that the factory returns the correct adapter for different URLs."""
    # Test FINRA
    finra_adapter = get_adapter(_snapshot("https://www.finra.org/rules-guidance"))
    assert isinstance(finra_adapter, FinraAdapter)

    # Test ECFR
    ecfr_adapter = get_adapter(_snapshot("https://www.ecfr.gov/current/title-17"))
    assert isinstance(ecfr_adapter, EcfrAdapter)

    # Test FCA
    fca_adapter = get_adapter(_snapshot("https://www.fca.org.uk/firms"))
    assert isinstance(fca_adapter, FcaAdapter)

    # Test RBI
    rbi_adapter = get_adapter(_snapshot("https://www.rbi.org.in/scripts/BS_PressReleaseDisplay.aspx"))
    assert isinstance(rbi_adapter, RbiAdapter)

    # Test Generic Fallback
    generic_adapter = get_adapter(_snapshot("https://www.example.com/other"))
    assert isinstance(generic_adapter, GenericAdapter)

def test_all_adapters_instantiate_with_a_name():
    """Verify that every adapter class can be instantiated and has a 'name' attribute."""
    adapter_classes = [
        GenericAdapter,
        FinraAdapter,
        EcfrAdapter,
        FcaAdapter,
        RbiAdapter,
    ]

    for adapter_class in adapter_classes:
        instance = adapter_class()
        assert hasattr(instance, "name") and isinstance(instance.name, str) and instance.name, f"{adapter_class.__name__} has an invalid or missing 'name' attribute"
