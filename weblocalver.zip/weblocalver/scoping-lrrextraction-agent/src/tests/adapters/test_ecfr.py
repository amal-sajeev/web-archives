"""Tests specific to the eCFR adapter."""
from main.adapters.ecfr import EcfrAdapter

def test_ecfr_adapter_instantiates():
    """Verify that the EcfrAdapter can be created."""
    adapter = EcfrAdapter()
    assert adapter.name == "ecfr"
