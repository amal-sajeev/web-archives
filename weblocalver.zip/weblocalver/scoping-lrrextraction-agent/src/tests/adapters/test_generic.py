"""Tests for the generic fallback adapter."""

from main.adapters.generic import GenericAdapter

def test_generic_adapter_instantiates():
    """Verify that the GenericAdapter can be created."""
    adapter = GenericAdapter()
    assert adapter.name == "generic"
