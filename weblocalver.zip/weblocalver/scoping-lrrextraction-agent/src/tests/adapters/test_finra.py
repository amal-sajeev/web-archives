"""Tests specific to the FINRA adapter."""

from main.adapters.finra import FinraAdapter

def test_finra_adapter_instantiates():
    """Verify that the FinraAdapter can be created and has the correct name."""
    adapter = FinraAdapter()
    assert adapter.name == "finra"
