"""Tests specific to the FCA adapter."""
from main.adapters.fca import FcaAdapter

def test_fca_adapter_instantiates():
    """Verify that the FcaAdapter can be created."""
    adapter = FcaAdapter()
    assert adapter.name == "fca"
