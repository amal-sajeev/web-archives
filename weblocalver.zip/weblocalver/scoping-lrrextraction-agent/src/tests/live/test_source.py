"""Tests for live source utilities."""

from main.live.source import _source_id, _domain, _build_source


def test_source_id_from_url():
    """Test source ID generation from URL."""
    url = "https://example.com/rules"
    result = _source_id(url)
    assert isinstance(result, str)
    assert len(result) <= 80


def test_domain_extraction():
    """Test domain extraction from URL."""
    url = "https://example.com/path"
    assert _domain(url) == "example.com"
    
    url_with_port = "https://example.com:8080/path"
    assert _domain(url_with_port) == "example.com:8080"


def test_domain_lowercase():
    """Test domain is lowercased."""
    url = "https://EXAMPLE.COM/path"
    assert _domain(url) == "example.com"


def test_build_source_html():
    """Test building source dict for HTML content."""
    result = _build_source("https://example.com/doc", "text/html", 200, "2026-10-06T00:00:00Z")
    assert result["format"] == "html"
    assert result["status"] == "accepted"
    assert result["url"] == "https://example.com/doc"


def test_build_source_pdf():
    """Test building source dict for PDF content."""
    result = _build_source("https://example.com/doc.pdf", "application/pdf", 200, "2026-10-06T00:00:00Z")
    assert result["format"] == "pdf"


def test_build_source_error_status():
    """Test building source with error status."""
    result = _build_source("https://example.com/404", "text/html", 404, "2026-10-06T00:00:00Z")
    assert result["status"] == "error"
