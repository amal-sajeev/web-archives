"""Tests for live builder module."""

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from main.live.builder import _build_live_data, _load_json_map, _run_id_from_key


def test_run_id_from_key_with_extension():
    """Test extracting run ID from JSON file key."""
    key = "checkpoints/run-123.json"
    result = _run_id_from_key(key)
    assert result == "run-123"


def test_run_id_from_key_without_extension():
    """Test extracting run ID from key without .json."""
    key = "manifests/run-456"
    result = _run_id_from_key(key)
    assert result == "run-456"


def test_load_json_map_empty():
    """Test loading JSON map when storage is empty."""
    mock_storage = MagicMock()
    mock_storage.list_keys.return_value = []
    result = _load_json_map(mock_storage, "prefix/")
    assert result == {}


def test_load_json_map_single_file():
    """Test loading single JSON file."""
    mock_storage = MagicMock()
    mock_storage.list_keys.return_value = ["prefix/run-123.json"]
    mock_storage.read.return_value = '{"run_id": "run-123", "objective": "test"}'

    result = _load_json_map(mock_storage, "prefix/")

    assert "run-123" in result
    assert result["run-123"]["objective"] == "test"


def test_load_json_map_invalid_json():
    """Test skipping files with invalid JSON."""
    mock_storage = MagicMock()
    mock_storage.list_keys.return_value = ["prefix/bad.json"]
    mock_storage.read.return_value = "{ invalid json }"

    result = _load_json_map(mock_storage, "prefix/")

    assert result == {}


def test_load_json_map_non_dict_content():
    """Test skipping non-dict JSON content."""
    mock_storage = MagicMock()
    mock_storage.list_keys.return_value = ["prefix/array.json"]
    mock_storage.read.return_value = '["item1", "item2"]'

    result = _load_json_map(mock_storage, "prefix/")

    assert result == {}


@patch("main.live.builder.make_storage")
@patch("main.live.builder.Settings")
def test_build_live_data_returns_none_when_storage_is_empty(mock_settings, mock_make_storage):
    mock_settings.return_value = object()
    mock_storage = MagicMock()
    mock_storage.list_keys.side_effect = [[], []]
    mock_make_storage.return_value = mock_storage

    result = _build_live_data()

    assert result is None


@patch("main.live.builder.make_storage")
@patch("main.live.builder.Settings")
@patch("main.live.builder.build_ir_from_text")
@patch("main.live.builder.classify_source_deterministic")
@patch("main.live.builder.resolve_version")
@patch("main.live.builder._source_id")
@patch("main.live.builder._build_source")
def test_build_live_data_builds_runs_sources_documents_and_review(
    mock_build_source,
    mock_source_id,
    mock_resolve_version,
    mock_classify,
    mock_build_ir,
    mock_settings,
    mock_make_storage,
):
    mock_settings.return_value = object()
    mock_storage = MagicMock()
    mock_storage.list_keys.side_effect = [
        ["manifests/run-1.json"],
        ["checkpoints/run-1.json"],
    ]
    mock_storage.read.side_effect = [
        '{"run_id": "run-1", "objective": "demo", "steps": 3, "documents": [{"title": "Doc 1"}], "history": [{"step": 1, "action": "fetch", "target": "https://example.com/a", "status": "ok"}, {"step": 2, "action": "extract", "target": "https://example.com/a", "error": "boom", "reason": "bad"}], "review": [{"source_url": "https://example.com/a", "identity": {"title": "Doc 1"}, "issues": ["missing data"]}], "completion": {"complete": true}, "created_at": "2024-01-01T00:00:00Z"}',
        '{"run_id": "run-1", "documents": [{"source_url": "https://example.com/a", "canonical_url": "https://example.com/a", "identity": {"title": "Doc 1", "publisher": "Example"}, "raw_text": "hello world", "raw_sha256": "abc123"}], "fetched": [{"final_url": "https://example.com/a", "requested_url": "https://example.com/a", "content_type": "text/html", "status_code": 200, "retrieved_at": "2024-01-01T00:00:00Z"}, {"final_url": "https://example.com/a", "requested_url": "https://example.com/a", "content_type": "text/html", "status_code": 200, "retrieved_at": "2024-01-01T00:00:00Z"}], "outputs": [{"canonical_url": "https://example.com/a", "validation": {"status": "passed", "score": 0.88, "source_fidelity_score": 0.92, "issues": ["ok"]}}]}',
    ]
    mock_make_storage.return_value = mock_storage

    mock_source_id.return_value = "doc-source-id"
    mock_build_source.return_value = {
        "id": "doc-source-id",
        "source_role": "instrument",
        "url": "https://example.com/a",
        "status": "accepted",
    }

    mock_classify.return_value = SimpleNamespace(
        source_role=SimpleNamespace(value="instrument"),
        source_authority=SimpleNamespace(value="government"),
        legal_authority_level=SimpleNamespace(value="primary"),
        temporal_state=SimpleNamespace(value="current"),
        title="Doc 1",
    )
    mock_resolve_version.return_value = SimpleNamespace(
        temporal_state=SimpleNamespace(value="current"),
        confidence=0.9,
        reasons=["ok"],
    )

    mock_ir = SimpleNamespace(
        nodes=[
            SimpleNamespace(
                node_id="n-1",
                parent_id=None,
                label="Section",
                title="Doc 1",
                node_type="section",
                text="hello world",
                children=[],
            )
        ],
        ir_sha256=lambda: "abc123",
    )
    mock_build_ir.return_value = mock_ir

    result = _build_live_data()

    assert result is not None
    assert result["runs"][0]["run_id"] == "run-1"
    assert result["events"]["run-1"][0]["action"] == "fetch"
    assert result["sources"][0]["url"] == "https://example.com/a"
    assert result["documents"][0]["source_url"] == "https://example.com/a"
    assert result["documents"][0]["validation"]["overall_status"] == "passed"
    assert result["review"][0]["document_title"] == "Doc 1"
    assert result["graph"]["nodes"]["doc-source-id"]["label"] == "Doc 1"
