"""Tests for live module data access."""

from unittest.mock import patch

import pytest

from main.live.data import get_live_data, invalidate_live_data


@patch("main.live.data._build_live_data")
def test_get_live_data_caching(mock_build_live_data):
    """Test that live data is cached and reused."""
    mock_build_live_data.return_value = {"runs": [{"run_id": "run-1"}]}
    invalidate_live_data()

    data1 = get_live_data()
    data2 = get_live_data()

    assert data1 is data2  # Same object reference
    assert mock_build_live_data.call_count == 1


@patch("main.live.data._build_live_data")
def test_invalidate_live_data(mock_build_live_data):
    """Test that invalidate resets the cache."""
    mock_build_live_data.return_value = {"runs": [{"run_id": "run-1"}]}

    invalidate_live_data()
    get_live_data()
    assert mock_build_live_data.call_count == 1

    invalidate_live_data()
    get_live_data()
    assert mock_build_live_data.call_count == 2
