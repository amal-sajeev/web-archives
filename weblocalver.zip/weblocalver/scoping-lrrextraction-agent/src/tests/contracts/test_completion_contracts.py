"""Tests for the completion contract logic."""

from main.contracts.completion_contracts import get_contract, check_completion
from main.models.domain import SourceRole, ValidationReport, SourceClassification

# A mock DocumentIR class for testing
class MockDocumentIR:
    def __init__(self, has_nodes=True):
        self.nodes = ["node1"] if has_nodes else []

def test_get_contract_returns_correct_contract():
    """Verify that get_contract returns the specific contract for a role."""
    instrument_contract = get_contract(SourceRole.INSTRUMENT)
    assert "identity resolved" in instrument_contract

    index_contract = get_contract(SourceRole.INDEX)
    assert "entries enumerated" in index_contract

def test_get_contract_falls_back_to_instrument_for_unknown_role():
    """Verify that get_contract returns the INSTRUMENT contract for an unknown or unhandled role."""
    # Use a role that doesn't have a specific contract defined
    fallback_contract = get_contract(SourceRole.UNKNOWN)
    instrument_contract = get_contract(SourceRole.INSTRUMENT)
    assert fallback_contract == instrument_contract

def test_check_completion_with_perfect_data():
    """Test check_completion with data that should satisfy all contract requirements."""
    perfect_report = ValidationReport(
        numeric_fidelity=1.0,
        date_fidelity=1.0,
        modal_fidelity=1.0,
        section_coverage=1.0,
        sequence_similarity=1.0,
    )
    perfect_classification = SourceClassification(
        title="Test Title",
        source_authority="primary_regulator",
    )
    perfect_ir = MockDocumentIR(has_nodes=True)
    version_is_resolved = True

    result = check_completion(
        SourceRole.INSTRUMENT,
        perfect_ir,
        perfect_report,
        perfect_classification,
        version_is_resolved
    )

    assert result["complete"] is True
    assert len(result["unmet"]) == 0
    assert len(result["met"]) == len(get_contract(SourceRole.INSTRUMENT))

def test_check_completion_with_failures():
    """Test that check_completion correctly identifies unmet requirements."""
    failing_report = ValidationReport(section_coverage=0.5) # This will fail the coverage check
    failing_classification = SourceClassification(title=None) # This will fail the identity check
    failing_ir = MockDocumentIR(has_nodes=False) # This will fail the structure check
    version_is_unresolved = False # This will fail the version check

    result = check_completion(
        SourceRole.INSTRUMENT,
        failing_ir,
        failing_report,
        failing_classification,
        version_is_unresolved
    )

    assert result["complete"] is False
    assert len(result["unmet"]) > 0
    # Check that specific requirements are in the unmet list
    assert any("identity resolved" in req for req in result["unmet"])
    assert any("structure reconstructed" in req for req in result["unmet"])
    assert any("version/temporal state resolved" in req for req in result['unmet'])
    assert any("all expected sections/pages covered" in req for req in result['unmet'])
