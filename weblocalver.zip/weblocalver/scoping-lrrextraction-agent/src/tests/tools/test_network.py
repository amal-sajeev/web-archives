"""Tests for core network utilities."""

import pytest
from unittest.mock import patch, MagicMock

from main.tools.network import canonicalize, allowed, host


def test_canonicalize():
    """Test URL canonicalization to remove fragments, extra slashes, and trailing slashes."""
    # Should remove fragment
    assert canonicalize("http://example.com/page.html#section1") == "http://example.com/page.html"
    
    # Should remove extra slashes in the path
    assert canonicalize("http://example.com//a///b/") == "http://example.com/a/b"
    
    # Should remove trailing slash, unless it's the root
    assert canonicalize("http://example.com/a/b/") == "http://example.com/a/b"
    assert canonicalize("http://example.com/") == "http://example.com/"
    
    # Should handle query parameters correctly
    assert canonicalize("http://example.com/page?q=1#frag") == "http://example.com/page?q=1"

def test_host():
    """Test host extraction from a URL."""
    assert host("https://www.example.co.uk:8080/path?query=1") == "www.example.co.uk"
    assert host("http://localhost/another/path") == "localhost"

@patch("main.tools.network.Settings")
def test_allowed(MockSettings):
    """Test the URL host allowlist logic."""
    settings = MockSettings.return_value
    settings.allowlist_open = False
    settings.allowed_hosts = {"example.com", "finra.org"}
    settings.source_host_alias_map = {}

    assert allowed("https://www.example.com/page", settings) is True
    assert allowed("http://sub.finra.org/other", settings) is True
    assert allowed("https://www.google.com", settings) is False
    assert allowed("ftp://example.com/file", settings) is False # Wrong scheme

@patch("main.tools.network.Settings")
def test_allowed_with_alias(MockSettings):
    """Test that host aliases are correctly used in allowlist checks."""
    settings = MockSettings.return_value
    settings.allowlist_open = False
    settings.allowed_hosts = {"prod.finra.org"}
    settings.source_host_alias_map = {"uat.finra.net": "prod.finra.org"}

    # This should be allowed because the alias maps it to an allowed host
    assert allowed("https://uat.finra.net/rule/123", settings) is True
    # This should be disallowed as it is not in the allowlist or the alias map
    assert allowed("https://www.finra.org/page", settings) is False


@patch("main.tools.network.Settings")
def test_allowed_with_wildcard(MockSettings):
    """Test wildcard in allowlist."""
    settings = MockSettings.return_value
    settings.allowlist_open = False
    settings.allowed_hosts = {"*"}
    settings.source_host_alias_map = {}

    assert allowed("https://any-host.com/page", settings) is True
    assert allowed("https://example.org/other", settings) is True


@patch("main.tools.network.Settings")
def test_allowed_subdomain_matching(MockSettings):
    """Test subdomain matching logic."""
    settings = MockSettings.return_value
    settings.allowlist_open = False
    settings.allowed_hosts = {"example.com"}
    settings.source_host_alias_map = {}

    assert allowed("https://sub.example.com/page", settings) is True
    assert allowed("https://deep.sub.example.com/page", settings) is True
    assert allowed("https://example.com/page", settings) is True
    assert allowed("https://notexample.com/page", settings) is False


@patch("main.tools.network.Settings")
def test_allowed_allowlist_open(MockSettings):
    """Test when allowlist is open (allowlist_open=True)."""
    settings = MockSettings.return_value
    settings.allowlist_open = True
    settings.allowed_hosts = set()
    settings.source_host_alias_map = {}

    assert allowed("https://any-site.com/page", settings) is True
    assert allowed("http://localhost/test", settings) is True


@patch("main.tools.network.Settings")
def test_robots_allowed_when_disabled(MockSettings):
    """Test robots.txt check when respect_robots_txt is False."""
    settings = MockSettings.return_value
    settings.respect_robots_txt = False

    from main.tools.network import robots_allowed
    assert robots_allowed("https://example.com/page", settings) is True


@patch("main.tools.network.httpx.Client")
@patch("main.tools.network.Settings")
def test_robots_allowed_unreachable(MockSettings, mock_client):
    """Test robots.txt check when robots.txt is unreachable (404)."""
    from main.tools.network import robots_allowed, _ROBOTS_CACHE
    _ROBOTS_CACHE.clear()
    
    settings = MockSettings.return_value
    settings.respect_robots_txt = True
    settings.request_timeout_seconds = 5
    settings.user_agent = "TestBot"

    mock_response = MagicMock()
    mock_response.status_code = 404
    mock_client.return_value.__enter__.return_value.get.return_value = mock_response

    result = robots_allowed("https://example.com/page", settings)
    assert result is True  # Unreachable robots.txt is treated as allow


@patch("main.tools.network.httpx.Client")
@patch("main.tools.network.Settings")
def test_robots_allowed_parse_success(MockSettings, mock_client):
    """Test robots.txt parsing when it's accessible."""
    from main.tools.network import robots_allowed, _ROBOTS_CACHE
    _ROBOTS_CACHE.clear()
    
    settings = MockSettings.return_value
    settings.respect_robots_txt = True
    settings.request_timeout_seconds = 5
    settings.user_agent = "TestBot"

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = "User-agent: *\nDisallow: /admin/"
    mock_client.return_value.__enter__.return_value.get.return_value = mock_response

    result = robots_allowed("https://example.com/page", settings)
    assert result is True


@patch("main.tools.network.Settings")
def test_canonicalize_edge_cases(MockSettings):
    """Test additional edge cases for URL canonicalization."""
    # Test with query parameters
    assert canonicalize("http://example.com:80/page?key=value") == "http://example.com:80/page?key=value"
    
    # Test with non-standard port
    assert canonicalize("http://example.com:8080/path/") == "http://example.com:8080/path"
    
    # Test with https
    assert canonicalize("https://example.com/path/to/page/") == "https://example.com/path/to/page"
    
    # Test with mixed slashes
    assert canonicalize("http://example.com//path//to///page//") == "http://example.com/path/to/page"


@patch("main.tools.network.httpx.Client")
@patch("main.tools.network.Settings")
def test_fetch_blocked_host(MockSettings, mock_client):
    """Test fetch raises error for non-allowlisted host."""
    from main.tools.network import fetch
    
    settings = MockSettings.return_value
    settings.allowlist_open = False
    settings.allowed_hosts = {"allowed.com"}
    settings.source_host_alias_map = {}
    settings.respect_robots_txt = False

    with pytest.raises(ValueError, match="Host is not allowlisted"):
        fetch("https://blocked.com/page", settings)


@patch("main.tools.network.httpx.Client")
@patch("main.tools.network.Settings")
def test_fetch_success(MockSettings, mock_client):
    """Test successful fetch."""
    from main.tools.network import fetch
    from unittest.mock import MagicMock
    
    settings = MockSettings.return_value
    settings.allowlist_open = True
    settings.allowed_hosts = set()
    settings.source_host_alias_map = {}
    settings.respect_robots_txt = False
    settings.max_retries = 1
    settings.max_redirects = 0
    settings.request_timeout_seconds = 5
    settings.user_agent = "TestBot"
    settings.max_bytes = 1000000

    # Mock the httpx response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.url = "https://example.com/page"
    mock_response.headers = {"content-type": "text/html"}
    mock_response.iter_bytes.return_value = [b"Hello ", b"World"]
    
    mock_client.return_value.__enter__.return_value.stream.return_value.__enter__.return_value = mock_response

    result = fetch("https://example.com/page", settings)
    assert result["status_code"] == 200
    assert result["content"] == b"Hello World"
    assert result["content_type"] == "text/html"
