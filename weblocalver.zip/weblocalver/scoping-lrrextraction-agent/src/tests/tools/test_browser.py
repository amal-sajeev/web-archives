"""Tests for the browser-based tools."""

import pytest
from unittest.mock import patch, MagicMock

from main.tools.browser import (
    discover_browser_dom,
    _dedupe,
)

def test_discover_browser_dom_finds_all_link_types(test_settings):
    """Verify that discover_browser_dom finds links in various HTML tags and attributes."""
    html = '''
        <a href="/link1.pdf">Link 1</a>
        <iframe src="/iframe.html"></iframe>
        <button data-url="/data-url.html">Click me</button>  <!-- Use a supported tag -->
        <button onclick="window.location.href='/onclick.html'">Go</button>
        <script>
            const url = "https://example.com/script-url.js";
        </script>
    '''
    test_settings.source_allowlist = "example.com"
    links = discover_browser_dom("http://example.com", html, test_settings)
    urls = {link["url"] for link in links}
    
    assert "http://example.com/link1.pdf" in urls
    assert "http://example.com/iframe.html" in urls
    assert "http://example.com/data-url.html" in urls
    assert "http://example.com/onclick.html" in urls
    assert "https://example.com/script-url.js" in urls

def test_dedupe_prioritizes_higher_relevance():
    """Verify the deduplication logic keeps the item with the highest relevance score."""
    items = [
        {"url": "http://example.com/page", "relevance": 0.5, "title": "Old"},
        {"url": "http://example.com/page", "relevance": 0.8, "title": "New"}, # Higher score
        {"url": "http://example.com/other", "relevance": 0.6, "title": "Other"},
    ]
    
    deduped = _dedupe(items)
    
    assert len(deduped) == 2
    page_item = next((item for item in deduped if item["url"] == "http://example.com/page"), None)
    assert page_item is not None
    assert page_item["title"] == "New"
