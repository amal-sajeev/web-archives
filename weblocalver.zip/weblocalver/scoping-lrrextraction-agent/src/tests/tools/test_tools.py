"""Tests for tools module."""

from main.tools.tools import *


def test_tools_imports():
    """Test that tools module imports without error."""
    assert True

