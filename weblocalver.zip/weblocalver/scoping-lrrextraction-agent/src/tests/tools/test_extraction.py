"""Tests for document content extraction."""

from unittest.mock import patch, MagicMock
import pytest

from main.tools.extraction import extract_html, extract_pdf


def test_extract_html_removes_scripts_and_keeps_main_content():
    """Test that standard HTML is cleaned, preserving the <main> tag."""
    html = """<html>
        <head><title>Old Title</title></head>
        <body>
            <nav><a>Home</a></nav>
            <main><h1>Main Title</h1><p>Main content.</p></main>
            <footer>Footer</footer>
        </body>
    </html>"""
    text, warnings = extract_html(html)
    assert "Main Title" in text
    assert "Main content" in text
    assert "Home" not in text
    assert "Footer" not in text

@patch("main.tools.extraction.trafilatura")
def test_extract_html_uses_trafilatura_as_fallback(mock_trafilatura):
    """Test that trafilatura is called when no main/article tag is found."""
    html = "<body><p>Just some text.</p></body>"
    mock_trafilatura.extract.return_value = "Extracted by trafilatura."
    
    text, warnings = extract_html(html)
    
    mock_trafilatura.extract.assert_called_once()
    assert text.strip() == "Extracted by trafilatura."

@patch("main.tools.extraction.trafilatura", None)
def test_extract_html_fallback_without_trafilatura():
    """Test the fallback behavior when trafilatura is not installed."""
    html = "<body><p>Body content only.</p></body>"
    
    text, warnings = extract_html(html)
    
    assert "Body content only." in text
    assert any("used body fallback" in w for w in warnings)


@patch("main.tools.extraction.pymupdf.open")
def test_extract_pdf_handles_basic_pdf(mock_pdf_open):
    """Test basic text extraction from a mocked PDF document."""
    mock_doc = MagicMock()
    mock_page1 = MagicMock()
    mock_page1.get_text.return_value = "This is page one."
    mock_page2 = MagicMock()
    mock_page2.get_text.return_value = "This is page two."
    
    mock_doc.page_count = 2
    mock_doc.__iter__.return_value = [mock_page1, mock_page2]
    mock_pdf_open.return_value = mock_doc

    pdf_bytes = b"%PDF-fake"
    text, warnings, page_count = extract_pdf(pdf_bytes)

    assert page_count == 2
    assert "This is page one." in text
    assert "This is page two." in text
    assert "<!-- source-page: 2 -->" in text
