"""Tests for quality and authority assessment tools."""

import hashlib
from unittest.mock import MagicMock, patch

from main.tools import quality as quality_tools
from main.tools.quality import (
    _publisher_matches_host,
    authority_assessment,
    bounded_fetch,
    deterministic_quality,
    sha256_text,
    slugify,
)


def test_deterministic_quality_full_match():
    raw = " ".join(["alpha"] * 12)
    result = deterministic_quality(raw, raw)

    assert result["score"] > 0.9
    assert result["missing_tail"] is False


def test_deterministic_quality_handles_empty_and_truncated_inputs():
    empty_result = deterministic_quality("", "alpha beta")
    assert empty_result == {
        "score": 0.0,
        "coverage": 0.0,
        "length_ratio": 0.0,
        "missing_tail": True,
    }

    truncated = deterministic_quality(
        "alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu nu xi omicron pi rho sigma",
        "alpha beta gamma",
    )
    assert truncated["score"] < 1.0
    assert truncated["missing_tail"] is True


def test_publisher_matches_host_supports_word_and_acronym_matching():
    assert _publisher_matches_host("FINRA", "finra.org") is True
    assert _publisher_matches_host("SEC", "sec.gov") is True
    assert _publisher_matches_host("Unknown Publisher", "example.org") is False


def test_authority_assessment_open_policy_alias_and_instrument():
    settings = MagicMock()
    settings.source_host_alias_map = {"example.com": "finra.org"}
    settings.allowed_hosts = {"example.org"}
    settings.allowlist_open = True

    score, reasons = authority_assessment(
        "https://example.com/page",
        {"publisher": "FINRA", "authority_class": "instrument"},
        settings,
    )

    assert score >= 0.75
    assert any("open acquisition policy" in r for r in reasons)
    assert any("instrument" in r for r in reasons)


def test_authority_assessment_subdomain_and_guidance_branch():
    settings = MagicMock()
    settings.source_host_alias_map = {}
    settings.allowed_hosts = {"secure.example.org"}
    settings.allowlist_open = False

    score, reasons = authority_assessment(
        "https://www.secure.example.org/rule",
        {"publisher": "Other Org", "authority_class": "guidance"},
        settings,
    )

    assert score >= 0.45
    assert any("subdomain" in r for r in reasons)
    assert any("guidance" in r for r in reasons)


def test_authority_assessment_unlisted_host_uses_fallback_score():
    settings = MagicMock()
    settings.source_host_alias_map = {}
    settings.allowed_hosts = {"allowed.example.org"}
    settings.allowlist_open = False

    score, reasons = authority_assessment(
        "https://example.com/page",
        {"publisher": "", "authority_class": ""},
        settings,
    )

    assert score == 0.03
    assert any("not allowlisted" in r for r in reasons)


def test_sha256_text_and_slugify_helpers():
    assert sha256_text("abc") == hashlib.sha256(b"abc").hexdigest()
    assert slugify("Hello, World!!!") == "hello-world"
    assert slugify("!!!") == "document"


@patch("main.tools.quality.fetch")
@patch("main.tools.quality.canonicalize")
def test_bounded_fetch_handles_successes_and_errors(mock_canonicalize, mock_fetch):
    settings = MagicMock()
    settings.max_concurrent_fetches = 2
    mock_fetch.side_effect = [
        {"requested_url": "https://example.com/ok", "status": 200},
        ValueError("bad request"),
    ]
    mock_canonicalize.side_effect = lambda value: value

    result = bounded_fetch(["https://example.com/ok", "https://example.com/bad"], settings)

    assert len(result) == 2
    assert any(item.get("error") == "bad request" for item in result)
    assert any(item.get("status") == 200 for item in result)


def test_quality_module_imports_are_available():
    assert quality_tools.slugify is slugify
    assert quality_tools.sha256_text is sha256_text