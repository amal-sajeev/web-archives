"""Tests for the link discovery tool."""

import pytest
from main.tools.discovery import _regulatory_score, discover_links

def test_regulatory_score():
    """Verify the scoring logic for regulatory-related keywords."""
    # High-value keywords should result in a high score
    score1 = _regulatory_score("/rule-123.pdf", "Download the new rule for 2024")
    assert score1 > 0.5

    # No keywords should result in a zero score
    score2 = _regulatory_score("/about-us.html", "Learn more about our company")
    assert score2 == 0.0

    # Test with custom terms
    score3 = _regulatory_score("/custom.html", "This is a custom document", terms=["custom"])
    assert score3 > 0.19

def test_discover_links_finds_and_scores_links(test_settings):
    """Verify that discover_links correctly finds, scores, and filters links from HTML."""
    html = '''
        <a href="/rule-1.pdf">Download Rule 1</a>
        <a href="/about-us.html">About the company</a>
        <a href="http://unapproved.com/spam">Spam Link</a>
    '''
    test_settings.source_allowlist = "example.com"
    links = discover_links("http://example.com", html, test_settings)

    assert len(links) == 2  # The unapproved link should be filtered out
    
    # The rule link should have a higher score than the about us link
    rule_link = next((link for link in links if "rule-1" in link["url"]), None)
    about_link = next((link for link in links if "about-us" in link["url"]), None)

    assert rule_link is not None
    assert about_link is not None
    assert rule_link["relevance"] > about_link["relevance"]
    assert rule_link["kind"] == "pdf"
