from unittest.mock import MagicMock, patch

import pytest

from main.processing.pdf_processing import _normalize_request_id, _safe_pdf_filename, process_pdf_files


def test_normalize_request_id_with_none_and_prefixed_value():
    value = _normalize_request_id(None)
    assert isinstance(value, str)
    assert value

    assert _normalize_request_id("dbaware_review_12345") == "12345"
    assert _normalize_request_id("  req-99  ") == "req-99"


def test_normalize_request_id_blank_value_uses_generated_id():
    value = _normalize_request_id("   ")
    assert isinstance(value, str)
    assert value


def test_safe_pdf_filename_valid_and_invalid():
    assert _safe_pdf_filename("report.pdf") == "report.pdf"

    with pytest.raises(ValueError, match="Only PDF files are allowed"):
        _safe_pdf_filename("report.txt")

    with pytest.raises(ValueError, match="missing a filename"):
        _safe_pdf_filename("")


@patch("main.processing.pdf_processing.upload_text_to_gcs")
@patch("main.processing.pdf_processing.extract_pdf")
@patch("main.processing.pdf_processing.Settings")
def test_process_pdf_files_success(mock_settings, mock_extract_pdf, mock_upload):
    mock_settings.return_value = object()
    mock_extract_pdf.return_value = ("Extracted text", ["warning one"], 2)
    mock_upload.return_value = "gs://demo-bucket/dbaware_review_req123/processing-data/llr-extracted/lrr_raw_data_req123.md"

    file = MagicMock()
    file.filename = "sample.pdf"
    file.file.read.return_value = b"pdf-bytes"

    result = process_pdf_files([file], request_id="dbaware_review_req123")

    assert result["status"] == "success"
    assert result["request_id"] == "req123"
    assert result["output_path"] == "dbaware_review_req123/processing-data/llr-extracted/lrr_raw_data_req123.md"
    assert result["gcs_uri"] == "gs://demo-bucket/dbaware_review_req123/processing-data/llr-extracted/lrr_raw_data_req123.md"
    assert result["file_count"] == 1
    assert result["warnings"] == ["sample.pdf: warning one"]
    assert result["output_format"] == "markdown"


@patch("main.processing.pdf_processing.Settings")
def test_process_pdf_files_requires_at_least_one_file(mock_settings):
    mock_settings.return_value = object()

    with pytest.raises(ValueError, match="At least one PDF file is required"):
        process_pdf_files([])


@patch("main.processing.pdf_processing.upload_text_to_gcs")
@patch("main.processing.pdf_processing.extract_pdf")
@patch("main.processing.pdf_processing.Settings")
def test_process_pdf_files_rejects_empty_pdf(mock_settings, mock_extract_pdf, mock_upload):
    mock_settings.return_value = object()
    mock_extract_pdf.return_value = ("", [], 0)

    file = MagicMock()
    file.filename = "empty.pdf"
    file.file.read.return_value = b""

    with pytest.raises(ValueError, match="empty"):
        process_pdf_files([file])

    mock_upload.assert_not_called()


@patch("main.processing.pdf_processing.upload_text_to_gcs")
@patch("main.processing.pdf_processing.extract_pdf")
@patch("main.processing.pdf_processing.Settings")
def test_process_pdf_files_raises_on_invalid_extension(mock_settings, mock_extract_pdf, mock_upload):
    mock_settings.return_value = object()

    file = MagicMock()
    file.filename = "bad.txt"
    file.file.read.return_value = b"whatever"

    with pytest.raises(ValueError, match="Unsupported file type"):
        process_pdf_files([file])

    mock_extract_pdf.assert_not_called()
    mock_upload.assert_not_called()


@patch("main.processing.pdf_processing.upload_text_to_gcs")
@patch("main.processing.pdf_processing.extract_pdf")
@patch("main.processing.pdf_processing.Settings")
def test_process_pdf_files_handles_empty_extracted_text_without_raising(mock_settings, mock_extract_pdf, mock_upload):
    mock_settings.return_value = object()
    mock_extract_pdf.return_value = ("", [], 0)
    mock_upload.return_value = "gs://demo-bucket/dbaware_review_req123/processing-data/llr-extracted/lrr_raw_data_req123.md"

    file = MagicMock()
    file.filename = "sample.pdf"
    file.file.read.return_value = b"not-empty"

    result = process_pdf_files([file])

    assert result["status"] == "success"
    assert result["gcs_uri"] == "gs://demo-bucket/dbaware_review_req123/processing-data/llr-extracted/lrr_raw_data_req123.md"
    mock_upload.assert_called_once()
