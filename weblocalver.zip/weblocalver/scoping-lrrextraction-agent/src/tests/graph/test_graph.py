"""Tests for the main graph construction."""

from main.graph.graph import build_graph

def test_build_graph_compiles_with_expected_nodes():
    """Verify that the graph can be built and contains all the expected nodes."""
    graph = build_graph()
    assert graph is not None
    # Get the actual nodes from the compiled graph.
    actual_nodes = set(graph.nodes.keys())
    # Check for the essential nodes that define the application's flow.
    assert "__start__" in actual_nodes
    assert "bootstrap" in actual_nodes
    assert "plan" in actual_nodes
    assert "agent_decide" in actual_nodes
    assert "execute_action" in actual_nodes
    assert "persist" in actual_nodes
    # The graph uses a conditional edge to END, so "__end__" is not a node itself.
    # We verify its presence by checking the compiled graph's connections if needed,
    # but for a basic compilation test, checking the main nodes is sufficient.
