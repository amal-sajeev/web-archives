"""Tests for the graph helper functions."""

import pytest
from unittest.mock import patch, MagicMock
from main.graph.fetch_helper import (
    _candidate_score,
    _all_urls,
    _failure,
    _failure_is_permanent,
    _completion,
    _repair_check,
    _action_failure_key,
    _failed_action_count,
    _record_action_failure,
    discover_page_resources,
)
from main.graph.core import State, Settings
from main.tools import canonicalize

def test_all_urls_gathers_from_all_sources():
    """Verify that _all_urls correctly collects URLs from all parts of the state."""
    state: State = {
        "seeds": ["http://a.com"],
        "frontier": [{"url": "http://b.com"}],
        "candidates": [{"url": "http://c.com"}],
        "fetched": [{"source_url": "http://d.com"}],
        "documents": [{"canonical_url": "http://e.com"}],
        "outputs": [{"source_url": "http://f.com"}],
    }
    
    expected_urls = {
        "http://a.com/", "http://b.com/", "http://c.com/",
        "http://d.com/", "http://e.com/", "http://f.com/"
    }
    
    all_urls = _all_urls(state)
    assert all_urls == expected_urls

def test_candidate_score_logic():
    pdf_candidate = {"relevance": 0.5, "kind": "pdf", "authoritative": True}
    assert _candidate_score(pdf_candidate) > 0.8

def test_failure_updates_state_correctly():
    initial_state: State = {"errors": ["initial error"]}
    failure_state = _failure(initial_state, "test_action", "http://target.com", "A test error occurred")
    assert len(failure_state["errors"]) == 2

def test_failure_is_permanent_logic():
    assert _failure_is_permanent("authority gate rejected") is True
    assert _failure_is_permanent("temporary error") is False

def test_completion_logic(monkeypatch, test_settings):
    """Verify the completion logic works correctly."""
    monkeypatch.setattr(Settings, "__new__", lambda cls: test_settings)
    
    state_with_output: State = {"outputs": [{"validation": {"status": "accept"}}]}
    assert _completion(state_with_output).complete is True

    state_without_output: State = {"outputs": [], "frontier": [], "candidates": [], "errors": ["An error"]}
    assert _completion(state_without_output).complete is True

def test_repair_check_increments_correctly():
    """Verify that _repair_check correctly counts retry attempts."""
    state: State = {
        "repair_attempts": {"http://example.com/": 1},
        "fetched": [{"final_url": "http://example.com/"}],
    }
    updated_counts = _repair_check(state, "retry", "http://example.com")
    assert updated_counts.get("http://example.com/") == 2

def test_action_failure_key_is_consistent():
    """Verify that the failure key is created consistently."""
    key1 = _action_failure_key("extract", "http://example.com")
    key2 = _action_failure_key("extract", "http://example.com/") # Should be the same
    assert key1 == key2
    assert ":" in key1

def test_record_and_count_action_failures():
    """Verify that failure recording and counting work together."""
    state: State = {"failed_actions": {"extract:http://example.com/": 1}}
    
    # First, check the count
    count = _failed_action_count(state, "extract", "http://example.com")
    assert count == 1

    # Then, record another failure
    new_counts = _record_action_failure(state, "extract", "http://example.com")
    assert new_counts["extract:http://example.com/"] == 2

@patch("main.graph.fetch_helper.discover_links")
@patch("main.graph.fetch_helper.discover_browser_resources")
def test_discover_page_resources_combines_sources(mock_browser_discover, mock_link_discover, test_settings):
    """Verify that discover_page_resources correctly combines links from HTML and browser."""
    # Arrange: Mock the return values of the two discovery functions
    mock_link_discover.return_value = [{"url": "http://example.com/from_html"}]
    mock_browser_discover.return_value = [{"url": "http://example.com/from_browser"}]
    
    test_settings.enable_browser_rendering = True
    
    # Act: Call the function under test
    links = discover_page_resources("http://example.com", "<html></html>", test_settings)
    
    # Assert: Check that links from both sources are present in the final list
    urls = {link["url"] for link in links}
    assert "http://example.com/from_html" in urls
    assert "http://example.com/from_browser" in urls
    assert len(links) == 2

@patch("main.graph.fetch_helper.discover_links")
@patch("main.graph.fetch_helper.discover_browser_resources")
def test_discover_page_resources_handles_browser_off(mock_browser_discover, mock_link_discover, test_settings):
    """Verify that browser discovery is skipped when disabled."""
    mock_link_discover.return_value = [{"url": "http://example.com/from_html"}]
    test_settings.enable_browser_rendering = False
    
    links = discover_page_resources("http://example.com", "<html></html>", test_settings)
    
    # Assert that the browser discovery function was never called
    mock_browser_discover.assert_not_called()
    assert len(links) == 1
