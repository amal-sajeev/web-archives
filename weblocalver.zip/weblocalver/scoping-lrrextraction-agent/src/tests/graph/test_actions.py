"""Tests for the graph action execution node."""

from unittest.mock import patch, MagicMock, Mock
from main.graph.actions import execute_action_node
from main.graph.core import State
from main.models import AgentDecision

# We patch the helper functions to isolate the logic of the action node itself.
@patch("main.graph.core._storage")
@patch("main.graph.actions.Settings")
@patch("main.graph.actions._fetch_one")
@patch("main.graph.actions._frontier_item")
def test_execute_action_node_handles_fetch(mock_frontier_item, mock_fetch_one, mock_settings_class, mock_storage_factory, test_settings):
    """Verify that a 'fetch' decision correctly calls the _fetch_one helper."""
    # Mock storage to avoid GCS calls
    mock_storage = Mock()
    mock_storage_factory.return_value = mock_storage
    
    # Configure Settings mock to have proper allowlist
    mock_instance = MagicMock()
    mock_instance.allowed_hosts = test_settings.allowed_hosts or {"*"}
    mock_instance.max_discovery_depth = test_settings.max_discovery_depth
    mock_instance.max_pages = test_settings.max_pages
    mock_instance.max_repair_attempts = test_settings.max_repair_attempts
    mock_instance.checkpoint_every_step = False  # Disable checkpointing for test
    mock_instance.require_source_allowlist = MagicMock()
    mock_settings_class.return_value = mock_instance
    mock_frontier_item.return_value = {"url": "http://example.com"}
    mock_fetch_one.return_value = {"final_url": "http://example.com", "content": b"data"}
    
    decision = AgentDecision(action="fetch", target="http://example.com", reason="test")
    # Add run_id to the state
    initial_state: State = {"run_id": "test-run", "decision": decision.model_dump(), "step": 0, "frontier": [{"url": "http://example.com"}]}

    new_state = execute_action_node(initial_state)

    mock_fetch_one.assert_called_once()
    assert new_state["step"] == 1
    assert len(new_state["fetched"]) == 1

@patch("main.graph.core._storage")
@patch("main.graph.actions.Settings")
@patch("main.graph.actions._extract_one")
@patch("main.graph.actions._matching_fetched_item")
def test_execute_action_node_handles_extract(mock_matching_item, mock_extract_one, mock_settings_class, mock_storage_factory, test_settings):
    """Verify that an 'extract' decision correctly calls the _extract_one helper."""
    # Mock storage to avoid GCS calls
    mock_storage = Mock()
    mock_storage_factory.return_value = mock_storage
    
    # Configure Settings mock to have proper allowlist
    mock_instance = MagicMock()
    mock_instance.allowed_hosts = test_settings.allowed_hosts or {"*"}
    mock_instance.max_discovery_depth = test_settings.max_discovery_depth
    mock_instance.max_pages = test_settings.max_pages
    mock_instance.max_repair_attempts = test_settings.max_repair_attempts
    mock_instance.checkpoint_every_step = False  # Disable checkpointing for test
    mock_instance.require_source_allowlist = MagicMock()
    mock_settings_class.return_value = mock_instance
    mock_matching_item.return_value = {"requested_url": "http://example.com"}
    mock_extract_one.return_value = {"canonical_url": "http://example.com", "raw_text": "text"}
    
    decision = AgentDecision(action="extract", target="http://example.com", reason="test")
    # Add run_id to the state
    initial_state: State = {"run_id": "test-run", "decision": decision.model_dump(), "step": 1, "fetched": [mock_matching_item.return_value]}

    new_state = execute_action_node(initial_state)

    mock_extract_one.assert_called_once()
    assert new_state["step"] == 2
    assert len(new_state["documents"]) == 1

@patch("main.graph.core._storage")
@patch("main.graph.actions.Settings")
def test_execute_action_node_handles_finish(mock_settings_class, mock_storage_factory, test_settings):
    """Verify that a 'finish' decision correctly sets the 'done' flag."""
    # Mock storage to avoid GCS calls
    mock_storage = Mock()
    mock_storage_factory.return_value = mock_storage
    
    # Configure Settings mock to have proper allowlist
    mock_instance = MagicMock()
    mock_instance.allowed_hosts = test_settings.allowed_hosts or {"*"}
    mock_instance.checkpoint_every_step = False  # Disable checkpointing for test
    mock_instance.require_source_allowlist = MagicMock()
    mock_settings_class.return_value = mock_instance
    decision = AgentDecision(action="finish", reason="test")
    # Add run_id to the state
    initial_state: State = {"run_id": "test-run", "decision": decision.model_dump(), "step": 5}

    new_state = execute_action_node(initial_state)

    assert new_state["done"] is True
    assert "completion" in new_state
