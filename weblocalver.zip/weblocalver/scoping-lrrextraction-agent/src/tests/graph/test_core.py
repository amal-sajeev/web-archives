"""Tests for the core graph utilities and state management."""

import json
from unittest.mock import Mock, patch

import pytest

from main.graph.core import (
    State,
    _json_safe,
    _json_restore,
    _save_checkpoint,
    load_checkpoint,
)


def test_json_serialization_handles_bytes():
    """Verify that _json_safe and _json_restore can handle bytes in the state."""
    original_state: State = {
        "objective": "test",
        "fetched": [
            {"content": b"hello world"}
        ]
    }

    safe_state = _json_safe(original_state)
    
    # Check that bytes are encoded into a specific dictionary format
    assert isinstance(safe_state["fetched"][0]["content"], dict)
    assert "__bytes__" in safe_state["fetched"][0]["content"]

    # Check that the state can be serialized to JSON without error
    json_string = json.dumps(safe_state)
    deserialized_state = json.loads(json_string)

    restored_state = _json_restore(deserialized_state)
    
    # Check that the bytes are correctly restored
    assert restored_state["fetched"][0]["content"] == b"hello world"
    assert restored_state["objective"] == "test"

@patch("main.graph.core._storage")
def test_save_checkpoint(mock_storage_factory, test_settings):
    """Verify that _save_checkpoint writes to the correct path."""
    mock_storage = Mock()
    mock_storage_factory.return_value = mock_storage
    
    # Enable checkpointing for this test
    settings = test_settings.model_copy(update={"checkpoint_every_step": True})
    test_state: State = {"run_id": "test-run-123", "step": 1}

    _save_checkpoint(test_state, settings)

    # Verify that the storage's write method was called with the correct path
    mock_storage.write.assert_called_once()
    call_args = mock_storage.write.call_args[0]
    assert call_args[0] == "checkpoints/test-run-123.json"

@patch("main.graph.core._storage")
def test_save_checkpoint_respects_setting(mock_storage_factory, test_settings):
    """Verify that checkpointing is skipped if the setting is false."""
    mock_storage = Mock()
    mock_storage_factory.return_value = mock_storage
    
    # Set checkpointing to false - create a modified copy of test_settings
    settings = test_settings.model_copy(update={"checkpoint_every_step": False})
    test_state: State = {"run_id": "test-run-456", "step": 1}

    _save_checkpoint(test_state, settings)

    # Verify that the write method was NOT called
    mock_storage.write.assert_not_called()

@patch("main.graph.core.Settings")
@patch("main.graph.core._storage")
def test_load_checkpoint(mock_storage_factory, mock_settings_class, test_settings):
    """Verify that loading a checkpoint works correctly."""
    mock_settings_class.return_value = test_settings
    mock_storage = Mock()
    mock_storage_factory.return_value = mock_storage

    # Create dummy checkpoint data
    checkpoint_data = {"run_id": "test-run-789", "step": 5}
    mock_storage.read.return_value = json.dumps(checkpoint_data)

    state = load_checkpoint("test-run-789")

    mock_storage.read.assert_called_once_with("checkpoints/test-run-789.json")
    assert state["run_id"] == "test-run-789"
    assert state["step"] == 5
    assert state["resume"] is True # Check that the resume flag is added

@patch("main.graph.core.Settings")
@patch("main.graph.core._storage")
def test_load_checkpoint_file_not_found(mock_storage_factory, mock_settings_class, test_settings):
    """Verify that a FileNotFoundError is raised for a missing checkpoint."""
    mock_settings_class.return_value = test_settings
    mock_storage = Mock()
    mock_storage_factory.return_value = mock_storage
    mock_storage.read.return_value = None # Simulate file not found

    with pytest.raises(FileNotFoundError):
        load_checkpoint("non-existent-run")
