"""Tests for graph actions module."""

import pytest
from unittest.mock import patch, MagicMock
from main.graph.actions import execute_action_node


@patch("main.graph.actions._save_checkpoint")
@patch("main.graph.actions._completion")
@patch("main.graph.actions.Settings")
def test_execute_action_finish(MockSettings, mock_completion, mock_save_checkpoint):
    """Test execute_action_node with finish action."""
    settings = MockSettings.return_value
    settings.require_source_allowlist.return_value = None
    
    mock_completion.return_value.model_dump.return_value = {"documents": []}
    
    state = {
        "run_id": "run-test",
        "decision": {"action": "finish", "target": None, "reason": "Done", "strategy_change": None},
        "step": 5,
        "history": [],
        "fetched": [],
        "documents": [],
        "outputs": [],
        "candidates": [],
        "frontier": [],
        "errors": [],
    }
    
    result = execute_action_node(state)
    assert result["done"] is True
    assert result["step"] == 6


@patch("main.graph.actions._save_checkpoint")
@patch("main.graph.actions.Settings")
def test_execute_action_reconsider(MockSettings, mock_save_checkpoint):
    """Test execute_action_node with reconsider action."""
    settings = MockSettings.return_value
    settings.require_source_allowlist.return_value = None
    
    state = {
        "run_id": "run-test",
        "decision": {
            "action": "reconsider",
            "target": None,
            "reason": "Try different strategy",
            "strategy_change": "Use alternative discovery"
        },
        "step": 3,
        "history": [],
        "memory": {"successful_strategies": []},
        "fetched": [],
        "documents": [],
        "candidates": [],
        "frontier": [],
        "errors": [],
    }
    
    result = execute_action_node(state)
    assert result["step"] == 4
    assert "memory" in result


@patch("main.graph.actions._save_checkpoint")
@patch("main.graph.actions.Settings")
def test_execute_action_missing_target_for_extract(MockSettings, mock_save_checkpoint):
    """Test execute_action_node extract without target raises error."""
    settings = MockSettings.return_value
    settings.require_source_allowlist.return_value = None
    
    state = {
        "run_id": "run-test",
        "decision": {"action": "extract", "target": None, "reason": "Missing target", "strategy_change": None},
        "step": 0,
        "history": [],
        "fetched": [],
        "documents": [],
        "errors": [],
        "candidates": [],
        "frontier": [],
    }
    
    result = execute_action_node(state)
    assert "errors" in result
    assert result["step"] == 1


@patch("main.graph.actions._save_checkpoint")
@patch("main.graph.actions.Settings")
def test_execute_action_step_increment(MockSettings, mock_save_checkpoint):
    """Test that execute_action_node increments step counter."""
    settings = MockSettings.return_value
    settings.require_source_allowlist.return_value = None
    
    state = {
        "run_id": "run-test",
        "decision": {"action": "reconsider", "target": None, "reason": "Test", "strategy_change": None},
        "step": 10,
        "history": [],
        "memory": {"successful_strategies": []},
        "fetched": [],
        "documents": [],
        "candidates": [],
        "frontier": [],
        "errors": [],
    }
    
    result = execute_action_node(state)
    assert result["step"] == 11


@patch("main.graph.actions._save_checkpoint")
@patch("main.graph.actions.Settings")
def test_execute_action_history_tracking(MockSettings, mock_save_checkpoint):
    """Test that action history is tracked."""
    settings = MockSettings.return_value
    settings.require_source_allowlist.return_value = None
    
    state = {
        "run_id": "run-test",
        "decision": {"action": "reconsider", "target": None, "reason": "First", "strategy_change": None},
        "step": 0,
        "history": [],
        "memory": {"successful_strategies": []},
        "fetched": [],
        "documents": [],
        "candidates": [],
        "frontier": [],
        "errors": [],
    }
    
    result = execute_action_node(state)
    assert "history" in result
    assert len(result["history"]) > 0
    assert result["history"][0]["action"] == "reconsider"


@patch("main.graph.actions._save_checkpoint")
@patch("main.graph.actions.Settings")
def test_execute_action_history_limit(MockSettings, mock_save_checkpoint):
    """Test that history is limited to 100 entries."""
    settings = MockSettings.return_value
    settings.require_source_allowlist.return_value = None
    
    # Create state with >100 history entries
    long_history = [{"step": i, "action": "reconsider", "target": None, "reason": f"step-{i}"} for i in range(150)]
    
    state = {
        "run_id": "run-test",
        "decision": {"action": "reconsider", "target": None, "reason": "Test", "strategy_change": None},
        "step": 150,
        "history": long_history,
        "memory": {"successful_strategies": []},
        "fetched": [],
        "documents": [],
        "candidates": [],
        "frontier": [],
        "errors": [],
    }
    
    result = execute_action_node(state)
    # History should be trimmed to 100
    assert len(result["history"]) <= 101  # 100 old + 1 new

