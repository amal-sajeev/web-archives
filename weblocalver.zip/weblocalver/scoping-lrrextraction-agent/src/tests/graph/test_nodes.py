"""Tests for the primary graph nodes."""

from unittest.mock import MagicMock, patch
import pytest

from main.graph.nodes import (
    plan_node,
    bootstrap_node,
    agent_decide_node,
    route_after_action,
)
from main.graph.core import State, Settings
from main.models import Plan, AgentDecision

@patch("main.graph.nodes.llm")
def test_plan_node(mock_llm):
    """Verify that the plan_node correctly invokes the LLM and structures the state."""
    mock_llm_instance = MagicMock()
    mock_plan = Plan(
        strategy="Test Strategy",
        plan=["Step 1"],
        discovery_terms=["term1"],
        seed_urls=["http://example.com"], # Provide the required seed_urls
        reasoning="Mocked reasoning.",
        completion_contract=[]
    )
    mock_llm_instance.with_structured_output.return_value.invoke.return_value = mock_plan
    mock_llm.return_value = mock_llm_instance

    initial_state: State = {"run_id": "test-run", "seeds": ["http://example.com"]}
    
    new_state = plan_node(initial_state)

    assert new_state["plan"]["strategy"] == "Test Strategy"

@patch("main.graph.nodes._require_settings")
def test_bootstrap_node(mock_require_settings, test_settings):
    """Verify the bootstrap node correctly initializes the frontier."""
    # IMPORTANT: Override the allowlist for this specific test
    test_settings.source_allowlist = "example.com"
    mock_require_settings.return_value = test_settings
    
    initial_state: State = {"seeds": ["http://example.com/a"]}
    new_state = bootstrap_node(initial_state)
    assert len(new_state["frontier"]) == 1

@patch("main.graph.nodes.llm")
def test_agent_decide_node_chooses_finish_when_done(mock_llm, monkeypatch, test_settings):
    """Verify the agent decides to finish when the completion condition is met."""
    monkeypatch.setattr(Settings, "__new__", lambda cls: test_settings)
    completed_state: State = {"run_id": "test-run", "step": 5, "outputs": [{"validation": {"status": "accept"}}]}
    new_state = agent_decide_node(completed_state)
    assert new_state["decision"]["action"] == "finish"


def test_route_after_action(monkeypatch, test_settings):
    """Verify the routing logic after an action."""
    monkeypatch.setattr(Settings, "__new__", lambda cls: test_settings)
    assert route_after_action({"done": True}) == "end"
    assert route_after_action({"step": 5}) == "continue"
