"""Tests for the graph persistence node."""

from unittest.mock import MagicMock, patch
import json
import pytest

from main.graph.persistence import persist_node
from main.graph.core import State, Settings

@patch("main.graph.persistence.GCSStorage")
@patch("main.graph.persistence._storage")
@patch("main.graph.persistence._load_registry")
def test_persist_node_writes_correct_files(mock_load_registry, mock_storage_factory, mock_gcs_storage, monkeypatch, test_settings):
    """Verify that the persistence node writes the manifest, registry, and other key files."""
    monkeypatch.setattr(Settings, "__new__", lambda cls: test_settings)

    mock_storage = {}
    def write_to_mock(key, content, *, if_absent=False):
        mock_storage[key] = content

    mock_storage_instance = MagicMock()
    mock_storage_instance.write.side_effect = write_to_mock
    mock_storage_factory.return_value = mock_storage_instance
    mock_load_registry.return_value = {"documents": {}}

    initial_state: State = {
        "run_id": "test-run-persist",
        "step": 5,
        "outputs": [
            {
                "validation": {"status": "accept"},
                "identity": {"title": "Test Doc", "publisher": "Test Publisher"},
                "source_url": "http://example.com",
                "canonical_url": "http://example.com/",
                "raw_text": "This is the raw text content.", # Add missing raw_text
                "raw_sha256": "abc",
                "markdown_sha256": "def",
                "markdown": "# Test Doc Content",
            }
        ],
        "memory": {},
    }

    final_state = persist_node(initial_state)

    assert final_state["done"] is True

    assert "registry.json" in mock_storage
    assert "manifests/test-run-persist.json" in mock_storage
    assert "agent_memory.json" in mock_storage
    assert any(".md" in key for key in mock_storage.keys())
