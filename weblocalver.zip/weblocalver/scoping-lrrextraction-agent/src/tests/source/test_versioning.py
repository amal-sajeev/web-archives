"""Tests for the source versioning logic."""

from main.models import TemporalState
from main.source.versioning import extract_dates, resolve_version


def test_resolve_version_future_effective():
    """Test that a document with a future effective date is identified correctly."""
    text = "This rule will be effective from January 1, 2099."
    resolution = resolve_version("doc1", "http://example.com", text)
    assert resolution.temporal_state == TemporalState.FUTURE_EFFECTIVE


def test_resolve_version_superseded():
    """Test that a document with superseding language is identified."""
    text = "This rule is superseded by rule 123."
    resolution = resolve_version("doc2", "http://example.com/old", text)
    assert resolution.temporal_state == TemporalState.SUPERSEDED


def test_resolve_version_current_with_enough_evidence():
    """Test that a URL with /current/ and a recent date is marked as CURRENT."""
    text = "This rule was last updated on October 1, 2026."
    resolution = resolve_version("doc3", "http://example.com/current/rule", text)
    assert resolution.temporal_state == TemporalState.UNKNOWN
    assert "URL contains /current/ path segment" in resolution.reasons
    assert any("insufficient evidence" in r for r in resolution.reasons)


def test_resolve_version_is_ambiguous_with_weak_evidence():
    """Test that only a /current/ URL results in an UNKNOWN (ambiguous) state."""
    text = "This is the text."
    resolution = resolve_version("doc4", "http://example.com/current/rule", text)
    assert resolution.temporal_state == TemporalState.UNKNOWN
    assert resolution.ambiguous is True
    assert any("insufficient evidence" in r for r in resolution.reasons)


def test_extract_dates():
    """Test the date extraction logic."""
    text = "Effective date: January 1, 2025. Published on: 2024-12-01."
    dates = extract_dates(text)
    assert dates["effective"][0] == "January 1, 2025"
    assert dates["issue"] == []
