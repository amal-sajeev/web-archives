"""Tests for source classification."""

import pytest
from main.source.classification import classify_source_deterministic
from main.models import SourceRole

def test_classify_source_deterministic_for_instrument():
    """Test that a rule URL is correctly identified as an instrument."""
    url = "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110"
    title = "FINRA Rule 3110"
    classification = classify_source_deterministic(url, title)
    assert classification.source_role == SourceRole.INSTRUMENT
    assert classification.operative_text is True

def test_classify_source_deterministic_for_guidance():
    """Test that a notice URL is classified as guidance."""
    url = "https://www.finra.org/rules-guidance/notices/24-02"
    title = "Regulatory Notice 24-02"
    classification = classify_source_deterministic(url, title)
    assert classification.source_role == SourceRole.AMENDMENT_NOTICE

def test_classify_source_deterministic_for_index():
    """Test that a rulebook URL is classified as an index."""
    url = "https://www.finra.org/rules-guidance/rulebooks"
    title = "FINRA Rulebook"
    classification = classify_source_deterministic(url, title)
    assert classification.source_role == SourceRole.INDEX
