"""Tests for the source graph."""

from main.source.graph import SourceGraph
from main.models import RelationshipType


def test_source_graph_add_and_get_edge():
    """Test adding an edge and retrieving it."""
    graph = SourceGraph()
    graph.add_edge("node1", "node2", "REFERENCES", evidence="Test link")
    edges = graph.edges()
    assert len(edges) == 1
    edge = edges[0]
    assert edge.relationship == "REFERENCES"


def test_graph_serialization():
    """Test that a graph can be converted to a dict and back."""
    graph = SourceGraph()
    graph.add_node("nodeA", metadata={"name": "A"})
    graph.add_edge("nodeA", "nodeB", "REFERENCES", confidence=0.9)

    graph_dict = graph.to_dict()
    rehydrated_graph = SourceGraph.from_dict(graph_dict)

    assert rehydrated_graph.edges()[0].relationship == "REFERENCES"
