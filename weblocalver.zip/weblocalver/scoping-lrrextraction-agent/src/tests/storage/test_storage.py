"""Tests for the storage classes."""

from unittest.mock import MagicMock, patch
import tempfile
from pathlib import Path

from main.storage.storage import GCSStorage, LocalStorage, _safe_key


@patch("google.cloud.storage.Client")
@patch("google.auth.default")
def test_gcs_storage_write(mock_auth, MockStorageClient):
    """Test the GCS write operation by mocking the GCS client."""
    mock_auth.return_value = (None, "test-project")
    mock_bucket = MagicMock()
    mock_blob = MagicMock()
    mock_bucket.name = "my-bucket"
    mock_blob.name = "my-prefix/path/to/object.json"
    MockStorageClient.return_value.bucket.return_value = mock_bucket
    mock_bucket.blob.return_value = mock_blob

    gcs = GCSStorage("my-bucket", prefix="my-prefix")
    key = "path/to/object.json"
    content = '{"key": "value"}'

    uri = gcs.write(key, content)

    expected_blob_name = "my-prefix/path/to/object.json"
    expected_uri = f"gs://my-bucket/{expected_blob_name}"

    mock_bucket.blob.assert_called_with(expected_blob_name)
    mock_blob.upload_from_string.assert_called_with(content, content_type="text/plain; charset=utf-8")
    assert uri == expected_uri


def test_safe_key_valid():
    """Test _safe_key with valid keys."""
    assert _safe_key("file.txt") == "file.txt"
    assert _safe_key("path/to/file.txt") == "path/to/file.txt"
    assert _safe_key("/leading/slash.txt") == "leading/slash.txt"


def test_safe_key_invalid_traversal():
    """Test _safe_key rejects path traversal."""
    import pytest
    with pytest.raises(ValueError, match="traversal"):
        _safe_key("../escape")
    with pytest.raises(ValueError, match="traversal"):
        _safe_key("path/../../escape")


def test_safe_key_empty():
    """Test _safe_key rejects empty keys."""
    import pytest
    with pytest.raises(ValueError):
        _safe_key("")
    with pytest.raises(ValueError):
        _safe_key("///")


def test_local_storage_write_read():
    """Test LocalStorage write and read operations."""
    with tempfile.TemporaryDirectory() as tmpdir:
        storage = LocalStorage(tmpdir)
        
        key = "test/file.txt"
        content = "Hello World"
        
        uri = storage.write(key, content)
        assert uri == str(Path(tmpdir) / key)
        
        read_content = storage.read(key)
        assert read_content == content


def test_local_storage_exists():
    """Test LocalStorage exists check."""
    with tempfile.TemporaryDirectory() as tmpdir:
        storage = LocalStorage(tmpdir)
        
        key = "test/file.txt"
        assert not storage.exists(key)
        
        storage.write(key, "content")
        assert storage.exists(key)


def test_local_storage_delete():
    """Test LocalStorage delete operation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        storage = LocalStorage(tmpdir)
        
        key = "test/file.txt"
        storage.write(key, "content")
        assert storage.exists(key)
        
        deleted = storage.delete(key)
        assert deleted is True
        assert not storage.exists(key)


def test_local_storage_write_if_absent():
    """Test LocalStorage write with if_absent flag."""
    with tempfile.TemporaryDirectory() as tmpdir:
        storage = LocalStorage(tmpdir)
        
        key = "test/file.txt"
        uri1 = storage.write(key, "first")
        uri2 = storage.write(key, "second", if_absent=True)
        
        # Second write should not have happened
        assert storage.read(key) == "first"


def test_local_storage_list_keys():
    """Test LocalStorage list_keys with prefix and suffix."""
    with tempfile.TemporaryDirectory() as tmpdir:
        storage = LocalStorage(tmpdir)
        
        storage.write("logs/2024-01-01.log", "data1")
        storage.write("logs/2024-01-02.log", "data2")
        storage.write("data/output.json", "data3")
        
        log_files = storage.list_keys(prefix="logs/", suffix=".log")
        assert len(log_files) == 2
        
        json_files = storage.list_keys(suffix=".json")
        assert len(json_files) == 1
