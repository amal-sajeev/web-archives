"""Tests for the query service."""

from unittest.mock import patch, MagicMock
import pytest

from main.services.query_service import run_query

# Note: We don't need to mock get_data_snapshot here because run_query
# passes the query directly to answer_query, which is what we are mocking.

@patch("main.services.query_service.answer_query")
def test_run_query_happy_path(mock_answer_query):
    """Test that run_query correctly calls the underlying answer_query function."""
    # Arrange: Set up mock return values
    mock_answer = {
        "answer": "This is the answer.",
        "passages": ["passage 1", "passage 2"]
    }
    mock_answer_query.return_value = mock_answer

    query_text = "What is the rule?"
    top_k = 5

    # Act: Call the function we are testing
    result = run_query(query_text, top_k)

    # Assert: Check that our mock was called and the result is correct
    mock_answer_query.assert_called_once_with(query_text, top_k=top_k)
    assert result == mock_answer
