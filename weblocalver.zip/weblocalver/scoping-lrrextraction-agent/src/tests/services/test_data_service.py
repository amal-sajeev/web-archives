"""Tests for the data service."""

from unittest.mock import patch
import pytest

from main.services.data_service import get_data_snapshot, find_record

@patch("main.services.data_service.get_live_data")
@patch("main.services.data_service.get_sample_data")
def test_get_data_snapshot_prefers_live_data(mock_get_sample_data, mock_get_live_data):
    """Test that get_data_snapshot returns live data when it is available."""
    mock_get_live_data.return_value = {"sources": [{"name": "Live Source"}]}
    mock_get_sample_data.return_value = {"sources": [{"name": "Sample Source"}]}

    data, mode = get_data_snapshot()

    assert mode == "live"
    assert data["sources"][0]["name"] == "Live Source"
    mock_get_live_data.assert_called_once()
    mock_get_sample_data.assert_not_called()

@patch("main.services.data_service.get_live_data")
@patch("main.services.data_service.get_sample_data")
def test_get_data_snapshot_falls_back_to_sample_data(mock_get_sample_data, mock_get_live_data):
    """Test that get_data_snapshot falls back to sample data when live is unavailable."""
    mock_get_live_data.return_value = None  # Simulate no live data
    mock_get_sample_data.return_value = {"sources": [{"name": "Sample Source"}]}

    data, mode = get_data_snapshot()

    assert mode == "sample"
    assert data["sources"][0]["name"] == "Sample Source"
    mock_get_live_data.assert_called_once()
    mock_get_sample_data.assert_called_once()

@patch("main.services.data_service.get_data_snapshot")
def test_find_record(mock_get_data_snapshot):
    """Test that find_record correctly finds an item in a collection."""
    mock_data = {
        "documents": [
            {"id": "doc1", "title": "Document 1"},
            {"id": "doc2", "title": "Document 2"},
        ]
    }
    mock_get_data_snapshot.return_value = (mock_data, "live")

    # Test finding an existing record
    found_record = find_record("documents", "id", "doc2")
    assert found_record is not None
    assert found_record["title"] == "Document 2"

    # Test not finding a record
    not_found_record = find_record("documents", "id", "doc3")
    assert not_found_record is None
