"""Tests for the run service."""
from unittest.mock import patch, MagicMock
import pytest

from main.services import run_service

def test_start_run():
    """Test that the start_run service function correctly calls the RUN_MANAGER."""
    with patch.object(run_service, 'RUN_MANAGER', MagicMock()) as mock_run_manager:
        seeds = ["https://example.com"]
        run_service.start_run(seeds=seeds, objective="Test", resume=None, request_id="123")
        mock_run_manager.start.assert_called_once()