"""Tests for the document service."""

from main.services.document_service import build_download_name


def test_build_download_name():
    """Test the logic for creating a consistent download filename."""
    expected_name = "finra-rule-3110.md"
    assert build_download_name("FINRA Rule 3110", "fallback.pdf") == expected_name
