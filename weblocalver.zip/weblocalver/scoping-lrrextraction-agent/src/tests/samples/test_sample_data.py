"""Tests for samples module."""

from main.samples.data import get_sample_data, _build_sample_data


def test_get_sample_data_structure():
    """Test sample data has required keys."""
    data = get_sample_data()
    assert isinstance(data, dict)
    assert "runs" in data
    assert "events" in data
    assert "sources" in data
    assert "documents" in data
    assert "graph" in data
    assert "review" in data


def test_get_sample_data_caching():
    """Test sample data is cached."""
    data1 = get_sample_data()
    data2 = get_sample_data()
    assert data1 is data2


def test_build_sample_data_returns_dict():
    """Test building sample data returns dict."""
    data = _build_sample_data()
    assert isinstance(data, dict)
    assert len(data) == 6
