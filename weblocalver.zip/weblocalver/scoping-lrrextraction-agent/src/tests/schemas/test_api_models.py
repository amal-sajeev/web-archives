"""Tests for schemas module."""

import pytest
from pydantic import ValidationError

from main.schemas.api_models import StartRunRequest, QueryRequest


def test_start_run_request_valid():
    """Test valid StartRunRequest."""
    req = StartRunRequest(urls=["https://example.com"])
    assert req.urls == ["https://example.com"]
    assert req.resume is None
    assert req.request_id is None


def test_start_run_request_with_all_fields():
    """Test StartRunRequest with all fields."""
    req = StartRunRequest(
        urls=["https://example.com"],
        resume="run-123",
        request_id="req-456"
    )
    assert req.resume == "run-123"
    assert req.request_id == "req-456"


def test_start_run_request_multiple_urls():
    """Test StartRunRequest with multiple URLs."""
    req = StartRunRequest(urls=["https://a.com", "https://b.com"])
    assert len(req.urls) == 2


def test_start_run_request_empty_urls():
    """Test StartRunRequest rejects empty URLs list."""
    with pytest.raises(ValidationError):
        StartRunRequest(urls=[])


def test_query_request_valid():
    """Test valid QueryRequest."""
    req = QueryRequest(query="test query")
    assert req.query == "test query"
    assert req.top_k == 6


def test_query_request_custom_top_k():
    """Test QueryRequest with custom top_k."""
    req = QueryRequest(query="test", top_k=10)
    assert req.top_k == 10


def test_query_request_top_k_bounds():
    """Test QueryRequest top_k validation."""
    with pytest.raises(ValidationError):
        QueryRequest(query="test", top_k=0)
    
    with pytest.raises(ValidationError):
        QueryRequest(query="test", top_k=21)


def test_query_request_empty_query():
    """Test QueryRequest rejects empty query."""
    with pytest.raises(ValidationError):
        QueryRequest(query="")
