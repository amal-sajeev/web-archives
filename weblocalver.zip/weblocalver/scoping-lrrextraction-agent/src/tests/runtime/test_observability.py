"""Tests for the observability and logging functions."""

from unittest.mock import patch, MagicMock
import pytest

from main.runtime.observability import event, timed, subscribe, unsubscribe

@patch("main.runtime.observability.human_logger.log")
def test_event_calls_human_logger(mock_log):
    """Test that calling event() correctly triggers the human_logger."""
    event("test_event", key="value")
    mock_log.assert_called_once()
    call_args, _ = mock_log.call_args
    payload = call_args[0]
    assert payload["event"] == "test_event"
    assert payload["key"] == "value"
    assert "ts" in payload

def test_timed_context_manager():
    """Test the @timed context manager for measuring execution time."""
    with patch("main.runtime.observability.event") as mock_event:
        with timed("my_timed_block", extra_field="extra_val"):
            # Simulate some work
            pass
        
        mock_event.assert_called_once()
        call_args, _ = mock_event.call_args
        assert call_args[0] == "my_timed_block"
        
        call_kwargs = mock_event.call_args[1]
        assert "duration_ms" in call_kwargs
        assert call_kwargs["extra_field"] == "extra_val"

def test_subscribe_and_unsubscribe():
    """Test that subscribers can be added and removed correctly."""
    mock_subscriber = MagicMock()
    
    # Subscribe and fire an event
    subscribe(mock_subscriber)
    with patch("main.runtime.observability.human_logger.log"):
        event("first_event")
    mock_subscriber.assert_called_once()

    # Unsubscribe and fire another event
    unsubscribe(mock_subscriber)
    with patch("main.runtime.observability.human_logger.log"):
        event("second_event")
    # The call count should still be 1, as the second event was not received
    mock_subscriber.assert_called_once() 
