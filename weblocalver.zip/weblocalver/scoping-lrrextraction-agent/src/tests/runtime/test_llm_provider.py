"""Tests for the LLM provider."""

from unittest.mock import patch

from main.config.settings import Settings
from main.runtime.llm_provider import build_llm


@patch("main.runtime.llm_provider.google.auth.default")
@patch("langchain_google_genai.ChatGoogleGenerativeAI")
def test_build_llm_uses_correct_model(mock_chat, mock_auth):
    """Test that the correct model (reasoning vs. standard) is selected."""
    settings = Settings()
    build_llm(settings, reasoning=False)
    call_kwargs = mock_chat.call_args.kwargs
    assert call_kwargs["model"] == settings.gemini_model

    build_llm(settings, reasoning=True)
    call_kwargs = mock_chat.call_args.kwargs
    assert call_kwargs["model"] == settings.gemini_reasoning_model
