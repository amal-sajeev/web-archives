"""Tests for the human-readable logger formatting."""


def test_human_logger_run_started(logger):
    """Test the formatting for the 'run_started' event."""
    payload = {
        "event": "run_started",
        "run_id": "run_123",
        "objective": "Test Objective",
        "output_dir": "/fake/dir",
    }
    message = logger._format_human("run_started", payload)
    assert "Run ID:" in message
    assert "run_123" in message
    assert "Objective:" in message
    assert "Test Objective" in message
    assert "/fake/dir" in message


def test_human_logger_run_complete(logger):
    """Test the formatting for the 'run_complete' event."""
    payload = {
        "event": "run_complete",
        "run_id": "run_456",
        "step": 10,
        "outputs": [],
        "output_dir": "/another/fake/dir",
    }
    message = logger._format_human("run_complete", payload)
    assert "Run ID:" in message
    assert "run_456" in message
    assert "Total Steps:" in message
    assert "10" in message
    assert "/another/fake/dir" in message
