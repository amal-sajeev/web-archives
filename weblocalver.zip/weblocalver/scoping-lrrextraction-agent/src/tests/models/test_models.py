"""Test the main models module to ensure all exports are valid."""

def test_models_py_imports():
    """
    This test ensures that all expected models can be imported from the main
    models.py file. This is a simple but effective way to ensure the package's
    public API is not broken by future changes.
    """
    try:
        from main.models.models import (
            AuthorityClass, CandidateSelection, CompletionAssessment, CorpusObject,
            DocumentIdentity, ExtractedDocument, FailureMemory, Plan, AgentDecision,
            AgentMemory, ValidationResult, SourceCandidate,
            DocumentVersion, EvidenceSpan, LegalAuthorityLevel, NodeType, RagChunk, Relationship,
            RelationshipType, RejectionReason,
            SectionNode, SourceAuthority, SourceClassification, SourceRole, SourceSnapshot,
            TemporalState, ValidationReport, VersionResolution,
        )
    except ImportError as e:
        # If any import fails, this test will fail, pointing to a broken dependency.
        assert False, f"Failed to import models from main.models.models: {e}"
