"""Tests for the main FastAPI application setup."""

from fastapi.testclient import TestClient
from main.app import app

client = TestClient(app)


def test_read_main():
    """Test that the main UI page loads correctly."""
    response = client.get("/lrr/ui/index.html")
    assert response.status_code == 200
    assert "Regulatory Source Intelligence" in response.text


def test_api_docs_load():
    """Test that the OpenAPI docs are available."""
    response = client.get("/docs")
    assert response.status_code == 200
    assert "Swagger UI" in response.text


def test_get_mode():
    """Test the /lrr/system/mode endpoint."""
    response = client.get("/lrr/system/mode")
    assert response.status_code == 200
    assert "mode" in response.json()
