"""
This file provides shared fixtures for the test suite.
"""

import pytest

from main.config.settings import Settings
from main.runtime.human_logger import human_logger

@pytest.fixture(autouse=True)
def _default_test_env(monkeypatch):
    """Provide default Settings values required by CI and local pytest runs."""
    monkeypatch.setenv("APP_ENV", "test")
    monkeypatch.setenv("OUTPUT_DIR", "/tmp/test_output")
    monkeypatch.setenv("SOURCE_HOST_ALIASES", "")
    monkeypatch.setenv("SOURCE_ALLOWLIST", "*")
    monkeypatch.setenv("PROJECT_NAME", "test-project")
    monkeypatch.setenv("GOOGLE_CLOUD_PROJECT", "test-project")
    monkeypatch.setenv("PROJECT_LOCATION", "us-central1")
    monkeypatch.setenv("GOOGLE_CLOUD_LOCATION", "us-central1")
    monkeypatch.setenv("GOOGLE_GENAI_USE_VERTEXAI", "false")


@pytest.fixture(scope="session")
def test_settings() -> Settings:
    """
    Provides a valid, pre-configured Settings object for use in tests.
    This avoids all file/environment loading issues in the CI/CD environment.
    """
    return Settings(
        output_dir="/tmp/test_output",
        source_host_aliases="",
        source_allowlist="*",
        master_risk_definitions="dummy_path.json",
        manifest="dummy_manifest.json",
        google_genai_use_vertexai=False,
        gemini_model="test-model",
        gemini_reasoning_model="test-model",
        temperature=0.0,
        top_p=0.95,
        top_k=40,
        max_pages=10,
        max_bytes=60000000,
        max_discovery_depth=1,
        max_candidates_per_page=100,
        request_timeout_seconds=30,
        max_concurrent_fetches=1,
        max_retries=1,
        max_redirects=2,
        backoff_base_seconds=1.0,
        max_repair_attempts=1,
        max_agent_steps=10,
        checkpoint_every_step=False,
        min_extracted_chars=10,
        min_quality_score=0.9,
        min_authority_confidence=0.8,
        user_agent="test-agent",
        respect_robots_txt=True,
        enable_ocr=False,
        ocr_language="eng",
        ocr_dpi=200,
        enable_browser_rendering=False,
        browser_timeout_seconds=30,
        enable_source_snapshots=False,
        require_human_review_on_rejection=False,
        log_style="json",
        google_cloud_project="test-project",
    )


@pytest.fixture
def logger():
    """Return the shared human logger used by runtime tests."""
    return human_logger
