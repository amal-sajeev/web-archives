"""Tests for the path helper functions."""

from pathlib import Path
from main.helpers.paths import get_repo_root, get_src_root, get_ui_dir

def test_path_helpers_return_correct_types():
    """Verify that all path helpers return Path objects."""
    assert isinstance(get_repo_root(), Path)
    assert isinstance(get_src_root(), Path)
    assert isinstance(get_ui_dir(), Path)

def test_get_repo_root_structure():
    """
    Verify the basic structure assumption of get_repo_root.
    This test is a bit fragile by nature but confirms the basic assumption
    that this file lives at a certain depth from the project root.
    """
    # We expect this test file to be at .../src/tests/helpers/test_paths.py
    # The root should be 4 levels up.
    expected_parent_parts = Path(__file__).resolve().parts[:-4]
    actual_root_parts = get_repo_root().parts
    assert actual_root_parts == expected_parent_parts

def test_get_src_root_is_correct():
    """Verify that get_src_root points to the correct 'src' directory."""
    repo_root = get_repo_root()
    expected_src_root = repo_root / "src"
    assert get_src_root() == expected_src_root
    # A simple check to see if a known file exists, proving the path is likely correct
    assert (get_src_root() / "main" / "app.py").exists()

def test_get_ui_dir_is_correct():
    """Verify that get_ui_dir points to the correct 'ui' directory."""
    repo_root = get_repo_root()
    expected_ui_dir = repo_root / "src" / "ui"
    assert get_ui_dir() == expected_ui_dir
    # A simple check to see if a known file exists, proving the path is likely correct
    assert (get_ui_dir() / "index.html").exists()
