"""Tests for the URL validator helper."""

import pytest
from pathlib import Path
from unittest.mock import patch, mock_open

from main.helpers.url_validator import ApprovedURLValidator, get_validator

# A sample YAML content string to be used for mocking the file read.
SAMPLE_YAML_CONTENT = """
approved_urls:
  - url: https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110
    regulator: FINRA
    description: "FINRA Rule 3110"
  - url: https://www.sec.gov/cgi-bin/browse-edgar
    regulator: SEC
    description: "SEC EDGAR"
"""

@patch("builtins.open", new_callable=mock_open, read_data=SAMPLE_YAML_CONTENT)
@patch("pathlib.Path.exists")
def test_validator_loads_urls_correctly(mock_exists, mock_file):
    """Verify that the validator correctly loads and parses the YAML file."""
    mock_exists.return_value = True  # Pretend the file exists
    validator = ApprovedURLValidator()
    
    assert validator.is_approved("https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110") is True
    assert validator.is_approved("https://www.invalid-url.com") is False
    assert len(validator.list_approved_urls()) == 2

@patch("builtins.open", new_callable=mock_open, read_data=SAMPLE_YAML_CONTENT)
@patch("pathlib.Path.exists")
def test_get_approval_info(mock_exists, mock_file):
    """Verify that get_approval_info returns the correct metadata."""
    mock_exists.return_value = True
    validator = ApprovedURLValidator()

    info = validator.get_approval_info("https://www.sec.gov/cgi-bin/browse-edgar")
    assert info is not None
    assert info["regulator"] == "SEC"
    assert info["description"] == "SEC EDGAR"

    # Test for a URL that doesn't exist
    info_none = validator.get_approval_info("http://not-approved.com")
    assert info_none is None

@patch("builtins.open", new_callable=mock_open, read_data=SAMPLE_YAML_CONTENT)
@patch("pathlib.Path.exists")
def test_validate_urls_separates_correctly(mock_exists, mock_file):
    """Verify that validate_urls correctly separates approved and unapproved URLs."""
    mock_exists.return_value = True
    validator = ApprovedURLValidator()
    
    urls_to_test = [
        "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110",
        "http://unapproved.com",
        "https://www.sec.gov/cgi-bin/browse-edgar",
    ]

    approved, unapproved = validator.validate_urls(urls_to_test)

    assert len(approved) == 2
    assert len(unapproved) == 1
    assert "http://unapproved.com" in unapproved

@patch("builtins.open", new_callable=mock_open, read_data=SAMPLE_YAML_CONTENT)
@patch("pathlib.Path.exists")
def test_get_approved_regulators(mock_exists, mock_file):
    """Verify that get_approved_regulators groups URLs correctly."""
    mock_exists.return_value = True
    validator = ApprovedURLValidator()

    regulators = validator.get_approved_regulators()
    assert "FINRA" in regulators
    assert "SEC" in regulators
    assert len(regulators["FINRA"]) == 1

@patch("pathlib.Path.exists")
def test_file_not_found_error(mock_exists):
    """Verify that a FileNotFoundError is raised if the catalogue is missing."""
    mock_exists.return_value = False  # Pretend the file does not exist
    with pytest.raises(FileNotFoundError):
        ApprovedURLValidator()

# Test the singleton get_validator function
@patch("main.helpers.url_validator.ApprovedURLValidator")
def test_get_validator_is_singleton(MockValidator):
    """Verify that get_validator always returns the same instance."""
    # Reset the global validator for a clean test
    from main.helpers import url_validator
    url_validator._validator = None

    instance1 = get_validator()
    instance2 = get_validator()

    assert instance1 is instance2
    # Check that the underlying ApprovedURLValidator was only instantiated once
    MockValidator.assert_called_once()
