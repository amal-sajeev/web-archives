"""Tests for semantic integrity validation."""

import pytest
from main.integrity.semantic import (
    _extract_numbers,
    _extract_dates,
    _extract_modals,
    _extract_negations,
    _extract_cross_refs,
    validate_semantic_integrity,
)

def test_extract_numbers():
    text = "The price is 1,234.56 and the quantity is 789."
    numbers = _extract_numbers(text)
    assert set(numbers) == {"1,234.56", "789"}

def test_extract_dates():
    text = "This was due on 10/25/2023 and also on Nov 1, 2024."
    dates = _extract_dates(text)
    assert set(dates) == {"10/25/2023", "Nov 1, 2024"}

def test_extract_modals():
    text = "You must do this, and you shall do that. You may also do this other thing."
    modals = _extract_modals(text)
    assert modals["must"] == 1
    assert modals["shall"] == 1
    assert modals["may"] == 1

def test_extract_negations():
    text = "This is not allowed, unless you have permission. No exceptions."
    negations = _extract_negations(text)
    assert negations["not"] == 1
    assert negations["unless"] == 1
    assert negations["no"] == 1

def test_extract_cross_refs():
    text = "Please see Rule 123 and also Form 4-A for more details."
    refs = _extract_cross_refs(text)
    assert set(refs) == {"Rule 123", "Form 4-A"}

def test_validate_semantic_integrity_perfect_match():
    """Verify that identical texts result in perfect fidelity scores."""
    text = "The price is $100. The date is 2024-01-01. You must comply. See Rule 100."
    result = validate_semantic_integrity(text, text)
    
    assert result["numeric_fidelity"] == 1.0
    assert result["date_fidelity"] == 1.0
    assert result["modal_fidelity"] == 1.0
    assert result["negation_fidelity"] == 1.0
    assert result["cross_reference_fidelity"] == 1.0
    assert not result["issues"]

def test_validate_semantic_integrity_detects_mismatches():
    """Verify that differences in semantic features are caught and lower scores."""
    raw_text = "The price is 100. You must not do this. See Section 5."
    rendered_text = "The price is 200. You must do this. See Section 6."
    
    result = validate_semantic_integrity(raw_text, rendered_text)

    assert result["numeric_fidelity"] == 0.0
    assert result["negation_fidelity"] == 0.0 # 'not' was removed
    assert result["cross_reference_fidelity"] == 0.0 # Section 5 became Section 6
    assert len(result["issues"]) > 0
