"""Tests for document structural integrity validation."""

import pytest
from unittest.mock import MagicMock, patch

from main.integrity.structure import (
    validate_tree_completeness,
    validate_numbering_continuity,
    detect_tail_truncation,
    validate_structure,
)

# Mock Node and IR classes for testing
class MockNode:
    def __init__(self, node_id, parent_id=None, label="", text="", children=None, node_type="section", ordinal=0):
        self.node_id = node_id
        self.parent_id = parent_id
        self.label = label
        self.text = text
        self.children = children if children is not None else []
        self.node_type = node_type
        self.ordinal = ordinal

class MockIR:
    def __init__(self, nodes, raw_text=""):
        self.nodes = nodes
        self.raw_text = raw_text

    def render_markdown(self):
        return self.raw_text


def test_validate_tree_completeness_finds_orphans():
    """Verify that nodes with missing parents are correctly identified."""
    nodes = [MockNode("child", parent_id="missing_parent")]
    ir = MockIR(nodes)
    result = validate_tree_completeness(ir)
    assert result["orphaned"] == 1
    assert "orphaned nodes" in result["issues"][0]

def test_validate_tree_completeness_finds_duplicates():
    """Verify that nodes with duplicate labels are identified."""
    nodes = [MockNode("1", label="(a)"), MockNode("2", label="(a)")]
    ir = MockIR(nodes)
    result = validate_tree_completeness(ir)
    assert result["duplicates"] == 1


def test_validate_numbering_continuity_finds_gaps():
    """Verify that gaps in numbered or lettered sequences are found."""
    nodes = [
        MockNode("1", parent_id="root", label="(1)", ordinal=1),
        MockNode("2", parent_id="root", label="(3)", ordinal=2), # Gap here
        MockNode("3", parent_id="root", label="(a)", ordinal=3),
        MockNode("4", parent_id="root", label="(c)", ordinal=4), # Gap here
    ]
    ir = MockIR(nodes)
    result = validate_numbering_continuity(ir)
    assert len(result["issues"]) == 2
    assert "numbering gap: 1 -> 3" in result["issues"][0]
    assert "letter gap: (a) -> (c)" in result["issues"][1]

def test_detect_tail_truncation_flags_abrupt_endings():
    """Verify that text ending without proper punctuation is flagged."""
    # Provide a valid node so the function can proceed to the punctuation check
    ir = MockIR([MockNode("1", text="This text just stops")], raw_text="This text just stops")
    result = detect_tail_truncation("This text just stops", ir)
    assert result["truncated"] is True
    assert "does not end with expected terminal punctuation" in result["issues"][0]

def test_detect_tail_truncation_passes_good_text():
    """Verify that well-formed text passes the tail truncation check."""
    text = "This is a complete sentence."
    ir = MockIR([MockNode("1", text=text)], raw_text=text)
    result = detect_tail_truncation(text, ir)
    assert result["truncated"] is False

@patch("main.integrity.structure.validate_tree_completeness")
@patch("main.integrity.structure.validate_numbering_continuity")
@patch("main.integrity.structure.detect_tail_truncation")
def test_validate_structure_aggregates_results(mock_tail, mock_numbering, mock_tree):
    """Verify that the main validation function calls and aggregates all checks."""
    mock_tree.return_value = {"issues": ["tree issue"]}
    mock_numbering.return_value = {"issues": ["numbering issue"]}
    mock_tail.return_value = {"issues": ["tail issue"], "truncated": True}

    ir = MockIR([], raw_text="")
    result = validate_structure(ir)

    assert len(result["issues"]) == 3
    assert result["pass"] is False
    mock_tree.assert_called_once_with(ir)
    mock_numbering.assert_called_once_with(ir, None)
    mock_tail.assert_called_once_with(ir.raw_text, ir)
