from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from main.utils import gcs_utils


def _mock_blob(name: str = "folder/file.txt", *, exists_result: bool = True, text: str = "hello", data: bytes = b"hello"):
    blob = MagicMock()
    blob.name = name
    blob.exists.return_value = exists_result
    blob.download_as_text.return_value = text
    blob.download_as_bytes.return_value = data
    blob.download_to_filename = MagicMock()
    blob.upload_from_string = MagicMock()
    return blob


def test_normalize_blob_path_valid_plain_and_gs_path():
    assert gcs_utils._normalize_blob_path("  folder/file.txt  ", bucket_name="demo-bucket") == "folder/file.txt"
    assert gcs_utils._normalize_blob_path("gs://demo-bucket/folder/file.txt", bucket_name="demo-bucket") == "folder/file.txt"
    assert gcs_utils._normalize_blob_path("folder//file.txt") == "folder/file.txt"


def test_normalize_blob_path_rejects_missing_invalid_paths():
    with pytest.raises(ValueError, match="required"):
        gcs_utils._normalize_blob_path("   ")

    with pytest.raises(ValueError, match="Invalid GCS path"):
        gcs_utils._normalize_blob_path("../evil.txt")

    with pytest.raises(ValueError, match="Invalid GCS path"):
        gcs_utils._normalize_blob_path("folder/../file.txt")

    with pytest.raises(ValueError, match="Invalid GCS path"):
        gcs_utils._normalize_blob_path("../../secret.txt")

    # These are valid relative paths under the current implementation.
    assert gcs_utils._normalize_blob_path("./nested/file.txt") == "nested/file.txt"
    assert gcs_utils._normalize_blob_path("folder/child.txt") == "folder/child.txt"


@patch("main.utils.gcs_utils.Settings")
def test_get_gcs_bucket_success(mock_settings):
    mock_settings.return_value.gcs_bucket = "demo-bucket"
    assert gcs_utils.get_gcs_bucket() == "demo-bucket"


@patch("main.utils.gcs_utils.Settings")
def test_get_gcs_bucket_missing_raises(mock_settings):
    mock_settings.return_value.gcs_bucket = "   "
    with pytest.raises(ValueError, match="GCS bucket is not configured"):
        gcs_utils.get_gcs_bucket()


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_get_gcs_file_bytes_success(mock_bucket_name, mock_storage_client):
    blob = _mock_blob(name="folder/file.txt", data=b"abc")
    client = MagicMock()
    client.bucket.return_value.blob.return_value = blob
    mock_storage_client.return_value = client

    data, normalized = gcs_utils.get_gcs_file_bytes("gs://demo-bucket/folder/file.txt")

    assert data == b"abc"
    assert normalized == "folder/file.txt"
    client.bucket.return_value.blob.assert_called_with("folder/file.txt")


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_get_gcs_file_bytes_missing_raises(mock_bucket_name, mock_storage_client):
    blob = _mock_blob(name="folder/file.txt", exists_result=False)
    client = MagicMock()
    client.bucket.return_value.blob.return_value = blob
    mock_storage_client.return_value = client

    with pytest.raises(FileNotFoundError, match="GCS object not found"):
        gcs_utils.get_gcs_file_bytes("folder/file.txt")


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_list_gcs_files_filters_by_prefix_and_suffix(mock_bucket_name, mock_storage_client):
    blob1 = _mock_blob(name="folder/a.txt")
    blob2 = _mock_blob(name="folder/b.md")
    blob3 = _mock_blob(name="folder/c.txt")
    client = MagicMock()
    bucket = MagicMock()
    bucket.list_blobs.return_value = [blob1, blob2, blob3]
    client.bucket.return_value = bucket
    mock_storage_client.return_value = client

    result = gcs_utils.list_gcs_files(prefix="folder/", suffix=".txt")

    assert result == ["folder/a.txt", "folder/c.txt"]
    bucket.list_blobs.assert_called_with(prefix="folder")


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_read_gcs_text_success_and_missing(mock_bucket_name, mock_storage_client):
    blob = _mock_blob(name="folder/file.txt", text="payload")
    client = MagicMock()
    client.bucket.return_value.blob.return_value = blob
    mock_storage_client.return_value = client

    assert gcs_utils.read_gcs_text("folder/file.txt") == "payload"

    blob_missing = _mock_blob(name="folder/missing.txt", exists_result=False)
    client.bucket.return_value.blob.return_value = blob_missing
    with pytest.raises(FileNotFoundError, match="GCS object not found"):
        gcs_utils.read_gcs_text("folder/missing.txt")


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_download_gcs_file_to_local_success(mock_bucket_name, mock_storage_client, tmp_path):
    blob = _mock_blob(name="folder/file.txt", data=b"payload")
    client = MagicMock()
    client.bucket.return_value.blob.return_value = blob
    mock_storage_client.return_value = client

    target = gcs_utils.download_gcs_file_to_local("folder/file.txt", local_dir=tmp_path)

    assert target == (tmp_path / "folder" / "file.txt").resolve()
    blob.download_to_filename.assert_called_once_with(str(target))
    assert target.exists() is False or target.parent.exists() is True


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_download_gcs_file_to_local_missing_raises(mock_bucket_name, mock_storage_client, tmp_path):
    blob = _mock_blob(name="folder/missing.txt", exists_result=False)
    client = MagicMock()
    client.bucket.return_value.blob.return_value = blob
    mock_storage_client.return_value = client

    with pytest.raises(FileNotFoundError, match="GCS object not found"):
        gcs_utils.download_gcs_file_to_local("folder/missing.txt", local_dir=tmp_path)


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_upload_text_to_gcs_success(mock_bucket_name, mock_storage_client):
    blob = _mock_blob(name="folder/file.txt")
    client = MagicMock()
    client.bucket.return_value.blob.return_value = blob
    mock_storage_client.return_value = client

    uri = gcs_utils.upload_text_to_gcs("folder/file.txt", "hello", content_type="text/plain")

    assert uri == "gs://demo-bucket/folder/file.txt"
    blob.upload_from_string.assert_called_once_with("hello", content_type="text/plain")


@patch("main.utils.gcs_utils.storage.Client")
@patch("main.utils.gcs_utils.get_gcs_bucket", return_value="demo-bucket")
def test_blob_exists_true_and_false(mock_bucket_name, mock_storage_client):
    blob_true = _mock_blob(name="folder/file.txt", exists_result=True)
    blob_false = _mock_blob(name="folder/missing.txt", exists_result=False)
    client = MagicMock()
    client.bucket.return_value.blob.side_effect = [blob_true, blob_false]
    mock_storage_client.return_value = client

    assert gcs_utils.blob_exists("folder/file.txt") is True
    assert gcs_utils.blob_exists("folder/missing.txt") is False


@pytest.mark.parametrize(
    "file_name, expected",
    [
        ("report.csv", {"text/csv", "application/vnd.ms-excel"}),
        ("image.png", {"image/png"}),
        ("archive.bin", {"application/octet-stream"}),
        ("no_extension", {"application/octet-stream"}),
    ],
)
def test_guess_content_type(file_name, expected):
    assert gcs_utils.guess_content_type(file_name) in expected
