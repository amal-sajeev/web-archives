"""Tests for Phase 3: Mandate Generation and Risk Type Mapping."""

from unittest.mock import patch, MagicMock
import pytest
import json

from main.risk_context.phase_3_mandate_generation import (
    _log_info,
    _read_gcs_file,
    _write_gcs_file,
    _load_local_json_prompt,
    _clean_llm_json_response,
    _flatten_to_csv_data,
    execute_phase_3,
)


def test_clean_llm_json_response_with_markdown():
    """Test cleaning LLM response with markdown code fences."""
    response = '```json\n{"key": "value"}\n```'
    result = _clean_llm_json_response(response)
    assert result == '{"key": "value"}'


def test_clean_llm_json_response_bare_json():
    """Test cleaning bare JSON response without markdown."""
    response = '{"key": "value"}'
    result = _clean_llm_json_response(response)
    assert result == '{"key": "value"}'


def test_clean_llm_json_response_nested_object():
    """Test cleaning response with nested JSON structure."""
    response = 'Some text before {"nested": {"value": 123}} and after'
    result = _clean_llm_json_response(response)
    assert result == '{"nested": {"value": 123}}'


def test_flatten_to_csv_data_single_mandate():
    """Test flattening enriched data to CSV format."""
    enriched = [
        {
            "Risk Name": "Risk ABC",
            "Mandates": [
                {
                    "Regulatory Mandate": "Mandate 1",
                    "Confidence Score": 0.95,
                    "AI Rationale": "Rationale text",
                    "Evidence": [
                        {
                            "source_url": "https://example.com",
                            "evidence_text": "Evidence snippet",
                            "deep_link": "https://example.com#section",
                        }
                    ],
                }
            ],
        }
    ]
    
    result = _flatten_to_csv_data(enriched)
    
    assert len(result) == 1
    assert result[0]["Risk Name"] == "Risk ABC"
    assert result[0]["Regulatory Mandate"] == "Mandate 1"
    assert result[0]["source_url"] == "https://example.com"


def test_flatten_to_csv_data_multiple_evidence():
    """Test flattening with multiple evidence items per mandate."""
    enriched = [
        {
            "Risk Name": "Risk XYZ",
            "Mandates": [
                {
                    "Regulatory Mandate": "Mandate A",
                    "Confidence Score": 0.9,
                    "AI Rationale": "Reason A",
                    "Evidence": [
                        {
                            "source_url": "https://source1.com",
                            "evidence_text": "Evidence 1",
                            "deep_link": "https://source1.com#a",
                        },
                        {
                            "source_url": "https://source2.com",
                            "evidence_text": "Evidence 2",
                            "deep_link": "https://source2.com#b",
                        },
                    ],
                }
            ],
        }
    ]
    
    result = _flatten_to_csv_data(enriched)
    
    assert len(result) == 2
    assert result[0]["source_url"] == "https://source1.com"
    assert result[1]["source_url"] == "https://source2.com"


def test_log_info():
    """Test the log_info helper function."""
    with patch("main.risk_context.phase_3_mandate_generation.event") as mock_event:
        _log_info("Test Phase 3 message")
        mock_event.assert_called_once_with("phase_log", message="Test Phase 3 message")


def test_read_gcs_file_success():
    """Test successful reading of GCS file."""
    with patch("main.risk_context.phase_3_mandate_generation.storage.Client") as mock_client:
        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_client.return_value.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob
        mock_blob.exists.return_value = True
        mock_blob.download_as_text.return_value = "File content"
        
        result = _read_gcs_file("test-bucket", "path/to/file.md")
        
        assert result == "File content"


def test_read_gcs_file_not_found():
    """Test GCS file not found error."""
    with patch("main.risk_context.phase_3_mandate_generation.storage.Client") as mock_client:
        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_client.return_value.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob
        mock_blob.exists.return_value = False
        
        with pytest.raises(FileNotFoundError):
            _read_gcs_file("test-bucket", "missing.md")


def test_write_gcs_file_success():
    """Test successful writing to GCS file."""
    with patch("main.risk_context.phase_3_mandate_generation.storage.Client") as mock_client:
        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_client.return_value.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob
        
        _write_gcs_file("test-bucket", "path/to/output.csv", "csv,data", "text/csv")
        
        mock_blob.upload_from_string.assert_called_once_with(
            "csv,data", content_type="text/csv"
        )


def test_load_local_json_prompt_success(tmp_path):
    """Test successful loading of local JSON prompt."""
    prompt_file = tmp_path / "prompt.json"
    prompt_data = {"prompt_instructions": "Do this task"}
    prompt_file.write_text(json.dumps(prompt_data))
    
    result = _load_local_json_prompt(prompt_file)
    
    assert result == prompt_data


def test_load_local_json_prompt_file_not_found():
    """Test file not found error."""
    with pytest.raises(FileNotFoundError):
        _load_local_json_prompt("/nonexistent/path/prompt.json")


def test_load_local_json_prompt_invalid_json(tmp_path):
    """Test invalid JSON error."""
    prompt_file = tmp_path / "bad_prompt.json"
    prompt_file.write_text("{ invalid json }")
    
    with pytest.raises(ValueError, match="Invalid JSON"):
        _load_local_json_prompt(prompt_file)


@patch("main.risk_context.phase_3_mandate_generation.build_llm")
@patch("main.risk_context.phase_3_mandate_generation.Settings")
def test_execute_phase_3_no_request_id(mock_settings, mock_build_llm):
    """Test Phase 3 with missing request_id."""
    mock_settings_inst = MagicMock()
    mock_settings.return_value = mock_settings_inst
    
    execute_phase_3(request_id="")
    
    # Should return early without processing


@patch("main.risk_context.phase_3_mandate_generation._read_gcs_file")
@patch("main.risk_context.phase_3_mandate_generation._load_local_json_prompt")
@patch("main.risk_context.phase_3_mandate_generation.build_llm")
@patch("main.risk_context.phase_3_mandate_generation.Settings")
def test_execute_phase_3_missing_prompt(mock_settings, mock_build_llm, mock_load_prompt, mock_read_gcs):
    """Test Phase 3 with missing prompt file."""
    mock_settings_inst = MagicMock()
    mock_settings_inst.gcs_bucket = "bucket"
    mock_settings_inst.gcs_prefix = "prefix"
    mock_settings.return_value = mock_settings_inst
    
    mock_read_gcs.return_value = "Source document"
    mock_load_prompt.side_effect = FileNotFoundError("Prompt not found")
    
    execute_phase_3(request_id="req123")
    
    # Should handle error gracefully
