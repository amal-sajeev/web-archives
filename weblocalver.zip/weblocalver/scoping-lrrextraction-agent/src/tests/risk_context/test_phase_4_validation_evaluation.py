"""Tests for Phase 4: Validation and Evaluation."""

from unittest.mock import patch
import pytest

from main.risk_context.phase_4_validation_evaluation import (
    _log_info,
    execute_phase_4,
)


def test_log_info():
    """Test the log_info helper function."""
    with patch("main.risk_context.phase_4_validation_evaluation.event") as mock_event:
        _log_info("Test Phase 4 message")
        mock_event.assert_called_once_with("phase_log", message="Test Phase 4 message")


def test_execute_phase_4_not_implemented():
    """Test that Phase 4 execution completes without error (logic not yet implemented)."""
    with patch("main.risk_context.phase_4_validation_evaluation.event") as mock_event:
        execute_phase_4("test-request-id")
        
        # Should call event with start and end messages
        assert mock_event.call_count >= 2


def test_execute_phase_4_logs_info():
    """Test that Phase 4 execution logs the expected messages."""
    with patch("main.risk_context.phase_4_validation_evaluation.event") as mock_event:
        execute_phase_4("req-456")
        
        # Verify that start and end messages are logged
        calls = mock_event.call_args_list
        start_msg = calls[0][1]["message"] if calls else ""
        end_msg = calls[-1][1]["message"] if len(calls) > 1 else ""
        
        assert "Phase 4" in start_msg
        assert "Phase 4" in end_msg
