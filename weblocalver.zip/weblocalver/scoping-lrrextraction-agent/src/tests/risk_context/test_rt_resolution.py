"""Tests for Phase 2: Risk Type Context Resolution."""

from unittest.mock import patch, MagicMock
import pytest

from main.risk_context.rt_resolution import (
    _log_info,
    _download_gcs_json,
    _build_active_risk_manifest,
    execute_phase_2,
    PHASE_3_PERSISTED_STORE,
)


def test_download_gcs_json_success():
    """Test successful download of JSON from GCS."""
    expected_data = [{"id": "risk1", "name": "Risk One"}]
    
    with patch("main.risk_context.rt_resolution.storage.Client") as mock_client:
        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_client.return_value.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob
        mock_blob.exists.return_value = True
        mock_blob.download_as_text.return_value = '{"id": "risk1", "name": "Risk One"}'
        
        result = _download_gcs_json("test-bucket", "test/path.json")
        
        assert result == {"id": "risk1", "name": "Risk One"}
        mock_client.return_value.bucket.assert_called_once_with("test-bucket")
        mock_bucket.blob.assert_called_once_with("test/path.json")


def test_download_gcs_json_file_not_found():
    """Test GCS file not found error."""
    with patch("main.risk_context.rt_resolution.storage.Client") as mock_client:
        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_client.return_value.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob
        mock_blob.exists.return_value = False
        
        with pytest.raises(FileNotFoundError):
            _download_gcs_json("test-bucket", "nonexistent.json")


def test_build_active_risk_manifest_single_risk():
    """Test extracting active risk codes from manifest."""
    inbound_data = [
        {
            "plan_item_number": "1",
            "search_combination": {"UoT Risk Type": "R123 - Risk Title"},
        }
    ]
    
    result = _build_active_risk_manifest(inbound_data)
    
    assert "R123" in result
    assert len(result) == 1


def test_build_active_risk_manifest_multiple_risks():
    """Test extracting multiple unique risk codes."""
    inbound_data = [
        {"plan_item_number": "1", "search_combination": {"UoT Risk Type": "R123 - Risk A"}},
        {"plan_item_number": "2", "search_combination": {"UoT Risk Type": "R456 - Risk B"}},
        {"plan_item_number": "3", "search_combination": {"UoT Risk Type": "R123 - Risk A"}},  # Duplicate
    ]
    
    result = _build_active_risk_manifest(inbound_data)
    
    assert result == {"R123", "R456"}


def test_build_active_risk_manifest_missing_key():
    """Test handling of missing required key."""
    inbound_data = [
        {"plan_item_number": "1", "search_combination": {}},  # Missing 'UoT Risk Type'
        {"plan_item_number": "2", "search_combination": {"UoT Risk Type": "R123"}},
    ]
    
    result = _build_active_risk_manifest(inbound_data)
    
    assert result == {"R123"}


def test_log_info():
    """Test the log_info helper function."""
    with patch("main.risk_context.rt_resolution.event") as mock_event:
        _log_info("Test message")
        mock_event.assert_called_once_with("phase_log", message="Test message")


@patch("main.risk_context.rt_resolution.Settings")
@patch("main.risk_context.rt_resolution._download_gcs_json")
def test_execute_phase_2_success(mock_download, mock_settings):
    """Test successful Phase 2 execution."""
    mock_settings_inst = MagicMock()
    mock_settings_inst.gcs_bucket = "test-bucket"
    mock_settings_inst.gcs_prefix = "test-prefix"
    mock_settings_inst.manifest = "manifest.json"
    mock_settings_inst.master_risk_definitions = "definitions.json"
    mock_settings.return_value = mock_settings_inst
    
    mock_download.side_effect = [
        [{"plan_item_number": "1", "search_combination": {"UoT Risk Type": "R123"}}],  # inbound manifest
        [{"Name": "R123 - Risk Name", "Risk Definition": "Definition text"}],  # master definitions
    ]
    
    execute_phase_2("test-request-id")
    
    assert mock_download.call_count == 2


@patch("main.risk_context.rt_resolution.Settings")
def test_execute_phase_2_missing_bucket(mock_settings):
    """Test Phase 2 execution with missing GCS bucket configuration."""
    mock_settings_inst = MagicMock()
    mock_settings_inst.gcs_bucket = None
    mock_settings.return_value = mock_settings_inst
    
    with pytest.raises(ValueError, match="GCS bucket not configured"):
        execute_phase_2("test-request-id")
