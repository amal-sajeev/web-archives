import pytest

from main.risk_context.document_chunking import (
    _normalize_markdown,
    _split_blocks,
    _split_block_by_paragraphs,
    _tokenize_keywords,
    score_chunk_relevance,
    select_relevant_chunks,
    split_markdown_into_chunks,
)


def test_normalize_markdown_replaces_windows_newlines():
    assert _normalize_markdown("one\r\ntwo\r\n") == "one\ntwo"


def test_split_blocks_creates_section_blocks():
    markdown = "# Heading One\nalpha\n## Heading Two\nbeta\ngamma"
    result = _split_blocks(markdown)
    assert result == ["# Heading One\nalpha", "## Heading Two\nbeta\ngamma"]


def test_split_block_by_paragraphs_handles_large_paragraphs_and_merge():
    block = ("A" * 30) + "\n\n" + ("B" * 60)
    result = _split_block_by_paragraphs(block, max_chars=80, min_chars=20)
    assert result[0] == "A" * 30
    assert result[1] == "B" * 60


def test_split_block_by_paragraphs_handles_sentence_breaks():
    paragraph = ("This is sentence one. " * 5) + ("X" * 200)
    result = _split_block_by_paragraphs(paragraph, max_chars=120, min_chars=20)
    assert len(result) >= 2
    assert all(isinstance(item, str) for item in result)


def test_split_markdown_into_chunks_handles_empty_input_and_merged_final_chunks():
    assert split_markdown_into_chunks("") == []

    markdown = "# Big\n" + ("A" * 800) + "\n\n# Small\n" + ("B" * 100)
    result = split_markdown_into_chunks(markdown, max_chars=1000, min_chars=200)
    assert len(result) == 1
    assert "B" * 100 in result[0]
    assert "A" * 800 in result[0]


def test_split_markdown_into_chunks_with_multiple_blocks():
    markdown = "# Head 1\nalpha\n\n# Head 2\nbeta\ngamma"
    result = split_markdown_into_chunks(markdown, max_chars=200, min_chars=20)
    assert len(result) == 1
    assert "Head 1" in result[0]
    assert "beta" in result[0]


def test_tokenize_keywords_extracts_expected_tokens():
    result = _tokenize_keywords("Risk, compliance, state-of-the-art, 2024")
    assert "risk" in result
    assert "compliance" in result
    assert "state-of-the-art" in result
    assert "2024" not in result


def test_score_chunk_relevance_handles_empty_keywords_and_no_matches():
    assert score_chunk_relevance("alpha beta gamma", []) == 1.0
    assert score_chunk_relevance("other words only", ["liquidity", "compliance"]) == 0.0
    assert score_chunk_relevance("Liquidity and compliance policy", ["liquidity", "compliance"]) == 1.0


def test_select_relevant_chunks_returns_qualifying_then_fallback():
    chunks = [
        "No relevant terms here",
        "risk liquidity",
        "risk compliance",
        "risk liquidity compliance",
    ]
    selected = select_relevant_chunks(chunks, ["liquidity", "compliance"], top_n=2, min_score=0.5)
    assert selected[0] == "risk liquidity compliance"
    assert len(selected) == 2

    empty = select_relevant_chunks([], ["liquidity"])
    assert empty == []

    fallback = select_relevant_chunks(["unrelated text", "another unrelated item"], ["liquidity"], top_n=1, min_score=0.5)
    assert len(fallback) == 1
    assert fallback[0] in {"unrelated text", "another unrelated item"}
