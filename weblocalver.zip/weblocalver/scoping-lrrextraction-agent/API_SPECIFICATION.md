# LRR Public API Specification
## For Frontend Development Team

**Service:** DBaware Scoping Service - LRR Extraction Agent  
**Base URL:** `http://localhost:8000` (local) or `https://<GKE_CLUSTER>/lrr` (production)  
**Version:** 1.0

---

## Overview

The LRR (Loan Risk Regulation) Public API provides endpoints to:
1. **Start** regulatory document extraction runs
2. **Poll** run status and progress
3. **Retrieve** run details and historical data
4. **List** all extraction runs

All endpoints return JSON responses with pipeline metadata.

---

## API Endpoints

### 1. Start a New Extraction Run
**Endpoint:** `POST /lrr/process`

**Purpose:** Trigger a new LRR extraction process with seed URLs.

**Request Body:**
```json
{
  "urls": ["https://example.com/regulation", "https://finra.org/rules"],
  "request_id": "REQ-12345",
  "resume": null
}
```

**Request Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `urls` | `string[]` | ✅ Yes | At least 1 seed URL to start extraction. Max depth configured server-side. |
| `request_id` | `string` | ❌ No | Client-generated request ID for tracking. If omitted, `run_id` is used. |
| `resume` | `string` | ❌ No | `run_id` to resume a previously paused run |

**Response (201/200):**
```json
{
  "run_id": "run-20260106-abc123def456",
  "request_id": "REQ-12345",
  "status": "queued",
  "objective": "Acquire authoritative regulatory instruments relevant to the supplied seeds and preserve their source text exactly.",
  "seeds": ["https://example.com/regulation", "https://finra.org/rules"],
  "pipeline": "lrr"
}
```

**Response Fields:**
| Field | Type | Description |
|-------|------|-------------|
| `run_id` | `string` | Unique run identifier. Use this for polling and retrieval. |
| `request_id` | `string` | Echo of input request_id or run_id if not provided. |
| `status` | `string` | Initial status: `"queued"` |
| `objective` | `string` | Default objective inferred from the supplied seed URLs |
| `seeds` | `string[]` | Echo of input URLs |
| `pipeline` | `string` | Always `"lrr"` for this service |

**Error Responses:**
- `400 Bad Request` - Invalid URLs or missing required fields
- `500 Internal Server Error` - Server-side failure

**Frontend Usage:**
```javascript
// Start extraction
const response = await fetch('/lrr/process', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    urls: ['https://example.com/rules'],
    request_id: `REQ-${Date.now()}`
  })
});

const { run_id, request_id } = await response.json();
// Store run_id for polling
```

---

### 2. Poll Run Status (Main Polling Endpoint)
**Endpoint:** `GET /lrr/process/{run_id}/status`

**Purpose:** Poll the status and progress of an active or completed extraction run.

**Path Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `run_id` | `string` | The run ID from `/lrr/process` response |

**Response (200):**
```json
{
  "run_id": "run-20260106-abc123def456",
  "status": "running",
  "progress": 45,
  "total_steps": 100,
  "current_step": 45,
  "pipeline": "lrr"
}
```

**Response Fields:**
| Field | Type | Description |
|-------|------|-------------|
| `run_id` | `string` | The requested run ID |
| `status` | `string` | One of: `queued`, `running`, `completed`, `failed` |
| `progress` | `integer` | Percentage progress (0-100) |
| `total_steps` | `integer` | Total extraction steps in this run |
| `current_step` | `integer` | Current step being executed |
| `pipeline` | `string` | Always `"lrr"` |

**Status Lifecycle:**
```
queued → running → completed
                 ↘ failed (on error)
```

**Error Responses:**
- `404 Not Found` - Run ID does not exist

**Frontend Usage - Polling Pattern:**
```javascript
async function pollStatus(runId, maxAttempts = 300) {
  for (let i = 0; i < maxAttempts; i++) {
    const response = await fetch(`/lrr/process/${runId}/status`);
    
    if (response.status === 404) {
      console.error('Run not found');
      break;
    }
    
    const status = await response.json();
    console.log(`Progress: ${status.progress}%`);
    
    if (status.status === 'completed') {
      console.log('Extraction complete!');
      return status;
    }
    
    if (status.status === 'failed') {
      console.error('Extraction failed');
      break;
    }
    
    // Wait before next poll (recommended: 2-5 seconds)
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
}
```

---

### 3. Get Run Details
**Endpoint:** `GET /lrr/runs/{run_id}`

**Purpose:** Retrieve full details of a completed or active run (status, metadata, seeds, objective).

**Path Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `run_id` | `string` | The run ID from `/lrr/process` response |

**Response (200):**
```json
{
  "run_id": "run-20260106-abc123def456",
  "status": "completed",
  "objective": "Extract consumer protection rules",
  "seeds": ["https://example.com/regulation"],
  "progress": 100,
  "total_steps": 150,
  "created_at": "2026-01-06T10:30:45Z",
  "documents_extracted": 45,
  "pipeline": "lrr"
}
```

**Error Responses:**
- `404 Not Found` - Run ID does not exist

**Frontend Usage:**
```javascript
// Call when extraction is complete to show final details
const response = await fetch(`/lrr/runs/${runId}`);
const runDetails = await response.json();
console.log(`Extracted ${runDetails.documents_extracted} documents`);
```

---

### 4. List All Runs
**Endpoint:** `GET /lrr/runs`

**Purpose:** Retrieve a list of all extraction runs (active and completed).

**Query Parameters:** None

**Response (200):**
```json
[
  {
    "run_id": "run-20260106-abc123def456",
    "status": "running",
    "objective": "Extract consumer protection rules",
    "progress": 45,
    "pipeline": "lrr"
  },
  {
    "run_id": "run-20260105-xyz789",
    "status": "completed",
    "objective": "Extract FINRA regulations",
    "progress": 100,
    "pipeline": "lrr"
  }
]
```

**Frontend Usage - History/Dashboard:**
```javascript
// Load run history on page load
const response = await fetch('/lrr/runs');
const runs = await response.json();

// Display active runs first
const activeRuns = runs.filter(r => r.status !== 'completed');
const completedRuns = runs.filter(r => r.status === 'completed');
```

---

## Implementation Guide for Frontend

### Recommended Flow

```
1. User clicks "Extract Documents"
   ↓
2. POST /lrr/process with URLs
   ↓
3. Receive run_id from response
   ↓
4. Show "Extraction in progress" page with progress bar
   ↓
5. Poll GET /lrr/process/{run_id}/status every 2-5 seconds
   ↓
6. Update UI with progress from response
   ↓
7. When status === "completed", fetch full details via GET /lrr/runs/{run_id}
   ↓
8. Display extracted documents to user
```

### Error Handling

```javascript
async function startExtraction(urls) {
  try {
    const response = await fetch('/lrr/process', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ urls, request_id: generateRequestId() })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to start extraction');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Extraction error:', error);
    // Show user-friendly error message
  }
}
```

### Progress Display

```javascript
function displayProgress(status) {
  return {
    progressPercent: status.progress,
    currentStep: status.current_step,
    totalSteps: status.total_steps,
    isComplete: status.status === 'completed',
    isFailed: status.status === 'failed'
  };
}
```

---

## Status Codes Reference

| Code | Meaning |
|------|---------|
| 200 | Success |
| 400 | Bad Request (invalid input) |
| 404 | Not Found (run_id doesn't exist) |
| 500 | Server Error |

---

## Rate Limiting

- **No hard limit** on `/lrr/process` POST (limited by queue size)
- **Polling recommendation:** Wait 2-5 seconds between status checks
- **Optimal polling interval:** 3 seconds (balance between latency and server load)

---

## Headers

**Request Headers:**
```
Content-Type: application/json
```

**Response Headers:**
```
Content-Type: application/json
```

---

## Example: Complete Frontend Implementation

```javascript
class LRRExtractionClient {
  constructor(baseUrl = '/lrr') {
    this.baseUrl = baseUrl;
  }

  async startExtraction(urls, requestId) {
    const response = await fetch(`${this.baseUrl}/process`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ urls, request_id: requestId })
    });
    
    if (!response.ok) throw new Error('Failed to start extraction');
    return await response.json();
  }

  async pollStatus(runId, onProgress) {
    let isComplete = false;
    let attempts = 0;
    const maxAttempts = 600; // 30 min with 3s interval
    
    while (!isComplete && attempts < maxAttempts) {
      const response = await fetch(`${this.baseUrl}/process/${runId}/status`);
      
      if (!response.ok) {
        throw new Error(`Run ${runId} not found`);
      }
      
      const status = await response.json();
      onProgress?.(status);
      
      if (status.status === 'completed' || status.status === 'failed') {
        isComplete = true;
      }
      
      if (!isComplete) {
        await new Promise(r => setTimeout(r, 3000));
      }
      
      attempts++;
    }
  }

  async getRunDetails(runId) {
    const response = await fetch(`${this.baseUrl}/runs/${runId}`);
    if (!response.ok) throw new Error('Run details not found');
    return await response.json();
  }

  async listRuns() {
    const response = await fetch(`${this.baseUrl}/runs`);
    if (!response.ok) throw new Error('Failed to list runs');
    return await response.json();
  }
}

// Usage
const client = new LRRExtractionClient();

// Start extraction
const run = await client.startExtraction(
  ['https://example.com/rules'],
  `REQ-${Date.now()}`
);

console.log(`Started run: ${run.run_id}`);

// Poll status
await client.pollStatus(run.run_id, (status) => {
  console.log(`Progress: ${status.progress}% (Step ${status.current_step}/${status.total_steps})`);
});

// Get details
const details = await client.getRunDetails(run.run_id);
console.log(`Completed! Details:`, details);
```

---

## Support & Questions

For questions or issues:
1. Check the error message returned by the API
2. Review the status code documentation above
3. Ensure URLs are valid and accessible
4. Verify the run_id is correct (copy-paste carefully)

---

**Last Updated:** 2026-01-06  
**API Version:** 1.0  
**Status:** Production Ready
