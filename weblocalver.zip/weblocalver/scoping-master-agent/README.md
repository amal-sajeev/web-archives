# Scoping Master Agent

FastAPI service (default port `4006`) that acts as the control-plane orchestrator for the scoping workflow. It receives requests from the upstream gateway and delegates work to the specialized subagents (Data Extraction, Procedure, Summary), aggregating and forwarding their responses, including binary PDF downloads.

## Endpoints

| Method | Path                               | Description                                                                           |
| ------ | ---------------------------------- | ------------------------------------------------------------------------------------- |
| GET    | `/health`                          | Health check                                                                          |
| POST   | `/trigger-scoping-master`          | Dispatch create/generate/retrieve actions to the appropriate subagent and return JSON |
| POST   | `/trigger-scoping-master-download` | Dispatch download actions to subagents and return raw binary (PDF) content            |

## Configuration

App settings, including subagent base URLs, live in `src/main/config/settings.py`.

## Running locally

```bash
pip install -r requirements.txt
python src/main/app.py
```

## Docker / Helm

Build via the provided `Dockerfile`; deploy with the Helm chart in `helm-chart/` (`values-dev1.yaml`, `values-ct1.yaml`, `values-uat1.yaml`).
