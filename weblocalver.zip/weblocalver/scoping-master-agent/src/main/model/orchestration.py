from dataclasses import dataclass
from enum import Enum
from typing import Any

from model.gateway_request import ScopingAction


class ScopingStage(str, Enum):
    NOIR = "NOIR"
    NOR = "NOR"
    QNA = "QNA"
    DATA_EXTRACTION = "DATA_EXTRACTION"
    PRELIMINARY_RESEARCH = "PRELIMINARY_RESEARCH"
    DISCOVERY_WALKTHROUGH = "DISCOVERY_WALKTHROUGH"
    SCOPING_RECOMMENDATION = "SCOPING_RECOMMENDATION"
    TEST_STEPS = "TEST_STEPS"


class StageStatus(str, Enum):
    NOT_STARTED = "NOT_STARTED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class BodyType(str, Enum):
    JSON = "json"
    FORM_URLENCODED = "form-urlencoded"
    MULTIPART_FORM = "multipart-form"


@dataclass(frozen=True)
class ActionDefinition:
    action: ScopingAction
    stage: ScopingStage
    service_name: str
    method: str
    endpoint: str
    body_type: BodyType = BodyType.JSON
    required_payload_fields: tuple[str, ...] = ()
    prerequisite_stages: tuple[ScopingStage, ...] = ()
    allow_missing_plan_number: bool = False
    plan_number_field: str = "planNumber"
    is_download: bool = False


@dataclass(frozen=True)
class OrchestrationResult:
    planNumber: str | None
    action: ScopingAction
    stage: ScopingStage
    status: StageStatus
    response: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "planNumber": self.planNumber,
            "action": self.action.value,
            "stage": self.stage.value,
            "status": self.status.value,
            "response": self.response,
        }