import os
from pathlib import Path

from dotenv import load_dotenv


load_dotenv()

SRC_MAIN_DIR = Path(__file__).resolve().parents[1]
DATA_DIR_ = SRC_MAIN_DIR / "data"


class Config:
    """Application configuration loaded from environment variables."""

    HTTP_PROXY = os.getenv("HTTP_PROXY") or os.getenv("http_proxy", "")
    HTTPS_PROXY = os.getenv("HTTPS_PROXY") or os.getenv("https_proxy", "")
    NO_PROXY = os.getenv("NO_PROXY") or os.getenv("no_proxy", "")

    # httpx trusts process-level proxy variables by default. Keep that behavior
    # opt-in so a stale local proxy cannot intercept CT1 service calls.
    HTTPX_TRUST_ENV = os.getenv("HTTPX_TRUST_ENV", "false").lower() == "true"
    HTTPX_VERIFY_SSL = os.getenv("HTTPX_VERIFY_SSL", "false").lower() == "true"

    NOIR_BASE_URL = os.getenv("noirBaseURL", "http://localhost:4001")
    DATA_EXTRACTION_BASE_URL = os.getenv("dataExtractionBaseURL", "http://localhost:4002")
    SUMMARY_AGENT_BASE_URL = os.getenv("summaryBaseURL", "http://localhost:8000")
    PROCEDURE_AGENT_BASE_URL = os.getenv("procedureBaseURL", "http://localhost:4003")
    NOR_BASE_URL = os.getenv("norBaseURL", "http://localhost:4004")
    QNA_BASE_URL = os.getenv("qnaBaseURL", "http://localhost:4005/qna")
    SUBAGENT_TIMEOUT_SECONDS = float(os.getenv("SUBAGENT_TIMEOUT_SECONDS", "500"))