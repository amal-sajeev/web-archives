import logging
import re
from time import perf_counter
from typing import Any
from urllib.parse import quote

import httpx

from config.settings import Config
from model.orchestration import ActionDefinition, BodyType


logger = logging.getLogger(__name__)

_PATH_PARAM_RE = re.compile(r"\{([^{}]+)\}")


class SubagentClient:
    def __init__(self) -> None:
        self._base_urls = {
            "noir": Config.NOIR_BASE_URL,
            "nor": Config.NOR_BASE_URL,
            "qna": Config.QNA_BASE_URL,
            "data_extraction": Config.DATA_EXTRACTION_BASE_URL,
            "scoping_summary": Config.SUMMARY_AGENT_BASE_URL,
            "scoping_procedure": Config.PROCEDURE_AGENT_BASE_URL,
        }

    async def call(
        self, action_definition: ActionDefinition, body: dict[str, Any]
    ) -> dict[str, Any]:
        base_url = self._base_urls[action_definition.service_name].rstrip("/")
        endpoint, remaining_body = self._render_endpoint(action_definition.endpoint, dict(body))
        url = f"{base_url}{endpoint}"
        request_kwargs = self._request_kwargs(action_definition, remaining_body)
        started_at = perf_counter()

        logger.info(
            "Calling subagent service=%s method=%s url=%s body_type=%s trust_env=%s verify_ssl=%s",
            action_definition.service_name,
            action_definition.method,
            url, 
            action_definition.body_type.value,
            Config.HTTPX_TRUST_ENV,
            Config.HTTPX_VERIFY_SSL,
        )

        try:
            async with httpx.AsyncClient(
                timeout=Config.SUBAGENT_TIMEOUT_SECONDS,
                trust_env=Config.HTTPX_TRUST_ENV,
                verify=Config.HTTPX_VERIFY_SSL,
            ) as client:
                response = await client.request(action_definition.method, url, **request_kwargs)
        except httpx.HTTPError as exc:
            logger.exception(
                "Subagent transport failure service=%s method=%s url=%s exception=%s: %s elapsed_ms=%.1f",
                action_definition.service_name,
                action_definition.method,
                url,
                type(exc).__name__,
                str(exc) or repr(exc),
                (perf_counter() - started_at) * 1000,
            )
            raise

        elapsed_ms = (perf_counter() - started_at) * 1000
        logger.info(
            "Subagent response service=%s endpoint=%s status_code=%s elapsed_ms=%.1f",
            action_definition.service_name,
            action_definition.endpoint,
            response.status_code,
            elapsed_ms,
        )

        try:
            response.raise_for_status()
            response_payload = response.json() if response.content else {}
        except (httpx.HTTPStatusError, ValueError):
            logger.exception(
                "Subagent response processing failure service=%s endpoint=%s status_code=%s",
                action_definition.service_name,
                action_definition.endpoint,
                response.status_code,
            )
            raise
        if isinstance(response_payload, dict):
            return response_payload
        return {"data": response_payload}

    async def download(
        self, action_definition: ActionDefinition, body: dict[str, Any]
    ) -> tuple[bytes, str, dict[str, str]]:
        """Call the subagent and return the raw response bytes.

        Intended for endpoints that produce binary content (e.g. PDF downloads).
        The response body is *not* JSON-decoded. Returns ``(content, content_type, headers)``.
        """
        base_url = self._base_urls[action_definition.service_name].rstrip("/")
        endpoint, remaining_body = self._render_endpoint(action_definition.endpoint, dict(body))
        url = f"{base_url}{endpoint}"
        request_kwargs = self._request_kwargs(action_definition, remaining_body)
        started_at = perf_counter()

        logger.info(
            "Calling subagent (download) service=%s method=%s url=%s",
            action_definition.service_name,
            action_definition.method,
            url,
        )

        try:
            async with httpx.AsyncClient(
                timeout=Config.SUBAGENT_TIMEOUT_SECONDS,
                trust_env=Config.HTTPX_TRUST_ENV,
                verify=Config.HTTPX_VERIFY_SSL,
            ) as client:
                response = await client.request(action_definition.method, url, **request_kwargs)
        except httpx.HTTPError as exc:
            logger.exception(
                "Subagent download transport failure service=%s url=%s exception=%s elapsed_ms=%.1f",
                action_definition.service_name,
                url,
                type(exc).__name__,
                (perf_counter() - started_at) * 1000,
            )
            raise

        elapsed_ms = (perf_counter() - started_at) * 1000
        logger.info(
            "Subagent download response service=%s endpoint=%s status_code=%s elapsed_ms=%.1f bytes=%d",
            action_definition.service_name,
            action_definition.endpoint,
            response.status_code,
            elapsed_ms,
            len(response.content or b""),
        )

        try:
            response.raise_for_status()
        except httpx.HTTPStatusError:
            logger.exception(
                "Subagent download failure service=%s endpoint=%s status_code=%s",
                action_definition.service_name,
                action_definition.endpoint,
                response.status_code,
            )
            raise

        content_type = response.headers.get("content-type", "application/octet-stream")
        # Forward only headers useful to the client (filename, length).
        forwarded: dict[str, str] = {}
        for key in ("content-disposition", "content-length"):
            value = response.headers.get(key)
            if value:
                forwarded[key] = value
        return response.content, content_type, forwarded

    def _request_kwargs(
        self, action_definition: ActionDefinition, body: dict[str, Any]
    ) -> dict[str, Any]:
        if action_definition.method.upper() == "GET":
            return {"params": body} if body else {}
        if action_definition.body_type == BodyType.FORM_URLENCODED:
            return {"data": body}
        if action_definition.body_type == BodyType.MULTIPART_FORM:
            files = body.get("files")
            form_data = {key: value for key, value in body.items() if key != "files"}
            return {"data": form_data, "files": self._normalize_files(files)}
        return {"json": body}

    @staticmethod
    def _render_endpoint(template: str, body: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        """Substitute ``{name}`` placeholders in ``template`` from ``body``.

        Returns the rendered path along with the remaining body (path params
        consumed are removed so they don't get sent again as body/query).
        """
        used: set[str] = set()

        def _sub(match: re.Match[str]) -> str:
            key = match.group(1)
            if key not in body or body[key] in (None, ""):
                raise ValueError(f"Missing path parameter: {key}")
            used.add(key)
            return quote(str(body[key]), safe="")

        rendered = _PATH_PARAM_RE.sub(_sub, template)
        remaining = {k: v for k, v in body.items() if k not in used}
        return rendered, remaining

    @staticmethod
    def _normalize_files(files: Any) -> list[tuple[str, tuple[str, Any, str]]]:
        if not isinstance(files, list) or not files:
            raise ValueError("payload.files must be a non-empty list for multipart requests.")

        normalized = []
        for file_item in files:
            if isinstance(file_item, dict):
                filename = file_item.get("filename")
                content = file_item.get("content")
                content_type = file_item.get("content_type", "application/octet-stream")
                if not filename or content is None:
                    raise ValueError("Each payload.files item needs filename and content.")
                normalized.append(("files", (filename, content, content_type)))
                continue
            raise ValueError("Each payload.files item must be an object with filename and content.")
        return normalized