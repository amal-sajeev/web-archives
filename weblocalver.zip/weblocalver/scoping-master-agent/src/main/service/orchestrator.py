import logging
from typing import Any

import httpx

# from audit.audit_repository import DummyAuditRepository
from client.subagent_client import SubagentClient
from model.gateway_request import GatewayRequest
from model.orchestration import OrchestrationResult, StageStatus
from registry.action_registry import get_action_definition
from validation.request_validator import RequestValidator
from validation.stage_validator import StageValidator


logger = logging.getLogger(__name__)


class ScopingMasterOrchestrator:
    def __init__(
        self,
        # audit_repository: DummyAuditRepository | None = None,
        subagent_client: SubagentClient | None = None,
    ) -> None:
        # self.audit_repository = audit_repository or DummyAuditRepository()
        self.request_validator = RequestValidator()
        self.stage_validator = StageValidator()  #StageValidator(self.audit_repository)
        self.subagent_client = subagent_client or SubagentClient()

    async def handle(self, request: GatewayRequest) -> dict[str, Any]:
        action_definition = get_action_definition(request.action)
        logger.info(
            "Received scoping action action=%s planNumber=%s stage=%s",
            request.action.value,
            request.planNumber,
            action_definition.stage.value,
        )

        if action_definition.is_download:
            raise ValueError(
                f"Invalid action type: {request.action.value} returns binary content; "
                "use /trigger-scoping-master-download instead."
            )

        self.request_validator.validate(request, action_definition)
        self.stage_validator.validate(request.planNumber, action_definition)

        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     action_definition.stage,
        #     StageStatus.IN_PROGRESS,
        # )

        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber,
        #         action_definition.stage,
        #         StageStatus.IN_PROGRESS,
        #     )

        try:
            response = await self.subagent_client.call(
                action_definition,
                self._build_subagent_body(request),
            )
        except httpx.HTTPStatusError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise ValueError(f"Subagent request failed: {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            error_detail = str(exc) or repr(exc)
            raise ValueError(f"Unable to reach subagent: {type(exc).__name__}: {error_detail}") from exc
        except ValueError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise

        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber,
        #         action_definition.stage,
        #         StageStatus.COMPLETED,
        #     )

        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     action_definition.stage,
        #     StageStatus.COMPLETED,
        #     {"response": response},
        # )

        return OrchestrationResult(
            planNumber=request.planNumber,
            action=request.action,
            stage=action_definition.stage,
            status=StageStatus.COMPLETED,
            response=response,
        ).to_dict()

    async def handle_download(
        self, request: GatewayRequest
    ) -> tuple[bytes, str, dict[str, str]]:
        """Handle actions that return raw binary content (e.g. PDF downloads).

        Runs the same validation as :meth:`handle` but returns the raw
        ``(content, content_type, headers)`` triple instead of a JSON dict.
        """
        action_definition = get_action_definition(request.action)
        logger.info(
            "Received scoping download action action=%s planNumber=%s stage=%s",
            request.action.value,
            request.planNumber,
            action_definition.stage.value,
        )

        self.request_validator.validate(request, action_definition)
        self.stage_validator.validate(request.planNumber, action_definition)

        try:
            return await self.subagent_client.download(
                action_definition,
                self._build_subagent_body(request),
            )
        except httpx.HTTPStatusError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise ValueError(f"Subagent request failed: {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            error_detail = str(exc) or repr(exc)
            raise ValueError(
                f"Unable to reach subagent: {type(exc).__name__}: {error_detail}"
            ) from exc
        except ValueError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise

    def _build_subagent_body(self, request: GatewayRequest) -> dict[str, Any]:
        body = dict(request.payload)
        if request.planNumber is not None:
            action_definition = get_action_definition(request.action)
            body[action_definition.plan_number_field] = request.planNumber
        return body

    def _record_failure(
        self, request: GatewayRequest, stage, details: dict[str, Any]
    ) -> None:
        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber, stage, StageStatus.FAILED
        #     )
        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     stage,
        #     StageStatus.FAILED,
        #     details,
        # )
        pass 
