from model.gateway_request import GatewayRequest
from model.orchestration import ActionDefinition


class RequestValidator:
    def validate(self, request: GatewayRequest, action_definition: ActionDefinition) -> None:
        missing_fields = [
            field_name
            for field_name in action_definition.required_payload_fields
            if field_name not in request.payload or request.payload[field_name] in (None, "")
        ]
        if missing_fields:
            raise ValueError(f"Missing required payload field(s): {', '.join(missing_fields)}")

        if request.action.value.startswith("UPDATE_") and not request.payload:
            raise ValueError("Update actions require a non-empty payload.")

        if request.action.value.startswith("GET_CITATION_DOCUMENT"):
            self._validate_citation_request(request)

    def _validate_citation_request(self, request: GatewayRequest) -> None:
        chunk_id = request.payload.get("chunk_id")
        document_uri = request.payload.get("document_uri")

        if not chunk_id and not document_uri:
            raise ValueError("Either payload.chunk_id or payload.document_uri is required.")

        if chunk_id and not request.planNumber:
            raise ValueError("planNumber is required when payload.chunk_id is provided.")