# from audit.audit_repository import DummyAuditRepository
from model.orchestration import ActionDefinition, StageStatus


class StageValidator:

    def validate(self, plan_number: str | None, action_definition: ActionDefinition) -> None:
        if not plan_number or not action_definition.prerequisite_stages:
            return

        incomplete_stages = [
            # stage.value
            # for stage in action_definition.prerequisite_stages
            # if self.audit_repository.get_stage_status(plan_number, stage) != StageStatus.COMPLETED
        ]

        if incomplete_stages:
            raise PermissionError(
                "Previous stage(s) must be completed before this action: "
                + ", ".join(incomplete_stages)
            )