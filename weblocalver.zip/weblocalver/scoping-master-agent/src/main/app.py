import logging

import uvicorn
from fastapi import FastAPI, HTTPException, Response

from model.gateway_request import GatewayRequest
from service.orchestrator import ScopingMasterOrchestrator


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Scoping Master Agent",
    description="Orchestrates the end-to-end scoping workflow across scoping subagents.",
    version="1.0.0",
)

orchestrator = ScopingMasterOrchestrator()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/trigger-scoping-master")
async def trigger_scoping_master(request: GatewayRequest):
    try:
        return await orchestrator.handle(request)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error handling scoping request action=%s planNumber=%s",
            request.action,
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail="An internal error occurred.") from exc


@app.post("/trigger-scoping-master-download")
async def trigger_scoping_master_download(request: GatewayRequest):
    """Dispatch actions whose subagent returns raw binary content (e.g. PDFs).

    Unlike ``/trigger-scoping-master``, this returns the downstream bytes
    verbatim with the original ``Content-Type`` and forwarded
    ``Content-Disposition`` header so the caller (gateway/browser) can save
    or stream the file directly.
    """
    try:
        content, content_type, headers = await orchestrator.handle_download(request)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Unexpected error handling scoping download action=%s planNumber=%s",
            request.action,
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail="An internal error occurred.") from exc

    return Response(content=content, media_type=content_type, headers=headers)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4006)