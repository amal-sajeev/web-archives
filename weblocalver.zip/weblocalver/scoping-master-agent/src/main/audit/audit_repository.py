# from dataclasses import dataclass
# from datetime import datetime, timezone
# from typing import Any

# from model.gateway_request import ScopingAction
# from model.orchestration import ScopingStage, StageStatus


# @dataclass(frozen=True)
# class AuditEvent:
#     planNumber: str | None
#     action: ScopingAction
#     stage: ScopingStage
#     status: StageStatus
#     details: dict[str, Any]
#     created_at: str


# class DummyAuditRepository:
#     """In-memory placeholder for the future audit table integration."""

#     def __init__(self) -> None:
#         self._stage_statuses: dict[str, dict[ScopingStage, StageStatus]] = {}
#         self._events: list[AuditEvent] = []

#     def get_stage_status(self, plan_number: str, stage: ScopingStage) -> StageStatus:
#         return self._stage_statuses.get(plan_number, {}).get(stage, StageStatus.NOT_STARTED)

#     def set_stage_status(self, plan_number: str, stage: ScopingStage, status: StageStatus) -> None:
#         self._stage_statuses.setdefault(plan_number, {})[stage] = status

#     def record_event(
#         self,
#         plan_number: str | None,
#         action: ScopingAction,
#         stage: ScopingStage,
#         status: StageStatus,
#         details: dict[str, Any] | None = None,
#     ) -> None:
#         self._events.append(
#             AuditEvent(
#                 planNumber=plan_number,
#                 action=action,
#                 stage=stage,
#                 status=status,
#                 details=details or {},
#                 created_at=datetime.now(timezone.utc).isoformat(),
#             )
#         )

#     def list_events(self) -> list[AuditEvent]:
#         return list(self._events)