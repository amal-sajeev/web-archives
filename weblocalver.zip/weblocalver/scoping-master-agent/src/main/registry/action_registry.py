from model.gateway_request import ScopingAction
from model.orchestration import ActionDefinition, BodyType, ScopingStage


def _action(action, stage, service_name, method, endpoint, *, body_type=BodyType.JSON,
            required_payload_fields=(), prerequisite_stages=(), plan_number_field="planNumber",
            is_download=False):
    return ActionDefinition(
        action=action, stage=stage, service_name=service_name, method=method,
        endpoint=endpoint, body_type=body_type,
        required_payload_fields=required_payload_fields,
        prerequisite_stages=prerequisite_stages,
        plan_number_field=plan_number_field,
        is_download=is_download,
    )


ACTION_REGISTRY: dict[ScopingAction, ActionDefinition] = {
    ScopingAction.GET_NOIR: _action(ScopingAction.GET_NOIR, ScopingStage.NOIR, "noir", "GET", "/noir/{plan_item_number}", plan_number_field="plan_item_number"),
    ScopingAction.GENERATE_NOIR: _action(ScopingAction.GENERATE_NOIR, ScopingStage.NOIR, "noir", "POST", "/noir/generate", plan_number_field="plan_item_number"),
    ScopingAction.HUMAN_EDIT: _action(ScopingAction.HUMAN_EDIT, ScopingStage.NOIR, "noir", "POST", "/noir/human-edit", required_payload_fields=("plan_item_number", "noir")),
    ScopingAction.EDIT_NOIR: _action(ScopingAction.EDIT_NOIR, ScopingStage.NOIR, "noir", "POST", "/noir/edit", required_payload_fields=("plan_item_number", "user_instruction")),
    ScopingAction.SEND_NOIR_EMAIL: _action(ScopingAction.SEND_NOIR_EMAIL, ScopingStage.NOIR, "noir", "POST", "/noir/send", required_payload_fields=("plan_item_number", "subject", "body", "to_recipients", "from_address")),
    ScopingAction.SKIP_NOIR: _action(ScopingAction.SKIP_NOIR, ScopingStage.NOIR, "noir", "POST", "/noir/skip"),
    ScopingAction.GET_NOR: _action(ScopingAction.GET_NOR, ScopingStage.NOR, "nor", "GET", "/nor/{plan_item_number}", plan_number_field="plan_item_number"),
    ScopingAction.GENERATE_NOR: _action(ScopingAction.GENERATE_NOR, ScopingStage.NOR, "nor", "POST", "/nor/generate", plan_number_field="plan_item_number"),
    ScopingAction.EDIT_NOR: _action(ScopingAction.EDIT_NOR, ScopingStage.NOR, "nor", "POST", "/nor/edit", required_payload_fields=("plan_item_number", "user_instruction")),
    ScopingAction.HUMAN_EDIT_NOR: _action(ScopingAction.HUMAN_EDIT_NOR, ScopingStage.NOR, "nor", "POST", "/nor/human-edit", required_payload_fields=("plan_item_number", "nor")),
    ScopingAction.SKIP_NOR: _action(ScopingAction.SKIP_NOR, ScopingStage.NOR, "nor", "POST", "/nor/skip", required_payload_fields=("plan_item_number",)),
    ScopingAction.SEND_NOR_EMAIL: _action(ScopingAction.SEND_NOR_EMAIL, ScopingStage.NOR, "nor", "POST", "/nor/send", required_payload_fields=("to_recipients",)),
    ScopingAction.QNA_CHAT: _action(ScopingAction.QNA_CHAT, ScopingStage.QNA, "qna", "POST", "/chat", required_payload_fields=("question",)),
    ScopingAction.QNA_LIST_DOCUMENTS: _action(ScopingAction.QNA_LIST_DOCUMENTS, ScopingStage.QNA, "qna", "POST", "/documents/list-all", plan_number_field="plan_number"),
    ScopingAction.QNA_DELETE_DOCUMENTS: _action(ScopingAction.QNA_DELETE_DOCUMENTS, ScopingStage.QNA, "qna", "POST", "/documents/delete", required_payload_fields=("documents",), plan_number_field="plan_number"),
    ScopingAction.DATA_EXTRACTION: _action(ScopingAction.DATA_EXTRACTION, ScopingStage.DATA_EXTRACTION, "data_extraction", "POST", "/data-extraction", prerequisite_stages=(ScopingStage.NOIR,)),
    ScopingAction.GET_DATA_EXTRACTION_STATUS: _action(ScopingAction.GET_DATA_EXTRACTION_STATUS, ScopingStage.DATA_EXTRACTION, "data_extraction", "GET", "/data-extraction/{session_id}/status", required_payload_fields=("session_id",)),
    ScopingAction.GET_PLAN_AVAILABILITY: _action(ScopingAction.GET_PLAN_AVAILABILITY, ScopingStage.DATA_EXTRACTION, "data_extraction", "GET", "/getdata/{plan_number}/availability", plan_number_field="plan_number"),
    ScopingAction.GET_PLAN_ARTIFACT: _action(ScopingAction.GET_PLAN_ARTIFACT, ScopingStage.DATA_EXTRACTION, "data_extraction", "GET", "/getdata/{plan_number}/{artifact}", plan_number_field="plan_number", required_payload_fields=("artifact",)),
    ScopingAction.RUN_ANALYTICS: _action(ScopingAction.RUN_ANALYTICS, ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST", "/run-analytics-agent", prerequisite_stages=(ScopingStage.DATA_EXTRACTION,)),
    ScopingAction.GET_CITATION_DOCUMENT: _action(ScopingAction.GET_CITATION_DOCUMENT, ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST", "/get_document"),
    ScopingAction.GET_PRELIMINARY_RESEARCH_DOCUMENT: _action(ScopingAction.GET_PRELIMINARY_RESEARCH_DOCUMENT, ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST", "/get-preliminary-research-document"),
    ScopingAction.EDIT_PRELIMINARY_RESEARCH_DOCUMENT: _action(ScopingAction.EDIT_PRELIMINARY_RESEARCH_DOCUMENT, ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST", "/edit-preliminary-research-document", required_payload_fields=("analysis_report",), prerequisite_stages=(ScopingStage.DATA_EXTRACTION,)),
    ScopingAction.GENERATE_DISCOVERY_WALKTHROUGH: _action(ScopingAction.GENERATE_DISCOVERY_WALKTHROUGH, ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "POST", "/generate-discovery-walkthrough", prerequisite_stages=(ScopingStage.PRELIMINARY_RESEARCH,)),
    ScopingAction.GET_DISCOVERY_WALKTHROUGH: _action(ScopingAction.GET_DISCOVERY_WALKTHROUGH, ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "POST", "/get-discovery-walkthrough"),
    ScopingAction.UPDATE_DISCOVERY_WALKTHROUGH: _action(ScopingAction.UPDATE_DISCOVERY_WALKTHROUGH, ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "PUT", "/update-discovery-walkthrough", required_payload_fields=("report_title", "sections"), prerequisite_stages=(ScopingStage.PRELIMINARY_RESEARCH,)),
    ScopingAction.GENERATE_INSCOPE_OUTSCOPE: _action(ScopingAction.GENERATE_INSCOPE_OUTSCOPE, ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST", "/generate-inscope-outscope", prerequisite_stages=(ScopingStage.DISCOVERY_WALKTHROUGH,)),
    ScopingAction.GET_INSCOPE_OUTSCOPE: _action(ScopingAction.GET_INSCOPE_OUTSCOPE, ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST", "/get-inscope-outscope"),
    ScopingAction.UPDATE_INSCOPE_OUTSCOPE: _action(ScopingAction.UPDATE_INSCOPE_OUTSCOPE, ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "PUT", "/update-inscope-outscope", required_payload_fields=("inscope", "outscope"), prerequisite_stages=(ScopingStage.DISCOVERY_WALKTHROUGH,)),
    ScopingAction.UPLOAD_MEETING_NOTES: _action(ScopingAction.UPLOAD_MEETING_NOTES, ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST", "/generate-meeting-notes", body_type=BodyType.MULTIPART_FORM, required_payload_fields=("files",)),
    ScopingAction.GET_MEETING_NOTES_SUMMARY: _action(ScopingAction.GET_MEETING_NOTES_SUMMARY, ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST", "/get-meeting-notes-summary"),
    ScopingAction.GENERATE_TEST_STEPS: _action(ScopingAction.GENERATE_TEST_STEPS, ScopingStage.TEST_STEPS, "scoping_procedure", "POST", "/generate-test-steps", prerequisite_stages=(ScopingStage.SCOPING_RECOMMENDATION,)),
    ScopingAction.GET_TEST_STEPS: _action(ScopingAction.GET_TEST_STEPS, ScopingStage.TEST_STEPS, "scoping_procedure", "POST", "/get-test-steps"),
    ScopingAction.UPDATE_TEST_STEPS: _action(ScopingAction.UPDATE_TEST_STEPS, ScopingStage.TEST_STEPS, "scoping_procedure", "PUT", "/update-test-steps", required_payload_fields=("test_steps",), prerequisite_stages=(ScopingStage.SCOPING_RECOMMENDATION,)),
    ScopingAction.DOWNLOAD_DISCOVERY_WALKTHROUGH: _action(ScopingAction.DOWNLOAD_DISCOVERY_WALKTHROUGH, ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "POST", "/download-discovery-walkthrough", required_payload_fields=("report_title", "sections"), is_download=True),
    ScopingAction.DOWNLOAD_INSCOPE_OUTSCOPE: _action(ScopingAction.DOWNLOAD_INSCOPE_OUTSCOPE, ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST", "/download-inscope-outscope", required_payload_fields=("inscope", "outscope"), is_download=True),
    ScopingAction.DOWNLOAD_TEST_STEPS: _action(ScopingAction.DOWNLOAD_TEST_STEPS, ScopingStage.TEST_STEPS, "scoping_procedure", "POST", "/download-test-steps", required_payload_fields=("test_steps",), is_download=True),
    ScopingAction.DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT: _action(ScopingAction.DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT, ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST", "/download", plan_number_field="plan_number", is_download=True),
    ScopingAction.DOWNLOAD_SCOPING_DOCUMENT: _action(ScopingAction.DOWNLOAD_SCOPING_DOCUMENT, ScopingStage.TEST_STEPS, "scoping_procedure", "POST", "/download-scoping-document", plan_number_field="planNumber", is_download=True),
    ScopingAction.GENERATE_SCOPING_DOCUMENT: _action(ScopingAction.GENERATE_SCOPING_DOCUMENT, ScopingStage.TEST_STEPS, "scoping_procedure", "POST", "/generate-scoping-document", is_download=True),
    ScopingAction.UPDATE_SCOPING_DOCUMENT: _action(ScopingAction.UPDATE_SCOPING_DOCUMENT, ScopingStage.TEST_STEPS, "scoping_procedure", "PUT", "/update-scoping-document", required_payload_fields=("document",)),
}


def get_action_definition(action: ScopingAction) -> ActionDefinition:
    return ACTION_REGISTRY[action]