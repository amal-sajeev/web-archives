"""Unit tests for the FastAPI `app` module."""
from __future__ import annotations

from unittest.mock import AsyncMock


import pytest
from fastapi.testclient import TestClient

import app as app_module
from model.gateway_request import ScopingAction


@pytest.fixture
def client(monkeypatch: pytest.MonkeyPatch) -> TestClient:
    # Ensure a clean orchestrator per test.
    monkeypatch.setattr(app_module, "orchestrator", AsyncMock())
    return TestClient(app_module.app)


class TestHealth:
    def test_returns_ok(self, client: TestClient) -> None:
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}


class TestTriggerScopingMaster:
    def _valid_body(self, **overrides) -> dict:
        body = {
            "planNumber": "P1",
            "action": ScopingAction.GENERATE_NOIR.value,
            "payload": {"foo": "bar"},
        }
        body.update(overrides)
        return body

    def test_success_returns_orchestrator_result(self, client: TestClient) -> None:
        expected = {"status": "COMPLETED", "response": {"ok": True}}
        app_module.orchestrator.handle = AsyncMock(return_value=expected)

        response = client.post("/trigger-scoping-master", json=self._valid_body())

        assert response.status_code == 200
        assert response.json() == expected
        app_module.orchestrator.handle.assert_awaited_once()

    def test_value_error_returns_400(self, client: TestClient) -> None:
        app_module.orchestrator.handle = AsyncMock(side_effect=ValueError("bad payload"))
        response = client.post("/trigger-scoping-master", json=self._valid_body())
        assert response.status_code == 400
        assert response.json() == {"detail": "bad payload"}

    def test_permission_error_returns_409(self, client: TestClient) -> None:
        app_module.orchestrator.handle = AsyncMock(
            side_effect=PermissionError("stage not ready")
        )
        response = client.post("/trigger-scoping-master", json=self._valid_body())
        assert response.status_code == 409
        assert response.json() == {"detail": "stage not ready"}

    def test_unexpected_error_returns_500(self, client: TestClient) -> None:
        app_module.orchestrator.handle = AsyncMock(side_effect=RuntimeError("boom"))
        response = client.post("/trigger-scoping-master", json=self._valid_body())
        assert response.status_code == 500
        assert response.json() == {"detail": "An internal error occurred."}

    def test_invalid_request_body_returns_422(self, client: TestClient) -> None:
        # Missing required "action" field triggers Pydantic validation before
        # the orchestrator is called.
        response = client.post(
            "/trigger-scoping-master", json={"planNumber": "P1", "payload": {}}
        )
        assert response.status_code == 422

    def test_invalid_action_enum_returns_422(self, client: TestClient) -> None:
        response = client.post(
            "/trigger-scoping-master",
            json={"planNumber": "P1", "action": "NOT_AN_ACTION", "payload": {}},
        )
        assert response.status_code == 422

    def test_missing_plan_number_rejected_by_model_validator(
        self, client: TestClient
    ) -> None:
        response = client.post(
            "/trigger-scoping-master",
            json={"action": ScopingAction.GENERATE_NOIR.value, "payload": {}},
        )
        # GatewayRequest.model_validator raises -> FastAPI returns 422
        assert response.status_code == 422


class TestTriggerScopingMasterDownload:
    def _valid_body(self, **overrides) -> dict:
        body = {
            "planNumber": "P1",
            "action": ScopingAction.DOWNLOAD_TEST_STEPS.value,
            "payload": {"test_steps": [{"step": 1}]},
        }
        body.update(overrides)
        return body

    def test_success_returns_pdf_bytes(self, client: TestClient) -> None:
        pdf = b"%PDF-1.4 fake bytes"
        headers = {"content-disposition": 'attachment; filename="report.pdf"'}
        app_module.orchestrator.handle_download = AsyncMock(
            return_value=(pdf, "application/pdf", headers)
        )

        response = client.post("/trigger-scoping-master-download", json=self._valid_body())

        assert response.status_code == 200
        assert response.headers["content-type"] == "application/pdf"
        assert response.headers.get("content-disposition") == 'attachment; filename="report.pdf"'
        assert response.content == pdf

    def test_value_error_returns_400(self, client: TestClient) -> None:
        app_module.orchestrator.handle_download = AsyncMock(
            side_effect=ValueError("bad payload")
        )
        response = client.post("/trigger-scoping-master-download", json=self._valid_body())
        assert response.status_code == 400
        assert response.json() == {"detail": "bad payload"}

    def test_permission_error_returns_409(self, client: TestClient) -> None:
        app_module.orchestrator.handle_download = AsyncMock(
            side_effect=PermissionError("stage not ready")
        )
        response = client.post("/trigger-scoping-master-download", json=self._valid_body())
        assert response.status_code == 409

    def test_unexpected_error_returns_500(self, client: TestClient) -> None:
        app_module.orchestrator.handle_download = AsyncMock(side_effect=RuntimeError("boom"))
        response = client.post("/trigger-scoping-master-download", json=self._valid_body())
        assert response.status_code == 500
