"""Unit tests for `service.orchestrator.ScopingMasterOrchestrator`."""
from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from model.gateway_request import GatewayRequest, ScopingAction
from model.orchestration import ActionDefinition, BodyType, ScopingStage, StageStatus
from service.orchestrator import ScopingMasterOrchestrator


def _run(coro):
    return asyncio.run(coro)


def _make_action_def(
    *,
    action: ScopingAction = ScopingAction.GENERATE_NOIR,
    stage: ScopingStage = ScopingStage.NOIR,
    service_name: str = "noir",
    method: str = "POST",
    endpoint: str = "/noir/generate",
    body_type: BodyType = BodyType.JSON,
    plan_number_field: str = "planNumber",
    is_download: bool = False,
) -> ActionDefinition:
    return ActionDefinition(
        action=action,
        stage=stage,
        service_name=service_name,
        method=method,
        endpoint=endpoint,
        body_type=body_type,
        plan_number_field=plan_number_field,
        is_download=is_download,
    )


def _make_orchestrator(
    *,
    subagent_response: dict | None = None,
    subagent_side_effect: Exception | None = None,
    action_def: ActionDefinition | None = None,
    monkeypatch: pytest.MonkeyPatch | None = None,
):
    """Build an orchestrator with mocked collaborators."""
    client = MagicMock()
    if subagent_side_effect is not None:
        client.call = AsyncMock(side_effect=subagent_side_effect)
    else:
        client.call = AsyncMock(return_value=subagent_response or {"ok": True})

    orch = ScopingMasterOrchestrator(subagent_client=client)
    orch.request_validator = MagicMock()
    orch.stage_validator = MagicMock()

    if action_def is not None and monkeypatch is not None:
        monkeypatch.setattr(
            "service.orchestrator.get_action_definition",
            lambda _action: action_def,
        )
    return orch, client


class TestInit:
    def test_uses_provided_client(self) -> None:
        client = MagicMock()
        orch = ScopingMasterOrchestrator(subagent_client=client)
        assert orch.subagent_client is client

    def test_creates_default_collaborators(self) -> None:
        orch = ScopingMasterOrchestrator()
        assert orch.subagent_client is not None
        assert orch.request_validator is not None
        assert orch.stage_validator is not None


class TestBuildSubagentBody:
    def test_includes_plan_number_under_configured_field(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(plan_number_field="plan_item_number")
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GENERATE_NOIR,
            payload={"foo": "bar"},
        )
        body = orch._build_subagent_body(request)
        assert body == {"foo": "bar", "plan_item_number": "P1"}

    def test_omits_plan_number_when_missing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        request = GatewayRequest(
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"document_uri": "gs://b/o"},
        )
        body = orch._build_subagent_body(request)
        assert body == {"document_uri": "gs://b/o"}

    def test_does_not_mutate_original_payload(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        payload = {"a": 1}
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload=payload
        )
        orch._build_subagent_body(request)
        assert payload == {"a": 1}


class TestHandleRejectsDownloadActions:
    def test_handle_raises_for_download_action(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(
            action=ScopingAction.DOWNLOAD_SCOPING_DOCUMENT,
            service_name="scoping_procedure",
            endpoint="/generate-scoping-document",
            is_download=True,
        )
        orch, client = _make_orchestrator(
            action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.DOWNLOAD_SCOPING_DOCUMENT
        )

        with pytest.raises(ValueError, match="Invalid action type"):
            _run(orch.handle(request))

        # The subagent must NOT be called for download actions via /handle.
        client.call.assert_not_called()


class TestHandleSuccess:
    def test_returns_completed_result_dict(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(plan_number_field="plan_item_number")
        orch, client = _make_orchestrator(
            subagent_response={"data": "ok"},
            action_def=action_def,
            monkeypatch=monkeypatch,
        )
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GENERATE_NOIR,
            payload={"k": "v"},
        )

        result = _run(orch.handle(request))

        assert result == {
            "planNumber": "P1",
            "action": "GENERATE_NOIR",
            "stage": "NOIR",
            "status": StageStatus.COMPLETED.value,
            "response": {"data": "ok"},
        }
        client.call.assert_awaited_once()
        called_def, called_body = client.call.call_args.args
        assert called_def is action_def
        assert called_body == {"k": "v", "plan_item_number": "P1"}

    def test_invokes_validators_before_subagent(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, client = _make_orchestrator(
            action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        _run(orch.handle(request))

        orch.request_validator.validate.assert_called_once_with(request, action_def)
        orch.stage_validator.validate.assert_called_once_with("P1", action_def)
        client.call.assert_awaited_once()

    def test_validation_error_short_circuits(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, client = _make_orchestrator(
            action_def=action_def, monkeypatch=monkeypatch
        )
        orch.request_validator.validate.side_effect = ValueError("bad request")
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="bad request"):
            _run(orch.handle(request))
        client.call.assert_not_awaited()


class TestHandleErrors:
    def _make_http_status_error(self, text: str = "boom") -> httpx.HTTPStatusError:
        response = MagicMock(spec=httpx.Response)
        response.text = text
        return httpx.HTTPStatusError("err", request=MagicMock(), response=response)

    def test_http_status_error_wrapped(self, monkeypatch: pytest.MonkeyPatch) -> None:
        action_def = _make_action_def()
        exc = self._make_http_status_error("server down")
        orch, _ = _make_orchestrator(
            subagent_side_effect=exc, action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="Subagent request failed: server down") as info:
            _run(orch.handle(request))
        assert info.value.__cause__ is exc

    def test_http_error_wrapped(self, monkeypatch: pytest.MonkeyPatch) -> None:
        action_def = _make_action_def()
        exc = httpx.ConnectError("boom")
        orch, _ = _make_orchestrator(
            subagent_side_effect=exc, action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="Unable to reach subagent") as info:
            _run(orch.handle(request))
        assert info.value.__cause__ is exc

    def test_value_error_reraised(self, monkeypatch: pytest.MonkeyPatch) -> None:
        action_def = _make_action_def()
        exc = ValueError("payload issue")
        orch, _ = _make_orchestrator(
            subagent_side_effect=exc, action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="payload issue"):
            _run(orch.handle(request))


class TestRecordFailure:
    def test_is_currently_a_no_op(self) -> None:
        orch = ScopingMasterOrchestrator(subagent_client=MagicMock())
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )
        # Should not raise and should return None.
        assert orch._record_failure(request, ScopingStage.NOIR, {"error": "x"}) is None
