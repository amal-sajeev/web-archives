"""Unit tests for `registry.action_registry`."""
from __future__ import annotations

import pytest

from model.gateway_request import ScopingAction
from model.orchestration import ActionDefinition, BodyType, ScopingStage
from registry.action_registry import ACTION_REGISTRY, get_action_definition


# Expected shape of every registered entry:
# action -> (stage, service_name, method, endpoint, body_type,
#            required_payload_fields, prerequisite_stages, plan_number_field)
EXPECTED: dict[ScopingAction, tuple] = {
    ScopingAction.GET_NOIR: (
        ScopingStage.NOIR, "noir", "GET", "/noir/{plan_item_number}",
        BodyType.JSON, (), (), "plan_item_number",
    ),
    ScopingAction.GENERATE_NOIR: (
        ScopingStage.NOIR, "noir", "POST", "/noir/generate",
        BodyType.JSON, (), (), "plan_item_number",
    ),
    ScopingAction.HUMAN_EDIT: (
        ScopingStage.NOIR, "noir", "POST", "/noir/human-edit",
        BodyType.JSON, ("plan_item_number", "noir"), (), "planNumber",
    ),
    ScopingAction.EDIT_NOIR: (
        ScopingStage.NOIR, "noir", "POST", "/noir/edit",
        BodyType.JSON, ("plan_item_number", "user_instruction"), (), "planNumber",
    ),
    ScopingAction.SEND_NOIR_EMAIL: (
        ScopingStage.NOIR, "noir", "POST", "/noir/send",
        BodyType.JSON,
        ("plan_item_number", "subject", "body", "to_recipients", "from_address"),
        (), "planNumber",
    ),
    ScopingAction.GET_NOR: (
        ScopingStage.NOR, "nor", "GET", "/nor/{plan_item_number}",
        BodyType.JSON, (), (), "plan_item_number",
    ),
    ScopingAction.GENERATE_NOR: (
        ScopingStage.NOR, "nor", "POST", "/nor/generate",
        BodyType.JSON, (), (), "plan_item_number",
    ),
    ScopingAction.EDIT_NOR: (
        ScopingStage.NOR, "nor", "POST", "/nor/edit",
        BodyType.JSON, ("plan_item_number", "user_instruction"), (), "planNumber",
    ),
    ScopingAction.HUMAN_EDIT_NOR: (
        ScopingStage.NOR, "nor", "POST", "/nor/human-edit",
        BodyType.JSON, ("plan_item_number", "nor"), (), "planNumber",
    ),
    ScopingAction.SKIP_NOR: (
        ScopingStage.NOR, "nor", "POST", "/nor/skip",
        BodyType.JSON, ("plan_item_number",), (), "planNumber",
    ),
    ScopingAction.SKIP_NOIR: (
        ScopingStage.NOIR, "noir", "POST", "/noir/skip",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.SEND_NOR_EMAIL: (
        ScopingStage.NOR, "nor", "POST", "/nor/send",
        BodyType.JSON, ("to_recipients",), (), "planNumber",
    ),
    ScopingAction.QNA_CHAT: (
        ScopingStage.QNA, "qna", "POST", "/chat",
        BodyType.JSON, ("question",), (), "planNumber",
    ),
    ScopingAction.QNA_LIST_DOCUMENTS: (
        ScopingStage.QNA, "qna", "POST", "/documents/list-all",
        BodyType.JSON, (), (), "plan_number",
    ),
    ScopingAction.QNA_DELETE_DOCUMENTS: (
        ScopingStage.QNA, "qna", "POST", "/documents/delete",
        BodyType.JSON, ("documents",), (), "plan_number",
    ),
    ScopingAction.DATA_EXTRACTION: (
        ScopingStage.DATA_EXTRACTION, "data_extraction", "POST", "/data-extraction",
        BodyType.JSON, (), (ScopingStage.NOIR,), "planNumber",
    ),
    ScopingAction.GET_DATA_EXTRACTION_STATUS: (
        ScopingStage.DATA_EXTRACTION, "data_extraction", "GET",
        "/data-extraction/{session_id}/status",
        BodyType.JSON, ("session_id",), (), "planNumber",
    ),
    ScopingAction.GET_PLAN_AVAILABILITY: (
        ScopingStage.DATA_EXTRACTION, "data_extraction", "GET",
        "/getdata/{plan_number}/availability",
        BodyType.JSON, (), (), "plan_number",
    ),
    ScopingAction.GET_PLAN_ARTIFACT: (
        ScopingStage.DATA_EXTRACTION, "data_extraction", "GET",
        "/getdata/{plan_number}/{artifact}",
        BodyType.JSON, ("artifact",), (), "plan_number",
    ),
    ScopingAction.RUN_ANALYTICS: (
        ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST", "/run-analytics-agent",
        BodyType.JSON, (), (ScopingStage.DATA_EXTRACTION,), "planNumber",
    ),
    ScopingAction.GET_CITATION_DOCUMENT: (
        ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST", "/get_document",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.GET_PRELIMINARY_RESEARCH_DOCUMENT: (
        ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST",
        "/get-preliminary-research-document",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.EDIT_PRELIMINARY_RESEARCH_DOCUMENT: (
        ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST",
        "/edit-preliminary-research-document",
        BodyType.JSON, ("analysis_report",), (ScopingStage.DATA_EXTRACTION,), "planNumber",
    ),
    ScopingAction.GENERATE_DISCOVERY_WALKTHROUGH: (
        ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "POST",
        "/generate-discovery-walkthrough",
        BodyType.JSON, (), (ScopingStage.PRELIMINARY_RESEARCH,), "planNumber",
    ),
    ScopingAction.GET_DISCOVERY_WALKTHROUGH: (
        ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "POST",
        "/get-discovery-walkthrough",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.UPDATE_DISCOVERY_WALKTHROUGH: (
        ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "PUT",
        "/update-discovery-walkthrough",
        BodyType.JSON, ("report_title", "sections"),
        (ScopingStage.PRELIMINARY_RESEARCH,), "planNumber",
    ),
    ScopingAction.GENERATE_INSCOPE_OUTSCOPE: (
        ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST",
        "/generate-inscope-outscope",
        BodyType.JSON, (), (ScopingStage.DISCOVERY_WALKTHROUGH,), "planNumber",
    ),
    ScopingAction.GET_INSCOPE_OUTSCOPE: (
        ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST",
        "/get-inscope-outscope",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.UPDATE_INSCOPE_OUTSCOPE: (
        ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "PUT",
        "/update-inscope-outscope",
        BodyType.JSON, ("inscope", "outscope"),
        (ScopingStage.DISCOVERY_WALKTHROUGH,), "planNumber",
    ),
    ScopingAction.UPLOAD_MEETING_NOTES: (
        ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST",
        "/generate-meeting-notes",
        BodyType.MULTIPART_FORM, ("files",), (), "planNumber",
    ),
    ScopingAction.GET_MEETING_NOTES_SUMMARY: (
        ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST",
        "/get-meeting-notes-summary",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.GENERATE_TEST_STEPS: (
        ScopingStage.TEST_STEPS, "scoping_procedure", "POST", "/generate-test-steps",
        BodyType.JSON, (), (ScopingStage.SCOPING_RECOMMENDATION,), "planNumber",
    ),
    ScopingAction.GET_TEST_STEPS: (
        ScopingStage.TEST_STEPS, "scoping_procedure", "POST", "/get-test-steps",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.UPDATE_TEST_STEPS: (
        ScopingStage.TEST_STEPS, "scoping_procedure", "PUT", "/update-test-steps",
        BodyType.JSON, ("test_steps",), (ScopingStage.SCOPING_RECOMMENDATION,), "planNumber",
    ),
    ScopingAction.DOWNLOAD_DISCOVERY_WALKTHROUGH: (
        ScopingStage.DISCOVERY_WALKTHROUGH, "scoping_procedure", "POST",
        "/download-discovery-walkthrough",
        BodyType.JSON, ("report_title", "sections"), (), "planNumber",
    ),
    ScopingAction.DOWNLOAD_INSCOPE_OUTSCOPE: (
        ScopingStage.SCOPING_RECOMMENDATION, "scoping_procedure", "POST",
        "/download-inscope-outscope",
        BodyType.JSON, ("inscope", "outscope"), (), "planNumber",
    ),
    ScopingAction.DOWNLOAD_TEST_STEPS: (
        ScopingStage.TEST_STEPS, "scoping_procedure", "POST",
        "/download-test-steps",
        BodyType.JSON, ("test_steps",), (), "planNumber",
    ),
    ScopingAction.DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT: (
        ScopingStage.PRELIMINARY_RESEARCH, "scoping_summary", "POST",
        "/download",
        BodyType.JSON, (), (), "plan_number",
    ),
    ScopingAction.DOWNLOAD_SCOPING_DOCUMENT: (
        ScopingStage.TEST_STEPS, "scoping_procedure", "POST",
        "/download-scoping-document",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.GENERATE_SCOPING_DOCUMENT: (
        ScopingStage.TEST_STEPS, "scoping_procedure", "POST",
        "/generate-scoping-document",
        BodyType.JSON, (), (), "planNumber",
    ),
    ScopingAction.UPDATE_SCOPING_DOCUMENT: (
        ScopingStage.TEST_STEPS, "scoping_procedure", "PUT",
        "/update-scoping-document",
        BodyType.JSON, ("document",), (), "planNumber",
    ),
}


class TestRegistryShape:
    def test_registry_covers_every_scoping_action(self) -> None:
        assert set(ACTION_REGISTRY.keys()) == set(ScopingAction)

    def test_registry_covers_every_expected_action(self) -> None:
        assert set(ACTION_REGISTRY.keys()) == set(EXPECTED.keys())

    def test_all_entries_are_action_definitions(self) -> None:
        for defn in ACTION_REGISTRY.values():
            assert isinstance(defn, ActionDefinition)

    def test_action_key_matches_definition_action(self) -> None:
        for action, defn in ACTION_REGISTRY.items():
            assert defn.action == action

    def test_valid_service_names(self) -> None:
        allowed = {"noir", "nor", "qna", "data_extraction", "scoping_summary", "scoping_procedure"}
        for defn in ACTION_REGISTRY.values():
            assert defn.service_name in allowed

    def test_valid_http_methods(self) -> None:
        allowed = {"GET", "POST", "PUT", "PATCH", "DELETE"}
        for defn in ACTION_REGISTRY.values():
            assert defn.method in allowed

    def test_endpoints_start_with_slash(self) -> None:
        for defn in ACTION_REGISTRY.values():
            assert defn.endpoint.startswith("/")


class TestRegistryEntries:
    @pytest.mark.parametrize("action, expected", list(EXPECTED.items()), ids=lambda v: getattr(v, "name", ""))
    def test_entry_matches_expected(self, action: ScopingAction, expected: tuple) -> None:
        defn = ACTION_REGISTRY[action]
        (stage, service, method, endpoint, body_type,
         required, prereqs, plan_field) = expected
        assert defn.stage == stage
        assert defn.service_name == service
        assert defn.method == method
        assert defn.endpoint == endpoint
        assert defn.body_type == body_type
        assert defn.required_payload_fields == required
        assert defn.prerequisite_stages == prereqs
        assert defn.plan_number_field == plan_field

    def test_html_document_action_uses_raw_response_path(self) -> None:
        assert ACTION_REGISTRY[ScopingAction.GENERATE_SCOPING_DOCUMENT].is_download is True

    def test_document_download_uses_raw_response_path(self) -> None:
        assert ACTION_REGISTRY[ScopingAction.DOWNLOAD_SCOPING_DOCUMENT].is_download is True


class TestGetActionDefinition:
    def test_returns_registered_definition(self) -> None:
        defn = get_action_definition(ScopingAction.GENERATE_NOIR)
        assert defn is ACTION_REGISTRY[ScopingAction.GENERATE_NOIR]

    def test_returns_action_definition_instance(self) -> None:
        assert isinstance(
            get_action_definition(ScopingAction.EDIT_NOIR), ActionDefinition
        )

    def test_unknown_action_raises_key_error(self) -> None:
        class Fake:
            pass
        with pytest.raises(KeyError):
            get_action_definition(Fake())  # type: ignore[arg-type]
