import os
import sys

TEST_DIR = os.path.dirname(__file__)
MAIN_DIR = os.path.abspath(os.path.join(TEST_DIR, "..", "main"))

if MAIN_DIR not in sys.path:
    sys.path.insert(0, MAIN_DIR)
