"""Unit tests for `config.settings.Config`."""
from __future__ import annotations

import importlib
from pathlib import Path

import pytest


def _reload_settings(monkeypatch: pytest.MonkeyPatch, env: dict[str, str | None]) -> object:
    """Reload the settings module after applying environment overrides.

    A value of ``None`` deletes the variable from the environment.
    """
    for key, value in env.items():
        if value is None:
            monkeypatch.delenv(key, raising=False)
        else:
            monkeypatch.setenv(key, value)

    # Prevent dotenv from clobbering the monkeypatched values.
    monkeypatch.setattr("dotenv.load_dotenv", lambda *args, **kwargs: False)

    import config.settings as settings_module

    return importlib.reload(settings_module)


# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------


class TestModulePaths:
    def test_src_main_dir_is_parent_of_config(self) -> None:
        import config.settings as settings_module

        expected = Path(settings_module.__file__).resolve().parents[1]
        assert settings_module.SRC_MAIN_DIR == expected
        assert settings_module.SRC_MAIN_DIR.name == "main"

    def test_data_dir_is_under_src_main(self) -> None:
        import config.settings as settings_module

        assert settings_module.DATA_DIR_ == settings_module.SRC_MAIN_DIR / "data"


# ---------------------------------------------------------------------------
# Defaults (no env vars set)
# ---------------------------------------------------------------------------


class TestDefaults:
    @pytest.fixture
    def cfg(self, monkeypatch: pytest.MonkeyPatch):
        env = {
            "HTTP_PROXY": None,
            "http_proxy": None,
            "HTTPS_PROXY": None,
            "https_proxy": None,
            "NO_PROXY": None,
            "no_proxy": None,
            "HTTPX_TRUST_ENV": None,
            "HTTPX_VERIFY_SSL": None,
            "noirBaseURL": None,
            "norBaseURL": None,
            "qnaBaseURL": None,
            "dataExtractionBaseURL": None,
            "summaryBaseURL": None,
            "procedureBaseURL": None,
            "SUBAGENT_TIMEOUT_SECONDS": None,
        }
        return _reload_settings(monkeypatch, env).Config

    def test_proxy_defaults_empty(self, cfg) -> None:
        assert cfg.HTTP_PROXY == ""
        assert cfg.HTTPS_PROXY == ""
        assert cfg.NO_PROXY == ""

    def test_httpx_flags_default_false(self, cfg) -> None:
        assert cfg.HTTPX_TRUST_ENV is False
        assert cfg.HTTPX_VERIFY_SSL is False

    def test_base_url_defaults(self, cfg) -> None:
        assert cfg.NOIR_BASE_URL == "http://localhost:4001"
        assert cfg.DATA_EXTRACTION_BASE_URL == "http://localhost:4002"
        assert cfg.SUMMARY_AGENT_BASE_URL == "http://localhost:8000"
        assert cfg.PROCEDURE_AGENT_BASE_URL == "http://localhost:4003"
        assert cfg.NOR_BASE_URL == "http://localhost:4004"
        assert cfg.QNA_BASE_URL == "http://localhost:4005/qna"

    def test_timeout_default(self, cfg) -> None:
        assert cfg.SUBAGENT_TIMEOUT_SECONDS == 500.0
        assert isinstance(cfg.SUBAGENT_TIMEOUT_SECONDS, float)


# ---------------------------------------------------------------------------
# Proxy variables
# ---------------------------------------------------------------------------


class TestProxyVars:
    def test_uppercase_takes_precedence(self, monkeypatch: pytest.MonkeyPatch) -> None:
        cfg = _reload_settings(
            monkeypatch,
            {
                "HTTP_PROXY": "http://upper:1",
                "http_proxy": "http://lower:2",
                "HTTPS_PROXY": "https://upper:1",
                "https_proxy": "https://lower:2",
                "NO_PROXY": "a.com",
                "no_proxy": "b.com",
            },
        ).Config
        assert cfg.HTTP_PROXY == "http://upper:1"
        assert cfg.HTTPS_PROXY == "https://upper:1"
        assert cfg.NO_PROXY == "a.com"

    def test_falls_back_to_lowercase(self, monkeypatch: pytest.MonkeyPatch) -> None:
        cfg = _reload_settings(
            monkeypatch,
            {
                "HTTP_PROXY": None,
                "http_proxy": "http://lower:2",
                "HTTPS_PROXY": None,
                "https_proxy": "https://lower:2",
                "NO_PROXY": None,
                "no_proxy": "b.com",
            },
        ).Config
        assert cfg.HTTP_PROXY == "http://lower:2"
        assert cfg.HTTPS_PROXY == "https://lower:2"
        assert cfg.NO_PROXY == "b.com"


# ---------------------------------------------------------------------------
# httpx boolean flags
# ---------------------------------------------------------------------------


class TestHttpxFlags:
    @pytest.mark.parametrize(
        "raw, expected",
        [
            ("true", True),
            ("TRUE", True),
            ("True", True),
            ("false", False),
            ("FALSE", False),
            ("0", False),
            ("1", False),  # only literal "true" is truthy
            ("yes", False),
            ("", False),
        ],
    )
    def test_trust_env_parsing(
        self, monkeypatch: pytest.MonkeyPatch, raw: str, expected: bool
    ) -> None:
        cfg = _reload_settings(monkeypatch, {"HTTPX_TRUST_ENV": raw}).Config
        assert cfg.HTTPX_TRUST_ENV is expected

    @pytest.mark.parametrize(
        "raw, expected",
        [
            ("true", True),
            ("True", True),
            ("false", False),
            ("no", False),
            ("", False),
        ],
    )
    def test_verify_ssl_parsing(
        self, monkeypatch: pytest.MonkeyPatch, raw: str, expected: bool
    ) -> None:
        cfg = _reload_settings(monkeypatch, {"HTTPX_VERIFY_SSL": raw}).Config
        assert cfg.HTTPX_VERIFY_SSL is expected


# ---------------------------------------------------------------------------
# Base URL overrides
# ---------------------------------------------------------------------------


class TestBaseUrlOverrides:
    def test_all_base_urls_can_be_overridden(self, monkeypatch: pytest.MonkeyPatch) -> None:
        cfg = _reload_settings(
            monkeypatch,
            {
                "noirBaseURL": "http://noir:9001",
                "norBaseURL": "http://nor:9005",
                "qnaBaseURL": "http://qna:9006/qna",
                "dataExtractionBaseURL": "http://de:9002",
                "summaryBaseURL": "http://sum:9003",
                "procedureBaseURL": "http://proc:9004",
            },
        ).Config
        assert cfg.NOIR_BASE_URL == "http://noir:9001"
        assert cfg.NOR_BASE_URL == "http://nor:9005"
        assert cfg.QNA_BASE_URL == "http://qna:9006/qna"
        assert cfg.DATA_EXTRACTION_BASE_URL == "http://de:9002"
        assert cfg.SUMMARY_AGENT_BASE_URL == "http://sum:9003"
        assert cfg.PROCEDURE_AGENT_BASE_URL == "http://proc:9004"


# ---------------------------------------------------------------------------
# Timeout
# ---------------------------------------------------------------------------


class TestSubagentTimeout:
    @pytest.mark.parametrize("raw, expected", [("30", 30.0), ("12.5", 12.5), ("0", 0.0)])
    def test_valid_values(
        self, monkeypatch: pytest.MonkeyPatch, raw: str, expected: float
    ) -> None:
        cfg = _reload_settings(monkeypatch, {"SUBAGENT_TIMEOUT_SECONDS": raw}).Config
        assert cfg.SUBAGENT_TIMEOUT_SECONDS == expected
        assert isinstance(cfg.SUBAGENT_TIMEOUT_SECONDS, float)

    def test_invalid_value_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        with pytest.raises(ValueError):
            _reload_settings(monkeypatch, {"SUBAGENT_TIMEOUT_SECONDS": "not-a-number"})
