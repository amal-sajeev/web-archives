"""Unit tests for `model.orchestration`."""
from __future__ import annotations

import dataclasses

import pytest

from model.gateway_request import ScopingAction
from model.orchestration import (
    ActionDefinition,
    BodyType,
    OrchestrationResult,
    ScopingStage,
    StageStatus,
)


class TestEnums:
    @pytest.mark.parametrize(
        "member, value",
        [
            (ScopingStage.NOIR, "NOIR"),
            (ScopingStage.DATA_EXTRACTION, "DATA_EXTRACTION"),
            (ScopingStage.PRELIMINARY_RESEARCH, "PRELIMINARY_RESEARCH"),
            (ScopingStage.DISCOVERY_WALKTHROUGH, "DISCOVERY_WALKTHROUGH"),
            (ScopingStage.SCOPING_RECOMMENDATION, "SCOPING_RECOMMENDATION"),
            (ScopingStage.TEST_STEPS, "TEST_STEPS"),
        ],
    )
    def test_scoping_stage_values(self, member: ScopingStage, value: str) -> None:
        assert member.value == value
        assert isinstance(member, str)

    @pytest.mark.parametrize(
        "member, value",
        [
            (StageStatus.NOT_STARTED, "NOT_STARTED"),
            (StageStatus.IN_PROGRESS, "IN_PROGRESS"),
            (StageStatus.COMPLETED, "COMPLETED"),
            (StageStatus.FAILED, "FAILED"),
        ],
    )
    def test_stage_status_values(self, member: StageStatus, value: str) -> None:
        assert member.value == value
        assert isinstance(member, str)

    @pytest.mark.parametrize(
        "member, value",
        [
            (BodyType.JSON, "json"),
            (BodyType.FORM_URLENCODED, "form-urlencoded"),
            (BodyType.MULTIPART_FORM, "multipart-form"),
        ],
    )
    def test_body_type_values(self, member: BodyType, value: str) -> None:
        assert member.value == value
        assert isinstance(member, str)


class TestActionDefinition:
    def _base_kwargs(self) -> dict:
        return {
            "action": ScopingAction.GENERATE_NOIR,
            "stage": ScopingStage.NOIR,
            "service_name": "noir",
            "method": "POST",
            "endpoint": "/generate",
        }

    def test_defaults(self) -> None:
        ad = ActionDefinition(**self._base_kwargs())
        assert ad.body_type == BodyType.JSON
        assert ad.required_payload_fields == ()
        assert ad.prerequisite_stages == ()
        assert ad.allow_missing_plan_number is False
        assert ad.plan_number_field == "planNumber"

    def test_custom_fields(self) -> None:
        ad = ActionDefinition(
            **self._base_kwargs(),
            body_type=BodyType.MULTIPART_FORM,
            required_payload_fields=("files",),
            prerequisite_stages=(ScopingStage.NOIR,),
            allow_missing_plan_number=True,
            plan_number_field="plan_id",
        )
        assert ad.body_type == BodyType.MULTIPART_FORM
        assert ad.required_payload_fields == ("files",)
        assert ad.prerequisite_stages == (ScopingStage.NOIR,)
        assert ad.allow_missing_plan_number is True
        assert ad.plan_number_field == "plan_id"

    def test_is_frozen(self) -> None:
        ad = ActionDefinition(**self._base_kwargs())
        with pytest.raises(dataclasses.FrozenInstanceError):
            ad.method = "GET"  # type: ignore[misc]

    def test_is_hashable(self) -> None:
        ad = ActionDefinition(**self._base_kwargs())
        assert isinstance(hash(ad), int)
        assert {ad, ad} == {ad}

    def test_equality(self) -> None:
        a = ActionDefinition(**self._base_kwargs())
        b = ActionDefinition(**self._base_kwargs())
        c = ActionDefinition(**{**self._base_kwargs(), "method": "GET"})
        assert a == b
        assert a != c


class TestOrchestrationResult:
    def _make(self, **overrides) -> OrchestrationResult:
        defaults = {
            "planNumber": "P1",
            "action": ScopingAction.GENERATE_NOIR,
            "stage": ScopingStage.NOIR,
            "status": StageStatus.COMPLETED,
            "response": {"ok": True},
        }
        defaults.update(overrides)
        return OrchestrationResult(**defaults)

    def test_to_dict_serializes_enum_values(self) -> None:
        result = self._make()
        assert result.to_dict() == {
            "planNumber": "P1",
            "action": "GENERATE_NOIR",
            "stage": "NOIR",
            "status": "COMPLETED",
            "response": {"ok": True},
        }

    def test_to_dict_allows_none_plan_number(self) -> None:
        result = self._make(planNumber=None)
        assert result.to_dict()["planNumber"] is None

    def test_to_dict_returns_new_dict_each_call(self) -> None:
        result = self._make()
        first = result.to_dict()
        second = result.to_dict()
        assert first == second
        assert first is not second

    def test_response_reference_preserved(self) -> None:
        payload = {"data": [1, 2]}
        result = self._make(response=payload)
        assert result.to_dict()["response"] is payload

    def test_is_frozen(self) -> None:
        result = self._make()
        with pytest.raises(dataclasses.FrozenInstanceError):
            result.status = StageStatus.FAILED  # type: ignore[misc]

    @pytest.mark.parametrize("status", list(StageStatus))
    def test_all_statuses_serialize(self, status: StageStatus) -> None:
        result = self._make(status=status)
        assert result.to_dict()["status"] == status.value
