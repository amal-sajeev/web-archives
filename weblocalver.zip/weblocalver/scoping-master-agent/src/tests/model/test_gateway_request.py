"""Unit tests for `model.gateway_request`."""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from model.gateway_request import GatewayRequest, ScopingAction


class TestScopingActionEnum:
    def test_is_str_enum(self) -> None:
        assert isinstance(ScopingAction.GENERATE_NOIR, str)
        assert ScopingAction.GENERATE_NOIR == "GENERATE_NOIR"


    def test_values_match_names(self) -> None:
        for member in ScopingAction:
            assert member.value == member.name

    def test_expected_members_present(self) -> None:
        expected = {
            "GET_NOIR",
            "GENERATE_NOIR",
            "HUMAN_EDIT",
            "EDIT_NOIR",
            "SEND_NOIR_EMAIL",
            "GET_NOR",
            "GENERATE_NOR",
            "EDIT_NOR",
            "HUMAN_EDIT_NOR",
            "SKIP_NOR",
            "SKIP_NOIR",
            "SEND_NOR_EMAIL",
            "QNA_CHAT",
            "DATA_EXTRACTION",
            "GET_DATA_EXTRACTION_STATUS",
            "GET_PLAN_AVAILABILITY",
            "GET_PLAN_ARTIFACT",
            "RUN_ANALYTICS",
            "GET_CITATION_DOCUMENT",
            "GET_PRELIMINARY_RESEARCH_DOCUMENT",
            "EDIT_PRELIMINARY_RESEARCH_DOCUMENT",
            "GENERATE_DISCOVERY_WALKTHROUGH",
            "GET_DISCOVERY_WALKTHROUGH",
            "UPDATE_DISCOVERY_WALKTHROUGH",
            "GENERATE_INSCOPE_OUTSCOPE",
            "GET_INSCOPE_OUTSCOPE",
            "UPDATE_INSCOPE_OUTSCOPE",
            "UPLOAD_MEETING_NOTES",
            "GET_MEETING_NOTES_SUMMARY",
            "GENERATE_TEST_STEPS",
            "GET_TEST_STEPS",
            "UPDATE_TEST_STEPS",
            "DOWNLOAD_DISCOVERY_WALKTHROUGH",
            "DOWNLOAD_INSCOPE_OUTSCOPE",
            "DOWNLOAD_TEST_STEPS",
            "DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT",
            "DOWNLOAD_SCOPING_DOCUMENT",
            "GENERATE_SCOPING_DOCUMENT",
            "UPDATE_SCOPING_DOCUMENT",
            "QNA_LIST_DOCUMENTS",
            "QNA_DELETE_DOCUMENTS"
        }
        assert {m.name for m in ScopingAction} == expected


class TestGatewayRequestDefaults:
    def test_payload_defaults_to_empty_dict(self) -> None:
        req = GatewayRequest(planNumber="P1", action=ScopingAction.GENERATE_NOIR)
        assert req.payload == {}

    def test_independent_default_payload_per_instance(self) -> None:
        a = GatewayRequest(planNumber="P1", action=ScopingAction.GENERATE_NOIR)
        b = GatewayRequest(planNumber="P2", action=ScopingAction.GENERATE_NOIR)
        a.payload["k"] = "v"
        assert b.payload == {}

    def test_accepts_string_action(self) -> None:
        req = GatewayRequest(planNumber="P1", action="EDIT_NOIR")
        assert req.action == ScopingAction.EDIT_NOIR

    def test_invalid_action_rejected(self) -> None:
        with pytest.raises(ValidationError):
            GatewayRequest(planNumber="P1", action="NOT_AN_ACTION")

    def test_missing_action_rejected(self) -> None:
        with pytest.raises(ValidationError):
            GatewayRequest(planNumber="P1")  # type: ignore[call-arg]


class TestPlanNumberValidation:
    @pytest.mark.parametrize("plan_number", [None, "", "   "])
    def test_missing_or_blank_plan_number_rejected(self, plan_number) -> None:
        with pytest.raises(ValidationError) as exc:
            GatewayRequest(planNumber=plan_number, action=ScopingAction.GENERATE_NOIR)
        assert "planNumber is required" in str(exc.value)

    def test_valid_plan_number_accepted(self) -> None:
        req = GatewayRequest(planNumber="P123", action=ScopingAction.EDIT_NOIR)
        assert req.planNumber == "P123"

    def test_plan_number_with_whitespace_padding_accepted(self) -> None:
        # non-whitespace content passes; value is preserved (not stripped)
        req = GatewayRequest(planNumber="  P123  ", action=ScopingAction.EDIT_NOIR)
        assert req.planNumber == "  P123  "


class TestCitationDocumentException:
    def test_missing_plan_number_allowed_with_document_uri(self) -> None:
        req = GatewayRequest(
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"document_uri": "gs://bucket/doc.pdf"},
        )
        assert req.planNumber is None
        assert req.payload["document_uri"] == "gs://bucket/doc.pdf"

    def test_blank_plan_number_allowed_with_document_uri(self) -> None:
        req = GatewayRequest(
            planNumber="   ",
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"document_uri": "gs://bucket/doc.pdf"},
        )
        assert req.payload["document_uri"] == "gs://bucket/doc.pdf"

    def test_missing_plan_number_and_missing_document_uri_rejected(self) -> None:
        with pytest.raises(ValidationError):
            GatewayRequest(action=ScopingAction.GET_CITATION_DOCUMENT, payload={})

    def test_missing_plan_number_and_empty_document_uri_rejected(self) -> None:
        with pytest.raises(ValidationError):
            GatewayRequest(
                action=ScopingAction.GET_CITATION_DOCUMENT,
                payload={"document_uri": ""},
            )

    def test_exception_only_applies_to_get_citation_document(self) -> None:
        with pytest.raises(ValidationError):
            GatewayRequest(
                action=ScopingAction.GENERATE_NOIR,
                payload={"document_uri": "gs://bucket/doc.pdf"},
            )

    def test_plan_number_with_citation_and_document_uri_ok(self) -> None:
        req = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"document_uri": "gs://bucket/doc.pdf"},
        )
        assert req.planNumber == "P1"


class TestQnaChatException:
    def test_missing_plan_number_allowed_for_qna_chat(self) -> None:
        req = GatewayRequest(
            action=ScopingAction.QNA_CHAT,
            payload={"question": "What is in scope?"},
        )
        assert req.planNumber is None

    def test_blank_plan_number_allowed_for_qna_chat(self) -> None:
        req = GatewayRequest(
            planNumber="   ",
            action=ScopingAction.QNA_CHAT,
            payload={"question": "What is in scope?"},
        )
        assert req.payload["question"] == "What is in scope?"

    def test_plan_number_provided_for_qna_chat_ok(self) -> None:
        req = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.QNA_CHAT,
            payload={"question": "What is in scope?"},
        )
        assert req.planNumber == "P1"
