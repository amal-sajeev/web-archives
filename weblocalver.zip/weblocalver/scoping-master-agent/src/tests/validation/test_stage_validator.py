"""Unit tests for `validation.stage_validator.StageValidator`."""
from __future__ import annotations

import pytest

from model.gateway_request import ScopingAction
from model.orchestration import ActionDefinition, BodyType, ScopingStage
from validation.stage_validator import StageValidator


def _action_def(
    *, prerequisite_stages: tuple[ScopingStage, ...] = ()
) -> ActionDefinition:
    return ActionDefinition(
        action=ScopingAction.DATA_EXTRACTION,
        stage=ScopingStage.DATA_EXTRACTION,
        service_name="data_extraction",
        method="POST",
        endpoint="/x",
        body_type=BodyType.JSON,
        prerequisite_stages=prerequisite_stages,
    )


@pytest.fixture
def validator() -> StageValidator:
    return StageValidator()


class TestStageValidator:
    @pytest.mark.parametrize("plan_number", [None, ""])
    def test_short_circuits_when_plan_number_missing(
        self, validator: StageValidator, plan_number
    ) -> None:
        # Even with prerequisites, a missing plan_number bypasses the check.
        action = _action_def(prerequisite_stages=(ScopingStage.NOIR,))
        assert validator.validate(plan_number, action) is None

    def test_short_circuits_when_no_prerequisites(
        self, validator: StageValidator
    ) -> None:
        action = _action_def(prerequisite_stages=())
        assert validator.validate("P1", action) is None

    def test_passes_when_no_incomplete_stages(
        self, validator: StageValidator
    ) -> None:
        # Audit lookup is currently commented out, so incomplete_stages is
        # always empty and validation passes.
        action = _action_def(
            prerequisite_stages=(ScopingStage.NOIR, ScopingStage.DATA_EXTRACTION)
        )
        assert validator.validate("P1", action) is None

    def test_raises_permission_error_when_incomplete_stages_exist(
        self, validator: StageValidator, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Simulate what the validator will look like once audit lookups are
        # re-enabled by monkeypatching the `validate` implementation to force a
        # non-empty `incomplete_stages` list.
        def fake_validate(self, plan_number, action_definition):
            incomplete = [s.value for s in action_definition.prerequisite_stages]
            if incomplete:
                raise PermissionError(
                    "Previous stage(s) must be completed before this action: "
                    + ", ".join(incomplete)
                )

        monkeypatch.setattr(StageValidator, "validate", fake_validate)
        action = _action_def(
            prerequisite_stages=(ScopingStage.NOIR, ScopingStage.DATA_EXTRACTION)
        )
        with pytest.raises(PermissionError) as exc:
            StageValidator().validate("P1", action)
        assert "NOIR" in str(exc.value)
        assert "DATA_EXTRACTION" in str(exc.value)

    def test_return_type_is_none(self, validator: StageValidator) -> None:
        action = _action_def(prerequisite_stages=(ScopingStage.NOIR,))
        assert validator.validate("P1", action) is None
