"""Unit tests for `validation.request_validator.RequestValidator`."""
from __future__ import annotations

import pytest

from model.gateway_request import GatewayRequest, ScopingAction
from model.orchestration import ActionDefinition, BodyType, ScopingStage
from validation.request_validator import RequestValidator


def _action_def(
    *,
    action: ScopingAction = ScopingAction.GENERATE_NOIR,
    required_payload_fields: tuple[str, ...] = (),
) -> ActionDefinition:
    return ActionDefinition(
        action=action,
        stage=ScopingStage.NOIR,
        service_name="noir",
        method="POST",
        endpoint="/x",
        body_type=BodyType.JSON,
        required_payload_fields=required_payload_fields,
    )


@pytest.fixture
def validator() -> RequestValidator:
    return RequestValidator()


class TestRequiredPayloadFields:
    def test_passes_when_no_required_fields(self, validator: RequestValidator) -> None:
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )
        validator.validate(request, _action_def())  # no raise

    def test_passes_when_all_required_fields_present(self, validator: RequestValidator) -> None:
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.EDIT_NOIR,
            payload={"original_data": "d", "original_text": "t", "user_instruction": "u"},
        )
        action = _action_def(
            action=ScopingAction.EDIT_NOIR,
            required_payload_fields=("original_data", "original_text", "user_instruction"),
        )
        validator.validate(request, action)

    @pytest.mark.parametrize(
        "payload, missing",
        [
            ({}, ["original_data", "original_text"]),
            ({"original_data": "d"}, ["original_text"]),
            ({"original_data": "d", "original_text": None}, ["original_text"]),
            ({"original_data": "d", "original_text": ""}, ["original_text"]),
        ],
    )
    def test_missing_or_blank_fields_raise(
        self,
        validator: RequestValidator,
        payload: dict,
        missing: list[str],
    ) -> None:
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.EDIT_NOIR, payload=payload
        )
        action = _action_def(
            action=ScopingAction.EDIT_NOIR,
            required_payload_fields=("original_data", "original_text"),
        )
        with pytest.raises(ValueError, match="Missing required payload field") as exc:
            validator.validate(request, action)
        for name in missing:
            assert name in str(exc.value)

    def test_falsy_but_valid_values_accepted(self, validator: RequestValidator) -> None:
        # Only None and "" are treated as missing; 0/False/[] are valid.
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.EDIT_NOIR,
            payload={"a": 0, "b": False, "c": []},
        )
        action = _action_def(
            action=ScopingAction.EDIT_NOIR, required_payload_fields=("a", "b", "c")
        )
        validator.validate(request, action)


class TestUpdateActionPayload:
    def test_update_action_with_empty_payload_rejected(
        self, validator: RequestValidator
    ) -> None:
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.UPDATE_TEST_STEPS,
            payload={"test_steps": "x"},
        )
        # Force empty payload post-validation to hit the branch.
        request.payload.clear()
        action = _action_def(action=ScopingAction.UPDATE_TEST_STEPS)
        with pytest.raises(ValueError, match="Update actions require a non-empty payload"):
            validator.validate(request, action)

    def test_update_action_with_payload_passes(self, validator: RequestValidator) -> None:
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.UPDATE_TEST_STEPS,
            payload={"test_steps": ["step1"]},
        )
        validator.validate(request, _action_def(action=ScopingAction.UPDATE_TEST_STEPS))

    def test_non_update_action_with_empty_payload_ok(
        self, validator: RequestValidator
    ) -> None:
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )
        validator.validate(request, _action_def())


class TestCitationRequest:
    def test_document_uri_only_ok(self, validator: RequestValidator) -> None:
        request = GatewayRequest(
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"document_uri": "gs://b/o"},
        )
        validator.validate(
            request, _action_def(action=ScopingAction.GET_CITATION_DOCUMENT)
        )

    def test_chunk_id_with_plan_number_ok(self, validator: RequestValidator) -> None:
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"chunk_id": "c1"},
        )
        validator.validate(
            request, _action_def(action=ScopingAction.GET_CITATION_DOCUMENT)
        )

    def test_missing_both_identifiers_rejected(self, validator: RequestValidator) -> None:
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={},
        )
        with pytest.raises(
            ValueError, match="Either payload.chunk_id or payload.document_uri"
        ):
            validator.validate(
                request, _action_def(action=ScopingAction.GET_CITATION_DOCUMENT)
            )

    def test_chunk_id_without_plan_number_rejected(
        self, validator: RequestValidator
    ) -> None:
        # Bypass GatewayRequest model validator to hit the branch.
        request = GatewayRequest.model_construct(
            planNumber=None,
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"chunk_id": "c1"},
        )
        with pytest.raises(
            ValueError, match="planNumber is required when payload.chunk_id"
        ):
            validator.validate(
                request, _action_def(action=ScopingAction.GET_CITATION_DOCUMENT)
            )

    def test_non_citation_action_skips_citation_validation(
        self, validator: RequestValidator
    ) -> None:
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GENERATE_NOIR,
            payload={},
        )
        validator.validate(request, _action_def())  # no raise


class TestRequiredFieldsCheckedFirst:
    def test_missing_field_error_precedes_update_error(
        self, validator: RequestValidator
    ) -> None:
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.UPDATE_TEST_STEPS,
            payload={"test_steps": ""},  # blank -> missing
        )
        action = _action_def(
            action=ScopingAction.UPDATE_TEST_STEPS,
            required_payload_fields=("test_steps",),
        )
        with pytest.raises(ValueError, match="Missing required payload field"):
            validator.validate(request, action)
