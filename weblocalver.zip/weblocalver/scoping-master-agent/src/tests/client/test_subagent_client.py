"""Unit tests for `client.subagent_client.SubagentClient`."""
from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from client.subagent_client import SubagentClient
from config.settings import Config
from model.gateway_request import ScopingAction
from model.orchestration import ActionDefinition, BodyType, ScopingStage


def _run(coro):
    return asyncio.run(coro)


def _make_action(
    *,
    service_name: str = "noir",
    method: str = "POST",
    endpoint: str = "/v1/do",
    body_type: BodyType = BodyType.JSON,
) -> ActionDefinition:
    return ActionDefinition(
        action=ScopingAction.GENERATE_NOIR,
        stage=ScopingStage.NOIR,
        service_name=service_name,
        method=method,
        endpoint=endpoint,
        body_type=body_type,
    )


def _mock_response(*, status_code: int = 200, json_data: Any = None, content: bytes = b"{}") -> MagicMock:
    response = MagicMock(spec=httpx.Response)
    response.status_code = status_code
    response.content = content
    response.json = MagicMock(return_value=json_data if json_data is not None else {})
    response.raise_for_status = MagicMock()
    return response


class _AsyncClientCM:
    def __init__(self, response: MagicMock) -> None:
        self.response = response
        self.request = AsyncMock(return_value=response)

    async def __aenter__(self) -> "_AsyncClientCM":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None


@pytest.fixture
def client() -> SubagentClient:
    return SubagentClient()


class TestInit:
    def test_base_urls_populated_from_config(self, client: SubagentClient) -> None:
        assert client._base_urls["noir"] == Config.NOIR_BASE_URL
        assert client._base_urls["nor"] == Config.NOR_BASE_URL
        assert client._base_urls["qna"] == Config.QNA_BASE_URL
        assert client._base_urls["data_extraction"] == Config.DATA_EXTRACTION_BASE_URL
        assert client._base_urls["scoping_summary"] == Config.SUMMARY_AGENT_BASE_URL
        assert client._base_urls["scoping_procedure"] == Config.PROCEDURE_AGENT_BASE_URL


class TestRequestKwargs:
    def test_json_body(self, client: SubagentClient) -> None:
        action = _make_action(body_type=BodyType.JSON)
        assert client._request_kwargs(action, {"a": 1}) == {"json": {"a": 1}}

    def test_form_urlencoded_body(self, client: SubagentClient) -> None:
        action = _make_action(body_type=BodyType.FORM_URLENCODED)
        assert client._request_kwargs(action, {"a": 1}) == {"data": {"a": 1}}

    def test_get_uses_query_params(self, client: SubagentClient) -> None:
        action = _make_action(method="GET")
        assert client._request_kwargs(action, {"a": 1}) == {"params": {"a": 1}}

    def test_get_with_empty_body_sends_no_params(self, client: SubagentClient) -> None:
        action = _make_action(method="GET")
        assert client._request_kwargs(action, {}) == {}

    def test_multipart_form_body(self, client: SubagentClient) -> None:
        action = _make_action(body_type=BodyType.MULTIPART_FORM)
        body = {
            "planNumber": "P1",
            "files": [
                {"filename": "a.txt", "content": b"hello", "content_type": "text/plain"},
            ],
        }
        kwargs = client._request_kwargs(action, body)
        assert kwargs["data"] == {"planNumber": "P1"}
        assert kwargs["files"] == [("files", ("a.txt", b"hello", "text/plain"))]


class TestRenderEndpoint:
    def test_no_placeholders_returns_template_and_body_unchanged(self) -> None:
        rendered, remaining = SubagentClient._render_endpoint("/foo/bar", {"a": 1})
        assert rendered == "/foo/bar"
        assert remaining == {"a": 1}

    def test_substitutes_placeholder_and_removes_from_body(self) -> None:
        rendered, remaining = SubagentClient._render_endpoint(
            "/noir/{plan_item_number}", {"plan_item_number": "P123", "extra": "x"}
        )
        assert rendered == "/noir/P123"
        assert remaining == {"extra": "x"}

    def test_url_encodes_values(self) -> None:
        rendered, _ = SubagentClient._render_endpoint(
            "/items/{id}", {"id": "a b/c"}
        )
        assert rendered == "/items/a%20b%2Fc"

    @pytest.mark.parametrize("value", [None, ""])
    def test_missing_or_blank_param_raises(self, value) -> None:
        with pytest.raises(ValueError, match="Missing path parameter: id"):
            SubagentClient._render_endpoint("/items/{id}", {"id": value})

    def test_absent_param_raises(self) -> None:
        with pytest.raises(ValueError, match="Missing path parameter: id"):
            SubagentClient._render_endpoint("/items/{id}", {})


class TestNormalizeFiles:
    def test_defaults_content_type(self) -> None:
        result = SubagentClient._normalize_files([{"filename": "a.bin", "content": b"x"}])
        assert result == [("files", ("a.bin", b"x", "application/octet-stream"))]

    @pytest.mark.parametrize("files", [None, [], "not-a-list", 42])
    def test_rejects_non_list_or_empty(self, files: Any) -> None:
        with pytest.raises(ValueError, match="non-empty list"):
            SubagentClient._normalize_files(files)

    def test_rejects_non_dict_item(self) -> None:
        with pytest.raises(ValueError, match="object with filename"):
            SubagentClient._normalize_files(["oops"])

    @pytest.mark.parametrize(
        "item",
        [
            {"content": b"x"},
            {"filename": "a.txt"},
            {"filename": "", "content": b"x"},
        ],
    )
    def test_rejects_missing_fields(self, item: dict[str, Any]) -> None:
        with pytest.raises(ValueError, match="filename and content"):
            SubagentClient._normalize_files([item])


class TestCall:
    def test_success_returns_dict_payload(self, client: SubagentClient) -> None:
        response = _mock_response(json_data={"ok": True}, content=b'{"ok": true}')
        cm = _AsyncClientCM(response)
        action = _make_action(service_name="noir", endpoint="/run")

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            result = _run(client.call(action, {"a": 1}))

        assert result == {"ok": True}
        cm.request.assert_awaited_once()
        args, kwargs = cm.request.call_args
        assert args[0] == "POST"
        assert args[1].endswith("/run")
        assert kwargs == {"json": {"a": 1}}

    def test_strips_trailing_slash_from_base_url(self, client: SubagentClient) -> None:
        client._base_urls["noir"] = "http://example.com/"
        response = _mock_response(json_data={}, content=b"{}")
        cm = _AsyncClientCM(response)
        action = _make_action(endpoint="/x")

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            _run(client.call(action, {}))

        assert cm.request.call_args.args[1] == "http://example.com/x"

    def test_empty_content_returns_empty_dict(self, client: SubagentClient) -> None:
        response = _mock_response(content=b"")
        cm = _AsyncClientCM(response)
        action = _make_action()

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            result = _run(client.call(action, {}))

        assert result == {}
        response.json.assert_not_called()

    def test_non_dict_payload_wrapped_in_data(self, client: SubagentClient) -> None:
        response = _mock_response(json_data=[1, 2, 3], content=b"[1,2,3]")
        cm = _AsyncClientCM(response)
        action = _make_action()

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            result = _run(client.call(action, {}))

        assert result == {"data": [1, 2, 3]}

    def test_transport_error_reraised(self, client: SubagentClient) -> None:
        cm = _AsyncClientCM(_mock_response())
        cm.request = AsyncMock(side_effect=httpx.ConnectError("boom"))
        action = _make_action()

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            with pytest.raises(httpx.ConnectError):
                _run(client.call(action, {}))

    def test_http_status_error_reraised(self, client: SubagentClient) -> None:
        response = _mock_response(status_code=500, content=b"{}")
        response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "server error", request=MagicMock(), response=response
        )
        cm = _AsyncClientCM(response)
        action = _make_action()

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            with pytest.raises(httpx.HTTPStatusError):
                _run(client.call(action, {}))

    def test_invalid_json_reraised(self, client: SubagentClient) -> None:
        response = _mock_response(content=b"not-json")
        response.json.side_effect = ValueError("bad json")
        cm = _AsyncClientCM(response)
        action = _make_action()

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            with pytest.raises(ValueError):
                _run(client.call(action, {}))

    def test_unknown_service_raises_key_error(self, client: SubagentClient) -> None:
        action = _make_action(service_name="unknown_service")
        with pytest.raises(KeyError):
            _run(client.call(action, {}))

    def test_async_client_configured_from_settings(self, client: SubagentClient) -> None:
        response = _mock_response(json_data={}, content=b"{}")
        cm = _AsyncClientCM(response)
        action = _make_action()

        with patch("client.subagent_client.httpx.AsyncClient") as async_client_cls:
            async_client_cls.return_value = cm
            _run(client.call(action, {}))

        _, kwargs = async_client_cls.call_args
        assert kwargs["timeout"] == Config.SUBAGENT_TIMEOUT_SECONDS
        assert kwargs["trust_env"] == Config.HTTPX_TRUST_ENV
        assert kwargs["verify"] == Config.HTTPX_VERIFY_SSL

    def test_get_substitutes_path_param_and_uses_remaining_as_query(
        self, client: SubagentClient
    ) -> None:
        response = _mock_response(json_data={"ok": True}, content=b"{}")
        cm = _AsyncClientCM(response)
        action = _make_action(method="GET", endpoint="/noir/{plan_item_number}")
        body = {"plan_item_number": "P123", "verbose": "true"}

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            _run(client.call(action, body))

        args, kwargs = cm.request.call_args
        assert args[0] == "GET"
        assert args[1].endswith("/noir/P123")
        assert kwargs == {"params": {"verbose": "true"}}

    def test_multipart_request_forwards_files(self, client: SubagentClient) -> None:
        response = _mock_response(json_data={"ok": True}, content=b"{}")
        cm = _AsyncClientCM(response)
        action = _make_action(body_type=BodyType.MULTIPART_FORM)
        body = {
            "planNumber": "P1",
            "files": [{"filename": "n.txt", "content": b"data"}],
        }

        with patch("client.subagent_client.httpx.AsyncClient", return_value=cm):
            _run(client.call(action, body))

        kwargs = cm.request.call_args.kwargs
        assert kwargs["data"] == {"planNumber": "P1"}
        assert kwargs["files"] == [("files", ("n.txt", b"data", "application/octet-stream"))]
