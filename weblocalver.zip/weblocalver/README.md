# scoping-service

This is the repository for scoping-service, a set of FastAPI microservices that automate the CT&A/GBSA scoping workflow: extracting source data, generating procedural artifacts (meeting notes, in-scope/out-scope, discovery walkthrough, test steps), producing analytical summaries, and orchestrating the end-to-end flow.

## Modules

| Module                                                                 | Description                                                                                          |
| ---------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| [scoping-master-agent](scoping-master-agent/README.md)                 | Orchestrates the end-to-end scoping workflow and routes requests to the subagents below              |
| [scoping-dataextraction-agent](scoping-dataextraction-agent/README.md) | Extracts scoping data from source systems (GFMS, DBaware, DBGRC, LRR)                                |
| [scoping-procedure-agent](scoping-procedure-agent/README.md)           | Generates/manages meeting notes, in-scope/out-scope, discovery walkthrough, and test steps artifacts |
| [scoping-summary-agent](scoping-summary-agent/README.md)               | Analyzes extracted data and generates preliminary research documents                                 |

Each module has its own `Dockerfile`, `helm-chart/`, and `requirements.txt` for independent build/deploy. See each module's README for its endpoints and configuration.
