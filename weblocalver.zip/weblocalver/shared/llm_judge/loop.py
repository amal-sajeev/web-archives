"""Bounded review/revision orchestration without model or schema dependencies.

Callers own prompts, structured review schemas, model initialization, and candidate
generation. This module only coordinates review results and corrective revisions.
"""

from __future__ import annotations

import logging
import os
import threading
from dataclasses import dataclass
from typing import Any, Callable, Generic, Literal, TypeVar


CandidateT = TypeVar("CandidateT")
ReviewT = TypeVar("ReviewT")
FailurePolicy = Literal["fail_open", "fail_closed"]

logger = logging.getLogger(__name__)
_debug_lock = threading.Lock()


def _env_flag(*names: str, default: bool = False) -> bool:
    for name in names:
        value = os.getenv(name)
        if value is None:
            continue
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return default


def _judge_debug_enabled() -> bool:
    return _env_flag("LLM_JUDGE_DEBUG", default=False)


def _debug_print(stage: str, label: str, _value: Any) -> None:
    if not _judge_debug_enabled():
        return
    with _debug_lock:
        print(f"LLM JUDGE DEBUG stage={stage} event={label}", flush=True)
        logger.debug(
            "LLM_JUDGE_DEBUG stage=%s event=%s",
            stage,
            label,
        )


class ReviewLoopError(RuntimeError):
    """Raised when a review or revision fails under the fail-closed policy."""


@dataclass(frozen=True)
class ReviewLoopResult(Generic[CandidateT, ReviewT]):
    """Candidate and minimal, content-free loop status for caller observability."""

    candidate: CandidateT
    review: ReviewT | None
    approved: bool
    revisions: int
    outcome: Literal[
        "approved", "revision_limit", "no_feedback", "review_failure", "revision_failure"
    ]


def review_and_revise(
    candidate: CandidateT,
    *,
    reviewer: Callable[[CandidateT], ReviewT],
    reviser: Callable[[CandidateT, ReviewT], CandidateT],
    approved: Callable[[ReviewT], bool],
    has_feedback: Callable[[ReviewT], bool],
    stage: str,
    max_revisions: int = 1,
    failure_policy: FailurePolicy = "fail_open",
    verify_final_revision: bool = True,
    log: logging.Logger | None = None,
) -> ReviewLoopResult[CandidateT, ReviewT]:
    """Review a candidate and make at most ``max_revisions`` corrective drafts.

    ``reviewer`` and ``reviser`` are application-provided callbacks. A returned
    candidate is therefore only as schema-valid as the caller's generator makes
    it. Keep source checks, schemas, rubrics, and model construction in the agent.

    Fail-open returns the latest candidate that was successfully generated. A
    failed revision leaves the preceding candidate intact. Fail-closed raises
    before the caller can persist the result.
    """
    active_logger = log or logger
    if max_revisions < 0:
        raise ValueError("max_revisions must be 0 or greater")
    if failure_policy not in ("fail_open", "fail_closed"):
        raise ValueError("failure_policy must be 'fail_open' or 'fail_closed'")

    revision_count = 0
    latest_review: ReviewT | None = None
    _debug_print(stage, "initial_candidate", candidate)
    if max_revisions == 0 and not verify_final_revision:
        _debug_print(
            stage,
            "loop_exit_revision_limit",
            {"candidate": candidate, "review": None, "revisions": 0},
        )
        return ReviewLoopResult(candidate, None, False, 0, "revision_limit")

    while True:
        try:
            latest_review = reviewer(candidate)
            is_approved = approved(latest_review)
            actionable_feedback = has_feedback(latest_review)
            _debug_print(
                stage,
                "review_result",
                {
                    "candidate": candidate,
                    "review": latest_review,
                    "approved": is_approved,
                    "actionable_feedback": actionable_feedback,
                },
            )
        except Exception as exc:
            active_logger.error(
                "LLM review failed stage=%s policy=%s revisions=%d error_type=%s",
                stage,
                failure_policy,
                revision_count,
                type(exc).__name__,
            )
            if failure_policy == "fail_closed":
                raise ReviewLoopError(f"LLM review failed at stage '{stage}'.") from exc
            _debug_print(
                stage,
                "review_exception",
                {"error_type": type(exc).__name__, "error": str(exc), "candidate": candidate},
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "review_failure"
            )

        active_logger.info(
            "LLM review completed stage=%s approved=%s revisions=%d",
            stage,
            is_approved,
            revision_count,
        )
        if is_approved:
            _debug_print(
                stage,
                "loop_exit_approved",
                {"candidate": candidate, "review": latest_review, "revisions": revision_count},
            )
            return ReviewLoopResult(candidate, latest_review, True, revision_count, "approved")
        if not actionable_feedback:
            active_logger.warning("LLM review returned no actionable feedback stage=%s", stage)
            _debug_print(
                stage,
                "loop_exit_no_feedback",
                {"candidate": candidate, "review": latest_review, "revisions": revision_count},
            )
            return ReviewLoopResult(candidate, latest_review, False, revision_count, "no_feedback")
        if revision_count >= max_revisions:
            active_logger.warning(
                "LLM review revision limit reached stage=%s revisions=%d",
                stage,
                revision_count,
            )
            _debug_print(
                stage,
                "loop_exit_revision_limit",
                {"candidate": candidate, "review": latest_review, "revisions": revision_count},
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_limit"
            )

        try:
            _debug_print(stage, "revision_input", {"candidate": candidate, "review": latest_review})
            revised_candidate = reviser(candidate, latest_review)
            _debug_print(
                stage,
                "revised_candidate",
                {
                    "from_candidate": candidate,
                    "review": latest_review,
                    "to_candidate": revised_candidate,
                },
            )
        except Exception as exc:
            active_logger.error(
                "LLM revision failed stage=%s policy=%s revisions=%d error_type=%s",
                stage,
                failure_policy,
                revision_count,
                type(exc).__name__,
            )
            if failure_policy == "fail_closed":
                raise ReviewLoopError(f"LLM revision failed at stage '{stage}'.") from exc
            _debug_print(
                stage,
                "revision_exception",
                {"error_type": type(exc).__name__, "error": str(exc), "candidate": candidate},
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_failure"
            )
        candidate = revised_candidate
        revision_count += 1
        if revision_count >= max_revisions and not verify_final_revision:
            active_logger.info(
                "LLM review completed final revision stage=%s revisions=%d",
                stage,
                revision_count,
            )
            _debug_print(
                stage,
                "loop_exit_revision_limit",
                {"candidate": candidate, "review": latest_review, "revisions": revision_count},
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_limit"
            )
