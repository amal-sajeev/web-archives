-- 2. Create review_data_extraction table
CREATE TABLE dbaware_scoping.review_data_extraction (
    review_scope_dataext_id INTEGER PRIMARY KEY,
    review_scope_instance_id INTEGER,
    data_source VARCHAR(100),
    metadata JSONB,
    created_by VARCHAR(100),
    created_on TIMESTAMP,
    updated_by VARCHAR(100),
    updated_on TIMESTAMP,
    remarks VARCHAR(500),
    CONSTRAINT fk_data_extraction_scope FOREIGN KEY (review_scope_instance_id)
        REFERENCES dbaware_scoping.review_scope (review_scope_instance_id)
        ON DELETE CASCADE
);
