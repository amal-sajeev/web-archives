-- 4. Create review_research_recommendation table
CREATE TABLE dbaware_scoping.review_research_recommendation (
    review_rr_id INTEGER PRIMARY KEY,
    review_scope_instance_id INTEGER,
    metadata JSONB,
    created_by VARCHAR(100),
    created_on TIMESTAMP,
    updated_by VARCHAR(100),
    updated_on TIMESTAMP,
    remarks VARCHAR(500),
    CONSTRAINT fk_research_recommendation_scope FOREIGN KEY (review_scope_instance_id)
        REFERENCES dbaware_scoping.review_scope (review_scope_instance_id)
        ON DELETE CASCADE
);
