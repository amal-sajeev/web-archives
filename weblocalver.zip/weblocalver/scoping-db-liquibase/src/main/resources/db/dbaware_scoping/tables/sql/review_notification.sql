-- 3. Create review_notification table
CREATE TABLE dbaware_scoping.review_notification (
    review_notification_id INTEGER PRIMARY KEY,
    review_scope_instance_id INTEGER,
    notification JSONB,
    distribution_list JSONB,
    notification_type VARCHAR(10),
    notification_sent_date DATE,
    created_by VARCHAR(100),
    created_on TIMESTAMP,
    updated_by VARCHAR(100),
    updated_on TIMESTAMP,
    remarks VARCHAR(500),
    CONSTRAINT fk_notification_scope FOREIGN KEY (review_scope_instance_id)
        REFERENCES dbaware_scoping.review_scope (review_scope_instance_id)
        ON DELETE CASCADE
);
