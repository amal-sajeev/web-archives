-- 1. Create review_scope table (Parent Table)
CREATE TABLE dbaware_scoping.review_scope (
    review_scope_instance_id INTEGER PRIMARY KEY,
    review_scope_id INTEGER,
    review_plan_id INTEGER,
    process_instance_id VARCHAR(100),
    task_id VARCHAR(100),
    review_scope_stage CHAR(50),
    status NUMERIC(2),
    created_by VARCHAR(100),
    created_on TIMESTAMP,
    updated_by VARCHAR(100),
    updated_on TIMESTAMP,
    remarks VARCHAR(500)
);
