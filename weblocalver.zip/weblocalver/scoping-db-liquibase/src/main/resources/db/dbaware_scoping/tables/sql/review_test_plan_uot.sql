-- 5. Create review_test_plan_uot table
CREATE TABLE dbaware_scoping.review_test_plan_uot (
    review_plan_uot_id INTEGER PRIMARY KEY,
    review_scope_instance_id INTEGER,
    assessment_unit_id INTEGER,
    control_instance_id INTEGER,
    risk_id INTEGER,
    is_active BOOLEAN,
    metadata JSONB,
    created_by VARCHAR(100),
    created_on TIMESTAMP,
    updated_by VARCHAR(100),
    updated_on TIMESTAMP,
    remarks VARCHAR(500),
    CONSTRAINT fk_test_plan_scope FOREIGN KEY (review_scope_instance_id)
        REFERENCES dbaware_scoping.review_scope (review_scope_instance_id)
        ON DELETE CASCADE
);
