import asyncio

import pytest

from agents import analytics_agent


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_section_quality():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "within_section_consistency",
                "analysis_actionability",
                "confidence_rationale_alignment",
                "source_applicability",
            )
        ]
    }


def _approve_report_rubric(names):
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": "", "affected_sections": []}
            for name in names
        ]
    }


def test_section_review_revises_with_feedback_and_stops_after_approval():
    generated_feedback = []
    model = _QueuedModel({
        "SectionReview": [
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "The conclusion is not supported.",
                        "action": "Add supporting evidence or remove the conclusion.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
            _approve_section(),
        ],
        "SectionQualityReview": [_approve_section_quality(), _approve_section_quality()],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example",
        builder,
        [{"chunk_id": "source-1", "content": "Evidence."}],
        model,
        max_revisions=1,
        failure_policy="fail_open",
    )

    assert result == "draft-2"
    assert generated_feedback == [
        None,
        "[evidence_support] The conclusion is not supported. Action: Add supporting evidence or remove the conclusion.",
    ]


def test_section_review_returns_latest_valid_draft_when_revision_limit_is_reached():
    generated_feedback = []
    model = _QueuedModel({
        "SectionReview": [
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "First issue.",
                        "action": "First correction.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "Still unsupported.",
                        "action": "Still needs work.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
        ],
        "SectionQualityReview": [_approve_section_quality(), _approve_section_quality()],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example", builder, [], model, max_revisions=1, failure_policy="fail_open"
    )

    assert result == "draft-2"
    assert len(generated_feedback) == 2


def test_section_quality_critique_is_forwarded_to_the_revision_and_rechecked():
    generated_feedback = []
    failed_quality = _approve_section_quality()
    failed_quality["criteria"][1] = {
        "name": "analysis_actionability",
        "passed": False,
        "issue": "The recommendation does not identify a validation target.",
        "action": "Name the control owner and evidence to validate.",
    }
    model = _QueuedModel({
        "SectionReview": [_approve_section(), _approve_section()],
        "SectionQualityReview": [failed_quality, _approve_section_quality()],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example",
        builder,
        [],
        model,
        max_revisions=1,
        failure_policy="fail_open",
    )

    assert result == "draft-2"
    assert generated_feedback == [
        None,
        "[analysis_actionability] The recommendation does not identify a validation target. "
        "Action: Name the control owner and evidence to validate.",
    ]


def test_section_review_failure_policy_can_fail_open_or_closed():
    model = _QueuedModel({"SectionReview": [RuntimeError("judge unavailable")]})
    builder = lambda _chunks, _model, review_feedback=None: "valid draft"

    result = analytics_agent._generate_reviewed_section(
        "Example", builder, [], model, max_revisions=1, failure_policy="fail_open"
    )
    assert result == "valid draft"

    model = _QueuedModel({"SectionReview": [RuntimeError("judge unavailable")]})
    with pytest.raises(RuntimeError, match="LLM review failed"):
        analytics_agent._generate_reviewed_section(
            "Example", builder, [], model, max_revisions=1, failure_policy="fail_closed"
        )


def test_section_quality_judge_failure_obeys_configured_failure_policy():
    builder = lambda _chunks, _model, review_feedback=None: "valid draft"
    responses = {
        "SectionReview": [_approve_section()],
        "SectionQualityReview": [RuntimeError("quality judge unavailable")],
    }
    result = analytics_agent._generate_reviewed_section(
        "Example",
        builder,
        [],
        _QueuedModel(responses),
        max_revisions=1,
        failure_policy="fail_open",
    )
    assert result == "valid draft"

    responses = {
        "SectionReview": [_approve_section()],
        "SectionQualityReview": [RuntimeError("quality judge unavailable")],
    }
    with pytest.raises(RuntimeError, match="LLM review failed"):
        analytics_agent._generate_reviewed_section(
            "Example",
            builder,
            [],
            _QueuedModel(responses),
            max_revisions=1,
            failure_policy="fail_closed",
        )


def test_deterministic_section_integrity_checks_citations_and_supplied_manifest_coverage():
    source_chunks = [
        {"chunk_id": "plan-1", "source_name": "current_plan_item_details", "content": {}},
        {
            "chunk_id": "policy-1",
            "source_name": "relevant_policy",
            "content": [
                {
                    "document_title": "Test Policy",
                    "nodes": [{"section_id": "1.1", "original_text": "Control requirement."}],
                }
            ],
        },
    ]
    invalid_candidate = {
        "report_title": "Policy, KOD and Regulatory Analysis",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": [
                    {
                        "content": "A source-backed statement.",
                        "citation_status": "supported",
                        "supporting_chunk_ids": ["invented-id"],
                        "supporting_citations": [{"chunk_id": "invented-id"}],
                    },
                    {
                        "content": "An unsupported implication.",
                        "citation_status": "unsupported",
                        "supporting_chunk_ids": ["plan-1"],
                        "supporting_citations": [{"chunk_id": "plan-1"}],
                    },
                ],
            }
        ],
    }

    issues = analytics_agent._deterministic_section_integrity(
        "Policy, KOD and Regulatory Analysis", source_chunks, invalid_candidate
    )

    assert "citation_validity" in issues
    assert any("invented-id" in issue for issue in issues["citation_validity"])
    assert any("marked unsupported" in issue for issue in issues["citation_validity"])
    assert "required_content" in issues
    assert any("POLICY|1|1.1" in issue for issue in issues["required_content"])


def test_deterministic_section_integrity_accepts_valid_citations_and_full_manifest_coverage():
    source_chunks = [
        {"chunk_id": "plan-1", "source_name": "current_plan_item_details", "content": {}},
        {
            "chunk_id": "policy-1",
            "source_name": "relevant_policy",
            "content": [
                {
                    "document_title": "Test Policy",
                    "nodes": [{"section_id": "1.1", "original_text": "Control requirement."}],
                }
            ],
        },
    ]
    candidate = {
        "report_title": "Policy, KOD and Regulatory Analysis",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": [
                    {
                        "content": "The policy requires an approval control.",
                        "citation_status": "supported",
                        "supporting_chunk_ids": ["POLICY|1|1.1"],
                        "supporting_citations": [{"chunk_id": "POLICY|1|1.1"}],
                    }
                ],
            }
        ],
    }

    assert analytics_agent._deterministic_section_integrity(
        "Policy, KOD and Regulatory Analysis", source_chunks, candidate
    ) == {}


def test_deterministic_section_integrity_rejects_mismatched_and_unrendered_citations():
    source_chunks = [{"chunk_id": "source-1", "source_name": "current_plan_item_details", "content": {}}]
    candidate = {
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": "Legacy text with an unrendered citation.",
                "supporting_chunk_ids": ["source-1"],
                "supporting_citations": [],
            },
            {
                "paragraph_id": "para_2",
                "content": [
                    {
                        "content": "Citation metadata disagrees.",
                        "citation_status": "supported",
                        "supporting_chunk_ids": ["source-1"],
                        "supporting_citations": [{"chunk_id": "different-source"}],
                    }
                ],
            },
        ]
    }

    issues = analytics_agent._deterministic_section_integrity("Example", source_chunks, candidate)

    assert "citation_validity" in issues
    assert any("no citation entries for rendering" in issue for issue in issues["citation_validity"])
    assert any("do not match" in issue for issue in issues["citation_validity"])


def test_agent_trace_logs_stage_markers_without_report_contents(monkeypatch, caplog):
    monkeypatch.setenv("SUMMARY_AGENT_JUDGE_DEBUG", "true")
    caplog.set_level("DEBUG")

    analytics_agent._terminal_trace(
        "section:Example",
        "judge_input",
        {"candidate": "sensitive report text", "feedback": "private critique"},
    )

    assert "SUMMARY_AGENT_TRACE stage=section:Example label=judge_input" in caplog.text
    assert "sensitive report text" not in caplog.text
    assert "private critique" not in caplog.text


def test_report_review_revises_only_flagged_section_then_reviews_again():
    builder_calls = {"Past Review Analysis": [], "Broad Scope Direction": []}

    def past_builder(_chunks, _model, review_feedback=None):
        builder_calls["Past Review Analysis"].append(review_feedback)
        return {"section": "past revised"}

    def broad_builder(_chunks, _model, review_feedback=None):
        builder_calls["Broad Scope Direction"].append(review_feedback)
        return {"section": "broad"}

    model = _QueuedModel({
        "ReportRubricReview": [
            _approve_report_rubric(("section_coverage", "review_identifier_consistency")),
            {
                "criteria": [
                    {
                        "name": "cross_section_consistency",
                        "passed": False,
                        "issue": "The review purpose differs between sections.",
                        "action": "Label the compliance focus as an inference and clarify that formal purpose is undocumented.",
                        "affected_sections": ["Past Review Analysis"],
                    }
                ]
            },
            _approve_report_rubric(("duplication_and_structure",)),
            _approve_report_rubric(("section_coverage", "review_identifier_consistency")),
            _approve_report_rubric(("cross_section_consistency",)),
            _approve_report_rubric(("duplication_and_structure",)),
        ],
        "SectionReview": [_approve_section()],
        "SectionQualityReview": [_approve_section_quality()],
    })

    result = asyncio.run(analytics_agent._review_complete_report(
        {
            "Past Review Analysis": {"section": "past original"},
            "Broad Scope Direction": {"section": "broad original"},
        },
        model,
        {
            "Past Review Analysis": (past_builder, []),
            "Broad Scope Direction": (broad_builder, []),
        },
        max_revisions=1,
        failure_policy="fail_open",
    ))

    assert result["Past Review Analysis"] == {"section": "past revised"}
    assert result["Broad Scope Direction"] == {"section": "broad original"}
    assert builder_calls["Past Review Analysis"] == [
        "[cross_section_consistency] The review purpose differs between sections. "
        "Action: Label the compliance focus as an inference and clarify that formal purpose is undocumented."
    ]
    assert builder_calls["Broad Scope Direction"] == []


def test_report_review_makes_focused_calls_and_aggregates_logged_failure_patterns():
    class _CaptureModel:
        def __init__(self, responses):
            self.responses = list(responses)
            self.prompts = []
            self.schemas = []

        def with_structured_output(self, schema, **_kwargs):
            self.schemas.append(schema)
            model = self

            class _Runner:
                def invoke(self, payload):
                    message = payload[0]
                    content = message.content if hasattr(message, "content") else message.get("content", [])
                    model.prompts.append("\n".join(part.get("text", "") for part in content))
                    return schema.model_validate(model.responses.pop(0))

            return _Runner()

    report = {
        "Past Review Analysis": {"report_title": "Past Review Analysis", "paragraphs": []},
        "Policy, KOD and Regulatory Analysis": {
            "paragraphs": [{"paragraph_id": "para_1", "content": "This is a Compliance-focused review."}]
        },
        "Broad Scope Direction": {
            "paragraphs": [
                {"paragraph_id": "para_1", "content": "The review purpose was not provided."},
                {"paragraph_id": "para_6", "content": "No dbGRC control instances were available."},
                {"paragraph_id": "para_9", "content": "No dbGRC control instances were available."},
                {"paragraph_id": "para_15", "content": "No dbGRC control instances were available."},
            ]
        },
    }
    model = _CaptureModel(
        [
            _approve_report_rubric(("section_coverage", "review_identifier_consistency")),
            {
                "criteria": [
                    {
                        "name": "cross_section_consistency",
                        "passed": False,
                        "issue": "The policy section asserts a formal compliance purpose while the broad-scope section says the purpose was not provided.",
                        "action": "Label the compliance focus as an inference or clarify that the formal purpose is undocumented.",
                        "affected_sections": [
                            "Policy, KOD and Regulatory Analysis",
                            "Broad Scope Direction",
                        ],
                    }
                ]
            },
            {
                "criteria": [
                    {
                        "name": "duplication_and_structure",
                        "passed": False,
                        "issue": "The missing dbGRC control-instance finding is repeated in paragraphs 6, 9, and 15 without adding a distinct consequence or action.",
                        "action": "Consolidate the finding and keep only references that serve distinct scope or walkthrough actions.",
                        "affected_sections": ["Broad Scope Direction"],
                    }
                ]
            },
        ]
    )

    review = analytics_agent._review_report_candidate(report, model)

    assert len(model.prompts) == 3
    assert model.schemas == [analytics_agent.ReportRubricReview] * 3
    assert {criterion.name for criterion in review.criteria} == {
        "section_coverage",
        "cross_section_consistency",
        "review_identifier_consistency",
        "duplication_and_structure",
    }
    assert not review.approved
    assert set(review.feedback_by_section) == {
        "Policy, KOD and Regulatory Analysis",
        "Broad Scope Direction",
    }
    assert "ONLY when it clearly labels" in model.prompts[1]
    assert "Within the same section, flag repeated statements" in model.prompts[2]
    assert "paragraph_id" in model.prompts[2]


def test_report_review_allows_explicit_inference_and_distinct_gap_references():
    class _PassingModel:
        def __init__(self):
            self.prompts = []

        def with_structured_output(self, schema, **_kwargs):
            model = self

            class _Runner:
                def invoke(self, payload):
                    message = payload[0]
                    content = message.content if hasattr(message, "content") else message.get("content", [])
                    prompt = "\n".join(part.get("text", "") for part in content)
                    model.prompts.append(prompt)
                    if "section_coverage" in prompt and "review_identifier_consistency" in prompt:
                        names = ("section_coverage", "review_identifier_consistency")
                    elif "cross_section_consistency" in prompt:
                        names = ("cross_section_consistency",)
                    else:
                        names = ("duplication_and_structure",)
                    return schema.model_validate(_approve_report_rubric(names))

            return _Runner()

    report = {
        "Past Review Analysis": {"report_title": "Past Review Analysis", "similar_review_count": 0, "historical_reviews": []},
        "Policy, KOD and Regulatory Analysis": {
            "paragraphs": [
                {
                    "paragraph_id": "para_1",
                    "content": "The risk profile suggests an inferred compliance-oriented focus; the plan does not state a formal purpose.",
                }
            ]
        },
        "Broad Scope Direction": {
            "paragraphs": [
                {"paragraph_id": "para_1", "content": "The formal review purpose was not provided."},
                {"paragraph_id": "para_6", "content": "Scope boundary: dbGRC control instances were unavailable."},
                {"paragraph_id": "para_15", "content": "Walkthrough action: ask control owners to identify the control population."},
            ]
        },
    }
    model = _PassingModel()

    review = analytics_agent._review_report_candidate(report, model)

    assert review.approved
    assert len(review.criteria) == 4
    assert "ONLY when it clearly labels" in model.prompts[1]
    assert "each mention serves a distinct purpose" in model.prompts[2]


def test_review_settings_default_and_vertex_connection_configuration(monkeypatch):
    from utils import gemini_connection

    captured = {}

    def fake_chat_model(**kwargs):
        captured.update(kwargs)
        return "configured model"

    monkeypatch.setattr(gemini_connection, "ChatGoogleGenerativeAI", fake_chat_model)
    result = gemini_connection.initialize_gemini_model()

    assert result == "configured model"
    assert captured["model"] == gemini_connection.Config.MODEL_NAME
    assert captured["project"] == gemini_connection.Config.PROJECT_NAME
    assert captured["location"] == gemini_connection.Config.PROJECT_LOCATION
    assert captured["max_output_tokens"] == gemini_connection.Config.GENERATION_CONFIG["max_output_tokens"]
    assert analytics_agent._review_settings() == (
        gemini_connection.Config.SUMMARY_AGENT_REVIEW_MAX_REVISIONS,
        gemini_connection.Config.SUMMARY_AGENT_REVIEW_FAILURE_POLICY,
    )


def test_broad_scope_direction_propagates_review_feedback_and_previous_candidate(monkeypatch):
    from utils.broad_scope_builder import BroadScopePart

    part_calls = []
    collation_calls = []

    def fake_part(_chunks, group, _model, review_feedback=None):
        part_calls.append((group["key"], review_feedback))
        part = BroadScopePart(
            key=group["key"],
            label=group["label"],
            unavailable_text=group["unavailable_text"],
            status="ok",
            output=analytics_agent.BroadScopePartOutput(section1=[], in_scope=[], out_of_scope=[]),
        )
        return part

    def fake_collation(_chunks, _draft_paragraphs, _model, review_feedback=None, previous_candidate=None):
        collation_calls.append((review_feedback, previous_candidate))
        return analytics_agent.BroadScopeCollationOutput(
            section2_rationale="Rationale.",
            section2_confidence_score=75,
            section3=[],
        )

    monkeypatch.setattr(analytics_agent, "_broad_scope_part", fake_part)
    monkeypatch.setattr(analytics_agent, "_broad_scope_collation", fake_collation)

    report = analytics_agent.broad_scope_direction(
        [],
        object(),
        review_feedback="[evidence_support] Fix unsupported claim.",
        previous_candidate={"paragraphs": []},
    )

    assert len(part_calls) == len(analytics_agent.BROAD_SCOPE_GROUPS)
    assert all(call[1] == "[evidence_support] Fix unsupported claim." for call in part_calls)
    assert collation_calls == [("[evidence_support] Fix unsupported claim.", {"paragraphs": []})]
    assert len(report.paragraphs) >= 3


def test_review_section_candidate_excludes_skip_schema_heading_level_and_passes_manifest_chunks():
    from model.response_model import ParagraphCitation, ParagraphMetadata, ScopingReport

    captured_payloads = []

    class _CapturingStructuredModel:
        def __init__(self, schema):
            self.schema = schema

        def invoke(self, payload):
            captured_payloads.append(payload)
            if self.schema is analytics_agent.SectionReview:
                return self.schema.model_validate(_approve_section())
            if self.schema is analytics_agent.SectionQualityReview:
                return self.schema.model_validate(_approve_section_quality())
            raise AssertionError(f"Unexpected schema {self.schema}")

    class _CapturingModel:
        def with_structured_output(self, schema, **_kwargs):
            return _CapturingStructuredModel(schema)

    report = ScopingReport(
        report_title="Policy, KOD and Regulatory Analysis",
        paragraphs=[
            ParagraphCitation(
                paragraph_id="para_1",
                content="Section 1: Overview",
                metadata=ParagraphMetadata(
                    is_section_start=True,
                    citation_status="unsupported",
                    rationale="Section heading.",
                    supporting_chunk_ids=[],
                    supporting_citations=[],
                    confidence_score=100,
                    heading_level=2,
                ),
            )
        ],
    )

    source_chunks = [
        {"chunk_id": "1", "source_name": "current_plan_item_details", "content": {"review_number": "123"}},
        {
            "chunk_id": "4",
            "source_name": "relevant_policy",
            "content": [{"Policy Name": "Test Policy", "Policy ID": "P-1", "Summary": "Details"}],
        },
    ]

    decision = analytics_agent._review_section_candidate(
        "Policy, KOD and Regulatory Analysis",
        source_chunks,
        report,
        _CapturingModel(),
    )

    assert decision.approved is True
    assert len(captured_payloads) == 2
    msg = captured_payloads[0][0]
    content = msg["content"] if isinstance(msg, dict) else msg.content
    text_blocks = [
        item["text"]
        for item in content
        if isinstance(item, dict) and item.get("type") == "text"
    ]
    combined_text = "\n".join(text_blocks)
    assert "heading_level" not in combined_text
    assert "POLICY|" in combined_text
    assert "Section generation requirements:" in combined_text
    quality_msg = captured_payloads[1][0]
    quality_content = quality_msg["content"] if isinstance(quality_msg, dict) else quality_msg.content
    quality_text = "\n".join(
        item["text"]
        for item in quality_content
        if isinstance(item, dict) and item.get("type") == "text"
    )
    assert "within_section_consistency" in quality_text
    assert "analysis_actionability" in quality_text
    assert "confidence_rationale_alignment" in quality_text
    assert "source_applicability" in quality_text


def test_past_review_report_without_historical_data_skips_judge_loop():
    class _FailingJudgeModel:
        def with_structured_output(self, schema, **_kwargs):
            if schema.__name__ == "SectionReview":
                raise AssertionError("SectionReview judge should not be invoked when no historical data exists")
            raise AssertionError(f"Unexpected schema {schema.__name__}")

    source_chunks = [
        {"chunk_id": "1", "source_name": "current_plan_item_details", "content": {"Plan Item Number": "REV-99"}},
        {"chunk_id": "2", "source_name": "historical_plan_item_details", "content": []},
    ]

    result = analytics_agent._generate_reviewed_section(
        "Past Review Analysis",
        analytics_agent.past_review_report,
        source_chunks,
        _FailingJudgeModel(),
        max_revisions=1,
        failure_policy="fail_closed",
    )

    assert result.current_review_id == "REV-99"
    assert result.similar_review_count == 0


def test_prepare_multimodal_payload_caches_pdf_bytes(monkeypatch):
    download_calls = []

    def fake_read_blob(uri):
        download_calls.append(uri)
        return b"%PDF-1.4 fake bytes"

    monkeypatch.setattr(analytics_agent, "read_blob_from_uri_as_bytes", fake_read_blob)
    chunks = [
        {
            "chunk_id": "2",
            "source_name": "historical_review_document",
            "metadata": {"url": "gs://bucket/doc1.pdf"},
            "content": "text",
        }
    ]

    analytics_agent._prepare_multimodal_payload(chunks, "Prompt 1", "Past Review Analysis")
    payload_2 = analytics_agent._prepare_multimodal_payload(chunks, "Prompt 2", "Past Review Analysis")

    assert download_calls == ["gs://bucket/doc1.pdf"]
    msg = payload_2[0]
    content = msg["content"] if isinstance(msg, dict) else msg.content
    text_blocks = [
        item["text"]
        for item in content
        if isinstance(item, dict) and item.get("type") == "text"
    ]
    assert "_cached_pdf_bytes" not in "\n".join(text_blocks)
    assert "to generate the report." in "\n".join(text_blocks)

    judge_payload = analytics_agent._prepare_multimodal_payload(chunks, "Judge Prompt", "Review Past Review Analysis")
    judge_msg = judge_payload[0]
    judge_content = judge_msg["content"] if isinstance(judge_msg, dict) else judge_msg.content
    judge_text = "\n".join(
        item["text"]
        for item in judge_content
        if isinstance(item, dict) and item.get("type") == "text"
    )
    assert "to review the candidate section." in judge_text


def test_policy_regulation_caches_source_assessments_on_revision_unless_flagged(monkeypatch):
    from model.response_model import PolicyDocumentAssessment, PolicyRegulationOutput, ScopingReport

    assessment_calls = []
    captured_prompts = []

    class _PolicyModel:
        def with_structured_output(self, schema, **_kwargs):
            assert schema is PolicyRegulationOutput

            class _Runner:
                def invoke(self, payload):
                    msg = payload[0]
                    content = msg["content"] if isinstance(msg, dict) else msg.content
                    captured_prompts.append(content[0]["text"])
                    return PolicyRegulationOutput.model_validate({
                        "section1": {
                            "intro": "Intro text.",
                            "rationale": "Rationale.",
                            "confidence_score": 80,
                            "document_assessments": [],
                            "regulatory_mandates": {"mandates": []},
                        },
                        "report": ScopingReport(
                            report_title="Policy, KOD and Regulatory Analysis",
                            paragraphs=[],
                        ).model_dump(),
                    })

            return _Runner()

    def fake_assessments(_chunks, _manifest, source_name, _model, review_feedback=None):
        assessment_calls.append((source_name, review_feedback))
        if source_name == "relevant_policy":
            return [
                PolicyDocumentAssessment(
                    doc_key="POLICY|1",
                    sections=[],
                )
            ]
        return []

    monkeypatch.setattr(analytics_agent, "_policy_source_assessments", fake_assessments)
    source_chunks = [
        {"chunk_id": "1", "source_name": "current_plan_item_details", "content": {"Plan Item Number": "101"}},
        {
            "chunk_id": "2",
            "source_name": "relevant_policy",
            "content": [{"document_title": "Policy A", "nodes": [{"section_id": "1.1", "original_text": "Rule"}]}],
        },
    ]

    first_report = analytics_agent.policy_regulation(source_chunks, _PolicyModel())
    assert len(assessment_calls) == 3

    # Revision that does NOT flag document assessments should reuse cached assessments
    # and pass PolicyRegulationOutput (not assembled ScopingReport) as previous_candidate
    second_report = analytics_agent.policy_regulation(
        source_chunks,
        _PolicyModel(),
        review_feedback="[evidence_support] Update Section 5 Source Evidence Log.",
        previous_candidate=first_report,
    )
    assert len(assessment_calls) == 3
    assert "PREVIOUS CANDIDATE DRAFT FOR REFERENCE" in captured_prompts[-1]
    assert "regulatory_mandates" in captured_prompts[-1]

    # Revision that explicitly mentions POLICY| or document_assessments re-runs assessments
    analytics_agent.policy_regulation(
        source_chunks,
        _PolicyModel(),
        review_feedback="[required_content] Missing summary for POLICY|1|1.1.",
        previous_candidate=second_report,
    )
    assert len(assessment_calls) == 6


def test_research_report_evaluates_merged_report_on_partial_regeneration(monkeypatch):
    reviewed_reports = []
    revised_sections = []

    class _PartialModel:
        def __init__(self):
            self.report_call_index = 0

        def with_structured_output(self, schema, **_kwargs):
            model = self

            class _Runner:
                def invoke(self, _payload):
                    if schema.__name__ == "SectionReview":
                        return analytics_agent.SectionReview.model_validate(_approve_section())
                    if schema.__name__ == "SectionQualityReview":
                        return analytics_agent.SectionQualityReview.model_validate(_approve_section_quality())
                    if schema.__name__ == "ReportRubricReview":
                        rubric_responses = [
                            _approve_report_rubric(("section_coverage", "review_identifier_consistency")),
                            _approve_report_rubric(("cross_section_consistency",)),
                            _approve_report_rubric(("duplication_and_structure",)),
                        ]
                        result = schema.model_validate(rubric_responses[model.report_call_index])
                        model.report_call_index += 1
                        return result
                    raise AssertionError(f"Unexpected schema {schema}")

            return _Runner()

    orig_review_report = analytics_agent._review_report_candidate

    def spy_review_report(candidate, model):
        reviewed_reports.append(dict(candidate))
        return orig_review_report(candidate, model)

    def fake_past_builder(_chunks, _model, review_feedback=None, previous_candidate=None):
        revised_sections.append(("past_review", review_feedback))
        return {"report_title": "Past Review Analysis", "paragraphs": []}

    def fake_broad_builder(_chunks, _model, review_feedback=None, previous_candidate=None):
        revised_sections.append(("broad_scope", review_feedback))
        return {"report_title": "Broad Scope Direction", "paragraphs": [{"paragraph_id": "para_1"}]}

    monkeypatch.setattr(analytics_agent, "initialize_gemini_model", lambda: _PartialModel())
    monkeypatch.setattr(analytics_agent, "_review_report_candidate", spy_review_report)
    monkeypatch.setitem(analytics_agent.SECTION_REGISTRY["past_review"], "builder", fake_past_builder)
    monkeypatch.setitem(analytics_agent.SECTION_REGISTRY["broad_scope"], "builder", fake_broad_builder)

    previous_report = {
        "Past Review Analysis": {"report_title": "Old Past", "paragraphs": []},
        "Policy, KOD and Regulatory Analysis": {"report_title": "Old Policy", "paragraphs": []},
        "Broad Scope Direction": {"report_title": "Old Broad", "paragraphs": []},
    }
    plan_data = {"output1": [{"chunk_id": "1", "source_name": "historical_review_document"}], "output2": [], "output3": []}

    result = asyncio.run(
        analytics_agent.research_report(
            plan_data,
            sections=["broad_scope"],
            previous_report=previous_report,
        )
    )

    assert len(reviewed_reports) == 1
    assert list(reviewed_reports[0].keys()) == [
        "Past Review Analysis",
        "Policy, KOD and Regulatory Analysis",
        "Broad Scope Direction",
    ]
    assert reviewed_reports[0]["Past Review Analysis"]["report_title"] == "Old Past"
    assert reviewed_reports[0]["Broad Scope Direction"]["report_title"] == "Broad Scope Direction"
    assert result["Policy, KOD and Regulatory Analysis"]["report_title"] == "Old Policy"
    assert revised_sections == [("broad_scope", None)]


def test_report_review_normalizes_section_aliases_and_avoids_nested_revision_loops():
    builder_calls = []

    def broad_builder(_chunks, _model, review_feedback=None, previous_candidate=None):
        builder_calls.append((review_feedback, previous_candidate))
        return {"section": f"broad-call-{len(builder_calls)}"}

    model = _QueuedModel({
        "ReportRubricReview": [
            _approve_report_rubric(("section_coverage", "review_identifier_consistency")),
            {
                "criteria": [
                    {
                        "name": "cross_section_consistency",
                        "passed": False,
                        "issue": "Inconsistent scope description.",
                        "action": "Align Broad Scope with Policy section.",
                        "affected_sections": ["broad_scope"],
                    }
                ]
            },
            _approve_report_rubric(("duplication_and_structure",)),
            _approve_report_rubric(("section_coverage", "review_identifier_consistency")),
            _approve_report_rubric(("cross_section_consistency",)),
            _approve_report_rubric(("duplication_and_structure",)),
        ],
        # Even if SectionReview rejects during complete-report revision, max_revisions=0
        # inside _review_complete_report ensures no nested revision loop occurs.
        "SectionReview": [
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "Nested section judge complaint.",
                        "action": "Would trigger nested revision if max_revisions > 0.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in ("citation_validity", "required_content", "schema_compliance")
                    ],
                ]
            }
        ],
        "SectionQualityReview": [_approve_section_quality()],
    })

    result = asyncio.run(
        analytics_agent._review_complete_report(
            {"Broad Scope Direction": {"section": "broad-original"}},
            model,
            {"Broad Scope Direction": (broad_builder, [])},
            max_revisions=2,
            failure_policy="fail_open",
        )
    )

    assert len(builder_calls) == 1
    assert result["Broad Scope Direction"] == {"section": "broad-call-1"}




