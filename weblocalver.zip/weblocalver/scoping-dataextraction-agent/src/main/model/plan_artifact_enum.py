from enum import Enum


class PlanArtifact(str, Enum):
    """Extracted artifacts retrievable for a plan."""

    CURRENT_DETAILS = "current_details"
    LRR = "lrr"
    HISTORICAL_PLAN_DETAILS = "historical_plan_details"
    POLICY = "policy"
    ALC_NALC = "alc_nlac"
    FINDINGS_DETAILS = "findings_details"
    CONTROL_DETAILS = "control_details"
    GROUP_AUDIT = "group_audit"
