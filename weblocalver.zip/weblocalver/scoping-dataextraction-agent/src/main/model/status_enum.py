from enum import Enum


class Status(str, Enum):
	
	QUEUED = "QUEUED"
	PROCESSING = "PROCESSING"
	COMPLETED = "COMPLETED"
	FAILED = "FAILED"
