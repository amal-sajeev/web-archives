from pydantic import AliasChoices, BaseModel, Field
from model.status_enum import Status
from model.user_request import UserRequest


class DataExtractionRequest(BaseModel):
    planNumber: str
    userDetails: UserRequest | None = Field(
        default=None,
        validation_alias=AliasChoices("userDetails", "userRequest"),
        serialization_alias="userDetails",
    )


class SessionStatusResponse(BaseModel):
    session_id: str
    stage_name: str
    plan_number: str
    status: Status
    error: str | None = None