from pydantic import BaseModel


class UserRequest(BaseModel):
    review_scope_instance_id: int | None = None
    user: str | None = None
    remarks: str | None = None
