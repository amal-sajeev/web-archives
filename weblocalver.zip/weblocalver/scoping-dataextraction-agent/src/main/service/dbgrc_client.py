import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from util.mcp_client import MCPClient
from config.settings import Config
from util.status_helper import  update_session_extract_mcp_tool

logger = logging.getLogger(__name__)

_LOCAL_BUCKET_ROOT = Path(__file__).resolve().parents[1] / "local-bucket"


def _resolve_local_bucket_root() -> Path:
    """Return the local-bucket root, honouring the LOCAL_BUCKET_ROOT override."""
    configured_root = os.getenv("LOCAL_BUCKET_ROOT", "").strip()
    return Path(configured_root) if configured_root else _LOCAL_BUCKET_ROOT


def _plan_id_from_dbaware(dbaware_data: Dict[str, Any]) -> Optional[str]:
    """Extract the Plan Item Number from dbAware current_data, if available."""
    current_data = dbaware_data.get("current_data")
    row: Dict[str, Any] = {}
    if (
        isinstance(current_data, list)
        and current_data
        and isinstance(current_data[0], dict)
    ):
        row = current_data[0]
    elif isinstance(current_data, dict):
        row = current_data
    plan_id = row.get("Plan Item Number")
    return str(plan_id) if plan_id else None


def _unique_preserve_order(values: List[str]) -> List[str]:
    """Return values in order while removing exact duplicates."""
    seen: Set[str] = set()
    ordered: List[str] = []
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def _result_unique_key(result_data: Dict[str, Any]) -> tuple[str, str, str, str, str]:
    """Build a stable identity for a single API result row."""
    inventory = result_data.get("inventory") or {}
    control_id = str(
        inventory.get("controlDefinitionNumber")
        or inventory.get("externalReferenceId")
        or ""
    )
    assessment_unit = str(inventory.get("assessmentUnitDer") or "")
    risk_id = str(inventory.get("riskId") or "")
    state = str(inventory.get("controlInstanceState") or "")
    return (
        control_id,
        assessment_unit,
        risk_id,
        state,
        str(result_data.get("error") or ""),
    )


def _split_au_rt_pair(pair_key: str) -> Tuple[str, str]:
    """Split an AU~RT pair key back into AU and RT values."""
    if "~" not in pair_key:
        return "", ""
    au, rt = pair_key.split("~", 1)
    return au, rt


async def _fetch_kcs_via_mcp_bulk(
    session_id:str, mcp_client: MCPClient, au_rt_pairs: List[str]
) -> Dict[str, Any]:
    """
    Fetches KC inventory from DBGRC for a list of unique AU-RT pairs
    using the 'get_au_rt_kc_list_bulk' MCP tool.
    """
    request_pairs = []
    for pair_key in au_rt_pairs:
        if "~" in pair_key:
            au, rt = pair_key.split("~", 1)
            request_pairs.append({"assessmentUnitDer": au, "riskId": rt})

    if not request_pairs:
        logger.debug("No valid AU-RT pairs to fetch")
        return {}

    logger.info("Fetching KC inventory for %d AU-RT pairs", len(request_pairs))
    tool_args = {"request": {"pairs": request_pairs}}
    bulk_results = await mcp_client.invoke(
        tool_name="get_au_rt_kc_list_bulk", args=tool_args
    )
    update_session_extract_mcp_tool(session_id,"get_au_rt_kc_list_bulk" )

    fetched_kcs_by_pair = {}
    for result in bulk_results:
        pair_key = f"{result['assessmentUnitDer']}~{result['riskId']}"
        fetched_kcs_by_pair[pair_key] = result

    logger.info("Fetched inventory for %d AU-RT pairs", len(fetched_kcs_by_pair))
    return fetched_kcs_by_pair


def _norm_state(state: Optional[str]) -> Optional[str]:
    """Normalizes the control instance state string."""
    if not state:
        return None
    return state.lower().strip()


def _build_au_rt_to_kcs_map(
    user_rows: Dict[str, Any],
) -> Tuple[Dict[str, Set[str]], List[str]]:
    """
    Parses input AU-RT-KC from dbaware and groups KCs by their AU-RT pair.

    We intentionally preserve every KC row seen in the source data for the final
    result processing, while only de-duplicating exact repeated lookups.
    This ensures same KC values across different AU/RT pairs are not collapsed
    earlier than necessary.

    Returns:
        A tuple of (au_rt_to_kcs map, full kc list in source order).
    """
    au_rt_to_kcs: Dict[str, Set[str]] = {}
    kc_rows: List[str] = []
    au_rt_kc_string = user_rows.get("AU-RT-KC", [])

    for row in au_rt_kc_string:
        kc = row.get("KC", "")
        if not kc:
            continue

        au_raw = row.get("AU", "")
        au_parts = au_raw.split("~") if au_raw else []
        if len(au_parts) <= 4 or not au_parts[4].strip():
            logger.debug("Skipping row with insufficient AU segments: %s", au_raw)
            continue

        au = au_parts[4].strip()
        rt = row.get("RT", "")
        kc_rows.append(kc)

        if not all([au, rt, kc]):
            continue

        pair_key = f"{au}~{rt}"
        if pair_key not in au_rt_to_kcs:
            au_rt_to_kcs[pair_key] = set()

        au_rt_to_kcs[pair_key].add(kc)

    return au_rt_to_kcs, kc_rows



def _build_au_kc_valid_pairs(user_rows: Dict[str, Any]) -> Set[Tuple[str, str]]:
    """Build the strict set of valid (AU, KC) pairs from dbAware mapping."""
    valid_pairs: Set[Tuple[str, str]] = set()
    au_rt_kc_string = user_rows.get("AU-RT-KC", [])


    for row in au_rt_kc_string:
        kc = str(row.get("KC", "") or "").strip()
        if not kc:
            continue

        au_raw = row.get("AU", "")
        au_parts = au_raw.split("~") if au_raw else []
        if len(au_parts) <= 4 or not au_parts[4].strip():
            logger.debug("Skipping row with insufficient AU segments: %s", au_raw)
            continue

        au = au_parts[4].strip()
        if au:
            valid_pairs.add((au, kc))

    return valid_pairs


async def trigger_dbgrc_pipeline(session_id: str, dbaware_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Orchestrates the simplified DBGRC data extraction and analysis process.

    1. Extracts a unique list of KCs from the dbAware data.
    2. Calls a single MCP tool to get full details for all KCs in bulk.
    3. Filters the returned results to only the valid (AU, KC) pairs in dbAware.
    4. Classifies KCs as "Included" or "Excluded" based on the filtered results.
       - Excluded: KC not found in DBGRC OR KC state is "Retired".
       - Included: All other KCs for which data was successfully returned.
    """
    mcp_client = MCPClient(base_url=Config.data_extraction_mcp_server_url)

    included_kcs: List[Dict[str, Any]] = []
    excluded_kcs: List[Dict[str, Any]] = []

    try:

        au_rt_to_kcs, kcs_from_dbaware = _build_au_rt_to_kcs_map(
            dbaware_data["current_data"]
        )
        valid_au_kc_pairs = _build_au_kc_valid_pairs(dbaware_data["current_data"])
        kcs_for_lookup = _unique_preserve_order(kcs_from_dbaware)

        if not kcs_for_lookup:
            return {"error": "No KCs found in the provided dbAware data."}

        logger.info(
            "Requesting details for %d unique KCs from MCP",
            len(kcs_for_lookup),
        )

        detailed_results = await mcp_client.invoke(
            tool_name="get_control_details_by_kc", args={"kcs": kcs_for_lookup}
        )
        if not isinstance(detailed_results, list):
            detailed_results = []

        filtered_results: List[Dict[str, Any]] = []
        for result in detailed_results:
            inventory = result.get("inventory") or {}
            assessment_unit = str(inventory.get("assessmentUnitDer") or "").strip()
            control_id = (
                inventory.get("controlDefinitionNumber")
                or inventory.get("externalReferenceId")
                or ""
            ).strip()
            if not assessment_unit or not control_id:
                continue

            if (assessment_unit, control_id) not in valid_au_kc_pairs:
                logger.debug(
                    "Skipping DBGRC result for KC %s because AU-KC pair (%s, %s) is not in dbAware mapping",
                    control_id,
                    assessment_unit,
                    control_id,
                )
                continue

            filtered_results.append(result)

        logger.info(
            "Filtered DBGRC results to %d rows matching dbAware AU-KC pairs",
            len(filtered_results),
        )
        update_session_extract_mcp_tool(session_id, 'get_control_details_by_kc')

        found_kcs_map = {}
        seen_result_keys: Set[Tuple[str, str, str, str, str]] = set()
        for index, result in enumerate(filtered_results, start=1):
            inventory = result.get("inventory")
            kc_id = (inventory and inventory.get("controlDefinitionNumber")) or (
                inventory and inventory.get("externalReferenceId")
            )
            if kc_id:
                found_kcs_map.setdefault(kc_id, []).append(result)

            result_key = _result_unique_key(result)
            if result_key in seen_result_keys:
                continue
            seen_result_keys.add(result_key)

            inventory = result.get("inventory") or {}
            state = _norm_state(inventory.get("controlInstanceState"))
            control_id = (
                inventory.get("controlDefinitionNumber")
                or inventory.get("externalReferenceId")
                or ""
            )
            if state == "retired":
                excluded_kcs.append(
                    {
                        "controlIdentifier": control_id,
                        "reason": "RETIRED_IN_DBGRC",
                        "details": result,
                    }
                )
            elif control_id:
                included_kcs.append(result)

        for kc in kcs_for_lookup:
            result_list = found_kcs_map.get(kc, [])
            if result_list:
                continue

            excluded_kcs.append(
                {
                    "controlIdentifier": kc,
                    "reason": "MISSING_IN_DBGRC",
                    "details": "No valid AU-KC match found in DBGRC results.",
                }
            )

    except Exception as exc:
        logger.warning(
            "DBGRC processing failed for plan_id=%s error=%s",
            _plan_id_from_dbaware(dbaware_data),
            exc,
        )
        return {"error": "An unexpected error occurred during control processing."}
    finally:
        try:
            await mcp_client.close()
        except Exception:
            logger.exception("Error closing MCP client")

    logger.info(
        "Processing complete. Included: %d, Excluded: %d",
        len(included_kcs),
        len(excluded_kcs),
    )

    final_result = {
        "included_kcs": included_kcs,
        "excluded_kcs": excluded_kcs,
    }

    return final_result
