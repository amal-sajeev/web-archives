import logging
from typing import Any, Dict

from config.settings import Config
from util.mcp_client import MCPClient
from util.status_helper import  update_session_extract_mcp_tool

logger = logging.getLogger(__name__)


def _build_group_audit_payload(current_data: Any) -> dict[str, list[str]]:
    """Build the group-audit request from the extracted plan data."""
    records = current_data if isinstance(current_data, list) else [current_data]
    records = [record for record in records if isinstance(record, dict)]

    def unique_values(values: list[str]) -> list[str]:
        return list(dict.fromkeys(value.strip() for value in values if value.strip()))

    countries: list[str] = []
    risk_types: list[str] = []
    key_controls: list[str] = []
    current_plan_year: str | None = None

    current_plan_year: str | None = None

    for record in records:
        countries.extend(str(record.get("UoT Countries", "")).split(";"))

        controls = record.get("AU-RT-KC", [])
        if isinstance(controls, list):
            for control in controls:
                if isinstance(control, dict):
                    risk_types.extend(str(control.get("RT", "")).split(";"))
                    key_controls.extend(str(control.get("KC", "")).split(";"))

        record_plan_year = record.get("Plan Year")
        if record_plan_year not in (None, "", "None") and current_plan_year is None:
            current_plan_year = str(record_plan_year)

    payload = {
        "key_controls": unique_values(key_controls),
        "countries": unique_values(countries),
        "risk_types": unique_values(risk_types),
    }
    if current_plan_year is not None:
        payload["current_plan_year"] = current_plan_year
    return payload


async def get_group_audit_data(session_id:str, current_data: Any) -> Any:
    """
    Fetches Group Audit data based on the provided payload.

    Args:
        current_data: The extracted plan data to build the Group Audit request payload.

    Returns:
        The Group Audit data from the MCP tool.
    """

    logger.info("Fetching Group Audit data")
    mcp = MCPClient(Config.data_extraction_mcp_server_url)
    try:
        payload = _build_group_audit_payload(current_data)
        group_audit_result = await mcp.invoke("get_group_audit_details", {"request": payload})
        update_session_extract_mcp_tool(session_id, "get_group_audit_details")
        logger.info("Successfully fetched Group Audit data")
        return group_audit_result
    except Exception:
        logger.exception("Failed to fetch Group Audit data")
        raise
    finally:
        try:
            await mcp.close()
        except Exception:
            logger.exception("Error closing MCP client")
