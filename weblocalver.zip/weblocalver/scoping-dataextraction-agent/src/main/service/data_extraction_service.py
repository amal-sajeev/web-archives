import asyncio
import copy
import json
import logging
from tempfile import TemporaryDirectory
from pathlib import Path
from typing import Any, Dict

from config.settings import Config
from model.status_enum import Status
from model.user_request import UserRequest
from persister.gcp_bucket_persister import delete_prefix, save_folder_to_destination
from persister.file_persister import save_json_to_file, build_plan_storage_paths
from service.dbaware_client import get_dbaware_data_for_plan
from service.dbgrc_client import trigger_dbgrc_pipeline
from service.gfms_client import create_gfms_payload_from_dbaware, get_gfms_findings
from service.group_audit_client import get_group_audit_data
from service.internet_search_client import perform_internet_search
from service import action_service
from service.rag_retrieval_service import (
    build_rag_base_payload,
    get_all_relevant_data,
    persist_rag_documents,
)
from service.session_service import update_session_status, DATA_EXTRACTION_STAGE
from util.agent_card import AgentCard
from util.status_helper import set_session_agent_card, set_session_extract_end_time,  set_session_extract_start_time, set_session_extract_response
from util.db_connector import DBConnector


logger = logging.getLogger(__name__)
extraction_semaphore = asyncio.Semaphore(Config.DATA_EXTRACTION_CONCURRENCY_LIMIT)

def generate_action_records(session_id: str):
    from service.session_service import get_session
    current_session = get_session(session_id)
    action_service.construct_human_actor_record_generate(current_session)
    action_service.construct_ai_actor_record_generate(current_session)



def _normalize_user_request(
    user_request: UserRequest | None, plan_number: str | None = None
) -> UserRequest:
    if user_request is not None:
        return user_request
    return UserRequest(
        review_scope_instance_id=None,
        user=None,
        remarks=f"data extraction for plan {plan_number or 'unknown'}",
    )


def _persist_source_payload(
    db_connector: DBConnector,
    source_name: str,
    payload: Any,
    user_request: UserRequest | None,
) -> None:
    metadata = _normalize_user_request(user_request)
    db_connector.persist_data_extraction_record(
        source_name=source_name,
        review_scope_instance_id=metadata.review_scope_instance_id,
        request_payload=payload,
        user=metadata.user,
        remarks=metadata.remarks,
    )


async def run_extraction_background(
    session_id: str, plan_number: str, user_request: UserRequest | None = None
) -> None:
    """Run one extraction while respecting the configured concurrency limit."""
    async with extraction_semaphore:
        update_session_status(
            session_id=session_id,
            stage_name=DATA_EXTRACTION_STAGE,
            plan_number=plan_number,
            status=Status.PROCESSING,
        )


        try:
            await run_extraction_pipeline(
                plan_number, session_id=session_id, user_request=user_request
            )
        except Exception as error:
            logger.exception(
                "Extraction failed for session %s and plan %s",
                session_id,
                plan_number,
            )
            from service.session_service import get_session

            current_session = get_session(session_id)
            failed_stage = (
                current_session.get("stage", DATA_EXTRACTION_STAGE)
                if current_session
                else DATA_EXTRACTION_STAGE
            )
            update_session_status(
                session_id=session_id,
                stage_name=failed_stage,
                plan_number=plan_number,
                status=Status.FAILED,
                error=str(error),
            )
            agent_card = AgentCard.build_agent_card("DATA_EXTRACTION",
                                                    plan_item_number=plan_number,
                                                    status="FAILED",
                                                    error_message=str(error),)

            set_session_agent_card(
                session_id,
                agent_card
            )

            response = {
                "status": "FAILED",
                "message": f"Data extraction failed for plan {plan_number}.",
                "response_code": 500
            }
            set_session_extract_response(session_id, response)
            set_session_extract_end_time(session_id)
            generate_action_records(session_id)
            return

        update_session_status(
            session_id=session_id,
            stage_name=DATA_EXTRACTION_STAGE,
            plan_number=plan_number,
            status=Status.COMPLETED,
        )
        generate_action_records(session_id)



async def run_extraction_pipeline(
    plan_number: str,
    session_id: str | None = None,
    user_request: UserRequest | None = None,
) -> Dict[str, Any]:
    """
    Orchestrates the entire data extraction pipeline.
    """
    db_connector = DBConnector()
    logger.info("Starting data extraction pipeline for plan %s", plan_number)
    set_session_extract_start_time(session_id)
    mcp_tools = []
    try:
        with TemporaryDirectory(prefix=f"scoping_{plan_number}_") as temp_dir:
            logger.info("Temporary working directory created for plan %s", plan_number)

            # 1. dbAware
            update_session_status(
                session_id=session_id,
                stage_name="dbaware",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )

            logger.info("dbAware extraction started for plan %s", plan_number)
            dbaware_sections = await get_dbaware_data_for_plan(
                plan_number, session_id=session_id
            )
            current_data = dbaware_sections.get("current_data", [])
            alc_nalc_details = dbaware_sections.get("alc_nalc_details", [])
            historical_data = dbaware_sections.get("historical_data", [])
            logger.info(
                "dbAware extraction completed for plan %s (current_data=%s, alc_nalc_details=%s, historical_data=%s)",
                plan_number,
                len(current_data) if isinstance(current_data, list) else 1,
                len(alc_nalc_details) if isinstance(alc_nalc_details, list) else 1,
                len(historical_data) if isinstance(historical_data, list) else 1,
            )

            plan_folder_name, plan_storage_key = build_plan_storage_paths(
                plan_number,
                current_data,
            )
            logger.info(
                "Storage paths built for plan %s (folder=%s, key=%s)",
                plan_number,
                plan_folder_name,
                plan_storage_key,
            )

            _persist_source_payload(
                db_connector, "dbaware_plan_details", current_data, user_request
            )
            save_json_to_file(
                current_data,
                plan_storage_key,
                "plan_details.json",
                "dbaware",
                base_dir=temp_dir,
            )
            _persist_source_payload(
                db_connector, "dbaware_alc_nalc_details", alc_nalc_details, user_request
            )
            save_json_to_file(
                alc_nalc_details,
                plan_storage_key,
                "alc_nalc_details.json",
                "dbaware",
                base_dir=temp_dir,
            )
            _persist_source_payload(
                db_connector,
                "dbaware_historical_plan_details",
                historical_data,
                user_request,
            )
            save_json_to_file(
                historical_data,
                plan_storage_key,
                "historical_plan_details.json",
                "dbaware",
                base_dir=temp_dir,
            )
            logger.info("dbAware artifacts persisted for plan %s", plan_number)

            # 2. dbGRC
            update_session_status(
                session_id=session_id,
                stage_name="dbgrc",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("dbGRC analysis started for plan %s", plan_number)
            dbgrc_search_input = {"current_data": current_data}
            dbgrc_analysis = await trigger_dbgrc_pipeline(session_id, dbgrc_search_input)
            _persist_source_payload(
                db_connector, "dbgrc_control_details", dbgrc_analysis, user_request
            )
            save_json_to_file(
                dbgrc_analysis,
                plan_storage_key,
                "control_details.json",
                "dbgrc",
                base_dir=temp_dir,
            )
            logger.info(
                "dbGRC analysis completed and persisted for plan %s", plan_number
            )

            # 3. GFMS
            update_session_status(
                session_id=session_id,
                stage_name="gfms",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("GFMS findings collection started for plan %s", plan_number)
            plan_item = current_data
            gfms_payload = create_gfms_payload_from_dbaware(plan_item)
            logger.info(
                "GFMS base payload controls=%s plan=%s",
                len(gfms_payload.get("control", [])),
                plan_number,
            )
            gfms_payloads = []
            for control in gfms_payload.get("control", []):
                payload_copy = copy.deepcopy(gfms_payload)
                payload_copy["control"] = control
                logger.debug(
                    "GFMS per-control payload prepared for plan %s control=%s",
                    plan_number,
                    control.get("name") if isinstance(control, dict) else control,
                )
                gfms_payloads.append(payload_copy)

            gfms_tasks = [
                get_gfms_findings(session_id, payload=payload) for payload in gfms_payloads
            ]
            gfms_raw_results = await asyncio.gather(*gfms_tasks, return_exceptions=True)

            gfms_findings = []
            for i, result in enumerate(gfms_raw_results):
                if isinstance(result, BaseException):
                    logger.error("GFMS task %d failed: %s", i, result)
                else:
                    gfms_findings.append(result)

            logger.info(
                "GFMS findings fetched for plan %s (success=%d, failed=%d)",
                plan_number,
                len(gfms_findings),
                len(gfms_raw_results) - len(gfms_findings),
            )

            _persist_source_payload(
                db_connector, "gfms_findings_details", gfms_findings, user_request
            )
            save_json_to_file(
                gfms_findings,
                plan_storage_key,
                "findings_details.json",
                "gfms",
                base_dir=temp_dir,
            )
            logger.info("GFMS artifacts persisted for plan %s", plan_number)

            # 4. RAG (policy, procedure, kod) retrieval
            update_session_status(
                session_id=session_id,
                stage_name="rag_enrichment",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("RAG enrichment started for plan %s", plan_number)

            plan_item_for_rag = (
                current_data[0]
                if isinstance(current_data, list) and current_data
                else current_data
            )
            try:
                rag_base_payload = build_rag_base_payload(
                    review_id=str(plan_number),
                    plan_item=plan_item_for_rag or {},
                    dbgrc_analysis=(
                        dbgrc_analysis if isinstance(dbgrc_analysis, dict) else {}
                    ),
                )
                rag_aggregated_response = await get_all_relevant_data(
                    base_payload=rag_base_payload,
                    request_id=session_id or str(plan_number),
                )

                logger.info(
                    "rag payload for planNumber=%s: %s", plan_number, rag_base_payload
                )
            except Exception as rag_error:
                logger.exception("RAG enrichment failed for plan %s", plan_number)
                rag_aggregated_response = {
                    "status": "failed",
                    "query_context": {
                        "review_id": str(plan_number),
                        "region": "",
                        "plan_item_title": "",
                    },
                    "results": {"policy": None, "procedure": None, "kod": None},
                    "errors": {
                        "policy": str(rag_error),
                        "procedure": str(rag_error),
                        "kod": str(rag_error),
                    },
                    "latency_ms_per_type": {
                        "policy": 0.0,
                        "procedure": 0.0,
                        "kod": 0.0,
                    },
                    "total_latency_ms": 0.0,
                }

            await persist_rag_documents(
                rag_aggregated_response,
                plan_storage_key,
                temp_dir,
                request_id=session_id or str(plan_number),
            )
            rag_results = rag_aggregated_response.get("results", {})
            _persist_source_payload(
                db_connector,
                "rag_policy",
                rag_results.get("policy"),
                user_request,
            )
            _persist_source_payload(
                db_connector,
                "rag_procedure",
                rag_results.get("procedure"),
                user_request,
            )
            _persist_source_payload(
                db_connector,
                "rag_kod",
                rag_results.get("kod"),
                user_request,
            )
            logger.info(
                "RAG enrichment completed for plan %s (status=%s)",
                plan_number,
                rag_aggregated_response.get("status"),
            )

            # 5. Group Audit
            update_session_status(
                session_id=session_id,
                stage_name="group_audit",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("Group Audit started for plan %s", plan_number)

            group_audit_analysis = await get_group_audit_data(session_id, current_data)
            _persist_source_payload(
                db_connector, "group_audit_details", group_audit_analysis, user_request
            )
            save_json_to_file(
                group_audit_analysis,
                plan_storage_key,
                "group_audit_details.json",
                "group_audit",
                base_dir=temp_dir,
            )
            logger.info(
                "Group Audit analysis completed and persisted for plan %s", plan_number
            )

            """
            # 6. Internet Search
            update_session_status(
                session_id=session_id,
                stage_name="internet_search",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("Internet search started for plan %s", plan_number)
            plan_item = current_data
            if not isinstance(plan_item, list):
                plan_item = [plan_item] if plan_item else []

            internet_search_input = {
                "searchTerm": f"reviewIds={plan_number}",
                "data": plan_item,
                "alc_nalc_details": alc_nalc_details,
                "historical_data": historical_data,
                "count": len(plan_item),
            }


            search_results = await perform_internet_search(session_id, internet_search_input)
            _persist_source_payload(
                db_connector, "internet_search_data", search_results, user_request
            )

            save_json_to_file(
                search_results,
                plan_storage_key,
                "internet_search_data.json",
                "lrr",
                base_dir=temp_dir,
            )

            logger.info(
                "Internet search completed and persisted for plan %s", plan_number
            )
            """

            # 7. Upload to GCP Bucket or mirror locally
            update_session_status(
                session_id=session_id,
                stage_name="upload",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("Artifact upload started for plan %s", plan_number)
            local_plan_folder = str(Path(temp_dir) / plan_folder_name)
            # Clear stale per-document parts so removed documents don't linger after re-extraction.
            for doc_type in ("policy", "procedure", "kod"):
                delete_prefix(f"{plan_storage_key}/policy/relevant_{doc_type}")
            bucket_location = save_folder_to_destination(
                local_folder=local_plan_folder,
                destination_prefix=f"{plan_folder_name}",
            )
            logger.info(
                "Artifact upload completed for plan %s (destination=%s)",
                plan_number,
                bucket_location,
            )
    except Exception:
        logger.exception("Data extraction pipeline failed for plan %s", plan_number)
        raise

    logger.info(
        "Data extraction pipeline finished successfully for plan %s", plan_number
    )

    response = {
        "status": "success",
        "message": f"Data extraction complete for plan {plan_number}.",
        "output_location": bucket_location,
        "response_code": 200
    }
    agent_card = AgentCard.build_agent_card("DATA_EXTRACTION",
                                            plan_item_number=plan_number,
                                            status="SUCCESS",
                                            )

    set_session_agent_card(
        session_id,
        agent_card
    )
    set_session_extract_response(session_id, response)
    set_session_extract_end_time(session_id)
    return response

