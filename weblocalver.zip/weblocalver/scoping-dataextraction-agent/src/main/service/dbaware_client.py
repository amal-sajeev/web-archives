import asyncio
import json
import logging
import re
from typing import Any, Dict, List
from util.mcp_client import MCPClient
from util.historical_plan_matcher import find_historical_plan_items
from config.settings import Config
from util.status_helper import set_session_extract_title_name, update_session_extract_mcp_tool
logger = logging.getLogger(__name__)


def _extract_plan_year(value: Any) -> int | None:
    """Normalize a plan-year value from dbAware plan details to an int."""
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        match = re.search(r"(\d{4})", value)
        if match:
            return int(match.group(1))
    return None


def extract_aurt_combination(data: Dict[str, Any]) -> List[Dict[str, str]]:
    """Extract unique AU-RT combinations from AU-RT-KC data."""
    logger.debug("Extracting AU-RT-KC combinations from data")
    aurtkc_combination_list = data.get("AU-RT-KC") or []
    seen = set()
    aurt_combination = []
    for item in aurtkc_combination_list:
        if not isinstance(item, dict):
            continue
        au = item.get("AU") or ""
        rt = item.get("RT")
        au_parts = au.split("~") if isinstance(au, str) else []
        auid = au_parts[0].strip() if len(au_parts) > 0 and au_parts[0] else ""
        rtId = rt.strip() if isinstance(rt, str) else rt
        if not auid or not rtId:
            logger.debug("Skipping item with missing AU[0] or RT: %s", item)
            continue
        key = (auid, rtId)
        if key not in seen:
            seen.add(key)
            aurt_combination.append({"auid": key[0], "rtId": key[1]})
    logger.info("Extracted %d unique AU-RT combinations", len(aurt_combination))
    return aurt_combination


async def get_dbaware_data_for_plan(
    plan_number: str, session_id: str | None = None
) -> Dict[str, Any]:
    """Fetch all dbAware data sections for a given plan number."""
    logger.info("Fetching dbaware data for plan_number=%s", plan_number)
    mcp_client = MCPClient(Config.data_extraction_mcp_server_url)

    try:
        # 1. Plan details
        logger.debug("Invoking get_plan_details for plan_number=%s", plan_number)

        current_data = await mcp_client.invoke(
            "get_plan_details", {"planItemNumber": plan_number}
        )
        logger.debug(
            "Successfully fetched plan details for plan_number=%s", plan_number
        )
        update_session_extract_mcp_tool(session_id,'get_plan_details')

        # 2. ALC/NALC details
        aurt_combination = extract_aurt_combination(current_data)
        logger.debug(
            "Invoking get_alc_nalc_details with %d combinations", len(aurt_combination)
        )

        plan_year = _extract_plan_year(
            current_data.get("Plan Year") if isinstance(current_data, dict) else None
        )
        alc_nalc_payload = {
            "acOrNcOrBoth": "BOTH",
            "from_plan_year": plan_year,
            "to_plan_year": plan_year,
            "auRtCombinations": aurt_combination,
        }

        logger.info(
            "ALC/NALC payload for plan %s: %s",
            plan_number,
            json.dumps({"request": alc_nalc_payload}, ensure_ascii=False),
        )
        alc_nalc_data = await mcp_client.invoke(
            "get_alc_nalc_details", {"request": alc_nalc_payload}
        )
        logger.info(
            "ALC/NALC request prepared for plan %s combos=%d from_year=%s to_year=%s",
            plan_number,
            len(aurt_combination),
            alc_nalc_payload.get("from_plan_year"),
            alc_nalc_payload.get("to_plan_year"),
        )

        update_session_extract_mcp_tool(session_id, 'get_alc_nalc_details')
        print("ALC/NALC payload:", alc_nalc_payload)

        logger.debug("Successfully fetched ALC/NALC details")

        # 3. Historical data — safely extract Plan Item Title from dict or list
        plan_title, currentPlanYear, uot_countries, plan_description = (
            None,
            None,
            None,
            None,
        )

        if isinstance(current_data, dict):
            currentPlanYear = current_data.get("Plan Year")
            plan_title = current_data.get("Plan Item Title")
            uot_countries = current_data.get("UoT Countries")
            plan_description = current_data.get("Description of Plan Item")
        elif isinstance(current_data, list) and current_data:
            first = current_data[0]
            if isinstance(first, dict):
                currentPlanYear = first.get("Plan Year")
                plan_title = first.get("Plan Item Title")
                uot_countries = first.get("UoT Countries")
                plan_description = first.get("Description of Plan Item")


        set_session_extract_title_name(session_id,plan_title)

        logger.debug(
            "Invoking get_historic_plan_details for plan_number=%s", plan_number
        )
        all_historical_data = await mcp_client.invoke(
            "get_historic_plan_details", {"currentPlanYear": str(currentPlanYear)}
        )
        update_session_extract_mcp_tool(session_id, 'get_historic_plan_details')


        # If currentPlanYear is available and historical data is a list, filter for genuine matches
        historical_data = []
        if currentPlanYear and isinstance(all_historical_data, list):
            matched_plan_numbers = (
                await find_historical_plan_items(
                    plan_title,
                    plan_description=plan_description,
                    uot_countries=uot_countries,
                    records=all_historical_data,
                    session_id=session_id,
                )
                or []
            )

            if matched_plan_numbers:
                semaphore = asyncio.Semaphore(
                    Config.HISTORICAL_DETAILS_CONCURRENCY_LIMIT
                )

                async def _fetch_historical_plan_details(matched_plan_number):
                    async with semaphore:
                        logger.debug(
                            "Invoking get_plan_details for historical plan_number=%s",
                            matched_plan_number,
                        )
                        return await mcp_client.invoke(
                            "get_plan_details", {"planItemNumber": matched_plan_number}
                        )

                historical_data = await asyncio.gather(
                    *(
                        _fetch_historical_plan_details(number)
                        for number in matched_plan_numbers
                    ),
                    return_exceptions=True,
                )
                historical_data = [
                    item for item in historical_data if not isinstance(item, Exception)
                ]
                logger.info(
                    "Fetched %d historical plan details from %d matches",
                    len(historical_data),
                    len(matched_plan_numbers),
                )

        logger.info("Successfully fetched dbaware data for plan_number=%s", plan_number)

    except Exception:
        logger.exception("Failed to fetch dbaware data for plan_number=%s", plan_number)
        raise
    finally:
        try:
            await mcp_client.close()
        except Exception:
            logger.exception("Error closing MCP client")

    return {
        "current_data": current_data,
        "alc_nalc_details": alc_nalc_data,
        "historical_data": historical_data,
    }
