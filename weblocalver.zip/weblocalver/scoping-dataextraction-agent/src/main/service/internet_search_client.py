import asyncio
import os
import logging
import itertools
from typing import List, Dict, Any, Union
from config.settings import Config
from util.mcp_client import MCPClient
from util.status_helper import  update_session_extract_mcp_tool

logger = logging.getLogger(__name__)

CONCURRENT_REQUEST_LIMIT = 10

# Ensure localhost/127.0.0.1 are excluded from proxy
_no_proxy = os.environ.get("no_proxy", "")
if "127.0.0.1" not in _no_proxy:
    _no_proxy += ",127.0.0.1"
if "localhost" not in _no_proxy:
    _no_proxy += ",localhost"
os.environ["no_proxy"] = _no_proxy

internet_search_prompt_template = """Please perform a detailed internet search for laws, rules, and regulations related to the following criteria.
Provide a comprehensive summary of your findings.

- Plan Title: "{plan_title}"
- Plan Description: "{plan_description}"
- Law/Rule/Regulation (LRR) to search for: "{lrr}"
- Geographic Region: "{region}"
- Risk Type: "{risk_type}"
"""


async def perform_internet_search(session_id: str, search_details_input: Union[Dict[str, Any], List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """
    Extracts search criteria, performs searches CONCURRENTLY,
    tags the results, and returns a list of all findings.
    """
    logger.info("Starting concurrent internet search process...")

    if isinstance(search_details_input, dict):
        search_details_list = search_details_input.get("data", [])
    else:
        search_details_list = search_details_input

    if not search_details_list:
        logger.warning("No data found to perform an internet search.")
        return []

    semaphore = asyncio.Semaphore(CONCURRENT_REQUEST_LIMIT)

    tasks_with_metadata = []

    mcp_client = MCPClient(
        base_url=Config.data_extraction_mcp_server_url
    )

    try:
        async def bounded_mcp_request(prompt: str):
            async with semaphore:
                # The 'internet_search' tool expects its argument to be named 'prompt'
                tool_args = {"prompt": prompt}
                return await mcp_client.invoke(
                    tool_name="internet_search", args=tool_args
                )
            update_session_extract_mcp_tool(session_id, "internet_search")

        # STEP 1: Create all tasks without running them yet

        for details in search_details_list:
            lrr_string = details.get("UoT LRR") or ""
            regions_string = details.get("UoT Regions") or ""
            risk_type_string = details.get("UoT Risk Type") or ""
            plan_item_title = details.get("Plan Item Title", "Not specified")

            lrr_list = [item.strip() for item in lrr_string.split(";") if item.strip()] or [
                "Not specified"
            ]
            regions_list = [
                item.strip() for item in regions_string.split(";") if item.strip()
            ] or ["Not specified"]
            risk_type_list = [
                item.strip() for item in risk_type_string.split(";") if item.strip()
            ] or ["Not specified"]

            combinations = itertools.product(lrr_list, regions_list, risk_type_list)

            for lrr, region, risk_type in combinations:
                if (
                    lrr == "Not specified"
                    and region == "Not specified"
                    and risk_type == "Not specified"
                ):
                    continue

                query = internet_search_prompt_template.format(
                    plan_title=plan_item_title,
                    plan_description=details.get(
                        "Description of Plan Item", "Not specified"
                    ),
                    lrr=lrr,
                    region=region,
                    risk_type=risk_type,
                )

                logger.debug(
                    "Creating task for Plan '%s' | LRR: '%s', Region: '%s', Risk: '%s'",
                    plan_item_title,
                    lrr,
                    region,
                    risk_type,
                )

                # Create the task and store it with its metadata
                task = asyncio.create_task(bounded_mcp_request(query))
                metadata = {
                    "details": details,
                    "combination": {
                        "UoT LRR": lrr,
                        "UoT Regions": region,
                        "UoT Risk Type": risk_type,
                    },
                }
                tasks_with_metadata.append({"task": task, "metadata": metadata})

        logger.info(
            "Executing %s tasks concurrently (limit: %s)...",
            len(tasks_with_metadata),
            CONCURRENT_REQUEST_LIMIT,
        )
        all_tasks = [item["task"] for item in tasks_with_metadata]
        all_raw_results = await asyncio.gather(*all_tasks, return_exceptions=True)
        logger.info("All concurrent tasks have completed.")

        all_tagged_results = []
        for i, search_result_content in enumerate(all_raw_results):
            metadata = tasks_with_metadata[i]["metadata"]
            details = metadata["details"]
            combination = metadata["combination"]

            # Handle tasks that raised exceptions
            if isinstance(search_result_content, BaseException):
                logger.error(
                    "Search task failed for combination %s: %s",
                    combination,
                    search_result_content,
                )
                continue

            if isinstance(search_result_content, str):
                text = search_result_content.strip()
            elif (
                isinstance(search_result_content, list)
                and search_result_content
                and isinstance(search_result_content[0], dict)
                and search_result_content[0].get("type") == "text"
            ):
                text = "\n".join(
                    item["text"]
                    for item in search_result_content
                    if item.get("type") == "text"
                ).strip()
            else:
                logger.error(
                    "Failed to get search result for combination %s. Unexpected response type %s: %s",
                    combination,
                    type(search_result_content).__name__,
                    search_result_content,
                )
                continue

            tagged_result = {
                "plan_item_number": details.get("Plan Item Number"),
                "plan_item_title": details.get("Plan Item Title"),
                "description_of_plan_item": details.get("Description of Plan Item"),
                "search_combination": combination,
                "search_result": text,
            }
            all_tagged_results.append(tagged_result)

    finally:
        try:
            await mcp_client.close()
        except Exception:
            logger.exception("Error closing MCP client")

    logger.info("Internet search completed with %d results", len(all_tagged_results))
    return all_tagged_results
