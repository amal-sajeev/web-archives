import asyncio
import base64
import json
import logging
import re
from pathlib import Path
from time import perf_counter
from typing import Any

import httpx

from config.settings import Config

logger = logging.getLogger(__name__)

DOCUMENT_TYPES = ("policy", "procedure", "kod")
LIST_FIELDS = (
    "au_countries",
    "au_list",
    "rt_list",
    "kc_list",
    "control_name",
    "control_how",
    "control_what",
    "control_why",
)
RETRY_STATUS_CODES = {429, 500, 502, 503, 504}
MAX_RETRIES = 3
BACKOFF_BASE_SECONDS = 0.5
RAG_TIMEOUT_SECONDS = 180.0


def _relevant_metadata_filename(document_type: str) -> str:
    return f"relevant_{document_type}.json"


def _split_semicolon_field(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [part.strip() for part in str(value).split(";") if part.strip()]


def _normalize_to_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _dedup_keep_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


def _dedup_documents(documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []

    for document in documents:
        if not isinstance(document, dict):
            continue

        key = str(
            document.get("gs_uri")
            or document.get("document_name")
            or json.dumps(document, sort_keys=True, default=str)
        )
        if key in seen:
            continue

        seen.add(key)
        deduped.append(document)

    return deduped


def _extract_referenced_documents(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, dict):
        referenced = result_payload.get("referenced_documents")
        if isinstance(referenced, list):
            return [item for item in referenced if isinstance(item, dict)]
    return []


def _extract_citations(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, dict):
        citations = result_payload.get("citations")
        if isinstance(citations, list):
            return [item for item in citations if isinstance(item, dict)]
    return []


def _extract_control_fields(dbgrc_analysis: dict[str, Any]) -> dict[str, list[str]]:
    controls = _normalize_to_list(dbgrc_analysis.get("included_kcs"))

    control_name: list[str] = []
    control_how: list[str] = []
    control_what: list[str] = []
    control_why: list[str] = []

    for control in controls:
        if not isinstance(control, dict):
            continue

        inventory = (
            control.get("inventory")
            if isinstance(control.get("inventory"), dict)
            else {}
        )
        details = (
            control.get("details") if isinstance(control.get("details"), dict) else {}
        )

        name = (
            inventory.get("controlDefinitionNumber")
            or inventory.get("externalReferenceId")
            or details.get("control_name")
            or details.get("name")
            or control.get("controlIdentifier")
        )
        how_value = (
            details.get("control_how")
            or details.get("how")
            or details.get("description")
            or inventory.get("controlHow")
            or inventory.get("controlDescription")
        )
        what_value = (
            details.get("control_what")
            or details.get("what")
            or inventory.get("controlWhat")
        )
        why_value = (
            details.get("control_why")
            or details.get("why")
            or inventory.get("controlWhy")
        )

        if name:
            control_name.append(str(name).strip())
        if how_value:
            control_how.append(str(how_value).strip())
        if what_value:
            control_what.append(str(what_value).strip())
        if why_value:
            control_why.append(str(why_value).strip())

    return {
        "control_name": _dedup_keep_order([item for item in control_name if item]),
        "control_how": _dedup_keep_order([item for item in control_how if item]),
        "control_what": _dedup_keep_order([item for item in control_what if item]),
        "control_why": _dedup_keep_order([item for item in control_why if item]),
    }


def build_rag_base_payload(
    review_id: str,
    plan_item: dict[str, Any],
    dbgrc_analysis: dict[str, Any],
) -> dict[str, Any]:
    if not isinstance(plan_item, dict):
        raise ValueError("plan_item must be a dictionary.")

    au_rt_kc = _normalize_to_list(plan_item.get("AU-RT-KC"))
    au_list: list[str] = []
    rt_list: list[str] = []
    kc_list: list[str] = []

    # Extract Risk Type from UoT Risk Type field (has full description)
    uot_rt = str(plan_item.get("UoT Risk Type") or "").strip()
    if uot_rt:
        rt_list.append(uot_rt)

    # Extract Key Controls from UoT KCs field (has full description)
    uot_kc = str(plan_item.get("UoT KCs") or "").strip()
    if uot_kc:
        kc_list = _split_semicolon_field(uot_kc)

    for row in au_rt_kc:
        if not isinstance(row, dict):
            continue

        au_raw = str(row.get("AU") or "").strip()
        if au_raw:
            au_parts = [part.strip() for part in au_raw.split("~")]
            if len(au_parts) > 4 and au_parts[4]:
                au_list.append(au_parts[4])
            else:
                au_list.append(au_raw)

    control_fields = _extract_control_fields(dbgrc_analysis)

    return {
        "review_id": str(review_id).strip(),
        "region": str(plan_item.get("UoT Regions") or "").strip(),
        "au_countries": _split_semicolon_field(plan_item.get("UoT Countries")),
        "plan_item_title": str(plan_item.get("Plan Item Title") or "").strip(),
        "plan_item_description": str(
            plan_item.get("Description of Plan Item") or ""
        ).strip(),
        "au_list": _dedup_keep_order([item for item in au_list if item]),
        "rt_list": _dedup_keep_order([item for item in rt_list if item]),
        "kc_list": _dedup_keep_order([item for item in kc_list if item]),
        "control_name": control_fields["control_name"],
        "control_how": control_fields["control_how"],
        "control_what": control_fields["control_what"],
        "control_why": control_fields["control_why"],
    }


def validate_base_payload(base_payload: dict[str, Any]) -> None:
    if not isinstance(base_payload, dict):
        raise ValueError("RAG base payload must be a dictionary.")

    required_scalar_fields = (
        "review_id",
        "plan_item_title",
        "plan_item_description",
    )

    for field_name in required_scalar_fields:
        value = base_payload.get(field_name)
        if value is None or not str(value).strip():
            raise ValueError(f"Missing required payload field: {field_name}")

    for field_name in LIST_FIELDS:
        if field_name not in base_payload:
            raise ValueError(f"Missing required list field: {field_name}")
        if not isinstance(base_payload[field_name], list):
            raise ValueError(f"Payload field '{field_name}' must be a list.")


def _compose_rag_url() -> str:
    base = Config.RAG_BASE_URL.strip().rstrip("/")
    if not base:
        raise ValueError("RAG_BASE_URL is required.")
    if base.endswith("/get-relevant-data"):
        return base
    return f"{base}/get-relevant-data"


def _auth_headers(request_id: str | None) -> dict[str, str]:
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if request_id:
        headers["X-Request-ID"] = request_id
    return headers


async def _post_with_retry(
    client: httpx.AsyncClient,
    url: str,
    json_payload: dict[str, Any],
    headers: dict[str, str],
    request_id: str | None,
    document_type: str,
) -> httpx.Response:
    last_error: Exception | None = None

    for attempt in range(MAX_RETRIES + 1):
        try:
            response = await client.post(url, json=json_payload, headers=headers)

            if response.status_code in RETRY_STATUS_CODES and attempt < MAX_RETRIES:
                wait_seconds = BACKOFF_BASE_SECONDS * (2**attempt)
                logger.warning(
                    "RAG retry scheduled request_id=%s document_type=%s status=%s attempt=%s wait_seconds=%s",
                    request_id,
                    document_type,
                    response.status_code,
                    attempt + 1,
                    wait_seconds,
                )
                await asyncio.sleep(wait_seconds)
                continue

            return response
        except (
            httpx.ConnectError,
            httpx.ReadTimeout,
            httpx.RemoteProtocolError,
        ) as error:
            last_error = error
            if attempt >= MAX_RETRIES:
                break
            wait_seconds = BACKOFF_BASE_SECONDS * (2**attempt)
            logger.warning(
                "RAG transient error request_id=%s document_type=%s attempt=%s wait_seconds=%s error=%s",
                request_id,
                document_type,
                attempt + 1,
                wait_seconds,
                error,
            )
            await asyncio.sleep(wait_seconds)

    if last_error is not None:
        raise RuntimeError(
            f"RAG call failed for {document_type}: {last_error}"
        ) from last_error

    raise RuntimeError(f"RAG call failed for {document_type}: exhausted retries")


async def call_rag(
    document_type: str,
    base_payload: dict[str, Any],
    *,
    request_id: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    if document_type not in DOCUMENT_TYPES:
        raise ValueError(f"Unsupported document_type: {document_type}")

    validate_base_payload(base_payload)

    payload = dict(base_payload)
    payload["document_type"] = document_type

    logger.info(
        "RAG payload request_id=%s document_type=%s payload=%s",
        request_id,
        document_type,
        json.dumps(payload, ensure_ascii=False, sort_keys=True),
    )

    url = _compose_rag_url()
    headers = _auth_headers(request_id)

    started = perf_counter()
    owns_client = client is None
    rag_client = client or httpx.AsyncClient(timeout=RAG_TIMEOUT_SECONDS)

    try:
        logger.info(
            "RAG request started request_id=%s document_type=%s",
            request_id,
            document_type,
        )
        response = await _post_with_retry(
            rag_client, url, payload, headers, request_id, document_type
        )

        if response.status_code >= 400:
            error_body = response.text[:1000]
            raise RuntimeError(
                f"RAG call failed for {document_type}. status={response.status_code}, body={error_body}"
            )

        try:
            response_json = response.json()
        except json.JSONDecodeError as error:
            raise RuntimeError(
                f"RAG response for {document_type} was not valid JSON"
            ) from error

        latency_ms = round((perf_counter() - started) * 1000, 2)
        logger.info(
            "RAG request completed request_id=%s document_type=%s latency_ms=%s",
            request_id,
            document_type,
            latency_ms,
        )

        return {
            "response": response_json,
            "latency_ms": latency_ms,
        }
    finally:
        if owns_client:
            await rag_client.aclose()


async def get_all_relevant_data(
    base_payload: dict[str, Any],
    *,
    request_id: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    validate_base_payload(base_payload)

    started = perf_counter()
    results: dict[str, Any] = {doc_type: None for doc_type in DOCUMENT_TYPES}
    errors: dict[str, Any] = {doc_type: None for doc_type in DOCUMENT_TYPES}
    latency_ms_per_type: dict[str, float] = {
        doc_type: 0.0 for doc_type in DOCUMENT_TYPES
    }
    combined_referenced_documents: list[dict[str, Any]] = []
    combined_citations: list[dict[str, Any]] = []

    for doc_type in DOCUMENT_TYPES:
        try:
            outcome = await call_rag(
                document_type=doc_type,
                base_payload=base_payload,
                request_id=request_id,
                client=client,
            )
        except BaseException as error:
            errors[doc_type] = str(error)
            logger.error(
                "RAG request failed request_id=%s document_type=%s error=%s",
                request_id,
                doc_type,
                error,
            )
            continue

        results[doc_type] = outcome.get("response")
        latency_ms_per_type[doc_type] = float(outcome.get("latency_ms") or 0.0)
        combined_referenced_documents.extend(
            _extract_referenced_documents(outcome.get("response"))
        )
        combined_citations.extend(_extract_citations(outcome.get("response")))

    successful_count = sum(1 for item in results.values() if item is not None)
    if successful_count == len(DOCUMENT_TYPES):
        status = "success"
    elif successful_count == 0:
        status = "failed"
    else:
        status = "partial_success"

    return {
        "status": status,
        "query_context": {
            "review_id": base_payload.get("review_id"),
            "region": base_payload.get("region"),
            "plan_item_title": base_payload.get("plan_item_title"),
        },
        "results": results,
        "errors": errors,
        "referenced_documents": _dedup_documents(combined_referenced_documents),
        "citations": _dedup_documents(combined_citations),
        "latency_ms_per_type": latency_ms_per_type,
        "total_latency_ms": round((perf_counter() - started) * 1000, 2),
    }


def _extract_candidate_documents(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, dict):
        if isinstance(result_payload.get("documents"), list):
            return [
                item for item in result_payload["documents"] if isinstance(item, dict)
            ]
        if isinstance(result_payload.get("data"), dict) and isinstance(
            result_payload["data"].get("documents"), list
        ):
            return [
                item
                for item in result_payload["data"]["documents"]
                if isinstance(item, dict)
            ]
        if isinstance(result_payload.get("items"), list):
            return [item for item in result_payload["items"] if isinstance(item, dict)]
    return []


def _extract_relevant_documents(result_payload: Any) -> list[dict[str, Any]]:
    if isinstance(result_payload, list):
        return [item for item in result_payload if isinstance(item, dict)]
    if not isinstance(result_payload, dict):
        return []
    if result_payload.get("document_id") is not None:
        return [result_payload]

    for key in ("documents", "referenced_documents", "items"):
        documents = result_payload.get(key)
        if isinstance(documents, list):
            return [item for item in documents if isinstance(item, dict)]

    data = result_payload.get("data")
    if isinstance(data, dict):
        for key in ("documents", "referenced_documents", "items"):
            documents = data.get(key)
            if isinstance(documents, list):
                return [item for item in documents if isinstance(item, dict)]
    return []


def _sanitize_filename(name: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return safe or "document"


def _decode_base64_field(item: dict[str, Any]) -> bytes | None:
    for key in ("pdf_base64", "content_base64", "file_base64", "blob_base64"):
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            try:
                return base64.b64decode(value)
            except Exception:
                logger.warning("Unable to decode base64 field %s", key)
                return None
    return None


async def _download_pdf_bytes(
    client: httpx.AsyncClient,
    url: str,
    *,
    request_id: str | None,
    document_type: str,
) -> bytes | None:
    try:
        response = await client.get(url, headers=_auth_headers(request_id))
    except Exception:
        logger.exception(
            "Failed to download document bytes request_id=%s document_type=%s url=%s",
            request_id,
            document_type,
            url,
        )
        return None

    if response.status_code >= 400:
        logger.warning(
            "Document download returned non-2xx request_id=%s document_type=%s status=%s url=%s",
            request_id,
            document_type,
            response.status_code,
            url,
        )
        return None
    return response.content


async def persist_rag_documents(
    aggregated_response: dict[str, Any],
    plan_storage_key: str,
    base_dir: str,
    *,
    request_id: str | None = None,
) -> dict[str, Any]:
    base_path = Path(base_dir) / plan_storage_key / "policy"
    base_path.mkdir(parents=True, exist_ok=True)

    write_report: dict[str, Any] = {
        doc_type: {"saved_files": []} for doc_type in DOCUMENT_TYPES
    }

    async with httpx.AsyncClient(timeout=RAG_TIMEOUT_SECONDS) as client:
        for doc_type in DOCUMENT_TYPES:
            rag_result = (aggregated_response.get("results") or {}).get(doc_type)
            metadata_path = base_path / _relevant_metadata_filename(doc_type)
            metadata_path.write_text(
                json.dumps(rag_result, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            write_report[doc_type]["saved_files"].append(str(metadata_path.name))

            relevant_documents = _extract_relevant_documents(rag_result)
            relevant_folder = base_path / f"relevant_{doc_type}"
            for document in relevant_documents:
                document_id = document.get("document_id")
                if document_id in (None, ""):
                    logger.warning(
                        "Skipping relevant document without document_id document_type=%s",
                        doc_type,
                    )
                    continue
                relevant_folder.mkdir(parents=True, exist_ok=True)
                file_name = f"{doc_type}{_sanitize_filename(str(document_id))}.json"
                output_path = relevant_folder / file_name
                output_path.write_text(
                    json.dumps(document, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                write_report[doc_type]["saved_files"].append(
                    str(output_path.relative_to(base_path))
                )

            if not isinstance(rag_result, dict):
                continue

            doc_folder = base_path / doc_type
            doc_folder.mkdir(parents=True, exist_ok=True)

            documents = _extract_candidate_documents(rag_result)
            for index, document in enumerate(documents, start=1):
                binary = _decode_base64_field(document)

                if binary is None:
                    candidate_url = document.get("pdf_url") or document.get("url")
                    if isinstance(candidate_url, str) and candidate_url.strip():
                        binary = await _download_pdf_bytes(
                            client,
                            candidate_url.strip(),
                            request_id=request_id,
                            document_type=doc_type,
                        )

                if binary is None:
                    continue

                name_from_payload = document.get("file_name") or document.get("name")
                file_name = _sanitize_filename(
                    str(name_from_payload)
                    if name_from_payload
                    else f"{doc_type}_{index}.pdf"
                )
                if not file_name.lower().endswith(".pdf"):
                    file_name = f"{file_name}.pdf"

                output_path = doc_folder / file_name
                output_path.write_bytes(binary)
                write_report[doc_type]["saved_files"].append(str(output_path.name))

    return write_report
