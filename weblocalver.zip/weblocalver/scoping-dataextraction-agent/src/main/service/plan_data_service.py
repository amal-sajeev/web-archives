import logging
import re
from pathlib import Path
from typing import Any

from model.plan_artifact_enum import PlanArtifact
from persister.gcp_bucket_persister import (
    download_json_from_gcs,
    gcs_prefix_exists,
    inbound_prefix_uri,
    json_exists_in_gcs,
    list_json_blobs_in_gcs,
    plan_prefix_uri,
)
from service import action_service
from util.agent_card import AgentCard

logger = logging.getLogger(__name__)
POLICY_DOCUMENT_TYPES = ("policy", "procedure", "kod")


def _validate_plan_number(plan_number: str) -> str:
    plan_id = str(plan_number).strip()
    if not re.fullmatch(r"\d+", plan_id):
        raise ValueError("plan_number must be a numeric value.")
    return plan_id


# Artifact -> object path relative to <plan folder>/inbound-data
ARTIFACT_FILES: dict[PlanArtifact, str] = {
    PlanArtifact.CURRENT_DETAILS: "dbaware/plan_details.json",
    PlanArtifact.LRR: "lrr/internet_search_data.json",
    PlanArtifact.HISTORICAL_PLAN_DETAILS: "dbaware/historical_plan_details.json",
    PlanArtifact.ALC_NALC: "dbaware/alc_nalc_details.json",
    PlanArtifact.FINDINGS_DETAILS: "gfms/findings_details.json",
    PlanArtifact.CONTROL_DETAILS: "dbgrc/control_details.json",
    PlanArtifact.GROUP_AUDIT: "group_audit/group_audit_details.json",
}

# Artifacts served as every JSON file inside a folder instead of a single file.
ARTIFACT_FOLDERS: dict[PlanArtifact, str] = {
    PlanArtifact.POLICY: "policy",
}


def _dedup_documents(documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []

    for document in documents:
        if not isinstance(document, dict):
            continue

        key = str(
            document.get("document_type")
            or ""
        ) + "|" + str(document.get("gs_uri") or document.get("document_name") or document)
        if key in seen:
            continue

        seen.add(key)
        deduped.append(document)

    return deduped


def _load_json_if_present(uri: str) -> tuple[bool, Any]:
    """Return (file_exists, parsed_content). Content is None when the file is absent or its JSON is null."""
    if not json_exists_in_gcs(uri):
        return False, None
    return True, download_json_from_gcs(uri)


def _relevant_filename_for_document_type(document_type: str) -> str:
    return f"relevant_{document_type}.json"


def _get_policy_artifact_data(plan_id: str) -> list[dict[str, Any]]:
    """Load and merge referenced_documents from all 3 policy-type artifacts."""
    policy_root_uri = _artifact_uri(plan_id, PlanArtifact.POLICY)
    legacy_policy_root_uri = f"{inbound_prefix_uri(plan_id)}/policy"
    combined_referenced_documents: list[dict[str, Any]] = []
    found_payload = False

    for document_type in POLICY_DOCUMENT_TYPES:
        preferred_uri = f"{policy_root_uri}/{_relevant_filename_for_document_type(document_type)}"
        legacy_flat_uri = f"{policy_root_uri}/relevant_{document_type}.json"
        legacy_nested_uri = f"{legacy_policy_root_uri}/{document_type}/relevant_{document_type}.json"
        legacy_data_uri = f"{legacy_policy_root_uri}/{document_type}/relevant_data.json"

        file_found = False
        payload = None
        for candidate_uri in (preferred_uri, legacy_flat_uri, legacy_nested_uri, legacy_data_uri):
            file_found, payload = _load_json_if_present(candidate_uri)
            if file_found:
                break
        if not file_found:
            continue

        found_payload = True
        if isinstance(payload, dict):
            referenced_documents = payload.get("referenced_documents")
            if isinstance(referenced_documents, list):
                combined_referenced_documents.extend(
                    {
                        "document_type": document_type,
                        "document_name": item.get("document_name"),
                        "gs_uri": item.get("gs_uri"),
                    }
                    for item in referenced_documents
                    if isinstance(item, dict)
                )

    if not found_payload:
        raise FileNotFoundError(f"No data found for plan {plan_id} artifact {PlanArtifact.POLICY.value}")

    return _dedup_documents(combined_referenced_documents)



def _artifact_uri(plan_number: str, artifact: PlanArtifact) -> str:
    base = inbound_prefix_uri(plan_number)
    if artifact in ARTIFACT_FOLDERS:
        return f"{base}/{ARTIFACT_FOLDERS[artifact]}"
    return f"{base}/{ARTIFACT_FILES[artifact]}"


def check_plan_data_availability(plan_number: str) -> dict[str, Any]:
    """Report whether the plan's root prefix exists in the bucket."""
    plan_id = _validate_plan_number(plan_number)
    plan_prefix = plan_prefix_uri(plan_id)
    plan_exists = gcs_prefix_exists(plan_prefix)

    return {
        "plan_number": plan_id,
        "available": plan_exists,
    }


def get_plan_artifact(plan_number: str, artifact: PlanArtifact) -> dict[str, Any]:
    """Return the stored content of one extracted artifact for a plan."""
    plan_id = _validate_plan_number(plan_number)
    agent_card = AgentCard.get_agent_card(plan_number.strip()) or {}
    artifact_value = artifact.value
    if artifact.value == 'current_details':
        artifact_value = 'current_plan_details'
    action_service.construct_human_actor_retrieve_records(plan_number, artifact_value, agent_card)

    if artifact is PlanArtifact.POLICY:
        uri = _artifact_uri(plan_id, artifact)
        referenced_documents = _get_policy_artifact_data(plan_id)
        response = {
            "plan_number": plan_id,
            "artifact": artifact.value,
            "source": uri,
            "data": {"referenced_documents": referenced_documents},
            "status": 'SUCCESS',
            "response_code": 200
        }
        action_service.construct_ai_actor_retrieve_records(plan_number, artifact_value, response, agent_card)
        return response

    uri = _artifact_uri(plan_id, artifact)

    response = {
        "plan_number": plan_id,
        "artifact": artifact.value,
        "source": uri,
         }

    if artifact in ARTIFACT_FOLDERS:
        blob_uris = list_json_blobs_in_gcs(uri)
        if not blob_uris:
            response["response_code"] = 500
            response["status"] = 'FAILED'
            action_service.construct_ai_actor_retrieve_records(plan_number, artifact.value, response)
            raise FileNotFoundError(f"No data found for plan {plan_id} artifact {artifact.value}")
        data = {Path(blob_uri).stem: download_json_from_gcs(blob_uri) for blob_uri in blob_uris}
    else:
        if not json_exists_in_gcs(uri):
            response["response_code"] = 500
            response["status"] = 'FAILED'
            action_service.construct_ai_actor_retrieve_records(plan_number, artifact.value, response)
            raise FileNotFoundError(f"No data found for plan {plan_id} artifact {artifact.value}")
        data = {Path(uri).stem: download_json_from_gcs(uri)}

    response["status"] = 'SUCCESS'
    response["response_code"] = 200
    response["data"] = data
    action_service.construct_ai_actor_retrieve_records(plan_number,artifact_value, response, agent_card)
    return response
