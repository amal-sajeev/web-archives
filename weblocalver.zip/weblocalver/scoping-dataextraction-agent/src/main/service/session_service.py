import uuid
from typing import Any

from model.status_enum import Status
from util.status_helper import get_session_status, set_session_status


DATA_EXTRACTION_STAGE = "data_extraction"


def update_session_status( session_id: str, stage_name: str, plan_number: str, status: Status, error: str = ""):
    """Persist the current status and metadata for a session."""
    set_session_status(
        session_id=session_id,
        stage_name=stage_name,
        plan_number=plan_number,
        status=status,
        error=error,
    )


def create_session(plan_number: str):
    """Create and persist a queued session for a plan."""
    session_id = str(uuid.uuid4())
    plan_number = str(plan_number)

    update_session_status(
        session_id=session_id,
        stage_name=DATA_EXTRACTION_STAGE,
        plan_number=plan_number,
        status=Status.QUEUED,
    )

    return {
        "session_id": session_id,
        "plan_number": plan_number,
        "status": Status.QUEUED.value,
    }


def get_session(session_id: str):
    """Return the stored session status, or None when it does not exist."""
    return get_session_status(session_id)
