import json
import logging
from typing import Any, Dict

from config.settings import Config
from util.mcp_client import MCPClient
from util.status_helper import  update_session_extract_mcp_tool

logger = logging.getLogger(__name__)


def create_gfms_payload_from_dbaware(plan_item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transforms a dbAware plan item into a payload for the GFMS findings API.

    Args:
        plan_item: A single dictionary representing a plan item from the dbAware "current_data".

    Returns:
        A dictionary formatted as the request body for the GFMS API containing control and findingStatus.
    """
    payload = {}

    kc_list = plan_item.get("AU-RT-KC", [])
    if kc_list:
        unique_kcs = {item["KC"] for item in kc_list if "KC" in item}
        payload["control"] = [
            {"id": 1, "name": kc, "control": kc} for kc in unique_kcs if len(kc) > 3
        ]

    payload["findingStatus"] = [{"id": 0, "name": "Open"}]

    logger.debug(
        "Built GFMS payload with control count: %d", len(payload.get("control", []))
    )
    return payload


async def get_gfms_findings(session_id: str, payload: Dict[str, Any]) -> Any:
    """
    Fetches GFMS findings based on the provided payload.

    Args:
        payload: The GFMS request payload.

    Returns:
        The findings data from the MCP tool.
    """
    if isinstance(payload, dict):
        control_count = len(
            payload.get("control", [])
            if isinstance(payload.get("control"), list)
            else []
        )
        logger.info("Fetching GFMS findings for %d control(s)", control_count)
    else:
        logger.info("Fetching GFMS findings")

    mcp = MCPClient(Config.data_extraction_mcp_server_url)
    try:
        gfms_result = await mcp.invoke("get_gfms_finding_data", {"request": payload})
        update_session_extract_mcp_tool(session_id, 'get_gfms_finding_data')
        logger.info("Successfully fetched GFMS findings")
        return gfms_result
    except Exception as exc:
        logger.warning(
            "GFMS call failed: payload_controls=%s error=%s",
            len(
                payload.get("control", [])
                if isinstance(payload, dict)
                and isinstance(payload.get("control"), list)
                else []
            ),
            exc,
        )
        raise
    finally:
        try:
            await mcp.close()
        except Exception as exc:
            logger.warning("GFMS MCP client close failed: %s", exc)
