import json
import os
import logging
from typing import Any, Dict, List

from config import settings

logger = logging.getLogger(__name__)


def build_plan_storage_paths(plan_number: str, current_data: object) -> tuple[str, str]:
    """Build plan folder name and inbound-data storage key."""
    plan_id = str(plan_number)

    if isinstance(current_data, list) and current_data and isinstance(current_data[0], dict):
        row = current_data[0]
        plan_id = str(row.get("Plan Item Number") or plan_number)
    elif isinstance(current_data, dict):
        plan_id = str(current_data.get("Plan Item Number") or plan_number)

    plan_folder_name = f"dbaware_review_{plan_id}"
    return plan_folder_name, f"{plan_folder_name}/inbound-data"

def save_json_to_file(
    data: Dict[str, Any] | List[Dict[str, Any]],
    plan_number: str,
    filename: str,
    source_folder: str | None = None,
    base_dir: str | None = None,
) -> str:
    """
    Saves a dictionary or list of dictionaries as a JSON file in the designated folder.

    Args:
        data: The data to save.
        plan_number: The plan item number, used as a subfolder name.
        filename: The name for the JSON file.
        source_folder: Optional subfolder name (e.g. "dbaware", "gfms").
        base_dir: Optional root directory; defaults to settings.DATA_DIR_.

    Returns:
        The full path to the saved file.
    """
    try:
    
        root_dir = str(base_dir) if base_dir else str(settings.DATA_DIR_)
        output_dir = os.path.join(root_dir, str(plan_number))
        if source_folder:
            output_dir = os.path.join(output_dir, source_folder)
        os.makedirs(output_dir, exist_ok=True)
        
        file_path = os.path.join(output_dir, filename)

        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        
        logger.info("Successfully saved data to %s", file_path)
        return file_path
    except Exception as e:
        logger.exception("Error saving file %s for plan %s: %s", filename, plan_number, e)
        raise