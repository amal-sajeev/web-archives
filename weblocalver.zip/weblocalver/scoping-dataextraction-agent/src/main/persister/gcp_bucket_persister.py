import os
import json
import logging
import shutil
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)
DEFAULT_LOCAL_BUCKET_ROOT = Path(__file__).resolve().parents[1] / "local-bucket"


def _local_bucket_root() -> Path:
    configured_root = os.getenv("LOCAL_BUCKET_ROOT", "").strip()
    if configured_root:
        return Path(configured_root)
    return DEFAULT_LOCAL_BUCKET_ROOT


def _local_path_from_gcs_uri(gcs_uri: str) -> Path:
    _, blob_path = _parse_gcs_uri(gcs_uri)
    return _local_bucket_root() / blob_path


def plan_prefix_uri(plan_number: str) -> str:
    """Return the root prefix for a plan in the configured bucket."""
    bucket_name = os.getenv("bucket_name", "").strip()
    if not bucket_name:
        raise ValueError("bucket_name is required to read extracted data.")
    return f"gs://{bucket_name}/dbaware_review_{plan_number}"


def inbound_prefix_uri(plan_number: str) -> str:
    """Return the inbound-data prefix for a plan in the configured bucket."""
    return f"{plan_prefix_uri(plan_number)}/inbound-data"


def _parse_gcs_uri(gcs_uri: str) -> tuple[str, str]:
    if not gcs_uri or not gcs_uri.startswith("gs://"):
        raise ValueError("GCS URI must start with gs://")
    without_scheme = gcs_uri[5:]
    if "/" not in without_scheme:
        raise ValueError("GCS URI must include object path after bucket name")
    bucket_name, blob_path = without_scheme.split("/", 1)
    if not bucket_name or not blob_path:
        raise ValueError("Invalid GCS URI")
    return bucket_name, blob_path


def _get_storage_client():
    import google.auth
    from google.cloud import storage

    credentials, project_id = google.auth.default()
    return storage.Client(project=project_id, credentials=credentials)



class GCPBucketPersister:
    def __init__(self) -> None:
        import google.auth
        from google.cloud import storage

        self.bucket_location = os.getenv("project_location", "")
        self.bucket_project = os.getenv("project_name", "")
        self.bucket_name = os.getenv("bucket_name", "").strip()

        if not self.bucket_name:
            raise ValueError("bucket_name is required to upload extracted data.")

        credentials, _ = google.auth.default()
        self.storage_client = storage.Client(
            project=self.bucket_project,
            credentials=credentials,
        )

    def upload_folder_to_bucket(self, local_folder: str, destination_prefix: str) -> str:
        """Upload all files from a local folder to GCS under the given prefix."""
        bucket = self.storage_client.bucket(self.bucket_name)
        prefix = destination_prefix.rstrip("/")

        root = Path(local_folder)
        uploaded_count = 0
        for file_path in root.rglob("*"):
            if not file_path.is_file():
                continue
            relative_path = file_path.relative_to(root).as_posix()
            blob_path = f"{prefix}/{relative_path}"
            try:
                bucket.blob(blob_path).upload_from_filename(str(file_path))
                uploaded_count += 1
            except Exception:
                logger.exception("Failed to upload %s to gs://%s/%s", file_path, self.bucket_name, blob_path)
                raise

        logger.info("Uploaded %d files to gs://%s/%s", uploaded_count, self.bucket_name, prefix)
        return f"gs://{self.bucket_name}/{prefix}"


def currently_local(local_folder: str, destination_prefix: str) -> str:
    """Copy files to local folder using the same path structure as bucket upload."""
    destination_root = _local_bucket_root() / destination_prefix.rstrip("/")
    destination_root.mkdir(parents=True, exist_ok=True)

    root = Path(local_folder)
    copied_count = 0
    for file_path in root.rglob("*"):
        if not file_path.is_file():
            continue
        relative_path = file_path.relative_to(root)
        target_path = destination_root / relative_path
        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file_path, target_path)
        copied_count += 1

    logger.info("Copied %d files locally to %s", copied_count, destination_root)
    return str(destination_root)


def delete_prefix(destination_prefix: str) -> int:
    """Delete every object under a prefix (GCS, or the local mirror when LOCAL_BUCKET_MODE=true)."""
    prefix = destination_prefix.strip("/") + "/"

    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        local_dir = _local_bucket_root() / prefix
        if not local_dir.exists():
            return 0
        count = sum(1 for p in local_dir.rglob("*") if p.is_file())
        shutil.rmtree(local_dir)
        logger.info("Deleted %d local files under %s", count, local_dir)
        return count

    persister = GCPBucketPersister()
    blobs = list(persister.storage_client.list_blobs(persister.bucket_name, prefix=prefix))
    for blob in blobs:
        blob.delete()
    logger.info("Deleted %d objects under gs://%s/%s", len(blobs), persister.bucket_name, prefix)
    return len(blobs)


def save_folder_to_destination(local_folder: str, destination_prefix: str) -> str:
    """Upload to GCS or mirror locally when LOCAL_BUCKET_MODE=true."""
    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        return currently_local(local_folder, destination_prefix)
    return GCPBucketPersister().upload_folder_to_bucket(local_folder, destination_prefix)


def download_json_from_gcs(gcs_uri: str) -> Any:
    """Download JSON content from a gs:// URI."""
    bucket_name, blob_path = _parse_gcs_uri(gcs_uri)
    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        local_path = _local_path_from_gcs_uri(gcs_uri)
        if not local_path.exists():
            raise FileNotFoundError(f"Local bucket mirror file not found: {local_path}")
        with open(local_path, "r", encoding="utf-8") as f:
            return json.load(f)

    storage_client = _get_storage_client()
    blob = storage_client.bucket(bucket_name).blob(blob_path)
    if not blob.exists(storage_client):
        raise FileNotFoundError(f"GCS object not found: {gcs_uri}")

    payload = blob.download_as_text(encoding="utf-8")
    return json.loads(payload)


def upload_json_to_gcs(data: Any, gcs_uri: str) -> str:
    """Upload JSON content to a gs:// URI."""
    bucket_name, blob_path = _parse_gcs_uri(gcs_uri)
    payload = json.dumps(data, ensure_ascii=False, indent=2)

    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        local_path = _local_path_from_gcs_uri(gcs_uri)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        with open(local_path, "w", encoding="utf-8") as f:
            f.write(payload)
        return str(local_path)

    storage_client = _get_storage_client()
    blob = storage_client.bucket(bucket_name).blob(blob_path)
    blob.upload_from_string(payload, content_type="application/json")
    return gcs_uri


def upload_text_to_gcs(text: str, gcs_uri: str, content_type: str = "text/plain; charset=utf-8") -> str:
    """Upload plain text content to a gs:// URI."""
    bucket_name, blob_path = _parse_gcs_uri(gcs_uri)

    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        local_path = _local_path_from_gcs_uri(gcs_uri)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        with open(local_path, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        return str(local_path)

    storage_client = _get_storage_client()
    blob = storage_client.bucket(bucket_name).blob(blob_path)
    blob.upload_from_string(text, content_type=content_type)
    return gcs_uri


def json_exists_in_gcs(gcs_uri: str) -> bool:
    """Return True when the object behind a gs:// URI exists."""
    bucket_name, blob_path = _parse_gcs_uri(gcs_uri)
    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        return _local_path_from_gcs_uri(gcs_uri).exists()

    storage_client = _get_storage_client()
    return storage_client.bucket(bucket_name).blob(blob_path).exists(storage_client)


def gcs_prefix_exists(gcs_prefix_uri: str) -> bool:
    """Return True when at least one object exists below a GCS prefix."""
    bucket_name, prefix = _parse_gcs_uri(gcs_prefix_uri)
    prefix = prefix.rstrip("/") + "/"

    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        local_prefix = _local_path_from_gcs_uri(f"gs://{bucket_name}/{prefix}")
        if not local_prefix.exists():
            return False
        return any(path.is_file() for path in local_prefix.rglob("*"))

    storage_client = _get_storage_client()
    return next(iter(storage_client.list_blobs(bucket_name, prefix=prefix, max_results=1)), None) is not None


def list_json_blobs_in_gcs(gcs_prefix_uri: str) -> list[str]:
    """Return gs:// URIs of the JSON files stored directly under a prefix."""
    bucket_name, prefix = _parse_gcs_uri(gcs_prefix_uri)
    prefix = prefix.rstrip("/") + "/"

    if os.getenv("LOCAL_BUCKET_MODE", "").strip().lower() in {"1", "true", "yes"}:
        local_prefix = _local_path_from_gcs_uri(f"gs://{bucket_name}/{prefix}")
        if not local_prefix.exists() or not local_prefix.is_dir():
            return []
        return sorted(
            f"gs://{bucket_name}/{prefix}{path.name}"
            for path in local_prefix.iterdir()
            if path.is_file() and path.suffix.lower() == ".json"
        )

    storage_client = _get_storage_client()
    blobs = storage_client.list_blobs(bucket_name, prefix=prefix, delimiter="/")
    return sorted(
        f"gs://{bucket_name}/{blob.name}"
        for blob in blobs
        if blob.name.lower().endswith(".json")
    )