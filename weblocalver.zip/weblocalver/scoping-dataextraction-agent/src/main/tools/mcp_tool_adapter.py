from typing import Any, List, Optional
import logging

import httpx
from langchain_mcp_adapters.client import MultiServerMCPClient

from config.settings import Config

_MCP_CLIENT: Optional[MultiServerMCPClient] = None
_MCP_TOOLS: Optional[List[Any]] = None
logger = logging.getLogger(__name__)


def _local_mcp_http_client_factory(
    headers: Optional[dict[str, str]] = None,
    timeout: Optional[httpx.Timeout] = None,
    auth: Optional[httpx.Auth] = None,
) -> httpx.AsyncClient:
    return httpx.AsyncClient(
        headers=headers,
        timeout=timeout,
        auth=auth,
        follow_redirects=True,
        trust_env=False,
        verify=False,
    )


async def get_mcp_tools() -> List[Any]:
    global _MCP_CLIENT, _MCP_TOOLS

    if _MCP_TOOLS is not None:
        logger.debug("Returning cached MCP tools (count=%s)", len(_MCP_TOOLS))
        return _MCP_TOOLS

    if not Config.data_extraction_mcp_server_url:
        logger.error("MCP server URL is not configured")
        raise ValueError("data_extraction_mcp_server_url must be configured")

    logger.info(
        "Initializing MCP client for server '%s'",
        Config.data_extraction_mcp_server_name,
    )

    try:
        _MCP_CLIENT = MultiServerMCPClient(
            {
                Config.data_extraction_mcp_server_name: {
                    "transport": "streamable_http",
                    "url": Config.data_extraction_mcp_server_url,
                    "httpx_client_factory": _local_mcp_http_client_factory,
                }
            }
        )
        _MCP_TOOLS = await _MCP_CLIENT.get_tools()
        logger.info("Fetched MCP tools successfully (count=%s)", len(_MCP_TOOLS))
        return _MCP_TOOLS
    except Exception:
        logger.exception(
            "Failed to initialize MCP tools from server '%s'",
            Config.data_extraction_mcp_server_name,
        )
        _MCP_CLIENT = None
        _MCP_TOOLS = None
        raise
