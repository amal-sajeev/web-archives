import json
import logging
import os
from pathlib import Path
from typing import Any, TYPE_CHECKING

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

_base_dir = Path(__file__).resolve().parent
_env_candidates = [
    _base_dir.parent.parent / ".env",
    _base_dir.parent / ".env",
    _base_dir / ".env",
    Path("/app/.env"),
    Path.cwd() / ".env",
]
for _env_path in _env_candidates:
    if _env_path.exists():
        load_dotenv(_env_path)
        break

if TYPE_CHECKING:
    import sqlalchemy
    from sqlalchemy import text
else:
    try:
        import sqlalchemy
        from sqlalchemy import text
    except (
        ModuleNotFoundError
    ):  # pragma: no cover - optional dependency for local/test installs
        sqlalchemy = None  # type: ignore[assignment]
        text = None  # type: ignore[assignment]


class DBConnector:
    """Database connector with a safe no-op fallback when DB config is absent."""

    def __init__(self):
        self.db_host = os.getenv("db_host") or os.getenv("DB_HOST")
        self.db_user = os.getenv("db_user") or os.getenv("DB_USER")
        self.db_pass = os.getenv("scoping_db_pass") or os.getenv("SCOPING_DB_PASS")
        self.db_name = os.getenv("db_name") or os.getenv("DB_NAME")
        self.db_port = os.getenv("db_port", "5432") or os.getenv("DB_PORT", "5432")
        self.table_name = (
            os.getenv("DATA_EXTRACTION_TABLE_NAME")
            or os.getenv("data_extraction_table_name")
            or "dbaware_scoping.review_data_extraction"
        )

    def _validate_config(self) -> None:
        if sqlalchemy is None:
            raise ModuleNotFoundError(
                "sqlalchemy is required for database persistence."
            )

        missing = []
        if not self.db_host:
            missing.append("db_host")
        if not self.db_user:
            missing.append("db_user")
        if not self.db_pass:
            missing.append("db_pass / DB_PASS / scoping_db_pass")
        if not self.db_name:
            missing.append("db_name")

        if missing:
            raise ValueError(
                f"Missing database environment variables: {', '.join(missing)}"
            )

    def connect_to_database(self):
        self._validate_config()

        pool = sqlalchemy.create_engine(
            sqlalchemy.engine.url.URL.create(
                drivername="postgresql+pg8000",
                username=self.db_user,
                password=self.db_pass,
                host=self.db_host,
                port=self.db_port,
                database=self.db_name,
            ),
            pool_pre_ping=True,
            future=True,
        )
        logger.info(
            "Created SQLAlchemy engine for db_host=%s db_name=%s db_port=%s table=%s",
            self.db_host,
            self.db_name,
            self.db_port,
            self.table_name,
        )
        return pool

    def check_connection(self) -> bool:
        if sqlalchemy is None:
            logger.warning(
                "SQLAlchemy is not installed; database connectivity cannot be checked."
            )
            return False

        engine = self.connect_to_database()
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        logger.info("Database connectivity check passed")
        return True

    def persist_data_extraction_record(
        self,
        source_name: str,
        review_scope_instance_id: int | None,
        request_payload: dict[str, Any] | list[dict[str, Any]] | None,
        user: str | None = None,
        remarks: str | None = None,
    ) -> Any:
        if sqlalchemy is None:
            logger.info(
                "SQLAlchemy is not installed; skipping persistence for source=%s review_scope_instance_id=%s",
                source_name,
                review_scope_instance_id,
            )
            return None

        missing_config = [
            name
            for name, value in {
                "db_host": self.db_host,
                "db_user": self.db_user,
                "db_pass": self.db_pass,
                "db_name": self.db_name,
            }.items()
            if not value
        ]
        if missing_config:
            logger.warning(
                "DB persistence skipped for source=%s because required config is missing: %s",
                source_name,
                ", ".join(missing_config),
            )
            return None

        if review_scope_instance_id is None:
            logger.warning(
                "DB persistence skipped for source=%s because review_scope_instance_id is missing.",
                source_name,
            )
            return None

        payload_json = json.dumps(request_payload, ensure_ascii=False, default=str)
        logger.info(
            "Attempting to persist extraction payload for source=%s review_scope_instance_id=%s user=%s remarks=%s payload_size=%s table=%s",
            source_name,
            review_scope_instance_id,
            user,
            remarks,
            len(payload_json),
            self.table_name,
        )

        try:
            engine = self.connect_to_database()
            with engine.begin() as connection:
                connection.execute(text(f"""
                        CREATE TABLE IF NOT EXISTS {self.table_name} (
                            review_scope_dataext_id SERIAL PRIMARY KEY,
                            review_scope_instance_id INTEGER,
                            data_source VARCHAR(255),
                            metadata JSONB,
                            created_by VARCHAR(255),
                            created_on TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                            updated_by VARCHAR(255),
                            updated_on TIMESTAMP,
                            remarks VARCHAR(255)
                        )
                        """))

                update_result = connection.execute(
                    text(f"""
                        UPDATE {self.table_name}
                        SET metadata = CAST(:metadata AS JSONB),
                            remarks = :remarks,
                            updated_by = :updated_by,
                            updated_on = CURRENT_TIMESTAMP
                        WHERE review_scope_instance_id = :review_scope_instance_id
                        AND data_source = :data_source
                        """),
                    {
                        "review_scope_instance_id": review_scope_instance_id,
                        "data_source": source_name,
                        "metadata": payload_json,
                        "remarks": remarks,
                        "updated_by": user,
                    },
                )

                if update_result.rowcount and update_result.rowcount > 0:
                    logger.info(
                        "DB persistence result: UPDATED existing row for source=%s review_scope_instance_id=%s user=%s table=%s",
                        source_name,
                        review_scope_instance_id,
                        user,
                        self.table_name,
                    )
                    operation = "updated"
                else:
                    connection.execute(
                        text(f"""
                            INSERT INTO {self.table_name} (
                                review_scope_instance_id,
                                data_source,
                                metadata,
                                created_by,
                                created_on,
                                remarks
                            ) VALUES (
                                :review_scope_instance_id,
                                :data_source,
                                CAST(:metadata AS JSONB),
                                :created_by,
                                CURRENT_TIMESTAMP,
                                :remarks
                            )
                            """),
                        {
                            "review_scope_instance_id": review_scope_instance_id,
                            "data_source": source_name,
                            "metadata": payload_json,
                            "created_by": user,
                            "remarks": remarks,
                        },
                    )
                    logger.info(
                        "DB persistence result: INSERTED new row for source=%s review_scope_instance_id=%s user=%s table=%s",
                        source_name,
                        review_scope_instance_id,
                        user,
                        self.table_name,
                    )
                    operation = "inserted"

            persisted_record = {
                "source_name": source_name,
                "review_scope_instance_id": review_scope_instance_id,
                "user": user,
                "remarks": remarks,
                "metadata": request_payload,
                "operation": operation,
            }
            logger.info(
                "DB persistence completed successfully for source=%s review_scope_instance_id=%s operation=%s table=%s",
                source_name,
                review_scope_instance_id,
                operation,
                self.table_name,
            )
            return persisted_record
        except Exception as exc:
            logger.warning(
                "DB not persisted for source=%s review_scope_instance_id=%s table=%s error=%s",
                source_name,
                review_scope_instance_id,
                self.table_name,
                exc,
            )
            return None


DatabaseConnector = DBConnector
