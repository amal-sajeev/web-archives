import os
import sys
import logging
from typing import Dict, Any

from langchain_google_genai import ChatGoogleGenerativeAI

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.settings import Config

logger = logging.getLogger(__name__)


def initialize_gemini_model() -> ChatGoogleGenerativeAI:
    """Initialize and return a ChatGoogleGenerativeAI model instance.
    
    Reads model configuration from Config and establishes connection to Google Generative AI.
    
    Returns:
        ChatGoogleGenerativeAI: Initialized Gemini model instance
        
    Raises:
        ValueError: If required configuration is missing
        Exception: If model initialization fails (auth, network, etc.)
    """
    try:
        # Validate required configuration
        if not Config.MODEL_NAME:
            raise ValueError("MODEL_NAME not configured")
        if not Config.PROJECT_NAME:
            raise ValueError("PROJECT_NAME not configured")
        if not Config.PROJECT_LOCATION:
            raise ValueError("PROJECT_LOCATION not configured")
        
        # Build model initialization parameters
        model_params: Dict[str, Any] = {
            "model": Config.MODEL_NAME,
            "project": Config.PROJECT_NAME,
            "location": Config.PROJECT_LOCATION,
            "temperature": Config.GENERATION_CONFIG.get("temperature", 0.7),
            "top_p": Config.GENERATION_CONFIG.get("top_p", 0.95),
            "top_k": Config.GENERATION_CONFIG.get("top_k"),
            "safety_settings": Config.SAFETY_CONFIG.get("safety_settings", []),
        }
        
        model = ChatGoogleGenerativeAI(**model_params)
        logger.info("Gemini model initialized: %s (project=%s, location=%s)", 
                   Config.MODEL_NAME, Config.PROJECT_NAME, Config.PROJECT_LOCATION)
        return model
        
    except ValueError as e:
        logger.error("Configuration validation failed: %s", e)
        raise
    except Exception as e:
        logger.exception(
            "Failed to initialize Gemini model for project=%s location=%s",
            Config.PROJECT_NAME,
            Config.PROJECT_LOCATION,
        )
        raise

    