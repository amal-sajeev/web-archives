import json
import logging
import re
from functools import lru_cache
from pathlib import Path
from typing import Optional, List, Set, Dict, Any

from config.settings import Config
from util.gemini_connection import initialize_gemini_model
from util.status_helper import append_session_llm_usage

logger = logging.getLogger(__name__)
PROMPTS_DIR = Path(__file__).resolve().parents[1] / "etc" / "prompts"
HISTORICAL_PLAN_MATCHING_PROMPT_FILE = "historical_plan_matching_prompt.json"

# Cap on how many candidates get sent to the LLM after semantic prefiltering.
SEMANTIC_PREFILTER_MAX_CANDIDATES = 15


def _tokenize(text: str) -> Set[str]:
    return {token for token in re.findall(r"[a-z0-9]+", text.lower()) if len(token) > 2}


@lru_cache(maxsize=1)
def _load_prompt_text(filename: str = HISTORICAL_PLAN_MATCHING_PROMPT_FILE) -> str:
    prompt_path = PROMPTS_DIR / filename
    if not prompt_path.exists():
        raise ValueError(f"Prompt file not found: {prompt_path}")

    payload = json.loads(prompt_path.read_text(encoding="utf-8"))
    prompt_instructions = payload.get("prompt_instructions")
    if not isinstance(prompt_instructions, dict):
        raise ValueError(f"Prompt file must contain prompt_instructions: {prompt_path}")

    lines: list[str] = []
    for section in prompt_instructions.values():
        if not isinstance(section, dict):
            continue
        content = section.get("content")
        if isinstance(content, str):
            lines.append(content.strip())
        elif isinstance(content, list):
            lines.extend(str(item).strip() for item in content if str(item).strip())

    if not lines:
        raise ValueError(f"Prompt file has no prompt content: {prompt_path}")

    return "\n".join(lines)


def _candidate_plan_item_number(candidate: Dict[str, Any]) -> Any:
    return candidate.get("plan_item_number") or candidate.get("Plan Item Number")


def _candidate_plan_item_title(candidate: Dict[str, Any]) -> str:
    return str(candidate.get("plan_item_title") or candidate.get("Plan Item Title") or "")


def _candidate_plan_item_description(candidate: Dict[str, Any]) -> str:
    return str(
        candidate.get("description_of_plan_item")
        or candidate.get("plan_item_description")
        or candidate.get("Description of Plan Item")
        or ""
    )


def _get_usage_metadata(response: Any) -> dict[str, Any]:
    usage_metadata = getattr(response, "usage_metadata", None)
    if isinstance(usage_metadata, dict):
        return usage_metadata

    response_metadata = getattr(response, "response_metadata", None)
    if isinstance(response_metadata, dict):
        fallback_usage_metadata = response_metadata.get("usage_metadata")
        if isinstance(fallback_usage_metadata, dict):
            return fallback_usage_metadata

    return {}


def _get_model_params() -> dict[str, Any]:
    return {
        "model": Config.MODEL_NAME,
        "project": Config.PROJECT_NAME,
        "location": Config.PROJECT_LOCATION,
        "temperature": Config.GENERATION_CONFIG.get("temperature", 0.7),
        "top_p": Config.GENERATION_CONFIG.get("top_p", 0.95),
        "top_k": Config.GENERATION_CONFIG.get("top_k"),
        "safety_settings": Config.SAFETY_CONFIG.get("safety_settings", []),
    }


def _build_usage_record(operation: str, response: Any) -> dict[str, Any]:
    return {
        "operation": operation,
        "model_params": _get_model_params(),
        "usage_metadata": _get_usage_metadata(response),
    }


def semantic_prefilter_candidates(
    plan_title: str,
    candidates: List[Dict[str, Any]],
    max_candidates: int = SEMANTIC_PREFILTER_MAX_CANDIDATES,
) -> List[Dict[str, Any]]:
    """Narrow down candidates by dynamically computed rare-token overlap before the LLM call.

    Token rarity is derived from the candidate corpus itself (document frequency) rather than a
    static stopword list, so common words in this dataset (e.g. "review", "global") are
    automatically down-weighted while distinctive terms drive the match.
    """
    title_tokens = _tokenize(plan_title)
    if not title_tokens or not candidates:
        return candidates

    doc_frequency: Dict[str, int] = {}
    candidate_tokens: List[Set[str]] = []
    for candidate in candidates:
        tokens = _tokenize(_candidate_plan_item_title(candidate))
        candidate_tokens.append(tokens)
        for token in tokens:
            doc_frequency[token] = doc_frequency.get(token, 0) + 1

    # A token is "rare" (and therefore meaningful) if it appears in only a minority of candidates.
    rarity_threshold = max(1, len(candidates) // 10)
    rare_title_tokens = {token for token in title_tokens if doc_frequency.get(token, 0) <= rarity_threshold}
    if not rare_title_tokens:
        rare_title_tokens = title_tokens

    scored = [
        (len(tokens & rare_title_tokens), candidate)
        for candidate, tokens in zip(candidates, candidate_tokens)
    ]
    scored = [item for item in scored if item[0] > 0]
    if not scored:
        logger.debug("Semantic prefilter found no token overlap, falling back to full candidate set")
        return candidates

    scored.sort(key=lambda item: item[0], reverse=True)
    narrowed = [candidate for _, candidate in scored[:max_candidates]]
    logger.debug(
        "Semantic prefilter narrowed %d candidates down to %d", len(candidates), len(narrowed)
    )
    return narrowed


def build_llm_match_prompt(
    plan_title: str,
    candidates: List[Dict[str, Any]],
    plan_description: Optional[str] = None,
    uot_countries: Optional[str] = None,
) -> str:
    prompt_template = _load_prompt_text()
    candidate_lines = [
        f"- Plan Item Number: {_candidate_plan_item_number(c)}; "
        f"Title: {_candidate_plan_item_title(c)}; "
        f"Description: {_candidate_plan_item_description(c) or 'Not provided'}; "
        f"UoT Countries: {c.get('UoT Countries')}; "
        for c in candidates
    ]
    return "\n".join(
        [
            prompt_template,
            f"Input title: {plan_title}",
            f"Input description: {plan_description or 'Not provided'}",
            f"Input UoT Countries: {uot_countries or 'Not provided'}",
            "Candidate historical plan items:",
            *candidate_lines,
        ]
    )



def _parse_llm_plan_item_numbers(response_text: str) -> Set[str]:
    """Parse LLM response to extract plan item numbers.

    Args:
        response_text: The LLM response text (may contain JSON with markdown)

    Returns:
        A set of plan item number strings

    Raises:
        ValueError: If response cannot be parsed as valid JSON
    """
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", response_text.strip())
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as e:
        logger.debug("Initial JSON parse failed, attempting to extract JSON from response")
        match = re.search(r"\{[\s\S]*\}|\[[\s\S]*\]", cleaned)
        if not match:
            logger.error("Failed to extract JSON from LLM response: %s", response_text[:100])
            raise ValueError(f"No valid JSON found in LLM response: {str(e)}") from e
        try:
            parsed = json.loads(match.group(0))
        except json.JSONDecodeError as e2:
            logger.error("Failed to parse extracted JSON: %s", match.group(0)[:100])
            raise ValueError(f"Extracted JSON is invalid: {str(e2)}") from e2

    if isinstance(parsed, dict):
        parsed = parsed.get("matches", [])
    if not isinstance(parsed, list):
        logger.error("LLM response does not contain a list or matches array: %s", parsed)
        raise ValueError("LLM response must be a JSON array or an object with a matches array.")

    logger.debug("Parsed %d plan item numbers from LLM response", len(parsed))
    return {str(item) for item in parsed}


def filter_matches_with_llm(
    plan_title: str,
    candidates: List[Dict[str, Any]],
    plan_description: Optional[str] = None,
    uot_countries: Optional[str] = None,
    session_id: Optional[str] = None,
) -> Optional[List[str]]:
    """Filter candidate plan items using LLM semantic matching.

    Args:
        plan_title: The current plan title to match
        candidates: List of historical candidate records
        uot_countries: Optional string of UoT countries to consider in matching

    Returns:
        List of matched plan item numbers, or None if no matches

    Raises:
        Exception: If LLM initialization or invocation fails
    """
    try:
        logger.debug("Initializing Gemini model for plan title matching")
        llm_client = initialize_gemini_model()

        narrowed_candidates = semantic_prefilter_candidates(plan_title, candidates)

        logger.debug("Building LLM prompt for %d candidates", len(narrowed_candidates))
        prompt = build_llm_match_prompt(
            plan_title,
            narrowed_candidates,
            plan_description=plan_description,
            uot_countries=uot_countries,
        )

        logger.debug("Invoking LLM for historical plan item matching")
        response = llm_client(prompt) if callable(llm_client) else llm_client.invoke(prompt)
        content = getattr(response, "content", response)
        response_text = content if isinstance(content, str) else json.dumps(content)

        usage_record = _build_usage_record("historical_plan_matching", response)
        # logger.info("Historical plan matching usage_record=%s", usage_record)
        if session_id:
            append_session_llm_usage(session_id, usage_record)

        logger.debug("LLM response received, parsing results")
        selected = _parse_llm_plan_item_numbers(response_text)

        candidate_numbers = {str(_candidate_plan_item_number(c)) for c in narrowed_candidates}
        matches = [number for number in selected if number in candidate_numbers]

        if matches:
            logger.info("Found %d historical matches for plan", len(matches))
        else:
            logger.debug("No historical matches found for plan title")

        return matches or None
    except Exception as e:
        logger.exception("Failed to filter matches with LLM for plan_title=%s", plan_title)
        raise


async def find_historical_plan_items(
    plan_title: str,
    plan_description: Optional[str] = None,
    uot_countries: Optional[str] = None,
    records: Optional[List[Dict[str, Any]]] = None,
    session_id: Optional[str] = None,
) -> Optional[List[str]]:
    """Match historical plan items via Gemini, returning the matched Plan Item Numbers.

    Args:
        plan_title: The current plan title to match
        records: Historical records to search for matches
        plan_description: Optional current plan description to consider in matching
        uot_countries: Optional string of UoT countries to consider in matching

    Returns:
        List of matched plan item numbers, or None if no matches found
    """
    try:
        if not plan_title or not plan_title.strip():
            logger.debug("Skipping historical plan matching: empty plan_title")
            return None

        if not records:
            logger.debug("Skipping historical plan matching: no records provided")
            return None

        logger.debug("Starting historical plan item matching with %d candidates", len(records))
        matches = filter_matches_with_llm(
            plan_title,
            records,
            plan_description=plan_description,
            uot_countries=uot_countries,
            session_id=session_id,
        )
        return matches or None
    except Exception as e:
        logger.exception("Error finding historical plan items for plan_title=%s", plan_title)
        raise

