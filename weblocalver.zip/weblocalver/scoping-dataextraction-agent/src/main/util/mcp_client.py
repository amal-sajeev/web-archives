import httpx
import logging
import json
from typing import Any, Dict, List, Optional
from tools.mcp_tool_adapter import get_mcp_tools

logger = logging.getLogger(__name__)


def _find_tool_by_name(tools: List[Any], tool_name: str) -> Optional[Any]:
    for tool in tools:
        if getattr(tool, "name", "") == tool_name:
            return tool
    return None


def _extract_mcp_output(result: Any) -> Any:
    if isinstance(result, list) and result:
        first_item = result[0]
        if isinstance(first_item, dict) and isinstance(first_item.get("text"), str):
            try:
                return json.loads(first_item["text"])
            except json.JSONDecodeError:
                logger.debug("MCP response text is not JSON; returning raw result")
                return result
    return result


class MCPClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8000"):
        self.invoke_url = f"{base_url}/tools/invoke"
        self.async_client = httpx.AsyncClient(
            verify=False,
            limits=httpx.Limits(max_keepalive_connections=0),
            trust_env=False,
        )
        logger.debug("MCPClient initialized with base URL %s", base_url)

    async def invoke(self, tool_name: str, args: Dict[str, Any]) -> Any:
        """Invokes a single tool on the MCP server."""
        logger.info("Invoking MCP tool '%s'", tool_name)
        try:
            tools = await get_mcp_tools()
            tool = _find_tool_by_name(tools, tool_name)
            if tool is None:
                logger.error("MCP tool '%s' was not discovered", tool_name)
                raise RuntimeError("MCP tool '%s' was not discovered" % tool_name)

            result = await tool.ainvoke(args)
            parsed_output = _extract_mcp_output(result)
            logger.debug("MCP tool '%s' invocation completed", tool_name)
            return parsed_output
        except Exception:
            logger.exception("MCP invocation failed for tool '%s'", tool_name)
            raise

    async def close(self):
        """Closes the underlying HTTP client."""
        try:
            await self.async_client.aclose()
            logger.debug("MCP client HTTP session closed")
        except Exception:
            logger.exception("Failed while closing MCP client HTTP session")
            raise
