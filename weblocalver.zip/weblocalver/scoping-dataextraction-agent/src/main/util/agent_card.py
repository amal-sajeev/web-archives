import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_ACTOR_ID = "data-extraction-agent"
DEFAULT_PARENT_ENTITY_TYPE = "SCOPING"
DEFAULT_ACTION_TYPE = "DATA_EXTRACT AND SAVE"
DEFAULT_ENVIRONMENT = "dev"
DEFAULT_SERVICE_VERSION = "unknown"
DEFAULT_ENTITY_TYPE = "DATA_EXTRACTION"



class AgentCard:
    cache: dict[str, str] = {}
    def __init__(self):
        pass

    @classmethod
    def build_agent_card(cls,
        entity_type: str,
        plan_item_number: str,
        activity_type: str = "DATA_EXTRACTION",
        action_type: str = DEFAULT_ACTION_TYPE,
        parent_entity_type: str | None = None,
        parent_entity_id: str | None = None,
        status: str = "SUCCESS",
        duration_ms: int | None = None,
        error_message: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build an agent-card dictionary describing one agent activity.

        This function only builds the agent-card dictionary; it does not persist it.
        Callers that need the card stored against a session should pass the returned
        dictionary to `util.status_helper.set_session_agent_card`.

        Args:
            activity_type: The type of activity performed by the agent.
            plan_item_number: required plan number; used to derive ENTITY_ID and the default parent entity ID.
            activity_id: Identifier for the activity being recorded.
            action_type: The action performed for this activity. Defaults to "GENERATE".
            parent_entity_type: Optional parent entity type; defaults to "SCOPING".
            parent_entity_id: Optional parent entity ID; defaults to plan_item_number or a service identifier.
            status: The outcome status of the activity. Defaults to "SUCCESS".
            correlation_id: Optional correlation ID; used as ENTITY_ID when supplied.
            duration_ms: Optional duration of the activity in milliseconds.
            error_message: Optional error message, included only for non-success statuses.
            metadata: Optional additional metadata to attach to the agent card.

        Returns:
            A dictionary describing the agent activity.
        """
        plan_item_number = plan_item_number.strip()
        agent_card = cls.cache.get(plan_item_number)

        if not agent_card:
            agent_card1: dict[str, Any] = {
                "ACTOR_ID": os.getenv("ACTOR_ID") or DEFAULT_ACTOR_ID,
                "ACTIVITY_ID": activity_type,
                "ENTITY_ID": str(uuid.uuid5(uuid.NAMESPACE_DNS, plan_item_number)),
                "ENTITY_TYPE": entity_type or DEFAULT_ENTITY_TYPE,
                "PARENT_ENTITY_TYPE": parent_entity_type or DEFAULT_PARENT_ENTITY_TYPE,
                "PARENT_ENTITY_ID": parent_entity_id or plan_item_number ,
                "ACTIVITY_TYPE": activity_type,
                "ACTION_TYPE": action_type,
                "STATUS": status,
                "TIMESTAMP": cls.utc_timestamp(),
                "ENVIRONMENT": cls.resolve_environment(),
                "SERVICE_VERSION": os.getenv("SERVICE_VERSION", DEFAULT_SERVICE_VERSION),
                }

            if duration_ms is not None:
                agent_card1["DURATION_MS"] = duration_ms

            if error_message and status != "SUCCESS":
                agent_card1["ERROR_MESSAGE"] = error_message

            if metadata is not None:
                agent_card1["METADATA"] = dict(metadata)
            cls.cache[plan_item_number] = agent_card1
            agent_card = agent_card1
        logger.info("Generated agent card: %s", agent_card)
        return agent_card

    @classmethod
    def resolve_environment(cls) -> str:
        return os.getenv("ENVIRONMENT") or os.getenv("ENV") or DEFAULT_ENVIRONMENT

    @classmethod
    def utc_timestamp(cls) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    @classmethod
    def resolve_entity_id(cls, plan_item_number: str | None) -> str:
        if plan_item_number:
            return str(uuid.uuid5(PLAN_ENTITY_UUID_NAMESPACE, str(plan_item_number)))
        return str(uuid.uuid4())

    @classmethod
    def get_agent_card(cls, plan_number: str) -> dict[str, Any]:
       plan_item_number = plan_number.strip()
       return cls.cache.get(plan_item_number, None)