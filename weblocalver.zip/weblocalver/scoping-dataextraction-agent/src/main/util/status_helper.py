import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from typing import Any

import yaml

from model.status_enum import Status


request_status_file_path = os.path.join(".", "tmp", "data_extraction_request_status.yml")

_session_file_lock = Lock()


def update_session_requests_file(request_status: dict[str, Any]) -> None:
	"""Atomically persist all extraction session data to the YAML file."""
	status_file = Path(request_status_file_path)
	status_file.parent.mkdir(parents=True, exist_ok=True)

	with tempfile.NamedTemporaryFile( mode="w", encoding="utf-8", dir=status_file.parent, delete=False ) as temporary_file:
		yaml.safe_dump(request_status, temporary_file, sort_keys=False)
		temporary_path = Path(temporary_file.name)

	temporary_path.replace(status_file)


def read_session_requests_file() -> dict[str, Any]:
	"""Read all extraction sessions, returning an empty store when absent."""
	status_file = Path(request_status_file_path)
	status_file.parent.mkdir(parents=True, exist_ok=True)

	if not status_file.exists():
		return {}

	with status_file.open("r", encoding="utf-8") as file_read:
		request_status = yaml.safe_load(file_read)

	return request_status if isinstance(request_status, dict) else {}


def set_session_status(
	session_id: str,
	stage_name: str,
	status: Status,
	error: str = "",
	plan_number: str | None = None,
) -> None:
	"""Create or update a session and persist its current lifecycle status."""
	now = datetime.now(timezone.utc).isoformat()

	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})

		session["session_id"] = session_id
		session["stage"] = stage_name
		session["status"] = status.value
		session["error"] = error
		session.setdefault("created_at", now)
		session["updated_at"] = now
		if plan_number is not None:
			session["plan_number"] = str(plan_number)

		current_run = request_status.setdefault("current_run", {})
		if status is Status.PROCESSING:
			current_run[stage_name] = session_id
		elif current_run.get(stage_name) == session_id:
			current_run[stage_name] = ""

		update_session_requests_file(request_status)


def get_session_status(session_id: str) -> dict[str, Any] | None:
	"""Return one session, or None when the session ID is unknown."""
	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.get(session_id)

	return session if isinstance(session, dict) else None


def append_session_llm_usage(session_id: str, usage_record: dict[str, Any]) -> None:
	"""Append one LLM usage record to a persisted extraction session."""
	now = datetime.now(timezone.utc).isoformat()

	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})
		session["session_id"] = session_id
		session.setdefault("created_at", now)
		session["updated_at"] = now
		llm_usage = session.setdefault("llm_usage", [])
		if not isinstance(llm_usage, list):
			llm_usage = []
			session["llm_usage"] = llm_usage
		llm_usage.append({"created_at": now, **usage_record})

		update_session_requests_file(request_status)


def set_session_agent_card(session_id: str, agent_card: dict[str, Any]) -> None:
	"""Set the single agent-card record for a persisted extraction session."""
	now = datetime.now(timezone.utc).isoformat()

	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})
		session["session_id"] = session_id
		session.setdefault("created_at", now)
		session["updated_at"] = now
		session["agent_card"] = agent_card

		update_session_requests_file(request_status)


def get_current_run_info(stage_name: str) -> str | None:
	"""Return the active session ID for a stage, if one exists."""
	with _session_file_lock:
		request_status = read_session_requests_file()
		current_run = request_status.get("current_run", {})

	session_id = current_run.get(stage_name) if isinstance(current_run, dict) else None
	return session_id or None

def set_session_extract_end_time(session_id: str) -> None:
	"""Set the  extract end time."""
	now = datetime.now(timezone.utc).isoformat()

	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})
		session["session_id"] = session_id
		session["extract_end_time"] = now

		update_session_requests_file(request_status)


def set_session_extract_start_time(session_id: str) -> None:
	"""Set the extract end timen."""
	now = datetime.now(timezone.utc).isoformat()

	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})
		session["session_id"] = session_id
		session["extract_start_time"] = now

		update_session_requests_file(request_status)

def set_session_extract_response(session_id: str, response: dict) -> None:
	"""Set the extract response"""


	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})
		session["session_id"] = session_id
		session["response"] = response

		update_session_requests_file(request_status)

def update_session_extract_mcp_tool(session_id: str, tool_name:str) -> None:
	"""Set the mcp_tool_names"""
	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})
		session["session_id"] = session_id
		mcp_tool = session.get('mcp_tool', None)
		if mcp_tool:
			mcp_tool.add(tool_name)
		else:
			mcp_tool1 = set()
			mcp_tool1.add(tool_name)
			session['mcp_tool'] = mcp_tool1
		update_session_requests_file(request_status)


def set_session_extract_title_name(session_id: str, title_name: str) -> None:
	"""Set the mcp_tool_names"""
	with _session_file_lock:
		request_status = read_session_requests_file()
		session = request_status.setdefault(session_id, {})
		session["session_id"] = session_id
		session["plan_title_name"] = title_name
		update_session_requests_file(request_status)