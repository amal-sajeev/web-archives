import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


# Base directories
SRC_MAIN_DIR = Path(__file__).resolve().parents[1]

# Directory to store the output JSONs, now correctly inside src/main/
DATA_DIR_ = SRC_MAIN_DIR / "data"


class Config:
    """Application configuration loaded from .env."""

    HTTP_PROXY = os.getenv("http_proxy", "")
    HTTPS_PROXY = os.getenv("https_proxy", "")
    NO_PROXY = os.getenv("no_proxy", "")

    MODEL_NAME = os.getenv("MODEL_NAME", "gemini-2.5-pro")
    PROJECT_NAME = os.getenv("PROJECT_NAME") or os.getenv("project_name")
    PROJECT_LOCATION = os.getenv("PROJECT_LOCATION") or os.getenv("project_location")
    GENERATION_CONFIG = {
        "temperature": 0.0,
        "top_p": 0.5,
        "top_k": 32,
    }
    SAFETY_CONFIG = {
        "safety_settings": {
            "HARM_CATEGORY_HARASSMENT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_HATE_SPEECH": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_MEDIUM_AND_ABOVE",
        }
    }

    data_extraction_mcp_server_url = os.getenv(
        "data_extraction_mcp_server_url", "http://127.0.0.1:8000"
    )
    data_extraction_mcp_server_name = os.getenv("data_extraction_mcp_server_name")

    MASTER_RISK_TYPE_MAPPING_GCS_URI = os.getenv(
        "MASTER_RISK_TYPE_MAPPING_GCS_URI",
        "gs://db-dev-euwe3-gcs-155081-dbaware_review/risktype_mapping/Risk_Type_V4.json",
    )
    MASTER_RISK_TYPE_MAPPING_GCS_URI_FALLBACKS = os.getenv(
        "MASTER_RISK_TYPE_MAPPING_GCS_URI_FALLBACKS",
        "",
    )
    MASTER_RISK_TYPE_MAPPING_LOCAL_FILE = os.getenv(
        "MASTER_RISK_TYPE_MAPPING_LOCAL_FILE",
        "",
    )
    HISTORICAL_DETAILS_CONCURRENCY_LIMIT = int(
        os.getenv("HISTORICAL_DETAILS_CONCURRENCY_LIMIT", 1)
    )
    DATA_EXTRACTION_CONCURRENCY_LIMIT = int(
        os.getenv("DATA_EXTRACTION_CONCURRENCY_LIMIT", 1)
    )
    RAG_BASE_URL = os.getenv("RAG_BASE_URL", "").strip()
