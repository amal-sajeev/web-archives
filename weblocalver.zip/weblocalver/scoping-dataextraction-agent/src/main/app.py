import logging
import uvicorn
from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from model.data_extrac_pipeline import DataExtractionRequest, SessionStatusResponse
from model.plan_artifact_enum import PlanArtifact
from service import data_extraction_service, plan_data_service, session_service

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("mcp.client.streamable_http").setLevel(logging.WARNING)
logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
logging.getLogger("sqlalchemy.pool").setLevel(logging.WARNING)
logging.getLogger("sqlalchemy").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Scoping Data Extraction Agent",
    description="Orchestrates data extraction from various sources for scoping.",
    version="1.0.0",
    root_path="/scoping-dataextraction-agent",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health_check():
    """Health check endpoint for Kubernetes probes."""
    return {"status": "healthy"}


@app.post("/data-extraction", status_code=202)
async def trigger_data_extraction(
    request: DataExtractionRequest,
    background_tasks: BackgroundTasks,
):
    """
    Triggers the asynchronous data extraction pipeline for a given Plan Item Number.
    """
    try:
        session = session_service.create_session(request.planNumber)
        background_tasks.add_task(
            data_extraction_service.run_extraction_background,
            session["session_id"],
            request.planNumber,
            request.userDetails,
        )
        return session
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception("Unexpected error for plan %s", request.planNumber)
        raise HTTPException(
            status_code=500,
            detail="An internal error occurred. Please try again later.",
        )


@app.get("/data-extraction/{session_id}/status", response_model=SessionStatusResponse)
async def get_data_extraction_status(session_id: str):
    """Return the current status for a data extraction session."""
    session = session_service.get_session(session_id)

    if session is None:
        raise HTTPException(status_code=404, detail="Invalid session id")

    return {
        "session_id": session_id,
        "stage_name": session.get("stage", ""),
        "plan_number": session.get("plan_number", ""),
        "status": session.get("status"),
        "error": session.get("error") or None,
    }


@app.get("/getdata/{plan_number}/availability")
async def get_plan_data_availability(plan_number: str):
    """Report which extracted artifacts are already stored in the bucket for a plan."""
    try:
        return plan_data_service.check_plan_data_availability(plan_number)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception:
        logger.exception("Availability check failed for plan %s", plan_number)
        raise HTTPException(
            status_code=500,
            detail="An internal error occurred. Please try again later.",
        )


@app.get("/getdata/{plan_number}/{artifact}")
async def get_plan_data(plan_number: str, artifact: PlanArtifact):
    """Return one stored extraction artifact for a plan."""
    try:
        return plan_data_service.get_plan_artifact(plan_number, artifact)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception:
        logger.exception(
            "Failed to read artifact %s for plan %s", artifact.value, plan_number
        )
        raise HTTPException(
            status_code=500,
            detail="An internal error occurred. Please try again later.",
        )


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4002)
