import sys
import asyncio
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from service.gfms_client import create_gfms_payload_from_dbaware, get_gfms_findings


class TestCreateGfmsPayloadFromDbaware:

    def test_empty_plan_item(self):
        """Empty plan item should return only findingStatus."""
        result = create_gfms_payload_from_dbaware({})
        assert result == {"findingStatus": [{"id": 0, "name": "Open"}]}

    def test_countries_parsed(self):
        """UoT Countries should not be included in the simplified payload."""
        plan_item = {"UoT Countries": "Germany;France; Italy "}
        result = create_gfms_payload_from_dbaware(plan_item)
        assert "country" not in result
        assert result["findingStatus"] == [{"id": 0, "name": "Open"}]

    def test_empty_countries_string_no_key(self):
        """Empty countries string should not create country key."""
        result = create_gfms_payload_from_dbaware({"UoT Countries": ""})
        assert "country" not in result

    def test_divisions_parsed(self):
        """AU Aggregation Point 4 should not be included in the simplified payload."""
        plan_item = {"AU Aggregation Point 4": "Div A;Div B"}
        result = create_gfms_payload_from_dbaware(plan_item)
        assert "division" not in result
        assert result["findingStatus"] == [{"id": 0, "name": "Open"}]

    def test_empty_divisions_no_key(self):
        """Empty divisions string should not create division key."""
        result = create_gfms_payload_from_dbaware({"AU Aggregation Point 4": ""})
        assert "division" not in result

    def test_risk_types_parsed(self):
        """UoT Risk Type should not be included in the simplified payload."""
        plan_item = {"UoT Risk Type": "001;002"}
        result = create_gfms_payload_from_dbaware(plan_item)
        assert "riskType" not in result

    def test_risk_types_with_dash_format(self):
        """Risk types with dash format should not be included in the simplified payload."""
        plan_item = {"UoT Risk Type": "001 - Credit Risk;002 - Market Risk"}
        result = create_gfms_payload_from_dbaware(plan_item)
        assert "riskType" not in result

    def test_risk_types_skips_empty_entries(self):
        """Empty risk type entries should be ignored in the simplified payload."""
        plan_item = {"UoT Risk Type": ";001 - Valid;"}
        result = create_gfms_payload_from_dbaware(plan_item)
        assert "riskType" not in result

    def test_empty_risk_types_no_key(self):
        """Empty risk types string should not create riskType key."""
        result = create_gfms_payload_from_dbaware({"UoT Risk Type": ""})
        assert "riskType" not in result

    def test_full_plan_item(self):
        """Full plan item should contain only control and findingStatus."""
        plan_item = {
            "UoT Countries": "US;UK",
            "AU Aggregation Point 4": "DivX",
            "UoT Risk Type": "01;02",
            "AU-RT-KC": [{"KC": "Control1"}, {"KC": "Control2"}],
        }
        result = create_gfms_payload_from_dbaware(plan_item)
        assert "control" in result
        assert "findingStatus" in result
        assert "country" not in result
        assert "division" not in result
        assert "riskType" not in result
        assert len(result["control"]) == 2
        assert result["findingStatus"] == [{"id": 0, "name": "Open"}]


class TestGetGfmsFindings:

    @patch("service.gfms_client.MCPClient")
    def test_invokes_mcp_and_returns_result(self, mock_client_cls):
        """MCPClient should be invoked with correct parameters and result returned."""
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value={"findings": [{"id": 1}]})
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        payload = {"country": [{"id": 0, "name": "US"}]}
        result = asyncio.run(get_gfms_findings("test_session", payload))

        assert result == {"findings": [{"id": 1}]}
        mock_instance.invoke.assert_awaited_once_with(
            "get_gfms_finding_data", {"request": payload}
        )
        mock_instance.close.assert_awaited_once()

    @patch("service.gfms_client.MCPClient")
    def test_propagates_mcp_error(self, mock_client_cls):
        """MCP errors should be propagated."""
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(side_effect=RuntimeError("mcp error"))
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        with pytest.raises(RuntimeError, match="mcp error"):
            asyncio.run(get_gfms_findings("test_session", {}))

    @patch("service.gfms_client.MCPClient")
    def test_closes_mcp_client_on_success(self, mock_client_cls):
        """MCP client should be closed even on success."""
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value={"findings": []})
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        asyncio.run(get_gfms_findings("test_session", {}))
        mock_instance.close.assert_awaited_once()

    @patch("service.gfms_client.MCPClient")
    def test_handles_close_error_gracefully(self, mock_client_cls):
        """MCP client close errors should be handled gracefully."""
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value={"findings": []})
        mock_instance.close = AsyncMock(side_effect=RuntimeError("close error"))
        mock_client_cls.return_value = mock_instance

        # Should not raise, error should be logged
        result = asyncio.run(get_gfms_findings("test_session", {}))
        assert result == {"findings": []}
