import sys
import asyncio
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock, call

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

# Mock action_service prior to importing data_extraction_service
# to prevent ActionServiceClt initialization from failing on config.dev
mock_action_service = MagicMock()
mock_action_service.action_clt.persist_action = lambda fn: fn
sys.modules["service.action_service"] = mock_action_service
sys.modules["action_client"] = MagicMock()

from service.data_extraction_service import (
    run_extraction_pipeline,
    run_extraction_background,
)
from service.group_audit_client import _build_group_audit_payload
from model.status_enum import Status


@pytest.fixture(autouse=True)
def mock_delete_prefix(monkeypatch):
    mock = MagicMock(return_value=0)
    monkeypatch.setattr("service.data_extraction_service.delete_prefix", mock)
    return mock


@pytest.fixture(autouse=True)
def mock_group_audit(monkeypatch):
    monkeypatch.setattr(
        "service.data_extraction_service.get_group_audit_data",
        AsyncMock(return_value={"group_audit": []}),
    )


def test_build_group_audit_payload_extracts_and_deduplicates_fields():
    current_data = [
        {
            "UoT Countries": "Germany; France; Germany",
            "AU-RT-KC": [
                {"RT": "R030", "KC": "KC-100"},
                {"RT": "R030", "KC": "KC-100"},
            ],
        },
        {
            "UoT Countries": "France; Luxembourg",
            "AU-RT-KC": [{"RT": "R077", "KC": "KC-200"}],
        },
    ]

    assert _build_group_audit_payload(current_data) == {
        "countries": ["Germany", "France", "Luxembourg"],
        "risk_types": ["R030", "R077"],
        "key_controls": ["KC-100", "KC-200"],
    }


def test_build_group_audit_payload_defaults_empty_values():
    assert _build_group_audit_payload({}) == {
        "countries": [],
        "risk_types": [],
        "key_controls": [],
    }


class TestRunExtractionPipelineSuccess:

    @patch(
        "service.data_extraction_service.save_folder_to_destination",
        return_value="gs://bucket/folder",
    )
    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "12345",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={"findings": []},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": [{"id": 1, "name": "C1", "control": "C1"}]},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[{"control": "data"}],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("plan_folder", "plan_folder/inbound-data"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_full_pipeline_success(
        self,
        mock_dbaware,
        mock_build_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms_findings,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_save_json,
        mock_save_folder,
    ):
        mock_dbaware.return_value = {
            "current_data": {"Plan Item Title": "Test", "AU-RT-KC": []},
            "alc_nalc_details": [{"alc": "data"}],
            "historical_data": [{"hist": "data"}],
        }

        result = asyncio.run(run_extraction_pipeline("12345"))

        assert result["status"] == "success"
        assert "12345" in result["message"]
        assert result["output_location"] == "gs://bucket/folder"

        mock_dbaware.assert_awaited_once_with("12345", session_id=None)
        mock_build_paths.assert_called_once()
        mock_dbgrc.assert_awaited_once()
        mock_gfms_payload.assert_called_once()
        mock_gfms_findings.assert_awaited()
        #mock_build_rag.assert_awaited_once()
        mock_build_rag.assert_called_once()
        mock_get_rag.assert_called_once()
        mock_persist_rag.assert_awaited_once()
        mock_save_folder.assert_called_once()
        # plan_details, alc_nalc, historical, dbgrc, gfms, group_audit = 6
        assert mock_save_json.call_count == 6

    @patch(
        "service.data_extraction_service.save_folder_to_destination",
        return_value="gs://bucket/folder",
    )
    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "999",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": []},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("folder", "folder/inbound-data"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_pipeline_with_no_controls_no_gfms_tasks(
        self,
        mock_dbaware,
        mock_build_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms_findings,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_save_json,
        mock_save_folder,
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        result = asyncio.run(run_extraction_pipeline("999"))

        assert result["status"] == "success"
        # No controls means no gfms_findings calls
        mock_gfms_findings.assert_not_awaited()


class TestRunExtractionPipelineErrors:

    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
        side_effect=RuntimeError("dbaware down"),
    )
    def test_raises_on_dbaware_failure(self, mock_dbaware):
        with pytest.raises(RuntimeError, match="dbaware down"):
            asyncio.run(run_extraction_pipeline("111"))

    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        side_effect=RuntimeError("dbgrc fail"),
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("f", "f/i"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_raises_on_dbgrc_failure(
        self, mock_dbaware, mock_paths, mock_dbgrc, mock_save
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        with pytest.raises(RuntimeError, match="dbgrc fail"):
            asyncio.run(run_extraction_pipeline("222"))

    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "333",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_group_audit_data",
        new_callable=AsyncMock,
        side_effect=RuntimeError("group audit fail"),
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": []},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("f", "f/i"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_raises_on_group_audit_failure(
        self,
        mock_dbaware,
        mock_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_group_audit_call,
        mock_save,
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        with pytest.raises(RuntimeError, match="group audit fail"):
            asyncio.run(run_extraction_pipeline("333"))

    @patch(
        "service.data_extraction_service.save_folder_to_destination",
        side_effect=RuntimeError("upload fail"),
    )
    @patch("service.data_extraction_service.save_json_to_file")
    @patch(
        "service.data_extraction_service.persist_rag_documents",
        new_callable=AsyncMock,
        return_value={"policy": {"saved_files": []}},
    )
    @patch(
        "service.data_extraction_service.get_all_relevant_data",
        new_callable=AsyncMock,
        return_value={
            "status": "success",
            "results": {"policy": {}, "procedure": {}, "kod": {}},
            "errors": {"policy": None, "procedure": None, "kod": None},
            "latency_ms_per_type": {"policy": 1, "procedure": 1, "kod": 1},
            "total_latency_ms": 3,
        },
    )
    @patch(
        "service.data_extraction_service.build_rag_base_payload",
        return_value={
            "review_id": "444",
            "region": "Americas",
            "plan_item_title": "X",
            "plan_item_description": "Y",
            "au_countries": [],
            "au_list": [],
            "rt_list": [],
            "kc_list": [],
            "control_name": [],
            "control_how": [],
            "control_what": [],
            "control_why": [],
        },
    )
    @patch(
        "service.data_extraction_service.get_gfms_findings",
        new_callable=AsyncMock,
        return_value={},
    )
    @patch(
        "service.data_extraction_service.create_gfms_payload_from_dbaware",
        return_value={"control": []},
    )
    @patch(
        "service.data_extraction_service.trigger_dbgrc_pipeline",
        new_callable=AsyncMock,
        return_value=[],
    )
    @patch(
        "service.data_extraction_service.build_plan_storage_paths",
        return_value=("f", "f/i"),
    )
    @patch(
        "service.data_extraction_service.get_dbaware_data_for_plan",
        new_callable=AsyncMock,
    )
    def test_raises_on_upload_failure(
        self,
        mock_dbaware,
        mock_paths,
        mock_dbgrc,
        mock_gfms_payload,
        mock_gfms,
        mock_build_rag,
        mock_get_rag,
        mock_persist_rag,
        mock_save,
        mock_upload,
    ):
        mock_dbaware.return_value = {
            "current_data": {},
            "alc_nalc_details": [],
            "historical_data": [],
        }

        with pytest.raises(RuntimeError, match="upload fail"):
            asyncio.run(run_extraction_pipeline("444"))


class TestSessionHandling:
    """Test session management and session status updates during extraction."""

    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    def test_session_status_updated_on_processing_start(
        self, mock_pipeline, mock_update_status
    ):
        """Verify session status is set to PROCESSING when extraction starts."""
        session_id = "sess-001"
        plan_number = "5678"

        asyncio.run(run_extraction_background(session_id, plan_number))

        # First call should set PROCESSING status
        calls = mock_update_status.call_args_list
        assert any(
            call_obj[1].get("status") == Status.PROCESSING for call_obj in calls
        ), "Session should be marked as PROCESSING"

    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    def test_session_status_updated_on_completion(
        self, mock_pipeline, mock_update_status
    ):
        """Verify session status is set to COMPLETED when extraction succeeds."""
        session_id = "sess-002"
        plan_number = "5679"

        asyncio.run(run_extraction_background(session_id, plan_number))

        # Final call should set COMPLETED status
        final_call = mock_update_status.call_args_list[-1]
        assert (
            final_call[1]["status"] == Status.COMPLETED
        ), "Session should be marked as COMPLETED on success"
        assert final_call[1]["session_id"] == session_id
        assert final_call[1]["plan_number"] == plan_number

    @patch("service.session_service.get_session")
    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        side_effect=RuntimeError("pipeline error"),
    )
    def test_session_status_updated_on_failure(
        self, mock_pipeline, mock_update_status, mock_get_session
    ):
        """Verify session status is set to FAILED when extraction fails."""
        session_id = "sess-003"
        plan_number = "5680"
        mock_get_session.return_value = {"stage": "data_extraction"}

        asyncio.run(run_extraction_background(session_id, plan_number))

        # Final call should set FAILED status with error message
        final_call = mock_update_status.call_args_list[-1]
        assert (
            final_call[1]["status"] == Status.FAILED
        ), "Session should be marked as FAILED on error"
        assert "error" in final_call[1], "Error message should be included"
        assert session_id in str(
            mock_update_status.call_args_list
        ), "Session ID should be tracked"

    @patch("service.data_extraction_service.update_session_status")
    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    def test_session_id_passed_to_pipeline(self, mock_pipeline, mock_update_status):
        """Verify session ID is properly passed to extraction pipeline."""
        session_id = "sess-004"
        plan_number = "5681"

        asyncio.run(run_extraction_background(session_id, plan_number))

        # Pipeline should receive session_id
        mock_pipeline.assert_awaited_once()
        call_kwargs = mock_pipeline.call_args[1]
        assert (
            call_kwargs.get("session_id") == session_id
        ), "Session ID should be passed to pipeline"


class TestSessionPooling:
    """Test concurrent session pooling and concurrency control."""

    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    @patch("service.data_extraction_service.update_session_status")
    def test_multiple_sessions_concurrent_processing(
        self, mock_update_status, mock_pipeline
    ):
        """Verify multiple sessions can be processed concurrently within limit."""
        sessions = [
            ("sess-101", "plan-A"),
            ("sess-102", "plan-B"),
            ("sess-103", "plan-C"),
        ]

        async def run_all_sessions():
            tasks = [run_extraction_background(sid, plan) for sid, plan in sessions]
            await asyncio.gather(*tasks)

        asyncio.run(run_all_sessions())

        # All sessions should be processed
        assert mock_pipeline.await_count == len(
            sessions
        ), "All sessions should be processed"
        update_calls = mock_update_status.call_args_list
        session_ids = [call_obj[1]["session_id"] for call_obj in update_calls]
        assert "sess-101" in session_ids
        assert "sess-102" in session_ids
        assert "sess-103" in session_ids

    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    @patch("service.data_extraction_service.update_session_status")
    def test_concurrency_limit_enforced(self, mock_update_status, mock_pipeline):
        """Verify multiple sessions can execute with semaphore-based pooling."""
        sessions = [(f"sess-{i:03d}", f"plan-{i}") for i in range(3)]

        async def run_all_sessions():
            tasks = [run_extraction_background(sid, plan) for sid, plan in sessions]
            await asyncio.gather(*tasks)

        # Should complete without error despite semaphore pooling
        asyncio.run(run_all_sessions())

        # Verify all sessions were started
        assert mock_pipeline.await_count == len(
            sessions
        ), "All sessions should be processed"
        assert mock_update_status.call_count >= len(
            sessions
        ), "Status should be updated for each session"

    @patch(
        "service.data_extraction_service.run_extraction_pipeline",
        new_callable=AsyncMock,
        return_value={"status": "success"},
    )
    @patch("service.data_extraction_service.update_session_status")
    def test_session_isolation_in_pool(self, mock_update_status, mock_pipeline):
        """Verify sessions are isolated and don't interfere with each other."""
        session_data = {}

        async def tracked_pipeline(plan_number, session_id=None, user_request=None):
            # Simulate that each session has isolated state
            session_data[session_id] = plan_number
            await asyncio.sleep(0.05)
            return {"status": "success"}

        mock_pipeline.side_effect = tracked_pipeline

        sessions = [
            ("sess-201", "plan-X"),
            ("sess-202", "plan-Y"),
            ("sess-203", "plan-Z"),
        ]

        async def run_all_sessions():
            tasks = [run_extraction_background(sid, plan) for sid, plan in sessions]
            await asyncio.gather(*tasks)

        asyncio.run(run_all_sessions())

        # Each session should have its own isolated data
        assert session_data["sess-201"] == "plan-X"
        assert session_data["sess-202"] == "plan-Y"
        assert session_data["sess-203"] == "plan-Z"
        assert len(session_data) == 3, "All sessions should maintain isolated state"
