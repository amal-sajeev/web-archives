import sys
import asyncio
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from service.dbaware_client import extract_aurt_combination, get_dbaware_data_for_plan


class TestExtractAurtCombination:

    def test_empty_data(self):
        assert extract_aurt_combination({}) == []

    def test_empty_aurtkc_list(self):
        assert extract_aurt_combination({"AU-RT-KC": []}) == []

    def test_none_aurtkc(self):
        assert extract_aurt_combination({"AU-RT-KC": None}) == []

    def test_valid_single_combination(self):
        data = {"AU-RT-KC": [{"AU": "a~b~c~d~DivName~f", "RT": "RT1"}]}
        result = extract_aurt_combination(data)
        assert result == [{"auid": "a", "rtId": "RT1"}]

    def test_deduplicates(self):
        data = {
            "AU-RT-KC": [
                {"AU": "a~b~c~d~Div~f", "RT": "RT1"},
                {"AU": "a~b~c~d~Div~f", "RT": "RT1"},
            ]
        }
        result = extract_aurt_combination(data)
        assert len(result) == 1

    def test_multiple_unique_combinations(self):
        data = {
            "AU-RT-KC": [
                {"AU": "a~b~c~d~Div1~f", "RT": "RT1"},
                {"AU": "a~b~c~d~Div2~f", "RT": "RT2"},
            ]
        }
        result = extract_aurt_combination(data)
        assert len(result) == 2

    def test_skips_non_dict_items(self):
        data = {"AU-RT-KC": ["not a dict", 123, None]}
        assert extract_aurt_combination(data) == []

    def test_skips_missing_au_parts(self):
        # AU has fewer than 5 parts
        data = {"AU-RT-KC": [{"AU": "a~b~c", "RT": "RT1"}]}
        assert extract_aurt_combination(data) == [{"auid": "a", "rtId": "RT1"}]

    def test_skips_empty_au_index4(self):
        data = {"AU-RT-KC": [{"AU": "a~b~c~d~~f", "RT": "RT1"}]}
        assert extract_aurt_combination(data) == [{"auid": "a", "rtId": "RT1"}]

    def test_skips_missing_rt(self):
        data = {"AU-RT-KC": [{"AU": "a~b~c~d~Div~f", "RT": None}]}
        assert extract_aurt_combination(data) == []

    def test_skips_empty_rt(self):
        data = {"AU-RT-KC": [{"AU": "a~b~c~d~Div~f", "RT": ""}]}
        assert extract_aurt_combination(data) == []

    def test_strips_whitespace(self):
        data = {"AU-RT-KC": [{"AU": "a~b~c~d~ Div ~f", "RT": " RT1 "}]}
        result = extract_aurt_combination(data)
        assert result == [{"auid": "a", "rtId": "RT1"}]


class TestGetDbawareDataForPlan:

    @patch("service.dbaware_client.find_historical_plan_items", new_callable=AsyncMock)
    @patch("service.dbaware_client.MCPClient")
    def test_success(self, mock_client_cls, mock_find_historical):
        mock_instance = MagicMock()
        mock_instance.close = AsyncMock()
        current_data = {
            "Plan Year": "2024",
            "Plan Item Title": "Test Plan",
            "Description of Plan Item": "Current plan description",
            "UoT Countries": "Germany",
            "AU-RT-KC": [{"AU": "a~b~c~d~Div~f", "RT": "RT1"}],
        }
        historical_candidates = [
            {"Plan Item Number": "101", "Plan Item Title": "Old Plan"}
        ]
        historical_detail = {"Plan Item Number": "101", "detail": "full"}
        mock_instance.invoke = AsyncMock(
            side_effect=[
                current_data,  # get_plan_details
                [{"alc": "data"}],  # get_alc_nalc_details
                historical_candidates,  # get_historic_plan_details
                historical_detail,  # get_plan_details for matched historical number
            ]
        )
        mock_client_cls.return_value = mock_instance
        mock_find_historical.return_value = ["101"]

        result = asyncio.run(get_dbaware_data_for_plan("12345"))

        assert result["current_data"] == current_data
        assert result["alc_nalc_details"] == [{"alc": "data"}]
        assert result["historical_data"] == [historical_detail]
        mock_find_historical.assert_awaited_once_with(
            "Test Plan",
            records=historical_candidates,
            plan_description="Current plan description",
            uot_countries="Germany",
            session_id=None,
        )
        assert mock_instance.invoke.await_count == 4

    @patch("service.dbaware_client.MCPClient")
    def test_calls_with_correct_args(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.close = AsyncMock()
        current_data = {
            "Plan Item Title": "My Title",
            "Plan Year": "2026",
            "AU-RT-KC": [{"AU": "a~b~c~d~Div~f", "RT": "RT1"}],
        }
        mock_instance.invoke = AsyncMock(side_effect=[current_data, [], []])
        mock_client_cls.return_value = mock_instance

        asyncio.run(get_dbaware_data_for_plan("999"))

        calls = mock_instance.invoke.await_args_list
        assert calls[0].args == ("get_plan_details", {"planItemNumber": "999"})
        assert calls[1].args[0] == "get_alc_nalc_details"
        assert calls[1].args[1] == {
            "request": {
                "auRtCombinations": [{"auid": "a", "rtId": "RT1"}],
                "acOrNcOrBoth": "BOTH",
                "from_plan_year": 2026,
                "to_plan_year": 2026,
            }
        }
        assert calls[2].args == (
            "get_historic_plan_details",
            {"currentPlanYear": "2026"},
        )

    @patch("service.dbaware_client.MCPClient")
    def test_propagates_error(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(side_effect=RuntimeError("fail"))
        mock_client_cls.return_value = mock_instance

        with pytest.raises(RuntimeError, match="fail"):
            asyncio.run(get_dbaware_data_for_plan("000"))
