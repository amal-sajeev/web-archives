import asyncio
import json
import sys
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx
import pytest

MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from service import rag_retrieval_service


def _valid_base_payload() -> dict:
    return {
        "review_id": "20090",
        "region": "Americas",
        "au_countries": ["USA"],
        "plan_item_title": "Plan title",
        "plan_item_description": "Plan description",
        "au_list": ["Investment Bank"],
        "rt_list": ["R019 - Client Classification"],
        "kc_list": ["IRC-CD-1000141"],
        "control_name": ["Control A"],
        "control_how": ["How A"],
        "control_what": ["What A"],
        "control_why": ["Why A"],
    }


class TestGetAllRelevantData:
    @patch("service.rag_retrieval_service.call_rag", new_callable=AsyncMock)
    def test_all_three_succeed(self, mock_call_rag):
        mock_call_rag.side_effect = [
            {
                "response": {
                    "policy_text": "policy",
                    "referenced_documents": [{"document_name": "a.pdf", "gs_uri": "gs://a"}],
                    "citations": [{"document_name": "a.pdf", "gs_uri": "gs://a", "page_number": 1}],
                },
                "latency_ms": 10,
            },
            {
                "response": {
                    "procedure_text": "procedure",
                    "referenced_documents": [{"document_name": "b.pdf", "gs_uri": "gs://b"}],
                    "citations": [{"document_name": "b.pdf", "gs_uri": "gs://b", "page_number": 2}],
                },
                "latency_ms": 11,
            },
            {
                "response": {
                    "kod_text": "kod",
                    "referenced_documents": [{"document_name": "c.pdf", "gs_uri": "gs://c"}],
                    "citations": [{"document_name": "c.pdf", "gs_uri": "gs://c", "page_number": 3}],
                },
                "latency_ms": 12,
            },
        ]

        result = asyncio.run(
            rag_retrieval_service.get_all_relevant_data(
                _valid_base_payload(), request_id="req-1"
            )
        )

        assert result["status"] == "success"
        assert result["results"]["policy"]["policy_text"] == "policy"
        assert result["results"]["procedure"]["procedure_text"] == "procedure"
        assert result["results"]["kod"]["kod_text"] == "kod"
        assert result["errors"]["policy"] is None
        assert result["errors"]["procedure"] is None
        assert result["errors"]["kod"] is None
        assert [item["gs_uri"] for item in result["referenced_documents"]] == ["gs://a", "gs://b", "gs://c"]
        assert [item["gs_uri"] for item in result["citations"]] == ["gs://a", "gs://b", "gs://c"]

    @patch("service.rag_retrieval_service.call_rag", new_callable=AsyncMock)
    def test_one_fails_two_succeed(self, mock_call_rag):
        mock_call_rag.side_effect = [
            {"response": {"policy_text": "policy"}, "latency_ms": 10},
            RuntimeError("procedure failed"),
            {"response": {"kod_text": "kod"}, "latency_ms": 12},
        ]

        result = asyncio.run(
            rag_retrieval_service.get_all_relevant_data(
                _valid_base_payload(), request_id="req-2"
            )
        )

        assert result["status"] == "partial_success"
        assert result["results"]["policy"] == {"policy_text": "policy"}
        assert result["results"]["procedure"] is None
        assert result["results"]["kod"] == {"kod_text": "kod"}
        assert "procedure failed" in result["errors"]["procedure"]

    def test_invalid_payload_handling(self):
        invalid_payload = _valid_base_payload()
        invalid_payload["control_how"] = "not-a-list"

        with pytest.raises(ValueError, match="must be a list"):
            asyncio.run(rag_retrieval_service.get_all_relevant_data(invalid_payload))


class TestCallRag:
    def test_timeout_handling(self):
        async def timeout_handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("timed out", request=request)

        transport = httpx.MockTransport(timeout_handler)
        client = httpx.AsyncClient(transport=transport, timeout=0.01)

        with patch.object(
            rag_retrieval_service.Config, "RAG_BASE_URL", "http://rag.local"
        ):
            with pytest.raises(RuntimeError, match="RAG call failed"):
                asyncio.run(
                    rag_retrieval_service.call_rag(
                        "policy",
                        _valid_base_payload(),
                        request_id="req-timeout",
                        client=client,
                    )
                )

        asyncio.run(client.aclose())


class TestRagIntegrationWithMockedApi:
    def test_integration_mocked_responses(self):
        def handler(request: httpx.Request) -> httpx.Response:
            payload = json.loads(request.content.decode("utf-8"))
            doc_type = payload.get("document_type")
            if doc_type == "policy":
                body = {"policy_text": "Policy result", "documents": []}
            elif doc_type == "procedure":
                body = {"procedure_text": "Procedure result", "documents": []}
            elif doc_type == "kod":
                body = {"kod_text": "KOD result", "documents": []}
            else:
                return httpx.Response(
                    status_code=400, json={"error": "bad document_type"}
                )
            return httpx.Response(status_code=200, json=body)

        transport = httpx.MockTransport(handler)
        client = httpx.AsyncClient(transport=transport, timeout=2.0)

        with patch.object(
            rag_retrieval_service.Config, "RAG_BASE_URL", "http://rag.local"
        ):
            result = asyncio.run(
                rag_retrieval_service.get_all_relevant_data(
                    _valid_base_payload(),
                    request_id="req-int-1",
                    client=client,
                )
            )

        asyncio.run(client.aclose())

        assert result["status"] == "success"
        assert result["results"]["policy"]["policy_text"] == "Policy result"
        assert result["results"]["procedure"]["procedure_text"] == "Procedure result"
        assert result["results"]["kod"]["kod_text"] == "KOD result"


class TestPersistRagDocuments:
    def test_persist_pdf_base64_documents(self, tmp_path):
        raw_pdf = b"%PDF-1.4 test"
        encoded = "JVBERi0xLjQgdGVzdA=="
        aggregated = {
            "results": {
                "policy": {
                    "documents": [{"file_name": "p1.pdf", "pdf_base64": encoded}]
                },
                "procedure": {"documents": []},
                "kod": None,
            }
        }

        with patch.object(rag_retrieval_service, "RAG_TIMEOUT_SECONDS", 2.0):
            report = asyncio.run(
                rag_retrieval_service.persist_rag_documents(
                    aggregated,
                    "dbaware_review_20090/inbound-data",
                    str(tmp_path),
                    request_id="req-persist",
                )
            )

        policy_file = (
            tmp_path
            / "dbaware_review_20090"
            / "inbound-data"
            / "policy"
            / "policy"
            / "p1.pdf"
        )
        policy_metadata = (
            tmp_path
            / "dbaware_review_20090"
            / "inbound-data"
            / "policy"
            / "relevant_policy.json"
        )
        assert policy_file.exists()
        assert policy_metadata.exists()
        assert policy_file.read_bytes() == raw_pdf
        assert "p1.pdf" in report["policy"]["saved_files"]
        assert "relevant_policy.json" in report["policy"]["saved_files"]

    def test_persists_each_relevant_document_by_document_id(self, tmp_path):
        documents = {
            "policy": [{"document_id": "21", "document_title": "Policy A", "nodes": [{"node_id": "21:section:1"}]}],
            "procedure": {"referenced_documents": [{"document_id": "32", "document_title": "Procedure B"}]},
            "kod": [{"document_id": "11", "document_title": "KOD C", "nodes": [{"node_id": "11:section:9.5"}]}],
        }

        report = asyncio.run(
            rag_retrieval_service.persist_rag_documents(
                {"results": documents},
                "dbaware_review_20090/inbound-data",
                str(tmp_path),
                request_id="req-documents",
            )
        )

        policy_file = tmp_path / "dbaware_review_20090/inbound-data/policy/relevant_policy/policy21.json"
        procedure_file = tmp_path / "dbaware_review_20090/inbound-data/policy/relevant_procedure/procedure32.json"
        kod_file = tmp_path / "dbaware_review_20090/inbound-data/policy/relevant_kod/kod11.json"

        assert json.loads(policy_file.read_text(encoding="utf-8")) == documents["policy"][0]
        assert json.loads(procedure_file.read_text(encoding="utf-8")) == documents["procedure"]["referenced_documents"][0]
        assert json.loads(kod_file.read_text(encoding="utf-8")) == documents["kod"][0]
        for doc_type, result in documents.items():
            aggregate_file = (
                tmp_path
                / "dbaware_review_20090/inbound-data/policy"
                / f"relevant_{doc_type}.json"
            )
            assert json.loads(aggregate_file.read_text(encoding="utf-8")) == result
        assert "relevant_policy/policy21.json" in report["policy"]["saved_files"]
        assert "relevant_procedure/procedure32.json" in report["procedure"]["saved_files"]
        assert "relevant_kod/kod11.json" in report["kod"]["saved_files"]


class TestBuildRagPayload:
    def test_extracts_control_fields_from_inventory_when_details_missing(self):
        plan_item = {
            "UoT Regions": "Americas",
            "UoT Countries": "USA",
            "Plan Item Title": "2025 Swap Dealer (CFTC)",
            "Description of Plan Item": "desc",
            "AU-RT-KC": [
                {
                    "AU": "a~b~c~d~Investment Bank",
                    "RT": "R019 - Client Classification",
                    "KC": "IRC-CD-1000141",
                }
            ],
        }
        dbgrc_analysis = {
            "included_kcs": [
                {
                    "inventory": {
                        "controlDefinitionNumber": "IRC-CD-1000141",
                        "controlHow": "How from inventory",
                        "controlWhat": "What from inventory",
                        "controlWhy": "Why from inventory",
                    },
                    "details": {},
                }
            ]
        }

        payload = rag_retrieval_service.build_rag_base_payload(
            "20090", plan_item, dbgrc_analysis
        )

        assert payload["control_name"] == ["IRC-CD-1000141"]
        assert payload["control_how"] == ["How from inventory"]
        assert payload["control_what"] == ["What from inventory"]
        assert payload["control_why"] == ["Why from inventory"]
