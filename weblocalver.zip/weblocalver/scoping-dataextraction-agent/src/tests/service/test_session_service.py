import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from service.session_service import (
    create_session,
    get_session,
    update_session_status,
    DATA_EXTRACTION_STAGE,
)
from model.status_enum import Status


class TestCreateSession:
    """Test session creation functionality."""

    @patch("service.session_service.update_session_status")
    @patch("service.session_service.uuid.uuid4")
    def test_create_session_returns_valid_structure(self, mock_uuid, mock_update):
        """Verify session creation returns correct structure."""
        mock_uuid.return_value = "sess-12345"

        result = create_session("plan-001")

        assert result["session_id"] == "sess-12345"
        assert result["plan_number"] == "plan-001"
        assert result["status"] == Status.QUEUED.value

    @patch("service.session_service.update_session_status")
    @patch("service.session_service.uuid.uuid4")
    def test_create_session_converts_plan_number_to_string(self, mock_uuid, mock_update):
        """Verify plan number is converted to string."""
        mock_uuid.return_value = "sess-789"

        result = create_session(12345)

        assert result["plan_number"] == "12345"
        assert isinstance(result["plan_number"], str)

    @patch("service.session_service.update_session_status")
    @patch("service.session_service.uuid.uuid4")
    def test_create_session_calls_update_status_with_queued(self, mock_uuid, mock_update):
        """Verify session status is persisted as QUEUED."""
        mock_uuid.return_value = "sess-new"

        create_session("plan-test")

        mock_update.assert_called_once()
        call_kwargs = mock_update.call_args[1]
        assert call_kwargs["session_id"] == "sess-new"
        assert call_kwargs["plan_number"] == "plan-test"
        assert call_kwargs["stage_name"] == DATA_EXTRACTION_STAGE
        assert call_kwargs["status"] == Status.QUEUED

    @patch("service.session_service.update_session_status")
    @patch("service.session_service.uuid.uuid4")
    def test_create_session_generates_unique_ids(self, mock_uuid, mock_update):
        """Verify unique session IDs are generated for each session."""
        mock_uuid.side_effect = ["sess-001", "sess-002", "sess-003"]

        s1 = create_session("plan-a")
        s2 = create_session("plan-b")
        s3 = create_session("plan-c")

        assert s1["session_id"] == "sess-001"
        assert s2["session_id"] == "sess-002"
        assert s3["session_id"] == "sess-003"
        assert s1["session_id"] != s2["session_id"] != s3["session_id"]


class TestGetSession:
    """Test session retrieval functionality."""

    @patch("service.session_service.get_session_status")
    def test_get_session_returns_session_when_exists(self, mock_get_status):
        """Verify session data is returned when session exists."""
        session_data = {
            "session_id": "sess-abc",
            "plan_number": "plan-xyz",
            "status": "PROCESSING",
            "stage": "data_extraction",
        }
        mock_get_status.return_value = session_data

        result = get_session("sess-abc")

        assert result == session_data
        mock_get_status.assert_called_once_with("sess-abc")

    @patch("service.session_service.get_session_status")
    def test_get_session_returns_none_when_not_found(self, mock_get_status):
        """Verify None is returned when session doesn't exist."""
        mock_get_status.return_value = None

        result = get_session("invalid-session")

        assert result is None

    @patch("service.session_service.get_session_status")
    def test_get_session_with_error_field(self, mock_get_status):
        """Verify session with error information is returned."""
        session_data = {
            "session_id": "sess-fail",
            "plan_number": "plan-fail",
            "status": "FAILED",
            "error": "Connection timeout",
            "stage": "dbaware",
        }
        mock_get_status.return_value = session_data

        result = get_session("sess-fail")

        assert result["status"] == "FAILED"
        assert result["error"] == "Connection timeout"


class TestUpdateSessionStatus:
    """Test session status update functionality."""

    @patch("service.session_service.set_session_status")
    def test_update_session_status_calls_set_status(self, mock_set_status):
        """Verify update_session_status delegates to set_session_status."""
        update_session_status(
            session_id="sess-001",
            stage_name="data_extraction",
            plan_number="plan-123",
            status=Status.PROCESSING,
        )

        mock_set_status.assert_called_once()
        call_kwargs = mock_set_status.call_args[1]
        assert call_kwargs["session_id"] == "sess-001"
        assert call_kwargs["stage_name"] == "data_extraction"
        assert call_kwargs["plan_number"] == "plan-123"
        assert call_kwargs["status"] == Status.PROCESSING
        assert call_kwargs["error"] == ""

    @patch("service.session_service.set_session_status")
    def test_update_session_status_with_error(self, mock_set_status):
        """Verify error message is passed to set_session_status."""
        error_msg = "Database connection failed"
        update_session_status(
            session_id="sess-002",
            stage_name="dbgrc",
            plan_number="plan-456",
            status=Status.FAILED,
            error=error_msg,
        )

        call_kwargs = mock_set_status.call_args[1]
        assert call_kwargs["error"] == error_msg
        assert call_kwargs["status"] == Status.FAILED

    @patch("service.session_service.set_session_status")
    def test_update_session_status_lifecycle(self, mock_set_status):
        """Verify status transitions through lifecycle."""
        # Simulate full lifecycle
        update_session_status("sess-003", DATA_EXTRACTION_STAGE, "plan-789", Status.QUEUED)
        update_session_status("sess-003", DATA_EXTRACTION_STAGE, "plan-789", Status.PROCESSING)
        update_session_status("sess-003", DATA_EXTRACTION_STAGE, "plan-789", Status.COMPLETED)

        assert mock_set_status.call_count == 3
        calls = mock_set_status.call_args_list
        assert calls[0][1]["status"] == Status.QUEUED
        assert calls[1][1]["status"] == Status.PROCESSING
        assert calls[2][1]["status"] == Status.COMPLETED


class TestSessionIntegration:
    """Integration tests for session management workflow."""

    @patch("service.session_service.set_session_status")
    @patch("service.session_service.get_session_status")
    @patch("service.session_service.uuid.uuid4")
    def test_full_session_lifecycle(self, mock_uuid, mock_get_status, mock_set_status):
        """Test complete session lifecycle: create -> process -> complete."""
        mock_uuid.return_value = "sess-lifecycle"
        session_data = {
            "session_id": "sess-lifecycle",
            "plan_number": "plan-lifecycle",
            "status": "COMPLETED",
            "stage": DATA_EXTRACTION_STAGE,
        }
        mock_get_status.return_value = session_data

        # Create session
        created = create_session("plan-lifecycle")
        assert created["status"] == Status.QUEUED.value

        # Simulate processing
        update_session_status(
            created["session_id"],
            DATA_EXTRACTION_STAGE,
            created["plan_number"],
            Status.PROCESSING,
        )

        # Simulate completion
        update_session_status(
            created["session_id"],
            DATA_EXTRACTION_STAGE,
            created["plan_number"],
            Status.COMPLETED,
        )

        # Retrieve final state
        final = get_session(created["session_id"])
        assert final["status"] == "COMPLETED"

    @patch("service.session_service.set_session_status")
    @patch("service.session_service.get_session_status")
    @patch("service.session_service.uuid.uuid4")
    def test_session_with_stage_transition(self, mock_uuid, mock_get_status, mock_set_status):
        """Test session with stage name transitions."""
        mock_uuid.return_value = "sess-stages"

        stages_transitioned = []

        def track_stages(**kwargs):
            stages_transitioned.append(kwargs.get("stage_name"))

        mock_set_status.side_effect = track_stages

        created = create_session("plan-stages")
        update_session_status(created["session_id"], "dbaware", "plan-stages", Status.PROCESSING)
        update_session_status(created["session_id"], "dbgrc", "plan-stages", Status.PROCESSING)
        update_session_status(created["session_id"], "gfms", "plan-stages", Status.PROCESSING)

        # Verify stage transitions were tracked
        assert DATA_EXTRACTION_STAGE in stages_transitioned  # From create
        assert "dbaware" in stages_transitioned
        assert "dbgrc" in stages_transitioned
        assert "gfms" in stages_transitioned
