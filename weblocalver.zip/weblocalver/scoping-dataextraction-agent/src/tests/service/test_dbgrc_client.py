import sys
import asyncio
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from service.dbgrc_client import (
    _norm_state,
    _build_au_rt_to_kcs_map,
    _fetch_kcs_via_mcp_bulk,
    trigger_dbgrc_pipeline,
)


class TestNormState:

    def test_normal_state(self):
        assert _norm_state("Active") == "active"

    def test_strips_whitespace(self):
        assert _norm_state("  Retired  ") == "retired"

    def test_none_returns_none(self):
        assert _norm_state(None) is None

    def test_empty_string_returns_none(self):
        assert _norm_state("") is None


class TestBuildAuRtToKcsMap:

    def test_basic_mapping(self):
        data = {
            "AU-RT-KC": [
                {"AU": "a~b~c~d~Div1~f", "RT": "R1", "KC": "C1"},
                {"AU": "a~b~c~d~Div1~f", "RT": "R1", "KC": "C2"},
                {"AU": "a~b~c~d~Div2~f", "RT": "R2", "KC": "C3"},
            ]
        }
        au_rt_map, kc_list = _build_au_rt_to_kcs_map(data)

        assert "Div1~R1" in au_rt_map
        assert "C1" in au_rt_map["Div1~R1"]
        assert "C2" in au_rt_map["Div1~R1"]
        assert "Div2~R2" in au_rt_map
        assert set(kc_list) == {"C1", "C2", "C3"}

    def test_deduplicates_kcs(self):
        data = {
            "AU-RT-KC": [
                {"AU": "a~b~c~d~Div~f", "RT": "R1", "KC": "C1"},
                {"AU": "a~b~c~d~Div~f", "RT": "R1", "KC": "C1"},
            ]
        }
        au_rt_map, kc_list = _build_au_rt_to_kcs_map(data)

        assert len(au_rt_map["Div~R1"]) == 1
        assert kc_list == ["C1", "C1"]

    def test_skips_empty_kc(self):
        data = {
            "AU-RT-KC": [
                {"AU": "a~b~c~d~Div~f", "RT": "R1", "KC": ""},
            ]
        }
        au_rt_map, kc_list = _build_au_rt_to_kcs_map(data)

        assert au_rt_map == {}
        assert kc_list == []

    def test_empty_input(self):
        au_rt_map, kc_list = _build_au_rt_to_kcs_map({})
        assert au_rt_map == {}
        assert kc_list == []


class TestFetchKcsViaMcpBulk:

    def test_success(self):
        mock_client = MagicMock()
        mock_client.invoke = AsyncMock(
            return_value=[
                {
                    "assessmentUnitDer": "Div1",
                    "riskId": "R1",
                    "kc_inventory": [{"kc": "C1"}],
                },
            ]
        )

        result = asyncio.run(_fetch_kcs_via_mcp_bulk("test_session", mock_client, ["Div1~R1"]))

        assert "Div1~R1" in result
        mock_client.invoke.assert_awaited_once()

    def test_empty_pairs(self):
        mock_client = MagicMock()
        result = asyncio.run(_fetch_kcs_via_mcp_bulk("test_session", mock_client, []))
        assert result == {}

    def test_skips_pairs_without_separator(self):
        mock_client = MagicMock()
        mock_client.invoke = AsyncMock(return_value=[])

        result = asyncio.run(_fetch_kcs_via_mcp_bulk("test_session", mock_client, ["nope"]))
        # No valid pairs means empty tool_args, returns {}
        assert result == {}



class TestTriggerDbgrcPipeline:

    @patch("service.dbgrc_client.MCPClient")
    def test_included_and_excluded_kcs(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.close = AsyncMock()

        # get_suggested_kcs call chain -> _fetch_kcs_via_mcp_bulk
        # We'll mock invoke to handle multiple calls
        call_count = {"n": 0}

        async def invoke_side_effect(tool_name, args):
            call_count["n"] += 1
            if tool_name == "get_au_rt_kc_list_bulk":
                return [
                    {
                        "assessmentUnitDer": "Div1",
                        "riskId": "R1",
                        "kc_inventory": [
                            {
                                "controlDefinitionNumber": "C_SUGGESTED",
                                "controlInstanceState": "Active",
                            },
                        ],
                    }
                ]
            elif tool_name == "get_control_details_by_kc":
                kcs = args.get("kcs", [])
                results = []
                for kc in kcs:
                    if kc == "C1":
                        results.append(
                            {
                                "inventory": {
                                    "assessmentUnitDer": "Div1",
                                    "controlDefinitionNumber": "C1",
                                    "controlInstanceState": "Active",
                                }
                            }
                        )
                    elif kc == "C2":
                        results.append(
                            {
                                "inventory": {
                                    "assessmentUnitDer": "Div1",
                                    "controlDefinitionNumber": "C2",
                                    "controlInstanceState": "Retired",
                                }
                            }
                        )
                    elif kc == "C_SUGGESTED":
                        results.append(
                            {
                                "inventory": {
                                    "assessmentUnitDer": "Div1",
                                    "controlDefinitionNumber": "C_SUGGESTED",
                                    "controlInstanceState": "Active",
                                }
                            }
                        )
                    else:
                        results.append({"error": "not found"})
                return results
            return []

        mock_instance.invoke = AsyncMock(side_effect=invoke_side_effect)
        mock_client_cls.return_value = mock_instance

        dbaware_data = {
            "current_data": {
                "AU-RT-KC": [
                    {"AU": "a~b~c~d~Div1~f", "RT": "R1", "KC": "C1"},
                    {"AU": "a~b~c~d~Div1~f", "RT": "R1", "KC": "C2"},
                    {"AU": "a~b~c~d~Div1~f", "RT": "R1", "KC": "C3"},
                ]
            }
        }

        result = asyncio.run(trigger_dbgrc_pipeline("test_session", dbaware_data))

        # C1 = included (active), C2 = excluded (retired), C3 = excluded (missing)
        included_ids = [
            r["inventory"]["controlDefinitionNumber"] for r in result["included_kcs"]
        ]
        excluded_ids = [r["controlIdentifier"] for r in result["excluded_kcs"]]

        assert "C1" in included_ids
        assert "C2" in excluded_ids
        assert "C3" in excluded_ids
        mock_instance.close.assert_awaited()

    @patch("service.dbgrc_client.MCPClient")
    def test_returns_error_when_no_kcs(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value=[])
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        dbaware_data = {"current_data": {"AU-RT-KC": []}}

        result = asyncio.run(trigger_dbgrc_pipeline( "test_session", dbaware_data))

        assert "error" in result

    @patch("service.dbgrc_client.MCPClient")
    def test_handles_mcp_error_gracefully(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.close = AsyncMock()

        # get_control_details_by_kc call raises an error
        mock_instance.invoke = AsyncMock(side_effect=RuntimeError("mcp down"))
        mock_client_cls.return_value = mock_instance

        dbaware_data = {
            "current_data": {
                "AU-RT-KC": [{"AU": "a~b~c~d~Div~f", "RT": "R1", "KC": "C1"}]
            }
        }

        result = asyncio.run(trigger_dbgrc_pipeline("test_session", dbaware_data))

        # Should catch exception and return error dict
        assert "error" in result
        mock_instance.close.assert_awaited()

    @patch("service.dbgrc_client.MCPClient")
    def test_keeps_distinct_au_rows_for_same_kc(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.close = AsyncMock()

        async def invoke_side_effect(tool_name, args):
            if tool_name == "get_au_rt_kc_list_bulk":
                return []
            if tool_name == "get_control_details_by_kc":
                kcs = args.get("kcs", [])
                if kcs == ["C1"]:
                    return [
                        {
                            "inventory": {
                                "controlDefinitionNumber": "C1",
                                "assessmentUnitDer": "AU1",
                                "riskId": "R1",
                                "controlInstanceState": "Active",
                            }
                        },
                        {
                            "inventory": {
                                "controlDefinitionNumber": "C1",
                                "assessmentUnitDer": "AU2",
                                "riskId": "R2",
                                "controlInstanceState": "Active",
                            }
                        },
                    ]
                return []
            return []

        mock_instance.invoke = AsyncMock(side_effect=invoke_side_effect)
        mock_client_cls.return_value = mock_instance

        dbaware_data = {
            "current_data": {
                "AU-RT-KC": [
                    {"AU": "a~b~c~d~AU1~f", "RT": "R1", "KC": "C1"},
                    {"AU": "a~b~c~d~AU2~f", "RT": "R2", "KC": "C1"},
                ]
            }
        }

        result = asyncio.run(trigger_dbgrc_pipeline("test_session", dbaware_data))

        assert len(result["included_kcs"]) == 2
        assert {
            item["inventory"]["assessmentUnitDer"] for item in result["included_kcs"]
        } == {"AU1", "AU2"}
        mock_instance.close.assert_awaited()
