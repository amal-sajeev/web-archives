import sys
import asyncio
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from service.internet_search_client import perform_internet_search


class TestPerformInternetSearchEmptyInput:

    def test_returns_empty_list_for_none_data(self):
        result = asyncio.run(perform_internet_search("testsession", {"data": []}))
        assert result == []

    def test_returns_empty_list_for_empty_list(self):
        result = asyncio.run(perform_internet_search("testsession", []))
        assert result == []

    def test_returns_empty_list_when_dict_has_no_data_key(self):
        result = asyncio.run(perform_internet_search("testsession", {}))
        assert result == []


class TestPerformInternetSearchSkipsAllNotSpecified:

    @patch("service.internet_search_client.MCPClient")
    def test_skips_when_all_fields_empty(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock()
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        data = [{"Plan Item Title": "Test", "UoT LRR": "", "UoT Regions": "", "UoT Risk Type": ""}]
        result = asyncio.run(perform_internet_search("testsession", {"data": data}))

        assert result == []
        mock_instance.invoke.assert_not_awaited()


class TestPerformInternetSearchSuccess:

    @patch("service.internet_search_client.MCPClient")
    def test_single_combination_string_result(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value="Found regulation XYZ.")
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        data = [{
            "Plan Item Number": "100",
            "Plan Item Title": "My Plan",
            "Description of Plan Item": "Desc",
            "UoT LRR": "GDPR",
            "UoT Regions": "EU",
            "UoT Risk Type": "Compliance",
        }]

        result = asyncio.run(perform_internet_search("testsession", {"data": data}))

        assert len(result) == 1
        assert result[0]["plan_item_number"] == "100"
        assert result[0]["plan_item_title"] == "My Plan"
        assert result[0]["search_result"] == "Found regulation XYZ."
        assert result[0]["search_combination"] == {
            "UoT LRR": "GDPR",
            "UoT Regions": "EU",
            "UoT Risk Type": "Compliance",
        }
        mock_instance.close.assert_awaited_once()

    @patch("service.internet_search_client.MCPClient")
    def test_single_combination_list_text_result(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value=[{"type": "text", "text": "Result line 1"}, {"type": "text", "text": "Result line 2"}])
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        data = [{
            "Plan Item Number": "200",
            "Plan Item Title": "Plan B",
            "Description of Plan Item": "Desc B",
            "UoT LRR": "SOX",
            "UoT Regions": "US",
            "UoT Risk Type": "Financial",
        }]

        result = asyncio.run(perform_internet_search("testsession", {"data": data}))

        assert len(result) == 1
        assert "Result line 1" in result[0]["search_result"]
        assert "Result line 2" in result[0]["search_result"]

    @patch("service.internet_search_client.MCPClient")
    def test_multiple_combinations(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value="result")
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        data = [{
            "Plan Item Number": "300",
            "Plan Item Title": "Plan C",
            "Description of Plan Item": "Desc",
            "UoT LRR": "LRR1;LRR2",
            "UoT Regions": "RegionA",
            "UoT Risk Type": "Risk1",
        }]

        result = asyncio.run(perform_internet_search("testsession", {"data": data}))

        # 2 LRR * 1 region * 1 risk = 2 combinations
        assert len(result) == 2
        assert mock_instance.invoke.await_count == 2


class TestPerformInternetSearchErrorHandling:

    @patch("service.internet_search_client.MCPClient")
    def test_unexpected_result_type_skipped(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value=12345)  # unexpected type
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        data = [{
            "Plan Item Number": "400",
            "Plan Item Title": "Plan D",
            "Description of Plan Item": "Desc",
            "UoT LRR": "Rule",
            "UoT Regions": "Region",
            "UoT Risk Type": "Risk",
        }]

        result = asyncio.run(perform_internet_search("testsession", {"data": data}))

        # Unexpected type is skipped
        assert result == []

    @patch("service.internet_search_client.MCPClient")
    def test_close_called_even_on_error(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(side_effect=RuntimeError("boom"))
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        data = [{
            "Plan Item Number": "500",
            "Plan Item Title": "Plan E",
            "Description of Plan Item": "Desc",
            "UoT LRR": "Rule",
            "UoT Regions": "Region",
            "UoT Risk Type": "Risk",
        }]

        # With return_exceptions=True, errors are logged and skipped, not raised
        result = asyncio.run(perform_internet_search("testsession", {"data": data}))

        assert result == []
        mock_instance.close.assert_awaited_once()


class TestPerformInternetSearchInputFormats:

    @patch("service.internet_search_client.MCPClient")
    def test_accepts_list_input_directly(self, mock_client_cls):
        mock_instance = MagicMock()
        mock_instance.invoke = AsyncMock(return_value="ok")
        mock_instance.close = AsyncMock()
        mock_client_cls.return_value = mock_instance

        data = [{
            "Plan Item Number": "600",
            "Plan Item Title": "Plan F",
            "Description of Plan Item": "Desc",
            "UoT LRR": "Law",
            "UoT Regions": "Area",
            "UoT Risk Type": "Type",
        }]

        result = asyncio.run(perform_internet_search("testsession", data))

        assert len(result) == 1
        assert result[0]["search_result"] == "ok"
