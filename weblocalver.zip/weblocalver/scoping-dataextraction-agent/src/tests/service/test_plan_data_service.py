import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from model.plan_artifact_enum import PlanArtifact
from service import action_service
from service import plan_data_service
from service.plan_data_service import get_plan_artifact


@pytest.fixture
def local_bucket_root(tmp_path):
    return tmp_path / "local-bucket"


def _write_json(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8")


def test_get_plan_artifact_handles_missing_agent_card(monkeypatch):
    recorded_cards = []
    monkeypatch.setenv("bucket_name", "test-bucket")
    monkeypatch.setattr(
        plan_data_service.AgentCard,
        "get_agent_card",
        lambda plan_number: None,
    )
    monkeypatch.setattr(
        action_service,
        "construct_human_actor_retrieve_records",
        lambda *args: recorded_cards.append(args[-1]),
    )
    monkeypatch.setattr(
        action_service,
        "construct_ai_actor_retrieve_records",
        lambda *args: recorded_cards.append(args[-1]),
    )
    monkeypatch.setattr(plan_data_service, "json_exists_in_gcs", lambda uri: True)
    monkeypatch.setattr(
        plan_data_service,
        "download_json_from_gcs",
        lambda uri: {"Plan Item Number": 20429},
    )

    result = get_plan_artifact("20429", PlanArtifact.HISTORICAL_PLAN_DETAILS)

    assert result["status"] == "SUCCESS"
    assert result["data"]["historical_plan_details"] == {"Plan Item Number": 20429}
    assert recorded_cards == [{}, {}]


class TestGetPlanArtifactPolicy:

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_combines_referenced_documents_from_all_three_results(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(
            base / "relevant_policy.json",
            '{"referenced_documents": [{"document_name": "PolicyDoc", "gs_uri": "gs://docs/policy.pdf"}]}',
        )
        _write_json(
            base / "relevant_procedure.json",
            '{"referenced_documents": [{"document_name": "ProcedureDoc", "gs_uri": "gs://docs/procedure.pdf"}, {"document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"}]}',
        )
        _write_json(
            base / "relevant_kod.json",
            '{"referenced_documents": [{"document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"}, {"document_name": "KodDoc", "gs_uri": "gs://docs/kod.pdf"}], "kod_text": "hello"}',
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["source"] == "gs://bucket/dbaware_review_20090/inbound-data/policy"
        assert result["data"]["referenced_documents"] == [
            {"document_type": "policy", "document_name": "PolicyDoc", "gs_uri": "gs://docs/policy.pdf"},
            {"document_type": "procedure", "document_name": "ProcedureDoc", "gs_uri": "gs://docs/procedure.pdf"},
            {"document_type": "procedure", "document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"},
            {"document_type": "kod", "document_name": "SharedDoc", "gs_uri": "gs://docs/shared.pdf"},
            {"document_type": "kod", "document_name": "KodDoc", "gs_uri": "gs://docs/kod.pdf"},
        ]

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_returns_empty_list_when_policy_payload_has_no_documents(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(base / "relevant_policy.json", '{"referenced_documents": []}')

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["data"]["referenced_documents"] == []

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_raises_when_policy_artifact_missing(self, local_bucket_root):
        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            with pytest.raises(FileNotFoundError, match="No data found"):
                get_plan_artifact("20090", PlanArtifact.POLICY)

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_returns_empty_list_when_policy_files_contain_null(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(base / "relevant_policy.json", "null")
        _write_json(base / "relevant_procedure.json", "null")
        _write_json(base / "relevant_kod.json", "null")

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["data"]["referenced_documents"] == []

    @patch.dict(
        "os.environ",
        {
            "LOCAL_BUCKET_MODE": "true",
            "bucket_name": "bucket",
        },
    )
    def test_policy_reader_supports_legacy_relevant_data_filename(self, local_bucket_root):
        base = local_bucket_root / "dbaware_review_20090" / "inbound-data" / "policy"
        _write_json(
            base / "policy" / "relevant_data.json",
            '{"referenced_documents": [{"document_name": "LegacyDoc", "gs_uri": "gs://docs/legacy.pdf"}]}'
        )

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(local_bucket_root) if k == "LOCAL_BUCKET_ROOT" else __import__("os").environ.get(k, d)):
            result = get_plan_artifact("20090", PlanArtifact.POLICY)

        assert result["plan_number"] == "20090"
        assert result["artifact"] == "policy"
        assert result["data"]["referenced_documents"] == [
            {
                "document_type": "policy",
                "document_name": "LegacyDoc",
                "gs_uri": "gs://docs/legacy.pdf",
            }
        ]