from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys
from unittest.mock import patch, MagicMock
import pytest

from fastapi.testclient import TestClient

def _load_module_from_path(module_path: Path, module_name: str): 
    """Load a module by path and temporarily ensure its parent "main" directory is on sys.path

    This allows imports like `from service import ...` inside the module to resolve to
    the project's `main` package directory when running tests.
    """
    main_dir = str(module_path.resolve().parent)
    inserted = False
    if main_dir not in sys.path:
        sys.path.insert(0, main_dir)
        inserted = True
    try:
        spec = spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise AssertionError(f"Unable to load module at {module_path}")
        module = module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        if inserted and main_dir in sys.path:
            sys.path.remove(main_dir)


class TestDataExtractionEndpoint:
    """Test POST /data-extraction endpoint for session creation and background task handling."""

    def test_trigger_data_extraction_success(self, monkeypatch):
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module")

        # Mock session and extraction services
        session_mock = {
            "session_id": "sess-123",
            "plan_number": "P123",
            "status": "QUEUED",
        }

        monkeypatch.setattr(module.session_service, "create_session", lambda plan: session_mock)

        client = TestClient(module.app)
        resp = client.post("/data-extraction", json={"planNumber": "P123"})

        assert resp.status_code == 202
        assert resp.json()["session_id"] == "sess-123"
        assert resp.json()["status"] == "QUEUED"

    def test_trigger_data_extraction_creates_session(self, monkeypatch):
        """Verify session is created before background task starts."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_create_session")

        create_session_mock = MagicMock(return_value={"session_id": "sess-456", "plan_number": "P456", "status": "QUEUED"})
        monkeypatch.setattr(module.session_service, "create_session", create_session_mock)

        client = TestClient(module.app)
        resp = client.post("/data-extraction", json={"planNumber": "P456"})

        assert resp.status_code == 202
        create_session_mock.assert_called_once_with("P456")

    def test_trigger_data_extraction_invalid_plan(self, monkeypatch):
        """Test error handling when plan validation fails."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_invalid")

        monkeypatch.setattr(module.session_service, "create_session", MagicMock(side_effect=ValueError("Invalid plan")))

        client = TestClient(module.app)
        resp = client.post("/data-extraction", json={"planNumber": "INVALID"})

        assert resp.status_code == 404
        assert "Invalid plan" in resp.json()["detail"]

    def test_trigger_data_extraction_internal_error(self, monkeypatch):
        """Test error handling for unexpected exceptions."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_error")

        monkeypatch.setattr(module.session_service, "create_session", MagicMock(side_effect=RuntimeError("DB connection failed")))

        client = TestClient(module.app)
        resp = client.post("/data-extraction", json={"planNumber": "ERR"})

        assert resp.status_code == 500
        assert "internal error" in resp.json()["detail"].lower()


class TestDataExtractionStatusEndpoint:
    """Test GET /data-extraction/{session_id}/status endpoint."""

    def test_get_extraction_status_success(self, monkeypatch):
        """Verify status endpoint returns session details."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_status")

        session_data = {
            "session_id": "sess-789",
            "stage": "data_extraction",
            "plan_number": "P789",
            "status": "PROCESSING",
            "error": "",
        }
        monkeypatch.setattr(module.session_service, "get_session", lambda sid: session_data if sid == "sess-789" else None)

        client = TestClient(module.app)
        resp = client.get("/data-extraction/sess-789/status")

        assert resp.status_code == 200
        data = resp.json()
        assert data["session_id"] == "sess-789"
        assert data["status"] == "PROCESSING"
        assert data["plan_number"] == "P789"
        assert data["stage_name"] == "data_extraction"

    def test_get_extraction_status_excludes_llm_usage(self, monkeypatch):
        """Verify status polling does not expose stored LLM usage details."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_status_without_llm_usage")

        session_data = {
            "session_id": "sess-usage",
            "stage": "dbaware",
            "plan_number": "P789",
            "status": "PROCESSING",
            "error": "",
            "llm_usage": [
                {
                    "operation": "historical_plan_matching",
                    "model_params": {"model": "gemini-2.5-pro"},
                    "usage_metadata": {"input_tokens": 1355},
                }
            ],
        }
        monkeypatch.setattr(module.session_service, "get_session", lambda sid: session_data)

        client = TestClient(module.app)
        resp = client.get("/data-extraction/sess-usage/status")

        assert resp.status_code == 200
        data = resp.json()
        assert data == {
            "session_id": "sess-usage",
            "stage_name": "dbaware",
            "plan_number": "P789",
            "status": "PROCESSING",
            "error": None,
        }

    def test_get_extraction_status_not_found(self, monkeypatch):
        """Verify error handling for non-existent session."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_status_notfound")

        monkeypatch.setattr(module.session_service, "get_session", lambda sid: None)

        client = TestClient(module.app)
        resp = client.get("/data-extraction/invalid-session/status")

        assert resp.status_code == 404
        assert "Invalid session id" in resp.json()["detail"]

    def test_get_extraction_status_completed(self, monkeypatch):
        """Verify status endpoint returns completed session."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_status_completed")

        session_data = {
            "session_id": "sess-comp",
            "stage": "data_extraction",
            "plan_number": "P999",
            "status": "COMPLETED",
            "error": "",
        }
        monkeypatch.setattr(module.session_service, "get_session", lambda sid: session_data)

        client = TestClient(module.app)
        resp = client.get("/data-extraction/sess-comp/status")

        assert resp.status_code == 200
        assert resp.json()["status"] == "COMPLETED"

    def test_get_extraction_status_failed(self, monkeypatch):
        """Verify status endpoint returns failed session with error."""
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_status_failed")

        session_data = {
            "session_id": "sess-fail",
            "stage": "dbaware",
            "plan_number": "P999",
            "status": "FAILED",
            "error": "Connection timeout",
        }
        monkeypatch.setattr(module.session_service, "get_session", lambda sid: session_data)

        client = TestClient(module.app)
        resp = client.get("/data-extraction/sess-fail/status")

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "FAILED"
        assert data["error"] == "Connection timeout"


class TestHealthCheckEndpoint:
    """Test GET /health endpoint."""

    def test_health_check(self):
        module_path = Path(__file__).resolve().parents[1] / "main" / "app.py"
        module = _load_module_from_path(module_path, "app_module_health")

        client = TestClient(module.app)
        resp = client.get("/health")

        assert resp.status_code == 200
        assert resp.json()["status"] == "healthy"
