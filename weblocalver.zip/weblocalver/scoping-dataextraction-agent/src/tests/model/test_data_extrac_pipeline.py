import sys
from pathlib import Path

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from model.data_extrac_pipeline import DataExtractionRequest


class TestDataExtractionRequest:

    def test_valid_plan_number(self):
        req = DataExtractionRequest(planNumber="12345")
        assert req.planNumber == "12345"

    def test_plan_number_is_required(self):
        with pytest.raises(Exception):
            DataExtractionRequest()

    def test_plan_number_rejects_non_string(self):
        with pytest.raises(Exception):
            DataExtractionRequest(planNumber=99999)

    def test_empty_plan_number_allowed(self):
        req = DataExtractionRequest(planNumber="")
        assert req.planNumber == ""

    def test_serialization(self):
        req = DataExtractionRequest(planNumber="ABC")
        assert req.model_dump() == {"planNumber": "ABC", "userDetails": None}

    def test_from_dict(self):
        req = DataExtractionRequest(**{"planNumber": "P-100"})
        assert req.planNumber == "P-100"

    def test_extra_fields_ignored_or_rejected(self):
        # Depending on Pydantic config, extra fields are either ignored or raise error
        try:
            req = DataExtractionRequest(planNumber="X", extra="nope")
            # If no error, extra field should not appear in model
            assert "extra" not in req.model_dump()
        except Exception:
            pass  # Pydantic rejected extra field — acceptable behavior
