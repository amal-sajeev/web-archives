import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))


class TestConfigDefaults:
    """Tests that Config loads expected defaults when env vars are not set."""

    @patch("dotenv.load_dotenv", MagicMock())
    @patch.dict(os.environ, {}, clear=True)
    def test_http_proxy_defaults_to_empty(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.HTTP_PROXY == ""

    @patch("dotenv.load_dotenv", MagicMock())
    @patch.dict(os.environ, {}, clear=True)
    def test_https_proxy_defaults_to_empty(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.HTTPS_PROXY == ""

    @patch("dotenv.load_dotenv", MagicMock())
    @patch.dict(os.environ, {}, clear=True)
    def test_no_proxy_defaults_to_empty(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.NO_PROXY == ""

    @patch("dotenv.load_dotenv", MagicMock())
    @patch.dict(os.environ, {}, clear=True)
    def test_mcp_server_url_default(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert (
            settings_mod.Config.data_extraction_mcp_server_url
            == "http://127.0.0.1:8000"
        )

    @patch("dotenv.load_dotenv", MagicMock())
    @patch.dict(os.environ, {}, clear=True)
    def test_mcp_server_name_defaults_to_none(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.data_extraction_mcp_server_name is None

    @patch("dotenv.load_dotenv", MagicMock())
    @patch.dict(os.environ, {}, clear=True)
    def test_rag_defaults(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.RAG_BASE_URL == ""


class TestConfigFromEnv:
    """Tests that Config reads values from environment variables."""

    @patch.dict(os.environ, {"http_proxy": "http://proxy:8080"})
    def test_http_proxy_from_env(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.HTTP_PROXY == "http://proxy:8080"

    @patch.dict(os.environ, {"https_proxy": "https://proxy:8443"})
    def test_https_proxy_from_env(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.HTTPS_PROXY == "https://proxy:8443"

    @patch.dict(os.environ, {"no_proxy": "localhost,127.0.0.1"})
    def test_no_proxy_from_env(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.NO_PROXY == "localhost,127.0.0.1"

    @patch.dict(os.environ, {"data_extraction_mcp_server_url": "http://mcp:9000"})
    def test_mcp_server_url_from_env(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.data_extraction_mcp_server_url == "http://mcp:9000"

    @patch.dict(os.environ, {"data_extraction_mcp_server_name": "my_server"})
    def test_mcp_server_name_from_env(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.data_extraction_mcp_server_name == "my_server"

    @patch.dict(
        os.environ,
        {
            "RAG_BASE_URL": "https://rag.internal",
        },
    )
    def test_rag_settings_from_env(self):
        import importlib
        import config.settings as settings_mod

        importlib.reload(settings_mod)

        assert settings_mod.Config.RAG_BASE_URL == "https://rag.internal"

class TestDirectoryPaths:
    """Tests that directory path constants are set correctly."""

    def test_src_main_dir_points_to_main(self):
        import config.settings as settings_mod

        assert settings_mod.SRC_MAIN_DIR.name == "main"
        assert settings_mod.SRC_MAIN_DIR.is_dir()

    def test_data_dir_is_under_main(self):
        import config.settings as settings_mod

        assert settings_mod.DATA_DIR_.parent == settings_mod.SRC_MAIN_DIR
        assert settings_mod.DATA_DIR_.name == "data"
