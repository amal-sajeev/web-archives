import sys
import asyncio
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest
import httpx

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))


class TestLocalMcpHttpClientFactory:

    def test_returns_async_client_with_correct_params(self):
        from tools.mcp_tool_adapter import _local_mcp_http_client_factory

        client = _local_mcp_http_client_factory(
            headers={"X-Custom": "value"},
            timeout=httpx.Timeout(30.0),
            auth=None,
        )

        assert isinstance(client, httpx.AsyncClient)
        assert client.headers.get("X-Custom") == "value"
        assert client.follow_redirects is True

    def test_returns_client_with_no_args(self):
        from tools.mcp_tool_adapter import _local_mcp_http_client_factory

        client = _local_mcp_http_client_factory()
        assert isinstance(client, httpx.AsyncClient)

    def test_ssl_verification_disabled(self):
        from tools.mcp_tool_adapter import _local_mcp_http_client_factory

        client = _local_mcp_http_client_factory()
        # verify=False results in an unverified SSL context
        assert client._transport._pool._ssl_context.check_hostname is False


class TestGetMcpTools:

    @pytest.fixture(autouse=True)
    def reset_globals(self):
        """Reset module-level globals before each test."""
        import tools.mcp_tool_adapter as mod
        mod._MCP_CLIENT = None
        mod._MCP_TOOLS = None
        yield
        mod._MCP_CLIENT = None
        mod._MCP_TOOLS = None

    @patch("tools.mcp_tool_adapter.MultiServerMCPClient")
    def test_get_mcp_tools_creates_client_and_returns_tools(self, mock_client_cls):
        from tools.mcp_tool_adapter import get_mcp_tools

        mock_instance = MagicMock()
        mock_instance.get_tools = AsyncMock(return_value=["tool_a", "tool_b"])
        mock_client_cls.return_value = mock_instance

        tools = asyncio.run(get_mcp_tools())

        assert tools == ["tool_a", "tool_b"]
        mock_client_cls.assert_called_once()
        mock_instance.get_tools.assert_awaited_once()

    @patch("tools.mcp_tool_adapter.MultiServerMCPClient")
    def test_get_mcp_tools_caches_result(self, mock_client_cls):
        from tools.mcp_tool_adapter import get_mcp_tools

        mock_instance = MagicMock()
        mock_instance.get_tools = AsyncMock(return_value=["tool_x"])
        mock_client_cls.return_value = mock_instance

        tools1 = asyncio.run(get_mcp_tools())
        tools2 = asyncio.run(get_mcp_tools())

        assert tools1 is tools2
        # Client created only once
        mock_client_cls.assert_called_once()
        mock_instance.get_tools.assert_awaited_once()

    @patch("tools.mcp_tool_adapter.MultiServerMCPClient")
    def test_get_mcp_tools_passes_config(self, mock_client_cls):
        from tools.mcp_tool_adapter import get_mcp_tools, Config

        mock_instance = MagicMock()
        mock_instance.get_tools = AsyncMock(return_value=[])
        mock_client_cls.return_value = mock_instance

        asyncio.run(get_mcp_tools())

        call_args = mock_client_cls.call_args[0][0]
        # Verify the dict has exactly one server entry with correct structure
        assert len(call_args) == 1
        server_cfg = list(call_args.values())[0]
        assert server_cfg["transport"] == "streamable_http"
        assert "url" in server_cfg
        assert "httpx_client_factory" in server_cfg

    @patch("tools.mcp_tool_adapter.MultiServerMCPClient")
    def test_get_mcp_tools_raises_on_client_error(self, mock_client_cls):
        from tools.mcp_tool_adapter import get_mcp_tools

        mock_instance = MagicMock()
        mock_instance.get_tools = AsyncMock(side_effect=RuntimeError("connection failed"))
        mock_client_cls.return_value = mock_instance

        with pytest.raises(RuntimeError, match="connection failed"):
            asyncio.run(get_mcp_tools())
