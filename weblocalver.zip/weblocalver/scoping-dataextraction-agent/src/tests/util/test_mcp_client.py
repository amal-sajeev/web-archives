import sys
import asyncio
import json
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from util.mcp_client import _find_tool_by_name, _extract_mcp_output, MCPClient


class TestFindToolByName:

    def test_finds_matching_tool(self):
        tool_a = MagicMock(name="tool_a")
        tool_a.name = "tool_a"
        tool_b = MagicMock(name="tool_b")
        tool_b.name = "tool_b"

        result = _find_tool_by_name([tool_a, tool_b], "tool_b")
        assert result is tool_b

    def test_returns_none_when_not_found(self):
        tool = MagicMock()
        tool.name = "other"
        assert _find_tool_by_name([tool], "missing") is None

    def test_returns_none_for_empty_list(self):
        assert _find_tool_by_name([], "anything") is None

    def test_handles_tools_without_name_attr(self):
        tool = object()  # no 'name' attribute
        assert _find_tool_by_name([tool], "x") is None


class TestExtractMcpOutput:

    def test_parses_json_text_from_first_item(self):
        result = [{"text": '{"key": "value"}'}]
        assert _extract_mcp_output(result) == {"key": "value"}

    def test_returns_original_on_invalid_json(self):
        result = [{"text": "not json"}]
        assert _extract_mcp_output(result) == result

    def test_returns_result_if_not_list(self):
        assert _extract_mcp_output("hello") == "hello"
        assert _extract_mcp_output(42) == 42
        assert _extract_mcp_output(None) is None

    def test_returns_result_if_empty_list(self):
        assert _extract_mcp_output([]) == []

    def test_returns_result_if_first_item_not_dict(self):
        assert _extract_mcp_output(["string"]) == ["string"]

    def test_returns_result_if_text_not_string(self):
        result = [{"text": 123}]
        assert _extract_mcp_output(result) == result

    def test_parses_list_json(self):
        result = [{"text": '[1, 2, 3]'}]
        assert _extract_mcp_output(result) == [1, 2, 3]


class TestMCPClientInit:

    def test_default_base_url(self):
        client = MCPClient()
        assert client.invoke_url == "http://127.0.0.1:8000/tools/invoke"

    def test_custom_base_url(self):
        client = MCPClient(base_url="http://my-server:9000")
        assert client.invoke_url == "http://my-server:9000/tools/invoke"


class TestMCPClientInvoke:

    @patch("util.mcp_client.get_mcp_tools")
    def test_invoke_success(self, mock_get_tools):
        mock_tool = MagicMock()
        mock_tool.name = "my_tool"
        mock_tool.ainvoke = AsyncMock(return_value=[{"text": '{"result": "ok"}'}])
        mock_get_tools.return_value = [mock_tool]

        client = MCPClient()
        result = asyncio.run(client.invoke("my_tool", {"arg": "val"}))

        assert result == {"result": "ok"}
        mock_tool.ainvoke.assert_awaited_once_with({"arg": "val"})

    @patch("util.mcp_client.get_mcp_tools")
    def test_invoke_tool_not_found_raises(self, mock_get_tools):
        mock_tool = MagicMock()
        mock_tool.name = "other_tool"
        mock_get_tools.return_value = [mock_tool]

        client = MCPClient()
        with pytest.raises(RuntimeError, match="was not discovered"):
            asyncio.run(client.invoke("missing_tool", {}))

    @patch("util.mcp_client.get_mcp_tools")
    def test_invoke_propagates_tool_error(self, mock_get_tools):
        mock_tool = MagicMock()
        mock_tool.name = "bad_tool"
        mock_tool.ainvoke = AsyncMock(side_effect=Exception("tool exploded"))
        mock_get_tools.return_value = [mock_tool]

        client = MCPClient()
        with pytest.raises(Exception, match="tool exploded"):
            asyncio.run(client.invoke("bad_tool", {}))

    @patch("util.mcp_client.get_mcp_tools", new_callable=AsyncMock, side_effect=RuntimeError("discovery failed"))
    def test_invoke_propagates_discovery_error(self, mock_get_tools):
        client = MCPClient()
        with pytest.raises(RuntimeError, match="discovery failed"):
            asyncio.run(client.invoke("any", {}))


class TestMCPClientClose:

    def test_close_calls_aclose(self):
        client = MCPClient()
        client.async_client = MagicMock()
        client.async_client.aclose = AsyncMock()

        asyncio.run(client.close())

        client.async_client.aclose.assert_awaited_once()
