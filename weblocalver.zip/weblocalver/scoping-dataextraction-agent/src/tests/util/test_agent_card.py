import sys
import uuid
from pathlib import Path

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from util import agent_card


def test_build_agent_card_default_values(monkeypatch):
    monkeypatch.delenv("ACTOR_ID", raising=False)
    monkeypatch.delenv("ENVIRONMENT", raising=False)
    monkeypatch.delenv("ENV", raising=False)
    monkeypatch.delenv("SERVICE_VERSION", raising=False)

    card = agent_card.AgentCard.build_agent_card("data_extraction","20090")

    assert card["ACTOR_ID"] == agent_card.DEFAULT_ACTOR_ID
    assert card["ACTIVITY_ID"] == "DATA_EXTRACTION"
    assert card["PARENT_ENTITY_TYPE"] == "SCOPING"
    assert card["PARENT_ENTITY_ID"] == "20090"
    assert card["ACTIVITY_TYPE"] == "DATA_EXTRACTION"
    assert card["ACTION_TYPE"] == "DATA_EXTRACT AND SAVE"
    assert card["STATUS"] == "SUCCESS"
    assert card["ENVIRONMENT"] == "dev"
    assert card["SERVICE_VERSION"] == 'unknown'
    assert "DURATION_MS" not in card
    assert "ERROR_MESSAGE" not in card
    assert "METADATA" not in card


def test_build_agent_card_environment_variable_overrides(monkeypatch):
    monkeypatch.setenv("ACTOR_ID", "data-extraction-agent")
    monkeypatch.setenv("ENVIRONMENT", "dev")
    monkeypatch.setenv("SERVICE_VERSION", "unknown")

    card = agent_card.AgentCard.build_agent_card("data_extraction", "20090")

    assert card["ACTOR_ID"] == "data-extraction-agent"
    assert card["ENVIRONMENT"] == "dev"
    assert card["SERVICE_VERSION"] == "unknown"


def test_build_agent_card_env_fallback_when_environment_missing(monkeypatch):
    monkeypatch.delenv("ENVIRONMENT", raising=False)
    monkeypatch.setenv("ENV", 'dev')

    card = agent_card.AgentCard.build_agent_card("data_extraction", "20090")

    assert card["ENVIRONMENT"] == "dev"




def test_build_agent_card_generates_uuid_when_correlation_id_missing():
    card = agent_card.AgentCard.build_agent_card("data_extraction","20090")

    assert uuid.UUID(card["ENTITY_ID"])


def test_build_agent_card_uses_plan_item_number_as_parent_entity_id():
    card = agent_card.AgentCard.build_agent_card("data_extraction", plan_item_number="20090")

    assert card["PARENT_ENTITY_ID"] == "20090"


def test_build_agent_card_derives_deterministic_entity_id_from_plan_item_number():
    card_one = agent_card.AgentCard.build_agent_card("data_extraction", plan_item_number="20090")
    card_two = agent_card.AgentCard.build_agent_card("data_extraction", plan_item_number="20538")

    assert uuid.UUID(card_one["ENTITY_ID"])
    assert card_one["ENTITY_ID"] != card_two["ENTITY_ID"]


def test_build_agent_card_supplied_parent_entity_values_take_precedence():
    card = agent_card.AgentCard.build_agent_card(
        "PLAN_EXTRACTION",
        plan_item_number="20538",
        parent_entity_type="SCOPING",
        parent_entity_id="20538",
    )

    assert card["PARENT_ENTITY_TYPE"] == "SCOPING"
    assert card["PARENT_ENTITY_ID"] == "20538"









def test_build_agent_card_includes_error_message_for_failure_status():
    card = agent_card.AgentCard.build_agent_card(
        "PLAN_EXTRACTION",
        status="FAILED",
        error_message="Connection timeout",
        plan_item_number="20538"
    )



def test_build_agent_card_excludes_error_message_for_success_status():
    card = agent_card.AgentCard.build_agent_card(
        "PLAN_EXTRACTION",
        status="SUCCESS",
        error_message="Should not appear",
        plan_item_number="20538"
    )

    assert "ERROR_MESSAGE" not in card


def test_build_agent_card_timestamp_is_utc_iso8601_with_z_suffix():
    card = agent_card.AgentCard.build_agent_card("data_extraction",plan_item_number="20538")

    timestamp = card["TIMESTAMP"]
    assert timestamp.endswith("Z")
    assert "T" in timestamp
