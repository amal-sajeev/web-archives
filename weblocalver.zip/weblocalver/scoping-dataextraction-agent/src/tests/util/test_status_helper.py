import sys
from pathlib import Path
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock, mock_open, call
from threading import Thread
import tempfile
import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from util.status_helper import (
    update_session_requests_file,
    read_session_requests_file,
    set_session_status,
    get_session_status,
    get_current_run_info,
)
from model.status_enum import Status


class TestUpdateSessionRequestsFile:
    """Test atomic file write operations for session persistence."""

    @patch("util.status_helper.tempfile.NamedTemporaryFile")
    @patch("util.status_helper.Path")
    def test_update_session_requests_file_creates_directory(self, mock_path_class, mock_temp_file):
        """Verify parent directory is created if it doesn't exist."""
        mock_path = MagicMock()
        mock_path_class.return_value = mock_path
        mock_file = MagicMock()
        mock_temp_file.return_value.__enter__.return_value = mock_file

        update_session_requests_file({"test": "data"})

        mock_path.parent.mkdir.assert_called_once_with(parents=True, exist_ok=True)

    @patch("util.status_helper.tempfile.NamedTemporaryFile")
    @patch("util.status_helper.Path")
    def test_update_session_requests_file_atomic_write(self, mock_path_class, mock_temp_file):
        """Verify atomic write using temporary file and rename."""
        mock_path_instance = MagicMock()
        mock_path_instance.replace = MagicMock()
        mock_path_class.return_value = mock_path_instance
        
        mock_temp_file_obj = MagicMock()
        mock_temp_file_obj.name = "/tmp/tempfile123"
        mock_temp_file.return_value.__enter__.return_value = mock_temp_file_obj

        update_session_requests_file({"test": "data"})

        # Verify temporary file was created
        mock_temp_file.assert_called_once()
        # Verify replace was called (atomic operation)
        assert mock_path_instance.replace.called


class TestReadSessionRequestsFile:
    """Test reading session data from YAML file."""

    @patch("util.status_helper.Path")
    def test_read_session_requests_file_returns_empty_dict_when_missing(self, mock_path_class):
        """Verify empty dict is returned when file doesn't exist."""
        mock_path = MagicMock()
        mock_path.exists.return_value = False
        mock_path_class.return_value = mock_path

        result = read_session_requests_file()

        assert result == {}

    @patch("util.status_helper.yaml.safe_load")
    @patch("util.status_helper.Path")
    def test_read_session_requests_file_returns_parsed_yaml(self, mock_path_class, mock_yaml_load):
        """Verify YAML file content is parsed and returned."""
        mock_path = MagicMock()
        mock_path.exists.return_value = True
        mock_path.open.return_value.__enter__.return_value.read.return_value = "{}"
        mock_path_class.return_value = mock_path
        mock_yaml_load.return_value = {"sess-001": {"status": "PROCESSING"}}

        result = read_session_requests_file()

        assert result == {"sess-001": {"status": "PROCESSING"}}

    @patch("util.status_helper.yaml.safe_load")
    @patch("util.status_helper.Path")
    def test_read_session_requests_file_handles_non_dict_yaml(self, mock_path_class, mock_yaml_load):
        """Verify empty dict is returned when YAML is not a dict."""
        mock_path = MagicMock()
        mock_path.exists.return_value = True
        mock_path.open.return_value.__enter__.return_value = MagicMock()
        mock_path_class.return_value = mock_path
        mock_yaml_load.return_value = "invalid"  # Not a dict

        result = read_session_requests_file()

        assert result == {}


class TestSetSessionStatus:
    """Test session status persistence with thread-safe locking."""

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    @patch("util.status_helper.datetime")
    def test_set_session_status_creates_new_session(self, mock_datetime, mock_read, mock_update):
        """Verify new session is created with proper structure."""
        mock_now = MagicMock()
        mock_now.isoformat.return_value = "2026-09-04T12:00:00"
        mock_datetime.now.return_value = mock_now
        mock_read.return_value = {}

        set_session_status(
            session_id="sess-new",
            stage_name="data_extraction",
            status=Status.QUEUED,
            plan_number="plan-123",
        )

        # Verify update was called
        mock_update.assert_called_once()
        call_args = mock_update.call_args[0][0]

        assert "sess-new" in call_args
        session = call_args["sess-new"]
        assert session["session_id"] == "sess-new"
        assert session["stage"] == "data_extraction"
        assert session["status"] == Status.QUEUED.value
        assert session["plan_number"] == "plan-123"
        assert "created_at" in session
        assert "updated_at" in session

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    @patch("util.status_helper.datetime")
    def test_set_session_status_updates_existing_session(self, mock_datetime, mock_read, mock_update):
        """Verify existing session is updated, not overwritten."""
        mock_now = MagicMock()
        mock_now.isoformat.return_value = "2026-09-04T12:00:01"
        mock_datetime.now.return_value = mock_now
        existing_session = {
            "session_id": "sess-existing",
            "created_at": "2026-09-04T12:00:00",
            "stage": "old_stage",
        }
        mock_read.return_value = {"sess-existing": existing_session}

        set_session_status(
            session_id="sess-existing",
            stage_name="data_extraction",
            status=Status.PROCESSING,
        )

        call_args = mock_update.call_args[0][0]
        session = call_args["sess-existing"]
        assert session["created_at"] == "2026-09-04T12:00:00"  # Preserved
        assert session["updated_at"] == "2026-09-04T12:00:01"  # Updated
        assert session["stage"] == "data_extraction"

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    @patch("util.status_helper.datetime")
    def test_set_session_status_tracks_current_run(self, mock_datetime, mock_read, mock_update):
        """Verify current_run is updated when status is PROCESSING."""
        mock_now = MagicMock()
        mock_now.isoformat.return_value = "2026-09-04T12:00:00"
        mock_datetime.now.return_value = mock_now
        mock_read.return_value = {}

        set_session_status(
            session_id="sess-proc",
            stage_name="dbaware",
            status=Status.PROCESSING,
        )

        call_args = mock_update.call_args[0][0]
        assert call_args["current_run"]["dbaware"] == "sess-proc"

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    @patch("util.status_helper.datetime")
    def test_set_session_status_clears_current_run_on_completion(self, mock_datetime, mock_read, mock_update):
        """Verify current_run is cleared when session completes."""
        mock_now = MagicMock()
        mock_now.isoformat.return_value = "2026-09-04T12:00:00"
        mock_datetime.now.return_value = mock_now
        mock_read.return_value = {"current_run": {"data_extraction": "sess-done"}}

        set_session_status(
            session_id="sess-done",
            stage_name="data_extraction",
            status=Status.COMPLETED,
        )

        call_args = mock_update.call_args[0][0]
        assert call_args["current_run"]["data_extraction"] == ""

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    @patch("util.status_helper.datetime")
    def test_set_session_status_with_error_message(self, mock_datetime, mock_read, mock_update):
        """Verify error message is persisted."""
        mock_now = MagicMock()
        mock_now.isoformat.return_value = "2026-09-04T12:00:00"
        mock_datetime.now.return_value = mock_now
        mock_read.return_value = {}

        error_msg = "Connection timeout occurred"
        set_session_status(
            session_id="sess-err",
            stage_name="dbgrc",
            status=Status.FAILED,
            error=error_msg,
        )

        call_args = mock_update.call_args[0][0]
        assert call_args["sess-err"]["error"] == error_msg


class TestGetSessionStatus:
    """Test retrieving session status with thread-safe access."""

    @patch("util.status_helper.read_session_requests_file")
    def test_get_session_status_returns_session(self, mock_read):
        """Verify session data is returned when found."""
        session_data = {
            "session_id": "sess-fetch",
            "status": "PROCESSING",
            "plan_number": "plan-x",
        }
        mock_read.return_value = {"sess-fetch": session_data}

        result = get_session_status("sess-fetch")

        assert result == session_data

    @patch("util.status_helper.read_session_requests_file")
    def test_get_session_status_returns_none_when_not_found(self, mock_read):
        """Verify None is returned for non-existent session."""
        mock_read.return_value = {}

        result = get_session_status("non-existent")

        assert result is None

    @patch("util.status_helper.read_session_requests_file")
    def test_get_session_status_returns_none_for_non_dict_value(self, mock_read):
        """Verify None is returned when session value is not a dict."""
        mock_read.return_value = {"sess-bad": "not-a-dict"}

        result = get_session_status("sess-bad")

        assert result is None


class TestGetCurrentRunInfo:
    """Test retrieving active session for a stage."""

    @patch("util.status_helper.read_session_requests_file")
    def test_get_current_run_info_returns_active_session(self, mock_read):
        """Verify active session ID is returned for stage."""
        mock_read.return_value = {"current_run": {"data_extraction": "sess-active"}}

        result = get_current_run_info("data_extraction")

        assert result == "sess-active"

    @patch("util.status_helper.read_session_requests_file")
    def test_get_current_run_info_returns_none_when_no_active_session(self, mock_read):
        """Verify None is returned when no active session for stage."""
        mock_read.return_value = {"current_run": {}}

        result = get_current_run_info("data_extraction")

        assert result is None

    @patch("util.status_helper.read_session_requests_file")
    def test_get_current_run_info_handles_empty_string_session(self, mock_read):
        """Verify None is returned when session ID is empty string."""
        mock_read.return_value = {"current_run": {"data_extraction": ""}}

        result = get_current_run_info("data_extraction")

        assert result is None

    @patch("util.status_helper.read_session_requests_file")
    def test_get_current_run_info_with_non_dict_current_run(self, mock_read):
        """Verify None is returned when current_run is not a dict."""
        mock_read.return_value = {"current_run": "invalid"}

        result = get_current_run_info("data_extraction")

        assert result is None


class TestThreadSafety:
    """Test thread-safe locking for concurrent access."""

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    def test_set_session_status_uses_lock(self, mock_read, mock_update):
        """Verify lock is acquired during set_session_status."""
        mock_read.return_value = {}

        with patch("util.status_helper._session_file_lock") as mock_lock:
            set_session_status(
                session_id="sess-lock",
                stage_name="data_extraction",
                status=Status.PROCESSING,
            )
            # Verify lock context manager was used
            mock_lock.__enter__.assert_called()
            mock_lock.__exit__.assert_called()

    @patch("util.status_helper.read_session_requests_file")
    def test_get_session_status_uses_lock(self, mock_read):
        """Verify lock is acquired during get_session_status."""
        mock_read.return_value = {}

        with patch("util.status_helper._session_file_lock") as mock_lock:
            get_session_status("sess-lock")
            mock_lock.__enter__.assert_called()
            mock_lock.__exit__.assert_called()

    @patch("util.status_helper.read_session_requests_file")
    def test_get_current_run_info_uses_lock(self, mock_read):
        """Verify lock is acquired during get_current_run_info."""
        mock_read.return_value = {}

        with patch("util.status_helper._session_file_lock") as mock_lock:
            get_current_run_info("data_extraction")
            mock_lock.__enter__.assert_called()
            mock_lock.__exit__.assert_called()


class TestStatusHelperIntegration:
    """Integration tests for complete session persistence workflow."""

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    @patch("util.status_helper.datetime")
    def test_session_lifecycle_persistence(self, mock_datetime, mock_read, mock_update):
        """Test complete session lifecycle with persistence."""
        mock_now = MagicMock()
        mock_now.isoformat.return_value = "2026-09-04T12:00:00"
        mock_datetime.now.return_value = mock_now

        # Simulate session creation
        mock_read.return_value = {}
        set_session_status(
            session_id="sess-lifecycle",
            stage_name="data_extraction",
            status=Status.QUEUED,
            plan_number="plan-lifecycle",
        )

        # Verify created session structure
        first_call_args = mock_update.call_args_list[0][0][0]
        session = first_call_args["sess-lifecycle"]
        assert session["status"] == Status.QUEUED.value

        # Simulate status transition to PROCESSING
        mock_read.return_value = first_call_args
        set_session_status(
            session_id="sess-lifecycle",
            stage_name="data_extraction",
            status=Status.PROCESSING,
        )

        # Verify PROCESSING state preserves created_at
        second_call_args = mock_update.call_args_list[1][0][0]
        session = second_call_args["sess-lifecycle"]
        assert session["status"] == Status.PROCESSING.value
        assert session["created_at"] == "2026-09-04T12:00:00"

    @patch("util.status_helper.update_session_requests_file")
    @patch("util.status_helper.read_session_requests_file")
    def test_multiple_sessions_concurrent_tracking(self, mock_read, mock_update):
        """Test tracking multiple concurrent sessions."""
        mock_read.return_value = {}

        sessions = [
            ("sess-001", "stage-a", Status.PROCESSING),
            ("sess-002", "stage-b", Status.PROCESSING),
            ("sess-003", "stage-c", Status.PROCESSING),
        ]

        for sess_id, stage, status in sessions:
            set_session_status(
                session_id=sess_id,
                stage_name=stage,
                status=status,
            )

        # Verify all sessions tracked
        last_call_args = mock_update.call_args_list[-1][0][0]
        assert "current_run" in last_call_args
