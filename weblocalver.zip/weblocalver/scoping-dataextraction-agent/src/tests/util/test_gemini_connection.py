import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from util import gemini_connection as gc


@patch("util.gemini_connection.ChatGoogleGenerativeAI")
def test_initialize_gemini_model_success(mock_chat, monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "gemini-2.5-pro")
    monkeypatch.setattr(gc.Config, "PROJECT_NAME", "proj")
    monkeypatch.setattr(gc.Config, "PROJECT_LOCATION", "europe-west3")
    monkeypatch.setattr(gc.Config, "GENERATION_CONFIG", {"temperature": 0.0, "top_p": 0.5, "top_k": 32})
    monkeypatch.setattr(gc.Config, "SAFETY_CONFIG", {"safety_settings": {"A": "B"}})

    fake_model = object()
    mock_chat.return_value = fake_model

    result = gc.initialize_gemini_model()

    assert result is fake_model
    mock_chat.assert_called_once_with(
        model="gemini-2.5-pro",
        project="proj",
        location="europe-west3",
        temperature=0.0,
        top_p=0.5,
        top_k=32,
        safety_settings={"A": "B"},
    )


def test_initialize_gemini_model_raises_on_missing_model_name(monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "")
    monkeypatch.setattr(gc.Config, "PROJECT_NAME", "proj")
    monkeypatch.setattr(gc.Config, "PROJECT_LOCATION", "loc")

    with pytest.raises(ValueError, match="MODEL_NAME not configured"):
        gc.initialize_gemini_model()


def test_initialize_gemini_model_raises_on_missing_project_name(monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "gemini")
    monkeypatch.setattr(gc.Config, "PROJECT_NAME", "")
    monkeypatch.setattr(gc.Config, "PROJECT_LOCATION", "loc")

    with pytest.raises(ValueError, match="PROJECT_NAME not configured"):
        gc.initialize_gemini_model()


def test_initialize_gemini_model_raises_on_missing_project_location(monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "gemini")
    monkeypatch.setattr(gc.Config, "PROJECT_NAME", "proj")
    monkeypatch.setattr(gc.Config, "PROJECT_LOCATION", "")

    with pytest.raises(ValueError, match="PROJECT_LOCATION not configured"):
        gc.initialize_gemini_model()


@patch("util.gemini_connection.ChatGoogleGenerativeAI", side_effect=RuntimeError("auth failed"))
def test_initialize_gemini_model_propagates_constructor_error(mock_chat, monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "gemini")
    monkeypatch.setattr(gc.Config, "PROJECT_NAME", "proj")
    monkeypatch.setattr(gc.Config, "PROJECT_LOCATION", "loc")

    with pytest.raises(RuntimeError, match="auth failed"):
        gc.initialize_gemini_model()
