import sys
import os
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock, call

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))


class TestGCPBucketPersisterInit:

    @patch.dict(os.environ, {"bucket_name": "my-bucket", "project_name": "proj", "project_location": "us-central1"})
    @patch("google.cloud.storage.Client")
    @patch("google.auth.default", return_value=(MagicMock(), "project-id"))
    def test_init_success(self, mock_auth, mock_storage_client):
        from persister.gcp_bucket_persister import GCPBucketPersister
        persister = GCPBucketPersister()

        assert persister.bucket_name == "my-bucket"
        assert persister.bucket_project == "proj"
        assert persister.bucket_location == "us-central1"
        mock_auth.assert_called_once()
        # storage.Client is called with both project and credentials
        mock_storage_client.assert_called_once()
        call_kwargs = mock_storage_client.call_args
        assert call_kwargs.kwargs.get("project") == "proj" or call_kwargs[1].get("project") == "proj"

    @patch.dict(os.environ, {"bucket_name": "", "project_name": "", "project_location": ""})
    @patch("google.auth.default", return_value=(MagicMock(), "project-id"))
    def test_init_raises_when_bucket_name_empty(self, mock_auth):
        from persister.gcp_bucket_persister import GCPBucketPersister
        with pytest.raises(ValueError, match="bucket_name is required"):
            GCPBucketPersister()


class TestUploadFolderToBucket:

    @patch.dict(os.environ, {"bucket_name": "my-bucket", "project_name": "proj", "project_location": "us"})
    @patch("google.cloud.storage.Client")
    @patch("google.auth.default", return_value=(MagicMock(), "project-id"))
    def test_upload_folder(self, mock_auth, mock_storage_client, tmp_path):
        from persister.gcp_bucket_persister import GCPBucketPersister

        # Create temp files to simulate local folder
        (tmp_path / "subdir").mkdir()
        (tmp_path / "file1.json").write_text('{"a":1}')
        (tmp_path / "subdir" / "file2.json").write_text('{"b":2}')

        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_bucket.blob.return_value = mock_blob
        mock_storage_client.return_value.bucket.return_value = mock_bucket

        persister = GCPBucketPersister()
        result = persister.upload_folder_to_bucket(str(tmp_path), "prefix/path/")

        assert result == "gs://my-bucket/prefix/path"
        assert mock_bucket.blob.call_count == 2
        mock_blob.upload_from_filename.assert_called()

    @patch.dict(os.environ, {"bucket_name": "my-bucket", "project_name": "proj", "project_location": "us"})
    @patch("google.cloud.storage.Client")
    @patch("google.auth.default", return_value=(MagicMock(), "project-id"))
    def test_upload_empty_folder(self, mock_auth, mock_storage_client, tmp_path):
        from persister.gcp_bucket_persister import GCPBucketPersister

        mock_bucket = MagicMock()
        mock_storage_client.return_value.bucket.return_value = mock_bucket

        persister = GCPBucketPersister()
        result = persister.upload_folder_to_bucket(str(tmp_path), "empty/")

        assert result == "gs://my-bucket/empty"
        mock_bucket.blob.assert_not_called()


class TestCurrentlyLocal:

    @patch.dict(os.environ, {"LOCAL_BUCKET_ROOT": ""})
    def test_copies_files_to_local_bucket(self, tmp_path):
        from persister.gcp_bucket_persister import currently_local

        # Create source folder with files
        source = tmp_path / "source"
        source.mkdir()
        (source / "a.json").write_text("data_a")
        (source / "sub").mkdir()
        (source / "sub" / "b.json").write_text("data_b")

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(tmp_path / "output") if k == "LOCAL_BUCKET_ROOT" else d):
            result = currently_local(str(source), "dest_prefix")

        dest = tmp_path / "output" / "dest_prefix"
        assert Path(result) == dest
        assert (dest / "a.json").read_text() == "data_a"
        assert (dest / "sub" / "b.json").read_text() == "data_b"

    @patch.dict(os.environ, {"LOCAL_BUCKET_ROOT": ""})
    def test_empty_source_folder(self, tmp_path):
        from persister.gcp_bucket_persister import currently_local

        source = tmp_path / "empty_source"
        source.mkdir()

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(tmp_path / "output") if k == "LOCAL_BUCKET_ROOT" else d):
            result = currently_local(str(source), "prefix")

        assert Path(result).exists()

    @patch.dict(os.environ, {}, clear=True)
    def test_defaults_local_bucket_root_to_src_main(self, tmp_path):
        from persister.gcp_bucket_persister import DEFAULT_LOCAL_BUCKET_ROOT, _local_bucket_root

        assert _local_bucket_root() == DEFAULT_LOCAL_BUCKET_ROOT


class TestSaveFolderToDestination:

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": "true"})
    @patch("persister.gcp_bucket_persister.currently_local", return_value="/local/path")
    def test_uses_local_mode_when_env_true(self, mock_local):
        from persister.gcp_bucket_persister import save_folder_to_destination

        result = save_folder_to_destination("/src/folder", "prefix")

        mock_local.assert_called_once_with("/src/folder", "prefix")
        assert result == "/local/path"

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": "1"})
    @patch("persister.gcp_bucket_persister.currently_local", return_value="/local/path")
    def test_uses_local_mode_when_env_1(self, mock_local):
        from persister.gcp_bucket_persister import save_folder_to_destination

        result = save_folder_to_destination("/src/folder", "prefix")
        mock_local.assert_called_once()

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": "false", "bucket_name": "bkt", "project_name": "p", "project_location": "l"})
    @patch("google.cloud.storage.Client")
    @patch("google.auth.default", return_value=(MagicMock(), "pid"))
    def test_uses_gcp_when_local_mode_false(self, mock_auth, mock_storage_client, tmp_path):
        from persister.gcp_bucket_persister import save_folder_to_destination

        source = tmp_path / "src"
        source.mkdir()
        (source / "f.json").write_text("{}")

        mock_bucket = MagicMock()
        mock_storage_client.return_value.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = MagicMock()

        result = save_folder_to_destination(str(source), "pfx")

        assert result.startswith("gs://bkt/")

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": ""})
    @patch("persister.gcp_bucket_persister.GCPBucketPersister")
    def test_uses_gcp_when_local_mode_empty(self, mock_persister_cls):
        from persister.gcp_bucket_persister import save_folder_to_destination

        mock_instance = MagicMock()
        mock_instance.upload_folder_to_bucket.return_value = "gs://bucket/pfx"
        mock_persister_cls.return_value = mock_instance

        result = save_folder_to_destination("/folder", "pfx")

        mock_instance.upload_folder_to_bucket.assert_called_once_with("/folder", "pfx")
        assert result == "gs://bucket/pfx"


class TestDeletePrefix:

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": "true"})
    def test_local_mode_removes_folder_contents(self, tmp_path):
        from persister.gcp_bucket_persister import delete_prefix

        target = tmp_path / "plan" / "policy" / "relevant_policy"
        target.mkdir(parents=True)
        (target / "policy1.json").write_text("{}")
        keep = tmp_path / "plan" / "policy" / "relevant_policy.json"
        keep.write_text("{}")

        with patch.dict(os.environ, {"LOCAL_BUCKET_ROOT": str(tmp_path)}):
            assert delete_prefix("plan/policy/relevant_policy") == 1
            assert delete_prefix("plan/policy/relevant_policy") == 0

        assert not target.exists()
        assert keep.exists()

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": ""})
    @patch("persister.gcp_bucket_persister.GCPBucketPersister")
    def test_gcs_mode_deletes_all_blobs_under_prefix(self, mock_persister_cls):
        from persister.gcp_bucket_persister import delete_prefix

        blobs = [MagicMock(), MagicMock()]
        instance = mock_persister_cls.return_value
        instance.bucket_name = "bkt"
        instance.storage_client.list_blobs.return_value = blobs

        assert delete_prefix("plan/policy/relevant_kod") == 2

        instance.storage_client.list_blobs.assert_called_once_with("bkt", prefix="plan/policy/relevant_kod/")
        for blob in blobs:
            blob.delete.assert_called_once()


class TestLocalReadHelpers:

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": "true"})
    def test_json_exists_in_gcs_uses_local_mirror(self, tmp_path):
        from persister.gcp_bucket_persister import json_exists_in_gcs

        target = tmp_path / "dbaware_review_20090" / "inbound-data" / "policy" / "policy" / "relevant_data.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("{}")

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(tmp_path) if k == "LOCAL_BUCKET_ROOT" else os.environ.get(k, d)):
            assert json_exists_in_gcs("gs://bucket/dbaware_review_20090/inbound-data/policy/policy/relevant_data.json") is True
            assert json_exists_in_gcs("gs://bucket/dbaware_review_20090/inbound-data/policy/kod/missing.json") is False

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": "true"})
    def test_list_json_blobs_in_gcs_reads_direct_children_only(self, tmp_path):
        from persister.gcp_bucket_persister import list_json_blobs_in_gcs

        folder = tmp_path / "dbaware_review_20090" / "inbound-data" / "policy"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "rag_request_payload.json").write_text("{}")
        (folder / "rag_relevant_data.json").write_text("{}")
        nested = folder / "policy"
        nested.mkdir()
        (nested / "relevant_data.json").write_text("{}")

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(tmp_path) if k == "LOCAL_BUCKET_ROOT" else os.environ.get(k, d)):
            result = list_json_blobs_in_gcs("gs://bucket/dbaware_review_20090/inbound-data/policy")

        assert result == [
            "gs://bucket/dbaware_review_20090/inbound-data/policy/rag_relevant_data.json",
            "gs://bucket/dbaware_review_20090/inbound-data/policy/rag_request_payload.json",
        ]

    @patch.dict(os.environ, {"LOCAL_BUCKET_MODE": "true"})
    def test_gcs_prefix_exists_uses_local_mirror(self, tmp_path):
        from persister.gcp_bucket_persister import gcs_prefix_exists

        folder = tmp_path / "dbaware_review_20090" / "inbound-data" / "policy" / "kod"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "relevant_data.json").write_text("{}")

        with patch("persister.gcp_bucket_persister.os.getenv", side_effect=lambda k, d="": str(tmp_path) if k == "LOCAL_BUCKET_ROOT" else os.environ.get(k, d)):
            assert gcs_prefix_exists("gs://bucket/dbaware_review_20090/inbound-data/policy") is True
            assert gcs_prefix_exists("gs://bucket/dbaware_review_20090/inbound-data/missing") is False

