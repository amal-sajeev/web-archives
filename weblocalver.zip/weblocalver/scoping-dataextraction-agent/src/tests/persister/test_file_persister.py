import sys
import json
import os
from pathlib import Path
from unittest.mock import patch, mock_open, MagicMock

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from persister.file_persister import  build_plan_storage_paths, save_json_to_file


class TestBuildPlanStoragePaths:

    def test_with_dict_current_data(self):
        data = {"Plan Item Number": "100", "Plan Item Title": "My Plan"}
        folder, key = build_plan_storage_paths("100", data)
        assert folder == "dbaware_review_100"
        assert key == "dbaware_review_100/inbound-data"

    def test_with_list_current_data(self):
        data = [{"Plan Item Number": "200", "Plan Item Title": "Test/Plan"}]
        folder, key = build_plan_storage_paths("200", data)
        assert folder == "dbaware_review_200"
        assert key == "dbaware_review_200/inbound-data"

    def test_with_empty_list_falls_back(self):
        folder, key = build_plan_storage_paths("300", [])
        assert folder == "dbaware_review_300"
        assert key == "dbaware_review_300/inbound-data"

    def test_with_none_falls_back(self):
        folder, key = build_plan_storage_paths("400", None)
        assert folder == "dbaware_review_400"
        assert key == "dbaware_review_400/inbound-data"

    def test_missing_title_uses_fallback(self):
        data = {"Plan Item Number": "500"}
        folder, key = build_plan_storage_paths("500", data)
        assert folder == "dbaware_review_500"

    def test_uses_plan_number_param_when_key_missing(self):
        data = {"Plan Item Title": "Some Title"}
        folder, _ = build_plan_storage_paths("600", data)
        assert folder == "dbaware_review_600"


class TestSaveJsonToFile:

    @patch("persister.file_persister.os.makedirs")
    @patch("builtins.open", new_callable=mock_open)
    def test_save_dict_data(self, mock_file, mock_makedirs):
        data = {"key": "value"}
        result = save_json_to_file(data, "plan_1", "output.json", base_dir="/tmp/test")

        actual_dir = mock_makedirs.call_args.args[0]
        assert os.path.normpath(actual_dir) == os.path.normpath("/tmp/test/plan_1")
        assert mock_makedirs.call_args.kwargs == {"exist_ok": True}

        actual_file = mock_file.call_args.args[0]
        assert os.path.normpath(actual_file) == os.path.normpath("/tmp/test/plan_1/output.json")
        assert mock_file.call_args.args[1:] == ("w",)
        assert mock_file.call_args.kwargs == {"encoding": "utf-8"}
        written = "".join(call.args[0] for call in mock_file().write.call_args_list)
        assert json.loads(written) == data
        assert os.path.normpath(result) == os.path.normpath("/tmp/test/plan_1/output.json")

    @patch("persister.file_persister.os.makedirs")
    @patch("builtins.open", new_callable=mock_open)
    def test_save_with_source_folder(self, mock_file, mock_makedirs):
        data = [{"a": 1}]
        result = save_json_to_file(data, "plan_2", "data.json", source_folder="dbaware", base_dir="/tmp/test")

        actual_dir = mock_makedirs.call_args.args[0]
        assert os.path.normpath(actual_dir) == os.path.normpath("/tmp/test/plan_2/dbaware")
        assert mock_makedirs.call_args.kwargs == {"exist_ok": True}
        assert os.path.normpath(result) == os.path.normpath("/tmp/test/plan_2/dbaware/data.json")

    @patch("persister.file_persister.os.makedirs")
    @patch("builtins.open", new_callable=mock_open)
    def test_save_uses_settings_data_dir_when_no_base_dir(self, mock_file, mock_makedirs):
        with patch("persister.file_persister.settings.DATA_DIR_", Path("/default/data")):
            save_json_to_file({"x": 1}, "plan_3", "f.json")

        expected_dir = "/default/data/plan_3"
        actual_dir = mock_makedirs.call_args.args[0]
        assert os.path.normpath(actual_dir) == os.path.normpath(expected_dir)
        assert mock_makedirs.call_args.kwargs == {"exist_ok": True}

    @patch("persister.file_persister.os.makedirs", side_effect=OSError("disk full"))
    def test_save_raises_on_makedirs_failure(self, mock_makedirs):
        with pytest.raises(OSError, match="disk full"):
            save_json_to_file({"x": 1}, "plan_4", "f.json", base_dir="/tmp/test")

    @patch("persister.file_persister.os.makedirs")
    @patch("builtins.open", side_effect=IOError("permission denied"))
    def test_save_raises_on_write_failure(self, mock_file, mock_makedirs):
        with pytest.raises(IOError, match="permission denied"):
            save_json_to_file({"x": 1}, "plan_5", "f.json", base_dir="/tmp/test")
