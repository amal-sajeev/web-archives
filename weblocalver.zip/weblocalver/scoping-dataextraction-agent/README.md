# Scoping Data Extraction Agent

FastAPI service (root path `/scoping-dataextraction-agent`, default port `4002`) that orchestrates asynchronous extraction of scoping data from multiple backend sources (GFMS, DBaware, DBGRC databases, LRR enrichment, internet search) for a given plan, tracks extraction session progress, and stores resulting artifacts in cloud storage.

## Endpoints

| Method | Path                                   | Description                                                                             |
| ------ | -------------------------------------- | --------------------------------------------------------------------------------------- |
| GET    | `/health`                              | Health check                                                                            |
| POST   | `/data-extraction`                     | Trigger asynchronous data extraction pipeline for a plan (202 Accepted with session ID) |
| GET    | `/data-extraction/{session_id}/status` | Get status of an extraction session                                                     |
| GET    | `/getdata/{plan_number}/availability`  | Report artifacts are available for a plan                               |
| GET    | `/getdata/{plan_number}/{artifact}`    | Retrieve a specific stored extraction artifact                                          |

## Configuration

App settings live in `src/main/config/settings.py`.

## Running locally

```bash
pip install -r requirements.txt
python src/main/app.py
```

## Docker / Helm

Build via the provided `Dockerfile`; deploy with the Helm chart in `helm-chart/` (`values-dev1.yaml`, `values-ct1.yaml`, `values-uat1.yaml`).
