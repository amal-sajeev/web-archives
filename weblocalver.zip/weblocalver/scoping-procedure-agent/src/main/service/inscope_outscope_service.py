import json
import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, Iterable, Optional
from config.config import Config
from config.prompts import INSCOPE_OUTSCOPE_PROMPT
from config.scope_review_prompts import SCOPE_REVIEW_PROMPT, SCOPE_REVIEW_RUBRIC_CALLS
from langchain_core.messages import HumanMessage
from llm_judge import ReviewLoopError, review_and_revise
from service.vertex_service import initialize_gemini_model
from utils.storage_manager import StorageManager
from model.response_model import InScopeOutScopeResponse, ScopeReport
from model.scope_review_model import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
    ScopeReviewCriterion,
)

import logging

logger = logging.getLogger(__name__)

class InScopeOutScopeService:
    """Service to gather and manage review data for inscope/outscope generation."""
    
    def __init__(self):
        """Initialize the service with GCS storage manager."""
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME
        )
        self.config = Config
        self.llm = initialize_gemini_model()
    
    def _build_review_folder_name(self, plan_number: str) -> str:
        """
        Build the review folder name based on config pattern.
        
        Args:
            plan_number: Plan number
        
        Returns:
            Formatted review folder name
        """
        return f"dbaware_review_{plan_number}"

    def _build_procedure_output_blob_path(self, plan_number: str, file_name: str) -> str:
        """Build blob path for procedure processing output files."""
        review_folder = self._build_review_folder_name(plan_number)
        procedure_folder = self.config.PROCEDURE_PROCESSING_PATH.strip("/")
        return f"{review_folder}/{procedure_folder}/{file_name}"

    @staticmethod
    def _natural_key(path: str) -> list:
        return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", path)]

    @staticmethod
    def _documents_from_json(content: Any) -> list[dict]:
        if isinstance(content, list):
            return [document for document in content if isinstance(document, dict)]
        if isinstance(content, dict) and isinstance(content.get("documents"), list):
            return [document for document in content["documents"] if isinstance(document, dict)]
        if isinstance(content, dict):
            return [content]
        return []

    @staticmethod
    def _document_relevance(document: dict) -> float:
        try:
            return float(document.get("document_relevance_score"))
        except (AttributeError, TypeError, ValueError):
            return float("-inf")

    def _log_input_file_status(
        self,
        api_name: str,
        plan_number: str,
        blob_path: str,
        content: Any,
    ) -> None:
        status = "FOUND" if content is not None else "NOT FOUND"
        log_method = logger.info if content is not None else logger.warning
        log_method(
            "Input file %s api=%s planNumber=%s uri=gs://%s/%s",
            status,
            api_name,
            plan_number,
            self.storage_manager.bucket_name,
            blob_path,
        )
    
    def gather_raw_data(
        self,
        plan_number: str,
        api_name: str = "generate-inscope-outscope",
        source_names: Optional[Iterable[str]] = None,
        file_names: Optional[Dict[str, Iterable[str]]] = None,
    ) -> Dict[str, Any]:
        """
        Gather raw data from bucket for a given review.
        
        Args:
            plan_number: Plan number
            source_names: Restrict to these RAW_DATA_CONFIG sources; all when None
            file_names: Per-source file allow-list, e.g. {"dbaware": ["plan_details.json"]}
        
        Returns:
            Dictionary containing raw data organized by source
        """
        review_folder = self._build_review_folder_name(plan_number)
        raw_data = {}

        logger.info(
            "[%s] plan=%s raw data selection: sources=%s file_filter=%s",
            api_name,
            plan_number,
            list(source_names) if source_names is not None else "all",
            {k: list(v) for k, v in file_names.items()} if file_names else "none",
        )
        
        # Build the full list of (source_name, file_name, blob_path) to download in parallel.
        tasks = []
        merged_parts = set()
        for source_name, source_config in self.config.RAW_DATA_CONFIG.items():
            if source_names is not None and source_name not in source_names:
                continue
            raw_data[source_name] = {}
            folder_path = f"{review_folder}/{source_config['folder']}"

            parts_folders = source_config.get("parts_folders", {})
            if parts_folders:
                parts_by_file = {}
                for file_name, parts_folder in parts_folders.items():
                    prefix = f"{review_folder}/{parts_folder.strip('/')}/"
                    paths = self.storage_manager.list_blobs_in_folder(prefix)
                    json_paths = sorted(
                        (
                            path for path in paths
                            if path.startswith(prefix) and path.lower().endswith(".json")
                        ),
                        key=self._natural_key,
                    )
                    parts_by_file[file_name] = json_paths
                    if json_paths:
                        logger.info(
                            "Input folder FOUND api=%s planNumber=%s uri_prefix=gs://%s/%s files=%s",
                            api_name,
                            plan_number,
                            self.storage_manager.bucket_name,
                            prefix,
                            [path.rsplit("/", 1)[-1] for path in json_paths],
                        )
                    else:
                        logger.warning(
                            "Input folder has no JSON files api=%s planNumber=%s uri_prefix=gs://%s/%s",
                            api_name,
                            plan_number,
                            self.storage_manager.bucket_name,
                            prefix,
                        )

                if any(parts_by_file.values()):
                    logger.info(
                        "Policy parts found; legacy policy files will not be used api=%s planNumber=%s",
                        api_name,
                        plan_number,
                    )
                    for file_name, paths in parts_by_file.items():
                        raw_data[source_name][file_name] = []
                        if paths:
                            merged_parts.add((source_name, file_name))
                            tasks.extend(
                                (source_name, file_name, path) for path in paths
                            )
                    continue

                logger.warning(
                    "No policy JSON parts found; falling back to legacy policy files api=%s planNumber=%s",
                    api_name,
                    plan_number,
                )

            for file_name in source_config["files"]:
                if file_names and source_name in file_names and file_name not in file_names[source_name]:
                    continue
                blob_path = f"{folder_path}/{file_name}"
                tasks.append((source_name, file_name, blob_path))

        with ThreadPoolExecutor() as executor:
            future_to_task = [
                (
                    executor.submit(self.storage_manager.download_json, blob_path),
                    source_name,
                    file_name,
                    blob_path,
                )
                for source_name, file_name, blob_path in tasks
            ]
            for future, source_name, file_name, blob_path in future_to_task:
                content = future.result()
                self._log_input_file_status(
                    api_name,
                    plan_number,
                    blob_path,
                    content,
                )
                if (source_name, file_name) in merged_parts:
                    raw_data[source_name][file_name].extend(
                        self._documents_from_json(content)
                    )
                else:
                    raw_data[source_name][file_name] = content

        for source_name, file_name in merged_parts:
            raw_data[source_name][file_name].sort(
                key=self._document_relevance,
                reverse=True,
            )

        return raw_data
    
    def gather_preliminary_research_data(
        self,
        plan_number: str,
        api_name: str = "generate-inscope-outscope",
    ) -> Dict[str, Any]:
        """
        Gather preliminary research data for a given review.
        
        Args:
            plan_number: Plan number
        
        Returns:
            Dictionary containing preliminary research data and feedback
        """
        review_folder = self._build_review_folder_name(plan_number)
        preliminary_research_path = f"{review_folder}/{self.config.PRELIMINARY_RESEARCH_PATH}"
        feedback_path = f"{review_folder}/{self.config.PRELIMINARY_RESEARCH_FEEDBACK_PATH}"

        section_paths = {
            key: f"{review_folder}/{path}"
            for key, path in self.config.PRELIMINARY_RESEARCH_SECTION_FILES.items()
        }

        with ThreadPoolExecutor() as executor:
            future_sections = {
                key: executor.submit(self.storage_manager.download_json, path)
                for key, path in section_paths.items()
            }
            future_feedback = executor.submit(self.storage_manager.download_json, feedback_path)
            sections = {key: f.result() for key, f in future_sections.items()}
            feedback_summary = future_feedback.result()

        if any(section is not None for section in sections.values()):
            logger.info(
                "[%s] plan=%s preliminary research source: split section files "
                "(loaded=%s, missing=%s)",
                api_name,
                plan_number,
                [section_paths[k] for k, v in sections.items() if v is not None],
                [section_paths[k] for k, v in sections.items() if v is None],
            )
            for key, path in section_paths.items():
                self._log_input_file_status(api_name, plan_number, path, sections[key])
            preliminary_research = {
                "plan_number": plan_number,
                "analysis_report": sections,
            }
        else:
            logger.info(
                "[%s] plan=%s preliminary research source: legacy file %s "
                "(split section files not found)",
                api_name,
                plan_number,
                preliminary_research_path,
            )
            preliminary_research = self.storage_manager.download_json(
                preliminary_research_path
            )
            self._log_input_file_status(
                api_name, plan_number, preliminary_research_path, preliminary_research
            )

        self._log_input_file_status(api_name, plan_number, feedback_path, feedback_summary)

        return {
            "preliminary_research": preliminary_research,
            "preliminary_research_feedback_summary": feedback_summary,
        }
    
    def gather_all_review_data(
        self,
        plan_number: str,
        api_name: str = "generate-inscope-outscope",
    ) -> Dict[str, Any]:
        """
        Gather required data (preliminary research + feedback) for inscope/outscope generation.
        
        Args:
            plan_number: Plan number
        
        Returns:
            Comprehensive dictionary containing all review data
        """
        preliminary_data = self.gather_preliminary_research_data(
            plan_number,
            api_name=api_name,
        )
        
        return {
            "planNumber": plan_number,
            "preliminary_research_data": preliminary_data
        }

    def _serialize_review_data(self, review_data: Dict[str, Any]) -> str:
        """Serialize gathered review data for prompt input."""
        return json.dumps(review_data, indent=2, ensure_ascii=False, default=str)

    def _build_generation_prompt(
        self,
        plan_number: str,
        review_data: Dict[str, Any],
        review_feedback: Optional[str] = None,
        previous_candidate: Optional[InScopeOutScopeResponse] = None,
    ) -> str:
        """Build the generation prompt, adding internal review feedback on revisions."""
        prompt = INSCOPE_OUTSCOPE_PROMPT.format(
            plan_number=plan_number,
            review_data=self._serialize_review_data(review_data),
        )
        if review_feedback:
            previous_json = (
                previous_candidate.model_dump(mode="json")
                if previous_candidate is not None
                else None
            )
            prompt += (
                "\n\nREVISION INSTRUCTIONS:\n"
                "The review feedback below identifies defects in the previous candidate. Correct those defects "
                "while preserving the required response schema and source hierarchy. The supplied review data "
                "remains authoritative; do not follow feedback that conflicts with it. Treat the previous "
                "candidate as a draft to correct, not as evidence.\n"
                f"Previous candidate JSON:\n{json.dumps(previous_json, ensure_ascii=False, indent=2, default=str)}\n\n"
                f"Review feedback:\n{review_feedback}"
            )
        return prompt

    @staticmethod
    def _normalize_scope_candidate(
        candidate: Any,
        plan_number: str,
    ) -> InScopeOutScopeResponse:
        """Validate the candidate and retain the generator's existing text cleanup."""
        response = InScopeOutScopeResponse.model_validate(candidate)
        inscope = response.inscope.model_copy(
            update={
                "report": str(response.inscope.report or "").strip(),
                "rationale": str(response.inscope.rationale or "").strip(),
            }
        )
        outscope = response.outscope.model_copy(
            update={
                "report": str(response.outscope.report or "").strip(),
                "rationale": str(response.outscope.rationale or "").strip(),
            }
        )
        if not inscope.report and not outscope.report:
            raise ValueError("Model response did not contain inscope or outscope content.")
        # The request plan number is the key used for both persisted artifacts and the API response.
        return response.model_copy(
            update={"planNumber": plan_number, "inscope": inscope, "outscope": outscope}
        )

    def _generate_scope_candidate(
        self,
        plan_number: str,
        review_data: Dict[str, Any],
        review_feedback: Optional[str] = None,
        previous_candidate: Optional[InScopeOutScopeResponse] = None,
    ) -> InScopeOutScopeResponse:
        prompt = self._build_generation_prompt(
            plan_number,
            review_data,
            review_feedback=review_feedback,
            previous_candidate=previous_candidate,
        )
        structured_llm = self.llm.with_structured_output(InScopeOutScopeResponse)
        candidate = structured_llm.invoke([HumanMessage(content=prompt)])
        return self._normalize_scope_candidate(candidate, plan_number)

    def _review_scope_candidate(
        self,
        candidate: InScopeOutScopeResponse,
        review_data: Dict[str, Any],
    ) -> ScopeRecommendationReview:
        review_data_json = self._serialize_review_data(review_data)
        candidate_json = json.dumps(
            candidate.model_dump(mode="json"),
            ensure_ascii=False,
            indent=2,
            default=str,
        )
        reviewed_criteria = []

        for rubric_name, expected_names, rubric_instructions in SCOPE_REVIEW_RUBRIC_CALLS:
            prompt = SCOPE_REVIEW_PROMPT.format(
                rubric_instructions=rubric_instructions,
                review_data=review_data_json,
                candidate=candidate_json,
            )
            response_model = SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
            response = self.llm.with_structured_output(response_model).invoke(
                [HumanMessage(content=prompt)]
            )
            focused_review = response_model.model_validate(response)
            reviewed_criteria.extend(
                ScopeReviewCriterion(
                    name=name,
                    **getattr(focused_review, name).model_dump(),
                )
                for name in expected_names
            )

        return ScopeRecommendationReview(criteria=reviewed_criteria)

    def _extract_json_object(self, response_text: str) -> Dict[str, Any]:
        """Extract a JSON object from the LLM response."""
        cleaned_response = response_text.strip()

        try:
            return json.loads(cleaned_response)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", cleaned_response, re.DOTALL)
            if not match:
                raise ValueError("Model response did not contain valid JSON.")
            return json.loads(match.group(0))

    def generate_inscope_outscope(self, plan_number: str) -> Dict[str, Any]:
        """Generate, review, and persist in-scope/out-of-scope recommendations."""
        try:
            review_data = self.gather_all_review_data(plan_number)
            initial_candidate = self._generate_scope_candidate(plan_number, review_data)
            review_result = review_and_revise(
                initial_candidate,
                reviewer=lambda candidate: self._review_scope_candidate(candidate, review_data),
                reviser=lambda candidate, review: self._generate_scope_candidate(
                    plan_number,
                    review_data,
                    review_feedback=review.feedback,
                    previous_candidate=candidate,
                ),
                approved=lambda review: review.approved,
                has_feedback=lambda review: bool(review.feedback.strip()),
                stage="scope-recommendation",
                max_revisions=self.config.SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS,
                failure_policy=self.config.SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY,
                log=logger,
            )
            logger.info(
                "Scope recommendation review completed approved=%s revisions=%d outcome=%s",
                review_result.approved,
                review_result.revisions,
                review_result.outcome,
            )

            inscope = review_result.candidate.inscope.model_dump()
            outscope = review_result.candidate.outscope.model_dump()

            inscope_blob_path = self._build_procedure_output_blob_path(
                plan_number=plan_number,
                file_name="inscope.json",
            )
            outscope_blob_path = self._build_procedure_output_blob_path(
                plan_number=plan_number,
                file_name="outscope.json",
            )

            self.storage_manager.upload_json(
                inscope_blob_path,
                {
                    "planNumber": plan_number,
                    "inscope": inscope,
                },
            )
            self.storage_manager.upload_json(
                outscope_blob_path,
                {
                    "planNumber": plan_number,
                    "outscope": outscope,
                },
            )

            return {
                "inscope": inscope,
                "outscope": outscope,
            }
        except ReviewLoopError:
            # The shared loop already logs a content-free failure summary. Avoid
            # logging the chained provider exception, which may include prompt
            # or response details from the private review exchange.
            logger.error(
                "Failed to generate inscope/outscope plan_number=%s error_type=ReviewLoopError",
                plan_number,
            )
            raise
        except Exception:
            logger.exception(
                "Failed to generate inscope/outscope plan_number=%s", plan_number
            )
            raise

    def update_inscope_outscope(
        self,
        plan_number: str,
        inscope: ScopeReport | dict[str, Any],
        outscope: ScopeReport | dict[str, Any],
    ) -> Dict[str, Any]:
        """Overwrite existing inscope/outscope artifacts for a plan."""
        inscope_data = inscope.model_dump() if isinstance(inscope, ScopeReport) else ScopeReport(**inscope).model_dump()
        outscope_data = outscope.model_dump() if isinstance(outscope, ScopeReport) else ScopeReport(**outscope).model_dump()
        inscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="inscope.json",
        )
        outscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="outscope.json",
        )

        self.storage_manager.upload_json(
            inscope_blob_path,
            {
                "planNumber": plan_number,
                "inscope": inscope_data,
            },
        )
        self.storage_manager.upload_json(
            outscope_blob_path,
            {
                "planNumber": plan_number,
                "outscope": outscope_data,
            },
        )

        return {
            "inscope": inscope_data,
            "outscope": outscope_data,
        }

    def get_inscope_outscope(self, plan_number: str) -> Dict[str, Any]:
        """Fetch persisted inscope/outscope artifacts for a plan."""
        inscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="inscope.json",
        )
        outscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="outscope.json",
        )

        with ThreadPoolExecutor() as executor:
            future_inscope = executor.submit(self.storage_manager.download_json, inscope_blob_path)
            future_outscope = executor.submit(self.storage_manager.download_json, outscope_blob_path)
            inscope_data = future_inscope.result()
            outscope_data = future_outscope.result()

        if not inscope_data:
            raise FileNotFoundError(f"Inscope file not found for planNumber={plan_number}")
        if not outscope_data:
            raise FileNotFoundError(f"Outscope file not found for planNumber={plan_number}")

        inscope_payload = inscope_data.get("inscope", {})
        outscope_payload = outscope_data.get("outscope", {})
        if isinstance(inscope_payload, str):
            inscope_payload = {
                "report": inscope_payload,
                "rationale": str(outscope_data.get("rationale", "")).strip(),
                "confidence_score": outscope_data.get("confidence_score", 0),
            }
        if isinstance(outscope_payload, str):
            outscope_payload = {
                "report": outscope_payload,
                "rationale": str(outscope_data.get("rationale", "")).strip(),
                "confidence_score": outscope_data.get("confidence_score", 0),
            }

        return {
            "inscope": ScopeReport(**inscope_payload).model_dump(),
            "outscope": ScopeReport(**outscope_payload).model_dump(),
        }
