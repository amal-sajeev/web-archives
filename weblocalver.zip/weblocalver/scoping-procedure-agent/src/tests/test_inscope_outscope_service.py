from pathlib import Path
import sys
import json
import logging
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.inscope_outscope_service import InScopeOutScopeService
from config.scope_review_prompts import SCOPE_REVIEW_RUBRIC_CALLS, SCOPE_REVIEW_PROMPT
from model.response_model import InScopeOutScopeResponse, ScopeReport
from model.scope_review_model import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
)
from llm_judge import ReviewLoopError


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


@pytest.fixture
def service_with_mocks():
    with patch("service.inscope_outscope_service.StorageManager") as storage_cls, patch(
        "service.inscope_outscope_service.initialize_gemini_model"
    ) as llm_initializer:
        storage_manager = MagicMock()
        llm = MagicMock()
        structured_llm = MagicMock()
        llm.with_structured_output.return_value = structured_llm

        storage_cls.return_value = storage_manager
        llm_initializer.return_value = llm

        service = InScopeOutScopeService()

    return service, storage_manager, structured_llm


def test_gather_raw_data_downloads_all_configured_files(service_with_mocks, monkeypatch):
    service, storage_manager, _ = service_with_mocks

    raw_data_config = {
        "dbaware": {"folder": "inbound-data/dbaware", "files": ["file1.json", "file2.json"]},
        "gfms": {"folder": "inbound-data/gfms", "files": ["file3.json"]},
    }
    monkeypatch.setattr(service.config, "RAW_DATA_CONFIG", raw_data_config)

    storage_manager.download_json.side_effect = [{"k": 1}, {"k": 2}, {"k": 3}]

    result = service.gather_raw_data("123")

    assert result == {
        "dbaware": {"file1.json": {"k": 1}, "file2.json": {"k": 2}},
        "gfms": {"file3.json": {"k": 3}},
    }

    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/dbaware/file1.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/dbaware/file2.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/gfms/file3.json"
    )


def test_gather_raw_data_logs_found_and_missing_files(
    service_with_mocks, monkeypatch, caplog
):
    service, storage_manager, _ = service_with_mocks
    storage_manager.bucket_name = "test-bucket"
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "dbaware": {
                "folder": "inbound-data/dbaware",
                "files": ["found.json", "missing.json"],
            }
        },
    )
    storage_manager.download_json.side_effect = [{"data": True}, None]

    with caplog.at_level(logging.INFO):
        service.gather_raw_data("123", api_name="generate-test-steps")

    assert (
        "Input file FOUND api=generate-test-steps planNumber=123 "
        "uri=gs://test-bucket/dbaware_review_123/inbound-data/dbaware/found.json"
    ) in caplog.text
    assert (
        "Input file NOT FOUND api=generate-test-steps planNumber=123 "
        "uri=gs://test-bucket/dbaware_review_123/inbound-data/dbaware/missing.json"
    ) in caplog.text


def test_gather_raw_data_uses_parts_and_leaves_missing_categories_empty(
    service_with_mocks, monkeypatch
):
    service, storage_manager, _ = service_with_mocks
    legacy_files = [
        "relevant_policy.json",
        "relevant_kod.json",
        "relevant_procedure.json",
    ]
    parts_folders = {
        "relevant_policy.json": "inbound-data/policy/relevant_policy",
        "relevant_kod.json": "inbound-data/policy/relevant_kod",
        "relevant_procedure.json": "inbound-data/policy/relevant_procedure",
    }
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "policy": {
                "folder": "inbound-data/policy",
                "files": legacy_files,
                "parts_folders": parts_folders,
            }
        },
    )
    storage_manager.list_blobs_in_folder.side_effect = [
        [
            "dbaware_review_123/inbound-data/policy/relevant_policy/policy2.json",
            "dbaware_review_123/inbound-data/policy/relevant_policy/policy1.json",
        ],
        [],
        [],
    ]
    storage_manager.download_json.side_effect = lambda path: {
        "dbaware_review_123/inbound-data/policy/relevant_policy/policy1.json": {
            "document_relevance_score": 0.2,
            "name": "policy1",
        },
        "dbaware_review_123/inbound-data/policy/relevant_policy/policy2.json": {
            "document_relevance_score": 0.9,
            "name": "policy2",
        },
    }[path]

    result = service.gather_raw_data("123")

    assert result == {
        "policy": {
            "relevant_policy.json": [
                {"document_relevance_score": 0.9, "name": "policy2"},
                {"document_relevance_score": 0.2, "name": "policy1"},
            ],
            "relevant_kod.json": [],
            "relevant_procedure.json": [],
        }
    }
    assert storage_manager.download_json.call_count == 2
    assert all(
        call.args[0].startswith("dbaware_review_123/inbound-data/policy/relevant_policy/")
        for call in storage_manager.download_json.call_args_list
    )


def test_gather_raw_data_falls_back_to_legacy_when_no_parts_exist(
    service_with_mocks, monkeypatch
):
    service, storage_manager, _ = service_with_mocks
    legacy_files = [
        "relevant_policy.json",
        "relevant_kod.json",
        "relevant_procedure.json",
    ]
    parts_folders = {
        "relevant_policy.json": "inbound-data/policy/relevant_policy",
        "relevant_kod.json": "inbound-data/policy/relevant_kod",
        "relevant_procedure.json": "inbound-data/policy/relevant_procedure",
    }
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "policy": {
                "folder": "inbound-data/policy",
                "files": legacy_files,
                "parts_folders": parts_folders,
            }
        },
    )
    storage_manager.list_blobs_in_folder.return_value = []
    storage_manager.download_json.side_effect = lambda path: {"path": path}

    result = service.gather_raw_data("123")

    assert result["policy"] == {
        file_name: {
            "path": f"dbaware_review_123/inbound-data/policy/{file_name}"
        }
        for file_name in legacy_files
    }
    assert storage_manager.download_json.call_count == 3
    assert storage_manager.list_blobs_in_folder.call_count == 3


def test_extract_json_object_handles_wrapped_json(service_with_mocks):
    service, _, _ = service_with_mocks

    wrapped_json = """Here is the response:\n```json\n{\"inscope\":\"In\",\"outscope\":\"Out\"}\n```"""

    parsed = service._extract_json_object(wrapped_json)

    assert parsed == {"inscope": "In", "outscope": "Out"}


def test_generate_inscope_outscope_uploads_expected_json(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    structured_llm.invoke.side_effect = [_scope_candidate(), *_passing_rubric_responses()]

    result = service.generate_inscope_outscope("42")

    assert result == {
        "inscope": {
            "report": "In paragraph",
            "rationale": "In-scope evidence supports testing.",
            "confidence_score": 90,
        },
        "outscope": {
            "report": "Out paragraph",
            "rationale": "Out-of-scope evidence supports exclusion.",
            "confidence_score": 80,
        },
    }

    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/inscope.json",
        {
            "planNumber": "42",
            "inscope": {
                "report": "In paragraph",
                "rationale": "In-scope evidence supports testing.",
                "confidence_score": 90,
            },
        },
    )
    assert result.keys() == {"inscope", "outscope"}
    assert structured_llm.invoke.call_count == 5
    assert [call.args[0] for call in service.llm.with_structured_output.call_args_list] == [
        InScopeOutScopeResponse,
        *[
            SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
            for rubric_name, _expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
        ],
    ]
    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/outscope.json",
        {
            "planNumber": "42",
            "outscope": {
                "report": "Out paragraph",
                "rationale": "Out-of-scope evidence supports exclusion.",
                "confidence_score": 80,
            },
        },
    )


def test_generate_inscope_outscope_raises_for_missing_content(service_with_mocks):
    service, _, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    structured_llm.invoke.return_value = InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(report="", rationale="", confidence_score=0),
        outscope=ScopeReport(report="", rationale="", confidence_score=0),
    )

    with pytest.raises(ValueError, match="did not contain inscope or outscope"):
        service.generate_inscope_outscope("42")


def test_review_critique_revises_candidate_and_reviews_revision_again(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(
        return_value={
            "preliminary_research": {"Broad Scope Direction": "PR Section 2 source"},
            "preliminary_research_feedback_summary": {"feedback": "C-202 should be included."},
        }
    )
    revised = _scope_candidate(
        inscope_report="Corrected in-scope attributes",
        outscope_report="Corrected out-of-scope attributes",
    )
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        revised,
        *_passing_rubric_responses(),
    ]

    result = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "Corrected in-scope attributes"
    assert result["outscope"]["report"] == "Corrected out-of-scope attributes"
    assert structured_llm.invoke.call_count == 10
    revision_prompt = _prompt_text(structured_llm.invoke.call_args_list[5])
    assert "REVISION INSTRUCTIONS" in revision_prompt
    assert "[scope_boundary_fidelity]" in revision_prompt
    assert "Control C-202 is absent" in revision_prompt
    assert "Previous candidate JSON" in revision_prompt
    assert storage_manager.upload_json.call_count == 2


def test_revision_limit_returns_and_persists_latest_valid_draft(service_with_mocks, monkeypatch, caplog):
    service, storage_manager, structured_llm = service_with_mocks
    caplog.set_level(logging.INFO)
    service.gather_all_review_data = MagicMock(return_value={"preliminary_research": "PR"})
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS", 1)
    revised = _scope_candidate(inscope_report="Latest revised in-scope draft")
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        revised,
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
    ]

    result = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "Latest revised in-scope draft"
    assert storage_manager.upload_json.call_count == 2
    assert "outcome=revision_limit" in caplog.text


@pytest.mark.parametrize(
    ("failure_policy", "raises", "expected_uploads"),
    [("fail_open", False, 2), ("fail_closed", True, 0)],
)
def test_judge_failure_policy_controls_whether_draft_is_persisted(
    service_with_mocks,
    monkeypatch,
    failure_policy,
    raises,
    expected_uploads,
):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value={"preliminary_research": "PR"})
    monkeypatch.setattr(
        service.config, "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY", failure_policy
    )
    structured_llm.invoke.side_effect = [_scope_candidate(), RuntimeError("judge unavailable")]

    if raises:
        with pytest.raises(ReviewLoopError, match="LLM review failed"):
            service.generate_inscope_outscope("42")
    else:
        result = service.generate_inscope_outscope("42")
        assert result["inscope"]["report"] == "In paragraph"

    assert storage_manager.upload_json.call_count == expected_uploads


@pytest.mark.parametrize(
    ("failure_policy", "raises", "expected_uploads"),
    [("fail_open", False, 2), ("fail_closed", True, 0)],
)
def test_revision_failure_policy_controls_whether_original_draft_is_persisted(
    service_with_mocks,
    monkeypatch,
    failure_policy,
    raises,
    expected_uploads,
):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value={"preliminary_research": "PR"})
    monkeypatch.setattr(
        service.config, "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY", failure_policy
    )
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        RuntimeError("revision unavailable"),
    ]

    if raises:
        with pytest.raises(ReviewLoopError, match="LLM revision failed"):
            service.generate_inscope_outscope("42")
    else:
        result = service.generate_inscope_outscope("42")
        assert result["inscope"]["report"] == "In paragraph"

    assert storage_manager.upload_json.call_count == expected_uploads


def test_missing_broad_scope_input_is_still_reviewed_and_generation_continues(
    service_with_mocks, monkeypatch
):
    service, storage_manager, structured_llm = service_with_mocks
    available_data = {"preliminary_research": None, "preliminary_research_feedback_summary": None}
    service.gather_all_review_data = MagicMock(return_value=available_data)
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS", 0)
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
    ]

    result = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "In paragraph"
    boundary_prompt = _prompt_text(structured_llm.invoke.call_args_list[1])
    assert "cannot be identified" in SCOPE_REVIEW_PROMPT
    assert '"preliminary_research": null' in boundary_prompt
    assert storage_manager.upload_json.call_count == 2


def test_review_model_aggregates_all_five_criteria_and_feedback_targets_fields():
    criteria = []
    for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS:
        if "scope_boundary_fidelity" in expected_names:
            criteria.extend(
                [
                    {
                        "name": "scope_boundary_fidelity",
                        "passed": False,
                        "affected_fields": ["inscope.report"],
                        "issue": "An item is missing.",
                        "action": "Restore the item from PR Section 2.",
                    },
                    {
                        "name": "required_content_format",
                        "passed": True,
                        "affected_fields": [],
                        "issue": "",
                        "action": "",
                    },
                ]
            )
        else:
            name = next(iter(expected_names))
            criteria.append(
                {
                    "name": name,
                    "passed": True,
                    "affected_fields": [],
                    "issue": "",
                    "action": "",
                }
            )

    review = ScopeRecommendationReview.model_validate({"criteria": criteria})

    assert review.approved is False
    assert "[scope_boundary_fidelity]" in review.feedback
    assert "inscope.report" in review.feedback
    assert len(review.criteria) == 5


def test_focused_review_schemas_require_each_requested_criterion():
    for rubric_name, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS:
        response_model = SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
        required_fields = set(response_model.model_json_schema().get("required", []))

        assert required_fields == set(expected_names)
        with pytest.raises(ValidationError):
            response_model.model_validate({})


def test_scope_judge_prompts_cover_boundary_hierarchy_conflicts_and_confidence():
    all_instructions = "\n".join(
        instructions for _name, _criteria, instructions in SCOPE_REVIEW_RUBRIC_CALLS
    )

    assert "Broad Scope Section 2" in all_instructions
    assert "must not add, remove, reclassify, or change a boundary" in all_instructions
    assert "When feedback explicitly differs from Section 2" in all_instructions
    assert "must not be flagged as an extra boundary" in all_instructions
    assert "never recommend using feedback to override PR Broad Scope Section 2" in all_instructions
    assert "confidence_score" in all_instructions
    assert "numeric review score" in SCOPE_REVIEW_PROMPT
    assert "exact plan, control, control-instance, risk, finding, review" in all_instructions
    assert "different instances on both sides" in all_instructions
    assert "bold label form (**Attribute:**)," in all_instructions
    assert "no introductory or closing prose" in all_instructions
    assert "no line breaks, bullets, or header" in all_instructions
    assert "retaining C-101 in scope passes this criterion" in all_instructions
    assert "a moderate score such as 60-79 may be consistent" in all_instructions


@pytest.mark.parametrize(
    (
        "rubric_index",
        "criterion_name",
        "affected_fields",
        "review_data",
        "candidate",
        "issue",
        "action",
    ),
    [
        (
            0,
            "scope_boundary_fidelity",
            ["inscope.report"],
            {"preliminary_research": {"Broad Scope Section 2": "In-scope: C-101"}},
            _scope_candidate(inscope_report="Control ID: C-102"),
            "C-101 is omitted from the in-scope report.",
            "Restore C-101 exactly as listed in Section 2.",
        ),
        (
            0,
            "scope_boundary_fidelity",
            ["outscope.report"],
            {"preliminary_research": {"Broad Scope Section 2": "Out of scope: C-101"}},
            _scope_candidate(outscope_report="Control ID: C-101; C-202"),
            "C-202 is not present in the out-of-scope list.",
            "Remove C-202 from the out-of-scope report.",
        ),
        (
            1,
            "evidence_identifier_accuracy",
            ["inscope.report"],
            {"preliminary_research": {"control": "C-101; instance 7; effective 2025-01-01; status Open"}},
            _scope_candidate(inscope_report="Control C-101, instance 8, effective 2025-02-01, status Closed"),
            "The instance, date, and status differ from the supplied record.",
            "Restore instance 7, effective date 2025-01-01, and status Open.",
        ),
        (
            2,
            "source_hierarchy_conflict_handling",
            ["inscope.report"],
            {
                "preliminary_research": {"Broad Scope Section 2": "C-101 is in scope"},
                "preliminary_research_feedback_summary": {"feedback": "C-101 is out of scope"},
            },
            _scope_candidate(inscope_report="C-101 is out of scope"),
            "Feedback conflicts with the authoritative PR boundary.",
            "Retain C-101 in scope and state the feedback discrepancy.",
        ),
        (
            2,
            "source_hierarchy_conflict_handling",
            ["inscope.report"],
            {
                "preliminary_research": {
                    "Broad Scope Section 2": "C-101 is in scope",
                    "Section 3": "C-202 is related",
                }
            },
            _scope_candidate(inscope_report="C-101 and C-202 are in scope"),
            "Secondary PR content adds C-202 to the boundary.",
            "Remove C-202 unless it is listed in Broad Scope Section 2.",
        ),
        (
            0,
            "required_content_format",
            ["inscope.report"],
            {"preliminary_research": {"Broad Scope Section 2": "In-scope: Control ID C-101; Control Name Payments"}},
            _scope_candidate(inscope_report="Control ID: C-101"),
            "The required Control Name attribute is missing.",
            "Add the Control Name value exactly as provided in Section 2.",
        ),
        (
            3,
            "rationale_confidence_alignment",
            ["inscope.rationale", "inscope.confidence_score"],
            {"preliminary_research": {"evidence_gaps": "No control-instance evidence or test status"}},
            _scope_candidate(),
            "The rationale is generic and confidence 90 ignores material evidence gaps.",
            "Explain the evidence supporting this decision and lower confidence to reflect the missing instance and status details.",
        ),
    ],
)
def test_synthetic_scope_regressions_keep_specific_feedback_targeted(
    service_with_mocks,
    rubric_index,
    criterion_name,
    affected_fields,
    review_data,
    candidate,
    issue,
    action,
):
    service, _, structured_llm = service_with_mocks
    responses = _passing_rubric_responses()
    if criterion_name not in responses[rubric_index]:
        pytest.fail(f"Criterion {criterion_name} is not in rubric {rubric_index}")
    responses[rubric_index][criterion_name].update(
        passed=False,
        affected_fields=affected_fields,
        issue=issue,
        action=action,
    )
    structured_llm.invoke.side_effect = responses

    review = service._review_scope_candidate(candidate, review_data)

    failed = next(item for item in review.criteria if item.name == criterion_name)
    assert failed.passed is False
    assert failed.affected_fields == affected_fields
    assert issue in review.feedback
    assert action in review.feedback
    reviewed_prompt = _prompt_text(structured_llm.invoke.call_args_list[rubric_index])
    assert json.dumps(review_data, ensure_ascii=False, indent=2, default=str) in reviewed_prompt
    assert json.dumps(candidate.model_dump(mode="json"), ensure_ascii=False, indent=2, default=str) in reviewed_prompt


def test_fail_closed_review_error_does_not_log_judge_exception_content(
    service_with_mocks, monkeypatch, caplog
):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value={"preliminary_research": "PR"})
    monkeypatch.setattr(
        service.config, "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY", "fail_closed"
    )
    private_error_detail = "private judge response detail"
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        RuntimeError(private_error_detail),
    ]

    with caplog.at_level(logging.ERROR), pytest.raises(ReviewLoopError):
        service.generate_inscope_outscope("42")

    assert private_error_detail not in caplog.text
    assert storage_manager.upload_json.call_count == 0
