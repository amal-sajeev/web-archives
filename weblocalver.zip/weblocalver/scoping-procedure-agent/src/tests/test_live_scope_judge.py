"""Opt-in Gemini calibration test for the real scope recommendation judge."""

import os
import sys
from pathlib import Path

import pytest
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[3]
load_dotenv(ROOT / ".misenv")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))
sys.path.insert(0, str(ROOT / "shared"))

RUN_LIVE_TESTS = (
    os.getenv("RUN_LIVE_SCOPE_JUDGE_TESTS", "").strip().lower() in {"1", "true", "yes"}
    and bool(os.getenv("GOOGLE_API_KEY"))
)


def _review_data():
    return {
        "planNumber": "42",
        "preliminary_research_data": {
            "preliminary_research": {
                "Broad Scope": {
                    "Section 2: Indicative Scope Boundaries": {
                        "In-scope": {
                            "Regulatory Requirement": "Annual Payment Oversight Review",
                            "Review Type": "Mandatory plan-year review",
                            "Review Period": "1 January 2025 - 31 December 2025",
                            "Jurisdiction & Legal Entity": "United States | Example Bank",
                            "Assessment Units": "Payments US",
                            "Risk Coverage": "R-17 - Wire Fraud",
                            "Key Control": (
                                "C-101 - Payment Approval; instance CI-101-US; AU Payments US; "
                                "risk R-17; monthly; effective 1 January 2025 - 31 December "
                                "2025; status Active."
                            ),
                        },
                        "Out of scope": {
                            "Key Control": (
                                "C-202 - Reconciliation; instance CI-202-EU; AU Corporate Ops EU; "
                                "risk R-90; monthly; effective 1 January 2025 - 31 December "
                                "2025; status Open; excluded due to open Group Audit finding "
                                "F-88 and ongoing remediation."
                            ),
                        },
                    },
                    "Section 3: Related Research": "C-999 is related context only.",
                }
            },
            "preliminary_research_feedback_summary": {
                "feedback": "Stakeholders say C-101 should be out of scope."
            },
        },
    }


def _candidate(*, corrected: bool):
    from model.response_model import InScopeOutScopeResponse, ScopeReport

    if corrected:
        inscope_report = (
            "**Regulatory Requirement:** Annual Payment Oversight Review\n\n"
            "**Review Type:** Mandatory plan-year review\n\n"
            "**Review Period:** 1 January 2025 - 31 December 2025\n\n"
            "**Jurisdiction & Legal Entity:** United States | Example Bank\n\n"
            "**Assessment Units:** Payments US\n\n"
            "**Risk Coverage:** R-17 - Wire Fraud\n\n"
            "**Key Control:**\n"
            "    1. C-101 - Payment Approval (PR Section 2 places C-101 in scope; stakeholder "
            "feedback says out of scope; retain the PR boundary pending confirmation)\n"
            "        **Control Instance ID:** CI-101-US\n"
            "        **Assessment Unit:** Payments US\n"
            "        **Risk Type:** R-17\n"
            "        **Control Frequency:** Monthly\n"
            "        **Effective Dates:** 1 January 2025 - 31 December 2025\n"
            "        **Status:** Active"
        )
        inscope_rationale = (
            "C-101 supports the documented R-17 Wire Fraud coverage for Payments US, and its "
            "CI-101-US instance is active during the review period. Stakeholder feedback "
            "conflicts with PR Section 2, so the PR boundary is retained pending confirmation."
        )
        inscope_confidence = 70
        outscope_report = (
            "**Key Control:**\n"
            "    1. C-202 - Reconciliation\n"
            "        **Control Instance ID:** CI-202-EU\n"
            "        **Assessment Unit:** Corporate Ops EU\n"
            "        **Risk Type:** R-90\n"
            "        **Control Frequency:** Monthly\n"
            "        **Effective Dates:** 1 January 2025 - 31 December 2025\n"
            "        **Status:** Open\n"
            "        **Exclusion Basis:** Open Group Audit finding F-88 and ongoing remediation"
        )
        outscope_rationale = (
            "C-202 is excluded because the PR identifies open Group Audit finding F-88 and "
            "ongoing remediation for its CI-202-EU instance. Those conditions support "
            "excluding this control during the review period."
        )
        outscope_confidence = 85
    else:
        inscope_report = (
            "**Assessment Units:** Global Payments\n\n"
            "**Risk Coverage:** R-71 - Card Fraud\n\n"
            "**Key Control:**\n"
            "    1. C-101 - Payment Approval\n"
            "        **Control Instance ID:** CI-101-EU\n"
            "        **Effective Dates:** 2 January 2025 - 31 December 2025\n"
            "        **Status:** Inactive\n"
            "    2. C-999 - Related processing control"
        )
        inscope_rationale = "Scope reflects current management priorities."
        inscope_confidence = 98
        outscope_report = "**Key Control:**\n    1. C-101 - Payment Approval"
        outscope_rationale = "These controls are not material to the review."
        outscope_confidence = 97

    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale=inscope_rationale,
            confidence_score=inscope_confidence,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale=outscope_rationale,
            confidence_score=outscope_confidence,
        ),
    )


@pytest.mark.skipif(
    not RUN_LIVE_TESTS,
    reason="set GOOGLE_API_KEY and RUN_LIVE_SCOPE_JUDGE_TESTS=1 to enable Gemini calls",
)
def test_gemini_scope_judge_rejects_bad_draft_and_approves_corrected_draft():
    from langchain_google_genai import ChatGoogleGenerativeAI
    from service.inscope_outscope_service import InScopeOutScopeService

    judge_model = ChatGoogleGenerativeAI(
        model=os.getenv("SCOPE_REVIEW_LIVE_MODEL", "gemini-3.6-flash"),
        google_api_key=os.environ["GOOGLE_API_KEY"],
        temperature=0,
        max_retries=3,
        timeout=60,
    )
    service = object.__new__(InScopeOutScopeService)
    service.llm = judge_model
    review_data = _review_data()

    try:
        bad_review = service._review_scope_candidate(_candidate(corrected=False), review_data)
        assert bad_review.approved is False, bad_review.feedback
        assert {
            "scope_boundary_fidelity",
            "required_content_format",
            "evidence_identifier_accuracy",
            "source_hierarchy_conflict_handling",
            "rationale_confidence_alignment",
        } == {criterion.name for criterion in bad_review.criteria if not criterion.passed}
        assert "C-999" in bad_review.feedback or "CI-101-EU" in bad_review.feedback

        corrected_review = service._review_scope_candidate(
            _candidate(corrected=True), review_data
        )
        assert corrected_review.approved is True, corrected_review.model_dump(mode="json")
        assert corrected_review.feedback == ""
    except Exception as exc:
        message = str(exc).lower()
        if "429" in message and any(
            marker in message for marker in ("quota", "resource_exhausted", "rate limit")
        ):
            pytest.skip("Gemini rate limit or quota exhausted; live calibration was not completed")
        if "503" in message and any(
            marker in message for marker in ("unavailable", "high demand", "service unavailable")
        ):
            pytest.skip("Gemini model temporarily unavailable; live calibration was not completed")
        raise
