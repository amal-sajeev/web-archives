# Brief: extract the trade-finance source data

You are extracting a bank's trade-finance sample data into structured JSON. The
data arrived as spreadsheets, screenshots pasted into spreadsheets, and two
screenshots of emails. Your output drives an application that reconciles customs
records against payment records and computes bank charges, so **a value read
into the wrong field is worse than a value left out**: the application will
compare it and report a discrepancy that does not exist, or bill a charge on a
figure nobody owes.

Work from the files alone. Do not assume a previous extraction was right — an
earlier pass got several of these wrong, and section 8 lists exactly how.

---

## 1. The business, in one page — read this before the files

An Indian importer buys goods abroad. Three things then exist, at three
different grains, and almost every mistake in this data comes from confusing
them.

### 1.1 The three levels

```
TF3 reference            ← payment is processed against this
  └── Bill of Entry      ← the customs record for one consignment
        └── invoice      ← one commercial invoice from the supplier
```

- **An invoice** is one commercial invoice: a number, a date, a currency and an
  amount. It is the smallest unit.
- **A Bill of Entry (BoE)** is the customs filing for one consignment arriving
  at one port on one date. It covers **one or more invoices**. In this data a
  BoE carries between 1 and 6 of them.
- **A TF3 reference** is the bank's collection reference. **Payment runs against
  it.** One TF3 covers **one or more Bills of Entry** — in this data, one or two.

So the worklist is indexed on the TF3, not on the Bill of Entry. A charge
summarised per TF3 may be built from figures levied at any of the three levels
(section 5).

### 1.2 What identifies what

| Level | Identified by | Unique on its own? |
|---|---|---|
| Invoice | invoice number | **No** — treat as unique only within its BoE |
| Consignment | **BoE number + importer** | BoE number alone: **No** |
| Collection | TF3 reference | Yes |

**The BoE number is not unique.** In this data one BoE number is used by two
different importers, with different dates and different ports. The written
procedure says roughly 10% of cases can carry a copied number, and names the
fields to disambiguate on: drawee name, member name, port of loading, port of
discharge.

**Therefore: the transaction key is BoE number *and* invoice number.** Any key,
count, grouping or join you build must be per *consignment* — BoE **and**
importer — never per bare number.

### 1.3 The systems

| System | What it is | What you get from it |
|---|---|---|
| **IDPMS** | Indian customs' import data processing system. The customs record. | `IDPMS file.xlsx`. One row per invoice line. Ports, parties, amounts, shipment details. |
| **TradePay** | The bank's payment portal, where the remittance is raised. | Screenshots embedded in Scenario 1 and 2. One row per invoice being paid. |
| **Autobahn / OEMS** | Where each client's pricing is held, as free-format text on a Products tab. | Screenshots embedded in Scenario 3. |
| **TF3** | The trade-finance system the validated data is posted to. | Nothing directly — it is the destination. |
| **WFMS** | Workflow system. Not supplied; referenced as the third fallback source. | Nothing. |
| **Volza** | Public port directory used to turn a port code into a full name. | Nothing; the rule for using it is in the procedure email. |

The application compares **TradePay against IDPMS**. That is the direction of
every consistency check, and it is why a value transcribed into the wrong system
is so damaging.

### 1.4 The vocabulary

- **Drawee / importer** — the Indian buyer. The bank's client.
- **Drawer / supplier** — the overseas seller being paid.
- **Remittance** — the payment. One remittance can cover several invoices, and
  **need not cover all the invoices on a Bill of Entry.** In this data three
  consignments have an invoice the remittance does not include: Rothe Erde's
  two bills, and Bosch Rexroth's 3079950, where invoice 60075467 for EUR 403
  is uncovered while 60075468 is paid. That is a finding, not an error, and
  the third one is easy to miss — the two Rothe Erde bills look like the
  pattern, and a single uncovered invoice on a two-invoice bill does not.
- **Deal** — an FX settlement booked to convert the rupees. Carries a rate, a
  currency, an amount, and a reference.

---

## 2. What you have been given

| File | What it is |
|---|---|
| `IDPMS file.xlsx` | The customs extract. One sheet, header row + **22 data rows × 51 columns**. One row per invoice line. |
| `Scenario 1.xlsx` | **5** FX deal rows, plus **10** embedded portal screenshots. |
| `Scenario 2.xlsx` | **3** deal rows, plus **6** embedded screenshots. |
| `Scenario 3.xlsx` | **3** client names, plus **3** embedded screenshots of the pricing tab. |
| `Forex Conversion.xlsx` | Rate card and charge calculators. **Five sheets, one hidden.** |
| `opera_U85EaD1tFo.png` | An email. **Specification. Read first.** |
| `opera_8ppKphuRC3.png` | A second email, the written procedure. **Specification. Read first.** |
| `20261001_190852.jpg` | Photo of a process-flow slide. Context only. |
| `trade_portal_reference_bundle/` | Produced independently of you: the 19 screenshots as PNGs, stitched per case, and `case_index.json` with cell references, row links and a join policy. A second opinion to reconcile against — **not truth**. |

The two `opera_*.png` files sit in the folder root, **outside** the reference
bundle. They are easy to overlook and they are the specification. The earlier
pass missed them for a long time and inferred rules that these emails state
outright.

---

## 3. What to produce

One JSON file per source. Every record carries its provenance.

### `idpms.json` — 22 records
All 51 columns, nothing dropped, corrected or reordered. Dates to ISO
`YYYY-MM-DD`, numbers as numbers. Add only derived keys, and derive them per
**consignment**:

- `recordId` — unique per invoice line, and disambiguated when a BoE number is
  shared by two importers
- `lineNo`, `linesForThisConsignment` — counted within BoE **+ importer**
- `boeNumberSharedWithAnotherImporter` — true when the *number* is reused

### `tradepay.json` — one record per portal row
One record per invoice row visible across the screenshots. Must carry
`billOfEntryNumber`, `invoiceNo`, and which capture it came from. Expected
fields include: BoE number and date, invoice number / date / currency / amount /
due date / outstanding, payment amount and date, adjustment, drawer name / city
/ country, TII reference, TF3 reference, TF3 received timestamp, goods
description, document type, port code, vendor code, debit account, status.

Not every capture shows every column — see 6.5.

### `deals.json` — one record per settlement row
`dealDate`, `branch`, `client`, `dealType`, `contractRef`, `rate`,
`baseCurrency`, `inrAmount`, `currency`, `amount`, `reference`, and which
scenario file it came from.

### `autobahn.json` — one record per client
The processing text **verbatim, including line breaks**. Do not normalise it;
the application parses it and a reader compares it against the parse.

### `fx.json`
The rate card, and the charge rules **read out of the workbook**, not typed from
the email. Carry any worked example the workbook contains so it can be asserted.

### `ports.json`
Every port code appearing in the data, with the rule for resolving it.

For any field you could not read: record it as **absent, with the reason**.
Never substitute a guess, and never silently omit a field you failed to read.

---

## 4. The joins, precisely

**4.1 TradePay row → IDPMS row.** Match on BoE number **and** invoice number.
Normalise punctuation and spacing for the comparison only (`INV260612999` in the
portal is `INV2606/12999` in IDPMS; `HAILU 202611044` is `HAILU202611044`). Keep
the raw values.

**4.2 Invoice not found under its own BoE.** Look for it under any other BoE
number before concluding there is no remittance. A remittance filed against the
wrong number is still that remittance, and it reads differently from one that
does not exist.

**4.3 IDPMS rows → consignment.** Group by BoE number **+ importer**.

**4.4 Consignment → TF3.** From the TradePay row's TF3 reference. A consignment
with no portal row has no TF3 from this route — see 4.5.

**4.5 The TF3 reference also appears on the deal blotter**, with a three-digit
prefix in front. Reconcile the two forms and report which is the reference and
what the prefix is (question 3 in section 7).

**4.6 Client → pricing.** By importer name against the Autobahn client name,
allowing for short forms. Note that the pricing set and the transaction set do
not fully overlap in either direction.

---

## 5. Charges, and the level each is levied at

A client's pricing text states a basis. The basis decides the level, and the
level decides how the figure is summed into the TF3 total:

| Basis in the text | Level | Behaviour |
|---|---|---|
| per document / per invoice | **invoice** | charged once per invoice |
| per transaction / per BoE | **transaction** | charged once per consignment |
| per remittance / flat | **TF3** | charged once for the whole collection |

Charges computed on the sum exchanged belong to the **TF3**, because that is
what the payment is. Summing a capped, banded charge per Bill of Entry and
adding the results breaches the cap and over-bills — a collection with two
Bills of Entry is the case that exposes it.

Carry the level on every charge line you emit. A line with no level will be
defaulted by the consumer and the default will be wrong.

---

## 6. Traps, each of which has already caught someone

**6.1 Read every sheet, including hidden ones.** Enumerate with
`openpyxl.load_workbook(...).worksheets` and print each `ws.sheet_state`. The
forex workbook's hidden sheet carries a rule that appears nowhere else, and an
earlier pass read one sheet of five and missed it.

**6.2 Read formulas, not only values.** Load a second time with
`data_only=False`. The calculators encode the charge logic in their formulas:
which cell feeds which, where a rate is hard-coded, where a floor or cap is
applied, which lines enter the total and which do not. The values alone do not
tell you the rule, and the rule is what you are after.

**6.3 Never read a spreadsheet row by column position.** At least one deal row
sits one column to the left of the others because an optional column is empty.
Read by shape — anchor on the right-hand end, or identify fields by content (a
currency code, a reference pattern, a number) — and **raise on any row that does
not parse**. A positionally-shifted row has something in every field and
disagrees with nothing, so it passes silently and poisons everything downstream.

**6.4 Screenshots clip text at column borders.** A portal column too narrow for
its content shows a fragment. **The fragment is not the value.** A column width
is a property of the screenshot; the real API returns the whole field. Record
the complete value where the surrounding evidence makes it unambiguous, or
record the field as not captured with the fragment noted separately. Both
failure directions are real:

- storing the fragment makes the application report a difference between two
  systems that does not exist, and can invent a counterparty — one fragment
  produced a party identified as the single letter `E`;
- silently expanding a fragment to what you think it should be makes a
  comparison pass on a value you made up.

**6.5 One table spans several screenshots.** Several captures are the same rows
scrolled sideways. Join them on the row, and **record which columns each capture
actually shows**, so a field absent from both is recognised as absent rather
than assumed empty.

**6.6 Excel serial dates.** At least one date cell holds a raw serial (for
example `46023`). Convert with the 1899-12-30 epoch. Text dates are
`dd/mm/yyyy`, **not** US order. Verify against a date you can reason about
before converting the rest.

**6.7 Count the embedded images and reconcile.** Open each `.xlsx` as a zip and
list `xl/media/`. Confirm what you extract equals what is embedded — there are
19 in total. Do the same for rows: count the data rows visible in every capture
and confirm the total equals the number of records you emit.

**6.8 Fixed-format identifiers should all be the same length.** Check each
reference type for an odd one out. A short one is either cut in the reading or
wrong at source. **Report it; do not pad it.**

**6.9 A value can be wrong in the source.** One IDPMS row has a number where an
address belongs and a currency code where a country belongs — a column shifted
in the bank's own file. **Preserve and flag.** Never correct. The same applies
to any disagreement between two systems: the bank's rule is to surface it.

**6.10 Fold punctuation, never fold legal forms.** `TWINTECH(S) PTE LTD` and
`TWINTECH S PTE LTD` are the same party. `PRIVATE LIMITED` against `PTE LTD` is
a real difference the written requirement says to flag, not absorb. Getting this
backwards either floods the worklist with noise or hides the finding.

**6.11 An absent value and a differing value are not the same.** A field the
portal never supplied cannot disagree with anything — it is unread, not
different. Keep the two states distinct in your output.

---

## 7. Questions to answer explicitly in your report

Each has a defensible answer either way. I want yours, with the evidence, not a
silent choice.

1. **The forex charge.** The clause gives a banded value on the gross amount
   exchanged and mentions GST at 18%. Is the amount billed the banded value, the
   18% of it, or both? Quote the sentences you relied on and name the sheet or
   email that settles it.
2. **The exchange rate.** Where a transaction has no booked deal, what rate
   converts it? Does anything in the sources say, or is it inference? Compare the
   rate card against the rates actually dealt in this same data and report the
   spread.
3. **The TF3 reference.** Some carry a three-digit prefix, some do not. What is
   the prefix, where is it defined, and which form is the reference?
4. **Missing payment records.** At least one customs consignment has no payment
   record in any capture. Is that a gap in the captures or in the supplied data?
   What evidence settles it?
5. **Invoice dates.** Many customs rows carry no invoice date. Where else, if
   anywhere, does a date for those invoices exist?
6. **Partial remittances.** Some Bills of Entry have an invoice the remittance
   does not cover. Confirm which, and that it is deliberate.
7. **Any row you believe is wrong at source**, with the evidence.

---

## 8. Mistakes the previous pass actually made

Not hypothetical. Each of these shipped and had to be found by a reviewer.

1. **Read one sheet of a five-sheet workbook**, missing the hidden sheet that
   defines the charge — and so billed it at roughly five and a half times.
2. **Typed a rule from the email instead of reading it from the workbook**, so
   the stated rule and the implemented numbers diverged.
3. **Parsed deal rows by column position**, so a shifted row produced
   `rate: "INR"`, `currency: 15255.93`, `amount: "784 ICS260134"`. Nothing
   complained, because every field had something in it.
4. **Stored a clipped screenshot fragment as a party's name**, which both
   reported a false mismatch and filed a counterparty under `E`.
5. **Then over-corrected**, expanding a fragment silently so a check passed on
   an invented value.
6. **Counted invoice lines per BoE number**, giving a one-invoice consignment a
   line count of six — five of them another importer's.
7. **Omitted the level on charge lines**, so the consumer's default swallowed
   the commission out of every collection total.
8. **Converted at the invoice total rather than the amount remitted**, which is
   not what the clause is charged on.
9. **Priced a conversion that had not happened**, for a consignment with no
   payment against it.
10. **Never opened the two email screenshots** until prompted, having assumed
    the reference bundle was the whole dataset.
11. **Filled a portal field from IDPMS when the capture never showed it**, so
    the consistency check between the two systems was comparing one source
    with itself and could not fail. Thirteen records: Symrise's drawer
    country, nine Rothe Erde drawer countries, both Bosch Automotive invoice
    amounts and currencies, and Putzmeister's Bill of Entry — all of them
    off-screen in every capture of those records. This is the worst of the
    ten because it is invisible from the output: the data looks complete and
    the checks look green, and the only way to catch it is to go back to the
    screenshot and ask whether the column was ever there.

Record which capture each field came from, and which fields a capture did not
show. A field the screenshot does not contain is **not captured** — not
"inferred from the other system".

The pattern in almost all of them: a plausible value in the right-shaped slot,
with nothing to contradict it. Build the checks that would have caught each.

---

## 9. What to verify before reporting

Build a reconciliation you can re-run, and include its output:

1. Every extracted record against its source cell or capture, field by field.
2. Every row and image in the sources accounted for in your output, and nothing
   in your output absent from the sources.
3. Every worked example in the workbooks reproduced exactly by your reading of
   the rule.
4. Every derived count and key recomputed per consignment and shown to match.
5. Your extraction against `case_index.json`. Where you disagree, say so and
   show why — either of you may be wrong.

## 10. How to report

Per source file: what you read, what you could not read and why, and any value
you judged anomalous. Then the reconciliation output. Then the seven answers.

Flag everything you inferred. An inference clearly labelled is useful. An
inference presented as a reading is the thing that causes the damage here.
