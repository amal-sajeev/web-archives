# Playground v10 bug-fix pass

This pass addressed several issues found by static and runtime-oriented review:

- Added sequence numbers to live run events so the SSE stream and polling fallback share one cursor and do not double-count progress.
- Fixed the polling fallback to respect an ingress path prefix instead of using a root-absolute URL.
- Added a visible Cancel action while a playground evaluation is running.
- Reset the Cancel control state between runs.
- Refreshes agent/dataset metadata after configuration edits and before running, so edited dataset case IDs and targets are reflected in the UI.
- Migrates older browser-local state that lacks `selectedCases` or `runs`.
- Prevents the Run action from being offered when no cases are selected.
- Added validation before starting a playground run, so custom-test/config errors are surfaced before background execution.
- Fixed undefined CSS variables in the custom-test status chip.
- Fixed API Tester Auth tab switching. Previously the Auth panel was excluded from the tab visibility list.
- API Tester no longer follows redirects in the server-side proxy. This avoids bypassing the initial SSRF destination check through a redirect.
- Comparison labels tolerate missing timestamps/scores/run IDs.

Validation performed:

- `python -m compileall -q src`
- `node --check` on all static JavaScript files
- Direct `LiveRun` sequence-number test
- ZIP integrity check

The full pytest suite remains blocked in this environment by the existing missing `google.auth` dependency during test bootstrap.
