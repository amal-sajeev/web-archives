# DB Redesign Implementation Checklist (Liquibase-safe)

Goal: deliver the final compliant schema without editing already-executed Liquibase changeSets.

## Target end-state

- Runs table name: `eval_execution`
- Baseline table name: `eval_baseline`
- `eval_execution` columns:
  - `creation_ts` (replaces `created_at`)
  - `status` VARCHAR (replaces `passed`) with values:
    - `PASS`
    - `FAIL`
    - `ERROR <detail>`
  - `created_by` (`CI_CD` or `DEVELOPER`)
- `eval_baseline` columns:
  - `dataset_id`
  - `dataset_version`
  - `baseline_metric_name` (from `metric`)
  - `baseline_metric_value` (from `baseline_value`)
  - `created_ts`
  - `created_by`
- Preserve historical data during migration.
- Keep Liquibase checksum/history intact by adding new changeSets only.

## Required migration approach

1. Restore previously-existing Liquibase table definitions (legacy/interim forms).
2. Add new additive migration file with new changeSet IDs only.
3. Use idempotent `ALTER TABLE`/`RENAME` logic guarded by `IF EXISTS` checks.
4. Migrate data values:
   - `passed` -> `status`
   - ensure `creation_ts`
   - set `created_by` default where missing
   - map baseline metric/value column names
   - derive/fill `dataset_id` where absent
5. Keep service grants valid after rename/migration.
6. Optionally add separate cleanup-context changesets for legacy table drops later.

## Validation checklist

- Fresh DB from scratch reaches end-state (`eval_execution`, `eval_baseline`).
- Existing DB with `runs`/`baselines` migrates cleanly.
- Existing DB with `cta_eval_*` migrates cleanly.
- No checksum edits on previously-run changeSets.
- Service can read/write run records and baselines after migration.
