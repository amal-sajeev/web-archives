# Evaluation Service: review and improvement change log

This document lists every change made to `dbaware-evaluation-service` in two review passes, with the reason for each one.

- **Pass 1: audit and fix.** A file-by-file audit found and fixed the bugs, API problems and UI defects.
- **Pass 2: improvements.**
  - further API improvements;
  - a plain-language UI for non-technical staff at a financial institution;
  - test coverage raised as far as practical.

All paths are relative to `dbaware-evaluation-service/`. Unless stated otherwise, Python paths are under `src/main/` and frontend paths under `src/main/static/`.

> **Current state of the UI (latest change): the complete pass-1 UI has been restored.**
>
> - `src/main/static/` is byte-for-byte identical to the pass-1 snapshot again. Everything the pass-2 sections below describe for the frontend has been rolled back: the plain-language UI, the run detail rework, the visual redesign, and the percentage change display.
> - The pass-2 frontend unit tests (`src/tests/js/`, `src/tests/test_js_units.py`) were removed with that code, because they tested modules that no longer exist.
> - Backend changes from pass 2 are kept. That covers API additions, error envelope, request ids, 503 handling, coverage work, and CSV/PDF export columns. The pass-1 UI only uses API behaviour that still exists.
> - Backups of the rolled-back UI are in the scratchpad: `backup/ui-before-pass1-restore/`.

> **Follow-up on the restored pass-1 UI (spacing and score changes):**
>
> **Score changes.** Every score change, in the UI and the PDF export, shows only the relative change: "−69.6%", "+4.2%" or "Unchanged".
> - The before → after scores in parentheses were dropped at the user's request.
> - When the old score was 0 there is no relative change, so it reads "Up from 0%".
> - The helpers are `formatChange`, `changeLabel` and `formatChangeVsBaseline` in `js/lib/format.js`, plus `changeHtml` in `fragments.js`, and `_change_text` for the PDF.
> - The CSV export still carries the raw baseline, current and relative-change columns.
>
> **Spacing.**
> - The caption under a heading lost its negative top margin. The criterion-summary footnote was overlapping the table.
> - Wider gaps between panel headers and their content, labels and their values, case sections and group headings, the progress bar and its text, and the API tester's request rows.
> - The per-criterion change cells no longer truncate.

> **Playground and API tester: second-pass UI restored.** Both pages are back to their second-pass design: the 1 Load → 2 Check → 3 Try it → 4 Save playground and the simple-mode API tester, from before the visual redesign. The dashboard, live run and run report stay on the pass-1 UI.
>
> - **Isolated styling.** The two tool pages load their own copy of the second-pass shared styles, `css/tools-v2/{tokens,base,components}.css`, so the other pages' look is unchanged. `shell.css` (the header) was identical in both versions and stays shared.
> - **Restored files.** `js/lib/wording.js` and `js/lib/skip-reasons.js` are back as tool dependencies, and `deltaPoints` returns to `format.js` as a numeric helper.
> - **Compare dialog.** Changes now show as a relative percentage ("+33.3%"), not "N points higher", in line with the earlier no-points request.
> - **Tests.** The 72 frontend unit tests for these pages (`src/tests/js/playground-*`, `apitester-*`) and `src/tests/test_js_units.py` are restored, and they run inside pytest.

## At a glance

| | Before | After pass 1 | After pass 2 |
|---|---|---|---|
| Python tests | 191 passed, 2 skipped | 571 passed, 2 skipped | **1055 passed, 0 skipped** |
| Frontend (JS) unit tests | none | none | 72 (playground and API tester; run inside pytest via `test_js_units.py`) |
| Line + branch coverage (`src/main`, sample agents, agent tests, scripts) | ~87% line, `src/main` only | 87% line | **99% (0 lines missed; 3 defensive branches partial)** |
| Ruff findings | 485 | 858 (all a config glob bug) | **0** |
| Files over 300 lines | 20 | 0 | **0** (largest is 296) |
| Functions over 50 lines, or McCabe complexity over 15 | many | 0 | **0** |
| Integration script (`scripts/run_integration_tests.ps1`) | broken | 47/48 | **48/48** |

**How to run everything:**
```powershell
cd dbaware-evaluation-service
.\.venv\Scripts\python.exe -m pytest                                          # Python + JS unit tests
.\.venv\Scripts\python.exe -m pytest --cov=src/main --cov-branch              # with coverage
.\.venv\Scripts\python.exe -m ruff check src scripts                          # lint
powershell -File scripts\run_integration_tests.ps1 -Port 4302 -AgentPortBase 4310   # end to end
```
`.venv` was created in pass 1 with the exact pinned requirements. The global Python had FastAPI 0.104, which is older than `requirements.txt` asks for.

## Decisions and deliberate non-changes

- **Security hardening was excluded, at your request.** This covers:
  - executing uploaded `custom_tests.py`;
  - the open `/api/playground/http` proxy;
  - webhook and base-URL SSRF;
  - the runtime TLS toggle;
  - zip path traversal;
  - authentication.

  These behave exactly as before and should be addressed separately.
- **Out of scope:** Dockerfile, Helm, `pom.xml` and `.env`. `.env` still contains plaintext DB passwords, and they should be rotated.
- **Scores have shifted against stored benchmarks.** The scoring fixes in both passes change results on purpose: missing data is no longer a free pass, and safety checks now see document contents.
- **Not changed; needs a product decision:**
  - `GoldenCase.golden_file` is never read by any scorer, so a test with only `golden_file` skips the reference checks.
  - A deliberately corrupted 7z archive can hang py7zr 0.22. This is security-adjacent, so it was left alone.

---

## Pass 1: audit and fix (summary)

The first pass followed an approved job list; the plan file has the full detail. Highlights:

### Scoring correctness (results changed on purpose)
- **Missing input no longer scores as a pass or fail.** Missing golden answers, source context and metrics used to score a perfect 1.0 (or 0.0); they now show as "not checked". Otherwise a broken pipeline looked healthy.
- **A crashed critical check now fails the test** instead of being silently dropped.
- **Scores are always clamped to 0–1, and NaN becomes 0.** The clamp was inverted, so out-of-range values leaked into the headline score.
- **The faithfulness judge's position swap is fixed.** It put the agent's answer under the "reference" label, so the judge graded the wrong direction.
- **Rubric scoring averages over the configured criteria.** Criteria the judge omitted used to inflate the score.
- **Pattern and schema fixes:**
  - IBANs with spaces are detected.
  - `expected_values` given as a string is no longer iterated character by character.
  - JSON Schema handles type lists and rejects `bool` where an integer or number is expected.
  - Invalid regexes are reported instead of crashing.
- **Benchmarks are normalised consistently** with scores, and lower-is-better metrics without a maximum are skipped rather than scored 0.

### Broken features fixed
- **Playground export by stream always crashed:** it read an attribute (`finished_run`) that didn't exist.
- **Cancel raced:** clients never saw the cancel event. Cancel now returns 202, or 409 if the run already finished.
- **The report-writer sample agent:** one topic always returned HTTP 500 (a 3-tuple in its data).
- **`scripts/ci_gate.py` never worked:** it treated a stream id as a run id and checked a field that doesn't exist.
- **`scripts/db_smoke.py` imported modules that don't exist.**
- **The integration script** never restored the `agent.yaml` files it patched, and asserted on fields that don't exist.
- **The dashboard silently counted only the first 50 runs.**

### Runtime robustness
- **Startup ran twice and connected to the database at import time.** It now runs once, in a FastAPI lifespan with dependency injection.
- **SQLite connections leaked.** They are now closed.
- **The run list ran one extra query per run.** The counts now come from SQL.
- **The pagination cursor skipped or duplicated runs with equal timestamps.** It is now a composite `(ts, id)` cursor.
- **One bad agent folder stopped the service starting.** It is now skipped and logged.
- **Structured logs dropped most fields.**
- **The runner swallowed cancellation** and didn't stop sibling cases on failure.

### Structure and standards
- **20 oversized files were split into focused modules**, re-exported so import paths still work. Examples: `runner.py` → 5 modules, `models.py` → package, `http_adapter.py` → 5 modules, `styles.css` (2241 lines) → 12 files, `run_detail.js` (851) → 8 modules.
- **Dead and duplicate code removed:** the router/bootstrap packages were never used and broken, a duplicate scorer registration silently won, and about 30 CSS selector groups were dead.

### UI (pass 1)
- **Theme toggle bugs:** it did nothing on two pages, and every page load overwrote your saved theme.
- **Playground editor text was invisible in the light theme.**
- **Markdown in agent output could inject `javascript:` links.**
- **Mobile layouts were broken.**
- **Cancelled runs left the live page spinning.**
- **New:** Export CSV/PDF, a Cancel button, loading and empty states, and one shared header.

---

## Pass 2: improvements

### Setup and integration

These are changes made while coordinating the pass and fitting the pieces together.

#### Tooling and test harness
- **`ruff.toml`: the test ignore glob `tests/**` became `**/tests/**`.**
  - The tests live in `src/tests`, so the old glob never matched. Ruff reported 858 false `S101` (assert) findings, and the integration script's lint step always failed.
  - Ruff is now fully clean, and the integration script passes 48/48.
- **New JS unit-test harness.**
  - Frontend logic had no automated tests at all.
  - Tests live in `src/tests/js/*.test.mjs` and use node's built-in `node:test`, so there are no npm dependencies.
  - `src/tests/test_js_units.py` runs them inside the normal `pytest` run, so one command tests everything. It skips cleanly where node isn't installed.
- **New `static/js/lib/wording.js`: one plain-language vocabulary.**
  - It uses "test" not "case", "check" not "metric", "benchmark" not "baseline", and "AI reviewer" not "LLM judge".
  - It also holds the verdict words and icons, friendly dates, and sentences like "7 points lower than the benchmark".
  - The audience is non-technical, so every page must use the same everyday words. One shared module stops the pages drifting apart.
  - The UI agents later extended it.

#### Integration fixes after the parallel work
- **`handlers/agents.py` now uses the new public `Registry.list_agents(include_disabled=...)`.** It used to read the registry's private `_agents` map, which bypassed the registry's own rules. `FakeRegistry` in `conftest.py` and the affected tests were updated to match.
- **New test for the summary fallback, for backends whose run rows lack `error_detail`.** Once the playground repository started providing the field, that code path lost its test coverage. It still protects third-party or older backends, so it keeps a test.
- **Removed the "TLS: Verify" switch from the header of the report, playground and API tester pages.**
  - It is a support setting that means nothing to most readers.
  - The dashboard already moved it into "Technical details", and the live page already dropped it.
  - It now appears only in the dashboard header, where it lived before pass 2.
- **Removed generated `.coverage` files** that parallel test runs left in the service folder.

### API / handlers / repository: second improvement pass

Scope: `src/main/main.py`, `api_routes.py`, `dependencies.py`, `handlers/**`, `repository/**`,
`core/models/api.py`, `core/run_manager.py`, plus two new top-level modules (`http_middleware.py`,
`error_handlers.py`) and their tests. Security hardening was out of scope, so auth, SSRF on
playground_http / webhook_url / base_url, custom_tests sandboxing and the TLS toggle all behave as before.

Existing response shapes are unchanged. Every change below either adds fields or turns a crash into a
proper 4xx/5xx.

Final state: the full suite passes (1037 tests), `ruff check src scripts` is clean, every file I touched
is under 300 lines, and every file I own is at 100% line coverage.

---

#### 1. Required API additions (the UI codes against these)

##### 1.1 `GET /api/runs`: items gain `error_detail` and `agent_name`
- **Files:** `repository/_sql.py`, `repository/sqlite_repo.py`, `repository/postgres_repo.py`, `handlers/runs.py`
- **What:**
  - `ListRunsDialect` has a new `error_detail_sql` fragment: `json_extract(detail_json,'$.error_detail')` on SQLite and `detail_json ->> 'error_detail'` on Postgres.
  - A new `item_columns()` method builds one SELECT list, which both the list query and the summary query use.
  - The handler adds `agent_name`, the registry `name` from `agent.yaml`, or `null` when the agent is unknown. Names are looked up once per agent per request.
- **Why:**
  - `error_detail` was stored only inside `detail_json`. The dashboard could not show why a run errored, or tell a cancelled run apart from a crash, without fetching every run record in full.
  - Rows showed only raw `agent_id` values.
  - The SQL extract keeps this to one query, with no N+1 lookups.

##### 1.2 `GET /api/runs/{run_id}`: top-level `agent_name`
- **Files:** `handlers/runs.py`
- **What:** the response is the full RunRecord plus `agent_name`, looked up the same way as in 1.1.
- **Why:** the run report needed a display name without a second call to `/api/agents`.

##### 1.3 `GET /api/agents?include_disabled=true`, and `enabled` on every item
- **Files:** `handlers/agents.py`
- **What:**
  - Every item now carries `enabled: bool`.
  - By default only enabled agents are returned, exactly as before.
  - With `include_disabled=true`, disabled agents are appended with the same fields and `enabled: false`.
- **Why:** agents disabled in `agent.yaml` were invisible. They are still loaded and can still be evaluated, so the UI had no way to list or explain them.
- **Note:** `Registry` (not mine) exposes only enabled summaries, so the handler reads the registry's loaded map for the disabled ones. See "Requests for other owners".

##### 1.4 New `GET /api/runs/summary?agent_id=&dataset_id=&since=`
- **Files:** new `repository/_summary_sql.py`, new `repository/_summary_fallback.py`, `repository/base.py`, `repository/sqlite_repo.py`, `repository/postgres_repo.py`, `handlers/runs.py`, `api_routes.py`
- **What:**
  - Returns `{total, passed, failed, errored, cancelled, average_score, latest, previous}`.
  - **One SQL statement on both backends.** CTEs build `filtered`, `totals`, `latest` and `previous`, and one row comes back with prefixed `latest_*` and `previous_*` columns.
  - `average_score` covers non-ERROR runs only and is `null` when there are none.
  - `cancelled` means ERROR with `error_detail == "cancelled"`; `errored` counts every other ERROR run.
  - `latest` and `previous` are run-list items with the same shape as 1.1, including `agent_name`.
  - `previous` is the run just before `latest` for the same agent. It honours `dataset_id`, so the two runs are comparable, but ignores `since`, so the run just before the window can still serve as the comparison point.
  - An invalid `since` returns 422 with FastAPI's validation shape.
  - The route is registered before `/api/runs/{run_id}`.
  - `EvaluationRepository.run_summary()` is a new, non-abstract method. Its default implementation pages through `list_runs`, so in-memory backends such as the playground `PreviewRepository` and test doubles keep working without changes. A test proves that this default and the SQLite query return identical results on the same data.
- **Why:** the dashboard computed its stats by pulling every run page into the browser. This moves the work to the database.

---

#### 2. Consistent errors, request correlation, and 503s

##### 2.1 Error envelope: `detail` + `error_type` + `request_id`
- **Files:** new `error_handlers.py`, `main.py`, `core/models/api.py` (`ErrorResponse`)
- **What:**
  - Every non-2xx JSON body now has the form `{"detail": ..., "error_type": ..., "request_id": ...}`. This covers HTTPException, unknown routes and 405s, and request validation.
  - `error_type` is a stable category: `not_found`, `conflict`, `validation_error`, `bad_request`, `upstream_error`, `service_unavailable`, and so on.
  - `detail` is unchanged: a string, or the list for 422, so `fetchJson` in the UI keeps working.
  - Unhandled exceptions keep their existing contract: `error_type` is the exception class name, and `detail` carries only an `error_id`.
  - Headers set on an HTTPException, such as `Retry-After` or `Allow`, are preserved. 204 and 304 get no body.
- **Why:** error bodies differed from route to route, and clients could not branch on a category or quote an id that matched a log line.

##### 2.2 `X-Request-ID` correlation
- **Files:** new `http_middleware.py`, `error_handlers.py`, `main.py`
- **What:**
  - A pure-ASGI middleware accepts a well-formed inbound `X-Request-ID` (at most 128 characters from `[A-Za-z0-9._:-]`) or mints one.
  - It stores the id on `request.state` and echoes it on every response, including 500s.
  - A log-record factory stamps `request_id` on every log line emitted while the request runs. Lines logged outside a request are unaffected.
- **Why:** there was no way to connect a user's failed request to its server log line. The middleware is pure ASGI, not `BaseHTTPMiddleware`, so SSE streams are not buffered or broken.

##### 2.3 Repository unavailable → 503 + `Retry-After`, not 500
- **Files:** new `repository/errors.py`, `error_handlers.py`, `handlers/_common.py`
- **What:**
  - Transient storage failures return 503 with `Retry-After: 5`, `error_type: service_unavailable` and a generic message with an `error_id`. These are `sqlite3.OperationalError` (locked or unopenable file) and SQLAlchemy `OperationalError`, `InterfaceError` and `TimeoutError` (the pool).
  - This works both through a global handler and through `classify_error`, which serves `/api/evaluate` and A/B.
  - Programming errors, such as bad SQL or integrity violations, stay 500.
- **Why:** a locked SQLite file or a Postgres blip used to surface as an opaque 500. Load balancers and clients could not tell "retry later" from "bug".

---

#### 3. HTTP hygiene

##### 3.1 Cache headers
- **Files:** `http_middleware.py` (`CacheControlMiddleware`, `cache_policy`)
- **What:** these apply only when the response did not set its own `Cache-Control`; the SSE `no-cache, no-transform` header is kept as is.
  - `/api/*`, `/health`, `/livez`, `/readyz` and every error response: `no-store`.
  - Static assets with `?v=`: `public, max-age=86400`.
  - Everything else, including HTML pages and ES modules imported without `?v=`: `no-cache`, so the browser revalidates using StaticFiles' ETag and Last-Modified.
  - `ROOT_PATH` is stripped before the path is matched.
- **Why:**
  - Browsers and proxies could cache JSON such as run lists and health.
  - Versioned assets were refetched on every page load.
  - Unversioned imported modules could go stale after a deploy.
  - A day, rather than a year, is used because `?v=` is the service version, not a content hash, so a developer editing CSS without bumping the version would otherwise stay stuck on the old file.

##### 3.2 GZip
- **Files:** `main.py`
- **What:** `GZipMiddleware(minimum_size=1024)`. Starlette 1.7 already excludes `text/event-stream`, so SSE is never compressed.
- **Why:** run lists and full run records (with observations) are large, repetitive JSON.

##### 3.3 HEAD on probes
- **Files:** `api_routes.py`
- **What:** `/api/health`, `/health`, `/livez` and `/readyz` accept HEAD. The HEAD routes are hidden from the schema, which avoids duplicate operation-id warnings.
- **Why:** many load balancers and uptime checkers probe with HEAD and got 405.

##### 3.4 OpenAPI
- **Files:** `api_routes.py`, `main.py`, `core/models/api.py`
- **What:**
  - Eight tags with descriptions.
  - Each route's summary is taken from the first line of its handler docstring, and the description from the full docstring.
  - Every declared error response points at `ErrorResponse`.
  - Real `response_model`s on `/api/agents` (`AgentListResponse`), `/api/runs` (`RunListResponse`) and `/api/runs/summary` (`RunSummaryResponse`). The list-item models use `extra="allow"`, so a new column is never silently dropped.
  - `/api/runs/{run_id}` documents `RunDetailResponse` without validating it at runtime; re-validating a full run record on every request costs more than it adds.
- **Why:** the docs at `/docs` were one flat, untyped list.

---

#### 4. Input validation and bug fixes

| File | Change | Why |
|---|---|---|
| `handlers/runs.py` | `before` cursor timestamps are validated, and an invalid one returns 422 | **Bug:** `?before=garbage` decoded as a "legacy timestamp", reached `fromisoformat` inside the repository and raised an unhandled 500. |
| `handlers/runs.py` | `POST /api/baselines/promote/{id}` returns 409 for ERROR runs, including cancelled ones | **Bug:** a cancelled run that finished 2 of 10 cases could become the baseline, which corrupted drift detection for every later run. |
| `handlers/playground_validate.py` | A custom scorer that collides with a built-in is reported once, not also as "did not register" | **Bug:** validation reported both "overrides an existing scorer: X" and "did not register declared scorer(s): X", which contradict each other. |
| `handlers/playground.py` | The export filename is reduced to `[A-Za-z0-9._-]` | A bundle `root` containing quotes or CR/LF went straight into `Content-Disposition`, where it could break the header or make the server error. |
| `handlers/playground.py` | `case_ids_json` must be an array of **strings** | `[1, 2]` was accepted and then silently matched no cases. |
| `core/models/api.py` | `agent_id` / `agent_a` / `agent_b` require at least 1 character. Label `case_id` is 1–256 characters, `labeler` at most 128, `note` at most 4000, ids at most 256 | Empty ids produced confusing 404s, and label text had no upper bound in an in-memory store. |
| `handlers/captures.py` | `/api/labels` and `/api/captures` take `limit` (default 1000, maximum 5000) and `offset`, and return `total`. `/api/captures` and `/api/captures/{case_id}` take an optional `agent_id` | One call could serialise up to 10,000 labels. The capture store is keyed by agent, but the API could not filter by it. |
| `repository/_pg_engine.py` | `missing_tables` was restructured: sleep only between attempts, raise after the last one | It ended in an unreachable `return list(tables)` (dead code), and the retry flow was harder to follow. |

#### 5. Graceful shutdown
- **Files:** `core/run_manager.py` (`RunManager.shutdown`), `main.py` (lifespan)
- **What:** on shutdown, every in-flight run is sent `request_cancel()` and has its task cancelled. The service then waits up to 10 s for the runs to finish their cancellation path, which persists an ERROR "cancelled" record and publishes `run_cancelled`, and only after that closes the repository. Runs that ignore cancellation are logged, and they cannot stall shutdown beyond the grace period.
- **Why:** before this, stopping the process while a run was live closed the repository under the run. The run was neither saved nor marked cancelled, and it disappeared from history.

#### 6. Small structural changes
- `dependencies.py`: a new `OptionalRegistryDep`. HTTP requests always get the registry; direct Python callers of `list_runs`, `get_run` and `runs_summary` may omit it, and `agent_name` is then `null`.
- `handlers/_common.py`: new `query_error()` (one 422 builder) and `agent_name()`. `http_error` adds `Retry-After` to 503s.
- `api_routes.py`: `_errors()`, `_tagged()` and `_probe()` helpers remove repeated literal dicts.

---

#### 7. Tests

The new test files hold 127 tests. `test_run_manager.py`, `test_sqlite_repo.py` and `test_handlers_health_agents.py` were extended, and `conftest.py`'s `FakeRegistry` now mirrors the real registry.
- `test_api_contract.py`: exact field contracts for every addition in section 1, route ordering, `since` and cursor validation, the promote 409, label and capture paging, and body validation.
- `test_api_middleware.py`: request ids (generated, kept, replaced when invalid, present in 500s, reset after the request, stamped on log records), the envelope for 404, 405, 422 and 500, 503 with `Retry-After` for SQLite and SQLAlchemy outages, the cache policy matrix, gzip for large responses but not small ones, HEAD on all four probes, and OpenAPI tags, summaries and models.
- `test_postgres_repo_engine.py` and `test_postgres_repo.py`: Postgres **without a database**. A scriptable fake engine and connection (`pg_fakes.py`) record every statement and its bound parameters. The tests cover pool configuration, the TCP and Connector transports (private IP, missing instance name, missing ADC), `SET LOCAL search_path`, the retry and give-up paths of schema verification, JSONB upsert binding, naive-UTC and aware-ISO timestamp conversion, the list query fragments, the single-statement summary, baselines, retention and dispose.
- `test_repo_factory.py`: every branch of `build_repository`, including CloudSQL failure with and without the SQLite fallback.
- `test_repo_summary.py`: summary semantics, run against both SQLite and the portable default, plus a test that the default and the SQL query agree.
- `test_api_playground.py`: inspect, environment, start → drive → `playground_done` (base-URL override, case ids, PreviewRepository), bad bundle → one error event, cancel → `run_cancelled`, `case_ids_json` validation, validate (valid, structure problems, sensitive files, collisions, undeclared scorers, load failure), export filename safety.
- `test_api_misc.py`: SSE replay, keep-alive and disconnect, UI pages and the 404 for a missing page, playground_http body variants and 502/504, webhook success and failure, retention, lifespan shutdown cancelling live runs, dependency providers, and the `__main__` entrypoint.

#### 8. Coverage (line coverage of the files I own)

| File | Before | After |
|---|---|---|
| main.py | 87% | 100% |
| api_routes.py | 100% | 100% |
| dependencies.py | 90% | 100% |
| core/models/api.py | 100% | 100% |
| core/run_manager.py | 98% | 100% |
| handlers/_common.py | 99% | 100% |
| handlers/agents.py | 100% | 100% |
| handlers/captures.py | 100% | 100% |
| handlers/comparison.py | 95% | 100% |
| handlers/evaluate.py | 90% | 100% |
| handlers/health.py | 100% | 100% |
| handlers/playground.py | 48% | 100% |
| handlers/playground_http.py | 81% | 100% |
| handlers/playground_validate.py | 42% | 100% |
| handlers/runs.py | 98% | 100% |
| handlers/settings.py | 100% | 100% |
| handlers/streams.py | 70% | 100% |
| handlers/ui.py | 76% | 100% |
| repository/\_\_init\_\_.py | 48% | 100% |
| repository/_pg_engine.py | 0% | 100% |
| repository/postgres_repo.py | 0% | 100% |
| repository/_sql.py | 96% | 100% |
| repository/base.py | 83% | 100% |
| repository/sqlite_migrations.py | 82% | 100% |
| repository/sqlite_repo.py | 96% | 100% |
| new: http_middleware.py, error_handlers.py, repository/errors.py, _summary_sql.py, _summary_fallback.py | n/a | 100% |

Suite at the start of this pass: 572 passed and 2 skipped (87% total). At the end: 1037 passed. That count includes tests other agents added in parallel; `src/main` total coverage is 100%.

#### 9. Requests for other owners (not changed by me)
- **registry/**: add a public `Registry.list_agents(include_disabled: bool = False)`, or an `iter_agents()`, so `handlers/agents.py` can stop reading `registry._agents` for disabled agents.
- **core/playground/preview_repo.py**: add `"error_detail": run.error_detail` to `_summary()` so its `list_runs` rows match the interface. The summary default currently fetches the run record for ERROR rows to fill it in.
- **UI**: error bodies now also carry `error_type` and `request_id`, and every response has an `X-Request-ID` header. Showing the id in error toasts would make support easier.

### Core, adapters, scorers, agents and scripts: second pass

**Scope:**
- `src/main/scorers`, `adapters`, `core` (everything except `core/models/api.py` and `core/run_manager.py`), `registry`, `service` and `utils.py`
- `src/sample_agents` and `src/agents`
- `scripts/`
- the tests for all of these

**Result:**
- **Coverage:** every file in this area is at **100% line and branch coverage**. The per-file table is at the end.
- **Tests:** the full suite has **1054 passed, 0 skipped**. The baseline was 572 passed and 2 skipped; those two could never run and now do (see the playground section).
- **Lint and size rules:** `ruff check src scripts` is clean. Every file is under 300 lines, every function is at most 50 lines, and the complexity checks pass.
- **Runner and scoring contract:** unchanged from pass 1. The few places where results change are real bugs, and each one is listed under "Bugs found while testing".

---

#### Conventions the UI can rely on (skip reasons and error text)

The prefixes below are stable, so UI code can key on them. The UI's `skipReason()` in `lib/format.js` matches on keywords, and every wording below still works with it: "judge unavailable", "timed out" and "quota" are kept.

| Where | Prefix / shape | Meaning |
|---|---|---|
| `SkippedMetric.reason` | `Scorer error: <Type>: <message>` | **New prefix in the stored reason.** The scorer crashed. The live `metric_skipped` event already said this; the saved run record only had `<Type>: <message>`. |
| `SkippedMetric.reason` | `config error: '<key>' must be a whole number, got <value>` | **New.** A metric's config has a non-numeric `min`, `max`, `min_count` or `min_rows`. |
| `SkippedMetric.reason` | `LLM judge invocation failed: <plain sentence> (<Type>: <message>)` | The prefix is unchanged. A plain sentence now comes first, for example "Could not connect to the AI assessment service. Check that it is running and that its address is correct." Timeouts read "…did not respond within the time limit. (TimeoutError: judge invoke timed out after 45.0s)", so the UI's timeout rule still matches. |
| `SkippedMetric.reason` | `embeddings unavailable: …` | Unchanged prefix. A new case is `embeddings unavailable: vector sizes differ (768 vs 512)`. |
| `SkippedMetric.reason` | `optimal_steps must be a whole number, got '<value>'` | **New.** `step_efficiency` with a bad `optimal_steps` in the case. |
| `Observation.error` | `HTTP <code>: <body>` | Unchanged. An empty body now falls back to the reason phrase, for example `HTTP 503: Service Unavailable`, instead of `HTTP 503: `. |
| `Observation.error` | `<plain sentence> (<Type>: <message>)` | **New shape for transport failures** (previously `ConnectError: [Errno 11001] getaddrinfo failed`). See the sentence list below. |

**Plain sentences.** These come from the new `service/http_errors.py`. `<What>` is "the agent" for target calls and "the AI assessment service" for the judge.
- Could not connect to `<what>`. Check that it is running and that its address is correct.
- `<What>` did not respond within the time limit.
- `<What>` did not accept the connection within the time limit.
- `<What>` closed the connection unexpectedly.
- The network proxy refused the connection to `<what>`.
- The address configured for `<what>` is not a valid URL.
- `<What>` replied, but the reply was not valid JSON.
- `<What>` replied, but not in the expected format.

Anything else keeps the old technical text `<Type>: <message>`.

---

#### 1. Plain-language error messages

- **New file: `service/http_errors.py`.**
  - *What:* `describe_http_error(exc, what)`, `plain_http_error(exc, what)` and `technical_detail(exc)`. They map httpx transport errors, `TimeoutError`, `json.JSONDecodeError` and pydantic `ValidationError` to the sentences above, and keep the technical text in brackets at the end.
  - *Why:* users saw raw Python text such as "httpx.ConnectError: [Errno 11001] getaddrinfo failed" or "ValidationError: 1 validation error for Observation target_id Field required". That doesn't tell a non-technical reader that the agent is down or has replied with the wrong shape. The technical part is kept so engineers can still diagnose.
- **`adapters/http_response.py`, `error_observation`.**
  - *What:* every target adapter (http, agent_eval_hook, scoping_analytics, walkthrough) now describes transport and reply-shape failures in plain words.
  - *Why:* this is the single place where adapter exceptions become `Observation.error`, which the run report shows next to each case.
- **`scorers/judge_invoke.py`, `_invoke_metric`.**
  - *What:* judge failures now use the same plain wording, about "the AI assessment service", after the unchanged `LLM judge invocation failed:` prefix.
  - *Why:* the same readability problem, this time for skipped judge metrics.
- **`agents/walkthrough_query_agent/custom_tests.py`.**
  - *What:* the "document upload also failed: …" suffix uses the plain wording as well.
  - *Why:* consistency with the other adapters.
- **`core/config.py`, `_load_yaml_for`.**
  - *What:* a broken `config/<env>/environment.yaml` now fails with "config/uat/environment.yaml is not valid YAML: …". It used to fail with a bare `yaml.scanner.ScannerError`.
  - *Why:* start-up still fails fast, but the message now names the file to fix.

#### 2. Scorer correctness (bugs that changed results)

- **`scorers/safety.py`: PII, injection and refusal checks now see document text.**
  - *What:* the new `_scan_text()` works as follows:
    - Structured output is still scanned as JSON, so every field is checked.
    - Document **bytes** are scanned as their extracted text.
    - Adapter-extracted text (`metadata.extracted_text`) is always included.
  - *Why:* an agent that returned a PDF or DOCX was scanned as the Python repr `"b'%PDF-1.4 …'"`. PII inside the document was never found, so the `no_pii_leakage` safety veto always passed. For a banking service that is a real compliance gap.
- **`scorers/deterministic.py`, `assertions`: the output is searched as readable text.**
  - *What:* it now uses `output_text(observation)` instead of a JSON dump: report bundles become prose, adapter-extracted text is preferred, and bytes are extracted.
  - *Why:* an "absent" spot check for a word such as `content`, `paragraphs` or `report_title` always failed, because those words are JSON keys in the dumped bundle. Byte outputs were searched as `b'...'`.
- **`scorers/configurable_json.py`, `json_schema_valid` shortcut: `types` is now checked on its own.**
  - *What:* a key listed in `types` but not in `required` is type-checked when it is present, and reported as "optional, absent" when it is missing.
  - *Why:* a config with only `types:` used to check nothing and always scored 1.0 ("0/0 schema checks passed").
- **`scorers/json_schema_check.py`: `enum` and `const` follow JSON equality.**
  - *What:* the new `_json_equal`: `true` no longer equals `1`, and `false` no longer equals `0`.
  - *Why:* Python treats `True == 1`, so `{"const": true}` accepted the number 1 and `{"enum": [0, 1]}` accepted booleans.
- **`scorers/similarity.py`, `embedding_similarity`: skips when the two vectors have different sizes.**
  - *What:* the new skip reason is `embeddings unavailable: vector sizes differ (a vs b)`. `zip()` is now `strict=True`, inside a new `_cosine` helper.
  - *Why:* `zip(strict=False)` silently cut the longer vector short and reported a cosine that meant nothing.
- **`scorers/base.py`, `is_judge_scorer`: a stale judge flag is no longer applied.**
  - *What:* the attribute on the function now wins. The name set is only a fallback for callables that refuse attributes.
  - *Why:* if a judge scorer was a callable that refuses attributes (such as a bound method) and was later replaced by a plain function under the same name, the name stayed in `_JUDGE_NAMES`. The plain scorer was then throttled by the judge semaphore and flagged `judge: true` in events.

#### 3. Configuration errors become clear skips

- **New helper: `scorers/_util.config_int`.**
  - *What:* used for `min_count` (in `contains` and `keyword_count`), `min` and `max` (in `length_range` and `heading_count`), and `min_rows` (in the table checks). A non-numeric value raises `MetricSkipped("config error: 'min_count' must be a whole number, got 'several'")`.
  - *Why:* `int("several")` raised `ValueError`, and the report showed "Scorer error: ValueError: invalid literal for int() with base 10: 'several'". The metric was omitted either way; the reason now says what to fix.
- **`scorers/trajectory.py`, `step_efficiency`.**
  - *What:* a non-numeric `optimal_steps` in the case is now a clear skip.
  - *Why:* the same problem as above, for case data rather than metric config.
- **`core/metric_scoring.py`.**
  - *What:* the stored skip reason for a crashed scorer now carries the same `Scorer error: ` prefix as the live event. `_skip()` lost its duplicate `shown` argument.
  - *Why:* the saved report could not tell a crashed scorer from an ordinary "not applicable" skip. Only the live stream could.

#### 4. Clearer rationales (no score change)

- **`configurable_json.field_match` with only optional fields.**
  - *Before:* "0/2 field checks passed", with a score of 1.0.
  - *Now:* "no required fields (2 optional checked)".
- **`configurable_text.regex_match` with only optional patterns.**
  - *Before:* "0/0 required patterns matched".
  - *Now:* "no required patterns (N optional checked)".
- **`trajectory.tool_arg_accuracy` with nothing to check** (for example, `expected_tool` without values).
  - *Before:* "0/0 tool-arg checks passed".
  - *Now:* "no expected tool args defined".
- **`json_schema_valid` with an empty config on an object.**
  - *Now:* "no schema checks applied".

*Why:* a rationale that says "0/2 passed" next to a 100% score looks like a bug to anyone reading the report.

#### 5. Robustness

- **`adapters/metrics_api.py`, `StubMetricsClient`.**
  - *What:* a corrupt (non-JSON or non-UTF-8) `metrics_stub.json` is logged and ignored, like a stub that is not an object.
  - *Why:* it used to raise `JSONDecodeError` while the run was being built, so the whole run failed before any case started. Now only the metrics that need stub data are skipped, each with its usual "missing" reason.
- **`registry/__init__.py`, `_import_custom_tests`.**
  - *What:* if a `custom_tests.py` cannot be loaded as a module, it now raises `ImportError`, and the agent is logged and skipped with that reason.
  - *Why:* it was silently ignored, which surfaced later as confusing "unknown scorer" validation errors.
- **`adapters/registry.py`.**
  - *What:* the re-registration warning compares module plus qualname.
  - *Why:* two different adapter classes with the same class name, from two agents' `custom_tests.py`, replaced each other without any warning.
- **`utils.build_text_pdf`.**
  - *What:* it now accepts a plain string and splits it into lines.
  - *Why:* passing a string, which is easy to do, iterated it character by character and produced a PDF with one character per line. I found this while writing tests.

#### 6. Dead code removed and structure simplified

- **`scorers/output_text.py`.**
  - `_paragraph_text` now takes the list directly.
  - Removed the unreachable `body is None` branches; both callers had already checked for a list.
  - New `_is_report()` helper.
- **`scorers/document_structure.py`.** Removed the tuple branch and the separate Markdown path in `_heading_keys`. `parse_headings` always returns strings, and its Markdown path gives the same headings.
- **`scorers/configurable_json.py`.** The new `_parse_output()` replaces four identical `try/except` parse blocks. Sonar flags these as duplicated code.
- **`scorers/judge_invoke.py`, `_invoke_with_retry`.** The loop is restructured so the last attempt sits outside it, which removes the unreachable `raise RuntimeError("judge retry loop exited without a result")`. The behaviour is identical.
- **`scorers/safety.py`.** Removed the Luhn length check. The card regex already guarantees 13 to 19 digits.

#### 7. Additions requested by the lead for the API agent

- **`registry.Registry.list_agents(include_disabled: bool = False) -> list[dict[str, Any]]`.**
  - Every item now carries `enabled: bool`.
  - With `include_disabled=True`, disabled agents come after the enabled ones, each group in folder order.
  - The default call returns the same rows as before, plus `enabled`.
  - A new module-level `_summary()` builds the row.
- **`core/playground/preview_repo._summary`.** Now includes `error_detail`, matching the SQL repositories' `list_runs`.


#### 8. Playground bundles and document extraction (detail)

Scope: `core/playground/*`, `adapters/documents.py`, `adapters/golden_files.py`, and their tests.

###### Bugs found while testing

1. **Agent folders nested inside the archive could not be run in the playground.** (`core/playground/bundle.py`, `extract_to_temp`)
   - If a ZIP held the agent at `bundle/agents/demo/agent.yaml`, it was extracted to `temp/bundle/agents/demo`.
   - The `Registry` only looks at the direct children of the temp dir, so it saw `temp/bundle`, found no `agent.yaml` there, and the playground run failed with an unknown-agent error.
   - The agent folder is now always a direct child of the temp dir: `temp/demo`.
   - Regression test: `test_nested_root_is_loadable_by_the_registry`.
2. **`dataset_file: ./dataset.json` was reported as missing.** (`bundle.py`, `_load_config`)
   - The Registry reads from disk, where `./dataset.json` works fine. The bundle inspector, however, looked up the literal key `./dataset.json` in the archive and rejected a valid upload.
   - Paths taken from agent.yaml (dataset and metrics stub) are now normalised before the lookup.
3. **A `custom_tests.py` that is not UTF-8 (for example Latin-1) crashed the inspection.** (`bundle.py`, `_custom_tests_info`)
   - The UI showed a raw `'utf-8' codec can't decode byte 0xff…` error, and the whole upload was rejected.
   - It is now reported the same way as a syntax error: `custom_tests.py syntax error: the file is not UTF-8 text`.
4. **Raw bytes leaked into text scorers as `"b'hello'"`.** (`adapters/documents.py`, `_extract`)
   - `extract_text(b"hello", "text")` returned the Python repr of the bytes.
   - Likewise, base64 text or markdown with `output_kind="base64"` came back as the undecoded base64 string.
   - Bytes and base64 values are now decoded (UTF-8, with replacement) before the text, markdown and json handling.
   - The current callers only send PDF/DOCX here, so nothing that ships today was hit. The public function was still wrong, though.
5. **Unreadable golden documents silently became an empty string.** (`adapters/golden_files.py`)
   - A corrupt PDF or DOCX golden file resolved to `""`, so every comparison against it would score 0 with no explanation.
   - It now raises `ValueError("golden_file broken.pdf could not be read as PDF: …")`.
   - A bad base64 payload in a data URL now gives a clear `ValueError` instead of a raw `binascii.Error`.
6. **Spreadsheet and presentation data URLs were parsed as DOCX.** (`golden_files.py`, `_kind_from_ctype`)
   - The code matched on `"officedocument"`, which also covers xlsx and pptx. These then failed extraction and came back empty.
   - It now matches `wordprocessingml` (and `msword`) only.
7. **Data URLs with parameters were rejected.** (`golden_files.py`)
   - `data:text/plain;charset=utf-8;base64,…` did not match the pattern, so it was reported as a malformed data URL.
   - Parameters are now accepted.
8. **7z support would break on the next py7zr upgrade.** (`core/playground/archive.py`)
   - py7zr 1.0 removed `SevenZipFile.readall()`, and the dependency is unpinned in pyproject.toml.
   - `_7z_payloads` uses `readall()` when it exists and otherwise extracts into a private `TemporaryDirectory`.
   - Both paths are tested. The fallback is tested with a real archive wrapped to hide `readall`.
9. **Two tests could never run** (these were the 2 "skipped" in the suite): `test_pdf_skips_without_pypdf` and `test_docx_skips_without_docx`.
   - They skipped whenever pypdf or python-docx was installed, which is always the case.
   - They now simulate the missing library with `monkeypatch.setitem(sys.modules, "pypdf", None)` and really check the `DocUnavailable` message.

###### Clearer messages for non-technical users (shown by the playground UI)
All of these messages still come through the existing `ValueError`, so they still reach the UI as HTTP 400 `detail` text or as validate `errors[]`.
- **No agent.yaml / more than one agent.yaml:** the old single message ("Upload exactly one agent configuration folder containing one agent.yaml.") is now two messages:
  - `No agent.yaml was found in the upload. The archive must contain one agent folder with an agent.yaml file.`
  - `The upload contains 2 agent.yaml files (a/agent.yaml, b/agent.yaml). Upload one agent folder at a time.`
- **Invalid ZIP:** `The uploaded file is not a valid ZIP archive, or it is damaged. Upload a .zip or .7z file that contains your agent folder.`
- **Invalid 7z** (the constructor, header or CRC failed): `The uploaded file is not a valid 7z archive, or it is damaged. Try creating the archive again.` The technical cause is logged at INFO.
- **py7zr missing:** `7z archives are not supported on this server (the py7zr package is not installed). Upload a .zip file instead.`
- **agent.yaml and dataset errors:** these keep their stable prefixes, `agent.yaml is invalid: ` and `Dataset is invalid: `. The text after the prefix is now one short line instead of a multi-line pydantic or yaml dump with URLs:
  - YAML: `line 2: mapping values are not allowed here`
  - JSON: `line 1: Expecting property name enclosed in double quotes`
  - Pydantic: `agent_id: Field required`
  - Encoding: `the file is not UTF-8 text`
  - This comes from the new `_describe_error()` in `bundle.py`.

###### Other improvements and cleanup
- **`bundle.py`, custom scorer discovery:**
  - `custom_tests.py` is now parsed once instead of twice.
  - Declared scorer discovery now also recognises `@scorer(name="x")` and `@module.scorer("x")`, not just `@scorer("x")`. Without this, the validate endpoint under-reported declared scorers.
  - The discovery was split into `_decorator_scorer_name` to reduce complexity.
- **`bundle.py`, `_load_config`:** narrowed the broad `except Exception` to `(ValueError, yaml.YAMLError)`. Pydantic, JSON and Unicode errors are all `ValueError` subclasses.
- **`bundle.py`, dead code:** removed the check in `_normalise_files`. It raised "The selected agent folder does not contain agent.yaml.", which can never happen because the root is derived from where agent.yaml was found.
- **`archive.py`, dead code:** removed the `try/except` around `archive.list()`. The constructor has already parsed the header, so `list()` cannot fail on bad input.
- **`archive.py`, broad excepts:** the remaining broad excepts around py7zr now log before converting the error.
- **`documents.py`:** removed the unused `_DocUnavailable` alias. Only the test used it; production code uses `DocUnavailable`.

###### New and extended tests
- `test_documents_extract.py` (new):
  - real PDFs from `utils.build_text_pdf` and a real DOCX built with python-docx (paragraphs and a table);
  - base64 and URL outputs via `httpx.MockTransport`;
  - corrupt PDF and DOCX;
  - the type and encoding error messages;
  - detection edge cases;
  - golden files from disk and from data URLs.
- `test_playground_archive.py` (new):
  - real ZIP and 7z fixtures in memory;
  - every limit: blob size, file count, uncompressed size in both archive formats, symlinks, a directory-only ZIP, an empty 7z;
  - a corrupt 7z, using a stored (copy-filter) member so the CRC error is deterministic;
  - py7zr missing;
  - the py7zr ≥ 1.0 fallback;
  - `files_to_zip` limits and duplicates;
  - nested-root extraction.
- `test_playground_bundle.py` (new): manifest discovery, each config error message, file items (binary, non-UTF-8, BOM), and custom-test decorator discovery.
- `test_playground.py`: added PreviewRepository filters and baselines, and the scoped-registry cleanup paths.

###### Notes for the other agents and for the lead
- **UI / API:** the error wording above changed. The prefixes `agent.yaml is invalid: `, `Dataset is invalid: `, `Configured dataset file is missing: `, `Configured metrics stub file is missing: ` and `Unsafe zip path` are unchanged.
- **`load_golden_file()` is not called anywhere in the service.** `GoldenCase.golden_file` exists in the model, but no scorer resolves it. The helper is fully tested and ready to use; wiring it into the similarity scorers is a product decision, so I did not do it.
- **Out of scope (security), not changed:** a *compressed* 7z with deliberately corrupted LZMA data made py7zr 0.22's `readall()` spin forever. I saw this in an early version of the corrupt-archive test, and that run hung until I killed it (sorry). A crafted upload could therefore tie up a worker. Possible mitigations are a decompression timeout or running the extraction in a subprocess.

###### Coverage (line + branch, before → after)
| File | Before | After |
|---|---|---|
| core/playground/archive.py | 83% | 100% |
| core/playground/bundle.py | 84% | 100% |
| core/playground/preview_repo.py | 82% | 100% |
| core/playground/scoped_registry.py | 97% | 100% |
| adapters/documents.py | 79% | 100% |
| adapters/golden_files.py | 84% | 100% |


#### 9. Scripts (detail)

Before this pass none of the four Python scripts had a single test. Each now has its own test file, and none of those tests touch the network or a real database. HTTP calls go through `httpx.MockTransport`, and `db_smoke` runs against a real SQLite file in `tmp_path`.

New test files:
- `src\tests\test_scripts_ci_gate_client.py`
- `src\tests\test_scripts_ci_gate.py`
- `src\tests\test_scripts_db_smoke.py`
- `src\tests\test_scripts_refresh_goldens.py`

###### Clearer error messages

- **`ci_gate_client.py`, `check_health`: HTTP errors no longer say "unreachable".**
  - *What changed:* when the service answers with an HTTP error, the message now reads "answered the health check with HTTP 404; is --eval-url pointing at the evaluation service?".
  - *Why:* any HTTP status error (404, 503, and so on) used to be reported as "eval service unreachable". The server *was* reachable, so the message sent people looking for a network problem when the usual cause is a wrong URL or path.
- **`ci_gate_client.py`, `_json`: non-JSON responses become a `GateError`.**
  - *What changed:* a non-JSON body, such as a corporate proxy's HTML login page, now raises `GateError` with "response from … is not JSON: '<first 200 chars>'". The pipeline exits 2 (infrastructure error).
  - *Why:* previously `json.JSONDecodeError` escaped `GateError`. It ended up at the top-level guard as "unexpected failure: JSONDecodeError: Expecting value: line 1 column 1", which does not tell anyone what the server actually sent.
- **`ci_gate.py`, `resolve_agent`: separate messages for conflicting and missing agent ids.**
  - *What changed:* `resolve_agent` now raises `ValueError` with a specific message, and `main()` prints it.
    - For conflicting ids: "two different agent ids given: 'a' (positional) and 'b' (--agent)".
    - When no id is given: "give one agent id …".
  - *Why:* `ci_gate.py a --agent b` used to print "give one agent id", which is confusing when two ids were given.
- **`refresh_walkthrough_query_goldens.py`: failures print one plain line and exit 1.**
  - *What changed:*
    - New `ReplayError` and `_json_body()` helper.
    - `load_json` reports "cannot read <path>: …" and rejects a file that is not a JSON object.
    - HTTP status errors print "<url> answered HTTP 503".
    - Transport errors print "could not reach the agent at <url>: …".
    - A non-JSON or non-object reply is reported as such.
    - In each of these cases the script exits 1, and exit codes are now named constants.
  - *Why:* a missing file, a down agent or an HTML error page each used to produce a raw traceback. A non-object JSON reply crashed with `AttributeError: 'list' object has no attribute 'get'`.

###### Robustness

- **`ci_gate.py`: environment-variable defaults are handed to argparse as strings.**
  - *What changed:* the env defaults (`EVAL_TIMEOUT_SECONDS`, `EVAL_JUDGE_REPS`, …) are now passed to argparse as strings, through `_env_default`, so argparse applies `type=` to them.
  - *Why:* a typo such as `EVAL_TIMEOUT_SECONDS=twenty` used to raise `ValueError` inside `build_parser()`. That happens before the top-level guard, so CI got a traceback. It is now a normal usage error ("argument --timeout: invalid float value: 'twenty'", exit 2).
- **`ci_gate_client.py`, `wait_for_run_id`: tolerate a null `seq`.**
  - *What changed:* when `seq` is null or not an integer, the cursor now advances by the number of events received.
  - *Why:* previously `int(None)` raised `TypeError`.
- **`ci_gate_client.py`, `EvalClient.__init__`: `poll_interval` is clamped to be at least 0.**
  - *Why:* `--poll-interval -1` used to crash inside `time.sleep`.
- **`refresh_walkthrough_query_goldens.py`: split `main()` and skip malformed cases.**
  - *What changed:*
    - `main(argv=None)` now takes arguments; the upload-and-replay loop moved into `replay_all()`.
    - Cases that are not objects are skipped.
    - A case with no `id` no longer raises `KeyError`.
  - *Why:* this makes the script testable and keeps `main` short.

###### `db_smoke.py`

- **`check_adc` reads the configured database URL.**
  - *What changed:* `check_adc` now reads `Config.DB_URL`, the value `build_repository()` actually uses, instead of the raw `EVAL_DB_URL` env var. See bug 1 below.
- **New `fell_back_to_sqlite()` check.**
  - *What changed:* when a postgres URL is configured but the repository came back as SQLite, the script prints "[FAIL] CloudSQL was configured but could not be reached; the repository fell back to SQLite" and exits 3. See bug 2 below.
- **Type hints and named exit codes.**
  - *What changed:* added type hints (`RunRecord`, `EvaluationRepository` via `TYPE_CHECKING`) and named exit-code constants (`EXIT_OK`, `EXIT_NO_ADC`, …). The numeric values are unchanged.

###### Bugs found while testing

1. **`db_smoke.check_adc` looked at the wrong setting.** It decided whether to check Google credentials from the `EVAL_DB_URL` env var only. `build_repository()` uses `Config.DB_URL`, which can also come from the YAML config (`database.url`). With a postgres URL in YAML and no env var, the ADC check was silently skipped.
2. **`db_smoke` reported success after falling back to SQLite.** With `EVAL_ALLOW_SQLITE_FALLBACK=1`, an unreachable CloudSQL made `build_repository()` quietly return SQLite. The smoke test then printed "SUCCESS - the evaluation service repository is live". A CloudSQL smoke test must fail in that case, and it now does.
3. **`ci_gate`: a bad env value crashed with a traceback** before the error guard ran (see Robustness).
4. **`ci_gate_client`: a non-JSON body or a null `seq`** escaped as `JSONDecodeError` / `TypeError` instead of a `GateError` (see above).
5. **`refresh_walkthrough_query_goldens`: a non-object JSON reply** crashed with `AttributeError` (see above).

###### Coverage (line + branch)

| File | Before | After |
|---|---|---|
| scripts\ci_gate.py | 0% | 100% |
| scripts\ci_gate_client.py | 0% | 100% |
| scripts\db_smoke.py | 0% | 100% |
| scripts\refresh_walkthrough_query_goldens.py | 0% | 100% |

---

#### Bugs found while testing (all areas, in one list)

The playground, documents and scripts sections above give the full detail for their own items.

1. **Safety veto blind to documents.** `no_pii_leakage`, `prompt_injection_safe` and `refusal_appropriate` scanned document bytes as a `b'...'` repr and ignored adapter-extracted text (section 2).
2. **Spot-check assertions matched JSON keys.** An absent check on a word such as "content" or "paragraphs" false-failed on report bundles, and byte outputs were searched as a repr (section 2).
3. **`json_schema_valid` ignored `types` for keys that are not required**, so a types-only config always scored 1.0 (section 2).
4. **JSON Schema `enum` and `const` treated `true`/`false` as equal to `1`/`0`** (section 2).
5. **`embedding_similarity` silently truncated vectors of different sizes** (section 2).
6. **A stale judge flag** made a later plain scorer with the same name a judge scorer (section 2).
7. **A corrupt `metrics_stub.json` failed the entire run** at start-up (section 5).
8. **`build_text_pdf(str)` put one character on each line** (section 5).
9. **Two adapter classes with the same name** replaced each other without a warning (section 5).
10. **The saved skip reason for a crashed scorer had no "Scorer error" prefix**, so the saved report could not tell it from an ordinary skip (section 3).
11. **Playground:** agent folders nested in the archive could not be run, and `./dataset.json` was reported as missing.
12. **Playground:** a non-UTF-8 `custom_tests.py` crashed the inspection.
13. **Documents:** `extract_text(bytes, "text")` returned `"b'…'"`, and base64 text was not decoded.
14. **Golden files:**
    - an unreadable golden PDF or DOCX silently became `""`;
    - xlsx and pptx data URLs were treated as DOCX;
    - data URLs with `;charset=` were rejected.
15. **py7zr 1.0 removed `readall()`.** The dependency is unpinned, so 7z uploads would have broken on the next upgrade.
16. **The 2 "skipped" tests could never run** in any real environment.
17. **`db_smoke.py` read the wrong database URL**, and it reported success after silently falling back to SQLite.
18. **`ci_gate.py` and `ci_gate_client.py`:**
    - a bad env value crashed with a traceback;
    - a non-JSON reply or a null `seq` escaped as a raw exception;
    - a negative poll interval crashed.
19. **`refresh_walkthrough_query_goldens.py` crashed or printed tracebacks** on replies that were not JSON objects, on missing files and when the agent was down.

#### New test files (this pass)

- **Scorers:**
  - `test_vertex.py`
  - `test_scorers_similarity.py`
  - `test_scorers_document_tables.py`
  - `test_scorers_judge_errors.py`
  - `test_configurable_json_edges.py`
- **Adapters and service:** `test_adapters_misc.py`, `test_service_http_errors.py`
- **Core:** `test_core_edges.py`
- **Agents:** `test_agent_custom_tests_more.py`, `test_sample_agents_entry.py`
- **Playground and documents:**
  - `test_documents_extract.py`
  - `test_playground_archive.py`
  - `test_playground_bundle.py`
- **Scripts:**
  - `test_scripts_ci_gate.py`
  - `test_scripts_ci_gate_client.py`
  - `test_scripts_db_smoke.py`
  - `test_scripts_refresh_goldens.py`

I also extended these existing files: `test_scorers_deterministic`, `test_configurable_text`, `test_configurable_advanced`, `test_safety`, `test_scorers_operational`, `test_scorers_base`, `test_config`, `test_aggregation`, `test_registry`, `test_metrics_api`, `test_adapters_http_response`, `test_http_adapter`, `test_target_agent_main`, `test_core_labels_utils`, `test_playground` and `test_documents`.

None of the tests use the network. Google auth and LangChain are faked in-process; HTTP goes through `httpx.MockTransport`; archives, PDFs, DOCX files and SQLite databases are real files built in `tmp_path` or in memory.

#### Not changed (flagged for a decision)

- **Golden files are not wired in.** `GoldenCase.golden_file` exists, and `load_golden_file()` is now fully tested, but no scorer resolves it. A case that sets only `golden_file` therefore skips the reference scorers with "no golden_output to compare". Connecting them is a product decision.
- **Crafted 7z uploads can hang a worker (security, out of scope).** A deliberately corrupted compressed 7z can make py7zr 0.22 spin forever. Possible mitigations are a decompression timeout or running the extraction in a subprocess.

#### Coverage per file (line + branch, before -> after)

The table covers every file owned by this area. Files that were already at 100% and stayed there are included for completeness. The baseline was measured at the start of this pass with the same command.

| File | Before | After |
|---|---|---|
| scripts/ci_gate.py | 0% | 100% |
| scripts/ci_gate_client.py | 0% | 100% |
| scripts/db_smoke.py | 0% | 100% |
| scripts/refresh_walkthrough_query_goldens.py | 0% | 100% |
| src/agents/preliminary_research_agent/custom_tests.py | 93% | 100% |
| src/agents/scoping_summary/custom_tests.py | 80% | 100% |
| src/agents/walkthrough_query_agent/custom_tests.py | 87% | 100% |
| src/main/adapters/capture.py | 90% | 100% |
| src/main/adapters/documents.py | 79% | 100% |
| src/main/adapters/golden_files.py | 84% | 100% |
| src/main/adapters/http_adapter.py | 100% | 100% |
| src/main/adapters/http_request.py | 78% | 100% |
| src/main/adapters/http_response.py | 94% | 100% |
| src/main/adapters/metrics_api.py | 94% | 100% |
| src/main/adapters/registry.py | 89% | 100% |
| src/main/adapters/target_agent.py | 96% | 100% |
| src/main/adapters/templating.py | 86% | 100% |
| src/main/core/aggregation.py | 94% | 100% |
| src/main/core/case_processor.py | 97% | 100% |
| src/main/core/config.py | 88% | 100% |
| src/main/core/labels.py | 97% | 100% |
| src/main/core/metric_scoring.py | 93% | 100% |
| src/main/core/models/dataset.py | 100% | 100% |
| src/main/core/models/results.py | 100% | 100% |
| src/main/core/playground/archive.py | 83% | 100% |
| src/main/core/playground/bundle.py | 84% | 100% |
| src/main/core/playground/preview_repo.py | 82% | 100% |
| src/main/core/playground/scoped_registry.py | 97% | 100% |
| src/main/core/run_builder.py | 100% | 100% |
| src/main/core/run_events.py | 93% | 100% |
| src/main/core/runner.py | 92% | 100% |
| src/main/core/structured_logging.py | 100% | 100% |
| src/main/registry/__init__.py | 96% | 100% |
| src/main/scorers/_util.py | 93% | 100% |
| src/main/scorers/base.py | 87% | 100% |
| src/main/scorers/configurable.py | 100% | 100% |
| src/main/scorers/configurable_advanced.py | 100% | 100% |
| src/main/scorers/configurable_json.py | 87% | 100% |
| src/main/scorers/configurable_text.py | 94% | 100% |
| src/main/scorers/deterministic.py | 84% | 100% |
| src/main/scorers/document_structure.py | 80% | 100% |
| src/main/scorers/document_tables.py | 87% | 100% |
| src/main/scorers/json_schema_check.py | 91% | 100% |
| src/main/scorers/judge_invoke.py | 96% | 100% |
| src/main/scorers/judge_prompts.py | 100% | 100% |
| src/main/scorers/llm_judge.py | 94% | 100% |
| src/main/scorers/operational.py | 95% | 100% |
| src/main/scorers/output_text.py | 64% | 100% |
| src/main/scorers/rubric.py | 97% | 100% |
| src/main/scorers/safety.py | 92% | 100% |
| src/main/scorers/similarity.py | 63% | 100% |
| src/main/scorers/trajectory.py | 83% | 100% |
| src/main/scorers/vertex.py | 44% | 100% |
| src/main/service/http_client.py | 100% | 100% |
| src/main/service/http_errors.py | new file | 100% |
| src/main/utils.py | 100% | 100% |
| src/sample_agents/_common.py | 96% | 100% |
| src/sample_agents/data_extraction_agent.py | 91% | 100% |
| src/sample_agents/document_qa_agent.py | 97% | 100% |
| src/sample_agents/invoice_parser_agent.py | 89% | 100% |
| src/sample_agents/report_writer_agent.py | 91% | 100% |

### UI second pass: shared layer, dashboard, live evaluation page

Audience: business staff at a financial institution, most of them not technical. Every change
below is about letting them understand a result at a glance without tooltips, jargon or raw data.

#### Shared layer (used by every page)

##### Type and colour (css/tokens.css, base.css)
- **Raised the type scale.** Body text is now 16px and secondary text 15px, and nothing is below 13px (it was 11–14px). The pages are read, not scanned, and many readers are not used to dense technical tools.
- **Added `--control-h` / `--control-h-lg`** so buttons and inputs are large and easy to hit.
- **Added `--on-fail`, plus a solid style for `button.button-danger`.** The "Stop evaluation" confirm button in dialogs used to show red text on the blue gradient, which was unreadable. It is now readable text on red in both themes (AA).

##### Components (css/components.css; short rules collapsed to one line to stay under 300 lines)
- **`.verdict-chip` badge (+ `-pass/-fail/-error/-cancelled`, `-lg`):** icon + word + colour for every verdict, so the meaning never depends on colour alone. It is named `verdict-chip` so it does not clash with the report page's own `.verdict` panel.
- **`.trend` (`.trend-up/-down/-same`):** an arrow plus words ("↓ 7 points lower than last time"), so a change is readable without knowing what a "delta" is.
- **`.tech-details` and the new `.tech-details-inline` variant:** the single collapsed "Technical details" section where ids, raw errors and logs now live, out of the main view. The inline variant is for messages and cards (the tools agent asked for it).
- **`.button-lg`, `a.button`, `a.button-secondary`, `.action-row`:** large verb buttons ("Open full report", "Start again") that can also be links.

##### Vocabulary (js/lib/wording.js), the one source for plain words
- Added `outcomeKind(run)`, which treats an ERROR run whose detail is "cancelled" as **Stopped**. A person pressed Stop; calling that "Could not finish" would suggest something broke.
- Added `assistantName()` (display name, falls back to `humanizeId(agent_id)`, drops a trailing "Agent"), `testName()`, `checkName()`, `countOf()`, `scoreText()` ("No score" rather than a dash), `comparedToPrevious()`, `trendArrow()`, `progressSentence()` ("2 of 5 tests done"), `TEST_STATES` / `TEST_STATE_ICONS` (Waiting / Checking… / Passed / Needs attention / Not checked / Not finished), `PLAIN_ERRORS`, `plainRunError()`, `plainRequestError()` and `HEALTH_WORDS`. Raw server text is never the main message now.
- `passedOutOf()` now says "0 of 1 test passed" (singular) instead of "0 of 1 tests passed".
- **Skip reasons are shared:** the report page's rules moved to the new `js/lib/skip-reasons.js`, and `run-detail/skip-reasons.js` is now a re-export, so the live page and the report give the same sentence ("The AI reviewer was not available, so this check was not run."). Before, the live page called an embedding outage "the AI reviewer".
- The metric catalogue's fallback description ("An evaluation criterion for this case.") is now empty, because it was jargon that added nothing.

##### Fragments and fetch (js/lib/fragments.js, api.js)
- New `verdictBadgeHtml()`, `trendHtml()` and `technicalDetailsHtml(rows | text, {inline, extraHtml, title, id})`, all escaped. Other pages can build the same plain building blocks.
- New `fetchOptionalJson()`, which resolves null on 404/405/501. The dashboard uses it for the new `/api/runs/summary` endpoint and falls back to computing the figures itself.

##### Small quality fixes (js/ui/*, combobox.js)
- Repeated attribute names became constants, and the empty `catch` in the theme code now logs at debug level (SonarQube rules). Behaviour is unchanged.

#### Dashboard (index.html, js/dashboard/*, css/pages/dashboard.css)

> **Reverted.** The dashboard redesign described in this section was rolled back to the pass-1 dashboard.
>
> **Why:** the redesign assumed the service runs all the time and keeps evaluating every assistant. It led with "How are our AI assistants doing?", showed a card per assistant and a last-30-days summary. In practice, the evaluation service is used as a CI gate, where a detected regression blocks a release. For that job, the regression, baseline and "needs attention" views, and the full run history with run ids, are what matter.
>
> **What was restored:** the pass-1 `index.html`, `js/dashboard/*` and `css/pages/dashboard.css`. These bring back:
> - the stat cards (average score, pass rate, Regressions, Needs review);
> - Latest evaluation;
> - Baseline context;
> - the Needs attention list;
> - the score trend;
> - the evaluation history with search and the Failures / Regressions / Low scores / Improved filters.
>
> **What was removed:** the pass-2 dashboard modules (`assistants.js`, `start-form.js`, `tech.js`, `view-model.js`) and their two JS test files. A copy is kept in `scratchpad/backup/dashboard-pass2/`.
>
> **What stays from pass 2:** the shared layer (larger type, `wording.js`, components), the live run and report pages, the tools pages, and every API addition, including `/api/runs/summary`. The restored dashboard simply doesn't use the summary endpoint.
>
> The rest of this section describes the reverted design and is kept for the record.

- **Leads with the answer.** The page now opens with "How are our AI assistants doing?", a big verdict badge ("Needs attention" / "Passed") and one plain sentence: "1 of 4 AI assistants passed their latest evaluation. Needs attention: Document QA, Report Writer…". Previously the page opened on four stat cards and a form, and the reader had to work out the answer.
- **Removed the "Regressions", "Needs review", "Pass rate" and "Average score (delta vs previous run)" stat cards.** Non-technical staff don't know what a regression, baseline or delta is. They were replaced by three figures that need no explanation: "Evaluations in the last 30 days", "Passed: 10 of 12" and "Average score". These come from `GET /api/runs/summary`, or are computed from the run list if that endpoint is missing.
- **Removed the "Baseline context" panel and the "Needs attention" list.** Both repeated the cards below in technical terms ("comparison baseline", run ids).
- **New "Your AI assistants" cards:** one per assistant, showing the latest verdict (icon + word), the score as a whole percentage, "↓ 7 points lower than last time", "1 of 2 tests passed", "Last evaluated Today at 12:18 AM", and one **Open full report** button. Cards that need attention come first. A stopped evaluation does not replace an assistant's standing, because stopping says nothing about quality.
- **Assistants never evaluated** are one compact "Not evaluated yet" group of name buttons, not a card each. Five near-empty cards pushed everything important off the screen, especially on phones. Pressing a name selects that assistant in the Start form and moves focus to Start.
- **One obvious Start flow:** "Start an evaluation" → choose AI assistant → a big **Start evaluation** button. The "All agents" pseudo-choice and the always-visible "Assessments" number were removed. The number is now under "More options" as "Repeat each test (more reliable, slower)", default 1. Pressing Start with nothing chosen says "Choose an AI assistant first…" instead of silently doing nothing. The button is never disabled with no explanation.
- **"Score over time" chart:** one assistant at a time (with a simple picker; by default the one with the most history). The y axis is fixed at 0–100%, so small wobbles don't look dramatic, and it is drawn at the real pixel width so the axis text stays readable on phones. It has a one-sentence caption ("Report Writer: 3 evaluations shown. Latest score 50%, 7 points lower than last time.") and no reliance on hover titles. Mixing several assistants on one line, as before, was misleading.
- **"Past evaluations" list:** Result (verdict badge), AI assistant (display name), Score, "3 of 4 tests passed", "Today at 11:22", and an **Open report** link. Run ids, dataset versions and "Versus baseline" columns are gone. The filters are now plain ("All / Passed / Needs attention", with a ✓ on the active one so it is not shown by colour alone), replacing "Failures / Regressions / Low scores / Improved" and the search box. The list shows 20 rows at a time with a "Show more" button. On phones each row becomes a simple labelled card.
- **Header:** the TLS toggle ("TLS: Verify") moved into Technical details, because it is a support setting and is meaningless to most readers. The status pill now says "Working normally" / "Some checks unavailable" / "Service not reachable", not "Available/Degraded" with a hover title.
- **Technical details (collapsed, at the bottom):** service status, AI reviewer back end, credential type, last error, how many evaluations were loaded, where the figures came from, the cap notice, and the TLS switch.
- **Friendly empty, loading and error states** that say what to do next ("No evaluations yet. Choose an AI assistant above and press Start evaluation.", "We could not load… Refresh the page in a minute. If it keeps happening, contact support."). Raw error text only goes to Technical details and the console.
- Assistants whose `enabled` is false are still offered in the picker, after the others, marked "Not in regular use", because they can still be run.

#### Live evaluation page (run.html, js/run-live/*, css/pages/run-live.css)

- **A plain progress story:** "Evaluating Report Writer…", "2 of 5 tests done", then a big 22px progress bar (`role=progressbar`, and an `aria-live` sentence for screen readers). The five meta tiles (Agent id, Dataset version, Cases, Concurrency, Independent assessments) moved to Technical details. They were jargon at the top of the page.
- **Then the verdict:** a big badge (✓ Passed / ! Needs attention / × Could not finish / ■ Stopped), a headline ("Document QA needs attention"), one plain sentence, and three simple figures: Score 79%, Tests "1 of 2 tests passed", Benchmark "↓ 17 points lower than the benchmark". Below them sits one primary button, **Open full report**, with **Back to dashboard** next to it. The score ring and the "FAIL" stamp are gone because they repeated the same information in a less readable way.
- **Per-test rows** now show a plain status with an icon (Waiting / Checking… / Passed / Needs attention / Not finished), the test's readable name ("Q1 financial summary" rather than `q1_financial_summary`) and its score. They are listed in order, with a "3 more tests waiting" line. The old per-criterion cards (weights, "Model assessment", "Mandatory", meters, rationale) were removed from the main view.
- **"Show checks" disclosure per test:** each check in plain words, e.g. "! Needs attention · Key findings present · Scored 67%; needs at least 70%" or "Not checked · The AI reviewer was not available, so this check was not run". It also shows the start of the assistant's answer. Checks that did not apply to a finished test are hidden, and a stopped test with nothing run shows no disclosure, so readers aren't shown a wall of "Not checked".
- **Stop evaluation** is a large button that asks for confirmation in plain language: "Stop this evaluation? Tests that have not finished will not be scored, and there will be no overall result…", with the buttons "Keep going" and "Stop evaluation". While it stops, the page says "Stopping… tests that have not finished will not be scored."
- **Errors never show raw server text as the main message.** Examples: "The AI assistant could not be reached, so there is no result. Please try again later.", "This AI assistant could not be found. Go back to the dashboard and choose another one.", "No AI assistant was chosen…". When the evaluation never started, the title is "The evaluation could not start", the empty Tests panel is hidden, and only "Back to dashboard" is offered ("Try again" makes no sense for an unknown assistant). Other failures offer **Try again**, and a stopped evaluation offers **Start again**.
- **Technical details (collapsed, at the bottom):** assistant id, test set and version, run id, stream id, repeats, concurrency, raw status, weighted score/delta, error detail, HTTP status, error type and reference, a per-test log (model, latency, tool calls, raw skip reasons), and a "Copy technical details" button for sending to support.
- The header status pill and the TLS toggle were removed; the verdict in the page is the status. The page title and header tagline change to the verdict when the evaluation finishes.
- Internals: the event handling is now a pure model (`model.js`) and pure view builders (`view.js`), unit-tested without a browser. `error.js` was replaced by `tech.js`.

#### Tests (src/tests/js)
wording (extended), lib-format, lib-fragments, lib-api-reps-catalog, dashboard-view-model and dashboard-chart-data (both since removed with the dashboard revert), run-live-model, run-live-view and run-live-stream: 79 tests across my files, all passing. The whole JS suite has 196 tests, and pytest `test_js_units.py` passes. The pure modules have 100% line coverage.

### Evaluation report page, second UI pass (plain language)

> **Superseded.** The plain-language report described in this section was replaced by the "Run detail page rework (after user feedback)" below. The user found it too simplified for reviewing a CI gate result (the agent output vs golden output per case was gone). The pass-1 report was restored and extended, and the pass-2 modules listed here were removed (a copy is kept in `scratchpad/backup/run-detail-pass2/`).
>
> The rest of this section describes the superseded design and is kept for the record.

Audience: business staff at a financial institution, most of them not technical. The goal of this pass is that anyone can open a report and understand it without tooltips, a glossary or help from an engineer.

#### Page structure (run_detail.html)
- **The page now opens with the answer.** The first panel shows a large verdict made of a word, an icon and a colour (Passed ✓ / Needs attention ! / Could not finish × / Stopped ■), then the AI assistant's display name, "Evaluated Today at 11:22", and one sentence such as "Report Writer did not meet the required standard. 1 of 2 tests passed. Its score is 50%, 43 points lower than the benchmark." *Why:* the reader's first question is "did it pass?", so that is answered before anything else, and never by colour alone.
- **Three simple figures sit under the sentence:** Score, Tests passed ("1 of 2") and Benchmark ("93%", with "↓ 43 points lower" underneath). They are hidden for stopped or unfinished evaluations. *Why:* big, familiar numbers are easy to take in, and a partial score shown next to "Stopped" would contradict the verdict.
- **New "What needs attention" panel.** It has one line per problem test, in everyday words, e.g. "Risk assessment report: required sections are missing and key figures are missing". Each test name links to that test and opens it. Checks that were not run are summed up in one line, e.g. "2 checks were not run because the AI reviewer was not available." Passed evaluations that still have small issues get the title "Worth a look". Evaluations that could not finish get "What went wrong" with a plain sentence. *Why:* readers see what to act on without opening anything.
- **The test list replaces the old "Case performance" table, the "Case details" list, and their search, status filter and sort controls.** Each test is one row with its verdict badge, its name, "3 of 5 checks passed, 1 not checked", "Score 50%" and a visible "Show checks ▾ / Hide checks ▴" label. Failed tests are listed first. Filter buttons (All / Need attention / Passed) appear only when there are more than 6 tests. *Why:* one list is simpler than a table plus a list, and the visible "Show checks" text means nobody has to discover by hovering that a row can be clicked.
- **Inside a test, each check shows** its plain title, a Passed / Needs attention / Not checked badge, and a one-line reason:
  - Failed checks state the problem, e.g. "Required sections are missing."
  - Passed checks state what was confirmed.
  - Checks that were not run state why, in plain words.

  A small "Must pass" tag marks mandatory checks. The explanation, evidence, score against the required level and benchmark comparison sit behind a small "Show details" disclosure. "Show the AI assistant's answer" and "Show the expected answer" let the reader look at the actual text. *Why:* the reason is readable at a glance, and the detail is still there for anyone who wants it.
- **The benchmark action is reworded.** It is a "Benchmark" panel with one explanatory sentence and a "Make this the new benchmark" button. The confirmation dialog says "Future evaluations of Report Writer will be compared against this one." For an evaluation that did not pass, a warning explains that this would make future results easier to beat. The confirm button reads "Yes, make it the benchmark". The panel is hidden for evaluations that were stopped or could not finish. *Why:* "Promote baseline" is jargon, and promoting a failed or incomplete result by accident is a real risk.
- **The downloads are renamed** "Download PDF report" and "Download spreadsheet (CSV)", and the files get friendly names such as `evaluation-report-writer-2026-09-28.pdf`. *Why:* people know what a PDF or a spreadsheet is, but not what "Export CSV" means.
- **All technical material moved into one collapsed "Technical details" area at the bottom.** It holds:
  - the evaluation ID and a copy button, the AI assistant ID, the test set and its version, who started the evaluation, the exact timestamp and the recorded status
  - the raw error message
  - statistics: pass rate, mean, standard deviation, confidence interval, drift p-value, and expert-label agreement
  - a "Results by check" table with required scores, weights and must-pass flags
  - the raw messages for checks that were not run
  - the word-by-word comparison with the expected answer
  - the full JSON record

  The comparisons and the JSON are only built when opened. *Why:* auditors still get everything, but nobody else meets terms like "weighting", "mean", "criterion roll-up", "p-value", "drift" or "coverage" unless they choose to.
- **Removed from view:** the "How much weight this result carries" reliability panel, the "Criterion summary" roll-up, the "Baseline management" grid and the "Run details" panel. What they said is now in the verdict sentence, the attention panel or Technical details.
- **The error state is friendlier.** "We couldn't load this report. Try again, or go back to the dashboard." offers "Try again" and "Back to the dashboard" buttons, and the raw error text sits under a "Technical details" disclosure. A missing report reads "We couldn't find this report. It may have been removed." *Why:* people should get reassurance and a next step, not a stack message.

#### Visual changes (css/pages/run-detail.css, run-detail-diagnostics.css)
- **Text is larger:** body text is 16px, secondary text 15px, the verdict sentence 19px and the verdict word 24px. Buttons are at least 44px tall. *Why:* easier to read for everyone, including on shared screens and on phones.
- **One colour token per state drives the badge, the side stripe and the icon.** Filled badges use the existing on-accent text colour, which meets AA contrast in both themes. The navy/blue dark theme and the cream light theme are unchanged. *Why:* consistent, and never colour-only.
- **Phone layout:** figures become label/value rows, test rows stack, the download and benchmark buttons span the full width, and the technical tables stack each row with its labels. Nothing depends on hover.

#### Wording logic (new DOM-free modules, all unit-tested)
- **`report-model.js`:** the verdict sentence, the key figures, the "What needs attention" items (phrases are joined in plain English, capped at 3 with "and N other problems") and the benchmark wording. It uses the shared `outcomeKind`, so a run stopped by a person ("ERROR" with detail "cancelled") shows as "Stopped". It also uses the shared `assistantName`, `plainRunError` and `passedOutOf`.
- **`check-phrases.js`:** an everyday "what went wrong" phrase for each catalogue check (e.g. `total_correct` → "the invoice total is wrong"), with a fallback that names the check.
- **`skip-reasons.js`:** maps the technical reasons for checks that were not run to plain sentences. For example, "LLM judge unavailable…" becomes "The AI reviewer was not available, so this check was not run." It also covers missing expected answers, the meaning-comparison service, timeouts, a busy reviewer, missing components, unreadable documents, mis-set checks and generic errors, with a fallback of "This check could not be run."
- **`check-model.js`:** view models for each test and check, check ordering (problems first, then not checked, then passed, with "for information only" checks last) and test names (the shared `testName`).
- **`technical-model.js` / `technical-html.js`:** the Technical details content.
- **`page-model.js`:** the friendly error copy, download file names and pill colours.
- **`report-html.js`:** HTML builders, with every interpolated value escaped.
- **`preview.js` / `diff.js`:** now pure. Their labels were reworded ("Text taken from the Word document", "Only in the expected answer" / "Only in the AI assistant's answer"). The markdown link-scheme hardening from pass 1 is kept unchanged.
- **Deleted:** `summary.js`, `cases.js` and `case-metrics.js`, which built the old technical tables and are replaced by the modules above.

### UI pass 2: Config Playground and API tester

Audience: staff at a financial institution, most of them not technical. These two pages are for the people who set up AI assistants, so they stay powerful, but every label, status and error is now in plain words and the flow explains itself.

#### Config Playground

| Change | Why (for the audience) |
|---|---|
| New step list at the top: **1 Load settings, 2 Check settings, 3 Try it, 4 Save a copy**. Each step has its own button, a one-line status (for example "No problems found", "2 problems to fix", "Running… 1 of 2 tests done", "Last result: Passed · 82%") and a visible word: Done / Next / In progress / Needs attention. | The page explains what to do next without tooltips or a manual. The state is shown as a word and a symbol as well as colour, so it doesn't depend on colour alone. |
| Buttons for steps 2–4 stay hidden until settings are loaded. The Run button becomes **Stop evaluation** while an evaluation runs. | Before this, a greyed-out blue Run button looked clickable. One place to start and one place to stop. |
| Load panel reworded: "Drop your settings file here, or choose it from your computer", with one sentence explaining agent.yaml and dataset.json. The primary button is "Choose a file". | File names stay, but they come with a plain explanation of what they are. |
| Load errors appear under the drop area as a notice (for example "× This file could not be opened. This is not a readable .zip file."), not as a toast that disappears. The raw server message is under **Technical details**. | People can read the problem at their own pace; support staff still get the exact error. |
| "Validate" is now **Check settings**. Its result appears full-width under the steps: "✓ No problems found" or "! 2 problems to fix", with each server message translated (for example "Dataset contains no cases." becomes "There are no tests yet. Add at least one test to the test file."). The raw list is under Technical details. | Server wording is jargon. The translated sentence says what is wrong and how to fix it. |
| Any edit clears the earlier check and "saved" state, so the steps go back to "Check settings". | The step list never claims the settings were checked when they have changed since. |
| Results use the app vocabulary: a verdict card (✓ Passed / ! Needs attention / × Could not finish / ■ Stopped), the verdict sentence, "62% overall score · 1 of 3 tests passed", the AI assistant's name and a friendly date. Each test shows a verdict badge, and each check shows its plain title (from the metric catalogue), its score, "(needs 70%)" and the reason. Details and raw evidence are folded away. | This matches the dashboard and the report, so results mean the same thing everywhere. |
| Live progress reads "2 of 5 tests done" with sentences like "Asking the AI assistant: test q1" and "Checking “Key figures present” on test q1". | Before, it showed raw event names such as "metric_started". |
| Run errors are translated: "The AI assistant could not be reached. Check its address under “Try it”", "took too long to answer", "The AI reviewer is not available right now", and a stopped evaluation shows "■ The evaluation was stopped". A 409 on Stop shows "The evaluation had already finished." | Plain cause, plain next step, raw detail kept under Technical details. |
| The right-hand panel is now "Before you run": tiles for AI assistant / Tests / Checks / Test set, "Extra checks" (custom_tests.py) marked "✓ Found" or "! Has a mistake", a "Tests to include" list ("3 of 4 tests selected", Select all / Select none, each row labelled "Test <id>" with a preview), "Where to send the test questions" (empty by default; the agent.yaml address is the placeholder and appears in the note under the field), and "Reviews per answer (1 to 5)". | Every field says what it does in everyday words. If no test is selected, step 3 says "Choose at least one test to include" instead of just disabling the button. |
| The file list shows a plain role under well-known files ("Describes the AI assistant", "The tests and checks", "Extra checks", "Not a text file"). The section intro is "Configuration files: the settings that describe your AI assistant and its tests." The buttons are New file / Add from computer / Rename / Delete. | File names stay, and each one is explained next to it. |
| Editor: quick check "✓ No formatting problems" / "! Formatting problem: …" for JSON, and "Checked when you press “Check settings”" for YAML/Python. The state reads "You can edit this file" / "Changed". Find bar buttons are Next / Replace / Replace all / Close, and its messages are plain. | Before, it showed "JSON ✓", "Python syntax: server validation" and "Unsaved browser edit". |
| Dialogs: "Load different settings?" / "Undo all your changes?" / "Delete agent.yaml?", each with a sentence explaining the consequence ("The .zip file on your computer is not changed"). "Evaluator details" became **AI reviewer settings**, with plain row labels (for example "Answers reviewed at the same time", and "Sign-in method: Google Cloud (Vertex AI)"). | People know exactly what will happen before they confirm. |
| Compare dialog: "Compare two evaluations", "First evaluation" / "Second evaluation", options like "Yesterday at 10:12 · Passed · 73%", changes shown as "7 points higher" / "No change" / "Only in one", plus a "Checks that changed" column. The empty state explains that at least two evaluations are needed. | Before, the labels were "Run A/B", "+7 pts" and "Metric changes". |
| Readable sizes: body 16px, secondary text 15px, meta and code 14px. Buttons are at least 40–44px tall. The layout stacks cleanly at 500px with no sideways scroll. | Easier to read on meeting-room screens and laptops, and at phone width. |
| Header status pill uses plain states: "Nothing loaded yet", "Settings loaded", "Checking…", "Ready to try", "Running… 1 of 2 tests done", "Passed · 82%", "Stopped". | The page state is always visible in one word or phrase. |

Pass-1 fixes kept: no persisted stream, lastRun or environment; polling only after an SSE error (with an in-flight guard); a single cached IndexedDB connection with evaluation history in its own store; Esc releases the Tab trap; all interpolated data escaped. After a reload, the last stored evaluation is used as "Last result" for the step list. It is display only, so nothing gets stuck.

#### API tester

| Change | Why |
|---|---|
| Titled **Test a connection**, with one sentence of explanation. Simple mode by default: Type, Address, **Send request**, plus "Message to send" (format: JSON / Plain text / Form fields). The message box hides for GET/HEAD, and a sentence says why. | The basic job (send something, see the reply) needs no technical knowledge. |
| Headers, Sign-in (auth) and Query values are folded into "More options: headers, sign-in and query values", as accessible tabs (arrow keys, Home and End all work). Auth options are renamed: "Access token (Bearer)", "Username and password", and so on. | The full power is still there, but out of the way. |
| The reply leads with a plain summary line: "✓ Success (200 OK) in 305 ms", "! Not found. Check the address (404 Not Found) in 20 ms", "× The server could not be reached", "× The server took too long to answer", "× The server’s security certificate could not be checked", "× The evaluation service could not be reached". Then come the size, Technical details (for failures), the raw body, and a folded "Reply headers (n)". | The verdict comes first and the raw detail after, as the brief asks. |
| Form problems are shown as a plain notice with technical details: "That address does not look right. It should start with http:// or https://" (addresses without a scheme and non-http schemes are now caught before sending), and "The message to send is not valid JSON. Check for a missing comma, quote or bracket." | Before, it showed "Invalid URL: …" and a raw JSON parser message. |
| Recent requests: each entry shows "✓ 200" / "! 404" / "× No answer". Failed sends are recorded too. There is a friendly empty state and a short privacy note ("never passwords or messages"). The button is "Clear list". | Shows at a glance which requests worked. |
| Removed the `title` tooltip on the remove-row button, and changed its label from "×" to "Remove". Key/value placeholders are Name / Value. | No hover-only information; the label says what the button does. |

#### Structure (for maintainers)
- New DOM-free modules with unit tests: `playground/messages.js`, `results-model.js`, `steps-model.js`, `workspace-model.js`, `editor-model.js`, `find-core.js`, `compare-model.js`. There are also new DOM modules `steps.js` and `check.js`. The API tester has new pure helpers in `response-model.js` and `request.js`.
- The inline disclosure class is `.tech-note`, so it doesn't clash with the shared, section-sized `.tech-details` in components.css.

### Run detail page rework (after user feedback)

The user's feedback on the plain-language report was: "The run detail page has been too simplified. Even simple stuff like being able to see the agent output vs the golden output for each case are gone." The page is read by people reviewing a **CI gate result**, where a regression against the stored baseline blocks a release. They need detail, not a summary. So the page was reset to the pass-1 report and then extended. It uses the dashboard's vocabulary again: run, case, criterion, baseline, regression.

#### What was restored
- **The pass-1 files as the base:** `run_detail.html`, `js/run-detail/*` and `css/pages/run-detail*.css`. This brings back the outcome header with stamp, score ring, cases passed, baseline and change vs baseline. It also brings back the "How much weight this result carries" statistics, the criterion summary, the case performance table, the filterable case list with the `?case=<id>` deep link, baseline management with the confirm dialog, and run details with the raw JSON.
- **Removed:** the pass-2-only modules (`check-model`, `check-phrases`, `page-model`, `report-html`, `report-model`, `technical-html`, `technical-model`, `technical-view`, `tests-view`, and the `run-detail/skip-reasons.js` re-export) and their tests. A grep confirmed nothing else imported them. `js/lib/skip-reasons.js` stays as the shared copy. Its tests were kept and pointed at it as `lib-skip-reasons.test.mjs`. A copy of the pass-2 page, modules, CSS and tests is in `scratchpad/backup/run-detail-pass2/`.
- **Pass-1 hardening kept:**
  - the markdown link-scheme allowlist (http, https, mailto) with `rel="noopener noreferrer"`;
  - every interpolated value escaped;
  - a load error state with Retry, hidden for 404;
  - a guarded clipboard that shows a toast when copying fails;
  - both `?run=` and `?run_id=` accepted.

#### What was improved, and why
- **Header:**
  - the agent's display name (the new `agent_name` field), with the `agent_id` chip next to it, the dataset and version, when the run happened and who triggered it (`created_by`, e.g. "CI/CD pipeline (CI_CD)");
  - the PASS / FAIL / ERROR / CANCELLED stamp and the weighted score;
  - cases passed x/y, the baseline score, and the change vs baseline in pts. A regression turns that tile red and adds "▼ Regression" (plus "Statistically significant drift" when the drift test says so), so the signal is never colour alone.
  - A run with status ERROR and `error_detail` "cancelled" is shown as **CANCELLED**, with a neutral note. Any other `error_detail` appears in full in a red callout.
  - *Why:* the gate outcome and the reason for it are the first thing a reviewer needs.
- **Run statistics and reliability:** one tile each for cases passed, mean case score (with standard deviation), 95% confidence interval (flagged as a normal approximation), drift vs baseline (mean delta, p-value, significant or not), human agreement (F1, Cohen's κ, precision and recall when labels exist), and assessment coverage (criteria skipped, by name). Tiles use an icon as well as a coloured edge. *Why:* the pass-1 prose hid the actual numbers a reviewer weighs.
- **Criterion summary:** one real table with the title and id, a Critical flag, cases met x/y (plus "+N skipped"), mean score, threshold, weight (a number plus High/Medium/Low, shown as a range if cases differ), and mean delta vs baseline. Failing criteria sort first, then never-assessed, then critical. A **Skipped criteria** list below it shows, for each criterion and reason, the plain sentence from `js/lib/skip-reasons.js`, the raw reason in monospace, and the affected cases. *Why:* the pass-1 table had no threshold, delta or critical column, and it hid the raw reason in a tooltip.
- **Case performance table:** case, status (Pass / Fail / **Error** when the agent call failed), score, baseline, delta, and criteria met / not met / skipped. Regressed rows get a red edge and a "Regression" badge. Rows are focusable, open the case on click or Enter/Space, and have a visible focus ring.
- **Case details:** search now matches the case id **and its input**. New filters are "Agent call failed" and "Has skipped criteria", and there is a new "Highest score first" sort. An expanded case shows everything directly:
  - **Input:** the question/query/prompt as a quote, then the full payload as pretty JSON.
  - **Outputs:** "Agent output" and "Golden output (expected)" **side by side**. They stack below 900px. The agent output is rendered by format: markdown (hardened), JSON, report bundles as titled sections, extracted document text (e.g. "Extracted text (PDF)"), or plain text. The golden output is rendered as JSON, markdown or text. A "Side by side / Word diff" toggle (`aria-pressed`) switches to the word-level diff. Reference-only words are struck out in red and agent-only words are highlighted in green, with a legend. Past 3,000 tokens the diff falls back to plain side-by-side text with a note. The diff is only computed on first use. Search counts matches in both outputs, and there are copy buttons for each output. When there is no golden output, the page says so and shows the agent output full width. When the agent returned nothing, the agent column says so and points to the observation error.
  - **Observation:** target, model, latency, tokens (in / out / total plus any other usage keys), the tool-call count, and every metadata key. Bulky `raw_output` and `extracted_text` are summarised by length. Tool calls appear as a table of name, arguments and latency. Arguments over 160 characters fold into a disclosure. The stage trace appears when present. A failed agent call shows its full error in a red "Agent call failed" box.
  - **Criteria:** one table with criterion (title, id, Critical / LLM judge / **Unstable** / **Variance** badges, rationale, and an "Evidence (n)" disclosure), score, threshold, weight, baseline, delta, measured value with unit (e.g. "542 ms"), and a Met / Not met label. Below 720px, each row stacks with its labels.
  - **Skipped criteria for the case:** criterion, weight, threshold, and reason (the plain sentence plus the raw text).
- **Baseline management:** promotion is **disabled for ERROR and cancelled runs**, which the API answers with 409. A one-line reason sits under the button, and the button carries the same text as a title. Success and failure both show a toast, and the confirm dialog warns before promoting a FAIL run.
- **Run details:** run id with Copy, agent name and id, dataset, version, stored status, created by, local and raw timestamps, cases, and the raw JSON (loaded on open).

#### Structure
Every file is under 300 lines. Pure, DOM-free modules (unit-tested):
- `run-model.js`: header model, cancelled detection, promotion rules;
- `stats-model.js`;
- `criteria-model.js`: the criterion roll-up and skipped groups;
- `case-model.js`: row model, search, filter and sort;
- `values.js`;
- `preview.js`: output rendering and text extraction;
- `diff.js`;
- `markdown.js`;
- `case-io.js`, `case-observation.js`, `case-metrics.js`, `case-list-html.js`, `summary-html.js`: markup builders.

DOM modules: `main.js`, `summary.js`, `cases.js`, `output-controls.js` (view toggle, search, copy) and `baseline.js`. The CSS is split into `run-detail.css` (page and tables), `run-detail-case.css` (case list and body) and `run-detail-diagnostics.css` (criterion table, previews, markdown). An ESLint run with SonarJS rules over the page's JS and tests was clean: cognitive complexity ≤ 15, functions ≤ 50 lines, no duplicated literals, no nested ternaries, no `var`, `==`, unused variables or empty catches.

#### Tests and verification
- **JS tests:** new files `run-detail-models`, `run-detail-markdown-diff` and `run-detail-html` (27 tests), plus `run-detail-fixtures.mjs` and `lib-skip-reasons` (4 tests, moved). `node --test src/tests/js/*.test.mjs` runs **164 tests, all passing**, down from 178 because the deleted pass-2 modules' tests went with them. `pytest src/tests/test_js_units.py` passes.
- **Real data:** checked against a scratchpad copy of `eval_service.db`, served by a separate server on port 4840. The user's server and database were not touched. Runs covered:
  - FAIL runs with regressions and a skipped LLM-judge criterion (document_qa, DOCX/PDF extracted text);
  - scope_extraction with text and JSON outputs and tool calls;
  - walkthrough_query_agent with failed agent calls (observation errors, no output);
  - ERROR runs with a connection error callout.
- **Synthetic runs:** two were added only to the copy to cover a markdown output with an unsafe link, a report bundle, long tool arguments, an unstable/variance score, a skipped critical criterion, human labels and a cancelled run.
- **Headless Chrome:** screenshots in dark, light and at 500px, with no horizontal page scroll (wide tables scroll inside `.table-scroll`), and no console errors or exceptions through CDP. Also exercised: the word-diff toggle and search, keyboard opening from the case table, the promote dialog → toast, the `?case=` deep link, the 404 state (Retry hidden), and the CSV/PDF export endpoints.

---

## Visual redesign (Emil Kowalski design-engineering pass)

The reviewer verdict on the previous UI was "lots of tiny grey text and tons of tropes". This pass restyles all five pages (dashboard, live run, run report, playground, API tester) along the `emil-design-eng` skill and `apple-design` §14–16 (reduced motion, typography, foundations). It is a visual pass only: page logic, API calls, data flow and features are unchanged, and the dashboard and run report keep their reviewer-oriented content and layout order.

### Before | After | Why

| Before | After | Why |
| --- | --- | --- |
| SVG `feTurbulence` grain overlay on `body::before`, two radial "spotlight" gradients on the page background | Solid `--bg` | Decoration competed with data; a CI gate tool should read as a calm, serious surface |
| Panels with a `linear-gradient` fill, a gradient top hairline and a large drop shadow | Solid `--panel`, 1px `--line` border, no shadow | Shadows now only separate real layers (menus, dialogs, toasts), via one subtle `--shadow-pop` |
| Gradient primary buttons with a coloured glow on hover and `translateY(-1px)` lift | Solid `--accent-bg` (#2563eb, 5.2:1 with white), hover darkens the colour | One accent for interactive elements; no glow, no movement on hover |
| Header with `backdrop-filter: blur`, a gradient background and a gradient accent hairline; glowing app icon | Solid header on `--bg` with one 1px border; plain 22px icon | Removes the glassmorphism trope and the glow |
| Uppercase letter-spaced kickers and taglines ("EVALUATION HEALTH", "EVALUATION DASHBOARD"), uppercase table headers, uppercase `dt`/data-label labels | Sentence-case labels, weight 500; taglines and kickers deleted from the HTML | Typography carries hierarchy by size and weight (apple-design §15), not by shouting |
| `--fg-dim` / `--muted` used ~118 times, so most text rendered grey; `--fg` was warm cream (#f3efe6) on navy | Neutral `--fg` for almost all text; a single secondary tone `--fg-2` (8.5:1 dark, 8.1:1 light on panels) used only for genuinely secondary labels; the aliases were removed | Fixes the "tiny grey text" complaint; contrast ≥ 7:1 for secondary text in both themes |
| Hard-coded px sizes (13–24px) in page CSS; body 16px with 13–14px meta scattered around | rem type scale (`--fs-2xs` 13 → `--fs-3xl` 40), body 15px, tables 14px, 13px only for dense table meta (metric ids, chart axes) | Follows the user's text size; one scale used everywhere |
| Headings with positive letter-spacing (`.15px`, `.01em`) | Size-specific tracking: `--track-tight` (-0.02em) on titles and big numbers, `--track-snug` on section headings, body at 0 | Large text needs negative tracking (apple-design §15) |
| Numbers in proportional figures | `font-variant-numeric: tabular-nums` on tables, stats, scores and deltas | Columns and changing numbers stay aligned |
| Monospace for non-code values (agent chip, observation metadata, dataset version, stored status) | Monospace only for ids, code, JSON, tool arguments and raw outputs | Mono signals "machine value"; using it for prose values was noise |
| Rubber-stamp status (`stampHtml`) and SVG score ring (`scoreRingHtml`) in the run report | Both exports deleted from `fragments.js`; the header shows the shared status label and the score is a plain 40px tabular number | Decorative gauges duplicated the number and read as marketing |
| Status shown five different ways: pill with pulsing dot, bordered uppercase `status-label`, circled icon, verdict chip with a filled circle, test-state circles | One treatment everywhere: coloured symbol + word (✓ Pass, ✕ Fail, ! Error, ■ Cancelled), no pill, border or fill | Consistent and colour is never the only signal (symbol + word) |
| Pill/badge soup: every value, header status and filter in a rounded pill | Plain text values; one restrained 1px-border badge for attributes (Critical, LLM judge, Unstable, Regression); quick filters as a segmented control | Pills are reserved for nothing; badges only mark attributes |
| Decorative icon circles (`attention-icon`, `status-icon`, `notice-icon`, `summary-icon`, `result-icon`, numbered step circles), `↗` info icon and `→` row arrows | Plain coloured glyphs where they carry meaning, numerals for steps, the rest deleted | Icons in circles were ornament; arrows are kept only where they encode a trend (↑/↓) |
| Filler captions under nearly every heading, the "Baseline comparisons are attached to individual runs…" footer panel, "+ New evaluation", "sent to the agent" hint, playground/API lead paragraphs and dialog notes | Deleted from the HTML/JS (not hidden). Captions that carry real information stay: the skipped-criteria scoring rules, the agent-scope note that explains the disabled button, privacy notes in the API tester, the zip format note | Honest headings without restating the obvious |
| `.panel { animation: rise .45s }` on every page load, toasts entering with the same keyframe | No load animation | Content that is seen dozens of times a day must not animate in |
| Pulsing `.live-dot` and `.pill.running::before` (`pulse 1.1s infinite`), shimmer skeletons | Static markers; running state is a small 600ms spinner; skeletons are static neutral bars | Looping pulses are a trope and a vestibular trigger |
| `transition: transform .12s ease` lift on hover, no press feedback | `button:active { transform: scale(.97) }` with `transition: transform 160ms ease-out`; colour changes `150ms ease` | Presses feel heard (emil-design-eng "Buttons must feel responsive") |
| Hover styles applied on touch devices | Row, button, nav and list hovers gated behind `@media (hover: hover) and (pointer: fine)` | Avoids sticky hover on tap |
| Dialogs appeared instantly; toasts used `rise` keyframes and were removed instantly | Dialogs: `@starting-style` 200ms `--ease-out` from `scale(.96)` + opacity, centre origin, exit 140ms via `allow-discrete`. Toasts: same entry, `.toast-leaving` 140ms exit before removal | Never from `scale(0)`; exit faster than enter; transitions stay interruptible |
| Built-in `ease` curves | `--ease-out: cubic-bezier(0.23, 1, 0.32, 1)` token (plus `--ease-in-out`) | Built-in curves lack punch |
| Progress bars with `width .4s ease` and a glow | `width 300ms linear`, 6px solid bar | Constant motion uses linear timing |
| Spinners at 700–900ms | 600ms | A faster spinner makes loading feel faster |
| Combobox chevron rotated with a 150ms transition on open (often keyboard-triggered) | Flips without animation | Keyboard-triggered UI is not animated |
| `prefers-reduced-motion` block that zeroed every duration | Keeps colour/opacity transitions, removes press scale and dialog/toast scale, replaces spinning with an opacity "breathe" | Reduced motion means gentler, not none (apple-design §14) |
| Light theme on warm cream (#f6f1e8) with beige borders | Neutral near-white `#f7f7f8` / white panels; semantic colours darkened for AA (`--ok` #166534, `--warn` #92400e) | Clean neutral light theme; every semantic colour ≥ 4.5:1 |
| Dark theme on navy (#0c1018) with warm text | Near-black neutral `#0b0b0c` / `#111113` / `#18181b` | Neutral surfaces keep status colours meaningful |
| `Inter` / `JetBrains Mono` font stack (not loaded) | System stack (`system-ui, -apple-system, "Segoe UI", …`) and `ui-monospace, "Cascadia Mono", …` | The platform face ships optical sizing and hinting (apple-design §15) |

### Files and structure
- Rewritten: `css/tokens.css`, `css/base.css`, `css/shell.css`, `css/components.css`, `css/tools.css`, `css/pages/{dashboard,run-detail,run-detail-case,run-detail-diagnostics,run-live,playground,apitester}.css`; `css/combobox.css` restyled.
- New (to keep every file under 300 lines): `css/components-extra.css` (verdict word, trend, link buttons, technical details), `css/pages/dashboard-mobile.css`, `css/pages/playground-extra.css`. The `<link>` tags were added to the five pages.
- Markup: taglines removed from all five headers; filler captions and the baseline footer panel removed from `index.html` and `run_detail.html`; lead paragraphs and dialog notes removed from `playground.html` / `apitester.html`; `#stamp` and `#quality-ring` replaced by `#run-status`.
- JS (markup strings only): `lib/fragments.js` (ring and stamp deleted), `lib/wording.js` (verdict symbols aligned: fail ✕, error !), `dashboard/summary.js` (status label instead of icon + pill, attention rows without icon circles and arrows), `run-detail/summary.js`, `run-detail/case-list-html.js` (duplicate circled status icon removed), `run-detail/case-io.js`, `run-detail/case-metrics.js`, `run-detail/summary-html.js`, `run-live/render.js` (tagline write removed), `ui/toast.js` (140ms exit before removal).
- Tests: `lib-fragments.test.mjs` drops the ring/stamp assertions and asserts the status label markup; `playground-results.test.mjs` expects the aligned ✕ symbol.

### How the redesign was verified
- Private server on port 4850 against a scratchpad copy of `eval_service.db` (the user's :4002 server and database were not touched), restarted after each HTML edit.
- Headless Chrome over CDP: dashboard, run report with an expanded document_qa FAIL case, an ERROR run, `run.html` for an unknown agent, playground (empty, loaded + checked, AI reviewer dialog, finished evaluation) and API tester, each in dark, light and at 500px; plus dashboard search + quick filter, word-diff toggle, promote dialog and toasts. No console errors or exceptions, and no horizontal page scroll at 500px.
- `node --test src/tests/js/*.test.mjs`: 164 tests pass. `pytest -p no:cacheprovider -q`: 1055 pass.

---

## Score changes shown as percentages and raw values (after user feedback)

The user asked: "what's 'mean delta vs baseline'? And I want you to use percentages and raw numbers instead of points, that are a lot vaguer".

**What "Mean delta vs baseline" was.** A column in the run report's criterion summary. For each criterion it averaged `score − baseline` over the cases, a difference of two 0–1 fractions, and showed it as percentage points ("−12 pts"). Every other change on the site used the same points format: "−17 pts" on the run header and in the case tables, "5 points higher than last time", "N points lower than the benchmark", "±N pts since first shown". Readers could not tell whether −17 pts meant 96% → 79% or a 17% relative drop, and they never saw the two scores being compared.

**What replaced it.** One shared formatter, `js/lib/change.js` (`describeChange`, `changeSentence`), used by every page. The criterion summary column is now **Vs baseline**. It compares the criterion's mean score with its mean baseline, both averaged over only the cases that have a baseline for that criterion, e.g. "−12.5% (100% → 88%)". If no case has a baseline it shows "No baseline". The Delta columns in the case table and the per-case criterion table are now **Change**.

**Formatting rules**

- The relative change is `(current − baseline) / baseline × 100`, signed, with one decimal and a real minus sign (U+2212). When only the score and the delta are known, baseline = current − delta.
- The raw values always sit next to it as "baseline → current" in whole percents: "−17.7% (96% → 79%)". If both round to the same whole percent but differ, they get one decimal: "−0.5% (67.0% → 66.7%)". A real change never shows as "0.0%" (the minimum shown is 0.1%).
- No change (the scores match to a tenth of a percent): "No change (96%)".
- Baseline 0, where the relative change is undefined: only the values, "0% → 45%".
- No baseline or delta: "No baseline". "Not compared" and "No comparison" stay where the page already used them (case table, run header, dashboard history, dashboard baseline tiles).
- Missing current score: "—".
- Colour classes are unchanged: `delta-pos` for a rise, `delta-neg` for a fall and `delta-flat` for no change. Narrow table cells and the run header tile put the percentage on the first line and the values on the second (`.change-stack` / `.change-values`, at normal size and in the same colour).
- Sentences keep each page's words: "17.7% lower than the benchmark (96% → 79%)" on the live run page, "Same as the benchmark (90%)", "Higher than the benchmark (0% → 45%)".
- Charts keep percentage axis and point labels. The trend summary reads "↑ +245.7% (23% → 79%) since first shown". The average-score card reads "vs previous run: No change (79%)". Drift text reads "Mean case score versus baseline: −18.0% (96% → 79%), p = 0.157."
- Playground compare: "+33.3% (60% → 80%)". "Only in one" stays for a test or check that is present in just one of the two evaluations.

**Removed helpers.** `deltaPoints`, `formatSignedPoints`, `deltaClass`, `formatDeltaPts` and `deltaLabel` (format.js). `deltaHtml` (fragments.js, replaced by `changeHtml`). `comparedToPrevious` and `trendDirection` (wording.js). `pointsChange` and `changeClass` (playground compare-model.js, replaced by `scoreChange`). `trendHtml` and `comparedToBenchmark` now take `{current, delta}` or `{current, baseline}`. No "pts" or "points" wording is left in the UI.

**Exports.** The CSV keeps its ten columns in the same order and appends four raw-number columns: `case_baseline_score` (score − delta, blank when no criterion of the case had a baseline), `case_change_pct`, `baseline` (the criterion's stored baseline) and `change_pct` (relative change, one decimal, blank without a baseline or when the baseline is 0). The PDF never printed "pts", but its run line showed a bare "Delta: +0.123". The run line and each case line now print the same format in ASCII, because the PDF font is Latin-1: "Vs baseline: -18.0% (96% -> 79%)".

**Verified.** New `src/tests/js/lib-change.test.mjs` (12 tests) covers negative, positive, zero, sub-0.1% differences, baseline 0, missing baseline, missing current, rounding collisions, clamping and the minus sign. Existing JS tests that asserted points wording were updated. New pytest cases cover the CSV columns (old order kept, new values, blanks), the PDF text and `_change_text`. `node --test`: 176 pass. `pytest`: 1065 pass. ruff is clean. A private server on port 4860 against a scratchpad copy of the database was screenshotted over CDP: the dashboard, and the run report for document_qa FAIL run 94bb2a3c with case q1_financial_pdf. Page text and HTML were grepped: no "pts" or "points" UI text is left. The only match was the agent's own PDF output, "improved by 15 points".

---

## How pass 2 was verified

- **Full suite:** `pytest` gives 1055 passed, 0 failed, 0 skipped. That includes the 164 JS unit tests.
- **Coverage:** line + branch coverage of `src/main`, `src/sample_agents`, `src/agents` and `scripts` is 99%, with 0 lines missed. Three defensive `if` branches are partially covered.
- **Postgres:** tested without a database, using a fake engine that records each SQL statement and its bound parameters.
- **Lint:** `ruff check src scripts` is clean.
- **Line counts:** no source file is at or over 300 lines.
- **JS rules:** an AST audit of all frontend JS found no functions over 50 lines, no `var`, no `==`, no nested ternaries and no empty catches.
- **Integration:** `scripts/run_integration_tests.ps1` passes 48/48. It starts the service and all four sample agents, evaluates every agent (Markdown, JSON, DOCX and PDF outputs), then covers pagination, compare, benchmark promotion, async + cancel (409), A/B, CSV and PDF export, captures and labels.
- **Real app in headless Chrome:**
  - every page in the dark and light themes and at phone width;
  - a live evaluation and a Stop;
  - the report's "What needs attention", check details and benchmark dialog;
  - the playground's load → check → run → stop flow;
  - the API tester's success, 404 and unreachable-host cases.
