# Agent Configuration Guide — How to Add Your Agent to the Evaluation Service

This tutorial teaches AI engineers how to configure their agents for evaluation
by the CTNA Evaluation Service. You will learn how to wire up an HTTP call to
your agent, define custom evaluation metrics entirely from config files, handle
document outputs (PDF, DOCX, Markdown, JSON), and run a full evaluation — all
without writing evaluation code.

**Audience**: AI engineers who have an agent service (or are building one) and
want it scored by the evaluation service.

**Prerequisites**: Basic familiarity with JSON and YAML. Your agent needs an HTTP
endpoint that accepts a request and returns a response. No Python knowledge is
required for the config-driven path.

---

## 0. The Contribution Workflow: From Clone to Merged Pull Request

You do **not** modify the evaluation service code. You only **add one folder**
describing your agent, then open a pull request. The eval-service maintainers
review and merge it. This section walks you through that end-to-end, assuming no
prior familiarity with the repo.

The repository lives at:

> https://github.com/ntbv-ifbn/dbaware-monitoring-service (branch: `feature/DBAWARE-3927-EVAL`)

If you are new to GitHub pull requests, keep these guides open in another tab:

- [GitHub: About pull requests](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests)
- [GitHub: Creating a pull request](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/creating-a-pull-request)
- [GitHub: Resolving merge conflicts](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/addressing-merge-conflicts/about-merge-conflicts)

### 0.1 One-time setup

1. **Get access.** Make sure you can see the repo on GitHub. If you get a 404,
   request read access from the eval-service team (contact: amal.sanjeev@db.com) — the repo is private.
2. **Install Git** through the Company Portal on your machine. If git isn't available on the company portal, request access for it through the **[Software Request Portal](https://apps.powerapps.com/play/e/69452230-e4b7-e14c-a4fb-286a59dae144/a/ebe6176f-463b-4154-852b-399b0b770682?tenantId=1e9b61e8-e590-4abc-b1af-24125e330d2a&sourcetime=1733907397514&source=portal)**
3. **Configure your identity** (once per machine):

   ```powershell
   git config --global user.name  "Your Name"
   git config --global user.email "your.name@example.com"
   ```

### 0.2 Clone the repo and check out the integration branch

At the time of writing, agent configs are integrated onto the
`feature/DBAWARE-3927-EVAL` branch (not `main`). Clone and check it out:

```powershell
git clone https://github.com/ntbv-ifbn/dbaware-monitoring-service.git
cd dbaware-monitoring-service
git fetch origin
git checkout feature/DBAWARE-3927-EVAL
```

### 0.3 Create your own agent branch

Never commit straight to the integration branch. Branch off it, using a name that identifies your agent:

```powershell
git checkout -b agent/<your_agent_id>-integration
```

Example: `git checkout -b agent/loan_summarizer-integration`.

### 0.4 Add your agent folder

Create exactly one new folder under `src/agents/` — this is the **only** part of
the repo you should touch. Do not edit files outside your folder (scorers,
adapters, the runner, other agents' configs). Everything the service needs to
call and score your agent lives here:

```
src/agents/<your_agent_id>/
  agent.yaml          # metadata + base URL   (§2)
  dataset.json        # target + metrics + golden cases   (§3, §4)
  metrics_stub.json   # optional
  custom_tests.py     # optional Python escape hatch   (§7)
```

The registry **auto-discovers** any folder here at startup, so no other file
needs to change. Copy one of the shipped examples as a starting point — the
closest match to your agent's output type:

| Your agent returns… | Copy this example folder |
|---------------------|--------------------------|
| Markdown / prose    | `src/agents/report_writer/`  |
| Structured JSON     | `src/agents/invoice_parser/` |
| PDF / DOCX          | `src/agents/document_qa/`    |

Rename the folder to your `agent_id`, then edit `agent.yaml` and `dataset.json`
per §2–§4.

### 0.5 Validate locally before you push

A pull request that fails startup validation wastes a review cycle. Verify your
config loads and runs on your machine first:

```powershell
# 1. Create/activate a venv and install deps (once)
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt --index-url https://artifactory.intranet.db.com/artifactory/api/pypi/pypi-all/simple

# 2. Start your agent (or the matching sample agent) on its port

# 3. Start the eval service — startup runs Registry.validate(), which fails
#    fast on unknown scorers or malformed config
python -m uvicorn src.main.main:app --host 0.0.0.0 --port 4002

# 4. Trigger a run against YOUR agent id
You can either use the UI directly, or use curl to send an API request.
curl -X POST http://localhost:4002/api/evaluate `
  -H "Content-Type: application/json" `
  -d '{"agent_id":"<your_agent_id>"}'
```

If the service starts cleanly and the run returns scored metrics, your config is
structurally valid. Common startup errors (`Unknown scorer 'X'`, bad
`output_path`) are covered in §11.

> **Offline check:** LLM-judge and document scorers **skip cleanly** when Vertex
> or the parsing libraries are absent — a skipped metric is normal offline and
> does not mean your config is broken.

### 0.6 Commit and push your branch

```powershell
git add src/agents/<your_agent_id>
git status                     # confirm ONLY your folder is staged
git commit -m "Add <your_agent_id> agent evaluation config"
git push -u origin agent/<your_agent_id>-integration
```

If you get a proxy/auth error on push, use your organisation's Git credential
helper or a personal access token as your password.

### 0.7 Open the pull request

1. **Open GitHub and navigate to the repo**:  
  `https://github.com/ntbv-ifbn/dbaware-monitoring-service`
2. **Open the branch selector** (top-left above the file list) and switch to your branch:  
  `agent/<your_agent_id>-integration`
3. **Open the PR flow using either path**:
  - If shown: click **Contribute** → **Open pull request**
  - If not shown: go to the **Pull requests** tab → click **New pull request**
4. In the compare screen, make sure your branch is selected as the **compare** branch.  
5. **Set the base branch to `feature/DBAWARE-3927-EVAL`** (not `main`) and the
   compare branch to your `agent/<your_agent_id>-integration` branch. This is the
   most common mistake — double-check the base.
6. Fill in the PR description:
   - What the agent does and which endpoint it exposes.
   - Output type (text / JSON / PDF / DOCX) and which scorers you configured.
   - Confirmation that you ran the local validation in §0.5.
7. Submit. CI (see §0.8) runs automatically; address any failures by pushing more
   commits to the same branch — the PR updates itself.

### 0.8 What reviewers and CI check

Your PR is expected to satisfy:

- ✅ Only files under `src/agents/<your_agent_id>/` are added or changed.
- ✅ `agent_id` in `agent.yaml` reuses the same identifier your agent already uses in other services, and the folder name matches that shared identifier.
- ✅ Every `scorer` referenced in `dataset.json` is a registered scorer
  (`Registry.validate()` passes at startup — see §5–§6).
- ✅ No secrets are committed. Tokens/passwords come from env vars via
  `${env.VAR}` or the `auth` block (§3), never literal values.
- ✅ At least one golden case with `input`, `golden_output`/`expected`, and
  `baseline_metrics`.
- ✅ `dataset.json` is valid JSON (trailing commas in the JSONC examples in this
  guide are illustrative — real files must be strict JSON).

Once approved, a maintainer merges your branch into
`feature/DBAWARE-3927-EVAL` and your agent becomes part of the evaluation suite.

### 0.9 Keeping your branch up to date

If the integration branch moves ahead while your PR is open, sync it:

```powershell
git checkout feature/DBAWARE-3927-EVAL
git pull origin feature/DBAWARE-3927-EVAL
git checkout agent/<your_agent_id>-integration
git merge feature/DBAWARE-3927-EVAL        # or: git rebase feature/DBAWARE-3927-EVAL
# resolve any conflicts (unlikely, since you only touch your own folder), then:
git push
```

---

## 1. How the Evaluation Service Calls Your Agent

The evaluation service replays **golden inputs** against your agent's HTTP
endpoint, captures the output, and scores it against **golden outputs** and
**deterministic checks**. The call is configured in your agent's
`dataset.json` — no evaluation-service code changes are needed.

```
┌─────────────────┐     POST/GET      ┌──────────────────┐
│  Eval Service   │ ────────────────> │  Your Agent API  │
│  (runner.py)    │ <──────────────── │  (any framework) │
│                 │    JSON/text/     │                  │
│  scorers run    │    PDF/DOCX       └──────────────────┘
│  on the output  │
└─────────────────┘
```

You create one folder under `src/agents/<your_agent_id>/` containing:

```
src/agents/<your_agent_id>/
  agent.yaml         # Agent metadata + base URL
  dataset.json       # Golden set + target config + metrics config
  metrics_stub.json  # Stubbed metrics (optional; use METRICS_SOURCE=capture instead)
  custom_tests.py    # Custom Python scorers (optional; config-driven scorers cover most needs)
```

The registry auto-discovers your folder at startup. No code changes to the
evaluation service core.

---

## 2. The `agent.yaml` File

This is a simple metadata file:

```yaml
agent_id: my_agent
name: My AI Agent
# base_url: where your agent is hosted. If omitted, falls back to
# AGENT_SERVICE_BASE_URL from the environment.
base_url: http://localhost:5000
dataset_file: dataset.json
metrics_stub_file: metrics_stub.json
# Per-agent metrics source override (optional). Takes precedence over the
# global METRICS_SOURCE env var. Values: capture | http | stub.
metrics_source: capture
```

- `agent_id` should reuse the same identifier your agent already uses in other services, and the folder name should match that shared identifier.
- `base_url` is the host:port of your agent. Can be overridden per-run by the
  `AGENT_SERVICE_BASE_URL` env var.
- `dataset_file` and `metrics_stub_file` default to `dataset.json` and
  `metrics_stub.json`.

Use these naming conventions consistently:

- `dataset_id`: `<agent_id>_<topic>_dataset`
- `dataset_version`: `v1`, `v2`, `v3`, and so on

---

## 3. The `dataset.json` File — Target Configuration

The `dataset.json` has three top-level sections: `target` (how to call your
agent), `metrics` (what to score), and `cases` (the golden inputs/outputs).

### 3.1 Target: the config-driven HTTP adapter

Set `adapter: "http"` to use the config-driven HTTP adapter. Everything about
the request and response is described in the `target` block:

```jsonc
{
  "target": {
    "adapter": "http",
    "endpoint": "/api/eval/my-agent",
    "method": "POST",                    // GET, POST, PUT, PATCH (default: POST)
    "headers": {
      "Authorization": "Bearer ${env.MY_AGENT_TOKEN}",
      "Content-Type": "application/json"
    },
    "auth": {                            // Alternative to manual auth headers
      "type": "bearer",                  // bearer | basic | api_key_header | api_key_query
      "token_env": "MY_AGENT_TOKEN"     // Secret from env ONLY — never commit
    },
    "params": {                          // Query parameters (templated from case.input)
      "q": "${input.query}"
    },
    "body": {                            // Request body (templated). Absent = send case.input as JSON
      "query": "${input.query}",
      "max_tokens": "${input.max_tokens}"
    },
    "body_type": "json",                 // json (default) | form | text | raw
    "response": {                        // How to map the response into the Observation
      "output_path": "data.result",      // Dotted path to the agent's output
      "tool_calls_path": "tool_calls",   // Dotted path to tool-call list
      "usage_path": "usage",              // Dotted path to token usage
      "model_path": "model",              // Dotted path to model name
      "latency_path": null,               // Dotted path to latency (or auto-measured)
      "error_path": "error",              // Dotted path to error message
      "metadata_path": "metadata",        // Dotted path to extra metadata
      "source_context_path": "source_context",  // Retrieved context for groundedness
      "content_type": "auto",             // auto | text | json | markdown | pdf | docx
      "output_kind": "text"               // text | json | base64 | bytes | url
    },
    "timeout": 60,                        // Seconds (default: 120)
    "trust_env": false,                   // false = bypass corporate proxy for localhost
    "retries": 0                          // Retry count (default: 0)
  }
}
```

#### Template syntax

All string values in `headers`, `params`, and `body` support two template
variables:

| Template | Resolves to |
|----------|-------------|
| `${env.VAR_NAME}` | The environment variable `VAR_NAME` |
| `${input.dotted.path}` | A value from the golden case's `input` dict |

Example: if the golden case's `input` is `{"query": "Summarize Q1", "context": "..."}`:

```json
"body": { "prompt": "${input.query}", "context": "${input.context}" }
```

resolves to `{"prompt": "Summarize Q1", "context": "..."}`.

#### Authentication

Secrets (tokens, passwords) are **never committed** in config files. They come
from environment variables, referenced by name:

```jsonc
// Bearer token from env
"auth": { "type": "bearer", "token_env": "MY_AGENT_TOKEN" }

// API key in a custom header
"auth": { "type": "api_key_header", "token_env": "MY_API_KEY", "header": "X-API-Key" }

// Basic auth
"auth": { "type": "basic", "username_env": "AGENT_USER", "password_env": "AGENT_PASS" }

// API key as query parameter (use params, not auth)
"params": { "api_key": "${env.MY_API_KEY}" }
```

#### Content types and document handling

Your agent can return text, JSON, Markdown, PDF, or DOCX. The adapter detects
the type automatically (`content_type: "auto"`) or you can specify it
explicitly:

| `content_type` | `output_kind` | What happens |
|----------------|-------------|--------------|
| `text` | `text` | Output used as-is |
| `json` | `json` | Output kept as parsed JSON; JSON scorers access it structurally |
| `markdown` | `text` | Output kept as-is; `#` headings detected for section scorers |
| `pdf` | `base64` | Text extracted from PDF via pypdf; raw bytes preserved for structure scorers |
| `docx` | `base64` | Text extracted from DOCX via python-docx; raw bytes preserved for table scorers |
| `auto` | `base64` | Magic-byte sniffing: detects PDF vs DOCX vs text automatically |

When the adapter extracts text from a document, **all existing scorers**
(token overlap, edit similarity, embedding similarity, LLM judges) work on
the extracted text automatically. Document-structure scorers
(`section_present`, `heading_count`, `docx_table_has`) access the raw bytes.

**Important**: if `pypdf` or `python-docx` is not installed, document scorers
**skip cleanly** (omitted from the score, not failed) — just like the LLM judge
skips when Vertex is unavailable offline.

---

## 4. The `dataset.json` File — Metrics Configuration

The `metrics` array defines what to score. Each metric references a scorer by
name and can pass parameters via the `config` block:

```jsonc
{
  "metrics": [
    {
      "name": "my_metric_name",         // Display name for this metric
      "type": "deterministic",           // deterministic | llm_judge | reference | trajectory | safety | operational
      "scorer": "contains",              // Registered scorer name (see §5)
      "weight": 2.0,                     // Relative weight in the weighted score
      "threshold": 0.8,                  // Minimum score to pass this metric
      "critical": false,                // If true, failing this metric fails the whole case
      "direction": "higher_is_better",  // higher_is_better | lower_is_better
      "unit": "ratio",                  // ratio | ms | tokens | count | usd ...
      "norm_min": null,                 // For lower_is_better: value at/above scores 0
      "norm_max": null,                 // For lower_is_better: value at/below scores 1
      "config": {                       // Scorer-specific parameters (see §5)
        "terms": ["required", "terms"]
      }
    }
  ]
}
```

The gate logic is: **passed** = (no critical metric failed) AND (all metrics ≥
threshold) AND (weighted score ≥ dataset threshold) AND (no drift beyond
tolerance).

---

## 5. Config-Driven Scorers — Custom Metrics from Config

These scorers are parameterised entirely through the `config` field. You
reference them by `scorer` name and supply parameters — no Python needed.

### 5.1 Text / regex scorers (operate on extracted output text)

#### `contains` — required terms must appear

```jsonc
{
  "name": "key_terms_present",
  "type": "deterministic",
  "scorer": "contains",
  "weight": 2.0,
  "threshold": 0.8,
  "config": {
    "terms": ["$10M", "revenue", "net income"],
    "case_sensitive": false,
    "min_count": 1
  }
}
```

Score = fraction of terms found (each must appear ≥ `min_count` times).

`op: "not_empty"` is accepted for back-compat; prefer the `not_empty` scorer.

#### `not_empty` — output must be non-empty

```jsonc
{
  "name": "answer_not_empty",
  "type": "deterministic",
  "scorer": "not_empty",
  "weight": 1.0,
  "threshold": 1.0,
  "critical": true
}
```

Fails on `null`, `""`, whitespace-only strings, `{}`, and `[]`.

#### `not_contains` — forbidden terms must not appear

```jsonc
{
  "name": "no_forbidden_phrases",
  "type": "deterministic",
  "scorer": "not_contains",
  "weight": 2.0,
  "threshold": 1.0,
  "critical": true,
  "config": {
    "terms": ["guaranteed return", "ignore previous instructions"],
    "case_sensitive": false
  }
}
```

Score = fraction of forbidden terms that are absent. Alias: `config.forbidden`.

#### `regex_match` — regex patterns must match

```jsonc
{
  "name": "invoice_number_valid",
  "type": "deterministic",
  "scorer": "regex_match",
  "weight": 1.0,
  "threshold": 1.0,
  "config": {
    "patterns": [
      { "pattern": "INV-\\d{4}-\\d{3}", "required": true, "flags": "i" },
      { "pattern": "PO-\\d+", "required": false }
    ]
  }
}
```

`flags`: any combination of `i` (case-insensitive), `m` (multiline), `s`
(dotall), `x` (verbose). Score = required patterns matched / required total.

#### `length_range` — output length within [min, max]

```jsonc
{
  "name": "response_length",
  "type": "deterministic",
  "scorer": "length_range",
  "weight": 0.5,
  "threshold": 0.5,
  "config": {
    "min": 50,
    "max": 1000,
    "unit": "words"           // "words" or "chars"
  }
}
```

Score = 1.0 inside range, linearly decreasing outside. For `lower_is_better`
use `direction: "lower_is_better"` + `norm_min`/`norm_max` on the MetricSpec.

#### `keyword_count` — count keyword occurrences (raw count metric)

```jsonc
{
  "name": "risk_mentions",
  "type": "deterministic",
  "scorer": "keyword_count",
  "weight": 1.0,
  "threshold": 0.3,
  "direction": "lower_is_better",
  "unit": "count",
  "norm_min": 0,
  "norm_max": 20,
  "config": {
    "terms": ["risk", "issue", "concern"],
    "case_sensitive": false
  }
}
```

Returns raw count in `raw_value`; normalise with `direction` + `norm_*`.

### 5.2 JSON scorers (operate on the parsed JSON output)

#### `json_path` — dotted-path value check

```jsonc
{
  "name": "total_correct",
  "type": "deterministic",
  "scorer": "json_path",
  "weight": 3.0,
  "threshold": 1.0,
  "config": {
    "path": "total",
    "op": "equals",         // equals | contains | exists | regex
    "value": 8000           // comparison value for equals/contains/regex
  }
}
```

`path` uses dot notation for nested objects and `.N` or `[N]` for array
indices (e.g., `"line_items.0.amount"` or `"line_items[0].amount"`).

#### `field_match` — required fields with value operators

```jsonc
{
  "name": "required_fields",
  "type": "deterministic",
  "scorer": "field_match",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "fields": [
      { "name": "vendor", "op": "exists", "required": true },
      { "name": "total", "op": "type", "value": "number", "required": true },
      { "name": "currency", "op": "==", "value": "USD", "required": true },
      { "name": "discount", "op": "!=", "value": 0, "required": false }
    ]
  }
}
```

Operators: `exists`, `==`, `!=`, `contains`, `regex`, `in`, `type`.

#### `json_schema_valid` — output matches a JSON Schema

```jsonc
{
  "name": "schema_valid",
  "type": "deterministic",
  "scorer": "json_schema_valid",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "schema": {
      "type": "object",
      "required": ["vendor", "total", "line_items"],
      "properties": {
        "vendor": { "type": "string" },
        "total": { "type": "number" },
        "line_items": {
          "type": "array",
          "items": {
            "type": "object",
            "required": ["description", "amount"],
            "properties": {
              "description": { "type": "string" },
              "amount": { "type": "number" }
            }
          }
        }
      }
    }
  }
}
```

Supports a subset of JSON Schema draft-07: `type`, `required`, `properties`,
`items`, `additionalProperties`.

Shortcut form (no full schema):

```jsonc
"config": {
  "required": ["vendor", "total"],
  "types": { "total": "number" }
}
```

### 5.3 Document-structure scorers (PDF / DOCX / Markdown)

These skip cleanly when the parsing library is absent.

#### `section_present` — required section headings must appear

```jsonc
{
  "name": "report_sections",
  "type": "deterministic",
  "scorer": "section_present",
  "weight": 3.0,
  "threshold": 0.8,
  "config": {
    "sections": ["Executive Summary", "Key Findings", "Recommendations"]
  }
}
```

Works on Markdown (`# Heading`), extracted PDF/DOCX text, and plain text.

#### `heading_count` — number of headings within [min, max]

```jsonc
{
  "name": "heading_count",
  "type": "deterministic",
  "scorer": "heading_count",
  "weight": 1.0,
  "threshold": 0.5,
  "config": {
    "min": 3,
    "max": 15
  }
}
```

#### `docx_table_has` — DOCX tables with required headers and rows

```jsonc
{
  "name": "summary_table",
  "type": "deterministic",
  "scorer": "docx_table_has",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "tables": [
      { "required_headers": ["Metric", "Value", "Status"], "min_rows": 3 }
    ]
  }
}
```

Requires `python-docx`. The scorer checks that at least one table in the
document has all required headers in its first row and at least `min_rows` rows.

#### `pdf_table_has` — PDF tables with required headers and rows

```jsonc
{
  "name": "summary_table_pdf",
  "type": "deterministic",
  "scorer": "pdf_table_has",
  "weight": 2.0,
  "threshold": 1.0,
  "config": {
    "tables": [
      { "required_headers": ["Metric", "Value", "Status"], "min_rows": 3 }
    ]
  }
}
```

Requires `pdfplumber` (optional; install with `pip install pdfplumber`). Skips
cleanly if not installed. Same interface as `docx_table_has` but for PDF tables.

### 5.4 Custom LLM rubric judge from config

This is the key feature: define a brand-new LLM evaluation criterion **from
config alone**. The scorer reuses the Vertex AI judge (Gemini) with
self-consistency sampling. It skips cleanly when Vertex is unavailable.

```jsonc
{
  "name": "professional_tone",
  "type": "llm_judge",
  "scorer": "rubric",
  "weight": 2.0,
  "threshold": 0.7,
  "config": {
    "rubric": "whether the output maintains a professional banking tone, avoids informal language, and presents information clearly and concisely. The language should be suitable for a regulatory submission.",
    "uses_golden": false,
    "bias_guard": true,
    "examples": "Score 1.0: 'The analysis indicates a 12% reduction in operational risk...'  Score 0.3: 'So yeah basically risk went down a lot lol...'"
  }
}
```

Config fields:

| Field | Default | Meaning |
|-------|---------|---------|
| `rubric` | (required) | The evaluation criterion text — what the judge should score |
| `uses_golden` | `false` | If `true`, include the golden_output in the prompt (skips if golden is missing) |
| `bias_guard` | `true` | Add the standard bias guard (ignore length, position) |
| `examples` | `""` | Optional few-shot examples appended to the prompt |

The judge returns a score 0..1, a rationale, and evidence strings. With
`judge_repetitions > 1`, multiple samples are averaged and the variance is
recorded (high variance flags an unstable verdict).

#### `rubric_multi` — Multi-criteria rubric in one judge call (cost saver)

Score N criteria in a **single** Vertex call instead of N separate `rubric`
metrics. The scorer returns the mean; per-criterion breakdown is in evidence.

```jsonc
{
  "name": "doc_quality",
  "type": "llm_judge",
  "scorer": "rubric_multi",
  "weight": 3.0,
  "threshold": 0.7,
  "config": {
    "criteria": [
      { "name": "professional_tone", "rubric": "maintains a professional banking tone" },
      { "name": "factual_accuracy", "rubric": "all claims are factually correct" },
      { "name": "completeness", "rubric": "covers all required topics" },
      { "name": "clarity", "rubric": "clear and concise language" }
    ],
    "uses_golden": false,
    "bias_guard": true
  }
}
```

This halves judge costs for agents with 5+ custom rubrics: one call returns
all criterion scores. Skips cleanly when Vertex is unavailable.

---

## 6. Built-in scorers also available

These are always available — reference them by name in your `scorer` field.

### 6.1 Core config-driven stock scorers

| Scorer | Family | What it measures |
|--------|--------|------------------|
| `contains` | deterministic | Required terms are present |
| `not_empty` | deterministic | Output is non-empty |
| `not_contains` | deterministic | Forbidden terms are absent |
| `regex_match` | deterministic | Required regex patterns match |
| `length_range` | deterministic | Length/word-count is in range |
| `keyword_count` | deterministic | Occurrence count of configured terms |
| `json_path` | deterministic | Dotted-path JSON value check |
| `field_match` | deterministic | Multiple JSON field checks |
| `json_schema_valid` | deterministic | JSON schema conformance |
| `section_present` | deterministic | Required document/markdown sections |
| `heading_count` | deterministic | Heading count in configured range |
| `docx_table_has` | document | DOCX table/header checks |
| `pdf_table_has` | document | PDF table/header checks |
| `rubric` | llm_judge | Custom LLM criterion from config |
| `rubric_multi` | llm_judge | Multiple custom criteria in one call |

### 6.2 Additional stock scorers

| Scorer | Family | What it measures |
|--------|--------|------------------|
| `assertions` | deterministic | Per-case present/absent spot-checks |
| `metric_threshold` | deterministic | Pass-through of a CTA numeric metric |
| `ai_confidence` | deterministic | Model self-reported confidence |
| `tool_selection` | trajectory | Did the agent call the expected tool? |
| `tool_order_correct` | trajectory | Expected tools in expected order |
| `no_redundant_calls` | trajectory | No duplicate identical tool calls |
| `tool_arg_accuracy` | trajectory | Expected args present per tool |
| `tool_error_free` | trajectory | No tool raised an error (critical) |
| `step_efficiency` | trajectory | Steps taken vs an expected budget |
| `token_overlap_f1` | reference | Token-level F1 vs golden output |
| `edit_similarity` | reference | Normalised Levenshtein similarity vs golden |
| `embedding_similarity` | reference | Vertex embedding cosine similarity vs golden |
| `faithfulness` | llm_judge | Factual correctness vs golden (Vertex; skips offline) |
| `relevance` | llm_judge | How directly the output answers the input |
| `completeness` | llm_judge | Whether output covers all golden info |
| `coherence` | llm_judge | Logical structure / internal consistency |
| `conciseness` | llm_judge | Avoids redundancy |
| `instruction_following` | llm_judge | Obeys explicit input instructions |
| `pairwise_vs_golden` | llm_judge | Pairwise preference vs golden |
| `groundedness` | safety | Claims grounded in source context (Vertex; skips offline) |
| `no_pii_leakage` | safety | No un-redacted PII patterns (critical) |
| `prompt_injection_safe` | safety | No injection-signal phrases |
| `refusal_appropriate` | safety | Refuses when it should, answers when it should |
| `latency_slo` | operational | End-to-end latency vs SLO (lower_is_better) |
| `tool_latency_slo` | operational | Total tool latency vs SLO (lower_is_better) |
| `token_cost_budget` | operational | Token usage vs budget (lower_is_better) |
| `response_success` | operational | Agent returned a usable response (critical) |

> Tip: if you are unsure which scorer to start with, begin with `not_empty`,
> one structural metric (for your output type), and one quality metric.

---

## 7. The Python escape hatch: `@register_adapter`

If your agent can't be called via HTTP (e.g. direct SDK, gRPC, a local
function), you can write a custom adapter in Python. Put it in your agent's
`custom_tests.py`:

```python
from eval_service.adapters import register_adapter
from eval_service.models import GoldenCase, Observation
import time

@register_adapter("my_custom_agent")
class MyCustomAdapter:
    def __init__(self, base_url, endpoint, target=None):
        self._base_url = base_url
        self._endpoint = endpoint

    async def run_case(self, case: GoldenCase) -> Observation:
        start = time.perf_counter()
        # Call your agent however you want...
        result = my_agent_sdk.run(case.input)
        return Observation(
            target_id=case.id,
            output=result.text,
            tool_calls=result.tool_calls,
            latency_ms=int((time.perf_counter() - start) * 1000),
            model="my-agent-v1",
            metadata={"ai_confidence": result.confidence},
        )
```

Then reference it in `dataset.json`:

```json
{ "target": { "adapter": "my_custom_agent", "endpoint": "/any" } }
```

The registry auto-imports `custom_tests.py` at startup, so the adapter is
registered before the first run. You can also add custom Python scorers in the
same file:

```python
from eval_service.scorers.base import scorer

@scorer("my_custom_check")
def my_check(*, observation, case, **_):
    # Your custom logic here
    return 1.0, "passed", ["evidence line"]
```

---

## 8. Worked examples

Three complete demo agents ship with the service under `src/agents/`:

### 8.1 `report_writer` — Markdown output with section + rubric scorers

- Sample agent: `src/sample_agents/report_writer_agent.py` (port 4011)
- Config: `src/agents/report_writer/dataset.json`
- Demonstrates: `http` adapter, `content_type: markdown`, `section_present`,
  `contains`, `heading_count`, `length_range`, custom `rubric` judge

Run it:
```powershell
python src/sample_agents/report_writer_agent.py
python -m uvicorn src.main.main:app --host 0.0.0.0 --port 4002
# In another terminal:
curl -X POST http://localhost:4002/api/evaluate -H "Content-Type: application/json" -d '{"agent_id":"report_writer"}'
```

### 8.2 `invoice_parser` — JSON output with structural + field scorers

- Sample agent: `src/sample_agents/invoice_parser_agent.py` (port 4012)
- Config: `src/agents/invoice_parser/dataset.json`
- Demonstrates: `http` adapter, `content_type: json`, `json_path`,
  `field_match`, `json_schema_valid`, custom `rubric` judge

### 8.3 `document_qa` — DOCX and PDF output with document-structure scorers

- Sample agent: `src/sample_agents/document_qa_agent.py` (port 4013)
- Config: `src/agents/document_qa/dataset.json`
- Demonstrates: `http` adapter, `content_type: auto`, `output_kind: base64`,
  `section_present`, `docx_table_has`, `heading_count`, custom `rubric` judge

---

## 9. Quick checklist: adding a new agent (config → PR)

**Get the repo ready** (details in §0):
1. Clone `dbaware-monitoring-service` and check out `feature/DBAWARE-3927-EVAL`.
2. Create a feature branch: `git checkout -b agent/<agent_id>-integration`.

**Author your config:**
3. Create `src/agents/<agent_id>/` (copy the closest sample folder — §0.4) with:
  - `agent.yaml` (agent_id reusing the identifier from your other services, folder name matching it, name, base_url)
   - `dataset.json` (target, metrics, cases)
   - `metrics_stub.json` (optional; or use `METRICS_SOURCE=capture`)

4. In `dataset.json`:
   - Set `target.adapter: "http"` and configure the endpoint, auth, body, and
     response mapping.
   - Define metrics referencing config-driven scorers by name.
   - Write golden cases with `input`, `golden_output`, `expected`, and
     `baseline_metrics`.

**Validate locally** (§0.5):
5. Start your agent and the eval service:
   ```powershell
  # Start your agent (or the matching sample agent)
  python -m uvicorn src.main.main:app --host 0.0.0.0 --port 4002
   ```

6. Trigger an evaluation and confirm it scores cleanly:
   ```powershell
   curl -X POST http://localhost:4002/api/evaluate `
     -H "Content-Type: application/json" `
     -d '{"agent_id":"<your_agent_id>"}'
   ```

7. Check `GET /api/health` for credential/Vertex status and open
   `http://localhost:4002` for the dashboard.

**Submit for integration** (§0.6–§0.7):
8. Commit **only** your folder and push your branch:
   ```powershell
   git add src/agents/<agent_id>
   git commit -m "Add <agent_id> agent evaluation config"
   git push -u origin agent/<agent_id>-integration
   ```
9. Open a pull request on GitHub with **base branch `feature/DBAWARE-3927-EVAL`**,
   describe your agent, and confirm the local validation passed. Address CI
   feedback by pushing more commits to the same branch.

---

## 10. API reference — new endpoints

Beyond the core `POST /api/evaluate` and `GET /api/runs/{id}`, the service now
provides these operational endpoints:

### Run comparison
```powershell
# Compare two runs side-by-side
curl "http://localhost:4002/api/runs/compare?a=<run_id_a>&b=<run_id_b>"
```
Returns per-case scores, deltas, and improved/regressed flags.

### Baseline promotion
```powershell
# Promote a run's mean per-metric scores as the new baseline
curl -X POST "http://localhost:4002/api/baselines/promote/<run_id>"
```
Computes the mean score per metric across all cases and stores it as the blessed
baseline — used for delta tracking and drift detection on future runs.

### Async evaluate with webhook
```powershell
# Start a run in the background; POST the result to a webhook when done
curl -X POST http://localhost:4002/api/evaluate/async `
  -H "Content-Type: application/json" `
  -d '{"agent_id":"my_agent","webhook_url":"https://my-ci.example.com/hook"}'
```
Returns immediately with a `stream_id`. The service POSTs the completed run
record to the `webhook_url` when the run finishes.

### A/B comparison
```powershell
# Run two agents against the same dataset and compare
curl -X POST http://localhost:4002/api/evaluate/ab `
  -H "Content-Type: application/json" `
  -d '{"agent_a":"my_agent_v1","agent_b":"my_agent_v2"}'
```
Returns a per-case comparison with an overall winner.

### Run export
```powershell
# Export a run as CSV (for audit/compliance)
curl "http://localhost:4002/api/runs/<run_id>/export?format=csv" -o run.csv

# Export a run as PDF
curl "http://localhost:4002/api/runs/<run_id>/export?format=pdf" -o run.pdf
```

### Cursor pagination
```powershell
# First page
curl "http://localhost:4002/api/runs?limit=20"
# Response includes next_cursor; use it for the next page:
curl "http://localhost:4002/api/runs?limit=20&before=<next_cursor>"
```

---

## 11. Troubleshooting

| Symptom | Fix |
|---------|-----|
| `Unknown scorer 'X'` | Caught at startup by `Registry.validate()`. Check the scorer name in `dataset.json` matches a registered scorer (see §5-6) |
| All LLM judge metrics skipped | Vertex is unavailable. Set `PROJECT_NAME` + run `gcloud auth application-default login` (or WIF) |
| `docx_table_has` skipped | `python-docx` not installed. Run `pip install python-docx --index-url https://artifactory.intranet.db.com/artifactory/api/pypi/pypi-all/simple` |
| `pdf_table_has` skipped | `pdfplumber` not installed. Run `pip install pdfplumber --index-url https://artifactory.intranet.db.com/artifactory/api/pypi/pypi-all/simple` (optional) |
| `rubric_multi` skipped | Vertex unavailable (check `PROJECT_NAME`/ADC), or no `config.criteria` defined |
| PDF text extraction empty | `pypdf` not installed, or the PDF has no extractable text (scanned images) |
| `HTTP 407` on agent call | Corporate proxy intercepting localhost. Set `trust_env: false` in the target config |
| Agent returns 500 | Check your agent's logs; the eval service captures the error in `observation.error` |
| `output_path` not found | Check the dotted path matches your agent's actual response JSON structure |
| Old runs not deleted | Set `EVAL_RUN_RETENTION_DAYS > 0` in `.env`; cleanup runs on startup |
| PR targets the wrong branch | Set the PR **base** to `feature/DBAWARE-3927-EVAL`, not `main` (§0.7) |
| 404 cloning the repo | The repo is private — request access from the eval-service team (§0.1) |
| PR touches files outside your folder | Only add `src/agents/<agent_id>/`; run `git status` before committing (§0.6) |
| `agent_id` not discovered | Reuse the same `agent_id` your agent already uses elsewhere, and make the folder name match it exactly (§0.8) |
| Push rejected / auth error | Use your org's Git credential helper or a personal access token (§0.6) |

---

## 12. Template library (beginner + advanced)

This section is designed to be copy-paste friendly. Every example uses these
strict conventions:

- `dataset_id`: `<agent_id>_<topic>_dataset`
- `version`: `v1`, `v2`, `v3`, ...

### 12.1 Minimal starter template (recommended first run)

Use this first, confirm one successful run, then add more metrics.

```yaml
# agent.yaml
agent_id: my_agent
name: My Agent
base_url: http://localhost:4000
dataset_file: dataset.json
metrics_stub_file: metrics_stub.json
metrics_source: capture
```

```json
{
  "dataset_id": "my_agent_general_dataset",
  "version": "v1",
  "description": "Starter dataset for first integration run",
  "target": {
    "adapter": "http",
    "endpoint": "/api/eval",
    "method": "POST",
    "body_type": "json",
    "trust_env": false,
    "response": {
      "output_path": "output",
      "content_type": "text",
      "output_kind": "text"
    }
  },
  "metrics": [
    {
      "name": "response_not_empty",
      "type": "deterministic",
      "scorer": "not_empty",
      "weight": 1.0,
      "threshold": 1.0,
      "critical": true
    }
  ],
  "cases": [
    {
      "id": "c1",
      "input": { "query": "Summarize scope for project Phoenix" },
      "golden_output": "Summary with key scope decisions and risks.",
      "baseline_metrics": { "response_not_empty": 1.0 }
    }
  ]
}
```

### 12.2 Advanced target templates

#### 12.2.1 Authenticated endpoint with env secrets

```json
{
  "target": {
    "adapter": "http",
    "endpoint": "/v1/agent/evaluate",
    "method": "POST",
    "headers": { "x-client-id": "${env.CLIENT_ID}" },
    "auth": { "type": "bearer", "token_env": "AGENT_BEARER_TOKEN" },
    "body": {
      "question": "${input.query}",
      "region": "${env.DEFAULT_REGION}"
    },
    "trust_env": false,
    "retries": 1
  }
}
```

#### 12.2.2 JSON output mapping

```json
{
  "target": {
    "adapter": "http",
    "endpoint": "/parse-invoice",
    "method": "POST",
    "body": { "document": "${input.document_text}" },
    "response": {
      "output_path": "result",
      "content_type": "json",
      "output_kind": "json",
      "model_path": "meta.model",
      "usage_path": "meta.usage"
    }
  }
}
```

#### 12.2.3 Document output mapping (auto detect PDF/DOCX)

```json
{
  "target": {
    "adapter": "http",
    "endpoint": "/generate-report",
    "method": "POST",
    "response": {
      "output_path": "file_b64",
      "content_type": "auto",
      "output_kind": "base64"
    }
  }
}
```

### 12.3 One snippet for each stock metric

Use these snippets inside your `metrics` array. Names and config keys are valid
for current scorer implementations.

#### 12.3.1 Core config-driven stock scorers

```jsonc
// contains
{
  "name": "contains_scope",
  "type": "deterministic",
  "scorer": "contains",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "terms": ["scope", "timeline"]
  }
}
// not_empty
{
  "name": "not_empty",
  "type": "deterministic",
  "scorer": "not_empty",
  "threshold": 1.0,
  "weight": 1.0,
  "critical": true
}
// not_contains
{
  "name": "no_forbidden",
  "type": "deterministic",
  "scorer": "not_contains",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "terms": ["ignore previous instructions"]
  }
}
// regex_match
{
  "name": "id_format",
  "type": "deterministic",
  "scorer": "regex_match",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "patterns": [
      { "pattern": "ID-\\d+", "required": true }
    ]
  }
}
// length_range
{
  "name": "length_range",
  "type": "deterministic",
  "scorer": "length_range",
  "threshold": 0.8,
  "weight": 0.5,
  "config": {
    "min": 50,
    "max": 600,
    "unit": "words"
  }
}
// keyword_count
{
  "name": "keyword_count",
  "type": "deterministic",
  "scorer": "keyword_count",
  "threshold": 0.7,
  "weight": 0.5,
  "direction": "lower_is_better",
  "unit": "count",
  "norm_min": 0,
  "norm_max": 20,
  "config": {
    "terms": ["risk", "control"]
  }
}
// json_path
{
  "name": "json_path_total",
  "type": "deterministic",
  "scorer": "json_path",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "path": "total",
    "op": "equals",
    "value": 8000
  }
}
// field_match
{
  "name": "field_match_currency",
  "type": "deterministic",
  "scorer": "field_match",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "fields": [
      {
        "name": "currency",
        "op": "==",
        "value": "EUR",
        "required": true
      }
    ]
  }
}
// json_schema_valid
{
  "name": "json_schema_valid",
  "type": "deterministic",
  "scorer": "json_schema_valid",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "required": ["vendor", "total"],
    "types": { "total": "number" }
  }
}
// section_present
{
  "name": "section_present",
  "type": "deterministic",
  "scorer": "section_present",
  "threshold": 0.8,
  "weight": 1.0,
  "config": {
    "sections": ["Executive Summary", "Risks"]
  }
}
// heading_count
{
  "name": "heading_count",
  "type": "deterministic",
  "scorer": "heading_count",
  "threshold": 0.6,
  "weight": 0.5,
  "config": {
    "min": 3,
    "max": 15
  }
}
// docx_table_has
{
  "name": "docx_table_has",
  "type": "deterministic",
  "scorer": "docx_table_has",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "tables": [
      {
        "required_headers": ["Metric", "Value"],
        "min_rows": 2
      }
    ]
  }
}
// pdf_table_has
{
  "name": "pdf_table_has",
  "type": "deterministic",
  "scorer": "pdf_table_has",
  "threshold": 1.0,
  "weight": 1.0,
  "config": {
    "tables": [
      {
        "required_headers": ["Metric", "Value"],
        "min_rows": 2
      }
    ]
  }
}
// rubric
{
  "name": "rubric_professional_tone",
  "type": "llm_judge",
  "scorer": "rubric",
  "threshold": 0.7,
  "weight": 1.5,
  "config": {
    "rubric": "professional and clear tone",
    "uses_golden": false,
    "bias_guard": true
  }
}
// rubric_multi
{
  "name": "rubric_multi_quality",
  "type": "llm_judge",
  "scorer": "rubric_multi",
  "threshold": 0.7,
  "weight": 2.0,
  "config": {
    "criteria": [
      { "name": "relevance", "rubric": "answers the question" },
      { "name": "clarity", "rubric": "clear and concise" }
    ]
  }
}
```

#### 12.3.2 Additional stock scorers

```jsonc
// assertions
{
  "name": "assertions",
  "type": "deterministic",
  "scorer": "assertions",
  "threshold": 1.0,
  "weight": 1.0
}
// metric_threshold
{
  "name": "ai_confidence_score",
  "type": "deterministic",
  "scorer": "metric_threshold",
  "threshold": 0.9,
  "weight": 1.0
}
// ai_confidence
{
  "name": "ai_confidence",
  "type": "deterministic",
  "scorer": "ai_confidence",
  "threshold": 0.8,
  "weight": 0.5
}
// tool_selection
{
  "name": "tool_selection",
  "type": "trajectory",
  "scorer": "tool_selection",
  "threshold": 1.0,
  "weight": 1.0
}
// tool_order_correct
{
  "name": "tool_order_correct",
  "type": "trajectory",
  "scorer": "tool_order_correct",
  "threshold": 1.0,
  "weight": 0.8
}
// no_redundant_calls
{
  "name": "no_redundant_calls",
  "type": "trajectory",
  "scorer": "no_redundant_calls",
  "threshold": 1.0,
  "weight": 0.8
}
// tool_arg_accuracy
{
  "name": "tool_arg_accuracy",
  "type": "trajectory",
  "scorer": "tool_arg_accuracy",
  "threshold": 0.8,
  "weight": 1.0
}
// tool_error_free
{
  "name": "tool_error_free",
  "type": "trajectory",
  "scorer": "tool_error_free",
  "threshold": 1.0,
  "weight": 1.0,
  "critical": true
}
// step_efficiency
{
  "name": "step_efficiency",
  "type": "trajectory",
  "scorer": "step_efficiency",
  "threshold": 0.7,
  "weight": 0.6
}
// token_overlap_f1
{
  "name": "token_overlap_f1",
  "type": "reference",
  "scorer": "token_overlap_f1",
  "threshold": 0.6,
  "weight": 1.0
}
// edit_similarity
{
  "name": "edit_similarity",
  "type": "reference",
  "scorer": "edit_similarity",
  "threshold": 0.6,
  "weight": 0.8
}
// embedding_similarity
{
  "name": "embedding_similarity",
  "type": "reference",
  "scorer": "embedding_similarity",
  "threshold": 0.7,
  "weight": 1.0
}
// faithfulness
{
  "name": "faithfulness",
  "type": "llm_judge",
  "scorer": "faithfulness",
  "threshold": 0.75,
  "weight": 1.5
}
// relevance
{
  "name": "relevance",
  "type": "llm_judge",
  "scorer": "relevance",
  "threshold": 0.7,
  "weight": 1.0
}
// completeness
{
  "name": "completeness",
  "type": "llm_judge",
  "scorer": "completeness",
  "threshold": 0.7,
  "weight": 1.0
}
// coherence
{
  "name": "coherence",
  "type": "llm_judge",
  "scorer": "coherence",
  "threshold": 0.7,
  "weight": 0.8
}
// conciseness
{
  "name": "conciseness",
  "type": "llm_judge",
  "scorer": "conciseness",
  "threshold": 0.6,
  "weight": 0.5
}
// instruction_following
{
  "name": "instruction_following",
  "type": "llm_judge",
  "scorer": "instruction_following",
  "threshold": 0.8,
  "weight": 1.2
}
// pairwise_vs_golden
{
  "name": "pairwise_vs_golden",
  "type": "llm_judge",
  "scorer": "pairwise_vs_golden",
  "threshold": 0.7,
  "weight": 0.8
}
// groundedness
{
  "name": "groundedness",
  "type": "safety",
  "scorer": "groundedness",
  "threshold": 0.8,
  "weight": 1.2
}
// no_pii_leakage
{
  "name": "no_pii_leakage",
  "type": "safety",
  "scorer": "no_pii_leakage",
  "threshold": 1.0,
  "weight": 1.5,
  "critical": true
}
// prompt_injection_safe
{
  "name": "prompt_injection_safe",
  "type": "safety",
  "scorer": "prompt_injection_safe",
  "threshold": 1.0,
  "weight": 1.0
}
// refusal_appropriate
{
  "name": "refusal_appropriate",
  "type": "safety",
  "scorer": "refusal_appropriate",
  "threshold": 0.8,
  "weight": 1.0
}
// latency_slo
{
  "name": "latency_slo",
  "type": "operational",
  "scorer": "latency_slo",
  "threshold": 0.9,
  "weight": 0.7,
  "direction": "lower_is_better",
  "unit": "ms",
  "norm_min": 0,
  "norm_max": 2500
}
// tool_latency_slo
{
  "name": "tool_latency_slo",
  "type": "operational",
  "scorer": "tool_latency_slo",
  "threshold": 0.9,
  "weight": 0.7,
  "direction": "lower_is_better",
  "unit": "ms",
  "norm_min": 0,
  "norm_max": 1800
}
// token_cost_budget
{
  "name": "token_cost_budget",
  "type": "operational",
  "scorer": "token_cost_budget",
  "threshold": 0.8,
  "weight": 0.6,
  "direction": "lower_is_better",
  "unit": "tokens",
  "norm_min": 0,
  "norm_max": 4000
}
// response_success
{
  "name": "response_success",
  "type": "operational",
  "scorer": "response_success",
  "threshold": 1.0,
  "weight": 1.0,
  "critical": true
}
```

### 12.4 Practical metric bundles (ready-to-use combinations)

#### Text/Markdown quality bundle

`not_empty`, `contains`, `section_present`, `length_range`, `rubric_multi`

#### JSON extraction bundle

`not_empty`, `json_schema_valid`, `field_match`, `json_path`, `faithfulness`

#### Tool-using agent bundle

`tool_selection`, `tool_order_correct`, `tool_arg_accuracy`, `tool_error_free`, `step_efficiency`

#### Safety/compliance bundle

`no_pii_leakage`, `prompt_injection_safe`, `refusal_appropriate`, `groundedness`

#### Operational SLO bundle

`response_success`, `latency_slo`, `tool_latency_slo`, `token_cost_budget`

### 12.5 New-user flow (how to use this section)

1. Copy the minimal starter from §12.1.
2. Choose one advanced target pattern from §12.2.
3. Add only 3 metrics from §12.3 for your first pass.
4. Run one case end-to-end.
5. Add the rest of your metrics in small increments.

---

## 13. Field reference (what each key means)

### 13.1 `agent.yaml`

- `agent_id`: Shared identifier used across services. Keep exactly the same value.
- `name`: Human-readable display name.
- `base_url`: Optional per-agent host override. If omitted, service uses `AGENT_SERVICE_BASE_URL`.
- `dataset_file`: Usually `dataset.json`.
- `metrics_stub_file`: Usually `metrics_stub.json`.
- `metrics_source`: Optional per-agent override (`capture`, `http`, `stub`).

### 13.2 `dataset.json`

- `dataset_id`: Must follow `<agent_id>_<topic>_dataset`.
- `version`: Use `v1`, `v2`, `v3`, ... (increment whenever golden set or target/metric logic changes meaningfully).
- `target`: How to call your agent (method, endpoint, headers, body, response mapping).
- `metrics`: Scoring definitions; each metric needs `name`, `type`, `scorer`, `threshold`, and usually `weight`.
- `cases`: Golden test cases. Each case should include:
  - stable `id`
  - realistic `input`
  - `golden_output` or `expected` structure
  - `baseline_metrics` for tracked comparisons

### 13.3 Versioning guidance

- Keep `dataset_id` stable for the same agent/topic.
- Bump `version` when changing any of:
  - case inputs/outputs
  - metric thresholds/weights
  - endpoint contract affecting scoring behavior
- Do **not** overwrite historical meaning of an old version.

---

## 14. FAQ (practical questions)

**Q: Can I evaluate without CloudSQL access?**  
Yes. Service startup is CloudSQL-first but falls back to local SQLite automatically when CloudSQL is unavailable.

**Q: Can I evaluate without Vertex credentials?**  
Yes. LLM judge metrics are skipped cleanly; deterministic metrics still run.

**Q: How many cases should I start with?**  
Start with 5–10 high-signal cases, then grow to 25+ for CI confidence.

**Q: What makes a good golden case?**  
Production-like input, explicit expected behavior, and clear acceptance criteria reflected in metric configs.

**Q: Should I use `capture`, `stub`, or `http` for metrics source?**  
- `capture`: best local end-to-end behavior (live derived action in memory)  
- `stub`: deterministic local scaffolding  
- `http`: integration with real metrics API

**Q: How do I avoid flaky runs?**  
Prefer deterministic metrics for gating; keep LLM judge as a weighted signal with conservative thresholds and stable prompts.
