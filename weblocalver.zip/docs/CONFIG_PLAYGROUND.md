# Agent Config Playground

The Config Playground lets a developer work on an agent evaluation bundle without deploying it to the registered evaluation configuration.

Open `/playground.html` from the evaluation service dashboard.

## Workflow

1. Upload a ZIP containing one agent folder with `agent.yaml`.
2. The service validates the manifest and dataset and returns the editable files to the browser.
3. The browser stores the working copy in IndexedDB for that origin. No playground configuration is written to the evaluation database.
4. Edit text files directly. JSON, YAML, Python, Markdown, and other text files are supported. Binary files are preserved for export.
5. Optionally set a target base URL override. This is useful when the uploaded configuration should call a different agent deployment than the URL in `agent.yaml`.
6. Run the configuration. The service creates a temporary workspace, loads the uploaded registry, runs the normal evaluation runner, and deletes the workspace when the run finishes.
7. Export the current browser copy as a ZIP.

## API

### `POST /api/playground/inspect`

Multipart field: `file`.

Validates and returns the discovered agent, dataset summary, warnings, and editable file contents. Nothing is persisted.

### `POST /api/playground/start`

Multipart fields:

- `file`: ZIP bundle
- `base_url`: optional target base URL override
- `judge_repetitions`: optional integer from 1 to 5

Returns an evaluation stream ID. Progress is available through the existing evaluation SSE endpoint at `/api/evaluate/stream/{stream_id}`. The terminal event is `playground_done` and contains the complete ephemeral `RunRecord`.

### `POST /api/playground/export`

JSON body:

```json
{
  "root": "my-agent",
  "files": [
    {"path": "agent.yaml", "encoding": "utf-8", "kind": "text", "content": "..."}
  ]
}
```

Returns a ZIP containing the browser's current file set.

## Limits and security

The service accepts ZIPs up to 32 MB compressed and 96 MB expanded, with a maximum of 1,500 files. Absolute paths, parent-directory traversal, and symlink entries are rejected.

`custom_tests.py` and other Python files are executable code when a registry loads them. The playground therefore needs to be treated as a trusted-developer feature. Run it behind the same authentication boundary as the evaluation service, and use a separate service identity if the endpoint is exposed to less-trusted users. A future hardened deployment can move preview execution into an isolated worker/container.

## Custom tests and scorer discovery

`custom_tests.py` is supported by the playground. The browser statically discovers `@scorer("...")` declarations on import and the Validate action additionally imports the uploaded bundle through an ephemeral Registry, so validation reports which custom scorers actually registered.

Preview runs use the same Registry/Runner scorer path as normal evaluations. Custom scorer registrations are scoped to the preview and restored after the run so one developer's bundle cannot leave stale scorer registrations for a later preview in the same process.

The playground also exposes `/api/playground/environment` with non-secret evaluator settings such as judge model, Vertex location, metrics source, embedding model, and concurrency values. The UI displays these on demand so developers can confirm evaluator parity without exposing credentials.

### Developer iteration features

- Select individual dataset cases or run the full dataset. Selected case IDs are passed to the same `Runner` used by normal evaluation, so a one-case iteration evaluates only that case.
- The editor includes line numbers, lightweight syntax highlighting for YAML/JSON/Python, JSON validation feedback, and find/replace controls. Server-side validation remains authoritative for Python syntax and bundle validation.
- Playground runs are retained only in the browser and can be compared by case weighted score and per-metric score deltas.
- The API Tester supports None, Bearer token, API key, Basic Auth, and custom-header authentication presets. Secrets are held only in page memory and are excluded from browser request history.
