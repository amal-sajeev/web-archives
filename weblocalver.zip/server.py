"""
CT1 Live Include/Exclude & Data Extraction Demo Server.

FastAPI proxy over CT1 endpoints:
  - Data Extraction Agent: /scoping-dataextraction-agent/{getdata/*, data-extraction*}
  - Query Service: /query-service/qna/{chat, documents/list-all, documents/ingest}
    (with Gateway / Master fallback and resilient local workflow fallback when
    query-service returns 503 no healthy upstream).
"""

from __future__ import annotations

import asyncio
import copy
import json
import logging
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ct1-demo-ui")

CTA_HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com").rstrip("/")
DATAEXTRACTION_BASE = os.getenv(
    "DATAEXTRACTION_URL", f"{CTA_HOST}/scoping-dataextraction-agent"
).rstrip("/")
QUERY_SERVICE_BASE = os.getenv(
    "QUERY_SERVICE_URL", f"{CTA_HOST}/query-service"
).rstrip("/")
DEFAULT_PLAN_NUMBER = os.getenv("DEFAULT_PLAN_NUMBER", "20440")
REQUEST_TIMEOUT_SECONDS = float(os.getenv("CT1_TIMEOUT_SECONDS", "60.0"))

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
SAMPLES_FILE = BASE_DIR / "CT1_ENDPOINTS_AND_JSON_SAMPLES.json"
LOCAL_REVIEW_ROOT = Path(os.getenv("LOCAL_REVIEW_ROOT", str(BASE_DIR.parent)))

PLAN_ARTIFACTS: List[Dict[str, str]] = [
    {"id": "policy", "label": "Policies / KOD / Proc", "excludable": "true"},
    {"id": "findings_details", "label": "GFMS Findings", "excludable": "true"},
    {"id": "historical_plan_details", "label": "Historical Plans", "excludable": "true"},
    {"id": "lrr", "label": "LRR Mandates", "excludable": "true"},
    {"id": "current_details", "label": "Current Plan", "excludable": "false"},
    {"id": "alc_nlac", "label": "ALC / NALC", "excludable": "false"},
    {"id": "control_details", "label": "Controls", "excludable": "false"},
    {"id": "risk_driver_details", "label": "Risk Drivers", "excludable": "false"},
    {"id": "group_audit", "label": "Group Audit", "excludable": "false"},
]

_TYPE_ALIASES: Dict[str, str] = {
    "policy": "policy",
    "policies": "policy",
    "kod": "kod",
    "kods": "kod",
    "procedure": "procedure",
    "procedures": "procedure",
    "procedure_documents": "procedure",
    "gfms": "gfms",
    "gfms_data": "gfms",
    "findings": "gfms",
    "findings_details": "gfms",
    "historical": "historical_scoping_document",
    "historical_plan": "historical_scoping_document",
    "historical_plan_details": "historical_scoping_document",
    "historical_scoping": "historical_scoping_document",
    "historical_scoping_document": "historical_scoping_document",
    "lrr": "lrr",
    "lrr_mandates": "lrr",
    "mandates": "lrr",
}

_AFFECTED_SECTIONS_MAP: Dict[str, Tuple[str, ...]] = {
    "policy": ("policy_regulation", "broad_scope"),
    "kod": ("policy_regulation", "broad_scope"),
    "procedure": ("policy_regulation", "broad_scope"),
    "gfms": ("findings_analysis", "broad_scope"),
    "historical_scoping_document": ("historical_plan", "broad_scope"),
    "lrr": ("policy_regulation", "broad_scope"),
}

_EXCLUDED_STATUSES = {"excluded", "removed", "deleted", "inactive"}

# Per-plan in-memory overlay so exclude / include / upload interactions work
# seamlessly even when upstream CT1 query-service returns 503.
_PLAN_STATE: Dict[str, Dict[str, Any]] = {}


class ChatProxyRequest(BaseModel):
    question: str
    plan_number: str
    context_type: str = "Preliminary Research Walkthrough"
    plan_name: Optional[str] = None
    research_sections: Optional[Any] = None
    userDetails: Optional[Dict[str, Any]] = None


class ExtractionRunRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


def create_async_client() -> httpx.AsyncClient:
    """Create the async HTTP client used for live CT1 calls."""
    return httpx.AsyncClient(verify=False, timeout=REQUEST_TIMEOUT_SECONDS)


app = FastAPI(title="CT1 Scoping Query & Data Extraction Demo UI", version="1.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _get_plan_state(plan_number: str) -> Dict[str, Any]:
    key = str(plan_number).strip()
    if key not in _PLAN_STATE:
        _PLAN_STATE[key] = {
            "excluded_docs": set(),       # normalized "{doc_type}|{key}"
            "excluded_sections": set(),   # normalized "{doc_type}|{sec_key}"
            "uploaded_docs": [],          # list[dict]
            "pending_plan": None,
        }
    return _PLAN_STATE[key]


def _norm_key(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if text.lower().endswith(".pdf") or text.lower().endswith(".json"):
        text = text.rsplit(".", 1)[0]
    text = text.replace("_", " ").replace("-", " ")
    return re.sub(r"\s+", " ", text).strip().lower()


def _raw_norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def _normalize_doc_type(value: Any) -> str:
    cleaned = re.sub(r"[\s-]+", "_", str(value or "").strip().lower())
    return _TYPE_ALIASES.get(cleaned, cleaned or "policy")


def _extract_error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            return str(payload.get("detail") or payload.get("message") or payload)
        return str(payload)
    except Exception:
        return response.text[:500] or f"HTTP {response.status_code}"


async def _forward_json(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    json_body: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    response = await client.request(method, url, json=json_body)
    if response.status_code >= 400:
        raise HTTPException(
            status_code=response.status_code,
            detail=_extract_error_detail(response),
        )
    try:
        return response.json()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Invalid JSON from CT1 ({url}): {exc}") from exc


def _read_json_file(path: Path) -> Any:
    try:
        if path.exists() and path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.debug("Unable to read JSON file %s: %s", path, exc)
    return None


def _load_samples_for_plan(plan_number: str) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any]]:
    """Load captured CT1 sample payloads for offline resilience when CTA_HOST is unreachable."""
    sample_doc = _read_json_file(SAMPLES_FILE)
    if not isinstance(sample_doc, dict):
        return None, {}

    artifacts: Dict[str, Any] = {}
    availability: Optional[Dict[str, Any]] = None
    target = str(plan_number).strip()

    for call in sample_doc.get("calls") or []:
        if not isinstance(call, dict) or call.get("status_code") != 200:
            continue
        url = str(call.get("url") or "")
        resp = call.get("response_json")
        if not isinstance(resp, dict):
            continue
        if f"/getdata/{target}/availability" in url:
            availability = copy.deepcopy(resp)
            continue
        marker = f"/getdata/{target}/"
        if marker in url:
            aid = url.split(marker, 1)[1].split("?", 1)[0].strip("/")
            if aid:
                artifacts[aid] = copy.deepcopy(resp)
    return availability, artifacts


def _local_inbound_dir(plan_number: str) -> Optional[Path]:
    candidate = LOCAL_REVIEW_ROOT / f"dbaware_review_{plan_number}" / "inbound-data"
    return candidate if candidate.exists() and candidate.is_dir() else None


def _read_local_part_sections(part_payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    sections: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    for idx, node in enumerate(part_payload.get("nodes") or [], start=1):
        if not isinstance(node, dict):
            continue
        nid = str(node.get("node_id") or f"sec:{idx}")
        if nid in seen:
            continue
        seen.add(nid)
        sid = node.get("section_id") or idx
        stitle = str(node.get("section_title") or node.get("title") or f"Section {sid}").strip()
        sections.append(
            {
                "section_id": sid,
                "section_title": stitle,
                "node_id": nid,
                "page_start": node.get("page_start"),
                "page_end": node.get("page_end"),
                "section_path": node.get("section_path"),
                "status": "active",
                "excluded": False,
            }
        )
    return sections


def _load_local_policy_groups(inbound_dir: Path) -> Dict[str, List[Dict[str, Any]]]:
    """Read local inbound-data/policy files for section enrichment and fallback catalog."""
    by_type: Dict[str, List[Dict[str, Any]]] = {"policy": [], "kod": [], "procedure": []}
    policy_root = inbound_dir / "policy"
    if not policy_root.exists():
        return by_type

    for dtype in ("policy", "kod", "procedure"):
        seen_keys: Set[str] = set()
        part_dir = policy_root / f"relevant_{dtype}"
        if part_dir.exists() and part_dir.is_dir():
            for file_path in sorted(part_dir.glob("*.json")):
                payload = _read_json_file(file_path)
                if not isinstance(payload, dict):
                    continue
                doc_id = str(payload.get("document_id") or file_path.stem)
                title = str(payload.get("document_title") or payload.get("title") or file_path.stem).strip()
                uri = str(payload.get("storage_uri") or payload.get("gs_uri") or "").strip()
                sections = _read_local_part_sections(payload)
                seen_keys.add(_norm_key(title))
                seen_keys.add(_norm_key(uri))
                by_type[dtype].append(
                    {
                        "document_type": dtype,
                        "document_id": doc_id,
                        "document_title": title,
                        "document_name": title,
                        "file_name": file_path.name,
                        "storage_uri": uri,
                        "gs_uri": uri,
                        "status": "excluded" if payload.get("excluded") is True else str(payload.get("status") or "active"),
                        "excluded": bool(payload.get("excluded") is True),
                        "sections": sections,
                    }
                )

        agg_payload = _read_json_file(policy_root / f"relevant_{dtype}.json")
        raw_sources: List[Dict[str, Any]] = []
        if isinstance(agg_payload, dict):
            raw_sources = (
                agg_payload.get("sources")
                or agg_payload.get("documents")
                or agg_payload.get("referenced_documents")
                or []
            )
        elif isinstance(agg_payload, list):
            raw_sources = agg_payload

        grouped_sources: Dict[str, Dict[str, Any]] = {}
        for idx, src in enumerate(raw_sources, start=1):
            if not isinstance(src, dict):
                continue
            dname = str(src.get("document_name") or src.get("document_title") or src.get("title") or "").strip()
            uri = str(src.get("gs_uri") or src.get("storage_uri") or "").strip()
            nk = _norm_key(dname) or _norm_key(uri)
            if not nk or nk in seen_keys:
                continue
            if nk not in grouped_sources:
                grouped_sources[nk] = {
                    "document_type": dtype,
                    "document_id": str(src.get("document_id") or f"{dtype}_{idx}"),
                    "document_title": dname or uri.rsplit("/", 1)[-1],
                    "document_name": dname or uri.rsplit("/", 1)[-1],
                    "file_name": f"{dtype}_{idx}.json",
                    "storage_uri": uri,
                    "gs_uri": uri,
                    "status": "active",
                    "excluded": False,
                    "sections": [],
                }
            page_no = src.get("page_number")
            cls_label = src.get("classification") or ""
            sec_title = f"Page {page_no}" + (f" ({cls_label})" if cls_label else "") if page_no else (src.get("rationale") or f"Source {idx}")
            grouped_sources[nk]["sections"].append(
                {
                    "section_id": str(page_no or src.get("source_index") or idx),
                    "section_title": str(sec_title)[:90],
                    "node_id": f"{dtype}:{nk}:p{page_no or idx}",
                    "status": "active",
                    "excluded": False,
                }
            )
        by_type[dtype].extend(grouped_sources.values())

    return by_type


def _enrich_artifacts_from_local_inbound(
    plan_number: str, artifacts: Dict[str, Any]
) -> Dict[str, Any]:
    """Attach section details to policy refs and backfill empty CT1 LRR/Historical arrays if local fixtures exist."""
    inbound = _local_inbound_dir(plan_number)
    if inbound is None:
        return artifacts

    enriched = copy.deepcopy(artifacts)
    local_policy_groups = _load_local_policy_groups(inbound)

    # 1. Enrich policy.data.referenced_documents with matching part sections & active KOD/Procedure refs
    if "policy" in enriched and isinstance(enriched["policy"], dict):
        pol_env = enriched["policy"]
        pol_data = pol_env.get("data")
        if isinstance(pol_data, dict) and isinstance(pol_data.get("referenced_documents"), list):
            docs_by_norm: Dict[str, Dict[str, Any]] = {}
            for gtype, docs in local_policy_groups.items():
                for d in docs:
                    for candidate in (d.get("document_title"), d.get("gs_uri"), Path(str(d.get("gs_uri") or "")).name):
                        nk = _norm_key(candidate)
                        if nk:
                            docs_by_norm[nk] = d

            seen_ref_keys: Set[str] = set()
            merged_refs: List[Dict[str, Any]] = []
            for ref in pol_data["referenced_documents"]:
                if not isinstance(ref, dict):
                    continue
                ref_copy = dict(ref)
                ref_type = _normalize_doc_type(ref_copy.get("document_type") or "policy")
                ref_name = ref_copy.get("document_name") or ref_copy.get("document_title") or ""
                matched = (
                    docs_by_norm.get(_norm_key(ref_name))
                    or docs_by_norm.get(_norm_key(ref_copy.get("gs_uri")))
                )
                if matched and not ref_copy.get("sections"):
                    ref_copy["sections"] = copy.deepcopy(matched.get("sections") or [])
                if matched and not ref_copy.get("document_id"):
                    ref_copy["document_id"] = matched.get("document_id")
                merged_refs.append(ref_copy)
                seen_ref_keys.add(f"{ref_type}|{_norm_key(ref_name)}")

            for gtype in ("policy", "kod", "procedure"):
                for d in local_policy_groups.get(gtype, []):
                    nk = f"{gtype}|{_norm_key(d.get('document_title'))}"
                    if nk not in seen_ref_keys and not d.get("excluded"):
                        merged_refs.append(
                            {
                                "document_type": gtype,
                                "document_id": d.get("document_id"),
                                "document_name": d.get("document_title"),
                                "gs_uri": d.get("gs_uri"),
                                "file_name": d.get("file_name"),
                                "sections": copy.deepcopy(d.get("sections") or []),
                            }
                        )
                        seen_ref_keys.add(nk)

            pol_data["referenced_documents"] = merged_refs

    # 2. If CT1 LRR returns empty internet_search_data: [], backfill from local internet_search_data_enriched.json if present
    if "lrr" in enriched and isinstance(enriched["lrr"], dict):
        lrr_data = enriched["lrr"].get("data")
        if isinstance(lrr_data, dict):
            existing_lrr = lrr_data.get("internet_search_data_enriched") or lrr_data.get("internet_search_data")
            if not existing_lrr:
                local_enriched = _read_json_file(inbound / "lrr" / "internet_search_data_enriched.json")
                if isinstance(local_enriched, list) and local_enriched:
                    lrr_data["internet_search_data_enriched"] = local_enriched

    # 3. If CT1 historical_plan_details returns [], backfill from local historical_plan_details.json if present
    if "historical_plan_details" in enriched and isinstance(enriched["historical_plan_details"], dict):
        hist_data = enriched["historical_plan_details"].get("data")
        if isinstance(hist_data, dict) and not hist_data.get("historical_plan_details"):
            local_hist = _read_json_file(inbound / "dbaware" / "historical_plan_details.json")
            if isinstance(local_hist, list) and local_hist:
                hist_data["historical_plan_details"] = local_hist

    return enriched


def _unwrap_data_dict(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def _extract_gfms_docs(artifacts: Dict[str, Any]) -> List[Dict[str, Any]]:
    data = _unwrap_data_dict(artifacts.get("findings_details"))
    raw_list = data.get("findings_details") if isinstance(data, dict) else data
    if not isinstance(raw_list, list):
        return []
    docs: List[Dict[str, Any]] = []
    for w_idx, wrapper in enumerate(raw_list, start=1):
        items = wrapper.get("responsePayload") if isinstance(wrapper, dict) and isinstance(wrapper.get("responsePayload"), list) else [wrapper]
        for f_idx, f in enumerate(items or [], start=1):
            if not isinstance(f, dict):
                continue
            fid = str(f.get("findingId") or f.get("id") or f"{w_idx}-{f_idx}")
            raw_title = str(f.get("findingTitle") or f.get("title") or "").strip()
            ct_ref = str(f.get("ct1") or "").strip()
            area = str(f.get("subBusinessArea") or f.get("businessArea") or "").strip()
            label = raw_title if raw_title and set(raw_title) != {"X"} else (ct_ref or area or f"GFMS Finding {fid}")
            display = f"Finding {fid}: {label}"
            docs.append(
                {
                    "document_id": fid,
                    "document_title": display,
                    "file_name": "findings_details.json",
                    "status": "excluded" if f.get("excluded") is True else "active",
                    "excluded": bool(f.get("excluded") is True),
                    "sections": [
                        {
                            "section_id": fid,
                            "section_title": display,
                            "node_id": f"gfms:finding:{fid}",
                            "status": "active",
                            "excluded": False,
                        }
                    ],
                }
            )
    return docs


def _extract_historical_docs(artifacts: Dict[str, Any]) -> List[Dict[str, Any]]:
    data = _unwrap_data_dict(artifacts.get("historical_plan_details"))
    raw_list = data.get("historical_plan_details") if isinstance(data, dict) else data
    if not isinstance(raw_list, list):
        return []
    docs: List[Dict[str, Any]] = []
    for idx, item in enumerate(raw_list, start=1):
        if not isinstance(item, dict):
            continue
        pnum = str(item.get("Plan Item Number") or item.get("plan_item_number") or idx)
        ptitle = str(item.get("Plan Item Title") or item.get("title") or f"Historical Plan {pnum}").strip()
        docs.append(
            {
                "document_id": pnum,
                "document_title": f"Plan {pnum}: {ptitle}",
                "file_name": "historical_plan_details.json",
                "status": "excluded" if item.get("excluded") is True else "active",
                "excluded": bool(item.get("excluded") is True),
                "sections": [],
            }
        )
    return docs


def _extract_lrr_docs(artifacts: Dict[str, Any]) -> List[Dict[str, Any]]:
    data = _unwrap_data_dict(artifacts.get("lrr"))
    if isinstance(data, dict):
        raw_list = data.get("internet_search_data_enriched") or data.get("internet_search_data") or []
    elif isinstance(data, list):
        raw_list = data
    else:
        raw_list = []

    if not isinstance(raw_list, list) or not raw_list:
        return []

    mandate_sections: List[Dict[str, Any]] = []
    m_idx = 0
    for entry in raw_list:
        if not isinstance(entry, dict):
            continue
        risk_name = str(entry.get("Risk Name") or entry.get("risk_name") or "Regulatory Risk").strip()
        mandates = entry.get("Mandates")
        if isinstance(mandates, list):
            for m in mandates:
                if not isinstance(m, dict):
                    continue
                m_idx += 1
                raw_m = str(m.get("Regulatory Mandate") or m.get("mandate") or f"Mandate {m_idx}").strip()
                short_m = raw_m if len(raw_m) <= 85 else f"{raw_m[:82]}..."
                mandate_sections.append(
                    {
                        "section_id": m_idx,
                        "section_title": f"{risk_name}: {short_m}",
                        "node_id": str(m.get("node_id") or f"lrr:mandate:{m_idx}"),
                        "status": "excluded" if m.get("excluded") is True else "active",
                        "excluded": bool(m.get("excluded") is True),
                    }
                )
    return [
        {
            "document_id": "lrr_internet_search_data_enriched",
            "document_title": "Regulatory & Internet Search Mandates",
            "file_name": "internet_search_data_enriched.json",
            "status": "active",
            "excluded": False,
            "sections": mandate_sections,
        }
    ]


def _build_catalog_from_artifacts(
    plan_number: str, artifacts: Dict[str, Any]
) -> Dict[str, Any]:
    """Build the 6-group query-service catalog structure from CT1 artifacts when list-all is 503."""
    grouped: Dict[str, List[Dict[str, Any]]] = {
        "policy": [],
        "kod": [],
        "procedure": [],
        "gfms": _extract_gfms_docs(artifacts),
        "historical_scoping_document": _extract_historical_docs(artifacts),
        "lrr": _extract_lrr_docs(artifacts),
    }

    pol_data = _unwrap_data_dict(artifacts.get("policy"))
    refs = pol_data.get("referenced_documents") if isinstance(pol_data, dict) else []
    for idx, ref in enumerate(refs or [], start=1):
        if not isinstance(ref, dict):
            continue
        dtype = _normalize_doc_type(ref.get("document_type") or "policy")
        if dtype not in ("policy", "kod", "procedure"):
            dtype = "policy"
        title = str(ref.get("document_name") or ref.get("document_title") or f"{dtype}_{idx}").strip()
        grouped[dtype].append(
            {
                "document_id": str(ref.get("document_id") or f"{dtype}_{idx}"),
                "document_title": title,
                "file_name": ref.get("file_name") or f"{title}.json",
                "storage_uri": ref.get("gs_uri") or ref.get("storage_uri") or "",
                "status": "excluded" if ref.get("excluded") is True else str(ref.get("status") or "active"),
                "excluded": bool(ref.get("excluded") is True),
                "sections": copy.deepcopy(ref.get("sections") or []),
            }
        )

    document_groups = [
        {
            "document_type": dtype,
            "total_count": len(docs),
            "documents": docs,
            "source": "ct1_artifacts_fallback",
        }
        for dtype, docs in grouped.items()
    ]
    return {
        "plan_number": plan_number,
        "source": "ct1_artifacts_fallback",
        "total_count": sum(len(docs) for docs in grouped.values()),
        "document_groups": document_groups,
    }


def _match_set_contains(candidate_keys: Iterable[str], excluded_keys: Set[str], doc_type: str) -> bool:
    for key in candidate_keys:
        if not key:
            continue
        if f"{doc_type}|{key}" in excluded_keys or f"*|{key}" in excluded_keys:
            return True
    return False


def _apply_plan_state_to_catalog(plan_number: str, catalog: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not isinstance(catalog, dict):
        return catalog
    st = _get_plan_state(plan_number)
    updated = copy.deepcopy(catalog)
    groups = updated.get("document_groups")
    if not isinstance(groups, list):
        return updated

    # Inject uploaded docs into matching groups
    groups_by_type = {str(g.get("document_type") or "").lower(): g for g in groups if isinstance(g, dict)}
    for up_doc in st["uploaded_docs"]:
        dtype = _normalize_doc_type(up_doc.get("document_type") or "policy")
        grp = groups_by_type.get(dtype)
        if grp is None:
            grp = {"document_type": dtype, "documents": [], "total_count": 0, "source": "uploaded"}
            groups.append(grp)
            groups_by_type[dtype] = grp
        existing_titles = {_norm_key(d.get("document_title") or d.get("document_name")) for d in grp.get("documents") or []}
        if _norm_key(up_doc.get("document_title")) not in existing_titles:
            grp.setdefault("documents", []).append(copy.deepcopy(up_doc))

    ex_docs: Set[str] = st["excluded_docs"]
    ex_secs: Set[str] = st["excluded_sections"]

    total_docs = 0
    for grp in groups:
        if not isinstance(grp, dict):
            continue
        dtype = _normalize_doc_type(grp.get("document_type") or "policy")
        docs = grp.get("documents") or []
        for doc in docs:
            if not isinstance(doc, dict):
                continue
            dkeys = {
                _norm_key(doc.get("document_title")),
                _norm_key(doc.get("document_name")),
                _norm_key(doc.get("file_name")),
                _raw_norm(doc.get("document_id")),
            } - {""}
            if _match_set_contains(dkeys, ex_docs, dtype):
                doc["excluded"] = True
                doc["status"] = "excluded"
            for sec in doc.get("sections") or []:
                if not isinstance(sec, dict):
                    continue
                skeys = {
                    _raw_norm(sec.get("node_id")),
                    _raw_norm(sec.get("section_id")),
                    _norm_key(sec.get("section_title")),
                } - {""}
                if doc.get("excluded") is True or _match_set_contains(skeys, ex_secs, dtype):
                    sec["excluded"] = True
                    sec["status"] = "excluded"
        grp["total_count"] = len(docs)
        total_docs += len(docs)

    updated["total_count"] = total_docs
    return updated


def _apply_plan_state_to_artifacts(plan_number: str, artifacts: Dict[str, Any]) -> Dict[str, Any]:
    """Apply in-memory exclusions/inclusions/uploads onto Data Extraction /getdata payloads."""
    st = _get_plan_state(plan_number)
    ex_docs: Set[str] = st["excluded_docs"]
    ex_secs: Set[str] = st["excluded_sections"]
    uploaded: List[Dict[str, Any]] = st["uploaded_docs"]

    if not ex_docs and not ex_secs and not uploaded:
        return artifacts

    filtered = copy.deepcopy(artifacts)

    # 1. Policy / KOD / Procedure artifact
    if "policy" in filtered and isinstance(filtered["policy"], dict):
        pol_data = filtered["policy"].get("data")
        if isinstance(pol_data, dict) and isinstance(pol_data.get("referenced_documents"), list):
            next_refs: List[Dict[str, Any]] = []
            for ref in pol_data["referenced_documents"]:
                if not isinstance(ref, dict):
                    continue
                dtype = _normalize_doc_type(ref.get("document_type") or "policy")
                dkeys = {
                    _norm_key(ref.get("document_name")),
                    _norm_key(ref.get("document_title")),
                    _norm_key(ref.get("file_name")),
                    _raw_norm(ref.get("document_id")),
                } - {""}
                if _match_set_contains(dkeys, ex_docs, dtype):
                    continue
                if isinstance(ref.get("sections"), list) and ref["sections"]:
                    kept_secs = [
                        s for s in ref["sections"]
                        if isinstance(s, dict)
                        and not _match_set_contains(
                            {_raw_norm(s.get("node_id")), _raw_norm(s.get("section_id")), _norm_key(s.get("section_title"))} - {""},
                            ex_secs,
                            dtype,
                        )
                    ]
                    if not kept_secs:
                        continue
                    ref["sections"] = kept_secs
                next_refs.append(ref)

            for up in uploaded:
                up_type = _normalize_doc_type(up.get("document_type") or "policy")
                up_keys = {_norm_key(up.get("document_title")), _raw_norm(up.get("document_id"))} - {""}
                if up_type in ("policy", "kod", "procedure") and not _match_set_contains(up_keys, ex_docs, up_type):
                    next_refs.append(
                        {
                            "document_type": up_type,
                            "document_id": up.get("document_id"),
                            "document_name": up.get("document_title"),
                            "gs_uri": up.get("storage_uri") or f"uploaded://{up.get('file_name')}",
                            "file_name": up.get("file_name"),
                            "sections": copy.deepcopy(up.get("sections") or []),
                        }
                    )
            pol_data["referenced_documents"] = next_refs

    # 2. GFMS findings_details
    if "findings_details" in filtered and isinstance(filtered["findings_details"], dict):
        f_data = filtered["findings_details"].get("data")
        if isinstance(f_data, dict) and isinstance(f_data.get("findings_details"), list):
            if f"gfms|{_norm_key('findings_details')}" in ex_docs or f"gfms|{_norm_key('findings_details.json')}" in ex_docs:
                f_data["findings_details"] = []
            else:
                next_wrappers = []
                for w in f_data["findings_details"]:
                    if not isinstance(w, dict) or not isinstance(w.get("responsePayload"), list):
                        next_wrappers.append(w)
                        continue
                    kept_f = []
                    for f in w["responsePayload"]:
                        if not isinstance(f, dict):
                            continue
                        fid = str(f.get("findingId") or f.get("id") or "").strip()
                        title_display = f"Finding {fid}: {f.get('ct1') or f.get('findingTitle') or ''}"
                        fkeys = {
                            _raw_norm(fid),
                            f"gfms:finding:{_raw_norm(fid)}",
                            _norm_key(f.get("findingTitle")),
                            _norm_key(title_display),
                        } - {""}
                        if _match_set_contains(fkeys, ex_docs, "gfms") or _match_set_contains(fkeys, ex_secs, "gfms"):
                            continue
                        kept_f.append(f)
                    if kept_f:
                        w_copy = dict(w)
                        w_copy["responsePayload"] = kept_f
                        next_wrappers.append(w_copy)
                f_data["findings_details"] = next_wrappers

    # 3. Historical plan details
    if "historical_plan_details" in filtered and isinstance(filtered["historical_plan_details"], dict):
        h_data = filtered["historical_plan_details"].get("data")
        if isinstance(h_data, dict) and isinstance(h_data.get("historical_plan_details"), list):
            h_data["historical_plan_details"] = [
                item
                for item in h_data["historical_plan_details"]
                if isinstance(item, dict)
                and not _match_set_contains(
                    {
                        _raw_norm(item.get("Plan Item Number")),
                        _norm_key(item.get("Plan Item Title")),
                        _norm_key(f"Plan {item.get('Plan Item Number')}: {item.get('Plan Item Title')}"),
                    }
                    - {""},
                    ex_docs | ex_secs,
                    "historical_scoping_document",
                )
            ]

    # 4. LRR mandates
    if "lrr" in filtered and isinstance(filtered["lrr"], dict):
        lrr_data = filtered["lrr"].get("data")
        if isinstance(lrr_data, dict):
            key_name = "internet_search_data_enriched" if lrr_data.get("internet_search_data_enriched") else "internet_search_data"
            entries = lrr_data.get(key_name)
            if isinstance(entries, list):
                if f"lrr|{_norm_key('Regulatory & Internet Search Mandates')}" in ex_docs:
                    lrr_data[key_name] = []
                else:
                    next_entries = []
                    m_idx = 0
                    for entry in entries:
                        if not isinstance(entry, dict) or not isinstance(entry.get("Mandates"), list):
                            next_entries.append(entry)
                            continue
                        risk_name = str(entry.get("Risk Name") or entry.get("risk_name") or "").strip()
                        kept_m = []
                        for m in entry["Mandates"]:
                            if not isinstance(m, dict):
                                continue
                            m_idx += 1
                            raw_m = str(m.get("Regulatory Mandate") or m.get("mandate") or "").strip()
                            short_m = raw_m if len(raw_m) <= 85 else f"{raw_m[:82]}..."
                            mkeys = {
                                _raw_norm(m_idx),
                                f"lrr:mandate:{m_idx}",
                                _norm_key(raw_m),
                                _norm_key(f"{risk_name}: {short_m}"),
                            } - {""}
                            if _match_set_contains(mkeys, ex_secs | ex_docs, "lrr"):
                                continue
                            kept_m.append(m)
                        if kept_m:
                            e_copy = dict(entry)
                            e_copy["Mandates"] = kept_m
                            next_entries.append(e_copy)
                    lrr_data[key_name] = next_entries

    return filtered


async def _fetch_artifact_safe(
    client: httpx.AsyncClient,
    plan_number: str,
    artifact_id: str,
) -> Dict[str, Any]:
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/{artifact_id}"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "data": resp.json()}
        return {"ok": False, "status_code": resp.status_code, "error": _extract_error_detail(resp), "data": None}
    except Exception as exc:
        return {"ok": False, "status_code": 502, "error": str(exc), "data": None}


async def _fetch_availability_safe(client: httpx.AsyncClient, plan_number: str) -> Dict[str, Any]:
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/availability"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "data": resp.json()}
        return {"ok": False, "status_code": resp.status_code, "error": _extract_error_detail(resp), "data": None}
    except Exception as exc:
        return {"ok": False, "status_code": 502, "error": str(exc), "data": None}


def _unwrap_gateway_catalog(raw: Any) -> Optional[Dict[str, Any]]:
    queue: List[Any] = [raw]
    seen: Set[int] = set()
    while queue:
        cur = queue.pop(0)
        if not isinstance(cur, dict) or id(cur) in seen:
            continue
        seen.add(id(cur))
        if isinstance(cur.get("document_groups"), list):
            return cur
        for key in ("response", "payload", "data", "result"):
            if key in cur:
                queue.append(cur[key])
    return None


async def _fetch_catalog_with_fallback(
    client: httpx.AsyncClient,
    plan_number: str,
    artifacts: Dict[str, Any],
) -> Tuple[Optional[Dict[str, Any]], Optional[str], str]:
    """Fetch document catalog from CT1 Query Service, Gateway, Master Agent, or build from CT1 artifacts."""
    errors: List[str] = []
    candidates = [
        ("query_service", f"{QUERY_SERVICE_BASE}/qna/documents/list-all", {"plan_number": plan_number}),
        (
            "api_gateway",
            f"{CTA_HOST}/dbaware-api-gateway/api/v1/actions",
            {"planNumber": plan_number, "action": "QNA_LIST_DOCUMENTS", "payload": {"plan_number": plan_number}},
        ),
        (
            "master_agent",
            f"{CTA_HOST}/scoping-master-agent/trigger-scoping-master",
            {"planNumber": plan_number, "action": "QNA_LIST_DOCUMENTS", "payload": {"plan_number": plan_number}},
        ),
    ]

    for source_name, url, body in candidates:
        try:
            resp = await client.post(url, json=body, timeout=15.0)
            if resp.status_code == 200:
                parsed = _unwrap_gateway_catalog(resp.json())
                if parsed is not None:
                    return parsed, None, source_name
            errors.append(f"{source_name}: HTTP {resp.status_code} ({_extract_error_detail(resp)[:120]})")
        except Exception as exc:
            errors.append(f"{source_name}: {type(exc).__name__}")

    fallback_catalog = _build_catalog_from_artifacts(plan_number, artifacts)
    notice = "; ".join(errors[:2]) if errors else "Query service unavailable; built catalog from CT1 artifacts"
    return fallback_catalog, notice, "ct1_artifacts_fallback"


async def _load_plan_bundle(plan_number: str) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]], Dict[str, Any], Optional[Dict[str, Any]], Dict[str, str], str]:
    """Load availability, all 9 artifacts, and catalog from CT1 with local/sample fallback."""
    artifact_ids = [item["id"] for item in PLAN_ARTIFACTS]
    async with create_async_client() as client:
        avail_res, *art_results = await asyncio.gather(
            _fetch_availability_safe(client, plan_number),
            *(_fetch_artifact_safe(client, plan_number, aid) for aid in artifact_ids),
        )

        artifacts: Dict[str, Any] = {}
        errors: Dict[str, str] = {}
        availability = avail_res["data"] if avail_res["ok"] else None
        if not avail_res["ok"]:
            errors["availability"] = str(avail_res.get("error") or "Availability unavailable")

        for aid, res in zip(artifact_ids, art_results):
            if res["ok"]:
                artifacts[aid] = res["data"]
            else:
                errors[aid] = str(res.get("error") or f"HTTP {res.get('status_code')}")

        # If all CT1 data extraction calls failed due to offline DNS/network, fall back to captured samples
        if not artifacts:
            sample_avail, sample_artifacts = _load_samples_for_plan(plan_number)
            if sample_artifacts:
                availability = availability or sample_avail
                artifacts = sample_artifacts
                errors.pop("availability", None)
                for aid in list(errors.keys()):
                    if aid in artifacts:
                        errors.pop(aid, None)

        enriched_artifacts = _enrich_artifacts_from_local_inbound(plan_number, artifacts)
        raw_catalog, cat_notice, query_mode = await _fetch_catalog_with_fallback(
            client, plan_number, enriched_artifacts
        )
        if cat_notice:
            errors["catalog"] = cat_notice

    final_catalog = _apply_plan_state_to_catalog(plan_number, raw_catalog)
    final_artifacts = _apply_plan_state_to_artifacts(plan_number, enriched_artifacts)
    return enriched_artifacts, availability, final_artifacts, final_catalog, errors, query_mode


def _resolve_chat_targets(
    user_text: str,
    action: str,
    catalog: Optional[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Resolve @[Group: Doc] / @[Group: Doc > Section] or natural-language targets against catalog."""
    actions: List[Dict[str, Any]] = []
    seen_targets: Set[str] = set()
    groups = (catalog or {}).get("document_groups") or []

    # 1. Exact bracketed @ mentions: @[Group: Doc] or @[Group: Doc > Section]
    mentions = re.findall(r"@\[([^\]]+)\]", user_text)
    for raw_m in mentions:
        if ":" in raw_m:
            group_hint, target_part = raw_m.split(":", 1)
            norm_type = _normalize_doc_type(group_hint)
        else:
            norm_type, target_part = "", raw_m

        if ">" in target_part:
            doc_hint, sec_hint = [p.strip() for p in target_part.split(">", 1)]
        else:
            doc_hint, sec_hint = target_part.strip(), ""

        sec_id_hint = ""
        m_sec = re.match(r"^section\s+([^:]+):\s*(.+)$", sec_hint, flags=re.IGNORECASE)
        if m_sec:
            sec_id_hint = m_sec.group(1).strip()
            sec_hint = m_sec.group(2).strip()

        norm_doc = _norm_key(doc_hint)
        norm_sec = _norm_key(sec_hint)
        for grp in groups:
            gtype = _normalize_doc_type(grp.get("document_type"))
            if norm_type and gtype != norm_type:
                continue
            for doc in grp.get("documents") or []:
                dtitle = str(doc.get("document_title") or doc.get("document_name") or "").strip()
                d_norm = _norm_key(dtitle)
                if not d_norm or (norm_doc not in d_norm and d_norm not in norm_doc):
                    continue
                if sec_hint:
                    matched_sec = None
                    for sec in doc.get("sections") or []:
                        stitle = str(sec.get("section_title") or "").strip()
                        sid = str(sec.get("section_id") or "").strip()
                        if (sec_id_hint and sid.lower() == sec_id_hint.lower()) or (
                            norm_sec and (norm_sec in _norm_key(stitle) or _norm_key(stitle) in norm_sec)
                        ):
                            matched_sec = sec
                            break
                    if matched_sec is not None:
                        tkey = f"{gtype}|{d_norm}|{matched_sec.get('node_id') or matched_sec.get('section_id')}"
                        if tkey not in seen_targets:
                            seen_targets.add(tkey)
                            actions.append(
                                {
                                    "action": action,
                                    "document_type": gtype,
                                    "title": dtitle,
                                    "document_id": doc.get("document_id"),
                                    "filename": doc.get("file_name"),
                                    "section_id": matched_sec.get("section_id"),
                                    "section_title": matched_sec.get("section_title"),
                                    "node_id": matched_sec.get("node_id"),
                                    "row_primary_key": str(matched_sec.get("node_id") or doc.get("document_id") or ""),
                                }
                            )
                        continue
                tkey = f"{gtype}|{d_norm}|doc"
                if tkey not in seen_targets:
                    seen_targets.add(tkey)
                    actions.append(
                        {
                            "action": action,
                            "document_type": gtype,
                            "title": dtitle,
                            "document_id": doc.get("document_id"),
                            "filename": doc.get("file_name"),
                            "section_id": None,
                            "section_title": None,
                            "node_id": None,
                            "row_primary_key": str(doc.get("document_id") or doc.get("file_name") or ""),
                        }
                    )

    if actions:
        return actions

    # 2. Free-text fallback match against document titles in catalog
    clean_query = _norm_key(user_text)
    for grp in groups:
        gtype = _normalize_doc_type(grp.get("document_type"))
        for doc in grp.get("documents") or []:
            dtitle = str(doc.get("document_title") or doc.get("document_name") or "").strip()
            d_norm = _norm_key(dtitle)
            if d_norm and len(d_norm) >= 4 and d_norm in clean_query:
                tkey = f"{gtype}|{d_norm}|doc"
                if tkey not in seen_targets:
                    seen_targets.add(tkey)
                    actions.append(
                        {
                            "action": action,
                            "document_type": gtype,
                            "title": dtitle,
                            "document_id": doc.get("document_id"),
                            "filename": doc.get("file_name"),
                            "row_primary_key": str(doc.get("document_id") or doc.get("file_name") or ""),
                        }
                    )
    return actions


def _apply_actions_to_plan_state(plan_number: str, actions: List[Dict[str, Any]]) -> List[str]:
    st = _get_plan_state(plan_number)
    affected: Set[str] = set()
    for act in actions:
        op = str(act.get("action") or "exclude").lower()
        dtype = _normalize_doc_type(act.get("document_type") or "policy")
        for sec in _AFFECTED_SECTIONS_MAP.get(dtype, ("broad_scope",)):
            affected.add(sec)

        has_section = bool(act.get("node_id") or act.get("section_id") or act.get("section_title"))
        if has_section:
            skeys = {
                f"{dtype}|{_raw_norm(act.get('node_id'))}",
                f"{dtype}|{_raw_norm(act.get('section_id'))}",
                f"{dtype}|{_norm_key(act.get('section_title'))}",
            }
            skeys = {k for k in skeys if not k.endswith("|")}
            if op in ("include", "restore"):
                st["excluded_sections"].difference_update(skeys)
            else:
                st["excluded_sections"].update(skeys)
        else:
            dkeys = {
                f"{dtype}|{_norm_key(act.get('title'))}",
                f"{dtype}|{_norm_key(act.get('filename'))}",
                f"{dtype}|{_raw_norm(act.get('document_id'))}",
            }
            dkeys = {k for k in dkeys if not k.endswith("|")}
            if op in ("include", "restore"):
                st["excluded_docs"].difference_update(dkeys)
            else:
                st["excluded_docs"].update(dkeys)
    return [s for s in ("historical_plan", "findings_analysis", "policy_regulation", "broad_scope") if s in affected]


def _answer_general_qna_from_artifacts(
    plan_number: str,
    question: str,
    artifacts: Dict[str, Any],
) -> str:
    """Grounded Q&A answer built from active (post-exclusion) CT1 artifacts when upstream QnA is 503."""
    plan_det = (_unwrap_data_dict(artifacts.get("current_details")) or {}).get("plan_details") or {}
    refs = (_unwrap_data_dict(artifacts.get("policy")) or {}).get("referenced_documents") or []
    gfms_wrappers = (_unwrap_data_dict(artifacts.get("findings_details")) or {}).get("findings_details") or []
    ctrls = ((_unwrap_data_dict(artifacts.get("control_details")) or {}).get("control_details") or {}).get("included_kcs") or []
    hist_items = (_unwrap_data_dict(artifacts.get("historical_plan_details")) or {}).get("historical_plan_details") or []
    lrr_data = _unwrap_data_dict(artifacts.get("lrr")) or {}
    lrr_items = lrr_data.get("internet_search_data_enriched") or lrr_data.get("internet_search_data") or []

    findings: List[Dict[str, Any]] = []
    for w in gfms_wrappers:
        if isinstance(w, dict) and isinstance(w.get("responsePayload"), list):
            findings.extend(w["responsePayload"])

    mandates: List[str] = []
    for r in lrr_items:
        if isinstance(r, dict) and isinstance(r.get("Mandates"), list):
            for m in r["Mandates"]:
                if isinstance(m, dict) and m.get("Regulatory Mandate"):
                    mandates.append(f"[{r.get('Risk Name', 'LRR')}] {str(m['Regulatory Mandate'])[:120]}")

    lines = [
        f"Summary from active Plan {plan_number} feeds (CT1 query-service fallback):",
    ]
    if isinstance(plan_det, dict) and plan_det.get("Plan Item Title"):
        lines.append(
            f"- Plan: **{plan_det.get('Plan Item Title')}** ({plan_det.get('AU Region', 'n/a')}, Risk: {plan_det.get('UoT Risk Type', 'n/a')})"
        )
    lines.append(f"- Active Governance Documents ({len(refs)}): " + (", ".join(str(r.get("document_name")) for r in refs[:6]) or "None"))
    lines.append(
        f"- Open GFMS Findings ({len(findings)}): "
        + (", ".join(f"{f.get('findingId')} ({f.get('rating', '')} / {f.get('ct1') or f.get('findingStatus', '')})" for f in findings[:4]) or "None")
    )
    lines.append(f"- Included Key Controls ({len(ctrls)}): " + (f"{ctrls[0].get('inventory', {}).get('controlDefinitionNumber')} ({len(ctrls)} assessment units)" if ctrls else "None"))
    lines.append(f"- Historical Scoping Plans ({len(hist_items)}): " + (", ".join(f"Plan {h.get('Plan Item Number')}" for h in hist_items[:4]) or "None"))
    lines.append(f"- Active LRR Mandates ({len(mandates)}): " + ("; ".join(mandates[:2]) or "None"))
    return "\n".join(lines)


@app.get("/api/config")
async def get_config() -> Dict[str, Any]:
    """Return CT1 host settings and artifact metadata definitions."""
    return {
        "cta_host": CTA_HOST,
        "default_plan_number": DEFAULT_PLAN_NUMBER,
        "artifacts": PLAN_ARTIFACTS,
    }


@app.get("/api/ct1/plan/{plan_number}/bootstrap")
async def bootstrap_plan(plan_number: str) -> Dict[str, Any]:
    """
    Fetch live CT1 availability + all 9 Data Extraction payloads alongside
    the Query Service document catalog (falling back smoothly to CT1 artifact
    catalog if CT1 query-service returns 503).
    """
    started = time.perf_counter()
    _, availability, artifacts, catalog, errors, query_mode = await _load_plan_bundle(plan_number)
    return {
        "plan_number": plan_number,
        "cta_host": CTA_HOST,
        "query_mode": query_mode,
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
        "catalog": catalog,
        "availability": availability,
        "artifacts": artifacts,
        "errors": errors,
    }


@app.post("/api/ct1/plan/{plan_number}/reset")
async def reset_plan_state(plan_number: str) -> Dict[str, Any]:
    """Reset in-memory fallback exclusion/upload state for a plan."""
    _PLAN_STATE.pop(str(plan_number).strip(), None)
    return {"status": "reset", "plan_number": plan_number}


@app.get("/api/ct1/dataextraction/status/{session_id}")
async def proxy_extraction_status(session_id: str) -> Dict[str, Any]:
    """Poll CT1 data extraction job status."""
    url = f"{DATAEXTRACTION_BASE}/data-extraction/{session_id}/status"
    async with create_async_client() as client:
        return await _forward_json(client, "GET", url)


@app.get("/api/ct1/dataextraction/{plan_number}/{artifact}")
async def proxy_get_artifact(plan_number: str, artifact: str) -> Any:
    """Live pass-through to CT1 GET /scoping-dataextraction-agent/getdata/{plan_number}/{artifact}."""
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/{artifact}"
    payload: Optional[Dict[str, Any]] = None
    async with create_async_client() as client:
        try:
            resp = await client.get(url)
            if resp.status_code == 200:
                payload = resp.json()
            else:
                raise HTTPException(status_code=resp.status_code, detail=_extract_error_detail(resp))
        except HTTPException:
            raise
        except Exception as exc:
            _, sample_artifacts = _load_samples_for_plan(plan_number)
            if artifact in sample_artifacts:
                payload = sample_artifacts[artifact]
            else:
                raise HTTPException(status_code=502, detail=f"Unable to fetch artifact from CT1: {exc}") from exc

    enriched = _enrich_artifacts_from_local_inbound(plan_number, {artifact: payload})
    applied = _apply_plan_state_to_artifacts(plan_number, enriched)
    return applied[artifact]


@app.post("/api/ct1/dataextraction/run")
async def proxy_run_extraction(payload: ExtractionRunRequest) -> Dict[str, Any]:
    """Trigger a fresh CT1 data extraction run."""
    url = f"{DATAEXTRACTION_BASE}/data-extraction"
    body = {"planNumber": payload.planNumber, "userDetails": payload.userDetails or {"user": "demo.user@db.com"}}
    async with create_async_client() as client:
        return await _forward_json(client, "POST", url, json_body=body)


@app.post("/api/ct1/query/chat")
async def proxy_query_chat(payload: ChatProxyRequest) -> Dict[str, Any]:
    """Forward chat turns to CT1 Query Service with automatic resilient workflow fallback on 503."""
    plan_number = str(payload.plan_number).strip()
    url = f"{QUERY_SERVICE_BASE}/qna/chat"
    body: Dict[str, Any] = {
        "question": payload.question,
        "plan_number": plan_number,
        "context_type": payload.context_type,
        "userDetails": payload.userDetails or {"user": "demo.user@db.com"},
    }
    if payload.plan_name:
        body["plan_name"] = payload.plan_name
    if payload.research_sections is not None:
        body["research_sections"] = payload.research_sections

    # 1. Try live CT1 Query Service first
    upstream_error: Optional[str] = None
    async with create_async_client() as client:
        try:
            resp = await client.post(url, json=body)
            if resp.status_code < 400:
                data = resp.json()
                wf = data.get("document_workflow") if isinstance(data, dict) else None
                if isinstance(wf, dict) and str(wf.get("stage") or "").lower() == "executed":
                    executed = (
                        (wf.get("execution") or {}).get("executed")
                        or wf.get("executed")
                        or (wf.get("plan") or {}).get("actions")
                        or wf.get("actions")
                        or []
                    )
                    _apply_actions_to_plan_state(plan_number, executed)
                return data
            if resp.status_code not in (404, 502, 503, 504):
                raise HTTPException(status_code=resp.status_code, detail=_extract_error_detail(resp))
            upstream_error = f"HTTP {resp.status_code}: {_extract_error_detail(resp)}"
        except HTTPException:
            raise
        except Exception as exc:
            upstream_error = str(exc)

    logger.warning("CT1 query-service /qna/chat unavailable (%s); running fallback workflow engine.", upstream_error)

    # 2. Resilient workflow + Q&A fallback over loaded CT1 artifacts & catalog
    _, _, final_artifacts, catalog, _, _ = await _load_plan_bundle(plan_number)
    st = _get_plan_state(plan_number)
    text = payload.question.strip()
    lower = text.lower()

    if st["pending_plan"] is not None:
        if re.match(r"^(approve|approved|yes|confirm|execute)\b", lower):
            pending = st["pending_plan"]
            st["pending_plan"] = None
            actions = pending["actions"]
            affected_sections = _apply_actions_to_plan_state(plan_number, actions)
            summary_lines = [
                f"**Applied {len(actions)} change(s) to Plan {plan_number}** (fallback workflow while CT1 query-service was `{upstream_error}`):"
            ]
            for act in actions:
                verb = "Included" if act["action"] == "include" else "Excluded"
                target = f"{act['title']} › {act['section_title']}" if act.get("section_title") else act["title"]
                summary_lines.append(f"- {verb} `{act['document_type']}` **{target}**")
            return {
                "session_id": plan_number,
                "answer": "\n".join(summary_lines),
                "document_workflow": {
                    "stage": "executed",
                    "plan_id": pending["plan_id"],
                    "plan_number": plan_number,
                    "plan": {"actions": actions},
                    "actions": actions,
                    "executed": actions,
                    "affected_sections": affected_sections,
                },
            }
        if re.match(r"^(cancel|reject|rejected|no|abort)\b", lower):
            pending = st["pending_plan"]
            st["pending_plan"] = None
            return {
                "session_id": plan_number,
                "answer": "Cancelled the proposed document scope plan. Nothing was modified.",
                "document_workflow": {
                    "stage": "cancelled",
                    "plan_id": pending["plan_id"],
                    "plan_number": plan_number,
                    "plan": {"actions": pending["actions"]},
                },
            }

    is_include = bool(re.search(r"\b(include|restore|re-include|add back|reinstate|add)\b", lower))
    is_exclude = bool(re.search(r"\b(exclude|remove|delete|drop|omit)\b", lower))
    if is_exclude or is_include or "@[" in text:
        op = "include" if is_include and not is_exclude else "exclude"
        actions = _resolve_chat_targets(text, op, catalog)
        if not actions:
            return {
                "session_id": plan_number,
                "answer": "Could not match any document or section in the active catalog. Use `@` to select an exact item.",
                "document_workflow": None,
            }
        plan_id = f"fallback-{uuid.uuid4().hex[:8]}"
        st["pending_plan"] = {"plan_id": plan_id, "actions": actions}
        return {
            "session_id": plan_number,
            "answer": (
                f"Proposed {len(actions)} {op} action(s) for Plan {plan_number}. "
                "Review below and click **Approve & Execute** to update the Data Extraction feed."
            ),
            "document_workflow": {
                "stage": "awaiting_approval",
                "plan_id": plan_id,
                "plan_number": plan_number,
                "plan": {"actions": actions},
                "actions": actions,
            },
        }

    return {
        "session_id": plan_number,
        "answer": _answer_general_qna_from_artifacts(plan_number, text, final_artifacts),
        "document_workflow": None,
    }


def _build_uploaded_doc_record(filename: str, content: bytes, doc_type: str) -> Dict[str, Any]:
    doc_id = f"upload-{uuid.uuid4().hex[:6]}"
    title = Path(filename).stem
    sections: List[Dict[str, Any]] = []

    if filename.lower().endswith(".json"):
        try:
            parsed = json.loads(content.decode("utf-8"))
            if isinstance(parsed, dict):
                title = str(parsed.get("document_title") or parsed.get("title") or title)
                sections = _read_local_part_sections(parsed)
        except Exception:
            pass
    if not sections:
        sections = [
            {
                "section_id": "1",
                "section_title": f"Uploaded content ({filename})",
                "node_id": f"{doc_id}:sec:1",
                "status": "active",
                "excluded": False,
            }
        ]

    return {
        "document_id": doc_id,
        "document_title": title,
        "document_name": title,
        "document_type": doc_type,
        "file_name": filename,
        "storage_uri": f"uploaded://{doc_type}/{filename}",
        "status": "active",
        "excluded": False,
        "sections": sections,
    }


@app.post("/api/ct1/query/ingest")
async def proxy_query_ingest(
    plan_number: str = Form(...),
    document_type: str = Form("policy"),
    files: List[UploadFile] = File(...),
) -> Dict[str, Any]:
    """Forward multipart upload to CT1 /query-service/qna/documents/ingest and sync into demo state."""
    if not files:
        raise HTTPException(status_code=400, detail="At least one file is required.")

    dtype = _normalize_doc_type(document_type)
    field_map = {"policy": "policy_files", "kod": "kod_files", "procedure": "procedure_files"}
    target_field = field_map.get(dtype, "files")

    raw_uploads: List[Tuple[str, bytes, str]] = []
    form_files = []
    for upload in files:
        content = await upload.read()
        fname = upload.filename or "document.pdf"
        ctype = upload.content_type or "application/pdf"
        raw_uploads.append((fname, content, ctype))
        form_files.append((target_field, (fname, content, ctype)))

    st = _get_plan_state(plan_number)
    for fname, content, _ in raw_uploads:
        record = _build_uploaded_doc_record(fname, content, dtype)
        st["uploaded_docs"].append(record)
        st["excluded_docs"].discard(f"{dtype}|{_norm_key(record['document_title'])}")

    url = f"{QUERY_SERVICE_BASE}/qna/documents/ingest"
    async with create_async_client() as client:
        try:
            resp = await client.post(
                url,
                data={"plan_number": plan_number, "document_type": dtype},
                files=form_files,
                timeout=30.0,
            )
            if resp.status_code < 400:
                payload = resp.json()
                payload["files_uploaded"] = [f for f, _, _ in raw_uploads]
                return payload
            if resp.status_code not in (404, 502, 503, 504):
                raise HTTPException(status_code=resp.status_code, detail=_extract_error_detail(resp))
            upstream_msg = f"HTTP {resp.status_code}: {_extract_error_detail(resp)}"
        except HTTPException:
            raise
        except Exception as exc:
            upstream_msg = str(exc)

    return {
        "status": "ingested_fallback",
        "job_id": f"local-{uuid.uuid4().hex[:8]}",
        "plan_number": plan_number,
        "document_type": dtype,
        "files_uploaded": [f for f, _, _ in raw_uploads],
        "message": f"Registered locally in active plan catalog & Data Extraction feed (CT1 ingest unavailable: {upstream_msg}).",
    }


@app.get("/")
async def index() -> FileResponse:
    """Serve the demo UI single-page app."""
    return FileResponse(STATIC_DIR / "index.html")


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8095"))
    uvicorn.run(app, host="0.0.0.0", port=port)
