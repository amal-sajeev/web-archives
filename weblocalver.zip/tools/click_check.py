"""Click a worklist row in a real browser and report whether the page moved.

    python tools/click_check.py http://127.0.0.1:8000/corp/index.html
    python tools/click_check.py file:///D:/.../site/corp/index.html

Drives headless Chrome over the DevTools protocol, because what is being
tested is a click. Everything short of one passed while this was broken:
the rows were there, the panels were there, the script was linked, and
following a row still threw the reader back to the top of the page. The
handler read the collection reference out of the link's href, which is
what the href says on a server and not what it says once freezing has
rewritten it into a flat filename.

Checked, after scrolling down so a jump would be unmistakable:

  * the panel switches to the row that was clicked;
  * window.scrollY does not move;
  * the document is not replaced - a marker set before the click has to
    survive it, because comparing location.href would report pushState,
    which is the thing we want, as a navigation, which is the thing we
    do not.

Run it against both the served copy and file://. The second is how the
zip is opened, and pushState is refused there, so only the panel switch
and the scroll position are expected to hold.
"""
import asyncio
import json
import pathlib
import subprocess
import sys
import urllib.request

import websockets

CHROME = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]
PORT = 9222


def chrome() -> str:
    for c in CHROME:
        if pathlib.Path(c).exists():
            return c
    raise SystemExit("no Chrome or Edge found")


async def run(url: str) -> int:
    proc = subprocess.Popen(
        [chrome(), "--headless=new", f"--remote-debugging-port={PORT}",
         "--disable-gpu", "--no-first-run", "--no-default-browser-check",
         "--user-data-dir=" + str(pathlib.Path.home() / ".cache" / "cdp-profile"),
         "--window-size=1500,900", "--allow-file-access-from-files", url],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        ws_url = None
        for _ in range(60):
            await asyncio.sleep(0.5)
            try:
                raw = urllib.request.urlopen(
                    f"http://127.0.0.1:{PORT}/json", timeout=2).read()
                for t in json.loads(raw):
                    if t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
                        ws_url = t["webSocketDebuggerUrl"]
                        break
            except Exception:
                pass
            if ws_url:
                break
        if not ws_url:
            print("  could not reach the browser")
            return 1

        async with websockets.connect(ws_url, max_size=40_000_000) as ws:
            n = 0

            async def call(method, **params):
                nonlocal n
                n += 1
                await ws.send(json.dumps({"id": n, "method": method,
                                          "params": params}))
                while True:
                    msg = json.loads(await ws.recv())
                    if msg.get("id") == n:
                        return msg.get("result", {})

            async def js(expr):
                r = await call("Runtime.evaluate", expression=expr,
                               returnByValue=True, awaitPromise=True)
                return r.get("result", {}).get("value")

            await call("Page.enable")
            await call("Runtime.enable")
            await asyncio.sleep(2.5)

            ready = await js("document.readyState")
            rows = await js("document.querySelectorAll('.pickrow__hit').length")
            panels = await js("document.querySelectorAll('.detail[data-sel]').length")
            script = await js(
                "!!document.querySelector('script[src*=\"pick.js\"]')")
            print(f"  page {ready}: {rows} rows, {panels} panels, "
                  f"pick.js linked: {script}")
            if not rows:
                print("  no rows to click")
                return 1

            # scroll down so a jump to the top is unmistakable
            await js("window.scrollTo(0, 600)")
            await asyncio.sleep(0.3)
            before = await js("Math.round(window.scrollY)")
            # A marker that a real navigation would destroy. Comparing
            # location.href instead reports pushState as a navigation,
            # which is the opposite of what pushState is for.
            await js("window.__stillHere = 'yes'")
            shown_before = await js(
                "(document.querySelector('.detail[data-sel]:not([hidden])')"
                "||{}).getAttribute? document.querySelector("
                "'.detail[data-sel]:not([hidden])').getAttribute('data-sel'):''")

            # click the last row, which is furthest from the current panel,
            # and click its beneficiary cell rather than its link: the whole
            # row is the target, so the check has to land somewhere the link
            # is not.
            clicked = await js("""
              (function () {
                var rows = document.querySelectorAll('tr.pickrow');
                var row = rows[rows.length - 1];
                var ref = row.querySelector('.pickrow__hit').getAttribute('data-ref');
                var cell = row.querySelector('td:nth-child(3)');
                cell.dispatchEvent(new MouseEvent('click',
                  {bubbles: true, cancelable: true, button: 0}));
                return ref;
              })()""")
            await asyncio.sleep(1.2)

            after = await js("Math.round(window.scrollY)")
            shown_after = await js(
                "(function(){var p=document.querySelector("
                "'.detail[data-sel]:not([hidden])');"
                "return p?p.getAttribute('data-sel'):'';})()")
            navigated = (await js("window.__stillHere")) != "yes"
            href_now = await js("location.href")

            print(f"  clicked      : {clicked}")
            print(f"  panel before : {shown_before}")
            print(f"  panel after  : {shown_after}")
            print(f"  scrollY      : {before} -> {after}")
            print(f"  document kept: {not navigated}")
            print(f"  url now      : {href_now.rsplit('/', 1)[-1]}")

            ok = True
            if shown_after != clicked:
                print("  FAIL the panel did not switch to the row clicked")
                ok = False
            if after != before:
                print(f"  FAIL the page moved ({before} -> {after})")
                ok = False
            if navigated:
                print("  FAIL the document was replaced: the link was followed")
                ok = False
            if ok:
                print("  PASS panel switched, page did not move, no navigation")
            return 0 if ok else 1
    finally:
        proc.terminate()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run(sys.argv[1])))
