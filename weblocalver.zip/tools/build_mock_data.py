"""Turn the supplied sample workbooks into the JSON the mock APIs serve.

Run it again whenever the bank sends newer files:

    python tools/build_mock_data.py

Everything it writes lands in app/data/. Nothing else reads the .xlsx files, so
the application has no dependency on Excel at runtime.

Sources, all under "sample data with screenshots":
  IDPMS file.xlsx        the import transactions
  Scenario 1/2/3.xlsx    FX settlement deals, plus portal screenshots
  Forex Conversion.xlsx  card rates, nostro and TF accounts
  opera_*.png            the covering email: the forex conversion clause and
                         the written procedure for extraction, checks and charges

The Autobahn instructions, the TradePay records and the rules carried in the
email only exist as screenshots, so they are transcribed below rather than
parsed.
"""

from __future__ import annotations

import json
import pathlib
import re
from datetime import date, datetime

import openpyxl

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "sample data with screenshots"
OUT = ROOT / "app" / "data"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def clean(v):
    if v is None:
        return None
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, str):
        v = " ".join(v.split())
        return v or None
    return v


def as_date(v):
    """IDPMS dates arrive as dd/mm/yyyy strings or as real datetimes."""
    if v is None:
        return None
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    s = str(v).strip()
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return s


def write(name: str, payload: dict) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    payload["_generated"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    (OUT / name).write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    body = (payload.get("records") or payload.get("clients")
            or payload.get("ports") or payload.get("checks") or [])
    print(f"  {name:<16} {len(body):>3} entries")


# ---------------------------------------------------------------------------
# IDPMS — the import transactions
# ---------------------------------------------------------------------------

DATE_COLS = {"billOfEntryDate", "IGMDate", "MAWB-MBLDate", "HAWB-HBLDate", "invoiceDate"}

# enough to turn a supplier country into the 2-letter code the port search needs
COUNTRY_ISO2 = {
    "SINGAPORE": "SG", "CHINA": "CN", "GERMANY": "DE", "THAILAND": "TH",
    "HONG KONG": "HK", "INDIA": "IN", "JAPAN": "JP", "KOREA": "KR",
    "UNITED STATES": "US", "USA": "US", "UNITED KINGDOM": "GB",
    "FRANCE": "FR", "ITALY": "IT", "SPAIN": "ES", "NETHERLANDS": "NL",
    "SWITZERLAND": "CH", "MALAYSIA": "MY", "TAIWAN": "TW", "VIETNAM": "VN",
    "INDONESIA": "ID", "AUSTRALIA": "AU", "BELGIUM": "BE", "AUSTRIA": "AT",
    "SWEDEN": "SE", "CZECH REPUBLIC": "CZ", "POLAND": "PL", "TURKEY": "TR",
}


def build_idpms() -> dict:
    wb = openpyxl.load_workbook(SRC / "IDPMS file.xlsx", data_only=True)
    ws = wb.active
    header = [clean(c.value) for c in ws[1]]

    records = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        rec = {}
        for key, val in zip(header, row):
            if not key:
                continue
            rec[key] = as_date(val) if key in DATE_COLS else clean(val)
        if not rec.get("billOfEntryNumber"):
            continue
        rec["billOfEntryNumber"] = str(rec["billOfEntryNumber"])
        records.append(rec)

    # The extract repeats a Bill of Entry once per invoice line. Flag the
    # repeats so the pipeline can dedupe before anything reaches TF3.
    counts: dict[str, int] = {}
    for rec in records:
        boe = rec["billOfEntryNumber"]
        counts[boe] = counts.get(boe, 0) + 1
    seen: dict[str, int] = {}
    for rec in records:
        boe = rec["billOfEntryNumber"]
        seen[boe] = seen.get(boe, 0) + 1
        rec["recordId"] = f"{boe}-{seen[boe]}"
        rec["lineNo"] = seen[boe]
        rec["linesForThisBoe"] = counts[boe]
        rec["isRepeatedBoe"] = counts[boe] > 1
        # the 2-letter code a 3-digit port code needs prepended
        rec["supplierCountryIso2"] = COUNTRY_ISO2.get(
            (rec.get("supplierCountry") or "").strip().upper())

    return {
        "source": "IDPMS file.xlsx",
        "note": "Import Data Processing and Monitoring System extract. One row per "
                "invoice line; a Bill of Entry may carry several, which the "
                "pipeline deduplicates before posting to TF3.",
        "repeatedBillsOfEntry": sorted(b for b, n in counts.items() if n > 1),
        "records": records,
    }


# ---------------------------------------------------------------------------
# FX settlement deals, from the Scenario workbooks
# ---------------------------------------------------------------------------

DEAL_REF = re.compile(r"^\d{3}\s?ICS\s?\d+$", re.I)


def _deal_tail(tail: list) -> dict:
    """The money end of a deal row, read from its shape rather than its columns.

    Reading these by column number was wrong, and silently so. One row in
    Scenario 2 — Putzmeister — carries no contract reference and sits one
    column to the left of the others, so a positional read gave it
    ``rate: "INR"``, ``currency: 15255.93`` and ``amount: "784 ICS260134"``.
    Nothing complained: every field had something in it.

    Read from the right instead, where the shape is fixed. The last three
    values of every row in these workbooks are the reference, the amount and
    the currency it is in. What remains in front of them is, in order, an
    optional contract reference, the rate, the currency the rate is quoted
    against, and an optional rupee total.
    """
    tail = [v for v in tail if v not in (None, "")]
    if len(tail) < 4:
        raise ValueError(f"a deal row with too few values to read: {tail!r}")

    reference, amount, currency = tail.pop(), tail.pop(), tail.pop()

    def is_money(v) -> bool:
        return isinstance(v, (int, float)) or (
            isinstance(v, str) and re.fullmatch(r"-?[\d,]*\.?\d+", v.strip()))

    # A contract reference is the only thing here that is neither a number,
    # nor a currency code, nor the EEFC marker that stands in for a rate.
    contract = None
    if tail and not is_money(tail[0]) and str(tail[0]).upper() != "EEFC" \
            and str(tail[0]).upper() not in CURRENCIES:
        contract = tail.pop(0)

    rate = tail.pop(0) if tail else None
    base = tail.pop(0) if tail else None
    inr = tail.pop(0) if tail else None

    # Loud rather than silent: a row that does not read this way has changed
    # shape, and guessing at it is what produced the bug above.
    if not DEAL_REF.match(str(reference)):
        raise ValueError(f"deal reference does not look like one: {reference!r}")
    if str(currency).upper() not in CURRENCIES:
        raise ValueError(f"deal currency does not look like one: {currency!r}")
    if base is not None and str(base).upper() not in CURRENCIES:
        raise ValueError(f"deal base currency does not look like one: {base!r}")
    if tail:
        raise ValueError(f"unread values left on a deal row: {tail!r}")

    return {"contractRef": contract, "rate": rate, "baseCurrency": base,
            "inrAmount": inr, "currency": currency, "amount": amount,
            "reference": str(reference).replace(" ", "")}


def build_deals() -> dict:
    records = []
    for n in (1, 2, 3):
        path = SRC / f"Scenario {n}.xlsx"
        if not path.exists():
            continue
        wb = openpyxl.load_workbook(path, data_only=True)
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                vals = [clean(c) for c in row]
                if not vals or not isinstance(vals[0], str):
                    continue
                if not re.fullmatch(r"\d{2}\.\d{2}\.\d{4}", vals[0].strip()):
                    continue
                date, branch, client, deal_type = (vals + [None] * 4)[:4]
                records.append({
                    "dealDate": as_date(date), "branch": branch,
                    "client": client, "dealType": deal_type,
                    **_deal_tail(vals[4:]), "scenario": n,
                })
    return {
        "source": "Scenario 1-3.xlsx",
        "note": "FX settlement deals booked against the import transactions.",
        "records": records,
    }


# ---------------------------------------------------------------------------
# FX — card rates, and the conversion clause from the covering email
# ---------------------------------------------------------------------------

# the rate block sits next to other three-letter labels (GST, ICA...), so the
# scrape is held to real currency codes
CURRENCIES = {
    "USD", "EUR", "GBP", "JPY", "CHF", "SGD", "HKD", "AUD", "SEK", "CAD",
    "DKK", "NOK", "AED", "NZD", "CNY", "THB", "ZAR", "RUB", "MYR", "KRW",
    "TWD", "IDR", "PHP", "VND", "SAR", "QAR", "KWD", "BHD", "OMR", "ILS",
    "PLN", "CZK", "HUF", "TRY", "MXN", "BRL", "LKR", "BDT", "NPR", "INR",
}


def build_fx() -> dict:
    wb = openpyxl.load_workbook(SRC / "Forex Conversion.xlsx", data_only=True)
    rates: dict[str, float] = {}
    ws = wb["CALCULATOR MODIFIED"]
    for row in ws.iter_rows(values_only=True):
        for i, cell in enumerate(row[:-1]):
            if not isinstance(cell, str):
                continue
            code = cell.strip().rstrip("*")
            if code not in CURRENCIES:
                continue
            nxt = row[i + 1]
            if isinstance(nxt, (int, float)) and nxt > 0:
                rates[code] = round(float(nxt), 4)

    # Some currencies in the data (CNY, THB) have no card rate. The settlement
    # deals carry the rate actually applied, so use those, marked as such.
    dealt: dict[str, float] = {}
    for rec in build_deals()["records"]:
        ccy, rate = rec.get("currency"), rec.get("rate")
        if ccy and ccy not in rates and isinstance(rate, (int, float)) and rate > 0:
            dealt[ccy] = round(float(rate), 6)

    return {
        "source": "Forex Conversion.xlsx (card rates) + covering email (clause)",
        "ratesFromDeals": dealt,
        "ratesFromDealsNote": "Currencies with no card rate on file. Taken from the "
                              "rate on the booked settlement deal.",
        "note": "Card rates are INR per unit of the foreign currency.",
        "cardRates": rates,
        "forexConversionClause": {
            "quotedAs": "1% of the gross amount exchanged up to INR 1 lakh, subject to a "
                        "minimum of INR 250; INR 1,000 + 0.5% above INR 1 lakh and up to "
                        "INR 10 lakh; INR 5,500 + 0.1% above INR 10 lakh, subject to a "
                        "maximum of INR 60,000. GST at 18% on the value arrived at.",
            # The percentage applies to the amount above each tier's lower
            # bound, not to the whole gross: 1% of one lakh is 1,000, and
            # 1,000 + 0.5% of nine lakh is 5,500, so every fixed figure is the
            # cumulative charge at the bound below it.
            "appliesTo": "The percentage applies to the amount above the tier's "
                         "lower bound, not to the whole gross. Each tier's fixed "
                         "figure is the cumulative charge at that bound.",
            "tiers": [
                {"fromInr": 0,       "upToInr": 100000,  "fixedInr": 0,
                 "percent": 1.0, "minimumInr": 250},
                {"fromInr": 100000,  "upToInr": 1000000, "fixedInr": 1000,
                 "percent": 0.5},
                {"fromInr": 1000000, "upToInr": None,    "fixedInr": 5500,
                 "percent": 0.1, "maximumInr": 60000},
            ],
            "gstPercent": 18,
        },
        "records": [{"currency": k, "inrPerUnit": v} for k, v in sorted(rates.items())],
    }


# ---------------------------------------------------------------------------
# Autobahn / OEMS — transcribed from the Scenario 3 screenshots
# ---------------------------------------------------------------------------

AUTOBAHN = [
    {
        "client": "SYMRISE PVT LTD",
        "matches": ["SYMRISE"],
        "product": "Import Collection",
        "tab": "Products",
        "field": "Processing",
        "processingText": (
            "IC\n\n"
            "INR 350 PER TRANSACTION FOR IMPORT\n"
            "PAYMENTS, AGENCY COMMISSION, GR\n"
            "WAIVERS AND NON REMITTANCE\n"
            "CERTIFICATE.\n"
            "(As per approval from Sreenath Vakkaleri on\n"
            "14Aug23)"
        ),
    },
    {
        "client": "HELLA INDIA AUTOMOTIVE PVT LTD",
        "matches": ["HELLA INDIA AUTOMOTIVE", "HELLA"],
        "product": "Import Collection",
        "tab": "Products",
        "field": "Processing",
        "processingText": (
            "IC\n"
            "same as HELLA INDIA lighting\n"
            "master number:1001916\n"
            "Import Payment: INR 450 per document\n"
            "Pricing to be levied at remittance level as\n"
            "per approvals from Gaurav dtd 21.01.2019\n\n"
            "EXTENDED EMAIL TEMP INDEM IN PLACE\n"
            "UPTO 30.04.20, CALL BACK PERFORMED BY RM\n"
            "YOGESH P 070420"
        ),
    },
    {
        "client": "PHOENIX CONTACT (INDIA) PVT LTD",
        "matches": ["PHOENIX CONTACT"],
        "product": "Import Collection",
        "tab": "Products",
        "field": "Processing",
        "processingText": (
            "IC\n"
            "Commission - INR 1000 per import doc and not at\n"
            "BOE level\n"
            "As per approvals from Gaurav Matur dtd 21.01.2019"
        ),
    },
]


def build_autobahn() -> dict:
    return {
        "source": "Scenario 3.xlsx (screenshots)",
        "note": "Free-format processing text from the Products tab of each client in "
                "Autobahn/OEMS. Transcribed from the screenshots; wording and line "
                "breaks reproduced as they appear. This is a sample of three "
                "clients, not the pricing book: one of them has no transaction in "
                "the data, and several importers that do have transactions have no "
                "page here. A client missing from this file has not had its pricing "
                "supplied; it does not follow that none exists.",
        "isSample": True,
        "clients": AUTOBAHN,
    }


# ---------------------------------------------------------------------------
# TradePay — transcribed from the Scenario 1 and 2 screenshots
# ---------------------------------------------------------------------------

TRADEPAY = [
    # ---------------------------------------------------------------- Scenario 1
    # Symrise — View & Export Payments, images 1 and 2.
    {
        "domain": "cnsymrisetrade.ap",
        "entity": "SYMRISE PRIVATE LIMITED",
        "billOfEntryNumber": "2450662",
        "billOfEntryDate": "2026-07-11",
        "debitAccount": "5000740-00-0 INR",
        "vendorCode": "7018863",
        "drawerName": "TWINTECH S PTE LTD",
        "drawerCountry": "SINGAPORE",
        "paymentCurrency": "SGD",
        "paymentAmount": 11699.72,
        "adjustmentAmount": 0.0,
        "paymentDate": "2026-10-01",
        "invoiceCount": 1,
        "tiiReference": "T000507456",
        "status": "Payment under Process",
        "groupOfVendor": "Third Party",
        "foreignBankCharges": "BEN",
        "documentType": "Direct Import",
        "invoiceNo": "INV260612999",
        "invoiceDate": "2026-06-25",
        "invoiceCurrency": "SGD",
        "invoiceAmount": 11699.72,
        "invoiceDueDate": "2026-08-24",
        "erpCustomerRef": "1000009238",
        "financialYear": "2025-2026",
        "_source": "Scenario 1, images 1-2",
    },

    # Rothe Erde — View & Export Invoices, images 3 and 4. Nine CNY invoices
    # split across two Bills of Entry on one TII reference. The amounts agree
    # with IDPMS line for line.
    *[
        {
            "domain": "rotheerdetrade.ap",
            "entity": "ROTHE ERDE INDIA PRIVATE LIMITED",
            "billOfEntryNumber": boe,
            "billOfEntryDate": boe_date,
            # The vendor-name column is scrolled out of frame in image 3; only
            # the country is legible. Recording a name here would be inventing
            # one, so the drawer-name check reports it as not captured.
            "drawerName": None,
            "drawerNameNotCaptured": True,
            "drawerCountry": "CHINA",
            "invoiceNo": f"HAILU {serial}",
            "invoiceDate": "2026-04-17",
            "invoiceCurrency": "CNY",
            "invoiceAmount": amount,
            "invoiceOutstanding": amount,
            "paymentAmount": amount,
            "adjustmentAmount": 0.0,
            "invoiceDueDate": "2026-05-29",
            "paymentDate": "2026-09-30",
            "tiiReference": "T000503560",
            "tf3Reference": "ICS2615416",
            "tf3ReceivedAt": "2026-10-05 17:58:55",
            "goodsDescription": "RAW RINGS",
            "documentType": "Direct Import",
            "_source": "Scenario 1, images 3-4",
        }
        for boe, boe_date, serial, amount in [
            ("9391455", "2026-05-20", "202611044", 571430.00),
            ("9391455", "2026-05-20", "202611046", 76069.00),
            ("9391455", "2026-05-20", "202611048", 650280.00),
            ("9391455", "2026-05-20", "202611050", 1291199.00),
            ("9391455", "2026-05-20", "202611051", 441372.00),
            ("9152082", "2026-05-09", "202611045", 46158.00),
            ("9152082", "2026-05-09", "202611047", 574616.00),
            ("9152082", "2026-05-09", "202611049", 352639.00),
            ("9152082", "2026-05-09", "202611052", 23758.00),
        ]
    ],

    # Bosch Rexroth — images 5 and 6. The vendor name is cut off at the left
    # edge of the screenshot; IDPMS holds it in full as HEINRICHS DREHTEILE
    # GMBH CO. KG, and only the legible part is recorded here.
    {
        "domain": "bbboschrexrothtrade.ap",
        "entity": "BOSCH REXROTH INDIA PVT LTD",
        "billOfEntryNumber": "3079950",
        "billOfEntryDate": "2026-08-11",
        "drawerName": "E GMBH CO KG",
        "drawerNameTruncated": True,
        "drawerCity": "DOMMERSHAUSEN",
        "drawerCountry": "GERMANY",
        "invoiceNo": "60075468",
        "invoiceDate": "2026-08-05",
        "invoiceCurrency": "EUR",
        "invoiceAmount": 300.0,
        "invoiceOutstanding": 300.0,
        "paymentAmount": 300.0,
        "adjustmentAmount": 0.0,
        "invoiceDueDate": "2026-10-04",
        "paymentDate": "2026-10-01",
        "tiiReference": "T000507467",
        "tf3Reference": "ICS2615375",
        "tf3ReceivedAt": "2026-10-05 15:57:43",
        "goodsDescription": "DAMPING",
        "documentType": "Direct Import",
        "_source": "Scenario 1, images 5-6",
    },

    # Bosch Limited, Fuchs Lubricants — images 7 and 8.
    {
        "domain": "bbmicotrade.ap",
        "entity": "BOSCH LIMITED",
        "billOfEntryNumber": "2838818",
        "billOfEntryDate": "2026-07-30",
        "drawerName": "BRICANTS GERMANY GMB",
        "drawerNameTruncated": True,
        "drawerCity": "GERMANY",
        "drawerCountry": "GERMANY",
        "invoiceNo": "3002226135",
        "invoiceDate": "2026-07-29",
        "invoiceCurrency": "EUR",
        "invoiceAmount": 305.48,
        "invoiceOutstanding": 0.0,
        "invoiceDueDate": "2026-09-28",
        "paymentDate": "2026-10-01",
        "tiiReference": "T000507732",
        "tf3Reference": "ICS2622721",
        "tf3ReceivedAt": "2026-10-01 18:05:22",
        "goodsDescription": "Components of autoparts",
        "portCode": "INBLR4",
        "documentType": "Direct Import",
        "_source": "Scenario 1, images 7-8",
    },

    # Bosch Limited, Robert Bosch Thailand — images 9 and 10.
    {
        "domain": "bbmicotrade.ap",
        "entity": "BOSCH LIMITED",
        "billOfEntryNumber": "2921288",
        "billOfEntryDate": "2026-08-03",
        "drawerName": "ROBERT BOSCH AUTOMOTIVE TECHNOLOGIES THAILAND CO",
        "drawerCountry": "THAILAND",
        "invoiceNo": "7134790190",
        "invoiceDate": "2026-07-30",
        "invoiceCurrency": "THB",
        "invoiceAmount": 1381897.26,
        "invoiceOutstanding": 0.0,
        "paymentAmount": 1381897.26,
        "adjustmentAmount": 0.0,
        "invoiceDueDate": "2026-09-28",
        "paymentDate": "2026-10-01",
        "tiiReference": "T000507506",
        "tf3Reference": "ICS2622726",
        "tf3ReceivedAt": "2026-10-01 18:05:35",
        "documentType": "Direct Import",
        "_source": "Scenario 1, images 9-10",
    },

    # ---------------------------------------------------------------- Scenario 2
    # Bosch Automotive Electronics — images 1 and 2. One TII reference covering
    # two Bills of Entry, which is the case the procedure has in mind when it
    # says to match on Bill of Entry *and* invoice number.
    *[
        {
            "domain": "blbaetrade.ap",
            "entity": "BOSCH AUTOMOTIVE ELECTRONICS INDIA",
            "billOfEntryNumber": boe,
            "billOfEntryDate": boe_date,
            "drawerName": "NUTEK PRIVATE LIMITED",
            "drawerCity": "Singapore",
            "drawerCountry": "SINGAPORE",
            "invoiceNo": invoice,
            "invoiceCurrency": "SGD",
            "invoiceAmount": amount,
            "adjustmentAmount": 0.0,
            "invoiceDueDate": due,
            "paymentDate": "2026-10-04",
            "tiiReference": "T000507935",
            "tf3Reference": "ICS2622880",
            "tf3ReceivedAt": "2026-10-05 12:34:13",
            "goodsDescription": "Components for auto parts",
            "documentType": "Direct Import",
            "_source": "Scenario 2, images 1-2",
        }
        for boe, boe_date, invoice, amount, due in [
            ("2892462", "2026-08-01", "SP50082A01", 757.00, "2026-08-11"),
            ("2983155", "2026-08-06", "SP50357A01", 1732.20, "2026-08-19"),
        ]
    ],

    # Sigma Aldrich / Merck — images 3 and 4. TradePay records the drawer in the
    # Peoples Rep of China; IDPMS holds Hong Kong. That difference is real and
    # the country check is meant to catch it.
    *[
        {
            "domain": "bbemercktrade.ap",
            "entity": "SIGMA ALDRICH CHEMICALS PRIVATE LIMITED",
            "billOfEntryNumber": boe,
            "billOfEntryDate": boe_date,
            "drawerName": "Leap Chem Co Ltd",
            "drawerCity": "PEOPLES REP OF CHINA",
            "drawerCountry": "PEOPLES REP OF CHINA",
            "invoiceNo": invoice,
            "invoiceDate": invoice_date,
            "invoiceCurrency": "USD",
            "adjustmentAmount": 0.0,
            "invoiceDueDate": due,
            "paymentDate": "2026-09-23",
            "tiiReference": "T000506090",
            "tf3Reference": "ICS2622129",
            "tf3ReceivedAt": "2026-09-23 16:01:44",
            "goodsDescription": goods,
            "documentType": "Direct Import",
            "_source": "Scenario 2, images 3-4",
        }
        for boe, boe_date, invoice, invoice_date, due, goods in [
            ("8451386", "2026-04-02", "DD094065", "2026-03-30", "2026-06-28",
             "Laboratory Chemistry"),
            ("9962137", "2026-06-18", "DD097013", "2026-06-05", "2026-09-03",
             "Laboratory Chemicals"),
        ]
    ],

    # Putzmeister — images 5 and 6. TradePay carries the invoice in EUR where
    # IDPMS holds USD, and names the vendor a third party.
    {
        "domain": "bbputzmeistertrade.ap",
        "entity": "PUTZMEISTER CONCRETE MACHINES PRIVATE LIMITED",
        "billOfEntryNumber": "6650111",
        "drawerName": "XIANGYANG CITY WEALTH CORP LTD CHI",
        "drawerNameTruncated": True,
        "drawerCity": "PEOPLES REP OF CHINA",
        "drawerCountry": "PEOPLES REP OF CHINA",
        "vendorCode": "6101740",
        "vendorCategory": "Third Party",
        "vendorAddress1": "NA",
        "vendorAddress2": "4 CHUNYUAN ROAD",
        "invoiceNo": "2025XYW65",
        "invoiceDate": "2025-11-20",
        "invoiceCurrency": "EUR",
        "invoiceAmount": 15255.93,
        "invoiceOutstanding": 15255.93,
        "paymentAmount": 15255.93,
        "adjustmentAmount": 0.0,
        "documentType": "Direct Import",
        "_source": "Scenario 2, images 5-6",
    },
]


def build_tradepay() -> dict:
    return {
        "source": "Scenario 1-2.xlsx (screenshots)",
        "note": "Payment and invoice records from the TradePay portal, keyed by Bill "
                "of Entry. Only the fields visible in the screenshots are present; a "
                "transaction with no record here has nothing to check IDPMS against.",
        "records": TRADEPAY,
    }


# ---------------------------------------------------------------------------
# Ports — awaiting the directory, but the search rule is already known
# ---------------------------------------------------------------------------

def build_ports(idpms: dict) -> dict:
    codes: dict[str, set] = {}
    for rec in idpms["records"]:
        for key in ("portOfShipment", "portOfDischarge"):
            code = (rec.get(key) or "").strip()
            if code:
                codes.setdefault(code, set()).add(rec.get("supplierCountryIso2") or "")

    seen = []
    for code in sorted(codes):
        hints = sorted(c for c in codes[code] if c)
        seen.append({
            "code": code,
            "length": len(code),
            "needsCountryPrefix": len(code) == 3,
            "countryHint": hints[0] if hints else None,
            "searchAs": (hints[0] + code) if len(code) == 3 and hints else code,
        })

    # A directory that has already been supplied lives in app/data/
    # ports-directory.json. Fold it back in, so rebuilding the mock data does
    # not silently throw away a loaded directory and re-block every case.
    supplied: list[dict] = []
    held = OUT / "ports-directory.json"
    if held.exists():
        try:
            rows = json.loads(held.read_text(encoding="utf-8"))
            if isinstance(rows, dict):
                rows = rows.get("ports", [])
            supplied = [
                {"code": str(r["code"]).upper(), "name": r["name"],
                 "country": r.get("country"), "unlocode": r.get("unlocode")}
                for r in rows if r.get("code") and r.get("name")
            ]
            supplied.sort(key=lambda r: r["code"])
        except (ValueError, KeyError, TypeError) as exc:
            print(f"  ports-directory.json could not be read ({exc}); "
                  "the directory will be left empty")

    return {
        "source": ("supplied directory, from app/data/ports-directory.json"
                   if supplied else "awaiting the port directory export"),
        "note": "Drop the directory in here and the lookup starts resolving. Each "
                "entry needs 'code' and 'name'; 'country' and 'unlocode' are used "
                "when present. Nothing else has to change.",
        "awaitingDirectory": not supplied,
        "searchRule": {
            "fiveDigit": "Search Volza directly using the code as it stands.",
            "threeDigit": "Prepend the 2-letter country code, then search. The country "
                          "comes from the supplier country on the IDPMS record.",
        },
        "codesSeenInData": seen,
        "ports": supplied,
        "example": [{"code": "INMAA1", "name": "<full port name>",
                     "country": "India", "unlocode": "INMAA"}],
    }


# ---------------------------------------------------------------------------
# The checks, as written in the covering email
# ---------------------------------------------------------------------------

def build_checks() -> dict:
    return {
        "source": "covering email",
        "note": "The consistency checks between IDPMS and TradePay/WFMS, exactly as "
                "specified. Each compares a TradePay value against the IDPMS record.",
        "checks": [
            {
                "id": "DRAWER_NAME",
                "label": "Drawer name",
                "tradePayField": "drawerName",
                "idpmsField": "supplierName",
                "compare": "name",
                "detail": "Drawer name on TradePay against the supplier on the IDPMS record.",
            },
            {
                "id": "DRAWER_COUNTRY",
                "label": "Drawer country",
                "tradePayField": "drawerCountry",
                "idpmsField": "supplierCountry",
                # One spelling per country: TradePay writes "PEOPLES REP OF
                # CHINA" where IDPMS writes "CHINA". Hong Kong is kept separate
                # from China, because that difference is a real one.
                "compare": "country",
                "detail": "Drawer country on TradePay against the supplier country in IDPMS.",
            },
            {
                "id": "CURRENCY",
                "label": "Currency",
                "tradePayField": "invoiceCurrency",
                "idpmsField": "invoiceCurrency",
                "compare": "exact",
                "detail": "Invoice currency on TradePay against the IDPMS record.",
            },
        ],
        "matching": {
            "key": ["billOfEntryNumber", "invoiceNo"],
            "note": "Match TradePay to IDPMS on Bill of Entry. Where TradePay holds "
                    "several Bills of Entry, match on Bill of Entry and invoice number "
                    "together.",
            "keyNote": "The invoice number is part of the key, not a tie-breaker "
                       "held back for ambiguous cases. A Bill of Entry number is not "
                       "unique and routinely carries several invoices: 9152082 is "
                       "Hella's consignment of 2025-03-28 through INGHR6 and Rothe "
                       "Erde's of 2026-05-09 through INBOM1. Looking a transaction up "
                       "on the number alone returns another importer's record.",
            "lookupPerInvoice": "Matching one invoice at a time is what shows that a "
                                "remittance covers four of five invoices and names "
                                "the fifth.",
            "invoiceSearchedAlone": "An invoice with no row under its own Bill of "
                                    "Entry is then looked for under every other "
                                    "number before anyone is told there is no "
                                    "remittance. A row found there is filed against "
                                    "the wrong Bill of Entry - a correction, not a "
                                    "chase - and the two read differently on screen.",
        },
        "extraction": {
            "fromIdpms": ["Port of Loading", "Port of Discharge",
                          "Third-Party Details (other than drawer and drawee)",
                          "Shipment details, taking the latest shipment date where "
                          "several records exist"],
            "postToTf3": ["Port of Loading", "Port of Discharge", "Third-Party Details"],
            "fallback": "Where IDPMS is incomplete, take the detail from the supporting "
                        "documents attached in TradePay.",
            "dedupe": "Remove duplicate entries before updating TF3.",
        },
        "charges": {
            "commission": "Per client, from the free-format text held in OEMS/Autobahn.",
            "forexConversion": "Per the forex conversion clause, on the gross INR exchanged.",
            "gst": "18% on the commission, and on the value arrived at under the clause.",
        },
    }


# ---------------------------------------------------------------------------

def main() -> None:
    if not SRC.exists():
        raise SystemExit(f"Sample data not found at {SRC}")

    print(f"Reading {SRC.name}/")
    idpms = build_idpms()
    write("idpms.json", idpms)
    write("tradepay.json", build_tradepay())
    write("autobahn.json", build_autobahn())
    write("fx.json", build_fx())
    write("deals.json", build_deals())
    write("ports.json", build_ports(idpms))
    write("checks.json", build_checks())
    print(f"\nWritten to {OUT}")


if __name__ == "__main__":
    main()
