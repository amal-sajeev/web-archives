"""Walk every page of both views and fail on anything a reader would see.

    python tools/ui_check.py                 against a running server
    python tools/ui_check.py --site site     against the baked folder

A 200 is not the test. A page can answer 200 with a Jinja variable
printed as "None", a template tag that never rendered, a stat that
disagrees with the rows beneath it, or a link to a page that is not
there. Those are the things this looks for, because those are the things
that reach the demo.

Checked on every page:

  * it is HTML, it has a <title>, and it has a <main>;
  * no raw template syntax survived into the output;
  * no "None", "Undefined" or "nan" where a value should be;
  * every internal link resolves - to a route that answers on the server,
    or to a file that exists in the baked folder;
  * every id is unique, which is what keeps label/for and the tab
    controls pointing at the thing they name;
  * every form control can be named by a label, an aria-label or a title.

Exit status is the number of pages with findings, so it can gate a bake.
"""

from __future__ import annotations

import argparse
import html
import pathlib
import re
import sys
import urllib.parse
import urllib.request

THEMES = ("corp", "desk")

# One of each kind of page, plus the states that render differently.
ROUTES = [
    "/", "/done", "/network", "/scenarios", "/ports", "/tariffs", "/rules",
]
CASE_ROUTES = ["/cases/{case}", "/cases/{case}/runlog"]

TAG = re.compile(r"<[^>]+>")
LINK = re.compile(r'(?:href|src)="([^"]+)"')
IDS = re.compile(r'\sid="([^"]+)"')
CONTROL = re.compile(r"<(input|select|textarea)\b([^>]*)>", re.I)
LEFTOVER = re.compile(r"\{\{|\{%|\{#")
# A value that rendered as a null stands alone where a value belongs:
# >None<, or a cell holding nothing else. Matching the bare word anywhere
# in the text caught the agent writing "None is requested on this
# consignment", which is a sentence, not a defect.
BAD_TEXT = re.compile(
    r">\s*(None|Undefined|undefined|nan|NaN|\[object Object\])\s*<")


class Source:
    """Where pages come from: a running server, or the baked folder."""

    def __init__(self, base: str | None, site: pathlib.Path | None):
        self.base, self.site = base, site

    def get(self, url: str) -> tuple[int, str]:
        if self.site is not None:
            path = self._file(url)
            if path is None or not path.exists():
                return 404, ""
            return 200, path.read_text(encoding="utf-8", errors="replace")
        try:
            with urllib.request.urlopen(self.base + url, timeout=30) as r:
                return r.status, r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as exc:
            return exc.code, ""

    def _file(self, url: str) -> pathlib.Path | None:
        """The baked file a URL lands on, by freeze's own naming."""
        split = urllib.parse.urlsplit(url)
        path = urllib.parse.unquote(split.path)
        params = dict(urllib.parse.parse_qsl(split.query))
        theme = params.pop("v", "corp")
        stem = path.strip("/") or "index"
        if stem.endswith(".html"):
            stem = stem[: -len(".html")]
        if params:
            tail = "_".join(f"{k}-{v}" for k, v in sorted(params.items()))
            stem = f"{stem}__{tail}"
        return self.site / theme / f"{stem}.html"

    def exists(self, url: str) -> bool:
        if self.site is not None:
            p = self._file(url)
            return bool(p and p.exists())
        return self.get(url)[0] == 200


def visible(body: str) -> str:
    out = re.sub(r"<(script|style)\b.*?</\1>", " ", body, flags=re.S | re.I)
    return html.unescape(TAG.sub(" ", out))


def check(url: str, body: str, src: Source, known: set[str]) -> list[str]:
    bad: list[str] = []
    text = visible(body)

    # /runlog answers with a fragment on purpose - the page swaps it in -
    # so it is held to the parts of the contract a fragment has.
    fragment = url.split("?")[0].endswith("/runlog")
    if not fragment:
        if "<html" not in body.lower():
            bad.append("not an HTML document")
        if "<title" not in body.lower():
            bad.append("no <title>")
        if "<main" not in body.lower():
            bad.append("no <main>")
    elif not body.strip():
        bad.append("empty fragment")

    if LEFTOVER.search(body):
        bad.append(f"unrendered template syntax: {LEFTOVER.search(body).group(0)}")

    for hit in BAD_TEXT.finditer(body):
        near = visible(body[max(0, hit.start() - 160):hit.end() + 60])
        near = re.sub(r"\s+", " ", near).strip()
        bad.append(f'"{hit.group(1)}" where a value belongs: ...{near[-90:]}')
        break

    ids = IDS.findall(body)
    dupes = sorted({i for i in ids if ids.count(i) > 1})
    if dupes:
        bad.append(f"duplicate id: {', '.join(dupes[:4])}")

    labelled = set(re.findall(r'<label[^>]*\sfor="([^"]+)"', body))
    # A label that wraps its control names it without a `for`, which is
    # ordinary HTML and what this project uses for its checkboxes - but
    # only when the label carries text of its own. One wrapping nothing
    # but an icon and the field names neither.
    wrapped: set[int] = set()
    for lab in re.finditer(r"<label\b[^>]*>(.*?)</label>", body, re.S | re.I):
        inner = lab.group(1)
        if not visible(inner).strip():
            continue
        for ctrl in CONTROL.finditer(inner):
            wrapped.add(lab.start(1) + ctrl.start())

    for m in CONTROL.finditer(body):
        kind, attrs = m.group(1), m.group(2)
        if re.search(r'type="(hidden|submit|button)"', attrs, re.I):
            continue
        ident = re.search(r'\sid="([^"]+)"', attrs)
        named = ((ident and ident.group(1) in labelled)
                 or m.start() in wrapped
                 or re.search(r"\saria-label=|\stitle=|\saria-labelledby=", attrs))
        if not named:
            bad.append(f"<{kind}> with nothing to name it: {attrs.strip()[:60]}")
            break

    # A worklist row switches its panel in the page. The script finds the
    # panel by the reference on the link, so every row must carry one and
    # every reference must name a panel that is actually here. Reading the
    # reference out of the href instead passed on the server and failed in
    # the built copy, where freezing had rewritten every href into a flat
    # filename - the half nobody tests and everybody demonstrates.
    rows = re.findall(r'class="pickrow__hit"([^>]*)>', body)
    if rows:
        here = set(re.findall(r'class="panel detail" data-sel="([^"]*)"', body))
        for attrs in rows:
            ref = re.search(r'data-ref="([^"]*)"', attrs)
            if not ref:
                bad.append("a worklist row carries no data-ref, so the panel "
                           "cannot be switched without a reload")
                break
            if ref.group(1) not in here:
                bad.append(f"row references {ref.group(1)!r}, which has no "
                           "panel on this page")
                break

    for href in LINK.findall(body):
        if href.startswith(("#", "mailto:", "http://", "https://", "data:")):
            continue
        if not href.startswith("/") or href.startswith("/static/"):
            continue
        if href.startswith("/api/") or href.endswith("/runlog"):
            continue
        target = href if "v=" in href or src.site is None else href
        if target in known:
            continue
        if src.exists(target):
            known.add(target)
        else:
            bad.append(f"link goes nowhere: {href}")
            break
    return bad


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", default="http://127.0.0.1:8099")
    ap.add_argument("--site", type=pathlib.Path,
                    help="check the baked folder instead of a server")
    ap.add_argument("--cases", default="",
                    help="comma-separated case ids to walk as well")
    ap.add_argument("--sel", default="",
                    help="comma-separated collection references to select")
    args = ap.parse_args()

    src = Source(args.base, args.site)
    baked = args.site is not None
    urls: list[str] = []
    for theme in THEMES:
        for route in ROUTES:
            urls.append(f"{route}?v={theme}" if "?" not in route
                        else f"{route}&v={theme}")
        for case in filter(None, args.cases.split(",")):
            for route in CASE_ROUTES:
                # The run log is a fragment the page polls for while a case
                # is running. A baked copy has nothing to poll and freeze
                # leaves it out on purpose, so it is only asked for of a
                # server.
                if baked and route.endswith("/runlog"):
                    continue
                urls.append(route.format(case=case) + f"?v={theme}")
        # Selecting a collection belongs to the corporate worklist. The
        # desk view lists collections as cards and opens them in place, so
        # it has no ?sel= and nothing bakes one.
        if theme == "corp":
            for ref in filter(None, args.sel.split(",")):
                urls.append(f"/?sel={ref}&v={theme}")
    urls.append("/?layout=classic&v=corp")

    known: set[str] = set()
    failed = 0
    for url in urls:
        status, body = src.get(url)
        if status != 200:
            print(f"  FAIL {url}  HTTP {status}")
            failed += 1
            continue
        bad = check(url, body, src, known)
        if bad:
            failed += 1
            print(f"  FAIL {url}")
            for b in bad:
                print(f"         {b}")
        else:
            print(f"  ok   {url}")

    where = f"the baked folder {args.site}" if args.site else args.base
    print(f"\n{len(urls)} pages checked against {where}: "
          f"{len(urls) - failed} clean, {failed} with findings")
    return failed


if __name__ == "__main__":
    raise SystemExit(main())
