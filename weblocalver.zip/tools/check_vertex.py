"""Vertex connectivity check used by run.bat.

``VertexProvider.available()`` only resolves credentials and opens a client -
it makes no network call, so it can report ``True`` right up until the first
real request hits a proxy or TLS problem. This sends one real, minimal
completion through the same ``complete()`` the pricing agent uses at runtime,
so a connection failure here prints the exact exception instead of a false
"OK" that only turns into a surprise once a case is actually opened.
"""

from __future__ import annotations

import sys


def main() -> int:
    sys.path.insert(0, ".")
    from app.agent.providers import build

    provider = build("vertex")
    ok, why = provider.available()
    if not ok:
        print(f"   NOT AVAILABLE: {why or 'unknown reason'}")
        return 1

    completion = provider.complete(
        "Reply with JSON only.", '{"ping": true}', max_tokens=16)
    if completion.error:
        print(f"   FAILED: {completion.error}")
        return 1

    print(f"   OK  {provider.describe()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
