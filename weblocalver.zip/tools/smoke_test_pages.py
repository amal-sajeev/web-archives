#!/usr/bin/env python3
"""Smoke-test every page route and log failures.

Run from repo root:
    .\.venv\Scripts\python.exe tools\smoke_test_pages.py
"""

from __future__ import annotations

import sys
from urllib.parse import urljoin

import requests

BASE = "http://127.0.0.1:8000"

ROUTES = [
    "/",
    "/?v=desk",
    "/done",
    "/done?v=desk",
    "/network",
    "/network?v=desk",
    "/scenarios",
    "/ports",
    "/tariffs",
    "/rules",
    "/cases/2921288",
    "/cases/2921288?v=desk",
    "/cases/2921288/runlog",
    "/cases/2921288/runlog?v=desk",
]


def main() -> int:
    session = requests.Session()
    session.trust_env = False
    failures = []

    for path in ROUTES:
        url = urljoin(BASE, path)
        try:
            response = session.get(url, timeout=20)
            status = response.status_code
            if status >= 400:
                failures.append((url, status, response.text[:500]))
                print(f"FAIL {url} -> HTTP {status}")
            else:
                print(f"OK   {url} -> HTTP {status}")
        except Exception as exc:  # noqa: BLE001
            failures.append((url, "exception", repr(exc)))
            print(f"FAIL {url} -> EXCEPTION {exc!r}")

    print("\nSUMMARY")
    if not failures:
        print("No failed pages detected.")
        return 0

    print(f"Failed pages: {len(failures)}")
    for item in failures:
        url, status, detail = item
        print(f"- {url}: {status}")
        print(detail[:500])
        print("---")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
