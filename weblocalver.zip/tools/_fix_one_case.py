"""One-off: re-price a single case fresh against Vertex and merge the
result into the existing app/data/pricing_cache.json, leaving every other
entry untouched.

Used when a bake fails on one or two cases rather than everything - cheaper
than a full re-bake, and still refuses to write a fallback reading.
"""
from __future__ import annotations

import os
import sys

ROOT_BOE = sys.argv[1] if len(sys.argv) > 1 else None
if not ROOT_BOE:
    raise SystemExit("usage: _fix_one_case.py <bill_of_entry>")

sys.path.insert(0, ".")
os.environ["PRICING_AGENT_PROVIDER"] = "vertex"

from app.agent import providers
from app import store as store_mod
from app.store import get_store

vertex = providers.build("vertex")
ok, why = vertex.available()
if not ok:
    raise SystemExit(f"Vertex is not reachable: {why}")
print(f"vertex provider available: {vertex.describe()}")

store = get_store()
store.reset(run=True, reload_data=True)
cases = [c for c in store.all_cases() if c.bill_of_entry == ROOT_BOE]
if not cases:
    raise SystemExit(f"No case found with bill_of_entry={ROOT_BOE}")

for case in cases:
    print(f"re-pricing {case.bill_of_entry} ({case.importer}) fresh via Vertex ...")
    charges = store.reprice(case, fresh=True)
    provider = (charges.agent_trace or {}).get("provider")
    print(f"  provider: {provider}")
    if provider != "vertex":
        warnings = (charges.agent_trace or {}).get("warnings")
        raise SystemExit(
            f"Vertex did not answer for {case.bill_of_entry} on this attempt "
            f"either (provider={provider}). warnings={warnings}")

saved = store_mod.save_pricing_cache()
print(f"{saved['total']} readings on file "
      f"({saved['written']} written, {saved['kept']} left as they were) "
      f"-> {store_mod._DISK_CACHE_PATH}")
if saved["skipped"]:
    raise SystemExit(f"refused to write {len(saved['skipped'])} rules reading(s)")
