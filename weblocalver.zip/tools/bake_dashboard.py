"""Re-bake only the dashboard (queue) pages, in place, inside an existing
./site build.

    .venv\\Scripts\\python tools\\bake_dashboard.py

Unlike tools/freeze.py, which rebuilds the whole site from nothing, this
touches only the files the queue page renders to — corp/index.html and its
index__sel-..._sort-..._layout-...html siblings, and the same for desk — and
leaves every case page, the port directory, the rule sets, the counterparty
map and the three source workbooks exactly as they already are on disk.

Two things this script will not do quietly:

* **Fall back to the regex reading.** The pricing agent's own fallback chain
  will happily produce a page using the pattern-matched charge instead of a
  model's reasoning, and label it correctly as a fallback — but a label in
  the trace is not the same as a reader knowing to look for it. Vertex is
  required to be reachable before anything is rendered, and every priced
  case is checked afterwards; either failure stops the bake rather than
  writing a snapshot of the regex path under the Vertex label.
* **Guess at a WIF credential.** The four environment variables Vertex needs
  (GOOGLE_APPLICATION_CREDENTIALS, SSL_CERT_FILE, PROJECT_NAME,
  PROJECT_LOCATION) must already be set — by bake-dashboard.bat, which wires
  them to the WIF file-based config, the same one bake-site.bat uses.
"""

from __future__ import annotations

import html
import os
import pathlib
import sys
from urllib.parse import urlsplit

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Same estate defaults freeze.py sets, for the same reasons: a snapshot
# reports the deployment it represents, and the agent actually runs rather
# than inheriting whatever a stray .env pins.
os.environ.setdefault("AGENT_PROVIDERS", "vertex")
os.environ.setdefault("AGENT_TRACE_AS", "vertex")
os.environ["PRICING_AGENT_PROVIDER"] = "vertex"   # no fallback to another API

REQUIRED_ENV = ("GOOGLE_APPLICATION_CREDENTIALS", "PROJECT_NAME")

import tools.freeze as freeze                        # noqa: E402
from app import main as M                             # noqa: E402
from app.agent import providers                       # noqa: E402
from app import store as store_mod                    # noqa: E402
from app.store import get_store                       # noqa: E402

DASHBOARD_PATH = "/"
THEMES = freeze.THEMES


def _require_vertex() -> None:
    missing = [k for k in REQUIRED_ENV if not os.environ.get(k)]
    if missing:
        raise SystemExit(
            "Missing environment variable(s) for Vertex: " + ", ".join(missing) +
            ". Run this through bake-dashboard.bat, which points them at the "
            "WIF config, or set them yourself before running this script.")

    vertex = providers.build("vertex")
    if vertex is None:
        raise SystemExit("The 'vertex' provider is not registered.")
    ok, why = vertex.available()
    if not ok:
        raise SystemExit(
            "Vertex is not reachable, so this bake is refusing to run rather "
            f"than silently writing a regex-fallback snapshot: {why}")
    print(f"  vertex provider available: {vertex.describe()}")


def _verify_no_fallback(cases) -> None:
    """Refuse to ship a page claiming Vertex ran the agent when it did not.

    ``_rules_fallback`` stamps ``agent_trace['provider'] = 'rules'`` whenever
    the model could not be reached or did not answer usefully. Pinning
    PRICING_AGENT_PROVIDER to vertex stops it trying another *provider*, but
    the regex reading inside pricing.price() is still the thing that runs
    when Vertex itself errors on a particular case, and that failure is
    worth stopping the bake for rather than shipping quietly.
    """
    fallen_back = [c.case_id for c in cases
                  if (c.charges.agent_trace or {}).get("provider") == "rules"]
    if fallen_back:
        raise SystemExit(
            "Vertex did not answer for every case — these fell back to the "
            f"regex reading: {', '.join(fallen_back)}. Fix the Vertex call "
            "and bake again rather than publish a mixed snapshot.")
    priced = sum(1 for c in cases
                if (c.charges.agent_trace or {}).get("provider") == "vertex")
    print(f"  {priced} case(s) priced by the actual Vertex agent, "
          f"0 by the regex fallback")


def _crawl_dashboard(store) -> tuple[dict, dict]:
    """Only the queue page, and whatever query-string variants it links to.

    A restricted copy of freeze.crawl: it starts at "/" for each theme and
    follows links, but only re-renders further "/" variants (the different
    selections, sorts and layouts the worklist can be viewed in). A link
    to a case, a port, a rule set or anything else found on the page is
    left for the existing build to answer — see `_rewrite_against_sitem`.
    """
    seen: dict = {}
    body: dict = {}
    queue = [(t, DASHBOARD_PATH, ()) for t in THEMES]
    queue.append(("corp", DASHBOARD_PATH, (("layout", "modern"),)))
    while queue:
        key = queue.pop(0)
        if key in seen:
            continue
        theme, path, params = key
        try:
            page = freeze.render(theme, path, params, store)
        except Exception as error:                    # noqa: BLE001
            print(f"  ! {theme}{path} {dict(params)}: "
                  f"{type(error).__name__}: {error}")
            continue
        seen[key] = freeze.filename(path, params)
        body[key] = page
        for url in freeze.links(page):
            found = freeze.canon(url, theme)
            if found and found[1] == DASHBOARD_PATH and found not in seen:
                queue.append(found)
    return seen, body


def _rewrite_against_site(page: str, *, theme: str, out_file: str,
                          rendered: dict) -> str:
    """Point links at the already-baked site rather than only what was
    re-rendered this run.

    freeze.rewrite() falls back to "#" for a link the crawl never reached,
    because a general-purpose freeze has no other build to fall back on.
    Here there is one: the filename a link resolves to is a pure function
    of its path and the query parameters this build keeps (freeze.filename),
    so a link to a case page or a reference page can be pointed at the file
    that already exists on disk for it, without re-rendering that page.
    """
    def one(match) -> str:
        raw = html.unescape(match.group("url"))
        key = freeze.canon(raw, theme)
        if key is None:
            if raw.startswith("#"):
                return match.group(0)
            if raw.startswith("/api/") or raw.endswith("/runlog"):
                return match.group("attr") + "#" + '"'
            return match.group(0)
        if key in rendered:
            target = rendered[key]
        else:
            # Not part of this bake — synthesize the filename the full
            # freeze would have used, and trust it is already on disk.
            target = freeze.filename(key[1], key[2])
        target = f"{key[0]}/{target}"
        fragment = urlsplit(raw).fragment
        rel = freeze.relative(out_file, target) + (f"#{fragment}" if fragment else "")
        return match.group("attr") + html.escape(rel, quote=True) + '"'

    page = freeze.LINK.sub(one, page)
    up = "../" * out_file.count("/")
    page = freeze.ASSET.sub(
        lambda m: m.group("attr") + up + "static/" + m.group("rest") + '"', page)
    page = page.replace(
        f'<script src="{up}static/js/app.js"></script>',
        f'<script src="{up}static/js/app.js"></script>\n'
        f'<script src="{up}static/js/offline.js"></script>')
    return page


def main() -> int:
    out = ROOT / "site"
    if not out.is_dir():
        raise SystemExit(f"{out} does not exist — run tools/freeze.py (or "
                          "bake-site.bat) first to produce a full build.")

    print("checking Vertex is reachable ...")
    _require_vertex()

    print("running the pipeline ...")
    store = get_store()
    store.reset(run=True)
    cases = store.all_cases()
    _verify_no_fallback(cases)

    # Every reading the agent just produced, committed to app/data so a copy
    # of this build handed to someone with no Vertex credentials still
    # answers every one of these cases without a network call.
    saved = store_mod.save_pricing_cache()
    print(f"  {saved['total']} pricing readings on file "
          f"({saved['written']} from this run, {saved['kept']} already there) "
          f"-> {store_mod._DISK_CACHE_PATH.relative_to(ROOT)}")
    if saved["skipped"]:
        # A regex reading must never reach the committed file: the next run
        # would serve it as a settled cached quote. Say so loudly.
        print(f"  WARNING: {len(saved['skipped'])} case(s) fell back to the "
              f"rules and were NOT written. The provider failed for them; "
              f"re-run once it is reachable.")
        for key in saved["skipped"]:
            print(f"    skipped {key[0]}")

    print("rendering the dashboard pages ...")
    pages, bodies = _crawl_dashboard(store)
    print(f"  {len(pages)} page(s)")

    written = []
    for key, name in pages.items():
        theme = key[0]
        out_file = f"{theme}/{name}"
        page = _rewrite_against_site(bodies[key], theme=theme,
                                     out_file=out_file, rendered={
                                         k: v for k, v in pages.items()})
        target = out / out_file
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(page, encoding="utf-8")
        written.append(out_file)

    print(f"\nwrote {len(written)} file(s) under {out}:")
    for name in sorted(written):
        print(f"  {name}")

    # The page markup is only half of what changes between bakes — the CSS
    # and JS the dashboard pages link to lives in app/static and is never
    # touched by the loop above, so a styling or script fix made since the
    # last full freeze would sit in the working tree forever, invisible in
    # every build this script produces. Refreshed on every run, not copied
    # once: `dirs_exist_ok` leaves the bundled web-font files freeze.py
    # wrote into site/static/fonts alone, because app/static has no fonts
    # directory of its own to overwrite them with.
    import shutil
    shutil.copytree(ROOT / "app" / "static", out / "static", dirs_exist_ok=True)
    print(f"  refreshed {out / 'static'} from app/static")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
