"""Walk every transaction and reconcile it across all four sources.

    python tools/reconcile.py            every transaction, summary at the end
    python tools/reconcile.py --verbose  every check, including the ones that pass

Checking an extract against the file it came from only proves the reading was
faithful. It does not prove the reading was *complete*, and it cannot catch a
field that was read into the wrong slot — a column-shifted row has a value in
every field and disagrees with nothing. Both of those got through a cell-level
comparison of the IDPMS workbook and reached the screen: a settlement deal
whose rate read "INR", and a TF3 reference that was never picked up at all.

So this goes the other way round. It starts from the supplied reference
bundle, which was produced independently of anything in app/data, and for each
transaction it asks the four sources the same questions and compares the
answers:

    IDPMS            the customs record, app/data/idpms.json
    TradePay         the portal capture, app/data/tradepay.json
    the blotter      the settlement deals, app/data/deals.json
    the bundle       trade_portal_reference_bundle/case_index.json

Every difference is reported and classified. A DEFECT is ours and has to be
fixed. A CONFLICT is a disagreement between two systems that the bank's own
join policy says to preserve and flag rather than resolve. A GAP is a field
no source carries. Only DEFECT counts as failure.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

BUNDLE = ROOT / "sample data with screenshots" / "trade_portal_reference_bundle"
DATA = ROOT / "app" / "data"

DEFECT, CONFLICT, GAP, OK = "DEFECT", "CONFLICT", "GAP", "ok"

def load(path: pathlib.Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def ref(value) -> str:
    """An identifier, with the punctuation the two systems disagree about."""
    return re.sub(r"[^A-Z0-9]", "", str(value or "").upper())


def num(value) -> float | None:
    try:
        return round(float(str(value).replace(",", "").strip()), 2)
    except (TypeError, ValueError):
        return None


def close(a, b, tolerance: float = 0.01) -> bool:
    x, y = num(a), num(b)
    return x is not None and y is not None and abs(x - y) <= tolerance


class Report:
    """What each transaction's reconciliation found."""

    def __init__(self, verbose: bool) -> None:
        self.verbose = verbose
        self.rows: list[tuple[str, str, str, str]] = []

    def add(self, case: str, verdict: str, what: str, detail: str = "") -> None:
        self.rows.append((case, verdict, what, detail))

    def ok(self, case, what, detail=""):
        self.add(case, OK, what, detail)

    def defect(self, case, what, detail=""):
        self.add(case, DEFECT, what, detail)

    def conflict(self, case, what, detail=""):
        self.add(case, CONFLICT, what, detail)

    def gap(self, case, what, detail=""):
        self.add(case, GAP, what, detail)

    def show(self) -> int:
        seen = None
        for case, verdict, what, detail in self.rows:
            if verdict == OK and not self.verbose:
                continue
            if case != seen:
                print(f"\n--- {case} ---")
                seen = case
            mark = {OK: "  ok   ", DEFECT: "  DEFECT", CONFLICT: "  conflict",
                    GAP: "  gap  "}[verdict]
            print(f"{mark}  {what}")
            if detail:
                print(f"            {detail}")
        counts = {v: sum(1 for r in self.rows if r[1] == v)
                  for v in (OK, DEFECT, CONFLICT, GAP)}
        print(f"\n{len(self.rows)} checks over "
              f"{len({r[0] for r in self.rows})} transactions: "
              f"{counts[OK]} agree, {counts[DEFECT]} defects, "
              f"{counts[CONFLICT]} source conflicts, {counts[GAP]} gaps")
        return counts[DEFECT]


# --------------------------------------------------------------- the sources

def idpms_by_excel_row() -> dict[int, dict]:
    """Our IDPMS extract, keyed by the Excel row the bundle cites.

    The bundle's row numbers are 1-based and include the header, so row 2 is
    the first record.
    """
    records = load(DATA / "idpms.json")["records"]
    return {i + 2: r for i, r in enumerate(records)}


def deals_by_reference() -> dict[str, dict]:
    return {ref(d.get("reference")): d
            for d in load(DATA / "deals.json")["records"] if d.get("reference")}


def portal_by_invoice() -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    for r in load(DATA / "tradepay.json")["records"]:
        out.setdefault(ref(r.get("invoiceNo")), []).append(r)
    return out


# ------------------------------------------------------- the deal, by column

# What the blotter's columns mean. Taken from the bundle's own reading of the
# cells rather than from their position, because one row is shifted and
# position is exactly what cannot be trusted.
CELL_FIELD = {
    "A": "dealDate", "B": "branch", "C": "client", "D": "dealType",
    "E": "contractRef", "F": None, "G": "rate", "H": "baseCurrency",
    "I": "inrAmount", "J": "currency", "K": "amount", "L": "reference",
}


def deal_from_cells(cells: dict) -> dict:
    """What the blotter row says, read the way the bundle read it.

    For a row sitting where the others sit, the column letters name the
    fields. For the one shifted row they do not, and the bundle's own cell
    map shows the shift: Putzmeister's rate is in F where every other row
    has it in G. So the fields are taken by shape from the right-hand end,
    which is the same rule the extractor uses, and this is the independent
    second opinion on it.
    """
    values = [cells[k] for k in sorted(cells) if cells[k] not in (None, "")]
    if len(values) < 4:
        return {}
    body = values[4:] if len(values) > 4 else []
    # date, branch, client, dealType are always the first four.
    out = {"dealDate": values[0], "branch": values[1], "client": values[2],
           "dealType": values[3]}
    if not body:
        return out
    out["reference"] = body.pop()
    out["amount"] = body.pop() if body else None
    out["currency"] = body.pop() if body else None
    if body and num(body[0]) is None and str(body[0]).upper() != "EEFC":
        out["contractRef"] = body.pop(0)
    out["rate"] = body.pop(0) if body else None
    out["baseCurrency"] = body.pop(0) if body else None
    out["inrAmount"] = body.pop(0) if body else None
    return out


# ------------------------------------------------------------------ the walk

def reconcile(report: Report) -> None:
    bundle = load(BUNDLE / "case_index.json")
    rows = idpms_by_excel_row()
    deals = deals_by_reference()
    portal = portal_by_invoice()

    from app.store import get_store
    store = get_store()
    store.reset(run=True)
    cases = store.all_cases()
    by_record = {}
    for c in cases:
        for line in c.invoice_lines:
            by_record[line.record_id] = c

    for entry in bundle["cases"]:
        name = entry["case_id"]
        primary = entry.get("primary_idpms_excel_rows") or []
        st = entry.get("source_transaction") or {}
        cells = st.get("source_cells") or {}
        av = entry.get("amount_validation") or {}

        # 1 — every IDPMS row the bundle names is in our extract, and is the
        #     row it says it is.
        mine = []
        for n in primary:
            row = rows.get(n)
            if row is None:
                report.defect(name, f"IDPMS Excel row {n} is missing from the extract")
                continue
            mine.append(row)
        if primary:
            report.ok(name, f"{len(mine)} of {len(primary)} cited IDPMS rows present")

        # 2 — the settlement deal, field by field against the bundle's cells.
        if cells and st.get("source_row") and "profile_company" not in \
                (st.get("interpreted_fields") or {}):
            want = deal_from_cells(cells)
            got = deals.get(ref(want.get("reference")))
            if got is None:
                report.defect(
                    name, f"no deal extracted for {want.get('reference')!r}",
                    f"the blotter row is in the workbook at row {st['source_row']}")
            else:
                for field in ("client", "dealType", "contractRef", "rate",
                              "baseCurrency", "inrAmount", "currency",
                              "amount", "branch"):
                    a, b = want.get(field), got.get(field)
                    same = (close(a, b) if num(a) is not None or num(b) is not None
                            else str(a or "").strip() == str(b or "").strip())
                    if same:
                        report.ok(name, f"deal {field}", f"{b!r}")
                    else:
                        report.defect(name, f"deal {field} disagrees",
                                      f"blotter {a!r}  extract {b!r}")

        # 3 — the amounts the bundle validated.
        if av.get("status", "").startswith("conflict"):
            report.conflict(name, "the bundle flags this transaction for review",
                            json.dumps({k: v for k, v in av.items()
                                        if k != "status"})[:150])
        elif "linked_idpms_invoice_amount_sum" in av:
            total = round(sum(num(r.get("invoiceAmount")) or 0 for r in mine), 2)
            if close(total, av["linked_idpms_invoice_amount_sum"]):
                report.ok(name, "the cited rows sum to the remitted amount",
                          f"{total:,.2f}")
            else:
                report.defect(name, "the cited rows do not sum to the remitted amount",
                              f"extract {total:,.2f}  bundle "
                              f"{av['linked_idpms_invoice_amount_sum']:,.2f}")
        elif "idpms_invoice_amount" in av and mine:
            if close(mine[0].get("invoiceAmount"), av["idpms_invoice_amount"]):
                report.ok(name, "invoice amount", f"{mine[0].get('invoiceAmount')}")
            else:
                report.defect(name, "invoice amount disagrees",
                              f"extract {mine[0].get('invoiceAmount')!r}  "
                              f"bundle {av['idpms_invoice_amount']!r}")
        if "invoice_plus_miscellaneous_total" in av and mine:
            got = round((num(mine[0].get("invoiceAmount")) or 0)
                        + (num(mine[0].get("miscellaneousCharges")) or 0), 2)
            if close(got, av["invoice_plus_miscellaneous_total"]):
                report.ok(name, "invoice plus miscellaneous reconciles", f"{got:,.2f}")
            else:
                report.defect(name, "invoice plus miscellaneous disagrees",
                              f"extract {got:,.2f}  bundle "
                              f"{av['invoice_plus_miscellaneous_total']:,.2f}")

        # 4 — the portal row for each cited invoice, and what it carries.
        for row in mine:
            inv = row.get("invoiceNo")
            found = portal.get(ref(inv)) or []
            if not found:
                report.gap(name, f"no portal row for invoice {inv}",
                           "nothing to take a date, a drawer or a TF3 from")
                continue
            p = found[0]
            if ref(p.get("billOfEntryNumber")) != ref(row.get("billOfEntryNumber")):
                report.conflict(
                    name, f"invoice {inv} is filed under a different bill",
                    f"IDPMS {row.get('billOfEntryNumber')}  "
                    f"portal {p.get('billOfEntryNumber')}")
            for field, theirs, ours in (
                    ("currency", "invoiceCurrency", "invoiceCurrency"),
                    ("bill of entry date", "billOfEntryDate", "billOfEntryDate")):
                a, b = p.get(theirs), row.get(ours)
                if a and b and str(a) != str(b):
                    report.conflict(name, f"invoice {inv}: {field} differs",
                                    f"portal {a!r}  IDPMS {b!r}")

        # 5 — the app's own assembly. The bundle calls one remittance one
        #     transaction; the application splits it into a case per Bill of
        #     Entry and gathers those under one TF3. So the test is that the
        #     cited rows reach one *collection*, not one case.
        owned = [by_record[r["recordId"]] for r in mine
                 if r.get("recordId") in by_record]
        if mine and not owned:
            report.defect(name, "the cited IDPMS rows reach no case at all")
        elif owned:
            tf3s = {c.tf3 for c in owned}
            bills = sorted({c.bill_of_entry for c in owned})
            if len(tf3s) > 1:
                report.defect(name, "the cited rows are split across TF3s",
                              f"{sorted(str(x) for x in tf3s)} over bills {bills}")
            else:
                report.ok(name, f"the cited rows reach one collection over "
                                f"{len(bills)} bill(s)", f"{bills}")
            want = (st.get("interpreted_fields") or {}).get("source_reference")
            if want:
                got = owned[0].tf3
                if ref(got) != ref(want):
                    report.defect(name, "the collection's TF3 is not the blotter's",
                                  f"case {got!r}  blotter {want!r}")
                else:
                    report.ok(name, "TF3 reference", got)


def sweep(report: Report) -> None:
    """Nothing left over, in either direction.

    The per-transaction walk proves that everything the bundle names was read.
    It cannot prove the reverse — that nothing was read which the bundle does
    not name, and that no supplied row was quietly dropped. A missing TF3
    reference is invisible to a walk that only looks where the bundle points.
    """
    name = "the book as a whole"
    idpms = load(DATA / "idpms.json")["records"]
    tp = load(DATA / "tradepay.json")["records"]
    deals = load(DATA / "deals.json")["records"]

    from app.store import get_store
    cases = get_store().all_cases()
    lines = [l for c in cases for l in c.invoice_lines]

    if len(lines) == len(idpms):
        report.ok(name, f"every one of the {len(idpms)} IDPMS rows reaches a case")
    else:
        report.defect(name, "IDPMS rows do not all reach a case",
                      f"{len(idpms)} supplied, {len(lines)} on cases")

    # Every portal row should answer to an invoice the book holds.
    held = {ref(l.invoice_no) for l in lines}
    orphan = [r.get("invoiceNo") for r in tp if ref(r.get("invoiceNo")) not in held]
    if orphan:
        report.defect(name, f"{len(orphan)} portal rows match no invoice",
                      ", ".join(str(o) for o in orphan))
    else:
        report.ok(name, f"all {len(tp)} portal rows answer to an invoice")

    # Every deal should reach the collection it was booked against.
    placed = {ref(c.tf3) for c in cases if c.tf3}
    stray = [d["reference"] for d in deals if ref(d.get("reference")) not in placed]
    if stray:
        report.defect(name, f"{len(stray)} booked deals reach no collection",
                      ", ".join(stray))
    else:
        report.ok(name, f"all {len(deals)} booked deals reach a collection")

    # And a collection that payment runs against needs a reference to run on.
    unref = sorted({c.bill_of_entry for c in cases if not c.tf3})
    if unref:
        report.gap(name, f"{len(unref)} bills carry no TF3 reference",
                   f"{unref} — payment runs against the reference, so these "
                   f"cannot be posted until one is supplied")
    else:
        report.ok(name, "every bill carries a TF3 reference")

    # Every drawer name the portal gives is treated as the whole value. A
    # column too narrow to show it is a fact about a screenshot, not about
    # the data — the API has no column width — so the extract records the
    # name the API would return and the checks compare it plainly. What is
    # still flagged is a name that genuinely differs: NUTEK PRIVATE LIMITED
    # against NUTEK PTE LTD, which is the short-form difference the written
    # requirement says to surface rather than absorb.
    from app.network import _counterparty_key
    from app.sources._data import normalise_name
    for c in cases:
        tp = c.tradepay or {}
        drawer = tp.get("drawerName")
        if not drawer or not c.supplier:
            continue
        key, _ = _counterparty_key(c)
        if key != normalise_name(drawer):
            report.defect(name, f"{c.bill_of_entry}: the counterparty is "
                                f"filed under {key!r}, not the drawer's name")
        else:
            report.ok(name, f"{c.bill_of_entry}: counterparty filed under the "
                            f"drawer's own name", key)

    # A reference or code that is the odd length out. These are fixed
    # formats — TII is T plus nine digits, a TF3 is ICS plus seven, a bill
    # of entry is seven — so one that is shorter is either cut in the
    # reading or wrong at source, and both are worth a look. Putzmeister's
    # blotter reference is the standing example: ICS260134, six digits
    # where every other is seven. It comes from a spreadsheet cell rather
    # than a screenshot, so no column could have cut it, which leaves the
    # source. It is reported, not corrected.
    import re as _re
    for field, pattern, what in (
            ("tiiReference", r"^T\d{9}$", "T plus nine digits"),
            ("tf3Reference", r"^ICS\d{7}$", "ICS plus seven digits"),
            ("billOfEntryNumber", r"^\d{7}$", "seven digits"),
            ("vendorCode", r"^\d{7}$", "seven digits")):
        odd = sorted({str(r[field]) for r in tp
                      if r.get(field) and not _re.match(pattern, str(r[field]))})
        if odd:
            report.conflict(name, f"{field}: not {what}", ", ".join(odd))
        else:
            report.ok(name, f"{field}: every value is {what}")
    odd = sorted({str(d["reference"]) for d in deals
                  if not _re.match(r"^\d{3}ICS\d{7}$", str(d.get("reference") or ""))})
    if odd:
        report.conflict(name, "a booked deal's reference is not three digits "
                              "plus ICS plus seven", ", ".join(odd))
    else:
        report.ok(name, "every booked reference has the standard shape")

    # A value the portal shows cut is still the whole value: the API has no
    # column width. Where a code appears in both systems they must agree,
    # and a portal code that is merely a prefix of the IDPMS one is a
    # reading that stopped at the column border.
    idpms_by_boe = {}
    for r in load(DATA / "idpms.json")["records"]:
        idpms_by_boe.setdefault(str(r["billOfEntryNumber"]), r)
    for r in tp:
        code = r.get("portCode")
        row = idpms_by_boe.get(str(r.get("billOfEntryNumber")))
        if not code or not row:
            continue
        theirs = str(row.get("portOfDischarge") or "")
        if code == theirs:
            report.ok(name, f"{r['billOfEntryNumber']}: port code agrees", code)
        elif theirs.startswith(code):
            report.defect(name, f"{r['billOfEntryNumber']}: the port code "
                                f"{code!r} is a prefix of IDPMS's {theirs!r} — "
                                f"read to the column border, not to the end")
        else:
            report.conflict(name, f"{r['billOfEntryNumber']}: port code "
                                  f"{code!r} against IDPMS {theirs!r}")

    # The forex charge, against the workbook's own worked example. The
    # clause was typed in once rather than read, and the figures that were
    # typed were the deemed value's rather than the tax's — five and a half
    # times what the bank's sheet bills. A worked example carried through
    # from the source is what makes that impossible to repeat.
    from app.sources.autobahn import forex_conversion_fee
    clause = load(DATA / "fx.json")["forexConversionClause"]
    worked = clause.get("worked") or {}
    if worked.get("grossInr"):
        got = forex_conversion_fee(worked["grossInr"])["amountInr"]
        if abs(got - float(worked["chargeInr"])) <= 0.01:
            report.ok(name, "the forex charge reproduces the workbook's "
                            "worked example", f"{got:,.2f}")
        else:
            report.defect(name, "the forex charge does not reproduce the "
                                "workbook's worked example",
                          f"computed {got:,.2f}  workbook "
                          f"{float(worked['chargeInr']):,.2f}")
    # And the two slabs must stay the same table, one multiplied by the other.
    rate = float(clause.get("gstPercent") or 18) / 100.0
    pairs = zip(clause.get("tiers", []), clause.get("valueTiers", []))
    drift = [f"{t['percent']} vs {v['percent']}" for t, v in pairs
             if abs(t["percent"] - v["percent"] * rate) > 1e-9]
    if drift:
        report.defect(name, "the charge slab is not the value slab times GST",
                      "; ".join(drift))
    else:
        report.ok(name, "the charge slab is the value slab times GST")

    # The branch prefix on every reference, against the branch the deal was
    # booked at. The two come from different sheets of different workbooks,
    # so agreement is evidence the prefix means what the table says.
    branches = load(DATA / "fx.json").get("branches") or {}
    for d in deals:
        code = str(d.get("reference") or "")[:3]
        booked = str(d.get("branch") or "").strip().title()
        mapped = branches.get(code)
        if not mapped:
            report.gap(name, f"{d['reference']}: branch code {code} is not in "
                             f"the PBC table")
        elif mapped.lower() != booked.lower():
            report.conflict(name, f"{d['reference']}: the prefix says "
                                  f"{mapped}, the blotter says {booked}")
        else:
            report.ok(name, f"{d['reference']}: prefix agrees with the branch",
                      mapped)

    # A field blank on every record is a column the source never fills.
    blank = [k for k in idpms[0]
             if all(r.get(k) in (None, "") for r in idpms)]
    if blank:
        report.gap(name, f"{len(blank)} IDPMS columns are empty on every row",
                   ", ".join(blank))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--verbose", action="store_true",
                    help="print the checks that pass as well")
    args = ap.parse_args()
    report = Report(args.verbose)
    reconcile(report)
    sweep(report)
    defects = report.show()
    print("\nno defects" if not defects else f"\n{defects} defects to fix")
    return 1 if defects else 0


if __name__ == "__main__":
    raise SystemExit(main())
