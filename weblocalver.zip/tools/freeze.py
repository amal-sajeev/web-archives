"""Bake the running demo into a folder of files that needs no server.

    python tools/freeze.py                  write ./site
    python tools/freeze.py --out somewhere  write it elsewhere

The result opens from a file:// path and hosts on GitHub Pages with nothing
configured, because every link in it is relative and no request leaves the
page. It is the same application, rendered once with the pipeline already
run, rather than a set of screenshots: the collections still open, the tabs
still switch, the map still pans, and the two views still cross-link.

What a snapshot cannot do is write. Validating, approving, resolving a check
and raising a query all post to an API that is not there, so the frozen build
answers those with a line saying so rather than a failed request. Searching
and filtering are done in the page instead of by the server.

The pages are found by crawling rather than listed here, so a link added to a
template is picked up without this file being touched.
"""

from __future__ import annotations

import argparse
import html
import inspect
import os
import pathlib
import re
import shutil
import sys
from urllib.parse import parse_qsl, unquote, urlsplit

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Only what this deployment is allowed to reach. Without it the status page
# lists every provider the machine that built the snapshot happened to have.
os.environ.setdefault("AGENT_PROVIDERS", "vertex")

from starlette.requests import Request              # noqa: E402

from app import main as M                           # noqa: E402
from app.store import get_store                     # noqa: E402

THEMES = ("corp", "desk")
LANDING = "corp"          # the view the application itself opens on

# Where each path is served from, and the name its file takes.
ROUTES = {
    "/":          (lambda: M.queue, "index"),
    "/done":      (lambda: M.done, "done"),
    "/network":   (lambda: M.network_page, "network"),
    "/scenarios": (lambda: M.scenarios_page, "scenarios"),
    "/ports":     (lambda: M.ports_page, "ports"),
    "/tariffs":   (lambda: M.tariffs_page, "tariffs"),
    "/rules":     (lambda: M.rules_page, "rules"),
}

# Query parameters worth keeping as separate files. Anything else is dropped
# and the page is served in its unnarrowed form: the filter selects alone
# would otherwise multiply into several hundred near-identical pages, and
# they are answered in the browser instead.
KEEP = {"/": {"open", "sort", "direction"},
        "/network": {"view", "only", "country", "importer", "currency",
                     "port", "band", "q"}}

CAP = 500                 # a crawl that runs away is a bug, not a big site


def request(path: str, query: str = "") -> Request:
    return Request({"type": "http", "method": "GET", "path": path,
                    "raw_path": path.encode(), "query_string": query.encode(),
                    "headers": [], "root_path": "", "scheme": "http",
                    "server": ("freeze", 80), "client": ("freeze", 1),
                    "app": M.app})


# ------------------------------------------------------------------ naming

def canon(url: str, here_theme: str) -> tuple[str, str, tuple] | None:
    """A link, reduced to the page it really names: (theme, path, params).

    Returns None for anything that is not a page of this site — an API call,
    an off-site link, a bare fragment, the run-log partial.
    """
    if not url or url.startswith(("#", "mailto:", "http://", "https://",
                                  "javascript:", "data:")):
        return None
    split = urlsplit(url)
    path = unquote(split.path) or "/"
    if not path.startswith("/") or path.startswith(("/static/", "/api/")):
        return None
    if path.endswith("/runlog"):
        return None

    params = dict(parse_qsl(split.query, keep_blank_values=False))
    theme = params.pop("v", here_theme)
    if theme not in THEMES:
        theme = here_theme

    if path.startswith("/cases/"):
        keep: dict = {}
    elif path in ROUTES:
        keep = {k: v for k, v in params.items()
                if k in KEEP.get(path, set()) and v and v != "all"}
    else:
        return None
    return theme, path, tuple(sorted(keep.items()))


def slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-")


def filename(path: str, params: tuple) -> str:
    """The file a page is written to, relative to its view's folder."""
    if path.startswith("/cases/"):
        stem = "cases/" + slug(path[len("/cases/"):])
    else:
        stem = ROUTES[path][1]
    if params:
        stem += "__" + "_".join(f"{slug(k)}-{slug(v)}" for k, v in params)
    return stem + ".html"


def relative(from_file: str, to_file: str) -> str:
    """A link from one page in the tree to another, as a relative path."""
    here = pathlib.PurePosixPath(from_file).parent
    return os.path.relpath(to_file, str(here)).replace("\\", "/")


# ----------------------------------------------------------------- render

def render(theme: str, path: str, params: tuple, store) -> str:
    query = "&".join(f"{k}={v}" for k, v in params)
    if path.startswith("/cases/"):
        case_id = unquote(path[len("/cases/"):])
        response = M.case_detail(request(path, query), case_id,
                                 v=theme, store=store)
    else:
        fn = ROUTES[path][0]()
        takes = inspect.signature(fn).parameters
        kwargs = {k: v for k, v in params if k in takes}
        response = fn(request(path, query), v=theme, store=store, **kwargs)
    return response.body.decode("utf-8", "replace")


LINK = re.compile(r'(?P<attr>\b(?:href|action)=")(?P<url>[^"]*)"')
ASSET = re.compile(r'(?P<attr>\b(?:href|src)=")/static/(?P<rest>[^"]*)"')


def links(page: str) -> list[str]:
    return [html.unescape(m.group("url")) for m in LINK.finditer(page)]


def rewrite(page: str, *, theme: str, out_file: str, pages: dict) -> str:
    """Point every link at a file in the tree, and every asset at the copy."""
    def one(match: re.Match) -> str:
        raw = html.unescape(match.group("url"))
        key = canon(raw, theme)
        if key is None:
            if raw.startswith("#"):
                return match.group(0)
            if raw.startswith("/api/") or raw.endswith("/runlog"):
                return match.group("attr") + "#" + '"'
            return match.group(0)
        target = pages.get(key)
        if target is None:
            # A page the crawl did not reach — the unnarrowed one stands in.
            target = pages.get((key[0], key[1], ()))
            if target is None:
                return match.group("attr") + "#" + '"'
        fragment = urlsplit(raw).fragment
        rel = relative(out_file, target) + (f"#{fragment}" if fragment else "")
        return match.group("attr") + html.escape(rel, quote=True) + '"'

    page = LINK.sub(one, page)
    up = "../" * out_file.count("/")
    page = ASSET.sub(
        lambda m: m.group("attr") + up + "static/" + m.group("rest") + '"', page)
    # The shim has to load before the page's own script, which takes its
    # copy of the API helper the moment it runs.
    page = page.replace(
        f'<script src="{up}static/js/app.js"></script>',
        f'<script src="{up}static/js/app.js"></script>\n'
        f'<script src="{up}static/js/offline.js"></script>')
    return page


# ------------------------------------------------------------------ crawl

def crawl(store) -> tuple[dict, dict]:
    """Every page reachable from the two front doors, rendered."""
    seen: dict = {}
    body: dict = {}
    queue = [(t, "/", ()) for t in THEMES]
    while queue:
        key = queue.pop(0)
        if key in seen:
            continue
        theme, path, params = key
        try:
            page = render(theme, path, params, store)
        except Exception as error:                   # noqa: BLE001
            print(f"  ! {theme}{path} {dict(params)}: "
                  f"{type(error).__name__}: {error}")
            continue
        seen[key] = filename(path, params)
        if theme != LANDING:
            seen[key] = seen[key]
        body[key] = page
        if len(seen) >= CAP:
            print(f"  ! stopped at {CAP} pages")
            break
        for url in links(page):
            found = canon(url, theme)
            if found and found not in seen:
                queue.append(found)
    return seen, body


# ------------------------------------------------------------------ write

OFFLINE_JS = '''/* The snapshot shim.
 *
 * This build is the application rendered once, as a folder of files. Reading
 * works exactly as it does on the server; writing cannot, because there is no
 * server to write to. Rather than let a click fail on a request that will
 * never be answered, the API helper is replaced here with one that says what
 * this build is. It has to load before each page own script, which takes its
 * copy of the helper the moment it runs.
 *
 * Searching and filtering move into the page for the same reason: a GET form
 * in a folder of files lands on the file and drops what was typed.
 */
(function () {
  "use strict";
  if (!window.App) return;

  var SAYS = "This is a saved copy of the workbench. It shows the finished "
           + "state of every case; validating, approving and raising queries "
           + "need the live service.";

  /* Reads are the live poll, which has nothing to poll and is already caught
     by its caller. Only a write is worth interrupting someone over. */
  window.App.api = function (method) {
    if (String(method).toUpperCase() !== "GET") {
      window.App.toast("info", "Saved copy", SAYS);
    }
    return Promise.reject(new Error(SAYS));
  };

  document.addEventListener("DOMContentLoaded", function () {
    var writes = "[data-run-all],[data-reset],[data-approve],[data-return],"
               + "[data-query],[data-answer],[data-start],[data-switch-role],"
               + "#validate-btn,.review__box input,#agree,#agree2";
    document.querySelectorAll(writes).forEach(function (el) {
      el.disabled = true;
      el.title = SAYS;
    });

    /* The page own scripts bind at parse time, before this runs. Replacing a
       control with a copy of itself is how their listeners come off it. */
    function fresh(el) {
      if (!el || !el.parentNode) return el;
      var copy = el.cloneNode(true);
      el.parentNode.replaceChild(copy, el);
      return copy;
    }

    var box = fresh(document.getElementById("q"));
    var selects = [];
    /* Importer and currency can be answered by reading the rows. Status is
       held as a case state that the markup never spells out, and sort is the
       server own ordering; a control that quietly does nothing is worse than
       one that says it cannot, so those two are turned off rather than
       bound to a pass that would ignore them. The desk orderings are links,
       and every one of them is a page in this build, so they still work. */
    document.querySelectorAll("form.sift select, form.toolbar select")
      .forEach(function (s) {
        s = fresh(s);
        s.removeAttribute("onchange");
        if (s.name === "status" || s.name === "sort") {
          s.disabled = true;
          s.title = "Not available in a saved copy — the live service does "
                  + "this ordering.";
          return;
        }
        s.addEventListener("change", sift);
        selects.push(s);
      });
    document.querySelectorAll("form.sift, form.toolbar").forEach(function (f) {
      f.addEventListener("submit", function (e) { e.preventDefault(); sift(); });
    });
    if (box) {
      box.addEventListener("input", sift);
      box.addEventListener("search", sift);
    }

    function chosen(name) {
      var el = selects.filter(function (s) { return s.name === name; })[0];
      return el && el.value && el.value !== "all" ? el.value.toLowerCase() : "";
    }

    /* One pass over the collections: hide the ones that do not answer, open
       the ones that do, and mark the invoice row that was asked for. */
    function sift() {
      var term = ((box && box.value) || "").trim().toLowerCase();
      var importer = chosen("importer"), currency = chosen("currency");
      var shown = 0;

      document.querySelectorAll("details.coll, tbody.cgrp").forEach(function (g) {
        var text = (g.textContent || "").toLowerCase();
        var ok = (!term || text.indexOf(term) !== -1)
              && (!importer || text.indexOf(importer) !== -1)
              && (!currency || text.indexOf(currency) !== -1);
        g.hidden = !ok;
        if (!ok) return;
        shown += 1;

        var hit = false;
        g.querySelectorAll("tr[id^=\'inv-\']").forEach(function (row) {
          var cell = row.querySelector("td.ref");
          var on = !!term && !!cell
                && cell.textContent.toLowerCase().indexOf(term) !== -1;
          row.classList.toggle("is-hit", on);
          hit = hit || on;
        });
        if (hit) {
          if (g.tagName === "DETAILS") g.open = true;
          else g.classList.add("is-open");
        }
      });

      /* A band heading with nothing under it is worse than no heading. */
      document.querySelectorAll("section.book").forEach(function (s) {
        s.hidden = !s.querySelector("details.coll:not([hidden])");
      });
      var blank = document.querySelector(".nothing, .blank");
      if (blank && (term || importer || currency)) blank.hidden = shown !== 0;

      /* The count in the heading was written by the server for the whole
         book. Narrowed here, it would stand over a shorter list saying a
         number that is no longer true. */
      var head = document.querySelector(".lede h1, .panel__hd h2");
      if (head) {
        if (!head.dataset.said) head.dataset.said = head.textContent;
        head.textContent = (term || importer || currency)
          ? shown + (shown === 1 ? " collection" : " collections") + " shown"
          : head.dataset.said;
      }
    }
  });
}());
'''

INDEX_HTML = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Trade Collections</title>
<meta http-equiv="refresh" content="0; url={landing}/index.html">
<link rel="canonical" href="{landing}/index.html">
<style>
  body {{ font: 15px/1.6 system-ui, sans-serif; margin: 12vh auto; max-width: 30rem;
         padding: 0 16px; color: #1b1d21; background: #eceef3; }}
  a {{ color: #004e99; }}
</style>
</head>
<body>
<p>Opening the workbench&hellip;</p>
<p>If nothing happens, choose a view:
  <a href="corp/index.html">corporate</a> or
  <a href="desk/index.html">desk</a>.</p>
</body>
</html>
'''

README = '''# Trade Collections — saved copy

A browsable snapshot of the Maker Workbench. Every page is a file, every link
is relative, and nothing is fetched from anywhere, so it runs from a folder on
disk or from any static host.

## Looking at it

Open `index.html`. It opens the corporate view; `Desk view` in the top right
crosses to the other one, and both show the same book.

## Putting it on GitHub Pages

Commit this folder to a repository and point Pages at it:

* **Settings -> Pages -> Build and deployment**, source *Deploy from a branch*
* pick the branch, and the folder this file is in

The site is then at `https://<user>.github.io/<repo>/`. `.nojekyll` is here
so Pages serves the files as they are rather than running them through Jekyll.

## What works, and what does not

Reading works throughout: the worklist, opening a collection onto its
invoices, every case with its checks and its charges, the counterparty map,
the port directory, the client pricing, the checks and the three source
workbooks. Searching and filtering the worklist work, in the page.

Writing does not, because there is no service behind it. Validating,
approving, resolving a check and raising a query are disabled, and say so.
The state shown is the state the pipeline finished in when this was built:
{cases} consignments in {collections} collections, {passed} checks passed,
{failed} failed and {blocked} unable to run.

Built {when} from the application in this repository, by `tools/freeze.py`.
'''


FONT_CSS = re.compile(r"""https://fonts\.googleapis\.com/css2\?[^"'<>]+""")
FONT_FILE = re.compile(r"https://fonts\.gstatic\.com/[^)]+")


def bundle_fonts(out: pathlib.Path) -> None:
    """Fetch the typefaces and serve them from the folder.

    The last thing in the build that still left the page. The two views are
    set in Spectral and IBM Plex Sans, and in Roboto, and a snapshot that
    falls back to Times the moment it is opened without a connection is not
    the same application. Fetched once here, rewritten to local paths, and
    never requested again.
    """
    import urllib.request
    import ssl

    def get(url: str, binary: bool = False):
        # Google serves woff2 to a browser and truetype to anything else.
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/126.0 Safari/537.36"})
        
        # A corporate CA bundle, when this machine has one. Checked for
        # existence first: the .env in this project names a path under
        # another user's home, and handing that to create_default_context
        # raises FileNotFoundError before a single byte is fetched. A CA
        # file that is not there is not a reason to skip the fonts — the
        # system trust store answers perfectly well.
        ssl_context = None
        ca_bundle = os.getenv("REQUESTS_CA_BUNDLE") or os.getenv("SSL_CERT_FILE")
        if ca_bundle and pathlib.Path(ca_bundle).is_file():
            ssl_context = ssl.create_default_context(cafile=ca_bundle)
        elif ca_bundle:
            print(f"  (CA bundle {ca_bundle} is not on this machine; "
                  f"using the system trust store)")
        
        # Configure proxy if available
        proxy_url = os.getenv("HTTPS_PROXY") or os.getenv("HTTP_PROXY")
        if proxy_url:
            from urllib.request import ProxyHandler
            handler = ProxyHandler({"http": proxy_url, "https": proxy_url})
            opener = urllib.request.build_opener(handler)
            if ssl_context:
                https_handler = urllib.request.HTTPSHandler(context=ssl_context)
                opener.add_handler(https_handler)
            with opener.open(req, timeout=30) as answer:
                raw = answer.read()
        else:
            with urllib.request.urlopen(req, timeout=30, context=ssl_context) as answer:
                raw = answer.read()
        
        return raw if binary else raw.decode("utf-8")

    fonts = out / "static" / "fonts"
    fonts.mkdir(parents=True, exist_ok=True)
    sheets: dict[str, str] = {}
    files: dict[str, str] = {}

    for page in out.rglob("*.html"):
        text = page.read_text(encoding="utf-8")
        for url in set(FONT_CSS.findall(text)):
            if url in sheets:
                continue
            css = get(url)
            for src in set(FONT_FILE.findall(css)):
                if src not in files:
                    name = src.rsplit("/", 1)[-1].split("?")[0]
                    (fonts / name).write_bytes(get(src, binary=True))
                    files[src] = name
            for src, name in files.items():
                css = css.replace(src, "../fonts/" + name)
            stem = "fonts-" + str(len(sheets) + 1) + ".css"
            (out / "static" / "css" / stem).write_text(css, encoding="utf-8")
            sheets[url] = stem

    if not sheets:
        return
    for page in out.rglob("*.html"):
        text = page.read_text(encoding="utf-8")
        if "fonts.googleapis.com" not in text:
            continue
        up = "../" * str(page.relative_to(out)).replace("\\", "/").count("/")
        for url, stem in sheets.items():
            text = text.replace(url, up + "static/css/" + stem)
        # The preconnects point at a host nothing asks for any more.
        text = re.sub(r'\s*<link rel="preconnect"[^>]*>', "", text)
        page.write_text(text, encoding="utf-8")
    weight = sum(f.stat().st_size for f in fonts.iterdir())
    print(f"  {len(files)} font files bundled ({weight/1024:.0f} KB), "
          f"{len(sheets)} stylesheets")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=str(ROOT / "site"))
    args = ap.parse_args()
    out = pathlib.Path(args.out)

    print("running the pipeline ...")
    store = get_store()
    store.reset(run=True)
    cases = store.all_cases()

    print("crawling ...")
    pages, bodies = crawl(store)
    print(f"  {len(pages)} pages")

    if out.exists():
        shutil.rmtree(out)
    for theme in THEMES:
        (out / theme / "cases").mkdir(parents=True, exist_ok=True)

    for key, name in pages.items():
        theme = key[0]
        out_file = f"{theme}/{name}"
        page = rewrite(bodies[key], theme=theme, out_file=out_file, pages={
            k: f"{k[0]}/{v}" for k, v in pages.items()})
        target = out / out_file
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(page, encoding="utf-8")

    shutil.copytree(ROOT / "app" / "static", out / "static")
    try:
        bundle_fonts(out)
    except Exception as e:
        print(f"  Warning: Could not bundle fonts ({type(e).__name__}: {str(e)[:80]})")
        print(f"  Pages will use fallback fonts. Continuing build...")
    (out / "static" / "js" / "offline.js").write_text(OFFLINE_JS, encoding="utf-8")
    (out / "index.html").write_text(INDEX_HTML.format(landing=LANDING),
                                    encoding="utf-8")
    (out / ".nojekyll").write_text("", encoding="utf-8")

    from datetime import date
    from app.store import collections as collect
    checks = [k for c in cases for k in c.checks]
    (out / "README.md").write_text(README.format(
        cases=len(cases), collections=len(collect(cases)),
        passed=sum(1 for k in checks if k.status == "pass"),
        failed=sum(1 for k in checks if k.status == "fail"),
        blocked=sum(1 for k in checks if k.status not in ("pass", "fail")),
        when=date.today().isoformat()), encoding="utf-8")

    size = sum(f.stat().st_size for f in out.rglob("*") if f.is_file())
    print(f"\n{out}  —  {len(pages)} pages, {size/1_048_576:.1f} MB")
    print(f"open {out / 'index.html'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
