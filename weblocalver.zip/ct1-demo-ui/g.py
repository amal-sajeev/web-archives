#!/usr/bin/env python3
"""
Download files or folders from Google Cloud Storage (GCS) using the local WIF connection.

Default WIF directory:
    C:\\Users\\sanjama\\Downloads\\wif_new\\dbgarda

Supported URL / path formats:
    - https://console.cloud.google.com/storage/browser/_details/<bucket>/<path>
    - https://console.cloud.google.com/storage/browser/<bucket>/<path>
    - https://storage.cloud.google.com/<bucket>/<path>
    - https://storage.googleapis.com/<bucket>/<path>
    - gs://<bucket>/<path>
    - <bucket>/<path>

Examples:
    python gcs_download.py "https://console.cloud.google.com/storage/browser/_details/db-dev-euwe3-gcs-155081-dbaware_review/dbaware_review_20086/inbound-data/policy/relevant_policy.json"
    python gcs_download.py "https://console.cloud.google.com/storage/browser/_details/db-dev-euwe3-gcs-155081-dbaware_review/dbaware_review_20086/inbound-data/" -o ./downloads
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.parse
import warnings
from pathlib import Path
from typing import List, Tuple

warnings.filterwarnings("ignore", category=FutureWarning)

DEFAULT_WIF_DIR = Path(r"C:\Users\sanjama\Downloads\wif_new\dbgarda")
DEFAULT_PROJECT = "db-dev-46jr-mp-cta-analytics"
DEFAULT_BUCKET = "db-dev-euwe3-gcs-155081-dbaware_review"
DEFAULT_PROXY = "http://sdod3-proxy.intranet.db.com:8080"
FALLBACK_VENV_PYTHON = Path(r"C:\Users\sanjama\dev\dbconda-2023_09-py311-r36\python.exe")


def _ensure_gcs_dependencies() -> None:
    """If current Python lacks google-cloud-storage, re-exec using the llmjudge venv Python."""
    try:
        import certifi  # noqa: F401
        from google.cloud import storage  # noqa: F401
    except ImportError:
        if (
            FALLBACK_VENV_PYTHON.exists()
            and Path(sys.executable).resolve() != FALLBACK_VENV_PYTHON.resolve()
        ):
            res = subprocess.run([str(FALLBACK_VENV_PYTHON), *sys.argv])
            sys.exit(res.returncode)
        raise


def _is_jwt_expired(jwt_file: Path, leeway_seconds: int = 120) -> bool:
    """Check if the Azure AD JWT in jwtResponse.json is missing or expired."""
    if not jwt_file.exists():
        return True
    try:
        data = json.loads(jwt_file.read_text(encoding="utf-8"))
        token = data.get("access_token", "")
        parts = token.split(".")
        if len(parts) < 2:
            return True
        payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64).decode("utf-8"))
        exp = float(payload.get("exp", 0))
        return (time.time() + leeway_seconds) >= exp
    except Exception:
        return True


def refresh_wif_token(wif_dir: Path, force: bool = False) -> None:
    """Refresh jwtResponse.json using gcp-wif.jar if expired or forced."""
    config_dir = wif_dir / "config"
    jwt_file = config_dir / "jwtResponse.json"
    jar_file = wif_dir / "gcp-wif.jar"
    props_file = config_dir / "application.properties"

    if not force and not _is_jwt_expired(jwt_file):
        return

    if not jar_file.exists() or not props_file.exists():
        raise FileNotFoundError(
            f"WIF jar or application.properties not found in {wif_dir}"
        )

    print(f"[WIF] Refreshing WIF token via {jar_file.name} ...")
    props_uri = props_file.as_posix()
    cmd = [
        "java",
        f"-Dspring.config.location={props_uri}",
        "-jar",
        str(jar_file),
    ]
    proc = subprocess.run(
        cmd,
        cwd=str(wif_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"Failed to refresh WIF token (exit {proc.returncode}):\n{proc.stdout}"
        )
    print("[WIF] Token refreshed successfully.")


def configure_wif_environment(wif_dir: Path, proxy: str) -> None:
    """Configure GOOGLE_APPLICATION_CREDENTIALS, proxy, and combined SSL CA bundle."""
    import certifi

    config_dir = wif_dir / "config"
    wif_json = config_dir / "wif-file-based.json"
    cacert = config_dir / "cacert.crt"

    if not wif_json.exists():
        raise FileNotFoundError(f"WIF credential file not found: {wif_json}")

    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(wif_json)

    if proxy:
        os.environ.setdefault("HTTPS_PROXY", proxy)
        os.environ.setdefault("HTTP_PROXY", proxy)
        os.environ.setdefault("NO_PROXY", "localhost,127.0.0.1")

    ca_bundle = Path(certifi.where()).read_text(encoding="utf-8")
    if cacert.exists():
        custom_ca = cacert.read_text(encoding="utf-8")
        combined_ca = f"{ca_bundle}\n{custom_ca}\n"
    else:
        combined_ca = ca_bundle

    combined_path = Path(tempfile.gettempdir()) / "dbgarda-wif-combined-ca.pem"
    combined_path.write_text(combined_ca, encoding="utf-8")
    os.environ["REQUESTS_CA_BUNDLE"] = str(combined_path)
    os.environ["SSL_CERT_FILE"] = str(combined_path)


def parse_gcs_target(target: str, default_bucket: str = DEFAULT_BUCKET) -> Tuple[str, str, bool]:
    """
    Parse a GCS Console URL, gs:// URI, or bucket/path into (bucket_name, object_path, explicit_folder).
    """
    raw = target.strip()

    if raw.startswith(("http://", "https://")):
        parsed = urllib.parse.urlsplit(raw)
        path = urllib.parse.unquote(parsed.path)
        explicit_folder = path.endswith("/")

        prefixes = [
            "/storage/browser/_details/",
            "/storage/browser/",
        ]
        for prefix in prefixes:
            if path.startswith(prefix):
                remainder = path[len(prefix) :]
                parts = remainder.split("/", 1)
                bucket = parts[0]
                blob_path = parts[1] if len(parts) > 1 else ""
                return bucket, blob_path, explicit_folder

        # https://storage.cloud.google.com/<bucket>/<path> or storage.googleapis.com/<bucket>/<path>
        remainder = path.lstrip("/")
        parts = remainder.split("/", 1)
        bucket = parts[0]
        blob_path = parts[1] if len(parts) > 1 else ""
        return bucket, blob_path, explicit_folder

    if raw.startswith("gs://"):
        remainder = raw[len("gs://") :]
        explicit_folder = remainder.endswith("/")
        parts = remainder.split("/", 1)
        bucket = parts[0]
        blob_path = parts[1] if len(parts) > 1 else ""
        return bucket, blob_path, explicit_folder

    explicit_folder = raw.endswith("/")
    cleaned = raw.lstrip("/")
    if cleaned.startswith(default_bucket + "/"):
        return default_bucket, cleaned[len(default_bucket) + 1 :], explicit_folder

    parts = cleaned.split("/", 1)
    if len(parts) == 2 and parts[0].startswith("db-"):
        return parts[0], parts[1], explicit_folder

    return default_bucket, cleaned, explicit_folder


def download_target(
    client,
    target: str,
    output_dir: Path,
    flat: bool = False,
    list_only: bool = False,
) -> List[Path]:
    """Download a single file or an entire folder prefix from GCS."""
    bucket_name, blob_path, explicit_folder = parse_gcs_target(target)
    bucket = client.bucket(bucket_name)
    downloaded: List[Path] = []

    # 1. If not explicitly ending with '/', check if an exact file blob exists first
    if blob_path and not explicit_folder:
        blob = bucket.blob(blob_path)
        if blob.exists():
            blob.reload()
            if list_only:
                print(f"[FILE] gs://{bucket_name}/{blob.name} ({blob.size} bytes)")
                return []

            dest_path = (
                output_dir / Path(blob_path).name
                if flat
                else output_dir / Path(blob_path)
            )
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            blob.download_to_filename(str(dest_path))
            print(f"[DOWNLOADED] gs://{bucket_name}/{blob.name} -> {dest_path} ({blob.size} bytes)")
            downloaded.append(dest_path)
            return downloaded

    # 2. Treat as folder / prefix
    prefix = blob_path.rstrip("/") + "/" if blob_path.rstrip("/") else ""
    blobs = [
        b
        for b in client.list_blobs(bucket_name, prefix=prefix)
        if not b.name.endswith("/")
    ]

    if not blobs:
        raise FileNotFoundError(
            f"No GCS file or folder objects found at gs://{bucket_name}/{blob_path}"
        )

    print(f"[FOLDER] Found {len(blobs)} file(s) under gs://{bucket_name}/{prefix}")
    base_folder_name = Path(prefix.rstrip("/")).name if prefix else bucket_name

    for b in blobs:
        if list_only:
            print(f"  - gs://{bucket_name}/{b.name} ({b.size} bytes)")
            continue

        if flat:
            rel_path = Path(b.name[len(prefix) :]) if prefix and b.name.startswith(prefix) else Path(b.name)
            dest_path = output_dir / base_folder_name / rel_path
        else:
            dest_path = output_dir / Path(b.name)

        dest_path.parent.mkdir(parents=True, exist_ok=True)
        b.download_to_filename(str(dest_path))
        print(f"  [DOWNLOADED] gs://{bucket_name}/{b.name} -> {dest_path} ({b.size} bytes)")
        downloaded.append(dest_path)

    return downloaded


def main() -> int:
    _ensure_gcs_dependencies()
    from google.cloud import storage

    parser = argparse.ArgumentParser(
        description="Download files or folders from GCS using the dbgarda WIF connection."
    )
    parser.add_argument(
        "targets",
        nargs="+",
        help="One or more GCS browser URLs, gs:// URIs, or bucket/object paths.",
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        default="gcs_downloads",
        help="Local directory to save downloaded files (default: ./gcs_downloads).",
    )
    parser.add_argument(
        "--flat",
        action="store_true",
        help="Save files directly by filename/subfolder instead of full bucket key hierarchy.",
    )
    parser.add_argument(
        "-l",
        "--list-only",
        action="store_true",
        help="List matching GCS objects without downloading them.",
    )
    parser.add_argument(
        "--refresh-token",
        action="store_true",
        help="Force refresh of jwtResponse.json via gcp-wif.jar before connecting.",
    )
    parser.add_argument(
        "--wif-dir",
        default=str(DEFAULT_WIF_DIR),
        help=f"Path to WIF directory (default: {DEFAULT_WIF_DIR}).",
    )
    parser.add_argument(
        "--project",
        default=DEFAULT_PROJECT,
        help=f"GCP project ID (default: {DEFAULT_PROJECT}).",
    )
    parser.add_argument(
        "--proxy",
        default=DEFAULT_PROXY,
        help=f"Corporate HTTP/HTTPS proxy URL (default: {DEFAULT_PROXY}).",
    )

    args = parser.parse_args()
    wif_dir = Path(args.wif_dir)
    output_dir = Path(args.output_dir).resolve()

    refresh_wif_token(wif_dir, force=args.refresh_token)
    configure_wif_environment(wif_dir, proxy=args.proxy)

    client = storage.Client(project=args.project)

    total_downloaded: List[Path] = []
    for target in args.targets:
        try:
            files = download_target(
                client=client,
                target=target,
                output_dir=output_dir,
                flat=args.flat,
                list_only=args.list_only,
            )
            total_downloaded.extend(files)
        except Exception as exc:
            # If token expired mid-run or STS rejected it, try refreshing once automatically
            if "invalid_grant" in str(exc).lower() or "expired" in str(exc).lower():
                refresh_wif_token(wif_dir, force=True)
                client = storage.Client(project=args.project)
                files = download_target(
                    client=client,
                    target=target,
                    output_dir=output_dir,
                    flat=args.flat,
                    list_only=args.list_only,
                )
                total_downloaded.extend(files)
            else:
                raise

    if not args.list_only:
        print(f"\nDone. Downloaded {len(total_downloaded)} file(s) to: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
