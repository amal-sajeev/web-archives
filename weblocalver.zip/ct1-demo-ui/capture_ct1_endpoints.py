"""Capture actual read-only CT1 responses used by the demo UI; never synthesize payloads."""
import argparse
import datetime
import json
import os
import ssl
import urllib.error
import urllib.request
from pathlib import Path

HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com").rstrip("/")
LOCAL = os.getenv("DEMO_UI_URL", "http://127.0.0.1:8095").rstrip("/")
ARTIFACTS = ("policy", "findings_details", "historical_plan_details", "lrr", "current_details", "alc_nlac", "control_details", "risk_driver_details", "group_audit")
TYPES = ("policy", "kod", "procedure", "gfms", "historical_scoping_document", "lrr")


def capture(method, url, body=None, timeout=30):
    payload = json.dumps(body).encode("utf-8") if body is not None else None
    request = urllib.request.Request(url, data=payload, method=method)
    if body is not None:
        request.add_header("Content-Type", "application/json")
    entry = {"method": method, "url": url, "request_json": body}
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl._create_unverified_context()) as response:
            raw = response.read().decode("utf-8", errors="replace")
            entry["status_code"] = response.status
    except urllib.error.HTTPError as error:
        raw = error.read().decode("utf-8", errors="replace")
        entry["status_code"] = error.code
    except Exception as error:
        entry["connection_error"] = str(error)
        return entry
    try:
        entry["response_json"] = json.loads(raw)
    except ValueError:
        entry["response_text"] = raw
    return entry


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan-number", default="20440")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("CT1_ENDPOINTS_AND_JSON_SAMPLES.json"))
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--session-id", help="Optional existing extraction session for read-only status polling")
    args = parser.parse_args()
    plan = args.plan_number
    t = args.timeout
    calls = [
        capture("GET", f"{LOCAL}/api/config", timeout=t),
        capture("GET", f"{LOCAL}/api/ct1/plan/{plan}/bootstrap", timeout=t),
        capture("POST", f"{HOST}/query-service/qna/documents/list-all", {"plan_number": plan}, t),
        capture("GET", f"{HOST}/scoping-dataextraction-agent/getdata/{plan}/availability", timeout=t),
    ]
    for doc_type in TYPES:
        calls.append(capture("POST", f"{HOST}/query-service/qna/documents/list", {"plan_number": plan, "document_type": doc_type}, t))
    for artifact in ARTIFACTS:
        calls.append(capture("GET", f"{HOST}/scoping-dataextraction-agent/getdata/{plan}/{artifact}", timeout=t))
    if args.session_id:
        calls.append(capture("GET", f"{HOST}/scoping-dataextraction-agent/data-extraction/{args.session_id}/status", timeout=t))
        calls.append(capture("GET", f"{LOCAL}/api/ct1/dataextraction/status/{args.session_id}", timeout=t))
    result = {
        "captured_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "plan_number": plan,
        "note": "Raw live HTTP responses, including errors. Mutating/costly routes are intentionally not invoked.",
        "calls": calls,
        "not_invoked": [
            {"method": "POST", "url": f"{LOCAL}/api/ct1/query/chat", "reason": "Invokes paid LLM and may persist chat context"},
            {"method": "POST", "url": f"{LOCAL}/api/ct1/query/ingest", "reason": "Uploads and mutates documents"},
            {"method": "POST", "url": f"{LOCAL}/api/ct1/dataextraction/run", "reason": "Starts an extraction job"},
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
    print(f"Saved {len(calls)} actual HTTP responses to {args.output}")
    for entry in calls:
        print(f"{entry['status_code'] if 'status_code' in entry else entry.get('connection_error')} {entry['url']}")


if __name__ == "__main__":
    main()
