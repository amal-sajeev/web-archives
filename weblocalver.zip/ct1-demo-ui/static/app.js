(() => {
  "use strict";

  const GROUP_LABEL_MAP = {
    policy: "Policies",
    kod: "KOD",
    procedure: "Procedures",
    gfms: "GFMS Data",
    historical_scoping_document: "Historical Scoping",
    lrr: "LRR Mandates",
  };

  const DOC_TYPE_TO_ARTIFACT = {
    policy: "policy",
    kod: "policy",
    procedure: "policy",
    gfms: "findings_details",
    historical_scoping_document: "historical_plan_details",
    lrr: "lrr",
  };

  const PR_SECTION_DEFS = [
    { key: "past_review", title: "Past Review Analysis", short: "Past Review" },
    {
      key: "policy_regulation",
      title: "Policy, KOD and Regulatory Analysis",
      short: "Policy, KOD & Regulatory",
    },
    { key: "broad_scope", title: "Broad Scope Direction", short: "Broad Scope" },
  ];

  const PR_AFFECTED_SECTIONS_MAP = {
    policy: ["policy_regulation", "broad_scope"],
    kod: ["policy_regulation", "broad_scope"],
    procedure: ["policy_regulation", "broad_scope"],
    gfms: ["broad_scope"],
    historical_scoping_document: ["past_review", "broad_scope"],
    lrr: ["policy_regulation", "broad_scope"],
  };

  const DEFAULT_ARTIFACTS = [
    { id: "policy", label: "Policies / KOD / Proc", excludable: "true" },
    { id: "findings_details", label: "GFMS Findings", excludable: "true" },
    { id: "historical_plan_details", label: "Historical Plans", excludable: "true" },
    { id: "lrr", label: "LRR Mandates", excludable: "true" },
    { id: "current_details", label: "Current Plan", excludable: "false" },
    { id: "alc_nlac", label: "ALC / NALC", excludable: "false" },
    { id: "control_details", label: "Controls", excludable: "false" },
    { id: "risk_driver_details", label: "Risk Drivers", excludable: "false" },
    { id: "group_audit", label: "Group Audit", excludable: "false" },
  ];

  const state = {
    planNumber: "20440",
    ctaHost: "",
    queryMode: "",
    chatMode: "add_remove", // "add_remove" | "qa"
    artifactDefs: [...DEFAULT_ARTIFACTS],
    activeArtifact: "policy",
    rightTab: "pr", // "pr" | "feeds"
    viewMode: "cards", // "cards" | "json"
    catalog: null,
    availability: null,
    artifacts: {},
    errors: {},
    prevCounts: {},
    prevArtifactKeys: {},
    mentionItems: [],
    filteredMentions: [],
    mentionOpen: false,
    mentionIndex: 0,
    mentionAnchorStart: -1,
    mentionFilter: "all",
    mentionLastQuery: "",
    isBusy: false,
    pollTimer: null,
    lastErrorPayload: null,
    scopeExplicit: false,
    scopeResolved: {},
    scopeSource: "",
    prReport: null,
    prPrevReport: null,
    prActiveSection: "Past Review Analysis",
    prEditMode: false,
    prAutoRegen: true,
    prStaleSections: [],
    prUpdatedSections: [],
    prLastChangeSummary: "",
    prAccepted: false,
    prGenerating: false,
    prSource: "",
    prLatencyMs: null,
    prTimer: null,
    prStartedAt: 0,
    citationBlobUrl: null,
  };

  const els = {
    ct1StatusDot: document.getElementById("ct1StatusDot"),
    ct1HostBadge: document.getElementById("ct1HostBadge"),
    planForm: document.getElementById("planForm"),
    planInput: document.getElementById("planInput"),
    loadPlanBtn: document.getElementById("loadPlanBtn"),
    refreshBtn: document.getElementById("refreshBtn"),
    runExtractionBtn: document.getElementById("runExtractionBtn"),
    statusDrawer: document.getElementById("statusDrawer"),
    statusText: document.getElementById("statusText"),
    catalogActiveCount: document.getElementById("catalogActiveCount"),
    catalogExcludedCount: document.getElementById("catalogExcludedCount"),
    chatPaneCaption: document.getElementById("chatPaneCaption"),
    chatModeAddRemove: document.getElementById("chatModeAddRemove"),
    chatModeQa: document.getElementById("chatModeQa"),
    chatStream: document.getElementById("chatStream"),
    composerForm: document.getElementById("composerForm"),
    chatInput: document.getElementById("chatInput"),
    sendBtn: document.getElementById("sendBtn"),
    triggerAtBtn: document.getElementById("triggerAtBtn"),
    attachBtn: document.getElementById("attachBtn"),
    fileInput: document.getElementById("fileInput"),
    ingestDrawer: document.getElementById("ingestDrawer"),
    ingestDocType: document.getElementById("ingestDocType"),
    ingestFileNames: document.getElementById("ingestFileNames"),
    ingestSubmitBtn: document.getElementById("ingestSubmitBtn"),
    ingestCancelBtn: document.getElementById("ingestCancelBtn"),
    mentionPopover: document.getElementById("mentionPopover"),
    mentionPlanTag: document.getElementById("mentionPlanTag"),
    mentionMatchCount: document.getElementById("mentionMatchCount"),
    mentionFilters: document.getElementById("mentionFilters"),
    mentionList: document.getElementById("mentionList"),
    quickPrompts: document.getElementById("quickPrompts"),
    kpiActiveFeedCount: document.getElementById("kpiActiveFeedCount"),
    kpiExcludedCount: document.getElementById("kpiExcludedCount"),
    kpiFeedCount: document.getElementById("kpiFeedCount"),
    kpiLatency: document.getElementById("kpiLatency"),
    artifactTabs: document.getElementById("artifactTabs"),
    feedViewport: document.getElementById("feedViewport"),
    feedSourceBadge: document.getElementById("feedSourceBadge"),
    feedDescription: document.getElementById("feedDescription"),
    deltaPill: document.getElementById("deltaPill"),
    cardsContainer: document.getElementById("cardsContainer"),
    rawJsonPre: document.getElementById("rawJsonPre"),
    segmented: document.querySelector(".segmented"),
    errorModalBackdrop: document.getElementById("errorModalBackdrop"),
    errorModalTitle: document.getElementById("errorModalTitle"),
    errorModalBadge: document.getElementById("errorModalBadge"),
    errorModalCloseBtn: document.getElementById("errorModalCloseBtn"),
    errorModalMessage: document.getElementById("errorModalMessage"),
    errorModalMeta: document.getElementById("errorModalMeta"),
    errorModalFailuresSection: document.getElementById("errorModalFailuresSection"),
    errorModalFailuresList: document.getElementById("errorModalFailuresList"),
    errorModalDetailsPre: document.getElementById("errorModalDetailsPre"),
    errorModalCopyBtn: document.getElementById("errorModalCopyBtn"),
    errorModalDismissBtn: document.getElementById("errorModalDismissBtn"),
    scopeBar: document.getElementById("scopeBar"),
    processInstanceInput: document.getElementById("processInstanceInput"),
    taskIdInput: document.getElementById("taskIdInput"),
    reviewScopeIdInput: document.getElementById("reviewScopeIdInput"),
    scopeSourceBadge: document.getElementById("scopeSourceBadge"),
    scopeHint: document.getElementById("scopeHint"),
    scopeApplyBtn: document.getElementById("scopeApplyBtn"),
    scopeClearBtn: document.getElementById("scopeClearBtn"),
    // Workflow stepper & right-pane PR workspace
    stepExtraction: document.getElementById("stepExtraction"),
    stepExtractionSub: document.getElementById("stepExtractionSub"),
    stepCuration: document.getElementById("stepCuration"),
    stepCurationSub: document.getElementById("stepCurationSub"),
    stepPr: document.getElementById("stepPr"),
    stepPrSub: document.getElementById("stepPrSub"),
    stepAccept: document.getElementById("stepAccept"),
    stepAcceptSub: document.getElementById("stepAcceptSub"),
    rightTabPr: document.getElementById("rightTabPr"),
    rightTabFeeds: document.getElementById("rightTabFeeds"),
    prTabBadge: document.getElementById("prTabBadge"),
    feedsTabBadge: document.getElementById("feedsTabBadge"),
    prPanel: document.getElementById("prPanel"),
    feedsPanel: document.getElementById("feedsPanel"),
    prGenerateAllBtn: document.getElementById("prGenerateAllBtn"),
    prRegenSelectedBtn: document.getElementById("prRegenSelectedBtn"),
    prAutoRegenCheckbox: document.getElementById("prAutoRegenCheckbox"),
    prReloadBtn: document.getElementById("prReloadBtn"),
    prEditBtn: document.getElementById("prEditBtn"),
    prDownloadBtn: document.getElementById("prDownloadBtn"),
    prAcceptBtn: document.getElementById("prAcceptBtn"),
    prStaleBanner: document.getElementById("prStaleBanner"),
    prStaleText: document.getElementById("prStaleText"),
    prRegenAffectedBtn: document.getElementById("prRegenAffectedBtn"),
    prSectionTabs: document.getElementById("prSectionTabs"),
    prViewport: document.getElementById("prViewport"),
    prSourceBadge: document.getElementById("prSourceBadge"),
    prDescription: document.getElementById("prDescription"),
    prDeltaPill: document.getElementById("prDeltaPill"),
    prStructuredContainer: document.getElementById("prStructuredContainer"),
    prEditContainer: document.getElementById("prEditContainer"),
    prEditTitle: document.getElementById("prEditTitle"),
    prEditFields: document.getElementById("prEditFields"),
    prSaveEditBtn: document.getElementById("prSaveEditBtn"),
    prCancelEditBtn: document.getElementById("prCancelEditBtn"),
    prRawJsonPre: document.getElementById("prRawJsonPre"),
    citationModalBackdrop: document.getElementById("citationModalBackdrop"),
    citationModalTitle: document.getElementById("citationModalTitle"),
    citationModalSubtitle: document.getElementById("citationModalSubtitle"),
    citationModalBadge: document.getElementById("citationModalBadge"),
    citationModalCloseBtn: document.getElementById("citationModalCloseBtn"),
    citationModalDismissBtn: document.getElementById("citationModalDismissBtn"),
    citationViewerLoading: document.getElementById("citationViewerLoading"),
    citationPdfFrame: document.getElementById("citationPdfFrame"),
    citationJsonPre: document.getElementById("citationJsonPre"),
    citationModalUriHint: document.getElementById("citationModalUriHint"),
    citationDownloadLink: document.getElementById("citationDownloadLink"),
  };

  const SCOPE_FIELDS = ["review_scope_id", "process_instance_id", "task_id", "review_scope_stage"];

  function scopeInputValues() {
    return {
      review_scope_id: ((els.reviewScopeIdInput && els.reviewScopeIdInput.value) || "").trim(),
      process_instance_id: ((els.processInstanceInput && els.processInstanceInput.value) || "").trim(),
      task_id: ((els.taskIdInput && els.taskIdInput.value) || "").trim(),
    };
  }

  function explicitScopeValues() {
    if (!state.scopeExplicit) return {};
    return Object.fromEntries(Object.entries(scopeInputValues()).filter(([, value]) => value));
  }

  function buildScopeQueryString() {
    const params = new URLSearchParams();
    Object.entries(explicitScopeValues()).forEach(([key, value]) => params.set(key, value));
    const query = params.toString();
    return query ? `?${query}` : "";
  }

  function buildUserDetails() {
    const resolved = state.scopeResolved || {};
    const details = { user: resolved.user || "demo.user@db.com" };
    SCOPE_FIELDS.forEach((key) => {
      const value = resolved[key];
      if (value !== undefined && value !== null && String(value).trim()) {
        details[key] = String(value).trim();
      }
    });
    Object.entries(explicitScopeValues()).forEach(([key, value]) => {
      if (SCOPE_FIELDS.includes(key)) details[key] = value;
    });
    return details;
  }

  function renderScopeState() {
    if (!els.scopeSourceBadge) return;
    let label = "Plan-level";
    let variant = "is-plan";
    if (state.scopeExplicit) {
      label = "Manual scope";
      variant = "is-manual";
    } else if (state.scopeSource === "auto") {
      label = "Auto from task";
      variant = "is-auto";
    }
    els.scopeSourceBadge.textContent = label;
    els.scopeSourceBadge.className = `scope-source-badge ${variant}`;

    if (els.scopeHint) {
      const bits = SCOPE_FIELDS.map((key) => state.scopeResolved[key])
        .filter((value) => value !== undefined && value !== null && String(value).trim())
        .map((value) => String(value).trim());
      els.scopeHint.textContent = bits.length
        ? `Resolved scope: ${bits.join(" · ")}. Manual values above always take precedence.`
        : "Scope resolves from /task/status/{plan}; manual values above always take precedence.";
    }
  }

  function markScopeInputsAuto(isAuto) {
    [els.processInstanceInput, els.taskIdInput, els.reviewScopeIdInput].forEach((input) => {
      if (input) input.classList.toggle("is-auto-filled", Boolean(isAuto));
    });
  }

  function syncScopeFromBootstrap(data) {
    const resolved = data && typeof data.scope_context === "object" && data.scope_context ? data.scope_context : {};
    state.scopeSource = (data && data.scope_source) || "";
    state.scopeResolved = resolved;
    if (!state.scopeExplicit) {
      if (els.processInstanceInput) els.processInstanceInput.value = resolved.process_instance_id || "";
      if (els.taskIdInput) els.taskIdInput.value = resolved.task_id || "";
      if (els.reviewScopeIdInput) els.reviewScopeIdInput.value = resolved.review_scope_id || "";
      markScopeInputsAuto(true);
    } else {
      markScopeInputsAuto(false);
    }
    renderScopeState();
  }

  function updateScopeFromInputs() {
    const hasAny = Object.values(scopeInputValues()).some((value) => value);
    state.scopeExplicit = hasAny;
    if (!hasAny) state.scopeResolved = {};
    markScopeInputsAuto(false);
    renderScopeState();
  }

  function clearScopeInputs() {
    [els.processInstanceInput, els.taskIdInput, els.reviewScopeIdInput].forEach((input) => {
      if (input) input.value = "";
    });
    state.scopeExplicit = false;
    state.scopeResolved = {};
    renderScopeState();
  }

  async function readResponsePayload(resp) {
    const rawText = await resp.text();
    if (!rawText) return { rawText: "", parsed: {} };
    try {
      return { rawText, parsed: JSON.parse(rawText) };
    } catch (_) {
      return { rawText, parsed: rawText };
    }
  }

  function normalizeErrorPayload(resp, payload, fallbackOp, endpoint) {
    const detail = payload && typeof payload === "object" && payload.detail !== undefined ? payload.detail : null;
    const errDetailsObj =
      payload && typeof payload === "object" && payload.error_details && !Array.isArray(payload.error_details)
        ? payload.error_details
        : null;
    const errDetailsArr =
      (detail && typeof detail === "object" && Array.isArray(detail.error_details) && detail.error_details) ||
      (payload && typeof payload === "object" && Array.isArray(payload.error_details) && payload.error_details) ||
      [];

    let message = "";
    if (errDetailsObj && errDetailsObj.message) {
      message = String(errDetailsObj.message);
    } else if (detail && typeof detail === "object") {
      message = String(detail.error || detail.message || JSON.stringify(detail));
    } else if (typeof detail === "string" && detail) {
      message = detail;
    } else if (payload && typeof payload === "object" && (payload.error || payload.message || payload.answer)) {
      message = String(payload.error || payload.message || payload.answer);
    } else if (typeof payload === "string" && payload) {
      message = payload;
    } else if (resp) {
      message = `HTTP ${resp.status} ${resp.statusText || ""}`.trim();
    } else {
      message = "Unexpected error";
    }

    const operation =
      (errDetailsObj && errDetailsObj.operation) ||
      (detail && typeof detail === "object" && detail.operation) ||
      fallbackOp ||
      "request";
    const resolvedEndpoint =
      (errDetailsObj && errDetailsObj.upstream_url) ||
      (detail && typeof detail === "object" && detail.upstream_url) ||
      endpoint ||
      "";
    const httpStatus =
      (errDetailsObj && errDetailsObj.upstream_status) ||
      (detail && typeof detail === "object" && detail.upstream_status) ||
      (resp ? resp.status : null);
    const stage =
      (errDetailsObj && (errDetailsObj.stage || errDetailsObj.status)) ||
      (payload && typeof payload === "object" && (payload.status || payload.stage)) ||
      (httpStatus ? `HTTP ${httpStatus}` : "error");

    const failures = [];
    if (errDetailsObj && Array.isArray(errDetailsObj.failed)) {
      failures.push(...errDetailsObj.failed);
    }
    if (errDetailsArr.length) {
      failures.push(...errDetailsArr);
    }

    const titleMap = {
      bootstrap: "CT1 Plan Sync Failed",
      query_chat: "Query Agent Q&A Error",
      query_add_remove: "Document Add/Remove Workflow Error",
      rag_ingest_documents: "RAG Document Ingest Failed",
      rag_ingest_job_poll: "RAG Ingest Job Failed",
      rag_categorize_document_ids: "RAG Categorization Failed",
      rag_get_relevant_data: "RAG Retrieval Failed",
      dataextraction_run: "Data Extraction Launch Failed",
      dataextraction_status: "Data Extraction Failed",
      pr_health: "Summary Agent Health Check Failed",
      pr_get: "Load Preliminary Research Failed",
      pr_generate: "Preliminary Research Generation Failed",
      pr_edit: "Save Preliminary Research Edit Failed",
      pr_document: "Citation Document Fetch Failed",
      pr_download: "PDF Download Failed",
      pr_accept: "Accept Preliminary Research Failed",
      config: "Configuration Load Failed",
      reset: "Reset Failed",
    };

    return {
      title: titleMap[operation] || "Operation Error",
      badge: httpStatus ? `HTTP ${httpStatus}` : String(stage || "ERROR").toUpperCase(),
      message,
      operation,
      endpoint: resolvedEndpoint,
      httpStatus,
      stage,
      planNumber: state.planNumber,
      timestamp: new Date().toISOString(),
      failures,
      details: payload,
    };
  }

  function showErrorModal(errInfo) {
    if (!els.errorModalBackdrop) return;
    const normalized = errInfo && typeof errInfo === "object" ? errInfo : { message: String(errInfo || "Unknown error") };
    state.lastErrorPayload = normalized;

    els.errorModalTitle.textContent = normalized.title || "Operation Error";
    els.errorModalBadge.textContent = normalized.badge || "ERROR";
    els.errorModalMessage.textContent = normalized.message || "An error occurred.";

    const metaRows = [
      ["Operation", normalized.operation || "unknown"],
      ["Plan #", normalized.planNumber || state.planNumber || "n/a"],
      ["HTTP Status", normalized.httpStatus != null ? String(normalized.httpStatus) : "n/a"],
      ["Stage / Status", normalized.stage || "error"],
      ["Endpoint / URL", normalized.endpoint || "n/a"],
      ["Timestamp", normalized.timestamp || new Date().toISOString()],
    ];
    els.errorModalMeta.innerHTML = metaRows
      .map(
        ([k, v]) => `
          <div class="error-modal-meta-item">
            <div class="error-modal-meta-label">${escapeHtml(k)}</div>
            <div class="error-modal-meta-val">${escapeHtml(v)}</div>
          </div>
        `
      )
      .join("");

    const failures = Array.isArray(normalized.failures) ? normalized.failures : [];
    if (failures.length > 0) {
      els.errorModalFailuresSection.hidden = false;
      els.errorModalFailuresList.innerHTML = failures
        .map((f, idx) => {
          const itemObj = f && typeof f === "object" ? f.item || f : {};
          const targetLabel =
            itemObj.title ||
            itemObj.document_title ||
            itemObj.file_name ||
            itemObj.filename ||
            (f && f.target) ||
            `Item #${idx + 1}`;
          const msg =
            (f && (f.error || f.reason || f.message)) ||
            (typeof f === "string" ? f : JSON.stringify(f));
          const urlOrDb = [];
          if (f && f.upstream_url) urlOrDb.push(`url=${f.upstream_url}`);
          if (f && f.upstream_status != null) urlOrDb.push(`status=${f.upstream_status}`);
          const dbInfo = (f && (f.db_result || f.db_target)) || {};
          for (const k of ["table", "data_source", "db_host", "db_name", "db_port", "db_user", "exception_type"]) {
            if (dbInfo[k]) urlOrDb.push(`${k}=${dbInfo[k]}`);
          }
          if (f && f.exception_type && !dbInfo.exception_type) urlOrDb.push(`exception=${f.exception_type}`);
          return `
            <div class="error-modal-failure-item">
              <div class="error-modal-failure-target">${escapeHtml(targetLabel)}</div>
              <div class="error-modal-failure-msg">${escapeHtml(msg)}</div>
              ${urlOrDb.length ? `<div class="error-modal-failure-sub">${escapeHtml(urlOrDb.join(" · "))}</div>` : ""}
            </div>
          `;
        })
        .join("");
    } else {
      els.errorModalFailuresSection.hidden = true;
      els.errorModalFailuresList.innerHTML = "";
    }

    let rawDump = "";
    try {
      rawDump =
        typeof normalized.details === "string"
          ? normalized.details
          : JSON.stringify(normalized.details ?? normalized, null, 2);
    } catch (_) {
      rawDump = String(normalized.details || normalized.message || "");
    }
    els.errorModalDetailsPre.textContent = rawDump || "{}";
    els.errorModalBackdrop.hidden = false;
  }

  function closeErrorModal() {
    if (!els.errorModalBackdrop) return;
    els.errorModalBackdrop.hidden = true;
  }

  function setStatus(kind, bannerMessage) {
    els.ct1StatusDot.classList.remove("is-loading", "is-error");
    if (kind === "loading") {
      els.ct1StatusDot.classList.add("is-loading");
    } else if (kind === "error") {
      els.ct1StatusDot.classList.add("is-error");
    }

    if (bannerMessage) {
      els.statusText.textContent = bannerMessage;
      els.statusDrawer.classList.add("is-open");
    } else {
      els.statusDrawer.classList.remove("is-open");
    }
  }

  function escapeHtml(text) {
    return String(text ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function formatRichUserText(text) {
    const escaped = escapeHtml(text);
    return escaped.replace(/(@\[[^\]]+\])/g, '<span class="mention-token">$1</span>');
  }

  function isExcludedStatus(item) {
    if (!item || typeof item !== "object") return false;
    if (item.excluded === true) return true;
    const st = String(item.status || "").trim().toLowerCase();
    return st === "excluded" || st === "removed" || st === "inactive" || st === "deleted";
  }

  function isMaskedPlaceholder(value) {
    const s = String(value ?? "").trim();
    return !s || /^x+$/i.test(s);
  }

  function unwrapEnvelope(payload) {
    if (payload && typeof payload === "object" && !Array.isArray(payload) && payload.data !== undefined) {
      return payload.data;
    }
    return payload;
  }

  function buildMentionCatalog(catalog) {
    const items = [];
    if (!catalog || !Array.isArray(catalog.document_groups)) return items;

    let docIdx = 0;
    let secIdx = 0;
    for (const group of catalog.document_groups) {
      const gtype = String(group.document_type || "policy").toLowerCase();
      const glabel = GROUP_LABEL_MAP[gtype] || gtype;
      const docs = Array.isArray(group.documents) ? group.documents : [];

      for (const doc of docs) {
        if (!doc || typeof doc !== "object") continue;
        docIdx += 1;
        const fileName = String(doc.file_name || doc.filename || "").trim();
        const gsUri = String(doc.storage_uri || doc.gs_uri || "").trim();
        const title = String(
          doc.document_title ||
            doc.document_name ||
            doc.title ||
            fileName ||
            (gsUri ? gsUri.split("/").pop() : "") ||
            "Document"
        ).trim();
        const docExcluded = isExcludedStatus(doc);

        items.push({
          key: `doc:${gtype}:${doc.document_id || fileName || title}:${docIdx}`,
          docType: gtype,
          groupLabel: glabel,
          isSection: false,
          title,
          subtitle: fileName ? `${glabel} · ${fileName}` : glabel,
          excluded: docExcluded,
          mentionText: `@[${glabel}: ${title}]`,
          searchBlob: `${glabel} ${title} ${fileName}`.toLowerCase(),
        });

        const sections = Array.isArray(doc.sections) ? doc.sections : [];
        for (const sec of sections) {
          if (!sec || typeof sec !== "object") continue;
          secIdx += 1;
          const sid = sec.section_id ?? "";
          const stitle = String(sec.section_title || sec.title || `Section ${sid}`).trim();
          const secExcluded = docExcluded || isExcludedStatus(sec);
          const secLabel =
            sid && !stitle.toLowerCase().includes(String(sid).toLowerCase())
              ? `Section ${sid}: ${stitle}`
              : stitle;

          items.push({
            key: `sec:${gtype}:${doc.document_id || fileName || title}:${sid}:${secIdx}`,
            docType: gtype,
            groupLabel: glabel,
            isSection: true,
            title: stitle,
            subtitle: `${glabel} · ${title}${sid ? ` (#${sid})` : ""}`,
            excluded: secExcluded,
            mentionText: `@[${glabel}: ${title} > ${secLabel}]`,
            searchBlob: `${glabel} ${title} ${stitle} ${sid} ${secLabel}`.toLowerCase(),
          });
        }
      }
    }
    return items;
  }

  function updateCatalogSummary(catalog) {
    let active = 0;
    let excluded = 0;
    if (catalog && Array.isArray(catalog.document_groups)) {
      for (const group of catalog.document_groups) {
        for (const doc of group.documents || []) {
          if (isExcludedStatus(doc)) {
            excluded += 1;
          } else {
            active += 1;
          }
          for (const sec of doc.sections || []) {
            if (isExcludedStatus(sec)) excluded += 1;
          }
        }
      }
    }
    els.catalogActiveCount.textContent = String(active);
    els.catalogExcludedCount.textContent = String(excluded);
    els.kpiExcludedCount.textContent = String(excluded);
  }

  function extractArtifactRecords(artifactId, payload) {
    if (payload == null) return [];
    const data = unwrapEnvelope(payload);
    if (data == null) return [];

    if (artifactId === "policy") {
      let list = [];
      if (Array.isArray(data)) {
        list = data;
      } else if (Array.isArray(data.referenced_documents)) {
        list = data.referenced_documents;
      } else if (Array.isArray(data.documents)) {
        list = data.documents;
      } else if (Array.isArray(data.items)) {
        list = data.items;
      } else if (Array.isArray(data.sources)) {
        list = data.sources;
      } else if (Array.isArray(data.nodes)) {
        list = data.nodes;
      } else if (data && typeof data === "object") {
        Object.entries(data).forEach(([k, val]) => {
          if (Array.isArray(val)) {
            val.forEach((item) => {
              if (item && typeof item === "object") {
                list.push({ document_type: item.document_type || k, ...item });
              }
            });
          } else if (val && typeof val === "object") {
            const nested =
              val.referenced_documents || val.documents || val.sources || val.nodes || null;
            if (Array.isArray(nested)) {
              nested.forEach((item) => {
                if (item && typeof item === "object") {
                  list.push({ document_type: item.document_type || val.document_type || k, ...item });
                }
              });
            } else if (val.document_name || val.document_title || val.gs_uri || val.storage_uri) {
              list.push({ document_type: val.document_type || k, ...val });
            }
          }
        });
      }

      const rows = [];
      list.forEach((row, idx) => {
        if (!row || typeof row !== "object" || isExcludedStatus(row)) return;
        const dtype = String(row.document_type || "policy").toLowerCase();
        const gsUri = row.gs_uri || row.storage_uri || row.source_uri || row.uri || "";
        const docName = String(
          row.document_name ||
            row.document_title ||
            row.file_name ||
            row.filename ||
            row.title ||
            (gsUri ? String(gsUri).split("/").pop() : "") ||
            `Policy Item ${idx + 1}`
        ).trim();
        const sections = Array.isArray(row.sections) ? row.sections.filter((s) => s && !isExcludedStatus(s)) : [];

        rows.push({
          key: `doc:${dtype}:${row.document_id || row.file_name || gsUri || docName}:${idx}`,
          title: docName,
          tag: dtype.toUpperCase(),
          body: String(row.text || row.content || gsUri || "").slice(0, 320),
          meta: [
            ["Type", dtype],
            row.document_id != null ? ["Doc ID", row.document_id] : null,
            sections.length ? ["Active Sections", sections.length] : null,
            row.file_name ? ["File", row.file_name] : null,
          ].filter(Boolean),
        });

        sections.forEach((sec, sIdx) => {
          const sid = sec.section_id ?? sIdx + 1;
          const stitle = String(sec.section_title || sec.title || `Section ${sid}`).trim();
          const secKey = sec.node_id ? `sec:${sec.node_id}:${sIdx}` : `sec:${dtype}:${idx}:${docName}:${sid}:${sIdx}`;
          rows.push({
            key: secKey,
            title: `${docName} › ${stitle}`,
            tag: `${dtype.toUpperCase()} §${sid}`,
            body: String(sec.section_path || sec.original_text || stitle).slice(0, 260),
            meta: [
              ["Section ID", sid],
              sec.page_start != null ? ["Page", sec.page_start] : null,
              sec.node_id ? ["Node", sec.node_id] : null,
            ].filter(Boolean),
          });
        });
      });
      return rows;
    }

    if (artifactId === "findings_details") {
      const rawList = Array.isArray(data.findings_details)
        ? data.findings_details
        : Array.isArray(data)
        ? data
        : [];
      const rows = [];
      rawList.forEach((wrapper, wIdx) => {
        if (!wrapper || typeof wrapper !== "object" || isExcludedStatus(wrapper)) return;
        const list = Array.isArray(wrapper.responsePayload) ? wrapper.responsePayload : [wrapper];
        list.forEach((f, idx) => {
          if (!f || typeof f !== "object" || isExcludedStatus(f)) return;
          const fid = f.findingId || f.id || `${wIdx}-${idx}`;
          const rawTitle = !isMaskedPlaceholder(f.findingTitle)
            ? f.findingTitle
            : !isMaskedPlaceholder(f.title)
            ? f.title
            : f.ct1 || f.subBusinessArea || f.businessArea || "Open Finding";
          const rawBody = !isMaskedPlaceholder(f.findingDescription)
            ? f.findingDescription
            : !isMaskedPlaceholder(f.findingExecutiveSummary)
            ? f.findingExecutiveSummary
            : [f.riskTaxonomy ? `Risk: ${f.riskTaxonomy}` : "", f.findingRootCause ? `Root Cause: ${f.findingRootCause}` : ""]
                .filter(Boolean)
                .join("\n") || "GFMS Finding";
          rows.push({
            key: `gfms:${fid}`,
            title: `Finding ${fid} — ${rawTitle}`,
            tag: [f.rating || f.findingRating || f.severity, f.findingStatus].filter(Boolean).join(" · ") || `ID ${fid}`,
            body: String(rawBody).slice(0, 320),
            meta: [
              ["Finding ID", fid],
              f.findingOwner ? ["Owner", f.findingOwner] : null,
              f.ct1 ? ["Control", f.ct1] : null,
              f.assuranceDate ? ["Assurance Date", f.assuranceDate] : null,
            ].filter(Boolean),
          });
        });
      });
      return rows;
    }

    if (artifactId === "historical_plan_details") {
      const list = Array.isArray(data.historical_plan_details)
        ? data.historical_plan_details
        : Array.isArray(data.items)
        ? data.items
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => {
          const pnum = item["Plan Item Number"] || item.plan_item_number || item.planNumber || String(idx + 1);
          const ptitle = item["Plan Item Title"] || item.plan_item_title || item.title || `Historical Plan ${pnum}`;
          return {
            key: `hist:${pnum}`,
            title: `Plan ${pnum}: ${ptitle}`,
            tag: [item["Plan Year"], item["Plan Item Type"] || item["Plan Item Status"]].filter(Boolean).join(" · ") || `Plan ${pnum}`,
            body: String(item["Description of Plan Item"] || item["Audit Objective"] || item.audit_objective || "Historical scoping plan record").slice(0, 320),
            meta: [
              item["Review Lead"] ? ["Lead", item["Review Lead"]] : null,
              item["Report Number"] ? ["Report #", item["Report Number"]] : null,
              item["UoT Risk Type"] ? ["Risk", item["UoT Risk Type"]] : null,
            ].filter(Boolean),
          };
        });
    }

    if (artifactId === "lrr") {
      const arr = Array.isArray(data.internet_search_data_enriched)
        ? data.internet_search_data_enriched
        : Array.isArray(data.internet_search_data)
        ? data.internet_search_data
        : Array.isArray(data.lrr)
        ? data.lrr
        : Array.isArray(data.documents)
        ? data.documents
        : Array.isArray(data)
        ? data
        : [];
      const rows = [];
      let mandateCounter = 0;
      arr.forEach((entry, idx) => {
        if (!entry || typeof entry !== "object" || isExcludedStatus(entry)) return;
        if (Array.isArray(entry.Mandates)) {
          const riskName = entry["Risk Name"] || entry.risk_name || `Risk ${idx + 1}`;
          entry.Mandates.forEach((m) => {
            if (!m || typeof m !== "object" || isExcludedStatus(m)) return;
            mandateCounter += 1;
            const mtitle = m["Regulatory Mandate"] || m.mandate || m.Citation || `Mandate ${mandateCounter}`;
            const firstEv = Array.isArray(m.Evidence) && m.Evidence[0] ? m.Evidence[0] : null;
            rows.push({
              key: String(m.node_id || `lrr:mandate:${mandateCounter}:${String(mtitle).slice(0, 40)}`),
              title: String(mtitle).slice(0, 140),
              tag: `${riskName}${m["Confidence Score"] != null ? ` · ${m["Confidence Score"]}` : ""}`,
              body: String(m["AI Rationale"] || m["Applicability Summary"] || firstEv?.evidence_text || "Regulatory mandate").slice(0, 320),
              meta: [
                ["Mandate #", mandateCounter],
                firstEv?.source_url ? ["Source", firstEv.source_url] : null,
                m.Jurisdiction ? ["Jurisdiction", m.Jurisdiction] : null,
              ].filter(Boolean),
            });
          });
        } else {
          mandateCounter += 1;
          const title = entry["Regulatory Mandate"] || entry.title || entry.document_title || `LRR Entry ${mandateCounter}`;
          rows.push({
            key: String(entry.node_id || `lrr:entry:${mandateCounter}:${String(title).slice(0, 40)}`),
            title,
            tag: entry["Risk Name"] || entry.document_type || "LRR",
            body: String(entry["AI Rationale"] || entry.summary || entry.Citation || "").slice(0, 320),
            meta: [
              entry.Regulator ? ["Regulator", entry.Regulator] : null,
              entry.Citation ? ["Citation", entry.Citation] : null,
            ].filter(Boolean),
          });
        }
      });
      return rows;
    }

    if (artifactId === "current_details") {
      const planObj = data.plan_details && typeof data.plan_details === "object"
        ? data.plan_details
        : Array.isArray(data)
        ? data[0]
        : data;
      if (!planObj || typeof planObj !== "object" || Array.isArray(planObj)) return [];
      const pnum = planObj["Plan Item Number"] || state.planNumber;
      const rows = [
        {
          key: `current:plan:${pnum}`,
          title: planObj["Plan Item Title"] || `Plan ${pnum}`,
          tag: `Plan ${pnum} · ${planObj["Plan Item Status"] || "Active"}`,
          body: String(planObj["Description of Plan Item"] || "").slice(0, 320),
          meta: [
            planObj["AU Region"] ? ["Region", planObj["AU Region"]] : null,
            planObj["Plan Year"] ? ["Year", planObj["Plan Year"]] : null,
            planObj["Review Lead"] ? ["Lead", planObj["Review Lead"]] : null,
            planObj["UoT Risk Type"] ? ["Risk Type", planObj["UoT Risk Type"]] : null,
          ].filter(Boolean),
        },
      ];
      if (Array.isArray(planObj["AU-RT-KC"])) {
        planObj["AU-RT-KC"].forEach((mapping, idx) => {
          rows.push({
            key: `current:aurtkc:${idx}:${mapping.KC || ""}`,
            title: mapping.AU || `Assessment Unit Mapping #${idx + 1}`,
            tag: `${mapping.RT || "Risk"} · ${mapping.KC || "KC"}`,
            body: `Mapped Assessment Unit to Risk Type ${mapping.RT || ""} and Key Control ${mapping.KC || ""}`,
            meta: [
              mapping.RT ? ["Risk Type", mapping.RT] : null,
              mapping.KC ? ["Key Control", mapping.KC] : null,
            ].filter(Boolean),
          });
        });
      }
      return rows;
    }

    if (artifactId === "alc_nlac") {
      const list = Array.isArray(data.alc_nalc_details)
        ? data.alc_nalc_details
        : Array.isArray(data.alc_nlac)
        ? data.alc_nlac
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => ({
          key: `alc:${item.id || idx}`,
          title: String(item.title || item.name || item.plan_item_title || `ALC/NALC Record #${idx + 1}`),
          tag: String(item.type || item.status || "ALC/NALC"),
          body: String(item.description || item.summary || item.rationale || "").slice(0, 320),
          meta: Object.entries(item)
            .filter(([, v]) => v != null && typeof v !== "object" && String(v).length < 60)
            .slice(0, 4),
        }));
    }

    if (artifactId === "control_details") {
      const ctrlRoot = data.control_details && typeof data.control_details === "object" ? data.control_details : data;
      const included = Array.isArray(ctrlRoot?.included_kcs)
        ? ctrlRoot.included_kcs
        : Array.isArray(ctrlRoot)
        ? ctrlRoot
        : [];
      return included
        .filter((c) => c && typeof c === "object" && !isExcludedStatus(c))
        .map((c, idx) => {
          const inv = c.inventory && typeof c.inventory === "object" ? c.inventory : c;
          const defn = c.definition && typeof c.definition === "object" ? c.definition : {};
          const obj = c.objective && typeof c.objective === "object" ? c.objective : {};
          const instNo = inv.controlInstanceNumber || inv.controlDefinitionNumber || idx;
          return {
            key: `ctrl:${instNo}`,
            title: `${inv.controlDefinitionNumber || "Control"}: ${inv.controlDefinitionName || inv.controlInstanceName || "Control"}`,
            tag: [inv.classification || defn.classification, inv.assessmentUnitDer].filter(Boolean).join(" · ") || "Included KC",
            body: String(inv.controlWhat || defn.description || inv.controlDescription || "").slice(0, 320),
            meta: [
              ["Instance", instNo],
              inv.controlFrequency ? ["Frequency", inv.controlFrequency] : null,
              inv.operatingControlOwner ? ["Owner", inv.operatingControlOwner] : null,
              obj.controlObjectiveNumber ? ["Objective", obj.controlObjectiveNumber] : null,
            ].filter(Boolean),
          };
        });
    }

    if (artifactId === "risk_driver_details") {
      const list = Array.isArray(data.risk_driver_details)
        ? data.risk_driver_details
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => {
          const rid = item.riskid || item.risk_id || item.id || String(idx + 1);
          const drivers = Array.isArray(item.risk_drivers) ? item.risk_drivers : [];
          return {
            key: `risk:${rid}:${idx}`,
            title: `${rid} — ${item.risk_name || item.title || "Risk Type"}`,
            tag: `${drivers.length} risk driver(s)`,
            body: drivers.length
              ? drivers.map((d) => d.name || d.title || JSON.stringify(d)).join("; ").slice(0, 320)
              : `Mapped risk taxonomy ${rid} (${item.risk_name || ""}) with no granular risk drivers returned.`,
            meta: [["Risk ID", rid]],
          };
        });
    }

    if (artifactId === "group_audit") {
      const list = Array.isArray(data.group_audit_details)
        ? data.group_audit_details
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => ({
          key: `ga:${item.auditId || item.id || idx}`,
          title: String(item.auditName || item.title || `Group Audit #${idx + 1}`),
          tag: String(item.auditNumber || item.status || "Group Audit"),
          body: String(item.summary || item.description || "").slice(0, 320),
          meta: [],
        }));
    }

    return [];
  }

  function renderArtifactTabs(deltasByArtifact = {}) {
    els.artifactTabs.innerHTML = "";
    let availableFeeds = 0;

    for (const def of state.artifactDefs) {
      const payload = state.artifacts[def.id];
      const records = payload ? extractArtifactRecords(def.id, payload) : [];
      if (payload !== undefined && payload !== null) {
        availableFeeds += 1;
      }

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "artifact-tab";
      if (def.id === state.activeArtifact) btn.classList.add("is-active");
      if (deltasByArtifact[def.id]) btn.classList.add("has-delta");
      btn.dataset.artifact = def.id;
      btn.innerHTML = `<span>${escapeHtml(def.label)}</span><span class="tab-count">${records.length}</span>`;
      btn.addEventListener("click", () => {
        if (state.activeArtifact === def.id) return;
        state.activeArtifact = def.id;
        renderArtifactTabs();
        renderActiveArtifactFeed(false);
      });
      els.artifactTabs.appendChild(btn);
    }

    if (els.feedsTabBadge) {
      els.feedsTabBadge.textContent = `${availableFeeds}/${state.artifactDefs.length}`;
    }
    els.kpiFeedCount.textContent = `${availableFeeds} / ${state.artifactDefs.length}`;
  }

  function buildCardSlot(record, isEntering) {
    const slot = document.createElement("div");
    slot.className = isEntering ? "feed-card-slot is-entering is-highlight" : "feed-card-slot";
    slot.dataset.itemKey = record.key;

    const metaHtml = (record.meta || [])
      .map(([k, v]) => `<span><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v)}</span>`)
      .join("");

    slot.innerHTML = `
      <div class="feed-card-slot-inner">
        <article class="feed-card">
          <div class="feed-card-head">
            <h3 class="feed-card-title">${escapeHtml(record.title)}</h3>
            <span class="feed-card-tag">${escapeHtml(record.tag)}</span>
          </div>
          ${record.body ? `<div class="feed-card-body">${escapeHtml(record.body)}</div>` : ""}
          ${metaHtml ? `<div class="feed-kv-grid">${metaHtml}</div>` : ""}
        </article>
      </div>
    `;
    return slot;
  }

  function renderActiveArtifactFeed(animateTransitions = true) {
    const artifactId = state.activeArtifact;
    const payload = state.artifacts[artifactId];
    const errMsg = state.errors[artifactId];
    const records = payload ? extractArtifactRecords(artifactId, payload) : [];

    els.kpiActiveFeedCount.textContent = String(records.length);
    els.rawJsonPre.textContent = payload !== undefined ? JSON.stringify(payload, null, 2) : `// ${errMsg || "No payload available"}`;

    const def = state.artifactDefs.find((d) => d.id === artifactId);
    let extraNote = "";
    if (artifactId === "control_details") {
      const exLen = unwrapEnvelope(payload)?.control_details?.excluded_kcs?.length || 0;
      if (exLen) extraNote = ` (${exLen} retired KC in dbGRC)`;
    }
    els.feedDescription.textContent = errMsg
      ? `Feed notice: ${errMsg}`
      : `${def ? def.label : artifactId} — ${records.length} active record(s) sent downstream${extraNote}`;
    els.feedSourceBadge.textContent = errMsg ? "Unavailable" : "CT1 Live";

    const prevKeys = state.prevArtifactKeys[artifactId] || new Set(records.map((r) => r.key));
    const nextKeys = new Set(records.map((r) => r.key));
    const addedCount = records.filter((r) => !prevKeys.has(r.key)).length;
    const removedCount = [...prevKeys].filter((k) => !nextKeys.has(k)).length;
    state.prevArtifactKeys[artifactId] = nextKeys;

    if (animateTransitions && (addedCount > 0 || removedCount > 0)) {
      const parts = [];
      if (removedCount > 0) parts.push(`-${removedCount} excluded`);
      if (addedCount > 0) parts.push(`+${addedCount} included`);
      els.deltaPill.textContent = parts.join(" · ");
      els.deltaPill.classList.add("is-visible");
    } else if (!animateTransitions) {
      els.deltaPill.classList.remove("is-visible");
    }

    const container = els.cardsContainer;

    if (!records.length && !animateTransitions) {
      container.innerHTML = `<div class="empty-state">${escapeHtml(errMsg || "No active records in this artifact feed.")}</div>`;
      return;
    }

    const existingSlots = new Map();
    container.querySelectorAll(".feed-card-slot:not(.is-exiting)").forEach((el) => {
      existingSlots.set(el.dataset.itemKey, el);
    });

    if (!animateTransitions || existingSlots.size === 0) {
      container.innerHTML = "";
      if (!records.length) {
        container.innerHTML = `<div class="empty-state">${escapeHtml(errMsg || "No active records in this artifact feed.")}</div>`;
        return;
      }
      const frag = document.createDocumentFragment();
      records.forEach((rec) => frag.appendChild(buildCardSlot(rec, false)));
      container.appendChild(frag);
      return;
    }

    const firstRects = new Map();
    existingSlots.forEach((el, key) => {
      firstRects.set(key, el.getBoundingClientRect());
    });

    container.querySelectorAll(".empty-state").forEach((n) => n.remove());

    const exitingNodes = [];
    existingSlots.forEach((el, key) => {
      if (!nextKeys.has(key)) {
        el.classList.add("is-exiting");
        exitingNodes.push(el);
      }
    });

    const newSlots = [];
    records.forEach((rec) => {
      const existing = existingSlots.get(rec.key);
      if (existing) {
        container.appendChild(existing);
      } else {
        const slot = buildCardSlot(rec, true);
        container.appendChild(slot);
        newSlots.push(slot);
      }
    });

    existingSlots.forEach((el, key) => {
      if (!nextKeys.has(key)) return;
      const first = firstRects.get(key);
      const last = el.getBoundingClientRect();
      if (!first || !last) return;
      const dy = first.top - last.top;
      if (Math.abs(dy) > 1) {
        el.style.transition = "none";
        el.style.transform = `translate3d(0, ${dy}px, 0)`;
        requestAnimationFrame(() => {
          el.style.transition = "";
          el.style.transform = "translate3d(0, 0, 0)";
        });
      }
    });

    if (newSlots.length > 0) {
      requestAnimationFrame(() => {
        newSlots.forEach((slot) => {
          slot.classList.remove("is-entering");
          slot.classList.add("is-entered");
          window.setTimeout(() => slot.classList.remove("is-highlight"), 1400);
        });
      });
    }

    if (exitingNodes.length > 0) {
      window.setTimeout(() => {
        exitingNodes.forEach((node) => node.remove());
        if (records.length === 0 && !container.querySelector(".feed-card-slot")) {
          container.innerHTML = `<div class="empty-state">All items in this feed have been excluded for downstream agents.</div>`;
        }
      }, 360);
    } else if (records.length === 0) {
      container.innerHTML = `<div class="empty-state">All items in this feed have been excluded for downstream agents.</div>`;
    }
  }

  async function refreshPlanData(planNumber, { animate = false, silentBanner = false } = {}) {
    const planChanged = planNumber !== state.planNumber;
    state.planNumber = planNumber;
    if (planChanged) {
      state.prReport = null;
      state.prPrevReport = null;
      state.prStaleSections = [];
      state.prUpdatedSections = [];
      state.prLastChangeSummary = "";
      state.prAccepted = false;
      state.mentionFilter = "all";
      if (state.prEditMode) cancelPrEdit();
    }
    els.mentionPlanTag.textContent = planNumber;
    if (!silentBanner) {
      setStatus("loading", `Syncing plan ${planNumber} from CT1 (${state.ctaHost || "live"})...`);
    } else {
      setStatus("loading", null);
    }

    const endpoint = `/api/ct1/plan/${encodeURIComponent(planNumber)}/bootstrap${buildScopeQueryString()}`;
    try {
      const resp = await fetch(endpoint);
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "bootstrap", endpoint);
        setStatus("error", `CT1 sync error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return false;
      }

      const deltas = {};
      for (const def of state.artifactDefs) {
        const nextPayload = data.artifacts ? data.artifacts[def.id] : undefined;
        const nextLen = nextPayload ? extractArtifactRecords(def.id, nextPayload).length : 0;
        const prevLen = state.prevCounts[def.id];
        if (animate && prevLen !== undefined && prevLen !== nextLen) {
          deltas[def.id] = nextLen - prevLen;
        }
        state.prevCounts[def.id] = nextLen;
      }

      state.catalog = data.catalog;
      state.availability = data.availability;
      state.artifacts = data.artifacts || {};
      state.errors = data.errors || {};
      state.ctaHost = data.cta_host || state.ctaHost;
      state.queryMode = data.query_mode || "";
      syncScopeFromBootstrap(data);

      if (data.preliminary_research && typeof data.preliminary_research === "object") {
        const prData = data.preliminary_research;
        if (prData.available && prData.analysis_report) {
          state.prReport = {
            plan_number: prData.plan_number || planNumber,
            analysis_report: prData.analysis_report,
          };
          state.prSource = prData.source || state.prSource || "summary_agent";
        } else if (planChanged) {
          state.prReport = null;
        }
      }

      const hasErrors = Boolean(
        data.has_errors ||
          (Array.isArray(data.error_details) && data.error_details.length > 0) ||
          Object.keys(state.errors).length > 0
      );
      const modeLabel = state.queryMode === "error"
        ? "Query Service ERROR"
        : state.queryMode
        ? `Query Service (${state.queryMode})`
        : "Query Service live";
      els.ct1HostBadge.textContent = `${state.ctaHost} · Plan ${planNumber} · ${modeLabel}`;
      els.kpiLatency.textContent = `${data.latency_ms ?? "--"} ms`;

      state.mentionItems = buildMentionCatalog(state.catalog);
      updateCatalogSummary(state.catalog);
      renderArtifactTabs(deltas);
      renderActiveArtifactFeed(animate);
      renderPrSectionTabs();
      renderPrReport();

      if (hasErrors) {
        const errInfo = normalizeErrorPayload(resp, data, "bootstrap", endpoint);
        errInfo.title = `CT1 Sync Partial Error (Plan ${planNumber})`;
        errInfo.message =
          Object.entries(state.errors)
            .map(([k, v]) => `${k}: ${v}`)
            .join("\n") || "One or more CT1 upstream endpoints returned an error.";
        setStatus("error", `CT1 sync encountered ${errInfo.failures.length || Object.keys(state.errors).length} upstream error(s).`);
        showErrorModal(errInfo);
        return false;
      }

      setStatus("ok", null);
      return true;
    } catch (err) {
      const errInfo = normalizeErrorPayload(
        null,
        { error: err.message, exception_type: err.name || "Error", endpoint },
        "bootstrap",
        endpoint
      );
      setStatus("error", `CT1 sync error: ${err.message}`);
      showErrorModal(errInfo);
      return false;
    }
  }

  function appendChatMessage({ role, text, workflow = null, errorInfo = null, isWelcome = false, mode = null }) {
    const wrapper = document.createElement("div");
    wrapper.className = `chat-msg ${role === "user" ? "is-user" : "is-assistant"}`;

    const label = document.createElement("div");
    label.className = "msg-role";
    label.textContent = role === "user" ? "You" : isWelcome ? "CT1 Scoping Query Agent" : "CT1 Query Agent";
    if (mode && !isWelcome) {
      const badge = document.createElement("span");
      badge.className = `msg-mode-badge ${mode === "add_remove" ? "is-workflow" : "is-qa"}`;
      badge.textContent = mode === "add_remove" ? "Include/Exclude" : "Q&A";
      label.appendChild(badge);
    }
    wrapper.appendChild(label);

    const bubble = document.createElement("div");
    bubble.className = "msg-bubble";
    if (role === "user") {
      bubble.innerHTML = formatRichUserText(text);
    } else {
      bubble.textContent = text;
    }

    if (workflow && typeof workflow === "object" && (workflow.stage || workflow.status || workflow.plan || workflow.actions)) {
      bubble.appendChild(buildWorkflowCard(workflow, errorInfo));
    } else if (errorInfo) {
      const errBtnRow = document.createElement("div");
      errBtnRow.className = "workflow-card-actions";
      errBtnRow.style.marginTop = "8px";
      const viewErrBtn = document.createElement("button");
      viewErrBtn.type = "button";
      viewErrBtn.className = "btn btn-error-details btn-xs";
      viewErrBtn.textContent = "View Error Details";
      viewErrBtn.addEventListener("click", () => showErrorModal(errorInfo));
      errBtnRow.appendChild(viewErrBtn);
      bubble.appendChild(errBtnRow);
    }

    wrapper.appendChild(bubble);
    els.chatStream.appendChild(wrapper);
    requestAnimationFrame(() => {
      els.chatStream.scrollTo({ top: els.chatStream.scrollHeight, behavior: "smooth" });
    });
  }

  // ===========================
  // Preliminary Research Engine
  // ===========================
  function getPrAnalysisReport() {
    if (state.prReport && state.prReport.analysis_report && typeof state.prReport.analysis_report === "object") {
      return state.prReport.analysis_report;
    }
    return null;
  }

  function switchRightTab(tab) {
    state.rightTab = tab === "feeds" ? "feeds" : "pr";
    if (els.rightTabPr) {
      els.rightTabPr.classList.toggle("is-active", state.rightTab === "pr");
      els.rightTabPr.setAttribute("aria-selected", String(state.rightTab === "pr"));
    }
    if (els.rightTabFeeds) {
      els.rightTabFeeds.classList.toggle("is-active", state.rightTab === "feeds");
      els.rightTabFeeds.setAttribute("aria-selected", String(state.rightTab === "feeds"));
    }
    if (els.prPanel) els.prPanel.hidden = state.rightTab !== "pr";
    if (els.feedsPanel) els.feedsPanel.hidden = state.rightTab !== "feeds";
  }

  function updateWorkflowStepper() {
    if (!els.stepExtraction) return;
    const feedCount = state.artifactDefs.filter((d) => state.artifacts[d.id] !== undefined && state.artifacts[d.id] !== null).length;
    const activeCatalog = Number(els.catalogActiveCount ? els.catalogActiveCount.textContent : 0) || 0;
    const excludedCatalog = Number(els.catalogExcludedCount ? els.catalogExcludedCount.textContent : 0) || 0;
    const report = getPrAnalysisReport();
    const reportSections = report ? Object.keys(report) : [];
    const staleCount = state.prStaleSections.length;

    els.stepExtraction.className = `step-pill ${feedCount > 0 ? "is-done" : "is-active"}`;
    els.stepExtractionSub.textContent = `${feedCount}/${state.artifactDefs.length} feeds synced`;

    els.stepCuration.className = `step-pill ${excludedCatalog > 0 ? "is-done" : activeCatalog > 0 ? "is-active" : "is-pending"}`;
    els.stepCurationSub.textContent = `${activeCatalog} active · ${excludedCatalog} excluded`;

    if (state.prGenerating) {
      els.stepPr.className = "step-pill is-active";
      els.stepPrSub.textContent = "Generating live on CT1...";
    } else if (report && staleCount > 0) {
      els.stepPr.className = "step-pill is-stale";
      els.stepPrSub.textContent = `${staleCount} section(s) stale`;
    } else if (report) {
      els.stepPr.className = "step-pill is-done";
      els.stepPrSub.textContent = `${reportSections.length}/3 sections ready`;
    } else {
      els.stepPr.className = "step-pill is-pending";
      els.stepPrSub.textContent = "Not generated yet";
    }

    if (state.prAccepted) {
      els.stepAccept.className = "step-pill is-done";
      els.stepAcceptSub.textContent = "Accepted in workflow";
    } else if (report) {
      els.stepAccept.className = "step-pill is-active";
      els.stepAcceptSub.textContent = state.prEditMode ? "Editing draft..." : "Ready for review";
    } else {
      els.stepAccept.className = "step-pill is-pending";
      els.stepAcceptSub.textContent = "Pending report";
    }
  }

  function updatePrControlsState() {
    const report = getPrAnalysisReport();
    const hasReport = Boolean(report);
    const hasSectionContent = Boolean(report && report[state.prActiveSection]);
    const busy = state.prGenerating;

    if (els.prGenerateAllBtn) els.prGenerateAllBtn.disabled = busy;
    if (els.prRegenSelectedBtn) els.prRegenSelectedBtn.disabled = busy;
    if (els.prReloadBtn) els.prReloadBtn.disabled = busy;
    if (els.prEditBtn) {
      els.prEditBtn.disabled = busy || !hasSectionContent;
      els.prEditBtn.textContent = state.prEditMode ? "Editing..." : "Edit Section";
    }
    if (els.prDownloadBtn) els.prDownloadBtn.disabled = busy || !hasReport;
    if (els.prAcceptBtn) {
      els.prAcceptBtn.disabled = busy || !hasReport || state.prAccepted;
      els.prAcceptBtn.textContent = state.prAccepted ? "Accepted ✓" : "Accept PR";
    }

    if (els.prTabBadge) {
      if (state.prGenerating) {
        els.prTabBadge.textContent = "Running...";
        els.prTabBadge.className = "right-tab-pill is-stale";
      } else if (state.prStaleSections.length > 0 && hasReport) {
        els.prTabBadge.textContent = `${state.prStaleSections.length} stale`;
        els.prTabBadge.className = "right-tab-pill is-stale";
      } else if (hasReport) {
        els.prTabBadge.textContent = state.prAccepted ? "Accepted" : "Ready";
        els.prTabBadge.className = "right-tab-pill is-ready";
      } else {
        els.prTabBadge.textContent = "Empty";
        els.prTabBadge.className = "right-tab-pill";
      }
    }

    if (els.prStaleBanner) {
      if (state.prStaleSections.length > 0 && !state.prGenerating) {
        const labels = state.prStaleSections
          .map((k) => {
            const found = PR_SECTION_DEFS.find((d) => d.key === k);
            return found ? found.short : k;
          })
          .join(", ");
        const prefix = state.prLastChangeSummary ? `${state.prLastChangeSummary} · ` : "";
        els.prStaleText.textContent = `${prefix}Affected section(s) need regeneration: ${labels}`;
        els.prStaleBanner.hidden = false;
      } else {
        els.prStaleBanner.hidden = true;
      }
    }

    updateWorkflowStepper();
  }

  function countSectionUnits(sectionObj) {
    if (!sectionObj || typeof sectionObj !== "object") return 0;
    if (Array.isArray(sectionObj.historical_reviews)) return sectionObj.historical_reviews.length;
    if (Array.isArray(sectionObj.paragraphs)) return sectionObj.paragraphs.length;
    return 0;
  }

  function renderPrSectionTabs() {
    if (!els.prSectionTabs) return;
    const report = getPrAnalysisReport();
    els.prSectionTabs.innerHTML = "";

    PR_SECTION_DEFS.forEach((def) => {
      const sectionData = report && report[def.title];
      const count = countSectionUnits(sectionData);
      const isStale = state.prStaleSections.includes(def.key);
      const isUpdated = !isStale && state.prUpdatedSections.includes(def.key);

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "pr-section-tab";
      if (def.title === state.prActiveSection) btn.classList.add("is-active");
      if (isStale) btn.classList.add("is-stale");
      else if (isUpdated) btn.classList.add("is-updated");

      const badgeText = isStale ? "STALE" : isUpdated ? "UPDATED" : sectionData ? String(count) : "0";
      btn.innerHTML = `<span>${escapeHtml(def.short)}</span><span class="pr-section-badge">${escapeHtml(badgeText)}</span>`;
      btn.addEventListener("click", () => {
        if (state.prEditMode) cancelPrEdit();
        state.prActiveSection = def.title;
        renderPrSectionTabs();
        renderPrReport();
      });
      els.prSectionTabs.appendChild(btn);
    });
  }

  function renderCitationChipsHtml(citations = [], chunkIds = []) {
    const chips = [];
    const seen = new Set();

    (Array.isArray(citations) ? citations : []).forEach((c) => {
      if (!c || typeof c !== "object") return;
      const cid = String(c.chunk_id || "").trim();
      const gsUri = String(c.gs_uri || c.access_info?.uri || "").trim();
      const url = String(c.url || "").trim();
      const page = c.page_number ?? c.location_metadata?.page_number ?? "";
      const docName = String(c.document_name || "").trim();
      const ctype = String(c.content_type || "").trim();
      const label = String(c.citation_label || (page ? `${cid || "Src"} p.${page}` : cid || docName || "Source")).trim();
      const dedupKey = `${cid}|${gsUri}|${url}|${page}`;
      if ((!cid && !gsUri && !url) || seen.has(dedupKey)) return;
      seen.add(dedupKey);
      if (cid) seen.add(`id:${cid}`);
      chips.push(
        `<button type="button" class="citation-chip" data-chunk-id="${escapeHtml(cid)}" data-gs-uri="${escapeHtml(gsUri)}" data-url="${escapeHtml(url)}" data-page-number="${escapeHtml(String(page))}" data-doc-name="${escapeHtml(docName)}" data-content-type="${escapeHtml(ctype)}" data-label="${escapeHtml(label)}" title="${escapeHtml(docName || gsUri || url || cid)}">[${escapeHtml(label)}]</button>`
      );
    });

    (Array.isArray(chunkIds) ? chunkIds : []).forEach((rawId) => {
      const cid = String(rawId || "").trim();
      if (!cid || seen.has(`id:${cid}`)) return;
      seen.add(`id:${cid}`);
      chips.push(
        `<button type="button" class="citation-chip" data-chunk-id="${escapeHtml(cid)}" data-label="Citation ${escapeHtml(cid)}" title="View source chunk ${escapeHtml(cid)}">[${escapeHtml(cid)}]</button>`
      );
    });

    return chips.length ? ` ${chips.join(" ")}` : "";
  }

  function formatInlineMarkdownHtml(rawText) {
    const escaped = escapeHtml(String(rawText || ""));
    return escaped
      .replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>")
      .replace(/&lt;u&gt;(.*?)&lt;\/u&gt;/gi, "<u>$1</u>")
      .replace(/\n/g, "<br />");
  }

  function renderNarrativeBlockHtml(value, fallbackCitations = [], fallbackChunkIds = []) {
    if (Array.isArray(value)) {
      return value
        .map((unit) => {
          if (typeof unit === "string") {
            return formatInlineMarkdownHtml(unit);
          }
          if (unit && typeof unit === "object") {
            const body = formatInlineMarkdownHtml(unit.content || unit.text || "");
            const chips = renderCitationChipsHtml(unit.supporting_citations, unit.supporting_chunk_ids);
            return `${body}${chips}`;
          }
          return "";
        })
        .filter(Boolean)
        .join("<br />");
    }
    if (value && typeof value === "object" && Array.isArray(value.content)) {
      return renderNarrativeBlockHtml(value.content, value.supporting_citations, value.supporting_chunk_ids);
    }
    const text = typeof value === "string" ? value : (value && value.content) || "";
    const chips = renderCitationChipsHtml(fallbackCitations, fallbackChunkIds);
    return `${formatInlineMarkdownHtml(text)}${chips}`;
  }

  function renderPastReviewReportHtml(sectionData) {
    const reviews = Array.isArray(sectionData.historical_reviews) ? sectionData.historical_reviews : [];
    const summaryBar = `
      <div class="pr-past-summary">
        <span>Current Review: <strong>${escapeHtml(sectionData.current_review_id || state.planNumber)}</strong></span>
        <span>Similar Historical Reviews Analyzed: <strong>${escapeHtml(String(sectionData.similar_review_count ?? reviews.length))}</strong></span>
      </div>
    `;
    if (!reviews.length) {
      return `${summaryBar}<div class="pr-section-card"><p class="pr-paragraph-block">No historical reviews returned in this report.</p></div>`;
    }
    const cards = reviews
      .map((rev) => {
        const assessments = Array.isArray(rev.assessments) ? rev.assessments : [];
        const rowsHtml = assessments
          .map((a) => `
            <tr>
              <td><strong>${escapeHtml(a.assessed_area || "Area")}</strong></td>
              <td>${renderNarrativeBlockHtml(a.key_observation)}</td>
              <td>${renderNarrativeBlockHtml(a.implication_for_current_review)}</td>
            </tr>
          `)
          .join("");
        return `
          <div class="pr-past-card">
            <div class="pr-section-head">
              <h3 class="pr-section-heading">Historical Review ${escapeHtml(rev.historical_review_id || "")}${rev.review_title ? ` — ${escapeHtml(rev.review_title)}` : ""}</h3>
              <span class="pill-type">${assessments.length} areas</span>
            </div>
            <table class="pr-past-table">
              <thead>
                <tr>
                  <th style="width:18%;">Assessed Area</th>
                  <th style="width:41%;">Key Observation</th>
                  <th style="width:41%;">Implication for Current Review</th>
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
            </table>
          </div>
        `;
      })
      .join("");
    return `${summaryBar}${cards}`;
  }

  function renderParagraphSectionsHtml(sectionData) {
    const paragraphs = Array.isArray(sectionData.paragraphs) ? sectionData.paragraphs : [];
    if (!paragraphs.length) {
      return `<div class="pr-empty-card"><h3>Section is empty</h3><p>No paragraphs were returned for ${escapeHtml(state.prActiveSection)}.</p></div>`;
    }

    const groups = [];
    let currentGroup = null;
    paragraphs.forEach((p, idx) => {
      if (!p || typeof p !== "object") return;
      const meta = p.metadata && typeof p.metadata === "object" ? p.metadata : {};
      const isStart = Boolean(meta.is_section_start) || currentGroup === null;
      if (isStart) {
        currentGroup = {
          paragraphs: [p],
          confidence: meta.section_confidence_score,
          rationale: p.rationale || "",
          index: idx,
        };
        groups.push(currentGroup);
      } else {
        currentGroup.paragraphs.push(p);
        if (!currentGroup.rationale && p.rationale) currentGroup.rationale = p.rationale;
      }
    });

    return groups
      .map((grp) => {
        const first = grp.paragraphs[0];
        const firstRendered = renderNarrativeBlockHtml(
          first.content,
          first.supporting_citations,
          first.supporting_chunk_ids
        );
        const firstLines = firstRendered.split("<br />");
        const headingHtml = firstLines[0] || `Section ${grp.index + 1}`;
        const restFirstHtml = firstLines.slice(1).join("<br />");

        const conf = grp.confidence;
        const confHtml =
          conf != null
            ? `<span class="pr-confidence-pill${Number(conf) < 70 ? " is-med" : ""}">Confidence ${escapeHtml(String(conf))}%</span>`
            : "";

        const bodyBlocks = [];
        if (restFirstHtml.trim()) {
          bodyBlocks.push(`<div class="pr-paragraph-block">${restFirstHtml}</div>`);
        }
        grp.paragraphs.slice(1).forEach((p) => {
          const meta = p.metadata && typeof p.metadata === "object" ? p.metadata : {};
          const level = meta.heading_level ? ` is-level-${meta.heading_level}` : "";
          const html = renderNarrativeBlockHtml(p.content, p.supporting_citations, p.supporting_chunk_ids);
          if (html.trim()) {
            bodyBlocks.push(`<div class="pr-paragraph-block${level}">${html}</div>`);
          }
        });

        const rationaleHtml = grp.rationale
          ? `<details class="pr-rationale-details"><summary>AI Section Reasoning</summary><div class="pr-rationale-body">${formatInlineMarkdownHtml(grp.rationale)}</div></details>`
          : "";

        return `
          <article class="pr-section-card">
            <div class="pr-section-head">
              <h3 class="pr-section-heading">${headingHtml}</h3>
              ${confHtml}
            </div>
            ${bodyBlocks.join("")}
            ${rationaleHtml}
          </article>
        `;
      })
      .join("");
  }

  function renderPrReport() {
    if (!els.prStructuredContainer) return;
    const report = getPrAnalysisReport();
    els.prRawJsonPre.textContent = state.prReport
      ? JSON.stringify(state.prReport, null, 2)
      : "// No Preliminary Research document loaded for this plan yet.";

    if (state.prGenerating) {
      const elapsedSec = state.prStartedAt ? ((Date.now() - state.prStartedAt) / 1000).toFixed(1) : "0.0";
      els.prSourceBadge.textContent = "Generating...";
      els.prDescription.textContent = `Running live CT1 scoping-summary-agent (${elapsedSec}s elapsed)...`;
      els.prStructuredContainer.innerHTML = `
        <div class="pr-loading-card">
          <span class="spinner" aria-hidden="true"></span>
          <div>
            <strong>Generating Preliminary Research on CT1</strong>
            <div style="font-size:12.5px;color:#475569;margin-top:3px;">Reading filtered Data Extraction inputs (post-exclusion) and synthesizing sections via Gemini AI Access Layer... (${escapeHtml(elapsedSec)}s)</div>
          </div>
        </div>
      `;
      updatePrControlsState();
      return;
    }

    if (!report) {
      els.prSourceBadge.textContent = "Not Generated";
      els.prDescription.textContent = `No saved Preliminary Research document found on CT1 for Plan ${state.planNumber}.`;
      els.prStructuredContainer.innerHTML = `
        <div class="pr-empty-card">
          <h3>Preliminary Research Not Generated Yet</h3>
          <p>Review or curate documents in the chat pane (exclude/include with <code>@</code> mentions or upload new docs), then click below to generate all 3 Preliminary Research sections directly on CT1.</p>
          <button type="button" class="btn btn-primary" id="prEmptyGenerateBtn">Generate Preliminary Research Now</button>
        </div>
      `;
      const emptyBtn = document.getElementById("prEmptyGenerateBtn");
      if (emptyBtn) {
        emptyBtn.addEventListener("click", () => generatePreliminaryResearch(null, "Initial full generation"));
      }
      updatePrControlsState();
      return;
    }

    const activeData = report[state.prActiveSection];
    const sourceLabel = "CT1 Summary Agent";
    els.prSourceBadge.textContent = state.prAccepted ? `${sourceLabel} · Accepted` : sourceLabel;
    const latencySuffix = state.prLatencyMs != null ? ` · ${(state.prLatencyMs / 1000).toFixed(1)}s` : "";
    els.prDescription.textContent = `Plan ${state.planNumber} — ${state.prActiveSection}${latencySuffix}`;

    if (state.prDeltaPill) {
      if (state.prUpdatedSections.length > 0) {
        els.prDeltaPill.textContent = `Updated ${state.prUpdatedSections.length} section(s)`;
        els.prDeltaPill.classList.add("is-visible");
      } else {
        els.prDeltaPill.classList.remove("is-visible");
      }
    }

    if (!activeData || typeof activeData !== "object") {
      els.prStructuredContainer.innerHTML = `
        <div class="pr-empty-card">
          <h3>Section Not Present</h3>
          <p><strong>${escapeHtml(state.prActiveSection)}</strong> has not been generated yet. Use Regen Selected above to generate it.</p>
        </div>
      `;
      updatePrControlsState();
      return;
    }

    if (Array.isArray(activeData.historical_reviews)) {
      els.prStructuredContainer.innerHTML = renderPastReviewReportHtml(activeData);
    } else {
      els.prStructuredContainer.innerHTML = renderParagraphSectionsHtml(activeData);
    }
    updatePrControlsState();
  }

  function openPrEditor() {
    const report = getPrAnalysisReport();
    if (!report || !report[state.prActiveSection]) return;
    const secData = report[state.prActiveSection];
    state.prEditMode = true;
    els.prStructuredContainer.hidden = true;
    els.prEditContainer.hidden = false;
    els.prEditTitle.textContent = `Editing: ${state.prActiveSection}`;
    els.prEditFields.innerHTML = "";

    if (Array.isArray(secData.paragraphs)) {
      secData.paragraphs.forEach((p, idx) => {
        const plain = Array.isArray(p.content)
          ? p.content.map((u) => (typeof u === "string" ? u : u.content || "")).join("\n")
          : String(p.content || "");
        const item = document.createElement("div");
        item.className = "pr-edit-item";
        item.innerHTML = `
          <label for="prEditPara_${idx}">Paragraph ${idx + 1} (${escapeHtml(p.paragraph_id || `para_${idx + 1}`)})</label>
          <textarea id="prEditPara_${idx}" class="pr-edit-textarea" data-para-idx="${idx}"></textarea>
        `;
        item.querySelector("textarea").value = plain;
        els.prEditFields.appendChild(item);
      });
    } else {
      const item = document.createElement("div");
      item.className = "pr-edit-item";
      item.innerHTML = `
        <label for="prEditRawSectionJson">Structured Section JSON (${escapeHtml(state.prActiveSection)})</label>
        <textarea id="prEditRawSectionJson" class="pr-edit-textarea is-mono" data-json-editor="true"></textarea>
      `;
      item.querySelector("textarea").value = JSON.stringify(secData, null, 2);
      els.prEditFields.appendChild(item);
    }
    updatePrControlsState();
  }

  function cancelPrEdit() {
    state.prEditMode = false;
    if (els.prEditContainer) els.prEditContainer.hidden = true;
    if (els.prStructuredContainer) els.prStructuredContainer.hidden = false;
    updatePrControlsState();
  }

  async function savePrEdits() {
    const report = getPrAnalysisReport();
    if (!report || !report[state.prActiveSection]) return;
    const updatedReport = JSON.parse(JSON.stringify(report));
    const sec = updatedReport[state.prActiveSection];

    const jsonArea = els.prEditFields.querySelector('textarea[data-json-editor="true"]');
    if (jsonArea) {
      try {
        updatedReport[state.prActiveSection] = JSON.parse(jsonArea.value);
      } catch (err) {
        showErrorModal(
          normalizeErrorPayload(null, { error: `Invalid JSON in section editor: ${err.message}` }, "pr_edit", "/api/ct1/preliminary-research/edit")
        );
        return;
      }
    } else if (Array.isArray(sec.paragraphs)) {
      els.prEditFields.querySelectorAll("textarea[data-para-idx]").forEach((ta) => {
        const idx = Number(ta.dataset.paraIdx);
        const target = sec.paragraphs[idx];
        if (!target) return;
        const nextText = ta.value;
        if (Array.isArray(target.content)) {
          if (target.content.length === 1 && target.content[0] && typeof target.content[0] === "object") {
            target.content[0].content = nextText;
          } else {
            target.content = [{ content: nextText, citation_status: "not_required", supporting_chunk_ids: [], supporting_citations: [] }];
          }
        } else {
          target.content = nextText;
        }
      });
    }

    const endpoint = "/api/ct1/preliminary-research/edit";
    els.prSaveEditBtn.disabled = true;
    setStatus("loading", `Saving edited Preliminary Research (${state.prActiveSection}) to CT1...`);
    try {
      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planNumber: state.planNumber,
          analysis_report: updatedReport,
          userDetails: buildUserDetails(),
        }),
      });
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "pr_edit", endpoint);
        setStatus("error", `Save failed: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }
      state.prReport = { plan_number: data.plan_number || state.planNumber, analysis_report: data.analysis_report || updatedReport };
      state.prSource = data.source || state.prSource;
      cancelPrEdit();
      renderPrSectionTabs();
      renderPrReport();
      setStatus("ok", `Saved edits for ${state.prActiveSection} to CT1.`);
    } catch (err) {
      const errInfo = normalizeErrorPayload(null, { error: err.message }, "pr_edit", endpoint);
      setStatus("error", `Save error: ${err.message}`);
      showErrorModal(errInfo);
    } finally {
      els.prSaveEditBtn.disabled = false;
    }
  }

  async function reloadPreliminaryResearch({ silent = false } = {}) {
    if (!silent) {
      setStatus("loading", `Fetching Preliminary Research for Plan ${state.planNumber} from CT1...`);
    }
    const endpoint = `/api/ct1/preliminary-research/${encodeURIComponent(state.planNumber)}`;
    try {
      const resp = await fetch(endpoint);
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "pr_get", endpoint);
        setStatus("error", `PR fetch failed: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }
      if (data && data.available && data.analysis_report) {
        state.prReport = { plan_number: data.plan_number || state.planNumber, analysis_report: data.analysis_report };
        state.prSource = data.source || "summary_agent";
      } else {
        state.prReport = null;
      }
      renderPrSectionTabs();
      renderPrReport();
      if (!silent) {
        setStatus("ok", data && data.available ? `Loaded saved Preliminary Research for Plan ${state.planNumber}.` : null);
      }
    } catch (err) {
      if (!silent) {
        const errInfo = normalizeErrorPayload(null, { error: err.message }, "pr_get", endpoint);
        setStatus("error", `PR fetch error: ${err.message}`);
        showErrorModal(errInfo);
      }
    }
  }

  async function generatePreliminaryResearch(sections = null, reasonLabel = "") {
    if (state.prGenerating) return;
    if (state.prEditMode) cancelPrEdit();

    const targetSections = Array.isArray(sections) && sections.length ? sections : null;
    state.prPrevReport = state.prReport ? JSON.parse(JSON.stringify(state.prReport)) : null;
    state.prGenerating = true;
    state.prStartedAt = Date.now();
    state.prAccepted = false;
    switchRightTab("pr");
    renderPrSectionTabs();
    renderPrReport();

    const scopeLabel = targetSections ? targetSections.join(", ") : "all 3 sections";
    setStatus("loading", `Generating Preliminary Research (${scopeLabel}) on CT1${reasonLabel ? ` — ${reasonLabel}` : ""}...`);

    if (state.prTimer) window.clearInterval(state.prTimer);
    state.prTimer = window.setInterval(() => {
      if (state.prGenerating) renderPrReport();
    }, 1000);

    const endpoint = "/api/ct1/preliminary-research/generate";
    try {
      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planNumber: state.planNumber,
          sections: targetSections,
          userDetails: buildUserDetails(),
        }),
      });
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "pr_generate", endpoint);
        setStatus("error", `PR generation error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }

      const generatedKeys = Array.isArray(data.sections_requested) ? data.sections_requested : (targetSections || PR_SECTION_DEFS.map((d) => d.key));
      state.prReport = { plan_number: data.plan_number || state.planNumber, analysis_report: data.analysis_report };
      state.prSource = data.source || "summary_agent";
      state.prLatencyMs = data.latency_ms ?? null;
      state.prStaleSections = state.prStaleSections.filter((k) => !generatedKeys.includes(k));
      state.prUpdatedSections = generatedKeys;

      if (targetSections && targetSections.length) {
        const firstDef = PR_SECTION_DEFS.find((d) => d.key === targetSections[0]);
        if (firstDef) state.prActiveSection = firstDef.title;
      }

      setStatus(
        "ok",
        `Preliminary Research ready (${generatedKeys.length} section(s) in ${((data.latency_ms || 0) / 1000).toFixed(1)}s via ${state.prSource}).`
      );
    } catch (err) {
      const errInfo = normalizeErrorPayload(null, { error: err.message }, "pr_generate", endpoint);
      setStatus("error", `PR generation error: ${err.message}`);
      showErrorModal(errInfo);
    } finally {
      state.prGenerating = false;
      if (state.prTimer) {
        window.clearInterval(state.prTimer);
        state.prTimer = null;
      }
      renderPrSectionTabs();
      renderPrReport();
    }
  }

  async function downloadPreliminaryResearchPdf() {
    const endpoint = "/api/ct1/preliminary-research/download";
    setStatus("loading", `Downloading Preliminary Research PDF for Plan ${state.planNumber} from CT1...`);
    try {
      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planNumber: state.planNumber, userDetails: buildUserDetails() }),
      });
      if (!resp.ok) {
        const { parsed: data } = await readResponsePayload(resp);
        const errInfo = normalizeErrorPayload(resp, data, "pr_download", endpoint);
        setStatus("error", `PDF download error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Preliminary_Research_Report_${state.planNumber}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 5000);
      setStatus("ok", `Downloaded Preliminary_Research_Report_${state.planNumber}.pdf`);
    } catch (err) {
      const errInfo = normalizeErrorPayload(null, { error: err.message }, "pr_download", endpoint);
      setStatus("error", `PDF download error: ${err.message}`);
      showErrorModal(errInfo);
    }
  }

  async function acceptPreliminaryResearch() {
    const endpoint = "/api/ct1/preliminary-research/accept";
    els.prAcceptBtn.disabled = true;
    setStatus("loading", `Submitting ACCEPT_PRELIMINARY_RESEARCH for Plan ${state.planNumber} on CT1...`);
    try {
      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planNumber: state.planNumber, userDetails: buildUserDetails() }),
      });
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "pr_accept", endpoint);
        setStatus("error", `Accept PR failed: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }
      state.prAccepted = true;
      renderPrReport();
      setStatus("ok", `Preliminary Research accepted for Plan ${state.planNumber}!`);
      appendChatMessage({
        role: "assistant",
        text: `ACCEPT_PRELIMINARY_RESEARCH completed on CT1 for Plan ${state.planNumber}.`,
      });
    } catch (err) {
      const errInfo = normalizeErrorPayload(null, { error: err.message }, "pr_accept", endpoint);
      setStatus("error", `Accept PR error: ${err.message}`);
      showErrorModal(errInfo);
    } finally {
      updatePrControlsState();
    }
  }

  function closeCitationModal() {
    if (state.citationBlobUrl) {
      URL.revokeObjectURL(state.citationBlobUrl);
      state.citationBlobUrl = null;
    }
    if (els.citationPdfFrame) {
      els.citationPdfFrame.src = "";
      els.citationPdfFrame.hidden = true;
    }
    if (els.citationJsonPre) {
      els.citationJsonPre.textContent = "";
      els.citationJsonPre.hidden = true;
    }
    if (els.citationModalBackdrop) els.citationModalBackdrop.hidden = true;
  }

  async function openCitationPreview(dataset) {
    const url = String(dataset.url || "").trim();
    if (url && /^https?:\/\//i.test(url) && !dataset.gsUri) {
      window.open(url, "_blank", "noopener,noreferrer");
      return;
    }
    if (!els.citationModalBackdrop) return;

    const chunkId = String(dataset.chunkId || "").trim() || null;
    const gsUri = String(dataset.gsUri || "").trim() || null;
    const pageNumber = Number(dataset.pageNumber) > 0 ? Number(dataset.pageNumber) : 1;
    const label = String(dataset.label || dataset.docName || chunkId || "Cited Source");

    closeCitationModal();
    els.citationModalTitle.textContent = dataset.docName || label;
    els.citationModalSubtitle.textContent = `Plan ${state.planNumber}${chunkId ? ` · Chunk ${chunkId}` : ""}${pageNumber ? ` · Page ${pageNumber}` : ""}`;
    els.citationModalBadge.textContent = gsUri && gsUri.toLowerCase().endsWith(".pdf") ? "PDF" : "SOURCE";
    els.citationModalUriHint.textContent = gsUri || url || "";
    els.citationDownloadLink.hidden = true;
    els.citationViewerLoading.hidden = false;
    els.citationModalBackdrop.hidden = false;

    const endpoint = "/api/ct1/preliminary-research/document";
    try {
      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planNumber: state.planNumber,
          chunk_id: chunkId,
          document_uri: gsUri,
          page_number: pageNumber,
        }),
      });
      const { parsed: data } = await readResponsePayload(resp);
      els.citationViewerLoading.hidden = true;
      if (!resp.ok) {
        closeCitationModal();
        const errInfo = normalizeErrorPayload(resp, data, "pr_document", endpoint);
        showErrorModal(errInfo);
        return;
      }

      const src = data.source || {};
      const resolvedUri = (src.access_info && src.access_info.uri) || gsUri || "";
      const resolvedPage = Number(src.location_metadata && src.location_metadata.page_number) || pageNumber;
      els.citationModalUriHint.textContent = resolvedUri;

      if (data.type === "pdf" && typeof data.content === "string") {
        const binaryStr = atob(data.content);
        const bytes = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i += 1) bytes[i] = binaryStr.charCodeAt(i);
        const blob = new Blob([bytes], { type: "application/pdf" });
        state.citationBlobUrl = URL.createObjectURL(blob);
        els.citationPdfFrame.src = `${state.citationBlobUrl}#page=${resolvedPage}`;
        els.citationPdfFrame.hidden = false;
        els.citationModalBadge.textContent = `PDF p.${resolvedPage}`;
        els.citationDownloadLink.href = state.citationBlobUrl;
        els.citationDownloadLink.download = (src.document_name || "cited-document.pdf").replace(/[^\w.-]+/g, "_");
        els.citationDownloadLink.hidden = false;
      } else {
        els.citationJsonPre.textContent = JSON.stringify(data.content ?? data, null, 2);
        els.citationJsonPre.hidden = false;
        els.citationModalBadge.textContent = String(data.type || "JSON").toUpperCase();
      }
    } catch (err) {
      els.citationViewerLoading.hidden = true;
      closeCitationModal();
      showErrorModal(normalizeErrorPayload(null, { error: err.message }, "pr_document", endpoint));
    }
  }

  function deriveAffectedSectionsFromExecList(execList, wf = null) {
    if (wf && Array.isArray(wf.affected_sections) && wf.affected_sections.length) {
      return wf.affected_sections;
    }
    const set = new Set();
    (Array.isArray(execList) ? execList : []).forEach((act) => {
      const dtype = String((act && act.document_type) || "policy").toLowerCase();
      (PR_AFFECTED_SECTIONS_MAP[dtype] || ["broad_scope"]).forEach((sec) => set.add(sec));
    });
    return PR_SECTION_DEFS.map((d) => d.key).filter((k) => set.has(k));
  }

  function extractPrSectionText(sec) {
    if (!sec || typeof sec !== "object") return "";
    if (Array.isArray(sec.paragraphs) && sec.paragraphs.length) {
      return sec.paragraphs
        .map((p) => {
          if (typeof p === "string") return p;
          if (!p || typeof p !== "object") return "";
          if (Array.isArray(p.content)) {
            return p.content
              .map((u) => (typeof u === "string" ? u : (u && (u.content || u.text)) || ""))
              .filter(Boolean)
              .join(" ");
          }
          return String(p.content || p.text || "");
        })
        .filter(Boolean)
        .join("\n\n");
    }
    if (Array.isArray(sec.historical_reviews) && sec.historical_reviews.length) {
      return sec.historical_reviews
        .map((rev) => {
          if (!rev || typeof rev !== "object") return "";
          const head = `Historical Review ${rev.historical_review_id || ""}${rev.review_title ? ` — ${rev.review_title}` : ""}`.trim();
          const areas = Array.isArray(rev.assessments)
            ? rev.assessments
                .map((a) => `${a.assessed_area || "Area"}: ${a.key_observation || ""} | ${a.implication_for_current_review || ""}`)
                .join("\n")
            : "";
          return areas ? `${head}\n${areas}` : head;
        })
        .filter(Boolean)
        .join("\n\n");
    }
    return "";
  }

  function buildChatResearchSectionsPayload() {
    const report = getPrAnalysisReport();
    if (!report || typeof report !== "object" || Array.isArray(report)) return null;
    const out = {};
    PR_SECTION_DEFS.forEach((d) => {
      const sec = report[d.title];
      if (!sec || typeof sec !== "object") return;
      const text = extractPrSectionText(sec).trim();
      if (text) out[d.title] = text;
    });
    return Object.keys(out).length ? out : null;
  }

  function buildWorkflowCard(workflow, errorInfo = null) {
    const stage = String(workflow.stage || "").toLowerCase();
    const wfStatus = String(workflow.status || "").toLowerCase();
    const execStatus = String((workflow.execution && workflow.execution.status) || "").toLowerCase();
    const isError = Boolean(
      errorInfo ||
        stage === "error" ||
        stage === "partial_failure" ||
        wfStatus === "error" ||
        wfStatus === "partial_failure" ||
        execStatus === "error" ||
        execStatus === "partial_failure" ||
        (workflow.execution && workflow.execution.registry_updated === false)
    );
    const needsApproval =
      !isError &&
      (stage === "awaiting_approval" ||
        stage === "pending_approval" ||
        (Boolean(workflow.requires_approval) &&
          stage !== "executed" &&
          stage !== "cancelled" &&
          stage !== "rejected"));
    const card = document.createElement("div");
    card.className = "workflow-card";
    if (isError) card.classList.add("is-error");
    else if (stage === "executed") card.classList.add("is-executed");
    if (stage === "cancelled" || stage === "rejected") card.classList.add("is-cancelled");

    const actions =
      (workflow.plan && Array.isArray(workflow.plan.actions) && workflow.plan.actions) ||
      (Array.isArray(workflow.steps) ? workflow.steps : null) ||
      (workflow.execution && Array.isArray(workflow.execution.executed) && workflow.execution.executed.length
        ? workflow.execution.executed
        : null) ||
      (workflow.execution_json && Array.isArray(workflow.execution_json.actions) ? workflow.execution_json.actions : null) ||
      (Array.isArray(workflow.executed) && workflow.executed.length ? workflow.executed : null) ||
      (Array.isArray(workflow.actions) ? workflow.actions : []);

    const stageLabel = isError
      ? stage === "partial_failure" || wfStatus === "partial_failure"
        ? "Partial Failure"
        : "Execution Failed"
      : needsApproval
      ? "Approval Required"
      : stage === "executed"
      ? "Executed"
      : stage === "cancelled" || stage === "rejected"
      ? "Cancelled"
      : stage || "Workflow";

    const itemsHtml = actions
      .map((act) => {
        const op = String(act.action || "exclude").toLowerCase();
        const opClass = op === "include" || op === "restore" ? "op-include" : "op-exclude";
        const target = act.section_title ? `${act.title} › ${act.section_title}` : act.title || act.filename || "Target";
        const meta = [act.document_type, act.row_primary_key ? `PK ${act.row_primary_key}` : null]
          .filter(Boolean)
          .join(" · ");
        return `
          <div class="workflow-action-item">
            <div>
              <strong>${escapeHtml(target)}</strong>
              ${meta ? `<div style="font-size:11px;color:#64748b;margin-top:2px;">${escapeHtml(meta)}</div>` : ""}
            </div>
            <span class="action-op-pill ${opClass}">${escapeHtml(op)}</span>
          </div>
        `;
      })
      .join("");

    card.innerHTML = `
      <div class="workflow-card-head">
        <span style="font-size:12px;font-weight:700;color:#1e293b;">Document Scope Plan</span>
        <span class="workflow-stage-badge">${escapeHtml(stageLabel)}</span>
      </div>
      ${itemsHtml ? `<div class="workflow-action-list">${itemsHtml}</div>` : ""}
    `;

    if (isError) {
      const btnRow = document.createElement("div");
      btnRow.className = "workflow-card-actions";
      const errBtn = document.createElement("button");
      errBtn.type = "button";
      errBtn.className = "btn btn-error-details btn-xs";
      errBtn.textContent = "View Error Details";
      errBtn.addEventListener("click", () => {
        showErrorModal(
          errorInfo ||
            normalizeErrorPayload(null, { document_workflow: workflow, error: workflow.message || stageLabel }, "query_chat", "/api/ct1/query/chat")
        );
      });
      btnRow.appendChild(errBtn);
      card.appendChild(btnRow);
    } else if (needsApproval) {
      const btnRow = document.createElement("div");
      btnRow.className = "workflow-card-actions";

      const approveBtn = document.createElement("button");
      approveBtn.type = "button";
      approveBtn.className = "btn btn-approve btn-xs";
      approveBtn.textContent = "Approve & Execute";

      const rejectBtn = document.createElement("button");
      rejectBtn.type = "button";
      rejectBtn.className = "btn btn-reject btn-xs";
      rejectBtn.textContent = "Cancel Plan";

      approveBtn.addEventListener("click", () => {
        approveBtn.disabled = true;
        rejectBtn.disabled = true;
        sendChatTurn("approve", { mode: "add_remove" });
      });
      rejectBtn.addEventListener("click", () => {
        approveBtn.disabled = true;
        rejectBtn.disabled = true;
        sendChatTurn("cancel", { mode: "add_remove" });
      });

      btnRow.appendChild(approveBtn);
      btnRow.appendChild(rejectBtn);
      card.appendChild(btnRow);
    } else if (stage === "executed") {
      const affected = deriveAffectedSectionsFromExecList(actions, workflow);
      if (affected.length) {
        const pill = document.createElement("div");
        pill.className = "affected-pill";
        pill.textContent = `Affected PR sections: ${affected.join(", ")}`;
        card.appendChild(pill);

        const btnRow = document.createElement("div");
        btnRow.className = "workflow-card-actions";
        const regenBtn = document.createElement("button");
        regenBtn.type = "button";
        regenBtn.className = "btn btn-subtle btn-xs";
        regenBtn.textContent = "Regen Affected PR Sections";
        regenBtn.addEventListener("click", () => {
          generatePreliminaryResearch(affected, "Re-run from workflow card");
        });
        btnRow.appendChild(regenBtn);
        card.appendChild(btnRow);
      }
    }

    return card;
  }

  function switchChatMode(mode) {
    const resolved = mode === "qa" ? "qa" : "add_remove";
    state.chatMode = resolved;
    const isWorkflow = resolved === "add_remove";

    if (els.chatModeAddRemove) {
      els.chatModeAddRemove.classList.toggle("is-active", isWorkflow);
      els.chatModeAddRemove.setAttribute("aria-selected", String(isWorkflow));
    }
    if (els.chatModeQa) {
      els.chatModeQa.classList.toggle("is-active", !isWorkflow);
      els.chatModeQa.setAttribute("aria-selected", String(!isWorkflow));
    }
    if (els.chatPaneCaption) {
      els.chatPaneCaption.innerHTML = isWorkflow
        ? "Include or exclude files &amp; sections with <code>@</code> mentions via live CT1 <code>/qna/documents/add-remove</code>"
        : "Ask scoping &amp; preliminary research questions via live CT1 <code>/qna/chat</code> (read-only Q&amp;A)";
    }
    if (els.chatInput) {
      els.chatInput.placeholder = isWorkflow
        ? "Type @ to pick any doc, section, finding, or LRR mandate to exclude/restore — or reply approve/cancel..."
        : "Ask a Q&A question about this plan's policies, findings, historical reviews, or Preliminary Research...";
    }
    if (els.quickPrompts) {
      els.quickPrompts.querySelectorAll(".prompt-chip").forEach((chip) => {
        const modes = (chip.dataset.modes || "").split(",").map((s) => s.trim()).filter(Boolean);
        chip.hidden = modes.length > 0 && !modes.includes(resolved);
      });
    }
  }

  async function sendChatTurn(questionText, options = {}) {
    const trimmed = questionText.trim();
    if (!trimmed || state.isBusy) return;

    const mode = options.mode === "qa" || options.mode === "add_remove" ? options.mode : state.chatMode;
    const isWorkflowMode = mode === "add_remove";

    closeMentionPopover();
    appendChatMessage({ role: "user", text: trimmed, mode });
    els.chatInput.value = "";
    autoResizeTextarea();

    state.isBusy = true;
    els.sendBtn.disabled = true;
    setStatus(
      "loading",
      isWorkflowMode ? "Waiting for Document Add/Remove Workflow..." : "Waiting for Query Agent Q&A response..."
    );

    const endpoint = isWorkflowMode ? "/api/ct1/query/add-remove" : "/api/ct1/query/chat";
    const operation = isWorkflowMode ? "query_add_remove" : "query_chat";
    try {
      const chatBody = isWorkflowMode
        ? {
            user_text: trimmed,
            plan_number: state.planNumber,
            context_type: "Preliminary Research Walkthrough",
            userDetails: buildUserDetails(),
          }
        : {
            question: trimmed,
            plan_number: state.planNumber,
            context_type: "Preliminary Research Walkthrough",
            userDetails: buildUserDetails(),
          };

      if (!isWorkflowMode) {
        const prSummary = buildChatResearchSectionsPayload();
        if (prSummary && typeof prSummary === "object" && !Array.isArray(prSummary) && Object.keys(prSummary).length > 0) {
          chatBody.research_sections = prSummary;
        }
      }

      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(chatBody),
      });
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, operation, endpoint);
        appendChatMessage({
          role: "assistant",
          text: `Error: ${errInfo.message}`,
          errorInfo: errInfo,
          mode,
        });
        setStatus("error", `Query error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }

      const wf = data.document_workflow || null;
      const stage = wf && String(wf.stage || data.stage || "").toLowerCase();
      const wfStatus = wf && String(wf.status || "").toLowerCase();
      const execStatus = wf && wf.execution && String(wf.execution.status || "").toLowerCase();
      const hasWfError = Boolean(
        data.error_details ||
          stage === "error" ||
          stage === "partial_failure" ||
          wfStatus === "error" ||
          wfStatus === "partial_failure" ||
          execStatus === "error" ||
          execStatus === "partial_failure" ||
          (wf && wf.execution && wf.execution.registry_updated === false)
      );

      if (hasWfError) {
        const errInfo = normalizeErrorPayload(resp, data, operation, endpoint);
        appendChatMessage({
          role: "assistant",
          text: data.answer || errInfo.message,
          workflow: wf,
          errorInfo: errInfo,
          mode,
        });
        if (stage === "partial_failure" || wfStatus === "partial_failure") {
          await refreshPlanData(state.planNumber, { animate: true, silentBanner: true });
        }
        setStatus("error", `Execution error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }

      appendChatMessage({
        role: "assistant",
        text: data.answer || "(No answer text returned)",
        workflow: wf,
        mode,
      });

      if (stage === "executed" || (wf && wf.execution_result)) {
        const execList =
          wf.executed ||
          (wf.execution && wf.execution.executed) ||
          (wf.execution_json && wf.execution_json.actions) ||
          wf.actions ||
          wf.steps ||
          (wf.plan && wf.plan.actions) ||
          [];
        const targetTabs = execList
          .map((a) => DOC_TYPE_TO_ARTIFACT[String(a.document_type || "").toLowerCase()])
          .filter(Boolean);
        if (targetTabs.length && !targetTabs.includes(state.activeArtifact)) {
          state.activeArtifact = targetTabs[0];
        }
        await refreshPlanData(state.planNumber, { animate: true, silentBanner: true });

        const affectedSections = deriveAffectedSectionsFromExecList(execList, wf);
        if (affectedSections.length) {
          const mergedStale = new Set([...state.prStaleSections, ...affectedSections]);
          state.prStaleSections = PR_SECTION_DEFS.map((d) => d.key).filter((k) => mergedStale.has(k));
          const summaryItem = execList[0];
          const opWord = summaryItem && summaryItem.action ? String(summaryItem.action) : "updated";
          const targetWord =
            summaryItem && (summaryItem.section_title || summaryItem.title || summaryItem.filename)
              ? `${opWord} ${summaryItem.section_title || summaryItem.title || summaryItem.filename}`
              : `${execList.length || 1} scope change(s)`;
          state.prLastChangeSummary = `Scope updated (${targetWord})`;
          renderPrSectionTabs();
          renderPrReport();

          if (state.prAutoRegen) {
            await generatePreliminaryResearch(affectedSections, targetWord);
          } else {
            setStatus("ok", `Scope updated (${targetWord}). Click Regenerate Affected Sections in Preliminary Research.`);
          }
        } else {
          setStatus("ok", null);
        }
      } else {
        setStatus("ok", null);
      }
    } catch (err) {
      const errInfo = normalizeErrorPayload(
        null,
        { error: err.message, exception_type: err.name || "Error", endpoint },
        operation,
        endpoint
      );
      appendChatMessage({
        role: "assistant",
        text: `Unable to complete request: ${err.message}`,
        errorInfo: errInfo,
        mode,
      });
      setStatus("error", `Query error: ${err.message}`);
      showErrorModal(errInfo);
    } finally {
      state.isBusy = false;
      els.sendBtn.disabled = false;
      els.chatInput.focus();
    }
  }

  // Predictive @ Autocomplete Engine
  function findActiveAtTrigger() {
    const val = els.chatInput.value;
    const pos = els.chatInput.selectionStart ?? val.length;
    const before = val.slice(0, pos);
    const lastAt = before.lastIndexOf("@");
    if (lastAt === -1) return null;
    if (lastAt > 0 && !/[\s(]/.test(before[lastAt - 1])) return null;
    const fragment = before.slice(lastAt + 1);
    if (fragment.includes("]") || fragment.includes("\n")) return null;
    return { start: lastAt, end: pos, query: fragment.trim().toLowerCase() };
  }

  const MENTION_FILTER_DEFS = [
    { key: "all", label: "All" },
    { key: "policy", label: "Policies" },
    { key: "kod", label: "KOD" },
    { key: "procedure", label: "Procedures" },
    { key: "gfms", label: "GFMS" },
    { key: "historical_scoping_document", label: "Historical" },
    { key: "lrr", label: "LRR" },
  ];

  function renderMentionFilters(queryMatches) {
    if (!els.mentionFilters) return;
    const counts = { all: queryMatches.length };
    queryMatches.forEach((item) => {
      counts[item.docType] = (counts[item.docType] || 0) + 1;
    });

    els.mentionFilters.innerHTML = "";
    MENTION_FILTER_DEFS.forEach((def) => {
      const count = counts[def.key] || 0;
      if (def.key !== "all" && count === 0 && state.mentionFilter !== def.key) return;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `mention-filter-pill${state.mentionFilter === def.key ? " is-active" : ""}`;
      btn.innerHTML = `<span>${escapeHtml(def.label)}</span><span class="mention-filter-count">${count}</span>`;
      btn.addEventListener("mousedown", (e) => {
        e.preventDefault();
        if (state.mentionFilter === def.key) return;
        state.mentionFilter = def.key;
        const anchor = state.mentionAnchorStart >= 0 ? state.mentionAnchorStart : 0;
        openMentionPopover(state.mentionLastQuery, anchor);
      });
      els.mentionFilters.appendChild(btn);
    });
  }

  function renderMentionList() {
    els.mentionList.innerHTML = "";
    if (els.mentionMatchCount) {
      els.mentionMatchCount.textContent = `${state.filteredMentions.length} of ${state.mentionItems.length} item(s)`;
    }
    if (state.filteredMentions.length === 0) {
      els.mentionList.innerHTML = `<div style="padding:14px;font-size:12px;color:#64748b;text-align:center;">No matching documents or sections in Plan ${escapeHtml(state.planNumber)}.</div>`;
      return;
    }

    const frag = document.createDocumentFragment();
    state.filteredMentions.forEach((item, idx) => {
      const row = document.createElement("div");
      row.className = `mention-item${item.isSection ? " is-section" : " is-doc"}${idx === state.mentionIndex ? " is-selected" : ""}`;
      row.setAttribute("role", "option");
      row.innerHTML = `
        <div class="mention-main">
          <div class="mention-title">${item.isSection ? '<span class="mention-sec-prefix">§</span> ' : ""}${escapeHtml(item.title)}</div>
          <div class="mention-sub">${escapeHtml(item.subtitle)}</div>
        </div>
        <div class="mention-badges">
          <span class="pill-type">${escapeHtml(item.groupLabel)}</span>
          <span class="${item.excluded ? "pill-status-excluded" : "pill-status-active"}">${item.excluded ? "EXCLUDED" : "ACTIVE"}</span>
        </div>
      `;
      row.addEventListener("mouseenter", () => {
        state.mentionIndex = idx;
        highlightMentionSelection();
      });
      row.addEventListener("mousedown", (e) => {
        e.preventDefault();
        insertMention(item);
      });
      frag.appendChild(row);
    });
    els.mentionList.appendChild(frag);
  }

  function highlightMentionSelection() {
    const children = els.mentionList.querySelectorAll(".mention-item");
    children.forEach((el, idx) => {
      el.classList.toggle("is-selected", idx === state.mentionIndex);
      if (idx === state.mentionIndex) {
        el.scrollIntoView({ block: "nearest" });
      }
    });
  }

  function openMentionPopover(query, anchorStart) {
    state.mentionAnchorStart = anchorStart;
    state.mentionLastQuery = String(query || "");
    const textBefore = els.chatInput.value.slice(0, Math.max(0, anchorStart)).toLowerCase();
    const preferExcluded = /\b(include|restore|re-include|add back|reinstate)\b/.test(textBefore);

    const queryMatches = state.mentionItems.filter((item) => !query || item.searchBlob.includes(query));
    renderMentionFilters(queryMatches);

    const matches =
      state.mentionFilter === "all"
        ? [...queryMatches]
        : queryMatches.filter((item) => item.docType === state.mentionFilter);

    matches.sort((a, b) => {
      if (preferExcluded && a.excluded !== b.excluded) return a.excluded ? -1 : 1;
      if (!preferExcluded && a.excluded !== b.excluded) return a.excluded ? 1 : -1;
      if (!query && Boolean(a.isSection) !== Boolean(b.isSection)) {
        return a.isSection ? 1 : -1;
      }
      return 0;
    });

    state.filteredMentions = matches;
    state.mentionIndex = 0;
    state.mentionOpen = true;
    renderMentionList();
    els.mentionPopover.classList.add("is-open");
  }

  function closeMentionPopover() {
    state.mentionOpen = false;
    state.mentionAnchorStart = -1;
    els.mentionPopover.classList.remove("is-open");
  }

  function insertMention(item) {
    const val = els.chatInput.value;
    const pos = els.chatInput.selectionStart ?? val.length;
    const start = state.mentionAnchorStart >= 0 ? state.mentionAnchorStart : pos;
    const before = val.slice(0, start);
    const after = val.slice(pos);
    const token = `${item.mentionText} `;
    els.chatInput.value = `${before}${token}${after}`;
    const nextPos = before.length + token.length;
    els.chatInput.setSelectionRange(nextPos, nextPos);
    closeMentionPopover();
    autoResizeTextarea();
    els.chatInput.focus();
  }

  function autoResizeTextarea() {
    els.chatInput.style.height = "auto";
    els.chatInput.style.height = `${Math.min(els.chatInput.scrollHeight, 140)}px`;
  }

  async function triggerDataExtractionRun() {
    els.runExtractionBtn.disabled = true;
    setStatus("loading", `Starting CT1 data extraction for Plan ${state.planNumber}...`);
    const runEndpoint = "/api/ct1/dataextraction/run";
    try {
      const resp = await fetch(runEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planNumber: state.planNumber, userDetails: buildUserDetails() }),
      });
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "dataextraction_run", runEndpoint);
        els.runExtractionBtn.disabled = false;
        setStatus("error", `Extraction launch error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }

      const sessionId = data.session_id;
      if (!sessionId) {
        els.runExtractionBtn.disabled = false;
        await refreshPlanData(state.planNumber, { animate: true });
        return;
      }

      if (state.pollTimer) window.clearInterval(state.pollTimer);
      state.pollTimer = window.setInterval(async () => {
        const statusEndpoint = `/api/ct1/dataextraction/status/${encodeURIComponent(sessionId)}`;
        try {
          const stResp = await fetch(statusEndpoint);
          const { parsed: st } = await readResponsePayload(stResp);
          if (!stResp.ok) {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            const errInfo = normalizeErrorPayload(stResp, st, "dataextraction_status", statusEndpoint);
            setStatus("error", `Extraction status error: ${errInfo.message}`);
            showErrorModal(errInfo);
            return;
          }
          const curStatus = String((st && st.status) || "").toLowerCase();
          setStatus("loading", `CT1 Extraction (${(st && st.stage_name) || "running"}): ${curStatus || "in progress"}...`);

          if (curStatus === "completed" || curStatus === "done" || curStatus === "success") {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            await refreshPlanData(state.planNumber, { animate: true });
            if (getPrAnalysisReport()) {
              state.prStaleSections = PR_SECTION_DEFS.map((d) => d.key);
              state.prLastChangeSummary = "Fresh Data Extraction completed";
              state.prAccepted = false;
              renderPrSectionTabs();
              renderPrReport();
            }
          } else if (curStatus === "failed" || curStatus === "error") {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            const errInfo = normalizeErrorPayload(stResp, st, "dataextraction_status", statusEndpoint);
            errInfo.message = `Extraction failed: ${(st && (st.error || st.message)) || errInfo.message}`;
            setStatus("error", errInfo.message);
            showErrorModal(errInfo);
          }
        } catch (err) {
          window.clearInterval(state.pollTimer);
          state.pollTimer = null;
          els.runExtractionBtn.disabled = false;
          const errInfo = normalizeErrorPayload(
            null,
            { error: err.message, exception_type: err.name || "Error", endpoint: statusEndpoint },
            "dataextraction_status",
            statusEndpoint
          );
          setStatus("error", `Status poll error: ${err.message}`);
          showErrorModal(errInfo);
        }
      }, 2500);
    } catch (err) {
      els.runExtractionBtn.disabled = false;
      const errInfo = normalizeErrorPayload(
        null,
        { error: err.message, exception_type: err.name || "Error", endpoint: runEndpoint },
        "dataextraction_run",
        runEndpoint
      );
      setStatus("error", `Extraction launch error: ${err.message}`);
      showErrorModal(errInfo);
    }
  }

  function wireEvents() {
    els.planForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const nextPlan = els.planInput.value.trim();
      if (!nextPlan) return;
      if (nextPlan !== state.planNumber && !state.scopeExplicit) {
        state.scopeResolved = {};
        state.scopeSource = "";
        clearScopeInputs();
      }
      state.prevCounts = {};
      state.prevArtifactKeys = {};
      await refreshPlanData(nextPlan, { animate: false });
    });

    els.refreshBtn.addEventListener("click", () => {
      refreshPlanData(state.planNumber, { animate: true });
    });

    els.runExtractionBtn.addEventListener("click", triggerDataExtractionRun);

    els.composerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      sendChatTurn(els.chatInput.value);
    });

    els.chatInput.addEventListener("input", () => {
      autoResizeTextarea();
      const trigger = findActiveAtTrigger();
      if (trigger) {
        openMentionPopover(trigger.query, trigger.start);
      } else {
        closeMentionPopover();
      }
    });

    els.chatInput.addEventListener("keydown", (e) => {
      if (state.mentionOpen) {
        if (e.key === "ArrowDown") {
          e.preventDefault();
          state.mentionIndex = (state.mentionIndex + 1) % Math.max(1, state.filteredMentions.length);
          highlightMentionSelection();
          return;
        }
        if (e.key === "ArrowUp") {
          e.preventDefault();
          const len = Math.max(1, state.filteredMentions.length);
          state.mentionIndex = (state.mentionIndex - 1 + len) % len;
          highlightMentionSelection();
          return;
        }
        if (e.key === "Enter" || e.key === "Tab") {
          if (state.filteredMentions[state.mentionIndex]) {
            e.preventDefault();
            insertMention(state.filteredMentions[state.mentionIndex]);
            return;
          }
        }
        if (e.key === "Escape") {
          e.preventDefault();
          closeMentionPopover();
          return;
        }
      }

      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendChatTurn(els.chatInput.value);
      }
    });

    els.triggerAtBtn.addEventListener("click", () => {
      const pos = els.chatInput.selectionStart ?? els.chatInput.value.length;
      const before = els.chatInput.value.slice(0, pos);
      const after = els.chatInput.value.slice(pos);
      const needsSpace = before.length > 0 && !/\s$/.test(before);
      const prefix = needsSpace ? " @" : "@";
      els.chatInput.value = `${before}${prefix}${after}`;
      const newPos = before.length + prefix.length;
      els.chatInput.setSelectionRange(newPos, newPos);
      openMentionPopover("", newPos - 1);
      els.chatInput.focus();
    });

    els.quickPrompts.querySelectorAll(".prompt-chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        const tmpl = chip.dataset.template || "";
        els.chatInput.value = tmpl;
        autoResizeTextarea();
        els.chatInput.focus();
        if (tmpl.endsWith(" ")) {
          const pos = tmpl.length;
          els.chatInput.value = `${tmpl}@`;
          els.chatInput.setSelectionRange(pos + 1, pos + 1);
          openMentionPopover("", pos);
        }
      });
    });

    els.attachBtn.addEventListener("click", () => els.fileInput.click());
    els.fileInput.addEventListener("change", () => {
      const files = Array.from(els.fileInput.files || []);
      if (files.length === 0) return;
      els.ingestFileNames.textContent = files.map((f) => f.name).join(", ");
      els.ingestDrawer.classList.add("is-open");
    });

    els.ingestCancelBtn.addEventListener("click", () => {
      els.fileInput.value = "";
      els.ingestDrawer.classList.remove("is-open");
    });

    els.ingestSubmitBtn.addEventListener("click", async () => {
      const files = Array.from(els.fileInput.files || []);
      if (!files.length) return;
      const form = new FormData();
      form.append("plan_number", state.planNumber);
      form.append("document_type", els.ingestDocType.value);
      const scopeDetails = buildUserDetails();
      SCOPE_FIELDS.forEach((key) => {
        if (scopeDetails[key]) form.append(key, scopeDetails[key]);
      });
      files.forEach((f) => form.append("files", f));

      els.ingestSubmitBtn.disabled = true;
      setStatus("loading", `Uploading ${files.length} file(s) through the API Gateway...`);
      const ingestEndpoint = "/api/ct1/query/ingest";
      try {
        const resp = await fetch(ingestEndpoint, { method: "POST", body: form });
        const { parsed: data } = await readResponsePayload(resp);
        if (!resp.ok) {
          const errInfo = normalizeErrorPayload(resp, data, "rag_ingest_documents", ingestEndpoint);
          setStatus("error", `Ingest error: ${errInfo.message}`);
          showErrorModal(errInfo);
          return;
        }

        const docsSummary = Array.isArray(data.documents)
          ? data.documents
              .map((d) => `${d.document_title || d.file_name} (${d.document_type || "policy"}, ${d.section_count || 1} section(s))`)
              .join("; ")
          : (data.files_uploaded || []).join(", ");
        const idsText =
          Array.isArray(data.document_ids) && data.document_ids.length
            ? ` · doc_ids=[${data.document_ids.join(", ")}]`
            : "";

        appendChatMessage({
          role: "assistant",
          text:
            `Document ingest complete (${data.status}, job_id=${data.job_id || "n/a"}${idsText}).\n` +
            `Stored in: Policies / KOD / Proc (${docsSummary || data.document_type || "policy"}).\n` +
            `${data.message || ""} Tip: type @ in the composer to reference or exclude the indexed document or sections.`,
        });
        els.fileInput.value = "";
        els.ingestDrawer.classList.remove("is-open");
        state.activeArtifact = data.stored_in_artifact || "policy";
        await refreshPlanData(state.planNumber, { animate: true });

        const uploadedAffected = ["policy_regulation", "broad_scope"];
        state.prStaleSections = PR_SECTION_DEFS.map((d) => d.key).filter(
          (k) => state.prStaleSections.includes(k) || uploadedAffected.includes(k)
        );
        state.prLastChangeSummary = "New document ingested through the API Gateway";
        renderPrSectionTabs();
        renderPrReport();
        if (state.prAutoRegen) {
          await generatePreliminaryResearch(uploadedAffected, "New document uploaded");
        }
      } catch (err) {
        const errInfo = normalizeErrorPayload(
          null,
          { error: err.message, exception_type: err.name || "Error", endpoint: ingestEndpoint },
          "rag_ingest_documents",
          ingestEndpoint
        );
        setStatus("error", `Ingest error: ${err.message}`);
        showErrorModal(errInfo);
      } finally {
        els.ingestSubmitBtn.disabled = false;
      }
    });

    if (els.chatModeAddRemove) {
      els.chatModeAddRemove.addEventListener("click", () => switchChatMode("add_remove"));
    }
    if (els.chatModeQa) {
      els.chatModeQa.addEventListener("click", () => switchChatMode("qa"));
    }
    if (els.rightTabPr) {
      els.rightTabPr.addEventListener("click", () => switchRightTab("pr"));
    }
    if (els.rightTabFeeds) {
      els.rightTabFeeds.addEventListener("click", () => switchRightTab("feeds"));
    }
    if (els.stepExtraction) {
      els.stepExtraction.addEventListener("click", () => switchRightTab("feeds"));
    }
    if (els.stepCuration) {
      els.stepCuration.addEventListener("click", () => {
        switchChatMode("add_remove");
        if (els.triggerAtBtn) els.triggerAtBtn.click();
      });
    }
    if (els.stepPr) {
      els.stepPr.addEventListener("click", () => switchRightTab("pr"));
    }
    if (els.stepAccept) {
      els.stepAccept.addEventListener("click", () => switchRightTab("pr"));
    }

    if (els.prGenerateAllBtn) {
      els.prGenerateAllBtn.addEventListener("click", () => {
        generatePreliminaryResearch(null, "Full generation");
      });
    }
    if (els.prRegenSelectedBtn) {
      els.prRegenSelectedBtn.addEventListener("click", () => {
        const selected = Array.from(document.querySelectorAll(".pr-section-check"))
          .filter((cb) => cb.checked)
          .map((cb) => cb.value);
        if (!selected.length) {
          setStatus("error", "Select at least one Preliminary Research section to regenerate.");
          return;
        }
        generatePreliminaryResearch(selected, "Selected sections");
      });
    }
    if (els.prAutoRegenCheckbox) {
      els.prAutoRegenCheckbox.checked = state.prAutoRegen;
      els.prAutoRegenCheckbox.addEventListener("change", () => {
        state.prAutoRegen = Boolean(els.prAutoRegenCheckbox.checked);
      });
    }
    if (els.prReloadBtn) {
      els.prReloadBtn.addEventListener("click", () => reloadPreliminaryResearch());
    }
    if (els.prEditBtn) {
      els.prEditBtn.addEventListener("click", () => {
        if (state.prEditMode) cancelPrEdit();
        else openPrEditor();
      });
    }
    if (els.prSaveEditBtn) {
      els.prSaveEditBtn.addEventListener("click", savePrEdits);
    }
    if (els.prCancelEditBtn) {
      els.prCancelEditBtn.addEventListener("click", cancelPrEdit);
    }
    if (els.prDownloadBtn) {
      els.prDownloadBtn.addEventListener("click", downloadPreliminaryResearchPdf);
    }
    if (els.prAcceptBtn) {
      els.prAcceptBtn.addEventListener("click", acceptPreliminaryResearch);
    }
    if (els.prRegenAffectedBtn) {
      els.prRegenAffectedBtn.addEventListener("click", () => {
        const targets = state.prStaleSections.length ? [...state.prStaleSections] : null;
        generatePreliminaryResearch(targets, state.prLastChangeSummary || "Affected sections");
      });
    }
    if (els.prStructuredContainer) {
      els.prStructuredContainer.addEventListener("click", (e) => {
        const chip = e.target.closest(".citation-chip");
        if (chip) {
          e.preventDefault();
          openCitationPreview(chip.dataset);
        }
      });
    }

    if (els.citationModalCloseBtn) els.citationModalCloseBtn.addEventListener("click", closeCitationModal);
    if (els.citationModalDismissBtn) els.citationModalDismissBtn.addEventListener("click", closeCitationModal);
    if (els.citationModalBackdrop) {
      els.citationModalBackdrop.addEventListener("click", (e) => {
        if (e.target === els.citationModalBackdrop) closeCitationModal();
      });
    }

    document.querySelectorAll(".seg-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const mode = btn.dataset.view || "cards";
        state.viewMode = mode;
        document.querySelectorAll(".seg-btn").forEach((b) => {
          const active = b.dataset.view === mode;
          b.classList.toggle("is-active", active);
          b.setAttribute("aria-selected", String(active));
        });
        els.segmented.classList.toggle("is-json", mode === "json");
        els.feedViewport.classList.toggle("is-json-mode", mode === "json");
        if (els.prViewport) els.prViewport.classList.toggle("is-json-mode", mode === "json");
      });
    });

    if (els.errorModalCloseBtn) els.errorModalCloseBtn.addEventListener("click", closeErrorModal);
    if (els.errorModalDismissBtn) els.errorModalDismissBtn.addEventListener("click", closeErrorModal);
    if (els.errorModalBackdrop) {
      els.errorModalBackdrop.addEventListener("click", (e) => {
        if (e.target === els.errorModalBackdrop) closeErrorModal();
      });
    }
    if (els.errorModalCopyBtn) {
      els.errorModalCopyBtn.addEventListener("click", async () => {
        const txt = els.errorModalDetailsPre ? els.errorModalDetailsPre.textContent : "";
        try {
          await navigator.clipboard.writeText(txt);
          els.errorModalCopyBtn.textContent = "Copied!";
          window.setTimeout(() => {
            els.errorModalCopyBtn.textContent = "Copy Full Error JSON";
          }, 1500);
        } catch (_) {
          // Ignore clipboard permission errors in non-HTTPS contexts
        }
      });
    }
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        if (els.citationModalBackdrop && !els.citationModalBackdrop.hidden) {
          closeCitationModal();
        } else if (els.errorModalBackdrop && !els.errorModalBackdrop.hidden) {
          closeErrorModal();
        }
      }
    });

    document.addEventListener("click", (e) => {
      if (state.mentionOpen && !e.target.closest(".composer-dock")) {
        closeMentionPopover();
      }
    });
  }

  function wireScopeEvents() {
    const inputs = [els.processInstanceInput, els.taskIdInput, els.reviewScopeIdInput].filter(Boolean);
    inputs.forEach((input) => {
      input.addEventListener("input", updateScopeFromInputs);
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          updateScopeFromInputs();
          refreshPlanData(state.planNumber, { animate: true });
        }
      });
    });

    if (els.scopeApplyBtn) {
      els.scopeApplyBtn.addEventListener("click", () => {
        updateScopeFromInputs();
        refreshPlanData(state.planNumber, { animate: true });
      });
    }

    if (els.scopeClearBtn) {
      els.scopeClearBtn.addEventListener("click", () => {
        clearScopeInputs();
        refreshPlanData(state.planNumber, { animate: true });
      });
    }

    renderScopeState();
  }

  async function init() {
    wireEvents();
    wireScopeEvents();
    switchChatMode("add_remove");
    switchRightTab("pr");
    renderPrSectionTabs();
    renderPrReport();
    appendChatMessage({
      role: "assistant",
      isWelcome: true,
      text: "Connected to CT1 Scoping & Preliminary Research endpoints. Use the mode tabs above to switch between Include / Exclude (/qna/documents/add-remove) for @-mention curation and Q&A Chat (/qna/chat) for read-only scoping questions. Approved scope changes immediately refresh Data Extraction feeds and auto-regenerate affected Preliminary Research sections on the right.",
    });

    try {
      const cfgResp = await fetch("/api/config");
      const { parsed: cfg } = await readResponsePayload(cfgResp);
      if (cfgResp.ok && cfg && typeof cfg === "object") {
        state.ctaHost = cfg.cta_host || "";
        state.planNumber = cfg.default_plan_number || "20440";
        if (Array.isArray(cfg.artifacts) && cfg.artifacts.length) {
          state.artifactDefs = cfg.artifacts;
        }
        els.planInput.value = state.planNumber;
        els.ct1HostBadge.textContent = `${state.ctaHost} · Plan ${state.planNumber}`;
      } else {
        const errInfo = normalizeErrorPayload(cfgResp, cfg, "config", "/api/config");
        setStatus("error", `Config load failed: ${errInfo.message}`);
        showErrorModal(errInfo);
      }
    } catch (err) {
      const errInfo = normalizeErrorPayload(null, { error: err.message }, "config", "/api/config");
      setStatus("error", `Config load failed: ${err.message}`);
      showErrorModal(errInfo);
    }

    await refreshPlanData(state.planNumber, { animate: false });
  }

  init();
})();
