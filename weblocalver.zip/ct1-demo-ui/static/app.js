(() => {
  "use strict";

  const GROUP_LABEL_MAP = {
    policy: "Policies",
    kod: "KOD",
    procedure: "Procedures",
    gfms: "GFMS Data",
    historical_scoping_document: "Historical Scoping",
    lrr: "LRR Mandates",
  };

  const DEFAULT_ARTIFACTS = [
    { id: "policy", label: "Policies / KOD / Proc", excludable: "true" },
    { id: "findings_details", label: "GFMS Findings", excludable: "true" },
    { id: "historical_plan_details", label: "Historical Plans", excludable: "true" },
    { id: "lrr", label: "LRR Mandates", excludable: "true" },
    { id: "current_details", label: "Current Plan", excludable: "false" },
    { id: "alc_nlac", label: "ALC / NALC", excludable: "false" },
    { id: "control_details", label: "Controls", excludable: "false" },
    { id: "risk_driver_details", label: "Risk Drivers", excludable: "false" },
    { id: "group_audit", label: "Group Audit", excludable: "false" },
  ];

  const state = {
    planNumber: "20440",
    ctaHost: "",
    artifactDefs: [...DEFAULT_ARTIFACTS],
    activeArtifact: "policy",
    viewMode: "cards", // "cards" | "json"
    catalog: null,
    availability: null,
    artifacts: {},
    errors: {},
    prevCounts: {},
    prevArtifactKeys: {},
    mentionItems: [],
    filteredMentions: [],
    mentionOpen: false,
    mentionIndex: 0,
    mentionAnchorStart: -1,
    isBusy: false,
    pollTimer: null,
  };

  const els = {
    ct1StatusDot: document.getElementById("ct1StatusDot"),
    ct1HostBadge: document.getElementById("ct1HostBadge"),
    planForm: document.getElementById("planForm"),
    planInput: document.getElementById("planInput"),
    loadPlanBtn: document.getElementById("loadPlanBtn"),
    refreshBtn: document.getElementById("refreshBtn"),
    runExtractionBtn: document.getElementById("runExtractionBtn"),
    statusDrawer: document.getElementById("statusDrawer"),
    statusText: document.getElementById("statusText"),
    catalogActiveCount: document.getElementById("catalogActiveCount"),
    catalogExcludedCount: document.getElementById("catalogExcludedCount"),
    chatStream: document.getElementById("chatStream"),
    composerForm: document.getElementById("composerForm"),
    chatInput: document.getElementById("chatInput"),
    sendBtn: document.getElementById("sendBtn"),
    triggerAtBtn: document.getElementById("triggerAtBtn"),
    attachBtn: document.getElementById("attachBtn"),
    fileInput: document.getElementById("fileInput"),
    ingestDrawer: document.getElementById("ingestDrawer"),
    ingestDocType: document.getElementById("ingestDocType"),
    ingestFileNames: document.getElementById("ingestFileNames"),
    ingestSubmitBtn: document.getElementById("ingestSubmitBtn"),
    ingestCancelBtn: document.getElementById("ingestCancelBtn"),
    mentionPopover: document.getElementById("mentionPopover"),
    mentionPlanTag: document.getElementById("mentionPlanTag"),
    mentionList: document.getElementById("mentionList"),
    quickPrompts: document.getElementById("quickPrompts"),
    kpiActiveFeedCount: document.getElementById("kpiActiveFeedCount"),
    kpiExcludedCount: document.getElementById("kpiExcludedCount"),
    kpiFeedCount: document.getElementById("kpiFeedCount"),
    kpiLatency: document.getElementById("kpiLatency"),
    artifactTabs: document.getElementById("artifactTabs"),
    feedViewport: document.getElementById("feedViewport"),
    feedSourceBadge: document.getElementById("feedSourceBadge"),
    feedDescription: document.getElementById("feedDescription"),
    deltaPill: document.getElementById("deltaPill"),
    cardsContainer: document.getElementById("cardsContainer"),
    rawJsonPre: document.getElementById("rawJsonPre"),
    segmented: document.querySelector(".segmented"),
  };

  function setStatus(kind, bannerMessage) {
    els.ct1StatusDot.classList.remove("is-loading", "is-error");
    if (kind === "loading") {
      els.ct1StatusDot.classList.add("is-loading");
    } else if (kind === "error") {
      els.ct1StatusDot.classList.add("is-error");
    }

    if (bannerMessage) {
      els.statusText.textContent = bannerMessage;
      els.statusDrawer.classList.add("is-open");
    } else {
      els.statusDrawer.classList.remove("is-open");
    }
  }

  function escapeHtml(text) {
    return String(text ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function formatRichUserText(text) {
    const escaped = escapeHtml(text);
    return escaped.replace(/(@\[[^\]]+\])/g, '<span class="mention-token">$1</span>');
  }

  function isExcludedStatus(item) {
    if (!item || typeof item !== "object") return false;
    if (item.excluded === true) return true;
    const st = String(item.status || "").trim().toLowerCase();
    return st === "excluded" || st === "removed" || st === "inactive" || st === "deleted";
  }

  function buildMentionCatalog(catalog) {
    const items = [];
    if (!catalog || !Array.isArray(catalog.document_groups)) return items;

    for (const group of catalog.document_groups) {
      const gtype = String(group.document_type || "policy").toLowerCase();
      const glabel = GROUP_LABEL_MAP[gtype] || gtype;
      const docs = Array.isArray(group.documents) ? group.documents : [];

      for (const doc of docs) {
        if (!doc || typeof doc !== "object") continue;
        const title = String(doc.document_title || doc.title || doc.file_name || "Document").trim();
        const fileName = String(doc.file_name || doc.filename || "").trim();
        const docExcluded = isExcludedStatus(doc);

        items.push({
          key: `doc:${gtype}:${doc.document_id || fileName || title}`,
          docType: gtype,
          groupLabel: glabel,
          title,
          subtitle: fileName ? `${glabel} · ${fileName}` : glabel,
          excluded: docExcluded,
          mentionText: `@[${glabel}: ${title}]`,
          searchBlob: `${glabel} ${title} ${fileName}`.toLowerCase(),
        });

        const sections = Array.isArray(doc.sections) ? doc.sections : [];
        for (const sec of sections) {
          if (!sec || typeof sec !== "object") continue;
          const sid = sec.section_id ?? "";
          const stitle = String(sec.section_title || sec.title || `Section ${sid}`).trim();
          const secExcluded = docExcluded || isExcludedStatus(sec);
          const secLabel = sid && !stitle.toLowerCase().includes(String(sid).toLowerCase())
            ? `Section ${sid}: ${stitle}`
            : stitle;

          items.push({
            key: `sec:${gtype}:${doc.document_id || title}:${sid}:${stitle}`,
            docType: gtype,
            groupLabel: glabel,
            title: stitle,
            subtitle: `${glabel} · ${title}${sid ? ` (#${sid})` : ""}`,
            excluded: secExcluded,
            mentionText: `@[${glabel}: ${title} > ${secLabel}]`,
            searchBlob: `${glabel} ${title} ${stitle} ${sid} ${secLabel}`.toLowerCase(),
          });
        }
      }
    }
    return items;
  }

  function updateCatalogSummary(catalog) {
    let active = 0;
    let excluded = 0;
    if (catalog && Array.isArray(catalog.document_groups)) {
      for (const group of catalog.document_groups) {
        for (const doc of group.documents || []) {
          if (isExcludedStatus(doc)) {
            excluded += 1;
          } else {
            active += 1;
          }
          for (const sec of doc.sections || []) {
            if (isExcludedStatus(sec)) excluded += 1;
          }
        }
      }
    }
    els.catalogActiveCount.textContent = String(active);
    els.catalogExcludedCount.textContent = String(excluded);
    els.kpiExcludedCount.textContent = String(excluded);
  }

  function extractArtifactRecords(artifactId, payload) {
    if (payload == null) return [];

    if (artifactId === "policy") {
      const list = Array.isArray(payload)
        ? payload
        : Array.isArray(payload.items)
        ? payload.items
        : Array.isArray(payload.sources)
        ? payload.sources
        : Array.isArray(payload.nodes)
        ? payload.nodes
        : [];
      return list.map((row, idx) => {
        const docName = row.document_name || row.document_title || row.file_name || row.title || `Policy Item ${idx + 1}`;
        const secLabel = row.section_title || row.section_name || row.section_path || (row.page_number ? `Page ${row.page_number}` : "");
        const key = String(row.node_id || `${docName}::${row.section_id || idx}`);
        const body = row.text || row.content || row.chunk_text || row.snippet || row.summary || "";
        return {
          key,
          title: docName,
          tag: secLabel || row.document_type || "RAG Source",
          body: String(body).slice(0, 320),
          meta: [
            row.section_id != null ? ["Section ID", row.section_id] : null,
            row.page_number != null ? ["Page", row.page_number] : null,
            row.similarity_score != null ? ["Score", Number(row.similarity_score).toFixed(3)] : null,
            row.node_id ? ["Node", row.node_id] : null,
          ].filter(Boolean),
        };
      });
    }

    if (artifactId === "findings_details") {
      const rows = [];
      const wrappers = Array.isArray(payload) ? payload : [payload];
      wrappers.forEach((wrapper, wIdx) => {
        const list = wrapper && Array.isArray(wrapper.responsePayload) ? wrapper.responsePayload : [wrapper];
        list.forEach((f, idx) => {
          if (!f || typeof f !== "object") return;
          const fid = f.findingId || f.id || `${wIdx}-${idx}`;
          rows.push({
            key: `gfms:${fid}`,
            title: f.findingTitle || f.title || `Finding ${fid}`,
            tag: f.findingRating || f.severity || `ID ${fid}`,
            body: String(f.findingDescription || f.description || f.issueSummary || "GFMS Finding").slice(0, 320),
            meta: [
              ["Finding ID", fid],
              f.findingStatus ? ["Status", f.findingStatus] : null,
              f.owner ? ["Owner", f.owner] : null,
            ].filter(Boolean),
          });
        });
      });
      return rows;
    }

    if (artifactId === "historical_plan_details") {
      const list = Array.isArray(payload) ? payload : payload.items || payload.plans || [payload];
      return list
        .filter((x) => x && typeof x === "object")
        .map((item, idx) => {
          const pnum = item["Plan Item Number"] || item.plan_item_number || item.planNumber || String(idx + 1);
          const ptitle = item["Plan Item Title"] || item.plan_item_title || item.title || `Historical Plan ${pnum}`;
          return {
            key: `hist:${pnum}`,
            title: ptitle,
            tag: `Plan ${pnum}`,
            body: String(item["Audit Objective"] || item.audit_objective || item.summary || "Historical scoping plan record").slice(0, 320),
            meta: [
              item["Plan Type"] ? ["Type", item["Plan Type"]] : null,
              item["Audit Period"] ? ["Period", item["Audit Period"]] : null,
              item["Legal Entity"] ? ["Entity", item["Legal Entity"]] : null,
            ].filter(Boolean),
          };
        });
    }

    if (artifactId === "lrr") {
      const rows = [];
      const arr = Array.isArray(payload) ? payload : Array.isArray(payload.documents) ? payload.documents : [payload];
      let mandateCounter = 0;
      arr.forEach((entry, idx) => {
        if (!entry || typeof entry !== "object") return;
        if (Array.isArray(entry.Mandates)) {
          const riskName = entry["Risk Name"] || entry.risk_name || `Risk ${idx + 1}`;
          entry.Mandates.forEach((m) => {
            if (!m || typeof m !== "object") return;
            mandateCounter += 1;
            const mtitle = m["Regulatory Mandate"] || m.mandate || m.Citation || `Mandate ${mandateCounter}`;
            rows.push({
              key: String(m.node_id || `lrr:mandate:${mandateCounter}:${mtitle.slice(0, 48)}`),
              title: mtitle,
              tag: riskName,
              body: String(m["Applicability Summary"] || m.summary || m["Source URL"] || "Regulatory mandate").slice(0, 320),
              meta: [
                m.Citation ? ["Citation", m.Citation] : null,
                m.Jurisdiction ? ["Jurisdiction", m.Jurisdiction] : null,
                m.Regulator ? ["Regulator", m.Regulator] : null,
              ].filter(Boolean),
            });
          });
        } else {
          mandateCounter += 1;
          const title = entry["Regulatory Mandate"] || entry.title || entry.document_title || `LRR Entry ${mandateCounter}`;
          rows.push({
            key: String(entry.node_id || `lrr:entry:${mandateCounter}:${title.slice(0, 48)}`),
            title,
            tag: entry["Risk Name"] || entry.document_type || "LRR",
            body: String(entry.summary || entry.Citation || entry.description || "").slice(0, 320),
            meta: [
              entry.Regulator ? ["Regulator", entry.Regulator] : null,
              entry.Citation ? ["Citation", entry.Citation] : null,
            ].filter(Boolean),
          });
        }
      });
      return rows;
    }

    // Generic handler for current_details, alc_nlac, control_details, risk_driver_details, group_audit
    const list = Array.isArray(payload)
      ? payload
      : Array.isArray(payload.responsePayload)
      ? payload.responsePayload
      : Array.isArray(payload.items)
      ? payload.items
      : [payload];

    return list
      .filter((x) => x && typeof x === "object")
      .map((item, idx) => {
        const title =
          item["Plan Item Title"] ||
          item.controlTitle ||
          item.riskDriverName ||
          item.title ||
          item.name ||
          item.document_name ||
          `${artifactId} #${idx + 1}`;
        const body =
          item["Audit Objective"] ||
          item.controlDescription ||
          item.riskDescription ||
          item.description ||
          item.summary ||
          "";
        const pairs = Object.entries(item)
          .filter(([, v]) => v !== null && v !== undefined && typeof v !== "object" && String(v).length < 70)
          .slice(0, 4);
        return {
          key: `${artifactId}:${idx}:${String(title).slice(0, 40)}`,
          title: String(title),
          tag: String(item["Plan Item Number"] || item.controlId || item.id || artifactId),
          body: String(body).slice(0, 320),
          meta: pairs,
        };
      });
  }

  function renderArtifactTabs(deltasByArtifact = {}) {
    els.artifactTabs.innerHTML = "";
    let availableFeeds = 0;

    for (const def of state.artifactDefs) {
      const payload = state.artifacts[def.id];
      const records = payload ? extractArtifactRecords(def.id, payload) : [];
      if (payload !== undefined && payload !== null) {
        availableFeeds += 1;
      }

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "artifact-tab";
      if (def.id === state.activeArtifact) btn.classList.add("is-active");
      if (deltasByArtifact[def.id]) btn.classList.add("has-delta");
      btn.dataset.artifact = def.id;
      btn.innerHTML = `<span>${escapeHtml(def.label)}</span><span class="tab-count">${records.length}</span>`;
      btn.addEventListener("click", () => {
        if (state.activeArtifact === def.id) return;
        state.activeArtifact = def.id;
        renderArtifactTabs();
        renderActiveArtifactFeed(false);
      });
      els.artifactTabs.appendChild(btn);
    }

    els.kpiFeedCount.textContent = `${availableFeeds} / ${state.artifactDefs.length}`;
  }

  function buildCardSlot(record, isEntering) {
    const slot = document.createElement("div");
    slot.className = isEntering ? "feed-card-slot is-entering is-highlight" : "feed-card-slot";
    slot.dataset.itemKey = record.key;

    const metaHtml = (record.meta || [])
      .map(([k, v]) => `<span><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v)}</span>`)
      .join("");

    slot.innerHTML = `
      <div class="feed-card-slot-inner">
        <article class="feed-card">
          <div class="feed-card-head">
            <h3 class="feed-card-title">${escapeHtml(record.title)}</h3>
            <span class="feed-card-tag">${escapeHtml(record.tag)}</span>
          </div>
          ${record.body ? `<div class="feed-card-body">${escapeHtml(record.body)}</div>` : ""}
          ${metaHtml ? `<div class="feed-kv-grid">${metaHtml}</div>` : ""}
        </article>
      </div>
    `;
    return slot;
  }

  function renderActiveArtifactFeed(animateTransitions = true) {
    const artifactId = state.activeArtifact;
    const payload = state.artifacts[artifactId];
    const errMsg = state.errors[artifactId];
    const records = payload ? extractArtifactRecords(artifactId, payload) : [];

    els.kpiActiveFeedCount.textContent = String(records.length);
    els.rawJsonPre.textContent = payload !== undefined ? JSON.stringify(payload, null, 2) : `// ${errMsg || "No payload available"}`;

    const def = state.artifactDefs.find((d) => d.id === artifactId);
    els.feedDescription.textContent = errMsg
      ? `Feed notice: ${errMsg}`
      : `${def ? def.label : artifactId} — ${records.length} active record(s) sent downstream`;
    els.feedSourceBadge.textContent = errMsg ? "Unavailable" : "CT1 Live";

    const prevKeys = state.prevArtifactKeys[artifactId] || new Set(records.map((r) => r.key));
    const nextKeys = new Set(records.map((r) => r.key));
    const addedCount = records.filter((r) => !prevKeys.has(r.key)).length;
    const removedCount = [...prevKeys].filter((k) => !nextKeys.has(k)).length;
    state.prevArtifactKeys[artifactId] = nextKeys;

    if (animateTransitions && (addedCount > 0 || removedCount > 0)) {
      const parts = [];
      if (removedCount > 0) parts.push(`-${removedCount} excluded`);
      if (addedCount > 0) parts.push(`+${addedCount} restored`);
      els.deltaPill.textContent = parts.join(" · ");
      els.deltaPill.classList.add("is-visible");
    } else if (!animateTransitions) {
      els.deltaPill.classList.remove("is-visible");
    }

    const container = els.cardsContainer;

    if (!records.length && !animateTransitions) {
      container.innerHTML = `<div class="empty-state">${escapeHtml(errMsg || "No active items remaining in this artifact feed.")}</div>`;
      return;
    }

    // Smooth FLIP reconciliation when updating the active artifact in-place
    const existingSlots = new Map();
    container.querySelectorAll(".feed-card-slot:not(.is-exiting)").forEach((el) => {
      existingSlots.set(el.dataset.itemKey, el);
    });

    if (!animateTransitions || existingSlots.size === 0) {
      container.innerHTML = "";
      if (!records.length) {
        container.innerHTML = `<div class="empty-state">${escapeHtml(errMsg || "No active items remaining in this artifact feed.")}</div>`;
        return;
      }
      const frag = document.createDocumentFragment();
      records.forEach((rec) => frag.appendChild(buildCardSlot(rec, false)));
      container.appendChild(frag);
      return;
    }

    // First: measure existing card positions before DOM change
    const firstRects = new Map();
    existingSlots.forEach((el, key) => {
      firstRects.set(key, el.getBoundingClientRect());
    });

    // Clear empty states
    container.querySelectorAll(".empty-state").forEach((n) => n.remove());

    // Mark exiting cards so they slide & collapse gracefully before removal
    const exitingNodes = [];
    existingSlots.forEach((el, key) => {
      if (!nextKeys.has(key)) {
        el.classList.add("is-exiting");
        exitingNodes.push(el);
      }
    });

    // Reorder continuing slots & insert entering slots
    const newSlots = [];
    records.forEach((rec) => {
      const existing = existingSlots.get(rec.key);
      if (existing) {
        container.appendChild(existing);
      } else {
        const slot = buildCardSlot(rec, true);
        container.appendChild(slot);
        newSlots.push(slot);
      }
    });

    // Last + Invert + Play for continuing cards
    existingSlots.forEach((el, key) => {
      if (!nextKeys.has(key)) return;
      const first = firstRects.get(key);
      const last = el.getBoundingClientRect();
      if (!first || !last) return;
      const dy = first.top - last.top;
      if (Math.abs(dy) > 1) {
        el.style.transition = "none";
        el.style.transform = `translate3d(0, ${dy}px, 0)`;
        requestAnimationFrame(() => {
          el.style.transition = "";
          el.style.transform = "translate3d(0, 0, 0)";
        });
      }
    });

    // Play entering animations on next frame
    if (newSlots.length > 0) {
      requestAnimationFrame(() => {
        newSlots.forEach((slot) => {
          slot.classList.remove("is-entering");
          slot.classList.add("is-entered");
          window.setTimeout(() => slot.classList.remove("is-highlight"), 1400);
        });
      });
    }

    // Remove exited cards cleanly after their collapse transition finishes
    if (exitingNodes.length > 0) {
      window.setTimeout(() => {
        exitingNodes.forEach((node) => node.remove());
        if (records.length === 0 && !container.querySelector(".feed-card-slot")) {
          container.innerHTML = `<div class="empty-state">All items in this feed have been excluded for downstream agents.</div>`;
        }
      }, 360);
    } else if (records.length === 0) {
      container.innerHTML = `<div class="empty-state">All items in this feed have been excluded for downstream agents.</div>`;
    }
  }

  async function refreshPlanData(planNumber, { animate = false, silentBanner = false } = {}) {
    state.planNumber = planNumber;
    els.mentionPlanTag.textContent = planNumber;
    if (!silentBanner) {
      setStatus("loading", `Syncing plan ${planNumber} from CT1 (${state.ctaHost || "live"})...`);
    } else {
      setStatus("loading", null);
    }

    try {
      const resp = await fetch(`/api/ct1/plan/${encodeURIComponent(planNumber)}/bootstrap`);
      const data = await resp.json();
      if (!resp.ok) {
        throw new Error(data.detail || `HTTP ${resp.status}`);
      }

      const deltas = {};
      for (const def of state.artifactDefs) {
        const nextPayload = data.artifacts ? data.artifacts[def.id] : undefined;
        const nextLen = nextPayload ? extractArtifactRecords(def.id, nextPayload).length : 0;
        const prevLen = state.prevCounts[def.id];
        if (animate && prevLen !== undefined && prevLen !== nextLen) {
          deltas[def.id] = nextLen - prevLen;
        }
        state.prevCounts[def.id] = nextLen;
      }

      state.catalog = data.catalog;
      state.availability = data.availability;
      state.artifacts = data.artifacts || {};
      state.errors = data.errors || {};
      state.ctaHost = data.cta_host || state.ctaHost;
      els.ct1HostBadge.textContent = `${state.ctaHost} · Plan ${planNumber}`;
      els.kpiLatency.textContent = `${data.latency_ms ?? "--"} ms`;

      state.mentionItems = buildMentionCatalog(state.catalog);
      updateCatalogSummary(state.catalog);
      renderArtifactTabs(deltas);
      renderActiveArtifactFeed(animate);
      setStatus("ok", null);
    } catch (err) {
      setStatus("error", `CT1 sync error: ${err.message}`);
    }
  }

  function appendChatMessage({ role, text, workflow = null, isWelcome = false }) {
    const wrapper = document.createElement("div");
    wrapper.className = `chat-msg ${role === "user" ? "is-user" : "is-assistant"}`;

    const label = document.createElement("div");
    label.className = "msg-role";
    label.textContent = role === "user" ? "You" : isWelcome ? "CT1 Scoping Query Agent" : "CT1 Query Agent";
    wrapper.appendChild(label);

    const bubble = document.createElement("div");
    bubble.className = "msg-bubble";
    if (role === "user") {
      bubble.innerHTML = formatRichUserText(text);
    } else {
      bubble.textContent = text;
    }

    if (workflow && typeof workflow === "object" && (workflow.stage || workflow.plan || workflow.actions)) {
      bubble.appendChild(buildWorkflowCard(workflow));
    }

    wrapper.appendChild(bubble);
    els.chatStream.appendChild(wrapper);
    requestAnimationFrame(() => {
      els.chatStream.scrollTo({ top: els.chatStream.scrollHeight, behavior: "smooth" });
    });
  }

  function buildWorkflowCard(workflow) {
    const stage = String(workflow.stage || "").toLowerCase();
    const card = document.createElement("div");
    card.className = "workflow-card";
    if (stage === "executed") card.classList.add("is-executed");
    if (stage === "cancelled") card.classList.add("is-cancelled");

    const actions =
      (workflow.plan && Array.isArray(workflow.plan.actions) && workflow.plan.actions) ||
      (Array.isArray(workflow.actions) ? workflow.actions : []);

    const stageLabel =
      stage === "awaiting_approval"
        ? "Approval Required"
        : stage === "executed"
        ? "Executed on CT1"
        : stage === "cancelled"
        ? "Cancelled"
        : stage || "Workflow";

    const itemsHtml = actions
      .map((act) => {
        const op = String(act.action || "exclude").toLowerCase();
        const opClass = op === "include" || op === "restore" ? "op-include" : "op-exclude";
        const target = act.section_title ? `${act.title} › ${act.section_title}` : act.title || act.filename || "Target";
        const meta = [act.document_type, act.row_primary_key ? `PK ${act.row_primary_key}` : null]
          .filter(Boolean)
          .join(" · ");
        return `
          <div class="workflow-action-item">
            <div>
              <strong>${escapeHtml(target)}</strong>
              ${meta ? `<div style="font-size:11px;color:#64748b;margin-top:2px;">${escapeHtml(meta)}</div>` : ""}
            </div>
            <span class="action-op-pill ${opClass}">${escapeHtml(op)}</span>
          </div>
        `;
      })
      .join("");

    card.innerHTML = `
      <div class="workflow-card-head">
        <span style="font-size:12px;font-weight:700;color:#1e293b;">Document Scope Plan</span>
        <span class="workflow-stage-badge">${escapeHtml(stageLabel)}</span>
      </div>
      ${itemsHtml ? `<div class="workflow-action-list">${itemsHtml}</div>` : ""}
    `;

    if (stage === "awaiting_approval") {
      const btnRow = document.createElement("div");
      btnRow.className = "workflow-card-actions";

      const approveBtn = document.createElement("button");
      approveBtn.type = "button";
      approveBtn.className = "btn btn-approve btn-xs";
      approveBtn.textContent = "Approve & Execute";

      const rejectBtn = document.createElement("button");
      rejectBtn.type = "button";
      rejectBtn.className = "btn btn-reject btn-xs";
      rejectBtn.textContent = "Cancel Plan";

      approveBtn.addEventListener("click", () => {
        approveBtn.disabled = true;
        rejectBtn.disabled = true;
        sendChatTurn("approve");
      });
      rejectBtn.addEventListener("click", () => {
        approveBtn.disabled = true;
        rejectBtn.disabled = true;
        sendChatTurn("cancel");
      });

      btnRow.appendChild(approveBtn);
      btnRow.appendChild(rejectBtn);
      card.appendChild(btnRow);
    }

    return card;
  }

  async function sendChatTurn(questionText) {
    const trimmed = questionText.trim();
    if (!trimmed || state.isBusy) return;

    closeMentionPopover();
    appendChatMessage({ role: "user", text: trimmed });
    els.chatInput.value = "";
    autoResizeTextarea();

    state.isBusy = true;
    els.sendBtn.disabled = true;
    setStatus("loading", "Waiting for CT1 Query Agent response...");

    try {
      const resp = await fetch("/api/ct1/query/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: trimmed,
          plan_number: state.planNumber,
          context_type: "Preliminary Research Walkthrough",
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        throw new Error(data.detail || `HTTP ${resp.status}`);
      }

      const wf = data.document_workflow || null;
      appendChatMessage({
        role: "assistant",
        text: data.answer || "(No answer text returned)",
        workflow: wf,
      });

      // Whenever an execution completes or workflow finishes, refresh live CT1 feeds smoothly!
      const stage = wf && String(wf.stage || "").toLowerCase();
      if (stage === "executed" || (wf && wf.execution_result)) {
        await refreshPlanData(state.planNumber, { animate: true, silentBanner: true });
      } else {
        setStatus("ok", null);
      }
    } catch (err) {
      appendChatMessage({
        role: "assistant",
        text: `Unable to complete CT1 request: ${err.message}`,
      });
      setStatus("error", `Query error: ${err.message}`);
    } finally {
      state.isBusy = false;
      els.sendBtn.disabled = false;
      els.chatInput.focus();
    }
  }

  // Predictive @ Autocomplete Engine
  function findActiveAtTrigger() {
    const val = els.chatInput.value;
    const pos = els.chatInput.selectionStart ?? val.length;
    const before = val.slice(0, pos);
    const lastAt = before.lastIndexOf("@");
    if (lastAt === -1) return null;
    if (lastAt > 0 && !/[\s(]/.test(before[lastAt - 1])) return null;
    const fragment = before.slice(lastAt + 1);
    if (fragment.includes("]") || fragment.includes("\n")) return null;
    return { start: lastAt, end: pos, query: fragment.trim().toLowerCase() };
  }

  function renderMentionList() {
    els.mentionList.innerHTML = "";
    if (state.filteredMentions.length === 0) {
      els.mentionList.innerHTML = `<div style="padding:14px;font-size:12px;color:#64748b;text-align:center;">No matching documents or sections in Plan ${escapeHtml(state.planNumber)}.</div>`;
      return;
    }

    state.filteredMentions.forEach((item, idx) => {
      const row = document.createElement("div");
      row.className = `mention-item${idx === state.mentionIndex ? " is-selected" : ""}`;
      row.setAttribute("role", "option");
      row.innerHTML = `
        <div class="mention-main">
          <div class="mention-title">${escapeHtml(item.title)}</div>
          <div class="mention-sub">${escapeHtml(item.subtitle)}</div>
        </div>
        <div class="mention-badges">
          <span class="pill-type">${escapeHtml(item.groupLabel)}</span>
          <span class="${item.excluded ? "pill-status-excluded" : "pill-status-active"}">${item.excluded ? "EXCLUDED" : "ACTIVE"}</span>
        </div>
      `;
      row.addEventListener("mouseenter", () => {
        state.mentionIndex = idx;
        highlightMentionSelection();
      });
      row.addEventListener("mousedown", (e) => {
        e.preventDefault();
        insertMention(item);
      });
      els.mentionList.appendChild(row);
    });
  }

  function highlightMentionSelection() {
    const children = els.mentionList.querySelectorAll(".mention-item");
    children.forEach((el, idx) => {
      el.classList.toggle("is-selected", idx === state.mentionIndex);
      if (idx === state.mentionIndex) {
        el.scrollIntoView({ block: "nearest" });
      }
    });
  }

  function openMentionPopover(query, anchorStart) {
    state.mentionAnchorStart = anchorStart;
    const textBefore = els.chatInput.value.slice(0, Math.max(0, anchorStart)).toLowerCase();
    const preferExcluded = /\b(include|restore|re-include|add back|reinstate)\b/.test(textBefore);

    const matches = state.mentionItems.filter((item) => !query || item.searchBlob.includes(query));
    matches.sort((a, b) => {
      if (preferExcluded && a.excluded !== b.excluded) return a.excluded ? -1 : 1;
      if (!preferExcluded && a.excluded !== b.excluded) return a.excluded ? 1 : -1;
      return 0;
    });

    state.filteredMentions = matches.slice(0, 24);
    state.mentionIndex = 0;
    state.mentionOpen = true;
    renderMentionList();
    els.mentionPopover.classList.add("is-open");
  }

  function closeMentionPopover() {
    state.mentionOpen = false;
    state.mentionAnchorStart = -1;
    els.mentionPopover.classList.remove("is-open");
  }

  function insertMention(item) {
    const val = els.chatInput.value;
    const pos = els.chatInput.selectionStart ?? val.length;
    const start = state.mentionAnchorStart >= 0 ? state.mentionAnchorStart : pos;
    const before = val.slice(0, start);
    const after = val.slice(pos);
    const token = `${item.mentionText} `;
    els.chatInput.value = `${before}${token}${after}`;
    const nextPos = before.length + token.length;
    els.chatInput.setSelectionRange(nextPos, nextPos);
    closeMentionPopover();
    autoResizeTextarea();
    els.chatInput.focus();
  }

  function autoResizeTextarea() {
    els.chatInput.style.height = "auto";
    els.chatInput.style.height = `${Math.min(els.chatInput.scrollHeight, 140)}px`;
  }

  async function triggerDataExtractionRun() {
    els.runExtractionBtn.disabled = true;
    setStatus("loading", `Starting CT1 data extraction for Plan ${state.planNumber}...`);
    try {
      const resp = await fetch("/api/ct1/dataextraction/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planNumber: state.planNumber }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.detail || `HTTP ${resp.status}`);

      const sessionId = data.session_id;
      if (!sessionId) {
        await refreshPlanData(state.planNumber, { animate: true });
        return;
      }

      if (state.pollTimer) window.clearInterval(state.pollTimer);
      state.pollTimer = window.setInterval(async () => {
        try {
          const stResp = await fetch(`/api/ct1/dataextraction/status/${encodeURIComponent(sessionId)}`);
          const st = await stResp.json();
          const curStatus = String(st.status || "").toLowerCase();
          setStatus("loading", `CT1 Extraction (${st.stage_name || "running"}): ${curStatus || "in progress"}...`);

          if (curStatus === "completed" || curStatus === "done" || curStatus === "success") {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            await refreshPlanData(state.planNumber, { animate: true });
          } else if (curStatus === "failed" || curStatus === "error") {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            setStatus("error", `Extraction failed: ${st.error || "Unknown error"}`);
          }
        } catch (err) {
          window.clearInterval(state.pollTimer);
          state.pollTimer = null;
          els.runExtractionBtn.disabled = false;
          setStatus("error", `Status poll error: ${err.message}`);
        }
      }, 2500);
    } catch (err) {
      els.runExtractionBtn.disabled = false;
      setStatus("error", `Extraction launch error: ${err.message}`);
    }
  }

  function wireEvents() {
    els.planForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const nextPlan = els.planInput.value.trim();
      if (!nextPlan) return;
      state.prevCounts = {};
      state.prevArtifactKeys = {};
      await refreshPlanData(nextPlan, { animate: false });
    });

    els.refreshBtn.addEventListener("click", () => {
      refreshPlanData(state.planNumber, { animate: true });
    });

    els.runExtractionBtn.addEventListener("click", triggerDataExtractionRun);

    els.composerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      sendChatTurn(els.chatInput.value);
    });

    els.chatInput.addEventListener("input", () => {
      autoResizeTextarea();
      const trigger = findActiveAtTrigger();
      if (trigger) {
        openMentionPopover(trigger.query, trigger.start);
      } else {
        closeMentionPopover();
      }
    });

    els.chatInput.addEventListener("keydown", (e) => {
      if (state.mentionOpen) {
        if (e.key === "ArrowDown") {
          e.preventDefault();
          state.mentionIndex = (state.mentionIndex + 1) % Math.max(1, state.filteredMentions.length);
          highlightMentionSelection();
          return;
        }
        if (e.key === "ArrowUp") {
          e.preventDefault();
          const len = Math.max(1, state.filteredMentions.length);
          state.mentionIndex = (state.mentionIndex - 1 + len) % len;
          highlightMentionSelection();
          return;
        }
        if (e.key === "Enter" || e.key === "Tab") {
          if (state.filteredMentions[state.mentionIndex]) {
            e.preventDefault();
            insertMention(state.filteredMentions[state.mentionIndex]);
            return;
          }
        }
        if (e.key === "Escape") {
          e.preventDefault();
          closeMentionPopover();
          return;
        }
      }

      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendChatTurn(els.chatInput.value);
      }
    });

    els.triggerAtBtn.addEventListener("click", () => {
      const pos = els.chatInput.selectionStart ?? els.chatInput.value.length;
      const before = els.chatInput.value.slice(0, pos);
      const after = els.chatInput.value.slice(pos);
      const needsSpace = before.length > 0 && !/\s$/.test(before);
      const prefix = needsSpace ? " @" : "@";
      els.chatInput.value = `${before}${prefix}${after}`;
      const newPos = before.length + prefix.length;
      els.chatInput.setSelectionRange(newPos, newPos);
      openMentionPopover("", newPos - 1);
      els.chatInput.focus();
    });

    els.quickPrompts.querySelectorAll(".prompt-chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        const tmpl = chip.dataset.template || "";
        els.chatInput.value = tmpl;
        autoResizeTextarea();
        els.chatInput.focus();
        if (tmpl.endsWith(" ")) {
          const pos = tmpl.length;
          els.chatInput.value = `${tmpl}@`;
          els.chatInput.setSelectionRange(pos + 1, pos + 1);
          openMentionPopover("", pos);
        }
      });
    });

    // Attach / Ingest flow
    els.attachBtn.addEventListener("click", () => els.fileInput.click());
    els.fileInput.addEventListener("change", () => {
      const files = Array.from(els.fileInput.files || []);
      if (files.length === 0) return;
      els.ingestFileNames.textContent = files.map((f) => f.name).join(", ");
      els.ingestDrawer.classList.add("is-open");
    });

    els.ingestCancelBtn.addEventListener("click", () => {
      els.fileInput.value = "";
      els.ingestDrawer.classList.remove("is-open");
    });

    els.ingestSubmitBtn.addEventListener("click", async () => {
      const files = Array.from(els.fileInput.files || []);
      if (!files.length) return;
      const form = new FormData();
      form.append("plan_number", state.planNumber);
      form.append("document_type", els.ingestDocType.value);
      files.forEach((f) => form.append("files", f));

      els.ingestSubmitBtn.disabled = true;
      setStatus("loading", `Uploading ${files.length} file(s) to CT1 RAG ingest...`);
      try {
        const resp = await fetch("/api/ct1/query/ingest", { method: "POST", body: form });
        const data = await resp.json();
        if (!resp.ok) throw new Error(data.detail || `HTTP ${resp.status}`);
        appendChatMessage({
          role: "assistant",
          text: `RAG Ingest submitted (status=${data.status}, job_id=${data.job_id || "n/a"}). ${data.message || ""}`,
        });
        els.fileInput.value = "";
        els.ingestDrawer.classList.remove("is-open");
        await refreshPlanData(state.planNumber, { animate: true });
      } catch (err) {
        setStatus("error", `Ingest error: ${err.message}`);
      } finally {
        els.ingestSubmitBtn.disabled = false;
      }
    });

    // Segmented view toggle (Structured Cards vs Raw JSON)
    document.querySelectorAll(".seg-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const mode = btn.dataset.view || "cards";
        state.viewMode = mode;
        document.querySelectorAll(".seg-btn").forEach((b) => {
          const active = b.dataset.view === mode;
          b.classList.toggle("is-active", active);
          b.setAttribute("aria-selected", String(active));
        });
        els.segmented.classList.toggle("is-json", mode === "json");
        els.feedViewport.classList.toggle("is-json-mode", mode === "json");
      });
    });

    document.addEventListener("click", (e) => {
      if (state.mentionOpen && !e.target.closest(".composer-dock")) {
        closeMentionPopover();
      }
    });
  }

  async function init() {
    wireEvents();
    appendChatMessage({
      role: "assistant",
      isWelcome: true,
      text: "Connected to live CT1 Scoping endpoints. Type @ in the box below to browse active or excluded documents, sections, findings, prior plans, and LRR mandates — propose an exclusion or restore, approve it inline, and watch the downstream Data Extraction feeds update smoothly on the right.",
    });

    try {
      const cfgResp = await fetch("/api/config");
      if (cfgResp.ok) {
        const cfg = await cfgResp.json();
        state.ctaHost = cfg.cta_host || "";
        state.planNumber = cfg.default_plan_number || "20440";
        if (Array.isArray(cfg.artifacts) && cfg.artifacts.length) {
          state.artifactDefs = cfg.artifacts;
        }
        els.planInput.value = state.planNumber;
        els.ct1HostBadge.textContent = `${state.ctaHost} · Plan ${state.planNumber}`;
      }
    } catch (_) {
      // Fallback defaults already active
    }

    await refreshPlanData(state.planNumber, { animate: false });
  }

  init();
})();
