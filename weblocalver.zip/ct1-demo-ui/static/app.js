(() => {
  "use strict";

  const GROUP_LABEL_MAP = {
    policy: "Policies",
    kod: "KOD",
    procedure: "Procedures",
    gfms: "GFMS Data",
    historical_scoping_document: "Historical Scoping",
    lrr: "LRR Mandates",
  };

  const DOC_TYPE_TO_ARTIFACT = {
    policy: "policy",
    kod: "policy",
    procedure: "policy",
    gfms: "findings_details",
    historical_scoping_document: "historical_plan_details",
    lrr: "lrr",
  };

  const DEFAULT_ARTIFACTS = [
    { id: "policy", label: "Policies / KOD / Proc", excludable: "true" },
    { id: "findings_details", label: "GFMS Findings", excludable: "true" },
    { id: "historical_plan_details", label: "Historical Plans", excludable: "true" },
    { id: "lrr", label: "LRR Mandates", excludable: "true" },
    { id: "current_details", label: "Current Plan", excludable: "false" },
    { id: "alc_nlac", label: "ALC / NALC", excludable: "false" },
    { id: "control_details", label: "Controls", excludable: "false" },
    { id: "risk_driver_details", label: "Risk Drivers", excludable: "false" },
    { id: "group_audit", label: "Group Audit", excludable: "false" },
  ];

  const state = {
    planNumber: "20440",
    ctaHost: "",
    queryMode: "",
    artifactDefs: [...DEFAULT_ARTIFACTS],
    activeArtifact: "policy",
    viewMode: "cards", // "cards" | "json"
    catalog: null,
    availability: null,
    artifacts: {},
    errors: {},
    prevCounts: {},
    prevArtifactKeys: {},
    mentionItems: [],
    filteredMentions: [],
    mentionOpen: false,
    mentionIndex: 0,
    mentionAnchorStart: -1,
    isBusy: false,
    pollTimer: null,
    lastErrorPayload: null,
  };

  const els = {
    ct1StatusDot: document.getElementById("ct1StatusDot"),
    ct1HostBadge: document.getElementById("ct1HostBadge"),
    planForm: document.getElementById("planForm"),
    planInput: document.getElementById("planInput"),
    loadPlanBtn: document.getElementById("loadPlanBtn"),
    refreshBtn: document.getElementById("refreshBtn"),
    runExtractionBtn: document.getElementById("runExtractionBtn"),
    resetBtn: document.getElementById("resetBtn"),
    statusDrawer: document.getElementById("statusDrawer"),
    statusText: document.getElementById("statusText"),
    catalogActiveCount: document.getElementById("catalogActiveCount"),
    catalogExcludedCount: document.getElementById("catalogExcludedCount"),
    chatStream: document.getElementById("chatStream"),
    composerForm: document.getElementById("composerForm"),
    chatInput: document.getElementById("chatInput"),
    sendBtn: document.getElementById("sendBtn"),
    triggerAtBtn: document.getElementById("triggerAtBtn"),
    attachBtn: document.getElementById("attachBtn"),
    fileInput: document.getElementById("fileInput"),
    ingestDrawer: document.getElementById("ingestDrawer"),
    ingestDocType: document.getElementById("ingestDocType"),
    ingestFileNames: document.getElementById("ingestFileNames"),
    ingestSubmitBtn: document.getElementById("ingestSubmitBtn"),
    ingestCancelBtn: document.getElementById("ingestCancelBtn"),
    mentionPopover: document.getElementById("mentionPopover"),
    mentionPlanTag: document.getElementById("mentionPlanTag"),
    mentionList: document.getElementById("mentionList"),
    quickPrompts: document.getElementById("quickPrompts"),
    kpiActiveFeedCount: document.getElementById("kpiActiveFeedCount"),
    kpiExcludedCount: document.getElementById("kpiExcludedCount"),
    kpiFeedCount: document.getElementById("kpiFeedCount"),
    kpiLatency: document.getElementById("kpiLatency"),
    artifactTabs: document.getElementById("artifactTabs"),
    feedViewport: document.getElementById("feedViewport"),
    feedSourceBadge: document.getElementById("feedSourceBadge"),
    feedDescription: document.getElementById("feedDescription"),
    deltaPill: document.getElementById("deltaPill"),
    cardsContainer: document.getElementById("cardsContainer"),
    rawJsonPre: document.getElementById("rawJsonPre"),
    segmented: document.querySelector(".segmented"),
    errorModalBackdrop: document.getElementById("errorModalBackdrop"),
    errorModalTitle: document.getElementById("errorModalTitle"),
    errorModalBadge: document.getElementById("errorModalBadge"),
    errorModalCloseBtn: document.getElementById("errorModalCloseBtn"),
    errorModalMessage: document.getElementById("errorModalMessage"),
    errorModalMeta: document.getElementById("errorModalMeta"),
    errorModalFailuresSection: document.getElementById("errorModalFailuresSection"),
    errorModalFailuresList: document.getElementById("errorModalFailuresList"),
    errorModalDetailsPre: document.getElementById("errorModalDetailsPre"),
    errorModalCopyBtn: document.getElementById("errorModalCopyBtn"),
    errorModalDismissBtn: document.getElementById("errorModalDismissBtn"),
  };

  async function readResponsePayload(resp) {
    const rawText = await resp.text();
    if (!rawText) return { rawText: "", parsed: {} };
    try {
      return { rawText, parsed: JSON.parse(rawText) };
    } catch (_) {
      return { rawText, parsed: rawText };
    }
  }

  function normalizeErrorPayload(resp, payload, fallbackOp, endpoint) {
    const detail = payload && typeof payload === "object" && payload.detail !== undefined ? payload.detail : null;
    const errDetailsObj =
      payload && typeof payload === "object" && payload.error_details && !Array.isArray(payload.error_details)
        ? payload.error_details
        : null;
    const errDetailsArr =
      (detail && typeof detail === "object" && Array.isArray(detail.error_details) && detail.error_details) ||
      (payload && typeof payload === "object" && Array.isArray(payload.error_details) && payload.error_details) ||
      [];

    let message = "";
    if (errDetailsObj && errDetailsObj.message) {
      message = String(errDetailsObj.message);
    } else if (detail && typeof detail === "object") {
      message = String(detail.error || detail.message || JSON.stringify(detail));
    } else if (typeof detail === "string" && detail) {
      message = detail;
    } else if (payload && typeof payload === "object" && (payload.error || payload.message || payload.answer)) {
      message = String(payload.error || payload.message || payload.answer);
    } else if (typeof payload === "string" && payload) {
      message = payload;
    } else if (resp) {
      message = `HTTP ${resp.status} ${resp.statusText || ""}`.trim();
    } else {
      message = "Unexpected error";
    }

    const operation =
      (errDetailsObj && errDetailsObj.operation) ||
      (detail && typeof detail === "object" && detail.operation) ||
      fallbackOp ||
      "request";
    const resolvedEndpoint =
      (errDetailsObj && errDetailsObj.upstream_url) ||
      (detail && typeof detail === "object" && detail.upstream_url) ||
      endpoint ||
      "";
    const httpStatus =
      (errDetailsObj && errDetailsObj.upstream_status) ||
      (detail && typeof detail === "object" && detail.upstream_status) ||
      (resp ? resp.status : null);
    const stage =
      (errDetailsObj && (errDetailsObj.stage || errDetailsObj.status)) ||
      (payload && typeof payload === "object" && (payload.status || payload.stage)) ||
      (httpStatus ? `HTTP ${httpStatus}` : "error");

    const failures = [];
    if (errDetailsObj && Array.isArray(errDetailsObj.failed)) {
      failures.push(...errDetailsObj.failed);
    }
    if (errDetailsArr.length) {
      failures.push(...errDetailsArr);
    }

    const titleMap = {
      bootstrap: "CT1 Plan Sync Failed",
      query_chat: "Query Agent / Execution Error",
      rag_ingest_documents: "RAG Document Ingest Failed",
      rag_ingest_job_poll: "RAG Ingest Job Failed",
      rag_categorize_document_ids: "RAG Categorization Failed",
      rag_get_relevant_data: "RAG Retrieval Failed",
      dataextraction_run: "Data Extraction Launch Failed",
      dataextraction_status: "Data Extraction Failed",
      config: "Configuration Load Failed",
      reset: "Reset Failed",
    };

    return {
      title: titleMap[operation] || "Operation Error",
      badge: httpStatus ? `HTTP ${httpStatus}` : String(stage || "ERROR").toUpperCase(),
      message,
      operation,
      endpoint: resolvedEndpoint,
      httpStatus,
      stage,
      planNumber: state.planNumber,
      timestamp: new Date().toISOString(),
      failures,
      details: payload,
    };
  }

  function showErrorModal(errInfo) {
    if (!els.errorModalBackdrop) return;
    const normalized = errInfo && typeof errInfo === "object" ? errInfo : { message: String(errInfo || "Unknown error") };
    state.lastErrorPayload = normalized;

    els.errorModalTitle.textContent = normalized.title || "Operation Error";
    els.errorModalBadge.textContent = normalized.badge || "ERROR";
    els.errorModalMessage.textContent = normalized.message || "An error occurred.";

    const metaRows = [
      ["Operation", normalized.operation || "unknown"],
      ["Plan #", normalized.planNumber || state.planNumber || "n/a"],
      ["HTTP Status", normalized.httpStatus != null ? String(normalized.httpStatus) : "n/a"],
      ["Stage / Status", normalized.stage || "error"],
      ["Endpoint / URL", normalized.endpoint || "n/a"],
      ["Timestamp", normalized.timestamp || new Date().toISOString()],
    ];
    els.errorModalMeta.innerHTML = metaRows
      .map(
        ([k, v]) => `
          <div class="error-modal-meta-item">
            <div class="error-modal-meta-label">${escapeHtml(k)}</div>
            <div class="error-modal-meta-val">${escapeHtml(v)}</div>
          </div>
        `
      )
      .join("");

    const failures = Array.isArray(normalized.failures) ? normalized.failures : [];
    if (failures.length > 0) {
      els.errorModalFailuresSection.hidden = false;
      els.errorModalFailuresList.innerHTML = failures
        .map((f, idx) => {
          const itemObj = f && typeof f === "object" ? f.item || f : {};
          const targetLabel =
            itemObj.title ||
            itemObj.document_title ||
            itemObj.file_name ||
            itemObj.filename ||
            (f && f.target) ||
            `Item #${idx + 1}`;
          const msg =
            (f && (f.error || f.reason || f.message)) ||
            (typeof f === "string" ? f : JSON.stringify(f));
          const urlOrDb = [];
          if (f && f.upstream_url) urlOrDb.push(`url=${f.upstream_url}`);
          if (f && f.upstream_status != null) urlOrDb.push(`status=${f.upstream_status}`);
          const dbInfo = (f && (f.db_result || f.db_target)) || {};
          for (const k of ["table", "data_source", "db_host", "db_name", "db_port", "db_user", "exception_type"]) {
            if (dbInfo[k]) urlOrDb.push(`${k}=${dbInfo[k]}`);
          }
          if (f && f.exception_type && !dbInfo.exception_type) urlOrDb.push(`exception=${f.exception_type}`);
          return `
            <div class="error-modal-failure-item">
              <div class="error-modal-failure-target">${escapeHtml(targetLabel)}</div>
              <div class="error-modal-failure-msg">${escapeHtml(msg)}</div>
              ${urlOrDb.length ? `<div class="error-modal-failure-sub">${escapeHtml(urlOrDb.join(" · "))}</div>` : ""}
            </div>
          `;
        })
        .join("");
    } else {
      els.errorModalFailuresSection.hidden = true;
      els.errorModalFailuresList.innerHTML = "";
    }

    let rawDump = "";
    try {
      rawDump =
        typeof normalized.details === "string"
          ? normalized.details
          : JSON.stringify(normalized.details ?? normalized, null, 2);
    } catch (_) {
      rawDump = String(normalized.details || normalized.message || "");
    }
    els.errorModalDetailsPre.textContent = rawDump || "{}";
    els.errorModalBackdrop.hidden = false;
  }

  function closeErrorModal() {
    if (!els.errorModalBackdrop) return;
    els.errorModalBackdrop.hidden = true;
  }

  function setStatus(kind, bannerMessage) {
    els.ct1StatusDot.classList.remove("is-loading", "is-error");
    if (kind === "loading") {
      els.ct1StatusDot.classList.add("is-loading");
    } else if (kind === "error") {
      els.ct1StatusDot.classList.add("is-error");
    }

    if (bannerMessage) {
      els.statusText.textContent = bannerMessage;
      els.statusDrawer.classList.add("is-open");
    } else {
      els.statusDrawer.classList.remove("is-open");
    }
  }

  function escapeHtml(text) {
    return String(text ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function formatRichUserText(text) {
    const escaped = escapeHtml(text);
    return escaped.replace(/(@\[[^\]]+\])/g, '<span class="mention-token">$1</span>');
  }

  function isExcludedStatus(item) {
    if (!item || typeof item !== "object") return false;
    if (item.excluded === true) return true;
    const st = String(item.status || "").trim().toLowerCase();
    return st === "excluded" || st === "removed" || st === "inactive" || st === "deleted";
  }

  function isMaskedPlaceholder(value) {
    const s = String(value ?? "").trim();
    return !s || /^x+$/i.test(s);
  }

  function unwrapEnvelope(payload) {
    if (payload && typeof payload === "object" && !Array.isArray(payload) && payload.data !== undefined) {
      return payload.data;
    }
    return payload;
  }

  function buildMentionCatalog(catalog) {
    const items = [];
    if (!catalog || !Array.isArray(catalog.document_groups)) return items;

    for (const group of catalog.document_groups) {
      const gtype = String(group.document_type || "policy").toLowerCase();
      const glabel = GROUP_LABEL_MAP[gtype] || gtype;
      const docs = Array.isArray(group.documents) ? group.documents : [];

      for (const doc of docs) {
        if (!doc || typeof doc !== "object") continue;
        const title = String(doc.document_title || doc.document_name || doc.title || doc.file_name || "Document").trim();
        const fileName = String(doc.file_name || doc.filename || "").trim();
        const docExcluded = isExcludedStatus(doc);

        items.push({
          key: `doc:${gtype}:${doc.document_id || fileName || title}`,
          docType: gtype,
          groupLabel: glabel,
          title,
          subtitle: fileName ? `${glabel} · ${fileName}` : glabel,
          excluded: docExcluded,
          mentionText: `@[${glabel}: ${title}]`,
          searchBlob: `${glabel} ${title} ${fileName}`.toLowerCase(),
        });

        const sections = Array.isArray(doc.sections) ? doc.sections : [];
        for (const sec of sections) {
          if (!sec || typeof sec !== "object") continue;
          const sid = sec.section_id ?? "";
          const stitle = String(sec.section_title || sec.title || `Section ${sid}`).trim();
          const secExcluded = docExcluded || isExcludedStatus(sec);
          const secLabel = sid && !stitle.toLowerCase().includes(String(sid).toLowerCase())
            ? `Section ${sid}: ${stitle}`
            : stitle;

          items.push({
            key: `sec:${gtype}:${doc.document_id || title}:${sid}:${stitle}`,
            docType: gtype,
            groupLabel: glabel,
            title: stitle,
            subtitle: `${glabel} · ${title}${sid ? ` (#${sid})` : ""}`,
            excluded: secExcluded,
            mentionText: `@[${glabel}: ${title} > ${secLabel}]`,
            searchBlob: `${glabel} ${title} ${stitle} ${sid} ${secLabel}`.toLowerCase(),
          });
        }
      }
    }
    return items;
  }

  function updateCatalogSummary(catalog) {
    let active = 0;
    let excluded = 0;
    if (catalog && Array.isArray(catalog.document_groups)) {
      for (const group of catalog.document_groups) {
        for (const doc of group.documents || []) {
          if (isExcludedStatus(doc)) {
            excluded += 1;
          } else {
            active += 1;
          }
          for (const sec of doc.sections || []) {
            if (isExcludedStatus(sec)) excluded += 1;
          }
        }
      }
    }
    els.catalogActiveCount.textContent = String(active);
    els.catalogExcludedCount.textContent = String(excluded);
    els.kpiExcludedCount.textContent = String(excluded);
  }

  function extractArtifactRecords(artifactId, payload) {
    if (payload == null) return [];
    const data = unwrapEnvelope(payload);
    if (data == null) return [];

    if (artifactId === "policy") {
      const list = Array.isArray(data)
        ? data
        : Array.isArray(data.referenced_documents)
        ? data.referenced_documents
        : Array.isArray(data.documents)
        ? data.documents
        : Array.isArray(data.items)
        ? data.items
        : Array.isArray(data.sources)
        ? data.sources
        : Array.isArray(data.nodes)
        ? data.nodes
        : [];

      const rows = [];
      list.forEach((row, idx) => {
        if (!row || typeof row !== "object" || isExcludedStatus(row)) return;
        const dtype = String(row.document_type || "policy").toLowerCase();
        const docName = String(row.document_name || row.document_title || row.file_name || row.title || `Policy Item ${idx + 1}`).trim();
        const gsUri = row.gs_uri || row.storage_uri || row.uri || "";
        const sections = Array.isArray(row.sections) ? row.sections.filter((s) => s && !isExcludedStatus(s)) : [];

        rows.push({
          key: `doc:${dtype}:${docName}`,
          title: docName,
          tag: dtype.toUpperCase(),
          body: String(row.text || row.content || gsUri || "").slice(0, 320),
          meta: [
            ["Type", dtype],
            row.document_id != null ? ["Doc ID", row.document_id] : null,
            sections.length ? ["Active Sections", sections.length] : null,
            row.file_name ? ["File", row.file_name] : null,
          ].filter(Boolean),
        });

        sections.forEach((sec, sIdx) => {
          const sid = sec.section_id ?? sIdx + 1;
          const stitle = String(sec.section_title || sec.title || `Section ${sid}`).trim();
          const secKey = sec.node_id ? `sec:${sec.node_id}` : `sec:${dtype}:${docName}:${sid}:${stitle.slice(0, 32)}`;
          rows.push({
            key: secKey,
            title: `${docName} › ${stitle}`,
            tag: `${dtype.toUpperCase()} §${sid}`,
            body: String(sec.section_path || sec.original_text || stitle).slice(0, 260),
            meta: [
              ["Section ID", sid],
              sec.page_start != null ? ["Page", sec.page_start] : null,
              sec.node_id ? ["Node", sec.node_id] : null,
            ].filter(Boolean),
          });
        });
      });
      return rows;
    }

    if (artifactId === "findings_details") {
      const rawList = Array.isArray(data.findings_details)
        ? data.findings_details
        : Array.isArray(data)
        ? data
        : [];
      const rows = [];
      rawList.forEach((wrapper, wIdx) => {
        if (!wrapper || typeof wrapper !== "object" || isExcludedStatus(wrapper)) return;
        const list = Array.isArray(wrapper.responsePayload) ? wrapper.responsePayload : [wrapper];
        list.forEach((f, idx) => {
          if (!f || typeof f !== "object" || isExcludedStatus(f)) return;
          const fid = f.findingId || f.id || `${wIdx}-${idx}`;
          const rawTitle = !isMaskedPlaceholder(f.findingTitle)
            ? f.findingTitle
            : !isMaskedPlaceholder(f.title)
            ? f.title
            : f.ct1 || f.subBusinessArea || f.businessArea || "Open Finding";
          const rawBody = !isMaskedPlaceholder(f.findingDescription)
            ? f.findingDescription
            : !isMaskedPlaceholder(f.findingExecutiveSummary)
            ? f.findingExecutiveSummary
            : [f.riskTaxonomy ? `Risk: ${f.riskTaxonomy}` : "", f.findingRootCause ? `Root Cause: ${f.findingRootCause}` : ""]
                .filter(Boolean)
                .join("\n") || "GFMS Finding";
          rows.push({
            key: `gfms:${fid}`,
            title: `Finding ${fid} — ${rawTitle}`,
            tag: [f.rating || f.findingRating || f.severity, f.findingStatus].filter(Boolean).join(" · ") || `ID ${fid}`,
            body: String(rawBody).slice(0, 320),
            meta: [
              ["Finding ID", fid],
              f.findingOwner ? ["Owner", f.findingOwner] : null,
              f.ct1 ? ["Control", f.ct1] : null,
              f.assuranceDate ? ["Assurance Date", f.assuranceDate] : null,
            ].filter(Boolean),
          });
        });
      });
      return rows;
    }

    if (artifactId === "historical_plan_details") {
      const list = Array.isArray(data.historical_plan_details)
        ? data.historical_plan_details
        : Array.isArray(data.items)
        ? data.items
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => {
          const pnum = item["Plan Item Number"] || item.plan_item_number || item.planNumber || String(idx + 1);
          const ptitle = item["Plan Item Title"] || item.plan_item_title || item.title || `Historical Plan ${pnum}`;
          return {
            key: `hist:${pnum}`,
            title: `Plan ${pnum}: ${ptitle}`,
            tag: [item["Plan Year"], item["Plan Item Type"] || item["Plan Item Status"]].filter(Boolean).join(" · ") || `Plan ${pnum}`,
            body: String(item["Description of Plan Item"] || item["Audit Objective"] || item.audit_objective || "Historical scoping plan record").slice(0, 320),
            meta: [
              item["Review Lead"] ? ["Lead", item["Review Lead"]] : null,
              item["Report Number"] ? ["Report #", item["Report Number"]] : null,
              item["UoT Risk Type"] ? ["Risk", item["UoT Risk Type"]] : null,
            ].filter(Boolean),
          };
        });
    }

    if (artifactId === "lrr") {
      const arr = Array.isArray(data.internet_search_data_enriched)
        ? data.internet_search_data_enriched
        : Array.isArray(data.internet_search_data)
        ? data.internet_search_data
        : Array.isArray(data.lrr)
        ? data.lrr
        : Array.isArray(data.documents)
        ? data.documents
        : Array.isArray(data)
        ? data
        : [];
      const rows = [];
      let mandateCounter = 0;
      arr.forEach((entry, idx) => {
        if (!entry || typeof entry !== "object" || isExcludedStatus(entry)) return;
        if (Array.isArray(entry.Mandates)) {
          const riskName = entry["Risk Name"] || entry.risk_name || `Risk ${idx + 1}`;
          entry.Mandates.forEach((m) => {
            if (!m || typeof m !== "object" || isExcludedStatus(m)) return;
            mandateCounter += 1;
            const mtitle = m["Regulatory Mandate"] || m.mandate || m.Citation || `Mandate ${mandateCounter}`;
            const firstEv = Array.isArray(m.Evidence) && m.Evidence[0] ? m.Evidence[0] : null;
            rows.push({
              key: String(m.node_id || `lrr:mandate:${mandateCounter}:${String(mtitle).slice(0, 40)}`),
              title: String(mtitle).slice(0, 140),
              tag: `${riskName}${m["Confidence Score"] != null ? ` · ${m["Confidence Score"]}` : ""}`,
              body: String(m["AI Rationale"] || m["Applicability Summary"] || firstEv?.evidence_text || "Regulatory mandate").slice(0, 320),
              meta: [
                ["Mandate #", mandateCounter],
                firstEv?.source_url ? ["Source", firstEv.source_url] : null,
                m.Jurisdiction ? ["Jurisdiction", m.Jurisdiction] : null,
              ].filter(Boolean),
            });
          });
        } else {
          mandateCounter += 1;
          const title = entry["Regulatory Mandate"] || entry.title || entry.document_title || `LRR Entry ${mandateCounter}`;
          rows.push({
            key: String(entry.node_id || `lrr:entry:${mandateCounter}:${String(title).slice(0, 40)}`),
            title,
            tag: entry["Risk Name"] || entry.document_type || "LRR",
            body: String(entry["AI Rationale"] || entry.summary || entry.Citation || "").slice(0, 320),
            meta: [
              entry.Regulator ? ["Regulator", entry.Regulator] : null,
              entry.Citation ? ["Citation", entry.Citation] : null,
            ].filter(Boolean),
          });
        }
      });
      return rows;
    }

    if (artifactId === "current_details") {
      const planObj = data.plan_details && typeof data.plan_details === "object"
        ? data.plan_details
        : Array.isArray(data)
        ? data[0]
        : data;
      if (!planObj || typeof planObj !== "object" || Array.isArray(planObj)) return [];
      const pnum = planObj["Plan Item Number"] || state.planNumber;
      const rows = [
        {
          key: `current:plan:${pnum}`,
          title: planObj["Plan Item Title"] || `Plan ${pnum}`,
          tag: `Plan ${pnum} · ${planObj["Plan Item Status"] || "Active"}`,
          body: String(planObj["Description of Plan Item"] || "").slice(0, 320),
          meta: [
            planObj["AU Region"] ? ["Region", planObj["AU Region"]] : null,
            planObj["Plan Year"] ? ["Year", planObj["Plan Year"]] : null,
            planObj["Review Lead"] ? ["Lead", planObj["Review Lead"]] : null,
            planObj["UoT Risk Type"] ? ["Risk Type", planObj["UoT Risk Type"]] : null,
          ].filter(Boolean),
        },
      ];
      if (Array.isArray(planObj["AU-RT-KC"])) {
        planObj["AU-RT-KC"].forEach((mapping, idx) => {
          rows.push({
            key: `current:aurtkc:${idx}:${mapping.KC || ""}`,
            title: mapping.AU || `Assessment Unit Mapping #${idx + 1}`,
            tag: `${mapping.RT || "Risk"} · ${mapping.KC || "KC"}`,
            body: `Mapped Assessment Unit to Risk Type ${mapping.RT || ""} and Key Control ${mapping.KC || ""}`,
            meta: [
              mapping.RT ? ["Risk Type", mapping.RT] : null,
              mapping.KC ? ["Key Control", mapping.KC] : null,
            ].filter(Boolean),
          });
        });
      }
      return rows;
    }

    if (artifactId === "alc_nlac") {
      const list = Array.isArray(data.alc_nalc_details)
        ? data.alc_nalc_details
        : Array.isArray(data.alc_nlac)
        ? data.alc_nlac
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => ({
          key: `alc:${item.id || idx}`,
          title: String(item.title || item.name || item.plan_item_title || `ALC/NALC Record #${idx + 1}`),
          tag: String(item.type || item.status || "ALC/NALC"),
          body: String(item.description || item.summary || item.rationale || "").slice(0, 320),
          meta: Object.entries(item)
            .filter(([, v]) => v != null && typeof v !== "object" && String(v).length < 60)
            .slice(0, 4),
        }));
    }

    if (artifactId === "control_details") {
      const ctrlRoot = data.control_details && typeof data.control_details === "object" ? data.control_details : data;
      const included = Array.isArray(ctrlRoot?.included_kcs)
        ? ctrlRoot.included_kcs
        : Array.isArray(ctrlRoot)
        ? ctrlRoot
        : [];
      return included
        .filter((c) => c && typeof c === "object" && !isExcludedStatus(c))
        .map((c, idx) => {
          const inv = c.inventory && typeof c.inventory === "object" ? c.inventory : c;
          const defn = c.definition && typeof c.definition === "object" ? c.definition : {};
          const obj = c.objective && typeof c.objective === "object" ? c.objective : {};
          const instNo = inv.controlInstanceNumber || inv.controlDefinitionNumber || idx;
          return {
            key: `ctrl:${instNo}`,
            title: `${inv.controlDefinitionNumber || "Control"}: ${inv.controlDefinitionName || inv.controlInstanceName || "Control"}`,
            tag: [inv.classification || defn.classification, inv.assessmentUnitDer].filter(Boolean).join(" · ") || "Included KC",
            body: String(inv.controlWhat || defn.description || inv.controlDescription || "").slice(0, 320),
            meta: [
              ["Instance", instNo],
              inv.controlFrequency ? ["Frequency", inv.controlFrequency] : null,
              inv.operatingControlOwner ? ["Owner", inv.operatingControlOwner] : null,
              obj.controlObjectiveNumber ? ["Objective", obj.controlObjectiveNumber] : null,
            ].filter(Boolean),
          };
        });
    }

    if (artifactId === "risk_driver_details") {
      const list = Array.isArray(data.risk_driver_details)
        ? data.risk_driver_details
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => {
          const rid = item.riskid || item.risk_id || item.id || String(idx + 1);
          const drivers = Array.isArray(item.risk_drivers) ? item.risk_drivers : [];
          return {
            key: `risk:${rid}:${idx}`,
            title: `${rid} — ${item.risk_name || item.title || "Risk Type"}`,
            tag: `${drivers.length} risk driver(s)`,
            body: drivers.length
              ? drivers.map((d) => d.name || d.title || JSON.stringify(d)).join("; ").slice(0, 320)
              : `Mapped risk taxonomy ${rid} (${item.risk_name || ""}) with no granular risk drivers returned.`,
            meta: [["Risk ID", rid]],
          };
        });
    }

    if (artifactId === "group_audit") {
      const list = Array.isArray(data.group_audit_details)
        ? data.group_audit_details
        : Array.isArray(data)
        ? data
        : [];
      return list
        .filter((x) => x && typeof x === "object" && !isExcludedStatus(x))
        .map((item, idx) => ({
          key: `ga:${item.auditId || item.id || idx}`,
          title: String(item.auditName || item.title || `Group Audit #${idx + 1}`),
          tag: String(item.auditNumber || item.status || "Group Audit"),
          body: String(item.summary || item.description || "").slice(0, 320),
          meta: [],
        }));
    }

    return [];
  }

  function renderArtifactTabs(deltasByArtifact = {}) {
    els.artifactTabs.innerHTML = "";
    let availableFeeds = 0;

    for (const def of state.artifactDefs) {
      const payload = state.artifacts[def.id];
      const records = payload ? extractArtifactRecords(def.id, payload) : [];
      if (payload !== undefined && payload !== null) {
        availableFeeds += 1;
      }

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "artifact-tab";
      if (def.id === state.activeArtifact) btn.classList.add("is-active");
      if (deltasByArtifact[def.id]) btn.classList.add("has-delta");
      btn.dataset.artifact = def.id;
      btn.innerHTML = `<span>${escapeHtml(def.label)}</span><span class="tab-count">${records.length}</span>`;
      btn.addEventListener("click", () => {
        if (state.activeArtifact === def.id) return;
        state.activeArtifact = def.id;
        renderArtifactTabs();
        renderActiveArtifactFeed(false);
      });
      els.artifactTabs.appendChild(btn);
    }

    els.kpiFeedCount.textContent = `${availableFeeds} / ${state.artifactDefs.length}`;
  }

  function buildCardSlot(record, isEntering) {
    const slot = document.createElement("div");
    slot.className = isEntering ? "feed-card-slot is-entering is-highlight" : "feed-card-slot";
    slot.dataset.itemKey = record.key;

    const metaHtml = (record.meta || [])
      .map(([k, v]) => `<span><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v)}</span>`)
      .join("");

    slot.innerHTML = `
      <div class="feed-card-slot-inner">
        <article class="feed-card">
          <div class="feed-card-head">
            <h3 class="feed-card-title">${escapeHtml(record.title)}</h3>
            <span class="feed-card-tag">${escapeHtml(record.tag)}</span>
          </div>
          ${record.body ? `<div class="feed-card-body">${escapeHtml(record.body)}</div>` : ""}
          ${metaHtml ? `<div class="feed-kv-grid">${metaHtml}</div>` : ""}
        </article>
      </div>
    `;
    return slot;
  }

  function renderActiveArtifactFeed(animateTransitions = true) {
    const artifactId = state.activeArtifact;
    const payload = state.artifacts[artifactId];
    const errMsg = state.errors[artifactId];
    const records = payload ? extractArtifactRecords(artifactId, payload) : [];

    els.kpiActiveFeedCount.textContent = String(records.length);
    els.rawJsonPre.textContent = payload !== undefined ? JSON.stringify(payload, null, 2) : `// ${errMsg || "No payload available"}`;

    const def = state.artifactDefs.find((d) => d.id === artifactId);
    let extraNote = "";
    if (artifactId === "control_details") {
      const exLen = unwrapEnvelope(payload)?.control_details?.excluded_kcs?.length || 0;
      if (exLen) extraNote = ` (${exLen} retired KC in dbGRC)`;
    }
    els.feedDescription.textContent = errMsg
      ? `Feed notice: ${errMsg}`
      : `${def ? def.label : artifactId} — ${records.length} active record(s) sent downstream${extraNote}`;
    els.feedSourceBadge.textContent = errMsg ? "Unavailable" : "CT1 Live";

    const prevKeys = state.prevArtifactKeys[artifactId] || new Set(records.map((r) => r.key));
    const nextKeys = new Set(records.map((r) => r.key));
    const addedCount = records.filter((r) => !prevKeys.has(r.key)).length;
    const removedCount = [...prevKeys].filter((k) => !nextKeys.has(k)).length;
    state.prevArtifactKeys[artifactId] = nextKeys;

    if (animateTransitions && (addedCount > 0 || removedCount > 0)) {
      const parts = [];
      if (removedCount > 0) parts.push(`-${removedCount} excluded`);
      if (addedCount > 0) parts.push(`+${addedCount} included`);
      els.deltaPill.textContent = parts.join(" · ");
      els.deltaPill.classList.add("is-visible");
    } else if (!animateTransitions) {
      els.deltaPill.classList.remove("is-visible");
    }

    const container = els.cardsContainer;

    if (!records.length && !animateTransitions) {
      container.innerHTML = `<div class="empty-state">${escapeHtml(errMsg || "No active records in this artifact feed.")}</div>`;
      return;
    }

    const existingSlots = new Map();
    container.querySelectorAll(".feed-card-slot:not(.is-exiting)").forEach((el) => {
      existingSlots.set(el.dataset.itemKey, el);
    });

    if (!animateTransitions || existingSlots.size === 0) {
      container.innerHTML = "";
      if (!records.length) {
        container.innerHTML = `<div class="empty-state">${escapeHtml(errMsg || "No active records in this artifact feed.")}</div>`;
        return;
      }
      const frag = document.createDocumentFragment();
      records.forEach((rec) => frag.appendChild(buildCardSlot(rec, false)));
      container.appendChild(frag);
      return;
    }

    const firstRects = new Map();
    existingSlots.forEach((el, key) => {
      firstRects.set(key, el.getBoundingClientRect());
    });

    container.querySelectorAll(".empty-state").forEach((n) => n.remove());

    const exitingNodes = [];
    existingSlots.forEach((el, key) => {
      if (!nextKeys.has(key)) {
        el.classList.add("is-exiting");
        exitingNodes.push(el);
      }
    });

    const newSlots = [];
    records.forEach((rec) => {
      const existing = existingSlots.get(rec.key);
      if (existing) {
        container.appendChild(existing);
      } else {
        const slot = buildCardSlot(rec, true);
        container.appendChild(slot);
        newSlots.push(slot);
      }
    });

    existingSlots.forEach((el, key) => {
      if (!nextKeys.has(key)) return;
      const first = firstRects.get(key);
      const last = el.getBoundingClientRect();
      if (!first || !last) return;
      const dy = first.top - last.top;
      if (Math.abs(dy) > 1) {
        el.style.transition = "none";
        el.style.transform = `translate3d(0, ${dy}px, 0)`;
        requestAnimationFrame(() => {
          el.style.transition = "";
          el.style.transform = "translate3d(0, 0, 0)";
        });
      }
    });

    if (newSlots.length > 0) {
      requestAnimationFrame(() => {
        newSlots.forEach((slot) => {
          slot.classList.remove("is-entering");
          slot.classList.add("is-entered");
          window.setTimeout(() => slot.classList.remove("is-highlight"), 1400);
        });
      });
    }

    if (exitingNodes.length > 0) {
      window.setTimeout(() => {
        exitingNodes.forEach((node) => node.remove());
        if (records.length === 0 && !container.querySelector(".feed-card-slot")) {
          container.innerHTML = `<div class="empty-state">All items in this feed have been excluded for downstream agents.</div>`;
        }
      }, 360);
    } else if (records.length === 0) {
      container.innerHTML = `<div class="empty-state">All items in this feed have been excluded for downstream agents.</div>`;
    }
  }

  async function refreshPlanData(planNumber, { animate = false, silentBanner = false } = {}) {
    state.planNumber = planNumber;
    els.mentionPlanTag.textContent = planNumber;
    if (!silentBanner) {
      setStatus("loading", `Syncing plan ${planNumber} from CT1 (${state.ctaHost || "live"})...`);
    } else {
      setStatus("loading", null);
    }

    const endpoint = `/api/ct1/plan/${encodeURIComponent(planNumber)}/bootstrap`;
    try {
      const resp = await fetch(endpoint);
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "bootstrap", endpoint);
        setStatus("error", `CT1 sync error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return false;
      }

      const deltas = {};
      for (const def of state.artifactDefs) {
        const nextPayload = data.artifacts ? data.artifacts[def.id] : undefined;
        const nextLen = nextPayload ? extractArtifactRecords(def.id, nextPayload).length : 0;
        const prevLen = state.prevCounts[def.id];
        if (animate && prevLen !== undefined && prevLen !== nextLen) {
          deltas[def.id] = nextLen - prevLen;
        }
        state.prevCounts[def.id] = nextLen;
      }

      state.catalog = data.catalog;
      state.availability = data.availability;
      state.artifacts = data.artifacts || {};
      state.errors = data.errors || {};
      state.ctaHost = data.cta_host || state.ctaHost;
      state.queryMode = data.query_mode || "";

      const hasErrors = Boolean(
        data.has_errors ||
          (Array.isArray(data.error_details) && data.error_details.length > 0) ||
          Object.keys(state.errors).length > 0
      );
      const modeLabel = state.queryMode === "error"
        ? "Query Service ERROR"
        : state.queryMode
        ? `Query Service (${state.queryMode})`
        : "Query Service live";
      els.ct1HostBadge.textContent = `${state.ctaHost} · Plan ${planNumber} · ${modeLabel}`;
      els.kpiLatency.textContent = `${data.latency_ms ?? "--"} ms`;

      state.mentionItems = buildMentionCatalog(state.catalog);
      updateCatalogSummary(state.catalog);
      renderArtifactTabs(deltas);
      renderActiveArtifactFeed(animate);

      if (hasErrors) {
        const errInfo = normalizeErrorPayload(resp, data, "bootstrap", endpoint);
        errInfo.title = `CT1 Sync Partial Error (Plan ${planNumber})`;
        errInfo.message =
          Object.entries(state.errors)
            .map(([k, v]) => `${k}: ${v}`)
            .join("\n") || "One or more CT1 upstream endpoints returned an error.";
        setStatus("error", `CT1 sync encountered ${errInfo.failures.length || Object.keys(state.errors).length} upstream error(s).`);
        showErrorModal(errInfo);
        return false;
      }

      setStatus("ok", null);
      return true;
    } catch (err) {
      const errInfo = normalizeErrorPayload(
        null,
        { error: err.message, exception_type: err.name || "Error", endpoint },
        "bootstrap",
        endpoint
      );
      setStatus("error", `CT1 sync error: ${err.message}`);
      showErrorModal(errInfo);
      return false;
    }
  }

  function appendChatMessage({ role, text, workflow = null, errorInfo = null, isWelcome = false }) {
    const wrapper = document.createElement("div");
    wrapper.className = `chat-msg ${role === "user" ? "is-user" : "is-assistant"}`;

    const label = document.createElement("div");
    label.className = "msg-role";
    label.textContent = role === "user" ? "You" : isWelcome ? "CT1 Scoping Query Agent" : "CT1 Query Agent";
    wrapper.appendChild(label);

    const bubble = document.createElement("div");
    bubble.className = "msg-bubble";
    if (role === "user") {
      bubble.innerHTML = formatRichUserText(text);
    } else {
      bubble.textContent = text;
    }

    if (workflow && typeof workflow === "object" && (workflow.stage || workflow.status || workflow.plan || workflow.actions)) {
      bubble.appendChild(buildWorkflowCard(workflow, errorInfo));
    } else if (errorInfo) {
      const errBtnRow = document.createElement("div");
      errBtnRow.className = "workflow-card-actions";
      errBtnRow.style.marginTop = "8px";
      const viewErrBtn = document.createElement("button");
      viewErrBtn.type = "button";
      viewErrBtn.className = "btn btn-error-details btn-xs";
      viewErrBtn.textContent = "View Error Details";
      viewErrBtn.addEventListener("click", () => showErrorModal(errorInfo));
      errBtnRow.appendChild(viewErrBtn);
      bubble.appendChild(errBtnRow);
    }

    wrapper.appendChild(bubble);
    els.chatStream.appendChild(wrapper);
    requestAnimationFrame(() => {
      els.chatStream.scrollTo({ top: els.chatStream.scrollHeight, behavior: "smooth" });
    });
  }

  function buildWorkflowCard(workflow, errorInfo = null) {
    const stage = String(workflow.stage || "").toLowerCase();
    const wfStatus = String(workflow.status || "").toLowerCase();
    const execStatus = String((workflow.execution && workflow.execution.status) || "").toLowerCase();
    const isError = Boolean(
      errorInfo ||
        stage === "error" ||
        stage === "partial_failure" ||
        wfStatus === "error" ||
        wfStatus === "partial_failure" ||
        execStatus === "error" ||
        execStatus === "partial_failure" ||
        (workflow.execution && workflow.execution.registry_updated === false)
    );
    const needsApproval =
      !isError &&
      (stage === "awaiting_approval" ||
        stage === "pending_approval" ||
        (Boolean(workflow.requires_approval) &&
          stage !== "executed" &&
          stage !== "cancelled" &&
          stage !== "rejected"));
    const card = document.createElement("div");
    card.className = "workflow-card";
    if (isError) card.classList.add("is-error");
    else if (stage === "executed") card.classList.add("is-executed");
    if (stage === "cancelled" || stage === "rejected") card.classList.add("is-cancelled");

    const actions =
      (workflow.plan && Array.isArray(workflow.plan.actions) && workflow.plan.actions) ||
      (Array.isArray(workflow.steps) ? workflow.steps : null) ||
      (workflow.execution && Array.isArray(workflow.execution.executed) && workflow.execution.executed.length
        ? workflow.execution.executed
        : null) ||
      (workflow.execution_json && Array.isArray(workflow.execution_json.actions) ? workflow.execution_json.actions : null) ||
      (Array.isArray(workflow.executed) && workflow.executed.length ? workflow.executed : null) ||
      (Array.isArray(workflow.actions) ? workflow.actions : []);

    const stageLabel = isError
      ? stage === "partial_failure" || wfStatus === "partial_failure"
        ? "Partial Failure"
        : "Execution Failed"
      : needsApproval
      ? "Approval Required"
      : stage === "executed"
      ? "Executed"
      : stage === "cancelled" || stage === "rejected"
      ? "Cancelled"
      : stage || "Workflow";

    const itemsHtml = actions
      .map((act) => {
        const op = String(act.action || "exclude").toLowerCase();
        const opClass = op === "include" || op === "restore" ? "op-include" : "op-exclude";
        const target = act.section_title ? `${act.title} › ${act.section_title}` : act.title || act.filename || "Target";
        const meta = [act.document_type, act.row_primary_key ? `PK ${act.row_primary_key}` : null]
          .filter(Boolean)
          .join(" · ");
        return `
          <div class="workflow-action-item">
            <div>
              <strong>${escapeHtml(target)}</strong>
              ${meta ? `<div style="font-size:11px;color:#64748b;margin-top:2px;">${escapeHtml(meta)}</div>` : ""}
            </div>
            <span class="action-op-pill ${opClass}">${escapeHtml(op)}</span>
          </div>
        `;
      })
      .join("");

    card.innerHTML = `
      <div class="workflow-card-head">
        <span style="font-size:12px;font-weight:700;color:#1e293b;">Document Scope Plan</span>
        <span class="workflow-stage-badge">${escapeHtml(stageLabel)}</span>
      </div>
      ${itemsHtml ? `<div class="workflow-action-list">${itemsHtml}</div>` : ""}
    `;

    if (isError) {
      const btnRow = document.createElement("div");
      btnRow.className = "workflow-card-actions";
      const errBtn = document.createElement("button");
      errBtn.type = "button";
      errBtn.className = "btn btn-error-details btn-xs";
      errBtn.textContent = "View Error Details";
      errBtn.addEventListener("click", () => {
        showErrorModal(
          errorInfo ||
            normalizeErrorPayload(null, { document_workflow: workflow, error: workflow.message || stageLabel }, "query_chat", "/api/ct1/query/chat")
        );
      });
      btnRow.appendChild(errBtn);
      card.appendChild(btnRow);
    } else if (needsApproval) {
      const btnRow = document.createElement("div");
      btnRow.className = "workflow-card-actions";

      const approveBtn = document.createElement("button");
      approveBtn.type = "button";
      approveBtn.className = "btn btn-approve btn-xs";
      approveBtn.textContent = "Approve & Execute";

      const rejectBtn = document.createElement("button");
      rejectBtn.type = "button";
      rejectBtn.className = "btn btn-reject btn-xs";
      rejectBtn.textContent = "Cancel Plan";

      approveBtn.addEventListener("click", () => {
        approveBtn.disabled = true;
        rejectBtn.disabled = true;
        sendChatTurn("approve");
      });
      rejectBtn.addEventListener("click", () => {
        approveBtn.disabled = true;
        rejectBtn.disabled = true;
        sendChatTurn("cancel");
      });

      btnRow.appendChild(approveBtn);
      btnRow.appendChild(rejectBtn);
      card.appendChild(btnRow);
    }

    return card;
  }

  async function sendChatTurn(questionText) {
    const trimmed = questionText.trim();
    if (!trimmed || state.isBusy) return;

    closeMentionPopover();
    appendChatMessage({ role: "user", text: trimmed });
    els.chatInput.value = "";
    autoResizeTextarea();

    state.isBusy = true;
    els.sendBtn.disabled = true;
    setStatus("loading", "Waiting for Query Agent response...");

    const endpoint = "/api/ct1/query/chat";
    try {
      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: trimmed,
          plan_number: state.planNumber,
          context_type: "Preliminary Research Walkthrough",
        }),
      });
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "query_chat", endpoint);
        appendChatMessage({
          role: "assistant",
          text: `Error: ${errInfo.message}`,
          errorInfo: errInfo,
        });
        setStatus("error", `Query error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }

      const wf = data.document_workflow || null;
      const stage = wf && String(wf.stage || "").toLowerCase();
      const wfStatus = wf && String(wf.status || "").toLowerCase();
      const execStatus = wf && wf.execution && String(wf.execution.status || "").toLowerCase();
      const hasWfError = Boolean(
        data.error_details ||
          stage === "error" ||
          stage === "partial_failure" ||
          wfStatus === "error" ||
          wfStatus === "partial_failure" ||
          execStatus === "error" ||
          execStatus === "partial_failure" ||
          (wf && wf.execution && wf.execution.registry_updated === false)
      );

      if (hasWfError) {
        const errInfo = normalizeErrorPayload(resp, data, "query_chat", endpoint);
        appendChatMessage({
          role: "assistant",
          text: data.answer || errInfo.message,
          workflow: wf,
          errorInfo: errInfo,
        });
        if (stage === "partial_failure" || wfStatus === "partial_failure") {
          await refreshPlanData(state.planNumber, { animate: true, silentBanner: true });
        }
        setStatus("error", `Execution error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }

      appendChatMessage({
        role: "assistant",
        text: data.answer || "(No answer text returned)",
        workflow: wf,
      });

      if (stage === "executed" || (wf && wf.execution_result)) {
        const execList =
          wf.executed ||
          (wf.execution && wf.execution.executed) ||
          (wf.execution_json && wf.execution_json.actions) ||
          wf.actions ||
          wf.steps ||
          (wf.plan && wf.plan.actions) ||
          [];
        const targetTabs = execList
          .map((a) => DOC_TYPE_TO_ARTIFACT[String(a.document_type || "").toLowerCase()])
          .filter(Boolean);
        if (targetTabs.length && !targetTabs.includes(state.activeArtifact)) {
          state.activeArtifact = targetTabs[0];
        }
        await refreshPlanData(state.planNumber, { animate: true, silentBanner: true });
      } else {
        setStatus("ok", null);
      }
    } catch (err) {
      const errInfo = normalizeErrorPayload(
        null,
        { error: err.message, exception_type: err.name || "Error", endpoint },
        "query_chat",
        endpoint
      );
      appendChatMessage({
        role: "assistant",
        text: `Unable to complete request: ${err.message}`,
        errorInfo: errInfo,
      });
      setStatus("error", `Query error: ${err.message}`);
      showErrorModal(errInfo);
    } finally {
      state.isBusy = false;
      els.sendBtn.disabled = false;
      els.chatInput.focus();
    }
  }

  // Predictive @ Autocomplete Engine
  function findActiveAtTrigger() {
    const val = els.chatInput.value;
    const pos = els.chatInput.selectionStart ?? val.length;
    const before = val.slice(0, pos);
    const lastAt = before.lastIndexOf("@");
    if (lastAt === -1) return null;
    if (lastAt > 0 && !/[\s(]/.test(before[lastAt - 1])) return null;
    const fragment = before.slice(lastAt + 1);
    if (fragment.includes("]") || fragment.includes("\n")) return null;
    return { start: lastAt, end: pos, query: fragment.trim().toLowerCase() };
  }

  function renderMentionList() {
    els.mentionList.innerHTML = "";
    if (state.filteredMentions.length === 0) {
      els.mentionList.innerHTML = `<div style="padding:14px;font-size:12px;color:#64748b;text-align:center;">No matching documents or sections in Plan ${escapeHtml(state.planNumber)}.</div>`;
      return;
    }

    state.filteredMentions.forEach((item, idx) => {
      const row = document.createElement("div");
      row.className = `mention-item${idx === state.mentionIndex ? " is-selected" : ""}`;
      row.setAttribute("role", "option");
      row.innerHTML = `
        <div class="mention-main">
          <div class="mention-title">${escapeHtml(item.title)}</div>
          <div class="mention-sub">${escapeHtml(item.subtitle)}</div>
        </div>
        <div class="mention-badges">
          <span class="pill-type">${escapeHtml(item.groupLabel)}</span>
          <span class="${item.excluded ? "pill-status-excluded" : "pill-status-active"}">${item.excluded ? "EXCLUDED" : "ACTIVE"}</span>
        </div>
      `;
      row.addEventListener("mouseenter", () => {
        state.mentionIndex = idx;
        highlightMentionSelection();
      });
      row.addEventListener("mousedown", (e) => {
        e.preventDefault();
        insertMention(item);
      });
      els.mentionList.appendChild(row);
    });
  }

  function highlightMentionSelection() {
    const children = els.mentionList.querySelectorAll(".mention-item");
    children.forEach((el, idx) => {
      el.classList.toggle("is-selected", idx === state.mentionIndex);
      if (idx === state.mentionIndex) {
        el.scrollIntoView({ block: "nearest" });
      }
    });
  }

  function openMentionPopover(query, anchorStart) {
    state.mentionAnchorStart = anchorStart;
    const textBefore = els.chatInput.value.slice(0, Math.max(0, anchorStart)).toLowerCase();
    const preferExcluded = /\b(include|restore|re-include|add back|reinstate)\b/.test(textBefore);

    const matches = state.mentionItems.filter((item) => !query || item.searchBlob.includes(query));
    matches.sort((a, b) => {
      if (preferExcluded && a.excluded !== b.excluded) return a.excluded ? -1 : 1;
      if (!preferExcluded && a.excluded !== b.excluded) return a.excluded ? 1 : -1;
      return 0;
    });

    state.filteredMentions = matches.slice(0, 24);
    state.mentionIndex = 0;
    state.mentionOpen = true;
    renderMentionList();
    els.mentionPopover.classList.add("is-open");
  }

  function closeMentionPopover() {
    state.mentionOpen = false;
    state.mentionAnchorStart = -1;
    els.mentionPopover.classList.remove("is-open");
  }

  function insertMention(item) {
    const val = els.chatInput.value;
    const pos = els.chatInput.selectionStart ?? val.length;
    const start = state.mentionAnchorStart >= 0 ? state.mentionAnchorStart : pos;
    const before = val.slice(0, start);
    const after = val.slice(pos);
    const token = `${item.mentionText} `;
    els.chatInput.value = `${before}${token}${after}`;
    const nextPos = before.length + token.length;
    els.chatInput.setSelectionRange(nextPos, nextPos);
    closeMentionPopover();
    autoResizeTextarea();
    els.chatInput.focus();
  }

  function autoResizeTextarea() {
    els.chatInput.style.height = "auto";
    els.chatInput.style.height = `${Math.min(els.chatInput.scrollHeight, 140)}px`;
  }

  async function triggerDataExtractionRun() {
    els.runExtractionBtn.disabled = true;
    setStatus("loading", `Starting CT1 data extraction for Plan ${state.planNumber}...`);
    const runEndpoint = "/api/ct1/dataextraction/run";
    try {
      const resp = await fetch(runEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planNumber: state.planNumber }),
      });
      const { parsed: data } = await readResponsePayload(resp);
      if (!resp.ok) {
        const errInfo = normalizeErrorPayload(resp, data, "dataextraction_run", runEndpoint);
        els.runExtractionBtn.disabled = false;
        setStatus("error", `Extraction launch error: ${errInfo.message}`);
        showErrorModal(errInfo);
        return;
      }

      const sessionId = data.session_id;
      if (!sessionId) {
        els.runExtractionBtn.disabled = false;
        await refreshPlanData(state.planNumber, { animate: true });
        return;
      }

      if (state.pollTimer) window.clearInterval(state.pollTimer);
      state.pollTimer = window.setInterval(async () => {
        const statusEndpoint = `/api/ct1/dataextraction/status/${encodeURIComponent(sessionId)}`;
        try {
          const stResp = await fetch(statusEndpoint);
          const { parsed: st } = await readResponsePayload(stResp);
          if (!stResp.ok) {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            const errInfo = normalizeErrorPayload(stResp, st, "dataextraction_status", statusEndpoint);
            setStatus("error", `Extraction status error: ${errInfo.message}`);
            showErrorModal(errInfo);
            return;
          }
          const curStatus = String((st && st.status) || "").toLowerCase();
          setStatus("loading", `CT1 Extraction (${(st && st.stage_name) || "running"}): ${curStatus || "in progress"}...`);

          if (curStatus === "completed" || curStatus === "done" || curStatus === "success") {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            await refreshPlanData(state.planNumber, { animate: true });
          } else if (curStatus === "failed" || curStatus === "error") {
            window.clearInterval(state.pollTimer);
            state.pollTimer = null;
            els.runExtractionBtn.disabled = false;
            const errInfo = normalizeErrorPayload(stResp, st, "dataextraction_status", statusEndpoint);
            errInfo.message = `Extraction failed: ${(st && (st.error || st.message)) || errInfo.message}`;
            setStatus("error", errInfo.message);
            showErrorModal(errInfo);
          }
        } catch (err) {
          window.clearInterval(state.pollTimer);
          state.pollTimer = null;
          els.runExtractionBtn.disabled = false;
          const errInfo = normalizeErrorPayload(
            null,
            { error: err.message, exception_type: err.name || "Error", endpoint: statusEndpoint },
            "dataextraction_status",
            statusEndpoint
          );
          setStatus("error", `Status poll error: ${err.message}`);
          showErrorModal(errInfo);
        }
      }, 2500);
    } catch (err) {
      els.runExtractionBtn.disabled = false;
      const errInfo = normalizeErrorPayload(
        null,
        { error: err.message, exception_type: err.name || "Error", endpoint: runEndpoint },
        "dataextraction_run",
        runEndpoint
      );
      setStatus("error", `Extraction launch error: ${err.message}`);
      showErrorModal(errInfo);
    }
  }

  function wireEvents() {
    els.planForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const nextPlan = els.planInput.value.trim();
      if (!nextPlan) return;
      state.prevCounts = {};
      state.prevArtifactKeys = {};
      await refreshPlanData(nextPlan, { animate: false });
    });

    els.refreshBtn.addEventListener("click", () => {
      refreshPlanData(state.planNumber, { animate: true });
    });

    els.runExtractionBtn.addEventListener("click", triggerDataExtractionRun);

    if (els.resetBtn) {
      els.resetBtn.addEventListener("click", async () => {
        const endpoint = `/api/ct1/plan/${encodeURIComponent(state.planNumber)}/reset`;
        setStatus("loading", `Clearing UI session state for Plan ${state.planNumber}...`);
        try {
          const resp = await fetch(endpoint, { method: "POST" });
          const { parsed: data } = await readResponsePayload(resp);
          if (!resp.ok) {
            const errInfo = normalizeErrorPayload(resp, data, "reset", endpoint);
            setStatus("error", `Reset failed: ${errInfo.message}`);
            showErrorModal(errInfo);
            return;
          }
          await refreshPlanData(state.planNumber, { animate: true });
          appendChatMessage({
            role: "assistant",
            text: `Refreshed live state for Plan ${state.planNumber} from CT1.`,
          });
        } catch (err) {
          const errInfo = normalizeErrorPayload(null, { error: err.message }, "reset", endpoint);
          setStatus("error", `Reset failed: ${err.message}`);
          showErrorModal(errInfo);
        }
      });
    }

    els.composerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      sendChatTurn(els.chatInput.value);
    });

    els.chatInput.addEventListener("input", () => {
      autoResizeTextarea();
      const trigger = findActiveAtTrigger();
      if (trigger) {
        openMentionPopover(trigger.query, trigger.start);
      } else {
        closeMentionPopover();
      }
    });

    els.chatInput.addEventListener("keydown", (e) => {
      if (state.mentionOpen) {
        if (e.key === "ArrowDown") {
          e.preventDefault();
          state.mentionIndex = (state.mentionIndex + 1) % Math.max(1, state.filteredMentions.length);
          highlightMentionSelection();
          return;
        }
        if (e.key === "ArrowUp") {
          e.preventDefault();
          const len = Math.max(1, state.filteredMentions.length);
          state.mentionIndex = (state.mentionIndex - 1 + len) % len;
          highlightMentionSelection();
          return;
        }
        if (e.key === "Enter" || e.key === "Tab") {
          if (state.filteredMentions[state.mentionIndex]) {
            e.preventDefault();
            insertMention(state.filteredMentions[state.mentionIndex]);
            return;
          }
        }
        if (e.key === "Escape") {
          e.preventDefault();
          closeMentionPopover();
          return;
        }
      }

      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendChatTurn(els.chatInput.value);
      }
    });

    els.triggerAtBtn.addEventListener("click", () => {
      const pos = els.chatInput.selectionStart ?? els.chatInput.value.length;
      const before = els.chatInput.value.slice(0, pos);
      const after = els.chatInput.value.slice(pos);
      const needsSpace = before.length > 0 && !/\s$/.test(before);
      const prefix = needsSpace ? " @" : "@";
      els.chatInput.value = `${before}${prefix}${after}`;
      const newPos = before.length + prefix.length;
      els.chatInput.setSelectionRange(newPos, newPos);
      openMentionPopover("", newPos - 1);
      els.chatInput.focus();
    });

    els.quickPrompts.querySelectorAll(".prompt-chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        const tmpl = chip.dataset.template || "";
        els.chatInput.value = tmpl;
        autoResizeTextarea();
        els.chatInput.focus();
        if (tmpl.endsWith(" ")) {
          const pos = tmpl.length;
          els.chatInput.value = `${tmpl}@`;
          els.chatInput.setSelectionRange(pos + 1, pos + 1);
          openMentionPopover("", pos);
        }
      });
    });

    els.attachBtn.addEventListener("click", () => els.fileInput.click());
    els.fileInput.addEventListener("change", () => {
      const files = Array.from(els.fileInput.files || []);
      if (files.length === 0) return;
      els.ingestFileNames.textContent = files.map((f) => f.name).join(", ");
      els.ingestDrawer.classList.add("is-open");
    });

    els.ingestCancelBtn.addEventListener("click", () => {
      els.fileInput.value = "";
      els.ingestDrawer.classList.remove("is-open");
    });

    els.ingestSubmitBtn.addEventListener("click", async () => {
      const files = Array.from(els.fileInput.files || []);
      if (!files.length) return;
      const form = new FormData();
      form.append("plan_number", state.planNumber);
      form.append("document_type", els.ingestDocType.value);
      files.forEach((f) => form.append("files", f));

      els.ingestSubmitBtn.disabled = true;
      setStatus("loading", `Uploading ${files.length} file(s) to CT1 RAG ingest...`);
      const ingestEndpoint = "/api/ct1/query/ingest";
      try {
        const resp = await fetch(ingestEndpoint, { method: "POST", body: form });
        const { parsed: data } = await readResponsePayload(resp);
        if (!resp.ok) {
          const errInfo = normalizeErrorPayload(resp, data, "rag_ingest_documents", ingestEndpoint);
          setStatus("error", `Ingest error: ${errInfo.message}`);
          showErrorModal(errInfo);
          return;
        }

        const docsSummary = Array.isArray(data.documents)
          ? data.documents
              .map((d) => `${d.document_title || d.file_name} (${d.document_type || "policy"}, ${d.section_count || 1} section(s))`)
              .join("; ")
          : (data.files_uploaded || []).join(", ");
        const idsText =
          Array.isArray(data.document_ids) && data.document_ids.length
            ? ` · doc_ids=[${data.document_ids.join(", ")}]`
            : "";

        appendChatMessage({
          role: "assistant",
          text:
            `Document ingest complete (${data.status}, job_id=${data.job_id || "n/a"}${idsText}).\n` +
            `Stored in: Policies / KOD / Proc (${docsSummary || data.document_type || "policy"}).\n` +
            `${data.message || ""} Tip: type @ in the composer to reference or exclude the indexed document or sections.`,
        });
        els.fileInput.value = "";
        els.ingestDrawer.classList.remove("is-open");
        state.activeArtifact = data.stored_in_artifact || "policy";
        await refreshPlanData(state.planNumber, { animate: true });
      } catch (err) {
        const errInfo = normalizeErrorPayload(
          null,
          { error: err.message, exception_type: err.name || "Error", endpoint: ingestEndpoint },
          "rag_ingest_documents",
          ingestEndpoint
        );
        setStatus("error", `Ingest error: ${err.message}`);
        showErrorModal(errInfo);
      } finally {
        els.ingestSubmitBtn.disabled = false;
      }
    });

    document.querySelectorAll(".seg-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const mode = btn.dataset.view || "cards";
        state.viewMode = mode;
        document.querySelectorAll(".seg-btn").forEach((b) => {
          const active = b.dataset.view === mode;
          b.classList.toggle("is-active", active);
          b.setAttribute("aria-selected", String(active));
        });
        els.segmented.classList.toggle("is-json", mode === "json");
        els.feedViewport.classList.toggle("is-json-mode", mode === "json");
      });
    });

    if (els.errorModalCloseBtn) els.errorModalCloseBtn.addEventListener("click", closeErrorModal);
    if (els.errorModalDismissBtn) els.errorModalDismissBtn.addEventListener("click", closeErrorModal);
    if (els.errorModalBackdrop) {
      els.errorModalBackdrop.addEventListener("click", (e) => {
        if (e.target === els.errorModalBackdrop) closeErrorModal();
      });
    }
    if (els.errorModalCopyBtn) {
      els.errorModalCopyBtn.addEventListener("click", async () => {
        const txt = els.errorModalDetailsPre ? els.errorModalDetailsPre.textContent : "";
        try {
          await navigator.clipboard.writeText(txt);
          els.errorModalCopyBtn.textContent = "Copied!";
          window.setTimeout(() => {
            els.errorModalCopyBtn.textContent = "Copy Full Error JSON";
          }, 1500);
        } catch (_) {
          // Ignore clipboard permission errors in non-HTTPS contexts
        }
      });
    }
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && els.errorModalBackdrop && !els.errorModalBackdrop.hidden) {
        closeErrorModal();
      }
    });

    document.addEventListener("click", (e) => {
      if (state.mentionOpen && !e.target.closest(".composer-dock")) {
        closeMentionPopover();
      }
    });
  }

  async function init() {
    wireEvents();
    appendChatMessage({
      role: "assistant",
      isWelcome: true,
      text: "Connected to CT1 Scoping endpoints. Type @ below to browse active or excluded documents, sections, findings, prior plans, and LRR mandates — propose an exclusion or restore, approve it inline, and view live Data Extraction feeds on the right. Any upstream or DB failure will open a full diagnostic pop-up.",
    });

    try {
      const cfgResp = await fetch("/api/config");
      const { parsed: cfg } = await readResponsePayload(cfgResp);
      if (cfgResp.ok && cfg && typeof cfg === "object") {
        state.ctaHost = cfg.cta_host || "";
        state.planNumber = cfg.default_plan_number || "20440";
        if (Array.isArray(cfg.artifacts) && cfg.artifacts.length) {
          state.artifactDefs = cfg.artifacts;
        }
        els.planInput.value = state.planNumber;
        els.ct1HostBadge.textContent = `${state.ctaHost} · Plan ${state.planNumber}`;
      } else {
        const errInfo = normalizeErrorPayload(cfgResp, cfg, "config", "/api/config");
        setStatus("error", `Config load failed: ${errInfo.message}`);
        showErrorModal(errInfo);
      }
    } catch (err) {
      const errInfo = normalizeErrorPayload(null, { error: err.message }, "config", "/api/config");
      setStatus("error", `Config load failed: ${err.message}`);
      showErrorModal(errInfo);
    }

    await refreshPlanData(state.planNumber, { animate: false });
  }

  init();
})();
