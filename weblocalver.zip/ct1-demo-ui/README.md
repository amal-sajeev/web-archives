# DBAware CT1 Live Include/Exclude & Data Extraction Demo UI

A clean, standalone demonstration interface that operates **purely over live CT1 endpoints** (`CTA_HOST`, defaulting to `https://ct1-cta.dbaware.dev.gcp.db.com`):

- **Left Pane — Scoping Query Agent (`POST /query-service/qna/chat`)**
  - Chat-first workflow where users request document or section exclusions/inclusions or ask RAG Q&A questions.
  - Predictive `@` autocomplete menu anchored directly above the input box, populated live from CT1 `POST /query-service/qna/documents/list-all` across **Policies**, **KOD**, **Procedures**, **GFMS Findings**, **Historical Scoping Plans**, and **LRR Mandates** (both active and excluded items).
  - Inline **Approve & Execute / Cancel Plan** workflow cards inside the assistant reply, plus optional file attachment for `POST /query-service/qna/documents/ingest`.

- **Right Pane — Data Extraction Downstream Feeds (`GET /scoping-dataextraction-agent/getdata/{plan}/{artifact}`)**
  - Displays the live payloads sent downstream to the other scoping agents across all 9 artifacts (`policy`, `findings_details`, `historical_plan_details`, `lrr`, `current_details`, `alc_nlac`, `control_details`, `risk_driver_details`, `group_audit`).
  - Smooth FLIP card reordering + slide-and-collapse exits on exclusion/restoration with a Structured Cards / Raw JSON view switch.

## Quick Start

```powershell
cd d:\Software\AI_ACCESS_LAYER_MANUAL\ct1-demo-ui
pip install -r requirements.txt
python server.py
```

Open `http://localhost:8095`.

### Optional Environment Variables

- `CTA_HOST` — Override target CT1 host (default: `https://ct1-cta.dbaware.dev.gcp.db.com`)
- `DEFAULT_PLAN_NUMBER` — Initial plan number on startup (default: `20440`)
- `PORT` — HTTP server port (default: `8095`)
