# DBAware CT1 Live Preliminary Research & Scope Curation Demo UI

A clean, standalone demonstration interface that exercises the **entire end-to-end Preliminary Research workflow** directly over live CT1 endpoints (`CTA_HOST`, defaulting to `https://ct1-cta.dbaware.dev.gcp.db.com`):

- **Left Pane — Scoping Query Agent (`POST /query-service/qna/chat`)**
  - Chat-first workflow to request document or section exclusions/inclusions or ask RAG Q&A questions aware of active Preliminary Research sections.
  - Predictive `@` autocomplete populated live from CT1 `POST /query-service/qna/documents/list-all` across **Policies**, **KOD**, **Procedures**, **GFMS Findings**, **Historical Scoping Plans**, and **LRR Mandates** (both active and excluded items).
  - Inline **Approve & Execute / Cancel Plan** workflow cards + RAG document upload via `/dbaware-rag-service-api-dev/ingest-documents` that automatically flag and (when enabled) regenerate affected Preliminary Research sections.

- **Right Pane — Preliminary Research Report & Data Extraction Feeds**
  - **Preliminary Research (`scoping-summary-agent` + `dbaware-api-gateway`)**:
    - Full & partial section generation (`past_review`, `policy_regulation`, `broad_scope`) via `POST /scoping-summary-agent/run-analytics-agent` (with `RUN_ANALYTICS` gateway fallback).
    - Auto-regeneration of affected sections immediately after chat exclusions/inclusions or document uploads.
    - Structured views for **Past Review Analysis**, **Policy, KOD & Regulatory Analysis**, and **Broad Scope Direction**, inline citation preview modal (`POST /scoping-summary-agent/get_document`), inline section editing (`POST /scoping-summary-agent/edit-preliminary-research-document`), PDF export (`POST /scoping-summary-agent/download`), and workflow acceptance (`ACCEPT_PRELIMINARY_RESEARCH`).
  - **Data Extraction Downstream Feeds (`GET /scoping-dataextraction-agent/getdata/{plan}/{artifact}`)**:
    - Inspect live payloads across all 9 artifacts (`policy`, `findings_details`, `historical_plan_details`, `lrr`, `current_details`, `alc_nlac`, `control_details`, `risk_driver_details`, `group_audit`) with smooth FLIP transitions.

## Quick Start

```powershell
cd d:\Software\AI_ACCESS_LAYER_MANUAL\ct1-demo-ui
pip install -r requirements.txt
python server.py
```

Open `http://localhost:8095`.

### Optional Environment Variables

- `CTA_HOST` — Override target CT1 host (default: `https://ct1-cta.dbaware.dev.gcp.db.com`)
- `SUMMARY_AGENT_URL` — Override Summary Agent URL (default: `${CTA_HOST}/scoping-summary-agent`)
- `GATEWAY_URL` — Override API Gateway URL (default: `${CTA_HOST}/dbaware-api-gateway`)
- `CT1_RC_TOKEN` — Optional `x-asm-rctoken` header forwarded on CT1 gateway requests
- `CT1_PR_TIMEOUT_SECONDS` — Timeout for Preliminary Research generation requests (default: `600`)
- `DEFAULT_PLAN_NUMBER` — Initial plan number on startup (default: `20440`)
- `PORT` — HTTP server port (default: `8095`)
