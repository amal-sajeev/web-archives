"""
CT1 Live Preliminary Research, Include/Exclude & Data Extraction Demo Server.

API Gateway-only FastAPI proxy over live CT1 endpoints (zero direct subagent calls, zero mocks):
  - GET  /dbaware-api-gateway/api/v1/task/status/{plan_number}
  - POST /dbaware-api-gateway/api/v1/actions
      (GET_PLAN_AVAILABILITY, GET_PLAN_ARTIFACT, DATA_EXTRACTION, GET_DATA_EXTRACTION_STATUS,
       QNA_LIST_DOCUMENTS, QNA_CHAT, DOCUMENT_ADD_REMOVE, QNA_GET_INGEST_JOB_STATUS,
       QNA_GET_RELEVANT_DATA, GET_PRELIMINARY_RESEARCH_DOCUMENT, RUN_ANALYTICS,
       EDIT_PRELIMINARY_RESEARCH_DOCUMENT, GET_CITATION_DOCUMENT, ACCEPT_PRELIMINARY_RESEARCH)
  - POST /dbaware-api-gateway/api/v1/actions/upload
      (QNA_INGEST_DOCUMENTS multipart with multi-file `file_types`, UPLOAD_ADDITIONAL_CONTEXT)
  - POST /dbaware-api-gateway/api/v1/actions/download
      (DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT)
"""

from __future__ import annotations

import asyncio
import base64
from collections import deque
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any, Deque, Dict, List, NoReturn, Optional, Set, Tuple
from urllib.parse import urlencode

import httpx
from fastapi import FastAPI, File, Form, HTTPException, Query, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ct1-demo-ui")

CTA_HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com").rstrip("/")
GATEWAY_BASE = os.getenv(
    "GATEWAY_URL", f"{CTA_HOST}/dbaware-api-gateway"
).rstrip("/")
DEFAULT_PLAN_NUMBER = os.getenv("DEFAULT_PLAN_NUMBER", "20440")
REQUEST_TIMEOUT_SECONDS = float(os.getenv("CT1_TIMEOUT_SECONDS", "120.0"))
PRELIMINARY_RESEARCH_TIMEOUT_SECONDS = float(os.getenv("CT1_PR_TIMEOUT_SECONDS", "600.0"))
PR_PROXY_DROP_RETRY_AFTER_SECONDS = float(os.getenv("CT1_PR_PROXY_DROP_AFTER_SECONDS", "15.0"))
PR_POLL_INTERVAL_SECONDS = float(os.getenv("CT1_PR_POLL_INTERVAL_SECONDS", "10.0"))
RAG_INGEST_POLL_TIMEOUT_SECONDS = float(os.getenv("CT1_RAG_INGEST_POLL_TIMEOUT_SECONDS", "300.0"))
RAG_INGEST_POLL_INTERVAL_SECONDS = float(os.getenv("CT1_RAG_INGEST_POLL_INTERVAL_SECONDS", "2.0"))
TASK_STATUS_TIMEOUT_SECONDS = float(os.getenv("CT1_TASK_STATUS_TIMEOUT_SECONDS", "10.0"))
RETRY_MAX_ATTEMPTS = max(1, int(os.getenv("CT1_RETRY_ATTEMPTS", "3")))
RETRY_BACKOFF_SECONDS = max(0.0, float(os.getenv("CT1_RETRY_BACKOFF_SECONDS", "1.5")))
POLL_MAX_CONSECUTIVE_ERRORS = max(1, int(os.getenv("CT1_POLL_MAX_CONSECUTIVE_ERRORS", "8")))
_TRANSIENT_HTTP_STATUSES = frozenset({408, 429, 502, 503, 504})
HTTPX_TRUST_ENV = os.getenv("HTTPX_TRUST_ENV", "false").strip().lower() in ("true", "1", "yes")
CT1_RC_TOKEN = os.getenv("CT1_RC_TOKEN", "").strip()

PR_SECTIONS: List[Dict[str, str]] = [
    {"key": "past_review", "title": "Past Review Analysis", "short": "Past Review"},
    {
        "key": "policy_regulation",
        "title": "Policy, KOD and Regulatory Analysis",
        "short": "Policy, KOD & Regulatory",
    },
    {"key": "broad_scope", "title": "Broad Scope Direction", "short": "Broad Scope"},
]
_VALID_PR_SECTION_KEYS = {item["key"] for item in PR_SECTIONS}

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

PLAN_ARTIFACTS: List[Dict[str, str]] = [
    {"id": "policy", "label": "Policies / KOD / Proc", "excludable": "true"},
    {"id": "findings_details", "label": "GFMS Findings", "excludable": "true"},
    {"id": "historical_plan_details", "label": "Historical Plans", "excludable": "true"},
    {"id": "lrr", "label": "LRR Mandates", "excludable": "true"},
    {"id": "current_details", "label": "Current Plan", "excludable": "false"},
    {"id": "alc_nlac", "label": "ALC / NALC", "excludable": "false"},
    {"id": "control_details", "label": "Controls", "excludable": "false"},
    {"id": "risk_driver_details", "label": "Risk Drivers", "excludable": "false"},
    {"id": "group_audit", "label": "Group Audit", "excludable": "false"},
]

_TYPE_ALIASES: Dict[str, str] = {
    "policy": "policy",
    "policies": "policy",
    "policy_ids": "policy",
    "policy_document_ids": "policy",
    "policy_files": "policy",
    "kod": "kod",
    "kods": "kod",
    "kod_ids": "kod",
    "kod_document_ids": "kod",
    "kod_files": "kod",
    "procedure": "procedure",
    "procedures": "procedure",
    "procedure_ids": "procedure",
    "procedure_document_ids": "procedure",
    "procedure_files": "procedure",
    "procedure_documents": "procedure",
    "gfms": "gfms",
    "gfms_data": "gfms",
    "findings": "gfms",
    "findings_details": "gfms",
    "historical": "historical_scoping_document",
    "historical_plan": "historical_scoping_document",
    "historical_plan_details": "historical_scoping_document",
    "historical_scoping": "historical_scoping_document",
    "historical_scoping_document": "historical_scoping_document",
    "lrr": "lrr",
    "lrr_mandates": "lrr",
    "mandates": "lrr",
}

_AFFECTED_SECTIONS_MAP: Dict[str, Tuple[str, ...]] = {
    "policy": ("policy_regulation", "broad_scope"),
    "kod": ("policy_regulation", "broad_scope"),
    "procedure": ("policy_regulation", "broad_scope"),
    "gfms": ("broad_scope",),
    "historical_scoping_document": ("past_review", "broad_scope"),
    "lrr": ("policy_regulation", "broad_scope"),
}

_RAG_FIELD_MAP: Dict[str, str] = {
    "policy": "policy_files",
    "kod": "kod_files",
    "procedure": "procedure_files",
}


class ChatProxyRequest(BaseModel):
    question: str
    plan_number: str
    context_type: str = "Preliminary Research Walkthrough"
    plan_name: Optional[str] = None
    research_sections: Optional[Dict[str, Any]] = None
    userDetails: Optional[Dict[str, Any]] = None


class DocumentAddRemoveProxyRequest(BaseModel):
    user_text: Optional[str] = None
    question: Optional[str] = None
    plan_number: str
    context_type: str = "Preliminary Research Walkthrough"
    userDetails: Optional[Dict[str, Any]] = None


class ExtractionRunRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchGetRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchGenerateRequest(BaseModel):
    planNumber: str
    sections: Optional[List[str]] = None
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchEditRequest(BaseModel):
    planNumber: str
    analysis_report: Dict[str, Any]
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchDocumentRequest(BaseModel):
    planNumber: Optional[str] = None
    chunk_id: Optional[str] = None
    document_uri: Optional[str] = None
    page_number: Optional[int] = None


class PreliminaryResearchDownloadRequest(BaseModel):
    planNumber: str
    planName: Optional[str] = None
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchAcceptRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


class CategorizeIdsRequest(BaseModel):
    document_ids: List[int]


class RagRelevantDataRequest(BaseModel):
    review_id: Optional[str] = None
    plan_number: Optional[str] = None
    region: Optional[str] = None
    au_countries: Optional[List[str]] = None
    plan_item_title: Optional[str] = None
    plan_item_description: Optional[str] = None
    au_list: Optional[List[str]] = None
    rt_list: Optional[List[str]] = None
    kc_list: Optional[List[str]] = None
    control_name: Optional[List[str]] = None
    control_how: Optional[List[str]] = None
    control_what: Optional[List[str]] = None
    control_why: Optional[List[str]] = None
    documents: List[Dict[str, Any]] = []


def create_async_client() -> httpx.AsyncClient:
    """Create the async HTTP client used for live CT1 calls (bypass local proxy env vars by default)."""
    timeout = httpx.Timeout(
        REQUEST_TIMEOUT_SECONDS,
        connect=30.0,
        read=REQUEST_TIMEOUT_SECONDS,
        write=60.0,
        pool=30.0,
    )
    return httpx.AsyncClient(verify=False, trust_env=HTTPX_TRUST_ENV, timeout=timeout)


app = FastAPI(title="CT1 Live Preliminary Research & Scoping Demo UI", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _normalize_doc_type(value: Any) -> str:
    cleaned = re.sub(r"[\s-]+", "_", str(value or "").strip().lower())
    return _TYPE_ALIASES.get(cleaned, cleaned or "policy")


def _unwrap_data_dict(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def _extract_error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            return str(payload.get("detail") or payload.get("message") or payload.get("error") or payload)
        return str(payload)
    except Exception:
        return response.text[:500] or f"HTTP {response.status_code}"


def _extract_error_payload(response: httpx.Response) -> Any:
    try:
        return response.json()
    except Exception:
        return response.text[:4000] if getattr(response, "text", None) else f"HTTP {response.status_code}"


def _raise_upstream_http_error(
    status_code: int,
    *,
    operation: str,
    url: str,
    message: str,
    upstream_status: Optional[int] = None,
    upstream_body: Any = None,
    extra: Optional[Dict[str, Any]] = None,
) -> NoReturn:
    detail: Dict[str, Any] = {
        "error": message,
        "operation": operation,
        "upstream_url": url,
        "upstream_status": upstream_status,
        "upstream_body": upstream_body,
    }
    if extra:
        detail["details"] = extra
    raise HTTPException(status_code=status_code, detail=detail)


_API_TRACE_MAX_ENTRIES = 400
_API_TRACE_LOG: Deque[Dict[str, Any]] = deque(maxlen=_API_TRACE_MAX_ENTRIES)
_API_TRACE_SEQ = 0


def _sanitize_trace_value(value: Any, *, max_str: int = 12000, depth: int = 0) -> Any:
    """Keep full diagnostic detail while safely bounding oversized strings/binary blobs."""
    if depth > 12:
        return "<max depth reached>"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, bytes):
        return {
            "__binary__": True,
            "size_bytes": len(value),
            "sha256_prefix": hashlib.sha256(value).hexdigest()[:12],
        }
    if isinstance(value, str):
        if len(value) > max_str:
            return f"{value[:max_str]} ... [truncated {len(value) - max_str} chars; total={len(value)}]"
        return value
    if isinstance(value, list):
        if len(value) > 200:
            return [
                *(_sanitize_trace_value(v, max_str=max_str, depth=depth + 1) for v in value[:200]),
                f"... [{len(value) - 200} more item(s); total={len(value)}]",
            ]
        return [_sanitize_trace_value(v, max_str=max_str, depth=depth + 1) for v in value]
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for k, v in value.items():
            k_str = str(k)
            if k_str.lower() in ("x-asm-rctoken", "authorization"):
                raw = str(v or "")
                out[k_str] = f"{raw[:6]}...{raw[-4:]} (len={len(raw)})" if len(raw) > 12 else "<redacted>"
            elif k_str == "content_base64" and isinstance(v, str) and len(v) > 200:
                out[k_str] = f"{v[:80]}... [base64 len={len(v)}]"
            else:
                out[k_str] = _sanitize_trace_value(v, max_str=max_str, depth=depth + 1)
        return out
    return str(value)[:max_str]


def _record_api_trace(
    *,
    method: str,
    url: str,
    action: Optional[str] = None,
    plan_number: Optional[str] = None,
    operation: str = "gateway_request",
    started_utc: datetime,
    started_perf: float,
    request_content_type: str = "application/json",
    request_headers: Optional[Dict[str, str]] = None,
    request_body: Any = None,
    response: Optional[httpx.Response] = None,
    response_body: Any = None,
    error: Optional[str] = None,
    attempt: int = 1,
    max_attempts: int = 1,
) -> Dict[str, Any]:
    global _API_TRACE_SEQ
    _API_TRACE_SEQ += 1
    completed_utc = datetime.now(timezone.utc)
    duration_ms = round((time.perf_counter() - started_perf) * 1000.0, 1)

    status_code = response.status_code if response is not None else None
    resp_headers: Dict[str, str] = {}
    x_plan_status: Any = None
    if response is not None and getattr(response, "headers", None):
        for hname in ("content-type", "content-disposition", "content-length", "x-plan-status", "x-request-id"):
            val = response.headers.get(hname)
            if val is not None:
                resp_headers[hname] = val
        raw_ps = response.headers.get("x-plan-status")
        if raw_ps:
            try:
                x_plan_status = json.loads(raw_ps)
            except Exception:
                x_plan_status = raw_ps

    parsed_resp_body = response_body
    if parsed_resp_body is None and response is not None:
        ctype = str((response.headers.get("content-type") if getattr(response, "headers", None) else "") or "").lower()
        if "application/pdf" in ctype or "application/octet-stream" in ctype:
            raw_bytes = getattr(response, "content", b"") or b""
            parsed_resp_body = {
                "__binary__": True,
                "content_type": ctype,
                "size_bytes": len(raw_bytes),
                "sha256_prefix": hashlib.sha256(raw_bytes).hexdigest()[:12] if raw_bytes else "",
            }
        else:
            try:
                parsed_resp_body = response.json()
            except Exception:
                parsed_resp_body = getattr(response, "text", "") or ""

    entry: Dict[str, Any] = {
        "id": _API_TRACE_SEQ,
        "started_at": started_utc.isoformat(),
        "completed_at": completed_utc.isoformat(),
        "duration_ms": duration_ms,
        "method": method.upper(),
        "url": url,
        "path": url.replace(GATEWAY_BASE, "/dbaware-api-gateway") if url.startswith(GATEWAY_BASE) else url,
        "action": action,
        "plan_number": str(plan_number) if plan_number is not None else None,
        "operation": operation,
        "request_content_type": request_content_type,
        "request_headers": _sanitize_trace_value(request_headers or {}),
        "request_body": _sanitize_trace_value(request_body),
        "status_code": status_code,
        "ok": bool(status_code is not None and 200 <= status_code < 400 and not error),
        "response_headers": _sanitize_trace_value(resp_headers),
        "x_plan_status": _sanitize_trace_value(x_plan_status) if x_plan_status is not None else None,
        "response_body": _sanitize_trace_value(parsed_resp_body),
        "error": error,
        "attempt": attempt,
        "max_attempts": max_attempts,
    }
    _API_TRACE_LOG.append(entry)
    return entry


def _gateway_headers() -> Dict[str, str]:
    return {"x-asm-rctoken": CT1_RC_TOKEN} if CT1_RC_TOKEN else {}


def _is_transient_status(status_code: Optional[int]) -> bool:
    return status_code in _TRANSIENT_HTTP_STATUSES


def _retry_delay_seconds(attempt: int) -> float:
    return RETRY_BACKOFF_SECONDS * (2 ** max(0, attempt - 1))


async def _call_gateway_get(
    path: str,
    *,
    plan_number: Optional[str] = None,
    operation: str = "gateway_get",
    action: Optional[str] = None,
    timeout: Optional[float] = None,
    client: Optional[httpx.AsyncClient] = None,
    max_attempts: Optional[int] = None,
) -> httpx.Response:
    """Execute a traced GET request against the API Gateway with transient retry."""
    url = f"{GATEWAY_BASE}/{path.lstrip('/')}"
    headers = _gateway_headers()
    req_timeout = REQUEST_TIMEOUT_SECONDS if timeout is None else timeout
    attempts_total = max(1, RETRY_MAX_ATTEMPTS if max_attempts is None else max_attempts)

    async def _do(c: httpx.AsyncClient) -> httpx.Response:
        kwargs: Dict[str, Any] = {"timeout": req_timeout}
        if headers:
            kwargs["headers"] = headers
        return await c.get(url, **kwargs)

    last_exc: Optional[Exception] = None
    last_resp: Optional[httpx.Response] = None
    for attempt in range(1, attempts_total + 1):
        started_utc = datetime.now(timezone.utc)
        started_perf = time.perf_counter()
        try:
            if client is not None:
                resp = await _do(client)
            else:
                async with create_async_client() as owned_client:
                    resp = await _do(owned_client)
        except Exception as exc:
            last_exc = exc
            _record_api_trace(
                method="GET",
                url=url,
                action=action,
                plan_number=plan_number,
                operation=operation,
                started_utc=started_utc,
                started_perf=started_perf,
                request_content_type="none",
                request_headers=headers,
                request_body=None,
                error=f"{type(exc).__name__}: {exc}",
                attempt=attempt,
                max_attempts=attempts_total,
            )
            if attempt < attempts_total:
                delay = _retry_delay_seconds(attempt)
                logger.warning("Transient GET %s error (attempt %d/%d), retrying in %.1fs: %s", url, attempt, attempts_total, delay, exc)
                await asyncio.sleep(delay)
                continue
            raise

        last_resp = resp
        err_msg = _extract_error_detail(resp) if resp.status_code >= 400 else None
        _record_api_trace(
            method="GET",
            url=url,
            action=action,
            plan_number=plan_number,
            operation=operation,
            started_utc=started_utc,
            started_perf=started_perf,
            request_content_type="none",
            request_headers=headers,
            request_body=None,
            response=resp,
            error=err_msg,
            attempt=attempt,
            max_attempts=attempts_total,
        )
        if _is_transient_status(resp.status_code) and attempt < attempts_total:
            delay = _retry_delay_seconds(attempt)
            logger.warning("Transient HTTP %d on GET %s (attempt %d/%d), retrying in %.1fs", resp.status_code, url, attempt, attempts_total, delay)
            await asyncio.sleep(delay)
            continue
        return resp

    if last_resp is not None:
        return last_resp
    assert last_exc is not None
    raise last_exc


async def _call_gateway_action(
    action: str,
    plan_number: str,
    payload: Dict[str, Any],
    *,
    timeout: Optional[float] = None,
    unwrap_response: bool = True,
    client: Optional[httpx.AsyncClient] = None,
    max_attempts: Optional[int] = None,
) -> Dict[str, Any]:
    """Call one API Gateway JSON action (`POST /api/v1/actions`) with tracing and transient retry."""
    url = f"{GATEWAY_BASE}/api/v1/actions"
    body = {"planNumber": str(plan_number), "action": action, "payload": payload}
    headers = _gateway_headers()
    kwargs: Dict[str, Any] = {
        "json": body,
        "timeout": REQUEST_TIMEOUT_SECONDS if timeout is None else timeout,
    }
    if headers:
        kwargs["headers"] = headers

    operation = f"gateway_{action.lower()}"
    non_idempotent_actions = {"RUN_ANALYTICS", "ACCEPT_PRELIMINARY_RESEARCH"}
    default_attempts = 1 if action in non_idempotent_actions else RETRY_MAX_ATTEMPTS
    attempts_total = max(1, default_attempts if max_attempts is None else max_attempts)

    async def _do(c: httpx.AsyncClient) -> httpx.Response:
        return await c.post(url, **kwargs)

    for attempt in range(1, attempts_total + 1):
        started_utc = datetime.now(timezone.utc)
        started_perf = time.perf_counter()
        try:
            if client is not None:
                resp = await _do(client)
            else:
                async with create_async_client() as owned_client:
                    resp = await _do(owned_client)
        except Exception as exc:
            _record_api_trace(
                method="POST",
                url=url,
                action=action,
                plan_number=plan_number,
                operation=operation,
                started_utc=started_utc,
                started_perf=started_perf,
                request_content_type="application/json",
                request_headers=headers,
                request_body=body,
                error=f"{type(exc).__name__}: {exc}",
                attempt=attempt,
                max_attempts=attempts_total,
            )
            if attempt < attempts_total:
                delay = _retry_delay_seconds(attempt)
                logger.warning("Transient error on %s (attempt %d/%d), retrying in %.1fs: %s", action, attempt, attempts_total, delay, exc)
                await asyncio.sleep(delay)
                continue
            _raise_upstream_http_error(
                502,
                operation=operation,
                url=url,
                message=f"API Gateway action {action} unreachable ({type(exc).__name__}): {exc}",
                extra={"exception_type": type(exc).__name__, "plan_number": plan_number, "action": action, "attempts": attempt},
            )

        if resp.status_code >= 400:
            err_detail = _extract_error_detail(resp)
            err_payload = _extract_error_payload(resp)
            _record_api_trace(
                method="POST",
                url=url,
                action=action,
                plan_number=plan_number,
                operation=operation,
                started_utc=started_utc,
                started_perf=started_perf,
                request_content_type="application/json",
                request_headers=headers,
                request_body=body,
                response=resp,
                response_body=err_payload,
                error=f"HTTP {resp.status_code}: {err_detail}",
                attempt=attempt,
                max_attempts=attempts_total,
            )
            if _is_transient_status(resp.status_code) and attempt < attempts_total:
                delay = _retry_delay_seconds(attempt)
                logger.warning("Transient HTTP %d on %s (attempt %d/%d), retrying in %.1fs", resp.status_code, action, attempt, attempts_total, delay)
                await asyncio.sleep(delay)
                continue
            _raise_upstream_http_error(
                resp.status_code,
                operation=operation,
                url=url,
                message=f"API Gateway action {action} returned HTTP {resp.status_code}: {err_detail}",
                upstream_status=resp.status_code,
                upstream_body=err_payload,
                extra={"plan_number": plan_number, "action": action, "attempts": attempt},
            )

        try:
            data = resp.json()
        except Exception as exc:
            raw_text = resp.text[:4000] if getattr(resp, "text", None) else ""
            _record_api_trace(
                method="POST",
                url=url,
                action=action,
                plan_number=plan_number,
                operation=operation,
                started_utc=started_utc,
                started_perf=started_perf,
                request_content_type="application/json",
                request_headers=headers,
                request_body=body,
                response=resp,
                response_body=raw_text,
                error=f"Invalid JSON: {exc}",
                attempt=attempt,
                max_attempts=attempts_total,
            )
            if attempt < attempts_total:
                delay = _retry_delay_seconds(attempt)
                logger.warning("Invalid JSON on %s (attempt %d/%d), retrying in %.1fs", action, attempt, attempts_total, delay)
                await asyncio.sleep(delay)
                continue
            _raise_upstream_http_error(
                502,
                operation=operation,
                url=url,
                message=f"API Gateway action {action} returned invalid JSON: {exc}",
                upstream_status=resp.status_code,
                upstream_body=raw_text,
                extra={"plan_number": plan_number, "action": action, "attempts": attempt},
            )

        _record_api_trace(
            method="POST",
            url=url,
            action=action,
            plan_number=plan_number,
            operation=operation,
            started_utc=started_utc,
            started_perf=started_perf,
            request_content_type="application/json",
            request_headers=headers,
            request_body=body,
            response=resp,
            response_body=data,
            attempt=attempt,
            max_attempts=attempts_total,
        )
        if unwrap_response and isinstance(data, dict) and isinstance(data.get("response"), dict):
            return data["response"]
        return data if isinstance(data, dict) else {"data": data}

    raise HTTPException(status_code=502, detail=f"API Gateway action {action} failed after {attempts_total} attempts.")


async def _call_gateway_upload_action(
    action: str,
    plan_number: str,
    payload: Dict[str, Any],
    files: List[Tuple[str, Tuple[str, bytes, str]]],
    *,
    timeout: Optional[float] = None,
    client: Optional[httpx.AsyncClient] = None,
    max_attempts: Optional[int] = None,
) -> Dict[str, Any]:
    """Call API Gateway multipart upload endpoint (`POST /api/v1/actions/upload`) with tracing and transient retry."""
    url = f"{GATEWAY_BASE}/api/v1/actions/upload"
    form_data = {
        "action": action,
        "planNumber": str(plan_number),
        "payload": json.dumps(payload),
    }
    headers = _gateway_headers()
    kwargs: Dict[str, Any] = {
        "data": form_data,
        "files": files,
        "timeout": REQUEST_TIMEOUT_SECONDS if timeout is None else timeout,
    }
    if headers:
        kwargs["headers"] = headers

    trace_req_body = {
        "form_fields": {
            "action": action,
            "planNumber": str(plan_number),
            "payload": payload,
        },
        "files": [
            {
                "field": field_name,
                "filename": fname,
                "content_type": ctype,
                "size_bytes": len(content),
                "sha256_prefix": hashlib.sha256(content).hexdigest()[:12],
            }
            for field_name, (fname, content, ctype) in files
        ],
    }

    operation = f"gateway_upload_{action.lower()}"
    attempts_total = max(1, RETRY_MAX_ATTEMPTS if max_attempts is None else max_attempts)

    async def _do(c: httpx.AsyncClient) -> httpx.Response:
        return await c.post(url, **kwargs)

    for attempt in range(1, attempts_total + 1):
        started_utc = datetime.now(timezone.utc)
        started_perf = time.perf_counter()
        try:
            if client is not None:
                resp = await _do(client)
            else:
                async with create_async_client() as owned_client:
                    resp = await _do(owned_client)
        except Exception as exc:
            _record_api_trace(
                method="POST",
                url=url,
                action=action,
                plan_number=plan_number,
                operation=operation,
                started_utc=started_utc,
                started_perf=started_perf,
                request_content_type="multipart/form-data",
                request_headers=headers,
                request_body=trace_req_body,
                error=f"{type(exc).__name__}: {exc}",
                attempt=attempt,
                max_attempts=attempts_total,
            )
            if attempt < attempts_total:
                delay = _retry_delay_seconds(attempt)
                logger.warning("Transient upload error on %s (attempt %d/%d), retrying in %.1fs: %s", action, attempt, attempts_total, delay, exc)
                await asyncio.sleep(delay)
                continue
            _raise_upstream_http_error(
                502,
                operation=operation,
                url=url,
                message=f"API Gateway upload {action} unreachable ({type(exc).__name__}): {exc}",
                extra={"exception_type": type(exc).__name__, "plan_number": plan_number, "action": action, "attempts": attempt},
            )

        if resp.status_code >= 400:
            err_detail = _extract_error_detail(resp)
            err_payload = _extract_error_payload(resp)
            _record_api_trace(
                method="POST",
                url=url,
                action=action,
                plan_number=plan_number,
                operation=operation,
                started_utc=started_utc,
                started_perf=started_perf,
                request_content_type="multipart/form-data",
                request_headers=headers,
                request_body=trace_req_body,
                response=resp,
                response_body=err_payload,
                error=f"HTTP {resp.status_code}: {err_detail}",
                attempt=attempt,
                max_attempts=attempts_total,
            )
            if _is_transient_status(resp.status_code) and attempt < attempts_total:
                delay = _retry_delay_seconds(attempt)
                logger.warning("Transient HTTP %d on upload %s (attempt %d/%d), retrying in %.1fs", resp.status_code, action, attempt, attempts_total, delay)
                await asyncio.sleep(delay)
                continue
            _raise_upstream_http_error(
                resp.status_code,
                operation=operation,
                url=url,
                message=f"API Gateway upload {action} returned HTTP {resp.status_code}: {err_detail}",
                upstream_status=resp.status_code,
                upstream_body=err_payload,
                extra={"plan_number": plan_number, "action": action, "attempts": attempt},
            )

        try:
            data = resp.json()
        except Exception as exc:
            raw_text = resp.text[:4000] if getattr(resp, "text", None) else ""
            _record_api_trace(
                method="POST",
                url=url,
                action=action,
                plan_number=plan_number,
                operation=operation,
                started_utc=started_utc,
                started_perf=started_perf,
                request_content_type="multipart/form-data",
                request_headers=headers,
                request_body=trace_req_body,
                response=resp,
                response_body=raw_text,
                error=f"Invalid JSON: {exc}",
                attempt=attempt,
                max_attempts=attempts_total,
            )
            if attempt < attempts_total:
                delay = _retry_delay_seconds(attempt)
                await asyncio.sleep(delay)
                continue
            _raise_upstream_http_error(
                502,
                operation=operation,
                url=url,
                message=f"API Gateway upload {action} returned invalid JSON: {exc}",
                upstream_status=resp.status_code,
                upstream_body=raw_text,
                extra={"plan_number": plan_number, "action": action, "attempts": attempt},
            )

        _record_api_trace(
            method="POST",
            url=url,
            action=action,
            plan_number=plan_number,
            operation=operation,
            started_utc=started_utc,
            started_perf=started_perf,
            request_content_type="multipart/form-data",
            request_headers=headers,
            request_body=trace_req_body,
            response=resp,
            response_body=data,
            attempt=attempt,
            max_attempts=attempts_total,
        )
        if isinstance(data, dict) and isinstance(data.get("response"), dict):
            return data["response"]
        return data if isinstance(data, dict) else {"data": data}

    raise HTTPException(status_code=502, detail=f"API Gateway upload {action} failed after {attempts_total} attempts.")


async def _call_gateway_download_action(
    action: str,
    plan_number: str,
    payload: Dict[str, Any],
    *,
    timeout: Optional[float] = None,
    max_attempts: Optional[int] = None,
) -> httpx.Response:
    """Call API Gateway binary download endpoint (`POST /api/v1/actions/download`) with tracing and transient retry."""
    url = f"{GATEWAY_BASE}/api/v1/actions/download"
    body = {"planNumber": str(plan_number), "action": action, "payload": payload}
    headers = _gateway_headers()
    kwargs: Dict[str, Any] = {
        "json": body,
        "timeout": REQUEST_TIMEOUT_SECONDS if timeout is None else timeout,
    }
    if headers:
        kwargs["headers"] = headers

    operation = f"gateway_download_{action.lower()}"
    attempts_total = max(1, RETRY_MAX_ATTEMPTS if max_attempts is None else max_attempts)

    for attempt in range(1, attempts_total + 1):
        started_utc = datetime.now(timezone.utc)
        started_perf = time.perf_counter()
        async with create_async_client() as client:
            try:
                resp = await client.post(url, **kwargs)
            except Exception as exc:
                _record_api_trace(
                    method="POST",
                    url=url,
                    action=action,
                    plan_number=plan_number,
                    operation=operation,
                    started_utc=started_utc,
                    started_perf=started_perf,
                    request_content_type="application/json",
                    request_headers=headers,
                    request_body=body,
                    error=f"{type(exc).__name__}: {exc}",
                    attempt=attempt,
                    max_attempts=attempts_total,
                )
                if attempt < attempts_total:
                    await asyncio.sleep(_retry_delay_seconds(attempt))
                    continue
                _raise_upstream_http_error(
                    502,
                    operation=operation,
                    url=url,
                    message=f"API Gateway download {action} unreachable ({type(exc).__name__}): {exc}",
                    extra={"exception_type": type(exc).__name__, "plan_number": plan_number, "action": action, "attempts": attempt},
                )

        _record_api_trace(
            method="POST",
            url=url,
            action=action,
            plan_number=plan_number,
            operation=operation,
            started_utc=started_utc,
            started_perf=started_perf,
            request_content_type="application/json",
            request_headers=headers,
            request_body=body,
            response=resp,
            error=(f"HTTP {resp.status_code}: {_extract_error_detail(resp)}" if resp.status_code >= 400 else None),
            attempt=attempt,
            max_attempts=attempts_total,
        )
        if _is_transient_status(resp.status_code) and attempt < attempts_total:
            await asyncio.sleep(_retry_delay_seconds(attempt))
            continue
        return resp

    raise HTTPException(status_code=502, detail=f"API Gateway download {action} failed after {attempts_total} attempts.")


def _scope_query_string(scope: Optional[Dict[str, Any]]) -> str:
    """Return '?review_scope_id=..&process_instance_id=..&task_id=..' only when values exist."""
    scope = scope or {}
    params = {
        k: str(scope[k]).strip()
        for k in ("review_scope_id", "process_instance_id", "task_id")
        if scope.get(k) not in (None, "") and str(scope[k]).strip()
    }
    return f"?{urlencode(params)}" if params else ""


def _normalize_user_details(
    raw: Optional[Dict[str, Any]] = None,
    *,
    review_scope_id: Optional[str] = None,
    process_instance_id: Optional[str] = None,
    task_id: Optional[str] = None,
    review_scope_stage: Optional[str] = None,
    user: Optional[str] = None,
) -> Dict[str, Any]:
    """Merge explicit scope fields over a raw userDetails dict; always carries a user."""
    details: Dict[str, Any] = dict(raw or {})
    for key, value in (
        ("review_scope_id", review_scope_id),
        ("process_instance_id", process_instance_id),
        ("task_id", task_id),
        ("review_scope_stage", review_scope_stage),
        ("user", user),
    ):
        if value not in (None, "") and str(value).strip():
            details[key] = str(value).strip()
    if not details.get("user"):
        details["user"] = "demo.user@db.com"
    return details


def _scope_user_details(scope: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return normalized userDetails only when workflow scope identifiers are present."""
    details = _normalize_user_details(scope)
    if any(
        details.get(key)
        for key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage")
    ):
        return details
    return None


def _merge_scope_context(
    explicit: Optional[Dict[str, Any]] = None,
    auto: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Merge explicit query/form scope fields over auto-detected `/task/status` values."""
    merged: Dict[str, Any] = {
        key: value
        for key, value in (auto or {}).items()
        if value not in (None, "") and str(value).strip()
    }
    for key, value in (explicit or {}).items():
        if value not in (None, "") and str(value).strip():
            merged[key] = str(value).strip()
    if not merged.get("user"):
        merged["user"] = "demo.user@db.com"
    return merged


def _scope_source(explicit: Optional[Dict[str, Any]], auto: Optional[Dict[str, Any]]) -> str:
    if any(
        (explicit or {}).get(key) not in (None, "") and str((explicit or {}).get(key)).strip()
        for key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage")
    ):
        return "explicit"
    if any(
        (auto or {}).get(key) not in (None, "") and str((auto or {}).get(key)).strip()
        for key in ("review_scope_id", "process_instance_id", "task_id")
    ):
        return "auto"
    return "plan"


def _scope_from_task_status(task_status: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(task_status, dict):
        return {}
    raw_variables = task_status.get("variables")
    if isinstance(raw_variables, str):
        try:
            raw_variables = json.loads(raw_variables)
        except Exception:
            raw_variables = {}
    variables = raw_variables if isinstance(raw_variables, dict) else {}
    scope_id = None
    for key in (
        "review_scope_id",
        "reviewScopeId",
        "review_scope_instance_id",
        "reviewScopeInstanceId",
        "p_REVIEW_SCOPE_ID",
    ):
        if variables.get(key) not in (None, ""):
            scope_id = variables[key]
            break
    out = {
        "review_scope_id": scope_id,
        "process_instance_id": task_status.get("processInstanceId"),
        "task_id": task_status.get("taskId"),
        "review_scope_stage": task_status.get("taskDefinitionKey"),
        "user": task_status.get("owner"),
    }
    return {k: str(v).strip() for k, v in out.items() if v not in (None, "") and str(v).strip()}


async def _fetch_task_status_best_effort(
    plan_number: str,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Fetch workflow task status from API Gateway; returns `(None, reason)` if plan has no active task."""
    try:
        resp = await _call_gateway_get(
            f"api/v1/task/status/{plan_number}",
            plan_number=plan_number,
            operation="gateway_task_status",
            timeout=TASK_STATUS_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        return None, f"task/status unavailable ({type(exc).__name__}): {exc}"
    if resp.status_code == 200:
        try:
            data = resp.json()
            return (data if isinstance(data, dict) else None), None
        except Exception as exc:
            return None, f"task/status invalid JSON: {exc}"
    return None, f"task/status returned HTTP {resp.status_code}: {_extract_error_detail(resp)}"


async def _fetch_artifact_safe(
    plan_number: str,
    artifact_id: str,
    scope: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Fetch a single plan artifact through API Gateway action `GET_PLAN_ARTIFACT`."""
    url = f"{GATEWAY_BASE}/api/v1/actions"
    payload: Dict[str, Any] = {"artifact": artifact_id}
    scope_fields = {
        k: str(v).strip()
        for k, v in (scope or {}).items()
        if k in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage")
        and v not in (None, "")
        and str(v).strip()
    }
    payload.update(scope_fields)
    if scope_fields:
        payload["userDetails"] = _normalize_user_details(scope)
    try:
        data = await _call_gateway_action("GET_PLAN_ARTIFACT", plan_number, payload)
        return {"ok": True, "status_code": 200, "url": url, "data": data}
    except HTTPException as exc:
        detail = exc.detail if isinstance(exc.detail, dict) else {"error": str(exc.detail)}
        return {
            "ok": False,
            "status_code": detail.get("upstream_status") or exc.status_code,
            "url": detail.get("upstream_url", url),
            "error": str(detail.get("error") or f"HTTP {exc.status_code}"),
            "upstream_body": detail.get("upstream_body"),
            "data": None,
        }
    except Exception as exc:
        return {
            "ok": False,
            "status_code": 502,
            "url": url,
            "error": f"{type(exc).__name__}: {exc}",
            "exception_type": type(exc).__name__,
            "data": None,
        }


async def _fetch_availability_safe(plan_number: str) -> Dict[str, Any]:
    """Fetch plan artifact availability through API Gateway action `GET_PLAN_AVAILABILITY`."""
    url = f"{GATEWAY_BASE}/api/v1/actions"
    try:
        data = await _call_gateway_action("GET_PLAN_AVAILABILITY", plan_number, {})
        return {"ok": True, "status_code": 200, "url": url, "data": data}
    except HTTPException as exc:
        detail = exc.detail if isinstance(exc.detail, dict) else {"error": str(exc.detail)}
        return {
            "ok": False,
            "status_code": detail.get("upstream_status") or exc.status_code,
            "url": detail.get("upstream_url", url),
            "error": str(detail.get("error") or f"HTTP {exc.status_code}"),
            "upstream_body": detail.get("upstream_body"),
            "data": None,
        }
    except Exception as exc:
        return {
            "ok": False,
            "status_code": 502,
            "url": url,
            "error": f"{type(exc).__name__}: {exc}",
            "exception_type": type(exc).__name__,
            "data": None,
        }


async def _fetch_catalog_live(
    plan_number: str,
    user_details: Optional[Dict[str, Any]] = None,
) -> Tuple[Optional[Dict[str, Any]], Optional[str], str, List[Dict[str, Any]]]:
    """Fetch the plan document catalog through the API Gateway action `QNA_LIST_DOCUMENTS`."""
    url = f"{GATEWAY_BASE}/api/v1/actions"
    try:
        parsed = await _call_gateway_action(
            "QNA_LIST_DOCUMENTS",
            plan_number,
            {"user_details": dict(user_details or {})},
        )
    except HTTPException as exc:
        detail = exc.detail if isinstance(exc.detail, dict) else {"error": str(exc.detail)}
        upstream_status = detail.get("upstream_status") or exc.status_code
        err_msg = f"api_gateway: HTTP {upstream_status} ({str(detail.get('error', 'request failed'))[:160]})"
        return (
            None,
            err_msg,
            "error",
            [
                {
                    "target": "catalog:QNA_LIST_DOCUMENTS",
                    "upstream_url": detail.get("upstream_url", url),
                    "upstream_status": upstream_status,
                    "error": detail.get("error", err_msg),
                    "upstream_body": detail.get("upstream_body"),
                }
            ],
        )
    except Exception as exc:
        err_msg = f"api_gateway: {type(exc).__name__}: {exc}"
        return (
            None,
            err_msg,
            "error",
            [
                {
                    "target": "catalog:QNA_LIST_DOCUMENTS",
                    "upstream_url": url,
                    "upstream_status": 502,
                    "error": f"{type(exc).__name__}: {exc}",
                    "exception_type": type(exc).__name__,
                }
            ],
        )

    if not isinstance(parsed, dict) or not isinstance(parsed.get("document_groups"), list):
        err_msg = "api_gateway: missing document_groups in QNA_LIST_DOCUMENTS response"
        return (
            None,
            err_msg,
            "error",
            [
                {
                    "target": "catalog:QNA_LIST_DOCUMENTS",
                    "upstream_url": url,
                    "upstream_status": 200,
                    "error": "Response missing document_groups",
                    "upstream_body": parsed,
                }
            ],
        )

    return parsed, None, "api_gateway", []


async def _load_plan_bundle(plan_number: str, scope_context: Optional[Dict[str, Any]] = None) -> Tuple[
    Optional[Dict[str, Any]],
    Dict[str, Any],
    Optional[Dict[str, Any]],
    Dict[str, str],
    str,
    List[Dict[str, Any]],
    Optional[Dict[str, Any]],
    Dict[str, Any],
    str,
]:
    """Load availability, all 9 Data Extraction feeds, and live document catalog solely via API Gateway."""
    artifact_ids = [item["id"] for item in PLAN_ARTIFACTS]
    explicit_scope = {
        key: str(value).strip()
        for key, value in (scope_context or {}).items()
        if key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage", "user")
        and value not in (None, "")
        and str(value).strip()
    }
    task_status, task_status_error = await _fetch_task_status_best_effort(plan_number)
    auto_scope = _scope_from_task_status(task_status)
    resolved_scope = _merge_scope_context(explicit_scope, auto_scope)
    scope_source = _scope_source(explicit_scope, auto_scope)
    scope_user_details = _scope_user_details(resolved_scope)
    if task_status_error:
        logger.info("Plan %s task/status not used for scope: %s", plan_number, task_status_error)

    avail_res, *art_results = await asyncio.gather(
        _fetch_availability_safe(plan_number),
        *(_fetch_artifact_safe(plan_number, aid, resolved_scope) for aid in artifact_ids),
    )

    artifacts: Dict[str, Any] = {}
    errors: Dict[str, str] = {}
    error_details: List[Dict[str, Any]] = []
    availability = avail_res["data"] if avail_res["ok"] else None
    if not avail_res["ok"]:
        errors["availability"] = str(avail_res.get("error") or "Availability unavailable")
        error_details.append(
            {
                "target": "availability",
                "upstream_url": avail_res.get("url"),
                "upstream_status": avail_res.get("status_code"),
                "error": errors["availability"],
                **(
                    {"upstream_body": avail_res["upstream_body"]}
                    if "upstream_body" in avail_res
                    else {}
                ),
                **(
                    {"exception_type": avail_res["exception_type"]}
                    if "exception_type" in avail_res
                    else {}
                ),
            }
        )

    for aid, res in zip(artifact_ids, art_results):
        if res["ok"]:
            artifacts[aid] = res["data"]
        else:
            errors[aid] = str(res.get("error") or f"HTTP {res.get('status_code')}")
            error_details.append(
                {
                    "target": aid,
                    "upstream_url": res.get("url"),
                    "upstream_status": res.get("status_code"),
                    "error": errors[aid],
                    **(
                        {"upstream_body": res["upstream_body"]}
                        if "upstream_body" in res
                        else {}
                    ),
                    **(
                        {"exception_type": res["exception_type"]}
                        if "exception_type" in res
                        else {}
                    ),
                }
            )

    if not artifacts and error_details:
        raise HTTPException(
            status_code=502,
            detail={
                "error": f"Failed to load Plan {plan_number} feeds from API Gateway ({len(error_details)} action failure(s)).",
                "operation": "bootstrap",
                "plan_number": plan_number,
                "upstream_url": f"{GATEWAY_BASE}/api/v1/actions",
                "upstream_status": error_details[0].get("upstream_status"),
                "errors": errors,
                "error_details": error_details,
            },
        )

    raw_catalog, cat_notice, query_mode, cat_error_details = await _fetch_catalog_live(
        plan_number, user_details=scope_user_details
    )
    if cat_notice:
        errors["catalog"] = cat_notice
        error_details.extend(cat_error_details)

    return (
        availability,
        artifacts,
        raw_catalog,
        errors,
        query_mode,
        error_details,
        task_status,
        resolved_scope,
        scope_source,
    )


def _derive_affected_sections(actions: List[Dict[str, Any]]) -> List[str]:
    affected: Set[str] = set()
    for act in actions or []:
        if not isinstance(act, dict):
            continue
        dtype = _normalize_doc_type(act.get("document_type") or "policy")
        for sec in _AFFECTED_SECTIONS_MAP.get(dtype, ("broad_scope",)):
            affected.add(sec)
    return [s for s in ("past_review", "policy_regulation", "broad_scope") if s in affected]


def _normalize_summary_user_details(raw: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Build a UserRequest-compatible dict for scoping-summary-agent."""
    base = _normalize_user_details(raw)
    out: Dict[str, Any] = {
        k: v
        for k, v in base.items()
        if k in ("process_instance_id", "task_id", "review_scope_stage", "user", "remarks")
        and v not in (None, "")
    }
    raw_scope = (raw or {}).get("review_scope_id") if isinstance(raw, dict) else None
    if raw_scope in (None, ""):
        raw_scope = base.get("review_scope_id")
    if isinstance(raw_scope, int) and not isinstance(raw_scope, bool):
        out["review_scope_id"] = raw_scope
        out["review_scope_instance_id"] = str(raw_scope)
    elif raw_scope not in (None, ""):
        cleaned = str(raw_scope).strip()
        if cleaned.lstrip("-").isdigit():
            out["review_scope_id"] = int(cleaned)
            out["review_scope_instance_id"] = cleaned
    return out


def _unwrap_preliminary_research_response(plan_number: str, raw: Any) -> Optional[Dict[str, Any]]:
    """Extract canonical `{plan_number, analysis_report}` from scoping-summary-agent payloads."""
    if not isinstance(raw, dict):
        return None
    pr_titles = {item["title"] for item in PR_SECTIONS}
    queue: List[Any] = [raw]
    seen: Set[int] = set()
    while queue:
        cur = queue.pop(0)
        if not isinstance(cur, dict) or id(cur) in seen:
            continue
        seen.add(id(cur))
        report = cur.get("analysis_report")
        if isinstance(report, dict) and report:
            resolved_plan = str(cur.get("plan_number") or cur.get("planNumber") or plan_number).strip()
            return {"plan_number": resolved_plan, "analysis_report": report}
        if any(title in cur and isinstance(cur.get(title), dict) for title in pr_titles):
            return {"plan_number": str(plan_number).strip(), "analysis_report": cur}
        for key in ("response", "payload", "data", "result"):
            if key in cur and cur[key] is not None:
                queue.append(cur[key])
    return None


async def _fetch_preliminary_research_on_bootstrap(plan_number: str) -> Dict[str, Any]:
    """Fetch the stored Preliminary Research document through the API Gateway."""
    try:
        raw = await _call_gateway_action("GET_PRELIMINARY_RESEARCH_DOCUMENT", plan_number, {})
    except HTTPException as exc:
        if exc.status_code == 404:
            error = None
        else:
            detail = exc.detail if isinstance(exc.detail, dict) else {"error": str(exc.detail)}
            error = str(detail.get("error") or f"HTTP {exc.status_code}")
        return {
            "available": False,
            "plan_number": plan_number,
            "analysis_report": None,
            "source": "master_agent_gateway",
            "error": error,
        }
    except Exception as exc:
        logger.info("Bootstrap Preliminary Research check through gateway failed: %s", exc)
        return {
            "available": False,
            "plan_number": plan_number,
            "analysis_report": None,
            "source": "master_agent_gateway",
            "error": f"{type(exc).__name__}: {exc}",
        }

    unwrapped = _unwrap_preliminary_research_response(plan_number, raw)
    if unwrapped:
        return {
            "available": True,
            "plan_number": unwrapped["plan_number"],
            "analysis_report": unwrapped["analysis_report"],
            "source": "master_agent_gateway",
            "error": None,
        }
    return {
        "available": False,
        "plan_number": plan_number,
        "analysis_report": None,
        "source": "master_agent_gateway",
        "error": "Gateway response missing analysis_report.",
    }


@app.get("/api/config")
async def get_config() -> Dict[str, Any]:
    """Return CT1 API Gateway settings and artifact metadata definitions."""
    return {
        "cta_host": CTA_HOST,
        "gateway_base": GATEWAY_BASE,
        "gateway_only": True,
        "default_plan_number": DEFAULT_PLAN_NUMBER,
        "artifacts": PLAN_ARTIFACTS,
        "pr_sections": PR_SECTIONS,
        "upload_limits": {
            "max_files": 5,
            "max_file_mb": 20,
            "allowed_extensions": [".pdf", ".docx", ".txt"],
        },
    }


@app.get("/api/ct1/trace")
async def get_api_trace(since_id: int = Query(default=0, ge=0)) -> Dict[str, Any]:
    """Return recorded upstream API Gateway HTTP requests and responses."""
    entries = [entry for entry in _API_TRACE_LOG if int(entry.get("id", 0)) > since_id]
    return {
        "entries": entries,
        "latest_id": _API_TRACE_SEQ,
        "total": len(_API_TRACE_LOG),
        "gateway_base": GATEWAY_BASE,
    }


@app.delete("/api/ct1/trace")
async def clear_api_trace() -> Dict[str, Any]:
    """Clear the in-memory upstream API Gateway trace log."""
    _API_TRACE_LOG.clear()
    return {"cleared": True, "latest_id": _API_TRACE_SEQ, "total": 0}


@app.get("/api/ct1/task/status/{plan_number}")
async def proxy_task_status(plan_number: str) -> Dict[str, Any]:
    """Pass through the live workflow task status for a plan from CT1 API Gateway."""
    task_status, error = await _fetch_task_status_best_effort(plan_number)
    return {
        "plan_number": plan_number,
        "available": task_status is not None,
        "task_status": task_status,
        "scope_context": _scope_from_task_status(task_status),
        "error": error,
    }


@app.get("/api/ct1/plan/{plan_number}/bootstrap")
async def bootstrap_plan(
    plan_number: str,
    review_scope_id: Optional[str] = Query(default=None),
    process_instance_id: Optional[str] = Query(default=None),
    task_id: Optional[str] = Query(default=None),
    review_scope_stage: Optional[str] = Query(default=None),
    user: Optional[str] = Query(default=None),
) -> Dict[str, Any]:
    """
    Fetch live availability, all 9 Data Extraction payloads, live document catalog,
    and saved Preliminary Research document strictly through CT1 API Gateway.
    """
    started = time.perf_counter()
    scope_context = {
        "review_scope_id": review_scope_id,
        "process_instance_id": process_instance_id,
        "task_id": task_id,
        "review_scope_stage": review_scope_stage,
        "user": user,
    }
    bundle, preliminary_research = await asyncio.gather(
        _load_plan_bundle(plan_number, scope_context),
        _fetch_preliminary_research_on_bootstrap(plan_number),
    )
    (
        availability,
        artifacts,
        catalog,
        errors,
        query_mode,
        error_details,
        task_status,
        resolved_scope,
        scope_source,
    ) = bundle
    return {
        "plan_number": plan_number,
        "cta_host": CTA_HOST,
        "gateway_base": GATEWAY_BASE,
        "gateway_only": True,
        "query_mode": query_mode,
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
        "catalog": catalog,
        "availability": availability,
        "artifacts": artifacts,
        "preliminary_research": preliminary_research,
        "errors": errors,
        "has_errors": bool(error_details),
        "error_details": error_details,
        "task_status": task_status,
        "scope_context": resolved_scope,
        "scope_source": scope_source,
    }


@app.get("/api/ct1/dataextraction/status/{session_id}")
async def proxy_extraction_status(
    session_id: str,
    plan_number: str = Query(default=DEFAULT_PLAN_NUMBER),
) -> Dict[str, Any]:
    """Poll CT1 data extraction job status via API Gateway action `GET_DATA_EXTRACTION_STATUS`."""
    return await _call_gateway_action(
        "GET_DATA_EXTRACTION_STATUS",
        str(plan_number or DEFAULT_PLAN_NUMBER).strip(),
        {"session_id": session_id},
    )


@app.get("/api/ct1/dataextraction/{plan_number}/{artifact}")
async def proxy_get_artifact(
    plan_number: str,
    artifact: str,
    review_scope_id: Optional[str] = Query(default=None),
    process_instance_id: Optional[str] = Query(default=None),
    task_id: Optional[str] = Query(default=None),
    review_scope_stage: Optional[str] = Query(default=None),
) -> Any:
    """Fetch a single plan artifact through API Gateway action `GET_PLAN_ARTIFACT`."""
    scope = {
        k: str(v).strip()
        for k, v in {
            "review_scope_id": review_scope_id,
            "process_instance_id": process_instance_id,
            "task_id": task_id,
            "review_scope_stage": review_scope_stage,
        }.items()
        if v not in (None, "") and str(v).strip()
    }
    payload: Dict[str, Any] = {"artifact": artifact, **scope}
    if scope:
        payload["userDetails"] = _normalize_user_details(scope)
    return await _call_gateway_action("GET_PLAN_ARTIFACT", plan_number, payload)


@app.post("/api/ct1/dataextraction/run")
async def proxy_run_extraction(payload: ExtractionRunRequest) -> Dict[str, Any]:
    """Trigger a fresh CT1 data extraction run via API Gateway action `DATA_EXTRACTION`."""
    user_details = _normalize_user_details(payload.userDetails)
    return await _call_gateway_action(
        "DATA_EXTRACTION",
        str(payload.planNumber).strip(),
        {"userDetails": user_details},
    )


_MAX_CHAT_QUERY_CHARS = 4000
_GUARDRAIL_PROMPT_INJECTION_RE = re.compile(
    r"(?:"
    r"\b(?:ignore|disregard|forget|override|bypass)\s+(?:all\s+|any\s+)?(?:previous|prior|above|system|developer)\s+(?:instructions?|prompts?|rules?|guardrails?)\b"
    r"|\b(?:reveal|print|show|dump|output|leak)\s+(?:your\s+|the\s+)?(?:system\s+prompt|hidden\s+instructions?|developer\s+message)\b"
    r"|\b(?:bypass|skip|disable|turn\s+off)\s+(?:the\s+)?(?:approval|human\s+review|verification|security|compliance|guardrails?)\b"
    r"|\b(?:you\s+are\s+now\s+in\s+developer\s+mode|act\s+as\s+an\s+unrestricted|jailbreak)\b"
    r")",
    re.IGNORECASE,
)
_GUARDRAIL_BULK_WIPE_RE = re.compile(
    r"(?:"
    r"\b(?:remove|delete|exclude|drop|wipe|clear|purge)\s+(?:all|every)\s+(?:the\s+)?(?:documents?|policies|kods?|procedures?|gfms|findings?|mandates?|files?|records?|context|data)\b"
    r"|\b(?:remove|delete|exclude|wipe|clear|purge)\s+everything\b"
    r")",
    re.IGNORECASE,
)
_GUARDRAIL_PAYLOAD_RE = re.compile(
    r"(?:\.\./|\.\.\\|<\s*script\b|javascript\s*:|;\s*(?:drop|delete|truncate|update|insert|alter)\s+(?:table|from|into)\b|\bunion\s+(?:all\s+)?select\b)",
    re.IGNORECASE,
)
_GUARDRAIL_SECRET_RE = re.compile(
    r"\b(?:bearer\s+[a-z0-9._\-]{8,}|(?:api[_-]?key|token|secret|password|passwd)\s*[:=]\s*['\"]?[^\s,;'\"]{4,}['\"]?)",
    re.IGNORECASE,
)


def _check_chat_guardrails(user_text: str, plan_number: str) -> Tuple[str, Optional[str]]:
    """Sanitize chat input and block prompt injection, cross-plan, script/SQL, or mass-wipe attempts."""
    cleaned = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", str(user_text or ""))
    cleaned = _GUARDRAIL_SECRET_RE.sub("[REDACTED]", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    if not cleaned:
        return "", "Query cannot be empty."
    if len(cleaned) > _MAX_CHAT_QUERY_CHARS:
        return cleaned[:_MAX_CHAT_QUERY_CHARS], f"Query exceeds maximum permitted length ({_MAX_CHAT_QUERY_CHARS} chars)."
    if _GUARDRAIL_PROMPT_INJECTION_RE.search(cleaned):
        return cleaned, "Blocked potential prompt injection or guardrail-bypass instruction."
    if _GUARDRAIL_PAYLOAD_RE.search(cleaned):
        return cleaned, "Blocked unsafe path-traversal, script, or SQL-injection payload."
    if _GUARDRAIL_BULK_WIPE_RE.search(cleaned):
        return cleaned, (
            "Compliance policy prohibits bulk-deleting all scoping documents at once. "
            "Specify the individual document(s) or section(s)."
        )
    for ref_plan in re.findall(r"\bdbaware_review_(\d+)\b", cleaned, flags=re.IGNORECASE):
        if ref_plan.strip() != str(plan_number).strip():
            return cleaned, f"Cross-plan access blocked: plan {ref_plan} does not match active plan {plan_number}."

    cleaned = cleaned.replace("<<<", "< < <").replace(">>>", "> > >")
    return cleaned, None


def _normalize_document_workflow_response(
    data: Any,
    *,
    operation: str,
    url: str,
    upstream_status: int,
    plan_number: str,
) -> Any:
    """Normalize document_workflow approval/execution/error shapes from Query Service."""
    if not isinstance(data, dict) or not isinstance(data.get("document_workflow"), dict):
        return data

    wf = data["document_workflow"]
    stage = str(wf.get("stage") or data.get("stage") or "").strip().lower()
    if stage and not wf.get("stage"):
        wf["stage"] = stage
    wf_status = str(wf.get("status") or "").strip().lower()
    exec_obj = wf.get("execution") if isinstance(wf.get("execution"), dict) else {}
    exec_status = str(exec_obj.get("status") or "").strip().lower()
    failed_list: List[Any] = []
    for candidate_failures in (
        wf.get("failed"),
        exec_obj.get("failed"),
        (exec_obj.get("audit") or {}).get("failures") if isinstance(exec_obj.get("audit"), dict) else None,
        (wf.get("audit") or {}).get("failures") if isinstance(wf.get("audit"), dict) else None,
    ):
        if isinstance(candidate_failures, list) and candidate_failures:
            failed_list.extend(candidate_failures)

    answer_text = str(data.get("answer") or "")
    is_wf_error = (
        stage in ("error", "partial_failure")
        or wf_status in ("error", "partial_failure")
        or exec_status in ("error", "partial_failure")
        or bool(failed_list)
        or (stage == "executed" and exec_obj.get("registry_updated") is False)
        or ("no document changes were applied" in answer_text.lower())
    )

    if is_wf_error:
        if stage == "executed" and (
            wf_status in ("error", "partial_failure")
            or exec_status in ("error", "partial_failure")
            or exec_obj.get("registry_updated") is False
            or not (exec_obj.get("executed") or wf.get("executed"))
        ):
            wf["raw_stage"] = stage
            wf["stage"] = (
                "partial_failure"
                if (wf_status == "partial_failure" or exec_status == "partial_failure")
                else "error"
            )
        data["error_details"] = {
            "operation": operation,
            "upstream_url": url,
            "upstream_status": upstream_status,
            "plan_number": plan_number,
            "stage": wf.get("stage"),
            "status": wf_status or exec_status or "error",
            "message": answer_text or str(wf.get("message") or "Document workflow execution failed."),
            "failed": failed_list,
            "audit": exec_obj.get("audit") or wf.get("audit") or {},
            "raw_workflow": wf,
        }
        return data

    if stage in ("pending_approval", "awaiting_approval") or (
        wf.get("requires_approval") is True
        and stage
        not in (
            "executed",
            "cancelled",
            "rejected",
            "no_verified_actions",
            "not_document_request",
            "not_found",
            "error",
        )
    ):
        proposed = (
            wf.get("steps")
            or (wf.get("plan") or {}).get("actions")
            or wf.get("actions")
            or []
        )
        if proposed:
            wf["stage"] = "awaiting_approval"
            wf["actions"] = proposed
            wf["steps"] = proposed
            wf["plan"] = {"actions": proposed}
        return data

    if stage == "executed":
        executed = (
            (wf.get("execution") or {}).get("executed")
            or wf.get("executed")
            or (wf.get("execution_json") or {}).get("actions")
            or (wf.get("plan") or {}).get("actions")
            or wf.get("actions")
            or wf.get("steps")
            or []
        )
        wf["executed"] = executed
        if executed and not wf.get("actions"):
            wf["actions"] = executed
        if not wf.get("affected_sections"):
            wf["affected_sections"] = _derive_affected_sections(executed)

    return data


@app.post("/api/ct1/query/chat")
async def proxy_query_chat(payload: ChatProxyRequest) -> Dict[str, Any]:
    """Forward Q&A chat turns through API Gateway action `QNA_CHAT`."""
    plan_number = str(payload.plan_number).strip()
    clean_question, violation = _check_chat_guardrails(payload.question, plan_number)
    if violation is not None:
        logger.warning("Guardrail blocked Demo UI chat query for Plan %s: %s", plan_number, violation)
        return {
            "session_id": plan_number,
            "answer": f"Request blocked by security & compliance guardrail: {violation}",
            "document_workflow": {
                "stage": "rejected",
                "status": "rejected_by_guardrail",
                "plan_number": plan_number,
                "requires_approval": False,
            },
        }

    url = f"{GATEWAY_BASE}/api/v1/actions"
    body: Dict[str, Any] = {
        "question": clean_question,
        "plan_number": plan_number,
        "context_type": payload.context_type,
        "userDetails": _normalize_user_details(payload.userDetails),
    }
    if payload.plan_name:
        body["plan_name"] = payload.plan_name
    if isinstance(payload.research_sections, dict) and payload.research_sections:
        body["research_sections"] = payload.research_sections

    data = await _call_gateway_action("QNA_CHAT", plan_number, body)
    return _normalize_document_workflow_response(
        data,
        operation="query_chat",
        url=url,
        upstream_status=200,
        plan_number=plan_number,
    )


@app.post("/api/ct1/query/add-remove")
async def proxy_query_add_remove(payload: DocumentAddRemoveProxyRequest) -> Dict[str, Any]:
    """Forward document inclusion/exclusion workflow turns through API Gateway action `DOCUMENT_ADD_REMOVE`."""
    plan_number = str(payload.plan_number).strip()
    raw_text = payload.user_text if payload.user_text is not None else (payload.question or "")
    if not str(raw_text).strip():
        raise HTTPException(status_code=422, detail="user_text is required.")

    clean_text, violation = _check_chat_guardrails(raw_text, plan_number)
    if violation is not None:
        logger.warning("Guardrail blocked Demo UI add/remove query for Plan %s: %s", plan_number, violation)
        return {
            "plan_number": plan_number,
            "stage": "rejected",
            "answer": f"Request blocked by security & compliance guardrail: {violation}",
            "document_workflow": {
                "stage": "rejected",
                "status": "rejected_by_guardrail",
                "plan_number": plan_number,
                "requires_approval": False,
            },
        }

    url = f"{GATEWAY_BASE}/api/v1/actions"
    body: Dict[str, Any] = {
        "user_text": clean_text,
        "plan_number": plan_number,
        "context_type": payload.context_type,
        "userDetails": _normalize_user_details(payload.userDetails),
    }

    data = await _call_gateway_action("DOCUMENT_ADD_REMOVE", plan_number, body)
    return _normalize_document_workflow_response(
        data,
        operation="query_add_remove",
        url=url,
        upstream_status=200,
        plan_number=plan_number,
    )


def _infer_doc_type_from_filename(filename: str, explicit_type: str = "auto") -> str:
    """Resolve document category (`policy`, `kod`, or `procedure`) from explicit choice or filename."""
    raw = str(explicit_type or "auto").strip().lower()
    if raw and raw != "auto":
        normalized = _normalize_doc_type(raw)
        if normalized in _RAG_FIELD_MAP:
            return normalized

    stem = Path(filename or "").stem.lower()
    if re.search(r"(^|[^a-z0-9])kod([^a-z0-9]|$)|key[_\s-]+operating", stem):
        return "kod"
    if re.search(r"procedure|(^|[^a-z0-9])(proc|sop)([^a-z0-9]|$)", stem):
        return "procedure"
    return "policy"


_RAG_DOC_ID_SCALAR_KEYS = {"document_id", "doc_id", "documentid", "docid"}
_RAG_DOC_ID_LIST_KEYS = {
    "document_ids",
    "doc_ids",
    "documentids",
    "docids",
    "ids",
    "policy_ids",
    "kod_ids",
    "procedure_ids",
    "policy_document_ids",
    "kod_document_ids",
    "procedure_document_ids",
    "ingested_document_ids",
    "created_document_ids",
}
_RAG_DOC_CONTAINER_KEYS = {
    "documents",
    "files",
    "results",
    "ingested_documents",
    "ingested_files",
    "processed_files",
    "succeeded",
    "completed",
    "items",
    "policy",
    "kod",
    "procedure",
    "policy_files",
    "kod_files",
    "procedure_files",
}
_RAG_JOB_ID_KEYS = ("job_id", "jobId", "ingest_job_id", "ingestJobId", "task_id", "taskId", "id")


def _extract_rag_job_id(payload: Any) -> str:
    """Recursively locate a RAG ingestion job identifier from `/ingest-documents` responses."""
    if not isinstance(payload, (dict, list)):
        return ""
    queue: List[Any] = [payload]
    visited: Set[int] = set()
    fallback_id = ""
    while queue:
        node = queue.pop(0)
        if id(node) in visited:
            continue
        visited.add(id(node))
        if isinstance(node, dict):
            for key in _RAG_JOB_ID_KEYS:
                val = node.get(key)
                if val is not None and not isinstance(val, (bool, dict, list)):
                    sval = str(val).strip()
                    if sval:
                        if key != "id":
                            return sval
                        if not fallback_id:
                            fallback_id = sval
            for nested_key in ("data", "result", "job", "jobs", "details"):
                child = node.get(nested_key)
                if isinstance(child, (dict, list)):
                    queue.append(child)
        elif isinstance(node, list):
            for item in node:
                if isinstance(item, (dict, list)):
                    queue.append(item)
    return fallback_id


def _extract_rag_doc_ids(payload: Any) -> List[int]:
    """Recursively collect numeric document IDs from RAG ingest / job status responses."""
    candidates: List[Any] = []
    visited: Set[int] = set()

    def _walk(node: Any, *, allow_generic_id: bool = False) -> None:
        if node is None or isinstance(node, (bool, bytes)):
            return
        if isinstance(node, (dict, list)):
            if id(node) in visited:
                return
            visited.add(id(node))

        if isinstance(node, dict):
            for k, v in node.items():
                k_low = str(k).strip().lower()
                if k_low in _RAG_DOC_ID_SCALAR_KEYS or (allow_generic_id and k_low == "id"):
                    if not isinstance(v, (bool, dict, list)) and v is not None:
                        candidates.append(v)
                elif k_low in _RAG_DOC_ID_LIST_KEYS:
                    if isinstance(v, list):
                        for item in v:
                            if isinstance(item, (dict, list)):
                                _walk(item, allow_generic_id=True)
                            else:
                                candidates.append(item)
                    elif isinstance(v, dict):
                        _walk(v, allow_generic_id=True)
                    elif v is not None and not isinstance(v, bool):
                        candidates.append(v)
                elif k_low in _RAG_DOC_CONTAINER_KEYS:
                    if isinstance(v, list):
                        for item in v:
                            if isinstance(item, (dict, list)):
                                _walk(item, allow_generic_id=True)
                            elif isinstance(item, (int, str)):
                                candidates.append(item)
                    elif isinstance(v, dict):
                        _walk(v, allow_generic_id=True)
                elif isinstance(v, (dict, list)):
                    _walk(v, allow_generic_id=allow_generic_id)
        elif isinstance(node, list):
            for item in node:
                if isinstance(item, (dict, list)):
                    _walk(item, allow_generic_id=allow_generic_id)

    _walk(payload, allow_generic_id=False)

    seen: Set[int] = set()
    out: List[int] = []
    for item in candidates:
        if isinstance(item, bool):
            continue
        sval = str(item).strip()
        if sval.lstrip("-").isdigit():
            ival = int(sval)
            if ival not in seen:
                seen.add(ival)
                out.append(ival)
    return out


def _parse_categorize_response(raw_cat: Any) -> Dict[int, str]:
    """Normalize `/categorize-document-ids` output into `{doc_id: 'policy'|'kod'|'procedure'}`."""
    mapping: Dict[int, str] = {}
    if not isinstance(raw_cat, (dict, list)):
        return mapping

    def _absorb_item(item: Dict[str, Any], default_type: Optional[str] = None) -> None:
        raw_id = item.get("document_id") if item.get("document_id") is not None else item.get("id")
        raw_type = item.get("document_type") or item.get("category") or item.get("type") or default_type
        if raw_id is not None and str(raw_id).strip().lstrip("-").isdigit() and raw_type:
            norm_t = _normalize_doc_type(raw_type)
            if norm_t in _RAG_FIELD_MAP:
                mapping[int(str(raw_id).strip())] = norm_t

    containers: List[Any] = [raw_cat]
    if isinstance(raw_cat, dict):
        for nested_key in ("categorized", "categories", "document_categories", "results", "documents", "data"):
            if nested_key in raw_cat and raw_cat[nested_key] is not None:
                containers.append(raw_cat[nested_key])

    for node in containers:
        if isinstance(node, list):
            for entry in node:
                if isinstance(entry, dict):
                    _absorb_item(entry)
        elif isinstance(node, dict):
            for k, v in node.items():
                k_norm = _normalize_doc_type(k)
                if k_norm in _RAG_FIELD_MAP and isinstance(v, list):
                    for sub in v:
                        if isinstance(sub, dict):
                            _absorb_item(sub, default_type=k_norm)
                        elif str(sub).strip().lstrip("-").isdigit():
                            mapping[int(str(sub).strip())] = k_norm
                elif str(k).strip().lstrip("-").isdigit() and isinstance(v, str):
                    v_norm = _normalize_doc_type(v)
                    if v_norm in _RAG_FIELD_MAP:
                        mapping[int(str(k).strip())] = v_norm
    return mapping


def _build_rag_relevant_payload_from_artifacts(
    plan_number: str,
    artifacts: Dict[str, Any],
    documents_spec: List[Dict[str, Any]],
    overrides: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build `/get-relevant-data-for-documents` JSON body from CT1 `current_details` + `control_details`."""
    ov = {k: v for k, v in (overrides or {}).items() if v is not None}
    plan_det = (_unwrap_data_dict(artifacts.get("current_details")) or {}).get("plan_details") or {}
    if not isinstance(plan_det, dict):
        plan_det = {}
    ctrl_wrap = (_unwrap_data_dict(artifacts.get("control_details")) or {}).get("control_details") or {}
    controls = (
        ctrl_wrap.get("included_kcs")
        if isinstance(ctrl_wrap, dict) and isinstance(ctrl_wrap.get("included_kcs"), list)
        else []
    )

    def _split_list(val: Any) -> List[str]:
        if isinstance(val, list):
            return [str(x).strip() for x in val if str(x).strip()]
        if not val:
            return []
        sep = ";" if ";" in str(val) else ","
        return [p.strip() for p in str(val).split(sep) if p.strip()]

    au_rt_kc = plan_det.get("AU-RT-KC") if isinstance(plan_det.get("AU-RT-KC"), list) else []
    au_list = list(dict.fromkeys(str(r["AU"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("AU")))
    rt_list = list(dict.fromkeys(str(r["RT"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("RT")))
    kc_list = list(dict.fromkeys(str(r["KC"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("KC")))
    if not rt_list and plan_det.get("UoT Risk Type"):
        rt_list = [str(plan_det["UoT Risk Type"]).split(" - ", 1)[0].strip()]
    if not kc_list and plan_det.get("UoT KCs"):
        kc_list = [str(plan_det["UoT KCs"]).split(" - ", 1)[0].strip()]

    c_names: List[str] = []
    c_how: List[str] = []
    c_what: List[str] = []
    c_why: List[str] = []
    for ctrl in controls:
        if not isinstance(ctrl, dict):
            continue
        inv = ctrl.get("inventory") if isinstance(ctrl.get("inventory"), dict) else {}
        defn = ctrl.get("definition") if isinstance(ctrl.get("definition"), dict) else {}
        det = ctrl.get("details") if isinstance(ctrl.get("details"), dict) else {}
        nm = (
            inv.get("controlDefinitionName")
            or defn.get("controlDefinitionName")
            or det.get("control_name")
            or inv.get("controlDefinitionNumber")
        )
        hw = det.get("control_how") or inv.get("controlHow") or defn.get("controlHow")
        wh = det.get("control_what") or inv.get("controlWhat") or defn.get("controlWhat")
        wy = det.get("control_why") or inv.get("controlWhy") or defn.get("controlWhy")
        for bucket, val in ((c_names, nm), (c_how, hw), (c_what, wh), (c_why, wy)):
            if val and str(val).strip() and str(val).strip() not in bucket:
                bucket.append(str(val).strip())

    return {
        "review_id": str(ov.get("review_id") or plan_number),
        "region": str(ov.get("region") or plan_det.get("AU Region") or plan_det.get("UoT Regions") or "").strip(),
        "au_countries": ov.get("au_countries") if "au_countries" in ov else _split_list(plan_det.get("UoT Countries")),
        "plan_item_title": str(ov.get("plan_item_title") or plan_det.get("Plan Item Title") or "").strip(),
        "plan_item_description": str(ov.get("plan_item_description") or plan_det.get("Description of Plan Item") or "").strip(),
        "au_list": ov.get("au_list") if "au_list" in ov else au_list,
        "rt_list": ov.get("rt_list") if "rt_list" in ov else rt_list,
        "kc_list": ov.get("kc_list") if "kc_list" in ov else kc_list,
        "control_name": ov.get("control_name") if "control_name" in ov else c_names,
        "control_how": ov.get("control_how") if "control_how" in ov else c_how,
        "control_what": ov.get("control_what") if "control_what" in ov else c_what,
        "control_why": ov.get("control_why") if "control_why" in ov else c_why,
        "documents": documents_spec,
    }


def _normalize_rag_section_list(raw_sections: Any, prefix: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if not isinstance(raw_sections, list):
        return out
    for idx, sec in enumerate(raw_sections, start=1):
        if isinstance(sec, str):
            text = sec.strip()
            if not text:
                continue
            out.append(
                {
                    "section_id": str(idx),
                    "section_title": text.splitlines()[0][:80],
                    "node_id": f"{prefix}:sec:{idx}",
                    "original_text": text[:800],
                    "status": "active",
                    "excluded": False,
                }
            )
        elif isinstance(sec, dict):
            sid = str(sec.get("section_id") or sec.get("id") or idx)
            stitle = str(
                sec.get("section_title")
                or sec.get("title")
                or sec.get("heading")
                or (sec.get("section_path") or "").split(">")[-1]
                or f"Section {sid}"
            ).strip()
            body = str(sec.get("original_text") or sec.get("content") or sec.get("text") or sec.get("chunk_text") or stitle).strip()
            item: Dict[str, Any] = {
                "section_id": sid,
                "section_title": stitle,
                "node_id": str(sec.get("node_id") or f"{prefix}:sec:{sid}"),
                "original_text": body[:800],
                "status": "active",
                "excluded": False,
            }
            if sec.get("section_path"):
                item["section_path"] = sec["section_path"]
            if sec.get("page_start") is not None:
                item["page_start"] = sec["page_start"]
            out.append(item)
    return out


def _extract_sections_from_rag_relevant_data(rag_resp: Any) -> Dict[str, List[Dict[str, Any]]]:
    """Extract normalized section lists keyed by doc_id (`str(id)`) or `document_type`."""
    by_key: Dict[str, List[Dict[str, Any]]] = {}
    if not isinstance(rag_resp, (dict, list)):
        return by_key

    items: List[Tuple[Optional[str], Dict[str, Any]]] = []
    if isinstance(rag_resp, list):
        items.extend((None, x) for x in rag_resp if isinstance(x, dict))
    else:
        for container_key in ("results", "documents", "relevant_documents", "referenced_documents"):
            val = rag_resp.get(container_key)
            if isinstance(val, list):
                items.extend((None, x) for x in val if isinstance(x, dict))
            elif isinstance(val, dict):
                for dtype, sub in val.items():
                    if isinstance(sub, list):
                        items.extend((_normalize_doc_type(dtype), x) for x in sub if isinstance(x, dict))
        for dtype in ("policy", "kod", "procedure"):
            if isinstance(rag_resp.get(dtype), list):
                items.extend((dtype, x) for x in rag_resp[dtype] if isinstance(x, dict))

    for hinted_type, entry in items:
        nested_docs = entry.get("referenced_documents") or entry.get("documents")
        if isinstance(nested_docs, list):
            for sub in nested_docs:
                if isinstance(sub, dict):
                    items.append((hinted_type or entry.get("document_type"), sub))
        raw_id = entry.get("document_id") if entry.get("document_id") is not None else entry.get("id")
        dtype = _normalize_doc_type(entry.get("document_type") or hinted_type or "policy")
        key_id = str(raw_id).strip() if raw_id is not None else None
        raw_secs = (
            entry.get("nodes")
            or entry.get("sections")
            or entry.get("relevant_sections")
            or entry.get("chunks")
            or entry.get("paragraphs")
        )
        prefix = f"rag-{key_id}" if key_id else f"rag-{dtype}"
        norm_secs = _normalize_rag_section_list(raw_secs, prefix=prefix)
        if not norm_secs and (entry.get("content") or entry.get("text") or entry.get("section_title")):
            norm_secs = _normalize_rag_section_list([entry], prefix=prefix)
        if norm_secs:
            if key_id:
                by_key.setdefault(key_id, []).extend(norm_secs)
            by_key.setdefault(dtype, []).extend(norm_secs)
    return by_key


async def _fetch_plan_context_artifacts(
    plan_number: str,
    scope: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Fetch `current_details` + `control_details` via API Gateway `GET_PLAN_ARTIFACT`."""
    cur_res, ctrl_res = await asyncio.gather(
        _fetch_artifact_safe(plan_number, "current_details", scope),
        _fetch_artifact_safe(plan_number, "control_details", scope),
    )
    artifacts: Dict[str, Any] = {}
    if cur_res.get("ok"):
        artifacts["current_details"] = cur_res["data"]
    if ctrl_res.get("ok"):
        artifacts["control_details"] = ctrl_res["data"]
    return artifacts


def _extract_rag_doc_metadata(rag_resp: Any) -> Dict[str, Dict[str, Any]]:
    """Extract per-document RAG relevance metadata (verdict, score, rationale, storage_uri, title)."""
    meta_by_key: Dict[str, Dict[str, Any]] = {}
    if not isinstance(rag_resp, (dict, list)):
        return meta_by_key

    queue: List[Any] = [rag_resp]
    visited: Set[int] = set()
    while queue:
        node = queue.pop(0)
        if not isinstance(node, (dict, list)) or id(node) in visited:
            continue
        visited.add(id(node))
        if isinstance(node, list):
            queue.extend(node)
            continue

        raw_id = node.get("document_id") if node.get("document_id") is not None else node.get("id")
        has_doc_signals = any(
            k in node
            for k in (
                "document_relevance_verdict",
                "document_relevance_score",
                "nodes",
                "sections",
                "storage_uri",
                "gs_uri",
                "document_title",
                "document_name",
            )
        )
        if raw_id is not None and not isinstance(raw_id, (dict, list, bool)) and has_doc_signals:
            key = str(raw_id).strip()
            entry = meta_by_key.setdefault(key, {})
            for field in (
                "document_title",
                "document_name",
                "document_type",
                "file_name",
                "filename",
                "storage_uri",
                "gs_uri",
                "document_relevance_verdict",
                "document_relevance_score",
                "rationale",
                "summary",
                "status",
            ):
                if node.get(field) not in (None, ""):
                    entry[field] = node.get(field)
        for v in node.values():
            if isinstance(v, (dict, list)):
                queue.append(v)
    return meta_by_key


def _extract_rag_ingest_summary_and_items(payload: Any) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Extract RAG ingest summary counts and per-file status items from ingest / job status payloads."""
    summary: Dict[str, Any] = {}
    items: List[Dict[str, Any]] = []
    if not isinstance(payload, dict):
        return summary, items

    candidates: List[Dict[str, Any]] = [payload]
    for nested in ("details", "data", "result", "job"):
        child = payload.get(nested)
        if isinstance(child, dict):
            candidates.append(child)
            if isinstance(child.get("details"), dict):
                candidates.append(child["details"])

    for cand in candidates:
        raw_sum = cand.get("summary")
        if isinstance(raw_sum, dict) and raw_sum:
            summary.update(raw_sum)
        for bucket_name, default_status in (
            ("indexed", "indexed"),
            ("already_indexed", "already_indexed"),
            ("invalid", "invalid"),
            ("failed", "failed"),
            ("in_progress", "in_progress"),
            ("queued", "queued"),
        ):
            bucket = cand.get(bucket_name)
            if isinstance(bucket, list):
                for entry in bucket:
                    if isinstance(entry, dict):
                        issues = entry.get("issues")
                        issues_str = "; ".join(str(x) for x in issues) if isinstance(issues, list) and issues else None
                        items.append(
                            {
                                "status": str(entry.get("status") or default_status),
                                "filename": entry.get("filename") or entry.get("file_name") or entry.get("name"),
                                "document_id": entry.get("document_id") if entry.get("document_id") is not None else entry.get("id"),
                                "document_type": entry.get("document_type") or entry.get("category") or entry.get("type"),
                                "message": entry.get("message") or entry.get("reason") or entry.get("error") or issues_str,
                                **({"issues": issues} if isinstance(issues, list) and issues else {}),
                            }
                        )
                    elif isinstance(entry, (int, str)):
                        items.append({"status": default_status, "document_id": entry})

    # Deduplicate items by (status, filename, document_id)
    deduped: List[Dict[str, Any]] = []
    seen_keys: Set[Tuple[Any, Any, Any]] = set()
    for it in items:
        k = (it.get("status"), it.get("filename"), str(it.get("document_id")))
        if k not in seen_keys:
            seen_keys.add(k)
            deduped.append(it)
    return summary, deduped


def _is_ingest_job_in_progress(payload: Any) -> bool:
    """Return True while a multi-file RAG ingest job still has active/unindexed files.

    Note: In `dbaware-rag-service` (`DocumentIngestionService._job_view`), `summary.queued`
    is the *total* number of files originally queued (it stays > 0 even after `status == 'completed'`),
    while `summary.in_progress` (and the `in_progress` list) drops to 0 when all files are indexed.
    """
    if not isinstance(payload, dict):
        return False
    summary, items = _extract_rag_ingest_summary_and_items(payload)
    in_prog_count = summary.get("in_progress")
    if isinstance(in_prog_count, int) and in_prog_count > 0:
        return True
    if any(it.get("status") in ("in_progress", "running", "processing") for it in items):
        return True

    status_vals = []
    for cand in (payload, payload.get("details") if isinstance(payload.get("details"), dict) else None):
        if isinstance(cand, dict) and cand.get("status"):
            status_vals.append(str(cand.get("status")).strip().lower())
    for st in status_vals:
        if st in ("completed", "done", "success", "succeeded", "partial_success", "failed", "error"):
            return False
    for st in status_vals:
        if st in ("in_progress", "queued", "running", "processing", "accepted", "pending"):
            return True
    return False


def _build_uploaded_doc_record(
    filename: str,
    content: bytes,
    doc_type: str,
    doc_id: Optional[Any] = None,
    rag_sections: Optional[List[Dict[str, Any]]] = None,
    *,
    original_file_name: Optional[str] = None,
    ingest_status: Optional[str] = None,
    rag_meta: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build upload summary strictly from real API Gateway / RAG response data."""
    meta = rag_meta if isinstance(rag_meta, dict) else {}
    title = str(meta.get("document_title") or meta.get("document_name") or Path(filename).stem).strip()
    if filename.lower().endswith(".json") and not meta.get("document_title"):
        try:
            parsed = json.loads(content.decode("utf-8"))
            if isinstance(parsed, dict):
                title = str(parsed.get("document_title") or parsed.get("title") or title)
        except Exception:
            pass

    sections = list(rag_sections or [])
    return {
        "document_id": doc_id,
        "document_title": title,
        "document_name": title,
        "document_type": doc_type,
        "file_name": filename,
        "original_file_name": original_file_name or filename,
        "ingest_status": ingest_status or "indexed",
        "storage_uri": str(meta.get("storage_uri") or meta.get("gs_uri") or ""),
        "document_relevance_verdict": meta.get("document_relevance_verdict"),
        "document_relevance_score": meta.get("document_relevance_score"),
        "rationale": meta.get("rationale") or meta.get("summary") or "",
        "status": "active",
        "excluded": False,
        "sections": sections,
    }


async def _ingest_uploads_via_gateway_multipart(
    plan_number: str,
    explicit_doc_type: str,
    raw_uploads: List[Tuple[str, str, bytes, str, str]],
    scope: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Execute the complete document ingestion workflow solely through API Gateway:
      1. POST /api/v1/actions/upload  (action=QNA_INGEST_DOCUMENTS, multipart `files` + `payload.file_types`)
      2. POST /api/v1/actions         (action=QNA_GET_INGEST_JOB_STATUS, polled until all files finish)
      3. POST /api/v1/actions         (action=QNA_GET_RELEVANT_DATA, persist_to_context=True)
    """
    if not raw_uploads:
        raise HTTPException(status_code=400, detail="At least one file is required.")

    scope_fields = {
        key: str(value).strip()
        for key, value in (scope or {}).items()
        if key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage", "user")
        and value not in (None, "")
        and str(value).strip()
    }
    user_details = _normalize_user_details(scope_fields)
    explicit_lower = str(explicit_doc_type or "auto").strip().lower()
    distinct_types = list(dict.fromkeys(dtype for _, _, _, _, dtype in raw_uploads))
    if explicit_lower in _RAG_FIELD_MAP:
        default_doc_type = explicit_lower
    elif len(distinct_types) == 1:
        default_doc_type = distinct_types[0]
    else:
        default_doc_type = raw_uploads[0][4]

    file_types_map: Dict[str, str] = {
        sent_fname: dtype for _, sent_fname, _, _, dtype in raw_uploads
    }
    multipart_files = [
        ("files", (sent_fname, content, ctype))
        for _, sent_fname, content, ctype, _ in raw_uploads
    ]
    upload_payload: Dict[str, Any] = {
        "document_type": default_doc_type,
        "file_types": json.dumps(file_types_map),
        **scope_fields,
    }

    # Stage 1: Submit multipart upload to API Gateway (with automatic transient retry)
    ingest_result = await _call_gateway_upload_action(
        "QNA_INGEST_DOCUMENTS",
        plan_number,
        upload_payload,
        multipart_files,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )

    job_id = _extract_rag_job_id(ingest_result)
    document_ids = _extract_rag_doc_ids(ingest_result)
    last_job_data: Any = ingest_result
    last_job_status = str(ingest_result.get("status") or "").strip().lower()
    poll_count = 0
    poll_transient_errors = 0
    consecutive_poll_errors = 0

    # Stage 2: Poll job status via API Gateway until terminal status (surviving transient blips)
    if job_id and (_is_ingest_job_in_progress(ingest_result) or not document_ids):
        deadline = time.monotonic() + max(RAG_INGEST_POLL_TIMEOUT_SECONDS, 1.0)
        poll_interval = max(RAG_INGEST_POLL_INTERVAL_SECONDS, 0.05)
        while True:
            poll_count += 1
            try:
                job_result = await _call_gateway_action(
                    "QNA_GET_INGEST_JOB_STATUS",
                    plan_number,
                    {"job_id": job_id},
                    timeout=REQUEST_TIMEOUT_SECONDS,
                )
            except HTTPException as poll_exc:
                detail_obj = poll_exc.detail if isinstance(poll_exc.detail, dict) else {}
                up_status = detail_obj.get("upstream_status")
                is_transient = _is_transient_status(poll_exc.status_code) or _is_transient_status(up_status)
                if is_transient and time.monotonic() < deadline and consecutive_poll_errors < POLL_MAX_CONSECUTIVE_ERRORS:
                    poll_transient_errors += 1
                    consecutive_poll_errors += 1
                    logger.warning(
                        "Transient poll error #%d (consecutive %d/%d) for job %s (status=%s); retrying after %.1fs",
                        poll_transient_errors,
                        consecutive_poll_errors,
                        POLL_MAX_CONSECUTIVE_ERRORS,
                        job_id,
                        up_status or poll_exc.status_code,
                        poll_interval,
                    )
                    await asyncio.sleep(poll_interval)
                    continue
                raise

            consecutive_poll_errors = 0
            last_job_data = job_result
            polled_ids = _extract_rag_doc_ids(job_result)
            if polled_ids:
                document_ids = polled_ids
            last_job_status = str(job_result.get("status") or "").strip().lower()
            if last_job_status in ("failed", "error"):
                _raise_upstream_http_error(
                    502,
                    operation="gateway_qna_get_ingest_job_status",
                    url=f"{GATEWAY_BASE}/api/v1/actions",
                    message=f"Ingest job '{job_id}' failed: {job_result.get('error') or job_result.get('message') or last_job_status}",
                    upstream_body=job_result,
                    extra={"job_id": job_id, "plan_number": plan_number, "poll_count": poll_count},
                )
            still_running = _is_ingest_job_in_progress(job_result)
            is_terminal = last_job_status in ("completed", "done", "success", "succeeded", "partial_success")
            if is_terminal and not still_running:
                break
            if not still_running and document_ids and len(document_ids) >= len(raw_uploads):
                break
            if time.monotonic() >= deadline:
                _raise_upstream_http_error(
                    504,
                    operation="gateway_qna_get_ingest_job_status",
                    url=f"{GATEWAY_BASE}/api/v1/actions",
                    message=(
                        f"Ingest job '{job_id}' did not complete within "
                        f"{int(RAG_INGEST_POLL_TIMEOUT_SECONDS)}s (last status: '{last_job_status or 'unknown'}', polls={poll_count})."
                    ),
                    upstream_body={"ingest_response": ingest_result, "last_job_response": last_job_data},
                    extra={"job_id": job_id, "plan_number": plan_number, "status": last_job_status, "poll_count": poll_count},
                )
            await asyncio.sleep(poll_interval)

    rag_summary, rag_file_outcomes = _extract_rag_ingest_summary_and_items(last_job_data)
    if not rag_summary and isinstance(ingest_result, dict):
        rag_summary, extra_items = _extract_rag_ingest_summary_and_items(ingest_result)
        if not rag_file_outcomes:
            rag_file_outcomes = extra_items

    if not document_ids:
        _raise_upstream_http_error(
            502,
            operation="gateway_qna_get_ingest_job_status" if job_id else "gateway_qna_ingest_documents",
            url=f"{GATEWAY_BASE}/api/v1/actions" if job_id else f"{GATEWAY_BASE}/api/v1/actions/upload",
            message=(
                f"API Gateway ingest returned no document_ids "
                f"(job_id='{job_id or 'none'}', status='{last_job_status or 'unknown'}'). "
                f"Check API Terminal or Error Details for the full upstream payload."
            ),
            upstream_body={"ingest_response": ingest_result, "last_job_response": last_job_data},
            extra={"plan_number": plan_number, "job_id": job_id, "rag_summary": rag_summary},
        )

    # Resolve per-document type and upload mapping from RAG job outcomes + sent file_types (no categorize endpoint)
    outcome_by_id: Dict[int, Dict[str, Any]] = {}
    outcome_by_fname: Dict[str, Dict[str, Any]] = {}
    for item in rag_file_outcomes:
        raw_did = item.get("document_id")
        if raw_did is not None and str(raw_did).strip().lstrip("-").isdigit():
            outcome_by_id[int(str(raw_did).strip())] = item
        if item.get("filename"):
            outcome_by_fname[str(item["filename"])] = item

    grouped_ids: Dict[str, List[int]] = {}
    id_type_map: Dict[int, str] = {}
    upload_id_map: Dict[int, int] = {}

    # First match uploads to document_ids by filename where available
    assigned_doc_ids: Set[int] = set()
    for idx, upload in enumerate(raw_uploads):
        _, sent_fname, _, _, init_type = upload
        matched = outcome_by_fname.get(sent_fname)
        if matched and matched.get("document_id") is not None and str(matched["document_id"]).strip().lstrip("-").isdigit():
            did = int(str(matched["document_id"]).strip())
            upload_id_map[idx] = did
            assigned_doc_ids.add(did)
            raw_t = matched.get("document_type")
            norm_t = _normalize_doc_type(raw_t) if raw_t else init_type
            id_type_map[did] = norm_t if norm_t in _RAG_FIELD_MAP else init_type

    # Fill any remaining uploads positionally from unassigned document_ids
    remaining_ids = [did for did in document_ids if did not in assigned_doc_ids]
    rem_iter = iter(remaining_ids)
    for idx, upload in enumerate(raw_uploads):
        if idx in upload_id_map:
            continue
        did = next(rem_iter, None)
        if did is not None:
            upload_id_map[idx] = did
            assigned_doc_ids.add(did)
            _, sent_fname, _, _, init_type = upload
            matched = outcome_by_id.get(did)
            raw_t = matched.get("document_type") if matched else None
            norm_t = _normalize_doc_type(raw_t) if raw_t else init_type
            id_type_map[did] = norm_t if norm_t in _RAG_FIELD_MAP else init_type

    for did in document_ids:
        if did not in id_type_map:
            matched = outcome_by_id.get(did)
            fname = matched.get("filename") if matched else None
            raw_t = (matched.get("document_type") if matched else None) or (file_types_map.get(fname) if fname else None) or default_doc_type
            norm_t = _normalize_doc_type(raw_t)
            id_type_map[did] = norm_t if norm_t in _RAG_FIELD_MAP else default_doc_type
        grouped_ids.setdefault(id_type_map[did], []).append(did)

    # Stage 3: Retrieve relevant sections and persist to plan context through API Gateway
    relevant_result = await _call_gateway_action(
        "QNA_GET_RELEVANT_DATA",
        plan_number,
        {
            "review_id": str(plan_number),
            "documents": [
                {"document_type": doc_type, "document_ids": ids, "top_k": 5}
                for doc_type, ids in grouped_ids.items()
            ],
            "persist_to_context": True,
            "user_details": user_details,
        },
        timeout=REQUEST_TIMEOUT_SECONDS,
    )

    # Surface any embedded RAG error returned inside HTTP 200 payload
    raw_results = relevant_result.get("results") if isinstance(relevant_result, dict) else None
    if isinstance(raw_results, dict) and raw_results.get("error"):
        _raise_upstream_http_error(
            502,
            operation="gateway_qna_get_relevant_data",
            url=f"{GATEWAY_BASE}/api/v1/actions",
            message=f"RAG relevant-data returned error: {raw_results.get('error')}",
            upstream_body=relevant_result,
            extra={"plan_number": plan_number, "document_ids": document_ids},
        )
    if isinstance(raw_results, list):
        scope_errors = [
            f"{item.get('document_type', 'unknown')}: {item.get('error')}"
            for item in raw_results
            if isinstance(item, dict) and item.get("status") == "error" and item.get("error")
        ]
        if scope_errors and not any(
            isinstance(item, dict) and item.get("documents") for item in raw_results
        ):
            _raise_upstream_http_error(
                502,
                operation="gateway_qna_get_relevant_data",
                url=f"{GATEWAY_BASE}/api/v1/actions",
                message=f"RAG relevant-data failed: {'; '.join(scope_errors)}",
                upstream_body=relevant_result,
                extra={"plan_number": plan_number, "document_ids": document_ids},
            )

    registry_updated = bool(isinstance(relevant_result, dict) and relevant_result.get("registry_updated"))
    persisted_files = (
        list(relevant_result.get("persisted_files") or [])
        if isinstance(relevant_result, dict) and isinstance(relevant_result.get("persisted_files"), list)
        else []
    )
    sections_by_key = _extract_sections_from_rag_relevant_data(relevant_result)
    doc_meta_by_id = _extract_rag_doc_metadata(relevant_result)

    documents: List[Dict[str, Any]] = []
    categorized_summary: Dict[str, List[str]] = {}
    for idx, upload in enumerate(raw_uploads):
        orig_fname, sent_fname, content, _, initial_type = upload
        doc_id = upload_id_map.get(idx)
        final_type = id_type_map.get(doc_id, initial_type) if doc_id is not None else initial_type
        sections = sections_by_key.get(str(doc_id)) if doc_id is not None else None
        if sections is None:
            sections = sections_by_key.get(final_type, []) if len(raw_uploads) == 1 else []
        outcome = (outcome_by_id.get(doc_id) if doc_id is not None else None) or outcome_by_fname.get(sent_fname) or {}
        rag_meta = doc_meta_by_id.get(str(doc_id)) if doc_id is not None else None
        record = _build_uploaded_doc_record(
            sent_fname,
            content,
            final_type,
            doc_id,
            sections,
            original_file_name=orig_fname,
            ingest_status=str(outcome.get("status") or "indexed"),
            rag_meta=rag_meta,
        )
        documents.append(record)
        categorized_summary.setdefault(final_type, []).append(record["document_title"])

    # Detect if upstream tagged any file with a different document_type than requested in file_types
    type_mismatch_warnings: List[str] = []
    for item in rag_file_outcomes:
        fname = str(item.get("filename") or "")
        expected_t = file_types_map.get(fname)
        actual_t = _normalize_doc_type(item.get("document_type")) if item.get("document_type") else None
        if expected_t and actual_t and actual_t != expected_t:
            type_mismatch_warnings.append(
                f"Sent '{fname}' as '{expected_t}' in payload.file_types, but upstream tagged it as '{actual_t}'."
            )

    primary_type = documents[0]["document_type"] if documents else default_doc_type
    total_sections = sum(len(item.get("sections") or []) for item in documents)
    extra_note = ""
    if total_sections == 0:
        extra_note = (
            " (RAG returned 0 sections passing relevance threshold >= 0.5 / non-LOW verdict for this plan.)"
        )
    return {
        "status": "ingested",
        "rag_mode": "api_gateway_multipart",
        "gateway_endpoint": f"{GATEWAY_BASE}/api/v1/actions/upload",
        "job_id": job_id or None,
        "job_status": last_job_status or "completed",
        "poll_count": poll_count,
        "poll_retries": poll_transient_errors,
        "plan_number": plan_number,
        "document_type": primary_type,
        "file_types_sent": file_types_map,
        "type_mismatch_warnings": type_mismatch_warnings,
        "stored_in_artifact": "policy",
        "document_ids": document_ids,
        "rag_summary": rag_summary,
        "rag_file_outcomes": rag_file_outcomes,
        "categorized": categorized_summary,
        "registry_updated": registry_updated,
        "persisted_files": persisted_files,
        "files_uploaded": [item["file_name"] for item in documents],
        "documents": [
            {
                "document_id": item["document_id"],
                "document_title": item["document_title"],
                "document_type": item["document_type"],
                "file_name": item["file_name"],
                "original_file_name": item["original_file_name"],
                "ingest_status": item["ingest_status"],
                "storage_uri": item["storage_uri"],
                "document_relevance_verdict": item["document_relevance_verdict"],
                "document_relevance_score": item["document_relevance_score"],
                "rationale": item["rationale"],
                "section_count": len(item.get("sections") or []),
                "sections": item.get("sections") or [],
            }
            for item in documents
        ],
        "message": (
            f"Ingested {len(documents)} file(s) via API Gateway ({', '.join(f'{k}={len(v)}' for k, v in categorized_summary.items())}) "
            f"with {total_sections} relevant section(s). document_ids={document_ids}.{extra_note}"
        ),
    }


def _stamp_pdf_for_fresh_ingest(filename: str, content: bytes) -> Tuple[str, bytes]:
    """Give a PDF a unique SHA-256 checksum & GCS filename so RAG always performs a fresh ingest."""
    if not filename.lower().endswith(".pdf") or not content.startswith(b"%PDF-"):
        return filename, content
    tag = uuid.uuid4().hex[:8]
    stamped_content = content + f"\n% ct1-demo-fresh-ingest: {tag}\n".encode("ascii")
    stem = filename[:-4]
    stamped_name = f"{stem}_{tag}.pdf"
    return stamped_name, stamped_content


def _deduplicate_filename(filename: str, seen: Set[str]) -> str:
    """Ensure uploaded filenames are unique so Query Service `_apply_file_types` never hits duplicate ambiguity."""
    if filename not in seen:
        seen.add(filename)
        return filename
    path = Path(filename)
    stem, suffix = path.stem, path.suffix
    idx = 2
    while True:
        candidate = f"{stem}_{idx}{suffix}"
        if candidate not in seen:
            seen.add(candidate)
            return candidate
        idx += 1


async def _handle_upload_ingest(
    plan_number: str,
    document_type: str,
    files: List[UploadFile],
    policy_files: List[UploadFile],
    kod_files: List[UploadFile],
    procedure_files: List[UploadFile],
    scope: Optional[Dict[str, Any]] = None,
    *,
    file_types_raw: Optional[str] = None,
    file_types_list_raw: Optional[str] = None,
    force_fresh_ingest: bool = False,
) -> Dict[str, Any]:
    parsed_file_types: Dict[str, str] = {}
    if file_types_raw:
        try:
            loaded = json.loads(file_types_raw)
            if isinstance(loaded, dict):
                parsed_file_types = {str(k): str(v).strip().lower() for k, v in loaded.items() if str(v).strip()}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Invalid file_types JSON: {exc}") from exc

    parsed_file_types_list: List[str] = []
    if file_types_list_raw:
        try:
            loaded_list = json.loads(file_types_list_raw)
            if isinstance(loaded_list, list):
                parsed_file_types_list = [str(v).strip().lower() for v in loaded_list]
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Invalid file_types_list JSON: {exc}") from exc

    raw_uploads: List[Tuple[str, str, bytes, str, str]] = []
    seen_names: Set[str] = set()

    for typed_group, upload_list in (
        ("policy", policy_files),
        ("kod", kod_files),
        ("procedure", procedure_files),
    ):
        for upload in upload_list:
            content = await upload.read()
            orig_fname = upload.filename or f"{typed_group}.pdf"
            sent_fname = orig_fname
            ctype = upload.content_type or "application/pdf"
            if force_fresh_ingest:
                sent_fname, content = _stamp_pdf_for_fresh_ingest(sent_fname, content)
            sent_fname = _deduplicate_filename(sent_fname, seen_names)
            raw_uploads.append((orig_fname, sent_fname, content, ctype, typed_group))

    for idx, upload in enumerate(files):
        content = await upload.read()
        orig_fname = upload.filename or "document.pdf"
        sent_fname = orig_fname
        ctype = upload.content_type or "application/pdf"
        explicit_for_file = (
            parsed_file_types_list[idx]
            if idx < len(parsed_file_types_list) and parsed_file_types_list[idx]
            else parsed_file_types.get(orig_fname)
            or parsed_file_types.get(Path(orig_fname).name)
            or document_type
        )
        resolved_type = _infer_doc_type_from_filename(orig_fname, explicit_for_file)
        if force_fresh_ingest:
            sent_fname, content = _stamp_pdf_for_fresh_ingest(sent_fname, content)
        sent_fname = _deduplicate_filename(sent_fname, seen_names)
        raw_uploads.append((orig_fname, sent_fname, content, ctype, resolved_type))

    if not raw_uploads:
        raise HTTPException(status_code=400, detail="At least one file is required.")

    return await _ingest_uploads_via_gateway_multipart(plan_number, document_type, raw_uploads, scope)


@app.post("/api/ct1/query/ingest")
async def proxy_query_ingest(
    plan_number: str = Form(DEFAULT_PLAN_NUMBER),
    document_type: str = Form("auto"),
    file_types: Optional[str] = Form(None),
    file_types_list: Optional[str] = Form(None),
    force_fresh_ingest: bool = Form(True),
    review_scope_id: Optional[str] = Form(None),
    process_instance_id: Optional[str] = Form(None),
    task_id: Optional[str] = Form(None),
    review_scope_stage: Optional[str] = Form(None),
    user: Optional[str] = Form(None),
    files: List[UploadFile] = File(default=[]),
    policy_files: List[UploadFile] = File(default=[]),
    kod_files: List[UploadFile] = File(default=[]),
    procedure_files: List[UploadFile] = File(default=[]),
) -> Dict[str, Any]:
    """Ingest one or more documents (with optional per-file `file_types`) solely through API Gateway."""
    scope = {
        "review_scope_id": review_scope_id,
        "process_instance_id": process_instance_id,
        "task_id": task_id,
        "review_scope_stage": review_scope_stage,
        "user": user,
    }
    return await _handle_upload_ingest(
        plan_number,
        document_type,
        files,
        policy_files,
        kod_files,
        procedure_files,
        scope,
        file_types_raw=file_types,
        file_types_list_raw=file_types_list,
        force_fresh_ingest=force_fresh_ingest,
    )


@app.post("/api/ct1/rag/ingest-documents")
async def proxy_rag_ingest_documents(
    plan_number: str = Form(DEFAULT_PLAN_NUMBER),
    document_type: str = Form("auto"),
    file_types: Optional[str] = Form(None),
    file_types_list: Optional[str] = Form(None),
    force_fresh_ingest: bool = Form(True),
    review_scope_id: Optional[str] = Form(None),
    process_instance_id: Optional[str] = Form(None),
    task_id: Optional[str] = Form(None),
    review_scope_stage: Optional[str] = Form(None),
    user: Optional[str] = Form(None),
    files: List[UploadFile] = File(default=[]),
    policy_files: List[UploadFile] = File(default=[]),
    kod_files: List[UploadFile] = File(default=[]),
    procedure_files: List[UploadFile] = File(default=[]),
) -> Dict[str, Any]:
    """Alias route for multipart document ingestion through API Gateway (`QNA_INGEST_DOCUMENTS`)."""
    scope = {
        "review_scope_id": review_scope_id,
        "process_instance_id": process_instance_id,
        "task_id": task_id,
        "review_scope_stage": review_scope_stage,
        "user": user,
    }
    return await _handle_upload_ingest(
        plan_number,
        document_type,
        files,
        policy_files,
        kod_files,
        procedure_files,
        scope,
        file_types_raw=file_types,
        file_types_list_raw=file_types_list,
        force_fresh_ingest=force_fresh_ingest,
    )


@app.get("/api/ct1/rag/ingest-jobs/{job_id}")
async def proxy_rag_job_status(
    job_id: str,
    plan_number: str = Query(default=DEFAULT_PLAN_NUMBER),
) -> Dict[str, Any]:
    """Check RAG ingestion job status through API Gateway action `QNA_GET_INGEST_JOB_STATUS`."""
    data = await _call_gateway_action(
        "QNA_GET_INGEST_JOB_STATUS",
        str(plan_number or DEFAULT_PLAN_NUMBER).strip(),
        {"job_id": job_id},
    )
    if isinstance(data, dict):
        data.setdefault("job_id", job_id)
    return data


@app.post("/api/ct1/rag/get-relevant-data-for-documents")
async def proxy_rag_relevant_data(payload: RagRelevantDataRequest) -> Dict[str, Any]:
    """Fetch relevant sections through API Gateway action `QNA_GET_RELEVANT_DATA`."""
    plan_num = str(payload.review_id or payload.plan_number or DEFAULT_PLAN_NUMBER).strip()
    overrides = payload.model_dump(exclude={"plan_number", "documents"}, exclude_none=True)
    body: Dict[str, Any] = {
        "review_id": plan_num,
        "documents": payload.documents,
        "persist_to_context": True,
        "user_details": _normalize_user_details({}),
        **overrides,
    }
    return await _call_gateway_action("QNA_GET_RELEVANT_DATA", plan_num, body)


@app.get("/api/ct1/preliminary-research/health")
async def proxy_pr_health() -> Dict[str, Any]:
    """Check health of CT1 API Gateway (`/openapi.json`)."""
    url = f"{GATEWAY_BASE}/openapi.json"
    try:
        resp = await _call_gateway_get("openapi.json", operation="gateway_health")
    except Exception as exc:
        _raise_upstream_http_error(
            502,
            operation="gateway_health",
            url=url,
            message=f"API Gateway unreachable ({type(exc).__name__}): {exc}",
        )
    if resp.status_code >= 400:
        _raise_upstream_http_error(
            resp.status_code,
            operation="gateway_health",
            url=url,
            message=f"API Gateway returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
            upstream_status=resp.status_code,
            upstream_body=_extract_error_payload(resp),
        )
    try:
        upstream = resp.json()
    except Exception:
        upstream = resp.text[:1000]
    return {"status": "ok", "gateway_base": GATEWAY_BASE, "upstream": upstream}


async def _handle_get_preliminary_research(plan_number: str) -> Dict[str, Any]:
    plan_num = str(plan_number or "").strip() or DEFAULT_PLAN_NUMBER
    used_url = f"{GATEWAY_BASE}/api/v1/actions"
    try:
        raw = await _call_gateway_action(
            "GET_PRELIMINARY_RESEARCH_DOCUMENT", plan_num, {}
        )
    except HTTPException as exc:
        if exc.status_code == 404:
            return {
                "available": False,
                "status_code": 404,
                "plan_number": plan_num,
                "analysis_report": None,
                "source": "master_agent_gateway",
                "message": "Preliminary Research document has not been generated for this plan yet.",
            }
        raise

    unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
    if not unwrapped:
        _raise_upstream_http_error(
            502,
            operation="pr_get",
            url=used_url,
            message="Preliminary Research response did not include analysis_report.",
            upstream_status=200,
            upstream_body=raw,
        )
    return {
        "available": True,
        "status_code": 200,
        "plan_number": unwrapped["plan_number"],
        "analysis_report": unwrapped["analysis_report"],
        "source": "master_agent_gateway",
    }


@app.get("/api/ct1/preliminary-research/{plan_number}")
async def proxy_get_preliminary_research_get(plan_number: str) -> Dict[str, Any]:
    """Fetch stored Preliminary Research document from CT1 scoping-summary-agent."""
    return await _handle_get_preliminary_research(plan_number)


@app.post("/api/ct1/preliminary-research/get")
async def proxy_get_preliminary_research_post(payload: PreliminaryResearchGetRequest) -> Dict[str, Any]:
    """Fetch stored Preliminary Research document from CT1 scoping-summary-agent."""
    return await _handle_get_preliminary_research(payload.planNumber)


def _pr_report_has_content(analysis_report: Any) -> bool:
    if not isinstance(analysis_report, dict) or not analysis_report:
        return False
    for sec in analysis_report.values():
        if not isinstance(sec, dict):
            continue
        if isinstance(sec.get("paragraphs"), list) and sec["paragraphs"]:
            return True
        if isinstance(sec.get("historical_reviews"), list) and sec["historical_reviews"]:
            return True
    return False


async def _poll_preliminary_research_after_proxy_drop(
    *,
    plan_num: str,
    started: float,
    initial_exc: HTTPException,
) -> Tuple[Any, str]:
    """
    Poll the master-agent document action until the background generation job writes
    the report or PRELIMINARY_RESEARCH_TIMEOUT_SECONDS elapses.
    """
    deadline = started + PRELIMINARY_RESEARCH_TIMEOUT_SECONDS
    while time.perf_counter() < deadline:
        try:
            raw = await _call_gateway_action(
                "GET_PRELIMINARY_RESEARCH_DOCUMENT", plan_num, {}
            )
            unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
            if unwrapped and _pr_report_has_content(unwrapped.get("analysis_report")):
                return raw, f"{GATEWAY_BASE}/api/v1/actions"
        except HTTPException:
            pass
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            break
        await asyncio.sleep(min(PR_POLL_INTERVAL_SECONDS, remaining))
    raise initial_exc


@app.post("/api/ct1/preliminary-research/generate")
async def proxy_generate_preliminary_research(payload: PreliminaryResearchGenerateRequest) -> Dict[str, Any]:
    """Trigger Preliminary Research generation through the API Gateway master agent."""
    started = time.perf_counter()
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    cleaned_sections: Optional[List[str]] = None
    if payload.sections is not None:
        cleaned_sections = [str(s).strip() for s in payload.sections if str(s).strip()]
        invalid = [s for s in cleaned_sections if s not in _VALID_PR_SECTION_KEYS]
        if invalid:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid preliminary research section(s): {invalid}. Valid keys: {sorted(_VALID_PR_SECTION_KEYS)}",
            )
        if not cleaned_sections:
            cleaned_sections = None

    summary_user = _normalize_summary_user_details(payload.userDetails)
    gateway_payload: Dict[str, Any] = {"userDetails": summary_user}
    if cleaned_sections:
        gateway_payload["sections"] = cleaned_sections

    try:
        raw = await _call_gateway_action(
            "RUN_ANALYTICS",
            plan_num,
            gateway_payload,
            timeout=PRELIMINARY_RESEARCH_TIMEOUT_SECONDS,
        )
        used_url = f"{GATEWAY_BASE}/api/v1/actions"
    except HTTPException as exc:
        elapsed = time.perf_counter() - started
        detail_obj = exc.detail if isinstance(exc.detail, dict) else {}
        upstream_st = detail_obj.get("upstream_status")
        is_long_proxy_drop = elapsed >= PR_PROXY_DROP_RETRY_AFTER_SECONDS and (
            exc.status_code in (502, 504) or upstream_st in (502, 504)
        )
        if not is_long_proxy_drop:
            raise
        logger.warning(
            "RUN_ANALYTICS action dropped after %.1fs (status=%s); polling gateway document action for plan %s",
            elapsed,
            upstream_st or exc.status_code,
            plan_num,
        )
        raw, used_url = await _poll_preliminary_research_after_proxy_drop(
            plan_num=plan_num,
            started=started,
            initial_exc=exc,
        )

    unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
    if not unwrapped or not _pr_report_has_content(unwrapped.get("analysis_report")):
        raw, used_url = await _poll_preliminary_research_after_proxy_drop(
            plan_num=plan_num,
            started=started,
            initial_exc=HTTPException(
                status_code=504,
                detail={
                    "error": "Preliminary Research generation did not return a completed report before the timeout.",
                    "operation": "gateway_run_analytics",
                    "upstream_url": f"{GATEWAY_BASE}/api/v1/actions",
                    "upstream_status": 504,
                    "upstream_body": raw,
                },
            ),
        )
        unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
    if not unwrapped:
        _raise_upstream_http_error(
            502,
            operation="pr_generate",
            url=used_url,
            message="Preliminary Research generation response missing analysis_report.",
            upstream_status=200,
            upstream_body=raw,
        )

    return {
        "available": True,
        "plan_number": unwrapped["plan_number"],
        "analysis_report": unwrapped["analysis_report"],
        "sections_requested": cleaned_sections or [item["key"] for item in PR_SECTIONS],
        "source": "master_agent_gateway",
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
    }


@app.post("/api/ct1/preliminary-research/edit")
async def proxy_edit_preliminary_research(payload: PreliminaryResearchEditRequest) -> Dict[str, Any]:
    """Persist edited Preliminary Research sections via API Gateway action `EDIT_PRELIMINARY_RESEARCH_DOCUMENT`."""
    started = time.perf_counter()
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    summary_user = _normalize_summary_user_details(payload.userDetails)
    used_url = f"{GATEWAY_BASE}/api/v1/actions"
    raw = await _call_gateway_action(
        "EDIT_PRELIMINARY_RESEARCH_DOCUMENT",
        plan_num,
        {
            "userDetails": summary_user,
            "analysis_report": payload.analysis_report,
        },
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
    if not unwrapped:
        _raise_upstream_http_error(
            502,
            operation="pr_edit",
            url=used_url,
            message="Preliminary Research edit response missing analysis_report.",
            upstream_status=200,
            upstream_body=raw,
        )
    return {
        "plan_number": unwrapped["plan_number"],
        "analysis_report": unwrapped["analysis_report"],
        "source": "api_gateway",
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
    }


@app.post("/api/ct1/preliminary-research/document")
async def proxy_pr_get_document(payload: PreliminaryResearchDocumentRequest) -> Dict[str, Any]:
    """Fetch a cited PDF/JSON document through API Gateway action `GET_CITATION_DOCUMENT`."""
    chunk_id = (payload.chunk_id or "").strip() or None
    doc_uri = (payload.document_uri or "").strip() or None
    if not chunk_id and not doc_uri:
        raise HTTPException(status_code=400, detail="Either chunk_id or document_uri is required.")
    if chunk_id and not doc_uri and not (payload.planNumber or "").strip():
        raise HTTPException(status_code=400, detail="planNumber is required when fetching by chunk_id.")

    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    gw_payload: Dict[str, Any] = {}
    if chunk_id:
        gw_payload["chunk_id"] = chunk_id
    if doc_uri:
        gw_payload["document_uri"] = doc_uri
    if payload.page_number is not None and payload.page_number >= 1:
        gw_payload["pageNumber"] = int(payload.page_number)

    raw = await _call_gateway_action(
        "GET_CITATION_DOCUMENT",
        plan_num,
        gw_payload,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    if isinstance(raw, dict):
        result = dict(raw)
        result.setdefault("source_service", "api_gateway")
        return result
    return {"content": raw, "source_service": "api_gateway"}


@app.post("/api/ct1/preliminary-research/download")
async def proxy_download_preliminary_research(payload: PreliminaryResearchDownloadRequest) -> Response:
    """Download the Preliminary Research Walkthrough PDF through API Gateway `/api/v1/actions/download`."""
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    gw_payload: Dict[str, Any] = {}
    if payload.planName:
        gw_payload["planName"] = payload.planName
    if payload.userDetails:
        gw_payload["userDetails"] = _normalize_summary_user_details(payload.userDetails)

    url = f"{GATEWAY_BASE}/api/v1/actions/download"
    resp = await _call_gateway_download_action(
        "DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT",
        plan_num,
        gw_payload,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )

    if resp.status_code == 200:
        disposition = (
            resp.headers.get("content-disposition")
            if hasattr(resp, "headers") and resp.headers
            else None
        ) or f'attachment; filename="Preliminary_Research_Report_{plan_num}.pdf"'
        pdf_bytes = getattr(resp, "content", None)
        if pdf_bytes is None:
            raw_text = getattr(resp, "text", "") or ""
            pdf_bytes = raw_text.encode("latin-1", errors="ignore")
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": disposition},
        )

    _raise_upstream_http_error(
        resp.status_code,
        operation="pr_download",
        url=url,
        message=f"API Gateway download returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
        upstream_status=resp.status_code,
        upstream_body=_extract_error_payload(resp),
    )


@app.post("/api/ct1/preliminary-research/accept")
async def proxy_accept_preliminary_research(payload: PreliminaryResearchAcceptRequest) -> Dict[str, Any]:
    """Accept Preliminary Research via CT1 API Gateway action `ACCEPT_PRELIMINARY_RESEARCH`."""
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    summary_user = _normalize_summary_user_details(payload.userDetails)
    gw_payload: Dict[str, Any] = {}
    if summary_user:
        gw_payload["user_details"] = summary_user
    data = await _call_gateway_action(
        "ACCEPT_PRELIMINARY_RESEARCH",
        plan_num,
        gw_payload,
        timeout=REQUEST_TIMEOUT_SECONDS,
        unwrap_response=False,
    )
    return {"status": "accepted", "plan_number": plan_num, "response": data}


@app.get("/")
async def index() -> FileResponse:
    """Serve the demo UI single-page app."""
    return FileResponse(STATIC_DIR / "index.html")


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8095"))
    uvicorn.run(app, host="0.0.0.0", port=port)
