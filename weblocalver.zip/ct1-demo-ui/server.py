"""
CT1 Live Include/Exclude & Data Extraction Demo Server.

Thin FastAPI CORS + TLS pass-through proxy over live CT1 endpoints:
  - Query Service: /query-service/qna/{chat, documents/list-all, documents/ingest}
  - Data Extraction Agent: /scoping-dataextraction-agent/{getdata/*, data-extraction*}

All plan catalog data, workflow proposals, approvals, and downstream Data Extraction
artifact payloads come directly from CT1 without local mock state or fake filtering.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ct1-demo-ui")

CTA_HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com").rstrip("/")
DEFAULT_PLAN_NUMBER = os.getenv("DEFAULT_PLAN_NUMBER", "20440")
REQUEST_TIMEOUT_SECONDS = float(os.getenv("CT1_TIMEOUT_SECONDS", "120.0"))
STATIC_DIR = Path(__file__).resolve().parent / "static"

PLAN_ARTIFACTS: List[Dict[str, str]] = [
    {"id": "policy", "label": "Policies / KOD / Proc", "excludable": "true"},
    {"id": "findings_details", "label": "GFMS Findings", "excludable": "true"},
    {"id": "historical_plan_details", "label": "Historical Plans", "excludable": "true"},
    {"id": "lrr", "label": "LRR Mandates", "excludable": "true"},
    {"id": "current_details", "label": "Current Plan", "excludable": "false"},
    {"id": "alc_nlac", "label": "ALC / NALC", "excludable": "false"},
    {"id": "control_details", "label": "Controls", "excludable": "false"},
    {"id": "risk_driver_details", "label": "Risk Drivers", "excludable": "false"},
    {"id": "group_audit", "label": "Group Audit", "excludable": "false"},
]


class ChatProxyRequest(BaseModel):
    question: str
    plan_number: str
    context_type: str = "preliminary_research"
    plan_name: Optional[str] = None
    research_sections: Optional[List[Any]] = None
    userDetails: Optional[Dict[str, Any]] = None


class ExtractionRunRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


def create_async_client() -> httpx.AsyncClient:
    """Create the async HTTP client used for live CT1 calls."""
    return httpx.AsyncClient(verify=False, timeout=REQUEST_TIMEOUT_SECONDS)


app = FastAPI(title="CT1 Scoping Query & Data Extraction Demo UI", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _extract_error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            return str(payload.get("detail") or payload.get("message") or payload)
        return str(payload)
    except Exception:
        return response.text[:500] or f"HTTP {response.status_code}"


async def _forward_json(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    json_body: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    response = await client.request(method, url, json=json_body)
    if response.status_code >= 400:
        raise HTTPException(
            status_code=response.status_code,
            detail=_extract_error_detail(response),
        )
    try:
        return response.json()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Invalid JSON from CT1 ({url}): {exc}") from exc


async def _fetch_artifact_safe(
    client: httpx.AsyncClient,
    plan_number: str,
    artifact_id: str,
) -> Dict[str, Any]:
    url = f"{CTA_HOST}/scoping-dataextraction-agent/getdata/{plan_number}/{artifact_id}"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "data": resp.json()}
        return {
            "ok": False,
            "status_code": resp.status_code,
            "error": _extract_error_detail(resp),
            "data": None,
        }
    except Exception as exc:
        return {"ok": False, "status_code": 502, "error": str(exc), "data": None}


async def _fetch_catalog_safe(client: httpx.AsyncClient, plan_number: str) -> Dict[str, Any]:
    url = f"{CTA_HOST}/query-service/qna/documents/list-all"
    try:
        resp = await client.post(url, json={"plan_number": plan_number})
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "data": resp.json()}
        return {
            "ok": False,
            "status_code": resp.status_code,
            "error": _extract_error_detail(resp),
            "data": None,
        }
    except Exception as exc:
        return {"ok": False, "status_code": 502, "error": str(exc), "data": None}


async def _fetch_availability_safe(client: httpx.AsyncClient, plan_number: str) -> Dict[str, Any]:
    url = f"{CTA_HOST}/scoping-dataextraction-agent/getdata/{plan_number}/availability"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "data": resp.json()}
        return {"ok": False, "status_code": resp.status_code, "error": _extract_error_detail(resp), "data": None}
    except Exception as exc:
        return {"ok": False, "status_code": 502, "error": str(exc), "data": None}


@app.get("/api/config")
async def get_config() -> Dict[str, Any]:
    """Return CT1 host settings and artifact metadata definitions."""
    return {
        "cta_host": CTA_HOST,
        "default_plan_number": DEFAULT_PLAN_NUMBER,
        "artifacts": PLAN_ARTIFACTS,
    }


@app.get("/api/ct1/plan/{plan_number}/bootstrap")
async def bootstrap_plan(plan_number: str) -> Dict[str, Any]:
    """
    Fetch live CT1 document catalog (for @ autocomplete) alongside availability
    and all PlanArtifact payloads from scoping-dataextraction-agent.
    """
    started = time.perf_counter()
    artifact_ids = [item["id"] for item in PLAN_ARTIFACTS]
    async with create_async_client() as client:
        catalog_task = _fetch_catalog_safe(client, plan_number)
        avail_task = _fetch_availability_safe(client, plan_number)
        artifact_tasks = [_fetch_artifact_safe(client, plan_number, aid) for aid in artifact_ids]
        results = await asyncio.gather(catalog_task, avail_task, *artifact_tasks)

    catalog_res = results[0]
    avail_res = results[1]
    artifact_results = results[2:]

    artifacts: Dict[str, Any] = {}
    errors: Dict[str, str] = {}
    if not catalog_res["ok"]:
        errors["catalog"] = str(catalog_res.get("error") or "Catalog unavailable")
    if not avail_res["ok"]:
        errors["availability"] = str(avail_res.get("error") or "Availability check unavailable")

    for aid, res in zip(artifact_ids, artifact_results):
        if res["ok"]:
            artifacts[aid] = res["data"]
        else:
            errors[aid] = str(res.get("error") or f"HTTP {res.get('status_code')}")

    return {
        "plan_number": plan_number,
        "cta_host": CTA_HOST,
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
        "catalog": catalog_res.get("data"),
        "availability": avail_res.get("data"),
        "artifacts": artifacts,
        "errors": errors,
    }


@app.get("/api/ct1/dataextraction/status/{session_id}")
async def proxy_extraction_status(session_id: str) -> Dict[str, Any]:
    """Poll CT1 data extraction job status."""
    url = f"{CTA_HOST}/scoping-dataextraction-agent/data-extraction/{session_id}/status"
    async with create_async_client() as client:
        return await _forward_json(client, "GET", url)


@app.get("/api/ct1/dataextraction/{plan_number}/{artifact}")
async def proxy_get_artifact(plan_number: str, artifact: str) -> Any:
    """Live pass-through to CT1 GET /scoping-dataextraction-agent/getdata/{plan_number}/{artifact}."""
    url = f"{CTA_HOST}/scoping-dataextraction-agent/getdata/{plan_number}/{artifact}"
    async with create_async_client() as client:
        return await _forward_json(client, "GET", url)


@app.post("/api/ct1/dataextraction/run")
async def proxy_run_extraction(payload: ExtractionRunRequest) -> Dict[str, Any]:
    """Trigger a fresh CT1 data extraction run."""
    url = f"{CTA_HOST}/scoping-dataextraction-agent/data-extraction"
    body = {"planNumber": payload.planNumber, "userDetails": payload.userDetails or {"user": "demo.user@db.com"}}
    async with create_async_client() as client:
        return await _forward_json(client, "POST", url, json_body=body)


@app.post("/api/ct1/query/chat")
async def proxy_query_chat(payload: ChatProxyRequest) -> Dict[str, Any]:
    """Live pass-through to CT1 POST /query-service/qna/chat."""
    url = f"{CTA_HOST}/query-service/qna/chat"
    body: Dict[str, Any] = {
        "question": payload.question,
        "plan_number": payload.plan_number,
        "context_type": payload.context_type,
        "userDetails": payload.userDetails or {"user": "demo.user@db.com"},
    }
    if payload.plan_name:
        body["plan_name"] = payload.plan_name
    if payload.research_sections is not None:
        body["research_sections"] = payload.research_sections
    async with create_async_client() as client:
        return await _forward_json(client, "POST", url, json_body=body)


@app.post("/api/ct1/query/ingest")
async def proxy_query_ingest(
    plan_number: str = Form(...),
    document_type: str = Form("policy"),
    files: List[UploadFile] = File(...),
) -> Dict[str, Any]:
    """Live multipart pass-through to CT1 POST /query-service/qna/documents/ingest."""
    if not files:
        raise HTTPException(status_code=400, detail="At least one file is required.")

    form_files = []
    field_map = {"policy": "policy_files", "kod": "kod_files", "procedure": "procedure_files"}
    target_field = field_map.get(document_type.strip().lower(), "files")

    for upload in files:
        content = await upload.read()
        form_files.append(
            (target_field, (upload.filename or "document.pdf", content, upload.content_type or "application/pdf"))
        )

    url = f"{CTA_HOST}/query-service/qna/documents/ingest"
    async with create_async_client() as client:
        resp = await client.post(
            url,
            data={"plan_number": plan_number, "document_type": document_type},
            files=form_files,
        )
        if resp.status_code >= 400:
            raise HTTPException(status_code=resp.status_code, detail=_extract_error_detail(resp))
        return resp.json()


@app.get("/")
async def index() -> FileResponse:
    """Serve the demo UI single-page app."""
    return FileResponse(STATIC_DIR / "index.html")


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8095"))
    uvicorn.run(app, host="0.0.0.0", port=port)
