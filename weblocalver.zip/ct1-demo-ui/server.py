"""
CT1 Live Preliminary Research, Include/Exclude & Data Extraction Demo Server.

Direct FastAPI proxy over live CT1 endpoints only (zero mocks, zero local samples, zero fallbacks):
  - Data Extraction Agent: /scoping-dataextraction-agent/{getdata/*, data-extraction*}
  - Query Service: /query-service/qna/{chat, documents/list-all}
  - RAG Service: /dbaware-rag-service-api-dev/{ingest-documents, ingest-jobs/*, categorize-document-ids, get-relevant-data-for-documents}
  - Summary Agent: /scoping-summary-agent/{health, get-preliminary-research-document, run-analytics-agent, edit-preliminary-research-document, get_document, download}
  - API Gateway: /dbaware-api-gateway/api/v1/{task/status/*, actions (ACCEPT_PRELIMINARY_RESEARCH)}
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, NoReturn, Optional, Set, Tuple
from urllib.parse import urlencode

import httpx
from fastapi import FastAPI, File, Form, HTTPException, Query, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ct1-demo-ui")

CTA_HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com").rstrip("/")
DATAEXTRACTION_BASE = os.getenv(
    "DATAEXTRACTION_URL", f"{CTA_HOST}/scoping-dataextraction-agent"
).rstrip("/")
QUERY_SERVICE_BASE = os.getenv(
    "QUERY_SERVICE_URL", f"{CTA_HOST}/query-service"
).rstrip("/")
RAG_SERVICE_BASE = os.getenv(
    "RAG_SERVICE_URL", f"{CTA_HOST}/dbaware-rag-service-api-dev"
).rstrip("/")
SUMMARY_AGENT_BASE = os.getenv(
    "SUMMARY_AGENT_URL", f"{CTA_HOST}/scoping-summary-agent"
).rstrip("/")
GATEWAY_BASE = os.getenv(
    "GATEWAY_URL", f"{CTA_HOST}/dbaware-api-gateway"
).rstrip("/")
DEFAULT_PLAN_NUMBER = os.getenv("DEFAULT_PLAN_NUMBER", "20440")
REQUEST_TIMEOUT_SECONDS = float(os.getenv("CT1_TIMEOUT_SECONDS", "60.0"))
PRELIMINARY_RESEARCH_TIMEOUT_SECONDS = float(os.getenv("CT1_PR_TIMEOUT_SECONDS", "600.0"))
PR_PROXY_DROP_RETRY_AFTER_SECONDS = float(os.getenv("CT1_PR_PROXY_DROP_AFTER_SECONDS", "15.0"))
PR_POLL_INTERVAL_SECONDS = float(os.getenv("CT1_PR_POLL_INTERVAL_SECONDS", "10.0"))
TASK_STATUS_TIMEOUT_SECONDS = float(os.getenv("CT1_TASK_STATUS_TIMEOUT_SECONDS", "10.0"))
HTTPX_TRUST_ENV = os.getenv("HTTPX_TRUST_ENV", "false").strip().lower() in ("true", "1", "yes")
CT1_RC_TOKEN = os.getenv("CT1_RC_TOKEN", "").strip()

PR_SECTIONS: List[Dict[str, str]] = [
    {"key": "past_review", "title": "Past Review Analysis", "short": "Past Review"},
    {
        "key": "policy_regulation",
        "title": "Policy, KOD and Regulatory Analysis",
        "short": "Policy, KOD & Regulatory",
    },
    {"key": "broad_scope", "title": "Broad Scope Direction", "short": "Broad Scope"},
]
_VALID_PR_SECTION_KEYS = {item["key"] for item in PR_SECTIONS}

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

PLAN_ARTIFACTS: List[Dict[str, str]] = [
    {"id": "policy", "label": "Policies / KOD / Proc", "excludable": "true"},
    {"id": "findings_details", "label": "GFMS Findings", "excludable": "true"},
    {"id": "historical_plan_details", "label": "Historical Plans", "excludable": "true"},
    {"id": "lrr", "label": "LRR Mandates", "excludable": "true"},
    {"id": "current_details", "label": "Current Plan", "excludable": "false"},
    {"id": "alc_nlac", "label": "ALC / NALC", "excludable": "false"},
    {"id": "control_details", "label": "Controls", "excludable": "false"},
    {"id": "risk_driver_details", "label": "Risk Drivers", "excludable": "false"},
    {"id": "group_audit", "label": "Group Audit", "excludable": "false"},
]

_TYPE_ALIASES: Dict[str, str] = {
    "policy": "policy",
    "policies": "policy",
    "kod": "kod",
    "kods": "kod",
    "procedure": "procedure",
    "procedures": "procedure",
    "procedure_documents": "procedure",
    "gfms": "gfms",
    "gfms_data": "gfms",
    "findings": "gfms",
    "findings_details": "gfms",
    "historical": "historical_scoping_document",
    "historical_plan": "historical_scoping_document",
    "historical_plan_details": "historical_scoping_document",
    "historical_scoping": "historical_scoping_document",
    "historical_scoping_document": "historical_scoping_document",
    "lrr": "lrr",
    "lrr_mandates": "lrr",
    "mandates": "lrr",
}

_AFFECTED_SECTIONS_MAP: Dict[str, Tuple[str, ...]] = {
    "policy": ("policy_regulation", "broad_scope"),
    "kod": ("policy_regulation", "broad_scope"),
    "procedure": ("policy_regulation", "broad_scope"),
    "gfms": ("broad_scope",),
    "historical_scoping_document": ("past_review", "broad_scope"),
    "lrr": ("policy_regulation", "broad_scope"),
}

_RAG_FIELD_MAP: Dict[str, str] = {
    "policy": "policy_files",
    "kod": "kod_files",
    "procedure": "procedure_files",
}


class ChatProxyRequest(BaseModel):
    question: str
    plan_number: str
    context_type: str = "Preliminary Research Walkthrough"
    plan_name: Optional[str] = None
    research_sections: Optional[Dict[str, Any]] = None
    userDetails: Optional[Dict[str, Any]] = None


class ExtractionRunRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchGetRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchGenerateRequest(BaseModel):
    planNumber: str
    sections: Optional[List[str]] = None
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchEditRequest(BaseModel):
    planNumber: str
    analysis_report: Dict[str, Any]
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchDocumentRequest(BaseModel):
    planNumber: Optional[str] = None
    chunk_id: Optional[str] = None
    document_uri: Optional[str] = None
    page_number: Optional[int] = None


class PreliminaryResearchDownloadRequest(BaseModel):
    planNumber: str
    planName: Optional[str] = None
    userDetails: Optional[Dict[str, Any]] = None


class PreliminaryResearchAcceptRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


class CategorizeIdsRequest(BaseModel):
    document_ids: List[int]


class RagRelevantDataRequest(BaseModel):
    review_id: Optional[str] = None
    plan_number: Optional[str] = None
    region: Optional[str] = None
    au_countries: Optional[List[str]] = None
    plan_item_title: Optional[str] = None
    plan_item_description: Optional[str] = None
    au_list: Optional[List[str]] = None
    rt_list: Optional[List[str]] = None
    kc_list: Optional[List[str]] = None
    control_name: Optional[List[str]] = None
    control_how: Optional[List[str]] = None
    control_what: Optional[List[str]] = None
    control_why: Optional[List[str]] = None
    documents: List[Dict[str, Any]] = []


def create_async_client() -> httpx.AsyncClient:
    """Create the async HTTP client used for live CT1 calls (bypass local proxy env vars by default)."""
    timeout = httpx.Timeout(
        REQUEST_TIMEOUT_SECONDS,
        connect=30.0,
        read=REQUEST_TIMEOUT_SECONDS,
        write=60.0,
        pool=30.0,
    )
    return httpx.AsyncClient(verify=False, trust_env=HTTPX_TRUST_ENV, timeout=timeout)


app = FastAPI(title="CT1 Live Preliminary Research & Scoping Demo UI", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _normalize_doc_type(value: Any) -> str:
    cleaned = re.sub(r"[\s-]+", "_", str(value or "").strip().lower())
    return _TYPE_ALIASES.get(cleaned, cleaned or "policy")


def _unwrap_data_dict(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def _extract_error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            return str(payload.get("detail") or payload.get("message") or payload.get("error") or payload)
        return str(payload)
    except Exception:
        return response.text[:500] or f"HTTP {response.status_code}"


def _extract_error_payload(response: httpx.Response) -> Any:
    try:
        return response.json()
    except Exception:
        return response.text[:4000] if getattr(response, "text", None) else f"HTTP {response.status_code}"


def _raise_upstream_http_error(
    status_code: int,
    *,
    operation: str,
    url: str,
    message: str,
    upstream_status: Optional[int] = None,
    upstream_body: Any = None,
    extra: Optional[Dict[str, Any]] = None,
) -> NoReturn:
    detail: Dict[str, Any] = {
        "error": message,
        "operation": operation,
        "upstream_url": url,
        "upstream_status": upstream_status,
        "upstream_body": upstream_body,
    }
    if extra:
        detail["details"] = extra
    raise HTTPException(status_code=status_code, detail=detail)


async def _forward_json(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    json_body: Optional[Dict[str, Any]] = None,
    *,
    operation: str = "upstream_request",
) -> Dict[str, Any]:
    try:
        response = await client.request(method, url, json=json_body)
    except Exception as exc:
        logger.error("Upstream request failed (%s %s): %s", method, url, exc, exc_info=True)
        _raise_upstream_http_error(
            502,
            operation=operation,
            url=url,
            message=f"Upstream request failed ({type(exc).__name__}): {exc}",
            extra={"exception_type": type(exc).__name__, "method": method},
        )
    if response.status_code >= 400:
        err_payload = _extract_error_payload(response)
        _raise_upstream_http_error(
            response.status_code,
            operation=operation,
            url=url,
            message=f"CT1 returned HTTP {response.status_code}: {_extract_error_detail(response)}",
            upstream_status=response.status_code,
            upstream_body=err_payload,
            extra={"method": method},
        )
    try:
        return response.json()
    except Exception as exc:
        _raise_upstream_http_error(
            502,
            operation=operation,
            url=url,
            message=f"Invalid JSON from CT1 ({url}): {exc}",
            upstream_status=response.status_code,
            upstream_body=(response.text[:4000] if getattr(response, "text", None) else ""),
            extra={"exception_type": type(exc).__name__, "method": method},
        )


def _gateway_headers() -> Dict[str, str]:
    return {"x-asm-rctoken": CT1_RC_TOKEN} if CT1_RC_TOKEN else {}


def _scope_query_string(scope: Optional[Dict[str, Any]]) -> str:
    """Return '?review_scope_id=..&process_instance_id=..&task_id=..' only when values exist."""
    scope = scope or {}
    params = {
        k: str(scope[k]).strip()
        for k in ("review_scope_id", "process_instance_id", "task_id")
        if scope.get(k) not in (None, "") and str(scope[k]).strip()
    }
    return f"?{urlencode(params)}" if params else ""


def _normalize_user_details(
    raw: Optional[Dict[str, Any]] = None,
    *,
    review_scope_id: Optional[str] = None,
    process_instance_id: Optional[str] = None,
    task_id: Optional[str] = None,
    review_scope_stage: Optional[str] = None,
    user: Optional[str] = None,
) -> Dict[str, Any]:
    """Merge explicit scope fields over a raw userDetails dict; always carries a user."""
    details: Dict[str, Any] = dict(raw or {})
    for key, value in (
        ("review_scope_id", review_scope_id),
        ("process_instance_id", process_instance_id),
        ("task_id", task_id),
        ("review_scope_stage", review_scope_stage),
        ("user", user),
    ):
        if value not in (None, "") and str(value).strip():
            details[key] = str(value).strip()
    if not details.get("user"):
        details["user"] = "demo.user@db.com"
    return details


def _scope_user_details(scope: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return normalized userDetails only when workflow scope identifiers are present."""
    details = _normalize_user_details(scope)
    if any(
        details.get(key)
        for key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage")
    ):
        return details
    return None


def _merge_scope_context(
    explicit: Optional[Dict[str, Any]] = None,
    auto: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Merge explicit query/form scope fields over auto-detected `/task/status` values."""
    merged: Dict[str, Any] = {
        key: value
        for key, value in (auto or {}).items()
        if value not in (None, "") and str(value).strip()
    }
    for key, value in (explicit or {}).items():
        if value not in (None, "") and str(value).strip():
            merged[key] = str(value).strip()
    if not merged.get("user"):
        merged["user"] = "demo.user@db.com"
    return merged


def _scope_source(explicit: Optional[Dict[str, Any]], auto: Optional[Dict[str, Any]]) -> str:
    if any(
        (explicit or {}).get(key) not in (None, "") and str((explicit or {}).get(key)).strip()
        for key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage")
    ):
        return "explicit"
    if any(
        (auto or {}).get(key) not in (None, "") and str((auto or {}).get(key)).strip()
        for key in ("review_scope_id", "process_instance_id", "task_id")
    ):
        return "auto"
    return "plan"


def _scope_from_task_status(task_status: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(task_status, dict):
        return {}
    raw_variables = task_status.get("variables")
    if isinstance(raw_variables, str):
        try:
            raw_variables = json.loads(raw_variables)
        except Exception:
            raw_variables = {}
    variables = raw_variables if isinstance(raw_variables, dict) else {}
    scope_id = None
    for key in (
        "review_scope_id",
        "reviewScopeId",
        "review_scope_instance_id",
        "reviewScopeInstanceId",
        "p_REVIEW_SCOPE_ID",
    ):
        if variables.get(key) not in (None, ""):
            scope_id = variables[key]
            break
    out = {
        "review_scope_id": scope_id,
        "process_instance_id": task_status.get("processInstanceId"),
        "task_id": task_status.get("taskId"),
        "review_scope_stage": task_status.get("taskDefinitionKey"),
        "user": task_status.get("owner"),
    }
    return {k: str(v).strip() for k, v in out.items() if v not in (None, "") and str(v).strip()}


async def _fetch_task_status_best_effort(
    client: httpx.AsyncClient, plan_number: str
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Fetch workflow task status from gateway; returns `(None, reason)` if plan has no active task."""
    url = f"{GATEWAY_BASE}/api/v1/task/status/{plan_number}"
    get_kwargs: Dict[str, Any] = {"timeout": TASK_STATUS_TIMEOUT_SECONDS}
    if _gateway_headers():
        get_kwargs["headers"] = _gateway_headers()
    try:
        resp = await client.get(url, **get_kwargs)
        if resp.status_code == 200:
            data = resp.json()
            return (data if isinstance(data, dict) else None), None
        return None, f"task/status returned HTTP {resp.status_code}"
    except Exception as exc:
        return None, f"task/status unavailable ({type(exc).__name__}): {exc}"


async def _fetch_artifact_safe(
    client: httpx.AsyncClient,
    plan_number: str,
    artifact_id: str,
    scope: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/{artifact_id}{_scope_query_string(scope)}"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "url": url, "data": resp.json()}
        return {
            "ok": False,
            "status_code": resp.status_code,
            "url": url,
            "error": _extract_error_detail(resp),
            "upstream_body": _extract_error_payload(resp),
            "data": None,
        }
    except Exception as exc:
        return {
            "ok": False,
            "status_code": 502,
            "url": url,
            "error": f"{type(exc).__name__}: {exc}",
            "exception_type": type(exc).__name__,
            "data": None,
        }


async def _fetch_availability_safe(client: httpx.AsyncClient, plan_number: str) -> Dict[str, Any]:
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/availability"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "url": url, "data": resp.json()}
        return {
            "ok": False,
            "status_code": resp.status_code,
            "url": url,
            "error": _extract_error_detail(resp),
            "upstream_body": _extract_error_payload(resp),
            "data": None,
        }
    except Exception as exc:
        return {
            "ok": False,
            "status_code": 502,
            "url": url,
            "error": f"{type(exc).__name__}: {exc}",
            "exception_type": type(exc).__name__,
            "data": None,
        }


async def _fetch_catalog_live(
    client: httpx.AsyncClient,
    plan_number: str,
    user_details: Optional[Dict[str, Any]] = None,
) -> Tuple[Optional[Dict[str, Any]], Optional[str], str, List[Dict[str, Any]]]:
    """Fetch document catalog directly from CT1 Query Service `/qna/documents/list-all` with zero fallbacks."""
    url = f"{QUERY_SERVICE_BASE}/qna/documents/list-all"
    body: Dict[str, Any] = {"plan_number": plan_number}
    if user_details:
        body["userDetails"] = dict(user_details)

    try:
        resp = await client.post(url, json=body, timeout=REQUEST_TIMEOUT_SECONDS)
    except Exception as exc:
        err_msg = f"query_service: {type(exc).__name__}: {exc}"
        return (
            None,
            err_msg,
            "error",
            [
                {
                    "target": "catalog:query_service",
                    "upstream_url": url,
                    "upstream_status": 502,
                    "error": f"{type(exc).__name__}: {exc}",
                    "exception_type": type(exc).__name__,
                }
            ],
        )

    if resp.status_code != 200:
        detail_str = _extract_error_detail(resp)
        err_msg = f"query_service: HTTP {resp.status_code} ({detail_str[:160]})"
        return (
            None,
            err_msg,
            "error",
            [
                {
                    "target": "catalog:query_service",
                    "upstream_url": url,
                    "upstream_status": resp.status_code,
                    "error": detail_str,
                    "upstream_body": _extract_error_payload(resp),
                }
            ],
        )

    try:
        parsed = resp.json()
    except Exception as exc:
        err_msg = f"query_service: Invalid JSON ({exc})"
        return (
            None,
            err_msg,
            "error",
            [
                {
                    "target": "catalog:query_service",
                    "upstream_url": url,
                    "upstream_status": 502,
                    "error": err_msg,
                    "upstream_body": (resp.text[:4000] if getattr(resp, "text", None) else ""),
                }
            ],
        )

    if not isinstance(parsed, dict) or not isinstance(parsed.get("document_groups"), list):
        err_msg = "query_service: missing document_groups in 200 JSON payload"
        return (
            None,
            err_msg,
            "error",
            [
                {
                    "target": "catalog:query_service",
                    "upstream_url": url,
                    "upstream_status": 200,
                    "error": "Response missing document_groups",
                    "upstream_body": parsed,
                }
            ],
        )

    return parsed, None, "query_service", []


async def _load_plan_bundle(plan_number: str, scope_context: Optional[Dict[str, Any]] = None) -> Tuple[
    Optional[Dict[str, Any]],
    Dict[str, Any],
    Optional[Dict[str, Any]],
    Dict[str, str],
    str,
    List[Dict[str, Any]],
    Optional[Dict[str, Any]],
    Dict[str, Any],
    str,
]:
    """Load availability, all 9 Data Extraction feeds, and live Query Service catalog from CT1."""
    artifact_ids = [item["id"] for item in PLAN_ARTIFACTS]
    explicit_scope = {
        key: str(value).strip()
        for key, value in (scope_context or {}).items()
        if key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage", "user")
        and value not in (None, "")
        and str(value).strip()
    }
    async with create_async_client() as client:
        task_status, task_status_error = await _fetch_task_status_best_effort(client, plan_number)
        auto_scope = _scope_from_task_status(task_status)
        resolved_scope = _merge_scope_context(explicit_scope, auto_scope)
        scope_source = _scope_source(explicit_scope, auto_scope)
        scope_user_details = _scope_user_details(resolved_scope)
        if task_status_error:
            logger.info("Plan %s task/status not used for scope: %s", plan_number, task_status_error)

        avail_res, *art_results = await asyncio.gather(
            _fetch_availability_safe(client, plan_number),
            *(_fetch_artifact_safe(client, plan_number, aid, resolved_scope) for aid in artifact_ids),
        )

        artifacts: Dict[str, Any] = {}
        errors: Dict[str, str] = {}
        error_details: List[Dict[str, Any]] = []
        availability = avail_res["data"] if avail_res["ok"] else None
        if not avail_res["ok"]:
            errors["availability"] = str(avail_res.get("error") or "Availability unavailable")
            error_details.append(
                {
                    "target": "availability",
                    "upstream_url": avail_res.get("url"),
                    "upstream_status": avail_res.get("status_code"),
                    "error": errors["availability"],
                    **(
                        {"upstream_body": avail_res["upstream_body"]}
                        if "upstream_body" in avail_res
                        else {}
                    ),
                    **(
                        {"exception_type": avail_res["exception_type"]}
                        if "exception_type" in avail_res
                        else {}
                    ),
                }
            )

        for aid, res in zip(artifact_ids, art_results):
            if res["ok"]:
                artifacts[aid] = res["data"]
            else:
                errors[aid] = str(res.get("error") or f"HTTP {res.get('status_code')}")
                error_details.append(
                    {
                        "target": aid,
                        "upstream_url": res.get("url"),
                        "upstream_status": res.get("status_code"),
                        "error": errors[aid],
                        **(
                            {"upstream_body": res["upstream_body"]}
                            if "upstream_body" in res
                            else {}
                        ),
                        **(
                            {"exception_type": res["exception_type"]}
                            if "exception_type" in res
                            else {}
                        ),
                    }
                )

        if not artifacts and error_details:
            raise HTTPException(
                status_code=502,
                detail={
                    "error": f"Failed to load Plan {plan_number} feeds from CT1 ({len(error_details)} endpoint failure(s)).",
                    "operation": "bootstrap",
                    "plan_number": plan_number,
                    "upstream_url": DATAEXTRACTION_BASE,
                    "upstream_status": error_details[0].get("upstream_status"),
                    "errors": errors,
                    "error_details": error_details,
                },
            )

        raw_catalog, cat_notice, query_mode, cat_error_details = await _fetch_catalog_live(
            client, plan_number, user_details=scope_user_details
        )
        if cat_notice:
            errors["catalog"] = cat_notice
            error_details.extend(cat_error_details)

    return (
        availability,
        artifacts,
        raw_catalog,
        errors,
        query_mode,
        error_details,
        task_status,
        resolved_scope,
        scope_source,
    )


def _derive_affected_sections(actions: List[Dict[str, Any]]) -> List[str]:
    affected: Set[str] = set()
    for act in actions or []:
        if not isinstance(act, dict):
            continue
        dtype = _normalize_doc_type(act.get("document_type") or "policy")
        for sec in _AFFECTED_SECTIONS_MAP.get(dtype, ("broad_scope",)):
            affected.add(sec)
    return [s for s in ("past_review", "policy_regulation", "broad_scope") if s in affected]


def _normalize_summary_user_details(raw: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Build a UserRequest-compatible dict for scoping-summary-agent."""
    base = _normalize_user_details(raw)
    out: Dict[str, Any] = {
        k: v
        for k, v in base.items()
        if k in ("process_instance_id", "task_id", "review_scope_stage", "user", "remarks")
        and v not in (None, "")
    }
    raw_scope = (raw or {}).get("review_scope_id") if isinstance(raw, dict) else None
    if raw_scope in (None, ""):
        raw_scope = base.get("review_scope_id")
    if isinstance(raw_scope, int) and not isinstance(raw_scope, bool):
        out["review_scope_id"] = raw_scope
        out["review_scope_instance_id"] = str(raw_scope)
    elif raw_scope not in (None, ""):
        cleaned = str(raw_scope).strip()
        if cleaned.lstrip("-").isdigit():
            out["review_scope_id"] = int(cleaned)
            out["review_scope_instance_id"] = cleaned
    return out


def _unwrap_preliminary_research_response(plan_number: str, raw: Any) -> Optional[Dict[str, Any]]:
    """Extract canonical `{plan_number, analysis_report}` from scoping-summary-agent payloads."""
    if not isinstance(raw, dict):
        return None
    pr_titles = {item["title"] for item in PR_SECTIONS}
    queue: List[Any] = [raw]
    seen: Set[int] = set()
    while queue:
        cur = queue.pop(0)
        if not isinstance(cur, dict) or id(cur) in seen:
            continue
        seen.add(id(cur))
        report = cur.get("analysis_report")
        if isinstance(report, dict) and report:
            resolved_plan = str(cur.get("plan_number") or cur.get("planNumber") or plan_number).strip()
            return {"plan_number": resolved_plan, "analysis_report": report}
        if any(title in cur and isinstance(cur.get(title), dict) for title in pr_titles):
            return {"plan_number": str(plan_number).strip(), "analysis_report": cur}
        for key in ("response", "payload", "data", "result"):
            if key in cur and cur[key] is not None:
                queue.append(cur[key])
    return None


async def _fetch_preliminary_research_on_bootstrap(plan_number: str) -> Dict[str, Any]:
    """Fetch existing Preliminary Research document directly from `/scoping-summary-agent/get-preliminary-research-document`."""
    url = f"{SUMMARY_AGENT_BASE}/get-preliminary-research-document"
    async with create_async_client() as client:
        try:
            resp = await client.post(url, json={"planNumber": plan_number}, timeout=20.0)
        except Exception as exc:
            logger.info("Bootstrap preliminary research check unreachable: %s", exc)
            return {
                "available": False,
                "plan_number": plan_number,
                "analysis_report": None,
                "source": "summary_agent",
                "error": f"{type(exc).__name__}: {exc}",
            }

        if resp.status_code == 200:
            try:
                raw = resp.json()
            except Exception as exc:
                return {
                    "available": False,
                    "plan_number": plan_number,
                    "analysis_report": None,
                    "source": "summary_agent",
                    "error": f"Invalid JSON from Summary Agent: {exc}",
                }
            unwrapped = _unwrap_preliminary_research_response(plan_number, raw)
            if unwrapped:
                return {
                    "available": True,
                    "plan_number": unwrapped["plan_number"],
                    "analysis_report": unwrapped["analysis_report"],
                    "source": "summary_agent",
                    "error": None,
                }
            return {
                "available": False,
                "plan_number": plan_number,
                "analysis_report": None,
                "source": "summary_agent",
                "error": "Response missing analysis_report.",
            }

        if resp.status_code == 404:
            return {
                "available": False,
                "plan_number": plan_number,
                "analysis_report": None,
                "source": "summary_agent",
                "error": None,
            }

        return {
            "available": False,
            "plan_number": plan_number,
            "analysis_report": None,
            "source": "summary_agent",
            "error": f"HTTP {resp.status_code}: {_extract_error_detail(resp)}",
        }


@app.get("/api/config")
async def get_config() -> Dict[str, Any]:
    """Return CT1 host settings and artifact metadata definitions."""
    return {
        "cta_host": CTA_HOST,
        "dataextraction_base": DATAEXTRACTION_BASE,
        "query_service_base": QUERY_SERVICE_BASE,
        "rag_service_base": RAG_SERVICE_BASE,
        "summary_agent_base": SUMMARY_AGENT_BASE,
        "gateway_base": GATEWAY_BASE,
        "default_plan_number": DEFAULT_PLAN_NUMBER,
        "artifacts": PLAN_ARTIFACTS,
        "pr_sections": PR_SECTIONS,
    }


@app.get("/api/ct1/task/status/{plan_number}")
async def proxy_task_status(plan_number: str) -> Dict[str, Any]:
    """Pass through the live workflow task status for a plan from CT1 API Gateway."""
    async with create_async_client() as client:
        task_status, error = await _fetch_task_status_best_effort(client, plan_number)
    return {
        "plan_number": plan_number,
        "available": task_status is not None,
        "task_status": task_status,
        "scope_context": _scope_from_task_status(task_status),
        "error": error,
    }


@app.get("/api/ct1/plan/{plan_number}/bootstrap")
async def bootstrap_plan(
    plan_number: str,
    review_scope_id: Optional[str] = Query(default=None),
    process_instance_id: Optional[str] = Query(default=None),
    task_id: Optional[str] = Query(default=None),
    review_scope_stage: Optional[str] = Query(default=None),
    user: Optional[str] = Query(default=None),
) -> Dict[str, Any]:
    """
    Fetch live CT1 availability, all 9 Data Extraction payloads, live Query Service
    document catalog, and saved Preliminary Research document without any fallbacks or mocks.
    """
    started = time.perf_counter()
    scope_context = {
        "review_scope_id": review_scope_id,
        "process_instance_id": process_instance_id,
        "task_id": task_id,
        "review_scope_stage": review_scope_stage,
        "user": user,
    }
    bundle, preliminary_research = await asyncio.gather(
        _load_plan_bundle(plan_number, scope_context),
        _fetch_preliminary_research_on_bootstrap(plan_number),
    )
    (
        availability,
        artifacts,
        catalog,
        errors,
        query_mode,
        error_details,
        task_status,
        resolved_scope,
        scope_source,
    ) = bundle
    return {
        "plan_number": plan_number,
        "cta_host": CTA_HOST,
        "query_mode": query_mode,
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
        "catalog": catalog,
        "availability": availability,
        "artifacts": artifacts,
        "preliminary_research": preliminary_research,
        "errors": errors,
        "has_errors": bool(error_details),
        "error_details": error_details,
        "task_status": task_status,
        "scope_context": resolved_scope,
        "scope_source": scope_source,
    }


@app.get("/api/ct1/dataextraction/status/{session_id}")
async def proxy_extraction_status(session_id: str) -> Dict[str, Any]:
    """Poll CT1 data extraction job status."""
    url = f"{DATAEXTRACTION_BASE}/data-extraction/{session_id}/status"
    async with create_async_client() as client:
        return await _forward_json(client, "GET", url, operation="dataextraction_status")


@app.get("/api/ct1/dataextraction/{plan_number}/{artifact}")
async def proxy_get_artifact(
    plan_number: str,
    artifact: str,
    review_scope_id: Optional[str] = Query(default=None),
    process_instance_id: Optional[str] = Query(default=None),
    task_id: Optional[str] = Query(default=None),
    review_scope_stage: Optional[str] = Query(default=None),
) -> Any:
    """Live pass-through to CT1 GET /scoping-dataextraction-agent/getdata/{plan_number}/{artifact}."""
    scope = {
        "review_scope_id": review_scope_id,
        "process_instance_id": process_instance_id,
        "task_id": task_id,
        "review_scope_stage": review_scope_stage,
    }
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/{artifact}{_scope_query_string(scope)}"
    async with create_async_client() as client:
        try:
            resp = await client.get(url)
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation=f"getdata:{artifact}",
                url=url,
                message=f"Unable to fetch artifact '{artifact}' from CT1 ({type(exc).__name__}): {exc}",
                extra={"exception_type": type(exc).__name__, "plan_number": plan_number, "artifact": artifact},
            )
        if resp.status_code != 200:
            _raise_upstream_http_error(
                resp.status_code,
                operation=f"getdata:{artifact}",
                url=url,
                message=f"CT1 getdata/{artifact} returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
                upstream_status=resp.status_code,
                upstream_body=_extract_error_payload(resp),
                extra={"plan_number": plan_number, "artifact": artifact},
            )
        try:
            return resp.json()
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation=f"getdata:{artifact}",
                url=url,
                message=f"Invalid JSON from CT1 getdata/{artifact}: {exc}",
                upstream_status=resp.status_code,
                upstream_body=resp.text[:4000],
            )


@app.post("/api/ct1/dataextraction/run")
async def proxy_run_extraction(payload: ExtractionRunRequest) -> Dict[str, Any]:
    """Trigger a fresh CT1 data extraction run."""
    url = f"{DATAEXTRACTION_BASE}/data-extraction"
    user_details = _normalize_user_details(payload.userDetails)
    body = {"planNumber": payload.planNumber, "userDetails": user_details}
    async with create_async_client() as client:
        return await _forward_json(client, "POST", url, json_body=body, operation="dataextraction_run")


_MAX_CHAT_QUERY_CHARS = 4000
_GUARDRAIL_PROMPT_INJECTION_RE = re.compile(
    r"(?:"
    r"\b(?:ignore|disregard|forget|override|bypass)\s+(?:all\s+|any\s+)?(?:previous|prior|above|system|developer)\s+(?:instructions?|prompts?|rules?|guardrails?)\b"
    r"|\b(?:reveal|print|show|dump|output|leak)\s+(?:your\s+|the\s+)?(?:system\s+prompt|hidden\s+instructions?|developer\s+message)\b"
    r"|\b(?:bypass|skip|disable|turn\s+off)\s+(?:the\s+)?(?:approval|human\s+review|verification|security|compliance|guardrails?)\b"
    r"|\b(?:you\s+are\s+now\s+in\s+developer\s+mode|act\s+as\s+an\s+unrestricted|jailbreak)\b"
    r")",
    re.IGNORECASE,
)
_GUARDRAIL_BULK_WIPE_RE = re.compile(
    r"(?:"
    r"\b(?:remove|delete|exclude|drop|wipe|clear|purge)\s+(?:all|every)\s+(?:the\s+)?(?:documents?|policies|kods?|procedures?|gfms|findings?|mandates?|files?|records?|context|data)\b"
    r"|\b(?:remove|delete|exclude|wipe|clear|purge)\s+everything\b"
    r")",
    re.IGNORECASE,
)
_GUARDRAIL_PAYLOAD_RE = re.compile(
    r"(?:\.\./|\.\.\\|<\s*script\b|javascript\s*:|;\s*(?:drop|delete|truncate|update|insert|alter)\s+(?:table|from|into)\b|\bunion\s+(?:all\s+)?select\b)",
    re.IGNORECASE,
)
_GUARDRAIL_SECRET_RE = re.compile(
    r"\b(?:bearer\s+[a-z0-9._\-]{8,}|(?:api[_-]?key|token|secret|password|passwd)\s*[:=]\s*['\"]?[^\s,;'\"]{4,}['\"]?)",
    re.IGNORECASE,
)


def _check_chat_guardrails(user_text: str, plan_number: str) -> Tuple[str, Optional[str]]:
    """Sanitize chat input and block prompt injection, cross-plan, script/SQL, or mass-wipe attempts."""
    cleaned = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", str(user_text or ""))
    cleaned = _GUARDRAIL_SECRET_RE.sub("[REDACTED]", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    if not cleaned:
        return "", "Query cannot be empty."
    if len(cleaned) > _MAX_CHAT_QUERY_CHARS:
        return cleaned[:_MAX_CHAT_QUERY_CHARS], f"Query exceeds maximum permitted length ({_MAX_CHAT_QUERY_CHARS} chars)."
    if _GUARDRAIL_PROMPT_INJECTION_RE.search(cleaned):
        return cleaned, "Blocked potential prompt injection or guardrail-bypass instruction."
    if _GUARDRAIL_PAYLOAD_RE.search(cleaned):
        return cleaned, "Blocked unsafe path-traversal, script, or SQL-injection payload."
    if _GUARDRAIL_BULK_WIPE_RE.search(cleaned):
        return cleaned, (
            "Compliance policy prohibits bulk-deleting all scoping documents at once. "
            "Specify the individual document(s) or section(s)."
        )
    for ref_plan in re.findall(r"\bdbaware_review_(\d+)\b", cleaned, flags=re.IGNORECASE):
        if ref_plan.strip() != str(plan_number).strip():
            return cleaned, f"Cross-plan access blocked: plan {ref_plan} does not match active plan {plan_number}."

    cleaned = cleaned.replace("<<<", "< < <").replace(">>>", "> > >")
    return cleaned, None


@app.post("/api/ct1/query/chat")
async def proxy_query_chat(payload: ChatProxyRequest) -> Dict[str, Any]:
    """Forward chat turns directly to CT1 Query Service `/qna/chat` without fallbacks."""
    plan_number = str(payload.plan_number).strip()
    clean_question, violation = _check_chat_guardrails(payload.question, plan_number)
    if violation is not None:
        logger.warning("Guardrail blocked Demo UI chat query for Plan %s: %s", plan_number, violation)
        return {
            "session_id": plan_number,
            "answer": f"Request blocked by security & compliance guardrail: {violation}",
            "document_workflow": {
                "stage": "rejected",
                "status": "rejected_by_guardrail",
                "plan_number": plan_number,
                "requires_approval": False,
            },
        }

    url = f"{QUERY_SERVICE_BASE}/qna/chat"
    body: Dict[str, Any] = {
        "question": clean_question,
        "plan_number": plan_number,
        "context_type": payload.context_type,
        "userDetails": _normalize_user_details(payload.userDetails),
    }
    if payload.plan_name:
        body["plan_name"] = payload.plan_name
    if isinstance(payload.research_sections, dict) and payload.research_sections:
        body["research_sections"] = payload.research_sections

    async with create_async_client() as client:
        try:
            resp = await client.post(url, json=body)
        except Exception as exc:
            logger.error("CT1 Query Service unreachable (%s): %s", url, exc, exc_info=True)
            _raise_upstream_http_error(
                502,
                operation="query_chat",
                url=url,
                message=f"Query Service unreachable ({type(exc).__name__}): {exc}",
                extra={
                    "exception_type": type(exc).__name__,
                    "plan_number": plan_number,
                    "question": clean_question,
                },
            )

    if resp.status_code >= 400:
        err_payload = _extract_error_payload(resp)
        _raise_upstream_http_error(
            resp.status_code,
            operation="query_chat",
            url=url,
            message=f"Query Service returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
            upstream_status=resp.status_code,
            upstream_body=err_payload,
            extra={"plan_number": plan_number, "question": clean_question},
        )

    try:
        data = resp.json()
    except Exception as exc:
        _raise_upstream_http_error(
            502,
            operation="query_chat",
            url=url,
            message=f"Invalid JSON from Query Service: {exc}",
            upstream_status=resp.status_code,
            upstream_body=(resp.text[:4000] if getattr(resp, "text", None) else ""),
            extra={"exception_type": type(exc).__name__, "plan_number": plan_number},
        )

    if isinstance(data, dict) and isinstance(data.get("document_workflow"), dict):
        wf = data["document_workflow"]
        stage = str(wf.get("stage") or "").strip().lower()
        wf_status = str(wf.get("status") or "").strip().lower()
        exec_obj = wf.get("execution") if isinstance(wf.get("execution"), dict) else {}
        exec_status = str(exec_obj.get("status") or "").strip().lower()
        failed_list: List[Any] = []
        for candidate_failures in (
            wf.get("failed"),
            exec_obj.get("failed"),
            (exec_obj.get("audit") or {}).get("failures") if isinstance(exec_obj.get("audit"), dict) else None,
            (wf.get("audit") or {}).get("failures") if isinstance(wf.get("audit"), dict) else None,
        ):
            if isinstance(candidate_failures, list) and candidate_failures:
                failed_list.extend(candidate_failures)

        answer_text = str(data.get("answer") or "")
        is_wf_error = (
            stage in ("error", "partial_failure")
            or wf_status in ("error", "partial_failure")
            or exec_status in ("error", "partial_failure")
            or bool(failed_list)
            or (stage == "executed" and exec_obj.get("registry_updated") is False)
            or ("no document changes were applied" in answer_text.lower())
        )

        if is_wf_error:
            if stage == "executed" and (
                wf_status in ("error", "partial_failure")
                or exec_status in ("error", "partial_failure")
                or exec_obj.get("registry_updated") is False
                or not (exec_obj.get("executed") or wf.get("executed"))
            ):
                wf["raw_stage"] = stage
                wf["stage"] = (
                    "partial_failure"
                    if (wf_status == "partial_failure" or exec_status == "partial_failure")
                    else "error"
                )
            data["error_details"] = {
                "operation": "query_chat",
                "upstream_url": url,
                "upstream_status": resp.status_code,
                "plan_number": plan_number,
                "stage": wf.get("stage"),
                "status": wf_status or exec_status or "error",
                "message": answer_text or str(wf.get("message") or "Document workflow execution failed."),
                "failed": failed_list,
                "audit": exec_obj.get("audit") or wf.get("audit") or {},
                "raw_workflow": wf,
            }
            return data

        if stage in ("pending_approval", "awaiting_approval") or (
            wf.get("requires_approval") is True
            and stage
            not in (
                "executed",
                "cancelled",
                "rejected",
                "no_verified_actions",
                "not_document_request",
                "not_found",
                "error",
            )
        ):
            proposed = (
                wf.get("steps")
                or (wf.get("plan") or {}).get("actions")
                or wf.get("actions")
                or []
            )
            if proposed:
                wf["stage"] = "awaiting_approval"
                wf["actions"] = proposed
                wf["steps"] = proposed
                wf["plan"] = {"actions": proposed}
            return data

        if stage == "executed":
            executed = (
                (wf.get("execution") or {}).get("executed")
                or wf.get("executed")
                or (wf.get("execution_json") or {}).get("actions")
                or (wf.get("plan") or {}).get("actions")
                or wf.get("actions")
                or wf.get("steps")
                or []
            )
            wf["executed"] = executed
            if executed and not wf.get("actions"):
                wf["actions"] = executed
            if not wf.get("affected_sections"):
                wf["affected_sections"] = _derive_affected_sections(executed)

    return data


def _infer_doc_type_from_filename(filename: str, explicit_type: str = "auto") -> str:
    """Resolve document category (`policy`, `kod`, or `procedure`) from explicit choice or filename."""
    raw = str(explicit_type or "auto").strip().lower()
    if raw and raw != "auto":
        normalized = _normalize_doc_type(raw)
        if normalized in _RAG_FIELD_MAP:
            return normalized

    stem = Path(filename or "").stem.lower()
    if re.search(r"(^|[^a-z0-9])kod([^a-z0-9]|$)|key[_\s-]+operating", stem):
        return "kod"
    if re.search(r"procedure|(^|[^a-z0-9])(proc|sop)([^a-z0-9]|$)", stem):
        return "procedure"
    return "policy"


def _extract_rag_doc_ids(payload: Any) -> List[int]:
    """Collect numeric document IDs from RAG service responses."""
    candidates: List[Any] = []
    if isinstance(payload, dict):
        for container in (payload, payload.get("result"), payload.get("data")):
            if not isinstance(container, dict):
                continue
            for key in ("document_ids", "doc_ids", "ids"):
                val = container.get(key)
                if isinstance(val, list):
                    candidates.extend(val)
            docs = container.get("documents")
            if isinstance(docs, list):
                for d in docs:
                    if isinstance(d, dict) and d.get("document_id") is not None:
                        candidates.append(d["document_id"])
                    elif isinstance(d, (int, str)):
                        candidates.append(d)

    seen: Set[int] = set()
    out: List[int] = []
    for item in candidates:
        if isinstance(item, bool):
            continue
        sval = str(item).strip()
        if sval.lstrip("-").isdigit():
            ival = int(sval)
            if ival not in seen:
                seen.add(ival)
                out.append(ival)
    return out


def _parse_categorize_response(raw_cat: Any) -> Dict[int, str]:
    """Normalize `/categorize-document-ids` output into `{doc_id: 'policy'|'kod'|'procedure'}`."""
    mapping: Dict[int, str] = {}
    if not isinstance(raw_cat, (dict, list)):
        return mapping

    def _absorb_item(item: Dict[str, Any], default_type: Optional[str] = None) -> None:
        raw_id = item.get("document_id") if item.get("document_id") is not None else item.get("id")
        raw_type = item.get("document_type") or item.get("category") or item.get("type") or default_type
        if raw_id is not None and str(raw_id).strip().lstrip("-").isdigit() and raw_type:
            norm_t = _normalize_doc_type(raw_type)
            if norm_t in _RAG_FIELD_MAP:
                mapping[int(str(raw_id).strip())] = norm_t

    containers: List[Any] = [raw_cat]
    if isinstance(raw_cat, dict):
        for nested_key in ("categorized", "categories", "document_categories", "results", "documents", "data"):
            if nested_key in raw_cat and raw_cat[nested_key] is not None:
                containers.append(raw_cat[nested_key])

    for node in containers:
        if isinstance(node, list):
            for entry in node:
                if isinstance(entry, dict):
                    _absorb_item(entry)
        elif isinstance(node, dict):
            for k, v in node.items():
                k_norm = _normalize_doc_type(k)
                if k_norm in _RAG_FIELD_MAP and isinstance(v, list):
                    for sub in v:
                        if isinstance(sub, dict):
                            _absorb_item(sub, default_type=k_norm)
                        elif str(sub).strip().lstrip("-").isdigit():
                            mapping[int(str(sub).strip())] = k_norm
                elif str(k).strip().lstrip("-").isdigit() and isinstance(v, str):
                    v_norm = _normalize_doc_type(v)
                    if v_norm in _RAG_FIELD_MAP:
                        mapping[int(str(k).strip())] = v_norm
    return mapping


def _build_rag_relevant_payload_from_artifacts(
    plan_number: str,
    artifacts: Dict[str, Any],
    documents_spec: List[Dict[str, Any]],
    overrides: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build `/get-relevant-data-for-documents` JSON body from CT1 `current_details` + `control_details`."""
    ov = {k: v for k, v in (overrides or {}).items() if v is not None}
    plan_det = (_unwrap_data_dict(artifacts.get("current_details")) or {}).get("plan_details") or {}
    if not isinstance(plan_det, dict):
        plan_det = {}
    ctrl_wrap = (_unwrap_data_dict(artifacts.get("control_details")) or {}).get("control_details") or {}
    controls = (
        ctrl_wrap.get("included_kcs")
        if isinstance(ctrl_wrap, dict) and isinstance(ctrl_wrap.get("included_kcs"), list)
        else []
    )

    def _split_list(val: Any) -> List[str]:
        if isinstance(val, list):
            return [str(x).strip() for x in val if str(x).strip()]
        if not val:
            return []
        sep = ";" if ";" in str(val) else ","
        return [p.strip() for p in str(val).split(sep) if p.strip()]

    au_rt_kc = plan_det.get("AU-RT-KC") if isinstance(plan_det.get("AU-RT-KC"), list) else []
    au_list = list(dict.fromkeys(str(r["AU"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("AU")))
    rt_list = list(dict.fromkeys(str(r["RT"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("RT")))
    kc_list = list(dict.fromkeys(str(r["KC"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("KC")))
    if not rt_list and plan_det.get("UoT Risk Type"):
        rt_list = [str(plan_det["UoT Risk Type"]).split(" - ", 1)[0].strip()]
    if not kc_list and plan_det.get("UoT KCs"):
        kc_list = [str(plan_det["UoT KCs"]).split(" - ", 1)[0].strip()]

    c_names: List[str] = []
    c_how: List[str] = []
    c_what: List[str] = []
    c_why: List[str] = []
    for ctrl in controls:
        if not isinstance(ctrl, dict):
            continue
        inv = ctrl.get("inventory") if isinstance(ctrl.get("inventory"), dict) else {}
        defn = ctrl.get("definition") if isinstance(ctrl.get("definition"), dict) else {}
        det = ctrl.get("details") if isinstance(ctrl.get("details"), dict) else {}
        nm = (
            inv.get("controlDefinitionName")
            or defn.get("controlDefinitionName")
            or det.get("control_name")
            or inv.get("controlDefinitionNumber")
        )
        hw = det.get("control_how") or inv.get("controlHow") or defn.get("controlHow")
        wh = det.get("control_what") or inv.get("controlWhat") or defn.get("controlWhat")
        wy = det.get("control_why") or inv.get("controlWhy") or defn.get("controlWhy")
        for bucket, val in ((c_names, nm), (c_how, hw), (c_what, wh), (c_why, wy)):
            if val and str(val).strip() and str(val).strip() not in bucket:
                bucket.append(str(val).strip())

    return {
        "review_id": str(ov.get("review_id") or plan_number),
        "region": str(ov.get("region") or plan_det.get("AU Region") or plan_det.get("UoT Regions") or "").strip(),
        "au_countries": ov.get("au_countries") if "au_countries" in ov else _split_list(plan_det.get("UoT Countries")),
        "plan_item_title": str(ov.get("plan_item_title") or plan_det.get("Plan Item Title") or "").strip(),
        "plan_item_description": str(ov.get("plan_item_description") or plan_det.get("Description of Plan Item") or "").strip(),
        "au_list": ov.get("au_list") if "au_list" in ov else au_list,
        "rt_list": ov.get("rt_list") if "rt_list" in ov else rt_list,
        "kc_list": ov.get("kc_list") if "kc_list" in ov else kc_list,
        "control_name": ov.get("control_name") if "control_name" in ov else c_names,
        "control_how": ov.get("control_how") if "control_how" in ov else c_how,
        "control_what": ov.get("control_what") if "control_what" in ov else c_what,
        "control_why": ov.get("control_why") if "control_why" in ov else c_why,
        "documents": documents_spec,
    }


def _normalize_rag_section_list(raw_sections: Any, prefix: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if not isinstance(raw_sections, list):
        return out
    for idx, sec in enumerate(raw_sections, start=1):
        if isinstance(sec, str):
            text = sec.strip()
            if not text:
                continue
            out.append(
                {
                    "section_id": str(idx),
                    "section_title": text.splitlines()[0][:80],
                    "node_id": f"{prefix}:sec:{idx}",
                    "original_text": text[:800],
                    "status": "active",
                    "excluded": False,
                }
            )
        elif isinstance(sec, dict):
            sid = str(sec.get("section_id") or sec.get("id") or idx)
            stitle = str(
                sec.get("section_title")
                or sec.get("title")
                or sec.get("heading")
                or (sec.get("section_path") or "").split(">")[-1]
                or f"Section {sid}"
            ).strip()
            body = str(sec.get("original_text") or sec.get("content") or sec.get("text") or sec.get("chunk_text") or stitle).strip()
            item: Dict[str, Any] = {
                "section_id": sid,
                "section_title": stitle,
                "node_id": str(sec.get("node_id") or f"{prefix}:sec:{sid}"),
                "original_text": body[:800],
                "status": "active",
                "excluded": False,
            }
            if sec.get("section_path"):
                item["section_path"] = sec["section_path"]
            if sec.get("page_start") is not None:
                item["page_start"] = sec["page_start"]
            out.append(item)
    return out


def _extract_sections_from_rag_relevant_data(rag_resp: Any) -> Dict[str, List[Dict[str, Any]]]:
    """Extract normalized section lists keyed by doc_id (`str(id)`) or `document_type`."""
    by_key: Dict[str, List[Dict[str, Any]]] = {}
    if not isinstance(rag_resp, (dict, list)):
        return by_key

    items: List[Tuple[Optional[str], Dict[str, Any]]] = []
    if isinstance(rag_resp, list):
        items.extend((None, x) for x in rag_resp if isinstance(x, dict))
    else:
        for container_key in ("results", "documents", "relevant_documents", "referenced_documents"):
            val = rag_resp.get(container_key)
            if isinstance(val, list):
                items.extend((None, x) for x in val if isinstance(x, dict))
            elif isinstance(val, dict):
                for dtype, sub in val.items():
                    if isinstance(sub, list):
                        items.extend((_normalize_doc_type(dtype), x) for x in sub if isinstance(x, dict))
        for dtype in ("policy", "kod", "procedure"):
            if isinstance(rag_resp.get(dtype), list):
                items.extend((dtype, x) for x in rag_resp[dtype] if isinstance(x, dict))

    for hinted_type, entry in items:
        nested_docs = entry.get("referenced_documents") or entry.get("documents")
        if isinstance(nested_docs, list):
            for sub in nested_docs:
                if isinstance(sub, dict):
                    items.append((hinted_type or entry.get("document_type"), sub))
        raw_id = entry.get("document_id") if entry.get("document_id") is not None else entry.get("id")
        dtype = _normalize_doc_type(entry.get("document_type") or hinted_type or "policy")
        key_id = str(raw_id).strip() if raw_id is not None else None
        raw_secs = (
            entry.get("sections")
            or entry.get("relevant_sections")
            or entry.get("chunks")
            or entry.get("paragraphs")
        )
        prefix = f"rag-{key_id}" if key_id else f"rag-{dtype}"
        norm_secs = _normalize_rag_section_list(raw_secs, prefix=prefix)
        if not norm_secs and (entry.get("content") or entry.get("text") or entry.get("section_title")):
            norm_secs = _normalize_rag_section_list([entry], prefix=prefix)
        if norm_secs:
            if key_id:
                by_key.setdefault(key_id, []).extend(norm_secs)
            by_key.setdefault(dtype, []).extend(norm_secs)
    return by_key


async def _fetch_plan_context_artifacts(
    client: httpx.AsyncClient,
    plan_number: str,
    scope: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Fetch `current_details` + `control_details` live from CT1 for RAG query context."""
    cur_res, ctrl_res = await asyncio.gather(
        _fetch_artifact_safe(client, plan_number, "current_details", scope),
        _fetch_artifact_safe(client, plan_number, "control_details", scope),
    )
    artifacts: Dict[str, Any] = {}
    if cur_res.get("ok"):
        artifacts["current_details"] = cur_res["data"]
    if ctrl_res.get("ok"):
        artifacts["control_details"] = ctrl_res["data"]
    return artifacts


def _build_uploaded_doc_record(
    filename: str,
    content: bytes,
    doc_type: str,
    doc_id: Optional[Any] = None,
    rag_sections: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Build upload summary strictly from real RAG response data (zero fabricated IDs/sections/URIs)."""
    title = Path(filename).stem
    if filename.lower().endswith(".json"):
        try:
            parsed = json.loads(content.decode("utf-8"))
            if isinstance(parsed, dict):
                title = str(parsed.get("document_title") or parsed.get("title") or title)
        except Exception:
            pass

    sections = list(rag_sections or [])
    return {
        "document_id": doc_id,
        "document_title": title,
        "document_name": title,
        "document_type": doc_type,
        "file_name": filename,
        "storage_uri": "",
        "status": "active",
        "excluded": False,
        "sections": sections,
    }


async def _ingest_and_categorize_uploads(
    plan_number: str,
    explicit_doc_type: str,
    raw_uploads: List[Tuple[str, bytes, str, str]],
    scope: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Execute the 4-stage CT1 RAG pipeline (`/ingest-documents` -> `/ingest-jobs/{id}` ->
    `/categorize-document-ids` -> `/get-relevant-data-for-documents`) and surface any failures directly.
    """
    form_files = [
        (_RAG_FIELD_MAP.get(dtype, "policy_files"), (fname, content, ctype))
        for fname, content, ctype, dtype in raw_uploads
    ]
    scope_form = {
        key: str(value).strip()
        for key, value in (scope or {}).items()
        if key in ("review_scope_id", "process_instance_id", "task_id", "review_scope_stage", "user")
        and value not in (None, "")
        and str(value).strip()
    }
    job_id = ""
    doc_ids: List[int] = []
    cat_map: Dict[int, str] = {}
    rag_sections_by_key: Dict[str, List[Dict[str, Any]]] = {}

    ingest_url = f"{RAG_SERVICE_BASE}/ingest-documents"
    async with create_async_client() as client:
        try:
            resp = await client.post(
                ingest_url,
                files=form_files,
                data=scope_form or None,
                timeout=REQUEST_TIMEOUT_SECONDS,
            )
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation="rag_ingest_documents",
                url=ingest_url,
                message=f"CT1 RAG /ingest-documents unreachable ({type(exc).__name__}): {exc}",
                extra={"exception_type": type(exc).__name__, "plan_number": plan_number},
            )
        if resp.status_code >= 400:
            _raise_upstream_http_error(
                resp.status_code,
                operation="rag_ingest_documents",
                url=ingest_url,
                message=f"CT1 RAG /ingest-documents returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
                upstream_status=resp.status_code,
                upstream_body=_extract_error_payload(resp),
                extra={"plan_number": plan_number},
            )
        try:
            ingest_data = resp.json()
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation="rag_ingest_documents",
                url=ingest_url,
                message=f"Invalid JSON from CT1 RAG /ingest-documents: {exc}",
                upstream_status=resp.status_code,
                upstream_body=resp.text[:4000],
            )
        if not isinstance(ingest_data, dict):
            ingest_data = {}
        job_id = str(ingest_data.get("job_id") or ingest_data.get("jobId") or ingest_data.get("id") or "").strip()
        doc_ids = _extract_rag_doc_ids(ingest_data)

        # Stage 2: Poll job status if job_id returned without document_ids
        if job_id and not doc_ids:
            job_url = f"{RAG_SERVICE_BASE}/ingest-jobs/{job_id}"
            for attempt in range(10):
                try:
                    j_resp = await client.get(job_url)
                except Exception as poll_exc:
                    _raise_upstream_http_error(
                        502,
                        operation="rag_ingest_job_poll",
                        url=job_url,
                        message=f"CT1 RAG job status request failed ({type(poll_exc).__name__}): {poll_exc}",
                        extra={"job_id": job_id, "exception_type": type(poll_exc).__name__},
                    )
                if j_resp.status_code >= 400:
                    _raise_upstream_http_error(
                        j_resp.status_code,
                        operation="rag_ingest_job_poll",
                        url=job_url,
                        message=f"CT1 RAG /ingest-jobs/{job_id} returned HTTP {j_resp.status_code}: {_extract_error_detail(j_resp)}",
                        upstream_status=j_resp.status_code,
                        upstream_body=_extract_error_payload(j_resp),
                        extra={"job_id": job_id},
                    )
                j_data = j_resp.json()
                j_status = str((j_data or {}).get("status") or "").strip().lower()
                if j_status in ("failed", "error"):
                    _raise_upstream_http_error(
                        502,
                        operation="rag_ingest_job_poll",
                        url=job_url,
                        message=f"CT1 RAG ingest job '{job_id}' failed: {(j_data or {}).get('error') or (j_data or {}).get('message') or j_status}",
                        upstream_status=j_resp.status_code,
                        upstream_body=j_data,
                        extra={"job_id": job_id},
                    )
                doc_ids = _extract_rag_doc_ids(j_data)
                if doc_ids or j_status in ("completed", "done", "success", "succeeded"):
                    break
                if attempt < 9:
                    await asyncio.sleep(0.5)

        # Stage 3: Auto-categorize returned document IDs
        if doc_ids:
            cat_url = f"{RAG_SERVICE_BASE}/categorize-document-ids"
            try:
                cat_resp = await client.post(cat_url, json={"document_ids": doc_ids}, timeout=REQUEST_TIMEOUT_SECONDS)
            except Exception as cat_exc:
                _raise_upstream_http_error(
                    502,
                    operation="rag_categorize_document_ids",
                    url=cat_url,
                    message=f"CT1 RAG /categorize-document-ids failed ({type(cat_exc).__name__}): {cat_exc}",
                    extra={"document_ids": doc_ids, "exception_type": type(cat_exc).__name__},
                )
            if cat_resp.status_code >= 400:
                _raise_upstream_http_error(
                    cat_resp.status_code,
                    operation="rag_categorize_document_ids",
                    url=cat_url,
                    message=f"CT1 RAG /categorize-document-ids returned HTTP {cat_resp.status_code}: {_extract_error_detail(cat_resp)}",
                    upstream_status=cat_resp.status_code,
                    upstream_body=_extract_error_payload(cat_resp),
                    extra={"document_ids": doc_ids},
                )
            cat_map = _parse_categorize_response(cat_resp.json())

        # Stage 4: Retrieve relevant sections/chunks for plan context
        explicit_lower = str(explicit_doc_type or "auto").strip().lower()
        if doc_ids:
            grouped_ids: Dict[str, List[int]] = {}
            for idx, did in enumerate(doc_ids):
                base_t = raw_uploads[idx][3] if idx < len(raw_uploads) else raw_uploads[0][3]
                resolved_t = cat_map.get(did, base_t) if explicit_lower in ("", "auto") else base_t
                grouped_ids.setdefault(resolved_t, []).append(did)
            docs_spec = [
                {"document_type": dtype, "document_ids": ids, "top_k": 5}
                for dtype, ids in grouped_ids.items()
            ]
            rel_url = f"{RAG_SERVICE_BASE}/get-relevant-data-for-documents"
            ctx_artifacts = await _fetch_plan_context_artifacts(client, plan_number, scope)
            rel_payload = _build_rag_relevant_payload_from_artifacts(plan_number, ctx_artifacts, docs_spec)
            try:
                rel_resp = await client.post(rel_url, json=rel_payload, timeout=REQUEST_TIMEOUT_SECONDS)
            except Exception as rel_exc:
                _raise_upstream_http_error(
                    502,
                    operation="rag_get_relevant_data",
                    url=rel_url,
                    message=f"CT1 RAG /get-relevant-data-for-documents failed ({type(rel_exc).__name__}): {rel_exc}",
                    extra={"document_ids": doc_ids, "exception_type": type(rel_exc).__name__},
                )
            if rel_resp.status_code >= 400:
                _raise_upstream_http_error(
                    rel_resp.status_code,
                    operation="rag_get_relevant_data",
                    url=rel_url,
                    message=f"CT1 RAG /get-relevant-data-for-documents returned HTTP {rel_resp.status_code}: {_extract_error_detail(rel_resp)}",
                    upstream_status=rel_resp.status_code,
                    upstream_body=_extract_error_payload(rel_resp),
                    extra={"document_ids": doc_ids},
                )
            rag_sections_by_key = _extract_sections_from_rag_relevant_data(rel_resp.json())

    explicit_lower = str(explicit_doc_type or "auto").strip().lower()
    created_records: List[Dict[str, Any]] = []
    categorized_summary: Dict[str, List[str]] = {}
    for idx, (fname, content, _, init_dtype) in enumerate(raw_uploads):
        assigned_id: Optional[int] = doc_ids[idx] if idx < len(doc_ids) else None
        if explicit_lower in ("", "auto") and assigned_id is not None and assigned_id in cat_map:
            final_dtype = cat_map[assigned_id]
        else:
            final_dtype = init_dtype

        custom_secs = None
        if assigned_id is not None:
            custom_secs = rag_sections_by_key.get(str(assigned_id))
        if not custom_secs:
            custom_secs = rag_sections_by_key.get(final_dtype)

        record = _build_uploaded_doc_record(
            filename=fname,
            content=content,
            doc_type=final_dtype,
            doc_id=assigned_id,
            rag_sections=custom_secs,
        )
        created_records.append(record)
        categorized_summary.setdefault(final_dtype, []).append(record["document_title"])

    primary_dtype = created_records[0]["document_type"] if created_records else "policy"
    total_sections = sum(len(r.get("sections") or []) for r in created_records)
    cat_desc = ", ".join(f"{k}: {', '.join(v)}" for k, v in categorized_summary.items())

    return {
        "status": "ingested",
        "rag_mode": "ct1_rag_service",
        "job_id": job_id,
        "plan_number": plan_number,
        "document_type": primary_dtype,
        "stored_in_artifact": "policy",
        "document_ids": doc_ids,
        "categorized": categorized_summary,
        "files_uploaded": [r["file_name"] for r in created_records],
        "documents": [
            {
                "document_id": r["document_id"],
                "document_title": r["document_title"],
                "document_type": r["document_type"],
                "file_name": r["file_name"],
                "storage_uri": r["storage_uri"],
                "section_count": len(r.get("sections") or []),
                "sections": r.get("sections") or [],
            }
            for r in created_records
        ],
        "message": (
            f"Ingested via CT1 RAG ({cat_desc}) with {total_sections} relevant section(s). "
            f"Returned document_ids={doc_ids}."
        ),
    }


async def _handle_upload_ingest(
    plan_number: str,
    document_type: str,
    files: List[UploadFile],
    policy_files: List[UploadFile],
    kod_files: List[UploadFile],
    procedure_files: List[UploadFile],
    scope: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    raw_uploads: List[Tuple[str, bytes, str, str]] = []
    for typed_group, upload_list in (
        ("policy", policy_files),
        ("kod", kod_files),
        ("procedure", procedure_files),
    ):
        for upload in upload_list:
            content = await upload.read()
            fname = upload.filename or f"{typed_group}.pdf"
            ctype = upload.content_type or "application/pdf"
            raw_uploads.append((fname, content, ctype, typed_group))

    for upload in files:
        content = await upload.read()
        fname = upload.filename or "document.pdf"
        ctype = upload.content_type or "application/pdf"
        inferred = _infer_doc_type_from_filename(fname, document_type)
        raw_uploads.append((fname, content, ctype, inferred))

    if not raw_uploads:
        raise HTTPException(status_code=400, detail="At least one file is required.")

    return await _ingest_and_categorize_uploads(plan_number, document_type, raw_uploads, scope)


@app.post("/api/ct1/query/ingest")
async def proxy_query_ingest(
    plan_number: str = Form(DEFAULT_PLAN_NUMBER),
    document_type: str = Form("auto"),
    review_scope_id: Optional[str] = Form(None),
    process_instance_id: Optional[str] = Form(None),
    task_id: Optional[str] = Form(None),
    review_scope_stage: Optional[str] = Form(None),
    user: Optional[str] = Form(None),
    files: List[UploadFile] = File(default=[]),
    policy_files: List[UploadFile] = File(default=[]),
    kod_files: List[UploadFile] = File(default=[]),
    procedure_files: List[UploadFile] = File(default=[]),
) -> Dict[str, Any]:
    """Ingest uploaded documents via CT1 `/dbaware-rag-service-api-dev/ingest-documents` workflow."""
    scope = {
        "review_scope_id": review_scope_id,
        "process_instance_id": process_instance_id,
        "task_id": task_id,
        "review_scope_stage": review_scope_stage,
        "user": user,
    }
    return await _handle_upload_ingest(
        plan_number, document_type, files, policy_files, kod_files, procedure_files, scope
    )


@app.post("/api/ct1/rag/ingest-documents")
async def proxy_rag_ingest_documents(
    plan_number: str = Form(DEFAULT_PLAN_NUMBER),
    document_type: str = Form("auto"),
    review_scope_id: Optional[str] = Form(None),
    process_instance_id: Optional[str] = Form(None),
    task_id: Optional[str] = Form(None),
    review_scope_stage: Optional[str] = Form(None),
    user: Optional[str] = Form(None),
    files: List[UploadFile] = File(default=[]),
    policy_files: List[UploadFile] = File(default=[]),
    kod_files: List[UploadFile] = File(default=[]),
    procedure_files: List[UploadFile] = File(default=[]),
) -> Dict[str, Any]:
    """Direct alias for CT1 `/dbaware-rag-service-api-dev/ingest-documents` workflow."""
    scope = {
        "review_scope_id": review_scope_id,
        "process_instance_id": process_instance_id,
        "task_id": task_id,
        "review_scope_stage": review_scope_stage,
        "user": user,
    }
    return await _handle_upload_ingest(
        plan_number, document_type, files, policy_files, kod_files, procedure_files, scope
    )


@app.get("/api/ct1/rag/ingest-jobs/{job_id}")
async def proxy_rag_job_status(job_id: str) -> Dict[str, Any]:
    """Check RAG ingestion job status via CT1 `/dbaware-rag-service-api-dev/ingest-jobs/{job_id}`."""
    url = f"{RAG_SERVICE_BASE}/ingest-jobs/{job_id}"
    async with create_async_client() as client:
        data = await _forward_json(client, "GET", url, operation="rag_ingest_job_status")
    if isinstance(data, dict):
        data.setdefault("job_id", job_id)
    return data


@app.post("/api/ct1/rag/categorize-document-ids")
async def proxy_rag_categorize_ids(payload: CategorizeIdsRequest) -> Dict[str, Any]:
    """Categorize RAG document IDs via CT1 `/dbaware-rag-service-api-dev/categorize-document-ids`."""
    url = f"{RAG_SERVICE_BASE}/categorize-document-ids"
    async with create_async_client() as client:
        return await _forward_json(
            client,
            "POST",
            url,
            json_body={"document_ids": payload.document_ids},
            operation="rag_categorize_document_ids",
        )


@app.post("/api/ct1/rag/get-relevant-data-for-documents")
async def proxy_rag_relevant_data(payload: RagRelevantDataRequest) -> Dict[str, Any]:
    """Fetch relevant sections via CT1 `/dbaware-rag-service-api-dev/get-relevant-data-for-documents`."""
    plan_num = str(payload.review_id or payload.plan_number or DEFAULT_PLAN_NUMBER).strip()
    url = f"{RAG_SERVICE_BASE}/get-relevant-data-for-documents"
    async with create_async_client() as client:
        ctx_artifacts = await _fetch_plan_context_artifacts(client, plan_num)
        overrides = payload.model_dump(exclude={"plan_number", "documents"}, exclude_none=True)
        body = _build_rag_relevant_payload_from_artifacts(plan_num, ctx_artifacts, payload.documents, overrides=overrides)
        return await _forward_json(client, "POST", url, json_body=body, operation="rag_get_relevant_data")


async def _call_summary_agent_post(
    *,
    path: str,
    body: Dict[str, Any],
    operation: str,
    timeout: float,
    allow_404: bool = False,
) -> Tuple[int, Any, str]:
    """Call CT1 `/scoping-summary-agent/...` directly with zero fallback."""
    url = f"{SUMMARY_AGENT_BASE}{path}"
    req_timeout = httpx.Timeout(timeout, connect=30.0, read=timeout, write=60.0, pool=30.0)
    async with create_async_client() as client:
        try:
            resp = await client.post(url, json=body, timeout=req_timeout)
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation=operation,
                url=url,
                message=f"Summary Agent unreachable ({type(exc).__name__}): {exc}",
                extra={"exception_type": type(exc).__name__},
            )

    if resp.status_code == 200:
        try:
            return 200, resp.json(), url
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation=operation,
                url=url,
                message=f"Invalid JSON from Summary Agent ({url}): {exc}",
                upstream_status=200,
                upstream_body=resp.text[:4000] if getattr(resp, "text", None) else "",
            )

    if allow_404 and resp.status_code == 404:
        return 404, _extract_error_payload(resp), url

    _raise_upstream_http_error(
        resp.status_code,
        operation=operation,
        url=url,
        message=f"Summary Agent returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
        upstream_status=resp.status_code,
        upstream_body=_extract_error_payload(resp),
    )


@app.get("/api/ct1/preliminary-research/health")
async def proxy_pr_health() -> Dict[str, Any]:
    """Check health of CT1 scoping-summary-agent."""
    url = f"{SUMMARY_AGENT_BASE}/health"
    async with create_async_client() as client:
        try:
            resp = await client.get(url)
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation="pr_health",
                url=url,
                message=f"Summary Agent unreachable ({type(exc).__name__}): {exc}",
            )
    if resp.status_code >= 400:
        _raise_upstream_http_error(
            resp.status_code,
            operation="pr_health",
            url=url,
            message=f"CT1 returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
            upstream_status=resp.status_code,
            upstream_body=_extract_error_payload(resp),
        )
    return {"status": "ok", "summary_agent_base": SUMMARY_AGENT_BASE, "upstream": resp.json()}


async def _handle_get_preliminary_research(plan_number: str) -> Dict[str, Any]:
    plan_num = str(plan_number or "").strip() or DEFAULT_PLAN_NUMBER
    status, raw, used_url = await _call_summary_agent_post(
        path="/get-preliminary-research-document",
        body={"planNumber": plan_num},
        operation="pr_get",
        timeout=REQUEST_TIMEOUT_SECONDS,
        allow_404=True,
    )
    if status == 404:
        return {
            "available": False,
            "status_code": 404,
            "plan_number": plan_num,
            "analysis_report": None,
            "source": "summary_agent",
            "message": "Preliminary Research document has not been generated for this plan yet.",
        }

    unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
    if not unwrapped:
        _raise_upstream_http_error(
            502,
            operation="pr_get",
            url=used_url,
            message="Preliminary Research response did not include analysis_report.",
            upstream_status=200,
            upstream_body=raw,
        )
    return {
        "available": True,
        "status_code": 200,
        "plan_number": unwrapped["plan_number"],
        "analysis_report": unwrapped["analysis_report"],
        "source": "summary_agent",
    }


@app.get("/api/ct1/preliminary-research/{plan_number}")
async def proxy_get_preliminary_research_get(plan_number: str) -> Dict[str, Any]:
    """Fetch stored Preliminary Research document from CT1 scoping-summary-agent."""
    return await _handle_get_preliminary_research(plan_number)


@app.post("/api/ct1/preliminary-research/get")
async def proxy_get_preliminary_research_post(payload: PreliminaryResearchGetRequest) -> Dict[str, Any]:
    """Fetch stored Preliminary Research document from CT1 scoping-summary-agent."""
    return await _handle_get_preliminary_research(payload.planNumber)


def _pr_report_has_content(analysis_report: Any) -> bool:
    if not isinstance(analysis_report, dict) or not analysis_report:
        return False
    for sec in analysis_report.values():
        if not isinstance(sec, dict):
            continue
        if isinstance(sec.get("paragraphs"), list) and sec["paragraphs"]:
            return True
        if isinstance(sec.get("historical_reviews"), list) and sec["historical_reviews"]:
            return True
    return False


async def _poll_preliminary_research_after_proxy_drop(
    *,
    plan_num: str,
    started: float,
    initial_exc: HTTPException,
) -> Tuple[Any, str]:
    """
    When GKE/proxy drops a long-running `/run-analytics-agent` connection after
    >= PR_PROXY_DROP_RETRY_AFTER_SECONDS, poll `/get-preliminary-research-document`
    until the background job writes to GCS or PRELIMINARY_RESEARCH_TIMEOUT_SECONDS elapses.
    """
    deadline = started + PRELIMINARY_RESEARCH_TIMEOUT_SECONDS
    while time.perf_counter() < deadline:
        try:
            status, raw, used_url = await _call_summary_agent_post(
                path="/get-preliminary-research-document",
                body={"planNumber": plan_num},
                operation="pr_generate_poll",
                timeout=REQUEST_TIMEOUT_SECONDS,
                allow_404=True,
            )
            if status == 200:
                unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
                if unwrapped and _pr_report_has_content(unwrapped.get("analysis_report")):
                    return raw, used_url
        except HTTPException:
            pass
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            break
        await asyncio.sleep(min(PR_POLL_INTERVAL_SECONDS, remaining))
    raise initial_exc


@app.post("/api/ct1/preliminary-research/generate")
async def proxy_generate_preliminary_research(payload: PreliminaryResearchGenerateRequest) -> Dict[str, Any]:
    """Trigger full or section-scoped Preliminary Research generation directly on CT1 scoping-summary-agent."""
    started = time.perf_counter()
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    cleaned_sections: Optional[List[str]] = None
    if payload.sections is not None:
        cleaned_sections = [str(s).strip() for s in payload.sections if str(s).strip()]
        invalid = [s for s in cleaned_sections if s not in _VALID_PR_SECTION_KEYS]
        if invalid:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid preliminary research section(s): {invalid}. Valid keys: {sorted(_VALID_PR_SECTION_KEYS)}",
            )
        if not cleaned_sections:
            cleaned_sections = None

    summary_user = _normalize_summary_user_details(payload.userDetails)
    direct_body: Dict[str, Any] = {
        "planNumber": plan_num,
        "userDetails": summary_user,
    }
    if cleaned_sections:
        direct_body["sections"] = cleaned_sections

    try:
        _, raw, used_url = await _call_summary_agent_post(
            path="/run-analytics-agent",
            body=direct_body,
            operation="pr_generate",
            timeout=PRELIMINARY_RESEARCH_TIMEOUT_SECONDS,
        )
    except HTTPException as exc:
        elapsed = time.perf_counter() - started
        detail_obj = exc.detail if isinstance(exc.detail, dict) else {}
        upstream_st = detail_obj.get("upstream_status")
        is_long_proxy_drop = elapsed >= PR_PROXY_DROP_RETRY_AFTER_SECONDS and (
            exc.status_code in (502, 504) or upstream_st in (502, 504)
        )
        if not is_long_proxy_drop:
            raise
        logger.warning(
            "run-analytics-agent dropped after %.1fs (status=%s); polling /get-preliminary-research-document for plan %s",
            elapsed,
            upstream_st or exc.status_code,
            plan_num,
        )
        raw, used_url = await _poll_preliminary_research_after_proxy_drop(
            plan_num=plan_num,
            started=started,
            initial_exc=exc,
        )

    unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
    if not unwrapped:
        _raise_upstream_http_error(
            502,
            operation="pr_generate",
            url=used_url,
            message="Preliminary Research generation response missing analysis_report.",
            upstream_status=200,
            upstream_body=raw,
        )

    return {
        "available": True,
        "plan_number": unwrapped["plan_number"],
        "analysis_report": unwrapped["analysis_report"],
        "sections_requested": cleaned_sections or [item["key"] for item in PR_SECTIONS],
        "source": "summary_agent",
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
    }


@app.post("/api/ct1/preliminary-research/edit")
async def proxy_edit_preliminary_research(payload: PreliminaryResearchEditRequest) -> Dict[str, Any]:
    """Persist edited Preliminary Research sections directly to CT1 scoping-summary-agent."""
    started = time.perf_counter()
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    summary_user = _normalize_summary_user_details(payload.userDetails)
    direct_body = {
        "planNumber": plan_num,
        "userDetails": summary_user,
        "analysis_report": payload.analysis_report,
    }
    _, raw, used_url = await _call_summary_agent_post(
        path="/edit-preliminary-research-document",
        body=direct_body,
        operation="pr_edit",
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    unwrapped = _unwrap_preliminary_research_response(plan_num, raw)
    if not unwrapped:
        _raise_upstream_http_error(
            502,
            operation="pr_edit",
            url=used_url,
            message="Preliminary Research edit response missing analysis_report.",
            upstream_status=200,
            upstream_body=raw,
        )
    return {
        "plan_number": unwrapped["plan_number"],
        "analysis_report": unwrapped["analysis_report"],
        "source": "summary_agent",
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
    }


@app.post("/api/ct1/preliminary-research/document")
async def proxy_pr_get_document(payload: PreliminaryResearchDocumentRequest) -> Dict[str, Any]:
    """Fetch a cited PDF/JSON document by chunk_id or gs:// URI directly from CT1 scoping-summary-agent."""
    chunk_id = (payload.chunk_id or "").strip() or None
    doc_uri = (payload.document_uri or "").strip() or None
    if not chunk_id and not doc_uri:
        raise HTTPException(status_code=400, detail="Either chunk_id or document_uri is required.")
    if chunk_id and not doc_uri and not (payload.planNumber or "").strip():
        raise HTTPException(status_code=400, detail="planNumber is required when fetching by chunk_id.")

    direct_body: Dict[str, Any] = {}
    if payload.planNumber:
        direct_body["planNumber"] = str(payload.planNumber).strip()
    if chunk_id:
        direct_body["chunk_id"] = chunk_id
    if doc_uri:
        direct_body["document_uri"] = doc_uri
    if payload.page_number is not None and payload.page_number >= 1:
        direct_body["pageNumber"] = int(payload.page_number)

    _, raw, _ = await _call_summary_agent_post(
        path="/get_document",
        body=direct_body,
        operation="pr_document",
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    if isinstance(raw, dict):
        result = dict(raw)
        result.setdefault("source_service", "summary_agent")
        return result
    return {"content": raw, "source_service": "summary_agent"}


@app.post("/api/ct1/preliminary-research/download")
async def proxy_download_preliminary_research(payload: PreliminaryResearchDownloadRequest) -> Response:
    """Download the Preliminary Research Walkthrough PDF directly from CT1 scoping-summary-agent."""
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    direct_body: Dict[str, Any] = {"planNumber": plan_num}
    if payload.planName:
        direct_body["planName"] = payload.planName

    url = f"{SUMMARY_AGENT_BASE}/download"
    async with create_async_client() as client:
        try:
            resp = await client.post(url, json=direct_body, timeout=REQUEST_TIMEOUT_SECONDS)
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation="pr_download",
                url=url,
                message=f"Summary Agent download unreachable ({type(exc).__name__}): {exc}",
                extra={"exception_type": type(exc).__name__, "plan_number": plan_num},
            )

    if resp.status_code == 200:
        disposition = (
            resp.headers.get("content-disposition")
            if hasattr(resp, "headers") and resp.headers
            else None
        ) or f'attachment; filename="Preliminary_Research_Report_{plan_num}.pdf"'
        pdf_bytes = getattr(resp, "content", None)
        if pdf_bytes is None:
            raw_text = getattr(resp, "text", "") or ""
            pdf_bytes = raw_text.encode("latin-1", errors="ignore")
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": disposition},
        )

    _raise_upstream_http_error(
        resp.status_code,
        operation="pr_download",
        url=url,
        message=f"Summary Agent download returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
        upstream_status=resp.status_code,
        upstream_body=_extract_error_payload(resp),
    )


@app.post("/api/ct1/preliminary-research/accept")
async def proxy_accept_preliminary_research(payload: PreliminaryResearchAcceptRequest) -> Dict[str, Any]:
    """Accept Preliminary Research via CT1 API Gateway HITL action."""
    plan_num = str(payload.planNumber or "").strip() or DEFAULT_PLAN_NUMBER
    url = f"{GATEWAY_BASE}/api/v1/actions"
    summary_user = _normalize_summary_user_details(payload.userDetails)
    gw_payload: Dict[str, Any] = {}
    if summary_user:
        gw_payload["user_details"] = summary_user
    body = {
        "planNumber": plan_num,
        "action": "ACCEPT_PRELIMINARY_RESEARCH",
        "payload": gw_payload,
    }
    post_kwargs: Dict[str, Any] = {"json": body, "timeout": REQUEST_TIMEOUT_SECONDS}
    if _gateway_headers():
        post_kwargs["headers"] = _gateway_headers()
    async with create_async_client() as client:
        try:
            resp = await client.post(url, **post_kwargs)
        except Exception as exc:
            _raise_upstream_http_error(
                502,
                operation="pr_accept",
                url=url,
                message=f"Gateway unreachable ({type(exc).__name__}): {exc}",
                extra={"exception_type": type(exc).__name__, "plan_number": plan_num},
            )
    if resp.status_code >= 400:
        _raise_upstream_http_error(
            resp.status_code,
            operation="pr_accept",
            url=url,
            message=f"CT1 accept returned HTTP {resp.status_code}: {_extract_error_detail(resp)}",
            upstream_status=resp.status_code,
            upstream_body=_extract_error_payload(resp),
        )
    try:
        data = resp.json()
    except Exception:
        data = {"status": "accepted", "raw": getattr(resp, "text", "")}
    return {"status": "accepted", "plan_number": plan_num, "response": data}


@app.get("/")
async def index() -> FileResponse:
    """Serve the demo UI single-page app."""
    return FileResponse(STATIC_DIR / "index.html")


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8095"))
    uvicorn.run(app, host="0.0.0.0", port=port)
