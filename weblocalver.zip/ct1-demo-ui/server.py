"""
CT1 Live Include/Exclude & Data Extraction Demo Server.

FastAPI proxy over CT1 endpoints:
  - Data Extraction Agent: /scoping-dataextraction-agent/{getdata/*, data-extraction*}
  - Query Service: /query-service/qna/{chat, documents/list-all, documents/ingest}
    (with Gateway / Master fallback and resilient local workflow fallback when
    query-service returns 503 no healthy upstream).
"""

from __future__ import annotations

import asyncio
import copy
import difflib
import json
import logging
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ct1-demo-ui")

CTA_HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com").rstrip("/")
DATAEXTRACTION_BASE = os.getenv(
    "DATAEXTRACTION_URL", f"{CTA_HOST}/scoping-dataextraction-agent"
).rstrip("/")
QUERY_SERVICE_BASE = os.getenv(
    "QUERY_SERVICE_URL", f"{CTA_HOST}/query-service"
).rstrip("/")
RAG_SERVICE_BASE = os.getenv(
    "RAG_SERVICE_URL", f"{CTA_HOST}/dbaware-rag-service-api-dev"
).rstrip("/")
DEFAULT_PLAN_NUMBER = os.getenv("DEFAULT_PLAN_NUMBER", "20440")
REQUEST_TIMEOUT_SECONDS = float(os.getenv("CT1_TIMEOUT_SECONDS", "60.0"))

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
SAMPLES_FILE = BASE_DIR / "CT1_ENDPOINTS_AND_JSON_SAMPLES.json"
LOCAL_REVIEW_ROOT = Path(os.getenv("LOCAL_REVIEW_ROOT", str(BASE_DIR.parent)))

PLAN_ARTIFACTS: List[Dict[str, str]] = [
    {"id": "policy", "label": "Policies / KOD / Proc", "excludable": "true"},
    {"id": "findings_details", "label": "GFMS Findings", "excludable": "true"},
    {"id": "historical_plan_details", "label": "Historical Plans", "excludable": "true"},
    {"id": "lrr", "label": "LRR Mandates", "excludable": "true"},
    {"id": "current_details", "label": "Current Plan", "excludable": "false"},
    {"id": "alc_nlac", "label": "ALC / NALC", "excludable": "false"},
    {"id": "control_details", "label": "Controls", "excludable": "false"},
    {"id": "risk_driver_details", "label": "Risk Drivers", "excludable": "false"},
    {"id": "group_audit", "label": "Group Audit", "excludable": "false"},
]

_TYPE_ALIASES: Dict[str, str] = {
    "policy": "policy",
    "policies": "policy",
    "kod": "kod",
    "kods": "kod",
    "procedure": "procedure",
    "procedures": "procedure",
    "procedure_documents": "procedure",
    "gfms": "gfms",
    "gfms_data": "gfms",
    "findings": "gfms",
    "findings_details": "gfms",
    "historical": "historical_scoping_document",
    "historical_plan": "historical_scoping_document",
    "historical_plan_details": "historical_scoping_document",
    "historical_scoping": "historical_scoping_document",
    "historical_scoping_document": "historical_scoping_document",
    "lrr": "lrr",
    "lrr_mandates": "lrr",
    "mandates": "lrr",
}

_AFFECTED_SECTIONS_MAP: Dict[str, Tuple[str, ...]] = {
    "policy": ("policy_regulation", "broad_scope"),
    "kod": ("policy_regulation", "broad_scope"),
    "procedure": ("policy_regulation", "broad_scope"),
    "gfms": ("broad_scope",),
    "historical_scoping_document": ("past_review", "broad_scope"),
    "lrr": ("policy_regulation", "broad_scope"),
}

_EXCLUDED_STATUSES = {"excluded", "removed", "deleted", "inactive"}

# Per-plan in-memory overlay so exclude / include / upload interactions work
# seamlessly even when upstream CT1 query-service returns 503.
_PLAN_STATE: Dict[str, Dict[str, Any]] = {}


class ChatProxyRequest(BaseModel):
    question: str
    plan_number: str
    context_type: str = "Preliminary Research Walkthrough"
    plan_name: Optional[str] = None
    research_sections: Optional[Any] = None
    userDetails: Optional[Dict[str, Any]] = None


class ExtractionRunRequest(BaseModel):
    planNumber: str
    userDetails: Optional[Dict[str, Any]] = None


def create_async_client() -> httpx.AsyncClient:
    """Create the async HTTP client used for live CT1 calls."""
    return httpx.AsyncClient(verify=False, timeout=REQUEST_TIMEOUT_SECONDS)


app = FastAPI(title="CT1 Scoping Query & Data Extraction Demo UI", version="1.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _get_plan_state(plan_number: str) -> Dict[str, Any]:
    key = str(plan_number).strip()
    if key not in _PLAN_STATE:
        _PLAN_STATE[key] = {
            "excluded_docs": set(),       # normalized "{doc_type}|{key}"
            "excluded_sections": set(),   # normalized "{doc_type}|{sec_key}"
            "custom_sections": [],        # dynamically targeted sections not originally listed in chunks
            "uploaded_docs": [],          # list[dict]
            "pending_plan": None,
        }
    return _PLAN_STATE[key]


def _norm_key(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if text.lower().endswith(".pdf") or text.lower().endswith(".json"):
        text = text.rsplit(".", 1)[0]
    text = text.replace("_", " ").replace("-", " ")
    return re.sub(r"\s+", " ", text).strip().lower()


def _raw_norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def _normalize_doc_type(value: Any) -> str:
    cleaned = re.sub(r"[\s-]+", "_", str(value or "").strip().lower())
    return _TYPE_ALIASES.get(cleaned, cleaned or "policy")


def _extract_error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            return str(payload.get("detail") or payload.get("message") or payload)
        return str(payload)
    except Exception:
        return response.text[:500] or f"HTTP {response.status_code}"


async def _forward_json(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    json_body: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    response = await client.request(method, url, json=json_body)
    if response.status_code >= 400:
        raise HTTPException(
            status_code=response.status_code,
            detail=_extract_error_detail(response),
        )
    try:
        return response.json()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Invalid JSON from CT1 ({url}): {exc}") from exc


def _read_json_file(path: Path) -> Any:
    try:
        if path.exists() and path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.debug("Unable to read JSON file %s: %s", path, exc)
    return None


def _load_samples_for_plan(plan_number: str) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any]]:
    """Load captured CT1 sample payloads for offline resilience when CTA_HOST is unreachable."""
    sample_doc = _read_json_file(SAMPLES_FILE)
    if not isinstance(sample_doc, dict):
        return None, {}

    artifacts: Dict[str, Any] = {}
    availability: Optional[Dict[str, Any]] = None
    target = str(plan_number).strip()

    for call in sample_doc.get("calls") or []:
        if not isinstance(call, dict) or call.get("status_code") != 200:
            continue
        url = str(call.get("url") or "")
        resp = call.get("response_json")
        if not isinstance(resp, dict):
            continue
        if f"/getdata/{target}/availability" in url:
            availability = copy.deepcopy(resp)
            continue
        marker = f"/getdata/{target}/"
        if marker in url:
            aid = url.split(marker, 1)[1].split("?", 1)[0].strip("/")
            if aid:
                artifacts[aid] = copy.deepcopy(resp)
    return availability, artifacts


def _local_inbound_dir(plan_number: str) -> Optional[Path]:
    candidate = LOCAL_REVIEW_ROOT / f"dbaware_review_{plan_number}" / "inbound-data"
    return candidate if candidate.exists() and candidate.is_dir() else None


def _read_local_part_sections(part_payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    sections: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    for idx, node in enumerate(part_payload.get("nodes") or [], start=1):
        if not isinstance(node, dict):
            continue
        nid = str(node.get("node_id") or f"sec:{idx}")
        if nid in seen:
            continue
        seen.add(nid)
        sid = node.get("section_id") or idx
        stitle = str(node.get("section_title") or node.get("title") or f"Section {sid}").strip()
        sections.append(
            {
                "section_id": sid,
                "section_title": stitle,
                "node_id": nid,
                "page_start": node.get("page_start"),
                "page_end": node.get("page_end"),
                "section_path": node.get("section_path"),
                "status": "active",
                "excluded": False,
            }
        )
    return sections


def _load_local_policy_groups(inbound_dir: Path) -> Dict[str, List[Dict[str, Any]]]:
    """Read local inbound-data/policy files for section enrichment and fallback catalog."""
    by_type: Dict[str, List[Dict[str, Any]]] = {"policy": [], "kod": [], "procedure": []}
    policy_root = inbound_dir / "policy"
    if not policy_root.exists():
        return by_type

    for dtype in ("policy", "kod", "procedure"):
        seen_keys: Set[str] = set()
        part_dir = policy_root / f"relevant_{dtype}"
        if part_dir.exists() and part_dir.is_dir():
            for file_path in sorted(part_dir.glob("*.json")):
                payload = _read_json_file(file_path)
                if not isinstance(payload, dict):
                    continue
                doc_id = str(payload.get("document_id") or file_path.stem)
                title = str(payload.get("document_title") or payload.get("title") or file_path.stem).strip()
                uri = str(payload.get("storage_uri") or payload.get("gs_uri") or "").strip()
                sections = _read_local_part_sections(payload)
                seen_keys.add(_norm_key(title))
                seen_keys.add(_norm_key(uri))
                by_type[dtype].append(
                    {
                        "document_type": dtype,
                        "document_id": doc_id,
                        "document_title": title,
                        "document_name": title,
                        "file_name": file_path.name,
                        "storage_uri": uri,
                        "gs_uri": uri,
                        "status": "excluded" if payload.get("excluded") is True else str(payload.get("status") or "active"),
                        "excluded": bool(payload.get("excluded") is True),
                        "sections": sections,
                    }
                )

        agg_payload = _read_json_file(policy_root / f"relevant_{dtype}.json")
        raw_sources: List[Dict[str, Any]] = []
        if isinstance(agg_payload, dict):
            raw_sources = (
                agg_payload.get("sources")
                or agg_payload.get("documents")
                or agg_payload.get("referenced_documents")
                or []
            )
        elif isinstance(agg_payload, list):
            raw_sources = agg_payload

        grouped_sources: Dict[str, Dict[str, Any]] = {}
        for idx, src in enumerate(raw_sources, start=1):
            if not isinstance(src, dict):
                continue
            dname = str(src.get("document_name") or src.get("document_title") or src.get("title") or "").strip()
            uri = str(src.get("gs_uri") or src.get("storage_uri") or "").strip()
            nk = _norm_key(dname) or _norm_key(uri)
            if not nk or nk in seen_keys:
                continue
            if nk not in grouped_sources:
                grouped_sources[nk] = {
                    "document_type": dtype,
                    "document_id": str(src.get("document_id") or f"{dtype}_{idx}"),
                    "document_title": dname or uri.rsplit("/", 1)[-1],
                    "document_name": dname or uri.rsplit("/", 1)[-1],
                    "file_name": f"{dtype}_{idx}.json",
                    "storage_uri": uri,
                    "gs_uri": uri,
                    "status": "active",
                    "excluded": False,
                    "sections": [],
                }
            page_no = src.get("page_number")
            cls_label = src.get("classification") or ""
            sec_title = f"Page {page_no}" + (f" ({cls_label})" if cls_label else "") if page_no else (src.get("rationale") or f"Source {idx}")
            grouped_sources[nk]["sections"].append(
                {
                    "section_id": str(page_no or src.get("source_index") or idx),
                    "section_title": str(sec_title)[:90],
                    "node_id": f"{dtype}:{nk}:p{page_no or idx}",
                    "status": "active",
                    "excluded": False,
                }
            )
        by_type[dtype].extend(grouped_sources.values())

    return by_type


def _enrich_artifacts_from_local_inbound(
    plan_number: str, artifacts: Dict[str, Any]
) -> Dict[str, Any]:
    """Attach section details to policy refs and backfill empty CT1 LRR/Historical arrays if local fixtures exist."""
    inbound = _local_inbound_dir(plan_number)
    if inbound is None:
        return artifacts

    enriched = copy.deepcopy(artifacts)
    local_policy_groups = _load_local_policy_groups(inbound)

    # 1. Enrich policy.data.referenced_documents with matching part sections & active KOD/Procedure refs
    if "policy" in enriched and isinstance(enriched["policy"], dict):
        pol_env = enriched["policy"]
        pol_data = pol_env.get("data")
        if isinstance(pol_data, dict) and isinstance(pol_data.get("referenced_documents"), list):
            docs_by_norm: Dict[str, Dict[str, Any]] = {}
            for gtype, docs in local_policy_groups.items():
                for d in docs:
                    for candidate in (d.get("document_title"), d.get("gs_uri"), Path(str(d.get("gs_uri") or "")).name):
                        nk = _norm_key(candidate)
                        if nk:
                            docs_by_norm[nk] = d

            seen_ref_keys: Set[str] = set()
            merged_refs: List[Dict[str, Any]] = []
            for ref in pol_data["referenced_documents"]:
                if not isinstance(ref, dict):
                    continue
                ref_copy = dict(ref)
                ref_type = _normalize_doc_type(ref_copy.get("document_type") or "policy")
                ref_name = ref_copy.get("document_name") or ref_copy.get("document_title") or ""
                matched = (
                    docs_by_norm.get(_norm_key(ref_name))
                    or docs_by_norm.get(_norm_key(ref_copy.get("gs_uri")))
                )
                if matched and not ref_copy.get("sections"):
                    ref_copy["sections"] = copy.deepcopy(matched.get("sections") or [])
                if matched and not ref_copy.get("document_id"):
                    ref_copy["document_id"] = matched.get("document_id")
                merged_refs.append(ref_copy)
                seen_ref_keys.add(f"{ref_type}|{_norm_key(ref_name)}")

            for gtype in ("policy", "kod", "procedure"):
                for d in local_policy_groups.get(gtype, []):
                    nk = f"{gtype}|{_norm_key(d.get('document_title'))}"
                    if nk not in seen_ref_keys and not d.get("excluded"):
                        merged_refs.append(
                            {
                                "document_type": gtype,
                                "document_id": d.get("document_id"),
                                "document_name": d.get("document_title"),
                                "gs_uri": d.get("gs_uri"),
                                "file_name": d.get("file_name"),
                                "sections": copy.deepcopy(d.get("sections") or []),
                            }
                        )
                        seen_ref_keys.add(nk)

            pol_data["referenced_documents"] = merged_refs

    # 2. If CT1 LRR returns empty internet_search_data: [], backfill from local internet_search_data_enriched.json if present
    if "lrr" in enriched and isinstance(enriched["lrr"], dict):
        lrr_data = enriched["lrr"].get("data")
        if isinstance(lrr_data, dict):
            existing_lrr = lrr_data.get("internet_search_data_enriched") or lrr_data.get("internet_search_data")
            if not existing_lrr:
                local_enriched = _read_json_file(inbound / "lrr" / "internet_search_data_enriched.json")
                if isinstance(local_enriched, list) and local_enriched:
                    lrr_data["internet_search_data_enriched"] = local_enriched

    # 3. If CT1 historical_plan_details returns [], backfill from local historical_plan_details.json if present
    if "historical_plan_details" in enriched and isinstance(enriched["historical_plan_details"], dict):
        hist_data = enriched["historical_plan_details"].get("data")
        if isinstance(hist_data, dict) and not hist_data.get("historical_plan_details"):
            local_hist = _read_json_file(inbound / "dbaware" / "historical_plan_details.json")
            if isinstance(local_hist, list) and local_hist:
                hist_data["historical_plan_details"] = local_hist

    return enriched


def _unwrap_data_dict(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def _extract_gfms_docs(artifacts: Dict[str, Any]) -> List[Dict[str, Any]]:
    data = _unwrap_data_dict(artifacts.get("findings_details"))
    raw_list = data.get("findings_details") if isinstance(data, dict) else data
    if not isinstance(raw_list, list):
        return []
    docs: List[Dict[str, Any]] = []
    for w_idx, wrapper in enumerate(raw_list, start=1):
        items = wrapper.get("responsePayload") if isinstance(wrapper, dict) and isinstance(wrapper.get("responsePayload"), list) else [wrapper]
        for f_idx, f in enumerate(items or [], start=1):
            if not isinstance(f, dict):
                continue
            fid = str(f.get("findingId") or f.get("id") or f"{w_idx}-{f_idx}")
            raw_title = str(f.get("findingTitle") or f.get("title") or "").strip()
            ct_ref = str(f.get("ct1") or "").strip()
            area = str(f.get("subBusinessArea") or f.get("businessArea") or "").strip()
            label = raw_title if raw_title and set(raw_title) != {"X"} else (ct_ref or area or f"GFMS Finding {fid}")
            display = f"Finding {fid}: {label}"
            docs.append(
                {
                    "document_id": fid,
                    "document_title": display,
                    "file_name": "findings_details.json",
                    "status": "excluded" if f.get("excluded") is True else "active",
                    "excluded": bool(f.get("excluded") is True),
                    "sections": [
                        {
                            "section_id": fid,
                            "section_title": display,
                            "node_id": f"gfms:finding:{fid}",
                            "status": "active",
                            "excluded": False,
                        }
                    ],
                }
            )
    return docs


def _extract_historical_docs(artifacts: Dict[str, Any]) -> List[Dict[str, Any]]:
    data = _unwrap_data_dict(artifacts.get("historical_plan_details"))
    raw_list = data.get("historical_plan_details") if isinstance(data, dict) else data
    if not isinstance(raw_list, list):
        return []
    docs: List[Dict[str, Any]] = []
    for idx, item in enumerate(raw_list, start=1):
        if not isinstance(item, dict):
            continue
        pnum = str(item.get("Plan Item Number") or item.get("plan_item_number") or idx)
        ptitle = str(item.get("Plan Item Title") or item.get("title") or f"Historical Plan {pnum}").strip()
        docs.append(
            {
                "document_id": pnum,
                "document_title": f"Plan {pnum}: {ptitle}",
                "file_name": "historical_plan_details.json",
                "status": "excluded" if item.get("excluded") is True else "active",
                "excluded": bool(item.get("excluded") is True),
                "sections": [],
            }
        )
    return docs


def _extract_lrr_docs(artifacts: Dict[str, Any]) -> List[Dict[str, Any]]:
    data = _unwrap_data_dict(artifacts.get("lrr"))
    if isinstance(data, dict):
        raw_list = data.get("internet_search_data_enriched") or data.get("internet_search_data") or []
    elif isinstance(data, list):
        raw_list = data
    else:
        raw_list = []

    if not isinstance(raw_list, list) or not raw_list:
        return []

    mandate_sections: List[Dict[str, Any]] = []
    m_idx = 0
    for entry in raw_list:
        if not isinstance(entry, dict):
            continue
        risk_name = str(entry.get("Risk Name") or entry.get("risk_name") or "Regulatory Risk").strip()
        mandates = entry.get("Mandates")
        if isinstance(mandates, list):
            for m in mandates:
                if not isinstance(m, dict):
                    continue
                m_idx += 1
                raw_m = str(m.get("Regulatory Mandate") or m.get("mandate") or f"Mandate {m_idx}").strip()
                short_m = raw_m if len(raw_m) <= 85 else f"{raw_m[:82]}..."
                mandate_sections.append(
                    {
                        "section_id": m_idx,
                        "section_title": f"{risk_name}: {short_m}",
                        "node_id": str(m.get("node_id") or f"lrr:mandate:{m_idx}"),
                        "status": "excluded" if m.get("excluded") is True else "active",
                        "excluded": bool(m.get("excluded") is True),
                    }
                )
    return [
        {
            "document_id": "lrr_internet_search_data_enriched",
            "document_title": "Regulatory & Internet Search Mandates",
            "file_name": "internet_search_data_enriched.json",
            "status": "active",
            "excluded": False,
            "sections": mandate_sections,
        }
    ]


def _build_catalog_from_artifacts(
    plan_number: str, artifacts: Dict[str, Any]
) -> Dict[str, Any]:
    """Build the 6-group query-service catalog structure from CT1 artifacts when list-all is 503."""
    grouped: Dict[str, List[Dict[str, Any]]] = {
        "policy": [],
        "kod": [],
        "procedure": [],
        "gfms": _extract_gfms_docs(artifacts),
        "historical_scoping_document": _extract_historical_docs(artifacts),
        "lrr": _extract_lrr_docs(artifacts),
    }

    pol_data = _unwrap_data_dict(artifacts.get("policy"))
    refs = pol_data.get("referenced_documents") if isinstance(pol_data, dict) else []
    for idx, ref in enumerate(refs or [], start=1):
        if not isinstance(ref, dict):
            continue
        dtype = _normalize_doc_type(ref.get("document_type") or "policy")
        if dtype not in ("policy", "kod", "procedure"):
            dtype = "policy"
        title = str(ref.get("document_name") or ref.get("document_title") or f"{dtype}_{idx}").strip()
        grouped[dtype].append(
            {
                "document_id": str(ref.get("document_id") or f"{dtype}_{idx}"),
                "document_title": title,
                "file_name": ref.get("file_name") or f"{title}.json",
                "storage_uri": ref.get("gs_uri") or ref.get("storage_uri") or "",
                "status": "excluded" if ref.get("excluded") is True else str(ref.get("status") or "active"),
                "excluded": bool(ref.get("excluded") is True),
                "sections": copy.deepcopy(ref.get("sections") or []),
            }
        )

    document_groups = [
        {
            "document_type": dtype,
            "total_count": len(docs),
            "documents": docs,
            "source": "ct1_artifacts_fallback",
        }
        for dtype, docs in grouped.items()
    ]
    return {
        "plan_number": plan_number,
        "source": "ct1_artifacts_fallback",
        "total_count": sum(len(docs) for docs in grouped.values()),
        "document_groups": document_groups,
    }


def _match_set_contains(candidate_keys: Iterable[str], excluded_keys: Set[str], doc_type: str) -> bool:
    for key in candidate_keys:
        if not key:
            continue
        if f"{doc_type}|{key}" in excluded_keys or f"*|{key}" in excluded_keys:
            return True
    return False


def _is_section_excluded(
    dtype: str,
    doc_keys: Iterable[str],
    sec: Dict[str, Any],
    ex_secs: Set[str],
) -> bool:
    if not ex_secs:
        return False
    nid = _raw_norm(sec.get("node_id"))
    sid = _raw_norm(sec.get("section_id"))
    stitle = _norm_key(sec.get("section_title"))
    if nid and (f"{dtype}|{nid}" in ex_secs or f"*|{nid}" in ex_secs):
        return True
    for dk in doc_keys:
        if not dk:
            continue
        if sid and f"{dtype}|{dk}::id:{sid}" in ex_secs:
            return True
        if stitle and f"{dtype}|{dk}::title:{stitle}" in ex_secs:
            return True
    return _match_set_contains({sid, stitle} - {""}, ex_secs, dtype)


def _apply_plan_state_to_catalog(plan_number: str, catalog: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not isinstance(catalog, dict):
        return catalog
    st = _get_plan_state(plan_number)
    updated = copy.deepcopy(catalog)
    groups = updated.get("document_groups")
    if not isinstance(groups, list):
        return updated

    # Inject or refresh uploaded docs into matching groups
    groups_by_type = {str(g.get("document_type") or "").lower(): g for g in groups if isinstance(g, dict)}
    for up_doc in st["uploaded_docs"]:
        dtype = _normalize_doc_type(up_doc.get("document_type") or "policy")
        grp = groups_by_type.get(dtype)
        if grp is None:
            grp = {"document_type": dtype, "documents": [], "total_count": 0, "source": "uploaded"}
            groups.append(grp)
            groups_by_type[dtype] = grp
        up_key = _norm_key(up_doc.get("document_title"))
        grp["documents"] = [
            d for d in (grp.get("documents") or [])
            if _norm_key(d.get("document_title") or d.get("document_name")) != up_key
        ]
        grp["documents"].append(copy.deepcopy(up_doc))

    ex_docs: Set[str] = st["excluded_docs"]
    ex_secs: Set[str] = st["excluded_sections"]
    custom_secs: List[Dict[str, Any]] = st.get("custom_sections") or []

    total_docs = 0
    for grp in groups:
        if not isinstance(grp, dict):
            continue
        dtype = _normalize_doc_type(grp.get("document_type") or "policy")
        docs = grp.get("documents") or []
        for doc in docs:
            if not isinstance(doc, dict):
                continue
            dkeys = {
                _norm_key(doc.get("document_title")),
                _norm_key(doc.get("document_name")),
                _norm_key(doc.get("file_name")),
                _raw_norm(doc.get("document_id")),
            } - {""}
            if _match_set_contains(dkeys, ex_docs, dtype):
                doc["excluded"] = True
                doc["status"] = "excluded"
            secs = doc.setdefault("sections", [])
            existing_sids = {_raw_norm(s.get("section_id")) for s in secs if isinstance(s, dict) and s.get("section_id") is not None}
            for csec in custom_secs:
                if csec.get("document_type") == dtype and csec.get("doc_key") in dkeys:
                    csid = _raw_norm(csec.get("section_id"))
                    if csid and csid not in existing_sids:
                        secs.append(
                            {
                                "section_id": csec.get("section_id"),
                                "section_title": csec.get("section_title"),
                                "node_id": csec.get("node_id"),
                                "status": "active",
                                "excluded": False,
                            }
                        )
                        existing_sids.add(csid)
            for sec in secs:
                if not isinstance(sec, dict):
                    continue
                if doc.get("excluded") is True or _is_section_excluded(dtype, dkeys, sec, ex_secs):
                    sec["excluded"] = True
                    sec["status"] = "excluded"
        grp["total_count"] = len(docs)
        total_docs += len(docs)

    updated["total_count"] = total_docs
    return updated


def _apply_plan_state_to_artifacts(plan_number: str, artifacts: Dict[str, Any]) -> Dict[str, Any]:
    """Apply in-memory exclusions/inclusions/uploads onto Data Extraction /getdata payloads."""
    st = _get_plan_state(plan_number)
    ex_docs: Set[str] = st["excluded_docs"]
    ex_secs: Set[str] = st["excluded_sections"]
    uploaded: List[Dict[str, Any]] = st["uploaded_docs"]

    if not ex_docs and not ex_secs and not uploaded:
        return artifacts

    filtered = copy.deepcopy(artifacts)

    # 1. Policy / KOD / Procedure artifact
    if "policy" in filtered and isinstance(filtered["policy"], dict):
        pol_data = filtered["policy"].get("data")
        if isinstance(pol_data, dict) and isinstance(pol_data.get("referenced_documents"), list):
            next_refs: List[Dict[str, Any]] = []
            for ref in pol_data["referenced_documents"]:
                if not isinstance(ref, dict):
                    continue
                dtype = _normalize_doc_type(ref.get("document_type") or "policy")
                dkeys = {
                    _norm_key(ref.get("document_name")),
                    _norm_key(ref.get("document_title")),
                    _norm_key(ref.get("file_name")),
                    _raw_norm(ref.get("document_id")),
                } - {""}
                if _match_set_contains(dkeys, ex_docs, dtype):
                    continue
                if isinstance(ref.get("sections"), list) and ref["sections"]:
                    kept_secs = [
                        s for s in ref["sections"]
                        if isinstance(s, dict)
                        and not _is_section_excluded(dtype, dkeys, s, ex_secs)
                    ]
                    if not kept_secs:
                        continue
                    ref["sections"] = kept_secs
                next_refs.append(ref)

            for up in uploaded:
                up_type = _normalize_doc_type(up.get("document_type") or "policy")
                up_title_key = _norm_key(up.get("document_title"))
                up_keys = {up_title_key, _raw_norm(up.get("document_id"))} - {""}
                if up_type not in ("policy", "kod", "procedure") or _match_set_contains(up_keys, ex_docs, up_type):
                    continue
                kept_up_secs = [
                    copy.deepcopy(s)
                    for s in (up.get("sections") or [])
                    if isinstance(s, dict)
                    and not _is_section_excluded(up_type, up_keys, s, ex_secs)
                ]
                if (up.get("sections") or []) and not kept_up_secs:
                    continue
                next_refs = [
                    r for r in next_refs
                    if not (
                        _normalize_doc_type(r.get("document_type") or "policy") == up_type
                        and _norm_key(r.get("document_name") or r.get("document_title")) == up_title_key
                    )
                ]
                next_refs.append(
                    {
                        "document_type": up_type,
                        "document_id": up.get("document_id"),
                        "document_name": up.get("document_title"),
                        "gs_uri": up.get("storage_uri") or f"uploaded://{up_type}/{up.get('file_name')}",
                        "file_name": up.get("file_name"),
                        "sections": kept_up_secs,
                    }
                )
            pol_data["referenced_documents"] = next_refs

    # 2. GFMS findings_details
    if "findings_details" in filtered and isinstance(filtered["findings_details"], dict):
        f_data = filtered["findings_details"].get("data")
        if isinstance(f_data, dict) and isinstance(f_data.get("findings_details"), list):
            if f"gfms|{_norm_key('findings_details')}" in ex_docs or f"gfms|{_norm_key('findings_details.json')}" in ex_docs:
                f_data["findings_details"] = []
            else:
                next_wrappers = []
                for w in f_data["findings_details"]:
                    if not isinstance(w, dict) or not isinstance(w.get("responsePayload"), list):
                        next_wrappers.append(w)
                        continue
                    kept_f = []
                    for f in w["responsePayload"]:
                        if not isinstance(f, dict):
                            continue
                        fid = str(f.get("findingId") or f.get("id") or "").strip()
                        title_display = f"Finding {fid}: {f.get('ct1') or f.get('findingTitle') or ''}"
                        fkeys = {
                            _raw_norm(fid),
                            f"gfms:finding:{_raw_norm(fid)}",
                            _norm_key(f.get("findingTitle")),
                            _norm_key(title_display),
                        } - {""}
                        if _match_set_contains(fkeys, ex_docs, "gfms") or _match_set_contains(fkeys, ex_secs, "gfms"):
                            continue
                        kept_f.append(f)
                    if kept_f:
                        w_copy = dict(w)
                        w_copy["responsePayload"] = kept_f
                        next_wrappers.append(w_copy)
                f_data["findings_details"] = next_wrappers

    # 3. Historical plan details
    if "historical_plan_details" in filtered and isinstance(filtered["historical_plan_details"], dict):
        h_data = filtered["historical_plan_details"].get("data")
        if isinstance(h_data, dict) and isinstance(h_data.get("historical_plan_details"), list):
            h_data["historical_plan_details"] = [
                item
                for item in h_data["historical_plan_details"]
                if isinstance(item, dict)
                and not _match_set_contains(
                    {
                        _raw_norm(item.get("Plan Item Number")),
                        _norm_key(item.get("Plan Item Title")),
                        _norm_key(f"Plan {item.get('Plan Item Number')}: {item.get('Plan Item Title')}"),
                    }
                    - {""},
                    ex_docs | ex_secs,
                    "historical_scoping_document",
                )
            ]

    # 4. LRR mandates
    if "lrr" in filtered and isinstance(filtered["lrr"], dict):
        lrr_data = filtered["lrr"].get("data")
        if isinstance(lrr_data, dict):
            key_name = "internet_search_data_enriched" if lrr_data.get("internet_search_data_enriched") else "internet_search_data"
            entries = lrr_data.get(key_name)
            if isinstance(entries, list):
                if f"lrr|{_norm_key('Regulatory & Internet Search Mandates')}" in ex_docs:
                    lrr_data[key_name] = []
                else:
                    next_entries = []
                    m_idx = 0
                    for entry in entries:
                        if not isinstance(entry, dict) or not isinstance(entry.get("Mandates"), list):
                            next_entries.append(entry)
                            continue
                        risk_name = str(entry.get("Risk Name") or entry.get("risk_name") or "").strip()
                        kept_m = []
                        for m in entry["Mandates"]:
                            if not isinstance(m, dict):
                                continue
                            m_idx += 1
                            raw_m = str(m.get("Regulatory Mandate") or m.get("mandate") or "").strip()
                            short_m = raw_m if len(raw_m) <= 85 else f"{raw_m[:82]}..."
                            mkeys = {
                                _raw_norm(m_idx),
                                f"lrr:mandate:{m_idx}",
                                _norm_key(raw_m),
                                _norm_key(f"{risk_name}: {short_m}"),
                            } - {""}
                            if _match_set_contains(mkeys, ex_secs | ex_docs, "lrr"):
                                continue
                            kept_m.append(m)
                        if kept_m:
                            e_copy = dict(entry)
                            e_copy["Mandates"] = kept_m
                            next_entries.append(e_copy)
                    lrr_data[key_name] = next_entries

    return filtered


async def _fetch_artifact_safe(
    client: httpx.AsyncClient,
    plan_number: str,
    artifact_id: str,
) -> Dict[str, Any]:
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/{artifact_id}"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "data": resp.json()}
        return {"ok": False, "status_code": resp.status_code, "error": _extract_error_detail(resp), "data": None}
    except Exception as exc:
        return {"ok": False, "status_code": 502, "error": str(exc), "data": None}


async def _fetch_availability_safe(client: httpx.AsyncClient, plan_number: str) -> Dict[str, Any]:
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/availability"
    try:
        resp = await client.get(url)
        if resp.status_code == 200:
            return {"ok": True, "status_code": 200, "data": resp.json()}
        return {"ok": False, "status_code": resp.status_code, "error": _extract_error_detail(resp), "data": None}
    except Exception as exc:
        return {"ok": False, "status_code": 502, "error": str(exc), "data": None}


def _unwrap_gateway_catalog(raw: Any) -> Optional[Dict[str, Any]]:
    queue: List[Any] = [raw]
    seen: Set[int] = set()
    while queue:
        cur = queue.pop(0)
        if not isinstance(cur, dict) or id(cur) in seen:
            continue
        seen.add(id(cur))
        if isinstance(cur.get("document_groups"), list):
            return cur
        for key in ("response", "payload", "data", "result"):
            if key in cur:
                queue.append(cur[key])
    return None


def _merge_catalogs(primary: Dict[str, Any], fallback: Dict[str, Any]) -> Dict[str, Any]:
    """Merge missing groups, docs, and sections from fallback artifact catalog into live catalog."""
    merged = copy.deepcopy(primary)
    groups = merged.setdefault("document_groups", [])
    if not isinstance(groups, list):
        return fallback

    groups_by_type: Dict[str, Dict[str, Any]] = {
        _normalize_doc_type(g.get("document_type")): g
        for g in groups
        if isinstance(g, dict) and g.get("document_type")
    }

    for fb_grp in fallback.get("document_groups") or []:
        if not isinstance(fb_grp, dict):
            continue
        dtype = _normalize_doc_type(fb_grp.get("document_type") or "policy")
        target_grp = groups_by_type.get(dtype)
        if target_grp is None:
            new_grp = copy.deepcopy(fb_grp)
            groups.append(new_grp)
            groups_by_type[dtype] = new_grp
            continue

        docs = target_grp.setdefault("documents", [])
        for fb_doc in fb_grp.get("documents") or []:
            if not isinstance(fb_doc, dict):
                continue
            fb_id = _raw_norm(fb_doc.get("document_id"))
            fb_keys = {
                _norm_key(fb_doc.get("document_title")),
                _norm_key(fb_doc.get("document_name")),
                _norm_key(fb_doc.get("file_name")),
            } - {""}
            match_doc = None
            for cur_doc in docs:
                if not isinstance(cur_doc, dict):
                    continue
                cur_id = _raw_norm(cur_doc.get("document_id"))
                cur_keys = {
                    _norm_key(cur_doc.get("document_title")),
                    _norm_key(cur_doc.get("document_name")),
                    _norm_key(cur_doc.get("file_name")),
                } - {""}
                if (fb_id and cur_id and fb_id == cur_id) or (fb_keys & cur_keys):
                    match_doc = cur_doc
                    break

            if match_doc is None:
                docs.append(copy.deepcopy(fb_doc))
            else:
                if not match_doc.get("sections") and fb_doc.get("sections"):
                    match_doc["sections"] = copy.deepcopy(fb_doc["sections"])
                if not match_doc.get("document_id") and fb_doc.get("document_id"):
                    match_doc["document_id"] = fb_doc["document_id"]
                if not match_doc.get("file_name") and fb_doc.get("file_name"):
                    match_doc["file_name"] = fb_doc["file_name"]

    total_docs = 0
    for grp in groups:
        if isinstance(grp, dict):
            grp_docs = grp.get("documents") or []
            grp["total_count"] = len(grp_docs)
            total_docs += len(grp_docs)
    merged["total_count"] = total_docs
    return merged


async def _fetch_catalog_with_fallback(
    client: httpx.AsyncClient,
    plan_number: str,
    artifacts: Dict[str, Any],
) -> Tuple[Optional[Dict[str, Any]], Optional[str], str]:
    """Fetch document catalog from CT1 Query Service, Gateway, Master Agent, or build from CT1 artifacts."""
    errors: List[str] = []
    fallback_catalog = _build_catalog_from_artifacts(plan_number, artifacts)
    candidates = [
        ("query_service", f"{QUERY_SERVICE_BASE}/qna/documents/list-all", {"plan_number": plan_number}),
        (
            "api_gateway",
            f"{CTA_HOST}/dbaware-api-gateway/api/v1/actions",
            {"planNumber": plan_number, "action": "QNA_LIST_DOCUMENTS", "payload": {"plan_number": plan_number}},
        ),
        (
            "master_agent",
            f"{CTA_HOST}/scoping-master-agent/trigger-scoping-master",
            {"planNumber": plan_number, "action": "QNA_LIST_DOCUMENTS", "payload": {"plan_number": plan_number}},
        ),
    ]

    for source_name, url, body in candidates:
        try:
            resp = await client.post(url, json=body, timeout=15.0)
            if resp.status_code == 200:
                parsed = _unwrap_gateway_catalog(resp.json())
                if parsed is not None:
                    return _merge_catalogs(parsed, fallback_catalog), None, source_name
            errors.append(f"{source_name}: HTTP {resp.status_code} ({_extract_error_detail(resp)[:120]})")
        except Exception as exc:
            errors.append(f"{source_name}: {type(exc).__name__}")

    notice = "; ".join(errors[:2]) if errors else "Query service unavailable; built catalog from CT1 artifacts"
    return fallback_catalog, notice, "ct1_artifacts_fallback"


async def _load_plan_bundle(plan_number: str) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]], Dict[str, Any], Optional[Dict[str, Any]], Dict[str, str], str]:
    """Load availability, all 9 artifacts, and catalog from CT1 with local/sample fallback."""
    artifact_ids = [item["id"] for item in PLAN_ARTIFACTS]
    async with create_async_client() as client:
        avail_res, *art_results = await asyncio.gather(
            _fetch_availability_safe(client, plan_number),
            *(_fetch_artifact_safe(client, plan_number, aid) for aid in artifact_ids),
        )

        artifacts: Dict[str, Any] = {}
        errors: Dict[str, str] = {}
        availability = avail_res["data"] if avail_res["ok"] else None
        if not avail_res["ok"]:
            errors["availability"] = str(avail_res.get("error") or "Availability unavailable")

        for aid, res in zip(artifact_ids, art_results):
            if res["ok"]:
                artifacts[aid] = res["data"]
            else:
                errors[aid] = str(res.get("error") or f"HTTP {res.get('status_code')}")

        # If all CT1 data extraction calls failed due to offline DNS/network, fall back to captured samples
        if not artifacts:
            sample_avail, sample_artifacts = _load_samples_for_plan(plan_number)
            if sample_artifacts:
                availability = availability or sample_avail
                artifacts = sample_artifacts
                errors.pop("availability", None)
                for aid in list(errors.keys()):
                    if aid in artifacts:
                        errors.pop(aid, None)

        enriched_artifacts = _enrich_artifacts_from_local_inbound(plan_number, artifacts)
        raw_catalog, cat_notice, query_mode = await _fetch_catalog_with_fallback(
            client, plan_number, enriched_artifacts
        )
        if cat_notice:
            errors["catalog"] = cat_notice

    final_catalog = _apply_plan_state_to_catalog(plan_number, raw_catalog)
    final_artifacts = _apply_plan_state_to_artifacts(plan_number, enriched_artifacts)
    return enriched_artifacts, availability, final_artifacts, final_catalog, errors, query_mode


_EXCLUDE_VERB_RE = re.compile(
    r"\b(exclude|remove|delete|drop|omit|discard|take\s+out|get\s+rid\s+of|leave\s+out|cut|scrap|withdraw)\b",
    re.IGNORECASE,
)
_INCLUDE_VERB_RE = re.compile(
    r"\b(include|restore|re-?include|re-?add|add\s+back|bring\s+back|put\s+back|bring\s+in|reinstate|add|keep|insert|attach|incorporate)\b",
    re.IGNORECASE,
)
_CLAUSE_SPLIT_RE = re.compile(
    r"\s*(?:;|\.\s+|,\s*(?:and\s+|but\s+|then\s+|also\s+)?|\b(?:and|but|then|while|whereas)\s+(?:also\s+)?)"
    r"(?=[^,;.]*\b(?:exclude|remove|delete|drop|omit|discard|take\s+out|get\s+rid\s+of|leave\s+out|cut|scrap|withdraw|"
    r"include|restore|re-?include|re-?add|add\s+back|bring\s+back|put\s+back|bring\s+in|reinstate|add|keep|insert|attach|incorporate)\b)",
    re.IGNORECASE,
)
_QUERY_STOP_WORDS = {
    "a", "an", "and", "as", "at", "be", "by", "for", "from", "in", "into", "is", "it",
    "of", "on", "or", "that", "the", "this", "to", "under", "was", "were", "with",
    "yo", "hey", "hi", "hello", "sorry", "please", "pls", "kindly", "actually", "ok", "okay",
    "instead", "now", "right", "too", "also", "just", "only",
    "policy", "policies", "kod", "kods", "procedure", "procedures",
    "document", "documents", "doc", "docs", "file", "files", "section", "manual",
    "plan", "plans", "historical", "hisorical", "history", "report", "reports",
    "finding", "findings", "mandate", "mandates", "gfms", "lrr", "scoping", "details",
    "exclude", "remove", "delete", "drop", "omit", "discard", "take", "out", "get", "rid",
    "leave", "cut", "scrap", "withdraw", "include", "restore", "reinclude", "readd",
    "add", "back", "bring", "put", "reinstate", "keep", "insert", "attach", "incorporate",
}


def _detect_clause_action(clause_text: str, default_action: str = "exclude") -> str:
    inc = _INCLUDE_VERB_RE.search(clause_text or "")
    exc = _EXCLUDE_VERB_RE.search(clause_text or "")
    if inc and exc:
        return "include" if inc.start() <= exc.start() else "exclude"
    if inc:
        return "include"
    if exc:
        return "exclude"
    return default_action


def _split_chat_clauses(user_text: str, default_action: Optional[str] = None) -> List[Tuple[str, str]]:
    """Split a multi-intent chat message into (action, clause_text) pairs."""
    clauses = [c.strip() for c in _CLAUSE_SPLIT_RE.split(user_text or "") if c and _core_tokens(c)]
    if not clauses:
        return [(default_action or "exclude", (user_text or "").strip())]
    result: List[Tuple[str, str]] = []
    last_action = default_action or "exclude"
    for clause in clauses:
        act = _detect_clause_action(clause, last_action)
        last_action = act
        result.append((act, clause))
    return result


def _extract_free_text_section_and_doc(clause_text: str) -> Tuple[str, Optional[str], Optional[str]]:
    """Extract optional section ID/title from `clause_text` without stripping prose from document matching."""
    text = re.sub(r"\s+", " ", (clause_text or "").strip())
    m1 = re.search(
        r"\bsections?\s+([0-9]+(?:\.[0-9]+)*|[a-zA-Z0-9_-]+)"
        r"(?:\s*[:\-–]\s*([^\n,;]+?))?"
        r"\s+(?:of|in|from|under|for|on)\s+(.+)$",
        text,
        flags=re.IGNORECASE,
    )
    if m1:
        sec_id = m1.group(1).strip()
        sec_title = m1.group(2).strip(" ,;:.-'\"") if m1.group(2) else None
        return m1.group(3).strip(), sec_id, sec_title

    m2 = re.search(
        r"^(.+?)\s+\bsections?\s+([0-9]+(?:\.[0-9]+)*|[a-zA-Z0-9_-]+)"
        r"(?:\s*[:\-–]\s*([^\n,;]+?))?$",
        text,
        flags=re.IGNORECASE,
    )
    if m2:
        sec_id = m2.group(2).strip()
        sec_title = m2.group(3).strip(" ,;:.-'\"") if m2.group(3) else None
        return m2.group(1).strip(), sec_id, sec_title

    m3 = re.search(
        r"\bsections?\s+[\"']?([^\"',;]+?)[\"']?\s+(?:of|in|from|under|for)\s+(.+)$",
        text,
        flags=re.IGNORECASE,
    )
    if m3:
        sec_title = m3.group(1).strip(" ,;:.-'\"")
        sec_id = sec_title if re.fullmatch(r"[0-9]+(?:\.[0-9]+)*", sec_title) else None
        return m3.group(2).strip(), sec_id, (None if sec_id else sec_title)

    return text, None, None


def _core_tokens(value: str) -> List[str]:
    norm = _norm_key(value)
    cleaned = re.sub(r"[^a-z0-9\s]", " ", norm)
    return [t for t in cleaned.split() if t and t not in _QUERY_STOP_WORDS]


def _score_catalog_doc_match(
    query_text: str,
    doc_title: str,
    doc_type: str,
    raw_clause: str,
    action: str,
    is_excluded: bool,
) -> float:
    q_norm = _norm_key(query_text)
    d_norm = _norm_key(doc_title)
    if not d_norm:
        return 0.0

    # Strict digit-bearing token guard: numeric/ID mismatches like 20051 vs 20061 must return 0.
    q_digit_tokens = {
        t for t in re.sub(r"[^a-z0-9\s]", " ", q_norm).split() if any(ch.isdigit() for ch in t)
    }
    d_digit_tokens = {
        t for t in re.sub(r"[^a-z0-9\s]", " ", d_norm).split() if any(ch.isdigit() for ch in t)
    }
    if q_digit_tokens and not q_digit_tokens.issubset(d_digit_tokens):
        return 0.0

    q_tokens = _core_tokens(query_text)
    d_tokens = _core_tokens(doc_title)
    q_joined = " ".join(q_tokens)
    d_joined = " ".join(d_tokens)

    base_score = 0.0
    if q_norm and (q_norm == d_norm or (q_joined and d_joined and q_joined == d_joined)):
        base_score = 1.0
    elif (q_joined and d_joined and len(q_joined) >= 4 and (q_joined in d_joined or d_joined in q_joined)) or (
        q_norm and len(q_norm) >= 4 and (q_norm in d_norm or d_norm in q_norm)
    ):
        base_score = 0.92
    elif q_tokens and d_tokens:
        d_set = set(d_tokens)
        non_digit_d_tokens = [dt for dt in d_tokens if not any(ch.isdigit() for ch in dt)]
        token_credit = 0.0
        exact_hits = 0
        for qt in q_tokens:
            if qt in d_set or (
                not any(ch.isdigit() for ch in qt)
                and any(qt in dt or dt in qt for dt in non_digit_d_tokens if len(qt) >= 4 and len(dt) >= 4)
            ):
                token_credit += 1.0
                exact_hits += 1
            elif not any(ch.isdigit() for ch in qt):
                best_ratio = max((difflib.SequenceMatcher(None, qt, dt).ratio() for dt in non_digit_d_tokens), default=0.0)
                if best_ratio >= 0.44 and len(qt) >= 4:
                    token_credit += best_ratio * 0.72
        if exact_hits > 0 or token_credit >= 1.1:
            coverage = token_credit / max(1, len(q_tokens))
            precision = token_credit / max(1, len(d_tokens))
            base_score = 0.75 * coverage + 0.25 * precision
        elif len(q_tokens) == 1 and not any(ch.isdigit() for ch in q_tokens[0]):
            best_ratio = max((difflib.SequenceMatcher(None, q_tokens[0], dt).ratio() for dt in non_digit_d_tokens), default=0.0)
            if best_ratio >= 0.68:
                base_score = best_ratio * 0.75

    if base_score < 0.35:
        return 0.0

    clause_lower = (raw_clause or "").lower()
    if doc_type == "procedure" and re.search(r"\bprocedures?\b", clause_lower):
        base_score += 0.16 if ("procedure" in d_norm or doc_type == "procedure") else 0.0
    elif doc_type == "kod" and re.search(r"\b(?:kods?|key\s+operating)\b", clause_lower):
        base_score += 0.16
    elif doc_type == "policy" and re.search(r"\bpolic(?:y|ies)\b", clause_lower):
        base_score += 0.12
    elif doc_type == "gfms" and re.search(r"\b(?:gfms|findings?)\b", clause_lower):
        base_score += 0.16
    elif doc_type == "historical_scoping_document" and re.search(r"\bhis?toric(?:al)?\b", clause_lower):
        base_score += 0.16
    elif doc_type == "lrr" and re.search(r"\b(?:lrr|mandates?|regulations?)\b", clause_lower):
        base_score += 0.16

    # Prefer active docs when excluding, and excluded docs when restoring/including
    if action == "exclude" and not is_excluded:
        base_score += 0.04
    elif action == "include" and is_excluded:
        base_score += 0.04

    return round(base_score, 4)


def _resolve_section_target(
    doc: Dict[str, Any],
    sec_id: Optional[str],
    sec_title: Optional[str],
    doc_type: str = "",
) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Find a section inside `doc['sections']` or synthesize a section target if absent from chunks."""
    sections = doc.get("sections") or []
    best_sec: Optional[Dict[str, Any]] = None
    best_score = 0.0
    norm_sec = _norm_key(sec_title)
    for sec in sections:
        if not isinstance(sec, dict):
            continue
        sid = str(sec.get("section_id") or "").strip()
        stitle = str(sec.get("section_title") or "").strip()
        if sec_id and sid:
            if sid.lower() == sec_id.lower():
                best_sec = sec
                best_score = 1.0
                break
            if doc_type not in {"gfms", "historical_scoping_document", "lrr"} and (
                sid.lower().startswith(f"{sec_id.lower()}.") or sec_id.lower().startswith(f"{sid.lower()}.")
            ):
                if 0.8 > best_score:
                    best_sec = sec
                    best_score = 0.8
        if norm_sec and stitle:
            st_norm = _norm_key(stitle)
            sc = 1.0 if norm_sec == st_norm else (0.85 if norm_sec in st_norm or st_norm in norm_sec else difflib.SequenceMatcher(None, norm_sec, st_norm).ratio())
            if sc >= 0.65 and sc > best_score:
                best_sec = sec
                best_score = sc

    if best_sec is not None:
        return (
            str(best_sec.get("section_id") or sec_id or ""),
            str(best_sec.get("section_title") or sec_title or ""),
            str(best_sec.get("node_id") or ""),
        )

    if doc_type in {"gfms", "historical_scoping_document", "lrr"}:
        return None, None, None

    doc_title = str(doc.get("document_title") or doc.get("document_name") or "").strip()
    doc_ref = str(doc.get("document_id") or _norm_key(doc_title) or "doc")
    resolved_id = sec_id or None
    resolved_title = sec_title or (f"Section {sec_id}" if sec_id else None)
    resolved_node = f"{doc_ref}:section:{sec_id or _norm_key(resolved_title)}"
    return resolved_id, resolved_title, resolved_node


def _resolve_chat_targets(
    user_text: str,
    action: Optional[str],
    catalog: Optional[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Resolve @[Group: Doc] / @[Group: Doc > Section] or natural-language clauses against catalog."""
    actions: List[Dict[str, Any]] = []
    seen_targets: Set[str] = set()
    groups = (catalog or {}).get("document_groups") or []

    for clause_action, clause_text in _split_chat_clauses(user_text, default_action=action or "exclude"):
        clause_added = False

        # 1. Exact bracketed @ mentions in this clause: @[Group: Doc] or @[Group: Doc > Section]
        mentions = re.findall(r"@\[([^\]]+)\]", clause_text)
        for raw_m in mentions:
            if ":" in raw_m:
                group_hint, target_part = raw_m.split(":", 1)
                norm_type = _normalize_doc_type(group_hint)
            else:
                norm_type, target_part = "", raw_m

            if ">" in target_part:
                doc_hint, sec_hint = [p.strip() for p in target_part.split(">", 1)]
            else:
                doc_hint, sec_hint = target_part.strip(), ""

            sec_id_hint = ""
            m_sec = re.match(r"^section\s+([^:]+)(?::\s*(.+))?$", sec_hint, flags=re.IGNORECASE)
            if m_sec:
                sec_id_hint = m_sec.group(1).strip()
                sec_hint = (m_sec.group(2) or "").strip()

            norm_doc = _norm_key(doc_hint)
            for grp in groups:
                gtype = _normalize_doc_type(grp.get("document_type"))
                if norm_type and gtype != norm_type:
                    continue
                for doc in grp.get("documents") or []:
                    dtitle = str(doc.get("document_title") or doc.get("document_name") or "").strip()
                    d_norm = _norm_key(dtitle)
                    if not d_norm or (norm_doc not in d_norm and d_norm not in norm_doc):
                        continue
                    if sec_id_hint or sec_hint:
                        sid, stitle, nid = _resolve_section_target(doc, sec_id_hint or None, sec_hint or None)
                        tkey = f"{gtype}|{d_norm}|sec|{nid or sid or _norm_key(stitle)}"
                        if tkey not in seen_targets:
                            seen_targets.add(tkey)
                            actions.append(
                                {
                                    "action": clause_action,
                                    "document_type": gtype,
                                    "title": dtitle,
                                    "document_id": doc.get("document_id"),
                                    "filename": doc.get("file_name"),
                                    "section_id": sid,
                                    "section_title": stitle,
                                    "node_id": nid,
                                    "row_primary_key": str(nid or doc.get("document_id") or ""),
                                }
                            )
                            clause_added = True
                        continue
                    tkey = f"{gtype}|{d_norm}|doc"
                    if tkey not in seen_targets:
                        seen_targets.add(tkey)
                        actions.append(
                            {
                                "action": clause_action,
                                "document_type": gtype,
                                "title": dtitle,
                                "document_id": doc.get("document_id"),
                                "filename": doc.get("file_name"),
                                "section_id": None,
                                "section_title": None,
                                "node_id": None,
                                "row_primary_key": str(doc.get("document_id") or doc.get("file_name") or ""),
                            }
                        )
                        clause_added = True

        if clause_added:
            continue

        # 2. Free-text natural-language matching (supports omitted category suffixes, typos, and sections)
        doc_query, sec_id, sec_title = _extract_free_text_section_and_doc(clause_text)
        best_candidate: Optional[Tuple[float, str, Dict[str, Any], str, Optional[Dict[str, Any]]]] = None
        query_raw_tokens = set(re.sub(r"[^a-z0-9#/_-]+", " ", (doc_query or clause_text).lower()).split())
        for grp in groups:
            gtype = _normalize_doc_type(grp.get("document_type"))
            for doc in grp.get("documents") or []:
                dtitle = str(doc.get("document_title") or doc.get("document_name") or "").strip()
                d_norm = _norm_key(dtitle)
                if not d_norm:
                    continue
                is_excluded = bool(doc.get("excluded")) or str(doc.get("status") or "").lower() in _EXCLUDED_STATUSES
                doc_id_label = str(doc.get("document_id") or "").strip()
                score = _score_catalog_doc_match(
                    doc_query or clause_text,
                    f"{dtitle} {doc_id_label}".strip() if doc_id_label and gtype in {"gfms", "historical_scoping_document"} else dtitle,
                    gtype,
                    clause_text,
                    clause_action,
                    is_excluded,
                )
                if score >= 0.45 and (best_candidate is None or score > best_candidate[0]):
                    best_candidate = (score, gtype, doc, dtitle, None)

                if gtype in {"gfms", "historical_scoping_document", "lrr"}:
                    for sec in doc.get("sections") or []:
                        if not isinstance(sec, dict):
                            continue
                        sid_s = str(sec.get("section_id") or "").strip()
                        stitle_s = str(sec.get("section_title") or "").strip()
                        sec_excluded = bool(sec.get("excluded")) or str(sec.get("status") or "").lower() in _EXCLUDED_STATUSES
                        sec_score = 0.0
                        if sid_s and sid_s.lower() in query_raw_tokens:
                            sec_score = 1.0
                        elif stitle_s:
                            sec_score = _score_catalog_doc_match(
                                doc_query or clause_text,
                                f"{sid_s} {stitle_s}".strip(),
                                gtype,
                                clause_text,
                                clause_action,
                                sec_excluded,
                            )
                        if sec_score >= 0.55 and (best_candidate is None or sec_score > best_candidate[0]):
                            best_candidate = (sec_score, gtype, doc, dtitle, sec)

        if best_candidate is not None:
            _, gtype, doc, dtitle, matched_sec = best_candidate
            d_norm = _norm_key(dtitle)
            if matched_sec is not None:
                sid = str(matched_sec.get("section_id") or "")
                stitle = str(matched_sec.get("section_title") or "")
                nid = str(matched_sec.get("node_id") or "")
                tkey = f"{gtype}|{d_norm}|sec|{nid or sid or _norm_key(stitle)}"
                if tkey not in seen_targets:
                    seen_targets.add(tkey)
                    actions.append(
                        {
                            "action": clause_action,
                            "document_type": gtype,
                            "title": dtitle,
                            "document_id": doc.get("document_id"),
                            "filename": doc.get("file_name"),
                            "section_id": sid,
                            "section_title": stitle,
                            "node_id": nid,
                            "row_primary_key": str(nid or sid or doc.get("document_id") or ""),
                        }
                    )
            elif sec_id or sec_title:
                sid, stitle, nid = _resolve_section_target(doc, sec_id, sec_title, doc_type=gtype)
                if sid or stitle or nid:
                    tkey = f"{gtype}|{d_norm}|sec|{nid or sid or _norm_key(stitle)}"
                    if tkey not in seen_targets:
                        seen_targets.add(tkey)
                        actions.append(
                            {
                                "action": clause_action,
                                "document_type": gtype,
                                "title": dtitle,
                                "document_id": doc.get("document_id"),
                                "filename": doc.get("file_name"),
                                "section_id": sid,
                                "section_title": stitle,
                                "node_id": nid,
                                "row_primary_key": str(nid or doc.get("document_id") or ""),
                            }
                        )
            else:
                tkey = f"{gtype}|{d_norm}|doc"
                if tkey not in seen_targets:
                    seen_targets.add(tkey)
                    actions.append(
                        {
                            "action": clause_action,
                            "document_type": gtype,
                            "title": dtitle,
                            "document_id": doc.get("document_id"),
                            "filename": doc.get("file_name"),
                            "section_id": None,
                            "section_title": None,
                            "node_id": None,
                            "row_primary_key": str(doc.get("document_id") or doc.get("file_name") or ""),
                        }
                    )

    return actions


def _apply_actions_to_plan_state(plan_number: str, actions: List[Dict[str, Any]]) -> List[str]:
    st = _get_plan_state(plan_number)
    affected: Set[str] = set()
    custom_secs: List[Dict[str, Any]] = st.setdefault("custom_sections", [])
    for act in actions:
        op = str(act.get("action") or "exclude").lower()
        dtype = _normalize_doc_type(act.get("document_type") or "policy")
        for sec in _AFFECTED_SECTIONS_MAP.get(dtype, ("broad_scope",)):
            affected.add(sec)

        has_section = bool(act.get("node_id") or act.get("section_id") or act.get("section_title"))
        doc_keys = {
            _norm_key(act.get("title")),
            _norm_key(act.get("filename")),
            _raw_norm(act.get("document_id")),
        } - {""}
        if has_section:
            nid = _raw_norm(act.get("node_id"))
            sid = _raw_norm(act.get("section_id"))
            stitle = _norm_key(act.get("section_title"))
            skeys: Set[str] = set()
            if nid:
                skeys.add(f"{dtype}|{nid}")
            for dk in doc_keys:
                if sid:
                    skeys.add(f"{dtype}|{dk}::id:{sid}")
                if stitle:
                    skeys.add(f"{dtype}|{dk}::title:{stitle}")
            if not nid and not doc_keys:
                if sid:
                    skeys.add(f"{dtype}|{sid}")
                if stitle:
                    skeys.add(f"{dtype}|{stitle}")

            primary_doc_key = _norm_key(act.get("title") or act.get("filename") or act.get("document_id"))
            if primary_doc_key and sid and not any(
                c.get("document_type") == dtype and c.get("doc_key") == primary_doc_key and _raw_norm(c.get("section_id")) == sid
                for c in custom_secs
            ):
                custom_secs.append(
                    {
                        "document_type": dtype,
                        "doc_key": primary_doc_key,
                        "section_id": act.get("section_id"),
                        "section_title": act.get("section_title") or f"Section {act.get('section_id')}",
                        "node_id": act.get("node_id") or f"{primary_doc_key}:section:{act.get('section_id')}",
                    }
                )

            if op in ("include", "restore"):
                st["excluded_sections"].difference_update(skeys)
            else:
                st["excluded_sections"].update(skeys)
        else:
            dkeys = {f"{dtype}|{dk}" for dk in doc_keys if dk}
            if op in ("include", "restore"):
                st["excluded_docs"].difference_update(dkeys)
            else:
                st["excluded_docs"].update(dkeys)
    return [s for s in ("past_review", "policy_regulation", "broad_scope") if s in affected]


def _answer_general_qna_from_artifacts(
    plan_number: str,
    question: str,
    artifacts: Dict[str, Any],
) -> str:
    """Grounded Q&A answer built from active (post-exclusion) CT1 artifacts when upstream QnA is 503."""
    plan_det = (_unwrap_data_dict(artifacts.get("current_details")) or {}).get("plan_details") or {}
    refs = (_unwrap_data_dict(artifacts.get("policy")) or {}).get("referenced_documents") or []
    gfms_wrappers = (_unwrap_data_dict(artifacts.get("findings_details")) or {}).get("findings_details") or []
    ctrls = ((_unwrap_data_dict(artifacts.get("control_details")) or {}).get("control_details") or {}).get("included_kcs") or []
    hist_items = (_unwrap_data_dict(artifacts.get("historical_plan_details")) or {}).get("historical_plan_details") or []
    lrr_data = _unwrap_data_dict(artifacts.get("lrr")) or {}
    lrr_items = lrr_data.get("internet_search_data_enriched") or lrr_data.get("internet_search_data") or []

    findings: List[Dict[str, Any]] = []
    for w in gfms_wrappers:
        if isinstance(w, dict) and isinstance(w.get("responsePayload"), list):
            findings.extend(w["responsePayload"])

    mandates: List[str] = []
    for r in lrr_items:
        if isinstance(r, dict) and isinstance(r.get("Mandates"), list):
            for m in r["Mandates"]:
                if isinstance(m, dict) and m.get("Regulatory Mandate"):
                    mandates.append(f"[{r.get('Risk Name', 'LRR')}] {str(m['Regulatory Mandate'])[:120]}")

    lines = [
        f"Summary from active Plan {plan_number} feeds (CT1 query-service fallback):",
    ]
    if isinstance(plan_det, dict) and plan_det.get("Plan Item Title"):
        lines.append(
            f"- Plan: **{plan_det.get('Plan Item Title')}** ({plan_det.get('AU Region', 'n/a')}, Risk: {plan_det.get('UoT Risk Type', 'n/a')})"
        )
    lines.append(f"- Active Governance Documents ({len(refs)}): " + (", ".join(str(r.get("document_name")) for r in refs[:6]) or "None"))
    lines.append(
        f"- Open GFMS Findings ({len(findings)}): "
        + (", ".join(f"{f.get('findingId')} ({f.get('rating', '')} / {f.get('ct1') or f.get('findingStatus', '')})" for f in findings[:4]) or "None")
    )
    lines.append(f"- Included Key Controls ({len(ctrls)}): " + (f"{ctrls[0].get('inventory', {}).get('controlDefinitionNumber')} ({len(ctrls)} assessment units)" if ctrls else "None"))
    lines.append(f"- Historical Scoping Plans ({len(hist_items)}): " + (", ".join(f"Plan {h.get('Plan Item Number')}" for h in hist_items[:4]) or "None"))
    lines.append(f"- Active LRR Mandates ({len(mandates)}): " + ("; ".join(mandates[:2]) or "None"))
    return "\n".join(lines)


@app.get("/api/config")
async def get_config() -> Dict[str, Any]:
    """Return CT1 host settings and artifact metadata definitions."""
    return {
        "cta_host": CTA_HOST,
        "rag_service_base": RAG_SERVICE_BASE,
        "default_plan_number": DEFAULT_PLAN_NUMBER,
        "artifacts": PLAN_ARTIFACTS,
    }


@app.get("/api/ct1/plan/{plan_number}/bootstrap")
async def bootstrap_plan(plan_number: str) -> Dict[str, Any]:
    """
    Fetch live CT1 availability + all 9 Data Extraction payloads alongside
    the Query Service document catalog (falling back smoothly to CT1 artifact
    catalog if CT1 query-service returns 503).
    """
    started = time.perf_counter()
    _, availability, artifacts, catalog, errors, query_mode = await _load_plan_bundle(plan_number)
    return {
        "plan_number": plan_number,
        "cta_host": CTA_HOST,
        "query_mode": query_mode,
        "latency_ms": round((time.perf_counter() - started) * 1000.0, 1),
        "catalog": catalog,
        "availability": availability,
        "artifacts": artifacts,
        "errors": errors,
    }


@app.post("/api/ct1/plan/{plan_number}/reset")
async def reset_plan_state(plan_number: str) -> Dict[str, Any]:
    """Reset in-memory fallback exclusion/upload state for a plan."""
    _PLAN_STATE.pop(str(plan_number).strip(), None)
    return {"status": "reset", "plan_number": plan_number}


@app.get("/api/ct1/dataextraction/status/{session_id}")
async def proxy_extraction_status(session_id: str) -> Dict[str, Any]:
    """Poll CT1 data extraction job status."""
    url = f"{DATAEXTRACTION_BASE}/data-extraction/{session_id}/status"
    async with create_async_client() as client:
        return await _forward_json(client, "GET", url)


@app.get("/api/ct1/dataextraction/{plan_number}/{artifact}")
async def proxy_get_artifact(plan_number: str, artifact: str) -> Any:
    """Live pass-through to CT1 GET /scoping-dataextraction-agent/getdata/{plan_number}/{artifact}."""
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/{artifact}"
    payload: Optional[Dict[str, Any]] = None
    async with create_async_client() as client:
        try:
            resp = await client.get(url)
            if resp.status_code == 200:
                payload = resp.json()
            else:
                raise HTTPException(status_code=resp.status_code, detail=_extract_error_detail(resp))
        except HTTPException:
            raise
        except Exception as exc:
            _, sample_artifacts = _load_samples_for_plan(plan_number)
            if artifact in sample_artifacts:
                payload = sample_artifacts[artifact]
            else:
                raise HTTPException(status_code=502, detail=f"Unable to fetch artifact from CT1: {exc}") from exc

    enriched = _enrich_artifacts_from_local_inbound(plan_number, {artifact: payload})
    applied = _apply_plan_state_to_artifacts(plan_number, enriched)
    return applied[artifact]


@app.post("/api/ct1/dataextraction/run")
async def proxy_run_extraction(payload: ExtractionRunRequest) -> Dict[str, Any]:
    """Trigger a fresh CT1 data extraction run."""
    url = f"{DATAEXTRACTION_BASE}/data-extraction"
    body = {"planNumber": payload.planNumber, "userDetails": payload.userDetails or {"user": "demo.user@db.com"}}
    async with create_async_client() as client:
        return await _forward_json(client, "POST", url, json_body=body)


_MAX_CHAT_QUERY_CHARS = 4000
_GUARDRAIL_PROMPT_INJECTION_RE = re.compile(
    r"(?:"
    r"\b(?:ignore|disregard|forget|override|bypass)\s+(?:all\s+|any\s+)?(?:previous|prior|above|system|developer)\s+(?:instructions?|prompts?|rules?|guardrails?)\b"
    r"|\b(?:reveal|print|show|dump|output|leak)\s+(?:your\s+|the\s+)?(?:system\s+prompt|hidden\s+instructions?|developer\s+message)\b"
    r"|\b(?:bypass|skip|disable|turn\s+off)\s+(?:the\s+)?(?:approval|human\s+review|verification|security|compliance|guardrails?)\b"
    r"|\b(?:you\s+are\s+now\s+in\s+developer\s+mode|act\s+as\s+an\s+unrestricted|jailbreak)\b"
    r")",
    re.IGNORECASE,
)
_GUARDRAIL_BULK_WIPE_RE = re.compile(
    r"(?:"
    r"\b(?:remove|delete|exclude|drop|wipe|clear|purge)\s+(?:all|every)\s+(?:the\s+)?(?:documents?|policies|kods?|procedures?|gfms|findings?|mandates?|files?|records?|context|data)\b"
    r"|\b(?:remove|delete|exclude|wipe|clear|purge)\s+everything\b"
    r")",
    re.IGNORECASE,
)
_GUARDRAIL_PAYLOAD_RE = re.compile(
    r"(?:\.\./|\.\.\\|<\s*script\b|javascript\s*:|;\s*(?:drop|delete|truncate|update|insert|alter)\s+(?:table|from|into)\b|\bunion\s+(?:all\s+)?select\b)",
    re.IGNORECASE,
)
_GUARDRAIL_SECRET_RE = re.compile(
    r"\b(?:bearer\s+[a-z0-9._\-]{8,}|(?:api[_-]?key|token|secret|password|passwd)\s*[:=]\s*['\"]?[^\s,;'\"]{4,}['\"]?)",
    re.IGNORECASE,
)


def _check_chat_guardrails(user_text: str, plan_number: str) -> Tuple[str, Optional[str]]:
    """Sanitize chat input and block prompt injection, cross-plan, script/SQL, or mass-wipe attempts."""
    cleaned = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", str(user_text or ""))
    cleaned = _GUARDRAIL_SECRET_RE.sub("[REDACTED]", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    if not cleaned:
        return "", "Query cannot be empty."
    if len(cleaned) > _MAX_CHAT_QUERY_CHARS:
        return cleaned[:_MAX_CHAT_QUERY_CHARS], f"Query exceeds maximum permitted length ({_MAX_CHAT_QUERY_CHARS} chars)."
    if _GUARDRAIL_PROMPT_INJECTION_RE.search(cleaned):
        return cleaned, "Blocked potential prompt injection or guardrail-bypass instruction."
    if _GUARDRAIL_PAYLOAD_RE.search(cleaned):
        return cleaned, "Blocked unsafe path-traversal, script, or SQL-injection payload."
    if _GUARDRAIL_BULK_WIPE_RE.search(cleaned):
        return cleaned, (
            "Compliance policy prohibits bulk-deleting all scoping documents at once. "
            "Specify the individual document(s) or section(s)."
        )
    for ref_plan in re.findall(r"\bdbaware_review_(\d+)\b", cleaned, flags=re.IGNORECASE):
        if ref_plan.strip() != str(plan_number).strip():
            return cleaned, f"Cross-plan access blocked: plan {ref_plan} does not match active plan {plan_number}."

    cleaned = cleaned.replace("<<<", "< < <").replace(">>>", "> > >")
    return cleaned, None


@app.post("/api/ct1/query/chat")
async def proxy_query_chat(payload: ChatProxyRequest) -> Dict[str, Any]:
    """Forward chat turns to CT1 Query Service with input guardrails and resilient fallback."""
    plan_number = str(payload.plan_number).strip()
    clean_question, violation = _check_chat_guardrails(payload.question, plan_number)
    if violation is not None:
        logger.warning("Guardrail blocked Demo UI chat query for Plan %s: %s", plan_number, violation)
        return {
            "session_id": plan_number,
            "answer": f"Request blocked by security & compliance guardrail: {violation}",
            "document_workflow": {
                "stage": "rejected",
                "status": "rejected_by_guardrail",
                "plan_number": plan_number,
                "requires_approval": False,
            },
        }

    url = f"{QUERY_SERVICE_BASE}/qna/chat"
    body: Dict[str, Any] = {
        "question": clean_question,
        "plan_number": plan_number,
        "context_type": payload.context_type,
        "userDetails": payload.userDetails or {"user": "demo.user@db.com"},
    }
    if payload.plan_name:
        body["plan_name"] = payload.plan_name
    if payload.research_sections is not None:
        body["research_sections"] = payload.research_sections

    # 1. Try live CT1 Query Service first
    upstream_error: Optional[str] = None
    live_no_verified_data: Optional[Dict[str, Any]] = None
    st = _get_plan_state(plan_number)
    text = clean_question
    lower = text.lower()
    is_approval_reply = st["pending_plan"] is not None and bool(
        re.match(r"^(approve|approved|yes|confirm|execute|cancel|reject|rejected|no|abort)\b", lower)
    )
    is_doc_intent = bool(_INCLUDE_VERB_RE.search(text) or _EXCLUDE_VERB_RE.search(text)) or "@[" in text
    skip_live_for_local_plan = is_approval_reply and bool((st["pending_plan"] or {}).get("local_only"))

    async with create_async_client() as client:
        if skip_live_for_local_plan:
            upstream_error = "local pending plan"
        else:
            try:
                resp = await client.post(url, json=body)
                if resp.status_code < 400:
                    data = resp.json()
                    wf = data.get("document_workflow") if isinstance(data, dict) else None
                    stage = str(wf.get("stage") or "").strip().lower() if isinstance(wf, dict) else ""

                    if isinstance(wf, dict) and stage in ("pending_approval", "awaiting_approval") or (
                        isinstance(wf, dict)
                        and wf.get("requires_approval") is True
                        and stage not in ("executed", "cancelled", "rejected", "no_verified_actions", "not_document_request", "not_found", "error")
                    ):
                        proposed = (
                            wf.get("steps")
                            or (wf.get("plan") or {}).get("actions")
                            or wf.get("actions")
                            or []
                        )
                        overridden_locally = False
                        has_multi_or_section = (
                            len(_split_chat_clauses(text)) > 1
                            or bool(re.search(r"\bsections?\s+[0-9a-zA-Z._-]+", text, re.IGNORECASE))
                            or bool(_INCLUDE_VERB_RE.search(text) and _EXCLUDE_VERB_RE.search(text))
                        )
                        if proposed and has_multi_or_section:
                            try:
                                _, _, _, local_catalog, _, _ = await _load_plan_bundle(plan_number)
                                default_op = (
                                    "include"
                                    if _INCLUDE_VERB_RE.search(text) and not _EXCLUDE_VERB_RE.search(text)
                                    else "exclude"
                                )
                                local_actions = _resolve_chat_targets(text, default_op, local_catalog)
                            except Exception:
                                local_actions = []

                            if local_actions:
                                live_ops = {str(a.get("action") or "").lower() for a in proposed if isinstance(a, dict)}
                                local_ops = {str(a.get("action") or "").lower() for a in local_actions}
                                live_has_sec = any(a.get("section_id") or a.get("section_title") for a in proposed if isinstance(a, dict))
                                local_has_sec = any(a.get("section_id") or a.get("section_title") for a in local_actions)
                                if (
                                    (len(local_ops) > 1 and len(live_ops) <= 1)
                                    or len(local_actions) > len(proposed)
                                    or (local_has_sec and not live_has_sec)
                                ):
                                    proposed = local_actions
                                    overridden_locally = True
                                    op_summary = "include/exclude" if len(local_ops) > 1 else next(iter(local_ops), default_op)
                                    data["answer"] = (
                                        f"Proposed {len(proposed)} {op_summary} action(s) for Plan {plan_number}. "
                                        "Review below and click **Approve & Execute** to update the Data Extraction feed."
                                    )

                        if proposed:
                            wf["stage"] = "awaiting_approval"
                            wf["actions"] = proposed
                            wf["steps"] = proposed
                            wf["plan"] = {"actions": proposed}
                            st["pending_plan"] = {
                                "plan_id": wf.get("plan_id") or f"live-{uuid.uuid4().hex[:8]}",
                                "actions": proposed,
                                "local_only": overridden_locally,
                            }
                            return data

                    if isinstance(wf, dict) and stage == "executed":
                        executed = (
                            (wf.get("execution") or {}).get("executed")
                            or wf.get("executed")
                            or (wf.get("execution_json") or {}).get("actions")
                            or (wf.get("plan") or {}).get("actions")
                            or wf.get("actions")
                            or wf.get("steps")
                            or (st["pending_plan"] or {}).get("actions")
                            or []
                        )
                        if executed:
                            affected_sections = _apply_actions_to_plan_state(plan_number, executed)
                            st["pending_plan"] = None
                            wf["stage"] = "executed"
                            wf["executed"] = executed
                            wf["actions"] = executed
                            wf["affected_sections"] = affected_sections
                            if str(wf.get("status") or "").lower() == "error" or "no document changes were applied" in str(data.get("answer") or "").lower():
                                summary_lines = [f"**Applied {len(executed)} change(s) to Plan {plan_number}** (synced with active Data Extraction feed):"]
                                for act in executed:
                                    op_name = str(act.get("action") or "exclude").lower()
                                    verb = "Included" if op_name in ("include", "restore") else "Excluded"
                                    target = f"{act.get('title')} › {act.get('section_title')}" if act.get("section_title") else (act.get("title") or act.get("filename") or "Target")
                                    summary_lines.append(f"- {verb} `{act.get('document_type', 'policy')}` **{target}**")
                                data["answer"] = "\n".join(summary_lines)
                            return data

                    if isinstance(wf, dict) and stage in ("cancelled", "rejected"):
                        st["pending_plan"] = None
                        return data

                    # Fall through to local workflow if live /qna/chat returned no verified actions for an explicit doc/approval request
                    if (is_approval_reply or is_doc_intent) and (
                        wf is None or stage in ("no_verified_actions", "not_document_request", "not_found", "error", "")
                    ):
                        if stage == "no_verified_actions":
                            live_no_verified_data = data
                        upstream_error = f"live stage={stage or 'none'}"
                    else:
                        return data
                else:
                    if resp.status_code not in (404, 502, 503, 504):
                        raise HTTPException(status_code=resp.status_code, detail=_extract_error_detail(resp))
                    upstream_error = f"HTTP {resp.status_code}: {_extract_error_detail(resp)}"
            except HTTPException:
                raise
            except Exception as exc:
                upstream_error = str(exc)

    logger.warning("Using demo workflow fallback for Plan %s (%s).", plan_number, upstream_error)

    # 2. Resilient workflow + Q&A fallback over loaded CT1 artifacts & catalog
    _, _, final_artifacts, catalog, _, _ = await _load_plan_bundle(plan_number)

    if st["pending_plan"] is not None:
        if re.match(r"^(approve|approved|yes|confirm|execute)\b", lower):
            pending = st["pending_plan"]
            st["pending_plan"] = None
            actions = pending["actions"]
            affected_sections = _apply_actions_to_plan_state(plan_number, actions)
            context_note = f"CT1 query-service: `{upstream_error}`" if upstream_error else "synced with active catalog"
            summary_lines = [
                f"**Applied {len(actions)} change(s) to Plan {plan_number}** ({context_note}):"
            ]
            for act in actions:
                op_name = str(act.get("action") or "exclude").lower()
                verb = "Included" if op_name in ("include", "restore") else "Excluded"
                target = f"{act.get('title')} › {act.get('section_title')}" if act.get("section_title") else (act.get("title") or act.get("filename") or "Target")
                summary_lines.append(f"- {verb} `{act.get('document_type', 'policy')}` **{target}**")
            return {
                "session_id": plan_number,
                "answer": "\n".join(summary_lines),
                "document_workflow": {
                    "stage": "executed",
                    "plan_id": pending["plan_id"],
                    "plan_number": plan_number,
                    "plan": {"actions": actions},
                    "actions": actions,
                    "executed": actions,
                    "affected_sections": affected_sections,
                },
            }
        if re.match(r"^(cancel|reject|rejected|no|abort)\b", lower):
            pending = st["pending_plan"]
            st["pending_plan"] = None
            return {
                "session_id": plan_number,
                "answer": "Cancelled the proposed document scope plan. Nothing was modified.",
                "document_workflow": {
                    "stage": "cancelled",
                    "plan_id": pending["plan_id"],
                    "plan_number": plan_number,
                    "plan": {"actions": pending["actions"]},
                },
            }

    is_include = bool(_INCLUDE_VERB_RE.search(text))
    is_exclude = bool(_EXCLUDE_VERB_RE.search(text))
    if is_exclude or is_include or "@[" in text:
        default_op = "include" if is_include and not is_exclude else "exclude"
        actions = _resolve_chat_targets(text, default_op, catalog)
        if not actions:
            if live_no_verified_data is not None:
                return live_no_verified_data
            return {
                "session_id": plan_number,
                "answer": "Could not match any document or section in the active catalog. Use `@` to select an exact item.",
                "document_workflow": None,
            }
        plan_id = f"fallback-{uuid.uuid4().hex[:8]}"
        st["pending_plan"] = {"plan_id": plan_id, "actions": actions, "local_only": True}
        ops = {str(a.get("action") or "").lower() for a in actions}
        op_label = "include/exclude" if len(ops) > 1 else next(iter(ops), default_op)
        return {
            "session_id": plan_number,
            "answer": (
                f"Proposed {len(actions)} {op_label} action(s) for Plan {plan_number}. "
                "Review below and click **Approve & Execute** to update the Data Extraction feed."
            ),
            "document_workflow": {
                "stage": "awaiting_approval",
                "plan_id": plan_id,
                "plan_number": plan_number,
                "plan": {"actions": actions},
                "actions": actions,
            },
        }

    return {
        "session_id": plan_number,
        "answer": _answer_general_qna_from_artifacts(plan_number, text, final_artifacts),
        "document_workflow": None,
    }


_RAG_FIELD_MAP: Dict[str, str] = {
    "policy": "policy_files",
    "kod": "kod_files",
    "procedure": "procedure_files",
}


class CategorizeIdsRequest(BaseModel):
    document_ids: List[int]


class RagRelevantDataRequest(BaseModel):
    review_id: Optional[str] = None
    plan_number: Optional[str] = None
    region: Optional[str] = None
    au_countries: Optional[List[str]] = None
    plan_item_title: Optional[str] = None
    plan_item_description: Optional[str] = None
    au_list: Optional[List[str]] = None
    rt_list: Optional[List[str]] = None
    kc_list: Optional[List[str]] = None
    control_name: Optional[List[str]] = None
    control_how: Optional[List[str]] = None
    control_what: Optional[List[str]] = None
    control_why: Optional[List[str]] = None
    documents: List[Dict[str, Any]] = []


def _infer_doc_type_from_filename(filename: str, explicit_type: str = "auto") -> str:
    """Resolve document category (`policy`, `kod`, or `procedure`) from explicit choice or filename."""
    raw = str(explicit_type or "auto").strip().lower()
    if raw and raw != "auto":
        normalized = _normalize_doc_type(raw)
        if normalized in _RAG_FIELD_MAP:
            return normalized

    stem = Path(filename or "").stem.lower()
    if re.search(r"(^|[^a-z0-9])kod([^a-z0-9]|$)|key[_\s-]+operating", stem):
        return "kod"
    if re.search(r"procedure|(^|[^a-z0-9])(proc|sop)([^a-z0-9]|$)", stem):
        return "procedure"
    return "policy"


def _extract_pdf_text_snippets(content: bytes) -> List[str]:
    """Best-effort lightweight text extraction from PDF bytes without requiring external packages."""
    try:
        import io
        import pypdf

        reader = pypdf.PdfReader(io.BytesIO(content), strict=False)
        chunks = []
        for idx, page in enumerate(reader.pages[:8], start=1):
            txt = (page.extract_text() or "").strip()
            if txt:
                chunks.append((idx, txt))
        if chunks:
            return [f"[Page {p}] {t}" for p, t in chunks]
    except Exception:
        pass

    raw_text = content.decode("latin-1", errors="ignore")
    lit_runs = re.findall(r"\(([^()\\]{12,240})\)\s*Tj", raw_text)
    cleaned = [re.sub(r"\s+", " ", s).strip() for s in lit_runs if re.search(r"[A-Za-z]{4,}", s)]
    if cleaned:
        return cleaned[:6]

    ascii_runs = re.findall(r"[A-Za-z][A-Za-z0-9 ,.;:()'\"/-]{24,220}", raw_text)
    skip_re = re.compile(r"\b(endobj|endstream|FlateDecode|FontDescriptor|MediaBox|Type|Catalog|xref|trailer)\b")
    filtered = [re.sub(r"\s+", " ", s).strip() for s in ascii_runs if not skip_re.search(s)]
    return filtered[:6]


def _extract_fallback_sections_from_upload(filename: str, content: bytes, doc_id: str) -> List[Dict[str, Any]]:
    """Derive selectable sections from JSON, Markdown/Text, or PDF upload bytes."""
    lower = filename.lower()
    if lower.endswith(".json"):
        try:
            parsed = json.loads(content.decode("utf-8"))
            if isinstance(parsed, dict):
                secs = _read_local_part_sections(parsed)
                if secs:
                    return secs
        except Exception:
            pass

    if lower.endswith((".txt", ".md")):
        decoded = content.decode("utf-8", errors="ignore").strip()
        blocks = [b.strip() for b in re.split(r"\n{2,}", decoded) if b.strip()][:8]
        if blocks:
            out: List[Dict[str, Any]] = []
            for idx, block in enumerate(blocks, start=1):
                first_line = block.splitlines()[0].lstrip("# ").strip()
                title = (first_line[:80] if first_line else f"Section {idx}")
                out.append(
                    {
                        "section_id": str(idx),
                        "section_title": title,
                        "node_id": f"{doc_id}:sec:{idx}",
                        "original_text": block[:600],
                        "status": "active",
                        "excluded": False,
                    }
                )
            return out

    if lower.endswith(".pdf"):
        snippets = _extract_pdf_text_snippets(content)
        if snippets:
            out = []
            for idx, snip in enumerate(snippets[:6], start=1):
                heading = snip.splitlines()[0][:72].strip()
                out.append(
                    {
                        "section_id": str(idx),
                        "section_title": heading or f"Section {idx}",
                        "node_id": f"{doc_id}:sec:{idx}",
                        "original_text": snip[:600],
                        "status": "active",
                        "excluded": False,
                    }
                )
            return out

    stem = Path(filename).stem or "Uploaded Document"
    return [
        {
            "section_id": "1",
            "section_title": f"{stem} — Full Document Scope",
            "node_id": f"{doc_id}:sec:1",
            "original_text": f"Indexed {filename} ({len(content)} bytes) into active plan scope.",
            "status": "active",
            "excluded": False,
        }
    ]


def _build_uploaded_doc_record(
    filename: str,
    content: bytes,
    doc_type: str,
    doc_id: Optional[Any] = None,
    custom_sections: Optional[List[Dict[str, Any]]] = None,
    storage_uri: Optional[str] = None,
) -> Dict[str, Any]:
    resolved_id = str(doc_id) if doc_id is not None else f"upload-{uuid.uuid4().hex[:6]}"
    title = Path(filename).stem
    if filename.lower().endswith(".json"):
        try:
            parsed = json.loads(content.decode("utf-8"))
            if isinstance(parsed, dict):
                title = str(parsed.get("document_title") or parsed.get("title") or title)
        except Exception:
            pass

    sections = custom_sections if custom_sections else _extract_fallback_sections_from_upload(filename, content, resolved_id)
    return {
        "document_id": resolved_id,
        "document_title": title,
        "document_name": title,
        "document_type": doc_type,
        "file_name": filename,
        "storage_uri": storage_uri or f"uploaded://{doc_type}/{filename}",
        "status": "active",
        "excluded": False,
        "sections": sections,
    }


def _upsert_uploaded_doc(plan_number: str, record: Dict[str, Any]) -> None:
    st = _get_plan_state(plan_number)
    dtype = _normalize_doc_type(record.get("document_type") or "policy")
    tkey = _norm_key(record.get("document_title"))
    st["uploaded_docs"] = [
        existing
        for existing in st["uploaded_docs"]
        if not (
            _normalize_doc_type(existing.get("document_type") or "policy") == dtype
            and _norm_key(existing.get("document_title")) == tkey
        )
    ]
    st["uploaded_docs"].append(record)
    if tkey:
        st["excluded_docs"].discard(f"{dtype}|{tkey}")


def _extract_rag_doc_ids(payload: Any) -> List[int]:
    """Collect numeric document IDs from diverse RAG service response shapes."""
    candidates: List[Any] = []
    if isinstance(payload, dict):
        for container in (payload, payload.get("result"), payload.get("data")):
            if not isinstance(container, dict):
                continue
            for key in ("document_ids", "doc_ids", "ids"):
                val = container.get(key)
                if isinstance(val, list):
                    candidates.extend(val)
            docs = container.get("documents")
            if isinstance(docs, list):
                for d in docs:
                    if isinstance(d, dict) and d.get("document_id") is not None:
                        candidates.append(d["document_id"])
                    elif isinstance(d, (int, str)):
                        candidates.append(d)

    seen: Set[int] = set()
    out: List[int] = []
    for item in candidates:
        if isinstance(item, bool):
            continue
        sval = str(item).strip()
        if sval.lstrip("-").isdigit():
            ival = int(sval)
            if ival not in seen:
                seen.add(ival)
                out.append(ival)
    return out


def _parse_categorize_response(raw_cat: Any) -> Dict[int, str]:
    """Normalize `/categorize-document-ids` output into `{doc_id: 'policy'|'kod'|'procedure'}`."""
    mapping: Dict[int, str] = {}
    if not isinstance(raw_cat, (dict, list)):
        return mapping

    def _absorb_item(item: Dict[str, Any], default_type: Optional[str] = None) -> None:
        raw_id = item.get("document_id") if item.get("document_id") is not None else item.get("id")
        raw_type = item.get("document_type") or item.get("category") or item.get("type") or default_type
        if raw_id is not None and str(raw_id).strip().lstrip("-").isdigit() and raw_type:
            norm_t = _normalize_doc_type(raw_type)
            if norm_t in _RAG_FIELD_MAP:
                mapping[int(str(raw_id).strip())] = norm_t

    containers: List[Any] = [raw_cat]
    if isinstance(raw_cat, dict):
        for nested_key in ("categorized", "categories", "document_categories", "results", "documents", "data"):
            if nested_key in raw_cat and raw_cat[nested_key] is not None:
                containers.append(raw_cat[nested_key])

    for node in containers:
        if isinstance(node, list):
            for entry in node:
                if isinstance(entry, dict):
                    _absorb_item(entry)
        elif isinstance(node, dict):
            for k, v in node.items():
                k_norm = _normalize_doc_type(k)
                if k_norm in _RAG_FIELD_MAP and isinstance(v, list):
                    for sub in v:
                        if isinstance(sub, dict):
                            _absorb_item(sub, default_type=k_norm)
                        elif str(sub).strip().lstrip("-").isdigit():
                            mapping[int(str(sub).strip())] = k_norm
                elif str(k).strip().lstrip("-").isdigit() and isinstance(v, str):
                    v_norm = _normalize_doc_type(v)
                    if v_norm in _RAG_FIELD_MAP:
                        mapping[int(str(k).strip())] = v_norm
    return mapping


def _build_rag_relevant_payload_from_artifacts(
    plan_number: str,
    artifacts: Dict[str, Any],
    documents_spec: List[Dict[str, Any]],
    overrides: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build `/get-relevant-data-for-documents` JSON body from CT1 `current_details` + `control_details`."""
    ov = {k: v for k, v in (overrides or {}).items() if v is not None}
    plan_det = (_unwrap_data_dict(artifacts.get("current_details")) or {}).get("plan_details") or {}
    if not isinstance(plan_det, dict):
        plan_det = {}
    ctrl_wrap = (_unwrap_data_dict(artifacts.get("control_details")) or {}).get("control_details") or {}
    controls = ctrl_wrap.get("included_kcs") if isinstance(ctrl_wrap, dict) and isinstance(ctrl_wrap.get("included_kcs"), list) else []

    def _split_list(val: Any) -> List[str]:
        if isinstance(val, list):
            return [str(x).strip() for x in val if str(x).strip()]
        if not val:
            return []
        sep = ";" if ";" in str(val) else ","
        return [p.strip() for p in str(val).split(sep) if p.strip()]

    au_rt_kc = plan_det.get("AU-RT-KC") if isinstance(plan_det.get("AU-RT-KC"), list) else []
    au_list = list(dict.fromkeys(str(r["AU"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("AU")))
    rt_list = list(dict.fromkeys(str(r["RT"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("RT")))
    kc_list = list(dict.fromkeys(str(r["KC"]).strip() for r in au_rt_kc if isinstance(r, dict) and r.get("KC")))
    if not rt_list and plan_det.get("UoT Risk Type"):
        rt_list = [str(plan_det["UoT Risk Type"]).split(" - ", 1)[0].strip()]
    if not kc_list and plan_det.get("UoT KCs"):
        kc_list = [str(plan_det["UoT KCs"]).split(" - ", 1)[0].strip()]

    c_names: List[str] = []
    c_how: List[str] = []
    c_what: List[str] = []
    c_why: List[str] = []
    for ctrl in controls:
        if not isinstance(ctrl, dict):
            continue
        inv = ctrl.get("inventory") if isinstance(ctrl.get("inventory"), dict) else {}
        defn = ctrl.get("definition") if isinstance(ctrl.get("definition"), dict) else {}
        det = ctrl.get("details") if isinstance(ctrl.get("details"), dict) else {}
        nm = (
            inv.get("controlDefinitionName")
            or defn.get("controlDefinitionName")
            or det.get("control_name")
            or inv.get("controlDefinitionNumber")
        )
        hw = det.get("control_how") or inv.get("controlHow") or defn.get("controlHow")
        wh = det.get("control_what") or inv.get("controlWhat") or defn.get("controlWhat")
        wy = det.get("control_why") or inv.get("controlWhy") or defn.get("controlWhy")
        for bucket, val in ((c_names, nm), (c_how, hw), (c_what, wh), (c_why, wy)):
            if val and str(val).strip() and str(val).strip() not in bucket:
                bucket.append(str(val).strip())

    return {
        "review_id": str(ov.get("review_id") or plan_number),
        "region": str(ov.get("region") or plan_det.get("AU Region") or plan_det.get("UoT Regions") or "").strip(),
        "au_countries": ov.get("au_countries") if "au_countries" in ov else _split_list(plan_det.get("UoT Countries")),
        "plan_item_title": str(ov.get("plan_item_title") or plan_det.get("Plan Item Title") or "").strip(),
        "plan_item_description": str(ov.get("plan_item_description") or plan_det.get("Description of Plan Item") or "").strip(),
        "au_list": ov.get("au_list") if "au_list" in ov else au_list,
        "rt_list": ov.get("rt_list") if "rt_list" in ov else rt_list,
        "kc_list": ov.get("kc_list") if "kc_list" in ov else kc_list,
        "control_name": ov.get("control_name") if "control_name" in ov else c_names,
        "control_how": ov.get("control_how") if "control_how" in ov else c_how,
        "control_what": ov.get("control_what") if "control_what" in ov else c_what,
        "control_why": ov.get("control_why") if "control_why" in ov else c_why,
        "documents": documents_spec,
    }


def _normalize_rag_section_list(raw_sections: Any, prefix: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if not isinstance(raw_sections, list):
        return out
    for idx, sec in enumerate(raw_sections, start=1):
        if isinstance(sec, str):
            text = sec.strip()
            if not text:
                continue
            out.append(
                {
                    "section_id": str(idx),
                    "section_title": text.splitlines()[0][:80],
                    "node_id": f"{prefix}:sec:{idx}",
                    "original_text": text[:800],
                    "status": "active",
                    "excluded": False,
                }
            )
        elif isinstance(sec, dict):
            sid = str(sec.get("section_id") or sec.get("id") or idx)
            stitle = str(
                sec.get("section_title")
                or sec.get("title")
                or sec.get("heading")
                or (sec.get("section_path") or "").split(">")[-1]
                or f"Section {sid}"
            ).strip()
            body = str(sec.get("original_text") or sec.get("content") or sec.get("text") or sec.get("chunk_text") or stitle).strip()
            item: Dict[str, Any] = {
                "section_id": sid,
                "section_title": stitle,
                "node_id": str(sec.get("node_id") or f"{prefix}:sec:{sid}"),
                "original_text": body[:800],
                "status": "active",
                "excluded": False,
            }
            if sec.get("section_path"):
                item["section_path"] = sec["section_path"]
            if sec.get("page_start") is not None:
                item["page_start"] = sec["page_start"]
            out.append(item)
    return out


def _extract_sections_from_rag_relevant_data(rag_resp: Any) -> Dict[str, List[Dict[str, Any]]]:
    """Extract normalized section lists keyed by doc_id (`str(id)`) or fallback `document_type`."""
    by_key: Dict[str, List[Dict[str, Any]]] = {}
    if not isinstance(rag_resp, (dict, list)):
        return by_key

    items: List[Tuple[Optional[str], Dict[str, Any]]] = []
    if isinstance(rag_resp, list):
        items.extend((None, x) for x in rag_resp if isinstance(x, dict))
    else:
        for container_key in ("results", "documents", "relevant_documents", "referenced_documents"):
            val = rag_resp.get(container_key)
            if isinstance(val, list):
                items.extend((None, x) for x in val if isinstance(x, dict))
            elif isinstance(val, dict):
                for dtype, sub in val.items():
                    if isinstance(sub, list):
                        items.extend((_normalize_doc_type(dtype), x) for x in sub if isinstance(x, dict))
        for dtype in ("policy", "kod", "procedure"):
            if isinstance(rag_resp.get(dtype), list):
                items.extend((dtype, x) for x in rag_resp[dtype] if isinstance(x, dict))

    for hinted_type, entry in items:
        nested_docs = entry.get("referenced_documents") or entry.get("documents")
        if isinstance(nested_docs, list):
            for sub in nested_docs:
                if isinstance(sub, dict):
                    items.append((hinted_type or entry.get("document_type"), sub))
        raw_id = entry.get("document_id") if entry.get("document_id") is not None else entry.get("id")
        dtype = _normalize_doc_type(entry.get("document_type") or hinted_type or "policy")
        key_id = str(raw_id).strip() if raw_id is not None else None
        raw_secs = (
            entry.get("sections")
            or entry.get("relevant_sections")
            or entry.get("chunks")
            or entry.get("paragraphs")
        )
        prefix = f"rag-{key_id}" if key_id else f"rag-{dtype}"
        norm_secs = _normalize_rag_section_list(raw_secs, prefix=prefix)
        if not norm_secs and (entry.get("content") or entry.get("text") or entry.get("section_title")):
            norm_secs = _normalize_rag_section_list([entry], prefix=prefix)
        if norm_secs:
            if key_id:
                by_key.setdefault(key_id, []).extend(norm_secs)
            by_key.setdefault(dtype, []).extend(norm_secs)
    return by_key


async def _fetch_plan_context_artifacts(client: httpx.AsyncClient, plan_number: str) -> Dict[str, Any]:
    """Fetch `current_details` + `control_details` for RAG query context, with sample fallback."""
    cur_res, ctrl_res = await asyncio.gather(
        _fetch_artifact_safe(client, plan_number, "current_details"),
        _fetch_artifact_safe(client, plan_number, "control_details"),
    )
    artifacts: Dict[str, Any] = {}
    if cur_res.get("ok"):
        artifacts["current_details"] = cur_res["data"]
    if ctrl_res.get("ok"):
        artifacts["control_details"] = ctrl_res["data"]
    if len(artifacts) < 2:
        _, sample_artifacts = _load_samples_for_plan(plan_number)
        for key in ("current_details", "control_details"):
            if key not in artifacts and key in sample_artifacts:
                artifacts[key] = sample_artifacts[key]
    return artifacts


async def _ingest_and_categorize_uploads(
    plan_number: str,
    explicit_doc_type: str,
    raw_uploads: List[Tuple[str, bytes, str, str]],
) -> Dict[str, Any]:
    """
    Execute the 4-stage CT1 RAG pipeline (`/ingest-documents` -> `/ingest-jobs/{id}` ->
    `/categorize-document-ids` -> `/get-relevant-data-for-documents`) with seamless local
    fallback when CT1 endpoints are unreachable or return 5xx.
    """
    form_files = [(_RAG_FIELD_MAP.get(dtype, "policy_files"), (fname, content, ctype)) for fname, content, ctype, dtype in raw_uploads]
    rag_mode = "local_auto_ingest"
    job_id = ""
    doc_ids: List[int] = []
    cat_map: Dict[int, str] = {}
    rag_sections_by_key: Dict[str, List[Dict[str, Any]]] = {}

    ingest_url = f"{RAG_SERVICE_BASE}/ingest-documents"
    async with create_async_client() as client:
        try:
            resp = await client.post(ingest_url, files=form_files, timeout=30.0)
            if resp.status_code < 400:
                rag_mode = "ct1_rag_service"
                try:
                    ingest_data = resp.json()
                except Exception:
                    ingest_data = {}
                if not isinstance(ingest_data, dict):
                    ingest_data = {}
                job_id = str(ingest_data.get("job_id") or ingest_data.get("jobId") or ingest_data.get("id") or "").strip()
                doc_ids = _extract_rag_doc_ids(ingest_data)

                # Stage 2: Poll job status if job_id returned without document_ids
                if job_id and not doc_ids:
                    job_url = f"{RAG_SERVICE_BASE}/ingest-jobs/{job_id}"
                    for attempt in range(3):
                        try:
                            j_resp = await client.get(job_url)
                            if j_resp.status_code >= 400:
                                break
                            j_data = j_resp.json()
                            doc_ids = _extract_rag_doc_ids(j_data)
                            j_status = str((j_data or {}).get("status") or "").strip().lower()
                            if doc_ids or j_status in ("completed", "done", "success", "succeeded", "failed", "error"):
                                break
                        except Exception as poll_exc:
                            logger.debug("CT1 RAG job poll failed (%s): %s", job_id, poll_exc)
                            break
                        if attempt < 2:
                            await asyncio.sleep(0.15)

                # Stage 3: Auto-categorize returned document IDs
                if doc_ids:
                    try:
                        cat_resp = await client.post(
                            f"{RAG_SERVICE_BASE}/categorize-document-ids",
                            json={"document_ids": doc_ids},
                            timeout=20.0,
                        )
                        if cat_resp.status_code < 400:
                            cat_map = _parse_categorize_response(cat_resp.json())
                    except Exception as cat_exc:
                        logger.debug("CT1 RAG categorize-document-ids skipped: %s", cat_exc)

                # Stage 4: Retrieve relevant sections/chunks automatically for plan context
                explicit_lower = str(explicit_doc_type or "auto").strip().lower()
                if doc_ids:
                    grouped_ids: Dict[str, List[int]] = {}
                    for idx, did in enumerate(doc_ids):
                        fallback_t = raw_uploads[idx][3] if idx < len(raw_uploads) else raw_uploads[0][3]
                        resolved_t = cat_map.get(did, fallback_t) if explicit_lower in ("", "auto") else fallback_t
                        grouped_ids.setdefault(resolved_t, []).append(did)
                    docs_spec = [
                        {"document_type": dtype, "document_ids": ids, "top_k": 5}
                        for dtype, ids in grouped_ids.items()
                    ]
                    try:
                        ctx_artifacts = await _fetch_plan_context_artifacts(client, plan_number)
                        rel_payload = _build_rag_relevant_payload_from_artifacts(plan_number, ctx_artifacts, docs_spec)
                        rel_resp = await client.post(
                            f"{RAG_SERVICE_BASE}/get-relevant-data-for-documents",
                            json=rel_payload,
                            timeout=30.0,
                        )
                        if rel_resp.status_code < 400:
                            rag_sections_by_key = _extract_sections_from_rag_relevant_data(rel_resp.json())
                    except Exception as rel_exc:
                        logger.debug("CT1 RAG get-relevant-data-for-documents skipped: %s", rel_exc)
            else:
                logger.warning("CT1 RAG /ingest-documents returned HTTP %s; registering locally.", resp.status_code)
        except Exception as exc:
            logger.warning("CT1 RAG /ingest-documents unreachable (%s); registering locally.", exc)

    explicit_lower = str(explicit_doc_type or "auto").strip().lower()
    created_records: List[Dict[str, Any]] = []
    categorized_summary: Dict[str, List[str]] = {}
    for idx, (fname, content, _, init_dtype) in enumerate(raw_uploads):
        assigned_id: Optional[int] = doc_ids[idx] if idx < len(doc_ids) else None
        if explicit_lower in ("", "auto") and assigned_id is not None and assigned_id in cat_map:
            final_dtype = cat_map[assigned_id]
        else:
            final_dtype = init_dtype

        custom_secs = None
        if assigned_id is not None:
            custom_secs = rag_sections_by_key.get(str(assigned_id))
        if not custom_secs:
            custom_secs = rag_sections_by_key.get(final_dtype)

        record = _build_uploaded_doc_record(
            filename=fname,
            content=content,
            doc_type=final_dtype,
            doc_id=assigned_id,
            custom_sections=custom_secs,
        )
        _upsert_uploaded_doc(plan_number, record)
        created_records.append(record)
        categorized_summary.setdefault(final_dtype, []).append(record["document_title"])

    primary_dtype = created_records[0]["document_type"] if created_records else "policy"
    total_sections = sum(len(r.get("sections") or []) for r in created_records)
    resolved_job_id = job_id or f"local-{uuid.uuid4().hex[:8]}"
    cat_desc = ", ".join(f"{k}: {', '.join(v)}" for k, v in categorized_summary.items())

    if rag_mode == "ct1_rag_service":
        status_val = "ingested"
        msg = (
            f"Ingested via CT1 RAG ({cat_desc}) with {total_sections} indexed section(s). "
            "Stored in the active catalog and Policies / KOD / Proc feed — use @ to reference or exclude."
        )
    else:
        status_val = "ingested_local"
        msg = (
            f"Registered locally into active Plan {plan_number} catalog & Policies / KOD / Proc feed "
            f"({cat_desc}; {total_sections} indexed section(s)). CT1 RAG service is offline/restarting, "
            "so local auto-categorization & section indexing were applied."
        )

    return {
        "status": status_val,
        "rag_mode": rag_mode,
        "job_id": resolved_job_id,
        "plan_number": plan_number,
        "document_type": primary_dtype,
        "stored_in_artifact": "policy",
        "document_ids": doc_ids,
        "categorized": categorized_summary,
        "files_uploaded": [r["file_name"] for r in created_records],
        "documents": [
            {
                "document_id": r["document_id"],
                "document_title": r["document_title"],
                "document_type": r["document_type"],
                "file_name": r["file_name"],
                "storage_uri": r["storage_uri"],
                "section_count": len(r.get("sections") or []),
            }
            for r in created_records
        ],
        "message": msg,
    }


async def _handle_upload_ingest(
    plan_number: str,
    document_type: str,
    files: List[UploadFile],
    policy_files: List[UploadFile],
    kod_files: List[UploadFile],
    procedure_files: List[UploadFile],
) -> Dict[str, Any]:
    raw_uploads: List[Tuple[str, bytes, str, str]] = []
    for typed_group, upload_list in (
        ("policy", policy_files),
        ("kod", kod_files),
        ("procedure", procedure_files),
    ):
        for upload in upload_list:
            content = await upload.read()
            fname = upload.filename or f"{typed_group}.pdf"
            ctype = upload.content_type or "application/pdf"
            raw_uploads.append((fname, content, ctype, typed_group))

    for upload in files:
        content = await upload.read()
        fname = upload.filename or "document.pdf"
        ctype = upload.content_type or "application/pdf"
        inferred = _infer_doc_type_from_filename(fname, document_type)
        raw_uploads.append((fname, content, ctype, inferred))

    if not raw_uploads:
        raise HTTPException(status_code=400, detail="At least one file is required.")

    return await _ingest_and_categorize_uploads(plan_number, document_type, raw_uploads)


@app.post("/api/ct1/query/ingest")
async def proxy_query_ingest(
    plan_number: str = Form(DEFAULT_PLAN_NUMBER),
    document_type: str = Form("auto"),
    files: List[UploadFile] = File(default=[]),
    policy_files: List[UploadFile] = File(default=[]),
    kod_files: List[UploadFile] = File(default=[]),
    procedure_files: List[UploadFile] = File(default=[]),
) -> Dict[str, Any]:
    """Ingest uploaded documents via CT1 `/dbaware-rag-service-api-dev/ingest-documents` workflow and sync into demo state."""
    return await _handle_upload_ingest(plan_number, document_type, files, policy_files, kod_files, procedure_files)


@app.post("/api/ct1/rag/ingest-documents")
async def proxy_rag_ingest_documents(
    plan_number: str = Form(DEFAULT_PLAN_NUMBER),
    document_type: str = Form("auto"),
    files: List[UploadFile] = File(default=[]),
    policy_files: List[UploadFile] = File(default=[]),
    kod_files: List[UploadFile] = File(default=[]),
    procedure_files: List[UploadFile] = File(default=[]),
) -> Dict[str, Any]:
    """Direct alias for CT1 `/dbaware-rag-service-api-dev/ingest-documents` workflow."""
    return await _handle_upload_ingest(plan_number, document_type, files, policy_files, kod_files, procedure_files)


@app.get("/api/ct1/rag/ingest-jobs/{job_id}")
async def proxy_rag_job_status(job_id: str) -> Dict[str, Any]:
    """Check RAG ingestion job status via CT1 `/dbaware-rag-service-api-dev/ingest-jobs/{job_id}`."""
    if job_id.startswith("local-"):
        return {"job_id": job_id, "status": "completed", "rag_mode": "local_auto_ingest"}
    url = f"{RAG_SERVICE_BASE}/ingest-jobs/{job_id}"
    async with create_async_client() as client:
        try:
            resp = await client.get(url)
            if resp.status_code < 400:
                data = resp.json()
                if isinstance(data, dict):
                    data.setdefault("job_id", job_id)
                return data
        except Exception as exc:
            logger.debug("CT1 RAG /ingest-jobs/%s fallback (%s)", job_id, exc)
    return {"job_id": job_id, "status": "unavailable_local_fallback"}


@app.post("/api/ct1/rag/categorize-document-ids")
async def proxy_rag_categorize_ids(payload: CategorizeIdsRequest) -> Dict[str, Any]:
    """Categorize RAG document IDs via CT1 `/dbaware-rag-service-api-dev/categorize-document-ids`."""
    url = f"{RAG_SERVICE_BASE}/categorize-document-ids"
    async with create_async_client() as client:
        try:
            resp = await client.post(url, json={"document_ids": payload.document_ids}, timeout=20.0)
            if resp.status_code < 400:
                return resp.json()
        except Exception as exc:
            logger.debug("CT1 RAG /categorize-document-ids fallback (%s)", exc)
    return {
        "status": "local_fallback",
        "categorized": {"policy": payload.document_ids, "kod": [], "procedure": []},
    }


@app.post("/api/ct1/rag/get-relevant-data-for-documents")
async def proxy_rag_relevant_data(payload: RagRelevantDataRequest) -> Dict[str, Any]:
    """Fetch relevant sections via CT1 `/dbaware-rag-service-api-dev/get-relevant-data-for-documents`."""
    plan_num = str(payload.review_id or payload.plan_number or DEFAULT_PLAN_NUMBER).strip()
    async with create_async_client() as client:
        ctx_artifacts = await _fetch_plan_context_artifacts(client, plan_num)
        overrides = payload.model_dump(exclude={"plan_number", "documents"}, exclude_none=True)
        body = _build_rag_relevant_payload_from_artifacts(plan_num, ctx_artifacts, payload.documents, overrides=overrides)
        try:
            resp = await client.post(
                f"{RAG_SERVICE_BASE}/get-relevant-data-for-documents",
                json=body,
                timeout=30.0,
            )
            if resp.status_code < 400:
                return resp.json()
        except Exception as exc:
            logger.debug("CT1 RAG /get-relevant-data-for-documents fallback (%s)", exc)
    return {"status": "local_fallback", "review_id": plan_num, "results": []}


@app.get("/")
async def index() -> FileResponse:
    """Serve the demo UI single-page app."""
    return FileResponse(STATIC_DIR / "index.html")


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8095"))
    uvicorn.run(app, host="0.0.0.0", port=port)
