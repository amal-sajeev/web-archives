"""Tests for the CT1 API Gateway-only Demo UI proxy server & API Terminal trace capture."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx
import pytest

CT1_UI_DIR = Path(__file__).resolve().parents[1]
if str(CT1_UI_DIR) not in sys.path:
    sys.path.insert(0, str(CT1_UI_DIR))

import server

STATIC_DIR = CT1_UI_DIR / "static"

SAMPLE_REPORT: Dict[str, Any] = {
    "Past Review Analysis": {
        "report_title": "Past Review Analysis",
        "current_review_id": "20429",
        "similar_review_count": 1,
        "historical_reviews": [
            {"historical_review_id": "13224", "review_title": "Prior Review", "assessments": []}
        ],
    },
    "Policy, KOD and Regulatory Analysis": {
        "report_title": "Policy, KOD and Regulatory Analysis",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": "**Section 1: Policy Analysis**\nRelevant policy summary.",
                "supporting_chunk_ids": ["4"],
                "metadata": {"is_section_start": True, "section_confidence_score": 88},
            }
        ],
    },
    "Broad Scope Direction": {
        "report_title": "Broad Scope Direction",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": "**Section 1: Broad Scope Direction**\nScope direction.",
                "supporting_chunk_ids": ["1"],
                "metadata": {"is_section_start": True, "section_confidence_score": 82},
            }
        ],
    },
}

SAMPLE_CATALOG: Dict[str, Any] = {
    "plan_number": "20429",
    "document_groups": [
        {
            "document_type": "policy",
            "documents": [
                {
                    "document_id": "pol-1",
                    "document_title": "Access_Control_Policy",
                    "file_name": "policy1.json",
                    "status": "active",
                    "excluded": False,
                    "sections": [
                        {
                            "section_id": "1",
                            "section_title": "Access Governance",
                            "status": "active",
                            "excluded": False,
                        }
                    ],
                }
            ],
        },
        {"document_type": "kod", "documents": []},
        {"document_type": "procedure", "documents": []},
    ],
    "total_count": 1,
    "source": "gcs",
}


class _FakeResponse:
    def __init__(
        self,
        status_code: int,
        payload: Any,
        *,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ):
        self.status_code = status_code
        self._payload = payload
        self.text = (
            payload
            if isinstance(payload, str)
            else (json.dumps(payload) if payload is not None else "")
        )
        self.content = content if content is not None else self.text.encode("utf-8")
        self.headers = headers or {"content-type": "application/json"}

    def json(self) -> Any:
        if isinstance(self._payload, str):
            raise ValueError("not json")
        return self._payload


class _GatewayMockClient:
    """Mocks ONLY API Gateway endpoints and records every outbound call for strict assertion."""

    def __init__(self, recorder: List[Dict[str, Any]], *, multi_poll: bool = True):
        self.recorder = recorder
        self.multi_poll = multi_poll
        self.job_poll_count = 0
        self.last_uploaded_files: List[Tuple[str, str]] = []
        self.last_file_types: Dict[str, str] = {}

    async def __aenter__(self) -> "_GatewayMockClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def get(self, url: str, headers: Any = None, timeout: Any = None) -> _FakeResponse:
        self.recorder.append({"method": "GET", "url": url, "headers": headers})
        if url.endswith("/openapi.json"):
            return _FakeResponse(200, {"openapi": "3.1.0", "info": {"title": "dbaware-api-gateway"}})
        if "/api/v1/task/status/" in url:
            return _FakeResponse(
                200,
                {
                    "processInstanceId": "proc-20429",
                    "taskId": "task-20429",
                    "taskDefinitionKey": "review_scope_definition",
                    "owner": "tester@db.com",
                    "variables": json.dumps({"review_scope_id": "901"}),
                },
            )
        return _FakeResponse(404, {"detail": f"Unexpected GET {url}"})

    async def post(
        self,
        url: str,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        headers: Any = None,
        timeout: Any = None,
    ) -> _FakeResponse:
        self.recorder.append(
            {
                "method": "POST",
                "url": url,
                "json": json,
                "data": data,
                "files": files,
                "headers": headers,
            }
        )
        plan_status_hdr = {
            "content-type": "application/json",
            "x-plan-status": json_dumps({"planNumber": "20429", "taskDefinitionKey": "pr_review"}),
        }

        if url.endswith("/api/v1/actions/upload"):
            assert data is not None
            action = data.get("action")
            raw_payload = json_loads(data.get("payload") or "{}")
            self.last_file_types = dict(raw_payload.get("file_types") or {})
            self.last_uploaded_files = [
                (part[0], part[1][0]) for part in (files or []) if isinstance(part, tuple)
            ]
            if action == "QNA_INGEST_DOCUMENTS":
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "status": "accepted",
                            "job_id": "job-multi-123",
                            "document_ids": [],
                            "plan_number": data.get("planNumber"),
                            "message": "Submitted to RAG",
                            "details": {
                                "status": "in_progress",
                                "summary": {"total": len(self.last_uploaded_files), "in_progress": len(self.last_uploaded_files)},
                            },
                        }
                    },
                    headers=plan_status_hdr,
                )
            return _FakeResponse(400, {"detail": f"Unsupported upload action {action}"})

        if url.endswith("/api/v1/actions/download"):
            assert json and json.get("action") == "DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT"
            return _FakeResponse(
                200,
                None,
                content=b"%PDF-1.4\n%fake-pr-pdf\n",
                headers={
                    "content-type": "application/pdf",
                    "content-disposition": 'attachment; filename="PR_20429.pdf"',
                    "x-plan-status": json_dumps({"planNumber": "20429"}),
                },
            )

        if url.endswith("/api/v1/actions"):
            action = (json or {}).get("action")
            plan = (json or {}).get("planNumber")
            payload = (json or {}).get("payload") or {}

            if action == "GET_PLAN_AVAILABILITY":
                return _FakeResponse(200, {"response": {"plan_number": plan, "available": True}}, headers=plan_status_hdr)
            if action == "GET_PLAN_ARTIFACT":
                art = payload.get("artifact")
                return _FakeResponse(
                    200,
                    {"response": {"plan_number": plan, "artifact": art, "data": {}}},
                    headers=plan_status_hdr,
                )
            if action == "DATA_EXTRACTION":
                return _FakeResponse(200, {"response": {"session_id": "sess-99", "status": "started"}}, headers=plan_status_hdr)
            if action == "GET_DATA_EXTRACTION_STATUS":
                return _FakeResponse(
                    200,
                    {"response": {"session_id": payload.get("session_id"), "status": "completed"}},
                    headers=plan_status_hdr,
                )
            if action == "QNA_LIST_DOCUMENTS":
                return _FakeResponse(200, {"response": SAMPLE_CATALOG}, headers=plan_status_hdr)
            if action == "QNA_CHAT":
                return _FakeResponse(
                    200,
                    {"response": {"session_id": plan, "answer": "Summary of risks via API Gateway."}},
                    headers=plan_status_hdr,
                )
            if action == "DOCUMENT_ADD_REMOVE":
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "answer": "Please approve excluding Access_Control_Policy.",
                            "document_workflow": {
                                "stage": "pending_approval",
                                "requires_approval": True,
                                "steps": [
                                    {
                                        "action": "exclude",
                                        "document_type": "policy",
                                        "title": "Access_Control_Policy",
                                    }
                                ],
                            },
                        }
                    },
                    headers=plan_status_hdr,
                )
            if action == "QNA_GET_INGEST_JOB_STATUS":
                self.job_poll_count += 1
                uploaded_names = [fname for _, fname in self.last_uploaded_files]
                if self.multi_poll and self.job_poll_count == 1 and len(uploaded_names) > 1:
                    # Simulate 1 file finished while others are still in_progress!
                    first_name = uploaded_names[0]
                    return _FakeResponse(
                        200,
                        {
                            "response": {
                                "job_id": payload.get("job_id"),
                                "status": "in_progress",
                                "document_ids": [501],
                                "details": {
                                    "status": "in_progress",
                                    "summary": {
                                        "total": len(uploaded_names),
                                        "indexed": 1,
                                        "in_progress": len(uploaded_names) - 1,
                                        "already_indexed": 0,
                                        "invalid": 0,
                                        "failed": 0,
                                    },
                                    "indexed": [
                                        {
                                            "filename": first_name,
                                            "document_id": 501,
                                            "document_type": self.last_file_types.get(first_name, "policy"),
                                        }
                                    ],
                                    "in_progress": [{"filename": n} for n in uploaded_names[1:]],
                                },
                            }
                        },
                        headers=plan_status_hdr,
                    )
                indexed_items = [
                    {
                        "filename": fname,
                        "document_id": 501 + idx,
                        "document_type": self.last_file_types.get(fname, "policy"),
                    }
                    for idx, fname in enumerate(uploaded_names)
                ]
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "job_id": payload.get("job_id"),
                            "status": "completed",
                            "document_ids": [it["document_id"] for it in indexed_items],
                            "details": {
                                "status": "completed",
                                "summary": {
                                    "total": len(indexed_items),
                                    "queued": len(indexed_items),
                                    "indexed": len(indexed_items),
                                    "in_progress": 0,
                                    "already_indexed": 0,
                                    "invalid": 0,
                                    "failed": 0,
                                },
                                "indexed": indexed_items,
                                "in_progress": [],
                                "already_indexed": [],
                                "invalid": [],
                                "failed": [],
                            },
                        }
                    },
                    headers=plan_status_hdr,
                )
            if action == "QNA_GET_RELEVANT_DATA":
                docs_payload = payload.get("documents") or []
                results_list = []
                for spec in docs_payload:
                    dtype = spec.get("document_type", "policy")
                    for did in spec.get("document_ids") or []:
                        results_list.append(
                            {
                                "document_id": did,
                                "document_type": dtype,
                                "document_title": f"Doc_{dtype}_{did}",
                                "storage_uri": f"gs://bucket/{dtype}_{did}.pdf",
                                "document_relevance_verdict": "HIGH",
                                "document_relevance_score": 0.91,
                                "rationale": f"Highly relevant {dtype} control text.",
                                "nodes": [
                                    {
                                        "section_id": "1",
                                        "section_title": f"Key {dtype.upper()} Section",
                                        "node_id": f"n-{did}-1",
                                        "original_text": "Detailed requirement text.",
                                    }
                                ],
                            }
                        )
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "status": "success",
                            "plan_number": plan,
                            "review_id": plan,
                            "registry_updated": True,
                            "persisted_files": [f"{r['document_type']}{r['document_id']}.json" for r in results_list],
                            "results": results_list,
                        }
                    },
                    headers=plan_status_hdr,
                )
            if action in (
                "GET_PRELIMINARY_RESEARCH_DOCUMENT",
                "RUN_ANALYTICS",
                "EDIT_PRELIMINARY_RESEARCH_DOCUMENT",
            ):
                return _FakeResponse(
                    200,
                    {"response": {"plan_number": plan, "analysis_report": SAMPLE_REPORT}},
                    headers=plan_status_hdr,
                )
            if action == "GET_CITATION_DOCUMENT":
                return _FakeResponse(
                    200,
                    {"response": {"type": "json", "content": {"chunk_id": payload.get("chunk_id")}}},
                    headers=plan_status_hdr,
                )
            if action == "ACCEPT_PRELIMINARY_RESEARCH":
                return _FakeResponse(
                    200,
                    {"status": "accepted", "planNumber": plan},
                    headers=plan_status_hdr,
                )
            return _FakeResponse(400, {"detail": f"Unexpected gateway action: {action}"})

        return _FakeResponse(404, {"detail": f"Unexpected POST {url}"})


def json_dumps(obj: Any) -> str:
    return json.dumps(obj)


def json_loads(raw: str) -> Any:
    return json.loads(raw)


@pytest.fixture
def gateway_recorder(monkeypatch):
    recorder: List[Dict[str, Any]] = []
    mock_client = _GatewayMockClient(recorder)
    server._API_TRACE_LOG.clear()
    monkeypatch.setattr(server, "create_async_client", lambda: mock_client)
    monkeypatch.setattr(server, "RAG_INGEST_POLL_INTERVAL_SECONDS", 0.01)
    monkeypatch.setattr(server, "CT1_RC_TOKEN", "secret-token-value-123")
    return recorder, mock_client


def _assert_all_calls_are_gateway_only(recorder: List[Dict[str, Any]]) -> None:
    assert len(recorder) > 0
    for call in recorder:
        assert call["url"].startswith(server.GATEWAY_BASE), f"Non-gateway URL detected: {call['url']}"


@pytest.mark.asyncio
async def test_config_and_full_gateway_only_endpoints(gateway_recorder):
    recorder, _ = gateway_recorder
    transport = httpx.ASGITransport(app=server.app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        cfg = (await client.get("/api/config")).json()
        assert cfg["gateway_only"] is True
        assert cfg["gateway_base"] == server.GATEWAY_BASE
        assert cfg["upload_limits"]["max_files"] == 5

        boot = await client.get("/api/ct1/plan/20429/bootstrap")
        assert boot.status_code == 200
        bdata = boot.json()
        assert bdata["gateway_only"] is True
        assert bdata["query_mode"] == "api_gateway"
        assert bdata["preliminary_research"]["available"] is True

        # Chat Q&A and Document Add/Remove
        qa = await client.post("/api/ct1/query/chat", json={"question": "Summarize risks", "plan_number": "20429"})
        assert qa.status_code == 200
        assert "API Gateway" in qa.json()["answer"]

        ar = await client.post(
            "/api/ct1/query/add-remove",
            json={"user_text": "Exclude Access_Control_Policy", "plan_number": "20429"},
        )
        assert ar.status_code == 200
        assert ar.json()["document_workflow"]["stage"] == "awaiting_approval"

        # Data Extraction
        ex_run = await client.post("/api/ct1/dataextraction/run", json={"planNumber": "20429"})
        assert ex_run.status_code == 200
        ex_st = await client.get("/api/ct1/dataextraction/status/sess-99?plan_number=20429")
        assert ex_st.status_code == 200
        art = await client.get("/api/ct1/dataextraction/20429/policy")
        assert art.status_code == 200

        # Preliminary Research lifecycle
        health = await client.get("/api/ct1/preliminary-research/health")
        assert health.status_code == 200
        gen = await client.post("/api/ct1/preliminary-research/generate", json={"planNumber": "20429"})
        assert gen.status_code == 200
        edit = await client.post(
            "/api/ct1/preliminary-research/edit",
            json={"planNumber": "20429", "analysis_report": SAMPLE_REPORT},
        )
        assert edit.status_code == 200
        doc = await client.post(
            "/api/ct1/preliminary-research/document",
            json={"planNumber": "20429", "chunk_id": "4"},
        )
        assert doc.status_code == 200
        dl = await client.post("/api/ct1/preliminary-research/download", json={"planNumber": "20429"})
        assert dl.status_code == 200
        assert dl.content.startswith(b"%PDF-1.4")
        acc = await client.post("/api/ct1/preliminary-research/accept", json={"planNumber": "20429"})
        assert acc.status_code == 200

        # Verify trace endpoint captured every upstream call and redacted auth token
        trace_resp = await client.get("/api/ct1/trace")
        assert trace_resp.status_code == 200
        trace_data = trace_resp.json()
        assert len(trace_data["entries"]) == len(recorder)
        actions_seen = {e["action"] for e in trace_data["entries"] if e["action"]}
        assert {
            "GET_PLAN_AVAILABILITY",
            "GET_PLAN_ARTIFACT",
            "QNA_LIST_DOCUMENTS",
            "GET_PRELIMINARY_RESEARCH_DOCUMENT",
            "QNA_CHAT",
            "DOCUMENT_ADD_REMOVE",
            "DATA_EXTRACTION",
            "GET_DATA_EXTRACTION_STATUS",
            "RUN_ANALYTICS",
            "EDIT_PRELIMINARY_RESEARCH_DOCUMENT",
            "GET_CITATION_DOCUMENT",
            "DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT",
            "ACCEPT_PRELIMINARY_RESEARCH",
        }.issubset(actions_seen)

        for entry in trace_data["entries"]:
            assert entry["duration_ms"] >= 0
            assert entry["started_at"]
            assert entry["completed_at"]
            req_hdrs = entry.get("request_headers") or {}
            if "x-asm-rctoken" in req_hdrs:
                assert req_hdrs["x-asm-rctoken"] != "secret-token-value-123"
                assert "..." in req_hdrs["x-asm-rctoken"]

        # Incremental since_id and DELETE clear
        latest_id = trace_data["latest_id"]
        inc = (await client.get(f"/api/ct1/trace?since_id={latest_id}")).json()
        assert inc["entries"] == []

        cleared = (await client.delete("/api/ct1/trace")).json()
        assert cleared["cleared"] is True
        after_clear = (await client.get("/api/ct1/trace")).json()
        assert after_clear["entries"] == []

    _assert_all_calls_are_gateway_only(recorder)


@pytest.mark.asyncio
async def test_multi_file_mixed_type_multipart_ingest_and_full_polling(gateway_recorder):
    recorder, mock_client = gateway_recorder
    transport = httpx.ASGITransport(app=server.app)
    pdf_bytes = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF"
    file_types = {"alpha.pdf": "policy", "beta.pdf": "kod", "gamma.pdf": "procedure"}

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.post(
            "/api/ct1/query/ingest",
            data={
                "plan_number": "20429",
                "document_type": "policy",
                "file_types": json.dumps(file_types),
                "force_fresh_ingest": "true",
            },
            files=[
                ("files", ("alpha.pdf", pdf_bytes, "application/pdf")),
                ("files", ("beta.pdf", pdf_bytes, "application/pdf")),
                ("files", ("gamma.pdf", pdf_bytes, "application/pdf")),
            ],
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["rag_mode"] == "api_gateway_multipart"
    assert body["job_id"] == "job-multi-123"
    assert body["poll_count"] == 2  # Waited past poll 1 while in_progress > 0!
    assert body["registry_updated"] is True
    assert len(body["document_ids"]) == 3
    assert len(body["persisted_files"]) == 3
    assert body["rag_summary"]["indexed"] == 3

    # Verify stamped filenames matched file_types 1-to-1 and types were preserved!
    uploaded_names = [fname for _, fname in mock_client.last_uploaded_files]
    assert len(uploaded_names) == 3
    assert set(mock_client.last_file_types.keys()) == set(uploaded_names)
    assert sorted(mock_client.last_file_types.values()) == ["kod", "policy", "procedure"]

    # Verify QNA_CATEGORIZE_DOCUMENTS was never called and all calls hit GATEWAY_BASE
    actions_called = [
        (c.get("json") or {}).get("action") or (c.get("data") or {}).get("action")
        for c in recorder
    ]
    assert "QNA_CATEGORIZE_DOCUMENTS" not in actions_called
    assert actions_called == [
        "QNA_INGEST_DOCUMENTS",
        "QNA_GET_INGEST_JOB_STATUS",
        "QNA_GET_INGEST_JOB_STATUS",
        "QNA_GET_RELEVANT_DATA",
    ]
    _assert_all_calls_are_gateway_only(recorder)

    # Rich per-doc fields surfaced to UI
    doc_types_out = {d["document_type"] for d in body["documents"]}
    assert doc_types_out == {"policy", "kod", "procedure"}
    for doc in body["documents"]:
        assert doc["document_relevance_verdict"] == "HIGH"
        assert doc["document_relevance_score"] == 0.91
        assert doc["section_count"] == 1
        assert doc["storage_uri"].startswith("gs://")


def test_static_ui_has_collapsible_terminal_and_multifile_upload():
    html = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
    js = (STATIC_DIR / "app.js").read_text(encoding="utf-8")

    assert 'id="openTerminalBtn"' in html
    assert 'id="terminalModalBackdrop"' in html
    assert 'id="ingestFileList"' in html
    assert "DOCUMENT_ADD_REMOVE" in html
    assert "QNA_INGEST_DOCUMENTS" in html

    # Collapsible <details> entries created collapsed by default (not setting details.open = true)
    assert 'document.createElement("details")' in js
    assert 'details.className = `term-entry' in js
    assert "details.open = true" not in js
    assert 'form.append("file_types"' in js
