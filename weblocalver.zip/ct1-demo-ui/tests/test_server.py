"""Tests for the CT1 Live Demo UI proxy server."""

from __future__ import annotations

import json
from typing import Any, List, Tuple

import httpx
import pytest

import server


class _FakeResponse:
    def __init__(self, status_code: int, payload: Any):
        self.status_code = status_code
        self._payload = payload
        self.text = json.dumps(payload) if payload is not None else ""

    def json(self) -> Any:
        return self._payload


class _FakeAsyncClient:
    def __init__(self, recorder: List[Tuple[str, str, Any]]):
        self.recorder = recorder

    async def __aenter__(self) -> "_FakeAsyncClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def get(self, url: str) -> _FakeResponse:
        self.recorder.append(("GET", url, None))
        if url.endswith("/availability"):
            return _FakeResponse(200, {"plan_number": "20440", "artifacts": {"policy": True}})
        if url.endswith("/getdata/20440/policy"):
            return _FakeResponse(200, {"items": [{"document_name": "Policy 1", "node_id": "1:sec:1"}]})
        if url.endswith("/getdata/20440/findings_details"):
            return _FakeResponse(200, [{"responsePayload": [{"findingId": "F-1", "findingTitle": "Gap"}]}])
        if url.endswith("/status"):
            return _FakeResponse(200, {"session_id": "sess-1", "status": "completed"})
        return _FakeResponse(404, {"detail": "Not found"})

    async def post(self, url: str, json: Any = None, data: Any = None, files: Any = None) -> _FakeResponse:
        self.recorder.append(("POST", url, json or data or files))
        if url.endswith("/documents/list-all"):
            return _FakeResponse(
                200,
                {
                    "plan_number": "20440",
                    "document_groups": [{"document_type": "policy", "documents": [{"document_title": "Policy 1"}]}],
                },
            )
        if url.endswith("/qna/chat"):
            return _FakeResponse(
                200,
                {
                    "answer": "Proposed excluding Policy 1.",
                    "document_workflow": {"stage": "awaiting_approval", "plan": {"actions": []}},
                },
            )
        if url.endswith("/data-extraction"):
            return _FakeResponse(200, {"session_id": "sess-1", "status": "queued"})
        if url.endswith("/documents/ingest"):
            return _FakeResponse(200, {"status": "accepted", "job_id": "job-42", "message": "Queued"})
        return _FakeResponse(404, {"detail": "Unknown POST"})

    async def request(self, method: str, url: str, json: Any = None) -> _FakeResponse:
        if method == "GET":
            return await self.get(url)
        return await self.post(url, json=json)


def _asgi_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app), base_url="http://testserver")


@pytest.mark.asyncio
async def test_index_and_config():
    async with _asgi_client() as client:
        resp = await client.get("/")
        assert resp.status_code == 200
        assert "DBAware CT1 Live Workflow" in resp.text

        cfg = await client.get("/api/config")
        assert cfg.status_code == 200
        body = cfg.json()
        assert body["cta_host"] == server.CTA_HOST
        assert len(body["artifacts"]) == 9


@pytest.mark.asyncio
async def test_bootstrap_forwards_only_to_ct1_endpoints(monkeypatch):
    calls: List[Tuple[str, str, Any]] = []
    monkeypatch.setattr(server, "create_async_client", lambda: _FakeAsyncClient(calls))

    async with _asgi_client() as client:
        resp = await client.get("/api/ct1/plan/20440/bootstrap")
    assert resp.status_code == 200
    payload = resp.json()

    assert payload["plan_number"] == "20440"
    assert payload["catalog"]["document_groups"][0]["document_type"] == "policy"
    assert payload["artifacts"]["policy"]["items"][0]["node_id"] == "1:sec:1"
    assert payload["artifacts"]["findings_details"][0]["responsePayload"][0]["findingId"] == "F-1"
    assert any(u.endswith("/query-service/qna/documents/list-all") for _, u, _ in calls)
    assert any(u.endswith("/scoping-dataextraction-agent/getdata/20440/lrr") for _, u, _ in calls)


@pytest.mark.asyncio
async def test_chat_ingest_and_extraction_proxies(monkeypatch):
    calls: List[Tuple[str, str, Any]] = []
    monkeypatch.setattr(server, "create_async_client", lambda: _FakeAsyncClient(calls))

    async with _asgi_client() as client:
        chat_resp = await client.post(
            "/api/ct1/query/chat",
            json={"question": "Exclude @[Policies: Policy 1]", "plan_number": "20440"},
        )
        assert chat_resp.status_code == 200
        assert chat_resp.json()["document_workflow"]["stage"] == "awaiting_approval"

        run_resp = await client.post("/api/ct1/dataextraction/run", json={"planNumber": "20440"})
        assert run_resp.status_code == 200
        assert run_resp.json()["session_id"] == "sess-1"

        st_resp = await client.get("/api/ct1/dataextraction/status/sess-1")
        assert st_resp.status_code == 200
        assert st_resp.json()["status"] == "completed"

        ingest_resp = await client.post(
            "/api/ct1/query/ingest",
            data={"plan_number": "20440", "document_type": "policy"},
            files={"files": ("test.pdf", b"%PDF-1.4 mock", "application/pdf")},
        )
        assert ingest_resp.status_code == 200
        assert ingest_resp.json()["job_id"] == "job-42"

        missing_artifact = await client.get("/api/ct1/dataextraction/20440/unknown_feed")
        assert missing_artifact.status_code == 404
