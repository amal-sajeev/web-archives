"""Tests for the CT1 API Gateway-only Demo UI proxy server & API Terminal trace capture."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx
import pytest

CT1_UI_DIR = Path(__file__).resolve().parents[1]
if str(CT1_UI_DIR) not in sys.path:
    sys.path.insert(0, str(CT1_UI_DIR))

import server

STATIC_DIR = CT1_UI_DIR / "static"

SAMPLE_REPORT: Dict[str, Any] = {
    "Past Review Analysis": {
        "report_title": "Past Review Analysis",
        "current_review_id": "20429",
        "similar_review_count": 1,
        "historical_reviews": [
            {"historical_review_id": "13224", "review_title": "Prior Review", "assessments": []}
        ],
    },
    "Policy, KOD and Regulatory Analysis": {
        "report_title": "Policy, KOD and Regulatory Analysis",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": "**Section 1: Policy Analysis**\nRelevant policy summary.",
                "supporting_chunk_ids": ["4"],
                "metadata": {"is_section_start": True, "section_confidence_score": 88},
            }
        ],
    },
    "Broad Scope Direction": {
        "report_title": "Broad Scope Direction",
        "paragraphs": [
            {
                "paragraph_id": "para_1",
                "content": "**Section 1: Broad Scope Direction**\nScope direction.",
                "supporting_chunk_ids": ["1"],
                "metadata": {"is_section_start": True, "section_confidence_score": 82},
            }
        ],
    },
}

SAMPLE_CATALOG: Dict[str, Any] = {
    "plan_number": "20429",
    "document_groups": [
        {
            "document_type": "policy",
            "documents": [
                {
                    "document_id": "pol-1",
                    "document_title": "Access_Control_Policy",
                    "file_name": "policy1.json",
                    "status": "active",
                    "excluded": False,
                    "sections": [
                        {
                            "section_id": "1",
                            "section_title": "Access Governance",
                            "status": "active",
                            "excluded": False,
                        }
                    ],
                }
            ],
        },
        {"document_type": "kod", "documents": []},
        {"document_type": "procedure", "documents": []},
    ],
    "total_count": 1,
    "source": "gcs",
}


class _FakeResponse:
    def __init__(
        self,
        status_code: int,
        payload: Any,
        *,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ):
        self.status_code = status_code
        self._payload = payload
        self.text = (
            payload
            if isinstance(payload, str)
            else (json.dumps(payload) if payload is not None else "")
        )
        self.content = content if content is not None else self.text.encode("utf-8")
        self.headers = headers or {"content-type": "application/json"}

    def json(self) -> Any:
        if isinstance(self._payload, str):
            raise ValueError("not json")
        return self._payload


class _GatewayMockClient:
    """Mocks ONLY API Gateway endpoints and records every outbound call for strict assertion."""

    def __init__(
        self,
        recorder: List[Dict[str, Any]],
        *,
        multi_poll: bool = True,
        fail_first_poll_503: bool = False,
        force_upstream_type: Optional[str] = None,
        ignore_file_types: bool = False,
    ):
        self.recorder = recorder
        self.multi_poll = multi_poll
        self.fail_first_poll_503 = fail_first_poll_503
        self.force_upstream_type = force_upstream_type
        self.ignore_file_types = ignore_file_types
        self.job_poll_count = 0
        self.job_poll_attempts = 0
        self.last_uploaded_files: List[Tuple[str, str]] = []
        self.last_file_types: Dict[str, str] = {}
        self.last_raw_file_types: Any = None
        self.upload_batches: List[Dict[str, Any]] = []
        self._jobs: Dict[str, Dict[str, Any]] = {}
        self._next_doc_id = 501

    async def __aenter__(self) -> "_GatewayMockClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def get(self, url: str, headers: Any = None, timeout: Any = None) -> _FakeResponse:
        self.recorder.append({"method": "GET", "url": url, "headers": headers})
        if url.endswith("/openapi.json"):
            return _FakeResponse(200, {"openapi": "3.1.0", "info": {"title": "dbaware-api-gateway"}})
        if "/api/v1/task/status/" in url:
            return _FakeResponse(
                200,
                {
                    "processInstanceId": "proc-20429",
                    "taskId": "task-20429",
                    "taskDefinitionKey": "review_scope_definition",
                    "owner": "tester@db.com",
                    "variables": json.dumps({"review_scope_id": "901"}),
                },
            )
        return _FakeResponse(404, {"detail": f"Unexpected GET {url}"})

    async def post(
        self,
        url: str,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        headers: Any = None,
        timeout: Any = None,
    ) -> _FakeResponse:
        self.recorder.append(
            {
                "method": "POST",
                "url": url,
                "json": json,
                "data": data,
                "files": files,
                "headers": headers,
            }
        )
        plan_status_hdr = {
            "content-type": "application/json",
            "x-plan-status": json_dumps({"planNumber": "20429", "taskDefinitionKey": "pr_review"}),
        }

        if url.endswith("/api/v1/actions/upload"):
            assert data is not None
            action = data.get("action")
            raw_payload = json_loads(data.get("payload") or "{}")
            raw_ft = raw_payload.get("file_types")
            batch_doc_type = raw_payload.get("document_type", "policy")
            self.last_raw_file_types = raw_ft
            if isinstance(raw_ft, str):
                parsed_ft = json_loads(raw_ft)
            else:
                parsed_ft = dict(raw_ft or {})
            self.last_file_types = parsed_ft
            uploaded_list = [
                (part[0], part[1][0]) for part in (files or []) if isinstance(part, tuple)
            ]
            self.last_uploaded_files = uploaded_list
            if action == "QNA_INGEST_DOCUMENTS":
                job_id = f"job-multi-{len(self._jobs) + 1}"
                self._jobs[job_id] = {
                    "uploaded_names": [fname for _, fname in uploaded_list],
                    "file_types": parsed_ft,
                    "raw_file_types": raw_ft,
                    "document_type": batch_doc_type,
                    "polls": 0,
                }
                self.upload_batches.append(
                    {
                        "job_id": job_id,
                        "document_type": batch_doc_type,
                        "raw_file_types": raw_ft,
                        "file_types": parsed_ft,
                        "filenames": [fname for _, fname in uploaded_list],
                    }
                )
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "status": "accepted",
                            "job_id": job_id,
                            "document_ids": [],
                            "plan_number": data.get("planNumber"),
                            "message": "Submitted to RAG",
                            "details": {
                                "status": "in_progress",
                                "summary": {"total": len(uploaded_list), "in_progress": len(uploaded_list)},
                            },
                        }
                    },
                    headers=plan_status_hdr,
                )
            return _FakeResponse(400, {"detail": f"Unsupported upload action {action}"})

        if url.endswith("/api/v1/actions/download"):
            assert json and json.get("action") == "DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT"
            return _FakeResponse(
                200,
                None,
                content=b"%PDF-1.4\n%fake-pr-pdf\n",
                headers={
                    "content-type": "application/pdf",
                    "content-disposition": 'attachment; filename="PR_20429.pdf"',
                    "x-plan-status": json_dumps({"planNumber": "20429"}),
                },
            )

        if url.endswith("/api/v1/actions"):
            action = (json or {}).get("action")
            plan = (json or {}).get("planNumber")
            payload = (json or {}).get("payload") or {}

            if action == "GET_PLAN_AVAILABILITY":
                return _FakeResponse(200, {"response": {"plan_number": plan, "available": True}}, headers=plan_status_hdr)
            if action == "GET_PLAN_ARTIFACT":
                art = payload.get("artifact")
                return _FakeResponse(
                    200,
                    {"response": {"plan_number": plan, "artifact": art, "data": {}}},
                    headers=plan_status_hdr,
                )
            if action == "DATA_EXTRACTION":
                return _FakeResponse(200, {"response": {"session_id": "sess-99", "status": "started"}}, headers=plan_status_hdr)
            if action == "GET_DATA_EXTRACTION_STATUS":
                return _FakeResponse(
                    200,
                    {"response": {"session_id": payload.get("session_id"), "status": "completed"}},
                    headers=plan_status_hdr,
                )
            if action == "QNA_LIST_DOCUMENTS":
                return _FakeResponse(200, {"response": SAMPLE_CATALOG}, headers=plan_status_hdr)
            if action == "QNA_CHAT":
                return _FakeResponse(
                    200,
                    {"response": {"session_id": plan, "answer": "Summary of risks via API Gateway."}},
                    headers=plan_status_hdr,
                )
            if action == "DOCUMENT_ADD_REMOVE":
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "answer": "Please approve excluding Access_Control_Policy.",
                            "document_workflow": {
                                "stage": "pending_approval",
                                "requires_approval": True,
                                "steps": [
                                    {
                                        "action": "exclude",
                                        "document_type": "policy",
                                        "title": "Access_Control_Policy",
                                    }
                                ],
                            },
                        }
                    },
                    headers=plan_status_hdr,
                )
            if action == "QNA_GET_INGEST_JOB_STATUS":
                self.job_poll_attempts += 1
                if self.fail_first_poll_503 and self.job_poll_attempts <= 2:
                    return _FakeResponse(503, {"detail": "upstream temporarily unavailable"})
                self.job_poll_count += 1
                req_job_id = payload.get("job_id")
                job_info = self._jobs.get(req_job_id) or {
                    "uploaded_names": [fname for _, fname in self.last_uploaded_files],
                    "file_types": self.last_file_types,
                    "document_type": "policy",
                    "polls": 0,
                }
                job_info["polls"] = int(job_info.get("polls", 0)) + 1
                uploaded_names = job_info["uploaded_names"]
                ft_map = job_info["file_types"]
                batch_dt = job_info["document_type"]

                def _resolved_up_type(fname: str) -> str:
                    if self.force_upstream_type:
                        return self.force_upstream_type
                    if self.ignore_file_types:
                        return batch_dt
                    return ft_map.get(fname, batch_dt)

                if self.multi_poll and job_info["polls"] == 1 and len(uploaded_names) > 1:
                    # Simulate 1 file finished while others are still in_progress!
                    first_name = uploaded_names[0]
                    first_id = self._next_doc_id
                    return _FakeResponse(
                        200,
                        {
                            "response": {
                                "job_id": req_job_id,
                                "status": "in_progress",
                                "document_ids": [first_id],
                                "details": {
                                    "status": "in_progress",
                                    "summary": {
                                        "total": len(uploaded_names),
                                        "indexed": 1,
                                        "in_progress": len(uploaded_names) - 1,
                                        "already_indexed": 0,
                                        "invalid": 0,
                                        "failed": 0,
                                    },
                                    "indexed": [
                                        {
                                            "filename": first_name,
                                            "document_id": first_id,
                                            "document_type": _resolved_up_type(first_name),
                                        }
                                    ],
                                    "in_progress": [{"filename": n} for n in uploaded_names[1:]],
                                },
                            }
                        },
                        headers=plan_status_hdr,
                    )
                indexed_items = []
                for fname in uploaded_names:
                    did = self._next_doc_id
                    self._next_doc_id += 1
                    indexed_items.append(
                        {
                            "filename": fname,
                            "document_id": did,
                            "document_type": _resolved_up_type(fname),
                        }
                    )
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "job_id": req_job_id,
                            "status": "completed",
                            "document_ids": [it["document_id"] for it in indexed_items],
                            "details": {
                                "status": "completed",
                                "summary": {
                                    "total": len(indexed_items),
                                    "queued": len(indexed_items),
                                    "indexed": len(indexed_items),
                                    "in_progress": 0,
                                    "already_indexed": 0,
                                    "invalid": 0,
                                    "failed": 0,
                                },
                                "indexed": indexed_items,
                                "in_progress": [],
                                "already_indexed": [],
                                "invalid": [],
                                "failed": [],
                            },
                        }
                    },
                    headers=plan_status_hdr,
                )
            if action == "QNA_GET_RELEVANT_DATA":
                docs_payload = payload.get("documents") or []
                results_list = []
                for spec in docs_payload:
                    dtype = spec.get("document_type", "policy")
                    for did in spec.get("document_ids") or []:
                        results_list.append(
                            {
                                "document_id": did,
                                "document_type": dtype,
                                "document_title": f"Doc_{dtype}_{did}",
                                "storage_uri": f"gs://bucket/{dtype}_{did}.pdf",
                                "document_relevance_verdict": "HIGH",
                                "document_relevance_score": 0.91,
                                "rationale": f"Highly relevant {dtype} control text.",
                                "nodes": [
                                    {
                                        "section_id": "1",
                                        "section_title": f"Key {dtype.upper()} Section",
                                        "node_id": f"n-{did}-1",
                                        "original_text": "Detailed requirement text.",
                                    }
                                ],
                            }
                        )
                return _FakeResponse(
                    200,
                    {
                        "response": {
                            "status": "success",
                            "plan_number": plan,
                            "review_id": plan,
                            "registry_updated": True,
                            "persisted_files": [f"{r['document_type']}{r['document_id']}.json" for r in results_list],
                            "results": results_list,
                        }
                    },
                    headers=plan_status_hdr,
                )
            if action in (
                "GET_PRELIMINARY_RESEARCH_DOCUMENT",
                "RUN_ANALYTICS",
                "EDIT_PRELIMINARY_RESEARCH_DOCUMENT",
            ):
                return _FakeResponse(
                    200,
                    {"response": {"plan_number": plan, "analysis_report": SAMPLE_REPORT}},
                    headers=plan_status_hdr,
                )
            if action == "GET_CITATION_DOCUMENT":
                return _FakeResponse(
                    200,
                    {"response": {"type": "json", "content": {"chunk_id": payload.get("chunk_id")}}},
                    headers=plan_status_hdr,
                )
            if action == "ACCEPT_PRELIMINARY_RESEARCH":
                return _FakeResponse(
                    200,
                    {"status": "accepted", "planNumber": plan},
                    headers=plan_status_hdr,
                )
            return _FakeResponse(400, {"detail": f"Unexpected gateway action: {action}"})

        return _FakeResponse(404, {"detail": f"Unexpected POST {url}"})


def json_dumps(obj: Any) -> str:
    return json.dumps(obj)


def json_loads(raw: str) -> Any:
    return json.loads(raw)


@pytest.fixture
def gateway_recorder(monkeypatch):
    recorder: List[Dict[str, Any]] = []
    mock_client = _GatewayMockClient(recorder)
    server._API_TRACE_LOG.clear()
    monkeypatch.setattr(server, "create_async_client", lambda: mock_client)
    monkeypatch.setattr(server, "RAG_INGEST_POLL_INTERVAL_SECONDS", 0.01)
    monkeypatch.setattr(server, "RETRY_BACKOFF_SECONDS", 0.0)
    monkeypatch.setattr(server, "CT1_RC_TOKEN", "secret-token-value-123")
    return recorder, mock_client


def _assert_all_calls_are_gateway_only(recorder: List[Dict[str, Any]]) -> None:
    assert len(recorder) > 0
    for call in recorder:
        assert call["url"].startswith(server.GATEWAY_BASE), f"Non-gateway URL detected: {call['url']}"


@pytest.mark.asyncio
async def test_config_and_full_gateway_only_endpoints(gateway_recorder):
    recorder, _ = gateway_recorder
    transport = httpx.ASGITransport(app=server.app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        cfg = (await client.get("/api/config")).json()
        assert cfg["gateway_only"] is True
        assert cfg["gateway_base"] == server.GATEWAY_BASE
        assert cfg["upload_limits"]["max_files"] == 5

        boot = await client.get("/api/ct1/plan/20429/bootstrap")
        assert boot.status_code == 200
        bdata = boot.json()
        assert bdata["gateway_only"] is True
        assert bdata["query_mode"] == "api_gateway"
        assert bdata["preliminary_research"]["available"] is True

        # Chat Q&A and Document Add/Remove
        qa = await client.post("/api/ct1/query/chat", json={"question": "Summarize risks", "plan_number": "20429"})
        assert qa.status_code == 200
        assert "API Gateway" in qa.json()["answer"]

        ar = await client.post(
            "/api/ct1/query/add-remove",
            json={"user_text": "Exclude Access_Control_Policy", "plan_number": "20429"},
        )
        assert ar.status_code == 200
        assert ar.json()["document_workflow"]["stage"] == "awaiting_approval"

        # Data Extraction
        ex_run = await client.post("/api/ct1/dataextraction/run", json={"planNumber": "20429"})
        assert ex_run.status_code == 200
        ex_st = await client.get("/api/ct1/dataextraction/status/sess-99?plan_number=20429")
        assert ex_st.status_code == 200
        art = await client.get("/api/ct1/dataextraction/20429/policy")
        assert art.status_code == 200

        # Preliminary Research lifecycle
        health = await client.get("/api/ct1/preliminary-research/health")
        assert health.status_code == 200
        gen = await client.post("/api/ct1/preliminary-research/generate", json={"planNumber": "20429"})
        assert gen.status_code == 200
        edit = await client.post(
            "/api/ct1/preliminary-research/edit",
            json={"planNumber": "20429", "analysis_report": SAMPLE_REPORT},
        )
        assert edit.status_code == 200
        doc = await client.post(
            "/api/ct1/preliminary-research/document",
            json={"planNumber": "20429", "chunk_id": "4"},
        )
        assert doc.status_code == 200
        dl = await client.post("/api/ct1/preliminary-research/download", json={"planNumber": "20429"})
        assert dl.status_code == 200
        assert dl.content.startswith(b"%PDF-1.4")
        acc = await client.post("/api/ct1/preliminary-research/accept", json={"planNumber": "20429"})
        assert acc.status_code == 200

        # Verify trace endpoint captured every upstream call and redacted auth token
        trace_resp = await client.get("/api/ct1/trace")
        assert trace_resp.status_code == 200
        trace_data = trace_resp.json()
        assert len(trace_data["entries"]) == len(recorder)
        actions_seen = {e["action"] for e in trace_data["entries"] if e["action"]}
        assert {
            "GET_PLAN_AVAILABILITY",
            "GET_PLAN_ARTIFACT",
            "QNA_LIST_DOCUMENTS",
            "GET_PRELIMINARY_RESEARCH_DOCUMENT",
            "QNA_CHAT",
            "DOCUMENT_ADD_REMOVE",
            "DATA_EXTRACTION",
            "GET_DATA_EXTRACTION_STATUS",
            "RUN_ANALYTICS",
            "EDIT_PRELIMINARY_RESEARCH_DOCUMENT",
            "GET_CITATION_DOCUMENT",
            "DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT",
            "ACCEPT_PRELIMINARY_RESEARCH",
        }.issubset(actions_seen)

        for entry in trace_data["entries"]:
            assert entry["duration_ms"] >= 0
            assert entry["started_at"]
            assert entry["completed_at"]
            req_hdrs = entry.get("request_headers") or {}
            if "x-asm-rctoken" in req_hdrs:
                assert req_hdrs["x-asm-rctoken"] != "secret-token-value-123"
                assert "..." in req_hdrs["x-asm-rctoken"]

        # Incremental since_id and DELETE clear
        latest_id = trace_data["latest_id"]
        inc = (await client.get(f"/api/ct1/trace?since_id={latest_id}")).json()
        assert inc["entries"] == []

        cleared = (await client.delete("/api/ct1/trace")).json()
        assert cleared["cleared"] is True
        after_clear = (await client.get("/api/ct1/trace")).json()
        assert after_clear["entries"] == []

    _assert_all_calls_are_gateway_only(recorder)


@pytest.mark.asyncio
async def test_multi_file_mixed_type_splits_by_type_even_if_upstream_ignores_file_types(monkeypatch):
    """Default mode splits mixed types into per-type QNA_INGEST_DOCUMENTS batches so CT1 tags every file accurately."""
    recorder: List[Dict[str, Any]] = []
    mock_client = _GatewayMockClient(recorder, multi_poll=True, ignore_file_types=True)
    server._API_TRACE_LOG.clear()
    monkeypatch.setattr(server, "create_async_client", lambda: mock_client)
    monkeypatch.setattr(server, "RAG_INGEST_POLL_INTERVAL_SECONDS", 0.01)
    monkeypatch.setattr(server, "RETRY_BACKOFF_SECONDS", 0.0)
    monkeypatch.setattr(server, "SPLIT_MIXED_INGEST_BY_TYPE", True)

    transport = httpx.ASGITransport(app=server.app)
    pdf_bytes = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF"
    files = [
        ("files", ("sample-kod-1.pdf", pdf_bytes, "application/pdf")),
        ("files", ("sample-kod-2.pdf", pdf_bytes, "application/pdf")),
        ("files", ("sample-policy-1.pdf", pdf_bytes, "application/pdf")),
        ("files", ("sample-policy-2.pdf", pdf_bytes, "application/pdf")),
        ("files", ("sample-procedure-1.pdf", pdf_bytes, "application/pdf")),
    ]
    file_types_list = ["kod", "kod", "policy", "policy", "procedure"]

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.post(
            "/api/ct1/query/ingest",
            data={
                "plan_number": "20429",
                "document_type": "auto",
                "file_types_list": json.dumps(file_types_list),
                "force_fresh_ingest": "true",
            },
            files=files,
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["rag_mode"] == "api_gateway_multipart"
    assert body["registry_updated"] is True
    assert len(body["document_ids"]) == 5
    assert body["rag_summary"]["indexed"] == 5
    assert body.get("type_mismatch_warnings") == []

    # 3 distinct per-type batches: kod (2 files), policy (2 files), procedure (1 file)
    assert len(mock_client.upload_batches) == 3
    by_batch_type = {b["document_type"]: b for b in mock_client.upload_batches}
    assert set(by_batch_type.keys()) == {"kod", "policy", "procedure"}
    assert len(by_batch_type["kod"]["filenames"]) == 2
    assert len(by_batch_type["policy"]["filenames"]) == 2
    assert len(by_batch_type["procedure"]["filenames"]) == 1
    for btype, batch in by_batch_type.items():
        assert isinstance(batch["raw_file_types"], str)
        assert set(batch["file_types"].values()) == {btype}

    # Every returned document kept its exact type even though mock ignored file_types!
    returned_types = sorted(d["document_type"] for d in body["documents"])
    assert returned_types == ["kod", "kod", "policy", "policy", "procedure"]

    # Exactly one QNA_GET_RELEVANT_DATA call covering all 3 document types
    rel_calls = [c for c in recorder if (c.get("json") or {}).get("action") == "QNA_GET_RELEVANT_DATA"]
    assert len(rel_calls) == 1
    rel_types = {d["document_type"] for d in rel_calls[0]["json"]["payload"]["documents"]}
    assert rel_types == {"kod", "policy", "procedure"}
    _assert_all_calls_are_gateway_only(recorder)


@pytest.mark.asyncio
async def test_multi_file_mixed_type_single_batch_mode_and_full_polling(gateway_recorder, monkeypatch):
    recorder, mock_client = gateway_recorder
    monkeypatch.setattr(server, "SPLIT_MIXED_INGEST_BY_TYPE", False)
    transport = httpx.ASGITransport(app=server.app)
    pdf_bytes = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF"
    file_types = {"alpha.pdf": "policy", "beta.pdf": "kod", "gamma.pdf": "procedure"}
    file_types_list = ["policy", "kod", "procedure"]

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.post(
            "/api/ct1/query/ingest",
            data={
                "plan_number": "20429",
                "document_type": "auto",
                "file_types": json.dumps(file_types),
                "file_types_list": json.dumps(file_types_list),
                "force_fresh_ingest": "true",
            },
            files=[
                ("files", ("alpha.pdf", pdf_bytes, "application/pdf")),
                ("files", ("beta.pdf", pdf_bytes, "application/pdf")),
                ("files", ("gamma.pdf", pdf_bytes, "application/pdf")),
            ],
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["rag_mode"] == "api_gateway_multipart"
    assert body["job_id"] == "job-multi-1"
    assert body["poll_count"] == 2  # Waited past poll 1 while in_progress > 0!
    assert body["registry_updated"] is True
    assert len(body["document_ids"]) == 3
    assert len(body["persisted_files"]) == 3
    assert body["rag_summary"]["indexed"] == 3
    assert body.get("type_mismatch_warnings") == []

    # Verify file_types was sent as a JSON string (matching Query Service Form(None)),
    # stamped filenames matched file_types 1-to-1, and types were preserved!
    assert isinstance(mock_client.last_raw_file_types, str)
    uploaded_names = [fname for _, fname in mock_client.last_uploaded_files]
    assert len(uploaded_names) == 3
    assert set(mock_client.last_file_types.keys()) == set(uploaded_names)
    assert sorted(mock_client.last_file_types.values()) == ["kod", "policy", "procedure"]

    # Verify QNA_CATEGORIZE_DOCUMENTS was never called and all calls hit GATEWAY_BASE
    actions_called = [
        (c.get("json") or {}).get("action") or (c.get("data") or {}).get("action")
        for c in recorder
    ]
    assert "QNA_CATEGORIZE_DOCUMENTS" not in actions_called
    assert actions_called == [
        "QNA_INGEST_DOCUMENTS",
        "QNA_GET_INGEST_JOB_STATUS",
        "QNA_GET_INGEST_JOB_STATUS",
        "QNA_GET_RELEVANT_DATA",
    ]
    _assert_all_calls_are_gateway_only(recorder)

    # Rich per-doc fields surfaced to UI
    doc_types_out = {d["document_type"] for d in body["documents"]}
    assert doc_types_out == {"policy", "kod", "procedure"}
    for doc in body["documents"]:
        assert doc["document_relevance_verdict"] == "HIGH"
        assert doc["document_relevance_score"] == 0.91
        assert doc["section_count"] == 1
        assert doc["storage_uri"].startswith("gs://")


@pytest.mark.asyncio
async def test_transient_503_retries_during_polling_and_actions(monkeypatch):
    recorder: List[Dict[str, Any]] = []
    mock_client = _GatewayMockClient(recorder, multi_poll=False, fail_first_poll_503=True)
    server._API_TRACE_LOG.clear()
    monkeypatch.setattr(server, "create_async_client", lambda: mock_client)
    monkeypatch.setattr(server, "RAG_INGEST_POLL_INTERVAL_SECONDS", 0.01)
    monkeypatch.setattr(server, "RETRY_BACKOFF_SECONDS", 0.0)
    monkeypatch.setattr(server, "RETRY_MAX_ATTEMPTS", 3)
    monkeypatch.setattr(server, "SPLIT_MIXED_INGEST_BY_TYPE", False)
    monkeypatch.setattr(server, "CT1_RC_TOKEN", "secret-token-value-123")

    transport = httpx.ASGITransport(app=server.app)
    pdf_bytes = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF"

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.post(
            "/api/ct1/query/ingest",
            data={
                "plan_number": "20429",
                "document_type": "auto",
                "file_types": json.dumps({"branch_kod.pdf": "kod", "sop_proc.pdf": "procedure"}),
                "file_types_list": json.dumps(["kod", "procedure"]),
                "force_fresh_ingest": "true",
            },
            files=[
                ("files", ("branch_kod.pdf", pdf_bytes, "application/pdf")),
                ("files", ("sop_proc.pdf", pdf_bytes, "application/pdf")),
            ],
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["rag_summary"]["indexed"] == 2
        assert {d["document_type"] for d in body["documents"]} == {"kod", "procedure"}
        # First 2 QNA_GET_INGEST_JOB_STATUS attempts returned 503, 3rd succeeded
        assert mock_client.job_poll_attempts == 3

        trace_resp = await client.get("/api/ct1/trace")
        assert trace_resp.status_code == 200
        poll_traces = [
            e for e in trace_resp.json()["entries"] if e.get("action") == "QNA_GET_INGEST_JOB_STATUS"
        ]
        assert len(poll_traces) == 3
        assert [e["status_code"] for e in poll_traces] == [503, 503, 200]
        assert [e["attempt"] for e in poll_traces] == [1, 2, 3]
        assert poll_traces[-1]["ok"] is True

    _assert_all_calls_are_gateway_only(recorder)


@pytest.mark.asyncio
async def test_outer_poll_loop_survives_503_and_flags_upstream_type_mismatch(monkeypatch):
    recorder: List[Dict[str, Any]] = []
    mock_client = _GatewayMockClient(
        recorder,
        multi_poll=False,
        fail_first_poll_503=True,
        force_upstream_type="policy",
    )
    server._API_TRACE_LOG.clear()
    monkeypatch.setattr(server, "create_async_client", lambda: mock_client)
    monkeypatch.setattr(server, "RAG_INGEST_POLL_INTERVAL_SECONDS", 0.01)
    monkeypatch.setattr(server, "RETRY_BACKOFF_SECONDS", 0.0)
    # Force per-call retry to 1 so the outer polling loop itself must catch & recover from 503s
    monkeypatch.setattr(server, "RETRY_MAX_ATTEMPTS", 1)
    monkeypatch.setattr(server, "POLL_MAX_CONSECUTIVE_ERRORS", 5)
    monkeypatch.setattr(server, "SPLIT_MIXED_INGEST_BY_TYPE", False)

    transport = httpx.ASGITransport(app=server.app)
    pdf_bytes = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF"

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.post(
            "/api/ct1/query/ingest",
            data={
                "plan_number": "20429",
                "document_type": "auto",
                "file_types_list": json.dumps(["kod", "procedure"]),
                "force_fresh_ingest": "true",
            },
            files=[
                ("files", ("branch_kod.pdf", pdf_bytes, "application/pdf")),
                ("files", ("sop_proc.pdf", pdf_bytes, "application/pdf")),
            ],
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["poll_retries"] == 2
    assert mock_client.job_poll_attempts == 3
    assert len(body["type_mismatch_warnings"]) == 2
    assert any("kod" in w and "policy" in w for w in body["type_mismatch_warnings"])
    assert any("procedure" in w and "policy" in w for w in body["type_mismatch_warnings"])


def test_static_ui_has_collapsible_terminal_and_multifile_upload():
    html = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
    js = (STATIC_DIR / "app.js").read_text(encoding="utf-8")

    assert 'id="openTerminalBtn"' in html
    assert 'id="terminalModalBackdrop"' in html
    assert 'id="ingestFileList"' in html
    assert "DOCUMENT_ADD_REMOVE" in html
    assert "QNA_INGEST_DOCUMENTS" in html

    # Collapsible <details> entries created collapsed by default (not setting details.open = true)
    assert 'document.createElement("details")' in js
    assert 'details.className = `term-entry' in js
    assert "details.open = true" not in js
    assert 'form.append("file_types"' in js
    assert 'form.append("file_types_list"' in js
    assert "MAX_POLL_RETRIES" in js
