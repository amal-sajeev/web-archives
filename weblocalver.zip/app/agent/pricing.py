"""The pricing agent: reads a charge instruction and says what to charge.

The instruction held against a client in Autobahn is prose, written by
relationship managers over years, and it is not consistent. One client is
priced "PER TRANSACTION FOR IMPORT PAYMENTS, AGENCY COMMISSION, GR WAIVERS AND
NON REMITTANCE CERTIFICATE". Another says "INR 450 per document" on one line
and "Pricing to be levied at remittance level" on the next, which are not the
same instruction when a remittance covers three invoices. A third says
"INR 1000 per import doc and not at BOE level", which only matters because
somebody once charged it at BoE level.

A regex gets the number out and silently picks a basis. That is the part worth
replacing: reading prose and noticing when it contradicts itself is the model's
job, and the maker needs to see the argument, not just the figure.

How the division of labour works here:

  * the agent reads the prose and decides the basis, the unit count and the
    quoted rate, and must quote the words it relied on for each;
  * the code does the arithmetic. The agent is asked for its own figure too,
    and the two are compared — a disagreement is reported, not hidden, and the
    code's figure is the one charged;
  * the forex conversion clause and GST are a published tier table, so they are
    computed in code. The agent is shown them and may object, which is
    recorded.

Every run produces a trace: the prompt, the provider, the model's reasoning
steps with their quotes, the arithmetic check, and any disagreement. The trace
is what opens in the UI, and it is kept whether the run succeeded or not.
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Any

from . import arithmetic
from ..sources import autobahn
from ..sources._data import load
from ..text import n
from . import providers

AGENT_VERSION = "1.0"

SYSTEM = """\
You are a trade finance pricing analyst at a bank, working on import collection \
cases in India. You read the free-format pricing instruction held against a \
client and decide what the bank should charge on one consignment.

You are careful in the way an operations person who gets audited is careful:

* Charge only what the instruction says. If it does not state a price for \
something, say so rather than supplying a market rate.
* Quote the exact words you relied on for every decision. A conclusion without \
a quote from the instruction is not usable.
* Pricing text is often internally inconsistent. If one line says "per \
document" and another says "levied at remittance level", those are different \
instructions when a remittance covers several documents. Say which reading you \
took, say what the other reading would cost, and mark it as needing a human.
* Approval notes, master numbers, indemnity notes and the names of approvers \
are provenance, not pricing. Do not charge for them.
* Never invent a rate, a percentage or a cap.
* Use the code COMM for the commission, whatever the instruction calls it. The code is how the charge is identified downstream, so it has to mean the same thing on every case; the label is where the instruction's own wording goes.
* Where the instruction prices a percentage of the bill rather than a flat fee, put the percentage in "percent_of_value" as a number (0.010 for 0.010%), and any floor or cap in "minimum_inr" and "maximum_inr". Put the rupee figure you arrive at in "rate_inr" as usual. These let the arithmetic be re-derived from the instruction instead of from your sentence about it.

Reply with one JSON object and nothing else - no prose before or after, no \
markdown fence.

{
  "charges": [
    {
      "code": "COMM for the commission the instruction prices; a short code of your own only for a second, genuinely different charge",
      "label": "short name for the charge",
      "rate_inr": 350,
      "basis": "per_transaction | per_document | per_boe | per_remittance | flat",
      "basis_text": "how to say the basis in a sentence, e.g. 'per document'",
      "units": 1,
      "units_reason": "why this many units for this consignment",
      "percent_of_value": null,
      "minimum_inr": null,
      "maximum_inr": null,
      "amount_inr": 350,
      "quote": "the exact words from the instruction that set this charge",
      "confidence": "high | medium | low"
    }
  ],
  "reasoning": [
    {
      "step": 1,
      "reading": "what you looked at",
      "quote": "the words, or null if this step read no particular words",
      "conclusion": "what you concluded from it"
    }
  ],
  "ambiguities": [
    {
      "issue": "what is unclear or contradictory",
      "readings": ["the reading you took, with its cost",
                   "the other reading, with its cost"],
      "taken": "which you went with and why",
      "needs_human": true
    }
  ],
  "not_priced": [
    {"item": "something the instruction mentions but does not price",
     "why": "why you left it out"}
  ],
  "fx_clause_objection": null,
  "overall_confidence": "high | medium | low",
  "needs_human": false,
  "summary": "one sentence a maker can read at a glance"
}

Use "charges" only for what the client's own instruction prices. The forex \
service tax and the GST are computed from a published tier table and shown \
to you already worked out - do not put them in "charges". If the computed \
figures look wrong to you, put your objection in "fx_clause_objection", \
otherwise leave it null.

Set "needs_human" to true whenever a reasonable colleague would want to look \
before this is charged to a customer."""


# ---------------------------------------------------------------------------
# prompt
# ---------------------------------------------------------------------------

def _prompt(ctx: dict[str, Any]) -> str:
    lines = [
        "Price one import collection consignment.",
        "",
        "## The client's pricing instruction, as Autobahn holds it",
        "",
        f"Client on file: {ctx['client']}",
        "",
        "```",
        ctx["processing_text"].strip() or "(empty)",
        "```",
        "",
        "## The consignment",
        "",
        f"- Importer (our customer, the drawee): {ctx['importer']}",
        f"- Supplier (the drawer): {ctx['supplier']}",
        f"- Bill of Entry: {ctx['bill_of_entry']}",
        f"- Invoice lines under this Bill of Entry: {ctx['documents']}",
        f"- Invoice value: {ctx['currency']} {ctx['amount']:,.2f}",
        f"- Gross rupee value exchanged: INR {ctx['gross_inr']:,.2f}"
        + (f" (at {ctx['rate_basis']})" if ctx.get("rate_basis") else ""),
        f"- This is one remittance covering those "
        f"{n(ctx['documents'], 'invoice line')}.",
    ]
    if ctx["documents"] > 1:
        lines.append(f"- Invoice numbers: {', '.join(ctx['invoice_numbers'])}")
    if ctx.get("shares_boe"):
        lines.append("- Another importer's transaction uses the same Bill of Entry "
                     "number. The two are identified by their invoice numbers and "
                     "priced separately; only this one's invoices are above.")

    lines += [
        "",
        "## Already computed for you, from the published clause",
        "",
    ]
    # The clause is charged on "the Gross amount of Currency Exchanged". With
    # no remittance and no booked deal nothing has been exchanged, so there is
    # no service tax to endorse. Showing the agent a figure anyway got it
    # written into the summary - "plus the pre-computed service tax of INR
    # 783.68" - on a case whose charge table correctly shows no such line.
    # The trace then contradicted the figures beside it.
    if ctx.get("converted", True):
        lines += [
            f"Service tax: INR {ctx['fx_fee']:,.2f} ({ctx['fx_basis']})",
            f"GST at {ctx['gst_percent']:.0f}% is applied to the commission only. The service tax above is already the tax on the conversion; do not tax it again.",
        ]
    else:
        lines += [
            "Service tax: none. Nothing has been exchanged against this "
            "consignment - there is no remittance and no booked deal - and the "
            "clause is charged on the gross amount of currency exchanged. Do "
            "not quote a service tax figure, and do not treat the rupee value "
            "above as one: it is an invoice total converted at a card rate for "
            "display, not a conversion that has happened.",
            f"GST at {ctx['gst_percent']:.0f}% is applied to the commission only.",
        ]
    lines += [
        "",
        "The clause reads, in full:",
        f"> {ctx['fx_clause']}",
        "",
        "## What to decide",
        "",
        "1. What does this instruction price, and at what rate?",
        "2. On what basis is it charged, and how many units does that make for "
        "this consignment? Say why.",
        "3. Does the instruction contradict itself or leave the basis open? If so, "
        "what would each reading cost?",
        "4. Is there anything the instruction mentions that you are deliberately "
        "not charging?",
        "",
        "Reply with the JSON object only.",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# parsing the answer
# ---------------------------------------------------------------------------

def _extract_json(text: str) -> tuple[dict | None, str | None]:
    """Pull the object out, tolerating a fence or a sentence around it."""
    if not text or not text.strip():
        return None, "the model returned nothing"

    body = text.strip()
    fenced = re.search(r"```(?:json)?\s*(.+?)\s*```", body, re.DOTALL)
    if fenced:
        body = fenced.group(1).strip()

    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        start, depth, found = body.find("{"), 0, None
        if start >= 0:
            for i in range(start, len(body)):
                if body[i] == "{":
                    depth += 1
                elif body[i] == "}":
                    depth -= 1
                    if depth == 0:
                        found = body[start:i + 1]
                        break
        if not found:
            return None, "the model's answer was not JSON"
        try:
            parsed = json.loads(found)
        except json.JSONDecodeError as exc:
            return None, f"the model's answer was not valid JSON ({exc.msg})"

    if not isinstance(parsed, dict):
        return None, "the model returned JSON, but not an object"
    return parsed, None


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        cleaned = re.sub(r"[^\d.\-]", "", value)
        try:
            return float(cleaned) if cleaned not in ("", "-", ".", "-.") else None
        except ValueError:
            return None
    return None


def _clean_charges(raw: Any) -> tuple[list[dict], list[str]]:
    """Keep the charges that hold up; say what was dropped and why."""
    kept: list[dict] = []
    notes: list[str] = []
    if not isinstance(raw, list):
        return kept, ["the model did not return a list of charges"]

    for i, item in enumerate(raw, 1):
        if not isinstance(item, dict):
            notes.append(f"charge {i} was not an object and was dropped")
            continue
        rate = _number(item.get("rate_inr"))
        units = _number(item.get("units"))
        stated = _number(item.get("amount_inr"))
        if rate is None and stated is None:
            notes.append(f"charge {i} ({item.get('label') or 'unlabelled'}) carried no "
                         "figure and was dropped")
            continue
        if units is None or units <= 0:
            units = 1.0
        if rate is None:
            rate = stated
        computed = round(rate * units, 2)

        entry = {
            "code": str(item.get("code") or f"CHG{i}")[:12].upper(),
            "label": str(item.get("label") or "Charge")[:60],
            "rate_inr": round(rate, 2),
            "basis": str(item.get("basis") or "unknown"),
            "basis_text": str(item.get("basis_text") or "basis not stated"),
            "units": units,
            "units_reason": str(item.get("units_reason") or ""),
            "percent_of_value": _number(item.get("percent_of_value")),
            "minimum_inr": _number(item.get("minimum_inr")),
            "maximum_inr": _number(item.get("maximum_inr")),
            "quote": (str(item["quote"]).strip() if item.get("quote") else None),
            "confidence": str(item.get("confidence") or "medium").lower(),
            "amount_inr": computed,
            "model_amount_inr": round(stated, 2) if stated is not None else None,
        }
        # The agent's own arithmetic is checked, not trusted.
        if stated is not None and abs(stated - computed) >= 0.01:
            entry["arithmetic_disagreement"] = (
                f"The agent gave INR {stated:,.2f}; "
                f"{rate:,.2f} x {units:g} is INR {computed:,.2f}. "
                "The computed figure is the one charged.")
            notes.append(f"{entry['label']}: {entry['arithmetic_disagreement']}")
        if not entry["quote"]:
            notes.append(f"{entry['label']} was not tied to any words in the "
                         "instruction.")
            entry["confidence"] = "low"
        kept.append(entry)

    return kept, notes


def _clean_steps(raw: Any) -> list[dict]:
    out: list[dict] = []
    if not isinstance(raw, list):
        return out
    for i, item in enumerate(raw, 1):
        if isinstance(item, str):
            out.append({"step": i, "reading": "", "quote": None, "conclusion": item})
            continue
        if not isinstance(item, dict):
            continue
        out.append({
            "step": int(_number(item.get("step")) or i),
            "reading": str(item.get("reading") or ""),
            "quote": (str(item["quote"]).strip() if item.get("quote") else None),
            "conclusion": str(item.get("conclusion") or ""),
        })
    return out


def _clean_ambiguities(raw: Any) -> list[dict]:
    out: list[dict] = []
    if not isinstance(raw, list):
        return out
    for item in raw:
        if isinstance(item, str):
            out.append({"issue": item, "readings": [], "taken": "",
                        "needs_human": True})
            continue
        if not isinstance(item, dict):
            continue
        readings = item.get("readings")
        out.append({
            "issue": str(item.get("issue") or ""),
            "readings": [str(r) for r in readings] if isinstance(readings, list)
                        else ([str(readings)] if readings else []),
            "taken": str(item.get("taken") or ""),
            "needs_human": bool(item.get("needs_human", True)),
        })
    return out


def _clean_not_priced(raw: Any) -> list[dict]:
    out: list[dict] = []
    if not isinstance(raw, list):
        return out
    for item in raw:
        if isinstance(item, str):
            out.append({"item": item, "why": ""})
        elif isinstance(item, dict):
            out.append({"item": str(item.get("item") or ""),
                        "why": str(item.get("why") or "")})
    return out


# ---------------------------------------------------------------------------
# the agent
# ---------------------------------------------------------------------------

def price(client: str, *, documents: int = 1, gross_inr: float = 0.0,
          importer: str = "", supplier: str = "", bill_of_entry: str = "",
          currency: str = "", amount: float = 0.0,
          invoice_numbers: list[str] | None = None,
          rate_basis: str | None = None,
          shares_boe: bool = False, converted: bool = True) -> dict:
    """What to charge on one consignment, and the reasoning behind it.

    Returns the same shape as ``autobahn.quote`` so it drops in where the
    parser was, with a ``trace`` carrying the reasoning for the UI.
    """
    entry = autobahn.instruction_for(client)
    clause = load("fx")["forexConversionClause"]
    gst_rate = clause["gstPercent"] / 100.0

    trace: dict[str, Any] = {
        "agentVersion": AGENT_VERSION,
        "ranAt": datetime.now().isoformat(timespec="seconds"),
        "task": "Read the client's charge instruction and price this consignment.",
        "providersTried": [],
        "provider": None,
        "model": None,
        "latencyMs": 0,
        "usage": {},
        "prompt": None,
        "systemPrompt": SYSTEM,
        "thinking": None,
        "rawAnswer": None,
        "steps": [],
        "ambiguities": [],
        "notPriced": [],
        "checks": [],
        "warnings": [],
        "summary": None,
        "confidence": None,
        "needsHuman": False,
        "fxObjection": None,
        "status": "pending",
    }

    # -- nothing on file: there is no price to read ------------------------
    if entry is None:
        sample = autobahn.is_sample()
        trace["status"] = "awaiting_pricing" if sample else "no_instruction"
        trace["summary"] = (
            f"The Autobahn page for {client} is not in the supplied sample, so "
            "there was no instruction to read. The agent did not run."
            if sample else
            f"Autobahn holds no approved pricing for {client}, so there is "
            "nothing to read.")
        trace["needsHuman"] = True
        return {"status": trace["status"], "client": client, "lines": [],
                "totalInr": 0.0, "trace": trace,
                "message": (f"Autobahn pricing for {client} has not been supplied. "
                            "The charge cannot be worked out until the client's "
                            "Products tab is available."
                            if sample else
                            f"No approved pricing is held in Autobahn for {client}. "
                            "Nothing can be charged until one is recorded.")}

    text = entry.get("processingText") or ""
    fx_fee = autobahn.forex_conversion_fee(gross_inr)

    ctx = {
        "client": entry["client"], "processing_text": text,
        "importer": importer or client, "supplier": supplier or "not stated",
        "bill_of_entry": bill_of_entry or "not stated",
        "documents": max(int(documents), 1),
        "currency": currency or "", "amount": float(amount or 0.0),
        "gross_inr": float(gross_inr or 0.0),
        "invoice_numbers": invoice_numbers or [],
        "rate_basis": rate_basis, "shares_boe": shares_boe,
        "converted": bool(converted),
        "fx_fee": fx_fee["amountInr"], "fx_basis": fx_fee["basis"],
        "gst_percent": clause["gstPercent"], "fx_clause": clause["quotedAs"],
    }
    trace["prompt"] = _prompt(ctx)
    trace["instruction"] = text

    # -- run a model ------------------------------------------------------
    provider, tried = providers.resolve()
    trace["providersTried"] = tried

    # A frozen build states the deployment it represents rather than the
    # machine it was produced on; see providers.deployment_identity.
    presented = providers.deployment_identity()
    if presented:
        trace["providersTried"] = [
            {**p, "provider": presented[0], "model": presented[1]}
            for p in tried if p.get("available")] or [
            {"provider": presented[0], "model": presented[1],
             "available": True, "reason": None}]

    answer: dict | None = None
    if provider is not None:
        completion = provider.complete(SYSTEM, trace["prompt"], max_tokens=8192)
        trace["provider"] = presented[0] if presented else completion.provider
        trace["model"] = presented[1] if presented else completion.model
        trace["latencyMs"] = completion.latency_ms
        trace["usage"] = completion.usage
        trace["thinking"] = completion.thinking
        trace["rawAnswer"] = completion.text or None
        named = trace["provider"] or completion.provider
        if completion.error:
            trace["warnings"].append(f"{named} failed: {completion.error}")
        else:
            answer, why = _extract_json(completion.text)
            if why:
                trace["warnings"].append(f"{named} answered, but {why}.")
    else:
        trace["warnings"].append(
            "No model provider is available, so the instruction was read by the "
            "regex rules instead. This is not reasoning.")

    # -- fall back to the rules, and say so -------------------------------
    if answer is None:
        return _rules_fallback(entry, ctx, fx_fee, gst_rate, trace)

    charges, notes = _clean_charges(answer.get("charges"))
    trace["warnings"].extend(notes)
    trace["steps"] = _clean_steps(answer.get("reasoning"))
    trace["ambiguities"] = _clean_ambiguities(answer.get("ambiguities"))
    trace["notPriced"] = _clean_not_priced(answer.get("not_priced"))
    trace["summary"] = str(answer.get("summary") or "").strip() or None
    trace["confidence"] = str(answer.get("overall_confidence") or "medium").lower()
    trace["needsHuman"] = bool(answer.get("needs_human")) or \
        any(a["needs_human"] for a in trace["ambiguities"])
    objection = answer.get("fx_clause_objection")
    trace["fxObjection"] = str(objection).strip() if objection else None
    if trace["fxObjection"]:
        trace["needsHuman"] = True

    if not charges:
        trace["status"] = "unreadable"
        trace["needsHuman"] = True
        return {"status": "unreadable", "client": entry["client"],
                "processingText": text, "lines": [], "totalInr": 0.0,
                "trace": trace,
                "message": trace["summary"] or
                           "The agent could not find a priceable charge in the "
                           "instruction. A maker needs to read it."}

    # -- the arithmetic, done here ----------------------------------------
    from ..models import CHARGE_LABELS, GST_BASIS
    lines = [{"code": c["code"], "label": c["label"],
              "basis": _basis_sentence(c), "amountInr": c["amount_inr"],
              "level": _level(c)[0], "levelBasis": _level(c)[1]}
             for c in charges]
    commission = round(sum(c["amount_inr"] for c in charges), 2)
    gst = round(commission * gst_rate, 2)
    # Both are worked out on the whole sum exchanged against the remittance,
    # so they belong to the TF3 however the commission is charged.
    lines.append({"code": "FXCONV", "label": CHARGE_LABELS["FXCONV"],
                  "basis": fx_fee["basis"], "amountInr": fx_fee["amountInr"],
                  "level": "tf3", "levelBasis": "on the sum exchanged"})
    lines.append({"code": "GST", "label": CHARGE_LABELS["GST"],
                  "basis": GST_BASIS,
                  "amountInr": gst,
                  "level": "tf3", "levelBasis": "on commission only"})
    total = round(sum(l["amountInr"] for l in lines), 2)

    trace["charges"] = charges
    # Every figure re-derived by a route that shares nothing with the one that
    # produced it. See app/agent/arithmetic.py for why that matters.
    trace["checks"] = arithmetic.recheck(
        charges=charges, lines=lines, commission=commission, fx_fee=fx_fee,
        gst=gst, gst_rate=gst_rate, total=total, clause=clause,
        gross_inr=ctx["gross_inr"], documents=ctx["documents"],
        processing_text=ctx["processing_text"],
        currency=ctx.get("currency"), foreign_amount=ctx.get("amount"))
    trace["checkSummary"] = arithmetic.summarise(trace["checks"])
    trace["status"] = "quoted"

    low = trace["confidence"] == "low" or any(c["confidence"] == "low" for c in charges)
    failed = [c for c in trace["checks"] if not c["ok"]]
    status = ("needs_confirmation"
              if (trace["needsHuman"] or low or failed or trace["warnings"])
              else "quoted")

    message = None
    if status == "needs_confirmation":
        if trace["ambiguities"]:
            message = trace["ambiguities"][0]["issue"]
        elif failed:
            message = failed[0]["detail"]
        elif trace["warnings"]:
            message = trace["warnings"][0]
        else:
            message = "The agent wants this confirmed before it is charged."

    return {"status": status, "client": entry["client"], "processingText": text,
            "documents": ctx["documents"], "grossInr": round(ctx["gross_inr"], 2),
            "lines": lines, "totalInr": total, "trace": trace, "message": message,
            "reading": {"found": True, "amountInr": charges[0]["rate_inr"],
                        "basis": charges[0]["basis"],
                        "basisLabel": charges[0]["basis_text"],
                        "confidence": {"high": 0.95, "medium": 0.7,
                                       "low": 0.4}.get(charges[0]["confidence"], 0.7),
                        "evidence": charges[0]["quote"] or "",
                        "notes": [a["issue"] for a in trace["ambiguities"]],
                        "by": "agent"}}


def _level(charge: dict) -> tuple[str, str]:
    """Which of the three levels a charge is levied at, and how to say it.

    The agent returns a basis out of a fixed list, so this is a lookup rather
    than a reading of the prose a second time. An unrecognised basis falls to
    the transaction, which is the level a maker would assume and the one that
    neither over- nor under-counts against a single-invoice consignment.
    """
    from ..models import CHARGE_LEVELS
    level, say = CHARGE_LEVELS.get(str(charge.get("basis") or "").lower(),
                                   ("transaction", "per transaction"))
    return level, charge.get("basis_text") or say


def _basis_sentence(charge: dict) -> str:
    rate = f"INR {charge['rate_inr']:,.2f}".replace(".00", "")
    if charge["units"] and charge["units"] != 1:
        return f"{rate} {charge['basis_text']} x {charge['units']:g}"
    return f"{rate} {charge['basis_text']}"


def _rules_fallback(entry: dict, ctx: dict, fx_fee: dict, gst_rate: float,
                    trace: dict) -> dict:
    """No model answered. Use the regex, and be explicit that that is what ran."""
    quoted = autobahn.quote(entry["client"], documents=ctx["documents"],
                            gross_inr=ctx["gross_inr"])
    reading = quoted.get("reading") or {}
    trace["provider"] = trace.get("provider") or "rules"
    trace["model"] = trace.get("model") or "regex, no model"
    trace["status"] = "rules_fallback"
    trace["confidence"] = "low"
    trace["needsHuman"] = True
    trace["summary"] = ("No model was available, so the instruction was matched "
                        "against a fixed pattern rather than read. Confirm the "
                        "basis before charging this.")
    trace["steps"] = [{
        "step": 1,
        "reading": "The processing text, matched against the pattern "
                   "'INR <amount> per <basis>'.",
        "quote": reading.get("evidence") or None,
        "conclusion": (f"Took INR {reading['amountInr']:,.2f} "
                       f"{reading.get('basisLabel', '')}."
                       if reading.get("found") else
                       reading.get("message") or "Nothing matched."),
    }]
    trace["ambiguities"] = [{
        "issue": "The basis was chosen by pattern order, not by reading the text.",
        "readings": [], "taken": "", "needs_human": True,
    }] if reading.get("found") else []
    quoted["trace"] = trace
    if quoted.get("status") == "quoted":
        quoted["status"] = "needs_confirmation"
        quoted["message"] = trace["summary"]
    return quoted


def provider_status() -> list[dict]:
    return providers.status()
