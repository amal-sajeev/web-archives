"""Trade Collections — Maker Workbench.

Run with:  uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

import inspect
from pathlib import Path
from urllib.parse import quote_plus

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .api import router as api_router
from .models import CaseStatus
from .sources.router import router as mock_router
from .store import VIEWS, CaseStore, get_store
from .text import is_are, n, verb

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title="Trade Collections — Maker Workbench",
    description="Import collections from IDPMS and TradePay, checked, priced and "
                "posted to TF3. External systems are mocked under /api/mock.",
    version="3.0.0",
)
app.include_router(api_router)
app.include_router(mock_router)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
# "1 invoice line", not "1 invoice line(s)". See app/text.py.
templates.env.globals["n"] = n
# The branch a TF3 reference was raised at, from its prefix.
from .store import tf3_branch as _tf3_branch
templates.env.globals["branch_of"] = _tf3_branch
# An address prints as supplied, with its own empty components closed
# up. The punctuation is the only thing touched.
from .sources._data import tidy_address as _tidy_address
templates.env.filters["addr"] = _tidy_address


def _place(supplier: str | None, country: str | None) -> str:
    """A supplier and where it is, without saying the country twice.

    IDPMS carries "XIANGYANG CITY WEALTH CORP., LTD. CHINA" with CHINA in
    the country column as well, and appending one to the other read
    "... LTD. CHINA, China" - which looks like a rendering fault rather
    than two fields that happen to agree.
    """
    name = (supplier or "").strip()
    place = (country or "").strip()
    if not name:
        return place.title()
    if not place or name.upper().rstrip(".,").endswith(place.upper()):
        return name
    return f"{name}, {place.title()}"


templates.env.globals["place_of"] = _place
from .network import fmt_inr as _fmt_inr
templates.env.globals["inr"] = _fmt_inr

THEMES = {"desk", "corp"}
DEFAULT_THEME = "corp"

# Only dimensions the supplied data actually carries.
SORT_LABELS = {
    "boe_date":    "Bill of Entry date",
    "shipment":    "Shipment date",
    "amount":      "Invoice value",
    "charges":     "Charges",
    "outstanding": "Things outstanding",
    "checks":      "Checks passed",
    "importer":    "Importer",
    "supplier":    "Supplier",
    "invoices":    "Invoice lines",
    "currency":    "Currency",
    "port":        "Port of discharge",
    "boe":         "Bill of Entry",
    "status":      "Status",
}

DESK_SORTS = ["boe_date", "amount", "outstanding", "importer", "charges", "shipment"]


def pick_theme(request: Request, v: str | None) -> str:
    if v in THEMES:
        return v
    cookie = request.cookies.get("view")
    return cookie if cookie in THEMES else DEFAULT_THEME


_TEMPLATE_WANTS_REQUEST = "request" in inspect.signature(
    Jinja2Templates.TemplateResponse).parameters


def render(theme: str, name: str, ctx: dict) -> HTMLResponse:
    path = f"{theme}/{name}"
    if _TEMPLATE_WANTS_REQUEST:
        response = templates.TemplateResponse(request=ctx["request"], name=path, context=ctx)
    else:
        response = templates.TemplateResponse(path, ctx)
    response.set_cookie("view", theme, max_age=60 * 60 * 24 * 30, samesite="lax")
    return response


def _qs(q: str | None, path: str, filters: dict | None) -> str:
    parts = [f"q={quote_plus(q or '')}"]
    for key, val in (filters or {}).items():
        if val and val != "all":
            parts.append(f"{key}={quote_plus(val)}")
    return f"{path}?" + "&".join(parts)


def _shell(request: Request, store: CaseStore, active: str, theme: str) -> dict:
    cases = store.all_cases()
    checker = store.session.role == "Checker"
    todo = (sum(1 for c in cases if c.status is CaseStatus.IN_CHECKER_QUEUE) if checker
            else sum(1 for c in cases if c.needs_maker))
    return {"request": request, "session": store.session, "active": active,
            "theme": theme, "counts": {"todo": todo}}


def _band(groups: list[dict], *, running: set[str]) -> dict[str, list[dict]]:
    """Each collection under the heading its worst Bill of Entry earns.

    The order is the order of trouble: anything a maker has to decide, then
    anything held up by a source we were not given, then what is clear and
    ready to post, and last what has not finished running.
    """
    out: dict[str, list[dict]] = {"todo": [], "ready": [], "held": [],
                                  "waiting": []}
    for g in groups:
        cases = g["cases"]
        if all(c.case_id in running for c in cases):
            out["waiting"].append(g)
        elif any(c.needs_maker or c.status is CaseStatus.RETURNED
                 for c in cases):
            out["todo"].append(g)
        elif any(c.waiting_on_source for c in cases):
            out["held"].append(g)
        else:
            out["ready"].append(g)
    return out


def _groups(store: CaseStore, q: str | None, sort: str | None,
            direction: str, filters: dict) -> tuple[list, list, list, list]:
    """todo, ready, held (waiting on a source), waiting (not yet run).

    Every open case must land in exactly one of these. A case that matches none
    of them disappears from the worklist, which is worse than showing it in the
    wrong place.
    """
    kw = {"search": q, **{k: v for k, v in filters.items() if v and v != "all"}}
    if sort:
        kw |= {"sort": sort, "direction": direction}
    if store.session.role == "Checker":
        return store.list_cases(view="checker", **kw), [], [], []
    rows = store.list_cases(view="all", **kw)
    running = (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING)
    todo, ready, held, waiting = [], [], [], []
    for c in rows:
        if c.status in running:
            waiting.append(c)
        elif c.needs_maker or c.status is CaseStatus.RETURNED:
            todo.append(c)
        elif c.waiting_on_source:
            held.append(c)
        else:
            ready.append(c)
    return todo, ready, held, waiting


@app.get("/", response_class=HTMLResponse)
def queue(request: Request, q: str | None = None, v: str | None = None,
          sort: str | None = None, direction: str = "asc",
          importer: str = "all", currency: str = "all", status: str = "all",
          open: str = "",
          store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    if sort not in SORT_LABELS:
        sort = None
    direction = "desc" if direction == "desc" else "asc"
    filters = {"importer": importer, "currency": currency, "status": status}
    todo, ready, held, waiting = _groups(store, q, sort, direction, filters)
    checker = store.session.role == "Checker"
    # The worklist is indexed on the TF3 reference, because that is what
    # payment is processed against; each band keeps its own grouping so a
    # collection appears under the heading its worst consignment earns.
    from .store import collections as _collect
    # Group once over every case, then put each collection in a band — not
    # the other way round. Grouping inside each band split a TF3 whose bills
    # are in different states: ICS2622880 has one bill needing a decision
    # and one waiting on a source, and it appeared twice, once under each
    # heading, as though the bank were paying it twice. Payment runs against
    # the reference, so the reference is one row, and it sits under the
    # heading its worst bill earns.
    bands = _band(_collect(todo + ready + held + waiting, q,
                           sort=sort, direction=direction),
                  running={c.case_id for c in waiting})
    total = len(todo) + len(ready) + len(held)

    if checker:
        greeting = f"{len(todo)} to check" if todo else "Nothing to check yet"
        if todo:
            summary = ("Each has been validated by a maker and is waiting on your "
                       "control. Approve it, or send it back with a reason.")
        else:
            # NB: not `ready` — that name holds the ready list from _groups.
            awaiting_maker = sum(
                1 for c in store.all_cases()
                if c.status is CaseStatus.READY_FOR_REVIEW and not c.needs_maker)
            summary = ("A case reaches you once a maker has validated it — the "
                       "second pair of eyes is the point, so you cannot check your "
                       "own work."
                       + (f" {n(awaiting_maker, 'case')} "
                          f"{is_are(awaiting_maker)} ready for a maker to "
                          "validate now." if awaiting_maker else ""))
    elif total:
        # Counted in TF3 references, because that is what the list shows and
        # what gets paid. Saying "12 collections" over nine rows invites the
        # reader to work out which number is wrong.
        shown = sum(len(bands[b]) for b in ("todo", "ready", "held"))
        greeting = f"{n(shown, 'collection')} open"
        parts = []
        if todo:
            count = len(bands["todo"])
            parts.append(f"{count} {verb(count, 'need')} a decision")
        if ready:
            parts.append(f"{len(bands['ready'])} ready to post")
        if held:
            parts.append(f"{len(bands['held'])} waiting on a source")
        # Not str.capitalize, which lower-cases everything after the first
        # letter and would quietly undo any other word that earns a capital.
        summary = ", ".join(parts[:-1]) + (" and " if len(parts) > 1 else "")             + parts[-1] + "."
        summary = summary[0].upper() + summary[1:]
    else:
        greeting = "Queue is clear"
        summary = "No open collections."

    ctx = _shell(request, store, "queue", theme)
    ctx.update({
        "bands": bands, "opened": open,
        # The grid in the corporate view shows every band at once, worst
        # first, so it gets them flattened in that order.
        "collections": [g for b in ("todo", "ready", "held", "waiting")
                        for g in bands[b]],
        "todo": todo, "ready": ready, "held": held, "waiting": waiting,
        "q": q or "", "greeting": greeting, "summary": summary,
        "progress": {c.case_id: store.progress(c) for c in waiting},
        "sort": sort, "direction": direction, "sort_labels": SORT_LABELS,
        "desk_sorts": DESK_SORTS, "filters": filters,
        "filtered": any(x != "all" for x in filters.values()),
        "base_qs": _qs(q, "/", filters),
        "importers": store.importers(), "currencies": store.currencies(),
        "rows": (store.list_cases(view="checker" if checker else "all", search=q,
                                  sort=sort, direction=direction,
                                  **{k: val for k, val in filters.items() if val != "all"})
                 if sort else todo + ready + held + waiting),
    })
    return render(theme, "queue.html", ctx)


@app.get("/done", response_class=HTMLResponse)
def done(request: Request, q: str | None = None, v: str | None = None,
         sort: str | None = None, direction: str = "asc",
         store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    if sort not in SORT_LABELS:
        sort = None
    direction = "desc" if direction == "desc" else "asc"
    kw = {"search": q} | ({"sort": sort, "direction": direction} if sort else {})
    posted = store.list_cases(view="completed", **kw)
    sent = store.list_cases(view="checker", **kw)
    ctx = _shell(request, store, "done", theme)
    # Grouped the same way the worklist is. Without this the page renders
    # its headings and then nothing under them, because the template reads
    # the collections out of `bands` and there were none to read.
    from .store import collections as _collect
    bands = {"todo": [], "held": [],
             "ready": _collect(sent, q, sort=sort, direction=direction),
             "waiting": _collect(posted, q, sort=sort, direction=direction)}
    ctx.update({
        "bands": bands, "opened": "",
        "collections": bands["ready"] + bands["waiting"],
        "todo": [], "ready": sent, "held": [], "waiting": posted, "q": q or "",
        "greeting": "Finished",
        # This route renders the worklist template, so it has to say which
        # worklist it is. Without these it announced itself as "Collections
        # worklist" and, when empty, invited the reader to wait for IDPMS to
        # deliver - which is the other page's job and the other page's queue.
        "heading": "Finished collections",
        "empty_title": "Nothing finished yet",
        "empty_body": "A collection appears here once a maker validates it "
                      "and a checker approves it.",
        "summary": f"{len(sent)} with the checker, {len(posted)} posted to TF3.",
        "progress": {}, "sort": sort, "direction": direction,
        "sort_labels": SORT_LABELS, "desk_sorts": DESK_SORTS,
        "filters": {"importer": "all", "currency": "all", "status": "all"},
        "filtered": False, "base_qs": _qs(q, "/done", None),
        "importers": store.importers(), "currencies": store.currencies(),
        "rows": sent + posted,
    })
    return render(theme, "queue.html", ctx)


@app.get("/cases/{case_id}", response_class=HTMLResponse)
def case_detail(request: Request, case_id: str, v: str | None = None,
                store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    case = store.get(case_id)
    if case is None:
        raise HTTPException(404, f"Case {case_id} not found")
    todo, ready, held, _ = _groups(store, None, None, "asc",
                                   {"importer": "all", "currency": "all",
                                    "status": "all"})
    queue = [c for c in todo + ready + held if c.case_id != case.case_id]
    ctx = _shell(request, store, "queue", theme)
    ctx["case"] = case
    ctx["next_case"] = queue[0] if queue else None
    return render(theme, "case.html", ctx)


@app.get("/cases/{case_id}/runlog", response_class=HTMLResponse)
def case_runlog(request: Request, case_id: str, v: str | None = None,
                store: CaseStore = Depends(get_store)) -> HTMLResponse:
    """Just the run panel.

    The case page asks for this every second while a run is in flight, so the
    panel is drawn by the same template whether it arrives with the page or
    arrives on its own. One renderer, no second copy of the markup in JS.
    """
    case = store.get(case_id)
    if case is None:
        raise HTTPException(404, f"Case {case_id} not found")
    theme = pick_theme(request, v)
    return render(theme, "partials/_runlog.html",
                  {"request": request, "case": case})


# --------------------------------------------------------------- reference

@app.get("/network", response_class=HTMLResponse)
def network_page(request: Request, v: str | None = None, view: str = "",
                 only: str = "", country: str = "", importer: str = "",
                 q: str = "", currency: str = "", port: str = "",
                 band: str = "",
                 store: CaseStore = Depends(get_store)) -> HTMLResponse:
    """The whole book as one picture: counterparties, importers, transactions.

    The layout and the findings are worked out in ``app/network.py`` and sent
    as coordinates, so the page needs no script to draw itself. Narrowing is a
    query string rather than client state, because a large book is read by
    narrowing it and a link to a narrowed map should be a link somebody can
    send.
    """
    from . import network
    theme = pick_theme(request, v)
    ctx = _shell(request, store, "network", theme)
    ctx["graph"] = network.build(store.all_cases(), view=view, only=only,
                                 country=country, importer=importer, q=q,
                                 currency=currency, port=port, band=band)
    return render(theme, "network.html", ctx)


@app.get("/scenarios", response_class=HTMLResponse)
def scenarios_page(request: Request, v: str | None = None,
                   store: CaseStore = Depends(get_store)) -> HTMLResponse:
    """The book arranged by the workbook it arrived in.

    A demo aid: the worklist is indexed on the TF3 reference because that is
    what payment runs against, but the bank sent three files and each makes a
    different point, so this says which is which.
    """
    from . import scenarios
    from .store import collections as _collect
    theme = pick_theme(request, v)
    cases = store.all_cases()
    ctx = _shell(request, store, "scenarios", theme)
    ctx["book"] = scenarios.build(cases, _collect(cases))
    ctx["match"] = lambda client: scenarios.pricing_match(client, cases)
    return render(theme, "scenarios.html", ctx)


@app.get("/ports", response_class=HTMLResponse)
def ports_page(request: Request, q: str = "", v: str | None = None,
               store: CaseStore = Depends(get_store)) -> HTMLResponse:
    from .sources import ports as port_src
    theme = pick_theme(request, v)
    state = port_src.status()
    # Resolved, not just listed. The page used to hand the template the raw
    # codes seen in the data, which carry no name, city or country, against
    # a table headed with all three: thirteen codes beside three empty
    # columns. Resolving each one is what the directory is for.
    rows = []
    for seen in state["codesSeenInData"]:
        # With the country hint the data supplied, so the row reports the
        # term the lookup really used: BKK is searched as THBKK.
        found = port_src.resolve(seen["code"], seen.get("countryHint")) or {}
        row = {**seen, **found}
        if q:
            hay = " ".join(str(row.get(k) or "") for k in
                           ("code", "name", "city", "country", "searchedAs"))
            if q.lower() not in hay.lower():
                continue
        rows.append(row)
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "ports", "title": "Port directory", "rows": rows, "q": q,
                "port_state": state,
                "blurb": "Transport documents carry a short code; TF3 needs the full "
                         "name. A five-digit code is searched as it stands, a "
                         "three-digit code with its country prefix."})
    return render(theme, "reference.html", ctx)


@app.get("/tariffs", response_class=HTMLResponse)
def tariffs_page(request: Request, v: str | None = None,
                 store: CaseStore = Depends(get_store)) -> HTMLResponse:
    from .agent import provider_status
    from .sources import autobahn
    theme = pick_theme(request, v)
    providers = provider_status()
    live = next((p for p in providers if p["available"]), None)
    coverage = autobahn.coverage(sorted({c.importer for c in store.all_cases()}))
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "tariffs", "title": "Client pricing", "q": "",
                "rows": autobahn.clients(),
                "providers": providers, "live": live, "coverage": coverage,
                "blurb": "The free-format processing text held against each client in "
                         "Autobahn. The pricing agent reads this, and its reasoning "
                         "opens from the charges card on a case."})
    return render(theme, "reference.html", ctx)


@app.get("/rules", response_class=HTMLResponse)
def rules_page(request: Request, v: str | None = None,
               store: CaseStore = Depends(get_store)) -> HTMLResponse:
    from .sources import fallback
    from .sources._data import load
    theme = pick_theme(request, v)
    data = load("checks")
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "rules", "title": "Checks and procedure", "q": "",
                "rows": data["checks"], "procedure": data,
                "cascade": fallback.status(),
                "blurb": "The consistency checks between IDPMS and TradePay, and the "
                         "procedure they sit in, as specified."})
    return render(theme, "reference.html", ctx)
