"""The case store, built from the mocked external systems.

Everything here comes out of ``app/sources``. Replacing a mock with a real
integration means changing that module; this file does not care where the data
came from.
"""

from __future__ import annotations

import re
import secrets
import threading
import time
from collections.abc import Iterator
from datetime import datetime, timedelta

from .text import listed, n as _n
from .models import (
    CHARGE_LABELS, GST_BASIS,
    AuditEntry,
    CaseStatus,
    ChargeLine,
    Charges,
    Check,
    CollectionCase,
    ComparedField,
    InvoiceLine,
    PortRef,
    Query,
    RunStep,
    ThirdParty,
)
from .agent import price as agent_price
from .agent import arithmetic
from . import graphmap
from .sources import autobahn, checks as check_rules, idpms, ports, tf3, tradepay
from .sources._data import load, normalise_name, reload as load_sources

# Only dimensions that exist in the supplied data.
SORTABLE = {
    "boe_date":   lambda c: c.bill_of_entry_date or "",
    "boe":        lambda c: c.bill_of_entry,
    "importer":   lambda c: c.importer.lower(),
    "supplier":   lambda c: c.supplier.lower(),
    "amount":     lambda c: c.total_amount,
    "currency":   lambda c: (c.currency, -c.total_amount),
    "charges":    lambda c: c.charges.total if c.charges.priced else -1.0,
    "outstanding": lambda c: len(c.action_items),
    "checks":     lambda c: (c.checks_passed / c.checks_total) if c.checks_total else 0.0,
    "invoices":   lambda c: len(c.invoice_lines),
    "shipment":   lambda c: c.latest_shipment_date or "",
    "status":     lambda c: c.status.value,
    "port":       lambda c: (c.port("discharge").code or "") if c.port("discharge") else "",
}

VIEWS: dict[str, dict] = {
    "all": {"label": "All open", "statuses": None},
    "attention": {"label": "Needs attention", "statuses": [CaseStatus.NEEDS_ATTENTION]},
    "ready": {"label": "Ready", "statuses": [CaseStatus.READY_FOR_REVIEW]},
    "processing": {"label": "Running", "statuses": [CaseStatus.RECEIVED,
                                                    CaseStatus.AI_PROCESSING]},
    "checker": {"label": "With checker", "statuses": [CaseStatus.IN_CHECKER_QUEUE]},
    "completed": {"label": "Posted", "statuses": [CaseStatus.COMPLETED]},
}

# How long a finished step stays on screen before the next one lands. The work
# itself is not slowed down - the pipeline is simply walked at reading speed
# when someone is watching. A bulk run uses no pause at all.
RUN_BEAT_S = 0.5


OPEN_STATUSES = (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING,
                 CaseStatus.NEEDS_ATTENTION, CaseStatus.READY_FOR_REVIEW,
                 CaseStatus.RETURNED)


class Session:
    """Who is driving. A real deployment reads this from SSO."""

    def __init__(self) -> None:
        self.name = "Maker"
        self.initials = "MK"
        self.role = "Maker"
        self.desk = "Trade Finance Ops"

    def switch(self, role: str) -> None:
        self.role = "Checker" if role.lower() == "checker" else "Maker"
        self.name = self.role
        self.initials = "CK" if self.role == "Checker" else "MK"


# ---------------------------------------------------------------------------
# building a case out of the sources
# ---------------------------------------------------------------------------

def _case_id(consignment: dict, shared: bool) -> str:
    boe = consignment["billOfEntryNumber"]
    if not shared:
        return boe
    word = re.sub(r"[^A-Z]", "", (consignment["importer"] or "").upper().split()[0])
    return f"{boe}-{word[:6]}"


def _invoice_date(line: dict) -> tuple[str | None, str | None]:
    """The invoice date, and which system it came from.

    IDPMS leaves this blank on fifteen of the twenty-two lines the bank sent —
    not a reading failure, the cells are empty in the file. Step 6 of the
    procedure covers it: where the information is incomplete in IDPMS, take it
    from TradePay. Twelve of the fifteen are on the portal row for the same
    invoice, so they are shown, attributed.

    The date is not one of the seven fields the checks compare, so filling it
    this way settles nothing that ought to be compared; it only stops the
    worklist printing a dash where both systems together know the answer.
    """
    if line.get("invoiceDate"):
        return line["invoiceDate"], "IDPMS"
    for row in tradepay.rows_for_invoice(line.get("invoiceNo") or ""):
        if row.get("invoiceDate"):
            return row["invoiceDate"], "TradePay"
    return None, None


def _invoice_lines(consignment: dict) -> list[InvoiceLine]:
    out = []
    for r in consignment["invoiceLines"]:
        dated, dated_by = _invoice_date(r)
        out.append(InvoiceLine(
            record_id=r["recordId"],
            invoice_no=_text(r.get("invoiceNo")),
            invoice_date=dated,
            invoice_date_source=dated_by,
            amount=_num(r.get("invoiceAmount")),
            currency=r.get("invoiceCurrency"),
            terms=_text(r.get("termsOfInvoice")),
            supplier_name=r.get("supplierName"),
            supplier_address=r.get("supplierAddress"),
            supplier_country=r.get("supplierCountry"),
            freight_amount=_num(r.get("freightAmount")),
            freight_currency=r.get("freightCurrencyCode"),
            insurance_amount=_num(r.get("insuranceAmount")),
            insurance_currency=r.get("insuranceCurrencyCode"),
            misc_amount=_num(r.get("miscellaneousCharges")),
            misc_currency=r.get("miscellaneousCurrency"),
            shipment_date=r.get("HAWB-HBLDate") or r.get("MAWB-MBLDate"),
            transport_document=_text(r.get("HAWB-HBLNumber") or r.get("MAWB-MBLNumber")),
        ))
    return out


def _text(v) -> str | None:
    """IDPMS returns codes as numbers where they happen to look numeric."""
    return None if v is None or v == "" else str(v)


def _num(v) -> float | None:
    try:
        return float(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


def _port_refs(consignment: dict) -> list[PortRef]:
    out = []
    for role, key in (("loading", "portOfShipment"), ("discharge", "portOfDischarge")):
        code = consignment.get(key)
        hint = consignment.get("supplierCountryIso2") if role == "loading" else "IN"
        r = ports.resolve(code, hint)
        out.append(PortRef(
            role=role, code=r["code"] or None, searched_as=r["searchedAs"],
            prefix_applied=r["prefixApplied"], name=r.get("name"),
            city=r.get("city"), country=r.get("country"),
            status=r["status"], message=r.get("message"),
        ))
    return out


_PRICE_CACHE: dict[tuple, dict] = {}
_PRICE_LOCK = threading.Lock()


def _price(case: CollectionCase, *, fresh: bool = False) -> Charges:
    """Charges for one case, read out of the client's instruction by the agent.

    A model call takes seconds, and the decision the agent makes depends only on
    the instruction text and how many documents the remittance covers - not on
    the rupee value, which only feeds the forex clause and is computed here. So
    the reading is cached on (client, documents) and the money is worked out per
    case. ``fresh`` skips the cache, which is what the recalculate button does.
    """
    exchanged = _gross(case, case.deal)
    gross = exchanged["amountInr"]
    # Whether anything has actually been exchanged. The clause is charged on
    # "the Gross amount of Currency Exchanged", and with no remittance and
    # no booked deal there is no exchange to charge on — only an invoice
    # total multiplied by a card rate, which is a conversion this
    # application invented. Hella's consignment is the case: a complete
    # IDPMS transaction that no capture carries a payment for, which was
    # nonetheless carrying a forex service tax worked out on a payment
    # nobody has made. Whether its remittance is still to come or was never
    # part of this batch is not something the data settles, and it does not
    # need to be: either way nothing has been converted yet.
    converted = bool(case.tradepay) or bool(
        case.deal and arithmetic._numeric(case.deal.get("rate")))
    # Whether anything was exchanged changes what the agent is told and so
    # what it may conclude, which makes it part of the reading, not of the
    # money worked out per case. Leaving it out of the key let a converted
    # case's reading be reused for an unconverted one.
    key = (normalise_name(case.importer), len(case.invoice_lines), converted)

    with _PRICE_LOCK:
        cached = None if fresh else _PRICE_CACHE.get(key)

    if cached is None:
        quote = agent_price(
            case.importer,
            documents=len(case.invoice_lines),
            gross_inr=gross,
            importer=case.importer,
            supplier=case.supplier,
            bill_of_entry=case.bill_of_entry,
            currency=case.currency,
            amount=case.total_amount,
            invoice_numbers=[l.invoice_no for l in case.invoice_lines if l.invoice_no],
            rate_basis=exchanged["basis"] or None,
            shares_boe=case.shares_boe_with_another_importer,
            converted=converted,
        )
        with _PRICE_LOCK:
            _PRICE_CACHE[key] = quote
    else:
        # Same reading, this case's money.
        quote = _restate(cached, gross)

    # Drop the service tax here rather than on the way into Charges, so the
    # re-derivation below sees the lines that will actually be charged. It
    # used to be filtered afterwards, and the arithmetic then verified a
    # total of INR 1,314.68 - agreeing with itself, both sides including a
    # service tax - beside a charge table correctly showing INR 531.00.
    if not converted and quote.get("lines"):
        quote = dict(quote)
        quote["lines"] = [l for l in quote["lines"] if l["code"] != "FXCONV"]
        quote["totalInr"] = round(sum(l["amountInr"] for l in quote["lines"]), 2)

    trace = dict(quote.get("trace") or {})
    trace["reusedReading"] = cached is not None
    trace["grossInr"] = round(gross, 2)
    # Every figure again, against this case's own money. A cached reading is
    # restated for a different transaction, so the verification that came with
    # it was of somebody else's numbers and has to be redone here.
    trace["checks"] = _recheck(quote, exchanged, case, converted)
    trace["checkSummary"] = arithmetic.summarise(trace["checks"])
    # A figure that does not agree pulls the quote back for a person. Only a
    # quote, though: a case with no pricing at all is waiting on a source, and
    # calling that "needs confirmation" would move it out of the queue where a
    # maker can see there is nothing for them to decide yet.
    if quote.get("lines") and not trace["checkSummary"]["ok"]:
        quote = dict(quote)
        quote["status"] = "needs_confirmation"
        # The arithmetic leads. A figure that does not reconcile — a card
        # rate nothing else in the book agrees with, say — is more material
        # than a note about how the instruction was read, and the note used
        # to win simply because it was set first.
        failed = trace["checkSummary"]["failed"][0]["detail"]
        existing = quote.get("message")
        quote["message"] = (f"{failed} {existing}" if existing and
                            existing not in failed else failed)

    return Charges(
        status=quote["status"],
        client=quote.get("client"),
        processing_text=quote.get("processingText"),
        reading=quote.get("reading", {}),
        agent_trace=trace,
        documents=quote.get("documents", len(case.invoice_lines)),
        gross_inr=gross,
        unconverted_note=(None if converted else
                          "Nothing has been exchanged against this "
                          "consignment yet — TradePay holds no remittance "
                          "and no deal is booked — so the service tax on "
                          "the conversion cannot be worked out. The "
                          "commission and its GST do not depend on it."),
        exchanged=_exchanged(case)[0],
        exchanged_from=_exchanged(case)[1],
        rate=arithmetic._numeric(exchanged.get("rate")),
        rate_from=exchanged.get("basis"),
        forex_value_inr=autobahn.forex_conversion_fee(gross).get("valueInr", 0.0),
        forex_value_basis=autobahn.forex_conversion_fee(gross).get("valueBasis"),
        message=quote.get("message"),
        lines=[ChargeLine(code=l["code"], label=l["label"], basis=l["basis"],
                          amount_inr=l["amountInr"],
                          level=l.get("level", "tf3"),
                          level_basis=l.get("levelBasis", ""))
               # The commission and its GST stand whatever happens to the
               # money; the tax on the conversion cannot be worked out
               # until there is a conversion.
               for l in quote.get("lines", [])],
    )


def _recheck(quote: dict, exchanged: dict, case: CollectionCase,
             converted: bool = True) -> list[dict]:
    """Re-derive every figure on the quote for this case."""
    lines = quote.get("lines") or []
    if not lines:
        return list(exchanged["checks"])
    clause = load("fx")["forexConversionClause"]
    gst_rate = clause["gstPercent"] / 100.0
    own = [l for l in lines if l["code"] not in ("FXCONV", "GST")]
    fx_line = next((l for l in lines if l["code"] == "FXCONV"), None)
    gst_line = next((l for l in lines if l["code"] == "GST"), None)
    return arithmetic.recheck(
        charges=(quote.get("trace") or {}).get("charges") or [],
        lines=lines,
        commission=round(sum(l["amountInr"] for l in own), 2),
        fx_fee={"amountInr": fx_line["amountInr"] if fx_line else 0.0},
        gst=gst_line["amountInr"] if gst_line else 0.0,
        gst_rate=gst_rate,
        total=round(sum(l["amountInr"] for l in lines), 2),
        clause=clause,
        gross_inr=exchanged["amountInr"],
        documents=len(case.invoice_lines),
        processing_text=quote.get("processingText") or "",
        gross_checks=exchanged["checks"],
        currency=case.currency,
        foreign_amount=case.total_amount,
        converted=converted)


def _restate(quote: dict, gross: float) -> dict:
    """A cached reading, with the forex fee and GST redone for this case."""
    if not quote.get("lines"):
        return quote

    clause = load("fx")["forexConversionClause"]
    gst_rate = clause["gstPercent"] / 100.0
    own = [l for l in quote["lines"] if l["code"] not in ("FXCONV", "GST")]
    fx = autobahn.forex_conversion_fee(gross)
    commission = round(sum(l["amountInr"] for l in own), 2)
    gst = round(commission * gst_rate, 2)

    lines = own + [
        {"code": "FXCONV", "label": CHARGE_LABELS["FXCONV"],
         "basis": fx["basis"], "amountInr": fx["amountInr"],
         "level": "tf3", "levelBasis": "on the sum exchanged"},
        {"code": "GST", "label": CHARGE_LABELS["GST"],
         "basis": GST_BASIS,
         "amountInr": gst,
         "level": "tf3", "levelBasis": "on commission only"},
    ]
    restated = dict(quote)
    restated["lines"] = lines
    restated["totalInr"] = round(sum(l["amountInr"] for l in lines), 2)
    restated["grossInr"] = round(gross, 2)
    return restated


def _rate_basis(case: CollectionCase) -> str | None:
    """How the rupee value was arrived at, for the agent's context.

    Taken from the conversion itself rather than worked out a second time, so
    the agent is never told one rate while the gross it is given was computed
    at another.
    """
    return _gross(case, case.deal)["basis"] or None


def _exchanged(case: CollectionCase) -> tuple[float, str]:
    """The amount the remittance converts, and where that figure came from.

    Not the sum of the invoice lines. The forex clause runs on the gross
    amount exchanged, and what is exchanged is what is paid, which the two
    differ from in both directions:

      Symrise   IDPMS invoices 11,619.72 SGD, remittance 11,699.72 — the
                invoice plus 80 SGD of miscellaneous charges, all of it
                converted. Billing the clause on the invoice total alone
                undercharged the conversion.
      Rothe     IDPMS invoices 3,057,532 CNY under one bill, remittance
                3,030,350 — five of six invoices. The sixth is not paid in
                this batch and nothing is exchanged for it.

    The portal's figure is used only when it is in the transaction's own
    currency: Putzmeister's record is in EUR against an IDPMS line in USD,
    and that disagreement is for a maker to settle, not for this to pick a
    side in.
    """
    portal = case.tradepay or {}
    amount = portal.get("invoiceAmount")
    currency = portal.get("invoiceCurrency") or case.currency
    if amount and float(amount) > 0 and currency == case.currency:
        return float(amount), "the remittance"
    return case.total_amount, "the invoice lines in IDPMS"


def _gross(case: CollectionCase, deal: dict | None) -> dict:
    """What was actually exchanged, in rupees, with the working shown.

    Worked out in ``app/agent/arithmetic`` so that the conversion is checked by
    the same pass that checks everything else, and so that a deal covering more
    than this transaction contributes its rate rather than its total.
    """
    amount, whence = _exchanged(case)
    out = arithmetic.gross_exchanged(amount=amount, currency=case.currency,
                                     deal=deal, fx=load("fx"))
    out["basisAmount"] = amount
    out["basisFrom"] = whence
    # Said out loud when the two sources differ, because the figure the
    # clause is charged on is then not the one on the face of the case.
    if abs(amount - (case.total_amount or 0.0)) >= 0.01:
        out.setdefault("checks", []).append(arithmetic._ok(
            "The amount the forex clause is charged on",
            f"{amount:,.2f} {case.currency} from {whence}, against "
            f"{case.total_amount:,.2f} on the IDPMS invoice lines. The "
            f"clause runs on what was exchanged.", "source"))
    return out


def _gross_inr(case: CollectionCase, deal: dict | None) -> float:
    return _gross(case, deal)["amountInr"]


def _usable_deal(d: dict) -> bool:
    """Is this row a deal, or a row that only landed in the deal columns?

    One row in the supplied blotter is shifted a column: its rate reads "INR",
    its INR amount reads "EUR". Converting at it would be nonsense, and quietly
    half-using it is worse than not using it, so a deal has to carry a numeric
    rate or a numeric foreign amount before it is offered to a case at all.
    """
    rate = arithmetic._numeric(d.get("rate"))
    amount = arithmetic._numeric(d.get("amount"))
    return bool(rate and rate > 0) or bool(amount and amount > 0)


def _same_client(deal_client: str | None, importer: str) -> bool:
    """The blotter truncates the client name; the two still have to be matched.

    "Sigma Aldrich Chemicals Private Lim" is cut mid-word at the blotter's
    column width, and "Lim" is not a word anything strips, so comparing the
    normalised names fails on exactly the rows that most need matching.

    Allowing either name to be the start of the other is too generous the
    other way: Bosch Limited normalises to "BOSCH", which starts Bosch Rexroth
    India and Bosch Automotive Electronics too, and would hand Bosch Limited
    somebody else's rate. So a longer name may only extend a shorter one by a
    cut-off legal suffix - "LIM" begins "LIMITED" - and never by a word that
    tells two companies apart.
    """
    a, b = normalise_name(deal_client), normalise_name(importer)
    if not a or not b:
        return False
    if a == b:
        return True
    longer, shorter = (a, b) if len(a) > len(b) else (b, a)
    if not longer.startswith(shorter):
        return False
    extra = longer[len(shorter):].split()
    # Every extra word must be the beginning of a legal-form word, which is
    # all a truncation can leave behind.
    return bool(extra) and all(
        any(form.startswith(word.lower()) for form in _LEGAL_FORMS)
        for word in extra)


# The legal-form words ``normalise_name`` strips, which is what a name cut off
# at a column edge leaves a fragment of.
_LEGAL_FORMS = ("private", "limited", "ltd", "pvt", "company", "corporation",
                "incorporated", "international", "india")


def tf3_branch(reference: str | None) -> str | None:
    """The branch a TF3 reference was raised at, from its first three digits.

    784 is Mumbai, 797 Bangalore, 916 Chennai. The table is the PBC block on
    the "TF & TRADE AC" sheet of the forex workbook, and all eight booked
    deals agree with it, so the prefix is worth reading out rather than
    carrying as three unexplained digits.
    """
    code = str(reference or "")[:3]
    return (load("fx").get("branches") or {}).get(code) if code.isdigit() else None


def _full_tf3(portal: str | None, importer: str) -> str | None:
    """The TF3 reference in the form the bank writes it.

    Two things the portal capture does not give. The branch prefix — 784 for
    Mumbai, 797 for Bangalore, 916 for Chennai — which the settlement blotter
    puts in front of every reference, and, for Symrise and Putzmeister, the
    reference itself, because their captures do not include the column.

    The blotter is the other place the reference appears. Where the portal
    does show one, the blotter row is required to end with it before its
    prefix is believed, so a client with two deals cannot lend one
    transaction the other's reference. Where the portal shows none, the
    blotter is used only if the client has exactly one deal to be confused
    with.
    """
    deals = load("deals").get("records", [])
    if portal:
        for d in deals:
            ref = str(d.get("reference") or "")
            if ref and ref != portal and ref.endswith(portal):
                return ref
        return portal
    mine = [str(d.get("reference")) for d in deals
            if d.get("reference") and _same_client(d.get("client"), importer)]
    return mine[0] if len(mine) == 1 else None


def _deal_for(importer: str, currency: str, reference: str | None = None) -> dict | None:
    """The deal booked for this client in this currency, or nothing.

    Only in this currency: a deal in another one tells us nothing about what
    this transaction exchanged at, and returning it as a near-miss used to put
    a EUR total on a THB case.
    """
    deals = load("deals").get("records", [])
    # A TF3 reference is the strongest join between the payment and its booked
    # settlement. Prefer it so a client with multiple deals in one currency
    # cannot inherit another remittance's exchange rate.
    if reference:
        wanted = str(reference).strip().casefold().replace(" ", "")
        for d in deals:
            booked = str(d.get("reference") or "").strip().casefold().replace(" ", "")
            # The deals workbook includes a branch prefix (for example
            # 784ICS2615375), while TradePay exposes the payment reference
            # without that prefix (ICS2615375). Match the complete shared
            # reference suffix, not an arbitrary substring.
            same_reference = bool(booked and wanted and
                                  (booked == wanted or booked.endswith(wanted)
                                   or wanted.endswith(booked)))
            if (same_reference and d.get("currency") == currency and _usable_deal(d)):
                return d
    for d in deals:
        if (d.get("currency") == currency and _usable_deal(d)
                and _same_client(d.get("client"), importer)):
            return d
    return None


def build_cases() -> list[CollectionCase]:
    cases: list[CollectionCase] = []
    for consignment in idpms.consignments():
        shared = consignment["sharesBoeWithAnotherImporter"]
        case = CollectionCase(
            case_id=_case_id(consignment, shared),
            bill_of_entry=consignment["billOfEntryNumber"],
            bill_of_entry_date=consignment["billOfEntryDate"],
            importer=consignment["importer"],
            importer_code=_text(consignment.get("importerCode")),
            importer_pan=_text(consignment.get("importerPan")),
            importer_address=_text(consignment.get("importerAddress")),
            ad_code=_text(consignment.get("adCode")),
            ports=_port_refs(consignment),
            invoice_lines=_invoice_lines(consignment),
            third_parties=[ThirdParty(**t) for t in consignment.get("thirdParties", [])],
            latest_shipment_date=consignment.get("latestShipmentDate"),
            duplicate_lines_removed=consignment.get("duplicateLinesRemoved", 0),
            shares_boe_with_another_importer=shared,
        )
        # Match on Bill of Entry *and* the consignment's own invoice numbers.
        # A shared Bill of Entry otherwise picks up the other importer's record.
        case.tradepay = tradepay.for_consignment(
            case.bill_of_entry,
            [l.get("invoiceNo") for l in consignment["invoiceLines"]])
        # Which TF3 collection this consignment is paid under. One reference
        # carries several Bills of Entry, so this is what the worklist groups
        # on; a consignment TradePay has no row for has no reference yet.
        case.tf3 = (case.tradepay or {}).get("tf3Reference") or None
        case.tii = (case.tradepay or {}).get("tiiReference") or None
        case.deal = _deal_for(case.importer, case.currency, case.tf3 or case.tii)
        # The portal shows the reference without its branch prefix and, on
        # Symrise's capture, does not show it at all. The settlement blotter
        # carries the full form, and for all six transactions where both are
        # present the blotter's reference is the portal's with three digits
        # in front, so it is the better of the two to show and to group on.
        case.tf3 = _full_tf3(case.tf3, case.importer)
        case.audit.append(AuditEntry(
            at=datetime.now(), actor="IDPMS", role="System", action="Transaction received",
            detail=f"Bill of Entry {case.bill_of_entry}, "
                   f"{_n(len(case.invoice_lines), 'invoice line')}"
                   + (f", {_n(case.duplicate_lines_removed, 'duplicate line')} removed"
                      if case.duplicate_lines_removed else "") + "."))
        cases.append(case)
    return cases


# ---------------------------------------------------------------------------

class CaseStore:
    UNDO_TTL = timedelta(seconds=90)

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._cases: dict[str, CollectionCase] = {c.case_id: c for c in build_cases()}
        self._query_seq = 1000
        self._undo: dict[str, tuple[str, CollectionCase, datetime]] = {}
        self._watched: set[str] = set()   # cases with a live runner thread
        self.session = Session()

    # --------------------------------------------------------------- reset
    def reset(self, *, run: bool = True, reload_data: bool = True) -> dict:
        """Put the demo back to a known state.

        Everything a person did — settled checks, typed port names, queries,
        validations, approvals and TF3 postings — is discarded and the cases are
        rebuilt from the source data. The pricing agent's readings are kept,
        because they depend on the instruction text rather than on anything a
        maker did, and re-reading them costs a model call apiece.

        ``run`` puts every case straight back through the pipeline, which is the
        state a demo usually wants to open on. Pass false to show the pipeline
        running live instead.
        """
        with self._lock:
            if reload_data:
                load_sources()           # pick up edits to app/data/*.json
            tf3.reset()                  # nothing has been posted
            graphmap.forget()            # the map's layouts describe the old book
            self._cases = {c.case_id: c for c in build_cases()}
            self._undo.clear()
            self._query_seq = 1000
            self.session.switch("Maker")
            ran = 0
            if run:
                for case in self._cases.values():
                    if case.status is CaseStatus.RECEIVED:
                        self.run_pipeline(case)
                        ran += 1
        return {"cases": len(self._cases), "ran": ran,
                "message": (f"{_n(len(self._cases), 'case')} rebuilt"
                            + (f" and put through the checks." if ran
                               else ", none run yet."))}

    # ------------------------------------------------------------ pipeline
    # ------------------------------------------------------------ running
    # One description of what running a case means, written as a sequence of
    # steps. run_pipeline() exhausts it at once; the case page walks it with a
    # pause between steps so a maker can watch the work land.

    def _steps(self, case: CollectionCase) -> Iterator[RunStep]:
        """Do the work, yielding each step as it is settled.

        A step yielded as ``running`` has been announced but not finished. Only
        the agent's reading of the charge instruction is slow enough to need
        that, and it is genuinely in flight while it shows.
        """
        consignment = next((c for c in idpms.consignments()
                            if c["billOfEntryNumber"] == case.bill_of_entry
                            and c["importer"] == case.importer), None)
        if consignment is None:
            return

        # A single fact often settles several steps: one missing remittance
        # blocks the drawer, the country, the currency and the invoice match
        # with the same sentence. Say it once and point back to it, or the
        # panel buries the reason in four copies of itself.
        said: dict[str, str] = {}

        def done(step_id: str, label: str, detail: str, tone: str = "ok",
                 result: str = "") -> RunStep:
            first = said.get(detail)
            if first:
                detail = f"Same reason as \u201c{first}\u201d above."
            elif detail:
                said[detail] = label
            return RunStep(id=step_id, label=label, status="done", detail=detail,
                           tone=tone, result=result, at=datetime.now())

        # --- the source record --------------------------------------------
        lines = len(consignment["invoiceLines"])
        yield done("idpms", "Consignment read from IDPMS",
                   f"Bill of Entry {case.bill_of_entry}, "
                   f"{_n(lines, 'invoice line')}, {case.amount_display}"
                   + (f", {_n(case.duplicate_lines_removed, 'duplicate')} removed"
                      if case.duplicate_lines_removed else "") + ".", "info")

        # --- the remittance the checks compare against --------------------
        if case.tradepay:
            ref = case.tradepay.get("invoiceNo") or "NO REFERENCE"
            amt = case.tradepay.get("invoiceAmount")
            # Several invoices can sit behind one remittance, so lead with the
            # figure: a run of invoice numbers followed by an amount reads as
            # if the amount were one more reference.
            yield done("tradepay", "TradePay remittance matched",
                       (f"{amt:,.2f} paid against invoice {ref}"
                        if isinstance(amt, (int, float)) else f"Invoice {ref}")
                       + ". This is the record every comparison is made against.",
                       "info")
        else:
            yield done("tradepay", "No TradePay remittance",
                       tradepay.why_no_match(
                           case.bill_of_entry,
                           [l.invoice_no for l in case.invoice_lines],
                           case.bill_of_entry_date)
                       or "Nothing in TradePay matches this consignment, so the "
                          "comparisons cannot be made.", "warn")

        # --- the port directory -------------------------------------------
        for fresh, existing in zip(_port_refs(consignment), case.ports):
            if not existing.entered_by_maker:
                existing.name = fresh.name
                existing.status = fresh.status
                existing.message = fresh.message
                existing.searched_as = fresh.searched_as
                existing.prefix_applied = fresh.prefix_applied
                existing.country = fresh.country
            searched = (f" Searched as {existing.searched_as}."
                        if existing.prefix_applied else "")
            if existing.resolved:
                yield done(f"port-{existing.role}",
                           f"Port of {existing.role} named",
                           f"{existing.code or 'The code'} is {existing.name}."
                           + (" Entered by the maker." if existing.entered_by_maker
                              else searched))
            else:
                yield done(f"port-{existing.role}",
                           f"Port of {existing.role} not named",
                           (existing.message
                            or f"{existing.code or 'The code'} is not in the "
                               "directory.") + searched, "warn")

        # --- the consistency checks, one comparison at a time -------------
        tones = {"pass": "ok", "fail": "bad", "warn": "warn", "blocked": "warn"}
        case.checks = []
        for r in check_rules.run_iter(consignment, case.tradepay):
            case.checks.append(Check(
                id=r["id"], label=r["label"], status=r["status"], detail=r["detail"],
                source=r.get("source", ""),
                compared=[ComparedField(**c) for c in r.get("compared", [])],
            ))
            if r["id"].startswith("PORT_"):
                continue                 # reported above, as its own step
            yield done(f"chk-{r['id']}", r["label"], r["detail"],
                       tones.get(r["status"], ""), r["status"])

        # --- the agent reads the charge instruction -----------------------
        # The one genuinely slow step, so it is announced before the call
        # rather than after: what the panel shows as running really is.
        yield RunStep(id="agent", label="Reading the charge instruction",
                      status="running",
                      detail="The agent is working through the client's "
                             "free-format pricing text.", tone="info")
        case.charges = _price(case)
        tr = case.charges.agent_trace or {}
        if case.charges.priced:
            how = ("the reading already made for this client"
                   if tr.get("reusedReading")
                   else (tr.get("model") or "the model")
                        + (f" via {tr['provider']}" if tr.get("provider") else ""))
            yield done("agent", "Charge instruction read",
                       f"{_n(len(tr.get('steps') or []), 'reasoning step')} "
                       f"from {how}. " + (tr.get("summary") or "").strip())
        else:
            yield done("agent", "Charge instruction not settled",
                       case.charges.message
                       or "The instruction could not be read into charges.",
                       "warn")

        # --- the money ----------------------------------------------------
        if case.charges.priced:
            yield done("tariff", "Tariff and forex clause applied",
                       f"{_n(len(case.charges.lines), 'charge')} on "
                       f"INR {case.charges.gross_inr:,.2f} exchanged, "
                       f"INR {case.charges.total:,.2f} in all.")
        else:
            yield done("tariff", "Charges not priced",
                       "Nothing is billed until the instruction is settled.", "warn")

        # --- and every figure in it, worked out again ----------------------
        # The agent decides what to charge; it is not trusted to multiply. This
        # step is the second route through the same numbers, and a maker should
        # be able to watch it happen rather than take it on faith.
        summary = tr.get("checkSummary") or {}
        if summary.get("total"):
            failed = summary.get("failed") or []
            if failed:
                yield done("recheck", "Figures re-checked, and one does not agree"
                           if len(failed) == 1 else
                           f"Figures re-checked, {_n(len(failed), 'disagreement')}",
                           f"{summary['passed']} of "
                           f"{_n(summary['total'], 'recomputation')} agree. "
                           + failed[0]["detail"], "bad",
                           result=f"{summary['passed']}/{summary['total']}")
            else:
                yield done("recheck", "Every figure re-checked",
                           f"{_n(summary['total'], 'recomputation')} — the "
                           "rupee value exchanged, each charge from its rate and "
                           "count, the forex fee band by band, GST on a base "
                           "that excludes it, and the total against its parts "
                           "— all agree.",
                           result=f"{summary['total']}/{summary['total']}")

        # --- what it leaves for a person ----------------------------------
        case.status = (CaseStatus.NEEDS_ATTENTION if case.blockers
                       else CaseStatus.READY_FOR_REVIEW)
        case.processing_started = None
        case.audit.append(AuditEntry(
            at=datetime.now(), actor="Pipeline", role="Pipeline", action="Checks run",
            detail=f"{case.checks_passed} of {case.checks_total} checks passed; "
                   + (f"charges INR {case.charges.total:,.2f}." if case.charges.priced
                      else (case.charges.message or "charges not settled."))))
        n = len(case.blockers)
        yield done("verdict", "Needs a maker" if n else "Nothing outstanding",
                   (f"{_n(n, 'thing')} the checks could not settle." if n else
                    "Every check passed and the charges are priced. Ready for "
                    "review."), "warn" if n else "ok")

    def _walk(self, case: CollectionCase, *, beat: float) -> None:
        """Record each step as the pipeline produces it.

        The lock is held only long enough to write a step, never across the
        agent's model call or the pause, so the page can read the case while
        the run is still going.
        """
        for step in self._steps(case):
            with self._lock:
                for i, existing in enumerate(case.run_steps):
                    if existing.id == step.id:
                        case.run_steps[i] = step
                        break
                else:
                    case.run_steps.append(step)
            if beat and step.status == "done":
                time.sleep(beat)

    def run_pipeline(self, case: CollectionCase) -> None:
        """Run the checks and price the charges, all at once.

        Ports are resolved when the case is built; re-resolving here picks up a
        port directory that was dropped in since.
        """
        case.run_steps = []
        self._walk(case, beat=0)

    def _tick(self) -> None:
        """Finish any case left mid-run with no runner behind it.

        A case released by start_processing has its own thread; this only
        catches one whose thread is gone, so nothing can sit in the queue
        showing as running for ever.
        """
        now = datetime.now()
        for case in self._cases.values():
            if (case.status is CaseStatus.AI_PROCESSING and case.processing_started
                    and case.case_id not in self._watched
                    and (now - case.processing_started).total_seconds()
                        >= case.processing_seconds):
                self.run_pipeline(case)

    # A full run is about this many steps: the source record, the remittance,
    # two ports, four checks, the agent, the money, the verdict. Only used to
    # draw the queue gauge, which is why an approximation is enough.
    STEPS_EXPECTED = 12

    def progress(self, case: CollectionCase) -> int:
        """How far through a run a case is, from the steps actually recorded."""
        if case.status is not CaseStatus.AI_PROCESSING or not case.processing_started:
            return 0 if case.status is CaseStatus.RECEIVED else 100
        done = sum(1 for s in case.run_steps if s.status == "done")
        return max(5, min(97, int(done / self.STEPS_EXPECTED * 100)))

    def start_processing(self, case: CollectionCase) -> None:
        """Release one case and let the page watch it run.

        The work goes on its own thread so each step appears as it happens,
        rather than all at once when one long request finally returns.
        """
        case.status = CaseStatus.AI_PROCESSING
        case.processing_started = datetime.now()
        case.run_steps = []
        case.audit.append(AuditEntry(
            at=datetime.now(), actor=self.session.name, role="Maker",
            action="Sent for checking",
            detail="Released to the pipeline for port lookup, consistency checks and charges."))

        case_id = case.case_id
        self._watched.add(case_id)

        def work() -> None:
            try:
                self._walk(case, beat=RUN_BEAT_S)
            except Exception as exc:                  # never leave a case hung
                with self._lock:
                    case.run_steps.append(RunStep(
                        id="error", label="The run stopped", status="done",
                        detail=f"{type(exc).__name__}: {exc}", tone="bad",
                        at=datetime.now()))
                    case.status = CaseStatus.NEEDS_ATTENTION
                    case.processing_started = None
            finally:
                self._watched.discard(case_id)

        threading.Thread(target=work, name=f"run-{case_id}", daemon=True).start()

    def run_all(self) -> int:
        """Run every case that has not been through the pipeline."""
        n = 0
        with self._lock:
            for case in self._cases.values():
                if case.status is CaseStatus.RECEIVED:
                    self.run_pipeline(case)
                    n += 1
        return n

    # ---------------------------------------------------------------- read
    def all_cases(self) -> list[CollectionCase]:
        with self._lock:
            self._tick()
            return list(self._cases.values())

    def get(self, case_id: str) -> CollectionCase | None:
        with self._lock:
            self._tick()
            return self._cases.get(case_id)

    def list_cases(self, *, view: str = "all", search: str | None = None,
                   importer: str | None = None, currency: str | None = None,
                   status: str | None = None, sort: str | None = None,
                   direction: str = "asc") -> list[CollectionCase]:
        rows = self.all_cases()
        spec = VIEWS.get(view, VIEWS["all"])
        if spec.get("statuses"):
            rows = [c for c in rows if c.status in spec["statuses"]]
        elif view == "all":
            rows = [c for c in rows if c.status in OPEN_STATUSES]

        if importer and importer != "all":
            rows = [c for c in rows if c.importer == importer]
        if currency and currency != "all":
            rows = [c for c in rows if c.currency == currency]
        if status and status != "all":
            rows = [c for c in rows if c.status.value == status]
        if search:
            # The drawer is searched as well as the supplier, because the two
            # systems name the same party differently and a maker searching
            # one expects to find the other's transactions too. Sigma Aldrich
            # ships from LEAP CHEM CO LTD on one transaction and LEAP LABCHEM
            # CO.,LTD. on the next, and TradePay pays both as Leap Chem Co
            # Ltd; searching that name used to find one of the two.
            n = search.strip().lower()
            rows = [c for c in rows if n in c.case_id.lower()
                    or n in c.importer.lower() or n in c.bill_of_entry.lower()
                    or n in c.supplier.lower()
                    or n in str((c.tradepay or {}).get("drawerName") or "").lower()
                    or any(n in (l.invoice_no or "").lower()
                           for l in c.invoice_lines)]

        key = SORTABLE.get(sort or "", SORTABLE["boe_date"])
        rows.sort(key=key, reverse=(direction == "desc"))
        return rows

    def counts(self) -> dict[str, int]:
        rows = self.all_cases()
        return {
            "all": sum(1 for c in rows if c.status in OPEN_STATUSES),
            # What a maker can actually act on — not every case whose status
            # happens to be NEEDS_ATTENTION. A case held for a source nobody
            # supplied is counted separately, because there is nothing to do.
            "attention": sum(1 for c in rows if c.needs_maker),
            "held": sum(1 for c in rows if c.waiting_on_source),
            "ready": sum(1 for c in rows if c.status is CaseStatus.READY_FOR_REVIEW
                         and not c.needs_maker),
            "processing": sum(1 for c in rows if c.status in
                              (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING)),
            "checker": sum(1 for c in rows if c.status is CaseStatus.IN_CHECKER_QUEUE),
            "completed": sum(1 for c in rows if c.status is CaseStatus.COMPLETED),
            "queries": sum(len(c.open_queries) for c in rows),
        }

    def importers(self) -> list[str]:
        return sorted({c.importer for c in self.all_cases()})

    def currencies(self) -> list[str]:
        return sorted({c.currency for c in self.all_cases() if c.currency})

    # ------------------------------------------------------------ mutations
    def _log(self, case, action, detail, role=None):
        case.audit.append(AuditEntry(at=datetime.now(), actor=self.session.name,
                                     role=role or self.session.role,
                                     action=action, detail=detail))

    def set_port(self, case: CollectionCase, role: str, name: str,
                 note: str | None = None) -> PortRef | None:
        port = case.port(role)
        if port is None:
            return None
        port.name = name
        port.status = "resolved"
        port.entered_by_maker = True
        port.message = note
        self._log(case, "Port named",
                  f"Port of {role} ({port.code}) set to {name}."
                  + (f" {note}" if note else ""))
        self._revalidate(case)
        return port

    def resolve_check(self, case: CollectionCase, check_id: str,
                      resolution: str) -> Check | None:
        """Settle one check, or the several that share a cause.

        Where checks were grouped into a single thing for the maker to deal
        with, ``check_id`` arrives as their ids joined by commas, and one
        reason settles all of them.
        """
        wanted = [c.strip() for c in str(check_id).split(",") if c.strip()]
        settled = [c for c in case.checks if c.id in wanted and c.blocking]
        if not settled:
            return None
        for check in settled:
            check.status = "resolved"
            check.resolution = resolution
            check.resolved_by = self.session.name
            check.resolved_at = datetime.now()
        labels = ", ".join(c.label for c in settled)
        self._log(case, "Check settled" if len(settled) == 1 else "Checks settled",
                  f"{labels}: {resolution}")
        self._revalidate(case)
        return settled[0]

    def _revalidate(self, case: CollectionCase) -> None:
        if case.status in (CaseStatus.IN_CHECKER_QUEUE, CaseStatus.COMPLETED):
            return
        # a port named by the maker clears the port check it was blocking
        for check in case.checks:
            if check.id.startswith("PORT_") and check.blocking:
                role = "loading" if check.id.endswith("LOADING") else "discharge"
                port = case.port(role)
                if port and port.resolved:
                    check.status = "resolved"
                    check.resolution = f"Named by the maker as {port.name}."
                    check.resolved_by = self.session.name
                    check.resolved_at = datetime.now()
        case.status = (CaseStatus.NEEDS_ATTENTION if case.blockers
                       else CaseStatus.READY_FOR_REVIEW)

    def reprice(self, case: CollectionCase, *, fresh: bool = True) -> Charges:
        """Ask the agent again. ``fresh`` makes it re-read rather than reuse."""
        case.charges = _price(case, fresh=fresh)
        trace = case.charges.agent_trace
        by = (f"{trace.get('provider')} / {trace.get('model')}"
              if trace.get("provider") else "the charge rules")
        self._log(case, "Charges recalculated",
                  (f"INR {case.charges.total:,.2f}, read by {by}."
                   if case.charges.priced
                   else (case.charges.message or "Still not settled.")))
        return case.charges

    def raise_query(self, case, reason, recipient, check_id) -> Query:
        self._query_seq += 1
        q = Query(query_id=f"QRY-{self._query_seq}", check_id=check_id, recipient=recipient,
                  reason=reason, raised_by=self.session.name, raised_at=datetime.now())
        case.queries.append(q)
        case.status = CaseStatus.NEEDS_ATTENTION
        self._log(case, "Query raised", f"{q.query_id} to {recipient}: {reason}")
        return q

    def close_query(self, case, query_id, response) -> Query | None:
        q = next((x for x in case.queries if x.query_id == query_id), None)
        if q is None:
            return None
        q.status = "answered"
        q.response = response
        self._log(case, "Query answered", f"{q.query_id}: {response}")
        self._revalidate(case)
        return q

    # ----------------------------------------------------------- transitions
    def _snapshot(self, case) -> str:
        now = datetime.now()
        for stale in [t for t, (_, _, at) in self._undo.items()
                      if now - at > self.UNDO_TTL]:
            self._undo.pop(stale, None)
        token = secrets.token_urlsafe(9)
        self._undo[token] = (case.case_id, case.model_copy(deep=True), now)
        return token

    def undo(self, token: str) -> CollectionCase | None:
        entry = self._undo.pop(token, None)
        if entry is None:
            return None
        case_id, snapshot, at = entry
        if datetime.now() - at > self.UNDO_TTL:
            return None
        self._cases[case_id] = snapshot
        return snapshot

    def validate(self, case, note) -> tuple[bool, str, str | None]:
        if case.blockers:
            return False, "Settle these first: " + "; ".join(case.blockers) + ".", None
        token = self._snapshot(case)
        case.status = CaseStatus.IN_CHECKER_QUEUE
        self._log(case, "Validated",
                  note or "Checked against IDPMS and TradePay; sent for checker control.")
        return True, f"{case.case_id} is with the checker.", token

    def approve(self, case, note) -> tuple[bool, str, str | None]:
        """Checker approval posts the record to TF3."""
        if case.status is not CaseStatus.IN_CHECKER_QUEUE:
            return False, f"{case.case_id} is not with the checker.", None
        token = self._snapshot(case)
        loading, discharge = case.port("loading"), case.port("discharge")
        result = tf3.post({
            "billOfEntryNumber": case.bill_of_entry,
            "billOfEntryDate": case.bill_of_entry_date,
            "importer": case.importer,
            "importerCode": case.importer_code,
            "adCode": case.ad_code,
            "portOfLoading": loading.name if loading else None,
            "portOfLoadingCode": loading.code if loading else None,
            "portOfDischarge": discharge.name if discharge else None,
            "portOfDischargeCode": discharge.code if discharge else None,
            "thirdParties": [t.model_dump() for t in case.third_parties],
            "invoices": [{"invoiceNo": l.invoice_no, "date": l.invoice_date,
                          "amount": l.amount, "currency": l.currency}
                         for l in case.invoice_lines],
            "charges": {"totalInr": case.charges.total,
                        "lines": [l.model_dump() for l in case.charges.lines]},
            "approvedBy": self.session.name,
        })
        if not result["accepted"]:
            self._undo.pop(token, None)
            return False, result["message"], None

        case.status = CaseStatus.COMPLETED
        case.tf3_reference = result["tf3Reference"]
        self._log(case, "Approved", note or "Checker control complete.", role="Checker")
        case.audit.append(AuditEntry(
            at=datetime.now(), actor="TF3", role="System", action="Posted to TF3",
            detail=result["message"]))
        return True, result["message"], token

    def return_to_maker(self, case, reason) -> tuple[bool, str, str | None]:
        if case.status is not CaseStatus.IN_CHECKER_QUEUE:
            return False, f"{case.case_id} is not with the checker.", None
        token = self._snapshot(case)
        case.status = CaseStatus.RETURNED
        case.returned_reason = reason
        self._log(case, "Returned to maker", reason, role="Checker")
        return True, f"{case.case_id} went back to the maker.", token



store = CaseStore()


def get_store() -> CaseStore:
    return store


# ---------------------------------------------------------------------------
# collections: the TF3 reference, and everything paid under it
# ---------------------------------------------------------------------------
# Payment is processed against a TF3 reference, so that is what the worklist
# is indexed on. The hierarchy underneath it is real in the data and is three
# deep: ICS2615416 carries two Bills of Entry, and those carry nine invoices
# between them. A list of Bills of Entry could show neither the thing that
# gets paid nor the thing that gets checked.
#
# A consignment TradePay holds no row for has no reference yet. Those are not
# hidden and not lumped together: each stands on its own, labelled as waiting
# for one, because "no TF3 reference" is a fact about that consignment rather
# than a collection it shares with any other.

def _anchor(boe: str, invoice_no: str | None) -> str:
    """A stable id for one invoice row.

    Keyed on the bill of entry as well as the number, because that pair is
    the transaction key: an invoice number is not unique on its own, and
    nothing should start assuming it is.
    """
    raw = f"inv-{boe}-{invoice_no or 'none'}"
    return re.sub(r"[^A-Za-z0-9]+", "-", raw).strip("-").lower()


def _bill(case: CollectionCase) -> dict:
    """One Bill of Entry and the invoices under it.

    The middle rung of the hierarchy. Flattening straight from the TF3 to its
    invoices loses it, and the supplier and the Bill of Entry then repeat down
    every row of a table that has no way to say they are the same.
    """
    per_invoice = sum(l.amount_inr for l in case.charges.lines
                      if l.level == "invoice")
    per_bill = sum(l.amount_inr for l in case.charges.lines
                   if l.level == "transaction")
    # Which of these invoices the remittance actually covers. Rothe Erde's
    # two bills carry eleven invoices between them and the payment covers
    # nine; the other two are under the same bills but were not paid in this
    # batch. That is the reason they have no date — the portal is where the
    # date would come from and the portal has no row for them — so the two
    # facts are shown as one rather than as an unexplained gap.
    covered = tradepay.coverage(
        case.bill_of_entry, [l.invoice_no for l in case.invoice_lines])
    remitted = {str(n) for n in covered["matched"]}
    return {
        "case": case,
        "caseId": case.case_id,
        "boe": case.bill_of_entry,
        "boeDate": case.bill_of_entry_date,
        "supplier": case.supplier,
        "supplierCountry": case.supplier_country,
        "currency": case.currency,
        "total": case.total_amount,
        "charge": round(per_bill + per_invoice * len(case.invoice_lines), 2),
        "chargePerInvoice": per_invoice,
        "chargePerBill": per_bill,
        "state": ("broken" if case.needs_maker else
                  "waiting" if case.waiting_on_source else "clear"),
        "headline": case.headline,
        "open": len(case.action_items or []),
        "invoices": [{
            "invoiceNo": line.invoice_no or "—",
            "invoiceDate": line.invoice_date,
            "invoiceDateFrom": line.invoice_date_source,
            "remitted": str(line.invoice_no) in remitted,
            "currency": line.currency or case.currency,
            "amount": line.amount,
            "charge": per_invoice,
            # An invoice is a line of its bill rather than a thing with a
            # page: no check resolves to one, two of the seven are set
            # operations over the whole list, and under a given bill the
            # lines here differ in nothing but number and amount. So it gets
            # an address instead — enough to link to and to land on from a
            # search, not enough to navigate away to.
            "anchor": _anchor(case.bill_of_entry, line.invoice_no),
            "hit": False,
        } for line in case.invoice_lines],
    }


def _tf3_charge(cases: list[CollectionCase]) -> dict:
    """What the bank bills against one TF3 reference.

    The commission is levied per invoice or per bill of entry, so it adds up
    across the collection. The service tax is not: the clause runs
    on the sum exchanged and is capped, so charging it per bill of entry and
    adding the results bills the lower bands twice and sails past the cap.
    Rothe Erde's two bills come to INR 67,158.10 that way against INR
    60,000.00 charged once on the remittance — INR 7,158.10 of overcharge
    that only appears when a TF3 carries more than one bill.

    Payment is processed against the TF3, so the remittance-level charges are
    worked out once, here, on what the TF3 exchanged.
    """
    own = [l for c in cases for l in c.charges.lines if l.level != "tf3"]
    commission = round(sum(l.amount_inr for l in own), 2)
    gross = round(sum(c.charges.gross_inr for c in cases), 2)
    priced = any(c.charges.priced for c in cases)

    clause = load("fx")["forexConversionClause"]
    fx = autobahn.forex_conversion_fee(gross) if priced else {"amountInr": 0.0,
                                                              "basis": ""}
    gst = round(commission * clause["gstPercent"] / 100.0, 2)
    remittance = [
        ChargeLine(code="FXCONV", label="Service tax", basis=fx["basis"],
                   amount_inr=fx["amountInr"], level="tf3",
                   level_basis="on everything this TF3 exchanged"),
        ChargeLine(code="GST", label="GST on commission",
                   basis=f"{clause['gstPercent']:.0f}% on commission only",
                   amount_inr=gst, level="tf3",
                   level_basis="on commission only"),
    ] if priced else []

    lines = own + remittance
    # Why the per-invoice column is empty, in the words the case already
    # uses. A blank cell in a column of money should say whether nothing is
    # owed or nothing is known yet; those are not the same answer.
    if not priced:
        why = next((c.charges.message for c in cases if c.charges.message),
                   "The charge has not been worked out yet.")
    elif not any(l.level == "invoice" for l in lines):
        # Read out as a sentence rather than as the level codes: "levied TF3"
        # is the dictionary key talking, not the bank.
        said = {"invoice": "per invoice", "transaction": "per transaction",
                "tf3": "on the remittance"}
        where = sorted({said.get(l.level, l.level) for l in lines})
        why = ("Nothing is charged per invoice for this client. The charge is "
               "levied " + (listed(where) if where else "elsewhere") + ".")
    else:
        why = "No charge falls on this invoice."

    return {
        "why": why,
        "total": round(sum(l.amount_inr for l in lines), 2),
        "priced": all(c.charges.priced for c in cases),
        "anyPriced": priced,
        # Kept apart by level so the table can show each where it is levied
        # rather than adding three different things into one figure.
        "byLevel": {
            level: round(sum(l.amount_inr for l in lines if l.level == level), 2)
            for level in ("invoice", "transaction", "tf3")
        },
        "lines": lines,
        "grossInr": gross,
        "perBillWouldBe": round(
            sum(l.amount_inr for c in cases for l in c.charges.lines), 2),
    }


def collections(cases: list[CollectionCase],
                search: str | None = None) -> list[dict]:
    """The worklist, grouped on the TF3 reference payment runs against.

    A search term is carried down to the invoice rows it matches, so the
    collection holding one opens on arrival with the row marked. Searching
    an invoice number otherwise filters to a collapsed collection and leaves
    the reader to expand it and scan eleven numbers for the one they typed.
    """
    groups: dict[str, dict] = {}
    for case in cases:
        key = case.tf3 or f"~{case.case_id}"      # no reference: stands alone
        g = groups.get(key)
        if g is None:
            g = groups[key] = {
                "key": key, "tf3": case.tf3, "tii": case.tii,
                "cases": [], "importers": [], "suppliers": [],
                "billNumbers": [], "bills": [], "currencies": [],
            }
        g["cases"].append(case)
        for field, value in (("importers", case.importer),
                             ("suppliers", case.supplier),
                             ("currencies", case.currency)):
            if value and value not in g[field]:
                g[field].append(value)
        if case.bill_of_entry not in g["billNumbers"]:
            g["billNumbers"].append(case.bill_of_entry)
        g["bills"].append(_bill(case))

    out = []
    for g in groups.values():
        cs = g["cases"]
        g["charge"] = _tf3_charge(cs)
        g["open"] = sum(len(c.action_items or []) for c in cs)
        g["state"] = ("broken" if any(c.needs_maker for c in cs) else
                      "waiting" if any(c.waiting_on_source for c in cs) else
                      "clear")
        g["valueInr"] = round(sum(c.charges.gross_inr for c in cs), 2)
        g["checksPassed"] = sum(c.checks_passed for c in cs)
        g["checksTotal"] = sum(c.checks_total for c in cs)
        g["invoiceCount"] = sum(len(b["invoices"]) for b in g["bills"])
        g["bills"].sort(key=lambda b: (b["boeDate"] or "", b["boe"]))
        g["single"] = len(cs) == 1 and g["invoiceCount"] == 1
        g["hit"] = _mark_hits(g, search)
        out.append(g)

    # Anything needing a decision first, then the biggest money. A search
    # that landed on an invoice overrides it: the row you asked for goes to
    # the top rather than wherever its collection would otherwise sort.
    order = {"broken": 0, "waiting": 1, "clear": 2}
    out.sort(key=lambda g: (not g["hit"], order.get(g["state"], 3),
                            -g["valueInr"]))
    return out


def _mark_hits(group: dict, search: str | None) -> bool:
    """Flag the invoice rows a search names. True if the group holds one."""
    term = (search or "").strip().lower()
    if not term:
        return False
    found = False
    for bill in group["bills"]:
        for invoice in bill["invoices"]:
            if term in (invoice["invoiceNo"] or "").lower():
                invoice["hit"] = found = True
    return found
