/* Selecting a collection without reloading the page.
 *
 * Every row is a real link to its own ?sel= page, which is what makes the
 * frozen build work and what lets a selection be sent to someone. Followed
 * as a link, though, it is a navigation: the browser lands at the top of a
 * new document and the list you were half way down jumps back to the
 * start. Every panel is already in the page, so the click can swap which
 * one is shown and write the same URL into the history instead.
 *
 * Without this script the links still navigate and the ?sel= pages still
 * stand, so nothing here is load-bearing.
 */
(function () {
  "use strict";

  var list = document.querySelector(".split__list");
  var panels = document.querySelectorAll(".detail[data-sel]");
  if (!list || panels.length < 2 || !window.history || !history.pushState) return;

  function show(ref) {
    var found = false;
    for (var i = 0; i < panels.length; i++) {
      var mine = panels[i].getAttribute("data-sel") === ref;
      panels[i].hidden = !mine;
      if (mine) found = true;
    }
    if (!found) return false;

    var rows = list.querySelectorAll("tr.pickrow");
    for (var j = 0; j < rows.length; j++) {
      var hit = rows[j].querySelector(".pickrow__hit");
      var on = !!hit && hit.getAttribute("data-ref") === ref;
      rows[j].classList.toggle("is-on", on);
      if (hit) {
        if (on) { hit.setAttribute("aria-current", "true"); }
        else { hit.removeAttribute("aria-current"); }
      }
    }
    return true;
  }

  list.addEventListener("click", function (e) {
    /* Let the browser have the ones a reader means for it: a new tab, a
       saved link, a download. */
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey ||
        e.shiftKey || e.altKey) return;
    var hit = e.target.closest ? e.target.closest(".pickrow__hit") : null;
    if (!hit) return;

    /* Read the reference off the link, not out of its href: freezing
       rewrites hrefs into flat filenames, so parsing ?sel= back out works
       on the server and fails in the built copy. */
    var href = hit.getAttribute("href") || "";
    var ref = hit.getAttribute("data-ref");
    if (!ref) return;
    if (!show(ref)) return;          /* no panel for it: let the link go */

    e.preventDefault();
    try { history.pushState({ sel: ref }, "", href); } catch (err) { /* file:// */ }
  });

  window.addEventListener("popstate", function (e) {
    var ref = e.state && e.state.sel;
    if (!ref) {
      /* Served, the reference is in the query; baked, it is in the file
         name the link was rewritten to. */
      var m = /[?&]sel=([^&]+)/.exec(location.search) ||
              /_?sel-([^_.]+)/.exec(location.pathname);
      ref = m && decodeURIComponent(m[1]);
    }
    if (ref) show(ref);
  });
}());
