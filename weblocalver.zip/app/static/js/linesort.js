/* Sorting the panel's invoice table by its headings.
 *
 * The table is small and already on the page, so the rows are reordered
 * in place: no request, no URL, and it works the same from a file as it
 * does from a server. A heading is a button; the one in charge carries
 * aria-sort, and clicking it again turns the order round.
 *
 * A figure that is not there - no charge on file - sorts as zero, the
 * same as the worklist treats a collection with no pricing.
 */
(function () {
  "use strict";

  function value(cell, kind) {
    if (!cell) return kind === "money" ? 0 : "";
    var text = (cell.textContent || "").replace(/\s+/g, " ").trim();
    if (kind === "money") {
      var m = /-?[\d,]+(?:\.\d+)?/.exec(text);
      return m ? parseFloat(m[0].replace(/,/g, "")) : 0;
    }
    if (kind === "date") {
      var d = /\d{4}-\d{2}-\d{2}/.exec(text);
      return d ? d[0] : "";
    }
    /* The reference is the first run of text; a note after it ("not in
       this remittance") is not part of the name. */
    var first = cell.firstChild;
    var own = first && first.nodeType === 3 ? first.textContent : text;
    return own.replace(/\s+/g, " ").trim().toLowerCase();
  }

  document.addEventListener("click", function (e) {
    var btn = e.target.closest ? e.target.closest("button.linesort") : null;
    if (!btn) return;
    var th = btn.closest("th");
    var table = btn.closest("table");
    var body = table && table.tBodies[0];
    if (!th || !body) return;

    var col = th.cellIndex;
    var kind = btn.getAttribute("data-kind") || "text";
    var dir = th.getAttribute("aria-sort") === "ascending" ? "descending" : "ascending";
    var heads = th.parentNode.children;
    for (var i = 0; i < heads.length; i++) heads[i].removeAttribute("aria-sort");
    th.setAttribute("aria-sort", dir);

    var rows = Array.prototype.slice.call(body.rows);
    var keyed = rows.map(function (row, index) {
      return { row: row, index: index, key: value(row.cells[col], kind) };
    });
    keyed.sort(function (a, b) {
      var c = a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
      if (dir === "descending") c = -c;
      return c || a.index - b.index;     /* a tie keeps the original order */
    });
    for (var j = 0; j < keyed.length; j++) body.appendChild(keyed[j].row);
  });
}());
