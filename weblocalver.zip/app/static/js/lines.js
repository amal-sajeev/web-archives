/* The panel's invoice table: sorting it, and opening a bill from it.
 *
 * The table has one body per bill of entry, and the bill's own cell spans
 * the invoices under it. Sorting keeps that shape: the invoices inside a
 * bill are put in order, then the bills are put in order by their first
 * row, so the merged cells stay merged. Sorting on the bill column orders
 * the bills and leaves their invoices alone.
 *
 * The rows are reordered in place: no request, no URL, and it works the
 * same from a file as it does from a server. A heading is a button; the
 * one in charge carries aria-sort, and clicking it again turns the order
 * round. A figure that is not there - no charge on file - sorts as zero,
 * the same as the worklist treats a collection with no pricing.
 *
 * A bill is the thing that opens. Its number is a real link, so the page
 * is reachable without any of this; with it, a click anywhere on the
 * bill's rows follows that link.
 */
(function () {
  "use strict";

  function value(cell, kind) {
    if (!cell) return kind === "money" ? 0 : "";
    var text = (cell.textContent || "").replace(/\s+/g, " ").trim();
    if (kind === "money") {
      var m = /-?[\d,]+(?:\.\d+)?/.exec(text);
      return m ? parseFloat(m[0].replace(/,/g, "")) : 0;
    }
    if (kind === "date") {
      var d = /\d{4}-\d{2}-\d{2}/.exec(text);
      return d ? d[0] : "";
    }
    /* The reference is the first run of text; a note after it ("not in
       this remittance") is not part of the name. */
    var first = cell.firstChild;
    var own = first && first.nodeType === 3 ? first.textContent : text;
    return own.replace(/\s+/g, " ").trim().toLowerCase();
  }

  function compare(dir) {
    return function (a, b) {
      var c = a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
      if (dir === "descending") c = -c;
      return c || a.index - b.index;     /* a tie keeps the order it had */
    };
  }

  function sort(table, th, dir) {
    var col = th.cellIndex;
    var kind = th.querySelector("button").getAttribute("data-kind") || "text";
    var bodies = Array.prototype.slice.call(table.tBodies);

    var groups = bodies.map(function (body, index) {
      var rows = Array.prototype.slice.call(body.rows);
      var first = rows[0] && rows[0].cells[0];
      var head = first && first.classList.contains("boe") ? first : null;
      if (head && col === 0) {
        /* The bill column: order the bills, keep their invoices as they are. */
        return { body: body, index: index, rows: rows, head: null, key: value(head, kind) };
      }
      if (head) head.parentNode.removeChild(head);   /* every row now has the same cells */
      var keyed = rows.map(function (row, i) {
        return { row: row, index: i, key: value(row.cells[col - (head ? 1 : 0)], kind) };
      });
      keyed.sort(compare(dir));
      return {
        body: body, index: index, head: head,
        rows: keyed.map(function (k) { return k.row; }),
        key: keyed.length ? keyed[0].key : (kind === "money" ? 0 : "")
      };
    });

    groups.sort(compare(dir));
    groups.forEach(function (g) {
      g.rows.forEach(function (row) { g.body.appendChild(row); });
      if (g.head && g.rows.length) g.rows[0].insertBefore(g.head, g.rows[0].firstChild);
      table.appendChild(g.body);
    });
  }

  document.addEventListener("click", function (e) {
    if (!e.target.closest) return;

    var btn = e.target.closest("button.linesort");
    if (btn) {
      var th = btn.closest("th");
      var table = btn.closest("table");
      if (!th || !table || !table.tBodies.length) return;
      var dir = th.getAttribute("aria-sort") === "ascending" ? "descending" : "ascending";
      var heads = th.parentNode.children;
      for (var i = 0; i < heads.length; i++) heads[i].removeAttribute("aria-sort");
      th.setAttribute("aria-sort", dir);
      sort(table, th, dir);
      return;
    }

    /* Let the browser have the ones a reader means for it: a new tab, a
       saved link. A click on the link itself, or on any other control,
       keeps its own meaning, and a click that ends a text selection is a
       selection, not a choice. */
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey ||
        e.shiftKey || e.altKey) return;
    var body = e.target.closest("tbody.boe");
    if (!body || e.target.closest("a, button, input, select, label")) return;
    var go = body.querySelector("a.boe__go");
    if (!go) return;
    var sel = window.getSelection ? window.getSelection() : null;
    if (sel && sel.type === "Range" && String(sel).length) return;
    e.preventDefault();
    location.href = go.href;
  });
}());
