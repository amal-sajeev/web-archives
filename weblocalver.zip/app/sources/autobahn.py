"""Autobahn / OEMS — the per-client pricing text.

Stands in for the Products tab of a client in Autobahn, where the approved
pricing lives in a free-format text box. It is prose written by relationship
managers over several years, so the job here is to read it, not to look it up:

    "INR 350 PER TRANSACTION, AGENCY COMMISSION..."
    "Import Payment: INR 450 per document"
    "Commission - INR 1000 per import doc and not at BOE level"
    "0.010% per bill (min INR 100 & max INR 4000)"

The parser reports what it found *and* how sure it is. Anything it cannot read
confidently is handed to the maker rather than guessed at, and a client with no
instruction on file stops the case — there is no approved price to charge.
"""

from __future__ import annotations

import re

from ._data import load, normalise_name
from ..text import n

# "INR 350 PER TRANSACTION", "INR 1000 per import doc", "INR 450 per document"
# "0.010% per bill (min INR 100 & max INR 4000)"
_AMOUNT = re.compile(
    r"(?:"
    r"(?:INR|RS\.?)\s*(?P<fixed>[\d,]+(?:\.\d+)?)\s*(?:/-)?\s*(?:PER|P\.?A\.?|EACH)\s+(?P<fixed_basis>[A-Z ]{3,30})"
    r"|"
    r"(?P<pct>[\d,]+(?:\.\d+)?)\s*%\s*(?:(?:PER|P\.?A\.?|EACH)\s+)?(?P<pct_basis>[A-Z ]{0,30})"
    r")",
    re.IGNORECASE)

_BASIS = [
    (r"\bIMPORT\s+DOC", "per_document", "per import document"),
    (r"\bDOCUMENT\b|\bDOC\b", "per_document", "per document"),
    (r"\bTRANSACTION\b|\bTXN\b", "per_transaction", "per transaction"),
    (r"\bBILL\b|\bBILL\s+OF\s+ENTRY\b|\bBOE\b", "per_boe", "per Bill of Entry"),
    (r"\bREMITTANCE\b", "per_remittance", "per remittance"),
]
_MINMAX = re.compile(
    r"(?:MIN(?:IMUM)?\s*(?:INR|RS\.?)\s*([\d,]+(?:\.\d+)?)|"
    r"MAX(?:IMUM)?\s*(?:INR|RS\.?)\s*([\d,]+(?:\.\d+)?))",
    re.IGNORECASE)


def is_sample() -> bool:
    """True when the file holds a sample of clients rather than the full book."""
    return bool(load("autobahn").get("isSample"))


def coverage(importers: list[str] | None = None) -> dict:
    """Which clients have pricing on file, and which were never supplied.

    The distinction matters. A client absent from a *sample* has simply not been
    given to us; concluding that it has no approved pricing would be inventing a
    fact about the customer.
    """
    entries = load("autobahn").get("clients", [])
    supplied = [e["client"] for e in entries]
    missing = [i for i in (importers or []) if instruction_for(i) is None]
    unused = [c for c in supplied
              if not any(instruction_for(i) and instruction_for(i)["client"] == c
                         for i in (importers or []))]
    return {
        "isSample": is_sample(),
        "suppliedFor": supplied,
        "notSuppliedFor": missing,
        "suppliedButUnused": unused,
        "note": ("The Autobahn pages supplied cover "
                 f"{n(len(supplied), 'client')}. Pricing for a client that is not "
                 "among them has not been supplied, which is not the same as "
                 "the client having none."),
    }


def instruction_for(client: str) -> dict | None:
    """The raw processing text held against a client, if there is one.

    Longest alias wins, and an alias that fits more than one client on file
    is no match at all. The group names here overlap: Bosch Limited, Bosch
    Rexroth and Bosch Automotive Electronics are three legal entities, two
    of them with their own tariff. Taking the first alias that fit priced
    all three off Bosch Limited's page - including Rexroth, whose own
    all-inclusive pricing sat unread two entries further down - and billed
    a client against a tariff that was never approved for it.
    """
    want = normalise_name(client)
    entries = load("autobahn").get("clients", [])

    for entry in entries:
        if normalise_name(entry["client"]) == want:
            return entry

    # An alias is an alternate spelling of the whole name, not a fragment of
    # it. Matching on containment made "BOSCH" fit Bosch Automotive
    # Electronics India, so a client with no page of its own was charged off
    # the page of a different company in the same group. Nothing is lost by
    # being strict: once the legal form is folded, every client on file
    # matches its own importer exactly, which is what the branch above does.
    hits = [e for e in entries
            for alias in e.get("matches", [])
            if normalise_name(alias) and normalise_name(alias) == want]
    if not hits:
        return None
    # Two different clients answering to one spelling is an ambiguity, not a
    # match. The consignment does not say which page applies.
    return hits[0] if len({e["client"] for e in hits}) == 1 else None


def _basis_from_text(text: str) -> tuple[str | None, str | None]:
    """Pick the charging basis from the matched amount's surrounding text."""
    for pattern, key, label in _BASIS:
        if re.search(pattern, text, re.IGNORECASE):
            return key, label
    return None, None


def _extract_amount_details(text: str):
    """Read an amount or percentage and the basis it is charged on."""
    match = _AMOUNT.search(text)
    if not match:
        return None

    if match.group("fixed"):
        amount = float(match.group("fixed").replace(",", ""))
        tail = (match.group("fixed_basis") or "").upper()
        return {"amount": amount, "tail": tail, "is_percent": False}

    amount = float(match.group("pct").replace(",", ""))
    tail = (match.group("pct_basis") or "").upper()
    return {"amount": amount, "tail": tail, "is_percent": True}


def parse(text: str) -> dict:
    """Pull an amount and a charging basis out of the processing text."""
    if not text or not text.strip():
        return {"found": False, "confidence": 0.0,
                "message": "The processing text is empty."}

    match = _AMOUNT.search(text)
    if not match:
        return {"found": False, "confidence": 0.0,
                "message": "No 'INR <amount> per <basis>' or '% per <basis>' phrasing could be found in the processing text. A maker needs to read it."}

    details = _extract_amount_details(text)
    amount = details["amount"]
    tail = details["tail"]
    basis, basis_label = _basis_from_text(tail)
    if basis is None:
        start = max(0, match.start() - 40)
        end = min(len(text), match.end() + 80)
        window = text[start:end].upper()
        basis, basis_label = _basis_from_text(window)

    min_amt = None
    max_amt = None
    for min_match in _MINMAX.finditer(text):
        if min_match.group(1):
            min_amt = float(min_match.group(1).replace(",", ""))
        elif min_match.group(2):
            max_amt = float(min_match.group(2).replace(",", ""))

    confidence = 0.95 if basis else 0.55
    notes = []
    if details["is_percent"]:
        notes.append("The quoted rate is a percentage of the gross, not a fixed INR amount.")
    if re.search(r"NOT\s+AT\s+BOE\s+LEVEL", text, re.IGNORECASE):
        notes.append("Charged per document, explicitly not at Bill of Entry level.")
    if re.search(r"REMITTANCE\s+LEVEL", text, re.IGNORECASE):
        notes.append("Pricing to be levied at remittance level.")
    if len(_AMOUNT.findall(text)) > 1:
        confidence = min(confidence, 0.5)
        notes.append("The text quotes more than one amount; a maker should confirm which one applies.")

    evidence = next((ln.strip() for ln in text.splitlines()
                     if match.group(0) in ln or str(amount) in ln or f"{amount:g}%" in ln),
                    match.group(0)).strip()

    result = {
        "found": True,
        "amountInr": amount,
        "basis": basis or "unknown",
        "basisLabel": basis_label or "basis not stated",
        "confidence": round(confidence, 2),
        "evidence": evidence,
        "notes": notes,
        "message": None if basis else "An amount was found but the charging basis is not stated plainly.",
        "isPercent": details["is_percent"],
        "minInr": min_amt,
        "maxInr": max_amt,
    }
    return result


def quote(client: str, *, documents: int = 1, gross_inr: float = 0.0) -> dict:
    """What to charge: commission, the service tax, and GST on the commission.

    The covering email: "Service tax need to be collected basis the forex
    conversion clause and 18% of Commission as GST." Two things are
    collected. The commission comes from the client's OEMS text; the service
    tax is 18% of the value the bracketed clause arrives at on the gross
    exchanged; the GST is 18% of the commission and of nothing else. The
    clause's own value is the basis of the tax, not a charge in itself.
    """
    entry = instruction_for(client)
    if entry is None:
        return {
            "status": "awaiting_pricing" if is_sample() else "no_instruction",
            "client": client,
            "message": (f"Autobahn pricing for {client} has not been supplied. The "
                        "sample covers other clients, so there is nothing here to "
                        "read — this does not mean the client is unpriced."
                        if is_sample() else
                        f"No approved pricing is held in Autobahn for {client}. "
                        "Nothing can be charged until one is recorded."),
            "lines": [], "totalInr": 0.0,
        }

    reading = parse(entry["processingText"])
    if not reading["found"]:
        return {
            "status": "unreadable",
            "client": entry["client"],
            "processingText": entry["processingText"],
            "reading": reading,
            "message": reading["message"],
            "lines": [], "totalInr": 0.0,
        }

    if reading.get("isPercent"):
        commission = float(gross_inr or 0.0) * (reading["amountInr"] / 100.0)
        if reading.get("minInr") is not None:
            commission = max(commission, float(reading["minInr"]))
        if reading.get("maxInr") is not None:
            commission = min(commission, float(reading["maxInr"]))
    else:
        units = documents if reading["basis"] in ("per_document", "per_remittance") else 1
        commission = reading["amountInr"] * units

    fx_fee = forex_conversion_fee(gross_inr)
    gst_rate = load("fx")["forexConversionClause"]["gstPercent"] / 100.0
    gst = round(commission * gst_rate, 2)

    from ..models import CHARGE_LABELS, CHARGE_LEVELS, GST_BASIS
    level, level_basis = CHARGE_LEVELS.get(reading["basis"],
                                           ("transaction", "per transaction"))

    if reading.get("isPercent"):
        basis_text = f"{reading['amountInr']:.3f}% of the gross exchanged"
    else:
        basis_text = f"INR {reading['amountInr']:,.0f} {reading['basisLabel']}"
        if reading["basis"] in ("per_document", "per_remittance") and documents > 1:
            basis_text += f" x {documents} documents"
    if reading.get("minInr") is not None:
        basis_text += f" (minimum INR {reading['minInr']:,.0f})"
    if reading.get("maxInr") is not None:
        basis_text += f" (maximum INR {reading['maxInr']:,.0f})"

    lines = [
        {"code": "COMM", "label": CHARGE_LABELS["COMM"],
         "basis": basis_text,
         "amountInr": round(commission, 2),
         "level": level, "levelBasis": level_basis},
        {"code": "FXCONV", "label": CHARGE_LABELS["FXCONV"],
         "basis": fx_fee["basis"], "amountInr": fx_fee["amountInr"],
         "level": "tf3", "levelBasis": "on the sum exchanged"},
        {"code": "GST", "label": CHARGE_LABELS["GST"],
         "basis": GST_BASIS,
         "amountInr": gst,
         "level": "tf3", "levelBasis": "on commission only"},
    ]
    return {
        "status": "quoted" if reading["confidence"] >= 0.9 else "needs_confirmation",
        "client": entry["client"],
        "processingText": entry["processingText"],
        "reading": reading,
        "documents": documents,
        "grossInr": round(gross_inr, 2),
        "lines": lines,
        "totalInr": round(sum(l["amountInr"] for l in lines), 2),
        "message": None if reading["confidence"] >= 0.9 else reading["message"],
    }


def _scope_sentence(clause: dict) -> str | None:
    """"Import Bill Collection, at full settlement", or nothing."""
    scope = clause.get("scope") or {}
    product, cycle = scope.get("product"), scope.get("cycle")
    if not product:
        return None
    return f"{product}, at {cycle.lower()}" if cycle else product


def forex_conversion_fee(gross_inr: float) -> dict:
    """The forex conversion clause, charged marginally.

    "0.18% up to INR 1 lakh, minimum INR 45; INR 180 + 0.09% above INR 1 lakh
    and up to INR 10 lakh; INR 990 + 0.018% above INR 10 lakh, capped at INR
    10,800, as specified in Forex Conversion.xlsx."

    The percentage applies to the amount *above* the tier's lower bound. The
    fixed figures are what make that unambiguous: 1% of one lakh is exactly
    1,000, and 1,000 + 0.5% of nine lakh is exactly 5,500, so each tier's fixed
    part is the cumulative charge at the bound below it. Charging the
    percentage on the whole gross would bill the lower band twice.
    """
    clause = load("fx")["forexConversionClause"]
    gross = max(float(gross_inr or 0.0), 0.0)
    if gross <= 0:
        return {"amountInr": 0.0, "basis": "no amount exchanged"}

    for tier in clause["tiers"]:
        cap = tier.get("upToInr")
        if cap is None or gross <= cap:
            floor = float(tier.get("fromInr", 0) or 0)
            excess = max(gross - floor, 0.0)
            fee = tier["fixedInr"] + excess * tier["percent"] / 100.0
            if tier.get("minimumInr"):
                fee = max(fee, tier["minimumInr"])
            if tier.get("maximumInr"):
                fee = min(fee, tier["maximumInr"])

            def working(band: dict) -> str:
                """How one band's figure is arrived at, in its own numbers."""
                pct, fixed = band["percent"], band["fixedInr"]
                if not fixed:
                    out = f"{pct}% of INR {gross:,.2f}"
                else:
                    out = (f"INR {fixed:,.0f} + {pct}% of INR {excess:,.2f}, "
                           f"the amount above INR {floor:,.0f}")
                got = fixed + excess * pct / 100.0
                if band.get("minimumInr") and got <= band["minimumInr"]:
                    out += f" (the INR {band['minimumInr']:,.0f} minimum applies)"
                if band.get("maximumInr") and got >= band["maximumInr"]:
                    out += f" (capped at INR {band['maximumInr']:,.0f})"
                return out

            # The tax's own band, stated in its own numbers. It had been
            # computed here and then discarded in favour of "18% of the
            # deemed value of INR 4,899.42" — which does not reproduce:
            # 4,899.42 x 18% is 881.8956, a paisa above the 881.89 charged.
            # The deemed value is derived by division and rounded for
            # display, so quoting it as the input to a multiplication
            # invites a maker to redo the sum and get a different answer.
            # The band the charge actually comes from reproduces exactly.
            tax_working = working(tier)
            # The deemed value is a different band of a different table —
            # 1% / 0.5% / 0.1% against the tax's 0.18% / 0.09% / 0.018% —
            # so it needs its own working. Showing the tax band's sum under
            # the value put "INR 180 + 0.09% of 670,760.54" beneath a figure
            # of 4,353.80, when that sum is 783.68: the number on the line
            # below it.
            value_tiers = clause.get("valueTiers") or clause["tiers"]
            value_band = next((b for b in value_tiers
                               if b.get("upToInr") is None
                               or gross <= float(b["upToInr"])), value_tiers[-1])
            rate = float(clause.get("gstPercent") or 18) / 100.0
            value = round(fee / rate, 2) if rate else 0.0
            return {"amountInr": round(fee, 2), "valueInr": value,
                    "valueBasis": working(value_band),
                    # Both halves in one line: the band the figure actually
                    # comes from, which reproduces, and the relationship to
                    # the deemed value above it, which is what a maker is
                    # looking for when the two rows sit together.
                    # What the clause is for, from the two dropdowns above
                    # the slab on the same sheet. Without it the charge
                    # reads like a general tariff rather than the one this
                    # product is priced under.
                    "scope": _scope_sentence(clause),
                    "basis": f"{tax_working} — which is "
                             f"{clause.get('gstPercent', 18):.0f}% of the "
                             "deemed value above"}
    return {"amountInr": 0.0, "valueInr": 0.0,
            "basis": "outside the quoted clause"}


def clients() -> list[dict]:
    """Every client with pricing on file, and what the parser makes of it.

    ``matches`` is filtered to the spellings that would actually find this
    page. An alias is an alternate way of writing the whole name, so one
    that is merely a fragment - "HELLA" for Hella India Automotive, "BOSCH
    REXROTH" for Bosch Rexroth India - no longer resolves, and listing it
    would promise a lookup the page does not answer to.
    """
    out = []
    for entry in load("autobahn").get("clients", []):
        want = normalise_name(entry["client"])
        live = [a for a in entry.get("matches", [])
                if normalise_name(a) and normalise_name(a) == want
                and normalise_name(a) != normalise_name(entry["client"]) or
                (normalise_name(a) == want and a.upper() != entry["client"].upper())]
        out.append({**entry, "matches": live,
                    "reading": parse(entry["processingText"])})
    return out
