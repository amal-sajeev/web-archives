"""The consistency checks between IDPMS and TradePay.

Three checks are specified: drawer name, drawer country and currency. Each
compares what TradePay holds against a reference value, and the reference is a
cascade, not a single system — IDPMS first, then the supporting documents
attached in TradePay, then WFMS. ``fallback.resolve`` walks it and says which
source answered, or which one the case is waiting on.

Their definitions live in ``app/data/checks.json`` so they can be changed
without touching code.

Further checks come out of the data itself rather than the written list, and
are reported separately as such: an amount that does not reconcile, which of
the consignment's invoices the remittance actually covers, and a port that
could not be resolved.

A Bill of Entry carrying several invoices is the ordinary case and is not
reported as anything. Nor is a Bill of Entry number shared with another
importer: the number is not unique, the transaction is identified on the number
and the invoice number together, and a maker has nothing to do about either.
"""

from __future__ import annotations

from collections.abc import Iterator

from . import fallback, idpms, ports, tradepay
from ._data import tidy_address, fold, load, normalise_country, normalise_name
from ..text import has_have, listed, n, s


def _where(resolved: dict) -> str:
    """A port written out: the facility, its town, its country.

    The town is only added when the directory's name does not already carry
    it, or INBOM4 reads "Air Cargo Complex Sahar, Mumbai, Mumbai, India".
    """
    name = resolved.get("name") or ""
    bits = [name]
    city = resolved.get("city")
    if city and city.lower() not in name.lower():
        bits.append(city)
    if resolved.get("country"):
        bits.append(resolved["country"])
    return ", ".join(b for b in bits if b)


def definitions() -> list[dict]:
    return load("checks").get("checks", [])


# Currency codes, for spotting one sitting in a country field.
_CCY = {"USD", "EUR", "GBP", "JPY", "CHF", "SGD", "HKD", "AUD", "CAD", "CNY",
        "THB", "INR", "SEK", "AED", "NZD", "DKK", "NOK", "ZAR", "MYR", "KRW"}


def _tidy(label: str, value) -> str:
    """One IDPMS field, cleaned of its own punctuation and checked for sense.

    Two things show up in the supplied extract. Addresses carry empty
    components, so "CHINA HUBEI, , CHINA" prints a comma with nothing in
    front of it. And row 23 — Putzmeister — holds 14911.43 where the seller
    address belongs and CNY where its country belongs, which is a column
    shifted in the bank's own file.

    Neither is corrected here. The procedure is to preserve the source value
    and flag it, so the value is shown as supplied and told plainly what it
    cannot be. Rewriting it would hide a fault in the record a maker is
    supposed to find.
    """
    text = tidy_address(value)

    low = label.lower()
    wrong = None
    if _numeric(text) and ("address" in low or "country" in low
                           or low in ("seller",)):
        wrong = "a number where " + ("an address" if "address" in low
                                     else "a name" if low == "seller"
                                     else "a country") + " should be"
    elif "country" in low and text.upper() in _CCY:
        wrong = "a currency code where a country should be"
    if wrong:
        return f"{text} — {wrong}; this IDPMS row looks shifted"
    return text


def _numeric(text: str) -> bool:
    try:
        float(text.replace(",", ""))
    except (TypeError, ValueError):
        return False
    return True


def _compare(mode: str, left, right) -> bool:
    """Do the two systems hold the same value?

    Only the typing is folded — case, spacing, punctuation. Abbreviations are
    not: NUTEK PTE LTD against NUTEK PRIVATE LIMITED is a difference, and so
    is PEOPLES REP OF CHINA against CHINA. Both are probably the same party
    and the same country, and probably is what a maker is paid to decide. A
    comparison that knew the legal forms would make that call invisibly, on
    every case, with nobody's name against it.

    The lookups keep their knowledge: ``normalise_name`` still finds the
    right TradePay row and the right booked deal. Finding a record and
    agreeing with it are different jobs.
    """
    if left is None or right is None:
        return False
    return fold(left) == fold(right)


def _paid_lines(consignment: dict, tradepay_record: dict) -> list[dict]:
    """The IDPMS lines the TradePay record actually covers.

    A remittance need not cover every invoice under the Bill of Entry. Rothe
    Erde's nine portal rows leave out two IDPMS invoices; Bosch Rexroth's row
    covers one of two. Reconciling against all of them invents a difference.
    """
    from ._data import normalise_ref

    paid = {normalise_ref(n) for n in
            str(tradepay_record.get("invoiceNo") or "").split(",") if n.strip()}
    if not paid:
        return consignment["invoiceLines"]
    lines = [l for l in consignment["invoiceLines"]
             if normalise_ref(l.get("invoiceNo")) in paid]
    return lines or consignment["invoiceLines"]


def _reconcile_amount(head: dict, consignment: dict, tp_amount: float,
                      lines: list[dict] | None = None) -> dict:
    """Does the TradePay figure reconcile with the IDPMS invoice line(s)?

    The portal pays the invoice plus whatever charges are billed in the same
    currency. Symrise is the worked example: IDPMS holds 11,619.72 SGD with
    80 SGD of miscellaneous charges, and TradePay pays 11,699.72. Comparing the
    invoice alone would report a difference that is not one.
    """
    currency = head.get("invoiceCurrency")
    lines = lines if lines is not None else consignment.get("invoiceLines", [])

    invoice_total = sum(float(l.get("invoiceAmount") or 0) for l in lines)
    extras: list[tuple[str, float]] = []
    for label, amount_key, ccy_key in (
        ("miscellaneous charges", "miscellaneousCharges", "miscellaneousCurrency"),
        ("agency commission", "agencyCommission", "agencyCurrency"),
        ("freight", "freightAmount", "freightCurrencyCode"),
        ("insurance", "insuranceAmount", "insuranceCurrencyCode"),
    ):
        total = sum(float(l.get(amount_key) or 0) for l in lines
                    if l.get(ccy_key) == currency)
        if total:
            extras.append((label, round(total, 2)))

    if abs(tp_amount - invoice_total) < 0.01:
        return {"ok": True, "basis": "the invoice amount",
                "expected": round(invoice_total, 2), "extras": []}

    running = invoice_total
    used: list[tuple[str, float]] = []
    for label, amount in extras:
        running += amount
        used.append((label, amount))
        if abs(tp_amount - running) < 0.01:
            parts = " plus ".join(f"{a:,.2f} of {lbl}" for lbl, a in used)
            return {"ok": True, "basis": f"the invoice amount plus {parts}",
                    "expected": round(running, 2), "extras": used}

    return {"ok": False, "basis": None,
            "expected": round(invoice_total, 2), "extras": extras}


def run(consignment: dict, tradepay_record: dict | None) -> list[dict]:
    """Every check for one consignment, in the order a maker would read them."""
    return list(run_iter(consignment, tradepay_record))


def run_iter(consignment: dict, tradepay_record: dict | None) -> Iterator[dict]:
    """The same checks, yielded one at a time as each is worked out.

    The case page walks this so each comparison appears as it is made; nothing
    is held back and nothing is computed twice.
    """
    head = consignment["invoiceLines"][0]
    boe = consignment["billOfEntryNumber"]
    boe_date = consignment.get("billOfEntryDate")
    invoice_nos = [l.get("invoiceNo") for l in consignment["invoiceLines"]]

    # --- the three specified checks ---------------------------------------
    for spec in definitions():
        reference = fallback.resolve(spec["idpmsField"], head, consignment)

        if tradepay_record is None:
            yield {
                "id": spec["id"], "label": spec["label"], "status": "blocked",
                "detail": (tradepay.why_no_match(boe, invoice_nos, boe_date) or
                           "There is no TradePay record for this consignment, so "
                           "nothing can be compared against it."),
                "source": "TradePay", "compared": [],
            }
            continue

        if reference["status"] != "found":
            yield {
                "id": spec["id"], "label": spec["label"], "status": "blocked",
                "detail": reference["message"],
                "source": " / ".join(reference["consulted"]), "compared": [],
            }
            continue

        left = tradepay_record.get(spec["tradePayField"])
        right = reference["value"]

        # A field the portal did not return cannot be compared, and must not
        # be reported as a difference. The first sentence is short because the
        # queue takes it as the case's headline.
        field = spec["tradePayField"]
        if left in (None, "") and tradepay_record.get(f"{field}NotCaptured"):
            yield {
                "id": spec["id"], "label": spec["label"], "status": "blocked",
                "detail": f"TradePay returned no {spec['label'].lower()} for this "
                          "remittance. There is nothing to compare the "
                          f"{reference['source']} record against, so the check "
                          "settles as soon as the field comes back.",
                "source": "TradePay", "compared": [],
            }
            continue

        # A name the portal returns cut to its column width is reported as a
        # difference, not quietly accepted. "E GMBH CO KG" probably is the tail
        # of HEINRICHS DREHTEILE GMBH CO. KG, and the bank's own rule is that
        # probably is not good enough: a maker settles it and says so, which
        # leaves a record. Matching short forms to long ones in code would make
        # that judgement invisibly, on every case, with nobody's name against
        # it - and would match the wrong pair the first time two counterparties
        # shared an ending.
        ok = _compare(spec["compare"], left, right)
        # Keep the comparison itself name-to-name, but expose the identifying
        # fields IDPMS has alongside the supplier name so a maker can distinguish
        # similar counterparties without opening the raw record.
        idpms_details = []
        if spec.get("id") == "DRAWER_NAME":
            details = []
            for label, key in (("Address", "supplierAddress"),
                               ("Country", "supplierCountry"),
                               ("Seller", "sellerName"),
                               ("Seller address", "sellerAddress"),
                               ("Seller country", "sellerCountry")):
                value = head.get(key)
                if value and str(value).strip() and str(value).strip() != str(right or "").strip():
                    details.append(f"{label}: {_tidy(label, value)}")
            idpms_details = details

        yield {
            "id": spec["id"],
            "label": spec["label"],
            "status": "pass" if ok else "fail",
            "detail": spec["detail"] if ok else
                      f"{spec['label']} differs. TradePay holds "
                      f"“{left or '—'}”; {reference['source']} holds "
                      f"“{right or '—'}”.",
            "source": f"TradePay ↔ {reference['source']}",
            "compared": [{"field": spec["label"],
                          "tradePay": str(left or "—"),
                          "idpms": str(right or "—"),
                          "idpms_details": idpms_details}],
        }

    # --- checks the data forces, beyond the written three ------------------
    if tradepay_record is not None:
        tp_amount = tradepay_record.get("invoiceAmount")
        if isinstance(tp_amount, (int, float)):
            paid = _paid_lines(consignment, tradepay_record)
            r = _reconcile_amount(head, consignment, float(tp_amount), paid)
            covered = (f" across the {n(len(paid), 'invoice line')} it covers"
                       if len(paid) != len(consignment["invoiceLines"]) else "")
            idpms_total = r["expected"]
            yield {
                "id": "INVOICE_AMOUNT",
                "label": "Amount reconciles",
                "status": "pass" if r["ok"] else "fail",
                "detail": (f"TradePay pays {tp_amount:,.2f}, which is "
                           f"{r['basis']} in IDPMS{covered}."
                           if r["ok"] else
                           f"TradePay holds {tp_amount:,.2f}; IDPMS adds up to "
                           f"{idpms_total:,.2f}{covered}"
                           + (" even after the charges billed in the same "
                              "currency are added" if r["extras"] else "")
                           + ". Not one of the three specified checks, but the "
                             "difference is material and nothing in the record "
                             "explains it."),
                "source": "TradePay ↔ IDPMS",
                "compared": [{"field": "Amount",
                              "tradePay": f"{tp_amount:,.2f}",
                              "idpms": f"{idpms_total:,.2f}"}],
            }

    # --- the lookup, done one invoice at a time ---------------------------
    # Reported where it says something: more than one invoice under the number,
    # or a remittance that does not cover them all. A single invoice matched to
    # a single row needs no line of its own.
    cover = tradepay.coverage(boe, invoice_nos)
    mine = len([l for l in consignment["invoiceLines"] if l.get("invoiceNo")])
    if mine > 1 or cover["missing"]:
        found = len(cover["matched"])
        absent, misfiled = cover["absent"], cover["elsewhere"]
        shared_note = ""
        if cover["foreignRows"]:
            holders = sorted({
                r.get("IEName") for r in idpms.all_lines()
                if r["billOfEntryNumber"] == boe
                and r.get("IEName") != consignment["importer"] and r.get("IEName")
            })
            rows = len(cover["foreignRows"])
            shared_note = (
                f" Another {n(rows, 'row')} under the same number "
                f"{'belongs' if rows == 1 else 'belong'} to "
                + (listed(holders) if holders else "another transaction")
                + ", which is why the invoice number is part of the key.")

        # A misfiled row is a different piece of work from a missing one: the
        # money has moved and the reference is wrong, rather than nothing having
        # been raised at all. Reporting both as "no row yet" sends a maker
        # chasing a remittance that TradePay already holds.
        misfiled_note = ""
        if misfiled:
            where = [f"{ref} under Bill of Entry "
                     + listed(sorted({str(r.get("billOfEntryNumber"))
                                      for r in rows_found}))
                     for ref, rows_found in list(misfiled.items())[:3]]
            misfiled_note = (f" TradePay holds {listed(where, limit=3)} \u2014 the "
                             "remittance exists, filed against a different number.")

        if found == 0:
            detail = (tradepay.why_no_match(boe, invoice_nos, boe_date)
                      or "No remittance could be matched to this transaction.")
            status = "blocked"
        elif absent or misfiled:
            parts = [f"The remittance covers {found} of this transaction's "
                     f"{n(mine, 'invoice')}."]
            if absent:
                # "Invoice 60075467 has", not "60075467 has" - a sentence that
                # opens on a figure reads as a continuation of the one before.
                parts.append(
                    f"Invoice{s(len(absent))} {listed(absent)} "
                    f"{has_have(len(absent))} no TradePay row under this Bill of "
                    f"Entry or any other, so nothing is reconciled against "
                    f"{'it' if len(absent) == 1 else 'them'}.")
            detail = " ".join(parts) + misfiled_note + shared_note
            status = "pass"
        else:
            detail = (f"All {n(mine, 'invoice')} under Bill of Entry {boe} "
                      f"{'is' if mine == 1 else 'are'} matched to the remittance "
                      "on invoice number." + shared_note)
            status = "pass"

        yield {
            "id": "INVOICE_MATCH",
            "label": "Invoices matched on Bill of Entry and invoice number",
            "status": status,
            "detail": detail,
            "source": "TradePay \u2194 IDPMS",
            "compared": [],
        }

    for role, code in (("Port of loading", consignment.get("portOfShipment")),
                       ("Port of discharge", consignment.get("portOfDischarge"))):
        resolved = ports.resolve(code, consignment.get("supplierCountryIso2"))
        check_id = f"PORT_{role.split()[-1].upper()}"
        if resolved["status"] == "resolved":
            yield {
                "id": check_id, "label": role, "status": "pass",
                "detail": f"{code} resolves to {_where(resolved)}.",
                "source": "Port directory", "compared": [],
            }
        else:
            yield {
                "id": check_id, "label": role,
                "status": "blocked" if resolved["status"] == "directory_unavailable" else "fail",
                "detail": resolved["message"] + (
                    f" Searched as {resolved['searchedAs']}."
                    if resolved.get("prefixApplied") else ""),
                "source": "Port directory", "compared": [],
            }


def summary(results: list[dict]) -> dict:
    passed = sum(1 for r in results if r["status"] == "pass")
    open_items = [r for r in results if r["status"] in ("fail", "warn", "blocked")]
    return {
        "passed": passed,
        "total": len(results),
        "open": len(open_items),
        "clear": not open_items,
    }
