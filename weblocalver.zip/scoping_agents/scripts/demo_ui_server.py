#!/usr/bin/env python3
"""
Lightweight FastAPI Demo UI for CT1 Data Extraction & Query Service
Document Inclusion / Exclusion.

Run:
    python scripts/demo_ui_server.py
Then open http://127.0.0.1:8090
"""

from __future__ import annotations

import io
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
import uvicorn
from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse

CT1_HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com").rstrip("/")
DATAEXTRACTION_BASE = f"{CT1_HOST}/scoping-dataextraction-agent"
QUERY_SERVICE_BASE = f"{CT1_HOST}/query-service"
SUMMARY_AGENT_BASE = f"{CT1_HOST}/scoping-summary-agent"

app = FastAPI(title="DBAware CT1 Inclusion/Exclusion Demo UI")


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(verify=False, timeout=120.0)


@app.get("/api/overview/{plan_number}")
async def api_overview(plan_number: str) -> JSONResponse:
    async with _client() as client:
        avail_r, list_all_r, policy_art_r, hist_r, findings_r = (
            await client.get(f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/availability"),
            await client.post(
                f"{QUERY_SERVICE_BASE}/qna/documents/list-all",
                json={"plan_number": plan_number},
            ),
            await client.get(f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/policy"),
            await client.get(
                f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/historical_plan_details"
            ),
            await client.get(
                f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/findings_details"
            ),
        )

    def _safe_json(resp: httpx.Response) -> Any:
        try:
            return resp.json()
        except Exception:
            return {"raw": resp.text, "status_code": resp.status_code}

    list_all_body = _safe_json(list_all_r)
    policy_body = _safe_json(policy_art_r)
    policy_body = _sync_policy_artifact_with_active_list(policy_body, list_all_body)

    return JSONResponse(
        {
            "plan_number": plan_number,
            "ct1_host": CT1_HOST,
            "availability": {"status": avail_r.status_code, "body": _safe_json(avail_r)},
            "query_documents_list_all": {
                "status": list_all_r.status_code,
                "body": list_all_body,
            },
            "dataextraction_policy": {
                "status": policy_art_r.status_code,
                "body": policy_body,
            },
            "dataextraction_historical": {
                "status": hist_r.status_code,
                "body": _safe_json(hist_r),
            },
            "dataextraction_findings": {
                "status": findings_r.status_code,
                "body": _safe_json(findings_r),
            },
        }
    )


def _sync_policy_artifact_with_active_list(
    policy_body: Any, list_all_body: Any
) -> Any:
    """Filter dataextraction policy referenced_documents against query-service active documents."""
    if not isinstance(policy_body, dict) or not isinstance(list_all_body, dict):
        return policy_body
    data_obj = policy_body.get("data")
    if not isinstance(data_obj, dict) or not isinstance(
        data_obj.get("referenced_documents"), list
    ):
        return policy_body

    active_by_type: dict[str, set[str]] = {}
    active_docs_by_type: dict[str, list[dict[str, Any]]] = {}
    for group in list_all_body.get("document_groups") or []:
        if not isinstance(group, dict):
            continue
        dtype = str(group.get("document_type") or "").strip().lower()
        docs = [
            d
            for d in (group.get("documents") or [])
            if isinstance(d, dict)
            and d.get("excluded") is not True
            and str(d.get("status") or "active").strip().lower()
            not in {"excluded", "removed", "deleted", "inactive"}
        ]
        active_docs_by_type[dtype] = docs
        active_by_type[dtype] = {
            str(d.get("document_title") or d.get("file_name") or "").strip().lower()
            for d in docs
            if d.get("document_title") or d.get("file_name")
        }

    filtered_refs: list[dict[str, Any]] = []
    seen_titles: set[tuple[str, str]] = set()
    for ref in data_obj["referenced_documents"]:
        if not isinstance(ref, dict):
            continue
        dtype = str(ref.get("document_type") or "").strip().lower()
        dname = str(ref.get("document_name") or "").strip()
        if dtype in active_by_type and dname.lower() not in active_by_type[dtype]:
            continue
        filtered_refs.append(ref)
        seen_titles.add((dtype, dname.lower()))

    # Also include any newly uploaded active documents not yet in referenced_documents
    for dtype, docs in active_docs_by_type.items():
        for d in docs:
            dtitle = str(d.get("document_title") or d.get("file_name") or "").strip()
            if dtitle and (dtype, dtitle.lower()) not in seen_titles:
                filtered_refs.append(
                    {
                        "document_type": dtype,
                        "document_name": dtitle,
                        "gs_uri": d.get("storage_uri")
                        or f"gs://db-dev-euwe3-gcs-155081-dbaware_review/dbaware_review_{list_all_body.get('plan_number', '20090')}/inbound-data/policy/relevant_{dtype}/{d.get('file_name', '')}",
                    }
                )
                seen_titles.add((dtype, dtitle.lower()))

    updated = dict(policy_body)
    updated_data = dict(data_obj)
    updated_data["referenced_documents"] = filtered_refs
    updated["data"] = updated_data
    return updated


@app.get("/api/dataextraction/getdata/{plan_number}/{artifact}")
async def api_get_artifact(plan_number: str, artifact: str) -> JSONResponse:
    url = f"{DATAEXTRACTION_BASE}/getdata/{plan_number}/{artifact}"
    async with _client() as client:
        r = await client.get(url)
        list_all_r = (
            await client.post(
                f"{QUERY_SERVICE_BASE}/qna/documents/list-all",
                json={"plan_number": plan_number},
            )
            if artifact == "policy"
            else None
        )
    try:
        body = r.json()
    except Exception:
        body = {"raw": r.text}
    if artifact == "policy" and list_all_r is not None:
        try:
            body = _sync_policy_artifact_with_active_list(body, list_all_r.json())
        except Exception:
            pass
    return JSONResponse({"url": url, "status": r.status_code, "body": body})


@app.post("/api/dataextraction/run")
async def api_run_extraction(request: Request) -> JSONResponse:
    payload = await request.json()
    url = f"{DATAEXTRACTION_BASE}/data-extraction"
    async with _client() as client:
        r = await client.post(url, json=payload)
    try:
        body = r.json()
    except Exception:
        body = {"raw": r.text}
    return JSONResponse({"url": url, "status": r.status_code, "body": body})


@app.post("/api/query/exclude")
async def api_exclude_documents(request: Request) -> JSONResponse:
    """
    Calls CT1 query-service exclusion endpoint.
    Tries staged /qna/documents/exclusion/execute if available, and also calls
    /qna/documents/delete (the BulkDocumentDeleteRequest endpoint live on CT1).
    """
    payload = await request.json()
    plan_number = str(payload.get("plan_number", "20090"))
    documents: List[Dict[str, Any]] = payload.get("documents", [])
    endpoint_mode = payload.get("mode", "delete")

    async with _client() as client:
        if endpoint_mode == "staged_execute":
            url = f"{QUERY_SERVICE_BASE}/qna/documents/exclusion/execute"
            actions = []
            for group in documents:
                dtype = group.get("document_type", "policy")
                for item in group.get("items", []):
                    actions.append(
                        {
                            "action": item.get("action", "exclude"),
                            "document_type": dtype,
                            "title": item.get("document_title", ""),
                            "document_id": str(item.get("document_id", "")),
                            "filename": item.get("file_name", ""),
                            "section_id": item.get("section_id"),
                            "section_title": item.get("section_title"),
                            "scope": "all_related",
                        }
                    )
            req_body = {
                "plan_number": plan_number,
                "actions": actions,
                "approved_by": payload.get("approved_by", "demo-ui-user"),
            }
            r = await client.post(url, json=req_body)
        else:
            url = f"{QUERY_SERVICE_BASE}/qna/documents/delete"
            req_body = {"plan_number": plan_number, "documents": documents}
            r = await client.post(url, json=req_body)

    try:
        body = r.json()
    except Exception:
        body = {"raw": r.text}
    return JSONResponse(
        {"url": url, "request": req_body, "status": r.status_code, "body": body}
    )


def _extract_nodes_from_uploaded_file(
    raw_filename: str,
    file_bytes: bytes,
    doc_id: str,
    doc_title: str,
    doc_type: str,
    default_section_title: str,
) -> Dict[str, Any]:
    """
    Converts an uploaded PDF, DOCX, JSON, or TXT file into the CT1 document JSON schema
    (with `nodes[]` containing `original_text` and `text`) so `/qna/upload`, `/qna/documents/list-all`,
    and `/qna/chat` can immediately index and use it.
    """
    ext = Path(raw_filename or "").suffix.lower()

    if ext == ".json":
        try:
            parsed = json.loads(file_bytes.decode("utf-8", errors="replace"))
            if isinstance(parsed, dict):
                parsed.setdefault("document_id", doc_id)
                parsed.setdefault("document_title", doc_title)
                parsed.setdefault("document_type", doc_type)
                parsed["status"] = "active"
                parsed["excluded"] = False
                return parsed
        except Exception:
            pass

    nodes: List[Dict[str, Any]] = []

    if ext == ".pdf":
        import pypdf

        reader = pypdf.PdfReader(io.BytesIO(file_bytes))
        for page_idx, page in enumerate(reader.pages, start=1):
            page_text = (page.extract_text() or "").strip()
            if not page_text:
                continue
            first_line = next(
                (ln.strip() for ln in page_text.splitlines() if ln.strip()),
                f"Page {page_idx}",
            )[:120]
            sec_title = (
                default_section_title
                if (page_idx == 1 and default_section_title)
                else f"Page {page_idx} - {first_line}"
            )
            nodes.append(
                {
                    "chunk_id": page_idx,
                    "document_id": int(doc_id) if str(doc_id).isdigit() else doc_id,
                    "document_type": doc_type,
                    "node_id": f"{doc_id}:section:{page_idx}",
                    "section_id": str(page_idx),
                    "section_title": sec_title,
                    "page_start": page_idx,
                    "page_end": page_idx,
                    "original_text": page_text,
                    "text": page_text,
                    "document_title": doc_title,
                    "status": "active",
                    "excluded": False,
                }
            )
    elif ext == ".docx":
        import docx

        doc = docx.Document(io.BytesIO(file_bytes))
        paras = [p.text.strip() for p in doc.paragraphs if p.text and p.text.strip()]
        full_text = "\n\n".join(paras) or f"Uploaded DOCX: {raw_filename}"
        nodes.append(
            {
                "chunk_id": 1,
                "document_id": int(doc_id) if str(doc_id).isdigit() else doc_id,
                "document_type": doc_type,
                "node_id": f"{doc_id}:section:1",
                "section_id": "1",
                "section_title": default_section_title or doc_title,
                "page_start": 1,
                "page_end": 1,
                "original_text": full_text,
                "text": full_text,
                "document_title": doc_title,
                "status": "active",
                "excluded": False,
            }
        )
    else:
        text_content = file_bytes.decode("utf-8", errors="replace").strip()
        if not text_content:
            text_content = f"Uploaded file {raw_filename}"
        nodes.append(
            {
                "chunk_id": 1,
                "document_id": int(doc_id) if str(doc_id).isdigit() else doc_id,
                "document_type": doc_type,
                "node_id": f"{doc_id}:section:1",
                "section_id": "1",
                "section_title": default_section_title or doc_title,
                "page_start": 1,
                "page_end": 1,
                "original_text": text_content,
                "text": text_content,
                "document_title": doc_title,
                "status": "active",
                "excluded": False,
            }
        )

    if not nodes:
        nodes.append(
            {
                "chunk_id": 1,
                "document_id": int(doc_id) if str(doc_id).isdigit() else doc_id,
                "document_type": doc_type,
                "node_id": f"{doc_id}:section:1",
                "section_id": "1",
                "section_title": default_section_title or doc_title,
                "page_start": 1,
                "page_end": 1,
                "original_text": f"Uploaded PDF document: {doc_title} ({raw_filename})",
                "text": f"Uploaded PDF document: {doc_title} ({raw_filename})",
                "document_title": doc_title,
                "status": "active",
                "excluded": False,
            }
        )

    return {
        "document_id": str(doc_id),
        "document_title": doc_title,
        "document_type": doc_type,
        "source_file_name": raw_filename,
        "status": "active",
        "excluded": False,
        "nodes": nodes,
    }


@app.post("/api/query/include-file")
async def api_include_uploaded_file(
    file: UploadFile = File(...),
    plan_number: str = Form("20090"),
    document_type: str = Form("policy"),
    document_id: str = Form("99"),
    file_name: str = Form(""),
    document_title: str = Form(""),
    section_title: str = Form(""),
) -> JSONResponse:
    """
    Accepts a PDF, DOCX, JSON, or TXT file upload from the browser, extracts its pages/sections
    into the CT1 document structure, and uploads it via POST /query-service/qna/upload.
    """
    raw_filename = file.filename or "uploaded_document.pdf"
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", Path(raw_filename).stem).strip("_") or "uploaded_doc"
    resolved_title = document_title.strip() or stem
    resolved_json_name = file_name.strip() or f"{stem}.json"
    if not resolved_json_name.endswith(".json"):
        resolved_json_name = f"{ Path(resolved_json_name).stem }.json"

    file_bytes = await file.read()
    doc_json = _extract_nodes_from_uploaded_file(
        raw_filename=raw_filename,
        file_bytes=file_bytes,
        doc_id=document_id.strip() or "99",
        doc_title=resolved_title,
        doc_type=document_type.strip() or "policy",
        default_section_title=section_title.strip(),
    )

    dest_blob_path = (
        f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{document_type}/{resolved_json_name}"
    )
    url = f"{QUERY_SERVICE_BASE}/qna/upload"
    async with _client() as client:
        files = {
            "file": (
                resolved_json_name,
                io.BytesIO(json.dumps(doc_json, indent=2).encode("utf-8")),
                "application/json",
            )
        }
        data = {"dest_blob_path": dest_blob_path}
        r = await client.post(url, data=data, files=files)

    try:
        body = r.json()
    except Exception:
        body = {"raw": r.text}
    return JSONResponse(
        {
            "url": url,
            "source_file": raw_filename,
            "extracted_sections_or_pages": len(doc_json.get("nodes", [])),
            "dest_blob_path": dest_blob_path,
            "uploaded_document": doc_json,
            "status": r.status_code,
            "body": body,
        }
    )


@app.post("/api/query/include")
async def api_include_document(request: Request) -> JSONResponse:
    """
    Includes / uploads a JSON document to CT1 query-service:
    Uses /qna/upload (multipart JSON upload to GCS) or /qna/documents/upload if deployed.
    """
    payload = await request.json()
    plan_number = str(payload.get("plan_number", "20090"))
    doc_type = str(payload.get("document_type", "policy"))
    file_name = str(payload.get("file_name", "policy_demo.json"))
    if not file_name.endswith(".json"):
        file_name = f"{file_name}.json"
    doc_id = str(payload.get("document_id", "99"))
    doc_title = str(payload.get("document_title", "Demo_Included_Policy"))
    section_title = str(payload.get("section_title", "Section 1 - Scope"))
    content_text = str(payload.get("content", "Included via Demo UI."))

    dest_blob_path = (
        f"dbaware_review_{plan_number}/inbound-data/policy/relevant_{doc_type}/{file_name}"
    )
    doc_json = {
        "document_id": doc_id,
        "document_title": doc_title,
        "document_type": doc_type,
        "status": "active",
        "excluded": False,
        "nodes": [
            {
                "section_id": "1",
                "section_title": section_title,
                "node_id": f"{doc_id}:section:1",
                "original_text": content_text,
                "text": content_text,
                "document_title": doc_title,
                "status": "active",
                "excluded": False,
            }
        ],
    }

    url = f"{QUERY_SERVICE_BASE}/qna/upload"
    async with _client() as client:
        files = {
            "file": (
                file_name,
                io.BytesIO(json.dumps(doc_json, indent=2).encode("utf-8")),
                "application/json",
            )
        }
        data = {"dest_blob_path": dest_blob_path}
        r = await client.post(url, data=data, files=files)

    try:
        body = r.json()
    except Exception:
        body = {"raw": r.text}
    return JSONResponse(
        {
            "url": url,
            "dest_blob_path": dest_blob_path,
            "uploaded_document": doc_json,
            "status": r.status_code,
            "body": body,
        }
    )


@app.post("/api/query/chat")
async def api_query_chat(request: Request) -> JSONResponse:
    payload = await request.json()
    url = f"{QUERY_SERVICE_BASE}/qna/chat"
    async with _client() as client:
        r = await client.post(url, json=payload)
    try:
        body = r.json()
    except Exception:
        body = {"raw": r.text}
    return JSONResponse(
        {"url": url, "request": payload, "status": r.status_code, "body": body}
    )


HTML_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>DBAware CT1 — Document Inclusion & Exclusion Console</title>
<style>
  :root {
    --bg: #0f172a;
    --panel: #1e293b;
    --panel-alt: #0b1120;
    --border: #334155;
    --text: #f8fafc;
    --muted: #94a3b8;
    --accent: #38bdf8;
    --danger: #ef4444;
    --success: #22c55e;
    --warn: #f59e0b;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.45;
  }
  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 24px;
    background: var(--panel);
    border-bottom: 1px solid var(--border);
  }
  header h1 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
  }
  .controls {
    display: flex;
    gap: 10px;
    align-items: center;
  }
  input, select, textarea, button {
    font: inherit;
    color: var(--text);
    background: var(--panel-alt);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 7px 11px;
  }
  button {
    cursor: pointer;
    background: #2563eb;
    border-color: #3b82f6;
    font-weight: 500;
  }
  button:hover { opacity: 0.92; }
  button.danger { background: #dc2626; border-color: #ef4444; }
  button.success { background: #16a34a; border-color: #22c55e; }
  button.secondary { background: #334155; border-color: #475569; }
  main {
    display: grid;
    grid-template-columns: 1.15fr 0.85fr;
    gap: 16px;
    padding: 16px 24px;
    max-width: 1600px;
    margin: 0 auto;
  }
  .card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 16px;
  }
  .card h2 {
    margin: 0 0 10px 0;
    font-size: 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .badge {
    font-size: 11px;
    padding: 2px 8px;
    border-radius: 999px;
    background: #1d4ed8;
    color: #e0f2fe;
  }
  .badge.ok { background: #15803d; }
  .badge.warn { background: #b45309; }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    margin-top: 8px;
  }
  th, td {
    text-align: left;
    padding: 8px 10px;
    border-bottom: 1px solid var(--border);
  }
  th { color: var(--muted); font-weight: 500; }
  pre {
    background: var(--panel-alt);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 12px;
    overflow: auto;
    max-height: 460px;
    font-size: 12px;
    margin: 0;
  }
  .form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-bottom: 8px;
  }
  .muted { color: var(--muted); font-size: 12px; }
  .row-actions { display: flex; gap: 6px; }
</style>
</head>
<body>
<header>
  <div>
    <h1>DBAware CT1 — Data Extraction & Query Agent Document Inclusion / Exclusion</h1>
    <div class="muted">Live CT1 Endpoints: <code>/scoping-dataextraction-agent</code> &amp; <code>/query-service/qna</code></div>
  </div>
  <div class="controls">
    <label class="muted">Plan Number:</label>
    <input id="planInput" value="20090" style="width:90px" />
    <label class="muted">Scope ID:</label>
    <input id="scopeInput" value="1" style="width:65px" />
    <button onclick="loadOverview()">Refresh CT1 State</button>
  </div>
</header>

<main>
  <div>
    <!-- Active Documents in Query Service -->
    <div class="card">
      <h2>
        <span>1. Active Documents (<code>POST /query-service/qna/documents/list-all</code>)</span>
        <span id="docCountBadge" class="badge">Loading...</span>
      </h2>
      <div class="muted" style="margin-bottom:8px">
        Select individual documents or click <strong>Exclude</strong> to call <code>POST /query-service/qna/documents/delete</code> on CT1.
      </div>
      <table>
        <thead>
          <tr>
            <th><input type="checkbox" id="selectAllBox" onchange="toggleSelectAll(this)" /></th>
            <th>Type</th>
            <th>ID</th>
            <th>File Name</th>
            <th>Document Title</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="docsTableBody">
          <tr><td colspan="6" class="muted">Loading documents...</td></tr>
        </tbody>
      </table>
      <div style="margin-top:12px; display:flex; gap:8px;">
        <button class="danger" onclick="excludeSelected()">Exclude Selected Documents</button>
        <button class="secondary" onclick="loadOverview()">Reload List</button>
      </div>
    </div>

    <!-- Include / Upload Document -->
    <div class="card">
      <h2>
        <span>2. Include / Upload Document (<code>POST /query-service/qna/upload</code>)</span>
        <span class="badge ok">PDF / DOCX / JSON</span>
      </h2>
      <div style="margin-bottom:10px; padding:10px; background:var(--panel-alt); border:1px dashed var(--border); border-radius:6px;">
        <div class="muted" style="margin-bottom:6px;">
          Upload a <strong>.pdf</strong>, <strong>.docx</strong>, <strong>.json</strong>, or <strong>.txt</strong> file (pages/sections are automatically extracted and uploaded to CT1), or leave empty to use the text fields below:
        </div>
        <div style="display:flex; gap:8px; align-items:center;">
          <input type="file" id="incUploadFile" accept=".pdf,.docx,.json,.txt,.md" onchange="onFilePicked(this)" style="flex:1;" />
          <button class="secondary" type="button" onclick="clearUploadFile()">Clear File</button>
        </div>
      </div>
      <div class="form-grid">
        <select id="incType">
          <option value="policy">policy</option>
          <option value="procedure">procedure</option>
          <option value="kod">kod</option>
        </select>
        <input id="incId" placeholder="Document ID (e.g. 1)" value="1" />
        <input id="incFile" placeholder="Target file name (e.g. policy1.json)" value="policy1.json" />
        <input id="incTitle" placeholder="Document Title" value="Operational_Risk_Management_Policy" />
      </div>
      <input id="incSection" placeholder="Section Title (optional for PDF)" value="Section 1 - Governance & Scope" style="width:100%; margin-bottom:8px;" />
      <textarea id="incContent" rows="2" style="width:100%; margin-bottom:8px;" placeholder="Manual text content (ignored if a PDF/DOCX/JSON file is selected above)">Operational risk management framework requirements for swap dealer compliance.</textarea>
      <button class="success" onclick="includeDocument()">Upload &amp; Include Document into Plan Context</button>
    </div>

    <!-- Conversational Q&A / Natural Language Exclusion -->
    <div class="card">
      <h2>
        <span>3. Query Service Chat (<code>POST /query-service/qna/chat</code>)</span>
        <span class="badge">Agent</span>
      </h2>
      <div style="display:flex; gap:8px; margin-bottom:8px;">
        <input id="chatInput" style="flex:1" value="Which policy and procedure documents are currently in scope for this review?" />
        <button onclick="sendChat()">Ask Query Agent</button>
      </div>
      <div id="chatAnswerBox" class="muted" style="white-space:pre-wrap; background:var(--panel-alt); padding:10px; border-radius:6px; border:1px solid var(--border);">
        Chat response will appear here.
      </div>
    </div>
  </div>

  <div>
    <!-- Data Extraction Artifacts -->
    <div class="card">
      <h2>
        <span>4. Data Extraction Agent (<code>GET /scoping-dataextraction-agent/getdata/{plan}/{artifact}</code>)</span>
      </h2>
      <div style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:10px;">
        <button class="secondary" onclick="fetchArtifact('policy')">policy</button>
        <button class="secondary" onclick="fetchArtifact('current_details')">current_details</button>
        <button class="secondary" onclick="fetchArtifact('historical_plan_details')">historical_plan_details</button>
        <button class="secondary" onclick="fetchArtifact('findings_details')">findings_details</button>
        <button class="secondary" onclick="fetchArtifact('control_details')">control_details</button>
        <button class="secondary" onclick="fetchArtifact('risk_driver_details')">risk_driver_details</button>
        <button class="secondary" onclick="fetchArtifact('lrr')">lrr</button>
      </div>
      <div class="muted" id="artifactStatus" style="margin-bottom:6px;">Click any artifact above to inspect live CT1 response.</div>
      <pre id="artifactInspector">Loading...</pre>
    </div>

    <!-- Live API Call Log -->
    <div class="card">
      <h2>
        <span>5. Last CT1 API Request / Response</span>
        <span id="lastStatusBadge" class="badge">Ready</span>
      </h2>
      <pre id="apiLogInspector">No mutation executed yet.</pre>
    </div>
  </div>
</main>

<script>
let currentDocs = [];

function getPlan() {
  return document.getElementById('planInput').value.trim() || '20090';
}
function getScopeId() {
  return parseInt(document.getElementById('scopeInput').value.trim() || '1', 10);
}

function logApi(title, data, status = 200) {
  const badge = document.getElementById('lastStatusBadge');
  badge.textContent = `${title} (HTTP ${status})`;
  badge.className = 'badge ' + (status >= 200 && status < 300 ? 'ok' : 'warn');
  document.getElementById('apiLogInspector').textContent = JSON.stringify(data, null, 2);
}

async function loadOverview() {
  const plan = getPlan();
  const tbody = document.getElementById('docsTableBody');
  tbody.innerHTML = '<tr><td colspan="6" class="muted">Fetching from CT1...</td></tr>';
  const res = await fetch(`/api/overview/${encodeURIComponent(plan)}`);
  const data = await res.json();

  const listAll = (data.query_documents_list_all || {}).body || {};
  const groups = listAll.document_groups || [];
  currentDocs = [];
  for (const g of groups) {
    for (const d of (g.documents || [])) {
      currentDocs.push({
        document_type: g.document_type,
        file_name: d.file_name,
        document_id: String(d.document_id ?? ''),
        document_title: d.document_title || d.file_name,
        status: d.status || 'active',
        excluded: Boolean(d.excluded)
      });
    }
  }

  document.getElementById('docCountBadge').textContent = `${currentDocs.length} Active Document(s)`;
  renderDocsTable();

  document.getElementById('artifactStatus').textContent =
    `GET /scoping-dataextraction-agent/getdata/${plan}/policy (HTTP ${data.dataextraction_policy?.status})`;
  document.getElementById('artifactInspector').textContent =
    JSON.stringify(data.dataextraction_policy?.body, null, 2);
}

function renderDocsTable() {
  const tbody = document.getElementById('docsTableBody');
  if (!currentDocs.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="muted">No active documents found for this plan.</td></tr>';
    return;
  }
  tbody.innerHTML = currentDocs.map((d, idx) => `
    <tr>
      <td><input type="checkbox" class="doc-check" data-idx="${idx}" /></td>
      <td><span class="badge">${d.document_type}</span></td>
      <td><code>${d.document_id}</code></td>
      <td><code>${d.file_name}</code></td>
      <td>${d.document_title}</td>
      <td class="row-actions">
        <button class="danger" style="padding:4px 8px; font-size:12px;" onclick="excludeSingle(${idx})">Exclude</button>
        <button class="secondary" style="padding:4px 8px; font-size:12px;" onclick="prefillInclude(${idx})">Copy to Include</button>
      </td>
    </tr>
  `).join('');
}

function toggleSelectAll(master) {
  document.querySelectorAll('.doc-check').forEach(cb => { cb.checked = master.checked; });
}

function prefillInclude(idx) {
  const d = currentDocs[idx];
  if (!d) return;
  document.getElementById('incType').value = d.document_type;
  document.getElementById('incId').value = d.document_id;
  document.getElementById('incFile').value = d.file_name;
  document.getElementById('incTitle').value = d.document_title;
}

async function excludeSingle(idx) {
  const d = currentDocs[idx];
  if (!d) return;
  prefillInclude(idx); // Save fields in Include form so user can re-include with 1 click
  await runExclusion([d]);
}

async function excludeSelected() {
  const indices = Array.from(document.querySelectorAll('.doc-check:checked'))
    .map(cb => parseInt(cb.getAttribute('data-idx'), 10));
  const picked = indices.map(i => currentDocs[i]).filter(Boolean);
  if (!picked.length) {
    alert('Select at least one document to exclude.');
    return;
  }
  prefillInclude(indices[0]);
  await runExclusion(picked);
}

async function runExclusion(docs) {
  const plan = getPlan();
  const byType = {};
  for (const d of docs) {
    if (!byType[d.document_type]) byType[d.document_type] = [];
    byType[d.document_type].push({
      file_name: d.file_name,
      document_title: d.document_title,
      document_id: String(d.document_id)
    });
  }
  const documentsPayload = Object.entries(byType).map(([document_type, items]) => ({
    document_type,
    items
  }));

  const res = await fetch('/api/query/exclude', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ plan_number: plan, documents: documentsPayload })
  });
  const data = await res.json();
  logApi('POST /qna/documents/delete', data, data.status);
  await loadOverview();
}

function onFilePicked(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const stem = file.name.replace(/\.[^/.]+$/, '').replace(/[^A-Za-z0-9_.-]+/g, '_');
  document.getElementById('incTitle').value = stem;
  document.getElementById('incFile').value = `${stem}.json`;
  const nextId = String(Math.floor(100 + Math.random() * 900));
  if (!document.getElementById('incId').value || document.getElementById('incId').value === '1') {
    document.getElementById('incId').value = nextId;
  }
}

function clearUploadFile() {
  const fileInput = document.getElementById('incUploadFile');
  if (fileInput) fileInput.value = '';
}

async function includeDocument() {
  const fileInput = document.getElementById('incUploadFile');
  const pickedFile = fileInput && fileInput.files && fileInput.files[0];

  if (pickedFile) {
    const form = new FormData();
    form.append('file', pickedFile);
    form.append('plan_number', getPlan());
    form.append('document_type', document.getElementById('incType').value);
    form.append('document_id', document.getElementById('incId').value.trim());
    form.append('file_name', document.getElementById('incFile').value.trim());
    form.append('document_title', document.getElementById('incTitle').value.trim());
    form.append('section_title', document.getElementById('incSection').value.trim());

    const res = await fetch('/api/query/include-file', {
      method: 'POST',
      body: form
    });
    const data = await res.json();
    logApi(`POST /qna/upload (${pickedFile.name})`, data, data.status);
    await loadOverview();
    return;
  }

  const payload = {
    plan_number: getPlan(),
    document_type: document.getElementById('incType').value,
    document_id: document.getElementById('incId').value.trim(),
    file_name: document.getElementById('incFile').value.trim(),
    document_title: document.getElementById('incTitle').value.trim(),
    section_title: document.getElementById('incSection').value.trim(),
    content: document.getElementById('incContent').value
  };
  const res = await fetch('/api/query/include', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  logApi('POST /qna/upload', data, data.status);
  await loadOverview();
}

async function fetchArtifact(artifact) {
  const plan = getPlan();
  document.getElementById('artifactStatus').textContent = `Fetching ${artifact}...`;
  const res = await fetch(`/api/dataextraction/getdata/${encodeURIComponent(plan)}/${encodeURIComponent(artifact)}`);
  const data = await res.json();
  document.getElementById('artifactStatus').textContent = `${data.url} (HTTP ${data.status})`;
  document.getElementById('artifactInspector').textContent = JSON.stringify(data.body, null, 2);
}

async function sendChat() {
  const question = document.getElementById('chatInput').value.trim();
  if (!question) return;
  const answerBox = document.getElementById('chatAnswerBox');
  answerBox.textContent = 'Querying CT1 /query-service/qna/chat ...';
  const payload = {
    question,
    planNumber: getPlan(),
    contextType: 'Preliminary Research Walkthrough',
    userDetails: {
      review_scope_instance_id: getScopeId(),
      user: 'demo-ui-user',
      remarks: 'Interactive CT1 Demo UI'
    }
  };
  const res = await fetch('/api/query/chat', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  logApi('POST /qna/chat', data, data.status);
  const body = data.body || {};
  answerBox.textContent = body.answer || JSON.stringify(body, null, 2);
}

window.addEventListener('DOMContentLoaded', loadOverview);
</script>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
async def index() -> HTMLResponse:
    return HTMLResponse(HTML_PAGE)


if __name__ == "__main__":
    port = int(os.getenv("DEMO_UI_PORT", "8090"))
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="info")
