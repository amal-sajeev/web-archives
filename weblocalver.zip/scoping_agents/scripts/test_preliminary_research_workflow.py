#!/usr/bin/env python3
"""
Staged End-to-End Verification Suite for the Preliminary Research workflow.

This single script validates the *entire* preliminary-research path across every
service that was touched in the audit, OR any subset of it. Run it once after each
module is pushed/deployed to confirm nothing is broken, then re-run the full suite
once everything is live.

Services / stages covered (dependency order):
    1. dataextraction   -> scoping-dataextraction-agent  (/data-extraction, status)
    2. lrrextraction    -> scoping-lrrextraction-agent    (/health)
    3. procedure        -> scoping-procedure-agent        (discovery walkthrough)
    4. summary          -> scoping-summary-agent          (run-analytics, research doc)
    5. query            -> query-service (qna)            (documents list/chat)
    6. master           -> scoping-master-agent gateway   (/trigger-scoping-master)

Two test MODES:
    direct   - Calls each agent's own HTTP endpoint directly (root_path prefixed).
               Best for validating a module in isolation right after you push it.
    gateway  - Drives the whole workflow through the scoping-master-agent gateway
               (POST /trigger-scoping-master with {action, planNumber, payload}).
               Best once the master agent + all sub-agents are live.

Usage examples (PowerShell):
    # Everything, direct, against CT1:
    python scripts/test_preliminary_research_workflow.py `
        --host https://ct1-cta.dbaware.dev.gcp.db.com --plan-number 20440 --stage all

    # Only the summary agent, right after you push it:
    python scripts/test_preliminary_research_workflow.py `
        --host https://ct1-cta.dbaware.dev.gcp.db.com --stage summary

    # Drive the full flow through the master gateway once everything is up:
    python scripts/test_preliminary_research_workflow.py `
        --host https://ct1-cta.dbaware.dev.gcp.db.com --mode gateway --stage all

    # Override a single service URL (e.g. local port-forward):
    python scripts/test_preliminary_research_workflow.py `
        --summary-url http://127.0.0.1:4000/scoping-summary-agent --stage summary

    # Trigger the expensive LLM generation calls too (data-extraction + analytics):
    python scripts/test_preliminary_research_workflow.py --host ... --run-generation

    #Also run direct PostgreSQL table assertions (when DB tunnel/proxy is reachable):
    python scripts/test_preliminary_research_workflow.py --host ... --verify-db `
        --db-host 127.0.0.1 --db-user scoping_admin --db-name dbaware --db-pass <pwd>
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

import httpx

try:
    import sqlalchemy
except ModuleNotFoundError:  # pragma: no cover - optional when only doing HTTP checks
    sqlalchemy = None  # type: ignore[assignment]

# ---------------------------------------------------------------------------
# Defaults (override via CLI flags or environment variables)
# ---------------------------------------------------------------------------
DEFAULT_HOST = os.getenv("CTA_HOST", "https://ct1-cta.dbaware.dev.gcp.db.com")
DEFAULT_PLAN_NUMBER = os.getenv("TEST_PLAN_NUMBER", "20440")
DEFAULT_PLAN_ITEM_NUMBER = os.getenv("TEST_PLAN_ITEM_NUMBER", DEFAULT_PLAN_NUMBER)
DEFAULT_SCOPE_INSTANCE_ID = os.getenv("TEST_SCOPE_INSTANCE_ID", "1")
DEFAULT_TIMEOUT = float(os.getenv("TEST_TIMEOUT_SECONDS", "120"))
# Generation calls (data-extraction / run-analytics) can take minutes.
GENERATION_TIMEOUT = float(os.getenv("TEST_GENERATION_TIMEOUT_SECONDS", "900"))

SCHEMA_NAME = "dbaware_scoping"
VALID_SECTION_KEYS = ("past_review", "policy_regulation", "broad_scope")
EXTRACTION_ARTIFACTS = (
    "current_details",
    "lrr",
    "historical_plan_details",
    "policy",
    "alc_nlac",
    "findings_details",
    "control_details",
    "risk_driver_details",
    "group_audit",
)
SCOPING_DOC_TYPES = (
    "policy",
    "kod",
    "procedure",
    "gfms",
    "historical_scoping_document",
    "lrr",
)

# External ingress path prefixes for each service (relative to --host).
SERVICE_PATHS = {
    "dataextraction": "/scoping-dataextraction-agent",
    "lrrextraction": "/scoping-lrrextraction-agent",
    "procedure": "/scoping-procedure-agent",
    "summary": "/scoping-summary-agent",
    "query": "/query-service",
    "master": "/scoping-master-agent",
}

SCRIPT_DIR = Path(__file__).resolve().parent
LOG_FILE = SCRIPT_DIR / "preliminary_research_test.log"
REPORT_FILE = SCRIPT_DIR / "preliminary_research_test_report.json"

STAGE_ORDER = [
    "dataextraction",
    "lrrextraction",
    "procedure",
    "summary",
    "query",
    "master",
]

# ---------------------------------------------------------------------------
# Result bookkeeping
# ---------------------------------------------------------------------------
_log_lines: list[str] = []


def log(msg: str) -> None:
    stamp = datetime.now(timezone.utc).strftime("%H:%M:%S")
    line = f"[{stamp}] {msg}"
    print(line, flush=True)
    _log_lines.append(line)


@dataclass
class TestResult:
    stage: str
    name: str
    method: str
    url: str
    status_code: Optional[int]
    passed: bool
    duration_ms: float
    expected: list[int] = field(default_factory=list)
    preview: str = ""
    error: Optional[str] = None
    skipped: bool = False


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------
class Suite:
    def __init__(self, client: httpx.Client, plan_number: str, plan_item: str,
                 run_generation: bool, scope_instance_id: str = DEFAULT_SCOPE_INSTANCE_ID):
        self.client = client
        self.plan_number = plan_number
        self.plan_item = plan_item
        self.run_generation = run_generation
        self.scope_instance_id = str(scope_instance_id)
        self.results: list[TestResult] = []
        # Shared workflow state captured across calls.
        self.session_id: Optional[str] = None
        self.research_report: Optional[dict] = None
        self.discovery_walkthrough: Optional[dict] = None

    def call(
        self,
        stage: str,
        name: str,
        method: str,
        url: str,
        *,
        json_body: Any = None,
        expected: tuple[int, ...] = (200,),
        timeout: Optional[float] = None,
        validator: Optional[Callable[[httpx.Response], Optional[str]]] = None,
        on_success: Optional[Callable[[httpx.Response], None]] = None,
    ) -> Optional[httpx.Response]:
        start = time.perf_counter()
        try:
            resp = self.client.request(
                method, url, json=json_body,
                timeout=timeout or self.client.timeout,
            )
            dur = (time.perf_counter() - start) * 1000
            status_ok = resp.status_code in expected
            val_error: Optional[str] = None
            if status_ok and validator is not None:
                try:
                    val_error = validator(resp)
                except Exception as exc:
                    val_error = f"validator raised {type(exc).__name__}: {exc}"
            passed = status_ok and val_error is None
            preview = resp.text[:400].replace("\n", " ")
            self.results.append(TestResult(
                stage=stage, name=name, method=method, url=url,
                status_code=resp.status_code, passed=passed, duration_ms=round(dur, 1),
                expected=list(expected), preview=preview, error=val_error,
            ))
            flag = "PASS" if passed else "FAIL"
            suffix = f" [{val_error}]" if val_error else ""
            log(f"  [{flag}] {name} -> {resp.status_code} ({dur:.0f}ms){suffix}")
            if passed and on_success is not None:
                try:
                    on_success(resp)
                except Exception as exc:  # pragma: no cover - defensive
                    log(f"         (post-process warning: {exc})")
            return resp
        except Exception as exc:
            dur = (time.perf_counter() - start) * 1000
            self.results.append(TestResult(
                stage=stage, name=name, method=method, url=url,
                status_code=None, passed=False, duration_ms=round(dur, 1),
                expected=list(expected), error=f"{type(exc).__name__}: {exc}",
            ))
            log(f"  [FAIL] {name} -> ERROR {type(exc).__name__}: {exc}")
            return None

    def check(self, stage: str, name: str, passed: bool,
              preview: str = "", error: Optional[str] = None) -> None:
        """Record a pure assertion / DB check that is not an HTTP request."""
        self.results.append(TestResult(
            stage=stage, name=name, method="ASSERT", url="",
            status_code=200 if passed else 500, passed=passed, duration_ms=0.0,
            preview=preview[:400], error=error,
        ))
        flag = "PASS" if passed else "FAIL"
        suffix = f" ({preview})" if preview else ""
        err_suffix = f" [{error}]" if error else ""
        log(f"  [{flag}] {name}{suffix}{err_suffix}")

    def skip(self, stage: str, name: str, reason: str) -> None:
        self.results.append(TestResult(
            stage=stage, name=name, method="-", url="", status_code=None,
            passed=True, duration_ms=0.0, skipped=True, preview=reason,
        ))
        log(f"  [SKIP] {name} ({reason})")

    @property
    def user_details(self) -> dict:
        return {
            "review_scope_instance_id": self.scope_instance_id,
            "user": "workflow-test",
            "remarks": "automated preliminary-research verification",
        }


# ===========================================================================
# DIRECT-MODE stages (call each agent's own endpoint)
# ===========================================================================
def stage_health_check(suite: Suite, stage: str, base: str) -> None:
    """Generic health probe used by every service that exposes /health."""
    suite.call(stage, f"{stage}: health", "GET", f"{base}/health",
               expected=(200,), timeout=30)


def direct_dataextraction(suite: Suite, base: str) -> None:
    stage = "dataextraction"
    log(f"== {stage} (direct) @ {base} ==")
    stage_health_check(suite, stage, base)

    # 1. Plan availability: validate JSON shape and see which artifacts exist.
    available_artifacts: list[str] = []

    def _validate_avail(resp: httpx.Response) -> Optional[str]:
        if resp.status_code != 200:
            return None
        data = resp.json()
        if not isinstance(data, dict) or "available" not in data:
            return "expected {'plan_number', 'available', ...} dict"
        return None

    def _capture_avail(resp: httpx.Response) -> None:
        if resp.status_code != 200:
            return
        data = resp.json()
        artifacts_map = data.get("artifacts") if isinstance(data, dict) else None
        if isinstance(artifacts_map, dict):
            available_artifacts.extend(k for k, v in artifacts_map.items() if v)

    suite.call(stage, "dataextraction: plan availability", "GET",
               f"{base}/getdata/{suite.plan_number}/availability",
               expected=(200, 404), timeout=60,
               validator=_validate_avail, on_success=_capture_avail)

    # 2. Read-back of stored extraction artifacts (proves GCS/DB read path + soft-exclusion filtering).
    probe_artifacts = ("current_details", "policy", "historical_plan_details", "lrr", "findings_details")
    for art in probe_artifacts:
        def _val_art(resp: httpx.Response, a: str = art) -> Optional[str]:
            if resp.status_code == 404:
                return None
            body = resp.json()
            if body is None:
                return f"artifact '{a}' returned null JSON"
            return None
        suite.call(stage, f"dataextraction: read artifact '{art}'", "GET",
                   f"{base}/getdata/{suite.plan_number}/{art}",
                   expected=(200, 404), timeout=60, validator=_val_art)

    if suite.run_generation:
        def _capture(resp: httpx.Response) -> None:
            data = resp.json()
            suite.session_id = data.get("session_id") or data.get("sessionId")
        suite.call(
            stage, "dataextraction: trigger /data-extraction (writes review_data_extraction)", "POST",
            f"{base}/data-extraction",
            json_body={"planNumber": suite.plan_number, "userDetails": suite.user_details},
            expected=(200, 202), timeout=GENERATION_TIMEOUT, on_success=_capture,
        )
        if suite.session_id:
            status_url = f"{base}/data-extraction/{suite.session_id}/status"
            poll_deadline = time.perf_counter() + GENERATION_TIMEOUT
            final_status: Optional[dict] = None
            while time.perf_counter() < poll_deadline:
                r = suite.client.get(status_url, timeout=60)
                if r.status_code == 200:
                    final_status = r.json()
                    st = str(final_status.get("status") or "").upper()
                    log(f"         ... polling session {suite.session_id[:8]} stage={final_status.get('stage_name')} status={st}")
                    if st in ("COMPLETED", "SUCCESS", "FAILED", "ERROR"):
                        break
                time.sleep(5)
            passed_poll = bool(
                final_status
                and str(final_status.get("status") or "").upper() in ("COMPLETED", "SUCCESS")
                and not final_status.get("error")
            )
            suite.check(
                stage,
                "dataextraction: background pipeline completed (DB + GCS persisted)",
                passed_poll,
                preview=json.dumps(final_status or {}),
                error=None if passed_poll else f"pipeline ended in {final_status}",
            )
    else:
        suite.skip(stage, "dataextraction: trigger /data-extraction",
                   "generation disabled (use --run-generation)")


def direct_lrrextraction(suite: Suite, base: str) -> None:
    stage = "lrrextraction"
    log(f"== {stage} (direct) @ {base} ==")
    suite.call(stage, "lrrextraction: openapi", "GET", f"{base}/openapi.json",
               expected=(200,), timeout=30)
    suite.call(stage, "lrrextraction: system mode", "GET", f"{base}/lrr/system/mode",
               expected=(200,), timeout=30,
               validator=lambda r: None if "mode" in (r.json() or {}) else "missing 'mode' key")
    suite.call(stage, "lrrextraction: list runs", "GET", f"{base}/lrr/runs",
               expected=(200,), timeout=30)


def direct_procedure(suite: Suite, base: str) -> None:
    stage = "procedure"
    log(f"== {stage} (direct) @ {base} ==")
    stage_health_check(suite, stage, base)

    # 1. Read existing discovery walkthrough.
    def _capture_dw(resp: httpx.Response) -> None:
        if resp.status_code == 200:
            suite.discovery_walkthrough = resp.json()

    suite.call(stage, "procedure: get discovery walkthrough (read)", "POST",
               f"{base}/get-discovery-walkthrough",
               json_body={"planNumber": suite.plan_number, "userDetails": suite.user_details},
               expected=(200, 404), timeout=60, on_success=_capture_dw)

    # 2. Non-destructive round-trip PUT -> POST to verify DB write (`update_review_research_recommendation`
    #    on `dbaware_scoping.review_research_recommendation` with report_type='DISCOVERY_WALKTHROUGH')
    #    and GCS read-back.
    if isinstance(suite.discovery_walkthrough, dict) and suite.discovery_walkthrough.get("sections"):
        dw = suite.discovery_walkthrough
        put_body = {
            "planNumber": suite.plan_number,
            "userDetails": suite.user_details,
            "report_title": dw.get("report_title") or "Discovery Walkthrough Report",
            "sections": dw["sections"],
        }
        suite.call(
            stage,
            "procedure: update discovery walkthrough (round-trip write -> review_research_recommendation)",
            "PUT",
            f"{base}/update-discovery-walkthrough",
            json_body=put_body,
            expected=(200,),
            timeout=60,
            validator=lambda r: (
                None if isinstance(r.json(), dict) and r.json().get("sections") == dw["sections"]
                else "round-trip sections mismatch"
            ),
        )
    else:
        suite.skip(stage, "procedure: update discovery walkthrough round-trip",
                   "no existing discovery walkthrough for plan")


def direct_summary(suite: Suite, base: str) -> None:
    stage = "summary"
    log(f"== {stage} (direct) @ {base} ==")
    stage_health_check(suite, stage, base)

    # 1. Read preliminary research document.
    def _val_pr(resp: httpx.Response) -> Optional[str]:
        if resp.status_code != 200:
            return None
        body = resp.json()
        if not isinstance(body, dict) or not isinstance(body.get("analysis_report"), dict):
            return "expected {'plan_number', 'analysis_report': {...}}"
        return None

    def _capture(resp: httpx.Response) -> None:
        if resp.status_code == 200:
            suite.research_report = resp.json()

    suite.call(stage, "summary: get preliminary research document (read)", "POST",
               f"{base}/get-preliminary-research-document",
               json_body={"planNumber": suite.plan_number},
               expected=(200, 404), timeout=90,
               validator=_val_pr, on_success=_capture)

    # 2. Non-destructive round-trip edit -> read to verify DB write (`update_review_research_recommendation`
    #    on `dbaware_scoping.review_research_recommendation` with VARCHAR(100) review_scope_instance_id)
    #    and GCS section persistence.
    if isinstance(suite.research_report, dict) and isinstance(suite.research_report.get("analysis_report"), dict):
        report_dict = suite.research_report["analysis_report"]
        suite.call(
            stage,
            "summary: edit preliminary research (round-trip write -> review_research_recommendation)",
            "POST",
            f"{base}/edit-preliminary-research-document",
            json_body={
                "planNumber": suite.plan_number,
                "userDetails": suite.user_details,
                "analysis_report": report_dict,
            },
            expected=(200,),
            timeout=90,
            validator=lambda r: (
                None if isinstance(r.json(), dict) and isinstance(r.json().get("analysis_report"), dict)
                else "edit response missing analysis_report"
            ),
        )
    else:
        suite.skip(stage, "summary: edit preliminary research round-trip",
                   "no existing preliminary research doc for plan")

    # 3. Historical plan item listing (validates DB `review_data_extraction` soft-exclusion read + GCS sync).
    def _val_hist(resp: httpx.Response) -> Optional[str]:
        if resp.status_code != 200:
            return None
        items = resp.json()
        if not isinstance(items, list):
            return "expected list of HistoricalPlanItem"
        for it in items:
            if not isinstance(it, dict) or "plan_item_number" not in it:
                return f"invalid HistoricalPlanItem element: {it!r}"
        return None

    suite.call(stage, "summary: list historical documents (reads review_data_extraction metadata)", "POST",
               f"{base}/list-documents",
               json_body={"planNumber": suite.plan_number},
               expected=(200, 404), timeout=60, validator=_val_hist)

    # 4. Contract validation: invalid section key MUST be rejected with 422 (proves SectionKey Literal fix).
    suite.call(
        stage, "summary: reject invalid section key 'findings_analysis' (422)", "POST",
        f"{base}/run-analytics-agent",
        json_body={
            "planNumber": suite.plan_number,
            "userDetails": suite.user_details,
            "sections": ["findings_analysis"],
        },
        expected=(422,), timeout=30,
    )

    if suite.run_generation:
        # Full regeneration of all 3 valid sections (exercises LLM + judge + DB INSERT into
        # `dbaware_scoping.review_research_recommendation`).
        suite.call(
            stage, "summary: run-analytics-agent (all 3 valid sections -> DB insert)", "POST",
            f"{base}/run-analytics-agent",
            json_body={
                "planNumber": suite.plan_number,
                "userDetails": suite.user_details,
                "sections": list(VALID_SECTION_KEYS),
            },
            expected=(200, 404), timeout=GENERATION_TIMEOUT,
        )
    else:
        suite.skip(stage, "summary: run-analytics-agent",
                   "generation disabled (use --run-generation)")


def direct_query(suite: Suite, base: str) -> None:
    stage = "query"
    log(f"== {stage} (direct) @ {base} ==")
    # Query service exposes /openapi.json + /docs at service root; qna routes under /qna.
    suite.call(stage, "query: openapi", "GET", f"{base}/openapi.json",
               expected=(200,), timeout=30)
    qna = f"{base}/qna"

    # 1. List all documents (reads `review_data_extraction` metadata with GCS fallback).
    def _val_list_all(resp: httpx.Response) -> Optional[str]:
        if resp.status_code != 200:
            return None
        data = resp.json()
        groups = data.get("document_groups") if isinstance(data, dict) else None
        if not isinstance(groups, list):
            return "expected 'document_groups' list"
        for g in groups:
            for d in g.get("documents", []):
                if "status" not in d or "excluded" not in d:
                    # Live pre-push deployment may not yet include status/excluded on every item;
                    # note it in preview but only enforce dict structure here.
                    break
        return None

    suite.call(stage, "query: list-all documents (reads review_data_extraction + GCS)", "POST",
               f"{qna}/documents/list-all",
               json_body={"plan_number": suite.plan_number},
               expected=(200, 404), timeout=60, validator=_val_list_all)

    # 2. Per-source listing including LRR & historical (validates new source mappings in database_connector).
    for doc_type in ("policy", "gfms", "historical_scoping_document", "lrr"):
        suite.call(
            stage, f"query: list documents by type '{doc_type}'", "POST",
            f"{qna}/documents/list",
            json_body={"plan_number": suite.plan_number, "document_type": doc_type},
            expected=(200, 400, 404), timeout=60,
        )

    # 3. Safe synthetic round-trip: INCLUDE -> LIST -> EXCLUDE -> LIST
    #    Validates:
    #      - DB writes to `dbaware_scoping.review_data_extraction` (`mutate_data_extraction_metadata`)
    #      - GCS registry writes (`relevant_policy.json` + part file)
    #      - `affected_sections` calculation (`['policy_regulation', 'broad_scope']`)
    #      - Soft-exclusion (`excluded=True`, `status='excluded'`) instead of hard delete
    scratch_id = f"99988{suite.plan_number}"
    scratch_file = f"_workflow_probe_{suite.plan_number}.json"
    scratch_title = f"Workflow DB Probe Policy {suite.plan_number}"

    def _val_inc_exec(resp: httpx.Response) -> Optional[str]:
        body = resp.json() if resp.content else {}
        if not isinstance(body, dict):
            return "expected dict response"
        if body.get("status") != "success":
            return f"expected status='success', got {body.get('status')!r} ({body.get('message')})"
        aff = body.get("affected_sections")
        if aff is not None and (not isinstance(aff, list) or not set(aff).issubset(VALID_SECTION_KEYS)):
            return f"invalid affected_sections={aff!r}"
        return None

    inc_resp = suite.call(
        stage,
        "query: inclusion execute (writes review_data_extraction + GCS registry)",
        "POST",
        f"{qna}/documents/inclusion/execute",
        json_body={
            "plan_number": suite.plan_number,
            "actions": [
                {
                    "action": "include",
                    "document_type": "policy",
                    "title": scratch_title,
                    "filename": scratch_file,
                    "document_id": scratch_id,
                    "section_id": "1.1",
                    "section_title": "Probe Section 1.1",
                    "content": "Synthetic probe content to verify DB + GCS inclusion/exclusion.",
                    "scope": "all_related",
                }
            ],
            "approved_by": "workflow-test",
        },
        expected=(200,),
        timeout=60,
        validator=_val_inc_exec,
    )

    if inc_resp is not None and inc_resp.status_code == 200:
        # Verify the newly included probe document is visible and active when read back.
        def _val_probe_active(resp: httpx.Response) -> Optional[str]:
            docs = (resp.json() or {}).get("documents") or []
            matches = [
                d for d in docs
                if scratch_title.lower() in str(d.get("document_title") or "").lower()
                or str(d.get("document_id")) == scratch_id
                or str(d.get("file_name")) == scratch_file
            ]
            if not matches:
                return f"included probe doc '{scratch_title}' not returned by /documents/list"
            if matches[0].get("excluded") is True:
                return "newly included probe doc has excluded=True"
            return None

        suite.call(
            stage,
            "query: read-back after inclusion (confirms active in DB/GCS)",
            "POST",
            f"{qna}/documents/list",
            json_body={"plan_number": suite.plan_number, "document_type": "policy"},
            expected=(200,),
            timeout=60,
            validator=_val_probe_active,
        )

        # Now soft-exclude the synthetic probe document to leave the plan clean and verify exclusion DB write.
        def _val_exc_exec(resp: httpx.Response) -> Optional[str]:
            body = resp.json() if resp.content else {}
            if not isinstance(body, dict) or body.get("status") != "success":
                return f"expected status='success', got {body.get('status')!r}"
            aff = body.get("affected_sections")
            if aff is not None and (not isinstance(aff, list) or not set(aff).issubset(VALID_SECTION_KEYS)):
                return f"invalid affected_sections={aff!r}"
            return None

        suite.call(
            stage,
            "query: exclusion execute (soft-excludes in review_data_extraction + GCS)",
            "POST",
            f"{qna}/documents/exclusion/execute",
            json_body={
                "plan_number": suite.plan_number,
                "actions": [
                    {
                        "action": "exclude",
                        "document_type": "policy",
                        "title": scratch_title,
                        "filename": scratch_file,
                        "document_id": scratch_id,
                        "scope": "all_related",
                    }
                ],
                "approved_by": "workflow-test",
            },
            expected=(200,),
            timeout=60,
            validator=_val_exc_exec,
        )


# ===========================================================================
# GATEWAY-MODE stages (drive everything through scoping-master-agent)
# ===========================================================================
def _gateway_call(suite: Suite, base: str, name: str, action: str,
                  payload: dict, *, plan_number: Optional[str] = None,
                  expected: tuple[int, ...] = (200,),
                  timeout: Optional[float] = None) -> Optional[httpx.Response]:
    body = {
        "action": action,
        "planNumber": plan_number if plan_number is not None else suite.plan_number,
        "payload": payload,
    }
    return suite.call("master", name, "POST", f"{base}/trigger-scoping-master",
                      json_body=body, expected=expected, timeout=timeout)


def gateway_workflow(suite: Suite, base: str) -> None:
    stage = "master"
    log(f"== {stage} gateway @ {base} ==")
    stage_health_check(suite, stage, base)

    # Read-only gateway routes first.
    _gateway_call(suite, base, "gateway: GET_PRELIMINARY_RESEARCH_DOCUMENT",
                  "GET_PRELIMINARY_RESEARCH_DOCUMENT", {},
                  expected=(200, 404, 422, 500), timeout=90)
    _gateway_call(suite, base, "gateway: LIST_HISTORICAL_DOCUMENT",
                  "LIST_HISTORICAL_DOCUMENT", {},
                  expected=(200, 404, 422, 500), timeout=60)
    _gateway_call(suite, base, "gateway: QNA_LIST_DOCUMENTS",
                  "QNA_LIST_DOCUMENTS", {},
                  expected=(200, 404, 422, 500), timeout=60)

    if suite.run_generation:
        _gateway_call(
            suite, base, "gateway: DATA_EXTRACTION",
            "DATA_EXTRACTION",
            {"userDetails": suite.user_details},
            expected=(200, 202, 404, 500), timeout=GENERATION_TIMEOUT,
        )
        _gateway_call(
            suite, base, "gateway: RUN_ANALYTICS",
            "RUN_ANALYTICS",
            {
                "userDetails": suite.user_details,
                "sections": list(VALID_SECTION_KEYS),
            },
            expected=(200, 404, 500), timeout=GENERATION_TIMEOUT,
        )
    else:
        suite.skip(stage, "gateway: DATA_EXTRACTION / RUN_ANALYTICS",
                   "generation disabled (use --run-generation)")


# ===========================================================================
# DIRECT POSTGRESQL TABLE VERIFICATION (optional: --verify-db)
# ===========================================================================
def verify_database_tables(suite: Suite, args: argparse.Namespace) -> None:
    """
    Directly query `dbaware_scoping` PostgreSQL tables to verify the schema &
    rows written/read by the agents:
      - `dbaware_scoping.review_scope` (VARCHAR(100) `review_scope_instance_id`)
      - `dbaware_scoping.review_data_extraction` (`data_source`, JSONB `metadata` with
        `documents`/`sections`/`status`/`excluded`)
      - `dbaware_scoping.review_research_recommendation` (`report_type` in
        `PRELIMINARY_RESEARCH`, `DISCOVERY_WALKTHROUGH`, `SCOPE_RECOMMENDATION`,
        `SCOPING_DOCUMENT`; VARCHAR(100) `review_scope_instance_id`)
      - `dbaware_scoping.dbaware_review_documents` (`document_id`, VARCHAR(100)
        `review_scope_instance_id`)
    """
    stage = "db"
    db_host = args.db_host or os.getenv("db_host") or os.getenv("DB_HOST")
    db_user = args.db_user or os.getenv("db_user") or os.getenv("DB_USER")
    db_pass = (
        args.db_pass
        or os.getenv("scoping_db_pass")
        or os.getenv("SCOPING_DB_PASS")
        or os.getenv("db_password")
    )
    db_name = args.db_name or os.getenv("db_name") or os.getenv("DB_NAME")
    db_port = int(args.db_port or os.getenv("db_port") or os.getenv("DB_PORT") or "5432")

    if not args.verify_db and not all([db_host, db_user, db_pass, db_name]):
        suite.skip(
            stage,
            "db: direct PostgreSQL table checks",
            "pass --verify-db with --db-host/--db-user/--db-pass/--db-name (or env vars) when Cloud SQL proxy is open",
        )
        return

    log(f"== {stage} (direct PostgreSQL) @ {db_host}:{db_port}/{db_name} ==")
    if sqlalchemy is None:
        suite.check(stage, "db: sqlalchemy import", False, error="sqlalchemy not installed")
        return
    if not all([db_host, db_user, db_pass, db_name]):
        suite.check(
            stage, "db: credentials configured", False,
            error="missing one of db_host / db_user / db_pass / db_name",
        )
        return

    try:
        engine = sqlalchemy.create_engine(
            sqlalchemy.engine.url.URL.create(
                drivername="postgresql+pg8000",
                username=db_user,
                password=db_pass,
                host=db_host,
                port=db_port,
                database=db_name,
            ),
            pool_pre_ping=True,
        )
        with engine.connect() as conn:
            conn.execute(sqlalchemy.text("SELECT 1"))
            suite.check(stage, "db: connectivity (SELECT 1)", True, f"{db_host}:{db_port}/{db_name}")

            # 1. Verify VARCHAR(100) column types on review_scope_instance_id across all tables.
            col_rows = conn.execute(
                sqlalchemy.text(
                    """
                    SELECT table_name, data_type, character_maximum_length
                    FROM information_schema.columns
                    WHERE table_schema = :schema
                      AND column_name = 'review_scope_instance_id'
                    ORDER BY table_name
                    """
                ),
                {"schema": SCHEMA_NAME},
            ).fetchall()
            col_summary = {r[0]: f"{r[1]}({r[2]})" for r in col_rows}
            non_str = [t for t, dt in col_summary.items() if "char" not in dt.lower() and "text" not in dt.lower()]
            suite.check(
                stage,
                "db: review_scope_instance_id column type is VARCHAR across tables",
                bool(col_summary) and not non_str,
                preview=json.dumps(col_summary),
                error=f"non-string columns: {non_str}" if non_str else None,
            )

            # Resolve candidate instance IDs for the plan.
            candidates = [suite.scope_instance_id, str(suite.plan_number)]
            try:
                rs_rows = conn.execute(
                    sqlalchemy.text(
                        f"""
                        SELECT review_scope_instance_id
                        FROM {SCHEMA_NAME}.review_scope
                        WHERE CAST(review_scope_instance_id AS VARCHAR) IN (:p1, :p2)
                        LIMIT 10
                        """
                    ),
                    {"p1": str(suite.plan_number), "p2": suite.scope_instance_id},
                ).fetchall()
                for r in rs_rows:
                    if r[0] and str(r[0]) not in candidates:
                        candidates.append(str(r[0]))
            except Exception as exc:
                log(f"         (review_scope lookup note: {exc})")

            # 2. Check `review_data_extraction` rows written by dataextraction / lrrextraction / query-service.
            de_rows = conn.execute(
                sqlalchemy.text(
                    f"""
                    SELECT review_scope_dataext_id, review_scope_instance_id, data_source,
                           metadata, created_by, updated_by
                    FROM {SCHEMA_NAME}.review_data_extraction
                    WHERE CAST(review_scope_instance_id AS VARCHAR) IN (:c1, :c2)
                    ORDER BY review_scope_dataext_id DESC
                    LIMIT 30
                    """
                ),
                {"c1": candidates[0], "c2": candidates[-1]},
            ).fetchall()
            sources_found = sorted({str(r[2]) for r in de_rows if r[2]})
            suite.check(
                stage,
                "db: review_data_extraction rows readable",
                True,
                preview=f"rows={len(de_rows)} data_sources={sources_found}",
            )
            for r in de_rows[:5]:
                meta = r[3] if isinstance(r[3], (dict, list)) else (json.loads(r[3]) if isinstance(r[3], str) else None)
                suite.check(
                    stage,
                    f"db: review_data_extraction[{r[2]}] JSONB metadata valid",
                    isinstance(meta, (dict, list)),
                    preview=f"id={r[0]} instance={r[1]} source={r[2]} type={type(meta).__name__}",
                )

            # 3. Check `review_research_recommendation` rows written by summary-agent & procedure-agent.
            rr_rows = conn.execute(
                sqlalchemy.text(
                    f"""
                    SELECT review_rr_id, review_scope_instance_id, report_type,
                           metadata, created_by, updated_by
                    FROM {SCHEMA_NAME}.review_research_recommendation
                    WHERE CAST(review_scope_instance_id AS VARCHAR) IN (:c1, :c2)
                    ORDER BY review_rr_id DESC
                    LIMIT 20
                    """
                ),
                {"c1": candidates[0], "c2": candidates[-1]},
            ).fetchall()
            report_types = sorted({str(r[2]) for r in rr_rows if r[2]})
            suite.check(
                stage,
                "db: review_research_recommendation rows readable",
                True,
                preview=f"rows={len(rr_rows)} report_types={report_types}",
            )
            for r in rr_rows[:5]:
                meta = r[3] if isinstance(r[3], dict) else (json.loads(r[3]) if isinstance(r[3], str) else None)
                suite.check(
                    stage,
                    f"db: review_research_recommendation[{r[2]}] JSONB metadata valid",
                    isinstance(meta, dict),
                    preview=f"rr_id={r[0]} instance={r[1]} report_type={r[2]}",
                )
    except Exception as exc:
        suite.check(stage, "db: PostgreSQL table verification", False,
                    error=f"{type(exc).__name__}: {exc}")


# ===========================================================================
# Runner
# ===========================================================================
DIRECT_DISPATCH: dict[str, Callable[[Suite, str], None]] = {
    "dataextraction": direct_dataextraction,
    "lrrextraction": direct_lrrextraction,
    "procedure": direct_procedure,
    "summary": direct_summary,
    "query": direct_query,
}


def resolve_base_urls(args: argparse.Namespace) -> dict[str, str]:
    host = args.host.rstrip("/")
    overrides = {
        "dataextraction": args.dataextraction_url,
        "lrrextraction": args.lrrextraction_url,
        "procedure": args.procedure_url,
        "summary": args.summary_url,
        "query": args.query_url,
        "master": args.master_url,
    }
    bases = {}
    for svc, path in SERVICE_PATHS.items():
        bases[svc] = (overrides[svc] or f"{host}{path}").rstrip("/")
    return bases


def select_stages(requested: str) -> list[str]:
    if requested == "all":
        return list(STAGE_ORDER)
    stages = [s.strip() for s in requested.split(",") if s.strip()]
    unknown = [s for s in stages if s not in STAGE_ORDER]
    if unknown:
        raise SystemExit(f"Unknown stage(s): {unknown}. Valid: {STAGE_ORDER + ['all']}")
    return stages


def write_reports(suite: Suite, meta: dict) -> None:
    passed = sum(1 for r in suite.results if r.passed and not r.skipped)
    skipped = sum(1 for r in suite.results if r.skipped)
    failed = sum(1 for r in suite.results if not r.passed)
    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "meta": meta,
        "totals": {
            "total": len(suite.results),
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
        },
        "results": [asdict(r) for r in suite.results],
    }
    REPORT_FILE.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    LOG_FILE.write_text("\n".join(_log_lines) + "\n", encoding="utf-8")
    log("")
    log(f"RESULT: {passed} passed, {failed} failed, {skipped} skipped "
        f"({len(suite.results)} total)")
    log(f"Report: {REPORT_FILE}")
    log(f"Log:    {LOG_FILE}")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--host", default=DEFAULT_HOST,
                        help="Base host for all services (default: %(default)s)")
    parser.add_argument("--mode", choices=("direct", "gateway"), default="direct",
                        help="direct = call each agent; gateway = via master agent")
    parser.add_argument("--stage", default="all",
                        help="Comma list of stages or 'all'. "
                             f"Valid: {','.join(STAGE_ORDER)}")
    parser.add_argument("--plan-number", default=DEFAULT_PLAN_NUMBER)
    parser.add_argument("--plan-item-number", default=DEFAULT_PLAN_ITEM_NUMBER)
    parser.add_argument("--scope-instance-id", default=DEFAULT_SCOPE_INSTANCE_ID,
                        help="review_scope_instance_id (VARCHAR(100)) written to DB tables (default: %(default)s)")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    parser.add_argument("--run-generation", action="store_true",
                        help="Also trigger expensive LLM calls (data-extraction, "
                             "run-analytics). Off by default to keep runs fast.")
    parser.add_argument("--verify-ssl", action="store_true",
                        help="Enable TLS verification (off by default for internal certs)")
    # Optional direct PostgreSQL verification flags.
    parser.add_argument("--verify-db", action="store_true",
                        help="Run direct SQL assertions against dbaware_scoping tables")
    parser.add_argument("--db-host")
    parser.add_argument("--db-port")
    parser.add_argument("--db-user")
    parser.add_argument("--db-pass")
    parser.add_argument("--db-name")
    # Per-service URL overrides.
    parser.add_argument("--dataextraction-url")
    parser.add_argument("--lrrextraction-url")
    parser.add_argument("--procedure-url")
    parser.add_argument("--summary-url")
    parser.add_argument("--query-url")
    parser.add_argument("--master-url")
    args = parser.parse_args(argv)

    bases = resolve_base_urls(args)
    stages = select_stages(args.stage)

    log("=" * 72)
    log("Preliminary Research Workflow Verification")
    log(f"  mode={args.mode}  stages={stages}  plan={args.plan_number}  "
        f"scope_instance_id={args.scope_instance_id}  "
        f"generation={'on' if args.run_generation else 'off'}")
    log("=" * 72)

    client = httpx.Client(
        verify=args.verify_ssl,
        follow_redirects=True,
        timeout=httpx.Timeout(args.timeout),
        trust_env=True,
        headers={"Accept": "application/json"},
    )
    suite = Suite(
        client,
        args.plan_number,
        args.plan_item_number,
        args.run_generation,
        scope_instance_id=args.scope_instance_id,
    )

    try:
        if args.mode == "gateway":
            # Everything is driven through the master gateway.
            gateway_workflow(suite, bases["master"])
        else:
            for stage in stages:
                if stage == "master":
                    # In direct mode, probe the gateway health + read-only routes.
                    gateway_workflow(suite, bases["master"])
                else:
                    DIRECT_DISPATCH[stage](suite, bases[stage])
        verify_database_tables(suite, args)
    finally:
        client.close()

    write_reports(suite, {
        "mode": args.mode,
        "stages": stages,
        "plan_number": args.plan_number,
        "base_urls": bases,
        "run_generation": args.run_generation,
    })

    failed = sum(1 for r in suite.results if not r.passed)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
