from model.gateway_request import GatewayRequest, ScopingAction
from model.orchestration import ActionDefinition


class RequestValidator:
    def validate(self, request: GatewayRequest, action_definition: ActionDefinition) -> None:
        missing_fields = [
            field_name
            for field_name in action_definition.required_payload_fields
            if field_name not in request.payload or request.payload[field_name] in (None, "")
        ]
        if missing_fields:
            raise ValueError(f"Missing required payload field(s): {', '.join(missing_fields)}")

        if request.action == ScopingAction.QNA_CHAT:
            self._validate_qna_chat_request(request)

        if request.action == ScopingAction.QNA_PLAN_DOCUMENT_ACTIONS:
            self._validate_qna_plan_document_actions_request(request)

        if request.action == ScopingAction.QNA_CLOSE_SESSION:
            self._validate_qna_close_session_request(request)

        if request.action.value.startswith("UPDATE_") and not request.payload:
            raise ValueError("Update actions require a non-empty payload.")

        if request.action.value.startswith("GET_CITATION_DOCUMENT"):
            self._validate_citation_request(request)

    def _validate_qna_chat_request(self, request: GatewayRequest) -> None:
        question = request.payload.get("question")
        user_text = request.payload.get("userText")
        user_text_snake = request.payload.get("user_text")
        if all(val in (None, "") for val in (question, user_text, user_text_snake)):
            raise ValueError("Missing required payload field(s): question or userText")

    def _validate_qna_plan_document_actions_request(self, request: GatewayRequest) -> None:
        user_text = request.payload.get("user_text")
        actions = request.payload.get("actions")
        extracted_actions = request.payload.get("extracted_actions")
        if (
            user_text in (None, "")
            and not actions
            and not extracted_actions
        ):
            raise ValueError("Missing required payload field(s): user_text or actions")

    def _validate_qna_close_session_request(self, request: GatewayRequest) -> None:
        session_id = request.payload.get("session_id")
        plan_number = request.planNumber.strip() if request.planNumber else ""
        if session_id in (None, "") and not plan_number:
            raise ValueError("Missing required payload field(s): session_id")

    def _validate_citation_request(self, request: GatewayRequest) -> None:
        chunk_id = request.payload.get("chunk_id")
        document_uri = request.payload.get("document_uri")

        if not chunk_id and not document_uri:
            raise ValueError("Either payload.chunk_id or payload.document_uri is required.")

        if chunk_id and not request.planNumber:
            raise ValueError("planNumber is required when payload.chunk_id is provided.")