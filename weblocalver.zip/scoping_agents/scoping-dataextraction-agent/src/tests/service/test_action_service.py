from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from unittest.mock import MagicMock

_action_service_path = Path(__file__).resolve().parents[2] / "main" / "service" / "action_service.py"
_spec = spec_from_file_location("real_action_service", _action_service_path)
action_service = module_from_spec(_spec)
_spec.loader.exec_module(action_service)


def test_construct_human_and_ai_actor_records(monkeypatch):
    recorded = []
    monkeypatch.setattr(action_service, "call_to_action_service", lambda data: recorded.append(data) or data)
    monkeypatch.setattr(
        action_service.AgentCard,
        "build_agent_card",
        staticmethod(lambda entity_type, plan_item_number: {"ENTITY_TYPE": entity_type, "PARENT_ENTITY_ID": plan_item_number}),
    )

    session_data = {
        "plan_number": "20440",
        "plan_title_name": "FX Audit",
        "extract_start_time": 100,
        "extract_end_time": 200,
        "mcp_tool": ["rag_tool"],
        "llm_usage": [
            {
                "model_params": {"model": "gemini-2.5-pro"},
                "usage_metadata": {"input_tokens": 120, "output_tokens": 80},
            }
        ],
        "response": {"response_code": 200, "message": "ok", "output_location": "gs://bucket/20440"},
    }

    action_service.construct_human_actor_record_generate(session_data)
    action_service.construct_ai_actor_record_generate(session_data)
    action_service.construct_human_actor_retrieve_records("20440", "gfms", {})
    action_service.construct_ai_actor_retrieve_records("20440", "gfms", {"status": "ok", "response_code": 200}, {})

    assert len(recorded) == 4
    assert recorded[0]["CTA_ACTION"]["action_type"] == "DATA_EXTRACT_AND_SAVE"
    assert recorded[1]["CTA_ACTION"]["payload"]["Token_Input_Count"] == 120
    assert recorded[2]["CTA_ACTION"]["action_type"] == "DATA_RETRIEVAL_REQUEST"
    assert recorded[3]["CTA_ACTION"]["action_type"] == "DATA_RETRIEVAL_RESPONSE"


def test_get_prompt_version_fallback_and_call_to_action(tmp_path):
    assert action_service._get_prompt_version("nonexistent_prompt_xyz.json") == "0.1"
    res = action_service.call_to_action_service({"CTA_ACTION": {"ok": True}})
    assert res == {"CTA_ACTION": {"ok": True}}
