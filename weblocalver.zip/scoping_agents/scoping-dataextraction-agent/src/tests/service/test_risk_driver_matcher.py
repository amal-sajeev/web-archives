import json
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from util import risk_driver_matcher


@pytest.fixture

def plan_details():
    return {
        "Plan Item Title": "2026 Market Access",
        "Description of Plan Item": "Review the control framework for SEC Rule 15c3-5 market access requirements.",
        "UoT Countries": "USA",
        "UoT Currencies": "USD",
    }


@pytest.fixture

def risk_groups():
    return [
        {
            "riskid": "R033",
            "risk_name": "Supervisory Arrangements",
            "risk_drivers": [
                {
                    "riskDriverId": "R033 - RD1",
                    "riskDrivers": "Failure to define business activities that require supervision.",
                    "level_2": "Governance & Regulatory Failure",
                },
                {
                    "riskDriverId": "R033 - RD2",
                    "riskDrivers": "Failure to maintain supervisory roles.",
                    "level_2": "Governance & Regulatory Failure",
                },
            ],
        },
        {
            "riskid": "R038",
            "risk_name": "Market manipulation",
            "risk_drivers": [
                {
                    "riskDriverId": "R038 - RD1",
                    "riskDrivers": "Entering orders to move the market price.",
                    "level_2": "Market Focused Conduct",
                },
                {
                    "riskDriverId": "R038 - RD2",
                    "riskDrivers": "Trading with no change in beneficial ownership.",
                    "level_2": "Market Focused Conduct",
                },
            ],
        },
    ]


def test_prompt_includes_plan_context_and_candidates(plan_details, risk_groups):
    prompt = risk_driver_matcher.build_risk_driver_prompt(plan_details, risk_groups)

    assert "2026 Market Access" in prompt
    assert "SEC Rule 15c3-5" in prompt
    assert "USA" in prompt
    assert "USD" in prompt
    assert "all and only the drivers that are actually applicable" in prompt
    assert "select at least one candidate driver" in prompt
    assert "Do not optimize for the smallest number" in prompt
    assert "normally two sentences" in prompt
    assert "Make each rationale distinct to its driver" in prompt
    prompt_data = json.loads(prompt.split("Input data:\n", 1)[1])
    candidate_ids = [
        driver["risk_driver_id"]
        for risk in prompt_data["risks"]
        for driver in risk["risk_drivers"]
    ]
    assert candidate_ids == ["RD1", "RD2", "RD1", "RD2"]
    assert set(prompt_data["risks"][0]["risk_drivers"][0]) == {"risk_driver_id", "description"}


def test_selects_short_driver_ids_for_each_plan_risk(monkeypatch, plan_details, risk_groups):
    class FakeResponse:
        content = (
            '[{"risk_id":"R033","risk_name":"ignored by validator",'
            '"risk_driver":[{"risk_driver_id":"RD2","rationale":"The plan describes supervised activities."}]},'
            '{"risk_id":"R038","risk_name":"ignored by validator",'
            '"risk_driver":[{"risk_driver_id":"RD1","rationale":"The plan reviews orders that could affect market prices."},'
            '{"risk_driver_id":"RD2","rationale":"The plan reviews the stated trading activity."}]}]'
        )

    monkeypatch.setattr(risk_driver_matcher, "initialize_gemini_model", lambda: lambda _: FakeResponse())

    result = risk_driver_matcher.select_applicable_risk_drivers(plan_details, risk_groups)

    assert result == [
        {"riskid": "R033", "risk_name": "Supervisory Arrangements", "risk_drivers": [
            {
                "riskDriverId": "R033 - RD2",
                "riskDrivers": "Failure to maintain supervisory roles.",
                "level_2": "Governance & Regulatory Failure",
                "rationale": "The plan describes supervised activities.",
            },
        ]},
        {"riskid": "R038", "risk_name": "Market manipulation", "risk_drivers": [
            {
                "riskDriverId": "R038 - RD1",
                "riskDrivers": "Entering orders to move the market price.",
                "level_2": "Market Focused Conduct",
                "rationale": "The plan reviews orders that could affect market prices.",
            },
            {
                "riskDriverId": "R038 - RD2",
                "riskDrivers": "Trading with no change in beneficial ownership.",
                "level_2": "Market Focused Conduct",
                "rationale": "The plan reviews the stated trading activity.",
            },
        ]},
    ]


def test_accepts_response_without_risk_name_and_uses_plan_risk_name(monkeypatch, plan_details, risk_groups):
    monkeypatch.setattr(
        risk_driver_matcher,
        "initialize_gemini_model",
        lambda: lambda _: '[{"risk_id":"R033","risk_driver":'
        '[{"risk_driver_id":"RD1","rationale":"Applies to the plan."}]},'
        '{"risk_id":"R038","risk_driver":'
        '[{"risk_driver_id":"RD1","rationale":"Applies to the plan."}]}]',
    )

    result = risk_driver_matcher.select_applicable_risk_drivers(plan_details, risk_groups)

    assert [group["risk_name"] for group in result] == [
        "Supervisory Arrangements",
        "Market manipulation",
    ]


def test_rejects_driver_id_not_in_risk_candidates(monkeypatch, plan_details, risk_groups):
    monkeypatch.setattr(
        risk_driver_matcher,
        "initialize_gemini_model",
        lambda: lambda _: '[{"risk_id":"R033","risk_name":"x","risk_driver":[{"risk_driver_id":"RD99","rationale":"x"}]},'
        '{"risk_id":"R038","risk_name":"x","risk_driver":[{"risk_driver_id":"RD1","rationale":"x"}]}]',
    )

    with pytest.raises(ValueError, match="unknown driver IDs"):
        risk_driver_matcher.select_applicable_risk_drivers(plan_details, risk_groups)


def test_rejects_response_missing_a_plan_risk(monkeypatch, plan_details, risk_groups):
    monkeypatch.setattr(
        risk_driver_matcher,
        "initialize_gemini_model",
        lambda: lambda _: '[{"risk_id":"R033","risk_name":"x","risk_driver":[{"risk_driver_id":"RD1","rationale":"x"}]}]',
    )

    with pytest.raises(ValueError, match="omitted plan risks"):
        risk_driver_matcher.select_applicable_risk_drivers(plan_details, risk_groups)


def test_preserves_risk_without_candidates_and_matches_other_risks(monkeypatch, plan_details, risk_groups):
    risk_groups.insert(1, {
        "riskid": "R034",
        "risk_name": "Participation in Trading Markets",
        "risk_drivers": [],
    })
    monkeypatch.setattr(
        risk_driver_matcher,
        "initialize_gemini_model",
        lambda: lambda _: '[{"risk_id":"R033","risk_name":"x","risk_driver":'
        '[{"risk_driver_id":"RD1","rationale":"Applicable to the plan."}]},'
        '{"risk_id":"R038","risk_name":"x","risk_driver":'
        '[{"risk_driver_id":"RD1","rationale":"Applicable to the plan."}]}]',
    )

    result = risk_driver_matcher.select_applicable_risk_drivers(plan_details, risk_groups)

    assert [group["riskid"] for group in result] == ["R033", "R034", "R038"]
    assert result[1] == {
        "riskid": "R034",
        "risk_name": "Participation in Trading Markets",
        "risk_drivers": [],
    }
    assert result[0]["risk_drivers"][0]["riskDriverId"] == "R033 - RD1"
    assert result[2]["risk_drivers"][0]["riskDriverId"] == "R038 - RD1"


def test_records_usage_metadata_with_model_settings(monkeypatch, plan_details, risk_groups):
    class FakeResponse:
        content = (
            '[{"risk_id":"R033","risk_name":"x","risk_driver":'
            '[{"risk_driver_id":"RD1","rationale":"Applies to the plan."}]},'
            '{"risk_id":"R038","risk_name":"x","risk_driver":'
            '[{"risk_driver_id":"RD1","rationale":"Applies to the plan."}]}]'
        )
        usage_metadata = {"input_tokens": 120, "output_tokens": 32}

    append_usage = MagicMock()
    monkeypatch.setattr(risk_driver_matcher, "initialize_gemini_model", lambda: lambda _: FakeResponse())
    monkeypatch.setattr(risk_driver_matcher, "append_session_llm_usage", append_usage)
    monkeypatch.setattr(risk_driver_matcher.Config, "MODEL_NAME", "test-model")
    monkeypatch.setattr(risk_driver_matcher.Config, "SAFETY_CONFIG", {"safety_settings": {"policy": "test"}})

    risk_driver_matcher.select_applicable_risk_drivers(plan_details, risk_groups, session_id="session-123")

    append_usage.assert_called_once_with("session-123", {
        "operation": "applicable_risk_driver_matching",
        "model_params": {
            "model": "test-model",
            "safety_settings": {"policy": "test"},
        },
        "usage_metadata": {"input_tokens": 120, "output_tokens": 32},
    })
