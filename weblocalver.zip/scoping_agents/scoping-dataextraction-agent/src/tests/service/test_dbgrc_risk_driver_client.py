import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from service import dbgrc_risk_driver_client


def test_fetches_paginated_risk_drivers_and_filters_by_plan_risk_ids(monkeypatch):
    mcp = MagicMock()
    mcp.close = AsyncMock()
    mcp.invoke = AsyncMock(side_effect=[
        [
            {"riskId": "R1", "riskDriverId": "D1"},
            {"riskId": "R2", "riskDriverId": "D2"},
        ],
        [{"riskId": "R3", "riskDriverId": "D3"}],
    ])
    monkeypatch.setattr(dbgrc_risk_driver_client, "MCPClient", lambda **_: mcp)
    selected = [{
        "riskid": "R1",
        "risk_name": "Market Risk",
        "risk_drivers": [{"risk_driver_id": "D1", "rationale": "Applies to plan."}],
    }]
    match = MagicMock(return_value=selected)
    monkeypatch.setattr(dbgrc_risk_driver_client, "select_applicable_risk_drivers", match)
    current_data = {
        "UoT Risk Type": "R1 - Market Risk; R3 - Operational Risk",
        "AU-RT-KC": [{"RT": "R4"}],
    }

    result = asyncio.run(dbgrc_risk_driver_client.get_risk_driver_data(
        current_data,
        limit=2,
        session_id="session-1",
    ))

    assert result == selected
    match.assert_called_once_with(
        current_data,
        [
            {"riskid": "R1", "risk_name": "Market Risk", "risk_drivers": [{"riskId": "R1", "riskDriverId": "D1"}]},
            {"riskid": "R3", "risk_name": "Operational Risk", "risk_drivers": [{"riskId": "R3", "riskDriverId": "D3"}]},
        ],
        session_id="session-1",
    )
    assert mcp.invoke.await_args_list[0].args == ("get_risk_drivers", {"offset": 0, "limit": 2})
    assert mcp.invoke.await_args_list[1].args == ("get_risk_drivers", {"offset": 2, "limit": 2})
    mcp.close.assert_awaited_once()


def test_skips_mcp_call_when_plan_has_no_risk_ids(monkeypatch):
    mcp = MagicMock()
    mcp.close = AsyncMock()
    mcp.invoke = AsyncMock()
    monkeypatch.setattr(dbgrc_risk_driver_client, "MCPClient", lambda **_: mcp)

    result = asyncio.run(dbgrc_risk_driver_client.get_risk_driver_data({
        "UoT Risk Type": "",
        "AU-RT-KC": [{"RT": "R1"}],
    }))

    assert result == []
    mcp.invoke.assert_not_awaited()
    mcp.close.assert_not_awaited()