import asyncio
import sys
from pathlib import Path

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from util import historical_plan_matcher


def test_filter_matches_with_llm_keeps_selected_plan_numbers(monkeypatch) -> None:
    candidates = [
        {
            "plan_item_number": 10,
            "plan_year": 2024,
            "plan_item_title": "Waivers - Private Bank",
        },
        {
            "plan_item_number": 11,
            "plan_year": 2025,
            "plan_item_title": "Complaints Handling - Private Bank",
        },
    ]

    monkeypatch.setattr(
        historical_plan_matcher,
        "initialize_gemini_model",
        lambda: (
            lambda prompt: (
                '{"decisions": [{"plan_item_number": "10", '
                '"match": true, "reason": "Same review subject"}]}'
            )
        ),
    )

    matches = historical_plan_matcher.filter_matches_with_llm(
        "KYC Waivers - Private Bank", candidates
    )

    assert matches == ["10"]


def test_find_historical_plan_items_returns_none_for_blank_title() -> None:
    assert (
        asyncio.run(
            historical_plan_matcher.find_historical_plan_items("   ", records=[])
        )
        is None
    )


def test_find_historical_plan_items_returns_none_when_llm_rejects_all(
    monkeypatch,
) -> None:
    records = [
        {
            "Plan Year": 2025,
            "Plan Item Number": 20,
            "Plan Item Title": "KYC Waivers - Private Bank",
        }
    ]

    monkeypatch.setattr(
        historical_plan_matcher,
        "initialize_gemini_model",
        lambda: (
            lambda prompt: (
                '{"decisions": [{"plan_item_number": "20", '
                '"match": false, "reason": "Different scope"}]}'
            )
        ),
    )

    assert (
        asyncio.run(
            historical_plan_matcher.find_historical_plan_items(
                "KYC Waivers - Private Bank",
                records=records,
            )
        )
        is None
    )


def test_find_historical_plan_items_uses_gemini_by_default(monkeypatch) -> None:
    records = [
        {
            "Plan Year": 2025,
            "plan_item_number": 20,
            "Plan Item Title": "KYC Waivers - Private Bank",
        }
    ]

    class FakeGeminiModel:
        def invoke(self, prompt: str) -> str:
            return (
                '{"decisions": [{"plan_item_number": "20", '
                '"match": true, "reason": "Same review subject"}]}'
            )

    monkeypatch.setattr(
        historical_plan_matcher,
        "initialize_gemini_model",
        lambda: FakeGeminiModel(),
    )

    matches = asyncio.run(
        historical_plan_matcher.find_historical_plan_items(
            "KYC Waivers - Private Bank",
            records=records,
        )
    )

    assert matches == ["20"]


def test_load_prompt_text_reads_historical_matching_prompt() -> None:
    historical_plan_matcher._load_prompt_text.cache_clear()

    prompt = historical_plan_matcher._load_prompt_text()

    assert "You are matching a current compliance testing plan" in prompt
    assert "Do not infer unstated scope" in prompt
    assert "Mandatory specificity gate for ALL selection rules" in prompt
    assert "Same-country regional branch-review exception" in prompt
    assert "missing detail is not a conflict" in prompt
    assert "country compatibility is required" in prompt
    assert "A different subnational region, state, province, or local office region within the same country" in prompt
    assert "Region West may match Region North, Region South, Region East, or Region Südwest" in prompt
    assert "the candidate is explicitly Global" in prompt
    assert (
        "input 'Remote Location Review - Pakistan' must not match candidate 'Remote Location Review - South Korea'"
        in prompt
    )
    assert (
        "If the input is Global, the candidate must also be explicitly Global" in prompt
    )
    assert "Never add a weak, partial, or merely closest candidate" in prompt
    assert "Include every candidate exactly once, including when there are no matches" in prompt
    assert '"decisions"' in prompt
    assert "one decision for each supplied Plan Item Number" in prompt


def test_build_llm_match_prompt_includes_input_and_candidates() -> None:
    prompt = historical_plan_matcher.build_llm_match_prompt(
        "KYC Waivers - Private Bank",
        [
            {
                "plan_item_number": 30,
                "plan_year": 2025,
                "plan_item_title": "Waivers - Private Bank",
                "Description of Plan Item": "Validate KYC waiver governance controls.",
                "UoT Countries": "Germany",
            }
        ],
        plan_description="Current KYC waiver review description.",
        uot_countries="Germany",
    )

    assert "KYC Waivers - Private Bank" in prompt
    assert "Input description: Current KYC waiver review description." in prompt
    assert "Plan Item Number: 30" in prompt
    assert "Description: Validate KYC waiver governance controls." in prompt
    assert "Input UoT Countries: Germany" in prompt
    assert "UoT Countries: Germany" in prompt
    assert '"decisions"' in prompt


def test_semantic_prefilter_uses_titles_only() -> None:
    candidates = [
        {
            "plan_item_number": 10,
            "plan_item_title": "Generic Controls Review",
            "Description of Plan Item": "Validate HFT controls for German Banking Separation Act obligations.",
        },
        {
            "plan_item_number": 11,
            "plan_item_title": "GBSA Review",
            "Description of Plan Item": "Review branch inspection governance evidence.",
        },
    ]

    narrowed = historical_plan_matcher.semantic_prefilter_candidates(
        "GBSA Review",
        candidates,
        max_candidates=1,
    )

    assert narrowed == [candidates[1]]


def test_get_usage_metadata_returns_response_usage_metadata() -> None:
    class FakeResponse:
        usage_metadata = {
            "input_tokens": 123,
            "output_tokens": 45,
        }

    assert historical_plan_matcher._get_usage_metadata(FakeResponse()) == {
        "input_tokens": 123,
        "output_tokens": 45,
    }


def test_get_usage_metadata_falls_back_to_response_metadata() -> None:
    class FakeResponse:
        response_metadata = {
            "usage_metadata": {
                "prompt_token_count": 234,
                "candidates_token_count": 56,
            }
        }

    assert historical_plan_matcher._get_usage_metadata(FakeResponse()) == {
        "prompt_token_count": 234,
        "candidates_token_count": 56,
    }


def test_get_usage_metadata_preserves_reasoning_details() -> None:
    class FakeResponse:
        usage_metadata = {
            "input_tokens": 1355,
            "output_tokens": 2016,
            "total_tokens": 3371,
            "output_token_details": {"reasoning": 2001},
        }

    assert historical_plan_matcher._get_usage_metadata(FakeResponse()) == {
        "input_tokens": 1355,
        "output_tokens": 2016,
        "total_tokens": 3371,
        "output_token_details": {"reasoning": 2001},
    }


def test_find_historical_plan_items_passes_uot_countries_to_llm(monkeypatch) -> None:
    records = [
        {
            "plan_item_number": 50,
            "plan_item_title": "Branch Inspection - Germany",
            "UoT Countries": "Germany",
        }
    ]
    captured_prompt = {}

    def fake_model(prompt: str) -> str:
        captured_prompt["value"] = prompt
        return (
            '{"decisions": [{"plan_item_number": "50", '
            '"match": true, "reason": "Same review subject"}]}'
        )

    monkeypatch.setattr(
        historical_plan_matcher, "initialize_gemini_model", lambda: fake_model
    )

    matches = asyncio.run(
        historical_plan_matcher.find_historical_plan_items(
            "Branch Inspection",
            records=records,
            plan_description="Inspection governance description",
            uot_countries="Germany",
        )
    )

    assert matches == ["50"]
    assert "Input UoT Countries: Germany" in captured_prompt["value"]
    assert (
        "Input description: Inspection governance description"
        in captured_prompt["value"]
    )


def test_build_llm_match_prompt_uses_standardized_matching_rubric() -> None:
    candidates = [
        {
            "plan_item_number": 4035,
            "plan_item_title": "FRB Regulation D",
            "UoT Countries": "USA; Germany",
        },
        {
            "plan_item_number": 20226,
            "plan_item_title": "FRB Regulation BB",
            "UoT Countries": "USA",
        },
    ]

    prompt = historical_plan_matcher.build_llm_match_prompt(
        "2026 FRB Regulation D",
        candidates,
        uot_countries="USA",
    )

    assert "at least two independent signals align" in prompt
    assert (
        "separately named business activity, testing subject, product, or control"
        in prompt
    )
    assert "Do not infer unstated scope" in prompt
    assert "specific rule identifier differs" in prompt
    assert "candidate has UoT-country overlap and the same review type" in prompt


def test_parse_llm_plan_item_numbers_accepts_fenced_json_object() -> None:
    assert historical_plan_matcher._parse_llm_plan_item_numbers(
        '```json\n{"matches": [30]}\n```'
    ) == {"30"}


def test_find_historical_plan_items_returns_matched_plan_numbers(monkeypatch) -> None:
    records = [
        {
            "Plan Year": 2025,
            "plan_item_number": 40,
            "Plan Item Title": "KYC Waivers - Private Bank",
        },
        {
            "Plan Year": 2025,
            "plan_item_number": 41,
            "Plan Item Title": "Waivers - Private Bank",
        },
    ]

    monkeypatch.setattr(
        historical_plan_matcher,
        "initialize_gemini_model",
        lambda: (
            lambda prompt: (
                '{"decisions": ['
                '{"plan_item_number": "40", "match": true, "reason": "Same title"}, '
                '{"plan_item_number": "41", "match": false, "reason": "Different subject"}'
                ']}'
            )
        ),
    )

    matches = asyncio.run(
        historical_plan_matcher.find_historical_plan_items(
            "KYC Waivers - Private Bank",
            records=records,
        )
    )

    assert matches == ["40"]


def test_parse_llm_candidate_decisions_returns_all_candidates() -> None:
    decisions = historical_plan_matcher._parse_llm_candidate_decisions(
        '{"decisions": ['
        '{"plan_item_number": "30", "match": true, "reason": "same scope"}, '
        '{"plan_item_number": "31", "match": false, "reason": "different scope"}'
        ']}'
    )

    assert decisions["30"]["match"] is True
    assert decisions["31"]["match"] is False


def test_filter_matches_retries_candidates_omitted_from_batch(monkeypatch) -> None:
    candidates = [
        {
            "plan_item_number": number,
            "plan_item_title": "Branch Review Corporate Bank Germany West",
        }
        for number in (70, 71, 72)
    ]
    prompts = []

    def fake_model(prompt: str) -> str:
        prompts.append(prompt)
        if len(prompts) == 1:
            return (
                '{"decisions": [{"plan_item_number": "70", '
                '"match": true, "reason": "Same title"}]}'
            )
        candidate_id = "71" if "Plan Item Number: 71;" in prompt else "72"
        is_match = "true" if candidate_id == "72" else "false"
        return (
            '{"decisions": [{"plan_item_number": "'
            + candidate_id
            + '", "match": '
            + is_match
            + ', "reason": "Reviewed individually"}]}'
        )

    monkeypatch.setattr(
        historical_plan_matcher, "initialize_gemini_model", lambda: fake_model
    )

    matches = historical_plan_matcher.filter_matches_with_llm(
        "Branch Review Corporate Bank Germany West", candidates
    )

    assert matches == ["70", "72"]
    assert len(prompts) == 3
    assert "Plan Item Number: 71;" in prompts[1]
    assert "Plan Item Number: 70;" not in prompts[1]
    assert "Plan Item Number: 72;" in prompts[2]


def test_filter_matches_does_not_expand_beyond_narrowed_candidates(monkeypatch) -> None:
    candidates = [
        {
            "plan_item_number": number,
            "plan_item_title": "Branch Review Corporate Bank Germany West",
        }
        for number in range(100, 117)
    ]
    prompts = []

    def fake_model(prompt: str) -> str:
        prompts.append(prompt)
        candidate_ids = historical_plan_matcher.re.findall(
            r"Plan Item Number: (\d+);", prompt
        )
        decisions = [
            '{"plan_item_number": "'
            + candidate_id
            + '", "match": false, "reason": "Not a match"}'
            for candidate_id in candidate_ids
        ]
        return '{"decisions": [' + ", ".join(decisions) + ']}'

    monkeypatch.setattr(
        historical_plan_matcher, "initialize_gemini_model", lambda: fake_model
    )

    matches = historical_plan_matcher.filter_matches_with_llm(
        "Branch Review Corporate Bank Germany West", candidates
    )

    assert matches is None
    assert len(prompts) == 1
    assert "Plan Item Number: 114;" in prompts[0]
    assert "Plan Item Number: 115;" not in prompts[0]
    assert "Plan Item Number: 116;" not in prompts[0]
