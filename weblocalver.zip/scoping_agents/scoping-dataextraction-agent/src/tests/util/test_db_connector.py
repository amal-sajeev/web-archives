from unittest.mock import MagicMock

import pytest

from util import db_connector as dbc


def _configure_env(monkeypatch):
    monkeypatch.setenv("db_host", "localhost")
    monkeypatch.setenv("db_user", "postgres")
    monkeypatch.setenv("scoping_db_pass", "secret")
    monkeypatch.setenv("db_name", "dbaware")
    monkeypatch.setenv("db_port", "5432")
    if dbc.sqlalchemy is None:
        monkeypatch.setattr(dbc, "sqlalchemy", MagicMock())
    if dbc.text is None:
        monkeypatch.setattr(dbc, "text", lambda s: s)


def test_db_connector_missing_config_raises_and_skips(monkeypatch):
    if dbc.sqlalchemy is None:
        monkeypatch.setattr(dbc, "sqlalchemy", MagicMock())
    if dbc.text is None:
        monkeypatch.setattr(dbc, "text", lambda s: s)
    for key in ("db_host", "DB_HOST", "db_user", "DB_USER", "scoping_db_pass", "SCOPING_DB_PASS", "db_name", "DB_NAME"):
        monkeypatch.delenv(key, raising=False)

    connector = dbc.DBConnector()
    with pytest.raises(ValueError, match="Missing database environment variables"):
        connector._validate_config()

    assert connector.persist_data_extraction_record("gfms", 20440, {"a": 1}) is None
    assert connector.persist_document_references(20440, [{"document_id": "DOC-1"}]) is None


def test_db_connector_check_connection_and_no_sqlalchemy(monkeypatch):
    _configure_env(monkeypatch)
    connector = dbc.DBConnector()

    fake_conn = MagicMock()
    fake_engine = MagicMock()
    fake_engine.connect.return_value.__enter__.return_value = fake_conn
    monkeypatch.setattr(connector, "connect_to_database", lambda: fake_engine)
    assert connector.check_connection() is True
    fake_conn.execute.assert_called_once()

    monkeypatch.setattr(dbc, "sqlalchemy", None)
    assert connector.check_connection() is False
    assert connector.persist_data_extraction_record("gfms", 20440, {}) is None
    assert connector.persist_document_references(20440, [{"document_id": "D1"}]) is None
    with pytest.raises(ModuleNotFoundError):
        connector._validate_config()


def test_persist_data_extraction_record_updates_and_inserts(monkeypatch):
    _configure_env(monkeypatch)
    connector = dbc.DBConnector()

    assert connector.persist_data_extraction_record("gfms", None, {}) is None

    # Update path (SELECT existing scope returns (77,), UPDATE rowcount == 1)
    conn_update = MagicMock()
    select_res = MagicMock()
    select_res.first.return_value = (77,)
    conn_update.execute.side_effect = [select_res, MagicMock(rowcount=1)]
    engine_update = MagicMock()
    engine_update.begin.return_value.__enter__.return_value = conn_update
    monkeypatch.setattr(connector, "connect_to_database", lambda: engine_update)

    res_upd = connector.persist_data_extraction_record(
        "gfms", 20440, {"documents": []}, user="alice", remarks="rerun", plan_number="20440"
    )
    assert res_upd["operation"] == "updated"
    assert res_upd["review_scope_id"] == 77
    assert conn_update.execute.call_count == 2

    # Insert path (SELECT returns None -> INSERT review_scope -> UPDATE rowcount == 0 -> INSERT dataext)
    conn_insert = MagicMock()
    no_scope_res = MagicMock()
    no_scope_res.first.return_value = None
    conn_insert.execute.side_effect = [
        no_scope_res,
        MagicMock(rowcount=1),
        MagicMock(rowcount=0),
        MagicMock(rowcount=1),
    ]
    engine_insert = MagicMock()
    engine_insert.begin.return_value.__enter__.return_value = conn_insert
    monkeypatch.setattr(connector, "connect_to_database", lambda: engine_insert)

    res_ins = connector.persist_data_extraction_record(
        "policy", 20440, {"documents": []}, user="bob", remarks="init"
    )
    assert res_ins["operation"] == "inserted"
    assert res_ins["review_scope_id"] == 20440
    assert conn_insert.execute.call_count == 4

    # Exception path returns None gracefully
    monkeypatch.setattr(connector, "connect_to_database", MagicMock(side_effect=RuntimeError("db down")))
    assert connector.persist_data_extraction_record("gfms", 20440, {}) is None


def test_persist_document_references_dedup_and_error(monkeypatch):
    _configure_env(monkeypatch)
    connector = dbc.DBConnector()

    assert connector.persist_document_references(None, [{"document_id": "D1"}]) is None
    assert connector.persist_document_references(20440, []) == []
    assert connector.persist_document_references(20440, ["not-a-dict", {"document_id": ""}]) == []

    conn = MagicMock()
    conn.execute.return_value = MagicMock(rowcount=1)
    engine = MagicMock()
    engine.begin.return_value.__enter__.return_value = conn
    monkeypatch.setattr(connector, "connect_to_database", lambda: engine)

    persisted = connector.persist_document_references(
        20440,
        [{"document_id": "1"}, {"document_id": "1"}, {"document_id": "2"}],
        user="alice",
    )
    assert persisted == [{"document_id": "1"}, {"document_id": "2"}]
    assert conn.execute.call_count == 3

    connector.persist_document_reference(20440, "3")
    assert conn.execute.call_count == 5

    monkeypatch.setattr(connector, "connect_to_database", MagicMock(side_effect=RuntimeError("err")))
    assert connector.persist_document_references(20440, [{"document_id": "DOC-4"}]) is None


def test_user_request_supports_both_review_scope_id_and_instance_id():
    from model.user_request import UserRequest

    req_by_scope_id = UserRequest.model_validate(
        {"review_scope_id": 55, "user": "jdoe", "remarks": "test"}
    )
    assert req_by_scope_id.review_scope_id == 55
    assert req_by_scope_id.review_scope_instance_id == 55

    req_by_instance_id = UserRequest.model_validate(
        {"review_scope_instance_id": "55", "user": "jdoe"}
    )
    assert req_by_instance_id.review_scope_id == "55"
    assert req_by_instance_id.review_scope_instance_id == "55"


def test_coerce_scope_id_edge_cases():
    assert dbc.DBConnector._coerce_scope_id(None) is None
    assert dbc.DBConnector._coerce_scope_id(True) is None
    assert dbc.DBConnector._coerce_scope_id("") is None
    assert dbc.DBConnector._coerce_scope_id("non-int") is None
    assert dbc.DBConnector._coerce_scope_id(" 20440 ") == 20440
    assert dbc.DBConnector._coerce_scope_id(20440) == 20440

