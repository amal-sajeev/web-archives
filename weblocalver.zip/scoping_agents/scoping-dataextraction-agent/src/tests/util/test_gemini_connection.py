import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

# Ensure src/main is importable
MAIN_DIR = Path(__file__).resolve().parents[2] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from util import gemini_connection as gc


@patch("util.gemini_connection.ChatGoogleGenerativeAI")
@patch("util.gemini_connection.GoogleOAuthTokenProvider")
def test_initialize_gemini_model_success(mock_provider, mock_chat, monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "gemini-2.5-pro")
    monkeypatch.setattr(gc.Config, "SAFETY_CONFIG", {"safety_settings": {"A": "B"}})
    monkeypatch.setenv("AI_ACCESS_LAYER_BASE_URL", "https://example.test")
    mock_provider.return_value.token = "test-token"
    fake_model = object()
    mock_chat.return_value = fake_model

    result = gc.initialize_gemini_model()

    assert result is fake_model
    mock_chat.assert_called_once_with(
        model="gemini-2.5-pro",
        api_key="test-token",
        base_url="https://example.test",
        safety_settings={"A": "B"},
    )


def test_initialize_gemini_model_raises_on_missing_model_name(monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "")
    monkeypatch.delenv("AI_ACCESS_LAYER_BASE_URL", raising=False)

    with pytest.raises(ValueError, match="MODEL_NAME not configured"):
        gc.initialize_gemini_model()


def test_initialize_gemini_model_raises_on_missing_base_url(monkeypatch):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "gemini")
    monkeypatch.delenv("AI_ACCESS_LAYER_BASE_URL", raising=False)
    monkeypatch.delenv("GENAI_BASE_URL", raising=False)

    with pytest.raises(ValueError, match="AI_ACCESS_LAYER_BASE_URL not configured"):
        gc.initialize_gemini_model()


@patch(
    "util.gemini_connection.ChatGoogleGenerativeAI",
    side_effect=RuntimeError("auth failed"),
)
@patch("util.gemini_connection.GoogleOAuthTokenProvider")
def test_initialize_gemini_model_propagates_constructor_error(
    mock_provider, mock_chat, monkeypatch
):
    monkeypatch.setattr(gc.Config, "MODEL_NAME", "gemini")
    monkeypatch.setenv("AI_ACCESS_LAYER_BASE_URL", "https://example.test")
    mock_provider.return_value.token = "test-token"

    with pytest.raises(RuntimeError, match="auth failed"):
        gc.initialize_gemini_model()


def test_configure_certificate_and_token_provider(tmp_path, monkeypatch):
    cert_file = tmp_path / "custom.pem"
    cert_file.write_text("-----BEGIN CERTIFICATE-----\nFAKE\n-----END CERTIFICATE-----\n")

    with pytest.raises(ValueError, match="No custom certificate paths"):
        gc.configure_certificate([])

    with pytest.raises(FileNotFoundError, match="Certificate file not found"):
        gc.configure_certificate([str(tmp_path / "missing.pem")])

    bad_cert = tmp_path / "bad.pem"
    bad_cert.write_text("NOT A CERT")
    with pytest.raises(ValueError, match="not PEM format"):
        gc.configure_certificate([str(bad_cert)])

    combined = gc.configure_certificate([str(cert_file)])
    assert combined.endswith("combined-ca-bundle.pem")
    assert gc.os.environ["REQUESTS_CA_BUNDLE"] == combined

    monkeypatch.setattr(gc, "_CERTIFICATE_CONFIGURED", False)
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    monkeypatch.setenv("CA_BUNDLE_PATH", "/etc/ssl/custom.pem")
    gc._configure_certificate_once()
    assert gc.os.environ["SSL_CERT_FILE"] == "/etc/ssl/custom.pem"

    monkeypatch.setattr(gc, "_CERTIFICATE_CONFIGURED", False)
    monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
    monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "true")
    monkeypatch.setenv("CUSTOM_CERT_PATHS", str(cert_file))
    gc._configure_certificate_once()
    assert gc._CERTIFICATE_CONFIGURED is True

    creds = SimpleNamespace(valid=False, token="refreshed-token", refresh=MagicMock())
    monkeypatch.setattr(gc, "default", lambda scopes=None: (creds, "proj"))
    provider = gc.GoogleOAuthTokenProvider()
    assert provider.token == "refreshed-token"
    creds.refresh.assert_called_once()

