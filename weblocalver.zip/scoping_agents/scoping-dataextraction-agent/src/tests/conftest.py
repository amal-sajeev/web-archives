import os
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock

import httpx

_orig_httpx_client_init = httpx.Client.__init__
if not getattr(_orig_httpx_client_init, "_starlette_compat", False):

    def _compat_httpx_client_init(self, *args, **kwargs):
        kwargs.pop("app", None)
        return _orig_httpx_client_init(self, *args, **kwargs)

    _compat_httpx_client_init._starlette_compat = True  # type: ignore[attr-defined]
    httpx.Client.__init__ = _compat_httpx_client_init  # type: ignore[method-assign]

src_main = Path(__file__).resolve().parents[1] / "main"
if str(src_main) not in sys.path:
    sys.path.insert(0, str(src_main))

if "action_client" not in sys.modules:
    mock_action_client = MagicMock()
    mock_clt_instance = MagicMock()
    mock_clt_instance.persist_action = lambda func: func
    mock_action_client.ActionServiceClt.return_value = mock_clt_instance
    sys.modules["action_client"] = mock_action_client

try:
    import langchain_mcp_adapters.client  # noqa: F401
except ModuleNotFoundError:
    mcp_pkg = types.ModuleType("langchain_mcp_adapters")
    mcp_client_mod = types.ModuleType("langchain_mcp_adapters.client")
    mcp_client_mod.MultiServerMCPClient = MagicMock()
    mcp_pkg.client = mcp_client_mod
    sys.modules["langchain_mcp_adapters"] = mcp_pkg
    sys.modules["langchain_mcp_adapters.client"] = mcp_client_mod

os.environ.setdefault("PROJECT_NAME", "db-dev-46jr-mp-cta-analytics")
os.environ.setdefault("PROJECT_LOCATION", "europe-west1")
os.environ.setdefault("DBAWARE_REVIEW_BUCKET_NAME", "db-dev-euwe3-gcs-155081-dbaware_review")
os.environ.setdefault("bucket_name", "db-dev-euwe3-gcs-155081-dbaware_review")
os.environ.setdefault("GCP_MODEL_NAME", "gemini-2.5-pro")

