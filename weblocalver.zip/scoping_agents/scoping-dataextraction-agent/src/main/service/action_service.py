import logging
import os
import site
import sys
from datetime import datetime, timezone
import uuid
import json
from typing import Any, Dict, List, Optional
from util.agent_card import AgentCard

logger = logging.getLogger(__name__)
HUMAN_ACTOR_ID = "dbaware@db.com"
AI_AGENT_ACTOR_ID = "data-extraction-agent"

# Stash any already imported local 'config' modules so ActionServiceClt can load
# the wheel's config.dev package from dependencies without collision.
_stashed_config_modules = {
    name: mod
    for name, mod in list(sys.modules.items())
    if name == "config" or name.startswith("config.")
}
for name in _stashed_config_modules:
    sys.modules.pop(name, None)

_site_packages = site.getsitepackages() if hasattr(site, "getsitepackages") else []
# Support custom container dependency paths like /opt/python-deps or PYTHONPATH entries
_custom_dep_paths = [
    path
    for path in ["/opt/python-deps", *os.getenv("PYTHONPATH", "").split(os.pathsep)]
    if path and os.path.isdir(path)
]
_target_dep_paths = list(dict.fromkeys(_custom_dep_paths + _site_packages))

_saved_sys_path = list(sys.path)

try:
    # Put dependency directories at the top of sys.path for action client initialization
    for sp in reversed(_target_dep_paths):
        while sp in sys.path:
            sys.path.remove(sp)
        sys.path.insert(0, sp)

    from action_client import ActionServiceClt

    env = os.getenv("ENV_NAME", "dev")
    action_clt = ActionServiceClt()
finally:
    # Restore sys.path and restore local config module cache
    sys.path[:] = _saved_sys_path
    # Retain the loaded config.dev subpackage if present
    dev_submod = sys.modules.get("config.dev")
    sys.modules.update(_stashed_config_modules)
    if dev_submod is not None:
        sys.modules["config.dev"] = dev_submod
        if "config" in sys.modules and hasattr(sys.modules["config"], "__path__"):
            for sp in _target_dep_paths:
                candidate = os.path.join(sp, "config")
                if (
                    os.path.isdir(candidate)
                    and candidate not in sys.modules["config"].__path__
                ):
                    sys.modules["config"].__path__.append(candidate)


def _get_prompt_version(filename: str = "qna_prompt.json") -> str:
    """Helper to read prompt version dynamically from prompts directory."""
    try:
        # Resolves path relative to service file down to main/etc/prompts/
        base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        prompt_path = os.path.join(base_path, "etc", "prompts", filename)
        if os.path.exists(prompt_path):
            with open(prompt_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                version_str = data.get("_comment")
                split_words = version_str.split(" ")
                version = split_words[0].split("=")[1]
                return version
    except FileNotFoundError:
        logger.warning("Prompt file not found: %s", filename)
    except json.JSONDecodeError as e:
        logger.warning("Failed to parse JSON from %s: %s", filename, e)
    except Exception as e:
        logger.warning(
            "An unexpected error occurred while parsing prompt version from %s: %s",
            filename,
            e,
        )
    return "0.1"


decomposition_prompt = _get_prompt_version("decomposition_prompt.json")
historical_plan_matching_prompt = _get_prompt_version(
    "historical_plan_matching_prompt.json"
)
mandate_generation_prompt = _get_prompt_version("mandate_generation_prompt.json")
risktype_mapping = _get_prompt_version("risktype_mapping.json")


@action_clt.persist_action
def call_to_action_service(json_data):
    logger.info(f"********* in call_to_action_service json data = {json_data}")
    return json_data


def construct_cta_action_record(
    plan_number: str,
    action_type: str,
    actor_type: str,
    actor_id: str,
    activity_type: str,
    payload: Dict[str, str],
):
    logger.info(
        f"inside construct_cta_action_record plan -idplan_number = {plan_number}, action_type = {action_type}, "
        f" actor_type = {actor_type}, actor_id= {actor_id} "
    )
    agent_card = AgentCard.build_agent_card(
        entity_type="DATA_EXTRACTION", plan_item_number=plan_number
    )
    now_utc = datetime.now(timezone.utc)
    create_ts = now_utc.isoformat()

    if actor_id is None:
        actor_id = agent_card.get("ACTOR_ID", "data-extraction-agent")
    json_data = {
        "CTA_ACTION": {
            "action_id": None,
            "entity_id": agent_card.get(
                "ENTITY_ID", str(uuid.uuid5(uuid.NAMESPACE_DNS, plan_number))
            ),
            "entity_type": agent_card.get("ENTITY_TYPE", "DATA_EXTRACTION"),
            "create_ts": create_ts,
            "insert_ts": None,
            "actor_type": actor_type,
            "actor_id": actor_id,
            "action_type": action_type,
            "parent_entity_type": agent_card.get("PARENT_ENTITY_TYPE", "SCOPING"),
            "parent_entity_id": agent_card.get("PARENT_ENTITY_ID", plan_number),
            "activity_type": activity_type or agent_card.get("ACTIVITY_TYPE", ""),
            "payload": payload,
        }
    }
    logging.info(f"ACTION_TYPE={action_type}")
    return json_data


def construct_human_actor_record_generate(session_data):
    logger.info(" INSIDE construct_human_actor_record_generate *******")
    session_data = session_data or {}

    payload = {
        "Human_Notes": "extract data for plan "
        + str(session_data.get("plan_number", 0)),
        "Remarks": "",
    }

    json_data = construct_cta_action_record(
        plan_number=session_data.get("plan_number", 0),
        action_type="DATA_EXTRACT_AND_SAVE",
        actor_type="SYSTEM",
        actor_id=HUMAN_ACTOR_ID,
        activity_type="DBAWARE, DBGRC, GFMS, GROUP_AUDIT, INTERNET_SEARCH",
        payload=payload,
    )

    call_to_action_service(json_data)


def construct_ai_actor_record_generate(session_data):
    logger.info(" INSIDE construct_ai_actor_record_generate *******")
    session_data = session_data or {}
    agent_card = session_data.get("agent_card", None)
    llm_usage = session_data.get("llm_usage", None) or []

    first_usage = llm_usage[0] if isinstance(llm_usage, list) and llm_usage else {}
    model_params = (
        first_usage.get("model_params", None) if isinstance(first_usage, dict) else None
    )
    usage_metadata = (
        first_usage.get("usage_metadata", None)
        if isinstance(first_usage, dict)
        else None
    )
    response = session_data.get("response", None)

    model_name = None
    model_version = None

    if isinstance(model_params, dict):
        model_name = model_params.get("model", "")
        if isinstance(model_name, str) and model_name:
            model_version = model_name.split("-", 1)[1] if "-" in model_name else None

    input_tokens = 0
    output_tokens = 0
    if isinstance(usage_metadata, dict):
        input_tokens = usage_metadata.get("input_tokens", 0)
        output_tokens = usage_metadata.get("output_tokens", 0)
    response_code = None
    response_text = ""
    save_location = None

    if isinstance(response, dict):
        response_code = response.get("response_code", None)
        response_text = response.get("message", None)
        save_location = response.get("output_location", None)

    plan_title = session_data.get("plan_title_name", None)
    mcp_tools = session_data.get("mcp_tool", None) or []

    payload = {
        "Agent_Name": AI_AGENT_ACTOR_ID,
        "Action_type": "RESPONSE",
        "AI_Model_Name": model_name,
        "Plan_Number": session_data.get("plan_number", None),
        "Plan_Title": plan_title,
        "AI_Model_Version": model_version,
        "AI_Model_Config_Setting": {},
        "Prompt_Version": {
            "historical_plan_matching_prompt": historical_plan_matching_prompt
        },
        "AI_Rationale": None,
        "AI_Confidence_Score": None,
        "Mcp_Tools": list(mcp_tools),
        "Token_Input_Count": input_tokens if input_tokens > 0 else 0,
        "Token_Output_Count": output_tokens if output_tokens > 0 else 0,
        "Execution_Start_Time": session_data.get("extract_start_time", 0),
        "Execution_End_Time": session_data.get("extract_end_time", 0),
        "Response_Code": response_code,
        "Save_Location": save_location,
        "Remarks": "",
    }
    json_data = construct_cta_action_record(
        plan_number=session_data.get("plan_number", 0),
        action_type="RESPONSE",
        actor_type="AI_AGENT",
        actor_id=AI_AGENT_ACTOR_ID,
        activity_type="DBAWARE, DBGRC, GFMS, GROUP_AUDIT, INTERNET_SEARCH",
        payload=payload,
    )

    call_to_action_service(json_data)


def construct_human_actor_retrieve_records(plan_number, artifact, agent_card):
    agent_card = agent_card or {}

    payload = {
        "Human_Notes": "Retrieve data for plan number "
        + str(plan_number)
        + ", artifact = "
        + artifact,
        "Remarks": "",
    }

    json_data = construct_cta_action_record(
        plan_number=plan_number,
        action_type="DATA_RETRIEVAL_REQUEST",
        actor_type="HUMAN",
        actor_id=HUMAN_ACTOR_ID,
        activity_type=artifact,
        payload=payload,
    )

    call_to_action_service(json_data)


def construct_ai_actor_retrieve_records(plan_number, artifact, response, agent_card):
    agent_card = agent_card

    payload = {
        "Retrieve_status": response.get("status", None),
        "Response_Code": response.get("response_code", None),
        "Remarks": "",
    }

    json_data = construct_cta_action_record(
        plan_number=plan_number,
        action_type="DATA_RETRIEVAL_RESPONSE",
        actor_type="AI_AGENT",
        actor_id=AI_AGENT_ACTOR_ID,
        activity_type=artifact,
        payload=payload,
    )
    call_to_action_service(json_data)
