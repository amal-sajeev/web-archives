import asyncio
import copy
import json
import logging
from tempfile import TemporaryDirectory
from pathlib import Path
from typing import Any, Dict

from config.settings import Config
from model.status_enum import Status
from model.user_request import UserRequest
from persister.gcp_bucket_persister import (
    delete_prefix,
    list_historical_scoping_pdfs,
    save_folder_to_destination,
)
from persister.file_persister import save_json_to_file, build_plan_storage_paths
from service.dbaware_client import get_dbaware_data_for_plan
from service.dbgrc_client import trigger_dbgrc_pipeline
from service.dbgrc_risk_driver_client import get_risk_driver_data
from service.gfms_client import create_gfms_payload_from_dbaware, get_gfms_findings
from service.group_audit_client import get_group_audit_data
from service.internet_search_client import perform_internet_search
from service import action_service
from service.rag_retrieval_service import (
     _resolve_bucket_name,
    build_rag_base_payload,
    build_rag_metadata_payload,
    build_rag_source_metadata_from_result,
    get_all_relevant_data,
    persist_rag_documents,
)
from service.session_service import update_session_status, DATA_EXTRACTION_STAGE
from util.agent_card import AgentCard
from util.status_helper import (
    set_session_agent_card,
    set_session_extract_end_time,
    set_session_extract_start_time,
    set_session_extract_response,
)
from util.db_connector import DBConnector

logger = logging.getLogger(__name__)
extraction_semaphore = asyncio.Semaphore(Config.DATA_EXTRACTION_CONCURRENCY_LIMIT)


def generate_action_records(session_id: str):
    from service.session_service import get_session

    current_session = get_session(session_id)
    action_service.construct_human_actor_record_generate(current_session)
    action_service.construct_ai_actor_record_generate(current_session)


def _normalize_user_request(
    user_request: UserRequest | None, plan_number: str | None = None
) -> UserRequest:
    if user_request is not None:
        return user_request
    return UserRequest(
        review_scope_instance_id=None,
        user=None,
        remarks=f"data extraction for plan {plan_number or 'unknown'}",
    )


def _build_storage_uri(plan_storage_key: str, relative_path: str) -> str:
    bucket_name = _resolve_bucket_name()
    clean_key = str(plan_storage_key).strip("/")
    clean_rel = str(relative_path).strip("/")
    return f"gs://{bucket_name}/{clean_key}/{clean_rel}"


def _build_standard_source_metadata(
    source_name: str,
    filename: str,
    subfolder: str,
    plan_storage_key: str,
    document_title: str | None = None,
    sections: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    storage_uri = _build_storage_uri(plan_storage_key, f"{subfolder}/{filename}")
    title = document_title or filename
    return {
        "source_type": source_name,
        "filename": filename,
        "storage_uri": storage_uri,
        "status": "active",
        "excluded": False,
        "documents": [
            {
                "filename": filename,
                "storage_uri": storage_uri,
                "document_id": source_name,
                "document_title": title,
                "document_type": source_name,
                "status": "active",
                "excluded": False,
                "sections": sections or [],
            }
        ],
    }


def _as_dict_list(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict) and payload:
        return [payload]
    return []


def _build_current_plan_metadata(
    current_data: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    sections: list[dict[str, Any]] = []
    for idx, item in enumerate(_as_dict_list(current_data), start=1):
        plan_num = str(item.get("Plan Item Number") or item.get("plan_item_number") or idx).strip()
        title = str(item.get("Plan Item Title") or item.get("plan_item_title") or f"Plan {plan_num}").strip()
        entry: dict[str, Any] = {
            "section_id": plan_num,
            "section_title": title,
            "node_id": f"current_details:{plan_num}",
            "status": "active",
            "excluded": False,
        }
        for src_k, dst_k in (
            ("UoT Risk Type", "uot_risk_type"),
            ("UoT KCs", "uot_kcs"),
            ("UoT Regions", "uot_regions"),
            ("UoT Countries", "uot_countries"),
            ("Plan Item Status", "plan_status"),
            ("Mandatory Review", "mandatory_review"),
        ):
            if item.get(src_k) not in (None, ""):
                entry[dst_k] = item[src_k]
        if isinstance(item.get("AU-RT-KC"), list):
            entry["assessment_unit_count"] = len(item["AU-RT-KC"])
        sections.append(entry)
    return _build_standard_source_metadata(
        "current_details", "plan_details.json", "dbaware", plan_storage_key,
        document_title="Current Plan Details", sections=sections,
    )


def _build_alc_nalc_metadata(
    alc_nalc_details: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    raw_items = (
        alc_nalc_details.get("data")
        if isinstance(alc_nalc_details, dict) and isinstance(alc_nalc_details.get("data"), list)
        else alc_nalc_details
    )
    sections: list[dict[str, Any]] = []
    for idx, item in enumerate(_as_dict_list(raw_items), start=1):
        sec_id = str(item.get("id") or item.get("assessment_unit_id") or idx).strip()
        sec_title = str(
            item.get("name") or item.get("title") or item.get("au_name") or f"ALC/NALC Entry {idx}"
        ).strip()
        sections.append({
            "section_id": sec_id,
            "section_title": sec_title,
            "node_id": f"alc_nlac:{sec_id}",
            "status": "active",
            "excluded": False,
        })
    return _build_standard_source_metadata(
        "alc_nlac", "alc_nalc_details.json", "dbaware", plan_storage_key,
        document_title="ALC NALC Details", sections=sections,
    )


def _build_control_details_metadata(
    dbgrc_analysis: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    raw_kcs = (
        dbgrc_analysis.get("included_kcs")
        if isinstance(dbgrc_analysis, dict)
        else dbgrc_analysis
    )
    sections: list[dict[str, Any]] = []
    for idx, ctrl in enumerate(_as_dict_list(raw_kcs), start=1):
        inv = ctrl.get("inventory") if isinstance(ctrl.get("inventory"), dict) else ctrl
        ctrl_id = str(
            inv.get("controlInstanceNumber")
            or inv.get("controlDefinitionNumber")
            or ctrl.get("controlIdentifier")
            or idx
        ).strip()
        ctrl_title = str(
            inv.get("controlDefinitionName")
            or inv.get("controlInstanceName")
            or inv.get("controlDefinitionNumber")
            or f"Control {ctrl_id}"
        ).strip()
        entry: dict[str, Any] = {
            "section_id": ctrl_id,
            "section_title": ctrl_title,
            "node_id": f"control_details:{ctrl_id}",
            "status": "active",
            "excluded": False,
        }
        for src_k, dst_k in (
            ("controlDefinitionNumber", "control_definition_number"),
            ("controlInstanceNumber", "control_instance_number"),
            ("controlFrequency", "control_frequency"),
            ("designEffectivenessStatus", "design_effectiveness_status"),
            ("operatingControlLoc", "operating_control_location"),
        ):
            if inv.get(src_k) not in (None, ""):
                entry[dst_k] = inv[src_k]
        sections.append(entry)
    return _build_standard_source_metadata(
        "control_details", "control_details.json", "dbgrc", plan_storage_key,
        document_title="Control Details", sections=sections,
    )


def _build_risk_driver_metadata(
    risk_drivers: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    raw_list = (
        risk_drivers.get("risk_drivers")
        if isinstance(risk_drivers, dict) and isinstance(risk_drivers.get("risk_drivers"), list)
        else risk_drivers
    )
    sections: list[dict[str, Any]] = []
    for idx, item in enumerate(_as_dict_list(raw_list), start=1):
        rid = str(item.get("risk_driver_id") or item.get("riskid") or item.get("risk_id") or idx).strip()
        rtitle = str(
            item.get("risk_name") or item.get("title") or item.get("rationale") or f"Risk Driver {rid}"
        ).strip()
        sections.append({
            "section_id": rid,
            "section_title": rtitle,
            "node_id": f"risk_driver:{rid}",
            "status": "active",
            "excluded": False,
        })
    return _build_standard_source_metadata(
        "risk_driver_details", "risk_driver_details.json", "dbgrc", plan_storage_key,
        document_title="Risk Driver Details", sections=sections,
    )


def _build_group_audit_metadata(
    group_audit_analysis: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    raw_items = (
        group_audit_analysis.get("results")
        if isinstance(group_audit_analysis, dict) and isinstance(group_audit_analysis.get("results"), list)
        else group_audit_analysis
    )
    sections: list[dict[str, Any]] = []
    for idx, item in enumerate(_as_dict_list(raw_items), start=1):
        gid = str(item.get("audit_id") or item.get("report_number") or item.get("id") or idx).strip()
        gtitle = str(
            item.get("title") or item.get("audit_name") or item.get("name") or f"Group Audit {gid}"
        ).strip()
        sections.append({
            "section_id": gid,
            "section_title": gtitle,
            "node_id": f"group_audit:{gid}",
            "status": "active",
            "excluded": False,
        })
    return _build_standard_source_metadata(
        "group_audit", "group_audit_details.json", "group_audit", plan_storage_key,
        document_title="Group Audit Details", sections=sections,
    )


def _build_lrr_initial_metadata(
    search_results: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    sections: list[dict[str, Any]] = []
    for idx, item in enumerate(_as_dict_list(search_results), start=1):
        pnum = str(item.get("plan_item_number") or idx).strip()
        title = str(
            item.get("plan_item_title") or item.get("title") or f"LRR Search Result {pnum}"
        ).strip()
        entry: dict[str, Any] = {
            "section_id": str(idx),
            "section_title": title,
            "node_id": f"lrr:search:{idx}",
            "status": "active",
            "excluded": False,
        }
        if isinstance(item.get("search_combination"), dict):
            entry["search_combination"] = item["search_combination"]
        sections.append(entry)
    return _build_standard_source_metadata(
        "lrr", "internet_search_data.json", "lrr", plan_storage_key,
        document_title="LRR Internet Search Data", sections=sections,
    )


def _build_gfms_metadata(
    gfms_findings: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    storage_uri = _build_storage_uri(plan_storage_key, "gfms/findings_details.json")
    raw_findings: list[dict[str, Any]] = []

    def _collect(item: Any) -> None:
        if isinstance(item, list):
            for elem in item:
                _collect(elem)
        elif isinstance(item, dict):
            if isinstance(item.get("responsePayload"), list):
                for f in item["responsePayload"]:
                    if isinstance(f, dict):
                        raw_findings.append(f)
            elif isinstance(item.get("findings"), list):
                for f in item["findings"]:
                    if isinstance(f, dict):
                        raw_findings.append(f)
            elif any(
                k in item
                for k in ("findingId", "finding_id", "findingTitle", "auditNumber")
            ):
                raw_findings.append(item)

    _collect(gfms_findings)

    sections: list[dict[str, Any]] = []
    seen_finding_keys: set[str] = set()
    for idx, finding in enumerate(raw_findings, start=1):
        raw_id = (
            finding.get("findingId")
            or finding.get("finding_id")
            or finding.get("id")
            or idx
        )
        finding_id = str(raw_id).strip()
        control_num = str(
            finding.get("controlNumber") or finding.get("control_number") or ""
        ).strip()
        dedup_key = f"{finding_id}|{control_num}"
        if dedup_key in seen_finding_keys:
            continue
        seen_finding_keys.add(dedup_key)

        finding_title = str(
            finding.get("findingTitle")
            or finding.get("title")
            or finding.get("auditName")
            or f"Finding {finding_id}"
        ).strip()
        audit_number = str(
            finding.get("auditNumber") or finding.get("audit_number") or ""
        ).strip()
        audit_name = str(
            finding.get("auditName") or finding.get("audit_name") or ""
        ).strip()
        rating = str(finding.get("rating") or "").strip()
        excluded = bool(finding.get("excluded", False))
        raw_status = str(finding.get("status") or "").strip().lower()
        if raw_status in {"excluded", "removed", "deleted", "inactive"}:
            excluded = True
        status = raw_status if raw_status else ("excluded" if excluded else "active")

        sec_entry: dict[str, Any] = {
            "section_id": finding_id,
            "section_title": finding_title,
            "node_id": f"gfms:finding:{finding_id}",
            "status": status,
            "excluded": excluded,
        }
        if audit_number:
            sec_entry["audit_number"] = audit_number
        if audit_name:
            sec_entry["audit_name"] = audit_name
        if rating:
            sec_entry["rating"] = rating
        if control_num:
            sec_entry["control_number"] = control_num
        for src_k, dst_k in (
            ("findingStatus", "finding_status"),
            ("findingType", "finding_type"),
            ("findingTd", "finding_td"),
            ("findingOwner", "finding_owner"),
        ):
            if finding.get(src_k) not in (None, ""):
                sec_entry[dst_k] = finding[src_k]
        sections.append(sec_entry)

    return {
        "source_type": "gfms",
        "filename": "findings_details.json",
        "storage_uri": storage_uri,
        "status": "active",
        "excluded": False,
        "documents": [
            {
                "filename": "findings_details.json",
                "storage_uri": storage_uri,
                "document_id": "findings_details",
                "document_title": "GFMS Findings Details",
                "document_type": "gfms",
                "status": "active",
                "excluded": False,
                "sections": sections,
            }
        ],
    }


def _build_historical_plan_metadata(
    historical_data: Any,
    plan_storage_key: str,
) -> dict[str, Any]:
    storage_uri = _build_storage_uri(
        plan_storage_key, "dbaware/historical_plan_details.json"
    )
    items: list[dict[str, Any]] = []
    if isinstance(historical_data, list):
        items = [x for x in historical_data if isinstance(x, dict)]
    elif isinstance(historical_data, dict) and historical_data:
        items = [historical_data]

    json_sections: list[dict[str, Any]] = []
    pdf_documents: list[dict[str, Any]] = []

    for idx, item in enumerate(items, start=1):
        raw_plan_num = (
            item.get("Plan Item Number")
            or item.get("plan_item_number")
            or item.get("document_id")
            or idx
        )
        plan_num_str = str(raw_plan_num).strip()
        plan_title = str(
            item.get("Plan Item Title")
            or item.get("plan_item_title")
            or item.get("title")
            or f"Historical Plan {plan_num_str}"
        ).strip()
        report_number = str(
            item.get("Report Number") or item.get("report_number") or ""
        ).strip()
        plan_year = item.get("Plan Year") or item.get("plan_year")
        excluded = bool(item.get("excluded", False))
        raw_status = str(item.get("status") or "").strip().lower()
        if raw_status in {"excluded", "removed", "deleted", "inactive"}:
            excluded = True
        status = raw_status if raw_status else ("excluded" if excluded else "active")

        sec_entry: dict[str, Any] = {
            "section_id": plan_num_str,
            "section_title": plan_title,
            "node_id": f"historical_plan:{plan_num_str}",
            "status": status,
            "excluded": excluded,
        }
        if report_number:
            sec_entry["report_number"] = report_number
        if plan_year is not None:
            sec_entry["plan_year"] = plan_year
        for src_k, dst_k in (
            ("Review Lead", "review_lead"),
            ("Plan Item Status", "plan_status"),
            ("UoT Risk Type", "uot_risk_type"),
            ("UoT Regions", "uot_regions"),
        ):
            if item.get(src_k) not in (None, ""):
                sec_entry[dst_k] = item[src_k]
        json_sections.append(sec_entry)

        discovered_pdfs = list_historical_scoping_pdfs(plan_num_str)
        for pdf_info in discovered_pdfs:
            pdf_filename = pdf_info.get("filename") or ""
            pdf_uri = pdf_info.get("storage_uri") or ""
            if not pdf_filename:
                continue
            pdf_documents.append(
                {
                    "filename": pdf_filename,
                    "storage_uri": pdf_uri,
                    "document_id": plan_num_str,
                    "historic_plan_number": plan_num_str,
                    "document_title": plan_title,
                    "document_type": "historical_scoping_document",
                    "status": status,
                    "excluded": excluded,
                    "sections": [
                        {
                            "section_id": plan_num_str,
                            "section_title": pdf_filename,
                            "node_id": f"historical_pdf:{plan_num_str}:{pdf_filename}",
                            "status": status,
                            "excluded": excluded,
                        }
                    ],
                }
            )

    documents: list[dict[str, Any]] = [
        {
            "filename": "historical_plan_details.json",
            "storage_uri": storage_uri,
            "document_id": "historical_plan_details",
            "document_title": "Historical Plan Details",
            "document_type": "historical_scoping_document",
            "status": "active",
            "excluded": False,
            "sections": json_sections,
        },
        *pdf_documents,
    ]
    return {
        "source_type": "historical_scoping_document",
        "filename": "historical_plan_details.json",
        "storage_uri": storage_uri,
        "status": "active",
        "excluded": False,
        "documents": documents,
    }


def _persist_source_response(
    db_connector: DBConnector,
    source_name: str,
    response: Any,
    user_request: UserRequest | None,
    plan_number: str | None = None,
) -> None:
    metadata = _normalize_user_request(user_request, plan_number=plan_number)
    effective_scope_id = (
        metadata.review_scope_instance_id
        if metadata.review_scope_instance_id not in (None, "")
        else plan_number
    )
    db_connector.persist_data_extraction_record(
        source_name=source_name,
        review_scope_instance_id=effective_scope_id,
        response=response,
        user=metadata.user,
        remarks=metadata.remarks,
        plan_number=plan_number,
    )


def _persist_rag_metadata_payload(
    db_connector: DBConnector,
    review_scope_instance_id: int | str | None,
    rag_aggregated_response: dict[str, Any],
    persisted_files: dict[str, Any],
    user_request: UserRequest | None,
    plan_number: str | None = None,
) -> None:
    if review_scope_instance_id is None and plan_number is None:
        logger.warning(
            "Skipping RAG metadata persistence because review_scope_id is missing."
        )
        return

    metadata_payload = {
        "rag_response": rag_aggregated_response,
        "persisted_files": persisted_files,
    }
    _persist_source_response(
        db_connector,
        "rag_document_metadata",
        metadata_payload,
        user_request,
        plan_number=plan_number,
    )


async def run_extraction_background(
    session_id: str, plan_number: str, user_request: UserRequest | None = None
) -> None:
    """Run one extraction while respecting the configured concurrency limit."""
    async with extraction_semaphore:
        update_session_status(
            session_id=session_id,
            stage_name=DATA_EXTRACTION_STAGE,
            plan_number=plan_number,
            status=Status.PROCESSING,
        )

        try:
            await run_extraction_pipeline(
                plan_number, session_id=session_id, user_request=user_request
            )
        except Exception as error:
            logger.exception(
                "Extraction failed for session %s and plan %s",
                session_id,
                plan_number,
            )
            from service.session_service import get_session

            current_session = get_session(session_id)
            failed_stage = (
                current_session.get("stage", DATA_EXTRACTION_STAGE)
                if current_session
                else DATA_EXTRACTION_STAGE
            )
            update_session_status(
                session_id=session_id,
                stage_name=failed_stage,
                plan_number=plan_number,
                status=Status.FAILED,
                error=str(error),
            )
            agent_card = AgentCard.build_agent_card(
                "DATA_EXTRACTION",
                plan_item_number=plan_number,
                status="FAILED",
                error_message=str(error),
            )

            set_session_agent_card(session_id, agent_card)

            response = {
                "status": "FAILED",
                "message": f"Data extraction failed for plan {plan_number}.",
                "response_code": 500,
            }
            set_session_extract_response(session_id, response)
            set_session_extract_end_time(session_id)
            generate_action_records(session_id)
            return

        update_session_status(
            session_id=session_id,
            stage_name=DATA_EXTRACTION_STAGE,
            plan_number=plan_number,
            status=Status.COMPLETED,
        )
        generate_action_records(session_id)


async def run_extraction_pipeline(
    plan_number: str,
    session_id: str | None = None,
    user_request: UserRequest | None = None,
) -> Dict[str, Any]:
    """
    Orchestrates the entire data extraction pipeline.
    """
    db_connector = DBConnector()
    logger.info("Starting data extraction pipeline for plan %s", plan_number)
    set_session_extract_start_time(session_id)
    mcp_tools = []
    try:
        with TemporaryDirectory(prefix=f"scoping_{plan_number}_") as temp_dir:
            logger.info("Temporary working directory created for plan %s", plan_number)

            # 1. dbAware
            update_session_status(
                session_id=session_id,
                stage_name="dbaware",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )

            logger.info("dbAware extraction started for plan %s", plan_number)
            dbaware_sections = await get_dbaware_data_for_plan(
                plan_number, session_id=session_id
            )
            current_data = dbaware_sections.get("current_data", [])
            alc_nalc_details = dbaware_sections.get("alc_nalc_details", [])
            historical_data = dbaware_sections.get("historical_data", [])
            logger.info(
                "dbAware extraction completed for plan %s (current_data=%s, alc_nalc_details=%s, historical_data=%s)",
                plan_number,
                len(current_data) if isinstance(current_data, list) else 1,
                len(alc_nalc_details) if isinstance(alc_nalc_details, list) else 1,
                len(historical_data) if isinstance(historical_data, list) else 1,
            )

            plan_folder_name, plan_storage_key = build_plan_storage_paths(
                plan_number,
                current_data,
            )
            logger.info(
                "Storage paths built for plan %s (folder=%s, key=%s)",
                plan_number,
                plan_folder_name,
                plan_storage_key,
            )

            _persist_source_response(
                db_connector,
                "current_details",
                _build_current_plan_metadata(current_data, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )
            save_json_to_file(
                current_data,
                plan_storage_key,
                "plan_details.json",
                "dbaware",
                base_dir=temp_dir,
            )
            _persist_source_response(
                db_connector,
                "alc_nlac",
                _build_alc_nalc_metadata(alc_nalc_details, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )
            save_json_to_file(
                alc_nalc_details,
                plan_storage_key,
                "alc_nalc_details.json",
                "dbaware",
                base_dir=temp_dir,
            )
            _persist_source_response(
                db_connector,
                "historical_plan_details",
                _build_historical_plan_metadata(historical_data, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )
            save_json_to_file(
                historical_data,
                plan_storage_key,
                "historical_plan_details.json",
                "dbaware",
                base_dir=temp_dir,
            )
            logger.info("dbAware artifacts persisted for plan %s", plan_number)

            # 2. dbGRC
            update_session_status(
                session_id=session_id,
                stage_name="dbgrc",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("dbGRC analysis started for plan %s", plan_number)
            dbgrc_search_input = {"current_data": current_data}
            dbgrc_analysis = await trigger_dbgrc_pipeline(session_id, dbgrc_search_input)
            _persist_source_response(
                db_connector,
                "control_details",
                _build_control_details_metadata(dbgrc_analysis, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )
            save_json_to_file(
                dbgrc_analysis,
                plan_storage_key,
                "control_details.json",
                "dbgrc",
                base_dir=temp_dir,
            )
            applicable_risk_drivers = await get_risk_driver_data(
                current_data,
                session_id=session_id,
            )

            _persist_source_response(
                db_connector,
                "risk_driver_details",
                _build_risk_driver_metadata(applicable_risk_drivers, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )
            save_json_to_file(
                applicable_risk_drivers,
                plan_storage_key,
                "risk_driver_details.json",
                "dbgrc",
                base_dir=temp_dir,
            )
            logger.info(
                "dbGRC analysis completed and persisted for plan %s", plan_number
            )

            # 3. GFMS
            update_session_status(
                session_id=session_id,
                stage_name="gfms",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("GFMS findings collection started for plan %s", plan_number)
            plan_item = current_data
            gfms_payload = create_gfms_payload_from_dbaware(plan_item)
            logger.info(
                "GFMS base payload controls=%s plan=%s",
                len(gfms_payload.get("control", [])),
                plan_number,
            )
            gfms_payloads = []
            for control in gfms_payload.get("control", []):
                payload_copy = copy.deepcopy(gfms_payload)
                payload_copy["control"] = control
                logger.debug(
                    "GFMS per-control payload prepared for plan %s control=%s",
                    plan_number,
                    control.get("name") if isinstance(control, dict) else control,
                )
                gfms_payloads.append(payload_copy)

            gfms_tasks = [
                get_gfms_findings(session_id, payload=payload)
                for payload in gfms_payloads
            ]
            gfms_raw_results = await asyncio.gather(*gfms_tasks, return_exceptions=True)

            gfms_findings = []
            for i, result in enumerate(gfms_raw_results):
                if isinstance(result, BaseException):
                    logger.error("GFMS task %d failed: %s", i, result)
                else:
                    gfms_findings.append(result)

            logger.info(
                "GFMS findings fetched for plan %s (success=%d, failed=%d)",
                plan_number,
                len(gfms_findings),
                len(gfms_raw_results) - len(gfms_findings),
            )

            _persist_source_response(
                db_connector,
                "findings_details",
                _build_gfms_metadata(gfms_findings, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )
            save_json_to_file(
                gfms_findings,
                plan_storage_key,
                "findings_details.json",
                "gfms",
                base_dir=temp_dir,
            )
            logger.info("GFMS artifacts persisted for plan %s", plan_number)

            # 4. RAG (policy, procedure, kod) retrieval
            update_session_status(
                session_id=session_id,
                stage_name="rag_enrichment",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("RAG enrichment started for plan %s", plan_number)

            plan_item_for_rag = (
                current_data[0]
                if isinstance(current_data, list) and current_data
                else current_data
            )
            try:
                rag_base_payload = build_rag_base_payload(
                    review_id=str(plan_number),
                    plan_item=plan_item_for_rag or {},
                    dbgrc_analysis=(
                        dbgrc_analysis if isinstance(dbgrc_analysis, dict) else {}
                    ),
                )
                rag_aggregated_response = await get_all_relevant_data(
                    base_payload=rag_base_payload,
                    request_id=session_id or str(plan_number),
                )
              

            except Exception as rag_error:
                logger.exception("RAG enrichment failed for plan %s", plan_number)
                rag_aggregated_response = {
                    "status": "failed",
                    "query_context": {
                        "review_id": str(plan_number),
                        "region": "",
                        "plan_item_title": "",
                    },
                    "results": {"policy": None, "procedure": None, "kod": None},
                    "errors": {
                        "policy": str(rag_error),
                        "procedure": str(rag_error),
                        "kod": str(rag_error),
                    },
                    "latency_ms_per_type": {
                        "policy": 0.0,
                        "procedure": 0.0,
                        "kod": 0.0,
                    },
                    "total_latency_ms": 0.0,
                }

            rag_write_report = await persist_rag_documents(
                rag_aggregated_response,
                plan_storage_key,
                temp_dir,
                request_id=session_id or str(plan_number),
            )
            rag_results = rag_aggregated_response.get("results", {})
            
            _persist_source_response(
                db_connector,
                "policy",
                build_rag_source_metadata_from_result(
                    "policy", rag_results.get("policy"), plan_storage_key
                ),
                user_request,
                plan_number=plan_number,
            )
            _persist_source_response(
                db_connector,
                "procedure",
                build_rag_source_metadata_from_result(
                    "procedure", rag_results.get("procedure"), plan_storage_key
                ),
                user_request,
                plan_number=plan_number,
            )
            _persist_source_response(
                db_connector,
                "kod",
                build_rag_source_metadata_from_result(
                    "kod", rag_results.get("kod"), plan_storage_key
                ),
                user_request,
                plan_number=plan_number,
            )
            logger.info(
                "RAG enrichment completed for plan %s (status=%s)",
                plan_number,
                rag_aggregated_response.get("status"),
            )
            _persist_referenced_documents(
                db_connector,
                rag_aggregated_response,
                user_request,
                plan_number=plan_number,
            )
            logger.info(
                "Retrieved document id's persisted for plan %s (status=%s)",
                plan_number,
                rag_aggregated_response.get("status"),
            )

    

            # 5. Group Audit
            update_session_status(
                session_id=session_id,
                stage_name="group_audit",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("Group Audit started for plan %s", plan_number)

            group_audit_analysis = await get_group_audit_data(session_id, current_data)
            _persist_source_response(
                db_connector,
                "group_audit",
                _build_group_audit_metadata(group_audit_analysis, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )
            save_json_to_file(
                group_audit_analysis,
                plan_storage_key,
                "group_audit_details.json",
                "group_audit",
                base_dir=temp_dir,
            )
            logger.info(
                "Group Audit analysis completed and persisted for plan %s", plan_number
            )

            # 6. Internet Search
            update_session_status(
                session_id=session_id,
                stage_name="internet_search",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("Internet search started for plan %s", plan_number)
            plan_item = current_data
            if not isinstance(plan_item, list):
                plan_item = [plan_item] if plan_item else []

            internet_search_input = {
                "searchTerm": f"reviewIds={plan_number}",
                "data": plan_item,
                "alc_nalc_details": alc_nalc_details,
                "historical_data": historical_data,
                "count": len(plan_item),
            }


            search_results = await perform_internet_search(session_id, internet_search_input)
            _persist_source_response(
                db_connector,
                "lrr",
                _build_lrr_initial_metadata(search_results, plan_storage_key),
                user_request,
                plan_number=plan_number,
            )

            save_json_to_file(
                search_results,
                plan_storage_key,
                "internet_search_data.json",
                "lrr",
                base_dir=temp_dir,
            )

            logger.info(
                "Internet search completed and persisted for plan %s", plan_number
            )

            # 7. Upload to GCP Bucket or mirror locally
            update_session_status(
                session_id=session_id,
                stage_name="upload",
                plan_number=plan_number,
                status=Status.PROCESSING,
            )
            logger.info("Artifact upload started for plan %s", plan_number)
            local_plan_folder = str(Path(temp_dir) / plan_folder_name)
            # Clear stale per-document parts so removed documents don't linger after re-extraction.
            for doc_type in ("policy", "procedure", "kod"):
                delete_prefix(f"{plan_storage_key}/policy/relevant_{doc_type}")
            bucket_location = save_folder_to_destination(
                local_folder=local_plan_folder,
                destination_prefix=f"{plan_folder_name}",
            )
            logger.info(
                "Artifact upload completed for plan %s (destination=%s)",
                plan_number,
                bucket_location,
            )
    except Exception:
        logger.exception("Data extraction pipeline failed for plan %s", plan_number)
        raise

    logger.info(
        "Data extraction pipeline finished successfully for plan %s", plan_number
    )

    response = {
        "status": "success",
        "message": f"Data extraction complete for plan {plan_number}.",
        "output_location": bucket_location,
        "response_code": 200,
    }
    agent_card = AgentCard.build_agent_card(
        "DATA_EXTRACTION",
        plan_item_number=plan_number,
        status="SUCCESS",
    )

    set_session_agent_card(session_id, agent_card)
    set_session_extract_response(session_id, response)
    set_session_extract_end_time(session_id)
    return response


def _extract_rag_document_references(
    rag_aggregated_response: dict[str, Any] | None,
) -> list[dict[str, str]]:
    """Collect deduplicated document ids across the policy/procedure/kod RAG payloads."""
    if not isinstance(rag_aggregated_response, dict):
        return []

    results = rag_aggregated_response.get("results")
    if not isinstance(results, dict):
        return []

    referenced_docs: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()

    def walk(node: Any, document_type: str | None = None) -> None:
        if isinstance(node, dict):
            doc_id = node.get("document_id")
            if doc_id not in (None, ""):
                normalized_document_type = str(
                    document_type or node.get("document_type") or ""
                ).strip()
                normalized_document_id = str(doc_id).strip()
                dedupe_key = (normalized_document_type, normalized_document_id)
                if normalized_document_id and dedupe_key not in seen:
                    seen.add(dedupe_key)
                    referenced_docs.append(
                        {
                            "document_type": normalized_document_type,
                            "document_id": normalized_document_id,
                        }
                    )

            for key, value in node.items():
                if key in {"document_id", "document_type"}:
                    continue
                walk(value, document_type or str(key).strip())
        elif isinstance(node, list):
            for item in node:
                walk(item, document_type)

    for doc_type, payload in results.items():
        if doc_type not in {"policy", "procedure", "kod"}:
            continue
        walk(payload, doc_type)

    return referenced_docs


def _persist_referenced_documents(
    db_connector: DBConnector,
    rag_aggregated_response: dict[str, Any] | None,
    user_request: UserRequest | None,
    plan_number: str | None = None,
) -> None:
    metadata = _normalize_user_request(user_request, plan_number=plan_number)
    effective_scope_id = (
        metadata.review_scope_instance_id
        if metadata.review_scope_instance_id not in (None, "")
        else plan_number
    )
    document_refs = _extract_rag_document_references(rag_aggregated_response)
    if not document_refs:
        logger.info(
            "No referenced document IDs were found in the RAG payload for review_scope_id=%s",
            effective_scope_id,
        )
        return

    db_connector.persist_document_references(
        review_scope_instance_id=effective_scope_id,
        document_references=document_refs,
        user=metadata.user,
        remarks=metadata.remarks,
        plan_number=plan_number,
    )
