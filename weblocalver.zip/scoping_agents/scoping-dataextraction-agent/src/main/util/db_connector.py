import json
import logging
import os
from pathlib import Path
from typing import Any, TYPE_CHECKING

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

_base_dir = Path(__file__).resolve().parent
_env_candidates = [
    _base_dir.parent.parent / ".env",
    _base_dir.parent / ".env",
    _base_dir / ".env",
    Path("/app/.env"),
    Path.cwd() / ".env",
]
for _env_path in _env_candidates:
    if _env_path.exists():
        load_dotenv(_env_path)
        break

if TYPE_CHECKING:
    import sqlalchemy
    from sqlalchemy import text
else:
    try:
        import sqlalchemy
        from sqlalchemy import text
    except (
        ModuleNotFoundError
    ):  # pragma: no cover - optional dependency for local/test installs
        sqlalchemy = None  # type: ignore[assignment]
        text = None  # type: ignore[assignment]


class DBConnector:
    """Database connector with a safe no-op fallback when DB config is absent."""

    def __init__(self):
        self.db_host = os.getenv("db_host") or os.getenv("DB_HOST")
        self.db_user = os.getenv("db_user") or os.getenv("DB_USER")
        self.db_pass = os.getenv("scoping_db_pass") or os.getenv("SCOPING_DB_PASS")
        self.db_name = os.getenv("db_name") or os.getenv("DB_NAME")
        self.db_port = os.getenv("db_port", "5432") or os.getenv("DB_PORT", "5432")
        self.table_name = (
            os.getenv("DATA_EXTRACTION_TABLE_NAME")
            or os.getenv("data_extraction_table_name")
            or "dbaware_scoping.review_data_extraction"
        )
        self.document_reference_table_name = (
            os.getenv("DOCUMENT_REFERENCE_TABLE_NAME")
            or os.getenv("document_reference_table_name")
            or os.getenv("REVIEW_DOCUMENT_REFERENCE_TABLE_NAME")
            or os.getenv("review_document_reference_table_name")
            or os.getenv("DBAWARE_REVIEW_DOCUMENTS_TABLE_NAME")
            or os.getenv("dbaware_review_documents_table_name")
            or "dbaware_scoping.dbaware_review_documents"
        )

    def _validate_config(self) -> None:
        if sqlalchemy is None:
            raise ModuleNotFoundError(
                "sqlalchemy is required for database persistence."
            )

        missing = []
        if not self.db_host:
            missing.append("db_host")
        if not self.db_user:
            missing.append("db_user")
        if not self.db_pass:
            missing.append("db_pass / DB_PASS / scoping_db_pass")
        if not self.db_name:
            missing.append("db_name")

        if missing:
            raise ValueError(
                f"Missing database environment variables: {', '.join(missing)}"
            )

    def connect_to_database(self):
        self._validate_config()

        pool = sqlalchemy.create_engine(
            sqlalchemy.engine.url.URL.create(
                drivername="postgresql+pg8000",
                username=self.db_user,
                password=self.db_pass,
                host=self.db_host,
                port=self.db_port,
                database=self.db_name,
            ),
            pool_pre_ping=True,
            future=True,
        )
        logger.info(
            "Created SQLAlchemy engine for db_host=%s db_name=%s db_port=%s table=%s",
            self.db_host,
            self.db_name,
            self.db_port,
            self.table_name,
        )
        return pool

    def check_connection(self) -> bool:
        if sqlalchemy is None:
            logger.warning(
                "SQLAlchemy is not installed; database connectivity cannot be checked."
            )
            return False

        engine = self.connect_to_database()
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        logger.info("Database connectivity check passed")
        return True

    def persist_data_extraction_record(
        self,
        source_name: str,
        review_scope_instance_id: int | None,
        response: dict[str, Any] | list[dict[str, Any]] | None,
        user: str | None = None,
        remarks: str | None = None,
    ) -> Any:
        if sqlalchemy is None:
            logger.info(
                "SQLAlchemy is not installed; skipping persistence for source=%s review_scope_instance_id=%s",
                source_name,
                review_scope_instance_id,
            )
            return None

        missing_config = [
            name
            for name, value in {
                "db_host": self.db_host,
                "db_user": self.db_user,
                "db_pass": self.db_pass,
                "db_name": self.db_name,
            }.items()
            if not value
        ]
        if missing_config:
            logger.warning(
                "DB persistence skipped for source=%s because required config is missing: %s",
                source_name,
                ", ".join(missing_config),
            )
            return None

        if review_scope_instance_id is None:
            logger.warning(
                "DB persistence skipped for source=%s because review_scope_instance_id is missing.",
                source_name,
            )
            return None

        response_json = json.dumps(response, ensure_ascii=False, default=str)
        logger.info(
            "Attempting to persist extraction response for source=%s review_scope_instance_id=%s user=%s remarks=%s response_size=%s table=%s",
            source_name,
            review_scope_instance_id,
            user,
            remarks,
            len(response_json),
            self.table_name,
        )

        try:
            engine = self.connect_to_database()
            with engine.begin() as connection:
                # Table creation is intentionally not done here.
                # The schema/table must exist via migration/DBA privileges.
                update_result = connection.execute(
                    text(f"""
                        UPDATE {self.table_name}
                        SET metadata = CAST(:metadata AS JSONB),
                            remarks = :remarks,
                            updated_by = :updated_by,
                            updated_on = CURRENT_TIMESTAMP
                        WHERE review_scope_instance_id = :review_scope_instance_id
                        AND data_source = :data_source
                        """),
                    {
                        "review_scope_instance_id": review_scope_instance_id,
                        "data_source": source_name,
                        "metadata": response_json,
                        "remarks": remarks,
                        "updated_by": user,
                    },
                )

                if update_result.rowcount and update_result.rowcount > 0:
                    logger.info(
                        "DB persistence result: UPDATED existing row for source=%s review_scope_instance_id=%s user=%s table=%s",
                        source_name,
                        review_scope_instance_id,
                        user,
                        self.table_name,
                    )
                    operation = "updated"
                else:
                    connection.execute(
                        text(f"""
                            INSERT INTO {self.table_name} (
                                review_scope_instance_id,
                                data_source,
                                metadata,
                                created_by,
                                created_on,
                                remarks
                            ) VALUES (
                                :review_scope_instance_id,
                                :data_source,
                                CAST(:metadata AS JSONB),
                                :created_by,
                                CURRENT_TIMESTAMP,
                                :remarks
                            )
                            """),
                        {
                            "review_scope_instance_id": review_scope_instance_id,
                            "data_source": source_name,
                            "metadata": response_json,
                            "created_by": user,
                            "remarks": remarks,
                        },
                    )
                    logger.info(
                        "DB persistence result: INSERTED new row for source=%s review_scope_instance_id=%s user=%s table=%s",
                        source_name,
                        review_scope_instance_id,
                        user,
                        self.table_name,
                    )
                    operation = "inserted"

            persisted_record = {
                "source_name": source_name,
                "review_scope_instance_id": review_scope_instance_id,
                "user": user,
                "remarks": remarks,
                "metadata": response,
                "operation": operation,
            }

            logger.info(
                "DB persistence completed successfully for source=%s review_scope_instance_id=%s operation=%s table=%s",
                source_name,
                review_scope_instance_id,
                operation,
                self.table_name,
            )
            return persisted_record
        except Exception as exc:
            logger.warning(
                "DB not persisted for source=%s review_scope_instance_id=%s table=%s error=%s",
                source_name,
                review_scope_instance_id,
                self.table_name,
                exc,
            )
            return None

    def persist_document_references(
        self,
        review_scope_instance_id: int | None,
        document_references: list[dict[str, str]] | None,
        user: str | None = None,
        remarks: str | None = None,
    ) -> Any:
        """Persist deduplicated document references for the active review scope instance."""
        if sqlalchemy is None:
            logger.info(
                "SQLAlchemy is not installed; skipping document reference persistence for review_scope_instance_id=%s",
                review_scope_instance_id,
            )
            return None

        missing_config = [
            name
            for name, value in {
                "db_host": self.db_host,
                "db_user": self.db_user,
                "db_pass": self.db_pass,
                "db_name": self.db_name,
            }.items()
            if not value
        ]
        if missing_config:
            logger.warning(
                "Document reference persistence skipped for review_scope_instance_id=%s because required config is missing: %s",
                review_scope_instance_id,
                ", ".join(missing_config),
            )
            return None

        if review_scope_instance_id is None:
            logger.warning(
                "Document reference persistence skipped because review_scope_instance_id is missing."
            )
            return None

        if not document_references:
            logger.info(
                "No document references to persist for review_scope_instance_id=%s",
                review_scope_instance_id,
            )
            return []

        deduped: list[str] = []
        seen: set[str] = set()
        for item in document_references:
            if not isinstance(item, dict):
                continue
            document_id = str(item.get("document_id") or "").strip()
            if not document_id:
                continue
            if document_id in seen:
                continue
            seen.add(document_id)
            deduped.append(document_id)

        if not deduped:
            return []

        try:
            engine = self.connect_to_database()
            inserted_count = 0
            with engine.begin() as connection:
                # Table creation is intentionally not done here.
                # The schema/table must exist via migration/DBA privileges.
                for document_id in deduped:
                    result = connection.execute(
                        text(f"""
                            INSERT INTO {self.document_reference_table_name} (
                                review_scope_instance_id,
                                document_id
                            )
                            SELECT :review_scope_instance_id, :document_id
                            WHERE NOT EXISTS (
                                SELECT 1
                                FROM {self.document_reference_table_name} existing
                                WHERE existing.review_scope_instance_id = :review_scope_instance_id
                                  AND existing.document_id = :document_id
                            )
                            """),
                        {
                            "review_scope_instance_id": review_scope_instance_id,
                            "document_id": document_id,
                        },
                    )
                    if result.rowcount and result.rowcount > 0:
                        inserted_count += int(result.rowcount)

            logger.info(
                "Persisted %s document references for review_scope_instance_id=%s table=%s",
                inserted_count,
                review_scope_instance_id,
                self.document_reference_table_name,
            )
            return [{"document_id": document_id} for document_id in deduped]
        except Exception as exc:
            logger.warning(
                "Document references not persisted for review_scope_instance_id=%s table=%s error=%s",
                review_scope_instance_id,
                self.document_reference_table_name,
                exc,
            )
            return None

    def persist_document_reference(
        self,
        review_scope_instance_id: int,
        document_reference: str,
        user: str | None = None,
        remarks: str | None = None,
    ) -> None:
        """Persist a single document reference for the active review scope instance."""
        return self.persist_document_references(
            review_scope_instance_id=review_scope_instance_id,
            document_references=[{"document_id": document_reference}],
            user=user,
            remarks=remarks,
        )
