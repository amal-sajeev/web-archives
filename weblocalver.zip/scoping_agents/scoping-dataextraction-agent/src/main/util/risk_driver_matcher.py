import json
import logging
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, List

from pydantic import TypeAdapter, ValidationError

from config.settings import Config
from model.dbgrc_model import ApplicableRiskDriverGroup
from util.gemini_connection import initialize_gemini_model
from util.status_helper import append_session_llm_usage

logger = logging.getLogger(__name__)
PROMPT_PATH = Path(__file__).resolve().parents[1] / "etc" / "prompts" / "applicable_rd_matching_prompt.json"
_SELECTION_ADAPTER = TypeAdapter(List[ApplicableRiskDriverGroup])


def _plan_items(plan_details: Any) -> Iterable[Dict[str, Any]]:
    if isinstance(plan_details, dict):
        yield plan_details
    elif isinstance(plan_details, list):
        yield from (item for item in plan_details if isinstance(item, dict))


def _joined_plan_field(plan_items: List[Dict[str, Any]], *field_names: str) -> str:
    values: List[str] = []
    for item in plan_items:
        for field_name in field_names:
            value = item.get(field_name)
            if value is not None and str(value).strip():
                value = str(value).strip()
                if value not in values:
                    values.append(value)
                break
    return "; ".join(values)


def _driver_short_id(driver: Dict[str, Any]) -> str:
    full_id = str(driver.get("riskDriverId") or driver.get("risk_driver_id") or "").strip()
    return full_id.rsplit("-", 1)[-1].strip() if full_id else ""


def _prompt_data(plan_details: Any, risk_groups: List[Dict[str, Any]]) -> Dict[str, Any]:
    plan_items = list(_plan_items(plan_details))
    plan = {
        "plan_title": _joined_plan_field(plan_items, "Plan Item Title", "plan_title"),
        "plan_description": _joined_plan_field(
            plan_items, "Description of Plan Item", "Plan Item Description", "plan_description"
        ),
        "uot_countries": _joined_plan_field(plan_items, "UoT Countries", "uot_countries"),
        "uot_currencies": _joined_plan_field(
            plan_items, "UoT Currencies", "UoT Currency", "uot_currencies"
        ),
    }

    risks = []
    for group in risk_groups:
        candidates = []
        for driver in group.get("risk_drivers", []):
            short_id = _driver_short_id(driver)
            if not short_id:
                continue
            candidates.append({
                "risk_driver_id": short_id,
                "description": driver.get("riskDrivers"),
            })
        risks.append({
            "risk_id": str(group.get("riskid") or "").strip(),
            "risk_name": str(group.get("risk_name") or "").strip(),
            "risk_drivers": candidates,
        })
    return {"plan": plan, "risks": risks}


@lru_cache(maxsize=1)
def _load_prompt() -> str:
    if not PROMPT_PATH.exists():
        raise ValueError(f"Applicable risk-driver prompt not found: {PROMPT_PATH}")
    payload = json.loads(PROMPT_PATH.read_text(encoding="utf-8"))
    prompt_instructions = payload.get("prompt_instructions")
    if not isinstance(prompt_instructions, dict):
        raise ValueError(f"Prompt file must contain prompt_instructions: {PROMPT_PATH}")

    instructions: List[str] = []
    for section in prompt_instructions.values():
        if not isinstance(section, dict):
            continue
        content = section.get("content")
        if isinstance(content, str):
            instructions.append(content.strip())
        elif isinstance(content, list):
            instructions.extend(str(item).strip() for item in content if str(item).strip())
    if not instructions:
        raise ValueError(f"Applicable risk-driver prompt is empty: {PROMPT_PATH}")
    return "\n".join(instructions)


def build_risk_driver_prompt(plan_details: Any, risk_groups: List[Dict[str, Any]]) -> str:
    return "\n".join([
        _load_prompt(),
        "Input data:",
        json.dumps(_prompt_data(plan_details, risk_groups), ensure_ascii=True, separators=(",", ":")),
    ])


def _response_text(response: Any) -> str:
    content = getattr(response, "content", response)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        text_parts = [part.get("text", "") for part in content if isinstance(part, dict)]
        if text_parts:
            return "".join(text_parts)
    return json.dumps(content)


def _parse_selection(response: Any, risk_groups: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    response_text = _response_text(response).strip()
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", response_text)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as error:
        match = re.search(r"\[[\s\S]*\]", cleaned)
        if not match:
            raise ValueError("Risk-driver matcher did not return a JSON array") from error
        try:
            parsed = json.loads(match.group(0))
        except json.JSONDecodeError as extracted_error:
            raise ValueError("Risk-driver matcher returned invalid JSON") from extracted_error

    try:
        selections = _SELECTION_ADAPTER.validate_python(parsed)
    except ValidationError as error:
        raise ValueError("Risk-driver matcher returned an invalid selection schema") from error

    expected = {str(group.get("riskid")): group for group in risk_groups}
    selected_by_risk: Dict[str, Dict[str, str]] = {}
    for selection in selections:
        risk_id = selection.risk_id.strip()
        if risk_id not in expected:
            raise ValueError(f"Risk-driver matcher returned unknown risk ID: {risk_id}")
        if risk_id in selected_by_risk:
            raise ValueError(f"Risk-driver matcher returned duplicate risk ID: {risk_id}")
        candidate_ids = {
            _driver_short_id(driver)
            for driver in expected[risk_id].get("risk_drivers", [])
        }
        selected_drivers = {
            driver.risk_driver_id.strip(): driver.rationale.strip()
            for driver in selection.risk_driver
        }
        invalid_ids = set(selected_drivers) - candidate_ids
        if invalid_ids:
            raise ValueError(
                f"Risk-driver matcher returned unknown driver IDs for {risk_id}: {sorted(invalid_ids)}"
            )
        if any(not rationale for rationale in selected_drivers.values()):
            raise ValueError(f"Risk-driver matcher returned an empty rationale for {risk_id}")
        selected_by_risk[risk_id] = selected_drivers

    if set(selected_by_risk) != set(expected):
        missing = sorted(set(expected) - set(selected_by_risk))
        raise ValueError(f"Risk-driver matcher omitted plan risks: {missing}")

    output = []
    for group in risk_groups:
        risk_id = str(group["riskid"])
        selected_ids = selected_by_risk[risk_id]
        ordered_drivers = []
        emitted_ids = set()
        for driver in group.get("risk_drivers", []):
            short_id = _driver_short_id(driver)
            if short_id in selected_ids and short_id not in emitted_ids:
                emitted_ids.add(short_id)
                applicable_driver = dict(driver)
                applicable_driver["rationale"] = selected_ids[short_id]
                ordered_drivers.append(applicable_driver)
        if not ordered_drivers:
            raise ValueError(f"Risk-driver matcher selected no candidates for plan risk {risk_id}")
        output.append({
            "riskid": risk_id,
            "risk_name": str(group.get("risk_name") or ""),
            "risk_drivers": ordered_drivers,
        })
    return output


def _usage_metadata(response: Any) -> Dict[str, Any]:
    usage = getattr(response, "usage_metadata", None)
    if isinstance(usage, dict):
        return usage
    response_metadata = getattr(response, "response_metadata", None)
    if isinstance(response_metadata, dict):
        usage = response_metadata.get("usage_metadata")
        if isinstance(usage, dict):
            return usage
    return {}


def _model_params() -> Dict[str, Any]:
    return {
        "model": Config.MODEL_NAME,
        "safety_settings": Config.SAFETY_CONFIG.get("safety_settings", []),
    }


def _build_usage_record(operation: str, response: Any) -> Dict[str, Any]:
    return {
        "operation": operation,
        "model_params": _model_params(),
        "usage_metadata": _usage_metadata(response),
    }


def select_applicable_risk_drivers(
    plan_details: Any,
    risk_groups: List[Dict[str, Any]],
    session_id: str | None = None,
) -> List[Dict[str, Any]]:
    """Use Gemini to select applicable driver IDs independently for each plan risk."""
    if not risk_groups:
        return []

    candidate_groups = [group for group in risk_groups if group.get("risk_drivers")]
    empty_candidate_groups = [group for group in risk_groups if not group.get("risk_drivers")]
    for group in empty_candidate_groups:
        logger.warning(
            "No risk-driver candidates returned for plan risk %s; preserving an empty result group",
            group.get("riskid"),
        )

    if candidate_groups:
        prompt = build_risk_driver_prompt(plan_details, candidate_groups)
        llm = initialize_gemini_model()
        response = llm(prompt) if callable(llm) else llm.invoke(prompt)
        selected = _parse_selection(response, candidate_groups)

        if session_id:
            append_session_llm_usage(
                session_id,
                _build_usage_record("applicable_risk_driver_matching", response),
            )
    else:
        selected = []

    selected_by_id = {group["riskid"]: group for group in selected}
    return [
        selected_by_id.get(
            str(group.get("riskid")),
            {
                "riskid": str(group.get("riskid") or ""),
                "risk_name": str(group.get("risk_name") or ""),
                "risk_drivers": [],
            },
        )
        for group in risk_groups
    ]