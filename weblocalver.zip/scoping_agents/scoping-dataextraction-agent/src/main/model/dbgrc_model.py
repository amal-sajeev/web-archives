from pydantic import BaseModel, ConfigDict, Field


class ApplicableRiskDriver(BaseModel):
	model_config = ConfigDict(extra="forbid")

	risk_driver_id: str = Field(min_length=1)
	rationale: str = Field(min_length=1)


class ApplicableRiskDriverGroup(BaseModel):
	model_config = ConfigDict(extra="forbid")

	risk_id: str
	risk_name: str | None = None
	risk_driver: list[ApplicableRiskDriver] = Field(min_length=1)
