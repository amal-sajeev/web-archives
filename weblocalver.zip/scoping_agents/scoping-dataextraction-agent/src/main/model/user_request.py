from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class UserRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    review_scope_instance_id: int | str | None = Field(
        default=None,
        validation_alias=AliasChoices("review_scope_instance_id", "review_scope_id"),
    )
    user: str | None = None
    remarks: str | None = None

    @property
    def review_scope_id(self) -> int | str | None:
        return self.review_scope_instance_id

