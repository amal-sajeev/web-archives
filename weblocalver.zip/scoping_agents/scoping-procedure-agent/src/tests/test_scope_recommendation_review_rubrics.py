import pytest
from pydantic import ValidationError

from agents.llm_judge import SCOPE_REVIEW_PROMPT, SCOPE_REVIEW_RUBRIC_CALLS
from agents.llm_judge.models import SCOPE_REVIEW_RESPONSE_MODELS


def test_focused_review_schemas_require_each_requested_criterion():
    for rubric_name, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS:
        response_model = SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
        required_fields = set(response_model.model_json_schema().get("required", []))

        assert required_fields == set(expected_names)
        with pytest.raises(ValidationError):
            response_model.model_validate({})


def test_scope_judge_prompts_cover_boundary_hierarchy_conflicts_and_confidence():
    all_instructions = "\n".join(
        instructions for _name, _criteria, instructions in SCOPE_REVIEW_RUBRIC_CALLS
    )

    assert "Broad Scope Section 2" in all_instructions
    assert "must not independently add, remove, reclassify, or change a boundary" in all_instructions
    assert "When non-action feedback explicitly differs from Section 2" in all_instructions
    assert "must not be flagged as an extra boundary" in all_instructions
    assert (
        "clear, explicit MOM decision or action item"
        in all_instructions
    )
    assert "confidence_score" in all_instructions
    assert "numeric review score" in SCOPE_REVIEW_PROMPT
    assert (
        "exact plan, control, control-instance, risk, finding, review"
        in all_instructions
    )
    assert "different instances on both sides" in all_instructions
    assert "bold label form (**Attribute:**)," in all_instructions
    assert "no introductory or closing prose" in all_instructions
    assert "no line breaks, bullets, or header" in all_instructions
    assert "MOM-directed scope action" in all_instructions
    assert "a moderate score such as 60-79 may be consistent" in all_instructions
    assert "hypothesis, assumption, possible focus" in all_instructions
    assert "no controls are attached or no controls were fetched" in all_instructions
