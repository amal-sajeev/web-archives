from unittest.mock import MagicMock

import pytest


def test_llm_invoke_retries_rate_limits_with_exponential_backoff(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    model = MagicMock()
    model.invoke.side_effect = [RuntimeError("429 resource exhausted"), RuntimeError("429 rate limit"), "ok"]
    sleeps = []
    monkeypatch.setattr("service.inscope_outscope_service.time.sleep", sleeps.append)
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_LLM_MAX_ATTEMPTS", 4)
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_LLM_RETRY_BASE_SECONDS", 2)

    result = service._invoke_llm_with_backoff(model, ["prompt"], stage="judge:test")

    assert result == "ok"
    assert model.invoke.call_count == 3
    assert sleeps == [2, 4]


def test_llm_invoke_honors_provider_retry_delay(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    model = MagicMock()
    model.invoke.side_effect = [RuntimeError("429 retry in 60s"), "ok"]
    sleeps = []
    monkeypatch.setattr("service.inscope_outscope_service.time.sleep", sleeps.append)

    assert service._invoke_llm_with_backoff(model, ["prompt"], stage="judge:test") == "ok"
    assert sleeps == [60.0]


def test_llm_invoke_does_not_retry_permanent_errors(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    model = MagicMock()
    model.invoke.side_effect = ValueError("invalid request")
    sleeps = []
    monkeypatch.setattr("service.inscope_outscope_service.time.sleep", sleeps.append)

    with pytest.raises(ValueError, match="invalid request"):
        service._invoke_llm_with_backoff(model, ["prompt"], stage="judge:test")

    model.invoke.assert_called_once()
    assert sleeps == []


def test_llm_invoke_stops_on_daily_quota_exhaustion(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    model = MagicMock()
    model.invoke.side_effect = RuntimeError(
        "RESOURCE_EXHAUSTED: Generate content requests per day limit exceeded. "
        "Please retry in 14h30m24.5s."
    )
    sleeps = []
    monkeypatch.setattr("service.inscope_outscope_service.time.sleep", sleeps.append)

    with pytest.raises(RuntimeError, match="per day limit exceeded"):
        service._invoke_llm_with_backoff(model, ["prompt"], stage="judge:test")

    model.invoke.assert_called_once()
    assert sleeps == []
    assert service._provider_retry_delay_seconds(model.invoke.side_effect) == pytest.approx(
        14 * 3600 + 30 * 60 + 24.5
    )



