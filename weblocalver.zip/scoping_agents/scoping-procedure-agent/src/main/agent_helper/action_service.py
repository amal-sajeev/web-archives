import os
import sys
import json
import site
from datetime import datetime, timezone
import uuid
import logging
from pathlib import Path

# Dynamically locate the action-service root containing action_client and insert it into sys.path
current = Path(__file__).resolve()
action_service_root = None
for parent in current.parents:
    if (parent / "action_client").exists() or parent.name == "action-service":
        action_service_root = parent
        break

if action_service_root:
    if str(action_service_root) not in sys.path:
        sys.path.insert(0, str(action_service_root))
else:
    fallback_idx = min(5, len(current.parents) - 1)
    if fallback_idx >= 0 and str(current.parents[fallback_idx]) not in sys.path:
        sys.path.insert(0, str(current.parents[fallback_idx]))

# Ensure sys.modules["config"] is bound to site-packages/config for importlib.resources
try:
    import helper
    import importlib.util

    sp_config_dir = Path(helper.__file__).resolve().parent.parent / "config"
    agent_config_dir = current.parent.parent / "config"
    if sp_config_dir.is_dir() and (sp_config_dir / "app.yml").exists():
        current_config = sys.modules.get("config")
        sp_init = sp_config_dir / "__init__.py"
        if not current_config or getattr(current_config, "__file__", None) != str(sp_init):
            search_locs = [str(sp_config_dir)]
            if agent_config_dir.is_dir() and str(agent_config_dir) not in search_locs:
                search_locs.append(str(agent_config_dir))
            spec = importlib.util.spec_from_file_location(
                "config",
                str(sp_init),
                submodule_search_locations=search_locs,
            )
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                sys.modules["config"] = mod
                spec.loader.exec_module(mod)

        mod = sys.modules.get("config")
        if mod and hasattr(mod, "__path__"):
            if not isinstance(mod.__path__, list):
                mod.__path__ = list(mod.__path__)
            if agent_config_dir.is_dir() and str(agent_config_dir) not in mod.__path__:
                mod.__path__.append(str(agent_config_dir))
            if hasattr(mod, "__spec__") and mod.__spec__ and hasattr(mod.__spec__, "submodule_search_locations"):
                if agent_config_dir.is_dir() and mod.__spec__.submodule_search_locations and str(agent_config_dir) not in mod.__spec__.submodule_search_locations:
                    mod.__spec__.submodule_search_locations.append(str(agent_config_dir))
except Exception:
    pass

logger = logging.getLogger(__name__)

try:
    from action_client import ActionServiceClt
    action_clt = ActionServiceClt()
except Exception as exc:
    logger.warning("Failed to initialize ActionServiceClt (fallback to pass-through for testing/offline environments): %s", exc)

    class _FallbackActionClient:
        def persist_action(self, func):
            return func

    action_clt = _FallbackActionClient()

@action_clt.persist_action
def call_to_action_service(agent_card, data):
    """
    Format and stream the CTA_ACTION payload block to the ledger database.
    """
    now_utc = datetime.now(timezone.utc)
    # Standard ISO 8601 format with full seconds precision for PostgreSQL TIMESTAMP columns
    create_ts = now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")

    action_id = agent_card.get("ACTION_ID") or str(uuid.uuid4())
    entity_id = agent_card.get("ENTITY_ID") or str(uuid.uuid4())
    correlation_id = agent_card.get("CORRELATION_ID") or entity_id
    parent_entity_id = agent_card.get("PARENT_ENTITY_ID", "")
    entity_type = agent_card.get("ENTITY_TYPE") or "DISCOVERY_WALKTHROUGH"
    activity_type = agent_card.get("ACTIVITY_TYPE") or entity_type
    actor_type = agent_card.get("ACTOR_TYPE", "HUMAN")
    actor_id = agent_card.get("ACTOR_ID", "dbaware@db.com")
    action_type = agent_card.get("ACTION_TYPE", "GENERATE")
    parent_entity_type = agent_card.get("PARENT_ENTITY_TYPE", "scoping")

    if isinstance(data, dict) and "correlation_id" not in data:
        data["correlation_id"] = correlation_id

    payload_str = json.dumps(data, default=str) if not isinstance(data, str) else data

    json_data = {
        "CTA_ACTION": {
            "entity_id": entity_id,
            "action_id": action_id,
            "entity_type": entity_type,
            "create_ts": create_ts,
            "insert_ts": create_ts,
            "actor_type": actor_type,
            "actor_id": actor_id,
            "action_type": action_type,
            "parent_entity_type": parent_entity_type,
            "parent_entity_id": parent_entity_id,
            "payload": payload_str,
            "activity_type": activity_type,
        }
    }
    return json_data

def construct_human_actor_record(agent_card, query):
    """Logs the human instruction payload prior to executing LLM analytical tasks."""
    agent_card['ACTOR_TYPE'] = 'HUMAN'
    agent_card['ACTOR_ID'] = 'dbaware@db.com'
    agent_card['ACTION_TYPE'] = 'GENERATE'

    data = {
        "action_type": "GENERATE",
        "Human_Notes": query,
        "Remarks": ""
    }
    call_to_action_service(agent_card, data)

def construct_ai_actor_record(agent_card,
                              total_input_tokens=0,
                              total_output_tokens=0,
                              final_answer="",
                              start_time=None,
                              end_time=None,
                              score=1.0,
                              reasoning="",
                              env_config=None,
                              prompt_version="1.0"):
                                  
    """Logs the generated artifact and system metrics generated by the Gemini model."""
    agent_card['ACTOR_TYPE'] = 'AI_AGENT'
    agent_card['ACTION_TYPE'] = 'RESPONSE'
    agent_card['ACTOR_ID'] = 'dbaware@db.com'

    model_name = (
        os.getenv("GENAI_MODEL_NAME")
        or os.getenv("GCP_MODEL_NAME")
        or os.getenv("model_name")
        or "gemini-2.5-pro"
    )
    top_k = os.getenv("MODEL_TOP_K", "40")
    top_p = os.getenv("MODEL_TOP_P", "0.9")
    temperature = os.getenv("MODEL_TEMPERATURE", "0.0")
    if env_config:
        model_name = (
            env_config.get_env_config("GENAI_MODEL_NAME", None)
            or env_config.get_env_config("GCP_MODEL_NAME", "gemini-2.5-pro")
        )
        top_k = str(env_config.get_env_config("MODEL_TOP_K", "40"))
        top_p = str(env_config.get_env_config("MODEL_TOP_P", "0.9"))
        temperature = str(env_config.get_env_config("MODEL_TEMPERATURE", "0.0"))
    model_version = model_name.split('-', 1)[1] if '-' in model_name else "2.5"

    data = {
        'Remarks': '',
        'Agent_Name': agent_card['ACTOR_ID'],
        'action_type': 'RESPONSE',
        'AI_Rationale': reasoning,
        'AI_Model_Name': model_name,
        'AI_Model_Version': model_version,
        'Prompt_Version': prompt_version,
        'Response_Code': 200,
        'Response_Text': final_answer,
        'Token_Input_Count': total_input_tokens,
        'Token_Output_Count': total_output_tokens,
        'AI_Confidence_Score': float(score) if score is not None else 1.0,
        'Execution_Start_Time': (
            start_time.strftime("%Y-%m-%dT%H:%M:%SZ")
            if isinstance(start_time, datetime)
            else str(start_time)
        ),
        'Execution_End_Time': (
            end_time.strftime("%Y-%m-%dT%H:%M:%SZ")
            if isinstance(end_time, datetime)
            else str(end_time)
        ),
        'AI_Model_Config_Setting': {
            'model_top_k': top_k,
            'model_top_p': top_p,
            'model_temperature': temperature
        }
    }
    call_to_action_service(agent_card, data)

def construct_human_update_record(agent_card, remarks="", payload=None):
    """Logs human edits and revisions."""
    agent_card['ACTOR_TYPE'] = 'HUMAN'
    agent_card['ACTOR_ID'] = 'dbaware@db.com'
    agent_card['ACTION_TYPE'] = 'REVISE'
    call_to_action_service(agent_card, payload or {"Remarks": remarks, "action_type": "REVISE"})


def audit_human_request(
    activity_type: str,
    query: str,
    plan_number: str,
    entity_type: str,
    request_obj: object | None = None,
) -> tuple[dict, datetime]:
    """
    Initializes the agent card, records the initial human request, and returns
    the card along with the start timestamp for AI latency tracking.
    """
    from agent_helper.agent_card import build_agent_card

    start_time = datetime.now(timezone.utc)
    session_id = (
        getattr(request_obj, "entity_id", None)
        or getattr(request_obj, "correlation_id", None)
        or str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{plan_number}:{entity_type}"))
    )
    agent_card = build_agent_card(
        activity_type=activity_type,
        query=query,
        plan_item_number=plan_number,
        correlation_id=session_id,
    )
    agent_card.update({
        "ENTITY_ID": session_id,
        "ENTITY_TYPE": entity_type,
        "PARENT_ENTITY_TYPE": "scoping",
        "PARENT_ENTITY_ID": plan_number,
        "CORRELATION_ID": session_id,
        "ACTIVITY_TYPE": activity_type,
    })
    construct_human_actor_record(agent_card, query)
    return agent_card, start_time


def audit_human_update(
    activity_type: str,
    entity_type: str,
    plan_number: str,
    remarks: str,
    payload: dict,
    request_obj: object | None = None,
) -> dict:
    """Initializes the agent card and logs a human update/revision record."""
    from agent_helper.agent_card import build_agent_card

    session_id = (
        getattr(request_obj, "entity_id", None)
        or getattr(request_obj, "correlation_id", None)
        or str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{plan_number}:{entity_type}"))
    )
    agent_card = build_agent_card(
        activity_type=activity_type,
        query=remarks,
        plan_item_number=plan_number,
        correlation_id=session_id,
    )
    agent_card.update({"ENTITY_ID": session_id, "ENTITY_TYPE": entity_type, "PARENT_ENTITY_TYPE": "scoping", "PARENT_ENTITY_ID": plan_number, "CORRELATION_ID": session_id, "ACTIVITY_TYPE": activity_type})
    construct_human_update_record(agent_card=agent_card, remarks=remarks, payload=payload)
    return agent_card


def audit_generation_start(
    activity_type: str,
    entity_type: str,
    plan_number: str,
    description: str,
    request_obj: object | None = None,
) -> tuple[dict, datetime]:
    """Helper to start and audit a generation request."""
    query = f"Generate {description} for plan number {plan_number}"
    return audit_human_request(
        activity_type=activity_type,
        query=query,
        plan_number=plan_number,
        entity_type=entity_type,
        request_obj=request_obj,
    )


def audit_revision(
    activity_type: str,
    entity_type: str,
    plan_number: str,
    request_obj: object,
    description: str,
) -> dict:
    """Helper to audit updates and revisions across endpoints."""
    updated_sections = (
        list(request_obj.model_dump(exclude={"planNumber"}, exclude_unset=True).keys())
        if hasattr(request_obj, "model_dump")
        else []
    )
    payload = {
        "action_type": "REVISE",
        "Human_Notes": f"Update {description} for plan {plan_number}",
        "Remarks": "",
        "updated_sections": updated_sections,
    }
    return audit_human_update(
        activity_type=activity_type,
        entity_type=entity_type,
        plan_number=plan_number,
        remarks=f"User updated {description} for plan {plan_number}",
        payload=payload,
        request_obj=request_obj,
    )


def audit_ai_response(
    agent_card: dict,
    start_time: datetime,
    result_payload: object,
    default_reasoning: str = "Execution completed successfully.",
    usage_metadata: dict | None = None,
) -> None:
    """Extracts summary, latency, confidence, and logs an AI response audit record."""
    end_time = datetime.now(timezone.utc)
    if hasattr(result_payload, "model_dump"):
        payload_data = result_payload.model_dump()
    elif hasattr(result_payload, "dict"):
        payload_data = result_payload.dict()
    elif isinstance(result_payload, dict):
        payload_data = result_payload
    else:
        payload_data = {}

    plan_number = agent_card.get("PARENT_ENTITY_ID") or agent_card.get("ENTITY_ID") or ""
    activity_type = agent_card.get("ACTIVITY_TYPE") or "scoping procedure"

    if getattr(result_payload, "normalized_summary_uri", None):
        final_answer = f"Meeting notes consolidated successfully for plan {plan_number}. Summary URI: {result_payload.normalized_summary_uri}"
    elif "test_steps" in payload_data:
        step_count = len(payload_data.get("test_steps", []))
        final_answer = f"Successfully generated {step_count} test steps for plan {plan_number}."
    elif "inscope" in payload_data and "outscope" in payload_data:
        final_answer = f"Successfully generated in-scope and out-of-scope determinations for plan {plan_number}."
    elif "sections" in payload_data:
        section_count = len(payload_data.get("sections", []))
        final_answer = f"Successfully generated discovery walkthrough ({section_count} sections) for plan {plan_number}."
    else:
        final_answer = f"Successfully completed {activity_type} for plan {plan_number}."

    score = (
        float(payload_data.get("confidence_score", 100)) / 100.0
        if isinstance(payload_data, dict) and "confidence_score" in payload_data
        else 1.0
    )
    reasoning = (
        str(payload_data.get("rationale", default_reasoning))
        if isinstance(payload_data, dict) and "rationale" in payload_data
        else default_reasoning
    )
    usage = usage_metadata or {}
    construct_ai_actor_record(
        agent_card=agent_card,
        total_input_tokens=int(usage.get("input_tokens", 0) or 0),
        total_output_tokens=int(usage.get("output_tokens", 0) or 0),
        final_answer=final_answer,
        start_time=start_time,
        end_time=end_time,
        score=score,
        reasoning=reasoning,
    )