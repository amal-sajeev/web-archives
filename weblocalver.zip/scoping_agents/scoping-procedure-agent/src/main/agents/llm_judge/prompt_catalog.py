"""Load scope recommendation judge and refinement prompts from etc/prompts JSON files."""

import json
import os
import re
from pathlib import Path

PROMPT_DIRECTORY = Path(__file__).resolve().parents[2] / "etc" / "prompts"
JUDGE_PROMPT_FILE = PROMPT_DIRECTORY / "scope_recommendation_judge_prompt.json"
REFINEMENT_PROMPT_FILE = PROMPT_DIRECTORY / "scope_recommendation_refinement_prompt.json"
_REQUIRED_SECTIONS = {
    "persona",
    "definitions",
    "instructions",
    "evaluation_criteria",
    "common_failure_modes",
    "scoring_rules",
    "output_specification",
    "output_example",
    "analysis_section",
}


def _section_text(section: object) -> str:
    if not isinstance(section, dict):
        return ""
    content = section.get("content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        return "\n".join(str(line).strip() for line in content if str(line).strip())
    return ""


def _parse_comment_metadata(comment: str) -> dict[str, str]:
    return dict(re.findall(r"(\w+)=([^\s]+)", str(comment or "")))


def _normalize_judge_catalog(payload: dict, path: Path) -> dict:
    prompt_instructions = payload.get("prompt_instructions")
    if not isinstance(prompt_instructions, dict) or _REQUIRED_SECTIONS - prompt_instructions.keys():
        raise ValueError(f"Invalid scope judge prompt structure: {path.name}")

    meta = _parse_comment_metadata(payload.get("_comment", ""))
    criteria_block = prompt_instructions["evaluation_criteria"]
    rubric_calls = [
        {
            "name": key,
            "criteria": list(value.get("criteria") or [key]),
            "instructions": _section_text(value),
        }
        for key, value in criteria_block.items()
        if key != "title" and isinstance(value, dict)
    ]
    if not rubric_calls:
        raise ValueError(f"Scope judge prompt has no rubric evaluation criteria: {path.name}")

    review_sections = [
        _section_text(prompt_instructions[section])
        for section in (
            "persona",
            "definitions",
            "instructions",
            "common_failure_modes",
            "scoring_rules",
            "output_specification",
            "analysis_section",
        )
    ]
    return {
        "date": meta.get("date", "2026-11-06"),
        "version": meta.get("version", "1.1.0"),
        "prompt_instructions": prompt_instructions,
        "review_prompt": "\n\n".join(part for part in review_sections if part) + "\n",
        "rubric_calls": rubric_calls,
    }


def load_prompt_catalog(version: str | None = None) -> dict:
    if not JUDGE_PROMPT_FILE.exists():
        raise FileNotFoundError(f"Judge prompt file not found: {JUDGE_PROMPT_FILE}")
    catalog = _normalize_judge_catalog(
        json.loads(JUDGE_PROMPT_FILE.read_text(encoding="utf-8")), JUDGE_PROMPT_FILE
    )
    requested = version or os.getenv("SCOPE_RECOMMENDATION_JUDGE_PROMPT_VERSION")
    if requested and catalog.get("version") != requested:
        raise ValueError(f"Scope judge prompt version {requested!r} is unavailable")
    return catalog


def load_refinement_prompt(path: Path = REFINEMENT_PROMPT_FILE) -> str:
    if not path.exists():
        raise FileNotFoundError(f"Refinement prompt file not found: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    prompt_instructions = payload.get("prompt_instructions")
    if not isinstance(prompt_instructions, dict):
        raise ValueError(f"Refinement prompt must contain prompt_instructions: {path.name}")
    text = "\n\n".join(
        part for part in (_section_text(s) for s in prompt_instructions.values()) if part
    )
    if not text:
        raise ValueError(f"Refinement prompt is empty: {path.name}")
    return text


PROMPT_CATALOG = load_prompt_catalog()
SCOPE_REVIEW_PROMPT = PROMPT_CATALOG["review_prompt"]
SCOPE_REFINEMENT_PROMPT = load_refinement_prompt()
SCOPE_REVIEW_RUBRIC_CALLS = tuple(
    (item["name"], tuple(item["criteria"]), item["instructions"])
    for item in PROMPT_CATALOG["rubric_calls"]
)
