# Scoping Summary Agent

FastAPI service (root path `/scoping-summary-agent`) that analyzes extracted scoping data to produce preliminary research documents. Aggregates findings across data sources, resolves citations, and supports retrieving individual document/citation fragments, editing research findings, and exporting the final research document as a PDF.

## Endpoints

| Method | Path                                  | Description                                                                                    |
| ------ | ------------------------------------- | ---------------------------------------------------------------------------------------------- |
| POST   | `/list-all`                           | Read `historical_plan_details.json` for a plan and return `Plan Item Number`/`Plan Item Title` rows |
| POST   | `/run-analytics-agent`                | Run analytics on extracted plan data and generate a preliminary research document. Optional `sections` (`past_review`, `policy_regulation`, `broad_scope`) regenerates only those; others are kept from the latest stored document. Omit for all |
| POST   | `/get_document`                       | Retrieve a document page or citation chunk (`document_uri`/`chunk_id`, optional `page_number`) |
| POST   | `/get-preliminary-research-document`  | Retrieve the complete preliminary research document for a plan                                 |
| POST   | `/edit-preliminary-research-document` | Update the analysis report section of a research document                                      |
| POST   | `/download`                           | Export the research document (with citations/analysis) as a PDF                                |

## Configuration

- `src/main/config/config.py` — application settings and external service URLs
- `src/main/config/prompts.py` — LLM prompt templates

## Running locally

```bash
pip install -r requirements.txt
python src/main/app.py
```

## Docker / Helm

Build via the provided `Dockerfile`; deploy with the Helm chart in `helm-chart/` (`values-dev1.yaml`, `values-ct1.yaml`, `values-uat1.yaml`).

Persists data in table also.
