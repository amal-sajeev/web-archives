import asyncio
import importlib
import sys
import types
from pathlib import Path

import pytest


@pytest.fixture
def fake_genai(monkeypatch):
    captured = []

    class _FakeChatGoogleGenerativeAI:
        def __init__(self, **kwargs):
            captured.append(kwargs)
            self.kwargs = kwargs

    fake_mod = types.ModuleType("langchain_google_genai")
    fake_mod.ChatGoogleGenerativeAI = _FakeChatGoogleGenerativeAI
    monkeypatch.setitem(sys.modules, "langchain_google_genai", fake_mod)
    return captured


def test_google_oauth_token_provider_and_cert_helpers(monkeypatch, tmp_path):
    from utils import google_oauth_token_provider as gtp

    gtp._CERTIFICATE_CONFIGURED = False
    cert_file = tmp_path / "custom.pem"
    cert_file.write_text("-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----\n", encoding="utf-8")

    monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
    monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "true")
    monkeypatch.setenv("CUSTOM_CERT_PATHS", str(cert_file))

    combined = gtp.configure_certificate([str(cert_file)])
    assert Path(combined).exists()
    assert "BEGIN CERTIFICATE" in Path(combined).read_text(encoding="utf-8")

    gtp._CERTIFICATE_CONFIGURED = False
    gtp.configure_certificate_once()
    assert gtp._CERTIFICATE_CONFIGURED is True
    assert Path(gtp.os.environ["REQUESTS_CA_BUNDLE"]).exists()

    # Non-PEM and missing cert errors
    bad_cert = tmp_path / "bad.pem"
    bad_cert.write_text("not-a-cert", encoding="utf-8")
    with pytest.raises(ValueError):
        gtp.configure_certificate([])
    with pytest.raises(FileNotFoundError):
        gtp.configure_certificate([str(tmp_path / "missing.pem")])
    with pytest.raises(ValueError):
        gtp.configure_certificate([str(bad_cert)])

    # Kubernetes runtime path
    gtp._CERTIFICATE_CONFIGURED = False
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    monkeypatch.setenv("CA_BUNDLE_PATH", "/etc/ssl/custom-ca.pem")
    gtp.configure_certificate_once()
    assert gtp.os.environ["SSL_CERT_FILE"] == "/etc/ssl/custom-ca.pem"

    # Token refresh behavior
    class _FakeCreds:
        def __init__(self):
            self.valid = False
            self.token = "oauth-token-123"
            self.refreshed = False

        def refresh(self, req):
            self.valid = True
            self.refreshed = True

    monkeypatch.setattr(gtp, "default", lambda scopes=None: (_FakeCreds(), "proj"))
    provider = gtp.GoogleOAuthTokenProvider()
    assert provider.token == "oauth-token-123"
    assert provider.credentials.refreshed is True


def test_initialize_gemini_model_uses_ai_access_layer_without_banned_kwargs(monkeypatch, fake_genai):
    from utils import gemini_connection

    importlib.reload(gemini_connection)

    monkeypatch.setenv("AI_ACCESS_LAYER_BASE_URL", "https://ai-access.internal.example/v1")
    monkeypatch.setattr(
        gemini_connection,
        "configure_certificate_once",
        lambda: None,
    )

    class _FakeTokenProvider:
        token = "bearer-oauth-xyz"

    monkeypatch.setattr(gemini_connection, "GoogleOAuthTokenProvider", _FakeTokenProvider)

    model = gemini_connection.initialize_gemini_model()
    assert model.kwargs["base_url"] == "https://ai-access.internal.example/v1"
    assert model.kwargs["api_key"] == "bearer-oauth-xyz"
    assert model.kwargs["model"]
    for banned in ("project", "location", "temperature", "top_p", "top_k", "seed"):
        assert banned not in model.kwargs

    # Fallback when no base_url is configured: requires GOOGLE_API_KEY
    monkeypatch.delenv("AI_ACCESS_LAYER_BASE_URL", raising=False)
    monkeypatch.delenv("GENAI_BASE_URL", raising=False)
    monkeypatch.setattr(gemini_connection.Config, "AI_ACCESS_LAYER_BASE_URL", None, raising=False)
    monkeypatch.setattr(gemini_connection.Config, "GENAI_BASE_URL", None, raising=False)
    monkeypatch.setenv("GOOGLE_API_KEY", "direct-api-key")
    model_direct = gemini_connection.initialize_gemini_model()
    assert model_direct.kwargs["api_key"] == "direct-api-key"
    assert "base_url" not in model_direct.kwargs

    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    with pytest.raises(ValueError):
        gemini_connection.initialize_gemini_model()


def test_filter_lrr_data_with_table_meta_and_enriched_preference(monkeypatch):
    from utils import data_manager

    raw_lrr = [
        {
            "Risk Name": "Compliance Risk",
            "Mandates": [
                {"Regulatory Mandate": "FINRA Rule 3110", "Evidence": []},
                {"Regulatory Mandate": "SEC Rule 17a-4", "Evidence": []},
            ],
        },
        {
            "Risk Name": "Excluded Risk Inline",
            "status": "excluded",
            "Mandates": [
                {"Regulatory Mandate": "Inline Excluded Mandate", "Evidence": []},
            ],
        },
        {
            "Risk Name": "Credit Risk",
            "Mandates": [
                {"Regulatory Mandate": "CRR Article 92", "Evidence": []},
            ],
        },
    ]

    meta = {
        "documents": [
            {
                "filename": "internet_search_data_enriched.json",
                "status": "active",
                "excluded": False,
                "sections": [
                    {"section_id": 2, "section_title": "SEC Rule 17a-4", "node_id": "lrr:mandate:2", "status": "excluded", "excluded": True},
                    {"section_id": 4, "section_title": "CRR Article 92", "node_id": "lrr:mandate:4", "status": "excluded", "excluded": True},
                ],
            }
        ]
    }
    filtered = data_manager._filter_lrr_data_with_table_meta(raw_lrr, meta)
    assert len(filtered) == 1
    assert filtered[0]["Risk Name"] == "Compliance Risk"
    assert [m["Regulatory Mandate"] for m in filtered[0]["Mandates"]] == ["FINRA Rule 3110"]

    # Whole source excluded returns empty list
    excluded_meta = {"documents": [{"filename": "internet_search_data_enriched.json", "excluded": True, "status": "excluded"}]}
    assert data_manager._filter_lrr_data_with_table_meta(raw_lrr, excluded_meta) == []

    # read_plan_json prefers internet_search_data_enriched.json over internet_search_data.json
    checked = []

    def fake_blob_exists(path):
        checked.append(path)
        return path.endswith("internet_search_data_enriched.json")

    monkeypatch.setattr(data_manager, "blob_exists", fake_blob_exists)
    monkeypatch.setattr(data_manager, "read_blob_json", lambda path: raw_lrr)
    path, loaded = data_manager.read_plan_json("20440", "lrr", "internet_search_data.json", source_meta=meta)
    assert path is not None and path.endswith("internet_search_data_enriched.json")
    assert checked[0].endswith("internet_search_data_enriched.json")
    assert [m["Regulatory Mandate"] for m in loaded[0]["Mandates"]] == ["FINRA Rule 3110"]


def test_build_regulation_manifest_skips_excluded_risks_and_mandates():
    from utils.policy_section_builder import build_regulation_manifest

    chunks = [
        {
            "source_name": "internet_search",
            "chunk_id": 5,
            "content": [
                {
                    "Risk Name": "Compliance Risk",
                    "Mandates": [
                        {"Regulatory Mandate": "Active Mandate", "Confidence Score": 0.9, "Evidence": []},
                        {"Regulatory Mandate": "Soft Excluded Mandate", "excluded": True, "Evidence": []},
                        {"Regulatory Mandate": "Status Inactive Mandate", "status": "inactive", "Evidence": []},
                    ],
                },
                {
                    "Risk Name": "Excluded Risk Block",
                    "status": "excluded",
                    "Mandates": [
                        {"Regulatory Mandate": "Hidden Under Risk", "Evidence": []},
                    ],
                },
            ],
        }
    ]
    manifest = build_regulation_manifest(chunks)
    assert [m["mandate"] for m in manifest] == ["Active Mandate"]


def test_partial_regeneration_merges_existing_citation_mapping(monkeypatch):
    from service import analytics_service
    from agents import analytics_agent

    previous_report = {
        entry["title"]: {"report_title": entry["title"], "paragraphs": []}
        for entry in analytics_agent.SECTION_REGISTRY.values()
    }
    existing_citations = {
        "POLICY|1|1": [{"document_name": "Existing Policy", "access_info": {"uri": "gs://b/p.pdf"}}],
    }
    written = {}

    monkeypatch.setattr(analytics_service, "get_plan_output_blob_path", lambda plan, name: f"{plan}/{name}")
    monkeypatch.setattr(
        analytics_service,
        "_resolve_sections_to_generate",
        lambda plan, sections=None: asyncio.sleep(0, (["broad_scope"], previous_report)),
    )
    monkeypatch.setattr(
        analytics_service,
        "read_plan_data_async",
        lambda plan: asyncio.sleep(0, ({"output1": [], "output2": [], "output3": []}, {"9": [{"document_name": "New Doc", "access_info": {"uri": "gs://b/n.pdf"}}]})),
    )
    monkeypatch.setattr(
        analytics_service,
        "run_analytics_agent",
        lambda plan, data, progress_callback=None, sections=None: asyncio.sleep(
            0, {"Broad Scope Direction": {"report_title": "Broad Scope Direction", "paragraphs": []}}
        ),
    )
    monkeypatch.setattr(analytics_service, "read_blob_json", lambda path: existing_citations)
    monkeypatch.setattr(analytics_service, "write_blob_json", lambda path, payload: written.__setitem__(path, payload) or path)
    monkeypatch.setattr(
        analytics_service,
        "write_preliminary_research_sections",
        lambda plan, report: asyncio.sleep(0, {"broad_scope": "ok"}),
    )

    asyncio.run(analytics_service.run_analytics_task("20440", sections=["broad_scope"]))
    merged_citations = written["20440/citation_mapping.json"]
    assert "POLICY|1|1" in merged_citations
    assert "9" in merged_citations


def test_review_data_extraction_repository_uses_review_scope_id(monkeypatch):
    from persistor import review_data_extraction_repository as rde
    from unittest.mock import MagicMock

    fake_row = rde.ReviewDataExtractionORM(
        review_scope_dataext_id=10,
        review_scope_id=20440,
        data_source="policy",
        metadata_={"documents": [{"filename": "policy1.json", "document_title": "Policy 1", "excluded": False, "sections": []}]},
        status=1,
    )
    fake_session = MagicMock()
    fake_session.execute.return_value.fetchall.return_value = [(20440,)]
    fake_session.query.return_value.filter.return_value.order_by.return_value.all.return_value = [fake_row]

    monkeypatch.setattr(rde.Config, "db_pass", "secret", raising=False)
    monkeypatch.setattr(rde, "get_session", lambda: fake_session)

    meta_map = rde.get_data_extraction_metadata_map("20440")
    assert "policy" in meta_map
    assert meta_map["policy"]["review_scope_id"] == 20440
    assert meta_map["policy"]["review_scope_instance_id"] == "20440"
    assert meta_map["policy"]["documents"][0]["filename"] == "policy1.json"


def test_summary_ignores_status_zero_drops_empty_gfms_wrappers_and_supports_sources(monkeypatch):
    from persistor import review_data_extraction_repository as rde
    from utils import data_manager as dm, policy_section_builder as psb
    from unittest.mock import MagicMock

    inactive_row = rde.ReviewDataExtractionORM(
        review_scope_dataext_id=12,
        review_scope_id=20440,
        data_source="gfms",
        metadata_={"documents": [{"document_id": "findings_details", "excluded": True}]},
        status=0,
    )
    fake_session = MagicMock()
    fake_session.execute.return_value.fetchall.return_value = [(20440,)]
    fake_session.query.return_value.filter.return_value.order_by.return_value.all.return_value = [inactive_row]
    monkeypatch.setattr(rde.Config, "db_pass", "secret", raising=False)
    monkeypatch.setattr(rde, "get_session", lambda: fake_session)
    assert rde.get_data_extraction_metadata_map("20440") == {}

    gfms_raw = [{"statusCode": 200, "responsePayload": [{"findingId": "F-1"}]}]
    gfms_meta = {"documents": [{"document_id": "findings_details", "excluded": False, "sections": [{"section_id": "F-1", "excluded": True}]}]}
    assert dm._filter_findings_data_with_table_meta(gfms_raw, gfms_meta) == []

    docs = psb._documents_from_content({"sources": [{"document_name": "P1.pdf", "excluded": False}, {"document_name": "P2.pdf", "excluded": True}]})
    assert [d["document_name"] for d in docs] == ["P1.pdf"]


def test_policy_section_exclusion_via_data_extraction_table_drops_excluded_section_only(monkeypatch):
    from utils import data_manager, policy_section_builder as psb

    table_meta = {
        "policy": {
            "source_type": "policy",
            "documents": [
                {
                    "filename": "policy5.json",
                    "document_id": "5",
                    "document_title": "Supervision_Policy",
                    "storage_uri": "gs://test-bucket/policy/relevant_policy/policy5.json",
                    "status": "active",
                    "excluded": False,
                    "sections": [
                        {
                            "section_id": "2.6",
                            "section_title": "Supervisory Hierarchy",
                            "node_id": "5:section:2.6",
                            "status": "active",
                            "excluded": False,
                        },
                        {
                            "section_id": "4",
                            "section_title": "List of Annexes and Attachments",
                            "node_id": "5:section:4",
                            "status": "excluded",
                            "excluded": True,
                        },
                    ],
                }
            ],
        }
    }
    policy5_payload = {
        "document_id": "5",
        "document_title": "Supervision_Policy",
        "document_relevance_score": 79.33,
        "document_relevance_verdict": "HIGH",
        "rationale": "Relevant policy.",
        "nodes": [
            {
                "node_id": "node-keep-2-6",
                "section_id": "2.6",
                "section_title": "Supervisory Hierarchy",
                "original_text": "Mandates reporting line structures.",
                "page_start": 5,
                "page_end": 5,
            },
            {
                "node_id": "node-drop-4",
                "section_id": "4",
                "section_title": "List of Annexes and Attachments",
                "original_text": "Annex 1 and Annex 2 details.",
                "page_start": 10,
                "page_end": 12,
            },
        ],
    }

    monkeypatch.setattr(data_manager, "get_data_extraction_metadata_map", lambda plan_number: table_meta)
    monkeypatch.setattr(data_manager.Config, "REVIEW_BUCKET_NAME", "test-bucket")
    monkeypatch.setattr(
        data_manager,
        "list_blob_paths",
        lambda prefix: ["dbaware_review_20429/inbound-data/policy/relevant_policy/policy5.json"],
    )
    monkeypatch.setattr(data_manager, "read_blob_json", lambda path: policy5_payload)

    cfg = {
        "folder": "policy",
        "file_name": "relevant_policy.json",
        "parts_folder": "policy/relevant_policy",
    }
    _, documents = asyncio.run(data_manager.read_plan_json_parts_async("20429", cfg))
    assert len(documents) == 1
    assert [n["section_id"] for n in documents[0]["nodes"]] == ["2.6"]

    manifest = psb.build_policy_manifest([
        {"chunk_id": 4, "source_name": "relevant_policy", "content": documents}
    ])
    manifest_docs = manifest["relevant_policy"]["documents"]
    assert len(manifest_docs) == 1
    assert [sec["section_id"] for sec in manifest_docs[0]["sections"]] == ["2.6"]
    assert [sec["section_title"] for sec in manifest_docs[0]["sections"]] == ["Supervisory Hierarchy"]
