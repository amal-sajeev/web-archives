from model.response_model import PolicyRegulationOutput
from utils.policy_section_builder import (
    MISSING_SUMMARY_TEXT,
    assemble_policy_report,
    build_policy_manifest,
    build_regulation_manifest,
    regulation_citation_mapping,
    to_model_source_chunks,
)

RATIONALE = "Highly relevant because Section 4.5.4 mandates quarterly reviews.\nSecond line kept as-is."


def _node(section_id, title, path, text, page):
    return {
        "section_id": section_id,
        "section_title": title,
        "section_path": path,
        "original_text": text,
        "page_start": page,
        "page_end": page,
        "node_id": f"1:section:{section_id}",
    }


def _source_chunks():
    policy_doc = {
        "document_id": "1",
        "document_title": "German_Bank_Separation_Act__GBSA__-_Global",
        "document_version": "1.0",
        "storage_uri": "gs://bucket/gbsa.pdf",
        "document_relevance_score": 57.736,
        "document_relevance_verdict": "HIGH",
        "rationale": RATIONALE,
        "nodes": [
            _node("4.10", "Late", ["Section 4 Trading"], "text 4.10", 60),
            _node("4.5.4", "Detective Controls", ["Section 4 Trading", "Section 4.5 Governance"], "text 4.5.4", 50),
            _node("2.3", "Governance", ["Section 2 Prop"], "text 2.3 a", 19),
            _node("4.5", "Governance", ["Section 4 Trading"], "text 4.5", 48),
            _node("2.3", "Governance", ["Section 2 Prop"], "text 2.3 b", 20),
            _node("5(GBSA)", "(GBSA)", ["Section 5 Glossary"], "text gbsa", 52),
        ],
    }
    kod_doc = {
        "document_id": "1",
        "document_title": "KOD_One",
        "document_version": "2.0",
        "document_relevance_score": 3.14159,
        "document_relevance_verdict": "medium",
        "rationale": "Brief KOD rationale.",
        "nodes": [_node("1.1", "Intro", [], "kod text", 1)],
    }
    return [
        {"chunk_id": 1, "source_name": "current_plan_item_details", "content": {"plan": "x"}},
        {"chunk_id": 2, "source_name": "relevant_kod", "content": [kod_doc]},
        {"chunk_id": 3, "source_name": "relevant_procedure", "content": {}},
        {"chunk_id": 4, "source_name": "relevant_policy", "content": [policy_doc]},
        {"chunk_id": 5, "source_name": "internet_search", "content": [{
            "Risk Name": "R032 - Employee Licensing",
            "Mandates": [{
                "Regulatory Mandate": "Designate a registered principal.",
                "Confidence Score": 1.0,
                "AI Rationale": "Maps to R032.",
                "Evidence": [{
                    "source_url": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110",
                    "evidence_text": "(2) The designation...",
                    "deep_link": "https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110#:~:text=The%20designation",
                }],
            }, {
                "Regulatory Mandate": "Second mandate.",
                "AI Rationale": "Verbatim AI rationale.",
                "Evidence": [{"evidence_text": "Evidence with neither deep_link nor source_url."}],
            }],
        }]},
    ]


def _section(key, text="Summary.", applicability="Directly Applicable"):
    return {"key": key, "summary": text, "applicability": applicability, "relevance": "Impacts testing."}


def _model_output(policy_sections, extra_paragraphs=None):
    paragraphs = extra_paragraphs or []
    paragraphs.append({
        "paragraph_id": "x",
        "content": "Section 2: Obligation to Process and Control Traceability\nBody.",
        "supporting_chunk_ids": ["4"],
        "metadata": {"is_section_start": True, "section_confidence_score": 60},
    })
    return PolicyRegulationOutput.model_validate({
        "section1": {
            "intro": "Review intro.",
            "rationale": "Section rationale.",
            "confidence_score": 75,
            "document_assessments": [
                {"doc_key": "POLICY|1", "sections": policy_sections},
                {"doc_key": "KOD|1", "sections": [_section("KOD|1|1.1")]},
                {"doc_key": "POLICY|99", "sections": []},
            ],
            "regulatory_mandates": {"mandates": [
                {"key": "REG|1|1", "name": "FINRA 3110 Principal Designation",
                 "applicability": "Directly Applicable", "content": "Requires a registered principal."},
                {"key": "REG|9|9", "name": "Unknown", "applicability": "Not Applicable", "content": "Unknown."},
            ]},
        },
        "report": {"report_title": "ignored", "paragraphs": paragraphs},
    })


def test_manifest_uses_unique_keys_merges_duplicates_and_sorts_naturally():
    manifest = build_policy_manifest(_source_chunks())

    policy_doc = manifest["relevant_policy"]["documents"][0]
    assert policy_doc["doc_key"] == "POLICY|1"
    assert policy_doc["storage_uri"] == "gs://bucket/gbsa.pdf"
    assert [s["section_id"] for s in policy_doc["sections"]] == ["2.3", "4.5", "4.5.4", "4.10", "5(GBSA)"]
    merged = policy_doc["sections"][0]
    assert merged["texts"] == ["text 2.3 a", "text 2.3 b"]
    assert (merged["page_start"], merged["page_end"]) == (19, 20)
    # Same document_id "1" in another file must not collide.
    assert manifest["relevant_kod"]["documents"][0]["sections"][0]["key"] == "KOD|1|1.1"
    assert manifest["relevant_procedure"]["documents"] == []

    model_chunks = to_model_source_chunks(_source_chunks(), manifest)
    policy_chunk = next(c for c in model_chunks if c["source_name"] == "relevant_policy")
    assert policy_chunk["chunk_id"] == 4
    assert policy_chunk["content"][0]["sections"][0]["text"] == "text 2.3 a\n\ntext 2.3 b"
    reg_chunk = next(c for c in model_chunks if c["source_name"] == "internet_search")
    assert reg_chunk["content"] == _source_chunks()[4]["content"]

    with_reg = to_model_source_chunks(_source_chunks(), manifest, build_regulation_manifest(_source_chunks()))
    reg_content = next(c for c in with_reg if c["source_name"] == "internet_search")["content"]
    assert [m["key"] for m in reg_content] == ["REG|1|1", "REG|1|2"]

    assert "deep_link" not in reg_content[0]["evidence"][0]


def test_regulation_citation_mapping_uses_deep_link():
    mapping = regulation_citation_mapping(build_regulation_manifest(_source_chunks()))

    entry = mapping["REG|1|1|1"][0]
    assert entry["url"].endswith("#:~:text=The%20designation")
    assert entry["citation_label"] == "finra.org 3110"
    


def test_assemble_builds_section1_from_source_and_matches_by_key():
    source_chunks = _source_chunks()
    manifest = build_policy_manifest(source_chunks)
    # Model returns sections out of order and omits 4.10.
    output = _model_output(
        [_section("POLICY|1|5(GBSA)"), _section("POLICY|1|4.5.4", "Detective summary."),
         _section("POLICY|1|2.3"), _section("POLICY|1|4.5")],
        extra_paragraphs=[{
            "paragraph_id": "y",
            "content": "Section 1: Policy, KOD/Procedure and Regulatory Analysis\nModel-written.",
            "supporting_chunk_ids": [],
            "metadata": {"is_section_start": True, "section_confidence_score": 50},
        }],
    )

    report = assemble_policy_report(output, manifest, source_chunks, "Policy, KOD and Regulatory Analysis")
    contents = [p.content for p in report.paragraphs]

    assert report.report_title == "Policy, KOD and Regulatory Analysis"
    assert [p.paragraph_id for p in report.paragraphs] == [f"para_{i}" for i in range(1, len(contents) + 1)]
    assert contents[0] == "Section 1: Policy, KOD/Procedure and Regulatory Analysis\nReview intro."
    assert report.paragraphs[0].metadata.is_section_start
    assert report.paragraphs[0].supporting_chunk_ids == ["1"]
    assert report.paragraphs[0].rationale == "Section rationale."
    assert report.paragraphs[0].metadata.heading_level is None

    assert contents[1] == "**Regulatory Mandates**"
    assert report.paragraphs[1].metadata.heading_level == 2
    # Applicability sits on the heading line; rationale comes verbatim from the source JSON.
    assert contents[2] == (
        "1. **FINRA 3110 Principal Designation** - Directly Applicable\n"
        "Maps to R032.\n"
        "Requires a registered principal."
    )
    assert report.paragraphs[2].metadata.heading_level == 3
    assert report.paragraphs[2].supporting_chunk_ids == ["REG|1|1|1"]
    # Missing model output falls back to the risk name and source mandate text, without applicability.
    assert contents[3] == "2. **R032 - Employee Licensing**\nVerbatim AI rationale.\nSecond mandate."
    assert report.paragraphs[3].supporting_chunk_ids == []
    assert report.paragraphs[4].metadata.heading_level == 2
    assert report.paragraphs[5].metadata.heading_level == 3
    assert report.paragraphs[6].metadata.heading_level is None
    del contents[1:4]
    contents.insert(1, "regulatory")
    paragraphs = report.paragraphs[:1] + [None] + report.paragraphs[4:]

    assert contents[2] == "**Policy**"
    policy_header = contents[3]
    assert policy_header == (
        "1. **German Bank Separation Act GBSA - Global** - Directly Applicable\n"
        "Relevance Score: 57.74\n"
        f"{RATIONALE}"
    )
    assert "Version" not in policy_header and "Rationale:" not in policy_header
    policy_sections = contents[4:9]
    assert [paragraph.supporting_chunk_ids for paragraph in paragraphs[4:9]] == [
        ["POLICY|1|2.3"], ["POLICY|1|4.5"], ["POLICY|1|4.5.4"],
        ["POLICY|1|4.10"], ["POLICY|1|5(GBSA)"],
    ]
    order = [policy_sections.index(next(text for text in policy_sections if marker in text)) for marker in (
        "<u>Section 2.3 Governance</u>",
        "<u>Section 4.5 Governance</u>",
        "<u>Section 4.5.4 Detective Controls</u>: Detective summary.",
        "<u>Section 4.10 Late</u>",
        "<u>Section 5(GBSA)</u>",
    )]
    assert order == sorted(order)
    # Parent headings from section_path are not rendered.
    for parent in ("Section 2 Prop", "Section 4 Trading", "Section 5 Glossary"):
        assert all(parent not in text for text in policy_sections)
    assert f"<u>Section 4.10 Late</u>: {MISSING_SUMMARY_TEXT}" in policy_sections[3]
    assert "Applicability: Directly Applicable. Impacts testing." in policy_sections[0]

    assert contents[9].startswith("**Procedure**\nData Not Available")
    assert contents[10] == "**KOD**"
    assert contents[11].startswith("1. **KOD One** - Partially Applicable\nRelevance Score: 3.14\nBrief KOD rationale.")
    assert "KOD rationale." not in contents[11].replace("Brief KOD rationale.", "")
    assert paragraphs[12].supporting_chunk_ids == ["KOD|1|1.1"]
    # Model's own Section 1 is discarded; Section 2 follows the assembled Section 1.
    assert contents[13].startswith("Section 2:")
    assert len(contents) == 14


def test_build_policy_manifest_filters_excluded_documents_and_reads_paragraphs():
    chunks = [
        {
            "chunk_id": 1,
            "source_name": "relevant_policy",
            "content": {
                "documents": [
                    {
                        "document_id": "keep-1",
                        "document_title": "Included Uploaded Policy",
                        "document_relevance_score": 88.0,
                        "document_relevance_verdict": "HIGH",
                        "rationale": "Included by user.",
                        "paragraphs": [
                            {
                                "section_id": "1.1",
                                "section_title": "Scope",
                                "content": "Uploaded paragraph content.",
                                "page_start": 1,
                                "page_end": 2,
                            }
                        ],
                    },
                    {
                        "document_id": "drop-1",
                        "document_title": "Excluded Policy Flag",
                        "excluded": True,
                        "nodes": [_node("1.1", "Ignored", [], "ignored text", 1)],
                    },
                    {
                        "document_id": "drop-2",
                        "document_title": "Removed Policy Status",
                        "status": "removed",
                        "nodes": [_node("1.2", "Ignored", [], "ignored text", 1)],
                    },
                ]
            },
        }
    ]
    manifest = build_policy_manifest(chunks)
    docs = manifest["relevant_policy"]["documents"]
    assert len(docs) == 1
    assert docs[0]["doc_key"] == "POLICY|1"
    assert docs[0]["title"] == "Included Uploaded Policy"
    assert len(docs[0]["sections"]) == 1
    assert docs[0]["sections"][0]["texts"] == ["Uploaded paragraph content."]




import asyncio
from utils import data_manager


def test_read_plan_json_parts_async_filters_excluded_docs_across_parts_and_registry(monkeypatch):
    monkeypatch.setattr(
        data_manager,
        "list_blob_paths",
        lambda prefix: [
            "dbaware_review_20086/inbound-data/policy/relevant_policy.json",
            "dbaware_review_20086/inbound-data/policy/relevant_policy/doc1.json",
            "dbaware_review_20086/inbound-data/policy/relevant_policy/doc2.json",
        ],
    )
    payloads = {
        "dbaware_review_20086/inbound-data/policy/relevant_policy.json": {
            "documents": [
                {"document_id": "1", "document_title": "Doc One", "excluded": True, "status": "removed"},
                {"document_id": "2", "document_title": "Doc Two", "document_relevance_score": 0.9},
            ]
        },
        "dbaware_review_20086/inbound-data/policy/relevant_policy/doc1.json": {
            "document_id": "1",
            "document_title": "Doc One",
            "document_relevance_score": 0.95,
        },
        "dbaware_review_20086/inbound-data/policy/relevant_policy/doc2.json": {
            "document_id": "2",
            "document_title": "Doc Two",
            "document_relevance_score": 0.9,
        },
    }
    monkeypatch.setattr(data_manager, "read_blob_json", lambda path: payloads[path])

    cfg = {
        "folder": "policy",
        "file_name": "relevant_policy.json",
        "parts_folder": "policy/relevant_policy",
    }
    prefix, documents = asyncio.run(data_manager.read_plan_json_parts_async("20086", cfg))

    assert prefix == "dbaware_review_20086/inbound-data/policy/relevant_policy"
    assert len(documents) == 1
    assert documents[0]["document_id"] == "2"


def test_table_metadata_resolves_storage_uris_and_filters_kod_sections(monkeypatch):
    """Verify read_plan_json_parts_async uses storage_uri from review_data_extraction.metadata
    and filters out soft-excluded documents and soft-excluded sections (node_id / section_id)."""
    table_meta = {
        "kod": {
            "source_type": "kod",
            "documents": [
                {
                    "filename": "kod20.json",
                    "storage_uri": "gs://test-bucket/custom_table_path/kod20.json",
                    "document_id": "20",
                    "document_title": "Key Operating Document 20",
                    "status": "active",
                    "excluded": False,
                    "sections": [
                        {
                            "section_id": 1,
                            "section_title": "Overview",
                            "node_id": "node-kod-20-1",
                            "status": "active",
                            "excluded": False,
                        },
                        {
                            "section_id": 2,
                            "section_title": "Escalation Matrix",
                            "node_id": "node-kod-20-2",
                            "status": "excluded",
                            "excluded": True,
                        },
                    ],
                },
                {
                    "filename": "kod21.json",
                    "storage_uri": "gs://test-bucket/custom_table_path/kod21.json",
                    "document_id": "21",
                    "document_title": "Excluded KOD 21",
                    "status": "excluded",
                    "excluded": True,
                    "sections": [],
                },
            ],
        }
    }
    monkeypatch.setattr(data_manager, "get_data_extraction_metadata_map", lambda plan_number: table_meta)
    monkeypatch.setattr(data_manager.Config, "REVIEW_BUCKET_NAME", "test-bucket")

    payloads = {
        "custom_table_path/kod20.json": {
            "document_id": "20",
            "document_title": "Key Operating Document 20",
            "document_relevance_score": 0.92,
            "nodes": [
                {
                    "node_id": "node-kod-20-1",
                    "section_id": 1,
                    "section_title": "Overview",
                    "relevant_passages": [{"text": "Keep this passage"}],
                },
                {
                    "node_id": "node-kod-20-2",
                    "section_id": 2,
                    "section_title": "Escalation Matrix",
                    "relevant_passages": [{"text": "Drop this excluded section"}],
                },
            ],
        },
        "custom_table_path/kod21.json": {
            "document_id": "21",
            "document_title": "Excluded KOD 21",
            "document_relevance_score": 0.99,
            "nodes": [
                {
                    "node_id": "node-kod-21-1",
                    "section_id": 1,
                    "section_title": "Should Not Load",
                    "relevant_passages": [{"text": "Excluded doc"}],
                }
            ],
        },
    }
    monkeypatch.setattr(data_manager, "blob_exists", lambda path: path in payloads)
    monkeypatch.setattr(data_manager, "read_blob_json", lambda path: payloads[path])
    monkeypatch.setattr(data_manager, "list_blob_paths", lambda prefix: [])

    cfg = {
        "folder": "policy",
        "file_name": "relevant_kod.json",
        "parts_folder": "policy/relevant_kod",
    }
    prefix, documents = asyncio.run(data_manager.read_plan_json_parts_async("20440", cfg))
    assert len(documents) == 1
    assert documents[0]["document_id"] == "20"
    assert documents[0]["storage_uri"] == "gs://test-bucket/custom_table_path/kod20.json"
    assert len(documents[0]["nodes"]) == 1
    assert documents[0]["nodes"][0]["node_id"] == "node-kod-20-1"


def test_table_metadata_filters_gfms_findings_and_historical_scoping_docs(monkeypatch):
    """Verify read_plan_json resolves custom storage_uri from review_data_extraction.metadata
    and filters excluded GFMS finding sections and excluded historical scoping plans."""
    table_meta = {
        "findings_details": {
            "source_type": "gfms",
            "documents": [
                {
                    "filename": "findings_details.json",
                    "storage_uri": "gs://test-bucket/table_gfms/findings_details.json",
                    "document_id": "findings_details",
                    "status": "active",
                    "excluded": False,
                    "sections": [
                        {
                            "section_id": "F-101",
                            "section_title": "Finding 101",
                            "node_id": "finding:F-101",
                            "status": "active",
                            "excluded": False,
                        },
                        {
                            "section_id": "F-102",
                            "section_title": "Finding 102",
                            "node_id": "finding:F-102",
                            "status": "excluded",
                            "excluded": True,
                        },
                    ],
                }
            ],
        },
        "historical_plan_details": {
            "source_type": "historical_scoping_document",
            "documents": [
                {
                    "filename": "historical_plan_details.json",
                    "storage_uri": "gs://test-bucket/table_hist/historical_plan_details.json",
                    "document_id": "historical_plan_details",
                    "status": "active",
                    "excluded": False,
                    "sections": [
                        {
                            "section_id": "13224",
                            "section_title": "Plan 13224",
                            "node_id": "historical_plan:13224",
                            "status": "active",
                            "excluded": False,
                        },
                        {
                            "section_id": "19572",
                            "section_title": "Plan 19572",
                            "node_id": "historical_plan:19572",
                            "status": "excluded",
                            "excluded": True,
                        },
                    ],
                },
                {
                    "filename": "Scoping_13224.pdf",
                    "storage_uri": "gs://hist-bucket/dbaware_historic_review_docs/13224/Scoping_13224.pdf",
                    "document_id": "13224",
                    "historic_plan_number": "13224",
                    "status": "active",
                    "excluded": False,
                    "sections": [],
                },
                {
                    "filename": "Scoping_19572.pdf",
                    "storage_uri": "gs://hist-bucket/dbaware_historic_review_docs/19572/Scoping_19572.pdf",
                    "document_id": "19572",
                    "historic_plan_number": "19572",
                    "status": "excluded",
                    "excluded": True,
                    "sections": [],
                },
            ],
        },
    }
    monkeypatch.setattr(data_manager, "get_data_extraction_metadata_map", lambda plan_number: table_meta)
    monkeypatch.setattr(data_manager.Config, "REVIEW_BUCKET_NAME", "test-bucket")

    payloads = {
        "table_gfms/findings_details.json": {
            "Finding Details": [
                {"Finding Number": "F-101", "Finding Title": "Finding 101"},
                {"Finding Number": "F-102", "Finding Title": "Finding 102"},
            ],
            "Issue Details": [
                {"Finding Number": "F-101", "Issue Number": "I-1"},
                {"Finding Number": "F-102", "Issue Number": "I-2"},
            ],
        },
        "table_hist/historical_plan_details.json": [
            {"Plan Item Number": "13224", "Plan Item Title": "Plan 13224"},
            {"Plan Item Number": "19572", "Plan Item Title": "Plan 19572"},
        ],
    }
    monkeypatch.setattr(data_manager, "blob_exists", lambda path: path in payloads)
    monkeypatch.setattr(data_manager, "read_blob_json", lambda path: payloads[path])
    monkeypatch.setattr(data_manager, "list_blob_paths", lambda prefix, bucket_name=None: [])

    gfms_path, gfms_data = data_manager.read_plan_json("20440", "gfms", "findings_details.json")
    assert gfms_path == "table_gfms/findings_details.json"
    assert len(gfms_data["Finding Details"]) == 1
    assert gfms_data["Finding Details"][0]["Finding Number"] == "F-101"
    assert len(gfms_data["Issue Details"]) == 1
    assert gfms_data["Issue Details"][0]["Finding Number"] == "F-101"

    hist_path, hist_data = data_manager.read_plan_json("20440", "dbaware", "historical_plan_details.json")
    assert hist_path == "table_hist/historical_plan_details.json"
    assert len(hist_data) == 1
    assert hist_data[0]["Plan Item Number"] == "13224"

    resolved_pdfs = data_manager._resolve_historical_review_documents(
        ["13224", "19572"], table_meta["historical_plan_details"]
    )
    assert len(resolved_pdfs) == 1
    assert resolved_pdfs[0]["historic_plan_number"] == "13224"
    assert resolved_pdfs[0]["uri"] == "gs://hist-bucket/dbaware_historic_review_docs/13224/Scoping_13224.pdf"


def test_policy_section_builder_filters_excluded_sections_by_node_id():
    chunks = [
        {
            "chunk_id": 15,
            "source_name": "relevant_kod",
            "content": {
                "documents": [
                    {
                        "document_id": "20",
                        "document_title": "Key Operating Document 20",
                        "sections": [
                            {
                                "section_id": 1,
                                "section_title": "Section 1",
                                "node_id": "node-keep",
                                "status": "active",
                                "excluded": False,
                            },
                            {
                                "section_id": 2,
                                "section_title": "Section 2",
                                "node_id": "node-drop",
                                "status": "excluded",
                                "excluded": True,
                            },
                        ],
                        "nodes": [
                            {
                                **_node("1", "Section 1", ["1 Section 1"], "Active section text.", 1),
                                "node_id": "node-keep",
                            },
                            {
                                **_node("2", "Section 2", ["2 Section 2"], "Excluded section text.", 2),
                                "node_id": "node-drop",
                            },
                        ],
                    }
                ]
            },
        }
    ]
    manifest = build_policy_manifest(chunks)
    docs = manifest["relevant_kod"]["documents"]
    assert len(docs) == 1
    assert len(docs[0]["sections"]) == 1
    assert docs[0]["sections"][0]["texts"] == ["Active section text."]




