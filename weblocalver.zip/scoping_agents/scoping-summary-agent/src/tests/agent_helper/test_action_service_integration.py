import uuid
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock
import pytest
from fastapi.testclient import TestClient

from app import app

from agent_helper import action_service
from agent_helper.agent_card import AgentCard
from model.response_model import PreliminaryResearchDocument
from config.config import Config

client = TestClient(app)


def test_call_to_action_service_payload_structure():
    """Verify call_to_action_service produces the standard CTA_ACTION payload."""
    session_id = str(uuid.uuid4())
    card = {
        "ENTITY_ID": session_id,
        "ENTITY_TYPE": "PRELIMINARY_RESEARCH",
        "PARENT_ENTITY_TYPE": "SCOPING",
        "PARENT_ENTITY_ID": "20583",
        "CORRELATION_ID": session_id,
        "ACTOR_TYPE": "HUMAN",
        "ACTOR_ID": "dbaware@db.com",
        "ACTION_TYPE": "GENERATE",
        "ACTIVITY_TYPE": "PRELIMINARY_RESEARCH",
    }
    data = {"action_type": "GENERATE", "Human_Notes": "Test note", "Remarks": ""}
    
    result = action_service.construct_cta_action_record(plan_number="20583",
                                                        action_type="GENERATE",
                                                        actor_type="HUMAN",
                                                        actor_id="dbaware@db.com",
                                                        activity_type="PRELIMINARY_RESEARCH",
                                                        payload=data)


    assert "CTA_ACTION" in result



@patch("agent_helper.action_service.call_to_action_service")
def test_construct_human_actor_record(mock_call):
    """Verify construct_human_actor_record sets HUMAN and GENERATE attributes."""

    action_service.construct_human_actor_generate_record(plan_number="20583",
                                                         activity_type= "PRELIMINARY_RESEARCH",
                                                         query="construct",
                                                         user="dbaware@db.com" )

    mock_call.assert_called_once()
    args, _ = mock_call.call_args
    data_arg = args



@patch("agent_helper.action_service.call_to_action_service")
def test_construct_ai_actor_record(mock_call):
    """Verify construct_ai_actor_record records model metadata and minute precision timestamps."""
    agent_card = {
        "ACTOR_ID": "preliminary-research-agent",
        "ENTITY_ID": "entity-123",
        "CORRELATION_ID": "corr-123",
        "PARENT_ENTITY_ID": "20583",
        "PARENT_ENTITY_TYPE": "SCOPING",
    }
    start = datetime(2026, 9, 24, 12, 0, 0, tzinfo=timezone.utc)
    end = datetime(2026, 9, 24, 12, 5, 0, tzinfo=timezone.utc)
    

    action_service.construct_ai_actor_response_record(plan_number="20583",
                                       activity_type="PRELIMINARY_RESEARCH",
                                       response_code=200,
                                       total_input_tokens=0,
                                       total_output_tokens=0,
                                       final_answer="",
                                       start_time=start,
                                       end_time=end,
                                       score=0,
                                       reasoning="",
                                       env_config=Config,
                                       prompt_version="1.0",
                                       )
    
    mock_call.assert_called_once()
    data_arg = mock_call.call_args[0]




@patch("agent_helper.action_service.call_to_action_service")
def test_construct_human_update_record(mock_call):
    """Verify construct_human_update_record records REVISE action."""

    action_service.construct_human_update_record(plan_number="20508",
                                                 activity_type="PRELIMINARY_RESEARCH",
                                                 human_notes="save human edited report",
                                                 updated_by="dbaware@db.com",
                                                 updated_section="Edited section 2")
    
    mock_call.assert_called_once()
    data_arg = mock_call.call_args[0]

@patch("agent_helper.action_service.construct_human_actor_generate_record")
@patch("agent_helper.action_service.construct_ai_actor_response_record")
@patch("router.router.persist_review_research_recommendation", return_value=101)
@patch("router.router.has_plan_data", return_value=True)
@patch("router.router.run_analytics_task")
def test_run_analytics_agent_endpoint(mock_run, mock_has_data, mock_persist, mock_ai_rec, mock_human_rec):
    """Test /run-analytics-agent endpoint triggers both human and AI action records."""
    mock_response = PreliminaryResearchDocument(
        plan_number="20583",
        analysis_report={
            "summary": {"report_title": "Summary", "paragraphs": []}
        },

    )
    mock_run.return_value = mock_run.return_value = (
    {"plan_number": "20583", "analysis_report": {"summary": {"report_title": "Summary", "paragraphs": []}}},
    [],
)

    response = client.post(
        "/run-analytics-agent",
        json={"planNumber": "20583", "userDetails": {"user": "jdoe"}},
    )
    assert response.status_code == 200


@patch("agent_helper.action_service.construct_human_update_record")
@patch("router.router.update_review_research_recommendation", return_value=101)
@patch("router.router.write_preliminary_research_sections")
@patch("router.router.blob_exists", return_value=False)
def test_edit_preliminary_research_document_endpoint(mock_exists, mock_write_blob, mock_update, mock_update_rec):
    """Test /edit-preliminary-research-document endpoint triggers human revision record."""
    payload = {
        "planNumber": "20583",
        "analysis_report": {
            "summary": {"report_title": "Summary", "paragraphs": []}
        },
        "userDetails": {"review_scope_id": 55, "user": "jdoe"},
    }
    response = client.post("/edit-preliminary-research-document", json=payload)
    assert response.status_code == 200
    assert mock_update_rec.called