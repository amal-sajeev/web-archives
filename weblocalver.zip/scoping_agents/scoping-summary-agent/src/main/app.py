import os
import sys
import logging
from pathlib import Path
from dotenv import load_dotenv

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    stream=sys.stdout,
    force=True,
)
logging.getLogger().setLevel(logging.INFO)
logger = logging.getLogger(__name__)


project_root = os.path.abspath(os.path.dirname(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Keep the existing direct imports available for callers; HTTP routes are registered only via the router.
from router.router import (
    router as app_router,
    run_analytics_agent_endpoint,
    get_document,
    get_preliminary_research_document,
    edit_preliminary_research_document,
    download_research_walkthrough,
    run_analytics_task,
    has_plan_data,
    process_citations,
    process_document_uri,
    read_preliminary_research_report,
    write_preliminary_research_sections,
    download_research_walkthrough_pdf,
    Config,
)
# Load environment variables from .env if present
load_dotenv()

# Align fallback GCS bucket name across variable naming conventions
bucket_name_val = os.getenv("bucket_name") or os.getenv("BUCKET_NAME") or os.getenv("DBAWARE_REVIEW_BUCKET_NAME")
if bucket_name_val:
    for var in ["bucket_name", "BUCKET_NAME", "review_bucket_name", "DBAWARE_REVIEW_BUCKET_NAME"]:
        os.environ.setdefault(var, bucket_name_val)

from fastapi import FastAPI, HTTPException
from model.request_model import (
    AnalyticsRequest,
    DownloadResearchWalkthroughRequest,
    EditPreliminaryResearchRequest,
    GetDocumentRequest,
    GetPreliminaryResearchRequest,
)
from fastapi.middleware.cors import CORSMiddleware
import uvicorn


# Log to stdout: the default handler writes to stderr, which GCP reports as ERROR severity.
log_handler = logging.StreamHandler(sys.stdout)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    handlers=[log_handler],
    force=True,  # replace any handler installed by an earlier import
)

# uvicorn's own loggers (startup messages, access log) write to stderr by default.
for _uvicorn_logger in ("uvicorn", "uvicorn.error", "uvicorn.access"):
    for _handler in logging.getLogger(_uvicorn_logger).handlers:
        if isinstance(_handler, logging.StreamHandler) and _handler.stream is sys.stderr:
            _handler.setStream(sys.stdout)

logger = logging.getLogger(__name__)

ASGI_ROOT_PATH = "/scoping-summary-agent"

app = FastAPI(
    title="Scoping Analytics Agent",
    description="API for the Scoping Analytics Agent",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(app_router)
if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=4000,
        root_path=ASGI_ROOT_PATH,
        reload=True,
    )
