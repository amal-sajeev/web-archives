import logging
import asyncio
import base64
import json
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from typing import Any, Callable, Dict, List, Optional

from config.config import Config
from config.prompts import (
    ANALYSE_DATA_PROMPT,
    BROAD_SCOPE_ALC_PROMPT,
    BROAD_SCOPE_COLLATION_OUTPUT_FORMAT_PROMPT,
    BROAD_SCOPE_COLLATION_PROMPT,
    BROAD_SCOPE_COMMON_PROMPT,
    BROAD_SCOPE_DBGRC_CONTROL_LEVEL_PROMPT,
    BROAD_SCOPE_DBGRC_PROMPT,
    BROAD_SCOPE_FINDINGS_GA_PROMPT,
    BROAD_SCOPE_HISTORICAL_PROMPT,
    BROAD_SCOPE_PART_OUTPUT_FORMAT_PROMPT,
    BROAD_SCOPE_QUALITY_PROMPT,
    OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    PAST_REVIEW_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    POLICY_ASSESSMENT_OUTPUT_FORMAT_PROMPT,
    POLICY_ASSESSMENT_PROMPT,
    POLICY_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    POLICY_REGULATION_PROMPT,
)
from utils.gemini_connection import initialize_gemini_model
from utils.storage_manager import read_blob_from_uri_as_bytes
from utils.policy_section_builder import (
    assemble_policy_report,
    build_policy_manifest,
    build_regulation_manifest,
    to_model_source_chunks,
)
from utils.broad_scope_builder import (
    BroadScopePart,
    build_risk_driver_paragraphs,
    build_section1,
    build_section2,
    cited_chunk_ids,
    compact_dbgrc_controls,
    draft_for_collation,
    finalize_broad_scope_report,
    resolve_draft_refs,
    restrict_citations,
)
from model.response_model import (
    BroadScopeCollationOutput,
    BroadScopePartOutput,
    PastReviewIntelligenceReport,
    PolicyAssessmentsOutput,
    PolicyRegulationOutput,
    ScopingReport,
)

logger = logging.getLogger(__name__)


ProgressCallback = Optional[Callable[[Dict[str, Any]], None]]


def _emit_progress(
    progress_callback: ProgressCallback,
    status: str,
    message: str,
    progress: int,
    phase: Optional[str] = None,
    section: Optional[str] = None,
) -> None:
    if progress_callback:
        progress_callback({"status": status, "message": message, "progress": progress, "phase": phase, "section": section})


def _to_human_message(content_parts: list[dict]):
    """Build a HumanMessage when langchain_core is available, otherwise fallback to dict."""
    try:
        from langchain_core.messages import HumanMessage

        return HumanMessage(content=content_parts)
    except Exception:
        return {"role": "user", "content": content_parts}


def _prepare_multimodal_payload(
    source_chunks: List[dict],
    user_prompt: str,
    report_title: str,
    output_format_instructions: Optional[str] = None,
):
    """Build a multimodal payload with source JSON plus historical review PDFs.

    Temporary diagnostic: log payload sizing/timing around historical review PDFs
    so we can assess whether they are causing the Vertex INVALID_ARGUMENT error.
    """
    started_at = time.perf_counter()
    text_chunks: list[dict] = []
    pdf_chunks: list[dict] = []

    for chunk in source_chunks:
        source_name = str(chunk.get("source_name", ""))
        metadata = chunk.get("metadata") or {}
        url = str(metadata.get("url", ""))
        if source_name == "historical_review_document" and url.lower().endswith(".pdf"):
            pdf_chunks.append(chunk)
            continue
        text_chunks.append(chunk)

    payload_json = {
        "user_prompt": user_prompt,
        "output_format_instructions": (
            output_format_instructions
            or OUTPUT_FORMAT_INSTRUCTIONS_PROMPT.format(title=report_title)
        ),
        "source_chunks": text_chunks + pdf_chunks,
    }

    json_text = json.dumps(payload_json, ensure_ascii=False)
    logger.info(
        "TEMP_PAYLOAD_METRICS section=%s total_chunks=%d text_chunks=%d pdf_chunks=%d json_chars=%d",
        report_title,
        len(source_chunks),
        len(text_chunks),
        len(pdf_chunks),
        len(json_text),
    )

    content_parts: list[dict] = [
        {
            "type": "text",
            "text": (
                "Use the following JSON payload and attached historical review documents to generate the report. "
                "Treat each attachment as evidence for the corresponding historical review document chunk in source_chunks.\n\n"
                f"{json_text}"
            ),
        }
    ]

    downloaded_pdf_bytes = 0
    for chunk in pdf_chunks:
        metadata = chunk.get("metadata") or {}
        uri = str(metadata.get("url", "")).strip()
        if not uri.startswith("gs://"):
            logger.warning("Skipping historical review document with invalid uri=%s", uri)
            continue

        try:
            pdf_bytes = read_blob_from_uri_as_bytes(uri)
        except Exception:
            logger.exception("Failed to download historical review document uri=%s", uri)
            continue

        downloaded_pdf_bytes += len(pdf_bytes or b"")
        content_parts.append(
            {
                "type": "media",
                "mime_type": "application/pdf",
                "data": base64.b64encode(pdf_bytes).decode("utf-8"),
            }
        )

    elapsed_ms = (time.perf_counter() - started_at) * 1000
    logger.info(
        "TEMP_PAYLOAD_METRICS section=%s elapsed_ms=%.1f downloaded_pdf_bytes=%d total_text_chars=%d total_media_parts=%d",
        report_title,
        elapsed_ms,
        downloaded_pdf_bytes,
        len(json_text),
        len(content_parts),
    )

    return [_to_human_message(content_parts)]


def _has_historical_data(source_chunks: List[dict]) -> bool:
    for chunk in source_chunks:
        if not isinstance(chunk, dict):
            continue
        if chunk.get("source_name") == "historical_review_document":
            return True
        if chunk.get("source_name") == "historical_plan_item_details" and chunk.get("content"):
            return True
    return False


def _current_plan_number(source_chunks: List[dict]) -> str:
    for chunk in source_chunks:
        if not isinstance(chunk, dict) or chunk.get("source_name") != CURRENT_PLAN_SOURCE:
            continue
        content = chunk.get("content")
        if isinstance(content, dict):
            return str(content.get("Plan Item Number") or "")
    return ""


def past_review_report(source_chunks: List[dict], model) -> PastReviewIntelligenceReport:
    logger.info("Generating past review report with %d source chunks", len(source_chunks))
    report_title = "Past Review Analysis"
    # Without historical data the model only sees the current plan and invents a "historical review" from
    # references in its description (e.g. "last review in 2022"), so return an empty comparison instead.
    if not _has_historical_data(source_chunks):
        logger.info("No historical plan data or documents; skipping past review model call")
        return PastReviewIntelligenceReport(
            report_title=report_title,
            current_review_id=_current_plan_number(source_chunks),
            similar_review_count=0,
            historical_reviews=[],
        )
    structured_model = model.with_structured_output(PastReviewIntelligenceReport)
    payload = _prepare_multimodal_payload(
        source_chunks,
        ANALYSE_DATA_PROMPT,
        report_title,
        output_format_instructions=PAST_REVIEW_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT,
    )
    logger.info("Generating past review report")
    response: PastReviewIntelligenceReport = structured_model.invoke(payload)
    # Enforce the exact title; the model tends to synthesize its own otherwise.
    response.report_title = report_title
    logger.info("Past review report generated")
    return response

def _policy_source_assessments(source_chunks: List[dict], manifest: Dict[str, dict], source_name: str, model) -> list:
    """Summarise every document/section of one source (policy, procedure or KOD) in its own model call."""
    if not manifest[source_name]["documents"]:
        return []
    sub_manifest = {source_name: manifest[source_name]}
    sub_chunks = [
        chunk for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") in ("current_plan_item_details", source_name)
    ]
    payload = _prepare_multimodal_payload(
        to_model_source_chunks(sub_chunks, sub_manifest),
        POLICY_ASSESSMENT_PROMPT,
        f"Policy assessment {source_name}",
        output_format_instructions=POLICY_ASSESSMENT_OUTPUT_FORMAT_PROMPT,
    )
    try:
        result: PolicyAssessmentsOutput = model.with_structured_output(PolicyAssessmentsOutput).invoke(payload)
    except Exception:
        # Missing keys are rendered as "Summary not available" by assemble_policy_report.
        logger.exception("Policy assessment call failed source=%s", source_name)
        return []
    return list(result.document_assessments)


def policy_regulation(source_chunks: List[dict], model) -> ScopingReport:
    logger.info("Generating policy regulation report with %d source chunks", len(source_chunks))
    report_title = "Policy, KOD and Regulatory Analysis"
    structured_model = model.with_structured_output(PolicyRegulationOutput)
    manifest = build_policy_manifest(source_chunks)
    model_chunks = to_model_source_chunks(source_chunks, manifest, build_regulation_manifest(source_chunks))
    output_format_instructions = (
        POLICY_OUTPUT_FORMAT_INSTRUCTIONS_PROMPT
        + OUTPUT_FORMAT_INSTRUCTIONS_PROMPT.format(title=report_title)
    )
    payload = _prepare_multimodal_payload(
        model_chunks,
        POLICY_REGULATION_PROMPT,
        report_title,
        output_format_instructions=output_format_instructions,
    )
    logger.info("Generating policy regulation report")
    with ThreadPoolExecutor(max_workers=len(manifest) + 1) as pool:
        main_future = pool.submit(structured_model.invoke, payload)
        assessment_futures = [
            pool.submit(_policy_source_assessments, source_chunks, manifest, source_name, model)
            for source_name in manifest
        ]
        output: PolicyRegulationOutput = main_future.result()
        output.section1.document_assessments = [
            assessment for future in assessment_futures for assessment in future.result()
        ]
    # Section 1 is assembled deterministically in code from the merged model output.
    response = assemble_policy_report(output, manifest, source_chunks, report_title)
    logger.info("Policy regulation report generated")

    return response

BROAD_SCOPE_TITLE = "Broad Scope Direction"
CURRENT_PLAN_SOURCE = "current_plan_item_details"
# Rendered as-is at the end of Section 1; never sent to a model.
RISK_DRIVERS_SOURCE = "risk_drivers"

# Parallel calls; each receives the current plan chunk plus the chunks of its `sources`.
# `label` is the code-written heading of the group's block in Section 2 (None when the model writes its own sub-headings).
BROAD_SCOPE_GROUPS: List[Dict[str, Any]] = [
    {
        "key": "historical",
        "label": "Historical Plan Context",
        "prompt": BROAD_SCOPE_HISTORICAL_PROMPT,
        # Findings are needed for the Section 1 open/closed check on historically referenced findings.
        "sources": {"historical_review_document", "findings"},
        "always_run": True,  # also produces Section 1
        "unavailable_text": None,
    },
    {
        "key": "dbgrc",
        "label": "dbGRC Control Scope",
        "prompt": BROAD_SCOPE_DBGRC_PROMPT,
        # Appended only when the compacted dbGRC data has control-level KCs (plan KCs listed without an AU).
        "control_level_prompt": BROAD_SCOPE_DBGRC_CONTROL_LEVEL_PROMPT,
        "sources": {"key_controls"},
        "compact": {"key_controls": compact_dbgrc_controls},
        # The prompt always asks for in-scope/out-of-scope blocks, so an empty answer means the call silently failed.
        "require_output": True,
        "unavailable_text": "Data Not Available - no dbGRC control data was retrieved for this plan.",
    },
    {
        "key": "findings_ga",
        "label": None,
        "prompt": BROAD_SCOPE_FINDINGS_GA_PROMPT,
        "sources": {"findings", "group_audit"},
        "unavailable_text": "Data Not Available - no GFMS findings or Group Audit data was retrieved for this plan.",
    },
    {
        "key": "alc_nc",
        "label": "Alternate Coverage",
        "prompt": BROAD_SCOPE_ALC_PROMPT,
        "sources": {"alternate_coverage"},
        "unavailable_text": None,
    },
]

# Order of the group blocks under A. In-scope / B. Out of scope.
BROAD_SCOPE_LAYOUT: Dict[str, List[str]] = {
    "in_scope": ["dbgrc", "historical"],
    "out_of_scope": ["dbgrc", "findings_ga", "historical", "alc_nc"],
}

# Raw sources sent to the collation call (Section 3) alongside the assembled Sections 1-2 draft.
BROAD_SCOPE_COLLATION_SOURCES = {
    CURRENT_PLAN_SOURCE,
    "relevant_policy",
    "relevant_procedure",
    "relevant_kod",
    "internet_search",
}


def _broad_scope_prompt(*blocks: str) -> str:
    # Section 1 compares finding target dates against "today", so the date must be in the request.
    return "\n".join([*blocks, BROAD_SCOPE_QUALITY_PROMPT, f"Current date (today): {date.today().isoformat()}"])


def _broad_scope_output_format(prefix: str) -> str:
    return prefix + OUTPUT_FORMAT_INSTRUCTIONS_PROMPT.format(title=BROAD_SCOPE_TITLE)


def _log_input_tokens(model, payload, context: str) -> None:
    """Log the text token count of a Broad Scope call (attached PDFs are logged separately as bytes)."""
    try:
        message = payload[0]
        content = message["content"] if isinstance(message, dict) else message.content
        tokens = model.get_num_tokens(content[0]["text"])
    except Exception:
        logger.warning("Broad scope token count unavailable part=%s", context, exc_info=True)
        return
    threshold = Config.BROAD_SCOPE_MAX_INPUT_TOKENS
    level = logging.WARNING if tokens > threshold else logging.INFO
    logger.log(level, "Broad scope input tokens part=%s text_tokens=%d threshold=%d", context, tokens, threshold)


def _has_control_level_kcs(chunks: List[dict]) -> bool:
    return any(
        isinstance(chunk.get("content"), dict)
        and (chunk["content"].get("control_level_included_kcs") or chunk["content"].get("control_level_excluded_kcs"))
        for chunk in chunks
    )


def _log_empty_part_response(key: str, raw: Any, parsed: Any, parsing_error: Any) -> None:
    """Explain an empty required part: log what Gemini actually returned (finish reason, tokens, filled keys)."""
    tool_calls = getattr(raw, "tool_calls", None) or []
    logger.warning(
        "Broad scope part=%s empty output finish_reason=%s usage=%s tool_calls=%d tool_arg_keys=%s "
        "invalid_tool_calls=%d text_chars=%d parsing_error=%s parsed=%s",
        key,
        (getattr(raw, "response_metadata", None) or {}).get("finish_reason"),
        getattr(raw, "usage_metadata", None),
        len(tool_calls),
        [sorted((call.get("args") or {}) if isinstance(call.get("args"), dict) else []) for call in tool_calls],
        len(getattr(raw, "invalid_tool_calls", None) or []),
        len(str(getattr(raw, "content", "") or "")),
        parsing_error,
        parsed is not None,
    )


def _broad_scope_part(source_chunks: List[dict], group: Dict[str, Any], model) -> BroadScopePart:
    part = BroadScopePart(
        key=group["key"],
        label=group["label"],
        unavailable_text=group["unavailable_text"],
    )
    compactors = group.get("compact") or {}
    current_plan = next(
        (chunk.get("content") for chunk in source_chunks
         if isinstance(chunk, dict) and chunk.get("source_name") == CURRENT_PLAN_SOURCE),
        None,
    )
    group_chunks = [
        {**chunk, "content": compactors[chunk["source_name"]](chunk.get("content"), current_plan)}
        if chunk.get("source_name") in compactors else chunk
        for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") in {CURRENT_PLAN_SOURCE, *group["sources"]}
    ]
    has_group_data = any(chunk.get("source_name") in group["sources"] for chunk in group_chunks)
    if not has_group_data and not group.get("always_run"):
        logger.info("Skipping broad scope part=%s: no source data", group["key"])
        return part

    payload = _prepare_multimodal_payload(
        group_chunks,
        _broad_scope_prompt(
            BROAD_SCOPE_COMMON_PROMPT,
            group["prompt"],
            *([group["control_level_prompt"]] if group.get("control_level_prompt") and _has_control_level_kcs(group_chunks) else []),
        ),
        f"{BROAD_SCOPE_TITLE} - {group['key']}",
        output_format_instructions=_broad_scope_output_format(BROAD_SCOPE_PART_OUTPUT_FORMAT_PROMPT),
    )
    _log_input_tokens(model, payload, group["key"])
    try:
        result = model.with_structured_output(BroadScopePartOutput, include_raw=True).invoke(payload)
    except Exception:
        logger.exception("Broad scope part call failed part=%s", group["key"])
        part.status = "failed"
        return part
    output: Optional[BroadScopePartOutput] = result.get("parsed")
    if output is None or (group.get("require_output") and not output.in_scope and not output.out_of_scope):
        _log_empty_part_response(group["key"], result.get("raw"), output, result.get("parsing_error"))
        logger.warning("Broad scope part=%s returned no in-scope or out-of-scope boundaries", group["key"])
        part.status = "failed"
        return part

    restrict_citations(
        [*output.section1, *output.in_scope, *output.out_of_scope],
        {str(chunk.get("chunk_id")) for chunk in group_chunks},
        group["key"],
    )
    part.status = "ok"
    part.output = output
    return part


def _broad_scope_collation(source_chunks: List[dict], draft_paragraphs: list, model) -> Optional[BroadScopeCollationOutput]:
    """Write the Section 2 rationale/score and Section 3 from the assembled draft plus policy/regulatory data."""
    context_chunks = [
        chunk for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") in BROAD_SCOPE_COLLATION_SOURCES
    ]
    # Same keyed manifests as the policy section, so citations resolve to the exact document page / web link.
    manifest = build_policy_manifest(context_chunks)
    regulation = build_regulation_manifest(context_chunks)
    draft, draft_refs = draft_for_collation(draft_paragraphs)
    collation_chunks = [
        *to_model_source_chunks(context_chunks, manifest, regulation),
        {"source_name": "broad_scope_draft", "content": draft},
    ]
    payload = _prepare_multimodal_payload(
        collation_chunks,
        _broad_scope_prompt(BROAD_SCOPE_COLLATION_PROMPT),
        f"{BROAD_SCOPE_TITLE} - collation",
        output_format_instructions=_broad_scope_output_format(BROAD_SCOPE_COLLATION_OUTPUT_FORMAT_PROMPT),
    )
    _log_input_tokens(model, payload, "collation")
    try:
        output: BroadScopeCollationOutput = model.with_structured_output(BroadScopeCollationOutput).invoke(payload)
    except Exception:
        logger.exception("Broad scope collation call failed")
        return None

    # Draft refs (D1, D2, ...) become the original Section 1/2 data citations (document + page).
    resolve_draft_refs(output.section3, draft_refs)
    # Raw policy/procedure/KOD/regulatory chunk IDs are not citable: they map to a whole file, not a document page.
    documents = [doc for entry in manifest.values() for doc in entry["documents"]]
    allowed_ids = (
        cited_chunk_ids(draft_paragraphs)
        | {str(chunk.get("chunk_id")) for chunk in context_chunks if chunk.get("source_name") == CURRENT_PLAN_SOURCE}
        | {doc["doc_key"] for doc in documents}
        | {section["key"] for doc in documents for section in doc["sections"]}
        | {mandate["key"] for mandate in regulation}
        | {evidence["key"] for mandate in regulation for evidence in mandate["evidence"]}
    )
    restrict_citations(output.section3, allowed_ids, "collation")
    return output


def broad_scope_direction(source_chunks: List[dict], model) -> ScopingReport:
    logger.info("Generating broad scope direction report with %d source chunks", len(source_chunks))
    with ThreadPoolExecutor(max_workers=len(BROAD_SCOPE_GROUPS)) as pool:
        parts = list(pool.map(lambda group: _broad_scope_part(source_chunks, group, model), BROAD_SCOPE_GROUPS))
    logger.info("Broad scope parts status=%s", {part.key: part.status for part in parts})
    if not any(part.status == "ok" for part in parts):
        raise RuntimeError("Broad scope direction generation failed: no source-group part succeeded")

    section1 = build_section1(parts)
    section2 = build_section2(parts, BROAD_SCOPE_LAYOUT)
    collation = _broad_scope_collation(source_chunks, [*section1, *section2], model)
    risk_driver_chunk = next(
        (chunk for chunk in source_chunks if isinstance(chunk, dict) and chunk.get("source_name") == RISK_DRIVERS_SOURCE),
        None,
    )
    section1.extend(build_risk_driver_paragraphs(risk_driver_chunk))
    response = finalize_broad_scope_report(section1, section2, collation, BROAD_SCOPE_TITLE)

    logger.info("Broad scope direction generated")
    return response

async def _run_section(
    section_builder,
    source_chunks: List[dict],
    model,
):
    response = await asyncio.to_thread(section_builder, source_chunks, model)
    return response


# Ordered: defines the section order of the consolidated report.
SECTION_REGISTRY: Dict[str, Dict[str, Any]] = {
    "past_review": {
        "title": "Past Review Analysis",
        "builder": past_review_report,
        "data_key": "output1",
        "progress": (30, 40),
    },
    "policy_regulation": {
        "title": "Policy, KOD and Regulatory Analysis",
        "builder": policy_regulation,
        "data_key": "output2",
        "progress": (45, 60),
    },
    "broad_scope": {
        "title": "Broad Scope Direction",
        "builder": broad_scope_direction,
        "data_key": "output3",
        "progress": (65, 80),
    },
}


async def research_report(
    plan_data: Dict[str, Any],
    progress_callback: ProgressCallback = None,
    sections: Optional[List[str]] = None,
) -> Dict[str, Any]:
    selected_keys = [key for key in SECTION_REGISTRY if not sections or key in sections]
    logger.info("Building consolidated research report sections=%s", selected_keys)
    _emit_progress(progress_callback, "running", "Preparing the section review.", 25, phase="preparing_sections")
    model = initialize_gemini_model()

    tasks = {
        key: asyncio.create_task(
            _run_section(SECTION_REGISTRY[key]["builder"], plan_data[SECTION_REGISTRY[key]["data_key"]], model)
        )
        for key in selected_keys
    }

    consolidated_report: Dict[str, Any] = {}
    for key, task in tasks.items():
        title = SECTION_REGISTRY[key]["title"]
        start_progress, end_progress = SECTION_REGISTRY[key]["progress"]
        _emit_progress(
            progress_callback,
            "running",
            f"Generating section {title}.",
            start_progress,
            phase="generating_section",
            section=title,
        )
        consolidated_report[title] = await task
        _emit_progress(
            progress_callback,
            "running",
            f"Section {title} is complete.",
            end_progress,
            phase="generating_section",
            section=title,
        )

    _emit_progress(progress_callback, "running", "Consolidating the completed sections.", 90, phase="consolidating_sections")

    logger.info("Consolidated research report built")
    _emit_progress(progress_callback, "running", "Final touch on the draft report.", 95, phase="final_touch")
    return consolidated_report


async def run_analytics_agent(
    _plan_number: str,
    plan_data: Dict[str, Any],
    progress_callback: ProgressCallback = None,
    sections: Optional[List[str]] = None,
) -> Dict[str, Any]:
    logger.info("Running analytics agent")
    return await research_report(plan_data, progress_callback=progress_callback, sections=sections)
