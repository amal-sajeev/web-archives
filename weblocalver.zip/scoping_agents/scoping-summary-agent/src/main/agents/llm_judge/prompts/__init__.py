"""Versioned judge prompt catalogs."""
