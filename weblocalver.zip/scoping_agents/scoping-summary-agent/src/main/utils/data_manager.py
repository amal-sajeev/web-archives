import asyncio
import base64
import inspect
import json
import logging
import re
from typing import Any, Dict, Optional
from urllib.parse import urlparse

from config.config import Config
from persistor.review_data_extraction_repository import (
    get_data_extraction_metadata_map,
    is_excluded_entry,
    mark_historical_plan_items_excluded,
)
from utils.storage_manager import (
    blob_exists,
    list_blob_paths,
    read_blob_json,
    read_blob_from_uri_as_bytes,
    write_blob_json,
)

logger = logging.getLogger(__name__)



def _base_prefix(plan_number: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number),
    )
    parts = [p.strip("/") for p in [Config.REVIEW_BUCKET_PREFIX, plan_folder, Config.REVIEW_INBOUND_DATA_FOLDER] if p]
    return "/".join(parts)


def _historical_bucket_name() -> str:
    return Config.HISTORICAL_REVIEW_BUCKET_NAME or Config.REVIEW_BUCKET_NAME


def _plan_blob_path(plan_number: str, folder: str, file_name: str) -> str:
    return "/".join([_base_prefix(plan_number), folder, file_name])


def _build_gs_uri(blob_path: str, bucket_name: Optional[str] = None) -> str:
    resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
    return f"gs://{resolved_bucket_name}/{blob_path.lstrip('/')}"


def _historical_documents_prefix(historical_plan_number: str) -> str:
    """Build the prefix that stores historical scoping docs for a historical review id."""
    parts = [
        p.strip("/")
        for p in [
            Config.HISTORICAL_REVIEW_DOCS_PREFIX,
            str(historical_plan_number),
        ]
        if p
    ]
    return "/".join(parts)


def _extract_historical_plan_numbers(node: Any) -> list[str]:
    """Extract historical plan numbers from fixed historical_plan_details format.

    Expected input is a list of objects where each object contains
    "Plan Item Number".
    """
    if not isinstance(node, list):
        return []

    plan_numbers: list[str] = []
    for item in node:
        if not isinstance(item, dict):
            continue
        plan_number = item.get("Plan Item Number")
        if plan_number not in (None, ""):
            plan_numbers.append(str(plan_number).strip())

    deduped = []
    seen = set()
    for item in plan_numbers:
        if item not in seen:
            deduped.append(item)
            seen.add(item)
    return deduped


def _normalize_meta_text(value: Any) -> str:
    text = str(value or "").replace("_", " ")
    return re.sub(r"\s+", " ", text).strip().lower()


def _normalize_section_id(value: Any) -> str:
    text = str(value or "").strip().lower()
    if text.startswith("section "):
        text = text[len("section "):].strip()
    return text


def _collect_excluded_section_markers(sections: Any) -> tuple[set[str], set[str], set[str]]:
    excluded_ids: set[str] = set()
    excluded_node_ids: set[str] = set()
    excluded_titles: set[str] = set()
    if not isinstance(sections, list):
        return excluded_ids, excluded_node_ids, excluded_titles
    for sec in sections:
        if not isinstance(sec, dict) or not is_excluded_entry(sec):
            continue
        sec_id = _normalize_section_id(sec.get("section_id"))
        if sec_id:
            excluded_ids.add(sec_id)
        node_id = str(sec.get("node_id") or "").strip().lower()
        if node_id:
            excluded_node_ids.add(node_id)
            if ":section:" in node_id:
                excluded_ids.add(node_id.rsplit(":section:", 1)[-1].strip())
        for title_key in ("section_title", "title", "findingTitle", "finding_title"):
            norm_title = _normalize_meta_text(sec.get(title_key))
            if norm_title:
                excluded_titles.add(norm_title)
    return excluded_ids, excluded_node_ids, excluded_titles


def _filter_lrr_data_with_table_meta(raw_lrr: Any, source_meta: Optional[Dict[str, Any]]) -> Any:
    if not isinstance(raw_lrr, list):
        return raw_lrr

    excluded_section_ids: set[str] = set()
    excluded_node_ids: set[str] = set()
    excluded_titles: set[str] = set()

    if isinstance(source_meta, dict):
        docs = source_meta.get("documents") or []
        if isinstance(docs, list) and docs:
            active_docs = [d for d in docs if isinstance(d, dict) and not is_excluded_entry(d)]
            if any(is_excluded_entry(d) for d in docs if isinstance(d, dict)) and not active_docs:
                return []
            for doc in docs:
                if not isinstance(doc, dict):
                    continue
                sec_ids, node_ids, titles = _collect_excluded_section_markers(doc.get("sections"))
                excluded_section_ids.update(sec_ids)
                excluded_node_ids.update(node_ids)
                excluded_titles.update(titles)

    filtered_risks: list[Any] = []
    global_mandate_idx = 0
    for risk in raw_lrr:
        if not isinstance(risk, dict):
            continue
        mandates = risk.get("Mandates")
        risk_excluded = is_excluded_entry(risk)
        if not isinstance(mandates, list):
            if not risk_excluded:
                filtered_risks.append(risk)
            continue

        kept_mandates: list[Any] = []
        for mandate in mandates:
            if isinstance(mandate, dict):
                global_mandate_idx += 1
                if risk_excluded or is_excluded_entry(mandate):
                    continue
                mandate_idx_str = str(global_mandate_idx)
                mandate_node_id = f"lrr:mandate:{global_mandate_idx}"
                raw_node_id = str(mandate.get("node_id") or "").strip().lower()
                mandate_title = _normalize_meta_text(mandate.get("Regulatory Mandate") or mandate.get("title"))
                if (
                    mandate_idx_str in excluded_section_ids
                    or mandate_node_id in excluded_node_ids
                    or (raw_node_id and raw_node_id in excluded_node_ids)
                    or (mandate_title and mandate_title in excluded_titles)
                ):
                    continue
                kept_mandates.append(mandate)
            elif not risk_excluded:
                kept_mandates.append(mandate)

        if not risk_excluded and kept_mandates:
            risk_copy = dict(risk)
            risk_copy["Mandates"] = kept_mandates
            filtered_risks.append(risk_copy)

    return filtered_risks


def _filter_findings_data_with_table_meta(raw_findings: Any, source_meta: Optional[Dict[str, Any]]) -> Any:
    if raw_findings is None:
        return raw_findings

    excluded_ids: set[str] = set()
    excluded_node_ids: set[str] = set()
    excluded_titles: set[str] = set()

    if isinstance(source_meta, dict):
        docs = source_meta.get("documents") or []
        if isinstance(docs, list) and docs:
            active_docs = [d for d in docs if isinstance(d, dict) and not is_excluded_entry(d)]
            if any(is_excluded_entry(d) for d in docs if isinstance(d, dict)) and not active_docs:
                return [] if isinstance(raw_findings, list) else {}
            for doc in docs:
                if not isinstance(doc, dict):
                    continue
                sec_ids, node_ids, titles = _collect_excluded_section_markers(doc.get("sections"))
                excluded_ids.update(sec_ids)
                excluded_node_ids.update(node_ids)
                excluded_titles.update(titles)

    def _is_finding_excluded(item: Any) -> bool:
        if not isinstance(item, dict):
            return False
        if is_excluded_entry(item):
            return True
        for id_key in ("findingId", "finding_id", "Finding Number", "finding_number", "id", "section_id", "Plan Item Number"):
            val = str(item.get(id_key) or "").strip().lower()
            if val and (
                val in excluded_ids
                or f"gfms:finding:{val}" in excluded_node_ids
                or f"finding:{val}" in excluded_node_ids
            ):
                return True
        node_val = str(item.get("node_id") or "").strip().lower()
        if node_val and node_val in excluded_node_ids:
            return True
        for title_key in ("findingTitle", "finding_title", "Finding Title", "title", "section_title", "Plan Item Title"):
            val = _normalize_meta_text(item.get(title_key))
            if val and val in excluded_titles:
                return True
        return False

    if isinstance(raw_findings, dict):
        if is_excluded_entry(raw_findings):
            return {}
        if isinstance(raw_findings.get("responsePayload"), list):
            kept_payload = [f for f in raw_findings["responsePayload"] if not _is_finding_excluded(f)]
            if not kept_payload:
                return {}
            copy_dict = dict(raw_findings)
            copy_dict["responsePayload"] = kept_payload
            return copy_dict
        copy_dict = dict(raw_findings)
        for key, value in copy_dict.items():
            if isinstance(value, list):
                copy_dict[key] = [f for f in value if not _is_finding_excluded(f)]
        return copy_dict

    if not isinstance(raw_findings, list):
        return raw_findings

    filtered: list[Any] = []
    for entry in raw_findings:
        if not isinstance(entry, dict):
            filtered.append(entry)
            continue
        if isinstance(entry.get("responsePayload"), list):
            if is_excluded_entry(entry):
                continue
            kept_payload = [f for f in entry["responsePayload"] if not _is_finding_excluded(f)]
            if not kept_payload:
                continue
            entry_copy = dict(entry)
            entry_copy["responsePayload"] = kept_payload
            filtered.append(entry_copy)
        else:
            if not _is_finding_excluded(entry):
                filtered.append(entry)
    return filtered


def _filter_historical_data_with_table_meta(raw_historical: Any, source_meta: Optional[Dict[str, Any]]) -> Any:
    if not isinstance(raw_historical, list):
        return raw_historical

    excluded_numbers: set[str] = set()
    excluded_titles: set[str] = set()
    if isinstance(source_meta, dict):
        docs = source_meta.get("documents") or []
        if isinstance(docs, list):
            for doc in docs:
                if not isinstance(doc, dict):
                    continue
                if is_excluded_entry(doc):
                    for key in ("historic_plan_number", "plan_item_number", "document_id", "id"):
                        val = str(doc.get(key) or "").strip().lower()
                        if val:
                            excluded_numbers.add(val)
                    for key in ("document_title", "plan_item_title", "title"):
                        val = _normalize_meta_text(doc.get(key))
                        if val:
                            excluded_titles.add(val)
                sec_ids, node_ids, titles = _collect_excluded_section_markers(doc.get("sections"))
                excluded_numbers.update(sec_ids)
                for node_id in node_ids:
                    if node_id.startswith("historical_plan:"):
                        excluded_numbers.add(node_id.split("historical_plan:", 1)[-1].strip())
                excluded_titles.update(titles)

    filtered: list[Any] = []
    for item in raw_historical:
        if not isinstance(item, dict):
            filtered.append(item)
            continue
        if is_excluded_entry(item):
            continue
        num = str(item.get("Plan Item Number") or item.get("plan_item_number") or "").strip().lower()
        title = _normalize_meta_text(item.get("Plan Item Title") or item.get("plan_item_title"))
        if (num and num in excluded_numbers) or (title and title in excluded_titles):
            continue
        filtered.append(item)
    return filtered


def _filter_policy_documents_with_table_meta(
    documents: list[Any],
    source_meta: Optional[Dict[str, Any]],
    doc_filenames: Optional[dict[int, str]] = None,
) -> list[Any]:
    if not isinstance(documents, list):
        return []

    meta_docs: list[dict[str, Any]] = []
    if isinstance(source_meta, dict) and isinstance(source_meta.get("documents"), list):
        meta_docs = [d for d in source_meta["documents"] if isinstance(d, dict)]

    def _find_matching_meta(doc: dict[str, Any], part_filename: str) -> Optional[dict[str, Any]]:
        if not meta_docs:
            return None
        doc_filenames_set = {
            str(v).strip().lower()
            for v in (part_filename, doc.get("filename"), doc.get("file_name"))
            if str(v or "").strip()
        }
        doc_uris = {
            str(v).strip().lower()
            for v in (doc.get("storage_uri"), doc.get("gcs_uri"), doc.get("uri"))
            if str(v or "").strip()
        }
        doc_ids = {
            str(v).strip().lower()
            for v in (doc.get("document_id"), doc.get("id"))
            if str(v or "").strip()
        }
        doc_titles = {
            _normalize_meta_text(v)
            for v in (doc.get("document_title"), doc.get("document_name"), doc.get("title"))
            if _normalize_meta_text(v)
        }

        for mdoc in meta_docs:
            m_filenames = {
                str(v).strip().lower()
                for v in (mdoc.get("filename"), mdoc.get("file_name"))
                if str(v or "").strip()
            }
            if doc_filenames_set and (doc_filenames_set & m_filenames):
                return mdoc
            m_uri = str(mdoc.get("storage_uri") or mdoc.get("gcs_uri") or mdoc.get("uri") or "").strip().lower()
            if m_uri and m_uri in doc_uris:
                return mdoc
            m_id = str(mdoc.get("document_id") or mdoc.get("id") or "").strip().lower()
            if m_id and m_id in doc_ids:
                return mdoc
            m_titles = {
                _normalize_meta_text(v)
                for v in (mdoc.get("document_title"), mdoc.get("document_name"), mdoc.get("title"))
                if _normalize_meta_text(v)
            }
            if doc_titles and (doc_titles & m_titles):
                return mdoc
        return None

    filtered_docs: list[Any] = []
    for doc in documents:
        if not isinstance(doc, dict):
            continue
        if is_excluded_entry(doc):
            continue

        part_filename = (doc_filenames or {}).get(id(doc), "")
        matched_meta = _find_matching_meta(doc, part_filename)
        if matched_meta is not None and is_excluded_entry(matched_meta):
            continue

        excluded_sec_ids, excluded_node_ids, excluded_sec_titles = _collect_excluded_section_markers(
            matched_meta.get("sections") if matched_meta else doc.get("sections")
        )
        if matched_meta and isinstance(doc.get("sections"), list):
            extra_ids, extra_nodes, extra_titles = _collect_excluded_section_markers(doc.get("sections"))
            excluded_sec_ids.update(extra_ids)
            excluded_node_ids.update(extra_nodes)
            excluded_sec_titles.update(extra_titles)

        doc_copy = dict(doc)
        if matched_meta and not doc_copy.get("storage_uri") and matched_meta.get("storage_uri"):
            doc_copy["storage_uri"] = matched_meta.get("storage_uri")

        raw_nodes = doc_copy.get("nodes")
        if isinstance(raw_nodes, list):
            kept_nodes = []
            for node in raw_nodes:
                if not isinstance(node, dict) or is_excluded_entry(node):
                    continue
                node_sec_id = _normalize_section_id(node.get("section_id"))
                node_id = str(node.get("node_id") or "").strip().lower()
                node_sec_title = _normalize_meta_text(node.get("section_title") or node.get("title"))
                if (
                    (node_sec_id and node_sec_id in excluded_sec_ids)
                    or (node_id and node_id in excluded_node_ids)
                    or (node_sec_title and node_sec_title in excluded_sec_titles)
                ):
                    continue
                kept_nodes.append(node)
            if raw_nodes and not kept_nodes:
                continue
            doc_copy["nodes"] = kept_nodes
        filtered_docs.append(doc_copy)

    return filtered_docs


def _resolve_historical_review_documents(
    historical_plan_numbers: list[str],
    source_meta: Optional[Dict[str, Any]] = None,
) -> list[Dict[str, Any]]:
    """Resolve historical scoping PDFs from table metadata and/or GCS prefix."""
    allowed_plans = {str(p).strip() for p in (historical_plan_numbers or []) if str(p).strip()}
    resolved: list[Dict[str, Any]] = []
    seen_uris: set[str] = set()

    if isinstance(source_meta, dict):
        for doc in source_meta.get("documents") or []:
            if not isinstance(doc, dict) or is_excluded_entry(doc):
                continue
            filename = str(doc.get("filename") or doc.get("document_name") or "").strip()
            uri = str(doc.get("storage_uri") or doc.get("uri") or "").strip()
            if not uri:
                continue
            if not (filename.lower().endswith(".pdf") or uri.lower().endswith(".pdf")):
                continue
            hp = str(doc.get("historic_plan_number") or doc.get("document_id") or "").strip()
            if allowed_plans and hp and hp not in allowed_plans:
                continue
            doc_name = filename or uri.rsplit("/", 1)[-1]
            seen_uris.add(uri.lower())
            resolved.append(
                {
                    "historic_plan_number": hp,
                    "document_name": doc_name,
                    "uri": uri,
                }
            )

    for doc in _list_historical_review_documents(historical_plan_numbers, source_meta=source_meta):
        uri = str(doc.get("uri") or "").strip()
        if uri and uri.lower() in seen_uris:
            continue
        if uri:
            seen_uris.add(uri.lower())
        resolved.append(doc)

    return resolved


def _list_historical_review_documents(
    historical_plan_numbers: list[str],
    source_meta: Optional[Dict[str, Any]] = None,
) -> list[Dict[str, Any]]:
    """Discover historical scoping documents for the given historical review ids.

    Expected layout: <historical_docs_prefix>/<historical_review_id>/<files>
    Only PDF files are currently attached to the model payload.
    """
    excluded_hist_plans: set[str] = set()
    excluded_doc_names: set[str] = set()
    excluded_uris: set[str] = set()
    if isinstance(source_meta, dict):
        for doc in source_meta.get("documents") or []:
            if not isinstance(doc, dict) or not is_excluded_entry(doc):
                continue
            hp = str(doc.get("historic_plan_number") or doc.get("document_id") or "").strip()
            dname = str(doc.get("document_name") or doc.get("filename") or "").strip().lower()
            duri = str(doc.get("storage_uri") or doc.get("uri") or "").strip().lower()
            if hp and not dname and not duri:
                excluded_hist_plans.add(hp)
            if dname:
                excluded_doc_names.add(f"{hp}:{dname}" if hp else dname)
            if duri:
                excluded_uris.add(duri)

    documents: list[Dict[str, Any]] = []
    bucket_name = _historical_bucket_name()
    for historical_plan_number in historical_plan_numbers:
        plan_key = str(historical_plan_number).strip()
        if plan_key in excluded_hist_plans:
            continue
        prefix = _historical_documents_prefix(historical_plan_number)

        try:
            blob_paths = list_blob_paths(prefix, bucket_name=bucket_name)
        except Exception:
            logger.exception(
                "Failed to list historical documents historical_plan_number=%s prefix=%s",
                historical_plan_number,
                prefix,
            )
            continue

        for blob_path in blob_paths:
            if blob_path.endswith("/"):
                continue
            if not blob_path.lower().endswith(".pdf"):
                logger.debug("Skipping unsupported historical document blob_path=%s", blob_path)
                continue

            doc_name = blob_path.rsplit("/", 1)[-1]
            gs_uri = _build_gs_uri(blob_path, bucket_name=bucket_name)
            if (
                gs_uri.lower() in excluded_uris
                or doc_name.lower() in excluded_doc_names
                or f"{plan_key}:{doc_name.lower()}" in excluded_doc_names
            ):
                continue

            documents.append(
                {
                    "historic_plan_number": str(historical_plan_number),
                    "document_name": doc_name,
                    "uri": gs_uri,
                }
            )

    logger.info(
        "Discovered historical review documents count=%s from_plans=%s",
        len(documents),
        [str(plan_number) for plan_number in historical_plan_numbers],
    )
    return documents


def _build_historical_document_chunk(document: Dict[str, Any]) -> Dict[str, Any]:
    """Build a standard source chunk for a historical review document."""
    return {
        "source_name": "historical_review_document",
        "metadata": {
            "url": document["uri"],
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
        "content": {
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
    }


def get_plan_output_blob_path(plan_number: str, file_name: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    )
    outbound_folder = (Config.REVIEW_OUTBOUND_DATA_FOLDER).strip("/")

    parts = [
        p.strip("/")
        for p in [
            Config.REVIEW_BUCKET_PREFIX,
            plan_folder,
            outbound_folder,
            file_name,
        ]
        if p
    ]
    return "/".join(parts)


def get_preliminary_research_blob_path(plan_number: str) -> str:
    """Build preliminary research blob path under the plan folder.

    Target format:
    dbaware_review_{plan_number}/processing-data/preliminary-research/preliminary-research.json
    """
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    ).strip("/")
    outbound_folder = Config.REVIEW_OUTBOUND_DATA_FOLDER.strip("/")
    file_name = Config.REVIEW_OUTBOUND_DATA_FILE.strip("/")
    return "/".join([plan_folder, outbound_folder, file_name])


def get_preliminary_research_section_blob_path(plan_number: str, section_key: str) -> str:
    """Build the blob path of a single preliminary research section.

    Target format:
    dbaware_review_{plan_number}/processing-data/preliminary-research/{section_key}.json
    """
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    ).strip("/")
    outbound_folder = Config.REVIEW_OUTBOUND_DATA_FOLDER.strip("/")
    return "/".join([plan_folder, outbound_folder, f"{section_key}.json"])


def _blob_path_from_gs_uri(uri: Any) -> Optional[str]:
    text = str(uri or "").strip()
    if not text.startswith("gs://"):
        return None
    without_scheme = text[5:]
    if "/" not in without_scheme:
        return None
    bucket, blob_path = without_scheme.split("/", 1)
    expected_bucket = str(getattr(Config, "REVIEW_BUCKET_NAME", None) or "").strip()
    if expected_bucket and bucket != expected_bucket:
        return None
    cleaned = blob_path.lstrip("/")
    return cleaned or None


def _source_meta_keys_for(folder: str = "", file_name: str = "", parts_folder: str = "") -> tuple[str, ...]:
    lf = str(folder or "").strip().lower()
    lfn = str(file_name or "").strip().lower()
    lpf = str(parts_folder or "").strip().lower()
    if lf == "gfms" or "findings" in lfn:
        return ("findings_details", "gfms", "findings")
    if "historical_plan_details" in lfn:
        return ("historical_plan_details", "historical_scoping_document")
    if lf == "lrr" or "internet_search" in lfn:
        return ("lrr", "internet_search_data", "internet_search")
    if "kod" in lfn or "relevant_kod" in lpf:
        return ("kod", "relevant_kod")
    if "procedure" in lfn or "relevant_procedure" in lpf:
        return ("procedure", "relevant_procedure")
    if "policy" in lfn or "relevant_policy" in lpf:
        return ("policy", "relevant_policy")
    if "alc_nalc" in lfn:
        return ("alc_nalc", "alternative_coverage", "alc_nalc_details")
    if "group_audit" in lfn:
        return ("group_audit", "group_audit_details")
    if "control_details" in lfn:
        return ("key_controls", "control_details")
    if "risk_driver" in lfn:
        return ("risk_drivers", "risk_driver_details")
    if "plan_details" in lfn:
        return ("plan_details",)
    return ()


def _lookup_source_meta(plan_number: str, *keys: str) -> Optional[Dict[str, Any]]:
    if not keys:
        return None
    try:
        meta_map = get_data_extraction_metadata_map(str(plan_number))
    except Exception:
        return None
    if not isinstance(meta_map, dict):
        return None
    for key in keys:
        val = meta_map.get(key)
        if isinstance(val, dict):
            return val
    return None


def _filter_source_data_with_table_meta(
    folder: str,
    file_name: str,
    data: Any,
    source_meta: Optional[Dict[str, Any]],
) -> Any:
    lower_folder = str(folder or "").strip().lower()
    lower_file = str(file_name or "").strip().lower()
    if lower_folder == "lrr" or "internet_search_data" in lower_file:
        return _filter_lrr_data_with_table_meta(data, source_meta)
    if "findings" in lower_file:
        return _filter_findings_data_with_table_meta(data, source_meta)
    if "historical_plan_details" in lower_file:
        return _filter_historical_data_with_table_meta(data, source_meta)
    if isinstance(source_meta, dict):
        docs = source_meta.get("documents") or []
        if isinstance(docs, list) and docs:
            active_docs = [d for d in docs if isinstance(d, dict) and not is_excluded_entry(d)]
            if any(is_excluded_entry(d) for d in docs if isinstance(d, dict)) and not active_docs:
                return [] if isinstance(data, list) else ({} if isinstance(data, dict) else data)
    return data


def _meta_storage_paths_for_file(file_name: str, source_meta: Optional[Dict[str, Any]]) -> list[str]:
    if not isinstance(source_meta, dict):
        return []
    target_name = str(file_name or "").strip().lower()
    target_stem = target_name[:-5] if target_name.endswith(".json") else target_name
    paths: list[str] = []
    for doc in source_meta.get("documents") or []:
        if not isinstance(doc, dict) or is_excluded_entry(doc):
            continue
        blob_path = _blob_path_from_gs_uri(doc.get("storage_uri") or doc.get("gcs_uri") or doc.get("uri"))
        if not blob_path or not blob_path.lower().endswith(".json"):
            continue
        dname = str(doc.get("filename") or doc.get("file_name") or "").strip().lower()
        did = str(doc.get("document_id") or "").strip().lower()
        bname = blob_path.rsplit("/", 1)[-1].lower()
        if target_name in {dname, bname} or (target_stem and target_stem in {dname, did, bname[:-5] if bname.endswith(".json") else bname}):
            if blob_path not in paths:
                paths.append(blob_path)
    return paths


def read_plan_json(
    plan_number: str,
    folder: str,
    file_name: str,
    source_meta: Optional[Dict[str, Any]] = None,
) -> Any:
    if source_meta is None:
        keys = _source_meta_keys_for(folder=folder, file_name=file_name)
        source_meta = _lookup_source_meta(plan_number, *keys)

    candidates: list[str] = []
    if str(file_name or "").strip().lower() == "internet_search_data.json":
        candidates.append("internet_search_data_enriched.json")
    candidates.append(file_name)
    if not file_name.lower().endswith(".json"):
        candidates.append(f"{file_name}.json")

    checked_paths: list[str] = []
    for meta_path in _meta_storage_paths_for_file(file_name, source_meta):
        checked_paths.append(meta_path)
        if blob_exists(meta_path):
            logger.info("Reading plan JSON blob from table metadata storage_uri path=%s", meta_path)
            data = read_blob_json(meta_path)
            data = _filter_source_data_with_table_meta(folder, meta_path.rsplit("/", 1)[-1], data, source_meta)
            return meta_path, data

    for candidate in candidates:
        path = _plan_blob_path(plan_number, folder, candidate)
        checked_paths.append(path)
        if blob_exists(path):
            logger.info("Reading plan JSON blob path=%s", path)
            data = read_blob_json(path)
            data = _filter_source_data_with_table_meta(folder, candidate, data, source_meta)
            return path, data

    logger.warning(
        "Plan JSON blob not found plan_number=%s folder=%s file_name=%s bucket=%s checked_paths=%s",
        plan_number,
        folder,
        file_name,
        Config.REVIEW_BUCKET_NAME,
        checked_paths,
    )
    return None, None


def read_historical_plan_item_details(plan_number: str) -> list[dict[str, Any]]:
    """Return plan_item_number / plan_item_title rows from historical_plan_details.

    Reads:
    dbaware_review_{plan_number}/inbound-data/dbaware/historical_plan_details.json
    """
    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    metadata_map = get_data_extraction_metadata_map(str(plan_number))
    hist_meta = metadata_map.get("historical_plan_details") or metadata_map.get("historical_scoping_document")
    if hist_meta is not None:
        path, data = read_plan_json(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
            source_meta=hist_meta,
        )
    else:
        path, data = read_plan_json(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        )

    if not path:
        expected_path = _plan_blob_path(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        )
        raise FileNotFoundError(
            f"Historical plan details not found for plan '{plan_number}' at '{expected_path}'."
        )

    if not isinstance(data, list):
        raise ValueError("historical_plan_details.json must contain a list of dictionaries.")

    response: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        if item.get("Plan Item Number") in (None, ""):
            logger.warning("Skipping historical plan row without Plan Item Number plan_number=%s", plan_number)
            continue
        response.append(
            {
                "plan_item_number": item.get("Plan Item Number"),
                "plan_item_title": item.get("Plan Item Title"),
            }
        )

    logger.info(
        "Prepared historical plan item details plan_number=%s rows=%s",
        plan_number,
        len(response),
    )
    return response


def delete_historical_plan_item(
    plan_number: str,
    plan_item_numbers: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Delete entries from historical_plan_details by Plan Item Number.

    Titles are not unique across years, so rows are matched on the number only.

    Reads and writes:
    dbaware_review_{plan_number}/inbound-data/dbaware/historical_plan_details.json
    """
    number_set = {
        str(value).strip()
        for value in (plan_item_numbers or [])
        if str(value).strip()
    }

    if not number_set:
        raise ValueError("At least one Plan Item Number is required.")

    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    path, data = read_plan_json(
        plan_number,
        historical_cfg["folder"],
        historical_cfg["file_name"],
    )

    if not path:
        expected_path = _plan_blob_path(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        )
        raise FileNotFoundError(
            f"Historical plan details not found for plan '{plan_number}' at '{expected_path}'."
        )

    if not isinstance(data, list):
        raise ValueError("historical_plan_details.json must contain a list of dictionaries.")

    remaining: list[Any] = []
    deleted: list[dict[str, Any]] = []

    for item in data:
        if not isinstance(item, dict):
            remaining.append(item)
            continue

        item_number = str(item.get("Plan Item Number") or "").strip()

        if item_number in number_set:
            deleted.append(
                {
                    "plan_item_number": item.get("Plan Item Number"),
                    "plan_item_title": item.get("Plan Item Title"),
                }
            )
            continue

        remaining.append(item)

    if not deleted:
        raise LookupError(
            "No matching record found in historical_plan_details.json for provided filter."
        )

    write_blob_json(path, remaining)
    try:
        mark_historical_plan_items_excluded(str(plan_number), number_set)
    except Exception:
        logger.debug("Optional historical metadata exclusion sync failed plan_number=%s", plan_number)

    logger.info(
        "Deleted historical plan item details plan_number=%s deleted_count=%s remaining_count=%s",
        plan_number,
        len(deleted),
        len(remaining),
    )
    return {
        "plan_number": str(plan_number),
        "deleted_count": len(deleted),
        "remaining_count": len(remaining),
        "deleted": deleted,
    }

def _natural_key(path: str) -> list:
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", path)]


def _relevance(doc: Any) -> float:
    try:
        return float(doc.get("document_relevance_score"))
    except (AttributeError, TypeError, ValueError):
        return float("-inf")


def _accepts_kwarg(fn: Any, kwarg_name: str) -> bool:
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return False
    return any(
        param.kind == inspect.Parameter.VAR_KEYWORD or name == kwarg_name
        for name, param in sig.parameters.items()
    )


def _merge_source_meta_docs(*metas: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    merged_docs: list[dict[str, Any]] = []
    for meta in metas:
        if not isinstance(meta, dict):
            continue
        docs = meta.get("documents")
        if isinstance(docs, list):
            merged_docs.extend(d for d in docs if isinstance(d, dict))
    if not merged_docs:
        return next((m for m in metas if isinstance(m, dict)), None)
    return {"documents": merged_docs}


def _extract_documents_from_payload(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [d for d in payload if isinstance(d, dict)]
    if isinstance(payload, dict):
        for key in ("documents", "sources", "data", "items"):
            candidate = payload.get(key)
            if isinstance(candidate, list):
                return [d for d in candidate if isinstance(d, dict)]
        return [payload]
    return []


async def read_plan_json_parts_async(
    plan_number: str,
    cfg: Dict[str, str],
    source_meta: Optional[Dict[str, Any]] = None,
) -> Any:
    """Merge the per-document JSON parts in cfg['parts_folder'] into one list, most relevant first.

    Falls back to table metadata storage_uri or the legacy single file when the folder has no parts.
    """
    if source_meta is None:
        keys = _source_meta_keys_for(
            folder=cfg.get("folder", ""),
            file_name=cfg.get("file_name", ""),
            parts_folder=cfg.get("parts_folder", ""),
        )
        source_meta = _lookup_source_meta(plan_number, *keys)

    prefix = _plan_blob_path(plan_number, cfg["parts_folder"], "")
    registry_path = _plan_blob_path(plan_number, cfg["folder"], cfg["file_name"])
    try:
        listed = await asyncio.to_thread(list_blob_paths, prefix)
    except Exception:
        logger.exception("Failed to list parts prefix=%s", prefix)
        listed = []

    registry_meta: Optional[Dict[str, Any]] = None
    if any(p.rstrip("/") == registry_path for p in listed):
        try:
            reg_payload = await asyncio.to_thread(read_blob_json, registry_path)
            reg_docs = _extract_documents_from_payload(reg_payload)
            excluded_reg_docs = [d for d in reg_docs if is_excluded_entry(d)]
            if excluded_reg_docs:
                registry_meta = {"documents": excluded_reg_docs}
        except Exception:
            logger.debug("Optional registry exclusion lookup skipped path=%s", registry_path)

    effective_meta = _merge_source_meta_docs(source_meta, registry_meta)

    # list_blob_paths strips the trailing "/", so the legacy sibling file (relevant_policy.json) also matches.
    paths = sorted(
        (p for p in listed if p.startswith(prefix) and p.lower().endswith(".json")),
        key=_natural_key,
    )

    documents: list = []
    doc_filenames: dict[int, str] = {}

    if not paths and isinstance(source_meta, dict) and isinstance(source_meta.get("documents"), list):
        meta_paths: list[str] = []
        for mdoc in source_meta["documents"]:
            if not isinstance(mdoc, dict) or is_excluded_entry(mdoc):
                continue
            blob_path = _blob_path_from_gs_uri(mdoc.get("storage_uri") or mdoc.get("gcs_uri") or mdoc.get("uri"))
            if not blob_path or not blob_path.lower().endswith(".json"):
                continue
            if await asyncio.to_thread(blob_exists, blob_path):
                meta_paths.append(blob_path)
        paths = meta_paths

    if not paths:
        if (
            isinstance(source_meta, dict)
            and isinstance(source_meta.get("documents"), list)
            and source_meta["documents"]
            and all(is_excluded_entry(d) for d in source_meta["documents"] if isinstance(d, dict))
        ):
            return prefix.rstrip("/"), []

        logger.info("No parts under prefix=%s, falling back to %s", prefix, cfg["file_name"])
        if source_meta is not None and _accepts_kwarg(read_plan_json, "source_meta"):
            path, fallback_content = await asyncio.to_thread(
                read_plan_json, plan_number, cfg["folder"], cfg["file_name"], source_meta=source_meta
            )
        else:
            path, fallback_content = await asyncio.to_thread(
                read_plan_json, plan_number, cfg["folder"], cfg["file_name"]
            )
        if isinstance(fallback_content, list):
            fallback_content = _filter_policy_documents_with_table_meta(fallback_content, effective_meta)
        elif isinstance(fallback_content, dict):
            for key in ("documents", "sources", "data", "items"):
                if isinstance(fallback_content.get(key), list):
                    fallback_content = dict(fallback_content)
                    fallback_content[key] = _filter_policy_documents_with_table_meta(
                        fallback_content[key], effective_meta
                    )
                    break
        return path, fallback_content

    contents = await asyncio.gather(*(asyncio.to_thread(read_blob_json, p) for p in paths))

    for path, content in zip(paths, contents):
        part_filename = path.rsplit("/", 1)[-1]
        if isinstance(content, list):
            for d in content:
                if isinstance(d, dict):
                    doc_filenames[id(d)] = part_filename
                    documents.append(d)
        elif isinstance(content, dict) and isinstance(content.get("documents"), list):
            for d in content["documents"]:
                if isinstance(d, dict):
                    doc_filenames[id(d)] = part_filename
                    documents.append(d)
        elif isinstance(content, dict):
            doc_filenames[id(content)] = part_filename
            documents.append(content)
        else:
            logger.warning("Skipping unreadable part path=%s", path)

    documents = _filter_policy_documents_with_table_meta(
        documents,
        effective_meta,
        doc_filenames=doc_filenames,
    )

    # Stable sort keeps filename order for equal/missing scores.
    documents.sort(key=_relevance, reverse=True)
    logger.info("Merged %s parts into %s documents prefix=%s", len(paths), len(documents), prefix)
    return prefix.rstrip("/"), documents


def read_citation_mapping(plan_number: str) -> Dict[str, str]:
    """Reads the chunk_id to path mapping file from blob storage."""
    file_name = "citation_mapping.json"
    path = get_plan_output_blob_path(plan_number, file_name)
    logger.info("Reading citation mapping from path=%s", path)
    if blob_exists(path):
        return read_blob_json(path)
    
    logger.warning("Citation mapping not found at path=%s", path)
    raise FileNotFoundError(f"Citation mapping for plan {plan_number} not found at {path}")


def read_plan_json_by_path(path: str) -> Any: 
    return read_blob_json(path)


def has_plan_data(plan_number: str) -> bool:
    plan_details_config = Config.REVIEW_DATA_FILES["plan_details"]
    plan_details_path = _plan_blob_path(
        plan_number,
        plan_details_config["folder"],
        plan_details_config["file_name"],
    )
    logger.info(
        "Checking for plan data existence plan_number=%s path=%s",
        plan_number,
        plan_details_path,
    )
    exists = blob_exists(plan_details_path)
    logger.info(
        "Plan data existence plan_number=%s path=%s exists=%s",
        plan_number,
        plan_details_path,
        exists,
    )
    return exists

async def read_plan_data_async(plan_number: str) -> Dict[str, Any]:
    logger.info("Reading plan data asynchronously plan_number=%s", plan_number)
    return await get_standard_scoping_data_async(plan_number)


def _unpack_plan_json(result: Any) -> tuple:
    """Normalize the output of read_plan_json into (url, content).

    read_plan_json returns (path, data) when the blob is found, or (None, None) when it
    is missing. This helper safely handles both cases so callers always get a
    (url, content) pair without risking a KeyError/IndexError on missing data.
    """
    if isinstance(result, tuple) and len(result) == 2:
        return result[0], result[1]
    return None, result


async def get_standard_scoping_data_async(plan_number: str) -> Dict[str, Any]:
    logger.debug("Building standard scoping data asynchronously")
    try:
        metadata_map = await asyncio.to_thread(get_data_extraction_metadata_map, str(plan_number))
        if not isinstance(metadata_map, dict):
            metadata_map = {}
    except Exception:
        logger.debug("Could not load data extraction metadata map plan_number=%s", plan_number)
        metadata_map = {}

    def _source_meta(*keys: str) -> Optional[Dict[str, Any]]:
        for key in keys:
            val = metadata_map.get(key)
            if isinstance(val, dict):
                return val
        return None

    def _read_json_task(folder: str, file_name: str, meta: Optional[Dict[str, Any]]):
        if meta is not None and _accepts_kwarg(read_plan_json, "source_meta"):
            return asyncio.to_thread(read_plan_json, plan_number, folder, file_name, source_meta=meta)
        return asyncio.to_thread(read_plan_json, plan_number, folder, file_name)

    def _read_parts_task(cfg: Dict[str, str], meta: Optional[Dict[str, Any]]):
        if meta is not None and _accepts_kwarg(read_plan_json_parts_async, "source_meta"):
            return read_plan_json_parts_async(plan_number, cfg, source_meta=meta)
        return read_plan_json_parts_async(plan_number, cfg)

    complete_plan_cfg = Config.REVIEW_DATA_FILES["plan_details"]
    internet_cfg = Config.REVIEW_DATA_FILES["internet_search_data"]
    findings_cfg = Config.REVIEW_DATA_FILES["findings_details"]
    group_audit_cfg = Config.REVIEW_DATA_FILES["group_audit_details"]
    controls_cfg = Config.REVIEW_DATA_FILES["control_details"]
    risk_driver_cfg = Config.REVIEW_DATA_FILES["risk_driver_details"]
    relevant_kod = Config.REVIEW_DATA_FILES["relevant_kod"]
    relevant_policy = Config.REVIEW_DATA_FILES["relevant_policy"]
    alternate_cfg = Config.REVIEW_DATA_FILES["alc_nalc_details"]
    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    relevant_procedure = Config.REVIEW_DATA_FILES["relevant_procedure"]

    hist_meta = _source_meta("historical_plan_details", "historical_scoping_document")

    (
        current_plan_data,
        internet_search_data,
        findings_data,
        group_audit_data,
        controls_data,
        risk_driver_data,
        relevant_kod,
        relevant_policy,
        relevant_procedure,
        alternate_coverage_data,
        historical_data,
    ) = await asyncio.gather(
        _read_json_task(complete_plan_cfg["folder"], complete_plan_cfg["file_name"], _source_meta("plan_details")),
        _read_json_task(internet_cfg["folder"], internet_cfg["file_name"], _source_meta("lrr", "internet_search_data", "internet_search")),
        _read_json_task(findings_cfg["folder"], findings_cfg["file_name"], _source_meta("gfms", "findings_details", "findings")),
        _read_json_task(group_audit_cfg["folder"], group_audit_cfg["file_name"], _source_meta("group_audit", "group_audit_details")),
        _read_json_task(controls_cfg["folder"], controls_cfg["file_name"], _source_meta("key_controls", "control_details")),
        _read_json_task(risk_driver_cfg["folder"], risk_driver_cfg["file_name"], _source_meta("risk_drivers", "risk_driver_details")),
        _read_parts_task(relevant_kod, _source_meta("kod", "relevant_kod")),
        _read_parts_task(relevant_policy, _source_meta("policy", "relevant_policy")),
        _read_parts_task(relevant_procedure, _source_meta("procedure", "relevant_procedure")),
        _read_json_task(alternate_cfg["folder"], alternate_cfg["file_name"], _source_meta("alc_nalc", "alternative_coverage", "alc_nalc_details")),
        _read_json_task(historical_cfg["folder"], historical_cfg["file_name"], hist_meta),
    )

    # Normalize each result into (url, content). read_plan_json returns
    # (path, data) when the blob exists and {} when it is missing, so unpacking
    # safely here avoids KeyError/IndexError for absent files (e.g. procedure).
    current_plan_url, current_plan_data = _unpack_plan_json(current_plan_data)
    internet_search_url, internet_search_data = _unpack_plan_json(internet_search_data)
    findings_url, findings_data = _unpack_plan_json(findings_data)
    group_audit_url, group_audit_data = _unpack_plan_json(group_audit_data)
    controls_url, controls_data = _unpack_plan_json(controls_data)
    risk_driver_url, risk_driver_data = _unpack_plan_json(risk_driver_data)
    relevant_kod_url, relevant_kod = _unpack_plan_json(relevant_kod)
    relevant_policy_url, relevant_policy = _unpack_plan_json(relevant_policy)
    relevant_procedure_url, relevant_procedure = _unpack_plan_json(relevant_procedure)
    alternate_coverage_url, alternate_coverage_data = _unpack_plan_json(alternate_coverage_data)
    historical_url, historical_data = _unpack_plan_json(historical_data)
    historical_plan_numbers = _extract_historical_plan_numbers(historical_data)
    if hist_meta is not None:
        historical_documents = _resolve_historical_review_documents(historical_plan_numbers, source_meta=hist_meta)
    else:
        historical_documents = _resolve_historical_review_documents(historical_plan_numbers)

    output1 = [
        {
            "source_name": "current_plan_item_details",
            "metadata": {"url": current_plan_url},
            "content": current_plan_data,
        },
        {
            "source_name": "historical_plan_item_details",
            "metadata": {"url": historical_url},
            "content": historical_data,
        },
    ]
    # Build independent chunk dicts per output; add_chunk_id mutates in place and
    # sharing objects across outputs would silently overwrite/gap their chunk_id.
    output1.extend(
        _build_historical_document_chunk(document)
        for document in historical_documents
    )
    # built_historical_documents = [
    #     _build_historical_document_chunk(document)
    #     for document in historical_documents
    # ]
    # logger.info("created historical documents ")
    # print(built_historical_documents)

    data = {
        "output1": output1,


        "output2": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            }
            ],


        "output3": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "alternate_coverage",
                "metadata": {"url": alternate_coverage_url},
                "content": alternate_coverage_data,
            },
            {
                "source_name": "group_audit",
                "metadata": {"url": group_audit_url},
                "content": group_audit_data,
            },
            {
                "source_name": "key_controls",
                "metadata": {"url": controls_url},
                "content": controls_data,
            },
            {
                "source_name": "risk_drivers",
                "metadata": {"url": risk_driver_url},
                "content": risk_driver_data,
            },
            {
                "source_name": "findings",
                "metadata": {"url": findings_url},
                "content": findings_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            },
            *(
                _build_historical_document_chunk(document)
                for document in historical_documents
            ),
        ],
    }

    # A missing configured blob is returned as (None, None). Do not expose it
    # as a numbered prompt chunk: it has no URI that get_document can resolve.
    for output_name, chunks in data.items():
        resolved_chunks = []
        for chunk in chunks:
            metadata = chunk.get("metadata") or {}
            content = chunk.get("content") or {}
            embedded_citations = (
                content.get("citations") or content.get("sources")
                if isinstance(content, dict)
                else None
            )
            has_embedded_uri = (
                isinstance(embedded_citations, list)
                and any(
                    isinstance(citation, dict) and citation.get("gs_uri")
                    for citation in embedded_citations
                )
            )
            if metadata.get("url") or has_embedded_uri:
                resolved_chunks.append(chunk)
                continue
            logger.warning(
                "Skipping unresolved source chunk plan_number=%s output=%s source_name=%s",
                plan_number,
                output_name,
                chunk.get("source_name"),
            )
        data[output_name] = resolved_chunks

    indexed_data = add_chunk_id(data)
    chunk_id_path_mapping = create_citation_mapping(indexed_data)
    return indexed_data, chunk_id_path_mapping


def add_chunk_id(data):
    """Assign chunk ids across all outputs.

    Historical review documents get a stable string id so that adding or removing
    historical reviews never shifts the numeric ids of the other sources.
    """
    chunk_id = 1

    for key in data:
        # Documents of a historical review are numbered per review (HIST|<plan>|<n>), in listing
        # order, so the id is the same in every output and independent of other reviews.
        historical_counts: Dict[str, int] = {}
        for chunk in data[key]:
            if chunk.get("source_name") == "historical_review_document":
                content = chunk.get("content") or {}
                plan = str(content.get("historic_plan_number"))
                historical_counts[plan] = historical_counts.get(plan, 0) + 1
                chunk["chunk_id"] = f"HIST|{plan}|{historical_counts[plan]}"
                continue
            chunk["chunk_id"] = chunk_id
            chunk_id += 1

    return data

def create_citation_mapping(indexed_data: Dict[str, Any]) -> Dict[int, list]:
    """
    Creates a mapping from chunk_id to a list of citation details.

    This function processes indexed data to extract citation information.
    For certain source types (containing 'kod', 'policy', or 'scoping'), it
    attempts to extract detailed citations from the content. Otherwise, it
    falls back to using the metadata URL as the citation source.

    The format for the output is:
    {
        "chunk_id": [{
            "content_type": "application/json" or "application/pdf",
            "document_name": "...",
            "access_info": {
                "uri": "..."
            }
        }]
    }

    Args:
        indexed_data: A dictionary containing the structured data with chunk_ids.

    Returns:
        A dictionary mapping each chunk_id to a list of citation objects.
    """
    chunk_id_path_mapping = {}
    source_keywords = ["kod", "policy", "scoping"]

    try:
        for key in indexed_data:
            if not isinstance(indexed_data.get(key), list):
                continue

            for chunk in indexed_data[key]:
                try:
                    chunk_id = chunk.get("chunk_id")
                    if not chunk_id:
                        logger.warning("Skipping chunk without chunk_id in key '%s'", key)
                        continue

                    citations_for_chunk = []
                    content = chunk.get("content")
                    source_name = chunk.get("source_name", "")
                    metadata = chunk.get("metadata", {})
                    url = metadata.get("url")

                    # Check if source_name contains keywords and content has 'citations'
                    if (any(keyword in source_name.lower() for keyword in source_keywords) and
                            isinstance(content, dict) and
                            "citations" in content and
                            isinstance(content.get("citations"), list)):

                        for citation in content["citations"]:
                            if isinstance(citation, dict):
                                doc_name = citation.get("document_name", "")
                                gs_uri = citation.get("gs_uri")
                                page_number = citation.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # parsing logic for new policy/kod/scoping structures using a "sources" list
                    if (not citations_for_chunk and
                            isinstance(content, dict) and
                            isinstance(content.get("sources"), list)):

                        for source in content["sources"]:
                            if isinstance(source, dict):
                                doc_name = source.get("document_name", "")
                                gs_uri = source.get("gs_uri")
                                page_number = source.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # Fallback to metadata URL if no content citations were found or applicable
                    if not citations_for_chunk and url:
                        doc_name = url.split("/")[-1]
                        lower_name = doc_name.lower()
                        fallback_content_type = (
                            "application/pdf"
                            if lower_name.endswith(".pdf")
                            else "application/json"
                        )
                        citations_for_chunk.append({
                            "content_type": fallback_content_type,
                            "document_name": doc_name,
                            "access_info": {"uri": url},
                            "location_metadata": {}
                        })

                    chunk_id_path_mapping[str(chunk_id)] = citations_for_chunk
                    logger.info("mapping created for chunk_id = %s, citations = %s", chunk_id, str(citations_for_chunk[0])) 

                except Exception as e:
                    logger.error(
                        "Error processing chunk %s for citation mapping: %s",
                        chunk.get("chunk_id", "N/A"), e, exc_info=True
                    )

    except Exception as e:
        logger.error("Failed to create citation mapping. Error: %s", e, exc_info=True)

    return chunk_id_path_mapping



def process_citations(planNumber: str, chunk_id: int) -> Dict[str, Any]:
    """
    Fetches and processes the first citation document for a given chunk_id.

    This function reads the citation mapping for a plan, finds the relevant
    citations for the given chunk_id, and processes the first one based on its
    content type.
    - For JSON documents, it reads and returns the content.
    - For PDF documents, it fetches the document, encodes it in base64, and
      returns it along with metadata.

    Args:
        planNumber: The plan number.
        chunk_id: The chunk ID to retrieve citations for.

    Returns:
        A dictionary representing the processed citation. This contains the
        type, source metadata, and either the content (for JSON) or base64
        encoded content (for PDF).

    Raises:
        FileNotFoundError: If the citation mapping for the plan is not found,
                           or if the chunk_id does not exist in the mapping.
        RuntimeError: For any other unexpected errors during processing.
        ValueError: If the citation entry is missing a URI.
    """
    try:
        logger.info(
            "Processing citation for plan_number=%s  chunk_id=%s",
            planNumber,
            chunk_id,
        )
        mapping = read_citation_mapping(planNumber)  # Can raise FileNotFoundError
        chunk_id_str = str(chunk_id)
        citations = mapping.get(chunk_id_str) or mapping.get(chunk_id)
        logger.info("printing citation mapping ")
        print(mapping)
        if not citations:
            logger.warning("No citations found for chunk_id %s in plan %s", chunk_id, planNumber)
            raise FileNotFoundError(f"Document for chunk_id {chunk_id} not found in mapping for plan {planNumber}")

        # Per requirement, only process the first citation
        first_citation = citations[0]

        content_type = first_citation.get("content_type")
        uri = first_citation.get("access_info", {}).get("uri")

        if not uri:
            logger.error("First citation for chunk_id %s is missing a URI.", chunk_id)
            raise ValueError(f"Citation for chunk_id {chunk_id} is invalid; missing URI.")

        if content_type == "application/json":
            try:
                json_content = read_plan_json_by_path(uri)
                return {"type": "json", "source": first_citation, "content": json_content}
            except FileNotFoundError:
                logger.error("JSON blob not found at path: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        elif content_type == "application/pdf":
            try:
                pdf_bytes = read_blob_from_uri_as_bytes(uri)
                pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
                return {"type": "pdf", "source": first_citation, "content": pdf_base64}
            except FileNotFoundError:
                logger.error("PDF blob not found at URI: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        else:
            logger.warning("Unsupported content_type '%s' for chunk_id %s and uri %s", content_type, chunk_id, uri)
            return {"type": "unsupported", "source": first_citation}
    except FileNotFoundError:
        logger.warning("Citation file or chunk_id not found for plan_number=%s.", planNumber)
        raise
    except ValueError as e:
        logger.error(str(e))
        raise
    except Exception as exc:
        logger.exception("Unexpected error in process_citations. plan_number=%s chunk_id=%s", planNumber, chunk_id)
        raise RuntimeError(f"An unexpected error occurred while processing citations for chunk {chunk_id}.") from exc


def process_document_uri(document_uri: str, page_number: int = 1) -> Dict[str, Any]:
    """Fetches and processes a document directly from a gs:// URI."""
    parsed_uri = urlparse(document_uri)
    if parsed_uri.scheme != "gs":
        raise ValueError("document_uri must use the gs:// scheme.")

    document_name = parsed_uri.path.rsplit("/", 1)[-1] if parsed_uri.path else "document"
    source = {
        "content_type": "application/octet-stream",
        "document_name": document_name,
        "access_info": {"uri": document_uri},
        "location_metadata": {"page_number": page_number},
    }

    if document_name.lower().endswith(".json"):
        raw_bytes = read_blob_from_uri_as_bytes(document_uri)
        raw_text = raw_bytes.decode("utf-8")
        try:
            content = json.loads(raw_text)
        except json.JSONDecodeError:
            content = raw_text
        source["content_type"] = "application/json"
        return {"type": "json", "source": source, "content": content}

    if document_name.lower().endswith(".pdf"):
        pdf_bytes = read_blob_from_uri_as_bytes(document_uri)
        pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
        source["content_type"] = "application/pdf"
        return {"type": "pdf", "source": source, "content": pdf_base64}

    return {"type": "unsupported", "source": source}