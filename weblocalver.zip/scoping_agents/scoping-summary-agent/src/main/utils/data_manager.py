import asyncio
import base64
import json
import logging
import re
from typing import Any, Dict, List, Optional, Set
from urllib.parse import urlparse

from config.config import Config
from persistor.review_data_extraction_repository import (
    get_data_extraction_metadata_map,
    mark_historical_plan_items_excluded,
)
from utils.storage_manager import (
    blob_exists,
    list_blob_paths,
    read_blob_json,
    read_blob_from_uri_as_bytes,
    write_blob_json,
)

logger = logging.getLogger(__name__)


def _resolve_blob_path_from_uri(uri_or_path: Optional[str]) -> Optional[str]:
    """Strip gs://<bucket>/ prefix from a storage_uri so blob_exists/read_blob_json receive a blob path."""
    if not uri_or_path:
        return None
    raw = str(uri_or_path).strip()
    if raw.startswith("gs://"):
        parsed = urlparse(raw)
        path = parsed.path.lstrip("/")
        return path or None
    return raw.lstrip("/") or None


_FILE_TO_DATA_SOURCE_KEYS: Dict[str, tuple[str, ...]] = {
    "plan_details.json": ("current_details", "plan_details"),
    "alc_nalc_details.json": ("alc_nlac", "alc_nalc_details"),
    "historical_plan_details.json": ("historical_plan_details", "historical_scoping_document"),
    "control_details.json": ("control_details",),
    "risk_driver_details.json": ("risk_driver_details",),
    "findings_details.json": ("findings_details", "gfms"),
    "group_audit_details.json": ("group_audit", "group_audit_details"),
    "internet_search_data.json": ("lrr", "internet_search_data"),
    "internet_search_data_enriched.json": ("lrr", "internet_search_data"),
    "relevant_kod.json": ("kod", "relevant_kod"),
    "relevant_procedure.json": ("procedure", "relevant_procedure"),
    "relevant_policy.json": ("policy", "relevant_policy"),
}


def _lookup_source_meta(
    metadata_map: Optional[Dict[str, Dict[str, Any]]],
    *candidate_keys: str,
) -> Optional[Dict[str, Any]]:
    if not metadata_map:
        return None
    for key in candidate_keys:
        if not key:
            continue
        k_low = key.strip().lower()
        if k_low in metadata_map:
            return metadata_map[k_low]
        for mapped_key in _FILE_TO_DATA_SOURCE_KEYS.get(k_low, ()):
            if mapped_key in metadata_map:
                return metadata_map[mapped_key]
    return None



def _base_prefix(plan_number: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number),
    )
    parts = [p.strip("/") for p in [Config.REVIEW_BUCKET_PREFIX, plan_folder, Config.REVIEW_INBOUND_DATA_FOLDER] if p]
    return "/".join(parts)


def _historical_bucket_name() -> str:
    return Config.HISTORICAL_REVIEW_BUCKET_NAME or Config.REVIEW_BUCKET_NAME


def _plan_blob_path(plan_number: str, folder: str, file_name: str) -> str:
    return "/".join([_base_prefix(plan_number), folder, file_name])


def _build_gs_uri(blob_path: str, bucket_name: Optional[str] = None) -> str:
    resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
    return f"gs://{resolved_bucket_name}/{blob_path.lstrip('/')}"


def _historical_documents_prefix(historical_plan_number: str) -> str:
    """Build the prefix that stores historical scoping docs for a historical review id."""
    parts = [
        p.strip("/")
        for p in [
            Config.HISTORICAL_REVIEW_DOCS_PREFIX,
            str(historical_plan_number),
        ]
        if p
    ]
    return "/".join(parts)


def _extract_historical_plan_numbers(node: Any) -> list[str]:
    """Extract historical plan numbers from fixed historical_plan_details format.

    Expected input is a list of objects where each object contains
    "Plan Item Number".
    """
    if not isinstance(node, list):
        return []

    plan_numbers: list[str] = []
    for item in node:
        if not isinstance(item, dict):
            continue
        plan_number = item.get("Plan Item Number")
        if plan_number not in (None, ""):
            plan_numbers.append(str(plan_number).strip())

    deduped = []
    seen = set()
    for item in plan_numbers:
        if item not in seen:
            deduped.append(item)
            seen.add(item)
    return deduped


def _list_historical_review_documents(historical_plan_numbers: list[str]) -> list[Dict[str, Any]]:
    """Discover historical scoping documents for the given historical review ids.

    Expected layout: <historical_docs_prefix>/<historical_review_id>/<files>
    Only PDF files are currently attached to the model payload.
    """
    documents: list[Dict[str, Any]] = []
    bucket_name = _historical_bucket_name()
    for historical_plan_number in historical_plan_numbers:
        prefix = _historical_documents_prefix(historical_plan_number)

        try:
            blob_paths = list_blob_paths(prefix, bucket_name=bucket_name)
        except Exception:
            logger.exception(
                "Failed to list historical documents historical_plan_number=%s prefix=%s",
                historical_plan_number,
                prefix,
            )
            continue

        for blob_path in blob_paths:
            if blob_path.endswith("/"):
                continue
            if not blob_path.lower().endswith(".pdf"):
                logger.debug("Skipping unsupported historical document blob_path=%s", blob_path)
                continue

            documents.append(
                {
                    "historic_plan_number": str(historical_plan_number),
                    "document_name": blob_path.rsplit("/", 1)[-1],
                    "uri": _build_gs_uri(blob_path, bucket_name=bucket_name),
                }
            )

    logger.info(
        "Discovered historical review documents count=%s from_plans=%s",
        len(documents),
        [str(plan_number) for plan_number in historical_plan_numbers],
    )
    return documents


def _build_historical_document_chunk(document: Dict[str, Any]) -> Dict[str, Any]:
    """Build a standard source chunk for a historical review document."""
    return {
        "source_name": "historical_review_document",
        "metadata": {
            "url": document["uri"],
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
        "content": {
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
    }


def get_plan_output_blob_path(plan_number: str, file_name: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    )
    outbound_folder = (Config.REVIEW_OUTBOUND_DATA_FOLDER).strip("/")

    parts = [
        p.strip("/")
        for p in [
            Config.REVIEW_BUCKET_PREFIX,
            plan_folder,
            outbound_folder,
            file_name,
        ]
        if p
    ]
    return "/".join(parts)


def get_preliminary_research_blob_path(plan_number: str) -> str:
    """Build preliminary research blob path under the plan folder.

    Target format:
    dbaware_review_{plan_number}/processing-data/preliminary-research/preliminary-research.json
    """
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    ).strip("/")
    outbound_folder = Config.REVIEW_OUTBOUND_DATA_FOLDER.strip("/")
    file_name = Config.REVIEW_OUTBOUND_DATA_FILE.strip("/")
    return "/".join([plan_folder, outbound_folder, file_name])


def get_preliminary_research_section_blob_path(plan_number: str, section_key: str) -> str:
    """Build the blob path of a single preliminary research section.

    Target format:
    dbaware_review_{plan_number}/processing-data/preliminary-research/{section_key}.json
    """
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    ).strip("/")
    outbound_folder = Config.REVIEW_OUTBOUND_DATA_FOLDER.strip("/")
    return "/".join([plan_folder, outbound_folder, f"{section_key}.json"])


def _filter_findings_data_with_table_meta(data: Any, source_meta: Optional[Dict[str, Any]] = None) -> Any:
    """Filter out soft-excluded GFMS findings based on inline flags and review_data_extraction.metadata."""
    excluded_finding_ids: Set[str] = set()
    excluded_node_ids: Set[str] = set()

    if isinstance(source_meta, dict):
        docs = source_meta.get("documents") or []
        if docs and all(isinstance(d, dict) and _is_excluded_document(d) for d in docs):
            return [] if isinstance(data, list) else {}
        for doc in docs:
            if not isinstance(doc, dict):
                continue
            for sec in doc.get("sections") or []:
                if isinstance(sec, dict) and _is_excluded_document(sec):
                    if sec.get("section_id") is not None:
                        excluded_finding_ids.add(str(sec["section_id"]).strip().lower())
                    if sec.get("node_id"):
                        excluded_node_ids.add(str(sec["node_id"]).strip().lower())

    def _is_finding_item_excluded(finding: dict, idx: int) -> bool:
        if _is_excluded_document(finding):
            return True
        fid = str(
            finding.get("findingId")
            or finding.get("Finding Number")
            or finding.get("finding_number")
            or finding.get("id")
            or idx
        ).strip().lower()
        return (
            fid in excluded_finding_ids
            or f"gfms:finding:{fid}" in excluded_node_ids
            or f"finding:{fid}" in excluded_node_ids
        )

    if isinstance(data, dict):
        if _is_excluded_document(data):
            return {}
        d_copy = dict(data)
        for key in ("Finding Details", "Issue Details", "responsePayload", "findings"):
            if isinstance(d_copy.get(key), list):
                d_copy[key] = [
                    item
                    for idx, item in enumerate(d_copy[key], start=1)
                    if not (isinstance(item, dict) and _is_finding_item_excluded(item, idx))
                ]
        return d_copy

    if not isinstance(data, list):
        return data

    filtered_wrappers: list[Any] = []
    for idx_w, wrapper in enumerate(data, start=1):
        if not isinstance(wrapper, dict):
            filtered_wrappers.append(wrapper)
            continue
        if _is_excluded_document(wrapper):
            continue
        payload = wrapper.get("responsePayload")
        if isinstance(payload, list):
            kept = [
                finding
                for idx, finding in enumerate(payload, start=1)
                if not (isinstance(finding, dict) and _is_finding_item_excluded(finding, idx))
            ]
            if kept or not payload:
                w_copy = dict(wrapper)
                w_copy["responsePayload"] = kept
                filtered_wrappers.append(w_copy)
        else:
            if _is_finding_item_excluded(wrapper, idx_w):
                continue
            filtered_wrappers.append(wrapper)
    return filtered_wrappers


def _filter_historical_plan_data_with_table_meta(data: Any, source_meta: Optional[Dict[str, Any]] = None) -> Any:
    """Filter out soft-excluded historical plan items based on inline flags and review_data_extraction.metadata."""
    excluded_plan_nums: Set[str] = set()
    excluded_node_ids: Set[str] = set()

    if isinstance(source_meta, dict):
        docs = source_meta.get("documents") or []
        json_docs = [
            d for d in docs
            if isinstance(d, dict) and str(d.get("filename") or "").lower().endswith(".json")
        ]
        if json_docs and all(_is_excluded_document(d) for d in json_docs):
            return []
        for doc in docs:
            if not isinstance(doc, dict):
                continue
            if _is_excluded_document(doc):
                hist_num = str(doc.get("historic_plan_number") or doc.get("document_id") or "").strip().lower()
                if hist_num and hist_num not in ("historical_plan_details", "historical_scoping_document"):
                    excluded_plan_nums.add(hist_num)
            for sec in doc.get("sections") or []:
                if isinstance(sec, dict) and _is_excluded_document(sec):
                    if sec.get("section_id") is not None:
                        excluded_plan_nums.add(str(sec["section_id"]).strip().lower())
                    if sec.get("node_id"):
                        excluded_node_ids.add(str(sec["node_id"]).strip().lower())

    if not isinstance(data, list):
        return data

    filtered_items = []
    for idx, item in enumerate(data, start=1):
        if not isinstance(item, dict):
            filtered_items.append(item)
            continue
        if _is_excluded_document(item):
            continue
        pnum = str(item.get("Plan Item Number") or item.get("plan_item_number") or idx).strip().lower()
        pnode = f"historical_plan:{pnum}"
        if pnum in excluded_plan_nums or pnode in excluded_node_ids:
            continue
        filtered_items.append(item)
    return filtered_items


def _normalize_lrr_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("_", " ")).strip().lower()


def _filter_lrr_data_with_table_meta(data: Any, source_meta: Optional[Dict[str, Any]] = None) -> Any:
    """Filter out soft-excluded LRR risk entries and mandates using inline flags and table metadata."""
    excluded_sec_ids: Set[str] = set()
    excluded_node_ids: Set[str] = set()
    excluded_titles: Set[str] = set()

    if isinstance(source_meta, dict):
        if _is_excluded_document(source_meta):
            return [] if isinstance(data, list) else {}
        docs = [d for d in (source_meta.get("documents") or []) if isinstance(d, dict)]
        if docs and all(_is_excluded_document(d) for d in docs):
            return [] if isinstance(data, list) else {}

        section_containers: list[dict] = [source_meta, *docs]
        for container in section_containers:
            for sec in container.get("sections") or []:
                if not isinstance(sec, dict) or not _is_excluded_document(sec):
                    continue
                if sec.get("section_id") is not None:
                    excluded_sec_ids.add(str(sec["section_id"]).strip().lower())
                if sec.get("node_id"):
                    excluded_node_ids.add(str(sec["node_id"]).strip().lower())
                norm_title = _normalize_lrr_text(sec.get("section_title") or sec.get("title"))
                if norm_title:
                    excluded_titles.add(norm_title)

    def _is_mandate_excluded(mandate: dict, global_idx: int) -> bool:
        if _is_excluded_document(mandate):
            return True
        explicit_nid = str(mandate.get("node_id") or "").strip().lower()
        indexed_nid = f"lrr:mandate:{global_idx}"
        if (explicit_nid and explicit_nid in excluded_node_ids) or indexed_nid in excluded_node_ids:
            return True
        explicit_sid = str(mandate.get("section_id") or "").strip().lower()
        if (explicit_sid and explicit_sid in excluded_sec_ids) or str(global_idx) in excluded_sec_ids:
            return True
        title = _normalize_lrr_text(
            mandate.get("Regulatory Mandate")
            or mandate.get("mandate")
            or mandate.get("Citation")
            or mandate.get("section_title")
        )
        return bool(title and title in excluded_titles)

    def _filter_entries(entries: list[Any]) -> list[Any]:
        filtered: list[Any] = []
        global_idx = 0
        for item in entries:
            if not isinstance(item, dict):
                filtered.append(item)
                continue
            mandates = item.get("Mandates")
            if isinstance(mandates, list):
                risk_excluded = _is_excluded_document(item)
                kept_mandates = []
                for mandate in mandates:
                    if not isinstance(mandate, dict):
                        continue
                    global_idx += 1
                    if risk_excluded or _is_mandate_excluded(mandate, global_idx):
                        continue
                    kept_mandates.append(mandate)
                if not risk_excluded and kept_mandates:
                    item_copy = dict(item)
                    item_copy["Mandates"] = kept_mandates
                    filtered.append(item_copy)
            else:
                global_idx += 1
                if not _is_mandate_excluded(item, global_idx):
                    filtered.append(item)
        return filtered

    if isinstance(data, list):
        return _filter_entries(data)
    if isinstance(data, dict):
        if _is_excluded_document(data):
            return {}
        d_copy = dict(data)
        for key, value in d_copy.items():
            if isinstance(value, list) and any(isinstance(v, dict) for v in value):
                d_copy[key] = _filter_entries(value)
        return d_copy
    return data


def _resolve_historical_review_documents(
    historical_plan_numbers: list[str],
    source_meta: Optional[Dict[str, Any]] = None,
) -> list[Dict[str, Any]]:
    """
    Resolve historical scoping PDFs from `review_data_extraction.metadata` first,
    falling back to bucket discovery for any active historical plan numbers not covered by the table.
    """
    active_nums = {str(n).strip() for n in (historical_plan_numbers or []) if str(n).strip()}
    if not active_nums:
        return []

    table_pdfs: list[Dict[str, Any]] = []
    covered_plans: Set[str] = set()
    excluded_pdf_uris: Set[str] = set()
    excluded_pdf_names: Set[str] = set()

    if isinstance(source_meta, dict):
        for doc in source_meta.get("documents") or []:
            if not isinstance(doc, dict):
                continue
            fname = str(doc.get("filename") or doc.get("document_name") or "").strip()
            uri = str(doc.get("storage_uri") or doc.get("uri") or "").strip()
            if not (fname.lower().endswith(".pdf") or uri.lower().endswith(".pdf")):
                continue
            hist_num = str(
                doc.get("historic_plan_number") or doc.get("document_id") or ""
            ).strip()
            if _is_excluded_document(doc):
                if uri:
                    excluded_pdf_uris.add(uri)
                if fname:
                    excluded_pdf_names.add(fname.lower())
                continue
            if hist_num and hist_num not in active_nums:
                continue
            if uri:
                resolved_doc_name = fname or uri.rsplit("/", 1)[-1]
                resolved_hist_num = hist_num or next(iter(active_nums))
                table_pdfs.append(
                    {
                        "historic_plan_number": resolved_hist_num,
                        "document_name": resolved_doc_name,
                        "uri": uri,
                    }
                )
                covered_plans.add(resolved_hist_num)

    remaining_plans = [p for p in historical_plan_numbers if str(p).strip() not in covered_plans]
    discovered = _list_historical_review_documents(remaining_plans) if remaining_plans else []
    for d in discovered:
        if d.get("uri") in excluded_pdf_uris or str(d.get("document_name") or "").lower() in excluded_pdf_names:
            continue
        table_pdfs.append(d)
    return table_pdfs


def read_plan_json(
    plan_number: str,
    folder: str,
    file_name: str,
    source_meta: Optional[Dict[str, Any]] = None,
) -> Any:
    if source_meta is None:
        meta_map = get_data_extraction_metadata_map(plan_number)
        source_meta = _lookup_source_meta(meta_map, file_name, folder)

    checked_paths: list[str] = []
    if isinstance(source_meta, dict) and source_meta:
        docs = [d for d in (source_meta.get("documents") or []) if isinstance(d, dict)]
        # For historical_plan_details, only inspect .json document entries here (PDFs are handled separately)
        if file_name.lower() == "historical_plan_details.json":
            json_docs = [
                d for d in docs
                if str(d.get("filename") or d.get("storage_uri") or "").lower().endswith(".json")
            ]
            if json_docs:
                docs = json_docs

        if docs and all(_is_excluded_document(d) for d in docs):
            logger.info(
                "Source '%s' is marked excluded in review_data_extraction for plan=%s",
                file_name,
                plan_number,
            )
            return None, None

        for doc in docs:
            if _is_excluded_document(doc):
                continue
            uri_path = _resolve_blob_path_from_uri(doc.get("storage_uri"))
            if uri_path and uri_path not in checked_paths:
                checked_paths.append(uri_path)

        reg_uri_path = _resolve_blob_path_from_uri(source_meta.get("registry_storage_uri"))
        if reg_uri_path and reg_uri_path not in checked_paths:
            checked_paths.append(reg_uri_path)

    candidates: list[str] = []
    if file_name.lower() == "internet_search_data.json":
        candidates.append("internet_search_data_enriched.json")
    candidates.append(file_name)
    if not file_name.lower().endswith(".json"):
        candidates.append(f"{file_name}.json")

    for candidate in candidates:
        path = _plan_blob_path(plan_number, folder, candidate)
        if path not in checked_paths:
            checked_paths.append(path)

    for path in checked_paths:
        if blob_exists(path):
            logger.info("Reading plan JSON blob path=%s", path)
            raw_data = read_blob_json(path)
            if file_name.lower() == "findings_details.json":
                raw_data = _filter_findings_data_with_table_meta(raw_data, source_meta)
            elif file_name.lower() == "historical_plan_details.json":
                raw_data = _filter_historical_plan_data_with_table_meta(raw_data, source_meta)
            elif file_name.lower() in ("internet_search_data.json", "internet_search_data_enriched.json"):
                raw_data = _filter_lrr_data_with_table_meta(raw_data, source_meta)
            else:
                raw_data = _filter_excluded_plan_json(raw_data, source_meta)
            return path, raw_data

    logger.warning(
        "Plan JSON blob not found plan_number=%s folder=%s file_name=%s bucket=%s checked_paths=%s",
        plan_number,
        folder,
        file_name,
        Config.REVIEW_BUCKET_NAME,
        checked_paths,
    )
    return None, None


def read_historical_plan_item_details(plan_number: str) -> list[dict[str, Any]]:
    """Return plan_item_number / plan_item_title rows from historical_plan_details.

    Reads path from review_data_extraction metadata or falls back to:
    dbaware_review_{plan_number}/inbound-data/dbaware/historical_plan_details.json
    """
    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    path, data = read_plan_json(
        plan_number,
        historical_cfg["folder"],
        historical_cfg["file_name"],
    )

    if not path:
        expected_path = _plan_blob_path(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        )
        raise FileNotFoundError(
            f"Historical plan details not found for plan '{plan_number}' at '{expected_path}'."
        )

    if not isinstance(data, list):
        raise ValueError("historical_plan_details.json must contain a list of dictionaries.")

    response: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict) or _is_excluded_document(item):
            continue
        if item.get("Plan Item Number") in (None, ""):
            logger.warning("Skipping historical plan row without Plan Item Number plan_number=%s", plan_number)
            continue
        response.append(
            {
                "plan_item_number": item.get("Plan Item Number"),
                "plan_item_title": item.get("Plan Item Title"),
            }
        )

    logger.info(
        "Prepared historical plan item details plan_number=%s rows=%s",
        plan_number,
        len(response),
    )
    return response


def delete_historical_plan_item(
    plan_number: str,
    plan_item_numbers: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Delete entries from historical_plan_details by Plan Item Number.

    Titles are not unique across years, so rows are matched on the number only.

    Reads and writes:
    dbaware_review_{plan_number}/inbound-data/dbaware/historical_plan_details.json
    and synchronizes dbaware_scoping.review_data_extraction metadata.
    """
    number_set = {
        str(value).strip()
        for value in (plan_item_numbers or [])
        if str(value).strip()
    }

    if not number_set:
        raise ValueError("At least one Plan Item Number is required.")

    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    path, data = read_plan_json(
        plan_number,
        historical_cfg["folder"],
        historical_cfg["file_name"],
        source_meta={},
    )

    if not path:
        expected_path = _plan_blob_path(
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        )
        raise FileNotFoundError(
            f"Historical plan details not found for plan '{plan_number}' at '{expected_path}'."
        )

    if not isinstance(data, list):
        raise ValueError("historical_plan_details.json must contain a list of dictionaries.")

    remaining: list[Any] = []
    deleted: list[dict[str, Any]] = []

    for item in data:
        if not isinstance(item, dict):
            remaining.append(item)
            continue

        item_number = str(item.get("Plan Item Number") or "").strip()

        if item_number in number_set:
            deleted.append(
                {
                    "plan_item_number": item.get("Plan Item Number"),
                    "plan_item_title": item.get("Plan Item Title"),
                }
            )
            continue

        remaining.append(item)

    if not deleted:
        raise LookupError(
            "No matching record found in historical_plan_details.json for provided filter."
        )

    write_blob_json(path, remaining)
    mark_historical_plan_items_excluded(plan_number, number_set)

    logger.info(
        "Deleted historical plan item details plan_number=%s deleted_count=%s remaining_count=%s",
        plan_number,
        len(deleted),
        len(remaining),
    )
    return {
        "plan_number": str(plan_number),
        "deleted_count": len(deleted),
        "remaining_count": len(remaining),
        "deleted": deleted,
    }

def _natural_key(path: str) -> list:
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", path)]


def _relevance(doc: Any) -> float:
    try:
        return float(doc.get("document_relevance_score"))
    except (AttributeError, TypeError, ValueError):
        return float("-inf")


_EXCLUDED_DOC_STATUSES = {"removed", "excluded", "deleted", "inactive"}


def _is_excluded_document(doc: Any) -> bool:
    if not isinstance(doc, dict):
        return True
    if doc.get("excluded") is True:
        return True
    status = str(doc.get("status") or "").strip().lower()
    return status in _EXCLUDED_DOC_STATUSES


def _document_identity_keys(doc: dict) -> set[str]:
    keys: set[str] = set()
    for field in ("document_id", "id", "row_primary_key"):
        val = doc.get(field)
        if val not in (None, ""):
            keys.add(f"id:{str(val).strip().lower()}")
    for field in ("filename", "file_name"):
        val = doc.get(field)
        if val not in (None, ""):
            keys.add(f"file:{str(val).strip().lower()}")
    for field in ("document_title", "title", "document_name", "name"):
        val = doc.get(field)
        if val not in (None, ""):
            norm = re.sub(r"\s+", " ", str(val).replace("_", " ")).strip().lower()
            if norm:
                keys.add(f"title:{norm}")
    return keys


def _filter_document_nodes_with_table_sections(
    doc: dict,
    table_doc_entry: Optional[dict] = None,
) -> Optional[dict]:
    """
    Filter a RAG document part (`kod20.json`, `policy10.json`, etc.) against both its own
    inline flags and its `sections` array in `review_data_extraction.metadata`.
    Returns None if the document itself is excluded or if all of its nodes were excluded.
    """
    if _is_excluded_document(doc):
        return None
    if table_doc_entry and _is_excluded_document(table_doc_entry):
        return None

    excluded_node_ids: Set[str] = set()
    excluded_sec_ids: Set[str] = set()
    excluded_sec_titles: Set[str] = set()

    for sec_source in (table_doc_entry, doc):
        if not isinstance(sec_source, dict):
            continue
        for sec in sec_source.get("sections") or []:
            if not isinstance(sec, dict) or not _is_excluded_document(sec):
                continue
            if sec.get("node_id"):
                excluded_node_ids.add(str(sec["node_id"]).strip().lower())
            if sec.get("section_id") is not None:
                excluded_sec_ids.add(str(sec["section_id"]).strip().lower())
            if sec.get("section_title"):
                excluded_sec_titles.add(str(sec["section_title"]).strip().lower())

    doc_copy = dict(doc)
    if table_doc_entry and table_doc_entry.get("storage_uri") and not doc_copy.get("storage_uri"):
        doc_copy["storage_uri"] = table_doc_entry["storage_uri"]

    if isinstance(doc_copy.get("nodes"), list):
        original_nodes = doc_copy["nodes"]
        filtered_nodes = []
        for idx, node in enumerate(original_nodes, start=1):
            if not isinstance(node, dict) or _is_excluded_document(node):
                continue
            nid = str(node.get("node_id") or "").strip().lower()
            sid = str(node.get("section_id") if node.get("section_id") is not None else idx).strip().lower()
            stitle = str(
                node.get("section_title") or node.get("title") or node.get("header_path") or ""
            ).strip().lower()
            if (
                (nid and nid in excluded_node_ids)
                or (sid and sid in excluded_sec_ids)
                or (stitle and stitle in excluded_sec_titles)
            ):
                continue
            filtered_nodes.append(node)
        if original_nodes and not filtered_nodes:
            return None
        doc_copy["nodes"] = filtered_nodes

    return doc_copy


def _filter_excluded_plan_json(content: Any, source_meta: Optional[Dict[str, Any]] = None) -> Any:
    table_by_key: Dict[str, dict] = {}
    excluded_keys: Set[str] = set()
    if isinstance(source_meta, dict):
        for tdoc in source_meta.get("documents") or []:
            if not isinstance(tdoc, dict):
                continue
            if _is_excluded_document(tdoc):
                excluded_keys.update(_document_identity_keys(tdoc))
            for k in _document_identity_keys(tdoc):
                table_by_key[k] = tdoc

    def _filter_doc_list(items: list) -> list:
        out = []
        for d in items:
            if not isinstance(d, dict):
                out.append(d)
                continue
            d_keys = _document_identity_keys(d)
            if excluded_keys and (d_keys & excluded_keys):
                continue
            matched_tdoc = next((table_by_key[k] for k in d_keys if k in table_by_key), None)
            filtered_d = _filter_document_nodes_with_table_sections(d, matched_tdoc)
            if filtered_d is not None:
                out.append(filtered_d)
        return out

    if isinstance(content, list):
        return _filter_doc_list(content)
    if isinstance(content, dict) and isinstance(content.get("documents"), list):
        filtered = dict(content)
        filtered["documents"] = _filter_doc_list(content["documents"])
        return filtered
    if isinstance(content, dict) and "nodes" in content:
        matched_tdoc = None
        for k in _document_identity_keys(content):
            if k in table_by_key:
                matched_tdoc = table_by_key[k]
                break
        return _filter_document_nodes_with_table_sections(content, matched_tdoc) or {}
    return content


async def read_plan_json_parts_async(
    plan_number: str,
    cfg: Dict[str, str],
    source_meta: Optional[Dict[str, Any]] = None,
) -> Any:
    """Merge the per-document JSON parts in cfg['parts_folder'] into one list, most relevant first.

    Uses `review_data_extraction.metadata` (`storage_uri`s and `sections` exclusions) when available,
    falling back to listing `cfg['parts_folder']` or reading the legacy single file.
    """
    if source_meta is None:
        meta_map = await asyncio.to_thread(get_data_extraction_metadata_map, plan_number)
        source_meta = _lookup_source_meta(meta_map, cfg.get("file_name", ""), cfg.get("parts_folder", ""))

    prefix = _plan_blob_path(plan_number, cfg["parts_folder"], "")
    table_docs_by_path: Dict[str, dict] = {}
    table_docs_by_key: Dict[str, dict] = {}
    excluded_keys: set[str] = set()
    table_active_paths: list[str] = []

    if isinstance(source_meta, dict) and source_meta:
        table_docs = [d for d in (source_meta.get("documents") or []) if isinstance(d, dict)]
        if table_docs and all(_is_excluded_document(d) for d in table_docs):
            logger.info("All documents excluded in review_data_extraction for prefix=%s", prefix)
            return prefix.rstrip("/"), []

        for tdoc in table_docs:
            for k in _document_identity_keys(tdoc):
                table_docs_by_key[k] = tdoc
            bpath = _resolve_blob_path_from_uri(tdoc.get("storage_uri"))
            if not bpath and tdoc.get("filename"):
                bpath = _plan_blob_path(plan_number, cfg["parts_folder"], str(tdoc["filename"]))
            if bpath:
                table_docs_by_path[bpath] = tdoc
            if _is_excluded_document(tdoc):
                excluded_keys.update(_document_identity_keys(tdoc))
            elif bpath and bpath.lower().endswith(".json") and bpath not in table_active_paths:
                table_active_paths.append(bpath)

    paths: list[str] = []
    listed: list[str] = []
    if table_active_paths:
        existing_Checks = await asyncio.gather(*(asyncio.to_thread(blob_exists, p) for p in table_active_paths))
        paths = [p for p, ok in zip(table_active_paths, existing_Checks) if ok]

    if not paths:
        try:
            listed = await asyncio.to_thread(list_blob_paths, prefix)
        except Exception:
            logger.exception("Failed to list parts prefix=%s", prefix)
            listed = []
        # list_blob_paths strips the trailing "/", so the legacy sibling file (relevant_policy.json) also matches.
        paths = sorted(
            (
                p for p in listed
                if p.startswith(prefix)
                and p.lower().endswith(".json")
                and not (p in table_docs_by_path and _is_excluded_document(table_docs_by_path[p]))
            ),
            key=_natural_key,
        )

    if not paths:
        logger.info("No parts under prefix=%s, falling back to %s", prefix, cfg["file_name"])
        fallback_result = await asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            cfg["folder"],
            cfg["file_name"],
            source_meta,
        )
        if isinstance(fallback_result, tuple) and len(fallback_result) == 2:
            return fallback_result[0], _filter_excluded_plan_json(fallback_result[1], source_meta)
        return _filter_excluded_plan_json(fallback_result, source_meta)

    sibling_registry_path = (
        _resolve_blob_path_from_uri(source_meta.get("registry_storage_uri"))
        if isinstance(source_meta, dict) and source_meta.get("registry_storage_uri")
        else None
    ) or f"{prefix.rstrip('/')}.json"
    read_paths = list(paths)
    has_sibling_registry = sibling_registry_path in listed or (
        sibling_registry_path not in read_paths
        and isinstance(source_meta, dict)
        and bool(source_meta.get("registry_storage_uri"))
        and await asyncio.to_thread(blob_exists, sibling_registry_path)
    )
    if has_sibling_registry and sibling_registry_path not in read_paths:
        read_paths.append(sibling_registry_path)

    contents = await asyncio.gather(*(asyncio.to_thread(read_blob_json, p) for p in read_paths))

    raw_documents: list[tuple[str, dict]] = []
    for path, content in zip(read_paths, contents):
        is_sibling = has_sibling_registry and path == sibling_registry_path
        if isinstance(content, list):
            items = [d for d in content if isinstance(d, dict)]
        elif isinstance(content, dict) and isinstance(content.get("documents"), list):
            items = [d for d in content["documents"] if isinstance(d, dict)]
        elif isinstance(content, dict):
            items = [content]
        else:
            if not is_sibling:
                logger.warning("Skipping unreadable part path=%s", path)
            continue

        for item in items:
            if _is_excluded_document(item):
                excluded_keys.update(_document_identity_keys(item))
            elif not is_sibling:
                raw_documents.append((path, item))

    documents: list[dict] = []
    for path, d in raw_documents:
        d_keys = _document_identity_keys(d)
        fname = path.rsplit("/", 1)[-1].lower()
        d_keys.add(f"file:{fname}")
        if excluded_keys and (d_keys & excluded_keys):
            continue
        tdoc = table_docs_by_path.get(path) or next(
            (table_docs_by_key[k] for k in d_keys if k in table_docs_by_key),
            None,
        )
        filtered_doc = _filter_document_nodes_with_table_sections(d, tdoc)
        if filtered_doc is not None:
            documents.append(filtered_doc)

    # Stable sort keeps filename order for equal/missing scores.
    documents.sort(key=_relevance, reverse=True)
    logger.info("Merged %s parts into %s documents prefix=%s", len(paths), len(documents), prefix)
    return prefix.rstrip("/"), documents


def read_citation_mapping(plan_number: str) -> Dict[str, str]:
    """Reads the chunk_id to path mapping file from blob storage."""
    file_name = "citation_mapping.json"
    path = get_plan_output_blob_path(plan_number, file_name)
    logger.info("Reading citation mapping from path=%s", path)
    if blob_exists(path):
        return read_blob_json(path)
    
    logger.warning("Citation mapping not found at path=%s", path)
    raise FileNotFoundError(f"Citation mapping for plan {plan_number} not found at {path}")


def read_plan_json_by_path(path: str) -> Any: 
    return read_blob_json(path)


def has_plan_data(plan_number: str) -> bool:
    meta_map = get_data_extraction_metadata_map(plan_number)
    plan_meta = _lookup_source_meta(meta_map, "current_details", "plan_details.json")
    if isinstance(plan_meta, dict):
        for doc in plan_meta.get("documents") or []:
            if isinstance(doc, dict) and not _is_excluded_document(doc):
                uri_path = _resolve_blob_path_from_uri(doc.get("storage_uri"))
                if uri_path and blob_exists(uri_path):
                    return True

    plan_details_config = Config.REVIEW_DATA_FILES["plan_details"]
    plan_details_path = _plan_blob_path(
        plan_number,
        plan_details_config["folder"],
        plan_details_config["file_name"],
    )
    logger.info(
        "Checking for plan data existence plan_number=%s path=%s",
        plan_number,
        plan_details_path,
    )
    exists = blob_exists(plan_details_path)
    logger.info(
        "Plan data existence plan_number=%s path=%s exists=%s",
        plan_number,
        plan_details_path,
        exists,
    )
    return exists

async def read_plan_data_async(plan_number: str) -> Dict[str, Any]:
    logger.info("Reading plan data asynchronously plan_number=%s", plan_number)
    return await get_standard_scoping_data_async(plan_number)


def _unpack_plan_json(result: Any) -> tuple:
    """Normalize the output of read_plan_json into (url, content).

    read_plan_json returns (path, data) when the blob is found, or (None, None) when it
    is missing. This helper safely handles both cases so callers always get a
    (url, content) pair without risking a KeyError/IndexError on missing data.
    """
    if isinstance(result, tuple) and len(result) == 2:
        return result[0], result[1]
    return None, result


def _call_read_plan_json(
    plan_number: str,
    folder: str,
    file_name: str,
    source_meta: Optional[Dict[str, Any]] = None,
) -> Any:
    meta_arg = source_meta if source_meta is not None else {}
    try:
        return read_plan_json(plan_number, folder, file_name, meta_arg)
    except TypeError:
        return read_plan_json(plan_number, folder, file_name)


async def _call_read_plan_json_parts_async(
    plan_number: str,
    cfg: dict,
    source_meta: Optional[Dict[str, Any]] = None,
) -> Any:
    meta_arg = source_meta if source_meta is not None else {}
    try:
        return await read_plan_json_parts_async(plan_number, cfg, meta_arg)
    except TypeError:
        return await read_plan_json_parts_async(plan_number, cfg)


async def get_standard_scoping_data_async(plan_number: str) -> Dict[str, Any]:
    logger.debug("Building standard scoping data asynchronously")
    complete_plan_cfg = Config.REVIEW_DATA_FILES["plan_details"]
    internet_cfg = Config.REVIEW_DATA_FILES["internet_search_data"]
    findings_cfg = Config.REVIEW_DATA_FILES["findings_details"]
    group_audit_cfg = Config.REVIEW_DATA_FILES["group_audit_details"]
    controls_cfg = Config.REVIEW_DATA_FILES["control_details"]
    risk_driver_cfg = Config.REVIEW_DATA_FILES["risk_driver_details"]
    relevant_kod = Config.REVIEW_DATA_FILES["relevant_kod"]
    relevant_policy = Config.REVIEW_DATA_FILES["relevant_policy"]
    alternate_cfg = Config.REVIEW_DATA_FILES["alc_nalc_details"]
    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    relevant_procedure = Config.REVIEW_DATA_FILES["relevant_procedure"]

    meta_map = await asyncio.to_thread(get_data_extraction_metadata_map, plan_number)
    plan_meta = _lookup_source_meta(meta_map, "current_details", complete_plan_cfg["file_name"])
    internet_meta = _lookup_source_meta(meta_map, "lrr", internet_cfg["file_name"])
    findings_meta = _lookup_source_meta(meta_map, "findings_details", "gfms", findings_cfg["file_name"])
    group_audit_meta = _lookup_source_meta(meta_map, "group_audit", group_audit_cfg["file_name"])
    controls_meta = _lookup_source_meta(meta_map, "control_details", controls_cfg["file_name"])
    risk_driver_meta = _lookup_source_meta(meta_map, "risk_driver_details", risk_driver_cfg["file_name"])
    kod_meta = _lookup_source_meta(meta_map, "kod", relevant_kod["file_name"])
    policy_meta = _lookup_source_meta(meta_map, "policy", relevant_policy["file_name"])
    procedure_meta = _lookup_source_meta(meta_map, "procedure", relevant_procedure["file_name"])
    alc_meta = _lookup_source_meta(meta_map, "alc_nlac", alternate_cfg["file_name"])
    historical_meta = _lookup_source_meta(
        meta_map, "historical_plan_details", "historical_scoping_document", historical_cfg["file_name"]
    )

    (
        current_plan_data,
        internet_search_data,
        findings_data,
        group_audit_data,
        controls_data,
        risk_driver_data,
        relevant_kod,
        relevant_policy,
        relevant_procedure,
        alternate_coverage_data,
        historical_data,
    ) = await asyncio.gather(
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            complete_plan_cfg["folder"],
            complete_plan_cfg["file_name"],
            plan_meta,
        ),
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            internet_cfg["folder"],
            internet_cfg["file_name"],
            internet_meta,
        ),
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            findings_cfg["folder"],
            findings_cfg["file_name"],
            findings_meta,
        ),
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            group_audit_cfg["folder"],
            group_audit_cfg["file_name"],
            group_audit_meta,
        ),
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            controls_cfg["folder"],
            controls_cfg["file_name"],
            controls_meta,
        ),
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            risk_driver_cfg["folder"],
            risk_driver_cfg["file_name"],
            risk_driver_meta,
        ),
        _call_read_plan_json_parts_async(plan_number, relevant_kod, kod_meta),
        _call_read_plan_json_parts_async(plan_number, relevant_policy, policy_meta),
        _call_read_plan_json_parts_async(plan_number, relevant_procedure, procedure_meta),
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            alternate_cfg["folder"],
            alternate_cfg["file_name"],
            alc_meta,
        ),
        asyncio.to_thread(
            _call_read_plan_json,
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
            historical_meta,
        ),
    )

    # Normalize each result into (url, content). read_plan_json returns
    # (path, data) when the blob exists and {} when it is missing, so unpacking
    # safely here avoids KeyError/IndexError for absent files (e.g. procedure).
    current_plan_url, current_plan_data = _unpack_plan_json(current_plan_data)
    internet_search_url, internet_search_data = _unpack_plan_json(internet_search_data)
    findings_url, findings_data = _unpack_plan_json(findings_data)
    group_audit_url, group_audit_data = _unpack_plan_json(group_audit_data)
    controls_url, controls_data = _unpack_plan_json(controls_data)
    risk_driver_url, risk_driver_data = _unpack_plan_json(risk_driver_data)
    relevant_kod_url, relevant_kod = _unpack_plan_json(relevant_kod)
    relevant_policy_url, relevant_policy = _unpack_plan_json(relevant_policy)
    relevant_procedure_url, relevant_procedure = _unpack_plan_json(relevant_procedure)
    alternate_coverage_url, alternate_coverage_data = _unpack_plan_json(alternate_coverage_data)
    historical_url, historical_data = _unpack_plan_json(historical_data)
    historical_plan_numbers = _extract_historical_plan_numbers(historical_data)
    historical_documents = _resolve_historical_review_documents(historical_plan_numbers, historical_meta)

    output1 = [
        {
            "source_name": "current_plan_item_details",
            "metadata": {"url": current_plan_url},
            "content": current_plan_data,
        },
        {
            "source_name": "historical_plan_item_details",
            "metadata": {"url": historical_url},
            "content": historical_data,
        },
    ]
    # Build independent chunk dicts per output; add_chunk_id mutates in place and
    # sharing objects across outputs would silently overwrite/gap their chunk_id.
    output1.extend(
        _build_historical_document_chunk(document)
        for document in historical_documents
    )
    # built_historical_documents = [
    #     _build_historical_document_chunk(document)
    #     for document in historical_documents
    # ]
    # logger.info("created historical documents ")
    # print(built_historical_documents)

    data = {
        "output1": output1,


        "output2": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            }
            ],


        "output3": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "alternate_coverage",
                "metadata": {"url": alternate_coverage_url},
                "content": alternate_coverage_data,
            },
            {
                "source_name": "group_audit",
                "metadata": {"url": group_audit_url},
                "content": group_audit_data,
            },
            {
                "source_name": "key_controls",
                "metadata": {"url": controls_url},
                "content": controls_data,
            },
            {
                "source_name": "risk_drivers",
                "metadata": {"url": risk_driver_url},
                "content": risk_driver_data,
            },
            {
                "source_name": "findings",
                "metadata": {"url": findings_url},
                "content": findings_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            },
            *(
                _build_historical_document_chunk(document)
                for document in historical_documents
            ),
        ],
    }

    # A missing configured blob is returned as (None, None). Do not expose it
    # as a numbered prompt chunk: it has no URI that get_document can resolve.
    for output_name, chunks in data.items():
        resolved_chunks = []
        for chunk in chunks:
            metadata = chunk.get("metadata") or {}
            content = chunk.get("content") or {}
            embedded_citations = (
                content.get("citations") or content.get("sources")
                if isinstance(content, dict)
                else None
            )
            has_embedded_uri = (
                isinstance(embedded_citations, list)
                and any(
                    isinstance(citation, dict) and citation.get("gs_uri")
                    for citation in embedded_citations
                )
            )
            if metadata.get("url") or has_embedded_uri:
                resolved_chunks.append(chunk)
                continue
            logger.warning(
                "Skipping unresolved source chunk plan_number=%s output=%s source_name=%s",
                plan_number,
                output_name,
                chunk.get("source_name"),
            )
        data[output_name] = resolved_chunks

    indexed_data = add_chunk_id(data)
    chunk_id_path_mapping = create_citation_mapping(indexed_data)
    return indexed_data, chunk_id_path_mapping


def add_chunk_id(data):
    """Assign chunk ids across all outputs.

    Historical review documents get a stable string id so that adding or removing
    historical reviews never shifts the numeric ids of the other sources.
    """
    chunk_id = 1

    for key in data:
        # Documents of a historical review are numbered per review (HIST|<plan>|<n>), in listing
        # order, so the id is the same in every output and independent of other reviews.
        historical_counts: Dict[str, int] = {}
        for chunk in data[key]:
            if chunk.get("source_name") == "historical_review_document":
                content = chunk.get("content") or {}
                plan = str(content.get("historic_plan_number"))
                historical_counts[plan] = historical_counts.get(plan, 0) + 1
                chunk["chunk_id"] = f"HIST|{plan}|{historical_counts[plan]}"
                continue
            chunk["chunk_id"] = chunk_id
            chunk_id += 1

    return data

def create_citation_mapping(indexed_data: Dict[str, Any]) -> Dict[int, list]:
    """
    Creates a mapping from chunk_id to a list of citation details.

    This function processes indexed data to extract citation information.
    For certain source types (containing 'kod', 'policy', or 'scoping'), it
    attempts to extract detailed citations from the content. Otherwise, it
    falls back to using the metadata URL as the citation source.

    The format for the output is:
    {
        "chunk_id": [{
            "content_type": "application/json" or "application/pdf",
            "document_name": "...",
            "access_info": {
                "uri": "..."
            }
        }]
    }

    Args:
        indexed_data: A dictionary containing the structured data with chunk_ids.

    Returns:
        A dictionary mapping each chunk_id to a list of citation objects.
    """
    chunk_id_path_mapping = {}
    source_keywords = ["kod", "policy", "scoping"]

    try:
        for key in indexed_data:
            if not isinstance(indexed_data.get(key), list):
                continue

            for chunk in indexed_data[key]:
                try:
                    chunk_id = chunk.get("chunk_id")
                    if not chunk_id:
                        logger.warning("Skipping chunk without chunk_id in key '%s'", key)
                        continue

                    citations_for_chunk = []
                    content = chunk.get("content")
                    source_name = chunk.get("source_name", "")
                    metadata = chunk.get("metadata", {})
                    url = metadata.get("url")

                    # Check if source_name contains keywords and content has 'citations'
                    if (any(keyword in source_name.lower() for keyword in source_keywords) and
                            isinstance(content, dict) and
                            "citations" in content and
                            isinstance(content.get("citations"), list)):

                        for citation in content["citations"]:
                            if isinstance(citation, dict):
                                doc_name = citation.get("document_name", "")
                                gs_uri = citation.get("gs_uri")
                                page_number = citation.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # parsing logic for new policy/kod/scoping structures using a "sources" list
                    if (not citations_for_chunk and
                            isinstance(content, dict) and
                            isinstance(content.get("sources"), list)):

                        for source in content["sources"]:
                            if isinstance(source, dict):
                                doc_name = source.get("document_name", "")
                                gs_uri = source.get("gs_uri")
                                page_number = source.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # Fallback to metadata URL if no content citations were found or applicable
                    if not citations_for_chunk and url:
                        doc_name = url.split("/")[-1]
                        lower_name = doc_name.lower()
                        fallback_content_type = (
                            "application/pdf"
                            if lower_name.endswith(".pdf")
                            else "application/json"
                        )
                        citations_for_chunk.append({
                            "content_type": fallback_content_type,
                            "document_name": doc_name,
                            "access_info": {"uri": url},
                            "location_metadata": {}
                        })

                    chunk_id_path_mapping[str(chunk_id)] = citations_for_chunk
                    logger.info("mapping created for chunk_id = %s, citations = %s", chunk_id, str(citations_for_chunk[0])) 

                except Exception as e:
                    logger.error(
                        "Error processing chunk %s for citation mapping: %s",
                        chunk.get("chunk_id", "N/A"), e, exc_info=True
                    )

    except Exception as e:
        logger.error("Failed to create citation mapping. Error: %s", e, exc_info=True)

    return chunk_id_path_mapping



def process_citations(planNumber: str, chunk_id: int) -> Dict[str, Any]:
    """
    Fetches and processes the first citation document for a given chunk_id.

    This function reads the citation mapping for a plan, finds the relevant
    citations for the given chunk_id, and processes the first one based on its
    content type.
    - For JSON documents, it reads and returns the content.
    - For PDF documents, it fetches the document, encodes it in base64, and
      returns it along with metadata.

    Args:
        planNumber: The plan number.
        chunk_id: The chunk ID to retrieve citations for.

    Returns:
        A dictionary representing the processed citation. This contains the
        type, source metadata, and either the content (for JSON) or base64
        encoded content (for PDF).

    Raises:
        FileNotFoundError: If the citation mapping for the plan is not found,
                           or if the chunk_id does not exist in the mapping.
        RuntimeError: For any other unexpected errors during processing.
        ValueError: If the citation entry is missing a URI.
    """
    try:
        logger.info(
            "Processing citation for plan_number=%s  chunk_id=%s",
            planNumber,
            chunk_id,
        )
        mapping = read_citation_mapping(planNumber)  # Can raise FileNotFoundError
        chunk_id_str = str(chunk_id)
        citations = mapping.get(chunk_id_str) or mapping.get(chunk_id)
        logger.info("printing citation mapping ")
        print(mapping)
        if not citations:
            logger.warning("No citations found for chunk_id %s in plan %s", chunk_id, planNumber)
            raise FileNotFoundError(f"Document for chunk_id {chunk_id} not found in mapping for plan {planNumber}")

        # Per requirement, only process the first citation
        first_citation = citations[0]

        content_type = first_citation.get("content_type")
        uri = first_citation.get("access_info", {}).get("uri")

        if not uri:
            logger.error("First citation for chunk_id %s is missing a URI.", chunk_id)
            raise ValueError(f"Citation for chunk_id {chunk_id} is invalid; missing URI.")

        if content_type == "application/json":
            try:
                json_content = read_plan_json_by_path(uri)
                return {"type": "json", "source": first_citation, "content": json_content}
            except FileNotFoundError:
                logger.error("JSON blob not found at path: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        elif content_type == "application/pdf":
            try:
                pdf_bytes = read_blob_from_uri_as_bytes(uri)
                pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
                return {"type": "pdf", "source": first_citation, "content": pdf_base64}
            except FileNotFoundError:
                logger.error("PDF blob not found at URI: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        else:
            logger.warning("Unsupported content_type '%s' for chunk_id %s and uri %s", content_type, chunk_id, uri)
            return {"type": "unsupported", "source": first_citation}
    except FileNotFoundError:
        logger.warning("Citation file or chunk_id not found for plan_number=%s.", planNumber)
        raise
    except ValueError as e:
        logger.error(str(e))
        raise
    except Exception as exc:
        logger.exception("Unexpected error in process_citations. plan_number=%s chunk_id=%s", planNumber, chunk_id)
        raise RuntimeError(f"An unexpected error occurred while processing citations for chunk {chunk_id}.") from exc


def process_document_uri(document_uri: str, page_number: int = 1) -> Dict[str, Any]:
    """Fetches and processes a document directly from a gs:// URI."""
    parsed_uri = urlparse(document_uri)
    if parsed_uri.scheme != "gs":
        raise ValueError("document_uri must use the gs:// scheme.")

    document_name = parsed_uri.path.rsplit("/", 1)[-1] if parsed_uri.path else "document"
    source = {
        "content_type": "application/octet-stream",
        "document_name": document_name,
        "access_info": {"uri": document_uri},
        "location_metadata": {"page_number": page_number},
    }

    if document_name.lower().endswith(".json"):
        raw_bytes = read_blob_from_uri_as_bytes(document_uri)
        raw_text = raw_bytes.decode("utf-8")
        try:
            content = json.loads(raw_text)
        except json.JSONDecodeError:
            content = raw_text
        source["content_type"] = "application/json"
        return {"type": "json", "source": source, "content": content}

    if document_name.lower().endswith(".pdf"):
        pdf_bytes = read_blob_from_uri_as_bytes(document_uri)
        pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
        source["content_type"] = "application/pdf"
        return {"type": "pdf", "source": source, "content": pdf_base64}

    return {"type": "unsupported", "source": source}