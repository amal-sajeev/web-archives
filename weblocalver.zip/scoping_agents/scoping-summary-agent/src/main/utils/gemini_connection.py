import os
import sys
import logging
from typing import Any, Dict
from langchain_google_genai import ChatGoogleGenerativeAI
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.config import Config
from utils.google_oauth_token_provider import (
    GoogleOAuthTokenProvider,
    configure_certificate_once,
)


logger = logging.getLogger(__name__)


def initialize_gemini_model() -> ChatGoogleGenerativeAI:
    """Initialize ChatGoogleGenerativeAI using AI Access Layer token authentication."""
    configure_certificate_once()
    base_url = (
        os.getenv("AI_ACCESS_LAYER_BASE_URL")
        or os.getenv("GENAI_BASE_URL")
        or getattr(Config, "AI_ACCESS_LAYER_BASE_URL", None)
        or getattr(Config, "GENAI_BASE_URL", None)
    )
    if base_url:
        api_key = GoogleOAuthTokenProvider().token
    else:
        api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("AI_ACCESS_LAYER_BASE_URL or GOOGLE_API_KEY must be configured")

    logger.info("Initializing Gemini model model=%s base_url=%s", Config.MODEL_NAME, base_url)
    kwargs: Dict[str, Any] = {
        "model": Config.MODEL_NAME,
        "safety_settings": Config.SAFETY_CONFIG["safety_settings"],
        "api_key": api_key,
    }
    if base_url:
        kwargs["base_url"] = base_url
    return ChatGoogleGenerativeAI(**kwargs)
    