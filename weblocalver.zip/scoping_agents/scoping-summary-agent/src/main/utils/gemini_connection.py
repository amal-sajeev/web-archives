import os
import sys
import logging

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.config import Config
from utils.google_oauth_token_provider import (
    GoogleOAuthTokenProvider,
    configure_certificate_once,
)

logger = logging.getLogger(__name__)


AI_ACCESS_LAYER_BASE_URL = os.getenv(
    "AI_ACCESS_LAYER_BASE_URL"
)


def _resolve_ai_access_layer_base_url() -> str:
    """Resolve the configured AI Access Layer or GenAI proxy base URL at call time."""
    for candidate in (
        os.getenv("AI_ACCESS_LAYER_BASE_URL"),
        os.getenv("GENAI_BASE_URL"),
        getattr(Config, "AI_ACCESS_LAYER_BASE_URL", None),
        getattr(Config, "GENAI_BASE_URL", None),
        AI_ACCESS_LAYER_BASE_URL,
    ):
        text = str(candidate or "").strip()
        if text:
            return text
    return ""


def initialize_gemini_model():
    from langchain_google_genai import ChatGoogleGenerativeAI

    # Only pass explicitly configured values; unset ones fall back to the model defaults.
    banned_kwargs = {"project", "location", "temperature", "top_p", "top_k", "seed"}
    generation_kwargs = {
        key: value
        for key, value in Config.GENERATION_CONFIG.items()
        if value is not None and key not in banned_kwargs
    }
    if Config.THINKING_LEVEL:
        generation_kwargs["thinking_level"] = Config.THINKING_LEVEL

    base_url = _resolve_ai_access_layer_base_url()
    logger.info(
        "Initializing Gemini model model=%s location=%s base_url=%s generation=%s",
        Config.MODEL_NAME,
        Config.PROJECT_LOCATION,
        base_url or "<direct>",
        generation_kwargs,
    )
    if base_url:
        configure_certificate_once()
        provider = GoogleOAuthTokenProvider()
        return ChatGoogleGenerativeAI(
            model=Config.MODEL_NAME,
            api_key=provider.token,
            base_url=base_url,
            safety_settings=Config.SAFETY_CONFIG["safety_settings"],
            **generation_kwargs,
        )

    api_key = (
        str(os.getenv("GOOGLE_API_KEY") or "").strip()
        or str(os.getenv("GEMINI_API_KEY") or "").strip()
    )
    if not api_key:
        raise ValueError(
            "Neither AI_ACCESS_LAYER_BASE_URL nor GOOGLE_API_KEY/GEMINI_API_KEY is configured."
        )
    return ChatGoogleGenerativeAI(
        model=Config.MODEL_NAME,
        api_key=api_key,
        safety_settings=Config.SAFETY_CONFIG["safety_settings"],
        **generation_kwargs,
    )

