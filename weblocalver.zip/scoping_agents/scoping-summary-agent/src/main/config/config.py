import os
from dotenv import load_dotenv
load_dotenv()


class Config:
    db_host = os.getenv("db_host","localhost")
    db_user = os.getenv("db_user")
    db_name = os.getenv("db_name")
    db_port = os.getenv("db_port","5432")
    db_pass = os.getenv("scoping_db_pass")
    MODEL_NAME = (
        os.getenv("GENAI_MODEL_NAME")
        or os.getenv("GCP_MODEL_NAME")
        or "gemini-2.5-pro"
    )
    AI_ACCESS_LAYER_BASE_URL = (
        os.getenv("AI_ACCESS_LAYER_BASE_URL")
        or os.getenv("GENAI_BASE_URL")
    )
    GENAI_BASE_URL = os.getenv("GENAI_BASE_URL") or AI_ACCESS_LAYER_BASE_URL
    SAFETY_CONFIG = {
        "safety_settings": {
            "HARM_CATEGORY_HARASSMENT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_HATE_SPEECH": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_MEDIUM_AND_ABOVE"
        }
    }
    PROJECT_NAME = (
        os.getenv("PROJECT_NAME")
        or os.getenv("project_name")
    
    )
    PROJECT_LOCATION = (
        os.getenv("PROJECT_LOCATION")
        or os.getenv("project_location")
        
    )
    REVIEW_BUCKET_NAME = os.getenv(
        "DBAWARE_REVIEW_BUCKET_NAME",
    )
    HISTORICAL_REVIEW_BUCKET_NAME = os.getenv(
        "DBAWARE_HISTORICAL_REVIEW_BUCKET_NAME",
        REVIEW_BUCKET_NAME,
    )
    REVIEW_BUCKET_PREFIX = os.getenv("DBAWARE_REVIEW_BUCKET_PREFIX", "")
    REVIEW_PLAN_FOLDER_TEMPLATE = "dbaware_review_{plan_number}"
    REVIEW_INBOUND_DATA_FOLDER = "inbound-data"
    REVIEW_OUTBOUND_DATA_FOLDER = "processing-data/preliminary-research"
    REVIEW_OUTBOUND_DATA_FILE = "preliminary-research.json"
    HISTORICAL_REVIEW_DOCS_PREFIX = os.getenv(
        "DBAWARE_HISTORICAL_REVIEW_DOCS_PREFIX",
        "historical_scoping_documents",
    )
    DOWNLOAD_PDF_CITATION_BASE_URL = os.getenv(
        "SUMMARY_AGENT_PDF_CITATION_BASE_URL",
        "https://ct1-cta.dbaware.dev.gcp.db.com/dbaware-ui",
    )
    # Warn when a single Broad Scope call's text input exceeds this many tokens (gemini-2.5-pro limit is 1,048,576).
    BROAD_SCOPE_MAX_INPUT_TOKENS = int(os.getenv("SUMMARY_AGENT_BROAD_SCOPE_MAX_INPUT_TOKENS", "900000"))

    
    REVIEW_DATA_FILES = {
        "plan_details": {
            "folder": "dbaware",
            "file_name": os.getenv("DBAWARE_PLAN_DETAILS_FILE", "plan_details.json"),
        },
        "alc_nalc_details": {
            "folder": "dbaware",
            "file_name": os.getenv("DBAWARE_ALC_NALC_DETAILS_FILE", "alc_nalc_details.json"),
        },
        "historical_plan_details": {
            "folder": "dbaware",
            "file_name": os.getenv(
                "DBAWARE_HISTORICAL_PLAN_DETAILS_FILE",
                "historical_plan_details.json",
            ),
        },
        "control_details": {
            "folder": "dbgrc",
            "file_name": os.getenv("DBAWARE_CONTROL_DETAILS_FILE", "control_details.json"),
        },
        "risk_driver_details": {
            "folder": "dbgrc",
            "file_name": os.getenv("DBAWARE_RISK_DRIVER_DETAILS_FILE", "risk_driver_details.json"),
        },
        "findings_details": {
            "folder": "gfms",
            "file_name": os.getenv("DBAWARE_FINDINGS_DETAILS_FILE", "findings_details.json"),
        },
        "group_audit_details": {
            "folder": "group_audit",
            "file_name": os.getenv("DBAWARE_GROUP_AUDIT_DETAILS_FILE", "group_audit_details.json"),
        },
        "internet_search_data": {
            "folder": "lrr",
            "file_name": os.getenv(
                "DBAWARE_INTERNET_SEARCH_FILE",
                "internet_search_data.json",
            ),
        },
        "relevant_kod": {
            "folder": "policy",
            "parts_folder": "policy/relevant_kod",
            "file_name": os.getenv("DBAWARE_RELEVANT_KOD_PROCEDURE_FILE", "relevant_kod.json"),
        },
        "relevant_procedure":{
            "folder": "policy",
            "parts_folder": "policy/relevant_procedure",
            "file_name": os.getenv("DBAWARE_RELEVANT_PROCEDURE_FILE", "relevant_procedure.json"),

        },
        "relevant_policy": {
            "folder": "policy",
            "parts_folder": "policy/relevant_policy",
            "file_name": os.getenv("DBAWARE_RELEVANT_POLICY_FILE", "relevant_policy.json"),
        },
    }
    DATA_EXTRACTION_SYSTEM_PROMPT="You are a Data Extraction Assistant with an access to mcp tools to fetch required data. Please call relevant mcp tools to get the data."
    


