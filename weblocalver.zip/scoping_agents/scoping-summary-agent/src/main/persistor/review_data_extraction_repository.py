"""Repository helpers for reading and updating dbaware_scoping.review_data_extraction."""

from datetime import datetime, timezone
import json
import logging
from typing import Any, Dict, List, Optional, Set

import sqlalchemy
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base

from config.config import Config
from persistor.database_connector import get_session

logger = logging.getLogger(__name__)

SCHEMA_NAME = "dbaware_scoping"
Base = declarative_base()

_EXCLUDED_STATUSES = {"removed", "excluded", "deleted", "inactive"}


class ReviewDataExtractionORM(Base):
    __tablename__ = "review_data_extraction"
    __table_args__ = {"schema": SCHEMA_NAME}

    review_scope_dataext_id = Column(Integer, primary_key=True, autoincrement=True)
    review_scope_id = Column(Integer, nullable=False)
    data_source = Column(String(100), nullable=True)
    metadata_ = Column("metadata", JSONB, nullable=True)
    status = Column(Integer, nullable=True)
    created_by = Column(String(100), nullable=True)
    created_on = Column(DateTime, nullable=True)
    updated_by = Column(String(100), nullable=True)
    updated_on = Column(DateTime, nullable=True)
    remarks = Column(String(500), nullable=True)

    @property
    def review_scope_instance_id(self) -> Optional[str]:
        return str(self.review_scope_id) if self.review_scope_id is not None else None

    @review_scope_instance_id.setter
    def review_scope_instance_id(self, value: Any) -> None:
        self.review_scope_id = _coerce_scope_id(value)


def _coerce_scope_id(value: Any) -> Optional[int]:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    cleaned = str(value).strip()
    if cleaned.lstrip("-").isdigit():
        return int(cleaned)
    return None


def is_excluded_entry(entry: Any) -> bool:
    if not isinstance(entry, dict):
        return False
    if entry.get("excluded") is True:
        return True
    status = str(entry.get("status") or "").strip().lower()
    return status in _EXCLUDED_STATUSES


def normalize_data_extraction_metadata(
    raw_metadata: Any,
    data_source: str,
    review_scope_dataext_id: Optional[int] = None,
    review_scope_instance_id: Optional[str] = None,
    review_scope_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Normalize a review_data_extraction.metadata JSON value into a canonical structure."""
    if isinstance(raw_metadata, str):
        try:
            raw_metadata = json.loads(raw_metadata)
        except Exception:
            raw_metadata = {}

    documents: List[Dict[str, Any]] = []
    registry_filename: Optional[str] = None
    registry_storage_uri: Optional[str] = None

    if isinstance(raw_metadata, dict):
        registry_filename = raw_metadata.get("registry_filename")
        registry_storage_uri = raw_metadata.get("registry_storage_uri")
        if isinstance(raw_metadata.get("documents"), list):
            documents = [dict(d) for d in raw_metadata["documents"] if isinstance(d, dict)]
        elif raw_metadata.get("filename") or raw_metadata.get("storage_uri"):
            documents = [dict(raw_metadata)]
    elif isinstance(raw_metadata, list):
        documents = [dict(d) for d in raw_metadata if isinstance(d, dict)]

    normalized_docs: List[Dict[str, Any]] = []
    for doc in documents:
        doc_copy = dict(doc)
        doc_excluded = is_excluded_entry(doc_copy)
        doc_copy["excluded"] = doc_excluded
        doc_copy["status"] = "excluded" if doc_excluded else str(doc_copy.get("status") or "active")

        raw_sections = doc_copy.get("sections")
        norm_sections: List[Dict[str, Any]] = []
        if isinstance(raw_sections, list):
            for idx, sec in enumerate(raw_sections, start=1):
                if not isinstance(sec, dict):
                    continue
                sec_copy = dict(sec)
                sec_ex = doc_excluded or is_excluded_entry(sec_copy)
                sec_copy["section_id"] = sec_copy.get("section_id") if sec_copy.get("section_id") is not None else idx
                sec_copy["section_title"] = str(
                    sec_copy.get("section_title") or sec_copy.get("title") or f"Section {idx}"
                )
                sec_copy["node_id"] = sec_copy.get("node_id")
                sec_copy["excluded"] = sec_ex
                sec_copy["status"] = "excluded" if sec_ex else str(sec_copy.get("status") or "active")
                norm_sections.append(sec_copy)
        doc_copy["sections"] = norm_sections
        normalized_docs.append(doc_copy)

    resolved_scope_int = review_scope_id if review_scope_id is not None else _coerce_scope_id(review_scope_instance_id)
    resolved_scope_str = review_scope_instance_id or (str(resolved_scope_int) if resolved_scope_int is not None else None)
    return {
        "review_scope_dataext_id": review_scope_dataext_id,
        "review_scope_id": resolved_scope_int,
        "review_scope_instance_id": resolved_scope_str,
        "source_type": data_source,
        "registry_filename": registry_filename,
        "registry_storage_uri": registry_storage_uri,
        "documents": normalized_docs,
    }


def _resolve_scope_ids(session, plan_number: str) -> List[int]:
    """Return candidate integer review_scope_id values for the given plan_number."""
    plan_int = _coerce_scope_id(plan_number)
    if plan_int is None:
        return []
    candidates: List[int] = []
    try:
        rows = session.execute(
            sqlalchemy.text(
                f"""
                SELECT review_scope_id
                FROM {SCHEMA_NAME}.review_scope
                WHERE review_scope_id = :plan_int
                   OR review_plan_id = :plan_int
                ORDER BY CASE WHEN review_scope_id = :plan_int THEN 0 ELSE 1 END,
                         created_on DESC NULLS LAST
                """
            ),
            {"plan_int": plan_int},
        ).fetchall()
        for row in rows:
            if row and row[0] is not None:
                val = _coerce_scope_id(row[0])
                if val is not None and val not in candidates:
                    candidates.append(val)
    except Exception as exc:
        logger.debug("Could not resolve review_scope_id from review_scope for plan=%s: %s", plan_number, exc)

    if plan_int not in candidates:
        candidates.append(plan_int)
    return candidates


def get_data_extraction_metadata_map(plan_number: str) -> Dict[str, Dict[str, Any]]:
    """
    Fetch the latest `review_data_extraction` rows for `plan_number`, keyed by `data_source`.
    Returns `{}` if the database is not configured or unreachable so callers can fall back gracefully.
    """
    if not getattr(Config, "db_pass", None):
        return {}
    try:
        session = get_session()
    except Exception as exc:
        logger.debug("Database session unavailable for review_data_extraction lookup (plan=%s): %s", plan_number, exc)
        return {}

    try:
        scope_ids = _resolve_scope_ids(session, plan_number)
        if not scope_ids:
            return {}
        rows = (
            session.query(ReviewDataExtractionORM)
            .filter(ReviewDataExtractionORM.review_scope_id.in_(scope_ids))
            .order_by(ReviewDataExtractionORM.review_scope_dataext_id.desc())
            .all()
        )
        result: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            if getattr(row, "status", None) == 0:
                continue
            ds = str(row.data_source or "").strip().lower()
            if not ds or ds in result:
                continue
            result[ds] = normalize_data_extraction_metadata(
                row.metadata_,
                data_source=ds,
                review_scope_dataext_id=row.review_scope_dataext_id,
                review_scope_instance_id=row.review_scope_instance_id,
                review_scope_id=row.review_scope_id,
            )
        logger.info(
            "Loaded %d review_data_extraction metadata row(s) for plan_number=%s sources=%s",
            len(result),
            plan_number,
            list(result.keys()),
        )
        return result
    except Exception as exc:
        logger.warning(
            "Failed querying review_data_extraction for plan_number=%s: %s",
            plan_number,
            exc,
        )
        return {}
    finally:
        session.close()


def mark_historical_plan_items_excluded(
    plan_number: str,
    plan_item_numbers: Set[str],
    updated_by: str = "SYSTEM",
) -> bool:
    """
    Soft-exclude historical plan items in `dbaware_scoping.review_data_extraction`
    (`data_source = 'historical_plan_details'`) when `delete_historical_plan_item` is called.
    """
    if not plan_item_numbers or not getattr(Config, "db_pass", None):
        return False

    try:
        session = get_session()
    except Exception as exc:
        logger.debug("Database session unavailable for historical exclusion update (plan=%s): %s", plan_number, exc)
        return False

    try:
        scope_ids = _resolve_scope_ids(session, plan_number)
        if not scope_ids:
            return False
        row = (
            session.query(ReviewDataExtractionORM)
            .filter(
                ReviewDataExtractionORM.review_scope_id.in_(scope_ids),
                ReviewDataExtractionORM.data_source == "historical_plan_details",
            )
            .order_by(ReviewDataExtractionORM.review_scope_dataext_id.desc())
            .first()
        )
        if row is None:
            return False

        normalized = normalize_data_extraction_metadata(
            row.metadata_,
            data_source="historical_plan_details",
            review_scope_dataext_id=row.review_scope_dataext_id,
            review_scope_instance_id=row.review_scope_instance_id,
            review_scope_id=row.review_scope_id,
        )
        target_ids = {str(x).strip().lower() for x in plan_item_numbers if str(x).strip()}
        mutated = False

        for doc in normalized.get("documents", []):
            if not isinstance(doc, dict):
                continue
            doc_hist_id = str(
                doc.get("historic_plan_number") or doc.get("document_id") or ""
            ).strip().lower()
            if doc_hist_id in target_ids:
                doc["excluded"] = True
                doc["status"] = "excluded"
                mutated = True
            for sec in doc.get("sections", []):
                if not isinstance(sec, dict):
                    continue
                sec_id = str(sec.get("section_id") or "").strip().lower()
                node_id = str(sec.get("node_id") or "").strip().lower()
                if sec_id in target_ids or any(node_id == f"historical_plan:{tid}" for tid in target_ids):
                    sec["excluded"] = True
                    sec["status"] = "excluded"
                    mutated = True

        if not mutated:
            return False

        row.metadata_ = {
            "source_type": "historical_scoping_document",
            "documents": normalized.get("documents", []),
        }
        row.updated_by = updated_by
        row.updated_on = datetime.now(timezone.utc).replace(tzinfo=None)
        session.commit()
        return True
    except Exception as exc:
        session.rollback()
        logger.warning("Failed updating historical_plan_details metadata for plan=%s: %s", plan_number, exc)
        return False
    finally:
        session.close()
