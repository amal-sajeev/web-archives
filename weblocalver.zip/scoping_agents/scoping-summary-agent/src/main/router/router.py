import asyncio
import logging
from fastapi import APIRouter, HTTPException, Response

from agent_helper.action_service import (
    audit_generation_start,
    audit_revision,
    audit_ai_response,
)
from service.analytics_service import (
    read_preliminary_research_report,
    run_analytics_task,
    write_preliminary_research_sections,
)
from config.config import Config
from utils.data_manager import (
    delete_historical_plan_item,
    process_citations,
    process_document_uri,
    has_plan_data,
    read_historical_plan_item_details,
)
from model.request_model import (
    AnalyticsRequest,
    DeleteHistoricalPlanItemRequest,
    DeleteHistoricalPlanItemResponse,
    DownloadResearchWalkthroughRequest,
    EditPreliminaryResearchRequest,
    GetDocumentRequest,
    GetPreliminaryResearchRequest,
    HistoricalPlanItem,
    ListAllPlanItemsRequest,
)
from model.response_model import PreliminaryResearchDocument
from service.pdf_download_service import download_research_walkthrough_pdf

from persistor.review_research_recommendation_repository import (
    persist_review_research_recommendation,
    update_review_research_recommendation,
)
logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/health")
def health() -> dict[str, str]: 
    return {"status": "ok"}


@router.post("/list-documents", response_model=list[HistoricalPlanItem])
async def list_all_plan_items(request: ListAllPlanItemsRequest):
    plan_number = request.plan_number
    try:
        logger.info("Reading historical plan item list plan_number=%s", plan_number)
        return await asyncio.to_thread(read_historical_plan_item_details, plan_number)
    except FileNotFoundError as exc:
        logger.warning("Historical plan details not found plan_number=%s error=%s", plan_number, exc)
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        logger.warning("Invalid historical plan details plan_number=%s error=%s", plan_number, exc)
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error reading historical plan details plan_number=%s", plan_number)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/delete-document", response_model=DeleteHistoricalPlanItemResponse)
async def delete_document(request: DeleteHistoricalPlanItemRequest):
    plan_number = request.plan_number
    plan_item_numbers = [str(item.plan_item_number).strip() for item in request.plan_items]
    try:
        logger.info(
            "Deleting historical plan detail row(s) plan_number=%s plan_item_numbers=%s",
            plan_number,
            plan_item_numbers,
        )
        return await asyncio.to_thread(
            delete_historical_plan_item,
            plan_number,
            plan_item_numbers,
        )
    except FileNotFoundError as exc:
        logger.warning("Historical plan details not found for delete request plan_number=%s error=%s", plan_number, exc)
        raise HTTPException(status_code=404, detail=str(exc))
    except LookupError as exc:
        logger.warning("Delete target not found in historical plan details plan_number=%s error=%s", plan_number, exc)
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        logger.warning("Invalid delete request for historical plan details plan_number=%s error=%s", plan_number, exc)
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error deleting historical plan details plan_number=%s", plan_number)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/run-analytics-agent")
async def run_analytics_agent_endpoint(
    request: AnalyticsRequest,
) -> PreliminaryResearchDocument:
    planNumber = request.planNumber
    logger.info("Received analytics request plan_number=%s sections=%s", planNumber, request.sections)

    agent_card, start_time = audit_generation_start(
        activity_type="PRELIMINARY_RESEARCH_GENERATION",
        entity_type="PRELIMINARY_RESEARCH",
        plan_number=planNumber,
        description="preliminary research baseline report",
        request_obj=request,
    )

    try:
        if not has_plan_data(planNumber):
            logger.warning("Plan not found plan_number=%s", planNumber)
            raise FileNotFoundError(f"No data found for plan '{planNumber}'.")
        response = await run_analytics_task(planNumber, sections=request.sections)
        logger.info("Analytics completed plan_number=%s", planNumber)

        try:
            resolved_scope_id = (
                request.userDetails.review_scope_instance_id
                if request.userDetails.review_scope_instance_id is not None
                else planNumber
            )
            review_rr_id = persist_review_research_recommendation(
                review_scope_instance_id=resolved_scope_id,
                metadata=response,
                report_type="PRELIMINARY_RESEARCH",
                created_by=request.userDetails.user,
                remarks=request.userDetails.remarks,
            )
            logger.info(
                "Persisted research recommendation plan_number=%s review_rr_id=%s",
                planNumber,
                review_rr_id,
            )
        except Exception as e:
            # Persistence is best-effort; do not fail the analytics response.
            logger.exception(
                "Failed to persist research recommendation plan_number=%s", planNumber
            )

        audit_ai_response(
            agent_card=agent_card,
            start_time=start_time,
            result_payload=response,
            default_reasoning="Successfully compiled GRC, Policy, and Historical context into a Preliminary Research baseline.",
        )
        return response
    except FileNotFoundError as exc:
        logger.warning("Plan not found plan_number=%s error=%s", planNumber, exc)
        raise HTTPException(status_code=404, detail=str(exc))
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error processing plan plan_number=%s", planNumber)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get_document")
async def get_document(request: GetDocumentRequest):
    try:
        document_uri = (request.document_uri or "").strip()
        chunk_id = (request.chunk_id or "").strip()
        page_number = request.page_number or 1

        if document_uri:
            logger.info("Received get_document request via direct uri=%s", document_uri)
            document_data = process_document_uri(document_uri, page_number=page_number)
            if document_data.get("type") == "unsupported":
                raise HTTPException(status_code=415, detail="Unsupported document type for provided document_uri.")
            return document_data

        if not chunk_id:
            raise ValueError("Either chunk_id or document_uri is required.")
        if not request.planNumber:
            raise ValueError("planNumber is required when chunk_id is provided.")

        logger.info("Received get_document request plan_number=%s chunk_id=%s", request.planNumber, chunk_id)
        citation_data = process_citations(request.planNumber, chunk_id)

        if citation_data.get("type") == "error":
            raise HTTPException(status_code=404, detail=citation_data.get("message", "Cited document not found."))

        return citation_data
    except FileNotFoundError as exc:
        logger.warning("File not found for get_document request. plan_number=%s. Error: %s", request.planNumber, exc)
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        logger.warning("Invalid data for get_document request. plan_number=%s. Error: %s", request.planNumber, exc)
        raise HTTPException(status_code=400, detail=str(exc))
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_document. plan_number=%s", request.planNumber)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get-preliminary-research-document")
async def get_preliminary_research_document(request: GetPreliminaryResearchRequest) -> PreliminaryResearchDocument:
    plan_number = request.planNumber
    try:
        logger.info("Fetching preliminary research document plan_number=%s", plan_number)
        analysis_report = await read_preliminary_research_report(plan_number)
        if analysis_report is None:
            logger.warning("Preliminary research document not found plan_number=%s", plan_number)
            raise HTTPException(status_code=404, detail="Document not found.")
        return PreliminaryResearchDocument(plan_number=plan_number, analysis_report=analysis_report)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error fetching preliminary research plan_number=%s", plan_number)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/edit-preliminary-research-document")
async def edit_preliminary_research_document(request: EditPreliminaryResearchRequest) -> PreliminaryResearchDocument:
    plan_number = request.plan_number
    try:
        if not isinstance(request.analysis_report, dict):
            raise ValueError("analysis_report must be a dictionary.")
        await asyncio.to_thread(
            audit_revision,
            activity_type="PRELIMINARY_RESEARCH",
            entity_type="PRELIMINARY_RESEARCH",
            plan_number=plan_number,
            request_obj=request,
            description="preliminary research document",
        )
        document = PreliminaryResearchDocument(plan_number=plan_number, analysis_report=request.analysis_report)
        paths = await write_preliminary_research_sections(plan_number, document.model_dump()["analysis_report"])
        logger.info("Updated preliminary research document plan_number=%s paths=%s", plan_number, paths)

        try:
            resolved_scope_id = (
                request.userDetails.review_scope_instance_id
                if request.userDetails.review_scope_instance_id is not None
                else plan_number
            )
            updated_id = await asyncio.to_thread(
                update_review_research_recommendation,
                review_scope_instance_id=resolved_scope_id,
                metadata=document,
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                plan_number,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s", plan_number
            )

        return document
    except ValueError as exc:
        logger.warning("Invalid preliminary research edit plan_number=%s error=%s", plan_number, exc)
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error updating preliminary research plan_number=%s", plan_number)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/download")
async def download_research_walkthrough(request: DownloadResearchWalkthroughRequest) -> Response:
    plan_number = request.plan_number
    try:
        logger.info("Fetching preliminary research document for download plan_number=%s", plan_number)
        analysis_report = await read_preliminary_research_report(plan_number)
        if analysis_report is None:
            logger.warning("Preliminary research document not found for download plan_number=%s", plan_number)
            raise HTTPException(status_code=404, detail="Document not found.")

        logger.info("Generating PDF for preliminary research plan_number=%s", plan_number)
        pdf_bytes, headers = await asyncio.to_thread(
            download_research_walkthrough_pdf,
            plan_number=plan_number,
            plan_name=request.plan_name,
            analysis_report=analysis_report,
            pdf_citation_base_url=Config.DOWNLOAD_PDF_CITATION_BASE_URL or None,
        )
        return Response(content=pdf_bytes, media_type="application/pdf", headers=headers)
    except HTTPException:
        raise
    except ValueError as exc:
        logger.warning("Invalid request for download endpoint plan_number=%s error=%s", plan_number, exc)
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error generating walkthrough PDF plan_number=%s", plan_number)
        raise HTTPException(status_code=500, detail=str(exc))