import asyncio
import logging
from fastapi import APIRouter, HTTPException, Response
from datetime import datetime, timezone
from typing import Any, Dict

from agents.analytics_agent import SECTION_REGISTRY
from service.analytics_service import (
    read_preliminary_research_report,
    run_analytics_task,
    write_preliminary_research_sections,
)
from config.config import Config
from utils.data_manager import (
    delete_historical_plan_item,
    get_preliminary_research_blob_path,
    get_preliminary_research_section_blob_path,
    process_citations,
    process_document_uri,
    has_plan_data,
    read_historical_plan_item_details,
)
from utils.storage_manager import blob_exists
from model.request_model import (
    AnalyticsRequest,
    DeleteHistoricalPlanItemRequest,
    DeleteHistoricalPlanItemResponse,
    DownloadResearchWalkthroughRequest,
    EditPreliminaryResearchRequest,
    GetDocumentRequest,
    GetPreliminaryResearchRequest,
    HistoricalPlanItem,
    ListAllPlanItemsRequest,
)
from model.response_model import PreliminaryResearchDocument
from service.pdf_download_service import download_research_walkthrough_pdf

from persistor.review_research_recommendation_repository import (
    persist_review_research_recommendation,
    update_review_research_recommendation,
)
from agent_helper.agent_card import AgentCard
from agent_helper import action_service
logger = logging.getLogger(__name__)

router = APIRouter()


def _preliminary_research_metadata(plan_number: str, section_titles, include_existing: bool = False) -> dict:
    bucket = Config.REVIEW_BUCKET_NAME
    if not bucket:
        raise ValueError("Review bucket name is not configured.")
    titles = set(section_titles)
    paths = []
    for key, entry in SECTION_REGISTRY.items():
        path = get_preliminary_research_section_blob_path(plan_number, key)
        if entry["title"] in titles or (include_existing and blob_exists(path)):
            paths.append(path)
    if include_existing and len(paths) < len(SECTION_REGISTRY):
        legacy_path = get_preliminary_research_blob_path(plan_number)
        if blob_exists(legacy_path):
            paths.append(legacy_path)
    return {
        "files": [
            {"filename": path.rsplit("/", 1)[-1], "filepath": f"gs://{bucket}/{path}"}
            for path in paths
        ]
    }


@router.get("/health")
def health() -> dict[str, str]: 
    return {"status": "ok"}


@router.post("/list-documents", response_model=list[HistoricalPlanItem])
async def list_all_plan_items(request: ListAllPlanItemsRequest):
    plan_number = request.plan_number
    try:
        start_time_dt = datetime.now(timezone.utc)
        agent_card = AgentCard.build_agent_card(
            activity_type="HISTORICAL_PLAN",
            plan_item_number=request.plan_number,
            entity_type="SCOPING_SUMMARY",
            parent_entity_type="SCOPING",
            parent_entity_id=request.plan_number,
            actor_id="dbaware@db.com",
            actor_type="HUMAN",
        )
        action_service.construct_human_list_record(plan_number=request.plan_number,
                                                   activity_type="HISTORICAL_PLAN",
                                                   human_notes=f"list all historical plan  document for plan number = {request.plan_number}",
                                                   user="dbaware@db.com")
        logger.info("Reading historical plan item list plan_number=%s", plan_number)
        end_time_dt = datetime.now(timezone.utc)
        response= await asyncio.to_thread(read_historical_plan_item_details, plan_number)
        action_service.construct_ai_list_response_record(plan_number=request.plan_number,
                                                         activity_type="HISTORICAL_PLAN",
                                                         start_time=start_time_dt,
                                                         end_time=end_time_dt,
                                                         response_code=200,
                                                         user="dbaware@db.com",
                                                         response_text=f"Successfully list the historical plan document for plan number = {request.plan_number}",
                                                         remarks="")
        return response
    except FileNotFoundError as exc:
        logger.exception("Historical plan details not found plan_number=%s error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_list_response_record(plan_number=request.plan_number,
                                                         activity_type="HISTORICAL_PLAN",
                                                         start_time=start_time_dt,
                                                         end_time=end_time_dt,
                                                         response_code=404,
                                                         user="dbaware@db.com",
                                                         response_text=f"Failed to  list the historical plan document for plan number = {request.plan_number}",
                                                         remarks="")
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        logger.exception("Invalid historical plan details plan_number=%s error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_list_response_record(plan_number=request.plan_number,
                                                         activity_type="HISTORICAL_PLAN",
                                                         start_time=start_time_dt,
                                                         end_time=end_time_dt,
                                                         response_code=400,
                                                         user="dbaware@db.com",
                                                         response_text=f"Failed to  list the historical plan document for plan number = {request.plan_number}",
                                                         remarks="")
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error reading historical plan details plan_number=%s, error = %s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_list_response_record(plan_number=request.plan_number,
                                                         activity_type="HISTORICAL_PLAN",
                                                         start_time=start_time_dt,
                                                         end_time=end_time_dt,
                                                         response_code=500,
                                                         user="dbaware@db.com",
                                                         response_text=f"Failed to  list the preliminary research document for plan number = {request.plan_number}",
                                                         remarks="")
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/delete-document", response_model=DeleteHistoricalPlanItemResponse)
async def delete_document(request: DeleteHistoricalPlanItemRequest):
    plan_number = request.plan_number
    plan_item_numbers = [str(item.plan_item_number).strip() for item in request.plan_items]
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_delete_record(plan_number=request.plan_number,
                                                     activity_type="HISTORICAL_PLAN",
                                                     human_notes=f"Delete historical plan document for plan_number = {request.plan_number}",
                                                     user="dbaware@db.com")
        logger.info(
            "Deleting historical plan detail row(s) plan_number=%s plan_item_numbers=%s",
            plan_number,
            plan_item_numbers,
        )
        response= await asyncio.to_thread(
            delete_historical_plan_item,
            plan_number,
            plan_item_numbers,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_delete_response_record(plan_number=request.plan_number,
                                                           activity_type="HISTORICAL_PLAN",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=200,
                                                           user="dbaware@db.com",
                                                            response_text=f"Successfully deleted the historical plan detail for plan number = {request.plan_number}",
                                                           remarks="")
        return response

    except FileNotFoundError as exc:
        logger.exception("Historical plan details not found for delete request plan_number=%s error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_delete_response_record(plan_number=request.plan_number,
                                                           activity_type="HISTORICAL_PLAN",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=404,
                                                           user="dbaware@db.com",
                                                           response_text=f"Failed to  deleted the historical plan detail for plan number = {request.plan_number}",
                                                           remarks="")
        raise HTTPException(status_code=404, detail=str(exc))
    except LookupError as exc:
        logger.exception("Delete target not found in historical plan details plan_number=%s error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_delete_response_record(plan_number=request.plan_number,
                                                           activity_type="HISTORICAL_PLAN",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=404,
                                                           user="dbaware@db.com",
                                                           response_text=f"Failed to  deleted the historical plan detail for plan number = {request.plan_number}",
                                                           remarks="")
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        logger.exception("Invalid delete request for historical plan details plan_number=%s error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_delete_response_record(plan_number=request.plan_number,
                                                           activity_type="HISTORICAL_PLAN",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=400,
                                                           user="dbaware@db.com",
                                                           response_text=f"Failed to  deleted the historical plan detail for plan number = {request.plan_number}",
                                                           remarks="")
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error deleting historical plan details plan_number=%s, error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_delete_response_record(plan_number=request.plan_number,
                                                           activity_type="HISTORICAL_PLAN",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=500,
                                                           user="dbaware@db.com",
                                                           response_text=f"Failed to  deleted the historical plan detail for plan number = {request.plan_number}",
                                                           remarks="")
        raise HTTPException(status_code=500, detail=str(exc))


def _calculate_total_input_output_tokens(llm_usage: list[dict[str, Any]] = None):
    logger.info(f"****** in _calculate_total_input_output_tokens llm_usage data = {llm_usage} ")
    total_input_tokens = 0
    total_output_tokens = 0
    if not llm_usage:
        logger.error("usage metadata is empty")
        return total_input_tokens, total_output_tokens
    for item in llm_usage:
        input_token = item.get("input_tokens", 0)
        output_token = item.get("output_tokens", 0)
        section = item.get("section", "")
        logger.info(f"Token data section = {section}, input_token = {input_token}, output_token = {output_token} ")
        total_input_tokens = total_input_tokens + input_token
        total_output_tokens = total_output_tokens + output_token
        logger.info(f"Token data section total_input_tokens = {total_input_tokens}, total_output_tokens = {total_output_tokens} ")
    return total_input_tokens, total_output_tokens


@router.post("/run-analytics-agent")
async def run_analytics_agent_endpoint(
    request: AnalyticsRequest,
) -> PreliminaryResearchDocument:
    planNumber = request.planNumber
    logger.info("Received analytics request plan_number=%s sections=%s", planNumber, request.sections)
    llm_usage: list[dict[str, Any]] = []
    start_time_dt = datetime.now(timezone.utc)
    try:
        action_service.construct_human_actor_generate_record(plan_number=request.planNumber,
                                                             activity_type="PRELIMINARY_RESEARCH",
                                                             query=f"Generate priliminary research document for plan_number = {request.planNumber}",
                                                             user=request.userDetails.user)
        if not has_plan_data(planNumber):
            logger.warning("Plan not found plan_number=%s", planNumber)
            raise FileNotFoundError(f"No data found for plan '{planNumber}'.")
        response, llm_usage_1= await run_analytics_task(planNumber, sections=request.sections, llm_usage=llm_usage)
        logger.info("Analytics completed plan_number=%s", planNumber)
        logger.info(f"Analytics completed llm_usage = {llm_usage_1}")

        try:
            report = response.model_dump() if isinstance(response, PreliminaryResearchDocument) else response
            review_rr_id = persist_review_research_recommendation(
                review_scope_id=request.userDetails.review_scope_id,
                metadata=_preliminary_research_metadata(planNumber, report["analysis_report"]),
                report_type="PRELIMINARY_RESEARCH",
                created_by=request.userDetails.user,
                remarks=request.userDetails.remarks,
            )
            logger.info(
                "Persisted research recommendation plan_number=%s review_rr_id=%s",
                planNumber,
                review_rr_id,
            )
        except Exception as e:
            # Persistence is best-effort; do not fail the analytics response.
            logger.exception(
                "Failed to persist research recommendation plan_number=%s", planNumber
            )

        end_time_dt = datetime.now(timezone.utc)
        input_tokens = 0
        output_tokens = 0

        if isinstance(llm_usage_1, list):
            input_tokens, output_tokens = _calculate_total_input_output_tokens(llm_usage_1)

        action_service.construct_ai_actor_response_record(
                                            plan_number=request.planNumber,
                                            activity_type="PRELIMINARY_RESEARCH",
                                            response_code=200,
                                            total_input_tokens=input_tokens,
                                            total_output_tokens=output_tokens,
                                            final_answer=f"Sucessfully generated the preliminary_research document for plan_number {request.planNumber}",
                                            start_time=start_time_dt,
                                            end_time=end_time_dt,
                                            score=0,
                                            reasoning="",
                                            env_config=None,
                                            prompt_version="1.0",
                                           )

        return response
    except FileNotFoundError as exc:
        logger.exception("Plan not found plan_number=%s error=%s", planNumber, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(plan_number=request.planNumber,
                                                          activity_type="PRELIMINARY_RESEARCH",
                                                          response_code=404,
                                                          total_input_tokens=0,
                                                          total_output_tokens=0,
                                                          final_answer=f"Failed generated the preliminary_research document for plan_number {request.planNumber}",
                                                          start_time=start_time_dt,
                                                          end_time=end_time_dt,
                                                          score=0,
                                                          reasoning="",
                                                          env_config=None,
                                                          prompt_version="1.0",
                                                          )
        raise HTTPException(status_code=404, detail=str(exc))
    except HTTPException as exc:
        logger.exception("HTTPException for plan_number=%s error=%s", planNumber, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(plan_number=request.planNumber,
                                                          activity_type="PRELIMINARY_RESEARCH",
                                                          response_code=500,
                                                          total_input_tokens=0,
                                                          total_output_tokens=0,
                                                          final_answer=f"Failed generated the preliminary_research document for plan_number {request.planNumber}",
                                                          start_time=start_time_dt,
                                                          end_time=end_time_dt,
                                                          score=0,
                                                          reasoning="",
                                                          env_config=None,
                                                          prompt_version="1.0",
                                                          )
        raise
    except Exception as exc:
        logger.exception("Unexpected error processing plan plan_number=%s, Error=%s", planNumber, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(plan_number=request.planNumber,
                                                          activity_type="PRELIMINARY_RESEARCH",
                                                          response_code=500,
                                                          total_input_tokens=0,
                                                          total_output_tokens=0,
                                                          final_answer=f"Failed generated the preliminary_research document for plan_number {request.planNumber}",
                                                          start_time=start_time_dt,
                                                          end_time=end_time_dt,
                                                          score=0,
                                                          reasoning="",
                                                          env_config=None,
                                                          prompt_version="1.0",
                                                          )
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get_document")
async def get_document(request: GetDocumentRequest):
    try:
        start_time_dt = datetime.now(timezone.utc)
        document_uri = (request.document_uri or "").strip()
        chunk_id = (request.chunk_id or "").strip()
        page_number = request.page_number or 1
        action_service.construct_human_actor_get_document_from_uri_record(plan_number=request.planNumber,
                                                                          activity_type="PRELIMINARY_RESEARCH",
                                                                          document_uri=request.document_uri,
                                                                          chunk_id=request.chunk_id,
                                                                          page_number=request.page_number)

        if document_uri:
            logger.info("Received get_document request via direct uri=%s", document_uri)
            document_data = process_document_uri(document_uri, page_number=page_number)
            if document_data.get("type") == "unsupported":
                end_time_dt = datetime.now(timezone.utc)
                action_service.construct_ai_actor_get_document_from_uri_response_record(plan_number=request.planNumber,
                                                                                        activity_type="PRELIMINARY_RESEARCH",
                                                                                        remarks="",
                                                                                        start_time=start_time_dt,
                                                                                        end_time=end_time_dt,
                                                                                        document_uri=request.document_uri,
                                                                                        response_code=415,
                                                                                        response_txt=f"Failed to  Fetched document from uri unsupported document type for  plan number = {request.planNumber}")

                raise HTTPException(status_code=415, detail="Unsupported document type for provided document_uri.")
            return document_data

        if not chunk_id:
            raise ValueError("Either chunk_id or document_uri is required.")
        if not request.planNumber:
            raise ValueError("planNumber is required when chunk_id is provided.")

        logger.info("Received get_document request plan_number=%s chunk_id=%s", request.planNumber, chunk_id)
        citation_data = process_citations(request.planNumber, chunk_id)

        if citation_data.get("type") == "error":
            raise HTTPException(status_code=404, detail=citation_data.get("message", "Cited document not found."))

        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_from_uri_response_record(plan_number=request.planNumber,
                                                                                activity_type="PRELIMINARY_RESEARCH",
                                                                                remarks="",
                                                                                start_time=start_time_dt,
                                                                                end_time=end_time_dt,
                                                                                document_uri=request.document_uri,
                                                                                response_code=200,
                                                                                response_txt=f"Successfully Fetched document from uri for plan number = {request.planNumber}")

        return citation_data
    except FileNotFoundError as exc:
        logger.exception("File not found for get_document request. plan_number=%s. Error: %s", request.planNumber, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_from_uri_response_record(plan_number=request.planNumber,
                                                                                activity_type="PRELIMINARY_RESEARCH",
                                                                                remarks="",
                                                                                start_time=start_time_dt,
                                                                                end_time=end_time_dt,
                                                                                document_uri=request.document_uri,
                                                                                response_code=404,
                                                                                response_txt=f"Failed to  Fetched document from uri for plan number = {request.planNumber}")

        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        logger.exception("Invalid data for get_document request. plan_number=%s. Error: %s", request.planNumber, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_from_uri_response_record(plan_number=request.planNumber,
                                                                                activity_type="PRELIMINARY_RESEARCH",
                                                                                remarks="",
                                                                                start_time=start_time_dt,
                                                                                end_time=end_time_dt,
                                                                                document_uri=request.document_uri,
                                                                                response_code=400,
                                                                                response_txt=f"Failed to  Fetched document from uri for plan number = {request.planNumber}")

        raise HTTPException(status_code=400, detail=str(exc))
    except HTTPException as exc:
        logger.exception("HTTPException for. plan_number=%s. Error: %s", request.planNumber, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_from_uri_response_record(plan_number=request.planNumber,
                                                                                activity_type="PRELIMINARY_RESEARCH",
                                                                                remarks="",
                                                                                start_time=start_time_dt,
                                                                                end_time=end_time_dt,
                                                                                document_uri=request.document_uri,
                                                                                response_code=500,
                                                                                response_txt=f"Failed to  Fetched document from uri for plan number = {request.planNumber}")

        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_document. plan_number=%s, Error = %s", request.planNumber, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_from_uri_response_record(plan_number=request.planNumber,
                                                                                activity_type="PRELIMINARY_RESEARCH",
                                                                                remarks="",
                                                                                start_time=start_time_dt,
                                                                                end_time=end_time_dt,
                                                                                document_uri=request.document_uri,
                                                                                response_code=500,
                                                                                response_txt=f"Failed to  Fetched document from uri for plan number = {request.planNumber}")

        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get-preliminary-research-document")
async def get_preliminary_research_document(request: GetPreliminaryResearchRequest) -> PreliminaryResearchDocument:
    plan_number = request.planNumber
    start_time_dt = datetime.now(timezone.utc)
    try:
        logger.info("Fetching preliminary research document plan_number=%s", plan_number)
        action_service.construct_human_actor_get_document_record(plan_number=request.planNumber,
                                                                 activity_type="PRELIMINARY_RESEARCH",
                                                                 user="dbaware@db.com",
                                                                 user_remarks=f"Fetch document for plan_number = {request.planNumber}")
        analysis_report = await read_preliminary_research_report(plan_number)

        if analysis_report is None:
            logger.warning("Preliminary research document not found plan_number=%s", plan_number)
            end_time_dt = datetime.now(timezone.utc)
            action_service.construct_ai_actor_get_document_response_record(plan_number=request.planNumber,
                                                                           activity_type="PRELIMINARY_RESEARCH",
                                                                           user="dbaware@db.com",
                                                                           user_remarks="",
                                                                           remarks=f"Failed to  Fetch preliminary research document for plan_number = {request.planNumber}",
                                                                           start_time=start_time_dt,
                                                                           end_time=end_time_dt,
                                                                           response_code=500)
            raise HTTPException(status_code=404, detail="Document not found.")
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(plan_number=request.planNumber,
                                                                       activity_type="PRELIMINARY_RESEARCH",
                                                                       user="dbaware@db.com",
                                                                       user_remarks="",
                                                                       remarks=f"Successfully Fetch the preliminary research document for plan_number = {request.planNumber}",
                                                                       start_time=start_time_dt,
                                                                       end_time=end_time_dt,
                                                                       response_code=200)
        return PreliminaryResearchDocument(plan_number=plan_number, analysis_report=analysis_report)
    except HTTPException as exc:
        logger.exception("Unexpected error fetching preliminary research plan_number=%s, Error = %s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(plan_number=request.planNumber,
                                                                       activity_type="PRELIMINARY_RESEARCH",
                                                                       user="dbaware@db.com",
                                                                       user_remarks="",
                                                                       remarks=f"Failed to  Fetch preliminary research document for plan_number = {request.planNumber}",
                                                                       start_time=start_time_dt,
                                                                       end_time=end_time_dt,
                                                                       response_code=500)
        raise
    except Exception as exc:
        logger.exception("Unexpected error fetching preliminary research plan_number=%s, Error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(plan_number=request.planNumber,
                                                                       activity_type="PRELIMINARY_RESEARCH",
                                                                       user="dbaware@db.com",
                                                                       user_remarks="",
                                                                       remarks=f"Failed to  Fetch preliminary research document for plan_number = {request.planNumber}",
                                                                       start_time=start_time_dt,
                                                                       end_time=end_time_dt,
                                                                       response_code=500)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/edit-preliminary-research-document")
async def edit_preliminary_research_document(request: EditPreliminaryResearchRequest) -> PreliminaryResearchDocument:
    plan_number = request.plan_number
    start_time_dt = datetime.now(timezone.utc)
    try:
        action_service.construct_human_update_record(plan_number=request.plan_number,
                                                     activity_type="PRELIMINARY_RESEARCH",
                                                     human_notes=f"Persist human edited preliminary research doc for plan_number = {request.plan_number}",
                                                     updated_by=request.userDetails.user,
                                                     updated_section=request.analysis_report)
        if not isinstance(request.analysis_report, dict):
            end_time_dt = datetime.now(timezone.utc)
            action_service.construct_ai_update_response_record(plan_number=request.plan_number,
                                                               activity_type="PRELIMINARY_RESEARCH",
                                                               start_time=start_time_dt,
                                                               end_time=end_time_dt,
                                                               response_code=500,
                                                               updated_by=request.userDetails.user,
                                                               response_text=f"Failed to  Persisted the human edited preliminary research"
                                                                             f" for plan number = {request.plan_number}",
                                                               remarks="")
            raise ValueError("analysis_report must be a dictionary.")

        document = PreliminaryResearchDocument(plan_number=plan_number, analysis_report=request.analysis_report)
        paths = await write_preliminary_research_sections(plan_number, document.model_dump()["analysis_report"])
        logger.info("Updated preliminary research document plan_number=%s paths=%s", plan_number, paths)

        try:
            metadata = await asyncio.to_thread(
                _preliminary_research_metadata,
                plan_number,
                document.analysis_report,
                include_existing=True,
            )
            updated_id = await asyncio.to_thread(
                update_review_research_recommendation,
                review_scope_id=request.userDetails.review_scope_id,
                report_type="PRELIMINARY_RESEARCH",
                metadata=metadata,
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                plan_number,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s", plan_number
            )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.plan_number,
                                                           activity_type="PRELIMINARY_RESEARCH",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=200,
                                                            updated_by=request.userDetails.user,
                                                           response_text=f"Successfully Persisted the human edited preliminary research"
                                                                         f" for plan number = {request.plan_number}",
                                                           remarks="")
        return document
    except ValueError as exc:
        logger.exception("Invalid preliminary research edit plan_number=%s error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.plan_number,
                                                           activity_type="PRELIMINARY_RESEARCH",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=400,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to  Persisted the human edited preliminary research"
                                                                         f" for plan number = {request.plan_number}",
                                                           remarks="")
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.plan_number,
                                                           activity_type="PRELIMINARY_RESEARCH",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=500,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to  Persisted the human edited preliminary research"
                                                                         f" for plan number = {request.plan_number}",
                                                           remarks="")
        logger.exception("Unexpected error updating preliminary research plan_number=%s, error = %s", plan_number, exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/download")
async def download_research_walkthrough(request: DownloadResearchWalkthroughRequest) -> Response:
    plan_number = request.plan_number
    start_time_dt = datetime.now(timezone.utc)
    action_service.construct_human_download_record(plan_number=request.plan_number,
                                                   activity_type="PRELIMINARY_RESEARCH",
                                                   human_notes=f"download prelimnary_research doc for plan_number = {request.plan_number}",
                                                   updated_by="dbaware_db.com",
                                                   data=request.analysis_report)
    try:
        logger.info("Fetching preliminary research document for download plan_number=%s", plan_number)
        analysis_report = await read_preliminary_research_report(plan_number)
        if analysis_report is None:
            logger.warning("Preliminary research document not found for download plan_number=%s", plan_number)
            raise HTTPException(status_code=404, detail="Document not found.")

        logger.info("Generating PDF for preliminary research plan_number=%s", plan_number)
        pdf_bytes, headers = await asyncio.to_thread(
            download_research_walkthrough_pdf,
            plan_number=plan_number,
            plan_name=request.plan_name,
            analysis_report=analysis_report,
            pdf_citation_base_url=Config.DOWNLOAD_PDF_CITATION_BASE_URL or None,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.plan_number,
                                                             activity_type="PRELIMINARY_RESEARCH",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=200,
                                                             updated_by="dbaware@db.com",
                                                             response_text="Sucessfully Downloaded the Preliminary research"
                                                                           " doc for plan_number = {request.plan_number}",
                                                             remarks="")

        return Response(content=pdf_bytes, media_type="application/pdf", headers=headers)
    except HTTPException as exc:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.plan_number,
                                                             activity_type="PRELIMINARY_RESEARCH",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=500,
                                                             updated_by="dbaware@db.com",
                                                             response_text="Failed to  Downloaded the Preliminary research"
                                                                           " doc for plan_number = {request.plan_number}",
                                                             remarks="")
        logger.exception("HTTPException for  plan_number=%s error=%s", plan_number, exc)
        raise
    except ValueError as exc:
        logger.exception("Invalid request for download endpoint plan_number=%s error=%s", plan_number, exc)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.plan_number,
                                                             activity_type="PRELIMINARY_RESEARCH",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=400,
                                                             updated_by="dbaware@db.com",
                                                             response_text="Failed to  Downloaded the Preliminary research"
                                                                           " doc for plan_number = {request.plan_number}",
                                                             remarks="")
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error generating walkthrough PDF plan_number=%s, error = %s", plan_number, exec)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.plan_number,
                                                             activity_type="PRELIMINARY_RESEARCH",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=500,
                                                             updated_by="dbaware@db.com",
                                                             response_text="Failed to  Downloaded the Preliminary research"
                                                                           " doc for plan_number = {request.plan_number}",
                                                             remarks="")
        raise HTTPException(status_code=500, detail=str(exc))