from unittest.mock import MagicMock, patch

from fastapi.testclient import TestClient

from main.app import app

client = TestClient(app)


@patch("routes.data.find_record")
@patch("routes.data.get_data_snapshot")
def test_data_routes_snapshot_endpoints(mock_get_data_snapshot, mock_find_record):
    """Exercise the snapshot-backed data endpoints."""
    mock_get_data_snapshot.return_value = (
        {
            "sources": [{"id": "src-1", "name": "Source One"}],
            "documents": [{
                "id": "doc-1",
                "title": "Doc One",
                "text": "Hello world",
                "tree": [{"id": "node-1"}],
                "validation": {"status": "ok"},
                "versions": [{"version_id": "v1"}],
            }],
            "graph": {"nodes": {"node-1": {"label": "Node 1"}}},
            "review": [{"id": "review-1", "severity": "medium"}],
        },
        "live",
    )
    mock_find_record.return_value = {
        "id": "doc-1",
        "title": "Doc One",
        "text": "Hello world",
        "tree": [{"id": "node-1"}],
        "validation": {"status": "ok"},
        "versions": [{"version_id": "v1"}],
    }

    assert client.get("/lrr/sources").json() == [{"id": "src-1", "name": "Source One"}]
    assert client.get("/lrr/documents").json() == [{
        "id": "doc-1",
        "title": "Doc One",
        "tree": [{"id": "node-1"}],
        "validation": {"status": "ok"},
        "versions": [{"version_id": "v1"}],
    }]
    assert client.get("/lrr/documents/doc-1/tree").json() == [{"id": "node-1"}]
    assert client.get("/lrr/documents/doc-1/text").json() == {
        "id": "doc-1",
        "title": "Doc One",
        "source_url": None,
        "text": "Hello world",
        "chars": 0,
    }
    assert client.get("/lrr/graph").json() == {"nodes": {"node-1": {"label": "Node 1"}}}
    assert client.get("/lrr/review").json() == [{"id": "review-1", "severity": "medium"}]


@patch("routes.data.find_record")
def test_data_routes_single_record_lookup_and_download(mock_find_record):
    """Cover source and document lookup routes as well as the download endpoint."""
    document = {
        "id": "doc-1",
        "title": "Doc One",
        "source_url": "https://example.com/doc-one",
        "text": "Hello world",
        "validation": {"status": "ok"},
        "versions": [{"version_id": "v1"}],
        "tree": [{"id": "node-1"}],
    }
    mock_find_record.return_value = document

    assert client.get("/lrr/sources/src-1").json() == document
    assert client.get("/lrr/documents/doc-1").json() == document
    assert client.get("/lrr/documents/doc-1/validation").json() == {"status": "ok"}
    assert client.get("/lrr/documents/doc-1/versions").json() == [{"version_id": "v1"}]

    with patch("routes.data.build_download_name", return_value="doc-one.md"):
        response = client.get("/lrr/documents/doc-1/download")
        assert response.status_code == 200
        assert response.headers["content-disposition"] == 'attachment; filename="doc-one.md"'
        assert response.text == "Hello world"


@patch("routes.data.find_record")
def test_data_routes_not_found_cases(mock_find_record):
    """Exercise the 404 branches for missing source and document records."""
    mock_find_record.return_value = None

    assert client.get("/lrr/sources/missing").status_code == 404
    assert client.get("/lrr/documents/missing").status_code == 404
    assert client.get("/lrr/documents/missing/tree").status_code == 404
    assert client.get("/lrr/documents/missing/text").status_code == 404
    assert client.get("/lrr/documents/missing/validation").status_code == 404
    assert client.get("/lrr/documents/missing/versions").status_code == 404
    assert client.get("/lrr/documents/missing/download").status_code == 404


@patch("routes.data._read_gcs_json")
@patch("routes.data.Settings")
def test_data_routes_enriched_output_and_artifact(mock_settings, mock_read_gcs_json):
    """Cover enriched-output success paths."""
    mock_settings.return_value.gcs_bucket = "demo-bucket"
    mock_settings.return_value.gcs_prefix = "req-prefix"
    mock_read_gcs_json.side_effect = [{"ok": True}, {"inbound": True}, {"ok": True}]

    response = client.get("/lrr/requests/abc123/enriched")
    assert response.status_code == 200
    assert response.json()["request_id"] == "abc123"
    assert response.json()["artifacts"]["processing"] == {"ok": True}

    response = client.get("/lrr/requests/abc123/enriched/processing")
    assert response.status_code == 200
    assert response.json()["artifact"] == "processing"

    response = client.get("/lrr/requests/abc123/enriched/invalid")
    assert response.status_code == 400


@patch("routes.data._read_gcs_json")
@patch("routes.data.Settings")
def test_data_routes_missing_enriched_404_and_error(mock_settings, mock_read_gcs_json):
    """Cover the missing and error branches for enriched GCS data."""
    mock_settings.return_value.gcs_bucket = "demo-bucket"
    mock_settings.return_value.gcs_prefix = "req-prefix"

    mock_read_gcs_json.side_effect = FileNotFoundError("missing")
    response = client.get("/lrr/requests/abc123/enriched")
    assert response.status_code == 404

    mock_read_gcs_json.side_effect = ValueError("bad json")
    response = client.get("/lrr/requests/abc123/enriched/processing")
    assert response.status_code == 500


@patch("routes.lrr.list_active_runs")
@patch("routes.data.get_data_snapshot")
def test_lrr_get_runs_mixed(mock_get_data_snapshot, mock_list_active_runs):
    """Test /lrr/runs returns both active and persisted runs."""
    mock_get_data_snapshot.return_value = (
        {"runs": [{"run_id": "persisted-1", "status": "completed"}]},
        "live",
    )
    mock_active_run = MagicMock()
    mock_active_run.__getitem__.side_effect = lambda k: {"run_id": "active-1", "status": "running"}.get(k)
    mock_list_active_runs.return_value = [mock_active_run]

    response = client.get("/lrr/runs")
    assert response.status_code == 200
    runs = response.json()
    assert len(runs) >= 1
    assert all(run["pipeline"] == "lrr" for run in runs)


@patch("main.services.data_service.find_record")
@patch("routes.lrr.get_active_run")
def test_lrr_get_run_persisted(mock_get_active_run, mock_find_record):
    """Test /lrr/runs/{run_id} returns persisted run when not active."""
    mock_get_active_run.return_value = None
    mock_find_record.return_value = {
        "run_id": "run-456",
        "status": "completed",
        "total_steps": 100,
    }

    response = client.get("/lrr/runs/run-456")
    assert response.status_code == 200
    assert response.json()["run_id"] == "run-456"
    assert response.json()["pipeline"] == "lrr"


@patch("routes.lrr.get_active_run")
@patch("routes.data.find_record")
def test_lrr_get_run_not_found(mock_find_record, mock_get_active_run):
    """Test /lrr/runs/{run_id} returns 404 when run not found."""
    mock_get_active_run.return_value = None
    mock_find_record.return_value = None

    response = client.get("/lrr/runs/nonexistent")
    assert response.status_code == 404


@patch("main.services.data_service.find_record")
@patch("routes.lrr.get_active_run")
def test_lrr_get_process_status_persisted(mock_get_active_run, mock_find_record):
    """Test /lrr/process/{run_id}/status for completed/persisted run."""
    mock_get_active_run.return_value = None
    mock_find_record.return_value = {
        "status": "completed",
        "total_steps": 100,
    }

    response = client.get("/lrr/process/run-456/status")
    assert response.status_code == 200
    status = response.json()
    assert status["status"] == "completed"
    assert status["progress"] == 100
    assert status["pipeline"] == "lrr"


@patch("routes.lrr.get_active_run")
@patch("routes.data.find_record")
def test_lrr_get_process_status_not_found(mock_find_record, mock_get_active_run):
    """Test /lrr/process/{run_id}/status returns 404 when not found."""
    mock_get_active_run.return_value = None
    mock_find_record.return_value = None

    response = client.get("/lrr/process/nonexistent/status")
    assert response.status_code == 404


def test_lrr_download_pdf_and_system_routes(monkeypatch):
    """Exercise download-file, process GET/POST, process-pdf, and system run routes."""
    import routes.lrr as lrr_mod
    import routes.runs as runs_mod

    monkeypatch.setattr(lrr_mod, "get_gcs_file_bytes", lambda path: (b"pdf-bytes", "folder/doc.pdf"))
    resp = client.get("/lrr/download-file", params={"file_path": "gs://b/folder/doc.pdf"})
    assert resp.status_code == 200
    assert resp.content == b"pdf-bytes"

    monkeypatch.setattr(lrr_mod, "get_gcs_file_bytes", MagicMock(side_effect=FileNotFoundError("missing")))
    assert client.get("/lrr/download-file", params={"file_path": "gs://b/m.pdf"}).status_code == 404

    monkeypatch.setattr(lrr_mod, "get_gcs_file_bytes", MagicMock(side_effect=ValueError("bad path")))
    assert client.get("/lrr/download-file", params={"file_path": "bad"}).status_code == 400

    assert client.get("/lrr/process").status_code == 200

    fake_run = MagicMock(run_id="r-1", status="running", objective="obj", seeds=["https://example.com"])
    fake_validator = MagicMock()
    fake_validator.validate_urls.return_value = (["https://example.com"], [])
    monkeypatch.setattr(lrr_mod, "get_validator", lambda: fake_validator, raising=False)
    monkeypatch.setattr("routes.lrr.get_validator", lambda: fake_validator, raising=False)
    monkeypatch.setattr(runs_mod, "get_validator", lambda: fake_validator)
    monkeypatch.setattr(runs_mod, "start_run", lambda **kwargs: fake_run)
    monkeypatch.setattr(runs_mod, "get_data_snapshot", lambda: ({"runs": [{"run_id": "r-p"}], "events": {"r-p": []}}, "live"))
    monkeypatch.setattr(runs_mod, "list_active_runs", lambda: [])
    monkeypatch.setattr(runs_mod, "get_active_run", lambda rid: None)
    monkeypatch.setattr(runs_mod, "find_record", lambda col, k, v: {"run_id": v} if v == "r-p" else None)

    assert client.get("/lrr/system/mode").json() == {"mode": "live"}
    assert client.get("/lrr/system/runs").json() == [{"run_id": "r-p"}]
    assert client.get("/lrr/system/runs/r-p").json() == {"run_id": "r-p"}
    assert client.get("/lrr/system/runs/missing").status_code == 404
    assert client.get("/lrr/system/runs/r-p/events").status_code == 200
    assert client.get("/lrr/system/runs/missing/events").status_code == 404
    assert client.post("/lrr/system/runs", json={"urls": ["https://example.com"]}).status_code == 200
    assert client.post("/lrr/system/runs", json={"urls": ["   "]}).status_code == 400
    assert client.post("/lrr/process", json={"urls": ["https://example.com"], "request_id": "20440"}).status_code == 200

    monkeypatch.setattr(lrr_mod, "process_pdf_files", lambda files, request_id=None: {"request_id": request_id or "1", "output_path": "gs://b/p", "gcs_uri": "gs://b/p", "file_count": 1})
    async def _fake_trigger(rid):
        return None
    monkeypatch.setattr(lrr_mod, "trigger_downstream_phases", _fake_trigger)
    pdf_resp = client.post("/lrr/process-pdf", data={"request_id": "20440"}, files={"files": ("test.pdf", b"%PDF-1.4", "application/pdf")})
    assert pdf_resp.status_code == 200
    assert pdf_resp.json()["request_id"] == "20440"

    for page_route in ("/", "/sources", "/documents", "/graph", "/review", "/versions", "/runs", "/query"):
        r = client.get(page_route)
        assert r.status_code in (200, 404, 500)

    # Active run branches in /lrr/system/runs/{run_id} & /events
    from main.runtime.runner import LiveRun
    active_run = LiveRun("active-99", ["https://example.com"], "Obj")
    active_run.publish({"step": 1, "action": "fetch", "target": "t"})
    monkeypatch.setattr(runs_mod, "get_active_run", lambda rid: active_run if rid == "active-99" else None)
    assert client.get("/lrr/system/runs/active-99").status_code == 200
    assert len(client.get("/lrr/system/runs/active-99/events").json()) == 1
    assert client.get("/lrr/system/runs/missing/live").status_code == 404



