"""Tests for the run service."""
from unittest.mock import patch, MagicMock
import pytest

from main.services import run_service

def test_start_run():
    """Test that the start_run service function correctly calls the RUN_MANAGER."""
    with patch.object(run_service, 'RUN_MANAGER', MagicMock()) as mock_run_manager:
        seeds = ["https://example.com"]
        run_service.start_run(seeds=seeds, objective="Test", resume=None, request_id="123")
        mock_run_manager.start.assert_called_once()


async def test_serializers_and_trigger_downstream_phases(monkeypatch):
    state = {
        "run_id": "r1",
        "objective": "obj",
        "status": "running",
        "step": 2,
        "created_at": "2026-01-01T00:00:00Z",
        "error": None,
        "seeds": ["https://example.com"],
        "result": {"outputs": [{"id": "o1"}], "errors": []},
    }
    summary = run_service.serialize_live_run_summary(state)
    detail = run_service.serialize_live_run_detail(state)
    events = run_service.serialize_live_events([{"step": 1, "action": "fetch", "target": "t"}])
    assert summary["accepted"] == 1
    assert detail["seeds"] == ["https://example.com"]
    assert events[0]["status"] == "ok"

    await run_service.trigger_downstream_phases("")
    p2 = MagicMock()
    p3 = MagicMock()
    p4 = MagicMock()
    monkeypatch.setattr(run_service, "execute_phase_2", p2)
    monkeypatch.setattr(run_service, "execute_phase_3", p3)
    monkeypatch.setattr(run_service, "execute_phase_4", p4)
    await run_service.trigger_downstream_phases("20440")
    import asyncio
    await asyncio.sleep(0.05)
    p2.assert_called_once_with("20440")
