"""Tests for runtime runner module."""

from main.runtime.runner import LiveRun
import pytest


def test_live_run_creation():
    """Test LiveRun object creation."""
    run = LiveRun("run-123", ["https://example.com"], "Test objective")
    assert run.run_id == "run-123"
    assert run.seeds == ["https://example.com"]
    assert run.objective == "Test objective"
    assert run.status == "queued"


def test_live_run_attach_detach():
    """Test attaching and detaching queue subscribers."""
    run = LiveRun("run-123", ["https://example.com"], "Test")
    q = run.attach()
    assert q is not None
    run.detach(q)


def test_live_run_publish():
    """Test publishing events to subscribers."""
    run = LiveRun("run-123", ["https://example.com"], "Test")
    run.publish({"event": "test", "data": "value"})
    assert len(run.history) == 1
    assert run.history[0]["event"] == "test"


def test_live_run_snapshot():
    """Test snapshot method."""
    run = LiveRun("run-123", ["https://example.com"], "Test")
    run.status = "running"
    run.step = 5
    snap = run.snapshot()
    assert snap["run_id"] == "run-123"
    assert snap["status"] == "running"
    assert snap["step"] == 5


def test_live_run_multiple_publishes():
    """Test multiple publish events accumulate in history."""
    run = LiveRun("run-456", ["https://seed1.com", "https://seed2.com"], "Multi seed")
    run.publish({"event": "start"})
    run.publish({"event": "progress", "data": 25})
    run.publish({"event": "progress", "data": 50})
    assert len(run.history) == 3
    assert run.history[0]["event"] == "start"
    assert run.history[1]["data"] == 25


def test_live_run_snapshot_with_history():
    """Test snapshot includes history."""
    run = LiveRun("run-789", ["https://example.com"], "Test")
    run.publish({"event": "init"})
    run.status = "running"
    snap = run.snapshot()
    assert "run_id" in snap
    assert "status" in snap


def test_live_run_empty_seeds():
    """Test LiveRun with empty seeds list."""
    run = LiveRun("run-empty", [], "Empty seeds test")
    assert run.seeds == []
    assert run.objective == "Empty seeds test"


def test_live_run_status_transitions():
    """Test status transitions through lifecycle."""
    run = LiveRun("run-lifecycle", ["https://example.com"], "Lifecycle test")
    
    # Initial state
    assert run.status == "queued"
    
    # Transition to running
    run.status = "running"
    assert run.status == "running"
    
    # Transition to completed
    run.status = "completed"
    assert run.status == "completed"
    
    snap = run.snapshot()
    assert snap["status"] == "completed"


def test_live_run_step_counter():
    """Test step counter in LiveRun."""
    run = LiveRun("run-step", ["https://example.com"], "Step test")
    assert run.step == 0
    
    run.step = 10
    assert run.step == 10
    
    snap = run.snapshot()
    assert snap["step"] == 10


def test_live_run_attach_multiple_queues():
    """Test attaching multiple subscriber queues."""
    run = LiveRun("run-multi", ["https://example.com"], "Multi queue test")
    q1 = run.attach()
    q2 = run.attach()
    
    assert q1 is not None
    assert q2 is not None
    assert q1 != q2  # Different queue objects
    run.detach(q1)
    run.detach(q2)


def test_run_manager_execute_success_and_failure(monkeypatch):
    """Test RunManager execution lifecycle for both success and error paths."""
    import main.runtime.runner as runner_mod
    from unittest.mock import MagicMock

    mgr = runner_mod.RunManager()
    live = runner_mod.LiveRun("run-ok", ["https://example.com"], "Obj")

    class FakeGraph:
        def stream(self, initial, stream_mode="updates"):
            yield {"planner": {"step": 1, "history": [{"step": 1, "action": "fetch", "target": "t", "reason": "r"}], "outputs": [{"id": "o1"}]}}
            yield {"finish": {"step": 2, "errors": []}}

    monkeypatch.setattr(runner_mod, "build_graph", lambda: FakeGraph())
    p2 = MagicMock()
    p3 = MagicMock()
    p4 = MagicMock()
    monkeypatch.setattr(runner_mod, "execute_phase_2", p2)
    monkeypatch.setattr(runner_mod, "execute_phase_3", p3)
    monkeypatch.setattr(runner_mod, "execute_phase_4", p4)
    monkeypatch.setattr(runner_mod, "invalidate_live_data", MagicMock())

    mgr._execute(live, resume=None, request_id="20440")
    assert live.status == "completed"
    assert live.result["step"] == 2
    p2.assert_called_once_with(request_id="20440")
    p3.assert_called_once_with(request_id="20440")
    p4.assert_called_once_with(request_id="20440")

    # Failure path
    live_fail = runner_mod.LiveRun("run-fail", ["https://example.com"], "Obj")
    monkeypatch.setattr(runner_mod, "build_graph", MagicMock(side_effect=RuntimeError("graph boom")))
    mgr._execute(live_fail, resume=None, request_id="20440")
    assert live_fail.status == "failed"
    assert "graph boom" in live_fail.error

    # List/get active
    mgr._runs[live.run_id] = live
    assert mgr.get(live.run_id) is live
    assert len(mgr.list_active()) >= 1



def test_live_run_publish_to_multiple_subscribers():
    """Test publish reaches all attached subscribers."""
    run = LiveRun("run-broadcast", ["https://example.com"], "Broadcast test")
    q1 = run.attach()
    q2 = run.attach()
    
    run.publish({"event": "broadcast"})
    
    # Both queues should have received the event
    assert len(run.history) == 1
    assert run.history[0]["event"] == "broadcast"
