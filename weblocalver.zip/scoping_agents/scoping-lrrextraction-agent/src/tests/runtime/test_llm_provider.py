"""Tests for the LLM provider."""

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from main.config.settings import Settings
from main.runtime.llm_provider import build_llm


@patch("main.runtime.llm_provider.google.auth.default")
@patch("langchain_google_genai.ChatGoogleGenerativeAI")
def test_build_llm_uses_correct_model_without_deprecated_kwargs(mock_chat, mock_auth, monkeypatch):
    """Test that the correct model is selected and no temperature/top_p/top_k/project/location are passed."""
    monkeypatch.delenv("AI_ACCESS_LAYER_BASE_URL", raising=False)
    monkeypatch.delenv("GENAI_BASE_URL", raising=False)
    settings = Settings()

    build_llm(settings, reasoning=False)
    call_kwargs = mock_chat.call_args.kwargs
    assert call_kwargs["model"] == settings.gemini_model
    for forbidden in ("project", "location", "vertexai", "temperature", "top_p", "top_k", "seed"):
        assert forbidden not in call_kwargs

    build_llm(settings, reasoning=True)
    call_kwargs = mock_chat.call_args.kwargs
    assert call_kwargs["model"] == settings.gemini_reasoning_model
    for forbidden in ("project", "location", "vertexai", "temperature", "top_p", "top_k", "seed"):
        assert forbidden not in call_kwargs


@patch("main.runtime.llm_provider.GoogleOAuthTokenProvider")
@patch("langchain_google_genai.ChatGoogleGenerativeAI")
def test_build_llm_uses_ai_access_layer_when_base_url_configured(mock_chat, mock_provider, monkeypatch):
    """Test AI Access Layer auth via GoogleOAuthTokenProvider and base_url."""
    monkeypatch.setenv("AI_ACCESS_LAYER_BASE_URL", "https://ai-access.internal/v1")
    monkeypatch.setenv("HTTPS_PROXY", "http://proxy:8080")
    monkeypatch.setenv("HTTP_PROXY", "http://proxy:8080")
    monkeypatch.setenv("NO_PROXY", "localhost")
    mock_provider.return_value = SimpleNamespace(token="oauth-token-123")

    settings = Settings()
    build_llm(settings, reasoning=False)

    call_kwargs = mock_chat.call_args.kwargs
    assert call_kwargs["model"] == settings.gemini_model
    assert call_kwargs["api_key"] == "oauth-token-123"
    assert call_kwargs["base_url"] == "https://ai-access.internal/v1"
    for forbidden in ("project", "location", "vertexai", "temperature", "top_p", "top_k", "seed"):
        assert forbidden not in call_kwargs


@patch("main.runtime.llm_provider.google.auth.default", side_effect=RuntimeError("no adc"))
def test_build_llm_raises_clear_error_when_adc_missing(mock_auth, monkeypatch):
    monkeypatch.delenv("AI_ACCESS_LAYER_BASE_URL", raising=False)
    monkeypatch.delenv("GENAI_BASE_URL", raising=False)
    settings = Settings()

    with pytest.raises(RuntimeError, match="No Application Default Credentials available"):
        build_llm(settings)
