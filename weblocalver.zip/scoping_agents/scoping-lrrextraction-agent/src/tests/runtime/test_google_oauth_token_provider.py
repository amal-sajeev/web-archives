"""Tests for GoogleOAuthTokenProvider and certificate configuration."""

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from main.runtime import google_oauth_token_provider as gtp


def test_configure_certificate_and_token_provider(tmp_path, monkeypatch):
    with pytest.raises(ValueError, match="No custom certificate paths"):
        gtp.configure_certificate([])

    with pytest.raises(FileNotFoundError, match="Certificate file not found"):
        gtp.configure_certificate([str(tmp_path / "missing.pem")])

    bad_cert = tmp_path / "bad.pem"
    bad_cert.write_text("invalid cert")
    with pytest.raises(ValueError, match="not PEM format"):
        gtp.configure_certificate([str(bad_cert)])

    good_cert = tmp_path / "good.pem"
    good_cert.write_text("-----BEGIN CERTIFICATE-----\nFAKE\n-----END CERTIFICATE-----\n")
    combined = gtp.configure_certificate([str(good_cert)])
    assert combined.endswith("combined-ca-bundle.pem")

    monkeypatch.setattr(gtp, "_CERTIFICATE_CONFIGURED", False)
    monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
    monkeypatch.setenv("CA_BUNDLE_PATH", "/etc/ssl/bundle.pem")
    gtp.configure_certificate_once()
    assert gtp.os.environ["SSL_CERT_FILE"] == "/etc/ssl/bundle.pem"

    monkeypatch.setattr(gtp, "_CERTIFICATE_CONFIGURED", False)
    monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
    monkeypatch.setenv("ENABLE_LOCAL_CERT_AUTH", "true")
    monkeypatch.setenv("CUSTOM_CERT_PATHS", str(good_cert))
    gtp.configure_certificate_once()
    assert gtp._CERTIFICATE_CONFIGURED is True

    creds = SimpleNamespace(valid=False, token="refreshed-lrr-token", refresh=MagicMock())
    monkeypatch.setattr(gtp, "default", lambda scopes=None: (creds, "proj"))
    provider = gtp.GoogleOAuthTokenProvider()
    assert provider.token == "refreshed-lrr-token"
    creds.refresh.assert_called_once()
