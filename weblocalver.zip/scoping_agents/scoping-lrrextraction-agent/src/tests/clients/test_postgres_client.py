"""Tests for clients.postgres_client."""

from unittest.mock import MagicMock

from main.clients import postgres_client as pc


def _sample_enriched_data():
    return [
        {
            "Risk Name": "R034 - Participation in Trading Markets",
            "Mandates": [
                {
                    "Regulatory Mandate": "MiFID II Art. 14 transparency requirement",
                    "Confidence Score": 0.9,
                    "AI Rationale": "Direct rule match",
                    "Evidence": [
                        {
                            "source_url": "https://eur-lex.europa.eu",
                            "deep_link": "https://eur-lex.europa.eu#m1",
                        }
                    ],
                },
                {
                    "Regulatory Mandate": "Best execution monitoring",
                    "Confidence Score": 0.85,
                    "AI Rationale": "Relevant obligation",
                    "Evidence": [],
                },
            ],
        }
    ]


def test_build_lrr_metadata_payload():
    payload = pc.build_lrr_metadata_payload(
        "gs://bucket/dbaware_review_20440/inbound-data/lrr/internet_search_data_enriched.json",
        _sample_enriched_data(),
    )
    assert payload["data_source"] == "lrr"
    assert payload["filename"] == "internet_search_data_enriched.json"
    assert len(payload["sections"]) == 2
    assert payload["sections"][0]["node_id"] == "lrr:mandate:1"
    assert payload["sections"][0]["section_id"] == 1
    assert payload["sections"][0]["excluded"] is False
    assert payload["sections"][1]["node_id"] == "lrr:mandate:2"
    assert payload["documents"][0]["sections"] == payload["sections"]


def test_upsert_lrr_data_extraction_metadata_skips_when_unconfigured(monkeypatch):
    for k in ("db_host", "DB_HOST", "db_user", "DB_USER", "scoping_db_pass", "SCOPING_DB_PASS", "db_name", "DB_NAME"):
        monkeypatch.delenv(k, raising=False)
    assert pc.upsert_lrr_data_extraction_metadata("20440", "gs://b/file.json", []) is None
    assert pc.upsert_lrr_data_extraction_metadata(None, "gs://b/file.json", []) is None
    assert pc.upsert_lrr_data_extraction_metadata("not-int", "gs://b/file.json", []) is None


def test_upsert_lrr_data_extraction_metadata_updates_and_inserts(monkeypatch):
    monkeypatch.setenv("db_host", "localhost")
    monkeypatch.setenv("db_user", "postgres")
    monkeypatch.setenv("scoping_db_pass", "pw")
    monkeypatch.setenv("db_name", "dbaware")
    if pc.sqlalchemy is None:
        monkeypatch.setattr(pc, "sqlalchemy", MagicMock())
    if pc.text is None:
        monkeypatch.setattr(pc, "text", lambda s: s)

    # Update path (1st execute resolves review_scope_id, 2nd execute updates row)
    conn_upd = MagicMock()
    res_lookup = MagicMock()
    res_lookup.first.return_value = (20440,)
    conn_upd.execute.side_effect = [res_lookup, MagicMock(rowcount=1)]
    engine_upd = MagicMock()
    engine_upd.begin.return_value.__enter__.return_value = conn_upd
    monkeypatch.setattr(pc.sqlalchemy, "create_engine", lambda *a, **k: engine_upd)

    res_upd = pc.upsert_lrr_data_extraction_metadata(
        "20440",
        "gs://b/dbaware_review_20440/inbound-data/lrr/internet_search_data_enriched.json",
        _sample_enriched_data(),
    )
    assert res_upd["operation"] == "updated"
    assert res_upd["review_scope_id"] == 20440
    assert conn_upd.execute.call_count == 2

    # Insert path (1st execute lookup returns None, 2nd inserts parent, 3rd update rowcount=0, 4th inserts row)
    conn_ins = MagicMock()
    res_lookup_none = MagicMock()
    res_lookup_none.first.return_value = None
    conn_ins.execute.side_effect = [
        res_lookup_none,
        MagicMock(rowcount=1),
        MagicMock(rowcount=0),
        MagicMock(rowcount=1),
    ]
    engine_ins = MagicMock()
    engine_ins.begin.return_value.__enter__.return_value = conn_ins
    monkeypatch.setattr(pc.sqlalchemy, "create_engine", lambda *a, **k: engine_ins)

    res_ins = pc.upsert_lrr_data_extraction_metadata(
        20440,
        "gs://b/dbaware_review_20440/inbound-data/lrr/internet_search_data_enriched.json",
        _sample_enriched_data(),
    )
    assert res_ins["operation"] == "inserted"
    assert res_ins["review_scope_id"] == 20440
    assert conn_ins.execute.call_count == 4
    insert_params = conn_ins.execute.call_args_list[-1][0][1]
    assert insert_params["status"] == 1
