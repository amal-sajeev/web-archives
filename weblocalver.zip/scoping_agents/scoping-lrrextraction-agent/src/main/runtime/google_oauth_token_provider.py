import logging
import os
import tempfile

import certifi
from google.auth import default
from google.auth.transport.requests import Request

logger = logging.getLogger(__name__)

_CERTIFICATE_CONFIGURED = False


def _is_local_cert_auth_enabled() -> bool:
    """Enable custom certificate auth only when explicitly enabled for local runs."""
    return str(os.getenv("ENABLE_LOCAL_CERT_AUTH", "")).strip().lower() == "true"


def _is_local_runtime() -> bool:
    """Treat Kubernetes runtime as non-local; default to local otherwise."""
    return not bool(os.getenv("KUBERNETES_SERVICE_HOST"))


def _set_ssl_bundle_env(path: str) -> None:
    """Set SSL CA bundle environment variables."""
    os.environ["REQUESTS_CA_BUNDLE"] = path
    os.environ["SSL_CERT_FILE"] = path
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = path
    os.environ["CURL_CA_BUNDLE"] = path


def configure_certificate(custom_cert_paths: list[str]) -> str:
    """Combine certifi's CA bundle with custom PEM certs and configure env vars."""
    if not custom_cert_paths:
        raise ValueError("No custom certificate paths are set")

    with open(certifi.where(), "r", encoding="utf-8") as fh:
        ca_bundle = fh.read()

    custom_certs: list[str] = []
    for cert_path in custom_cert_paths:
        if not os.path.exists(cert_path):
            raise FileNotFoundError(f"Certificate file not found: {cert_path}")
        with open(cert_path, "r", encoding="utf-8") as fh:
            cert_content = fh.read()
        if "-----BEGIN CERTIFICATE-----" not in cert_content:
            raise ValueError(f"Certificate file is not PEM format: {cert_path}")
        custom_certs.append(cert_content)

    bundle_dir = os.path.dirname(custom_cert_paths[0]) or tempfile.gettempdir()
    combined_path = os.path.join(bundle_dir, "combined-ca-bundle.pem")
    try:
        with open(combined_path, "w", encoding="utf-8") as fh:
            fh.write(ca_bundle)
            for cert_content in custom_certs:
                fh.write("\n")
                fh.write(cert_content)
    except OSError:
        combined_path = os.path.join(tempfile.gettempdir(), "combined-ca-bundle.pem")
        with open(combined_path, "w", encoding="utf-8") as fh:
            fh.write(ca_bundle)
            for cert_content in custom_certs:
                fh.write("\n")
                fh.write(cert_content)

    _set_ssl_bundle_env(combined_path)
    return combined_path


def configure_certificate_once() -> None:
    """Configure custom SSL certificates once per process when requested."""
    global _CERTIFICATE_CONFIGURED
    if _CERTIFICATE_CONFIGURED:
        return

    if not _is_local_runtime():
        configured_path = (os.getenv("CA_BUNDLE_PATH") or "").strip()
        if configured_path:
            _set_ssl_bundle_env(configured_path)
            logger.info("Configured SSL CA bundle from CA_BUNDLE_PATH: %s", configured_path)
        else:
            logger.info("CA_BUNDLE_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    if not _is_local_cert_auth_enabled():
        logger.info("Local certificate auth is disabled; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    custom_paths = str(os.getenv("CUSTOM_CERT_PATHS") or "").strip()
    if custom_paths:
        cert_paths = [p.strip() for p in custom_paths.split(",") if p.strip()]
    else:
        legacy_path = str(os.getenv("CUSTOM_CERT_PATH") or "").strip()
        cert_paths = [legacy_path] if legacy_path else []

    if not cert_paths:
        logger.info("CUSTOM_CERT_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    combined_path = configure_certificate(cert_paths)
    logger.info("Custom certificate bundle configured at: %s", combined_path)
    _CERTIFICATE_CONFIGURED = True


class GoogleOAuthTokenProvider:
    """Obtain and refresh Google OAuth access tokens for AI Access Layer calls."""

    def __init__(self) -> None:
        configure_certificate_once()
        self.credentials, _ = default(
            scopes=[
                "https://www.googleapis.com/auth/cloud-platform",
                "https://www.googleapis.com/auth/userinfo.email",
            ]
        )
        self.request = Request()

    @property
    def token(self) -> str | None:
        if not self.credentials.valid:
            configure_certificate_once()
            self.credentials.refresh(self.request)
        return self.credentials.token
