import os
from typing import Any

import google.auth
from config.settings import Settings
from runtime.google_oauth_token_provider import (
    GoogleOAuthTokenProvider,
    configure_certificate_once,
)


def build_llm(settings: Settings, reasoning: bool = False) -> Any:
    """Create the configured chat model via AI Access Layer / Google OAuth."""
    return _build_gemini(settings, reasoning)


def _build_gemini(settings: Settings, reasoning: bool) -> Any:
    from langchain_google_genai import ChatGoogleGenerativeAI

    settings.require_llm_config()
    _apply_network_env(settings)
    if settings.google_application_credentials:
        os.environ.setdefault(
            "GOOGLE_APPLICATION_CREDENTIALS",
            settings.google_application_credentials,
        )
    configure_certificate_once()

    model_name = settings.gemini_reasoning_model if reasoning else settings.gemini_model
    base_url = (
        getattr(settings, "ai_access_layer_base_url", None)
        or os.getenv("AI_ACCESS_LAYER_BASE_URL")
        or os.getenv("GENAI_BASE_URL")
    )

    if base_url:
        token = GoogleOAuthTokenProvider().token
        return ChatGoogleGenerativeAI(
            model=model_name,
            api_key=token,
            base_url=base_url,
            max_retries=settings.max_retries,
        )

    try:
        google.auth.default()
    except Exception as exc:
        raise RuntimeError(
            "No Application Default Credentials available for Gemini. "
            "Locally, run: gcloud auth application-default login. "
            "For WIF, set GOOGLE_APPLICATION_CREDENTIALS to your external_account "
            f"credential config file. ({exc})"
        ) from exc

    return ChatGoogleGenerativeAI(
        model=model_name,
        max_retries=settings.max_retries,
    )


def _apply_network_env(settings: Settings) -> None:
    if settings.https_proxy:
        os.environ["HTTPS_PROXY"] = settings.https_proxy
        os.environ["https_proxy"] = settings.https_proxy
    if settings.http_proxy:
        os.environ["HTTP_PROXY"] = settings.http_proxy
        os.environ["http_proxy"] = settings.http_proxy
    if settings.no_proxy:
        os.environ["NO_PROXY"] = settings.no_proxy
        os.environ["no_proxy"] = settings.no_proxy
    if settings.ssl_cert_file:
        os.environ["SSL_CERT_FILE"] = settings.ssl_cert_file
    if settings.requests_ca_bundle:
        os.environ["REQUESTS_CA_BUNDLE"] = settings.requests_ca_bundle
