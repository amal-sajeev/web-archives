"""PostgreSQL client for persisting LRR extraction metadata to dbaware_scoping.review_data_extraction."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Iterable

try:
    import sqlalchemy
    from sqlalchemy import text
except ModuleNotFoundError:  # pragma: no cover - optional in lightweight test envs
    sqlalchemy = None  # type: ignore[assignment]
    text = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


def build_lrr_metadata_payload(
    storage_uri: str,
    enriched_data: Iterable[dict[str, Any]] | None,
) -> dict[str, Any]:
    """Build structured review_data_extraction metadata for LRR enriched mandates."""
    sections: list[dict[str, Any]] = []
    idx = 0
    for risk_entry in enriched_data or []:
        if not isinstance(risk_entry, dict):
            continue
        risk_name = str(risk_entry.get("Risk Name") or risk_entry.get("risk_name") or "").strip()
        for mandate in risk_entry.get("Mandates") or []:
            if not isinstance(mandate, dict):
                continue
            idx += 1
            title = str(
                mandate.get("Regulatory Mandate")
                or mandate.get("mandate")
                or mandate.get("Citation")
                or f"{risk_name} - Mandate {idx}"
            ).strip()
            evidence = mandate.get("Evidence") or []
            source_urls = [
                str(ev.get("source_url") or ev.get("deep_link") or "").strip()
                for ev in evidence
                if isinstance(ev, dict) and (ev.get("source_url") or ev.get("deep_link"))
            ]
            sections.append(
                {
                    "section_id": idx,
                    "section_title": title,
                    "node_id": f"lrr:mandate:{idx}",
                    "risk_name": risk_name,
                    "citation": str(mandate.get("Citation") or "").strip(),
                    "issuing_authority": str(mandate.get("Issuing Authority") or "").strip(),
                    "source_urls": source_urls,
                    "status": "excluded" if mandate.get("excluded") else "active",
                    "excluded": bool(mandate.get("excluded", False)),
                }
            )

    return {
        "data_source": "lrr",
        "filename": "internet_search_data_enriched.json",
        "storage_uri": storage_uri,
        "status": "active",
        "excluded": False,
        "sections": sections,
        "documents": [
            {
                "document_id": "lrr_internet_search_data_enriched",
                "document_title": "Regulatory & Internet Search Mandates",
                "filename": "internet_search_data_enriched.json",
                "storage_uri": storage_uri,
                "status": "active",
                "excluded": False,
                "sections": sections,
            }
        ],
    }


def _get_db_config() -> tuple[str | None, str | None, str | None, str | None, str, str]:
    db_host = os.getenv("db_host") or os.getenv("DB_HOST")
    db_user = os.getenv("db_user") or os.getenv("DB_USER")
    db_pass = os.getenv("scoping_db_pass") or os.getenv("SCOPING_DB_PASS")
    db_name = os.getenv("db_name") or os.getenv("DB_NAME")
    db_port = os.getenv("db_port", "5432") or os.getenv("DB_PORT", "5432")
    table_name = (
        os.getenv("DATA_EXTRACTION_TABLE_NAME")
        or os.getenv("data_extraction_table_name")
        or "dbaware_scoping.review_data_extraction"
    )
    return db_host, db_user, db_pass, db_name, db_port, table_name


def _coerce_scope_id(raw_scope_id: int | str | None) -> int | None:
    if raw_scope_id is None or isinstance(raw_scope_id, bool):
        return None
    if isinstance(raw_scope_id, int):
        return raw_scope_id
    cleaned = str(raw_scope_id).strip()
    if cleaned.lstrip("-").isdigit():
        return int(cleaned)
    return None


def _resolve_or_ensure_review_scope_id(
    connection: Any,
    scope_candidate: int,
    user_id: str = "system",
    remarks: str = "LRR enriched mandate generation",
) -> int:
    """Resolve review_scope_id from dbaware_scoping.review_scope or insert a parent row."""
    review_scope_table = (
        os.getenv("REVIEW_SCOPE_TABLE_NAME")
        or os.getenv("review_scope_table_name")
        or "dbaware_scoping.review_scope"
    )
    row = connection.execute(
        text(
            f"""
            SELECT review_scope_id
            FROM {review_scope_table}
            WHERE review_scope_id = :candidate
               OR review_plan_id = :candidate
            ORDER BY CASE WHEN review_scope_id = :candidate THEN 0 ELSE 1 END,
                     created_on DESC NULLS LAST
            LIMIT 1
            """
        ),
        {"candidate": scope_candidate},
    ).first()
    if row and row[0] is not None:
        return int(row[0])

    connection.execute(
        text(
            f"""
            INSERT INTO {review_scope_table} (
                review_scope_id,
                review_plan_id,
                created_by,
                created_on,
                remarks
            )
            SELECT :review_scope_id, :review_plan_id, :created_by, CURRENT_TIMESTAMP, :remarks
            WHERE NOT EXISTS (
                SELECT 1
                FROM {review_scope_table} existing
                WHERE existing.review_scope_id = :review_scope_id
            )
            """
        ),
        {
            "review_scope_id": scope_candidate,
            "review_plan_id": scope_candidate,
            "created_by": user_id,
            "remarks": remarks,
        },
    )
    return scope_candidate


def upsert_lrr_data_extraction_metadata(
    review_scope_instance_id: int | str | None = None,
    storage_uri: str = "",
    enriched_data: Iterable[dict[str, Any]] | None = None,
    user_id: str = "system",
    remarks: str = "LRR enriched mandate generation",
    *,
    review_scope_id: int | str | None = None,
) -> dict[str, Any] | None:
    """Upsert LRR enriched mandate metadata into dbaware_scoping.review_data_extraction."""
    payload = build_lrr_metadata_payload(storage_uri=storage_uri, enriched_data=enriched_data)

    if sqlalchemy is None:
        logger.info("SQLAlchemy unavailable; skipping LRR metadata persistence.")
        return None

    raw_scope = review_scope_id if review_scope_id is not None else review_scope_instance_id
    scope_id_int = _coerce_scope_id(raw_scope)
    if scope_id_int is None:
        logger.warning(
            "Skipping LRR metadata persistence because review_scope_id is missing or non-integer (%r).",
            raw_scope,
        )
        return None

    db_host, db_user, db_pass, db_name, db_port, table_name = _get_db_config()
    if not all([db_host, db_user, db_pass, db_name]):
        logger.info(
            "Skipping LRR metadata DB persistence because DB environment config is incomplete."
        )
        return None

    payload_json = json.dumps(payload, ensure_ascii=False, default=str)
    try:
        engine = sqlalchemy.create_engine(
            sqlalchemy.engine.url.URL.create(
                drivername="postgresql+pg8000",
                username=db_user,
                password=db_pass,
                host=db_host,
                port=db_port,
                database=db_name,
            ),
            pool_pre_ping=True,
            future=True,
        )
        with engine.begin() as connection:
            resolved_scope_id = _resolve_or_ensure_review_scope_id(
                connection,
                scope_id_int,
                user_id=user_id,
                remarks=remarks,
            )
            update_result = connection.execute(
                text(
                    f"""
                    UPDATE {table_name}
                    SET metadata = CAST(:metadata AS JSONB),
                        status = :status,
                        remarks = :remarks,
                        updated_by = :updated_by,
                        updated_on = CURRENT_TIMESTAMP
                    WHERE review_scope_id = :review_scope_id
                      AND data_source = 'lrr'
                    """
                ),
                {
                    "review_scope_id": resolved_scope_id,
                    "metadata": payload_json,
                    "status": 1,
                    "remarks": remarks,
                    "updated_by": user_id,
                },
            )
            if update_result.rowcount and update_result.rowcount > 0:
                operation = "updated"
            else:
                connection.execute(
                    text(
                        f"""
                        INSERT INTO {table_name} (
                            review_scope_id,
                            data_source,
                            metadata,
                            status,
                            created_by,
                            created_on,
                            remarks
                        ) VALUES (
                            :review_scope_id,
                            'lrr',
                            CAST(:metadata AS JSONB),
                            :status,
                            :created_by,
                            CURRENT_TIMESTAMP,
                            :remarks
                        )
                        """
                    ),
                    {
                        "review_scope_id": resolved_scope_id,
                        "metadata": payload_json,
                        "status": 1,
                        "created_by": user_id,
                        "remarks": remarks,
                    },
                )
                operation = "inserted"

        logger.info(
            "LRR metadata %s in %s for review_scope_id=%s (%d mandates)",
            operation,
            table_name,
            resolved_scope_id,
            len(payload["sections"]),
        )
        return {
            "operation": operation,
            "review_scope_id": resolved_scope_id,
            "review_scope_instance_id": str(resolved_scope_id),
            "metadata": payload,
        }
    except Exception as exc:
        logger.warning(
            "Failed to persist LRR metadata for review_scope_id=%s: %s",
            scope_id_int,
            exc,
        )
        return None
