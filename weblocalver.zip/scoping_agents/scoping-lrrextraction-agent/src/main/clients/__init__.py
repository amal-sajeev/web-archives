"""PostgreSQL persistence helpers for scoping-lrrextraction-agent."""
