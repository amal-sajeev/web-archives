# Pull Request Description: `dbaware-ui` (`apps/remote_leftSidebar`)

## Summary
Updates the AI Chat sidebar (`apps/remote_leftSidebar`) so users can view, exclude, or restore source documents and individual sections across all 5 Preliminary Research categories, approve/reject document workflow proposals interactively in chat, and automatically trigger partial Preliminary Research regeneration for only the affected sections.

## What Changed
- **API Client & Section Mapping (`src/api/preliminaryResearchClient.ts`)**
  - Expanded `PreliminaryResearchDocumentType` to all 5 categories: `'Policies'`, `'KOD'`, `'Procedure Documents'`, `'GFMS Data'`, and `'Historical Scoping Documents'`.
  - Added `PreliminaryResearchSectionRecord` (`section_id`, `section_title`, `node_id`, `status`, `excluded`), `storageUri`, and `sections[]` to `PreliminaryResearchDocumentItem`.
  - Added `computeAffectedPreliminaryResearchSections(...)`, support for section-level selections and `mode: 'exclude' | 'include'` in `regeneratePreliminaryResearchWithExclusions`, `affectedSections` return values, and `triggerPreliminaryResearchGeneration(planId, sectionsToGenerate)`.
- **Chat Hook & Types (`src/types/aiChat.ts`, `src/hooks/useAiChat.tsx`, `src/components/AiChat/AiChatContainer.tsx`)**
  - Added `WorkflowMessageState` to `ChatMessage`.
  - Parsed `document_workflow` state from `QNA_CHAT` responses, added `handleWorkflowDecision('approve' | 'reject', messageId)`, and dispatched `'ai-chat:preliminary-research-workflow-executed'` with `affectedSections` upon workflow execution.
- **UI Controls & Styling (`src/components/AiChat/AiChatPresenter.tsx`, `src/components/AiChat/AiChat.module.css`)**
  - Updated the Source Documents panel to list all 5 categories, switch between **Exclude Active** and **Restore Excluded** modes, and expand documents with `sections[]` to select/restore individual sections.
  - Added an interactive **`@` mention autocomplete popover** above the chat input box that lazy-loads plan source documents and sections, filters live across categories, document titles, and sections (showing `Category`, `Active`, and `Excluded` badges), and supports keyboard navigation (`ArrowDown`, `ArrowUp`, `Enter`/`Tab`, `Escape`) or mouse click to insert structured `@[Category: Document > Section ID: Section Title]` annotations.
  - Added inline **Approve & Regenerate** / **Cancel** buttons on pending workflow approval chat messages.
  - Wired `'ai-chat:preliminary-research-workflow-executed'` and manual exclude/restore submissions to trigger partial Preliminary Research regeneration using `affectedSections`.
- **Unit Tests & Coverage**
  - Added `src/api/preliminaryResearchClient.test.ts`, `src/api/sharedApi.test.ts`, `src/store/aiChatSlice.test.ts`, `src/hooks/useAiChat.test.tsx`, `src/components/AiChat/AiChatContainer.test.tsx`, `src/test/setupTests.ts`, and expanded `src/components/AiChat/AiChatPresenter.test.tsx`.

## Why
Completes the end-to-end UI flow for both button-driven and chat-driven Preliminary Research include/exclude workflows so only impacted sections regenerate, while making `@`-annotated document and section targeting effortless in chat.

## Testing & Coverage
- Command: `npx vitest run --coverage` (in `apps/remote_leftSidebar`)
- Result: **6 test files passed, 20 tests passed, 0 failed** (**86.82% statement coverage** across configured client, hook, store, container, and mode-menu modules)
