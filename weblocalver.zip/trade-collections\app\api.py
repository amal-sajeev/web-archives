"""JSON API.

The screens are server-rendered from the same store these routes read, so the
pages work without JavaScript; every mutation goes through here.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel

from .models import (
    ActionResult,
    CaseStatus,
    CheckResolution,
    CollectionCase,
    FieldUpdate,
    QueryCreate,
    ValidationRequest,
)
from .store import CaseStore, get_store

router = APIRouter(prefix="/api", tags=["collections"])


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _case(store: CaseStore, case_id: str) -> CollectionCase:
    case = store.get(case_id)
    if case is None:
        raise HTTPException(status_code=404, detail=f"Case {case_id} not found")
    return case


def _next_href(store: CaseStore, current: CollectionCase) -> str:
    """Where to send the maker once this case is off their plate."""
    queue = [c for c in store.list_cases(view="all")
             if c.case_id != current.case_id
             and (c.needs_maker or c.status is CaseStatus.READY_FOR_REVIEW)]
    queue.sort(key=lambda c: c.sla_due or c.received_at)
    return f"/cases/{queue[0].case_id}" if queue else "/"

def _snapshot(case: CollectionCase) -> dict[str, Any]:
    """Everything the page needs to repaint itself after a mutation."""
    return {
        "case_id": case.case_id,
        "status": case.status.value,
        "status_label": case.status_label,
        "status_tone": case.status_tone,
        "blockers": case.blockers,
        "ready_to_validate": case.ready_to_validate,
        "checks_passed": case.checks_passed,
        "checks_total": case.checks_total,
        "open_queries": len(case.open_queries),
        "audit": [
            {"at": e.at.strftime("%d %b %H:%M"), "actor": e.actor,
             "role": e.role, "action": e.action, "detail": e.detail}
            for e in case.audit
        ],
    }


def _ok(case: CollectionCase, message: str, store: CaseStore | None = None,
        **extra: Any) -> ActionResult:
    data = _snapshot(case)
    if store is not None:
        data["next"] = _next_href(store, case)
    data.update(extra)
    return ActionResult(ok=True, message=message, case_id=case.case_id,
                        status=case.status.value, status_label=case.status_label,
                        status_tone=case.status_tone, data=data)


# ---------------------------------------------------------------------------
# session
# ---------------------------------------------------------------------------

class RoleSwitch(BaseModel):
    role: str


@router.post("/session/role")
def switch_role(body: RoleSwitch, store: CaseStore = Depends(get_store)) -> dict[str, str]:
    store.session.switch(body.role)
    return {"role": store.session.role, "name": store.session.name}


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "trade-collections-maker-workbench"}


# ---------------------------------------------------------------------------
# reads
# ---------------------------------------------------------------------------

@router.get("/cases", response_model=list[CollectionCase])
def list_cases(
    view: str = "all",
    search: str | None = None,
    source: str | None = None,
    status: str | None = None,
    priority: str | None = None,
    assignee: str | None = None,
    sort: str = "received",
    direction: str = "desc",
    store: CaseStore = Depends(get_store),
) -> list[CollectionCase]:
    return store.list_cases(view=view, search=search, source=source, status=status,
                            priority=priority, assignee=assignee, sort=sort, direction=direction)


@router.get("/cases/counts")
def counts(store: CaseStore = Depends(get_store)) -> dict[str, int]:
    return store.counts()


@router.get("/cases/live")
def live(store: CaseStore = Depends(get_store)) -> dict[str, Any]:
    """Light payload the worklist polls while the pipeline is running."""
    return {
        "cases": [
            {"case_id": c.case_id, "status": c.status.value,
             "status_label": c.status_label, "status_tone": c.status_tone,
             "progress": store.progress(c),
             "checks_passed": c.checks_passed, "checks_total": c.checks_total}
            for c in store.all_cases()
        ]
    }


@router.get("/search")
def search(q: str = Query(default=""), store: CaseStore = Depends(get_store)) -> dict[str, Any]:
    rows = store.list_cases(view="all", search=q or None) if q else store.list_cases(view="all")
    if q:
        extra = [c for c in store.all_cases()
                 if c.status in (CaseStatus.IN_CHECKER_QUEUE, CaseStatus.COMPLETED)
                 and (q.lower() in c.case_id.lower() or q.lower() in c.customer.lower()
                      or q.lower() in c.boe_number.lower())]
        rows = rows + extra
    return {
        "results": [
            {"title": c.case_id,
             "subtitle": f"{c.customer} · {c.principal_display} · BoE {c.boe_number}",
             "badge": c.status_label, "tone": c.status_tone,
             "href": f"/cases/{c.case_id}"}
            for c in rows[:12]
        ]
    }


@router.get("/ports")
def ports(q: str | None = None, store: CaseStore = Depends(get_store)) -> dict[str, Any]:
    return {"ports": [p.model_dump() for p in store.ports(q)]}


@router.get("/cases/{case_id}", response_model=CollectionCase)
def get_case(case_id: str, store: CaseStore = Depends(get_store)) -> CollectionCase:
    return _case(store, case_id)


@router.get("/cases/{case_id}/state")
def case_state(case_id: str, store: CaseStore = Depends(get_store)) -> dict[str, Any]:
    case = _case(store, case_id)
    data = _snapshot(case)
    data["progress"] = store.progress(case)
    data["stages"] = [s.model_dump() for s in case.stages]
    return data


# ---------------------------------------------------------------------------
# field mutations
# ---------------------------------------------------------------------------

@router.patch("/cases/{case_id}/fields/{key}", response_model=ActionResult)
def update_field(case_id: str, key: str, body: FieldUpdate,
                 store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    field = store.update_field(case, key, body.value, body.note)
    if field is None:
        raise HTTPException(status_code=404, detail=f"Field {key} not found on {case_id}")
    return _ok(case, f"{field.label} set to {field.value}.", field=field.model_dump())


@router.post("/cases/{case_id}/fields/{key}/accept", response_model=ActionResult)
def accept_field(case_id: str, key: str, store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    field = store.accept_field(case, key)
    if field is None:
        raise HTTPException(status_code=404, detail=f"Field {key} not found on {case_id}")
    return _ok(case, f"{field.label} accepted.", field=field.model_dump())


class PortResolve(BaseModel):
    code: str


@router.post("/cases/{case_id}/fields/{key}/resolve-port", response_model=ActionResult)
def resolve_port(case_id: str, key: str, body: PortResolve,
                 store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    field = store.resolve_port(case, key, body.code)
    if field is None:
        raise HTTPException(status_code=400, detail=f"Unknown port code {body.code}")
    resolved = next((c for c in case.checks if c.status == "resolved"), None)
    return _ok(case, f"{field.label} set to {field.value}.",
               field=field.model_dump(),
               check=resolved.model_dump() if resolved else None,
               charges=case.charges.model_dump() | {"total": case.charges.total})


# ---------------------------------------------------------------------------
# checks, charges, queries
# ---------------------------------------------------------------------------

@router.post("/cases/{case_id}/checks/{check_id}/resolve", response_model=ActionResult)
def resolve_check(case_id: str, check_id: str, body: CheckResolution,
                  store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    check = store.resolve_check(case, check_id, body.resolution)
    if check is None:
        raise HTTPException(status_code=400, detail=f"{check_id} is not an open exception")
    return _ok(case, f"{check.label} resolved.",
               check=check.model_dump(),
               charges=case.charges.model_dump() | {"total": case.charges.total})


@router.post("/cases/{case_id}/charges/recalculate", response_model=ActionResult)
def recalculate(case_id: str, store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    charges = store.recalculate_charges(case)
    return _ok(case, f"Total INR {charges.total:,.2f} from tariff {charges.tariff_ref}.",
               charges=charges.model_dump() | {"total": charges.total})


@router.post("/cases/{case_id}/queries", response_model=ActionResult)
def raise_query(case_id: str, body: QueryCreate,
                store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    query = store.raise_query(case, body.reason, body.recipient, body.check_id)
    return _ok(case, f"{query.query_id} sent to {query.recipient}. The case is held in needs attention.",
               query=query.model_dump())


class QueryAnswer(BaseModel):
    response: str


@router.post("/cases/{case_id}/queries/{query_id}/answer", response_model=ActionResult)
def answer_query(case_id: str, query_id: str, body: QueryAnswer,
                 store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    query = store.close_query(case, query_id, body.response)
    if query is None:
        raise HTTPException(status_code=404, detail=f"{query_id} not found on {case_id}")
    return _ok(case, f"{query.query_id} marked answered.", query=query.model_dump())


# ---------------------------------------------------------------------------
# workflow
# ---------------------------------------------------------------------------

@router.post("/cases/{case_id}/start", response_model=ActionResult)
def start(case_id: str, store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    if case.status is not CaseStatus.RECEIVED:
        raise HTTPException(status_code=400, detail="Only a received case can be released to the pipeline")
    store.start_processing(case)
    return _ok(case, "Entity retrieval, rule evaluation and charges are running.")


@router.post("/cases/{case_id}/assign", response_model=ActionResult)
def assign(case_id: str, store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    store.assign(case, store.session.name)
    return _ok(case, f"{case.case_id} assigned to {store.session.name}.")


class BulkAssign(BaseModel):
    case_ids: list[str]


@router.post("/cases/assign", response_model=ActionResult)
def bulk_assign(body: BulkAssign, store: CaseStore = Depends(get_store)) -> ActionResult:
    done = 0
    last: CollectionCase | None = None
    for cid in body.case_ids:
        case = store.get(cid)
        if case is not None:
            store.assign(case, store.session.name)
            last, done = case, done + 1
    if last is None:
        raise HTTPException(status_code=404, detail="No matching cases")
    return _ok(last, f"{done} case(s) assigned to {store.session.name}.")


@router.post("/cases/{case_id}/validate", response_model=ActionResult)
def validate(case_id: str, body: ValidationRequest,
             store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    if not (body.source_reviewed and body.exceptions_resolved):
        return ActionResult(ok=False, case_id=case.case_id, data=_snapshot(case),
                            message="Confirm both attestations before validating.")
    ok, message, undo_token = store.validate(case, body.maker_note)
    if not ok:
        return ActionResult(ok=False, case_id=case.case_id, data=_snapshot(case), message=message)
    return _ok(case, message, store=store, undo_token=undo_token)


@router.post("/cases/{case_id}/approve", response_model=ActionResult)
def approve(case_id: str, note: dict = Body(default={}),
            store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    ok, message, undo_token = store.approve(case, note.get("note"))
    if not ok:
        raise HTTPException(status_code=400, detail=message)
    return _ok(case, message, undo_token=undo_token)


class ReturnReason(BaseModel):
    reason: str


@router.post("/cases/{case_id}/return", response_model=ActionResult)
def return_case(case_id: str, body: ReturnReason,
                store: CaseStore = Depends(get_store)) -> ActionResult:
    case = _case(store, case_id)
    ok, message, undo_token = store.return_to_maker(case, body.reason)
    if not ok:
        raise HTTPException(status_code=400, detail=message)
    return _ok(case, message, undo_token=undo_token)


class UndoRequest(BaseModel):
    token: str


@router.post("/cases/{case_id}/undo", response_model=ActionResult)
def undo(case_id: str, body: UndoRequest,
         store: CaseStore = Depends(get_store)) -> ActionResult:
    """Reverse a validate, approve or return within the undo window."""
    case = store.undo(body.token)
    if case is None:
        raise HTTPException(
            status_code=410,
            detail="That can no longer be undone. The window has passed, or it was already undone.")
    return _ok(case, f"{case.case_id} is back to {case.status_label.lower()}.")
