from types import SimpleNamespace

from fastapi import FastAPI
from fastapi.testclient import TestClient

from agents.llm_judge import ReviewLoopError
from router import router as router_module


def test_router_log_omits_private_detail_from_sanitized_judge_error(
    monkeypatch, caplog
) -> None:
    app = FastAPI()
    app.include_router(router_module.router)
    client = TestClient(app)
    private_detail = "private judge response detail"

    def raise_sanitized_error(**_kwargs):
        try:
            raise RuntimeError(private_detail)
        except RuntimeError:
            raise ReviewLoopError("LLM review failed at stage 'scope_recommendations'.") from None

    monkeypatch.setattr(router_module, "audit_generation_start", lambda **_k: (object(), object()))
    monkeypatch.setattr(
        router_module,
        "get_inscope_outscope_service",
        lambda: SimpleNamespace(generate_inscope_outscope=raise_sanitized_error),
    )

    with caplog.at_level("ERROR"):
        response = client.post(
            "/generate-inscope-outscope", json={"planNumber": "20587", "userDetails": {}}
        )

    assert response.status_code == 500
    assert private_detail not in caplog.text
