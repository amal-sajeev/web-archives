from utils.document_processor import convert_to_pdf


def test_convert_to_pdf_returns_existing_pdf_unchanged() -> None:
    pdf_content = b"%PDF-1.4\nexisting"

    filename, content = convert_to_pdf("minutes.pdf", pdf_content)

    assert filename == "minutes.pdf"
    assert content == pdf_content


def test_convert_to_pdf_converts_text_file() -> None:
    filename, content = convert_to_pdf("minutes.txt", b"Decision: approve")

    assert filename == "minutes.pdf"
    assert content.startswith(b"%PDF")