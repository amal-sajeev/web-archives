from pathlib import Path
import sys
import json
import logging
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.inscope_outscope_service import InScopeOutScopeService
from agents.llm_judge import SCOPE_REVIEW_RUBRIC_CALLS, SCOPE_REVIEW_PROMPT, ReviewLoopError
from model.response_model import InScopeOutScopeResponse, ScopeReport
from agents.llm_judge.models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
)


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


def test_focused_review_schemas_require_each_requested_criterion():
    for rubric_name, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS:
        response_model = SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
        required_fields = set(response_model.model_json_schema().get("required", []))

        assert required_fields == set(expected_names)
        with pytest.raises(ValidationError):
            response_model.model_validate({})


def test_scope_judge_prompts_cover_boundary_hierarchy_conflicts_and_confidence():
    all_instructions = "\n".join(
        instructions for _name, _criteria, instructions in SCOPE_REVIEW_RUBRIC_CALLS
    )

    assert "Broad Scope Section 2" in all_instructions
    assert "must not add, remove, reclassify, or change a boundary" in all_instructions
    assert "When feedback explicitly differs from Section 2" in all_instructions
    assert "must not be flagged as an extra boundary" in all_instructions
    assert "never recommend using feedback to override PR Broad Scope Section 2" in all_instructions
    assert "confidence_score" in all_instructions
    assert "numeric review score" in SCOPE_REVIEW_PROMPT
    assert "exact plan, control, control-instance, risk, finding, review" in all_instructions
    assert "different instances on both sides" in all_instructions
    assert "bold label form (**Attribute:**)," in all_instructions
    assert "no introductory or closing prose" in all_instructions
    assert "no line breaks, bullets, or header" in all_instructions
    assert "retaining C-101 in scope passes this criterion" in all_instructions
    assert "a moderate score such as 60-79 may be consistent" in all_instructions
    assert "hypothesis, assumption, possible focus" in all_instructions
    assert "no controls are attached or no controls were fetched" in all_instructions
