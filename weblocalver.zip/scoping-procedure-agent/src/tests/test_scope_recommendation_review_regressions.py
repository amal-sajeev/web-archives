import json
import logging
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from agents.llm_judge import SCOPE_REVIEW_RUBRIC_CALLS, ReviewLoopError
from model.response_model import InScopeOutScopeResponse, ScopeReport


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


@pytest.mark.parametrize(
    (
        "rubric_index",
        "criterion_name",
        "affected_fields",
        "review_data",
        "candidate",
        "issue",
        "action",
    ),
    [
        (
            0,
            "scope_boundary_fidelity",
            ["inscope.report"],
            {"preliminary_research": {"Broad Scope Section 2": "In-scope: C-101"}},
            _scope_candidate(inscope_report="Control ID: C-102"),
            "C-101 is omitted from the in-scope report.",
            "Restore C-101 exactly as listed in Section 2.",
        ),
        (
            0,
            "scope_boundary_fidelity",
            ["outscope.report"],
            {"preliminary_research": {"Broad Scope Section 2": "Out of scope: C-101"}},
            _scope_candidate(outscope_report="Control ID: C-101; C-202"),
            "C-202 is not present in the out-of-scope list.",
            "Remove C-202 from the out-of-scope report.",
        ),
        (
            0,
            "scope_boundary_fidelity",
            ["inscope.report"],
            {
                "preliminary_research": {
                    "Broad Scope Direction": {
                        "Section 2: Indicative Scope Boundaries": (
                            "In-scope: Based on dbGRC, no key controls are attached and "
                            "no controls were fetched."
                        ),
                        "Section 3: Scope Validation": (
                            "Hypothesis: IRC-CD-1000035 and IRC-CD-1000027 may be intended "
                            "focus controls; confirm with stakeholders."
                        ),
                    }
                }
            },
            _scope_candidate(
                inscope_report=(
                    "IRC-CD-1000035 and IRC-CD-1000027 are included as assumptions "
                    "pending stakeholder confirmation."
                )
            ),
            "The controls appear only as a Section 3 hypothesis, not as Section 2 boundaries.",
            "Remove both controls from the applied scope and state that Section 2 lists no fetched controls.",
        ),
        (
            1,
            "evidence_identifier_accuracy",
            ["inscope.report"],
            {
                "preliminary_research": {
                    "control": "C-101; instance 7; effective 2025-01-01; status Open"
                }
            },
            _scope_candidate(
                inscope_report="Control C-101, instance 8, effective 2025-02-01, status Closed"
            ),
            "The instance, date, and status differ from the supplied record.",
            "Restore instance 7, effective date 2025-01-01, and status Open.",
        ),
        (
            2,
            "source_hierarchy_conflict_handling",
            ["inscope.report"],
            {
                "preliminary_research": {"Broad Scope Section 2": "C-101 is in scope"},
                "preliminary_research_feedback_summary": {
                    "feedback": "C-101 is out of scope"
                },
            },
            _scope_candidate(inscope_report="C-101 is out of scope"),
            "Feedback conflicts with the authoritative PR boundary.",
            "Retain C-101 in scope and state the feedback discrepancy.",
        ),
        (
            2,
            "source_hierarchy_conflict_handling",
            ["inscope.report"],
            {
                "preliminary_research": {
                    "Broad Scope Section 2": "C-101 is in scope",
                    "Section 3": "C-202 is related",
                }
            },
            _scope_candidate(inscope_report="C-101 and C-202 are in scope"),
            "Secondary PR content adds C-202 to the boundary.",
            "Remove C-202 unless it is listed in Broad Scope Section 2.",
        ),
        (
            0,
            "required_content_format",
            ["inscope.report"],
            {
                "preliminary_research": {
                    "Broad Scope Section 2": "In-scope: Control ID C-101; Control Name Payments"
                }
            },
            _scope_candidate(inscope_report="Control ID: C-101"),
            "The required Control Name attribute is missing.",
            "Add the Control Name value exactly as provided in Section 2.",
        ),
        (
            3,
            "rationale_confidence_alignment",
            ["inscope.rationale", "inscope.confidence_score"],
            {
                "preliminary_research": {
                    "evidence_gaps": "No control-instance evidence or test status"
                }
            },
            _scope_candidate(),
            "The rationale is generic and confidence 90 ignores material evidence gaps.",
            "Explain the evidence supporting this decision and lower confidence to reflect the missing instance and status details.",
        ),
    ],
)
def test_synthetic_scope_regressions_keep_specific_feedback_targeted(
    service_with_mocks,
    rubric_index,
    criterion_name,
    affected_fields,
    review_data,
    candidate,
    issue,
    action,
):
    service, _, structured_llm = service_with_mocks
    responses = _passing_rubric_responses()
    if criterion_name not in responses[rubric_index]:
        pytest.fail(f"Criterion {criterion_name} is not in rubric {rubric_index}")
    responses[rubric_index][criterion_name].update(
        passed=False,
        affected_fields=affected_fields,
        issue=issue,
        action=action,
    )
    structured_llm.invoke.side_effect = responses

    review = service._review_scope_candidate(candidate, review_data)

    failed = next(item for item in review.criteria if item.name == criterion_name)
    assert failed.passed is False
    assert failed.affected_fields == affected_fields
    assert issue in review.feedback
    assert action in review.feedback
    reviewed_prompt = _prompt_text(structured_llm.invoke.call_args_list[rubric_index])
    assert (
        json.dumps(review_data, ensure_ascii=False, indent=2, default=str)
        in reviewed_prompt
    )
    assert (
        json.dumps(
            candidate.model_dump(mode="json"), ensure_ascii=False, indent=2, default=str
        )
        in reviewed_prompt
    )


def test_fail_closed_review_error_does_not_log_judge_exception_content(
    service_with_mocks, monkeypatch, caplog
):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(
        return_value={"preliminary_research": "PR"}
    )
    monkeypatch.setattr(
        service.config, "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY", "fail_closed"
    )
    private_error_detail = "private judge response detail"
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        RuntimeError(private_error_detail),
    ]

    with caplog.at_level(logging.ERROR), pytest.raises(ReviewLoopError) as caught:
        service.generate_inscope_outscope("42")

    assert private_error_detail not in caplog.text
    assert caught.value.__cause__ is None
    assert storage_manager.upload_json.call_count == 0


@pytest.mark.parametrize(
    ("section_two", "mom_action", "candidate"),
    [
        (
            "In-scope: C-101",
            "Add named Key Control C-202 to the review.",
            _scope_candidate(inscope_report="Key Control: C-101; C-202 (MOM-directed scope action)"),
        ),
        (
            "In-scope: C-101",
            "Remove named Key Control C-101 from the review.",
            _scope_candidate(outscope_report="Key Control: C-101 (MOM-directed scope action)"),
        ),
    ],
)
def test_named_explicit_mom_scope_actions_are_reviewed_as_boundary_exceptions(
    service_with_mocks, section_two, mom_action, candidate
):
    service, _, structured_llm = service_with_mocks
    review_data = {
        "preliminary_research": {"Broad Scope Section 2": section_two},
        "meeting_mom_summaries": {"action": mom_action},
    }
    structured_llm.invoke.side_effect = _passing_rubric_responses()

    review = service._review_scope_candidate(candidate, review_data)

    assert review.approved is True
    hierarchy_prompt = _prompt_text(structured_llm.invoke.call_args_list[2])
    assert mom_action in hierarchy_prompt
    assert "authorized exception to the PR baseline" in hierarchy_prompt
