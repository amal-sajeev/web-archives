import importlib

import pytest

from service import pdf_download_service as pdf_service


def test_sanitize_replaces_unsupported_punctuation() -> None:
    value = pdf_service._sanitize(
        "A\u2013B\u2014C\u2018D\u2019E\u201cF\u201dG\u2026H\u2022I\u00a0J"
    )

    assert value == "A-B-C'D'E\"F\"G...H-I J"


def test_escape_and_paragraph_helpers() -> None:
    assert pdf_service._escape("<scope>") == "&lt;scope&gt;"
    assert pdf_service._paragraphs("First\nline\n\nSecond") == (
        "<p>First<br>line</p><p>Second</p>"
    )
    assert pdf_service._paragraphs("   ") == ""


def test_headers_include_plan_number() -> None:
    headers = pdf_service._headers("test_steps", "20587")

    assert headers == {
        "Content-Disposition": 'attachment; filename="test_steps_20587.pdf"',
        "Content-Type": "application/pdf",
    }


def test_simple_report_renderer_handles_wrapped_and_indented_lines() -> None:
    pdf = pdf_service._render_simple_report_pdf(
        "Test Steps",
        "20587",
        [("1. Test Step", "    Field: value\n        - nested point\n        continuation")],
        spacing_after=6,
    )

    assert pdf.startswith(b"%PDF")


def test_legacy_html_helpers_render_sections_and_test_steps() -> None:
    report_html = pdf_service._section_body(
        {
            "sections": [
                {
                    "section_title": "Key Drivers",
                    "key_points": ["Control coverage", "Evidence review"],
                },
                "invalid section",
            ]
        }
    )
    test_steps_html = pdf_service._test_steps_body(
        [
            {
                "objective": "Test the control",
                "evidence": ["Evidence A", "Evidence B"],
            },
            "Free-form step",
        ]
    )

    assert "Key Drivers" in report_html
    assert "- Control coverage" in report_html
    assert "Objective" in test_steps_html
    assert "Evidence A" in test_steps_html
    assert "Free-form step" in test_steps_html


def test_render_pdf_handles_optional_metadata() -> None:
    pdf = pdf_service._render_pdf(
        "Scope Recommendation",
        "20587",
        "Example Plan",
        "<p>In scope content</p>",
    )

    assert pdf.startswith(b"%PDF")


def test_discovery_walkthrough_pdf_contains_report_content() -> None:
    report = {
        "report_title": "Discovery Walkthrough Preparation",
        "sections": [
            {
                "section_title": "Key Scope Drivers",
                "key_points": ["Confirm controls", "Review evidence"],
            },
            {"section_title": "Empty Section", "key_points": []},
            "invalid section",
        ],
    }

    pdf = pdf_service.build_discovery_walkthrough_pdf(report, "20587")
    download_pdf, headers = pdf_service.download_discovery_walkthrough_pdf(
        "20587", report
    )

    assert pdf.startswith(b"%PDF")
    assert download_pdf.startswith(b"%PDF")
    assert headers["Content-Disposition"].endswith(
        'discovery_walkthrough_20587.pdf"'
    )


def test_discovery_walkthrough_pdf_excludes_rationale_and_confidence(monkeypatch) -> None:
    captured = {}

    def capture_report(title, plan_number, lines, spacing_after=3, **_kwargs):
        captured["lines"] = lines
        return b"%PDF"

    monkeypatch.setattr(pdf_service, "_render_simple_report_pdf", capture_report)

    pdf_service.build_discovery_walkthrough_pdf(
        {
            "rationale": "Evidence supports these walkthrough topics.",
            "confidence_score": 85,
        },
        "20587",
    )

    assert not any("rationale" in heading.lower() for heading, _ in captured["lines"])
    assert not any("confidence" in heading.lower() for heading, _ in captured["lines"])


def test_scope_recommendation_pdf_contains_both_sections() -> None:
    pdf = pdf_service.build_scope_recommendation_pdf(
        "In-scope controls",
        "Out-of-scope controls",
        "20587",
    )
    download_pdf, headers = pdf_service.download_scope_recommendation_pdf(
        "20587", "In-scope controls", "Out-of-scope controls"
    )

    assert pdf.startswith(b"%PDF")
    assert download_pdf.startswith(b"%PDF")
    assert headers["Content-Disposition"].endswith(
        'scope_recommendation_20587.pdf"'
    )


def test_scope_recommendation_pdf_includes_scope_rationales(monkeypatch) -> None:
    captured = {}

    def capture_report(title, plan_number, lines, spacing_after=3):
        captured["lines"] = lines
        return b"%PDF"

    monkeypatch.setattr(pdf_service, "_render_simple_report_pdf", capture_report)

    pdf_service.build_scope_recommendation_pdf(
        {
            "report": "In scope report",
            "rationale": "Evidence supports inclusion.",
            "confidence_score": 92,
        },
        {
            "report": "Out of scope report",
            "rationale": "Evidence supports exclusion.",
            "confidence_score": 78,
        },
        "20587",
    )

    assert ("In-Scope Rationale", "Evidence supports inclusion.") in captured["lines"]
    assert ("Out-of-Scope Rationale", "Evidence supports exclusion.") in captured["lines"]
    assert not any("confidence" in heading.lower() for heading, _ in captured["lines"])


def test_test_steps_pdf_handles_mapping_lists_multiline_and_scalar() -> None:
    test_steps = [
        {
            "objective": "Test the control",
            "evidence": ["Evidence A", "Evidence B"],
            "regulatory_obligations": "First point\n- Second point",
        },
        "Free-form test step",
    ]

    pdf = pdf_service.build_test_steps_pdf(test_steps, "20587")
    download_pdf, headers = pdf_service.download_test_steps_pdf("20587", test_steps)

    assert pdf.startswith(b"%PDF")
    assert download_pdf.startswith(b"%PDF")
    assert headers["Content-Disposition"].endswith('test_steps_20587.pdf"')


def test_test_steps_pdf_includes_per_step_rationale(monkeypatch) -> None:
    captured = {}

    def capture_report(title, plan_number, lines, spacing_after=3, **kwargs):
        captured["lines"] = lines
        captured.update(kwargs)
        return b"%PDF"

    monkeypatch.setattr(pdf_service, "_render_simple_report_pdf", capture_report)

    pdf_service.build_test_steps_pdf(
        [
            {
                "test_step": {
                    f"field_{index}": f"value_{index}"
                    for index in range(1, 25)
                },
                "rationale": "This test addresses the documented control risk.",
                "confidence_score": 88,
            }
        ],
        "20587",
    )

    assert all(
        (f"Field {index}", f"    value_{index}") in captured["lines"]
        for index in range(1, 25)
    )
    assert ("Rationale", "This test addresses the documented control risk.") in captured["lines"]
    assert captured["underline_headings"] is True
    assert not any("confidence" in heading.lower() for heading, _ in captured["lines"])


def test_test_steps_pdf_preserves_nested_value_indentation(monkeypatch) -> None:
    captured = {}

    def capture_report(title, plan_number, lines, spacing_after=3, **kwargs):
        captured["lines"] = lines
        return b"%PDF"

    monkeypatch.setattr(pdf_service, "_render_simple_report_pdf", capture_report)

    pdf_service.build_test_steps_pdf(
        [
            {
                "test_step": {
                    "evidence": ["Evidence A", "Evidence B"],
                    "criteria": {"policy": "Clause 1"},
                    "procedure": "First line\nSecond line",
                }
            }
        ],
        "20587",
    )

    assert ("Evidence", "        - Evidence A\n        - Evidence B") in captured["lines"]
    assert ("Criteria", "        policy: Clause 1") in captured["lines"]
    assert ("Procedure", "    First line\n    Second line") in captured["lines"]


def test_simple_report_underlines_rationale_headings(monkeypatch) -> None:
    calls = []

    class FakePDF:
        w = 210
        l_margin = 10
        r_margin = 10

        def __init__(self):
            self.font_styles = []

        def set_auto_page_break(self, **_kwargs):
            pass

        def set_title(self, _title):
            pass

        def add_page(self):
            pass

        def set_font(self, _family, style, _size):
            self.font_styles.append(style)

        def set_text_color(self, *_args):
            pass

        def cell(self, *_args, **_kwargs):
            pass

        def ln(self, *_args):
            pass

        def set_x(self, _x):
            pass

        def multi_cell(self, *_args, **kwargs):
            if kwargs.get("dry_run"):
                return [kwargs["text"]]

        def output(self):
            calls.extend(self.font_styles)
            return bytearray(b"%PDF")

    monkeypatch.setattr(
        pdf_service.importlib,
        "import_module",
        lambda _name: type("FakeFPDFModule", (), {"FPDF": FakePDF}),
    )

    pdf_service._render_simple_report_pdf(
        "Scope Recommendation",
        "20587",
        [("In-Scope Rationale", "Evidence supports inclusion.")],
    )

    assert "BU" in calls


def test_pdf_builders_accept_empty_content() -> None:
    assert pdf_service.build_discovery_walkthrough_pdf({}, "20587").startswith(b"%PDF")
    assert pdf_service.build_test_steps_pdf([], "20587").startswith(b"%PDF")


def test_scoping_document_pdf_builds_with_complex_sections_and_tables() -> None:
    inscope = """
    1. Validate design effectiveness
    - Confirm ownership model
    - Validate evidence standards

    2. Confirm regulatory obligations and dependencies.
    """
    outscope = "Residual risk accepted by governance."
    testing_rows = [
        ("1. Execution Approach", "Walkthrough + Evidence review"),
        ("Planned Publication", "2026-12-15"),
    ]
    plan_rows = [
        ("Plan Item Type", "Mandatory review"),
        ("Plan item Title (incl system ID)", "Payments Controls (20587)"),
        ("Coverage Period", "2026-01-01 - 2026-12-31"),
        ("Execution Approach", "Hybrid"),
        ("Prepared by", "HITL"),
    ]

    pdf = pdf_service.build_scoping_document_pdf(
        inscope=inscope,
        outscope=outscope,
        plan_number="20587",
        testing_approach_rows=testing_rows,
        plan_details_rows=plan_rows,
        plan_name="Payments Controls",
    )

    assert pdf.startswith(b"%PDF")


def test_scoping_document_pdf_download_wrapper_and_empty_rows() -> None:
    pdf, headers = pdf_service.download_scoping_document_pdf(
        plan_number="20587",
        inscope="",
        outscope="",
        testing_approach_rows=[],
        plan_details_rows=[],
    )

    assert pdf.startswith(b"%PDF")
    assert headers["Content-Disposition"].endswith('scoping_document_20587.pdf"')


def test_missing_pdf_dependency_has_actionable_error(monkeypatch) -> None:
    original_import = importlib.import_module

    def raise_for_fpdf(name: str):
        if name == "fpdf":
            raise ModuleNotFoundError("No module named fpdf")
        return original_import(name)

    monkeypatch.setattr(pdf_service.importlib, "import_module", raise_for_fpdf)

    with pytest.raises(RuntimeError, match="Install 'fpdf2'"):
        pdf_service._render_simple_report_pdf("Test Steps", "20587", [])

    with pytest.raises(RuntimeError, match="Install 'fpdf2'"):
        pdf_service._render_pdf("Test Steps", "20587", None, "")
