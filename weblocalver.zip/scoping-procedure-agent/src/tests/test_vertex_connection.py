from service import vertex_service


def test_initialize_gemini_model_refreshes_wif_token_between_requests(monkeypatch) -> None:
    captured = []

    class FakeModel:
        def __init__(self, token):
            self.token = token

        def invoke(self, _message):
            return self.token

        def with_structured_output(self, _schema, **_kwargs):
            return self

    def fake_chat_model(**kwargs):
        captured.append(kwargs)
        return FakeModel(kwargs["api_key"])

    class FakeTokenProvider:
        def __init__(self):
            self.tokens = iter(["first-token", "refreshed-token"])

        @property
        def token(self):
            return next(self.tokens)

    monkeypatch.setattr(vertex_service, "ChatGoogleGenerativeAI", fake_chat_model)
    monkeypatch.setattr(vertex_service, "GoogleOAuthTokenProvider", FakeTokenProvider)
    monkeypatch.setattr(vertex_service, "_configure_certificate_once", lambda: None)

    model = vertex_service.initialize_gemini_model()
    structured_model = model.with_structured_output(dict)

    assert structured_model.invoke("first request") == "first-token"
    assert structured_model.invoke("second request") == "refreshed-token"
    assert [request["api_key"] for request in captured] == [
        "first-token",
        "refreshed-token",
    ]
    assert captured[0]["model"] == vertex_service.Config.MODEL_NAME
    assert captured[0]["base_url"] == vertex_service.AI_ACCESS_LAYER_BASE_URL
    assert captured[0]["temperature"] == vertex_service.Config.GENERATION_CONFIG["temperature"]
