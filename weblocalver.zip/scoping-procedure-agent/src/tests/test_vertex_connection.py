from service import vertex_service
from agent_helper import action_service



def test_initialize_gemini_model_uses_configured_values(monkeypatch) -> None:
    captured = {}

    def fake_chat_model(**kwargs):
        captured.update(kwargs)
        return "model"

    monkeypatch.setattr(vertex_service, "ChatGoogleGenerativeAI", fake_chat_model)

    assert vertex_service.initialize_gemini_model() == "model"
    assert vertex_service.Config.MODEL_NAME == "gemini-3.5-flash"
    assert captured["model"] == vertex_service.Config.MODEL_NAME
    assert captured["project"] == vertex_service.Config.PROJECT_NAME
    assert captured["location"] == vertex_service.Config.PROJECT_LOCATION
    assert captured["temperature"] == vertex_service.Config.GENERATION_CONFIG["temperature"]


def test_initialize_gemini_model_can_disable_client_retries(monkeypatch) -> None:
    captured = {}

    def fake_chat_model(**kwargs):
        captured.update(kwargs)
        return "model"

    monkeypatch.setattr(vertex_service, "ChatGoogleGenerativeAI", fake_chat_model)

    assert vertex_service.initialize_gemini_model(max_retries=0) == "model"
    assert captured["max_retries"] == 0


def test_ai_action_metadata_uses_configured_default_model(monkeypatch) -> None:
    monkeypatch.delenv("GCP_MODEL_NAME", raising=False)
    monkeypatch.delenv("model_name", raising=False)
    captured = {}
    monkeypatch.setattr(
        action_service,
        "call_to_action_service",
        lambda _card, data: captured.update(data),
    )

    action_service.construct_ai_actor_record({})

    assert captured["AI_Model_Name"] == "gemini-3.5-flash"
    assert captured["AI_Model_Version"] == "3.5-flash"
