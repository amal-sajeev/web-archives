from service import vertex_service



def test_initialize_gemini_model_uses_configured_values(monkeypatch) -> None:
    captured = {}

    def fake_chat_model(**kwargs):
        captured.update(kwargs)
        return "model"

    monkeypatch.setattr(vertex_service, "ChatGoogleGenerativeAI", fake_chat_model)

    assert vertex_service.initialize_gemini_model() == "model"
    assert captured["model"] == vertex_service.Config.MODEL_NAME
    assert captured["project"] == vertex_service.Config.PROJECT_NAME
    assert captured["location"] == vertex_service.Config.PROJECT_LOCATION
    assert captured["temperature"] == vertex_service.Config.GENERATION_CONFIG["temperature"]
