from service import vertex_service


def test_initialize_gemini_model_omits_unset_generation_options(monkeypatch) -> None:
    captured = []

    class FakeModel:
        def __init__(self, token):
            self.token = token

        def invoke(self, _message):
            return self.token

        def with_structured_output(self, _schema, **_kwargs):
            return self

    def fake_chat_model(**kwargs):
        captured.append(kwargs)
        return FakeModel(kwargs["api_key"])

    class FakeTokenProvider:
        @property
        def token(self):
            return "first-token"

    monkeypatch.setattr(
        vertex_service, "TokenRefreshingChatGoogleGenerativeAI", fake_chat_model
    )
    monkeypatch.setattr(vertex_service, "GoogleOAuthTokenProvider", FakeTokenProvider)
    monkeypatch.setattr(vertex_service, "_configure_certificate_once", lambda: None)
    monkeypatch.setattr(
        vertex_service.Config,
        "GENERATION_CONFIG",
        {"temperature": None, "top_p": 0.5, "top_k": None},
    )
    monkeypatch.setattr(vertex_service.Config, "THINKING_LEVEL", "high")

    model = vertex_service.initialize_gemini_model()
    assert model.invoke("request") == "first-token"
    assert len(captured) == 1
    assert captured[0]["api_key"] == "first-token"
    assert captured[0]["model"] == vertex_service.Config.MODEL_NAME
    assert captured[0]["base_url"] == vertex_service.AI_ACCESS_LAYER_BASE_URL
    assert "temperature" not in captured[0]
    assert captured[0]["top_p"] == 0.5
    assert "top_k" not in captured[0]
    assert captured[0]["thinking_level"] == "high"
    assert isinstance(model._token_provider, FakeTokenProvider)


def test_refreshing_model_rebuilds_client_only_when_token_changes() -> None:
    class FakeTokenProvider:
        token = "first-token"

    model = vertex_service.TokenRefreshingChatGoogleGenerativeAI(
        model="gemini-2.5-flash", api_key="first-token"
    )
    model._token_provider = FakeTokenProvider()
    original_client = model.client

    model._refresh_token()
    assert model.client is original_client

    FakeTokenProvider.token = "second-token"
    model._refresh_token()

    assert model.google_api_key.get_secret_value() == "second-token"
    assert model.client is not original_client


def test_refreshing_model_handles_library_without_client_cleanup() -> None:
    class FakeTokenProvider:
        token = "first-token"

    model = vertex_service.TokenRefreshingChatGoogleGenerativeAI(
        model="gemini-2.5-flash", api_key="first-token"
    )
    model._token_provider = FakeTokenProvider()
    # Older pinned versions never set this private attribute.
    (model.__pydantic_private__ or {}).pop("_client_cleanup", None)
    original_client = model.client

    FakeTokenProvider.token = "second-token"
    model._refresh_token()

    assert model.google_api_key.get_secret_value() == "second-token"
    assert model.client is not original_client
    assert model._previous_client[0] is original_client


def test_refreshing_model_refreshes_before_generate(monkeypatch) -> None:
    calls = []
    model = vertex_service.TokenRefreshingChatGoogleGenerativeAI(
        model="gemini-2.5-flash", api_key="first-token"
    )
    monkeypatch.setattr(model, "_refresh_token", lambda: calls.append("refresh"))
    monkeypatch.setattr(
        vertex_service.ChatGoogleGenerativeAI,
        "_generate",
        lambda self, *_args, **_kwargs: calls.append("generate") or "result",
    )

    assert model._generate([]) == "result"
    assert calls == ["refresh", "generate"]

