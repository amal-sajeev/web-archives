"""Unit tests for plan details retrieval and payload normalization helpers."""

import pytest

from service import plan_details_service as plan_details_module


class _FakeStorageManager:
    def __init__(self, project_name: str, bucket_name: str):
        self.project_name = project_name
        self.bucket_name = bucket_name
        self.downloaded_path: str | None = None
        self.payload = None

    def download_json(self, blob_path: str):
        self.downloaded_path = blob_path
        return self.payload


def test_get_plan_details_reads_expected_blob_path(monkeypatch) -> None:
    monkeypatch.setattr(plan_details_module, "StorageManager", _FakeStorageManager)

    service = plan_details_module.PlanDetailsService()
    service.storage_manager.payload = {"planName": "Sample Plan"}

    result = service.get_plan_details("20587")

    assert result == {"planName": "Sample Plan"}
    assert service.storage_manager.downloaded_path == (
        "dbaware_review_20587/inbound-data/dbaware/plan_details.json"
    )


def test_get_plan_details_raises_file_not_found_when_payload_missing(monkeypatch) -> None:
    monkeypatch.setattr(plan_details_module, "StorageManager", _FakeStorageManager)

    service = plan_details_module.PlanDetailsService()
    service.storage_manager.payload = {}

    with pytest.raises(FileNotFoundError, match="planNumber=20587"):
        service.get_plan_details("20587")


def test_build_testing_approach_rows_handles_mixed_payloads() -> None:
    rows = plan_details_module._build_testing_approach_rows(
        [
            {
                "test_step": {
                    "1. Planned Publication": "2026-10-10",
                    "Evidence": ["A", "B"],
                    "None Value": None,
                }
            },
            {"test_step": "invalid"},
            "skip",
        ]
    )

    assert rows == [
        ("Planned Publication Date", "2026-10-10"),
        ("Evidence", "A\nB"),
        ("None Value", ""),
    ]


@pytest.mark.parametrize(
    "payload, expected",
    [
        ({"plan_name": "Plan A"}, "Plan A"),
        ({"planDetails": {"planTitle": "Plan B"}}, "Plan B"),
        ({"plan": {"name": "Plan C"}}, "Plan C"),
        ({"plan_name": "  "}, None),
        (None, None),
    ],
)
def test_extract_plan_name(payload, expected) -> None:
    assert plan_details_module._extract_plan_name(payload) == expected


def test_normalize_plan_details_payload_for_list_and_nested_dicts() -> None:
    assert plan_details_module._normalize_plan_details_payload(["x", {"k": "v"}]) == {"k": "v"}
    assert plan_details_module._normalize_plan_details_payload(["x", "y"]) == {}
    assert plan_details_module._normalize_plan_details_payload({"plan_details": {"a": 1}}) == {"a": 1}
    assert plan_details_module._normalize_plan_details_payload(None) == {}


def test_stringify_plan_detail_value_and_first_non_empty_lookup() -> None:
    payload = {
        "alias_1": "   ",
        "alias_2": ["A", "", None, "B"],
        "alias_3": {"k1": "v1", "k2": ""},
    }

    assert plan_details_module._stringify_plan_detail_value(payload["alias_2"]) == "A; B"
    assert plan_details_module._stringify_plan_detail_value(payload["alias_3"]) == "k1: v1"
    assert (
        plan_details_module._first_non_empty_plan_detail_value(
            payload,
            ("alias_1", "alias_2", "alias_3"),
        )
        == "A; B"
    )


def test_build_coverage_period_value_and_assessment_units_fallbacks() -> None:
    source_with_range = {
        "Review Coverage Period Start Date": "2026-01-01",
        "Review Coverage Period End Date": "2026-12-31",
        "AU Aggregation Point 1": "AP-1",
        "AU Aggregation Point 2": "AP-1",
        "AU Aggregation Point 3": "AP-3",
    }
    source_fallback = {
        "coverage_period": "FY26",
        "Assessment Unit(s)": "Core AU",
    }

    assert (
        plan_details_module._build_coverage_period_value(source_with_range)
        == "2026-01-01 - 2026-12-31"
    )
    assert plan_details_module._build_coverage_period_value(source_fallback) == "FY26"
    assert plan_details_module._build_assessment_units_value(source_with_range) == "AP-1, AP-3"
    assert plan_details_module._build_assessment_units_value(source_fallback) == "Core AU"


def test_build_plan_details_rows_builds_expected_defaults_and_transforms() -> None:
    payload = {
        "current_data": {
            "Plan Item Type": "Mandatory",
            "Plan Item Title": "Payments Controls",
            "review_coverage_period_start_date": "2026-01-01",
            "review_coverage_period_end_date": "2026-03-31",
            "planned_publication": "2026-05-01",
            "AU Aggregation Point A": "AP-A",
            "UoT LE": "DB AG",
            "UoT Countries": "DE",
            "UoT Core Process": "",
            "Mode of Execution": "Hybrid",
            "Review Lead": "Owner",
            "Coordinating Team Lead": "TL",
            "Lead Regional/Functional Head": "RFH",
        }
    }

    rows = plan_details_module._build_plan_details_rows(payload, default_system_id="20587")
    rows_map = dict(rows)

    assert rows_map["Plan Item Type"] == "Mandatory"
    assert rows_map["Plan item Title (incl system ID)"] == "Payments Controls (20587)"
    assert rows_map["Coverage Period"] == "2026-01-01 - 2026-03-31"
    assert rows_map["Planned Publication Date"] == "2026-05-01"
    assert rows_map["Assessment Units"] == "AP-A"
    assert rows_map["Legal Entity(ies)"] == "DB AG"
    assert rows_map["Geographical Coverage"] == "DE"
    assert rows_map["Core Processes"] == "NA"
    assert rows_map["Execution Approach"] == "Hybrid"
    assert rows_map["Prepared by"] == "HITL"


def test_build_plan_details_rows_uses_default_system_id_when_title_missing() -> None:
    rows = plan_details_module._build_plan_details_rows({}, default_system_id="20587")
    rows_map = dict(rows)

    assert rows_map["Plan item Title (incl system ID)"] == "20587"
