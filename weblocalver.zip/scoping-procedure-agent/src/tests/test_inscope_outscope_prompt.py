from config.prompts import INSCOPE_OUTSCOPE_PROMPT


def test_prompt_formats_with_plan_number_and_review_data() -> None:
    rendered = INSCOPE_OUTSCOPE_PROMPT.format(
        plan_number="20587",
        preliminary_research_data="PR DATA",
        meeting_mom_summaries="MOM DATA",
    )

    assert "Plan Number: 20587" in rendered
    assert "Preliminary Research Report:\nPR DATA" in rendered
    assert "Meeting Notes (MOM) Summary:\nMOM DATA" in rendered


def test_prompt_requires_bold_keys_and_spacing() -> None:
    assert "Report formatting rules" in INSCOPE_OUTSCOPE_PROMPT
    assert "**Regulatory Requirement:**" in INSCOPE_OUTSCOPE_PROMPT
    assert "blank line" in INSCOPE_OUTSCOPE_PROMPT
    assert "numbered list" in INSCOPE_OUTSCOPE_PROMPT


def test_prompt_lists_expected_in_scope_attributes() -> None:
    for label in (
        "Regulatory Requirement",
        "Review Type",
        "Review Period",
        "Jurisdiction & Legal Entity",
        "Assessment Units",
        "Risk Coverage",
        "Core Processes",
        "Regulatory Finding / Remediation",
        "Key Control",
    ):
        assert label in INSCOPE_OUTSCOPE_PROMPT


def test_prompt_distinguishes_moms_and_applies_explicit_scope_actions() -> None:
    assert "Meeting Notes (MOM) Summary (`meeting_mom_summaries`) contains consolidated summaries" in INSCOPE_OUTSCOPE_PROMPT
    assert "MUST place that item in `inscope`" in INSCOPE_OUTSCOPE_PROMPT
    assert "MUST place that item in `outscope`" in INSCOPE_OUTSCOPE_PROMPT
    assert "refer to the summarised meeting notes" in INSCOPE_OUTSCOPE_PROMPT
    assert "Reflect relevant validation or follow-up actions" in INSCOPE_OUTSCOPE_PROMPT
