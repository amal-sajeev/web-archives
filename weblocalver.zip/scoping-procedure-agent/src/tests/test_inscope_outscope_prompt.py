from config.prompts import INSCOPE_OUTSCOPE_PROMPT


def test_prompt_formats_with_plan_number_and_review_data() -> None:
    rendered = INSCOPE_OUTSCOPE_PROMPT.format(plan_number="20587", review_data="DATA")

    assert "Plan Number: 20587" in rendered
    assert rendered.rstrip().endswith("DATA")


def test_prompt_requires_bold_keys_and_spacing() -> None:
    assert "Report formatting rules" in INSCOPE_OUTSCOPE_PROMPT
    assert "**Regulatory Requirement:**" in INSCOPE_OUTSCOPE_PROMPT
    assert "blank line" in INSCOPE_OUTSCOPE_PROMPT
    assert "numbered list" in INSCOPE_OUTSCOPE_PROMPT


def test_prompt_lists_expected_in_scope_attributes() -> None:
    for label in (
        "Regulatory Requirement",
        "Review Type",
        "Review Period",
        "Jurisdiction & Legal Entity",
        "Assessment Units",
        "Risk Coverage",
        "Core Processes",
        "Regulatory Finding / Remediation",
        "Key Control",
    ):
        assert label in INSCOPE_OUTSCOPE_PROMPT
