import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from agents.llm_judge import (
    SCOPE_REVIEW_PROMPT,
    SCOPE_REVIEW_RUBRIC_CALLS,
    ReviewLoopError,
)
from agents.llm_judge.models import (
    ScopeRecommendationReview,
)
from model.response_model import InScopeOutScopeResponse, ScopeReport


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


@pytest.mark.parametrize(
    ("failure_policy", "raises", "expected_uploads"),
    [("fail_open", False, 2), ("fail_closed", True, 0)],
)
def test_judge_failure_policy_controls_whether_draft_is_persisted(
    service_with_mocks,
    monkeypatch,
    failure_policy,
    raises,
    expected_uploads,
):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(
        return_value={"preliminary_research": "PR"}
    )
    monkeypatch.setattr(
        service.config, "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY", failure_policy
    )
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        RuntimeError("judge unavailable"),
    ]

    if raises:
        with pytest.raises(ReviewLoopError, match="LLM review failed"):
            service.generate_inscope_outscope("42")
    else:
        result = service.generate_inscope_outscope("42")
        assert result["inscope"]["report"] == "In paragraph"

    assert storage_manager.upload_json.call_count == expected_uploads


@pytest.mark.parametrize(
    ("failure_policy", "raises", "expected_uploads"),
    [("fail_open", False, 2), ("fail_closed", True, 0)],
)
def test_revision_failure_policy_controls_whether_original_draft_is_persisted(
    service_with_mocks,
    monkeypatch,
    failure_policy,
    raises,
    expected_uploads,
):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(
        return_value={"preliminary_research": "PR"}
    )
    monkeypatch.setattr(
        service.config, "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY", failure_policy
    )
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        RuntimeError("revision unavailable"),
    ]

    if raises:
        with pytest.raises(ReviewLoopError, match="LLM revision failed"):
            service.generate_inscope_outscope("42")
    else:
        result = service.generate_inscope_outscope("42")
        assert result["inscope"]["report"] == "In paragraph"

    assert storage_manager.upload_json.call_count == expected_uploads


def test_missing_broad_scope_input_is_still_reviewed_and_generation_continues(
    service_with_mocks, monkeypatch
):
    service, storage_manager, structured_llm = service_with_mocks
    available_data = {
        "preliminary_research": None,
        "preliminary_research_feedback_summary": None,
    }
    service.gather_all_review_data = MagicMock(return_value=available_data)
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS", 0)
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
    ]

    result = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "In paragraph"
    boundary_prompt = _prompt_text(structured_llm.invoke.call_args_list[1])
    assert "cannot be identified" in SCOPE_REVIEW_PROMPT
    assert '"preliminary_research": null' in boundary_prompt
    assert storage_manager.upload_json.call_count == 2


def test_review_model_aggregates_all_five_criteria_and_feedback_targets_fields():
    criteria = []
    for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS:
        if "scope_boundary_fidelity" in expected_names:
            criteria.extend(
                [
                    {
                        "name": "scope_boundary_fidelity",
                        "passed": False,
                        "affected_fields": ["inscope.report"],
                        "issue": "An item is missing.",
                        "action": "Restore the item from PR Section 2.",
                    },
                    {
                        "name": "required_content_format",
                        "passed": True,
                        "affected_fields": [],
                        "issue": "",
                        "action": "",
                    },
                ]
            )
        else:
            name = next(iter(expected_names))
            criteria.append(
                {
                    "name": name,
                    "passed": True,
                    "affected_fields": [],
                    "issue": "",
                    "action": "",
                }
            )

    review = ScopeRecommendationReview.model_validate({"criteria": criteria})

    assert review.approved is False
    assert "[scope_boundary_fidelity]" in review.feedback
    assert "inscope.report" in review.feedback
    assert len(review.criteria) == 5
