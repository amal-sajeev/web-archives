"""Unit tests for persistor.review_research_recommendation_repository."""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

MAIN_DIR = Path(__file__).resolve().parents[1] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from persistor import review_research_recommendation_repository as repo
from persistor.review_research_recommendation_repository import (
    ReviewResearchRecommendationORM,
    persist_review_research_recommendation,
    update_review_research_recommendation,
)


class TestOrmModel:
    def test_table_and_schema(self) -> None:
        assert ReviewResearchRecommendationORM.__tablename__ == "review_research_recommendation"
        assert ReviewResearchRecommendationORM.__table_args__["schema"] == "dbaware_scoping"

    def test_metadata_column_name_mapping(self) -> None:
        # Attribute is metadata_ but the physical column is "metadata".
        column = ReviewResearchRecommendationORM.__table__.c.metadata
        assert column.name == "metadata"

    def test_report_type_length(self) -> None:
        assert ReviewResearchRecommendationORM.__table__.c.report_type.type.length == 30

    def test_primary_key_is_review_rr_id(self) -> None:
        pk_cols = [c.name for c in ReviewResearchRecommendationORM.__table__.primary_key.columns]
        assert pk_cols == ["review_rr_id"]


class _PydanticV2Like:
    """Stub mimicking a Pydantic v2 model (has model_dump)."""

    def __init__(self, data):
        self._data = data

    def model_dump(self, mode=None):  # noqa: ARG002 - signature parity
        return self._data


class _PydanticV1Like:
    """Stub mimicking a Pydantic v1 model (has dict but no model_dump)."""

    def __init__(self, data):
        self._data = data

    def dict(self):
        return self._data


class TestToJsonable:
    def test_none_passthrough(self) -> None:
        assert repo._to_jsonable(None) is None

    def test_primitives_passthrough(self) -> None:
        assert repo._to_jsonable("s") == "s"
        assert repo._to_jsonable(5) == 5
        assert repo._to_jsonable(True) is True

    def test_pydantic_v2_model(self) -> None:
        obj = _PydanticV2Like({"plan_number": "20587"})
        assert repo._to_jsonable(obj) == {"plan_number": "20587"}

    def test_pydantic_v1_model(self) -> None:
        obj = _PydanticV1Like({"plan_number": "20587"})
        assert repo._to_jsonable(obj) == {"plan_number": "20587"}

    def test_nested_dict_and_list_of_models(self) -> None:
        obj = {
            "reports": [_PydanticV2Like({"title": "A"}), _PydanticV1Like({"title": "B"})],
            "meta": _PydanticV2Like({"ok": True}),
        }
        assert repo._to_jsonable(obj) == {
            "reports": [{"title": "A"}, {"title": "B"}],
            "meta": {"ok": True},
        }


def _mock_session_factory():
    """Return (session_mock, assigned-id setter) that simulates refresh assigning a PK."""
    session = MagicMock()

    def _refresh(row):
        row.review_rr_id = 999

    session.refresh.side_effect = _refresh
    return session


class TestPersist:
    def test_persists_and_returns_generated_id(self) -> None:
        session = _mock_session_factory()
        with patch.object(repo, "get_session", return_value=session):
            review_rr_id = persist_review_research_recommendation(
                review_scope_instance_id="55",
                metadata={"k": "v"},
                report_type="PRELIMINARY_RESEARCH",
                created_by="jdoe",
                remarks="note",
            )

        assert review_rr_id == 999
        session.add.assert_called_once()
        session.commit.assert_called_once()
        session.refresh.assert_called_once()
        session.close.assert_called_once()

        row = session.add.call_args[0][0]
        assert isinstance(row, ReviewResearchRecommendationORM)
        assert row.review_scope_instance_id == "55"
        assert row.metadata_ == {"k": "v"}
        assert row.report_type == "PRELIMINARY_RESEARCH"
        assert row.created_by == "jdoe"
        assert row.remarks == "note"
        assert row.created_on is not None

    def test_serializes_pydantic_metadata(self) -> None:
        session = _mock_session_factory()
        doc = _PydanticV2Like({"plan_number": "20587", "analysis_report": {"x": 1}})
        with patch.object(repo, "get_session", return_value=session):
            persist_review_research_recommendation(
                review_scope_instance_id="55",
                metadata=doc,
                created_by="jdoe",
            )

        row = session.add.call_args[0][0]
        assert row.metadata_ == {"plan_number": "20587", "analysis_report": {"x": 1}}

    def test_defaults_are_optional(self) -> None:
        session = _mock_session_factory()
        with patch.object(repo, "get_session", return_value=session):
            review_rr_id = persist_review_research_recommendation()

        assert review_rr_id == 999
        row = session.add.call_args[0][0]
        assert row.review_scope_instance_id is None
        assert row.metadata_ is None
        assert row.report_type is None
        assert row.created_by is None
        assert row.remarks is None

    def test_rolls_back_and_closes_on_error(self) -> None:
        session = MagicMock()
        session.commit.side_effect = RuntimeError("db down")
        with patch.object(repo, "get_session", return_value=session):
            with pytest.raises(RuntimeError, match="db down"):
                persist_review_research_recommendation(created_by="jdoe")

        session.rollback.assert_called_once()
        session.close.assert_called_once()


def _mock_update_session(row):
    """Return a session mock whose query(...).filter(...).order_by(...).first() yields ``row``."""
    session = MagicMock()
    query = session.query.return_value
    query.filter.return_value.order_by.return_value.first.return_value = row
    return session


class TestUpdate:
    def test_updates_latest_row_and_returns_id(self) -> None:
        row = ReviewResearchRecommendationORM(review_scope_instance_id="55")
        row.review_rr_id = 999
        session = _mock_update_session(row)

        with patch.object(repo, "get_session", return_value=session):
            review_rr_id = update_review_research_recommendation(
                review_scope_instance_id="55",
                metadata={"k": "new"},
                updated_by="jdoe",
            )

        assert review_rr_id == 999
        assert row.metadata_ == {"k": "new"}
        assert row.updated_by == "jdoe"
        assert row.updated_on is not None
        session.commit.assert_called_once()
        session.refresh.assert_called_once_with(row)
        session.close.assert_called_once()

    def test_serializes_pydantic_metadata_on_update(self) -> None:
        row = ReviewResearchRecommendationORM(review_scope_instance_id="55")
        row.review_rr_id = 999
        session = _mock_update_session(row)
        doc = _PydanticV2Like({"plan_number": "20587"})

        with patch.object(repo, "get_session", return_value=session):
            review_rr_id = update_review_research_recommendation(
                review_scope_instance_id="55",
                metadata=doc,
                updated_by="jdoe",
            )

        assert review_rr_id == 999
        assert row.metadata_ == {"plan_number": "20587"}

    def test_does_not_overwrite_metadata_when_none(self) -> None:
        row = ReviewResearchRecommendationORM(review_scope_instance_id="55")
        row.review_rr_id = 999
        row.metadata_ = {"existing": True}
        session = _mock_update_session(row)

        with patch.object(repo, "get_session", return_value=session):
            review_rr_id = update_review_research_recommendation(
                review_scope_instance_id="55",
                updated_by="jdoe",
            )

        assert review_rr_id == 999
        # metadata left untouched because None was passed.
        assert row.metadata_ == {"existing": True}
        assert row.updated_by == "jdoe"
        assert row.updated_on is not None

    def test_returns_none_when_no_matching_row(self) -> None:
        session = _mock_update_session(None)

        with patch.object(repo, "get_session", return_value=session):
            review_rr_id = update_review_research_recommendation(
                review_scope_instance_id="12345",
                metadata={"k": "v"},
                updated_by="jdoe",
            )

        assert review_rr_id is None
        session.commit.assert_not_called()
        session.refresh.assert_not_called()
        session.close.assert_called_once()

    def test_rolls_back_and_closes_on_error(self) -> None:
        row = ReviewResearchRecommendationORM(review_scope_instance_id="55")
        row.review_rr_id = 999
        session = _mock_update_session(row)
        session.commit.side_effect = RuntimeError("db down")

        with patch.object(repo, "get_session", return_value=session):
            with pytest.raises(RuntimeError, match="db down"):
                update_review_research_recommendation(
                    review_scope_instance_id="55",
                    metadata={"k": "v"},
                    updated_by="jdoe",
                )

        session.rollback.assert_called_once()
        session.close.assert_called_once()
