from model.request_model import ScopingDocumentContent, ScopingDocumentRow
from service.scoping_document_service import ScopingDocumentService


def test_editor_html_contains_document_sections_and_editable_cells() -> None:
    document = ScopingDocumentContent(
        plan_name="GBSA Review",
        plan_details_rows=[ScopingDocumentRow(key="Plan Number", value="20440")],
        inscope="**Regulatory Requirement:** GBSA HFT",
        outscope="Retired control instance",
        testing_approach_rows=[ScopingDocumentRow(key="Step 1", value="Review report")],
    )

    rendered = ScopingDocumentService.render_editor_html(
        ScopingDocumentService.__new__(ScopingDocumentService), "20440", document
    )

    assert "GBSA Review" in rendered
    assert "A) Scope" in rendered
    assert "B) Testing Approach" in rendered
    assert "data-path=\"inscope\"" in rendered
    assert "data-path=\"testing_approach_rows.0.value\"" in rendered
    assert "<strong>Regulatory Requirement:</strong> GBSA HFT" in rendered
    assert "scoping-document:download" in rendered
    assert "scoping-document:save" in rendered
    assert "fetch(" not in rendered
    assert "trigger-scoping-master" not in rendered
    assert ".brand { position: fixed; top: -12mm" in rendered
    assert ".footer { position: fixed; left: 8mm; right: 8mm; bottom: -13mm;" in rendered
    assert "content: counter(page)" in rendered
    assert ".footer { position: static" in rendered


def test_editor_html_escapes_document_values() -> None:
    document = ScopingDocumentContent(
        inscope='<script>alert("xss")</script>',
    )

    rendered = ScopingDocumentService.render_editor_html(
        ScopingDocumentService.__new__(ScopingDocumentService), "20440", document
    )

    assert "<script>alert(\"xss\")</script>" not in rendered
    assert "&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;" in rendered


def test_editor_html_locks_keys_and_edits_values_in_place() -> None:
    document = ScopingDocumentContent(
        plan_details_rows=[ScopingDocumentRow(key="Plan Item Type", value="C&AFC")],
        testing_approach_rows=[ScopingDocumentRow(key="Step 1", value="Review")],
    )

    rendered = ScopingDocumentService.render_editor_html(
        ScopingDocumentService.__new__(ScopingDocumentService), "20440", document
    )

    assert 'data-path="plan_details_rows.0.value"' in rendered
    assert 'data-path="testing_approach_rows.0.value"' in rendered
    assert "plan_details_rows.0.key" not in rendered
    assert "testing_approach_rows.0.key" not in rendered
    assert "<textarea" not in rendered


class _FakeStorage:
    def __init__(self, stored):
        self.stored = stored
        self.uploads = []

    def download_json(self, path):
        return self.stored

    def upload_json(self, path, data):
        self.uploads.append(data)
        return f"gs://bucket/{path}"


def _document(key: str = "Plan Item Type", value: str = "A") -> ScopingDocumentContent:
    return ScopingDocumentContent(
        plan_details_rows=[ScopingDocumentRow(key=key, value=value)],
        testing_approach_rows=[ScopingDocumentRow(key="Step 1", value="Review")],
    )


def test_save_document_rejects_changed_keys() -> None:
    storage = _FakeStorage({"document": _document().model_dump()})
    service = ScopingDocumentService(storage_manager=storage)

    try:
        service.save_document("20440", _document(key="Renamed"))
    except ValueError as error:
        assert "locked" in str(error)
    else:
        raise AssertionError("changed keys should be rejected")
    assert storage.uploads == []


def test_save_document_allows_changed_values() -> None:
    storage = _FakeStorage({"document": _document().model_dump()})
    service = ScopingDocumentService(storage_manager=storage)

    service.save_document("20440", _document(value="B"))

    assert storage.uploads[0]["document"]["plan_details_rows"][0]["value"] == "B"