"""Opt-in Gemini calibration test for the real scope recommendation judge."""

import os
import sys
import json
from pathlib import Path

import pytest
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[3]
load_dotenv(ROOT / ".misenv")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))
sys.path.insert(0, str(ROOT / "shared"))

RUN_LIVE_TESTS = (
    os.getenv("RUN_LIVE_SCOPE_JUDGE_TESTS", "").strip().lower() in {"1", "true", "yes"}
    and bool(os.getenv("GOOGLE_API_KEY"))
)


def _review_data():
    return {
        "planNumber": "42",
        "preliminary_research_data": {
            "preliminary_research": {
                "Broad Scope": {
                    "Section 2: Indicative Scope Boundaries": {
                        "In-scope": {
                            "Regulatory Requirement": "Annual Payment Oversight Review",
                            "Review Type": "Mandatory plan-year review",
                            "Review Period": "1 January 2025 - 31 December 2025",
                            "Jurisdiction & Legal Entity": "United States | Example Bank",
                            "Assessment Units": "Payments US",
                            "Risk Coverage": "R-17 - Wire Fraud",
                            "Key Control": (
                                "C-101 - Payment Approval; instance CI-101-US; AU Payments US; "
                                "risk R-17; monthly; effective 1 January 2025 - 31 December "
                                "2025; status Active."
                            ),
                        },
                        "Out of scope": {
                            "Key Control": (
                                "C-202 - Reconciliation; instance CI-202-EU; AU Corporate Ops EU; "
                                "risk R-90; monthly; effective 1 January 2025 - 31 December "
                                "2025; status Open; excluded due to open Group Audit finding "
                                "F-88 and ongoing remediation."
                            ),
                        },
                    },
                    "Section 3: Related Research": "C-999 is related context only.",
                }
            },
            "preliminary_research_feedback_summary": {
                "feedback": "Stakeholders say C-101 should be out of scope."
            },
        },
    }


def _candidate(*, corrected: bool):
    from model.response_model import InScopeOutScopeResponse, ScopeReport

    if corrected:
        inscope_report = (
            "**Regulatory Requirement:** Annual Payment Oversight Review\n\n"
            "**Review Type:** Mandatory plan-year review\n\n"
            "**Review Period:** 1 January 2025 - 31 December 2025\n\n"
            "**Jurisdiction & Legal Entity:** United States | Example Bank\n\n"
            "**Assessment Units:** Payments US\n\n"
            "**Risk Coverage:** R-17 - Wire Fraud\n\n"
            "**Key Control:**\n"
            "    1. C-101 - Payment Approval (PR Section 2 places C-101 in scope; stakeholder "
            "feedback says out of scope; retain the PR boundary pending confirmation)\n"
            "        **Control Instance ID:** CI-101-US\n"
            "        **Assessment Unit:** Payments US\n"
            "        **Risk Type:** R-17\n"
            "        **Control Frequency:** Monthly\n"
            "        **Effective Dates:** 1 January 2025 - 31 December 2025\n"
            "        **Status:** Active"
        )
        inscope_rationale = (
            "C-101 supports the documented R-17 Wire Fraud coverage for Payments US, and its "
            "CI-101-US instance is active during the review period. Stakeholder feedback "
            "conflicts with PR Section 2, so the PR boundary is retained pending confirmation."
        )
        inscope_confidence = 70
        outscope_report = (
            "**Key Control:**\n"
            "    1. C-202 - Reconciliation\n"
            "        **Control Instance ID:** CI-202-EU\n"
            "        **Assessment Unit:** Corporate Ops EU\n"
            "        **Risk Type:** R-90\n"
            "        **Control Frequency:** Monthly\n"
            "        **Effective Dates:** 1 January 2025 - 31 December 2025\n"
            "        **Status:** Open\n"
            "        **Exclusion Basis:** Open Group Audit finding F-88 and ongoing remediation"
        )
        outscope_rationale = (
            "C-202 is excluded because the PR identifies open Group Audit finding F-88 and "
            "ongoing remediation for its CI-202-EU instance. Those conditions support "
            "excluding this control during the review period."
        )
        outscope_confidence = 85
    else:
        inscope_report = (
            "**Assessment Units:** Global Payments\n\n"
            "**Risk Coverage:** R-71 - Card Fraud\n\n"
            "**Key Control:**\n"
            "    1. C-101 - Payment Approval\n"
            "        **Control Instance ID:** CI-101-EU\n"
            "        **Effective Dates:** 2 January 2025 - 31 December 2025\n"
            "        **Status:** Inactive\n"
            "    2. C-999 - Related processing control"
        )
        inscope_rationale = "Scope reflects current management priorities."
        inscope_confidence = 98
        outscope_report = "**Key Control:**\n    1. C-101 - Payment Approval"
        outscope_rationale = "These controls are not material to the review."
        outscope_confidence = 97

    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale=inscope_rationale,
            confidence_score=inscope_confidence,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale=outscope_rationale,
            confidence_score=outscope_confidence,
        ),
    )


def _captured_case(plan_number: str):
    """Load the exact review input and generated response recorded in scripts/loggo.log."""
    from model.response_model import InScopeOutScopeResponse

    log_text = (ROOT / "scripts" / "loggo.log").read_text(encoding="utf-16")
    input_marker = (
        f"--- [INPUT] Preliminary Research & User Feedback Data for Plan {plan_number} ---"
    )
    input_start = log_text.find(input_marker)
    if input_start < 0:
        raise AssertionError(f"Captured input for plan {plan_number} was not found")
    input_start += len(input_marker)
    decoder = json.JSONDecoder()
    review_data, _ = decoder.raw_decode(log_text[input_start:].lstrip())

    endpoint_marker = (
        f"--- [4] HTTP 200 OK - Completed POST /generate-inscope-outscope "
        f"for Plan {plan_number}"
    )
    endpoint_start = log_text.find(endpoint_marker, input_start)
    if endpoint_start < 0:
        raise AssertionError(f"Captured endpoint response for plan {plan_number} was not found")
    response_marker = "--- [OUTPUT] Raw JSON Response from POST /generate-inscope-outscope ---"
    response_start = log_text.find(response_marker, endpoint_start)
    if response_start < 0:
        raise AssertionError(f"Captured report for plan {plan_number} was not found")
    response_start += len(response_marker)
    response_json, _ = decoder.raw_decode(log_text[response_start:].lstrip())
    return review_data, InScopeOutScopeResponse.model_validate(response_json)


def test_captured_production_cases_parse_without_model_access():
    plan_20086_data, plan_20086_candidate = _captured_case("20086")
    plan_20090_data, plan_20090_candidate = _captured_case("20090")

    assert plan_20086_data["planNumber"] == "20086"
    assert "IRC-CD-1000035" in plan_20086_candidate.inscope.report
    assert plan_20090_data["planNumber"] == "20090"
    assert "IRC-CD-1000141" in plan_20090_candidate.inscope.report


@pytest.mark.skipif(
    not RUN_LIVE_TESTS,
    reason="set GOOGLE_API_KEY and RUN_LIVE_SCOPE_JUDGE_TESTS=1 to enable Gemini calls",
)
def test_gemini_scope_judge_rejects_bad_draft_and_approves_corrected_draft():
    from langchain_google_genai import ChatGoogleGenerativeAI
    from service.inscope_outscope_service import InScopeOutScopeService

    judge_model = ChatGoogleGenerativeAI(
        model=os.getenv("SCOPE_REVIEW_LIVE_MODEL", "gemini-3.5-flash"),
        google_api_key=os.environ["GOOGLE_API_KEY"],
        temperature=0,
        max_retries=0,
        timeout=60,
    )
    service = object.__new__(InScopeOutScopeService)
    from config.config import Config
    service.config = Config
    service.llm = judge_model
    review_data = _review_data()

    try:
        bad_review = service._review_scope_candidate(_candidate(corrected=False), review_data)
        assert bad_review.approved is False, bad_review.feedback
        assert {
            "scope_boundary_fidelity",
            "required_content_format",
            "evidence_identifier_accuracy",
            "source_hierarchy_conflict_handling",
            "rationale_confidence_alignment",
        } == {criterion.name for criterion in bad_review.criteria if not criterion.passed}
        assert "C-999" in bad_review.feedback or "CI-101-EU" in bad_review.feedback

        corrected_review = service._review_scope_candidate(
            _candidate(corrected=True), review_data
        )
        assert corrected_review.approved is True, corrected_review.model_dump(mode="json")
        assert corrected_review.feedback == ""
    except Exception as exc:
        message = str(exc).lower()
        if "429" in message and any(
            marker in message for marker in ("quota", "resource_exhausted", "rate limit")
        ):
            pytest.skip("Gemini rate limit or quota exhausted; live calibration was not completed")
        if "503" in message and any(
            marker in message for marker in ("unavailable", "high demand", "service unavailable")
        ):
            pytest.skip("Gemini model temporarily unavailable; live calibration was not completed")
        raise


@pytest.mark.skipif(
    not RUN_LIVE_TESTS,
    reason="set GOOGLE_API_KEY and RUN_LIVE_SCOPE_JUDGE_TESTS=1 to enable Gemini calls",
)
def test_gemini_35_flash_reviews_captured_production_reports():
    """Replay logged outputs to measure boundary and report quality on real cases."""
    from langchain_google_genai import ChatGoogleGenerativeAI
    from service.inscope_outscope_service import InScopeOutScopeService

    service = object.__new__(InScopeOutScopeService)
    from config.config import Config
    service.config = Config
    service.llm = ChatGoogleGenerativeAI(
        model=os.getenv("SCOPE_REVIEW_LIVE_MODEL", "gemini-3.5-flash"),
        google_api_key=os.environ["GOOGLE_API_KEY"],
        temperature=0,
        max_retries=0,
        timeout=90,
    )

    try:
        plan_20086_data, plan_20086_candidate = _captured_case("20086")
        plan_20086_review = service._review_scope_candidate(
            plan_20086_candidate, plan_20086_data
        )
        boundary_result = next(
            criterion
            for criterion in plan_20086_review.criteria
            if criterion.name == "scope_boundary_fidelity"
        )
        assert not boundary_result.passed, (
            "Judge missed controls in the generated scope that PR Section 2 says were not "
            "attached or fetched."
        )
        assert "inscope.report" in boundary_result.affected_fields
        assert any(
            control_id in boundary_result.issue + boundary_result.action
            for control_id in ("IRC-CD-1000035", "IRC-CD-1000027")
        )

        plan_20090_data, plan_20090_candidate = _captured_case("20090")
        plan_20090_review = service._review_scope_candidate(
            plan_20090_candidate, plan_20090_data
        )
        assert len(plan_20090_review.criteria) == 5
        assert plan_20090_review.approved, plan_20090_review.feedback
    except Exception as exc:
        message = str(exc).lower()
        if "429" in message and any(
            marker in message for marker in ("quota", "resource_exhausted", "rate limit")
        ):
            pytest.skip("Gemini rate limit or quota exhausted; captured replay was not completed")
        if "503" in message and any(
            marker in message for marker in ("unavailable", "high demand", "service unavailable")
        ):
            pytest.skip("Gemini model temporarily unavailable; captured replay was not completed")
        raise
