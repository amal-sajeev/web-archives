import logging
from unittest.mock import MagicMock

from conftest import (
    extract_prompt_text as _prompt_text,
    make_failed_boundary_response as _failed_boundary_response,
    make_passing_rubric_responses as _passing_rubric_responses,
    make_scope_candidate as _scope_candidate,
)


def test_review_critique_revises_candidate_and_reviews_revision_again(service_with_mocks, monkeypatch, caplog):
    caplog.set_level(logging.INFO)
    service, storage_manager, structured_llm = service_with_mocks
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_JUDGE_LOOP", True)
    service.gather_all_review_data = MagicMock(
        return_value={
            "preliminary_research": {"Broad Scope Direction": "PR Section 2 source"},
            "preliminary_research_feedback_summary": {"feedback": "C-202 should be included."},
        }
    )
    revised = _scope_candidate(
        inscope_report="Corrected in-scope attributes",
        outscope_report="Corrected out-of-scope attributes",
    )
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        revised,
        *_passing_rubric_responses(),
    ]

    result, usage_metadata = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "Corrected in-scope attributes"
    assert result["outscope"]["report"] == "Corrected out-of-scope attributes"
    assert usage_metadata == {"input_tokens": 0, "output_tokens": 0}
    assert structured_llm.invoke.call_count == 10
    revision_prompt = _prompt_text(structured_llm.invoke.call_args_list[5])
    assert "REVISION INSTRUCTIONS" in revision_prompt
    assert "[scope_boundary_fidelity]" in revision_prompt
    assert "Control C-202 is absent" in revision_prompt
    assert "Previous candidate JSON" in revision_prompt
    assert storage_manager.upload_json.call_count == 2
    assert "stage=scope_recommendations outcome=approved revisions=1" in caplog.text
    assert "Corrected in-scope attributes" not in caplog.text
    assert "C-202 is absent" not in caplog.text
    assert "PR Section 2 source" not in caplog.text


def test_revision_limit_returns_and_persists_latest_valid_draft(service_with_mocks, monkeypatch, caplog):
    service, storage_manager, structured_llm = service_with_mocks
    caplog.set_level(logging.INFO)
    service.gather_all_review_data = MagicMock(return_value={"preliminary_research": "PR"})
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_JUDGE_LOOP", True)
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS", 1)
    revised = _scope_candidate(inscope_report="Latest revised in-scope draft")
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        revised,
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
    ]

    result, usage_metadata = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "Latest revised in-scope draft"
    assert usage_metadata == {"input_tokens": 0, "output_tokens": 0}
    assert storage_manager.upload_json.call_count == 2
    assert "outcome=revision_limit" in caplog.text
