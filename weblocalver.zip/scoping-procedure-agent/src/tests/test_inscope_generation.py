from pathlib import Path
import sys
import json
import logging
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.inscope_outscope_service import InScopeOutScopeService
from agents.llm_judge import SCOPE_REVIEW_RUBRIC_CALLS, SCOPE_REVIEW_PROMPT, ReviewLoopError
from model.response_model import InScopeOutScopeResponse, ScopeReport
from agents.llm_judge.models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
)


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


def test_generate_inscope_outscope_raises_for_missing_content(service_with_mocks):
    service, _, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    structured_llm.invoke.return_value = InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(report="", rationale="", confidence_score=0),
        outscope=ScopeReport(report="", rationale="", confidence_score=0),
    )

    with pytest.raises(ValueError, match="did not contain inscope or outscope"):
        service.generate_inscope_outscope("42")


def test_review_critique_revises_candidate_and_reviews_revision_again(service_with_mocks, caplog):
    caplog.set_level(logging.INFO)
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(
        return_value={
            "preliminary_research": {"Broad Scope Direction": "PR Section 2 source"},
            "preliminary_research_feedback_summary": {"feedback": "C-202 should be included."},
        }
    )
    revised = _scope_candidate(
        inscope_report="Corrected in-scope attributes",
        outscope_report="Corrected out-of-scope attributes",
    )
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        revised,
        *_passing_rubric_responses(),
    ]

    result = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "Corrected in-scope attributes"
    assert result["outscope"]["report"] == "Corrected out-of-scope attributes"
    assert structured_llm.invoke.call_count == 10
    revision_prompt = _prompt_text(structured_llm.invoke.call_args_list[5])
    assert "REVISION INSTRUCTIONS" in revision_prompt
    assert "[scope_boundary_fidelity]" in revision_prompt
    assert "Control C-202 is absent" in revision_prompt
    assert "Previous candidate JSON" in revision_prompt
    assert storage_manager.upload_json.call_count == 2
    assert (
        "Scope recommendation review completed approved=True revisions=1 outcome=approved"
        in caplog.text
    )
    assert "Corrected in-scope attributes" not in caplog.text


def test_revision_limit_returns_and_persists_latest_valid_draft(service_with_mocks, monkeypatch, caplog):
    service, storage_manager, structured_llm = service_with_mocks
    caplog.set_level(logging.INFO)
    service.gather_all_review_data = MagicMock(return_value={"preliminary_research": "PR"})
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS", 1)
    revised = _scope_candidate(inscope_report="Latest revised in-scope draft")
    structured_llm.invoke.side_effect = [
        _scope_candidate(),
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
        revised,
        _failed_boundary_response(),
        *_passing_rubric_responses()[1:],
    ]

    result = service.generate_inscope_outscope("42")

    assert result["inscope"]["report"] == "Latest revised in-scope draft"
    assert storage_manager.upload_json.call_count == 2
    assert "outcome=revision_limit" in caplog.text
