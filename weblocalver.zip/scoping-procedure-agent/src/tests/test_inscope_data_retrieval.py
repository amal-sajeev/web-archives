from pathlib import Path
import sys
import json
import logging
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.inscope_outscope_service import InScopeOutScopeService
from agents.llm_judge import SCOPE_REVIEW_RUBRIC_CALLS, SCOPE_REVIEW_PROMPT, ReviewLoopError
from model.response_model import InScopeOutScopeResponse, ScopeReport
from agents.llm_judge.models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
)


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


def test_llm_invoke_retries_rate_limits_with_exponential_backoff(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    model = MagicMock()
    model.invoke.side_effect = [RuntimeError("429 resource exhausted"), RuntimeError("429 rate limit"), "ok"]
    sleeps = []
    monkeypatch.setattr("service.inscope_outscope_service.time.sleep", sleeps.append)
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_LLM_MAX_ATTEMPTS", 4)
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_LLM_RETRY_BASE_SECONDS", 2)

    result = service._invoke_llm_with_backoff(model, ["prompt"], stage="judge:test")

    assert result == "ok"
    assert model.invoke.call_count == 3
    assert sleeps == [2, 4]


def test_llm_invoke_does_not_retry_permanent_errors(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    model = MagicMock()
    model.invoke.side_effect = ValueError("invalid request")
    sleeps = []
    monkeypatch.setattr("service.inscope_outscope_service.time.sleep", sleeps.append)

    with pytest.raises(ValueError, match="invalid request"):
        service._invoke_llm_with_backoff(model, ["prompt"], stage="judge:test")

    model.invoke.assert_called_once()
    assert sleeps == []


def test_llm_invoke_stops_on_daily_quota_exhaustion(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    model = MagicMock()
    model.invoke.side_effect = RuntimeError(
        "RESOURCE_EXHAUSTED: Generate content requests per day limit exceeded. "
        "Please retry in 14h30m24.5s."
    )
    sleeps = []
    monkeypatch.setattr("service.inscope_outscope_service.time.sleep", sleeps.append)

    with pytest.raises(RuntimeError, match="per day limit exceeded"):
        service._invoke_llm_with_backoff(model, ["prompt"], stage="judge:test")

    model.invoke.assert_called_once()
    assert sleeps == []
    assert service._provider_retry_delay_seconds(model.invoke.side_effect) == pytest.approx(
        14 * 3600 + 30 * 60 + 24.5
    )


def test_gather_raw_data_downloads_all_configured_files(service_with_mocks, monkeypatch):
    service, storage_manager, _ = service_with_mocks

    raw_data_config = {
        "dbaware": {"folder": "inbound-data/dbaware", "files": ["file1.json", "file2.json"]},
        "gfms": {"folder": "inbound-data/gfms", "files": ["file3.json"]},
    }
    monkeypatch.setattr(service.config, "RAW_DATA_CONFIG", raw_data_config)

    storage_manager.download_json.side_effect = [{"k": 1}, {"k": 2}, {"k": 3}]

    result = service.gather_raw_data("123")

    assert result == {
        "dbaware": {"file1.json": {"k": 1}, "file2.json": {"k": 2}},
        "gfms": {"file3.json": {"k": 3}},
    }

    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/dbaware/file1.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/dbaware/file2.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/gfms/file3.json"
    )


def test_gather_raw_data_logs_found_and_missing_files(
    service_with_mocks, monkeypatch, caplog
):
    service, storage_manager, _ = service_with_mocks
    storage_manager.bucket_name = "test-bucket"
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "dbaware": {
                "folder": "inbound-data/dbaware",
                "files": ["found.json", "missing.json"],
            }
        },
    )
    storage_manager.download_json.side_effect = [{"data": True}, None]

    with caplog.at_level(logging.INFO):
        service.gather_raw_data("123", api_name="generate-test-steps")

    assert (
        "Input file FOUND api=generate-test-steps planNumber=123 "
        "uri=gs://test-bucket/dbaware_review_123/inbound-data/dbaware/found.json"
    ) in caplog.text
    assert (
        "Input file NOT FOUND api=generate-test-steps planNumber=123 "
        "uri=gs://test-bucket/dbaware_review_123/inbound-data/dbaware/missing.json"
    ) in caplog.text


