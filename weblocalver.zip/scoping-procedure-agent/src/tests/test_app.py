from fastapi.testclient import TestClient

import app as api


def test_health_returns_ok() -> None:
    response = TestClient(api.app).get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_app_metadata_and_root_path() -> None:
    assert api.app.title == "Scoping Procedure Agent"
    assert api.app.root_path == "/scoping-procedure-agent"


def test_app_includes_all_router_endpoints() -> None:
    pass