import importlib

from service import pdf_download_service as pdf_service


def _record_multi_cell(monkeypatch) -> list[dict]:
    """Record real (non dry-run) multi_cell calls made by the PDF renderers."""
    fpdf_module = importlib.import_module("fpdf")
    original = fpdf_module.FPDF.multi_cell
    calls: list[dict] = []

    def recording(self, *args, **kwargs):
        if not kwargs.get("dry_run"):
            calls.append(
                {
                    "text": kwargs.get("text"),
                    "markdown": kwargs.get("markdown", False),
                    "x": self.get_x(),
                }
            )
        return original(self, *args, **kwargs)

    monkeypatch.setattr(fpdf_module.FPDF, "multi_cell", recording)
    return calls


def test_markdown_safe_keeps_bold_but_neutralises_italic_and_underline_markers() -> None:
    assert pdf_service._markdown_safe("**Key:** value") == "**Key:** value"
    assert pdf_service._markdown_safe("a -- b") == "a - - b"
    assert pdf_service._markdown_safe("a __b__ c") == "a _ _b_ _ c"


def test_simple_report_renders_bold_keys_with_markdown(monkeypatch) -> None:
    calls = _record_multi_cell(monkeypatch)

    pdf = pdf_service._render_simple_report_pdf(
        "Scope Recommendation",
        "20587",
        [
            (
                "1. In Scope",
                "**Review Type:** Mandatory review\n\n**Key Control:**\n    1. IRC-CD-1001083 - Quarterly Review",
            )
        ],
    )

    assert pdf.startswith(b"%PDF")
    assert [call["text"] for call in calls if call["markdown"]] == [
        "**Review Type:** Mandatory review",
        "**Key Control:**",
        "1. IRC-CD-1001083 - Quarterly Review",
    ]


def test_simple_report_indents_nested_lines_further_than_parent(monkeypatch) -> None:
    calls = _record_multi_cell(monkeypatch)

    pdf_service._render_simple_report_pdf(
        "Test",
        "1",
        [("Heading", "**Key:**\n    1. Item\n        **Sub Key:** value")],
    )

    xs = {call["text"]: call["x"] for call in calls if call["markdown"]}
    assert xs["**Key:**"] < xs["1. Item"] < xs["**Sub Key:** value"]


def test_simple_report_does_not_turn_double_dash_into_italic(monkeypatch) -> None:
    calls = _record_multi_cell(monkeypatch)

    pdf_service._render_simple_report_pdf("Test", "1", [("Heading", "**Key:** a -- b __c__")])

    assert [call["text"] for call in calls if call["markdown"]] == ["**Key:** a - - b _ _c_ _"]


def test_test_steps_preserve_unicode_and_remove_formatting_artifacts(monkeypatch) -> None:
    calls = _record_multi_cell(monkeypatch)
    content = (
        "**<u>Policy \u2013 Germany</u>**\n"
        "* Review `WpHG` \u00a7 64: \u201cGeeignetheitspr\u00fcfung\u201d \u20ac100 \u2265 \u20ac50 &amp; fees."
    )

    pdf = pdf_service.build_test_steps_pdf(
        [{"test_step": {"DB Policies": content}, "rationale": "Client\u2019s protection"}],
        "20429",
    )

    texts = [call["text"] for call in calls if call["markdown"]]
    assert "**Policy \u2013 Germany**" in texts
    assert '- Review WpHG \u00a7 64: \u201cGeeignetheitspr\u00fcfung\u201d \u20ac100 \u2265 \u20ac50 & fees.' in texts
    assert "Client\u2019s protection" in texts
    assert b"/FontFile2" in pdf
    assert not any("?" in text or "<u>" in text or "`" in text for text in texts)


def test_scoping_document_keeps_one_line_per_attribute_with_bold_keys(monkeypatch) -> None:
    calls = _record_multi_cell(monkeypatch)
    inscope = (
        "**Regulatory Requirement:** GBSA HFT prohibition\n\n"
        "**Key Control:**\n"
        "    1. IRC-CD-1001083 - Quarterly Review\n"
        "        **Control Instance ID:** 123"
    )

    pdf = pdf_service.build_scoping_document_pdf(
        inscope=inscope,
        outscope="**Assessment Units:** Group Treasury",
        plan_number="20587",
    )

    assert pdf.startswith(b"%PDF")
    texts = [call["text"] for call in calls if call["markdown"]]
    assert texts[:4] == [
        "**Regulatory Requirement:** GBSA HFT prohibition",
        "**Key Control:**",
        "1. IRC-CD-1001083 - Quarterly Review",
        "**Control Instance ID:** 123",
    ]
    assert "**Assessment Units:** Group Treasury" in texts
    # Numbered lines must not be rewritten into merged "- " bullets.
    assert not any(text.startswith("- ") for text in texts)


def test_scoping_document_indents_nested_lines(monkeypatch) -> None:
    calls = _record_multi_cell(monkeypatch)

    pdf_service.build_scoping_document_pdf(
        inscope="**Key Control:**\n    1. Item\n        **Sub Key:** value",
        outscope="",
        plan_number="20587",
    )

    xs = {call["text"]: call["x"] for call in calls if call["markdown"]}
    assert xs["**Key Control:**"] < xs["1. Item"] < xs["**Sub Key:** value"]


def test_scoping_document_paginates_long_formatted_content() -> None:
    inscope = "\n\n".join(f"**Attribute {index}:** " + "detail " * 40 for index in range(60))

    pdf = pdf_service.build_scoping_document_pdf(inscope=inscope, outscope="", plan_number="20587")

    assert pdf.startswith(b"%PDF")
    assert pdf.count(b"/Type /Page\n") + pdf.count(b"/Type /Page ") > 1


def test_scoping_document_formatted_output_uses_bold_font() -> None:
    pdf = pdf_service.build_scoping_document_pdf(
        inscope="**Review Type:** Mandatory review",
        outscope="",
        plan_number="20587",
    )

    assert b"Helvetica-Bold" in pdf
