import uuid
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock
import pytest
from fastapi.testclient import TestClient

from app import app
from agent_helper.action_service import (
    call_to_action_service,
    construct_human_actor_record,
    construct_ai_actor_record,
    construct_human_update_record,
)

client = TestClient(app)


def test_call_to_action_service_procedure_payload_structure():
    """Verify call_to_action_service formats correctly for SCOPING_PROCEDURE."""
    session_id = str(uuid.uuid4())
    card = {
        "ENTITY_ID": session_id,
        "ENTITY_TYPE": "DISCOVERY_WALKTHROUGH",
        "PARENT_ENTITY_TYPE": "SCOPING_PROCEDURE",
        "PARENT_ENTITY_ID": "20583",
        "CORRELATION_ID": session_id,
        "ACTOR_TYPE": "HUMAN",
        "ACTOR_ID": "dbaware@db.com",
        "ACTION_TYPE": "GENERATE",
        "ACTIVITY_TYPE": "DISCOVERY_WALKTHROUGH",
    }
    data = {"action_type": "GENERATE", "Human_Notes": "Generate walkthrough", "Remarks": ""}
    result = call_to_action_service(card, data)

    assert "CTA_ACTION" in result
    action = result["CTA_ACTION"]
    assert action["entity_id"] == session_id
    assert action["parent_entity_type"] == "SCOPING_PROCEDURE"
    assert action["parent_entity_id"] == "20583"
    assert action["create_ts"].endswith("Z")


@patch("agent_helper.action_service.construct_human_actor_record")
@patch("agent_helper.action_service.construct_ai_actor_record")
@patch("router.router.get_discovery_walkthrough_service")
def test_generate_discovery_walkthrough_action_records(mock_service_getter, mock_ai_rec, mock_human_rec):
    """Test /generate-discovery-walkthrough emits both human and AI records."""
    mock_svc = MagicMock()
    mock_svc.generate_report.return_value = {"report_title": "Discovery Walkthrough Preparation", "sections": []}
    mock_service_getter.return_value = mock_svc

    response = client.post("/generate-discovery-walkthrough", json={"planNumber": "20583", "userDetails": {}})
    assert response.status_code == 200
    assert mock_human_rec.called
    assert mock_ai_rec.called


@patch("agent_helper.action_service.construct_human_update_record")
@patch("router.router.get_discovery_walkthrough_service")
def test_update_discovery_walkthrough_action_records(mock_service_getter, mock_update_rec):
    """Test /update-discovery-walkthrough emits human update record."""
    mock_svc = MagicMock()
    mock_svc.update_report.return_value = {"report_title": "Updated", "sections": []}
    mock_service_getter.return_value = mock_svc

    response = client.put(
        "/update-discovery-walkthrough",
        json={
            "planNumber": "20583",
            "userDetails": {},
            "report_title": "Updated",
            "sections": [
                {
                    "section_title": "Key Scope Drivers",
                    "key_points": ["Point 1"],
                }
            ],
        },
    )
    assert response.status_code == 200
    assert mock_update_rec.called