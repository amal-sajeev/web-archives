from types import SimpleNamespace
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel, ValidationError

from router import router as router_module
from model.request_model import ScopingDocumentContent, ScopingDocumentRow
from model.response_model import MeetingNotesSummaryResponse

app = FastAPI()
app.include_router(router_module.router)
client = TestClient(app)


def _build_validation_error() -> ValidationError:
    class _Tmp(BaseModel):
        value: int

    try:
        _Tmp.model_validate({"value": "not-an-int"})
    except ValidationError as err:
        return err

    raise AssertionError("Expected ValidationError was not created")


def test_router_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_meeting_notes_accepts_multipart_upload(monkeypatch) -> None:
    async def fake_process(request):
        assert request.planNumber == "12345"
        assert request.files[0].filename == "notes.txt"
        return MeetingNotesSummaryResponse(
            planNumber="12345",
            uploaded_documents=[],
            normalized_summary_uri="gs://bucket/summary.json",
        )

    monkeypatch.setattr(
        router_module,
        "get_meeting_notes_service",
        lambda: SimpleNamespace(process_meeting_notes=fake_process),
    )

    response = client.post(
        "/meeting-notes",
        data={"planNumber": "12345"},
        files=[("files", ("notes.txt", b"Decision: approve", "text/plain"))],
    )
    assert response.status_code == 200
    assert response.json()["normalized_summary_uri"] == "gs://bucket/summary.json"


def test_meeting_notes_rejects_blank_plan_values() -> None:
    response = client.post(
        "/meeting-notes",
        data={"planNumber": " "},
        files=[("files", ("notes.txt", b"Note", "text/plain"))],
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "planNumber is required."


def test_meeting_notes_returns_service_value_error(monkeypatch) -> None:
    async def failing_process(request):
        raise ValueError("Unable to normalize meeting notes.")

    monkeypatch.setattr(
        router_module,
        "get_meeting_notes_service",
        lambda: SimpleNamespace(process_meeting_notes=failing_process),
    )

    response = client.post(
        "/meeting-notes",
        data={"planNumber": "12345"},
        files=[("files", ("notes.txt", b"Note", "text/plain"))],
    )
    assert response.status_code == 500
    assert response.json()["detail"] == "Unable to normalize meeting notes."


def test_update_discovery_walkthrough(monkeypatch) -> None:
    expected_payload = {
        "planNumber": "20587",
        "userDetails": {},
        "report_title": "Discovery Walkthrough Preparation",
        "sections": [
            {
                "section_title": "Key Scope Drivers",
                "key_points": ["Point 1", "Point 2"],
            }
        ],
    }

    def fake_update_report(plan_number: str, report_data: dict):
        assert plan_number == "20587"
        assert report_data == {
            "report_title": "Discovery Walkthrough Preparation",
            "sections": [
                {
                    "section_title": "Key Scope Drivers",
                    "key_points": ["Point 1", "Point 2"],
                }
            ],
        }
        return report_data

    monkeypatch.setattr(
        router_module,
        "get_discovery_walkthrough_service",
        lambda: SimpleNamespace(update_report=fake_update_report),
    )

    response = client.put(
        "/update-discovery-walkthrough",
        json=expected_payload,
    )
    assert response.status_code == 200
    assert response.json() == {
        "report_title": expected_payload["report_title"],
        "sections": expected_payload["sections"],
        "rationale": "",
        "confidence_score": 0,
    }


def test_get_inscope_outscope(monkeypatch) -> None:
    request_payload = {"planNumber": "20587", "userDetails": {}}

    def fake_get_inscope_outscope(plan_number: str):
        assert plan_number == "20587"
        return {
            "planNumber": "20587",
            "inscope": {
                "report": "Generated inscope",
                "rationale": "High risk",
                "confidence_score": 90,
            },
            "outscope": {
                "report": "Generated outscope",
                "rationale": "Low risk",
                "confidence_score": 80,
            },
        }

    monkeypatch.setattr(
        router_module,
        "get_inscope_outscope_service",
        lambda: SimpleNamespace(get_inscope_outscope=fake_get_inscope_outscope),
    )

    response = client.post("/get-inscope-outscope", json=request_payload)
    assert response.status_code == 200
    assert response.json() == {
        "planNumber": "20587",
        "inscope": {
            "report": "Generated inscope",
            "rationale": "High risk",
            "confidence_score": 90,
        },        "outscope": {
            "report": "Generated outscope",
            "rationale": "Low risk",
            "confidence_score": 80,
        },
    }


def test_get_discovery_walkthrough(monkeypatch) -> None:
    request_payload = {"planNumber": "20587", "userDetails": {}}

    def fake_get_report(plan_number: str):
        assert plan_number == "20587"
        return {
            "report_title": "Discovery Walkthrough Preparation",
            "sections": [
                {
                    "section_title": "Key Scope Drivers",
                    "key_points": ["Point 1"],
                }
            ],
        }

    monkeypatch.setattr(
        router_module,
        "get_discovery_walkthrough_service",
        lambda: SimpleNamespace(get_report=fake_get_report),
    )

    response = client.post("/get-discovery-walkthrough", json=request_payload)
    assert response.status_code == 200
    assert response.json() == {
        "report_title": "Discovery Walkthrough Preparation",
        "sections": [
            {
                "section_title": "Key Scope Drivers",
                "key_points": ["Point 1"],
            }
        ],
        "rationale": "",
        "confidence_score": 0,
    }


def test_get_test_steps(monkeypatch) -> None:
    request_payload = {"planNumber": "20587"}

    def fake_get_test_steps(plan_number: str):
        assert plan_number == "20587"
        return {
            "planNumber": "20587",
            "test_steps": [
                {
                    "test_step": {
                        "1. Test Step Name and Number": "Test Step 1",
                        "2. Execution Approach": "Risk Management Assessment: Selected",
                    },
                    "rationale": "Assessment evaluates control coverage. Metrics validate sustainable risk management.",
                    "confidence_score": 80,
                }
            ]
        }

    monkeypatch.setattr(
        router_module,
        "get_test_steps_service",
        lambda: SimpleNamespace(get_test_steps=fake_get_test_steps),
    )

    response = client.post("/get-test-steps", json=request_payload)
    assert response.status_code == 200
    assert response.json() == {
        "planNumber": "20587",
        "test_steps": [
            {
                "test_step": {
                    "1. Test Step Name and Number": "Test Step 1",
                    "2. Execution Approach": "Risk Management Assessment: Selected",
                },
                "rationale": "Assessment evaluates control coverage. Metrics validate sustainable risk management.",
                "confidence_score": 80,
            }
        ],
    }


def test_get_meeting_notes_summary(monkeypatch) -> None:
    request_payload = {"planNumber": "20587"}

    def fake_get_meeting_notes_summary(plan_number: str):
        assert plan_number == "20587"
        return {
            "planNumber": "20587",
            "normalized_meeting_notes": "summary content",
        }

    monkeypatch.setattr(
        router_module,
        "get_meeting_notes_service",
        lambda: SimpleNamespace(get_meeting_notes_summary=fake_get_meeting_notes_summary),
    )

    response = client.post("/get-meeting-notes-summary", json=request_payload)
    assert response.status_code == 200
    assert response.json() == {
        "planNumber": "20587",
        "normalized_meeting_notes": "summary content",
    }


def test_download_discovery_walkthrough(monkeypatch) -> None:
    def fake_download(plan_number, report, plan_name=None):
        assert plan_number == "20587"
        assert report["report_title"] == "Discovery Walkthrough Preparation"
        assert report["rationale"] == "Discovery rationale"
        assert plan_name is None
        return b"%PDF-discovery", {
            "Content-Disposition": 'attachment; filename="discovery_walkthrough_20587.pdf"',
        }

    monkeypatch.setattr(router_module, "download_discovery_walkthrough_pdf", fake_download)
    response = client.post(
        "/download-discovery-walkthrough",
        json={
            "planNumber": "20587",
            "report_title": "Discovery Walkthrough Preparation",
            "sections": [],
            "rationale": "Discovery rationale",
            "confidence_score": 86,
        },
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.headers["content-disposition"].endswith("discovery_walkthrough_20587.pdf\"")
    assert response.content == b"%PDF-discovery"


def test_build_scoping_document_content_maps_sources_to_rows(monkeypatch) -> None:
    inscope_json = {
        "inscope": {
            "report": "In-scope report details",
            "rationale": "In-scope rationale",
            "confidence_score": 90,
        }
    }
    outscope_json = {
        "outscope": {
            "report": "Out-of-scope report details",
            "rationale": "Out-of-scope rationale",
            "confidence_score": 80,
        }
    }
    test_steps_json = {
        "test_steps": [
            {
                "test_step": {
                    "Execution Approach": "Controls Testing",
                    "Risk Type": "Operational Risk",
                },
                "rationale": "risk-driven",
                "confidence_score": 84,
            }
        ]
    }
    plan_details_json = {
        "planName": "Sample Plan 20587",
        "Plan Item Type": "Mandatory review",
        "Plan Item Title": "Key Controls Testing",
        "Review Coverage Period Start Date": "2026-01-01",
        "Review Coverage Period End Date": "2026-12-31",
        "Report Publication Current Target Start Date": "2027-01-15",
        "AU Aggregation Point 4": "AP-4",
        "AU Aggregation Point 5": "AP-5",
        "AU Aggregation Point 3": "AP-3",
        "UoT LE": "DB AG",
        "UoT Core Process": None,
        "Review Lead": "Owner A",
        "Coordinating Team Lead": "Lead A",
        "Lead Regional/Functional Head": "Regional Head A",
    }

    def fake_load_source_artifacts(plan_number: str):
        assert plan_number == "20587"
        return {
            "inscope": inscope_json,
            "outscope": outscope_json,
            "test_steps": test_steps_json,
            "plan_details": plan_details_json,
        }

    monkeypatch.setattr(
        router_module,
        "get_scoping_document_service",
        lambda: SimpleNamespace(load_source_artifacts=fake_load_source_artifacts),
    )

    document = router_module._build_scoping_document_content("20587")

    assert document.plan_name == "Sample Plan 20587"
    assert document.inscope == "In-scope report details"
    assert document.outscope == "Out-of-scope report details"
    assert [(row.key, row.value) for row in document.testing_approach_rows] == [
        ("Execution Approach", "Controls Testing"),
        ("Risk Type", "Operational Risk"),
    ]
    plan_details_map = {row.key: row.value for row in document.plan_details_rows}
    assert plan_details_map["Plan Item Type"] == "Mandatory review"
    assert plan_details_map["Plan item Title (incl system ID)"] == "Key Controls Testing (20587)"
    assert plan_details_map["Coverage Period"] == "2026-01-01 - 2026-12-31"
    assert plan_details_map["Planned Publication Date"] == "2027-01-15"
    assert plan_details_map["Assessment Units"] == "AP-4, AP-5, AP-3"
    assert plan_details_map["Legal Entity(ies)"] == "DB AG"
    assert plan_details_map["Core Processes"] == "NA"
    assert plan_details_map["Review Owner"] == "Owner A"
    assert plan_details_map["Team Lead"] == "Lead A"
    assert plan_details_map["CT&A Regional/Functional Head"] == "Regional Head A"
    assert plan_details_map["Prepared by"] == "HITL"


def test_build_scoping_document_content_preserves_more_than_100_testing_rows(monkeypatch) -> None:
    test_steps = [
        {"test_step": {f"Field {index}": f"Value {index}" for index in range(7)}}
        for _ in range(24)
    ]
    monkeypatch.setattr(
        router_module,
        "get_scoping_document_service",
        lambda: SimpleNamespace(
            load_source_artifacts=lambda plan_number: {
                "inscope": {"inscope": {"report": "In-scope report"}},
                "outscope": {"outscope": {"report": "Out-of-scope report"}},
                "test_steps": {"test_steps": test_steps},
                "plan_details": {},
            }
        ),
    )

    document = router_module._build_scoping_document_content("20587")

    assert len(document.testing_approach_rows) == 168
    assert [(row.key, row.value) for row in document.testing_approach_rows] == [
        (key, value) for step in test_steps for key, value in step["test_step"].items()
    ]
    assert ScopingDocumentContent.model_validate_json(document.model_dump_json()) == document


def test_build_scoping_document_content_rejects_empty_scope_reports(monkeypatch) -> None:
    monkeypatch.setattr(
        router_module,
        "get_scoping_document_service",
        lambda: SimpleNamespace(
            load_source_artifacts=lambda plan_number: {
                "inscope": {"inscope": {"report": "   "}},
                "outscope": {"outscope": {"report": ""}},
                "test_steps": {"test_steps": []},
                "plan_details": {},
            }
        ),
    )

    with pytest.raises(ValueError, match="Both inscope.report and outscope.report are empty."):
        router_module._build_scoping_document_content("20587")


def test_GENERATE_SCOPING_DOCUMENT_returns_saved_document(monkeypatch) -> None:
    document = ScopingDocumentContent(plan_name="Saved draft", inscope="Updated scope")
    fake_service = SimpleNamespace(
        get_saved_document=lambda plan_number: document,
        save_document=lambda *args: pytest.fail("saved document should not be replaced"),
        render_editor_html=lambda plan_number, value, user_details=None: "<html>saved draft</html>",
    )
    monkeypatch.setattr(router_module, "get_scoping_document_service", lambda: fake_service)

    response = client.post(
        "/generate-scoping-document",
        json={"planNumber": "20587", "userDetails": {}},
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/html")
    assert response.text == "<html>saved draft</html>"


def test_GENERATE_SCOPING_DOCUMENT_builds_and_saves_first_draft(monkeypatch) -> None:
    document = ScopingDocumentContent(
        plan_name="New draft",
        plan_details_rows=[ScopingDocumentRow(key="Plan Number", value="20587")],
    )
    saved = []
    persisted = []
    fake_service = SimpleNamespace(
        get_saved_document=lambda plan_number: None,
        save_document=lambda plan_number, value: saved.append((plan_number, value)),
        render_editor_html=lambda plan_number, value, user_details=None: "<html>new draft</html>",
    )
    monkeypatch.setattr(router_module, "get_scoping_document_service", lambda: fake_service)
    monkeypatch.setattr(router_module, "audit_generation_start", lambda **_k: (object(), object()))
    monkeypatch.setattr(router_module, "audit_ai_response", lambda **_k: None)
    monkeypatch.setattr(
        router_module,
        "persist_review_research_recommendation",
        lambda **kwargs: persisted.append(kwargs) or 1,
    )
    monkeypatch.setattr(
        router_module,
        "_build_scoping_document_content",
        lambda plan_number: document,
    )

    response = client.post(
        "/generate-scoping-document",
        json={"planNumber": "20587", "userDetails": {"review_scope_instance_id": "7", "user": "jdoe"}},
    )

    assert response.status_code == 200
    assert saved == [("20587", document)]
    assert persisted[0]["report_type"] == "SCOPING_DOCUMENT"
    assert persisted[0]["review_scope_instance_id"] == "7"
    assert persisted[0]["created_by"] == "jdoe"


def test_update_scoping_document_saves_all_editable_cells(monkeypatch) -> None:
    saved = []
    fake_service = SimpleNamespace(
        save_document=lambda plan_number, document: saved.append((plan_number, document))
        or "gs://review-bucket/scoping-document.json"
    )
    monkeypatch.setattr(router_module, "get_scoping_document_service", lambda: fake_service)
    monkeypatch.setattr(router_module, "audit_revision", lambda **_k: None)
    updated = []
    monkeypatch.setattr(
        router_module,
        "update_review_research_recommendation",
        lambda **kwargs: updated.append(kwargs) or 1,
    )

    response = client.put(
        "/update-scoping-document",
        json={
            "planNumber": "20587",
            "userDetails": {"review_scope_instance_id": "7", "user": "jdoe"},
            "document": {
                "plan_name": "Edited title",
                "plan_details_rows": [{"key": "Plan Number", "value": "20587"}],
                "inscope": "Edited in-scope content",
                "outscope": "Edited out-of-scope content",
                "testing_approach_rows": [{"key": "Step 1", "value": "Edited test"}],
            },
        },
    )

    assert response.status_code == 200
    assert response.json()["saved"] is True
    assert response.json()["document"]["inscope"] == "Edited in-scope content"
    assert saved[0][0] == "20587"
    assert saved[0][1].testing_approach_rows[0].value == "Edited test"
    assert updated[0]["report_type"] == "SCOPING_DOCUMENT"
    assert updated[0]["updated_by"] == "jdoe"


def test_download_edited_scoping_document_uses_saved_model(monkeypatch) -> None:
    document = ScopingDocumentContent(
        plan_name="Edited plan",
        plan_details_rows=[ScopingDocumentRow(key="Plan Number", value="20587")],
        inscope="Edited in-scope",
        outscope="Edited out-of-scope",
        testing_approach_rows=[ScopingDocumentRow(key="Step 1", value="Edited test")],
    )
    captured = {}

    monkeypatch.setattr(
        router_module,
        "get_scoping_document_service",
        lambda: SimpleNamespace(
            get_saved_document=lambda plan_number: document,
            render_pdf_html=lambda plan_number, doc: f"<html>{doc.inscope}</html>",
        ),
    )

    def fake_download_pdf_from_html(**kwargs):
        captured.update(kwargs)
        return b"%PDF-edited", {"Content-Disposition": 'attachment; filename="scoping_document_20587.pdf"'}

    monkeypatch.setattr(router_module, "download_scoping_document_pdf_from_html", fake_download_pdf_from_html)

    response = client.post(
        "/download-scoping-document",
        json={"planNumber": "20587"},
    )

    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content == b"%PDF-edited"
    assert captured["plan_number"] == "20587"
    assert captured["html_content"] == "<html>Edited in-scope</html>"


def test_download_test_steps(monkeypatch) -> None:
    expected_test_steps = [{"objective": "Test control", "procedure": "Inspect evidence"}]

    def fake_download(plan_number, test_steps, plan_name=None):
        assert plan_number == "20587"
        assert test_steps == expected_test_steps
        assert plan_name is None
        return b"%PDF-test-steps", {
            "Content-Disposition": 'attachment; filename="test_steps_20587.pdf"',
        }

    monkeypatch.setattr(router_module, "download_test_steps_pdf", fake_download)
    response = client.post(
        "/download-test-steps",
        json={
            "planNumber": "20587",
            "test_steps": expected_test_steps,
        },
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.headers["content-disposition"].endswith("test_steps_20587.pdf\"")
    assert response.content == b"%PDF-test-steps"


def test_meeting_notes_rejects_empty_files() -> None:
    response = client.post(
        "/meeting-notes",
        data={"planNumber": "12345"},
    )
    assert response.status_code == 422


def test_generate_meeting_notes_alias_route_works(monkeypatch) -> None:
    async def fake_process(_request):
        return MeetingNotesSummaryResponse(
            planNumber="12345",
            uploaded_documents=[],
            normalized_summary_uri="gs://bucket/summary.json",
        )

    monkeypatch.setattr(
        router_module,
        "get_meeting_notes_service",
        lambda: SimpleNamespace(process_meeting_notes=fake_process),
    )

    response = client.post(
        "/generate-meeting-notes",
        data={"planNumber": "12345"},
        files=[("files", ("notes.txt", b"Decision", "text/plain"))],
    )
    assert response.status_code == 200


def test_get_meeting_notes_summary_file_not_found(monkeypatch) -> None:
    monkeypatch.setattr(
        router_module,
        "get_meeting_notes_service",
        lambda: SimpleNamespace(
            get_meeting_notes_summary=lambda _plan_number: (_ for _ in ()).throw(
                FileNotFoundError("missing")
            )
        ),
    )

    response = client.post(
        "/get-meeting-notes-summary", json={"planNumber": "20587"}
    )
    assert response.status_code == 404
    assert response.json()["detail"] == "missing"


def test_generate_discovery_walkthrough_not_found(monkeypatch) -> None:
    monkeypatch.setattr(
        router_module,
        "get_discovery_walkthrough_service",
        lambda: SimpleNamespace(
            generate_report=lambda _plan_number: (_ for _ in ()).throw(FileNotFoundError("missing report"))
        ),
    )

    response = client.post(
        "/generate-discovery-walkthrough", json={"planNumber": "20587", "userDetails": {}}
    )
    assert response.status_code == 404


def test_lazy_getters_initialize_once(monkeypatch) -> None:
    class _Discovery:
        pass

    class _InScope:
        pass

    class _Meeting:
        pass

    class _TestSteps:
        pass

    class _PlanDetails:
        pass

    monkeypatch.setattr(router_module, "DiscoveryWalkthroughService", _Discovery)
    monkeypatch.setattr(router_module, "InScopeOutScopeService", _InScope)
    monkeypatch.setattr(router_module, "MeetingNotesService", _Meeting)
    monkeypatch.setattr(router_module, "TestStepsService", _TestSteps)
    monkeypatch.setattr(router_module, "PlanDetailsService", _PlanDetails)

    router_module.discovery_walkthrough_service = None
    router_module.inscope_outscope_service = None
    router_module.meeting_notes_service = None
    router_module.test_steps_service = None
    router_module.plan_details_service = None

    first_discovery = router_module.get_discovery_walkthrough_service()
    second_discovery = router_module.get_discovery_walkthrough_service()
    first_inscope = router_module.get_inscope_outscope_service()
    second_inscope = router_module.get_inscope_outscope_service()
    first_meeting = router_module.get_meeting_notes_service()
    second_meeting = router_module.get_meeting_notes_service()
    first_steps = router_module.get_test_steps_service()
    second_steps = router_module.get_test_steps_service()
    first_plan = router_module.get_plan_details_service()
    second_plan = router_module.get_plan_details_service()

    assert isinstance(first_discovery, _Discovery)
    assert first_discovery is second_discovery
    assert isinstance(first_inscope, _InScope)
    assert first_inscope is second_inscope
    assert isinstance(first_meeting, _Meeting)
    assert first_meeting is second_meeting
    assert isinstance(first_steps, _TestSteps)
    assert first_steps is second_steps
    assert isinstance(first_plan, _PlanDetails)
    assert first_plan is second_plan


def test_generate_inscope_outscope_success(monkeypatch) -> None:
    monkeypatch.setattr(router_module, "audit_generation_start", lambda **_k: (object(), object()))
    monkeypatch.setattr(router_module, "audit_ai_response", lambda **_k: None)
    monkeypatch.setattr(
        router_module,
        "get_inscope_outscope_service",
        lambda: SimpleNamespace(
            generate_inscope_outscope=lambda plan_number: {
                "inscope": {"report": "in", "rationale": "r1", "confidence_score": 91},
                "outscope": {"report": "out", "rationale": "r2", "confidence_score": 72},
                "rationale": "overall",
                "confidence_score": 80,
            }
        ),
    )

    response = client.post("/generate-inscope-outscope", json={"planNumber": "20587", "userDetails": {}})
    assert response.status_code == 200
    assert response.json()["inscope"]["report"] == "in"
    assert response.json()["outscope"]["report"] == "out"


def test_generate_inscope_outscope_returns_500_on_failure(monkeypatch) -> None:
    monkeypatch.setattr(router_module, "audit_generation_start", lambda **_k: (object(), object()))
    monkeypatch.setattr(
        router_module,
        "get_inscope_outscope_service",
        lambda: SimpleNamespace(
            generate_inscope_outscope=lambda **_kwargs: (_ for _ in ()).throw(RuntimeError("boom"))
        ),
    )

    response = client.post("/generate-inscope-outscope", json={"planNumber": "20587", "userDetails": {}})
    assert response.status_code == 500
    assert response.json()["detail"] == "Error generating inscope/outscope: boom"


def test_update_inscope_outscope_success(monkeypatch) -> None:
    monkeypatch.setattr(router_module, "audit_revision", lambda **_k: None)
    monkeypatch.setattr(
        router_module,
        "get_inscope_outscope_service",
        lambda: SimpleNamespace(
            update_inscope_outscope=lambda **kwargs: {
                "inscope": kwargs["inscope"],
                "outscope": kwargs["outscope"],
            }
        ),
    )

    response = client.put(
        "/update-inscope-outscope",
        json={
            "planNumber": "20587",
            "userDetails": {},
            "inscope": {"report": "in"},
            "outscope": {"report": "out"},
        },
    )
    assert response.status_code == 200
    assert response.json()["inscope"]["report"] == "in"
    assert response.json()["outscope"]["report"] == "out"


def test_generate_discovery_walkthrough_awaitable_success(monkeypatch) -> None:
    monkeypatch.setattr(router_module, "audit_generation_start", lambda **_k: (object(), object()))
    monkeypatch.setattr(router_module, "audit_ai_response", lambda **_k: None)

    async def _async_report():
        return {
            "report_title": "Discovery Walkthrough Preparation",
            "sections": [{"section_title": "A", "key_points": ["p1"]}],
        }

    monkeypatch.setattr(
        router_module,
        "get_discovery_walkthrough_service",
        lambda: SimpleNamespace(generate_report=lambda _plan_number: _async_report()),
    )

    response = client.post("/generate-discovery-walkthrough", json={"planNumber": "20587", "userDetails": {}})
    assert response.status_code == 200
    assert response.json()["report_title"] == "Discovery Walkthrough Preparation"


def test_generate_test_steps_and_update_paths(monkeypatch) -> None:
    monkeypatch.setattr(router_module, "audit_generation_start", lambda **_k: (object(), object()))
    monkeypatch.setattr(router_module, "audit_ai_response", lambda **_k: None)
    monkeypatch.setattr(router_module, "audit_revision", lambda **_k: None)

    generated = {
        "test_steps": [
            {
                "test_step": {"Step": "Do work"},
                "rationale": "Sampling tests control execution. Reperformance validates recorded outcomes.",
                "confidence_score": 75,
            }
        ]
    }

    monkeypatch.setattr(
        router_module,
        "get_test_steps_service",
        lambda: SimpleNamespace(
            generate_test_steps=lambda **_kwargs: generated,
            update_test_steps=lambda **_kwargs: generated,
        ),
    )

    generate_response = client.post("/generate-test-steps", json={"planNumber": "20587"})
    assert generate_response.status_code == 200
    assert generate_response.json()["test_steps"] == generated["test_steps"]

    update_response = client.put(
        "/update-test-steps",
        json={
            "planNumber": "20587",
            "test_steps": generated["test_steps"],
        },
    )
    assert update_response.status_code == 200
    assert update_response.json()["test_steps"] == generated["test_steps"]


def test_download_scope_recommendation_endpoint(monkeypatch) -> None:
    captured = {}

    def fake_download(**kwargs):
        captured.update(kwargs)
        return (
            b"%PDF-scope",
            {"Content-Disposition": 'attachment; filename="scope_recommendation_20587.pdf"'},
        )

    monkeypatch.setattr(
        router_module,
        "download_scope_recommendation_pdf",
        fake_download,
    )

    response = client.post(
        "/download-inscope-outscope",
        json={
            "planNumber": "20587",
            "inscope": {"report": "in", "rationale": "include because evidence"},
            "outscope": {"report": "out", "rationale": "exclude because evidence"},
        },
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content == b"%PDF-scope"
    assert captured["inscope"]["rationale"] == "include because evidence"
    assert captured["outscope"]["rationale"] == "exclude because evidence"