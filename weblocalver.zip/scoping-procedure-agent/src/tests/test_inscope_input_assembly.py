from pathlib import Path
import sys
import json
import logging
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.inscope_outscope_service import InScopeOutScopeService
from agents.llm_judge import SCOPE_REVIEW_RUBRIC_CALLS, SCOPE_REVIEW_PROMPT, ReviewLoopError
from model.response_model import InScopeOutScopeResponse, ScopeReport
from agents.llm_judge.models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
)


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


def test_generate_inscope_outscope_uploads_expected_json(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    structured_llm.invoke.side_effect = [_scope_candidate(), *_passing_rubric_responses()]

    result = service.generate_inscope_outscope("42")

    assert result == {
        "inscope": {
            "report": "In paragraph",
            "rationale": "In-scope evidence supports testing.",
            "confidence_score": 90,
        },
        "outscope": {
            "report": "Out paragraph",
            "rationale": "Out-of-scope evidence supports exclusion.",
            "confidence_score": 80,
        },
    }

    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/inscope.json",
        {
            "planNumber": "42",
            "inscope": {
                "report": "In paragraph",
                "rationale": "In-scope evidence supports testing.",
                "confidence_score": 90,
            },
        },
    )
    assert result.keys() == {"inscope", "outscope"}
    assert structured_llm.invoke.call_count == 5
    assert [call.args[0] for call in service.llm.with_structured_output.call_args_list] == [
        InScopeOutScopeResponse,
        *[
            SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
            for rubric_name, _expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
        ],
    ]
    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/outscope.json",
        {
            "planNumber": "42",
            "outscope": {
                "report": "Out paragraph",
                "rationale": "Out-of-scope evidence supports exclusion.",
                "confidence_score": 80,
            },
        },
    )


