from pathlib import Path
import sys
import json
import logging
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.inscope_outscope_service import InScopeOutScopeService
from agents.llm_judge import SCOPE_REVIEW_RUBRIC_CALLS, SCOPE_REVIEW_PROMPT, ReviewLoopError
from model.response_model import InScopeOutScopeResponse, ScopeReport
from agents.llm_judge.models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
)


def _passing_rubric_responses():
    return [
        {
            name: {
                "passed": True,
                "affected_fields": [],
                "issue": "",
                "action": "",
            }
            for name in expected_names
        }
        for _rubric, expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
    ]


def _failed_boundary_response():
    return {
        "scope_boundary_fidelity": {
            "passed": False,
            "affected_fields": ["inscope.report"],
            "issue": "Control C-202 is absent from PR Broad Scope Section 2.",
            "action": "Remove C-202 unless Section 2 lists it.",
        },
        "required_content_format": {
            "passed": True,
            "affected_fields": [],
            "issue": "",
            "action": "",
        },
    }


def _scope_candidate(inscope_report="In paragraph", outscope_report="Out paragraph"):
    return InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report=inscope_report,
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report=outscope_report,
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )


def _prompt_text(call):
    message = call.args[0][0]
    return message.content if hasattr(message, "content") else message["content"]


def test_gather_raw_data_uses_parts_and_leaves_missing_categories_empty(
    service_with_mocks, monkeypatch
):
    service, storage_manager, _ = service_with_mocks
    legacy_files = [
        "relevant_policy.json",
        "relevant_kod.json",
        "relevant_procedure.json",
    ]
    parts_folders = {
        "relevant_policy.json": "inbound-data/policy/relevant_policy",
        "relevant_kod.json": "inbound-data/policy/relevant_kod",
        "relevant_procedure.json": "inbound-data/policy/relevant_procedure",
    }
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "policy": {
                "folder": "inbound-data/policy",
                "files": legacy_files,
                "parts_folders": parts_folders,
            }
        },
    )
    storage_manager.list_blobs_in_folder.side_effect = [
        [
            "dbaware_review_123/inbound-data/policy/relevant_policy/policy2.json",
            "dbaware_review_123/inbound-data/policy/relevant_policy/policy1.json",
        ],
        [],
        [],
    ]
    storage_manager.download_json.side_effect = lambda path: {
        "dbaware_review_123/inbound-data/policy/relevant_policy/policy1.json": {
            "document_relevance_score": 0.2,
            "name": "policy1",
        },
        "dbaware_review_123/inbound-data/policy/relevant_policy/policy2.json": {
            "document_relevance_score": 0.9,
            "name": "policy2",
        },
    }[path]

    result = service.gather_raw_data("123")

    assert result == {
        "policy": {
            "relevant_policy.json": [
                {"document_relevance_score": 0.9, "name": "policy2"},
                {"document_relevance_score": 0.2, "name": "policy1"},
            ],
            "relevant_kod.json": [],
            "relevant_procedure.json": [],
        }
    }
    assert storage_manager.download_json.call_count == 2
    assert all(
        call.args[0].startswith("dbaware_review_123/inbound-data/policy/relevant_policy/")
        for call in storage_manager.download_json.call_args_list
    )


def test_gather_raw_data_falls_back_to_legacy_when_no_parts_exist(
    service_with_mocks, monkeypatch
):
    service, storage_manager, _ = service_with_mocks
    legacy_files = [
        "relevant_policy.json",
        "relevant_kod.json",
        "relevant_procedure.json",
    ]
    parts_folders = {
        "relevant_policy.json": "inbound-data/policy/relevant_policy",
        "relevant_kod.json": "inbound-data/policy/relevant_kod",
        "relevant_procedure.json": "inbound-data/policy/relevant_procedure",
    }
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "policy": {
                "folder": "inbound-data/policy",
                "files": legacy_files,
                "parts_folders": parts_folders,
            }
        },
    )
    storage_manager.list_blobs_in_folder.return_value = []
    storage_manager.download_json.side_effect = lambda path: {"path": path}

    result = service.gather_raw_data("123")

    assert result["policy"] == {
        file_name: {
            "path": f"dbaware_review_123/inbound-data/policy/{file_name}"
        }
        for file_name in legacy_files
    }
    assert storage_manager.download_json.call_count == 3
    assert storage_manager.list_blobs_in_folder.call_count == 3


def test_extract_json_object_handles_wrapped_json(service_with_mocks):
    service, _, _ = service_with_mocks

    wrapped_json = """Here is the response:\n```json\n{\"inscope\":\"In\",\"outscope\":\"Out\"}\n```"""

    parsed = service._extract_json_object(wrapped_json)

    assert parsed == {"inscope": "In", "outscope": "Out"}


def test_generate_inscope_outscope_uploads_expected_json(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    structured_llm.invoke.side_effect = [_scope_candidate(), *_passing_rubric_responses()]

    result = service.generate_inscope_outscope("42")

    assert result == {
        "inscope": {
            "report": "In paragraph",
            "rationale": "In-scope evidence supports testing.",
            "confidence_score": 90,
        },
        "outscope": {
            "report": "Out paragraph",
            "rationale": "Out-of-scope evidence supports exclusion.",
            "confidence_score": 80,
        },
    }

    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/inscope.json",
        {
            "planNumber": "42",
            "inscope": {
                "report": "In paragraph",
                "rationale": "In-scope evidence supports testing.",
                "confidence_score": 90,
            },
        },
    )
    assert result.keys() == {"inscope", "outscope"}
    assert structured_llm.invoke.call_count == 5
    assert [call.args[0] for call in service.llm.with_structured_output.call_args_list] == [
        InScopeOutScopeResponse,
        *[
            SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
            for rubric_name, _expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
        ],
    ]
    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/outscope.json",
        {
            "planNumber": "42",
            "outscope": {
                "report": "Out paragraph",
                "rationale": "Out-of-scope evidence supports exclusion.",
                "confidence_score": 80,
            },
        },
    )


