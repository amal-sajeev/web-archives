from unittest.mock import MagicMock

from agents.llm_judge import SCOPE_REVIEW_RUBRIC_CALLS
from agents.llm_judge.models import SCOPE_REVIEW_RESPONSE_MODELS
from conftest import (
    make_passing_rubric_responses as _passing_rubric_responses,
    make_scope_candidate as _scope_candidate,
)
from model.response_model import InScopeOutScopeResponse


def test_generate_inscope_outscope_uploads_expected_json(service_with_mocks, monkeypatch):
    service, storage_manager, structured_llm = service_with_mocks
    monkeypatch.setattr(service.config, "SCOPE_RECOMMENDATION_JUDGE_LOOP", True)

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    structured_llm.invoke.side_effect = [_scope_candidate(), *_passing_rubric_responses()]

    result, usage_metadata = service.generate_inscope_outscope("42")

    assert result == {
        "inscope": {
            "report": "In paragraph",
            "rationale": "In-scope evidence supports testing.",
            "confidence_score": 90,
        },
        "outscope": {
            "report": "Out paragraph",
            "rationale": "Out-of-scope evidence supports exclusion.",
            "confidence_score": 80,
        },
    }
    assert usage_metadata == {"input_tokens": 0, "output_tokens": 0}

    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/inscope.json",
        {
            "planNumber": "42",
            "inscope": {
                "report": "In paragraph",
                "rationale": "In-scope evidence supports testing.",
                "confidence_score": 90,
            },
        },
    )
    assert result.keys() == {"inscope", "outscope"}
    assert structured_llm.invoke.call_count == 5
    assert [call.args[0] for call in service.llm.with_structured_output.call_args_list] == [
        InScopeOutScopeResponse,
        *[
            SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
            for rubric_name, _expected_names, _instructions in SCOPE_REVIEW_RUBRIC_CALLS
        ],
    ]
    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/outscope.json",
        {
            "planNumber": "42",
            "outscope": {
                "report": "Out paragraph",
                "rationale": "Out-of-scope evidence supports exclusion.",
                "confidence_score": 80,
            },
        },
    )


def test_generate_inscope_outscope_accumulates_agent_usage_metadata(service_with_mocks):
    service, _storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    raw_msg = MagicMock(usage_metadata={"input_tokens": 310, "output_tokens": 95})
    structured_llm.invoke.side_effect = [
        {"raw": raw_msg, "parsed": _scope_candidate()},
        *_passing_rubric_responses(),
    ]

    _result, usage_metadata = service.generate_inscope_outscope("42")

    assert usage_metadata == {"input_tokens": 310, "output_tokens": 95}



