from pathlib import Path
import sys
import logging
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.inscope_outscope_service import InScopeOutScopeService
from model.response_model import InScopeOutScopeResponse, ScopeReport


@pytest.fixture
def service_with_mocks():
    with patch("service.inscope_outscope_service.StorageManager") as storage_cls, patch(
        "service.inscope_outscope_service.initialize_gemini_model"
    ) as llm_initializer:
        storage_manager = MagicMock()
        llm = MagicMock()
        structured_llm = MagicMock()
        llm.with_structured_output.return_value = structured_llm

        storage_cls.return_value = storage_manager
        llm_initializer.return_value = llm

        service = InScopeOutScopeService()

    return service, storage_manager, structured_llm


def test_gather_raw_data_downloads_all_configured_files(service_with_mocks, monkeypatch):
    service, storage_manager, _ = service_with_mocks

    raw_data_config = {
        "dbaware": {"folder": "inbound-data/dbaware", "files": ["file1.json", "file2.json"]},
        "gfms": {"folder": "inbound-data/gfms", "files": ["file3.json"]},
    }
    monkeypatch.setattr(service.config, "RAW_DATA_CONFIG", raw_data_config)

    storage_manager.download_json.side_effect = [{"k": 1}, {"k": 2}, {"k": 3}]

    result = service.gather_raw_data("123")

    assert result == {
        "dbaware": {"file1.json": {"k": 1}, "file2.json": {"k": 2}},
        "gfms": {"file3.json": {"k": 3}},
    }

    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/dbaware/file1.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/dbaware/file2.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_123/inbound-data/gfms/file3.json"
    )


def test_gather_all_review_data_labels_feedback_as_mom_summaries(service_with_mocks):
    service, _, _ = service_with_mocks
    mom_summary = {"normalized_meeting_notes": "Action: add control CTRL-1 to scope"}
    service.gather_preliminary_research_data = MagicMock(
        return_value={
            "preliminary_research": {"analysis_report": {}},
            "preliminary_research_feedback_summary": mom_summary,
        }
    )

    result = service.gather_all_review_data("123")
    review_inputs = result["preliminary_research_data"]

    assert review_inputs["meeting_mom_summaries"] == mom_summary
    assert "preliminary_research_feedback_summary" not in review_inputs


def test_gather_all_review_data_preserves_newly_gathered_mom_summaries(service_with_mocks):
    service, _, _ = service_with_mocks
    mom_summary = {"normalized_meeting_notes": "Confirm CTRL-1 with stakeholders"}
    service.gather_preliminary_research_data = MagicMock(
        return_value={
            "preliminary_research": {"analysis_report": {"Broad Scope": "PR scope"}},
            "meeting_mom_summaries": mom_summary,
        }
    )

    result = service.gather_all_review_data("123")

    assert result["preliminary_research_data"]["meeting_mom_summaries"] == mom_summary


def test_build_generation_prompt_separates_preliminary_research_and_moms(
    service_with_mocks,
):
    service, _, _ = service_with_mocks
    prompt = service._build_generation_prompt(
        "123",
        {
            "preliminary_research_data": {
                "preliminary_research": {"analysis_report": {"Broad Scope": "PR scope"}},
                "meeting_mom_summaries": {"normalized_meeting_notes": "Add CTRL-1"},
            }
        },
    )

    assert "Preliminary Research Report:" in prompt
    assert '"Broad Scope": "PR scope"' in prompt
    assert "Meeting Notes (MOM) Summary:" in prompt
    assert '"normalized_meeting_notes": "Add CTRL-1"' in prompt


def test_gather_raw_data_logs_found_and_missing_files(
    service_with_mocks, monkeypatch, caplog
):
    service, storage_manager, _ = service_with_mocks
    storage_manager.bucket_name = "test-bucket"
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "dbaware": {
                "folder": "inbound-data/dbaware",
                "files": ["found.json", "missing.json"],
            }
        },
    )
    storage_manager.download_json.side_effect = [{"data": True}, None]

    with caplog.at_level(logging.INFO):
        service.gather_raw_data("123", api_name="generate-test-steps")

    assert (
        "Input file FOUND api=generate-test-steps planNumber=123 "
        "uri=gs://test-bucket/dbaware_review_123/inbound-data/dbaware/found.json"
    ) in caplog.text
    assert (
        "Input file NOT FOUND api=generate-test-steps planNumber=123 "
        "uri=gs://test-bucket/dbaware_review_123/inbound-data/dbaware/missing.json"
    ) in caplog.text


def test_gather_raw_data_uses_parts_and_leaves_missing_categories_empty(
    service_with_mocks, monkeypatch
):
    service, storage_manager, _ = service_with_mocks
    legacy_files = [
        "relevant_policy.json",
        "relevant_kod.json",
        "relevant_procedure.json",
    ]
    parts_folders = {
        "relevant_policy.json": "inbound-data/policy/relevant_policy",
        "relevant_kod.json": "inbound-data/policy/relevant_kod",
        "relevant_procedure.json": "inbound-data/policy/relevant_procedure",
    }
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "policy": {
                "folder": "inbound-data/policy",
                "files": legacy_files,
                "parts_folders": parts_folders,
            }
        },
    )
    storage_manager.list_blobs_in_folder.side_effect = [
        [
            "dbaware_review_123/inbound-data/policy/relevant_policy/policy2.json",
            "dbaware_review_123/inbound-data/policy/relevant_policy/policy1.json",
        ],
        [],
        [],
    ]
    storage_manager.download_json.side_effect = lambda path: {
        "dbaware_review_123/inbound-data/policy/relevant_policy/policy1.json": {
            "document_relevance_score": 0.2,
            "name": "policy1",
        },
        "dbaware_review_123/inbound-data/policy/relevant_policy/policy2.json": {
            "document_relevance_score": 0.9,
            "name": "policy2",
        },
    }[path]

    result = service.gather_raw_data("123")

    assert result == {
        "policy": {
            "relevant_policy.json": [
                {"document_relevance_score": 0.9, "name": "policy2"},
                {"document_relevance_score": 0.2, "name": "policy1"},
            ],
            "relevant_kod.json": [],
            "relevant_procedure.json": [],
        }
    }
    assert storage_manager.download_json.call_count == 2
    assert all(
        call.args[0].startswith("dbaware_review_123/inbound-data/policy/relevant_policy/")
        for call in storage_manager.download_json.call_args_list
    )


def test_gather_raw_data_falls_back_to_legacy_when_no_parts_exist(
    service_with_mocks, monkeypatch
):
    service, storage_manager, _ = service_with_mocks
    legacy_files = [
        "relevant_policy.json",
        "relevant_kod.json",
        "relevant_procedure.json",
    ]
    parts_folders = {
        "relevant_policy.json": "inbound-data/policy/relevant_policy",
        "relevant_kod.json": "inbound-data/policy/relevant_kod",
        "relevant_procedure.json": "inbound-data/policy/relevant_procedure",
    }
    monkeypatch.setattr(
        service.config,
        "RAW_DATA_CONFIG",
        {
            "policy": {
                "folder": "inbound-data/policy",
                "files": legacy_files,
                "parts_folders": parts_folders,
            }
        },
    )
    storage_manager.list_blobs_in_folder.return_value = []
    storage_manager.download_json.side_effect = lambda path: {"path": path}

    result = service.gather_raw_data("123")

    assert result["policy"] == {
        file_name: {
            "path": f"dbaware_review_123/inbound-data/policy/{file_name}"
        }
        for file_name in legacy_files
    }
    assert storage_manager.download_json.call_count == 3
    assert storage_manager.list_blobs_in_folder.call_count == 3


def test_extract_json_object_handles_wrapped_json(service_with_mocks):
    service, _, _ = service_with_mocks

    wrapped_json = """Here is the response:\n```json\n{\"inscope\":\"In\",\"outscope\":\"Out\"}\n```"""

    parsed = service._extract_json_object(wrapped_json)

    assert parsed == {"inscope": "In", "outscope": "Out"}


def test_generate_inscope_outscope_uploads_expected_json(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    service._review_scope_candidate = MagicMock(
        return_value=MagicMock(approved=True, feedback="")
    )
    structured_llm.invoke.return_value = InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(
            report="In paragraph",
            rationale="In-scope evidence supports testing.",
            confidence_score=90,
        ),
        outscope=ScopeReport(
            report="Out paragraph",
            rationale="Out-of-scope evidence supports exclusion.",
            confidence_score=80,
        ),
    )

    result = service.generate_inscope_outscope("42")

    assert result == {
        "inscope": {
            "report": "In paragraph",
            "rationale": "In-scope evidence supports testing.",
            "confidence_score": 90,
        },
        "outscope": {
            "report": "Out paragraph",
            "rationale": "Out-of-scope evidence supports exclusion.",
            "confidence_score": 80,
        },
    }

    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/inscope.json",
        {
            "planNumber": "42",
            "inscope": {
                "report": "In paragraph",
                "rationale": "In-scope evidence supports testing.",
                "confidence_score": 90,
            },
        },
    )
    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/outscope.json",
        {
            "planNumber": "42",
            "outscope": {
                "report": "Out paragraph",
                "rationale": "Out-of-scope evidence supports exclusion.",
                "confidence_score": 80,
            },
        },
    )


def test_generate_inscope_outscope_raises_for_missing_content(service_with_mocks):
    service, _, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value={"sample": "data"})
    service._review_scope_candidate = MagicMock(
        return_value=MagicMock(approved=True, feedback="")
    )
    structured_llm.invoke.return_value = InScopeOutScopeResponse(
        planNumber="42",
        inscope=ScopeReport(report="", rationale="", confidence_score=0),
        outscope=ScopeReport(report="", rationale="", confidence_score=0),
    )

    with pytest.raises(ValueError, match="did not contain inscope or outscope"):
        service.generate_inscope_outscope("42")
