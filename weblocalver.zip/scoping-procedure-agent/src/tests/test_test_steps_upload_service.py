import asyncio
from io import BytesIO
from unittest.mock import MagicMock

import pytest
from fastapi import UploadFile

from model.response_model import TestStepsUploadValidation
from service import test_steps_upload_service


@pytest.fixture
def upload_service(monkeypatch):
    class FakeStorageManager:
        def __init__(self, project_name, bucket_name):
            self.writes = []

        def write_blob_bytes(self, path, content, content_type):
            self.writes.append((path, content, content_type))
            return f"gs://bucket/{path}"

    fake_storage = FakeStorageManager("proj", "bucket")

    monkeypatch.setattr(
        test_steps_upload_service,
        "StorageManager",
        lambda project_name, bucket_name: fake_storage,
    )

    llm = MagicMock()
    structured = MagicMock()
    llm.with_structured_output.return_value = structured
    monkeypatch.setattr(
        test_steps_upload_service,
        "initialize_gemini_model",
        lambda: llm,
    )

    service = test_steps_upload_service.TestStepsUploadService()
    return service, fake_storage, structured


def test_parse_uploaded_step_fields_handles_aliases_and_execution_approach_values():
    text = """
    Assessment Unit (AU): Payments
    Test Step Name and Number
    TS-1
    Execution Approach
    Design Effectiveness Testing Approach
    Operating Effectiveness Testing Approach
    Risk Type
    Financial Crime
    """

    parsed = (
        test_steps_upload_service.TestStepsUploadService._parse_uploaded_step_fields(
            text
        )
    )

    assert parsed["Assessment Unit"] == "Payments"
    assert (
        parsed["Execution Approach"]
        == "Design Effectiveness Testing Approach ; Operating Effectiveness Testing Approach"
    )
    assert parsed["Risk Type"].strip() == "Financial Crime"


def test_validate_test_steps_document_returns_invalid_when_empty(
    upload_service, monkeypatch
):
    service, _, _ = upload_service
    monkeypatch.setattr(test_steps_upload_service, "extract_text", lambda *_: "")

    validation, extracted = service._validate_test_steps_document("test.txt", b"data")

    assert validation.is_valid is False
    assert validation.document_type == "not_test_steps"
    assert extracted == ""


def test_validate_test_steps_document_handles_guardrail_exception(
    upload_service, monkeypatch
):
    service, _, structured = upload_service
    structured.invoke.side_effect = RuntimeError("llm down")

    monkeypatch.setattr(
        test_steps_upload_service,
        "extract_text",
        lambda *_: "\n".join(
            [
                "Test Step Name and Number",
                "Execution Approach",
                "Overview of Risk(s) to be Considered in this Workpaper",
                "Assessment Unit",
                "Risk Type",
                "Design Effectiveness Testing Approach",
                "Operating Effectiveness Testing Approach",
                "Core Processes",
            ]
        ),
    )

    validation, _ = service._validate_test_steps_document("step.txt", b"content")

    assert validation.is_valid is False
    assert validation.document_type == "not_test_steps"
    assert "guardrail check failed" in validation.reason.lower()


def test_process_upload_rejects_missing_files(upload_service):
    service, _, _ = upload_service

    with pytest.raises(ValueError, match="At least one test-steps supporting document"):
        asyncio.run(service.process_upload("42", []))


def test_process_upload_rejects_unsupported_extension(upload_service):
    service, _, _ = upload_service
    files = [UploadFile(file=BytesIO(b"data"), filename="steps.xlsx")]

    with pytest.raises(ValueError, match="Unsupported file type"):
        asyncio.run(service.process_upload("42", files))


def test_process_upload_returns_confirmation_with_validated_files(
    upload_service, monkeypatch
):
    service, _, _ = upload_service

    def fake_validate(filename, content):
        return (
            TestStepsUploadValidation(
                filename=filename,
                is_valid=True,
                reason="valid",
                document_type="test_steps",
            ),
            """Test Step Name and Number\nTS-001\nExecution Approach\nDesign Effectiveness Testing Approach""",
        )

    monkeypatch.setattr(service, "_validate_test_steps_document", fake_validate)

    files = [UploadFile(file=BytesIO(b"abc"), filename="steps.txt")]
    response = asyncio.run(service.process_upload("123", files))

    assert response.planNumber == "123"
    assert response.upload_completed is False
    assert response.confirmation_required is True
    assert response.validated_files
    assert response.validated_files[0]["filename"].endswith(".txt")
    assert response.validation_results[0].is_valid is True


def test_process_upload_returns_no_confirmation_when_all_invalid(
    upload_service, monkeypatch
):
    service, _, _ = upload_service

    monkeypatch.setattr(
        service,
        "_validate_test_steps_document",
        lambda filename, content: (
            TestStepsUploadValidation(
                filename=filename,
                is_valid=False,
                reason="invalid",
                document_type="not_test_steps",
            ),
            "n/a",
        ),
    )

    files = [UploadFile(file=BytesIO(b"abc"), filename="steps.txt")]
    response = asyncio.run(service.process_upload("321", files))

    assert response.upload_completed is False
    assert response.confirmation_required is False
    assert response.validated_files is None


def test_confirm_pending_upload_requires_confirmation(upload_service):
    service, _, _ = upload_service

    with pytest.raises(ValueError, match="User confirmation is required"):
        service.confirm_pending_upload("42", [], confirmed=False)


def test_confirm_pending_upload_uploads_files(upload_service):
    service, fake_storage, _ = upload_service

    response = service.confirm_pending_upload(
        "Plan 1",
        [
            {"filename": "step one.txt", "content": "YWJj"},
        ],
        confirmed=True,
    )

    assert response.upload_completed is True
    assert response.confirmation_required is False
    assert response.uploaded_documents[0].filename == "step_one.txt"
    assert fake_storage.writes
