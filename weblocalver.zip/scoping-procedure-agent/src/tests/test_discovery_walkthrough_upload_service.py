import asyncio
from io import BytesIO
from unittest.mock import MagicMock

import pytest
from fastapi import UploadFile

from model.response_model import DiscoveryWalkthroughQuestionBankValidation
from service import discovery_walkthrough_upload_service


@pytest.fixture
def upload_service(monkeypatch):
    class FakeStorageManager:
        def __init__(self, project_name, bucket_name):
            self.writes = []
            self.blobs = []
            self.downloads = {}

        def write_blob_bytes(self, path, content, content_type):
            self.writes.append((path, content, content_type))
            return f"gs://bucket/{path}"

        def list_blobs_in_folder(self, folder):
            return self.blobs

        def download_blob_bytes(self, name):
            if name == "raise.txt":
                raise RuntimeError("boom")
            return self.downloads.get(name, b"")

    fake_storage = FakeStorageManager("proj", "bucket")

    monkeypatch.setattr(
        discovery_walkthrough_upload_service,
        "StorageManager",
        lambda project_name, bucket_name: fake_storage,
    )

    llm = MagicMock()
    structured = MagicMock()
    llm.with_structured_output.return_value = structured
    monkeypatch.setattr(
        discovery_walkthrough_upload_service,
        "initialize_gemini_model",
        lambda: llm,
    )

    service = discovery_walkthrough_upload_service.DiscoveryWalkthroughUploadService()
    return service, fake_storage, structured


def test_question_line_detection_covers_multiple_styles():
    svc = discovery_walkthrough_upload_service.DiscoveryWalkthroughUploadService

    assert svc._has_actual_question_line("What controls exist?") is True
    assert svc._has_actual_question_line("Q1: Describe process") is True
    assert svc._has_actual_question_line("Narrative line only") is False


def test_validate_question_bank_short_circuits_on_reference(
    upload_service, monkeypatch
):
    service, _, _ = upload_service
    monkeypatch.setattr(
        discovery_walkthrough_upload_service,
        "extract_text",
        lambda *_: "#SYM:discovery_walkthrough_question_bank",
    )

    validation = service._validate_question_bank_document("dw.txt", b"data")

    assert validation.is_valid is True
    assert validation.document_type == "question_bank"


def test_validate_question_bank_rejects_non_question_text(upload_service, monkeypatch):
    service, _, _ = upload_service
    monkeypatch.setattr(
        discovery_walkthrough_upload_service,
        "extract_text",
        lambda *_: "This is a status update with no prompts.",
    )

    validation = service._validate_question_bank_document("dw.txt", b"data")

    assert validation.is_valid is False
    assert validation.document_type == "not_question_bank"


def test_validate_question_bank_handles_guardrail_exception(
    upload_service, monkeypatch
):
    service, _, structured = upload_service
    structured.invoke.side_effect = RuntimeError("llm down")
    monkeypatch.setattr(
        discovery_walkthrough_upload_service,
        "extract_text",
        lambda *_: "What controls are in place?\nHow do you monitor exceptions?",
    )

    validation = service._validate_question_bank_document("dw.txt", b"data")

    assert validation.is_valid is False
    assert "guardrail" in validation.reason.lower()


def test_process_upload_rejects_empty_and_unsupported(upload_service):
    service, _, _ = upload_service

    with pytest.raises(ValueError, match="At least one discovery-walkthrough"):
        asyncio.run(service.process_upload("42", []))

    with pytest.raises(ValueError, match="Unsupported file type"):
        asyncio.run(
            service.process_upload(
                "42", [UploadFile(file=BytesIO(b"x"), filename="dw.xlsx")]
            )
        )


def test_process_upload_returns_confirmation_with_valid_files(
    upload_service, monkeypatch
):
    service, _, _ = upload_service

    monkeypatch.setattr(
        service,
        "_validate_question_bank_document",
        lambda filename, content: DiscoveryWalkthroughQuestionBankValidation(
            filename=filename,
            is_valid=True,
            reason="valid",
            document_type="question_bank",
        ),
    )

    response = asyncio.run(
        service.process_upload(
            "99", [UploadFile(file=BytesIO(b"abc"), filename="dw notes.txt")]
        )
    )

    assert response.upload_completed is False
    assert response.confirmation_required is True
    assert response.validated_files
    assert response.validated_files[0]["filename"] == "dw_notes.txt"


def test_confirm_pending_upload_and_load_question_bank(upload_service, monkeypatch):
    service, fake_storage, _ = upload_service

    with pytest.raises(ValueError, match="User confirmation is required"):
        service.confirm_pending_upload("77", [], confirmed=False)

    confirmed = service.confirm_pending_upload(
        "77",
        [{"filename": "dw one.txt", "content": "YWJj"}],
        confirmed=True,
    )
    assert confirmed.upload_completed is True
    assert fake_storage.writes

    fake_storage.blobs = ["a.txt", "b.txt", "raise.txt"]
    fake_storage.downloads = {
        "a.txt": b"What controls are in place?",
        "b.txt": b"What controls are in place?",  # duplicate text should dedupe
    }
    monkeypatch.setattr(
        discovery_walkthrough_upload_service,
        "extract_text",
        lambda filename, content: content.decode("utf-8"),
    )

    loaded = service.load_question_bank("77")
    assert len(loaded["question_documents"]) == 1
    assert loaded["question_documents"][0]["filename"] == "a.txt"
