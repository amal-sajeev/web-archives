from utils import storage_manager


class FakeBlob:
    def __init__(self) -> None:
        self.string_write = None
        self.file_write = None

    def upload_from_string(self, content, content_type) -> None:
        self.string_write = (content, content_type)

    def upload_from_file(self, file, content_type, rewind) -> None:
        self.file_write = (file.read(), content_type, rewind)


class FakeBucket:
    name = "review-bucket"

    def __init__(self) -> None:
        self.blobs = {}

    def blob(self, name: str) -> FakeBlob:
        return self.blobs.setdefault(name, FakeBlob())


def test_storage_manager_initializes_client_and_bucket(monkeypatch) -> None:
    bucket = FakeBucket()
    captured = {}

    class FakeClient:
        def __init__(self, project=None):
            captured["project"] = project

        def bucket(self, name):
            captured["bucket"] = name
            return bucket

    monkeypatch.setattr(storage_manager.storage, "Client", FakeClient)

    manager = storage_manager.StorageManager("project-x", "review-bucket")

    assert captured["project"] == "project-x"
    assert captured["bucket"] == "review-bucket"
    assert manager.bucket is bucket


def test_write_blob_helpers_write_expected_content(monkeypatch) -> None:
    bucket = FakeBucket()
    monkeypatch.setattr(
        storage_manager.storage,
        "Client",
        lambda project=None: type("Client", (), {"bucket": lambda self, name: bucket})(),
    )

    manager = storage_manager.StorageManager("project-x", "review-bucket")

    assert manager.write_blob_bytes("notes.pdf", b"pdf", "application/pdf") == "gs://review-bucket/notes.pdf"
    assert bucket.blobs["notes.pdf"].string_write == (b"pdf", "application/pdf")

    manager.write_blob_json("summary.json", {"status": "ok"})
    assert bucket.blobs["summary.json"].string_write[1] == "application/json"