import asyncio
from io import BytesIO

from docx import Document
from fastapi import UploadFile

from model.request_model import MeetingNotesUploadRequest
from service import meeting_notes_service
from utils.document_processor import extract_text


def _build_docx_bytes() -> bytes:
    document = Document()
    document.add_paragraph("Decision: approve budget")
    table = document.add_table(rows=1, cols=2)
    table.rows[0].cells[0].text = "Owner"
    table.rows[0].cells[1].text = "Jane Doe"
    buffer = BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def test_extract_text_keeps_utf8_meeting_notes() -> None:
    assert extract_text("notes.txt", b"Meeting decision") == "Meeting decision"


def test_extract_text_marks_unsupported_document_as_source_material() -> None:
    assert "text extraction is not configured" in extract_text("notes.docx", b"binary")


def test_extract_text_reads_paragraphs_and_tables_from_docx() -> None:
    text = extract_text("notes.docx", _build_docx_bytes())

    assert "Decision: approve budget" in text
    assert "Owner | Jane Doe" in text


def test_process_meeting_notes_normalizes_before_writing_documents(monkeypatch) -> None:
    writes = []

    async def fake_normalize(plan_item_number: str, source_notes: list[str]) -> str:
        assert plan_item_number == "12345"
        assert source_notes == ["Decision: approve"]
        assert not writes
        return "# Normalized notes"

    monkeypatch.setattr(meeting_notes_service, "normalize", fake_normalize)
    monkeypatch.setattr(
        meeting_notes_service,
        "convert_to_pdf",
        lambda filename, content: ("notes.pdf", b"%PDF-1.4"),
    )

    class FakeStorageManager:
        def __init__(self, project_name, bucket_name):
            pass

        def write_blob_bytes(self, path, content, content_type):
            writes.append((path, content_type))
            return f"gs://bucket/{path}"

        def write_blob_json(self, path, payload):
            writes.append((path, payload))
            return f"gs://bucket/{path}"

    monkeypatch.setattr(meeting_notes_service, "StorageManager", FakeStorageManager)
    service = meeting_notes_service.MeetingNotesService()

    request = MeetingNotesUploadRequest(
        planNumber="12345",
        files=[UploadFile(file=BytesIO(b"Decision: approve"), filename="notes.txt")],
    )

    response = asyncio.run(service.process_meeting_notes(request))

    review_folder = "dbaware_review_12345"
    assert response.planNumber == "12345"
    assert response.uploaded_documents[0].document_url == (
        f"gs://bucket/{review_folder}/processing-data/preliminary-research/"
        "preliminary-research-user-feedback/notes.pdf"
    )
    assert response.normalized_summary_uri == (
        f"gs://bucket/{review_folder}/processing-data/preliminary-research/"
        "preliminary-research-user-feedback-summary.json"
    )
    assert writes[0][1] == "application/pdf"
    assert writes[1][1]["normalized_meeting_notes"] == "# Normalized notes"