from pathlib import Path
import json
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.test_steps_service import (
    TestStepsRefinementTargetNotFoundError,
    TestStepsService,
)
from model.response_model import (
    RegeneratedTestStepParts,
    TestStep,
    TestStepsRefinementTargets,
    TestStepsResponse,
)


def _review_data():
    return {
        "raw_data": {
            "dbaware": {
                "alc_nalc_details.json": None,
                "historical_plan_details.json": None,
                "plan_details.json": None,
            },
            "dbgrc": {
                "control_details.json": None,
                "risk_driver_details.json": None,
            },
            "gfms": {"findings_details.json": None},
            "lrr": {"internet_search_data.json": None},
            "policy": {
                "relevant_policy.json": [],
                "relevant_kod.json": [],
                "relevant_procedure.json": [],
            },
        },
        "preliminary_research_data": {},
        "inscope_outscope_data": {},
    }


@pytest.fixture
def service_with_mocks(monkeypatch):
    with patch("service.inscope_outscope_service.StorageManager") as storage_cls, patch(
        "service.inscope_outscope_service.initialize_gemini_model"
    ) as llm_initializer, patch(
        "service.test_steps_service.TestStepsRegenerationService"
    ) as regeneration_service_cls:
        storage_manager = MagicMock()
        llm = MagicMock()
        structured_llm = MagicMock()
        llm.with_structured_output.return_value = structured_llm

        storage_cls.return_value = storage_manager
        llm_initializer.return_value = llm
        regeneration_service_cls.return_value.should_regenerate_test_steps.return_value = (
            False
        )

        service = TestStepsService()

    regeneration_service = MagicMock()
    regeneration_service.should_regenerate_test_steps.return_value = False
    monkeypatch.setattr(
        "service.test_steps_service.TestStepsRegenerationService",
        lambda: regeneration_service,
    )

    return service, storage_manager, structured_llm


def test_gather_inscope_outscope_data_downloads_expected_files(service_with_mocks):
    service, storage_manager, _ = service_with_mocks

    storage_manager.download_json.side_effect = [
        {"inscope": "In paragraph"},
        {"outscope": "Out paragraph"},
    ]

    result = service.gather_inscope_outscope_data("42")

    assert result == {
        "inscope": {"inscope": "In paragraph"},
        "outscope": {"outscope": "Out paragraph"},
    }

    storage_manager.download_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/inscope.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/outscope.json"
    )


def test_generate_test_steps_regeneration_returns_result_and_usage(service_with_mocks, monkeypatch):
    service, _, _ = service_with_mocks
    regeneration_service = MagicMock()
    regeneration_service.should_regenerate_test_steps.return_value = True
    regeneration_service.regenerate_test_steps.return_value = {"test_steps": [{"test_step": {"name": "existing"}}]}
    monkeypatch.setattr("service.test_steps_service.TestStepsRegenerationService", lambda: regeneration_service)

    result, usage = service.generate_test_steps("42")

    assert result == regeneration_service.regenerate_test_steps.return_value
    assert usage == {}
    regeneration_service.regenerate_test_steps.assert_called_once_with("42")


def test_generate_test_steps_uploads_expected_json(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks

    step = {
        "test_step": {
            "test_step_name_and_number": "Test Step 1: Onboarding Controls",
            "execution_approach": "OE",
        },
        "rationale": "Sampling tests whether onboarding controls operate consistently.",
        "confidence_score": 82,
    }
    service.gather_all_review_data = MagicMock(return_value=_review_data())
    structured_llm.invoke.return_value = TestStepsResponse(
        planNumber="42",
        test_steps=[step],
    )

    result_payload, usage_metadata = service.generate_test_steps("42")

    service.llm.with_structured_output.assert_called_once_with(
        TestStepsResponse,
        include_raw=True,
    )
    assert result_payload == {
        "test_steps": [step],
    }
    assert usage_metadata == {"input_tokens": 0, "output_tokens": 0}

    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/test-steps.json",
        {
            "planNumber": "42",
            "test_steps": [step],
        },
    )


def _refinement_step(number: int, title: str, policy: str) -> TestStep:
    return TestStep(
        test_step={
            "Test Step Name and Number": f"Test Step {number}: {title}",
            "Core Processes": None,
            "DB Policies": policy,
        },
        rationale=f"Testing validates {title} controls.",
        confidence_score=80,
    )


def test_refine_test_steps_regenerates_only_affected_parts(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks
    steps = [
        _refinement_step(1, "Supervision", "**Policy A**\n* Section 1\n\n**Policy B**\n* Section 2"),
        _refinement_step(2, "Market Abuse", "**Policy C**\n* Section 3"),
    ]
    structured_llm.invoke.side_effect = [
        TestStepsRefinementTargets(affected_part_ids=["S1.F3", "S1.RATIONALE"]),
        RegeneratedTestStepParts(
            parts=[
                {"part_id": "S1.F3", "value": "**Policy A**\n* Section 1"},
                {"part_id": "S1.RATIONALE", "value": "Testing validates supervision under Policy A."},
            ],
        ),
    ]

    result = service.refine_test_steps("42", steps, "Remove Policy B")

    first, second = result["test_steps"]
    assert first["test_step"]["DB Policies"] == "**Policy A**\n* Section 1"
    assert first["test_step"]["Core Processes"] is None
    assert first["rationale"] == "Testing validates supervision under Policy A."
    assert first["confidence_score"] == 80
    assert second == steps[1].model_dump()
    identify_prompt = structured_llm.invoke.call_args_list[0].args[0][0].content
    assert "Remove Policy B" in identify_prompt
    assert '"part_id": "S2.F3"' in identify_prompt
    regenerate_prompt = structured_llm.invoke.call_args_list[1].args[0][0].content
    assert '"part_id": "S2.F3"' not in regenerate_prompt
    storage_manager.upload_json.assert_not_called()


def test_refine_test_steps_drops_emptied_step_and_renumbers(service_with_mocks):
    service, _, structured_llm = service_with_mocks
    steps = [
        _refinement_step(1, "Supervision", "**Policy A**"),
        _refinement_step(2, "Market Abuse", "**Policy C**"),
    ]
    structured_llm.invoke.side_effect = [
        TestStepsRefinementTargets(affected_part_ids=["S1.F1", "S1.F3", "S1.RATIONALE"]),
        RegeneratedTestStepParts(
            parts=[
                {"part_id": "S1.F1", "value": ""},
                {"part_id": "S1.F3", "value": ""},
                {"part_id": "S1.RATIONALE", "value": ""},
            ]
        ),
    ]

    result = service.refine_test_steps("42", steps, "Remove test step 1")

    assert len(result["test_steps"]) == 1
    remaining = result["test_steps"][0]
    assert remaining["test_step"]["Test Step Name and Number"] == "Test Step 1: Market Abuse"
    assert remaining["test_step"]["DB Policies"] == "**Policy C**"
    assert remaining["rationale"] == steps[1].rationale


def test_refine_test_steps_removes_field_for_blank_and_keeps_it_for_null(service_with_mocks):
    service, _, structured_llm = service_with_mocks
    steps = [
        _refinement_step(1, "Supervision", "**Policy A**"),
        _refinement_step(2, "Market Abuse", "**Policy C**"),
    ]
    structured_llm.invoke.side_effect = [
        TestStepsRefinementTargets(affected_part_ids=["S1.F3", "S2.F3"]),
        RegeneratedTestStepParts(
            parts=[
                {"part_id": "S1.F3", "value": ""},
                {"part_id": "S2.F3", "value": None},
            ]
        ),
    ]

    result = service.refine_test_steps("42", steps, "Remove DB Policies")

    first, second = result["test_steps"]
    assert "DB Policies" not in first["test_step"]
    assert first["test_step"]["Test Step Name and Number"] == "Test Step 1: Supervision"
    assert "DB Policies" in second["test_step"]
    assert second["test_step"]["DB Policies"] is None
    assert second["rationale"] == steps[1].rationale
    assert second["confidence_score"] == steps[1].confidence_score


def test_refine_test_steps_keeps_step_when_all_content_is_cleared(service_with_mocks):
    service, _, structured_llm = service_with_mocks
    steps = [_refinement_step(1, "Supervision", "**Policy A**")]
    structured_llm.invoke.side_effect = [
        TestStepsRefinementTargets(affected_part_ids=["S1.F1", "S1.F3"]),
        RegeneratedTestStepParts(
            parts=[
                {"part_id": "S1.F1", "value": None},
                {"part_id": "S1.F3", "value": None},
            ]
        ),
    ]

    result = service.refine_test_steps("42", steps, "Delete all data from Test step 1")

    assert len(result["test_steps"]) == 1
    step = result["test_steps"][0]
    assert step["test_step"] == {
        "Test Step Name and Number": None,
        "Core Processes": None,
        "DB Policies": None,
    }
    assert step["rationale"] == steps[0].rationale
    assert step["confidence_score"] == steps[0].confidence_score


def test_refine_test_steps_rejects_unmatched_comment(service_with_mocks):
    service, _, structured_llm = service_with_mocks
    structured_llm.invoke.return_value = TestStepsRefinementTargets(
        affected_part_ids=["S9.F1"]
    )

    with pytest.raises(TestStepsRefinementTargetNotFoundError):
        service.refine_test_steps(
            "42", [_refinement_step(1, "Supervision", "**Policy A**")], "Remove Policy Z"
        )

    assert structured_llm.invoke.call_count == 1


def test_refine_test_steps_retries_when_field_gains_content(service_with_mocks):
    service, _, structured_llm = service_with_mocks
    targets = TestStepsRefinementTargets(affected_part_ids=["S1.F3"])
    grown = RegeneratedTestStepParts(
        parts=[{"part_id": "S1.F3", "value": "**Policy A** with added commentary"}]
    )
    structured_llm.invoke.side_effect = [targets, grown, grown]

    with pytest.raises(ValueError, match="failed validation"):
        service.refine_test_steps(
            "42", [_refinement_step(1, "Supervision", "**Policy A**")], "Remove Policy A"
        )

    assert structured_llm.invoke.call_count == 3


def test_generation_prompt_requires_verbatim_policy_and_procedure_sections(service_with_mocks):
    service, _, _ = service_with_mocks
    original_text = "4.5 Governance\nExact policy requirement."
    review_data = _review_data()
    review_data["raw_data"]["policy"]["relevant_policy.json"] = [
        {
            "document_title": "Example Policy",
            "nodes": [
                {
                    "section_id": "4.5",
                    "section_title": "Governance",
                    "original_text": original_text,
                }
            ],
        }
    ]
    risk_driver = {"risk_number": "R-17", "risk_driver_number": "RD-4"}
    review_data["raw_data"]["dbgrc"]["risk_driver_details.json"] = [risk_driver]

    prompt = service._build_generation_prompt("42", review_data)

    assert "reproduce that node's `original_text` exactly" in prompt
    assert "Risk Crystallisation Scenarios:" in prompt
    assert "risk drivers explicitly associated with that risk" in prompt
    for source_label in (
        "dbaware.historical_plan_details.json:",
        "dbaware.plan_details.json:",
        "dbgrc.risk_driver_details.json:",
        "lrr.internet_search_data.json:",
        "policy.relevant_policy.json:",
        "policy.relevant_kod.json:",
        "policy.relevant_procedure.json:",
    ):
        assert source_label in prompt
    for removed_label in (
        "dbaware.alc_nalc_details.json:",
        "dbgrc.control_details.json:",
        "gfms.findings_details.json:",
    ):
        assert removed_label not in prompt
    assert '"section_id": "4.5"' in prompt
    assert '"section_title": "Governance"' in prompt
    assert '"risk_driver_number": "RD-4"' in prompt
    assert json.dumps(original_text)[1:-1] in prompt


def test_generate_test_steps_raises_for_missing_content(service_with_mocks):
    service, _, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value=_review_data())
    structured_llm.invoke.return_value = TestStepsResponse(
        planNumber="42",
        test_steps=[],
    )

    with pytest.raises(ValueError, match="did not contain test_steps"):
        service.generate_test_steps("42")


def test_test_steps_response_rejects_missing_metadata():
    with pytest.raises(ValueError):
        TestStepsResponse(
            planNumber="42",
            test_steps=[{"test_step": {"test_step_name_and_number": "Test Step 1"}}],
        )


@pytest.mark.parametrize("score", [-1, 101])
def test_test_steps_response_rejects_invalid_step_confidence(score):
    with pytest.raises(ValueError):
        TestStepsResponse(
            planNumber="42",
            test_steps=[{"test_step": {}, "rationale": "Testing addresses the risk.", "confidence_score": score}],
        )


@pytest.mark.parametrize(
    "metadata",
    [
        {},
        {"rationale": "Sampling tests control execution."},
        {"confidence_score": 75},
        {"rationale": "", "confidence_score": 0},
        {"rationale": "   ", "confidence_score": 75},
    ],
)
def test_generation_rejects_invalid_metadata_after_retry(service_with_mocks, metadata):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value=_review_data())
    structured_llm.invoke.return_value = SimpleNamespace(
        model_dump=MagicMock(return_value={
            "planNumber": "42",
            "test_steps": [{"test_step": {"execution_approach": "OE"}, **metadata}],
        }),
    )

    with pytest.raises(ValueError):
        service.generate_test_steps("42")

    assert structured_llm.invoke.call_count == 2
    storage_manager.upload_json.assert_not_called()


def test_generation_retries_missing_metadata_and_saves_corrected_response(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value=_review_data())
    corrected = TestStepsResponse(
        planNumber="42",
        test_steps=[{
            "test_step": {"execution_approach": "OE"},
            "rationale": "Sampling tests control execution. Reperformance validates recorded outcomes.",
            "confidence_score": 75,
        }],
    )
    structured_llm.invoke.side_effect = [
        SimpleNamespace(model_dump=MagicMock(return_value={
            "planNumber": "42", "test_steps": [{"test_step": {}}],
        })),
        corrected,
    ]

    result_payload, usage_metadata = service.generate_test_steps("42")

    assert result_payload["test_steps"] == corrected.model_dump()["test_steps"]
    assert isinstance(usage_metadata, dict)
    assert structured_llm.invoke.call_count == 2
    storage_manager.upload_json.assert_called_once()


def test_generation_schema_requires_step_metadata():
    schema = TestStepsResponse.model_json_schema()
    assert set(schema["$defs"]["TestStep"]["required"]) == {
        "test_step", "rationale", "confidence_score"
    }
