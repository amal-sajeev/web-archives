from pathlib import Path
import json
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "main"))

from service.test_steps_service import TestStepsService
from model.response_model import TestStepsResponse


def _review_data():
    return {
        "raw_data": {
            "dbaware": {
                "alc_nalc_details.json": None,
                "historical_plan_details.json": None,
                "plan_details.json": None,
            },
            "dbgrc": {
                "control_details.json": None,
                "risk_driver_details.json": None,
            },
            "gfms": {"findings_details.json": None},
            "lrr": {"internet_search_data.json": None},
            "policy": {
                "relevant_policy.json": [],
                "relevant_kod.json": [],
                "relevant_procedure.json": [],
            },
        },
        "preliminary_research_data": {},
        "inscope_outscope_data": {},
    }


@pytest.fixture
def service_with_mocks():
    with patch("service.inscope_outscope_service.StorageManager") as storage_cls, patch(
        "service.inscope_outscope_service.initialize_gemini_model"
    ) as llm_initializer:
        storage_manager = MagicMock()
        llm = MagicMock()
        structured_llm = MagicMock()
        llm.with_structured_output.return_value = structured_llm

        storage_cls.return_value = storage_manager
        llm_initializer.return_value = llm

        service = TestStepsService()

    return service, storage_manager, structured_llm


def test_gather_inscope_outscope_data_downloads_expected_files(service_with_mocks):
    service, storage_manager, _ = service_with_mocks

    storage_manager.download_json.side_effect = [
        {"inscope": "In paragraph"},
        {"outscope": "Out paragraph"},
    ]

    result = service.gather_inscope_outscope_data("42")

    assert result == {
        "inscope": {"inscope": "In paragraph"},
        "outscope": {"outscope": "Out paragraph"},
    }

    storage_manager.download_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/inscope.json"
    )
    storage_manager.download_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/outscope.json"
    )


def test_generate_test_steps_uploads_expected_json(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks

    step = {
        "test_step": {
            "test_step_name_and_number": "Test Step 1: Onboarding Controls",
            "execution_approach": "OE",
        },
        "rationale": "Sampling tests whether onboarding controls operate consistently.",
        "confidence_score": 82,
    }
    service.gather_all_review_data = MagicMock(return_value=_review_data())
    structured_llm.invoke.return_value = TestStepsResponse(
        planNumber="42",
        test_steps=[step],
    )

    result = service.generate_test_steps("42")

    service.llm.with_structured_output.assert_called_once_with(TestStepsResponse)
    assert result == {
        "test_steps": [step],
    }

    storage_manager.upload_json.assert_any_call(
        "dbaware_review_42/processing-data/procedure/test-steps.json",
        {
            "planNumber": "42",
            "test_steps": [step],
        },
    )


def test_generation_prompt_requires_verbatim_policy_and_procedure_sections(service_with_mocks):
    service, _, _ = service_with_mocks
    original_text = "4.5 Governance\nExact policy requirement."
    review_data = _review_data()
    review_data["raw_data"]["policy"]["relevant_policy.json"] = [
        {
            "document_title": "Example Policy",
            "nodes": [
                {
                    "section_id": "4.5",
                    "section_title": "Governance",
                    "original_text": original_text,
                }
            ],
        }
    ]
    risk_driver = {"risk_number": "R-17", "risk_driver_number": "RD-4"}
    review_data["raw_data"]["dbgrc"]["risk_driver_details.json"] = [risk_driver]

    prompt = service._build_generation_prompt("42", review_data)

    assert "reproduce that node's `original_text` exactly" in prompt
    assert "Risk Crystallisation Scenarios:" in prompt
    assert "risk drivers explicitly associated with that risk" in prompt
    for source_label in (
        "dbaware.historical_plan_details.json:",
        "dbaware.plan_details.json:",
        "dbgrc.risk_driver_details.json:",
        "lrr.internet_search_data.json:",
        "policy.relevant_policy.json:",
        "policy.relevant_kod.json:",
        "policy.relevant_procedure.json:",
    ):
        assert source_label in prompt
    for removed_label in (
        "dbaware.alc_nalc_details.json:",
        "dbgrc.control_details.json:",
        "gfms.findings_details.json:",
    ):
        assert removed_label not in prompt
    assert '"section_id": "4.5"' in prompt
    assert '"section_title": "Governance"' in prompt
    assert '"risk_driver_number": "RD-4"' in prompt
    assert json.dumps(original_text)[1:-1] in prompt


def test_generate_test_steps_raises_for_missing_content(service_with_mocks):
    service, _, structured_llm = service_with_mocks

    service.gather_all_review_data = MagicMock(return_value=_review_data())
    structured_llm.invoke.return_value = TestStepsResponse(
        planNumber="42",
        test_steps=[],
    )

    with pytest.raises(ValueError, match="did not contain test_steps"):
        service.generate_test_steps("42")


def test_test_steps_response_rejects_missing_metadata():
    with pytest.raises(ValueError):
        TestStepsResponse(
            planNumber="42",
            test_steps=[{"test_step": {"test_step_name_and_number": "Test Step 1"}}],
        )


@pytest.mark.parametrize("score", [-1, 101])
def test_test_steps_response_rejects_invalid_step_confidence(score):
    with pytest.raises(ValueError):
        TestStepsResponse(
            planNumber="42",
            test_steps=[{"test_step": {}, "rationale": "Testing addresses the risk.", "confidence_score": score}],
        )


@pytest.mark.parametrize(
    "metadata",
    [
        {},
        {"rationale": "Sampling tests control execution."},
        {"confidence_score": 75},
        {"rationale": "", "confidence_score": 0},
        {"rationale": "   ", "confidence_score": 75},
    ],
)
def test_generation_rejects_invalid_metadata_after_retry(service_with_mocks, metadata):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value=_review_data())
    structured_llm.invoke.return_value = SimpleNamespace(
        model_dump=MagicMock(return_value={
            "planNumber": "42",
            "test_steps": [{"test_step": {"execution_approach": "OE"}, **metadata}],
        }),
    )

    with pytest.raises(ValueError):
        service.generate_test_steps("42")

    assert structured_llm.invoke.call_count == 2
    storage_manager.upload_json.assert_not_called()


def test_generation_retries_missing_metadata_and_saves_corrected_response(service_with_mocks):
    service, storage_manager, structured_llm = service_with_mocks
    service.gather_all_review_data = MagicMock(return_value=_review_data())
    corrected = TestStepsResponse(
        planNumber="42",
        test_steps=[{
            "test_step": {"execution_approach": "OE"},
            "rationale": "Sampling tests control execution. Reperformance validates recorded outcomes.",
            "confidence_score": 75,
        }],
    )
    structured_llm.invoke.side_effect = [
        SimpleNamespace(model_dump=MagicMock(return_value={
            "planNumber": "42", "test_steps": [{"test_step": {}}],
        })),
        corrected,
    ]

    result = service.generate_test_steps("42")

    assert result["test_steps"] == corrected.model_dump()["test_steps"]
    assert structured_llm.invoke.call_count == 2
    storage_manager.upload_json.assert_called_once()


def test_generation_schema_requires_step_metadata():
    schema = TestStepsResponse.model_json_schema()
    assert set(schema["$defs"]["TestStep"]["required"]) == {
        "test_step", "rationale", "confidence_score"
    }
