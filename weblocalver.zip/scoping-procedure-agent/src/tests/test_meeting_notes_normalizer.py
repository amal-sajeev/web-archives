import asyncio

import pytest

from utils import meeting_notes_normalizer


class FakeModel:
    async def ainvoke(self, prompt: str):
        self.prompt = prompt
        return type("Response", (), {"content": "# Consolidated Meeting Notes"})()


def test_normalize_generates_summary_from_all_source_notes(monkeypatch) -> None:
    model = FakeModel()
    monkeypatch.setattr(meeting_notes_normalizer, "initialize_gemini_model", lambda: model)

    result = asyncio.run(meeting_notes_normalizer.normalize("PI-123", ["First note", "Second note"]))

    assert result == "# Consolidated Meeting Notes"
    assert "PI-123" in model.prompt
    assert "First note\n\nSecond note" in model.prompt


def test_normalize_raises_value_error_when_model_fails(monkeypatch) -> None:
    class FailingModel:
        async def ainvoke(self, prompt: str):
            raise RuntimeError("Gemini unavailable")

    monkeypatch.setattr(
        meeting_notes_normalizer,
        "initialize_gemini_model",
        lambda: FailingModel(),
    )

    with pytest.raises(ValueError, match="Unable to normalize meeting notes"):
        asyncio.run(meeting_notes_normalizer.normalize("PI-123", ["Note"]))