import os
import sys
from unittest.mock import MagicMock, patch

import pytest

TEST_DIR = os.path.dirname(__file__)
MAIN_DIR = os.path.abspath(os.path.join(TEST_DIR, "..", "main"))

if MAIN_DIR not in sys.path:
    sys.path.insert(0, MAIN_DIR)

# Stub ActionServiceClt if the external network/PubSub dependencies are not reachable in test runs
if "action_client" not in sys.modules:
    mock_action_client = MagicMock()
    mock_clt_instance = MagicMock()
    mock_clt_instance.persist_action = lambda func: func
    mock_action_client.ActionServiceClt.return_value = mock_clt_instance
    sys.modules["action_client"] = mock_action_client


@pytest.fixture
def service_with_mocks():
    """Create a scope recommendation service with isolated model and storage clients."""
    from service.inscope_outscope_service import InScopeOutScopeService

    with (
        patch("service.inscope_outscope_service.StorageManager") as storage_cls,
        patch(
            "service.inscope_outscope_service.initialize_gemini_model"
        ) as llm_initializer,
    ):
        storage_manager = MagicMock()
        llm = MagicMock()
        structured_llm = MagicMock()
        llm.with_structured_output.return_value = structured_llm
        storage_cls.return_value = storage_manager
        llm_initializer.return_value = llm
        service = InScopeOutScopeService()

    return service, storage_manager, structured_llm


@pytest.fixture(autouse=True)
def mock_review_research_recommendation_persistor(monkeypatch):
    """Prevent router persistence helpers from hitting a real database.

    The router imports ``persist_review_research_recommendation`` and
    ``update_review_research_recommendation`` directly, so patch them on the
    router module where they are referenced. Dedicated persistor unit tests
    exercise the real implementations separately.
    """
    try:
        from router import router as router_module
    except ImportError:
        # Router not importable in this test context; nothing to patch.
        return

    if hasattr(router_module, "persist_review_research_recommendation"):
        monkeypatch.setattr(
            router_module,
            "persist_review_research_recommendation",
            MagicMock(return_value=1),
        )
    if hasattr(router_module, "update_review_research_recommendation"):
        monkeypatch.setattr(
            router_module,
            "update_review_research_recommendation",
            MagicMock(return_value=1),
        )
