import os
import sys
from unittest.mock import MagicMock

import pytest


TEST_DIR = os.path.dirname(__file__)
MAIN_DIR = os.path.abspath(os.path.join(TEST_DIR, "..", "main"))
REPOSITORY_ROOT = os.path.abspath(os.path.join(TEST_DIR, "..", "..", ".."))
SHARED_DIR = os.path.join(REPOSITORY_ROOT, "shared")

if MAIN_DIR not in sys.path:
    sys.path.insert(0, MAIN_DIR)
if SHARED_DIR not in sys.path:
    sys.path.insert(0, SHARED_DIR)

# Stub ActionServiceClt if the external network/PubSub dependencies are not reachable in test runs
if "action_client" not in sys.modules:
    mock_action_client = MagicMock()
    mock_clt_instance = MagicMock()
    mock_clt_instance.persist_action = lambda func: func
    mock_action_client.ActionServiceClt.return_value = mock_clt_instance
    sys.modules["action_client"] = mock_action_client


@pytest.fixture(autouse=True)
def mock_review_research_recommendation_persistor(monkeypatch):
    """Prevent router persistence helpers from hitting a real database.

    The router imports ``persist_review_research_recommendation`` and
    ``update_review_research_recommendation`` directly, so patch them on the
    router module where they are referenced. Dedicated persistor unit tests
    exercise the real implementations separately.
    """
    try:
        from router import router as router_module
    except Exception:
        # Router not importable in this test context; nothing to patch.
        return

    if hasattr(router_module, "persist_review_research_recommendation"):
        monkeypatch.setattr(
            router_module,
            "persist_review_research_recommendation",
            MagicMock(return_value=1),
        )
    if hasattr(router_module, "update_review_research_recommendation"):
        monkeypatch.setattr(
            router_module,
            "update_review_research_recommendation",
            MagicMock(return_value=1),
        )

