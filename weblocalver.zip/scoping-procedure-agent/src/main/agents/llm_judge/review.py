"""Focused rubric calls, backoff helpers, and revision workflow for scope recommendations."""

import json
import re
import time
from collections.abc import Callable
from typing import Any

from .loop import ReviewLoopResult, review_and_revise
from .models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
    ScopeReviewCriterion,
)
from .prompt_catalog import SCOPE_REVIEW_PROMPT, SCOPE_REVIEW_RUBRIC_CALLS

_RETRY_DELAY_PATTERN = re.compile(
    r"retry in\s+(?:(\d+)h)?(?:(\d+)m)?(\d+(?:\.\d+)?)s",
    re.IGNORECASE,
)
_TRANSIENT_ERROR_MARKERS = (
    "429",
    "resource_exhausted",
    "resource exhausted",
    "rate limit",
    "503",
    "service unavailable",
    "temporarily unavailable",
)


def provider_retry_delay_seconds(exc: BaseException) -> float | None:
    """Extract provider-suggested retry delay in seconds when present."""
    match = _RETRY_DELAY_PATTERN.search(str(exc))
    if not match:
        return None
    hours = int(match.group(1) or 0)
    minutes = int(match.group(2) or 0)
    seconds = float(match.group(3) or 0.0)
    return hours * 3600 + minutes * 60 + seconds


def invoke_llm_with_backoff(
    model: Any,
    messages: list[Any],
    *,
    stage: str,
    max_attempts: int = 4,
    retry_base_seconds: int | float = 2,
    sleep_fn: Callable[[float], None] = time.sleep,
) -> Any:
    """Invoke a structured LLM with exponential backoff on transient rate limits."""
    attempts = max(1, int(max_attempts))
    for attempt in range(attempts):
        try:
            return model.invoke(messages)
        except Exception as exc:
            message = str(exc).lower()
            provider_delay = provider_retry_delay_seconds(exc)
            is_daily_quota = "per day" in message or (
                provider_delay is not None and provider_delay > 300
            )
            is_transient = any(marker in message for marker in _TRANSIENT_ERROR_MARKERS)
            if is_daily_quota or not is_transient or attempt >= attempts - 1:
                raise
            delay = max(
                retry_base_seconds * (2**attempt), provider_delay or 0.0
            )
            sleep_fn(delay)


def format_revision_prompt(
    base_prompt: str,
    review_feedback: str = "",
    previous_candidate: Any = None,
) -> str:
    """Append previous candidate context and revision instructions when feedback exists."""
    if not review_feedback:
        return base_prompt
    candidate_payload = (
        previous_candidate.model_dump(mode="json")
        if hasattr(previous_candidate, "model_dump")
        else (previous_candidate or {})
    )
    candidate_json = json.dumps(
        candidate_payload,
        ensure_ascii=False,
        indent=2,
        default=str,
    )
    return (
        f"{base_prompt}\n\n"
        "## REVISION INSTRUCTIONS\n"
        "Address the following review feedback while preserving all accurate content "
        "and required formatting:\n"
        f"{review_feedback}\n\n"
        f"Previous candidate JSON:\n{candidate_json}"
    )


def review_scope_candidate(
    candidate: Any,
    review_data: dict[str, Any],
    model: Any,
    *,
    serialize_review_data: Callable[[dict[str, Any]], str],
    invoke_with_backoff: Callable,
    message_factory: Callable[[str], Any],
) -> ScopeRecommendationReview:
    """Run focused reviews and aggregate criteria into the internal review model."""
    review_data_json = serialize_review_data(review_data)
    candidate_json = json.dumps(
        candidate.model_dump(mode="json"),
        ensure_ascii=False,
        indent=2,
        default=str,
    )
    criteria = []
    for rubric_name, expected_names, rubric_instructions in SCOPE_REVIEW_RUBRIC_CALLS:
        prompt = SCOPE_REVIEW_PROMPT.format(
            rubric_instructions=rubric_instructions,
            review_data=review_data_json,
            candidate=candidate_json,
        )
        response_model = SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
        response = invoke_with_backoff(
            model.with_structured_output(response_model),
            [message_factory(prompt)],
            stage=f"judge:{rubric_name}",
        )
        focused_review = response_model.model_validate(response)
        criteria.extend(
            ScopeReviewCriterion(
                name=name, **getattr(focused_review, name).model_dump()
            )
            for name in expected_names
        )
    return ScopeRecommendationReview(criteria=criteria)


def run_scope_review_workflow(
    *,
    generate_fn: Callable[[str, Any], Any],
    reviewer_fn: Callable[[Any], ScopeRecommendationReview],
    max_revisions: int,
    failure_policy: str,
) -> Any:
    """Generate initial scope draft and run the bounded judge loop."""
    initial_candidate = generate_fn("", None)
    review_result: ReviewLoopResult = review_and_revise(
        initial_candidate,
        reviewer=reviewer_fn,
        reviser=lambda candidate, review: generate_fn(review.feedback, candidate),
        approved=lambda review: review.approved,
        has_feedback=lambda review: bool(review.feedback),
        stage="scope_recommendations",
        max_revisions=max_revisions,
        failure_policy=failure_policy,
    )
    return review_result.candidate
