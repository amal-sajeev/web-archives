"""Focused rubric calls for generated scope recommendations."""

import json
from typing import Any, Callable, Dict

from .models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
    ScopeReviewCriterion,
)
from .prompt_catalog import SCOPE_REVIEW_PROMPT, SCOPE_REVIEW_RUBRIC_CALLS


def review_scope_candidate(
    candidate: Any,
    review_data: Dict[str, Any],
    model: Any,
    *,
    serialize_review_data: Callable[[Dict[str, Any]], str],
    invoke_with_backoff: Callable,
    message_factory: Callable[[str], Any],
) -> ScopeRecommendationReview:
    """Run focused reviews and aggregate criteria into the internal review model."""
    review_data_json = serialize_review_data(review_data)
    candidate_json = json.dumps(
        candidate.model_dump(mode="json"),
        ensure_ascii=False,
        indent=2,
        default=str,
    )
    criteria = []
    for rubric_name, expected_names, rubric_instructions in SCOPE_REVIEW_RUBRIC_CALLS:
        prompt = SCOPE_REVIEW_PROMPT.format(
            rubric_instructions=rubric_instructions,
            review_data=review_data_json,
            candidate=candidate_json,
        )
        response_model = SCOPE_REVIEW_RESPONSE_MODELS[rubric_name]
        response = invoke_with_backoff(
            model.with_structured_output(response_model),
            [message_factory(prompt)],
            stage=f"judge:{rubric_name}",
        )
        focused_review = response_model.model_validate(response)
        criteria.extend(
            ScopeReviewCriterion(name=name, **getattr(focused_review, name).model_dump())
            for name in expected_names
        )
    return ScopeRecommendationReview(criteria=criteria)
