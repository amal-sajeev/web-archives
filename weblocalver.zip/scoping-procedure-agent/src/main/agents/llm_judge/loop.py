"""Bounded review/revision orchestration without model or schema dependencies.

Callers own prompts, structured review schemas, model initialization, and candidate
generation. This module only coordinates review results and corrective revisions.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from typing import Generic, Literal, TypeVar

CandidateT = TypeVar("CandidateT")
ReviewT = TypeVar("ReviewT")
FailurePolicy = Literal["fail_open", "fail_closed"]

logger = logging.getLogger(__name__)


class ReviewLoopError(RuntimeError):
    """Raised when a review or revision fails under the fail-closed policy."""


@dataclass(frozen=True)
class ReviewLoopResult(Generic[CandidateT, ReviewT]):
    """Candidate and minimal, content-free loop status for caller observability."""

    candidate: CandidateT
    review: ReviewT | None
    approved: bool
    revisions: int
    outcome: Literal[
        "approved",
        "revision_limit",
        "no_feedback",
        "review_failure",
        "revision_failure",
    ]


def _log_loop_event(
    log: logging.Logger,
    *,
    stage: str,
    outcome: str,
    revisions: int,
    failure_type: str | None = None,
) -> None:
    """Log loop status without serializing prompts, candidates, or judge output."""
    if failure_type:
        log.error(
            "LLM judge stage=%s outcome=%s revisions=%d failure_type=%s",
            stage,
            outcome,
            revisions,
            failure_type,
        )
        return
    log.info(
        "LLM judge stage=%s outcome=%s revisions=%d",
        stage,
        outcome,
        revisions,
    )


def review_and_revise(
    candidate: CandidateT,
    *,
    reviewer: Callable[[CandidateT], ReviewT],
    reviser: Callable[[CandidateT, ReviewT], CandidateT],
    approved: Callable[[ReviewT], bool],
    has_feedback: Callable[[ReviewT], bool],
    stage: str,
    max_revisions: int = 1,
    failure_policy: FailurePolicy = "fail_open",
    verify_final_revision: bool = True,
    log: logging.Logger | None = None,
) -> ReviewLoopResult[CandidateT, ReviewT]:
    """Review a candidate and make at most ``max_revisions`` corrective drafts.

    ``reviewer`` and ``reviser`` are application-provided callbacks. A returned
    candidate is therefore only as schema-valid as the caller's generator makes
    it. Keep source checks, schemas, rubrics, and model construction in the agent.

    Fail-open returns the latest candidate that was successfully generated. A
    failed revision leaves the preceding candidate intact. Fail-closed raises
    before the caller can persist the result.
    """
    active_logger = log or logger
    if max_revisions < 0:
        raise ValueError("max_revisions must be 0 or greater")
    if failure_policy not in ("fail_open", "fail_closed"):
        raise ValueError("failure_policy must be 'fail_open' or 'fail_closed'")

    revision_count = 0
    latest_review: ReviewT | None = None
    if max_revisions == 0 and not verify_final_revision:
        _log_loop_event(
            active_logger, stage=stage, outcome="revision_limit", revisions=0
        )
        return ReviewLoopResult(candidate, None, False, 0, "revision_limit")

    while True:
        try:
            latest_review = reviewer(candidate)
            is_approved = approved(latest_review)
            actionable_feedback = has_feedback(latest_review)
        except Exception as exc:
            _log_loop_event(
                active_logger,
                stage=stage,
                outcome="review_failure",
                revisions=revision_count,
                failure_type=type(exc).__name__,
            )
            if failure_policy == "fail_closed":
                raise ReviewLoopError(f"LLM review failed at stage '{stage}'.") from exc
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "review_failure"
            )

        if is_approved:
            _log_loop_event(
                active_logger, stage=stage, outcome="approved", revisions=revision_count
            )
            return ReviewLoopResult(
                candidate, latest_review, True, revision_count, "approved"
            )
        if not actionable_feedback:
            _log_loop_event(
                active_logger, stage=stage, outcome="no_feedback", revisions=revision_count
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "no_feedback"
            )
        if revision_count >= max_revisions:
            _log_loop_event(
                active_logger,
                stage=stage,
                outcome="revision_limit",
                revisions=revision_count,
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_limit"
            )

        try:
            revised_candidate = reviser(candidate, latest_review)
        except Exception as exc:
            _log_loop_event(
                active_logger,
                stage=stage,
                outcome="revision_failure",
                revisions=revision_count,
                failure_type=type(exc).__name__,
            )
            if failure_policy == "fail_closed":
                raise ReviewLoopError(
                    f"LLM revision failed at stage '{stage}'."
                ) from exc
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_failure"
            )
        candidate = revised_candidate
        revision_count += 1
        if revision_count >= max_revisions and not verify_final_revision:
            _log_loop_event(
                active_logger,
                stage=stage,
                outcome="revision_limit",
                revisions=revision_count,
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_limit"
            )
