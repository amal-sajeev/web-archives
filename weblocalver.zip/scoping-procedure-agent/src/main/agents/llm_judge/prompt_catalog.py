"""Load dated, versioned scope recommendation judge prompts from JSON."""

import json
import os
from pathlib import Path

PROMPT_DIRECTORY = Path(__file__).with_name("prompts")
REQUIRED_CATALOG_FIELDS = {"date", "version", "review_prompt", "rubric_calls"}


def _read_catalog(path: Path) -> dict:
    catalog = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(catalog, dict) or REQUIRED_CATALOG_FIELDS - catalog.keys():
        raise ValueError(f"Invalid scope judge prompt catalog: {path.name}")
    if not catalog["date"] or not catalog["version"] or not catalog["rubric_calls"]:
        raise ValueError(
            f"Scope judge prompt catalog is missing metadata or rubrics: {path.name}"
        )
    return catalog


def load_prompt_catalog(version: str | None = None) -> dict:
    catalogs = [
        _read_catalog(path)
        for path in PROMPT_DIRECTORY.glob("scope_recommendation_judge_*.json")
    ]
    if not catalogs:
        raise FileNotFoundError(
            f"No scope recommendation judge prompts in {PROMPT_DIRECTORY}"
        )
    requested = version or os.getenv("SCOPE_RECOMMENDATION_JUDGE_PROMPT_VERSION")
    if requested:
        for catalog in catalogs:
            if catalog.get("version") == requested:
                return catalog
        raise ValueError(f"Scope judge prompt version {requested!r} is unavailable")
    return max(
        catalogs, key=lambda item: (item.get("date", ""), item.get("version", ""))
    )


PROMPT_CATALOG = load_prompt_catalog()
SCOPE_REVIEW_PROMPT = PROMPT_CATALOG["review_prompt"]
SCOPE_REVIEW_RUBRIC_CALLS = tuple(
    (item["name"], tuple(item["criteria"]), item["instructions"])
    for item in PROMPT_CATALOG["rubric_calls"]
)
