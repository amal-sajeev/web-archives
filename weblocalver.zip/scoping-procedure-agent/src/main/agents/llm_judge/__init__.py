"""Scope recommendation LLM judge models, prompts, and bounded review loop."""

from .loop import ReviewLoopError, ReviewLoopResult, judge_loop_enabled, review_and_revise
from .models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
    ScopeReviewCriterion,
    ScopeReviewDecision,
)
from .prompt_catalog import (
    PROMPT_CATALOG,
    SCOPE_REFINEMENT_PROMPT,
    SCOPE_REVIEW_PROMPT,
    SCOPE_REVIEW_RUBRIC_CALLS,
    load_prompt_catalog,
    load_refinement_prompt,
)
from .review import (
    format_revision_prompt,
    invoke_llm_with_backoff,
    provider_retry_delay_seconds,
    review_scope_candidate,
    run_scope_review_workflow,
)

__all__ = [
    "PROMPT_CATALOG",
    "SCOPE_REFINEMENT_PROMPT",
    "SCOPE_REVIEW_PROMPT",
    "SCOPE_REVIEW_RESPONSE_MODELS",
    "SCOPE_REVIEW_RUBRIC_CALLS",
    "ReviewLoopError",
    "ReviewLoopResult",
    "ScopeRecommendationReview",
    "ScopeReviewCriterion",
    "ScopeReviewDecision",
    "format_revision_prompt",
    "invoke_llm_with_backoff",
    "judge_loop_enabled",
    "load_prompt_catalog",
    "load_refinement_prompt",
    "provider_retry_delay_seconds",
    "review_and_revise",
    "review_scope_candidate",
    "run_scope_review_workflow",
]
