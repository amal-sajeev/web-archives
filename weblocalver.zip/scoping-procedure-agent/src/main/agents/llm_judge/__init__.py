"""Scope recommendation review models, prompts, and bounded judge loop."""

from .loop import ReviewLoopError, ReviewLoopResult, review_and_revise
from .models import (
    SCOPE_REVIEW_RESPONSE_MODELS,
    ScopeRecommendationReview,
    ScopeReviewCriterion,
    ScopeReviewDecision,
)
from .prompt_catalog import (
    PROMPT_CATALOG,
    SCOPE_REVIEW_PROMPT,
    SCOPE_REVIEW_RUBRIC_CALLS,
    load_prompt_catalog,
)
from .review import review_scope_candidate

__all__ = [
    "PROMPT_CATALOG",
    "ReviewLoopError",
    "ReviewLoopResult",
    "SCOPE_REVIEW_PROMPT",
    "SCOPE_REVIEW_RESPONSE_MODELS",
    "SCOPE_REVIEW_RUBRIC_CALLS",
    "ScopeRecommendationReview",
    "ScopeReviewCriterion",
    "ScopeReviewDecision",
    "load_prompt_catalog",
    "review_and_revise",
    "review_scope_candidate",
]
