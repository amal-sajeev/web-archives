"""Internal structured review models for scope recommendation generation."""

from typing import Literal

from pydantic import BaseModel, Field, model_validator

ScopeReviewCriterionName = Literal[
    "scope_boundary_fidelity",
    "evidence_identifier_accuracy",
    "source_hierarchy_conflict_handling",
    "required_content_format",
    "rationale_confidence_alignment",
]

ScopeReviewField = Literal[
    "inscope.report",
    "inscope.rationale",
    "inscope.confidence_score",
    "outscope.report",
    "outscope.rationale",
    "outscope.confidence_score",
]

REQUIRED_SCOPE_REVIEW_CRITERIA = {
    "scope_boundary_fidelity",
    "evidence_identifier_accuracy",
    "source_hierarchy_conflict_handling",
    "required_content_format",
    "rationale_confidence_alignment",
}


class ScopeReviewDecision(BaseModel):
    """Decision fields for one criterion in a focused response schema."""

    passed: bool = Field(description="Whether this scope recommendation check passed.")
    affected_fields: list[ScopeReviewField] = Field(
        default_factory=list,
        description="Exact scope-report fields that need correction when this check fails.",
    )
    issue: str = Field(default="", description="Specific defect found by this check.")
    action: str = Field(
        default="", description="Concrete correction for the identified defect."
    )

    @model_validator(mode="before")
    @classmethod
    def coerce_legacy_fields(cls, data: object) -> object:
        if isinstance(data, dict):
            normalized = dict(data)
            if "name" not in normalized and "criterion" in normalized:
                normalized["name"] = normalized.pop("criterion")
            if "passed" not in normalized and "status" in normalized:
                status = str(normalized.pop("status")).strip().lower()
                normalized["passed"] = status in {
                    "pass",
                    "passed",
                    "true",
                    "ok",
                    "approved",
                }
            return normalized
        return data

    @model_validator(mode="after")
    def validate_feedback(self):
        if self.passed:
            if self.affected_fields or self.issue.strip() or self.action.strip():
                raise ValueError(
                    "Passed scope-review criteria must have empty feedback fields"
                )
        else:
            issue_text = self.issue.strip()
            action_text = self.action.strip()
            if issue_text and not action_text:
                self.action = f"Resolve the reported issue: {issue_text}"
            elif action_text and not issue_text:
                self.issue = action_text
            if (
                not self.affected_fields
                or not self.issue.strip()
                or not self.action.strip()
            ):
                raise ValueError(
                    "Each failed scope-review criterion needs affected fields, an issue, and an action"
                )
        return self


class ScopeReviewCriterion(ScopeReviewDecision):
    """One named pass/fail decision with field-specific corrective feedback."""

    name: ScopeReviewCriterionName


class BoundaryAndCoverageReview(BaseModel):
    """Fixed-shape response requiring both results in the combined rubric."""

    scope_boundary_fidelity: ScopeReviewDecision
    required_content_format: ScopeReviewDecision


class EvidenceIdentifierReview(BaseModel):
    """Fixed-shape response for evidence and identifier review."""

    evidence_identifier_accuracy: ScopeReviewDecision


class SourceHierarchyReview(BaseModel):
    """Fixed-shape response for source hierarchy and conflict review."""

    source_hierarchy_conflict_handling: ScopeReviewDecision


class RationaleConfidenceReview(BaseModel):
    """Fixed-shape response for rationale and confidence review."""

    rationale_confidence_alignment: ScopeReviewDecision


SCOPE_REVIEW_RESPONSE_MODELS = {
    "boundary_and_coverage": BoundaryAndCoverageReview,
    "evidence_and_identifiers": EvidenceIdentifierReview,
    "source_hierarchy_and_conflicts": SourceHierarchyReview,
    "rationale_and_confidence": RationaleConfidenceReview,
}


class ScopeRecommendationReview(BaseModel):
    """Aggregated review result consumed by the shared review/revision loop."""

    criteria: list[ScopeReviewCriterion] = Field(
        description="Exactly one result for each scope recommendation review criterion."
    )

    @model_validator(mode="after")
    def validate_complete_rubric(self):
        names = [criterion.name for criterion in self.criteria]
        if set(names) != REQUIRED_SCOPE_REVIEW_CRITERIA or len(names) != len(
            REQUIRED_SCOPE_REVIEW_CRITERIA
        ):
            raise ValueError(
                "Scope recommendation review must include every criterion exactly once"
            )
        return self

    @property
    def approved(self) -> bool:
        return all(criterion.passed for criterion in self.criteria)

    @property
    def feedback(self) -> str:
        return "\n".join(
            f"[{criterion.name}] Fields: {', '.join(criterion.affected_fields)}. "
            f"Issue: {criterion.issue.strip()} Action: {criterion.action.strip()}"
            for criterion in self.criteria
            if not criterion.passed
        )
