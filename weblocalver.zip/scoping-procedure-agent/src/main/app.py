import sys
import os
import logging
import logging
    
from pathlib import Path
from contextlib import asynccontextmanager
from dotenv import load_dotenv
import uvicorn
from fastapi import FastAPI
load_dotenv()

bucket_name_val = os.getenv("bucket_name") or os.getenv("BUCKET_NAME") or os.getenv("DBAWARE_REVIEW_BUCKET_NAME")
if bucket_name_val:
    for var in ["bucket_name", "BUCKET_NAME", "review_bucket_name", "DBAWARE_REVIEW_BUCKET_NAME"]:
        os.environ.setdefault(var, bucket_name_val)

project_root = Path(__file__).resolve().parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# Ensure action-service root is in sys.path before importing router or ActionServiceClt
for parent in project_root.parents:
    if (parent / "action_client").exists() or parent.name == "action-service":
        if str(parent) not in sys.path:
            sys.path.insert(0, str(parent))
        break

agent_config_dir = project_root / "config"
try:
    import helper
    import importlib.util

    sp_config_dir = Path(helper.__file__).resolve().parent.parent / "config"
    if sp_config_dir.is_dir() and (sp_config_dir / "app.yml").exists():
        current_config = sys.modules.get("config")
        sp_init = sp_config_dir / "__init__.py"
        if not current_config or getattr(current_config, "__file__", None) != str(sp_init):
            search_locs = [str(sp_config_dir)]
            if agent_config_dir.is_dir() and str(agent_config_dir) not in search_locs:
                search_locs.append(str(agent_config_dir))
            spec = importlib.util.spec_from_file_location(
                "config",
                str(sp_init),
                submodule_search_locations=search_locs,
            )
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                sys.modules["config"] = mod
                spec.loader.exec_module(mod)

        mod = sys.modules.get("config")
        if mod and hasattr(mod, "__path__"):
            if not isinstance(mod.__path__, list):
                mod.__path__ = list(mod.__path__)
            if agent_config_dir.is_dir() and str(agent_config_dir) not in mod.__path__:
                mod.__path__.append(str(agent_config_dir))
            if hasattr(mod, "__spec__") and mod.__spec__ and hasattr(mod.__spec__, "submodule_search_locations"):
                if agent_config_dir.is_dir() and mod.__spec__.submodule_search_locations and str(agent_config_dir) not in mod.__spec__.submodule_search_locations:
                    mod.__spec__.submodule_search_locations.append(str(agent_config_dir))
except Exception:
    pass

from router import router as app_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing configurations on FastAPI server startup...")
    yield

app = FastAPI(
    title="Scoping Procedure Agent",
    root_path="/scoping-procedure-agent",
    lifespan=lifespan,
)

# Import and mount the modular router
# Mount the modular API router


app.include_router(app_router.router)


if __name__=="__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8001, reload=True)
