import logging
import inspect
from typing import Annotated
from fastapi import APIRouter, File, Form, HTTPException, Response, UploadFile
from pydantic import ValidationError
from agent_helper.action_service import (
    audit_human_request,
    audit_ai_response,
    audit_generation_start,
    audit_revision,
)
from model.request_model import (
    DownloadDiscoveryWalkthroughRequest,
    DownloadScopeRecommendationRequest,
    DownloadTestStepsRequest,
    GenerateDiscoveryWalkthrough,
    GenerateInScopeOutScopeRequest,
    GenerateScopingDocumentRequest,
    GenerateTestStepsRequest,
    GetScopingDocumentRequest,
    GetMeetingNotesSummaryRequest,
    MeetingNotesUploadRequest,
    ScopingDocumentContent,
    ScopingDocumentRow,
    UpdateScopingDocumentRequest,
    UpdateDiscoveryWalkthroughRequest,
    UpdateInScopeOutScopeRequest,
    UpdateTestStepsRequest,
)
from model.response_model import (
    DiscoveryWalkthroughReport,
    MeetingNotesSummaryContentResponse,
    MeetingNotesSummaryResponse,
    InScopeOutScopeResponse,
    TestStepsResponse,
)
from persistor.review_research_recommendation_repository import (
    persist_review_research_recommendation, update_review_research_recommendation
)
from service.inscope_outscope_service import InScopeOutScopeService
from service.meeting_notes_service import MeetingNotesService
from service.discovery_walkthrough_service import DiscoveryWalkthroughService
from service.plan_details_service import (
    PlanDetailsService,
    _build_plan_details_rows,
    _build_testing_approach_rows,
    _extract_plan_name,
)
from service.scoping_document_service import ScopingDocumentService
from service.test_steps_service import TestStepsService
from service.pdf_download_service import (
    download_discovery_walkthrough_pdf,
    download_scoping_document_pdf_from_html,
    download_scope_recommendation_pdf,
    download_test_steps_pdf,
)

logger = logging.getLogger(__name__)
router = APIRouter()
inscope_outscope_service = None
meeting_notes_service = None
test_steps_service = None
discovery_walkthrough_service = None
plan_details_service = None
scoping_document_service = None


def get_discovery_walkthrough_service() -> DiscoveryWalkthroughService:
    global discovery_walkthrough_service
    if discovery_walkthrough_service is None:
        discovery_walkthrough_service = DiscoveryWalkthroughService()
    return discovery_walkthrough_service


def get_inscope_outscope_service() -> InScopeOutScopeService:
    global inscope_outscope_service
    if inscope_outscope_service is None:
        inscope_outscope_service = InScopeOutScopeService()
    return inscope_outscope_service


def get_meeting_notes_service() -> MeetingNotesService:
    global meeting_notes_service
    if meeting_notes_service is None:
        meeting_notes_service = MeetingNotesService()
    return meeting_notes_service


def get_test_steps_service() -> TestStepsService:
    global test_steps_service
    if test_steps_service is None:
        test_steps_service = TestStepsService()
    return test_steps_service


def get_plan_details_service() -> PlanDetailsService:
    global plan_details_service
    if plan_details_service is None:
        plan_details_service = PlanDetailsService()
    return plan_details_service


def get_scoping_document_service() -> ScopingDocumentService:
    global scoping_document_service
    if scoping_document_service is None:
        scoping_document_service = ScopingDocumentService()
    return scoping_document_service


def _scope_report_text(artifact: dict, key: str) -> str:
    payload = artifact.get(key, {})
    report = payload if isinstance(payload, str) else (payload or {}).get("report", "")
    return str(report).strip()


def _build_scoping_document_content(plan_number: str) -> ScopingDocumentContent:
    artifacts = get_scoping_document_service().load_source_artifacts(plan_number)
    inscope = _scope_report_text(artifacts["inscope"], "inscope")
    outscope = _scope_report_text(artifacts["outscope"], "outscope")
    if not inscope and not outscope:
        raise ValueError("Both inscope.report and outscope.report are empty.")

    plan_details = artifacts["plan_details"]
    test_steps = artifacts["test_steps"]
    return ScopingDocumentContent(
        plan_name=_extract_plan_name(plan_details) or "",
        plan_details_rows=[
            ScopingDocumentRow(key=str(key or ""), value=str(value or ""))
            for key, value in _build_plan_details_rows(
                plan_details,
                default_system_id=plan_number,
            )
        ],
        inscope=inscope,
        outscope=outscope,
        testing_approach_rows=[
            ScopingDocumentRow(key=str(key or ""), value=str(value or ""))
            for key, value in _build_testing_approach_rows(
                test_steps.get("test_steps", [])
            )
        ],
    )


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/meeting-notes")
@router.post("/generate-meeting-notes")
async def summarize_meeting_notes(
    planNumber: Annotated[str, Form(description="Plan number")],
    files: Annotated[
        list[UploadFile], File(description="Meeting notes or MOM documents")
    ],
) -> MeetingNotesSummaryResponse:
    if not planNumber.strip():
        raise HTTPException(status_code=400, detail="planNumber is required.")
    if not files:
        raise HTTPException(
            status_code=400, detail="At least one document is required."
        )
    agent_card, start_time = audit_human_request(
        activity_type="MEETING_NOTES_CONSOLIDATION",
        query=f"Consolidate and summarize {len(files)} meeting notes for plan number {planNumber}",
        plan_number=planNumber,
        entity_type="MEETING_NOTES",
    )
    try:
        result = await get_meeting_notes_service().process_meeting_notes(
            MeetingNotesUploadRequest(
                planNumber=planNumber,
                files=files,
            )
        )
        audit_ai_response(
            agent_card=agent_card,
            start_time=start_time,
            result_payload=result,
            default_reasoning=f"Successfully consolidated meeting notes for plan {planNumber}.",
        )
        return result
    except ValueError as error:
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.post("/get-meeting-notes-summary")
def get_meeting_notes_summary(
    request: GetMeetingNotesSummaryRequest,
) -> MeetingNotesSummaryContentResponse:
    try:
        summary_data = get_meeting_notes_service().get_meeting_notes_summary(
            request.planNumber
        )
        return MeetingNotesSummaryContentResponse(
            planNumber=request.planNumber,
            normalized_meeting_notes=summary_data.get("normalized_meeting_notes"),
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error fetching meeting notes summary: {str(e)}"
        )


@router.post("/generate-inscope-outscope")
def generate_inscope_outscope(
    request: GenerateInScopeOutScopeRequest,
) -> InScopeOutScopeResponse:
    logger.info("Received inscope/outscope request planNumber=%s", request.planNumber)
    try:
        agent_card, start_time = audit_generation_start(
            activity_type="SCOPE_RECOMMENDATION",
            entity_type="SCOPE_RECOMMENDATION",
            plan_number=request.planNumber,
            description="in-scope and out-of-scope recommendations",
        )
        generation_result = get_inscope_outscope_service().generate_inscope_outscope(
            plan_number=request.planNumber,
        )
        audit_ai_response(
            agent_card=agent_card,
            start_time=start_time,
            result_payload=generation_result,
            default_reasoning="Successfully generated in-scope / out-of-scope boundaries.",
        )
        api_response = InScopeOutScopeResponse(
            planNumber=request.planNumber,
            inscope=generation_result["inscope"],
            outscope=generation_result["outscope"],
            rationale=generation_result.get("rationale", ""),
            confidence_score=generation_result.get("confidence_score", 0),
        )
        try:
            review_rr_id = persist_review_research_recommendation(
                review_scope_instance_id=request.userDetails.review_scope_instance_id,
                metadata=api_response.model_dump(),
                report_type="SCOPE_RECOMMENDATION",
                created_by=request.userDetails.user,
                remarks=request.userDetails.remarks,
            )
            logger.info(
                "Persisted research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                review_rr_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the generation response.
            logger.exception(
                "Failed to persist research recommendation plan_number=%s",
                request.planNumber,
            )
        return api_response
    except FileNotFoundError as e:
        logger.warning(
            "Data not found for inscope/outscope planNumber=%s error=%s",
            request.planNumber,
            e,
        )
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        logger.warning(
            "Invalid inscope/outscope request planNumber=%s error=%s",
            request.planNumber,
            e,
        )
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except ValueError as e:
        logger.warning(
            "Invalid inscope/outscope data planNumber=%s error=%s",
            request.planNumber,
            e,
        )
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(
            "Unexpected error generating inscope/outscope planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(
            status_code=500, detail=f"Error generating inscope/outscope: {str(e)}"
        )


@router.post("/get-inscope-outscope")
def get_inscope_outscope(
    request: GenerateInScopeOutScopeRequest,
) -> InScopeOutScopeResponse:
    try:
        result = get_inscope_outscope_service().get_inscope_outscope(
            plan_number=request.planNumber,
        )
        return InScopeOutScopeResponse(
            planNumber=request.planNumber,
            inscope=result["inscope"],
            outscope=result["outscope"],
            rationale=result.get("rationale", ""),
            confidence_score=result.get("confidence_score", 0),
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error fetching inscope/outscope: {str(e)}"
        )


@router.post("/generate-scoping-document")
def GENERATE_SCOPING_DOCUMENT(request: GenerateScopingDocumentRequest) -> Response:
    try:
        document_service = get_scoping_document_service()
        document = document_service.get_saved_document(request.planNumber)
        if document is None:
            agent_card, start_time = audit_generation_start(
                activity_type="SCOPING_DOCUMENT",
                entity_type="SCOPING_DOCUMENT",
                plan_number=request.planNumber,
                description="scoping document",
            )
            document = _build_scoping_document_content(request.planNumber)
            document_service.save_document(request.planNumber, document)
            audit_ai_response(
                agent_card=agent_card,
                start_time=start_time,
                result_payload=document,
                default_reasoning="Successfully generated scoping document.",
            )
            try:
                review_rr_id = persist_review_research_recommendation(
                    review_scope_instance_id=request.userDetails.review_scope_instance_id,
                    metadata=document.model_dump(),
                    report_type="SCOPING_DOCUMENT",
                    created_by=request.userDetails.user,
                    remarks=request.userDetails.remarks,
                )
                logger.info(
                    "Persisted research recommendation plan_number=%s review_rr_id=%s",
                    request.planNumber,
                    review_rr_id,
                )
            except Exception:
                # Persistence is best-effort; do not fail the generation response.
                logger.exception(
                    "Failed to persist research recommendation plan_number=%s",
                    request.planNumber,
                )

        return Response(
            content=document_service.render_editor_html(request.planNumber, document),
            media_type="text/html",
            headers={"Content-Disposition": "inline; filename=scoping_document.html"},
        )
    except FileNotFoundError as error:
        raise HTTPException(status_code=404, detail=str(error)) from error
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception(
            "Error generating editable scoping document planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.put("/update-scoping-document")
def update_scoping_document(request: UpdateScopingDocumentRequest) -> dict:
    try:
        audit_revision(
            activity_type="SCOPING_DOCUMENT",
            entity_type="SCOPING_DOCUMENT",
            plan_number=request.planNumber,
            request_obj=request,
            description="scoping document",
        )
        document_service = get_scoping_document_service()
        uri = document_service.save_document(request.planNumber, request.document)
        try:
            updated_id = update_review_research_recommendation(
                review_scope_instance_id=request.userDetails.review_scope_instance_id,
                report_type="SCOPING_DOCUMENT",
                metadata=request.document.model_dump(),
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s", request.planNumber
            )
        return {
            "planNumber": request.planNumber,
            "document": request.document.model_dump(),
            "saved": True,
            "uri": uri,
        }
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception(
            "Error updating editable scoping document planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.post("/download-scoping-document")
def download_edited_scoping_document(request: GetScopingDocumentRequest) -> Response:
    try:
        document_service = get_scoping_document_service()
        document = document_service.get_saved_document(request.planNumber)
        if document is None:
            document = _build_scoping_document_content(request.planNumber)
            document_service.save_document(request.planNumber, document)

        pdf_bytes, headers = download_scoping_document_pdf_from_html(
            plan_number=request.planNumber,
            html_content=document_service.render_pdf_html(request.planNumber, document),
        )
        return Response(content=pdf_bytes, media_type="application/pdf", headers=headers)
    except FileNotFoundError as error:
        raise HTTPException(status_code=404, detail=str(error)) from error
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception(
            "Error downloading edited scoping document planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.put("/update-inscope-outscope")
def update_inscope_outscope(
    request: UpdateInScopeOutScopeRequest,
) -> InScopeOutScopeResponse:
    try:
        audit_revision(
            activity_type="SCOPE_RECOMMENDATION",
            entity_type="SCOPE_RECOMMENDATION",
            plan_number=request.planNumber,
            request_obj=request,
            description="in-scope/out-of-scope recommendations",
        )
        update_arguments = dict(
            plan_number=request.planNumber,
            inscope=request.inscope,
            outscope=request.outscope,
        )
        if "rationale" in request.model_fields_set:
            update_arguments["rationale"] = request.rationale
        if "confidence_score" in request.model_fields_set:
            update_arguments["confidence_score"] = request.confidence_score
        updated_result = get_inscope_outscope_service().update_inscope_outscope(
            **update_arguments
        )
        api_response=InScopeOutScopeResponse(
            planNumber=request.planNumber,
            inscope=updated_result["inscope"],
            outscope=updated_result["outscope"],
            rationale=updated_result.get("rationale", ""),
            confidence_score=updated_result.get("confidence_score", 0),
        )
        try:
            updated_id = update_review_research_recommendation(
                review_scope_instance_id=request.userDetails.review_scope_instance_id,
                report_type="SCOPE_RECOMMENDATION",
                metadata=api_response.model_dump(),
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s", request.planNumber
            )
        return api_response
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error updating inscope/outscope: {str(e)}"
        )


@router.post("/generate-discovery-walkthrough")
async def generate_discovery_walkthrough(request: GenerateDiscoveryWalkthrough):
    plan_number = request.planNumber
    logger.info("Received discovery walkthrough request planNumber=%s", plan_number)
    agent_card, start_time = audit_generation_start(
        activity_type="DISCOVERY_WALKTHROUGH_GENERATION",
        entity_type="DISCOVERY_WALKTHROUGH",
        plan_number=plan_number,
        description="discovery walkthrough report",
    )
    try:
        report = get_discovery_walkthrough_service().generate_report(plan_number)
        if inspect.isawaitable(report):
            report = await report
        audit_ai_response(
            agent_card=agent_card,
            start_time=start_time,
            result_payload=report,
            default_reasoning="Successfully generated discovery walkthrough.",
        )
        try:
            review_rr_id = persist_review_research_recommendation(
                review_scope_instance_id=request.userDetails.review_scope_instance_id,
                metadata=report,
                report_type="DISCOVERY_WALKTHROUGH",
                created_by=request.userDetails.user,
                remarks=request.userDetails.remarks,
            )
            logger.info(
                "Persisted research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                review_rr_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the generation response.
            logger.exception(
                "Failed to persist research recommendation plan_number=%s",
                request.planNumber,
            )
        return report
    except FileNotFoundError as exc:
        logger.warning(
            "Preliminary report not found. planNumber=%s. Error: %s",
            request.planNumber,
            exc,
        )
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        logger.exception(
            "Unexpected error in generate_discovery_walkthrough. planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get-discovery-walkthrough")
def get_discovery_walkthrough(
    request: GenerateDiscoveryWalkthrough,
) -> DiscoveryWalkthroughReport:
    try:
        report_data = get_discovery_walkthrough_service().get_report(request.planNumber)
        return DiscoveryWalkthroughReport(**report_data)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error fetching discovery walkthrough: {str(e)}"
        )


@router.put("/update-discovery-walkthrough")
def update_discovery_walkthrough(
    request: UpdateDiscoveryWalkthroughRequest,
) -> DiscoveryWalkthroughReport:
    try:
        audit_revision(
            activity_type="DISCOVERY_WALKTHROUGH",
            entity_type="DISCOVERY_WALKTHROUGH",
            plan_number=request.planNumber,
            request_obj=request,
            description="discovery walkthrough",
        )
        updated_report = get_discovery_walkthrough_service().update_report(
            plan_number=request.planNumber,
            report_data=request.model_dump(exclude={"planNumber", "userDetails"}, exclude_unset=True),
        )
        api_response=DiscoveryWalkthroughReport(**updated_report)
        try:
            updated_id = update_review_research_recommendation(
                review_scope_instance_id=request.userDetails.review_scope_instance_id,
                report_type="DISCOVERY_WALKTHROUGH",
                metadata=api_response.model_dump(),
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s", request.planNumber
            )
        return api_response
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error updating discovery walkthrough: {str(e)}"
        )


@router.post("/generate-test-steps")
def generate_test_steps(request: GenerateTestStepsRequest) -> TestStepsResponse:
    try:
        agent_card, start_time = audit_generation_start(
            activity_type="TEST_STEPS",
            entity_type="TEST_STEPS",
            plan_number=request.planNumber,
            description="compliance audit test steps",
        )
        generation_result = get_test_steps_service().generate_test_steps(
            plan_number=request.planNumber,
        )
        audit_ai_response(
            agent_card=agent_card,
            start_time=start_time,
            result_payload=generation_result,
            default_reasoning="Successfully generated audit test steps.",
        )
        return TestStepsResponse(
            planNumber=request.planNumber,
            test_steps=generation_result["test_steps"],
            rationale=generation_result.get("rationale", ""),
            confidence_score=generation_result.get("confidence_score", 0),
        )
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error generating test steps: {str(e)}"
        )


@router.post("/get-test-steps")
def get_test_steps(request: GenerateTestStepsRequest) -> TestStepsResponse:
    try:
        result = get_test_steps_service().get_test_steps(
            plan_number=request.planNumber,
        )
        return TestStepsResponse(
            planNumber=request.planNumber,
            test_steps=result["test_steps"],
            rationale=result.get("rationale", ""),
            confidence_score=result.get("confidence_score", 0),
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error fetching test steps: {str(e)}"
        )


@router.put("/update-test-steps")
def update_test_steps(request: UpdateTestStepsRequest) -> TestStepsResponse:
    try:
        audit_revision(
            activity_type="TEST_STEPS",
            entity_type="TEST_STEPS",
            plan_number=request.planNumber,
            request_obj=request,
            description="test steps",
        )
        update_arguments = dict(
            plan_number=request.planNumber,
            test_steps=request.test_steps,
        )
        if "rationale" in request.model_fields_set:
            update_arguments["rationale"] = request.rationale
        if "confidence_score" in request.model_fields_set:
            update_arguments["confidence_score"] = request.confidence_score
        updated_result = get_test_steps_service().update_test_steps(**update_arguments)
        return TestStepsResponse(
            planNumber=request.planNumber,
            test_steps=updated_result["test_steps"],
            rationale=updated_result.get("rationale", ""),
            confidence_score=updated_result.get("confidence_score", 0),
        )
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error updating test steps: {str(e)}"
        )


@router.post("/download-discovery-walkthrough")
def download_discovery_walkthrough(
    request: DownloadDiscoveryWalkthroughRequest,
) -> Response:
    try:
        pdf_bytes, headers = download_discovery_walkthrough_pdf(
            plan_number=request.planNumber or "",
            report=request.model_dump(),
        )
        return Response(
            content=pdf_bytes, media_type="application/pdf", headers=headers
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Error generating discovery walkthrough PDF planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/download-inscope-outscope")
def download_scope_recommendation(
    request: DownloadScopeRecommendationRequest,
) -> Response:
    try:
        pdf_bytes, headers = download_scope_recommendation_pdf(
            plan_number=request.planNumber,
            inscope=request.inscope.model_dump(),
            outscope=request.outscope.model_dump(),
        )
        return Response(
            content=pdf_bytes, media_type="application/pdf", headers=headers
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Error generating scope recommendation PDF planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/download-test-steps")
def download_test_steps(request: DownloadTestStepsRequest) -> Response:
    try:
        pdf_bytes, headers = download_test_steps_pdf(
            plan_number=request.planNumber,
            test_steps=request.test_steps,
        )
        return Response(
            content=pdf_bytes, media_type="application/pdf", headers=headers
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Error generating test steps PDF planNumber=%s", request.planNumber
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc
