import logging
import inspect
import uuid
from datetime import datetime, timezone
from typing import Annotated, Any
from fastapi import APIRouter, File, Form, HTTPException, Response, UploadFile
from pydantic import ValidationError
from agent_helper.agent_card import AgentCard
from agent_helper import action_service
from model.request_model import (
    ConfirmDiscoveryWalkthroughUploadRequest,
    ConfirmTestStepsUploadRequest,
    DownloadDiscoveryWalkthroughRequest,
    DownloadScopeRecommendationRequest,
    DownloadTestStepsRequest,
    GenerateDiscoveryWalkthrough,
    GenerateInScopeOutScopeRequest,
    GenerateScopingDocumentRequest,
    GenerateTestStepsRequest,
    GetScopingDocumentRequest,
    GetMeetingNotesSummaryRequest,
    MeetingNotesUploadRequest,
    RefineTestStepsRequest,
    ScopingDocumentContent,
    ScopingDocumentRow,
    TestStepsUploadRequest,
    UpdateScopingDocumentRequest,
    UpdateDiscoveryWalkthroughRequest,
    UpdateInScopeOutScopeRequest,
    UpdateTestStepsRequest,
    UserRequest,
)
from model.response_model import (
    DiscoveryWalkthroughReport,
    DiscoveryWalkthroughUploadResponse,
    MeetingNotesSummaryContentResponse,
    MeetingNotesSummaryResponse,
    InScopeOutScopeResponse,
    TestStepsResponse,
    TestStepsUploadResponse,
)
from persistor.review_research_recommendation_repository import (
    persist_review_research_recommendation,
    update_review_research_recommendation,
)
from service.inscope_outscope_service import InScopeOutScopeService
from service.meeting_notes_service import MeetingNotesService
from service.discovery_walkthrough_service import DiscoveryWalkthroughService
from service.plan_details_service import (
    PlanDetailsService,
    _build_plan_details_rows,
    _build_testing_approach_rows,
    _extract_plan_name,
    _normalize_plan_details_payload,
)
from service.scoping_document_service import ScopingDocumentService
from service.test_steps_service import (
    TestStepsRefinementTargetNotFoundError,
    TestStepsService,
)
from service.pdf_download_service import (
    download_discovery_walkthrough_pdf,
    download_scoping_document_pdf_from_html,
    download_scope_recommendation_pdf,
    download_test_steps_pdf,
)

from config.config import Config

from service.discovery_walkthrough_upload_service import (
    DiscoveryWalkthroughUploadService,
)
from service.test_steps_upload_service import TestStepsUploadService
from utils.blob_metadata import blob_metadata, report_blob_metadata

logger = logging.getLogger(__name__)
router = APIRouter()

inscope_outscope_service = None
meeting_notes_service = None
test_steps_service = None
discovery_walkthrough_service = None
plan_details_service = None
scoping_document_service = None
discovery_walkthrough_upload_service = None

test_steps_upload_service = None


def get_discovery_walkthrough_service() -> DiscoveryWalkthroughService:
    global discovery_walkthrough_service
    if discovery_walkthrough_service is None:
        discovery_walkthrough_service = DiscoveryWalkthroughService()
    return discovery_walkthrough_service


def get_inscope_outscope_service() -> InScopeOutScopeService:
    global inscope_outscope_service
    if inscope_outscope_service is None:
        inscope_outscope_service = InScopeOutScopeService()
    return inscope_outscope_service


def get_meeting_notes_service() -> MeetingNotesService:
    global meeting_notes_service
    if meeting_notes_service is None:
        meeting_notes_service = MeetingNotesService()
    return meeting_notes_service


def get_test_steps_service() -> TestStepsService:
    global test_steps_service
    if test_steps_service is None:
        test_steps_service = TestStepsService()
    return test_steps_service


def get_plan_details_service() -> PlanDetailsService:
    global plan_details_service
    if plan_details_service is None:
        plan_details_service = PlanDetailsService()
    return plan_details_service


def get_scoping_document_service() -> ScopingDocumentService:
    global scoping_document_service
    if scoping_document_service is None:
        scoping_document_service = ScopingDocumentService()
    return scoping_document_service


def get_discovery_walkthrough_upload_service() -> DiscoveryWalkthroughUploadService:
    global discovery_walkthrough_upload_service
    if discovery_walkthrough_upload_service is None:
        discovery_walkthrough_upload_service = DiscoveryWalkthroughUploadService()
    return discovery_walkthrough_upload_service


def get_test_steps_upload_service() -> TestStepsUploadService:
    global test_steps_upload_service
    if test_steps_upload_service is None:
        test_steps_upload_service = TestStepsUploadService()
    return test_steps_upload_service


def _scope_report_text(artifact: dict, key: str) -> str:
    payload = artifact.get(key, {})
    report = payload if isinstance(payload, str) else (payload or {}).get("report", "")
    return str(report).strip()


def _build_scoping_document_content(plan_number: str) -> ScopingDocumentContent:
    artifacts = get_scoping_document_service().load_source_artifacts(plan_number)
    inscope = _scope_report_text(artifacts["inscope"], "inscope")
    outscope = _scope_report_text(artifacts["outscope"], "outscope")
    if not inscope and not outscope:
        raise ValueError("Both inscope.report and outscope.report are empty.")

    plan_details = artifacts["plan_details"]
    test_steps = artifacts["test_steps"]
    purpose_statement = _normalize_plan_details_payload(plan_details).get(
        "Description of Plan Item"
    )
    return ScopingDocumentContent(
        plan_name=_extract_plan_name(plan_details) or "",
        purpose_statement=str(purpose_statement or "").replace("\r\n", "\n").strip(),
        plan_details_rows=[
            ScopingDocumentRow(key=str(key or ""), value=str(value or ""))
            for key, value in _build_plan_details_rows(
                plan_details,
                default_system_id=plan_number,
            )
        ],
        inscope=inscope,
        outscope=outscope,
        testing_approach_rows=[
            ScopingDocumentRow(key=str(key or ""), value=str(value or ""))
            for key, value in _build_testing_approach_rows(
                test_steps.get("test_steps", [])
            )
        ],
    )


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/meeting-notes")
@router.post("/generate-meeting-notes")
async def summarize_meeting_notes(
    planNumber: Annotated[str, Form(description="Plan number")],
    files: Annotated[
        list[UploadFile], File(description="Meeting notes or MOM documents")
    ],
) -> MeetingNotesSummaryResponse:
    if not planNumber.strip():
        raise HTTPException(status_code=400, detail="planNumber is required.")
    if not files:
        raise HTTPException(status_code=400, detail="At least one document is required.")

    start_time_dt = datetime.now(timezone.utc)
    agent_card = AgentCard.build_agent_card(
        activity_type="SCOPE_RECOMMENDATION",
        plan_item_number=planNumber,
        entity_type="SCOPING_PROCEDURE",
        parent_entity_type="SCOPING",
        parent_entity_id=planNumber,
        actor_id="dbaware@db.com",
        actor_type="HUMAN",
    )

    action_service.construct_human_actor_generate_meeting_notes_record(plan_number= planNumber,
                                                activity_type="SCOPE_RECOMMENDATION",
                                                query =f"Consolidate and summarize {len(files)} meeting notes for plan number {planNumber}",
                                                user="dbaware@db.com")

    service = get_meeting_notes_service()
    try:
        result, usage_metadata = await service.process_meeting_notes(
            MeetingNotesUploadRequest(
                planNumber=planNumber,
                files=files,
            )
        )

        final_answer = (
            getattr(result, "normalized_summary_uri", None)
            or getattr(result, "normalized_meeting_notes", None)
            or str(result)
        )

        input_tokens = usage_metadata.get("input_tokens", 0)
        output_tokens = usage_metadata.get("output_tokens", 0)
        logger.info("Meeting Notes Tokens - Input-Tokens: %s | Output-Tokens: %s ", input_tokens, output_tokens)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_meeting_notes_record(
            plan_number=planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=input_tokens,
            total_output_tokens=output_tokens,
            final_answer=str(final_answer),
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=1.0,
            reasoning="",
            response_code=200,
            env_config=Config

        )
        return result
    except ValueError as error:
        logger.exception("Value Error for  plan_number=%s error=%s", planNumber, error)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_meeting_notes_record(
            plan_number=planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=500,
            env_config=Config
        )
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.post("/get-meeting-notes-summary")
def get_meeting_notes_summary(
    request: GetMeetingNotesSummaryRequest,
) -> MeetingNotesSummaryContentResponse:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_actor_get_document_meeting_notes_record(plan_number=request.planNumber,
                                                                 activity_type="SCOPE_RECOMMENDATION",
                                                                 user="dbaware@db.com",
                                                                 user_remarks="")
        summary_data = get_meeting_notes_service().get_meeting_notes_summary(
            request.planNumber
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_meeting_notes_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user="dbaware@db.com",
            user_remarks="",
            remarks=f"Successfully Fetched for plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=200)
        return MeetingNotesSummaryContentResponse(
            planNumber=request.planNumber,
            normalized_meeting_notes=summary_data.get("normalized_meeting_notes"),
        )
    except FileNotFoundError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_meeting_notes_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user="dbaware@db.com",
            user_remarks="",
            remarks=f"Failed to  Fetch document for plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=404)
        logger.exception("File not found Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_meeting_notes_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user="dbaware@db.com",
            user_remarks="",
            remarks=f"Failed to  Fetch document for plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=400)
        logger.exception("Validation Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_meeting_notes_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user="dbaware@db.com",
            user_remarks="",
            remarks=f"Failed to  Fetch document for plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=500)
        logger.exception("Exception for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(
            status_code=500, detail=f"Error fetching meeting notes summary: {str(e)}"
        )


@router.post("/generate-inscope-outscope")
def generate_inscope_outscope(
    request: GenerateInScopeOutScopeRequest,
) -> InScopeOutScopeResponse:
    logger.info("Received inscope/outscope request planNumber=%s", request.planNumber)
    try:
        start_time_dt = datetime.now(timezone.utc)
        agent_card = AgentCard.build_agent_card(
            activity_type="SCOPE_RECOMMENDATION",
            plan_item_number=request.planNumber,
            entity_type="SCOPING_PROCEDURE",
            parent_entity_type="SCOPING",
            parent_entity_id=request.planNumber,
            actor_id="dbaware@db.com",
            actor_type="HUMAN",
        )

        action_service.construct_human_actor_generate_record(
                                                            plan_number=request.planNumber,
                                                            activity_type="SCOPE_RECOMMENDATION",
                                                            query=f"Generate in-scope and out-of-scope "
                                                                f"recommendations for plan number {request.planNumber}",
                                                            user=request.userDetails.user)

        raw_generation_result = get_inscope_outscope_service().generate_inscope_outscope(
            plan_number=request.planNumber,
        )
        if isinstance(raw_generation_result, tuple):
            generation_result, usage_metadata = raw_generation_result
        else:
            generation_result, usage_metadata = raw_generation_result, {"input_tokens": 0, "output_tokens": 0}

        inscope_val = generation_result.get("inscope", "")
        outscope_val = generation_result.get("outscope", "")

        input_tokens = usage_metadata.get('input_tokens', 0)
        output_tokens =usage_metadata.get('input_tokens', 0)
        logger.info("Scope Recommendation Tokens - Input-Tokens: %s | Output-Tokens: %s ", input_tokens, output_tokens)
        rationale = generation_result.get("rationale")
        if not rationale and isinstance(inscope_val, dict) and isinstance(outscope_val, dict):
            in_rat = inscope_val.get("rationale", "")
            out_rat = outscope_val.get("rationale", "")
            rationale = f"In-scope: {in_rat} | Out-scope: {out_rat}".strip(" |")
        rationale = rationale or "Successfully generated in-scope / out-of-scope boundaries."

        confidence_score = generation_result.get("confidence_score")
        if confidence_score is None:
            if isinstance(inscope_val, dict) and isinstance(outscope_val, dict):
                in_score = inscope_val.get("confidence_score", 100)
                out_score = outscope_val.get("confidence_score", 100)
                confidence_score = int((in_score + out_score) / 2)
            else:
                confidence_score = 0


        api_response = InScopeOutScopeResponse(
            planNumber=request.planNumber,
            inscope=generation_result["inscope"],
            outscope=generation_result["outscope"],
            rationale=generation_result.get("rationale", ""),
            confidence_score=generation_result.get("confidence_score", 0),
        )
        try:
            review_rr_id = persist_review_research_recommendation(
                review_scope_id=request.userDetails.review_scope_id,
                metadata=report_blob_metadata(request.planNumber, Config.PROCEDURE_PROCESSING_PATH, ("inscope.json", "outscope.json")),
                report_type="SCOPE_RECOMMENDATION",
                created_by=request.userDetails.user,
                remarks=request.userDetails.remarks,
            )
            logger.info(
                "Persisted research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                review_rr_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the generation response.
            logger.exception(
                "Failed to persist research recommendation plan_number=%s",
                request.planNumber,
            )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=input_tokens,
            total_output_tokens=output_tokens,
            final_answer=f"Inscope: {inscope_val}\nOutscope: {outscope_val}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=confidence_score,
            reasoning=rationale,
            response_code=200,
            env_config=Config
        )
        return api_response
    except FileNotFoundError as e:
        logger.exception(
            "Data not found for inscope/outscope planNumber=%s error=%s",
            request.planNumber,
            e,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=404,
            env_config=Config
        )
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        logger.exception(
            "Invalid inscope/outscope request planNumber=%s error=%s",
            request.planNumber,
            e,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=400,
            env_config=Config
        )
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except ValueError as e:
        logger.exception(
            "Invalid inscope/outscope data planNumber=%s error=%s",
            request.planNumber,
            e,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=400,
            env_config=Config
        )
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException as e:
        logger.exception(
            "HttpException planNumber=%s error=%s",
            request.planNumber, e,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=500,
            env_config=Config
        )
        raise
    except Exception as e:
        logger.exception(
            "Unexpected error generating inscope/outscope planNumber=%s",
            request.planNumber,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=500,
            env_config=Config
        )
        raise HTTPException(
            status_code=500, detail=f"Error generating inscope/outscope: {str(e)}"
        )


@router.post("/get-inscope-outscope")
def get_inscope_outscope(
    request: GenerateInScopeOutScopeRequest,
) -> InScopeOutScopeResponse:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_actor_get_document_record(plan_number=request.planNumber,
                                                                 activity_type="SCOPE_RECOMMENDATION",
                                                                 user=request.userDetails.user,
                                                                 user_remarks=request.userDetails.remarks)
        result = get_inscope_outscope_service().get_inscope_outscope(
            plan_number=request.planNumber,
        )
        inscope_val = result.get("inscope", "")
        outscope_val = result.get("outscope", "")
        rationale = result.get("rationale")
        if not rationale and isinstance(inscope_val, dict) and isinstance(outscope_val, dict):
            in_rat = inscope_val.get("rationale", "")
            out_rat = outscope_val.get("rationale", "")
            rationale = f"In-scope: {in_rat} | Out-scope: {out_rat}".strip(" |")
        rationale = rationale or "Successfully fetched in-scope / out-of-scope boundaries."
        confidence_score = result.get("confidence_score")
        if confidence_score is None:
            if isinstance(inscope_val, dict) and isinstance(outscope_val, dict):
                confidence_score = int((inscope_val.get("confidence_score", 100) + outscope_val.get("confidence_score", 100)) / 2)
            else:
                confidence_score = 0
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks="Successfully Fetched",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=200)
        return InScopeOutScopeResponse(
            planNumber=request.planNumber,
            inscope=inscope_val,
            outscope=outscope_val,
            rationale=rationale,
            confidence_score=confidence_score,
        )
    except FileNotFoundError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks=f"Failed to fetched the document = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=404)
        logger.exception("File not found error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks=f"Failed to fetched the document = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=400)
        logger.exception("Validation error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="SCOPE_RECOMMENDATION",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks=f"Failed to fetched the document = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=500)
        logger.exception("Exception error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(
            status_code=500, detail=f"Error fetching inscope/outscope: {str(e)}"
        )


@router.post("/generate-scoping-document")
def GENERATE_SCOPING_DOCUMENT(request: GenerateScopingDocumentRequest) -> Response:
    try:
        start_time_dt = datetime.now(timezone.utc)
        document_service = get_scoping_document_service()
        document = document_service.get_saved_document(request.planNumber)
        if document is None:
            start_time_dt = datetime.now(timezone.utc)
            agent_card = AgentCard.build_agent_card(
                activity_type="FINAL_SCOPING_DOCUMENT",
                plan_item_number=request.planNumber,
                entity_type="SCOPING_PROCEDURE",
                parent_entity_type="SCOPING",
                parent_entity_id=request.planNumber,
                actor_id="dbaware@db.com",
                actor_type="HUMAN",
            )

            #### it should be get operation

            action_service.construct_human_actor_get_document_record(
                                                        plan_number=request.planNumber,
                                                        activity_type="FINAL_SCOPING_DOCUMENT",
                                                        user=request.userDetails.user,
                                                        user_remarks=request.userDetails.remarks)

            document = _build_scoping_document_content(request.planNumber)
            uri = document_service.save_document(request.planNumber, document)
            try:
                review_rr_id = persist_review_research_recommendation(
                    review_scope_id=request.userDetails.review_scope_id,
                    metadata=blob_metadata([uri]),
                    report_type="SCOPING_DOCUMENT",
                    created_by=request.userDetails.user,
                    remarks=request.userDetails.remarks,
                )
                logger.info(
                    "Persisted research recommendation plan_number=%s review_rr_id=%s",
                    request.planNumber,
                    review_rr_id,
                )
            except Exception:
                # Persistence is best-effort; do not fail the generation response.
                logger.exception(
                    "Failed to persist research recommendation plan_number=%s",
                    request.planNumber,
                )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="FINAL_SCOPING_DOCUMENT",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks="Successfully Fetched",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=200)
        return Response(
            content=document_service.render_editor_html(request.planNumber, document),
            media_type="text/html",
            headers={"Content-Disposition": "inline; filename=scoping_document.html"},
        )
    except FileNotFoundError as error:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="FINAL_SCOPING_DOCUMENT",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks="Failed",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=404)
        logger.exception("FileNotFoundError for  plan_number=%s error=%s", request.planNumber, error)
        raise HTTPException(status_code=404, detail=str(error)) from error
    except ValueError as error:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="FINAL_SCOPING_DOCUMENT",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks="Failed",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=400)
        logger.exception("Value Error for  plan_number=%s error=%s", request.planNumber, error)
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="FINAL_SCOPING_DOCUMENT",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks="Failed",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=500)
        logger.exception(
            "Error generating editable scoping document planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.put("/update-scoping-document")
def update_scoping_document(request: UpdateScopingDocumentRequest) -> dict:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_update_record(plan_number=request.planNumber,
                                                     activity_type="FINAL_SCOPING_DOCUMENT",
                                                     human_notes=f"save human edited scoping document "
                                                                   f"for plan_number = {request.planNumber}",
                                                     updated_by=request.userDetails.user,
                                                     updated_section=list(request.document.model_dump(exclude={"planNumber"}, exclude_unset=True).keys()))

        document_service = get_scoping_document_service()
        uri = document_service.save_document(request.planNumber, request.document)
        try:
            updated_id = update_review_research_recommendation(

                review_scope_id=request.userDetails.review_scope_id,
                report_type="SCOPING_DOCUMENT",
                metadata=blob_metadata([uri]),
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s",
                request.planNumber,
            )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="FINAL_SCOPING_DOCUMENT",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=200,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Saved successfully the human edited scoping dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        return {
            "planNumber": request.planNumber,
            "document": request.document.model_dump(),
            "saved": True,
            "uri": uri,
        }
    except ValueError as error:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="FINAL_SCOPING_DOCUMENT",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=400,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to save the human edited scoping dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Value Error for  plan_number=%s error=%s", request.planNumber, error)
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception(
            "Error updating editable scoping document planNumber=%s",
            request.planNumber,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="FINAL_SCOPING_DOCUMENT",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=500,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to save the human edited scoping dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Exception Error for  plan_number=%s error=%s", request.planNumber, error)
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.post("/download-scoping-document")
def download_edited_scoping_document(request: GetScopingDocumentRequest) -> Response:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_download_record(plan_number=request.planNumber,
                                                       activity_type="FINAL_SCOPING_DOCUMENT",
                                                       human_notes=f"Download scoping document for plan_number = {request.planNumber}",
                                                       updated_by="dbaware@db.com",
                                                       data=request.test_steps)
        document_service = get_scoping_document_service()
        document = document_service.get_saved_document(request.planNumber)
        if document is None:
            document = _build_scoping_document_content(request.planNumber)
            document_service.save_document(request.planNumber, document)

        pdf_bytes, headers = download_scoping_document_pdf_from_html(
            plan_number=request.planNumber,
            html_content=document_service.render_pdf_html(request.planNumber, document),
        )

        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                                activity_type="FINAL_SCOPING_DOCUMENT",
                                                                start_time=start_time_dt,
                                                                end_time=end_time_dt,
                                                                response_code=200,
                                                                updated_by="",
                                                                response_text=f"Succfully downloaded the document for planNumber = {request.planNumber}, ",
                                                                remarks="")
        return Response(content=pdf_bytes, media_type="application/pdf", headers=headers)

    except FileNotFoundError as error:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                                activity_type="FINAL_SCOPING_DOCUMENT",
                                                                start_time=start_time_dt,
                                                                end_time=end_time_dt,
                                                                response_code=404,
                                                                updated_by="",
                                                                response_text=f"Failed to  downloaded the document for planNumber = {request.planNumber}, ",
                                                                remarks="")
        logger.exception("File Not Found Error for  plan_number=%s error=%s", request.planNumber, error)
        raise HTTPException(status_code=404, detail=str(error)) from error
    except ValueError as error:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                                activity_type="FINAL_SCOPING_DOCUMENT",
                                                                start_time=start_time_dt,
                                                                end_time=end_time_dt,
                                                                response_code=400,
                                                                updated_by="",
                                                                response_text=f"Failed to  downloaded the document for planNumber = {request.planNumber}, ",
                                                                remarks="")
        logger.exception("Value Error for  plan_number=%s error=%s", request.planNumber, error)
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                                activity_type="FINAL_SCOPING_DOCUMENT",
                                                                start_time=start_time_dt,
                                                                end_time=end_time_dt,
                                                                response_code=500,
                                                                updated_by="",
                                                                response_text=f"Failed to  downloaded the document for planNumber = {request.planNumber}, ",
                                                                remarks="")
        logger.exception(
            "Error downloading edited scoping document planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(status_code=500, detail=str(error)) from error


@router.put("/update-inscope-outscope")
def update_inscope_outscope(
    request: UpdateInScopeOutScopeRequest,
) -> InScopeOutScopeResponse:
    start_time_dt = datetime.now(timezone.utc)
    try:

        action_service.construct_human_update_record(plan_number=request.planNumber,
                                                     activity_type="SCOPE_RECOMMENDATION",
                                                     human_notes=f"save human edited in-scope and out-scope document for plan_number = {request.planNumber}",
                                                     updated_by=request.userDetails.user,
                                                     updated_section=list(
                                                         request.model_dump(exclude={"planNumber", "userDetails"},
                                                                            exclude_unset=True).keys()))

        update_arguments = dict(
            plan_number=request.planNumber,
            inscope=request.inscope,
            outscope=request.outscope,
        )
        if "rationale" in request.model_fields_set:
            update_arguments["rationale"] = request.rationale
        if "confidence_score" in request.model_fields_set:
            update_arguments["confidence_score"] = request.confidence_score
        updated_result = get_inscope_outscope_service().update_inscope_outscope(
            **update_arguments
        )
        api_response = InScopeOutScopeResponse(
            planNumber=request.planNumber,
            inscope=updated_result["inscope"],
            outscope=updated_result["outscope"],
            rationale=updated_result.get("rationale", ""),
            confidence_score=updated_result.get("confidence_score", 0),
        )
        try:
            updated_id = update_review_research_recommendation(
                review_scope_id=request.userDetails.review_scope_id,
                report_type="SCOPE_RECOMMENDATION",
                metadata=report_blob_metadata(request.planNumber, Config.PROCEDURE_PROCESSING_PATH, ("inscope.json", "outscope.json")),
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                updated_id,
            )

            end_time_dt = datetime.now(timezone.utc)
            action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                               activity_type="SCOPE_RECOMMENDATION",
                                                               start_time=start_time_dt,
                                                               end_time=end_time_dt,
                                                               response_code=200,
                                                               updated_by=request.userDetails.user,
                                                               response_text=f"Saved successfully the inscope-outscope dcoument for plan_number = {request.planNumber}",
                                                               remarks="")
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s",
                request.planNumber,
            )
        return api_response
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="SCOPE_RECOMMENDATION",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=400,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to save the inscope-outscope dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Validation Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="SCOPE_RECOMMENDATION",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=500,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to save the inscope-outscope dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Exception Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(
            status_code=500, detail=f"Error updating inscope/outscope: {str(e)}"
        )


@router.post("/generate-discovery-walkthrough")
async def generate_discovery_walkthrough(request: GenerateDiscoveryWalkthrough):
    plan_number = request.planNumber
    logger.info("Received discovery walkthrough request planNumber=%s", plan_number)
    start_time_dt = datetime.now(timezone.utc)
    agent_card = AgentCard.build_agent_card(
        activity_type="DISCOVERY_WALKTHROUGH",
        plan_item_number=plan_number,
        entity_type="SCOPING_PROCEDURE",
        parent_entity_type="SCOPING",
        parent_entity_id=plan_number,
        actor_id="dbaware@db.com",
        actor_type="HUMAN",
    )
    action_service.construct_human_actor_generate_record(
                                                plan_number=request.planNumber,
                                                activity_type="DISCOVERY_WALKTHROUGH",
                                                query=f"Generate discovery walkthrough report for plan number {plan_number}",
                                                user=request.userDetails.user)

    service = get_discovery_walkthrough_service()
    try:
        report, usage_metadata = await service.generate_report(plan_number)
        if inspect.isawaitable(report):
            report = await report
        if inspect.isawaitable(usage_metadata):
            usage_metadata = await usage_metadata

        input_tokens = 0
        output_tokens=0

        if isinstance(usage_metadata, dict):
            input_tokens = usage_metadata.get('input_tokens',0)
            output_tokens = usage_metadata.get('input_tokens',0)
        logger.info("Discovery Walkthrough Tokens - Input-Tokens: %s | Output-Tokens: %s ", input_tokens, output_tokens)
        score = 1.0
        reasoning = "Successfully generated discovery walkthrough."
        if isinstance(report, dict):
            score = float(report.get("confidence_score", 100)) / 100.0
            reasoning = str(report.get("rationale", reasoning))

        try:
            review_rr_id = persist_review_research_recommendation(
                review_scope_id=request.userDetails.review_scope_id,
                metadata=report_blob_metadata(plan_number, Config.SCOPING_FOLDER_PATH, (Config.DISCOVERY_WALKTHROUGH_FILE,)),
                report_type="DISCOVERY_WALKTHROUGH",
                created_by=request.userDetails.user,
                remarks=request.userDetails.remarks,
            )
            logger.info(
                "Persisted research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                review_rr_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the generation response.
            logger.exception(
                "Failed to persist research recommendation plan_number=%s",
                request.planNumber,
            )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="DISCOVERY_WALKTHROUGH",
            total_input_tokens=input_tokens,
            total_output_tokens=output_tokens,
            final_answer=str(report),
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=score,
            reasoning=reasoning,
            response_code= 200,
            env_config=Config
        )
        return report
    except FileNotFoundError as exc:
        logger.exception(
            "Preliminary report not found. planNumber=%s. Error: %s",
            request.planNumber,
            exc,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="DISCOVERY_WALKTHROUGH",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="Error",
            response_code=404,
            env_config=Config
        )
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        logger.exception(
            "Unexpected error in generate_discovery_walkthrough. planNumber=%s",
            request.planNumber,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="DISCOVERY_WALKTHROUGH",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=500,
            env_config=Config
        )
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get-discovery-walkthrough")
def get_discovery_walkthrough(
    request: GenerateDiscoveryWalkthrough,
) -> DiscoveryWalkthroughReport:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_actor_get_document_record(plan_number=request.planNumber,
                                                                 activity_type="DISCOVERY_WALKTHROUGH",
                                                                 user=request.userDetails.user,
                                                                 user_remarks=request.userDetails.remarks)

        report_data = get_discovery_walkthrough_service().get_report(request.planNumber)
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="DISCOVERY_WALKTHROUGH",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks="Successfully Fetched",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=200)
        return DiscoveryWalkthroughReport(**report_data)
    except FileNotFoundError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="DISCOVERY_WALKTHROUGH",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks=f"Failed to fetch document for plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=404)
        logger.exception("File not Found Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="DISCOVERY_WALKTHROUGH",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks=f"Failed to fetch document for plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=400)
        logger.exception("Validation Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="DISCOVERY_WALKTHROUGH",
            user=request.userDetails.user,
            user_remarks=request.userDetails.remarks,
            remarks=f"Failed to fetch document for plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=500)
        logger.exception("Exception Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(
            status_code=500, detail=f"Error fetching discovery walkthrough: {str(e)}"
        )


@router.put("/update-discovery-walkthrough")
def update_discovery_walkthrough(
    request: UpdateDiscoveryWalkthroughRequest,
) -> DiscoveryWalkthroughReport:
    try:

        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_update_record(plan_number=request.planNumber,
                                                     activity_type="DISCOVERY_WALKTHROUGH",
                                                     human_notes=f"save human edited discovery walkthrough document for plan_number = {request.planNumber}",
                                                     updated_by=request.userDetails.user,
                                                     updated_section=list(
                                                         request.model_dump(exclude={"planNumber", "userDetails"},
                                                                            exclude_unset=True).keys()))
        updated_report = get_discovery_walkthrough_service().update_report(
            plan_number=request.planNumber,
            report_data=request.model_dump(
                exclude={"planNumber", "userDetails"}, exclude_unset=True
            ),
        )
        api_response = DiscoveryWalkthroughReport(**updated_report)
        try:
            updated_id = update_review_research_recommendation(
                review_scope_id=request.userDetails.review_scope_id,
                report_type="DISCOVERY_WALKTHROUGH",
                metadata=report_blob_metadata(request.planNumber, Config.SCOPING_FOLDER_PATH, (Config.DISCOVERY_WALKTHROUGH_FILE,)),
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                request.planNumber,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s",
                request.planNumber,
            )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="DISCOVERY_WALKTHROUGH",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=200,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Saved successfully the discovery walkthrough dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        return api_response
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="DISCOVERY_WALKTHROUGH",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=400,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to Save the human edited discovery walkthrough dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Validation Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="DISCOVERY_WALKTHROUGH",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=500,
                                                           updated_by=request.userDetails.user,
                                                           response_text=f"Failed to Save the human edited discovery walkthrough dcoument for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Exception Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(
            status_code=500, detail=f"Error updating discovery walkthrough: {str(e)}"
        )


@router.post("/generate-test-steps")
def generate_test_steps(request: GenerateTestStepsRequest) -> TestStepsResponse:
    logger.info(
        "ENTER /generate-test-steps planNumber=%s",
        request.planNumber,
    )
    try:

        start_time_dt = datetime.now(timezone.utc)
        agent_card = AgentCard.build_agent_card(
            activity_type="TEST_STEPS",
            plan_item_number=request.planNumber,
            entity_type="SCOPING_PROCEDURE",
            parent_entity_type="SCOPING",
            parent_entity_id=request.planNumber,
            actor_id="dbaware@db.com",
            actor_type="HUMAN",
        )

        action_service.construct_human_actor_generate_record(
                                                    plan_number=request.planNumber,
                                                    activity_type="TEST_STEPS",
                                                    query=f"Generate compliance audit test steps for plan number {request.planNumber}",
                                                             user=request.userDetails.user)

        service = get_test_steps_service()
        generation_result, usage_metadata = service.generate_test_steps(
            plan_number=request.planNumber,
        )

        input_tokens = usage_metadata.get("input_tokens", 0)
        output_tokens = usage_metadata.get("output_tokens", 0)
        logger.info("Test Steps Tokens - Input-Tokens: %s | Output-Tokens: %s ", input_tokens, output_tokens)

        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="TEST_STEPS",
            total_input_tokens=input_tokens,
            total_output_tokens=output_tokens,
            final_answer=str(generation_result.get("test_steps", "")),
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=200,
            env_config=Config

        )
        api_response = TestStepsResponse(
            planNumber=request.planNumber,
            test_steps=generation_result.get("test_steps", []),
            rationale=generation_result.get("rationale", ""),
            confidence_score=generation_result.get("confidence_score", 0),
        )
        if request.userDetails and request.userDetails.review_scope_id is not None:
            try:
                persist_review_research_recommendation(
                    review_scope_id=request.userDetails.review_scope_id,
                    metadata=report_blob_metadata(
                        request.planNumber, Config.PROCEDURE_PROCESSING_PATH, ("test-steps.json",)
                    ),
                    report_type="TEST_STEPS",
                    created_by=request.userDetails.user,
                    remarks=request.userDetails.remarks,
                )
            except Exception:
                logger.exception("Failed to persist test steps plan_number=%s", request.planNumber)
        else:
            logger.warning("Skipping test steps database persistence without review_scope_id plan_number=%s", request.planNumber)
        return api_response
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="TEST_STEPS",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=400,
            env_config=Config
        )
        logger.exception(f"Exception {e}")
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_response_record(
            plan_number=request.planNumber,
            activity_type="TEST_STEPS",
            total_input_tokens=0,
            total_output_tokens=0,
            final_answer="Error",
            start_time=start_time_dt,
            end_time=end_time_dt,
            score=0,
            reasoning="",
            response_code=400,
            env_config=Config
        )
        logger.exception(f"Exception {e}")
        raise HTTPException(
            status_code=500, detail=f"Error generating test steps: {str(e)}"
        )


@router.post("/get-test-steps")
def get_test_steps(request: GenerateTestStepsRequest) -> TestStepsResponse:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_actor_get_document_record(plan_number=request.planNumber,
                                                                 activity_type="TEST_STEPS",
                                                                 user=request.userDetails.user,
                                                                 user_remarks="")
        result = get_test_steps_service().get_test_steps(
            plan_number=request.planNumber,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="TEST_STEPS",
            user="dbaware@db.com",
            user_remarks="",
            remarks="Successfully Fetched",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=200)

        return TestStepsResponse(
            planNumber=request.planNumber,
            test_steps=result.get("test_steps", []),
            rationale=result.get("rationale", ""),
            confidence_score=result.get("confidence_score", 0),
        )
    except FileNotFoundError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="TEST_STEPS",
            user="dbaware@db.com",
            user_remarks="",
            remarks=f"Failed to Fetch document with plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=404)
        logger.exception("File not found error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="TEST_STEPS",
            user="dbaware@db.com",
            user_remarks="",
            remarks=f"Failed to Fetch document with plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=400)
        logger.exception("Validation Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_actor_get_document_response_record(
            plan_number=request.planNumber,
            activity_type="TEST_STEPS",
            user="dbaware@db.com",
            user_remarks="",
            remarks=f"Failed to Fetch document with plan_number = {request.planNumber}",
            start_time=start_time_dt,
            end_time=end_time_dt,
            response_code=500)
        logger.exception("Exception  Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(
            status_code=500, detail=f"Error fetching test steps: {str(e)}"
        )


@router.post("/refine-test-steps")
def refine_test_steps(request: RefineTestStepsRequest) -> TestStepsResponse:
    try:
        result = get_test_steps_service().refine_test_steps(
            plan_number=request.planNumber,
            test_steps=request.test_steps,
            comment=request.comment,
        )

        return TestStepsResponse(
            planNumber=request.planNumber,
            test_steps=result["test_steps"],
        )
    except TestStepsRefinementTargetNotFoundError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error refining test steps: {str(e)}"
        )


@router.put("/update-test-steps")
def update_test_steps(request: UpdateTestStepsRequest) -> TestStepsResponse:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_update_record(plan_number=request.planNumber,
                                                     activity_type="TEST_STEPS",
                                                     human_notes=f"save human edited test_steps document for plan_number = {request.planNumber}",
                                                     updated_by=request.userDetails.user,
                                                     updated_section=list(
                                                         request.model_dump(exclude={"planNumber", "userDetails"},
                                                                            exclude_unset=True).keys()))

        update_arguments = dict(
            plan_number=request.planNumber,
            test_steps=request.test_steps,
        )
        if "rationale" in request.model_fields_set:
            update_arguments["rationale"] = request.rationale
        if "confidence_score" in request.model_fields_set:
            update_arguments["confidence_score"] = request.confidence_score
        updated_result = get_test_steps_service().update_test_steps(**update_arguments)
        api_response = TestStepsResponse(
            planNumber=request.planNumber,
            test_steps=updated_result.get("test_steps", []),
            rationale=updated_result.get("rationale", ""),
            confidence_score=updated_result.get("confidence_score", 0),
        )
        if request.userDetails and request.userDetails.review_scope_id is not None:
            try:
                update_review_research_recommendation(
                    review_scope_id=request.userDetails.review_scope_id,
                    report_type="TEST_STEPS",
                    metadata=report_blob_metadata(
                        request.planNumber, Config.PROCEDURE_PROCESSING_PATH, ("test-steps.json",)
                    ),
                    updated_by=request.userDetails.user,
                )
            except Exception:
                logger.exception("Failed to update test steps plan_number=%s", request.planNumber)
        else:
            logger.warning("Skipping test steps database update without review_scope_id plan_number=%s", request.planNumber)
        return api_response
    except ValidationError as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="TEST_STEPS",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=400,
                                                           updated_by="dbaware@db.com",
                                                           response_text=f"Failed to save the human edited test steps for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Validation Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(status_code=400, detail=f"Invalid request: {str(e)}")
    except Exception as e:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_update_response_record(plan_number=request.planNumber,
                                                           activity_type="TEST_STEPS",
                                                           start_time=start_time_dt,
                                                           end_time=end_time_dt,
                                                           response_code=500,
                                                           updated_by="dbaware@db.com",
                                                           response_text=f"Failed to save the human edited test steps for plan_number = {request.planNumber}",
                                                           remarks="")
        logger.exception("Exception Error for  plan_number=%s error=%s", request.planNumber, e)
        raise HTTPException(
            status_code=500, detail=f"Error updating test steps: {str(e)}"
        )


@router.post("/download-discovery-walkthrough")
def download_discovery_walkthrough(
    request: DownloadDiscoveryWalkthroughRequest,
) -> Response:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_download_record(plan_number=request.planNumber,
                                                       activity_type="DISCOVERY_WALKTHROUGH",
                                                       human_notes = f"Download document for plan_number = {request.planNumber}",
                                                       updated_by="dbaware@db.com",
                                                       data=request.model_dump())
        pdf_bytes, headers = download_discovery_walkthrough_pdf(
            plan_number=request.planNumber or "",
            report=request.model_dump(),
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="DISCOVERY_WALKTHROUGH",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=200,
                                                             updated_by="",
                                                             response_text=f"Succfully downloaded the discovery walkthrough document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        return Response(
            content=pdf_bytes, media_type="application/pdf", headers=headers
        )
    except ValueError as exc:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="DISCOVERY_WALKTHROUGH",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=400,
                                                             updated_by="",
                                                             response_text=f"Failed to  downloaded the discovery walkthrough document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        logger.exception("Value Error for  plan_number=%s error=%s", request.planNumber, exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Error generating discovery walkthrough PDF planNumber=%s",
            request.planNumber,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="DISCOVERY_WALKTHROUGH",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=500,
                                                             updated_by="",
                                                             response_text=f"Failed to  downloaded the discovery walkthrough document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/download-inscope-outscope")
def download_scope_recommendation(
    request: DownloadScopeRecommendationRequest,
) -> Response:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_download_record(plan_number=request.planNumber,
                                                       activity_type="SCOPE_RECOMMENDATION",
                                                       human_notes=f"Download document for plan_number = {request.planNumber}",
                                                       updated_by="dbaware@db.com",
                                                       data="")
        pdf_bytes, headers = download_scope_recommendation_pdf(
            plan_number=request.planNumber,
            inscope=request.inscope.model_dump(),
            outscope=request.outscope.model_dump(),
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="SCOPE_RECOMMENDATION",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=200,
                                                             updated_by="dbaware@db.com",
                                                             response_text=f"Succfully downloaded the inscode and outscope document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        return Response(
            content=pdf_bytes, media_type="application/pdf", headers=headers
        )
    except ValueError as exc:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="SCOPE_RECOMMENDATION",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=400,
                                                             updated_by="dbaware@db.com",
                                                             response_text=f"Failed to downloaded the inscope and outscope document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        logger.exception("Value Error for  plan_number=%s error=%s", request.planNumber, exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception(
            "Error generating scope recommendation PDF planNumber=%s",
            request.planNumber,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="SCOPE_RECOMMENDATION",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=500,
                                                             updated_by="dbaware@db.com",
                                                             response_text=f"Failed to downloaded the inscope and outscope document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/download-test-steps")
def download_test_steps(request: DownloadTestStepsRequest) -> Response:
    try:
        start_time_dt = datetime.now(timezone.utc)
        action_service.construct_human_download_record(plan_number=request.planNumber,
                                                       activity_type="TEST_STEPS",
                                                       human_notes=f"Download document for plan_number = {request.planNumber}",
                                                       updated_by="dbaware@db.com",
                                                       data=request.test_steps)
        pdf_bytes, headers = download_test_steps_pdf(
            plan_number=request.planNumber,
            test_steps=request.test_steps,
        )
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="TEST_STEPS",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=200,
                                                             updated_by="dbaware@db.com",
                                                             response_text=f"Succfully downloaded the Test steps document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        return Response(
            content=pdf_bytes, media_type="application/pdf", headers=headers
        )
    except ValueError as exc:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="TEST_STEPS",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=400,
                                                             updated_by="dbaware@db.com",
                                                             response_text=f"Failed to downloaded the Test steps document for planNumber = {request.planNumber}, ",
                                                             remarks="")
        logger.exception("Value Error for  plan_number=%s error=%s", request.planNumber, exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        end_time_dt = datetime.now(timezone.utc)
        action_service.construct_ai_download_response_record(plan_number=request.planNumber,
                                                             activity_type="TEST_STEPS",
                                                             start_time=start_time_dt,
                                                             end_time=end_time_dt,
                                                             response_code=500,
                                                             updated_by="dbaware@db.com",
                                                             response_text=f"Failed to downloaded the Test steps document for planNumber = {request.planNumber}",
                                                             remarks="")
        logger.exception(
            "Error generating test steps PDF planNumber=%s", request.planNumber
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/upload-discovery-walkthrough-questions")
async def upload_discovery_walkthrough_questions(
    planNumber: Annotated[str, Form(description="Plan number")],
    userDetails: Annotated[str, Form(description="JSON-encoded user details")],
    files: Annotated[
        list[UploadFile], File(description="Discovery-walkthrough question documents")
    ],
) -> DiscoveryWalkthroughUploadResponse:
    if not planNumber.strip():
        raise HTTPException(status_code=400, detail="planNumber is required.")
    if not files:
        raise HTTPException(
            status_code=400,
            detail="At least one discovery-walkthrough question document is required.",
        )
    if not userDetails or not userDetails.strip():
        raise HTTPException(status_code=400, detail="userDetails is required.")

    try:
        parsed_user_details = UserRequest.model_validate_json(userDetails)
    except Exception as exc:
        raise HTTPException(
            status_code=400, detail=f"Invalid userDetails JSON: {str(exc)}"
        ) from exc

    try:
        result = await get_discovery_walkthrough_upload_service().process_upload(
            plan_number=planNumber,
            files=files,
            user_details=parsed_user_details,
        )
        return result
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception(
            "Failed to upload discovery walkthrough questions for planNumber=%s",
            planNumber,
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error uploading discovery walkthrough questions: {str(error)}",
        ) from error


@router.post("/confirm-discovery-walkthrough-upload")
async def confirm_discovery_walkthrough_upload(
    request: ConfirmDiscoveryWalkthroughUploadRequest,
) -> DiscoveryWalkthroughUploadResponse:
    if not request.planNumber.strip():
        raise HTTPException(status_code=400, detail="planNumber is required.")

    try:
        result = get_discovery_walkthrough_upload_service().confirm_pending_upload(
            plan_number=request.planNumber,
            validated_files=request.validated_files,
            confirmed=request.confirmed,
        )
        return result
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception(
            "Failed to confirm discovery walkthrough upload for planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error confirming discovery walkthrough upload: {str(error)}",
        ) from error


@router.post("/upload-extra-test-steps")
async def upload_test_steps(
    planNumber: Annotated[str, Form(description="Plan number")],
    userDetails: Annotated[str, Form(description="JSON-encoded user details")],
    files: Annotated[
        list[UploadFile], File(description="Test steps supporting documents")
    ],
) -> Response:
    if not planNumber.strip():
        raise HTTPException(status_code=400, detail="planNumber is required.")
    if not files:
        raise HTTPException(
            status_code=400, detail="At least one test steps document is required."
        )
    if not userDetails or not userDetails.strip():
        raise HTTPException(status_code=400, detail="userDetails is required.")

    try:
        parsed_user_details = UserRequest.model_validate_json(userDetails)
    except Exception as exc:
        raise HTTPException(
            status_code=400, detail=f"Invalid userDetails JSON: {str(exc)}"
        ) from exc

    try:
        result = await get_test_steps_upload_service().process_upload(
            plan_number=planNumber,
            files=files,
            user_details=parsed_user_details,
        )
        return result
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception("Failed to upload test steps for planNumber=%s", planNumber)
        raise HTTPException(
            status_code=500, detail=f"Error uploading test steps: {str(error)}"
        ) from error


@router.post("/confirm-extra-test-steps-upload")
async def confirm_test_steps_upload(
    request: ConfirmTestStepsUploadRequest,
) -> TestStepsUploadResponse:
    if not request.planNumber.strip():
        raise HTTPException(status_code=400, detail="planNumber is required.")

    try:
        result = get_test_steps_upload_service().confirm_pending_upload(
            plan_number=request.planNumber,
            validated_files=request.validated_files,
            confirmed=request.confirmed,
        )
        return result
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception(
            "Failed to confirm test-steps upload for planNumber=%s",
            request.planNumber,
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error confirming test-steps upload: {str(error)}",
        ) from error
