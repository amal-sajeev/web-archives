import os
import sys
import json
import site
from datetime import datetime, timezone
import uuid
import logging
from pathlib import Path
from agent_helper.agent_card import AgentCard
from config.config import Config
from typing import Any, Dict

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    stream=sys.stdout)

HUMAN_ACTOR_ID = "dbaware@db.com"
DEFAULT_ENTITY_TYPE = "SCOPING_PROCEDURE"
HUMAN_ACTOR="HUMAN"
AI_ACTOR="AI_AGENT"
AI_ACTOR_ID="scoping-procedure-agent"
def _resolve_action_service_config():
    import importlib.util

    current_file = Path(__file__).resolve()
    agent_config_dir = current_file.parent.parent / "config"

    candidate_dirs = []
    try:
        sp_roots = site.getsitepackages() if hasattr(site, "getsitepackages") else []
        if hasattr(site, "getusersitepackages"):
            sp_roots.append(site.getusersitepackages())
        for sp in sp_roots:
            candidate = Path(sp) / "config"
            if candidate.is_dir() and (candidate / "app.yml").exists():
                candidate_dirs.append(candidate)
    except Exception:
        pass

    for entry in sys.path:
        candidate = Path(entry) / "config"
        if candidate.is_dir() and (candidate / "app.yml").exists() and candidate not in candidate_dirs:
            candidate_dirs.append(candidate)

    if not candidate_dirs:
        return

    app_config_dirs = []
    if agent_config_dir.is_dir() and agent_config_dir not in candidate_dirs:
        app_config_dirs.append(agent_config_dir)

    for entry in sys.path:
        candidate = Path(entry) / "config"
        if candidate.is_dir() and candidate not in candidate_dirs and candidate not in app_config_dirs:
            app_config_dirs.append(candidate)

    search_locs = [str(d) for d in candidate_dirs]
    for d in app_config_dirs:
        if str(d) not in search_locs:
            search_locs.append(str(d))

    sp_config_dir = candidate_dirs[0]
    sp_init = sp_config_dir / "__init__.py"
    current_config = sys.modules.get("config")

    if not current_config or getattr(current_config, "__file__", None) != str(sp_init):
        spec = importlib.util.spec_from_file_location(
            "config",
            str(sp_init) if sp_init.exists() else None,
            submodule_search_locations=search_locs,
        )
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            sys.modules["config"] = mod
            spec.loader.exec_module(mod)
        elif spec:
            mod = importlib.util.module_from_spec(spec)
            sys.modules["config"] = mod

    mod = sys.modules.get("config")
    if mod and hasattr(mod, "__path__"):
        paths = list(mod.__path__)
        for d_str in search_locs:
            if d_str not in paths:
                paths.append(d_str)
        mod.__path__ = paths
    if mod and hasattr(mod, "__spec__") and mod.__spec__ and hasattr(mod.__spec__, "submodule_search_locations"):
        spec_paths = list(mod.__spec__.submodule_search_locations or [])
        for d_str in search_locs:
            if d_str not in spec_paths:
                spec_paths.append(d_str)
        mod.__spec__.submodule_search_locations = spec_paths

_resolve_action_service_config()



logger = logging.getLogger(__name__)

try:
    from action_client import ActionServiceClt
    action_clt = ActionServiceClt()
except Exception as exc:
    if os.getenv("FAIL_ON_ACTION_CLIENT_ERROR", "").lower() in ("true", "1", "yes"):
        logger.critical("Fatal: ActionServiceClt initialization failed in strict mode: %s", exc)
        raise
    logger.warning("Failed to initialize ActionServiceClt (fallback to pass-through): %s", exc)

    class _FallbackActionClient:
        def persist_action(self, func):
            from functools import wraps
            @wraps(func)
            def wrapper(*args, **kwargs):
                logger.warning(
                    "ActionServiceClt is in fallback mode; skipping action persistence for %s",
                    getattr(func, "__name__", str(func))
                )
                return func(*args, **kwargs)
            return wrapper

    action_clt = _FallbackActionClient()




@action_clt.persist_action
def call_to_action_service(json_data):
    logger.info(f'********* in call_to_action_service json data = {json_data}')
    return json_data
def construct_cta_action_record(plan_number: str,
                                action_type: str,
                                actor_type: str,
                                actor_id: str,
                                activity_type : str,
                                payload: Dict[str,str]):
    logger.info(f"inside construct_cta_action_record plan -idplan_number = {plan_number}, action_type = {action_type}, "
                f" actor_type = {actor_type}, actor_id= {actor_id} ")
    agent_card = AgentCard.get_agent_card(plan_number=plan_number, activity_type=activity_type)
    logger.info(f"inside construct_cta_action_record plan agent-card = {agent_card}")

    now_utc = datetime.now(timezone.utc)
    create_ts = now_utc.isoformat()


    json_data = {
        "CTA_ACTION": {
            "action_id": None,
            "entity_id": agent_card.get('ENTITY_ID', str(uuid.uuid5(uuid.NAMESPACE_DNS, plan_number))),
            "entity_type": agent_card.get('ENTITY_TYPE', "DEFAULT_ENTITY_TYPE"),
            "create_ts": create_ts,
            "insert_ts": None,
            "actor_type": actor_type,
            "actor_id": actor_id,
            "action_type": action_type,
            "parent_entity_type": agent_card.get("PARENT_ENTITY_TYPE", "SCOPING"),
            "parent_entity_id": agent_card.get("PARENT_ENTITY_ID", plan_number),
            "activity_type": activity_type or agent_card.get("ACTIVITY_TYPE", ""),
            "payload": payload
        }
    }
    logger.info(f"ACTION_TYPE={action_type}")
    return json_data


def construct_human_actor_generate_meeting_notes_record(plan_number, activity_type, query, user):
    """Logs the human instruction payload prior to executing LLM analytical tasks."""
    logger.info(f"Inside construct_human_actor_generate_meeting_notes_record "
                 f" plan_number = {plan_number}, activity_type = {activity_type}, query={query}, user={user}")

    payload = {
        "Action_Type": "GENERATE_MEETING_NOTES_CONSOLIDATION",
        "Human_Notes": query,
        "Remarks": "",
        "User": user
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='GENERATE_MEETING_NOTES_CONSOLIDATION',
                                            actor_type=HUMAN_ACTOR,
                                            actor_id=user,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)


def construct_ai_actor_response_meeting_notes_record(plan_number,
                                       activity_type,
                                       response_code,
                                       total_input_tokens=0,
                                       total_output_tokens=0,
                                       final_answer="",
                                       start_time=None,
                                       end_time=None,
                                       score=0,
                                       reasoning="",
                                       env_config=None,
                                       prompt_version="1.0",
                                       ):
    logger.info(f"construct_ai_actor_response_meeting_notes_record"
                f" plan_number = {plan_number}, activity_type = {activity_type}, "
                f"response_code={response_code} total_input_tokens={total_input_tokens}, total_output_tokens={total_output_tokens},"
                f" final_answer = {final_answer}, start_time={start_time}, end_time = {end_time},"
                f" score={score}, reasoing={reasoning} env_config = {env_config}, prompt_version= {prompt_version} ")

    model_name = os.getenv("GCP_MODEL_NAME") or os.getenv("model_name") or "gemini-2.5-pro"
    top_k = os.getenv("MODEL_TOP_K", "40")
    top_p = os.getenv("MODEL_TOP_P", "0.9")
    temperature = os.getenv("MODEL_TEMPERATURE", "0.0")
    if env_config:
        model_name = env_config.MODEL_NAME
        config_param = env_config.GENERATION_CONFIG
        temperature = config_param.get('temperature', "0.0")
        top_k = config_param.get('top_k', "40")
        top_p = config_param.get('top_p', "0.9")
    model_version = model_name.split('-', 1)[1] if '-' in model_name else "2.5"

    payload = {

        'Agent_Name': AI_ACTOR_ID,
        'Action_Type': 'RESPONSE_MEETING_NOTES_CONSOLIDATION',
        'AI_Rationale': "",
        'AI_Model_Name': model_name,
        'AI_Model_Version': model_version,
        'Prompt_Version': prompt_version,
        'Response_Code': response_code,
        'Response_Text': final_answer,
        'Token_Input_Count': total_input_tokens,
        'Token_Output_Count': total_output_tokens,
        'AI_Confidence_Score': score,
        'Execution_Start_Time': start_time.isoformat(),
        'Execution_End_Time': end_time.isoformat(),
        'AI_Model_Config_Setting': {
            'model_top_k': top_k,
            'model_top_p': top_p,
            'model_temperature': temperature
        },
        'Remarks': '',
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='RESPONSE_MEETING_NOTES_CONSOLIDATION',
                                            actor_type=AI_ACTOR,
                                            actor_id=AI_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)

def construct_human_actor_get_document_meeting_notes_record(plan_number, activity_type, user, user_remarks):
    """Logs the human instruction to get the document."""
    logger.info(f"Inside construct_human_actor_get_document_record "
                 f" plan_number = {plan_number}, activity_type = {activity_type}, userr={user}, user_remarks={user_remarks}")

    payload = {
        "Action_Type": "GET_MEETING_NOTES_CONSOLIDATION",
        "Human_Notes": f"Get document from storage for plan number = {plan_number}",
        "Remarks": "",
        "User": user,
        "User_Remarks": user_remarks
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='GET_MEETING_NOTES_CONSOLIDATION',
                                            actor_type=HUMAN_ACTOR,
                                            actor_id=HUMAN_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)
def construct_ai_actor_get_document_response_meeting_notes_record(plan_number, activity_type, user, user_remarks, remarks, start_time, end_time, response_code):
    """Logs the human instruction to get the document."""
    logger.info(f"Inside construct_ai_actor_get_document_response_record "
                 f" plan_number = {plan_number}, activity_type = {activity_type}, "
                f"user = {user}, user_remarks = {user_remarks}, remarks = {remarks}, "
                f"start_time={start_time} , end_time={end_time}, response_code={response_code}")

    payload = {
        "Action_Type": "GET_MEETING_NOTES_CONSOLIDATION_RESPONSE",
        "Remarks": "",
        "User": user,
        "User_Remarks": user_remarks,
        "Execution_Start_Time": start_time.isoformat(),
        "Execution_End_Time": end_time.isoformat(),
        "Response_Code": response_code,
        "Response_Text": remarks,

    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='GET_MEETING_NOTES_CONSOLIDATION_RESPONSE',
                                            actor_type=AI_ACTOR,
                                            actor_id=HUMAN_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)


#------------------------------------------------------------------------

def construct_human_actor_generate_record(plan_number, activity_type, query, user):
    """Logs the human instruction payload prior to executing LLM analytical tasks."""
    logger.info(f"Inside construct_human_actor_generate_record "
                 f" plan_number = {plan_number}, activity_type = {activity_type}, query={query}, user={user}")

    payload = {
        "Action_Type": "GENERATE",
        "Human_Notes": query,
        "Remarks": "",
        "User": user
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='GENERATE',
                                            actor_type=HUMAN_ACTOR,
                                            actor_id=user,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)



def construct_ai_actor_response_record(plan_number,
                              activity_type,
                              response_code,
                              total_input_tokens=0,
                              total_output_tokens=0,
                              final_answer="",
                              start_time=None,
                              end_time=None,
                              score=0,
                              reasoning="",
                              env_config=None,
                              prompt_version="1.0",
                              ):
    logger.info(f"construct_ai_actor_response_record"
                f" plan_number = {plan_number}, activity_type = {activity_type}, "
                f"response_code={response_code} total_input_tokens={total_input_tokens}, total_output_tokens={total_output_tokens},"
                f" final_answer = {final_answer}, start_time={start_time}, end_time = {end_time},"
                f" score={score}, reasoing={reasoning} env_config = {env_config}, prompt_version= {prompt_version} ")
                                  
    model_name = os.getenv("GCP_MODEL_NAME") or os.getenv("model_name") or "gemini-3.5-flash-europe-west3"
    top_k = os.getenv("MODEL_TOP_K", "40")
    top_p = os.getenv("MODEL_TOP_P", "0.9")
    temperature = os.getenv("MODEL_TEMPERATURE", "0.0")
    if env_config:
        model_name = env_config.MODEL_NAME
        config_param = env_config.GENERATION_CONFIG
        temperature = config_param.get('temperature', "0.0")
        top_k = config_param.get('top_k', "40")
        top_p = config_param.get('top_p', "0.9")
    model_version = model_name.split('-', 1)[1] if '-' in model_name else "2.5"

    payload = {

        'Agent_Name': AI_ACTOR_ID,
        'Action_Type': 'RESPONSE',
        'AI_Rationale': "",
        'AI_Model_Name': model_name,
        'AI_Model_Version': model_version,
        'Prompt_Version': prompt_version,
        'Response_Code': response_code,
        'Response_Text': final_answer,
        'Token_Input_Count': total_input_tokens,
        'Token_Output_Count': total_output_tokens,
        'AI_Confidence_Score': score,
        'Execution_Start_Time': start_time.isoformat(),
        'Execution_End_Time': end_time.isoformat(),
        'AI_Model_Config_Setting': {
            'model_top_k': top_k,
            'model_top_p': top_p,
            'model_temperature': temperature
        },
        'Remarks': '',
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='RESPONSE',
                                            actor_type=AI_ACTOR,
                                            actor_id=AI_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)


def construct_human_actor_get_document_record(plan_number, activity_type, user, user_remarks):
    """Logs the human instruction to get the document."""
    logger.info(f"Inside construct_human_actor_get_document_record "
                 f" plan_number = {plan_number}, activity_type = {activity_type}, userr={user}, user_remarks={user_remarks}")

    payload = {
        "Action_Type": "GET_DOCUMENT",
        "Human_Notes": f"Get document from storage for plan number = {plan_number}",
        "Remarks": "",
        "User": user,
        "User_Remarks": user_remarks
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='GET_DOCUMENT',
                                            actor_type=HUMAN_ACTOR,
                                            actor_id=HUMAN_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)
def construct_ai_actor_get_document_response_record(plan_number, activity_type, user, user_remarks, remarks, start_time, end_time, response_code):
    """Logs the human instruction to get the document."""
    logger.info(f"Inside construct_ai_actor_get_document_response_record "
                 f" plan_number = {plan_number}, activity_type = {activity_type}, "
                f"user = {user}, user_remarks = {user_remarks}, remarks = {remarks}, "
                f"start_time={start_time} , end_time={end_time}, response_code={response_code}")

    payload = {
        "Action_Type": "GET_DOCUMENT_RESPONSE",
        "Remarks": "",
        "User": user,
        "User_Remarks": user_remarks,
        "Execution_Start_Time": start_time.isoformat(),
        "Execution_End_Time": end_time.isoformat(),
        "Response_Code": response_code,
        "Response_Text": remarks,

    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type='GET_DOCUMENT_RESPONSE',
                                            actor_type=AI_ACTOR,
                                            actor_id=HUMAN_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)



def construct_human_update_record(plan_number, activity_type, human_notes,  updated_by, updated_section):
    logger.info(f" inside construct_human_update_record plan_number = {plan_number},"
                f" activity_type={activity_type},human_notes={human_notes}, updated_by={updated_by}, updated_section= {updated_section}, human_notes = {human_notes}")

    payload = {
        "Action_Type": "PERSIST_HUMAN_EDITED_DOC",
        "Human_Notes": human_notes,
        "Remarks": "",
        "Updated_By": updated_by,
        "updated_sections": updated_section
    }

    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type="PERSIST_HUMAN_EDITED_DOC",
                                            actor_type=HUMAN_ACTOR,
                                            actor_id=updated_by,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)

def construct_ai_update_response_record(plan_number, activity_type, start_time, end_time, response_code, updated_by="", response_text="",  remarks=""):
    logger.info(f" inside construct_ai_update_response_record plan_number = {plan_number},"
                f" activity_type={activity_type}, updated_by={updated_by}, start_time={start_time}, end_time = {end_time},"
                f"response_code = {response_code}, remarks= {remarks}, response_text = {response_text}")


    payload = {
        "Action_type": "PERSIST_HUMAN_EDITED_DOC_RESPONSE",
        "Execution_Start_Time": start_time.isoformat(),
        "Execution_End_Time": end_time.isoformat(),
        "Response_Code": response_code,
        "Response_Text": response_text,
        "Updated_By": updated_by,
        "Remarks": remarks,
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type="PERSIST_HUMAN_EDITED_DOC_RESPONSE",
                                            actor_type=AI_ACTOR,
                                            actor_id=AI_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)


def construct_human_download_record(plan_number, activity_type, human_notes,  updated_by, data):
    logger.info(f" inside construct_human_download_record plan_number = {plan_number},"
                f" activity_type={activity_type}, updated_by={updated_by}, data= {data}, human_notes = {human_notes}")

    payload = {
        "Action_Type": "DOWNLOAD",
        "Human_Notes": human_notes,
        "Remarks": "",
        "Downloaded_By": updated_by,
        "Data": data
    }

    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type="DOWNLOAD",
                                            actor_type=HUMAN_ACTOR,
                                            actor_id=updated_by,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)

def construct_ai_download_response_record(plan_number, activity_type, start_time, end_time, response_code, updated_by="", response_text="",  remarks=""):
    logger.info(f" inside construct_ai_download_response_record plan_number = {plan_number},"
                f" activity_type={activity_type}, updated_by={updated_by}, start_time={start_time}, end_time = {end_time},"
                f"response_code = {response_code}, remarks= {remarks}, response_text = {response_text}")

    payload = {
        "Action_type": "DOWNLOAD_RESPONSE",
        "Execution_Start_Time": start_time.isoformat(),
        "Execution_End_Time": end_time.isoformat(),
        "Response_Code": response_code,
        "Response_Text": response_text,
        "Updated_By": updated_by,
        "Remarks": remarks,
    }
    json_data = construct_cta_action_record(plan_number=plan_number,
                                            action_type="DOWNLOAD_RESPONSE",
                                            actor_type=AI_ACTOR,
                                            actor_id=AI_ACTOR_ID,
                                            activity_type=activity_type,
                                            payload=payload)

    call_to_action_service(json_data)



def _init_agent_card(activity_type: str, entity_type: str, plan_number: str, query: str, request_obj: object | None) -> dict:
    session_id = (
        getattr(request_obj, "entity_id", None)
        or getattr(request_obj, "correlation_id", None)
        or str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{plan_number}:{entity_type}"))
    )
    agent_card = build_agent_card(
        activity_type=activity_type,
        query=query,
        plan_item_number=plan_number,
        correlation_id=session_id,
    )
    agent_card.update({
        "ENTITY_ID": session_id,
        "ENTITY_TYPE": entity_type,
        "PARENT_ENTITY_TYPE": "scoping",
        "PARENT_ENTITY_ID": plan_number,
        "CORRELATION_ID": session_id,
        "ACTIVITY_TYPE": activity_type,
    })
    return agent_card


