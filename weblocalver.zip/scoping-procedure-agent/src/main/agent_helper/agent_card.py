import os
import uuid
import logging
from datetime import datetime
from typing import Any, Dict

logger = logging.getLogger(__name__)

def _resolve_actor_id() -> str:
    return os.getenv("ACTOR_ID") or "dbaware@db.com"

def _resolve_environment() -> str:
    return os.getenv("ENVIRONMENT") or os.getenv("ENV") or "dev"

def _resolve_service_version() -> str:
    return os.getenv("SERVICE_VERSION") or "1.0.0"

def build_agent_card(
    activity_type: str,
    query: str,
    plan_item_number: str | None = None,
    activity_id: str = "scoping-procedure",
    entity_id: str | None = None,
    entity_type: str | None = None,
    action_type: str = "RESPONSE",
    actor_type: str = "AI_AGENT",
    actor_id: str | None = None,
    parent_entity_type: str | None = None,
    parent_entity_id: str | None = None,
    status: str = "SUCCESS",
    correlation_id: str | None = None,
    duration_ms: int | None = None,
    error_message: str | None = None,
    metadata: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    resolved_actor_id = actor_id or _resolve_actor_id()
    resolved_parent_entity_type = parent_entity_type or "scoping"
    resolved_parent_entity_id = parent_entity_id or (str(plan_item_number) if plan_item_number else "scoping-service")
    resolved_correlation_id = correlation_id or str(uuid.uuid4())
    resolved_entity_id = entity_id or resolved_correlation_id
    resolved_entity_type = entity_type or activity_type
    timestamp = datetime.utcnow().isoformat() + "Z"
    environment = _resolve_environment()
    service_version = _resolve_service_version()

    agent_card = {
        "ACTOR_ID": resolved_actor_id,
        "ACTOR_TYPE": actor_type,
        "ACTION_TYPE": action_type,
        "ACTIVITY_ID": activity_id,
        "ACTIVITY_TYPE": activity_type,
        "ENTITY_ID": resolved_entity_id,
        "ENTITY_TYPE": resolved_entity_type,
        "PARENT_ENTITY_TYPE": resolved_parent_entity_type,
        "PARENT_ENTITY_ID": resolved_parent_entity_id,
        "CORRELATION_ID": resolved_correlation_id,
        "QUERY": query,
        "STATUS": status,
        "TIMESTAMP": timestamp,
        "ENVIRONMENT": environment,
        "SERVICE_VERSION": service_version,
    }

    if duration_ms is not None:
        agent_card["DURATION_MS"] = duration_ms
    if error_message:
        agent_card["ERROR_MESSAGE"] = error_message
    if metadata:
        agent_card["METADATA"] = metadata

    logger.info(
        "[BUILD_AGENT_CARD] Generated card: ENTITY_ID=%s, CORRELATION_ID=%s, ACTIVITY_TYPE=%s",
        resolved_entity_id, resolved_correlation_id, activity_type
    )

    return agent_card