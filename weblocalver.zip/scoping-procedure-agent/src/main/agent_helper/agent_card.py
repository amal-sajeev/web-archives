
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict

logger = logging.getLogger(__name__)


DEFAULT_PARENT_ENTITY_TYPE = "SCOPING"

DEFAULT_ENTITY_TYPE = "SCOPING_PROCEDURE"



class AgentCard:
    cache: dict() = {}
    def __init__(self):
        pass

    @classmethod
    def build_agent_card(cls,
                         activity_type: str,
                         plan_item_number: str,
                         entity_id: str | None = None,
                         entity_type: str = DEFAULT_ENTITY_TYPE,
                         action_type: str = "GENERATE",
                         actor_type: str = "AI_AGENT",
                         actor_id: str | None = None,
                         parent_entity_type: str | None = None,
                         parent_entity_id: str | None = None,
                         ) -> Dict[str, Any]:

        plan_item_number = plan_item_number.strip()
        agent_card = cls.cache.get(plan_item_number)

        if not agent_card:
            agent_card1: dict[str, Any] = {
                "ACTOR_ID": actor_id,
                "ENTITY_ID": str(uuid.uuid5(uuid.NAMESPACE_DNS, plan_item_number)),
                "ENTITY_TYPE": entity_type or DEFAULT_ENTITY_TYPE,
                "PARENT_ENTITY_TYPE": parent_entity_type or DEFAULT_PARENT_ENTITY_TYPE,
                "PARENT_ENTITY_ID": parent_entity_id or plan_item_number ,
                "ACTIVITY_TYPE": activity_type,
                "ACTION_TYPE": action_type,
                "ACTOR_TYPE": actor_type
                }

            key = plan_item_number.strip() +  activity_type.strip()
            cls.cache[key] = agent_card1
            agent_card = agent_card1
        logger.info("Generated agent card: %s", agent_card)
        return agent_card


    @classmethod
    def utc_timestamp(cls) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    @classmethod
    def resolve_entity_id(cls, plan_item_number: str | None) -> str:
        if plan_item_number:
            return str(uuid.uuid5(PLAN_ENTITY_UUID_NAMESPACE, str(plan_item_number)))
        return str(uuid.uuid4())

    @classmethod
    def get_agent_card(cls, plan_number: str, activity_type: str) -> dict[str, Any]:
        key =  plan_number.strip() + " " + activity_type.strip()
        agent_card =  cls.cache.get(key, None)
        if agent_card is None:
           agent_card = AgentCard.build_agent_card( activity_type=activity_type,
                                                    plan_item_number=plan_number,
                                                    entity_type="SCOPING_PROCEDURE",
                                                    parent_entity_type="SCOPING",
                                                    parent_entity_id=plan_number,
                                                    actor_id="dbaware@db.com",
                                                    actor_type="HUMAN",)
        return agent_card