import logging

from config.prompts import MEETING_NOTES_TEMPLATE
from service.vertex_service import initialize_gemini_model
from typing import Any, Dict


logger = logging.getLogger(__name__)

def _extract_usage_tokens(response_obj) -> dict[str, int]:
    usage = None

    if response_obj is None:
        return {"input_tokens": 0, "output_tokens": 0}

    usage = getattr(response_obj, "usage_metadata", None)
    if usage is None:
        nested_response = getattr(response_obj, "response", None)
        if nested_response is not None:
            usage = getattr(nested_response, "usage_metadata", None)

    if usage is None:
        response_metadata = getattr(response_obj, "response_metadata", None) or {}
        if isinstance(response_metadata, dict):
            usage = response_metadata.get("usage_metadata")

    if not usage:
        return {"input_tokens": 0, "output_tokens": 0}

    if isinstance(usage, dict):
        input_tokens = int(usage.get("prompt_token_count") or usage.get("input_tokens") or 0)
        output_tokens = int(usage.get("candidates_token_count") or usage.get("output_tokens") or 0)
        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        }

    input_tokens = int(getattr(usage, "prompt_token_count", 0) or getattr(usage, "input_tokens", 0) or 0)
    output_tokens = int(getattr(usage, "candidates_token_count", 0) or getattr(usage, "output_tokens", 0) or 0)
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
    }
async def normalize(plan_item_number: str, source_notes: list[str]) -> tuple[str,Dict[str, int]]:
    merged_notes = "\n\n".join(note for note in source_notes if note) or "No readable notes supplied."
    prompt = MEETING_NOTES_TEMPLATE.format(
        plan_item_number=plan_item_number,
        source_notes=merged_notes,
        normalized_notes="Generate the normalized meeting notes from the source notes.",
    )
    try:
        response = await initialize_gemini_model().ainvoke(prompt)
        usage_metadata = _extract_usage_tokens(response)
        logger.info(f"**************** in normalize usage_metadata = {usage_metadata}")
        return response.content, usage_metadata
    except Exception as error:
        logger.exception("Failed to normalize meeting notes plan_item_number=%s", plan_item_number)
        raise ValueError("Unable to normalize meeting notes.") from error