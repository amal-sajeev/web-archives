import logging

from config.prompts import MEETING_NOTES_TEMPLATE
from service.vertex_service import initialize_gemini_model


logger = logging.getLogger(__name__)


async def normalize(plan_item_number: str, source_notes: list[str]) -> str:
    merged_notes = "\n\n".join(note for note in source_notes if note) or "No readable notes supplied."
    prompt = MEETING_NOTES_TEMPLATE.format(
        plan_item_number=plan_item_number,
        source_notes=merged_notes,
        normalized_notes="Generate the normalized meeting notes from the source notes.",
    )
    try:
        response = await initialize_gemini_model().ainvoke(prompt)
        return response.content
    except Exception as error:
        logger.exception("Failed to normalize meeting notes plan_item_number=%s", plan_item_number)
        raise ValueError("Unable to normalize meeting notes.") from error