"""
GCS Bucket storage utilities for downloading and managing review data.
"""
import json
from typing import Dict, Any, Optional
from google.api_core.exceptions import NotFound
from google.cloud import storage
from pathlib import Path

from config.config import Config


class StorageManager:
    """Manages interactions with GCS bucket for review data."""

    def __init__(self, project_name: str, bucket_name: str):
        """
        Initialize StorageManager with GCS credentials.

        Args:
            project_name: GCP project name
            bucket_name: GCS bucket name
        """
        self.project_name = project_name
        self.bucket_name = bucket_name
        self.client = storage.Client(project=project_name)
        self.bucket = self.client.bucket(bucket_name)

    def write_blob_bytes(
        self,
        object_name: str,
        content: bytes,
        content_type: Optional[str],
    ) -> str:
        """Upload byte content to a blob and return its GCS URI."""
        try:
            blob = self.bucket.blob(object_name)
            blob.upload_from_string(content, content_type=content_type)
            return f"gs://{self.bucket_name}/{object_name}"
        except Exception as e:
            raise RuntimeError(f"Error uploading blob to {object_name}: {str(e)}") from e

    def write_blob_json(self, object_name: str, content: Dict[str, Any]) -> str:
        """Serialize JSON content, upload it to a blob, and return its GCS URI."""
        try:
            payload = json.dumps(content, ensure_ascii=False, indent=2, default=str)
            return self.write_blob_bytes(object_name, payload.encode("utf-8"), "application/json")
        except Exception as e:
            raise RuntimeError(f"Error uploading JSON to {object_name}: {str(e)}") from e


    def download_json(self, blob_path: str) -> Optional[Dict[str, Any]]:
        """
        Download a JSON file from GCS bucket and return parsed content.

        Args:
            blob_path: Path to the blob in the bucket (e.g., 'dbaware_review_123/inbound-data/dbaware/file.json')

        Returns:
            Parsed JSON content as dictionary, or None if file not found
        """
        try:
            blob = self.bucket.blob(blob_path)
            try:
                content = blob.download_as_text()
            except NotFound:
                return None
            return json.loads(content)
        except Exception as e:
            print(f"Error downloading {blob_path}: {str(e)}")
            return None

    def download_json_to_file(self, blob_path: str, local_path: str) -> bool:
        """
        Download a JSON file from GCS bucket to local storage.

        Args:
            blob_path: Path to the blob in the bucket
            local_path: Local file path to save the file

        Returns:
            True if successful, False otherwise
        """
        try:
            blob = self.bucket.blob(blob_path)
            if not blob.exists():
                print(f"File not found in bucket: {blob_path}")
                return False

            # Create parent directory if needed
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)
            blob.download_to_filename(local_path)
            return True
        except Exception as e:
            print(f"Error downloading {blob_path} to {local_path}: {str(e)}")
            return False

    def blob_exists(self, blob_path: str) -> bool:
        """
        Check if a blob exists in the bucket.

        Args:
            blob_path: Path to the blob in the bucket

        Returns:
            True if blob exists, False otherwise
        """
        try:
            blob = self.bucket.blob(blob_path)
            return blob.exists()
        except Exception as e:
            print(f"Error checking blob existence for {blob_path}: {str(e)}")
            return False

    def list_blobs_in_folder(self, folder_path: str) -> list[str]:
        """
        List all blobs in a specific folder path.

        Args:
            folder_path: Path to the folder in the bucket

        Returns:
            List of blob names in the folder
        """
        try:
            blobs = self.client.list_blobs(self.bucket_name, prefix=folder_path)
            return [blob.name for blob in blobs]
        except Exception as e:
            print(f"Error listing blobs in {folder_path}: {str(e)}")
            return []

    def upload_json(self, blob_path: str, data: Dict[str, Any]) -> str:
        """
        Upload JSON content to GCS bucket.

        Args:
            blob_path: Path to the blob in bucket.
            data: JSON-serializable dictionary.

        Returns:
            GCS URI of uploaded file.
        """
        try:
            blob = self.bucket.blob(blob_path)
            payload = json.dumps(data, ensure_ascii=False, indent=2, default=str)
            blob.upload_from_string(payload, content_type="application/json")
            return f"gs://{self.bucket_name}/{blob_path}"
        except Exception as e:
            raise RuntimeError(f"Error uploading JSON to {blob_path}: {str(e)}") from e
