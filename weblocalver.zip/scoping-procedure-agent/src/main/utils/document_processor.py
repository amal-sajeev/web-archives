from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape

from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer


def _extract_docx_text(content: bytes) -> str:
    """Extract paragraph and table text from a DOCX document using python-docx."""
    try:
        document = Document(BytesIO(content))
    except Exception:
        return ""

    sections = [paragraph.text.strip() for paragraph in document.paragraphs if paragraph.text.strip()]

    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
            if cells:
                sections.append(" | ".join(cells))

    return "\n".join(sections)


def extract_text(filename: str, content: bytes) -> str:
    """Extract readable text from supported meeting-note document formats."""
    if filename.lower().endswith((".txt", ".md", ".csv")):
        return content.decode("utf-8", errors="replace").strip()

    if filename.lower().endswith(".docx"):
        text = _extract_docx_text(content)
        if text:
            return text

    return f"[{filename}: stored as source material; text extraction is not configured.]"


def convert_to_pdf(filename: str, content: bytes) -> tuple[str, bytes]:
    if filename.lower().endswith(".pdf"):
        return filename, content

    pdf_buffer = BytesIO()
    document = SimpleDocTemplate(pdf_buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    text = extract_text(filename, content)
    paragraphs = [
        Paragraph(escape(Path(filename).name), styles["Title"]),
        Spacer(1, 12),
    ]
    paragraphs.extend(
        Paragraph(escape(line) or " ", styles["BodyText"])
        for line in text.splitlines()
    )
    document.build(paragraphs)
    return f"{Path(filename).stem}.pdf", pdf_buffer.getvalue()