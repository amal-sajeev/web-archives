from config.config import Config


def blob_metadata(uris: list[str]) -> dict:
    return {"files": [{"filename": uri.rsplit("/", 1)[-1], "filepath": uri} for uri in uris]}


def report_blob_metadata(plan_number: str, folder: str, filenames: tuple[str, ...]) -> dict:
    bucket = Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME
    if not bucket:
        raise ValueError("Review bucket name is not configured.")
    review_folder = Config.REVIEW_FOLDER_PATTERN.format(plan_number=plan_number)
    return blob_metadata([
        f"gs://{bucket}/{review_folder}/{folder.strip('/')}/{filename}"
        for filename in filenames
    ])