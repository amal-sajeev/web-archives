import base64
import json
import logging
import re
from pathlib import Path

from fastapi import UploadFile

from config.config import Config
from config.prompts import DISCOVERY_WALKTHROUGH_QUESTION_BANK_GUARDRAIL_PROMPT
from model.request_model import UserRequest
from model.response_model import (
    DiscoveryWalkthroughQuestionBankValidation,
    DiscoveryWalkthroughUploadResponse,
    UploadedMeetingNote,
)
from service.vertex_service import initialize_gemini_model
from utils.document_processor import extract_text
from utils.storage_manager import StorageManager

logger = logging.getLogger(__name__)


class DiscoveryWalkthroughUploadService:
    """Stores uploaded discovery-walkthrough question documents in the review bucket."""

    def __init__(self):
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )
        self.llm = initialize_gemini_model()

    @staticmethod
    def _has_question_bank_reference(text: str) -> bool:
        normalized = "\n".join(
            line.strip() for line in text.splitlines() if line.strip()
        ).lower()
        if not normalized:
            return False

        markers = (
            "#sym:discovery_walkthrough_question_bank",
            "sym:discovery_walkthrough_question_bank",
            "discovery_walkthrough_question_bank",
        )
        return any(marker in normalized for marker in markers)

    @staticmethod
    def _has_actual_question_line(line: str) -> bool:
        cleaned = re.sub(r"^[\-\*\d\.\)\s]+", "", line).strip()
        if not cleaned:
            return False

        lower = cleaned.lower()
        if lower.endswith("?"):
            return True

        if re.match(
            r"^(q[0-9]+|question\s*[0-9]+|questionnaire\s*[0-9]+)\s*[-:]?\s*", lower
        ):
            return True

        question_starts = (
            "what ",
            "why ",
            "how ",
            "who ",
            "when ",
            "where ",
            "which ",
            "describe ",
            "identify ",
            "assess ",
            "review ",
            "confirm ",
            "verify ",
            "list ",
            "document ",
            "evaluate ",
            "determine ",
            "do ",
            "does ",
            "is ",
            "are ",
            "can ",
            "could ",
            "should ",
            "has ",
            "have ",
            "did ",
            "would ",
            "may ",
            "might ",
        )
        return any(lower.startswith(prefix) for prefix in question_starts)

    @staticmethod
    def _safe_name(value: str) -> str:
        return re.sub(r"[^A-Za-z0-9._-]", "_", value)

    @staticmethod
    def _normalize_extracted_text(text: str) -> str:
        cleaned = text.strip()
        if not cleaned:
            return ""
        return "\n".join(line.strip() for line in cleaned.splitlines() if line.strip())

    @staticmethod
    def _looks_like_question_bank_content(filename: str, text: str) -> bool:
        normalized = "\n".join(
            line.strip() for line in text.splitlines() if line.strip()
        )
        if not normalized:
            return False

        if DiscoveryWalkthroughUploadService._has_question_bank_reference(text):
            return True

        lines = [line.strip() for line in normalized.splitlines() if line.strip()]
        question_count = sum(
            1
            for line in lines
            if DiscoveryWalkthroughUploadService._has_actual_question_line(line)
        )
        return question_count >= 2

    @staticmethod
    def _is_explicit_question_bank_text(text: str) -> bool:
        return DiscoveryWalkthroughUploadService._has_question_bank_reference(text) or (
            DiscoveryWalkthroughUploadService._contains_explicit_question_content(text)
        )

    @staticmethod
    def _contains_explicit_question_content(text: str) -> bool:
        normalized = "\n".join(
            line.strip() for line in text.splitlines() if line.strip()
        )
        if not normalized:
            return False

        if DiscoveryWalkthroughUploadService._has_question_bank_reference(text):
            return True

        lines = [line.strip() for line in normalized.splitlines() if line.strip()]
        if not lines:
            return False

        question_lines = [
            line
            for line in lines
            if DiscoveryWalkthroughUploadService._has_actual_question_line(line)
        ]
        if not question_lines:
            return False

        if len(lines) == 1:
            return True

        question_ratio = len(question_lines) / len(lines)
        return question_ratio >= 0.5

    def _validate_question_bank_document(
        self,
        filename: str,
        content: bytes,
    ) -> DiscoveryWalkthroughQuestionBankValidation:
        extracted_text = self._normalize_extracted_text(extract_text(filename, content))
        if not extracted_text:
            return DiscoveryWalkthroughQuestionBankValidation(
                filename=filename,
                is_valid=False,
                reason="The document is empty, unreadable, or contains no usable question content.",
                document_type="not_question_bank",
            )

        if self._has_question_bank_reference(extracted_text):
            return DiscoveryWalkthroughQuestionBankValidation(
                filename=filename,
                is_valid=True,
                reason="The document contains the discovery-walkthrough reference and is accepted as a question-bank artifact.",
                document_type="question_bank",
            )

        if not self._contains_explicit_question_content(extracted_text):
            return DiscoveryWalkthroughQuestionBankValidation(
                filename=filename,
                is_valid=False,
                reason="The document does not contain explicit walkthrough questions or questionnaire-style prompts.",
                document_type="not_question_bank",
            )

        structured_model = self.llm.with_structured_output(
            DiscoveryWalkthroughQuestionBankValidation
        )
        prompt = (
            f"{DISCOVERY_WALKTHROUGH_QUESTION_BANK_GUARDRAIL_PROMPT}\n\n"
            f"Uploaded file name: {filename}\n\n"
            "Extracted text:\n"
            f"{extracted_text[:15000]}"
        )

        try:
            validation_result = structured_model.invoke(prompt)
        except Exception as exc:
            logger.warning(
                "DW question-bank guardrail validation failed for file %s: %s",
                filename,
                exc,
            )
            return DiscoveryWalkthroughQuestionBankValidation(
                filename=filename,
                is_valid=False,
                reason="The document could not be validated as a question-bank file because the guardrail check failed.",
                document_type="not_question_bank",
            )

        if isinstance(validation_result, DiscoveryWalkthroughQuestionBankValidation):
            validation = validation_result
        else:
            payload = (
                validation_result.model_dump()
                if hasattr(validation_result, "model_dump")
                else dict(validation_result)
            )
            payload.setdefault("filename", filename)
            validation = DiscoveryWalkthroughQuestionBankValidation.model_validate(
                payload
            )

        validation.filename = filename

        if validation.document_type == "not_question_bank":
            validation.is_valid = False
            validation.reason = (
                validation.reason
                or "The document is not a discovery-walkthrough question-bank artifact."
            )
            return validation

        if validation.document_type in {"question_bank", "generic_business_document"}:
            validation.is_valid = self._contains_explicit_question_content(
                extracted_text
            )
            if validation.is_valid:
                validation.document_type = "question_bank"
                validation.reason = "The document contains explicit walkthrough questions and is accepted as a question-bank artifact."
            else:
                validation.is_valid = False
                validation.reason = "The document does not contain explicit walkthrough questions or questionnaire-style prompts."
                validation.document_type = "not_question_bank"
            return validation

        return validation

    def confirm_pending_upload(
        self,
        plan_number: str,
        validated_files: list[dict[str, str]],
        confirmed: bool = False,
    ) -> DiscoveryWalkthroughUploadResponse:
        if not confirmed:
            raise ValueError(
                "User confirmation is required before uploading the validated question-bank documents."
            )

        review_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
            plan_number=self._safe_name(plan_number),
        )
        storage_prefix = f"{review_folder}/inbound-data/additional-context"

        documents: list[UploadedMeetingNote] = []
        for payload in validated_files:
            filename = payload.get("filename")
            encoded_content = payload.get("content")
            if not filename or encoded_content is None:
                raise ValueError(
                    "Each validated file record must include a filename and content."
                )
            safe_filename = self._safe_name(filename)
            content = base64.b64decode(encoded_content)
            blob_path = f"{storage_prefix}/{safe_filename}"
            gcs_uri = self.storage_manager.write_blob_bytes(
                blob_path,
                content,
                self._resolve_content_type(safe_filename),
            )
            documents.append(
                UploadedMeetingNote(
                    filename=safe_filename,
                    document_url=gcs_uri,
                    size_bytes=len(content),
                )
            )

        logger.info(
            "Confirmed and uploaded DW question-bank files for planNumber=%s file_count=%s storage_prefix=%s",
            plan_number,
            len(documents),
            storage_prefix,
        )

        return DiscoveryWalkthroughUploadResponse(
            planNumber=plan_number,
            uploaded_documents=documents,
            storage_prefix=storage_prefix,
            upload_completed=True,
            confirmation_required=False,
        )

    def load_question_bank(self, plan_number: str) -> dict:
        """Load uploaded DW question-bank documents as raw extracted text."""
        review_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
            plan_number=self._safe_name(plan_number),
        )
        folder = f"{review_folder}/inbound-data/additional-context"

        logger.info(
            "Loading DW uploaded question bank for planNumber=%s folder=%s",
            plan_number,
            folder,
        )

        blob_names = self.storage_manager.list_blobs_in_folder(folder)

        logger.info(
            "DW question bank blob count for planNumber=%s: %s",
            plan_number,
            len(blob_names),
        )
        if not blob_names:
            return {"question_documents": []}

        question_documents: list[dict[str, str]] = []
        seen_texts: set[str] = set()

        for blob_name in blob_names:
            try:
                logger.info("Reading DW uploaded blob from bucket: %s", blob_name)
                blob_content = self.storage_manager.download_blob_bytes(blob_name)
            except Exception as exc:
                logger.warning("Failed to read DW uploaded blob %s: %s", blob_name, exc)
                continue

            filename = Path(blob_name).name
            text = extract_text(filename, blob_content).strip()
            logger.info(
                "Extracted text length for DW uploaded file %s: %s", filename, len(text)
            )
            if not text:
                continue

            normalized_text = self._normalize_extracted_text(text)
            if not normalized_text:
                continue

            if normalized_text.lower() in seen_texts:
                continue
            seen_texts.add(normalized_text.lower())

            question_documents.append(
                {
                    "filename": filename,
                    "text": text,
                }
            )

        logger.info(
            "Loaded DW uploaded question documents for planNumber=%s: %s",
            plan_number,
            len(question_documents),
        )
        return {"question_documents": question_documents}

    async def process_upload(
        self,
        plan_number: str,
        files: list[UploadFile],
        user_details: UserRequest | None = None,
    ) -> DiscoveryWalkthroughUploadResponse:
        if not files:
            raise ValueError(
                "At least one discovery-walkthrough question document is required."
            )

        allowed_extensions = (".pdf", ".docx", ".txt")
        unsupported = [
            document.filename or "unnamed-document"
            for document in files
            if not (document.filename or "").lower().endswith(allowed_extensions)
        ]
        if unsupported:
            raise ValueError(
                f"Unsupported file type(s): {', '.join(unsupported)}. "
                "Only .pdf, .docx and .txt files are allowed."
            )

        validation_results: list[DiscoveryWalkthroughQuestionBankValidation] = []
        valid_files: list[tuple[str, bytes]] = []

        for document in files:
            original_filename = document.filename or "unnamed-document"
            content = await document.read()
            validation = self._validate_question_bank_document(
                original_filename, content
            )
            validation_results.append(validation)

            if validation.is_valid:
                valid_files.append((self._safe_name(original_filename), content))
                logger.info(
                    "Accepted DW uploaded document for planNumber=%s file=%s",
                    plan_number,
                    original_filename,
                )
            else:
                logger.warning(
                    "Rejected DW uploaded document during guardrail validation for planNumber=%s file=%s reason=%s",
                    plan_number,
                    original_filename,
                    validation.reason,
                )

        if not valid_files:
            logger.warning(
                "No valid DW question-bank files detected for planNumber=%s validation_results=%s",
                plan_number,
                validation_results,
            )
            return DiscoveryWalkthroughUploadResponse(
                planNumber=plan_number,
                uploaded_documents=[],
                storage_prefix=(
                    f"{Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(plan_number=self._safe_name(plan_number))}/"
                    "inbound-data/additional-context"
                ),
                validation_results=validation_results,
                upload_completed=False,
                confirmation_required=False,
            )

        logger.info(
            "Validated DW question-bank upload for planNumber=%s valid_file_count=%s",
            plan_number,
            len(valid_files),
        )

        return DiscoveryWalkthroughUploadResponse(
            planNumber=plan_number,
            uploaded_documents=[],
            storage_prefix=(
                f"{Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(plan_number=self._safe_name(plan_number))}/"
                "inbound-data/additional-context/discovery-walkthrough-questions"
            ),
            validation_results=validation_results,
            upload_completed=False,
            confirmation_required=True,
            validated_files=[
                {
                    "filename": filename,
                    "content": base64.b64encode(content).decode("utf-8"),
                }
                for filename, content in valid_files
            ],
        )

    @staticmethod
    def _resolve_content_type(filename: str) -> str:
        lower_name = filename.lower()
        if lower_name.endswith(".pdf"):
            return "application/pdf"
        if lower_name.endswith(".docx"):
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        if lower_name.endswith(".doc"):
            return "application/msword"
        if lower_name.endswith(".txt"):
            return "text/plain"
        return "application/octet-stream"
