import logging
import re

from model.request_model import MeetingNotesUploadRequest
from model.response_model import MeetingNotesSummaryResponse, UploadedMeetingNote
from utils.document_processor import convert_to_pdf, extract_text
from utils.meeting_notes_normalizer import normalize
from utils.storage_manager import StorageManager
from config.config import Config


logger = logging.getLogger(__name__)


class MeetingNotesService:
    """Process meeting-note uploads and persist normalized summaries."""

    def __init__(self):
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )

    @staticmethod
    def _safe_name(value: str) -> str:
        return re.sub(r"[^A-Za-z0-9._-]", "_", value)

    async def process_meeting_notes(
        self,
        request: MeetingNotesUploadRequest,
    ) -> MeetingNotesSummaryResponse:
        plan_item_key = self._safe_name(request.planNumber)

        review_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=plan_item_key,
        )
        preliminary_research_folder = (
            f"{review_folder}/{Config.PROCESSING_DATA_FOLDER}/{Config.PRELIMINARY_RESEARCH_FOLDER}"
        )
        feedback_folder = (
            f"{preliminary_research_folder}/{Config.USER_FEEDBACK_FOLDER}"
        )

        documents = []
        source_notes = []
        converted_files = []

        logger.info(
            "Processing meeting notes planNumber=%s file_count=%s",
            request.planNumber,
            len(request.files),
        )

        for document in request.files:
            filename = self._safe_name(document.filename or "unnamed-document")
            content = await document.read()
            logger.info("Processing file filename=%s size_bytes=%s", filename, len(content))
            pdf_filename, pdf_content = convert_to_pdf(filename, content)
            converted_files.append((pdf_filename, pdf_content))
            source_notes.append(extract_text(filename, content))

        logger.info("Normalizing meeting notes source_count=%s", len(source_notes))
        summary = await normalize(request.planNumber, source_notes)


        for pdf_filename, pdf_content in converted_files:
            object_uri = self.storage_manager.write_blob_bytes(
                f"{feedback_folder}/{pdf_filename}",
                pdf_content,
                "application/pdf",
            )
            documents.append(
                UploadedMeetingNote(
                    filename=pdf_filename,
                    document_url=object_uri,
                    size_bytes=len(pdf_content),
                )
            )

        normalized_summary_uri = self.storage_manager.write_blob_json(
            f"{preliminary_research_folder}/{Config.USER_FEEDBACK_SUMMARY_FILE}",
            {
                "planNumber": request.planNumber,
                "normalized_meeting_notes": summary,
            },
        )
        logger.info("Wrote normalized meeting notes uri=%s", normalized_summary_uri)
        return MeetingNotesSummaryResponse(
            planNumber=request.planNumber,
            uploaded_documents=documents,
            normalized_summary_uri=normalized_summary_uri,
        )

    def get_meeting_notes_summary(self, plan_number: str) -> dict:
        """Fetch persisted normalized meeting-notes summary content from storage."""
        plan_item_key = self._safe_name(plan_number)
        review_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(plan_number=plan_item_key)
        summary_blob_path = (
            f"{review_folder}/{Config.PROCESSING_DATA_FOLDER}/"
            f"{Config.PRELIMINARY_RESEARCH_FOLDER}/{Config.USER_FEEDBACK_SUMMARY_FILE}"
        )

        summary_data = self.storage_manager.download_json(summary_blob_path)
        if not summary_data:
            raise FileNotFoundError(f"Meeting notes summary file not found for planNumber={plan_number}")

        return summary_data