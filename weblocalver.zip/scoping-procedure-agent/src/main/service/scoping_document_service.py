"""Build and persist editable scoping-document drafts."""

from __future__ import annotations

import base64
import html
import json
import re
from collections.abc import Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from config.config import Config
from model.request_model import ScopingDocumentContent, ScopingDocumentRow
from utils.storage_manager import StorageManager
from reportlab.pdfbase.pdfmetrics import stringWidth

_PDF_FONT_SIZE = 8
# Letter landscape (279.4mm) minus 2 x 8mm page margins, in points.
_PDF_CONTENT_WIDTH_PT = (279.4 - 16) / 25.4 * 72
_PDF_CELL_PADDING_PT = 4
# Leave headroom so xhtml2pdf never re-wraps a pre-wrapped line.
_PDF_WRAP_SAFETY = 0.96
_MARKUP_PATTERN = re.compile(r"\*\*(.+?)\*\*|<u>(.+?)</u>")


def _markup_segments(text: str, bold: bool = False, underline: bool = False):
    position = 0
    for match in _MARKUP_PATTERN.finditer(text):
        if match.start() > position:
            yield text[position:match.start()], bold, underline
        if match.group(1) is not None:
            yield from _markup_segments(match.group(1), True, underline)
        else:
            yield from _markup_segments(match.group(2), bold, True)
        position = match.end()
    if position < len(text):
        yield text[position:], bold, underline


def _wrap_markup_line(raw_line: str, max_width_pt: float) -> list[str]:
    """Wrap one source line into HTML lines that each fit max_width_pt (bold/underline kept per line)."""
    stripped = raw_line.strip()
    indent = len(raw_line) - len(raw_line.lstrip(" "))
    if not stripped:
        return ["&nbsp;"]

    limit = max_width_pt * _PDF_WRAP_SAFETY
    lines: list[list[tuple[str, bool, bool]]] = [[]]
    width = indent * stringWidth(" ", "Helvetica", _PDF_FONT_SIZE)
    for segment, bold, underline in _markup_segments(stripped):
        font = "Helvetica-Bold" if bold else "Helvetica"
        for token in re.findall(r"\s+|\S+", segment):
            if token.isspace():
                if lines[-1]:
                    lines[-1].append((" ", bold, underline))
                    width += stringWidth(" ", font, _PDF_FONT_SIZE)
                continue
            token_width = stringWidth(token, font, _PDF_FONT_SIZE)
            if lines[-1] and width + token_width > limit:
                while lines[-1] and lines[-1][-1][0] == " ":
                    lines[-1].pop()
                lines.append([])
                width = 0
            lines[-1].append((token, bold, underline))
            width += token_width

    rendered = []
    for line_index, tokens in enumerate(lines):
        while tokens and tokens[-1][0] == " ":
            tokens.pop()
        parts: list[str] = []
        run_text, run_style = "", None
        for text, bold, underline in tokens + [("", None, None)]:
            style = (bold, underline)
            if style != run_style and run_text:
                chunk = html.escape(run_text)
                if run_style[0]:
                    chunk = f"<strong>{chunk}</strong>"
                if run_style[1]:
                    chunk = f"<u>{chunk}</u>"
                parts.append(chunk)
                run_text = ""
            run_text += text
            run_style = style
        prefix = "&nbsp;" * indent if line_index == 0 else ""
        rendered.append(prefix + "".join(parts))
    return rendered


class ScopingDocumentService:
    """Stores the document model and renders it through a fixed HTML template."""

    def __init__(self, storage_manager: StorageManager | None = None):
        self.storage_manager = storage_manager or StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )

    @staticmethod
    def _validate_plan_number(plan_number: str) -> str:
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,50}", plan_number):
            raise ValueError("planNumber contains unsupported characters.")
        return plan_number

    def _blob_path(self, plan_number: str) -> str:
        safe_plan_number = self._validate_plan_number(plan_number)
        folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(plan_number=safe_plan_number)
        scoping_folder = Config.SCOPING_FOLDER_PATH.strip("/")
        return f"{folder}/{scoping_folder}/scoping-document.json"

    def load_source_artifacts(self, plan_number: str) -> dict[str, Any]:
        """Read inscope, outscope, test-steps and plan-details JSONs directly from storage in parallel."""
        folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
            plan_number=self._validate_plan_number(plan_number)
        )
        procedure_folder = Config.PROCEDURE_PROCESSING_PATH.strip("/")
        paths = {
            "inscope": f"{folder}/{procedure_folder}/inscope.json",
            "outscope": f"{folder}/{procedure_folder}/outscope.json",
            "test_steps": f"{folder}/{procedure_folder}/test-steps.json",
            "plan_details": f"{folder}/inbound-data/dbaware/plan_details.json",
        }
        with ThreadPoolExecutor(max_workers=len(paths)) as executor:
            futures = {
                name: executor.submit(self.storage_manager.download_json, path)
                for name, path in paths.items()
            }
            artifacts = {name: future.result() for name, future in futures.items()}

        for name, data in artifacts.items():
            if not data:
                raise FileNotFoundError(
                    f"{name} file not found for planNumber={plan_number}"
                )
        return artifacts

    def get_saved_document(self, plan_number: str) -> ScopingDocumentContent | None:
        payload = self.storage_manager.download_json(self._blob_path(plan_number))
        if not payload:
            return None
        return ScopingDocumentContent.model_validate(payload.get("document", payload))

    def save_document(
        self, plan_number: str, document: ScopingDocumentContent
    ) -> str:
        existing = self.get_saved_document(plan_number)
        if existing is not None and self._row_keys(existing) != self._row_keys(document):
            raise ValueError("Row keys are locked and cannot be modified.")

        path = self._blob_path(plan_number)
        uri = self.storage_manager.upload_json(
            path,
            {
                "planNumber": plan_number,
                "document": document.model_dump(),
            },
        )
        return uri

    @staticmethod
    def _row_keys(document: ScopingDocumentContent) -> tuple[list[str], list[str]]:
        return (
            [row.key for row in document.plan_details_rows],
            [row.key for row in document.testing_approach_rows],
        )

    @staticmethod
    def _markdown_cell(value: str, preserve_indent: bool = False) -> str:
        escaped = html.escape(value or "")
        escaped = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
        escaped = re.sub(r"&lt;u&gt;(.+?)&lt;/u&gt;", r"<u>\1</u>", escaped)
        escaped = escaped.replace("\r\n", "\n")
        if preserve_indent:
            escaped = re.sub(
                r"(?m)^( +)", lambda match: "&nbsp;" * len(match.group(1)), escaped
            )
        return escaped.replace("\n", "<br>")

    @staticmethod
    def _key_cell(value: str, class_name: str = "key") -> str:
        return f'<td class="{class_name}">{ScopingDocumentService._markdown_cell(value or "")}</td>'

    @staticmethod
    def _value_cell(value: str, path: str | None) -> str:
        # path=None renders a static cell for the PDF instead of an editable one.
        if path is None:
            return f"<td>{ScopingDocumentService._markdown_cell(value or '', preserve_indent=True)}</td>"
        escaped_path = html.escape(path, quote=True)
        return (
            f'<td><div class="cell" data-path="{escaped_path}">'
            f"{ScopingDocumentService._markdown_cell(value or '')}</div></td>"
        )

    @staticmethod
    def _split_plan_rows(
        rows: Sequence[ScopingDocumentRow],
    ) -> tuple[Sequence[ScopingDocumentRow], Sequence[ScopingDocumentRow]]:
        split_index = next(
            (
                index
                for index, row in enumerate(rows)
                if row.key.strip().lower() == "execution approach"
            ),
            None,
        )
        if split_index is None or split_index <= 0 or split_index >= len(rows):
            split_index = (len(rows) + 1) // 2
        return rows[:split_index], rows[split_index:]

    @staticmethod
    def _logo_data_uri() -> str:
        logo_path = Path(__file__).resolve().parent.parent / "assets" / "DB-Logo-sRGB.svg"
        if not logo_path.exists():
            return ""
        encoded = base64.b64encode(logo_path.read_bytes()).decode("ascii")
        return f"data:image/svg+xml;base64,{encoded}"

    def _build_table_rows(
        self, document: ScopingDocumentContent, editable: bool
    ) -> tuple[list[str], list[str], list[str]]:
        def path_for(path: str) -> str | None:
            return path if editable else None

        left_rows, right_rows = self._split_plan_rows(document.plan_details_rows)
        plan_rows = []
        for index in range(max(len(left_rows), len(right_rows))):
            cells = []
            for column, source_rows in enumerate((left_rows, right_rows)):
                if index < len(source_rows):
                    row = source_rows[index]
                    row_index = index if column == 0 else len(left_rows) + index
                    cells.extend((
                        self._key_cell(row.key),
                        self._value_cell(row.value, path_for(f"plan_details_rows.{row_index}.value")),
                    ))
                else:
                    cells.extend(("<td></td>", "<td></td>"))
            plan_rows.append(f"<tr>{''.join(cells)}</tr>")

        scope_rows = []
        for key, title, value in (
            ("inscope", "In Scope", document.inscope),
            ("outscope", "Out of Scope", document.outscope),
        ):
            scope_rows.append(f"<tr><th>{title}</th></tr>")
            scope_rows.append("<tr>" + self._value_cell(value, path_for(key)) + "</tr>")

        testing_rows = []
        for index, row in enumerate(document.testing_approach_rows):
            testing_rows.append(
                "<tr>"
                + self._key_cell(row.key)
                + self._value_cell(row.value, path_for(f"testing_approach_rows.{index}.value"))
                + "</tr>"
            )
        return plan_rows, scope_rows, testing_rows

    @staticmethod
    def _wrapped_lines(value: str, column_width_pt: float) -> list[str]:
        usable = column_width_pt - 2 * _PDF_CELL_PADDING_PT
        lines: list[str] = []
        for source_line in (value or "").replace("\r\n", "\n").split("\n"):
            lines.extend(_wrap_markup_line(source_line, usable))
        return lines

    @staticmethod
    def _flowing_rows(label: str, value: str, label_class: str) -> list[str]:
        """One row per rendered line so a long cell can break across pages instead of jumping to a new one."""
        # The label column is 40% of the table; the value column gets the rest.
        lines = ScopingDocumentService._wrapped_lines(value, _PDF_CONTENT_WIDTH_PT * 0.6)
        label_html = ScopingDocumentService._markdown_cell(label)
        rows = []
        for index, body in enumerate(lines):
            position = ("t " if index == 0 else "") + ("b" if index == len(lines) - 1 else "")
            rows.append(
                f'<tr><td class="{label_class} {position}">{label_html if index == 0 else "&nbsp;"}</td>'
                f'<td class="{position}">{body}</td></tr>'
            )
        return rows

    @staticmethod
    def _flowing_section_rows(title: str, value: str) -> list[str]:
        """Single-column section: a header cell, then the content one rendered line per row."""
        lines = ScopingDocumentService._wrapped_lines(value, _PDF_CONTENT_WIDTH_PT)
        rows = [f'<tr><td class="scope-header t b">{html.escape(title)}</td></tr>']
        for index, body in enumerate(lines):
            position = ("f " if index == 0 else "") + ("b" if index == len(lines) - 1 else "")
            rows.append(f'<tr><td class="{position}">{body}</td></tr>')
        return rows

    def render_pdf_html(self, plan_number: str, document: ScopingDocumentContent) -> str:
        """Static, print-oriented HTML built from the same rows as the editor (xhtml2pdf-compatible CSS)."""
        plan_rows, _, _ = self._build_table_rows(document, editable=False)
        scope_tables = '<p style="margin: 0; font-size: 12pt;">&nbsp;</p>'.join(
            f'<table class="flow-table">{"".join(self._flowing_section_rows(title, value))}</table>'
            for title, value in (("In Scope", document.inscope), ("Out of Scope", document.outscope))
        )
        testing_rows = [
            row_html
            for row in document.testing_approach_rows
            for row_html in self._flowing_rows(row.key, row.value, "testing-label")
        ]
        logo_uri = self._logo_data_uri()
        logo_markup = f'<img src="{logo_uri}" width="28" height="28">' if logo_uri else ""
        return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{html.escape(plan_number)}</title>
<style>
  @page {{
    size: letter landscape; margin: 19mm 8mm 18mm;
    @frame header {{ -pdf-frame-content: page-header; left: 8mm; top: 6mm; width: 263mm; height: 12mm; }}
    @frame footer {{ -pdf-frame-content: page-footer; left: 8mm; top: 199mm; width: 263mm; height: 10mm; }}
  }}
  body {{ font-family: Helvetica; font-size: 8pt; line-height: 1.3; color: #111; }}
  h2 {{ font-size: 8pt; margin: 6mm 0 1.5mm; }}
  table {{ width: 100%; margin-bottom: 4mm; }}
  td {{ padding: 4pt; vertical-align: top; }}
  .plan-table td {{ border: 0.5pt solid #787878; }}
  .flow-table td {{ border-left: 0.5pt solid #787878; border-right: 0.5pt solid #787878; padding-top: 0; padding-bottom: 0; }}
  .flow-table td.t {{ border-top: 0.5pt solid #787878; padding-top: 4pt; }}
  .flow-table td.b {{ border-bottom: 0.5pt solid #787878; padding-bottom: 4pt; }}
  .key {{ background-color: #d8d8d8; font-weight: bold; }}
  .plan-table .key {{ width: 17%; }}
  .flow-table td.f {{ padding-top: 4pt; }}
  .scope-header {{ background-color: #d6d6d6; font-weight: bold; }}
  .testing-label {{ width: 40%; background-color: #ebebeb; font-weight: bold; }}
  .brand {{ color: #14248e; }}
  .division {{ color: #0097e6; }}
  .foot {{ color: #5a5a5a; font-size: 7pt; }}
</style></head>
<body>
  <div id="page-header"><table style="border: 0; margin: 0;"><tr><td style="border: 0; padding: 0;">
    <span class="brand">Deutsche Bank</span><br><span class="division">Controls Testing &amp; Assurance</span>
  </td><td style="border: 0; padding: 0; text-align: right; width: 12%;">{logo_markup}</td></tr></table></div>
  <div id="page-footer" class="foot"><table style="border: 0; margin: 0;"><tr>
    <td style="border: 0; padding: 0; width: 28%;">Deutsche Bank | Controls Testing &amp; Assurance</td>
    <td style="border: 0; padding: 0; text-align: center;">This document is confidential and should not be distributed without the express permission of the CT&amp;A Testing Team<br><b>For internal use only</b></td>
    <td style="border: 0; padding: 0; text-align: right; width: 12%;">Page <pdf:pagenumber/></td>
  </tr></table></div>
  <table class="plan-table">{''.join(plan_rows)}</table>
  <h2>A) Scope</h2>
  {scope_tables}
  <h2>B) Testing Approach</h2>
  <table class="flow-table">{''.join(testing_rows)}</table>
</body></html>"""

    def render_editor_html(self, plan_number: str, document: ScopingDocumentContent) -> str:
        plan_rows, scope_rows, testing_rows = self._build_table_rows(document, editable=True)

        payload = json.dumps(
            {"planNumber": plan_number, "document": document.model_dump()},
            ensure_ascii=True,
        ).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
        logo_uri = self._logo_data_uri()
        logo_markup = f'<img class="logo" src="{logo_uri}" alt="Deutsche Bank">' if logo_uri else ""

        return rf"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(plan_number)}</title>
  <style>
    @page {{ size: letter landscape; margin: 19mm 8mm 18mm; }}
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; color: #111; font: 8pt/1.35 Helvetica, Arial, sans-serif; }}
    .toolbar {{ position: sticky; top: 0; z-index: 2; display: flex; gap: 8px; justify-content: flex-end; padding: 12px 18px; background: #f2f4f5; border-bottom: 1px solid #9a9a9a; }}
    /* Mirrors the app's WADK OutlineButton (primary), light theme, default density. */
    button {{ display: inline-flex; align-items: center; justify-content: center; box-sizing: border-box; margin: 0; padding: 0.25rem 0.5rem; font-family: 'DeutscheBank', Arial, 'Helvetica Neue', sans-serif; font-size: 0.75rem; font-weight: 400; line-height: calc(1rem - 2px); white-space: nowrap; color: #0550d1; background: transparent; border: 1px solid #0550d1; border-radius: 2px; cursor: pointer; }}
    button:hover, button:focus-visible {{ background: rgba(18, 130, 242, 0.08); }}
    button:focus-visible {{ outline: 2px solid #0550d1; outline-offset: 1px; }}
    button:disabled {{ opacity: 0.5; cursor: default; }}
    button[hidden] {{ display: none; }}
    #save-status {{ align-self: center; margin-right: auto; color: #333; }}
    main {{ max-width: 1100px; margin: 0 auto; padding: 19mm 8mm 18mm; }}
    .brand {{ position: relative; min-height: 12mm; margin: -12mm 0 5mm; color: #14248e; }}
    .brand .division {{ display: block; color: #0097e6; }}
    .logo {{ position: absolute; right: 0; top: -2mm; width: 10mm; height: 10mm; }}
    h2 {{ margin: 4mm 0 1mm; font-size: 8pt; }}
    table {{ width: 100%; border-collapse: collapse; table-layout: fixed; margin: 0 0 2mm; }}
    th, td {{ border: 1px solid #787878; padding: 2mm; vertical-align: top; overflow-wrap: anywhere; white-space: pre-wrap; }}
    th {{ background: #d6d6d6; text-align: left; font-weight: bold; }}
    .plan-table .key {{ width: 17%; background: #d8d8d8; font-weight: bold; }}
    .plan-table td:nth-child(2) {{ width: 33%; }}
    .plan-table .key:nth-child(3) {{ width: 17%; }}
    .plan-table td:nth-child(4) {{ width: 33%; }}
    .scope-table {{ margin-bottom: 6mm; }}
    .scope-table th {{ background: #d6d6d6; }}
    .testing-table .key {{ width: 40%; background: #ebebeb; font-weight: bold; }}
    .cell {{ display: block; min-height: 1.35em; outline: none; }}
    body.editing .cell[contenteditable="true"] {{ outline: 1px dashed #005291; outline-offset: 1px; background: #f4f9fd; cursor: text; }}
    .footer {{ position: static; max-width: 1100px; margin: 0 auto 16px; padding: 4mm 8mm; display: grid; grid-template-columns: 28% 1fr 12%; color: #5a5a5a; font-size: 7pt; }}
    .confidential {{ grid-column: 2; text-align: center; }}
        .page-label {{ text-align: right; }}
    @media screen {{ body {{ background: #e7e9eb; }} main {{ min-height: 210mm; margin: 16px auto 0; padding: 19mm 14mm 8mm; background: white; box-shadow: 0 2px 8px #0002; }} .footer {{ background: white; box-shadow: 0 2px 8px #0002; }} }}
        @media print {{
            .toolbar {{ display: none; }}
            main {{ max-width: none; margin: 0; padding: 0; }}
            .brand {{ position: fixed; top: -12mm; left: 0; right: 0; height: 12mm; min-height: 0; margin: 0; }}
            .logo {{ top: 0; }}
            .footer {{ position: fixed; left: 8mm; right: 8mm; bottom: -13mm; max-width: none; margin: 0; padding: 0; }}
            .page-number::before {{ content: counter(page); }}
            button {{ display: none; }}
        }}
  </style>
</head>
<body>
  <div class="toolbar">
    <span id="save-status" role="status"></span>
    <button id="edit-button" type="button">Edit</button>
    <button id="bold-button" type="button" hidden><strong>B</strong></button>
    <button id="underline-button" type="button" hidden><u>U</u></button>
    <button id="cancel-button" type="button" hidden>Cancel</button>
    <button id="save-button" type="button" hidden>Save</button>
    <button id="download-button" type="button">Download PDF</button>
  </div>
  <main>
    <header class="brand"><span>Deutsche Bank</span><span class="division">Controls Testing &amp; Assurance</span>{logo_markup}</header>
    <table class="plan-table"><tbody>{''.join(plan_rows)}</tbody></table>
    <h2>A) Scope</h2>
    <table class="scope-table"><tbody>{''.join(scope_rows[:2])}</tbody></table>
    <table class="scope-table"><tbody>{''.join(scope_rows[2:])}</tbody></table>
    <h2>B) Testing Approach</h2>
    <table class="testing-table"><tbody>{''.join(testing_rows)}</tbody></table>
  </main>
  <footer class="footer"><span>Deutsche Bank | Controls Testing &amp; Assurance</span><span class="confidential">This document is confidential and should not be distributed without the express permission of the CT&amp;A Testing Team<br><b>For internal use only</b></span><span class="page-label">Page <span class="page-number"></span></span></footer>
  <script id="document-data" type="application/json">{payload}</script>
  <script>
    const savedPayload = JSON.parse(document.getElementById('document-data').textContent);
    // The host page owns the API calls (via the gateway); this page only asks it to save or download.
    const pending = new Map();
    let nextRequestId = 0;
    window.addEventListener('message', (event) => {{
      const message = event.data;
      if (event.source !== window.parent || !message || message.type !== 'scoping-document:result' || !pending.has(message.requestId)) return;
      const request = pending.get(message.requestId);
      pending.delete(message.requestId);
      if (message.ok) request.resolve(message);
      else request.reject(new Error(message.error || 'Request failed'));
    }});
    function requestHost(type, body) {{
      return new Promise((resolve, reject) => {{
        const requestId = String(++nextRequestId);
        pending.set(requestId, {{ resolve, reject }});
        window.parent.postMessage({{ type, requestId, planNumber: savedPayload.planNumber, ...body }}, window.origin);
      }});
    }}
    const cells = [...document.querySelectorAll('.cell[data-path]')];
    const status = document.getElementById('save-status');
    const editButton = document.getElementById('edit-button');
    const saveButton = document.getElementById('save-button');
    const cancelButton = document.getElementById('cancel-button');
    const boldButton = document.getElementById('bold-button');
    const underlineButton = document.getElementById('underline-button');
    const escapeHtml = (text) => text.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
    const markdownToHtml = (text) => escapeHtml(text || '').replaceAll('\r\n', '\n').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/&lt;u&gt;(.+?)&lt;\/u&gt;/g, '<u>$1</u>').replaceAll('\n', '<br>');
    const boldLines = (text) => text.split('\n').map((line) => (line.trim() ? line.replace(/^(\s*)(.*?)(\s*)$/, '$1**$2**$3') : line)).join('\n');
    const underlineLines = (text) => text.split('\n').map((line) => (line.trim() ? line.replace(/^(\s*)(.*?)(\s*)$/, '$1<u>$2</u>$3') : line)).join('\n');
    // Convert the formatted cell back to the markdown-style text the PDF renderer consumes.
    function domToMarkdown(node) {{
      let out = '';
      for (const child of node.childNodes) {{
        if (child.nodeType === Node.TEXT_NODE) out += child.textContent.replaceAll('\u00a0', ' ');
        else if (child.nodeName === 'BR') out += '\n';
        else if (child.nodeName === 'STRONG' || child.nodeName === 'B') out += boldLines(domToMarkdown(child));
        else if (child.nodeName === 'U') out += underlineLines(domToMarkdown(child));
        else if (child.nodeName === 'DIV' || child.nodeName === 'P') {{
          const inner = domToMarkdown(child);
          if (out && !out.endsWith('\n')) out += '\n';
          out += inner.endsWith('\n') ? inner : inner + '\n';
        }} else out += domToMarkdown(child);
      }}
      return out;
    }}
    function readCell(cell) {{
      let text = domToMarkdown(cell).replaceAll('****', '').replaceAll('<u></u>', '').replace(/[ \t]+$/gm, '').replace(/\n+$/, '');
      if (cell.dataset.singleLine) text = text.replace(/\s*\n\s*/g, ' ');
      return text;
    }}
    function getPath(target, path) {{
      let value = target;
      for (const part of path.split('.')) value = value[Array.isArray(value) ? Number(part) : part];
      return value;
    }}
    function renderCell(cell) {{
      cell.innerHTML = markdownToHtml(getPath(savedPayload.document, cell.dataset.path));
    }}
    function setEditing(enabled) {{
      document.body.classList.toggle('editing', enabled);
      for (const cell of cells) cell.contentEditable = enabled ? 'true' : 'false';
      editButton.hidden = enabled;
      saveButton.hidden = !enabled;
      cancelButton.hidden = !enabled;
      boldButton.hidden = !enabled;
      underlineButton.hidden = !enabled;
      status.textContent = enabled ? 'Editing document' : '';
    }}
    function assignPath(target, path, value) {{
      const parts = path.split('.');
      let cursor = target;
      for (const part of parts.slice(0, -1)) cursor = cursor[Array.isArray(cursor) ? Number(part) : part];
      cursor[Array.isArray(cursor) ? Number(parts.at(-1)) : parts.at(-1)] = value;
    }}
    for (const cell of cells) {{
      cell.addEventListener('keydown', (event) => {{
        if (event.key === 'Enter') {{
          event.preventDefault();
          if (!cell.dataset.singleLine) document.execCommand('insertLineBreak');
        }} else if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'b') {{
          event.preventDefault();
          if (!cell.dataset.singleLine) document.execCommand('bold');
        }}
      }});
      cell.addEventListener('paste', (event) => {{
        event.preventDefault();
        const text = event.clipboardData.getData('text/plain');
        document.execCommand('insertText', false, cell.dataset.singleLine ? text.replace(/\s*\n\s*/g, ' ') : text);
      }});
    }}
    boldButton.addEventListener('mousedown', (event) => event.preventDefault());
    boldButton.addEventListener('click', () => document.execCommand('bold'));
    underlineButton.addEventListener('mousedown', (event) => event.preventDefault());
    underlineButton.addEventListener('click', () => document.execCommand('underline'));
    editButton.addEventListener('click', () => setEditing(true));
    cancelButton.addEventListener('click', () => {{
      cells.forEach(renderCell);
      setEditing(false);
    }});
    saveButton.addEventListener('click', async () => {{
      const payload = structuredClone(savedPayload);
      for (const cell of cells) assignPath(payload.document, cell.dataset.path, readCell(cell));
      status.textContent = 'Saving...';
      saveButton.disabled = true;
      try {{
        const result = await requestHost('scoping-document:save', {{ document: payload.document }});
        savedPayload.document = result.document;
        cells.forEach(renderCell);
        status.textContent = 'Saved';
        setEditing(false);
      }} catch (error) {{ status.textContent = error.message; }}
      finally {{ saveButton.disabled = false; }}
    }});
    document.getElementById('download-button').addEventListener('click', async () => {{
      if (document.body.classList.contains('editing')) {{ status.textContent = 'Save or cancel edits before downloading.'; return; }}
      status.textContent = 'Preparing PDF...';
      try {{
        await requestHost('scoping-document:download', {{}});
        status.textContent = '';
      }} catch (error) {{ status.textContent = error.message; }}
    }});
  </script>
</body>
</html>"""