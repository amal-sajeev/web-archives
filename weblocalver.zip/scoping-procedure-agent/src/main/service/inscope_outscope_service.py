import json
import logging
import re
from collections.abc import Iterable
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from agents.llm_judge import ReviewLoopError, review_and_revise, review_scope_candidate
from agents.llm_judge.models import ScopeRecommendationReview
from config.config import Config
from config.prompts import INSCOPE_OUTSCOPE_PROMPT
from langchain_core.messages import HumanMessage
from model.response_model import InScopeOutScopeResponse, ScopeReport
from utils.storage_manager import StorageManager

from service.vertex_service import initialize_gemini_model

logger = logging.getLogger(__name__)


class InScopeOutScopeService:
    """Service to gather and manage review data for inscope/outscope generation."""

    def __init__(self):
        """Initialize the service with GCS storage manager."""
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )
        self.config = Config
        self.llm = initialize_gemini_model()

    def _build_review_folder_name(self, plan_number: str) -> str:
        """
        Build the review folder name based on config pattern.

        Args:
            plan_number: Plan number

        Returns:
            Formatted review folder name
        """
        return f"dbaware_review_{plan_number}"

    def _build_procedure_output_blob_path(
        self, plan_number: str, file_name: str
    ) -> str:
        """Build blob path for procedure processing output files."""
        review_folder = self._build_review_folder_name(plan_number)
        procedure_folder = self.config.PROCEDURE_PROCESSING_PATH.strip("/")
        return f"{review_folder}/{procedure_folder}/{file_name}"

    @staticmethod
    def _natural_key(path: str) -> list:
        return [
            int(part) if part.isdigit() else part for part in re.split(r"(\d+)", path)
        ]

    @staticmethod
    def _documents_from_json(content: Any) -> list[dict]:
        if isinstance(content, list):
            return [document for document in content if isinstance(document, dict)]
        if isinstance(content, dict) and isinstance(content.get("documents"), list):
            return [
                document
                for document in content["documents"]
                if isinstance(document, dict)
            ]
        if isinstance(content, dict):
            return [content]
        return []

    @staticmethod
    def _document_relevance(document: dict) -> float:
        try:
            return float(document.get("document_relevance_score"))
        except (AttributeError, TypeError, ValueError):
            return float("-inf")

    def _log_input_file_status(
        self,
        api_name: str,
        plan_number: str,
        blob_path: str,
        content: Any,
    ) -> None:
        status = "FOUND" if content is not None else "NOT FOUND"
        log_method = logger.info if content is not None else logger.warning
        log_method(
            "Input file %s api=%s planNumber=%s uri=gs://%s/%s",
            status,
            api_name,
            plan_number,
            self.storage_manager.bucket_name,
            blob_path,
        )

    def gather_raw_data(
        self,
        plan_number: str,
        api_name: str = "generate-inscope-outscope",
        source_names: Iterable[str] | None = None,
        file_names: dict[str, Iterable[str]] | None = None,
    ) -> dict[str, Any]:
        """
        Gather raw data from bucket for a given review.

        Args:
            plan_number: Plan number
            source_names: Restrict to these RAW_DATA_CONFIG sources; all when None
            file_names: Per-source file allow-list, e.g. {"dbaware": ["plan_details.json"]}

        Returns:
            Dictionary containing raw data organized by source
        """
        review_folder = self._build_review_folder_name(plan_number)
        raw_data = {}

        logger.info(
            "[%s] plan=%s raw data selection: sources=%s file_filter=%s",
            api_name,
            plan_number,
            list(source_names) if source_names is not None else "all",
            {k: list(v) for k, v in file_names.items()} if file_names else "none",
        )

        # Build the full list of (source_name, file_name, blob_path) to download in parallel.
        tasks = []
        merged_parts = set()
        for source_name, source_config in self.config.RAW_DATA_CONFIG.items():
            if source_names is not None and source_name not in source_names:
                continue
            raw_data[source_name] = {}
            folder_path = f"{review_folder}/{source_config['folder']}"

            parts_folders = source_config.get("parts_folders", {})
            if parts_folders:
                parts_by_file = {}
                for file_name, parts_folder in parts_folders.items():
                    prefix = f"{review_folder}/{parts_folder.strip('/')}/"
                    paths = self.storage_manager.list_blobs_in_folder(prefix)
                    json_paths = sorted(
                        (
                            path
                            for path in paths
                            if path.startswith(prefix)
                            and path.lower().endswith(".json")
                        ),
                        key=self._natural_key,
                    )
                    parts_by_file[file_name] = json_paths
                    if json_paths:
                        logger.info(
                            "Input folder FOUND api=%s planNumber=%s uri_prefix=gs://%s/%s files=%s",
                            api_name,
                            plan_number,
                            self.storage_manager.bucket_name,
                            prefix,
                            [path.rsplit("/", 1)[-1] for path in json_paths],
                        )
                    else:
                        logger.warning(
                            "Input folder has no JSON files api=%s planNumber=%s uri_prefix=gs://%s/%s",
                            api_name,
                            plan_number,
                            self.storage_manager.bucket_name,
                            prefix,
                        )

                if any(parts_by_file.values()):
                    logger.info(
                        "Policy parts found; legacy policy files will not be used api=%s planNumber=%s",
                        api_name,
                        plan_number,
                    )
                    for file_name, paths in parts_by_file.items():
                        raw_data[source_name][file_name] = []
                        if paths:
                            merged_parts.add((source_name, file_name))
                            tasks.extend(
                                (source_name, file_name, path) for path in paths
                            )
                    continue

                logger.warning(
                    "No policy JSON parts found; falling back to legacy policy files api=%s planNumber=%s",
                    api_name,
                    plan_number,
                )

            for file_name in source_config["files"]:
                if (
                    file_names
                    and source_name in file_names
                    and file_name not in file_names[source_name]
                ):
                    continue
                blob_path = f"{folder_path}/{file_name}"
                tasks.append((source_name, file_name, blob_path))

        with ThreadPoolExecutor() as executor:
            future_to_task = [
                (
                    executor.submit(self.storage_manager.download_json, blob_path),
                    source_name,
                    file_name,
                    blob_path,
                )
                for source_name, file_name, blob_path in tasks
            ]
            for future, source_name, file_name, blob_path in future_to_task:
                content = future.result()
                self._log_input_file_status(
                    api_name,
                    plan_number,
                    blob_path,
                    content,
                )
                if (source_name, file_name) in merged_parts:
                    raw_data[source_name][file_name].extend(
                        self._documents_from_json(content)
                    )
                else:
                    raw_data[source_name][file_name] = content

        for source_name, file_name in merged_parts:
            raw_data[source_name][file_name].sort(
                key=self._document_relevance,
                reverse=True,
            )

        return raw_data

    def gather_preliminary_research_data(
        self,
        plan_number: str,
        api_name: str = "generate-inscope-outscope",
    ) -> dict[str, Any]:
        """
        Gather preliminary research data for a given review.

        Args:
            plan_number: Plan number

        Returns:
            Dictionary containing preliminary research data and feedback
        """
        review_folder = self._build_review_folder_name(plan_number)
        preliminary_research_path = (
            f"{review_folder}/{self.config.PRELIMINARY_RESEARCH_PATH}"
        )
        feedback_path = (
            f"{review_folder}/{self.config.PRELIMINARY_RESEARCH_FEEDBACK_PATH}"
        )

        section_paths = {
            key: f"{review_folder}/{path}"
            for key, path in self.config.PRELIMINARY_RESEARCH_SECTION_FILES.items()
        }

        with ThreadPoolExecutor() as executor:
            future_sections = {
                key: executor.submit(self.storage_manager.download_json, path)
                for key, path in section_paths.items()
            }
            future_feedback = executor.submit(
                self.storage_manager.download_json, feedback_path
            )
            sections = {key: f.result() for key, f in future_sections.items()}
            feedback_summary = future_feedback.result()

        if any(section is not None for section in sections.values()):
            logger.info(
                "[%s] plan=%s preliminary research source: split section files "
                "(loaded=%s, missing=%s)",
                api_name,
                plan_number,
                [section_paths[k] for k, v in sections.items() if v is not None],
                [section_paths[k] for k, v in sections.items() if v is None],
            )
            for key, path in section_paths.items():
                self._log_input_file_status(api_name, plan_number, path, sections[key])
            preliminary_research = {
                "plan_number": plan_number,
                "analysis_report": sections,
            }
        else:
            logger.info(
                "[%s] plan=%s preliminary research source: legacy file %s "
                "(split section files not found)",
                api_name,
                plan_number,
                preliminary_research_path,
            )
            preliminary_research = self.storage_manager.download_json(
                preliminary_research_path
            )
            self._log_input_file_status(
                api_name, plan_number, preliminary_research_path, preliminary_research
            )

        self._log_input_file_status(
            api_name, plan_number, feedback_path, feedback_summary
        )

        return {
            "preliminary_research": preliminary_research,
            "meeting_mom_summaries": feedback_summary,
        }

    def gather_all_review_data(
        self,
        plan_number: str,
        api_name: str = "generate-inscope-outscope",
    ) -> dict[str, Any]:
        """
        Gather required data (preliminary research + feedback) for inscope/outscope generation.

        Args:
            plan_number: Plan number

        Returns:
            Comprehensive dictionary containing all review data
        """
        preliminary_data = self.gather_preliminary_research_data(
            plan_number,
            api_name=api_name,
        )
        preliminary_data["meeting_mom_summaries"] = preliminary_data.pop(
            "preliminary_research_feedback_summary", None
        )

        return {
            "planNumber": plan_number,
            "preliminary_research_data": preliminary_data,
        }

    def _serialize_review_data(self, review_data: dict[str, Any]) -> str:
        """Serialize gathered review data for prompt input."""
        return json.dumps(review_data, indent=2, ensure_ascii=False, default=str)

    def _build_generation_prompt(
        self,
        plan_number: str,
        review_data: dict[str, Any],
        review_feedback: str = "",
    ) -> str:
        """Build the prompt used for inscope/outscope generation."""
        preliminary_data = review_data.get("preliminary_research_data", {})
        prompt = INSCOPE_OUTSCOPE_PROMPT.format(
            plan_number=plan_number,
            preliminary_research_data=self._serialize_review_data(
                preliminary_data.get("preliminary_research")
            ),
            meeting_mom_summaries=self._serialize_review_data(
                preliminary_data.get("meeting_mom_summaries")
            ),
        )
        if review_feedback:
            prompt += (
                "\n\nAddress this focused review feedback while preserving all correct content:\n"
                f"{review_feedback}"
            )
        return prompt

    def _extract_json_object(self, response_text: str) -> dict[str, Any]:
        """Extract a JSON object from the LLM response."""
        cleaned_response = response_text.strip()

        try:
            return json.loads(cleaned_response)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", cleaned_response, re.DOTALL)
            if not match:
                raise ValueError("Model response did not contain valid JSON.")
            return json.loads(match.group(0))

    def _review_scope_candidate(
        self,
        candidate: InScopeOutScopeResponse,
        review_data: dict[str, Any],
    ) -> ScopeRecommendationReview:
        """Review a generated candidate against the supplied research and feedback."""
        return review_scope_candidate(
            candidate,
            review_data,
            self.llm,
            serialize_review_data=self._serialize_review_data,
            invoke_with_backoff=lambda structured, messages, **_: structured.invoke(
                messages
            ),
            message_factory=HumanMessage,
        )

    def generate_inscope_outscope(self, plan_number: str) -> dict[str, Any]:
        """Gather review data, invoke Gemini, and return independent scope reports."""
        try:
            review_data = self.gather_all_review_data(plan_number)

            def generate(feedback: str = "") -> InScopeOutScopeResponse:
                prompt = self._build_generation_prompt(
                    plan_number, review_data, feedback
                )
                structured_llm = self.llm.with_structured_output(
                    InScopeOutScopeResponse
                )
                return structured_llm.invoke([HumanMessage(content=prompt)])

            def reviewer(
                candidate: InScopeOutScopeResponse,
            ) -> ScopeRecommendationReview:
                return self._review_scope_candidate(candidate, review_data)

            initial_candidate = generate()
            review_result = review_and_revise(
                initial_candidate,
                reviewer=reviewer,
                reviser=lambda _candidate, review: generate(review.feedback),
                approved=lambda review: review.approved,
                has_feedback=lambda review: bool(review.feedback),
                stage="scope_recommendations",
                max_revisions=self.config.SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS,
                failure_policy=self.config.SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY,
            )
            parsed_response = review_result.candidate

            inscope = parsed_response.inscope.model_dump()
            outscope = parsed_response.outscope.model_dump()
            inscope["report"] = str(inscope["report"] or "").strip()
            inscope["rationale"] = str(inscope["rationale"] or "").strip()
            outscope["report"] = str(outscope["report"] or "").strip()
            outscope["rationale"] = str(outscope["rationale"] or "").strip()

            if not inscope["report"] and not outscope["report"]:
                raise ValueError(
                    "Model response did not contain inscope or outscope content."
                )

            inscope_blob_path = self._build_procedure_output_blob_path(
                plan_number=plan_number,
                file_name="inscope.json",
            )
            outscope_blob_path = self._build_procedure_output_blob_path(
                plan_number=plan_number,
                file_name="outscope.json",
            )

            self.storage_manager.upload_json(
                inscope_blob_path,
                {
                    "planNumber": plan_number,
                    "inscope": inscope,
                },
            )
            self.storage_manager.upload_json(
                outscope_blob_path,
                {
                    "planNumber": plan_number,
                    "outscope": outscope,
                },
            )

            return {
                "inscope": inscope,
                "outscope": outscope,
            }
        except Exception as exc:
            if isinstance(exc, ReviewLoopError):
                logger.error(
                    "Failed to generate inscope/outscope plan_number=%s", plan_number
                )
                raise
            logger.exception(
                "Failed to generate inscope/outscope plan_number=%s", plan_number
            )
            raise

    def update_inscope_outscope(
        self,
        plan_number: str,
        inscope: ScopeReport | dict[str, Any],
        outscope: ScopeReport | dict[str, Any],
    ) -> dict[str, Any]:
        """Overwrite existing inscope/outscope artifacts for a plan."""
        inscope_data = (
            inscope.model_dump()
            if isinstance(inscope, ScopeReport)
            else ScopeReport(**inscope).model_dump()
        )
        outscope_data = (
            outscope.model_dump()
            if isinstance(outscope, ScopeReport)
            else ScopeReport(**outscope).model_dump()
        )
        inscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="inscope.json",
        )
        outscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="outscope.json",
        )

        self.storage_manager.upload_json(
            inscope_blob_path,
            {
                "planNumber": plan_number,
                "inscope": inscope_data,
            },
        )
        self.storage_manager.upload_json(
            outscope_blob_path,
            {
                "planNumber": plan_number,
                "outscope": outscope_data,
            },
        )

        return {
            "inscope": inscope_data,
            "outscope": outscope_data,
        }

    def get_inscope_outscope(self, plan_number: str) -> dict[str, Any]:
        """Fetch persisted inscope/outscope artifacts for a plan."""
        inscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="inscope.json",
        )
        outscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="outscope.json",
        )

        with ThreadPoolExecutor() as executor:
            future_inscope = executor.submit(
                self.storage_manager.download_json, inscope_blob_path
            )
            future_outscope = executor.submit(
                self.storage_manager.download_json, outscope_blob_path
            )
            inscope_data = future_inscope.result()
            outscope_data = future_outscope.result()

        if not inscope_data:
            raise FileNotFoundError(
                f"Inscope file not found for planNumber={plan_number}"
            )
        if not outscope_data:
            raise FileNotFoundError(
                f"Outscope file not found for planNumber={plan_number}"
            )

        inscope_payload = inscope_data.get("inscope", {})
        outscope_payload = outscope_data.get("outscope", {})
        if isinstance(inscope_payload, str):
            inscope_payload = {
                "report": inscope_payload,
                "rationale": str(outscope_data.get("rationale", "")).strip(),
                "confidence_score": outscope_data.get("confidence_score", 0),
            }
        if isinstance(outscope_payload, str):
            outscope_payload = {
                "report": outscope_payload,
                "rationale": str(outscope_data.get("rationale", "")).strip(),
                "confidence_score": outscope_data.get("confidence_score", 0),
            }

        return {
            "inscope": ScopeReport(**inscope_payload).model_dump(),
            "outscope": ScopeReport(**outscope_payload).model_dump(),
        }
