import json
import logging
import re
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, Iterable, Optional

from agents.llm_judge import (
    ReviewLoopError, ScopeRecommendationReview, format_revision_prompt,
    invoke_llm_with_backoff, provider_retry_delay_seconds, review_scope_candidate, run_scope_review_workflow,
)
from config.config import Config
from config.prompts import INSCOPE_OUTSCOPE_PROMPT
from langchain_core.messages import HumanMessage
from model.response_model import InScopeOutScopeResponse, ScopeReport
from service.vertex_service import initialize_gemini_model
from utils.storage_manager import StorageManager

logger = logging.getLogger(__name__)


class InScopeOutScopeService:
    """Service to gather and manage review data for inscope/outscope generation."""

    def __init__(self):
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME, bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )
        self.config = Config
        self.llm = initialize_gemini_model()

    def _build_review_folder_name(self, plan_number: str) -> str:
        return f"dbaware_review_{plan_number}"

    def _build_procedure_output_blob_path(self, plan_number: str, file_name: str) -> str:
        return f"{self._build_review_folder_name(plan_number)}/{self.config.PROCEDURE_PROCESSING_PATH.strip('/')}/{file_name}"

    @staticmethod
    def _natural_key(path: str) -> list:
        return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", path)]

    @staticmethod
    def _documents_from_json(content: Any) -> list[dict]:
        if isinstance(content, list):
            return [doc for doc in content if isinstance(doc, dict)]
        if isinstance(content, dict) and isinstance(content.get("documents"), list):
            return [doc for doc in content["documents"] if isinstance(doc, dict)]
        return [content] if isinstance(content, dict) else []

    @staticmethod
    def _document_relevance(document: dict) -> float:
        try:
            return float(document.get("document_relevance_score"))
        except (AttributeError, TypeError, ValueError):
            return float("-inf")

    def _log_input_file_status(self, api_name: str, plan_number: str, blob_path: str, content: Any) -> None:
        log_method = logger.info if content is not None else logger.warning
        log_method(
            "Input file %s api=%s planNumber=%s uri=gs://%s/%s",
            "FOUND" if content is not None else "NOT FOUND",
            api_name, plan_number, self.storage_manager.bucket_name, blob_path,
        )

    def gather_raw_data(
        self, plan_number: str, api_name: str = "generate-inscope-outscope",
        source_names: Optional[Iterable[str]] = None, file_names: Optional[Dict[str, Iterable[str]]] = None,
    ) -> Dict[str, Any]:
        review_folder = self._build_review_folder_name(plan_number)
        raw_data: Dict[str, Any] = {}
        logger.info(
            "[%s] plan=%s raw data selection: sources=%s file_filter=%s",
            api_name, plan_number, list(source_names) if source_names is not None else "all",
            {k: list(v) for k, v in file_names.items()} if file_names else "none",
        )
        tasks, merged_parts = [], set()
        for source_name, source_config in self.config.RAW_DATA_CONFIG.items():
            if source_names is not None and source_name not in source_names:
                continue
            raw_data[source_name] = {}
            folder_path = f"{review_folder}/{source_config['folder']}"
            parts_folders = source_config.get("parts_folders", {})
            if parts_folders:
                parts_by_file = {}
                for file_name, parts_folder in parts_folders.items():
                    prefix = f"{review_folder}/{parts_folder.strip('/')}/"
                    paths = self.storage_manager.list_blobs_in_folder(prefix)
                    json_paths = sorted(
                        (p for p in paths if p.startswith(prefix) and p.lower().endswith(".json")),
                        key=self._natural_key,
                    )
                    parts_by_file[file_name] = json_paths
                    if json_paths:
                        logger.info(
                            "Input folder FOUND api=%s planNumber=%s uri_prefix=gs://%s/%s files=%s",
                            api_name, plan_number, self.storage_manager.bucket_name,
                            prefix, [p.rsplit("/", 1)[-1] for p in json_paths],
                        )
                    else:
                        logger.warning(
                            "Input folder has no JSON files api=%s planNumber=%s uri_prefix=gs://%s/%s",
                            api_name, plan_number, self.storage_manager.bucket_name, prefix,
                        )
                if any(parts_by_file.values()):
                    logger.info(
                        "Policy parts found; legacy policy files will not be used api=%s planNumber=%s",
                        api_name, plan_number,
                    )
                    for file_name, paths in parts_by_file.items():
                        raw_data[source_name][file_name] = []
                        if paths:
                            merged_parts.add((source_name, file_name))
                            tasks.extend((source_name, file_name, path) for path in paths)
                    continue
                logger.warning(
                    "No policy JSON parts found; falling back to legacy policy files api=%s planNumber=%s",
                    api_name, plan_number,
                )
            for file_name in source_config["files"]:
                if file_names and source_name in file_names and file_name not in file_names[source_name]:
                    continue
                tasks.append((source_name, file_name, f"{folder_path}/{file_name}"))

        with ThreadPoolExecutor() as executor:
            futures = [(executor.submit(self.storage_manager.download_json, bp), sn, fn, bp) for sn, fn, bp in tasks]
            for future, sn, fn, bp in futures:
                content = future.result()
                self._log_input_file_status(api_name, plan_number, bp, content)
                if (sn, fn) in merged_parts:
                    raw_data[sn][fn].extend(self._documents_from_json(content))
                else:
                    raw_data[sn][fn] = content

        for sn, fn in merged_parts:
            raw_data[sn][fn].sort(key=self._document_relevance, reverse=True)
        return raw_data

    def gather_preliminary_research_data(
        self, plan_number: str, api_name: str = "generate-inscope-outscope",
    ) -> Dict[str, Any]:
        review_folder = self._build_review_folder_name(plan_number)
        pr_path = f"{review_folder}/{self.config.PRELIMINARY_RESEARCH_PATH}"
        feedback_path = f"{review_folder}/{self.config.PRELIMINARY_RESEARCH_FEEDBACK_PATH}"
        section_paths = {
            k: f"{review_folder}/{p}" for k, p in self.config.PRELIMINARY_RESEARCH_SECTION_FILES.items()
        }
        with ThreadPoolExecutor() as executor:
            future_sections = {k: executor.submit(self.storage_manager.download_json, p) for k, p in section_paths.items()}
            future_feedback = executor.submit(self.storage_manager.download_json, feedback_path)
            sections = {k: f.result() for k, f in future_sections.items()}
            feedback_summary = future_feedback.result()

        if any(s is not None for s in sections.values()):
            logger.info(
                "[%s] plan=%s preliminary research source: split section files (loaded=%s, missing=%s)",
                api_name, plan_number,
                [section_paths[k] for k, v in sections.items() if v is not None],
                [section_paths[k] for k, v in sections.items() if v is None],
            )
            for k, p in section_paths.items():
                self._log_input_file_status(api_name, plan_number, p, sections[k])
            preliminary_research = {"plan_number": plan_number, "analysis_report": sections}
        else:
            logger.info(
                "[%s] plan=%s preliminary research source: legacy file %s (split section files not found)",
                api_name, plan_number, pr_path,
            )
            preliminary_research = self.storage_manager.download_json(pr_path)
            self._log_input_file_status(api_name, plan_number, pr_path, preliminary_research)

        self._log_input_file_status(api_name, plan_number, feedback_path, feedback_summary)
        return {"preliminary_research": preliminary_research, "meeting_mom_summaries": feedback_summary}

    def gather_all_review_data(
        self, plan_number: str, api_name: str = "generate-inscope-outscope",
    ) -> Dict[str, Any]:
        preliminary_data = self.gather_preliminary_research_data(plan_number, api_name=api_name)
        if "meeting_mom_summaries" not in preliminary_data:
            preliminary_data["meeting_mom_summaries"] = preliminary_data.pop(
                "preliminary_research_feedback_summary", None
            )
        else:
            preliminary_data.pop("preliminary_research_feedback_summary", None)
        return {"planNumber": plan_number, "preliminary_research_data": preliminary_data}

    def _serialize_review_data(self, review_data: Dict[str, Any]) -> str:
        return json.dumps(review_data, indent=2, ensure_ascii=False, default=str)

    def _build_generation_prompt(
        self, plan_number: str, review_data: Dict[str, Any], review_feedback: str = "", previous_candidate: Any = None,
    ) -> str:
        preliminary_data = review_data.get("preliminary_research_data", {})
        prompt = INSCOPE_OUTSCOPE_PROMPT.format(
            plan_number=plan_number,
            preliminary_research_data=self._serialize_review_data(preliminary_data.get("preliminary_research")),
            meeting_mom_summaries=self._serialize_review_data(preliminary_data.get("meeting_mom_summaries")),
        )
        return format_revision_prompt(prompt, review_feedback, previous_candidate)

    _provider_retry_delay_seconds = staticmethod(provider_retry_delay_seconds)

    def _invoke_llm_with_backoff(self, model: Any, messages: list[Any], *, stage: str) -> Any:
        return invoke_llm_with_backoff(
            model, messages, stage=stage,
            max_attempts=getattr(self.config, "SCOPE_RECOMMENDATION_LLM_MAX_ATTEMPTS", 4),
            retry_base_seconds=getattr(self.config, "SCOPE_RECOMMENDATION_LLM_RETRY_BASE_SECONDS", 2),
            sleep_fn=time.sleep,
        )

    def _review_scope_candidate(
        self, candidate: InScopeOutScopeResponse, review_data: Dict[str, Any]
    ) -> ScopeRecommendationReview:
        return review_scope_candidate(
            candidate, review_data, self.llm,
            serialize_review_data=self._serialize_review_data,
            invoke_with_backoff=self._invoke_llm_with_backoff,
            message_factory=HumanMessage,
        )

    def _extract_json_object(self, response_text: str) -> Dict[str, Any]:
        cleaned = response_text.strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if not match:
                raise ValueError("Model response did not contain valid JSON.")
            return json.loads(match.group(0))

    def _persist_scope_outputs(self, plan_number: str, inscope: Dict[str, Any], outscope: Dict[str, Any]) -> Dict[str, Any]:
        for key, payload in (("inscope", inscope), ("outscope", outscope)):
            blob_path = self._build_procedure_output_blob_path(plan_number, f"{key}.json")
            self.storage_manager.upload_json(blob_path, {"planNumber": plan_number, key: payload})
        return {"inscope": inscope, "outscope": outscope}

    def _is_judge_loop_enabled(self) -> bool:
        env_override = None
        for env_name in ("SCOPE_RECOMMENDATION_JUDGE_LOOP", "JUDGE_LOOP", "judge_loop"):
            import os
            val = os.getenv(env_name)
            if val is not None:
                normalized = val.strip().lower()
                if normalized in {"1", "true", "yes", "on"}:
                    env_override = True
                    break
                if normalized in {"0", "false", "no", "off"}:
                    env_override = False
                    break
        config_flag = getattr(
            self.config,
            "SCOPE_RECOMMENDATION_JUDGE_LOOP",
            getattr(self.config, "JUDGE_LOOP", False),
        )
        if config_flag is not Config.SCOPE_RECOMMENDATION_JUDGE_LOOP:
            return bool(config_flag)
        if env_override is not None:
            return env_override
        return bool(config_flag)

    def generate_inscope_outscope(self, plan_number: str) -> tuple[Dict[str, Any], Dict[str, int]]:
        try:
            review_data = self.gather_all_review_data(plan_number)
            structured_llm = self.llm.with_structured_output(InScopeOutScopeResponse, include_raw=True)
            usage_metadata = {"input_tokens": 0, "output_tokens": 0}

            def _generate_candidate(feedback: str = "", prev: Any = None) -> InScopeOutScopeResponse:
                prompt = self._build_generation_prompt(plan_number, review_data, feedback, prev)
                result = self._invoke_llm_with_backoff(
                    structured_llm, [HumanMessage(content=prompt)], stage="generate_inscope_outscope",
                )
                if isinstance(result, dict) and "parsed" in result:
                    usage = getattr(result.get("raw"), "usage_metadata", None) or {}
                    usage_metadata["input_tokens"] += int(usage.get("input_tokens", 0) or 0)
                    usage_metadata["output_tokens"] += int(usage.get("output_tokens", 0) or 0)
                    return result["parsed"]
                return result

            parsed_response: InScopeOutScopeResponse = run_scope_review_workflow(
                generate_fn=_generate_candidate,
                reviewer_fn=lambda candidate: self._review_scope_candidate(candidate, review_data),
                max_revisions=self.config.SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS,
                failure_policy=self.config.SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY,
                judge_loop=self._is_judge_loop_enabled(),
            )
            inscope = parsed_response.inscope.model_dump()
            outscope = parsed_response.outscope.model_dump()
            for item in (inscope, outscope):
                item["report"] = str(item["report"] or "").strip()
                item["rationale"] = str(item["rationale"] or "").strip()
            if not inscope["report"] and not outscope["report"]:
                raise ValueError("Model response did not contain inscope or outscope content.")

            logger.info(f"******** in generate_inscope_outscope usage_metadata = {usage_metadata}")

            return self._persist_scope_outputs(plan_number, inscope, outscope), usage_metadata
        except ReviewLoopError as exc:
            raise ReviewLoopError(str(exc)) from None
        except Exception:
            logger.exception("Failed to generate inscope/outscope plan_number=%s", plan_number)
            raise

    def update_inscope_outscope(
        self, plan_number: str, inscope: ScopeReport | dict[str, Any], outscope: ScopeReport | dict[str, Any],
    ) -> Dict[str, Any]:
        inscope_data = inscope.model_dump() if isinstance(inscope, ScopeReport) else ScopeReport(**inscope).model_dump()
        outscope_data = outscope.model_dump() if isinstance(outscope, ScopeReport) else ScopeReport(**outscope).model_dump()
        return self._persist_scope_outputs(plan_number, inscope_data, outscope_data)

    def get_inscope_outscope(self, plan_number: str) -> Dict[str, Any]:
        inscope_path = self._build_procedure_output_blob_path(plan_number, "inscope.json")
        outscope_path = self._build_procedure_output_blob_path(plan_number, "outscope.json")
        with ThreadPoolExecutor() as executor:
            f_in = executor.submit(self.storage_manager.download_json, inscope_path)
            f_out = executor.submit(self.storage_manager.download_json, outscope_path)
            inscope_data, outscope_data = f_in.result(), f_out.result()
        if not inscope_data or not outscope_data:
            missing = "Inscope" if not inscope_data else "Outscope"
            raise FileNotFoundError(f"{missing} file not found for planNumber={plan_number}")

        def _coerce(raw: dict[str, Any], key: str) -> dict[str, Any]:
            payload = raw.get(key, {})
            if isinstance(payload, str):
                payload = {"report": payload, "rationale": str(outscope_data.get("rationale", "")).strip(), "confidence_score": outscope_data.get("confidence_score", 0)}
            return ScopeReport(**payload).model_dump()

        return {"inscope": _coerce(inscope_data, "inscope"), "outscope": _coerce(outscope_data, "outscope")}
