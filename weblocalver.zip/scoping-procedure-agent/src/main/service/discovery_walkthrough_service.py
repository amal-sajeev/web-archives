import asyncio
import json
import logging
from typing import Any, Dict

from config.prompts import DISCOVERY_WALKTHROUGH_PROMPT
from model.response_model import DiscoveryWalkthroughReport
from service.discovery_walkthrough_upload_service import (
    DiscoveryWalkthroughUploadService,
)
from service.inscope_outscope_service import InScopeOutScopeService
from service.vertex_service import initialize_gemini_model
from utils.storage_manager import StorageManager
from config.config import Config

logger = logging.getLogger(__name__)


class DiscoveryWalkthroughService:
    """Service for generating the discovery walkthrough report."""

    def __init__(self):
        """Initialize the service with GCS storage manager."""
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )
        self.config = Config
        self.llm = initialize_gemini_model()
        self.inscope_outscope_service = InScopeOutScopeService()
        self.question_bank_service = DiscoveryWalkthroughUploadService()


    @staticmethod
    def _extract_usage_tokens(response_obj: Any) -> dict[str, int]:
        usage = None

        if response_obj is None:
            return {"input_tokens": 0, "output_tokens": 0}

        usage = getattr(response_obj, "usage_metadata", None)
        if usage is None:
            nested_response = getattr(response_obj, "response", None)
            if nested_response is not None:
                usage = getattr(nested_response, "usage_metadata", None)

        if usage is None:
            response_metadata = getattr(response_obj, "response_metadata", None) or {}
            if isinstance(response_metadata, dict):
                usage = response_metadata.get("usage_metadata")

        if not usage:
            return {"input_tokens": 0, "output_tokens": 0}

        if isinstance(usage, dict):
            input_tokens = int(usage.get("prompt_token_count") or usage.get("input_tokens") or 0)
            output_tokens = int(usage.get("candidates_token_count") or usage.get("output_tokens") or 0)

            return {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens
            }

        input_tokens = int(getattr(usage, "prompt_token_count", 0) or getattr(usage, "input_tokens", 0) or 0)
        output_tokens = int(getattr(usage, "candidates_token_count", 0) or getattr(usage, "output_tokens", 0) or 0)

        logger.info(f" ********* _extract_usage_tokens input_tokens = {input_tokens} , output_tokens={output_tokens}")
        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens
        }

    async def generate_report(self, plan_number: str) -> tuple[Dict[str, Any], Dict[str, int]]:

        """
        Generates a discovery walkthrough report by summarizing a preliminary research report.

        Args:
            plan_number: The plan number.

        Returns:
            A dictionary representing the generated discovery walkthrough report.

        Raises:
            FileNotFoundError: If the preliminary research report is not found.
        """
        logger.info(
            "Generating discovery walkthrough report for planNumber=%s",
            plan_number,
        )

        data = self.inscope_outscope_service.gather_preliminary_research_data(
            plan_number,
            api_name="generate-discovery-walkthrough",
        )
        preliminary_report = data["preliminary_research"]
        user_question_bank = self.question_bank_service.load_question_bank(plan_number)

        user_question_context = ""
        uploaded_question_documents = user_question_bank.get("question_documents", [])
        if uploaded_question_documents:
            user_question_context = "\n\nUser Uploaded Question Bank Documents:\n"
            for document in uploaded_question_documents:
                filename = document.get("filename", "uploaded_document")
                text = document.get("text", "").strip()
                if not text:
                    continue
                user_question_context += f"\n--- File: {filename} ---\n{text}\n"

        # 2. Use LLM to generate the discovery walkthrough report
        structured_model = self.llm.with_structured_output(DiscoveryWalkthroughReport, include_raw=True)

        input_prompt = f"""
        {DISCOVERY_WALKTHROUGH_PROMPT}

        Here is the Preliminary Research Report:
        {json.dumps(preliminary_report, indent=2)}

        {user_question_context}
        """

        logger.info("Generating discovery walkthrough with Gemini.")
        raw_result = await asyncio.to_thread(structured_model.invoke, input_prompt)

        logger.info("Discovery walkthrough report generated.")

        raw_response = raw_result.get("raw") if isinstance(raw_result, dict) else raw_result
        parsed_response = raw_result.get("parsed") if isinstance(raw_result, dict) else raw_result
        usage_metadata = self._extract_usage_tokens(raw_response)
        logger.info(f"****** in generate_report usage_metadata = {usage_metadata}")

        # .model_dump() returns a Python dictionary from the Pydantic model.
        # FastAPI will automatically serialize this dictionary into a JSON response.
        #report_data = discovery_report.model_dump()
        report_data = parsed_response.model_dump() if hasattr(parsed_response,
                                                              "model_dump") else raw_response.model_dump()

        # Construct the full GCS path for the output file
        review_folder = self.inscope_outscope_service._build_review_folder_name(
            plan_number
        )
        upload_path = (
            f"{review_folder}/"
            f"{self.config.SCOPING_FOLDER_PATH.strip('/')}/"
            f"{self.config.DISCOVERY_WALKTHROUGH_FILE}"
        )

        self.storage_manager.upload_json(upload_path, report_data)
        logger.info("Uploaded discovery walkthrough report to %s", upload_path)

        return report_data, usage_metadata

    def update_report(
        self, plan_number: str, report_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Overwrite discovery walkthrough artifact for a plan with user-edited JSON."""
        review_folder = self.inscope_outscope_service._build_review_folder_name(
            plan_number
        )
        upload_path = (
            f"{review_folder}/"
            f"{self.config.SCOPING_FOLDER_PATH.strip('/')}/"
            f"{self.config.DISCOVERY_WALKTHROUGH_FILE}"
        )
        self.storage_manager.upload_json(upload_path, report_data)
        logger.info("Updated discovery walkthrough report at %s", upload_path)
        return report_data

    def get_report(self, plan_number: str) -> Dict[str, Any]:
        """Fetch persisted discovery walkthrough artifact for a plan."""
        review_folder = self.inscope_outscope_service._build_review_folder_name(
            plan_number
        )
        upload_path = (
            f"{review_folder}/"
            f"{self.config.SCOPING_FOLDER_PATH.strip('/')}/"
            f"{self.config.DISCOVERY_WALKTHROUGH_FILE}"
        )
        report_data = self.storage_manager.download_json(upload_path)
        if not report_data:
            raise FileNotFoundError(
                f"Discovery walkthrough file not found for planNumber={plan_number}"
            )
        return report_data
