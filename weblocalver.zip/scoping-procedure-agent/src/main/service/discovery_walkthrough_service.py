import asyncio
import json
import logging
from typing import Any, Dict

from config.prompts import DISCOVERY_WALKTHROUGH_PROMPT
from model.response_model import DiscoveryWalkthroughReport
from service.inscope_outscope_service import InScopeOutScopeService
from service.vertex_service import initialize_gemini_model
from utils.storage_manager import StorageManager
from config.config import Config



logger = logging.getLogger(__name__)


class DiscoveryWalkthroughService():
    """Service for generating the discovery walkthrough report."""
    
    def __init__(self):
        """Initialize the service with GCS storage manager."""
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME
        )
        self.config = Config
        self.llm = initialize_gemini_model()
        self.inscope_outscope_service = InScopeOutScopeService()
    

    async def generate_report(self, plan_number: str) -> Dict[str, Any]:
        """
        Generates a discovery walkthrough report by summarizing a preliminary research report.

        Args:
            plan_number: The plan number.

        Returns:
            A dictionary representing the generated discovery walkthrough report.

        Raises:
            FileNotFoundError: If the preliminary research report is not found.
        """
        logger.info(
            "Generating discovery walkthrough report for planNumber=%s",
            plan_number,
        )


        data = self.inscope_outscope_service.gather_preliminary_research_data(
            plan_number,
            api_name="generate-discovery-walkthrough",
        )
        preliminary_report = data["preliminary_research"]

        # 2. Use LLM to generate the discovery walkthrough report
        structured_model = self.llm.with_structured_output(DiscoveryWalkthroughReport)

        input_prompt = f"""
        {DISCOVERY_WALKTHROUGH_PROMPT}

        Here is the Preliminary Research Report:
        {json.dumps(preliminary_report, indent=2)}
        """

        logger.info("Generating discovery walkthrough with Gemini.")
        discovery_report = await asyncio.to_thread(structured_model.invoke, input_prompt)
        logger.info("Discovery walkthrough report generated.")

        # .model_dump() returns a Python dictionary from the Pydantic model.
        # FastAPI will automatically serialize this dictionary into a JSON response.
        report_data = discovery_report.model_dump()

        # Construct the full GCS path for the output file
        review_folder = self.inscope_outscope_service._build_review_folder_name(
            plan_number
        )
        upload_path = (
            f"{review_folder}/"
            f"{self.config.SCOPING_FOLDER_PATH.strip('/')}/"
            f"{self.config.DISCOVERY_WALKTHROUGH_FILE}"
        )

        self.storage_manager.upload_json(upload_path, report_data)
        logger.info("Uploaded discovery walkthrough report to %s", upload_path)

        return report_data

    def update_report(self, plan_number: str, report_data: Dict[str, Any]) -> Dict[str, Any]:
        """Overwrite discovery walkthrough artifact for a plan with user-edited JSON."""
        review_folder = self.inscope_outscope_service._build_review_folder_name(plan_number)
        upload_path = (
            f"{review_folder}/"
            f"{self.config.SCOPING_FOLDER_PATH.strip('/')}/"
            f"{self.config.DISCOVERY_WALKTHROUGH_FILE}"
        )
        self.storage_manager.upload_json(upload_path, report_data)
        logger.info("Updated discovery walkthrough report at %s", upload_path)
        return report_data

    def get_report(self, plan_number: str) -> Dict[str, Any]:
        """Fetch persisted discovery walkthrough artifact for a plan."""
        review_folder = self.inscope_outscope_service._build_review_folder_name(plan_number)
        upload_path = (
            f"{review_folder}/"
            f"{self.config.SCOPING_FOLDER_PATH.strip('/')}/"
            f"{self.config.DISCOVERY_WALKTHROUGH_FILE}"
        )
        report_data = self.storage_manager.download_json(upload_path)
        if not report_data:
            raise FileNotFoundError(f"Discovery walkthrough file not found for planNumber={plan_number}")
        return report_data