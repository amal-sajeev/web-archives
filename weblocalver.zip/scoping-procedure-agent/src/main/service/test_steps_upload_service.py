import base64
import logging
import re
from typing import Any

from fastapi import UploadFile

from config.config import Config
from config.prompts import TEST_STEPS_GUARDRAIL_PROMPT, TEST_STEPS_PROMPT
from model.request_model import UserRequest
from model.response_model import TestStepsUploadResponse, TestStepsUploadValidation
from service.vertex_service import initialize_gemini_model
from utils.document_processor import extract_text
from utils.storage_manager import StorageManager

logger = logging.getLogger(__name__)


class TestStepsUploadService:
    """Validate and persist user-uploaded test-step supporting documents."""

    _TEST_STEP_FIELD_LAYOUT = (
        "Test Step Name and Number",
        "Execution Approach",
        "Overview of Risk(s) to be Considered in this Workpaper",
        "Assessment Unit",
        "Risk Type",
        "Geographical Coverage",
        "Legal Entities",
        "Core Processes",
        "Any Other Elements",
        "DMA Relevance",
        "Laws, Rules and Regulations",
        "Name of MTR and Description",
        "Key Regulatory Obligations",
        "DB Policies",
        "Procedures/Supporting Documents",
        "Minimum Control Standards (MCS)/Control Objectives",
        "Control(s): Name, Number, Key/Non-Key, Control Description",
        "Training",
        "Other Risk Mitigating Activity",
        "Regulatory Traceability Approach",
        "Design Effectiveness Testing Approach",
        "Operating Effectiveness Testing Approach",
        "Process Outcome/Adherence Testing Approach",
        "Risk Management Assessment Approach",
    )
    _TEST_STEP_FIELD_HEADINGS = tuple(
        field.lower() for field in _TEST_STEP_FIELD_LAYOUT
    )
    _TEMPLATE_PLACEHOLDER_PATTERNS = (
        "template version",
        "this document is confidential",
        "to be sourced directly from aware",
        "can be [party] automated",
        "can be partially automated based on the pre-research phase",
        "to be greyed out",
        "greyed out for plan items",
        "this can be pulled through to the workpaper",
        "this can filter through from the key information section",
    )

    def __init__(self):
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )
        self.llm = initialize_gemini_model()

    @staticmethod
    def _safe_name(value: str) -> str:
        return re.sub(r"[^A-Za-z0-9._-]", "_", value)

    @staticmethod
    def _normalize_text(text: str) -> str:
        cleaned = text.strip()
        if not cleaned:
            return ""
        return "\n".join(line.strip() for line in cleaned.splitlines() if line.strip())

    @staticmethod
    def _is_invalid_placeholder(value: str) -> bool:
        text = value.strip()
        return text in {"", ".", "-", "N/A", "NA", "null", "None"}

    @staticmethod
    def _normalize_for_matching(value: str) -> str:
        return re.sub(r"\s+", " ", value).strip().lower()

    _HEADING_ALIASES = (
        ("Assessment Unit (AU)", "Assessment Unit"),
        ("Laws, Rules and Regulations (LRRs)", "Laws, Rules and Regulations"),
    )
    _EXECUTION_APPROACH_FIELD = "Execution Approach"
    _APPROACH_FIELDS = (
        "Design Effectiveness Testing Approach",
        "Operating Effectiveness Testing Approach",
        "Process Outcome/Adherence Testing Approach",
    )

    @classmethod
    def _match_field_heading(cls, line: str) -> tuple[str, str] | None:
        """Return (field, inline_value) only when the line IS a field heading.

        A heading line is exactly a heading (ignoring case, markdown emphasis and a
        trailing colon), or "<heading>: <value>". Lines that merely contain heading
        words, such as a value of "Sanctions and AML Risk Type", are not headings.
        """
        plain = re.sub(r"[*_#]+", "", line).strip()
        if not plain:
            return None

        entries = [(name, name) for name in cls._TEST_STEP_FIELD_LAYOUT]
        entries.extend(cls._HEADING_ALIASES)
        entries.sort(key=lambda item: len(item[0]), reverse=True)

        exact = cls._normalize_for_matching(plain.rstrip(":"))
        for heading_text, field in entries:
            if cls._normalize_for_matching(heading_text) == exact:
                return field, ""

        for heading_text, field in entries:
            inline = re.match(
                rf"^{re.escape(heading_text)}\s*:\s*(.+)$", plain, re.IGNORECASE
            )
            if inline:
                return field, inline.group(1).strip()
        return None

    @classmethod
    def _parse_uploaded_step_fields(cls, extracted_text: str) -> dict[str, str | None]:
        """Extract field values using the fixed 24 heading contract.

        Values keep their original line breaks and markdown. A field stays None only
        when its heading is absent or its value is a placeholder such as null or "-".
        """
        step = {field: None for field in cls._TEST_STEP_FIELD_LAYOUT}
        lines = [line.rstrip() for line in extracted_text.splitlines()]
        if not any(line.strip() for line in lines):
            return step

        current_field: str | None = None
        buffer: list[str] = []
        seen_fields: set[str] = set()

        def flush() -> None:
            nonlocal current_field, buffer
            if current_field is None:
                return
            while buffer and not buffer[0].strip():
                buffer.pop(0)
            while buffer and not buffer[-1].strip():
                buffer.pop()
            if current_field == cls._EXECUTION_APPROACH_FIELD:
                value = " ; ".join(item.strip() for item in buffer if item.strip())
            else:
                value = "\n".join(buffer)
            if value.strip() and not cls._is_invalid_placeholder(value):
                step[current_field] = value
            current_field = None
            buffer = []

        for index, line in enumerate(lines):
            matched = cls._match_field_heading(line) if line.strip() else None

            if matched:
                field, inline_value = matched
                next_line = next(
                    (item.strip() for item in lines[index + 1 :] if item.strip()), ""
                )
                # Under "Execution Approach", the approach names are its values, unless
                # they start a real section (followed by a numbered list of steps).
                is_approach_value = (
                    current_field == cls._EXECUTION_APPROACH_FIELD
                    and field in cls._APPROACH_FIELDS
                    and not inline_value
                    and not re.match(r"^\d+[.)]\s", next_line)
                )
                if is_approach_value or field in seen_fields:
                    buffer.append(line)
                    continue

                flush()
                current_field = field
                seen_fields.add(field)
                if inline_value:
                    buffer.append(inline_value)
                continue

            if current_field is not None:
                buffer.append(line)

        flush()
        return step

    @classmethod
    def _build_canonical_test_step_content(
        cls,
        filename: str,
        extracted_text: str,
    ) -> str:
        """Build a canonical 24-field text payload so generation sees stable headings."""
        parsed = cls._parse_uploaded_step_fields(extracted_text)
        lines = [f"Source Filename: {filename}", ""]
        for field in cls._TEST_STEP_FIELD_LAYOUT:
            lines.append(field)
            value = parsed.get(field)
            if value is None or cls._is_invalid_placeholder(value):
                lines.append("null")
            else:
                lines.append(value)
            lines.append("")
        return "\n".join(lines).strip() + "\n"

    @staticmethod
    def _has_template_placeholder_content(text: str) -> bool:
        normalized = TestStepsUploadService._normalize_text(text).lower()
        if not normalized:
            return False

        placeholder_hits = sum(
            1
            for pattern in TestStepsUploadService._TEMPLATE_PLACEHOLDER_PATTERNS
            if pattern in normalized
        )
        if placeholder_hits < 2:
            return False

        required_section_hits = sum(
            1
            for heading in (
                "test step name and number",
                "execution approach",
                "overview of risk(s) to be considered in this workpaper",
                "risk type",
                "design effectiveness testing approach",
                "operating effectiveness testing approach",
            )
            if heading in normalized
        )

        return required_section_hits >= 2 and placeholder_hits >= 2

    @staticmethod
    def _count_test_step_heading_matches(text: str) -> int:
        normalized = TestStepsUploadService._normalize_text(text).lower()
        if not normalized:
            return 0
        return sum(
            1
            for heading in TestStepsUploadService._TEST_STEP_FIELD_HEADINGS
            if heading in normalized
        )

    @staticmethod
    def _extract_test_step_markers(text: str) -> list[str]:
        normalized = TestStepsUploadService._normalize_text(text)
        if not normalized:
            return []

        markers = list(TestStepsUploadService._TEST_STEP_FIELD_HEADINGS)
        lower = normalized.lower()

        found: list[str] = []
        for marker in markers:
            if marker in lower:
                found.append(marker)
        return found

    @staticmethod
    def _has_core_test_step_signature(text: str) -> bool:
        normalized = TestStepsUploadService._normalize_text(text).lower()
        if not normalized:
            return False

        required_markers = (
            "test step name and number",
            "execution approach",
            "overview of risk(s) to be considered in this workpaper",
            "assessment unit",
            "risk type",
            "design effectiveness testing approach",
            "operating effectiveness testing approach",
        )
        signature_count = sum(1 for marker in required_markers if marker in normalized)
        if signature_count >= 4:
            return True

        return (
            ("test step" in normalized or "test steps" in normalized)
            and (
                "execution approach" in normalized
                or "design effectiveness testing approach" in normalized
                or "operating effectiveness testing approach" in normalized
            )
            and ("risk type" in normalized or "assessment unit" in normalized)
        )

    @staticmethod
    def _is_likely_test_steps_document(text: str) -> bool:
        normalized = TestStepsUploadService._normalize_text(text)
        if not normalized:
            return False

        if TestStepsUploadService._has_template_placeholder_content(normalized):
            return False

        heading_matches = TestStepsUploadService._count_test_step_heading_matches(
            normalized
        )
        if heading_matches >= 8:
            return True

        if not TestStepsUploadService._has_core_test_step_signature(normalized):
            return False

        if heading_matches < 4:
            return False

        markers = TestStepsUploadService._extract_test_step_markers(normalized)
        if not markers:
            return False

        lines = [line.strip() for line in normalized.splitlines() if line.strip()]
        total_lines = len(lines)
        if total_lines == 0:
            return False

        marker_ratio = len(markers) / max(1, min(total_lines, 24))
        return len(markers) >= 3 and marker_ratio >= 0.15

    def _validate_test_steps_document(
        self,
        filename: str,
        content: bytes,
    ) -> tuple[TestStepsUploadValidation, str]:
        extracted_text = self._normalize_text(extract_text(filename, content))
        if not extracted_text:
            return (
                TestStepsUploadValidation(
                    filename=filename,
                    is_valid=False,
                    reason="The document is empty, unreadable, or contains no usable test-step content.",
                    document_type="not_test_steps",
                ),
                "",
            )

        if not self._is_likely_test_steps_document(extracted_text):
            return (
                TestStepsUploadValidation(
                    filename=filename,
                    is_valid=False,
                    reason="The document does not contain the recognizable structure of a test-steps artifact or a meaningful subset of its fixed headings.",
                    document_type="not_test_steps",
                ),
                extracted_text,
            )

        structured_model = self.llm.with_structured_output(TestStepsUploadValidation)
        prompt = (
            f"{TEST_STEPS_PROMPT}\n\n"
            f"Uploaded file name: {filename}\n\n"
            "Extracted text:\n"
            f"{extracted_text[:15000]}\n\n"
            f"{TEST_STEPS_GUARDRAIL_PROMPT}"
        )

        try:
            validation_result = structured_model.invoke(prompt)
        except Exception as exc:
            logger.warning(
                "Test-steps guardrail validation failed for file %s: %s",
                filename,
                exc,
            )
            return (
                TestStepsUploadValidation(
                    filename=filename,
                    is_valid=False,
                    reason="The document could not be validated as a test-steps artifact because the guardrail check failed.",
                    document_type="not_test_steps",
                ),
                extracted_text,
            )

        if isinstance(validation_result, TestStepsUploadValidation):
            validation = validation_result
        else:
            payload = (
                validation_result.model_dump()
                if hasattr(validation_result, "model_dump")
                else dict(validation_result)
            )
            payload.setdefault("filename", filename)
            validation = TestStepsUploadValidation.model_validate(payload)

        validation.filename = filename
        if validation.document_type == "not_test_steps":
            validation.is_valid = False
            validation.reason = (
                validation.reason or "The document is not a valid test-steps artifact."
            )
            return validation, extracted_text

        validation.is_valid = self._is_likely_test_steps_document(extracted_text)
        if validation.is_valid:
            validation.reason = "The document contains recognizable test-step structure and is accepted as a valid test-steps artifact."
            validation.document_type = "test_steps"
        else:
            validation.reason = "The document does not contain recognizable test-step structure or a sufficiently clear subset of the 24 fixed headings."
            validation.document_type = "not_test_steps"
        return validation, extracted_text

    @staticmethod
    def _resolve_content_type(filename: str) -> str:
        lower_name = filename.lower()
        if lower_name.endswith(".pdf"):
            return "application/pdf"
        if lower_name.endswith(".txt"):
            return "text/plain"
        if lower_name.endswith(".json"):
            return "application/json"
        if lower_name.endswith(".csv"):
            return "text/csv"
        if lower_name.endswith(".docx"):
            return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        if lower_name.endswith(".doc"):
            return "application/msword"
        if lower_name.endswith(".pptx"):
            return "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        if lower_name.endswith(".xlsx"):
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        return "application/octet-stream"

    def confirm_pending_upload(
        self,
        plan_number: str,
        validated_files: list[dict[str, str]],
        confirmed: bool = False,
    ) -> TestStepsUploadResponse:
        if not confirmed:
            raise ValueError(
                "User confirmation is required before uploading the validated test-steps documents."
            )

        review_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
            plan_number=self._safe_name(plan_number),
        )
        storage_prefix = f"{review_folder}/inbound-data/additional-context/test-steps"

        documents: list[dict[str, Any]] = []

        for payload in validated_files:
            filename = payload.get("filename")
            encoded_content = payload.get("content")
            if not filename or encoded_content is None:
                raise ValueError(
                    "Each validated file record must include a filename and content."
                )
            content = base64.b64decode(encoded_content)
            blob_path = f"{storage_prefix}/{self._safe_name(filename)}"
            gcs_uri = self.storage_manager.write_blob_bytes(
                blob_path,
                content,
                self._resolve_content_type(filename),
            )
            documents.append(
                {
                    "filename": self._safe_name(filename),
                    "document_url": gcs_uri,
                    "size_bytes": len(content),
                }
            )

        logger.info(
            "Confirmed and uploaded extra test-steps files for planNumber=%s file_count=%s storage_prefix=%s",
            plan_number,
            len(documents),
            storage_prefix,
        )

        return TestStepsUploadResponse(
            planNumber=plan_number,
            uploaded_documents=[
                {
                    "filename": item["filename"],
                    "document_url": item["document_url"],
                    "size_bytes": item["size_bytes"],
                }
                for item in documents
            ],
            storage_prefix=storage_prefix,
            upload_completed=True,
            confirmation_required=False,
        )

    async def process_upload(
        self,
        plan_number: str,
        files: list[UploadFile],
        user_details: UserRequest | None = None,
    ) -> TestStepsUploadResponse:
        if not files:
            raise ValueError("At least one test-steps supporting document is required.")

        allowed_extensions = (".pdf", ".docx", ".txt")
        unsupported = [
            document.filename or "unnamed-document"
            for document in files
            if not (document.filename or "").lower().endswith(allowed_extensions)
        ]
        if unsupported:
            raise ValueError(
                f"Unsupported file type(s): {', '.join(unsupported)}. "
                "Only .pdf, .docx and .txt files are allowed."
            )

        validation_results: list[TestStepsUploadValidation] = []
        valid_files: list[tuple[str, bytes]] = []

        for document in files:
            original_filename = document.filename or "unnamed-document"
            content = await document.read()
            validation, extracted_text = self._validate_test_steps_document(
                original_filename, content
            )
            validation_results.append(validation)

            if validation.is_valid:
                canonical_content = self._build_canonical_test_step_content(
                    original_filename,
                    extracted_text,
                )
                canonical_filename = self._safe_name(original_filename)
                if not canonical_filename.lower().endswith(".txt"):
                    canonical_filename = f"{canonical_filename}.txt"
                valid_files.append(
                    (canonical_filename, canonical_content.encode("utf-8"))
                )
                logger.info(
                    "Accepted and canonicalized test-steps uploaded document for planNumber=%s file=%s",
                    plan_number,
                    original_filename,
                )
            else:
                logger.warning(
                    "Rejected test-steps uploaded document during guardrail validation for planNumber=%s file=%s reason=%s",
                    plan_number,
                    original_filename,
                    validation.reason,
                )

        if not valid_files:
            logger.warning(
                "No valid test-steps files detected for planNumber=%s validation_results=%s",
                plan_number,
                validation_results,
            )
            return TestStepsUploadResponse(
                planNumber=plan_number,
                uploaded_documents=[],
                storage_prefix=(
                    f"{Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(plan_number=self._safe_name(plan_number))}/"
                    "inbound-data/additional-context/test-steps"
                ),
                validation_results=validation_results,
                upload_completed=False,
                confirmation_required=False,
            )

        logger.info(
            "Validated extra test-steps upload for planNumber=%s valid_file_count=%s",
            plan_number,
            len(valid_files),
        )

        return TestStepsUploadResponse(
            planNumber=plan_number,
            uploaded_documents=[],
            storage_prefix=(
                f"{Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(plan_number=self._safe_name(plan_number))}/"
                "inbound-data/additional-context/test-steps"
            ),
            validation_results=validation_results,
            upload_completed=False,
            confirmation_required=True,
            validated_files=[
                {
                    "filename": filename,
                    "content": base64.b64encode(content).decode("utf-8"),
                }
                for filename, content in valid_files
            ],
        )
