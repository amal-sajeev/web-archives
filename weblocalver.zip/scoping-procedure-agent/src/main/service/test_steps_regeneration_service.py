import hashlib
import json
import logging
from typing import Any, Dict

from config.prompts import TEST_STEPS_REGENERATION_PROMPT
from langchain_core.messages import HumanMessage
from model.response_model import TestStepsResponse
from pydantic import ValidationError
from service.inscope_outscope_service import InScopeOutScopeService
from service.test_steps_upload_service import TestStepsUploadService
from utils.document_processor import extract_text

logger = logging.getLogger(__name__)


class TestStepsRegenerationService(InScopeOutScopeService):
    """LLM-driven regeneration flow for test steps uploaded after the first generation."""

    @staticmethod
    def _parse_text_test_step_content(content: str) -> list[dict]:
        """Convert canonical uploaded .txt test-step content into one or more structured step dicts."""
        normalized = (content or "").strip()
        if not normalized:
            return []

        parsed = TestStepsUploadService._parse_uploaded_step_fields(normalized)
        populated_values = [
            value
            for value in parsed.values()
            if value is not None
            and str(value).strip() not in {"", "-", "null", "None", "N/A", "NA"}
        ]
        if not populated_values:
            logger.info(
                "No structured test-step fields detected in uploaded content during regeneration parse."
            )
            return []

        logger.info(
            "Parsed canonical uploaded test-step text into a structured step object."
        )
        return [parsed]

    def _load_existing_test_steps(self, plan_number: str) -> list[dict]:
        """Fetch the authoritative saved test steps artifact."""
        path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )
        payload = self.storage_manager.download_json(path)
        if not isinstance(payload, dict):
            logger.info(
                "No existing test-steps artifact loaded for planNumber=%s at path=%s payload_type=%s",
                plan_number,
                path,
                type(payload).__name__,
            )
            return []

        test_steps = payload.get("test_steps", [])
        if not isinstance(test_steps, list):
            logger.warning(
                "Existing test-steps artifact invalid for planNumber=%s path=%s type=%s",
                plan_number,
                path,
                type(test_steps).__name__,
            )
            return []

        logger.info(
            "Loaded existing test steps for planNumber=%s count=%s path=%s",
            plan_number,
            len(test_steps),
            path,
        )
        return test_steps

    def _load_uploaded_test_steps_context(self, plan_number: str) -> list[dict]:
        """Fetch uploaded extra test-step files from additional-context as raw blobs and decode them."""
        review_folder = self._build_review_folder_name(plan_number)
        upload_prefix = f"{review_folder}/inbound-data/additional-context/test-steps"
        blob_names = self.storage_manager.list_blobs_in_folder(upload_prefix)

        logger.info(
            "Scanning uploaded test-step context for planNumber=%s prefix=%s files_found=%s",
            plan_number,
            upload_prefix,
            len(blob_names),
        )

        uploaded_steps: list[dict] = []
        for blob_name in sorted(blob_names):
            if not blob_name.lower().endswith(
                (".txt", ".json", ".md", ".csv", ".pdf", ".docx")
            ):
                continue
            try:
                blob_bytes = self.storage_manager.download_blob_bytes(blob_name)
            except Exception:
                logger.warning(
                    "Could not read uploaded test-step file as blob for planNumber=%s file=%s",
                    plan_number,
                    blob_name,
                )
                continue

            filename = blob_name.split("/")[-1]
            lower_name = filename.lower()
            if lower_name.endswith((".txt", ".json", ".md", ".csv")):
                content = blob_bytes.decode("utf-8", errors="replace")
            else:
                content = extract_text(filename, blob_bytes)

            normalized = content.strip()
            if not normalized:
                logger.info(
                    "Uploaded test-step file empty for planNumber=%s file=%s",
                    plan_number,
                    blob_name,
                )
                continue

            uploaded_steps.append(
                {
                    "filename": filename,
                    "content": normalized,
                    "sha256": hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
                }
            )

        logger.info(
            "Completed uploaded test-step scan for planNumber=%s uploaded_count=%s",
            plan_number,
            len(uploaded_steps),
        )
        return uploaded_steps

    def _extract_uploaded_test_step_objects(
        self, uploaded_steps: list[dict]
    ) -> list[dict]:
        """Parse JSON or canonical text uploaded test-step payloads into objects when the uploaded file contains JSON objects."""
        parsed_steps: list[dict] = []
        for entry in uploaded_steps:
            content = (entry or {}).get("content", "")
            if not content:
                continue
            try:
                payload = json.loads(content)
            except Exception:
                payload = None

            if isinstance(payload, dict):
                if isinstance(payload.get("test_steps"), list):
                    parsed_steps.extend(
                        [
                            step
                            for step in payload["test_steps"]
                            if isinstance(step, dict)
                        ]
                    )
                elif payload:
                    parsed_steps.append(payload)
            elif isinstance(payload, list):
                parsed_steps.extend(
                    [step for step in payload if isinstance(step, dict)]
                )
            else:
                parsed_steps.extend(self._parse_text_test_step_content(content))

        return parsed_steps

    def _load_new_uploaded_test_steps(self, plan_number: str) -> list[dict]:
        """Uploaded files that are not already present in the saved test-steps artifact."""
        uploaded_steps = self._load_uploaded_test_steps_context(plan_number)
        if not uploaded_steps:
            return []

        existing_test_steps = self._load_existing_test_steps(plan_number)
        if not existing_test_steps:
            return uploaded_steps

        existing_step_hashes = {
            hashlib.sha256(
                json.dumps(
                    step, sort_keys=True, separators=(",", ":"), ensure_ascii=False
                ).encode("utf-8")
            ).hexdigest()
            for step in existing_test_steps
            if isinstance(step, dict)
        }

        deduped_steps: list[dict] = []
        for entry in uploaded_steps:
            parsed_objects = self._extract_uploaded_test_step_objects([entry])
            parsed_hashes = {
                hashlib.sha256(
                    json.dumps(
                        step, sort_keys=True, separators=(",", ":"), ensure_ascii=False
                    ).encode("utf-8")
                ).hexdigest()
                for step in parsed_objects
                if isinstance(step, dict)
            }
            if parsed_hashes and (parsed_hashes & existing_step_hashes):
                logger.info(
                    "Skipping uploaded test-step content already present in saved artifact for planNumber=%s file=%s",
                    plan_number,
                    entry.get("filename"),
                )
                continue
            deduped_steps.append(entry)

        logger.info(
            "Final deduped uploaded test-step count for planNumber=%s count=%s",
            plan_number,
            len(deduped_steps),
        )
        return deduped_steps

    def should_regenerate_test_steps(self, plan_number: str) -> bool:
        """Only regenerate when a saved artifact and new uploads both exist."""
        existing_test_steps = self._load_existing_test_steps(plan_number)
        uploaded_test_steps = self._load_new_uploaded_test_steps(plan_number)
        decision = bool(existing_test_steps) and bool(uploaded_test_steps)
        logger.info(
            "Regeneration decision inputs for planNumber=%s existing_count=%s uploaded_count=%s decision=%s",
            plan_number,
            len(existing_test_steps),
            len(uploaded_test_steps),
            decision,
        )
        return decision

    def mark_uploads_consumed(
        self, plan_number: str, uploaded_steps: list[dict]
    ) -> None:
        """Record that uploaded helper documents have already been folded into the regenerated output."""
        if not uploaded_steps:
            logger.info(
                "No uploaded test-step docs to mark as consumed for planNumber=%s",
                plan_number,
            )
            return

        files = [
            entry.get("filename")
            for entry in uploaded_steps
            if isinstance(entry, dict) and entry.get("filename")
        ]
        logger.info(
            "Marked uploaded test-step docs as consumed for planNumber=%s files=%s",
            plan_number,
            files,
        )

    def regenerate_test_steps(self, plan_number: str) -> Dict[str, Any]:
        """Ask the LLM to return the saved test steps unchanged followed by the new uploaded steps."""
        existing_test_steps = self._load_existing_test_steps(plan_number)
        uploaded_test_steps = self._load_new_uploaded_test_steps(plan_number)
        uploaded_step_objects = self._extract_uploaded_test_step_objects(
            uploaded_test_steps
        )

        if not existing_test_steps:
            raise ValueError(
                f"Regeneration requires an existing test-steps artifact for planNumber={plan_number}."
            )
        if not uploaded_step_objects:
            raise ValueError(
                f"Regeneration requires uploaded test-step additions for planNumber={plan_number}."
            )

        logger.info(
            "LLM_APPEND_ONLY_REGENERATION planNumber=%s existing_count=%s uploaded_additions_count=%s",
            plan_number,
            len(existing_test_steps),
            len(uploaded_step_objects),
        )

        prompt = TEST_STEPS_REGENERATION_PROMPT.format(
            plan_number=plan_number,
            existing_test_steps_count=len(existing_test_steps),
            existing_test_steps=self._serialize_review_data(existing_test_steps),
            uploaded_test_steps=self._serialize_review_data(
                [
                    {"filename": entry["filename"], "content": entry["content"]}
                    for entry in uploaded_test_steps
                ]
            ),
        )

        structured_llm = self.llm.with_structured_output(TestStepsResponse)
        messages = [HumanMessage(content=prompt)]
        for attempt in range(2):
            try:
                model_response = structured_llm.invoke(messages)
                validated_response = TestStepsResponse.model_validate(
                    model_response.model_dump(exclude_unset=True)
                )
                break
            except ValidationError:
                if attempt == 1:
                    raise
                messages.append(
                    HumanMessage(
                        content=(
                            "The previous response failed schema validation. Return the complete corrected response: "
                            "all saved test steps unchanged, followed by every uploaded test step. Every test_steps item "
                            "must include test_step, a nonblank rationale and an integer confidence_score between 0 and 100."
                        )
                    )
                )

        final_test_steps = [
            test_step.model_dump() for test_step in validated_response.test_steps
        ]

        blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )
        logger.info(
            "REGENERATION_SAVE_START planNumber=%s target_path=%s final_count=%s",
            plan_number,
            blob_path,
            len(final_test_steps),
        )
        self.storage_manager.upload_json(
            blob_path,
            {
                "planNumber": plan_number,
                "test_steps": final_test_steps,
            },
        )
        logger.info(
            "REGENERATION_SAVE_DONE planNumber=%s target_path=%s final_count=%s",
            plan_number,
            blob_path,
            len(final_test_steps),
        )

        try:
            self.mark_uploads_consumed(plan_number, uploaded_test_steps)
        except Exception:
            logger.warning(
                "Could not mark uploaded test-step documents as consumed after regeneration for planNumber=%s",
                plan_number,
                exc_info=True,
            )

        return {"test_steps": final_test_steps}
