import os
import sys
from langchain_google_genai import ChatGoogleGenerativeAI
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.config import Config


def initialize_gemini_model() -> ChatGoogleGenerativeAI:
    """
    Initializes and returns a ChatGoogleGenerativeAI instance (using LangChain).
    """
    try:
        llm = ChatGoogleGenerativeAI(
            model=Config.MODEL_NAME,
            project=Config.PROJECT_NAME,
            location=Config.PROJECT_LOCATION,
            temperature=Config.GENERATION_CONFIG["temperature"],
            top_p=Config.GENERATION_CONFIG["top_p"],
            top_k=Config.GENERATION_CONFIG.get("top_k"),
            safety_settings=Config.SAFETY_CONFIG['safety_settings'],
        )
        return llm
    except Exception as e:
        raise e
    