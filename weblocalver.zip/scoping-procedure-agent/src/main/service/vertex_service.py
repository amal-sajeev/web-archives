import os
import sys
from langchain_google_genai import ChatGoogleGenerativeAI
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.config import Config


def initialize_gemini_model(*, max_retries=None) -> ChatGoogleGenerativeAI:
    """
    Initialize Gemini through the configured Vertex project and location.
    """
    try:
        model_options = {
            "model": Config.MODEL_NAME,
            "project": Config.PROJECT_NAME,
            "location": Config.PROJECT_LOCATION,
            "temperature": Config.GENERATION_CONFIG["temperature"],
            "top_p": Config.GENERATION_CONFIG["top_p"],
            "top_k": Config.GENERATION_CONFIG.get("top_k"),
            "safety_settings": Config.SAFETY_CONFIG['safety_settings'],
        }
        if max_retries is not None:
            model_options["max_retries"] = max_retries
        llm = ChatGoogleGenerativeAI(**model_options)
        return llm
    except Exception as e:
        raise e
    
