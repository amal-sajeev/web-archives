import os
import sys
import logging
import tempfile
from typing import Any
import certifi
from langchain_google_genai import ChatGoogleGenerativeAI
from google.auth import default
import google.auth.transport.requests

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
from config.config import Config

logger = logging.getLogger(__name__)


AI_ACCESS_LAYER_BASE_URL = os.getenv(
    "AI_ACCESS_LAYER_BASE_URL"
)
_CERTIFICATE_CONFIGURED = False


def _is_local_cert_auth_enabled() -> bool:
    """
    Enables custom certificate auth only when explicitly turned on.
    Intended for local development.
    """
    raw_value = str(os.getenv("ENABLE_LOCAL_CERT_AUTH", "")).strip().lower()
    return raw_value == "true"


def _is_local_runtime() -> bool:
    """
    Treat Kubernetes runtime as non-local; everything else defaults to local.
    """
    return not bool(os.getenv("KUBERNETES_SERVICE_HOST"))


def _set_ssl_bundle_env(path: str) -> None:
    """
    Set SSL bundle environment variables without overriding pre-existing values.
    """
    os.environ.setdefault("REQUESTS_CA_BUNDLE", path)
    os.environ.setdefault("SSL_CERT_FILE", path)
    os.environ.setdefault("GRPC_DEFAULT_SSL_ROOTS_FILE_PATH", path)


def configure_certificate(custom_cert_paths: list[str]) -> str:
    """
    Combines certifi's default CA bundle with one or more custom certificates
    and sets the required environment variables.
    """
    if not custom_cert_paths:
        raise ValueError("No custom certificate paths are set")

    with open(certifi.where(), "r", encoding="utf-8") as f:
        ca_bundle = f.read()

    custom_certs: list[str] = []
    for custom_cert_path in custom_cert_paths:
        if not os.path.exists(custom_cert_path):
            raise FileNotFoundError(f"Certificate file not found: {custom_cert_path}")

        with open(custom_cert_path, "r", encoding="utf-8") as f:
            custom_cert = f.read()

        if "-----BEGIN CERTIFICATE-----" not in custom_cert:
            raise ValueError(
                f"Certificate file is not PEM format: {custom_cert_path}"
            )
        custom_certs.append(custom_cert)

    bundle_dir = os.path.dirname(custom_cert_paths[0]) or tempfile.gettempdir()
    combined_path = os.path.join(bundle_dir, "combined-ca-bundle.pem")
    try:
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)
    except OSError:
        combined_path = os.path.join(tempfile.gettempdir(), "combined-ca-bundle.pem")
        with open(combined_path, "w", encoding="utf-8") as f:
            f.write(ca_bundle)
            for custom_cert in custom_certs:
                f.write("\n")
                f.write(custom_cert)

    os.environ["REQUESTS_CA_BUNDLE"] = combined_path
    os.environ["SSL_CERT_FILE"] = combined_path
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = combined_path
    return combined_path


def _configure_certificate_once() -> None:
    global _CERTIFICATE_CONFIGURED
    if _CERTIFICATE_CONFIGURED:
        return

    if not _is_local_runtime():
        configured_path = (os.getenv("CA_BUNDLE_PATH") or "").strip()
        if configured_path:
            _set_ssl_bundle_env(configured_path)
            logger.info("Configured SSL CA bundle from CA_BUNDLE_PATH: %s", configured_path)
        else:
            logger.info("CA_BUNDLE_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    if not _is_local_cert_auth_enabled():
        logger.info("Local certificate auth is disabled; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    custom_paths = str(os.getenv("CUSTOM_CERT_PATHS") or "").strip()
    if custom_paths:
        cert_paths = [p.strip() for p in custom_paths.split(",") if p.strip()]
    else:
        legacy_path = str(os.getenv("CUSTOM_CERT_PATH") or "").strip()
        cert_paths = [legacy_path] if legacy_path else []

    if not cert_paths:
        logger.info("CUSTOM_CERT_PATH is not set; using default trust store")
        _CERTIFICATE_CONFIGURED = True
        return

    combined_path = configure_certificate(cert_paths)
    logger.info("Custom certificate bundle configured at: %s", combined_path)
    _CERTIFICATE_CONFIGURED = True


class GoogleOAuthTokenProvider:
    def __init__(self):
        self.credentials, _ = default(
            scopes=[
                "https://www.googleapis.com/auth/cloud-platform",
                "https://www.googleapis.com/auth/userinfo.email",
            ]
        )
        self.request = google.auth.transport.requests.Request()

    @property
    def token(self):
        if not self.credentials.valid:
            self.credentials.refresh(self.request)
        return self.credentials.token


class _RefreshingStructuredModel:
    """Resolve a structured model immediately before each provider request."""

    def __init__(self, client: "RefreshingVertexModel", schema: Any, **kwargs: Any):
        self._client = client
        self._schema = schema
        self._kwargs = kwargs

    def invoke(self, *args: Any, **kwargs: Any) -> Any:
        return self._client._model_for_request().with_structured_output(
            self._schema, **self._kwargs
        ).invoke(*args, **kwargs)

    async def ainvoke(self, *args: Any, **kwargs: Any) -> Any:
        return await self._client._model_for_request().with_structured_output(
            self._schema, **self._kwargs
        ).ainvoke(*args, **kwargs)


class RefreshingVertexModel:
    """Vertex client that renews the WIF access token between requests."""

    def __init__(self, provider: GoogleOAuthTokenProvider):
        self._provider = provider
        self._model: Any | None = None
        self._token: str | None = None

    def _model_for_request(self) -> Any:
        token = self._provider.token
        if self._model is None or token != self._token:
            self._model = ChatGoogleGenerativeAI(
                model=Config.MODEL_NAME,
                api_key=token,
                base_url=AI_ACCESS_LAYER_BASE_URL,
                temperature=Config.GENERATION_CONFIG["temperature"],
                top_p=Config.GENERATION_CONFIG["top_p"],
                top_k=Config.GENERATION_CONFIG.get("top_k"),
                safety_settings=Config.SAFETY_CONFIG['safety_settings'],
            )
            self._token = token
        return self._model

    def invoke(self, *args: Any, **kwargs: Any) -> Any:
        return self._model_for_request().invoke(*args, **kwargs)

    async def ainvoke(self, *args: Any, **kwargs: Any) -> Any:
        return await self._model_for_request().ainvoke(*args, **kwargs)

    def with_structured_output(self, schema: Any, **kwargs: Any) -> _RefreshingStructuredModel:
        return _RefreshingStructuredModel(self, schema, **kwargs)


def initialize_gemini_model() -> RefreshingVertexModel:
    """Return a Vertex client that refreshes WIF credentials for each request."""
    _configure_certificate_once()
    return RefreshingVertexModel(GoogleOAuthTokenProvider())
