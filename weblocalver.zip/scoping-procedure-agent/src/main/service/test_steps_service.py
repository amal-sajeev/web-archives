"""Service layer for generating test steps."""

import json
from typing import Any, Dict

from config.prompts import TEST_STEPS_PROMPT
from model.response_model import TestStep, TestStepsResponse
from langchain_core.messages import HumanMessage
from pydantic import ValidationError
from service.inscope_outscope_service import InScopeOutScopeService


class TestStepsService(InScopeOutScopeService):
    """Generates audit test steps by reusing shared review-data collection logic."""

    TEST_STEPS_RAW_SOURCES = ("dbaware", "dbgrc", "lrr", "policy")
    TEST_STEPS_RAW_FILES = {
        "dbaware": ("plan_details.json", "historical_plan_details.json"),
        "dbgrc": ("risk_driver_details.json",),
    }

    def gather_inscope_outscope_data(
        self,
        plan_number: str,
        api_name: str = "generate-test-steps",
    ) -> Dict[str, Any]:
        """Load previously generated `inscope` and `outscope` artifacts from storage."""
        inscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="inscope.json",
        )
        outscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="outscope.json",
        )

        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor() as executor:
            future_inscope = executor.submit(self.storage_manager.download_json, inscope_blob_path)
            future_outscope = executor.submit(self.storage_manager.download_json, outscope_blob_path)
            inscope_data = future_inscope.result()
            outscope_data = future_outscope.result()

        self._log_input_file_status(api_name, plan_number, inscope_blob_path, inscope_data)
        self._log_input_file_status(api_name, plan_number, outscope_blob_path, outscope_data)

        if inscope_data is None:
            raise ValueError("Missing required inscope data in bucket. Please generate inscope first.")
        if outscope_data is None:
            raise ValueError("Missing required outscope data in bucket. Please generate outscope first.")

        return {
            "inscope": inscope_data,
            "outscope": outscope_data,
        }

    def gather_all_review_data(self, plan_number: str) -> Dict[str, Any]:
        """Collect all inputs needed for test-steps generation, fetching data sources in parallel."""
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor() as executor:
            future_raw = executor.submit(
                self.gather_raw_data,
                plan_number,
                api_name="generate-test-steps",
                source_names=self.TEST_STEPS_RAW_SOURCES,
                file_names=self.TEST_STEPS_RAW_FILES,
            )
            future_preliminary = executor.submit(
                self.gather_preliminary_research_data,
                plan_number,
                api_name="generate-test-steps",
            )
            future_inscope_outscope = executor.submit(
                self.gather_inscope_outscope_data,
                plan_number,
                api_name="generate-test-steps",
            )
            raw_data = future_raw.result()
            preliminary_data = future_preliminary.result()
            inscope_outscope_data = future_inscope_outscope.result()

        return {
            "planNumber": plan_number,
            "raw_data": raw_data,
            "preliminary_research_data": preliminary_data,
            "inscope_outscope_data": inscope_outscope_data,
        }

    def _build_generation_prompt(self, plan_number: str, review_data: Dict[str, Any]) -> str:
        """Build the LLM prompt for generating test steps."""
        raw_data = review_data["raw_data"]
        return TEST_STEPS_PROMPT.format(
            plan_number=plan_number,
            dbaware_historical_plan_details=self._serialize_review_data(
                raw_data["dbaware"]["historical_plan_details.json"]
            ),
            dbaware_plan_details=self._serialize_review_data(
                raw_data["dbaware"]["plan_details.json"]
            ),
            dbgrc_risk_driver_details=self._serialize_review_data(
                raw_data["dbgrc"]["risk_driver_details.json"]
            ),
            lrr_internet_search_data=self._serialize_review_data(
                raw_data["lrr"]["internet_search_data.json"]
            ),
            policy_relevant_policy=self._serialize_review_data(
                raw_data["policy"]["relevant_policy.json"]
            ),
            policy_relevant_kod=self._serialize_review_data(
                raw_data["policy"]["relevant_kod.json"]
            ),
            policy_relevant_procedure=self._serialize_review_data(
                raw_data["policy"]["relevant_procedure.json"]
            ),
            preliminary_research_data=self._serialize_review_data(
                review_data["preliminary_research_data"]
            ),
            inscope_outscope_data=self._serialize_review_data(
                review_data["inscope_outscope_data"]
            ),
        )

    def _normalize_test_steps(self, parsed_response: Dict[str, Any]) -> list[dict]:
        """Normalize model output into a non-empty list of 24-field test step dicts."""
        test_steps = parsed_response.get("test_steps", [])

        if not isinstance(test_steps, list) or not test_steps:
            raise ValueError("Model response did not contain test_steps content.")

        return test_steps

    def generate_test_steps(self, plan_number: str):
        """Generate test steps, persist them to storage, and return the final payload."""
        review_data = self.gather_all_review_data(plan_number)
        prompt = self._build_generation_prompt(plan_number, review_data)

        structured_llm = self.llm.with_structured_output(TestStepsResponse)
        messages = [HumanMessage(content=prompt)]
        for attempt in range(2):
            try:
                model_response = structured_llm.invoke(messages)
                parsed_response = TestStepsResponse.model_validate(
                    model_response.model_dump(exclude_unset=True)
                )
                break
            except ValidationError:
                if attempt == 1:
                    raise
                messages.append(HumanMessage(content=(
                    "The previous response failed schema validation. Return the complete corrected response. "
                    "Every test_steps item must include test_step, a nonblank 2-to-3-sentence rationale "
                    "specific to that step, and an explicit integer confidence_score between 0 and 100. "
                    "Do not omit these fields or use an empty rationale."
                )))

        test_steps = [test_step.model_dump() for test_step in parsed_response.test_steps]

        if not test_steps:
            raise ValueError("Model response did not contain test_steps content.")

        test_steps_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )

        self.storage_manager.upload_json(
            test_steps_blob_path,
            {
                "planNumber": plan_number,
                "test_steps": test_steps,
            },
        )

        return {
            "test_steps": test_steps,
        }

    def update_test_steps(self, plan_number: str, test_steps: list[TestStep]) -> Dict[str, Any]:
        """Overwrite existing test-steps artifact for a plan."""
        if not isinstance(test_steps, list) or not test_steps:
            raise ValueError("test_steps must be a non-empty list.")

        test_steps_payload = [test_step.model_dump() for test_step in test_steps]

        test_steps_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )

        self.storage_manager.upload_json(
            test_steps_blob_path,
            {
                "planNumber": plan_number,
                "test_steps": test_steps_payload,
            },
        )

        return {
            "test_steps": test_steps_payload,
        }

    def get_test_steps(self, plan_number: str) -> Dict[str, list[dict]]:
        """Fetch persisted test-steps artifact for a plan."""
        test_steps_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )
        test_steps_data = self.storage_manager.download_json(test_steps_blob_path)
        if not test_steps_data:
            raise FileNotFoundError(f"Test steps file not found for planNumber={plan_number}")

        test_steps = test_steps_data.get("test_steps", [])
        if not isinstance(test_steps, list):
            raise ValueError("Invalid test_steps structure in persisted file.")

        validated_response = TestStepsResponse(
            planNumber=plan_number,
            test_steps=test_steps,
        )

        return {
            "test_steps": [test_step.model_dump() for test_step in validated_response.test_steps],
        }