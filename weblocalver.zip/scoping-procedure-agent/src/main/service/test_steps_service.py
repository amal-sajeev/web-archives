"""Service layer for generating test steps."""

import copy
import json
import logging
import re
from typing import Any, Dict

from config.prompts import (
    TEST_STEPS_PROMPT,
    TEST_STEPS_REFINEMENT_IDENTIFY_PROMPT,
    TEST_STEPS_REFINEMENT_REGENERATE_PROMPT,
)
from model.response_model import (
    RegeneratedTestStepParts,
    TestStep,
    TestStepsRefinementTargets,
    TestStepsResponse,
)
from langchain_core.messages import HumanMessage
from pydantic import ValidationError
from service.inscope_outscope_service import InScopeOutScopeService
from service.test_steps_regeneration_service import TestStepsRegenerationService

logger = logging.getLogger(__name__)  # Initialize logger


logger = logging.getLogger(__name__)

RATIONALE_PART_SUFFIX = ".RATIONALE"
TEST_STEP_NAME_FIELD = "test step name and number"


class TestStepsRefinementTargetNotFoundError(ValueError):
    """Raised when the refinement comment does not match any test step content."""


class TestStepsService(InScopeOutScopeService):
    """Generates audit test steps by reusing shared review-data collection logic."""

    TEST_STEPS_RAW_SOURCES = ("dbaware", "dbgrc", "lrr", "policy")
    TEST_STEPS_RAW_FILES = {
        "dbaware": ("plan_details.json", "historical_plan_details.json"),
        "dbgrc": ("risk_driver_details.json",),
    }


    @staticmethod
    def _extract_usage_tokens(response_obj: Any) -> dict[str, int]:
        usage = None

        if response_obj is None:
            return {"input_tokens": 0, "output_tokens": 0}

        usage = getattr(response_obj, "usage_metadata", None)
        if usage is None:
            nested_response = getattr(response_obj, "response", None)
            if nested_response is not None:
                usage = getattr(nested_response, "usage_metadata", None)

        if usage is None:
            response_metadata = getattr(response_obj, "response_metadata", None) or {}
            if isinstance(response_metadata, dict):
                usage = response_metadata.get("usage_metadata")

        if not usage:
            return {"input_tokens": 0, "output_tokens": 0}

        if isinstance(usage, dict):
            input_tokens = int(usage.get("prompt_token_count") or usage.get("input_tokens") or 0)
            output_tokens = int(usage.get("candidates_token_count") or usage.get("output_tokens") or 0)
            return {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            }

        input_tokens = int(getattr(usage, "prompt_token_count", 0) or getattr(usage, "input_tokens", 0) or 0)
        output_tokens = int(getattr(usage, "candidates_token_count", 0) or getattr(usage, "output_tokens", 0) or 0)
        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        }

    def _load_existing_test_steps(self, plan_number: str) -> list[dict]:
        """Fetch the current generated test-steps artifact if one already exists for the plan."""
        path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )
        payload = self.storage_manager.download_json(path)
        if not isinstance(payload, dict):
            return []

        test_steps = payload.get("test_steps", [])
        if not isinstance(test_steps, list):
            return []
        return test_steps

    def _load_uploaded_test_steps_context(self, plan_number: str) -> list[dict]:
        """Fetch uploaded supporting test-step docs from the plan's extra-context folder."""
        review_folder = self._build_review_folder_name(plan_number)
        upload_prefix = f"{review_folder}/inbound-data/additional-context/test-steps"
        blob_names = self.storage_manager.list_blobs_in_folder(upload_prefix)

        uploaded_steps: list[dict] = []
        for blob_name in sorted(blob_names):
            if not blob_name.lower().endswith((".txt", ".json")):
                continue
            try:
                content = self.storage_manager.download_text(blob_name)
            except Exception:
                try:
                    content = self.storage_manager.download_blob_bytes(
                        blob_name
                    ).decode("utf-8", "replace")
                except Exception:
                    continue

            normalized = content.strip()
            if not normalized:
                continue

            uploaded_steps.append(
                {
                    "filename": blob_name.split("/")[-1],
                    "content": normalized,
                }
            )

        return uploaded_steps


    def gather_inscope_outscope_data(
        self,
        plan_number: str,
        api_name: str = "generate-test-steps",
    ) -> Dict[str, Any]:
        """Load previously generated `inscope` and `outscope` artifacts from storage."""
        inscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="inscope.json",
        )
        outscope_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="outscope.json",
        )

        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor() as executor:
            future_inscope = executor.submit(
                self.storage_manager.download_json, inscope_blob_path
            )
            future_outscope = executor.submit(
                self.storage_manager.download_json, outscope_blob_path
            )
            inscope_data = future_inscope.result()
            outscope_data = future_outscope.result()

        self._log_input_file_status(
            api_name, plan_number, inscope_blob_path, inscope_data
        )
        self._log_input_file_status(
            api_name, plan_number, outscope_blob_path, outscope_data
        )

        if inscope_data is None:
            raise ValueError(
                "Missing required inscope data in bucket. Please generate inscope first."
            )
        if outscope_data is None:
            raise ValueError(
                "Missing required outscope data in bucket. Please generate outscope first."
            )

        return {
            "inscope": inscope_data,
            "outscope": outscope_data,
        }

    def gather_all_review_data(self, plan_number: str) -> Dict[str, Any]:
        """Collect all inputs needed for test-steps generation, fetching data sources in parallel."""
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor() as executor:
            future_raw = executor.submit(
                self.gather_raw_data,
                plan_number,
                api_name="generate-test-steps",
                source_names=self.TEST_STEPS_RAW_SOURCES,
                file_names=self.TEST_STEPS_RAW_FILES,
            )
            future_preliminary = executor.submit(
                self.gather_preliminary_research_data,
                plan_number,
                api_name="generate-test-steps",
            )
            future_inscope_outscope = executor.submit(
                self.gather_inscope_outscope_data,
                plan_number,
                api_name="generate-test-steps",
            )
            raw_data = future_raw.result()
            preliminary_data = future_preliminary.result()
            inscope_outscope_data = future_inscope_outscope.result()

        return {
            "planNumber": plan_number,
            "raw_data": raw_data,
            "preliminary_research_data": preliminary_data,
            "inscope_outscope_data": inscope_outscope_data,
        }

    def _build_generation_prompt(
        self, plan_number: str, review_data: Dict[str, Any]
    ) -> str:
        """Build the LLM prompt for generating test steps."""
        raw_data = review_data["raw_data"]
        existing_test_steps = self._load_existing_test_steps(plan_number)
        uploaded_test_steps = self._load_uploaded_test_steps_context(plan_number)
        return TEST_STEPS_PROMPT.format(
            plan_number=plan_number,
            dbaware_historical_plan_details=self._serialize_review_data(
                raw_data["dbaware"]["historical_plan_details.json"]
            ),
            dbaware_plan_details=self._serialize_review_data(
                raw_data["dbaware"]["plan_details.json"]
            ),
            dbgrc_risk_driver_details=self._serialize_review_data(
                raw_data["dbgrc"]["risk_driver_details.json"]
            ),
            lrr_internet_search_data=self._serialize_review_data(
                raw_data["lrr"]["internet_search_data.json"]
            ),
            policy_relevant_policy=self._serialize_review_data(
                raw_data["policy"]["relevant_policy.json"]
            ),
            policy_relevant_kod=self._serialize_review_data(
                raw_data["policy"]["relevant_kod.json"]
            ),
            policy_relevant_procedure=self._serialize_review_data(
                raw_data["policy"]["relevant_procedure.json"]
            ),
            preliminary_research_data=self._serialize_review_data(
                review_data["preliminary_research_data"]
            ),
            inscope_outscope_data=self._serialize_review_data(
                review_data["inscope_outscope_data"]
            ),
            existing_test_steps=self._serialize_review_data(
                existing_test_steps
                or "No previous generated test steps exist for this plan."
            ),
            uploaded_test_steps=self._serialize_review_data(
                uploaded_test_steps
                or "No uploaded test-step document was found for this plan."
            ),
        )

    def _normalize_test_steps(self, parsed_response: Dict[str, Any]) -> list[dict]:
        """Normalize model output into a non-empty list of 24-field test step dicts."""
        test_steps = parsed_response.get("test_steps", [])

        if not isinstance(test_steps, list) or not test_steps:
            raise ValueError("Model response did not contain test_steps content.")

        return test_steps


    def generate_test_steps(self, plan_number: str)->tuple[Dict[str, Any], Dict[str, int]]:
        """Generate test steps, persist them to storage, and return the final payload."""

        """If both saved steps and uploaded additions exist, regenerate; otherwise do normal generation."""
        regeneration_service = TestStepsRegenerationService()

        should_regenerate = regeneration_service.should_regenerate_test_steps(
            plan_number
        )

        logger.info(
            "TEST_STEPS_DECISION planNumber=%s should_regenerate=%s",
            plan_number,
            should_regenerate,
        )

        if should_regenerate:
            logger.info(
                "REGENERATION_BRANCH_ENTER planNumber=%s",
                plan_number,
            )
            result = regeneration_service.regenerate_test_steps(plan_number)
            logger.info(
                "REGENERATION_BRANCH_EXIT planNumber=%s final_count=%s",
                plan_number,
                len(result.get("test_steps", [])),
            )
            return result, {}

        logger.info(
            "NORMAL_GENERATION_BRANCH_ENTER planNumber=%s",
            plan_number,
        )
        review_data = self.gather_all_review_data(plan_number)
        logger.info(
            "NORMAL_GENERATION_REVIEW_DATA_LOADED planNumber=%s",
            plan_number,
        )
        prompt = self._build_generation_prompt(plan_number, review_data)
        logger.info(
            "NORMAL_GENERATION_PROMPT_BUILT planNumber=%s",
            plan_number,
        )

        structured_llm = self.llm.with_structured_output(TestStepsResponse, include_raw=True)
        messages = [HumanMessage(content=prompt)]
        for attempt in range(3):
            try:
                raw_result = structured_llm.invoke(messages)
                raw_response = raw_result.get("raw") if isinstance(raw_result, dict) else raw_result
                model_response = raw_result.get("parsed") if isinstance(raw_result, dict) else raw_result
                usage_metadata = self._extract_usage_tokens(raw_response)
                logger.info(f"****** generate_test_steps usage_metadata = {usage_metadata}")

                if model_response:

                    parsed_response = TestStepsResponse.model_validate(
                        model_response.model_dump(exclude_unset=True)
                    )
                    break
            except ValidationError as e:
                logger.exception(f"Exception in generae_test_steps expeion = {e}")
                if attempt == 1:
                    raise
                messages.append(
                    HumanMessage(
                        content=(
                            "The previous response failed schema validation. Return the complete corrected response. "
                            "Every test_steps item must include test_step, a nonblank 2-to-3-sentence rationale "
                            "specific to that step, and an explicit integer confidence_score between 0 and 100. "
                            "Do not omit these fields or use an empty rationale."
                        )
                    )
                )

        test_steps = [
            test_step.model_dump() for test_step in parsed_response.test_steps
        ]

        if not test_steps:
            raise ValueError("Model response did not contain test_steps content.")

        test_steps_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )

        self.storage_manager.upload_json(
            test_steps_blob_path,
            {
                "planNumber": plan_number,
                "test_steps": test_steps,
            },
        )
        logger.info(
            "NORMAL_GENERATION_PERSISTED planNumber=%s saved_count=%s path=%s",
            plan_number,
            len(test_steps),
            test_steps_blob_path,
        )

        return {
            "test_steps": test_steps,
        }, usage_metadata

    def refine_test_steps(
        self, plan_number: str, test_steps: list[TestStep], comment: str
    ) -> Dict[str, Any]:
        """Apply an exclusion to the supplied test steps without saving it."""
        steps = [step.model_dump() for step in test_steps]
        parts = self._build_refinement_parts(steps)
        affected_part_ids = self._identify_refinement_targets(
            plan_number, comment, parts
        )
        regenerated_values = self._regenerate_refinement_parts(
            plan_number, comment, steps, parts, affected_part_ids
        )
        refined_steps = self._apply_refined_parts(steps, parts, regenerated_values)
        logger.info(
            "REFINE_TEST_STEPS_COMPLETE planNumber=%s affected_parts=%s steps_before=%s steps_after=%s",
            plan_number,
            affected_part_ids,
            len(steps),
            len(refined_steps),
        )
        validated_response = TestStepsResponse(
            planNumber=plan_number, test_steps=refined_steps
        )
        return {
            "test_steps": [step.model_dump() for step in validated_response.test_steps],
        }

    @staticmethod
    def _build_refinement_parts(steps: list[dict]) -> Dict[str, Dict[str, Any]]:
        """Split test steps into addressable parts: each non-empty field and each rationale."""
        parts: Dict[str, Dict[str, Any]] = {}
        for step_number, step in enumerate(steps, start=1):
            for field_number, (field, value) in enumerate(
                step["test_step"].items(), start=1
            ):
                if isinstance(value, str) and value.strip():
                    part_id = f"S{step_number}.F{field_number}"
                    parts[part_id] = {
                        "part_id": part_id,
                        "test_step": step_number,
                        "field": field,
                        "value": value,
                    }
            part_id = f"S{step_number}{RATIONALE_PART_SUFFIX}"
            parts[part_id] = {
                "part_id": part_id,
                "test_step": step_number,
                "field": "rationale",
                "value": step["rationale"],
            }
        return parts

    def _identify_refinement_targets(
        self, plan_number: str, comment: str, parts: Dict[str, Dict[str, Any]]
    ) -> list[str]:
        prompt = TEST_STEPS_REFINEMENT_IDENTIFY_PROMPT.format(
            plan_number=plan_number,
            comment=json.dumps(comment, ensure_ascii=False),
            parts=json.dumps(list(parts.values()), ensure_ascii=False, indent=1),
        )
        response = self.llm.with_structured_output(TestStepsRefinementTargets).invoke(
            [HumanMessage(content=prompt)]
        )
        returned_ids = list(dict.fromkeys(response.affected_part_ids))
        unknown_ids = [part_id for part_id in returned_ids if part_id not in parts]
        if unknown_ids:
            logger.warning(
                "REFINE_TEST_STEPS_UNKNOWN_PARTS planNumber=%s part_ids=%s",
                plan_number,
                unknown_ids,
            )
        affected_part_ids = [part_id for part_id in returned_ids if part_id in parts]
        if not affected_part_ids:
            raise TestStepsRefinementTargetNotFoundError(
                "Could not identify the content to remove from the test steps. Please name the test step, "
                "document, section or text clearly, as it appears in the test steps."
            )
        return affected_part_ids

    def _regenerate_refinement_parts(
        self,
        plan_number: str,
        comment: str,
        steps: list[dict],
        parts: Dict[str, Dict[str, Any]],
        affected_part_ids: list[str],
    ) -> Dict[str, str | None]:
        affected_step_numbers = sorted(
            {parts[part_id]["test_step"] for part_id in affected_part_ids}
        )
        context_steps = [
            {"test_step_number": step_number, **steps[step_number - 1]}
            for step_number in affected_step_numbers
        ]
        prompt = TEST_STEPS_REFINEMENT_REGENERATE_PROMPT.format(
            plan_number=plan_number,
            comment=json.dumps(comment, ensure_ascii=False),
            context_steps=json.dumps(context_steps, ensure_ascii=False, indent=1),
            parts=json.dumps(
                [parts[part_id] for part_id in affected_part_ids],
                ensure_ascii=False,
                indent=1,
            ),
        )
        structured_llm = self.llm.with_structured_output(RegeneratedTestStepParts)
        messages = [HumanMessage(content=prompt)]
        for attempt in range(2):
            response = structured_llm.invoke(messages)
            values = {
                part.part_id: part.value
                for part in response.parts
                if part.part_id in parts and part.part_id in affected_part_ids
            }
            problems = []
            missing_ids = [
                part_id for part_id in affected_part_ids if part_id not in values
            ]
            if missing_ids:
                problems.append(f"missing part_id values: {missing_ids}")
            # Only removal is allowed in fields, so a longer value means content was added.
            grown_ids = [
                part_id
                for part_id, value in values.items()
                if not part_id.endswith(RATIONALE_PART_SUFFIX)
                and value is not None
                and len(value.strip()) > len(parts[part_id]["value"].strip())
            ]
            if grown_ids:
                problems.append(
                    f"parts longer than their original value although content may only be removed: {grown_ids}"
                )
            if not problems:
                return values
            logger.warning(
                "REFINE_TEST_STEPS_INVALID_REGENERATION planNumber=%s attempt=%s problems=%s",
                plan_number,
                attempt + 1,
                problems,
            )
            if attempt == 1:
                raise ValueError(
                    "Regenerated test step parts failed validation: "
                    + "; ".join(problems)
                )
            messages.append(
                HumanMessage(
                    content=(
                        "The previous response was invalid: "
                        + "; ".join(problems)
                        + ". Return the complete corrected response with one entry for every listed part_id, "
                        "removing content only and keeping all remaining text exactly as it is."
                    )
                )
            )
        raise ValueError("Regenerated test step parts failed validation.")

    @staticmethod
    def _apply_refined_parts(
        steps: list[dict],
        parts: Dict[str, Dict[str, Any]],
        regenerated_values: Dict[str, str | None],
    ) -> list[dict]:
        """Insert regenerated parts into a copy of the steps, then drop steps whose fields were all removed."""
        refined_steps = copy.deepcopy(steps)
        cleared_step_numbers = set()
        for part_id, value in regenerated_values.items():
            step_number = parts[part_id]["test_step"]
            step = refined_steps[step_number - 1]
            if part_id.endswith(RATIONALE_PART_SUFFIX):
                # A blank rationale is only valid for a removed step; otherwise keep the original.
                if value and value.strip():
                    step["rationale"] = value.strip()
            elif value is None:
                step["test_step"][parts[part_id]["field"]] = None
                cleared_step_numbers.add(step_number)
            elif not value.strip():
                step["test_step"].pop(parts[part_id]["field"], None)
            else:
                step["test_step"][parts[part_id]["field"]] = value

        affected_step_numbers = {
            parts[part_id]["test_step"] for part_id in regenerated_values
        }
        kept_steps = [
            step
            for step_number, step in enumerate(refined_steps, start=1)
            if step_number not in affected_step_numbers
            or step_number in cleared_step_numbers
            or any(
                value is not None and (not isinstance(value, str) or value.strip())
                for value in step["test_step"].values()
            )
        ]
        if len(kept_steps) < len(refined_steps):
            for step_number, step in enumerate(kept_steps, start=1):
                for field, value in step["test_step"].items():
                    if field.strip().lower() == TEST_STEP_NAME_FIELD and isinstance(
                        value, str
                    ):
                        step["test_step"][field] = re.sub(
                            r"^(\s*test step\s*)\d+",
                            rf"\g<1>{step_number}",
                            value,
                            count=1,
                            flags=re.IGNORECASE,
                        )
        return kept_steps

    def update_test_steps(
        self, plan_number: str, test_steps: list[TestStep]
    ) -> Dict[str, Any]:
        """Overwrite existing test-steps artifact for a plan."""
        if not isinstance(test_steps, list) or not test_steps:
            raise ValueError("test_steps must be a non-empty list.")

        test_steps_payload = [test_step.model_dump() for test_step in test_steps]

        test_steps_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )

        self.storage_manager.upload_json(
            test_steps_blob_path,
            {
                "planNumber": plan_number,
                "test_steps": test_steps_payload,
            },
        )

        return {
            "test_steps": test_steps_payload,
        }

    def get_test_steps(self, plan_number: str) -> Dict[str, list[dict]]:
        """Fetch persisted test-steps artifact for a plan."""
        test_steps_blob_path = self._build_procedure_output_blob_path(
            plan_number=plan_number,
            file_name="test-steps.json",
        )
        test_steps_data = self.storage_manager.download_json(test_steps_blob_path)
        if not test_steps_data:
            raise FileNotFoundError(
                f"Test steps file not found for planNumber={plan_number}"
            )

        test_steps = test_steps_data.get("test_steps", [])
        if not isinstance(test_steps, list):
            raise ValueError("Invalid test_steps structure in persisted file.")

        validated_response = TestStepsResponse(
            planNumber=plan_number,
            test_steps=test_steps,
        )

        return {
            "test_steps": [
                test_step.model_dump() for test_step in validated_response.test_steps
            ],
        }
