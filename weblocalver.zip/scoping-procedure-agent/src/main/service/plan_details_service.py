"""Service layer for fetching plan-details artifacts from storage."""

import re
from typing import Any

from config.config import Config
from utils.storage_manager import StorageManager


def _build_testing_approach_rows(test_steps: list[dict[str, Any]] | None) -> list[tuple[str, str]]:
    """Convert persisted test-step payload into key/value rows for Section B table."""
    def normalize_key_label(key_name: Any) -> str:
        key_text = "" if key_name is None else str(key_name).strip()
        key_text = re.sub(r"^\s*\d+\s*[.)-:]\s*", "", key_text)
        normalized_key = re.sub(r"\s+", " ", key_text).strip().lower().rstrip(":")
        if "planned" in normalized_key and "publication" in normalized_key:
            return "Planned Publication Date"
        return key_text

    rows: list[tuple[str, str]] = []
    for step in test_steps or []:
        step_payload = step.get("test_step") if isinstance(step, dict) else None
        if not isinstance(step_payload, dict):
            continue
        for key_name, value in step_payload.items():
            if isinstance(value, (list, tuple)):
                value_text = "\n".join(str(item) for item in value)
            else:
                value_text = "" if value is None else str(value)
            rows.append((normalize_key_label(key_name), value_text))
    return rows


def _extract_plan_name(plan_details: dict[str, Any] | None) -> str | None:
    """Best-effort extraction of plan name from plan-details payload."""
    if not isinstance(plan_details, dict):
        return None

    candidate_keys = (
        "plan_name",
        "planName",
        "name",
        "plan_title",
        "planTitle",
    )

    for key_name in candidate_keys:
        candidate_value = plan_details.get(key_name)
        if isinstance(candidate_value, str) and candidate_value.strip():
            return candidate_value.strip()

    nested_candidates = (
        plan_details.get("plan_details"),
        plan_details.get("planDetails"),
        plan_details.get("plan"),
    )
    for nested in nested_candidates:
        if not isinstance(nested, dict):
            continue
        for key_name in candidate_keys:
            candidate_value = nested.get(key_name)
            if isinstance(candidate_value, str) and candidate_value.strip():
                return candidate_value.strip()

    return None


def _normalize_plan_details_payload(plan_details: dict[str, Any] | list[Any] | None) -> dict[str, Any]:
    """Normalize plan-details payload to a single dictionary record."""
    if isinstance(plan_details, list):
        for entry in plan_details:
            if isinstance(entry, dict):
                return entry
        return {}

    if not isinstance(plan_details, dict):
        return {}

    for nested_key in ("current_data", "plan_details", "planDetails", "plan"):
        nested = plan_details.get(nested_key)
        if isinstance(nested, dict):
            return nested

    return plan_details


def _stringify_plan_detail_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (list, tuple, set)):
        rendered_items = [_stringify_plan_detail_value(item) for item in value]
        rendered_items = [item for item in rendered_items if item]
        return "; ".join(rendered_items)
    if isinstance(value, dict):
        rendered_items = []
        for key_name, item_value in value.items():
            item_text = _stringify_plan_detail_value(item_value)
            if item_text:
                rendered_items.append(f"{key_name}: {item_text}")
        return "; ".join(rendered_items)
    return str(value).strip()


def _first_non_empty_plan_detail_value(source: dict[str, Any], aliases: tuple[str, ...]) -> str:
    for key_name in aliases:
        if key_name not in source:
            continue
        value_text = _stringify_plan_detail_value(source.get(key_name))
        if value_text:
            return value_text
    return ""


def _build_coverage_period_value(source: dict[str, Any]) -> str:
    start_value = _first_non_empty_plan_detail_value(
        source,
        (
            "Review Coverage Period Start Date",
            "review_coverage_period_start_date",
            "coverage_period_start_date",
        ),
    )
    end_value = _first_non_empty_plan_detail_value(
        source,
        (
            "Review Coverage Period End Date",
            "review_coverage_period_end_date",
            "coverage_period_end_date",
        ),
    )

    if start_value and end_value:
        return f"{start_value} - {end_value}"
    if start_value:
        return start_value
    if end_value:
        return end_value

    return _first_non_empty_plan_detail_value(source, ("Coverage Period", "coverage_period"))


def _build_assessment_units_value(source: dict[str, Any]) -> str:
    aggregation_values: list[str] = []
    seen_values: set[str] = set()

    for key_name, raw_value in source.items():
        key_text = str(key_name).strip().lower()
        if not key_text.startswith("au aggregation point"):
            continue

        value_text = _stringify_plan_detail_value(raw_value)
        if not value_text or value_text in seen_values:
            continue

        seen_values.add(value_text)
        aggregation_values.append(value_text)

    if aggregation_values:
        return ", ".join(aggregation_values)

    return _first_non_empty_plan_detail_value(
        source,
        ("Assessment Units", "Assessment Unit(s)", "Assessment Unit", "assessment_units"),
    )


def _build_plan_details_rows(
    plan_details: dict[str, Any] | list[Any] | None,
    default_system_id: str | None = None,
) -> list[tuple[str, str]]:
    """Build key/value rows for grey plan-details section from plan_details.json."""
    source = _normalize_plan_details_payload(plan_details)

    title_value = _first_non_empty_plan_detail_value(
        source,
        ("Plan Item Title", "Plan item Title", "planName", "plan_name", "name"),
    )
    system_id_value = _first_non_empty_plan_detail_value(
        source,
        ("Plan Item Number", "Plan Number", "System ID", "system_id", "planNumber"),
    )
    if not system_id_value and default_system_id:
        system_id_value = str(default_system_id).strip()
    combined_title = title_value
    if title_value and system_id_value and system_id_value not in title_value:
        combined_title = f"{title_value} ({system_id_value})"
    elif not combined_title:
        combined_title = system_id_value

    row_specs: list[tuple[str, tuple[str, ...]]] = [
        ("Plan Item Type", ("Plan Item Type", "plan_item_type")),
        ("Plan item Title (incl system ID)", ("Plan Item Title (incl system ID)", "Plan item Title (incl system ID)")),
        ("Coverage Period", ("Coverage Period", "coverage_period")),
        (
            "Planned Publication Date",
            (
                "Report Publication Current Target Start Date",
                "report_publication_current_target_start_date",
                "Planned Publication Date",
                "Planned Publication",
                "planned_publication_date",
                "planned_publication",
            ),
        ),
        ("Assessment Units", ("Assessment Units", "Assessment Unit(s)", "Assessment Unit", "assessment_units")),
        ("Legal Entity(ies)", ("Legal Entity(ies)", "UoT LE", "Legal Entities", "legal_entities")),
        ("Geographical Coverage", ("Geographical Coverage", "UoT Countries", "Countries", "countries")),
        ("Core Processes", ("Core Processes", "UoT Core Process", "core_processes")),
        ("Other Elements", ("Other Elements", "other_elements")),
        ("DMA relevant", ("DMA relevant", "DMA Relevant", "dma_relevant")),
        ("Risk Type Head", ("Risk Type Head", "UoT Risk Type", "risk_type")),
        ("Execution Approach", ("Execution Approach", "execution_approach", "Mode of Execution")),
        ("Review Owner", ("Review Owner", "Review Lead", "review_owner")),
        ("Team Lead", ("Team Lead", "Coordinating Team Lead", "team_lead")),
        ("Participating Team Lead", ("Participating Team Lead", "participating_team_lead")),
        ("Team Member(s)", ("Team Member(s)", "Team Members", "team_members")),
        ("CT&A Regional/Functional Head", ("CT&A Regional/Functional Head", "Lead Regional/Functional Head", "CTA Regional/Functional Head", "cta_regional_functional_head")),
        ("FINRA CRD #", ("FINRA CRD #", "FINRA CRD#", "finra_crd")),
        ("Prepared by", ("Prepared by", "prepared_by")),
    ]

    rows: list[tuple[str, str]] = []
    for label, aliases in row_specs:
        if label == "Plan item Title (incl system ID)":
            rows.append((label, combined_title or "-"))
            continue

        if label == "Coverage Period":
            coverage_period = _build_coverage_period_value(source)
            rows.append((label, coverage_period or "-"))
            continue

        if label == "Assessment Units":
            assessment_units = _build_assessment_units_value(source)
            rows.append((label, assessment_units or "-"))
            continue

        if label == "Core Processes":
            core_processes = _first_non_empty_plan_detail_value(source, aliases)
            rows.append((label, core_processes or "NA"))
            continue

        if label == "Prepared by":
            rows.append((label, "HITL"))
            continue

        value_text = _first_non_empty_plan_detail_value(source, aliases)
        rows.append((label, value_text or "-"))

    return rows


class PlanDetailsService:
    """Loads plan-details JSON from inbound dbaware data."""

    def __init__(self):
        self.storage_manager = StorageManager(
            project_name=Config.PROJECT_NAME,
            bucket_name=Config.REVIEW_BUCKET_NAME or Config.BUCKET_NAME,
        )

    def _build_review_folder_name(self, plan_number: str) -> str:
        return Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(plan_number=plan_number)

    def _build_plan_details_blob_path(self, plan_number: str) -> str:
        review_folder = self._build_review_folder_name(plan_number)
        return f"{review_folder}/inbound-data/dbaware/plan_details.json"

    def get_plan_details(self, plan_number: str) -> dict[str, Any]:
        """Fetch persisted plan details for a plan number."""
        plan_details_blob_path = self._build_plan_details_blob_path(plan_number)
        plan_details_data = self.storage_manager.download_json(plan_details_blob_path)

        if not plan_details_data:
            raise FileNotFoundError(f"Plan details file not found for planNumber={plan_number}")

        return plan_details_data
