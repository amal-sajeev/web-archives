from __future__ import annotations

import html
import importlib
import io
import re
import textwrap
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any


SCOPING_DOCUMENT_BODY_FONT_SIZE = 8
SCOPING_DOCUMENT_BRAND_FONT_SIZE = 8.5
SCOPING_DOCUMENT_LINE_HEIGHT = 4.1
SCOPING_DOCUMENT_HEADING_LINE_HEIGHT = 4.6


def _sanitize(value: Any) -> str:
	"""Make arbitrary report values safe for the default FPDF font."""
	text = "" if value is None else str(value)
	replacements = {
		"\u2013": "-",
		"\u2014": "-",
		"\u2212": "-",
		"\u2018": "'",
		"\u2019": "'",
		"\u201c": '"',
		"\u201d": '"',
		"\u2026": "...",
		"\u2022": "-",
		"\u00a0": " ",
	}
	for source, replacement in replacements.items():
		text = text.replace(source, replacement)
	return text.encode("latin-1", "replace").decode("latin-1")


def _escape(value: Any) -> str:
	return html.escape(_sanitize(value))


def _markdown_safe(text: str) -> str:
	"""Keep only **bold** as markup; stop fpdf2 treating '--' / '__' in data as italic / underline."""
	return text.replace("--", "- -").replace("__", "_ _")


def _paragraphs(value: Any) -> str:
	text = _escape(value).strip()
	if not text:
		return ""
	return "".join(
		f"<p>{paragraph.replace(chr(10), '<br>')}</p>"
		for paragraph in text.split("\n\n")
		if paragraph.strip()
	)


def _render_pdf(title: str, plan_number: str | int | None, plan_name: str | None, body: str) -> bytes:
	try:
		fpdf_module = importlib.import_module("fpdf")
	except ModuleNotFoundError as exc:
		raise RuntimeError("PDF generation dependency missing. Install 'fpdf2'.") from exc

	pdf = fpdf_module.FPDF()
	pdf.set_auto_page_break(auto=True, margin=15)
	pdf.set_title(_sanitize(title))
	pdf.add_page()

	header = f"<h1>{_escape(title)}</h1>"
	if plan_number:
		header += f"<p><b>Plan Number:</b> {_escape(plan_number)}</p>"
	if plan_name:
		header += f"<p><b>Plan Name:</b> {_escape(plan_name)}</p>"

	pdf.write_html(header + body)
	return bytes(pdf.output())


def _render_simple_report_pdf(
	title: str,
	plan_number: str | int,
	lines: Sequence[tuple[str, str]],
	spacing_after: int = 3,
	underline_headings: bool = False,
	bold_headings: Sequence[str] = (),
	space_indent_mm: float | None = None,
) -> bytes:
	"""Render the plain-text report layout used by the Streamlit exports."""
	try:
		fpdf_module = importlib.import_module("fpdf")
	except ModuleNotFoundError as exc:
		raise RuntimeError("PDF generation dependency missing. Install 'fpdf2'.") from exc

	pdf = fpdf_module.FPDF()
	pdf.set_auto_page_break(auto=True, margin=15)
	pdf.set_title(_sanitize(title))
	pdf.add_page()

	pdf.set_font("Helvetica", "B", 16)
	pdf.set_text_color(0, 82, 145)
	pdf.cell(0, 10, text=_sanitize(title), new_x="LMARGIN", new_y="NEXT")
	pdf.set_font("Helvetica", "", 10)
	pdf.set_text_color(80, 80, 80)
	pdf.cell(0, 7, text=f"Plan ID: {_sanitize(plan_number)}", new_x="LMARGIN", new_y="NEXT")
	pdf.ln(4)

	def write_wrapped(text: str, line_height: int = 5, markdown: bool = False) -> None:
		for source_line in _sanitize(text).splitlines() or [""]:
			leading_spaces = len(source_line) - len(source_line.lstrip(" "))
			source_line = source_line.lstrip(" ")
			indent_level = leading_spaces // 4
			line_x = pdf.l_margin + (indent_level * 8)
			if space_indent_mm is not None:
				line_x = pdf.l_margin + (leading_spaces * space_indent_mm)
			line_width = pdf.w - pdf.r_margin - line_x
			if markdown:
				# Wrapping is left to multi_cell so **bold** spans stay intact across wrapped lines.
				if not source_line.strip():
					pdf.ln(line_height)
					continue
				pdf.set_x(line_x)
				pdf.multi_cell(
					line_width,
					line_height,
					text=_markdown_safe(source_line),
					new_x="LMARGIN",
					new_y="NEXT",
					markdown=True,
				)
				continue
			wrapped_lines = pdf.multi_cell(
				line_width,
				line_height,
				text=source_line,
				dry_run=True,
				output="LINES",
			) or [""]
			for line in wrapped_lines:
				pdf.set_x(line_x)
				pdf.multi_cell(
					line_width,
					line_height,
					text=line,
					new_x="LMARGIN",
					new_y="NEXT",
				)

	for heading, content in lines:
		is_section_heading = heading[:1].isdigit() or heading in bold_headings
		is_rationale_heading = "rationale" in heading.lower()
		font_style = ("B" if is_section_heading or is_rationale_heading else "")
		if is_rationale_heading or underline_headings:
			font_style += "U"
		pdf.set_font("Helvetica", font_style, 10)
		pdf.set_text_color(0, 0, 0)
		write_wrapped(heading, line_height=6)
		pdf.set_font("Helvetica", "", 10)
		if content:
			write_wrapped(content, markdown=True)
		pdf.ln(spacing_after)

	return bytes(pdf.output())


def _render_scope_document_pdf(
	inscope: str,
	outscope: str,
	plan_number: str | int | None,
	testing_approach_rows: Sequence[tuple[str, str]] | None = None,
	plan_details_rows: Sequence[tuple[str, str]] | None = None,
	plan_name: str | None = None,
) -> bytes:
	"""Render scope recommendation PDF with gray section headers and boxed content."""
	try:
		fpdf_module = importlib.import_module("fpdf")
	except ModuleNotFoundError as exc:
		raise RuntimeError("PDF generation dependency missing. Install 'fpdf2'.") from exc

	class ScopedRecommendationPDF(fpdf_module.FPDF):
		def header(self) -> None:
			page_width = self.w - self.l_margin - self.r_margin
			top_y = 7.0
			text_x = self.l_margin + 1.0
			logo_size = 10.0
			logo_x = self.w - self.r_margin - logo_size
			logo_y = 6.0

			self.set_y(top_y)
			self.set_text_color(20, 36, 142)
			self.set_font("Helvetica", "", SCOPING_DOCUMENT_BRAND_FONT_SIZE)
			self.set_x(text_x)
			self.cell(page_width - logo_size - 6, 5.0, text="Deutsche Bank", new_x="LMARGIN", new_y="NEXT")

			self.set_text_color(0, 151, 230)
			self.set_font("Helvetica", "", SCOPING_DOCUMENT_BRAND_FONT_SIZE)
			self.set_x(text_x)
			self.cell(page_width - logo_size - 6, 5.0, text="Controls Testing & Assurance", new_x="LMARGIN", new_y="NEXT")

			base_dir = Path(__file__).resolve().parent.parent
			logo_candidates = [
				base_dir / "assets" / "DB-Logo-sRGB.svg",
				base_dir / "DB-Logo-sRGB.svg",
			]
			logo_path = next((path for path in logo_candidates if path.exists()), None)
			if logo_path:
				try:
					self.image(str(logo_path), x=logo_x, y=logo_y, w=logo_size, h=logo_size)
				except Exception:
					pass

			self.set_y(top_y + 12.5)
			self.ln(2)

		def footer(self) -> None:
			first_line_y = self.h - 12
			usable_width = self.w - self.l_margin - self.r_margin
			left_reserved = 78
			right_reserved = 34
			middle_x = self.l_margin + left_reserved
			middle_width = max(20.0, usable_width - left_reserved - right_reserved)
			self.set_text_color(90, 90, 90)

			self.set_y(first_line_y)
			self.set_font("Helvetica", "", 8)
			self.cell(0, 4, text="Deutsche Bank | Controls Testing & Assurance", new_x="LMARGIN", new_y="TOP")

			self.set_y(first_line_y)
			self.set_x(middle_x)
			self.set_font("Helvetica", "", 8)
			self.cell(
				middle_width,
				4,
				text="This document is confidential and should not be distributed without the express permission of the CT&A Testing Team",
				align="C",
			)

			self.set_y(first_line_y)
			self.set_x(-40)
			self.set_font("Helvetica", "", 8)
			self.cell(32, 4, text=f"Page {self.page_no()}", align="R")

			self.set_y(first_line_y + 3.8)
			self.set_x(middle_x)
			self.set_font("Helvetica", "B", 8)
			self.cell(middle_width, 4, text="For internal use only", align="C")

	pdf = ScopedRecommendationPDF(orientation="L", format="letter")
	pdf.set_margins(left=8, top=19, right=8)
	pdf.set_auto_page_break(auto=True, margin=18)
	pdf.set_title("Scope Recommendation")
	pdf.add_page()

	page_width = pdf.w - pdf.l_margin - pdf.r_margin
	left_col_width = page_width * 0.40
	right_col_width = page_width - left_col_width

	section_header_bg = (214, 214, 214)
	plan_key_bg = (216, 216, 216)
	testing_key_bg = (235, 235, 235)
	grid_border = (120, 120, 120)

	def normalize_display_key(key_name: str) -> str:
		normalized = _sanitize(key_name).strip()
		normalized = re.sub(r"^\s*\d+\s*[.)-:]\s*", "", normalized)
		normalized_compact = re.sub(r"\s+", " ", normalized).lower().rstrip(":")
		if "planned" in normalized_compact and "publication" in normalized_compact:
			return "Planned Publication Date"
		return normalized

	def draw_section_header(title: str) -> None:
		if not title:
			return
		pdf.set_draw_color(*grid_border)
		pdf.set_fill_color(*section_header_bg)
		pdf.set_text_color(0, 0, 0)
		pdf.set_font("Helvetica", "B", SCOPING_DOCUMENT_BODY_FONT_SIZE)
		pdf.cell(page_width, 6.0, text=title, border=1, fill=True, new_x="LMARGIN", new_y="NEXT")

	def draw_block_title(title: str) -> None:
		ensure_page_space(10)
		pdf.set_font("Helvetica", "B", SCOPING_DOCUMENT_BODY_FONT_SIZE)
		pdf.set_text_color(0, 0, 0)
		pdf.cell(page_width, 5.8, text=title, new_x="LMARGIN", new_y="NEXT")
		pdf.ln(0.8)

	def normalized_lines(
		text: str,
		width: float,
		line_height: float = SCOPING_DOCUMENT_LINE_HEIGHT,
		empty_placeholder: str = "-",
	) -> list[str]:
		text_value = _sanitize(text).strip() or empty_placeholder
		result: list[str] = []
		for source_line in text_value.splitlines() or [empty_placeholder]:
			if not source_line.strip():
				result.append("")
				continue
			wrapped = pdf.multi_cell(
				width,
				line_height,
				text=source_line,
				dry_run=True,
				output="LINES",
			)
			result.extend(wrapped or [""])
		return result or ["-"]

	def ensure_page_space(min_height: float) -> None:
		if pdf.get_y() + min_height <= pdf.h - pdf.b_margin:
			return
		pdf.add_page()

	def draw_wrapped_lines(x: float, y: float, width: float, lines: Sequence[str], line_height: float) -> None:
		# Lines are already wrapped by normalized_lines; cell() avoids a second line-break pass.
		pdf.set_xy(x, y)
		for line in lines:
			pdf.cell(width, line_height, text=line, new_x="LEFT", new_y="NEXT")

	def build_section_lines(
		content: str,
		width: float,
		line_height: float = SCOPING_DOCUMENT_LINE_HEIGHT,
	) -> list[tuple[str, float, int]]:
		"""Split content into (text, indent_mm, wrapped_line_count), keeping line breaks, indentation and **bold** keys."""
		clean_content = textwrap.dedent(_sanitize(content).replace("\r\n", "\n")).strip("\n")
		if not clean_content.strip():
			return [("-", 0.0, 1)]

		items: list[tuple[str, float, int]] = []
		for raw_line in clean_content.split("\n"):
			if not raw_line.strip():
				if items and items[-1][0]:
					items.append(("", 0.0, 1))
				continue
			indent_mm = (len(raw_line) - len(raw_line.lstrip(" "))) // 4 * 6.0
			text = _markdown_safe(raw_line.strip())
			wrapped = pdf.multi_cell(
				max(10.0, width - indent_mm),
				line_height,
				text=text,
				dry_run=True,
				output="LINES",
				markdown=True,
			)
			items.append((text, indent_mm, max(1, len(wrapped or []))))

		while items and not items[-1][0]:
			items.pop()
		return items or [("-", 0.0, 1)]

	def write_section(
		title: str,
		content: str,
		text_align: str = "J",
		horizontal_padding: float = 1.2,
	) -> None:
		line_height = SCOPING_DOCUMENT_LINE_HEIGHT
		content_width = max(20.0, page_width - (horizontal_padding * 2))
		pdf.set_font("Helvetica", "", SCOPING_DOCUMENT_BODY_FONT_SIZE)
		remaining_items = build_section_lines(content, content_width, line_height)
		header_drawn = False

		while remaining_items:
			ensure_page_space(20)
			if not header_drawn:
				draw_section_header(title)
				header_drawn = True

			available_height = max(8.0, (pdf.h - pdf.b_margin) - pdf.get_y())
			max_lines = max(1, int((available_height - 2.4) // line_height))

			chunk_items: list[tuple[str, float, int]] = []
			used_lines = 0
			for item in remaining_items:
				if chunk_items and used_lines + item[2] > max_lines:
					break
				chunk_items.append(item)
				used_lines += item[2]
			remaining_items = remaining_items[len(chunk_items):]

			row_height = max(6.2, line_height * max(used_lines, 1) + 1.0)
			start_x = pdf.get_x()
			start_y = pdf.get_y()

			pdf.set_draw_color(*grid_border)
			pdf.rect(start_x, start_y, page_width, row_height)
			pdf.set_font("Helvetica", "", SCOPING_DOCUMENT_BODY_FONT_SIZE)
			pdf.set_text_color(0, 0, 0)

			cursor_y = start_y + 0.5
			for text, indent_mm, line_count in chunk_items:
				if text:
					pdf.set_xy(start_x + horizontal_padding + indent_mm, cursor_y)
					pdf.multi_cell(
						max(10.0, content_width - indent_mm),
						line_height,
						text=text,
						border=0,
						align="L" if indent_mm else text_align,
						markdown=True,
					)
				cursor_y += line_count * line_height
			pdf.set_xy(start_x, start_y + row_height)

			if remaining_items:
				pdf.add_page()
			else:
				pdf.ln(3)

	def write_key_value_table(
		title: str,
		rows: Sequence[tuple[str, str]],
		empty_message: str,
		key_fill_color: tuple[int, int, int] | None = None,
	) -> None:
		ensure_page_space(26)
		draw_section_header(title)

		pdf.set_font("Helvetica", "", SCOPING_DOCUMENT_BODY_FONT_SIZE)
		pdf.set_text_color(0, 0, 0)
		normalized_rows = rows or [("-", empty_message)]
		line_height = SCOPING_DOCUMENT_LINE_HEIGHT

		for key_name, value in normalized_rows:
			row_key = normalize_display_key(str(key_name)) or "-"
			row_value = _sanitize(value).strip() or "-"

			key_lines = normalized_lines(row_key, left_col_width - 2)
			value_lines = normalized_lines(row_value, right_col_width - 2)

			remaining_key_lines = key_lines[:]
			remaining_value_lines = value_lines[:]
			while remaining_key_lines or remaining_value_lines:
				available_height = (pdf.h - pdf.b_margin) - pdf.get_y()
				if available_height <= line_height + 2:
					pdf.add_page()
					pdf.set_font("Helvetica", "", SCOPING_DOCUMENT_BODY_FONT_SIZE)
					continue

				available_lines = max(1, int(available_height // line_height))

				chunk_key = remaining_key_lines[:available_lines]
				chunk_value = remaining_value_lines[:available_lines]

				row_height = (line_height * max(len(chunk_key), len(chunk_value), 1)) + 1.0
				if pdf.get_y() + row_height > pdf.h - pdf.b_margin:
					pdf.add_page()
					pdf.set_font("Helvetica", "", SCOPING_DOCUMENT_BODY_FONT_SIZE)
					continue

				remaining_key_lines = remaining_key_lines[available_lines:]
				remaining_value_lines = remaining_value_lines[available_lines:]

				start_x = pdf.get_x()
				start_y = pdf.get_y()

				pdf.set_draw_color(*grid_border)
				if key_fill_color is not None:
					pdf.set_fill_color(*key_fill_color)
					pdf.rect(start_x, start_y, left_col_width, row_height, style="DF")
				else:
					pdf.rect(start_x, start_y, left_col_width, row_height)
				pdf.rect(start_x + left_col_width, start_y, right_col_width, row_height)

				pdf.set_font("Helvetica", "B", SCOPING_DOCUMENT_BODY_FONT_SIZE)
				draw_wrapped_lines(start_x + 1.2, start_y + 0.5, left_col_width - 2, chunk_key or ["-"], line_height)

				pdf.set_font("Helvetica", "", SCOPING_DOCUMENT_BODY_FONT_SIZE)
				draw_wrapped_lines(start_x + left_col_width + 1.2, start_y + 0.5, right_col_width - 2, chunk_value or ["-"], line_height)

				pdf.set_xy(start_x, start_y + row_height)

				if remaining_key_lines or remaining_value_lines:
					pdf.add_page()
					pdf.set_font("Helvetica", "", SCOPING_DOCUMENT_BODY_FONT_SIZE)

		pdf.ln(2)

	def write_plan_details_table_two_columns(
		rows: Sequence[tuple[str, str]],
		empty_message: str,
		key_fill_color: tuple[int, int, int],
	) -> None:
		ensure_page_space(26)

		normalized_rows = list(rows or [("-", empty_message)])
		split_index = next(
			(index for index, (label, _) in enumerate(normalized_rows) if _sanitize(label).strip().lower() == "execution approach"),
			None,
		)
		if split_index is None or split_index <= 0 or split_index >= len(normalized_rows):
			split_index = (len(normalized_rows) + 1) // 2

		left_rows = normalized_rows[:split_index]
		right_rows = normalized_rows[split_index:]

		half_width = page_width / 2
		key_width = half_width * 0.34
		value_width = half_width - key_width
		line_height = SCOPING_DOCUMENT_LINE_HEIGHT

		for row_index in range(max(len(left_rows), len(right_rows))):
			left_key, left_value = left_rows[row_index] if row_index < len(left_rows) else ("", "")
			right_key, right_value = right_rows[row_index] if row_index < len(right_rows) else ("", "")

			left_key = normalize_display_key(str(left_key))
			right_key = normalize_display_key(str(right_key))

			remaining_left_key_lines = normalized_lines(left_key, key_width - 2, line_height, empty_placeholder="")
			remaining_left_value_lines = normalized_lines(left_value, value_width - 2, line_height, empty_placeholder="")
			remaining_right_key_lines = normalized_lines(right_key, key_width - 2, line_height, empty_placeholder="")
			remaining_right_value_lines = normalized_lines(right_value, value_width - 2, line_height, empty_placeholder="")

			while (
				remaining_left_key_lines
				or remaining_left_value_lines
				or remaining_right_key_lines
				or remaining_right_value_lines
			):
				available_height = (pdf.h - pdf.b_margin) - pdf.get_y()
				if available_height <= line_height + 2:
					pdf.add_page()
					continue

				available_lines = max(1, int(available_height // line_height))

				chunk_left_key = remaining_left_key_lines[:available_lines]
				chunk_left_value = remaining_left_value_lines[:available_lines]
				chunk_right_key = remaining_right_key_lines[:available_lines]
				chunk_right_value = remaining_right_value_lines[:available_lines]

				row_height = (line_height * max(
					len(chunk_left_key),
					len(chunk_left_value),
					len(chunk_right_key),
					len(chunk_right_value),
					1,
				)) + 1.0

				if pdf.get_y() + row_height > pdf.h - pdf.b_margin:
					pdf.add_page()
					continue

				remaining_left_key_lines = remaining_left_key_lines[available_lines:]
				remaining_left_value_lines = remaining_left_value_lines[available_lines:]
				remaining_right_key_lines = remaining_right_key_lines[available_lines:]
				remaining_right_value_lines = remaining_right_value_lines[available_lines:]

				start_x = pdf.get_x()
				start_y = pdf.get_y()

				cell_widths = [key_width, value_width, key_width, value_width]
				cell_texts = [chunk_left_key, chunk_left_value, chunk_right_key, chunk_right_value]
				cell_fonts = ["B", "", "B", ""]

				current_x = start_x
				for cell_index, (cell_width, cell_text, font_style) in enumerate(zip(cell_widths, cell_texts, cell_fonts, strict=True)):
					pdf.set_draw_color(*grid_border)
					if cell_index in (0, 2):
						pdf.set_fill_color(*key_fill_color)
						pdf.rect(current_x, start_y, cell_width, row_height, style="DF")
					else:
						pdf.rect(current_x, start_y, cell_width, row_height)

					pdf.set_font("Helvetica", font_style, SCOPING_DOCUMENT_BODY_FONT_SIZE)
					pdf.set_text_color(0, 0, 0)
					draw_wrapped_lines(current_x + 1.2, start_y + 0.5, cell_width - 2, cell_text, line_height)
					current_x += cell_width

				pdf.set_xy(start_x, start_y + row_height)

		pdf.ln(2)

	write_plan_details_table_two_columns(plan_details_rows or [], "No plan details data available", key_fill_color=plan_key_bg)
	draw_block_title("A) Scope")
	write_section("In Scope", inscope, text_align="J", horizontal_padding=1.2)
	write_section("Out of Scope", outscope)
	draw_block_title("B) Testing Approach")
	write_key_value_table("Test Step", testing_approach_rows or [], "No test step data available", key_fill_color=testing_key_bg)

	return bytes(pdf.output())


def _headers(file_prefix: str, plan_number: str | int | None) -> dict[str, str]:
	suffix = f"_{_sanitize(plan_number)}" if plan_number else ""
	return {
		"Content-Disposition": f'attachment; filename="{file_prefix}{suffix}.pdf"',
		"Content-Type": "application/pdf",
	}


def _section_body(report: Mapping[str, Any]) -> str:
	parts = []
	for index, section in enumerate(report.get("sections", []) or [], start=1):
		if not isinstance(section, Mapping):
			continue
		section_title = _escape(section.get("section_title", "Untitled Section"))
		parts.append(f"<h2>{index}. {section_title}</h2>")
		for point in section.get("key_points", []) or []:
			parts.append(f"<p>- {_escape(point)}</p>")
	return "".join(parts)


def _test_steps_body(test_steps: Sequence[Any]) -> str:
	parts = []
	for index, step in enumerate(test_steps, start=1):
		parts.append(f"<h2>{index}. Test Step</h2>")
		if isinstance(step, Mapping):
			for field, value in step.items():
				label = _escape(str(field).replace("_", " ").title())
				if isinstance(value, (list, tuple)):
					rendered = "<br>".join(f"- {_escape(item)}" for item in value)
				else:
					rendered = _paragraphs(value)
				if rendered:
					parts.append(f"<p><b>{label}:</b> {rendered}</p>")
		else:
			parts.append(_paragraphs(step))
	return "".join(parts)


def build_discovery_walkthrough_pdf(
	report: Mapping[str, Any],
	plan_number: str | int | None,
	plan_name: str | None = None,
) -> bytes:
	"""Build a PDF containing a discovery walkthrough report."""
	report_title = _sanitize(report.get("report_title") or "")
	sections: list[tuple[str, str]] = []
	section_titles: list[str] = []
	if report_title:
		sections.append((report_title, "=" * len(report_title)))

	for section in report.get("sections", []) or []:
		if not isinstance(section, Mapping):
			continue
		section_title = _sanitize(section.get("section_title", ""))
		section_titles.append(section_title)
		points = [_sanitize(point) for point in section.get("key_points", []) or []]

		def indent_of(text: str) -> int:
			return len(text) - len(text.lstrip(" "))

		# Blank line after each question only; none after group headings or sub-item labels.
		point_lines_list: list[str] = []
		for position, point in enumerate(points):
			point_lines_list.append(point)
			next_point = points[position + 1] if position + 1 < len(points) else None
			is_heading = point.lstrip().startswith("**")
			is_label = next_point is not None and indent_of(next_point) > indent_of(point)
			if not is_heading and not is_label and next_point is not None:
				point_lines_list.append("")
		point_lines = "\n".join(point_lines_list)
		content = point_lines
		sections.append((section_title, content))

	return _render_simple_report_pdf("Discovery Walkthrough", plan_number, sections, bold_headings=section_titles, space_indent_mm=3)


def download_discovery_walkthrough_pdf(
	plan_number: str,
	report: Mapping[str, Any],
	plan_name: str | None = None,
) -> tuple[bytes, dict[str, str]]:
	pdf_bytes = build_discovery_walkthrough_pdf(report, plan_number, plan_name)
	return pdf_bytes, _headers("discovery_walkthrough", plan_number)


def build_scope_recommendation_pdf(
	inscope: str | Mapping[str, Any] | Any,
	outscope: str | Mapping[str, Any] | Any,
	plan_number: str | int | None,
	plan_name: str | None = None,
) -> bytes:
	"""Build a PDF containing in-scope and out-of-scope recommendations."""
	def report_values(value: Any) -> tuple[str, str]:
		if hasattr(value, "model_dump"):
			value = value.model_dump()
		if isinstance(value, Mapping):
			return (
				_sanitize(value.get("report", "")),
				_sanitize(value.get("rationale", "")),
			)
		return _sanitize(value), ""

	inscope_report, inscope_rationale = report_values(inscope)
	outscope_report, outscope_rationale = report_values(outscope)
	lines = [
		("1. In Scope", inscope_report),
		("In-Scope Rationale", inscope_rationale),
		("2. Out of Scope", outscope_report),
		("Out-of-Scope Rationale", outscope_rationale),
	]
	return _render_simple_report_pdf("Scope Recommendation", plan_number, lines)


def download_scope_recommendation_pdf(
	plan_number: str,
	inscope: str,
	outscope: str,
	plan_name: str | None = None,
) -> tuple[bytes, dict[str, str]]:
	pdf_bytes = build_scope_recommendation_pdf(inscope, outscope, plan_number, plan_name)
	return pdf_bytes, _headers("scope_recommendation", plan_number)


def build_scoping_document_pdf(
	inscope: str,
	outscope: str,
	plan_number: str | int | None,
	testing_approach_rows: Sequence[tuple[str, str]] | None = None,
	plan_details_rows: Sequence[tuple[str, str]] | None = None,
	plan_name: str | None = None,
) -> bytes:
	"""Build the enhanced CT&A layout used for generated scoping documents."""
	return _render_scope_document_pdf(
		inscope=_sanitize(inscope),
		outscope=_sanitize(outscope),
		plan_number=plan_number,
		testing_approach_rows=testing_approach_rows,
		plan_details_rows=plan_details_rows,
		plan_name=plan_name,
	)


def download_scoping_document_pdf(
	plan_number: str,
	inscope: str,
	outscope: str,
	testing_approach_rows: Sequence[tuple[str, str]] | None = None,
	plan_details_rows: Sequence[tuple[str, str]] | None = None,
	plan_name: str | None = None,
) -> tuple[bytes, dict[str, str]]:
	pdf_bytes = build_scoping_document_pdf(
		inscope,
		outscope,
		plan_number,
		testing_approach_rows=testing_approach_rows,
		plan_details_rows=plan_details_rows,
		plan_name=plan_name,
	)
	return pdf_bytes, _headers("scoping_document", plan_number)


def download_scoping_document_pdf_from_html(
	plan_number: str,
	html_content: str,
) -> tuple[bytes, dict[str, str]]:
	"""Convert the scoping-document print HTML to PDF with xhtml2pdf (pure Python, no system libraries)."""
	try:
		pisa = importlib.import_module("xhtml2pdf.pisa")
	except ModuleNotFoundError as exc:
		raise RuntimeError("PDF generation dependency missing. Install 'xhtml2pdf'.") from exc

	buffer = io.BytesIO()
	# Built-in Helvetica is latin-1 only, so replace unsupported characters up front.
	result = pisa.CreatePDF(_sanitize(html_content), dest=buffer)
	if result.err:
		raise RuntimeError("Failed to render scoping document PDF.")
	return buffer.getvalue(), _headers("scoping_document", plan_number)


def build_test_steps_pdf(
	test_steps: Sequence[Any],
	plan_number: str | int | None,
	plan_name: str | None = None,
) -> bytes:
	"""Build a PDF containing structured audit test steps."""
	lines: list[tuple[str, str]] = []
	for index, step in enumerate(test_steps, start=1):
		lines.append((f"{index}. Test Step", ""))
		if isinstance(step, Mapping):
			structured_fields = step.get("test_step")
			if isinstance(structured_fields, Mapping):
				fields_to_render = structured_fields.items()
			else:
				fields_to_render = (
					(field, value)
					for field, value in step.items()
					if field not in {"rationale", "confidence_score"}
				)
			for field, value in fields_to_render:
				label = str(field).replace("_", " ").title()
				if isinstance(value, (list, tuple)):
					rendered = "\n".join(f"        - {_sanitize(item)}" for item in value)
				elif isinstance(value, Mapping):
					rendered = "\n".join(
						f"        {_sanitize(key)}: {_sanitize(item)}"
						for key, item in value.items()
					)
				else:
					rendered = f"    {_sanitize(value).replace(chr(10), chr(10) + '    ')}"
				if rendered:
					lines.append((label, rendered))
			if step.get("rationale"):
				lines.append(("Rationale", _sanitize(step["rationale"])))
		else:
			lines.append(("", _sanitize(step)))

	return _render_simple_report_pdf(
		"Test Steps",
		plan_number,
		lines,
		spacing_after=1,
		underline_headings=True,
	)


def download_test_steps_pdf(
	plan_number: str,
	test_steps: Sequence[Any],
	plan_name: str | None = None,
) -> tuple[bytes, dict[str, str]]:
	pdf_bytes = build_test_steps_pdf(test_steps, plan_number, plan_name)
	return pdf_bytes, _headers("test_steps", plan_number)
