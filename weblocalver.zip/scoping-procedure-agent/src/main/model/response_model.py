from pydantic import BaseModel, Field
from typing import Any, List, Optional




class UploadedMeetingNote(BaseModel):
    filename: str = Field(..., description="Name of the uploaded file")
    document_url: str = Field(..., description="URL to access the uploaded document")
    size_bytes: int = Field(..., description="Size of the uploaded document in bytes")


class MeetingNotesSummaryResponse(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    uploaded_documents: list[UploadedMeetingNote] = Field(..., description="List of uploaded meeting notes or MOM documents")
    normalized_summary_uri: str = Field(..., description="URI to access the normalized summary of the meeting notes")


class ScopeReport(BaseModel):
    """Narrative and supporting metadata for one scope determination."""
    report: str = Field(..., description="Labelled attribute list (one 'Attribute: value' per line) describing the scope determination")
    rationale: str = Field(
        "",
        description=(
            "A concise explanation of the evidence-based reasoning for this scope determination. "
            "Explain why the documented risks, controls, obligations, findings, remediation, or prior-year "
            "precedent support including or excluding the identified areas. Do not restate the report."
        ),
    )
    confidence_score: int = Field(
        0,
        ge=0,
        le=100,
        description=(
            "An integer between 0 and 100 reflecting the sufficiency and completeness of the evidence supporting "
            "this scope determination. Lower the score when material evidence gaps affect the conclusion."
        ),
    )


class InScopeOutScopeResponse(BaseModel):
    """Response model for independent in-scope and out-of-scope determinations."""
    planNumber: str = Field(..., description="Unique identifier for the plan")
    inscope: ScopeReport = Field(..., description="In-scope report, rationale, and confidence score")
    outscope: ScopeReport = Field(..., description="Out-of-scope report, rationale, and confidence score")


class DiscoveryWalkthroughSection(BaseModel):
    """
    Represents a section of the discovery walkthrough report.
    """
    section_title: str = Field(..., description="The title of the section.")
    key_points: List[str] = Field(..., description="A list of key points for this section.")

class DiscoveryWalkthroughReport(BaseModel):
    """
    A structured report for the discovery walkthrough, highlighting key points from the preliminary research.
    """
    report_title: str = Field(
        ...,
        description="The title of the discovery walkthrough report."
    )
    sections: List[DiscoveryWalkthroughSection] = Field(
        ..., description="A list of sections in the report."
    )
    rationale: str = Field(
        "",
        description=(
            "A single, report-level explanation of the core reasoning behind the entire report's content, "
            "written as one coherent paragraph covering all sections together. "
            "Explain the core reasoning with data: the key evidence (open findings, key controls, mandatory "
            "policies, regulatory obligations, prior-year review precedent) and the analysis performed to arrive "
            "at the scope drivers, requirements, and open questions — not a restatement of the report content. "
            "Do NOT reference any confidence score, limitations, or data gaps. "
            "Keep it short: optimally 3-4 lines and never more than 4-5 lines."
        )
    )
    confidence_score: int = Field(
        0,
        ge=0,
        le=100,
        description=(
            "An integer between 0 and 100 reflecting the Evidence Sufficiency and Response Completeness of the "
            "discovery walkthrough report. First analyse the gaps and limitations in the provided preliminary "
            "research data, then assign a score consistent with those gaps (more or larger gaps => lower score)."
        )
    )

class TestStep(BaseModel):
    """One generated audit test step."""
    test_step: dict[str, Any] = Field(
        ...,
        description=(
            "The generated audit test step containing all 24 structured testing fields."
        ),
    )


class TestStepsResponse(BaseModel):
    """Response model for test steps generation."""
    planNumber: str = Field(..., description="Unique identifier for the plan")
    test_steps: list[TestStep] = Field(..., description="Generated audit test steps")

class MeetingNotesSummaryContentResponse(BaseModel):
    """Response model for fetching persisted meeting-notes summary content."""
    planNumber: str = Field(..., description="Plan number")
    normalized_meeting_notes: Any = Field(..., description="Persisted normalized meeting notes summary content")
