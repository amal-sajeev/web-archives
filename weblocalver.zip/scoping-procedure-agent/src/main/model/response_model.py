from pydantic import BaseModel, Field
from typing import Any, List, Optional


class UploadedMeetingNote(BaseModel):
    filename: str = Field(..., description="Name of the uploaded file")
    document_url: str = Field(..., description="URL to access the uploaded document")
    size_bytes: int = Field(..., description="Size of the uploaded document in bytes")


class MeetingNotesSummaryResponse(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    uploaded_documents: list[UploadedMeetingNote] = Field(
        ..., description="List of uploaded meeting notes or MOM documents"
    )
    normalized_summary_uri: str = Field(
        ..., description="URI to access the normalized summary of the meeting notes"
    )


class ScopeReport(BaseModel):
    """Narrative and supporting metadata for one scope determination."""

    report: str = Field(
        ...,
        description="Labelled attribute list (one 'Attribute: value' per line) describing the scope determination",
    )
    rationale: str = Field(
        "",
        description=(
            "A concise explanation of the evidence-based reasoning for this scope determination. "
            "Explain why the documented risks, controls, obligations, findings, remediation, or prior-year "
            "precedent support including or excluding the identified areas. Do not restate the report."
        ),
    )
    confidence_score: int = Field(
        0,
        ge=0,
        le=100,
        description=(
            "An integer between 0 and 100 reflecting the sufficiency and completeness of the evidence supporting "
            "this scope determination. Lower the score when material evidence gaps affect the conclusion."
        ),
    )


class InScopeOutScopeResponse(BaseModel):
    """Response model for independent in-scope and out-of-scope determinations."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    inscope: ScopeReport = Field(
        ..., description="In-scope report, rationale, and confidence score"
    )
    outscope: ScopeReport = Field(
        ..., description="Out-of-scope report, rationale, and confidence score"
    )


class DiscoveryWalkthroughSection(BaseModel):
    """
    Represents a section of the discovery walkthrough report.
    """

    section_title: str = Field(..., description="The title of the section.")
    key_points: List[str] = Field(
        ..., description="A list of key points for this section."
    )


class DiscoveryWalkthroughReport(BaseModel):
    """
    A structured report for the discovery walkthrough, highlighting key points from the preliminary research.
    """

    report_title: str = Field(
        ..., description="The title of the discovery walkthrough report."
    )
    sections: List[DiscoveryWalkthroughSection] = Field(
        ..., description="A list of sections in the report."
    )
    rationale: str = Field(
        "",
        description=(
            "A single, report-level explanation of the core reasoning behind the entire report's content, "
            "written as one coherent paragraph covering all sections together. "
            "Explain the core reasoning with data: the key evidence (open findings, key controls, mandatory "
            "policies, regulatory obligations, prior-year review precedent) and the analysis performed to arrive "
            "at the scope drivers, requirements, and open questions — not a restatement of the report content. "
            "Do NOT reference any confidence score, limitations, or data gaps. "
            "Keep it short: optimally 3-4 lines and never more than 4-5 lines."
        ),
    )
    confidence_score: int = Field(
        0,
        ge=0,
        le=100,
        description=(
            "An integer between 0 and 100 reflecting the Evidence Sufficiency and Response Completeness of the "
            "discovery walkthrough report. First analyse the gaps and limitations in the provided preliminary "
            "research data, then assign a score consistent with those gaps (more or larger gaps => lower score)."
        ),
    )


class TestStep(BaseModel):
    """One generated audit test step."""

    test_step: dict[str, Any] = Field(
        ...,
        description=(
            "The generated audit test step containing all 24 structured testing fields."
        ),
    )
    rationale: str = Field(
        ...,
        pattern=r"\S",
        description=(
            "A highly information-dense, 2-to-3-sentence executive-level audit summary for this test step, "
            "written in a risk-focused, business-justified tone. It must focus strictly on the 'How' of "
            "the audit strategy — how this test step maps to the regulatory and operational lifecycle of its "
            "in-scope activities, and how its selected testing approaches (DE, OE, or transaction-level validation) adapt "
            "to the maturity or gaps in the current control environment. Do NOT describe the generation process, "
            "prompt constraints, or raw data, and do NOT open with a description/summary of the review, its "
            "objective, lifecycle, or the regulation it supports — start directly with the testing strategy behind "
            "this test step. Formal, third-person tone suitable for senior leadership and regulators."
        ),
    )
    confidence_score: int = Field(
        ...,
        ge=0,
        le=100,
        description=(
            "An integer between 0 and 100 reflecting the Evidence Sufficiency and Response Completeness of "
            "this test step. First analyse the gaps and limitations in the provided data relevant to this step, "
            "then independently assign a score consistent with those gaps (more or larger gaps => lower score)."
        ),
    )


class TestStepsResponse(BaseModel):
    """Response model for test steps generation."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    test_steps: list[TestStep] = Field(..., description="Generated audit test steps")


class TestStepsRefinementTargets(BaseModel):
    """Test step parts identified as affected by a user's exclusion request."""

    affected_part_ids: list[str] = Field(
        ...,
        description=(
            "part_id values, exactly as given, of the test step parts that must change to apply the "
            "exclusion request. Empty when the request does not clearly match any content."
        ),
    )


class RegeneratedTestStepPart(BaseModel):
    """New value for one affected test step part."""

    part_id: str = Field(..., description="part_id of the regenerated part, exactly as given")
    value: str | None = Field(
        ...,
        description=(
            "New value of the part. An empty string \"\" when the field itself must be removed from the "
            "test step; null when all of the field's content is removed but the field must be kept."
        ),
    )


class RegeneratedTestStepParts(BaseModel):
    """Regenerated values for the affected test step parts."""

    parts: list[RegeneratedTestStepPart] = Field(
        ..., description="One entry for every part_id that was requested for regeneration"
    )


class MeetingNotesSummaryContentResponse(BaseModel):
    """Response model for fetching persisted meeting-notes summary content."""

    planNumber: str = Field(..., description="Plan number")
    normalized_meeting_notes: Any = Field(
        ..., description="Persisted normalized meeting notes summary content"
    )


class DiscoveryWalkthroughQuestionBankValidation(BaseModel):
    filename: str = Field(
        ..., description="Original file name used for the validation decision"
    )
    is_valid: bool = Field(
        ..., description="Whether the uploaded file is a valid question-bank document"
    )
    reason: str = Field(..., description="Short explanation of the validation verdict")
    document_type: str = Field(
        ...,
        description="Classification of the uploaded document: question_bank, generic_business_document, or not_question_bank",
    )


class DiscoveryWalkthroughUploadResponse(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    uploaded_documents: list[UploadedMeetingNote] = Field(
        ...,
        description="List of uploaded discovery-walkthrough question-bank documents",
    )
    storage_prefix: str = Field(
        ...,
        description="GCS prefix where the uploaded discovery-walkthrough documents were stored",
    )
    validation_results: Optional[list[DiscoveryWalkthroughQuestionBankValidation]] = (
        Field(
            default=None,
            description="Guardrail validation result for each file uploaded",
        )
    )
    upload_completed: bool = Field(
        default=False,
        description="Whether the validated files were uploaded to the bucket",
    )
    confirmation_required: bool = Field(
        default=True,
        description="Whether the user must explicitly confirm the guardrail outcome before files are persisted",
    )
    validated_files: Optional[list[dict[str, Any]]] = Field(
        default=None,
        description="Base64-encoded validated file payloads to carry forward to the confirm step without server-side pending state.",
    )


class TestStepsUploadValidation(BaseModel):
    filename: str = Field(
        ..., description="Original file name used for the validation decision"
    )
    is_valid: bool = Field(
        ..., description="Whether the uploaded file is a valid test-steps document"
    )
    reason: str = Field(..., description="Short explanation of the validation verdict")
    document_type: str = Field(
        ...,
        description="Classification of the uploaded document: test_steps or not_test_steps",
    )


class TestStepsUploadResponse(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    uploaded_documents: list[UploadedMeetingNote] = Field(
        ...,
        description="List of uploaded test-steps supporting documents",
    )
    storage_prefix: str = Field(
        ...,
        description="GCS prefix where the uploaded test-steps documents were stored",
    )
    validation_results: Optional[list[TestStepsUploadValidation]] = Field(
        default=None,
        description="Guardrail validation result for each file uploaded",
    )
    upload_completed: bool = Field(
        default=False,
        description="Whether the validated files were uploaded to the bucket",
    )
    confirmation_required: bool = Field(
        default=True,
        description="Whether the user must explicitly confirm the guardrail outcome before files are persisted",
    )
    validated_files: Optional[list[dict[str, Any]]] = Field(
        default=None,
        description="Base64-encoded validated file payloads to carry forward to the confirm step without server-side pending state.",
    )
