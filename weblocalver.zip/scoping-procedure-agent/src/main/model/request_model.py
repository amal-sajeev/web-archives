from fastapi import UploadFile
from pydantic import BaseModel, Field
from typing import List, Optional
from model.response_model import ScopeReport, TestStep


class UserRequest(BaseModel):
    review_scope_id: Optional[int] = Field(
        None, description="review_scope_id provided by the gateway"
    )
    user: Optional[str] = Field(None, max_length=100)
    remarks: Optional[str] = Field(None, max_length=500)


class MeetingNotesUploadRequest(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    files: list[UploadFile] = Field(
        ..., description="List of uploaded meeting notes or MOM documents"
    )


class DiscoveryWalkthroughQuestionsUploadRequest(BaseModel):
    # plan number for bucket flow, for database userDetails req
    planNumber: str = Field(..., description="Plan number")
    userDetails: UserRequest = Field(..., description="User details for the request.")
    files: list[UploadFile] = Field(
        ...,
        description="List of uploaded discovery-walkthrough question-bank documents",
    )


class GenerateInScopeOutScopeRequest(BaseModel):
    """Request model for /generate-inscope-outscope endpoint."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    userDetails: UserRequest = Field(..., description="User details for the request.")


class GenerateTestStepsRequest(BaseModel):
    """Request model for /generate-test-steps endpoint."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    userDetails: Optional[UserRequest] = Field(None, description="User details for database persistence.")


class GetScopingDocumentRequest(BaseModel):
    """Request model for downloading the editable scoping document as PDF."""

    planNumber: str = Field(..., description="Unique identifier for the plan")


class GenerateScopingDocumentRequest(BaseModel):
    """Request model for rendering the editable scoping document."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    userDetails: UserRequest = Field(..., description="User details for the request.")


class GenerateDiscoveryWalkthrough(BaseModel):
    planNumber: str
    userDetails: UserRequest = Field(..., description="User details for the request.")


class GetMeetingNotesSummaryRequest(BaseModel):
    """Request model for fetching persisted meeting-notes summary."""

    planNumber: str = Field(..., description="Unique identifier for the plan")


class DiscoveryWalkthroughSectionPayload(BaseModel):
    """Section payload for discovery walkthrough updates."""

    section_title: str = Field(..., description="The title of the section.")
    key_points: List[str] = Field(
        ..., description="A list of key points for this section."
    )


class UpdateDiscoveryWalkthroughRequest(BaseModel):
    """Request model for updating discovery walkthrough artifact."""

    userDetails: UserRequest = Field(..., description="User details for the request.")
    planNumber: str = Field(..., description="Unique identifier for the plan")
    report_title: str = Field(
        ..., description="The title of the discovery walkthrough report."
    )
    sections: List[DiscoveryWalkthroughSectionPayload] = Field(
        ...,
        description="A list of sections in the report.",
    )
    rationale: str = Field(
        "",
        description=("rationale fo the discovery walkthrough report"),
    )
    confidence_score: int = Field(
        0,
        ge=0,
        le=100,
        description="Confidence score for the discovery walkthrough report.",
    )


class UpdateInScopeOutScopeRequest(BaseModel):
    """Request model for updating inscope/outscope artifacts."""

    userDetails: UserRequest = Field(..., description="User details for the request.")
    planNumber: str = Field(..., description="Unique identifier for the plan")
    inscope: ScopeReport = Field(
        ..., description="Updated in-scope report, rationale, and confidence score"
    )
    outscope: ScopeReport = Field(
        ..., description="Updated out-of-scope report, rationale, and confidence score"
    )


class UpdateTestStepsRequest(BaseModel):
    """Request model for updating generated test steps artifact."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    userDetails: Optional[UserRequest] = Field(None, description="User details for database persistence.")
    test_steps: list[TestStep] = Field(
        ...,
        description="Full updated list of structured test steps with a rationale and confidence score per step",
    )


class RefineTestStepsRequest(UpdateTestStepsRequest):
    """Request model for excluding content from test steps."""

    comment: str = Field(
        ..., description="User comment on exclusion of data from the current test steps"
    )


class ScopingDocumentRow(BaseModel):
    key: str = Field(..., max_length=500)
    value: str = Field(..., max_length=50000)


class ScopingDocumentStakeholder(BaseModel):
    name: str = Field("", max_length=500)
    role: str = Field("", max_length=1000)


APPROVAL_ROW_KEYS = (
    "Scope Reviewed By / Date\n**Team Lead attestation - I attest to the quality of the Scoping template completed"
    " and that it includes sufficient rationale where required.**",
    "Regional Head Approver / Date",
)


class ScopingDocumentContent(BaseModel):
    """Editable content for the generated scoping-document template."""

    plan_name: str = Field("", max_length=500)
    plan_details_rows: list[ScopingDocumentRow] = Field(
        default_factory=list, max_length=100
    )
    purpose_statement: str = Field("", max_length=100000)
    inscope: str = Field("", max_length=100000)
    outscope: str = Field("", max_length=100000)
    testing_approach_rows: list[ScopingDocumentRow] = Field(default_factory=list)
    key_stakeholders: list[ScopingDocumentStakeholder] = Field(
        default_factory=lambda: [ScopingDocumentStakeholder() for _ in range(5)],
        max_length=100,
    )
    approval_rows: list[ScopingDocumentRow] = Field(
        default_factory=lambda: [
            ScopingDocumentRow(key=key, value="") for key in APPROVAL_ROW_KEYS
        ],
        max_length=10,
    )


class UpdateScopingDocumentRequest(BaseModel):
    userDetails: UserRequest = Field(..., description="User details for the request.")
    planNumber: str = Field(..., min_length=1, max_length=50)
    document: ScopingDocumentContent


class DownloadDiscoveryWalkthroughRequest(BaseModel):
    """Request model for downloading a discovery walkthrough PDF."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    report_title: str = Field(
        ..., description="The title of the discovery walkthrough report"
    )
    sections: List[DiscoveryWalkthroughSectionPayload] = Field(
        ...,
        description="Discovery walkthrough sections to render in the PDF",
    )
    rationale: str = Field("", description="Report-level rationale for the walkthrough")
    confidence_score: int = Field(
        0, ge=0, le=100, description="Evidence confidence score"
    )


class DownloadScopeRecommendationRequest(BaseModel):
    """Request model for downloading a scope recommendation PDF."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    inscope: ScopeReport = Field(..., description="In-scope recommendation")
    outscope: ScopeReport = Field(..., description="Out-of-scope recommendation")


class DownloadTestStepsRequest(BaseModel):
    """Request model for downloading a test steps PDF."""

    planNumber: str = Field(..., description="Unique identifier for the plan")
    test_steps: list[dict] = Field(
        ...,
        description="Structured test steps to render in the PDF",
    )


class ConfirmDiscoveryWalkthroughUploadRequest(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    userDetails: UserRequest = Field(..., description="User details for the request.")
    validated_files: list[dict[str, str]] = Field(
        ...,
        min_length=1,
        description="Validated file payloads passed through from the upload step without storing them in memory.",
    )
    confirmed: bool = Field(
        default=False,
        description="Whether the user explicitly confirms the question-bank guardrail result",
    )


class TestStepsUploadRequest(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    userDetails: UserRequest = Field(..., description="User details for the request.")
    files: list[UploadFile] = Field(
        ...,
        description="List of uploaded test-steps supporting documents",
    )


class ConfirmTestStepsUploadRequest(BaseModel):
    planNumber: str = Field(..., description="Plan number")
    userDetails: UserRequest = Field(..., description="User details for the request.")
    validated_files: list[dict[str, str]] = Field(
        ...,
        min_length=1,
        description="Validated file payloads passed through from the upload step without storing them in memory.",
    )
    confirmed: bool = Field(
        default=False,
        description="Whether the user explicitly confirms the test-steps guardrail result",
    )
