import os
from dotenv import load_dotenv
load_dotenv()

def _optional_number(name: str, cast):
    value = (os.getenv(name) or "").strip()
    return cast(value) if value else None

def _env_flag(*names: str, default: bool = False) -> bool:
    for name in names:
        value = os.getenv(name)
        if value is None:
            continue
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return default

class Config:
    db_host = os.getenv("db_host","localhost")
    db_user = os.getenv("db_user")
    db_name = os.getenv("db_name")
    db_port = os.getenv("db_port","5432")
    db_pass = os.getenv("scoping_db_pass")
    MODEL_NAME = os.getenv("GENAI_MODEL_NAME", "gemini-3.5-flash-europe-west3")
    SCOPE_RECOMMENDATION_JUDGE_LOOP = _env_flag(
        "SCOPE_RECOMMENDATION_JUDGE_LOOP",
        "JUDGE_LOOP",
        "judge_loop",
        default=False,
    )
    JUDGE_LOOP = SCOPE_RECOMMENDATION_JUDGE_LOOP
    SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS = int(
        os.getenv("SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS", "1")
    )
    SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY = os.getenv(
        "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY", "fail_open"
    )
    SCOPE_RECOMMENDATION_LLM_MAX_ATTEMPTS = int(
        os.getenv("SCOPE_RECOMMENDATION_LLM_MAX_ATTEMPTS", "4")
    )
    SCOPE_RECOMMENDATION_LLM_RETRY_BASE_SECONDS = int(
        os.getenv("SCOPE_RECOMMENDATION_LLM_RETRY_BASE_SECONDS", "2")
    )
    if SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS < 0:
        raise ValueError(
            "SCOPE_RECOMMENDATION_REVIEW_MAX_REVISIONS must be 0 or greater"
        )
    if SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY not in {"fail_open", "fail_closed"}:
        raise ValueError(
            "SCOPE_RECOMMENDATION_REVIEW_FAILURE_POLICY must be 'fail_open' or 'fail_closed'"
        )
    GENERATION_CONFIG = {
        "temperature": _optional_number("GENAI_TEMPERATURE", float),
        "top_p": _optional_number("GENAI_TOP_P", float),
        "top_k": _optional_number("GENAI_TOP_K", int),
    }
    # Gemini 3+ reasoning depth: minimal | low | medium | high. Empty string uses the model default.
    THINKING_LEVEL = os.getenv("GENAI_THINKING_LEVEL", "high").strip().lower() or None
    SAFETY_CONFIG = {
        "safety_settings": {
            "HARM_CATEGORY_HARASSMENT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_HATE_SPEECH": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_MEDIUM_AND_ABOVE"
        }
    }
    PROJECT_NAME = os.getenv("PROJECT_NAME") or os.getenv("project_name")
    PROJECT_LOCATION = os.getenv("PROJECT_LOCATION") or os.getenv("project_location")
    REVIEW_BUCKET_NAME = (
        os.getenv("DBAWARE_REVIEW_BUCKET_NAME")
        or os.getenv("BUCKET_NAME")
        or os.getenv("bucket_name")
    )
    BUCKET_NAME = os.getenv("BUCKET_NAME") or os.getenv("bucket_name")

    # Bucket folder naming convention
    REVIEW_FOLDER_PATTERN = "dbaware_review_{plan_number}"

    # Raw data folders configuration
    RAW_DATA_CONFIG = {
        "dbaware": {
            "folder": "inbound-data/dbaware",
            "files": [
                "alc_nalc_details.json",
                "historical_plan_details.json",
                "plan_details.json"
            ]
        },
        "dbgrc": {
            "folder": "inbound-data/dbgrc",
            "files": ["control_details.json", "risk_driver_details.json"]
        },
        "gfms": {
            "folder": "inbound-data/gfms",
            "files": ["findings_details.json"]
        },
        "lrr": {
            "folder": "inbound-data/lrr",
            "files": ["internet_search_data.json"]
        },
        "policy": {
            "folder": "inbound-data/policy",
            "files": [
                "relevant_policy.json",
                "relevant_kod.json",
                "relevant_procedure.json"
            ],
            "parts_folders": {
                "relevant_policy.json": "inbound-data/policy/relevant_policy",
                "relevant_kod.json": "inbound-data/policy/relevant_kod",
                "relevant_procedure.json": "inbound-data/policy/relevant_procedure",
            },
        }
    }

    # Preliminary research configuration
    REVIEW_PLAN_FOLDER_TEMPLATE ="dbaware_review_{plan_number}"
    PROCESSING_DATA_FOLDER = "processing-data"
    PRELIMINARY_RESEARCH_FOLDER ="preliminary-research"
    USER_FEEDBACK_FOLDER = "preliminary-research-user-feedback"
    USER_FEEDBACK_SUMMARY_FILE = "preliminary-research-user-feedback-summary.json"
    DISCOVERY_WALKTHROUGH_FILE = "discovery_walkthrough.json"
    PRELIMINARY_RESEARCH_PATH = "processing-data/preliminary-research/preliminary-research.json"
    # Report section files (latest format) mapped to their analysis_report keys
    PRELIMINARY_RESEARCH_SECTION_FILES = {
        "Past Review Analysis": "processing-data/preliminary-research/past_review.json",
        "Policy, KOD and Regulatory Analysis": "processing-data/preliminary-research/policy_regulation.json",
        "Broad Scope Direction": "processing-data/preliminary-research/broad_scope.json",
    }
    PRELIMINARY_RESEARCH_FEEDBACK_PATH = "processing-data/preliminary-research/preliminary-research-user-feedback-summary.json"
    PROCEDURE_PROCESSING_PATH = "processing-data/procedure/"
    SCOPING_FOLDER_PATH = "processing-data/scoping/"
