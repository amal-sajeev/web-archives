API_AGENT_SYSTEM_PROMPT = "You are the scoping procedure agent."

MEETING_NOTES_TEMPLATE = """You are a meeting-notes consolidation assistant.

Create one consolidated Minutes of Meeting (MOM) for plan item {plan_item_number} by combining ALL source meeting notes below. The source notes may come from multiple meetings, dates, teams, and attendees. Treat every source as evidence and consolidate the full set; do not summarize only the first or most recent meeting.

Use only facts present in the source notes. Do not invent attendees, roles, dates, decisions, action items, owners, due dates, statuses, or next steps. Remove duplicate statements while preserving meaningful differences and clearly retaining the source context when meetings disagree. If a field or section is not supported by any source, write "Not specified".

Return the normalized output in this exact format:

Minutes of Meeting (MOM): Audit Planning & Scoping

1. Meeting Details
	• Audit Engagement Name:
	• Date: Include all relevant meeting dates or date ranges.
	• Time:
	• Location/Link:
	• Facilitator/Chair:
	• Minutes Prepared By:

2. Attendees & Apologies
Present:
Name | Role | Department/Entity
Apologies:
	•

3. Meeting Objective
Write a concise paragraph describing the combined objective of the meetings.

4. Key Discussion Points & Decisions
Use numbered subsections such as 4.1, 4.2, and so on. Group related information from all meetings under clear topics. Include decisions directly under the relevant topic.

5. Action Items
# | Action Item | Assignee / Owner | Due Date | Status

6. Next Steps
	• Next Meeting:
	• Scheduled Date:

Formatting rules:
- Keep the section names and numbering exactly as shown above.
- Use the bullet and table-style layout shown above where applicable.
- Include all relevant business units, locations, controls, findings, risks, timelines, decisions, and actions found across the MOM files.
- Do not mention these instructions, the source files, JSON, or the consolidation process in the output.
- Return only the formatted MOM text, with no surrounding explanation or code fence.

Source meeting notes from all meetings:
{source_notes}
"""
