DISCOVERY_WALKTHROUGH_QUESTION_BANK = """
Use this business question bank to drive walkthrough depth, challenge, and coverage.

I. Governance, Strategy, and Risk Control Frameworks
- Control Design & Operating Effectiveness: What is the design and operating effectiveness of key 2LoD controls across regional entities, and how is adherence to local regulatory synchronization requirements ensured?
- Framework Coverage & Automated Exception Testing: How does the control framework ensure risk-based coverage of core operational frameworks, and how are automated testing methods used to verify specific compliance exceptions (e.g., absence policies)?
- Gap Analysis & Residual Control Testing: What process performs control-based testing for remaining required controls not covered by other scheduled reviews?
- Centralized vs. Regional Activity Scoping: How does the audit plan balance risk-based coverage of central investigative/supporting activities with appropriate scope for regional teams?
- Regulatory Continuity & Subsidiary Alignment: How is local subsidiary compliance ensured while maintaining methodological continuity with prior risk assessments?
- Functional Exception Management & Filtering Key Controls: How effective are screening and filtering controls, and how are investigations, blocking/releasing/reporting exceptions, and local program requirements managed regionally?
- Strategic Redesign & Cross-Functional Interfaces: How are central processes/controls managed during strategic transitions, and how are interfaces to adjacent functions, model management, and IT applications monitored?
- Risk Management & Control System Verification: How is an independent view formed on RMS/ICS effectiveness by leveraging and challenging 1LoD and 2LoD assessments?
- Governance Committee Oversight & Escalation Handling: How does governance committee oversight operate, and how are escalations/complaints handled, tracked, and resolved?
- Core Unit Control Effectiveness: What framework assesses operating and control effectiveness of localized operational units?

II. Operational Resilience and Business Continuity Management
- How are localized regulatory/compliance controls synchronized, and how are data protection/privacy requirements integrated into regional frameworks?
- What parameters and rules are used in automated testing protocols for key operational or absence controls?
- What is the step-by-step process for initiating, documenting, and escalating specialized case investigation files across regional teams?
- What is the formal workflow for reviewing, verifying, and releasing restricted accounts or flagged transactions?
- What are boundaries, differences, and interconnections between operational resilience responsibilities and business continuity roles?
- How do mandates, scopes, and authority levels differ between global divisional oversight partners and regional execution partners?
- How are roles/reporting lines differentiated between local operational resilience leads and regional resilience owners?
- What is the structured link, hierarchy, and data flow between core business service management, continuity planning, and crisis response?
- What is the formal process for creating new organizational recovery units, and what operational/financial triggers initiate this?
- How are critical recovery units mapped, managed, or consolidated during reorganizations/restructures?
- Are there thresholds/caps on personnel assigned to a single recovery unit?
- What are the limits on geographical locations or total staff headcount covered by a consolidated recovery unit?
- Is staff headcount tracked by financial cost center or physical location?
- How are multi-location recovery units configured in the core tool, and how are regional/location-specific variations documented?
- What is the root cause for previously exempted cost centers/business units reappearing on non-compliance or monitoring reports?
- What guidance governs adding key contacts to control plans, and what evidence is required to justify inclusion/retention/removal?
- What is the mandatory frequency for verifying accuracy of functional contacts and key personnel roles?
- What is the handover/escalation/offboarding protocol when an accountable manager or key control coordinator departs?
- What is the strategy, timeline, and migration plan for transition from legacy reporting to enterprise GRC?
- How are unstructured governance forums, peer reviews, and informal advisory discussions documented as audit-ready evidence?
- How are 2LoD testing methods/findings aligned with internal/external audit standards and reviews?
- What is the frequency for measuring/reporting KRIs and tolerance thresholds, and is reporting divisional or regional?

III. Organizational Structure, Clients, and Performance Operations
- What is the mandate of specialized executive/private coverage teams, and which client segments are in scope?
- Do specialized private coverage teams support holding companies/legal entities in addition to natural persons?
- How are service levels, prioritization, and operating models of premium/niche desks differentiated from standard units?
- Is there a centralized registry to track active policy exceptions and risk approvals for high-value/specialized portfolios?
- What is the organizational structure, reporting hierarchy, and role allocation within the unit?
- Do client support/operations staff report to unit head directly or via matrix/functional lines?
- How is labor split between general account managers and specialized technical advisors?
- What is the distribution between discretionary/non-advisory mandates and active advisory transaction models?
- What is the client transition protocol when eligibility for specialized desk services is lost?
- What operational challenges, conflicts of interest, and system limitations exist in shared/co-coverage models?
- Do revenues/performance metrics from shared coverage count toward individual targets/reviews?
- Which KPIs (e.g., asset growth, lending volume, discretionary mandates) measure desk success?
- What is the process for setting/calibrating/approving team and individual targets?
- What operational pain points (e.g., delays, SLA misalignment with back office) affect efficiency?
- How is the unit aligned with enterprise transformation, digitization, and professionalization programs?
"""

DISCOVERY_WALKTHROUGH_PROMPT = f"""
You are a scoping analyst. Your task is to review a preliminary research report and extract key information to prepare for a discovery walkthrough meeting with stakeholders.

Objective:
Analyse the provided "Preliminary Research Report" and produce a "Discovery Walkthrough Report" whose purpose is to highlight gaps, assumptions, and open questions to be raised with stakeholders. It must be evidence-based, risk-oriented, and aligned to the business question bank.

Required question bank:
{DISCOVERY_WALKTHROUGH_QUESTION_BANK}

Output Structure:
The report must have a main title and exactly ONE section.

- Report Title must be exactly: "Discovery Walkthrough Preparation"
- The single section's `section_title` must be exactly: "Open Questions and Verification Points"
- The section's `key_points` list must be a flat list of Markdown strings in the order and format below. Each of the six group headings appears EXACTLY ONCE. NEVER repeat a group heading; multiple KODs, controls/risks, assessment units, or regulations/policies are sub-items inside that single group.
- String formats:
  - Group heading: "**<Group>:** <description>" (one string per group). Wrap only the group heading in double asterisks; do not wrap sub-item labels in asterisks or any other markdown emphasis.
  - Flat question (Findings, Generic): " 1. <question>" (numbered 1., 2., 3. ... within the group)
  - Sub-item label (KOD, Control/Risk, Assessment Unit, Regulation/Policy): " <label>" (one-space indent, no hyphen), followed by its questions as "  1. <question>" (two-space indent, numbered 1., 2., 3. ... within that sub-item, no hyphen). Use space indentation, not hyphens, to separate sub-items and their questions.
Groups (in this order, each exactly once):

1. "**Findings:** Gaps or assumptions identified from Findings Data"
   Flat questions on open/closed audit, regulatory, or issue findings (IDs, ratings, closure status, evidence of closure, sign-off, whether the related control should be in scope).
2. "**KOD:** Gaps or assumptions identified from KOD"
   One sub-item per KOD, labelled " <KOD NAME>" using the EXACT KOD name as it appears in the preliminary research (no shortening, rewording, or other modification), followed by that KOD's gaps/assumptions as indented questions. Never place a KOD's questions outside its own sub-item.
3. "**Control/Risk:**"
   One sub-item per control or risk with a gap, labelled " <CONTROL ID/NAME> (Risk <ID>: <Risk name>)", then indented questions (risk mapping discrepancies, design/operating effectiveness, ownership, automation parameters, exceptions, missing test evidence).
4. "**Assessment Unit:** Gaps or Assumptions identified from AU"
   One sub-item per AU, labelled " AU: <AU NAME>" (AU name only, no extra qualifiers), then indented questions.
5. "**Regulation/Policy:** Gaps or assumptions identified from Regulations/Policy"
   One sub-item per regulation/policy (or related set), labelled " <NAME(S)>", then indented questions (e.g., confirm prior out-of-scope items remain appropriate; request step-by-step process, parameters, rules behind a regulatory action).
6. "**Generic:** Generic gaps or assumptions that are not associated in any of the above areas"
   Flat questions from question bank themes (governance, operational resilience, organizational model, operating performance) not tied to the groups above.


Terminology rule: NEVER use the term "GFMS" (or any internal system name for the findings source) in the output. Refer to it as "Findings" instead.

Do NOT create any other sections (no "Key Scope Drivers", "Historical Context", etc.). Fold any relevant analysis into the questions of the appropriate group above.

- Also produce a single `rationale` covering the whole report, following the "RATIONALE GENERATION INSTRUCTIONS" and "RATIONALE OUTPUT STRUCTURE" at the end of this prompt.
- Also produce a `confidence_score` for the whole report, following the "CONFIDENCE SCORE INSTRUCTIONS" at the end of this prompt.

Quality and mapping rules:
1. Use ONLY the data provided in the preliminary report; do not invent, assume, or infer any facts, names (KODs, controls, risks, AUs, findings, regulations), IDs, dates, or statuses that are not present in it. Base all analysis strictly on that data.
2. Explicitly map discovered evidence to the relevant themes from the question bank.
3. Prioritize points by risk significance and potential scope impact.
4. When evidence is missing for an important question-bank theme, include a targeted verification question under the most relevant group (or "Generic").
5. Keep each key point concise, specific, and decision-useful.
6. Remove duplicates but preserve materially different nuances across regions, entities, or control types.
7. Include references to control design, operating effectiveness, ownership (global vs regional), governance/escalation, automation parameters, and exception handling where evidenced.

Instructions:
1. Read the entire "Preliminary Research Report" provided below.
2. Identify critical facts, risks, controls, gaps, open issues, and dependencies.
3. Organize the gaps and assumptions into the groups of the single required section.
4. Within each group, provide key points as concise verification questions, each stating the gap/assumption and the specific evidence or document to request.
5. Ensure the output strictly follows the structured format required by the DiscoveryWalkthroughReport model.


## RATIONALE GENERATION INSTRUCTIONS:

The goal is to explain the core logic/reasoning used to build the Discovery Walkthrough Preparation report — the key evidence relied on and the analysis performed to arrive at the gaps, assumptions, and open questions — NOT to re-list or re-explain the report content itself.

Understand the intent of this report: it surfaces the current review's gaps, assumptions, and open verification questions. Each group is driven by a core requirement (e.g., an annual regulatory mandate, an open audit finding that makes a control untestable, a mandatory bank/regulatory policy, or a precedent from a prior-year review). The rationale must convey WHY those points are requirements, grounded in that evidence.

Core Principles for Writing the Rationale
1.  **STRICT ADHERENCE TO EVIDENCE:** Rely only on the provided preliminary research data and evidence. Do not assume or extrapolate.
2.  **CORE REASONING WITH DATA:** Present the key data points (open findings, key controls, policies, regulatory obligations, prior-review precedent) and the analysis performed on them. Explain the underlying logic — for example, a control is a scope driver because it carries an open high-rated finding that must be closed per audit rules — rather than restating the listed points.
3.  **QUALITY OVER QUANTITY:** Across all groups, prioritize only the most material gaps and assumptions. Deliver deep, high-impact reasoning over a broad list of weak associations.
4.  **COVER THE CORE OF THE REASONING:** Within a single paragraph, convey:
        1. The core requirement or driver behind the report's key points (the "why it matters").
        2. How it was identified (from which source/analysis).
        3. The reasoning behind any derived or secondary elements (e.g., why alternative scope areas or open questions follow).
        4. Ground every key selection in its source (e.g., open audit finding, mandatory policy, regulatory obligation, prior-year review).

## RATIONALE OUTPUT STRUCTURE:

The generated `rationale` MUST follow these output rules:
1.  **SINGLE COHERENT PARAGRAPH:** Provide exactly one rationale covering all groups of the report as one unified explanation. Do NOT write a separate rationale per group, and do NOT use bullet points, numbered lists, or headers.
2.  **SHORT AND OPTIMAL LENGTH:** Keep the rationale short — optimally 3-4 lines, and never more than 4-5 lines. Prioritize the most important drivers to fit this limit.
3.  **DO NOT START WITH "This paragraph":** Never begin with phrases like "This paragraph" or "This report". Describe the reasoning directly.
4.  **NO CONFIDENCE SCORE EXPLANATION:** Do NOT explain, justify, or reference any confidence score — never state why a score is high or low, nor how data gaps affect it.
5.  **NO LIMITATIONS OR DATA GAPS:** Do NOT mention limitations, data gaps, missing/null fields, absence of information, or lack of detail. Focus strictly on the core reasoning and the evidence that WAS used to reach the conclusions.

## CONFIDENCE SCORE INSTRUCTIONS:

Produce a `confidence_score` as an integer between 0 and 100. First analyse the gaps and limitations in the provided preliminary research data (e.g., missing themes from the question bank, absent control/finding details, incomplete governance or historical context), THEN assign a score consistent with those gaps (more or larger gaps => lower score).
The score reflects the Evidence Sufficiency and Response Completeness: how relevant and complete the provided preliminary research is, and how completely the report satisfies the required sections and question-bank coverage.
**Score Scale:**
    *   **80 - 100:** Evidence is highly relevant and complete; the report fully meets the requirements with no material gaps.
    *   **60 - 79:** Evidence is largely sufficient; only minor gaps that do not affect key conclusions.
    *   **40 - 59:** Partial evidence; notable gaps or missing fields affect some conclusions.
    *   **20 - 39:** Weak evidence; major gaps, with several required areas Data Not Available.
    *   **0 - 19:** Little to no usable evidence for this report.

"""
