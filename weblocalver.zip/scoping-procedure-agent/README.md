# Scoping Procedure Agent

FastAPI service (root path `/scoping-procedure-agent`, default port `8001`) that generates and manages the procedural documentation artifacts for a scope: meeting notes summaries, in-scope/out-scope determinations, discovery walkthroughs, and test steps. Supports generate/get/update operations for each artifact, file uploads for source documents, and PDF export. Uses Vertex AI for LLM-assisted content generation.

## Endpoints

| Method | Path                                        | Description                                                         |
| ------ | ------------------------------------------- | ------------------------------------------------------------------- |
| GET    | `/health`                                   | Health check                                                        |
| POST   | `/meeting-notes`, `/generate-meeting-notes` | Upload meeting note/MOM documents and generate a normalized summary |
| POST   | `/get-meeting-notes-summary`                | Retrieve stored meeting notes summary                               |
| POST   | `/generate-inscope-outscope`                | Generate in-scope/out-scope determinations                          |
| POST   | `/get-inscope-outscope`                     | Retrieve stored in-scope/out-scope data                             |
| PUT    | `/update-inscope-outscope`                  | Update in-scope/out-scope determinations                            |
| POST   | `/generate-discovery-walkthrough`           | Generate a discovery walkthrough report                             |
| POST   | `/get-discovery-walkthrough`                | Retrieve stored discovery walkthrough report                        |
| PUT    | `/update-discovery-walkthrough`             | Update discovery walkthrough report                                 |
| POST   | `/generate-test-steps`                      | Generate test steps                                                 |
| POST   | `/get-test-steps`                           | Retrieve stored test steps                                          |
| POST   | `/refine-test-steps`                        | Apply exclusions to test steps for review                           |
| PUT    | `/update-test-steps`                        | Update test steps                                                   |
| POST   | `/download-discovery-walkthrough`           | Export discovery walkthrough as PDF                                 |
| POST   | `/download-inscope-outscope`                | Export in-scope/out-scope as PDF                                    |
| POST   | `/download-test-steps`                      | Export test steps as PDF                                            |
| POST   | `/generate-scoping-document`           | Load or generate the editable scoping-document HTML editor           |
| PUT    | `/update-scoping-document`                  | Save the complete editable document model to GCS                      |
| POST   | `/download-scoping-document`        | Render the saved editable model as a paginated PDF                    |

The HTML editor keeps the document layout server-controlled, allows edits to the values in the document title and table cells (row keys are locked), and saves the edited content as JSON. Its **Download PDF** action fetches the saved JSON and renders it with the paginated PDF renderer, so the PDF always matches what the editor shows.

## Configuration

- `src/main/config/config.py` — application settings
- `src/main/config/prompts.py` — LLM prompt templates
- `src/main/config/template.py` — document template configuration

The scope recommendation LLM judge loop is controlled by `SCOPE_RECOMMENDATION_JUDGE_LOOP` (or `JUDGE_LOOP` / `judge_loop`, default `false`). When set to `false`, the initial candidate output passes through without running the judge loop; set to `true` to enable bounded review and revision.

## Running locally

```bash
pip install -r requirements.txt
python src/main/app.py
```

## Testing

```bash
pytest src/tests
```

## Docker / Helm

Build via the provided `Dockerfile`; deploy with the Helm chart in `helm-chart/` (`values-dev1.yaml`, `values-ct1.yaml`, `values-uat1.yaml`).

Persists data in table also.
