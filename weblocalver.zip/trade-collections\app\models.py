"""Domain schemas for the Trade Collections maker workbench.

These are the contract between the UI and whatever backend eventually serves
it (WFMS / TradePay intake, OEMS tariffs, TF3 hand-off). Swap the store in
``store.py``; the templates keep working as long as these shapes hold.
"""

from __future__ import annotations

import re

from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# enums + lookups
# ---------------------------------------------------------------------------

class CaseStatus(str, Enum):
    RECEIVED = "received"
    AI_PROCESSING = "ai_processing"
    NEEDS_ATTENTION = "needs_attention"
    READY_FOR_REVIEW = "ready_for_review"
    IN_CHECKER_QUEUE = "checker_queue"
    COMPLETED = "completed"
    RETURNED = "returned"


STATUS_LABELS: dict[str, str] = {
    "received": "Received",
    "ai_processing": "Processing",
    "needs_attention": "Needs attention",
    "ready_for_review": "Ready for review",
    "checker_queue": "With checker",
    "completed": "Completed",
    "returned": "Returned to maker",
}

STATUS_TONES: dict[str, str] = {
    "received": "neutral",
    "ai_processing": "info",
    "needs_attention": "warn",
    "ready_for_review": "ok",
    "checker_queue": "violet",
    "completed": "done",
    "returned": "bad",
}

FieldStatus = Literal["auto", "accepted", "overridden", "unresolved"]
CheckStatus = Literal["pass", "fail", "warn", "pending", "resolved"]
StageState = Literal["done", "running", "queued", "attention", "blocked"]


# ---------------------------------------------------------------------------
# extraction
# ---------------------------------------------------------------------------

class ExtractedField(BaseModel):
    """One field lifted from a document, with its provenance.

    ``anchor`` ties the field to a ``data-anchor`` span in the rendered
    document so the viewer can highlight where the value came from.
    """

    key: str
    group: Literal["transaction", "parties", "ports", "references"]
    label: str
    value: str
    confidence: float
    source_doc: str
    source_page: int
    anchor: str
    status: FieldStatus = "auto"
    original_value: str | None = None
    note: str | None = None

    @property
    def low_confidence(self) -> bool:
        return self.confidence < 0.85

    @property
    def confidence_pct(self) -> int:
        return round(self.confidence * 100)


class DocumentFile(BaseModel):
    doc_id: str
    name: str
    kind: Literal["Invoice", "Transport", "Instruction", "Supporting"]
    pages: int
    received_at: datetime
    classified_by: Literal["WFMS", "TradePay"]
    # Rendered as a synthetic page in the viewer; values keyed by anchor id.
    render: dict[str, str] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# checks, charges, queries
# ---------------------------------------------------------------------------

class ComparedField(BaseModel):
    field: str
    document: str
    record: str

    @property
    def matches(self) -> bool:
        return self.document.strip().lower() == self.record.strip().lower()


class Check(BaseModel):
    id: str
    group: Literal["duplicate", "consistency", "fema", "fiu"]
    label: str
    status: CheckStatus
    detail: str
    evidence: str
    rule_version: str
    compared: list[ComparedField] = Field(default_factory=list)
    resolution: str | None = None
    resolved_by: str | None = None
    resolved_at: datetime | None = None

    @property
    def blocking(self) -> bool:
        return self.status in ("fail", "warn")


class ChargeLine(BaseModel):
    code: str
    label: str
    basis: str
    amount_inr: float
    overridden: bool = False
    waiver_reason: str | None = None


class Charges(BaseModel):
    tariff_ref: str
    tariff_source: str = "OEMS via Autobahn processing instructions"
    product: str = "Comm Direct Docs"
    status: Literal["calculated", "pending", "blocked"] = "pending"
    calculated_at: datetime | None = None
    lines: list[ChargeLine] = Field(default_factory=list)

    @property
    def total(self) -> float:
        return round(sum(line.amount_inr for line in self.lines), 2)


class Query(BaseModel):
    query_id: str
    check_id: str | None = None
    recipient: str
    reason: str
    raised_by: str
    raised_at: datetime
    status: Literal["open", "answered", "closed"] = "open"
    response: str | None = None


class AuditEntry(BaseModel):
    at: datetime
    actor: str
    role: Literal["System", "AI", "Maker", "Checker"]
    action: str
    detail: str


class Stage(BaseModel):
    """One band of the automated pipeline, as drawn on the flow slide."""

    key: Literal["intake", "entity", "checks", "charges", "tf3"]
    label: str
    state: StageState
    note: str = ""


# ---------------------------------------------------------------------------
# case
# ---------------------------------------------------------------------------

class CollectionCase(BaseModel):
    case_id: str
    received_at: datetime
    source: Literal["WFMS", "TradePay"]
    customer: str
    customer_id: str
    direction: Literal["Export", "Import"]
    terms: Literal["D/P", "D/A"]
    currency: str
    principal: float
    boe_number: str
    boe_duplicate_of: str | None = None
    tf3_reference: str
    status: CaseStatus
    priority: Literal["high", "medium", "low"] = "medium"
    assignee: str | None = None
    sla_due: datetime | None = None

    fields: list[ExtractedField] = Field(default_factory=list)
    documents: list[DocumentFile] = Field(default_factory=list)
    checks: list[Check] = Field(default_factory=list)
    charges: Charges
    queries: list[Query] = Field(default_factory=list)
    audit: list[AuditEntry] = Field(default_factory=list)
    stages: list[Stage] = Field(default_factory=list)

    processing_started: datetime | None = None
    processing_seconds: float = 12.0
    completed_at: datetime | None = None
    returned_reason: str | None = None

    # -- derived ------------------------------------------------------------
    @property
    def status_label(self) -> str:
        return STATUS_LABELS[self.status.value]

    @property
    def status_tone(self) -> str:
        return STATUS_TONES[self.status.value]

    @property
    def principal_display(self) -> str:
        return f"{self.currency} {self.principal:,.0f}"

    @property
    def collection_display(self) -> str:
        return f"{self.direction} / {self.terms}"

    @property
    def open_exceptions(self) -> list[Check]:
        return [c for c in self.checks if c.blocking]

    @property
    def open_queries(self) -> list[Query]:
        return [q for q in self.queries if q.status == "open"]

    @property
    def checks_passed(self) -> int:
        return sum(1 for c in self.checks if c.status in ("pass", "resolved"))

    @property
    def checks_total(self) -> int:
        return len(self.checks)

    @property
    def unresolved_fields(self) -> list[ExtractedField]:
        return [f for f in self.fields if f.status == "unresolved"]

    @property
    def low_confidence_fields(self) -> list[ExtractedField]:
        return [f for f in self.fields if f.low_confidence and f.status == "auto"]

    @property
    def ready_to_validate(self) -> bool:
        return (
            self.status in (CaseStatus.READY_FOR_REVIEW, CaseStatus.NEEDS_ATTENTION, CaseStatus.RETURNED)
            and not self.open_exceptions
            and not self.unresolved_fields
            and self.charges.status == "calculated"
        )

    @property
    def blockers(self) -> list[str]:
        out: list[str] = []
        if self.unresolved_fields:
            out.append(
                f"{len(self.unresolved_fields)} field(s) need a maker value"
            )
        if self.open_exceptions:
            out.append(f"{len(self.open_exceptions)} open exception(s)")
        if self.charges.status != "calculated":
            out.append("charges not calculated")
        return out

    @property
    def sla_state(self) -> str:
        if self.sla_due is None or self.status in (CaseStatus.COMPLETED, CaseStatus.IN_CHECKER_QUEUE):
            return "none"
        remaining = self.sla_due - datetime.now()
        if remaining < timedelta(0):
            return "breached"
        if remaining < timedelta(minutes=45):
            return "due"
        return "ok"

    @property
    def sla_display(self) -> str:
        if self.sla_due is None:
            return "-"
        delta = self.sla_due - datetime.now()
        minutes = int(abs(delta).total_seconds() // 60)
        hours, minutes = divmod(minutes, 60)
        text = f"{hours}h {minutes:02d}m" if hours else f"{minutes}m"
        return f"{text} over" if delta.total_seconds() < 0 else text

    # -- what the maker actually has to do -----------------------------------
    @property
    def action_items(self) -> list[dict[str, str]]:
        """The concrete things standing between this case and a decision.

        Plain language, in the order a maker would work them. An empty list
        means the case is ready to validate.
        """
        items: list[dict[str, str]] = []
        for f in self.unresolved_fields:
            items.append({
                "kind": "field",
                "id": f.key,
                "title": f"{f.label} could not be read.",
                "detail": f.note or f"No value was found for {f.label.lower()}.",
            })
        for c in self.open_exceptions:
            # The rule's name means nothing to a maker. Lead with the first
            # sentence of the finding, which already says what is wrong, and
            # keep whatever follows as the explanation. Splitting only on a
            # period followed by whitespace leaves decimals like 58,900.00 intact.
            parts = re.split(r"\.\s+(?=[A-Z])", c.detail.strip(), maxsplit=1)
            head = parts[0].rstrip(".")
            items.append({
                "kind": "check",
                "id": c.id,
                "title": head + "." if head else c.detail,
                "detail": parts[1] if len(parts) > 1 else "",
                "rule": c.label,
            })
        return items

    @property
    def headline(self) -> str:
        """One line telling the maker where this case stands."""
        if self.status is CaseStatus.RECEIVED:
            return "Waiting to be processed"
        if self.status is CaseStatus.AI_PROCESSING:
            return "Being processed"
        if self.status is CaseStatus.IN_CHECKER_QUEUE:
            return "With the checker"
        if self.status is CaseStatus.COMPLETED:
            return "Closed"
        if self.status is CaseStatus.RETURNED:
            return f"Sent back: {self.returned_reason or 'see the activity log'}"
        items = self.action_items
        if not items:
            return "All checks passed - ready to validate"
        first = items[0]["title"]
        if len(items) > 1:
            return f"{first.rstrip('.')}, and {len(items) - 1} more."
        return first

    @property
    def needs_maker(self) -> bool:
        return bool(self.action_items) and self.status not in (
            CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING,
            CaseStatus.IN_CHECKER_QUEUE, CaseStatus.COMPLETED,
        )

    @property
    def checked_summary(self) -> str:
        """The reassurance line: what the pipeline did so the maker need not."""
        passed = [c for c in self.checks if c.status in ("pass", "resolved")]
        return (f"{len(self.fields)} fields read from {len(self.documents)} documents, "
                f"{len(passed)} of {len(self.checks)} checks passed")

    def field(self, key: str) -> ExtractedField | None:
        return next((f for f in self.fields if f.key == key), None)

    def document(self, doc_id: str) -> DocumentFile | None:
        return next((d for d in self.documents if d.doc_id == doc_id), None)


# ---------------------------------------------------------------------------
# reference data
# ---------------------------------------------------------------------------

class PortEntry(BaseModel):
    code: str
    name: str
    country: str
    region: str


class ClientTariff(BaseModel):
    customer_id: str
    customer: str
    tariff_ref: str
    product: str = "Comm Direct Docs"
    commission_bps: float
    minimum_inr: float
    swift_inr: float
    handling_inr: float
    gst_pct: float = 18.0
    effective_from: str


class RuleSet(BaseModel):
    key: str
    label: str
    version: str
    owner: str
    updated: str
    conditions: int
    description: str


# ---------------------------------------------------------------------------
# request / response payloads
# ---------------------------------------------------------------------------

class FieldUpdate(BaseModel):
    value: str
    note: str | None = None


class CheckResolution(BaseModel):
    resolution: str


class QueryCreate(BaseModel):
    check_id: str | None = None
    reason: str
    recipient: str = "Branch operations"


class ValidationRequest(BaseModel):
    source_reviewed: bool = False
    exceptions_resolved: bool = False
    maker_note: str | None = None


class ActionResult(BaseModel):
    ok: bool
    message: str
    case_id: str
    status: str | None = None
    status_label: str | None = None
    status_tone: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)
