"""Illustrative book of work.

Nothing here is live. The shapes mirror what the WFMS / TradePay extraction
produces so the screens can be pointed at the real services unchanged.
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta

from .models import (
    AuditEntry,
    CaseStatus,
    ChargeLine,
    Charges,
    Check,
    ClientTariff,
    CollectionCase,
    ComparedField,
    DocumentFile,
    ExtractedField,
    PortEntry,
    Query,
    RuleSet,
    Stage,
)

NOW = datetime.now()  # the book of work is always relative to when the demo starts

MAKERS = ["R. Kadiam", "P. Shetty", "A. Varma", "N. Dsouza"]

# ---------------------------------------------------------------------------
# reference tables
# ---------------------------------------------------------------------------

PORTS: list[PortEntry] = [
    PortEntry(code="INNSA1", name="Jawaharlal Nehru (Nhava Sheva)", country="India", region="West"),
    PortEntry(code="INMUN1", name="Mundra", country="India", region="West"),
    PortEntry(code="INMAA1", name="Chennai", country="India", region="South"),
    PortEntry(code="INMAA4", name="Ennore (Kamarajar)", country="India", region="South"),
    PortEntry(code="INCOK1", name="Cochin", country="India", region="South"),
    PortEntry(code="INCCU1", name="Kolkata", country="India", region="East"),
    PortEntry(code="INPAV1", name="Pipavav", country="India", region="West"),
    PortEntry(code="SEMMA", name="Malmo", country="Sweden", region="Europe"),
    PortEntry(code="NOOSL", name="Oslo", country="Norway", region="Europe"),
    PortEntry(code="NOBGO", name="Bergen", country="Norway", region="Europe"),
    PortEntry(code="GBTYN", name="Tyne", country="United Kingdom", region="Europe"),
    PortEntry(code="GBLIV", name="Liverpool", country="United Kingdom", region="Europe"),
    PortEntry(code="GBFXT", name="Felixstowe", country="United Kingdom", region="Europe"),
    PortEntry(code="ESVLC", name="Valencia", country="Spain", region="Europe"),
    PortEntry(code="NLRTM", name="Rotterdam", country="Netherlands", region="Europe"),
    PortEntry(code="DEHAM", name="Hamburg", country="Germany", region="Europe"),
    PortEntry(code="AEJEA", name="Jebel Ali", country="United Arab Emirates", region="Middle East"),
    PortEntry(code="SGSIN", name="Singapore", country="Singapore", region="Asia"),
    PortEntry(code="USNYC", name="New York", country="United States", region="Americas"),
    PortEntry(code="USLAX", name="Los Angeles", country="United States", region="Americas"),
]

PORT_BY_CODE = {p.code: p for p in PORTS}

RULE_SETS: list[RuleSet] = [
    RuleSet(key="dup-boe", label="Bill of Entry uniqueness", version="v2.3", owner="Trade Ops",
            updated="2026-08-14", conditions=5,
            description="Flags a repeated Bill of Entry and separates the transactions on drawee name, "
                        "drawer name, port of loading and port of discharge."),
    RuleSet(key="consistency", label="Document / record consistency", version="v4.1", owner="Trade Ops",
            updated="2026-09-02", conditions=17,
            description="Compares currency, principal, parties, ports and tenor across every document "
                        "in the set and the intake record."),
    RuleSet(key="fema", label="FEMA rule set", version="v1.9", owner="Regulatory Compliance",
            updated="2026-07-29", conditions=6,
            description="Export realisation window, declaration references and contract value limits."),
    RuleSet(key="fiu", label="FIU rule set", version="v3.4", owner="Financial Crime",
            updated="2026-09-30", conditions=9,
            description="Counterparty, vessel and jurisdiction screening against the lists in force."),
]

TARIFFS: list[ClientTariff] = []


# ---------------------------------------------------------------------------
# counterparties
# ---------------------------------------------------------------------------

CLIENTS = [
    ("Aster Exports Pvt Ltd", "CUST-884120", "Plot 44, MIDC Industrial Area, Andheri East, Mumbai 400093, India"),
    ("Meridian Components Pvt Ltd", "CUST-771305", "Survey 118/2, Hosur Road, Bengaluru 560100, India"),
    ("Crestline Textiles Ltd", "CUST-650914", "19 Sarkhej Road, Ahmedabad 380055, India"),
    ("Northstar Engineering Pvt Ltd", "CUST-903441", "Plot 21, Sector 8, IMT Manesar, Gurugram 122051, India"),
    ("Harbourline Trading Co", "CUST-412076", "7 Marine Drive, Kochi 682001, India"),
    ("Vantage Agro Exports", "CUST-559832", "Unit 3, Krishnapatnam SEZ, Nellore 524344, India"),
    ("Deccan Alloys Ltd", "CUST-220417", "Plot 9, Patancheru Industrial Estate, Hyderabad 502319, India"),
    ("Saffron Marine Foods", "CUST-336508", "Dock Road, Veraval 362265, India"),
    ("Orient Polymer Industries", "CUST-128740", "Block C, Haldia Petrochemical Park, Haldia 721602, India"),
    ("Linden Pharma Exports", "CUST-704913", "Plot 55, Pharma City, Visakhapatnam 531021, India"),
]

COUNTERPARTIES = [
    ("Lindqvist Handel AB", "Hamngatan 12, 211 22 Malmo, Sweden", "SEMMA"),
    ("Brevik Industri AS", "Storgata 9, 3970 Langesund, Norway", "NOOSL"),
    ("Atlantic Linen Co", "4 Quayside, Liverpool L3 4AD, United Kingdom", "GBLIV"),
    ("Tyne Precision Ltd", "Unit 7, Benton Park Road, Newcastle NE7 7LX, United Kingdom", "GBTYN"),
    ("Cordoba Importaciones SL", "Calle Mayor 28, 14003 Cordoba, Spain", "ESVLC"),
    ("Rhein Chemie Handels GmbH", "Hafenstrasse 44, 20457 Hamburg, Germany", "DEHAM"),
    ("Delta Maritime Supplies FZE", "Warehouse 12, Jebel Ali Free Zone, Dubai, UAE", "AEJEA"),
    ("Keppel Trading Pte Ltd", "18 Tanjong Pagar Road, 088441 Singapore", "SGSIN"),
    ("Hudson Valley Imports LLC", "250 Water Street, New York NY 10038, United States", "USNYC"),
    ("Van Dijk Grondstoffen BV", "Waalhaven 210, 3089 JJ Rotterdam, Netherlands", "NLRTM"),
]

GOODS = [
    "Cotton yarn, combed, 30s count",
    "Aluminium extruded sections, mill finish",
    "Stainless steel precision components",
    "Frozen shrimp, HLSO, block frozen",
    "Polypropylene granules, injection grade",
    "Pharmaceutical intermediates, bulk drums",
    "Basmati rice, parboiled, 1121 grade",
    "Industrial valves, cast steel",
]


# ---------------------------------------------------------------------------
# builders
# ---------------------------------------------------------------------------

def _tariff_for(customer_id: str, customer: str, index: int) -> ClientTariff:
    return ClientTariff(
        customer_id=customer_id,
        customer=customer,
        tariff_ref=f"OEMS/{customer_id}/2026-{(index % 4) + 1:02d}",
        commission_bps=[6.25, 5.0, 7.5, 6.25][index % 4],
        minimum_inr=[1500, 1200, 2000, 1500][index % 4],
        swift_inr=750,
        handling_inr=500,
        effective_from=["2026-04-01", "2026-01-01", "2026-07-01", "2026-04-01"][index % 4],
    )


for i, (name, cid, _addr) in enumerate(CLIENTS):
    TARIFFS.append(_tariff_for(cid, name, i))

TARIFF_BY_CUSTOMER = {t.customer_id: t for t in TARIFFS}

FX = {"USD": 83.10, "EUR": 90.40, "GBP": 105.40, "AED": 22.62, "SGD": 61.80}


def _charges(customer_id: str, currency: str, principal: float, when: datetime | None,
             status: str = "calculated") -> Charges:
    tariff = TARIFF_BY_CUSTOMER[customer_id]
    if status != "calculated":
        return Charges(tariff_ref=tariff.tariff_ref, status=status, lines=[])

    rate = FX.get(currency, 83.0)
    inr_value = principal * rate
    commission = max(inr_value * tariff.commission_bps / 10_000, tariff.minimum_inr)
    fees = commission + tariff.swift_inr + tariff.handling_inr
    return Charges(
        tariff_ref=tariff.tariff_ref,
        status="calculated",
        calculated_at=when,
        lines=[
            ChargeLine(code="COMM", label="Collection commission",
                       basis=f"{tariff.commission_bps:.4g} bps on {currency} {principal:,.0f} @ {rate:.2f}",
                       amount_inr=round(commission, 2)),
            ChargeLine(code="SWFT", label="Swift / correspondence",
                       basis="Flat per collection", amount_inr=tariff.swift_inr),
            ChargeLine(code="HNDL", label="Document handling",
                       basis=f"Flat, {tariff.product}", amount_inr=tariff.handling_inr),
            ChargeLine(code="GST", label="GST",
                       basis=f"{tariff.gst_pct:.0f}% on fee lines",
                       amount_inr=round(fees * tariff.gst_pct / 100, 2)),
        ],
    )


def _documents(source: str, received: datetime, direction: str, render: dict[str, str]) -> list[DocumentFile]:
    transport_name = "Bill of lading" if direction == "Export" else "Air waybill"
    docs = [
        DocumentFile(doc_id="DOC-INV", name="Commercial invoice", kind="Invoice", pages=2,
                     received_at=received, classified_by=source, render=render),
        DocumentFile(doc_id="DOC-TRN", name=transport_name, kind="Transport", pages=1,
                     received_at=received, classified_by=source, render=render),
        DocumentFile(doc_id="DOC-ORD", name="Collection order", kind="Instruction", pages=1,
                     received_at=received + timedelta(minutes=1), classified_by=source, render=render),
    ]
    return docs


def _fields(spec: dict) -> list[ExtractedField]:
    """Build the extracted field set with per-field provenance."""
    pol = spec["pol"]
    pod = spec["pod"]
    pol_port = PORT_BY_CODE.get(pol)
    pod_port = PORT_BY_CODE.get(pod)

    def conf(key: str, default: float) -> float:
        return spec.get("confidence", {}).get(key, default)

    out = [
        ExtractedField(key="boe_number", group="references", label="Bill of Entry",
                       value=spec["boe"], confidence=conf("boe_number", 0.99),
                       source_doc="DOC-TRN", source_page=1, anchor="boe_number"),
        ExtractedField(key="invoice_no", group="references", label="Invoice number",
                       value=spec["invoice_no"], confidence=conf("invoice_no", 0.98),
                       source_doc="DOC-INV", source_page=1, anchor="invoice_no"),
        # On a currency or amount mismatch the invoice and the collection order
        # disagree, so the authoritative value is taken from the order and the
        # disagreement is what the consistency rule set reports.
        ExtractedField(key="currency", group="transaction", label="Currency",
                       value=spec["currency"], confidence=conf("currency", 0.99),
                       source_doc="DOC-ORD" if spec.get("exception") == "currency" else "DOC-INV",
                       source_page=1, anchor="currency",
                       note=(f"Collection order reads {spec['currency']}; the invoice reads "
                             f"{spec.get('doc_currency')}")
                            if spec.get("exception") == "currency" else None),
        ExtractedField(key="principal", group="transaction", label="Principal",
                       value=f"{spec['principal']:,.2f}", confidence=conf("principal", 0.98),
                       source_doc="DOC-ORD" if spec.get("exception") == "amount" else "DOC-INV",
                       source_page=1, anchor="principal",
                       note=(f"Collection order reads {spec['principal']:,.2f}; the invoice reads "
                             f"{spec.get('doc_principal', 0):,.2f}")
                            if spec.get("exception") == "amount" else None),
        ExtractedField(key="terms", group="transaction", label="Settlement terms",
                       value=spec["terms"], confidence=conf("terms", 0.97),
                       source_doc="DOC-ORD", source_page=1, anchor="terms"),
        ExtractedField(key="tenor", group="transaction", label="Tenor",
                       value=spec.get("tenor", "At sight"), confidence=conf("tenor", 0.96),
                       source_doc="DOC-ORD", source_page=1, anchor="tenor"),
        ExtractedField(key="drawer_name", group="parties", label="Drawer name",
                       value=spec["drawer_name"], confidence=conf("drawer_name", 0.97),
                       source_doc="DOC-INV", source_page=1, anchor="drawer_name"),
        ExtractedField(key="drawer_address", group="parties", label="Drawer address",
                       value=spec["drawer_address"], confidence=conf("drawer_address", 0.93),
                       source_doc="DOC-INV", source_page=1, anchor="drawer_address"),
        ExtractedField(key="drawee_name", group="parties", label="Drawee name",
                       value=spec["drawee_name"], confidence=conf("drawee_name", 0.96),
                       source_doc="DOC-INV", source_page=1, anchor="drawee_name"),
        ExtractedField(key="drawee_address", group="parties", label="Drawee address",
                       value=spec["drawee_address"], confidence=conf("drawee_address", 0.91),
                       source_doc="DOC-INV", source_page=1, anchor="drawee_address"),
        ExtractedField(key="port_loading", group="ports", label="Port of loading",
                       value=pol_port.name if pol_port else "",
                       confidence=conf("port_loading", 0.95),
                       source_doc="DOC-TRN", source_page=1, anchor="port_loading",
                       status="auto" if pol_port else "unresolved",
                       note=f"Short code {pol} resolved via port directory" if pol_port
                            else f"Short code {pol} did not resolve to a unique port",
                       original_value=pol),
        ExtractedField(key="port_discharge", group="ports", label="Port of discharge",
                       value=pod_port.name if pod_port else "",
                       confidence=conf("port_discharge", 0.95),
                       source_doc="DOC-TRN", source_page=1, anchor="port_discharge",
                       status="auto" if pod_port else "unresolved",
                       note=f"Short code {pod} resolved via port directory" if pod_port
                            else f"Short code {pod} did not resolve to a unique port",
                       original_value=pod),
    ]
    return out


def _render(spec: dict) -> dict[str, str]:
    pol_port = PORT_BY_CODE.get(spec["pol"])
    pod_port = PORT_BY_CODE.get(spec["pod"])
    return {
        "invoice_no": spec["invoice_no"],
        "invoice_date": spec["invoice_date"],
        "boe_number": spec["boe"],
        "currency": spec["currency"],
        "principal": f"{spec['principal']:,.2f}",
        "doc_currency": spec.get("doc_currency", spec["currency"]),
        "doc_principal": f"{spec.get('doc_principal', spec['principal']):,.2f}",
        "terms": spec["terms"],
        "tenor": spec.get("tenor", "At sight"),
        "drawer_name": spec["drawer_name"],
        "drawer_address": spec["drawer_address"],
        "drawee_name": spec["drawee_name"],
        "drawee_address": spec["drawee_address"],
        "port_loading": spec["pol"],
        "port_loading_full": pol_port.name if pol_port else "- unresolved -",
        "port_discharge": spec["pod"],
        "port_discharge_full": pod_port.name if pod_port else "- unresolved -",
        "goods": spec["goods"],
        "vessel": spec.get("vessel", "MV Southern Trader / V.218"),
        "incoterm": spec.get("incoterm", "FOB"),
        "quantity": spec.get("quantity", "1 x 40' FCL"),
    }


def _checks(spec: dict) -> list[Check]:
    exc = spec.get("exception")
    boe = spec["boe"]
    source = spec["source"]
    stamp = spec["received"]

    dup = Check(
        id="CHK-DUP-BOE", group="duplicate", label="Bill of Entry uniqueness",
        status="pass",
        detail=f"Bill of Entry {boe} is unique across the open book.",
        evidence="Intake BoE index - 2,418 open transactions scanned",
        rule_version="dup-boe v2.3",
        compared=[ComparedField(field="Bill of Entry", document=boe, record=boe)],
    )
    consistency = Check(
        id="CHK-CONSISTENCY", group="consistency", label="Document / record consistency",
        status="pass",
        detail="Currency, principal, parties and ports agree across the document set and the intake record.",
        evidence=f"3 documents - 17 fields compared",
        rule_version="consistency v4.1",
        compared=[
            ComparedField(field="Currency", document=spec["currency"], record=spec["currency"]),
            ComparedField(field="Principal", document=f"{spec['principal']:,.2f}", record=f"{spec['principal']:,.2f}"),
            ComparedField(field="Drawee name", document=spec["drawee_name"], record=spec["drawee_name"]),
            ComparedField(field="Port of loading", document=spec["pol"], record=spec["pol"]),
            ComparedField(field="Port of discharge", document=spec["pod"], record=spec["pod"]),
        ],
    )
    fema = Check(
        id="CHK-FEMA", group="fema", label="FEMA rule set", status="pass",
        detail=("Export realisation window and declaration references present; value within the declared contract."
                if spec["direction"] == "Export" else
                "Import payment conditions satisfied against the declared contract value."),
        evidence="FEMA checklist - 6 of 6 conditions met",
        rule_version="fema v1.9",
    )
    fiu = Check(
        id="CHK-FIU", group="fiu", label="FIU rule set", status="pass",
        detail="No counterparty, vessel or jurisdiction hit against the screening lists in force.",
        evidence=f"Screening run {stamp.strftime('%d %b %H:%M')} - list build 2026-09-30",
        rule_version="fiu v3.4",
    )

    if exc == "currency":
        consistency.status = "fail"
        consistency.detail = (
            f"Invoice is denominated in {spec['doc_currency']}; the collection order states "
            f"{spec['currency']}. The collection cannot be booked until the currency is confirmed."
        )
        consistency.evidence = "3 documents - 17 fields compared - 1 mismatch"
        consistency.compared[0] = ComparedField(
            field="Currency", document=spec["doc_currency"], record=spec["currency"])
    elif exc == "amount":
        consistency.status = "fail"
        consistency.detail = (
            f"Invoice total is {spec['currency']} {spec['doc_principal']:,.2f}; the collection order "
            f"states {spec['currency']} {spec['principal']:,.2f}."
        )
        consistency.evidence = "3 documents - 17 fields compared - 1 mismatch"
        consistency.compared[1] = ComparedField(
            field="Principal", document=f"{spec['doc_principal']:,.2f}", record=f"{spec['principal']:,.2f}")
    elif exc == "drawee":
        consistency.status = "fail"
        consistency.detail = (
            "Drawee on the transport document does not match the collection order. "
            "Confirm the correct buying entity before the documents are released."
        )
        consistency.evidence = "3 documents - 17 fields compared - 1 mismatch"
        consistency.compared[2] = ComparedField(
            field="Drawee name", document=spec["drawee_name"],
            record=spec["drawee_name"].replace("Ltd", "Limited").replace("AB", "A/B"))
    elif exc == "duplicate":
        dup.status = "warn"
        dup.detail = (
            f"Bill of Entry {boe} is already present on {spec['duplicate_of']}. Secondary match on "
            "drawee name, drawer name, port of loading and port of discharge separates the two "
            "transactions; confirm before proceeding."
        )
        dup.evidence = "Intake BoE index - 1 collision found"
        dup.compared = [
            ComparedField(field="Bill of Entry", document=boe, record=boe),
            ComparedField(field="Drawee name", document=spec["drawee_name"], record=spec["drawee_name"]),
            ComparedField(field="Drawer name", document=spec["drawer_name"], record="Nordkapp Systems AS"),
            ComparedField(field="Port of loading", document=spec["pol"], record="NOBGO"),
        ]
    elif exc == "port":
        consistency.status = "fail"
        consistency.detail = (
            f"Port short code did not resolve to a unique entry in the port directory. "
            "The full name is required before the record is posted."
        )
        consistency.evidence = "3 documents - 17 fields compared - 1 unresolved"
        consistency.compared[4] = ComparedField(
            field="Port of discharge", document=spec["pod"], record="unresolved")
    elif exc == "fiu":
        fiu.status = "warn"
        fiu.detail = (
            "Vessel name is a partial match to an entry on the watch list. Review the screening "
            "evidence and record a disposition."
        )
        fiu.evidence = f"Screening run {stamp.strftime('%d %b %H:%M')} - 1 partial match"

    return [dup, consistency, fema, fiu]


def _stages(status: CaseStatus, spec: dict) -> list[Stage]:
    exc = spec.get("exception")
    if status is CaseStatus.RECEIVED:
        states = ["done", "queued", "queued", "queued", "queued"]
    elif status is CaseStatus.AI_PROCESSING:
        states = ["done", "done", "running", "queued", "queued"]
    elif status is CaseStatus.NEEDS_ATTENTION:
        states = ["done", "done" if exc != "port" else "attention", "attention",
                  "blocked" if exc in ("currency", "amount") else "done", "queued"]
    else:
        states = ["done", "done", "done", "done", "done"]

    labels = [
        ("intake", "Intake and extraction"),
        ("entity", "Entity retrieval and matching"),
        ("checks", "Consistency, FEMA and FIU"),
        ("charges", "Charge calculation"),
        ("tf3", "TF3 update"),
    ]
    return [Stage(key=k, label=l, state=s) for (k, l), s in zip(labels, states)]


def _audit(spec: dict, status: CaseStatus) -> list[AuditEntry]:
    t = spec["received"]
    source = spec["source"]
    rows = [
        AuditEntry(at=t, actor=source, role="System", action="Case received",
                   detail=f"Document set classified and extracted; 3 documents."),
    ]
    if status is CaseStatus.RECEIVED:
        return rows

    rows.append(AuditEntry(at=t + timedelta(minutes=1), actor="AI engine", role="AI",
                           action="Entity retrieved",
                           detail=f"Customer extract matched to {spec['customer_id']}."))
    if status is CaseStatus.AI_PROCESSING:
        rows.append(AuditEntry(at=t + timedelta(minutes=1), actor="AI engine", role="AI",
                               action="Processing started",
                               detail="Rule evaluation running across the document set."))
        return rows

    pol_port = PORT_BY_CODE.get(spec["pol"])
    pod_port = PORT_BY_CODE.get(spec["pod"])
    rows.append(AuditEntry(
        at=t + timedelta(minutes=1), actor="AI engine", role="AI", action="Ports resolved",
        detail=f"{spec['pol']} to {pol_port.name if pol_port else 'unresolved'}; "
               f"{spec['pod']} to {pod_port.name if pod_port else 'unresolved'}."))

    exc = spec.get("exception")
    if exc:
        rows.append(AuditEntry(at=t + timedelta(minutes=2), actor="AI engine", role="AI",
                               action="Exception raised",
                               detail={
                                   "currency": "Currency mismatch between invoice and collection order.",
                                   "amount": "Principal mismatch between invoice and collection order.",
                                   "drawee": "Drawee name mismatch between transport document and order.",
                                   "duplicate": f"Bill of Entry collides with {spec.get('duplicate_of')}.",
                                   "port": "Port short code did not resolve uniquely.",
                                   "fiu": "Partial vessel match on the FIU watch list.",
                               }[exc]))
    else:
        rows.append(AuditEntry(at=t + timedelta(minutes=2), actor="AI engine", role="AI",
                               action="Checks evaluated",
                               detail="All rule sets passed; no exceptions raised."))
        rows.append(AuditEntry(at=t + timedelta(minutes=2), actor="AI engine", role="AI",
                               action="Charges calculated",
                               detail=f"Tariff applied; total posted to the case."))

    if status in (CaseStatus.IN_CHECKER_QUEUE, CaseStatus.COMPLETED):
        rows.append(AuditEntry(at=t + timedelta(minutes=14), actor=spec.get("assignee") or "Maker",
                               role="Maker", action="Validated",
                               detail="Source data reviewed and exceptions cleared; released to the checker queue."))
        rows.append(AuditEntry(at=t + timedelta(minutes=14), actor="TF3", role="System",
                               action="TF3 updated",
                               detail=f"Final data and charges posted against {spec['tf3']}."))
    if status is CaseStatus.COMPLETED:
        rows.append(AuditEntry(at=t + timedelta(minutes=26), actor="S. Iyer", role="Checker",
                               action="Approved",
                               detail="Checker controls complete; transaction closed."))
    return rows


def _build(spec: dict) -> CollectionCase:
    status = spec["status"]
    received = spec["received"]
    render = _render(spec)

    charge_status = "calculated"
    if status in (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING):
        charge_status = "pending"
    elif spec.get("exception") in ("currency", "amount"):
        charge_status = "blocked"

    case = CollectionCase(
        case_id=spec["case_id"],
        received_at=received,
        source=spec["source"],
        customer=spec["customer"],
        customer_id=spec["customer_id"],
        direction=spec["direction"],
        terms=spec["terms"],
        currency=spec["currency"],
        principal=spec["principal"],
        boe_number=spec["boe"],
        boe_duplicate_of=spec.get("duplicate_of"),
        tf3_reference=spec["tf3"],
        status=status,
        priority=spec.get("priority", "medium"),
        assignee=spec.get("assignee"),
        sla_due=received + timedelta(hours=spec.get("sla_hours", 8)),
        fields=_fields(spec),
        documents=_documents(spec["source"], received, spec["direction"], render),
        checks=_checks(spec),
        charges=_charges(spec["customer_id"], spec["currency"], spec["principal"],
                         received + timedelta(minutes=2), charge_status),
        stages=_stages(status, spec),
        audit=_audit(spec, status),
        completed_at=received + timedelta(minutes=26) if status is CaseStatus.COMPLETED else None,
    )

    if status is CaseStatus.AI_PROCESSING:
        case.processing_started = datetime.now() - timedelta(seconds=spec.get("elapsed", 2))
        case.processing_seconds = spec.get("duration", 25)

    if spec.get("exception") == "duplicate":
        case.priority = "high"

    if spec.get("query"):
        case.queries.append(Query(
            query_id=spec["query"]["id"], check_id=spec["query"].get("check_id"),
            recipient="Branch operations", reason=spec["query"]["reason"],
            raised_by=spec.get("assignee") or "R. Kadiam",
            raised_at=received + timedelta(minutes=9), status="open"))
        case.audit.append(AuditEntry(
            at=received + timedelta(minutes=9), actor=spec.get("assignee") or "R. Kadiam",
            role="Maker", action="Query raised",
            detail=f"{spec['query']['id']} to Branch operations: {spec['query']['reason']}"))

    return case


# ---------------------------------------------------------------------------
# the book of work
# ---------------------------------------------------------------------------

def _spec(idx: int, case_no: int, status: CaseStatus, **kw) -> dict:
    rnd = random.Random(case_no)
    client = CLIENTS[idx % len(CLIENTS)]
    cp = COUNTERPARTIES[(idx * 3 + 1) % len(COUNTERPARTIES)]
    direction = kw.get("direction", "Export" if idx % 2 == 0 else "Import")
    currency = kw.get("currency", ["USD", "EUR", "GBP", "USD", "SGD"][idx % 5])
    principal = kw.get("principal", rnd.choice([31_250, 48_900, 74_600, 92_400, 128_400, 185_000, 56_800, 212_500]))
    pol = kw.get("pol", "INNSA1" if direction == "Export" else cp[2])
    pod = kw.get("pod", cp[2] if direction == "Export" else "INNSA1")
    minutes = kw.get("age_minutes", 40 + idx * 37)

    spec = {
        "case_id": f"COL-{case_no}",
        "received": NOW - timedelta(minutes=minutes),
        "source": kw.get("source", "WFMS" if idx % 2 == 0 else "TradePay"),
        "customer": client[0],
        "customer_id": client[1],
        "direction": direction,
        "terms": kw.get("terms", "D/P" if idx % 3 else "D/A"),
        "currency": currency,
        "principal": float(principal),
        "boe": kw.get("boe", f"{7_700_000 + case_no * 13}"),
        "tf3": f"TF3-COL-2026-{case_no}",
        "invoice_no": f"INV/{2026}/{4000 + case_no}",
        "invoice_date": (NOW - timedelta(minutes=minutes, days=3)).strftime("%d %b %Y"),
        "drawer_name": client[0] if direction == "Export" else cp[0],
        "drawer_address": client[2] if direction == "Export" else cp[1],
        "drawee_name": cp[0] if direction == "Export" else client[0],
        "drawee_address": cp[1] if direction == "Export" else client[2],
        "pol": pol,
        "pod": pod,
        "goods": GOODS[idx % len(GOODS)],
        "status": status,
        "vessel": rnd.choice(["MV Southern Trader / V.218", "MV Baltic Dawn / V.044",
                              "MV Cape Meridian / V.117", "MV Orient Star / V.309"]),
        "quantity": rnd.choice(["1 x 40' FCL", "2 x 20' FCL", "3 x 40' HC", "LCL 14.2 CBM"]),
    }
    spec.update({k: v for k, v in kw.items() if k not in spec or k in
                 ("terms", "currency", "principal", "pol", "pod", "source", "direction")})
    return spec


def build_cases() -> list[CollectionCase]:
    specs: list[dict] = []

    # -- needs attention, one per exception type ----------------------------
    s = _spec(1, 10481, CaseStatus.NEEDS_ATTENTION, direction="Import", currency="EUR",
              principal=92_400, age_minutes=117, source="TradePay")
    s.update(exception="currency", doc_currency="USD", assignee="R. Kadiam", priority="high",
             boe="6610277", duplicate_of=None)
    specs.append(s)

    s = _spec(5, 10477, CaseStatus.NEEDS_ATTENTION, direction="Export", currency="USD",
              principal=128_400, age_minutes=186, source="WFMS")
    s.update(exception="duplicate", duplicate_of="COL-10455", boe="7719085",
             assignee="R. Kadiam", priority="high")
    specs.append(s)

    s = _spec(3, 10474, CaseStatus.NEEDS_ATTENTION, direction="Import", currency="GBP",
              principal=48_900, age_minutes=243, source="TradePay", pod="INMAA7")
    s.update(exception="port", assignee="P. Shetty")
    specs.append(s)

    s = _spec(7, 10470, CaseStatus.NEEDS_ATTENTION, direction="Export", currency="USD",
              principal=56_800, age_minutes=302, source="WFMS")
    s.update(exception="amount", doc_principal=58_900.0, assignee="A. Varma",
             query={"id": "QRY-4087", "check_id": "CHK-CONSISTENCY",
                    "reason": "Confirm whether the invoice total or the collection order amount is correct."})
    specs.append(s)

    s = _spec(9, 10466, CaseStatus.NEEDS_ATTENTION, direction="Import", currency="USD",
              principal=212_500, age_minutes=365, source="TradePay")
    s.update(exception="fiu", assignee="N. Dsouza", priority="high")
    specs.append(s)

    s = _spec(2, 10463, CaseStatus.NEEDS_ATTENTION, direction="Export", currency="EUR",
              principal=74_600, age_minutes=412)
    s.update(exception="drawee", assignee="P. Shetty")
    specs.append(s)

    # -- ready for review ---------------------------------------------------
    ready = [
        (0, 10482, dict(direction="Export", currency="USD", principal=185_000, age_minutes=93, boe="7731904", assignee="R. Kadiam", priority="high")),
        (3, 10479, dict(direction="Import", currency="GBP", principal=48_900, age_minutes=164,
                        source="TradePay", boe="6604512", assignee="R. Kadiam")),
        (4, 10476, dict(direction="Export", currency="USD", principal=31_250, age_minutes=208)),
        (6, 10473, dict(direction="Export", currency="EUR", principal=67_300, age_minutes=255, assignee="A. Varma")),
        (8, 10471, dict(direction="Import", currency="USD", principal=94_800, age_minutes=288,
                        source="TradePay")),
        (2, 10468, dict(direction="Export", currency="GBP", principal=42_150, age_minutes=334, assignee="N. Dsouza")),
        (5, 10465, dict(direction="Import", currency="USD", principal=158_900, age_minutes=398,
                        source="TradePay", priority="high")),
        (7, 10461, dict(direction="Export", currency="SGD", principal=88_400, age_minutes=455)),
    ]
    for idx, no, kw in ready:
        specs.append(_spec(idx, no, CaseStatus.READY_FOR_REVIEW, **kw))

    # -- processing ---------------------------------------------------------
    specs.append(_spec(2, 10480, CaseStatus.AI_PROCESSING, direction="Export", currency="USD",
                       principal=74_600, age_minutes=79,
                       elapsed=4, duration=30))
    specs.append(_spec(6, 10478, CaseStatus.AI_PROCESSING, direction="Import", currency="EUR",
                       principal=53_700, age_minutes=71, source="TradePay", elapsed=12, duration=40))
    specs.append(_spec(8, 10475, CaseStatus.AI_PROCESSING, direction="Export", currency="USD",
                       principal=119_200, age_minutes=64,
                       elapsed=1, duration=35))

    # -- received -----------------------------------------------------------
    specs.append(_spec(4, 10484, CaseStatus.RECEIVED, direction="Export", currency="USD",
                       principal=31_250, age_minutes=9))
    specs.append(_spec(9, 10483, CaseStatus.RECEIVED, direction="Import", currency="EUR",
                       principal=61_400, age_minutes=22, source="TradePay"))
    specs.append(_spec(1, 10485, CaseStatus.RECEIVED, direction="Export", currency="GBP",
                       principal=27_900, age_minutes=3))

    # -- with checker -------------------------------------------------------
    for idx, no, kw in [
        (0, 10460, dict(direction="Export", currency="USD", principal=76_500, age_minutes=512, assignee="R. Kadiam")),
        (4, 10458, dict(direction="Import", currency="EUR", principal=44_200, age_minutes=560,
                        source="TradePay", assignee="P. Shetty")),
        (6, 10456, dict(direction="Export", currency="USD", principal=103_750, age_minutes=604, assignee="A. Varma")),
    ]:
        specs.append(_spec(idx, no, CaseStatus.IN_CHECKER_QUEUE, **kw))

    # -- completed ----------------------------------------------------------
    for idx, no, kw in [
        (1, 10455, dict(direction="Import", currency="USD", principal=39_900, age_minutes=688,
                        source="TradePay", boe="7719085",
                        assignee="R. Kadiam")),
        (8, 10452, dict(direction="Export", currency="GBP", principal=58_300, age_minutes=742, assignee="N. Dsouza")),
    ]:
        specs.append(_spec(idx, no, CaseStatus.COMPLETED, **kw))

    return [_build(s) for s in specs]
