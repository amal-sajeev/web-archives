import base64
import binascii
import json
import logging
from typing import Any

import httpx

# from audit.audit_repository import DummyAuditRepository
from client.subagent_client import SubagentClient
from model.gateway_request import GatewayRequest, ScopingAction
from model.orchestration import OrchestrationResult, StageStatus
from registry.action_registry import get_action_definition
from validation.request_validator import RequestValidator
from validation.stage_validator import StageValidator


logger = logging.getLogger(__name__)


class ScopingMasterOrchestrator:
    def __init__(
        self,
        # audit_repository: DummyAuditRepository | None = None,
        subagent_client: SubagentClient | None = None,
    ) -> None:
        # self.audit_repository = audit_repository or DummyAuditRepository()
        self.request_validator = RequestValidator()
        self.stage_validator = StageValidator()  #StageValidator(self.audit_repository)
        self.subagent_client = subagent_client or SubagentClient()

    async def handle(self, request: GatewayRequest) -> dict[str, Any]:
        action_definition = get_action_definition(request.action)
        logger.info(
            "Received scoping action action=%s planNumber=%s stage=%s",
            request.action.value,
            request.planNumber,
            action_definition.stage.value,
        )

        if action_definition.is_download:
            raise ValueError(
                f"Invalid action type: {request.action.value} returns binary content; "
                "use /trigger-scoping-master-download instead."
            )

        self.request_validator.validate(request, action_definition)
        self.stage_validator.validate(request.planNumber, action_definition)

        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     action_definition.stage,
        #     StageStatus.IN_PROGRESS,
        # )

        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber,
        #         action_definition.stage,
        #         StageStatus.IN_PROGRESS,
        #     )

        try:
            response = await self.subagent_client.call(
                action_definition,
                self._build_subagent_body(request),
            )
        except httpx.HTTPStatusError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise ValueError(f"Subagent request failed: {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            error_detail = str(exc) or repr(exc)
            raise ValueError(f"Unable to reach subagent: {type(exc).__name__}: {error_detail}") from exc
        except ValueError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise

        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber,
        #         action_definition.stage,
        #         StageStatus.COMPLETED,
        #     )

        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     action_definition.stage,
        #     StageStatus.COMPLETED,
        #     {"response": response},
        # )

        return OrchestrationResult(
            planNumber=request.planNumber,
            action=request.action,
            stage=action_definition.stage,
            status=StageStatus.COMPLETED,
            response=response,
        ).to_dict()

    async def handle_download(
        self, request: GatewayRequest
    ) -> tuple[bytes, str, dict[str, str]]:
        """Handle actions that return raw binary content (e.g. PDF downloads).

        Runs the same validation as :meth:`handle` but returns the raw
        ``(content, content_type, headers)`` triple instead of a JSON dict.
        """
        action_definition = get_action_definition(request.action)
        logger.info(
            "Received scoping download action action=%s planNumber=%s stage=%s",
            request.action.value,
            request.planNumber,
            action_definition.stage.value,
        )

        self.request_validator.validate(request, action_definition)
        self.stage_validator.validate(request.planNumber, action_definition)

        try:
            return await self.subagent_client.download(
                action_definition,
                self._build_subagent_body(request),
            )
        except httpx.HTTPStatusError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise ValueError(f"Subagent request failed: {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            error_detail = str(exc) or repr(exc)
            raise ValueError(
                f"Unable to reach subagent: {type(exc).__name__}: {error_detail}"
            ) from exc
        except ValueError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise

    _QNA_INGEST_FILE_GROUPS = ("files", "policy_files", "kod_files", "procedure_files")
    _QNA_SCOPE_FORM_KEYS = (
        "user",
        "review_scope_id",
        "review_scope_instance_id",
        "process_instance_id",
        "task_id",
        "review_scope_stage",
    )

    def _build_subagent_body(self, request: GatewayRequest) -> dict[str, Any]:
        body = dict(request.payload)
        action_definition = get_action_definition(request.action)
        if request.planNumber is not None:
            if (
                action_definition.plan_number_field == "session_id"
                and body.get("session_id") not in (None, "")
            ):
                pass
            else:
                body[action_definition.plan_number_field] = request.planNumber
        if request.action in (
            ScopingAction.QNA_INGEST_DOCUMENTS,
            ScopingAction.QNA_UPLOAD_FILE,
        ):
            body = self._normalize_qna_multipart_body(request.action, body)
        if request.action == ScopingAction.QNA_CHAT and body.get("question") in (None, ""):
            user_text = body.get("userText") or body.get("user_text")
            if user_text not in (None, ""):
                body["question"] = user_text
        if request.action == ScopingAction.QNA_PLAN_DOCUMENT_ACTIONS:
            if "actions" in body and "extracted_actions" not in body:
                body["extracted_actions"] = body["actions"]
            if body.get("user_text") in (None, "") and body.get("extracted_actions"):
                body["user_text"] = "document action plan request"
        return body

    @classmethod
    def _decode_qna_base64(cls, raw_value: Any, filename: str) -> bytes:
        if isinstance(raw_value, bytes):
            try:
                text = raw_value.decode("ascii")
            except UnicodeDecodeError as exc:
                raise ValueError(f"Invalid base64 file content for '{filename}'.") from exc
        elif isinstance(raw_value, str):
            text = raw_value
        else:
            raise ValueError("payload.files[].content_base64 must be a base64 string.")

        stripped = text.strip()
        if stripped.lower().startswith("data:") and ";base64," in stripped.lower():
            _, stripped = stripped.split(",", 1)
        compact = "".join(stripped.split())
        try:
            return base64.b64decode(compact, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ValueError(f"Invalid base64 file content for '{filename}'.") from exc

    @classmethod
    def _normalize_qna_file_item(cls, file_item: Any, default_field_name: str) -> Any:
        if not isinstance(file_item, dict):
            return file_item
        normalized = dict(file_item)
        filename = str(normalized.get("filename") or "<unknown>")
        content_base64 = normalized.pop("content_base64", None)
        if content_base64 is not None:
            normalized["content"] = cls._decode_qna_base64(content_base64, filename)
        elif (
            isinstance(normalized.get("content"), str)
            and normalized["content"].lstrip().lower().startswith("data:")
            and ";base64," in normalized["content"].lower()
        ):
            normalized["content"] = cls._decode_qna_base64(normalized["content"], filename)
        if not normalized.get("field_name"):
            normalized["field_name"] = default_field_name
        return normalized

    @classmethod
    def _normalize_qna_multipart_body(
        cls, action: ScopingAction, body: dict[str, Any]
    ) -> dict[str, Any]:
        if action == ScopingAction.QNA_INGEST_DOCUMENTS:
            collected_files: list[Any] = []
            for group_key in cls._QNA_INGEST_FILE_GROUPS:
                if group_key not in body:
                    continue
                group_items = body.pop(group_key)
                if group_items is None:
                    continue
                if not isinstance(group_items, list):
                    raise ValueError(f"payload.{group_key} must be a list of file objects.")
                for file_item in group_items:
                    collected_files.append(
                        cls._normalize_qna_file_item(file_item, group_key)
                    )
            body["files"] = collected_files
        elif action == ScopingAction.QNA_UPLOAD_FILE:
            raw_files = body.get("files")
            if isinstance(raw_files, list):
                body["files"] = [
                    cls._normalize_qna_file_item(file_item, "file")
                    for file_item in raw_files
                ]

        form_data = body.pop("form_data", None)
        if isinstance(form_data, dict):
            for key, value in form_data.items():
                if key == "files" or value is None:
                    continue
                if key not in body or body[key] is None:
                    body[key] = value
            if (
                action == ScopingAction.QNA_INGEST_DOCUMENTS
                and body.get("user_details") in (None, "")
                and body.get("userDetails") in (None, "")
                and any(form_data.get(k) not in (None, "") for k in cls._QNA_SCOPE_FORM_KEYS)
            ):
                body["user_details"] = {
                    key: value for key, value in form_data.items() if value is not None
                }

        if "userDetails" in body:
            user_details_camel = body.pop("userDetails")
            if user_details_camel is not None and body.get("user_details") in (None, ""):
                body["user_details"] = user_details_camel

        sanitized: dict[str, Any] = {}
        for key, value in body.items():
            if key == "files":
                sanitized[key] = value
            elif value is None:
                continue
            elif isinstance(value, (dict, list)):
                sanitized[key] = json.dumps(value)
            else:
                sanitized[key] = value
        return sanitized

    def _record_failure(
        self, request: GatewayRequest, stage, details: dict[str, Any]
    ) -> None:
        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber, stage, StageStatus.FAILED
        #     )
        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     stage,
        #     StageStatus.FAILED,
        #     details,
        # )
        pass 
