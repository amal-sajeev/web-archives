import base64
import binascii
import logging
from typing import Any

import httpx

# from audit.audit_repository import DummyAuditRepository
from client.subagent_client import SubagentClient
from model.gateway_request import GatewayRequest, ScopingAction
from model.orchestration import OrchestrationResult, StageStatus
from registry.action_registry import get_action_definition
from validation.request_validator import RequestValidator
from validation.stage_validator import StageValidator


logger = logging.getLogger(__name__)


class ScopingMasterOrchestrator:
    def __init__(
        self,
        # audit_repository: DummyAuditRepository | None = None,
        subagent_client: SubagentClient | None = None,
    ) -> None:
        # self.audit_repository = audit_repository or DummyAuditRepository()
        self.request_validator = RequestValidator()
        self.stage_validator = StageValidator()  #StageValidator(self.audit_repository)
        self.subagent_client = subagent_client or SubagentClient()

    async def handle(self, request: GatewayRequest) -> dict[str, Any]:
        action_definition = get_action_definition(request.action)
        logger.info(
            "Received scoping action action=%s planNumber=%s stage=%s",
            request.action.value,
            request.planNumber,
            action_definition.stage.value,
        )

        if action_definition.is_download:
            raise ValueError(
                f"Invalid action type: {request.action.value} returns binary content; "
                "use /trigger-scoping-master-download instead."
            )

        self.request_validator.validate(request, action_definition)
        self.stage_validator.validate(request.planNumber, action_definition)

        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     action_definition.stage,
        #     StageStatus.IN_PROGRESS,
        # )

        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber,
        #         action_definition.stage,
        #         StageStatus.IN_PROGRESS,
        #     )

        try:
            response = await self.subagent_client.call(
                action_definition,
                self._build_subagent_body(request),
            )
        except httpx.HTTPStatusError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise ValueError(f"Subagent request failed: {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            error_detail = str(exc) or repr(exc)
            raise ValueError(f"Unable to reach subagent: {type(exc).__name__}: {error_detail}") from exc
        except ValueError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise

        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber,
        #         action_definition.stage,
        #         StageStatus.COMPLETED,
        #     )

        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     action_definition.stage,
        #     StageStatus.COMPLETED,
        #     {"response": response},
        # )

        return OrchestrationResult(
            planNumber=request.planNumber,
            action=request.action,
            stage=action_definition.stage,
            status=StageStatus.COMPLETED,
            response=response,
        ).to_dict()

    async def handle_download(
        self, request: GatewayRequest
    ) -> tuple[bytes, str, dict[str, str]]:
        """Handle actions that return raw binary content (e.g. PDF downloads).

        Runs the same validation as :meth:`handle` but returns the raw
        ``(content, content_type, headers)`` triple instead of a JSON dict.
        """
        action_definition = get_action_definition(request.action)
        logger.info(
            "Received scoping download action action=%s planNumber=%s stage=%s",
            request.action.value,
            request.planNumber,
            action_definition.stage.value,
        )

        self.request_validator.validate(request, action_definition)
        self.stage_validator.validate(request.planNumber, action_definition)

        try:
            return await self.subagent_client.download(
                action_definition,
                self._build_subagent_body(request),
            )
        except httpx.HTTPStatusError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise ValueError(f"Subagent request failed: {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            error_detail = str(exc) or repr(exc)
            raise ValueError(
                f"Unable to reach subagent: {type(exc).__name__}: {error_detail}"
            ) from exc
        except ValueError as exc:
            self._record_failure(request, action_definition.stage, {"error": str(exc)})
            raise

    def _build_subagent_body(self, request: GatewayRequest) -> dict[str, Any]:
        body = dict(request.payload)
        action_definition = get_action_definition(request.action)
        if request.action == ScopingAction.QNA_INGEST_DOCUMENTS:
            files = body.get("files")
            if isinstance(files, list):
                normalized_files = []
                for file_item in files:
                    if not isinstance(file_item, dict):
                        normalized_files.append(file_item)
                        continue
                    normalized = dict(file_item)
                    content_base64 = normalized.pop("content_base64", None)
                    if content_base64 is not None:
                        if not isinstance(content_base64, (str, bytes)):
                            raise ValueError("payload.files[].content_base64 must be a base64 string.")
                        try:
                            normalized["content"] = base64.b64decode(content_base64, validate=True)
                        except (binascii.Error, ValueError) as exc:
                            filename = normalized.get("filename") or "<unknown>"
                            raise ValueError(f"Invalid base64 file content for '{filename}'.") from exc
                    normalized_files.append(normalized)
                body["files"] = normalized_files
        if request.planNumber is not None:
            if (
                action_definition.plan_number_field == "session_id"
                and body.get("session_id") not in (None, "")
            ):
                pass
            else:
                body[action_definition.plan_number_field] = request.planNumber
        if request.action == ScopingAction.QNA_CHAT and body.get("question") in (None, ""):
            user_text = body.get("userText") or body.get("user_text")
            if user_text not in (None, ""):
                body["question"] = user_text
        if request.action == ScopingAction.QNA_PLAN_DOCUMENT_ACTIONS:
            if "actions" in body and "extracted_actions" not in body:
                body["extracted_actions"] = body["actions"]
            if body.get("user_text") in (None, "") and body.get("extracted_actions"):
                body["user_text"] = "document action plan request"
        return body

    def _record_failure(
        self, request: GatewayRequest, stage, details: dict[str, Any]
    ) -> None:
        # if request.planNumber:
        #     self.audit_repository.set_stage_status(
        #         request.planNumber, stage, StageStatus.FAILED
        #     )
        # self.audit_repository.record_event(
        #     request.planNumber,
        #     request.action,
        #     stage,
        #     StageStatus.FAILED,
        #     details,
        # )
        pass 
