"""Unit tests for `service.orchestrator.ScopingMasterOrchestrator`."""
from __future__ import annotations

import asyncio
import base64
import json
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from client.subagent_client import SubagentClient
from model.gateway_request import GatewayRequest, ScopingAction
from model.orchestration import ActionDefinition, BodyType, ScopingStage, StageStatus
from registry.action_registry import get_action_definition
from service.orchestrator import ScopingMasterOrchestrator


def _run(coro):
    return asyncio.run(coro)


def _make_action_def(
    *,
    action: ScopingAction = ScopingAction.GENERATE_NOIR,
    stage: ScopingStage = ScopingStage.NOIR,
    service_name: str = "noir",
    method: str = "POST",
    endpoint: str = "/noir/generate",
    body_type: BodyType = BodyType.JSON,
    plan_number_field: str = "planNumber",
    is_download: bool = False,
) -> ActionDefinition:
    return ActionDefinition(
        action=action,
        stage=stage,
        service_name=service_name,
        method=method,
        endpoint=endpoint,
        body_type=body_type,
        plan_number_field=plan_number_field,
        is_download=is_download,
    )


def _make_orchestrator(
    *,
    subagent_response: dict | None = None,
    subagent_side_effect: Exception | None = None,
    action_def: ActionDefinition | None = None,
    monkeypatch: pytest.MonkeyPatch | None = None,
):
    """Build an orchestrator with mocked collaborators."""
    client = MagicMock()
    if subagent_side_effect is not None:
        client.call = AsyncMock(side_effect=subagent_side_effect)
    else:
        client.call = AsyncMock(return_value=subagent_response or {"ok": True})

    orch = ScopingMasterOrchestrator(subagent_client=client)
    orch.request_validator = MagicMock()
    orch.stage_validator = MagicMock()

    if action_def is not None and monkeypatch is not None:
        monkeypatch.setattr(
            "service.orchestrator.get_action_definition",
            lambda _action: action_def,
        )
    return orch, client


class TestInit:
    def test_uses_provided_client(self) -> None:
        client = MagicMock()
        orch = ScopingMasterOrchestrator(subagent_client=client)
        assert orch.subagent_client is client

    def test_creates_default_collaborators(self) -> None:
        orch = ScopingMasterOrchestrator()
        assert orch.subagent_client is not None
        assert orch.request_validator is not None
        assert orch.stage_validator is not None


class TestBuildSubagentBody:
    def test_includes_plan_number_under_configured_field(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(plan_number_field="plan_item_number")
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GENERATE_NOIR,
            payload={"foo": "bar"},
        )
        body = orch._build_subagent_body(request)
        assert body == {"foo": "bar", "plan_item_number": "P1"}

    def test_omits_plan_number_when_missing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        request = GatewayRequest(
            action=ScopingAction.GET_CITATION_DOCUMENT,
            payload={"document_uri": "gs://b/o"},
        )
        body = orch._build_subagent_body(request)
        assert body == {"document_uri": "gs://b/o"}

    def test_does_not_mutate_original_payload(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        payload = {"a": 1}
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload=payload
        )
        orch._build_subagent_body(request)
        assert payload == {"a": 1}

    def test_qna_chat_populates_question_from_user_text(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(
            action=ScopingAction.QNA_CHAT,
            stage=ScopingStage.QNA,
            service_name="qna",
            endpoint="/chat",
        )
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.QNA_CHAT,
            payload={"userText": "exclude policy A"},
        )
        body = orch._build_subagent_body(request)
        assert body["question"] == "exclude policy A"
        assert body["userText"] == "exclude policy A"
        assert body["planNumber"] == "P1"

    def test_qna_close_session_preserves_explicit_session_id(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(
            action=ScopingAction.QNA_CLOSE_SESSION,
            stage=ScopingStage.QNA,
            service_name="qna",
            endpoint="/session/close",
            plan_number_field="session_id",
        )
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.QNA_CLOSE_SESSION,
            payload={"session_id": "custom-session"},
        )
        body = orch._build_subagent_body(request)
        assert body["session_id"] == "custom-session"

    def test_qna_plan_document_actions_maps_actions_to_extracted_actions(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(
            action=ScopingAction.QNA_PLAN_DOCUMENT_ACTIONS,
            stage=ScopingStage.QNA,
            service_name="qna",
            endpoint="/documents/actions/plan",
            plan_number_field="plan_number",
        )
        orch, _ = _make_orchestrator(action_def=action_def, monkeypatch=monkeypatch)
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.QNA_PLAN_DOCUMENT_ACTIONS,
            payload={"actions": [{"action": "exclude", "title": "Policy A"}]},
        )
        body = orch._build_subagent_body(request)
        assert body["extracted_actions"] == [{"action": "exclude", "title": "Policy A"}]
        assert body["user_text"] == "document action plan request"
        assert body["plan_number"] == "P1"

    def test_qna_ingest_decodes_content_base64_and_builds_valid_httpx_multipart(self) -> None:
        raw_pdf = b"%PDF-1.4\nhello world\n"
        b64_pdf = base64.b64encode(raw_pdf).decode("ascii")
        orch, _ = _make_orchestrator()
        request = GatewayRequest(
            planNumber="20440",
            action=ScopingAction.QNA_INGEST_DOCUMENTS,
            payload={
                "files": [
                    {
                        "filename": "policy.pdf",
                        "content_base64": b64_pdf,
                        "content_type": "application/pdf",
                    }
                ],
                "document_type": "policy",
                "review_scope_id": "42",
                "task_id": None,
            },
        )
        body = orch._build_subagent_body(request)
        assert body["plan_number"] == "20440"
        assert body["document_type"] == "policy"
        assert body["review_scope_id"] == "42"
        assert "task_id" not in body
        assert body["files"] == [
            {
                "filename": "policy.pdf",
                "content": raw_pdf,
                "content_type": "application/pdf",
                "field_name": "files",
            }
        ]
        # Verify httpx actually encodes the multipart request without TypeError.
        kwargs = SubagentClient()._request_kwargs(
            get_action_definition(ScopingAction.QNA_INGEST_DOCUMENTS), body
        )
        req = httpx.Request("POST", "http://qna/documents/ingest", **kwargs)
        req.read()
        assert raw_pdf in req.content

    def test_qna_ingest_handles_dbaware_ui_payload_with_form_data_dict(self) -> None:
        raw_pdf = b"%PDF-1.4\ndbaware-ui-doc\n"
        b64_pdf = base64.b64encode(raw_pdf).decode("ascii")
        orch, _ = _make_orchestrator()
        request = GatewayRequest(
            planNumber="20440",
            action=ScopingAction.QNA_INGEST_DOCUMENTS,
            payload={
                "files": [
                    {
                        "filename": "kod.pdf",
                        "content": b64_pdf,
                        "content_base64": b64_pdf,
                        "content_type": "application/pdf",
                    }
                ],
                "form_data": {"user": "auditor@db.com"},
            },
        )
        body = orch._build_subagent_body(request)
        assert "form_data" not in body
        assert body["user"] == "auditor@db.com"
        assert json.loads(body["user_details"]) == {"user": "auditor@db.com"}
        assert body["files"][0]["content"] == raw_pdf

        kwargs = SubagentClient()._request_kwargs(
            get_action_definition(ScopingAction.QNA_INGEST_DOCUMENTS), body
        )
        req = httpx.Request("POST", "http://qna/documents/ingest", **kwargs)
        req.read()
        assert raw_pdf in req.content

    def test_qna_ingest_handles_data_uri_whitespace_typed_groups_and_user_details_dict(
        self,
    ) -> None:
        raw_policy = b"%PDF-1.4\npolicy-bytes"
        raw_kod = b"%PDF-1.4\nkod-bytes"
        b64_policy = base64.b64encode(raw_policy).decode("ascii")
        b64_kod = base64.b64encode(raw_kod).decode("ascii")
        wrapped_data_uri = f"data:application/pdf;base64,{b64_policy[:8]}\n  {b64_policy[8:]}"
        orch, _ = _make_orchestrator()
        request = GatewayRequest(
            planNumber="20440",
            action=ScopingAction.QNA_INGEST_DOCUMENTS,
            payload={
                "policy_files": [
                    {
                        "filename": "p.pdf",
                        "content_base64": wrapped_data_uri,
                        "content_type": "application/pdf",
                    }
                ],
                "kod_files": [
                    {
                        "filename": "k.pdf",
                        "content": f"data:application/pdf;base64,{b64_kod}",
                        "content_type": "application/pdf",
                    }
                ],
                "userDetails": {"review_scope_id": "99", "user": "auditor@db.com"},
            },
        )
        body = orch._build_subagent_body(request)
        assert "policy_files" not in body
        assert "kod_files" not in body
        assert "userDetails" not in body
        assert json.loads(body["user_details"]) == {
            "review_scope_id": "99",
            "user": "auditor@db.com",
        }
        kwargs = SubagentClient()._request_kwargs(
            get_action_definition(ScopingAction.QNA_INGEST_DOCUMENTS), body
        )
        assert kwargs["files"] == [
            ("policy_files", ("p.pdf", raw_policy, "application/pdf")),
            ("kod_files", ("k.pdf", raw_kod, "application/pdf")),
        ]
        req = httpx.Request("POST", "http://qna/documents/ingest", **kwargs)
        req.read()
        assert raw_policy in req.content and raw_kod in req.content

    def test_qna_ingest_rejects_invalid_base64(self) -> None:
        orch, _ = _make_orchestrator()
        request = GatewayRequest(
            planNumber="20440",
            action=ScopingAction.QNA_INGEST_DOCUMENTS,
            payload={
                "files": [
                    {"filename": "bad.pdf", "content_base64": "!!!not-base64!!!"}
                ]
            },
        )
        with pytest.raises(ValueError, match="Invalid base64 file content for 'bad.pdf'"):
            orch._build_subagent_body(request)

    def test_qna_upload_file_decodes_base64_and_uses_singular_file_field(self) -> None:
        raw_json = b'{"hello": "world"}'
        b64_json = base64.b64encode(raw_json).decode("ascii")
        orch, _ = _make_orchestrator()
        request = GatewayRequest(
            planNumber="20440",
            action=ScopingAction.QNA_UPLOAD_FILE,
            payload={
                "files": [
                    {
                        "filename": "sample.json",
                        "content_base64": b64_json,
                        "content_type": "application/json",
                    }
                ],
                "dest_blob_path": "plans/20440/sample.json",
            },
        )
        body = orch._build_subagent_body(request)
        kwargs = SubagentClient()._request_kwargs(
            get_action_definition(ScopingAction.QNA_UPLOAD_FILE), body
        )
        assert kwargs["files"] == [
            ("file", ("sample.json", raw_json, "application/json"))
        ]
        req = httpx.Request("POST", "http://qna/upload", **kwargs)
        req.read()
        assert raw_json in req.content

    def test_non_qna_multipart_action_is_unchanged(self) -> None:
        orch, _ = _make_orchestrator()
        request = GatewayRequest(
            planNumber="20440",
            action=ScopingAction.UPLOAD_MEETING_NOTES,
            payload={
                "files": [
                    {"filename": "notes.txt", "content": b"notes", "content_type": "text/plain"}
                ],
            },
        )
        body = orch._build_subagent_body(request)
        assert body["files"] == [
            {"filename": "notes.txt", "content": b"notes", "content_type": "text/plain"}
        ]
        assert body["planNumber"] == "20440"



class TestHandleRejectsDownloadActions:
    def test_handle_raises_for_download_action(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(
            action=ScopingAction.DOWNLOAD_SCOPING_DOCUMENT,
            service_name="scoping_procedure",
            endpoint="/generate-scoping-document",
            is_download=True,
        )
        orch, client = _make_orchestrator(
            action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.DOWNLOAD_SCOPING_DOCUMENT
        )

        with pytest.raises(ValueError, match="Invalid action type"):
            _run(orch.handle(request))

        # The subagent must NOT be called for download actions via /handle.
        client.call.assert_not_called()


class TestHandleSuccess:
    def test_returns_completed_result_dict(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def(plan_number_field="plan_item_number")
        orch, client = _make_orchestrator(
            subagent_response={"data": "ok"},
            action_def=action_def,
            monkeypatch=monkeypatch,
        )
        request = GatewayRequest(
            planNumber="P1",
            action=ScopingAction.GENERATE_NOIR,
            payload={"k": "v"},
        )

        result = _run(orch.handle(request))

        assert result == {
            "planNumber": "P1",
            "action": "GENERATE_NOIR",
            "stage": "NOIR",
            "status": StageStatus.COMPLETED.value,
            "response": {"data": "ok"},
        }
        client.call.assert_awaited_once()
        called_def, called_body = client.call.call_args.args
        assert called_def is action_def
        assert called_body == {"k": "v", "plan_item_number": "P1"}

    def test_invokes_validators_before_subagent(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, client = _make_orchestrator(
            action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        _run(orch.handle(request))

        orch.request_validator.validate.assert_called_once_with(request, action_def)
        orch.stage_validator.validate.assert_called_once_with("P1", action_def)
        client.call.assert_awaited_once()

    def test_validation_error_short_circuits(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        action_def = _make_action_def()
        orch, client = _make_orchestrator(
            action_def=action_def, monkeypatch=monkeypatch
        )
        orch.request_validator.validate.side_effect = ValueError("bad request")
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="bad request"):
            _run(orch.handle(request))
        client.call.assert_not_awaited()


class TestHandleErrors:
    def _make_http_status_error(self, text: str = "boom") -> httpx.HTTPStatusError:
        response = MagicMock(spec=httpx.Response)
        response.text = text
        return httpx.HTTPStatusError("err", request=MagicMock(), response=response)

    def test_http_status_error_wrapped(self, monkeypatch: pytest.MonkeyPatch) -> None:
        action_def = _make_action_def()
        exc = self._make_http_status_error("server down")
        orch, _ = _make_orchestrator(
            subagent_side_effect=exc, action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="Subagent request failed: server down") as info:
            _run(orch.handle(request))
        assert info.value.__cause__ is exc

    def test_http_error_wrapped(self, monkeypatch: pytest.MonkeyPatch) -> None:
        action_def = _make_action_def()
        exc = httpx.ConnectError("boom")
        orch, _ = _make_orchestrator(
            subagent_side_effect=exc, action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="Unable to reach subagent") as info:
            _run(orch.handle(request))
        assert info.value.__cause__ is exc

    def test_value_error_reraised(self, monkeypatch: pytest.MonkeyPatch) -> None:
        action_def = _make_action_def()
        exc = ValueError("payload issue")
        orch, _ = _make_orchestrator(
            subagent_side_effect=exc, action_def=action_def, monkeypatch=monkeypatch
        )
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )

        with pytest.raises(ValueError, match="payload issue"):
            _run(orch.handle(request))


class TestRecordFailure:
    def test_is_currently_a_no_op(self) -> None:
        orch = ScopingMasterOrchestrator(subagent_client=MagicMock())
        request = GatewayRequest(
            planNumber="P1", action=ScopingAction.GENERATE_NOIR, payload={}
        )
        # Should not raise and should return None.
        assert orch._record_failure(request, ScopingStage.NOIR, {"error": "x"}) is None
