# CTNA Evaluation Service

A separately-hosted **agent evaluation service** (LLM-as-a-judge). It scores
production agents against a versioned **golden set** using both **objective
(deterministic)** checks and **LLM-based** judges, computes a weighted pass/fail
gate plus a **weighted delta** to trend metric drift over time, and persists runs
to SQL. It can be driven directly by a human (browser dashboard) or by a CI/CD
pipeline (one REST call, non-zero exit on failure).

See [docs/EVAL_SERVICE_DESIGN.md](docs/EVAL_SERVICE_DESIGN.md) for the full design
and [docs/VERTEX_INTEGRATION.md](docs/VERTEX_INTEGRATION.md) for the Vertex judge
pattern.

## Layout

```
src/main/              FastAPI app, runner, scorers, adapters, repository, UI
src/tests/             pytest suite (unit + scorer coverage)
src/agents/<id>/       one folder per evaluated agent (config + golden set + tests)
src/sample_agents/     runnable stub agents for offline demos
scripts/               start_local*.ps1 / setup_local.ps1 (local), run_eval_service.ps1, ci_gate.py
```

## Setup

Create a virtual environment and install dependencies:

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r src/main/requirements.txt
```

If your environment requires a private package index, configure `pip` or pass
`--index-url` per your organisation's standards.

Copy `.env.example` to `.env` and set `PROJECT_NAME` / `PROJECT_LOCATION`, then:

```powershell
gcloud auth application-default login
```

## Run locally (quick start)

On a new machine, set up once (creates `.venv` with the pinned requirements; needs
Python 3.11+):

```powershell
.\scripts\setup_local.ps1
```

Then either:

```powershell
# Service only, on http://127.0.0.1:4002 with SQLite (eval_service.db in this folder)
.\scripts\start_local.ps1 -Open

# Service + all four sample agents (:4010-4013), shown in the dashboard for testing
.\scripts\start_local_all.ps1 -Open
```

- **Stop:** press Ctrl+C. `start_local_all.ps1` also stops the agents it started. If a window was closed without Ctrl+C, run `.\scripts\stop_local.ps1` to free the ports.
- **Options:** `-Port <n>` and `-Db <path>`. Use `-Db` to keep test runs out of `eval_service.db`, e.g. `-Db C:\temp\scratch.db`.
- **Database:** an `EVAL_DB_URL` already set in your shell takes precedence over the local SQLite default.
- **Agent logs:** `%TEMP%\dbaware-eval-local\`.
- **Sample agents:** they ship with `enabled: false` in their `agent.yaml`. `start_local_all.ps1` shows them for that run by setting `EVAL_ENABLE_AGENTS` (a comma-separated list of agent ids, or `*` for all); the YAML files are not changed.
- **AI reviewer:** checks that need it are skipped without Vertex credentials; everything else runs offline.

## Run (corporate network / CloudSQL)

1. Start the evaluation target agent on `:4000`.
2. Start this service:

   ```powershell
   .\scripts\run_eval_service.ps1
   ```

  The launcher defaults `EVAL_DB_URL` to CloudSQL (`postgresql://`). If the
  CloudSQL connection/init fails, the service automatically falls back to local
  SQLite (`eval_service.db`) so local config testing still works.

3. Open http://localhost:4002 for the dashboard, or check wiring:

   ```powershell
   curl http://localhost:4002/api/health
   ```

  The health response includes the current service `version` so you can
  confirm which build is active in a deployed environment.

  The Helm chart `appVersion` should be kept in sync with the service version
  whenever a new commit is deployed.

  Set `EVAL_EXCLUDE_TLS=1` if the eval service needs to reach internal HTTPS
  endpoints with untrusted or broken certificates.

## Run fully offline (sample agent + capture service, no DB, no Vertex)

To exercise the whole pipeline without the production agent, the metrics API, or
Google Cloud credentials, use the bundled **sample LangChain agent** and the
**capture service** (which derives a `CTA_ACTION` from each live agent run and
holds it in memory):

```powershell
# 1. Start the sample agent on :4010
.\scripts\run_sample_agent.ps1

# 2. In another terminal, point the eval service at it in capture mode
$env:AGENT_SERVICE_BASE_URL = "http://localhost:4010"
$env:METRICS_SOURCE = "capture"
.\scripts\run_eval_service.ps1

# 3. Evaluate, then inspect the captured CTA_ACTIONs
Invoke-RestMethod http://localhost:4002/api/evaluate -Method Post `
  -Body '{"agent_id":"scope_extraction"}' -ContentType 'application/json'
Invoke-RestMethod http://localhost:4002/api/captures
```

`METRICS_SOURCE` selects where metrics come from: `capture` (live, in-memory),
`http` (the real `CTA_ACTION` API via `METRICS_API_BASE`), or `stub` (the
agent's `metrics_stub.json`). The LLM judge metric is skipped automatically when
no Vertex credentials are present, so the run still completes offline.


## CI/CD gate

```powershell
.venv\Scripts\python.exe scripts\ci_gate.py --agent scope_extraction --eval-url http://localhost:4002
```

The agent can also be passed positionally or via `AGENT_ID`. The gate starts a
run, polls `/api/evaluate/stream/{id}/events` until it finishes, then checks the
run record's `status == "PASS"` (plus optional `--score`, `--delta`,
`--pass-rate` thresholds). Exit code 0 = pass, 1 = gate failed, 2 = service or
run error, failing the pipeline step.

## Add a new agent

Create `src/agents/<agent_id>/` with:

- `agent.yaml` — id, name, base_url, dataset/metrics files
- `dataset.json` — the golden set (inputs, ideal outputs, baseline metrics)
- `metrics_stub.json` — stubbed metrics-API response (until the real API exists)
- `custom_tests.py` — optional bespoke scorers via `@scorer("name")`

The registry auto-discovers it at startup — no core code changes.

**Config-driven agent calls**: set `target.adapter: "http"` in `dataset.json`
to call any agent HTTP endpoint (GET/POST/PUT, auth, params, body, response
mapping) without writing Python. Supports document outputs (PDF, DOCX,
Markdown, JSON) with automatic text extraction.

**Config-driven metrics**: 11 scorers parameterised via `MetricSpec.config`
(text/regex: `contains`, `regex_match`, `length_range`, `keyword_count`; JSON:
`json_path`, `field_match`, `json_schema_valid`; document: `section_present`,
`heading_count`, `docx_table_has`; custom LLM: `rubric`). No Python needed.

See [docs/AGENT_CONFIG_GUIDE.md](docs/AGENT_CONFIG_GUIDE.md) for a complete
engineer tutorial and [docs/UPGRADES_AND_CHANGES.md](docs/UPGRADES_AND_CHANGES.md)
for the full changelog.

## Demo agents

Three sample LangChain agents (hostable standalone) demonstrate the upgrades:

```powershell
.\scripts\run_report_writer_agent.ps1    # Markdown reports  (port 4011)
.\scripts\run_invoice_parser_agent.ps1    # JSON invoices    (port 4012)
.\scripts\run_document_qa_agent.ps1      # DOCX + PDF docs  (port 4013)
```

Evaluate any of them:
```powershell
Invoke-RestMethod http://localhost:4002/api/evaluate -Method Post `
  -Body '{"agent_id":"report_writer"}' -ContentType 'application/json'
```

## Notes

- **Persistence:** CloudSQL Postgres is the default (`EVAL_DB_URL=postgresql://`).
  On CloudSQL connection/init failure, the service falls back to local SQLite
  automatically (`eval_service.db`).
- **Metrics API:** stubbed from each agent's `metrics_stub.json`; set
  `METRICS_API_BASE` to switch to the live API with no scorer changes.

## Config Playground

Use `/playground.html` to upload an agent configuration ZIP, edit its files in the browser, run the edited configuration against a target, inspect case-level evaluation results, and export the edited ZIP. Playground workspaces and runs are ephemeral and are not written to the normal evaluation database.
