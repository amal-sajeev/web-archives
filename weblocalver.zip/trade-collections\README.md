# Trade Collections — Maker Workbench

A demo application for the WFMS / TradePay → TF3 collections flow, served in
**two house styles off one API**. Same data, same routes, same behaviour —
only the presentation differs.

**All case data is illustrative.**

## Run

Double-click **`run.bat`**. The first run builds a local `.venv`, installs what
it needs and opens the browser; after that it starts in a couple of seconds.
Pass a port if 8000 is busy:

```
run.bat 8080
```

By hand, if you prefer:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m uvicorn app.main:app --port 8000
```

| Link | View |
| --- | --- |
| `http://127.0.0.1:8000/?v=desk` | **Desk** — the collections-desk interpretation |
| `http://127.0.0.1:8000/?v=corp` | **Corporate** — the project deck's house style |

Either link is shareable and the choice sticks via a cookie, so navigation
keeps whichever view you opened. Both carry a switch link in the top bar.

### Desk view

Built from the materials of the job: buff folder stock, document white, fountain
ink, bank-stamp violet for the bank's own marks, and annotation red reserved for
one meaning — two documents disagree. Spectral and IBM Plex Sans. The queue is a
*register* with the finding written under each entry; the verdict is a rubber
stamp, and it is the only loud thing on the page.

### Corporate view

Rebuilds the deck's own mockups as working screens. The worklist is slide 1:
navy header row, the deck's seven columns, source tags, the toolbar and the
status-path strip beneath. The case screen is slide 2: the navy case bar, then
three columns at the deck's own proportions (3.25 / 5.23 / 3.14 inches) —
**01 Transaction snapshot**, the three automated activity cards, and the
**02 Maker review** rail with its two attestations and the
"Validate to checker queue" button. Source Sans 3, Deutsche Bank blue on navy.

Where the deck shows "View source JSON + documents" as a link, this view does
the same: the documents and the extracted-field list open in a drawer, with the
same click-to-highlight provenance as the desk view.

## The two screens

**The queue** tells you what to do in plain words. Three groups — needs a
decision, cleared, still processing — and each row leads with the actual problem
("Invoice is denominated in USD; the collection order states EUR"), never a rule
name. One search box, no filters to configure.

**The case** is one screen, no tabs. Documents on one side, the decision on the
other. Top to bottom: the verdict, the thing that needs you with its fix beside
it, everything that passed folded into a single line, the charge, the button.
A clear case is a verdict, a checkbox, a button — and it hands you the next case.

## Demo path

1. The queue opens on **6 need you**, each with its problem stated.
2. **Northstar Engineering (COL-10474)** — a port code would not resolve.
   *Look it up*, search `Chennai`, pick it. The field fills, the check clears,
   charges calculate, the case turns green.
3. Tick the box, **Send to the checker**. TF3 is updated and it hands you the
   next case automatically.
4. **Switch to checker** in the top bar, open the case, **Approve and close**.
5. **Meridian Components (COL-10481)** — the invoice reads USD, the order reads
   EUR. You can see both on screen. *Ask the branch* instead; the case waits.
6. **Vantage Agro (COL-10477)** — a repeated Bill of Entry. The comparison shows
   only the fields that actually differ. *This is fine — explain why*.

## Where the real systems plug in

Everything reads and writes through `CaseStore` in `app/store.py`. Replace it
and nothing else changes.

| Method | Real source |
| --- | --- |
| `list_cases` / `get` | WFMS extraction output and the TradePay transaction file |
| `resolve_port` / `ports` | The port directory (volza.com/ports) |
| `_calculate_charges` | OEMS tariff via the Autobahn processing instructions, product *Comm Direct Docs* |
| `validate` | Posts the final data and charges to TF3 |
| `approve` | Posts the process update back to WFMS |
| `raise_query` | Sends the branch query |

```python
# app/store.py
store = Tf3BackedCaseStore(...)   # swap this line
```

Or override per deployment:

```python
from app.main import app
from app.store import get_store
app.dependency_overrides[get_store] = lambda: Tf3BackedCaseStore(...)
```

## API

Full reference at `/docs`. The screens use exactly these routes.

```
GET   /api/cases                  ?view= &search= &source= &priority= &assignee=
GET   /api/cases/live             progress for the rows still processing
GET   /api/cases/{id}             /state  /payload
GET   /api/ports  ?q=             port directory

PATCH /api/cases/{id}/fields/{key}                  {value, note}
POST  /api/cases/{id}/fields/{key}/accept
POST  /api/cases/{id}/fields/{key}/resolve-port     {code}
POST  /api/cases/{id}/checks/{cid}/resolve          {resolution}
POST  /api/cases/{id}/charges/recalculate
POST  /api/cases/{id}/queries                       {reason, recipient, check_id}
POST  /api/cases/{id}/queries/{qid}/answer          {response}
POST  /api/cases/{id}/start | /assign | /validate | /approve | /return
POST  /api/session/role                             {role}
```

## Layout

```
app/
  main.py            page routes + theme resolution
  api.py             JSON API (shared by both views)
  store.py           CaseStore — the swap point, plus the pipeline simulation
  models.py          Pydantic schemas (the UI contract)
  seed.py            the illustrative book of work
  templates/desk/    base, queue, case, reference, partials/
  templates/corp/    the same screens in the deck's house style
  static/css/        desk.css, corp.css
  static/js/         app.js, queue.js, case.js — shared, both views use the
                     same class hooks so one script drives both
```

## Modelled from the meeting notes

- Bill of Entry as the transaction key, with the ~10% duplicate path resolved on
  drawee name, drawer name, port of loading and port of discharge.
- Port short codes resolved to full names before TF3, with an unresolved state
  that blocks the case until a maker looks it up.
- Drawer and drawee name + address carried through to TF3.
- Currency, amount, party and port consistency between the documents and the
  intake record.
- FEMA and FIU rule sets, each stamping its version onto the evidence.
- Charges from the OEMS tariff (commission with a minimum, Swift, handling, GST).
- Mismatch → raise a query; the case holds in *Needs attention*.

## Note

The slide-reproduction pages from the first cut, including the to-be flow
diagram, were removed when this became an application. The flow diagram can be
restored as a reference page if it is useful for the meeting.
