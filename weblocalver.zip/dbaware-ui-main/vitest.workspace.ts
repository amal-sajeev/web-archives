export default [
  'apps/*'
];
