﻿$ErrorActionPreference = 'Stop'

$AutobahnHome = if ($env:AUTOBAHN_HOME) { $env:AUTOBAHN_HOME } else { Join-Path $HOME '.autobahn' }
$NodeCacheRoot = Join-Path $AutobahnHome '.node'
$CliCacheRoot = Join-Path $AutobahnHome 'agents'
$BinRoot = Join-Path $AutobahnHome 'bin'
$CliVersion = '0.1.15-beta.33'
$CliUrl = 'https://qa1.toolbar-autobahn.gm.intranet.db.com/tbws/api/download/AGENTS/INT/active.zip'
$CliEntryRelativePath = 'runtime\dist\cli.js'
$NodeVersion = '22.15.0'
$NodeMinMajorVersion = 22
$NodeUrlWin32X64 = 'https://artifactory.intranet.db.com/artifactory/node-dist/v22.15.0/node-v22.15.0-win-x64.zip'
$NodeUrlWin32Arm64 = 'https://artifactory.intranet.db.com/artifactory/node-dist/v22.15.0/node-v22.15.0-win-arm64.zip'
$NodeArchiveTypeWin32X64 = 'zip'
$NodeArchiveTypeWin32Arm64 = 'zip'

function Ensure-Directory([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Download-File([string]$Url, [string]$Destination) {
  Invoke-WebRequest -Uri $Url -OutFile $Destination
}

function Resolve-NodeMajorVersion([string]$NodeBinary) {
  try {
    $RawVersion = & $NodeBinary --version 2>$null
  }
  catch {
    return $null
  }

  if ($RawVersion -match '^v?([0-9]+)') {
    return [int]$Matches[1]
  }

  return $null
}

function Resolve-NodeBinary {
  $ExistingNode = Get-Command node -ErrorAction SilentlyContinue
  if ($ExistingNode) {
    $ExistingNodeMajor = Resolve-NodeMajorVersion $ExistingNode.Source
    if ($ExistingNodeMajor -ge $NodeMinMajorVersion) {
      return $ExistingNode.Source
    }
  }

  $Architecture = $env:PROCESSOR_ARCHITECTURE
  switch ($Architecture) {
    'ARM64' {
      $PlatformKey = 'win32-arm64'
      $NodeUrl = $NodeUrlWin32Arm64
      $NodeArchiveType = $NodeArchiveTypeWin32Arm64
    }
    default {
      $PlatformKey = 'win32-x64'
      $NodeUrl = $NodeUrlWin32X64
      $NodeArchiveType = $NodeArchiveTypeWin32X64
    }
  }

  $InstallRoot = Join-Path (Join-Path $NodeCacheRoot $NodeVersion) $PlatformKey
  if ($NodeArchiveType -ne 'zip') {
    throw "Unsupported Windows Node archive type: $NodeArchiveType"
  }
  $ArchivePath = Join-Path $InstallRoot 'node.zip'
  Ensure-Directory $InstallRoot

  $CachedNode = Get-ChildItem -Path $InstallRoot -Filter node.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $CachedNode) {
    Download-File $NodeUrl $ArchivePath
    Expand-Archive -LiteralPath $ArchivePath -DestinationPath $InstallRoot -Force
    $CachedNode = Get-ChildItem -Path $InstallRoot -Filter node.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
  }

  if (-not $CachedNode) {
    throw "Failed to resolve a cached Node binary under $InstallRoot"
  }

  return $CachedNode.FullName
}

function Resolve-CliEntry {
  $InstallRoot = Join-Path $CliCacheRoot $CliVersion
  $ArchivePath = Join-Path $InstallRoot 'cli.zip'
  $EntryPath = Join-Path $InstallRoot $CliEntryRelativePath
  Ensure-Directory $InstallRoot

  if (-not (Test-Path -LiteralPath $EntryPath)) {
    Download-File $CliUrl $ArchivePath
    Expand-Archive -LiteralPath $ArchivePath -DestinationPath $InstallRoot -Force
  }

  if (-not (Test-Path -LiteralPath $EntryPath)) {
    throw "Failed to resolve the Autobahn CLI entrypoint at $EntryPath"
  }

  return $EntryPath
}

function Install-CommandShim([string]$Path) {
  Ensure-Directory (Split-Path -Parent $Path)
  $Content = @(
    '@echo off',
    'set "NODE_OPTIONS=--use-system-ca %NODE_OPTIONS%"',
    ('"{0}" "{1}" %*' -f $NodeBinary, $CliEntry)
  ) -join "`r`n"
  Set-Content -LiteralPath $Path -Value $Content -Encoding Ascii
}

function Show-PathGuidance {
  $AgentsCmd = Join-Path $BinRoot 'agents.cmd'
  Write-Host ""
  Write-Host "[OK] Autobahn Agents installed successfully!"
  Write-Host ""
  Write-Host "To get started, add the agents command to your PATH:"
  Write-Host ('  $env:Path += '';{0}''' -f $BinRoot)
  Write-Host ""
  Write-Host "Then run:"
  Write-Host "  agents --help"
  Write-Host ""
  Write-Host "Or run directly:"
  Write-Host ('  {0} --help' -f $AgentsCmd)
}

$NodeBinary = Resolve-NodeBinary
$CliEntry = Resolve-CliEntry

Install-CommandShim (Join-Path $BinRoot 'agents.cmd')

Show-PathGuidance