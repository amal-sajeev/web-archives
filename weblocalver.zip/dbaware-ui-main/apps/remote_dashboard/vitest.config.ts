import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const rootDir = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: [path.resolve(rootDir, 'src/test/setupTests.ts')],
    alias: {
      '@wadk/ui': path.resolve(rootDir, 'src/test/mocks/wadkUi.tsx'),
      '@wadk/icons': path.resolve(rootDir, 'src/test/mocks/wadkIcons.tsx'),
    },
  },
});
