import { defineConfig, PluginOption } from 'vite';
import react from '@vitejs/plugin-react';
import federation from '@originjs/vite-plugin-federation';

const API_BASE_URL = '/';

export default defineConfig(({ mode }) => {
  const plugins: PluginOption[] = [react()];

  if (process.env.NODE_ENV !== 'test') {
    plugins.push(
      federation({
        name: 'remote_dashboard',
        filename: 'remoteEntry.js',
        exposes: {
          './Dashboard': './src/Dashboard.tsx',
          './DocumentViewer': './src/pages/DocumentViewer/DocumentViewerPage.tsx',
        },
        shared: [
          'react',
          'react-dom',
          'react/jsx-runtime',
          'react/jsx-dev-runtime',
          'react-router-dom',
          'react-redux',
          'react-dom/client',
          '@reduxjs/toolkit',
          '@wadk/ui',
          '@wadk/icons',
          '@wadk/design-tokens',
          'com.db.rca.commons.afcc-components',
          'quill',
          '@apollo/client',
          'graphql'
        ]
      })
    );
  }

  return {
    optimizeDeps: { force: true },
    plugins,
    build: {
      target: 'esnext',
      minify: false,
      cssCodeSplit: false,
      emptyOutDir: false,
      modulePreload: false,
      sourcemap: true
    },
    server: {
      port: 5004,
      cors: true,
      origin: 'http://localhost:5004',
      proxy: {
        '/dbaware-api-gateway': {
          target: 'https://ct1-cta.dbaware.dev.gcp.db.com',
          changeOrigin: true,
          secure: false
        }
      }
    },
    preview: {
      port: 5004,
      proxy: {
        '/dbaware-api-gateway': {
          target: 'https://ct1-cta.dbaware.dev.gcp.db.com',
          changeOrigin: true,
          secure: false
        }
      }
    }
  };
});