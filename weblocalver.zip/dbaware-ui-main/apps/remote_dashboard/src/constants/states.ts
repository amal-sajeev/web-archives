export type GenerationState = 'empty' | 'generating' | 'generated';
export type SendState = 'idle' | 'loading' | 'sent';
export type ApprovalState = 'idle' | 'loading' | 'approved';
