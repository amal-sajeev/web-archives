export const NOIR_MESSAGES = {
  UPDATE_SUCCESS: 'NOIR updated successfully',
  SEND_SUCCESS: 'NOIR sent successfully',
  EDIT_NOT_ALLOWED_TITLE: 'Edit not allowed',
  EDIT_NOT_ALLOWED_DESCRIPTION: 'Editing is not available at this step.',
  UPDATE_ERROR_TITLE: 'Failed to update NOIR',
  UPDATE_ERROR_DESCRIPTION: 'Could not save the document changes.',
  SEND_NOT_ALLOWED_TITLE: 'Send not allowed',
  SEND_NOT_ALLOWED_DESCRIPTION: 'Sending NOIR is not available at this step.',
  RECIPIENT_REQUIRED_TITLE: 'Recipients email ID',
  RECIPIENT_REQUIRED_DESCRIPTION: 'Recipient is required',
  SEND_ERROR_TITLE: 'Failed to send NOIR',
  SEND_ERROR_DESCRIPTION: 'Could not send the document.',
  DOWNLOAD_ERROR_TITLE: 'Failed to download NOIR',
  DOWNLOAD_ERROR_DESCRIPTION: 'No email content available to download.',
  DOWNLOAD_SUCCESS: 'NOIR email downloaded',
  COPY_SUCCESS: 'Content copied to clipboard',
};

export const DISCOVERY_WALKTHROUGH_MESSAGES = {
  UPDATE_SUCCESS: 'Discovery Walkthrough successfully updated',
  APPROVE_SUCCESS: 'Discovery Walkthrough approved',
  ACTION_NOT_AVAILABLE_TITLE: 'Action not available',
  UPDATE_NOT_AVAILABLE_DESCRIPTION: 'UPDATE_DISCOVERY_WALKTHROUGH is not available for this plan.',
  ACCEPT_NOT_AVAILABLE_DESCRIPTION: 'ACCEPT_DISCOVERY_WALKTHROUGH is not available for this plan.',
  DOWNLOAD_NOT_AVAILABLE_DESCRIPTION: 'DOWNLOAD_DISCOVERY_WALKTHROUGH is not available for this plan.',
  UPDATE_ERROR_TITLE: 'Failed to update section',
  UPDATE_ERROR_DESCRIPTION: 'Could not save this section.',
  APPROVE_ERROR_TITLE: 'Failed to approve discovery walkthrough',
  APPROVE_PLAN_REQUIRED_DESCRIPTION: 'Plan number is not available.',
  APPROVE_ERROR_DESCRIPTION: 'Could not approve the document.',
  GENERATE_ERROR_TITLE: 'Failed to generate Discovery Walkthrough',
  GENERATE_SYNC_SUCCESS_MESSAGE: 'Discovery Walkthrough has been generated successfully.',
  GENERATE_SYNC_FAILED_MESSAGE: 'Failed to generate Discovery Walkthrough. Please try again.',
  LOADING_SUBTITLE: 'loading...........',
  FETCH_FAILED_SUBTITLE: 'Failed to fetch',
  REDIRECT_TO_SCOPE_RECOMMENDATION: 'Redirecting to Generate Scope Recommendation...',
  APPROVE_RESULT: 'Approve Result',
  DOWNLOAD_RESULT: 'Download Result',
  AI_RATIONALE_BUTTON: 'View AI Rationale',
  AI_RATIONALE_TITLE: 'AI Rationale',
  EDIT_SECTION_LABEL: 'Edit section',
  COPY_SECTION_LABEL: 'Copy section',
  COPY_SUCCESS: 'Section copied to clipboard',
  OUTPUT_TITLE: 'Discovery Walkthrough Output',
  KEY_POINTS_LABEL: 'Key Points (one per line)',
  CANCEL: 'Cancel',
  SAVE: 'Save',
  EDIT: 'Edit',
  COPY: 'Copy'
};

export const SCOPE_RECOMMENDATION_MESSAGES = {
  UPDATE_SUCCESS: 'Scope successfully updated',
  APPROVE_SUCCESS: 'Scope approved'
};

export const PRELIMINARY_RESEARCH_MESSAGES = {
  TITLE: 'Preliminary Research Output',
  PLACEHOLDER: 'Compose an epic...',
  RATIONALE_PLACEHOLDER: 'Ai insights did not contain relevant information...',
  LOADING_TEXTS: [
    'Creating Preliminary Research...',
    'Analyzing historical data...',
    'Generating insights...'
  ],
  VIEW_AI_RATIONAL: 'View AI Rational',
  DOWNLOAD_RESULT: 'Download Result',
  APPROVE_RESULT: 'Approve Result',
  GENERATE_DISCOVERY_WALKTHROUGH: 'Generate Discovery Walkthrough',
  RATIONAL_FOR_EDIT: 'Rational for Edit',
  CHARS_REMAINING: '100 characters remaining',
  FAILED_TO_LOAD: 'Failed to load data.',
  APPROVE_SUCCESS: 'Preliminary Research approved successfully',
  COPY_SUCCESS: 'Content copied to clipboard'
};

export const TEST_STEPS_MESSAGES = {
  UPDATE_SUCCESS: 'Test steps saved successfully',
  APPROVE_SUCCESS: 'Result approved successfully',
  COPY_SUCCESS: 'Test steps copied to clipboard',
  TITLE: 'Test Steps Output',
  LOADING_TEXTS: [
    'Creating Test Steps...',
    'Analyzing historical data...',
    'Generating insights...'
  ],
  AI_RATIONAL_TITLE: 'AI Rational',
  AI_RATIONAL_CONTENT: 'AI derived test steps from scope recommendation.'
};
