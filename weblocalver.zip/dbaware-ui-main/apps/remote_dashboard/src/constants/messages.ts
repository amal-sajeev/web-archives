export const NOIR_MESSAGES = {
  UPDATE_SUCCESS: 'NOIR updated successfully',
  SEND_SUCCESS: 'NOIR sent successfully',
};

export const DISCOVERY_WALKTHROUGH_MESSAGES = {
  UPDATE_SUCCESS: 'Discovery Walkthrough successfully updated',
  APPROVE_SUCCESS: 'Discovery Walkthrough approved'
};

export const SCOPE_RECOMMENDATION_MESSAGES = {
  UPDATE_SUCCESS: 'Scope successfully updated',
  APPROVE_SUCCESS: 'Scope approved'
};

export const PRELIMINARY_RESEARCH_MESSAGES = {
  TITLE: 'Preliminary Research Output',
  PLACEHOLDER: 'Compose an epic...',
  RATIONALE_PLACEHOLDER: 'Ai insights did not contain relevant information...',
  LOADING_TEXTS: [
    'Creating Preliminary Research...',
    'Analyzing historical data...',
    'Generating insights...'
  ],
  VIEW_AI_RATIONAL: 'View AI Rational',
  DOWNLOAD_RESULT: 'Download Result',
  APPROVE_RESULT: 'Approve Result',
  GENERATE_DISCOVERY_WALKTHROUGH: 'Generate Discovery Walkthrough',
  RATIONAL_FOR_EDIT: 'Rational for Edit',
  CHARS_REMAINING: '100 characters remaining',
  FAILED_TO_LOAD: 'Failed to load data.',
  APPROVE_SUCCESS: 'Preliminary Research approved successfully',
  COPY_SUCCESS: 'Content copied to clipboard'
};

export const TEST_STEPS_MESSAGES = {
  UPDATE_SUCCESS: 'Test steps saved successfully',
  APPROVE_SUCCESS: 'Result approved successfully',
  COPY_SUCCESS: 'Test steps copied to clipboard',
  TITLE: 'Test Steps Output',
  LOADING_TEXTS: [
    'Creating Test Steps...',
    'Analyzing historical data...',
    'Generating insights...'
  ],
  AI_RATIONAL_TITLE: 'AI Rational',
  AI_RATIONAL_CONTENT: 'AI derived test steps from scope recommendation.'
};
