export const NOR_PLACEHOLDERS = {
  SCORE: 'Very High (100%)',
  RECIPIENTS: 'Recipients: Key Stakeholders (Distribution list to be appended)',
  RATIONALE: 'Metadata matching completed successfully. Risk types and AU aggregations aligned with historical baselines.',
};

export const NOR_MESSAGES = {
  UPDATE_SUCCESS: 'NOR updated successfully',
  SEND_SUCCESS: 'NOR sent successfully',
  GENERATE_SUCCESS: 'NOR generated successfully',
  GENERATE_ERROR: 'Failed to generate NOR',
  UPDATE_ERROR: 'Failed to update NOR',
  SCOPE_COMPLETED : 'Scoping completed successfully',
};

export const NOR_CONFIG = {
  fromAddress: import.meta.env.VITE_NOR_FROM_ADDRESS || 'dbawareaitechteam@list.db.com',
};