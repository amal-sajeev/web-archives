import { withUndoRedoEditorOptions } from '../utils/richTextMarkdownUtils';

export const NOIR_PLACEHOLDERS = {
  SCORE: 'Very High (100%)',
  RECIPIENTS: 'Key Stakeholders (Distribution list to be appended)',
  RATIONALE: 'Metadata matching completed successfully. Risk types and AU aggregations aligned with historical baselines.',
};

export const EDITOR_OPTIONS = withUndoRedoEditorOptions({
  placeholder: 'Compose an epic...',
  modules: {
    toolbar: [['undo', 'redo']],
  },
});

export const INSCOPE_EDITOR_OPTIONS = withUndoRedoEditorOptions({
  placeholder: 'Compose In-Scope...',
  modules: {
    toolbar: [['undo', 'redo']],
  },
});
export const OUTSCOPE_EDITOR_OPTIONS = withUndoRedoEditorOptions({
  placeholder: 'Compose Out-of-Scope...',
  modules: {
    toolbar: [['undo', 'redo']],
  },
});

export const TEST_STEPS_CONSTANTS = {
  APPROVE_TIMEOUT_MS: 1000,
};

export const APP_CONFIG = {
  APP_TITLE: 'DBAware AI Hub',
};

export const NOIR_CONFIG = {
  fromAddress: import.meta.env.VITE_NOIR_FROM_ADDRESS || 'dbawareaitechteam@list.db.com',
};

export const AUTO_REDIRECT_DELAY_MS = 2000;
