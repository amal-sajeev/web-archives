export const norMockData = {
  "email": "Subject: CT&A – Compliance / AFC Testing – Notice of Review – 2025 Swap Dealer (CFTC) (20090)\n\nBody:\nControls Testing & Assurance (CT&A)\n\nCompliance / AFC Testing – Notice of Review\n\n2025 Swap Dealer (CFTC)\n\nCT&A, as part of Compliance & AFC, provides independent feedback on the Risk Management Frameworks, including the first- and second-line Controls that manage Compliance and Financial Crime Risk Types.\n\nThe Compliance/AFC Testing Team is undertaking a review of 2025 Swap Dealer (CFTC).\n\nThe main objective of the review is to assess the design and operating effectiveness of the processes and controls in respect of the Firm's Swap Dealer programs (CFTC ) to help support compliance with Title VII of the Dodd-Frank Act. Testing will cover the following areas:\n\nInvestment Bank\n\nWhere applicable, and in line with the Operational Risk Control Framework Procedure, the Testing Team will assess Key Controls within the Bank Control Inventory (dbGRC / dbCI) which manages the relevant risks covered in the review. If you are not familiar with the Operational Risk Control Framework Minimum Standards or how it applies to your business, please contact your ORM coverage or DCO/BRC team.\n\nPreliminary planning with stakeholders has started, and the Testing Team will begin the fieldwork on 04 August 2025. Testing may require meetings, interviews and requests for information with and from relevant stakeholders.\n\nUpon completion of fieldwork, the Testing Team will discuss any identified issues, Findings and remediation actions with relevant stakeholders and will provide the Testing Team’s assessment conclusion. A draft report will be prepared for discussion and, where possible, agreement prior to the final report being issued.\n\nPlease distribute this information to your relevant teams in anticipation of the Testing Team reaching out, and do not hesitate to contact Dhaval Casimire-samaranayeke if you have any queries.\n\nThank you in advance for your attention and support.",
  "original_data": [
    {
      "Plan Item Number": 20090,
      "Plan Item Title": "2025 Swap Dealer (CFTC)",
      "Description of Plan Item": "Review of Swap Dealer (CFTC)",
      "Coordinating Team Lead": "Dhaval Casimire-samaranayeke",
      "Risk Types": [
        "Compliance / AFC Testing"
      ]
    }
  ]
};