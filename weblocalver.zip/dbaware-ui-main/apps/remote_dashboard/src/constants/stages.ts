/**
 * Workflow stage names used by the comments API (`stage` query param).
 * They match the workflow task definition keys (upper case, underscores).
 */
export enum ScopingStageEnum {
  NOIR = 'NOIR',
  PRELIMINARY_RESEARCH = 'PRELIMINARY_RESEARCH',
  DISCOVERY_WALKTHROUGH = 'DISCOVERY_WALKTHROUGH',
  DISCOVERY_WALKTHROUGH_AGENDA = 'DISCOVERY_WALKTHROUGH_AGENDA',
  SCOPE_RECOMMENDATION = 'SCOPE_RECOMMENDATION',
  TEST_STEPS = 'TEST_STEPS',
  SCOPING_DOCUMENT = 'SCOPING_DOCUMENT',
  FINAL_SCOPE_DOCUMENT = 'FINAL_SCOPE_DOCUMENT',
  NOR = 'NOR',
}
