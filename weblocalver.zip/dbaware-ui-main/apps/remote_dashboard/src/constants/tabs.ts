import { ScopingTabEnum } from "../store/scopingSlice";

export const TABS_CONFIG = [
    { value: ScopingTabEnum.NOIR, label: 'NOIR' },
    { value: ScopingTabEnum.DATA_GATHERING, label: 'Data Gathering' },
    { value: ScopingTabEnum.PRELIMINARY_RESEARCH, label: 'Preliminary Research' },
    { value: ScopingTabEnum.DISCOVERY_WALKTHROUGH, label: 'Discovery Walkthrough' },
    { value: ScopingTabEnum.SCOPE_RECOMMENDATION, label: 'Scope Recommendation' },
    { value: ScopingTabEnum.TEST_STEPS, label: 'Test Steps' },
    { value: ScopingTabEnum.FINAL_SCOPE_DOCUMENT, label: 'Final Scope Document' },
    { value: ScopingTabEnum.NOR, label: 'NoR' },
];