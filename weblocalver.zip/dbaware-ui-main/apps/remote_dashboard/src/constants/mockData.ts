export const discoveryWalkthroughMockData = {
  report_title: "Discovery Walkthrough Preparation",
  sections: [
    {
      section_title: "Key Scope Drivers",
      key_points: [
        "The review is a mandatory annual assessment of the Swap Dealer program for compliance with Title VII of the Dodd-Frank Act (CFTC).",
        "The primary entity in scope is DWS Investment S.A. in Luxembourg (EMEA), with a focus on the client classification process for swap counterparties.",
        "The central control is IRC-CD-1000141 (Client Classification Monitoring Control), but a critical scoping conflict exists as its primary Key Operating Document (KOD) is confirmed as not applicable to the DWS entity.",
        "A historical, medium-rated finding for 'Incorrect client data reported to the CFTC' in the EMEA region (Switzerland) elevates data integrity as a key risk driver for this review.",
        "The scope for in-plan risks R124 (Best Execution), R030 (Business Conflicts), R076 (Information Security), and R077 (Cyber Security) is provisional due to missing or only partially applicable governing documents for the DWS entity."
      ]
    },
    {
      section_title: "Governance, Strategy, and Control Framework",
      key_points: [
        "Control Design & Effectiveness: The design of the primary control (IRC-CD-1000141) for DWS is unknown due to the missing governing KOD, blocking assessment of its design and operating effectiveness.",
        "Framework Coverage & Gaps: The control framework has significant traceability gaps; no governing documents were identified for scoped risks R076 (Information Security) and R077 (Cyber Security) in the DWS context.",
        "Regulatory Synchronization: A global procedure mandates adherence to stricter local regulations like CFTC rules, but the specific implementation mechanism within DWS Luxembourg is undocumented.",
        "Centralized vs. Regional Scoping: The process for managing Business Conflicts (R030) appears to rely on a centralized, bank-wide function (BSCO), but its specific application and integration with the regional DWS unit is undefined.",
        "Risk Mapping Conflict: There is a contradiction in how the key control IRC-CD-1000141 is mapped to risk. The current plan links it to Business Conflicts (R030) and Best Execution (R124), while historical reviews links it to Client Classification (R019).",
        "Governance Oversight: The presence of numerous open F1, F2, and F3 findings against DWS Investment S.A. suggests a heightened risk environment and raises questions about the effectiveness of governance committee oversight and thematic root cause analysis."
      ]
    },
    {
      section_title: "Operational Resilience and Business Continuity",
      key_points: [
        "Data Governance: The historical finding of incorrect CFTC data reporting points to potential weaknesses in data governance and integrity processes for client classification data.",
        "Automated Controls: A prior review indicates that automated monitoring of classification breaks exists via Tableau reports, but the specific parameters, rules, and tools (e.g., dbCAR-CRDS) used for the DWS entity are unconfirmed.",
        "Roles and Responsibilities: Accountable managers and reporting lines for the client classification lifecycle within DWS Luxembourg are currently unknown and have been flagged as a key evidence request.",
        "Process Documentation: A detailed process map for the client classification lifecycle within DWS Luxembourg is missing, hindering the ability to assess operational resilience and control hand-offs.",
        "Alternative Coverage: An approved alternative coverage entry exists for Best Execution (R124), but its scope and effectiveness in mitigating risk for the DWS entity must be verified to justify exclusion from this review."
      ]
    },
    {
      section_title: "Organizational Model and Operating Performance",
      key_points: [
        "Organizational Structure: The reporting hierarchy and role allocation within the DWS Compliance and Operations teams responsible for the in-scope processes are unknown.",
        "Operational Pain Points: The primary operational challenge is the critical documentation gap for the main control, which prevents control testing and creates significant audit and regulatory risk.",
        "Performance Metrics: No information is available on the Key Performance Indicators (KPIs) used to measure the success or efficiency of the client classification process within DWS.",
        "System Limitations: It is unclear if the DWS entity utilizes the same core workflow tools (dbCAR-CRDS) as other divisions, or if different systems and potential integration challenges exist."
      ]
    },
    {
      section_title: "Historical Context and Prior Findings",
      key_points: [
        "A highly similar past review, '2025 Swap Dealer (CFTC)', provides a direct blueprint for testing the design and operating effectiveness of control IRC-CD-1000141.",
        "A significant data conflict exists for the prior review: while a detailed scoping document is available, the corresponding plan item (20090) was officially 'Cancelled', meaning no final report or findings were produced.",
        "A relevant open finding (93-130/2024#5) exists for 'Incorrect client data reported to the CFTC' in Switzerland, suggesting a potential for similar data quality issues within the EMEA region and for the in-scope Luxembourg entity.",
        "A high number of other open findings (F1, F2, F3) exist for DWS Investment S.A. in Luxembourg, indicating a generally heightened risk environment that warrants attention, even if they do not trigger a direct scope exclusion."
      ]
    },
    {
      section_title: "Open Questions and Verification Points",
      key_points: [
        "What is the definitive Key Operating Document (KOD) or procedure that governs the operation of control IRC-CD-1000141 for DWS Investment S.A.?",
        "Please provide the 'DWS Client Classification Policy' document, which is referenced in other applicable policies but was not supplied.",
        "How does the DWS unit in Luxembourg ensure and evidence adherence to stricter local regulatory requirements (e.g., CFTC) for swap dealing?",
        "Can the owner of the 'alternative coverage' for Best Execution (R124) confirm their testing fully mitigates the risk for this AU, justifying its exclusion from our review?",
        "What are the governing policies, processes, and controls for the scoped risks R076 (Information Security) and R077 (Cyber Security) within the DWS EMEA context?",
        "What is the organizational structure, including key accountable managers and reporting lines, for the client classification lifecycle within DWS Luxembourg?",
        "Given the high volume of open findings for DWS Luxembourg, what is management's assessment of the overall control environment and any thematic root causes?",
        "How does control IRC-CD-1000141 effectively mitigate risks related to Business Conflicts (R030) and Best Execution (R124), as suggested by the current plan's risk mapping?"
      ]
    }
  ]
};

export const finalScopeDocumentMockData = {
  title: 'Final Scope Document for Plan ID-R1020',
  content: `<h3>A. Sourced from dbAWARE (Review Metadata)</h3>
<ul>
  <li><strong>Plan Item Type:</strong> Key Operating Document / Review & Test</li>
  <li><strong>Title:</strong> UK Certified Persons regime - cross-border review</li>
  <li><strong>AWARE ID:</strong> 20079</li>
  <li><strong>Review Owner:</strong> Andy Smith</li>
  <li><strong>Team Lead:</strong> Tim David</li>
  <li><strong>Assessment Unit:</strong> FIC, O&A, Research</li>
</ul>
<br/>
<h3>B. Overview, Scope and Timelines</h3>
<h4>Overview</h4>
<p>This review is initiated to evaluate the supervision, oversight, and controls regarding Deutsche Bank's compliance with the UK Certified Persons (CPs) Regime for employees involved in cross-border activities into and outside the UK and Ireland. Given the heightened regulatory focus on employee licensing in the context of their physical location (specifically UK-licensed coverage bankers relocating to Ireland), this review will confirm the adequacy of F&P assessments and line-manager oversight.</p>
<h4>High Level Scope</h4>
<ul>
  <li><strong>In-Scope:</strong> UK-certified CPs residing outside the UK (including 7 in FIC, 20 in O&A, and 1 in Research based in Ireland); annual Fit & Proper (F&P) recertifications; local Irish compliance declarations under the Central Bank of Ireland (CBI) Individual Accountability Framework (IAF Act 2023).</li>
  <li><strong>Out-of-Scope:</strong> Controls C5279 and C5280 (under active remediation); France-resident Research CP (previously validated); temporary "fly-in" overseas visitors (covered by Group Audit Plan No. 55092).</li>
</ul>
<h4>Timeline</h4>
<ul>
  <li><strong>Review Coverage Period:</strong> 1 June 2024 to 31 May 2025</li>
  <li><strong>Fieldwork Start Date:</strong> 1 June 2025</li>
  <li><strong>Planned Publication Date:</strong> 19 September 2025</li>
</ul>
<br/>
<h3>C. Minimum Control Standards (MCS) and Controls</h3>
<ul>
  <li><strong>MCS 032.02:</strong> The Business must maintain an Inventory of Employees and details of license(s) held for his/her role on an ongoing basis.</li>
  <li><strong>MCS 032.15:</strong> The Business must review its staff, at a minimum annually, to identify those individuals whose roles/responsibilities are subject to certification, licensing, or registration requirements.</li>
  <li><strong>Associated Control (dbGRC):</strong> F&P Annual Recertification Process (associated with Control ID C12345).</li>
  <li><strong>Note on Out-of-Scope Controls:</strong> Controls C5279 (Employee Licensing - Review) and C5280 (Employee Licensing - Monitor new joiners) are de-scoped from active testing due to material open findings.</li>
</ul>
<br/>
<h3>D. Material Open Findings/Projects and Ongoing Remediation</h3>
<ul>
  <li><strong>Audit Finding 01209/2024 (The Global Employee Licensing and Registration Audit):</strong><br/><em>Summary:</em> Global Employee Licensing Suite of controls has substantial gaps; no consistent controls exist globally.<br/><em>Impact on Review:</em> Excludes controls C5279 and C5280 from active DE/OE testing during remediation. Target Date: 19 March 2026 (Significant F3 rating).</li>
  <br/>
  <li><strong>Self-Identified Issue (SII) 00704/2024:</strong><br/><em>Summary:</em> Opened to perform a FIC-wide read-across of the ICG audit finding 40-057/2023#3.<br/><em>Impact on Review:</em> Requires CT&A to verify that Dublin-based FIC supervisors are aligned with the remedial actions designed under this read-across. Target Date: 28 November 2025 (Significant F3 rating).</li>
</ul>
`,
  editContent: `<h3>A. Sourced from dbAWARE (Review Metadata)</h3>
<ul>
  <li><strong>Plan Item Type:</strong> Key Operating Document / Review & Test</li>
  <li><strong>Title:</strong> UK Certified Persons regime - cross-border review</li>
  <li><strong>AWARE ID:</strong> 20079</li>
  <li><strong>Review Owner:</strong> Andy Smith</li>
  <li><strong>Team Lead:</strong> Tim David</li>
  <li><strong>Assessment Unit:</strong> FIC, O&A, Research</li>
</ul>
<br/>
<h3>B. Overview, Scope and Timelines</h3>
<h4>Overview</h4>
<p>This review is initiated to evaluate the supervision, oversight, and controls regarding Deutsche Bank's compliance with the UK Certified Persons (CPs) Regime for employees involved in cross-border activities into and outside the UK and Ireland. Given the heightened regulatory focus on employee licensing in the context of their physical location (specifically UK-licensed coverage bankers relocating to Ireland), this review will confirm the adequacy of F&P assessments and line-manager oversight.</p>
<h4>High Level Scope</h4>
<ul>
  <li><strong>In-Scope:</strong> UK-certified CPs residing outside the UK (including 7 in FIC, 20 in O&A, and 1 in Research based in Ireland); annual Fit & Proper (F&P) recertifications; local Irish compliance declarations under the Central Bank of Ireland (CBI) Individual Accountability Framework (IAF Act 2023).</li>
  <li><strong>Out-of-Scope:</strong> Controls C5279 and C5280 (under active remediation); France-resident Research CP (previously validated); temporary "fly-in" overseas visitors (covered by Group Audit Plan No. 55092).</li>
</ul>
<h4>Timeline</h4>
<ul>
  <li><strong>Review Coverage Period:</strong> 1 June 2024 to 31 May 2025</li>
  <li><strong>Fieldwork Start Date:</strong> 1 June 2025</li>
  <li><strong>Planned Publication Date:</strong> 19 September 2025</li>
</ul>
<br/>
<h3>C. Minimum Control Standards (MCS) and Controls</h3>
<ul>
  <li><strong>MCS 032.02:</strong> The Business must maintain an Inventory of Employees and details of license(s) held for his/her role on an ongoing basis.</li>
  <li><strong>MCS 032.15:</strong> The Business must review its staff, at a minimum annually, to identify those individuals whose roles/responsibilities are subject to certification, licensing, or registration requirements.</li>
  <li><strong>Associated Control (dbGRC):</strong> F&P Annual Recertification Process (associated with Control ID C12345).</li>
  <li><strong>Note on Out-of-Scope Controls:</strong> Controls C5279 (Employee Licensing - Review) and C5280 (Employee Licensing - Monitor new joiners) are de-scoped from active testing due to material open findings.</li>
</ul>
<br/>
<h3>D. Material Open Findings/Projects and Ongoing Remediation</h3>
<ul>
  <li><strong>Audit Finding 01209/2024 (The Global Employee Licensing and Registration Audit):</strong><br/><em>Summary:</em> Global Employee Licensing Suite of controls has substantial gaps; no consistent controls exist globally.<br/><em>Impact on Review:</em> Excludes controls C5279 and C5280 from active DE/OE testing during remediation. Target Date: 19 March 2026 (Significant F3 rating).</li>
  <br/>
  <li><strong>Self-Identified Issue (SII) 00704/2024:</strong><br/><em>Summary:</em> Opened to perform a FIC-wide read-across of the ICG audit finding 40-057/2023#3.<br/><em>Impact on Review:</em> Requires CT&A to verify that Dublin-based FIC supervisors are aligned with the remedial actions designed under this read-across. Target Date: 28 November 2025 (Significant F3 rating).</li>
</ul>
`,
  aiRationale: 'AI analyzed 5 similar past reviews. [1.0]'
};

export const noirMockData = {
  "email": "Subject: CT&A – Notice of Intention to Review – Suitability and Appropriateness Review - Global - CB (20583)\n\nBody:\nDear Colleagues\n\nCT&A will be undertaking a review on Suitability and Appropriateness Review - Global - CB. CT&A will review the Design and Operating Effectiveness of the framework and a number of key controls as part of its 2025 Compliance Testing Plan.\n\nCT&A will assess various risks and controls in place in DB in relation to business communications and messaging and use of appropriate channels. These include:\n\nRisks\nR014 - Suitability and Appropriateness - Client & Product\n\ndbGRC CODE    NAME OF KEY CONTROL\nIRC-CD-1001095 - Pre-Trade Escalation -  Designated Client Type (CB - Ex - RMS DACH)\n\nThis review will cover the following areas: Corporate Bank.\n\nKey Timeline:\n  •   Notice of review will be published: Q1 2025\n  •   Planned start of fieldwork: Q1 2025\n  •   End of fieldwork: Q1 2025\n  •   Planned report issuance: Q2 2025\n\nNext Steps: A preliminary data request will be issued and/or targeted discussions will be scheduled with relevant stakeholders and locations to obtain an understanding of the processes in scope. The specific testing scope and approach will be determined following assessment of the information obtained during the scoping phase.\n\nIn the interim, please could you provide the following information:\n•    Any open Self-Identified Issues (SII), Internal or External audit Issues relevant to the above;\n•    Upcoming internal or external audits, which may be relevant for this review;\n•    Any other key points of contacts with whom we can liaise with during the review to obtain relevant information & clarifications; and\n•     Names of all the individuals who should be included in the distribution list for the Notice of Results.\n\nPlease cascade this information through to your relevant teams as you see fit in anticipation of CT&A reaching out. Please do not hesitate to contact any member of our team listed below, if you have any queries:\nTeam Lead: Dhaval Casimire-samaranayeke\n\nThank you in advance for your attention and support regarding this matter.",
  "original_data": [
    {
      "Plan Item Number": 20583,
      "Plan Item Title": "Suitability and Appropriateness Review - Global - CB",
      "Description of Plan Item": "Primary driver is the  Risk Type  rated as \"Significant\" globally and \"Critical\" specifically in UK and Americas. While parts of S&A risk type gets covered in  various reviews and based on AU/RT combination apart from UK and Americas are due only in 2026, we are accelerating coverage in 2025 globally given that a dedicated S&A review was last conducted in 2020. \r\n\r\nThe main objective for this review will be validating that the business lines in scope are selling the right products to its clients, matching the level of complexity of these products with the level of sophistication of its clients. After the implementation of MIFID II regulations, Suitability and Appropriateness (S&A) has become one of the key risks for the finance industry. There is an increased focus from Regulators globally and consequences of not complying can lead to regulatory fines in addition to reputational and legal risks.\r\n\r\nThis is particularly relevant in relation to the GFX product suite which includes Products which are deemed complex.\r\n\r\nESG is also increasingly a potential risk for S&A as consideration to be given to the sustainable products and services to match the client objectives and sustainability preferences and the need to consider sustainability factors.  While there may not be specific rules and regulations across all countries at present, CT&A will consider this risk in further detail during the scoping stage. \r\n\r\nCT&A will review the Design and Operating Effectiveness of the framework and a number of key controls as part of its 2025 Compliance Testing Plan.Primary driver is the  Risk Type  rated as \"Significant\" globally and \"Critical\" specifically in UK and Americas. While parts of S&A risk type gets covered in  various reviews and based on AU/RT combination apart from UK and Americas are due only in 2026, we are accelerating coverage in 2025 globally given that a dedicated S&A review was last conducted in 2020. \r\n\r\nThe main objective for this review will be validating that the business lines in scope are selling the right products to its clients, matching the level of complexity of these products with the level of sophistication of its clients. After the implementation of MIFID II regulations, Suitability and Appropriateness (S&A) has become one of the key risks for the finance industry. There is an increased focus from Regulators globally and consequences of not complying can lead to regulatory fines in addition to reputational and legal risks.\r\n\r\nThis is particularly relevant in relation to the GFX product suite which includes Products which are deemed complex.\r\n\r\nESG is also increasingly a potential risk for S&A as consideration to be given to the sustainable products and services to match the client objectives and sustainability preferences and the need to consider sustainability factors.  While there may not be specific rules and regulations across all countries at present, CT&A will consider this risk in further detail during the scoping stage. \r\n\r\nCT&A will review the Design and Operating Effectiveness of the framework and a number of key controls as part of its 2025 Compliance Testing Plan. ",
      "AU Aggregation point 2": "Corporate Bank",
      "UoT KCs": [
        "IRC-CD-1001095 - Pre-Trade Escalation -  Designated Client Type (CB - Ex - RMS DACH)"
      ],
      "Review Coverage Period Start Date": null,
      "Review Coverage Period End Date": null,
      "Plan Item original Target Start date": "13-Jan-2025",
      "Plan Item Current Target Start Date": "13-Jan-2025",
      "Plan Item Actual Start Date": "13-Jan-2025",
      "Draft Reporting Original Target Start Date": "07-Apr-2025",
      "Draft Reporting Current Target Start Date": "24-Mar-2025",
      "Report Publication Original Target Start Date": "02-May-2025",
      "Report Publication Current Target Start Date": "16-Apr-2025",
      "Coordinating Team Lead": "Casimire-samaranayeke,Dhaval",
      "Review Lead": "",
      "Risk Types": [
        "R014 - Suitability and Appropriateness - Client & Product"
      ]
    }
  ]
};

export const preliminaryResearchMockData = {
  "plan_number": "20593",
  "analysis_report": {
    "Past Review Analysis": {
      "report_title": "Past Review Analysis",
      "paragraphs": [
        {
          "paragraph_id": "para_1",
          "content": "**Section 1: Similar Review Count and Match Summary**\n\nOne similar past review was identified: Plan Item 20140 from 2025. The similarity is based on an identical title, a shared focus on 'Compliance', and a description that references an annual review for the Philippines driven by the \"BSP Manual of Regulation for Banks.\" However, the overall match quality is low due to significant contradictions in the historical data; for example, the review's stated UoT Country is 'Philippines', but its Assessment Units are located in Australia, Brazil, Germany, and the USA. This suggests potential data quality issues in the historical record, limiting its reliability as a direct precedent.",
          "supporting_chunk_ids": [
            "1",
            "2"
          ],
          "rationale": "The identification of one similar review is based on the exact match of the 'Plan Item Title' and the shared reference to the \"BSP Manual of Regulation for Banks\" in the descriptions of both the current and past reviews. The overall match quality assessment is derived from noting the significant contradictions within the past review's data, such as the mismatch between its stated UoT Country ('Philippines') and its actual AU Countries ('Australia', 'Brazil', 'Germany', 'United States of America').",
          "metadata": {
            "is_section_start": true,
            "section_confidence_score": 50
          }
        },
        {
          "paragraph_id": "para_2",
          "content": "**Section 2: Prior Review Coverage Inventory**\n\nThe similar review is titled \"Remote Location Testing - Philippines - CB/IB\" (Plan Item 20140) from plan year 2025, with no report number or coverage period specified. Its coverage themes included:\n\n*   **Risk Types:** Churning (R028), Bribery & Corruption (R053), Credit Fraud (R132), and Financial Sanctions (R150).\n*   **Business Lines:** Corporate Cash Management, Business Banking, and CB Central & Functions.\n*   **Jurisdictions:** Despite a UoT Country of 'Philippines', the review's Assessment Units were in Australia, Brazil, Germany, and the United States.\n*   **Core Process:** 'AFC Risk Type Assessment'.",
          "supporting_chunk_ids": [
            "2"
          ],
          "rationale": "The inventory of the prior review and its coverage themes was compiled by directly extracting data points from the historical plan item details. Specifically, the review's title, plan number, and year were taken from their respective fields, while the coverage themes were synthesized from the 'UoT Risk Type', 'AU Aggregation Point' hierarchy, 'AU Countries', and 'UoT Core Process' fields.",
          "metadata": {
            "is_section_start": true,
            "section_confidence_score": 90
          }
        },
        {
          "paragraph_id": "para_3",
          "content": "**Section 3: Historical Scope Focus and Testing Approach**\n\nThe scope focus of the 2025 review was on 'AFC Risk Type Assessment' and devising an \"annual testing plan... to test areas of Compliance Risks management,\" as stated in its description. No explicit testing approach, such as Design Effectiveness (DE) or Operating Effectiveness (OE) paths, is documented, as the scoping document from the prior review was not available.",
          "supporting_chunk_ids": [
            "2",
            "3"
          ],
          "rationale": "The historical scope focus on \"Compliance Risks management\" and \"AFC Risk Type Assessment\" is identified from the 'Description of Plan Item' and 'UoT Core Process' fields in the past review data. The testing approach is inferred from the description's mention of a \"testing plan,\" as no explicit methodology was available in the provided data.",
          "metadata": {
            "is_section_start": false,
            "section_confidence_score": 40
          }
        },
        {
          "paragraph_id": "para_4",
          "content": "**Section 4: Standards, Regulations, Procedures, KODs, and Control Framework Signals**\n\nThe 2025 review explicitly referenced the \"BSP Manual of Regulation for Banks\" and \"DB Group Policies and Procedures\" in its description. The data also contained signals of other, seemingly unrelated regulations in the UoT LRR field, such as \"31 CFR Part 212 Garnishment of Accounts Containing Federal Benefits,\" and operating letters like \"Beneficial Ownership Requirements for Legal Entity Customers (2018)\" in the UoT OELs field.",
          "supporting_chunk_ids": [
            "2"
          ],
          "rationale": "The identified regulatory signals are based on direct extraction from the historical review data. The \"BSP Manual of Regulation for Banks\" and \"DB Group Policies and Procedures\" are explicitly mentioned in the 'Description of Plan Item', while other regulations like \"31 CFR Part 212\" and operating letters like \"Beneficial Ownership Requirements\" are taken from the 'UoT LRR' and 'UoT OELs' fields respectively.",
          "metadata": {
            "is_section_start": true,
            "section_confidence_score": 60
          }
        }
      ]
    }
  }
};

export const scopeRecommendationMockData = {
  title: 'Scope Recommendation for Plan ID- R1020',
  content: `<h3>A. Sourced from dbAWARE (Review Metadata)</h3>
<ul>
  <li><strong>Plan Item Type:</strong> Key Operating Document / Review & Test</li>
  <li><strong>Title:</strong> UK Certified Persons regime - cross-border review</li>
  <li><strong>AWARE ID:</strong> 20079</li>
  <li><strong>Review Owner:</strong> Andy Smith</li>
  <li><strong>Team Lead:</strong> Tim David</li>
  <li><strong>Assessment Unit:</strong> FIC, O&A, Research</li>
</ul>
<br/>
<h3>B. Overview, Scope and Timelines</h3>
<h4>Overview</h4>
<p>This review is initiated to evaluate the supervision, oversight, and controls regarding Deutsche Bank's compliance with the UK Certified Persons (CPs) Regime for employees involved in cross-border activities into and outside the UK and Ireland. Given the heightened regulatory focus on employee licensing in the context of their physical location (specifically UK-licensed coverage bankers relocating to Ireland), this review will confirm the adequacy of F&P assessments and line-manager oversight.</p>
<h4>High Level Scope</h4>
<ul>
  <li><strong>In-Scope:</strong> UK-certified CPs residing outside the UK (including 7 in FIC, 20 in O&A, and 1 in Research based in Ireland); annual Fit & Proper (F&P) recertifications; local Irish compliance declarations under the Central Bank of Ireland (CBI) Individual Accountability Framework (IAF Act 2023).</li>
  <li><strong>Out-of-Scope:</strong> Controls C5279 and C5280 (under active remediation); France-resident Research CP (previously validated); temporary "fly-in" overseas visitors (covered by Group Audit Plan No. 55092).</li>
</ul>
<h4>Timeline</h4>
<ul>
  <li><strong>Review Coverage Period:</strong> 1 June 2024 to 31 May 2025</li>
  <li><strong>Fieldwork Start Date:</strong> 1 June 2025</li>
  <li><strong>Planned Publication Date:</strong> 19 September 2025</li>
</ul>
<br/>
<h3>C. Minimum Control Standards (MCS) and Controls</h3>
<ul>
  <li><strong>MCS 032.02:</strong> The Business must maintain an Inventory of Employees and details of license(s) held for his/her role on an ongoing basis.</li>
  <li><strong>MCS 032.15:</strong> The Business must review its staff, at a minimum annually, to identify those individuals whose roles/responsibilities are subject to certification, licensing, or registration requirements.</li>
  <li><strong>Associated Control (dbGRC):</strong> F&P Annual Recertification Process (associated with Control ID C12345).</li>
  <li><strong>Note on Out-of-Scope Controls:</strong> Controls C5279 (Employee Licensing - Review) and C5280 (Employee Licensing - Monitor new joiners) are de-scoped from active testing due to material open findings.</li>
</ul>`,
  editContent: `<h3>A. Sourced from dbAWARE (Review Metadata)</h3>
<ul>
  <li><strong>Plan Item Type:</strong> Key Operating Document / Review & Test</li>
  <li><strong>Title:</strong> UK Certified Persons regime - cross-border review</li>
  <li><strong>AWARE ID:</strong> 20079</li>
  <li><strong>Review Owner:</strong> Andy Smith</li>
  <li><strong>Team Lead:</strong> Tim David</li>
  <li><strong>Assessment Unit:</strong> FIC, O&A, Research</li>
</ul>
<br/>
<h3>B. Overview, Scope and Timelines</h3>
<h4>Overview</h4>
<p>This review is initiated to evaluate the supervision, oversight, and controls regarding Deutsche Bank's compliance with the UK Certified Persons (CPs) Regime for employees involved in cross-border activities into and outside the UK and Ireland. Given the heightened regulatory focus on employee licensing in the context of their physical location (specifically UK-licensed coverage bankers relocating to Ireland), this review will confirm the adequacy of F&P assessments and line-manager oversight.</p>
<h4>High Level Scope</h4>
<ul>
  <li><strong>In-Scope:</strong> UK-certified CPs residing outside the UK (including 7 in FIC, 20 in O&A, and 1 in Research based in Ireland); annual Fit & Proper (F&P) recertifications; local Irish compliance declarations under the Central Bank of Ireland (CBI) Individual Accountability Framework (IAF Act 2023).</li>
  <li><strong>Out-of-Scope:</strong> Controls C5279 and C5280 (under active remediation); France-resident Research CP (previously validated); temporary "fly-in" overseas visitors (covered by Group Audit Plan No. 55092).</li>
</ul>
<h4>Timeline</h4>
<ul>
  <li><strong>Review Coverage Period:</strong> 1 June 2024 to 31 May 2025</li>
  <li><strong>Fieldwork Start Date:</strong> 1 June 2025</li>
  <li><strong>Planned Publication Date:</strong> 19 September 2025</li>
</ul>
<br/>
<h3>C. Minimum Control Standards (MCS) and Controls</h3>
<ul>
  <li><strong>MCS 032.02:</strong> The Business must maintain an Inventory of Employees and details of license(s) held for his/her role on an ongoing basis.</li>
  <li><strong>MCS 032.15:</strong> The Business must review its staff, at a minimum annually, to identify those individuals whose roles/responsibilities are subject to certification, licensing, or registration requirements.</li>
  <li><strong>Associated Control (dbGRC):</strong> F&P Annual Recertification Process (associated with Control ID C12345).</li>
  <li><strong>Note on Out-of-Scope Controls:</strong> Controls C5279 (Employee Licensing - Review) and C5280 (Employee Licensing - Monitor new joiners) are de-scoped from active testing due to material open findings.</li>
</ul>`,
  aiRationale: 'AI analyzed 5 similar past reviews. [1.0]'
};

export const testStepsMockData = {
  title: 'Test Steps Plan ID-R1020',
  content: `<h3>Test Steps &mdash; Areas Covered and Obligations</h3>
<h4>Test Step 1: Annual Fit &amp; Proper Recertification</h4>
<ul>
  <li><strong>Area Covered / Core Process:</strong> Annual Recertification / Employee Licensing Lifecycle.</li>
  <li><strong>Risk &amp; Risk Crystallisation Scenario:</strong>
    <ul>
      <li><em>Risk:</em> DB employees do not comply with individual licensing and certification requirements.</li>
      <li><em>Crystallisation Scenario (R032 - RD2):</em> Risk that an overseas-based Certified Person fails to maintain or renew their UK license while engaged in UK-regulated activities, or fails to complete local Irish F&P requirements.</li>
    </ul>
  </li>
  <li><strong>Regulatory Obligation:</strong> FCA Handbook SYSC 27.2.4 (annual certification requirement) and Central Bank of Ireland IAF Act 2023 Section 10 (12-month validity of compliance certificates).</li>
  <li><strong>Mitigants:</strong> Centralized tracking by UK Employee Compliance; local Dublin branch F&P compliance forms.</li>
  <li><strong>Controls:</strong> Control ID C12345 (F&P Annual Recertification).</li>
</ul>
<br/>
<h4>DE &amp; OE</h4>
<ul>
  <li><strong>Design Effectiveness (DE) Test Step:</strong> Review the design of the annual recertification procedure to confirm it integrates both UK FCA SYSC 27 and Irish CBI IAF criteria, and ensures the dual-regulatory status of Dublin-based CPs is explicitly checked.</li>
  <li><strong>Operating Effectiveness (OE) Test Step:</strong> Select a sample of Dublin-based CPs and inspect their completed F&P assessment forms, local Irish compliance declarations, and training completion logs to verify recertification was executed within the mandatory 12-month window.</li>
</ul>`,
  editContent: `<h3>Test Steps &mdash; Areas Covered and Obligations</h3>
<h4>Test Step 1: Annual Fit &amp; Proper Recertification</h4>
<ul>
  <li><strong>Area Covered / Core Process:</strong> Annual Recertification / Employee Licensing Lifecycle.</li>
  <li><strong>Risk &amp; Risk Crystallisation Scenario:</strong>
    <ul>
      <li><em>Risk:</em> DB employees do not comply with individual licensing and certification requirements.</li>
      <li><em>Crystallisation Scenario (R032 - RD2):</em> Risk that an overseas-based Certified Person fails to maintain or renew their UK license while engaged in UK-regulated activities, or fails to complete local Irish F&P requirements.</li>
    </ul>
  </li>
  <li><strong>Regulatory Obligation:</strong> FCA Handbook SYSC 27.2.4 (annual certification requirement) and Central Bank of Ireland IAF Act 2023 Section 10 (12-month validity of compliance certificates).</li>
  <li><strong>Mitigants:</strong> Centralized tracking by UK Employee Compliance; local Dublin branch F&P compliance forms.</li>
  <li><strong>Controls:</strong> Control ID C12345 (F&P Annual Recertification).</li>
</ul>
<br/>
<h4>DE &amp; OE</h4>
<ul>
  <li><strong>Design Effectiveness (DE) Test Step:</strong> Review the design of the annual recertification procedure to confirm it integrates both UK FCA SYSC 27 and Irish CBI IAF criteria, and ensures the dual-regulatory status of Dublin-based CPs is explicitly checked.</li>
  <li><strong>Operating Effectiveness (OE) Test Step:</strong> Select a sample of Dublin-based CPs and inspect their completed F&P assessment forms, local Irish compliance declarations, and training completion logs to verify recertification was executed within the mandatory 12-month window.</li>
</ul>`,
  aiRationale: 'AI analyzed 5 similar past reviews. [1.0]'
};
