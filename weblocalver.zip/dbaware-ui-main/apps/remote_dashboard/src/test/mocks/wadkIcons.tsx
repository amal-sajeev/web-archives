import React from 'react';

const createIcon = (displayName: string) => {
  const Component = () => React.createElement('svg', { 'data-testid': displayName });
  Component.displayName = displayName;
  return Component;
};

export const DownloadSolid = createIcon('DownloadSolid');
export const EditBoxSolid = createIcon('EditBoxSolid');
export const EnvelopeOutline = createIcon('EnvelopeOutline');
export const CloneSolid = createIcon('CloneSolid');
export const ContextInfoOutline = createIcon('ContextInfoOutline');
