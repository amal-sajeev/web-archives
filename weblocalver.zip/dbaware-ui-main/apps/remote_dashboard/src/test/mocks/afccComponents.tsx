import React from 'react';
import { vi } from 'vitest';

export const EmptyScopingState = ({ title, subtitle, actionText, onActionClick, secondaryActionText, onSecondaryActionClick }: any) => React.createElement(
  'div',
  { 'data-testid': 'EmptyScopingState' },
  React.createElement('div', { 'data-testid': 'empty-title' }, title),
  subtitle ? React.createElement('div', { 'data-testid': 'empty-subtitle' }, subtitle) : null,
  actionText ? React.createElement('button', { type: 'button', onClick: onActionClick }, actionText) : null,
  secondaryActionText ? React.createElement('button', { type: 'button', onClick: onSecondaryActionClick }, secondaryActionText) : null
);

export const EmailView = ({ subject, teamLeadName, recipients, content }: any) => React.createElement(
  'div',
  { 'data-testid': 'EmailView' },
  subject ? React.createElement('div', null, subject) : null,
  teamLeadName ? React.createElement('div', null, teamLeadName) : null,
  recipients ? React.createElement('div', null, recipients) : null,
  content ? React.createElement('div', null, content) : null
);

export const EmailEdit = ({ subject, content, recipients }: any) => React.createElement(
  'div',
  { 'data-testid': 'EmailEdit' },
  subject ? React.createElement('div', null, subject) : null,
  content ? React.createElement('div', null, content) : null,
  recipients ? React.createElement('div', null, recipients) : null
);

export const FadingTextCycler = ({ texts }: any) => React.createElement('div', { 'data-testid': 'FadingTextCycler' }, Array.isArray(texts) ? texts.join(' | ') : String(texts));

export const showSuccessToast = vi.fn();
export const showErrorToast = vi.fn();
