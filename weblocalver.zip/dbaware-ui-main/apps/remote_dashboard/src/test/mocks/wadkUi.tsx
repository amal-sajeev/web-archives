import React from 'react';

const createBlock = (tagName: keyof JSX.IntrinsicElements, displayName: string) => {
  const Component = ({ children, outlined, ...props }: any) => React.createElement(tagName, { 'data-testid': displayName, ...props }, children);
  Component.displayName = displayName;
  return Component;
};

const createButton = (displayName: string) => {
  const Component = ({ children, icon, onClick, loading, disabled, ...props }: any) => React.createElement(
    'button',
    { type: 'button', 'data-testid': displayName, onClick, disabled, ...props },
    icon,
    children,
    loading ? 'loading' : null
  );
  Component.displayName = displayName;
  return Component;
};

export const Card = createBlock('div', 'Card');
export const CardContent = createBlock('div', 'CardContent');
export const CardHeader = createBlock('header', 'CardHeader');
export const CardTitle = ({ content }: any) => React.createElement('h1', { 'data-testid': 'CardTitle' }, content);
export const LeftSlot = createBlock('div', 'LeftSlot');
export const Stack = createBlock('div', 'Stack');
export const Button = createButton('Button');
export const RightSlot = createBlock('div', 'RightSlot');
export const OutlineButton = createButton('OutlineButton');
export const CardFooter = createBlock('footer', 'CardFooter');
export const CardSubHeader = createBlock('div', 'CardSubHeader');
export const Text = createBlock('span', 'Text');
export const Separator = createBlock('hr', 'Separator');
export const NavTab = createBlock('div', 'NavTab');
export const Tab = createButton('Tab');
export const PopoverTrigger = createBlock('div', 'PopoverTrigger');
export const Popover = createBlock('div', 'Popover');
export const PopoverSurface = createBlock('div', 'PopoverSurface');
export const ModalDialog = createBlock('div', 'ModalDialog');
export const FormGroup = createBlock('div', 'FormGroup');
export const FormItem = createBlock('div', 'FormItem');
export const TextInput = createBlock('input', 'TextInput');
export const TextArea = createBlock('textarea', 'TextArea');
