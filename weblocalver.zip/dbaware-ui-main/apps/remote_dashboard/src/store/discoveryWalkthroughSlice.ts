import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface DiscoveryWalkthroughState {
    reports: {
        [planNumber: string]: any;
    }
}

const initialState: DiscoveryWalkthroughState = {
    reports: {}
};

const discoveryWalkthroughSlice = createSlice({
    name: 'discoveryWalkthrough',
    initialState,
    reducers: {
        setDiscoveryWalkthroughData: (state, action: PayloadAction<{ planNumber: string, data: any }>) => {
            const { planNumber, data } = action.payload;
            state.reports[planNumber] = data;
        },
    },
});

export const { setDiscoveryWalkthroughData } = discoveryWalkthroughSlice.actions;
export default discoveryWalkthroughSlice.reducer;