import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface NoirState {
    reports: {
        [planNumber: string]: any;
    }
}

const initialState: NoirState = {
    reports: {}
};

const noirSlice = createSlice({
    name: 'noir',
    initialState,
    reducers: {
        setNoirData: (state, action: PayloadAction<{ planNumber: string, data: any }>) => {
            const { planNumber, data } = action.payload;
            state.reports[planNumber] = data;
        },
    },
});

export const { setNoirData } = noirSlice.actions;
export default noirSlice.reducer;