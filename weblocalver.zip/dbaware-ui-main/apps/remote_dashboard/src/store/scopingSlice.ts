import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { TestStep, TestStepEntry } from '../api/type';

export enum ScopingTabEnum {
  NOIR = 'noir',
  DATA_GATHERING = 'data-gathering',
  PRELIMINARY_RESEARCH = 'preliminary-research',
  DISCOVERY_WALKTHROUGH = 'discovery-walkthrough',
  SCOPE_RECOMMENDATION = 'scope-recommendation',
  FINAL_SCOPE_DOCUMENT = 'final-scope-document',
  NOR = 'nor',
  TEST_STEPS = 'test-steps'
}

export interface NoirOriginalData {
  "Plan Item Number": number;
  "Plan Item Title": string;
  "Description of Plan Item": string;
  "AU Aggregation point 2": string;
  "UoT KCs": string[];
  "Review Coverage Period Start Date": string | null;
  "Review Coverage Period End Date": string | null;
  "Plan Item original Target Start date": string;
  "Plan Item Current Target Start Date": string;
  "Plan Item Actual Start Date": string;
  "Draft Reporting Original Target Start Date": string;
  "Draft Reporting Current Target Start Date": string;
  "Report Publication Original Target Start Date": string;
  "Report Publication Current Target Start Date": string;
  "Coordinating Team Lead": string;
  "Review Lead": string;
  "Risk Types": string[];
}

export interface NoirData {
  subject?: string;
  body?: string;
  email?: string;
  recipients?: string[];
  next_available_actions?: string[];
  task_definition_key?: string;
  original_data?: NoirOriginalData[];
}

export interface DiscoveryWalkthroughSection {
  section_title: string;
  key_points: string[];
}

export interface DiscoveryWalkthroughData {
  report_title: string;
  sections: DiscoveryWalkthroughSection[];
}

export interface ScopeRecommendationSection {
  report?: string;
  rationale?: string;
  confidence_score?: number;
}

export type ScopeRecommendationSectionValue = string | ScopeRecommendationSection;

export interface ScopeRecommendationData {
  planNumber?: string;
  inscope: ScopeRecommendationSectionValue;
  outscope: ScopeRecommendationSectionValue;
  report_title?: string;
  aiRationale?: string;
  rationale?: string;
  confidence_score?: number;
}

export interface TestStepsData {
  planNumber: string;
  test_steps: TestStepEntry[];
}

export interface ScopingState {
  enabledTabs: ScopingTabEnum[];
  maxReachedTabIndex: number;
  noirData: NoirData | null;
  nextAvailableActionsByPlan: Record<string, string[]>;
  taskDefinitionKeyByPlan: Record<string, string>;
  discoveryWalkthroughData: DiscoveryWalkthroughData | null;
  scopeRecommendationData: ScopeRecommendationData | null;
  testStepsData: TestStepsData | null;
  finalScopeDocumentPdfDataUrl: string | null;
  finalScopeDocumentPlanId: string | null;
  recipients: any[];
  isGeneratingNoir?: boolean;
}

const initialState: ScopingState = {
  enabledTabs: [ScopingTabEnum.NOIR],
  maxReachedTabIndex: 0,
  noirData: null,
  nextAvailableActionsByPlan: {},
  taskDefinitionKeyByPlan: {},
  discoveryWalkthroughData: null,
  scopeRecommendationData: null,
  testStepsData: null,
  finalScopeDocumentPdfDataUrl: null,
  finalScopeDocumentPlanId: null,
  recipients: [],
  isGeneratingNoir: false,
};

export const scopingSlice = createSlice({
  name: 'scoping',
  initialState,
  reducers: {
    enableTab: (state, action: PayloadAction<ScopingTabEnum>) => {
      if (!state.enabledTabs.includes(action.payload)) {
        state.enabledTabs.push(action.payload);
      }
    },
    disableTab: (state, action: PayloadAction<ScopingTabEnum>) => {
      state.enabledTabs = state.enabledTabs.filter(tab => tab !== action.payload);
    },
    setIsGeneratingNoir: (state, action: PayloadAction<boolean>) => {
      state.isGeneratingNoir = action.payload;
    },
    setNoirData: (state, action: PayloadAction<NoirData>) => {
      state.noirData = action.payload;
    },
    setNextAvailableActionsForPlan: (
      state,
      action: PayloadAction<{ planNumber: string; actions: string[] }>
    ) => {
      const { planNumber, actions } = action.payload;
      state.nextAvailableActionsByPlan[planNumber] = actions;
    },
    setTaskDefinitionKeyForPlan: (
      state,
      action: PayloadAction<{ planNumber: string; taskDefinitionKey: string }>
    ) => {
      const { planNumber, taskDefinitionKey } = action.payload;
      state.taskDefinitionKeyByPlan[planNumber] = taskDefinitionKey;
    },
    setDiscoveryWalkthroughData: (state, action: PayloadAction<DiscoveryWalkthroughData>) => {
      state.discoveryWalkthroughData = action.payload;
    },
    setScopeRecommendationData: (state, action: PayloadAction<ScopeRecommendationData>) => {
      state.scopeRecommendationData = action.payload;
    },
    setTestStepsData: (state, action: PayloadAction<TestStepsData>) => {
      state.testStepsData = action.payload;
    },
    setFinalScopeDocumentPdf: (state, action: PayloadAction<{ planId: string; pdfDataUrl: string }>) => {
      state.finalScopeDocumentPlanId = action.payload.planId;
      state.finalScopeDocumentPdfDataUrl = action.payload.pdfDataUrl;
    },
    clearFinalScopeDocumentPdf: (state) => {
      state.finalScopeDocumentPlanId = null;
      state.finalScopeDocumentPdfDataUrl = null;
    },
    setRecipients: (state, action: PayloadAction<any[]>) => {
      state.recipients = action.payload;
    },
    setMaxReachedTabIndex: (state, action: PayloadAction<number>) => {
      state.maxReachedTabIndex = Math.max(state.maxReachedTabIndex, action.payload);
    }
  }
});

export const { enableTab, disableTab, setIsGeneratingNoir, setNoirData, setNextAvailableActionsForPlan, setTaskDefinitionKeyForPlan, setDiscoveryWalkthroughData, setScopeRecommendationData, setTestStepsData, setFinalScopeDocumentPdf, clearFinalScopeDocumentPdf, setRecipients, setMaxReachedTabIndex } = scopingSlice.actions;
export default scopingSlice.reducer;
