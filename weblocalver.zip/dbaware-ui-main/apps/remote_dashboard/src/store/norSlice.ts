import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface NorOriginalData {
  "Plan Item Number"?: number;
  "Plan Item Title"?: string;
  "Description of Plan Item"?: string;
  "Coordinating Team Lead"?: string;
  "Review Lead"?: string;
  "Risk Types"?: string[];
  [key: string]: any;
}

export interface NorData {
  subject?: string;
  body?: string;
  email_content?: string;
  email: string;
  recipients?: string[];
  original_data: NorOriginalData[];
}

export interface NorState {
  norData: NorData | null;
  isGeneratingNor?: boolean;
}

const initialState: NorState = {
  norData: null,
  isGeneratingNor: false,
};

export const norSlice = createSlice({
  name: 'nor',
  initialState,
  reducers: {
    setNorData: (state, action: PayloadAction<NorData>) => {
      state.norData = action.payload;
    },
    setIsGeneratingNor: (state, action: PayloadAction<boolean>) => {
      state.isGeneratingNor = action.payload;
    },
  }
});

export const { setNorData, setIsGeneratingNor } = norSlice.actions;
export default norSlice.reducer;