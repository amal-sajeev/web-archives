import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface PreliminaryResearchState {
    reports: {
        [planNumber: string]: any;
    }
}

const initialState: PreliminaryResearchState = {
    reports: {}
};

const preliminaryResearchSlice = createSlice({
    name: 'preliminaryResearch',
    initialState,
    reducers: {
        setPreliminaryResearchData: (state, action: PayloadAction<{ planNumber: string, data: any }>) => {
            const { planNumber, data } = action.payload;
            state.reports[planNumber] = data;
        },
    },
});

export const { setPreliminaryResearchData } = preliminaryResearchSlice.actions;
export default preliminaryResearchSlice.reducer;