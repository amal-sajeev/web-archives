import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface DataGatheringState {
    artifacts: {
        [planNumber: string]: {
            [artifactType: string]: any;
        }
    }
}

const initialState: DataGatheringState = {
    artifacts: {}
};

const dataGatheringSlice = createSlice({
    name: 'dataGathering',
    initialState,
    reducers: {
        setArtifactData: (state, action: PayloadAction<{ planNumber: string, artifactType: string, data: any }>) => {
            const { planNumber, artifactType, data } = action.payload;
            if (!state.artifacts[planNumber]) {
                state.artifacts[planNumber] = {};
            }
            state.artifacts[planNumber][artifactType] = data;
        },
    },
});

export const { setArtifactData } = dataGatheringSlice.actions;
export default dataGatheringSlice.reducer;