import React, { useEffect, useRef, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import ScopeTabs from '../../components/ScopeTabs/ScopeTabs';
import { AppToaster } from '../../components/AppToaster/AppToaster';
import { getTaskStatus, startScoping, getNextAvailableActionsFromTaskStatus } from '../../api/scopingClient';
import { setTaskDefinitionKeyForPlan, setNextAvailableActionsForPlan } from '../../store/scopingSlice';
import { usePlanId } from '../../hooks/usePlanId';
import styles from './ScopeLayout.module.css';

const normalizeTaskDefinitionKey = (value: string): string =>
  value
    .trim()
    .replace(/[\s-]+/g, '_')
    .toUpperCase();

const SCOPING_STATUS_SYNC_INTERVAL_MS = 60 * 1000;

const ScopeLayout: React.FC = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const [showScopingInProgressModal, setShowScopingInProgressModal] = useState(false);
  const startScopingTriggeredByPlanRef = useRef({} as Record<string, boolean>);
  const planId = usePlanId();

  useEffect(() => {
    if (!planId) {
      setShowScopingInProgressModal(false);
      return;
    }

    let isActive = true;
    let intervalId: ReturnType<typeof setInterval> | null = null;

    let isSyncInProgress = false;

    const stopSync = () => {
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
    };

    const syncScopingStatus = async () => {
      if (isSyncInProgress) return;
      isSyncInProgress = true;

      try {
        const response = await getTaskStatus(planId);
        if (!isActive) return;

        const resolvedPlanNumber = String(response.planNumber ?? planId);
        const taskDefinitionKey = typeof response.taskDefinitionKey === 'string' ? response.taskDefinitionKey : '';

        dispatch(setTaskDefinitionKeyForPlan({
          planNumber: resolvedPlanNumber, taskDefinitionKey,
        }));
        dispatch(setNextAvailableActionsForPlan({
          planNumber: resolvedPlanNumber,
          actions: getNextAvailableActionsFromTaskStatus(response),
        }));

        if (response.taskDefinitionKey === null) {
          if (!startScopingTriggeredByPlanRef.current[resolvedPlanNumber]) {
            startScopingTriggeredByPlanRef.current[resolvedPlanNumber] = true;
            await startScoping(resolvedPlanNumber, true);
          }

          if (isActive) {
            setShowScopingInProgressModal(true);
          }
          return;
        }

        const normalizedTaskDefinitionKey = normalizeTaskDefinitionKey(taskDefinitionKey);
        setShowScopingInProgressModal(normalizedTaskDefinitionKey === 'DATA_GATHERING');

        if (response.taskDefinitionKey !== null && normalizedTaskDefinitionKey !== 'DATA_GATHERING') {
          stopSync();
        }
      } catch (error) {
        console.warn('Failed to sync scoping status in ScopeLayout', error);
      } finally {
        isSyncInProgress = false;
      }
    };

    void syncScopingStatus();
    intervalId = setInterval(() => {
      void syncScopingStatus();
    }, SCOPING_STATUS_SYNC_INTERVAL_MS);

    return () => {
      isActive = false;
      stopSync();
    };
  }, [dispatch, planId, location.pathname]);

  return (
    <>
      <ScopeTabs />
      {!showScopingInProgressModal && <Outlet key={location.pathname} />}
      {showScopingInProgressModal && (
        <div className={styles.scopingModalOverlay} role="dialog" aria-modal="true" aria-label="Scoping process in progress">
          <div className={styles.scopingModalContent}>
            <div className={styles.scopingModalBadge}>Data extraction In progress</div>
            <h3 className={styles.scopingModalTitle}>Preparing your workitem</h3>
            <p className={styles.scopingModalText}>
              The screen will become active automatically once processing is complete.
            </p>
            <p className={styles.scopingModalSubText}>
              This may take a few minutes.
            </p>
            <div className={styles.scopingProgressTrack} aria-hidden="true">
              <div className={styles.scopingProgressIndicator} />
            </div>
          </div>
        </div>
      )}
      <AppToaster />
    </>
  );
};

export default ScopeLayout;
