// Use direct path to leverage current origin
export const NOR_API_PATHS = {
    actions: `/dbaware-api-gateway/api/v1/actions`,
};