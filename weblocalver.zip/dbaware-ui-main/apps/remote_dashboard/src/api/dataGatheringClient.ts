import { apiClient, API_BASE_URL } from './apiClient';
import type {
    PlanArtifactResponse,
    ArtifactType,
    DataExtractionTriggerResponse,
    DataExtractionStatusResponse,
    PlanAvailabilityResponse,
    LrrProcessStartResponse,
    LrrProcessStatusResponse,
    LrrRunDetailsResponse,
} from './type';

type DataGatheringAction =
    | 'DATA_EXTRACTION'
    | 'GET_DATA_EXTRACTION_STATUS'
    | 'GET_PLAN_AVAILABILITY'
    | 'GET_PLAN_ARTIFACT';

interface DataGatheringGatewayRequest<TPayload> {
    planNumber: string;
    action: DataGatheringAction;
    payload: TPayload;
}

const DG_ACTIONS_URL = `/dbaware-api-gateway/api/v1/actions`;
const LRR_AGENT_BASE_URL = '/scoping-lrrextraction-agent';
const LRR_PROCESS_URL = `${LRR_AGENT_BASE_URL}/lrr/process`;
const LRR_STATUS_URL = `${LRR_AGENT_BASE_URL}/lrr/process`;
const LRR_RUNS_URL = `${LRR_AGENT_BASE_URL}/lrr/runs`;
const EXTRACTION_TERMINAL_SUCCESS = new Set(['complete', 'completed', 'done', 'success', 'succeeded', 'available']);
const EXTRACTION_TERMINAL_FAILURE = new Set(['failed', 'error', 'cancelled', 'canceled']);
const inFlightArtifactRequests = new Map<string, Promise<PlanArtifactResponse<any>>>();

const buildPlanNumber = (planNumber: string | number): string => String(planNumber);

const buildArtifactRequestKey = (planNumber: string | number, artifact: ArtifactType): string => (
    `${buildPlanNumber(planNumber)}:${artifact}`
);

const toRecord = (value: unknown): Record<string, any> | null => (
    value && typeof value === 'object' ? value as Record<string, any> : null
);

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const extractActionPayload = (response: unknown, hints: string[]): Record<string, any> => {
    const preferred = unwrapGatewayEnvelope(response);
    const queue: unknown[] = preferred === response ? [response] : [preferred, response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        const record = toRecord(current);

        if (!record || visited.has(record)) {
            continue;
        }

        visited.add(record);

        if (hints.some(hint => hint in record)) {
            return record;
        }

        if ('payload' in record) queue.push(record.payload);
        if ('data' in record) queue.push(record.data);
        if ('result' in record) queue.push(record.result);
        if ('response' in record) queue.push(record.response);
    }

    return toRecord(response) ?? {};
};

const getStringField = (record: Record<string, any>, keys: string[]): string | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (typeof value === 'string' && value.trim()) {
            return value;
        }
    }

    return undefined;
};

const getBooleanField = (record: Record<string, any>, keys: string[]): boolean | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (typeof value === 'boolean') {
            return value;
        }
        if (typeof value === 'string') {
            const normalized = value.trim().toLowerCase();
            if (normalized === 'true') return true;
            if (normalized === 'false') return false;
        }
    }

    return undefined;
};

const getNumberField = (record: Record<string, any>, keys: string[]): number | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (typeof value === 'number' && Number.isFinite(value)) {
            return value;
        }
        if (typeof value === 'string') {
            const parsed = Number(value);
            if (Number.isFinite(parsed)) {
                return parsed;
            }
        }
    }

    return undefined;
};

const getStringArrayField = (record: Record<string, any>, keys: string[]): string[] | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (Array.isArray(value)) {
            return value
                .map((item) => (typeof item === 'string' ? item.trim() : ''))
                .filter((item) => Boolean(item));
        }
    }

    return undefined;
};

const normalizeStatus = (status?: string): string => (status || 'pending').toLowerCase();

const LRR_TERMINAL_SUCCESS = new Set(['complete', 'completed', 'done', 'success', 'succeeded']);
const LRR_TERMINAL_FAILURE = new Set(['failed', 'error', 'cancelled', 'canceled']);

const buildLrrStatusMessage = (payload: Record<string, any>, status: string): string | undefined => {
    const explicitMessage = getStringField(payload, ['message', 'detail']);
    if (explicitMessage) {
        return explicitMessage;
    }

    const progress = getNumberField(payload, ['progress']);
    const currentStep = getNumberField(payload, ['current_step', 'currentStep']);
    const totalSteps = getNumberField(payload, ['total_steps', 'totalSteps']);

    if (typeof progress === 'number') {
        return `LRR URL processing status: ${status} (${progress}%).`;
    }

    if (typeof currentStep === 'number' && typeof totalSteps === 'number' && totalSteps > 0) {
        return `LRR URL processing status: ${status} (step ${currentStep}/${totalSteps}).`;
    }

    return `LRR URL processing status: ${status}.`;
};

const postDataGatheringAction = async <TResponse, TPayload>(
    planNumber: string | number,
    action: DataGatheringAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: DataGatheringGatewayRequest<TPayload> = {
        planNumber: buildPlanNumber(planNumber),
        action,
        payload,
    };

    return apiClient.post<TResponse>(DG_ACTIONS_URL, request, {
        timeout: 600000,
    });
};

export const triggerDataExtraction = async (
    planNumber: string | number
): Promise<DataExtractionTriggerResponse> => {
    const response = await postDataGatheringAction<unknown, { planNumber: string }>(
        planNumber,
        'DATA_EXTRACTION',
        { planNumber: buildPlanNumber(planNumber) }
    );

    const payload = extractActionPayload(response, ['session_id', 'sessionId', 'status', 'message']);
    const status = getStringField(payload, ['status', 'state']);

    return {
        planNumber: buildPlanNumber(planNumber),
        sessionId: getStringField(payload, ['session_id', 'sessionId', 'extraction_session_id']),
        status,
        message: getStringField(payload, ['message', 'detail']),
        accepted: !status || !EXTRACTION_TERMINAL_FAILURE.has(normalizeStatus(status)),
    };
};

export const getDataExtractionStatus = async (
    planNumber: string | number,
    sessionId: string
): Promise<DataExtractionStatusResponse> => {
    const response = await postDataGatheringAction<unknown, { session_id: string }>(
        planNumber,
        'GET_DATA_EXTRACTION_STATUS',
        { session_id: sessionId }
    );

    const payload = extractActionPayload(response, ['session_id', 'sessionId', 'status', 'state', 'message']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        planNumber: buildPlanNumber(planNumber),
        sessionId: getStringField(payload, ['session_id', 'sessionId', 'extraction_session_id']) || sessionId,
        status,
        message: getStringField(payload, ['message', 'detail']),
        isComplete: EXTRACTION_TERMINAL_SUCCESS.has(status),
        isFailed: EXTRACTION_TERMINAL_FAILURE.has(status),
    };
};

export const getPlanAvailability = async (
    planNumber: string | number
): Promise<PlanAvailabilityResponse> => {
    const response = await postDataGatheringAction<unknown, Record<string, never>>(
        planNumber,
        'GET_PLAN_AVAILABILITY',
        {}
    );

    const payload = extractActionPayload(response, ['available', 'is_available', 'plan_available', 'status', 'session_id', 'sessionId']);
    const status = getStringField(payload, ['status', 'state']);
    const explicitAvailability = getBooleanField(payload, ['available', 'is_available', 'plan_available']);
    const normalizedStatus = normalizeStatus(status);

    return {
        planNumber: buildPlanNumber(planNumber),
        available: explicitAvailability ?? EXTRACTION_TERMINAL_SUCCESS.has(normalizedStatus),
        status,
        sessionId: getStringField(payload, ['session_id', 'sessionId', 'extraction_session_id']),
        message: getStringField(payload, ['message', 'detail']),
    };
};

/**
 * Returns one stored extraction artifact for a given Plan Item Number.
 */
export const getPlanArtifact = async <T = any>(
    planNumber: string | number,
    artifact: ArtifactType
): Promise<PlanArtifactResponse<T>> => {
    const requestKey = buildArtifactRequestKey(planNumber, artifact);
    const existingRequest = inFlightArtifactRequests.get(requestKey);

    if (existingRequest) {
        return existingRequest as Promise<PlanArtifactResponse<T>>;
    }

    const requestPromise = postDataGatheringAction<unknown, { artifact: ArtifactType }>(
        planNumber,
        'GET_PLAN_ARTIFACT',
        { artifact }
    )
        .then((response) => {
            const payload = extractActionPayload(response, ['artifact', 'plan_number', 'data', 'source']);

            return {
                plan_number: payload.plan_number ?? payload.planNumber ?? buildPlanNumber(planNumber),
                artifact: (payload.artifact ?? artifact) as ArtifactType,
                source: payload.source ?? 'gateway',
                data: (payload.data ?? payload) as T,
            };
        })
        .finally(() => {
            inFlightArtifactRequests.delete(requestKey);
        });

    inFlightArtifactRequests.set(requestKey, requestPromise as Promise<PlanArtifactResponse<any>>);

    return requestPromise;
};

export const startLrrProcess = async (
    planNumber: string | number,
    urls: string[],
    goal: string
): Promise<LrrProcessStartResponse> => {
    const response = await apiClient.post<unknown>(
        LRR_PROCESS_URL,
        {
            urls,
            goal,
            request_id: buildPlanNumber(planNumber),
        },
        {
            timeout: 600000,
        }
    );

    const payload = extractActionPayload(response, ['run_id', 'runId', 'request_id', 'status', 'objective', 'seeds', 'pipeline']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        runId: getStringField(payload, ['run_id', 'runId', 'id']) || '',
        requestId: getStringField(payload, ['request_id', 'requestId']),
        status: getStringField(payload, ['status', 'state']),
        objective: getStringField(payload, ['objective', 'goal']),
        seeds: getStringArrayField(payload, ['seeds', 'urls']),
        pipeline: getStringField(payload, ['pipeline']),
        message: buildLrrStatusMessage(payload, status),
    };
};

export const getLrrProcessStatus = async (
    runId: string
): Promise<LrrProcessStatusResponse> => {
    const response = await apiClient.get<unknown>(
        `${LRR_STATUS_URL}/${encodeURIComponent(runId)}/status`,
        {
            timeout: 600000,
        }
    );

    const payload = extractActionPayload(response, ['run_id', 'runId', 'status', 'state', 'message']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        runId: getStringField(payload, ['run_id', 'runId', 'id']) || runId,
        status,
        progress: getNumberField(payload, ['progress']),
        totalSteps: getNumberField(payload, ['total_steps', 'totalSteps']),
        currentStep: getNumberField(payload, ['current_step', 'currentStep']),
        pipeline: getStringField(payload, ['pipeline']),
        message: buildLrrStatusMessage(payload, status),
        isComplete: LRR_TERMINAL_SUCCESS.has(status),
        isFailed: LRR_TERMINAL_FAILURE.has(status),
    };
};

export const getLrrRunDetails = async (
    runId: string
): Promise<LrrRunDetailsResponse> => {
    const response = await apiClient.get<unknown>(
        `${LRR_RUNS_URL}/${encodeURIComponent(runId)}`,
        {
            timeout: 600000,
        }
    );

    const payload = extractActionPayload(response, ['run_id', 'runId', 'status', 'objective', 'error', 'seeds', 'pipeline']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        runId: getStringField(payload, ['run_id', 'runId', 'id']) || runId,
        objective: getStringField(payload, ['objective', 'goal']),
        status,
        step: getNumberField(payload, ['step']),
        durationMs: getNumberField(payload, ['duration_ms', 'durationMs']),
        sources: getNumberField(payload, ['sources']),
        documents: getNumberField(payload, ['documents']),
        accepted: getNumberField(payload, ['accepted']),
        review: getNumberField(payload, ['review']),
        rejected: getNumberField(payload, ['rejected']),
        createdAt: getStringField(payload, ['created_at', 'createdAt']),
        live: getBooleanField(payload, ['live']),
        error: getStringField(payload, ['error']),
        seeds: getStringArrayField(payload, ['seeds', 'urls']),
        pipeline: getStringField(payload, ['pipeline']),
        message: getStringField(payload, ['message', 'detail']) || getStringField(payload, ['error']),
        isComplete: LRR_TERMINAL_SUCCESS.has(status),
        isFailed: LRR_TERMINAL_FAILURE.has(status),
    };
};