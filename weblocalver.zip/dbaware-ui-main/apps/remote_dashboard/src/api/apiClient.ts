import type { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import axios from 'axios';

// --- Token Manager ---
let rctoken: string | null = null;

// Stable key used to persist the token on `window`, so the interceptor can read
// it at request time regardless of which remote registered the client first.
const RC_TOKEN_GLOBAL_KEY = '__dbawareRcToken';

/**
 * Sets the token for the API client. This should be called from the root
 * of your application to keep the token in sync.
 */
export const setApiClientToken = (token: string | null) => {
    rctoken = token;
    if (typeof window !== 'undefined') {
        (window as any)[RC_TOKEN_GLOBAL_KEY] = token;
    }
};
// --- End of Token Manager ---

/**
 * Base URL for all API calls - uses relative path to leverage current origin
 * This automatically uses the same server as the app is deployed on
 */
export const API_BASE_URL = '/';

// Create a base axios instance
const axiosInstance: AxiosInstance = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
    timeout: 600000, // 10 minutes
});

// Add a request interceptor to automatically add the token to every request
axiosInstance.interceptors.request.use(
    (config) => {
        const token = rctoken ?? (typeof window !== 'undefined' ? (window as any)[RC_TOKEN_GLOBAL_KEY] : null);
        if (token) {
            config.headers = config.headers ?? {};
            config.headers['x-asm-rctoken'] = token;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

// --- Hybrid API Client (returns data) ---

// Base function for backward compatibility (e.g., apiClient({ method: 'get', ... }))
const callableApiClient = <T,>(config: AxiosRequestConfig): Promise<T> =>
    axiosInstance.request<T>(config).then((res) => res.data);

// Attach convenience methods (e.g., apiClient.get(...)) and export
export const apiClient = Object.assign(callableApiClient, {
    get: <T>(url: string, config?: AxiosRequestConfig): Promise<T> =>
        axiosInstance.get<T>(url, config).then((res) => res.data),
    post: <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> =>
        axiosInstance.post<T>(url, data, config).then((res) => res.data),
    put: <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> =>
        axiosInstance.put<T>(url, data, config).then((res) => res.data),
    delete: <T>(url: string, config?: AxiosRequestConfig): Promise<T> =>
        axiosInstance.delete<T>(url, config).then((res) => res.data),
});

// --- Hybrid API Client (returns full response) ---

// Base function for backward compatibility
const callableApiClientFullResponse = <T,>(
    config: AxiosRequestConfig
): Promise<AxiosResponse<T>> => axiosInstance.request<T>(config);

// Attach convenience methods and export
export const apiClientFullResponse = Object.assign(callableApiClientFullResponse, {
    get: <T>(
        url: string,
        config?: AxiosRequestConfig
    ): Promise<AxiosResponse<T>> => axiosInstance.get<T>(url, config),
    post: <T>(
        url: string,
        data?: any,
        config?: AxiosRequestConfig
    ): Promise<AxiosResponse<T>> => axiosInstance.post<T>(url, data, config),
    put: <T>(
        url: string,
        data?: any,
        config?: AxiosRequestConfig
    ): Promise<AxiosResponse<T>> => axiosInstance.put<T>(url, data, config), delete: <T>(
        url: string,
        config?: AxiosRequestConfig
    ): Promise<AxiosResponse<T>> => axiosInstance.delete<T>(url, config),
});

// --- Global registration -----------------------------------------------------
// Expose the shared API client on `window.__dbaware` so any federated remote
// can reuse the exact same axios instance (auth interceptor + rctoken) without
// importing across module-federation boundaries.
declare global {
    interface Window {
        __dbaware?: {
            apiClient: typeof apiClient;
            apiClientFullResponse: typeof apiClientFullResponse;
            setApiClientToken: typeof setApiClientToken;
        };
    }
}

if (typeof window !== 'undefined') {
    window.__dbaware = window.__dbaware ?? ({} as NonNullable<Window['__dbaware']>);
    window.__dbaware.apiClient = apiClient;
    window.__dbaware.apiClientFullResponse = apiClientFullResponse;
    window.__dbaware.setApiClientToken = setApiClientToken;
}