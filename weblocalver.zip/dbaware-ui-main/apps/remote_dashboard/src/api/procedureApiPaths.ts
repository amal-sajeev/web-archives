import { API_BASE_URL } from './apiClient';

// Use the resolved API_BASE_URL (empty string on localhost to leverage Vite proxy, or absolute URL in production)
export const PROCEDURE_API_BASE = import.meta.env.VITE_PROCEDURE_BASE_URL || `/scoping-procedure-agent`;

export const PROCEDURE_API_PATHS = {
    actions: `/dbaware-api-gateway/api/v1/actions`,
    download: `/dbaware-api-gateway/api/v1/actions/download`,
    getDiscoveryWalkthrough: `${PROCEDURE_API_BASE}/get-discovery-walkthrough`,
    generateDiscoveryWalkthrough: `${PROCEDURE_API_BASE}/generate-discovery-walkthrough`,
    updateDiscoveryWalkthrough: `${PROCEDURE_API_BASE}/update-discovery-walkthrough`,
    downloadDiscoveryWalkthrough: `${PROCEDURE_API_BASE}/download-discovery-walkthrough`,
    getInscopeOutscope: `${PROCEDURE_API_BASE}/get-inscope-outscope`,
    generateInscopeOutscope: `${PROCEDURE_API_BASE}/generate-inscope-outscope`,
    updateInscopeOutscope: `${PROCEDURE_API_BASE}/update-inscope-outscope`,
    downloadInscopeOutscope: `${PROCEDURE_API_BASE}/download-inscope-outscope`,
    getTestSteps: `${PROCEDURE_API_BASE}/get-test-steps`,
    generateTestSteps: `${PROCEDURE_API_BASE}/generate-test-steps`,
    updateTestSteps: `${PROCEDURE_API_BASE}/update-test-steps`,
    downloadTestSteps: `${PROCEDURE_API_BASE}/download-test-steps`,
};
