import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('./apiClient', () => ({
  apiClient: { get: vi.fn(), post: vi.fn() },
  API_BASE_URL: '',
}));

import { apiClient } from './apiClient';
import { getTaskStatus } from './scopingClient';
import { buildUserDetailsForPlan } from './scopeContext';

describe('scopingClient.getTaskStatus scope context', () => {
  beforeEach(() => {
    window.sessionStorage.clear();
    vi.clearAllMocks();
  });

  it('persists workflow identifiers for the plan and exposes them as userDetails', async () => {
    (apiClient.get as any).mockResolvedValue({
      planNumber: '20440',
      processInstanceId: 'proc-9',
      taskId: 'task-3',
      taskDefinitionKey: 'DATA_GATHERING',
      owner: 'alice@db.com',
      variables: { review_scope_id: 19 },
    });
    await getTaskStatus('20440');
    expect(buildUserDetailsForPlan('20440')).toEqual({
      review_scope_id: '19',
      process_instance_id: 'proc-9',
      task_id: 'task-3',
      review_scope_stage: 'DATA_GATHERING',
      user: 'alice@db.com',
    });
  });

  it('returns undefined when nothing cached', () => {
    expect(buildUserDetailsForPlan('99999')).toBeUndefined();
  });
});
