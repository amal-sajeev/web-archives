import type { DiscoveryWalkthroughData } from "../store/scopingSlice";

/**
 * Represents a single payload item in the generic update-payloads API.
 *
 * Each child component / module (e.g. DecisionLog, FamWorkshop,
 * ExternalThirdPartyCoverage) constructs its own PayloadRequest and passes it
 * up to the parent screen via the `onSavePayload` callback.  The parent owns
 * the outer request structure and the actual API call.
 */
export interface PayloadRequest {
    /** Identifies the module, e.g. "DECISION_LOG", "FAM_WORKSHOP", "EXTERNAL_THIRD_PARTY_COVERAGE" */
    payloadType: string;
    /** Optimistic-concurrency version received from the corresponding GET endpoint */
    version: number | null;
    /** Module-specific data object – typed generically so each component can use its own shape */
    data: unknown;
}

/**
 * Full request body sent to PUT /dbaware-gateway/api/payload/update-payloads.
 *
 * The parent screen (AssignmentPlanning, AuditPlan, etc.) owns this shape.
 * It can either pass a single PayloadRequest for individual saves or an array
 * of PayloadRequests for a bulk save of the whole screen.
 */
export interface UpdatePayloadsBody {
    taskId: string | null;
    /** Workflow task definition key, e.g. "ASSIGNMENT_PLAN" or "AUDIT_PLAN" */
    taskDefKey: string;
    auditId: number;
    payloads: PayloadRequest[];
}

/**
 * Callback signature that child components use to persist their data without
 * owning the API call directly.
 *
 * @param payloadItem - The module-specific payload (type + version + data).
 *                      Also accepts an array for a bulk call from a single component.
 * @param taskId      - The workflow task ID returned by the initial GET for this component.
 */
export type SavePayloadFn = (
    payloadItem: PayloadRequest | PayloadRequest[],
    taskId: string | null
) => Promise<unknown>;

/**
 * Shared shape for the header-level alert banner used across AssignmentPlanning
 * child components (e.g. DecisionLog, ScopingLog, FAMScenarios, TeamMembers,
 * ProcessFlow). Passing `null` clears the currently displayed alert.
 */
export type AlertChange = { type: 'success' | 'error' | 'warning'; message: string } | null;

/**
 * Callback signature used by child components to surface success/warning/error
 * messages to a centralized banner owned by the parent screen, instead of each
 * component rendering its own local inline alert.
 */
export type OnAlertChange = (alert: AlertChange) => void;



export interface GetDiscoveryWalkthroughParams {
    planNumber: string;
}

export interface UpdateDiscoveryWalkthroughPayload extends DiscoveryWalkthroughData {
    planNumber: string;
}

export interface DownloadDiscoveryWalkthroughPayload extends DiscoveryWalkthroughData {
    planNumber: string;
}

export interface GetScopeRecommendationParams {
    planNumber: string;
}

export interface ScopeRecommendationPayload {
    planNumber: string;
    inscope?: string;
    outscope?: string;
    rationale?: string;
    confidence_score?: number;
}

export interface GetTestStepsParams {
    planNumber: string;
}

export interface TestStep {
    [key: string]: string;
}

export interface TestStepEntry {
    test_step: TestStep;
    rationale: string;
    confidence_score: number;
}

export interface GetTestStepsResponse {
    planNumber: string;
    test_steps: TestStepEntry[];
}

export interface UpdateTestStepsPayload {
    planNumber: string;
    test_steps: TestStepEntry[];
}

export interface DownloadTestStepsPayload {
    planNumber: string;
    test_steps: TestStepEntry[];
}
export interface NoirAiEditPayload {
    plan_item_number: string;
    user_instruction: string;
}

export interface NoirEditPayload {
    plan_item_number: string;
    subject?: string;
    body?: string;
    noir: {
        subject: string;
        body: string;
    };
}

export interface NoirSendPayload {
    plan_item_number: string;
    subject: string;
    body: string;
    to_recipients: string[];
    from_address: string;
}
export interface PreliminaryResearchParagraph {
    paragraph_id: string;
    content: string;
    supporting_chunk_ids: string[];
    rationale: string;
    metadata: {
        is_section_start: boolean;
        section_confidence_score: number;
    };
}

export interface PreliminaryResearchReport {
    [key: string]: {
        report_title: string;
        paragraphs: PreliminaryResearchParagraph[];
    };
}

export interface PreliminaryResearchResponse {
    plan_number: string;
    analysis_report: PreliminaryResearchReport;
}

export interface DownloadPreliminaryResearchPayload {
    plan_number: string;
    analysis_report: PreliminaryResearchReport;
}

export interface DataExtractionTriggerResponse {
    planNumber: string;
    sessionId?: string;
    status?: string;
    message?: string;
    accepted: boolean;
}

export interface DataExtractionStatusResponse {
    planNumber: string;
    sessionId?: string;
    status: string;
    message?: string;
    isComplete: boolean;
    isFailed: boolean;
}

export interface PlanAvailabilityResponse {
    planNumber: string;
    available: boolean;
    status?: string;
    sessionId?: string;
    message?: string;
}

export interface NorEditPayload {
    plan_item_number: string;
    subject?: string;
    body?: string;
    nor: {
        subject: string;
        body: string;
    };
}

export interface NorSendPayload {
    plan_item_number: string;
    email_content: string;
    subject: string;
    body: string;
    to_recipients: string[];
    from_address: string;
}

export type ArtifactType = 'current_details' | 'lrr' | 'historical_plan_details' | 'policy' | 'alc_nlac' | 'findings_details' | 'control_details';

export interface PlanArtifactResponse<T = any> {
    plan_number: string;
    artifact: ArtifactType;
    source: string;
    data: T;
}

export interface LrrProcessStartResponse {
    runId: string;
    requestId?: string;
    status?: string;
    objective?: string;
    seeds?: string[];
    pipeline?: string;
    message?: string;
}

export interface LrrProcessStatusResponse {
    runId: string;
    status: string;
    progress?: number;
    totalSteps?: number;
    currentStep?: number;
    pipeline?: string;
    message?: string;
    isComplete: boolean;
    isFailed: boolean;
}

export interface LrrRunDetailsResponse {
    runId: string;
    objective?: string;
    status: string;
    step?: number;
    durationMs?: number;
    sources?: number;
    documents?: number;
    accepted?: number;
    review?: number;
    rejected?: number;
    createdAt?: string;
    live?: boolean;
    error?: string;
    seeds?: string[];
    pipeline?: string;
    message?: string;
    isComplete: boolean;
    isFailed: boolean;
}
