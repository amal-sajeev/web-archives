import { API_BASE_URL } from './apiClient';

export const SCOPING_AGENT_API_PATHS = {
    gatewayActions: `/dbaware-api-gateway/api/v1/actions`,
};

export const summaryBaseURL = `/scoping-summary-agent`;

export const PRELIMINARY_RESEARCH_API_PATHS = {
    gatewayActions: `/dbaware-api-gateway/api/v1/actions`,
    download: `/dbaware-api-gateway/api/v1/actions/download`,
};
