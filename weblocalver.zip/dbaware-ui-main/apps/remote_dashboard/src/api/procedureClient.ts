import { apiClient } from './apiClient';
import { PROCEDURE_API_PATHS } from './procedureApiPaths';
import type { DiscoveryWalkthroughData, ScopeRecommendationData, ScopeRecommendationSection } from '../store/scopingSlice';
import {
    GetDiscoveryWalkthroughParams,
    UpdateDiscoveryWalkthroughPayload,
    DownloadDiscoveryWalkthroughPayload,
    GetScopeRecommendationParams,
    ScopeRecommendationPayload,
    GetTestStepsParams,
    GetTestStepsResponse,
    UpdateTestStepsPayload,
    DownloadTestStepsPayload
} from './type';

type ProcedureAction =
    | 'GENERATE_DISCOVERY_WALKTHROUGH'
    | 'GET_DISCOVERY_WALKTHROUGH'
    | 'UPDATE_DISCOVERY_WALKTHROUGH'
    | 'ACCEPT_DISCOVERY_WALKTHROUGH'
    | 'DOWNLOAD_DISCOVERY_WALKTHROUGH'
    | 'GENERATE_INSCOPE_OUTSCOPE'
    | 'GET_INSCOPE_OUTSCOPE'
    | 'UPDATE_INSCOPE_OUTSCOPE'
    | 'ACCEPT_INSCOPE_OUTSCOPE'
    | 'SR_RH_APPROVE'
    | 'SR_RH_REJECT'
    | 'REJECT_INSCOPE_OUTSCOPE'
    | 'DOWNLOAD_INSCOPE_OUTSCOPE'
    | 'GENERATE_TEST_STEPS'
    | 'GET_TEST_STEPS'
    | 'UPDATE_TEST_STEPS'
    | 'ACCEPT_TEST_STEPS'
    | 'TS_RH_APPROVE'
    | 'TS_RH_REJECT'
    | 'TS_GH_FWD'
    | 'TS_GH_APPROVE'
    | 'TS_GH_REJECT'
    | 'ACCEPT_FINAL_SCOPING_DOCUMENT'
    | 'SD_RH_APPROVE'
    | 'SD_RH_REJECT'
    | 'SD_GH_FWD'
    | 'SD_GH_APPROVE'
    | 'SD_GH_REJECT'
    | 'GENERATE_SCOPING_DOCUMENT'
    | 'GET_SCOPING_DOCUMENT'
    | 'UPDATE_SCOPING_DOCUMENT'
    | 'DOWNLOAD_SCOPING_DOCUMENT'
    | 'DOWNLOAD_TEST_STEPS';

interface ProcedureGatewayRequest<TPayload> {
    planNumber: string;
    action: ProcedureAction;
    payload: TPayload;
}

const toRecord = (value: unknown): Record<string, any> | null => (
    value && typeof value === 'object' ? value as Record<string, any> : null
);

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const extractActionPayload = (response: unknown, hints: string[]): Record<string, any> => {
    const preferred = unwrapGatewayEnvelope(response);
    const queue: unknown[] = preferred === response ? [response] : [preferred, response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        const record = toRecord(current);

        if (!record || visited.has(record)) {
            continue;
        }

        visited.add(record);

        if (hints.some(hint => hint in record)) {
            return record;
        }

        if ('payload' in record) queue.push(record.payload);
        if ('data' in record) queue.push(record.data);
        if ('result' in record) queue.push(record.result);
        if ('response' in record) queue.push(record.response);
    }

    return toRecord(response) ?? {};
};

const normalizeScopeRecommendationSection = (value: unknown): string | ScopeRecommendationSection => {
    if (typeof value === 'string') {
        return value;
    }

    const record = toRecord(value);
    if (!record) {
        return '';
    }

    const report = typeof record.report === 'string'
        ? record.report
        : typeof record.content === 'string'
            ? record.content
            : '';

    const rationale = typeof record.rationale === 'string' ? record.rationale : undefined;
    const confidenceScore = typeof record.confidence_score === 'number'
        ? record.confidence_score
        : typeof record.confidenceScore === 'number'
            ? record.confidenceScore
            : undefined;

    return {
        report,
        rationale,
        confidence_score: confidenceScore,
    };
};

const normalizeDiscoveryWalkthroughData = (
    response: unknown
): DiscoveryWalkthroughData => {
    const payload = extractActionPayload(response, ['report_title', 'sections']);
    const nestedData = toRecord(payload.data);

    if (nestedData && ('report_title' in nestedData || 'sections' in nestedData)) {
        return nestedData as DiscoveryWalkthroughData;
    }

    return payload as DiscoveryWalkthroughData;
};

const normalizeScopeRecommendationData = (
    response: unknown
): ScopeRecommendationData => {
    const payload = extractActionPayload(response, ['inscope', 'outscope']);
    const nestedData = toRecord(payload.data);
    const source = nestedData && ('inscope' in nestedData || 'outscope' in nestedData)
        ? nestedData
        : payload;

    return {
        planNumber: String(
            source.planNumber ??
            source.plan_number ??
            payload.planNumber ??
            payload.plan_number ??
            ''
        ),
        inscope: normalizeScopeRecommendationSection(source.inscope ?? payload.inscope),
        outscope: normalizeScopeRecommendationSection(source.outscope ?? payload.outscope),
        report_title: typeof source.report_title === 'string' ? source.report_title : undefined,
        aiRationale: typeof source.aiRationale === 'string' ? source.aiRationale : undefined,
        rationale: typeof source.rationale === 'string' ? source.rationale : undefined,
        confidence_score: typeof source.confidence_score === 'number' ? source.confidence_score : undefined,
    };
};

const normalizeTestStepsData = (
    response: unknown
): GetTestStepsResponse => {
    const payload = extractActionPayload(response, ['test_steps', 'planNumber', 'plan_number']);
    const nestedData = toRecord(payload.data);

    if (nestedData && ('test_steps' in nestedData || 'planNumber' in nestedData || 'plan_number' in nestedData)) {
        return nestedData as GetTestStepsResponse;
    }

    return payload as GetTestStepsResponse;
};

const postProcedureAction = async <TResponse, TPayload>(
    planNumber: string,
    action: ProcedureAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: ProcedureGatewayRequest<TPayload> = {
        planNumber,
        action,
        payload,
    };

    return apiClient.post<TResponse>(PROCEDURE_API_PATHS.actions, request, {
        timeout: 600000,
    });
};

export const getDiscoveryWalkthrough = async ({
    planNumber
}: GetDiscoveryWalkthroughParams): Promise<DiscoveryWalkthroughData> => {
    const response = await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GET_DISCOVERY_WALKTHROUGH',
        {}
    );

    return normalizeDiscoveryWalkthroughData(response);
};

export const generateDiscoveryWalkthrough = async ({
    planNumber
}: GetDiscoveryWalkthroughParams): Promise<unknown> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GENERATE_DISCOVERY_WALKTHROUGH',
        {}
    );

    const response = await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GET_DISCOVERY_WALKTHROUGH',
        {}
    );

    return normalizeDiscoveryWalkthroughData(response);
};

export const updateDiscoveryWalkthrough = async <TResponse = unknown>(body: UpdateDiscoveryWalkthroughPayload): Promise<TResponse> => {
    const { planNumber, ...payload } = body;

    return postProcedureAction<TResponse, typeof payload>(
        planNumber,
        'UPDATE_DISCOVERY_WALKTHROUGH',
        payload
    );
};

export const acceptDiscoveryWalkthrough = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'ACCEPT_DISCOVERY_WALKTHROUGH',
        {}
    );
};

export const downloadTestSteps = async (body: DownloadTestStepsPayload): Promise<Blob> => {
    const { planNumber, ...payload } = body;

    return apiClient.post<Blob>(
        PROCEDURE_API_PATHS.download,
        {
            planNumber,
            action: 'DOWNLOAD_TEST_STEPS',
            payload: {
                planNumber,
                ...payload
            },
        } as ProcedureGatewayRequest<any>,
        { responseType: 'blob' }
    );
};

export const downloadDiscoveryWalkthrough = async (body: DownloadDiscoveryWalkthroughPayload): Promise<Blob> => {
    const { planNumber, ...payload } = body;

    return apiClient.post<Blob>(
        PROCEDURE_API_PATHS.download,
        {
            planNumber,
            action: 'DOWNLOAD_DISCOVERY_WALKTHROUGH',
            payload: {
                planNumber,
                ...payload
            },
        } as ProcedureGatewayRequest<any>,
        { responseType: 'blob' }
    );
};

export const getScopeRecommendation = async ({
    planNumber
}: GetScopeRecommendationParams): Promise<ScopeRecommendationData> => {
    const response = await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GET_INSCOPE_OUTSCOPE',
        {}
    );

    return normalizeScopeRecommendationData(response);
};

export const generateScopeRecommendation = async <TResponse = unknown>(body: ScopeRecommendationPayload): Promise<TResponse> => {
    const { planNumber, ...payload } = body;

    await postProcedureAction<unknown, typeof payload>(
        planNumber,
        'GENERATE_INSCOPE_OUTSCOPE',
        payload
    );

    const response = await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GET_INSCOPE_OUTSCOPE',
        {}
    );

    return normalizeScopeRecommendationData(response) as any;
};

export const updateInscopeOutscope = async <TResponse = unknown>(body: ScopeRecommendationPayload): Promise<TResponse> => {
    const { planNumber, inscope, outscope, rationale, confidence_score } = body;

    const request: ProcedureGatewayRequest<any> = {
        planNumber,
        action: 'UPDATE_INSCOPE_OUTSCOPE',
        payload: {
            planNumber,
            inscope: typeof inscope === 'string' ? { report: inscope } : inscope,
            outscope: typeof outscope === 'string' ? { report: outscope } : outscope,
            ...(rationale && { rationale }),
            ...(confidence_score !== undefined && { confidence_score })
        }
    };

    return apiClient.post<TResponse>(PROCEDURE_API_PATHS.actions, request, {
        timeout: 600000,
    });
};

export const acceptInscopeOutscope = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'ACCEPT_INSCOPE_OUTSCOPE',
        {}
    );
};

export const rejectInscopeOutscope = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'REJECT_INSCOPE_OUTSCOPE',
        {}
    );
};

export const rejectScopeRecommendationByRoleAction = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'SR_RH_REJECT',
        {}
    );
};

export const approveScopeRecommendationByRoleAction = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'SR_RH_APPROVE',
        {}
    );
};

export const downloadInscopeOutscope = async (body: ScopeRecommendationPayload): Promise<Blob> => {
    const { planNumber, inscope, outscope, rationale, confidence_score } = body;

    return apiClient.post<Blob>(
        PROCEDURE_API_PATHS.download,
        {
            planNumber,
            action: 'DOWNLOAD_INSCOPE_OUTSCOPE',
            payload: {
                planNumber,
                inscope: typeof inscope === 'string' ? { report: inscope } : inscope,
                outscope: typeof outscope === 'string' ? { report: outscope } : outscope,
                ...(rationale && { rationale }),
                ...(confidence_score !== undefined && { confidence_score })
            },
        } as ProcedureGatewayRequest<any>,
        { responseType: 'blob' }
    );
};

export const getTestSteps = async ({
    planNumber
}: GetTestStepsParams): Promise<GetTestStepsResponse> => {
    const response = await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GET_TEST_STEPS',
        {}
    );

    return normalizeTestStepsData(response);
};

export const generateTestSteps = async ({
    planNumber,
    useGetAfterGenerate = true,
}: { planNumber: string; useGetAfterGenerate?: boolean }): Promise<unknown> => {
    const generateResponse = await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GENERATE_TEST_STEPS',
        {}
    );

    if (!useGetAfterGenerate) {
        return normalizeTestStepsData(generateResponse);
    }

    const response = await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'GET_TEST_STEPS',
        {}
    );

    return normalizeTestStepsData(response);
};

export const updateTestSteps = async <TResponse = unknown>(body: UpdateTestStepsPayload): Promise<TResponse> => {
    const { planNumber, ...payload } = body;

    const request: ProcedureGatewayRequest<any> = {
        planNumber,
        action: 'UPDATE_TEST_STEPS',
        payload: {
            planNumber,
            ...payload
        }
    };

    return apiClient.post<TResponse>(PROCEDURE_API_PATHS.actions, request, {
        timeout: 600000,
    });
};

export const acceptTestSteps = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'ACCEPT_TEST_STEPS',
        {}
    );
};

export const approveTestStepsAsRh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'TS_RH_APPROVE',
        {}
    );
};

export const rejectTestStepsAsRh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'TS_RH_REJECT',
        {}
    );
};

export const forwardTestStepsToGh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'TS_GH_FWD',
        {}
    );
};

export const approveTestStepsAsGh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'TS_GH_APPROVE',
        {}
    );
};

export const rejectTestStepsAsGh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'TS_GH_REJECT',
        {}
    );
};

export const approveScopingDocumentAsRh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'SD_RH_APPROVE',
        {}
    );
};

export const rejectScopingDocumentAsRh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'SD_RH_REJECT',
        {}
    );
};

export const forwardScopingDocumentToGh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'SD_GH_FWD',
        {}
    );
};

export const approveScopingDocumentAsGh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'SD_GH_APPROVE',
        {}
    );
};

export const rejectScopingDocumentAsGh = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'SD_GH_REJECT',
        {}
    );
};

const postProcedureDownload = async (
    planNumber: string,
    action: ProcedureAction,
    payload: Record<string, unknown> = {}
): Promise<Blob> => {
    const response = await apiClient.post<Blob>(
        PROCEDURE_API_PATHS.download,
        {
            planNumber,
            action,
            payload: { planNumber, ...payload },
        } as ProcedureGatewayRequest<any>,
        { responseType: 'blob' }
    );

    return new Blob([(response as any).data || response]);
};

export const getScopingDocumentEditorHtml = async (planNumber: string): Promise<string> => {
    // GET is served through the download endpoint (dbaware-api-gateway/api/v1/actions/download).
    const blob = await postProcedureDownload(planNumber, 'GET_SCOPING_DOCUMENT');
    return blob.text();
};

export const generateScopingDocument = async (planNumber: string): Promise<string> => {
    // GENERATE is served through the download endpoint and returns the editor HTML directly.
    const blob = await postProcedureDownload(planNumber, 'GENERATE_SCOPING_DOCUMENT');
    return blob.text();
};

export const updateScopingDocument = async (
    planNumber: string,
    document: Record<string, unknown>
): Promise<Record<string, unknown>> => {
    const response = await postProcedureAction<unknown, { document: Record<string, unknown> }>(
        planNumber,
        'UPDATE_SCOPING_DOCUMENT',
        { document }
    );
    const saved = toRecord(extractActionPayload(response, ['document']).document);

    return saved ?? document;
};

export const downloadScopingDocument = async (planNumber: string): Promise<Blob> => {
    const blob = await postProcedureDownload(planNumber, 'DOWNLOAD_SCOPING_DOCUMENT');
    return new Blob([blob], { type: 'application/pdf' });
};

export const acceptFinalScopingDocument = async (planNumber: string): Promise<void> => {
    await postProcedureAction<unknown, Record<string, never>>(
        planNumber,
        'ACCEPT_FINAL_SCOPING_DOCUMENT',
        {}
    );
};