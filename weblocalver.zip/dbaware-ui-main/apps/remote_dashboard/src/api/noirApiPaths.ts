import { API_BASE_URL } from './apiClient';

// Use the resolved API_BASE_URL (empty string on localhost to leverage Vite proxy, or absolute URL in production)
export const NOIR_API_BASE = import.meta.env.VITE_NOIR_BASE_URL || `/dbaware-api-gateway`;

export const NOIR_API_PATHS = {
    actions: `${NOIR_API_BASE}/api/v1/actions`,
};
