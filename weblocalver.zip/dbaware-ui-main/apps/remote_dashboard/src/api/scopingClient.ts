
import { apiClient } from './apiClient';
import { SCOPING_AGENT_API_PATHS } from './scopingApiPaths';
import { API_BASE_URL } from './apiClient';
import { PRELIMINARY_RESEARCH_API_PATHS } from './scopingApiPaths';
import { buildScopeContextFromTaskStatus, buildUserDetailsForPlan, saveScopingContext } from './scopeContext';
import type { DownloadPreliminaryResearchPayload, PreliminaryResearchResponse } from './type';

interface PlanStatusWorkflowAction {
    action?: string;
    sub_action?: string | null;
}

type ScopingAction = 'START_SCOPING';

interface StartScopingPayload {
    noir_required: boolean;
}

interface ScopingGatewayRequest<TPayload> {
    planNumber: string;
    action: ScopingAction;
    payload: TPayload;
}

export interface TaskStatusResponse {
    planNumber?: string;
    hasActiveTask?: boolean;
    taskId?: string;
    taskDefinitionKey?: string;
    status?: string;
    owner?: string;
    processInstanceId?: string;
    processName?: string;
    variables?: {
        p_NEXT_AVAILABLE_ACTIONS?: string;
        [key: string]: unknown;
    };
    nextAvailableWorkflowActions?: Array<PlanStatusWorkflowAction | string>;
}

const PRELIMINARY_RESEARCH_TIMEOUT_MS = 10 * 60 * 1000;
const PRELIMINARY_RESEARCH_POLL_INTERVAL_MS = 20 * 1000;
const PRELIMINARY_RESEARCH_MAX_POLL_MS = 12 * 60 * 1000;

type PreliminaryResearchAction =
    | 'RUN_ANALYTICS'
    | 'GET_PRELIMINARY_RESEARCH_DOCUMENT'
    | 'EDIT_PRELIMINARY_RESEARCH_DOCUMENT'
    | 'ACCEPT_PRELIMINARY_RESEARCH'
    | 'DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT';

interface PreliminaryResearchGatewayRequest<TPayload> {
    planNumber: string;
    action: PreliminaryResearchAction;
    payload: TPayload;
}

const toRecord = (value: unknown): Record<string, any> | null => (
    value && typeof value === 'object' ? value as Record<string, any> : null
);

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const extractActionPayload = (response: unknown, hints: string[]): Record<string, any> => {
    const preferred = unwrapGatewayEnvelope(response);
    const queue: unknown[] = preferred === response ? [response] : [preferred, response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        const record = toRecord(current);

        if (!record || visited.has(record)) {
            continue;
        }

        visited.add(record);

        if (hints.some(hint => hint in record)) {
            return record;
        }

        if ('payload' in record) queue.push(record.payload);
        if ('data' in record) queue.push(record.data);
        if ('result' in record) queue.push(record.result);
        if ('response' in record) queue.push(record.response);
    }

    return toRecord(response) ?? {};
};

const normalizePreliminaryResearchResponse = (
    planNumber: string,
    raw: unknown
): PreliminaryResearchResponse => {
    if (!raw) {
        throw new Error('Invalid response: received null or undefined');
    }

    const record = extractActionPayload(raw, ['plan_number', 'analysis_report']);

    if (!record || typeof record !== 'object') {
        throw new Error('Invalid response format: could not extract payload');
    }

    // Variant A: { plan_number, analysis_report }
    if (record.plan_number && record.analysis_report) {
        return {
            plan_number: String(record.plan_number),
            analysis_report: record.analysis_report,
        };
    }

    // Variant B: { analysis_report: { plan_number, analysis_report } }
    const nested = toRecord(record.analysis_report);
    if (nested && nested.plan_number && nested.analysis_report) {
        return {
            plan_number: String(nested.plan_number),
            analysis_report: nested.analysis_report,
        };
    }

    // Variant C: payload is just the analysis_report object map
    return {
        plan_number: planNumber,
        analysis_report: (record.analysis_report ?? record) as PreliminaryResearchResponse['analysis_report'],
    };
};

const postPreliminaryResearchAction = async <TResponse, TPayload>(
    planNumber: string,
    action: PreliminaryResearchAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: PreliminaryResearchGatewayRequest<TPayload> = {
        planNumber,
        action,
        payload,
    };

    try {
        return await apiClient.post<TResponse>(SCOPING_AGENT_API_PATHS.gatewayActions, request, {
            timeout: PRELIMINARY_RESEARCH_TIMEOUT_MS,
        });
    } catch (error) {
        if (error instanceof Error) {
            throw new Error(`Failed to ${action}: ${error.message}`);
        }
        throw error;
    }
};

const postPreliminaryResearchDownload = async <TPayload>(
    planNumber: string,
    payload: TPayload
): Promise<Blob> => {
    const request: PreliminaryResearchGatewayRequest<TPayload> = {
        planNumber,
        action: 'DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT',
        payload,
    };

    return apiClient.post<Blob>(PRELIMINARY_RESEARCH_API_PATHS.download, request, {
        responseType: 'blob',
        timeout: PRELIMINARY_RESEARCH_TIMEOUT_MS,
    });
};

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const hasAnalysisContent = (response: PreliminaryResearchResponse): boolean => {
    if (!response?.analysis_report || typeof response.analysis_report !== 'object') return false;

    const tabs = Object.values(response.analysis_report || {});
    if (tabs.length === 0) return false;

    return tabs.some((tab: any) => {
        if (Array.isArray(tab?.paragraphs) && tab.paragraphs.length > 0) return true;
        if (Array.isArray(tab?.historical_reviews) && tab.historical_reviews.length > 0) return true;
        return false;
    });
};

/**
 * Runs preliminary research generation and fetches the latest generated document.
 *
 * @param planItemNumber - Plan Item Number to generate the research for (e.g. 20593).
 */
export const generatePreliminaryResearch = async (
    planItemNumber: number | string,
    runAnalyticsPayload: Record<string, unknown> = {}
): Promise<PreliminaryResearchResponse> => {
    const planNumber = planItemNumber.toString();
    let runAnalyticsError: unknown = null;

    const userDetails = buildUserDetailsForPlan(planNumber);
    const analyticsPayload = userDetails
        ? { ...runAnalyticsPayload, userDetails }
        : runAnalyticsPayload;

    try {
        await postPreliminaryResearchAction<unknown, Record<string, unknown>>(
            planNumber,
            'RUN_ANALYTICS',
            analyticsPayload
        );
    } catch (error) {
        // Some environments terminate long HTTP requests around ~4 minutes
        // while the backend job continues. Keep polling GET endpoint below.
        runAnalyticsError = error;
        console.warn('RUN_ANALYTICS request failed; falling back to polling GET_PRELIMINARY_RESEARCH_DOCUMENT.', error);
    }

    const startedAt = Date.now();
    let lastGetError: unknown = null;

    while (Date.now() - startedAt <= PRELIMINARY_RESEARCH_MAX_POLL_MS) {
        try {
            const response = await postPreliminaryResearchAction<unknown, Record<string, never>>(
                planNumber,
                'GET_PRELIMINARY_RESEARCH_DOCUMENT',
                {}
            );

            const normalized = normalizePreliminaryResearchResponse(planNumber, response);
            if (hasAnalysisContent(normalized)) {
                return normalized;
            }
        } catch (error) {
            lastGetError = error;
        }

        await wait(PRELIMINARY_RESEARCH_POLL_INTERVAL_MS);
    }

    const runErrMessage = runAnalyticsError instanceof Error ? runAnalyticsError.message : '';
    const getErrMessage = lastGetError instanceof Error ? lastGetError.message : '';
    const details = [runErrMessage, getErrMessage].filter(Boolean).join(' | ');
    throw new Error(
        details
            ? `Preliminary research generation timed out while polling result. ${details}`
            : 'Preliminary research generation timed out while polling result.'
    );
};

/**
 * Fetches an existing preliminary research document via gateway action.
 */
export const getPreliminaryResearchDocument = async (
    planItemNumber: number | string
): Promise<PreliminaryResearchResponse> => {
    const planNumber = planItemNumber.toString();

    const response = await postPreliminaryResearchAction<unknown, Record<string, never>>(
        planNumber,
        'GET_PRELIMINARY_RESEARCH_DOCUMENT',
        {}
    );

    return normalizePreliminaryResearchResponse(planNumber, response);
};

/**
 * Persists edited preliminary research document via gateway action.
 *
 * @param body - Payload containing the plan number and analysis report paragraphs.
 */
export const editPreliminaryResearchDocument = async (
    planItemNumber: number | string,
    body: PreliminaryResearchResponse
): Promise<PreliminaryResearchResponse> => {
    const planNumber = planItemNumber.toString();

    const response = await postPreliminaryResearchAction<unknown, Record<string, any>>(
        planNumber,
        'EDIT_PRELIMINARY_RESEARCH_DOCUMENT',
        {
            analysis_report: body.analysis_report,
        }
    );

    return normalizePreliminaryResearchResponse(planNumber, response);
};

/**
 * Accepts the preliminary research result via HITL gateway action.
 */
export const acceptPreliminaryResearch = async (
    planItemNumber: number | string
): Promise<void> => {
    const planNumber = planItemNumber.toString();

    await postPreliminaryResearchAction<unknown, Record<string, never>>(
        planNumber,
        'ACCEPT_PRELIMINARY_RESEARCH',
        {}
    );
};

export const downloadPreliminaryResearchDocument = async (
    planItemNumber: number | string,
    body: DownloadPreliminaryResearchPayload
): Promise<Blob> => {
    const planNumber = planItemNumber.toString();
    return postPreliminaryResearchDownload(planNumber, body);
};

export const getTaskStatus = async (planItemNumber: number | string): Promise<TaskStatusResponse> => {
    const planNumber = String(planItemNumber);
    const response = await apiClient.get<TaskStatusResponse>(`/dbaware-api-gateway/api/v1/task/status/${planNumber}`);
    if (response && typeof response === 'object') {
        const resolvedPlan = String(response.planNumber ?? planNumber);
        const context = buildScopeContextFromTaskStatus(resolvedPlan, response);
        saveScopingContext(resolvedPlan, context);
    }
    return response;
};

export const startScoping = async (planItemNumber: number | string, noirRequired = true): Promise<unknown> => {
    const planNumber = String(planItemNumber);
    const request: ScopingGatewayRequest<StartScopingPayload> = {
        planNumber,
        action: 'START_SCOPING',
        payload: {
            noir_required: noirRequired,
        },
    };

    return apiClient.post<unknown>(SCOPING_AGENT_API_PATHS.gatewayActions, request);
};

export const getNextAvailableActionsFromTaskStatus = (taskStatus?: TaskStatusResponse): string[] => {
    if (!taskStatus) return [];

    const fromVariables = taskStatus.variables?.p_NEXT_AVAILABLE_ACTIONS;
    if (typeof fromVariables === 'string' && fromVariables.trim().length > 0) {
        return fromVariables
            .split(',')
            .map((item) => item.trim())
            .filter(Boolean);
    }

    const fromWorkflowActions = taskStatus.nextAvailableWorkflowActions;
    if (!Array.isArray(fromWorkflowActions)) return [];

    return fromWorkflowActions
        .map((item) => {
            if (typeof item === 'string') return item.trim();
            if (item && typeof item === 'object' && typeof item.action === 'string') return item.action.trim();
            return '';
        })
        .filter(Boolean);
};
