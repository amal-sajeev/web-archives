import { apiClient, apiClientFullResponse } from './apiClient';
import { NOIR_API_PATHS } from './noirApiPaths';
import type { NoirData } from '../store/scopingSlice';
import type { NoirAiEditPayload, NoirEditPayload, NoirSendPayload } from './type';
import type { AxiosResponseHeaders, RawAxiosResponseHeaders } from 'axios';

type NoirAction = 'GET_NOIR' | 'GENERATE_NOIR' | 'EDIT_NOIR' | 'HUMAN_EDIT' | 'SEND_NOIR_EMAIL';

interface NoirGatewayRequest<TPayload> {
    planNumber: string;
    action: NoirAction;
    payload: TPayload;
}

const buildPlanNumber = (planNumber: number | string): string => String(planNumber);

const serializeHumanEditPayload = (payload: NoirEditPayload): NoirEditPayload => ({
    ...payload,
    subject: payload.subject ?? payload.noir.subject,
    body: payload.body ?? payload.noir.body,
});

const extractNoirPayload = (response: unknown): Record<string, any> => {
    const queue: unknown[] = [response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();

        if (!current || typeof current !== 'object' || visited.has(current)) {
            continue;
        }

        visited.add(current);

        const candidate = current as Record<string, any>;
        const nestedNoir = candidate.noir && typeof candidate.noir === 'object'
            ? {
                ...candidate.noir,
                original_data: candidate.original_data ?? candidate.updated_data ?? candidate.noir.original_data,
            }
            : null;

        if (
            nestedNoir ||
            'subject' in candidate ||
            'body' in candidate ||
            'email' in candidate ||
            'email_content' in candidate ||
            'recipients' in candidate ||
            'original_data' in candidate ||
            'updated_data' in candidate
        ) {
            return nestedNoir ?? candidate;
        }

        if ('payload' in candidate) queue.push(candidate.payload);
        if ('data' in candidate) queue.push(candidate.data);
        if ('result' in candidate) queue.push(candidate.result);
        if ('response' in candidate) queue.push(candidate.response);
    }

    return (response ?? {}) as Record<string, any>;
};

const normalizeNoirData = (response: unknown): NoirData => {
    if (!response) {
        throw new Error('Invalid response: received null or undefined');
    }

    const payload = extractNoirPayload(response);

    if (!payload || typeof payload !== 'object') {
        throw new Error('Invalid response format: could not extract payload');
    }

    return {
        subject: payload.subject ?? '',
        body: payload.body ?? '',
        email: payload.email_content ?? payload.email ?? '',
        recipients: Array.isArray(payload.recipients) ? payload.recipients : [],
        original_data: payload.original_data ?? payload.updated_data ?? null,
    };
};

interface PlanStatusWorkflowAction {
    action?: string;
    sub_action?: string | null;
}

interface PlanStatusHeaderPayload {
    taskDefinitionKey?: string;
    variables?: {
        p_NEXT_AVAILABLE_ACTIONS?: string;
        [key: string]: unknown;
    };
    nextAvailableWorkflowActions?: PlanStatusWorkflowAction[];
}

const parseNextAvailableActionsFromHeader = (headerValue?: string): string[] => {
    if (!headerValue) return [];

    try {
        const parsed = JSON.parse(headerValue) as PlanStatusHeaderPayload;
        const fromVariables = parsed.variables?.p_NEXT_AVAILABLE_ACTIONS;

        if (typeof fromVariables === 'string' && fromVariables.trim().length > 0) {
            return fromVariables
                .split(',')
                .map((action) => action.trim())
                .filter(Boolean);
        }

        if (Array.isArray(parsed.nextAvailableWorkflowActions)) {
            return parsed.nextAvailableWorkflowActions
                .map((item) => (typeof item.action === 'string' ? item.action.trim() : ''))
                .filter(Boolean);
        }
    } catch (error) {
        console.warn('Unable to parse x-plan-status header', error);
    }

    return [];
};

const parseTaskDefinitionKeyFromHeader = (headerValue?: string): string | undefined => {
    if (!headerValue) return undefined;

    try {
        const parsed = JSON.parse(headerValue) as PlanStatusHeaderPayload;
        if (typeof parsed.taskDefinitionKey === 'string' && parsed.taskDefinitionKey.trim().length > 0) {
            return parsed.taskDefinitionKey.trim();
        }
    } catch (error) {
        console.warn('Unable to parse taskDefinitionKey from x-plan-status header', error);
    }

    return undefined;
};

const getXPlanStatusHeaderValue = (
    headers: RawAxiosResponseHeaders | AxiosResponseHeaders | undefined
): string | undefined => {
    if (!headers) return undefined;

    const map = headers as Record<string, unknown>;
    const raw = map['x-plan-status'] ?? map['X-Plan-Status'];

    if (typeof raw === 'string') return raw;
    if (Array.isArray(raw) && typeof raw[0] === 'string') return raw[0];

    return undefined;
};

const postNoirAction = async <TResponse, TPayload>(
    planNumber: number | string,
    action: NoirAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: NoirGatewayRequest<TPayload> = {
        planNumber: buildPlanNumber(planNumber),
        action,
        payload,
    };

    try {
        return await apiClient.post<TResponse>(NOIR_API_PATHS.actions, request, {
            timeout: 600000,
        });
    } catch (error) {
        if (error instanceof Error) {
            throw new Error(`Failed to ${action}: ${error.message}`);
        }
        throw error;
    }
};

export const getNoir = async (planNumber: number | string): Promise<NoirData> => {
    const response = await postNoirAction<unknown, Record<string, never>>(planNumber, 'GET_NOIR', {});
    return normalizeNoirData(response);
};

/**
 * Calls the NOIR gateway action endpoint to generate a NOIR document.
 *
 * @param planItemNumber - Plan Item Number to generate the NOIR for (e.g. 20583).
 */
export const generateNoir = async (
    planItemNumber: number | string
): Promise<NoirData> => {
    const request: NoirGatewayRequest<{ plan_item_number: string; review_scope_instance_id: number }> = {
        planNumber: buildPlanNumber(planItemNumber),
        action: 'GENERATE_NOIR',
        payload: {
            plan_item_number: buildPlanNumber(planItemNumber),
            review_scope_instance_id: 1,
        },
    };

    const response = await apiClientFullResponse.post<unknown>(NOIR_API_PATHS.actions, request, {
        timeout: 600000,
    });

    console.log('GENERATE_NOIR response headers:', response.headers);

    const planStatusHeader = getXPlanStatusHeaderValue(response.headers);
    const nextAvailableActions = parseNextAvailableActionsFromHeader(planStatusHeader);
    const taskDefinitionKey = parseTaskDefinitionKeyFromHeader(planStatusHeader);
    const normalized = normalizeNoirData(response.data);

    return {
        ...normalized,
        next_available_actions: nextAvailableActions,
        task_definition_key: taskDefinitionKey,
    };
};

/**
 * Calls the NOIR gateway action endpoint to apply AI instruction-based edits.
 *
 * @param payload - Payload containing original data, original text, and user instructions.
 */
export const aiEditNoir = async (payload: NoirAiEditPayload): Promise<NoirData> => {
    const response = await postNoirAction<unknown, NoirAiEditPayload>(
        payload.plan_item_number,
        'EDIT_NOIR',
        payload
    );

    return normalizeNoirData(response);
};

/**
 * Calls the NOIR gateway action endpoint to persist human edits.
 */
export const editNoir = async (payload: NoirEditPayload): Promise<NoirData> => {
    const response = await postNoirAction<unknown, NoirEditPayload>(
        payload.plan_item_number,
        'HUMAN_EDIT',
        serializeHumanEditPayload(payload)
    );

    return normalizeNoirData(response);
};

/**
 * Calls the NOIR gateway action endpoint to send the generated NOIR document.
 *
 * @param payload - Payload containing plan item number, subject, body, and recipients.
 */
export const sendNoir = async (
    payload: NoirSendPayload
): Promise<{ next_available_actions: string[]; task_definition_key?: string }> => {
    const request: NoirGatewayRequest<NoirSendPayload> = {
        planNumber: buildPlanNumber(payload.plan_item_number),
        action: 'SEND_NOIR_EMAIL',
        payload,
    };

    const response = await apiClientFullResponse.post<unknown>(NOIR_API_PATHS.actions, request, {
        timeout: 600000,
    });

    console.log('SEND_NOIR_EMAIL response headers:', response.headers);

    const planStatusHeader = getXPlanStatusHeaderValue(response.headers);
    const nextAvailableActions = parseNextAvailableActionsFromHeader(planStatusHeader);
    const taskDefinitionKey = parseTaskDefinitionKeyFromHeader(planStatusHeader);

    return {
        next_available_actions: nextAvailableActions,
        task_definition_key: taskDefinitionKey,
    };
};
