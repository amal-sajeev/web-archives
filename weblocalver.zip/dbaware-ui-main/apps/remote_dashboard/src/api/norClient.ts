import { apiClient } from './apiClient';
import { NOR_API_PATHS } from './norApiPaths';
import type { NorData } from '../store/norSlice';
import type { NorEditPayload, NorSendPayload } from './type';

type NorAction = 'GET_NOR' | 'GENERATE_NOR' | 'EDIT_NOR' | 'HUMAN_EDIT_NOR' | 'SEND_NOR_EMAIL';

interface NorGatewayRequest<TPayload> {
    planNumber: string;
    action: NorAction;
    payload: TPayload;
}

type NorAiEditPayload = {
    plan_item_number: string;
    user_instruction: string;
};

type NorHumanEditGatewayPayload = Omit<NorEditPayload, 'nor'> & {
    /** Gateway expects this key for edited document payload. */
    nor: {
        subject: string;
        body: string;
    };
};

const buildPlanNumber = (planNumber: number | string): string => String(planNumber);

const extractNorPayload = (response: unknown): Record<string, any> => {
    const queue: unknown[] = [response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();

        if (!current || typeof current !== 'object' || visited.has(current)) {
            continue;
        }

        visited.add(current);

        const candidate = current as Record<string, any>;
        const nestedNor =
            candidate.nor && typeof candidate.nor === 'object'
                ? {
                    ...candidate.nor,
                    original_data:
                        candidate.original_data ??
                        candidate.updated_data ??
                        candidate.nor.original_data,
                }
                : null;

        const nestedNoir =
            candidate.noir && typeof candidate.noir === 'object'
                ? {
                    ...candidate.noir,
                    original_data:
                        candidate.original_data ??
                        candidate.updated_data ??
                        candidate.noir.original_data,
                }
                : null;

        if (
            nestedNor ||
            nestedNoir ||
            'subject' in candidate ||
            'body' in candidate ||
            'email' in candidate ||
            'email_content' in candidate ||
            'recipients' in candidate ||
            'original_data' in candidate ||
            'updated_data' in candidate
        ) {
            return nestedNor ?? nestedNoir ?? candidate;
        }

        if ('payload' in candidate) queue.push(candidate.payload);
        if ('data' in candidate) queue.push(candidate.data);
        if ('result' in candidate) queue.push(candidate.result);
        if ('response' in candidate) queue.push(candidate.response);
    }

    return (response ?? {}) as Record<string, any>;
};

const normalizeNorData = (response: unknown): NorData => {
    if (!response) {
        throw new Error('Invalid response: received null or undefined');
    }

    const payload = extractNorPayload(response);

    if (!payload || typeof payload !== 'object') {
        throw new Error('Invalid response format: could not extract payload');
    }

    const email = payload.email_content ?? payload.email ?? '';

    return {
        subject: payload.subject ?? '',
        body: payload.body ?? '',
        email_content: email,
        email,
        recipients: Array.isArray(payload.recipients) ? payload.recipients : [],
        original_data: payload.original_data ?? payload.updated_data ?? null,
    };
};

const postNorAction = async <TResponse, TPayload>(
    planNumber: number | string,
    action: NorAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: NorGatewayRequest<TPayload> = {
        planNumber: buildPlanNumber(planNumber),
        action,
        payload,
    };

    try {
        return await apiClient.post<TResponse>(NOR_API_PATHS.actions, request, {
            timeout: 600000,
        });
    } catch (error) {
        if (error instanceof Error) {
            throw new Error(`Failed to ${action}: ${error.message}`);
        }
        throw error;
    }
};

export const getNor = async (
    planItemNumber: number | string
): Promise<NorData> => {
    const response = await postNorAction<unknown, Record<string, never>>(
        planItemNumber,
        'GET_NOR',
        {}
    );

    return normalizeNorData(response);
};

export const generateNor = async (
    planItemNumber: number | string
): Promise<NorData> => {
    const response = await postNorAction<unknown, { plan_item_number: string }>(
        planItemNumber,
        'GENERATE_NOR',
        { plan_item_number: buildPlanNumber(planItemNumber) }
    );

    return normalizeNorData(response);
};

export const editNor = async (payload: NorEditPayload): Promise<NorData> => {
    const requestPayload: NorHumanEditGatewayPayload = {
        plan_item_number: payload.plan_item_number,
        subject: payload.subject ?? payload.nor.subject,
        body: payload.body ?? payload.nor.body,
        nor: {
            subject: payload.nor.subject,
            body: payload.nor.body,
        },
    };

    const response = await postNorAction<unknown, NorHumanEditGatewayPayload>(
        payload.plan_item_number,
        'HUMAN_EDIT_NOR',
        requestPayload
    );

    return normalizeNorData(response);
};

export const aiEditNor = async (payload: NorAiEditPayload): Promise<NorData> => {
    const response = await postNorAction<unknown, NorAiEditPayload>(
        payload.plan_item_number,
        'EDIT_NOR',
        payload
    );

    return normalizeNorData(response);
};

export const sendNor = async (payload: NorSendPayload): Promise<void> => {
    await postNorAction<unknown, NorSendPayload>(
        payload.plan_item_number,
        'SEND_NOR_EMAIL',
        payload
    );
};