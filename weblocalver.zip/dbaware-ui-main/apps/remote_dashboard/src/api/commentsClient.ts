import { apiClient } from './apiClient';
import { PROCEDURE_API_PATHS } from './procedureApiPaths';
import type { ScopingStageEnum } from '../constants/stages';

const COMMENT_KEYS = ['comment', 'comments', 'message', 'text', 'remarks', 'reason'];

const pickText = (item: unknown): string => {
    if (typeof item === 'string') return item.trim();
    if (!item || typeof item !== 'object') return '';
    const record = item as Record<string, unknown>;
    for (const key of COMMENT_KEYS) {
        const value = record[key];
        if (typeof value === 'string' && value.trim()) return value.trim();
    }
    return '';
};

/**
 * Normalizes the comments response. Supports a single object, a plain string,
 * an array (latest/last entry wins) or an envelope such as { data | comments | response }.
 */
const extractLatestComment = (response: unknown): string => {
    if (Array.isArray(response)) {
        for (let i = response.length - 1; i >= 0; i -= 1) {
            const text = pickText(response[i]);
            if (text) return text;
        }
        return '';
    }

    const direct = pickText(response);
    if (direct) return direct;

    if (response && typeof response === 'object') {
        const record = response as Record<string, unknown>;
        for (const key of ['data', 'response', 'payload', 'comments', 'items']) {
            if (record[key] !== undefined && record[key] !== response) {
                const nested = extractLatestComment(record[key]);
                if (nested) return nested;
            }
        }
    }

    return '';
};

/**
 * GET /v1/comments?planNumber=<planNumber>&stage=<stage>
 * Returns the saved send-back comment for the plan/stage, or '' when there is none.
 */
export const getSavedComment = async (
    planNumber: string,
    stage: ScopingStageEnum | string
): Promise<string> => {
    const response = await apiClient.get<unknown>(PROCEDURE_API_PATHS.comments, {
        params: { planNumber, stage },
    });

    return extractLatestComment(response);
};
