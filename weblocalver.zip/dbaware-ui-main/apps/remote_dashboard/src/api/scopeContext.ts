export interface StoredScopingContext {
  planNumber: string;
  processInstanceId?: string;
  taskId?: string;
  taskDefinitionKey?: string;
  owner?: string;
  reviewScopeId?: string;
}

export interface ApiUserDetails {
  review_scope_id?: string;
  process_instance_id?: string;
  task_id?: string;
  review_scope_stage?: string;
  user?: string;
}

const SCOPING_CONTEXT_PREFIX = 'scopingContext:';

const firstNonEmptyString = (...values: unknown[]): string | undefined => {
  for (const val of values) {
    if (typeof val === 'string' && val.trim()) {
      return val.trim();
    }
    if (typeof val === 'number' && Number.isFinite(val)) {
      return String(val);
    }
  }
  return undefined;
};

export const extractReviewScopeIdFromVariables = (
  variables?: Record<string, unknown> | null
): string | undefined => {
  if (!variables || typeof variables !== 'object') return undefined;
  return firstNonEmptyString(
    variables.review_scope_id,
    variables.reviewScopeId,
    variables.review_scope_instance_id,
    variables.reviewScopeInstanceId,
    variables.p_REVIEW_SCOPE_ID
  );
};

export const buildScopeContextFromTaskStatus = (
  planNumber: string | number,
  taskStatus?: {
    planNumber?: string;
    processInstanceId?: string;
    taskId?: string;
    taskDefinitionKey?: string | null;
    owner?: string;
    variables?: Record<string, unknown>;
  } | null
): StoredScopingContext => {
  const plan = String(taskStatus?.planNumber ?? planNumber).trim();
  return {
    planNumber: plan,
    processInstanceId: firstNonEmptyString(taskStatus?.processInstanceId),
    taskId: firstNonEmptyString(taskStatus?.taskId),
    taskDefinitionKey: firstNonEmptyString(taskStatus?.taskDefinitionKey),
    owner: firstNonEmptyString(taskStatus?.owner),
    reviewScopeId: extractReviewScopeIdFromVariables(taskStatus?.variables),
  };
};

export const saveScopingContext = (
  planNumber: string | number,
  context: StoredScopingContext
): void => {
  if (typeof window === 'undefined' || !window.sessionStorage) return;
  const plan = String(context.planNumber || planNumber || '').trim();
  if (!plan) return;
  try {
    window.sessionStorage.setItem(`${SCOPING_CONTEXT_PREFIX}${plan}`, JSON.stringify(context));
  } catch {
    // Ignore storage quota/security errors
  }
};

export const getScopingContext = (
  planNumber: string | number | undefined | null
): StoredScopingContext | null => {
  if (typeof window === 'undefined' || !window.sessionStorage) return null;
  const plan = String(planNumber ?? '').trim();
  if (!plan) return null;
  try {
    const raw = window.sessionStorage.getItem(`${SCOPING_CONTEXT_PREFIX}${plan}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? (parsed as StoredScopingContext) : null;
  } catch {
    return null;
  }
};

export const buildUserDetailsForPlan = (
  planNumber: string | number | undefined | null
): ApiUserDetails | undefined => {
  const ctx = getScopingContext(planNumber);
  if (!ctx) return undefined;

  const details: ApiUserDetails = {};
  if (ctx.reviewScopeId) details.review_scope_id = ctx.reviewScopeId;
  if (ctx.processInstanceId) details.process_instance_id = ctx.processInstanceId;
  if (ctx.taskId) details.task_id = ctx.taskId;
  if (ctx.taskDefinitionKey) details.review_scope_stage = ctx.taskDefinitionKey;
  if (ctx.owner) details.user = ctx.owner;

  return Object.keys(details).length > 0 ? details : undefined;
};
