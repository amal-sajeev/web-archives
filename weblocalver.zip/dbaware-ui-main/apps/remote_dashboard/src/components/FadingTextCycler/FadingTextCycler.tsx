import { useState, useEffect } from 'react';
import type { FC } from 'react';
import styles from './FadingTextCycler.module.css';

interface FadingTextCyclerProps {
    texts: string[];
    cycleIntervalMs?: number;
    fadeDurationMs?: number;
}

const FadingTextCycler: FC<FadingTextCyclerProps> = ({
    texts,
    cycleIntervalMs = 2000,
    fadeDurationMs = 300,
}) => {
    const [index, setIndex] = useState<number>(0);
    const [fade, setFade] = useState<'in' | 'out'>('in');

    useEffect(() => {
        if (!texts || texts.length === 0) return;

        const interval = setInterval(() => {
            setFade('out');
            setTimeout(() => {
                setIndex((prevIndex) => (prevIndex + 1) % texts.length);
                setFade('in');
            }, fadeDurationMs);
        }, cycleIntervalMs);

        return () => clearInterval(interval);
    }, [texts, cycleIntervalMs, fadeDurationMs]);

    if (!texts || texts.length === 0) return null;

    return (
        <span
            className={`${styles.text} ${fade === 'in' ? styles.fadeIn : styles.fadeOut}`}
            style={{ transitionDuration: `${fadeDurationMs}ms` }}
        >
            {texts[index]}
        </span>
    );
};

export default FadingTextCycler;