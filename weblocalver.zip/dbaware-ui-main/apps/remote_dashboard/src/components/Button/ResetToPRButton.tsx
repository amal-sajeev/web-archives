import { OutlineButton } from '@wadk/ui'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { resetToPreliminaryResearch } from '../../api/procedureClient'
import { usePlanId } from '../../hooks/usePlanId'
import { ScopingTabEnum } from '../../store/scopingSlice'
import { showErrorToast, showSuccessToast } from '..'

export default function ResetToPRButton() {
  const navigate = useNavigate()
  const planId = usePlanId()
  const [isResetting, setIsResetting] = useState(false)

  const handleResetToPr = async () => {
    if (!planId) {
      showErrorToast('Reset failed', 'Plan number is not available.')
      return
    }

    setIsResetting(true)
    try {
      await resetToPreliminaryResearch(planId)
      showSuccessToast('Reset to Preliminary Research successful')
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'))
      navigate(`../${ScopingTabEnum.PRELIMINARY_RESEARCH}/${planId}`)
    } catch (error) {
      console.error('Failed to reset to Preliminary Research:', error)
      showErrorToast('Reset failed', 'Could not reset to Preliminary Research.')
    } finally {
      setIsResetting(false)
    }
  }

  return (
    <OutlineButton onClick={handleResetToPr} loading={isResetting} disabled={isResetting}>
      Reset to PR
    </OutlineButton>
  )
}
