import React from 'react';
import { Toaster, toast, ToastSuccess, ToastDanger } from '@wadk/ui';

export const AppToaster: React.FC = () => {
  return <Toaster style={{ top: '24px', bottom: 'auto', right: '24px' }} />;
};

export const showSuccessToast = (title: string, details?: string) => {
  toast(details || title, {
    title: details ? title : undefined,
    variant: ToastSuccess,
  });
};

export const showErrorToast = (title: string, details?: string) => {
  toast(details || title, {
    title: details ? title : undefined,
    variant: ToastDanger,
  });
};

