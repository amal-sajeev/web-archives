
export default function AiRationalIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M15 9.5C12.2472 9.5 9.5 12.2472 9.5 15C9.5 12.2472 6.75279 9.5 4 9.5C6.75279 9.5 9.5 6.75279 9.5 4C9.5 6.75279 12.2472 9.5 15 9.5Z" stroke="#163796" strokeLinecap="round" />
            <path d="M6 3.5C4.74873 3.5 3.5 4.74873 3.5 6C3.5 4.74873 2.25127 3.5 1 3.5C2.25127 3.5 3.5 2.25127 3.5 1C3.5 2.25127 4.74873 3.5 6 3.5Z" stroke="#0098DB" strokeLinecap="round" />
        </svg>
    )
}

