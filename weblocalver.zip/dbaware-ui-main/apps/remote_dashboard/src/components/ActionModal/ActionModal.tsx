import React from 'react';
import { ModalDialog, Button, OutlineButton, Text } from '@wadk/ui';
import styles from './ActionModal.module.css';

export interface ActionModalItem {
  key: string;
  label: string;
  onClick: () => void | Promise<void>;
  disabled?: boolean;
  loading?: boolean;
  tone?: 'default' | 'danger';
  emphasis?: 'primary' | 'default';
}

interface ActionModalProps {
  opened: boolean;
  title?: string;
  subtitle?: string;
  actions: ActionModalItem[];
  emptyMessage?: string;
  onClose: () => void;
}

const ActionModal: React.FC<ActionModalProps> = ({
  opened,
  title = 'Actions',
  subtitle,
  actions,
  emptyMessage = 'No action is required at this stage.',
  onClose,
}) => {
  if (!opened) {
    return null;
  }

  return (
    <ModalDialog
      opened={opened}
      title={title}
      width="md"
      position="center"
      onClose={onClose}
    >
      <div className={styles.container}>
        {subtitle ? <Text className={styles.subtitle}>{subtitle}</Text> : null}
        {actions.length > 0 ? (
          <div className={styles.actions}>
            {actions.map((action) => (
              action.emphasis === 'primary' ? (
                <Button
                  key={action.key}
                  variant={action.tone === 'danger' ? 'danger' : 'primary'}
                  onClick={action.onClick}
                  disabled={action.disabled}
                  loading={action.loading}
                >
                  {action.label}
                </Button>
              ) : (
                <OutlineButton
                  key={action.key}
                  variant={action.tone === 'danger' ? 'danger' : undefined}
                  onClick={action.onClick}
                  disabled={action.disabled}
                  loading={action.loading}
                >
                  {action.label}
                </OutlineButton>
              )
            ))}
          </div>
        ) : (
          <Text className={styles.emptyMessage}>{emptyMessage}</Text>
        )}
      </div>
    </ModalDialog>
  );
};

export default ActionModal;