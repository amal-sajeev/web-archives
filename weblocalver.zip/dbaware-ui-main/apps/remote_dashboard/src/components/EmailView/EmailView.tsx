import React, { ReactNode } from 'react';
import { CardSubHeader, CardContent, LeftSlot, RightSlot, Stack, Text, Separator } from '@wadk/ui';
import { UserDbOutline, UserGroupOutline } from '@wadk/icons';
import { truncateText } from '../../utils/formatUtils';
import style from './EmailView.module.css';

export interface EmailViewProps {
  subject: string;
  teamLeadName: string;
  recipients: string;
  content: string;
  rightSlotContent?: ReactNode;
  contentClassName?: string;
}

export const EmailView: React.FC<EmailViewProps> = ({
  subject,
  teamLeadName,
  recipients,
  content,
  rightSlotContent,
  contentClassName
}) => {
  return (
    <>
      <CardSubHeader>
        <LeftSlot>
          <Stack>
            <Text fontWeight="bold">
              {truncateText(subject, 110)}
            </Text>
            <Text variant="secondary" className={style.emailMeta}>
              Recipients: <UserGroupOutline /> {recipients}
            </Text>
          </Stack>
        </LeftSlot>
        {rightSlotContent && <RightSlot><>{rightSlotContent}</></RightSlot>}
      </CardSubHeader>

      <CardContent>
        <Separator placement="horizontal" />
        <div
          className={`${style.htmlContent}${contentClassName ? ` ${contentClassName}` : ''}`}
          dangerouslySetInnerHTML={{ __html: content }}
        />
      </CardContent>
    </>
  );
};
