import React, { useState } from 'react';
import {
  Stack,
  FormGroup,
  FormItem,
  TextInput,
  RightSlot,
  Text
} from "@wadk/ui"
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';
import 'com.db.rca.commons.afcc-components/style.css';
import style from './EditorForm.module.css';

const EDITOR_OPTIONS = {
  placeholder: 'Compose an epic...',
  modules: { toolbar: false }
};

export interface EditorFormProps {
  initialTitle: string;
  initialContent: string;
  titleLabel?: string;
  onChange: (title: string, content: string) => void;
}

const EditorForm: React.FC<EditorFormProps> = ({
  initialTitle,
  initialContent,
  titleLabel = "Report Title",
  onChange
}) => {
  const [title, setTitle] = useState(initialTitle);
  const [content, setContent] = useState(initialContent);

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = e.target.value;
    setTitle(newTitle);
    onChange(newTitle, content);
  };

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    onChange(title, newContent);
  };

  return (
    <Stack direction="column" gap="md">
      <FormGroup
        id="edit-title-group"
        label={
          <Stack direction="row" gap="xs" align="center">
            <Text>{titleLabel}</Text>
          </Stack>
        }
      >
        <>
          <RightSlot>
            <Text variant="secondary" size="sm">{Math.max(0, 100 - title.length)} characters remaining</Text>
          </RightSlot>
          <FormItem>
            <TextInput
              value={title}
              placeholder={`Enter ${titleLabel.toLowerCase()}...`}
              maxLength={100}
              onChange={handleTitleChange}
            />
          </FormItem>
        </>
      </FormGroup>
      <div className={style.editorContainer}>
        <RichTextEditor
          value={content}
          options={EDITOR_OPTIONS}
          onValueChange={handleContentChange}
        />
      </div>
    </Stack>
  );
};

export default EditorForm;