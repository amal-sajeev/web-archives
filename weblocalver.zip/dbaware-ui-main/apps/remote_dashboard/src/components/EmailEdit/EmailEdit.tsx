import React, { useEffect, useMemo, useState } from 'react';
import { CardSubHeader, CardContent, Stack, FormGroup, FormItem, TextInput } from '@wadk/ui';
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';
import { withUndoRedoEditorOptions } from '../../utils';
import style from './EmailEdit.module.css';

const DEFAULT_EDITOR_OPTIONS = withUndoRedoEditorOptions({
  formats: [
    'bold',
    'italic',
    'underline',
    'strike',
    'header',
    'list',
    'color',
    'background',
    'align'
  ],
  modules: {
    toolbar: [
      ['undo', 'redo'],
      ['bold', 'italic', 'underline', 'strike'],
      [{ header: [1, 2, 3, false] }],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ color: [] }, { background: [] }],
      [{ align: [] }],
      ['clean']
    ]
  }
});

export interface EmailEditProps {
  subject: string;
  onSubjectChange: (value: string) => void;
  content: string;
  onContentChange: (value: string) => void;
  recipients?: string;
  onRecipientsChange?: (value: string) => void;
  recipientPlaceholder?: string;
}

const parseRecipients = (value: string, recipientPlaceholder?: string): string[] => {
  const placeholder = recipientPlaceholder?.trim().toLowerCase();

  return value
    .split(',')
    .map(recipient => recipient.trim())
    .filter(recipient => Boolean(recipient))
    .filter(recipient => recipient.toLowerCase() !== placeholder);
};

export const EmailEdit: React.FC<EmailEditProps> = ({
  subject,
  onSubjectChange,
  content,
  onContentChange,
  recipients = '',
  onRecipientsChange,
  recipientPlaceholder
}) => {
  const recipientItems = useMemo(
    () => parseRecipients(recipients, recipientPlaceholder),
    [recipients, recipientPlaceholder]
  );
  const [draftRecipient, setDraftRecipient] = useState('');

  useEffect(() => {
    if (!draftRecipient.trim()) {
      setDraftRecipient('');
    }
  }, [draftRecipient]);

  const updateRecipients = (nextRecipients: string[]) => {
    const uniqueRecipients = Array.from(
      new Set(nextRecipients.map(recipient => recipient.trim()).filter(Boolean))
    );

    onRecipientsChange?.(uniqueRecipients.join(', '));
  };

  const handleAddRecipient = () => {
    const nextValues = draftRecipient
      .split(/[;,\n]/)
      .map(recipient => recipient.trim())
      .filter(Boolean);

    if (nextValues.length === 0) {
      return;
    }

    updateRecipients([...recipientItems, ...nextValues]);
    setDraftRecipient('');
  };

  const handleRemoveRecipient = (recipientToRemove: string) => {
    updateRecipients(recipientItems.filter(recipient => recipient !== recipientToRemove));
  };

  const handleRecipientKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',' || e.key === ';') {
      e.preventDefault();
      handleAddRecipient();
    }

    if (e.key === 'Backspace' && !draftRecipient.trim() && recipientItems.length > 0) {
      handleRemoveRecipient(recipientItems[recipientItems.length - 1]);
    }
  };

  return (
    <div className={style.emailEditContainer}>
      <CardSubHeader>
        {/* <LeftSlot> */}
        <div className={style.recipientFromEdit} >
          <FormGroup
            id="recipients-group"
            label="Request Recipient(s)"
            required
            hint={{ content: "Add or remove the intended recipients for this review notification." }}
          >
            <FormItem>
              <Stack direction="column" gap="xs">
                <div className={style.recipientInputContainer}>
                  {recipientItems.map(recipient => (
                    <div
                      key={recipient}
                      className={style.recipientChip}
                    >
                      <div className={style.recipientChipContent}>
                        <span className={style.recipientChipText}>
                          {recipient}
                        </span>
                      </div>
                      <button
                        type="button"
                        className={style.recipientRemove}
                        onClick={() => handleRemoveRecipient(recipient)}
                        aria-label={`Remove ${recipient}`}
                      >
                        ×
                      </button>
                    </div>
                  ))}

                  <input
                    className={style.recipientInlineInput}
                    value={draftRecipient}
                    onChange={(e) => setDraftRecipient(e.target.value)}
                    onKeyDown={handleRecipientKeyDown}
                    onBlur={handleAddRecipient}
                    placeholder="Type an email..."
                  />
                </div>
              </Stack>
            </FormItem>
          </FormGroup>

          <FormGroup id="subject-group" label="Subject" required>
            <FormItem>
              <TextInput
                value={subject}
                onChange={(e: any) => onSubjectChange(e.target.value)}
              />
            </FormItem>
          </FormGroup>
        </div>

      </CardSubHeader>

      <CardContent>
        <div className={style.emailEditor}>
          <RichTextEditor
            options={DEFAULT_EDITOR_OPTIONS}
            value={content}
            onValueChange={onContentChange}
          />
        </div>
      </CardContent>
    </div>
  );
};
