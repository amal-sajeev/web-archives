import React, { useEffect, useState } from 'react';
import { Button, OutlineButton, Text, TextArea, Alert, AlertWarning } from '@wadk/ui';
import { DraggableDialog } from 'com.db.rca.commons.afcc-components';
import 'com.db.rca.commons.afcc-components/style.css';
import styles from './SendBackWithComments.module.css';

export const SEND_BACK_COMMENT_MAX_LENGTH = 1000;
export const SEND_BACK_LABEL = 'Send Back with Comments';

const DIALOG_WRAPPER_STYLE: React.CSSProperties = { width: 'min(94vw, 760px)', minWidth: '560px', maxWidth: '94vw' };

interface SendBackModalProps {
    opened: boolean;
    loading?: boolean;
    onCancel: () => void;
    onConfirm: (comment: string) => void | Promise<void>;
}

/** Modal with a mandatory comment textarea (max 1000 chars, counter above at right). */
export const SendBackCommentModal: React.FC<SendBackModalProps> = ({ opened, loading, onCancel, onConfirm }) => {
    const [comment, setComment] = useState('');

    useEffect(() => {
        if (opened) setComment('');
    }, [opened]);

    if (!opened) return null;

    const trimmed = comment.trim();

    return (
        <DraggableDialog
            title="Send Request Back With Comments" onClose={onCancel}
            width="lg"
            position="center"
            wrapperStyle={DIALOG_WRAPPER_STYLE}
            actions={
                <div className={styles.footer} style={{ display: 'flex', justifyContent: 'flex-end', gap: '16px', width: '100%' }}>
                    <OutlineButton onClick={onCancel} disabled={loading}>Cancel</OutlineButton>
                    <Button onClick={() => onConfirm(trimmed)} disabled={!trimmed || loading} loading={loading}>Confirm</Button>
                </div>
            }
        >
            <div className={styles.container}>
                <div className={styles.labelRow}>
                    <Text>Comments <span className={styles.required} aria-hidden="true">*</span></Text>
                    <Text variant="secondary">{comment.length}/{SEND_BACK_COMMENT_MAX_LENGTH}</Text>
                </div>
                <TextArea
                    className={styles.textarea}
                    value={comment}
                    maxLength={SEND_BACK_COMMENT_MAX_LENGTH}
                    rows={6}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setComment(e.target.value)}
                    aria-label="Comments"
                    aria-required="true"
                />
            </div>
        </DraggableDialog>
    );
};

interface SendBackAlertProps {
    message: string;
}

/** Warning alert showing the send-back comment, with a View option for the full message. */
export const SendBackCommentAlert: React.FC<SendBackAlertProps> = ({ message }) => {
    const [viewOpened, setViewOpened] = useState(false);

    if (!message) return null;

    return (
        <>
            <Alert variant={AlertWarning} appearance="light">
                <div className={styles.alertContent}>
                    <span className={styles.alertMessage}>Send Back with Comment Message: {message}</span>
                    <Button variant="link" className={styles.viewButton} onClick={() => setViewOpened(true)}>View</Button>
                </div>
            </Alert>
            {viewOpened && (
                <DraggableDialog
                    title="Send Request Back With Comments" onClose={() => setViewOpened(false)}
                    width="lg"
                    position="center"
                    wrapperStyle={DIALOG_WRAPPER_STYLE}
                    actions={
                        <div className={styles.footer} style={{ display: 'flex', justifyContent: 'flex-end', gap: '16px', width: '100%' }}>
                            <OutlineButton onClick={() => setViewOpened(false)}>Cancel</OutlineButton>
                        </div>}
                >
                    <div className={styles.container}>
                        <Text className={styles.fullMessage}>{message}</Text>
                    </div>
                </DraggableDialog>
            )}
        </>
    );
};
