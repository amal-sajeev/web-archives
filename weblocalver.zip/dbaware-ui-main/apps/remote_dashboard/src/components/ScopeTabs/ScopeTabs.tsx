import React, { useEffect, useMemo } from 'react';
import { TabBar, TabBarTab } from 'com.db.rca.commons.afcc-components';
import { useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { TABS_CONFIG } from '../../constants/tabs';
import {
  ScopingTabEnum,
  setMaxReachedTabIndex,
  setNextAvailableActionsForPlan,
  setTaskDefinitionKeyForPlan,
} from '../../store/scopingSlice';
import { getNextAvailableActionsFromTaskStatus, getTaskStatus } from '../../api/scopingClient';
import { usePlanId } from '../../hooks/usePlanId';

const TASK_DEFINITION_TO_TAB: Record<string, ScopingTabEnum> = {
  NOIR: ScopingTabEnum.NOIR,
  PRELIMINARY_RESEARCH: ScopingTabEnum.PRELIMINARY_RESEARCH,
  DISCOVERY_WALKTHROUGH: ScopingTabEnum.DISCOVERY_WALKTHROUGH,
  DISCOVERY_WALKTHROUGH_AGENDA: ScopingTabEnum.DISCOVERY_WALKTHROUGH,
  SCOPE_RECOMMENDATION: ScopingTabEnum.SCOPE_RECOMMENDATION,
  SCOPING_DOCUMENT: ScopingTabEnum.FINAL_SCOPE_DOCUMENT,
  TEST_STEPS: ScopingTabEnum.TEST_STEPS,
  FINAL_SCOPE_DOCUMENT: ScopingTabEnum.FINAL_SCOPE_DOCUMENT,
  NOR: ScopingTabEnum.NOR,
};

const normalizeTaskDefinitionKey = (value: string): string =>
  value
    .trim()
    .replace(/[\s-]+/g, '_')
    .toUpperCase();

const ScopeTabs: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();

  const scopingState = useSelector((state: any) => state.scoping) || { enabledTabs: [ScopingTabEnum.NOIR], maxReachedTabIndex: 0 };
  const maxReachedTabIndex = scopingState.maxReachedTabIndex ?? 0;
  const taskDefinitionKeyByPlan = scopingState.taskDefinitionKeyByPlan ?? {};
  const isDataGatheringEnabled = localStorage.getItem('dataGatheringToggle') === 'true';

  // Extract planId from route params
  const planId = usePlanId();

  // Robustly determine the current active tab based on the URL segments, even for sub-routes
  const pathSegments = location.pathname.split('/').filter(Boolean).reverse();
  const matchedSegment = pathSegments.find(segment => TABS_CONFIG.some(tab => tab.value === segment));
  const currentPath = (matchedSegment as ScopingTabEnum) || ScopingTabEnum.NOIR;

  // Only the current tab and all earlier tabs are allowed.
  // Later tabs remain disabled until the user reaches them step by step.
  const currentTabIndex = TABS_CONFIG.findIndex(tab => tab.value === currentPath);
  const safeCurrentTabIndex = currentTabIndex >= 0 ? currentTabIndex : 0;

  const effectiveMaxReachedTabIndex = useMemo(() => {
    if (!planId) {
      return maxReachedTabIndex;
    }

    const rawTaskDefinitionKey = String(taskDefinitionKeyByPlan?.[planId] ?? '');
    const normalizedTaskDefinitionKey = normalizeTaskDefinitionKey(rawTaskDefinitionKey);
    const mappedTab = TASK_DEFINITION_TO_TAB[normalizedTaskDefinitionKey];

    if (!mappedTab) {
      return maxReachedTabIndex;
    }

    const mappedTabIndex = TABS_CONFIG.findIndex((tab) => tab.value === mappedTab);
    if (mappedTabIndex < 0) {
      return maxReachedTabIndex;
    }

    return Math.min(maxReachedTabIndex, mappedTabIndex);
  }, [maxReachedTabIndex, planId, taskDefinitionKeyByPlan]);

  useEffect(() => {
    // Do not promote max reached tab from a direct URL jump.
    // Only keep redux in sync when current route is already within allowed range.
    if (safeCurrentTabIndex <= maxReachedTabIndex) {
      dispatch(setMaxReachedTabIndex(safeCurrentTabIndex));
    }
  }, [dispatch, safeCurrentTabIndex, maxReachedTabIndex]);

  useEffect(() => {
    if (!planId) return;

    let isActive = true;

    const syncPlanStatus = async () => {
      try {
        const response = await getTaskStatus(planId);

        if (!isActive) return;

        const resolvedPlanNumber = String(response.planNumber ?? planId);
        const taskDefinitionKey = typeof response.taskDefinitionKey === 'string' ? response.taskDefinitionKey : '';
        const nextAvailableActions = getNextAvailableActionsFromTaskStatus(response);

        dispatch(setTaskDefinitionKeyForPlan({
          planNumber: resolvedPlanNumber,
          taskDefinitionKey,
        }));

        dispatch(setNextAvailableActionsForPlan({
          planNumber: resolvedPlanNumber,
          actions: nextAvailableActions,
        }));

        const normalizedTaskDefinitionKey = normalizeTaskDefinitionKey(taskDefinitionKey);

        const mappedTab = TASK_DEFINITION_TO_TAB[normalizedTaskDefinitionKey];
        if (mappedTab) {
          const mappedTabIndex = TABS_CONFIG.findIndex((tab) => tab.value === mappedTab);
          if (mappedTabIndex >= 0) {
            dispatch(setMaxReachedTabIndex(mappedTabIndex));

            const currentPathIndex = TABS_CONFIG.findIndex((tab) => tab.value === currentPath);
            if (currentPathIndex > mappedTabIndex) {
              navigate(planId ? `/${mappedTab}/${planId}` : `/${mappedTab}`, { replace: true });
            }
          }
        }
      } catch (error) {
        console.warn('Failed to fetch task status for tab route', error);
      }
    };

    syncPlanStatus();

    const handleRefreshPlanStatus = () => {
      void syncPlanStatus();
    };

    window.addEventListener('scoping:refresh-plan-status', handleRefreshPlanStatus as EventListener);

    return () => {
      isActive = false;
      window.removeEventListener('scoping:refresh-plan-status', handleRefreshPlanStatus as EventListener);
    };
  }, [dispatch, planId, location.pathname, currentPath, navigate]);

  const handleTabChange = (value: ScopingTabEnum) => {
    const targetIndex = TABS_CONFIG.findIndex(tab => tab.value === value);

    if (targetIndex <= effectiveMaxReachedTabIndex) {
      if (value !== currentPath) {
        window.dispatchEvent(new CustomEvent('scoping:tab-switch', { detail: { from: currentPath, to: value } }));
      }
      navigate(planId ? `/${value}/${planId}` : `/${value}`);
    }
  };

  const visibleTabs = TABS_CONFIG.filter(
    (tab) => tab.value !== ScopingTabEnum.DATA_GATHERING || isDataGatheringEnabled
  );

  return (
    <>      <TabBar direction="row"
      gap="sm"
      value={currentPath}
      style={{ width: "100%", display: "flex", columnGap: "8px" }}
      onChange={(val) => handleTabChange(val as ScopingTabEnum)}
    >
      {visibleTabs.map((tab, visibleIndex) => {
        const originalIndex = TABS_CONFIG.findIndex((configTab) => configTab.value === tab.value);

        return (
          <TabBarTab
            key={tab.value}
            value={tab.value}
            disabled={originalIndex > effectiveMaxReachedTabIndex}
          >
            {visibleIndex + 1}. {tab.label}
          </TabBarTab>
        );
      })}
    </TabBar>
    </>
  );
};

export default ScopeTabs;
