import { useCallback, useEffect, useState } from 'react';
import { getSavedComment } from '../api/commentsClient';

/**
 * Loads the saved send-back comment for a plan/stage (GET /v1/comments).
 * Returns the comment plus helpers to set it locally (right after a send back) and to reload it.
 * Errors are swallowed on purpose: a missing comment must never break the page.
 */
export const useSavedComment = (planId: string | undefined, stages: string[]) => {
    const [comment, setComment] = useState('');
    const stagesKey = stages.join(',');

    const load = useCallback(async () => {
        if (!planId) {
            setComment('');
            return;
        }

        for (const stage of stagesKey.split(',').filter(Boolean)) {
            try {
                const saved = await getSavedComment(planId, stage);
                if (saved) {
                    setComment(saved);
                    return;
                }
            } catch {
                // no saved comment for this stage
            }
        }
        setComment('');
    }, [planId, stagesKey]);

    useEffect(() => {
        void load();
    }, [load]);

    return { comment, setComment, reloadComment: load };
};
