const STATIC_APPROVER_EMAIL = 'sweekar.a@db.com';

const ROLE_GLOBAL_HEAD = 'GLOBAL_HEAD';
const ROLE_REGIONAL_HEAD = 'REGIONAL_HEAD';
const RC_TOKEN_GLOBAL_KEY = '__dbawareRcToken';

let staticUserRolesPromise: Promise<string[]> | null = null;

const buildRcTokenHeader = (): Record<string, string> => {
  const token = typeof window !== 'undefined' ? ((window as any)[RC_TOKEN_GLOBAL_KEY] as string | null | undefined) : null;
  return token ? { 'x-asm-rctoken': token } : {};
};

const normalizeRoleValue = (value: unknown): string[] => {
  if (typeof value === 'string') {
    return value
      .split(/[;,]/)
      .map((role) => role.trim().toUpperCase())
      .filter(Boolean);
  }

  if (Array.isArray(value)) {
    return value
      .flatMap((role) => normalizeRoleValue(role))
      .filter(Boolean);
  }

  return [];
};

const normalizeRoles = (roles: unknown): string[] => {
  if (Array.isArray(roles) || typeof roles === 'string') {
    return normalizeRoleValue(roles);
  }

  if (roles && typeof roles === 'object') {
    const payload = roles as Record<string, unknown>;

    return normalizeRoleValue(
      payload.roles ??
      payload.role ??
      payload.permissions ??
      payload.permission ??
      payload.data
    );
  }

  return [];
};

export const fetchUserRoles = async (email: string = STATIC_APPROVER_EMAIL): Promise<string[]> => {
  const requestRoles = async () => {
    try {
      const response = await fetch(`/dbaware-user-service/ws/roles/${encodeURIComponent(email)}`, {
        method: 'GET',
        headers: buildRcTokenHeader(),
      });

      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      return normalizeRoles(payload);
    } catch {
      return [];
    }
  };

  if (email === STATIC_APPROVER_EMAIL) {
    if (!staticUserRolesPromise) {
      staticUserRolesPromise = requestRoles();
    }
    return staticUserRolesPromise;
  }

  return requestRoles();
};

export const getApproveButtonTextForRoles = (roles: string[]): string => {
  if (roles.includes(ROLE_GLOBAL_HEAD)) {
    return 'GH Approve';
  }

  if (roles.includes(ROLE_REGIONAL_HEAD)) {
    return 'RH Approve';
  }

  return 'Approve Result';
};

export const resolveApproveButtonTextForStaticUser = async (): Promise<string> => {
  return "Approve Result";
  // const roles = await fetchUserRoles(STATIC_APPROVER_EMAIL);
  // return getApproveButtonTextForRoles(roles);
};
