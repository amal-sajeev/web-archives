const ROLE_GLOBAL_HEAD = 'GLOBAL_HEAD';
const ROLE_REGIONAL_HEAD = 'REGIONAL_HEAD';

export const getApproveButtonTextForRoles = (roles: string[]): string => {
  if (roles.includes(ROLE_GLOBAL_HEAD)) {
    return 'GH Approve';
  }

  if (roles.includes(ROLE_REGIONAL_HEAD)) {
    return 'RH Approve';
  }

  return 'Approve Result';
};

export const resolveApproveButtonTextForStaticUser = async (): Promise<string> => {
  return "Approve Result";
};
