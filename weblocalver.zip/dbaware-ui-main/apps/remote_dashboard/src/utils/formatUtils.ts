import { DiscoveryWalkthroughSection } from '../store/scopingSlice';
import { TestStep } from '../api/type';

/**
 * Truncates a string to a specified maximum length, adding an ellipsis if it exceeds the limit.
 * It also strips newlines to prevent multiline formatting issues in single-line UI elements.
 * 
 * @param text The string to truncate.
 * @param maxLength The maximum allowed length of the string.
 * @returns The truncated string, or the original string if it is within the limit.
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (!text) return '';
  const singleLine = text.split('\n')[0]; // Safeguard against newlines
  if (singleLine.length <= maxLength) return singleLine;
  return `${singleLine.substring(0, maxLength)}...`;
};

/**
 * Extracts the subject line from a combined email string format (e.g., "Subject: ...\n\nBody: ...").
 * 
 * @param emailString The full raw email string.
 * @returns The extracted subject, or a fallback if not found.
 */
export const extractEmailSubject = (emailString: string): string => {
  if (!emailString) return "No Subject";
  const subjectMatch = emailString.match(/^Subject:\s*(.*?)(?:\r?\n\r?\nBody:|$)/is);
  return subjectMatch ? subjectMatch[1].trim() : emailString.trim();
};

/**
 * Extracts the body line from a combined email string format (e.g., "Subject: ...\n\nBody: ...").
 * 
 * @param emailString The full raw email string.
 * @returns The extracted body, or a fallback if not found.
 */
export const extractEmailBody = (emailString: string): string => {
  if (!emailString) return "";
  const bodyMatch = emailString.match(/(?:\r?\n\r?\nBody:\s*|^Body:\s*)([\s\S]*)$/is);
  return bodyMatch ? bodyMatch[1].trim() : emailString.trim();
};

/**
 * Converts plain text email content into a simple HTML paragraph string.
 * Newlines are converted to <br/> to preserve line breaks in rendered views.
 *
 * @param text Plain text body content.
 * @returns Formatted HTML string, or an empty string when input is empty.
 */
export const formatPlainTextEmailBodyAsHtml = (text: string): string => {
  if (!text) return '';
  return `<p>${text.replace(/(?:\r\n|\r|\n)/g, '<br/>')}</p>`;
};

export const jsonToHtml = (sections?: DiscoveryWalkthroughSection[]): string => {
  if (!sections || !Array.isArray(sections)) return '';
  return sections
    .map(s => `<h3>${s.section_title}</h3><ul>${s.key_points.map((p: string) => `<li>${p}</li>`).join('')}</ul>`)
    .join('');
};

export const htmlToJson = (html: string): DiscoveryWalkthroughSection[] => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const sections: DiscoveryWalkthroughSection[] = [];
  let currentSection: DiscoveryWalkthroughSection | null = null;

  Array.from(doc.body.children).forEach(child => {
    if (['H1', 'H2', 'H3', 'H4', 'H5', 'H6'].includes(child.tagName) || (child.tagName === 'P' && child.querySelector('strong'))) {
      if (currentSection) {
        sections.push(currentSection);
      }
      currentSection = { section_title: child.textContent || '', key_points: [] };
    } else if (child.tagName === 'UL' || child.tagName === 'OL') {
      if (!currentSection) {
        currentSection = { section_title: 'General', key_points: [] };
      }
      const points = Array.from(child.querySelectorAll('li')).map(li => li.textContent || '');
      currentSection.key_points.push(...points);
    } else if (child.textContent && child.textContent.trim() !== '') {
      if (!currentSection) {
        currentSection = { section_title: 'General', key_points: [] };
      }
      currentSection.key_points.push(child.textContent.trim());
    }
  });

  if (currentSection) {
    sections.push(currentSection);
  }
  return sections;
};

export const formatSectionsForClipboard = (sections?: any[]): string => {
  if (!sections || !Array.isArray(sections)) return '';
  return sections.map(section => {
    const titleLine = `section_title: "${section.section_title}",`;
    const pointsLines = section.key_points
      .map((point: string) => `  "${point}",`)
      .join('\n');
    return `${titleLine}\nkey_points: \n${pointsLines}`;
  }).join('\n');
};

/**
 * Converts an HTML string to plain text, replacing `<br>` and `<p>` tags with newlines,
 * stripping remaining HTML tags, and decoding HTML entities like `&nbsp;`.
 */
export const stripHtmlToText = (html: string): string => {
  if (!html) return '';

  // Replace common block elements with newlines before parsing
  let text = html.replace(/<br\s*\/?>/gi, '\n');
  text = text.replace(/<\/p>/gi, '\n\n');
  text = text.replace(/<\/div>/gi, '\n');

  // Use DOMParser to decode entities and strip tags
  const doc = new DOMParser().parseFromString(text, 'text/html');
  const decodedText = doc.body.textContent || '';

  // Replace non-breaking spaces (\u00A0) with regular spaces, and clean up extra whitespace
  return decodedText.replace(/\u00A0/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
};

const escapeHtml = (value: string): string => value
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#39;');

const formatInlineMarkdown = (text: string): string => {
  let html = escapeHtml(text);
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/(^|[\s(])\*(?!\*)([^*\n]+?)\*(?=[\s).,:;!?]|$)/g, '$1<em>$2</em>');
  return html;
};

const formatApiTextToHtml = (text: string): string => {
  if (!text) return '';

  const normalizedText = text
    .replace(/\r\n?/g, '\n')
    .replace(/\u00A0/g, ' ')
    .replace(/\n\s*[—–]\s*\n\s*/g, '\n- ')
    .trim();

  if (!normalizedText) return '';

  const lines = normalizedText.split('\n');
  const htmlParts: string[] = [];
  let paragraphLines: string[] = [];
  let isInList = false;
  let currentListItemLines: string[] = [];

  const flushParagraph = () => {
    if (paragraphLines.length === 0) return;
    const paragraphText = paragraphLines.join(' ').replace(/\s+/g, ' ').trim();
    paragraphLines = [];
    if (!paragraphText) return;
    htmlParts.push(`<p style="margin: 0 0 8px 0;">${formatInlineMarkdown(paragraphText)}</p>`);
  };

  const flushListItem = () => {
    if (currentListItemLines.length === 0) return;
    const listItemText = currentListItemLines.join('\n').trim();
    currentListItemLines = [];
    if (!listItemText) return;

    let listItemHtml = formatInlineMarkdown(listItemText);
    listItemHtml = listItemHtml.replace(/\n\s*-\s+/g, '<br/>&bull; ');
    listItemHtml = listItemHtml.replace(/\n+/g, '<br/>');
    htmlParts.push(`<li>${listItemHtml}</li>`);
  };

  const closeList = () => {
    if (!isInList) return;
    flushListItem();
    htmlParts.push('</ul>');
    isInList = false;
  };

  for (const line of lines) {
    const trimmedLine = line.trim();
    const bulletMatch = trimmedLine.match(/^[*-]\s+(.+)$/);
    const boldHeadingMatch = trimmedLine.match(/^\*\*(.+)\*\*$/);

    if (!trimmedLine) {
      if (isInList) {
        if (currentListItemLines.length > 0) {
          currentListItemLines.push('');
        }
      } else {
        flushParagraph();
      }
      continue;
    }

    if (bulletMatch) {
      flushParagraph();
      if (!isInList) {
        htmlParts.push('<ul style="margin: 0 0 8px 20px; padding: 0;">');
        isInList = true;
      } else {
        flushListItem();
      }

      currentListItemLines = [bulletMatch[1].trim()];
      continue;
    }

    if (isInList) {
      currentListItemLines.push(trimmedLine);
      continue;
    }

    if (boldHeadingMatch) {
      flushParagraph();
      closeList();
      htmlParts.push(`<h4 style="margin: 0 0 8px 0;">${formatInlineMarkdown(boldHeadingMatch[1].trim())}</h4>`);
      continue;
    }

    paragraphLines.push(trimmedLine);
  }

  flushParagraph();
  closeList();

  return htmlParts.join('\n');
};

export const testStepsToDisplayHtml = (testSteps?: TestStep[]): string => {
  if (!testSteps || !Array.isArray(testSteps)) return '';

  return testSteps.map((step) => {
    if (!step || typeof step !== 'object') return '';

    const stepData = (step as any).test_step || step;
    if (!stepData || typeof stepData !== 'object') return '';

    let html = '';

    for (const [key, value] of Object.entries(stepData)) {
      const normalizedKey = key.replace(/\u00A0/g, ' ');
      const formattedValue = formatApiTextToHtml(value ? String(value) : '');
      const keyHtml = escapeHtml(normalizedKey);

      html += `<div style="margin: 0 0 12px 0; padding: 0;">`;
      html += `<p style="margin: 0 0 4px 0;"><strong>${keyHtml}</strong>:</p>`;
      html += formattedValue || '<p style="margin: 0;"></p>';
      html += `</div>`;
    }

    return html;
  }).join('<br/>\n');
};

export const testStepsToHtml = (testSteps?: TestStep[]): string => {
  if (!testSteps || !Array.isArray(testSteps)) return '';
  return testSteps.map((step, index) => {
    // Validate that step is an object before processing
    if (!step || typeof step !== 'object') return '';
    
    // Extract test_step if it exists, otherwise use the step directly
    const stepData = (step as any).test_step || step;
    
    // Validate that stepData is an object
    if (!stepData || typeof stepData !== 'object') return '';
    
    let html = ``;
    for (const [key, value] of Object.entries(stepData)) {
      // The API response may contain non-breaking spaces (\u00A0) in keys, replace them with regular spaces
      const normalizedKey = key.replace(/\u00A0/g, ' ');
      const formattedValue = value
        ? String(value)
          .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
          .replace(/\n/g, '<br/>')
        : '';

      if (normalizedKey === 'Test Step Name and Number' || normalizedKey === '1. Test Step Name and Number') {
        html += `<p style="margin: 0; padding: 0;"><strong>${normalizedKey}</strong>: <strong>${formattedValue}</strong></p>\n`;
      } else {
        html += `<p style="margin: 0; padding: 0;"><strong>${normalizedKey}</strong>: ${formattedValue}</p>\n`;
      }
    }
    return html;
  }).join('<br/>\n');
};

export const htmlToTestSteps = (html: string): TestStep[] => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const testSteps: TestStep[] = [];
  let currentStep: TestStep | null = null;

  Array.from(doc.body.children).forEach(child => {
    if (['H1', 'H2', 'H3', 'H4', 'H5', 'H6'].includes(child.tagName)) {
      if (currentStep && Object.keys(currentStep).length > 0) {
        testSteps.push(currentStep);
      }
      currentStep = {};
    } else if (child.tagName === 'P') {
      const strongNode = child.querySelector('strong');
      if (strongNode) {
        const key = strongNode.textContent?.trim() || '';

        // Treat 'Test Step Name and Number' as the delimiter for a new step
        if (key === 'Test Step Name and Number' || key === '1. Test Step Name and Number') {
          if (currentStep && Object.keys(currentStep).length > 0) {
            testSteps.push(currentStep);
          }
          currentStep = {};
        } else if (!currentStep) {
          currentStep = {};
        }

        // Remove the strong node that acts as the key, leaving the value
        const valueContainer = child.cloneNode(true) as HTMLElement;
        const firstStrong = valueContainer.querySelector('strong');
        if (firstStrong) {
          // Remove the key from the HTML, which might include the colon
          // We will use regex on the innerHTML
          let htmlStr = valueContainer.innerHTML;
          htmlStr = htmlStr.replace(/<strong>.*?<\/strong>\s*:\s*/, '');

          // convert <br> to newlines
          htmlStr = htmlStr.replace(/<br\s*\/?>/gi, '\n');

          // extract text
          const tempDoc = new DOMParser().parseFromString(htmlStr, 'text/html');
          const value = tempDoc.body.textContent || '';

          if (key) {
            currentStep[key] = value.trim();
          }
        }
      }
    }
  });

  if (currentStep && Object.keys(currentStep).length > 0) {
    testSteps.push(currentStep);
  }
  return testSteps;
};

/**
 * Converts simple markdown tags (bolding and basic lists) to HTML
 * 
 * @param text Markdown text to format
 * @returns HTML formatted string
 */
export const formatMarkdownToHtml = (text: string): string => {
  if (!text) return '';
  let html = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/(?:\r?\n|^)\*\s+(.*)/g, '<br/>&bull; $1');
  html = html.replace(/\r?\n/g, '<br/>');
  return html;
};

/**
 * Gets a formatted label and percentage for a given confidence score.
 * 
 * @param score The confidence score (0-100)
 * @returns A formatted string label with the score
 */
export const getConfidenceLabel = (score: number): string => {
  if (score >= 90) return `VERY HIGH (${score}%)`;
  if (score >= 70) return `HIGH (${score}%)`;
  if (score >= 50) return `MEDIUM (${score}%)`;
  return `LOW (${score}%)`;
};

/**
 * Gets a CSS module class name prefix based on a confidence score.
 * Note: The caller must map this string to their local CSS module import.
 * 
 * @param score The confidence score (0-100)
 * @returns A string representing the class name key (e.g. 'scoreHigh')
 */
export const getConfidenceColorClassKey = (score: number): string => {
  if (score >= 70) return 'scoreHigh';
  if (score >= 50) return 'scoreMedium';
  return 'scoreLow';
};
