import { matchPath } from 'react-router-dom';

const DASHBOARD_ROUTE_PATTERN = '/:tab/:planId';

export const getDashboardRouteParams = (pathname: string) => {
  const dashboardMatch = matchPath({ path: DASHBOARD_ROUTE_PATTERN, end: false }, pathname);
  return {
    tab: dashboardMatch?.params?.tab,
    planId: dashboardMatch?.params?.planId,
  };
};
