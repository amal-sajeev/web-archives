/**
 * Shared converters between the stored text format and the AFCC RichTextEditor (Quill) HTML.
 *
 * Stored format (what the backend keeps and the view components render):
 *   - `**bold**`
 *   - `* list item` lines
 *   - `<u>underline</u>`
 *   - one text line per line, blank line = paragraph break
 */

const escapeHtml = (value: string): string => value
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;');

const inlineMarkdownToHtml = (text: string): string =>
  escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // `<u>` is part of the stored format (escaped above), so turn it back into a real tag.
    .replace(/&lt;u&gt;(.*?)&lt;\/u&gt;/gi, '<u>$1</u>');

const RICH_TEXT_HISTORY_MODULE = {
  delay: 500,
  maxStack: 100,
  userOnly: true,
};

/**
 * Ensures every RichTextEditor instance has a consistent history module.
 */
export const withUndoRedoEditorOptions = <T extends Record<string, any>>(options: T): T => {
  const modules = (options?.modules || {}) as Record<string, any>;

  return {
    ...options,
    modules: {
      ...modules,
      history: {
        ...RICH_TEXT_HISTORY_MODULE,
        ...(modules.history || {}),
      },
    },
  };
};

/**
 * Stored text -> HTML for the rich text editor.
 * One text line = one <p>; blank line = empty <p>, so line structure round-trips exactly.
 */
export const markdownToEditorHtml = (markdown: string): string => {
  const lines = String(markdown || '').replace(/\r\n?/g, '\n').split('\n');
  const out: string[] = [];
  let listItems: string[] = [];
  const flushList = () => {
    if (listItems.length) {
      out.push(`<ul>${listItems.join('')}</ul>`);
      listItems = [];
    }
  };

  lines.forEach((line) => {
    const listMatch = line.match(/^\s*\*\s+(.*)$/);
    if (listMatch) {
      listItems.push(`<li>${inlineMarkdownToHtml(listMatch[1])}</li>`);
      return;
    }
    flushList();
    out.push(line.trim() === '' ? '<p><br></p>' : `<p>${inlineMarkdownToHtml(line)}</p>`);
  });
  flushList();
  return out.join('');
};

const inlineNodesToMarkdown = (node: Node): string => {
  let result = '';
  node.childNodes.forEach((child) => {
    if (child.nodeType === Node.TEXT_NODE) {
      result += (child.textContent || '').replace(/\u00a0/g, ' ');
      return;
    }
    if (child.nodeType !== Node.ELEMENT_NODE) return;
    const el = child as HTMLElement;
    const tag = el.tagName.toLowerCase();
    if (tag === 'br') return;
    const inner = inlineNodesToMarkdown(el);
    const isBold = tag === 'strong' || tag === 'b';
    if ((isBold || tag === 'u') && inner.trim()) {
      const lead = inner.match(/^\s*/)?.[0] || '';
      const trail = inner.match(/\s*$/)?.[0] || '';
      const core = inner.trim();
      result += isBold ? `${lead}**${core}**${trail}` : `${lead}<u>${core}</u>${trail}`;
    } else {
      result += inner;
    }
  });
  return result;
};

/**
 * Editor HTML -> `**bold**` / `* list item` / `<u>` text (the format the backend stores).
 */
export const editorHtmlToMarkdown = (html: string): string => {
  const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
  const lines: string[] = [];

  const handleBlock = (el: Element) => {
    const tag = el.tagName.toLowerCase();
    if (tag === 'ul' || tag === 'ol') {
      el.querySelectorAll(':scope > li').forEach((li) => {
        lines.push(`* ${inlineNodesToMarkdown(li).trim()}`);
      });
      return;
    }
    lines.push(inlineNodesToMarkdown(el).trim());
  };

  doc.body.childNodes.forEach((node) => {
    if (node.nodeType === Node.ELEMENT_NODE) {
      handleBlock(node as Element);
    } else if (node.nodeType === Node.TEXT_NODE && (node.textContent || '').trim()) {
      lines.push((node.textContent || '').trim());
    }
  });

  return lines.join('\n').replace(/\n+$/, '');
};

/**
 * Editor options: toolbar shows only bold + bullet list.
 * 'underline' is allowed so existing <u> text displays and survives a save.
 */
export const SECTION_EDITOR_OPTIONS = withUndoRedoEditorOptions({
  placeholder: 'Edit content...',
  formats: ['bold', 'underline', 'list'],
  modules: { toolbar: [['undo', 'redo'], ['bold'], [{ list: 'bullet' }]] },
});
