/**
 * Downloads a string as a text file to the user's local machine.
 * 
 * @param content The plain text content to be downloaded.
 * @param filename The desired name of the file (including extension, e.g., 'data.txt').
 */
export const downloadFile = (
  payload: Blob | BlobPart | BlobPart[],
  filename: string,
  mimeType = 'application/octet-stream'
): void => {
  if (!filename) return;

  const blob = payload instanceof Blob
    ? payload
    : new Blob(Array.isArray(payload) ? payload : [payload], { type: mimeType });

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const downloadTextAsFile = (content: string, filename: string): void => {
  if (!content) return;
  downloadFile(content, filename, 'text/plain;charset=utf-8');
};
