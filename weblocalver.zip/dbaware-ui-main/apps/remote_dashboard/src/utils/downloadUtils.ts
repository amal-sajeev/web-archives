/**
 * Downloads a string as a text file to the user's local machine.
 * 
 * @param content The plain text content to be downloaded.
 * @param filename The desired name of the file (including extension, e.g., 'data.txt').
 */
export const downloadTextAsFile = (content: string, filename: string): void => {
  if (!content) return;
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
