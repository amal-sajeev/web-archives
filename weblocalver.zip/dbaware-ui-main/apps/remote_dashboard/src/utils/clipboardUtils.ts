/**
 * Strips HTML tags from a given HTML string and replaces block-level elements
 * like <br> and <p> with appropriate newlines to preserve formatting.
 * 
 * @param html The HTML string to parse.
 * @returns Plain text representation of the HTML.
 */
export const stripHtml = (html: string): string => {
  if (!html) return '';
  const tmp = document.createElement('div');
  
  // Replace <br> and <p> tags with newlines before extracting text content
  let formattedHtml = html.replace(/<br\s*[\/]?>/gi, '\n');
  formattedHtml = formattedHtml.replace(/<\/p>/gi, '\n\n');
  
  tmp.innerHTML = formattedHtml;
  return (tmp.textContent || tmp.innerText || '').trim();
};

const fallbackCopyTextToClipboard = (text: string): boolean => {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  
  // Avoid scrolling to bottom
  textArea.style.top = "0";
  textArea.style.left = "0";
  textArea.style.position = "fixed";

  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();

  try {
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    return successful;
  } catch (err) {
    console.error('Fallback: Oops, unable to copy', err);
    document.body.removeChild(textArea);
    return false;
  }
};

/**
 * Copies the provided text to the user's system clipboard.
 * 
 * @param text The plain text string to copy.
 * @returns A promise that resolves to true if successful, false otherwise.
 */
export const copyToClipboard = (text: string): Promise<boolean> => {
  if (!text) return Promise.resolve(false);
  
  if (navigator?.clipboard?.writeText) {
    return navigator.clipboard.writeText(text)
      .then(() => true)
      .catch((err) => {
        console.warn("Clipboard API failed, trying fallback", err);
        return fallbackCopyTextToClipboard(text);
      });
  } else {
    // Fallback for older browsers or insecure contexts
    return Promise.resolve(fallbackCopyTextToClipboard(text));
  }
};
