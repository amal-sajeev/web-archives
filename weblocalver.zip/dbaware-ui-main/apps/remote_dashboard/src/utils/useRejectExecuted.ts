import { useCallback, useEffect, useState } from 'react';
import { getTaskStatus } from '../api/scopingClient';

const normalize = (value: unknown): string => String(value ?? '').trim().toUpperCase();

/**
 * True when the workflow's last executed action (task status `p_EXECUTED_ACTION`)
 * is one of the given reject actions, i.e. the request was already sent back.
 */
export const useRejectExecuted = (planId: string | undefined, rejectActions: string[]) => {
  const [executedAction, setExecutedAction] = useState('');

  const refresh = useCallback(async () => {
    if (!planId) {
      setExecutedAction('');
      return;
    }
    try {
      const status = await getTaskStatus(planId);
      const vars = (status?.variables ?? {}) as Record<string, unknown>;
      setExecutedAction(normalize(vars.p_EXECUTED_ACTION ?? vars.p_executedAction ?? vars.p_actionTaken));
    } catch {
      // keep previous value on failure
    }
  }, [planId]);

  useEffect(() => {
    void refresh();
    const handler = () => { void refresh(); };
    window.addEventListener('scoping:refresh-plan-status', handler);
    return () => window.removeEventListener('scoping:refresh-plan-status', handler);
  }, [refresh]);

  return rejectActions.map(normalize).includes(executedAction);
};
