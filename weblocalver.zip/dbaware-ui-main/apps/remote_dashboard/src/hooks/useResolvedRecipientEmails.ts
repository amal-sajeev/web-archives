import { useMemo } from 'react';

interface RecipientEntry {
  type?: string;
  emails?: string[];
  attachment?: string;
}

export const useResolvedRecipientEmails = (
  documentRecipients?: string[] | null,
  recipientsList?: RecipientEntry[] | null
): string[] => {
  return useMemo(() => {
    const allEmails: string[] = [];

    if (Array.isArray(documentRecipients)) {
      allEmails.push(...documentRecipients);
    }

    if (Array.isArray(recipientsList) && recipientsList.length > 0) {
      recipientsList.forEach((recipient) => {
        if (recipient?.type === 'Email') {
          if (Array.isArray(recipient.emails) && recipient.emails.length > 0) {
            allEmails.push(...recipient.emails);
          } else {
            allEmails.push(String(recipient.attachment || ''));
          }
        } else if (recipient?.type === 'File' && Array.isArray(recipient.emails) && recipient.emails.length > 0) {
          allEmails.push(...recipient.emails);
        }
      });
    }

    return Array.from(
      new Set(allEmails.map((email) => email?.trim()).filter((email): email is string => Boolean(email)))
    );
  }, [documentRecipients, recipientsList]);
};
