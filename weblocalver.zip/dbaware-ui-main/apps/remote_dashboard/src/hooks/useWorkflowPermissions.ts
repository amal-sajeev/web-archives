import { useMemo } from 'react';

interface WorkflowPayload {
  next_available_actions?: string[];
  task_definition_key?: string;
}

interface UseWorkflowPermissionsParams {
  currentPlanNumber: string;
  nextAvailableActionsByPlan?: Record<string, string[]>;
  taskDefinitionKeyByPlan?: Record<string, string>;
  workflowPayload?: WorkflowPayload | null;
}

const normalize = (value: unknown): string => String(value ?? '').trim().toUpperCase();

const normalizeActions = (actions: unknown[]): string[] => {
  return actions
    .map((action) => normalize(action))
    .filter(Boolean);
};

export const useWorkflowPermissions = ({
  currentPlanNumber,
  nextAvailableActionsByPlan,
  taskDefinitionKeyByPlan,
  workflowPayload,
}: UseWorkflowPermissionsParams) => {
  const availableWorkflowActions = useMemo(() => {
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];
    const actionsFromPayload = Array.isArray(workflowPayload?.next_available_actions)
      ? workflowPayload.next_available_actions
      : [];

    return Array.from(new Set(normalizeActions([...actionsFromPlan, ...actionsFromPayload])));
  }, [nextAvailableActionsByPlan, currentPlanNumber, workflowPayload?.next_available_actions]);

  const actionsForCurrentPlan = useMemo(() => {
    const actions = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];
    return normalizeActions(actions);
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const taskDefinitionKey = useMemo(() => {
    const fromPlan = normalize(taskDefinitionKeyByPlan?.[currentPlanNumber]);
    const fromPayload = normalize(workflowPayload?.task_definition_key);
    return fromPlan || fromPayload;
  }, [taskDefinitionKeyByPlan, currentPlanNumber, workflowPayload?.task_definition_key]);

  const hasAction = (action: string): boolean => availableWorkflowActions.includes(normalize(action));

  const hasActionForCurrentPlan = (action: string): boolean => {
    return actionsForCurrentPlan.includes(normalize(action));
  };

  const isTaskDefinition = (taskKey: string): boolean => taskDefinitionKey === normalize(taskKey);

  return {
    availableWorkflowActions,
    taskDefinitionKey,
    hasAction,
    hasActionForCurrentPlan,
    isTaskDefinition,
  };
};
