import { useParams } from 'react-router-dom';

export const usePlanId = (): string | undefined => {
  const { planId } = useParams<{ planId?: string }>();
  return planId;
};
