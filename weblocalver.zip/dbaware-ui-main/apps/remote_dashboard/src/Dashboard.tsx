import React, { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from 'react-redux';
import scopingReducer, { ScopingTabEnum } from './store/scopingSlice';

import norReducer from './store/norSlice';
import dataGatheringReducer from './store/dataGatheringSlice';
import preliminaryResearchReducer from './store/preliminaryResearchSlice';
import discoveryWalkthroughReducer from './store/discoveryWalkthroughSlice';
import noirReducer from './store/noirSlice';

import ScopeLayout from './layouts/ScopeLayout/ScopeLayout';
import NoirPage from './pages/Noir/NoirPage';
import PreliminaryResearchPage from './pages/PreliminaryResearch/PreliminaryResearchPage';
import DiscoveryWalkthroughPage from './pages/DiscoveryWalkthrough/DiscoveryWalkthroughPage';
import ScopeRecommendationPage from './pages/ScopeRecommendation/ScopeRecommendationPage';
import FinalScopeDocumentPage from './pages/FinalScopeDocument/FinalScopeDocumentPage';
import NorPage from './pages/Nor/NorPage';
import TestStepsPage from './pages/TestSteps/TestPage';
import DataGatheringPage from './pages/DataGathering/DataGatheringPage';
import './Dashboard.module.css';

const HOST_HOME_URL = '/';

const RedirectToHostHome: React.FC = () => {
  useEffect(() => {
    window.location.replace(HOST_HOME_URL);
  }, []);

  return null;
};

const Dashboard: React.FC = () => {
  const store = useStore() as any;
  const planIdRoute = '/:planId';
  useEffect(() => {
    // Inject the scoping reducer dynamically into the host's Redux store
    if (store && typeof store.injectReducer === 'function') {
      if (!store.getState().scoping) {
        store.injectReducer('scoping', scopingReducer);
      }
      if (!store.getState().nor) {
        store.injectReducer('nor', norReducer);
      }
      if (!store.getState().dataGathering) {
        store.injectReducer('dataGathering', dataGatheringReducer);
      }
      if (!store.getState().preliminaryResearch) {
        store.injectReducer('preliminaryResearch', preliminaryResearchReducer);
      }
      if (!store.getState().discoveryWalkthrough) {
        store.injectReducer('discoveryWalkthrough', discoveryWalkthroughReducer);
      }
      if (!store.getState().noir) {
        store.injectReducer('noir', noirReducer);
      }
    }
  }, [store]);

  return (
    <Routes>
      <Route path="/" element={<ScopeLayout />}>
        {/* Require planId, otherwise redirect to host home */}
        <Route index element={<RedirectToHostHome />} />

        <Route path={ScopingTabEnum.NOIR + planIdRoute} element={<NoirPage />} />
        <Route path={ScopingTabEnum.DATA_GATHERING + planIdRoute} element={<DataGatheringPage />} />
        <Route path={ScopingTabEnum.PRELIMINARY_RESEARCH + planIdRoute} element={<PreliminaryResearchPage />} />
        <Route path={ScopingTabEnum.DISCOVERY_WALKTHROUGH + planIdRoute} element={<DiscoveryWalkthroughPage />} />
        <Route path={ScopingTabEnum.SCOPE_RECOMMENDATION + planIdRoute} element={<ScopeRecommendationPage />} />
        <Route path={ScopingTabEnum.TEST_STEPS + planIdRoute} element={<TestStepsPage />} />
        <Route path={ScopingTabEnum.FINAL_SCOPE_DOCUMENT + planIdRoute} element={<FinalScopeDocumentPage />} />
        <Route path={ScopingTabEnum.NOR + planIdRoute} element={<NorPage />} />

        {/* Tab path without planId */}
        <Route path={ScopingTabEnum.NOIR} element={<RedirectToHostHome />} />
        <Route path={ScopingTabEnum.DATA_GATHERING} element={<RedirectToHostHome />} />
        <Route path={ScopingTabEnum.PRELIMINARY_RESEARCH} element={<RedirectToHostHome />} />
        <Route path={ScopingTabEnum.DISCOVERY_WALKTHROUGH} element={<RedirectToHostHome />} />
        <Route path={ScopingTabEnum.SCOPE_RECOMMENDATION} element={<RedirectToHostHome />} />
        <Route path={ScopingTabEnum.TEST_STEPS} element={<RedirectToHostHome />} />
        <Route path={ScopingTabEnum.FINAL_SCOPE_DOCUMENT} element={<RedirectToHostHome />} />
        <Route path={ScopingTabEnum.NOR} element={<RedirectToHostHome />} />

        {/* Catch-all redirect */}
        <Route path="*" element={<RedirectToHostHome />} />
      </Route>
    </Routes>
  );
};

export default Dashboard;
