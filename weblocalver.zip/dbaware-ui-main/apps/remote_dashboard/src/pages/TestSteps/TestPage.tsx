import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Card,
  CardContent,
  CardHeader,
  CardFooter,
  CardTitle,
  LeftSlot,
  Stack,
  Button,
  RightSlot,
  Text,
  Separator,
  OutlineButton,
  FormGroup,
  FormItem,
  TextInput,
  PopoverTrigger,
  Popover,
  PopoverSurface
} from "@wadk/ui";
import { EditBoxSolid, CloneSolid } from '@wadk/icons';
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';

import { ScopingTabEnum, setTestStepsData, ScopingState } from '../../store/scopingSlice';
import { acceptTestSteps, getTestSteps, updateTestSteps, generateTestSteps, downloadTestSteps, approveTestStepsAsRh, rejectTestStepsAsRh, forwardTestStepsToGh, approveTestStepsAsGh, rejectTestStepsAsGh } from '../../api/procedureClient';
import { testStepsToHtml, testStepsToDisplayHtml, htmlToTestSteps, stripHtmlToText, copyToClipboard, resolveApproveButtonTextForStaticUser, fetchUserRoles } from '../../utils';
import { getDashboardRouteParams } from '../../utils';
import { EmptyScopingState, showSuccessToast, FadingTextCycler, AiRationalIcon, ActionModal } from '../../components';
import { showErrorToast } from '../../components/AppToaster/AppToaster';
import {
  AUTO_REDIRECT_DELAY_MS,
  GenerationState,
  ApprovalState,
  TEST_STEPS_MESSAGES,
  EDITOR_OPTIONS
} from '../../constants';

import 'com.db.rca.commons.afcc-components/style.css';
import style from './TestPage.module.css';


// Generation requests currently running, keyed by plan number. Module scope so they
// outlive the page component when the user switches tabs.
const inFlightTestStepsGeneration = new Map<string, Promise<boolean>>();

// Helper function to extract rationale from section
const getSectionRationale = (section: any): string | undefined => {
  if (!section || typeof section === 'string') {
    return undefined;
  }
  return section?.rationale;
};

// Helper function to extract confidence score from section
const getSectionConfidenceScore = (section: any): number | undefined => {
  if (!section || typeof section === 'string') {
    return undefined;
  }
  return section?.confidence_score ?? section?.confidenceScore;
};

/**
 * Renders section metadata including confidence score and AI rationale
 */
const renderSectionMetadata = (section: any, topLevelData?: any) => {
  // Try to get rationale from section first, then fallback to top-level data
  const sectionRationale = getSectionRationale(section) || (topLevelData ? getSectionRationale(topLevelData) : undefined);
  // Try to get confidence score from section first, then fallback to top-level data
  const sectionConfidenceScore = getSectionConfidenceScore(section) ?? (topLevelData ? getSectionConfidenceScore(topLevelData) : undefined);

  const confidenceLabel = typeof sectionConfidenceScore === 'number'
    ? sectionConfidenceScore >= 90
      ? 'VERY HIGH'
      : sectionConfidenceScore >= 70
        ? 'HIGH'
        : sectionConfidenceScore >= 50
          ? 'MEDIUM'
          : 'LOW'
    : 'N/A';

  return (
    <div className={style.aiRationaleContainer}>
      <Text variant="secondary" className={style.confidenceText}>
        Confidence Score : <span className={style.confidenceValue}>{confidenceLabel}{typeof sectionConfidenceScore === 'number' ? ` (${sectionConfidenceScore}%)` : ''}</span>
      </Text>
      <Separator placement="vertical" />
      <Popover>
        <PopoverTrigger>
          <Button variant="link" icon={<AiRationalIcon />} disabled={!sectionRationale}>View AI Rationale</Button>
        </PopoverTrigger>
        <PopoverSurface placement="bottom-end" title="AI Rationale" closable={true}>
          <Text className={style.preWrapText}>{sectionRationale || 'No rationale available for this section.'}</Text>
        </PopoverSurface>
      </Popover>
    </div>
  );
};

/**
 * TestStepsPage Component
 * 
 * Renders the test steps view, allowing users to generate, view, edit, 
 * and approve AI-generated test steps based on scoping data.
 * 
 * @returns {React.FC} The TestStepsPage component
 */
const TestStepsPage: React.FC = () => {
  const testStepsData = useSelector((state: { scoping?: ScopingState }) => state?.scoping?.testStepsData);
  const nextAvailableActionsByPlan = useSelector((state: any) => state.scoping?.nextAvailableActionsByPlan);
  const taskDefinitionKeyByPlan = useSelector((state: any) => state.scoping?.taskDefinitionKeyByPlan);

  const [generationState, setGenerationState] = useState<GenerationState>(
    testStepsData ? 'generated' : 'empty'
  );
  const [selectedStepIndex, setSelectedStepIndex] = useState<number>(0);
  const [isEditingAll, setIsEditingAll] = useState<boolean>(false);
  const [editContentByIndex, setEditContentByIndex] = useState<Record<number, string>>({});
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [approveState, setApproveState] = useState<ApprovalState>('idle');
  const [approveButtonText, setApproveButtonText] = useState('Approve Result');
  const [isGetApiLoading, setIsGetApiLoading] = useState<boolean>(false);
  const [isRedirectingToFinalScope, setIsRedirectingToFinalScope] = useState(false);
  const [isRejecting, setIsRejecting] = useState<boolean>(false);
  const [isForwarding, setIsForwarding] = useState<boolean>(false);
  const [isActionsModalOpen, setIsActionsModalOpen] = useState<boolean>(false);
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const redirectTimeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();
  const { planId } = getDashboardRouteParams(location.pathname);
  const currentPlanNumber = String(planId || '').trim();

  const availableWorkflowActions = useMemo(() => {
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];

    return Array.from(new Set(actionsFromPlan))
      .map((action: unknown) => String(action || '').trim().toUpperCase())
      .filter(Boolean);
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const taskDefinitionKey = useMemo(() => {
    const fromPlan = String(taskDefinitionKeyByPlan?.[currentPlanNumber] ?? '').trim();
    return fromPlan.replace(/[\s-]+/g, '_').toUpperCase();
  }, [taskDefinitionKeyByPlan, currentPlanNumber]);

  const isTestStepsTaskDefinition = taskDefinitionKey === 'TEST_STEPS';
  const isCurrentTabActionable = !taskDefinitionKey || isTestStepsTaskDefinition;
  const canGetTestSteps = availableWorkflowActions.includes('GET_TEST_STEPS');
  const canUpdateTestSteps =
    isCurrentTabActionable && (!isTestStepsTaskDefinition || availableWorkflowActions.includes('UPDATE_TEST_STEPS'));
  const canDownloadTestSteps =
    !isTestStepsTaskDefinition || availableWorkflowActions.includes('DOWNLOAD_TEST_STEPS');
  // Each action button is strictly tied to its own available workflow action.
  const canAcceptTestSteps =
    isCurrentTabActionable && availableWorkflowActions.includes('ACCEPT_TEST_STEPS');

  const TS_RH_APPROVE = 'TS_RH_APPROVE';
  const TS_RH_REJECT = 'TS_RH_REJECT';
  const TS_GH_FWD = 'TS_GH_FWD';
  const TS_GH_APPROVE = 'TS_GH_APPROVE';
  const TS_GH_REJECT = 'TS_GH_REJECT';

  const hasCapability = useCallback((permission: string) => (
    isCurrentTabActionable && availableWorkflowActions.includes(permission)
  ), [isCurrentTabActionable, availableWorkflowActions]);

  // Scenario 1: Regional Head reviewer (approve / forward to GH / reject)
  const canRhApprove = hasCapability(TS_RH_APPROVE);
  const canRhReject = hasCapability(TS_RH_REJECT);
  const canGhForward = hasCapability(TS_GH_FWD);
  const isRhReviewer = canRhApprove || canRhReject || canGhForward;

  // Scenario 2: Global Head reviewer (approve / reject)
  const canGhApprove = hasCapability(TS_GH_APPROVE);
  const canGhReject = hasCapability(TS_GH_REJECT);
  const isGhReviewer = canGhApprove || canGhReject;

  const hasAnyAvailableAction = canAcceptTestSteps || canRhApprove || canRhReject || canGhForward || canGhApprove || canGhReject;

  const hasCachedTestStepsForCurrentPlan =
    !!planId &&
    !!testStepsData &&
    String((testStepsData as any).planNumber) === String(planId) &&
    Array.isArray((testStepsData as any).test_steps) &&
    (testStepsData as any).test_steps.length > 0;

  useEffect(() => {
    let cancelled = false;

    const loadApproveButtonText = async () => {
      const nextButtonText = await resolveApproveButtonTextForStaticUser();
      if (!cancelled) {
        setApproveButtonText(nextButtonText);
      }
    };

    loadApproveButtonText();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    const loadRoles = async () => {
      try {
        const roles = await fetchUserRoles();
        const normalizedRoles = roles.map((role) => String(role || '').trim().toUpperCase());
        if (!cancelled) {
          setUserRoles(normalizedRoles);
        }
      } catch {
        if (!cancelled) {
          setUserRoles([]);
        }
      }
    };

    loadRoles();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (hasCachedTestStepsForCurrentPlan) {
      setGenerationState('generated');
      setSelectedStepIndex(0);
    } else if (generationState !== 'generating') {
      setGenerationState('empty');
    }
  }, [hasCachedTestStepsForCurrentPlan, generationState]);

  useEffect(() => {
    const steps = Array.isArray((testStepsData as any)?.test_steps)
      ? (testStepsData as any).test_steps
      : [];

    if (steps.length === 0) {
      setSelectedStepIndex(0);
      return;
    }

    if (selectedStepIndex >= steps.length) {
      setSelectedStepIndex(0);
    }
  }, [testStepsData, selectedStepIndex]);

  useEffect(() => {
    const handleGenerate = () => {
      setGenerationState('generating');
    };
    window.addEventListener('ai-chat:generate-test-steps', handleGenerate);
    return () => window.removeEventListener('ai-chat:generate-test-steps', handleGenerate);
  }, []);

  useEffect(() => {
    if (!planId || hasCachedTestStepsForCurrentPlan || generationState === 'generating' || !canGetTestSteps) {
      return;
    }

    let cancelled = false;

    const fetchTestStepsIfEmpty = async () => {
      setIsGetApiLoading(true);
      try {
        const response = await getTestSteps({ planNumber: planId });
        if (cancelled || !response) return;

        const hasUsefulTestStepsData =
          Array.isArray((response as any).test_steps) && (response as any).test_steps.length > 0;

        if (!hasUsefulTestStepsData) return;

        dispatch(setTestStepsData(response as any));
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'test-steps-loading' }
        }));
      } catch {
        // Intentionally no-op on error as requested.
      } finally {
        setIsGetApiLoading(false);
      }
    };

    fetchTestStepsIfEmpty();

    return () => {
      cancelled = true;
    };
  }, [dispatch, generationState, hasCachedTestStepsForCurrentPlan, planId, canGetTestSteps]);
  // Latest permission value, read inside the request without re-triggering the effect.
  const canGetTestStepsRef = React.useRef(canGetTestSteps);
  canGetTestStepsRef.current = canGetTestSteps;

  // Re-attach to a generation that is still running after returning to this tab.
  useEffect(() => {
    if (planId && inFlightTestStepsGeneration.has(planId) && !hasCachedTestStepsForCurrentPlan) {
      setGenerationState('generating');
    }
  }, [planId, hasCachedTestStepsForCurrentPlan]);

  useEffect(() => {
    if (generationState !== 'generating' || !planId) {
      return;
    }

    let isMounted = true;

    // One request per plan. It lives outside the component, so it survives tab switches
    // (unmount) and is never duplicated by a remount or dependency change.
    let request = inFlightTestStepsGeneration.get(planId);
    if (!request) {
      const targetPlan = planId;
      request = (async () => {
        try {
          const response: any = await generateTestSteps({
            planNumber: targetPlan,
            useGetAfterGenerate: canGetTestStepsRef.current,
          });
          const payload = response?.data || response?.payload || response;
          // The page matches cached data by planNumber, so make sure it is always present.
          dispatch(setTestStepsData({ ...payload, planNumber: payload?.planNumber ?? targetPlan }));
          window.dispatchEvent(new CustomEvent('test-steps:sync', {
            detail: {
              planNumber: targetPlan,
              status: 'completed',
              message: 'Test Steps have been generated successfully.',
            }
          }));
          window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
          return true;
        } catch (error) {
          console.error('Failed to get or generate test steps data:', error);
          window.dispatchEvent(new CustomEvent('test-steps:sync', {
            detail: {
              planNumber: targetPlan,
              status: 'failed',
              message: 'Failed to generate Test Steps. Please try again.',
            }
          }));
          return false;
        } finally {
          inFlightTestStepsGeneration.delete(targetPlan);
        }
      })();
      inFlightTestStepsGeneration.set(targetPlan, request);
    }

    request.then((succeeded) => {
      if (isMounted) {
        setGenerationState(succeeded ? 'generated' : 'empty');
      }
    });

    return () => {
      isMounted = false;
    };
  }, [generationState, dispatch, planId]);

  /**
   * Handles transitioning a specific test step into edit mode.
   * Converts the test steps into HTML for the rich text editor.
   */
  const handleEditClick = useCallback(() => {
    if (!canUpdateTestSteps) {
      showErrorToast('Action not available', 'UPDATE_TEST_STEPS is not available for this plan.');
      return;
    }

    if (!testStepsData?.test_steps?.length) {
      return;
    }

    const initialEditContentByIndex = testStepsData.test_steps.reduce((acc: Record<number, string>, stepEntry: any, index: number) => {
      acc[index] = testStepsToHtml([stepEntry.test_step]);
      return acc;
    }, {});

    setEditContentByIndex(initialEditContentByIndex);
    setIsEditingAll(true);
  }, [canUpdateTestSteps, testStepsData]);

  /**
   * Handles saving the modified test step.
   * Converts the HTML content back to test steps format and updates the store/API.
   */
  const handleSaveClick = useCallback(async () => {
    if (!canUpdateTestSteps) {
      showErrorToast('Action not available', 'UPDATE_TEST_STEPS is not available for this plan.');
      return;
    }

    if (!testStepsData) return;
    setIsSaving(true);

    try {
      const newSteps = testStepsData.test_steps.map((stepEntry: any, index: number) => {
        const editedHtml = editContentByIndex[index];
        if (typeof editedHtml !== 'string') {
          return stepEntry;
        }

        const parsedSteps = htmlToTestSteps(editedHtml);
        const updatedTestStep = Array.isArray(parsedSteps) ? parsedSteps[0] : parsedSteps;

        return {
          ...stepEntry,
          test_step: updatedTestStep,
        } as any;
      });

      const updatedData: any = {
        ...testStepsData,
        test_steps: newSteps
      };

      await updateTestSteps(updatedData);
      dispatch(setTestStepsData(updatedData));
      setIsEditingAll(false);
      setEditContentByIndex({});
      showSuccessToast(TEST_STEPS_MESSAGES.UPDATE_SUCCESS);
    } catch (error) {
      console.error("Failed to update test steps:", error);
    } finally {
      setIsSaving(false);
    }
  }, [testStepsData, editContentByIndex, dispatch, canUpdateTestSteps]);

  /**
   * Cancels the edit mode and resets the document content.
   */
  const handleCancelClick = useCallback(() => {
    setIsEditingAll(false);
    setEditContentByIndex({});
  }, []);

  /**
    * Calls HITL approval API for generated test steps.
   */
  const handleApproveClick = useCallback(async () => {
    if (!canAcceptTestSteps) {
      showErrorToast('Action not available', 'ACCEPT_TEST_STEPS is not available for this plan.');
      return;
    }

    if (!planId) {
      showErrorToast('Failed to approve test steps', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await acceptTestSteps(planId);
      setApproveState('approved');
      setIsActionsModalOpen(false);
      showSuccessToast(TEST_STEPS_MESSAGES.APPROVE_SUCCESS);
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to approve test steps:', error);
      setApproveState('idle');
      showErrorToast('Failed to approve test steps', 'Could not approve the document.');
    }
  }, [canAcceptTestSteps, planId]);

  /**
   * Generic approve handler for role-based approve actions that redirect to Final Scope Document.
   */
  const handleRoleApproveClick = useCallback(async (
    approveAction: (planNumber: string) => Promise<void>,
    permissionLabel: string,
  ) => {
    if (!planId) {
      showErrorToast('Failed to approve test steps', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await approveAction(planId);
      setApproveState('approved');
      setIsActionsModalOpen(false);
      showSuccessToast(TEST_STEPS_MESSAGES.APPROVE_SUCCESS);
    } catch (error) {
      console.error(`Failed to approve test steps (${permissionLabel}):`, error);
      setApproveState('idle');
      showErrorToast('Failed to approve test steps', 'Could not approve the document.');
    }
  }, [planId]);

  /**
   * Generic reject handler for role-based reject actions that keep the user on the same page.
   */
  const handleRoleRejectClick = useCallback(async (
    rejectAction: (planNumber: string) => Promise<void>,
    permissionLabel: string,
  ) => {
    if (!planId) {
      showErrorToast('Failed to reject test steps', 'Plan number is not available.');
      return;
    }

    setIsRejecting(true);
    try {
      await rejectAction(planId);
      setApproveState('idle');
      setIsActionsModalOpen(false);
      showSuccessToast('Test steps rejected');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error(`Failed to reject test steps (${permissionLabel}):`, error);
      showErrorToast('Failed to reject test steps', 'Could not reject the document.');
    } finally {
      setIsRejecting(false);
    }
  }, [planId]);

  /**
   * Forward to Global Head handler (Regional Head reviewer). Keeps the user on the same page.
   */
  const handleForwardToGhClick = useCallback(async () => {
    if (!planId) {
      showErrorToast('Failed to forward test steps', 'Plan number is not available.');
      return;
    }

    setIsForwarding(true);
    try {
      await forwardTestStepsToGh(planId);
      setIsActionsModalOpen(false);
      showSuccessToast('Test steps forwarded to Global Head');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to forward test steps to GH:', error);
      showErrorToast('Failed to forward test steps', 'Could not forward the document.');
    } finally {
      setIsForwarding(false);
    }
  }, [planId]);

  const isAnyActionBusy = approveState === 'loading' || isRejecting || isForwarding;

  const actionItems = useMemo(() => {
    const items: Array<{
      key: string;
      label: string;
      onClick: () => void | Promise<void>;
      disabled?: boolean;
      loading?: boolean;
      tone?: 'default' | 'danger';
      emphasis?: 'primary' | 'default';
    }> = [];

    if (canAcceptTestSteps) {
      items.push({
        key: 'accept',
        label: 'Accept result',
        onClick: handleApproveClick,
        loading: approveState === 'loading',
        disabled: isAnyActionBusy,
        emphasis: 'primary',
      });
    }

    if (isRhReviewer) {
      items.push({
        key: 'rh-approve',
        label: 'Approve Result',
        onClick: () => handleRoleApproveClick(approveTestStepsAsRh, 'TS_RH_APPROVE'),
        loading: approveState === 'loading',
        disabled: isAnyActionBusy || !canRhApprove,
        emphasis: canAcceptTestSteps ? 'default' : 'primary',
      });
      items.push({
        key: 'gh-forward',
        label: 'Forward to GH',
        onClick: handleForwardToGhClick,
        loading: isForwarding,
        disabled: isAnyActionBusy || !canGhForward,
        emphasis: 'default',
      });
      items.push({
        key: 'rh-reject',
        label: 'Send Back',
        onClick: () => handleRoleRejectClick(rejectTestStepsAsRh, 'TS_RH_REJECT'),
        loading: isRejecting,
        disabled: isAnyActionBusy || !canRhReject,
        tone: 'danger',
        emphasis: 'default',
      });
      return items;
    }

    if (isGhReviewer) {
      items.push({
        key: 'gh-approve',
        label: 'Approve Result',
        onClick: () => handleRoleApproveClick(approveTestStepsAsGh, 'TS_GH_APPROVE'),
        loading: approveState === 'loading',
        disabled: isAnyActionBusy || !canGhApprove,
        emphasis: canAcceptTestSteps ? 'default' : 'primary',
      });
      items.push({
        key: 'gh-reject',
        label: 'Send Back',
        onClick: () => handleRoleRejectClick(rejectTestStepsAsGh, 'TS_GH_REJECT'),
        loading: isRejecting,
        disabled: isAnyActionBusy || !canGhReject,
        tone: 'danger',
        emphasis: 'default',
      });
    }

    return items;
  }, [
    isRhReviewer,
    isGhReviewer,
    canAcceptTestSteps,
    handleApproveClick,
    approveState,
    isRejecting,
    isForwarding,
    isAnyActionBusy,
    canRhApprove,
    canRhReject,
    canGhForward,
    canGhApprove,
    canGhReject,
    handleRoleApproveClick,
    handleRoleRejectClick,
    handleForwardToGhClick,
  ]);

  const hasRoleActions = actionItems.length > 0;

  const handleOpenActionsModal = useCallback(() => {
    setIsActionsModalOpen(true);
  }, []);

  useEffect(() => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (approveState === 'approved' && generationState === 'generated' && planId) {
      setIsRedirectingToFinalScope(true);
      redirectTimeoutRef.current = setTimeout(() => {
        navigate(`../${ScopingTabEnum.FINAL_SCOPE_DOCUMENT}/${planId}`);
      }, AUTO_REDIRECT_DELAY_MS);
      return;
    }

    setIsRedirectingToFinalScope(false);
  }, [approveState, generationState, navigate, planId]);

  useEffect(() => () => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }
  }, []);

  /**
   * Navigates to the final scope document generation view
   */
  const handleGenerateFinalScopeClick = useCallback(() => {
    navigate(`../${ScopingTabEnum.FINAL_SCOPE_DOCUMENT}/${planId}`);
  }, [navigate, planId]);

  /**
   * Handles copying a specific test step to the clipboard.
   */
  const handleCopyClick = useCallback((stepEntry: any) => {
    const textContent = stripHtmlToText(testStepsToHtml([stepEntry.test_step]));
    copyToClipboard(textContent);
    showSuccessToast(TEST_STEPS_MESSAGES.COPY_SUCCESS);
  }, []);

  /**
   * Triggers a file download containing the Test Steps content.
   */
  const handleDownloadClick = async () => {
    if (!canDownloadTestSteps) {
      showErrorToast('Action not available', 'DOWNLOAD_TEST_STEPS is not available for this plan.');
      return;
    }

    if (!testStepsData || !planId) return;

    try {
      const response = await downloadTestSteps({
        planNumber: planId,
        test_steps: testStepsData.test_steps as any
      });

      const blob = new Blob([(response as any).data || response], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `test_steps_${planId}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Failed to download test steps data:", error);
    }
  };

  const anyData = testStepsData as any;
  const globalRationale = anyData?.rationale || TEST_STEPS_MESSAGES.AI_RATIONAL_CONTENT || "AI analyzed 5 similar past reviews and relevant policy documents. Standard scope drivers were mapped based on identified framework gaps and historical findings. [1.0]";
  const globalConfidenceScore = anyData?.confidence_score ?? anyData?.metadata?.confidence_score ?? 100;
  const selectedStep = testStepsData?.test_steps?.[selectedStepIndex];

  return (
    <div className={style.pageContainer}>
      <Card
        outlined
        radius="lg"
        raise="2-subtle"
      >
        <CardHeader>
          <LeftSlot>
            <Stack>
              <CardTitle content={TEST_STEPS_MESSAGES.TITLE} />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && testStepsData && (
            <RightSlot>
              <Stack direction="row" align="center" justifyContent="end" gap="xs">
                {isRedirectingToFinalScope ? (
                  <Text variant="secondary">Redirecting to Final Scope Document...</Text>
                ) : approveState === 'approved' ? (
                  <OutlineButton onClick={handleGenerateFinalScopeClick}>
                    Generate Final Scope Document
                  </OutlineButton>
                ) : (
                  <OutlineButton
                    onClick={handleOpenActionsModal}
                    disabled={isAnyActionBusy || !hasAnyAvailableAction}
                  >
                    Actions
                  </OutlineButton>
                )}
                <OutlineButton onClick={handleDownloadClick} disabled={!canDownloadTestSteps}>Download Result</OutlineButton>
              </Stack>
            </RightSlot>
          )}
        </CardHeader>

        <ActionModal
          opened={isActionsModalOpen}
          title="Test Steps Actions"
          subtitle="Select an action to continue."
          actions={actionItems}
          emptyMessage="No action required at this stage."
          onClose={() => setIsActionsModalOpen(false)}
        />

        {generationState === 'generating' || generationState === 'empty' || !testStepsData ? (
          <CardContent>
            <EmptyScopingState
              subtitle={isGetApiLoading ? 'loading...........' : undefined}
            // title="Ask AI about Test Steps"
            // subtitle={
            //   generationState === 'empty' ? (
            //     "Generate the test steps to get started."
            //   ) : (
            //     <FadingTextCycler texts={TEST_STEPS_MESSAGES.LOADING_TEXTS} />
            //   )
            // }
            // actionText={generationState === 'empty' ? 'Generate Test Steps' : undefined}
            // onActionClick={generationState === 'empty' ? () => {
            //   window.dispatchEvent(new CustomEvent('ai-chat:trigger-generate-test-steps'));
            // } : undefined}
            />
          </CardContent>
        ) : (
          <>
            <Separator placement="horizontal" className={style.topSeparator} />
            <div className={style.contentSectionContainer}>
              {testStepsData.test_steps.map((stepEntry: any, index: number) => {
                const isEditingThis = isEditingAll;

                return (
                  <React.Fragment key={index}>
                    {index > 0 && <Separator placement="horizontal" className={style.topSeparator} />}
                    <CardContent onClick={() => setSelectedStepIndex(index)}>
                      <Stack direction="row" justifyContent="space-between" style={{ width: '100%', gap: '24px', alignItems: 'flex-start', marginBottom: '16px', marginTop: '5px' }}>
                        <div style={{ flex: 1 }} />
                        {!isEditingThis && (
                          <div style={{ minWidth: '350px', textAlign: 'right' }}>
                            {renderSectionMetadata(stepEntry, testStepsData)}
                          </div>
                        )}
                      </Stack>
                      <Stack direction="column" gap="md">
                        <Stack direction="row" justifyContent="space-between" style={{ width: '100%', gap: '24px', alignItems: 'flex-start' }}>
                          <Stack direction="column" gap="sm" style={{ flex: 1 }}>
                            {!isEditingThis && (
                              <div
                                className={style.htmlContent}
                                dangerouslySetInnerHTML={{ __html: testStepsToDisplayHtml([stepEntry]) }}
                              />
                            )}
                          </Stack>
                        </Stack>
                        {isEditingThis && (
                          <div className={style.editorContainer}>
                            <RichTextEditor
                              value={editContentByIndex[index] ?? testStepsToHtml([stepEntry.test_step])}
                              options={EDITOR_OPTIONS}
                              onValueChange={(value: string) => {
                                setEditContentByIndex((prev) => ({
                                  ...prev,
                                  [index]: value,
                                }));
                              }}
                            />
                          </div>
                        )}
                      </Stack>
                    </CardContent>
                  </React.Fragment>
                );
              })}
            </div>
            <Separator placement="horizontal" />
            <CardFooter>
              <LeftSlot>
                {isEditingAll ? (
                  <Stack direction="row" gap="xs2" style={{ width: '100%', justifyContent: 'flex-end' }}>
                    <Button onClick={handleCancelClick} disabled={isSaving}>Cancel</Button>
                    <Button variant="primary" onClick={handleSaveClick} loading={isSaving} disabled={isSaving}>Save</Button>
                  </Stack>
                ) : (
                  <Stack direction="row" gap="xs2">
                    <Button
                      icon={<EditBoxSolid />}
                      variant="link"
                      onClick={handleEditClick}
                      disabled={!selectedStep || !canUpdateTestSteps}
                    >
                      Edit
                    </Button>
                    <Button
                      icon={<CloneSolid />}
                      variant="link"
                      onClick={() => {
                        if (selectedStep) {
                          handleCopyClick(selectedStep);
                        }
                      }}
                      disabled={!selectedStep}
                    >
                      Copy
                    </Button>
                  </Stack>
                )}
              </LeftSlot>
            </CardFooter>
          </>
        )}
      </Card>
    </div>
  );
};

export default TestStepsPage;