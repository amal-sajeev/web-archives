import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  LeftSlot,
  Stack,
  Button,
  RightSlot,
  OutlineButton,
  CardFooter,
  Separator,
} from "@wadk/ui";
import { DownloadSolid, EditBoxSolid, EnvelopeOutline, CloneSolid } from '@wadk/icons';
import {
  EmailView,
  EmailEdit,
  FadingTextCycler,
  EmptyScopingState,
  showSuccessToast,
  showErrorToast,
} from '../../components';
import {
  NOR_PLACEHOLDERS,
  GenerationState,
  SendState,
  NOR_MESSAGES,
  NOR_CONFIG,
} from '../../constants';
import {
  extractEmailSubject,
  extractEmailBody,
  formatPlainTextEmailBodyAsHtml,
  stripHtmlToText,
  copyToClipboard,
  stripHtml,
  downloadTextAsFile,
} from '../../utils';
import { ScopingTabEnum } from '../../store/scopingSlice';
import { setNorData } from '../../store/norSlice';
import { RootState, NorViewModel } from './types';
import { getNor, editNor, sendNor } from '../../api/norClient';
import { usePlanId } from '../../hooks/usePlanId';
import { useResolvedRecipientEmails } from '../../hooks/useResolvedRecipientEmails';
import ResetToPRButton from '../../components/Button/ResetToPRButton';
import style from './NorPage.module.css';

/**
 * NorPage Component.
 *
 * Displays and manages the state of a NOR document.
 * Allows users to generate, view, edit, and send NORs.
 *
 * @returns {React.FC} The rendered NOR Page component.
 */
const NorPage: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const hasHtmlTags = (value: string): boolean => /<\/?[a-z][\s\S]*>/i.test(String(value || ''));
  const normalizeNorBodyToEditorHtml = (body: string): string => {
    const rawBody = String(body || '');
    if (!rawBody.trim()) {
      return '';
    }

    if (!hasHtmlTags(rawBody)) {
      return formatPlainTextEmailBodyAsHtml(rawBody);
    }

    const parsed = new DOMParser().parseFromString(rawBody, 'text/html');
    const bodyNode = parsed.body;

    if (!bodyNode) {
      return rawBody;
    }

    const inner = (bodyNode.innerHTML || '').trim();
    const bodyStyle = (bodyNode.getAttribute('style') || '').trim();

    if (!inner) {
      return rawBody;
    }

    return bodyStyle ? `<div style="${bodyStyle}">${inner}</div>` : inner;
  };

  const planId = usePlanId();

  const norData = useSelector((state: RootState) => state.nor?.norData);
  const recipientsList = useSelector((state: RootState) => state.scoping?.recipients);
  const isGeneratingNor = useSelector((state: RootState) => state.nor?.isGeneratingNor);
  const nextAvailableActionsByPlan = useSelector((state: RootState) => state.scoping?.nextAvailableActionsByPlan);

  const [generationState, setGenerationState] = useState<GenerationState>(
    isGeneratingNor ? 'generating' : norData ? 'generated' : 'empty'
  );

  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [sendState, setSendState] = useState<SendState>('idle');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [norAccepted, setNorAccepted] = useState<boolean>(false);
  const [isNorPreviewAcceptancePending, setIsNorPreviewAcceptancePending] = useState<boolean>(false);
  const [isNorPreviewModalVisible, setIsNorPreviewModalVisible] = useState<boolean>(false);
  const [disableButtons, setDisableButtons] = useState<boolean>(false);
  const shouldRefreshPlanStatusAfterGenerationRef = useRef(false);


  useEffect(() => {
    if (generationState === 'generating') {
      setDisableButtons(true);
    }
  }, [generationState]);

  const currentPlanNumber = String(
    planId ||
    norData?.original_data?.[0]?.['Plan Item Number'] ||
    ''
  );
  const norPlanNumber = String(norData?.original_data?.[0]?.['Plan Item Number'] || '').trim();
  const hasNorForCurrentPlan = !!currentPlanNumber && (!!norData && (!norPlanNumber || norPlanNumber === currentPlanNumber));

  const availableWorkflowActions = useMemo(() => {
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];

    return Array.from(new Set(actionsFromPlan))
      .map((action) => String(action).trim().toUpperCase())
      .filter(Boolean);
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const canGetNor = availableWorkflowActions.includes('GET_NOR');
  const canManualEdit = availableWorkflowActions.includes('EDIT_NOR');
  const canSendNorEmail = availableWorkflowActions.includes('SEND_NOR_EMAIL');

  const resolvedRecipientEmails = useResolvedRecipientEmails(norData?.recipients, recipientsList);

  const hasRecipientEntries = useMemo(() => {
    return Array.isArray(recipientsList) && recipientsList.length > 0;
  }, [recipientsList]);

  const viewModel: NorViewModel = useMemo(() => {
    const data: any = norData;
    const rawItem = data?.original_data?.[0];

    const rawEmail = data?.email_content || data?.email || '';
    const emailBody = data?.body || extractEmailBody(rawEmail);
    const subject = data?.subject || extractEmailSubject(rawEmail);

    const formattedContent = normalizeNorBodyToEditorHtml(emailBody);

    const formattedRecipients = resolvedRecipientEmails.length > 0
      ? resolvedRecipientEmails.join(', ')
      : NOR_PLACEHOLDERS.RECIPIENTS;

    return {
      planTitle: rawItem?.["Plan Item Title"] || "Untitled Plan",
      subject,
      teamLeadName: rawItem?.["Coordinating Team Lead"] || "Unassigned",
      content: formattedContent,
      score: NOR_PLACEHOLDERS.SCORE,
      recipients: formattedRecipients,
      aiRationale: NOR_PLACEHOLDERS.RATIONALE,
    };
  }, [norData, resolvedRecipientEmails]);

  const [docContent, setDocContent] = useState<string>(viewModel.content);
  const [subjectContent, setSubjectContent] = useState<string>(viewModel.subject);
  const [recipientsContent, setRecipientsContent] = useState<string>(resolvedRecipientEmails.join(', '));

  useEffect(() => {
    if (isGeneratingNor) {
      setGenerationState('generating');
    } else if (norData) {
      setNorAccepted(true);
      setDocContent(viewModel.content);
      setSubjectContent(viewModel.subject);
      setRecipientsContent(resolvedRecipientEmails.join(', '));
      setGenerationState('generated');
    } else {
      setNorAccepted(false);
      setGenerationState('empty');
    }
  }, [norData, isGeneratingNor, resolvedRecipientEmails, viewModel.content, viewModel.subject]);

  useEffect(() => {
    if (!planId || hasNorForCurrentPlan || !canGetNor) {
      return;
    }

    let cancelled = false;

    const fetchNorIfEmpty = async () => {
      try {
        const response = await getNor(planId);
        if (cancelled || !response) return;

        const hasUsefulNorContent = Boolean(
          response.subject ||
          response.body ||
          response.email ||
          (Array.isArray(response.original_data) && response.original_data.length > 0)
        );

        if (!hasUsefulNorContent) return;

        dispatch(setNorData(response as any));
        setNorAccepted(true);
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'nor-loading' }
        }));
      } catch {
        // Intentionally no-op on error as requested.
      }
    };

    fetchNorIfEmpty();

    return () => {
      cancelled = true;
    };
  }, [dispatch, hasNorForCurrentPlan, isGeneratingNor, planId, canGetNor]);

  useEffect(() => {
    if (!planId || norData || isGeneratingNor) {
      return;
    }

    setGenerationState('empty');
  }, [isGeneratingNor, norData, planId]);

  useEffect(() => {
    if (!canManualEdit && isEditing) {
      setIsEditing(false);
    }
  }, [canManualEdit, isEditing]);

  useEffect(() => {
    if (!shouldRefreshPlanStatusAfterGenerationRef.current) {
      return;
    }

    if (generationState === 'generated') {
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
      shouldRefreshPlanStatusAfterGenerationRef.current = false;
    }
  }, [generationState]);

  // Listen for NOR acceptance event from the chat flow
  useEffect(() => {
    const activePlanId = String(currentPlanNumber || planId || '').trim();

    const handleNorAccepted = (event: Event) => {
      const customEvent = event as CustomEvent<{ norData: any; planId: string }>;
      const acceptedPlanId = String(customEvent.detail?.planId || '').trim();
      if (acceptedPlanId && activePlanId && acceptedPlanId !== activePlanId) {
        return;
      }

      setNorAccepted(true);
      setIsNorPreviewAcceptancePending(false);
      setIsNorPreviewModalVisible(false);
      if (customEvent.detail?.norData) {
        dispatch(setNorData(customEvent.detail.norData));
      }
    };

    const handleNorPreviewOpened = (event: Event) => {
      setIsNorPreviewAcceptancePending(true);
    };

    const handleNorPreviewVisibilityChanged = (event: Event) => {
      const customEvent = event as CustomEvent<{ planId?: string; visible?: boolean }>;
      setIsNorPreviewModalVisible(Boolean(customEvent.detail?.visible));
    };

    window.addEventListener('nor:accepted', handleNorAccepted);
    window.addEventListener('nor:preview-opened', handleNorPreviewOpened);
    window.addEventListener('nor:preview-visibility-changed', handleNorPreviewVisibilityChanged);
    return () => {
      window.removeEventListener('nor:accepted', handleNorAccepted);
      window.removeEventListener('nor:preview-opened', handleNorPreviewOpened);
      window.removeEventListener('nor:preview-visibility-changed', handleNorPreviewVisibilityChanged);
    };
  }, [dispatch, planId, currentPlanNumber]);

  useEffect(() => {
    if (!norData) {
      setNorAccepted(false);
      setIsNorPreviewAcceptancePending(false);
      setIsNorPreviewModalVisible(false);
    }
  }, [norData]);

  /**
   * Hide Generate NOR CTA immediately when AI Presenter triggers NOR generation.
   */
  useEffect(() => {
    const handleGenerateNorTriggered = () => {
      shouldRefreshPlanStatusAfterGenerationRef.current = true;
      setDisableButtons(true);
      setGenerationState('generating');
      setIsNorPreviewAcceptancePending(true);
    };

    window.addEventListener('ai-chat:generate-nor', handleGenerateNorTriggered);
    window.addEventListener('ai-chat:nor-generation-started', handleGenerateNorTriggered);

    return () => {
      window.removeEventListener('ai-chat:generate-nor', handleGenerateNorTriggered);
      window.removeEventListener('ai-chat:nor-generation-started', handleGenerateNorTriggered);
    };
  }, []);

  const handleGenerate = (): void => {
    if (!currentPlanNumber) {
      showErrorToast('Failed to generate NOR', 'Plan number is not available');
      return;
    }

    shouldRefreshPlanStatusAfterGenerationRef.current = true;
    setDisableButtons(true);

    setGenerationState('generating');

    window.dispatchEvent(new CustomEvent('ai-chat:generate-nor'));
  };

  const handleSaveClick = async (): Promise<void> => {
    if (!canManualEdit) {
      showErrorToast('Edit not allowed', 'Editing is not available at this step.');
      return;
    }

    setIsSaving(true);
    try {
      const originalData = norData?.original_data || [];
      const combinedText = `Subject: ${subjectContent}\n\nBody:\n${stripHtmlToText(docContent)}`;
      const planItemFromData = (originalData as any)?.[0]?.['Plan Item Number'];

      const payload = {
        plan_item_number: String(planId || planItemFromData || ''),
        nor: {
          subject: subjectContent,
          body: docContent,
        },
      };

      const responseData = await editNor(payload);
      const apiResult = responseData as any;

      const updatedNorData: any = {
        ...(norData || {}),
        email_content: apiResult.email_content || apiResult.email || combinedText,
        email: apiResult.email_content || apiResult.email || combinedText,
        subject: apiResult.subject || subjectContent,
        body: apiResult.body || docContent,
        recipients: recipientsContent
          .split(',')
          .map(recipient => recipient.trim())
          .filter(recipient => recipient.length > 0),
        original_data: apiResult.original_data || apiResult.updated_data || originalData,
      };

      dispatch(setNorData(updatedNorData));
      showSuccessToast(NOR_MESSAGES.UPDATE_SUCCESS);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update NOR:', error);
      showErrorToast(NOR_MESSAGES.UPDATE_ERROR, 'Could not save the document changes.');
    } finally {
      setIsSaving(false);
    }
  };



  const handleSendNorClick = async (): Promise<void> => {
    if (!canSendNorEmail) {
      showErrorToast('Send not allowed', 'Sending NOR is not available at this step.');
      return;
    }

    try {
      const originalData = norData?.original_data || [];
      const planItemFromData = (originalData as any)?.[0]?.['Plan Item Number'];
      const planItemNumber = String(planId || planItemFromData || '');

      if (!planItemNumber) {
        showErrorToast('Failed to send NOR', 'plan_item_number is required to persist recipients');
        setSendState('idle');
        return;
      }

      const recipientList = recipientsContent
        .split(',')
        .map(email => email.trim())
        .filter(email => email.length > 0);

      if (recipientList.length === 0) {
        showErrorToast('Recipients email ID', 'Recipient is required');
        return;
      }

      setSendState('loading');

      const payload = {
        plan_item_number: planItemNumber,
        email_content: `Subject: ${subjectContent}\n\nBody:\n${stripHtmlToText(docContent)}`,
        subject: subjectContent,
        body: docContent,
        to_recipients: recipientList,
        from_address: NOR_CONFIG.fromAddress,
      };

      await sendNor(payload);

      setSendState('sent');
      showSuccessToast(NOR_MESSAGES.SEND_SUCCESS);
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to send NOR:', error);
      showErrorToast('Failed to send NOR', 'Could not send the document.');
      setSendState('idle');
    }
  };
  /**
   * Downloads the NOR email content as a .txt file.
   */
  const handleDownloadNorClick = (): void => {
    const subject = (subjectContent || '').trim();
    const body = stripHtmlToText(docContent || '');

    if (!subject && !body) {
      showErrorToast('Failed to download NOR', 'No email content available to download.');
      return;
    }

    const content = `Subject: ${subject}\n\nBody:\n${body}`;
    const filePlanNumber = currentPlanNumber || 'unknown';
    downloadTextAsFile(content, `nor_email_${filePlanNumber}.txt`);
    showSuccessToast('NOR email downloaded');
  };

  const renderEmptyState = () => (
    <CardContent>
      {
        (disableButtons || hasRecipientEntries) ?
          <EmptyScopingState
          // title="Ask AI about NOR"
          // secondaryActionText="Skip for now"
          // onSecondaryActionClick={handleSkip}
          />
          :
          <EmptyScopingState
          // title="Ask AI about NOR"
          // actionText="Generate NOR"
          // onActionClick={handleGenerate}
          // secondaryActionText="Skip for now"
          // onSecondaryActionClick={handleSkip}
          />
      }
    </CardContent>
  );

  const renderGeneratingState = () => (
    <CardContent>
      <EmptyScopingState
      // title="NOR"
      // subtitle={
      //   <FadingTextCycler
      //     texts={[
      //       'Creating NOR...',
      //       'Analyzing historical data...',
      //       'Generating insights...'
      //     ]}
      //   />
      // }
      />
    </CardContent>
  );

  const renderGeneratedState = () => (
    <>

      <Separator placement="horizontal" className={style.emailSeparator} />

      {isEditing ? (
        <EmailEdit
          subject={subjectContent}
          onSubjectChange={setSubjectContent}
          content={docContent}
          onContentChange={setDocContent}
          recipients={recipientsContent}
          onRecipientsChange={setRecipientsContent}
          recipientPlaceholder={NOR_PLACEHOLDERS.RECIPIENTS}
        />
      ) : (
        <EmailView
          subject={viewModel.subject}
          teamLeadName={viewModel.teamLeadName}
          recipients={viewModel.recipients}
          content={docContent}
          contentClassName={style.htmlContent}
          rightSlotContent={undefined}
        />
      )}

      <CardFooter>
        {isEditing ? (
          <LeftSlot>
            <Stack direction="row" gap="xs2" grow={0}>
              <Button onClick={() => setIsEditing(false)} disabled={isSaving}>Cancel</Button>
              <Button variant="primary" onClick={handleSaveClick} loading={isSaving} disabled={isSaving}>Save</Button>
            </Stack>
          </LeftSlot>
        ) : (
          <LeftSlot>
            <>
              {canManualEdit && sendState !== 'loading' && sendState !== 'sent' && (
                <Button icon={<EditBoxSolid />} variant="link" onClick={() => setIsEditing(true)}>
                  Edit
                </Button>
              )}
              <Button icon={<CloneSolid />} variant="link" onClick={() => {
                copyToClipboard(stripHtml(docContent));
                showSuccessToast('Content copied to clipboard');
              }}>
                Copy
              </Button>
            </>
          </LeftSlot>
        )}
      </CardFooter>
    </>
  );

  return (
    <div className={style.pageContainer}>
      <Card outlined radius="lg" raise="2-subtle">
        <CardHeader>
          <LeftSlot>
            <Stack gap="xs">
              <CardTitle content="NOR Output" />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && (
            <RightSlot>
              <>
                <OutlineButton
                  icon={<EnvelopeOutline />}
                  onClick={handleSendNorClick}
                  loading={sendState === 'loading'}
                  disabled={isEditing || sendState === 'loading' || sendState === 'sent' || !canSendNorEmail || isNorPreviewAcceptancePending || isNorPreviewModalVisible}
                >
                  Accept and Send NOR
                </OutlineButton>
                <ResetToPRButton />
                <Button icon={<DownloadSolid />} variant="link" size="sm" onClick={handleDownloadNorClick}>
                  Download
                </Button>
              </>
            </RightSlot>
          )}
        </CardHeader>

        {generationState === 'empty' && renderEmptyState()}
        {generationState === 'generating' && renderGeneratingState()}
        {generationState === 'generated' && norAccepted && renderGeneratedState()}
      </Card>
    </div>
  );
};

export default NorPage;
