import { ScopingState } from '../../store/scopingSlice';
import { NorState } from '../../store/norSlice';

export interface RootState {
  scoping: ScopingState;
  nor: NorState;
}

export interface NorViewModel {
  planTitle: string;
  subject: string;
  teamLeadName: string;
  content: string;
  score: string;
  recipients: string;
  aiRationale: string;
}
