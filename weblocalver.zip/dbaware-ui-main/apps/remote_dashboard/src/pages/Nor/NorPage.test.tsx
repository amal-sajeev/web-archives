import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { render, screen, fireEvent, waitFor, cleanup } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import NorPage from './NorPage';
import { NOR_CONFIG } from '../../constants';
import { setNorData } from '../../store/norSlice';

const dispatchMock = vi.fn();
const getNorMock = vi.fn();
const generateNorMock = vi.fn();
const editNorMock = vi.fn();
const sendNorMock = vi.fn();
let mockState: any;

vi.mock('react-redux', async () => {
  const actual = await vi.importActual<typeof import('react-redux')>('react-redux');
  return {
    ...actual,
    useDispatch: () => dispatchMock,
    useSelector: (selector: any) => selector(mockState),
  };
});

vi.mock('../../api/norClient', () => ({
  getNor: (...args: any[]) => getNorMock(...args),
  generateNor: (...args: any[]) => generateNorMock(...args),
  editNor: (...args: any[]) => editNorMock(...args),
  sendNor: (...args: any[]) => sendNorMock(...args),
}));

vi.mock('../../components', async () => await import('../../test/mocks/afccComponents'));

describe('NorPage', () => {
  beforeEach(() => {
    mockState = {
      nor: {
        norData: null,
        isGeneratingNor: false,
      },
      scoping: {
        recipients: [],
        nextAvailableActionsByPlan: {
          '20090': ['GET_NOR', 'SEND_NOR_EMAIL', 'HUMAN_EDIT_NOR'],
        },
        taskDefinitionKeyByPlan: {
          '20090': 'NOR',
        },
      },
    };
    dispatchMock.mockClear();
    getNorMock.mockReset();
    generateNorMock.mockReset();
    editNorMock.mockReset();
    sendNorMock.mockReset();
    getNorMock.mockRejectedValue(new Error('GET failed'));
    generateNorMock.mockResolvedValue({
      subject: 'NOR subject',
      body: 'NOR body',
      email: 'Subject: NOR subject\n\nBody:\nNOR body',
      recipients: ['nor@example.com'],
      original_data: [{
        'Plan Item Number': 20090,
        'Plan Item Title': 'NOR Plan',
        'Coordinating Team Lead': 'John Doe',
      }],
    });
    editNorMock.mockResolvedValue({
      subject: 'Edited NOR subject',
      body: 'Edited NOR body',
      email: 'Subject: Edited NOR subject\n\nBody:\nEdited NOR body',
      recipients: ['nor@example.com'],
      original_data: [{
        'Plan Item Number': 20090,
        'Plan Item Title': 'NOR Plan',
        'Coordinating Team Lead': 'John Doe',
      }],
    });
    sendNorMock.mockResolvedValue(undefined);
  });

  afterEach(() => {
    cleanup();
  });

  it('renders the empty state and attempts GET NOR hydration', async () => {
    render(
      <MemoryRouter initialEntries={['/nor/20090']}>
        <NorPage />
      </MemoryRouter>
    );

    expect(screen.getByTestId('EmptyScopingState')).toBeTruthy();
    expect(getNorMock).toHaveBeenCalledWith('20090');
    expect(generateNorMock).not.toHaveBeenCalled();
    expect(dispatchMock).not.toHaveBeenCalledWith(expect.objectContaining({ type: setNorData.type }));
  });

  it('sends the NOR with the configured sender address', async () => {
    mockState = {
      nor: {
        norData: {
          subject: 'Subject line',
          body: 'Body line',
          email_content: 'Subject: Subject line\n\nBody:\nBody line',
          email: 'Subject: Subject line\n\nBody:\nBody line',
          recipients: ['alpha@example.com', 'beta@example.com'],
          original_data: [{
            'Plan Item Number': 20090,
            'Plan Item Title': 'NOR Plan',
            'Coordinating Team Lead': 'John Doe',
          }],
        },
        isGeneratingNor: false,
      },
      scoping: {
        recipients: [],
        nextAvailableActionsByPlan: {
          '20090': ['SEND_NOR_EMAIL', 'HUMAN_EDIT_NOR'],
        },
        taskDefinitionKeyByPlan: {
          '20090': 'NOR',
        },
      },
    };

    render(
      <MemoryRouter initialEntries={['/nor/20090']}>
        <NorPage />
      </MemoryRouter>
    );

    window.dispatchEvent(new CustomEvent('nor:accepted', { detail: {} }));

    const sendButtons = await screen.findAllByRole('button', { name: 'Send' });
    const sendButton = sendButtons[sendButtons.length - 1];
    fireEvent.click(sendButton);

    await waitFor(() => expect(sendNorMock).toHaveBeenCalledWith(expect.objectContaining({
      plan_item_number: '20090',
      subject: 'Subject line',
      body: 'Body line',
      to_recipients: ['alpha@example.com', 'beta@example.com'],
      from_address: NOR_CONFIG.fromAddress,
    })));
  });

  it('uses uploaded scoping recipients when NOR recipients are missing', async () => {
    mockState = {
      nor: {
        norData: {
          subject: 'Subject line',
          body: 'Body line',
          email_content: 'Subject: Subject line\n\nBody:\nBody line',
          email: 'Subject: Subject line\n\nBody:\nBody line',
          recipients: [],
          original_data: [{
            'Plan Item Number': 20090,
            'Plan Item Title': 'NOR Plan',
            'Coordinating Team Lead': 'John Doe',
          }],
        },
        isGeneratingNor: false,
      },
      scoping: {
        recipients: [
          { type: 'Email', attachment: 'uploaded1@example.com' },
          { type: 'File', emails: ['uploaded2@example.com', 'uploaded3@example.com'] },
        ],
        nextAvailableActionsByPlan: {
          '20090': ['SEND_NOR_EMAIL', 'HUMAN_EDIT_NOR'],
        },
        taskDefinitionKeyByPlan: {
          '20090': 'NOR',
        },
      },
    };

    render(
      <MemoryRouter initialEntries={['/nor/20090']}>
        <NorPage />
      </MemoryRouter>
    );

    window.dispatchEvent(new CustomEvent('nor:accepted', { detail: {} }));

    const sendButtons = await screen.findAllByRole('button', { name: 'Send' });
    const sendButton = sendButtons[sendButtons.length - 1];
    fireEvent.click(sendButton);

    await waitFor(() => expect(sendNorMock).toHaveBeenCalledWith(expect.objectContaining({
      plan_item_number: '20090',
      subject: 'Subject line',
      body: 'Body line',
      to_recipients: ['uploaded1@example.com', 'uploaded2@example.com', 'uploaded3@example.com'],
      from_address: NOR_CONFIG.fromAddress,
    })));
  });
});
