import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    LeftSlot,
    Stack,
    Separator,
    NavTab,
    Tab,
    RightSlot,
    OutlineButton
} from "@wadk/ui";
import { useDispatch } from 'react-redux';
import { AUTO_REDIRECT_DELAY_MS, GenerationState, SendState } from '../../constants';
import { EmptyScopingState, FadingTextCycler, showErrorToast, showSuccessToast } from '../../components';
import CurrentPlanDetailsTab from './tabs/CurrentPlanDetailsTab';
import AlternativeAndNoCoverageTab from './tabs/AlternativeAndNoCoverageTab';
import HistoricalPlanDetailsTab from './tabs/HistoricalPlanDetailsTab';
import LRRTab from './tabs/LRRTab';
import PolicyTab from './tabs/PolicyTab';
import ControlDetailsTab from './tabs/ControlDetailsTab';
import FindingsDataTab from './tabs/FindingsDataTab';
import style from './DataGathering.module.css';
import { ScopingTabEnum } from '../../store/scopingSlice';
import { useNavigate, useLocation } from 'react-router-dom';
import {
    getDataExtractionStatus,
    getPlanAvailability,
    getPlanArtifact,
    triggerDataExtraction,
} from '../../api/dataGatheringClient';
import { setArtifactData } from '../../store/dataGatheringSlice';
import { getDashboardRouteParams } from '../../utils';
import { useSelector } from 'react-redux';

const DATA_GATHERING_SESSION_PREFIX = 'dbaware:data-gathering:session:';
const DATA_GATHERING_TABS = [
    { label: "Current Plan Details", id: "current_details" },
    { label: "Alternative and No Coverage", id: "alc_nlac" },
    { label: "Historical Plan Details", id: "historical_plan_details" },
    { label: "LRR", id: "lrr" },
    { label: "Policy", id: "policy" },
    { label: "Control Details", id: "control_details" },
    { label: "Findings Data", id: "findings_details" }
];

const EXTRACTION_POLL_INTERVAL_MS = 20000; // 20 seconds

declare global {
    interface WindowEventMap {
        'data-gathering:sync': CustomEvent<{
            planNumber: string;
            status: 'triggered' | 'polling' | 'completed' | 'failed';
            sessionId?: string;
            message?: string;
        }>;
    }
}

const getSessionStorageKey = (planNumber: string) => `${DATA_GATHERING_SESSION_PREFIX}${planNumber}`;

const savePendingSession = (planNumber: string, sessionId: string) => {
    window.sessionStorage.setItem(getSessionStorageKey(planNumber), sessionId);
};

const getPendingSession = (planNumber: string): string | null =>
    window.sessionStorage.getItem(getSessionStorageKey(planNumber));

const clearPendingSession = (planNumber: string) => {
    window.sessionStorage.removeItem(getSessionStorageKey(planNumber));
};

/**
 * DataGatheringPage Component
 * 
 * Renders the data gathering results tabs and loading states.
 * 
 * @returns {React.ReactElement} The rendered DataGatheringPage component.
 */
const DataGatheringPage: React.FC = () => {
    const dispatch = useDispatch();
    const [generationState, setGenerationState] = useState<GenerationState>('empty');
    const [activeTabId, setActiveTabId] = useState<string>(DATA_GATHERING_TABS[0].id);
    const location = useLocation();
    const { planId: planNumber } = getDashboardRouteParams(location.pathname);
    const resolvedPlanNumber = planNumber || '';
    const cachedArtifacts = useSelector((state: any) => state.dataGathering?.artifacts?.[resolvedPlanNumber]);
    const [sendState, setSendState] = useState<SendState>('idle');
    const [loadingMessage, setLoadingMessage] = useState('Checking data availability...');
    const [isRedirectingToPrelim, setIsRedirectingToPrelim] = useState(false);
    const navigate = useNavigate();
    const approveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const pollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const redirectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    useEffect(() => {
        if (cachedArtifacts && Object.keys(cachedArtifacts).length > 0) {
            setGenerationState('generated');
        } else {
            // Check if there's a pending session - if so, show generating state
            const pendingSessionId = getPendingSession(resolvedPlanNumber);
            if (pendingSessionId) {
                setGenerationState('generating');
            }
        }
    }, [cachedArtifacts, resolvedPlanNumber]);

    const clearPendingTimers = useCallback(() => {
        if (approveTimeoutRef.current) {
            clearTimeout(approveTimeoutRef.current);
            approveTimeoutRef.current = null;
        }

        if (pollTimeoutRef.current) {
            clearTimeout(pollTimeoutRef.current);
            pollTimeoutRef.current = null;
        }

        if (redirectTimeoutRef.current) {
            clearTimeout(redirectTimeoutRef.current);
            redirectTimeoutRef.current = null;
        }
    }, []);

    const cacheLrrArtifact = useCallback(async (currentPlanNumber: string) => {
        const response = await getPlanArtifact<any>(currentPlanNumber, 'lrr');
        const rawDetails = response.data?.internet_search_data || response.data?.lrr_details || [];

        const formattedData = rawDetails.map((item: any) => ({
            riskName: item.search_combination?.['UoT Risk Type'] || item.riskName || item['Risk Name'] || 'Unknown',
            regulatoryMandate: item.search_result || item.regulatoryMandate || item['Regulatory Mandate'] || 'No mandate found.',
            confidenceScore: item.confidenceScore || item['Confidence Score'] || '1',
            aiRationale: item.aiRationale || item['AI Rationale'] || 'Extracted from search results.'
        }));

        dispatch(setArtifactData({ planNumber: currentPlanNumber, artifactType: 'lrr', data: formattedData }));
    }, [dispatch]);

    const preloadDataGatheringArtifacts = useCallback(async (currentPlanNumber: string) => {
        const loadCurrentPlanDetails = async () => {
            const response = await getPlanArtifact<any>(currentPlanNumber, 'current_details');
            const planDetails = response.data?.plan_details;

            if (!planDetails) return;

            const rawMappings = planDetails['AU-RT-KC'] || response.data?.mappings || [];
            const formattedMappings = rawMappings.map((m: any) => ({
                riskTypeId: m.RT || m.riskTypeId || '',
                assessmentUnit: m.AU || m.assessmentUnit || '',
                keyControls: m.KC || m.keyControls || ''
            }));

            const parsedData = {
                reviewId: planDetails['Plan Item Number'] || currentPlanNumber,
                reviewTitle: planDetails['Plan Item Title'] || planDetails['Review Title'] || '',
                reviewDescription: planDetails['Description of Plan Item'] || planDetails['Review Description'] || '',
                planItemType: planDetails['Plan Item Type'] || 'Review',
                uotCoreProcess: planDetails['UoT Core Process'] || '',
                planYear: planDetails['Plan Year'] || '',
                leadTeam: planDetails['Participating Office / Team'] || planDetails['Lead Team'] || '',
                focusArea: planDetails['Plan Item Focus (AFC/CT)'] || planDetails['Focus Area'] || '',
                assessmentUnit: planDetails['AU Aggregation point 2'] || planDetails['Assessment Unit'] || '',
                uotLe: planDetails['UoT LE'] || '',
                leadRegionalHead: planDetails['Lead Regional/Functional Head'] || '',
                uotRegions: planDetails['AU Region'] || planDetails['UoT Regions'] || '',
                uotCountries: planDetails['UoT Countries'] || '',
                uotRiskType: planDetails['Risk Types'] || planDetails['UoT Risk Type'] || '',
                uotKcs: planDetails['UoT KCs'] || '',
                mappings: formattedMappings
            };

            dispatch(setArtifactData({ planNumber: currentPlanNumber, artifactType: 'current_details', data: parsedData }));
        };

        const loadAlternativeAndNoCoverage = async () => {
            const response = await getPlanArtifact<any>(currentPlanNumber, 'alc_nlac');
            const rawDetails = response.data?.alc_nalc_details || [];
            dispatch(setArtifactData({ planNumber: currentPlanNumber, artifactType: 'alc_nlac', data: rawDetails }));
        };

        const loadHistoricalPlanDetails = async () => {
            const response = await getPlanArtifact<any>(currentPlanNumber, 'historical_plan_details');
            const rawDetails = response.data?.historical_plan_details || [];
            dispatch(setArtifactData({ planNumber: currentPlanNumber, artifactType: 'historical_plan_details', data: rawDetails }));
        };

        const loadLrr = async () => {
            await cacheLrrArtifact(currentPlanNumber);
        };

        const loadPolicy = async () => {
            const response = await getPlanArtifact<any>(currentPlanNumber, 'policy');
            const rawData = response.data || {};
            const uniqueDocs = new Map<string, any>();

            const processSection = (sectionKey: string, fileType: string) => {
                const citations = rawData[sectionKey]?.citations || [];
                citations.forEach((c: any) => {
                    if (c.gs_uri && !uniqueDocs.has(c.gs_uri)) {
                        uniqueDocs.set(c.gs_uri, {
                            documentName: c.document_name ? c.document_name.replace(/\.pdf$/i, '').replace(/_/g, ' ') : 'Unknown',
                            fileType,
                            gsUri: c.gs_uri
                        });
                    }
                });
            };

            processSection('relevant_policy', 'Policy');
            processSection('relevant_kod', 'KOD');
            processSection('relevant_procedure', 'Procedure');

            const formattedData = Array.from(uniqueDocs.values()).map((item, index) => {
                const encodedUri = encodeURIComponent(item.gsUri);
                return {
                    index: index + 1,
                    documentName: item.documentName,
                    fileType: item.fileType,
                    documentUrl: `/dbaware-ui/${currentPlanNumber}/docs/uri?document_uri=${encodedUri}`
                };
            });

            dispatch(setArtifactData({ planNumber: currentPlanNumber, artifactType: 'policy', data: formattedData }));
        };

        const loadControlDetails = async () => {
            const response = await getPlanArtifact<any>(currentPlanNumber, 'control_details');
            const rawData = response.data?.control_details?.included_kcs || [];
            dispatch(setArtifactData({ planNumber: currentPlanNumber, artifactType: 'control_details', data: rawData }));
        };

        const loadFindings = async () => {
            const response = await getPlanArtifact<any>(currentPlanNumber, 'findings_details');
            const findingsEntries = response.data?.findings_details;
            let rawData: any[] = [];
            if (Array.isArray(findingsEntries)) {
                rawData = findingsEntries.flatMap((entry: any) => entry?.responsePayload || []);
            } else if (findingsEntries?.responsePayload) {
                rawData = findingsEntries.responsePayload;
            }
            dispatch(setArtifactData({ planNumber: currentPlanNumber, artifactType: 'findings_details', data: rawData }));
        };

        await Promise.allSettled([
            loadCurrentPlanDetails(),
            loadAlternativeAndNoCoverage(),
            loadHistoricalPlanDetails(),
            loadLrr(),
            loadPolicy(),
            loadControlDetails(),
            loadFindings()
        ]);
    }, [cacheLrrArtifact, dispatch]);

    const handleApproveClick = useCallback(() => {
        setSendState('loading');
        approveTimeoutRef.current = setTimeout(() => {
            setSendState('sent');
            showSuccessToast('Data gathering approved successfully');
        }, 2000);
    }, []);

    useEffect(() => {
        if (redirectTimeoutRef.current) {
            clearTimeout(redirectTimeoutRef.current);
            redirectTimeoutRef.current = null;
        }

        if (generationState === 'generated' && sendState === 'sent' && resolvedPlanNumber) {
            setIsRedirectingToPrelim(true);
            redirectTimeoutRef.current = setTimeout(() => {
                navigate(`../${ScopingTabEnum.PRELIMINARY_RESEARCH}/${resolvedPlanNumber}`);
            }, AUTO_REDIRECT_DELAY_MS);
            return;
        }

        setIsRedirectingToPrelim(false);
    }, [generationState, navigate, resolvedPlanNumber, sendState]);

    const confirmAvailability = useCallback(async (currentPlanNumber: string) => {
        setLoadingMessage('Finalizing data gathering results...');

        try {
            const availability = await getPlanAvailability(currentPlanNumber);

            if (availability.available) {
                await preloadDataGatheringArtifacts(currentPlanNumber).catch(error => {
                    console.warn('Failed to preload data gathering artifacts after data extraction:', error);
                });
                clearPendingSession(currentPlanNumber);
                setGenerationState('generated');
                setLoadingMessage('Data extraction completed.');
                return true;
            }

            if (availability.sessionId) {
                savePendingSession(currentPlanNumber, availability.sessionId);
            }

            return false;
        } catch (error) {
            console.error('Failed to confirm data availability:', error);
            setGenerationState('empty');
            showErrorToast('Failed to load extracted data', 'Data extraction completed, but the results are not yet available.');
            return false;
        }
    }, [preloadDataGatheringArtifacts]);

    const pollExtractionStatus = useCallback(async (currentPlanNumber: string, sessionId: string) => {
        setLoadingMessage('Fetching extracted plan data...');

        try {
            const statusResponse = await getDataExtractionStatus(currentPlanNumber, sessionId);

            if (statusResponse.isComplete) {
                const isAvailable = await confirmAvailability(currentPlanNumber);

                if (!isAvailable) {
                    pollTimeoutRef.current = setTimeout(() => {
                        void pollExtractionStatus(currentPlanNumber, statusResponse.sessionId || sessionId);
                    }, EXTRACTION_POLL_INTERVAL_MS);
                }
                return;
            }

            if (statusResponse.isFailed) {
                clearPendingSession(currentPlanNumber);
                setGenerationState('empty');
                showErrorToast('Data extraction failed', statusResponse.message || 'Unable to complete data extraction.');
                return;
            }

            savePendingSession(currentPlanNumber, statusResponse.sessionId || sessionId);
            setLoadingMessage(statusResponse.message || 'Data extraction in progress...');
            pollTimeoutRef.current = setTimeout(() => {
                void pollExtractionStatus(currentPlanNumber, statusResponse.sessionId || sessionId);
            }, EXTRACTION_POLL_INTERVAL_MS);
        } catch (error) {
            console.error('Failed to fetch extraction status:', error);
            setGenerationState('empty');
            showErrorToast('Failed to fetch extraction status', 'Could not retrieve the extraction progress.');
        }
    }, []);

    const ensureDataAvailability = useCallback(async () => {
        if (!resolvedPlanNumber) {
            setGenerationState('empty');
            return;
        }

        clearPendingTimers();
        setSendState('idle');
        setGenerationState('generating');
        setLoadingMessage('Checking data availability...');

        try {
            const pendingSessionId = getPendingSession(resolvedPlanNumber);

            if (pendingSessionId) {
                setLoadingMessage('Resuming data extraction...');
                await pollExtractionStatus(resolvedPlanNumber, pendingSessionId);
                return;
            }

            try {
                const availability = await getPlanAvailability(resolvedPlanNumber);

                if (availability.available) {
                    clearPendingSession(resolvedPlanNumber);
                    setGenerationState('generated');
                    return;
                }

                if (availability.sessionId) {
                    savePendingSession(resolvedPlanNumber, availability.sessionId);
                    setLoadingMessage(availability.message || 'Resuming data extraction...');
                    await pollExtractionStatus(resolvedPlanNumber, availability.sessionId);
                    return;
                }
            } catch (error) {
                console.warn('GET plan availability failed, falling back to data extraction:', error);
            }

            setLoadingMessage('Starting data extraction...');
            const extractionResponse = await triggerDataExtraction(resolvedPlanNumber);

            if (!extractionResponse.accepted) {
                throw new Error(extractionResponse.message || 'Data extraction request was not accepted.');
            }

            if (extractionResponse.sessionId) {
                savePendingSession(resolvedPlanNumber, extractionResponse.sessionId);
                setLoadingMessage(extractionResponse.message || 'Data extraction in progress...');
                await pollExtractionStatus(resolvedPlanNumber, extractionResponse.sessionId);
                return;
            }

            throw new Error('Data extraction did not return a session ID.');
        } catch (error) {
            console.error('Failed to initialize data gathering:', error);
            setGenerationState('empty');
            showErrorToast('Failed to initialize data gathering', 'Could not start or resume data extraction.');
        }
    }, [clearPendingTimers, pollExtractionStatus, resolvedPlanNumber]);

    const handleGenerateDataGatheringClick = useCallback(() => {
        if (!resolvedPlanNumber) {
            showErrorToast('Failed to initialize data gathering', 'Plan number is not available.');
            return;
        }

        window.dispatchEvent(new CustomEvent('ai-chat:trigger-generate-data-gathering'));

        void ensureDataAvailability();
    }, [ensureDataAvailability, resolvedPlanNumber]);

    useEffect(() => () => {
        clearPendingTimers();
    }, [clearPendingTimers]);

    useEffect(() => {
        if (!resolvedPlanNumber) {
            return;
        }

        const handleDataGatheringSync = (event: WindowEventMap['data-gathering:sync']) => {
            const detail = event.detail;

            if (detail.planNumber !== resolvedPlanNumber) {
                return;
            }

            if (detail.message) {
                setLoadingMessage(detail.message);
            }

            if (detail.status === 'failed') {
                clearPendingTimers();
                clearPendingSession(resolvedPlanNumber);
                setGenerationState('empty');
                if (detail.message) {
                    showErrorToast('Data gathering generation failed', detail.message);
                }
                return;
            }

            if (detail.status === 'completed') {
                setLoadingMessage(detail.message || 'Data gathering completed successfully.');
                void confirmAvailability(resolvedPlanNumber);
                return;
            }

            // Keep generating state for 'triggered' and 'polling' statuses
            setGenerationState('generating');

            if (detail.sessionId) {
                savePendingSession(resolvedPlanNumber, detail.sessionId);
                void pollExtractionStatus(resolvedPlanNumber, detail.sessionId);
            }
        };

        window.addEventListener('data-gathering:sync', handleDataGatheringSync as EventListener);

        return () => {
            window.removeEventListener('data-gathering:sync', handleDataGatheringSync as EventListener);
        };
    }, [clearPendingTimers, confirmAvailability, pollExtractionStatus, resolvedPlanNumber]);

    const renderGeneratingState = () => (
        <CardContent>
            <EmptyScopingState
                // title="Data Gathering"
                // subtitle={
                //     <FadingTextCycler
                //         texts={[
                //             loadingMessage,
                //             'Analyzing source artifacts...',
                //             'Preparing data gathering tabs...'
                //         ]}
                //     />
                // }
            />
        </CardContent>
    );

    const renderEmptyState = () => (
        <CardContent>
            <EmptyScopingState
                // title="Ask AI about Data Gathering"
                // actionText="Generate Data Gathering"
                // onActionClick={handleGenerateDataGatheringClick}
            />
        </CardContent>
    );

    return (
        <div className={style.pageContainer}>
            <Card outlined radius="lg" raise="2-subtle">
                <CardHeader>
                    <LeftSlot>
                        <Stack>
                            <CardTitle content="Data Gathering" />
                        </Stack>
                    </LeftSlot>
                    {generationState === 'generated' && (
                        <RightSlot>
                            <>
                                {sendState === 'sent' ? (
                                    <OutlineButton disabled>
                                        {isRedirectingToPrelim ? 'Redirecting to Generate Preliminary Research...' : 'Redirecting to Generate Preliminary Research...'}
                                    </OutlineButton>
                                ) : (
                                    <OutlineButton
                                        onClick={handleApproveClick}
                                        loading={sendState === 'loading'}
                                        disabled={sendState === 'loading'}
                                    >
                                        Approve result
                                    </OutlineButton>
                                )}
                            </>
                        </RightSlot>
                    )}

                </CardHeader>
                {generationState === 'generated' && (
                    <CardContent>
                        <NavTab
                            direction="row"
                            variant="moustache"
                            value={activeTabId}
                            onChange={(val) => {
                                setActiveTabId(val as string);
                            }}
                        >
                            {DATA_GATHERING_TABS.map((tab) => (
                                <Tab key={tab.id} value={tab.id}>
                                    {tab.label}
                                </Tab>
                            ))}
                        </NavTab>
                    </CardContent>
                )}

                {generationState === 'generating' && renderGeneratingState()}

                {generationState === 'empty' && renderEmptyState()}

                {generationState === 'generated' && (
                    <>
                        <Separator placement="horizontal" className={style.topSeparator} />
                        <CardContent >
                            {activeTabId === 'current_details' && (
                                <CurrentPlanDetailsTab planNumber={resolvedPlanNumber} />
                            )}
                            {activeTabId === 'alc_nlac' && (
                                <AlternativeAndNoCoverageTab planNumber={resolvedPlanNumber} />
                            )}
                            {activeTabId === 'historical_plan_details' && (
                                <HistoricalPlanDetailsTab planNumber={resolvedPlanNumber} />
                            )}
                            {activeTabId === 'lrr' && (
                                <LRRTab planNumber={resolvedPlanNumber} />
                            )}
                            {activeTabId === 'policy' && (
                                <PolicyTab planNumber={resolvedPlanNumber} />
                            )}
                            {activeTabId === 'control_details' && (
                                <ControlDetailsTab planNumber={resolvedPlanNumber} />
                            )}
                            {activeTabId === 'findings_details' && (
                                <FindingsDataTab planNumber={resolvedPlanNumber} />
                            )}
                            {activeTabId !== 'current_details' && activeTabId !== 'alc_nlac' && activeTabId !== 'historical_plan_details' && activeTabId !== 'lrr' && activeTabId !== 'policy' && activeTabId !== 'control_details' && activeTabId !== 'findings_details' && (
                                <EmptyScopingState
                                    title="Tab Implementation Pending"
                                    subtitle={`Data for ${DATA_GATHERING_TABS.find(t => t.id === activeTabId)?.label} is not yet implemented.`}
                                />
                            )}
                        </CardContent>
                    </>
                )}
            </Card>
        </div>
    );
};

export default DataGatheringPage;