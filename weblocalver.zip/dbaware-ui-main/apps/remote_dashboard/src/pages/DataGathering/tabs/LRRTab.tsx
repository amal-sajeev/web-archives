import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Stack, Text, Table, CardContent, Spinner, FormGroup, FormItem, TextInput, Button } from '@wadk/ui';
import { useDispatch, useSelector } from 'react-redux';
import { getPlanArtifact, startLrrProcess, getLrrProcessStatus, getLrrRunDetails } from '../../../api/dataGatheringClient';
import style from '../DataGathering.module.css';
import { EmptyScopingState } from '../../../components';
import { setArtifactData } from '../../../store/dataGatheringSlice';
import type { DataGatheringTabProps, LrrProcessStatus } from './interfaces';

const LRR_COLUMNS = [
    { label: 'Risk Name', key: 'riskName' },
    { label: 'Regulatory Mandate', key: 'regulatoryMandate' },
    { label: 'Confidence Score', key: 'confidenceScore' },
    { label: 'AI Rationale', key: 'aiRationale' }
];

const LRR_POLL_INTERVAL_MS = 20000;
const LRR_STORAGE_PREFIX = 'dbaware:lrr:run:';
const DEFAULT_LRR_GOAL = '';

const LRRTab: React.FC<DataGatheringTabProps> = ({ planNumber }) => {
    const dispatch = useDispatch();
    const reduxData = useSelector((state: any) => state.dataGathering?.artifacts?.[planNumber]?.['lrr']);
    const data = reduxData || [];
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [urlInput, setUrlInput] = useState('');
    const [goalInput, setGoalInput] = useState(DEFAULT_LRR_GOAL);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [processStatus, setProcessStatus] = useState<LrrProcessStatus>('idle');
    const [processMessage, setProcessMessage] = useState<string>('');
    const [runId, setRunId] = useState<string>('');
    const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const isProcessing = isSubmitting || processStatus === 'in_progress';

    const getStorageKey = useCallback(() => `${LRR_STORAGE_PREFIX}${planNumber}`, [planNumber]);

    const stopPolling = useCallback(() => {
        if (pollIntervalRef.current) {
            clearInterval(pollIntervalRef.current);
            pollIntervalRef.current = null;
        }
    }, []);

    const clearSavedRunId = useCallback(() => {
        localStorage.removeItem(getStorageKey());
    }, [getStorageKey]);

    const saveRunId = useCallback((value: string) => {
        localStorage.setItem(getStorageKey(), value);
    }, [getStorageKey]);

    const buildRunSummaryMessage = useCallback((currentRunId: string, details: any, fallback: string) => {
        const normalizedStatus = details?.status ? String(details.status).toLowerCase() : fallback;
        const base = `LRR URL processing ${normalizedStatus} (Run ID: ${currentRunId}).`;

        if (normalizedStatus === 'queued' || normalizedStatus === 'running' || normalizedStatus === 'pending' || normalizedStatus === 'in_progress') {
            const step = details?.step;
            const pipeline = details?.pipeline;
            if (typeof step === 'number' && pipeline) {
                return `${base} Pipeline: ${pipeline}. Step: ${step}.`;
            }
            if (typeof step === 'number') {
                return `${base} Step: ${step}.`;
            }
            if (pipeline) {
                return `${base} Pipeline: ${pipeline}.`;
            }
            return base;
        }

        if (details?.error) {
            return `${base} Error: ${details.error}`;
        }

        const accepted = details?.accepted ?? 0;
        const rejected = details?.rejected ?? 0;
        const review = details?.review ?? 0;
        return `${base} Accepted: ${accepted}, Review: ${review}, Rejected: ${rejected}.`;
    }, []);

    const pollStatusOnce = useCallback(async (currentRunId: string): Promise<'in_progress' | 'completed' | 'failed'> => {
        try {
            const status = await getLrrProcessStatus(currentRunId);
            const statusLabel = status.status || 'in_progress';

            if (status.isComplete) {
                const details = await getLrrRunDetails(currentRunId).catch(() => null);
                setProcessStatus('completed');
                setProcessMessage('LRR URL processing completed.');
                stopPolling();
                clearSavedRunId();
                return 'completed';
            }

            if (status.isFailed) {
                const details = await getLrrRunDetails(currentRunId).catch(() => null);
                setProcessStatus('failed');
                setProcessMessage(
                    buildRunSummaryMessage(currentRunId, details, statusLabel) ||
                    status.message ||
                    'LRR URL processing failed.'
                );
                stopPolling();
                clearSavedRunId();
                return 'failed';
            }

            setProcessStatus('in_progress');
            const details = await getLrrRunDetails(currentRunId).catch(() => null);
            setProcessMessage(
                buildRunSummaryMessage(currentRunId, details, statusLabel) ||
                status.message ||
                `LRR URL processing is in progress (${statusLabel}).`
            );
            return 'in_progress';
        } catch (statusError: any) {
            setProcessStatus('failed');
            setProcessMessage(statusError?.message || 'Failed to fetch LRR process status.');
            stopPolling();
            return 'failed';
        }
    }, [buildRunSummaryMessage, clearSavedRunId, stopPolling]);

    const startPolling = useCallback((currentRunId: string) => {
        stopPolling();
        pollIntervalRef.current = setInterval(() => {
            void pollStatusOnce(currentRunId);
        }, LRR_POLL_INTERVAL_MS);
    }, [pollStatusOnce, stopPolling]);

    useEffect(() => {
        const fetchData = async () => {
            if (reduxData) return;
            setLoading(true);
            setError(null);
            try {
                const response = await getPlanArtifact(planNumber, 'lrr');
                const rawDetails = response.data?.internet_search_data || response.data?.lrr_details || [];

                const formattedData = rawDetails.map((item: any) => ({
                    riskName: item.search_combination?.['UoT Risk Type'] || item.riskName || item['Risk Name'] || 'Unknown',
                    regulatoryMandate: item.search_result || item.regulatoryMandate || item['Regulatory Mandate'] || 'No mandate found.',
                    confidenceScore: item.confidenceScore || item['Confidence Score'] || '1',
                    aiRationale: item.aiRationale || item['AI Rationale'] || 'Extracted from search results.'
                }));

                dispatch(setArtifactData({ planNumber, artifactType: 'lrr', data: formattedData }));
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Failed to fetch LRR details.';
                setError(message);
                console.warn('Failed to fetch LRR details.', err);
            } finally {
                setLoading(false);
            }
        };

        if (planNumber) {
            void fetchData();
        }
    }, [planNumber, reduxData, dispatch]);

    useEffect(() => {
        const savedRunId = localStorage.getItem(getStorageKey());
        if (!savedRunId) {
            return;
        }

        setRunId(savedRunId);
        setProcessStatus('in_progress');
        setProcessMessage('LRR URL processing is in progress. Checking latest status...');
        void pollStatusOnce(savedRunId);
        startPolling(savedRunId);

        return () => {
            stopPolling();
        };
    }, [getStorageKey, pollStatusOnce, startPolling, stopPolling]);

    const handleSubmitUrls = async (event: React.FormEvent) => {
        event.preventDefault();

        const urls = urlInput
            .split(',')
            .map((url) => url.trim())
            .filter((url) => Boolean(url));

        if (urls.length === 0) {
            setProcessStatus('failed');
            setProcessMessage('Please enter at least one URL.');
            return;
        }

        setIsSubmitting(true);
        setProcessStatus('in_progress');
        setProcessMessage('Starting LRR URL processing...');

        try {
            const response = await startLrrProcess(planNumber, urls, goalInput.trim() || DEFAULT_LRR_GOAL);
            if (!response.runId) {
                throw new Error('LRR process did not return a run ID.');
            }

            setRunId(response.runId);
            saveRunId(response.runId);
            setProcessMessage(response.message || 'LRR URL processing started.');

            const latest = await pollStatusOnce(response.runId);

            if (latest === 'in_progress') {
                startPolling(response.runId);
            }
        } catch (submitError: any) {
            setProcessStatus('failed');
            setProcessMessage(submitError?.message || 'Failed to start LRR URL processing.');
        } finally {
            setIsSubmitting(false);
        }
    };


    if (loading) {
        return <CardContent className={style.loadingContainer}>
            <Spinner />
        </CardContent>;
    }

    if (error && data.length === 0) {
        return <CardContent>
            <EmptyScopingState
                title="LRR"
                subtitle={<Text variant='negative'>Failed to load data: {error}</Text>}
            />
        </CardContent>;
    }

    return (
        <Stack direction="column" gap="lg" className={style.tabContainer}>
            <Text size='md' fontWeight="bold">LRR</Text>

            <form onSubmit={handleSubmitUrls}>
                <Stack direction="row" gap="sm" align="center" className={style.fullWidthRow}>
                    <FormGroup id="lrr-url-input-group" className={style.fullWidthFormGroup}>
                        <FormItem>
                            <TextInput
                                value={urlInput}
                                onChange={(event) => setUrlInput(event.target.value)}
                                placeholder="Enter URL(s), comma separated"
                                aria-label="LRR URLs"
                            />
                        </FormItem>
                    </FormGroup>
                    <FormGroup id="lrr-goal-input-group" className={style.fullWidthFormGroup}>
                        <FormItem>
                            <TextInput
                                value={goalInput}
                                onChange={(event) => setGoalInput(event.target.value)}
                                placeholder="Enter goal for LRR extraction"
                                aria-label="LRR Goal"
                            />
                        </FormItem>
                    </FormGroup>
                    <Button type="submit" variant="primary" loading={isProcessing} disabled={isProcessing}>
                        {isSubmitting ? 'Submitting...' : processStatus === 'in_progress' ? 'Processing...' : 'Submit'}
                    </Button>
                </Stack>
            </form>

            {runId && (
                <Text size='sm' variant='secondary'>Run ID: {runId}</Text>
            )}

            {processStatus === 'in_progress' && (
                <Text size='sm' variant='warning'>
                    {processMessage || 'LRR URL processing is in progress.'}
                </Text>
            )}

            {processStatus === 'completed' && (
                <Text size='sm' variant='positive'>
                    {processMessage || 'LRR URL processing completed.'}
                </Text>
            )}

            {processStatus === 'failed' && (
                <Text size='sm' variant='negative'>
                    {processMessage || 'LRR URL processing failed.'}
                </Text>
            )}

            {data.length === 0 && <Text>No LRR records found.</Text>}

            {data.length > 0 && (
                <div className={style.mediumScrollableContainer}>
                    <Table stickyHeader>
                        <thead>
                            <tr>
                                {LRR_COLUMNS.map((col) => (
                                    <th key={col.key} className={style.noWrapHeaderCell}>{col.label}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((row: any, rowIndex: number) => (
                                <tr key={`${row.riskName || 'risk'}-${rowIndex}`}>
                                    {LRR_COLUMNS.map((col, colIndex) => {
                                        const val = row[col.key];
                                        const displayVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : 'None';

                                        return (
                                            <td
                                                key={colIndex}
                                                className={style.tableCellEllipsis}
                                                title={displayVal}
                                            >
                                                {displayVal}
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            )}
        </Stack>
    );
};

export default LRRTab;
