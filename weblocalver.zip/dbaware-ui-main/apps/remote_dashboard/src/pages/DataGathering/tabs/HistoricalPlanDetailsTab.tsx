import React, { useState, useEffect } from 'react';
import { Stack, Text, Table, CardContent, Spinner } from '@wadk/ui';
import { useDispatch, useSelector } from 'react-redux';
import { getPlanArtifact } from '../../../api/dataGatheringClient';
import style from '../DataGathering.module.css';
import { EmptyScopingState } from '../../../components';
import { setArtifactData } from '../../../store/dataGatheringSlice';
import type { DataGatheringTabProps } from './interfaces';

const HISTORICAL_COLUMNS = [
    { label: 'Plan Item Title', key: 'Plan Item Title' },
    { label: 'Plan Year', key: 'Plan Year' },
    { label: 'Fieldwork Original Target Start Date', key: 'Fieldwork Original Target Start Date' },
    { label: 'Draft Reporting Revised Target Date', key: 'Draft Reporting Revised Target Date' },
    { label: 'Participating Office / Team', key: 'Participating Office / Team' },
    { label: 'Plan Item Number', key: 'Plan Item Number' },
    { label: 'UoT Core Process', key: 'UoT Core Process' },
    { label: 'AU Aggregation Point 4', key: 'AU Aggregation Point 4' },
    { label: 'AU Aggregation Point 5', key: 'AU Aggregation Point 5' },
    { label: 'AU Aggregation Point 3', key: 'AU Aggregation Point 3' },
    { label: 'Draft Reporting Actual Start Date', key: 'Draft Reporting Actual Start Date' },
    { label: 'Review Progress Comments', key: 'Review Progress Comments' },
    { label: 'Draft Reporting Original Target Start Date', key: 'Draft Reporting Original Target Start Date' },
    { label: 'Mandatory Review', key: 'Mandatory Review' },
    { label: 'AU Region', key: 'AU Region' },
    { label: 'Review Coverage Period End Date', key: 'Review Coverage Period End Date' },
    { label: 'UoT Countries', key: 'UoT Countries' },
    { label: 'Plan Item Original Target Start Date', key: 'Plan Item original Target Start date' },
    { label: 'Plan Item Focus (AFC/CT)', key: 'Plan Item Focus (AFC/CT)' },
    { label: 'AU Aggregation Point 2', key: 'AU Aggregation point 2' },
    { label: 'Draft Reporting Current Target Start Date', key: 'Draft Reporting Current Target Start Date' },
    { label: 'Plan Change Remarks', key: 'Plan Change Remarks' },
    { label: 'UoT LE', key: 'UoT LE' },
    { label: 'Lead Regional/Functional Head', key: 'Lead Regional/Functional Head' },
    { label: 'Plan Item Type', key: 'Plan Item Type' },
    { label: 'Fieldwork Revised Target Date', key: 'Fieldwork Revised Target Date' },
    { label: 'Plan Item Revised Target Date', key: 'Plan Item Revised Target Date' },
    { label: 'Report Publication Revised Target Date', key: 'Report Publication Revised Target Date' },
    { label: 'Report Sent Date', key: 'Report Sent Date' },
    { label: 'Coordinating Team Lead', key: 'Coordinating Team Lead' },
    { label: 'Description of Plan Item', key: 'Description of Plan Item' },
    { label: 'Plan Item Status', key: 'Plan Item Status' },
    { label: 'Application Coverage', key: 'Application Coverage' },
    { label: 'Review Coverage Period Start Date', key: 'Review Coverage Period Start Date' },
    { label: 'Report Publication Date', key: 'Report Publication Date' },
    { label: 'Report Publication Current Target Start Date', key: 'Report Publication Current Target Start Date' },
    { label: 'Review Lead', key: 'Review Lead' },
    { label: 'Fieldwork Actual Start Date', key: 'Fieldwork Actual Start Date' },
    { label: 'UoT LRR', key: 'UoT LRR' },
    { label: 'Report Number', key: 'Report Number' },
    { label: 'UoT Regions', key: 'UoT Regions' },
    { label: 'UoT Risk Type', key: 'UoT Risk Type' },
    { label: 'Report Publication Original Target Start Date', key: 'Report Publication Original Target Start Date' },
    { label: 'Lead Team', key: 'Lead Team' },
    { label: 'UoT OELs', key: 'UoT OELs' },
    { label: 'Plan Item Active Status', key: 'Plan Item Active Status' },
    { label: 'AU LE', key: 'AU LE' },
    { label: 'UoT KCs', key: 'UoT KCs' },
    { label: 'AU Countries', key: 'AU Countries' },
    { label: 'DMA Status', key: 'DMA Status' },
    { label: 'Plan Item Current Target Start Date', key: 'Plan Item Current Target Start Date' },
    { label: 'Plan Item Actual Start Date', key: 'Plan Item Actual Start Date' },
    { label: 'UoT Mandatory Test Requirements', key: 'UoT Mandatory Test Requirements' },
    { label: 'Finding Validation – Finding Ref.', key: 'Finding Validation – Finding Ref.' },
    { label: 'Fieldwork Current Target Start Date', key: 'Fieldwork Current Target Start Date' },
    { label: 'AU-RT-KC', key: 'AU-RT-KC' },
    { label: 'Final Report Sent', key: 'Final Report Sent' }
];

const HistoricalPlanDetailsTab: React.FC<DataGatheringTabProps> = ({ planNumber }) => {
    const dispatch = useDispatch();
    const reduxData = useSelector((state: any) => state.dataGathering?.artifacts?.[planNumber]?.['historical_plan_details']);
    const data = reduxData || [];
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            if (reduxData) return;
            setLoading(true);
            setError(null);
            try {
                const response = await getPlanArtifact(planNumber, 'historical_plan_details');
                const rawDetails = response.data?.historical_plan_details || [];
                dispatch(setArtifactData({ planNumber, artifactType: 'historical_plan_details', data: rawDetails }));
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Failed to fetch Historical Plan Details.';
                setError(message);
                console.warn('Failed to fetch Historical Plan Details.', err);
            } finally {
                setLoading(false);
            }
        };

        if (planNumber) {
            void fetchData();
        }
    }, [planNumber, reduxData, dispatch]);


    if (loading) {
        return <CardContent className={style.loadingContainer}>
            <Spinner />
        </CardContent>;
    }

    if (error && data.length === 0) {
        return <CardContent>
            <EmptyScopingState
                title="Historical Plan Details"
                subtitle={<Text variant='negative'>Failed to load data: {error}</Text>}
            />
        </CardContent>;
    }

    return (
        <Stack direction="column" gap="lg" className={style.tabContainer}>
            <Text size='md' fontWeight="bold">Historical Plan Details</Text>

            {data.length === 0 && <Text>No historical plans found.</Text>}

            {data.length > 0 && (
                <div className={style.mediumScrollableContainer}>
                    <Table stickyHeader>
                        <thead>
                            <tr>
                                {HISTORICAL_COLUMNS.map((col) => (
                                    <th key={col.key} className={style.noWrapHeaderCell}>{col.label}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((row: any, rowIndex: number) => (
                                <tr key={`${row['Plan Item Number'] || 'historical'}-${rowIndex}`}>
                                    {HISTORICAL_COLUMNS.map((col, colIndex) => {
                                        const val = row[col.key];

                                        if (col.key === 'AU-RT-KC' && Array.isArray(val)) {
                                            const formattedArrayStr = val.map((m: any) => `{'RT': '${m.RT || ''}', 'AU': '${m.AU || ''}', 'KC': '${m.KC || ''}'}`).join('; ');
                                            const displayVal = formattedArrayStr || 'None';
                                            return (
                                                <td
                                                    key={colIndex}
                                                    className={style.tableCellEllipsis}
                                                    title={displayVal}
                                                >
                                                    {displayVal}
                                                </td>
                                            );
                                        }

                                        const displayVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : 'None';
                                        return (
                                            <td
                                                key={colIndex}
                                                className={style.tableCellEllipsis}
                                                title={displayVal}
                                            >
                                                {displayVal}
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            )}
        </Stack>
    );
};

export default HistoricalPlanDetailsTab;
