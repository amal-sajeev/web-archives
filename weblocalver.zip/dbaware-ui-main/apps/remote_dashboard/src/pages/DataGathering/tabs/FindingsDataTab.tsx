import React, { useState, useEffect } from 'react';
import { Stack, Text, Table, Separator, CardContent, Spinner } from '@wadk/ui';
import { useDispatch, useSelector } from 'react-redux';
import { getPlanArtifact } from '../../../api/dataGatheringClient';
import style from '../DataGathering.module.css';
import { EmptyScopingState } from '../../../components';
import { setArtifactData } from '../../../store/dataGatheringSlice';
import type { DataGatheringTabProps } from './interfaces';

const OVERVIEW_COLUMNS = [
    { label: 'Finding ID', key: 'findingId' },
    { label: 'Finding Title', key: 'findingTitle' },
    { label: 'Status', key: 'findingStatus' },
    { label: 'Owner', key: 'findingOwner' },
    { label: 'Target Date', key: 'findingTd' },
    { label: 'Rating', key: 'rating' },
    { label: 'Regulator', key: 'regulator' },
    { label: 'Risk Taxonomy', key: 'riskTaxonomy' },
    { label: 'Country of Impact', key: 'countryOfImpact' },
    { label: 'Audit Number', key: 'auditNumber' },
    { label: 'Audit Name', key: 'auditName' },
    { label: 'Audit Type', key: 'auditType' },
    { label: 'CT1', key: 'ct1' }
];

const DETAIL_FIELDS = [
    { label: 'Audit Type', key: 'auditType' },
    { label: 'Audit Number', key: 'auditNumber' },
    { label: 'Audit Name', key: 'auditName' },
    { label: 'Audit Id', key: 'auditId' },
    { label: 'Finding Narrative', key: 'findingText' },
    { label: 'Finding Number', key: 'findingNumber' },
    { label: 'Status', key: 'findingStatus' },
    { label: 'Owner', key: 'findingOwner' },
    { label: 'Finding Owner Email', key: 'findingOwnerEmail' },
    { label: 'Finding Owner Delegate', key: 'findingOwnerDelegate' }
];

const FindingsDataTab: React.FC<DataGatheringTabProps> = ({ planNumber }) => {
    const dispatch = useDispatch();
    const reduxData = useSelector((state: any) => state.dataGathering?.artifacts?.[planNumber]?.['findings_details']);
    const data = reduxData || [];
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            if (reduxData) return;
            setLoading(true);
            setError(null);
            try {
                const response = await getPlanArtifact<any>(planNumber, 'findings_details');
                const findingsEntries = response.data?.findings_details;
                let rawData: any[] = [];
                if (Array.isArray(findingsEntries)) {
                    rawData = findingsEntries.flatMap((entry: any) => entry?.responsePayload || []);
                } else if (findingsEntries?.responsePayload) {
                    rawData = findingsEntries.responsePayload;
                }
                dispatch(setArtifactData({ planNumber, artifactType: 'findings_details', data: rawData }));
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Failed to fetch Findings details.';
                setError(message);
                console.warn('Failed to fetch Findings details.', err);
            } finally {
                setLoading(false);
            }
        };

        if (planNumber) {
            void fetchData();
        }
    }, [planNumber, reduxData, dispatch]);


    if (loading) {
        return <CardContent className={style.loadingContainer}>
            <Spinner />
        </CardContent>;
    }

    if (error && data.length === 0) {
        return <CardContent>
            <EmptyScopingState
                title="Findings Data"
                subtitle={<Text variant='negative'>Failed to load data: {error}</Text>}
            />
        </CardContent>;
    }

    return (
        <Stack direction="column" gap="xl" className={style.findingsOuterContainer}>
            <Stack direction="column" gap="md">
                <Text size='md' fontWeight="bold">Findings Overview</Text>

                {data.length === 0 ? (
                    <Text>No Findings records found.</Text>
                ) : (
                    <div className={style.mediumScrollableContainer}>
                        <Table stickyHeader>
                            <thead>
                                <tr>
                                    {OVERVIEW_COLUMNS.map((col) => (
                                        <th key={col.key} className={style.noWrapHeaderCell}>{col.label}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {data.map((row: any, rowIndex: number) => (
                                    <tr key={`${row.findingId || 'finding'}-${rowIndex}`}>
                                        {OVERVIEW_COLUMNS.map((col, colIndex) => {
                                            const val = row[col.key];
                                            const displayVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : '';

                                            return (
                                                <td key={colIndex} className={style.tableCellEllipsis} title={displayVal}>
                                                    {displayVal}
                                                </td>
                                            );
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    </div>
                )}
                <Text fontWeight="bold">Total findings: {data.length}</Text>
            </Stack>

            <Separator placement="horizontal" />

            <Stack direction="column" gap="md">
                <Text size='md' fontWeight="bold">Finding Details</Text>

                {data.map((finding: any, idx: number) => (
                    <details key={`${finding.findingId || 'finding-detail'}-${idx}`} className={style.findingDetailItem}>
                        <summary className={style.findingDetailSummary}>
                            Finding {idx + 1}: {finding.findingId}
                        </summary>
                        <div className={style.contentSectionFindingDataContainer}>
                            <Table>
                                <thead>
                                    <tr>
                                        <th>Field</th>
                                        <th>Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {DETAIL_FIELDS.map((field) => {
                                        const val = finding[field.key];
                                        const displayVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : '';
                                        return (
                                            <tr key={field.key}>
                                                <td className={style.fieldLabelCell}>{field.label}</td>
                                                <td className={style.preWrapCell}>{displayVal}</td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </Table>
                        </div>
                    </details>
                ))}
            </Stack>
        </Stack>
    );
};

export default FindingsDataTab;
