import React, { useState, useEffect } from 'react';
import { Stack, Text, Table, CardContent, Spinner } from '@wadk/ui';
import { useDispatch, useSelector } from 'react-redux';
import { getPlanArtifact } from '../../../api/dataGatheringClient';
import style from '../DataGathering.module.css';
import { EmptyScopingState } from '../../../components';
import { setArtifactData } from '../../../store/dataGatheringSlice';
import type { DataGatheringTabProps } from './interfaces';

const AlternativeAndNoCoverageTab: React.FC<DataGatheringTabProps> = ({ planNumber }) => {
    const dispatch = useDispatch();
    const reduxData = useSelector((state: any) => state.dataGathering?.artifacts?.[planNumber]?.['alc_nlac']);
    const data = reduxData || [];
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            if (reduxData) return;
            setLoading(true);
            setError(null);
            try {
                const response = await getPlanArtifact(planNumber, 'alc_nlac');
                const rawDetails = response.data?.alc_nalc_details || [];
                dispatch(setArtifactData({ planNumber, artifactType: 'alc_nlac', data: rawDetails }));
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Failed to fetch ALC/NLAC details.';
                setError(message);
                console.warn('Failed to fetch ALC/NLAC details.', err);
            } finally {
                setLoading(false);
            }
        };

        if (planNumber) {
            void fetchData();
        }
    }, [planNumber, reduxData, dispatch]);

    if (loading) {
        return <CardContent className={style.loadingContainer}>
            <Spinner />
        </CardContent>;
    }

    if (error && data.length === 0) {
        return <CardContent>
            <EmptyScopingState
                title="Alternative and No Coverage"
                subtitle={<Text variant='negative'>Failed to load data: {error}</Text>}
            />
        </CardContent>;
    }

    return (
        <Stack direction="column" gap="lg" className={style.tabContainer}>
            <Text size='md' fontWeight="bold">Alternative and No Coverage</Text>

            <div className={style.tableTallContainer}>
                <Table stickyHeader={true}>
                    <thead>
                        <tr>
                            <th>Risk Type</th>
                            <th>Risk Type ID</th>
                            <th>Coverage Year</th>
                            <th>Coverage Name</th>
                            <th>Coverage Description</th>
                            <th>Coverage Group</th>
                            <th>Region Name</th>
                            <th>Evidence Provided</th>
                            <th>Follow-up Required</th>
                            <th>AU Type</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((item: any, idx: number) => {
                            const riskType = item['RT'] || '';
                            const riskTypeId = item['RT_ID'] || '';
                            const coverageYear = item['Alternative coverage plan year'] || item['Noncoverage plan year'] || '';
                            const coverageName = item['Alternative coverage Name'] || item['Noncoverage Name'] || '';
                            const coverageDescription = item['Alternative coverage description'] || item['Noncoverage description'] || '';
                            const coverageGroup = item['AU Aggregation point 4'] || item['AU Aggregation point 3'] || item['AU Aggregation point 2'] || '';
                            const regionName = item['Region Name'] || '';
                            const evidenceProvided = item['Alternative coverage evidence yes/no'] || item['Noncoverage evidence yes/no'] || '';
                            const followUpRequired = item['Follow-up required'] || '';
                            const auType = item['AU Type'] || '';
                            const status = item['Status'] || '';

                            return (
                                <tr key={`${riskTypeId}-${coverageName}-${idx}`}>
                                    <td>{riskType}</td>
                                    <td>{riskTypeId}</td>
                                    <td>{coverageYear}</td>
                                    <td>{coverageName}</td>
                                    <td>{coverageDescription}</td>
                                    <td>{coverageGroup}</td>
                                    <td>{regionName}</td>
                                    <td>{evidenceProvided}</td>
                                    <td>{followUpRequired}</td>
                                    <td>{auType}</td>
                                    <td>{status}</td>
                                </tr>
                            );
                        })}
                        {data.length === 0 && (
                            <tr>
                                <td colSpan={11} className={style.centerText}>No results found.</td>
                            </tr>
                        )}
                    </tbody>
                </Table>
            </div>
        </Stack>
    );
};

export default AlternativeAndNoCoverageTab;
