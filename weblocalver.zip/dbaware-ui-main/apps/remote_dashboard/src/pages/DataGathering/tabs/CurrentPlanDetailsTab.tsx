import React, { useState, useEffect } from 'react';
import { Stack, Text, Separator, Table, CardContent, Card, CardHeader, CardTitle, Spinner } from '@wadk/ui';
import { useDispatch, useSelector } from 'react-redux';
import { getPlanArtifact } from '../../../api/dataGatheringClient';
import style from '../DataGathering.module.css';
import { EmptyScopingState } from '../../../components';
import { setArtifactData } from '../../../store/dataGatheringSlice';
import type { DataGatheringTabProps } from './interfaces';

const DetailItem = ({ label, value }: { label: string; value: React.ReactNode }) => (
    <Text><strong>{label}:</strong> {value || '-'}</Text>
);

const CurrentPlanDetailsTab: React.FC<DataGatheringTabProps> = ({ planNumber }) => {
    const dispatch = useDispatch();
    const data = useSelector((state: any) => state.dataGathering?.artifacts?.[planNumber]?.['current_details']);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            if (data) return;
            setLoading(true);
            setError(null);
            try {
                const response = await getPlanArtifact(planNumber, 'current_details');
                const planDetails = response.data?.plan_details;

                if (planDetails) {
                    const rawMappings = planDetails['AU-RT-KC'] || response.data?.mappings || [];
                    const formattedMappings = rawMappings.map((m: any) => ({
                        riskTypeId: m.RT || m.riskTypeId || '',
                        assessmentUnit: m.AU || m.assessmentUnit || '',
                        keyControls: m.KC || m.keyControls || ''
                    }));

                    const parsedData = {
                        reviewId: planDetails['Plan Item Number'] || planNumber,
                        reviewTitle: planDetails['Plan Item Title'] || planDetails['Review Title'] || '',
                        reviewDescription: planDetails['Description of Plan Item'] || planDetails['Review Description'] || '',
                        planItemType: planDetails['Plan Item Type'] || 'Review',
                        uotCoreProcess: planDetails['UoT Core Process'] || '',
                        planYear: planDetails['Plan Year'] || '',
                        leadTeam: planDetails['Participating Office / Team'] || planDetails['Lead Team'] || '',
                        focusArea: planDetails['Plan Item Focus (AFC/CT)'] || planDetails['Focus Area'] || '',
                        assessmentUnit: planDetails['AU Aggregation point 2'] || planDetails['Assessment Unit'] || '',
                        uotLe: planDetails['UoT LE'] || '',
                        leadRegionalHead: planDetails['Lead Regional/Functional Head'] || '',
                        uotRegions: planDetails['AU Region'] || planDetails['UoT Regions'] || '',
                        uotCountries: planDetails['UoT Countries'] || '',
                        uotRiskType: planDetails['Risk Types'] || planDetails['UoT Risk Type'] || '',
                        uotKcs: planDetails['UoT KCs'] || '',
                        mappings: formattedMappings
                    };
                    dispatch(setArtifactData({ planNumber, artifactType: 'current_details', data: parsedData }));
                } else {
                    throw new Error('Invalid API response format');
                }
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Failed to fetch Current Plan Details.';
                setError(message);
                console.warn('Failed to fetch current plan details.', err);
            } finally {
                setLoading(false);
            }
        };

        if (planNumber) {
            void fetchData();
        }
    }, [planNumber, data, dispatch]);

    if (loading) {
        return (
            <CardContent className={style.loadingContainer}>
                <Spinner />
            </CardContent>
        );
    }

    if (error && !data) {
        return <CardContent>
            <EmptyScopingState
                title="Current Plan Details"
                subtitle={<Text variant='negative'>Failed to load data: {error}</Text>}
            />
        </CardContent>;
    }

    if (!data) {
        return null;
    }

    return (
        <Stack direction="column" gap="lg" className={style.tabContainer}>
            <Text size='md' fontWeight="bold">Current Plan Details</Text>
            <div className={style.dataContentContainer}>
                <div className={style.detailsGrid}>
                    <Card outlined radius="md">
                        <CardHeader>
                            <CardTitle content="Review Summary" />
                        </CardHeader>
                        <CardContent>
                            <Stack direction="column" gap="md">
                                <DetailItem label="Review ID" value={data.reviewId} />
                                <DetailItem label="Review Title" value={data.reviewTitle} />
                                <DetailItem label="Review Description" value={data.reviewDescription} />
                                <DetailItem label="Plan Item Type" value={data.planItemType} />
                                <DetailItem label="UoT Core Process" value={data.uotCoreProcess} />
                                <DetailItem label="Plan Year" value={data.planYear} />
                                <DetailItem label="Lead Team" value={data.leadTeam} />
                            </Stack>
                        </CardContent>
                    </Card>

                    <Card outlined radius="md">
                        <CardHeader>
                            <CardTitle content="Additional Details" />
                        </CardHeader>
                        <CardContent>
                            <Stack direction="column" gap="md">
                                <DetailItem label="Focus Area" value={data.focusArea} />
                                <DetailItem label="Assessment Unit" value={data.assessmentUnit} />
                                <DetailItem label="UoT LE" value={data.uotLe} />
                                <DetailItem label="Lead Regional/Functional Head" value={data.leadRegionalHead} />
                                <DetailItem label="UoT Regions" value={data.uotRegions} />
                                <DetailItem label="UoT Countries" value={data.uotCountries} />
                                <DetailItem label="UoT Risk Type" value={data.uotRiskType} />
                                <DetailItem label="UoT KCs" value={data.uotKcs} />
                            </Stack>
                        </CardContent>
                    </Card>
                </div>

                <Separator placement="horizontal" />

                <Stack direction="column" gap="md">
                    <Text fontWeight="bold" className={style.sectionTopMargin}>Risk Type / Assessment Unit / Key Control Map</Text>

                    <div className={style.fixedTableHeightContainer}>
                        <Table stickyHeader={true}>
                            <thead>
                                <tr>
                                    <th>Risk Type ID</th>
                                    <th>Assessment Unit</th>
                                    <th>Key Controls</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.mappings?.map((mapping: any, idx: number) => (
                                    <tr key={`${mapping.riskTypeId}-${mapping.assessmentUnit}-${idx}`}>
                                        <td>{mapping.riskTypeId}</td>
                                        <td>{mapping.assessmentUnit}</td>
                                        <td>{mapping.keyControls}</td>
                                    </tr>
                                ))}
                                {data.mappings?.length === 0 && (
                                    <tr>
                                        <td colSpan={3} className={style.centerText}>No results found.</td>
                                    </tr>
                                )}
                            </tbody>
                        </Table>
                    </div>
                </Stack>
            </div>

        </Stack>
    );
};

export default CurrentPlanDetailsTab;
