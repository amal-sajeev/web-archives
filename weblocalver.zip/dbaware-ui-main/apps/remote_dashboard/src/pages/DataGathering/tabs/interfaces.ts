export interface DataGatheringTabProps {
    planNumber: string;
}

export interface PolicyDocumentData {
    index: number;
    documentName: string;
    fileType: string;
    documentUrl: string;
    gsUri: string;
    pageNumber?: number;
}

export type LrrProcessStatus = 'idle' | 'in_progress' | 'completed' | 'failed';
