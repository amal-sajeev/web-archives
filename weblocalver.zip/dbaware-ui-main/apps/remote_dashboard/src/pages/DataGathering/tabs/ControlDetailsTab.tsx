import React, { useState, useEffect } from 'react';
import { Stack, Text, Table, CardContent, Spinner } from '@wadk/ui';
import { useDispatch, useSelector } from 'react-redux';
import { getPlanArtifact } from '../../../api/dataGatheringClient';
import style from '../DataGathering.module.css';
import { EmptyScopingState } from '../../../components';
import { setArtifactData } from '../../../store/dataGatheringSlice';
import type { DataGatheringTabProps } from './interfaces';

type RowData = {
    inventory?: Record<string, any>;
    definition?: Record<string, any>;
    objective?: Record<string, any>;
};

const CONTROL_COLUMNS = [
    { label: 'Assessment Unit', get: (row: RowData) => row.inventory?.assessmentUnitDer },
    { label: 'Risk ID', get: (row: RowData) => row.inventory?.riskId },
    { label: 'Control Definition Number', get: (row: RowData) => row.inventory?.controlDefinitionNumber },
    { label: 'External Reference Id', get: (row: RowData) => [row.inventory?.externalReferenceId, row.objective?.externalReferenceId].filter(Boolean).join(' | ') },
    { label: 'Entity', get: (row: RowData) => row.inventory?.entity },
    { label: 'Entity Class', get: (row: RowData) => row.inventory?.entityClass },
    { label: 'Inventory', get: (row: RowData) => row.inventory?.inventory },
    { label: 'Control Name', get: (row: RowData) => row.inventory?.controlDefinitionName },
    { label: 'Control Status', get: (row: RowData) => row.inventory?.controlDefinitionStatus },
    { label: 'Process', get: (row: RowData) => row.inventory?.process },
    { label: 'Classification', get: (row: RowData) => row.inventory?.classification },
    { label: 'Design Control Function', get: (row: RowData) => row.inventory?.designControlFunction },
    { label: 'Design Control Owner', get: (row: RowData) => row.inventory?.designControlOwner },
    { label: 'Market Conduct Rel Control', get: (row: RowData) => row.inventory?.marketConductRelControl?.toString().toUpperCase() },
    { label: 'Control How', get: (row: RowData) => row.inventory?.controlHow },
    { label: 'Control What', get: (row: RowData) => row.inventory?.controlWhat },
    { label: 'Control Why', get: (row: RowData) => row.inventory?.controlWhy },
    { label: 'Control Description', get: (row: RowData) => row.inventory?.controlDescription },
    { label: 'Control Instance Number', get: (row: RowData) => row.inventory?.controlInstanceNumber },
    { label: 'Control Instance Name', get: (row: RowData) => row.inventory?.controlInstanceName },
    { label: 'Operating Control Owner', get: (row: RowData) => row.inventory?.operatingControlOwner },
    { label: 'Control Operating Function Ubr', get: (row: RowData) => row.inventory?.controlOperatingFunctionUbr },
    { label: 'Control Operating Function', get: (row: RowData) => row.inventory?.controlOperatingFunction },
    { label: 'Control Operating Function Ubr Code', get: (row: RowData) => row.inventory?.controlOperatingFunctionUbrCode },
    { label: 'Control Frequency', get: (row: RowData) => [row.inventory?.controlFrequency, row.inventory?.controlWhen].filter(Boolean).join(' | ') },
    { label: 'Key Control', get: (row: RowData) => row.inventory?.keyControl?.toString().toUpperCase() },
    { label: 'Vendor', get: (row: RowData) => row.inventory?.vendor },
    { label: 'Risk Type Level2', get: (row: RowData) => row.inventory?.riskTypeLevel2 },
    { label: 'Risk Type Level3', get: (row: RowData) => row.inventory?.riskTypeLevel3 },
    { label: 'Risk Type', get: (row: RowData) => row.inventory?.riskTypeLevel4 },
    { label: 'Approval Status', get: (row: RowData) => row.inventory?.approvalStatus },
    { label: 'Control Instance State', get: (row: RowData) => row.inventory?.controlInstanceState },
    { label: 'Control Location', get: (row: RowData) => row.inventory?.controlWhere },
    { label: 'Control Owner', get: (row: RowData) => row.inventory?.controlWho },
    { label: 'Control Scope', get: (row: RowData) => row.inventory?.controlScope },
    { label: 'Attestation Name', get: (row: RowData) => row.inventory?.attestationName },
    { label: 'Americas Relevant', get: (row: RowData) => row.inventory?.americasRelevant?.toString().toUpperCase() },
    { label: 'Control Design Owner Delegate', get: (row: RowData) => row.inventory?.controlDesignOwnerDelegate },
    { label: 'Design Owning Unit Dco', get: (row: RowData) => row.inventory?.designOwningUnitDco },
    { label: 'Control Definition Rtc', get: (row: RowData) => row.inventory?.controlDefinitionRtc },
    { label: 'Division', get: (row: RowData) => row.inventory?.division },
    { label: 'Sub Division', get: (row: RowData) => row.inventory?.subDivision },
    { label: 'Compliance Score', get: (row: RowData) => row.inventory?.complianceScore },
    { label: 'Report Ctrl Operating Function Name', get: (row: RowData) => row.inventory?.reportCtrlOperatingFunctionName },
    { label: 'Weighting', get: (row: RowData) => row.inventory?.weighting },
    { label: 'Sync With Entity Owner', get: (row: RowData) => row.inventory?.syncWithEntityOwner?.toString().toUpperCase() },
    { label: 'Design Effectiveness Status', get: (row: RowData) => row.inventory?.designEffectivenessStatus },
    { label: 'Recertification Due Date', get: (row: RowData) => [row.inventory?.recertificationDueDate, row.objective?.recertificationDueDate].filter(Boolean).join(' | ') },
    { label: 'Control Inst Sys Created On', get: (row: RowData) => row.inventory?.controlInstSysCreatedOn },
    { label: 'Control Inst Sys Updated On', get: (row: RowData) => row.inventory?.controlInstSysUpdatedOn },
    { label: 'Control Def Sys Created On', get: (row: RowData) => row.inventory?.controlDefSysCreatedOn },
    { label: 'Control Def Sys Updated On', get: (row: RowData) => row.inventory?.controlDefSysUpdatedOn },
    { label: 'Risk Stmt Sys Created On', get: (row: RowData) => row.inventory?.riskStmtSysCreatedOn },
    { label: 'Risk Stmt Sys Updated On', get: (row: RowData) => row.inventory?.riskStmtSysUpdatedOn },
    { label: 'Snapshot Date', get: (row: RowData) => row.inventory?.snapshotDate },
    { label: 'Guid', get: (row: RowData) => row.inventory?.guid },
    { label: 'Sys Id', get: (row: RowData) => row.definition?.sysId },
    { label: 'Control Design Owner', get: (row: RowData) => row.definition?.controlDesignOwner },
    { label: 'Description', get: (row: RowData) => row.definition?.description },
    { label: 'Attestation', get: (row: RowData) => row.definition?.attestation },
    { label: 'Divisional Control Officer Dco', get: (row: RowData) => row.definition?.divisionalControlOfficerDco },
    { label: 'Control Objective Reference', get: (row: RowData) => row.definition?.controlObjectiveReference },
    { label: 'Control Objective Number', get: (row: RowData) => row.objective?.controlObjectiveNumber },
    { label: 'Control Objective Name', get: (row: RowData) => row.objective?.controlObjectiveName },
    { label: 'Control Objective Description', get: (row: RowData) => row.objective?.controlObjectiveDescription },
    { label: 'Control Objective Rtc', get: (row: RowData) => row.objective?.controlObjectiveRtc },
    { label: 'Reporting Control Design Function', get: (row: RowData) => row.definition?.reportingControlDesignFunction },
    { label: 'Governance Forum', get: (row: RowData) => row.definition?.governanceForum },
    { label: 'Control Automation', get: (row: RowData) => row.definition?.controlAutomation },
    { label: 'Certification Status', get: (row: RowData) => row.definition?.certificationStatus },
    { label: 'Market Conduct Control Definition', get: (row: RowData) => row.definition?.marketConductControlDefinition?.toString().toUpperCase() },
    { label: 'Sys Created On', get: (row: RowData) => row.definition?.sysCreatedOn },
    { label: 'Sys Updated On', get: (row: RowData) => row.definition?.sysUpdatedOn },
    { label: 'Risktype Der', get: (row: RowData) => row.definition?.risktypeDer },
    { label: 'Create Control Requirements', get: (row: RowData) => row.objective?.createControlRequirements?.toString().toUpperCase() },
    { label: 'Has Downstream Controls', get: (row: RowData) => row.objective?.hasDownstreamControls?.toString().toUpperCase() },
    { label: 'Has Imported', get: (row: RowData) => row.objective?.hasImported?.toString().toUpperCase() },
    { label: 'Auto Control Create', get: (row: RowData) => row.objective?.autoControlCreate?.toString().toUpperCase() },
    { label: 'Active', get: (row: RowData) => row.objective?.active?.toString().toUpperCase() },
    { label: 'Type Name', get: (row: RowData) => row.objective?.typeName },
    { label: 'Requirement Name', get: (row: RowData) => row.objective?.requirementName },
    { label: 'Intended Child', get: (row: RowData) => row.objective?.intendedChild },
    { label: 'Requirement Spoc', get: (row: RowData) => row.objective?.requirementSpoc },
    { label: 'Requirement Spoc Delegate', get: (row: RowData) => row.objective?.requirementSpocDelegate },
    { label: 'Supplemental Guidance', get: (row: RowData) => row.objective?.supplementalGuidance },
    { label: 'Mcs Relevant', get: (row: RowData) => row.objective?.mcsRelevant?.toString().toUpperCase() },
];

const ControlDetailsTab: React.FC<DataGatheringTabProps> = ({ planNumber }) => {
    const dispatch = useDispatch();
    const reduxData = useSelector((state: any) => state.dataGathering?.artifacts?.[planNumber]?.['control_details']);
    const data = reduxData || [];
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            if (reduxData) return;
            setLoading(true);
            setError(null);
            try {
                const response = await getPlanArtifact(planNumber, 'control_details');
                const rawData = response.data?.control_details?.included_kcs || [];
                dispatch(setArtifactData({ planNumber, artifactType: 'control_details', data: rawData }));
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Failed to fetch Control Details.';
                setError(message);
                console.warn('Failed to fetch Control Details.', err);
            } finally {
                setLoading(false);
            }
        };

        if (planNumber) {
            void fetchData();
        }
    }, [planNumber, reduxData, dispatch]);

    if (loading) {
        return <CardContent className={style.loadingContainer}>
            <Spinner />
        </CardContent>;
    }

    if (error && data.length === 0) {
        return <CardContent>
            <EmptyScopingState
                title="Current Control Details"
                subtitle={<Text variant='negative'>Failed to load data: {error}</Text>}
            />
        </CardContent>;
    }

    return (
        <Stack direction="column" gap="lg" className={style.tabContainer}>
            <Text size="md" fontWeight="bold">Control Details</Text>

            {data.length === 0 && <Text>No Control Details found.</Text>}

            {data.length > 0 && (
                <div className={style.mediumScrollableContainer}>
                    <Table stickyHeader>
                        <thead>
                            <tr>
                                {CONTROL_COLUMNS.map((col) => (
                                    <th key={col.label} className={style.noWrapHeaderCell}>{col.label}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((row: RowData, rowIndex: number) => (
                                <tr key={`${row.inventory?.controlDefinitionNumber || rowIndex}`}>
                                    {CONTROL_COLUMNS.map((col, colIndex) => {
                                        const rawVal = col.get(row);
                                        const displayVal = rawVal !== null && rawVal !== undefined && String(rawVal).trim() !== '' ? String(rawVal) : 'None';

                                        return (
                                            <td
                                                key={colIndex}
                                                className={style.tableCellEllipsis}
                                                title={displayVal}
                                            >
                                                {displayVal}
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            )}
        </Stack>
    );
};

export default ControlDetailsTab;
