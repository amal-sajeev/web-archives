import React, { useState, useEffect } from 'react';
import { Stack, Text, Table, CardContent, Spinner, Button } from '@wadk/ui';
import { useDispatch, useSelector } from 'react-redux';
import { getPlanArtifact } from '../../../api/dataGatheringClient';
import style from '../DataGathering.module.css';
import { EmptyScopingState } from '../../../components';
import { PlusSolid } from '@wadk/icons';
import { setArtifactData } from '../../../store/dataGatheringSlice';
import type { DataGatheringTabProps, PolicyDocumentData } from './interfaces';

const POLICY_COLUMNS = [
    { label: '#', key: 'index' },
    { label: 'Document Name', key: 'documentName' },
    { label: 'File Type', key: 'fileType' },
    { label: 'Document', key: 'documentUrl' }
];

const extractPageNumber = (data: any): number | undefined => {
    if (data.page_number && typeof data.page_number === 'number') {
        return data.page_number;
    }

    if (data.location_metadata?.page_number && typeof data.location_metadata.page_number === 'number') {
        return data.location_metadata.page_number;
    }

    if (data.source?.location_metadata?.page_number && typeof data.source.location_metadata.page_number === 'number') {
        return data.source.location_metadata.page_number;
    }

    return undefined;
};

const isPdfDocument = (documentName: string, contentType?: string): boolean => {
    if (contentType) {
        return contentType.includes('application/pdf') || contentType.includes('pdf');
    }
    return documentName.toLowerCase().endsWith('.pdf');
};

const PolicyTab: React.FC<DataGatheringTabProps> = ({ planNumber }) => {
    const dispatch = useDispatch();
    const reduxData = useSelector((state: any) => state.dataGathering?.artifacts?.[planNumber]?.['policy']);
    const data = reduxData || [];
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [pdfViewerOpen, setPdfViewerOpen] = useState(false);
    const [selectedPdfData, setSelectedPdfData] = useState<{ uri: string; pageNumber?: number; name: string } | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            if (Array.isArray(reduxData) && reduxData.length > 0) return;
            setLoading(true);
            setError(null);
            try {
                const response = await getPlanArtifact(planNumber, 'policy');
                const rawData = response.data || {};

                const uniqueDocs = new Map<string, PolicyDocumentData>();

                const fileTypeLabel = (type: string): string => {
                    const normalized = (type || '').toLowerCase();
                    if (normalized === 'policy') return 'Policy';
                    if (normalized === 'kod') return 'KOD';
                    if (normalized === 'procedure') return 'Procedure';
                    return type ? type.charAt(0).toUpperCase() + type.slice(1) : 'Document';
                };

                const addDocument = (rawDoc: any, fileType: string) => {
                    if (!rawDoc?.gs_uri || uniqueDocs.has(rawDoc.gs_uri)) return;
                    const documentName = rawDoc.document_name
                        ? String(rawDoc.document_name).replace(/\.pdf$/i, '').replace(/_/g, ' ')
                        : 'Unknown';
                    const isPdf = isPdfDocument(rawDoc.document_name || '');
                    const pageNumber = isPdf ? extractPageNumber(rawDoc) : undefined;

                    uniqueDocs.set(rawDoc.gs_uri, {
                        index: 0,
                        documentName,
                        fileType,
                        documentUrl: '',
                        gsUri: rawDoc.gs_uri,
                        pageNumber
                    });
                };

                if (Array.isArray(rawData.referenced_documents)) {
                    rawData.referenced_documents.forEach((doc: any) => {
                        addDocument(doc, fileTypeLabel(doc.document_type));
                    });
                }

                const processSection = (sectionKey: string, fileType: string) => {
                    const citations = rawData[sectionKey]?.citations || [];
                    citations.forEach((c: any) => addDocument(c, fileType));
                };

                processSection('relevant_policy', 'Policy');
                processSection('relevant_kod', 'KOD');
                processSection('relevant_procedure', 'Procedure');

                const formattedData: PolicyDocumentData[] = Array.from(uniqueDocs.values()).map((item, index) => {
                    const encodedUri = encodeURIComponent(item.gsUri);
                    const url = `/dbaware-ui/${planNumber}/docs/uri?document_uri=${encodedUri}`;
                    return {
                        ...item,
                        index: index + 1,
                        documentUrl: url
                    };
                });

                dispatch(setArtifactData({ planNumber, artifactType: 'policy', data: formattedData }));
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Failed to fetch Policy details.';
                setError(message);
                console.warn('Failed to fetch Policy details.', err);
            } finally {
                setLoading(false);
            }
        };

        if (planNumber) {
            void fetchData();
        }
    }, [planNumber, reduxData, dispatch]);

    if (loading) {
        return <CardContent className={style.loadingContainer}>
            <Spinner />
        </CardContent>;
    }

    if (error && data.length === 0) {
        return <CardContent>
            <EmptyScopingState
                title="Policy"
                subtitle={<Text variant='negative'>Failed to load data: {error}</Text>}
            />
        </CardContent>;
    }

    const handlePdfOpen = (row: PolicyDocumentData) => {
        const isPdf = isPdfDocument(row.documentName);

        if (isPdf) {
            setSelectedPdfData({
                uri: row.gsUri,
                pageNumber: row.pageNumber,
                name: row.documentName
            });
            setPdfViewerOpen(true);
        } else {
            window.open(row.documentUrl, '_blank', 'noopener,noreferrer');
        }
    };

    const getPdfViewerUrl = (uri: string, pageNumber?: number): string => {
        let url = `/pdfjs/web/viewer.html?file=${encodeURIComponent(uri)}`;

        if (pageNumber && pageNumber > 0) {
            url += `#page=${pageNumber}`;
        }

        return url;
    };

    return (
        <Stack direction="column" gap="lg" className={style.tabContainer}>
            {pdfViewerOpen && selectedPdfData && (
                <div className={style.pdfOverlay} role="dialog" aria-modal="true" aria-label="PDF document viewer">
                    <div className={style.pdfOverlayHeader}>
                        <Text fontWeight="bold">{selectedPdfData.name}</Text>
                        <Button
                            variant="link"
                            onClick={() => {
                                setPdfViewerOpen(false);
                                setSelectedPdfData(null);
                            }}
                            aria-label="Close PDF viewer"
                        >
                            Close
                        </Button>
                    </div>
                    <iframe
                        src={getPdfViewerUrl(selectedPdfData.uri, selectedPdfData.pageNumber)}
                        className={style.pdfViewerFrame}
                        title={selectedPdfData.name}
                    />
                </div>
            )}

            <Text size='md' fontWeight="bold">Policy</Text>

            {data.length === 0 && <Text>No Policy records found.</Text>}

            {data.length > 0 && (
                <div className={style.mediumScrollableContainer}>
                    <Table stickyHeader>
                        <thead>
                            <tr>
                                {POLICY_COLUMNS.map((col) => (
                                    <th key={col.key} className={style.noWrapHeaderCell}>{col.label}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((row: PolicyDocumentData, rowIndex: number) => (
                                <tr key={`${row.gsUri}-${rowIndex}`}>
                                    {POLICY_COLUMNS.map((col, colIndex) => {
                                        const val = row[col.key as keyof PolicyDocumentData];

                                        if (col.key === 'documentUrl') {
                                            return (
                                                <td key={colIndex} className={style.tableCellEllipsis} title={val as string}>
                                                    <Button
                                                        variant="link"
                                                        icon={<PlusSolid />}
                                                        onClick={() => handlePdfOpen(row)}
                                                        aria-label={`Open document ${row.documentName}`}
                                                    >
                                                        Open
                                                    </Button>
                                                </td>
                                            );
                                        }

                                        const displayVal = val !== null && val !== undefined && String(val).trim() !== '' ? String(val) : 'None';

                                        return (
                                            <td
                                                key={colIndex}
                                                className={style.tableCellEllipsis}
                                                title={displayVal}
                                            >
                                                {displayVal}
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            )}
        </Stack>
    );
};

export default PolicyTab;
