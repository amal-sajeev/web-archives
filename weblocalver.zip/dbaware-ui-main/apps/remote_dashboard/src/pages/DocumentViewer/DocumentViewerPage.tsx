import React, { useEffect, useMemo, useState } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { apiClient } from '../../api/apiClient';
import { SCOPING_AGENT_API_PATHS } from '../../api/scopingApiPaths';
import type {
    DocumentResponse,
    GatewayActionRequest,
} from './types';
import styles from './DocumentViewer.module.css';

const ARTIFACT_NAMES = new Set([
    'current_details',
    'lrr',
    'historical_plan_details',
    'policy',
    'alc_nlac',
    'findings_details',
    'control_details',
]);

const toRecord = (value: unknown): Record<string, any> | null => (
    value && typeof value === 'object' ? value as Record<string, any> : null
);

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const normalizeGatewayDocumentResponse = (raw: unknown): DocumentResponse => {
    const unwrapped = unwrapGatewayEnvelope(raw);
    const record = toRecord(unwrapped) ?? {};

    if ('content' in record || 'source' in record || 'type' in record) {
        return record as DocumentResponse;
    }

    const artifactData = toRecord(record.data) ?? record;
    const sourceUri = typeof record.source === 'string'
        ? record.source
        : record.source?.access_info?.uri;

    return {
        type: 'json',
        source: {
            content_type: 'application/json',
            document_name: record.artifact || record.document_name || 'artifact',
            access_info: {
                uri: sourceUri,
            },
            location_metadata: record.location_metadata,
        },
        content: artifactData,
    };
};

const DocumentViewerPage: React.FC = () => {
    const { planId, chunkId } = useParams<'planId' | 'chunkId'>();
    const [searchParams] = useSearchParams();
    const documentUri = searchParams.get('document_uri');
    const artifactParam = searchParams.get('artifact');
    const requestedPageNumber = searchParams.get('pageNumber');
    
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [documentData, setDocumentData] = useState<DocumentResponse | null>(null);
    const [pdfBlobUrl, setPdfBlobUrl] = useState<string | null>(null);

    useEffect(() => {
        let cancelled = false;

        const fetchDocument = async () => {
            if (!planId) {
                if (!cancelled) {
                    setError('Missing plan ID parameter');
                    setLoading(false);
                }
                return;
            }

            const isUriLookup = chunkId === 'uri';
            const artifactCandidate = (artifactParam || chunkId || '').toLowerCase();
            const isArtifactLookup = ARTIFACT_NAMES.has(artifactCandidate) || chunkId === 'artifact';

            if (isUriLookup && !documentUri) {
                if (!cancelled) {
                    setError('Missing document_uri parameter');
                    setLoading(false);
                }
                return;
            }

            try {
                if (!cancelled) {
                    setLoading(true);
                    setError(null);
                }

                let requestBody: GatewayActionRequest<Record<string, any>>;
                if (isArtifactLookup) {
                    requestBody = {
                        planNumber: planId,
                        action: 'GET_PLAN_ARTIFACT',
                        payload: { artifact: artifactCandidate },
                    };
                } else {
                    requestBody = {
                        planNumber: planId,
                        action: 'GET_CITATION_DOCUMENT',
                        payload: isUriLookup && documentUri
                            ? { document_uri: documentUri }
                            : { chunk_id: chunkId },
                    };
                }

                const response = await apiClient.post<unknown>(
                    SCOPING_AGENT_API_PATHS.gatewayActions,
                    requestBody
                );

                if (!cancelled) {
                    setDocumentData(normalizeGatewayDocumentResponse(response));
                }
            } catch (err: unknown) {
                console.error('Error fetching document:', err);
                const message = err instanceof Error ? err.message : 'Failed to load document';
                if (!cancelled) {
                    setError(message);
                }
            } finally {
                if (!cancelled) {
                    setLoading(false);
                }
            }
        };

        void fetchDocument();

        return () => {
            cancelled = true;
        };
    }, [planId, chunkId, documentUri, artifactParam]);

    useEffect(() => {
        setPdfBlobUrl((currentUrl) => {
            if (currentUrl) {
                URL.revokeObjectURL(currentUrl);
            }
            return null;
        });

        if (!documentData) return;
        
        const docName = documentData.source?.document_name || '';
        const isPdf = documentData.type === 'pdf' || documentData.source?.content_type === 'application/pdf' || docName.toLowerCase().endsWith('.pdf');
        const docContent = documentData.content;

        if (isPdf && typeof docContent === 'string') {
            let createdUrl: string | null = null;

            try {
                let base64Data = docContent;
                if (docContent.startsWith('data:')) {
                    base64Data = docContent.split(',')[1];
                }
                
                // Remove whitespaces/newlines just in case
                base64Data = base64Data.replace(/\s/g, '');

                const binaryString = window.atob(base64Data);
                const len = binaryString.length;
                const bytes = new Uint8Array(len);
                for (let i = 0; i < len; i++) {
                    bytes[i] = binaryString.charCodeAt(i);
                }
                
                const blob = new Blob([bytes], { type: 'application/pdf' });
                const url = URL.createObjectURL(blob);
                createdUrl = url;
                setPdfBlobUrl(url);
            } catch (err) {
                console.error("Failed to create PDF blob URL:", err);
            }

            return () => {
                if (createdUrl) {
                    URL.revokeObjectURL(createdUrl);
                }
            };
        }
    }, [documentData]);

    const normalizedContent = useMemo(() => {
        if (!documentData) {
            return {
                isJson: false,
                isPdf: false,
                parsedJson: null as unknown,
                docName: '',
                docUri: '',
            };
        }

        const docName = documentData.source?.document_name || '';
        const docUri = documentData.source?.access_info?.uri || '';
        const sourcePage = Number(documentData.source?.location_metadata?.page_number);
        const queryPage = Number(requestedPageNumber);
        const pageNumber = Number.isFinite(queryPage) && queryPage > 0
            ? queryPage
            : (Number.isFinite(sourcePage) && sourcePage > 0 ? sourcePage : undefined);
        const docContent = documentData.content;
        const isPdf = documentData.type === 'pdf' || documentData.source?.content_type === 'application/pdf' || docName.toLowerCase().endsWith('.pdf');

        let isJson = false;
        if (documentData.type === 'json' || documentData.source?.content_type === 'application/json' || docName.toLowerCase().endsWith('.json')) {
            isJson = true;
        } else if (!isPdf) {
            isJson = true;
        }

        let parsedJson = docContent;
        if (isJson && typeof docContent === 'string') {
            try {
                parsedJson = JSON.parse(docContent);
            } catch {
                parsedJson = docContent;
            }
        }

        return {
            isJson,
            isPdf,
            parsedJson,
            docName,
            docUri,
            pageNumber,
        };
    }, [documentData, requestedPageNumber]);

    const serializedJson = useMemo(() => {
        if (!normalizedContent.isJson) return '';
        const content = normalizedContent.parsedJson;
        return typeof content === 'object'
            ? JSON.stringify(content, null, 4)
            : String(content || '');
    }, [normalizedContent]);

    if (loading) {
        return <div className={styles.container} role="status" aria-live="polite">Loading document...</div>;
    }

    if (error) {
        return <div className={styles.container} role="alert">Error: {error}</div>;
    }

    if (!documentData) {
        return <div className={styles.container} role="status">No document found.</div>;
    }

    return (
        <div className={styles.container}>
            <div className={styles.header}>
                <h1>Document Viewer</h1>
                <h2 className={styles.planTitle}>Plan: {planId}</h2>
            </div>

            <div className={styles.metadataSection}>
                <h3>Source Document</h3>
                <div className={styles.metadataRow}>
                    <strong>Name:</strong> {normalizedContent.docName || 'Unknown'}
                </div>
                <div className={styles.metadataRow}>
                    <strong>URI:</strong> {normalizedContent.docUri || 'Unknown'}
                </div>
            </div>

            <div className={styles.contentSection}>
                <h3>Content</h3>
                <div className={styles.contentBox}>
                    {normalizedContent.isPdf ? (
                        pdfBlobUrl ? (
                            <iframe
                                src={normalizedContent.pageNumber ? `${pdfBlobUrl}#page=${normalizedContent.pageNumber}` : pdfBlobUrl}
                                className={styles.pdfViewer}
                                title={normalizedContent.docName || 'PDF document'}
                            />
                        ) : (
                            <div className={styles.loadingPdf}>Loading PDF viewer...</div>
                        )
                    ) : (
                        <pre className={styles.jsonViewer}>
                            {serializedJson}
                        </pre>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DocumentViewerPage;
