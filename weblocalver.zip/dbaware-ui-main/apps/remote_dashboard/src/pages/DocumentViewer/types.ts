export interface DocumentResponse {
  type?: string;
  source?: {
    content_type?: string;
    document_name?: string;
    access_info?: {
      uri?: string;
    };
    location_metadata?: Record<string, unknown>;
  };
  content?: unknown;
}

export type DocumentGatewayAction = 'GET_CITATION_DOCUMENT' | 'GET_PLAN_ARTIFACT';

export interface GatewayActionRequest<TPayload> {
  planNumber: string;
  action: DocumentGatewayAction;
  payload: TPayload;
}

export interface DocumentViewerRouteParams {
  planId?: string;
  chunkId?: string;
}
