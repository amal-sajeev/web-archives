import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  LeftSlot,
  Stack,
  RightSlot,
  OutlineButton
} from "@wadk/ui"
import { ScopingTabEnum } from '../../store/scopingSlice';
import EmptyScopingState from '../../components/EmptyScopingState/EmptyScopingState';
import { getDashboardRouteParams } from '../../utils';
import { resolveApproveButtonTextForStaticUser, fetchUserRoles } from '../../utils';
import { showErrorToast, showSuccessToast, ActionModal } from '../../components';
import { acceptFinalScopingDocument, downloadScopingDocument, generateScopingDocument, getScopingDocumentEditorHtml, updateScopingDocument, approveScopingDocumentAsRh, rejectScopingDocumentAsRh, forwardScopingDocumentToGh, approveScopingDocumentAsGh, rejectScopingDocumentAsGh } from '../../api/procedureClient';
import { AUTO_REDIRECT_DELAY_MS } from '../../constants';

import style from './FinalScopeDocumentPage.module.css';

type GenerationState = 'empty' | 'generating' | 'generated' | 'error';
type ApproveState = 'idle' | 'loading' | 'approved';

// Plans whose document was already loaded this session; the editor is restored on revisit.
const generatedPlanIds = new Set<string>();

const getErrorMessage = (error: unknown): string => {
  const data = (error as any)?.response?.data;
  if (typeof data === 'string' && data.trim()) {
    return data;
  }
  if (data && typeof data === 'object') {
    const message = (data as any).error ?? (data as any).message ?? (data as any).detail;
    if (typeof message === 'string' && message.trim()) {
      return message;
    }
  }
  return error instanceof Error && error.message ? error.message : 'Could not load the scoping document editor.';
};

const disableEmbeddedDownloadOption = (html: string): string => {
  if (!html.trim() || html.includes('dbaware-disable-embedded-download')) {
    return html;
  }

  const injection = `
<style id="dbaware-disable-embedded-download">
  .dbaware-download-hidden {
    display: none !important;
  }
</style>
<script>
  (function () {
    var lockDownloads = function () {
      var candidates = document.querySelectorAll('button, a, [role="button"]');
      candidates.forEach(function (node) {
        var text = (node.textContent || '').trim().toLowerCase();
        var id = ((node.id || '') + ' ' + (node.className || '')).toLowerCase();
        var looksLikeDownload = text.includes('download') || id.includes('download');
        if (!looksLikeDownload) {
          return;
        }

        node.classList.add('dbaware-download-hidden');
        node.setAttribute('aria-hidden', 'true');
      });
    };

    lockDownloads();
    var observer = new MutationObserver(lockDownloads);
    observer.observe(document.documentElement, { childList: true, subtree: true });
  })();
</script>`;

  if (html.includes('</head>')) {
    return html.replace('</head>', `${injection}\n</head>`);
  }
  if (html.includes('<body')) {
    return html.replace(/<body([^>]*)>/i, `<body$1>${injection}`);
  }
  return `${injection}${html}`;
};

interface RootState {
  scoping?: {
    nextAvailableActionsByPlan?: Record<string, string[]>;
    taskDefinitionKeyByPlan?: Record<string, string>;
  };
}

const TASK_DEFINITION_TO_TAB: Record<string, string> = {
  NOIR: 'noir',
  PRELIMINARY_RESEARCH: 'preliminary-research',
  DISCOVERY_WALKTHROUGH: 'discovery-walkthrough',
  DISCOVERY_WALKTHROUGH_AGENDA: 'discovery-walkthrough',
  SCOPE_RECOMMENDATION: 'scope-recommendation',
  TEST_STEPS: 'test-steps',
  SCOPING_DOCUMENT: 'final-scope-document',
  FINAL_SCOPE_DOCUMENT: 'final-scope-document',
  NOR: 'nor',
};

const FinalScopeDocumentPage: React.FC = () => {
  const [generationState, setGenerationState] = useState<GenerationState>('empty');
  const [approveState, setApproveState] = useState<ApproveState>('idle');
  const [approveButtonText, setApproveButtonText] = useState('Approve Result');
  const [downloadState, setDownloadState] = useState<'idle' | 'loading'>('idle');
  const [isRedirectingToNor, setIsRedirectingToNor] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  const [isForwarding, setIsForwarding] = useState(false);
  const [isActionsModalOpen, setIsActionsModalOpen] = useState(false);
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const [editorHtml, setEditorHtml] = useState('');
  const [editorError, setEditorError] = useState('');
  const redirectTimeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const editorFrameRef = React.useRef<HTMLIFrameElement | null>(null);
  const norAutoLoadAttemptedRef = React.useRef<Record<string, boolean>>({});
  const scopingDocAutoLoadAttemptedRef = React.useRef<Record<string, boolean>>({});

  const location = useLocation();
  const navigate = useNavigate();
  const { planId } = getDashboardRouteParams(location.pathname);
  const nextAvailableActionsByPlan = useSelector((state: RootState) => state.scoping?.nextAvailableActionsByPlan ?? {});
  const taskDefinitionKeyByPlan = useSelector((state: RootState) => state.scoping?.taskDefinitionKeyByPlan ?? {});

  const currentPlanNumber = String(planId || '').trim();
  const availableWorkflowActions = useMemo(() => {
    console.log('nextAvailableActionsByPlan:', nextAvailableActionsByPlan);
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];

    return Array.from(new Set(actionsFromPlan))
      .map((action: unknown) => String(action || '').trim().toUpperCase())
      .filter(Boolean);
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const taskDefinitionKey = useMemo(() => {
    const fromPlan = String(taskDefinitionKeyByPlan?.[currentPlanNumber] ?? '').trim();
    return fromPlan.replace(/[\s-]+/g, '_').toUpperCase();
  }, [taskDefinitionKeyByPlan, currentPlanNumber]);

  const currentTab = useMemo(() => {
    const pathSegments = location.pathname.split('/').filter(Boolean);
    const matched = pathSegments.find((segment) => Object.values(TASK_DEFINITION_TO_TAB).includes(segment));
    return matched || 'final-scope-document';
  }, [location.pathname]);

  const taskDefinitionTab = TASK_DEFINITION_TO_TAB[taskDefinitionKey] || '';
  const isCurrentTabActionable = !taskDefinitionTab || currentTab === taskDefinitionTab;

  const isScopingDocumentTaskDefinition =
    taskDefinitionKey === 'SCOPING_DOCUMENT' ||
    taskDefinitionKey === 'FINAL_SCOPE_DOCUMENT';
  const isNorTaskDefinition = taskDefinitionKey === 'NOR';

  const canApproveFinalScopingDocument =
    isCurrentTabActionable && (!isScopingDocumentTaskDefinition || availableWorkflowActions.includes('ACCEPT_FINAL_SCOPING_DOCUMENT'));
  const canGetScopingDocument = availableWorkflowActions.includes('GET_SCOPING_DOCUMENT');
  const canDownloadScopingDocument =
    !isScopingDocumentTaskDefinition || availableWorkflowActions.includes('DOWNLOAD_SCOPING_DOCUMENT');
  const canUpdateScopingDocument =
    isCurrentTabActionable && (!isScopingDocumentTaskDefinition || availableWorkflowActions.includes('UPDATE_SCOPING_DOCUMENT'));

  const SD_RH_APPROVE = 'SD_RH_APPROVE';
  const SD_RH_REJECT = 'SD_RH_REJECT';
  const SD_GH_FWD = 'SD_GH_FWD';
  const SD_GH_APPROVE = 'SD_GH_APPROVE';
  const SD_GH_REJECT = 'SD_GH_REJECT';

  const hasCapability = useCallback((permission: string) => (
    userRoles.includes(permission) || availableWorkflowActions.includes(permission)
  ), [userRoles, availableWorkflowActions]);

  // Scenario 1: Regional Head reviewer (approve / forward to GH / reject)
  const canRhApprove = hasCapability(SD_RH_APPROVE);
  const canRhReject = hasCapability(SD_RH_REJECT);
  const canGhForward = hasCapability(SD_GH_FWD);
  const isRhReviewer = canRhApprove || canRhReject || canGhForward;

  // Scenario 2: Global Head reviewer (approve / reject)
  const canGhApprove = hasCapability(SD_GH_APPROVE);
  const canGhReject = hasCapability(SD_GH_REJECT);
  const isGhReviewer = canGhApprove || canGhReject;

  const dispatchSync = useCallback((status: 'triggered' | 'completed' | 'failed', message: string) => {
    if (!planId) return;
    window.dispatchEvent(new CustomEvent('final-scope-document:sync', {
      detail: { planNumber: planId, status, message }
    }));
  }, [planId]);

  const handleLoadEditor = useCallback(async () => {
    if (!planId) {
      setEditorError('Plan number is not available.');
      setGenerationState('error');
      return;
    }

    if (!canGetScopingDocument) {
      setEditorError('GET_SCOPING_DOCUMENT is not available for this plan.');
      setGenerationState('empty');
      return;
    }

    setGenerationState('generating');
    setEditorError('');
    dispatchSync('triggered', 'Loading final scope document...');
    try {
      // GET_SCOPING_DOCUMENT permission: fetch the existing document via the GET action.
      const html = await getScopingDocumentEditorHtml(planId);
      setEditorHtml(disableEmbeddedDownloadOption(html));
      generatedPlanIds.add(planId);
      setGenerationState('generated');
      window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
        detail: { id: 'final-scope-document-loading' }
      }));
      dispatchSync('completed', 'Final scope document has been loaded.');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to load scoping document editor:', error);
      const message = getErrorMessage(error);
      setEditorError(message);
      setGenerationState('error');
      dispatchSync('failed', 'Final scope document generation failed.');
      showErrorToast('Failed to load scope document', message);
    }
  }, [dispatchSync, planId, canGetScopingDocument]);

  // Generate the scoping document (GENERATE_SCOPING_DOCUMENT) and then load it (GET_SCOPING_DOCUMENT).
  const handleGenerateEditor = useCallback(async () => {
    if (!planId) {
      setEditorError('Plan number is not available.');
      setGenerationState('error');
      return;
    }

    setGenerationState('generating');
    setEditorError('');
    dispatchSync('triggered', 'Generating final scope document...');
    try {
      const html = await generateScopingDocument(planId);
      setEditorHtml(disableEmbeddedDownloadOption(html));
      generatedPlanIds.add(planId);
      setGenerationState('generated');
      dispatchSync('completed', 'Final scope document has been generated.');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to generate scoping document:', error);
      const message = getErrorMessage(error);
      setEditorError(message);
      setGenerationState('error');
      dispatchSync('failed', 'Final scope document generation failed.');
      showErrorToast('Failed to generate scope document', message);
    }
  }, [dispatchSync, planId]);

  // The editor iframe cannot call the gateway itself; it asks this page to save or download.
  useEffect(() => {
    const handleEditorMessage = async (event: MessageEvent) => {
      const frameWindow = editorFrameRef.current?.contentWindow;
      const message = event.data;
      if (
        !frameWindow ||
        event.source !== frameWindow ||
        event.origin !== window.location.origin ||
        typeof message?.type !== 'string' ||
        !message.type.startsWith('scoping-document:')
      ) {
        return;
      }

      const reply = (body: Record<string, unknown>) =>
        frameWindow.postMessage(
          { type: 'scoping-document:result', requestId: message.requestId, ...body },
          window.location.origin
        );

      try {
        if (!planId) {
          throw new Error('Plan number is not available.');
        }

        if (message.type === 'scoping-document:save') {
          if (!canUpdateScopingDocument) {
            reply({ ok: false, error: 'UPDATE_SCOPING_DOCUMENT is not available for this plan.' });
            return;
          }
          const savedDocument = await updateScopingDocument(planId, message.document);
          reply({ ok: true, document: savedDocument });
        } else if (message.type === 'scoping-document:download') {
          reply({
            ok: false,
            error: 'Download PDF from the embedded editor is disabled. Use Download Result.'
          });
        }
      } catch (error) {
        console.error('Scoping document editor request failed:', error);
        reply({ ok: false, error: getErrorMessage(error) });
      }
    };

    window.addEventListener('message', handleEditorMessage);
    return () => window.removeEventListener('message', handleEditorMessage);
  }, [planId, canUpdateScopingDocument]);

  useEffect(() => {
    let cancelled = false;

    const loadApproveButtonText = async () => {
      const nextButtonText = await resolveApproveButtonTextForStaticUser();
      if (!cancelled) {
        setApproveButtonText(nextButtonText);
      }
    };

    loadApproveButtonText();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    const loadRoles = async () => {
      try {
        const roles = await fetchUserRoles();
        const normalizedRoles = roles.map((role) => String(role || '').trim().toUpperCase());
        if (!cancelled) {
          setUserRoles(normalizedRoles);
        }
      } catch {
        if (!cancelled) {
          setUserRoles([]);
        }
      }
    };

    loadRoles();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (isNorTaskDefinition) {
      return;
    }

    const handleGenerateFinalScopeDocument = () => {
      void handleGenerateEditor();
    };

    window.addEventListener('ai-chat:generate-final-scope-document', handleGenerateFinalScopeDocument as EventListener);
    return () => {
      window.removeEventListener('ai-chat:generate-final-scope-document', handleGenerateFinalScopeDocument as EventListener);
    };
  }, [handleGenerateEditor, isNorTaskDefinition]);

  useEffect(() => {
    if (!planId || !isNorTaskDefinition || generatedPlanIds.has(planId)) {
      return;
    }

    if (norAutoLoadAttemptedRef.current[planId]) {
      return;
    }

    norAutoLoadAttemptedRef.current[planId] = true;
    void handleLoadEditor();
  }, [handleLoadEditor, isNorTaskDefinition, planId]);

  // Auto-load the scoping document (GET_SCOPING_DOCUMENT) when the user has that permission,
  // e.g. on page refresh. This calls the GET action, not GENERATE.
  useEffect(() => {
    if (!planId || isNorTaskDefinition || !canGetScopingDocument || generatedPlanIds.has(planId)) {
      return;
    }

    if (scopingDocAutoLoadAttemptedRef.current[planId]) {
      return;
    }

    scopingDocAutoLoadAttemptedRef.current[planId] = true;
    void handleLoadEditor();
  }, [handleLoadEditor, isNorTaskDefinition, planId, canGetScopingDocument]);

  const handleApproveClick = useCallback(async () => {
    if (!canApproveFinalScopingDocument) {
      showErrorToast('Action not available', 'ACCEPT_FINAL_SCOPING_DOCUMENT is not available for this plan.');
      return;
    }

    if (!planId) {
      showErrorToast('Failed to approve final scope document', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await acceptFinalScopingDocument(planId);
      setApproveState('approved');
      setIsActionsModalOpen(false);
      showSuccessToast('Final scope document approved');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to approve final scope document:', error);
      setApproveState('idle');
      showErrorToast('Failed to approve final scope document', 'Could not approve the document.');
    }
  }, [canApproveFinalScopingDocument, planId]);

  /**
   * Generic approve handler for role-based approve actions that redirect to NoR.
   */
  const handleRoleApproveClick = useCallback(async (
    approveAction: (planNumber: string) => Promise<void>,
    permissionLabel: string,
  ) => {
    if (!planId) {
      showErrorToast('Failed to approve final scope document', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await approveAction(planId);
      setApproveState('approved');
      setIsActionsModalOpen(false);
      showSuccessToast('Final scope document approved');
    } catch (error) {
      console.error(`Failed to approve final scope document (${permissionLabel}):`, error);
      setApproveState('idle');
      showErrorToast('Failed to approve final scope document', 'Could not approve the document.');
    }
  }, [planId]);

  /**
   * Generic reject handler for role-based reject actions that keep the user on the same page.
   */
  const handleRoleRejectClick = useCallback(async (
    rejectAction: (planNumber: string) => Promise<void>,
    permissionLabel: string,
  ) => {
    if (!planId) {
      showErrorToast('Failed to reject final scope document', 'Plan number is not available.');
      return;
    }

    setIsRejecting(true);
    try {
      await rejectAction(planId);
      setApproveState('idle');
      setIsActionsModalOpen(false);
      showSuccessToast('Final scope document rejected');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error(`Failed to reject final scope document (${permissionLabel}):`, error);
      showErrorToast('Failed to reject final scope document', 'Could not reject the document.');
    } finally {
      setIsRejecting(false);
    }
  }, [planId]);

  /**
   * Forward to Global Head handler (Regional Head reviewer). Keeps the user on the same page.
   */
  const handleForwardToGhClick = useCallback(async () => {
    if (!planId) {
      showErrorToast('Failed to forward final scope document', 'Plan number is not available.');
      return;
    }

    setIsForwarding(true);
    try {
      await forwardScopingDocumentToGh(planId);
      setIsActionsModalOpen(false);
      showSuccessToast('Final scope document forwarded to Global Head');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to forward final scope document to GH:', error);
      showErrorToast('Failed to forward final scope document', 'Could not forward the document.');
    } finally {
      setIsForwarding(false);
    }
  }, [planId]);

  const isAnyActionBusy = approveState === 'loading' || isRejecting || isForwarding;
  const hasAnyAvailableAction = canApproveFinalScopingDocument || canRhApprove || canRhReject || canGhForward || canGhApprove || canGhReject;

  const actionItems = useMemo(() => {
    const items: Array<{
      key: string;
      label: string;
      onClick: () => void | Promise<void>;
      disabled?: boolean;
      loading?: boolean;
      tone?: 'default' | 'danger';
      emphasis?: 'primary' | 'default';
    }> = [];

    if (canApproveFinalScopingDocument) {
      items.push({
        key: 'accept',
        label: 'Accept result',
        onClick: handleApproveClick,
        loading: approveState === 'loading',
        disabled: isAnyActionBusy,
        emphasis: 'primary',
      });
    }

    if (isRhReviewer) {
      items.push({
        key: 'rh-approve',
        label: 'Approve Result',
        onClick: () => handleRoleApproveClick(approveScopingDocumentAsRh, 'SD_RH_APPROVE'),
        loading: approveState === 'loading',
        disabled: isAnyActionBusy || !canRhApprove,
        emphasis: canApproveFinalScopingDocument ? 'default' : 'primary',
      });
      items.push({
        key: 'gh-forward',
        label: 'Forward to GH',
        onClick: handleForwardToGhClick,
        loading: isForwarding,
        disabled: isAnyActionBusy || !canGhForward,
        emphasis: 'default',
      });
      items.push({
        key: 'rh-reject',
        label: 'Send Back',
        onClick: () => handleRoleRejectClick(rejectScopingDocumentAsRh, 'SD_RH_REJECT'),
        loading: isRejecting,
        disabled: isAnyActionBusy || !canRhReject,
        tone: 'danger',
        emphasis: 'default',
      });
      return items;
    }

    if (isGhReviewer) {
      items.push({
        key: 'gh-approve',
        label: 'Approve Result',
        onClick: () => handleRoleApproveClick(approveScopingDocumentAsGh, 'SD_GH_APPROVE'),
        loading: approveState === 'loading',
        disabled: isAnyActionBusy || !canGhApprove,
        emphasis: canApproveFinalScopingDocument ? 'default' : 'primary',
      });
      items.push({
        key: 'gh-reject',
        label: 'Send Back',
        onClick: () => handleRoleRejectClick(rejectScopingDocumentAsGh, 'SD_GH_REJECT'),
        loading: isRejecting,
        disabled: isAnyActionBusy || !canGhReject,
        tone: 'danger',
        emphasis: 'default',
      });
    }

    return items;
  }, [
    isRhReviewer,
    isGhReviewer,
    canApproveFinalScopingDocument,
    handleApproveClick,
    approveState,
    isRejecting,
    isForwarding,
    isAnyActionBusy,
    canRhApprove,
    canRhReject,
    canGhForward,
    canGhApprove,
    canGhReject,
    handleRoleApproveClick,
    handleRoleRejectClick,
    handleForwardToGhClick,
  ]);

  const hasRoleActions = actionItems.length > 0;

  const handleOpenActionsModal = useCallback(() => {
    setIsActionsModalOpen(true);
  }, []);

  useEffect(() => {
    if (planId && generatedPlanIds.has(planId)) {
      void handleLoadEditor();
    }
  }, [handleLoadEditor, planId]);

  const handleGenerateNorClick = useCallback(() => {
    if (planId) {
      navigate(`../${ScopingTabEnum.NOR}/${planId}`);
      return;
    }
    navigate(`../${ScopingTabEnum.NOR}`);
  }, [navigate, planId]);

  const handleDownloadClick = useCallback(async () => {
    if (!canDownloadScopingDocument) {
      showErrorToast('Action not available', 'DOWNLOAD_SCOPING_DOCUMENT is not available for this plan.');
      return;
    }

    if (!planId) {
      showErrorToast('Failed to download scope document', 'Plan number is not available.');
      return;
    }

    setDownloadState('loading');
    try {
      const blob = await downloadScopingDocument(planId);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `scoping_document_${planId}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      showSuccessToast('Scope document downloaded');
    } catch (error) {
      console.error('Failed to download scope document:', error);
      showErrorToast('Failed to download scope document', 'Could not download the PDF file.');
    } finally {
      setDownloadState('idle');
    }
  }, [canDownloadScopingDocument, planId]);

  useEffect(() => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (generationState === 'generated' && approveState === 'approved') {
      setIsRedirectingToNor(true);
      redirectTimeoutRef.current = setTimeout(() => {
        handleGenerateNorClick();
      }, AUTO_REDIRECT_DELAY_MS);
      return;
    }

    setIsRedirectingToNor(false);
  }, [approveState, generationState, handleGenerateNorClick]);

  useEffect(() => () => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }
  }, []);

  return (
    <div className={style.pageContainer}>
      <Card
        outlined
        radius="lg"
        raise="2-subtle"
      >
        <CardHeader >
          <LeftSlot>
            <Stack>
              <CardTitle content="Final Scope Document" />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && (
            <RightSlot>
              <>
                <Stack direction="row" align="center" justifyContent="end" gap="xs">
                  {approveState === 'approved' ? (
                    <OutlineButton disabled>
                      Redirecting to Generate NoR...
                    </OutlineButton>
                  ) : (
                    <OutlineButton
                      onClick={handleOpenActionsModal}
                      disabled={isAnyActionBusy || !hasAnyAvailableAction}
                    >
                      Actions
                    </OutlineButton>
                  )}
                  <OutlineButton
                    onClick={handleDownloadClick}
                    loading={downloadState === 'loading'}
                    disabled={downloadState === 'loading' || !canDownloadScopingDocument}
                  >
                    Download Result
                  </OutlineButton>
                </Stack>
              </>
            </RightSlot>
          )}
        </CardHeader>

        <ActionModal
          opened={isActionsModalOpen}
          title="Final Scope Document Actions"
          subtitle="Select an action to continue."
          actions={actionItems}
          emptyMessage="No action required at this stage."
          onClose={() => setIsActionsModalOpen(false)}
        />

        {generationState === 'empty' || generationState === 'generating' ? (
          <CardContent>
            <EmptyScopingState />
          </CardContent>
        ) : generationState === 'error' ? (
          <CardContent>
            <Stack gap="xs">
              <div role="alert">{editorError}</div>
              <Stack direction="row" gap="xs">
                <OutlineButton onClick={handleLoadEditor}>Retry</OutlineButton>
              </Stack>
            </Stack>
          </CardContent>
        ) : (
          <CardContent>
            {/* The editor's built-in Edit/Save/Download PDF controls need scripts, so the iframe is not sandboxed. */}
            <iframe
              ref={editorFrameRef}
              className={style.pdfFrame}
              srcDoc={editorHtml}
              title="Final Scope Document"
            />
          </CardContent>
        )}
      </Card>
    </div>
  );
};

export default FinalScopeDocumentPage;
