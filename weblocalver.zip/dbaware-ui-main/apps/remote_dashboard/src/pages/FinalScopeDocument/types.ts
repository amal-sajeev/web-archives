export interface FinalScopeDocumentPageProps {}
