import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  LeftSlot,
  Stack,
  Button,
  RightSlot,
  Text,
  Separator,
  PopoverTrigger,
  Popover,
  PopoverSurface,
  OutlineButton
} from "@wadk/ui"
import { EditBoxSolid, CloneSolid } from '@wadk/icons'
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';
import { ScopingTabEnum, setScopeRecommendationData } from '../../store/scopingSlice';
import { AUTO_REDIRECT_DELAY_MS, GenerationState, ApprovalState, SCOPE_RECOMMENDATION_MESSAGES } from '../../constants';
import { acceptInscopeOutscope, approveScopeRecommendationByRoleAction, rejectScopeRecommendationByRoleAction, getScopeRecommendation, updateInscopeOutscope, generateScopeRecommendation, downloadInscopeOutscope, notifyTask } from '../../api/procedureClient';
import { EmptyScopingState, FadingTextCycler, showSuccessToast, showErrorToast, AiRationalIcon, ActionModal, SendBackCommentModal, SendBackCommentAlert, SEND_BACK_LABEL } from '../../components';
import { downloadTextAsFile, copyToClipboard, stripHtmlToText, resolveApproveButtonTextForStaticUser, markdownToEditorHtml, editorHtmlToMarkdown, SECTION_EDITOR_OPTIONS,downloadFile } from '../../utils';
import { getDashboardRouteParams, useSavedComment, useRejectExecuted } from '../../utils';
import { ScopingStageEnum } from '../../constants';
import { usePlanId } from '../../hooks/usePlanId';
import { ScopeRecommendationRootState } from './types';
import ResetToPRButton from '../../components/Button/ResetToPRButton';
import style from './ScopeRecommendationPage.module.css';
import 'com.db.rca.commons.afcc-components/style.css';


// Generation requests currently running, keyed by plan number. Module scope so they
// outlive the page component when the user switches tabs.
const inFlightScopeRecommendationGeneration = new Map<string, Promise<boolean>>();

const getRecommendationPlanNumber = (data: any): string | undefined => (
  data?.planNumber ??
  data?.plan_number ??
  data?.response?.planNumber ??
  data?.response?.plan_number ??
  data?.metadata?.planNumber ??
  data?.metadata?.plan_number
);

const getSectionReport = (section: any): string => {
  if (typeof section === 'string') {
    return section;
  }

  return section?.report ?? section?.content ?? '';
};

const escapeHtml = (value: string): string => value
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;');

const formatSectionReportForView = (section: any): string => {
  const report = getSectionReport(section);
  if (!report) {
    return '';
  }

  const hasHtmlTags = /<\/?[a-z][\s\S]*>/i.test(report);
  const source = hasHtmlTags ? report : escapeHtml(report).replace(/\n/g, '<br/>');

  return source.replace(/\*\*(.*?)\*\*/g, `<strong class="${style.markdownBoldSmall}">$1</strong>`);
};

const getSectionRationale = (section: any): string | undefined => {
  if (!section || typeof section === 'string') {
    return undefined;
  }

  return section?.rationale;
};

const getSectionConfidenceScore = (section: any): number | undefined => {
  if (!section || typeof section === 'string') {
    return undefined;
  }

  return section?.confidence_score ?? section?.confidenceScore;
};

const renderSectionMetadata = (section: any, topLevelData?: any) => {
  // Try to get rationale from section first, then fallback to top-level data
  const sectionRationale = getSectionRationale(section) || (topLevelData ? getSectionRationale(topLevelData) : undefined);
  // Try to get confidence score from section first, then fallback to top-level data
  const sectionConfidenceScore = getSectionConfidenceScore(section) ?? (topLevelData ? getSectionConfidenceScore(topLevelData) : undefined);

  const confidenceLabel = typeof sectionConfidenceScore === 'number'
    ? sectionConfidenceScore >= 90
      ? 'VERY HIGH'
      : sectionConfidenceScore >= 70
        ? 'HIGH'
        : sectionConfidenceScore >= 50
          ? 'MEDIUM'
          : 'LOW'
    : 'N/A';

  return (
    <div className={style.aiRationaleContainer}>
      <Text variant="secondary" className={style.confidenceText}>
        Confidence Score : <span className={style.confidenceValue}>{confidenceLabel}{typeof sectionConfidenceScore === 'number' ? ` (${sectionConfidenceScore}%)` : ''}</span>
      </Text>
      <Separator placement="vertical" />
      <Popover>
        <PopoverTrigger>
          <Button variant="link" icon={<AiRationalIcon />} disabled={!sectionRationale}>View AI Rationale</Button>
        </PopoverTrigger>
        <PopoverSurface placement="bottom-end" title="AI Rationale" closable={true}>
          <Text className={style.preWrapText}>{sectionRationale || 'No rationale available for this section.'}</Text>
        </PopoverSurface>
      </Popover>
    </div>
  );
};


const ScopeRecommendationPage: React.FC = () => {
  const APPROVE_PERMISSION = 'SR_RH_APPROVE';
  const REJECT_PERMISSION = 'SR_RH_REJECT';

  const [hasError, setHasError] = useState(false);
  const [isInscopeEditing, setIsInscopeEditing] = useState(false);
  const [isOutscopeEditing, setIsOutscopeEditing] = useState(false);
  const [inscopeValue, setInscopeValue] = useState('');
  const [outscopeValue, setOutscopeValue] = useState('');
  const [isSavingInscope, setIsSavingInscope] = useState(false);
  const [isSavingOutscope, setIsSavingOutscope] = useState(false);
  const [approveState, setApproveState] = useState<ApprovalState>('idle');

  const [isRejecting, setIsRejecting] = useState(false); 
  const [isSentBack, setIsSentBack] = useState(false); 
  const [isSendBackModalOpen, setIsSendBackModalOpen] = useState(false);
  const [hasApprovePermission, setHasApprovePermission] = useState(false);
  const [hasRejectPermission, setHasRejectPermission] = useState(false);
  const [approveButtonText, setApproveButtonText] = useState('Approve Result');
  const [isGetApiLoading, setIsGetApiLoading] = useState<boolean>(false);
  const [getApiFailed, setGetApiFailed] = useState<boolean>(false);
  const [isActionsModalOpen, setIsActionsModalOpen] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const planId = usePlanId();
  const { comment: sendBackMessage, setComment: setSendBackMessage } = useSavedComment(planId, [ScopingStageEnum.SCOPE_RECOMMENDATION]);
  const isRejectExecuted = useRejectExecuted(planId, ['SR_RH_REJECT']);
  const redirectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [isRedirectingToTestSteps, setIsRedirectingToTestSteps] = useState(false);

  const recommendationData = useSelector((state: ScopeRecommendationRootState) => state?.scoping?.scopeRecommendationData);
  const nextAvailableActionsByPlan = useSelector((state: any) => state.scoping?.nextAvailableActionsByPlan);
  const taskDefinitionKeyByPlan = useSelector((state: any) => state.scoping?.taskDefinitionKeyByPlan);

  const currentPlanNumber = String(planId || '').trim();
  const availableWorkflowActions = useMemo(() => {
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];

    return Array.from(new Set(actionsFromPlan))
      .map((action: unknown) => String(action || '').trim().toUpperCase())
      .filter(Boolean);
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const taskDefinitionKey = useMemo(() => {
    const fromPlan = String(taskDefinitionKeyByPlan?.[currentPlanNumber] ?? '').trim();
    return fromPlan.replace(/[\s-]+/g, '_').toUpperCase();
  }, [taskDefinitionKeyByPlan, currentPlanNumber]);

  const isScopeRecommendationTaskDefinition = taskDefinitionKey === 'SCOPE_RECOMMENDATION';
  const isCurrentTabActionable = !taskDefinitionKey || isScopeRecommendationTaskDefinition;
  const canGenerateScopeRecommendation =
    !isScopeRecommendationTaskDefinition || availableWorkflowActions.includes('GENERATE_INSCOPE_OUTSCOPE');
  const canGetScopeRecommendation =
    availableWorkflowActions.includes('GET_INSCOPE_OUTSCOPE');
  const canUpdateScopeRecommendation =
    isCurrentTabActionable && (!isScopeRecommendationTaskDefinition || availableWorkflowActions.includes('UPDATE_INSCOPE_OUTSCOPE'));
  const canDownloadScopeRecommendation =
    !isScopeRecommendationTaskDefinition || availableWorkflowActions.includes('DOWNLOAD_INSCOPE_OUTSCOPE');
  // Each action button is strictly tied to its own available workflow action.
  // "Accept result" => ACCEPT_INSCOPE_OUTSCOPE
  // "Approve Result" => SR_RH_APPROVE
  // "Reject Result"  => SR_RH_REJECT
  const canAcceptScopeRecommendation =
    isCurrentTabActionable && availableWorkflowActions.includes('ACCEPT_INSCOPE_OUTSCOPE');
  const canApproveByRolePermission =
    isCurrentTabActionable && availableWorkflowActions.includes(APPROVE_PERMISSION);
  const canRejectScopeRecommendation =
    isCurrentTabActionable && availableWorkflowActions.includes(REJECT_PERMISSION);

  const hasApproveCapability = canAcceptScopeRecommendation || canApproveByRolePermission;
  const hasRejectCapability = canRejectScopeRecommendation;

  const hasAnyAvailableAction = canAcceptScopeRecommendation || canApproveByRolePermission || canRejectScopeRecommendation;

  const recommendationPlanNumber = getRecommendationPlanNumber(recommendationData);

  const hasCachedRecommendationForCurrentPlan =
    !!planId &&
    !!recommendationData &&
    String(recommendationPlanNumber) === String(planId);

  const currentRecommendationData = hasCachedRecommendationForCurrentPlan ? recommendationData : null;

  const [generationState, setGenerationState] = useState<GenerationState>(
    hasCachedRecommendationForCurrentPlan ? 'generated' : 'empty'
  );

  useEffect(() => {
    let cancelled = false;

    const loadApproveButtonText = async () => {
      const nextButtonText = await resolveApproveButtonTextForStaticUser();
      if (!cancelled) {
        setApproveButtonText(nextButtonText);
      }
    };

    loadApproveButtonText();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (hasCachedRecommendationForCurrentPlan) {
      setGenerationState('generated');
      setHasError(false);
    } else if (generationState !== 'generating') {
      setGenerationState('empty');
    }
  }, [hasCachedRecommendationForCurrentPlan, generationState]);

  useEffect(() => {
    const handleGenerate = () => {
      if (!canGenerateScopeRecommendation) {
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'scope-recommendation-loading' }
        }));
        window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
          detail: { sender: 'ai', content: 'Generate Scope Recommendation is not available at this stage.' }
        }));
        return;
      }

      setGenerationState('generating');
      setHasError(false);
    };
    window.addEventListener('ai-chat:generate-scope-recommendation', handleGenerate);
    return () => window.removeEventListener('ai-chat:generate-scope-recommendation', handleGenerate);
  }, [canGenerateScopeRecommendation]);

  useEffect(() => {
    if (!planId || hasCachedRecommendationForCurrentPlan || generationState === 'generating' || !canGetScopeRecommendation) {
      return;
    }

    let cancelled = false;

    const fetchScopeRecommendationIfEmpty = async () => {
      setGetApiFailed(false);
      setIsGetApiLoading(true);
      try {
        const response = await getScopeRecommendation({ planNumber: planId });
        if (cancelled || !response) return;

        const hasUsefulRecommendationData = Boolean(
          response.inscope ||
          response.outscope ||
          response.report_title
        );

        if (!hasUsefulRecommendationData) return;

        dispatch(setScopeRecommendationData({
          ...response,
          planNumber: response.planNumber || planId,
        }));
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'scope-recommendation-loading' }
        }));
      } catch {
        if (!cancelled) {
          setGetApiFailed(true);
        }
      } finally {
        setIsGetApiLoading(false);
      }
    };

    fetchScopeRecommendationIfEmpty();

    return () => {
      cancelled = true;
    };
  }, [dispatch, generationState, hasCachedRecommendationForCurrentPlan, planId, canGetScopeRecommendation]);
  // Re-attach to a generation that is still running after returning to this tab.
  useEffect(() => {
    if (planId && inFlightScopeRecommendationGeneration.has(planId) && !hasCachedRecommendationForCurrentPlan) {
      setGenerationState('generating');
    }
  }, [planId, hasCachedRecommendationForCurrentPlan]);

  useEffect(() => {
    if (generationState !== 'generating' || !planId) {
      return;
    }

    let isMounted = true;

    // One request per plan, held at module scope so it survives tab switches and remounts.
    let request = inFlightScopeRecommendationGeneration.get(planId);
    if (!request) {
      const targetPlan = planId;
      request = (async () => {
        try {
          const response: any = await generateScopeRecommendation({ planNumber: targetPlan });
          const payload = response?.data || response?.payload || response?.response || response;
          dispatch(setScopeRecommendationData({ ...payload, planNumber: getRecommendationPlanNumber(payload) ?? targetPlan }));
          window.dispatchEvent(new CustomEvent('scope-recommendation:sync', {
            detail: {
              planNumber: targetPlan,
              status: 'completed',
              message: 'Scope Recommendation has been generated successfully.',
            }
          }));
          window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
          return true;
        } catch (error) {
          console.error('Failed to get or generate scope recommendation data:', error);
          window.dispatchEvent(new CustomEvent('scope-recommendation:sync', {
            detail: {
              planNumber: targetPlan,
              status: 'failed',
              message: 'Failed to generate Scope Recommendation. Please try again.',
            }
          }));
          return false;
        } finally {
          inFlightScopeRecommendationGeneration.delete(targetPlan);
        }
      })();
      inFlightScopeRecommendationGeneration.set(targetPlan, request);
    }

    request.then((succeeded) => {
      if (!isMounted) return;
      setGenerationState(succeeded ? 'generated' : 'empty');
      setHasError(!succeeded);
    });

    return () => {
      isMounted = false;
    };
  }, [generationState, dispatch, planId]);

  useEffect(() => {
    return () => {
      if (redirectTimeoutRef.current) clearTimeout(redirectTimeoutRef.current);
    };
  }, []);

  /**
   * Initializes the in-scope editor with current recommendation data and enters edit mode.
   */
  const handleInscopeEdit = useCallback(() => {
    if (!canUpdateScopeRecommendation) {
      showErrorToast('Action not available', 'UPDATE_INSCOPE_OUTSCOPE is not available for this plan.'); return;
    }

    setInscopeValue(markdownToEditorHtml(getSectionReport(currentRecommendationData?.inscope)));
    setIsInscopeEditing(true);
  }, [canUpdateScopeRecommendation, currentRecommendationData]);

  /**
   * Initializes the out-of-scope editor with current recommendation data and enters edit mode.
   */
  const handleOutscopeEdit = useCallback(() => {
    if (!canUpdateScopeRecommendation) {
      showErrorToast('Action not available', 'UPDATE_INSCOPE_OUTSCOPE is not available for this plan.'); return;
    }

    setOutscopeValue(markdownToEditorHtml(getSectionReport(currentRecommendationData?.outscope)));
    setIsOutscopeEditing(true);
  }, [canUpdateScopeRecommendation, currentRecommendationData]);

  /**
   * Saves the updated in-scope content by stripping HTML, updating via API, and updating Redux store.
   */
  const handleInscopeSave = async () => {
    if (!canUpdateScopeRecommendation) {
      showErrorToast('Action not available', 'UPDATE_INSCOPE_OUTSCOPE is not available for this plan.');
      return;
    }

    if (!currentRecommendationData || !planId) return;
    setIsSavingInscope(true);
    const plainTextInscope = editorHtmlToMarkdown(inscopeValue);
    const updatedData = {
      ...currentRecommendationData,
      inscope: typeof currentRecommendationData.inscope === 'string'
        ? plainTextInscope
        : { ...currentRecommendationData.inscope, report: plainTextInscope }
    };
    try {
      await updateInscopeOutscope({
        planNumber: planId,
        inscope: plainTextInscope,
        outscope: getSectionReport(currentRecommendationData.outscope),
        rationale: getSectionRationale(currentRecommendationData),
        confidence_score: getSectionConfidenceScore(currentRecommendationData)
      });
      setIsInscopeEditing(false);
      dispatch(setScopeRecommendationData(updatedData));
      showSuccessToast(SCOPE_RECOMMENDATION_MESSAGES.UPDATE_SUCCESS);
    } catch (error) {
      console.error("Failed to update in-scope data:", error);
    } finally {
      setIsSavingInscope(false);
    }
  };

  /**
   * Saves the updated out-of-scope content by stripping HTML, updating via API, and updating Redux store.
   */
  const handleOutscopeSave = async () => {
    if (!canUpdateScopeRecommendation) {
      showErrorToast('Action not available', 'UPDATE_INSCOPE_OUTSCOPE is not available for this plan.');
      return;
    }

    if (!currentRecommendationData || !planId) return;
    setIsSavingOutscope(true);
    const plainTextOutscope = editorHtmlToMarkdown(outscopeValue);
    const updatedData = {
      ...currentRecommendationData,
      outscope: typeof currentRecommendationData.outscope === 'string'
        ? plainTextOutscope
        : { ...currentRecommendationData.outscope, report: plainTextOutscope }
    };
    try {
      await updateInscopeOutscope({
        planNumber: planId,
        inscope: getSectionReport(currentRecommendationData.inscope),
        outscope: plainTextOutscope,
        rationale: getSectionRationale(currentRecommendationData),
        confidence_score: getSectionConfidenceScore(currentRecommendationData)
      });
      setIsOutscopeEditing(false);
      dispatch(setScopeRecommendationData(updatedData));
      showSuccessToast(SCOPE_RECOMMENDATION_MESSAGES.UPDATE_SUCCESS);
    } catch (error) {
      console.error("Failed to update out-of-scope data:", error);
    } finally {
      setIsSavingOutscope(false);
    }
  };

  /**
   * Approves the current scope recommendation result, updating the approval state visually.
   */
  const handleApproveClick = useCallback(async () => {
    if (!hasApproveCapability) {
      showErrorToast('Action not available', `${APPROVE_PERMISSION} permission is required.`);
      return;
    }

    if (!canAcceptScopeRecommendation) {
      showErrorToast('Action not available', 'ACCEPT_INSCOPE_OUTSCOPE is not available for this plan.');
      return;
    }

    if (!planId) {
      showErrorToast('Failed to approve scope recommendation', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await acceptInscopeOutscope(planId);
      try {
        await notifyTask(planId, 'scope_recommendation', 'REGIONAL_HEAD');
      } catch (notifyError) {
        console.error('Failed to notify REGIONAL_HEAD for scope recommendation:', notifyError);
      }
      setSendBackMessage('');
      setApproveState('approved');
      setIsActionsModalOpen(false);
      showSuccessToast(SCOPE_RECOMMENDATION_MESSAGES.APPROVE_SUCCESS);
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to approve scope recommendation:', error);
      setApproveState('idle');
      showErrorToast('Failed to approve scope recommendation', 'Could not approve the document.');
    }
  }, [canAcceptScopeRecommendation, hasApproveCapability, planId]);

  const handleRoleApproveClick = useCallback(async () => {
    if (!hasApproveCapability) {
      showErrorToast('Action not available', `${APPROVE_PERMISSION} permission is required.`);
      return;
    }

    if (!planId) {
      showErrorToast('Failed to approve scope recommendation', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await approveScopeRecommendationByRoleAction(planId);
      setApproveState('approved');
      setIsActionsModalOpen(false);
      showSuccessToast('Scope recommendation approved');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to approve scope recommendation via role action:', error);
      setApproveState('idle');
      showErrorToast('Failed to approve scope recommendation', 'Could not approve the document.');
    }
  }, [hasApproveCapability, planId]);
  const handleRejectClick = useCallback(async (comment: string) => {
    if (!hasRejectCapability) {
      showErrorToast('Action not available', `${REJECT_PERMISSION} permission is required.`);
      return;
    }

    if (!canRejectScopeRecommendation) {
      showErrorToast('Action not available', `${REJECT_PERMISSION} is not available for this plan.`);
      return;
    }

    if (!planId) {
      showErrorToast('Failed to reject scope recommendation', 'Plan number is not available.');
      return;
    }

    setIsRejecting(true);
    try {
      await rejectScopeRecommendationByRoleAction(planId, comment);
      setSendBackMessage(comment);
      setIsSentBack(true);
      setIsSendBackModalOpen(false);
      setApproveState('idle');
      setIsActionsModalOpen(false);
      showSuccessToast('Scope rejected');
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
    } catch (error) {
      console.error('Failed to reject scope recommendation via role action:', error);
      showErrorToast('Failed to reject scope recommendation', 'Could not reject the document.');
    } finally {
      setIsRejecting(false);
    }
  }, [hasRejectCapability, planId]);

  const handleOpenActionsModal = useCallback(() => {
    setIsActionsModalOpen(true);
  }, []);

  const actionItems = useMemo(() => {
    const items: Array<{
      key: string;
      label: string;
      onClick: () => void | Promise<void>;
      disabled?: boolean;
      loading?: boolean;
      tone?: 'default' | 'danger';
      emphasis?: 'primary' | 'default';
    }> = [];

    if (canAcceptScopeRecommendation) {
      items.push({
        key: 'accept',
        label: 'Accept result',
        onClick: handleApproveClick,
        loading: approveState === 'loading',
        disabled: approveState === 'loading' || isRejecting,
        emphasis: 'primary',
      });
    }

    if (canApproveByRolePermission) {
      items.push({
        key: 'role-approve',
        label: 'Approve Result',
        onClick: handleRoleApproveClick,
        loading: approveState === 'loading',
        disabled: approveState === 'loading' || isRejecting,
        emphasis: 'primary',
      });
    } return items;
  }, [
    handleApproveClick,
    handleRoleApproveClick,
    approveState,
    isRejecting,
    canAcceptScopeRecommendation,
    canApproveByRolePermission,
  ]);

  const hasRoleActions = actionItems.length > 0;

  /**
   * Navigates the user to the Test Steps tab for the next stage of scoping.
   */
  useEffect(() => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (generationState === 'generated' && approveState === 'approved' && planId) {
      setIsRedirectingToTestSteps(true);
      redirectTimeoutRef.current = setTimeout(() => {
        navigate(`../${ScopingTabEnum.TEST_STEPS}/${planId}`);
      }, AUTO_REDIRECT_DELAY_MS);
      return;
    }

    setIsRedirectingToTestSteps(false);
  }, [approveState, generationState, navigate, planId]);

  /**
   * Downloads the in-scope and out-of-scope recommendations as a generated PDF file.
   */
  const handleDownloadClick = async () => {
    if (!canDownloadScopeRecommendation) {
      showErrorToast('Action not available', 'DOWNLOAD_INSCOPE_OUTSCOPE is not available for this plan.');
      return;
    }

    if (!currentRecommendationData || !planId) return;

    try {
      const response = await downloadInscopeOutscope({
        planNumber: planId,
        inscope: getSectionReport(currentRecommendationData.inscope),
        outscope: getSectionReport(currentRecommendationData.outscope)
      });

      downloadFile((response as any).data || response, `scope_recommendation_${planId}.pdf`, 'application/pdf');
    } catch (error) {
      console.error("Failed to download scope recommendation data:", error);
    }
  };

  const anyData = currentRecommendationData as any;
  const inscopeRationale = getSectionRationale(anyData?.inscope);
  const outscopeRationale = getSectionRationale(anyData?.outscope);
  const rationale = anyData?.aiRationale || anyData?.rationale || [
    inscopeRationale ? `In-Scope: ${inscopeRationale}` : null,
    outscopeRationale ? `Out-of-Scope: ${outscopeRationale}` : null,
  ].filter(Boolean).join('\n\n') || "AI analyzed 5 similar past reviews and relevant policy documents. Standard scope drivers were mapped based on identified framework gaps and historical findings. [1.0]";
  const confidenceScores = [getSectionConfidenceScore(anyData?.inscope), getSectionConfidenceScore(anyData?.outscope)].filter((value): value is number => typeof value === 'number');
  const confidenceScore = confidenceScores.length > 0
    ? Math.round(confidenceScores.reduce((total, value) => total + value, 0) / confidenceScores.length)
    : anyData?.confidence_score ?? anyData?.metadata?.confidence_score ?? 100;

  let confidenceText = 'HIGH';
  if (confidenceScore >= 90) confidenceText = 'VERY HIGH';
  else if (confidenceScore >= 70) confidenceText = 'HIGH';
  else if (confidenceScore >= 50) confidenceText = 'MEDIUM';
  else confidenceText = 'LOW';

  return (
    <div className={style.pageContainer}>
      <Card
        outlined
        radius="lg"
        raise="2-subtle"
      >
        <CardHeader >
          <LeftSlot>
            <Stack>
              <CardTitle content="Scope Recommendation Output" />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && (
            <RightSlot>
              <>
                <Stack direction="row" align="center" justifyContent="end" gap="xs">
                  {approveState === 'approved' ? (
                    <OutlineButton disabled>
                      Redirecting to Generate Test Steps...
                    </OutlineButton>
                  ) : (
                    <OutlineButton
                      onClick={handleOpenActionsModal}
                      disabled={approveState === 'loading' || isRejecting || !hasRoleActions}
                    >                      Actions
                    </OutlineButton>
                  )}
                  {approveState !== 'approved' && !isSentBack && !isRejectExecuted && canRejectScopeRecommendation && (
                    <OutlineButton
                      variant="danger"
                      onClick={() => setIsSendBackModalOpen(true)}
                      loading={isRejecting}
                      disabled={approveState === 'loading' || isRejecting}
                    >
                      {SEND_BACK_LABEL}
                    </OutlineButton>
                  )}
                  <ResetToPRButton />
                  <OutlineButton onClick={handleDownloadClick} disabled={!canDownloadScopeRecommendation}>Download Result</OutlineButton>
                </Stack>
              </>
            </RightSlot>
          )}
        </CardHeader>

        <ActionModal
          opened={isActionsModalOpen}
          title="Scope Recommendation Actions"
          subtitle="Select an action to continue."
          actions={actionItems}
          emptyMessage="No action required at this stage." onClose={() => setIsActionsModalOpen(false)}
        />

        <SendBackCommentModal
          opened={isSendBackModalOpen}
          loading={isRejecting}
          onCancel={() => setIsSendBackModalOpen(false)}
          onConfirm={handleRejectClick}
        />

        {sendBackMessage?.trim() && (
          <CardContent>
            <SendBackCommentAlert message={sendBackMessage} />
          </CardContent>
        )}

        {generationState === 'generating' || !currentRecommendationData ? (
          <CardContent>
            <EmptyScopingState
              subtitle={isGetApiLoading ? 'loading...........' : (getApiFailed ? <Text variant='negative'>Failed to fetch</Text> : undefined)}
            />
          </CardContent>
        ) : (
          <>
            <Separator placement="horizontal" className={style.topSeparator} />
            <CardContent>
              <Stack direction="column" gap="md" className={style.stackFullWidth}>
                <div>
                  <Stack direction="row" justifyContent="space-between" align="center">
                    <LeftSlot>
                      <Text fontWeight="bold" size="lg" className={style.sectionHeader}>In-Scope</Text>
                    </LeftSlot>
                    <RightSlot>
                      {renderSectionMetadata(currentRecommendationData?.inscope, currentRecommendationData)}
                    </RightSlot>
                  </Stack>
                  {isInscopeEditing ? (
                    <div className={style.editorContainer}>
                      <div className={style.editorScrollArea}>
                        <RichTextEditor
                          value={inscopeValue} options={SECTION_EDITOR_OPTIONS}
                          onValueChange={setInscopeValue}
                        />
                      </div>
                      <Stack direction="row" gap="xs2" className={style.buttonGroup}>
                        <Button onClick={() => setIsInscopeEditing(false)} disabled={isSavingInscope}>Cancel</Button>
                        <Button variant="primary" onClick={handleInscopeSave} loading={isSavingInscope} disabled={isSavingInscope}>Save</Button>
                      </Stack>
                    </div>
                  ) : (
                    <>
                      <div className={style.contentScrollFrame}>
                        <div
                          className={style.htmlContent}
                          dangerouslySetInnerHTML={{ __html: formatSectionReportForView(currentRecommendationData?.inscope) }}
                        />
                      </div>
                      <Stack direction="row" gap="xs2" className={style.buttonGroup}>
                        <Button icon={<EditBoxSolid />} variant="link" onClick={handleInscopeEdit}
                          disabled={!canUpdateScopeRecommendation}
                        >Edit</Button>
                        <Button icon={<CloneSolid />} variant="link" onClick={() => {
                          copyToClipboard(stripHtmlToText(getSectionReport(currentRecommendationData?.inscope)));
                          showSuccessToast('In-Scope copied to clipboard');
                        }}>Copy</Button>
                      </Stack>
                    </>
                  )}
                </div>

                <div>
                  <Stack direction="row" justifyContent="space-between" align="center">
                    <LeftSlot>
                      <Text fontWeight="bold" size="lg" className={style.sectionHeader}>Out-of-Scope</Text>
                    </LeftSlot>
                    <RightSlot>
                      {renderSectionMetadata(currentRecommendationData?.outscope, currentRecommendationData)}
                    </RightSlot>
                  </Stack>

                  {isOutscopeEditing ? (
                    <div className={style.editorContainer}>
                      <div className={style.editorScrollArea}>
                        <RichTextEditor
                          value={outscopeValue} options={SECTION_EDITOR_OPTIONS}
                          onValueChange={setOutscopeValue}
                        />
                      </div>
                      <Stack direction="row" gap="xs2" className={style.buttonGroup}>
                        <Button onClick={() => setIsOutscopeEditing(false)} disabled={isSavingOutscope}>Cancel</Button>
                        <Button variant="primary" onClick={handleOutscopeSave} loading={isSavingOutscope} disabled={isSavingOutscope}>Save</Button>
                      </Stack>
                    </div>
                  ) : (
                    <>
                      <div className={style.contentScrollFrame}>
                        <div
                          className={style.htmlContent}
                          dangerouslySetInnerHTML={{ __html: formatSectionReportForView(currentRecommendationData?.outscope) }}
                        />
                      </div>
                      <Stack direction="row" gap="xs2" className={style.buttonGroup}>
                        <Button icon={<EditBoxSolid />} variant="link" onClick={handleOutscopeEdit}
                          disabled={!canUpdateScopeRecommendation}
                        >Edit</Button>
                        <Button icon={<CloneSolid />} variant="link" onClick={() => {
                          copyToClipboard(stripHtmlToText(getSectionReport(currentRecommendationData?.outscope)));
                          showSuccessToast('Out-of-Scope copied to clipboard');
                        }}>Copy</Button>
                      </Stack>
                    </>
                  )}
                </div>
              </Stack>
            </CardContent>
          </>
        )}
      </Card>
    </div>
  );
};

export default ScopeRecommendationPage;