import { ScopingState } from '../../store/scopingSlice';

export interface ScopeRecommendationRootState {
  scoping?: ScopingState;
}
