import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import NoirPage from './NoirPage';
import { NOIR_CONFIG } from '../../constants';
import { setNoirData } from '../../store/scopingSlice';

const dispatchMock = vi.fn();
const getNoirMock = vi.fn();
const generateNoirMock = vi.fn();
const editNoirMock = vi.fn();
const sendNoirMock = vi.fn();
let mockState: any;

vi.mock('react-redux', async () => {
  const actual = await vi.importActual<typeof import('react-redux')>('react-redux');
  return {
    ...actual,
    useDispatch: () => dispatchMock,
    useSelector: (selector: any) => selector(mockState),
  };
});

vi.mock('../../api/noirClient', () => ({
  getNoir: (...args: any[]) => getNoirMock(...args),
  generateNoir: (...args: any[]) => generateNoirMock(...args),
  editNoir: (...args: any[]) => editNoirMock(...args),
  sendNoir: (...args: any[]) => sendNoirMock(...args),
}));

vi.mock('../../components', async () => await import('../../test/mocks/afccComponents'));

describe('NoirPage', () => {
  beforeEach(() => {
    mockState = {
      scoping: {
        noirData: null,
        recipients: [],
        isGeneratingNoir: false,
        nextAvailableActionsByPlan: {
          '20583': ['GET_NOIR'],
        },
      },
    };
    dispatchMock.mockClear();
    getNoirMock.mockReset();
    generateNoirMock.mockReset();
    editNoirMock.mockReset();
    sendNoirMock.mockReset();
    getNoirMock.mockRejectedValue(new Error('GET failed'));
    generateNoirMock.mockResolvedValue({
      subject: 'NOIR subject',
      body: 'NOIR body',
      email: 'Subject: NOIR subject\n\nBody:\nNOIR body',
      recipients: ['alpha@example.com'],
      original_data: [{
        'Plan Item Number': 20583,
        'Plan Item Title': 'NOIR Plan',
        'Coordinating Team Lead': 'Jane Doe',
      }],
    });
    editNoirMock.mockResolvedValue({
      subject: 'Edited NOIR subject',
      body: 'Edited NOIR body',
      email: 'Subject: Edited NOIR subject\n\nBody:\nEdited NOIR body',
      recipients: ['alpha@example.com'],
      original_data: [{
        'Plan Item Number': 20583,
        'Plan Item Title': 'NOIR Plan',
        'Coordinating Team Lead': 'Jane Doe',
      }],
    });
    sendNoirMock.mockResolvedValue(undefined);
  });

  it('renders the empty state and generates a NOIR document', async () => {
    render(
      <MemoryRouter initialEntries={['/noir/20583']}>
        <NoirPage />
      </MemoryRouter>
    );

    expect(screen.getByTestId('EmptyScopingState')).toBeTruthy();
    expect(getNoirMock).toHaveBeenCalledWith('20583');
    expect(generateNoirMock).not.toHaveBeenCalled();
    expect(dispatchMock).not.toHaveBeenCalledWith(expect.objectContaining({ type: setNoirData.type }));
  });

  it('sends the NOIR with the configured sender address', async () => {
    mockState = {
      scoping: {
        noirData: {
          subject: 'Subject line',
          body: 'Body line',
          email: 'Subject: Subject line\n\nBody:\nBody line',
          task_definition_key: 'NOIR',
          recipients: ['alpha@example.com', 'beta@example.com'],
          original_data: [{
            'Plan Item Number': 20583,
            'Plan Item Title': 'NOIR Plan',
            'Coordinating Team Lead': 'Jane Doe',
          }],
        },
        recipients: [],
        isGeneratingNoir: false,
        nextAvailableActionsByPlan: {
          '20583': ['MANUAL_EDIT', 'SEND_NOIR_EMAIL'],
        },
        taskDefinitionKeyByPlan: {
          '20583': 'NOIR',
        },
      },
    };

    render(
      <MemoryRouter initialEntries={['/noir/20583']}>
        <NoirPage />
      </MemoryRouter>
    );

    window.dispatchEvent(new CustomEvent('noir:accepted'));

    const sendButton = await screen.findByRole('button', { name: 'Send NOIR' });
    fireEvent.click(sendButton);

    await waitFor(() => expect(sendNoirMock).toHaveBeenCalledWith(expect.objectContaining({
      plan_item_number: '20583',
      subject: 'Subject line',
      body: 'Body line',
      to_recipients: ['alpha@example.com', 'beta@example.com'],
      from_address: NOIR_CONFIG.fromAddress,
    })));
  });
});
