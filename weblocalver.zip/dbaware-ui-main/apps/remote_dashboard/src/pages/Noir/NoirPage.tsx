import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  LeftSlot,
  Stack,
  Button,
  RightSlot,
  OutlineButton,
  CardFooter,
  CardSubHeader,
  Text,
  Separator,
} from "@wadk/ui"
import { DownloadSolid, EditBoxSolid, EnvelopeOutline, CloneSolid } from '@wadk/icons'
import {
  EmailView,
  EmailEdit,
  FadingTextCycler,
  EmptyScopingState,
  showSuccessToast,
  showErrorToast
} from '../../components';
import {
  NOIR_PLACEHOLDERS,
  EDITOR_OPTIONS,
  GenerationState,
  SendState,
  NOIR_MESSAGES,
  NOIR_CONFIG,
  AUTO_REDIRECT_DELAY_MS
} from '../../constants';
import {
  truncateText,
  extractEmailSubject,
  extractEmailBody,
  stripHtmlToText,
  copyToClipboard,
  stripHtml,
  downloadTextAsFile
} from '../../utils';
import { ScopingTabEnum, setNoirData, setNextAvailableActionsForPlan, setTaskDefinitionKeyForPlan } from '../../store/scopingSlice';
import { RootState, NoirViewModel } from './types';
import { getNoir, editNoir, sendNoir } from '../../api/noirClient';
import { getDashboardRouteParams } from '../../utils';
import style from './NoirPage.module.css';

/**
 * NoirPage Component
 * 
 * Displays and manages the state of a NOIR document. 
 * Allows users to generate, view, edit, and send NOIRs.
 * 
 * @returns {React.FC} The rendered NOIR Page component.
 */
const NoirPage: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Extract planId from URL
  const location = useLocation();
  const { planId } = getDashboardRouteParams(location.pathname);
  const noirData = useSelector((state: RootState) => state.scoping?.noirData);
  const recipientsList = useSelector((state: RootState) => state.scoping?.recipients);
  const isGeneratingNoir = useSelector((state: RootState) => state.scoping?.isGeneratingNoir);
  const nextAvailableActionsByPlan = useSelector((state: RootState) => state.scoping?.nextAvailableActionsByPlan);
  const taskDefinitionKeyByPlan = useSelector((state: RootState) => state.scoping?.taskDefinitionKeyByPlan);
  const isDataGatheringEnabled = localStorage.getItem('dataGatheringToggle') === 'true';

  const [generationState, setGenerationState] = useState<GenerationState>(
    isGeneratingNoir ? 'generating' : noirData ? 'generated' : 'empty'
  );

  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [sendState, setSendState] = useState<SendState>('idle');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isGetNoirLoading, setIsGetNoirLoading] = useState<boolean>(false);
  const [disableButtons, setDisableButtons] = useState<boolean>(false); const [isRedirecting, setIsRedirecting] = useState<boolean>(false);
  const [noirAccepted, setNoirAccepted] = useState<boolean>(false);
  const [isNoirPreviewAcceptancePending, setIsNoirPreviewAcceptancePending] = useState<boolean>(false);
  const [isNoirPreviewModalVisible, setIsNoirPreviewModalVisible] = useState<boolean>(false);
  const redirectTimeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const shouldRefreshPlanStatusAfterGenerationRef = useRef(false);
  const currentPlanNumber = String(
    planId ||
    noirData?.original_data?.[0]?.['Plan Item Number'] ||
    ''
  );
  const noirPlanNumber = String(noirData?.original_data?.[0]?.['Plan Item Number'] || '').trim();
  const hasNoirForCurrentPlan = !!currentPlanNumber && (!!noirData && (!noirPlanNumber || noirPlanNumber === currentPlanNumber));
  const nextScopingTab = isDataGatheringEnabled ? ScopingTabEnum.DATA_GATHERING : ScopingTabEnum.PRELIMINARY_RESEARCH;

  const availableWorkflowActions = useMemo(() => {
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];
    const actionsFromNoirData = Array.isArray(noirData?.next_available_actions)
      ? noirData.next_available_actions
      : [];

    return Array.from(new Set([...actionsFromPlan, ...actionsFromNoirData]))
      .map((action) => String(action).trim().toUpperCase())
      .filter(Boolean);
  }, [nextAvailableActionsByPlan, currentPlanNumber, noirData?.next_available_actions]);

  const taskDefinitionKey = useMemo(() => {
    const fromPlan = String(taskDefinitionKeyByPlan?.[currentPlanNumber] ?? '').trim();
    const fromNoirData = String(noirData?.task_definition_key ?? '').trim();
    return (fromPlan || fromNoirData).toUpperCase();
  }, [taskDefinitionKeyByPlan, currentPlanNumber, noirData?.task_definition_key]);

  const isNoirTaskDefinition = taskDefinitionKey === 'NOIR';
  const canGetNoir = availableWorkflowActions.includes('GET_NOIR');
  const canGetNoirForCurrentPlan = useMemo(() => {
    const actionsForPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];
    return actionsForPlan
      .map((action: any) => String(action).trim().toUpperCase())
      .includes('GET_NOIR');
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const canManualEdit = availableWorkflowActions.includes('EDIT_NOIR');
  const canSendNoirEmail = isNoirTaskDefinition && availableWorkflowActions.includes('SEND_NOIR_EMAIL');
  const canDownloadNoir = availableWorkflowActions.includes('DOWNLOAD');

  const resolvedRecipientEmails = useMemo(() => {
    const allEmails: string[] = [];

    if (Array.isArray(noirData?.recipients)) {
      allEmails.push(...noirData.recipients);
    }

    if (recipientsList && recipientsList.length > 0) {
      recipientsList.forEach((r: any) => {
        if (r.type === 'Email') {
          if (Array.isArray(r.emails) && r.emails.length > 0) {
            allEmails.push(...r.emails);
          } else {
            allEmails.push(r.attachment);
          }
        } else if (r.type === 'File' && r.emails && r.emails.length > 0) {
          allEmails.push(...r.emails);
        }
      });
    }

    return Array.from(
      new Set(allEmails.map(email => email?.trim()).filter((email): email is string => Boolean(email)))
    );
  }, [noirData?.recipients, recipientsList]);

  const hasRecipientEntries = useMemo(() => {
    return Array.isArray(recipientsList) && recipientsList.length > 0;
  }, [recipientsList]);

  /**
   * Safely derives a flat View Model from the complex API data to be used in UI components.
   * Transforms raw API response/mock data into a standardized structure.
   */
  const viewModel: NoirViewModel = useMemo(() => {
    const data: any = noirData;
    const rawItem = data?.original_data?.[0];

    // Prefer the new separate subject and body from the API, fallback to extraction if needed.
    const emailBody = data?.body || extractEmailBody(data?.email || '');
    const subject = data?.subject || extractEmailSubject(data?.email || '');

    const formattedContent = emailBody
      ? `<p>${emailBody.replace(/(?:\r\n|\r|\n)/g, '<br/>')}</p>`
      : "";

    // Show placeholder only when no real recipients are available.
    const formattedRecipients = resolvedRecipientEmails.length > 0
      ? resolvedRecipientEmails.join(', ')
      : NOIR_PLACEHOLDERS.RECIPIENTS;

    return {
      planTitle: rawItem?.["Plan Item Title"] || "Untitled Plan",
      subject: subject,
      teamLeadName: rawItem?.["Coordinating Team Lead"] || "Unassigned",
      content: formattedContent,
      score: NOIR_PLACEHOLDERS.SCORE,
      recipients: formattedRecipients,
      aiRationale: NOIR_PLACEHOLDERS.RATIONALE,
    };
  }, [noirData, resolvedRecipientEmails]);

  useEffect(() => {
    if (generationState === 'generating') {
      setDisableButtons(true);
    }
  }, [generationState]);

  const [docContent, setDocContent] = useState<string>(viewModel.content);
  const [subjectContent, setSubjectContent] = useState<string>(viewModel.subject);
  const [recipientsContent, setRecipientsContent] = useState<string>(resolvedRecipientEmails.join(', '));

  /**
   * Synchronize local state when Redux store noirData changes.
   */
  useEffect(() => {
    if (isGeneratingNoir) {
      setGenerationState('generating');
    } else if (noirData) {
      setDocContent(viewModel.content);
      setSubjectContent(viewModel.subject);
      setRecipientsContent(resolvedRecipientEmails.join(', '));
      setGenerationState('generated');
    } else {
      setGenerationState('empty');
    }
  }, [noirData, isGeneratingNoir, resolvedRecipientEmails, viewModel.content, viewModel.subject]);

  useEffect(() => {
    if (!planId || isGeneratingNoir || hasNoirForCurrentPlan || !canGetNoirForCurrentPlan) {
      return;
    }

    let cancelled = false;

    const fetchNoirIfEmpty = async () => {
      setIsGetNoirLoading(true);
      try {
        const response = await getNoir(planId);
        if (cancelled || !response) return;

        const hasUsefulNoirContent = Boolean(
          response.subject ||
          response.body ||
          response.email ||
          (Array.isArray(response.original_data) && response.original_data.length > 0)
        );

        if (!hasUsefulNoirContent) return; dispatch(setNoirData(response));
        setNoirAccepted(true);
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'noir-loading' }
        }));
      } catch {
        // Intentionally no-op on error as requested.
      } finally {
        if (!cancelled) {
          setIsGetNoirLoading(false);
        }
      }
    };

    fetchNoirIfEmpty();

    return () => {
      cancelled = true;
    };
  }, [dispatch, hasNoirForCurrentPlan, isGeneratingNoir, planId, canGetNoirForCurrentPlan]);

  useEffect(() => {
    if (!planId || noirData || isGeneratingNoir) {
      return;
    }

    setGenerationState('empty');
  }, [isGeneratingNoir, noirData, planId]);

  useEffect(() => {
    if (!canManualEdit && isEditing) {
      setIsEditing(false);
    }
  }, [canManualEdit, isEditing]);

  useEffect(() => {
    if (!shouldRefreshPlanStatusAfterGenerationRef.current) {
      return;
    }

    if (generationState === 'generated') {
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
      shouldRefreshPlanStatusAfterGenerationRef.current = false;
    }
  }, [generationState]);
  // Enable Send NOIR only after the generated NOIR is accepted in the chat flow.
  useEffect(() => {
    const activePlanId = String(currentPlanNumber || planId || '').trim();

    const handleNoirAccepted = (event: Event) => {
      const customEvent = event as CustomEvent<{ noirData?: any; planId?: string }>;
      const acceptedPlanId = String(customEvent.detail?.planId || '').trim();
      if (acceptedPlanId && activePlanId && acceptedPlanId !== activePlanId) {
        return;
      }

      setNoirAccepted(true);
      setIsNoirPreviewAcceptancePending(false);
      setIsNoirPreviewModalVisible(false);
    };

    const handleNoirPreviewOpened = (event: Event) => {
      setIsNoirPreviewAcceptancePending(true);
      setNoirAccepted(false);
    };

    const handleNoirPreviewVisibilityChanged = (event: Event) => {
      const customEvent = event as CustomEvent<{ planId?: string; visible?: boolean }>;
      setIsNoirPreviewModalVisible(Boolean(customEvent.detail?.visible));
    };

    window.addEventListener('noir:accepted', handleNoirAccepted);
    window.addEventListener('noir:preview-opened', handleNoirPreviewOpened);
    window.addEventListener('noir:preview-visibility-changed', handleNoirPreviewVisibilityChanged);
    return () => {
      window.removeEventListener('noir:accepted', handleNoirAccepted);
      window.removeEventListener('noir:preview-opened', handleNoirPreviewOpened);
      window.removeEventListener('noir:preview-visibility-changed', handleNoirPreviewVisibilityChanged);
    };
  }, [planId, currentPlanNumber]);

  useEffect(() => {
    if (!noirData) {
      setNoirAccepted(false);
      setIsNoirPreviewAcceptancePending(false);
      setIsNoirPreviewModalVisible(false);
    }
  }, [noirData]);

  /**
   * Hide Generate NOIR CTA immediatelywhen AI Presenter triggers NOIR generation.
   */
  useEffect(() => {
    const handleGenerateNoirTriggered = () => {
      shouldRefreshPlanStatusAfterGenerationRef.current = true;
      setDisableButtons(true);
      setGenerationState('generating');
      setIsNoirPreviewAcceptancePending(true);
    };

    window.addEventListener('ai-chat:generate-noir', handleGenerateNoirTriggered);
    window.addEventListener('ai-chat:noir-generation-started', handleGenerateNoirTriggered);
    return () => {
      window.removeEventListener('ai-chat:generate-noir', handleGenerateNoirTriggered);
      window.removeEventListener('ai-chat:noir-generation-started', handleGenerateNoirTriggered);
    };
  }, []);

  // ===========================================================================
  // Handlers
  // ===========================================================================

  /**
   * Initiates the NOIR generation process via event dispatch to useAiChat hook.
   * This triggers handleSend('Generate Noir') in the AI Chat flow.
   */
  const handleGenerate = (): void => {
    if (!currentPlanNumber) {
      showErrorToast('Failed to generate NOIR', 'Plan number is not available');
      return;
    }

    shouldRefreshPlanStatusAfterGenerationRef.current = true;
    setDisableButtons(true); // Disable buttons to prevent multiple clicks

    // Hide the button immediately
    setGenerationState('generating');

    // Dispatch event that useAiChat hook listens for
    window.dispatchEvent(new CustomEvent('ai-chat:generate-noir'));
  };

  /**
   * Saves the user's edits to the NOIR document via API.
   */
  const handleSaveClick = async (): Promise<void> => {
    if (!canManualEdit) {
      showErrorToast('Edit not allowed', 'Editing is not available at this step.');
      return;
    }

    setIsSaving(true);
    try {
      const originalData = noirData?.original_data || [];
      const payload = {
        plan_item_number: currentPlanNumber,
        noir: {
          subject: subjectContent,
          body: stripHtmlToText(docContent)
        }
      };

      const responseData = await editNoir(payload);

      const combinedText = `Subject: ${subjectContent}\n\nBody:\n${stripHtmlToText(docContent)}`;

      // Map the edit API response to match the expected NoirData structure
      const updatedNoirData = {
        ...(noirData || {}),
        email: responseData.email || combinedText,
        subject: responseData.subject || subjectContent,
        body: responseData.body || stripHtmlToText(docContent),
        recipients: recipientsContent
          .split(',')
          .map(recipient => recipient.trim())
          .filter(recipient => recipient.length > 0),
        original_data: responseData.original_data || originalData
      };

      dispatch(setNoirData(updatedNoirData));
      showSuccessToast(NOIR_MESSAGES.UPDATE_SUCCESS);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update NOIR:', error);
      showErrorToast('Failed to update NOIR', 'Could not save the document changes.');
    } finally {
      setIsSaving(false);
    }
  };

  /**
   * Skips generation and navigates to the next configured tab.
   */
  const handleSkip = (): void => {
    navigate(`../${nextScopingTab}/${planId}`);
  };

  /**
   * Simulates sending the NOIR document and updates local send state.
   */
  const handleSendNoirClick = async (): Promise<void> => {
    if (!canSendNoirEmail) {
      showErrorToast('Send not allowed', 'Sending NOIR is not available at this step.');
      return;
    }

    try {
      // Parse recipients content from comma-separated string to array
      const recipientList = recipientsContent
        .split(',')
        .map(email => email.trim())
        .filter(email => email.length > 0);

      if (recipientList.length === 0) {
        showErrorToast('Recipients email ID', 'Recipient is required');
        return;
      }

      setSendState('loading');

      const payload = {
        plan_item_number: currentPlanNumber,
        subject: subjectContent,
        body: stripHtmlToText(docContent),
        to_recipients: recipientList,
        from_address: NOIR_CONFIG.fromAddress
      };

      const response = await sendNoir(payload);

      if (Array.isArray(response?.next_available_actions) && response.next_available_actions.length > 0) {
        dispatch(setNextAvailableActionsForPlan({
          planNumber: currentPlanNumber,
          actions: response.next_available_actions,
        }));
      }

      if (response?.task_definition_key) {
        dispatch(setTaskDefinitionKeyForPlan({
          planNumber: currentPlanNumber,
          taskDefinitionKey: response.task_definition_key,
        }));
      }

      setSendState('sent');
      showSuccessToast(NOIR_MESSAGES.SEND_SUCCESS);
    } catch (error) {
      console.error('Failed to send NOIR:', error);
      showErrorToast('Failed to send NOIR', 'Could not send the document.');
      setSendState('idle');
    }
  };

  useEffect(() => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (sendState === 'sent' && generationState === 'generated' && planId) {
      setIsRedirecting(true);
      redirectTimeoutRef.current = setTimeout(() => {
        navigate(`../${nextScopingTab}/${planId}`);
      }, AUTO_REDIRECT_DELAY_MS);
      return;
    }

    setIsRedirecting(false);
  }, [generationState, navigate, nextScopingTab, planId, sendState]);

  useEffect(() => () => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }
  }, []);

  /**
   * Navigates to the next configured tab after successful NOIR dispatch.
   */
  const handleGeneratePreliminaryResearchClick = (): void => {
    navigate(`../${nextScopingTab}/${planId}`);
  };

  /**
   * Downloads the NOIR email content as a .txt file.
   */
  const handleDownloadNoirClick = (): void => {
    const subject = (subjectContent || '').trim();
    const body = stripHtmlToText(docContent || '');

    if (!subject && !body) {
      showErrorToast('Failed to download NOIR', 'No email content available to download.');
      return;
    }

    const content = `Subject: ${subject}\n\nBody:\n${body}`;
    const filePlanNumber = currentPlanNumber || 'unknown';
    downloadTextAsFile(content, `noir_email_${filePlanNumber}.txt`);
    showSuccessToast('NOIR email downloaded');
  };

  // ===========================================================================
  // Render Helpers
  // ===========================================================================

  const renderEmptyState = () => (
    <CardContent>
      {isGetNoirLoading ? (
        <EmptyScopingState
          // title="NOIR"
          subtitle={
            <>Loading......</>
          }
        />
      ) : (
        (disableButtons || hasRecipientEntries) ?
          <EmptyScopingState
          // title="Ask AI about NOIR"
          // secondaryActionText="Skip for now"
          // onSecondaryActionClick={handleSkip}
          />
          :
          <EmptyScopingState
          // title="Ask AI about NOIR"
          // actionText="Generate NOIR"
          // onActionClick={handleGenerate}
          // secondaryActionText="Skip for now"
          // onSecondaryActionClick={handleSkip}
          />
      )}
    </CardContent>
  );

  const renderGeneratingState = () => (
    <CardContent>
      <EmptyScopingState
      // title="NOIR"
      // subtitle={
      //   <FadingTextCycler
      //     texts={[
      //       'Creating NOIR...',
      //       'Analyzing historical data...',
      //       'Generating insights...'
      //     ]}
      //   />
      // }
      />
    </CardContent>
  );

  const renderGeneratedState = () => (
    <>

      <Separator placement="horizontal" className={style.emailSeparator} />

      {isEditing ? (
        <EmailEdit
          subject={subjectContent}
          onSubjectChange={setSubjectContent}
          content={docContent}
          onContentChange={setDocContent}
          recipients={recipientsContent}
          onRecipientsChange={setRecipientsContent}
          recipientPlaceholder={NOIR_PLACEHOLDERS.RECIPIENTS}
          editorOptions={EDITOR_OPTIONS}
          editorContainerClassName={style.editorContainer}
        />
      ) : (
        <EmailView
          subject={viewModel.subject}
          teamLeadName={viewModel.teamLeadName}
          recipients={viewModel.recipients}
          content={docContent}
          contentClassName={style.htmlContent}
          rightSlotContent={
            /*
            <div className={style.sidePanel}>
              <div className={style.sideCard}>
                <div className={style.referenceDocsContainer}>
                  <FormGroup id="reference-docs-group" direction="vertical">
                    <FormItem>
                      <SelectInput
                        placeholder="Reference Documents"
                        model={[{ label: 'Reference Documents', value: 'refDocs' }]}
                        value="refDocs"
                        onValueChange={() => { }}
                      />
                    </FormItem>
                  </FormGroup>
                </div>
              </div>
            </div>
            */
            undefined
          }
        />
      )}

      <CardFooter>
        {isEditing ? (
          <RightSlot>
            <Stack direction="row" gap="xs2" grow={0}>
              <Button onClick={() => setIsEditing(false)} disabled={isSaving}>Cancel</Button>
              <Button variant="primary" onClick={handleSaveClick} loading={isSaving} disabled={isSaving}>Save</Button>
            </Stack>
          </RightSlot>
        ) : (
          <LeftSlot>
            <>
              <Button
                icon={<EditBoxSolid />}
                variant="link"
                onClick={() => setIsEditing(true)}
                disabled={!canManualEdit || sendState === 'loading' || sendState === 'sent'}
              >
                Edit
              </Button>
              <Button icon={<CloneSolid />} variant="link" onClick={() => {
                copyToClipboard(stripHtml(docContent));
                showSuccessToast('Content copied to clipboard');
              }}>
                Copy
              </Button>
            </>
          </LeftSlot>
        )}
      </CardFooter>
    </>
  );

  return (
    <div className={style.pageContainer}>
      <Card outlined radius="lg" raise="2-subtle">
        <CardHeader>
          <LeftSlot>
            <Stack gap="xs">
              <CardTitle content="NOIR Output" />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && (
            <RightSlot>
              <>
                {sendState === 'sent' ? (
                  <OutlineButton disabled>
                    {`${isRedirecting ? 'Redirecting to' : 'Redirecting to'} ${isDataGatheringEnabled ? 'Generate Data Gathering' : 'Generate Preliminary Research'}...`}
                  </OutlineButton>
                ) : (
                  <OutlineButton
                    icon={<EnvelopeOutline />}
                    onClick={handleSendNoirClick}
                    loading={sendState === 'loading'}
                    disabled={sendState === 'loading' || !canSendNoirEmail || !noirAccepted || isNoirPreviewAcceptancePending || isNoirPreviewModalVisible}
                  >
                    Send NOIR
                  </OutlineButton>
                )}
                <Button
                  icon={<DownloadSolid />}
                  variant="link"
                  size="sm"
                  onClick={handleDownloadNoirClick}
                // disabled={!canDownloadNoir}
                >
                  Download
                </Button>
              </>
            </RightSlot>
          )}

        </CardHeader>

        {generationState === 'empty' && renderEmptyState()}
        {generationState === 'generating' && renderGeneratingState()}
        {generationState === 'generated' && renderGeneratedState()}
      </Card>
    </div>
  );
};

export default NoirPage;
