import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  LeftSlot,
  Stack,
  Button,
  RightSlot,
  OutlineButton,
  CardFooter,
  Separator,
} from "@wadk/ui"
import { DownloadSolid, EditBoxSolid, EnvelopeOutline, CloneSolid } from '@wadk/icons'
import {
  EmailView,
  EmailEdit,
  EmptyScopingState,
  showSuccessToast,
  showErrorToast
} from '../../components';
import {
  NOIR_PLACEHOLDERS,
  GenerationState,
  SendState,
  NOIR_MESSAGES,
  NOIR_CONFIG,
  AUTO_REDIRECT_DELAY_MS,
  WORKFLOW_ACTIONS,
  TASK_DEFINITION_KEYS
} from '../../constants';
import {
  extractEmailSubject,
  extractEmailBody,
  formatPlainTextEmailBodyAsHtml,
  stripHtmlToText,
  copyToClipboard,
  stripHtml,
  downloadTextAsFile
} from '../../utils';
import { ScopingTabEnum, setNoirData, setNextAvailableActionsForPlan, setTaskDefinitionKeyForPlan } from '../../store/scopingSlice';
import { RootState, NoirViewModel } from './types';
import { getNoir, editNoir, sendNoir } from '../../api/noirClient';
import { usePlanId } from '../../hooks/usePlanId';
import { useWorkflowPermissions } from '../../hooks/useWorkflowPermissions';
import { useResolvedRecipientEmails } from '../../hooks/useResolvedRecipientEmails';
import style from './NoirPage.module.css';

/**
 * NoirPage Component
 * 
 * Displays and manages the state of a NOIR document. 
 * Allows users to generate, view, edit, and send NOIRs.
 * 
 * @returns {React.FC} The rendered NOIR Page component.
 */
const NoirPage: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const hasHtmlTags = (value: string): boolean => /<\/?[a-z][\s\S]*>/i.test(String(value || ''));
  const normalizeNoirBodyToEditorHtml = (body: string): string => {
    const rawBody = String(body || '');
    if (!rawBody.trim()) {
      return '';
    }

    if (!hasHtmlTags(rawBody)) {
      return formatPlainTextEmailBodyAsHtml(rawBody);
    }

    const parsed = new DOMParser().parseFromString(rawBody, 'text/html');
    const bodyNode = parsed.body;

    if (!bodyNode) {
      return rawBody;
    }

    const inner = (bodyNode.innerHTML || '').trim();
    const bodyStyle = (bodyNode.getAttribute('style') || '').trim();

    if (!inner) {
      return rawBody;
    }

    // If backend returns a full html/body document, render the body content inside a wrapper
    // so styles attached to <body> are preserved in EmailView.
    return bodyStyle ? `<div style="${bodyStyle}">${inner}</div>` : inner;
  };

  
  // Extract planId from route params
  const planId = usePlanId();
  const noirData = useSelector((state: RootState) => state.scoping?.noirData);
  const recipientsList = useSelector((state: RootState) => state.scoping?.recipients);
  const isGeneratingNoir = useSelector((state: RootState) => state.scoping?.isGeneratingNoir);
  const nextAvailableActionsByPlan = useSelector((state: RootState) => state.scoping?.nextAvailableActionsByPlan);
  const taskDefinitionKeyByPlan = useSelector((state: RootState) => state.scoping?.taskDefinitionKeyByPlan);
  const nextScopingTab = ScopingTabEnum.PRELIMINARY_RESEARCH;

  const [generationState, setGenerationState] = useState<GenerationState>(
    isGeneratingNoir ? 'generating' : noirData ? 'generated' : 'empty'
  );

  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [sendState, setSendState] = useState<SendState>('idle');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isGetNoirLoading, setIsGetNoirLoading] = useState<boolean>(false);
  const [disableButtons, setDisableButtons] = useState<boolean>(false);
  const [isRedirecting, setIsRedirecting] = useState<boolean>(false);
  const [noirAccepted, setNoirAccepted] = useState<boolean>(false);
  const [isNoirPreviewAcceptancePending, setIsNoirPreviewAcceptancePending] = useState<boolean>(false);
  const [isNoirPreviewModalVisible, setIsNoirPreviewModalVisible] = useState<boolean>(false);
  const redirectTimeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const shouldRefreshPlanStatusAfterGenerationRef = useRef(false);

  const normalizedPlanId = String(planId || '').trim();
  const hasNoirForCurrentPlan = !!planId && !!noirData && (() => {
    const noirPlanId = String(noirData?.original_data?.[0]?.['Plan Item Number'] || '').trim();
    return !noirPlanId || noirPlanId === normalizedPlanId;
  })();

  const { hasAction, hasActionForCurrentPlan, isTaskDefinition } = useWorkflowPermissions({
    currentPlanNumber: normalizedPlanId,
    nextAvailableActionsByPlan,
    taskDefinitionKeyByPlan,
    workflowPayload: noirData,
  });

  const isNoirTaskDefinition = isTaskDefinition(TASK_DEFINITION_KEYS.NOIR);
  const canGetNoirForCurrentPlan = hasActionForCurrentPlan(WORKFLOW_ACTIONS.GET_NOIR);
  const canManualEdit = hasAction(WORKFLOW_ACTIONS.EDIT_NOIR);
  const canSendNoirEmail = isNoirTaskDefinition && hasAction(WORKFLOW_ACTIONS.SEND_NOIR_EMAIL);

  const resolvedRecipientEmails = useResolvedRecipientEmails(noirData?.recipients, recipientsList);

  /**
   * Safely derives a flat View Model from the complex API data to be used in UI components.
   * Transforms raw API response/mock data into a standardized structure.
   */
  const viewModel: NoirViewModel = useMemo(() => {
    const data: any = noirData;
    const rawItem = data?.original_data?.[0];

    // Prefer the new separate subject and body from the API, fallback to extraction if needed.
    const emailBody = data?.body || extractEmailBody(data?.email || '');
    const subject = data?.subject || extractEmailSubject(data?.email || '');

    const formattedContent = normalizeNoirBodyToEditorHtml(emailBody);

    // Show placeholder only when no real recipients are available.
    const formattedRecipients = resolvedRecipientEmails.length > 0
      ? resolvedRecipientEmails.join(', ')
      : NOIR_PLACEHOLDERS.RECIPIENTS;

    return {
      planTitle: rawItem?.["Plan Item Title"] || "Untitled Plan",
      subject: subject,
      teamLeadName: rawItem?.["Coordinating Team Lead"] || "Unassigned",
      content: formattedContent,
      score: NOIR_PLACEHOLDERS.SCORE,
      recipients: formattedRecipients,
      aiRationale: NOIR_PLACEHOLDERS.RATIONALE,
    };
  }, [noirData, resolvedRecipientEmails]);

  useEffect(() => {
    if (generationState === 'generating') {
      setDisableButtons(true);
    }
  }, [generationState]);

  const [docContent, setDocContent] = useState<string>(viewModel.content);
  const [subjectContent, setSubjectContent] = useState<string>(viewModel.subject);
  const [recipientsContent, setRecipientsContent] = useState<string>(resolvedRecipientEmails.join(', '));

  /**
   * Synchronize local state when Redux store noirData changes.
   */
  useEffect(() => {
    if (isGeneratingNoir) {
      setGenerationState('generating');
    } else if (noirData) {
      setDocContent(viewModel.content);
      setSubjectContent(viewModel.subject);
      setRecipientsContent(resolvedRecipientEmails.join(', '));
      setGenerationState('generated');
    } else {
      setGenerationState('empty');
    }
  }, [noirData, isGeneratingNoir, resolvedRecipientEmails, viewModel.content, viewModel.subject]);

  useEffect(() => {
    if (!normalizedPlanId || isGeneratingNoir || hasNoirForCurrentPlan || !canGetNoirForCurrentPlan) {
      return;
    }

    let cancelled = false;

    const fetchNoirIfEmpty = async () => {
      setIsGetNoirLoading(true);
      try {
        const response = await getNoir(normalizedPlanId);
        if (cancelled || !response) return;

        const hasUsefulNoirContent = Boolean(
          response.subject ||
          response.body ||
          response.email ||
          (Array.isArray(response.original_data) && response.original_data.length > 0)
        );

        if (!hasUsefulNoirContent) return;
        dispatch(setNoirData(response));
        setNoirAccepted(true);
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'noir-loading' }
        }));
      } catch {
        // Intentionally no-op on error as requested.
      } finally {
        if (!cancelled) {
          setIsGetNoirLoading(false);
        }
      }
    };

    fetchNoirIfEmpty();

    return () => {
      cancelled = true;
    };
  }, [dispatch, hasNoirForCurrentPlan, isGeneratingNoir, normalizedPlanId, canGetNoirForCurrentPlan]);

  useEffect(() => {
    if (!normalizedPlanId || noirData || isGeneratingNoir) {
      return;
    }

    setGenerationState('empty');
  }, [isGeneratingNoir, noirData, normalizedPlanId]);

  useEffect(() => {
    if (!shouldRefreshPlanStatusAfterGenerationRef.current) {
      return;
    }

    if (generationState === 'generated') {
      window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
      shouldRefreshPlanStatusAfterGenerationRef.current = false;
    }
  }, [generationState]);

  
  // Enable Send NOIR only after the generated NOIR is accepted in the chat flow.
  useEffect(() => {
    const activePlanId = normalizedPlanId;

    const handleNoirAccepted = (event: Event) => {
      const customEvent = event as CustomEvent<{ noirData?: any; planId?: string }>;
      const acceptedPlanId = String(customEvent.detail?.planId || '').trim();
      if (acceptedPlanId && activePlanId && acceptedPlanId !== activePlanId) {
        return;
      }

      setNoirAccepted(true);
      setIsNoirPreviewAcceptancePending(false);
      setIsNoirPreviewModalVisible(false);
    };

    const handleNoirPreviewOpened = () => {
      setIsNoirPreviewAcceptancePending(true);
      setNoirAccepted(false);
    };

    const handleNoirPreviewVisibilityChanged = (event: Event) => {
      const customEvent = event as CustomEvent<{ planId?: string; visible?: boolean }>;
      setIsNoirPreviewModalVisible(Boolean(customEvent.detail?.visible));
    };

    window.addEventListener('noir:accepted', handleNoirAccepted);
    window.addEventListener('noir:preview-opened', handleNoirPreviewOpened);
    window.addEventListener('noir:preview-visibility-changed', handleNoirPreviewVisibilityChanged);
    return () => {
      window.removeEventListener('noir:accepted', handleNoirAccepted);
      window.removeEventListener('noir:preview-opened', handleNoirPreviewOpened);
      window.removeEventListener('noir:preview-visibility-changed', handleNoirPreviewVisibilityChanged);
    };
  }, [normalizedPlanId]);

  useEffect(() => {
    if (!noirData) {
      setNoirAccepted(false);
      setIsNoirPreviewAcceptancePending(false);
      setIsNoirPreviewModalVisible(false);
    }
  }, [noirData]);

  /**
   * Hide Generate NOIR CTA immediatelywhen AI Presenter triggers NOIR generation.
   */
  useEffect(() => {
    const handleGenerateNoirTriggered = () => {
      shouldRefreshPlanStatusAfterGenerationRef.current = true;
      setDisableButtons(true);
      setGenerationState('generating');
      setIsNoirPreviewAcceptancePending(true);
    };

    window.addEventListener('ai-chat:generate-noir', handleGenerateNoirTriggered);
    window.addEventListener('ai-chat:noir-generation-started', handleGenerateNoirTriggered);
    return () => {
      window.removeEventListener('ai-chat:generate-noir', handleGenerateNoirTriggered);
      window.removeEventListener('ai-chat:noir-generation-started', handleGenerateNoirTriggered);
    };
  }, []);

  // ===========================================================================
  // Handlers
  // ===========================================================================

  /**
   * Saves the user's edits to the NOIR document via API.
   */
  const handleSaveClick = async (): Promise<void> => {
    if (!canManualEdit) {
      showErrorToast(NOIR_MESSAGES.EDIT_NOT_ALLOWED_TITLE, NOIR_MESSAGES.EDIT_NOT_ALLOWED_DESCRIPTION);
      return;
    }

    setIsSaving(true);
    try {
      const originalData = noirData?.original_data || [];
      const payload = {
        plan_item_number: normalizedPlanId,
        noir: {
          subject: subjectContent,
          body: docContent
        }
      };

      const responseData = await editNoir(payload);

      const combinedText = `Subject: ${subjectContent}\n\nBody:\n${stripHtmlToText(docContent)}`;

      // Map the edit API response to match the expected NoirData structure
      const updatedNoirData = {
        ...(noirData || {}),
        email: responseData.email || combinedText,
        subject: responseData.subject || subjectContent,
        body: responseData.body || docContent,
        recipients: recipientsContent
          .split(',')
          .map(recipient => recipient.trim())
          .filter(recipient => recipient.length > 0),
        original_data: responseData.original_data || originalData
      };

      dispatch(setNoirData(updatedNoirData));
      showSuccessToast(NOIR_MESSAGES.UPDATE_SUCCESS);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update NOIR:', error);
      showErrorToast(NOIR_MESSAGES.UPDATE_ERROR_TITLE, NOIR_MESSAGES.UPDATE_ERROR_DESCRIPTION);
    } finally {
      setIsSaving(false);
    }
  };

  /**
   * Simulates sending the NOIR document and updates local send state.
   */
  const handleSendNoirClick = async (): Promise<void> => {
    if (!canSendNoirEmail) {
      showErrorToast(NOIR_MESSAGES.SEND_NOT_ALLOWED_TITLE, NOIR_MESSAGES.SEND_NOT_ALLOWED_DESCRIPTION);
      return;
    }

    try {
      // Parse recipients content from comma-separated string to array
      const recipientList = recipientsContent
        .split(',')
        .map(email => email.trim())
        .filter(email => email.length > 0);

      if (recipientList.length === 0) {
        showErrorToast(NOIR_MESSAGES.RECIPIENT_REQUIRED_TITLE, NOIR_MESSAGES.RECIPIENT_REQUIRED_DESCRIPTION);
        return;
      }

      setSendState('loading');

      const payload = {
        plan_item_number: normalizedPlanId,
        subject: subjectContent,
        body: docContent,
        to_recipients: recipientList,
        from_address: NOIR_CONFIG.fromAddress
      };

      const response = await sendNoir(payload);

      if (Array.isArray(response?.next_available_actions) && response.next_available_actions.length > 0) {
        dispatch(setNextAvailableActionsForPlan({
          planNumber: normalizedPlanId,
          actions: response.next_available_actions,
        }));
      }

      if (response?.task_definition_key) {
        dispatch(setTaskDefinitionKeyForPlan({
          planNumber: normalizedPlanId,
          taskDefinitionKey: response.task_definition_key,
        }));
      }

      setSendState('sent');
      showSuccessToast(NOIR_MESSAGES.SEND_SUCCESS);
    } catch (error) {
      console.error('Failed to send NOIR:', error);
      showErrorToast(NOIR_MESSAGES.SEND_ERROR_TITLE, NOIR_MESSAGES.SEND_ERROR_DESCRIPTION);
      setSendState('idle');
    }
  };

  useEffect(() => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (sendState === 'sent' && generationState === 'generated' && normalizedPlanId) {
      setIsRedirecting(true);
      redirectTimeoutRef.current = setTimeout(() => {
        navigate(`../${nextScopingTab}/${normalizedPlanId}`);
      }, AUTO_REDIRECT_DELAY_MS);
      return;
    }

    setIsRedirecting(false);
  }, [generationState, navigate, nextScopingTab, normalizedPlanId, sendState]);

  useEffect(() => () => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }
  }, []);

  /**
   * Downloads the NOIR email content as a .txt file.
   */
  const handleDownloadNoirClick = (): void => {
    const subject = (subjectContent || '').trim();
    const body = stripHtmlToText(docContent || '');

    if (!subject && !body) {
      showErrorToast(NOIR_MESSAGES.DOWNLOAD_ERROR_TITLE, NOIR_MESSAGES.DOWNLOAD_ERROR_DESCRIPTION);
      return;
    }

    const content = `Subject: ${subject}\n\nBody:\n${body}`;
    const filePlanNumber = normalizedPlanId || 'unknown';
    downloadTextAsFile(content, `noir_email_${filePlanNumber}.txt`);
    showSuccessToast(NOIR_MESSAGES.DOWNLOAD_SUCCESS);
  };

  // ===========================================================================
  // Render Helpers
  // ===========================================================================

  const renderEmptyState = () => (
    <CardContent>
      {isGetNoirLoading ? (
        <EmptyScopingState
          subtitle={
            <>Loading......</>
          }
        />
      ) : (
        <EmptyScopingState />
      )}
    </CardContent>
  );

  const renderGeneratingState = () => (
    <CardContent>
      <EmptyScopingState />
    </CardContent>
  );

  const renderGeneratedState = () => (
    <>

      <Separator placement="horizontal" className={style.emailSeparator} />

      {isEditing ? (
        <EmailEdit
          subject={subjectContent}
          onSubjectChange={setSubjectContent}
          content={docContent}
          onContentChange={setDocContent}
          recipients={recipientsContent}
          onRecipientsChange={setRecipientsContent}
          recipientPlaceholder={NOIR_PLACEHOLDERS.RECIPIENTS}
        />
      ) : (
        <EmailView
          subject={viewModel.subject}
          teamLeadName={viewModel.teamLeadName}
          recipients={viewModel.recipients}
          content={docContent}
          contentClassName={style.htmlContent}
          rightSlotContent={undefined}
        />
      )}

      <CardFooter>
        {isEditing ? (
          <LeftSlot>
            <Stack direction="row" gap="xs2" grow={0}>
              <Button onClick={() => setIsEditing(false)} disabled={isSaving}>Cancel</Button>
              <Button variant="primary" onClick={handleSaveClick} loading={isSaving} disabled={isSaving}>Save</Button>
            </Stack>
          </LeftSlot>
        ) : (
          <LeftSlot>
            <>
              <Button
                icon={<EditBoxSolid />}
                variant="link"
                onClick={() => setIsEditing(true)}
                disabled={!canManualEdit || sendState === 'loading' || sendState === 'sent'}
              >
                Edit
              </Button>
              <Button icon={<CloneSolid />} variant="link" onClick={() => {
                copyToClipboard(stripHtml(docContent));
                showSuccessToast(NOIR_MESSAGES.COPY_SUCCESS);
              }}>
                Copy
              </Button>
            </>
          </LeftSlot>
        )}
      </CardFooter>
    </>
  );

  return (
    <div className={style.pageContainer}>
      <Card outlined radius="lg" raise="2-subtle">
        <CardHeader>
          <LeftSlot>
            <Stack gap="xs">
              <CardTitle content="NOIR Output" />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && (
            <RightSlot>
              <>
                {sendState === 'sent' ? (
                  <OutlineButton disabled>
                    {`${isRedirecting ? 'Redirecting to' : 'Redirecting to'} Generate Preliminary Research...`}
                  </OutlineButton>
                ) : (
                  <OutlineButton
                    icon={<EnvelopeOutline />}
                    onClick={handleSendNoirClick}
                    loading={sendState === 'loading'}
                    disabled={isEditing || sendState === 'loading' || !canSendNoirEmail || !noirAccepted || isNoirPreviewAcceptancePending || isNoirPreviewModalVisible}
                  >
                    Accept and Send NOIR
                  </OutlineButton>
                )}
                <Button
                  icon={<DownloadSolid />}
                  variant="link"
                  size="sm"
                  onClick={handleDownloadNoirClick}
                >
                  Download
                </Button>
              </>
            </RightSlot>
          )}

        </CardHeader>

        {generationState === 'empty' && renderEmptyState()}
        {generationState === 'generating' && renderGeneratingState()}
        {generationState === 'generated' && renderGeneratedState()}
      </Card>
    </div>
  );
};

export default NoirPage;
