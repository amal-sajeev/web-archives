import { ScopingState } from '../../store/scopingSlice';

export interface RootState {
  scoping: ScopingState;
}

export interface NoirViewModel {
  planTitle: string;
  subject: string;
  teamLeadName: string;
  content: string;
  score: string;
  recipients: string;
  aiRationale: string;
}
