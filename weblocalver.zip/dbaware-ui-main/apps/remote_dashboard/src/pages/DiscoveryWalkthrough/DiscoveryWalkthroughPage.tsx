import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  LeftSlot,
  Stack,
  Button,
  RightSlot,
  CardFooter,
  Text,
  Separator,
  PopoverTrigger,
  Popover,
  PopoverSurface,
  OutlineButton,
  FormGroup, FormItem
} from "@wadk/ui";
import { EditBoxSolid, CloneSolid } from '@wadk/icons';

import { ScopingTabEnum } from '../../store/scopingSlice';
import { setDiscoveryWalkthroughData } from '../../store/discoveryWalkthroughSlice';
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';
import { copyToClipboard, markdownToEditorHtml, editorHtmlToMarkdown, SECTION_EDITOR_OPTIONS } from '../../utils';
import { EmptyScopingState, FadingTextCycler, showSuccessToast, showErrorToast, AiRationalIcon } from '../../components';
import { AUTO_REDIRECT_DELAY_MS, GenerationState, ApprovalState, DISCOVERY_WALKTHROUGH_MESSAGES } from '../../constants';
import { acceptDiscoveryWalkthrough, getDiscoveryWalkthrough, updateDiscoveryWalkthrough, generateDiscoveryWalkthrough, downloadDiscoveryWalkthrough } from '../../api/procedureClient';
import { getDashboardRouteParams } from '../../utils';
import type {
  DiscoveryWalkthroughData,
  DiscoveryWalkthroughRootState,
  DiscoveryWalkthroughSection,
  EditingSectionsState
} from './types';
import style from './DiscoveryWalkthroughPage.module.css';
import 'com.db.rca.commons.afcc-components/style.css';

// Generation requests currently running, keyed by plan number. Module scope so they
// outlive the page component when the user switches tabs.
const inFlightDiscoveryWalkthroughGeneration = new Map<string, Promise<boolean>>();

const ALLOWED_BOLD_LABELS = new Set(['findings:', 'kod:']);

const shouldRenderAsBoldLabel = (value: string): boolean => {
  const normalized = value.trim().toLowerCase();
  if (ALLOWED_BOLD_LABELS.has(normalized)) return true;

  // Also allow label-like markdown tokens such as "Control/Risk:" or "Assumption:"
  // when they are explicitly wrapped with **...**.
  return /^[a-z0-9][a-z0-9\s/&()_-]*:\s*$/i.test(normalized);
};


const formatInlineMarkdown = (text: string): React.ReactNode[] => {
  const tokens: React.ReactNode[] = [];
  const pattern = /(\*\*[^*]+\*\*|\*[^*]+\*)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      tokens.push(text.slice(lastIndex, match.index));
    }

    const value = match[0];
    if (value.startsWith('**') && value.endsWith('**')) {
      const boldCandidate = value.slice(2, -2);
      if (shouldRenderAsBoldLabel(boldCandidate)) {
        tokens.push(
          <span key={`${match.index}-b`} className={style.inlineStrong}>
            {boldCandidate}
          </span>
        );
      } else {
        tokens.push(boldCandidate);
      }
    } else if (value.startsWith('*') && value.endsWith('*')) {
      tokens.push(
        <span key={`${match.index}-i`} className={style.inlineSubheading}>
          {value.slice(1, -1)}
        </span>
      );
    } else {
      tokens.push(value);
    }

    lastIndex = pattern.lastIndex;
  }

  if (lastIndex < text.length) {
    tokens.push(text.slice(lastIndex));
  }

  return tokens;
};

const renderKeyPoint = (point: string, pointIndex: number) => {
  const leadingSpaces = point.match(/^\s*/)?.[0].length ?? 0;
  const trimmed = point.trim();
  const isBullet = trimmed.startsWith('- ');
  const bulletContent = isBullet ? trimmed.slice(2).trim() : trimmed;
  const isSubheadingOnly = /^\*[^*]+\*$/.test(bulletContent);
  const nestingLevel = Math.floor(leadingSpaces / 2);

  if (isSubheadingOnly) {
    return (
      <div
        key={pointIndex}
        className={style.subheadingLine}
        style={{ marginLeft: `${Math.max(0, nestingLevel) * 16}px` }}
      >
        <Text>{formatInlineMarkdown(bulletContent)}</Text>
      </div>
    );
  }

  if (isBullet) {
    return (
      <div
        key={pointIndex}
        className={style.bulletLine}
        style={{ marginLeft: `${Math.max(0, nestingLevel) * 16}px` }}
      >
        <span className={style.bulletMarker}>•</span>
        <Text>{formatInlineMarkdown(bulletContent)}</Text>
      </div>
    );
  }

  return (
    <div key={pointIndex} className={style.headingLine}>
      <Text>{formatInlineMarkdown(trimmed)}</Text>
    </div>
  );
};

/**
 * DiscoveryWalkthroughPage component.
 * Displays and manages the generated Discovery Walkthrough document.
 * Allows users to edit the document, approve the result, or download it.
 */
const DiscoveryWalkthroughPage: React.FC = () => {
  const location = useLocation();
  const { planId } = getDashboardRouteParams(location.pathname);

  const walkthroughData = useSelector((state: DiscoveryWalkthroughRootState) =>
    planId ? state.discoveryWalkthrough?.reports?.[planId] : undefined
  );
  const nextAvailableActionsByPlan = useSelector((state: any) => state.scoping?.nextAvailableActionsByPlan);
  const taskDefinitionKeyByPlan = useSelector((state: any) => state.scoping?.taskDefinitionKeyByPlan);

  const [generationState, setGenerationState] = useState<GenerationState>(
    walkthroughData ? 'generated' : 'empty'
  );
  const [editingSections, setEditingSections] = useState<EditingSectionsState>({});
  const [selectedSectionIndex, setSelectedSectionIndex] = useState<number>(0);
  const [approveState, setApproveState] = useState<ApprovalState>('idle');
  const [isGetApiLoading, setIsGetApiLoading] = useState<boolean>(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const redirectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [isRedirectingToScope, setIsRedirectingToScope] = useState(false);

  const currentPlanNumber = String(planId || '').trim();
  const availableWorkflowActions = useMemo(() => {
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];

    return Array.from(new Set(actionsFromPlan))
      .map((action: unknown) => String(action || '').trim().toUpperCase())
      .filter(Boolean);
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const taskDefinitionKey = useMemo(() => {
    const fromPlan = String(taskDefinitionKeyByPlan?.[currentPlanNumber] ?? '').trim();
    return fromPlan.replace(/[\s-]+/g, '_').toUpperCase();
  }, [taskDefinitionKeyByPlan, currentPlanNumber]);

  const isDiscoveryWalkthroughTaskDefinition =
    taskDefinitionKey === 'DISCOVERY_WALKTHROUGH' ||
    taskDefinitionKey === 'DISCOVERY_WALKTHROUGH_AGENDA';
  const isCurrentTabActionable = !taskDefinitionKey || isDiscoveryWalkthroughTaskDefinition;

  const canUpdateDiscoveryWalkthrough =
    isCurrentTabActionable && (!isDiscoveryWalkthroughTaskDefinition || availableWorkflowActions.includes('UPDATE_DISCOVERY_WALKTHROUGH'));
  const canGetDiscoveryWalkthrough =
    availableWorkflowActions.includes('GET_DISCOVERY_WALKTHROUGH');
  const canDownloadDiscoveryWalkthrough =
    !isDiscoveryWalkthroughTaskDefinition || availableWorkflowActions.includes('DOWNLOAD_DISCOVERY_WALKTHROUGH');
  const canAcceptDiscoveryWalkthrough =
    isCurrentTabActionable && (!isDiscoveryWalkthroughTaskDefinition || availableWorkflowActions.includes('ACCEPT_DISCOVERY_WALKTHROUGH'));

  const handleEditSection = (index: number, section: DiscoveryWalkthroughSection) => {
    if (!canUpdateDiscoveryWalkthrough) {
      showErrorToast('Action not available', 'UPDATE_DISCOVERY_WALKTHROUGH is not available for this plan.');
      return;
    }

    setEditingSections(prev => ({
      ...prev,
      [index]: {
        title: section.section_title,
        content: markdownToEditorHtml(
          section.key_points
            .map(point => String(point).trim().replace(/^- /, '* '))
            .join('\n')
        )
      }
    }));
  };

  const handleCancelSection = (index: number) => {
    setEditingSections(prev => {
      const next = { ...prev };
      delete next[index];
      return next;
    });
  };

  const handleSaveSection = async (index: number) => {
    if (!canUpdateDiscoveryWalkthrough) {
      showErrorToast('Action not available', 'UPDATE_DISCOVERY_WALKTHROUGH is not available for this plan.');
      return;
    }

    if (!walkthroughData || !planId) return;
    const edited = editingSections[index];
    if (!edited) return;

    const newSections = [...(walkthroughData.sections || [])];
    newSections[index] = {
      ...newSections[index],
      section_title: edited.title,
      key_points: editorHtmlToMarkdown(edited.content)
        .split('\n')
        .map(s => s.trim().replace(/^\* /, '- '))
        .filter(s => s !== '')
    };
    const updatedData = {
      ...walkthroughData,
      sections: newSections
    };

    try {
      await updateDiscoveryWalkthrough({
        ...updatedData,
        planNumber: planId
      });
      dispatch(setDiscoveryWalkthroughData({ planNumber: planId, data: updatedData }));
      handleCancelSection(index);
      showSuccessToast(DISCOVERY_WALKTHROUGH_MESSAGES.UPDATE_SUCCESS || "Section updated successfully");
    } catch (error) {
      console.error("Failed to update section:", error);
      showErrorToast('Failed to update section', 'Could not save this section.');
    }
  };

  /**
   * Initiates the approval sequence for the generated Discovery Walkthrough.
   */
  const handleApproveClick = async () => {
    if (!canAcceptDiscoveryWalkthrough) {
      showErrorToast('Action not available', 'ACCEPT_DISCOVERY_WALKTHROUGH is not available for this plan.');
      return;
    }

    if (!planId) {
      showErrorToast('Failed to approve discovery walkthrough', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await acceptDiscoveryWalkthrough(planId);
      setApproveState('approved');
      showSuccessToast(DISCOVERY_WALKTHROUGH_MESSAGES.APPROVE_SUCCESS);
    } catch (error) {
      console.error('Failed to approve discovery walkthrough:', error);
      setApproveState('idle');
      showErrorToast('Failed to approve discovery walkthrough', 'Could not approve the document.');
    }
  };

  useEffect(() => {
    const handleGenerate = () => {
      if (!planId) {
        return;
      }
      setGenerationState('generating');
    };
    window.addEventListener('ai-chat:generate-discovery-walkthrough', handleGenerate);
    return () => window.removeEventListener('ai-chat:generate-discovery-walkthrough', handleGenerate);
  }, [planId]);

  useEffect(() => {
    if (walkthroughData) {
      setGenerationState('generated');
      setSelectedSectionIndex(0);
    } else {
      setGenerationState('empty');
    }
    setEditingSections({});
  }, [planId, walkthroughData]);

  useEffect(() => {
    if (!planId || walkthroughData || generationState === 'generating' || !canGetDiscoveryWalkthrough) {
      return;
    }

    let cancelled = false;

    const fetchDiscoveryWalkthroughIfEmpty = async () => {
      setIsGetApiLoading(true);
      try {
        const response = await getDiscoveryWalkthrough({ planNumber: planId });
        if (cancelled || !response) return;

        const hasUsefulDiscoveryData =
          Boolean(response.report_title) ||
          (Array.isArray(response.sections) && response.sections.length > 0);

        if (!hasUsefulDiscoveryData) return;

        dispatch(setDiscoveryWalkthroughData({ planNumber: planId, data: response }));
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'discovery-walkthrough-loading' }
        }));
      } catch {
        // Intentionally no-op on error as requested.
      } finally {
        setIsGetApiLoading(false);
      }
    };

    fetchDiscoveryWalkthroughIfEmpty();

    return () => {
      cancelled = true;
    };
  }, [dispatch, generationState, planId, walkthroughData, canGetDiscoveryWalkthrough]);
  // Re-attach to a generation that is still running after returning to this tab.
  useEffect(() => {
    if (planId && inFlightDiscoveryWalkthroughGeneration.has(planId) && !walkthroughData) {
      setGenerationState('generating');
    }
  }, [planId, walkthroughData]);

  useEffect(() => {
    if (generationState !== 'generating' || !planId) {
      return;
    }

    let isMounted = true;

    // One request per plan, held at module scope so it survives tab switches and remounts.
    let request = inFlightDiscoveryWalkthroughGeneration.get(planId);
    if (!request) {
      const targetPlan = planId;
      request = (async () => {
        try {
          const response = await generateDiscoveryWalkthrough({ planNumber: targetPlan });
          const candidate = response as { data?: DiscoveryWalkthroughData; payload?: DiscoveryWalkthroughData };
          const dataToStore = candidate.data || candidate.payload || response as DiscoveryWalkthroughData;
          dispatch(setDiscoveryWalkthroughData({ planNumber: targetPlan, data: dataToStore }));
          window.dispatchEvent(new CustomEvent('discovery-walkthrough:sync', {
            detail: {
              planNumber: targetPlan,
              status: 'completed',
              message: 'Discovery Walkthrough has been generated successfully.',
            }
          }));
          window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
          return true;
        } catch (error) {
          console.error('Failed to get or generate discovery walkthrough data:', error);
          window.dispatchEvent(new CustomEvent('discovery-walkthrough:sync', {
            detail: {
              planNumber: targetPlan,
              status: 'failed',
              message: 'Failed to generate Discovery Walkthrough. Please try again.',
            }
          }));
          return false;
        } finally {
          inFlightDiscoveryWalkthroughGeneration.delete(targetPlan);
        }
      })();
      inFlightDiscoveryWalkthroughGeneration.set(targetPlan, request);
    }

    request.then((succeeded) => {
      if (isMounted) {
        setGenerationState(succeeded ? 'generated' : 'empty');
      }
    });

    return () => {
      isMounted = false;
    };
  }, [generationState, dispatch, planId]);

  useEffect(() => {
    return () => {
      if (redirectTimeoutRef.current) clearTimeout(redirectTimeoutRef.current);
    };
  }, []);

  /**
   * Navigates to the Scope Recommendation tab.
   */
  useEffect(() => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (generationState === 'generated' && approveState === 'approved' && planId) {
      setIsRedirectingToScope(true);
      redirectTimeoutRef.current = setTimeout(() => {
        navigate(`../${ScopingTabEnum.SCOPE_RECOMMENDATION}/${planId}`);
      }, AUTO_REDIRECT_DELAY_MS);
      return;
    }

    setIsRedirectingToScope(false);
  }, [approveState, generationState, navigate, planId]);

  const handleGenerateClick = useCallback(() => {
    if (!planId) {
      showErrorToast('Failed to generate Discovery Walkthrough', 'Plan number is not available.');
      return;
    }

    window.dispatchEvent(new CustomEvent('ai-chat:trigger-generate-discovery-walkthrough'));
  }, [planId]);

  /**
   * Triggers a file download containing the Discovery Walkthrough content.
   */
  const handleDownloadClick = async () => {
    if (!canDownloadDiscoveryWalkthrough) {
      showErrorToast('Action not available', 'DOWNLOAD_DISCOVERY_WALKTHROUGH is not available for this plan.');
      return;
    }

    if (!walkthroughData || !planId) return;

    try {
      const response = await downloadDiscoveryWalkthrough({
        planNumber: planId,
        report_title: walkthroughData.report_title,
        sections: walkthroughData.sections
      });

      // Ensure we treat the response as a blob and set the correct PDF type
      const blob = new Blob([(response as any).data || response], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `discovery_walkthrough_${planId}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Failed to download discovery walkthrough data:", error);
    }
  };

  const rationale = walkthroughData?.rationale || "AI analyzed 5 similar past reviews and relevant policy documents. Standard scope drivers were mapped based on identified framework gaps and historical findings. [1.0]";
  const confidenceScore = walkthroughData?.confidence_score ?? walkthroughData?.metadata?.confidence_score ?? walkthroughData?.metadata?.section_confidence_score ?? 100;

  let confidenceText = 'HIGH';
  if (confidenceScore >= 90) confidenceText = 'VERY HIGH';
  else if (confidenceScore >= 70) confidenceText = 'HIGH';
  else if (confidenceScore >= 50) confidenceText = 'MEDIUM';
  else confidenceText = 'LOW';

  const selectedSection = walkthroughData?.sections?.[selectedSectionIndex];
  const isSelectedSectionEditing = Boolean(editingSections[selectedSectionIndex]);

  return (
    <div className={style.pageContainer}>
      <Card
        outlined
        radius="lg"
        raise="2-subtle"
      >
        <CardHeader>
          <LeftSlot>
            <Stack>
              <CardTitle content="Discovery Walkthrough Output" />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && walkthroughData && (
            <RightSlot>
              <Stack direction="row" align="center" justifyContent="end" gap="xs">
                {approveState === 'approved' ? (
                  <OutlineButton disabled>
                    Redirecting to Generate Scope Recommendation...
                  </OutlineButton>
                ) : (
                  <OutlineButton
                    onClick={handleApproveClick}
                    loading={approveState === 'loading'}
                    disabled={approveState === 'loading' || !canAcceptDiscoveryWalkthrough}
                  >
                    Approve Result
                  </OutlineButton>
                )}
                <OutlineButton onClick={handleDownloadClick} disabled={!canDownloadDiscoveryWalkthrough}>Download Result</OutlineButton>
              </Stack>
            </RightSlot>
          )}
        </CardHeader>

        {generationState !== 'generated' || !walkthroughData ? (
          <CardContent>
            <EmptyScopingState
              subtitle={isGetApiLoading ? 'loading...........' : undefined}
            // title="Ask AI about Discovery Walkthrough"
            // subtitle={
            //   generationState === 'empty'
            //     ? 'Generate the discovery walkthrough to get started.'
            //     : <FadingTextCycler
            //       texts={[
            //         'Creating Discovery Walkthrough...',
            //         'Analyzing historical data...',
            //         'Generating insights...'
            //       ]}
            //     />
            // }
            // actionText={generationState === 'empty' ? 'Generate Discovery Walkthrough' : undefined}
            // onActionClick={generationState === 'empty' ? handleGenerateClick : undefined}
            />
          </CardContent>
        ) : (
          <>
            <Separator placement="horizontal" className={style.topSeparator} />

            <CardContent>
              <Stack direction="row" align="center" justifyContent="space-between">
                <LeftSlot>
                  <Text fontWeight="bold" className={style.titleText}>{walkthroughData.report_title}</Text>
                </LeftSlot>
                <RightSlot>
                  <div className={style.sideContent}>
                    <div className={style.aiRationaleContainer}>
                      <Text variant="secondary" className={style.confidenceText}>
                        Confidence Score : <span className={style.confidenceValue}>{confidenceText} ({confidenceScore}%)</span>
                      </Text>
                      <Separator placement="vertical" />
                      <Popover>
                        <PopoverTrigger>
                          <Button variant="link" icon={<AiRationalIcon />}>View AI Rationale</Button>
                        </PopoverTrigger>
                        <PopoverSurface placement="bottom-end" title="AI Rationale" closable>
                          <Text className={style.aiRationaleText}>{rationale}</Text>
                        </PopoverSurface>
                      </Popover>
                    </div>
                  </div>
                </RightSlot>
              </Stack>

              <div className={style.contentLayout}>
                <div className={style.scrollableSections}>
                  <Stack direction="column" gap="lg">
                    {walkthroughData.sections?.map((section: DiscoveryWalkthroughSection, index) => (
                      <div
                        key={`${section.section_title}-${index}`}
                        className={style.sectionContainer}
                        onClick={() => setSelectedSectionIndex(index)}
                      >
                        {editingSections[index] ? (
                          <Card outlined className={style.editCard}>
                            <CardContent>
                              <Stack direction="column" gap="md">
                                <Text fontWeight="bold">{editingSections[index].title}</Text>
                                <FormGroup id={`sec-points-${index}`} label="Key Points (one per line)" direction="vertical">
                                  <FormItem>
                                    <RichTextEditor
                                      value={editingSections[index].content}
                                      options={SECTION_EDITOR_OPTIONS}
                                      onValueChange={(val: string) => {
                                        setEditingSections(prev => (
                                          prev[index] ? { ...prev, [index]: { ...prev[index], content: val } } : prev
                                        ));
                                      }}
                                    />
                                  </FormItem>
                                </FormGroup>
                              </Stack>
                            </CardContent>
                          </Card>
                        ) : (
                          <div className={style.sectionView}>
                            <Stack direction="row" justifyContent="space-between" align="center" className={style.sectionHeader}>
                              <LeftSlot>
                                <Text fontWeight="bold" size="lg" className={style.sectionHighlight}>{section.section_title}</Text>

                              </LeftSlot>
                            </Stack>
                            <div className={style.keyPointsBlock}>
                              {section.key_points.map((point: string, pointIndex: number) => renderKeyPoint(point, pointIndex))}
                            </div>
                          </div>
                        )}
                        {index < walkthroughData.sections.length - 1 && <Separator placement="horizontal" className={style.sectionSeparator} />}
                      </div>
                    ))}
                  </Stack>
                </div>
              </div>
            </CardContent>
            <Separator placement="horizontal" />
            <CardFooter>
              <LeftSlot>
                <Stack direction="row" gap="xs">
                  {isSelectedSectionEditing ? (
                    <>
                      <Button onClick={() => handleCancelSection(selectedSectionIndex)}>Cancel</Button>
                      <Button variant="primary" onClick={() => void handleSaveSection(selectedSectionIndex)}>Save</Button>
                    </>
                  ) : (
                    <>
                      <Button
                        aria-label={selectedSection ? `Edit ${selectedSection.section_title}` : 'Edit section'}
                        icon={<EditBoxSolid />}
                        variant="link"
                        disabled={!selectedSection || !canUpdateDiscoveryWalkthrough}
                        onClick={() => {
                          if (selectedSection) {
                            handleEditSection(selectedSectionIndex, selectedSection);
                          }
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        aria-label={selectedSection ? `Copy ${selectedSection.section_title}` : 'Copy section'}
                        icon={<CloneSolid />}
                        variant="link"
                        disabled={!selectedSection}
                        onClick={() => {
                          if (!selectedSection) return;
                          const text = `${selectedSection.section_title}\n` + selectedSection.key_points.map((p: string) => `• ${p}`).join('\n');
                          copyToClipboard(text).then((success) => {
                            if (success) {
                              showSuccessToast("Section copied to clipboard");
                            }
                          });
                        }}
                      >
                        Copy
                      </Button>
                    </>
                  )}
                </Stack>
              </LeftSlot>
            </CardFooter>
          </>
        )}
      </Card>
    </div>
  );
};

export default DiscoveryWalkthroughPage;
