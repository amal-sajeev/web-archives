/**
 * Props for the DiscoveryWalkthroughPage component.
 */
export interface DiscoveryWalkthroughPageProps {}

export interface DiscoveryWalkthroughSection {
	section_title: string;
	key_points: string[];
}

export interface DiscoveryWalkthroughData {
	report_title: string;
	sections: DiscoveryWalkthroughSection[];
	rationale?: string;
	confidence_score?: number;
	metadata?: {
		confidence_score?: number;
		section_confidence_score?: number;
	};
}

export interface DiscoveryWalkthroughRootState {
	discoveryWalkthrough?: {
		reports?: Record<string, DiscoveryWalkthroughData | undefined>;
	};
}

export type EditingSectionsState = Record<number, { title: string; content: string }>;

