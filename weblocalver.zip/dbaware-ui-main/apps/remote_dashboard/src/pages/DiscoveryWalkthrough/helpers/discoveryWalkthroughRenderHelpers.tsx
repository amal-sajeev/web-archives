import React from 'react';
import { Text } from "@wadk/ui";
import { shouldRenderAsBoldLabel } from './DiscoveryWalkthrough.helpers';

type StyleClasses = {
  inlineStrong: string;
  inlineSubheading: string;
  subheadingLine: string;
  bulletLine: string;
  bulletMarker: string;
  headingLine: string;
};

export const formatInlineMarkdown = (
  text: string,
  styleClasses: StyleClasses
): React.ReactNode[] => {
  const tokens: React.ReactNode[] = [];
  const pattern = /(\*\*[^*]+\*\*|\*[^*]+\*)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      tokens.push(text.slice(lastIndex, match.index));
    }

    const value = match[0];
    if (value.startsWith('**') && value.endsWith('**')) {
      const boldCandidate = value.slice(2, -2);
      if (shouldRenderAsBoldLabel(boldCandidate)) {
        tokens.push(
          <span key={`${match.index}-b`} className={styleClasses.inlineStrong}>
            {boldCandidate}
          </span>
        );
      } else {
        tokens.push(boldCandidate);
      }
    } else if (value.startsWith('*') && value.endsWith('*')) {
      tokens.push(
        <span key={`${match.index}-i`} className={styleClasses.inlineSubheading}>
          {value.slice(1, -1)}
        </span>
      );
    } else {
      tokens.push(value);
    }

    lastIndex = pattern.lastIndex;
  }

  if (lastIndex < text.length) {
    tokens.push(text.slice(lastIndex));
  }

  return tokens;
};

export const renderKeyPoint = (
  point: string,
  pointIndex: number,
  styleClasses: StyleClasses
): React.ReactElement => {
  const leadingSpaces = point.match(/^\s*/)?.[0].length ?? 0;
  const trimmed = point.trim();
  const isBullet = trimmed.startsWith('- ');
  const bulletContent = isBullet ? trimmed.slice(2).trim() : trimmed;
  const isSubheadingOnly = /^\*[^*]+\*$/.test(bulletContent);
  const nestingLevel = Math.floor(leadingSpaces / 2);

  if (isSubheadingOnly) {
    return (
      <div
        key={pointIndex}
        className={styleClasses.subheadingLine}
        style={{ marginLeft: `${Math.max(0, nestingLevel) * 16}px` }}
      >
        <Text>{formatInlineMarkdown(bulletContent, styleClasses)}</Text>
      </div>
    );
  }

  if (isBullet) {
    return (
      <div
        key={pointIndex}
        className={styleClasses.bulletLine}
        style={{ marginLeft: `${Math.max(0, nestingLevel) * 16}px` }}
      >
        <span className={styleClasses.bulletMarker}>•</span>
        <Text>{formatInlineMarkdown(bulletContent, styleClasses)}</Text>
      </div>
    );
  }

  return (
    <div key={pointIndex} className={styleClasses.headingLine}>
      <Text>{formatInlineMarkdown(trimmed, styleClasses)}</Text>
    </div>
  );
};
