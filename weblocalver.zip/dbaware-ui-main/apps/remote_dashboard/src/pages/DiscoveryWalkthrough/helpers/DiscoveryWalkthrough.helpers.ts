import type { DiscoveryWalkthroughData } from '../types';

const ALLOWED_BOLD_LABELS = new Set(['findings:', 'kod:']);

type ConfidenceText = 'VERY HIGH' | 'HIGH' | 'MEDIUM' | 'LOW';

export interface DiscoveryWalkthroughConfidenceSummary {
  rationale: string;
  confidenceScore: number;
  confidenceText: ConfidenceText;
}

export const shouldRenderAsBoldLabel = (value: string): boolean => {
  const normalized = value.trim().toLowerCase();
  if (ALLOWED_BOLD_LABELS.has(normalized)) return true;

  // Also allow label-like markdown tokens such as "Control/Risk:" or "Assumption:"
  // when they are explicitly wrapped with **...**.
  return /^[a-z0-9][a-z0-9\s/&()_-]*:\s*$/i.test(normalized);
};

export const getRationaleAndConfidenceSummary = (
  walkthroughData?: DiscoveryWalkthroughData
): DiscoveryWalkthroughConfidenceSummary => {
  const rationale = walkthroughData?.rationale || 'No rationale available.';
  const rawConfidenceScore = walkthroughData?.confidence_score
    ?? walkthroughData?.metadata?.confidence_score
    ?? walkthroughData?.metadata?.section_confidence_score
    ?? 100;
  const confidenceScore = Number.isFinite(Number(rawConfidenceScore))
    ? Number(rawConfidenceScore)
    : 100;

  let confidenceText: ConfidenceText = 'LOW';
  if (confidenceScore >= 90) confidenceText = 'VERY HIGH';
  else if (confidenceScore >= 70) confidenceText = 'HIGH';
  else if (confidenceScore >= 50) confidenceText = 'MEDIUM';

  return {
    rationale,
    confidenceScore,
    confidenceText,
  };
};
