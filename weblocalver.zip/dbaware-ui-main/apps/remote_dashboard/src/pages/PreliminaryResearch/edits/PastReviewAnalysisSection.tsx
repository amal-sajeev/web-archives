import React, { useEffect, useMemo, useState } from 'react';
import { Text } from '@wadk/ui';
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';
import 'com.db.rca.commons.afcc-components/style.css';
import { PastReviewAnalysisData, PastReviewEditMeta, PastReviewGroupedItems } from '../types';
import { markdownToEditorHtml, editorHtmlToMarkdown } from './PolicyKodRegulatoryAnalysisSection';
import style from '../tabs/PastReviewAnalysisSection.module.css';

// Past review fields are saved as single-line text, so only bold is offered here.
const PAST_REVIEW_FIELD_EDITOR_OPTIONS = {
  placeholder: 'Edit content...',
  formats: ['bold', 'underline'],
  modules: { toolbar: [['bold']] },
};

interface MarkdownFieldEditorProps {
  value: string;
  onChange: (markdown: string) => void;
}

/** Rich text editor for one field; value in/out is `**bold**` text. Initialised once on mount. */
const MarkdownFieldEditor: React.FC<MarkdownFieldEditorProps> = ({ value, onChange }) => {
  const [html, setHtml] = useState<string>(() => markdownToEditorHtml(String(value || '')));
  return (
    <RichTextEditor
      value={html}
      options={PAST_REVIEW_FIELD_EDITOR_OPTIONS}
      onValueChange={(next: string) => {
        setHtml(next);
        onChange(editorHtmlToMarkdown(next));
      }}
    />
  );
};

interface PastReviewAnalysisSectionProps {
  data: PastReviewAnalysisData;
  planId?: string;
  title: string;
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void;
  onChange?: (value: string) => void;
}

const escapeHtml = (value: string): string =>
  String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const toSafeText = (value: string): string => String(value || '').replace(/\s+/g, ' ').trim();

const isCitationToken = (value: string): boolean => {
  const token = String(value || '').trim();
  if (!token) return false;
  if (token.startsWith('citation:')) return true;
  return /^[A-Za-z0-9|_.-]+$/.test(token);
};

const parseCitationBlock = (raw: string): string[] => {
  return raw
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
};

const splitTrailingCitationSuffix = (value: string): { text: string; citations: string[] } => {
  const normalized = toSafeText(value);
  const match = normalized.match(/\s*\[([^\[\]]+)\]\s*$/);
  if (!match) {
    return { text: normalized, citations: [] };
  }

  const citationTokens = parseCitationBlock(match[1]);
  if (citationTokens.length === 0 || !citationTokens.every(isCitationToken)) {
    return { text: normalized, citations: [] };
  }

  const stripped = normalized.slice(0, match.index).trim();
  return {
    text: stripped,
    citations: citationTokens,
  };
};

const extractCitationBlocksFromText = (value: string): { text: string; citations: string[] } => {
  const raw = String(value || '');
  if (!raw.includes('[') || !raw.includes(']')) {
    return { text: toSafeText(raw), citations: [] };
  }

  const collected: string[] = [];
  const stripped = raw.replace(/\[([^\[\]]+)\]/g, (fullMatch, innerText: string) => {
    const tokens = parseCitationBlock(innerText);
    if (tokens.length === 0 || !tokens.every(isCitationToken)) {
      return fullMatch;
    }

    collected.push(...tokens);
    return ' ';
  });

  const normalizedText = toSafeText(stripped)
    .replace(/\s+([,.;:!?])/g, '$1')
    .trim();

  return {
    text: normalizedText,
    citations: Array.from(new Set(collected.map((token) => String(token || '').trim()).filter(Boolean))),
  };
};

const stripTrailingCitationSuffix = (value: string): string => splitTrailingCitationSuffix(value).text;

const CITATION_REF_PREFIX = 'citation:';

interface CitationReferencePayload {
  chunkId?: string;
  gsUri?: string;
  pageNumber?: number;
  documentName?: string;
  contentType?: string;
  url?: string;
}

const parseCitationReference = (value: string): CitationReferencePayload | null => {
  if (!value || !value.startsWith(CITATION_REF_PREFIX)) return null;

  try {
    const encodedPayload = value.slice(CITATION_REF_PREFIX.length);
    if (!encodedPayload) return null;
    const decoded = decodeURIComponent(encodedPayload);
    const parsed = JSON.parse(decoded);
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed as CitationReferencePayload;
  } catch {
    return null;
  }
};

const getCitationDisplayLabel = (value: string): string => {
  const token = String(value || '').trim();
  if (!token.startsWith(CITATION_REF_PREFIX)) return token;

  const parsed = parseCitationReference(token);
  if (!parsed) return token;

  const chunkId = String(parsed.chunkId || '').trim();
  if (chunkId) return chunkId;
  return token;
};

const deepClone = <T,>(value: T): T => {
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return value;
  }
};

export const buildPastReviewAnalysisEditorText = (
  data?: PastReviewAnalysisData,
  title?: string,
  _editMeta?: PastReviewEditMeta
): string => {
  if (!data) return '';

  const blocks: string[] = [];
  if (title) blocks.push(`<p><strong><u>${escapeHtml(title)}</u></strong></p>`);

  blocks.push('<p><strong><u>Summary</u></strong></p>');
  blocks.push(`<p data-field="summary-count">Number of similar reviews: ${data.summaryCount ?? 0}</p>`);

  blocks.push('<p><strong><u>Key Observations</u></strong></p>');
  (data.keyObservations || []).forEach((group) => {
    blocks.push(`<p><strong>Review ID ${escapeHtml(group.reviewId)} (${escapeHtml(group.reviewTitle)}):</strong></p>`);
    blocks.push(`<ul>${(group.items || []).map((item) => `<li>${escapeHtml(item.text || '')}</li>`).join('')}</ul>`);
  });

  blocks.push('<p><strong><u>Implications</u></strong></p>');
  (data.implications || []).forEach((group) => {
    blocks.push(`<p><strong>Review ID ${escapeHtml(group.reviewId)} (${escapeHtml(group.reviewTitle)}):</strong></p>`);
    blocks.push(`<ul>${(group.items || []).map((item) => `<li>${escapeHtml(item.text || '')}</li>`).join('')}</ul>`);
  });

  blocks.push('<p><strong><u>Comparison Table</u></strong></p>');
  (data.tableRows || []).forEach((row, index) => {
    blocks.push(`<div data-table-row-index="${index}">`);
    blocks.push(`<p data-table-field="assessedArea">${escapeHtml(row.assessedArea || '')}</p>`);
    blocks.push(`<p data-table-field="keyObservations">${escapeHtml(row.keyObservations || '')}</p>`);
    blocks.push(`<p data-table-field="relevanceToCurrentReview">${escapeHtml(row.relevanceToCurrentReview || '')}</p>`);
    blocks.push('</div>');
  });

  return blocks.join('');
};

export const applyPastReviewEditorHtmlToRawTabData = (
  rawTabData: any,
  editorHtml: string,
  editMeta?: PastReviewEditMeta
): any => {
  const cloned = deepClone(rawTabData || {});
  if (!cloned || typeof cloned !== 'object') return cloned;

  const doc = new DOMParser().parseFromString(String(editorHtml || ''), 'text/html');

  const summaryNode = doc.querySelector('[data-field="summary-count"]');
  const summaryText = summaryNode?.textContent || doc.body.textContent || '';
  const summaryMatch = summaryText.match(/number of similar reviews\s*:\s*(\d+)/i);
  if (summaryMatch) {
    cloned.similar_review_count = Number(summaryMatch[1]);
  }

  const reviewMap = new Map<string, any>();
  (Array.isArray(cloned.historical_reviews) ? cloned.historical_reviews : []).forEach((review: any) => {
    const reviewId = String(review?.historical_review_id || '').trim();
    if (reviewId) reviewMap.set(reviewId, review);
  });

  const grouped = new Map<string, string[]>();
  const bodyChildren = Array.from(doc.body.children);
  let currentMode: 'key_observation' | 'implication_for_current_review' | null = null;
  let currentReviewId = '';

  bodyChildren.forEach((node) => {
    const tag = node.tagName.toLowerCase();
    const text = toSafeText(node.textContent || '');
    const normalized = text.toLowerCase();

    if (tag === 'p') {
      if (normalized === 'key observations') {
        currentMode = 'key_observation';
        currentReviewId = '';
        return;
      }
      if (normalized === 'implications') {
        currentMode = 'implication_for_current_review';
        currentReviewId = '';
        return;
      }

      const reviewMatch = text.match(/^review\s*id\s+([^\s(]+)\s*\(/i);
      if (reviewMatch && currentMode) {
        currentReviewId = String(reviewMatch[1] || '').trim();
      }
      return;
    }

    if ((tag === 'ul' || tag === 'ol') && currentMode && currentReviewId) {
      const key = `${currentReviewId}::${currentMode}`;
      const lines = Array.from(node.querySelectorAll('li'))
        .map((li) => stripTrailingCitationSuffix(li.textContent || ''))
        .filter(Boolean);
      if (lines.length > 0) grouped.set(key, lines);
    }
  });

  grouped.forEach((lines, key) => {
    const [reviewId, contentType] = key.split('::');
    const review = reviewMap.get(reviewId);
    if (!review) return;

    const assessments = Array.isArray(review.assessments) ? review.assessments : [];
    if (assessments.length === 0) return;

    const assessmentIndex = contentType === 'key_observation'
      ? (editMeta?.keyObservationAssessmentIndexByReviewId?.[reviewId] ?? 0)
      : (editMeta?.implicationAssessmentIndexByReviewId?.[reviewId] ?? 0);

    const safeIndex = assessmentIndex >= 0 && assessmentIndex < assessments.length ? assessmentIndex : 0;
    const assessment = assessments[safeIndex];
    if (!assessment) return;

    const target = contentType === 'key_observation'
      ? assessment.key_observation
      : assessment.implication_for_current_review;

    const existingContent = Array.isArray(target?.content) ? target.content : [];
    const updatedContent = existingContent.map((entry: any, idx: number) => {
      if (idx >= lines.length) return entry;
      if (entry && typeof entry === 'object' && !Array.isArray(entry)) {
        return { ...entry, content: lines[idx] };
      }
      return {
        content: lines[idx],
        citation_status: 'unsupported',
        supporting_chunk_ids: [],
        supporting_citations: [],
      };
    });

    if (lines.length > existingContent.length) {
      lines.slice(existingContent.length).forEach((line) => {
        updatedContent.push({
          content: line,
          citation_status: 'unsupported',
          supporting_chunk_ids: [],
          supporting_citations: [],
        });
      });
    }

    if (contentType === 'key_observation') {
      assessment.key_observation = { ...(assessment.key_observation || {}), content: updatedContent };
    } else {
      assessment.implication_for_current_review = { ...(assessment.implication_for_current_review || {}), content: updatedContent };
    }
  });

  const tableRowNodes = Array.from(doc.querySelectorAll('[data-table-row-index]'));
  tableRowNodes.forEach((rowNode) => {
    const rowIndex = Number((rowNode as HTMLElement).getAttribute('data-table-row-index') || '-1');
    if (!Number.isFinite(rowIndex) || rowIndex < 0) return;

    const mapping = editMeta?.tableRowMappings?.[rowIndex];
    if (!mapping) return;

    const review = reviewMap.get(String(mapping.reviewId || '').trim());
    if (!review) return;

    const assessments = Array.isArray(review.assessments) ? review.assessments : [];
    if (assessments.length === 0) return;

    const safeIndex = mapping.assessmentIndex >= 0 && mapping.assessmentIndex < assessments.length
      ? mapping.assessmentIndex
      : 0;
    const assessment = assessments[safeIndex];
    if (!assessment) return;

    const assessedAreaText = stripTrailingCitationSuffix(
      toSafeText(rowNode.querySelector('[data-table-field="assessedArea"]')?.textContent || '')
    );
    const keyObservationText = stripTrailingCitationSuffix(
      toSafeText(rowNode.querySelector('[data-table-field="keyObservations"]')?.textContent || '')
    );
    const implicationText = stripTrailingCitationSuffix(
      toSafeText(rowNode.querySelector('[data-table-field="relevanceToCurrentReview"]')?.textContent || '')
    );

    if (assessedAreaText) {
      assessment.assessed_area = assessedAreaText;
    }

    const mapContentToSingleLine = (target: any, value: string) => {
      const existing = Array.isArray(target?.content) ? target.content : [];
      const firstExisting = existing[0];
      const firstEntry = firstExisting && typeof firstExisting === 'object' && !Array.isArray(firstExisting)
        ? { ...firstExisting, content: value }
        : {
          content: value,
          citation_status: 'unsupported',
          supporting_chunk_ids: [],
          supporting_citations: [],
        };
      return [firstEntry];
    };

    if (keyObservationText) {
      assessment.key_observation = {
        ...(assessment.key_observation || {}),
        content: mapContentToSingleLine(assessment.key_observation, keyObservationText),
      };
    }

    if (implicationText) {
      assessment.implication_for_current_review = {
        ...(assessment.implication_for_current_review || {}),
        content: mapContentToSingleLine(assessment.implication_for_current_review, implicationText),
      };
    }
  });

  return cloned;
};

const normalizeCitationId = (value: string): string => value.trim();

const renderCitationList = (
  citationIds: string[],
  keyPrefix: string,
  planId?: string,
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void
): React.ReactNode => {
  if (citationIds.length === 0) return null;

  return (
    <span className={style.citationsInline}>
      {' ['}
      {citationIds.map((citationId, idx) => {
        const normalizedId = normalizeCitationId(citationId);
        const citationRef = parseCitationReference(normalizedId);
        const hrefChunkId = String(citationRef?.chunkId || normalizedId).trim();
        const displayLabel = getCitationDisplayLabel(normalizedId);
        return (
          <React.Fragment key={`${keyPrefix}-citation-${normalizedId}-${idx}`}>
            <a
              href={planId ? `/dbaware-ui/${planId}/docs/${hrefChunkId}` : '#'}
              className={style.citationLink}
              onClick={(e) => {
                if (onCitationClick) {
                  onCitationClick(normalizedId, e);
                }
              }}
            >
              {displayLabel}
            </a>
            {idx < citationIds.length - 1 ? ', ' : ''}
          </React.Fragment>
        );
      })}
      {']'}
    </span>
  );
};

const renderTextWithCitations = (
  text: string,
  citations: string[],
  keyPrefix: string,
  planId?: string,
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void,
  appendUnusedCitations: boolean = true
): React.ReactNode => {
  const citationSet = new Set(citations.map(normalizeCitationId));
  const usedCitations = new Set<string>();
  const parts: React.ReactNode[] = [];

  const citationRegex = /\[([^\[\]]+)\]/g;
  let cursor = 0;
  let match: RegExpExecArray | null;

  while ((match = citationRegex.exec(text)) !== null) {
    const fullMatch = match[0];
    const inner = match[1];
    const start = match.index;

    if (start > cursor) {
      parts.push(text.slice(cursor, start));
    }

    const blockIds = parseCitationBlock(inner);
    const isCitationBlock = blockIds.length > 0 && blockIds.every((id) => {
      const normalized = normalizeCitationId(id);
      return citationSet.has(normalized) || /^\d+$/.test(normalized);
    });

    if (isCitationBlock) {
      blockIds.forEach((id) => usedCitations.add(normalizeCitationId(id)));
      parts.push(
        <React.Fragment key={`${keyPrefix}-inline-${start}`}>
          {renderCitationList(blockIds, `${keyPrefix}-inline-${start}`, planId, onCitationClick)}
        </React.Fragment>
      );
    } else {
      parts.push(fullMatch);
    }

    cursor = start + fullMatch.length;
  }

  if (cursor < text.length) {
    parts.push(text.slice(cursor));
  }

  const remainingCitations = citations.filter((id) => !usedCitations.has(normalizeCitationId(id)));
  if (appendUnusedCitations && remainingCitations.length > 0) {
    parts.push(renderCitationList(remainingCitations, `${keyPrefix}-tail`, planId, onCitationClick));
  }

  return <>{parts}</>;
};

const mergeByReview = (groups: PastReviewGroupedItems[]): PastReviewGroupedItems[] => {
  const merged = new Map<string, PastReviewGroupedItems>();

  groups.forEach((group) => {
    const key = `${group.reviewId}::${group.reviewTitle}`;
    const existing = merged.get(key);

    if (!existing) {
      merged.set(key, {
        reviewId: group.reviewId,
        reviewTitle: group.reviewTitle,
        items: [...group.items],
      });
      return;
    }

    existing.items.push(...group.items);
  });

  return Array.from(merged.values());
};

const normalizeTableRowsForEditing = (rows: any[]): any[] => {
  return (Array.isArray(rows) ? rows : []).map((row) => {
    const keyObsSplit = extractCitationBlocksFromText(String(row?.keyObservations || ''));
    const relSplit = extractCitationBlocksFromText(String(row?.relevanceToCurrentReview || ''));

    const mergedKeyObsCitations = Array.from(new Set([
      ...((Array.isArray(row?.keyObservationCitations) ? row.keyObservationCitations : []).map((c: any) => String(c).trim()).filter(Boolean)),
      ...keyObsSplit.citations,
    ]));

    const mergedRelevanceCitations = Array.from(new Set([
      ...((Array.isArray(row?.relevanceCitations) ? row.relevanceCitations : []).map((c: any) => String(c).trim()).filter(Boolean)),
      ...relSplit.citations,
    ]));

    return {
      ...row,
      keyObservations: keyObsSplit.text,
      relevanceToCurrentReview: relSplit.text,
      keyObservationCitations: mergedKeyObsCitations,
      relevanceCitations: mergedRelevanceCitations,
    };
  });
};

const PastReviewAnalysisSectionEdit: React.FC<PastReviewAnalysisSectionProps> = ({ data, planId, title, onCitationClick, onChange }) => {
  const mergedKeyObservations = useMemo(() => mergeByReview(data.keyObservations), [data.keyObservations]);
  const mergedImplications = useMemo(() => mergeByReview(data.implications), [data.implications]);

  const [editableSummaryCount, setEditableSummaryCount] = useState<number>(data.summaryCount ?? 0);
  const [editableKeyObservations, setEditableKeyObservations] = useState<PastReviewGroupedItems[]>(mergedKeyObservations);
  const [editableImplications, setEditableImplications] = useState<PastReviewGroupedItems[]>(mergedImplications);
  const [editableTableRows, setEditableTableRows] = useState(normalizeTableRowsForEditing(data.tableRows || []));

  useEffect(() => {
    setEditableSummaryCount(data.summaryCount ?? 0);
    setEditableKeyObservations(mergedKeyObservations);
    setEditableImplications(mergedImplications);
    setEditableTableRows(normalizeTableRowsForEditing(data.tableRows || []));
  }, [data.summaryCount, data.tableRows, mergedKeyObservations, mergedImplications]);

  useEffect(() => {
    const editableData: PastReviewAnalysisData = {
      ...data,
      summaryCount: editableSummaryCount,
      keyObservations: editableKeyObservations,
      implications: editableImplications,
      tableRows: editableTableRows,
    };
    onChange?.(buildPastReviewAnalysisEditorText(editableData, title));
  }, [data, editableSummaryCount, editableKeyObservations, editableImplications, editableTableRows, onChange, title]);

  const updateGroupItemText = (
    groups: PastReviewGroupedItems[],
    groupIndex: number,
    itemIndex: number,
    value: string
  ): PastReviewGroupedItems[] => {
    return groups.map((group, gIdx) => {
      if (gIdx !== groupIndex) return group;
      return {
        ...group,
        items: group.items.map((item, iIdx) => (
          iIdx === itemIndex
            ? { ...item, text: value }
            : item
        )),
      };
    });
  };

  const updateTableRowField = (
    rowIndex: number,
    field: 'assessedArea' | 'keyObservations' | 'relevanceToCurrentReview',
    value: string
  ) => {
    setEditableTableRows((prev) => prev.map((row, idx) => {
      if (idx !== rowIndex) return row;

      if (field === 'assessedArea') {
        return { ...row, [field]: value };
      }

      const extracted = extractCitationBlocksFromText(value);
      if (field === 'keyObservations') {
        return {
          ...row,
          keyObservations: extracted.text,
          keyObservationCitations: Array.from(new Set([
            ...((Array.isArray(row?.keyObservationCitations) ? row.keyObservationCitations : []).map((c: any) => String(c).trim()).filter(Boolean)),
            ...extracted.citations,
          ])),
        };
      }

      return {
        ...row,
        relevanceToCurrentReview: extracted.text,
        relevanceCitations: Array.from(new Set([
          ...((Array.isArray(row?.relevanceCitations) ? row.relevanceCitations : []).map((c: any) => String(c).trim()).filter(Boolean)),
          ...extracted.citations,
        ])),
      };
    }));
  };

  return (
    <div className={style.wrapper} style={{ marginTop: "15px" }}>
      {title && <h3 className={style.mainTitle}>{title}</h3>}

      <h3 className={style.sectionTitle}>Summary</h3>
      <div className={style.bodyText}>
        <strong>Number of similar reviews:</strong> {editableSummaryCount}
      </div>

      <h3 className={style.sectionTitle}>Key Observations</h3>
      <div className={style.listBlock}>
        {editableKeyObservations.map((group, groupIndex) => (
          <div key={`obs-${group.reviewId}-${group.reviewTitle}`} className={style.bodyText} style={{ marginBottom: 12 }}>
            <strong>Review ID {group.reviewId} ({group.reviewTitle}): </strong>
            {group.items.map((item, itemIndex) => (
              <div key={`obs-item-${group.reviewId}-${itemIndex}`} style={{ marginTop: 8 }}>                <MarkdownFieldEditor
                value={item.text}
                onChange={(value) => setEditableKeyObservations((prev) => updateGroupItemText(prev, groupIndex, itemIndex, value))}
              />
                {item.citations?.length > 0 && (
                  <div style={{ marginTop: 4 }}>
                    {renderTextWithCitations('', item.citations, `obs-item-cit-${group.reviewId}-${itemIndex}`, planId, onCitationClick)}
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}
      </div>

      <h3 className={style.sectionTitle}>Implications</h3>
      <div className={style.listBlock}>
        {editableImplications.map((group, groupIndex) => (
          <div key={`imp-${group.reviewId}-${group.reviewTitle}`} className={style.bodyText} style={{ marginBottom: 12 }}>
            <strong>Review ID {group.reviewId} ({group.reviewTitle}): </strong>
            {group.items.map((item, itemIndex) => (
              <div key={`imp-item-${group.reviewId}-${itemIndex}`} style={{ marginTop: 8 }}>                <MarkdownFieldEditor
                value={item.text}
                onChange={(value) => setEditableImplications((prev) => updateGroupItemText(prev, groupIndex, itemIndex, value))}
              />
                {item.citations?.length > 0 && (
                  <div style={{ marginTop: 4 }}>
                    {renderTextWithCitations('', item.citations, `imp-item-cit-${group.reviewId}-${itemIndex}`, planId, onCitationClick)}
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}
      </div>

      <div className={style.tableWrapper}>
        <table className={style.table}>
          <thead>
            <tr>
              <th>Historical Review IDs</th>
              <th>Assessed Area</th>
              <th>Key Observations</th>
              <th>Relevance to Current Review</th>
            </tr>
          </thead>
          <tbody>
            {editableTableRows.map((row, rowIndex) => (
              <tr key={`${row.historicalReviewId}-${rowIndex}`}>
                <td>{row.historicalReviewId}</td>
                <td>                  <MarkdownFieldEditor
                  value={row.assessedArea}
                  onChange={(value) => updateTableRowField(rowIndex, 'assessedArea', value)}
                />
                </td>
                <td>                  <MarkdownFieldEditor
                  value={row.keyObservations}
                  onChange={(value) => updateTableRowField(rowIndex, 'keyObservations', value)}
                />
                  {row.keyObservationCitations?.length > 0 && (
                    <div style={{ marginTop: 4 }}>
                      {renderTextWithCitations(
                        '',
                        row.keyObservationCitations,
                        `row-key-obs-${rowIndex}`,
                        planId,
                        onCitationClick,
                        false
                      )}
                    </div>
                  )}
                </td>
                <td>                  <MarkdownFieldEditor
                  value={row.relevanceToCurrentReview}
                  onChange={(value) => updateTableRowField(rowIndex, 'relevanceToCurrentReview', value)}
                />
                  {row.relevanceCitations?.length > 0 && (
                    <div style={{ marginTop: 4 }}>
                      {renderTextWithCitations(
                        '',
                        row.relevanceCitations,
                        `row-rel-${rowIndex}`,
                        planId,
                        onCitationClick,
                        false
                      )}
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editableTableRows.length === 0 && (
        <Text variant="secondary">No historical review rows available.</Text>
      )}
    </div>
  );
};

export default PastReviewAnalysisSectionEdit;
