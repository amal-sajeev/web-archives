import React from 'react';
import PolicyKodRegulatoryAnalysisSectionEdit from './PolicyKodRegulatoryAnalysisSection';

interface BroadScopeDirectionSectionProps {
  content: string;
  title?: string;
  onChange?: (value: string) => void;
}

const BroadScopeDirectionSectionEdit: React.FC<BroadScopeDirectionSectionProps> = ({
  content,
  title,
  onChange,
}) => {
  return (
    <PolicyKodRegulatoryAnalysisSectionEdit
      content={content}
      title={title}
      onChange={onChange}
    />
  );
};

export default BroadScopeDirectionSectionEdit;
