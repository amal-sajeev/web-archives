﻿import React, { useState } from 'react';
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';
import 'com.db.rca.commons.afcc-components/style.css';
import style from '../tabs/PolicyKodRegulatoryAnalysisSection.module.css';

interface PolicyKodRegulatoryAnalysisSectionEditProps {
  content: string;
  title?: string;
  onChange?: (value: string) => void;
}

interface StructuredSectionUpdate {
  content: string;
  paragraphIndices?: number[];
  reviewIndex?: number;
  assessmentIndex?: number;
}

export const applyStructuredSectionsToRawTabData = (
  rawTabData: any,
  updates: StructuredSectionUpdate[]
): any => {
  const cloned = JSON.parse(JSON.stringify(rawTabData || {}));
  const paragraphs = Array.isArray(cloned?.paragraphs) ? cloned.paragraphs : [];
  const historicalReviews = Array.isArray(cloned?.historical_reviews) ? cloned.historical_reviews : [];

  const parseAssessmentEditContent = (value: string) => {
    const text = String(value || '');
    const lines = text.split(/\r?\n/);

    const assessedAreaMatch = text.match(/\*\*Assessed Area:\*\*\s*([^\n]+)/i);
    const assessedArea = String(assessedAreaMatch?.[1] || '').trim();

    const collectSectionLines = (startLabel: string, endLabel?: string): string[] => {
      const startIndex = lines.findIndex((line) => line.trim().toLowerCase() === startLabel.toLowerCase());
      if (startIndex < 0) return [];
      const endIndex = endLabel
        ? lines.findIndex((line, idx) => idx > startIndex && line.trim().toLowerCase() === endLabel.toLowerCase())
        : -1;
      const sectionLines = lines
        .slice(startIndex + 1, endIndex > -1 ? endIndex : undefined)
        .map((line) => line.trim().replace(/^-\s+/, ''))
        .filter(Boolean);
      return sectionLines;
    };

    const keyObservationLines = collectSectionLines('**Key Observation**', '**Implication for Current Review**');
    const implicationLines = collectSectionLines('**Implication for Current Review**');

    return {
      assessedArea,
      keyObservationLines,
      implicationLines,
    };
  };

  const applyLinesToStructuredContent = (target: any, lines: string[]) => {
    if (!lines.length) return target;

    const existing = Array.isArray(target?.content) ? target.content : [];
    const next = existing.map((entry: any, idx: number) => {
      if (idx >= lines.length) return entry;
      if (entry && typeof entry === 'object' && !Array.isArray(entry)) {
        return { ...entry, content: lines[idx] };
      }
      return lines[idx];
    });

    if (lines.length > existing.length) {
      lines.slice(existing.length).forEach((line) => {
        next.push({
          content: line,
          citation_status: 'unsupported',
          supporting_chunk_ids: [],
          supporting_citations: [],
        });
      });
    }

    return {
      ...(target || {}),
      content: next,
    };
  };

  updates.forEach((update) => {
    if (Array.isArray(update.paragraphIndices) && update.paragraphIndices.length > 0) {
      const sectionBlocks = String(update.content || '')
        .split(/\n{2,}/)
        .map((block) => block.trim())
        .filter(Boolean);

      update.paragraphIndices.forEach((paragraphIndex, localIndex) => {
        if (!Number.isFinite(paragraphIndex) || paragraphIndex < 0 || paragraphIndex >= paragraphs.length) return;

        const paragraph = paragraphs[paragraphIndex] || {};
        const isLastLocalIndex = localIndex === update.paragraphIndices!.length - 1;
        const hasOverflowBlocks = sectionBlocks.length > update.paragraphIndices!.length;

        let nextContent = sectionBlocks[localIndex] || '';
        if (isLastLocalIndex && hasOverflowBlocks) {
          nextContent = [
            nextContent,
            ...sectionBlocks.slice(update.paragraphIndices!.length),
          ].filter(Boolean).join('\n\n');
        }

        if (!nextContent) return;

        paragraph.content = nextContent;
        paragraphs[paragraphIndex] = paragraph;
      });
      return;
    }

    if (Number.isFinite(update.reviewIndex) && Number.isFinite(update.assessmentIndex)) {
      const review = historicalReviews[Number(update.reviewIndex)];
      const assessments = Array.isArray(review?.assessments) ? review.assessments : [];
      const assessment = assessments[Number(update.assessmentIndex)];
      if (!assessment) return;

      const parsed = parseAssessmentEditContent(String(update.content || ''));

      if (parsed.assessedArea) {
        assessment.assessed_area = parsed.assessedArea;
      }

      if (parsed.keyObservationLines.length > 0) {
        assessment.key_observation = applyLinesToStructuredContent(assessment.key_observation, parsed.keyObservationLines);
      }

      if (parsed.implicationLines.length > 0) {
        assessment.implication_for_current_review = applyLinesToStructuredContent(
          assessment.implication_for_current_review,
          parsed.implicationLines
        );
      }
    }
  });

  cloned.paragraphs = paragraphs;
  cloned.historical_reviews = historicalReviews;
  return cloned;
};

// Converters live in utils so every page can share them; re-exported here for existing imports.
import { markdownToEditorHtml, editorHtmlToMarkdown, SECTION_EDITOR_OPTIONS } from '../../../utils/richTextMarkdownUtils';
export { markdownToEditorHtml, editorHtmlToMarkdown, SECTION_EDITOR_OPTIONS };

const PolicyKodRegulatoryAnalysisSectionEdit: React.FC<PolicyKodRegulatoryAnalysisSectionEditProps> = ({
  content,
  title,
  onChange,
}) => {
  // Initialised once on mount so typing never resets the editor/cursor.
  const [html, setHtml] = useState<string>(() => markdownToEditorHtml(String(content || '')));

  const handleValueChange = (value: string) => {
    setHtml(value);
    onChange?.(editorHtmlToMarkdown(value));
  };

  return (
    <div className={style.wrapper} style={{ paddingTop: 8 }}>
      {title && <h4 className={style.mainTitle} style={{ marginTop: 4, marginBottom: 8 }}>{title}</h4>}
      <div style={{ marginBottom: 12 }}>
        <RichTextEditor
          value={html}
          options={SECTION_EDITOR_OPTIONS}
          onValueChange={handleValueChange}
        />
      </div>
    </div>
  );
};

export default PolicyKodRegulatoryAnalysisSectionEdit;
