import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardHeader,
  CardFooter,
  CardTitle,
  LeftSlot,
  Stack,
  Button,
  RightSlot,
  Text,
  Separator,
  PopoverTrigger,
  Popover,
  PopoverSurface,
  OutlineButton, NavTab,
  Tab
} from "@wadk/ui";
import { useDispatch, useSelector } from 'react-redux';
import { setPreliminaryResearchData } from '../../store/preliminaryResearchSlice';
import { EditBoxSolid, CloneSolid, MenuSolid, ContextInfoOutline } from '@wadk/icons';
import { RichTextEditor } from 'com.db.rca.commons.afcc-components/quill';
import { ScopingTabEnum } from '../../store/scopingSlice';
import { EmptyScopingState, AiRationalIcon } from '../../components';
import { showSuccessToast, showErrorToast } from '../../components/AppToaster/AppToaster';
import { PreliminaryResearchReport } from "../../api/type";
import { acceptPreliminaryResearch, downloadPreliminaryResearchDocument, generatePreliminaryResearch, editPreliminaryResearchDocument, getPreliminaryResearchDocument } from '../../api/scopingClient';
import {
  formatMarkdownToHtml,
  getConfidenceLabel,
  getConfidenceColorClassKey,
  copyToClipboard,
  stripHtml,
  stripHtmlToText,
  downloadFile
} from '../../utils';
import { usePlanId } from '../../hooks/usePlanId';
import { SectionData, PastReviewGroupedItems, PastReviewTableRow, PastReviewSentence, SupportingCitation } from './types';
import { AUTO_REDIRECT_DELAY_MS, GenerationState, SendState, PRELIMINARY_RESEARCH_MESSAGES } from '../../constants';
import PastReviewAnalysisSection from './tabs/PastReviewAnalysisSection';
import PolicyKodRegulatoryAnalysisSection from './tabs/PolicyKodRegulatoryAnalysisSection';
import BroadScopeDirectionSection from './tabs/BroadScopeDirectionSection';
import PastReviewAnalysisEditSection, {
  buildPastReviewAnalysisEditorText,
  applyPastReviewEditorHtmlToRawTabData
} from './edits/PastReviewAnalysisSection';
import PolicyKodRegulatoryAnalysisEditSection, {
  applyStructuredSectionsToRawTabData,
  markdownToEditorHtml,
  editorHtmlToMarkdown,
  SECTION_EDITOR_OPTIONS
} from './edits/PolicyKodRegulatoryAnalysisSection';
import BroadScopeDirectionEditSection from './edits/BroadScopeDirectionSection';
import 'com.db.rca.commons.afcc-components/style.css';
import style from './PreliminaryResearchPage.module.css';


/**
 * Helper function to extract page number from API response
 * Priority: page_number field > location_metadata.page_number > undefined
 */
const extractPageNumber = (data: any): number | undefined => {
  // Check if page_number exists directly in response
  if (data.page_number && typeof data.page_number === 'number') {
    return data.page_number;
  }

  // Check if page_number exists in location_metadata
  if (data.location_metadata?.page_number && typeof data.location_metadata.page_number === 'number') {
    return data.location_metadata.page_number;
  }

  // Check if source.location_metadata exists (for document details)
  if (data.source?.location_metadata?.page_number && typeof data.source.location_metadata.page_number === 'number') {
    return data.source.location_metadata.page_number;
  }

  return undefined;
};

/**
 * Helper function to check if a document is a PDF
 */
const isPdfDocument = (documentName: string, contentType?: string): boolean => {
  if (contentType) {
    return contentType.includes('application/pdf') || contentType.includes('pdf');
  }
  return documentName.toLowerCase().endsWith('.pdf');
};

const CITATION_REF_PREFIX = 'citation:';
const ALL_SECTIONS_EDIT_ID = '__ALL_SECTIONS__';

interface CitationReferencePayload {
  chunkId?: string;
  gsUri?: string;
  pageNumber?: number;
  documentName?: string;
  contentType?: string;
  url?: string;
}

const parseCitationReference = (value: string): CitationReferencePayload | null => {
  if (!value || !value.startsWith(CITATION_REF_PREFIX)) return null;

  try {
    const encodedPayload = value.slice(CITATION_REF_PREFIX.length);
    if (!encodedPayload) return null;
    const decoded = decodeURIComponent(encodedPayload);
    const parsed = JSON.parse(decoded);
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed as CitationReferencePayload;
  } catch {
    return null;
  }
};

const buildCitationReferenceValue = (
  payload?: CitationReferencePayload,
  fallbackChunkId?: string
): string => {
  const chunkId = String(payload?.chunkId || fallbackChunkId || '').trim();
  if (!chunkId) return '';

  const normalizedPayload: CitationReferencePayload = {
    chunkId,
    gsUri: payload?.gsUri,
    pageNumber: payload?.pageNumber,
    documentName: payload?.documentName,
    contentType: payload?.contentType,
    url: payload?.url,
  };

  const hasExtended = Boolean(
    normalizedPayload.gsUri
    || Number.isFinite(Number(normalizedPayload.pageNumber))
    || normalizedPayload.documentName
    || normalizedPayload.contentType
    || normalizedPayload.url
  );

  if (!hasExtended) return chunkId;

  return `${CITATION_REF_PREFIX}${encodeURIComponent(JSON.stringify(normalizedPayload))}`;
};

const buildCitationRedirectPreview = (
  referenceValue: string,
  planId?: string,
  fallbackCitation?: SupportingCitation
): string => {
  const normalized = String(referenceValue || '').trim();
  if (!normalized) return '';

  const parsed = parseCitationReference(normalized);
  if (!parsed) {
    const fallbackUrl = String(fallbackCitation?.url || '').trim();
    if (fallbackUrl) return fallbackUrl;

    const chunkId = String(fallbackCitation?.chunkId || normalized).trim();
    if (!chunkId) return normalized;
    return planId ? `/dbaware-ui/${planId}/docs/${chunkId}` : chunkId;
  }

  const sourceUrl = String(parsed.url || '').trim();
  if (sourceUrl) return sourceUrl;

  const rawGsUri = String(parsed.gsUri || '').trim();
  const gsUri = rawGsUri
    ? (/^gs:\/\//i.test(rawGsUri) ? rawGsUri : `gs://${rawGsUri.replace(/^\/+/, '')}`)
    : '';
  const pageNumber = Number(parsed.pageNumber);
  const citationContentType = String(parsed.contentType || '').trim().toLowerCase();
  const citationDocumentName = String(parsed.documentName || '').trim().toLowerCase();
  const isJsonCitation = citationContentType.includes('application/json') || citationDocumentName.endsWith('.json');

  if (planId && gsUri && !isJsonCitation) {
    const encodedUri = encodeURIComponent(gsUri);
    const pageParam = Number.isFinite(pageNumber) && pageNumber > 0 ? `&pageNumber=${pageNumber}` : '';
    return `/dbaware-ui/${planId}/docs/uri?document_uri=${encodedUri}${pageParam}`;
  }

  const chunkId = String(parsed.chunkId || '').trim();
  if (planId && chunkId) {
    return `/dbaware-ui/${planId}/docs/${chunkId}`;
  }

  return chunkId || normalized;
};

const getCitationReferenceDisplayLabel = (
  token: string,
  supportingCitations: SupportingCitation[] = []
): string => {
  const trimmedToken = String(token || '').trim();
  if (!trimmedToken.startsWith(CITATION_REF_PREFIX)) return trimmedToken;

  const parsed = parseCitationReference(trimmedToken);
  if (!parsed) return trimmedToken;

  const normalizedChunkId = String(parsed.chunkId || '').trim();
  const normalizedPage = Number(parsed.pageNumber);

  const matchedCitation = supportingCitations.find((citation) => {
    const citationChunkId = String(citation?.chunkId || '').trim();
    if (!citationChunkId || citationChunkId !== normalizedChunkId) return false;

    if (Number.isFinite(normalizedPage) && normalizedPage > 0) {
      return Number(citation?.pageNumber) === normalizedPage;
    }

    return true;
  }) || supportingCitations.find((citation) => String(citation?.chunkId || '').trim() === normalizedChunkId);

  const citationLabel = String(matchedCitation?.label || '').trim();
  if (citationLabel) return citationLabel;

  if (normalizedChunkId) return normalizedChunkId;

  const documentName = String(parsed.documentName || '').trim();
  if (documentName && Number.isFinite(normalizedPage) && normalizedPage > 0) {
    return `${documentName} (p. ${normalizedPage})`;
  }

  if (documentName) return documentName;

  return trimmedToken;
};

const replaceCitationReferenceTokensWithLabels = (
  content: string,
  supportingCitations: SupportingCitation[] = []
): string => {
  const text = String(content || '');
  if (!text.includes(CITATION_REF_PREFIX)) return text;

  const replaceStandaloneToken = (value: string): string => {
    if (!value.startsWith(CITATION_REF_PREFIX)) return value;
    return getCitationReferenceDisplayLabel(value, supportingCitations);
  };

  const withCitationBlocksReplaced = text.replace(/\[([^\[\]]+)\]/g, (fullMatch, innerText: string) => {
    const tokens = String(innerText || '')
      .split(',')
      .map((token) => String(token || '').trim())
      .filter(Boolean);

    if (tokens.length === 0) return fullMatch;

    const hasCitationReference = tokens.some((token) => token.startsWith(CITATION_REF_PREFIX));
    if (!hasCitationReference) return fullMatch;

    const mapped = tokens.map((token) => replaceStandaloneToken(token));
    return `[${mapped.join(', ')}]`;
  });

  return withCitationBlocksReplaced.replace(/citation:[^\s,\]]+/g, (token) => replaceStandaloneToken(token));
};

interface PreliminaryResearchGenerateEventDetail {
  payload?: {
    sections?: string[];
  };
}

/**
 * PreliminaryResearchPage Component
 * 
 * Renders the preliminary research results, allowing users to view AI-generated 
 * content, edit sections, and approve or download the research report.
 * 
 * @returns {React.ReactElement} The rendered PreliminaryResearchPage component.
 */
const PreliminaryResearchPage: React.FC = () => {
  const planId = usePlanId();

  const dispatch = useDispatch();
  const reduxReportData = useSelector((state: any) => planId ? state.preliminaryResearch?.reports?.[planId] : undefined);
  const nextAvailableActionsByPlan = useSelector((state: any) => state.scoping?.nextAvailableActionsByPlan);
  const taskDefinitionKeyByPlan = useSelector((state: any) => state.scoping?.taskDefinitionKeyByPlan);

  const [generationState, setGenerationState] = useState<GenerationState>(reduxReportData ? 'generated' : 'empty');
  const [reportData, setReportData] = useState<Record<string, { title: string, sections: SectionData[] }>>(reduxReportData || {});
  const [activeTab, setActiveTab] = useState<string>(reduxReportData ? Object.keys(reduxReportData)[0] || '' : '');
  const [editingSectionId, setEditingSectionId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState<string>('');
  const [sectionEditContentById, setSectionEditContentById] = useState<Record<string, string>>({});
  const [editBoxHeight, setEditBoxHeight] = useState<number>(300);
  const [saveState, setSaveState] = useState<SendState>('idle');
  const [getApiPendingCount, setGetApiPendingCount] = useState<number>(0);
  const runAnalyticsPayloadRef = useRef<Record<string, unknown>>({});

  const [approveState, setApproveState] = useState<SendState>('idle');
  const [downloadState, setDownloadState] = useState<SendState>('idle');
  const [pdfViewerOpen, setPdfViewerOpen] = useState(false);
  const [selectedPdfData, setSelectedPdfData] = useState<{ uri: string; pageNumber?: number; name: string; chunkId: string } | null>(null);
  const [chunkDetailsCache, setChunkDetailsCache] = useState<Map<string, any>>(new Map());

  const navigate = useNavigate();
  const redirectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pastReviewRefreshAttemptedRef = useRef<Record<string, boolean>>({});

  const currentPlanNumber = String(planId || '').trim();

  const availableWorkflowActions = useMemo(() => {
    const actionsFromPlan = nextAvailableActionsByPlan?.[currentPlanNumber] ?? [];

    return Array.from(new Set(actionsFromPlan))
      .map((action: unknown) => String(action || '').trim().toUpperCase())
      .filter(Boolean);
  }, [nextAvailableActionsByPlan, currentPlanNumber]);

  const taskDefinitionKey = useMemo(() => {
    const fromPlan = String(taskDefinitionKeyByPlan?.[currentPlanNumber] ?? '').trim();
    return fromPlan.replace(/[\s-]+/g, '_').toUpperCase();
  }, [taskDefinitionKeyByPlan, currentPlanNumber]);

  const isPreliminaryResearchTaskDefinition = taskDefinitionKey === 'PRELIMINARY_RESEARCH';
  const isCurrentTabActionable = !taskDefinitionKey || isPreliminaryResearchTaskDefinition;

  const canRunAnalytics = !isPreliminaryResearchTaskDefinition || availableWorkflowActions.includes('RUN_ANALYTICS');
  const canGetPreliminaryResearchDocument = availableWorkflowActions.includes('GET_PRELIMINARY_RESEARCH_DOCUMENT');
  const canEditPreliminaryResearchDocument = isCurrentTabActionable
    && availableWorkflowActions.includes('EDIT_PRELIMINARY_RESEARCH_DOCUMENT');
  const canGetCitationDocument = !isPreliminaryResearchTaskDefinition || availableWorkflowActions.includes('GET_CITATION_DOCUMENT');
  const canAcceptPreliminaryResearch = isCurrentTabActionable
    && (!isPreliminaryResearchTaskDefinition || availableWorkflowActions.includes('ACCEPT_PRELIMINARY_RESEARCH'));
  const canDownloadPreliminaryResearchDocument = !isPreliminaryResearchTaskDefinition || availableWorkflowActions.includes('DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT');
  const isGetApiLoading = getApiPendingCount > 0;
  const canGetPreliminaryResearchDocumentRef = useRef<boolean>(canGetPreliminaryResearchDocument);

  useEffect(() => {
    canGetPreliminaryResearchDocumentRef.current = canGetPreliminaryResearchDocument;
  }, [canGetPreliminaryResearchDocument]);

  const getPreliminaryResearchDocumentIfAllowed = useCallback(async (currentPlanId: string) => {
    if (!canGetPreliminaryResearchDocumentRef.current) {
      return null;
    }

    return getPreliminaryResearchDocument(currentPlanId);
  }, []);

  const extractStructuredContent = useCallback((value: any): string[] => {
    if (!value) return [];

    if (typeof value === 'string') {
      return [value];
    }

    if (Array.isArray(value)) {
      return value
        .map(item => {
          if (typeof item === 'string') return item;
          if (item && typeof item === 'object') return item.content || '';
          return '';
        })
        .filter(Boolean);
    }

    if (Array.isArray(value.content)) {
      return value.content
        .map((item: any) => {
          if (typeof item === 'string') return item;
          if (item && typeof item === 'object') return item.content || '';
          return '';
        })
        .filter(Boolean);
    }

    return [];
  }, []);

  const extractEvidenceItems = useCallback((value: any): { text: string; citations: string[] }[] => {
    if (!value) return [];

    const raw = Array.isArray(value?.content) ? value.content : Array.isArray(value) ? value : [];
    return raw
      .map((item: any) => {
        if (typeof item === 'string') {
          return { text: item, citations: [] as string[] };
        }
        if (item && typeof item === 'object') {
          const citationObjects = Array.isArray(item.supporting_citations)
            ? item.supporting_citations
            : [];
          const citationObjectChunkIds = new Set(
            citationObjects
              .map((citation: any) => String(citation?.chunk_id || '').trim())
              .filter(Boolean)
          );
          const supportingChunkIds = Array.isArray(item.supporting_chunk_ids)
            ? item.supporting_chunk_ids
              .map((c: any) => String(c).trim())
              .filter((id: string) => Boolean(id) && !citationObjectChunkIds.has(id))
            : [];
          const citationObjectTargets = citationObjects
            .map((citation: any) => {
              const chunkId = String(citation?.chunk_id || citation?.citation_label || '').trim();
              if (!chunkId) return '';

              return buildCitationReferenceValue({
                chunkId,
                gsUri: String(citation?.gs_uri || '').trim() || undefined,
                pageNumber: Number.isFinite(Number(citation?.page_number)) ? Number(citation?.page_number) : undefined,
                documentName: String(citation?.document_name || '').trim() || undefined,
                contentType: String(citation?.content_type || '').trim() || undefined,
                url: String(citation?.url || '').trim() || undefined,
              }, chunkId);
            })
            .filter(Boolean);

          const citations = Array.from(new Set([...supportingChunkIds, ...citationObjectTargets]));
          return {
            text: String(item.content || ''),
            citations,
          };
        }
        return { text: '', citations: [] as string[] };
      })
      .filter((entry: { text: string }) => Boolean(entry.text));
  }, []);

  const normalizeSupportingCitationsFromValue = useCallback((value: any): SupportingCitation[] => {
    if (!Array.isArray(value)) return [];

    return value
      .map((citation: any) => {
        const chunkId = String(citation?.chunk_id || '').trim();
        if (!chunkId) return null;

        const label = String(citation?.citation_label || '').trim() || undefined;
        const pageNumber = Number(citation?.page_number);
        const gsUri = String(citation?.gs_uri || '').trim() || undefined;
        const documentName = String(citation?.document_name || '').trim() || undefined;
        const contentType = String(citation?.content_type || '').trim() || undefined;
        const url = String(citation?.url || '').trim() || undefined;

        return {
          chunkId,
          label,
          pageNumber: Number.isFinite(pageNumber) && pageNumber > 0 ? pageNumber : undefined,
          gsUri,
          documentName,
          contentType,
          url,
        } as SupportingCitation;
      })
      .filter(Boolean) as SupportingCitation[];
  }, []);

  const collectSupportingCitationsFromAny = useCallback((value: any): SupportingCitation[] => {
    if (!value) return [];

    if (Array.isArray(value)) {
      return value.flatMap((item: any) => collectSupportingCitationsFromAny(item));
    }

    if (typeof value === 'object') {
      const direct = normalizeSupportingCitationsFromValue(value.supporting_citations);
      const nested = value.content && typeof value.content !== 'string'
        ? collectSupportingCitationsFromAny(value.content)
        : [];
      return [...direct, ...nested];
    }

    return [];
  }, [normalizeSupportingCitationsFromValue]);

  const mergeSupportingCitations = useCallback((existing: SupportingCitation[] = [], incoming: SupportingCitation[] = []): SupportingCitation[] => {
    const merged = new Map<string, SupportingCitation>();

    [...existing, ...incoming].forEach((citation) => {
      const key = String(citation?.chunkId || '').trim();
      if (!key) return;

      const prev = merged.get(key);
      if (!prev) {
        merged.set(key, {
          chunkId: key,
          label: citation.label,
          pageNumber: citation.pageNumber,
          gsUri: citation.gsUri,
          documentName: citation.documentName,
          contentType: citation.contentType,
          url: citation.url,
        });
        return;
      }

      merged.set(key, {
        chunkId: key,
        label: prev.label || citation.label,
        pageNumber: prev.pageNumber ?? citation.pageNumber,
        gsUri: prev.gsUri || citation.gsUri,
        documentName: prev.documentName || citation.documentName,
        contentType: prev.contentType || citation.contentType,
        url: prev.url || citation.url,
      });
    });

    return Array.from(merged.values());
  }, []);

  const extractChunkIdsFromCitationObjects = useCallback((value: any): string[] => {
    if (!Array.isArray(value)) return [];
    return value
      .map((citation: any) => String(citation?.chunk_id || citation?.citation_label || ''))
      .filter(Boolean);
  }, []);

  const extractCitationReferenceTargetsFromCitationObjects = useCallback((value: any): string[] => {
    if (!Array.isArray(value)) return [];

    return value
      .map((citation: any) => {
        const chunkId = String(citation?.chunk_id || '').trim();
        if (!chunkId) return '';

        return buildCitationReferenceValue({
          chunkId,
          gsUri: String(citation?.gs_uri || '').trim() || undefined,
          pageNumber: Number.isFinite(Number(citation?.page_number)) ? Number(citation?.page_number) : undefined,
          documentName: String(citation?.document_name || '').trim() || undefined,
          contentType: String(citation?.content_type || '').trim() || undefined,
          url: String(citation?.url || '').trim() || undefined,
        }, chunkId);
      })
      .filter(Boolean);
  }, []);

  const extractChunkIdsWithLabelsFromCitationObjects = useCallback((value: any): Set<string> => {
    const chunkIds = new Set<string>();
    if (!Array.isArray(value)) return chunkIds;

    value.forEach((citation: any) => {
      const chunkId = String(citation?.chunk_id || '').trim();
      const label = String(citation?.citation_label || '').trim();
      if (chunkId && label) {
        chunkIds.add(chunkId);
      }
    });

    return chunkIds;
  }, []);

  const appendCitationsIfMissing = useCallback((text: string, citations: string[]): string => {
    if (!text) return '';
    if (!Array.isArray(citations) || citations.length === 0) return text;

    const uniqueCitations = Array.from(new Set(citations.map((id) => String(id).trim()).filter(Boolean)));
    if (uniqueCitations.length === 0) return text;

    const hasCitationSuffix = /\[[^\]]+\]\s*$/.test(text.trim());
    if (hasCitationSuffix) return text;

    return `${text} [${uniqueCitations.join(', ')}]`;
  }, []);

  const flattenParagraphContent = useCallback((value: any): string => {
    if (value == null) return '';

    if (typeof value === 'string') {
      return value;
    }

    if (Array.isArray(value)) {
      const parts = value
        .map((item: any) => {
          if (typeof item === 'string') return item;
          if (item && typeof item === 'object') {
            const text = String(item.content || '').trim();
            const labeledChunkIds = extractChunkIdsWithLabelsFromCitationObjects(item.supporting_citations);
            const citationTokens = [
              ...extractCitationReferenceTargetsFromCitationObjects(item.supporting_citations),
              ...(Array.isArray(item.supporting_chunk_ids)
                ? item.supporting_chunk_ids
                  .map((id: any) => String(id).trim())
                  .filter((id: string) => Boolean(id) && !labeledChunkIds.has(id))
                : []),
            ];
            return appendCitationsIfMissing(text, citationTokens);
          }
          return '';
        })
        .filter(Boolean);

      return parts.join('\n\n');
    }

    if (value && typeof value === 'object') {
      if (Array.isArray(value.content)) {
        return flattenParagraphContent(value.content);
      }

      if (typeof value.content === 'string') {
        const text = String(value.content || '').trim();
        const labeledChunkIds = extractChunkIdsWithLabelsFromCitationObjects(value.supporting_citations);
        const citationTokens = [
          ...extractCitationReferenceTargetsFromCitationObjects(value.supporting_citations),
          ...(Array.isArray(value.supporting_chunk_ids)
            ? value.supporting_chunk_ids
              .map((id: any) => String(id).trim())
              .filter((id: string) => Boolean(id) && !labeledChunkIds.has(id))
            : []),
        ];
        return appendCitationsIfMissing(text, citationTokens);
      }
    }

    return String(value);
  }, [appendCitationsIfMissing, extractChunkIdsWithLabelsFromCitationObjects, extractCitationReferenceTargetsFromCitationObjects]);

  const collectChunkIdsFromContent = useCallback((value: any): string[] => {
    if (!value) return [];

    if (Array.isArray(value)) {
      return value.flatMap((item: any) => collectChunkIdsFromContent(item));
    }

    if (typeof value === 'object') {
      const directIds = Array.isArray(value.supporting_chunk_ids)
        ? value.supporting_chunk_ids.map((id: any) => String(id)).filter(Boolean)
        : [];
      const citationIds = extractChunkIdsFromCitationObjects(value.supporting_citations);

      const nestedIds = value.content && typeof value.content !== 'string'
        ? collectChunkIdsFromContent(value.content)
        : [];

      return [...directIds, ...citationIds, ...nestedIds];
    }

    return [];
  }, [extractChunkIdsFromCitationObjects]);

  const normalizeSectionsForTab = useCallback((tabKey: string, tabData: any): SectionData[] => {
    const paragraphs = Array.isArray(tabData?.paragraphs) ? tabData.paragraphs : [];
    const historicalReviews = Array.isArray(tabData?.historical_reviews) ? tabData.historical_reviews : [];
    const isPastReviewAnalysis = tabKey.toLowerCase().includes('past review analysis');
    const isPolicyKodRegulatoryAnalysis = /policy.*kod.*regulatory\s+analysis/i.test(tabKey);
    const isBroadScopeDirection = tabKey.toLowerCase().includes('broad scope direction');
    const shouldPreserveStructuredTabShape = isPolicyKodRegulatoryAnalysis || isBroadScopeDirection;
    const rawTabDataSnapshot = shouldPreserveStructuredTabShape
      ? JSON.parse(JSON.stringify(tabData))
      : undefined;

    const hasRenderableTabData = (() => {
      if (!tabData || typeof tabData !== 'object') return false;

      const keysToIgnore = new Set([
        'report_title',
        'current_review_id',
        'similar_review_count',
        'paragraphs',
        'historical_reviews',
      ]);

      const hasExtraData = Object.entries(tabData).some(([key, value]) => {
        if (keysToIgnore.has(key)) return false;
        if (value == null) return false;
        if (typeof value === 'string') return value.trim().length > 0;
        if (Array.isArray(value)) return value.length > 0;
        if (typeof value === 'object') return Object.keys(value).length > 0;
        if (typeof value === 'number') return value !== 0;
        return Boolean(value);
      });

      return paragraphs.length > 0 || historicalReviews.length > 0 || hasExtraData;
    })();

    // For Past Review Analysis, prefer structured historical review payload when available,
    // even if paragraph content also exists.
    if (isPastReviewAnalysis && historicalReviews.length > 0) {
      const summaryCount = Number(tabData?.similar_review_count || historicalReviews.length || 0);
      const currentReviewId = tabData?.current_review_id ? String(tabData.current_review_id) : 'N/A';

      const normalizeArea = (value: any): string => String(value || '').trim().toLowerCase();

      const pickAssessmentByPriority = (
        assessments: any[],
        preferredAreas: string[]
      ): any | undefined => {
        if (!Array.isArray(assessments) || assessments.length === 0) return undefined;
        const normalizedPreferred = preferredAreas.map((area) => area.toLowerCase());

        for (const preferred of normalizedPreferred) {
          const found = assessments.find((assessment: any) => normalizeArea(assessment?.assessed_area) === preferred);
          if (found) return found;
        }

        for (const preferred of normalizedPreferred) {
          const found = assessments.find((assessment: any) => normalizeArea(assessment?.assessed_area).includes(preferred));
          if (found) return found;
        }

        return assessments[0];
      };

      const pickAssessmentsByPriority = (
        assessments: any[],
        preferredAreas: string[]
      ): any[] => {
        if (!Array.isArray(assessments) || assessments.length === 0) return [];
        const selected: any[] = [];
        const seen = new Set<any>();
        const normalizedPreferred = preferredAreas.map((area) => area.toLowerCase());

        normalizedPreferred.forEach((preferred) => {
          const exact = assessments.find((assessment: any) => normalizeArea(assessment?.assessed_area) === preferred);
          if (exact && !seen.has(exact)) {
            selected.push(exact);
            seen.add(exact);
          }
        });

        normalizedPreferred.forEach((preferred) => {
          const partial = assessments.find((assessment: any) => normalizeArea(assessment?.assessed_area).includes(preferred));
          if (partial && !seen.has(partial)) {
            selected.push(partial);
            seen.add(partial);
          }
        });

        if (selected.length === 0 && assessments[0]) {
          selected.push(assessments[0]);
        }

        return selected;
      };

      const uniqueSentences = (items: { text: string; citations: string[] }[]): { text: string; citations: string[] }[] => {
        const seenText = new Set<string>();
        return items.filter((item) => {
          const key = String(item?.text || '').trim().toLowerCase();
          if (!key || seenText.has(key)) return false;
          seenText.add(key);
          return true;
        });
      };

      const allAssessments = historicalReviews.flatMap((review: any) => {
        const reviewId = review?.historical_review_id || 'N/A';
        const reviewTitle = review?.review_title || 'Historical Review';
        const assessments = Array.isArray(review?.assessments) ? review.assessments : [];

        return assessments.map((assessment: any, assessmentIndex: number) => ({
          reviewId,
          reviewTitle,
          assessmentIndex,
          assessedArea: assessment?.assessed_area || 'N/A',
          keyObservations: extractEvidenceItems(assessment?.key_observation),
          implications: extractEvidenceItems(assessment?.implication_for_current_review),
        }));
      });

      const keyObservations: PastReviewGroupedItems[] = historicalReviews.map((review: any) => {
        const reviewId = String(review?.historical_review_id || 'N/A');
        const reviewTitle = String(review?.review_title || 'Historical Review');
        const assessments = Array.isArray(review?.assessments) ? review.assessments : [];
        const selectedAssessments = pickAssessmentsByPriority(assessments, [
          'number of similar reviews performed in the past',
          'overall influence on the current scope'
        ]);

        const observationItems = uniqueSentences(
          selectedAssessments
            .slice(0, 1)
            .flatMap((assessment: any) => extractEvidenceItems(assessment?.key_observation))
        ).slice(0, 5);

        return {
          reviewId,
          reviewTitle,
          items: observationItems.length > 0
            ? observationItems.map((obs: any) => ({
              text: String(obs.text || ''),
              citations: Array.isArray(obs.citations) ? obs.citations.map((c: any) => String(c)).filter(Boolean) : []
            } as PastReviewSentence))
            : [{ text: 'No key observation provided.', citations: [] }]
        };
      });

      const keyObservationAssessmentIndexByReviewId = historicalReviews.reduce((acc: Record<string, number>, review: any) => {
        const reviewId = String(review?.historical_review_id || 'N/A');
        const assessments = Array.isArray(review?.assessments) ? review.assessments : [];
        const selectedAssessments = pickAssessmentsByPriority(assessments, [
          'number of similar reviews performed in the past',
          'overall influence on the current scope'
        ]);
        const selected = selectedAssessments[0];
        const index = selected ? assessments.findIndex((assessment: any) => assessment === selected) : -1;
        acc[reviewId] = index >= 0 ? index : 0;
        return acc;
      }, {});

      const implications: PastReviewGroupedItems[] = historicalReviews.map((review: any) => {
        const reviewId = String(review?.historical_review_id || 'N/A');
        const reviewTitle = String(review?.review_title || 'Historical Review');
        const assessments = Array.isArray(review?.assessments) ? review.assessments : [];
        const selectedAssessments = pickAssessmentsByPriority(assessments, [
          'number of similar reviews performed in the past',
          'overall influence on the current scope',
          'scope focus and testing approach'
        ]);

        const implicationItems = uniqueSentences(
          selectedAssessments
            .slice(0, 1)
            .flatMap((assessment: any) => extractEvidenceItems(assessment?.implication_for_current_review))
        ).slice(0, 4);

        return {
          reviewId,
          reviewTitle,
          items: implicationItems.length > 0
            ? implicationItems.map((imp: any) => ({
              text: String(imp.text || ''),
              citations: Array.isArray(imp.citations) ? imp.citations.map((c: any) => String(c)).filter(Boolean) : []
            } as PastReviewSentence))
            : [{ text: 'No implication provided.', citations: [] }]
        };
      });

      const implicationAssessmentIndexByReviewId = historicalReviews.reduce((acc: Record<string, number>, review: any) => {
        const reviewId = String(review?.historical_review_id || 'N/A');
        const assessments = Array.isArray(review?.assessments) ? review.assessments : [];
        const selectedAssessments = pickAssessmentsByPriority(assessments, [
          'number of similar reviews performed in the past',
          'overall influence on the current scope',
          'scope focus and testing approach'
        ]);
        const selected = selectedAssessments[0];
        const index = selected ? assessments.findIndex((assessment: any) => assessment === selected) : -1;
        acc[reviewId] = index >= 0 ? index : 0;
        return acc;
      }, {});

      const tableRows: PastReviewTableRow[] = allAssessments
        .filter((item: any) => normalizeArea(item.assessedArea) !== 'number of similar reviews performed in the past')
        .map((item: any) => ({
          historicalReviewId: String(item.reviewId),
          assessedArea: String(item.assessedArea),
          keyObservations: item.keyObservations
            .map((obs: any) => appendCitationsIfMissing(String(obs?.text || ''), Array.isArray(obs?.citations) ? obs.citations : []))
            .join(' ')
            .trim() || 'N/A',
          relevanceToCurrentReview: item.implications
            .map((imp: any) => appendCitationsIfMissing(String(imp?.text || ''), Array.isArray(imp?.citations) ? imp.citations : []))
            .join(' ')
            .trim() || 'N/A',
          keyObservationCitations: Array.from(new Set(item.keyObservations.flatMap((obs: any) => Array.isArray(obs.citations) ? obs.citations : []).map((c: any) => String(c)).filter(Boolean))),
          relevanceCitations: Array.from(new Set(item.implications.flatMap((imp: any) => Array.isArray(imp.citations) ? imp.citations : []).map((c: any) => String(c)).filter(Boolean))),
        }));

      const tableRowMappings = allAssessments
        .filter((item: any) => normalizeArea(item.assessedArea) !== 'number of similar reviews performed in the past')
        .map((item: any) => ({
          reviewId: String(item.reviewId),
          assessmentIndex: Number(item.assessmentIndex ?? 0),
        }));

      const pastReviewSupportingCitations = mergeSupportingCitations(
        [],
        historicalReviews.flatMap((review: any) => {
          const assessments = Array.isArray(review?.assessments) ? review.assessments : [];
          return assessments.flatMap((assessment: any) => ([
            ...collectSupportingCitationsFromAny(assessment?.key_observation),
            ...collectSupportingCitationsFromAny(assessment?.implication_for_current_review),
          ]));
        })
      );

      const description = `This section compares current review ${currentReviewId} with similar historical reviews and summarizes scope-relevant findings.`;

      return [{
        id: `${tabKey}-past-review-analysis`,
        content: `**Past Review Analysis**\n\n${description}`,
        rationale: '',
        confidenceScore: 0,
        supportingChunkIds: [],
        supportingCitations: pastReviewSupportingCitations,
        pastReviewAnalysis: {
          title: 'Past Review Analysis',
          description,
          summaryCount,
          keyObservations,
          implications,
          tableRows,
        },
        pastReviewEditMeta: {
          rawTabData: JSON.parse(JSON.stringify(tabData)),
          keyObservationAssessmentIndexByReviewId,
          implicationAssessmentIndexByReviewId,
          tableRowMappings,
        }
      }];
    }

    if (paragraphs.length > 0) {
      const groupedSections: SectionData[] = [];
      let currentSection: SectionData | null = null;

      paragraphs.forEach((para: any, index: number) => {
        const metadata = para?.metadata || {};
        const paragraphId = para?.paragraph_id || `${tabKey}-para-${index + 1}`;
        const paragraphContent = flattenParagraphContent(para?.content || '');
        const paragraphSupportingCitations = mergeSupportingCitations(
          normalizeSupportingCitationsFromValue(para?.supporting_citations),
          collectSupportingCitationsFromAny(para?.content)
        );
        const paragraphLabeledChunkIds = extractChunkIdsWithLabelsFromCitationObjects(para?.supporting_citations);
        const paragraphCitationTokens = Array.from(new Set([
          ...extractCitationReferenceTargetsFromCitationObjects(para?.supporting_citations),
          ...(Array.isArray(para?.supporting_chunk_ids)
            ? para.supporting_chunk_ids
              .map((id: any) => String(id).trim())
              .filter((id: string) => Boolean(id) && !paragraphLabeledChunkIds.has(id))
            : []),
        ]));
        const paragraphContentWithCitations = appendCitationsIfMissing(paragraphContent, paragraphCitationTokens);
        const supportingChunkIds = Array.from(new Set([
          ...(Array.isArray(para?.supporting_chunk_ids) ? para.supporting_chunk_ids.map((id: any) => String(id)).filter(Boolean) : []),
          ...paragraphSupportingCitations.map((citation) => citation.chunkId),
          ...collectChunkIdsFromContent(para?.content),
        ]));

        if (metadata?.is_section_start || !currentSection) {
          if (currentSection) {
            groupedSections.push(currentSection);
          }
          currentSection = {
            id: paragraphId,
            content: paragraphContentWithCitations,
            rationale: para?.rationale || '',
            confidenceScore: metadata?.section_confidence_score ?? 0,
            supportingChunkIds: [...supportingChunkIds],
            supportingCitations: mergeSupportingCitations([], paragraphSupportingCitations),
            structuredTabEditMeta: shouldPreserveStructuredTabShape
              ? {
                rawTabData: rawTabDataSnapshot,
                paragraphIndices: [index],
              }
              : undefined,
          };
        } else {
          currentSection.content += '\n\n' + paragraphContentWithCitations;
          currentSection.supportingChunkIds = Array.from(new Set([
            ...currentSection.supportingChunkIds,
            ...supportingChunkIds
          ]));
          currentSection.supportingCitations = mergeSupportingCitations(
            currentSection.supportingCitations || [],
            paragraphSupportingCitations
          );
          if (shouldPreserveStructuredTabShape) {
            currentSection.structuredTabEditMeta = {
              rawTabData: currentSection.structuredTabEditMeta?.rawTabData || rawTabDataSnapshot,
              paragraphIndices: [
                ...(currentSection.structuredTabEditMeta?.paragraphIndices || []),
                index,
              ],
            };
          }
        }
      });

      if (currentSection) {
        groupedSections.push(currentSection);
      }

      return groupedSections;
    }

    if (historicalReviews.length > 0) {
      return historicalReviews.flatMap((review: any, reviewIndex: number) => {
        const reviewTitle = review?.review_title || `Historical Review ${reviewIndex + 1}`;
        const reviewId = review?.historical_review_id || `review-${reviewIndex + 1}`;
        const assessments = Array.isArray(review?.assessments) ? review.assessments : [];

        if (assessments.length === 0) {
          return [{
            id: `${tabKey}-${reviewId}`,
            content: `### ${reviewTitle}\n\nNo assessments returned for this review.`,
            rationale: '',
            confidenceScore: 0,
            supportingChunkIds: []
          } as SectionData];
        }

        return assessments.map((assessment: any, assessmentIndex: number) => {
          const keyObservations = extractStructuredContent(assessment?.key_observation);
          const implications = extractStructuredContent(assessment?.implication_for_current_review);

          const content = [
            `### ${reviewTitle} (${reviewId})`,
            `**Assessed Area:** ${assessment?.assessed_area || 'N/A'}`,
            keyObservations.length > 0 ? `\n**Key Observation**\n${keyObservations.map((item: string) => `- ${item}`).join('\n')}` : '',
            implications.length > 0 ? `\n**Implication for Current Review**\n${implications.map((item: string) => `- ${item}`).join('\n')}` : ''
          ].filter(Boolean).join('\n\n');

          return {
            id: `${tabKey}-${reviewId}-${assessmentIndex + 1}`,
            content,
            rationale: '',
            confidenceScore: 0,
            supportingChunkIds: [],
            structuredTabEditMeta: shouldPreserveStructuredTabShape
              ? {
                rawTabData: rawTabDataSnapshot,
                reviewIndex,
                assessmentIndex,
              }
              : undefined,
          } as SectionData;
        });
      });
    }

    if (!hasRenderableTabData) {
      return [{
        id: `${tabKey}-no-data-1`,
        content: 'No data found',
        rationale: '',
        confidenceScore: 0,
        supportingChunkIds: [],
        isNoData: true,
      }];
    }

    return [{
      id: `${tabKey}-no-data-2`,
      content: 'No data found',
      rationale: '',
      confidenceScore: 0,
      supportingChunkIds: [],
      isNoData: true,
    }];
  }, [appendCitationsIfMissing, collectChunkIdsFromContent, collectSupportingCitationsFromAny, extractChunkIdsWithLabelsFromCitationObjects, extractCitationReferenceTargetsFromCitationObjects, extractEvidenceItems, extractStructuredContent, flattenParagraphContent, mergeSupportingCitations, normalizeSupportingCitationsFromValue]);

  const normalizeReportDataShape = useCallback((rawData: any): Record<string, { title: string, sections: SectionData[] }> => {
    if (!rawData || typeof rawData !== 'object') {
      return {};
    }

    const isAlreadyNormalized = Object.values(rawData).every((item: any) => (
      item && typeof item === 'object' && typeof item.title === 'string' && Array.isArray(item.sections)
    ));

    if (isAlreadyNormalized) {
      return rawData as Record<string, { title: string, sections: SectionData[] }>;
    }

    const analysisReport =
      rawData?.analysis_report ??
      rawData?.response?.analysis_report ??
      rawData?.payload?.analysis_report ??
      rawData?.data?.analysis_report ??
      rawData?.result?.analysis_report ??
      rawData;

    if (!analysisReport || typeof analysisReport !== 'object') {
      return {};
    }

    const normalized: Record<string, { title: string, sections: SectionData[] }> = {};

    Object.keys(analysisReport).forEach((tabKey) => {
      const tabData: any = analysisReport[tabKey];
      if (!tabData || typeof tabData !== 'object') return;

      const hasTabShape = Boolean(
        tabData?.report_title ||
        Array.isArray(tabData?.paragraphs) ||
        Array.isArray(tabData?.historical_reviews)
      );

      if (!hasTabShape) return;

      normalized[tabKey] = {
        title: tabData?.report_title || tabKey,
        sections: normalizeSectionsForTab(tabKey, tabData)
      };
    });

    return normalized;
  }, [normalizeSectionsForTab]);

  const buildAnalysisReport = useCallback((data: Record<string, { title: string, sections: SectionData[] }>): PreliminaryResearchReport => {
    const analysisReport: any = {};
    Object.keys(data).forEach(tabKey => {
      const sections = data[tabKey].sections || [];
      const pastReviewSection = sections.find((section) => Boolean(section.pastReviewEditMeta?.rawTabData));
      const structuredSection = sections.find((section) => Boolean(section.structuredTabEditMeta?.rawTabData));

      if (pastReviewSection?.pastReviewEditMeta?.rawTabData) {
        const reconstructed = applyPastReviewEditorHtmlToRawTabData(
          pastReviewSection.pastReviewEditMeta.rawTabData,
          String(pastReviewSection.content || ''),
          pastReviewSection.pastReviewEditMeta
        );

        analysisReport[tabKey] = reconstructed;
        return;
      }

      if (structuredSection?.structuredTabEditMeta?.rawTabData) {
        const reconstructed = applyStructuredSectionsToRawTabData(
          structuredSection.structuredTabEditMeta.rawTabData,
          sections
            .filter((section) => Boolean(section.structuredTabEditMeta))
            .map((section) => ({
              content: String(section.content || ''),
              paragraphIndices: section.structuredTabEditMeta?.paragraphIndices || [],
              reviewIndex: section.structuredTabEditMeta?.reviewIndex,
              assessmentIndex: section.structuredTabEditMeta?.assessmentIndex,
            }))
        );

        analysisReport[tabKey] = reconstructed;
        return;
      }

      analysisReport[tabKey] = {
        report_title: data[tabKey].title,
        paragraphs: sections.map(section => ({
          paragraph_id: section.id,
          content: section.content,
          supporting_chunk_ids: section.supportingChunkIds,
          rationale: section.rationale,
          metadata: {
            is_section_start: true,
            section_confidence_score: section.confidenceScore
          }
        }))
      };
    });

    return analysisReport as PreliminaryResearchReport;
  }, []);

  useEffect(() => {
    const handleGenerate = (event: Event) => {
      if (!canRunAnalytics) {
        showErrorToast('Action not available', 'RUN_ANALYTICS is not available for this plan.');
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'prelim-research-loading' }
        }));
        window.dispatchEvent(new CustomEvent('preliminary-research:sync', {
          detail: { status: 'failed' }
        }));
        return;
      }

      const detail = (event as CustomEvent<PreliminaryResearchGenerateEventDetail>).detail;
      const sections = detail?.payload?.sections;
      runAnalyticsPayloadRef.current = Array.isArray(sections) && sections.length > 0
        ? { sections }
        : {};
      setGenerationState('generating');
    };
    window.addEventListener('ai-chat:generate-preliminary-research', handleGenerate);
    return () => window.removeEventListener('ai-chat:generate-preliminary-research', handleGenerate);
  }, [canRunAnalytics]);

  useEffect(() => {
    let cancelled = false;

    const handleWorkflowExecuted = async (event: Event) => {
      if (!planId) return;
      const detail = (event as CustomEvent<{
        planNumber?: string;
        planId?: string;
        document?: unknown;
      }>).detail;
      const eventPlanId = String(detail?.planNumber ?? detail?.planId ?? '').trim();
      if (eventPlanId && eventPlanId !== String(planId).trim()) {
        return;
      }

      const applyReport = (rawDoc: unknown): boolean => {
        if (!rawDoc) return false;
        const normalizedData = normalizeReportDataShape(rawDoc);
        const tabs = Object.keys(normalizedData);
        if (tabs.length === 0) return false;
        setReportData(normalizedData);
        dispatch(setPreliminaryResearchData({ planNumber: planId, data: normalizedData }));
        setActiveTab((previousTab) => (previousTab && normalizedData[previousTab] ? previousTab : tabs[0]));
        setGenerationState('generated');
        return true;
      };

      if (applyReport(detail?.document)) {
        return;
      }

      if (!canGetPreliminaryResearchDocumentRef.current) return;
      setGetApiPendingCount((prev) => prev + 1);
      try {
        const response = await getPreliminaryResearchDocumentIfAllowed(planId);
        if (!cancelled) {
          applyReport(response);
        }
      } catch {
        // Best-effort refresh after chat-triggered regeneration
      } finally {
        if (!cancelled) {
          setGetApiPendingCount((prev) => Math.max(0, prev - 1));
        }
      }
    };

    window.addEventListener('ai-chat:preliminary-research-workflow-executed', handleWorkflowExecuted);
    return () => {
      cancelled = true;
      window.removeEventListener('ai-chat:preliminary-research-workflow-executed', handleWorkflowExecuted);
    };
  }, [planId, dispatch, normalizeReportDataShape, getPreliminaryResearchDocumentIfAllowed]);

  // Synchronize component state with Redux when planId changes
  useEffect(() => {
    if (reduxReportData) {
      const normalizedData = normalizeReportDataShape(reduxReportData);
      setReportData(normalizedData);
      const tabs = Object.keys(normalizedData);
      setGenerationState(tabs.length > 0 ? 'generated' : 'empty');
      if (tabs.length > 0) {
        setActiveTab((previousTab) => (previousTab && normalizedData[previousTab] ? previousTab : tabs[0]));
      }
    } else {
      setReportData({});
      setGenerationState('empty');
      setActiveTab('');
    }
    setEditingSectionId(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [planId, reduxReportData, normalizeReportDataShape]);

  useEffect(() => {
    if (!planId || reduxReportData || generationState === 'generating') return;
    if (!canGetPreliminaryResearchDocument) return;

    let cancelled = false;

    const fetchPreliminaryResearchIfEmpty = async () => {
      setGetApiPendingCount((prev) => prev + 1);
      try {
        const response = await getPreliminaryResearchDocumentIfAllowed(planId);
        if (cancelled || !response) return;

        const normalizedData = normalizeReportDataShape(response);
        const tabs = Object.keys(normalizedData);
        if (tabs.length === 0) return;

        dispatch(setPreliminaryResearchData({ planNumber: planId, data: normalizedData }));
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: 'prelim-research-loading' }
        }));
      } catch {
        // Intentionally no-op on error as requested.
      } finally {
        setGetApiPendingCount((prev) => Math.max(0, prev - 1));
      }
    };

    fetchPreliminaryResearchIfEmpty();

    return () => {
      cancelled = true;
    };
  }, [planId, reduxReportData, generationState, canGetPreliminaryResearchDocument, normalizeReportDataShape, dispatch, getPreliminaryResearchDocumentIfAllowed]);

  useEffect(() => {
    if (!planId || !reduxReportData) return;
    if (!canGetPreliminaryResearchDocument) return;
    if (pastReviewRefreshAttemptedRef.current[planId]) return;

    const normalizedData = normalizeReportDataShape(reduxReportData);
    const pastReviewTabKey = Object.keys(normalizedData).find((key) => key.toLowerCase().includes('past review analysis'));
    if (!pastReviewTabKey) return;

    const pastReviewSections = normalizedData[pastReviewTabKey]?.sections || [];
    const hasStructuredPastReviewSection = pastReviewSections.some((section) => Boolean(section.pastReviewAnalysis));

    // Existing cached state can contain legacy paragraph-only shape.
    // Refresh once from backend to load latest tab structure.
    if (pastReviewSections.length === 0 || hasStructuredPastReviewSection) return;

    pastReviewRefreshAttemptedRef.current[planId] = true;

    let cancelled = false;

    const refreshFromBackend = async () => {
      setGetApiPendingCount((prev) => prev + 1);
      try {
        const response = await getPreliminaryResearchDocumentIfAllowed(planId);
        if (!response) return;
        const refreshedData = normalizeReportDataShape(response);
        const mergedData = {
          ...normalizedData,
          ...refreshedData,
        };
        const tabs = Object.keys(mergedData);
        if (tabs.length === 0 || cancelled) return;

        setReportData(mergedData);
        dispatch(setPreliminaryResearchData({ planNumber: planId, data: mergedData }));

        setActiveTab((previousTab) => (previousTab && mergedData[previousTab] ? previousTab : tabs[0]));
      } catch (error) {
        console.warn('Unable to refresh preliminary research document for updated Past Review layout.', error);
      } finally {
        setGetApiPendingCount((prev) => Math.max(0, prev - 1));
      }
    };

    refreshFromBackend();

    return () => {
      cancelled = true;
    };
  }, [planId, reduxReportData, normalizeReportDataShape, dispatch, canGetPreliminaryResearchDocument, getPreliminaryResearchDocumentIfAllowed]);

  /**
   * Fetches and processes the preliminary research report.
   */
  useEffect(() => {
    if (generationState === 'generating') {
      const fetchResearch = async () => {
        if (!planId) return;
        try {
          const response = await generatePreliminaryResearch(
            planId,
            runAnalyticsPayloadRef.current,
            { allowGetDocumentPolling: canGetPreliminaryResearchDocument }
          );
          const newReportData = normalizeReportDataShape(response);
          const tabs = Object.keys(newReportData);

          if (tabs.length === 0) {
            throw new Error('Preliminary research generation completed without report content.');
          }

          setReportData(newReportData);
          dispatch(setPreliminaryResearchData({ planNumber: planId, data: newReportData }));
          setActiveTab(tabs[0]);
          setGenerationState('generated');

          window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
            detail: { id: 'prelim-research-loading' }
          }));
          window.dispatchEvent(new CustomEvent('preliminary-research:sync', {
            detail: { status: 'completed' }
          }));
          window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
          runAnalyticsPayloadRef.current = {};
        } catch (error) {
          console.error('Failed to generate preliminary research:', error);
          setReportData({});
          setActiveTab('');
          if (planId) {
            dispatch(setPreliminaryResearchData({ planNumber: planId, data: {} }));
          }
          setGenerationState('empty');
          window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
            detail: { id: 'prelim-research-loading' }
          }));
          window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
            detail: { sender: 'ai', content: 'Failed to generate preliminary research. Please try again.' }
          }));
          window.dispatchEvent(new CustomEvent('preliminary-research:sync', {
            detail: { status: 'failed' }
          }));
          runAnalyticsPayloadRef.current = {};
        }
      };

      fetchResearch();
    }
  }, [generationState, planId, dispatch, normalizeReportDataShape, canGetPreliminaryResearchDocument]);

  /**
   * Cleans up any pending timeouts on unmount.
   */
  useEffect(() => {
    return () => {
      if (redirectTimeoutRef.current) clearTimeout(redirectTimeoutRef.current);
    };
  }, []);

  /**
   * Initiates the edit mode for a specific section.
   * 
   * @param {SectionData} section - The section data to be edited.
   */
  const handleEditClick = useCallback((section: SectionData) => {
    if (!canEditPreliminaryResearchDocument) {
      //showErrorToast('Action not available', 'EDIT_PRELIMINARY_RESEARCH_DOCUMENT is not available for this plan.');
      // return;
    }

    const sourceContent = section.pastReviewAnalysis
      ? buildPastReviewAnalysisEditorText(section.pastReviewAnalysis, reportData[activeTab]?.title, section.pastReviewEditMeta)
      : section.content;
    const isPolicyKodRegulatoryTab = /policy.*kod.*regulatory\s+analysis/i.test(String(activeTab || ''));
    const isBroadScopeDirectionTab = activeTab?.toLowerCase().includes('broad scope direction');
    const isPolicyOrBroadTab = isPolicyKodRegulatoryTab || isBroadScopeDirectionTab;
    const usePlainTextEditor = Boolean(section.pastReviewAnalysis) || isPolicyKodRegulatoryTab || isBroadScopeDirectionTab;
    const normalizeStructuredEditorContent = (value: string): string => {
      const raw = String(value || '');
      // `<u>` is part of the stored text format (the editor supports it), so keep it while stripping other HTML.
      const U_OPEN = '\u0001U_OPEN\u0001';
      const U_CLOSE = '\u0001U_CLOSE\u0001';
      const protectedRaw = raw
        .replace(/<u>/gi, U_OPEN)
        .replace(/<\/u>/gi, U_CLOSE);
      const hasHtmlTags = /<\/?[a-z][\s\S]*>/i.test(protectedRaw);
      if (!hasHtmlTags) return raw;

      const text = stripHtmlToText(protectedRaw)
        .replace(/\u00a0/g, ' ')
        .replace(/\s+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
        .split(U_OPEN).join('<u>')
        .split(U_CLOSE).join('</u>');

      return text || raw;
    };
    const plainText = replaceCitationReferenceTokensWithLabels(
      String(sourceContent || ''),
      section.supportingCitations || []
    );
    const explicitLines = plainText.split(/\r?\n/).length;
    const wrappedLines = Math.ceil(plainText.length / 110);
    const estimatedLines = Math.max(explicitLines, wrappedLines);
    const computedHeight = Math.max(120, Math.min(700, estimatedLines * 22 + 80));

    if (isPolicyOrBroadTab) {
      const activeSections = reportData[activeTab]?.sections || [];
      const initialSectionEditMap = activeSections.reduce((acc: Record<string, string>, currentSection: SectionData) => {
        acc[currentSection.id] = normalizeStructuredEditorContent(
          replaceCitationReferenceTokensWithLabels(
            String(currentSection.content || ''),
            currentSection.supportingCitations || []
          )
        );
        return acc;
      }, {});
      setSectionEditContentById(initialSectionEditMap);
      setEditingSectionId(ALL_SECTIONS_EDIT_ID);
    } else {
      setEditingSectionId(section.id);
    }
    setEditContent(usePlainTextEditor ? normalizeStructuredEditorContent(plainText) : markdownToEditorHtml(plainText));
    setEditBoxHeight(computedHeight);
    setSaveState('idle');
  }, [canEditPreliminaryResearchDocument, activeTab, reportData]);

  /**
   * Saves the edited content for a specific section.
   * 
   * @param {string} id - The unique identifier of the section.
   */
  const handleSaveClick = useCallback(async (id: string) => {
    if (saveState === 'loading') return;

    if (!canEditPreliminaryResearchDocument) {
      //showErrorToast('Action not available', 'EDIT_PRELIMINARY_RESEARCH_DOCUMENT is not available for this plan.');
      //return;
    }

    if (!activeTab || !reportData[activeTab]) return;

    const isPolicyKodRegulatoryTab = /policy.*kod.*regulatory\s+analysis/i.test(String(activeTab || ''));
    const isBroadScopeDirectionTab = activeTab.toLowerCase().includes('broad scope direction');
    const isPolicyOrBroadTab = isPolicyKodRegulatoryTab || isBroadScopeDirectionTab;
    const isEditAllStructuredSections = isPolicyOrBroadTab && editingSectionId === ALL_SECTIONS_EDIT_ID;

    const sectionBeingEdited = reportData[activeTab].sections.find((s) => s.id === id);
    const isPastReviewSectionEdit = Boolean(sectionBeingEdited?.pastReviewAnalysis)
      || activeTab.toLowerCase().includes('past review analysis');    // Past review keeps its own text format; generic tabs: editor HTML -> **bold** / * list markdown.
    const contentToPersist = isPastReviewSectionEdit
      ? editContent
      : editorHtmlToMarkdown(editContent);

    let rebuiltPastReviewSection: SectionData | undefined;
    if (isPastReviewSectionEdit && sectionBeingEdited?.pastReviewEditMeta?.rawTabData) {
      const reconstructed = applyPastReviewEditorHtmlToRawTabData(
        sectionBeingEdited.pastReviewEditMeta.rawTabData,
        String(editContent || ''),
        sectionBeingEdited.pastReviewEditMeta
      );

      const normalizedFromReconstructed = normalizeSectionsForTab(activeTab, reconstructed);
      const normalizedPastReviewSection = normalizedFromReconstructed.find((s) => Boolean(s.pastReviewAnalysis))
        || normalizedFromReconstructed[0];

      if (normalizedPastReviewSection) {
        rebuiltPastReviewSection = {
          ...sectionBeingEdited,
          content: String(editContent || ''),
          pastReviewAnalysis: normalizedPastReviewSection.pastReviewAnalysis,
          pastReviewEditMeta: {
            ...(normalizedPastReviewSection.pastReviewEditMeta || sectionBeingEdited.pastReviewEditMeta),
            rawTabData: reconstructed,
          },
        };
      }
    }

    const updatedTabData = { ...reportData[activeTab] };
    if (isEditAllStructuredSections) {
      updatedTabData.sections = updatedTabData.sections.map((s) => ({
        ...s,
        content: sectionEditContentById[s.id] ?? s.content,
      }));
    } else {
      updatedTabData.sections = updatedTabData.sections.map(s => s.id === id
        ? (rebuiltPastReviewSection && isPastReviewSectionEdit
          ? { ...rebuiltPastReviewSection, id: s.id }
          : {
            ...s,
            content: contentToPersist,
            pastReviewAnalysis: s.pastReviewAnalysis,
            pastReviewEditMeta: s.pastReviewEditMeta,
          })
        : s);
    }
    const newData = { ...reportData, [activeTab]: updatedTabData };
    const previousData = reportData;

    setReportData(newData);
    setSaveState('loading');

    if (planId) {
      dispatch(setPreliminaryResearchData({ planNumber: planId, data: newData }));

      try {
        await editPreliminaryResearchDocument(planId, {
          plan_number: planId,
          analysis_report: buildAnalysisReport(newData)
        });

        if (canGetPreliminaryResearchDocument) {
          setGetApiPendingCount((prev) => prev + 1);
          const refreshedResponse = await getPreliminaryResearchDocumentIfAllowed(planId);
          if (!refreshedResponse) {
            setGetApiPendingCount((prev) => Math.max(0, prev - 1));
            showSuccessToast('Section updated successfully');
            setEditingSectionId(null);
            setSectionEditContentById({});
            setSaveState('idle');
            return;
          }
          const refreshedData = normalizeReportDataShape(refreshedResponse);
          const refreshedTabs = Object.keys(refreshedData);

          if (refreshedTabs.length > 0) {
            setReportData(refreshedData);
            dispatch(setPreliminaryResearchData({ planNumber: planId, data: refreshedData }));
            setActiveTab((previousTab) => (previousTab && refreshedData[previousTab] ? previousTab : refreshedTabs[0]));
          }
          setGetApiPendingCount((prev) => Math.max(0, prev - 1));
        }

        showSuccessToast('Section updated successfully');
      } catch (error) {
        setGetApiPendingCount((prev) => Math.max(0, prev - 1));
        console.error('Failed to persist preliminary research edits:', error);
        const errorMessage = error instanceof Error ? error.message : 'Failed to save changes';
        showErrorToast('Failed to update section', errorMessage);
        // Revert the local state on API failure
        setReportData(previousData);
        dispatch(setPreliminaryResearchData({ planNumber: planId, data: previousData }));
        setEditingSectionId(id);
        setSaveState('idle');
        return;
      }
    }

    setEditingSectionId(null);
    setSectionEditContentById({});
    setSaveState('idle');
  }, [activeTab, reportData, editContent, planId, dispatch, buildAnalysisReport, canEditPreliminaryResearchDocument, normalizeSectionsForTab, canGetPreliminaryResearchDocument, normalizeReportDataShape, saveState, editingSectionId, sectionEditContentById, getPreliminaryResearchDocumentIfAllowed]);

  /**
   * Cancels the current edit operation and resets edit state.
   */
  const handleCancelClick = useCallback(() => {
    if (saveState === 'loading') return;
    setEditingSectionId(null);
    setSectionEditContentById({});
    setEditContent('');
    setSaveState('idle');
  }, [saveState]);

  /**
   * Generate PDF viewer URL with page parameter
   */
  const getPdfViewerUrl = (uri: string, pageNumber?: number): string => {
    let url = `/pdfjs/web/viewer.html?file=${encodeURIComponent(uri)}`;

    // Add page number if available (1-indexed in PDF.js)
    if (pageNumber && pageNumber > 0) {
      url += `#page=${pageNumber}`;
    }

    return url;
  };

  /**
   * Handle opening PDF document with page number from chunk details
   */
  const handleChunkClick = useCallback(async (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!canGetCitationDocument) {
      e.preventDefault();
      showErrorToast('Action not available', 'GET_CITATION_DOCUMENT is not available for this plan.');
      return;
    }

    e.preventDefault();

    const fetchChunkDetailsById = async (chunkIdToFetch: string): Promise<any | null> => {
      const normalizedChunkId = String(chunkIdToFetch || '').trim();
      if (!normalizedChunkId || !planId) return null;

      const cachedChunkData = chunkDetailsCache.get(normalizedChunkId);
      if (cachedChunkData) return cachedChunkData;

      const rcToken = (window as any).__dbawareRcToken as string | null | undefined;
      const response = await fetch(`/dbaware-ui/${planId}/docs/${normalizedChunkId}`, {
        headers: rcToken ? { 'x-asm-rctoken': rcToken } : undefined
      });

      if (!response.ok) return null;

      const documentData = await response.json();
      setChunkDetailsCache((prev) => new Map(prev).set(normalizedChunkId, documentData));
      return documentData;
    };

    const citationRef = parseCitationReference(chunkId);
    if (citationRef) {
      const rawGsUri = String(citationRef.gsUri || '').trim();
      const gsUri = rawGsUri
        ? (/^gs:\/\//i.test(rawGsUri) ? rawGsUri : `gs://${rawGsUri.replace(/^\/+/, '')}`)
        : '';
      let pageNumber = Number(citationRef.pageNumber);
      const sourceUrl = String(citationRef.url || '').trim();
      const citationContentType = String(citationRef.contentType || '').trim().toLowerCase();
      const citationDocumentName = String(citationRef.documentName || '').trim().toLowerCase();
      const isJsonCitation = citationContentType.includes('application/json') || citationDocumentName.endsWith('.json');

      if ((!Number.isFinite(pageNumber) || pageNumber <= 0) && citationRef.chunkId) {
        try {
          const documentData = await fetchChunkDetailsById(citationRef.chunkId);
          if (documentData) {
            const sourcePage = Number(documentData.source?.location_metadata?.page_number);
            pageNumber = Number.isFinite(sourcePage) && sourcePage > 0
              ? sourcePage
              : Number(extractPageNumber(documentData?.source || documentData));
          }
        } catch {
          // Ignore page fallback errors and continue with default page.
        }
      }

      if (gsUri && !isJsonCitation) {
        if (planId) {
          const encodedUri = encodeURIComponent(gsUri);
          const pageParam = Number.isFinite(pageNumber) && pageNumber > 0 ? `&pageNumber=${pageNumber}` : '';
          window.open(`/dbaware-ui/${planId}/docs/uri?document_uri=${encodedUri}${pageParam}`, '_blank', 'noopener,noreferrer');
          return;
        }
      }

      if (citationRef.chunkId) {
        chunkId = citationRef.chunkId;
      }

      if (sourceUrl) {
        window.open(sourceUrl, '_blank', 'noopener,noreferrer');
        return;
      }
    }

    try {
      // Check cache first
      let chunkData = chunkDetailsCache.get(chunkId);

      if (!chunkData && planId) {
        chunkData = await fetchChunkDetailsById(chunkId);

        if (!chunkData) {
          // Fallback to standard document view if chunk details unavailable
          window.open(`/dbaware-ui/${planId}/docs/${chunkId}`, '_blank', 'noopener,noreferrer');
          return;
        }
      }

      // Check if it's a PDF document
      const isPdf = chunkData?.type === 'pdf' ||
        isPdfDocument(chunkData?.source?.document_name || '') ||
        chunkData?.source?.content_type?.includes('pdf');

      if (isPdf && chunkData?.source?.access_info?.uri) {
        const pageNumber = extractPageNumber(chunkData?.source || chunkData);
        const documentName = chunkData?.source?.document_name || chunkId;

        // Open PDF in iframe viewer with page number
        setSelectedPdfData({
          uri: chunkData.source.access_info.uri,
          pageNumber: pageNumber,
          name: documentName,
          chunkId: chunkId
        });
        setPdfViewerOpen(true);
      } else {
        // For non-PDF files, use the standard document URL
        window.open(`/dbaware-ui/${planId}/docs/${chunkId}`, '_blank', 'noopener,noreferrer');
      }
    } catch (error) {
      console.error('Error opening chunk:', error);
      // Fallback to standard document view
      window.open(`/dbaware-ui/${planId}/docs/${chunkId}`, '_blank', 'noopener,noreferrer');
    }
  }, [planId, chunkDetailsCache, canGetCitationDocument]);

  /**
   * Calls HITL approval API for preliminary research.
   */
  const handleApproveClick = useCallback(async () => {
    if (!canAcceptPreliminaryResearch) {
      showErrorToast('Action not available', 'ACCEPT_PRELIMINARY_RESEARCH is not available for this plan.');
      return;
    }

    if (!planId) {
      showErrorToast('Failed to approve preliminary research', 'Plan number is not available.');
      return;
    }

    setApproveState('loading');
    try {
      await acceptPreliminaryResearch(planId);
      setApproveState('sent');
      showSuccessToast(PRELIMINARY_RESEARCH_MESSAGES.APPROVE_SUCCESS);
    } catch (error) {
      console.error('Failed to approve preliminary research:', error);
      setApproveState('idle');
      showErrorToast('Failed to approve preliminary research', 'Could not approve the document.');
    }
  }, [canAcceptPreliminaryResearch, planId]);

  /**
   * Navigates to the discovery walkthrough tab.
   */
  useEffect(() => {
    if (redirectTimeoutRef.current) {
      clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = null;
    }

    if (generationState === 'generated' && approveState === 'sent' && planId) {
      redirectTimeoutRef.current = setTimeout(() => {
        navigate(`../${ScopingTabEnum.DISCOVERY_WALKTHROUGH}/${planId}`);
      }, AUTO_REDIRECT_DELAY_MS);
      return;
    }
  }, [approveState, generationState, navigate, planId]);

  /**
   * Handles copying content to the clipboard and showing a success toast.
   */
  const handleCopyClick = useCallback((content: string) => {
    copyToClipboard(stripHtml(formatMarkdownToHtml(content))).then((success) => {
      if (success) {
        showSuccessToast(PRELIMINARY_RESEARCH_MESSAGES.COPY_SUCCESS);
      }
    });
  }, []);

  /**
   * Triggers a file download containing the Preliminary Research report content.
   */
  const handleDownloadClick = async () => {
    if (!canDownloadPreliminaryResearchDocument) {
      showErrorToast('Action not available', 'DOWNLOAD_PRELIMINARY_RESEARCH_DOCUMENT is not available for this plan.');
      return;
    }

    if (!reportData || Object.keys(reportData).length === 0 || !planId) return;

    try {
      setDownloadState('loading');
      const payload = {
        plan_number: planId,
        analysis_report: buildAnalysisReport(reportData)
      };

      const response = await downloadPreliminaryResearchDocument(planId, payload);
      downloadFile((response as any).data || response, `preliminary_research_${planId}.pdf`, 'application/pdf');
    } catch (error) {
      console.error("Failed to download preliminary research data:", error);
    } finally {
      setDownloadState('idle');
    }
  };

  useEffect(() => {
    if (!canEditPreliminaryResearchDocument && editingSectionId) {
      setEditingSectionId(null);
      setEditContent('');
    }
  }, [canEditPreliminaryResearchDocument, editingSectionId]);

  /**
   * Helper function to get correct style module class based on score.
   */
  const getConfidenceColorClass = (score: number) => {
    const classKey = getConfidenceColorClassKey(score);
    if (classKey === 'scoreHigh') return style.scoreHigh;
    if (classKey === 'scoreMedium') return style.scoreMedium;
    return style.scoreLow;
  };

  return (
    <div className={style.pageContainer}>
      <Card outlined radius="lg" raise="2-subtle">
        {/* PDF Viewer Modal */}
        {pdfViewerOpen && selectedPdfData && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            flexDirection: 'column',
            zIndex: 9999
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '16px',
              backgroundColor: 'var(--wadk-fill-basic-blank, #fff)',
              borderBottom: '1px solid #ddd'
            }}>
              <Text fontWeight="bold">{selectedPdfData.name}</Text>
              <button
                onClick={() => {
                  setPdfViewerOpen(false);
                  setSelectedPdfData(null);
                }}
                style={{
                  backgroundColor: 'transparent',
                  border: 'none',
                  fontSize: '24px',
                  cursor: 'pointer',
                  padding: '0',
                  color: 'var(--wadk-text-basic-light, #666)'
                }}
              >
                ✕
              </button>
            </div>
            <iframe
              src={getPdfViewerUrl(selectedPdfData.uri, selectedPdfData.pageNumber)}
              style={{
                flex: 1,
                border: 'none',
                width: '100%'
              }}
              title={selectedPdfData.name}
            />
          </div>
        )}

        <CardHeader>
          <LeftSlot>
            <Stack>
              <CardTitle content="Preliminary Research Report" />
            </Stack>
          </LeftSlot>
          {generationState === 'generated' && (
            <RightSlot>
              <>
                <Stack direction="row" align="center" justifyContent="end" gap="xs">
                  {approveState === 'sent' ? (
                    <OutlineButton disabled>
                      {`Redirecting to ${PRELIMINARY_RESEARCH_MESSAGES.GENERATE_DISCOVERY_WALKTHROUGH}...`}
                    </OutlineButton>
                  ) : (
                    <OutlineButton
                      onClick={handleApproveClick}
                      loading={approveState === 'loading'}
                      disabled={approveState === 'loading' || !canAcceptPreliminaryResearch}
                    >
                      {PRELIMINARY_RESEARCH_MESSAGES.APPROVE_RESULT}
                    </OutlineButton>
                  )}
                  <OutlineButton
                    onClick={handleDownloadClick}
                    loading={downloadState === 'loading'}
                    disabled={downloadState === 'loading' || !canDownloadPreliminaryResearchDocument}
                  >
                    {PRELIMINARY_RESEARCH_MESSAGES.DOWNLOAD_RESULT}
                  </OutlineButton>
                </Stack>
              </>
            </RightSlot>
          )}
        </CardHeader>

        {generationState === 'generating' && (
          <CardContent>
            <EmptyScopingState
            // title="Ask AI about Preliminary Research"
            // subtitle={
            //   <FadingTextCycler
            //     texts={PRELIMINARY_RESEARCH_MESSAGES.LOADING_TEXTS}
            //   />
            // }
            />
          </CardContent>
        )}

        {isGetApiLoading && generationState !== 'generating' && generationState !== 'generated' && (
          <CardContent>
            <EmptyScopingState subtitle={'loading...........'} />
          </CardContent>
        )}

        {generationState === 'empty' && !isGetApiLoading && (
          <CardContent>
            <EmptyScopingState
            // title="Ask AI about Preliminary Research"
            // subtitle="Generate the preliminary research to get started."
            // actionText="Generate Preliminary Research"
            // onActionClick={() => {
            //   window.dispatchEvent(new CustomEvent('ai-chat:trigger-generate-preliminary-research'));
            // }}
            />
          </CardContent>
        )}

        {generationState === 'generated' && (
          <>
            <Separator placement="horizontal" className={style.topSeparator} />

            <div className={style.navLayout}>              <div className={style.sectionTabs}>
              <NavTab
                direction="row"
                value={activeTab}
                onChange={(newVal) => {
                  setActiveTab(newVal as string);
                  setEditingSectionId(null);
                }}
              >
                {Object.keys(reportData).map((tabKey) => (
                  <Tab key={tabKey} value={tabKey}>
                    {tabKey}
                  </Tab>
                ))}
              </NavTab>
            </div>

              <div className={style.navMainContent}>
                <CardContent>
                  {/* <Text fontWeight="bold" className={style.titleText}>Preliminary Research Report</Text> */}
                  {/* <Text className={style.planNumberText}>Plan Number: {planId || 'N/A'}</Text> */}
                  <Text fontWeight="bold" className={style.sectionTitleText}>{reportData[activeTab]?.title}</Text>
                </CardContent>
                <div className={style.contentSectionContainer}>
                  {(() => {
                    const isPastReviewTab = activeTab?.toLowerCase().includes('past review analysis');
                    const isPolicyKodRegulatoryTab = /policy.*kod.*regulatory\s+analysis/i.test(String(activeTab || ''));
                    const isBroadScopeDirectionTab = activeTab?.toLowerCase().includes('broad scope direction');
                    const sourceSections = reportData[activeTab]?.sections || [];
                    const visibleSections = (isPolicyKodRegulatoryTab || isBroadScopeDirectionTab)
                      ? sourceSections.filter((section) => String(section?.content || '').trim().length > 0 || Boolean(section?.isNoData))
                      : sourceSections;

                    return visibleSections.map((section, index) => {
                      const isEditingAllSections = editingSectionId === ALL_SECTIONS_EDIT_ID && (isPolicyKodRegulatoryTab || isBroadScopeDirectionTab);
                      const isEditingThis = editingSectionId === section.id || isEditingAllSections;
                      const isNoDataSection = Boolean(section.isNoData);
                      const isPastReviewSection = isPastReviewTab || Boolean(section.pastReviewAnalysis);
                      const hideSectionMeta = isPastReviewSection || isPolicyKodRegulatoryTab || isBroadScopeDirectionTab || isNoDataSection;
                      const hideSectionActions = true;
                      return (
                        <React.Fragment key={section.id}>
                          {!hideSectionMeta && (
                            <div className={style.sideContentRight}>
                              <div className={style.aiRationaleContainer}>
                                <Text variant="secondary" className={style.confidenceText}>
                                  Confidence Score : <span className={`${style.confidenceValue} ${getConfidenceColorClass(section.confidenceScore)}`}>{getConfidenceLabel(section.confidenceScore)}</span>
                                </Text>
                                <Separator placement="vertical" /> |
                                <Popover>
                                  <PopoverTrigger>
                                    <Button variant="link" icon={<AiRationalIcon />}>{PRELIMINARY_RESEARCH_MESSAGES.VIEW_AI_RATIONAL}</Button>
                                  </PopoverTrigger>
                                  <PopoverSurface placement="bottom-end" title={PRELIMINARY_RESEARCH_MESSAGES.VIEW_AI_RATIONAL} closable>
                                    <Text className={style.aiRationaleText}>{section.rationale}</Text>
                                  </PopoverSurface>
                                </Popover>
                              </div>
                            </div>
                          )}
                          <Separator placement="horizontal" />
                          <CardContent>
                            {isEditingThis ? (
                              <div className={style.editorFadeIn}>
                                {isPastReviewSection && section.pastReviewAnalysis ? (
                                  <PastReviewAnalysisEditSection
                                    title={reportData[activeTab]?.title}
                                    data={section.pastReviewAnalysis}
                                    planId={planId}
                                    onCitationClick={handleChunkClick}
                                    onChange={setEditContent}
                                  />
                                ) : isPolicyKodRegulatoryTab ? (
                                  <PolicyKodRegulatoryAnalysisEditSection
                                    content={sectionEditContentById[section.id] ?? section.content}
                                    title={index === 0 ? reportData[activeTab]?.title : undefined}
                                    onChange={(value) => {
                                      setSectionEditContentById((prev) => ({
                                        ...prev,
                                        [section.id]: value,
                                      }));
                                    }}
                                  />
                                ) : isBroadScopeDirectionTab ? (
                                  <BroadScopeDirectionEditSection
                                    content={sectionEditContentById[section.id] ?? section.content}
                                    title={index === 0 ? reportData[activeTab]?.title : undefined}
                                    onChange={(value) => {
                                      setSectionEditContentById((prev) => ({
                                        ...prev,
                                        [section.id]: value,
                                      }));
                                    }}
                                  />
                                ) : (
                                  <Stack direction="column" gap="md">
                                    <div
                                      className={style.editorContainer}
                                      style={{ ['--editorMinHeight' as any]: `${editBoxHeight}px` }}
                                    >
                                      <RichTextEditor
                                        value={editContent} options={SECTION_EDITOR_OPTIONS}
                                        onValueChange={setEditContent}
                                      />
                                    </div>
                                  </Stack>
                                )}
                              </div>
                            ) : (
                              <div className={style.contentLayout}>
                                <LeftSlot>
                                  {isNoDataSection ? (
                                    <div className={style.noDataContainer}>
                                      <Text variant="secondary">No data found</Text>
                                    </div>
                                  ) : (
                                    <div className={style.htmlContent}>
                                      {section.pastReviewAnalysis ? (
                                        <PastReviewAnalysisSection
                                          title={reportData[activeTab]?.title}
                                          data={section.pastReviewAnalysis}
                                          planId={planId}
                                          onCitationClick={handleChunkClick}
                                          supportingCitations={section.supportingCitations}
                                        />
                                      ) : isPolicyKodRegulatoryTab ? (
                                        <PolicyKodRegulatoryAnalysisSection
                                          content={section.content}
                                          title={index === 0 ? reportData[activeTab]?.title : undefined}
                                          planId={planId}
                                          onCitationClick={handleChunkClick}
                                          supportingCitations={section.supportingCitations}
                                        />
                                      ) : isBroadScopeDirectionTab ? (
                                        <BroadScopeDirectionSection
                                          content={section.content}
                                          title={index === 0 ? reportData[activeTab]?.title : undefined}
                                          planId={planId}
                                          onCitationClick={handleChunkClick}
                                          supportingCitations={section.supportingCitations}
                                        />
                                      ) : (
                                        <span dangerouslySetInnerHTML={{ __html: formatMarkdownToHtml(section.content) }} />
                                      )}
                                      {(!section.pastReviewAnalysis && !isPolicyKodRegulatoryTab && !isBroadScopeDirectionTab && section.supportingChunkIds && section.supportingChunkIds.length > 0) && (
                                        <span className={style.supportingChunks}>
                                          {' '}
                                          [
                                          {section.supportingChunkIds.map((id, idx) => (
                                            (() => {
                                              const citationMeta = (section.supportingCitations || []).find((citation) => String(citation?.chunkId || '').trim() === String(id || '').trim());
                                              const citationTarget = buildCitationReferenceValue(citationMeta, id) || String(id);
                                              const citationPreview = buildCitationRedirectPreview(citationTarget, planId, citationMeta);

                                              return (
                                                <React.Fragment key={id}>
                                                  <a
                                                    href={`/dbaware-ui/${planId}/docs/${id}`}
                                                    onClick={(e) => {
                                                      handleChunkClick(citationTarget, e);
                                                    }}
                                                    title={citationPreview}
                                                    className={style.chunkLink}
                                                  >
                                                    {id}
                                                  </a>
                                                  {idx < section.supportingChunkIds.length - 1 && ', '}
                                                </React.Fragment>
                                              );
                                            })()
                                          ))}
                                          ]
                                        </span>
                                      )}
                                    </div>
                                  )}
                                </LeftSlot>
                              </div>
                            )}
                          </CardContent>

                          {!isEditingThis && !hideSectionActions && (
                            <CardFooter className={style.sectionFooter}>
                              <Stack direction="row" gap="xs" className={style.leftActions}>
                                {!isPastReviewSection && (
                                  <Button
                                    icon={<EditBoxSolid />}
                                    variant="link"
                                    onClick={() => handleEditClick(section)}
                                  // disabled={!canEditPreliminaryResearchDocument}
                                  >
                                    Edit
                                  </Button>
                                )}
                                {!isPolicyKodRegulatoryTab && !isBroadScopeDirectionTab && (
                                  <Button
                                    icon={<CloneSolid />}
                                    variant="link"
                                    onClick={() => handleCopyClick(section.pastReviewAnalysis
                                      ? buildPastReviewAnalysisEditorText(section.pastReviewAnalysis, reportData[activeTab]?.title)
                                      : section.content)}
                                  >
                                    Copy
                                  </Button>
                                )}
                              </Stack>
                            </CardFooter>
                          )}
                         
                          {index < visibleSections.length - 1 && <Separator placement="horizontal" className={style.topSeparator} />}
                        </React.Fragment>
                      );
                    });
                  })()}
                </div>
                {(() => {
                  const isPolicyOrBroadTab = Boolean(
                    /policy.*kod.*regulatory\s+analysis/i.test(String(activeTab || ''))
                    || activeTab?.toLowerCase().includes('broad scope direction')
                  );
                  const sourceSections = reportData[activeTab]?.sections || [];
                  const activeSections = isPolicyOrBroadTab
                    ? sourceSections.filter((section) => String(section?.content || '').trim().length > 0 || Boolean(section?.isNoData))
                    : sourceSections;
                  const firstSection = activeSections[0];
                  const hasTabDataForActions = activeSections.some((section) => (
                    !section?.isNoData && (
                      Boolean(section?.pastReviewAnalysis)
                      || String(section?.content || '').trim().length > 0
                    )
                  ));
                  const canShowBottomFooter = Boolean(firstSection) && hasTabDataForActions;

                  if (!canShowBottomFooter) return null;

                  if (editingSectionId) {
                    return (
                      <CardFooter className={style.sectionFooter}>
                        <Stack direction="row" gap="xs" className={style.leftActions}>
                          <Button onClick={handleCancelClick} disabled={saveState === 'loading'}>Cancel</Button>
                          <Button
                            variant="primary"
                            onClick={() => handleSaveClick(isPolicyOrBroadTab ? (firstSection?.id || editingSectionId) : editingSectionId)}
                            loading={saveState === 'loading'}
                            disabled={saveState === 'loading'}
                          >
                            {saveState === 'loading' ? 'Saving...' : 'Save'}
                          </Button>
                        </Stack>
                      </CardFooter>
                    );
                  }

                  return (
                    <CardFooter className={style.sectionFooter}>
                      <Stack direction="row" gap="xs" className={style.leftActions}>
                        <Button
                          icon={<EditBoxSolid />}
                          variant="link"
                          onClick={() => handleEditClick(firstSection)}
                          disabled={!canEditPreliminaryResearchDocument}

                        >
                          Edit
                        </Button>
                        <Button
                          icon={<CloneSolid />}
                          variant="link"
                          onClick={() => {
                            if (isPolicyOrBroadTab) {
                              const allSectionText = activeSections
                                .map((section) => String(section?.content || '').trim())
                                .filter(Boolean)
                                .join('\n\n');
                              handleCopyClick(allSectionText);
                              return;
                            }

                            handleCopyClick(firstSection.pastReviewAnalysis
                              ? buildPastReviewAnalysisEditorText(firstSection.pastReviewAnalysis, reportData[activeTab]?.title)
                              : firstSection.content);
                          }}
                        >
                          Copy
                        </Button>
                      </Stack>
                    </CardFooter>
                  );
                })()}
              </div>
            </div>
          </>
        )}
      </Card>
    </div>
  );
};

export default PreliminaryResearchPage;