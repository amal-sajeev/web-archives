export interface PreliminaryResearchPageProps {}

export interface PastReviewSentence {
  text: string;
  citations: string[];
}

export interface PastReviewGroupedItems {
  reviewId: string;
  reviewTitle: string;
  items: PastReviewSentence[];
}

export interface PastReviewTableRow {
  historicalReviewId: string;
  assessedArea: string;
  keyObservations: string;
  relevanceToCurrentReview: string;
  keyObservationCitations: string[];
  relevanceCitations: string[];
}

export interface PastReviewAnalysisData {
  title: string;
  description: string;
  summaryCount: number;
  keyObservations: PastReviewGroupedItems[];
  implications: PastReviewGroupedItems[];
  tableRows: PastReviewTableRow[];
}

export interface PastReviewEditMeta {
  rawTabData: any;
  keyObservationAssessmentIndexByReviewId: Record<string, number>;
  implicationAssessmentIndexByReviewId: Record<string, number>;
  tableRowMappings?: Array<{
    reviewId: string;
    assessmentIndex: number;
  }>;
}

export interface SupportingCitation {
  chunkId: string;
  label?: string;
  pageNumber?: number;
  gsUri?: string;
  documentName?: string;
  contentType?: string;
  url?: string;
}

export interface SectionData {
  id: string;
  content: string;
  rationale: string;
  confidenceScore: number;
  supportingChunkIds: string[];
  supportingCitations?: SupportingCitation[];
  pastReviewAnalysis?: PastReviewAnalysisData;
  pastReviewEditMeta?: PastReviewEditMeta;
  structuredTabEditMeta?: {
    rawTabData: any;
    paragraphIndices?: number[];
    reviewIndex?: number;
    assessmentIndex?: number;
  };
  isNoData?: boolean;
}
