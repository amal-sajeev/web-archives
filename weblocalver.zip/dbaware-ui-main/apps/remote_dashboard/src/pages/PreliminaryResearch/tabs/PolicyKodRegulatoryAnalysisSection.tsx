import React from 'react';
import { formatMarkdownToHtml } from '../../../utils';
import { SupportingCitation } from '../types';
import style from './PolicyKodRegulatoryAnalysisSection.module.css';

interface PolicyKodRegulatoryAnalysisSectionProps {
  content: string;
  title?: string;
  planId?: string;
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void;
  supportingCitations?: SupportingCitation[];
}

interface CitationEntry {
  label: string;
  target: string;
}

const CITATION_REF_PREFIX = 'citation:';

interface CitationResolverContext {
  categoryKey?: string;
  itemNo?: string;
  citationLookup?: Map<string, string>;
  citationLabelLookup?: Map<string, string[]>;
  chunkLabelLookup?: Map<string, string>;
  citationMetaLookup?: Map<string, SupportingCitation>;
}

const DOC_HEADING_REGEX = /^(\d+)\.\s\*\*(.+?)\*\*\s*-\s*([^\n]+)(?:\n+Relevance Score:\s*([\d.]+))?/i;
const SUMMARY_HEADING_REGEX = /^Section\s+\d+\s*:\s*/i;
const TAB_TITLE_REGEX = /^policy\s*,\s*kod\s+and\s+regulatory\s+analysis\s*$/i;

const parseCitationBlock = (raw: string): string[] => {
  return raw
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
};

const normalizeCitationId = (value: string): string => value.trim();

const normalizeCitationLabelForDisplay = (label: string): string => {
  const trimmed = String(label || '').trim();
  if (!trimmed) return trimmed;
  return trimmed.toLowerCase() === 'link' ? 'Open source' : trimmed;
};

const normalizeInlineDisplayText = (value: string): string => {
  if (!value) return '';
  return value
    .replace(/\r?\n\s*(Version:\s*\d+(?:\.\d+)*)/gi, ' $1')
    .replace(/\r?\n\s*(\[Open source\]|\[Link\])/gi, ' $1');
};

const buildCitationTarget = (citation?: SupportingCitation, fallbackChunkId?: string): string => {
  const chunkId = String(citation?.chunkId || fallbackChunkId || '').trim();
  if (!chunkId) return '';

  const payload = {
    chunkId,
    gsUri: citation?.gsUri,
    pageNumber: citation?.pageNumber,
    documentName: citation?.documentName,
    contentType: citation?.contentType,
    url: citation?.url,
  };

  const hasExtended = Boolean(payload.gsUri || payload.pageNumber || payload.documentName || payload.contentType || payload.url);
  if (!hasExtended) return chunkId;

  return `${CITATION_REF_PREFIX}${encodeURIComponent(JSON.stringify(payload))}`;
};

const parseCitationReference = (value: string): {
  chunkId?: string;
  gsUri?: string;
  pageNumber?: number;
  documentName?: string;
  contentType?: string;
  url?: string;
} | null => {
  if (!value || !value.startsWith(CITATION_REF_PREFIX)) return null;

  try {
    const encodedPayload = value.slice(CITATION_REF_PREFIX.length);
    if (!encodedPayload) return null;
    const decoded = decodeURIComponent(encodedPayload);
    const parsed = JSON.parse(decoded);
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed as {
      chunkId?: string;
      gsUri?: string;
      pageNumber?: number;
      documentName?: string;
      contentType?: string;
      url?: string;
    };
  } catch {
    return null;
  }
};

const buildCitationRedirectPreview = (target: string, planId?: string): string => {
  const normalizedTarget = normalizeCitationId(target);
  if (!normalizedTarget) return '';

  const citationRef = parseCitationReference(normalizedTarget);
  if (citationRef) {
    const sourceUrl = String(citationRef.url || '').trim();
    if (sourceUrl) return sourceUrl;

    const rawGsUri = String(citationRef.gsUri || '').trim();
    const gsUri = rawGsUri
      ? (/^gs:\/\//i.test(rawGsUri) ? rawGsUri : `gs://${rawGsUri.replace(/^\/+/, '')}`)
      : '';
    const pageNumber = Number(citationRef.pageNumber);
    const citationContentType = String(citationRef.contentType || '').trim().toLowerCase();
    const citationDocumentName = String(citationRef.documentName || '').trim().toLowerCase();
    const isJsonCitation = citationContentType.includes('application/json') || citationDocumentName.endsWith('.json');

    if (planId && gsUri && !isJsonCitation) {
      const encodedUri = encodeURIComponent(gsUri);
      const pageParam = Number.isFinite(pageNumber) && pageNumber > 0 ? `&pageNumber=${pageNumber}` : '';
      return `/dbaware-ui/${planId}/docs/uri?document_uri=${encodedUri}${pageParam}`;
    }

    const chunkId = String(citationRef.chunkId || '').trim();
    if (planId && chunkId) {
      return `/dbaware-ui/${planId}/docs/${chunkId}`;
    }

    return chunkId || normalizedTarget;
  }

  if (planId) return `/dbaware-ui/${planId}/docs/${normalizedTarget}`;
  return normalizedTarget;
};

const isChunkIdLike = (value: string): boolean => /^[A-Za-z0-9|_.-]+$/.test(value.trim());

const normalizeCategoryKey = (value?: string): string | undefined => {
  if (!value) return undefined;
  const normalized = value.trim().toLowerCase();
  if (normalized.includes('regulatory mandates')) return 'REG';
  if (normalized.includes('policy')) return 'POLICY';
  if (normalized.includes('procedure')) return 'PROCEDURE';
  if (normalized.includes('kod')) return 'KOD';
  return undefined;
};

const resolveCitationEntry = (value: string, context?: CitationResolverContext): CitationEntry | null => {
  const label = value.trim();
  if (!label) return null;

  if (label.startsWith(CITATION_REF_PREFIX)) {
    const parsed = parseCitationReference(label);
    if (!parsed) return null;

    const normalizedChunkId = String(parsed.chunkId || '').trim();
    if (!normalizedChunkId) return null;

    const normalizedPage = Number(parsed.pageNumber);
    const citationMeta = (context?.citationMetaLookup?.get(normalizedChunkId.toLowerCase())
      && (!Number.isFinite(normalizedPage) || normalizedPage <= 0 || Number(context?.citationMetaLookup?.get(normalizedChunkId.toLowerCase())?.pageNumber) === normalizedPage))
      ? context?.citationMetaLookup?.get(normalizedChunkId.toLowerCase())
      : undefined;

    const preferredLabel = String(
      citationMeta?.label
      || context?.chunkLabelLookup?.get(normalizedChunkId.toLowerCase())
      || parsed.documentName
      || normalizedChunkId
    ).trim();

    return {
      label: normalizeCitationLabelForDisplay(preferredLabel),
      target: label,
    };
  }

  const normalized = label.toLowerCase();
  const strippedSection = label.replace(/^Section\s+/i, '').trim();
  const normalizedStrippedSection = strippedSection.toLowerCase();

  const rawSection = strippedSection;
  const isSectionToken = /^\d+(?:[._]\d+)*(?:__\d+)?$/i.test(rawSection);

  const isKnownChunkId = (candidate: string): boolean => {
    const normalized = String(candidate || '').trim().toLowerCase();
    if (!normalized) return false;
    return Boolean(
      context?.citationMetaLookup?.has(normalized)
      || context?.citationLookup?.has(normalized)
    );
  };

  const selectByContext = (candidates: string[]): string | undefined => {
    if (!Array.isArray(candidates) || candidates.length === 0) return undefined;

    const normalizedCandidates = candidates
      .map((candidate) => String(candidate || '').trim())
      .filter(Boolean);

    if (normalizedCandidates.length === 0) return undefined;

    if (context?.categoryKey && context?.itemNo) {
      const exactPrefix = `${context.categoryKey}|${context.itemNo}|`;
      const exactMatch = normalizedCandidates.find((candidate) => candidate.toUpperCase().startsWith(exactPrefix.toUpperCase()));
      if (exactMatch) return exactMatch;
    }

    if (context?.categoryKey) {
      const categoryPrefix = `${context.categoryKey}|`;
      const categoryMatch = normalizedCandidates.find((candidate) => candidate.toUpperCase().startsWith(categoryPrefix.toUpperCase()));
      if (categoryMatch) return categoryMatch;
    }

    return normalizedCandidates[0];
  };

  // Prefer context-aware chunk IDs first for tokens like "Section 1" to avoid
  // collisions across categories (POLICY/KOD/PROCEDURE) that share labels.
  if (isSectionToken && context?.categoryKey && context?.itemNo) {
    const normalizedSection = rawSection.replace(/_/g, '.');
    const contextualChunkId = `${context.categoryKey}|${context.itemNo}|${normalizedSection}`;
    const citationMeta = context?.citationMetaLookup?.get(contextualChunkId.toLowerCase());

    if (citationMeta || isKnownChunkId(contextualChunkId)) {
      return {
        label: normalizeCitationLabelForDisplay(label),
        target: buildCitationTarget(citationMeta, contextualChunkId),
      };
    }
  }

  const labelCandidates = [
    ...(context?.citationLabelLookup?.get(normalized) || []),
    ...(context?.citationLabelLookup?.get(normalizedStrippedSection) || []),
    ...(context?.citationLabelLookup?.get(`section ${normalizedStrippedSection}`) || []),
  ];

  const contextResolvedFromLabels = selectByContext(Array.from(new Set(labelCandidates)));
  if (contextResolvedFromLabels) {
    const citationMeta = context?.citationMetaLookup?.get(contextResolvedFromLabels.toLowerCase());
    const prettyLabel = context?.chunkLabelLookup?.get(contextResolvedFromLabels.toLowerCase()) || label;
    return {
      label: normalizeCitationLabelForDisplay(prettyLabel),
      target: buildCitationTarget(citationMeta, contextResolvedFromLabels),
    };
  }

  const directLookup = context?.citationLookup?.get(normalized)
    || context?.citationLookup?.get(normalizedStrippedSection)
    || context?.citationLookup?.get(`section ${normalizedStrippedSection}`);

  if (directLookup) {
    const prettyLabel = context?.chunkLabelLookup?.get(directLookup.toLowerCase()) || label;
    const citationMeta = context?.citationMetaLookup?.get(directLookup.toLowerCase());
    return { label: normalizeCitationLabelForDisplay(prettyLabel), target: buildCitationTarget(citationMeta, directLookup) };
  }

  if (isChunkIdLike(label) && label.includes('|')) {
    const prettyLabel = context?.chunkLabelLookup?.get(label.toLowerCase()) || label;
    const citationMeta = context?.citationMetaLookup?.get(label.toLowerCase());
    return { label: normalizeCitationLabelForDisplay(prettyLabel), target: buildCitationTarget(citationMeta, label) };
  }

  if (/^\d+$/.test(label)) {
    const citationMeta = context?.citationMetaLookup?.get(label.toLowerCase());
    return { label: normalizeCitationLabelForDisplay(label), target: buildCitationTarget(citationMeta, label) };
  }

  if (isSectionToken && context?.categoryKey && context?.itemNo) {
    const normalizedSection = rawSection.replace(/_/g, '.');
    const fallbackChunkId = `${context.categoryKey}|${context.itemNo}|${normalizedSection}`;
    const citationMeta = context?.citationMetaLookup?.get(fallbackChunkId.toLowerCase());
    if (!citationMeta && !isKnownChunkId(fallbackChunkId)) {
      return null;
    }
    return {
      label: normalizeCitationLabelForDisplay(label),
      target: buildCitationTarget(citationMeta, fallbackChunkId),
    };
  }

  return null;
};

const toInlineMarkdownHtml = (value: string): string => {
  const html = formatMarkdownToHtml(value);
  return html
    .replace(/^<p>/i, '')
    .replace(/<\/p>\s*$/i, '');
};

const isTopSectionHeading = (block: string): boolean => {
  const normalized = block.trim();
  return /^\*\*(regulatory mandates|policy|procedure|kod)\*\*$/i.test(normalized);
};

const isDocumentHeadingBlock = (block: string): boolean => DOC_HEADING_REGEX.test(block.trim());

const isSubSectionBlock = (block: string): boolean => {
  const normalized = block.trim();
  return /^(<u>)?Section\s+/i.test(normalized) || /^\*\*Section\s+/i.test(normalized);
};

const renderCitationList = (
  citations: CitationEntry[],
  keyPrefix: string,
  planId?: string,
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void
): React.ReactNode => {
  if (citations.length === 0) return null;

  return (
    <span className={style.citationsInline}>
      {'['}
      {citations.map((citation, idx) => {
        const normalizedTarget = normalizeCitationId(citation.target);
        return (
          <React.Fragment key={`${keyPrefix}-citation-${normalizedTarget}-${idx}`}>
            <a
              href="#"
              className={style.citationLink}
              title={buildCitationRedirectPreview(normalizedTarget, planId)}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (onCitationClick) {
                  onCitationClick(normalizedTarget, e);
                }
              }}
            >
              {citation.label}
            </a>
            {idx < citations.length - 1 ? ', ' : ''}
          </React.Fragment>
        );
      })}
      {']'}
    </span>
  );
};

const renderTextWithCitations = (
  text: string,
  keyPrefix: string,
  planId?: string,
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void,
  context?: CitationResolverContext
): React.ReactNode => {
  const normalizedText = normalizeInlineDisplayText(text);
  const parts: React.ReactNode[] = [];
  const citationRegex = /\[([^\[\]]+)\]/g;
  let cursor = 0;
  let match: RegExpExecArray | null;

  while ((match = citationRegex.exec(normalizedText)) !== null) {
    const fullMatch = match[0];
    const inner = match[1];
    const start = match.index;

    if (start > cursor) {
      const segment = normalizedText.slice(cursor, start);
      if (segment) {
        parts.push(
          <span
            key={`${keyPrefix}-txt-${cursor}`}
            dangerouslySetInnerHTML={{ __html: toInlineMarkdownHtml(segment) }}
          />
        );
      }
    }

    const candidateIds = parseCitationBlock(inner);
    const resolvedEntries = candidateIds
      .map((token) => resolveCitationEntry(token, context))
      .filter(Boolean) as CitationEntry[];
    const isCitationBlock = candidateIds.length > 0 && resolvedEntries.length === candidateIds.length;

    if (isCitationBlock) {
      parts.push(
        <React.Fragment key={`${keyPrefix}-cite-${start}`}>
          {renderCitationList(resolvedEntries, `${keyPrefix}-cite-${start}`, planId, onCitationClick)}
        </React.Fragment>
      );
    } else {
      parts.push(
        <span
          key={`${keyPrefix}-raw-${start}`}
          dangerouslySetInnerHTML={{ __html: toInlineMarkdownHtml(fullMatch) }}
        />
      );
    }

    cursor = start + fullMatch.length;
  }

  if (cursor < normalizedText.length) {
    const segment = normalizedText.slice(cursor);
    parts.push(
      <span
        key={`${keyPrefix}-tail`}
        dangerouslySetInnerHTML={{ __html: toInlineMarkdownHtml(segment) }}
      />
    );
  }

  return <>{parts}</>;
};

const PolicyKodRegulatoryAnalysisSection: React.FC<PolicyKodRegulatoryAnalysisSectionProps> = ({
  content,
  title,
  planId,
  onCitationClick,
  supportingCitations = [],
}) => {
  const citationLookup = React.useMemo(() => {
    const map = new Map<string, string>();

    supportingCitations.forEach((citation) => {
      const chunkId = String(citation?.chunkId || '').trim();
      if (!chunkId) return;

      map.set(chunkId.toLowerCase(), chunkId);

      const rawLabel = String(citation?.label || '').trim();
      if (!rawLabel) return;

      const lowerLabel = rawLabel.toLowerCase();
      map.set(lowerLabel, chunkId);

      const strippedLabel = rawLabel.replace(/^Section\s+/i, '').trim().toLowerCase();
      if (strippedLabel) {
        map.set(strippedLabel, chunkId);
        map.set(`section ${strippedLabel}`, chunkId);
      }
    });

    return map;
  }, [supportingCitations]);

  const chunkLabelLookup = React.useMemo(() => {
    const map = new Map<string, string>();

    supportingCitations.forEach((citation) => {
      const chunkId = String(citation?.chunkId || '').trim();
      const label = String(citation?.label || '').trim();
      if (!chunkId || !label) return;
      map.set(chunkId.toLowerCase(), label);
    });

    return map;
  }, [supportingCitations]);

  const citationLabelLookup = React.useMemo(() => {
    const map = new Map<string, string[]>();

    const add = (key: string, chunkId: string) => {
      const normalizedKey = String(key || '').trim().toLowerCase();
      if (!normalizedKey) return;

      const list = map.get(normalizedKey) || [];
      if (!list.includes(chunkId)) {
        list.push(chunkId);
      }
      map.set(normalizedKey, list);
    };

    supportingCitations.forEach((citation) => {
      const chunkId = String(citation?.chunkId || '').trim();
      if (!chunkId) return;

      const rawLabel = String(citation?.label || '').trim();
      if (!rawLabel) return;

      add(rawLabel, chunkId);

      const strippedLabel = rawLabel.replace(/^Section\s+/i, '').trim();
      if (strippedLabel) {
        add(strippedLabel, chunkId);
        add(`section ${strippedLabel}`, chunkId);
      }
    });

    return map;
  }, [supportingCitations]);

  const citationMetaLookup = React.useMemo(() => {
    const map = new Map<string, SupportingCitation>();

    supportingCitations.forEach((citation) => {
      const chunkId = String(citation?.chunkId || '').trim();
      if (!chunkId) return;
      map.set(chunkId.toLowerCase(), citation);
    });

    return map;
  }, [supportingCitations]);

  const blocks = content
    .split(/\n{2,}/)
    .map((item) => item.trim())
    .filter(Boolean);

  const renderDocumentBlock = (block: string, index: number, categoryKey?: string): React.ReactNode => {
    const match = block.match(DOC_HEADING_REGEX);
    if (!match) {
      return <p className={style.paragraph} key={`generic-${index}`}>{renderTextWithCitations(block, `generic-${index}`, planId, onCitationClick, { citationLookup, citationLabelLookup, chunkLabelLookup, citationMetaLookup })}</p>;
    }

    const [, itemNo, docTitle, applicability, score] = match;
    const consumed = match[0] || '';
    const remainder = block.slice(consumed.length).trim();

    return (
      <div className={style.documentBlock} key={`doc-${index}`}>
        <p className={style.documentTitleLine}>
          <strong>{itemNo}. {docTitle}</strong> - {applicability}
        </p>
        {score && <p className={style.relevanceLine}>Relevance Score: {score}</p>}
        {remainder && (
          <p className={style.paragraph}>{renderTextWithCitations(remainder, `doc-${index}`, planId, onCitationClick, { categoryKey, itemNo, citationLookup, citationLabelLookup, chunkLabelLookup, citationMetaLookup })}</p>
        )}
      </div>
    );
  };

  const elements: React.ReactNode[] = [];
  let activeCategoryHeading: string | undefined;

  blocks.forEach((block, index) => {
    const summaryParts = block
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean)
      .filter((line, lineIndex, allLines) => {
        if (!TAB_TITLE_REGEX.test(line)) return true;
        // Keep only a single top heading in page header; drop repeated inline tab titles.
        // If a block contains only that title line, remove the block entirely.
        return false;
      });

    if (summaryParts.length === 0) return;

    const firstLine = summaryParts[0] || '';
    const normalizedFirstLine = firstLine.replace(/^\*\*(.*)\*\*$/i, '$1').trim();

    if (SUMMARY_HEADING_REGEX.test(normalizedFirstLine)) {
      elements.push(
        <div key={`summary-${index}`}>
          <h4 className={style.summaryHeading}>{normalizedFirstLine}</h4>
          {summaryParts.length > 1 && (
            <p className={style.paragraph}>
              {renderTextWithCitations(summaryParts.slice(1).join('\n'), `summary-${index}`, planId, onCitationClick, { citationLookup, citationLabelLookup, chunkLabelLookup, citationMetaLookup })}
            </p>
          )}
        </div>
      );
      return;
    }

    if (isTopSectionHeading(block)) {
      activeCategoryHeading = block.replace(/\*\*/g, '').trim();
      elements.push(
        <h4 className={style.categoryHeading} key={`cat-${index}`}>
          {activeCategoryHeading}
        </h4>
      );
      return;
    }

    if (isDocumentHeadingBlock(block)) {
      elements.push(renderDocumentBlock(block, index, normalizeCategoryKey(activeCategoryHeading)));
      return;
    }

    if (isSubSectionBlock(block)) {
      elements.push(
        <p className={style.paragraph} key={`sub-${index}`}>
          {renderTextWithCitations(block, `sub-${index}`, planId, onCitationClick, { categoryKey: normalizeCategoryKey(activeCategoryHeading), citationLookup, citationLabelLookup, chunkLabelLookup, citationMetaLookup })}
        </p>
      );
      return;
    }

    elements.push(
      <p className={style.paragraph} key={`generic-${index}`}>
        {renderTextWithCitations(block, `generic-${index}`, planId, onCitationClick, { categoryKey: normalizeCategoryKey(activeCategoryHeading), citationLookup, citationLabelLookup, chunkLabelLookup, citationMetaLookup })}
      </p>
    );
  });

  return (
    <div className={style.wrapper}>
      {title && <h4 className={style.mainTitle}>{title}</h4>}
      {elements}
    </div>
  );
};

export default PolicyKodRegulatoryAnalysisSection;
