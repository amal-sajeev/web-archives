import React, { useMemo } from 'react';
import { Text } from '@wadk/ui';
import { PastReviewAnalysisData, PastReviewGroupedItems, PastReviewSentence, SupportingCitation } from '../types';
import style from './PastReviewAnalysisSection.module.css';

interface PastReviewAnalysisSectionProps {
  data: PastReviewAnalysisData;
  planId?: string;
  title:string;
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void;
  supportingCitations?: SupportingCitation[];
}

const CITATION_REF_PREFIX = 'citation:';

interface CitationReferencePayload {
  chunkId?: string;
  gsUri?: string;
  pageNumber?: number;
  documentName?: string;
  contentType?: string;
  url?: string;
}

const parseCitationReference = (value: string): CitationReferencePayload | null => {
  if (!value || !value.startsWith(CITATION_REF_PREFIX)) return null;

  try {
    const encodedPayload = value.slice(CITATION_REF_PREFIX.length);
    if (!encodedPayload) return null;
    const decoded = decodeURIComponent(encodedPayload);
    const parsed = JSON.parse(decoded);
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed as CitationReferencePayload;
  } catch {
    return null;
  }
};

const buildCitationTarget = (citation?: SupportingCitation, fallbackChunkId?: string): string => {
  const chunkId = String(citation?.chunkId || fallbackChunkId || '').trim();
  if (!chunkId) return '';

  const payload = {
    chunkId,
    gsUri: citation?.gsUri,
    pageNumber: citation?.pageNumber,
    documentName: citation?.documentName,
    contentType: citation?.contentType,
    url: citation?.url,
  };

  const hasExtended = Boolean(payload.gsUri || payload.pageNumber || payload.documentName || payload.contentType || payload.url);
  if (!hasExtended) return chunkId;

  return `${CITATION_REF_PREFIX}${encodeURIComponent(JSON.stringify(payload))}`;
};

const parseCitationBlock = (raw: string): string[] => {
  return raw
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
};

const normalizeCitationId = (value: string): string => value.trim();

const buildCitationRedirectPreview = (
  target: string,
  planId?: string,
  citationMetaByChunkId?: Map<string, SupportingCitation>
): string => {
  const normalizedTarget = normalizeCitationId(target);
  if (!normalizedTarget) return '';

  const citationRef = parseCitationReference(normalizedTarget);
  if (citationRef) {
    const sourceUrl = String(citationRef.url || '').trim();
    if (sourceUrl) return sourceUrl;

    const rawGsUri = String(citationRef.gsUri || '').trim();
    const gsUri = rawGsUri
      ? (/^gs:\/\//i.test(rawGsUri) ? rawGsUri : `gs://${rawGsUri.replace(/^\/+/, '')}`)
      : '';
    const pageNumber = Number(citationRef.pageNumber);
    const citationContentType = String(citationRef.contentType || '').trim().toLowerCase();
    const citationDocumentName = String(citationRef.documentName || '').trim().toLowerCase();
    const isJsonCitation = citationContentType.includes('application/json') || citationDocumentName.endsWith('.json');

    if (planId && gsUri && !isJsonCitation) {
      const encodedUri = encodeURIComponent(gsUri);
      const pageParam = Number.isFinite(pageNumber) && pageNumber > 0 ? `&pageNumber=${pageNumber}` : '';
      return `/dbaware-ui/${planId}/docs/uri?document_uri=${encodedUri}${pageParam}`;
    }

    const chunkId = String(citationRef.chunkId || '').trim();
    if (planId && chunkId) {
      return `/dbaware-ui/${planId}/docs/${chunkId}`;
    }

    return chunkId || normalizedTarget;
  }

  const fallbackCitation = citationMetaByChunkId?.get(normalizedTarget.toLowerCase());
  const fallbackUrl = String(fallbackCitation?.url || '').trim();
  if (fallbackUrl) return fallbackUrl;

  if (planId) return `/dbaware-ui/${planId}/docs/${normalizedTarget}`;
  return normalizedTarget;
};

const renderCitationList = (
  citationIds: string[],
  keyPrefix: string,
  planId?: string,
  citationMetaByChunkId?: Map<string, SupportingCitation>,
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void
): React.ReactNode => {
  if (citationIds.length === 0) return null;

  return (
    <span className={style.citationsInline}>
      {' ['}
      {citationIds.map((citationId, idx) => {
        const normalizedId = normalizeCitationId(citationId);
        const citationRef = parseCitationReference(normalizedId);
        const citationChunkId = String(citationRef?.chunkId || '').trim();
        const citationMeta = citationRef
          ? undefined
          : citationMetaByChunkId?.get(normalizedId.toLowerCase());
        const citationTarget = citationRef
          ? normalizedId
          : (buildCitationTarget(citationMeta, normalizedId) || normalizedId);
        const citationDisplayText = citationChunkId || normalizedId;
        return (
          <React.Fragment key={`${keyPrefix}-citation-${normalizedId}-${idx}`}>
            <a
              href="#"
              className={style.citationLink}
              title={buildCitationRedirectPreview(citationTarget, planId, citationMetaByChunkId)}
              onClick={(e) => {
                e.preventDefault();
                if (onCitationClick) {
                  onCitationClick(citationTarget, e);
                }
              }}
            >
              {citationDisplayText}
            </a>
            {idx < citationIds.length - 1 ? ', ' : ''}
          </React.Fragment>
        );
      })}
      {']'}
    </span>
  );
};

const renderTextWithCitations = (
  text: string,
  citations: string[],
  keyPrefix: string,
  planId?: string,
  citationMetaByChunkId?: Map<string, SupportingCitation>,
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void,
  appendUnusedCitations: boolean = true
): React.ReactNode => {
  const citationSet = new Set(citations.map(normalizeCitationId));
  const usedCitations = new Set<string>();
  const parts: React.ReactNode[] = [];

  const citationRegex = /\[([^\[\]]+)\]/g;
  let cursor = 0;
  let match: RegExpExecArray | null;

  while ((match = citationRegex.exec(text)) !== null) {
    const fullMatch = match[0];
    const inner = match[1];
    const start = match.index;

    if (start > cursor) {
      parts.push(text.slice(cursor, start));
    }

    const blockIds = parseCitationBlock(inner);
    const isCitationBlock = blockIds.length > 0 && blockIds.every((id) => {
      const normalized = normalizeCitationId(id);
      return citationSet.has(normalized) || /^\d+$/.test(normalized);
    });

    if (isCitationBlock) {
      blockIds.forEach((id) => usedCitations.add(normalizeCitationId(id)));
      parts.push(
        <React.Fragment key={`${keyPrefix}-inline-${start}`}>
          {renderCitationList(blockIds, `${keyPrefix}-inline-${start}`, planId, citationMetaByChunkId, onCitationClick)}
        </React.Fragment>
      );
    } else {
      parts.push(fullMatch);
    }

    cursor = start + fullMatch.length;
  }

  if (cursor < text.length) {
    parts.push(text.slice(cursor));
  }

  const remainingCitations = citations.filter((id) => !usedCitations.has(normalizeCitationId(id)));
  if (appendUnusedCitations && remainingCitations.length > 0) {
    parts.push(renderCitationList(remainingCitations, `${keyPrefix}-tail`, planId, citationMetaByChunkId, onCitationClick));
  }

  return <>{parts}</>;
};

const mergeByReview = (groups: PastReviewGroupedItems[]): PastReviewGroupedItems[] => {
  const merged = new Map<string, PastReviewGroupedItems>();

  groups.forEach((group) => {
    const key = `${group.reviewId}::${group.reviewTitle}`;
    const existing = merged.get(key);

    if (!existing) {
      merged.set(key, {
        reviewId: group.reviewId,
        reviewTitle: group.reviewTitle,
        items: [...group.items],
      });
      return;
    }

    existing.items.push(...group.items);
  });

  return Array.from(merged.values());
};

const PastReviewAnalysisSection: React.FC<PastReviewAnalysisSectionProps> = ({ data, planId, title, onCitationClick, supportingCitations = [] }) => {
  const mergedKeyObservations = useMemo(() => mergeByReview(data.keyObservations), [data.keyObservations]);
  const mergedImplications = useMemo(() => mergeByReview(data.implications), [data.implications]);
  const citationMetaByChunkId = useMemo(() => {
    const map = new Map<string, SupportingCitation>();
    supportingCitations.forEach((citation) => {
      const chunkId = String(citation?.chunkId || '').trim();
      if (!chunkId) return;
      map.set(chunkId.toLowerCase(), citation);
    });
    return map;
  }, [supportingCitations]);

  return (
    <div className={style.wrapper}>
            {title && <h3 className={style.mainTitle}>{title}</h3>}
      
      <h3 className={style.sectionTitle}>Summary</h3>
      <p className={style.bodyText}><strong>Number of similar reviews:</strong> {data.summaryCount}</p>

      <h3 className={style.sectionTitle}>Key Observations</h3>
      <div className={style.listBlock}>
        {mergedKeyObservations.map((group) => (
          <p key={`obs-${group.reviewId}-${group.reviewTitle}`} className={style.bodyText}>
            <strong>Review ID {group.reviewId} ({group.reviewTitle}): </strong>
            {group.items.map((item, index) => (
              <React.Fragment key={`obs-item-${group.reviewId}-${index}`}>
                {renderTextWithCitations(
                  item.text,
                  item.citations,
                  `obs-item-${group.reviewId}-${index}`,
                  planId,
                  citationMetaByChunkId,
                  onCitationClick
                )}
                {index < group.items.length - 1 ? ' ' : ''}
              </React.Fragment>
            ))}
          </p>
        ))}
      </div>

      <h3 className={style.sectionTitle}>Implications</h3>
      <div className={style.listBlock}>
        {mergedImplications.map((group) => (
          <p key={`imp-${group.reviewId}-${group.reviewTitle}`} className={style.bodyText}>
            <strong>Review ID {group.reviewId} ({group.reviewTitle}): </strong>
            {group.items.map((item, index) => (
              <React.Fragment key={`imp-item-${group.reviewId}-${index}`}>
                {renderTextWithCitations(
                  item.text,
                  item.citations,
                  `imp-item-${group.reviewId}-${index}`,
                  planId,
                  citationMetaByChunkId,
                  onCitationClick
                )}
                {index < group.items.length - 1 ? ' ' : ''}
              </React.Fragment>
            ))}
          </p>
        ))}
      </div>

      <div className={style.tableWrapper}>
        <table className={style.table}>
          <thead>
            <tr>
              <th>Historical Review IDs</th>
              <th>Assessed Area</th>
              <th>Key Observations</th>
              <th>Relevance to Current Review</th>
            </tr>
          </thead>
          <tbody>
            {data.tableRows.map((row, rowIndex) => (
              <tr key={`${row.historicalReviewId}-${rowIndex}`}>
                <td>{row.historicalReviewId}</td>
                <td>{row.assessedArea}</td>
                <td>
                  {renderTextWithCitations(
                    row.keyObservations,
                    row.keyObservationCitations,
                    `row-key-obs-${rowIndex}`,
                    planId,
                    citationMetaByChunkId,
                    onCitationClick,
                    false
                  )}
                </td>
                <td>
                  {renderTextWithCitations(
                    row.relevanceToCurrentReview,
                    row.relevanceCitations,
                    `row-rel-${rowIndex}`,
                    planId,
                    citationMetaByChunkId,
                    onCitationClick,
                    false
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data.tableRows.length === 0 && (
        <Text variant="secondary">No historical review rows available.</Text>
      )}
    </div>
  );
};

export default PastReviewAnalysisSection;
