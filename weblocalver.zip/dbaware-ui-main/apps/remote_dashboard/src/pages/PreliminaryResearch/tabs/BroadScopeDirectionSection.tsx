import React from 'react';
import { SupportingCitation } from '../types';
import PolicyKodRegulatoryAnalysisSection from './PolicyKodRegulatoryAnalysisSection';

interface BroadScopeDirectionSectionProps {
  content: string;
  title?: string;
  planId?: string;
  onCitationClick?: (chunkId: string, e: React.MouseEvent<HTMLAnchorElement>) => void;
  supportingCitations?: SupportingCitation[];
}

const BroadScopeDirectionSection: React.FC<BroadScopeDirectionSectionProps> = ({
  content,
  title,
  planId,
  onCitationClick,
  supportingCitations,
}) => {
  return (
    <PolicyKodRegulatoryAnalysisSection
      content={content}
      title={title}
      planId={planId}
      onCitationClick={onCitationClick}
      supportingCitations={supportingCitations}
    />
  );
};

export default BroadScopeDirectionSection;
