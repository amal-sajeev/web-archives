
declare module "*.css"