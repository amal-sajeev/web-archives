import { defineConfig, PluginOption } from 'vite';
import react from '@vitejs/plugin-react';
import federation from '@originjs/vite-plugin-federation';

export default defineConfig(({ mode }) => {
  const plugins: PluginOption[] = [react()];

  if (process.env.NODE_ENV !== 'test') {
    plugins.push(
      federation({
        name: 'remote_header',
        filename: 'remoteEntry.js',
        exposes: {
          './Header': './src/Header.tsx',
        },
        shared: [
          'react',
          'react-dom',
          'react/jsx-runtime',
          'react/jsx-dev-runtime',
          'react-router-dom',
          'react-redux',
          '@reduxjs/toolkit',
          '@wadk/ui',
          '@wadk/icons',
          '@wadk/design-tokens',
          '@apollo/client',
          'graphql'
        ]
      })
    );
  }

  return {
    optimizeDeps: {
      force: true
    },
    plugins,
    build: {
      target: 'esnext',
      minify: false,
      cssCodeSplit: false,
      emptyOutDir: false,
      modulePreload: false,
      sourcemap: true,
    },
    server: {
      port: 5001,
      cors: true,
      origin: 'http://localhost:5001',
    }
  };
});