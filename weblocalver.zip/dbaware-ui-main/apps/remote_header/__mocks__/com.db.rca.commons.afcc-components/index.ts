import React from 'react';

export const AppHeader = (props: any) => React.createElement('div', { className: 'header-container' },
  React.createElement('div', { className: 'header-left' },
    React.createElement('div', { className: 'header-title' }, props.header),
    props.environment ? React.createElement('span', { className: 'header-badge' }, props.environment.children) : null,
    props.tabs
  ),
  React.createElement('div', { className: 'header-right' }, props.actions)
);
export const AvatarFlyout = (props: any) => React.createElement('div', { className: 'user-avatar-flyout-mock' }, props.name && props.name !== 'TBD' ? props.name.charAt(0) : 'A');
export const FixedTab = () => React.createElement('div');
export const KeyValuePair = (props: any) => React.createElement('div', null, props.children);
export const KeyValuePairItem = (props: any) => React.createElement('div', null, props.term, props.children);
export const Time = () => React.createElement('div');
export const TabBar = (props: any) => React.createElement('div', null, props.children);
export const TabBarTab = (props: any) => React.createElement('div', { className: 'header-tab', onClick: props.onClick }, props.children);