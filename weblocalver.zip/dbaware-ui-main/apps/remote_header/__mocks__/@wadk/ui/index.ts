import React from 'react';

export const Surface = (props: any) => React.createElement('div', null, props.children);
export const Button = (props: any) => React.createElement('button', { className: 'icon-button', 'aria-label': props.title }, props.icon);
export const DropdownInput = (props: any) => React.createElement('select', { 'aria-label': props.label, value: props.value, onChange: (e: any) => props.onChange && props.onChange(e.target.value) }, (props.items || []).map((i: any) => React.createElement('option', { key: i.value, value: i.value }, i.label)));
