import React from 'react';

export const Surface = (props: any) => React.createElement('div', null, props.children);
export const Button = (props: any) => React.createElement('button', { className: 'icon-button', 'aria-label': props.title }, props.icon);
