declare module 'host_app/store' {
    // Define the expected shape of the federated Redux store
    const store: {
        injectReducer: (key: string, reducer: any) => void;
    };
    export default store;
}