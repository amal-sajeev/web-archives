import React, { useEffect } from 'react';
import "com.db.rca.commons.afcc-components/style.css";
import './Header.css';
import { Link, useLocation, useNavigate, matchPath } from 'react-router-dom';
import { useSelector, useStore } from 'react-redux';
import {
  AppHeader,
  AvatarFlyout,
  FixedTab,
  KeyValuePair,
  KeyValuePairItem,
  TabBar,
  TabBarTab,
  Time
} from 'com.db.rca.commons.afcc-components';
import { BriefcaseOutline, ChatOutline, CogOutline, DrawerOutline, PcScreenSolid, PlusSolid, SparkleSolid, UserOutline } from '@wadk/icons';

import { Base, Button, Paragraph, Surface } from '@wadk/ui';

const userReducer = (state = { name: "TBD" }, action: any) => state;

const Header = ({ selectedLrId, onTabClose }: any) => {
  const location = useLocation();
  const navigate = useNavigate();
  const store = useStore() as any;

  useEffect(() => {
    if (store && typeof store.injectReducer === 'function') {
      store.injectReducer('user', userReducer);
    }
  }, [store]);

  const userName = "TBD";

  // Extract the planId from the URL pathname, supporting the dashboard tab routes or doc viewer routes
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const docsMatch = matchPath({ path: '/:planId/docs/*', end: false }, location.pathname);
  const planId = dashboardMatch?.params?.planId || docsMatch?.params?.planId || 'Unknown';

  // This function is ONLY for the 'X' button.
  const handleTabClose = (e: any) => {
    // Stop the click from bubbling up to any parent elements.
    e.stopPropagation();

    if (onTabClose) {
      onTabClose(); // Clear the ID in the parent component.
    }
    navigate('/'); // Navigate to the home page.
  };

  return (
    <>
      <AppHeader
        environment={{ children: "UAT", variant: "neutral", appearance: "emphasised-pill", size: 'xs' }}
        header={<>CnAFC Scoping Assistant</>}
        actions={<><Button icon={<CogOutline />} title="Settings" variant="toolbar" /><AvatarFlyout model={
          [{ label: 'Alan Turing', type: 'item', value: 'avatar0' }, 
            // { label: '', type: 'separator', value: 'separator' },
            //  { label: 'Avatar item 2', type: 'item', value: 'avatar2' },
            //   { label: 'Avatar item 3', type: 'item', value: 'avatar3' },
            //    { label: 'Avatar item 4', type: 'item', value: 'avatar4' }
              ]
              } 
               name="Alan Turing" size="md"><Surface paddingX="base"
                paddingY="md" radius="base" shade="subtle">
                  <KeyValuePair alignment="vertical">
                    <KeyValuePairItem term="User:">alan.turing@db.com</KeyValuePairItem>
                    <KeyValuePairItem term="Last login to [Application title]:">
                      
                      <Time date="2024-04-23T11:23:39.000Z" dateFormat="dd-MM-yyyy hh:mm:ss O" /></KeyValuePairItem></KeyValuePair><Paragraph>If this time is incorrect contact a{' '}<a href="#">DB Support Representative</a>{' '}in you region.</Paragraph></Surface></AvatarFlyout></>}

        tabs={<><TabBar direction="row" value="1">
          <TabBarTab closable value="1">Review Plan ID {planId}</TabBarTab>
        </TabBar></>}
      />
    </>
  );
};

export default Header;
