import React, { useEffect, useState } from 'react';
import "com.db.rca.commons.afcc-components/style.css";
import './Header.css';
import { Link, useLocation, useNavigate, matchPath } from 'react-router-dom';
import { useSelector, useStore } from 'react-redux';
import {
  AppHeader,
  AvatarFlyout,
  FixedTab,
  KeyValuePair,
  KeyValuePairItem,
  TabBar,
  TabBarTab, Time,
  DropdownMenuItemRadio,
  DropdownMenuList
} from 'com.db.rca.commons.afcc-components';
import { BriefcaseOutline, ChatOutline, CogOutline, DotSolidSm, DrawerOutline, PcScreenSolid, PlusSolid, SparkleSolid, UserOutline } from '@wadk/icons';

import { Base, Button, DropdownMenu, DropdownMenuGroup, DropdownMenuTrigger, Paragraph, Surface } from '@wadk/ui';

const THEME_STORAGE_KEY = 'dbaware-theme';
const THEME_ITEMS = [
  { value: 'light', label: 'light' },
  { value: 'dark', label: 'dark' },
  { value: 'light-legacy', label: 'light-legacy' },
  { value: 'dark-legacy', label: 'dark-legacy' },
];
const DEFAULT_THEME = 'dark-legacy';

const getInitialTheme = (): string => {
  const fromDom = document.documentElement.getAttribute('data-theme');
  if (fromDom && THEME_ITEMS.some((item) => item.value === fromDom)) return fromDom;
  try {
    const stored = localStorage.getItem(THEME_STORAGE_KEY);
    if (stored && THEME_ITEMS.some((item) => item.value === stored)) return stored;
  } catch {
    // localStorage unavailable
  }
  return DEFAULT_THEME;
};

const userReducer = (state = { name: "TBD" }, action: any) => state;

const Header = ({ selectedLrId, onTabClose }: any) => {
  const location = useLocation();
  const navigate = useNavigate();
  const store = useStore() as any;
  const [theme, setTheme] = useState<string>(getInitialTheme);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // ignore storage errors
    }
  }, [theme]);

  useEffect(() => {
    if (store && typeof store.injectReducer === 'function') {
      store.injectReducer('user', userReducer);
    }
  }, [store]);

  const userName = "TBD";

  // Extract the planId from the URL pathname, supporting the dashboard tab routes or doc viewer routes
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const docsMatch = matchPath({ path: '/:planId/docs/*', end: false }, location.pathname);
  const planId = dashboardMatch?.params?.planId || docsMatch?.params?.planId || 'Unknown';

  // This function is ONLY for the 'X' button.
  const handleTabClose = (e: any) => {
    // Stop the click from bubbling up to any parent elements.
    e.stopPropagation();

    if (onTabClose) {
      onTabClose(); // Clear the ID in the parent component.
    }
    navigate('/'); // Navigate to the home page.
  };

  return (
    <>
      <AppHeader
        environment={{ children: "UAT", variant: "neutral", appearance: "emphasised-pill", size: 'xs' }}
        header={<>C&AFC Scoping Agent</>} actions={
          <DropdownMenu
            value={theme}
            onChange={(v: unknown) => {
              if (typeof v === 'string' && THEME_ITEMS.some((item) => item.value === v)) setTheme(v);
            }}
          >
            <DropdownMenuTrigger>
              <Button variant="toolbar">Theme: {theme}</Button>
            </DropdownMenuTrigger>
            <DropdownMenuList>
              <DropdownMenuGroup label="Theme">
                {THEME_ITEMS.map((item) => (
                  <DropdownMenuItemRadio
                    key={item.value}
                    value={item.value}
                    aria-checked={theme === item.value}
                    icon={theme === item.value ? <DotSolidSm /> : <span />}
                  >
                    {item.label}
                  </DropdownMenuItemRadio>
                ))}
              </DropdownMenuGroup>
            </DropdownMenuList>
          </DropdownMenu>
        }
        tabs={<><TabBar direction="row" value="1">
          <TabBarTab closable value="1">Review Plan ID {planId}</TabBarTab>
        </TabBar></>}
      />
    </>
  );
};

export default Header;
