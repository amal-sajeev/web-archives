import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
// @ts-ignore: Node types may not be installed due to proxy
import path from 'node:path';

export default defineConfig({
    plugins: [react()],
    test: {
        environment: 'jsdom',
        alias: {
            // @ts-ignore
            '@wadk/ui': path.resolve(__dirname, '__mocks__/@wadk/ui/index.ts'),
            // @ts-ignore
            '@wadk/icons': path.resolve(__dirname, '__mocks__/@wadk/icons/index.ts'),
            // @ts-ignore
            'com.db.rca.commons.afcc-components': path.resolve(__dirname, '__mocks__/com.db.rca.commons.afcc-components/index.ts'),
        }
    }
});