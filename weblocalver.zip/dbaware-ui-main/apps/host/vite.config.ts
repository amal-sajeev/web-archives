import { defineConfig, PluginOption } from 'vite';
import react from '@vitejs/plugin-react';
import federation from '@originjs/vite-plugin-federation';
import path from 'node:path';

const API_BASE_URL = '/';

export default defineConfig(({ mode }) => {
  const plugins: PluginOption[] = [react()];

  if (process.env.NODE_ENV !== 'test') {
    plugins.push(
      federation({
        name: 'host_app',
        filename: 'remoteEntry.js',
        exposes: {
          './store': './src/store/index.ts',
        },
        remotes: {
          remote_header: '/dbaware-ui/remote_header/assets/remoteEntry.js',
          remote_leftSidebar: '/dbaware-ui/remote_leftSidebar/assets/remoteEntry.js',
          remote_RightSidebar: '/dbaware-ui/remote_RightSidebar/assets/remoteEntry.js',
          remote_dashboard: '/dbaware-ui/remote_dashboard/assets/remoteEntry.js',
        },
        shared: [
          'react',
          'react-dom',
          'react/jsx-runtime',
          'react/jsx-dev-runtime',
          'react-router-dom',
          'react-redux',
          '@reduxjs/toolkit',
          '@wadk/ui',
          '@wadk/icons',
          '@wadk/design-tokens',
          '@apollo/client',
          'graphql'
        ]
      })
    );
  }

  return {
    base: '/dbaware-ui/',
    envDir: path.resolve(__dirname, '../../'),
    optimizeDeps: { force: true },
    plugins,
    build: {
      target: 'esnext',
      minify: false,
      cssCodeSplit: false,
      emptyOutDir: false,
      modulePreload: false,
      sourcemap: true
    },
    server: {
      port: 5173,
      cors: true,
      origin: 'http://localhost:5173',
      proxy: {
        '/dbaware-api-gateway': {
          target: 'https://ct1-cta.dbaware.dev.gcp.db.com',
          changeOrigin: true,
          secure: false
        },
        '/dbaware-ui/remote_header': {
          target: 'http://localhost:5001',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_header/, '')
        },
        '/dbaware-ui/remote_leftSidebar': {
          target: 'http://localhost:5002',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_leftSidebar/, '')
        },
        '/dbaware-ui/remote_RightSidebar': {
          target: 'http://localhost:5003',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_RightSidebar/, '')
        },
        '/dbaware-ui/remote_dashboard': {
          target: 'http://localhost:5004',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_dashboard/, '')
        },
        '^(?!/dbaware-ui/)': {
          target: 'https://ct1-cta.dbaware.dev.gcp.db.com',
          changeOrigin: true,
          secure: false,
          filter: (pathname: string, req: any) => {
            const origin = req.headers.origin || req.headers.referer || '';
            return origin.includes('localhost');
          }
        }
      }
    },
    preview: {
      proxy: {
        '/dbaware-api-gateway': {
          target: 'https://ct1-cta.dbaware.dev.gcp.db.com',
          changeOrigin: true,
          secure: false
        },
        '/dbaware-ui/remote_header': {
          target: 'http://localhost:5001',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_header/, '')
        },
        '/dbaware-ui/remote_leftSidebar': {
          target: 'http://localhost:5002',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_leftSidebar/, '')
        },
        '/dbaware-ui/remote_RightSidebar': {
          target: 'http://localhost:5003',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_RightSidebar/, '')
        },
        '/dbaware-ui/remote_dashboard': {
          target: 'http://localhost:5004',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/dbaware-ui\/remote_dashboard/, '')
        },
        '^(?!/dbaware-ui/)': {
          target: 'https://ct1-cta.dbaware.dev.gcp.db.com',
          changeOrigin: true,
          secure: false,
          filter: (pathname: string, req: any) => {
            const origin = req.headers.origin || req.headers.referer || '';
            return origin.includes('localhost');
          }
        }
      }
    }
  };
});
