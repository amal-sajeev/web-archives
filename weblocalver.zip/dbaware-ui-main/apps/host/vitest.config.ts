import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const rootDir = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      'remote_dashboard/Dashboard': path.resolve(rootDir, 'src/test/mocks/remoteDashboard.tsx'),
      'remote_dashboard/DocumentViewer': path.resolve(rootDir, 'src/test/mocks/remoteDashboard.tsx'),
    },
  },
  test: {
    environment: 'jsdom',
  },
});