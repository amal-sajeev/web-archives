// Fallback declarations for React
declare module 'react';
declare module 'react-dom';
