
export const isEmailEnabled = (): string | null => {
  const email = new URLSearchParams(window.location.search).get('email');
  return typeof email === 'string' && email.trim().length > 0 ? email.trim() : null;
}

export const isIdaasEnabled = (): boolean => {
  const { origin, hostname } = window.location;
  const isLocalhost = hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1';
  return origin !== 'https://ct1-cta.dbaware.dev.gcp.db.com' && !isLocalhost;
};

const EMAIL_RC_TOKEN_STORAGE_KEY_PREFIX = '__dbawareEmailRcToken__';
const LAST_EMAIL_STORAGE_KEY = '__dbawareLastEmailForRcToken';

function base64UrlEncode(value: unknown): string {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  let binary = '';
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  return btoa(binary)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function encodeJwt<T = Record<string, unknown>>(
  payload: T,
  header: { alg: string; typ?: string } = { alg: 'none', typ: 'JWT' }
): string {
  return `${base64UrlEncode(header)}.${base64UrlEncode(payload)}.`;
}

const buildEmailRcToken = (email: string): string => {
  return encodeJwt({ unique_name: email });
};

const getEmailRcTokenStorageKey = (email: string): string => {
  return `${EMAIL_RC_TOKEN_STORAGE_KEY_PREFIX}${encodeURIComponent(email.toLowerCase())}`;
};

const getEmailRcTokenFromStorage = (email: string): string | null => {
  try {
    return window.localStorage.getItem(getEmailRcTokenStorageKey(email));
  } catch {
    return null;
  }
};

const getLastEmailFromStorage = (): string | null => {
  try {
    const value = window.localStorage.getItem(LAST_EMAIL_STORAGE_KEY);
    return typeof value === 'string' && value.trim().length > 0 ? value.trim() : null;
  } catch {
    return null;
  }
};

const removeEmailRcTokenFromStorage = (email: string): void => {
  try {
    window.localStorage.removeItem(getEmailRcTokenStorageKey(email));
  } catch {
    // Ignore storage failures.
  }
};

const saveLastEmailToStorage = (email: string): void => {
  try {
    window.localStorage.setItem(LAST_EMAIL_STORAGE_KEY, email);
  } catch {
    // Ignore storage failures.
  }
};

const getAnyEmailRcTokenFromStorage = (): string | null => {
  try {
    const lastEmail = getLastEmailFromStorage();
    if (lastEmail) {
      const token = getEmailRcTokenFromStorage(lastEmail);
      if (token) {
        return token;
      }
    }

    for (let index = 0; index < window.localStorage.length; index += 1) {
      const key = window.localStorage.key(index);
      if (!key || !key.startsWith(EMAIL_RC_TOKEN_STORAGE_KEY_PREFIX)) {
        continue;
      }

      const token = window.localStorage.getItem(key);
      if (token) {
        return token;
      }
    }
  } catch {
    // Ignore storage failures.
  }

  return null;
};

const saveEmailRcTokenToStorage = (email: string, token: string | null): void => {
  try {
    const key = getEmailRcTokenStorageKey(email);
    if (token) {
      window.localStorage.setItem(key, token);
      return;
    }
    window.localStorage.removeItem(key);
  } catch {
    // Ignore storage failures.
  }
};

let rcToken: string | null = null;

export const setRcToken = (token: string | null): void => {
  rcToken = token;
};

export const getRcToken = (): string | null => {
  return rcToken;
};

const readRcTokenFromHeaders = (response: Response): string | null => {
  return response.headers.get('x-asm-rctoken') || response.headers.get('X-ASM-RCTOKEN');
};

const fetchRcTokenFromScriptAssets = async (): Promise<string | null> => {
  const scriptCandidates = Array.from(document.querySelectorAll('script[src]'))
    .map((script) => (script as HTMLScriptElement).src)
    .filter((src) => /\.m?js($|\?)/i.test(src));

  const preloadCandidates = Array.from(document.querySelectorAll('link[rel="modulepreload"][href]'))
    .map((link) => (link as HTMLLinkElement).href)
    .filter((href) => /\.m?js($|\?)/i.test(href));

  const candidates = Array.from(new Set([...scriptCandidates, ...preloadCandidates]))
    .map((src) => new URL(src, window.location.origin))
    .filter((url) => url.origin === window.location.origin)
    .map((url) => url.toString());

  for (const candidateUrl of candidates) {
    try {
      const headResponse = await fetch(candidateUrl, {
        method: 'HEAD',
        credentials: 'include',
        cache: 'no-store',
      });

      const headToken = readRcTokenFromHeaders(headResponse);
      if (headToken) {  
        return headToken;
      }
    } catch {
      // Ignore and continue with GET fallback below.
    }

    try {
      const getResponse = await fetch(candidateUrl, {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store',
      });

      const getToken = readRcTokenFromHeaders(getResponse);
      if (getToken) {
        return getToken;
      }
    } catch {
      // Ignore and continue to next candidate.
    }
  }

  return null;
};

export const fetchRcToken = async (): Promise<string | null> => {
  const email = isEmailEnabled();
  if (email) {
    const normalizedEmail = email.toLowerCase();
    const previousEmail = getLastEmailFromStorage()?.toLowerCase() || null;

    if (previousEmail && previousEmail !== normalizedEmail) {
      removeEmailRcTokenFromStorage(previousEmail);
    }

    const storedToken = getEmailRcTokenFromStorage(normalizedEmail);
    const token = storedToken || buildEmailRcToken(email);
    saveEmailRcTokenToStorage(normalizedEmail, token);
    saveLastEmailToStorage(normalizedEmail);
    setRcToken(token);
    return token;
  }

  const storedEmailToken = getAnyEmailRcTokenFromStorage();
  if (storedEmailToken) {
    setRcToken(storedEmailToken);
    return storedEmailToken;
  }

  const token: string | null = await fetchRcTokenFromScriptAssets();
  setRcToken(token);
  return token;
};
