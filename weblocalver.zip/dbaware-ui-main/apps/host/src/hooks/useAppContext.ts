import { useContext } from 'react';
import { AppContext, type ContextType } from '../contexts/AppContext';

export const useAppContext = (): ContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};