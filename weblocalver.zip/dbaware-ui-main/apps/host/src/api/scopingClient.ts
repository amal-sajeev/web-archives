import { getJson, postJson } from './sharedApi';

const ACTIONS_URL = '/dbaware-api-gateway/api/v1/actions';
const TASK_STATUS_URL = '/dbaware-api-gateway/api/v1/task/status';

type ScopingAction = 'START_SCOPING';

interface StartScopingPayload {
    noir_required: boolean;
}

interface ScopingGatewayRequest<TPayload> {
    planNumber: string;
    action: ScopingAction;
    payload: TPayload;
}

export interface TaskStatusResponse {
    planNumber: string;
    hasActiveTask: boolean;
    taskId: string;
    taskDefinitionKey: string;
    status: string;
    owner: string;
    processInstanceId: string;
    processName: string;
    variables?: Record<string, unknown>;
    nextAvailableWorkflowActions?: string[];
}

interface TaskStatusWorkflowAction {
    action?: string;
    sub_action?: string | null;
}

interface RawTaskStatusResponse {
    planNumber: string;
    hasActiveTask: boolean;
    taskId: string;
    taskDefinitionKey: string;
    status: string;
    owner: string;
    processInstanceId: string;
    processName: string;
    variables?: Record<string, unknown>;
    nextAvailableWorkflowActions?: TaskStatusWorkflowAction[];
}

const buildPlanNumber = (planNumber: number | string): string => String(planNumber);

export const startScoping = (planNumber: number | string, noirRequired = true): Promise<unknown> => {
    const request: ScopingGatewayRequest<StartScopingPayload> = {
        planNumber: buildPlanNumber(planNumber),
        action: 'START_SCOPING',
        payload: {
            noir_required: noirRequired,
        },
    };

    return postJson<unknown>(ACTIONS_URL, request);
};

export const getTaskStatus = (planNumber: number | string): Promise<TaskStatusResponse> => {
    const resolvedPlanNumber = buildPlanNumber(planNumber);
    return getJson<RawTaskStatusResponse>(`${TASK_STATUS_URL}/${resolvedPlanNumber}`).then((response) => {
        const nextActionsFromVariables = typeof response.variables?.p_NEXT_AVAILABLE_ACTIONS === 'string'
            ? response.variables.p_NEXT_AVAILABLE_ACTIONS
                .split(',')
                .map((action) => action.trim())
                .filter(Boolean)
            : [];

        const nextActionsFromWorkflow = Array.isArray(response.nextAvailableWorkflowActions)
            ? response.nextAvailableWorkflowActions
                .map((item) => (typeof item?.action === 'string' ? item.action.trim() : ''))
                .filter(Boolean)
            : [];

        const nextAvailableWorkflowActions = nextActionsFromVariables.length > 0
            ? nextActionsFromVariables
            : nextActionsFromWorkflow;

        const normalized: TaskStatusResponse = {
            ...response,
            taskDefinitionKey: String(response.taskDefinitionKey ?? '').trim(),
            nextAvailableWorkflowActions,
        };

        if (typeof window !== 'undefined') {
            const plan = normalized.planNumber || resolvedPlanNumber;
            try {
                window.sessionStorage.setItem(`taskDefinitionKey:${plan}`, normalized.taskDefinitionKey);
                window.sessionStorage.setItem(`nextAvailableActions:${plan}`, JSON.stringify(nextAvailableWorkflowActions));
                const vars = normalized.variables as Record<string, unknown> | undefined;
                const rawScopeId =
                    vars?.review_scope_id ??
                    vars?.reviewScopeId ??
                    vars?.review_scope_instance_id ??
                    vars?.reviewScopeInstanceId ??
                    vars?.p_REVIEW_SCOPE_ID;
                const scopingContext = {
                    planNumber: plan,
                    ...(typeof normalized.processInstanceId === 'string' && normalized.processInstanceId.trim()
                        ? { processInstanceId: normalized.processInstanceId.trim() }
                        : {}),
                    ...(typeof normalized.taskId === 'string' && normalized.taskId.trim()
                        ? { taskId: normalized.taskId.trim() }
                        : {}),
                    ...(normalized.taskDefinitionKey ? { taskDefinitionKey: normalized.taskDefinitionKey } : {}),
                    ...(typeof normalized.owner === 'string' && normalized.owner.trim()
                        ? { owner: normalized.owner.trim() }
                        : {}),
                    ...(rawScopeId !== undefined && rawScopeId !== null && String(rawScopeId).trim()
                        ? { reviewScopeId: String(rawScopeId).trim() }
                        : {}),
                };
                window.sessionStorage.setItem(`scopingContext:${plan}`, JSON.stringify(scopingContext));
            } catch {
                // Ignore sessionStorage errors
            }
        }

        return normalized;
    });
};
