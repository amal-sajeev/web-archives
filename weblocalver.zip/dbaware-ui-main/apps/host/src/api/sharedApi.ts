import { getRcToken } from '../auth/idaas';

type ApiClientLike = {
    post: <T>(url: string, data?: unknown, config?: unknown) => Promise<T>;
    get?: <T>(url: string, config?: unknown) => Promise<T>;
};

declare global {
    interface Window {
        __dbaware?: {
            apiClient?: ApiClientLike;
            [key: string]: unknown;
        };
    }
}

export const getSharedApiClient = (): ApiClientLike | undefined => {
    if (typeof window === 'undefined') return undefined;
    return window.__dbaware?.apiClient;
};

const resolveBaseUrl = (): string => '/';

const isAbsoluteUrl = (url: string): boolean => /^https?:\/\//i.test(url);
const toRequestUrl = (url: string): string => (isAbsoluteUrl(url) ? url : url.startsWith('/') ? url : `${resolveBaseUrl()}${url}`);
const buildJsonHeaders = (): Record<string, string> => {
    const token = getRcToken();
    return token
        ? { 'Content-Type': 'application/json', 'x-asm-rctoken': token }
        : { 'Content-Type': 'application/json' };
};

export const postJson = async <T>(url: string, payload: unknown): Promise<T> => {
    const fullUrl = toRequestUrl(url);
    const headers = buildJsonHeaders();

    const client = getSharedApiClient();
    if (client && !isAbsoluteUrl(url)) {
        return client.post<T>(url, payload, {
            headers,
            timeout: 600000,
        });
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 600000);

    try {
        const response = await fetch(fullUrl, {
            method: 'POST',
            headers,
            body: JSON.stringify(payload),
            signal: controller.signal,
        });

        if (!response.ok) {
            throw new Error(`POST ${fullUrl} failed: ${response.status} ${response.statusText}`);
        }

        return (await response.json()) as T;
    } finally {
        clearTimeout(timeoutId);
    }
};

export const getJson = async <T>(url: string, extraHeaders?: Record<string, string>): Promise<T> => {
    const fullUrl = toRequestUrl(url);
    const headers = { ...(extraHeaders ?? {}), ...buildJsonHeaders() };

    const client = getSharedApiClient();
    if (client?.get && !isAbsoluteUrl(url)) {
        return client.get<T>(url, {
            headers,
            timeout: 600000,
        });
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 600000);

    try {
        const response = await fetch(fullUrl, {
            method: 'GET',
            headers,
            signal: controller.signal,
        });

        if (!response.ok) {
            throw new Error(`GET ${fullUrl} failed: ${response.status} ${response.statusText}`);
        }

        return (await response.json()) as T;
    } finally {
        clearTimeout(timeoutId);
    }
};
