import React, { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import { HeaderLoader, LeftSidebarLoader, RightSidebarLoader } from '../components/loaders/SkeletonLoaders';
import ErrorBoundary from '../components/ErrorBoundary';
import styles from './Layout.module.css';
import { DragBarContainer } from "com.db.rca.commons.afcc-components";

const Header = lazy(() => import('remote_header/Header').catch(() => {
  return { default: () => <div className={styles['fallback-header']}>Header failed to load</div> }
}));

const LeftSidebar = lazy(() => import('remote_leftSidebar/LeftSidebar').catch(() => {
  return { default: () => <div className={styles['fallback-sidebar']}>Left Sidebar failed to load</div> }
}));

const RightSidebar = lazy(() => import('remote_RightSidebar/RightSidebar').catch(() => {
  return { default: () => <div className={styles['fallback-sidebar']}>Right Sidebar failed to load</div> }
}));

const Layout = () => {
  return (
    <>
      <header className={styles['layout-header']}>
        <ErrorBoundary componentName="Header">
          <Suspense fallback={<HeaderLoader />}>
            <Header />
          </Suspense>
        </ErrorBoundary>
      </header>
      <div className={styles['main-container']}>
        <div className={styles['container']}>
          <DragBarContainer
            className={styles['left-main-split']}
            orientation="vertical"
            startMinSize="260px"
            endMinSize="60%"
            offset="160px"
            borderPosition="end"
            startChild={
              <aside className={styles['layout-left-sidebar']}>
                <ErrorBoundary componentName="Left Sidebar">
                  <Suspense fallback={<LeftSidebarLoader />}>
                    <div className={styles['left-sidebar-content']}>
                      <LeftSidebar />
                    </div>
                  </Suspense>
                </ErrorBoundary>
              </aside>
            }
          >
            <main className={styles['layout-main-content']}>
              <ErrorBoundary componentName="Main Content">
                <Outlet />
              </ErrorBoundary>
            </main>
          </DragBarContainer>

          <aside className={styles['layout-right-sidebar']}>
            <ErrorBoundary componentName="Right Sidebar">
              <Suspense fallback={<RightSidebarLoader />}>
                <RightSidebar />
              </Suspense>
            </ErrorBoundary>
          </aside>
        </div>
      </div>

    </>
  );
};

export default Layout;