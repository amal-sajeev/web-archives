import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { Provider } from 'react-redux';
import dynamicStore from './store';
import { BrowserRouter } from 'react-router-dom';
import { Base } from '@wadk/ui';
import { AppProvider } from './providers/AppProvider';

const localFont = window.location.protocol !== 'https:';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>

    <Provider store={dynamicStore}>
      <BrowserRouter basename="/dbaware-ui">
        <Base localFont={localFont}>
          <AppProvider>
            <App />
          </AppProvider>
        </Base>
      </BrowserRouter>
    </Provider>
  </React.StrictMode>
);