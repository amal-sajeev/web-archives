import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AppContext } from './contexts/AppContext';

vi.mock('./auth/idaas', () => ({
  buildIdaasAuthorizeUrl: vi.fn(() => 'https://example.test/authorize'),
  decodeJwtPayload: vi.fn(() => ({ email: 'user@example.com' })),
  exchangeAuthorizationCode: vi.fn(),
  isIdaasEnabled: vi.fn(() => false),
}));

import App from './App';

// Mock the remote modules using vi.mock to avoid issues loading them during tests
vi.mock('remote_dashboard/Dashboard', () => {
  return {
    default: () => <div data-testid="remote-dashboard">Mocked Dashboard</div>
  };
});

vi.mock('./layouts/Layout', () => {
  const { Outlet } = require('react-router-dom');
  return {
    default: () => (
      <div data-testid="mock-layout">
        <h1>Mocked Layout</h1>
        <Outlet />
      </div>
    )
  };
});

describe('App Component', () => {
  it('renders the layout correctly for dashboard routes', async () => {
    render(
      <AppContext.Provider value={{
        idaasEnabled: false,
        isLoadingSession: false,
        hasRcToken: true,
        rctoken: null,
        setRctoken: vi.fn(),
      }}>
        <MemoryRouter initialEntries={['/dashboard']}>
          <App />
        </MemoryRouter>
      </AppContext.Provider>
    );

    expect(await screen.findByTestId('mock-layout')).toBeDefined();
  });

});
