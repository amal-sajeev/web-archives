import React, { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './layouts/Layout';
import ErrorBoundary from './components/ErrorBoundary';
import { DashboardLoader } from './components/loaders/SkeletonLoaders';
import { useAppContext } from './hooks/useAppContext';

const LandingPage = lazy(() => {
  return import('./pages/LandingPage').catch(() => {
    return { default: () => <div style={{ padding: '20px' }}>Landing Page failed to load</div> }
  });
});

const Dashboard = lazy(() => {
  return import('remote_dashboard/Dashboard').catch(() => {
    return { default: () => <div style={{ padding: '20px' }}>Dashboard failed to load</div> }
  });
});

const DocumentViewer = lazy(() => {
  return import('remote_dashboard/DocumentViewer').catch(() => {
    return { default: () => <div style={{ padding: '20px' }}>Document Viewer failed to load</div> }
  });
});

const NotAuthorizedPage = () => {
  return (
    <div style={{ padding: '24px', maxWidth: '600px', margin: '40px auto', textAlign: 'center' }}>
      <h2 style={{ marginBottom: '12px' }}>Not Authorized</h2>
      <p style={{ margin: 0 }}>
        You do not have permission to access this application.
      </p>
    </div>
  );
};

const Boundary = ErrorBoundary as any;

function App() {
  const { idaasEnabled, isLoadingSession, hasRcToken } = useAppContext();

  console.log("App context values:", { idaasEnabled, isLoadingSession, hasRcToken });
  if (isLoadingSession) {
    return <div style={{ padding: '20px' }}>Loading session...</div>;
  }

  const protect = (element) => {
    if (!idaasEnabled) {
      return element;
    }
    return hasRcToken ? element : <Navigate to="/not-authorized" replace />;
  };

  return (
    <Routes>
      <Route path="/not-authorized" element={
        idaasEnabled ? (
          <Boundary componentName="NotAuthorizedPage">
            <Suspense fallback={<div style={{ padding: '20px' }}>Loading not authorized page...</div>}>
              <NotAuthorizedPage />
            </Suspense>
          </Boundary>
        ) : (
          <Navigate to="/home" replace />
        )
      } />
      <Route path="/" element={protect(<Navigate to="/home" replace />)} />
      <Route path="/:planId/docs/:chunkId" element={
        protect(
          <Boundary componentName="DocumentViewer">
            <Suspense fallback={<div style={{ padding: '20px' }}>Loading document viewer...</div>}>
              <DocumentViewer />
            </Suspense>
          </Boundary>
        )
      } />
      <Route path="/home" element={
        protect(
          <Boundary componentName="LandingPage">
            <Suspense fallback={<div style={{ padding: '20px' }}>Loading LandingPage</div>}>
              <LandingPage />
            </Suspense>
          </Boundary>
        )
      } />
      <Route path="/" element={protect(<Layout />)}>
        <Route path="*" element={
          protect(
            <Boundary componentName="Dashboard">
              <Suspense fallback={<DashboardLoader />}>
                <Dashboard />
              </Suspense>
            </Boundary>
          )
        } />
      </Route>
    </Routes>
  );
}

export default App;