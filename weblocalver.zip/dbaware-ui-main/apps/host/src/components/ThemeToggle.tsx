import React, { useEffect, useState } from 'react';
import { Button, DropdownMenu, DropdownMenuGroup, DropdownMenuTrigger } from '@wadk/ui';
import { DotSolidSm } from '@wadk/icons';
import { DropdownMenuItemRadio, DropdownMenuList } from 'com.db.rca.commons.afcc-components';
import 'com.db.rca.commons.afcc-components/style.css';

const THEME_STORAGE_KEY = 'dbaware-theme';
const THEME_ITEMS = [
    { value: 'light', label: 'light' },
    { value: 'dark', label: 'dark' },
    { value: 'light-legacy', label: 'light-legacy' },
    { value: 'dark-legacy', label: 'dark-legacy' },
];
const DEFAULT_THEME = 'dark-legacy';

const isKnownTheme = (value: unknown): boolean =>
    typeof value === 'string' && THEME_ITEMS.some((item) => item.value === value);

const getInitialTheme = (): string => {
    const fromDom = document.documentElement.getAttribute('data-theme');
    if (fromDom && isKnownTheme(fromDom)) return fromDom;
    try {
        const stored = localStorage.getItem(THEME_STORAGE_KEY);
        if (stored && isKnownTheme(stored)) return stored;
    } catch {
        // localStorage unavailable
    }
    return DEFAULT_THEME;
};

/** Theme switcher (radio menu). Sets data-theme on <html> and remembers the choice. */
export function ThemeToggle() {
    const [theme, setTheme] = useState(getInitialTheme);

    useEffect(() => {
        document.documentElement.setAttribute('data-theme', theme);
        try {
            localStorage.setItem(THEME_STORAGE_KEY, theme);
        } catch {
            // ignore storage errors
        }
    }, [theme]);

    return (
        <DropdownMenu
            value={theme}
            onChange={(v: unknown) => {
                if (typeof v === 'string' && isKnownTheme(v)) setTheme(v);
            }}
        >
            <DropdownMenuTrigger>
                <Button variant="toolbar">{`Theme: ${theme}`}</Button>
            </DropdownMenuTrigger>
            <DropdownMenuList>
                <DropdownMenuGroup label="Theme">
                    {THEME_ITEMS.map((item) => (
                        <DropdownMenuItemRadio
                            key={item.value}
                            value={item.value}
                            aria-checked={theme === item.value}
                            icon={theme === item.value ? <DotSolidSm /> : <span />}
                        >
                            {item.label}
                        </DropdownMenuItemRadio>
                    ))}
                </DropdownMenuGroup>
            </DropdownMenuList>
        </DropdownMenu>
    );
}

export default ThemeToggle;