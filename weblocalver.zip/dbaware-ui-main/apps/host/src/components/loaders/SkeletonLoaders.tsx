import React from 'react';
import './SkeletonLoaders.css';

export const HeaderLoader = () => (
  <div className="skeleton-header">
    <div className="skeleton skeleton-header-logo"></div>
    <div className="skeleton-header-nav">
      <div className="skeleton skeleton-header-nav-item"></div>
      <div className="skeleton skeleton-header-nav-item"></div>
      <div className="skeleton skeleton-header-nav-item"></div>
    </div>
    <div className="skeleton skeleton-header-profile"></div>
  </div>
);

export const LeftSidebarLoader = () => (
  <div className="skeleton-sidebar left">
    <div className="skeleton skeleton-sidebar-title"></div>
    <div className="skeleton skeleton-sidebar-item"></div>
    <div className="skeleton skeleton-sidebar-item short"></div>
    <div className="skeleton skeleton-sidebar-item"></div>
    <div className="skeleton skeleton-sidebar-item short"></div>
    <div className="skeleton skeleton-sidebar-box"></div>
  </div>
);

export const RightSidebarLoader = () => (
  <div className="skeleton-sidebar right">
    <div className="skeleton skeleton-icon"></div>
    <div className="skeleton skeleton-icon"></div>
    <div className="skeleton skeleton-icon"></div>
    <div className="skeleton skeleton-icon"></div>
  </div>
);

export const DashboardLoader = () => (
  <div className="skeleton-dashboard">
    <div className="skeleton skeleton-dashboard-title"></div>
    <div className="skeleton-dashboard-cards">
      <div className="skeleton skeleton-dashboard-card"></div>
      <div className="skeleton skeleton-dashboard-card"></div>
      <div className="skeleton skeleton-dashboard-card"></div>
      <div className="skeleton skeleton-dashboard-card"></div>
    </div>
    <div className="skeleton skeleton-dashboard-chart"></div>
  </div>
);
