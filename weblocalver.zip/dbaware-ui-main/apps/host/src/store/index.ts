import { combineReducers, configureStore, Reducer, UnknownAction } from '@reduxjs/toolkit';

// Define the shape of our initial static reducers
const staticReducers = {
  app: (state = { loaded: true }, action: UnknownAction) => state
};

// Create a Reducer Manager to handle dynamic injection
export function createReducerManager(initialReducers: Record<string, Reducer>) {
  const reducers = { ...initialReducers };
  let combinedReducer = combineReducers(reducers);
  let keysToRemove: string[] = [];

  return {
    getReducerMap: () => reducers,

    // The root reducer function exposed to the store
    reduce: (state: any, action: UnknownAction) => {
      // If any reducers have been removed, clean up their state first
      if (keysToRemove.length > 0) {
        state = { ...state };
        for (const key of keysToRemove) {
          delete state[key];
        }
        keysToRemove = [];
      }
      return combinedReducer(state, action);
    },

    // Adds a new reducer dynamically
    injectReducer: (key: string, reducer: Reducer) => {
      if (!key || reducers[key]) {
        return; // Reducer already exists or key is invalid
      }
      reducers[key] = reducer;
      combinedReducer = combineReducers(reducers);
    },

    // Removes a reducer dynamically
    removeReducer: (key: string) => {
      if (!key || !reducers[key]) {
        return; // Reducer does not exist
      }
      delete reducers[key];
      keysToRemove.push(key);
      combinedReducer = combineReducers(reducers);
    }
  };
}

const reducerManager = createReducerManager(staticReducers);

export const store = configureStore({
  reducer: reducerManager.reduce,
  // We need to disable the thunk middleware's serialization check for the Reducer Manager if needed, 
  // but standard configuration is usually fine.
});

// Extend the store instance to attach the Reducer Manager methods so MFEs can call store.injectReducer()
export const dynamicStore = {
  ...store,
  injectReducer: reducerManager.injectReducer,
  removeReducer: reducerManager.removeReducer
};

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default dynamicStore;
