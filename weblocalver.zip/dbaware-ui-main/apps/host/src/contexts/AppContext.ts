import { createContext } from 'react';

export interface ContextType {
  /** Whether IDaaS auth is enabled for the current origin. */
  idaasEnabled: boolean;
  /** True while the IDaaS session is being initialized. */
  isLoadingSession: boolean;
  /** True when a valid rctoken is available (or when IDaaS is disabled). */
  hasRcToken: boolean;
  /** The current x-asm-rctoken value, if any. */
  rctoken: string | null;
  setRctoken: (token: string | null) => void;
}

export const AppContext = createContext<ContextType | undefined>(undefined);
