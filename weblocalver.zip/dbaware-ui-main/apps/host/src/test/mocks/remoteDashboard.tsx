import React from 'react';

const RemoteDashboardMock = () => <div data-testid="remote-dashboard">Mocked Dashboard</div>;

export default RemoteDashboardMock;