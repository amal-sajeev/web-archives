import React, { useState, useEffect } from 'react';
import { fetchRcToken, isIdaasEnabled, setRcToken } from '../auth/idaas';
import { AppContext, type ContextType } from '../contexts/AppContext';

/**
 * Propagates the rctoken to every federated remote that shares the global
 * `window.__dbaware` API client, regardless of which remote loaded first.
 */
const applyApiClientToken = (token: string | null): void => {
  setRcToken(token);
  if (typeof window !== 'undefined') {
    (window as any).__dbawareRcToken = token;
    (window as any).__dbaware?.setApiClientToken?.(token);
  }
};

export const AppProvider = ({ children }: { children: any }) => {
  const idaasEnabled = isIdaasEnabled();
  const [isLoadingSession, setIsLoadingSession] = useState(idaasEnabled);
  const [hasRcToken, setHasRcToken] = useState(!idaasEnabled);
  const [rctoken, setRctoken] = useState(null);

  useEffect(() => {
    if (!idaasEnabled) {
      return;
    }

    const initializeApp = async () => {
      setIsLoadingSession(true);
      try {
        // Step 1: Attempt to get the rctoken. An error here is caught but won't stop execution.
        try {
          console.log('[AppProvider] Fetching x-asm-rctoken...');
          const fetchedToken = await fetchRcToken();
          console.log("fetchedToken", fetchedToken)
          if (fetchedToken) {
            console.log('[AppProvider] Successfully fetched x-asm-rctoken. Setting in context and apiClient.');
            setRctoken(fetchedToken);
            applyApiClientToken(fetchedToken);
            setHasRcToken(true);
          } else {
            console.warn('[AppProvider] Could not find x-asm-rctoken in response headers.');
            setRctoken(null);
            applyApiClientToken(null);
            setHasRcToken(false);
          }
        } catch (error) {
          console.error('[AppProvider] Failed to fetch rctoken:', error);
          setRctoken(null);
          applyApiClientToken(null);
          setHasRcToken(false);
        }
      } finally {
        // Step 2: ALWAYS set loading to false to unblock the UI.
        console.log('[AppProvider] Initialization complete. Setting isLoading to false.');
        setIsLoadingSession(false);
      }
    };

    initializeApp();
  }, [idaasEnabled]); // This effect should only run once on mount

  const value: ContextType = {
    idaasEnabled,
    isLoadingSession,
    hasRcToken,
    rctoken,
    setRctoken,
  };

  if (isLoadingSession) {
    return <div style={{ padding: '20px' }}>Loading Session...</div>;
  }

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};
