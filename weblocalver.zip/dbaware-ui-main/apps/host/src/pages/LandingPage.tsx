import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './LandingPage.module.css';
import { getTaskStatus, startScoping } from '../api/scopingClient';

export interface AuditPlan {
  id: string;
  name: string;
  description: string;
  active: boolean;
}

export interface AuditApiResponse {
  planYear: number;
  data: AuditPlan[];
  count: number;
}

const TASK_DEFINITION_TO_ROUTE: Record<string, string> = {
  NOIR: 'noir',
  PRELIMINARY_RESEARCH: 'preliminary-research',
  DISCOVERY_WALKTHROUGH: 'discovery-walkthrough',
  DISCOVERY_WALKTHROUGH_AGENDA: 'discovery-walkthrough',
  SCOPE_RECOMMENDATION: 'scope-recommendation',
  TEST_STEPS: 'test-steps',
  FINAL_SCOPE_DOCUMENT: 'final-scope-document',
  NOR: 'nor',
};

const normalizeTaskDefinitionKey = (value: string | undefined): string =>
  (value ?? '')
    .trim()
    .replace(/[\s-]+/g, '_')
    .toUpperCase();

const PLAN_CATALOG = {
  "20440": {
    "name": "High-Frequency Trading (GBSA) Review",
    "description": "Deutsche Bank connects to the German venues (Eurex, Xetra and Eurex Repo) using leased lines and cross connects (a network cable connecting two networks together within a data centre.) that are limited to 1gigabit to prevent inadvertent contravention of the High Frequency Trading(HFT) requirements.  Deutsche Bank utilises specialist network monitoring devices from a third party vendor called Corvil. These devices analyse the data to determine its source and destination and hence allow us to ensure we have full transparency of our HFT activity.  \r\n\r\nThe scope of this review is to assess compliance with requirements of the Germany Banking Separation Act (GBSA) related to the prohibition of High Frequency Trading (HFT) for German venues, which have been implemented by DB via the Enterprise Compliance Program consisting of individual policies and procedures as well as the GBSA Compliance Manual. In addition CT&A plans to validate the implementation of the actions taken by the Issue/Action Owner as part of the closure of the F2 finding which was raised by BaFin in the external GBSA audit (refer GFMS ID 90-195/2023#2). ",
    "active": true,
  },
  "20521": {
    "description": "FRB Regulation D carries a significant inherent risk rating because CB and PB offer a range of deposit products. Reg D is due for coverage and remains an important area of focus for the bank's regulators.",
    "name": "2026 FRB Regulation D",
    "active": true,
  },
  "20583": {
    "name": "Suitability and Appropriateness Review - Global - CB",
    "description": "Primary driver is the  Risk Type  rated as \"Significant\" globally and \"Critical\" specifically in UK and Americas. While parts of S&A risk type gets covered in  various reviews and based on AU/RT combination apart from UK and Americas are due only in 2026, we are accelerating coverage in 2025 globally given that a dedicated S&A review was last conducted in 2020. \r\n\r\nThe main objective for this review will be validating that the business lines in scope are selling the right products to its clients, matching the level of complexity of these products with the level of sophistication of its clients. After the implementation of MIFID II regulations, Suitability and Appropriateness (S&A) has become one of the key risks for the finance industry. There is an increased focus from Regulators globally and consequences of not complying can lead to regulatory fines in addition to reputational and legal risks.\r\n\r\nThis is particularly relevant in relation to the GFX product suite which includes Products which are deemed complex.\r\n\r\nESG is also increasingly a potential risk for S&A as consideration to be given to the sustainable products and services to match the client objectives and sustainability preferences and the need to consider sustainability factors.  While there may not be specific rules and regulations across all countries at present, CT&A will consider this risk in further detail during the scoping stage. \r\n\r\nCT&A will review the Design and Operating Effectiveness of the framework and a number of key controls as part of its 2025 Compliance Testing Plan.",
    "active": true,
  },
  "20090": {
    "name": "2025 Swap Dealer (CFTC)",
    "description": "The US CT team is required to conduct an annual review of the Firm's Swap Dealer programs (CFTC ) to help support compliance with Title VII of the Dodd-Frank Act. However, the specific risk categories that will be covered during the review will not be known until planning for the review has commenced. The Compliance Risk Assessment will be used to help determine risk categories.",
    "active": true,
  },
  "20588": {
    "name": "2025 Swap Dealer (CFTC)",
    "description": "The US CT team is required to conduct an annual review of the Firm's Swap Dealer programs (CFTC & SBS) to help support compliance with Title VII of the Dodd-Frank Act. However, the specific risk categories that will be covered during the review will not be known until planning for the review has commenced. The Compliance Risk Assessment will be used to help determine risk categories.",
    "active": true,
  },
  "20587": {
    "name": "2026 Swap Dealer (CFTC)",
    "description": "US Mandatory review: The US CT team is required to conduct an annual review of the Firm's Swap Dealer programs (CFTC & SBS) to help support compliance with Title VII of the Dodd-Frank Act. However, the specific risk categories that will be covered during the review will not be known until planning for the review has commenced. The Compliance Risk Assessment will be used to help determine risk categories.",
    "active": true,
  },
  "20592": {
    "name": "Remote Location Testing - Philippines - CB/IB",
    "description": "In conjunction with Compliance, an annual testing plan will be devised to test areas of Compliance Risks management, especially in accordance with BSP Manual of Regulation for Banks and DB Group Policies and Procedures",
    "active": true,
  },
  "20593": {
    "name": "Remote Location Testing - Philippines - CB/IB",
    "description": "This is an annual mandatary review of Philippines’ compliance risks management in accordance with ‘BSP Manual of Regulation for Banks (MORB) Section 161 – Compliance Framework’ which states that \r\n\r\n• The Compliance function shall facilitate effective management of compliance risk by monitoring and testing compliance by performing sufficient and representative compliance testing.\r\n• The Compliance program shall set out the planned activities of the compliance function, such as…compliance testing…; and reporting to the board of directors or board-level committee. \r\n• The Compliance program shall espouse a risk-based approach and shall have appropriate coverage across businesses and units. For this purpose, the compliance program shall be updated on a regular basis or at least annually.\r\n\r\nHence, in conjunction with local Compliance, CT&A will undertake a risk-based testing of DB Manila's management of Compliance risks against BSP regulations and DB policies and procedures.",
    "active": true,
  },
  "20453": {
    "name": "2026 Swap Dealer (CFTC & SBS)",
    "description": "US Mandatory review: The US CT team is required to conduct an annual review of the Firm's Swap Dealer programs (CFTC & SBS) to help support compliance with Title VII of the Dodd-Frank Act. However, the specific risk categories that will be covered during the review will not be known until planning for the review has commenced. The Compliance Risk Assessment will be used to help determine risk categories.",
    "active": true,
  },
  "20447": {
    "name": "Market Access Rule 15c3-5 Review",
    "description": "The US CT&A team is required to conduct an annual review of Market Access requirement to help support the CEO attestation, in accordance with SEC Rule 15c3-5. This is a review of the Deutsche Bank Securities Inc. (DBSI) control framework related to Rule 15c3-5 under the Securities and Exchange Act of 1934 (The Market Access Rule).",
    "active": true,
  },
  "20538": {
    "name": "Regulation K Compliance Review",
    "description": "CT continues to conduct this review annually, given the regulatory scrutiny by FRB over compliance with Regulation K.",
    "active": true,
  },
  "20742": {
    "name": "Volcker ECP Trading Desk Review",
    "description": "As the independent testing pillar of the Firm’s Volcker ECP, CT&A CT is responsible for conducting reviews of selected trading desks to assess compliance with Volcker regulatory requirements. Additionally, CT&A CT is committed to assessing the design and/or operating effectiveness of the Firm’s Key Controls. Accordingly, CT&A will review relevant Volcker and GBSA Deutsche Bank Control Inventory (dbCI) key controls.",
    "active": true,
  },
  "20741": {
    "name": "Representative Office Compliance Review",
    "description": "Operating effectiveness testing of controls in place to ensure the Firm’s compliance with applicable rules and regulations including 3 NYCRR SP G 8.4. Scope includes overall governance and oversight; registration/licensing; maintenance and tracking processes and controls across Bank Rep Offices (LEAP, AMinet, and the Office of the Secretary); and relevant policies and procedures outlining permitted activities under licensing/registration for the Bank Rep Office.",
    "active": true,
  },
  "20377": {
    "name": "Concentration Accounts SoM Validation",
    "description": "CT&A has validated the design and evidence of updates to the Scope of Monitoring coverage for concentration accounts in 2025. This test focuses on the completion of the full 2025 SoM cycle to validate sustained operating effectiveness. Concentration accounts represent a risk factor under the BSA/AML program and FFIEC BSA/AML and LRR Patriot Act 325 cyclical coverage.",
    "active": true,
  },
  "20456": {
    "name": "AFC Internal Incidents Finding Validation",
    "description": "Validation of a significant finding that was identified in 2025 (Internal Incidents – 2025 AFC Testing finding 92-082/2025#1).",
    "active": true,
  },
  "20436": {
    "name": "RMS DACH Suitability & Appropriateness Review",
    "description": "The scope and main objective of the review is to assess the design and operating effectiveness of the processes and controls in RMS DACH for the distribution of investment products. Areas include key controls IRC-CD-1000222 (Pre-Trade Check Appropriateness & Suitability), IRC-CD-1000223 (Pre-Trade Escalation - Designated Client Type), and IRC-CD-1001091 (Post Trade Suitability Review).",
    "active": true,
  },
  "20527": {
    "name": "Pakistan Remote Location Review",
    "description": "The primary driver for this review is the cyclical coverage requirement for onsite visits to Tier 3 countries, which mandates a minimum frequency of once every four years. The last stand-alone CT Review for Pakistan was conducted in 2022.\r\n\r\nThe scope will targeted, focusing on areas that require local testing. The review will encompass all local Business Units.\r\n\r\nThis Review will be performed as a country inspection in line with CT's Remote Location Testing guidelines and cover i.a.:\r\nRisk types due in 2026 as per the UoT:\r\n- Communications with Clients/Public & Marketing Materials\r\n- Employee Licensing\r\n- Regulatory Disclosures\r\n- Handling of Customer Complaints\r\n\r\nIn addition, relevant elements from the Remote Location Testing (RLT) guidelines will be considered as appropriate:\r\nE.g.\r\n- Regulatory engagement & interaction\r\n- Compliance Function\r\nThis Review will also consider areas related to FX Currency Restrictions.\r\nDue to the size of the franchise, CT&A cannot cover all Compliance risk types in a single review and other due RTs will be included in global thematic reviews.\r\nWith the exception of Internal Fraud (which presents itself via Compliance RTs), this Remote Location Review will exclude AFC risk types, as these will be addressed separately during a local Affiliates Risk Management (ARM) Review, scheduled for 2026, which will coincide with a combined CT and AFCT onsite visit for efficiency reasons.",
    "active": true,
  },
  "20429": {
    "name": "Branch Review Corporate Bank Germany (Region West)",
    "description": "In accordance with BT 1.2.1.2 No. 2 MaComp,the Compliance function is required to conduct own on-site branch inspections in order to review and assess the internally established policies, procedures and controls in connection with the provision of securities services. For this purpose, employee interviews are conducted as part of the branch inspections as well as additional sample-based testing activities. \r\n\r\nThe branch inspection covers the Corporate Bank (CB) in the selected Region with the business units Risk Management Solutions Commercial Clients DACH (RMS CC DACH), Mid Corps Coverage of the Postbank and Deutsche Bank brand, and Biz Banking DB. The review focuses in RMS CC DACH on WpHG-relevant sales and advisory services for interest rate and fx products (Distribution of OTC Derivatives). \r\n\r\nIn Mid Corps Coverage, the review focuses on the identification and management of conflicts of interest for the Postbank brand and the origination of consumer loans for the Deutsche Bank brand. Consumer loan origination is also reviewed for BizBanking DB.",
    "active": true,
  },
  "20671": {
    "name": "Numis integration within the Compliance controls and processes Review",
    "description": "Numis, a leading UK focused Investment Bank (IB) founded in 1989, was aquired by DB in 2023 to strenthen its position in UK investment banking and accelerate its global Hausbank strategy. The acquisition allows DB to offer comprehensive financial advisory solutions to a broader client base, enhancing its corporate finance capabilities and deepening engagement with UK corporates. Given the following areas have been integrated previously into DB C&AFC processes, they will inform testing to confirm integration was effective and operating:\r\n\r\n•\tBSCO processes assimilated into DB’s \r\n•\tControl Room processes assimilated into DB’s\r\n•\tPRG (aggregation of positions and Takeover Panel reporting) in place\r\n•\tPAD, PIT, OBI under DB policy/procedural requirements applied to Numis employees\r\n•\tDB Code of Conduct became effective for Numis employees\r\n•\tSuite of DB Compliance Mandatory Training modules operative\r\n•\tSurveillance migrated onto DB platforms, standards and resourcing \r\n•\tNumis integrated within the DB Compliance Risk Assessment processes",
    "active": true,
  }
}

export default function LandingPage() {
  const [audits, setAudits] = useState([] as AuditPlan[]);
  const [loading, setLoading] = useState(true as boolean);
  const [error, setError] = useState(null as string | null);
  const [resumeError, setResumeError] = useState(null as string | null);
  const [resumingAuditId, setResumingAuditId] = useState(null as string | null);
  const [expandedDescriptions, setExpandedDescriptions] = useState({} as Record<string, boolean>);
  const navigate = useNavigate();

  useEffect(() => {
    document.title = "dbAware Plan List";

    const fetchAudits = async () => {
      try {
        // const response = await fetch(
        //   'http://ai-analytics-api-dk2791-a.apps.deonpd1a.dev.fabric.intranet.db.com/aiapi/audit/GetInfoAllAudits?planYear=2025'
        // );

        // if (!response.ok) {
        //   throw new Error(`HTTP error! status: ${response.status}`);
        //// }

        // const result = (await response.json()) as AuditApiResponse;
        const formattedAudits = Object.entries(PLAN_CATALOG).map(([id, details]) => ({
          id,
          ...details,
        }));
        setAudits(formattedAudits);
      } catch (err: unknown) {
        if (err instanceof Error) {
          setError(err.message);
        } else {
          setError('An unknown error occurred while fetching audit plans.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchAudits();
  }, []);

  const handleResume = async (auditId: string) => {
    setResumeError(null);
    setResumingAuditId(auditId);

    try {
      await startScoping(auditId, true);
      const taskStatus = await getTaskStatus(auditId);
      const normalizedTaskKey = normalizeTaskDefinitionKey(taskStatus.taskDefinitionKey);
      console.log(`Resuming audit ${auditId} with task definition key: ${normalizedTaskKey}`);
      const targetRoute = TASK_DEFINITION_TO_ROUTE[normalizedTaskKey] ?? 'noir';
      navigate(`/${targetRoute}/${auditId}`);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setResumeError(err.message);
      } else {
        setResumeError('Failed to start scoping. Please try again.');
      }
    } finally {
      setResumingAuditId(null);
    }
  };

  const toggleDescription = (auditId: string) => {
    setExpandedDescriptions((prev) => ({
      ...prev,
      [auditId]: !prev[auditId],
    }));
  };

  return (
    <div className={styles.pageContainer}>
      <header className={styles.header}>
        <h1 className={styles.headerTitle}>dbAware</h1>
      </header>

      <main className={styles.mainContent}>
        <h2 className={styles.pageTitle}>Plan List</h2>

        {loading ? (
          <div className={styles.statusState}>Loading audit plans...</div>
        ) : error ? (
          <div className={styles.statusState}>Error loading plans: {error}</div>
        ) : (
          <div className={styles.auditList}>
            {resumeError && <div className={styles.statusState}>Error starting scoping: {resumeError}</div>}
            {audits.map((audit) => (
              <React.Fragment key={audit.id}>
                <div className={styles.auditCard}>
                  <div>
                    <h3 className={styles.auditTitle}>
                      <span className={styles.highlightedId}>{audit.id}</span> &mdash; {audit.name}
                    </h3>
                    {audit.description && (
                      <>
                        <p
                          className={`${styles.auditDescription} ${expandedDescriptions[audit.id] ? styles.auditDescriptionExpanded : styles.auditDescriptionCollapsed}`}
                        >
                          {audit.description}
                        </p>
                        <button
                          type="button"
                          className={styles.viewMoreButton}
                          onClick={() => toggleDescription(audit.id)}
                        >
                          {expandedDescriptions[audit.id] ? 'View less' : 'View more'}
                        </button>
                      </>
                    )}
                    <div className={styles.auditDetails}>
                    </div>
                  </div>
                  <button
                    onClick={() => handleResume(audit.id)}
                    className={styles.resumeButton}
                    disabled={resumingAuditId === audit.id}
                  >
                    {resumingAuditId === audit.id ? 'Starting...' : 'Resume'}
                  </button>
                </div>
              </React.Fragment>
            ))}
            {audits.length === 0 && <div className={styles.statusState}>No audit plans found for this year.</div>}
          </div>
        )}
      </main>

      <footer className={styles.footer}>
        <p>&copy; {new Date().getFullYear()} dbAware. All rights reserved.</p>
      </footer>
    </div>
  );
}
