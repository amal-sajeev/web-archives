import React from 'react';

const NotAuthorizedPage = () => {
  return (
    <div style={{ padding: '24px', maxWidth: '600px', margin: '40px auto', textAlign: 'center' }}>
      <h2 style={{ marginBottom: '12px' }}>Not Authorized</h2>
      <p style={{ margin: 0 }}>
        You do not have permission to access this application.
      </p>
    </div>
  );
};

export default NotAuthorizedPage;
