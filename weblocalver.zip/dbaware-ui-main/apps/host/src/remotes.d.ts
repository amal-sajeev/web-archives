// Explicit module declarations for Micro-Frontends
declare module 'remote_dashboard/Dashboard' {
  const Dashboard: React.ComponentType;
  export default Dashboard;
}

declare module 'remote_dashboard/DocumentViewer' {
  const DocumentViewer: React.ComponentType;
  export default DocumentViewer;
}

declare module 'remote_header/Header' {
  interface HeaderProps {
    selectedLrId?: string;
    onTabClose?: () => void;
  }
  const Header: React.ComponentType<HeaderProps>;
  export default Header;
}

declare module 'remote_leftSidebar/LeftSidebar' {
  const LeftSidebar: React.ComponentType;
  export default LeftSidebar;
}

declare module 'remote_RightSidebar/RightSidebar' {
  const RightSidebar: React.ComponentType;
  export default RightSidebar;
}
