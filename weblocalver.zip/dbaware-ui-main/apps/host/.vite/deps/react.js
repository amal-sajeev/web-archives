import {
  require_react
} from "./chunk-66W55LCL.js";
import "./chunk-EQCVQC35.js";
export default require_react();
//# sourceMappingURL=react.js.map
