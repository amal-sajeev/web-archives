import React, { useState, useEffect, useMemo } from 'react';
import { getAuditLogs, formatGmt, AuditLogItem } from './auditApi';
import { SidePanel, SidePanelTab } from 'com.db.rca.commons.afcc-components';
import './RightSidebar.css';

const getItemExecutionEndTime = (item: AuditLogItem): string => {
  return String(item.payload?.Execution_End_Time || item.timestamp || '').trim();
};

const getItemPerformedBy = (item: AuditLogItem): string => {
  const raw = String(
    item.performedBy
    || item.payload?.performedBy
    || item.payload?.Performed_By
    || item.payload?.performed_by
    || ''
  ).trim();

  if (!raw) {
    return '';
  }

  const parts = raw.split(':');
  return parts.length > 1 ? parts.slice(1).join(':').trim() : raw;
};

const normalizeText = (value: string): string => {
  return String(value || '').replace(/\s+/g, ' ').trim().toLowerCase();
};

const RightSidebar: React.FC = () => {
  const pageSize = 20;
  const [expanded, setExpanded] = useState(false);
  const [items, setItems] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [sortOrder, setSortOrder] = useState<'' | 'asc' | 'desc'>('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  const handleToggle = (nextExpanded: boolean) => {
    if (nextExpanded) {
      setPage(1);
    }
    setExpanded(nextExpanded);
  };

  useEffect(() => {
    const handleTabSwitch = () => {
      setExpanded(false);
      setPage(1);
    };

    window.addEventListener('scoping:tab-switch', handleTabSwitch as EventListener);

    return () => {
      window.removeEventListener('scoping:tab-switch', handleTabSwitch as EventListener);
    };
  }, []);

  useEffect(() => {
    if (!expanded) return;
    const segments = window.location.pathname.split('/').filter(Boolean);
    const planId = segments.find((s) => /^\d+$/.test(s)) || '';
    const known = ['noir', 'nor', 'preliminary-research'];
    const tab = segments.map((s) => s.toLowerCase().replace(/_/g, '-')).find((s) => known.includes(s)) || 'noir';
    let cancelled = false;
    setLoading(true); getAuditLogs(planId, tab, page, pageSize, sortOrder || 'asc')
      .then((res) => {
        if (!cancelled) {
          setItems(res.items || []);
          setTotal(typeof res.total === 'number' ? res.total : 0);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setItems([]);
          setTotal(0);
        }
      })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [expanded, sortOrder, page, pageSize]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const visibleItems = useMemo(() => {
    const seen = new Set<string>();

    return items.filter((item) => {
      const description = String(item.description || '').trim();
      const humanNotes = String(item?.payload?.Human_Notes || '').trim();
      const performedBy = getItemPerformedBy(item);
      const timestamp = String(item.timestamp || '').trim();
      const executionEndTime = getItemExecutionEndTime(item);
      const renderedDate = timestamp
        ? formatGmt(timestamp)
        : (executionEndTime ? formatGmt(executionEndTime) : '-');
      const signature = [
        normalizeText(description),
        normalizeText(humanNotes),
        normalizeText(performedBy),
        normalizeText(renderedDate),
      ].join('||');

      if (seen.has(signature)) {
        return false;
      }

      seen.add(signature);
      return true;
    });
  }, [items]);

  return (
    <SidePanel
      position="right"
      expanded={expanded}
      onToggle={handleToggle}
      toggleTitle="Toggle Right Sidebar"
      contentWidth="385px"
      style={{ height: '90vh', ['--wadk-side-panel-width' as any]: '385px' }}
    >
      <SidePanelTab
        title="History"
        icon={
          <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
            <path d="M10.5 0C16.299 0 21 4.70101 21 10.5C21 16.299 16.299 21 10.5 21C5.74364 21 1.7275 17.837 0.436523 13.5H2.01465C3.25038 16.9952 6.58164 19.5 10.5 19.5C15.4706 19.5 19.5 15.4706 19.5 10.5C19.5 5.52944 15.4706 1.5 10.5 1.5C7.16926 1.5 4.26336 3.31061 2.70703 6H6V7.5H0V1.5H1.5V5.09082C3.33718 2.04088 6.67999 0 10.5 0ZM10.5 10.1387L14.5547 13.3828L13.6172 14.5547L9.28125 11.0859L9 10.8604V4.5H10.5V10.1387Z" fill="currentColor" />
          </svg>
        }
      />
      {/* <SidePanelTab
        title="Notifications"
        icon={
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
        }
      />
      <SidePanelTab
        title="Messages"
        icon={
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
        }      /> */}      <div style={{ overflowY: 'auto', height: '100%' }}>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
          <select
            aria-label="Sort audit logs"
            value={sortOrder} onChange={(e) => {
              setSortOrder(e.target.value as 'asc' | 'desc');
              setPage(1);
            }}
            style={{ fontSize: 12, padding: '4px 8px', width: 150, border: '1px solid var(--wadk-stroke-basic-base, #e5e7eb)', borderRadius: 4, background: 'var(--wadk-fill-basic-blank, #fff)' }}
          >
            <option value="" disabled hidden>Sort By</option>
            <option value="desc">Oldest</option>
            <option value="asc">Latest</option>
          </select>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, gap: 8 }}>
          <div style={{ fontSize: 12, color: 'var(--wadk-text-basic-light, #6b7280)' }}>
            Page {page} of {totalPages}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {/* <select
              aria-label="Page size"
              value={pageSize}
              onChange={(e) => {
                const nextSize = Number(e.target.value);
                setPageSize(nextSize);
                setPage(1);
              }}
              style={{ fontSize: 12, padding: '4px 8px', width: 90, border: '1px solid var(--wadk-stroke-basic-base, #e5e7eb)', borderRadius: 4, background: 'var(--wadk-fill-basic-blank, #fff)' }}
            >
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
            </select> */}
            <button
              type="button"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={loading || page <= 1}
              style={{ fontSize: 12, padding: '4px 8px', border: '1px solid var(--wadk-stroke-basic-base, #e5e7eb)', borderRadius: 4, background: 'var(--wadk-fill-basic-blank, #fff)', cursor: 'pointer' }}
            >
              Prev
            </button>
            <button
              type="button"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={loading || page >= totalPages}
              style={{ fontSize: 12, padding: '4px 8px', border: '1px solid var(--wadk-stroke-basic-base, #e5e7eb)', borderRadius: 4, background: 'var(--wadk-fill-basic-blank, #fff)', cursor: 'pointer' }}
            >
              Next
            </button>
          </div>
        </div>

        {loading && <p>Loading...</p>}
        {!loading && visibleItems.length === 0 && <p>No audit history available.</p>}
        <div className='step_container'>
        {visibleItems.map((item, index) => {
          const executionEndTime = getItemExecutionEndTime(item);
          const performedBy = getItemPerformedBy(item);
          const timestamp = String(item.timestamp || '').trim();
          const renderedDate = timestamp ? formatGmt(timestamp) : (executionEndTime ? formatGmt(executionEndTime) : '-');
          const description = String(item.description || '-');
          return (
            <div key={item.id || `${item.actionType || 'item'}-${index}`} className="history-item-card">
              {/* <div style={{ color: '#6b7280', marginBottom: 4 }}>Item</div> */}
              {/* <div style={{ marginBottom: 4, fontWeight: 600 }}>{item.activityType || item.actionType || item.entityType || 'Audit item'}</div> */}
              <div
                className="history-item-description ellipsis-text"
                title={description !== '-' ? description : undefined}
              >
                {description}
              </div>
              <div className="history-item-meta-grid">
                <div className="history-item-meta-cell">
                  <span className="history-item-meta-label">Date:</span>
                  <span className="ellipsis-text" title={renderedDate !== '-' ? renderedDate : undefined}> {renderedDate}</span>
                </div>
                <div className="history-item-meta-cell">
                  <span className="history-item-meta-label">By:</span>
                  <span className="ellipsis-text" title={performedBy ? performedBy : undefined}> {performedBy || '-'}</span>
                </div>
              </div>
            </div>
          );
        })}
        </div>
      </div>
    </SidePanel>
  );
};

export default RightSidebar;