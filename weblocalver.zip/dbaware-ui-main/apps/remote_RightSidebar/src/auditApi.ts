export interface AuditStep {
  stepNumber: number;
  stepName: string;
  status: string;
  title: string;
  summary: string;
  updatedAt: string | null;
}

export interface AuditLogItem {
  id: string;
  entityType?: string;
  actionType?: string;
  activityType?: string;
  description?: string;
  performedBy?: string;
  timestamp?: string;
  payload?: {
    Execution_End_Time?: string;
    [key: string]: any;
  };
}

export interface AuditLogResponse {
  planId: string;
  page: number;
  pageSize: number;
  sort: 'asc' | 'desc';
  total: number;
  steps: AuditStep[];
  items: AuditLogItem[];
}

const fetchAuditLogsPage = async (
  planId: string,
  page: number,
  pageSize: number,
  sort: 'asc' | 'desc'
): Promise<AuditLogResponse> => {
  const query = new URLSearchParams({
    sort,
    page: String(page),
    pageSize: String(pageSize),
  });

  const response = await fetch(
    `/dbaware-action-service/api/actions/${encodeURIComponent(planId)}/audit-logs?${query.toString()}`,
    {
      method: 'GET',
      credentials: 'include',
    }
  );

  if (!response.ok) {
    throw new Error(`Failed to fetch audit logs: ${response.status}`);
  }

  const data = await response.json();
  return {
    planId: String(data?.planId || planId || ''),
    page: Number(data?.page || page),
    pageSize: Number(data?.pageSize || pageSize),
    sort: (data?.sort === 'asc' ? 'asc' : 'desc'),
    total: Number(data?.total || 0),
    steps: Array.isArray(data?.steps) ? data.steps : [],
    items: Array.isArray(data?.items) ? data.items : [],
  };
};

export const getAuditLogs = async (
  planId: string,
  _tab: string,
  page = 1,
  pageSize = 100,
  sort: 'asc' | 'desc' = 'asc'
): Promise<AuditLogResponse> => {
  return fetchAuditLogsPage(planId, page, pageSize, sort);
};

export const formatGmt = (iso: string): string => {
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, '0');
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getUTCMonth()];
  return `${p(d.getUTCDate())}-${m}-${d.getUTCFullYear()} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())} GMT`;
};
