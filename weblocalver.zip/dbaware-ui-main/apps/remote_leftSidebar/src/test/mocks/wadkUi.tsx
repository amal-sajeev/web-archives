import React from 'react';

const createBlock = (tagName: keyof JSX.IntrinsicElements) => {
  return ({ children, content, outlined, radius, raise, ...props }: any) =>
    React.createElement(tagName, props, content ?? children);
};

const createButton = () => {
  return ({ children, icon, onClick, disabled, className, variant, size, ...props }: any) =>
    React.createElement(
      'button',
      { type: 'button', onClick, disabled, className, ...props },
      icon,
      children
    );
};

const createInput = () => {
  return ({ value, onChange, placeholder, className, disabled, ...props }: any) =>
    React.createElement('input', {
      value,
      onChange,
      placeholder,
      className,
      disabled,
      ...props,
    });
};

export const Box = createBlock('div');
export const Button = createButton();
export const Card = createBlock('div');
export const CardHeader = createBlock('div');
export const CardTitle = ({ content, children }: any) =>
  React.createElement('h1', null, content ?? children);
export const DropdownInput = createInput();
export const FileUpload = createBlock('div');
export const FormInput = createInput();
export const LeftSlot = createBlock('div');
export const ModalDialog = createBlock('div');
export const OutlineButton = createButton();
export const RightSlot = createBlock('div');
export const Spinner = createBlock('div');
export const Stack = createBlock('div');
export const StatusLabel = ({ children, content, className, appearance, size, variant, ...props }: any) =>
  React.createElement('span', { className, ...props }, content ?? children);
export const Table = createBlock('div');
export const Text = createBlock('span');
export const TextInput = createInput();
