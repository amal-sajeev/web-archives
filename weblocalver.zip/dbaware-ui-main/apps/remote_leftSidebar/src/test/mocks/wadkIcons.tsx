import React from 'react';

const createIcon = (name: string) => {
  return (props: any) =>
    React.createElement('svg', { 'data-testid': `icon-${name}`, ...props });
};

export const AiLogoSolid = createIcon('AiLogoSolid');
export const AttachSolid = createIcon('AttachSolid');
export const CheckmarkCircleOutline = createIcon('CheckmarkCircleOutline');
export const CheckmarkSolid = createIcon('CheckmarkSolid');
export const ContextHelpOutline = createIcon('ContextHelpOutline');
export const CrosshairOutline = createIcon('CrosshairOutline');
export const DocumentAddSolid = createIcon('DocumentAddSolid');
export const DocumentOutline = createIcon('DocumentOutline');
export const LinkSolid = createIcon('LinkSolid');
export const PaperPlaneOutline = createIcon('PaperPlaneOutline');
export const PlusSolid = createIcon('PlusSolid');
export const SingleChevronDownSolid = createIcon('SingleChevronDownSolid');
export const SingleChevronUpSolid = createIcon('SingleChevronUpSolid');
export const TrashOutline = createIcon('TrashOutline');
export const XSolid = createIcon('XSolid');
