import React from 'react';

export const AiInputPanelContent = ({ children, actions, onButtonClick, className }: any) =>
  React.createElement(
    'div',
    { 'data-testid': 'mock-input-panel', className },
    actions ? React.createElement('div', { 'data-testid': 'mock-actions' }, actions) : null,
    children,
    React.createElement(
      'button',
      { type: 'button', onClick: onButtonClick, 'data-testid': 'send-btn' },
      'Send'
    )
  );

export const AiInputPanelTextarea = ({
  value,
  onChange,
  onKeyDown,
  placeholder,
  disabled,
}: any) =>
  React.createElement('textarea', {
    'data-testid': 'mock-textarea',
    value,
    onChange,
    onKeyDown,
    placeholder,
    disabled,
  });

export const AiQuestion = ({ children, className }: any) =>
  React.createElement('div', { 'data-testid': 'mock-ai-question', className }, children);

export const AiResponse = ({ children, className, style }: any) =>
  React.createElement(
    'div',
    { 'data-testid': 'mock-ai-response', className, style },
    children ?? 'Generating response...'
  );

export const AiQuestions = ({ children, header, className }: any) =>
  React.createElement(
    'div',
    { 'data-testid': 'mock-ai-questions', className },
    header,
    children
  );

export const AiQuestionsPrompt = ({ children, onClick, disabled }: any) =>
  React.createElement(
    'button',
    {
      type: 'button',
      onClick,
      disabled,
      'data-disabled': disabled ? 'true' : 'false',
    },
    children
  );

export const AutoLoadingProgress = () =>
  React.createElement('div', { 'data-testid': 'mock-auto-loading-progress' });

export const LoadingProgress = () =>
  React.createElement('div', { 'data-testid': 'mock-loading-progress' }, 'Loading...');

export const DraggableDialog = ({ children, actions, title }: any) =>
  React.createElement('div', { 'data-testid': 'mock-draggable-dialog' }, title, children, actions);

export const FileUploadList = () => React.createElement('div', { 'data-testid': 'mock-file-upload-list' });

export const ScreenReaderOnly = ({ children }: any) => React.createElement('span', null, children);

export const KeyValuePair = ({ children }: any) => React.createElement('div', null, children);

export const KeyValuePairItem = ({ children, term }: any) =>
  React.createElement('div', null, term, children);
