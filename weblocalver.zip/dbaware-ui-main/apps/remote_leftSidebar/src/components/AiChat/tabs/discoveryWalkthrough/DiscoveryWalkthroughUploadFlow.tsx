import React from 'react';
import { UploadBeforeGenerationFlow, UploadBeforeGenerationConfig } from '../shared/UploadBeforeGenerationFlow';

const discoveryWalkthroughFlowConfig: UploadBeforeGenerationConfig = {
  generateButtonLabel: 'Generate Discovery Walkthrough',
  generateEventName: 'ai-chat:generate-discovery-walkthrough',
  generationLoadingMessageId: 'discovery-walkthrough-loading',
  generationLoadingTitle: 'Generating Discovery Walkthrough...',
};

export const DiscoveryWalkthroughUploadFlow: React.FC<{ messageId?: string }> = ({ messageId }) => (
  <UploadBeforeGenerationFlow messageId={messageId} config={discoveryWalkthroughFlowConfig} />
);
