import React from 'react';
import { UploadBeforeGenerationFlow, UploadBeforeGenerationConfig } from '../shared/UploadBeforeGenerationFlow';

const testStepsFlowConfig: UploadBeforeGenerationConfig = {
  generateButtonLabel: 'Generate Test Steps',
  generateEventName: 'ai-chat:generate-test-steps',
  generationLoadingMessageId: 'test-steps-loading',
  generationLoadingTitle: 'Generating Test Steps...',
  uploadApiPath: '/scoping-procedure-agent/upload-test-steps',
  useValidationStatusFlow: true,
};

export const TestStepsUploadFlow: React.FC<{ messageId?: string }> = ({ messageId }) => (
  <UploadBeforeGenerationFlow messageId={messageId} config={testStepsFlowConfig} />
);
