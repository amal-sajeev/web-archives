import React from 'react';
import { UploadBeforeGenerationFlow, UploadBeforeGenerationConfig } from '../shared/UploadBeforeGenerationFlow';

const scopeRecommendationFlowConfig: UploadBeforeGenerationConfig = {
  generateButtonLabel: 'Generate Scope Recommendation',
  generateEventName: 'ai-chat:generate-scope-recommendation',
  generationLoadingMessageId: 'scope-recommendation-loading',
  generationLoadingTitle: 'Generating Scope Recommendation...',
};

export const ScopeRecommendationUploadFlow: React.FC<{ messageId?: string }> = ({ messageId }) => (
  <UploadBeforeGenerationFlow messageId={messageId} config={scopeRecommendationFlowConfig} />
);