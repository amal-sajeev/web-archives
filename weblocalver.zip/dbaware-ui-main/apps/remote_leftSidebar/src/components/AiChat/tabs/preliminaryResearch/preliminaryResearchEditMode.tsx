import React, { useEffect, useMemo, useState } from 'react';
import SmartReferenceEditor, { SmartCategoryConfig, SmartFileItem } from '../../SmartReferenceEditor/SmartReferenceEditor';
import { fetchPreliminaryResearchDocumentGroups } from '../../../../api/preliminaryResearchClient';

interface PreliminaryResearchEditModeProps {
	badgeLabel: string;
	planNumber: string;
	disabled: boolean;
	onInputChange: (value: string) => void;
	onSend: (value?: string, attachments?: File[]) => void;
}

const PreliminaryResearchEditMode: React.FC<PreliminaryResearchEditModeProps> = ({
	badgeLabel,
	planNumber,
	disabled,
	onInputChange,
	onSend,
}) => {
	const FIXED_CATEGORIES: SmartCategoryConfig[] = useMemo(() => ([
		{ key: 'Policy', label: 'Policy, Procedure, KOD', files: [] },
		{ key: 'Historical', label: 'Historical Scoping Documents', files: [] },
		{ key: 'Other', label: 'Others (GFMS, ALC/NALC, content quality)', files: [] },
	]), []);

	const [categories, setCategories] = useState<SmartCategoryConfig[] | undefined>(FIXED_CATEGORIES);
	const [isCategoryDataLoading, setIsCategoryDataLoading] = useState(false);
	const [refreshToken, setRefreshToken] = useState(0);

	const normalizedPlanNumber = useMemo(() => String(planNumber || '').trim(), [planNumber]);

	useEffect(() => {
		const handleRefreshDocuments = (event: Event) => {
			const detail = (event as CustomEvent<{ planNumber?: string }>).detail || {};
			const targetPlan = String(detail.planNumber || '').trim();
			if (!targetPlan || targetPlan === normalizedPlanNumber) {
				setRefreshToken((prev) => prev + 1);
			}
		};

		window.addEventListener('prelim-research:refresh-documents', handleRefreshDocuments as EventListener);
		return () => window.removeEventListener('prelim-research:refresh-documents', handleRefreshDocuments as EventListener);
	}, [normalizedPlanNumber]);

	useEffect(() => {
		let disposed = false;

		if (!normalizedPlanNumber) {
			setCategories(FIXED_CATEGORIES);
			setIsCategoryDataLoading(false);
			return () => {
				disposed = true;
			};
		}

		const resolveCategoryKey = (documentType: string): SmartCategoryConfig['key'] => {
			const normalized = String(documentType || '').trim().toLowerCase();
			if (normalized === 'policy' || normalized === 'kod' || normalized === 'procedure') {
				return 'Policy';
			}
			if (normalized === 'historical_scoping_document') {
				return 'Historical';
			}
			return 'Other';
		};

		const load = async () => {
			setCategories(FIXED_CATEGORIES);
			setIsCategoryDataLoading(true);
			try {
				const groups = await fetchPreliminaryResearchDocumentGroups(normalizedPlanNumber);

				if (disposed) return;

				const categoryFiles: Record<string, SmartFileItem[]> = {
					Policy: [],
					Historical: [],
					Other: [],
				};

				groups.forEach((group) => {
					const sourceDocumentType = String(group.documentType || '').trim().toLowerCase();
					const categoryKey = resolveCategoryKey(group.documentType);
					group.documents.forEach((doc, docIndex) => {
						const docId = `doc-${categoryKey}-${doc.id || docIndex}`;
						categoryFiles[categoryKey].push({
							id: docId,
							name: doc.title,
							type: 'document',
							itemKind: 'document',
							sourceDocumentType,
							status: doc.status,
							excluded: doc.excluded,
							lastModified: new Date().toISOString().slice(0, 10),
							sizeKb: 1,
							documentId: doc.id,
						});

						doc.sections.forEach((section, sectionIndex) => {
							categoryFiles[categoryKey].push({
								id: `sec-${categoryKey}-${doc.id}-${section.id || sectionIndex}`,
								name: section.title,
								type: 'section',
								itemKind: 'section',
								sourceDocumentType,
								sectionId: section.sectionId,
								status: section.status,
								excluded: section.excluded,
								parentDocumentId: docId,
								nodeId: section.nodeId,
								lastModified: new Date().toISOString().slice(0, 10),
								sizeKb: 1,
								documentId: doc.id,
							});
						});
					});
				});

				setCategories([
					{ key: 'Policy', label: 'Policy, Procedure, KOD', files: categoryFiles.Policy },
					{ key: 'Historical', label: 'Historical Scoping Documents', files: categoryFiles.Historical },
					{ key: 'Other', label: 'Others (GFMS, ALC/NALC, content quality)', files: categoryFiles.Other },
				]);
			} catch {
				if (!disposed) {
					setCategories(FIXED_CATEGORIES);
				}
			} finally {
				if (!disposed) {
					setIsCategoryDataLoading(false);
				}
			}
		};

		load();

		return () => {
			disposed = true;
		};
	}, [FIXED_CATEGORIES, normalizedPlanNumber, refreshToken]);

	return (
		<SmartReferenceEditor
			key={normalizedPlanNumber || 'no-plan'}
			badgeLabel={badgeLabel}
			disabled={disabled}
			categories={categories}
			isCategoryDataLoading={isCategoryDataLoading}
			embedded
			showBadge={false}
			showContextPanel={false}
			openMenusUpward
			onValueChange={onInputChange}
			onSend={(value, attachments) => onSend(value, attachments)}
		/>
	);
};

export default PreliminaryResearchEditMode;
