import React, { useState } from 'react';
import { Button, Stack, Text, Table, StatusLabel, OutlineButton, Box, FileUpload } from '@wadk/ui';
import { DocumentOutline, CheckmarkSolid, TrashOutline } from '@wadk/icons';
import { postFormData } from '../../../../api/sharedApi';
import { DraggableDialog, FileUploadList, ScreenReaderOnly } from 'com.db.rca.commons.afcc-components';
import { useLocation, matchPath } from 'react-router-dom';
import { SequentialFadeList } from '../../Loader/SequentialFadeList';

const MOM_ALLOWED_FILE_TYPES_LABEL = '.txt, DOC, PDF';
const MOM_ALLOWED_FILE_TYPES_SHORT_LABEL = 'TXT, DOC, PDF';
const MOM_ALLOWED_FILE_TYPES_ACCEPT = '.txt,.doc,.docx,.pdf';

export interface UploadBeforeGenerationConfig {
  generateButtonLabel: string;
  generateEventName: string;
  generationLoadingMessageId: string;
  generationLoadingTitle: string;
  uploadApiPath?: string;
  useValidationStatusFlow?: boolean;
  buildUploadFields?: (args: { planId?: string; files: File[] }) => Record<string, string | Blob | Array<string | Blob>>;
}

interface UploadBeforeGenerationFlowProps {
  messageId?: string;
  config: UploadBeforeGenerationConfig;
}

interface UploadResponse {
  summary?: string;
  validation_results?: Array<{
    filename?: string;
    is_valid?: boolean;
  }>;
}

interface UploadedResult {
  files: File[];
  summary?: string;
  fileValidationByName?: Record<string, boolean>;
  validationFileNames?: string[];
}

const normalizeFileNameKey = (name: string): string => String(name || '').trim().toLowerCase();

const formatFileSize = (bytes: number) => {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  const kb = bytes / 1024;
  if (kb < 1024) {
    return `${kb.toFixed(kb < 10 ? 2 : 1)} KB`;
  }
  const mb = kb / 1024;
  return `${mb.toFixed(mb < 10 ? 2 : 1)} MB`;
};

const toFilesArray = (uploaded: unknown): File[] => {
  if (!uploaded) return [];

  if (uploaded instanceof File) {
    return [uploaded];
  }

  if (uploaded instanceof FileList) {
    return Array.from(uploaded);
  }

  if (Array.isArray(uploaded)) {
    return uploaded
      .map((item) => {
        if (item instanceof File) return item;
        const wrapped = (item as any)?.file;
        return wrapped instanceof File ? wrapped : null;
      })
      .filter((file): file is File => Boolean(file));
  }

  const uploadedObj = uploaded as any;
  if (uploadedObj?.files instanceof FileList) {
    return Array.from(uploadedObj.files);
  }

  if (Array.isArray(uploadedObj?.files)) {
    return uploadedObj.files.filter((f: unknown): f is File => f instanceof File);
  }

  if (uploadedObj?.file instanceof File) {
    return [uploadedObj.file];
  }

  return [];
};

const emitAddMessage = (
  sender: 'user' | 'ai',
  content: React.ReactNode,
  id?: string
) => {
  window.dispatchEvent(
    new CustomEvent('ai-chat:add-message', { detail: { id, sender, content } })
  );
};

const emitRemoveMessage = (id: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:remove-message', { detail: { id } }));
};

const triggerGeneration = (config: UploadBeforeGenerationConfig) => {
  window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
    detail: { sender: 'user', content: config.generateButtonLabel }
  }));

  window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
    detail: {
      id: config.generationLoadingMessageId,
      sender: 'ai',
      content: (
        <Stack gap="md" direction="column">
          <div style={{ fontWeight: 'bold' }}>{config.generationLoadingTitle}</div>
          <SequentialFadeList
            title="Looking into..."
            listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
            items={[
              'Reviewing regulatory obligations',
              'Analysing policies',
              'Comparing historical scope',
              'Reviewing open findings',
              'Mapping risks and controls',
              'Assessing evidence ',
              'Developing scope direction',
              'processing....'
            ]}
            intervalMs={40000}
          />
        </Stack>
      )
    }
  }));

  window.dispatchEvent(new CustomEvent(config.generateEventName));
};

const UploadDocumentDialog: React.FC<{
  planId?: string;
  onClose: () => void;
  onUploaded: (result: UploadedResult) => void;
  onCancelAll?: () => void;
  config: UploadBeforeGenerationConfig;
}> = ({ planId, onClose, onUploaded, onCancelAll, config }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'pending' | 'success' | 'error'>('pending');
  const [rejectMessage, setRejectMessage] = useState('');

  const handleUpload = async () => {
    if (files.length === 0) return;
    setIsUploading(true);
    setUploadStatus('pending');
    try {
      const fields = config.buildUploadFields
        ? config.buildUploadFields({ planId, files })
        : {
          planNumber: String(planId),
          files
        };

      const response = await postFormData<UploadResponse>(
        config.uploadApiPath ?? '/scoping-procedure-agent/generate-meeting-notes',
        fields
      );

      const fileValidationByName = Array.isArray(response?.validation_results)
        ? response.validation_results.reduce<Record<string, boolean>>((acc, item) => {
          const key = normalizeFileNameKey(String(item?.filename || ''));
          if (key) {
            acc[key] = item?.is_valid !== false;
          }
          return acc;
        }, {})
        : undefined;

      const validationFileNames = Array.isArray(response?.validation_results)
        ? response.validation_results
          .map((item) => String(item?.filename || '').trim())
          .filter(Boolean)
        : [];

      const filesByNormalizedName = files.reduce<Record<string, File>>((acc, file) => {
        const key = normalizeFileNameKey(file.name);
        if (key && !acc[key]) {
          acc[key] = file;
        }
        return acc;
      }, {});

      const filesFromValidation = validationFileNames
        .map((name) => filesByNormalizedName[normalizeFileNameKey(name)])
        .filter((file): file is File => Boolean(file));

      const filesToReturn = filesFromValidation.length > 0
        ? filesFromValidation
        : files;

      setUploadStatus('success');
      onUploaded({
        files: filesToReturn,
        summary: typeof response?.summary === 'string' && response.summary.trim().length > 0
          ? response.summary.trim()
          : undefined,
        fileValidationByName,
        validationFileNames,
      });
    } catch (err) {
      console.error('Upload failed:', err);
      setUploadStatus('error');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <DraggableDialog
      title="Upload Document"
      onClose={onClose}
      style={{ minWidth: '600px' }}
      actions={
        <div style={{ display: 'flex', gap: '16px', justifyContent: 'flex-end', width: '100%' }}>
          <OutlineButton onClick={() => (onCancelAll ? onCancelAll() : onClose())} variant="primary">Cancel</OutlineButton>
          <Button onClick={handleUpload} disabled={files.length === 0 || isUploading} variant="primary">
            {isUploading ? 'Uploading...' : 'Upload'}
          </Button>
        </div>
      }
    >
      <Box>
        <Stack gap="base">
          <FileUpload
            icon="upload"
            className="file-upload-component"
            inputTitle="Select file to upload or drag and drop it here"
            fileRestrictionsMessage="Up to 200MB per file. TXT, DOC, PDF only."
            accept={MOM_ALLOWED_FILE_TYPES_ACCEPT}
            onReject={(rejected: any[]) => {
              setRejectMessage(
                rejected.map((r) => `${r.name}: ${r.validationError}`).join(' | ')
              );
            }}
            onUpload={(uploaded: any) => {
              setRejectMessage('');
              const newFiles = toFilesArray(uploaded);
              if (newFiles.length > 0) {
                setFiles((prev) => [
                  ...prev,
                  ...newFiles.filter((nf) => !prev.some((p) => p.name === nf.name && p.size === nf.size)),
                ]);
                setUploadStatus('pending');
              }
            }}
            multiple
          />

          {files.length > 0 && (
            <Box style={{ marginTop: '16px' }}>
              <FileUploadList
                fileList={files}
                columns={[
                  'File Name',
                  'Size',
                  <ScreenReaderOnly key="actions">Actions</ScreenReaderOnly>
                ]}
                FileItem={(props: any) => {
                  const currentFile = props.file as File;
                  return (
                    <tr>
                      <td>
                        <Stack direction="row" gap="xs" align="center">
                          <Text>{currentFile.name}</Text>
                          <CheckmarkSolid style={{ color: 'var(--wadk-text-basic-positive, #008a00)' }} />
                        </Stack>
                      </td>
                      <td>
                        <Text>{formatFileSize(currentFile.size)}</Text>
                      </td>
                      <td>
                        <Button
                          icon={<TrashOutline />}
                          variant="link"
                          onClick={() => setFiles((prev) => prev.filter((f) => f !== currentFile))}
                        />
                      </td>
                    </tr>
                  );
                }}
              />
            </Box>
          )}

          {rejectMessage && <Text style={{ color: 'red' }}>{rejectMessage}</Text>}
          {uploadStatus === 'error' && <Text style={{ color: 'red', marginTop: '8px' }}>Upload failed. Please try again.</Text>}
        </Stack>
      </Box>
    </DraggableDialog>
  );
};

const UploadSuccessBubble: React.FC<{ initialFiles: File[]; initialSummary?: string; initialFileValidationByName?: Record<string, boolean>; planId?: string; config: UploadBeforeGenerationConfig }> = ({
  initialFiles,
  initialSummary,
  initialFileValidationByName,
  planId,
  config,
}) => {
  const [isGenerated, setIsGenerated] = useState(false);
  const [allFiles, setAllFiles] = useState<File[]>(initialFiles);
  const [uploadSummary, setUploadSummary] = useState<string | undefined>(initialSummary);
  const [fileValidationByName, setFileValidationByName] = useState<Record<string, boolean>>(initialFileValidationByName ?? {});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const useValidationStatusFlow = Boolean(config.useValidationStatusFlow);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Text fontWeight="bold" style={{ display: 'block', marginBottom: '8px' }}>
        Document Uploaded Successfully
      </Text>
      <Table>
        <thead>
          <tr>
            <Table.Cell header>Type</Table.Cell>
            <Table.Cell header>Document Name</Table.Cell>
            <Table.Cell header>Status</Table.Cell>
            {!isGenerated && !useValidationStatusFlow && (
              <Table.Cell header>
                <ScreenReaderOnly>Actions</ScreenReaderOnly>
              </Table.Cell>
            )}
          </tr>
        </thead>
        <tbody>
          {allFiles.map((f, i) => (
            <tr key={`${f.name}-${i}`}>
              <Table.Cell>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <DocumentOutline />
                  File
                </div>
              </Table.Cell>
              <Table.Cell>{f.name}</Table.Cell>
              <Table.Cell>
                {useValidationStatusFlow && fileValidationByName[normalizeFileNameKey(f.name)] === false ? (
                  <StatusLabel appearance="subtle-pill" size="xs" variant="danger">
                    Invalid</StatusLabel>
                ) : (
                  <StatusLabel appearance="subtle-pill" size="xs" variant="success">
                    Uploaded
                  </StatusLabel>
                )}
              </Table.Cell>
              {!isGenerated && !useValidationStatusFlow && (
                <Table.Cell>
                  <Button
                    icon={<TrashOutline />}
                    variant="link"
                    aria-label={`Delete ${f.name}`}
                    onClick={() => setAllFiles((prev) => prev.filter((_, idx) => idx !== i))}
                  />
                </Table.Cell>
              )}
            </tr>
          ))}
        </tbody>
      </Table>

      {uploadSummary && (
        <Text variant="secondary" style={{ marginTop: '8px' }}>
          {uploadSummary}
        </Text>
      )}

      {!isGenerated && (
        <div style={{ marginTop: '16px', display: 'flex', justifyContent: 'flex-end', gap: '16px', width: '100%' }}>
          <OutlineButton variant="primary" onClick={() => setIsModalOpen(true)}>
            Upload more files
          </OutlineButton>
          <Button
            variant="primary"
            disabled={allFiles.length === 0}
            onClick={() => {
              setIsGenerated(true);
              triggerGeneration(config);
            }}
          >
            {config.generateButtonLabel}
          </Button>
        </div>
      )}

      {isModalOpen && (
        <UploadDocumentDialog
          planId={planId}
          config={config}
          onClose={() => setIsModalOpen(false)}
          onUploaded={(result) => {
            const existingByName = allFiles.reduce<Record<string, File>>((acc, file) => {
              const key = normalizeFileNameKey(file.name);
              if (key && !acc[key]) {
                acc[key] = file;
              }
              return acc;
            }, {});

            const additionalFromValidation = (result.validationFileNames || [])
              .filter((name) => !existingByName[normalizeFileNameKey(name)])
              .map((name) => new File([''], name));

            const newFiles = [...result.files, ...additionalFromValidation];

            setAllFiles((prev) => [
              ...prev,
              ...newFiles.filter((nf) => !prev.some((p) => p.name === nf.name && p.size === nf.size)),
            ]);
            if (result.summary) {
              setUploadSummary(result.summary);
            }
            if (result.fileValidationByName) {
              setFileValidationByName((prev) => ({ ...prev, ...result.fileValidationByName }));
            }
            setIsModalOpen(false);
          }}
        />
      )}
    </div>
  );
};

export const UploadBeforeGenerationFlow: React.FC<UploadBeforeGenerationFlowProps> = ({ messageId, config }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const planId = dashboardMatch?.params?.planId;

  const handleCancel = () => {
    if (messageId) {
      emitRemoveMessage(messageId);
    }
    window.dispatchEvent(new CustomEvent('ai-chat:reset-chat'));
  };

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', width: '100%', gap: '16px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
          <Text fontWeight="bold" style={{ margin: 0 }}>Documents Referred</Text>
          <div style={{ marginTop: '16px', border: '1px dashed #ccc', padding: '16px', borderRadius: '4px' }}>
            <Stack direction="column" gap="xs">
              <Text style={{ fontWeight: 'bold' }}>{`Upload file (${MOM_ALLOWED_FILE_TYPES_LABEL})`}</Text>
              <Text variant="secondary">No file chosen</Text>
              <Text variant="secondary" size="xs">{`200MB per file • ${MOM_ALLOWED_FILE_TYPES_SHORT_LABEL}`}</Text>
              <div style={{ marginTop: '12px', display: 'flex', gap: '8px' }}>
                <Button onClick={() => setIsModalOpen(true)}>Upload</Button>
                <OutlineButton variant="primary" onClick={handleCancel}>Cancel</OutlineButton>
              </div>
            </Stack>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <UploadDocumentDialog
          planId={planId}
          config={config}
          onClose={() => setIsModalOpen(false)}
          onCancelAll={handleCancel}
          onUploaded={(result) => {
            setIsModalOpen(false);
            if (messageId) {
              emitRemoveMessage(messageId);
            }
            emitAddMessage(
              'ai',
              <UploadSuccessBubble
                initialFiles={result.files}
                initialSummary={result.summary}
                initialFileValidationByName={result.fileValidationByName}
                planId={planId}
                config={config}
              />
            );
          }}
        />
      )}
    </>
  );
};
