import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useForm, FormProvider } from 'react-hook-form';
import { Text, Button, OutlineButton, Table, StatusLabel, Stack, DropdownInput, FormInput, Box, TextInput, RightSlot } from '@wadk/ui';
import { DocumentOutline, LinkSolid, CheckmarkSolid, PlusSolid, DocumentAddSolid, XSolid, SingleChevronDownSolid, SingleChevronUpSolid } from '@wadk/icons';
import { AutoLoadingProgress, LoadingProgress, AiQuestions, AiQuestionsPrompt } from 'com.db.rca.commons.afcc-components'; // Keep this line
import { AddRecipientModal } from '../../UploadModal/UploadModal';
import { PreviewModal } from '../../PreviewModal';
import type { RecipientItem } from '../../../../types/aiChat';
import { generateNoir, type NoirGenerateResponse } from '../../../../api/noirClient';
import styles from '../../AiChat.module.css';
import { useLocation, matchPath } from 'react-router-dom'; // Import useLocation and matchPath
import { SequentialFadeList } from '../../Loader/SequentialFadeList';

export type { RecipientItem };

export interface NoirResponsePayload {
  /** Full response returned by gateway action `GENERATE_NOIR`. */
  noirData: NoirGenerateResponse;
  /** Convenience aggregates used to render the preview bubble. */
  findingsMapped: number;
  taxonomyAligned: boolean;
  recipientsValidated: boolean;
  message: string;
}

// --- Chat-bus helpers ---------------------------------------------------
const emitAddMessage = (
  sender: 'user' | 'ai',
  content: React.ReactNode,
  id?: string
) => {
  window.dispatchEvent(
    new CustomEvent('ai-chat:add-message', { detail: { id, sender, content } })
  );
};

const emitRemoveMessage = (id: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:remove-message', { detail: { id } }));
};

// --- Read-only recipients table (rendered inside a user chat bubble) ----
const RecipientsSummary: React.FC<{ recipients: RecipientItem[] }> = ({ recipients }) => {
  const [isExpandedSummary, setIsExpandedSummary] = React.useState(false);

  const displayedRecipients = isExpandedSummary ? recipients : recipients.slice(0, 5);
  const hasMoreRecipients = recipients.length > 5;

  return (
    <div className={styles['recipients-summary']}>
      <Text className={styles['recipients-summary-title']} fontWeight="bold">
        Recipient list uploaded ({recipients.length})
      </Text>
      <Text
        style={{
          fontSize: '12px',
          marginTop: '12px',
          whiteSpace: 'normal',
          overflowWrap: 'anywhere',
          wordBreak: 'break-word',
          lineHeight: '1.5'
        }}
      >
        {displayedRecipients.map(item => item.attachment).join(', ')}
      </Text>

      {hasMoreRecipients && (
        <div style={{ marginTop: '12px', display: 'flex', justifyContent: 'flex-start' }}>
          <Button
            variant="link"
            onClick={() => setIsExpandedSummary(!isExpandedSummary)}
            icon={isExpandedSummary ? <SingleChevronUpSolid /> : <SingleChevronDownSolid />}
            style={{ color: 'var(--wadk-text-basic-action-link, #0550D1)', fontSize: '12px', fontWeight: 500 }}
          >
            {isExpandedSummary
              ? `Show Less`
              : `Show More (+${recipients.length - 5})`
            }
          </Button>
        </div>
      )}
    </div>
  );
};

// --- AI "Generated NOIR" bubble content ---------------------------------
interface NoirGeneratedResponseProps {
  messageId: string;
  payload: NoirResponsePayload;
  onAccept: () => void;
}

const NoirLoadingBubble: React.FC<{ isSkipping: boolean, isCompleted: boolean }> = ({ isSkipping, isCompleted }) => {
  return (
    <Stack gap="md" direction="column">
      {isSkipping ? (
        <SequentialFadeList
          title="Looking into..."
          listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
          items={['Reviewing regulatory obligations',
            'Analysing policies',
            'Comparing historical scope',
            'Reviewing open findings',
            'Mapping risks and controls',
            'Assessing evidence ',
            'Developing scope direction',
            'processing....']}
        />
      ) : (
        <SequentialFadeList
          title="Aligning with:"
          listClassName={styles['noir-loading-list']}
          items={[
            'Review objective',
            'Ownership',
            'Assessment unit',
            'Risk type, controls & source lineage'
          ]}
          intervalMs={40000}
        />
      )}

      {/* {isCompleted ? (
        <LoadingProgress
          value={1}
          max={1}
          messages={['Complete!', 'Complete!', 'Complete!'] as unknown as readonly [React.ReactNode, React.ReactNode, React.ReactNode]}
        />
      ) : (
        <AutoLoadingProgress
          intervalMs={120000}
          messages={[
            'In Progress...',
            'Almost Done...',
            'Complete!'
          ]}
        />
      )} */}
    </Stack>
  );
};

// --- AI "NOIR Accepted" follow-up bubble --------------------------------
const emitSendMessage = (content: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:send-message', { detail: { content } }));
};

const emitNoirAccepted = (noirData: NoirGenerateResponse, planId: string) => {
  window.dispatchEvent(new CustomEvent('noir:accepted', { detail: { noirData, planId } }));
};

const emitNoirPreviewOpened = (planId?: string) => {
  window.dispatchEvent(new CustomEvent('noir:preview-opened', {
    detail: { planId: planId || '' }
  }));
};

const emitNoirPreviewVisibilityChanged = (visible: boolean, planId?: string) => {
  window.dispatchEvent(new CustomEvent('noir:preview-visibility-changed', {
    detail: { visible, planId: planId || '' }
  }));
};

const NoirAcceptedResponse: React.FC = () => (
  <Stack direction="row" gap="sm" style={{ alignItems: 'center' }}>
    <CheckmarkSolid style={{ color: 'var(--wadk-text-basic-positive, #2E7D32)', flexShrink: 0 }} />
    <Text>Your NOIR output has been generated and is ready to view.</Text>
  </Stack>
);

// --- NOIR Accepted Response ---
const NoirAcceptedFinal: React.FC = () => (
  <Stack direction="row" gap="sm" style={{ alignItems: 'center' }}>
    <CheckmarkSolid style={{ color: 'var(--wadk-text-basic-positive, #2E7D32)', flexShrink: 0 }} />
    <Text>Your NOIR output has been successfully submitted.</Text>
  </Stack>
);

// --- NOIR Preview with What's Next Component ---
interface NoirPreviewWithNextProps {
  noirData: NoirGenerateResponse;
  messageId: string;
  planId?: string;
}

const NoirPreviewWithNext: React.FC<NoirPreviewWithNextProps> = ({ noirData, messageId, planId }) => {
  const navigate = useNavigate();

  const handleAccept = () => {
    // Emit user message for acceptance
    emitAddMessage('user', 'Accept NOIR');
    // Remove preview message immediately
    emitRemoveMessage(messageId);
    // Show acceptance message
    emitAddMessage('ai', <NoirAcceptedFinal />);
    // Emit event that NOIR has been accepted
    emitNoirAccepted(noirData, planId || '');
    // Navigate after showing acceptance
    setTimeout(() => {
      navigate(planId ? `/noir/${planId}` : '/noir');
    }, 1500);
  };

  const handleEditOption = (option: string) => {
    // Remove the preview message immediately
    emitRemoveMessage(messageId);

    emitSendMessage(option);
  };

  return (
    <div>
      <NoirPreview
        noirData={noirData}
        onAccept={handleAccept}
        onViewPreview={() => {
          emitNoirPreviewOpened(planId);
          emitNoirPreviewVisibilityChanged(true, planId);
        }}
        onClosePreview={() => emitNoirPreviewVisibilityChanged(false, planId)}
      />
      <WhatsNextOptions onOptionClick={handleEditOption} />
    </div>
  );
};

// --- What's Next Questions Component (using AiQuestionsPrompt) ---
interface WhatsNextOptionsProps {
  onOptionClick?: (option: string) => void;
}

const WhatsNextOptions: React.FC<WhatsNextOptionsProps> = ({ onOptionClick }) => {
  const handleOptionClick = (option: string) => {
    if (onOptionClick) {
      onOptionClick(option);
    }
  };

  return (<>
    <Text fontWeight="bold" style={{ marginTop: "10px" }}>What&rsquo;s next?</Text>
    <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
      <AiQuestionsPrompt onClick={() => handleOptionClick('Make the tone more formal')}>
        Make the tone more formal
      </AiQuestionsPrompt>
      <AiQuestionsPrompt onClick={() => handleOptionClick('Make it more concise')}>
        Make it more concise
      </AiQuestionsPrompt>
    </div>
  </>
  );
};

// --- NOIR Preview Component ---
interface NoirPreviewProps {
  noirData: NoirGenerateResponse;
  onAccept?: () => void;
  onViewPreview?: () => void;
  onClosePreview?: () => void;
}

const NoirPreview: React.FC<NoirPreviewProps> = ({
  noirData,
  onAccept,
  onViewPreview,
  onClosePreview
}) => {
  const [isModalOpen, setIsModalOpen] = React.useState(false);

  const handleViewPreview = () => {
    setIsModalOpen(true);
    if (onViewPreview) {
      onViewPreview();
    }
  };

  const handleAccept = () => {
    if (onAccept) {
      onAccept();
    }
  };

  return (
    <>
      <div style={{
        backgroundColor: 'var(--wadk-fill-basic-blank, #FFFFFF)',
        borderRadius: '8px',
        padding: '16px',
        border: '1px solid #E0E0E0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
      }}>
        <div style={{ marginBottom: '16px', paddingBottom: '5px', borderBottom: '1px solid rgb(206, 224, 255)' }}>
          <Text fontWeight="bold" size="md">
            Preview - NOIR output
          </Text>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Text size="sm" style={{ color: 'var(--wadk-text-basic-light, #555)' }}>
            NOIR output is produced through the analysis of key metadata contained within dbAware.
          </Text>

          <div>
            <Text fontWeight="bold" size="sm" style={{ marginBottom: '12px', display: 'block' }}>
              What's included:
            </Text>
            <ul className={styles['noir-preview-list']}>
              <li>Risks</li>
              <li>Key Control</li>
              <li>Timelines</li>
              <li>Next Steps</li>
              <li>Request for Information</li>
            </ul>
          </div>

          <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-start', marginTop: '16px' }}>
            <OutlineButton
              onClick={handleAccept}
            >
              Accept
            </OutlineButton>
            <Button
              variant="primary"
              onClick={handleViewPreview}
            >
              View Preview
            </Button>
          </div>
        </div>
      </div>

      <PreviewModal
        isOpen={isModalOpen}
        title="NOIR Preview"
        subject={noirData.subject}
        body={noirData.body}
        onClose={() => {
          setIsModalOpen(false);
          if (onClosePreview) {
            onClosePreview();
          }
        }}
        onAccept={() => {
          setIsModalOpen(false);
          if (onClosePreview) {
            onClosePreview();
          }
          if (onAccept) {
            onAccept();
          }
        }}
      />
    </>
  );
};

const NoirGeneratedResponse: React.FC<NoirGeneratedResponseProps> = ({
  payload,
  onAccept
}) => {
  return (
    <div className={styles['noir-response']}>
      <div className={styles['noir-preview']}>
        <div className={styles['noir-preview-label']}>
          <Text fontWeight="bold">Preview - NOIR Output</Text>
        </div>

        <div style={{ maxHeight: '300px', overflowY: 'auto', paddingRight: '8px', paddingBottom: '8px' }}>
          <div style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '14px', lineHeight: '1.5' }}>
            {payload.message ? payload.message.replace(/\\n/g, '\n').replace(/\\/g, '') : ''}
          </div>
          <ul className={styles['noir-preview-list']} style={{ marginTop: '16px' }}>
            <li>
              <Text variant="secondary">{payload.findingsMapped} Findings mapped</Text>
            </li>
            <li>
              <Text variant="secondary">
                Taxonomy alignment {payload.taxonomyAligned ? 'completed' : 'pending'}
              </Text>
            </li>
            <li>
              <Text variant="secondary">
                Recipients {payload.recipientsValidated ? 'validated' : 'pending'}
              </Text>
            </li>
          </ul>
        </div>

        <div className={styles['noir-actions']}>
          <Button onClick={onAccept} variant="primary">
            Accept
          </Button>
        </div>
      </div>
    </div>
  );
};

// --- Main flow (initial upload bubble) ----------------------------------
interface NoirGenerationFlowProps {
  messageId?: string;
}

export const NoirGenerationFlow: React.FC<NoirGenerationFlowProps> = ({ messageId }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isNoirGenerationInFlightRef = useRef(false);

  // Inject keyframe animation if not already present
  React.useEffect(() => {
    if (!document.getElementById('recipient-badge-animation')) {
      const style = document.createElement('style');
      style.id = 'recipient-badge-animation';
      style.textContent = `
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  const [step, setStep] = useState<'loading' | 'preview' | 'recipients' | 'error'>('recipients');
  const [payload, setPayload] = useState<NoirResponsePayload | null>(null);

  const [isAddMoreOpen, setIsAddMoreOpen] = useState(false);
  const [recipients, setRecipients] = useState<RecipientItem[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [errors, setErrors] = useState<string[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [newRecipientIndices, setNewRecipientIndices] = useState<Set<number>>(new Set());
  const isSubmittingRef = useRef(false);

  useEffect(() => {
    dispatch({ type: 'scoping/setRecipients', payload: recipients });
  }, [recipients, dispatch]);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const parseEmails = (text: string) => {
    return text
      .split(',')
      .map(email => email.trim())
      .filter(email => email.length > 0);
  };

  const handleAddRecipients = () => {
    const emails = parseEmails(inputValue);
    const newErrors: string[] = [];
    const validEmails: string[] = [];

    emails.forEach(email => {
      if (validateEmail(email)) {
        validEmails.push(email);
      } else {
        newErrors.push(email);
      }
    });

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    if (validEmails.length > 0) {
      const startIndex = recipients.length;
      const newIndices = new Set<number>();
      for (let i = 0; i < validEmails.length; i++) {
        newIndices.add(startIndex + i);
      }
      setNewRecipientIndices(newIndices);

      const newRecipients: RecipientItem[] = validEmails.map((email) => ({
        id: Math.random().toString(36).substr(2, 9),
        type: 'Email',
        attachment: email,
        status: 'Added',
        emails: [email]
      }));

      setRecipients([...recipients, ...newRecipients]);
      setInputValue('');
      setErrors([]);

      setTimeout(() => {
        setNewRecipientIndices(new Set());
      }, 300);
    }
  };

  const handleRemoveRecipient = (id: string) => {
    setRecipients(prev => prev.filter(r => r.id !== id));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
    setErrors([]);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddRecipients();
    }
  };

  const hasFetchedNoir = useRef(false);
  const isMountedRef = useRef(false);

  // Extract planId from URL
  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const planId = dashboardMatch?.params?.planId;
  // Open Add Recipients flow first. NOIR generation runs on Submit.
  useEffect(() => {
    isMountedRef.current = true;
    window.dispatchEvent(new CustomEvent('ai-chat:set-input-disabled', { detail: { disabled: true } }));
    navigate(planId ? `/noir/${planId}` : '/noir');
    dispatch({ type: 'scoping/setIsGeneratingNoir', payload: false });

    return () => {
      isMountedRef.current = false;
      if (!isNoirGenerationInFlightRef.current) {
        dispatch({ type: 'scoping/setIsGeneratingNoir', payload: false });
      }
      window.dispatchEvent(new CustomEvent('ai-chat:set-input-disabled', { detail: { disabled: false } }));
    };
  }, []);

  const handleAcceptPreview = () => {
    if (payload) {
      dispatch({ type: 'scoping/setNoirData', payload: payload.noirData });
    }
    navigate(planId ? `/noir/${planId}` : '/noir');
    setStep('recipients');
  };

  const handleSubmitRecipients = (skipRecipients = false) => {
    if (isSubmittingRef.current || !planId) return;
    if (!skipRecipients && recipients.length === 0) return;

    if (skipRecipients) {
      emitAddMessage('user', 'Skip recipient entry');
    } else {
      emitAddMessage('user', <RecipientsSummary recipients={recipients} />);
    }

    window.dispatchEvent(new CustomEvent('ai-chat:noir-generation-started', {
      detail: { planNumber: String(planId || '').trim() }
    }));

    setStep('preview');
    isSubmittingRef.current = true;
    isNoirGenerationInFlightRef.current = true;
    dispatch({ type: 'scoping/setIsGeneratingNoir', payload: true });

    generateNoir(planId)
      .then(noirData => {
        if (planId && Array.isArray(noirData.next_available_actions)) {
          dispatch({
            type: 'scoping/setNextAvailableActionsForPlan',
            payload: {
              planNumber: planId,
              actions: noirData.next_available_actions,
            },
          });
        }

        if (planId && noirData.task_definition_key) {
          dispatch({
            type: 'scoping/setTaskDefinitionKeyForPlan',
            payload: {
              planNumber: planId,
              taskDefinitionKey: noirData.task_definition_key,
            },
          });
        }

        const item = noirData.original_data?.[0];
        const combinedContent = noirData.body && noirData.subject
          ? `Subject: ${noirData.subject}\n\nBody:\n${noirData.body}`
          : noirData.email;
        const emailContent = combinedContent || item?.['Description of Plan Item'];

        const nextPayload: NoirResponsePayload = {
          noirData,
          findingsMapped: 0,
          taxonomyAligned: true,
          recipientsValidated: (noirData.recipients?.length ?? 0) > 0,
          message: emailContent ?? 'The NOIR data has been successfully generated.'
        };

        setPayload(nextPayload);
        dispatch({ type: 'scoping/setNoirData', payload: noirData });
        // emitAddMessage('ai', <NoirAcceptedResponse />);

        // Preview step is temporarily disabled.
        // setTimeout(() => {
        //   const previewMessageId = Math.random().toString(36).substr(2, 9);
        //   emitAddMessage(
        //     'ai',
        //     <NoirPreviewWithNext
        //       noirData={noirData}
        //       messageId={previewMessageId}
        //       planId={planId}
        //     />,
        //     previewMessageId
        //   );
        // }, 1000);

        // Auto-accept generated NOIR for now (preview step skipped).
        emitAddMessage('ai', <NoirAcceptedFinal />);
        emitNoirAccepted(noirData, planId || '');
        navigate(planId ? `/noir/${planId}` : '/noir');
        setStep('recipients');

        if (messageId) {
          emitRemoveMessage(messageId);
        }
      })
      .catch(err => {
        console.error('Failed to generate NOIR', err);
        emitAddMessage('ai', 'Sorry, generating the NOIR failed. Please try again.');
      })
      .finally(() => {
        isSubmittingRef.current = false;
        isNoirGenerationInFlightRef.current = false;
        dispatch({ type: 'scoping/setIsGeneratingNoir', payload: false });
        window.dispatchEvent(new CustomEvent('ai-chat:noir-generation-finished', {
          detail: { planNumber: String(planId || '').trim() }
        }));
      });
  };

  if (step === 'loading') {
    return <NoirLoadingBubble isSkipping={false} isCompleted={payload !== null} />;
  }

  if (step === 'error') {
    return <Text>Sorry, generating the NOIR failed. Please try again.</Text>;
  }

  if (step === 'preview' && payload) {
    return (
      <NoirGeneratedResponse
        messageId={messageId || ''}
        payload={payload}
        onAccept={handleAcceptPreview}
      />
    );
  }

  if (step === 'recipients') {
    const displayedRecipients = isExpanded ? recipients : recipients.slice(0, 4);
    const hasMoreRecipients = recipients.length > 4;

    const handleModalSubmit = (items: any[]) => {
      const newErrors: string[] = [];
      const validEmails: string[] = [];

      items.forEach(item => {
        if (item.emails && Array.isArray(item.emails)) {
          item.emails.forEach((email: string) => {
            if (validateEmail(email)) {
              validEmails.push(email);
            } else {
              newErrors.push(email);
            }
          });
        }
      });

      if (newErrors.length > 0) {
        setErrors(newErrors);
      } else {
        setErrors([]);
      }

      if (validEmails.length > 0) {
        const startIndex = recipients.length;
        const newIndices = new Set<number>();
        for (let i = 0; i < validEmails.length; i++) {
          newIndices.add(startIndex + i);
        }
        setNewRecipientIndices(newIndices);

        // Create individual recipient entries for each email from the file
        const newRecipients: RecipientItem[] = validEmails.map((email) => ({
          id: Math.random().toString(36).substr(2, 9),
          type: 'File' as const,
          attachment: email,
          status: 'Uploaded',
          emails: [email]
        }));

        setRecipients([...recipients, ...newRecipients]);

        setTimeout(() => {
          setNewRecipientIndices(new Set());
        }, 300);
      }
    };

    return (
      <div className={styles['recipients-container']} style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <div>

          <Text className={styles['recipients-header']}>
            Would you like to upload the Recipient list?
          </Text>
          <div style={{ width: "85%", display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1px' }}>
            <Text style={{ fontWeight: "400" }}>Add Recipients</Text>
            <Button
              icon={<DocumentAddSolid />}
              variant="link"
              onClick={() => setIsAddMoreOpen(true)}
            >
              Upload Files
            </Button>
          </div>

          <Stack direction="row" gap="base">
            <Stack grow={1}>
              <TextInput
                style={{ width: "100%" }}
                placeholder="Add or paste a recipient list"
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                value={inputValue}
              />
            </Stack>
            <Stack grow={0}>
              <Button icon={<PlusSolid />} variant="link"
                onClick={handleAddRecipients}>
                Add
              </Button>
            </Stack>
          </Stack>

          <Text style={{ fontSize: '11px', color: 'var(--wadk-text-basic-light, rgba(23, 25, 69, 0.75))', marginBottom: '12px', display: 'block' }}>
            Use comma-separated addresses
          </Text>

          {errors.length > 0 && (
            <div style={{
              padding: '8px',
              backgroundColor: 'var(--wadk-status-error-subtle, #FFEBEE)',
              border: '1px solid #FFCDD2',
              borderRadius: '4px',
              marginBottom: '12px'
            }}>
              <Text style={{ color: 'var(--wadk-text-basic-negative, #C62828)', fontSize: '12px', fontWeight: 500 }}>
                Invalid email(s): {errors.join(', ')}
              </Text>
            </div>
          )}

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', padding: '4px 0', minHeight: 'auto', marginBottom: recipients.length > 0 ? '16px' : '0' }}>
            {displayedRecipients.map((recipient, index) => (
              <div
                key={recipient.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '2px',
                  padding: '2px 6px',
                  backgroundColor: 'var(--wadk-fill-accent-subtle, #E3F1FF)',
                  borderRadius: '4px',
                  border: '1px solid #B3D9FF',
                  fontSize: '11px',
                  color: 'var(--wadk-text-basic-base, #171945)',
                  animation: newRecipientIndices.has(index) ? 'fadeIn 0.3s ease-out forwards' : 'none'
                }}
              >
                <span>{recipient.attachment || recipient.emails?.[0]}</span>
                <button
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '0',
                    marginLeft: '4px',
                    color: 'var(--wadk-text-basic-action-link, #0550D1)',
                    transition: 'color 0.2s ease'
                  }}
                  onClick={() => handleRemoveRecipient(recipient.id)}
                  type='button'
                  onMouseEnter={(e) => (e.currentTarget.style.color = '#0340A6')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = '#0550D1')}
                >
                  <XSolid style={{ width: '14px', height: '14px' }} />
                </button>
              </div>
            ))}
          </div>

          {hasMoreRecipients && (
            <div style={{ marginTop: '8px', display: 'flex', justifyContent: 'flex-start' }}>
              <Button
                variant="link"
                onClick={() => setIsExpanded(!isExpanded)}
                icon={isExpanded ? <SingleChevronUpSolid /> : <SingleChevronDownSolid />}
                style={{ color: 'var(--wadk-text-basic-action-link, #0550D1)', fontSize: '12px', fontWeight: 500 }}
              >
                {isExpanded
                  ? `Show Less (${recipients.length})`
                  : `Show More (+${recipients.length - 4})`
                }
              </Button>
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', alignSelf: 'stretch' }}>
            <div className='xcm' style={{ display: 'flex', gap: '8px', margin: "15px" }}>
              {/* {recipients.length === 0 && (
                <Button
                  variant="link"
                  onClick={() => {
                    emitAddMessage('user', 'Skip recipient entry');
                    emitAddMessage('ai', <NoirAcceptedResponse />);
                    if (messageId) {
                      emitRemoveMessage(messageId);
                    }
                    navigate(planId ? `/noir/${planId}` : '/noir');
                  }}
                >
                  Skip for now
                </Button>
              )} */}
              {recipients.length === 0 && (
                <Button
                  variant="link"
                  onClick={() => handleSubmitRecipients(true)}>
                  Skip for now
                </Button>
              )}
              <OutlineButton
                // style={}
                disabled={recipients.length === 0}
                onClick={() => handleSubmitRecipients()}
              >
                Submit
              </OutlineButton>
            </div>
          </div>
        </div>

        <AddRecipientModal
          isOpen={isAddMoreOpen}
          onClose={() => setIsAddMoreOpen(false)}
          onSubmit={handleModalSubmit}
          openFileUploadModalOnly
        />
      </div>
    );
  }

  return null;
};
