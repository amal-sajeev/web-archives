import React, { useState, useEffect } from 'react';
import { Text, Spinner } from '@wadk/ui';

export interface SequentialFadeListProps {
    title?: React.ReactNode;
    items: React.ReactNode[];
    intervalMs?: number;
    listClassName?: string;
    listStyle?: React.CSSProperties;
}

export const SequentialFadeList: React.FC<SequentialFadeListProps> = ({
    title,
    items,
    intervalMs = 8000,
    listClassName,
    listStyle
}) => {
    // Start at 1 so the first item appears immediately
    const [visibleStep, setVisibleStep] = useState(1);

    useEffect(() => {
        const listInterval = setInterval(() => {
            setVisibleStep((prev) => (prev <= items.length ? prev + 1 : prev));
        }, intervalMs);
        return () => clearInterval(listInterval);
    }, [items.length, intervalMs]);

    return (
        <>
            {title && (typeof title === 'string' ? <Text fontWeight="bold">{title}</Text> : title)}
            <ul className={listClassName} style={{ listStyleType: 'none', ...listStyle }}>
                {items.map((item, index) => {
                    const isVisible = visibleStep > index;
                    const isCurrentLoading = visibleStep === index + 1 && visibleStep <= items.length;

                    return (
                        <li
                            key={index}
                            style={{
                                opacity: isVisible ? 1 : 0,
                                transition: 'opacity 0.5s ease-in',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                marginBottom: '4px'
                            }}
                        >
                            <span style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minWidth: '24px' }}>
                                {isCurrentLoading ? <Spinner size="sm" /> : <span style={{ fontSize: '18px', color: 'var(--text-secondary, #666)', lineHeight: 1 }}>•</span>}
                            </span>
                            <span style={{ flex: 1 }}>
                                {typeof item === 'string' ? <Text variant="secondary">{item}</Text> : item}
                            </span>
                        </li>
                    );
                })}
            </ul>
        </>
    );
};