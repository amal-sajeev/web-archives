import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Stack, Text, OutlineButton } from '@wadk/ui';
import { AutoLoadingProgress } from 'com.db.rca.commons.afcc-components';
import { CheckmarkSolid } from '@wadk/icons';
import { editNor } from '../../api/norClient';
import styles from './AiChat.module.css';
import { useLocation, matchPath } from 'react-router-dom';
import { PreviewModal } from './previewModal/previewModal';

const emitRemoveMessage = (id: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:remove-message', { detail: { id } }));
};

const emitAddMessage = (
  sender: 'user' | 'ai',
  content: React.ReactNode,
  id?: string
) => {
  window.dispatchEvent(
    new CustomEvent('ai-chat:add-message', { detail: { id, sender, content } })
  );
};

const emitNorAccepted = (norData: any, planId: string) => {
  window.dispatchEvent(new CustomEvent('nor:accepted', { detail: { norData, planId } }));
};

const emitNorPreviewVisibilityChanged = (visible: boolean, planId?: string) => {
  window.dispatchEvent(new CustomEvent('nor:preview-visibility-changed', {
    detail: { visible, planId: planId || '' }
  }));
};

export const NorEditFlow: React.FC<{ messageId: string, instruction: string }> = ({ messageId, instruction }) => {
  const dispatch = useDispatch();
  const norData = useSelector((state: any) => state.nor?.norData);
  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const planId = dashboardMatch?.params?.planId;
  const resolvedPlanId = String(norData?.original_data?.[0]?.['Plan Item Number'] || planId || '').trim();

  const [status, setStatus] = useState<'loading' | 'done' | 'error'>('loading');
  const [editedData, setEditedData] = useState<any>(null);
  const [decided, setDecided] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const requestFired = useRef(false);

  useEffect(() => {
    if (!norData) {
      setStatus('error');
      return;
    }

    if (requestFired.current) return;
    requestFired.current = true;

    const payload = {
      plan_item_number: String(planId || norData.original_data?.[0]?.['Plan Item Number']),
      user_instruction: instruction
    };

    dispatch({ type: 'nor/setIsGeneratingNor', payload: true });

    editNor(payload)
      .then((responseData: any) => {
        const apiResult = responseData.data || responseData.payload || responseData;
        const updatedNorData = {
          ...norData,
          subject: apiResult.subject || norData.subject,
          body: apiResult.body || norData.body,
          email_content: apiResult.email_content || apiResult.email || norData.email_content || norData.email,
          email: apiResult.email_content || apiResult.email || norData.email,
          original_data: apiResult.updated_data || apiResult.original_data || norData.original_data
        };
        setEditedData(updatedNorData);
        setStatus('done');
      })
      .catch(err => {
        console.error('editNor failed', err);
        setStatus('error');
      })
      .finally(() => {
        dispatch({ type: 'nor/setIsGeneratingNor', payload: false });
      });
  }, [instruction, norData]);

  const handleAccept = () => {
    setDecided(true);
    dispatch({ type: 'nor/setNorData', payload: editedData });
    emitRemoveMessage(messageId);
    emitNorAccepted(editedData, resolvedPlanId);

    emitAddMessage('ai', (
      <Stack direction="row" gap="sm" style={{ alignItems: 'center' }}>
        <CheckmarkSolid style={{ color: '#2E7D32', flexShrink: 0 }} />
        <Text>NOR has been updated successfully.</Text>
      </Stack>
    ));
  };

  const handleOpenPreview = () => {
    setIsModalOpen(true);
    emitNorPreviewVisibilityChanged(true, resolvedPlanId);
  };

  const handleClosePreview = () => {
    setIsModalOpen(false);
    emitNorPreviewVisibilityChanged(false, resolvedPlanId);
  };

  useEffect(() => {
    return () => {
      emitNorPreviewVisibilityChanged(false, resolvedPlanId);
    };
  }, [resolvedPlanId]);

  if (status === 'loading') {
    return (
      <Stack gap="md" direction="column">
        <Text fontWeight="bold">Updating NOR...</Text>
        <AutoLoadingProgress
          intervalMs={120000}
          messages={['Applying your instructions...', 'Almost Done...', 'processing...']}
        />
      </Stack>
    );
  }

  if (status === 'error') {
    return <Text>Sorry, updating the NOR failed. Please try again.</Text>;
  }

  return (
    <div className={styles['noir-response']}>
      <div style={{
        backgroundColor: '#FFFFFF',
        borderRadius: '8px',
        padding: '16px',
        border: '1px solid #E0E0E0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
      }}>
        <div style={{ marginBottom: '16px', paddingBottom: '5px', borderBottom: '1px solid rgb(206, 224, 255)' }}>
          <Text fontWeight="bold" size="md">
            Refined Output is ready!
          </Text>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Text size="sm" className={styles['noir-text']}>
            NOR output is produced through the analysis of key metadata contained within dbAware.
          </Text>

          <div>
            <Text fontWeight="bold" size="sm" style={{ marginBottom: '12px', display: 'block' }}>
              What's included:
            </Text>
            <ul className={styles['nor-preview-list']}>
              <li>Risks</li>
              <li>Key Control</li>
              <li>Timelines</li>
              <li>Next Steps</li>
              <li>Request for Information</li>
            </ul>
          </div>

          {!decided && (
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-start', marginTop: '16px' }}>
              <OutlineButton
                variant="primary"
                onClick={handleAccept}
              >
                Accept
              </OutlineButton>
              <OutlineButton
                variant="primary"
                onClick={handleOpenPreview}
              >
                View Preview
              </OutlineButton>
            </div>
          )}
        </div>
      </div>

      <PreviewModal
        isOpen={isModalOpen}
        title="NOR Preview"
        subject={editedData?.subject}
        body={editedData?.body}
        onClose={handleClosePreview}
        onAccept={() => {
          handleClosePreview();
          handleAccept();
        }}
      />
    </div>
  );
};