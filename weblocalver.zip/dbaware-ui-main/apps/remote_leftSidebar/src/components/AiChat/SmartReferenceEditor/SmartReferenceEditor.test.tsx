import React from 'react';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import SmartReferenceEditor from './SmartReferenceEditor';

vi.mock('@wadk/ui', () => ({
  Button: ({ children, onClick, disabled, type = 'button', ...rest }: any) => (
    <button type={type} onClick={onClick} disabled={disabled} {...rest}>
      {children}
    </button>
  ),
  Stack: ({ children }: any) => <div>{children}</div>,
  StatusLabel: ({ children }: any) => <span>{children}</span>,
}));

vi.mock('com.db.rca.commons.afcc-components', () => ({
  AiInputPanelAttachment: ({ children, onRemove }: any) => (
    <div>
      {children}
      {onRemove ? <button type="button" onClick={onRemove}>Remove</button> : null}
    </div>
  ),
  AiInputPanelContent: ({ children, actions, onButtonClick, className }: any) => (
    <div data-testid="input-panel" className={className}>
      {actions}
      {children}
      <button type="button" onClick={onButtonClick}>
        Send
      </button>
    </div>
  ),
  ScreenReaderOnly: ({ children }: any) => <span>{children}</span>,
}));

vi.mock('@wadk/icons', () => ({
  AttachSolid: () => <span />,
  ContextInfoOutline: () => <span />,
  PaperPlaneOutline: () => <span />,
  DocumentOutline: () => <span />,
  CheckmarkSolid: () => <span />,
}));

describe('SmartReferenceEditor', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    cleanup();
  });

  const sampleCategories = [
    {
      key: 'Policy',
      label: 'Policy, Procedure, KOD',
      files: [
        {
          id: 'doc-1',
          name: 'Policy With Sections',
          type: 'document',
          itemKind: 'document',
          sourceDocumentType: 'policy',
          status: 'active',
          excluded: false,
          lastModified: '2026-01-01',
          sizeKb: 1,
          documentId: '1',
        },
        {
          id: 'sec-1',
          name: 'Section One',
          type: 'section',
          itemKind: 'section',
          sourceDocumentType: 'policy',
          sectionId: '1',
          parentDocumentId: 'doc-1',
          status: 'active',
          excluded: false,
          lastModified: '2026-01-01',
          sizeKb: 1,
          documentId: '1',
        },
        {
          id: 'doc-2',
          name: 'Zero Section Policy',
          type: 'document',
          itemKind: 'document',
          sourceDocumentType: 'policy',
          status: 'active',
          excluded: false,
          lastModified: '2026-01-01',
          sizeKb: 1,
          documentId: '2',
        },
      ],
    },
    {
      key: 'Other',
      label: 'Others',
      files: [
        {
          id: 'gfms-doc',
          name: 'Findings Doc',
          type: 'document',
          itemKind: 'document',
          sourceDocumentType: 'gfms',
          status: 'active',
          excluded: false,
          lastModified: '2026-01-01',
          sizeKb: 1,
          documentId: 'gfms',
        },
      ],
    },
  ];

  it('keeps 0-section documents visible and emits whole-document mention tags', () => {
    const onSend = vi.fn();
    render(
      <SmartReferenceEditor
        categories={sampleCategories as any}
        badgeLabel="exclude"
        showBadge={false}
        onSend={onSend}
      />
    );

    fireEvent.click(screen.getByRole('button', { name: '@Policy, Procedure, KOD' }));
    const editable = document.querySelector('[role="textbox"]') as HTMLElement;
    expect(editable).toBeTruthy();
    editable.textContent = '@';
    fireEvent.input(editable);

    expect(screen.getByText('Zero Section Policy')).toBeTruthy();

    const checkboxes = screen.getAllByRole('checkbox');
    fireEvent.click(checkboxes[1]);
    fireEvent.click(screen.getByRole('button', { name: 'Insert' }));

    fireEvent.click(screen.getByRole('button', { name: 'Send' }));
    expect(onSend).toHaveBeenCalledTimes(1);
    expect(onSend.mock.calls[0][0]).toContain('@[Policy: Zero Section Policy]');
  });

  it('allows sending when Other badge is selected without analysis scope', () => {
    const onSend = vi.fn();
    render(
      <SmartReferenceEditor
        categories={sampleCategories as any}
        showBadge={true}
        onSend={onSend}
      />
    );

    fireEvent.click(screen.getByRole('button', { name: '@Others' }));
    const editable = document.querySelector('[role="textbox"]') as HTMLElement;
    editable.textContent = 'Summarize GFMS findings';
    fireEvent.input(editable);

    expect(screen.getByTestId('input-panel').className).not.toContain('send-disabled');
    fireEvent.click(screen.getByRole('button', { name: 'Send' }));
    expect(onSend).toHaveBeenCalledWith('Summarize GFMS findings', []);
  });
});
