import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Button, Stack, StatusLabel } from '@wadk/ui';
import { AiInputPanelAttachment, AiInputPanelContent, ScreenReaderOnly } from 'com.db.rca.commons.afcc-components';
import { AttachSolid, ContextInfoOutline } from '@wadk/icons';

type CategoryKey = 'Policy' | 'KOD' | 'Historical' | 'Other' | string;

export interface SmartFileItem {
	id: string;
	name: string;
	type: 'pdf' | 'doc' | 'docx' | 'xlsx' | 'txt' | 'pptx' | string;
	itemKind?: 'document' | 'section' | 'attachment';
	sourceDocumentType?: 'policy' | 'procedure' | 'kod' | 'historical_scoping_document' | 'gfms' | 'lrr' | string;
	sectionId?: string | number;
	status?: string;
	excluded?: boolean;
	parentDocumentId?: string;
	documentId?: string;
	nodeId?: string;
	lastModified: string;
	sizeKb: number;
	pinned?: boolean;
	sourceFile?: File;
}

export interface SmartCategoryConfig {
	key: CategoryKey;
	label: string;
	files: SmartFileItem[];
}

interface MentionRef {
	id: string;
	categoryKey: CategoryKey;
	fileIds: string[];
}

export interface SmartEditModeProps {
	badgeLabel?: string;
	placeholder?: string;
	disabled?: boolean;
	categories?: SmartCategoryConfig[];
	isCategoryDataLoading?: boolean;
	embedded?: boolean;
	showBadge?: boolean;
	showContextPanel?: boolean;
	openMenusUpward?: boolean;
	onValueChange?: (value: string) => void;
	onContextChange?: (context: Record<string, SmartFileItem[]>) => void;
	onSend?: (value: string, attachments?: File[]) => void;
}

const ALLOWED_EXTENSIONS = ['pdf', 'doc', 'docx', 'xlsx', 'txt', 'pptx'];
const ACCEPT_ATTR = '.pdf,.doc,.docx,.xlsx,.txt,.pptx';
const QUICK_ACTION_COMMANDS = ['Exclude', 'Include', 'Re-include', 'Summarize'];

const nowDate = () => new Date().toISOString().slice(0, 10);

const makeId = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 9)}-${Date.now()}`;
const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const isItemExcluded = (item: SmartFileItem) => item.excluded === true || String(item.status || '').toLowerCase() === 'excluded';

const defaultCategories: SmartCategoryConfig[] = [
	{
		key: 'Policy',
		label: 'Policy, Procedure, KOD',
		files: [],
	},
	{
		key: 'Historical',
		label: 'Historical Scoping Documents',
		files: [],
	},
	{
		key: 'Other',
		label: 'Others (GFMS, Alternative Coverage/Non-Coverage, content quality)',
		files: [],
	},
];

const chipStyle: React.CSSProperties = {
	display: 'inline-flex',
	alignItems: 'center',
	gap: 4,
	borderRadius: 12,
	background: '#dbeafe',
	color: '#1e3a8a',
	border: '1px solid #93c5fd',
	padding: '2px 6px',
	margin: '2px 3px 2px 0',
	fontSize: 10,
	whiteSpace: 'nowrap',
};

const compactBadgeStyle: React.CSSProperties = {
	transform: 'scale(0.9)',
	transformOrigin: 'left center',
	fontSize: 10,
};

const mentionTextStyle: Partial<CSSStyleDeclaration> = {
	display: 'inline',
	background: 'transparent',
	color: '#2563eb',
	padding: '0',
	borderRadius: '0',
	border: 'none',
	fontWeight: '700',
	fontSize: '12px',
	lineHeight: '16px',
};

const SmartReferenceEditor: React.FC<SmartEditModeProps> = ({
	badgeLabel = 'AI CONTEXT',
	placeholder = 'Type Exclude/Include/Re-include/Summarize and @ to reference files',
	disabled = false,
	categories = defaultCategories,
	isCategoryDataLoading = false,
	embedded = false,
	showBadge = true,
	showContextPanel = true,
	openMenusUpward = false,
	onValueChange,
	onContextChange,
	onSend,
}) => {
	const [allFilesByCategory, setAllFilesByCategory] = useState<Record<string, SmartFileItem[]>>(() => (
		categories.reduce((acc, cat) => ({ ...acc, [cat.key]: [...cat.files] }), {} as Record<string, SmartFileItem[]>)
	));
	const [uploadedAttachments, setUploadedAttachments] = useState<SmartFileItem[]>([]);
	const [inputValue, setInputValue] = useState('');
	const [mentions, setMentions] = useState<Record<string, MentionRef>>({});
	const [recentFileIds, setRecentFileIds] = useState<string[]>([]);
	const [pickerOpen, setPickerOpen] = useState(false);
	const [pickerCategoryKey, setPickerCategoryKey] = useState<CategoryKey | null>(null);
	const [pickerSelectedIds, setPickerSelectedIds] = useState<Record<string, boolean>>({});
	const [expandedDocumentIds, setExpandedDocumentIds] = useState<Record<string, boolean>>({});
	const [selectedBadgeKey, setSelectedBadgeKey] = useState<CategoryKey | null>(null);
	const [selectedAnalysisScope, setSelectedAnalysisScope] = useState<string | null>(null);
	const [scopeMenuOpen, setScopeMenuOpen] = useState(false);
	const [scopeInfoHovered, setScopeInfoHovered] = useState(false);
	const [policyDocTypeFilter, setPolicyDocTypeFilter] = useState<'policy' | 'procedure' | 'kod'>('policy');
	const [historicalDocTypeFilter, setHistoricalDocTypeFilter] = useState<string>('historical_scoping_document');
	const [otherDocTypeFilter, setOtherDocTypeFilter] = useState<string>('gfms');
	const [pickerSearch, setPickerSearch] = useState('');
	const [dragActive, setDragActive] = useState(false);
	const [commandSuggestion, setCommandSuggestion] = useState<{ prefix: string; completion: string; full: string } | null>(null);
	const [scopeMenuPosition, setScopeMenuPosition] = useState<{ top: number; left: number }>({ top: 0, left: 0 });

	const fileInputRef = useRef<HTMLInputElement | null>(null);
	const pickerFileInputRef = useRef<HTMLInputElement | null>(null);
	const scopeMenuRef = useRef<HTMLDivElement | null>(null);
	const scopeMenuFloatingRef = useRef<HTMLDivElement | null>(null);
	const lastAutoOpenedTokenRef = useRef<string | null>(null);
	const autoOpenedPickerRef = useRef(false);
	const editorRef = useRef<HTMLDivElement | null>(null);
	const ANALYSIS_SCOPE_OPTIONS = useMemo(
		() => [
			'Past Review Analysis',
			'Policy, KOD and Regulatory Analysis',
			'Broad Scope Direction',
		],
		[],
	);

	useEffect(() => {
		onValueChange?.(inputValue);
	}, [inputValue, onValueChange]);

	useEffect(() => {
		const trimmed = inputValue.trim();
		if (!trimmed || /\s/.test(trimmed)) {
			setCommandSuggestion(null);
			return;
		}

		const match = QUICK_ACTION_COMMANDS.find((command) => command.toLowerCase().startsWith(trimmed.toLowerCase()));
		if (!match || match.toLowerCase() === trimmed.toLowerCase()) {
			setCommandSuggestion(null);
			return;
		}

		setCommandSuggestion({
			prefix: trimmed,
			completion: match.slice(trimmed.length),
			full: match,
		});
	}, [inputValue]);

	useEffect(() => {
		setAllFilesByCategory(
			categories.reduce((acc, cat) => ({ ...acc, [cat.key]: [...cat.files] }), {} as Record<string, SmartFileItem[]>)
		);
	}, [categories]);

	const contextByCategory = useMemo(() => {
		const map: Record<string, SmartFileItem[]> = {};
		Object.values(mentions).forEach((mention) => {
			const files = allFilesByCategory[mention.categoryKey] || [];
			const selected = files.filter((f) => mention.fileIds.includes(f.id));
			map[mention.categoryKey] = [...(map[mention.categoryKey] || []), ...selected];
		});
		Object.keys(map).forEach((k) => {
			const uniq = new Map<string, SmartFileItem>();
			map[k].forEach((f) => uniq.set(f.id, f));
			map[k] = Array.from(uniq.values());
		});
		return map;
	}, [allFilesByCategory, mentions]);

	useEffect(() => {
		onContextChange?.(contextByCategory);
	}, [contextByCategory, onContextChange]);

	const getCheckedMapForCategory = (categoryKey: CategoryKey | null): Record<string, boolean> => {
		if (!categoryKey) return {};
		const selectedIds = new Set<string>();
		Object.values(mentions).forEach((mention) => {
			if (mention.categoryKey === categoryKey) {
				mention.fileIds.forEach((id) => selectedIds.add(id));
			}
		});

		return Array.from(selectedIds).reduce((acc, id) => {
			acc[id] = true;
			return acc;
		}, {} as Record<string, boolean>);
	};

	useEffect(() => {
		const atTokenMatch = inputValue.match(/(?:^|\s)@([^\s@]*)\s*$/);

		if (!selectedBadgeKey || !atTokenMatch) {
			if (autoOpenedPickerRef.current) {
				setPickerOpen(false);
				autoOpenedPickerRef.current = false;
			}
			setPickerSearch('');
			lastAutoOpenedTokenRef.current = null;
			return;
		}

		const rawToken = atTokenMatch[0].trim();
		const searchTerm = (atTokenMatch[1] || '').trim().toLowerCase();
		setPickerSearch(searchTerm);

		if (!pickerOpen || pickerCategoryKey !== selectedBadgeKey) {
			openPickerForCategory(selectedBadgeKey, true);
		}

		lastAutoOpenedTokenRef.current = rawToken;
	}, [inputValue, selectedBadgeKey, pickerOpen, pickerCategoryKey, mentions]);

	const openPickerForCategory = (categoryKey: CategoryKey, openedByToken = false) => {
		setPickerCategoryKey(categoryKey);
		setPickerOpen(true);
		const checkedMap = getCheckedMapForCategory(categoryKey);
		setPickerSelectedIds(checkedMap);
		const files = allFilesByCategory[categoryKey] || [];
		const nextExpanded: Record<string, boolean> = {};
		files
			.filter((item) => item.itemKind === 'document')
			.forEach((doc) => {
				const hasSelectedSection = files.some((section) => (
					(section.itemKind === 'section' || String(section.type).toLowerCase() === 'section')
					&& section.parentDocumentId === doc.id
					&& Boolean(checkedMap[section.id])
				));
				if (hasSelectedSection) {
					nextExpanded[doc.id] = true;
				}
			});
		setExpandedDocumentIds(nextExpanded);
		if (String(categoryKey).toLowerCase() === 'policy') {
			setPolicyDocTypeFilter('policy');
		} else if (String(categoryKey).toLowerCase() === 'historical') {
			setHistoricalDocTypeFilter('historical_scoping_document');
		} else if (String(categoryKey).toLowerCase() === 'other') {
			setOtherDocTypeFilter('gfms');
		}
		autoOpenedPickerRef.current = openedByToken;
	};

	const pickerAvailableSourceDocTypes = useMemo(() => {
		if (!pickerCategoryKey) return [];
		const files = allFilesByCategory[pickerCategoryKey] || [];
		const uniq = new Set<string>();
		files.forEach((item) => {
			const value = String(item.sourceDocumentType || '').toLowerCase().trim();
			if (value) {
				uniq.add(value);
			}
		});
		return Array.from(uniq.values());
	}, [allFilesByCategory, pickerCategoryKey]);

	useEffect(() => {
		if (!pickerCategoryKey || pickerAvailableSourceDocTypes.length === 0) return;

		const normalizedCategory = String(pickerCategoryKey).toLowerCase();
		if (normalizedCategory === 'policy' && !pickerAvailableSourceDocTypes.includes(policyDocTypeFilter)) {
			setPolicyDocTypeFilter(pickerAvailableSourceDocTypes[0] as 'policy' | 'procedure' | 'kod');
		}
		if (normalizedCategory === 'historical' && !pickerAvailableSourceDocTypes.includes(historicalDocTypeFilter)) {
			setHistoricalDocTypeFilter(pickerAvailableSourceDocTypes[0]);
		}
		if (normalizedCategory === 'other' && !pickerAvailableSourceDocTypes.includes(otherDocTypeFilter)) {
			setOtherDocTypeFilter(pickerAvailableSourceDocTypes[0]);
		}
	}, [historicalDocTypeFilter, otherDocTypeFilter, pickerAvailableSourceDocTypes, pickerCategoryKey, policyDocTypeFilter]);

	const listStatusMode = useMemo<'all' | 'included-only' | 'excluded-only'>(() => {
		const normalized = inputValue.trim().toLowerCase();
		if (normalized.startsWith('include') || normalized.startsWith('re-include')) {
			return 'excluded-only';
		}
		if (normalized.startsWith('exclude')) {
			return 'included-only';
		}
		return 'all';
	}, [inputValue]);

	const pickerFiles = useMemo(() => {
		if (!pickerCategoryKey) return [];
		const base = [...(allFilesByCategory[pickerCategoryKey] || [])];
		const normalizedCategory = String(pickerCategoryKey).toLowerCase();
		const isPolicyCategory = normalizedCategory === 'policy';
		const isHistoricalCategory = normalizedCategory === 'historical';
		const isOtherCategory = normalizedCategory === 'other';

		const hasTypedItems = base.some((item) => Boolean(item.sourceDocumentType));
		if (!hasTypedItems || (!isPolicyCategory && !isHistoricalCategory && !isOtherCategory)) {
			return base.sort((a, b) => a.name.localeCompare(b.name));
		}

		const activeType = isPolicyCategory
			? policyDocTypeFilter
			: isHistoricalCategory
				? historicalDocTypeFilter
				: otherDocTypeFilter;

		const byType = base
			.filter((item) => String(item.sourceDocumentType || '').toLowerCase() === activeType);

		const parentIdsWithAnySections = new Set(
			byType
				.filter((item) => (item.itemKind === 'section' || String(item.type).toLowerCase() === 'section') && item.parentDocumentId)
				.map((item) => String(item.parentDocumentId))
		);

		const byStatus = byType.filter((item) => {
			const isSection = item.itemKind === 'section' || String(item.type).toLowerCase() === 'section';
			if (!isSection && parentIdsWithAnySections.has(item.id)) {
				return true;
			}

			if (listStatusMode === 'included-only') {
				return !isItemExcluded(item);
			}
			if (listStatusMode === 'excluded-only') {
				return isItemExcluded(item);
			}
			return true;
		});

		return byStatus.sort((a, b) => a.name.localeCompare(b.name));
	}, [allFilesByCategory, historicalDocTypeFilter, otherDocTypeFilter, pickerCategoryKey, policyDocTypeFilter, listStatusMode]);

	const pickerDocuments = useMemo(() => {
		return pickerFiles
			.filter((file) => file.itemKind === 'document')
			.sort((a, b) => a.name.localeCompare(b.name));
	}, [pickerFiles]);

	const pickerSections = useMemo(() => {
		return pickerFiles
			.filter((file) => file.itemKind === 'section' || String(file.type).toLowerCase() === 'section')
			.sort((a, b) => a.name.localeCompare(b.name));
	}, [pickerFiles]);

	const pickerSectionsByDocument = useMemo(() => {
		const map: Record<string, SmartFileItem[]> = {};
		pickerSections.forEach((section) => {
			const docId = section.parentDocumentId || '__no_doc__';
			map[docId] = [...(map[docId] || []), section];
		});
		return map;
	}, [pickerSections]);
	const parentIdsWithStructuredSections = useMemo(() => {
		const activeItems = pickerCategoryKey ? (allFilesByCategory[pickerCategoryKey] || []) : [];
		return new Set(
			activeItems
				.filter((item) => (item.itemKind === 'section' || String(item.type).toLowerCase() === 'section') && item.parentDocumentId)
				.map((item) => String(item.parentDocumentId))
		);
	}, [allFilesByCategory, pickerCategoryKey]);
	const hasDocumentSectionStructure = useMemo(() => {
		return pickerDocuments.length > 0 && pickerSections.length > 0;
	}, [pickerDocuments.length, pickerSections.length]);

	const filteredPickerFiles = useMemo(() => {
		const term = pickerSearch.trim().toLowerCase();
		if (!term) return pickerFiles;
		return pickerFiles.filter((file) => file.name.toLowerCase().includes(term));
	}, [pickerFiles, pickerSearch]);

	const filteredDocumentRows = useMemo(() => {
		if (pickerDocuments.length === 0 || pickerSections.length === 0) return [];

		const term = pickerSearch.trim().toLowerCase();
		return pickerDocuments
			.map((doc) => {
				const allSections = pickerSectionsByDocument[doc.id] || [];
				if (listStatusMode !== 'all' && allSections.length === 0 && parentIdsWithStructuredSections.has(doc.id)) {
					return null;
				}
				const matchesDoc = !term || doc.name.toLowerCase().includes(term);
				const matchingSections = !term
					? allSections
					: allSections.filter((section) => section.name.toLowerCase().includes(term));

				if (!matchesDoc && matchingSections.length === 0) return null;

				return {
					doc,
					sections: matchesDoc ? allSections : matchingSections,
				};
			})
			.filter((item): item is { doc: SmartFileItem; sections: SmartFileItem[] } => Boolean(item));
	}, [pickerDocuments, pickerSections, pickerSectionsByDocument, pickerSearch, listStatusMode, parentIdsWithStructuredSections]);

	const fallbackFlatFiles = useMemo(() => {
		return filteredPickerFiles.filter((file) => {
			if (file.itemKind !== 'document') return true;
			return listStatusMode === 'all' || !parentIdsWithStructuredSections.has(file.id);
		});
	}, [filteredPickerFiles, listStatusMode, parentIdsWithStructuredSections]);

	const isOtherCategorySelected = (pickerCategoryKey || '').toLowerCase() === 'other';
	const isPolicyCategorySelected = (pickerCategoryKey || '').toLowerCase() === 'policy';
	const isHistoricalCategorySelected = (pickerCategoryKey || '').toLowerCase() === 'historical';
	const isOtherBadgeSelected = String(selectedBadgeKey || '').toLowerCase() === 'other';
	const selectedCategoryLabel = categories.find((cat) => cat.key === pickerCategoryKey)?.label || pickerCategoryKey || '';
	const isInputDisabled = disabled || !selectedBadgeKey;
	const canSend = !isInputDisabled;
	const inputPlaceholder = isOtherBadgeSelected ? 'Type your prompt here and use Attach to add files' : placeholder;

	const updateScopeMenuPosition = () => {
		if (!scopeMenuRef.current) return;
		const rect = scopeMenuRef.current.getBoundingClientRect();
		setScopeMenuPosition({
			top: rect.top - 8,
			left: rect.left,
		});
	};

	useEffect(() => {
		if (!scopeMenuOpen) return;
		const onDocMouseDown = (event: MouseEvent) => {
			const target = event.target as Node;
			const isInAnchor = Boolean(scopeMenuRef.current?.contains(target));
			const isInFloatingMenu = Boolean(scopeMenuFloatingRef.current?.contains(target));
			if (!isInAnchor && !isInFloatingMenu) {
				setScopeMenuOpen(false);
			}
		};
		document.addEventListener('mousedown', onDocMouseDown);
		return () => document.removeEventListener('mousedown', onDocMouseDown);
	}, [scopeMenuOpen]);

	useEffect(() => {
		if (!scopeMenuOpen) return;
		updateScopeMenuPosition();

		const onViewportChange = () => updateScopeMenuPosition();
		window.addEventListener('resize', onViewportChange);
		window.addEventListener('scroll', onViewportChange, true);

		return () => {
			window.removeEventListener('resize', onViewportChange);
			window.removeEventListener('scroll', onViewportChange, true);
		};
	}, [scopeMenuOpen]);

	useEffect(() => {
		if (!isOtherBadgeSelected) {
			setScopeMenuOpen(false);
			setScopeInfoHovered(false);
		}
	}, [isOtherBadgeSelected]);

	const allSectionItems = useMemo(() => {
		return Object.entries(allFilesByCategory).flatMap(([categoryKey, items]) => (
			items
				.filter((item) => item.itemKind === 'section' || String(item.type).toLowerCase() === 'section')
				.map((item) => ({ categoryKey, item }))
		));
	}, [allFilesByCategory]);
	const sectionByName = useMemo(() => {
		const map = new Map<string, { categoryKey: string; item: SmartFileItem }>();
		allSectionItems.forEach((entry) => map.set(entry.item.name, entry));
		return map;
	}, [allSectionItems]);
	const sectionMentionRegex = useMemo(() => {
		if (allSectionItems.length === 0) return null;
		const pattern = allSectionItems
			.map((entry) => entry.item.name)
			.sort((a, b) => b.length - a.length)
			.map(escapeRegExp)
			.join('|');
		return new RegExp(`@(${pattern})(?=\\s|$)`, 'g');
	}, [allSectionItems]);

	const attachmentItems = useMemo(() => {
		const merged = [...uploadedAttachments];
		const uniq = new Map<string, SmartFileItem>();
		merged.forEach((f) => uniq.set(f.id, f));
		return Array.from(uniq.values());
	}, [uploadedAttachments]);

	const findMentionTargetByTagText = (tagText: string): { categoryKey: string; fileId: string } | null => {
		for (const [categoryKey, items] of Object.entries(allFilesByCategory)) {
			for (const item of items) {
				if (item.itemKind !== 'section' && item.itemKind !== 'document') {
					continue;
				}

				const sourceType = String(item.sourceDocumentType || '').toLowerCase();
				const categoryLabel = sourceType === 'policy'
					? 'Policy'
					: sourceType === 'procedure'
						? 'Procedure'
						: sourceType === 'kod'
							? 'KOD'
							: sourceType === 'historical_scoping_document'
								? 'Historical'
								: sourceType === 'gfms'
									? 'GFMS'
									: sourceType === 'lrr'
										? 'LRR'
										: String(categoryKey || 'Policy');

				const parentDoc = item.parentDocumentId
					? items.find((candidate) => candidate.id === item.parentDocumentId)
					: undefined;
				const sectionLabel = item.sectionId ? `${item.sectionId}: ${item.name}` : item.name;
				const candidateTag = item.itemKind === 'section' && parentDoc
					? `@[${categoryLabel}: ${parentDoc.name} > ${sectionLabel}]`
					: `@[${categoryLabel}: ${item.name}]`;

				if (candidateTag === tagText) {
					return { categoryKey, fileId: item.id };
				}
			}
		}

		return null;
	};

	const serializeEditor = () => {
		const editor = editorRef.current;
		if (!editor) return inputValue;

		const parts: string[] = [];
		editor.childNodes.forEach((node) => {
			if (node.nodeType === Node.TEXT_NODE) {
				parts.push(node.textContent || '');
				return;
			}
			if (node.nodeType === Node.ELEMENT_NODE) {
				const el = node as HTMLElement;
				if (el.dataset.mentionText) {
					parts.push(el.dataset.mentionText);
					parts.push(' ');
					return;
				}
				parts.push(el.textContent || '');
			}
		});

		return parts.join('').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trimStart();
	};

	const renderEditorWithMentions = (text: string) => {
		const editor = editorRef.current;
		if (!editor) {
			setInputValue(text);
			return;
		}

		editor.innerHTML = '';
		const nextMentions: Record<string, MentionRef> = {};

		if (!sectionMentionRegex) {
			editor.appendChild(document.createTextNode(text));
			setMentions({});
			setInputValue(text);
			return;
		}

		const combinedPattern = sectionMentionRegex
			? new RegExp(`@\\[[^\\]]+\\]|${sectionMentionRegex.source}`, 'g')
			: /@\[[^\]]+\]/g;

		combinedPattern.lastIndex = 0;
		let lastIndex = 0;
		let match: RegExpExecArray | null = null;
		while ((match = combinedPattern.exec(text)) !== null) {
			const start = match.index;
			const mentionText = match[0];
			if (start > lastIndex) {
				editor.appendChild(document.createTextNode(text.slice(lastIndex, start)));
			}

			const isBracketTag = mentionText.startsWith('@[');
			if (isBracketTag) {
				const mentionId = makeId('mention');
				const target = findMentionTargetByTagText(mentionText);
				if (target) {
					nextMentions[mentionId] = {
						id: mentionId,
						categoryKey: target.categoryKey,
						fileIds: [target.fileId],
					};
				}

				const chip = document.createElement('span');
				chip.contentEditable = 'false';
				chip.dataset.mentionId = mentionId;
				chip.dataset.mentionText = mentionText;
				chip.textContent = mentionText;
				Object.assign(chip.style, mentionTextStyle);
				editor.appendChild(chip);
			} else {
				const sectionName = mentionText.replace(/^@/, '');
				const section = sectionByName.get(sectionName);
				if (section) {
					const mentionId = makeId('mention');
					nextMentions[mentionId] = {
						id: mentionId,
						categoryKey: section.categoryKey,
						fileIds: [section.item.id],
					};

					const chip = document.createElement('span');
					chip.contentEditable = 'false';
					chip.dataset.mentionId = mentionId;
					chip.dataset.mentionText = mentionText;
					chip.textContent = mentionText;
					Object.assign(chip.style, mentionTextStyle);
					editor.appendChild(chip);
				} else {
					editor.appendChild(document.createTextNode(mentionText));
				}
			}

			lastIndex = start + mentionText.length;
		}

		if (lastIndex < text.length) {
			editor.appendChild(document.createTextNode(text.slice(lastIndex)));
		}

		setMentions(nextMentions);
		setInputValue(serializeEditor());
	};

	const syncInputValueFromEditor = () => {
		const text = serializeEditor();
		if (!sectionMentionRegex) {
			setInputValue(text);
			return;
		}

		const editor = editorRef.current;
		if (editor) {
			const walker = document.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
			let node: Node | null = walker.nextNode();
			let hasRawSectionMention = false;

			while (node) {
				const parent = (node.parentElement || null);
				if (!parent?.dataset?.mentionId) {
					const value = node.textContent || '';
					sectionMentionRegex.lastIndex = 0;
					if (sectionMentionRegex.test(value)) {
						hasRawSectionMention = true;
						break;
					}
				}
				node = walker.nextNode();
			}

			if (hasRawSectionMention) {
				renderEditorWithMentions(text);
				const range = document.createRange();
				range.selectNodeContents(editor);
				range.collapse(false);
				const selection = window.getSelection();
				selection?.removeAllRanges();
				selection?.addRange(range);
				return;
			}
		}

		setInputValue(text);
	};

	const removeMentionById = (mentionId: string) => {
		setMentions((prev) => {
			const next = { ...prev };
			delete next[mentionId];
			return next;
		});
	};

	const getStatusBadge = (item: SmartFileItem) => {
		const isExcluded = item.excluded === true || String(item.status || '').toLowerCase() === 'excluded';
		return (
			<StatusLabel
				size="xs"
				appearance="subtle-pill"
				variant={isExcluded ? 'warning' : 'success'}
				style={compactBadgeStyle}
			>
				{isExcluded ? 'Excluded' : 'Included'}
			</StatusLabel>
		);
	};

	const getTagCategoryLabel = (item: SmartFileItem, categoryKey?: CategoryKey | null): string => {
		const sourceType = String(item.sourceDocumentType || '').toLowerCase();
		if (sourceType === 'policy') return 'Policy';
		if (sourceType === 'procedure') return 'Procedure';
		if (sourceType === 'kod') return 'KOD';
		if (sourceType === 'historical_scoping_document') return 'Historical';
		if (sourceType === 'gfms') return 'GFMS';
		if (sourceType === 'lrr') return 'LRR';

		const key = String(categoryKey || '').toLowerCase();
		if (key === 'policy') return 'Policy';
		if (key === 'historical') return 'Historical';
		if (key === 'other') return 'Other';
		return String(categoryKey || 'Policy');
	};

	const buildTagText = (item: SmartFileItem, categoryKey?: CategoryKey | null): string => {
		const categoryLabel = getTagCategoryLabel(item, categoryKey);
		const categoryItems = categoryKey ? (allFilesByCategory[categoryKey] || []) : [];
		const parentDoc = item.parentDocumentId
			? categoryItems.find((candidate) => candidate.id === item.parentDocumentId)
			: undefined;
		const sectionLabel = item.sectionId ? `${item.sectionId}: ${item.name}` : item.name;

		if (item.itemKind === 'section' && parentDoc) {
			return `@[${categoryLabel}: ${parentDoc.name} > ${sectionLabel}]`;
		}

		return `@[${categoryLabel}: ${item.name}]`;
	};

	const removeSectionMentionFromEditor = (item: SmartFileItem, categoryKey?: CategoryKey | null) => {
		const mentionTag = buildTagText(item, categoryKey);
		const tokenPattern = new RegExp(`${escapeRegExp(mentionTag)}(?=\\s|$)`, 'g');
		const currentText = serializeEditor();
		const nextText = currentText
			.replace(tokenPattern, '')
			.replace(/\s{2,}/g, ' ')
			.trim();

		renderEditorWithMentions(nextText);

		if (categoryKey) {
			setMentions((prev) => {
				const next: Record<string, MentionRef> = {};
				Object.values(prev).forEach((mention) => {
					if (mention.categoryKey === categoryKey) {
						const fileNames = (allFilesByCategory[categoryKey] || [])
							.filter((f) => mention.fileIds.includes(f.id))
							.map((f) => f.name);
						if (fileNames.includes(item.name)) {
							return;
						}
					}
					next[mention.id] = mention;
				});
				return next;
			});
		}
	};

	const commitPickerSelection = () => {
		if (!pickerCategoryKey) return;
		const allowedIds = new Set(pickerFiles.map((item) => item.id));
		const ids = Object.keys(pickerSelectedIds).filter((id) => pickerSelectedIds[id] && allowedIds.has(id));
		if (ids.length === 0) return;

		const selectedIdSet = new Set(ids);
		const categoryItems = allFilesByCategory[pickerCategoryKey] || [];
		const wholeDocIds = new Set(
			categoryItems
				.filter((item) => item.itemKind === 'document' && selectedIdSet.has(item.id))
				.map((item) => item.id)
		);
		const selectedItemsForTags = categoryItems.filter((item) => {
			if (!selectedIdSet.has(item.id)) return false;
			if (item.itemKind === 'section' && item.parentDocumentId && wholeDocIds.has(item.parentDocumentId)) {
				return false;
			}
			return true;
		});
		const selectedText = selectedItemsForTags.map((item) => buildTagText(item, pickerCategoryKey)).join(' ');

		const currentText = serializeEditor();
		const withoutToken = currentText.replace(/@([^\s@]*)\s*$/, '').replace(/\s+$/, '');
		const nextText = `${withoutToken}${withoutToken ? ' ' : ''}${selectedText} `;
		renderEditorWithMentions(nextText);
		setMentions((prev) => {
			const next: Record<string, MentionRef> = {};
			Object.values(prev).forEach((mention) => {
				if (mention.categoryKey !== pickerCategoryKey) {
					next[mention.id] = mention;
				}
			});

			const mentionId = makeId('mention');
			next[mentionId] = {
				id: mentionId,
				categoryKey: pickerCategoryKey,
				fileIds: ids,
			};

			return next;
		});

		const editor = editorRef.current;
		if (editor) {
			const range = document.createRange();
			range.selectNodeContents(editor);
			range.collapse(false);
			const selection = window.getSelection();
			selection?.removeAllRanges();
			selection?.addRange(range);
		}

		setPickerOpen(false);
		autoOpenedPickerRef.current = false;
		setPickerSearch('');
	};

	const handleUploadFiles = (files: FileList | null) => {
		if (!files || !pickerCategoryKey) return;

		const mapped: SmartFileItem[] = [];
		Array.from(files).forEach((file) => {
			const ext = file.name.split('.').pop()?.toLowerCase() || '';
			if (!ALLOWED_EXTENSIONS.includes(ext)) return;
			mapped.push({
				id: makeId('upload'),
				name: file.name,
				type: ext,
				lastModified: new Date(file.lastModified).toISOString().slice(0, 10),
				sizeKb: Math.max(1, Math.round(file.size / 1024)),
			});
		});

		if (mapped.length === 0) return;
		setAllFilesByCategory((prev) => ({
			...prev,
			[pickerCategoryKey]: [...(prev[pickerCategoryKey] || []), ...mapped],
		}));
	};

	const handleAttachUpload = (files: FileList | null) => {
		if (!files) return;

		const mapped: SmartFileItem[] = [];
		Array.from(files).forEach((file) => {
			const ext = file.name.split('.').pop()?.toLowerCase() || '';
			if (!ALLOWED_EXTENSIONS.includes(ext)) return;
			mapped.push({
				id: makeId('attach'),
				name: file.name,
				type: ext,
				lastModified: new Date(file.lastModified).toISOString().slice(0, 10),
				sizeKb: Math.max(1, Math.round(file.size / 1024)),
				sourceFile: file,
			});
		});

		if (mapped.length === 0) return;
		setUploadedAttachments((prev) => [...prev, ...mapped]);
	};

	const removeContextFile = (categoryKey: string, fileId: string) => {
		setMentions((prev) => {
			const next: Record<string, MentionRef> = {};
			Object.values(prev).forEach((m) => {
				if (m.categoryKey !== categoryKey) {
					next[m.id] = m;
					return;
				}
				const keep = m.fileIds.filter((id) => id !== fileId);
				if (keep.length > 0) {
					next[m.id] = { ...m, fileIds: keep };
				}
			});
			return next;
		});
	};

	const removeSelectedFile = (fileId: string) => {
		setUploadedAttachments((prev) => prev.filter((f) => f.id !== fileId));
		setRecentFileIds((prev) => prev.filter((id) => id !== fileId));
		setMentions((prev) => {
			const next: Record<string, MentionRef> = {};
			Object.values(prev).forEach((m) => {
				const keepIds = m.fileIds.filter((id) => id !== fileId);
				if (keepIds.length > 0) {
					next[m.id] = { ...m, fileIds: keepIds };
				}
			});
			return next;
		});
	};

	const resetInputAndSelections = () => {
		const editor = editorRef.current;
		if (editor) {
			editor.innerHTML = '';
		}
		setInputValue('');
		setMentions({});
		setPickerSelectedIds({});
		setExpandedDocumentIds({});
		setPickerSearch('');
		setPickerOpen(false);
		autoOpenedPickerRef.current = false;
		lastAutoOpenedTokenRef.current = null;
	};

	const handleSend = () => {
		if (!canSend) return;
		const text = serializeEditor().trim();

		if (!text) {
			resetInputAndSelections();
			setSelectedBadgeKey(null);
			setPickerCategoryKey(null);
			setSelectedAnalysisScope(null);
			setUploadedAttachments([]);
			setRecentFileIds([]);
			setScopeMenuOpen(false);
			return;
		}

		onSend?.(text, attachmentItems.map((item) => item.sourceFile).filter((file): file is File => Boolean(file)));
		resetInputAndSelections();
		setSelectedBadgeKey(null);
		setPickerCategoryKey(null);
		setSelectedAnalysisScope(null);
		setUploadedAttachments([]);
		setRecentFileIds([]);
		setScopeMenuOpen(false);
	};

	const applyCommandSuggestion = () => {
		if (!commandSuggestion) return;
		const nextText = `${commandSuggestion.full} `;
		renderEditorWithMentions(nextText);

		const editor = editorRef.current;
		if (editor) {
			const range = document.createRange();
			range.selectNodeContents(editor);
			range.collapse(false);
			const selection = window.getSelection();
			selection?.removeAllRanges();
			selection?.addRange(range);
		}
	};

	const closePickerAndRemoveAtToken = () => {
		const currentText = serializeEditor();
		const nextText = currentText
			.replace(/(?:^|\s)@([^\s@]*)$/, '')
			.replace(/\s+$/, '');

		renderEditorWithMentions(nextText);

		const editor = editorRef.current;
		if (editor) {
			const range = document.createRange();
			range.selectNodeContents(editor);
			range.collapse(false);
			const selection = window.getSelection();
			selection?.removeAllRanges();
			selection?.addRange(range);
		}

		setPickerOpen(false);
		autoOpenedPickerRef.current = false;
		setPickerSearch('');
		lastAutoOpenedTokenRef.current = null;
	};

	return (
		<div style={{ display: 'grid', gridTemplateColumns: showContextPanel ? '1fr minmax(240px, 320px)' : '1fr', gap: 16, width: '100%' }}>
			<div style={{ position: 'relative' }}>
				{showBadge && (
					<div style={{ marginBottom: 8 }}>
						<StatusLabel appearance="subtle-pill" size="xs" variant="neutral">{badgeLabel}</StatusLabel>
					</div>
				)}

				<Stack direction="row" gap="xs" style={{ marginBottom: 8, flexWrap: 'wrap' }}>
					{categories.map((cat) => (
						<button
							key={cat.key}
							type="button"
							onClick={() => {
								if (selectedBadgeKey && selectedBadgeKey !== cat.key) {
									resetInputAndSelections();
								}
								setSelectedBadgeKey((prev) => (prev === cat.key ? null : cat.key));
								setPickerOpen(false);
								autoOpenedPickerRef.current = false;
							}}
							disabled={disabled}
							style={{
								borderRadius: 16,
								border: selectedBadgeKey === cat.key ? '1px solid #2563eb' : '1px solid #d1d5db',
								background: selectedBadgeKey === cat.key ? '#dbeafe' : '#f8fafc',
								color: selectedBadgeKey === cat.key ? '#1e3a8a' : '#111827',
								cursor: disabled ? 'not-allowed' : 'pointer',
								padding: '3px 6px',
								fontSize: 10,
								lineHeight: 1.2,
								whiteSpace: 'nowrap',
							}}
						>
							@{cat.label}
						</button>
					))}
				</Stack>

				<AiInputPanelContent
					onButtonClick={handleSend}
					actions={(
						<Stack direction="row" gap="xs" align="center" style={{ position: 'relative', justifyContent: 'space-between' }}>
							
							{selectedBadgeKey && (
								<Button
									variant="link"
									title="Attach"
									icon={<AttachSolid />}
									onClick={() => fileInputRef.current?.click()}
									disabled={disabled}
								/>
							)}
							{isOtherBadgeSelected && (
								<div ref={scopeMenuRef} style={{ position: 'relative', zIndex: 10000 }}>
									<Stack direction="row" gap="xs" align="center">
										<div
											style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}
											onMouseEnter={() => setScopeInfoHovered(true)}
											onMouseLeave={() => setScopeInfoHovered(false)}
										>
											<span
												aria-label="Scope info"
												style={{
													display: 'inline-flex',
													alignItems: 'center',
													cursor: 'help',
												}}
											>
												<ContextInfoOutline color='#0550d1' />
											</span>
											{scopeInfoHovered && (
												<div
													style={{
														position: 'absolute',
														left: 0,
														bottom: 'calc(100% + 8px)',
														padding: '6px 8px',
														background: '#0f172a',
														color: '#fff',
														fontSize: 11,
														borderRadius: 6,
														whiteSpace: 'nowrap',
																			zIndex: 10001,
													}}
												>
													Note: Select scope before send
												</div>
											)}
										</div>
									<Button
										variant="link"
										title="Analysis Scope"
										onClick={() => {
											setScopeMenuOpen((prev) => {
												const next = !prev;
												if (next) {
													updateScopeMenuPosition();
												}
												return next;
											});
										}}
										disabled={disabled}
									>
										{selectedAnalysisScope ? 'Scope (1)' : 'Select Scope'}
									</Button>
									</Stack>
									{scopeMenuOpen && createPortal(
										<div
											ref={scopeMenuFloatingRef}
											style={{
												position: 'fixed',
												top: scopeMenuPosition.top,
												left: scopeMenuPosition.left,
												transform: 'translateY(-100%)',
												minWidth: 280,
												padding: 8,
												border: '1px solid #cbd5e1',
												borderRadius: 10,
												background: '#fff',
												boxShadow: '0 10px 30px rgba(2, 6, 23, 0.18)',
												zIndex: 2147483647,
											}}
										>
											{ANALYSIS_SCOPE_OPTIONS.map((option) => {
												const checked = selectedAnalysisScope === option;
												return (
													<label key={option} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 4px', fontSize: 12 }}>
														<input
															type="radio"
															name="analysis-scope"
															checked={checked}
															onChange={() => setSelectedAnalysisScope(option)}
														/>
														<span>{option}</span>
													</label>
												);
											})}
										</div>,
										document.body
									)}
								</div>
							)}
						</Stack>
					)}
					className={`chat-input-panel smart-edit-mode-panel ${canSend ? '' : 'send-disabled'}`}
					style={{ border: 'none', boxShadow: 'none', outline: 'none', background: 'transparent' }}
				>
					<style>
						{`.smart-edit-mode-panel.send-disabled button[title="Send"]{opacity:.45;pointer-events:none;cursor:not-allowed;}`}
					</style>
					<input
						ref={fileInputRef}
						type="file"
						multiple
						accept={ACCEPT_ATTR}
						style={{ display: 'none' }}
						onChange={(e) => {
							handleAttachUpload(e.target.files);
							e.currentTarget.value = '';
						}}
					/>

					{attachmentItems.length > 0 && (
						<fieldset style={{ border: 'none', margin: 0, padding: 0, marginBottom: 8 }}>
							<ScreenReaderOnly as="legend">Attachments</ScreenReaderOnly>
							<Stack direction="row" gap="xs" style={{ flexWrap: 'wrap' }}>
								{attachmentItems.slice(0, 6).map((file) => (
									<AiInputPanelAttachment
										key={file.id}
										file={file.sourceFile as File}
										onRemove={() => removeSelectedFile(file.id)}
									/>
								))}
							</Stack>
						</fieldset>
					)}

					<div
						style={{
							position: 'relative',
							minHeight: 74,
							border: 'none',
							borderRadius: 0,
							padding: 8,
							background: 'transparent',
							boxShadow: 'none',
						}}
					>
						<div
							ref={editorRef}
							role="textbox"
							aria-multiline="true"
							contentEditable={!isInputDisabled}
							suppressContentEditableWarning
							onInput={syncInputValueFromEditor}
							onKeyDown={(e) => {
								if (e.key === 'Enter' && !e.shiftKey) {
									e.preventDefault();
									handleSend();
									return;
								}

								if (e.key === 'Tab' && commandSuggestion) {
									e.preventDefault();
									applyCommandSuggestion();
									return;
								}

								if (e.key === 'Backspace') {
									const selection = window.getSelection();
									if (!selection || selection.rangeCount === 0) return;
									const range = selection.getRangeAt(0);
									if (!range.collapsed) return;

									const container = range.startContainer;
									const offset = range.startOffset;
									let mentionNode: HTMLElement | null = null;

									if (container.nodeType === Node.TEXT_NODE) {
										const textNode = container as Text;
										if (offset === 0) {
											mentionNode = (textNode.previousSibling as HTMLElement | null);
										} else {
											const beforeCaret = (textNode.textContent || '').slice(0, offset);
											if (/^\s+$/.test(beforeCaret)) {
												mentionNode = (textNode.previousSibling as HTMLElement | null);
											}
										}
									} else if (container.nodeType === Node.ELEMENT_NODE) {
										const element = container as HTMLElement;
										mentionNode = (element.childNodes[offset - 1] as HTMLElement | null) || null;
									}

									if (mentionNode && mentionNode.dataset?.mentionId) {
										e.preventDefault();
										removeMentionById(mentionNode.dataset.mentionId);
										mentionNode.remove();
										syncInputValueFromEditor();
									}
								}
							}}
							style={{
								outline: 'none',
								border: 'none',
								boxShadow: 'none',
								minHeight: 56,
								lineHeight: '20px',
								whiteSpace: 'pre-wrap',
								wordBreak: 'break-word',
								fontSize: 13,
								color: isInputDisabled ? '#37629d' : '#111827',
								cursor: isInputDisabled ? 'not-allowed' : 'text',
							}}
						/>
						{!inputValue.trim() && (
							<div style={{ position: 'absolute', top: 8, left: 8, color: '#94a3b8', pointerEvents: 'none', lineHeight: '20px' }}>
								{isInputDisabled ? 'Select one category badge to enable input' : inputPlaceholder}
							</div>
						)}
						{!isInputDisabled && commandSuggestion && (
							<div
								style={{
									position: 'absolute',
									top: 8,
									left: 8,
									pointerEvents: 'none',
									fontSize: 13,
									lineHeight: '20px',
									fontFamily: 'inherit',
									whiteSpace: 'pre-wrap',
									zIndex: 1,
								}}
							>
								<span style={{ color: 'transparent' }}>{commandSuggestion.prefix}</span>
								<span style={{ color: '#94a3b8' }}>{commandSuggestion.completion}</span>
							</div>
						)}
					</div>
				</AiInputPanelContent>

				{pickerOpen && pickerCategoryKey && (
					<div
						style={{
							position: 'absolute',
							zIndex: 30,
							left: 0,
							right: 0,
							top: openMenusUpward ? 'auto' : 72,
							bottom: openMenusUpward ? 'calc(100% + 8px)' : 'auto',
							borderRadius: 12,
							border: '1px solid #cbd5e1',
							background: '#fff',
							boxShadow: '0 16px 40px rgba(2, 6, 23, 0.18)',
							padding: 12,
						}}
					>
						<Stack direction="row" justifyContent="space-between" align="center" style={{ marginBottom: 8 }}>
							<strong>Select {selectedCategoryLabel} {isOtherCategorySelected ? 'files' : 'sections'}</strong>
							<Button variant="link" onClick={closePickerAndRemoveAtToken}>Close</Button>
						</Stack>

						<>
								{isPolicyCategorySelected && (
									<div style={{ marginTop: 8, marginBottom: 8 }}>
										<label style={{ fontSize: 12, color: '#475569', marginRight: 8 }}>Document type:</label>
										<select
											value={policyDocTypeFilter}
											onChange={(e) => {
												const nextType = e.target.value as 'policy' | 'procedure' | 'kod';
												setPolicyDocTypeFilter(nextType);
												setPickerSelectedIds({});
											}}
											style={{
												fontSize: 12,
												padding: '4px 8px',
												border: '1px solid #cbd5e1',
												borderRadius: 6,
												background: '#fff',
											}}
										>
											<option value="policy">Policy</option>
											<option value="procedure">Procedure</option>
											<option value="kod">KOD</option>
										</select>
									</div>
								)}
								{isHistoricalCategorySelected && pickerAvailableSourceDocTypes.length > 0 && (
									<div style={{ marginTop: 8, marginBottom: 8 }}>
										<label style={{ fontSize: 12, color: '#475569', marginRight: 8 }}>Document type:</label>
										<select
											value={historicalDocTypeFilter}
											onChange={(e) => {
												const nextType = String(e.target.value || '').toLowerCase();
												setHistoricalDocTypeFilter(nextType);
												setPickerSelectedIds({});
											}}
											style={{
												fontSize: 12,
												padding: '4px 8px',
												border: '1px solid #cbd5e1',
												borderRadius: 6,
												background: '#fff',
											}}
										>
											{pickerAvailableSourceDocTypes.map((type) => (
												<option key={type} value={type}>{type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}</option>
											))}
										</select>
									</div>
								)}
								{isOtherCategorySelected && pickerAvailableSourceDocTypes.length > 0 && (
									<div style={{ marginTop: 8, marginBottom: 8 }}>
										<label style={{ fontSize: 12, color: '#475569', marginRight: 8 }}>Document type:</label>
										<select
											value={otherDocTypeFilter}
											onChange={(e) => {
												const nextType = String(e.target.value || '').toLowerCase();
												setOtherDocTypeFilter(nextType);
												setPickerSelectedIds({});
											}}
											style={{
												fontSize: 12,
												padding: '4px 8px',
												border: '1px solid #cbd5e1',
												borderRadius: 6,
												background: '#fff',
											}}
										>
											{pickerAvailableSourceDocTypes.map((type) => (
												<option key={type} value={type}>{type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}</option>
											))}
										</select>
									</div>
								)}
								<div
									style={{ marginTop: 8, maxHeight: 230, overflowY: 'auto', border: '1px solid #e5e7eb', borderRadius: 8 }}
								>
									<div>
										{hasDocumentSectionStructure ? filteredDocumentRows.map(({ doc, sections }) => {
											const sectionIds = sections.map((section) => section.id);
											const selectedCount = sectionIds.filter((id) => Boolean(pickerSelectedIds[id])).length;
											const isDocumentExpanded = Boolean(expandedDocumentIds[doc.id]);

											return (
												<div key={doc.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
													<div
														style={{
															height: 44,
															display: 'grid',
															gridTemplateColumns: '22px 1fr auto',
															alignItems: 'center',
															padding: '0 10px',
															background: isDocumentExpanded ? '#eff6ff' : 'white',
															gap: 8,
															fontWeight: 600,
														}}
													>
														<input
															type="checkbox"
															checked={
																sectionIds.length > 0
																	? sectionIds.every((id) => Boolean(pickerSelectedIds[id]))
																	: Boolean(pickerSelectedIds[doc.id])
															}
															onChange={(e) => {
																const isChecked = e.target.checked;
																setPickerSelectedIds((prev) => {
																	const next = { ...prev, [doc.id]: isChecked };
																	sectionIds.forEach((sectionId) => {
																		next[sectionId] = isChecked;
																	});
																	return next;
																});

																if (!isChecked) {
																	removeSectionMentionFromEditor(doc, pickerCategoryKey);
																	sections.forEach((section) => {
																		removeSectionMentionFromEditor(section, pickerCategoryKey);
																	});
																}
															}}
														/>
														<span
															style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', cursor: 'pointer' }}
															onClick={() => setExpandedDocumentIds((prev) => ({ ...prev, [doc.id]: !Boolean(prev[doc.id]) }))}
														>
															{doc.name}
														</span>
														<Stack direction="row" gap="xs" align="center">
															{sectionIds.length === 0 && getStatusBadge(doc)}
															{selectedCount > 0 && (
																<StatusLabel size="xs" appearance="subtle-pill" variant="neutral" style={compactBadgeStyle}>{`${selectedCount}/${sectionIds.length}`}</StatusLabel>
															)}
														</Stack>
													</div>

													{(isDocumentExpanded || selectedCount > 0) && sections.map((section) => {
														const selected = Boolean(pickerSelectedIds[section.id]);
														return (
															<div
																key={section.id}
																style={{
																	height: 38,
																	display: 'grid',
																	gridTemplateColumns: '22px 1fr auto',
																	alignItems: 'center',
																	padding: '0 10px 0 26px',
																	background: selected ? '#eff6ff' : 'white',
																	gap: 8,
																	fontSize: 12,
																}}
															>
																<input
																	type="checkbox"
																	checked={selected}
																	onChange={(e) => {
																		const isChecked = e.target.checked;
																		setPickerSelectedIds((prev) => {
																			const next = { ...prev, [section.id]: isChecked };
																			if (!isChecked) {
																				next[doc.id] = false;
																			} else if (sectionIds.length > 0 && sectionIds.every((id) => Boolean(next[id]))) {
																				next[doc.id] = true;
																			}
																			return next;
																		});
																		if (!isChecked) {
																			removeSectionMentionFromEditor(doc, pickerCategoryKey);
																			removeSectionMentionFromEditor(section, pickerCategoryKey);
																		}
																	}}
																/>
																<span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{section.sectionId ? `${section.sectionId}: ${section.name}` : section.name}</span>
																<Stack direction="row" gap="xs" align="center">
																	{getStatusBadge(section)}
																	{recentFileIds.includes(section.id) && <StatusLabel size="xs" appearance="subtle-pill" variant="neutral" style={compactBadgeStyle}>Recent</StatusLabel>}
																</Stack>
															</div>
														);
													})}
												</div>
											);
										}) : fallbackFlatFiles.map((file) => {
											const selected = Boolean(pickerSelectedIds[file.id]);
											return (
												<div
													key={file.id}
													style={{
														height: 46,
														display: 'grid',
														gridTemplateColumns: '22px 1fr auto',
														alignItems: 'center',
														padding: '0 10px',
														borderBottom: '1px solid #f1f5f9',
														background: selected ? '#eff6ff' : 'white',
														gap: 8,
													}}
												>
													<input
														type="checkbox"
														checked={selected}
														onChange={(e) => {
															const isChecked = e.target.checked;
															setPickerSelectedIds((prev) => ({ ...prev, [file.id]: isChecked }));
															if (!isChecked) {
																removeSectionMentionFromEditor(file, pickerCategoryKey);
															}
														}}
													/>
													<span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{file.sectionId ? `${file.sectionId}: ${file.name}` : file.name}</span>
													<Stack direction="row" gap="xs" align="center">
														{getStatusBadge(file)}
														{recentFileIds.includes(file.id) && <StatusLabel size="xs" appearance="subtle-pill" variant="neutral" style={compactBadgeStyle}>Recent</StatusLabel>}
													</Stack>
												</div>
											);
										})}
										{((hasDocumentSectionStructure && filteredDocumentRows.length === 0) || (!hasDocumentSectionStructure && fallbackFlatFiles.length === 0)) && (
											<div style={{ padding: '10px', color: '#64748b', fontSize: 12 }}>
												{isCategoryDataLoading ? 'Loading documents...' : 'No matching sections'}
											</div>
										)}
									</div>
								</div>

								<Stack direction="row" justifyContent="space-between" align="center" style={{ marginTop: 8, width: '100%' }}>
									<span />
									<Button variant="primary" onClick={commitPickerSelection}>Insert</Button>
								</Stack>
							</>

					</div>
				)}
			</div>

			{showContextPanel && (
				<aside
					style={{
						border: '1px solid #dbe2ea',
						borderRadius: 12,
						padding: 12,
						background: 'var(--smart-context-bg, #fcfcfd)',
						minHeight: 200,
					}}
				>
					<h4 style={{ margin: '0 0 8px' }}>Selected Context</h4>
					{Object.keys(contextByCategory).length === 0 && (
						<div style={{ color: '#64748b', fontSize: 13 }}>No files selected yet.</div>
					)}

					{Object.entries(contextByCategory).map(([catKey, files]) => (
						<div key={catKey} style={{ marginBottom: 10 }}>
							<div style={{ fontWeight: 600, marginBottom: 6 }}>{categories.find((cat) => cat.key === catKey)?.label || catKey}:</div>
							<Stack direction="column" gap="xs">
								{files.map((file) => (
									<div key={file.id} style={{ ...chipStyle, justifyContent: 'space-between' }}>
										<span>{file.name}</span>
										<button
											type="button"
											style={{ border: 'none', background: 'transparent', cursor: 'pointer', color: '#1e3a8a' }}
											onClick={() => removeContextFile(catKey, file.id)}
											aria-label={`Remove ${file.name}`}
										>
											×
										</button>
									</div>
								))}
							</Stack>
						</div>
					))}
				</aside>
			)}
		</div>
	);
};

export default SmartReferenceEditor;
