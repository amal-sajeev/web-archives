import React from 'react';
import { useAiChat } from '../../hooks/useAiChat';
import { AiChatPresenter } from './AiChatPresenter';
import { useLocation, matchPath } from 'react-router-dom';

export const AiChatContainer: React.FC = () => {
  const {
    messages,
    inputValue,
    isGenerating,
    isInputDisabled,
    recommendedActions,
    handleInputChange,
    handleSend,
    handleWorkflowDecision,
    currentTab
  } = useAiChat();

  // Extract planId from URL
  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const planNumber = dashboardMatch?.params?.planId || '';

  return (
    <AiChatPresenter 
      messages={messages}
      inputValue={inputValue}
      isGenerating={isGenerating}
      isInputDisabled={isInputDisabled}
      recommendedActions={recommendedActions}
      onInputChange={handleInputChange}
      onSend={handleSend}
      onWorkflowDecision={handleWorkflowDecision}
      currentTab={currentTab}
      planNumber={planNumber}
    />
  );
};

export default AiChatContainer;
