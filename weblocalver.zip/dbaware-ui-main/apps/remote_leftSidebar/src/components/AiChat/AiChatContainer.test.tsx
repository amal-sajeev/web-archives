import React from 'react';
import { render, screen, renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { AiChatContainer } from './AiChatContainer';
import { useCurrentPath } from '../../hooks/useCurrentPath';

vi.mock('react-redux', async () => {
  const actual = await vi.importActual<typeof import('react-redux')>('react-redux');
  return {
    ...actual,
    useSelector: (selector: any) =>
      selector({
        scoping: {
          taskDefinitionKeyByPlan: {},
          nextAvailableActionsByPlan: {},
        },
      }),
  };
});

describe('AiChatContainer and useCurrentPath', () => {
  beforeEach(() => {
    window.history.pushState({}, '', '/preliminary-research/20440');
  });

  it('renders AiChatContainer wired to useAiChat with planNumber from route', () => {
    render(
      <MemoryRouter initialEntries={['/preliminary-research/20440']}>
        <Routes>
          <Route path="/:tab/:planId" element={<AiChatContainer />} />
        </Routes>
      </MemoryRouter>
    );
    expect(screen.getByText('AI Assistant')).toBeDefined();
    expect(screen.getByText('PRELIMINARY RESEARCH')).toBeDefined();
  });

  it('tracks pushState and replaceState route changes in useCurrentPath', () => {
    const { result } = renderHook(() => useCurrentPath());
    expect(result.current).toBe('/preliminary-research/20440');

    act(() => {
      window.history.pushState({}, '', '/scope-recommendation/20440');
    });
    expect(result.current).toBe('/scope-recommendation/20440');

    act(() => {
      window.history.replaceState({}, '', '/nor/20440');
    });
    expect(result.current).toBe('/nor/20440');
  });
});
