import React, { useEffect, useRef, useState } from 'react';
import { matchPath, useLocation, useNavigate } from 'react-router-dom';
import { Stack, Text } from '@wadk/ui';
import { AutoLoadingProgress, LoadingProgress } from 'com.db.rca.commons.afcc-components';
import { CheckmarkSolid } from '@wadk/icons';
import {
  getDataExtractionStatus,
  getPlanAvailability,
  getPlanArtifact,
  triggerDataExtraction,
} from '../../api/dataGatheringClient';
import styles from './AiChat.module.css';
import { SequentialFadeList } from './SequentialFadeList';

const DATA_GATHERING_SESSION_PREFIX = 'dbaware:data-gathering:session:';
const EXTRACTION_POLL_INTERVAL_MS = 1800000; // 30 minutes

type FlowState = 'loading' | 'done' | 'error';

declare global {
  interface WindowEventMap {
    'data-gathering:sync': CustomEvent<{
      planNumber: string;
      status: 'triggered' | 'polling' | 'completed' | 'failed';
      sessionId?: string;
      message?: string;
    }>;
  }
}

const getSessionStorageKey = (planNumber: string) => `${DATA_GATHERING_SESSION_PREFIX}${planNumber}`;

const savePendingSession = (planNumber: string, sessionId: string) => {
  window.sessionStorage.setItem(getSessionStorageKey(planNumber), sessionId);
};

const getPendingSession = (planNumber: string): string | null =>
  window.sessionStorage.getItem(getSessionStorageKey(planNumber));

const clearPendingSession = (planNumber: string) => {
  window.sessionStorage.removeItem(getSessionStorageKey(planNumber));
};

const emitDataGatheringSync = (
  planNumber: string,
  status: 'triggered' | 'polling' | 'completed' | 'failed',
  sessionId?: string,
  message?: string
) => {
  window.dispatchEvent(new CustomEvent('data-gathering:sync', {
    detail: { planNumber, status, sessionId, message }
  }));
};

const emitRemoveMessage = (id: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:remove-message', { detail: { id } }));
};

const emitDataGatheringSuccessMessage = () => {
  window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
    detail: { sender: 'ai', content: 'Data gathering has been generated successfully.' }
  }));
};

export const DataGatheringGenerationFlow: React.FC<{ messageId?: string }> = ({ messageId }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const planNumber = dashboardMatch?.params?.planId || '';

  const [flowState, setFlowState] = useState<FlowState>('loading');
  const [statusMessage, setStatusMessage] = useState('Checking data availability...');
  const mountedRef = useRef(false);
  const pollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startedRef = useRef(false);
  const successMessageSentRef = useRef(false);

  const clearPollTimer = () => {
    if (pollTimeoutRef.current) {
      clearTimeout(pollTimeoutRef.current);
      pollTimeoutRef.current = null;
    }
  };

  const hasArtifactData = (data: unknown): boolean => {
    if (data === null || data === undefined) return false;
    if (Array.isArray(data)) return data.length > 0;
    if (typeof data === 'object') return Object.keys(data as Record<string, unknown>).length > 0;
    if (typeof data === 'string') return data.trim().length > 0;
    return true;
  };

  const markAsCompleted = (currentPlanNumber: string, sessionId?: string, message?: string) => {
    clearPendingSession(currentPlanNumber);
    emitDataGatheringSync(currentPlanNumber, 'completed', sessionId, message);
    setFlowState('done');
    setStatusMessage('Data Gathering is ready to review.');
    if (!successMessageSentRef.current) {
      successMessageSentRef.current = true;
      if (messageId) {
        emitRemoveMessage(messageId);
      }
      emitDataGatheringSuccessMessage();
    }
  };

  const confirmAvailability = async (currentPlanNumber: string) => {
    setStatusMessage('Finalizing data gathering results...');
    const availability = await getPlanAvailability(currentPlanNumber);

    if (availability.available) {
      await getPlanArtifact(currentPlanNumber, 'lrr').catch(error => {
        console.warn('Failed to load LRR artifact after data extraction', error);
      });
      markAsCompleted(currentPlanNumber, availability.sessionId, availability.message);
      return true;
    }

    if (availability.sessionId) {
      savePendingSession(currentPlanNumber, availability.sessionId);
      emitDataGatheringSync(currentPlanNumber, 'polling', availability.sessionId, availability.message);
    }

    return false;
  };

  const pollStatus = async (currentPlanNumber: string, sessionId: string) => {
    if (!mountedRef.current) {
      return;
    }

    try {
      setStatusMessage('Fetching extracted plan data...');
      const status = await getDataExtractionStatus(currentPlanNumber, sessionId);

      if (!mountedRef.current) {
        return;
      }

      if (status.isComplete) {
        const isAvailable = await confirmAvailability(currentPlanNumber);

        if (!isAvailable && mountedRef.current) {
          pollTimeoutRef.current = setTimeout(() => {
            void pollStatus(currentPlanNumber, status.sessionId || sessionId);
          }, EXTRACTION_POLL_INTERVAL_MS);
        }
        return;
      }

      if (status.isFailed) {
        clearPendingSession(currentPlanNumber);
        emitDataGatheringSync(currentPlanNumber, 'failed', sessionId, status.message);
        setFlowState('error');
        return;
      }

      setStatusMessage(status.message || 'Data extraction in progress...');
      emitDataGatheringSync(currentPlanNumber, 'polling', sessionId, status.message);
      pollTimeoutRef.current = setTimeout(() => {
        void pollStatus(currentPlanNumber, sessionId);
      }, EXTRACTION_POLL_INTERVAL_MS);
    } catch (error) {
      console.error('Data Gathering polling failed', error);
      clearPendingSession(currentPlanNumber);
      emitDataGatheringSync(currentPlanNumber, 'failed', sessionId);
      if (mountedRef.current) {
        setFlowState('error');
      }
    }
  };

  useEffect(() => {
    mountedRef.current = true;
    navigate(planNumber ? `/data-gathering/${planNumber}` : '/data-gathering');

    if (!planNumber || startedRef.current) {
      return () => {
        mountedRef.current = false;
        clearPollTimer();
      };
    }

    startedRef.current = true;

    const startFlow = async () => {
      try {
        // Step 1: Always check if data gathering is already generated
        setStatusMessage('Checking data availability...');
        try {
          const existingArtifact = await getPlanArtifact(planNumber, 'current_details');
          if (!mountedRef.current) {
            return;
          }
          if (hasArtifactData(existingArtifact?.data)) {
            markAsCompleted(planNumber);
            return;
          }
        } catch (artifactError) {
          // Artifact not available yet — proceed to trigger extraction / resume polling
          console.info('current_details artifact not available, proceeding with data extraction', artifactError);
        }

        if (!mountedRef.current) {
          return;
        }

        // Step 2: Resume any in-flight extraction session
        const existingSessionId = getPendingSession(planNumber);

        if (existingSessionId) {
          emitDataGatheringSync(planNumber, 'polling', existingSessionId, 'Resuming data extraction...');
          await pollStatus(planNumber, existingSessionId);
          return;
        }

        // Step 3: Trigger a new data extraction
        setStatusMessage('Starting data extraction...');
        emitDataGatheringSync(planNumber, 'triggered', undefined, 'Starting data extraction...');

        const response = await triggerDataExtraction(planNumber);

        if (!mountedRef.current) {
          return;
        }

        if (!response.accepted || !response.sessionId) {
          throw new Error(response.message || 'Data extraction request was not accepted.');
        }

        savePendingSession(planNumber, response.sessionId);
        emitDataGatheringSync(planNumber, 'polling', response.sessionId, response.message || 'Data extraction in progress...');
        await pollStatus(planNumber, response.sessionId);
      } catch (error) {
        console.error('Data Gathering generation failed', error);
        clearPendingSession(planNumber);
        emitDataGatheringSync(planNumber, 'failed');
        if (mountedRef.current) {
          setFlowState('error');
        }
      }
    };

    void startFlow();

    return () => {
      mountedRef.current = false;
      clearPollTimer();
    };
  }, [navigate, planNumber]);

  if (flowState === 'error') {
    return <Text>Sorry, generating Data Gathering failed. Please try again.</Text>;
  }

  if (flowState === 'done') {
    return (
      <Stack direction="row" gap="sm" style={{ alignItems: 'center' }}>
        <CheckmarkSolid style={{ color: '#2E7D32', flexShrink: 0 }} />
        <Text>Data Gathering is ready to view.</Text>
      </Stack>
    );
  }

  return (
    <div className={styles['noir-response']}>
      <Stack gap="md" direction="column">
        <div style={{ fontWeight: 'bold' }}>Generating Data Gathering...</div>
        <SequentialFadeList
          title="Looking into..."
          listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
          items={[
            'Checking plan availability',
            'Triggering data extraction',
            'Polling extraction status',
            'Loading extracted artifacts',
            statusMessage
          ]}
          intervalMs={12000}
        />
        <AutoLoadingProgress
          intervalMs={180000}
          messages={['Starting extraction...', 'Preparing results...', 'Almost Done...']}
        />
      </Stack>
    </div>
  );
};