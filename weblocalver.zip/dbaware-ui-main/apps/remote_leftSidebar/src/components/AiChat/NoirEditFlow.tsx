import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Stack, Text, OutlineButton } from '@wadk/ui';
import { AutoLoadingProgress, LoadingProgress } from 'com.db.rca.commons.afcc-components';
import { CheckmarkSolid } from '@wadk/icons';
import { editNoir } from '../../api/noirClient';
import styles from './AiChat.module.css';
import { useLocation, matchPath } from 'react-router-dom';
import { PreviewModal } from './previewModal/previewModal';

const emitRemoveMessage = (id: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:remove-message', { detail: { id } }));
};

const emitAddMessage = (
  sender: 'user' | 'ai',
  content: React.ReactNode,
  id?: string
) => {
  window.dispatchEvent(
    new CustomEvent('ai-chat:add-message', { detail: { id, sender, content } })
  );
};

const emitNoirAccepted = (noirData: any, planId: string) => {
  window.dispatchEvent(new CustomEvent('noir:accepted', { detail: { noirData, planId } }));
};

const emitNoirPreviewVisibilityChanged = (visible: boolean, planId?: string) => {
  window.dispatchEvent(new CustomEvent('noir:preview-visibility-changed', {
    detail: { visible, planId: planId || '' }
  }));
};

export const NoirEditFlow: React.FC<{ messageId: string, instruction: string }> = ({ messageId, instruction }) => {
  const dispatch = useDispatch();
  const noirData = useSelector((state: any) => state.scoping?.noirData);

  const [status, setStatus] = useState<'loading' | 'done' | 'error'>('loading');
  const [editedData, setEditedData] = useState<any>(null);
  const [decided, setDecided] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const requestFired = useRef(false);

  // Extract planId from URL
  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const planId = dashboardMatch?.params?.planId;
  const resolvedPlanId = String(noirData?.original_data?.[0]?.['Plan Item Number'] || planId || '').trim();

  useEffect(() => {
    if (!noirData) {
      setStatus('error');
      return;
    }

    if (requestFired.current) return;
    requestFired.current = true;

    const payload = {
      plan_item_number: String(planId || noirData.original_data?.[0]?.['Plan Item Number']),
      user_instruction: instruction
    };

    dispatch({ type: 'scoping/setIsGeneratingNoir', payload: true });

    editNoir(payload)
      .then((responseData :any) => {
        const apiResult = responseData.data || responseData.payload || responseData;
        const updatedNoirData = {
          ...noirData,
          subject: apiResult.subject || noirData.subject,
          body: apiResult.body || noirData.body,
          email: apiResult.email_content || apiResult.email || noirData.email,
          original_data: apiResult.updated_data || noirData.original_data
        };
        setEditedData(updatedNoirData);
        setStatus('done');
      })
      .catch(err => {
        console.error('editNoir failed', err);
        setStatus('error');
      })
      .finally(() => {
        dispatch({ type: 'scoping/setIsGeneratingNoir', payload: false });
      });
  }, [instruction, noirData]);

  const handleAccept = () => {
    setDecided(true);
    dispatch({ type: 'scoping/setNoirData', payload: editedData });
    emitRemoveMessage(messageId);
    emitNoirAccepted(editedData, resolvedPlanId);

    emitAddMessage('ai', (
      <Stack direction="row" gap="sm" style={{ alignItems: 'center' }}>
        <CheckmarkSolid style={{ color: '#2E7D32', flexShrink: 0 }} />
        <Text>NOIR has been updated successfully.</Text>
      </Stack>
    ));
  };

  const handleOpenPreview = () => {
    setIsModalOpen(true);
    emitNoirPreviewVisibilityChanged(true, resolvedPlanId);
  };

  const handleClosePreview = () => {
    setIsModalOpen(false);
    emitNoirPreviewVisibilityChanged(false, resolvedPlanId);
  };

  useEffect(() => {
    return () => {
      emitNoirPreviewVisibilityChanged(false, resolvedPlanId);
    };
  }, [resolvedPlanId]);

  if (status === 'loading') {
    return (
      <Stack gap="md" direction="column">
        <Text fontWeight="bold">Updating NOIR...</Text>
        <AutoLoadingProgress
          intervalMs={120000}
          messages={['Applying your instructions...', 'Almost Done...', 'Processing...']}
        />
      </Stack>
    );
  }

  if (status === 'error') {
    return <Text>Sorry, updating the NOIR failed. Please try again.</Text>;
  }

  let formattedEmailContent = '';
  if (editedData?.subject && editedData?.body) {
    formattedEmailContent = `Subject: ${editedData.subject}\n\nBody:\n${editedData.body}`;
  } else if (editedData?.email) {
    formattedEmailContent = editedData.email.replace(/\\n/g, '\n').replace(/\\/g, '');
  }

  return (
    <div className={styles['noir-response']}>
      <div style={{
        backgroundColor: '#FFFFFF',
        borderRadius: '8px',
        padding: '16px',
        border: '1px solid #E0E0E0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
      }}>
        <div style={{ marginBottom: '16px', paddingBottom: '5px', borderBottom: '1px solid rgb(206, 224, 255)' }}>
          <Text fontWeight="bold" size="md">
            Refined Output is ready!
          </Text>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Text size="sm" className={styles['noir-text']}>
            NOIR output is produced through the analysis of key metadata contained within dbAware.
          </Text>

          <div>
            <Text fontWeight="bold" size="sm" style={{ marginBottom: '12px', display: 'block' }}>
              What's included:
            </Text>
            <ul className={styles['noir-preview-list']}>
              <li>Risks</li>
              <li>Key Control</li>
              <li>Timelines</li>
              <li>Next Steps</li>
              <li>Request for Information</li>
            </ul>
          </div>

          {!decided && (
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-start', marginTop: '16px' }}>
              <OutlineButton
                variant="primary"
                onClick={handleAccept}
              >
                Accept
              </OutlineButton>
              <OutlineButton
                variant="primary"
                onClick={handleOpenPreview}
              >
                View Preview
              </OutlineButton>
            </div>
          )}
        </div>
      </div>

      <PreviewModal
        isOpen={isModalOpen}
        title="NOIR Preview"
        subject={editedData?.subject}
        body={editedData?.body}
        onClose={handleClosePreview}
        onAccept={() => {
          handleClosePreview();
          handleAccept();
        }}
      />
    </div>
  );
};