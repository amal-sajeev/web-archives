import React from 'react';
import { useAiChat } from '../../../hooks/useAiChat';
import { useCurrentPath } from '../../../hooks/useCurrentPath';
import { AiChatPresenter } from '../AiChatPresenter/AiChatPresenter';
import { useLocation, matchPath } from 'react-router-dom';

export const AiChatContainer: React.FC = () => {
  const {
    messages,
    inputValue,
    isGenerating,
    isInputDisabled,
    recommendedActions,
    handleInputChange,
    handleSend,
    currentTab
  } = useAiChat();

  // Extract planId from URL (supporting both live MFE paths and MemoryRouter unit tests)
  const location = useLocation();
  const windowPath = useCurrentPath();
  const cleanWindowPath = (windowPath || '').replace(/^\/dbaware-ui(?=\/|$)/, '');
  const cleanRouterPath = (location.pathname || '').replace(/^\/dbaware-ui(?=\/|$)/, '');
  const effectivePath =
    cleanWindowPath && cleanWindowPath !== '/'
      ? cleanWindowPath
      : cleanRouterPath || cleanWindowPath || '/';
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, effectivePath);
  const planNumber = dashboardMatch?.params?.planId || '';

  return (
    <AiChatPresenter 
      messages={messages}
      inputValue={inputValue}
      isGenerating={isGenerating}
      isInputDisabled={isInputDisabled}
      recommendedActions={recommendedActions}
      onInputChange={handleInputChange}
      onSend={handleSend}
      currentTab={currentTab}
      planNumber={planNumber}
    />
  );
};

export default AiChatContainer;
