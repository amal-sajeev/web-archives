import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation, matchPath } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { Text, Button, OutlineButton, Stack, TextInput } from '@wadk/ui';
import { CheckmarkSolid, PlusSolid, DocumentAddSolid, XSolid, SingleChevronDownSolid, SingleChevronUpSolid } from '@wadk/icons';
import { AiQuestionsPrompt } from 'com.db.rca.commons.afcc-components';
import { AddRecipientModal } from './AddRecipientModal';
import { PreviewModal } from './previewModal/previewModal';
import type { RecipientItem } from '../../types/aiChat';
import { generateNor, type NorGenerateResponse } from '../../api/norClient';
import styles from './AiChat.module.css';
import { SequentialFadeList } from './SequentialFadeList';

export interface NorResponsePayload {
  /** Full response returned by gateway action `GENERATE_NOR`. */
  norData: NorGenerateResponse;
  /** Convenience aggregates used to render the preview bubble. */
  findingsMapped: number;
  taxonomyAligned: boolean;
  recipientsValidated: boolean;
  message: string;
}

// --- Chat-bus helpers ---------------------------------------------------
const emitAddMessage = (
  sender: 'user' | 'ai',
  content: React.ReactNode,
  id?: string
) => {
  window.dispatchEvent(
    new CustomEvent('ai-chat:add-message', { detail: { id, sender, content } })
  );
};

const emitRemoveMessage = (id: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:remove-message', { detail: { id } }));
};

// --- Read-only recipients table (rendered inside a user chat bubble) ----
const RecipientsSummary: React.FC<{ recipients: RecipientItem[] }> = ({ recipients }) => {
  const [isExpandedSummary, setIsExpandedSummary] = React.useState(false);

  const displayedRecipients = isExpandedSummary ? recipients : recipients.slice(0, 5);
  const hasMoreRecipients = recipients.length > 5;

  return (
    <div className={styles['recipients-summary']}>
      <Text className={styles['recipients-summary-title']} fontWeight="bold">
        Recipient list uploaded ({recipients.length})
      </Text>
      <Text
        style={{
          fontSize: '12px',
          marginTop: '12px',
          whiteSpace: 'normal',
          overflowWrap: 'anywhere',
          wordBreak: 'break-word',
          lineHeight: '1.5'
        }}
      >
        {displayedRecipients.map(item => item.attachment).join(', ')}
      </Text>

      {hasMoreRecipients && (
        <div style={{ marginTop: '12px', display: 'flex', justifyContent: 'flex-start' }}>
          <Button
            variant="link"
            onClick={() => setIsExpandedSummary(!isExpandedSummary)}
            icon={isExpandedSummary ? <SingleChevronUpSolid /> : <SingleChevronDownSolid />}
            style={{ color: '#0550D1', fontSize: '12px', fontWeight: 500 }}
          >
            {isExpandedSummary
              ? `Show Less`
              : `Show More (+${recipients.length - 5})`}
          </Button>
        </div>
      )}
    </div>
  );
};

// --- AI "NOR Accepted" follow-up bubble --------------------------------
const emitSendMessage = (content: string) => {
  window.dispatchEvent(new CustomEvent('ai-chat:send-message', { detail: { content } }));
};

const emitNorAccepted = (norData: NorGenerateResponse, planId: string) => {
  window.dispatchEvent(new CustomEvent('nor:accepted', { detail: { norData, planId } }));
};

const emitNorPreviewOpened = (planId?: string) => {
  window.dispatchEvent(new CustomEvent('nor:preview-opened', {
    detail: { planId: planId || '' }
  }));
};

const emitNorPreviewVisibilityChanged = (visible: boolean, planId?: string) => {
  window.dispatchEvent(new CustomEvent('nor:preview-visibility-changed', {
    detail: { visible, planId: planId || '' }
  }));
};

const NorAcceptedResponse: React.FC = () => (
  <Stack direction="row" gap="sm" style={{ alignItems: 'center' }}>
    <CheckmarkSolid style={{ color: '#2E7D32', flexShrink: 0 }} />
    <Text>Your NOR output has been generated and is ready to view.</Text>
  </Stack>
);

// --- NOR Accepted Response ---
const NorAcceptedFinal: React.FC = () => (
  <Stack direction="row" gap="sm" style={{ alignItems: 'center' }}>
    <CheckmarkSolid style={{ color: '#2E7D32', flexShrink: 0 }} />
    <Text>Your NOR output has been successfully submitted.</Text>
  </Stack>
);

// --- NOR Preview with What's Next Component ---
interface NorPreviewWithNextProps {
  norData: NorGenerateResponse;
  messageId: string;
  planId?: string;
}

const NorPreviewWithNext: React.FC<NorPreviewWithNextProps> = ({ norData, messageId, planId }) => {
  const navigate = useNavigate();
  
  const handleAccept = () => {
    // Emit user message for acceptance
    emitAddMessage('user', 'Accept NOR');
    // Remove preview message immediately
    emitRemoveMessage(messageId);
    // Show acceptance message
    emitAddMessage('ai', <NorAcceptedFinal />);
    // Emit event that NOR has been accepted
    emitNorAccepted(norData, planId || '');
    // Navigate after showing acceptance
    setTimeout(() => {
      navigate(planId ? `/nor/${planId}` : '/nor');
    }, 1500);
  };

  const handleEditOption = (option: string) => {
    // Remove the preview message immediately
    emitRemoveMessage(messageId);
    
    emitSendMessage(option);
  };

  return (
    <div>
      <NorPreview
        norData={norData}
        onAccept={handleAccept}
        onViewPreview={() => {
          emitNorPreviewOpened(planId);
          emitNorPreviewVisibilityChanged(true, planId);
        }}
        onClosePreview={() => emitNorPreviewVisibilityChanged(false, planId)}
      />
      <WhatsNextOptions onOptionClick={handleEditOption} />
    </div>
  );
};

// --- What's Next Questions Component (using AiQuestionsPrompt) ---
interface WhatsNextOptionsProps {
  onOptionClick?: (option: string) => void;
}

const WhatsNextOptions: React.FC<WhatsNextOptionsProps> = ({ onOptionClick }) => {
  const handleOptionClick = (option: string) => {
    if (onOptionClick) {
      onOptionClick(option);
    }
  };

  return (<>
    <Text fontWeight="bold" style={{marginTop : "10px"}}>What&rsquo;s next?</Text>
    <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
      <AiQuestionsPrompt onClick={() => handleOptionClick('Make the tone more formal')}>
        Make the tone more formal
      </AiQuestionsPrompt>
      <AiQuestionsPrompt onClick={() => handleOptionClick('Make it more concise')}>
        Make it more concise
      </AiQuestionsPrompt>
    </div>
  </>
  );
};

// --- NOR Preview Component ---
interface NorPreviewProps {
  norData: NorGenerateResponse;
  onAccept?: () => void;
  onViewPreview?: () => void;
  onClosePreview?: () => void;
}

const NorPreview: React.FC<NorPreviewProps> = ({ norData, onAccept, onViewPreview, onClosePreview }) => {
  const [isModalOpen, setIsModalOpen] = React.useState(false);

  const handleViewPreview = () => {
    setIsModalOpen(true);
    if (onViewPreview) {
      onViewPreview();
    }
  };

  const handleAccept = () => {
    if (onAccept) {
      onAccept();
    }
  };

  return (
    <>
      <div style={{
        backgroundColor: '#FFFFFF',
        borderRadius: '8px',
        padding: '16px',
        border: '1px solid #E0E0E0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
      }}>
        <div style={{ marginBottom: '16px', paddingBottom: '5px', borderBottom: '1px solid rgb(206, 224, 255)' }}>
          <Text fontWeight="bold" size="md">
            Preview - NOR output
          </Text>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Text size="sm" style={{ color: '#555' }}>
            NOR output is produced through the analysis of key metadata contained within dbAware.
          </Text>

          <div>
            <Text fontWeight="bold" size="sm" style={{ marginBottom: '12px', display: 'block' }}>
              What's included:
            </Text>
            <ul className={styles['nor-preview-list']}>
              <li>Risks</li>
              <li>Key Control</li>
              <li>Timelines</li>
              <li>Next Steps</li>
              <li>Request for Information</li>
            </ul>
          </div>

          <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-start', marginTop: '16px' }}>
            <OutlineButton onClick={handleAccept}>
              Accept
            </OutlineButton>
            <Button variant="primary" onClick={handleViewPreview}>
              View Preview
            </Button>
          </div>
        </div>
      </div>

      <PreviewModal
        isOpen={isModalOpen}
        title="NOR Preview"
        subject={norData.subject}
        body={norData.body}
        onClose={() => {
          setIsModalOpen(false);
          if (onClosePreview) {
            onClosePreview();
          }
        }}
        onAccept={() => {
          setIsModalOpen(false);
          if (onClosePreview) {
            onClosePreview();
          }
          if (onAccept) {
            onAccept();
          }
        }}
      />
    </>
  );
};

// --- NOR Loading Bubble ---
const NorLoadingBubble: React.FC<{ isSkipping: boolean, isCompleted: boolean }> = ({ isSkipping }) => {
  return (
    <Stack gap="md" direction="column">
      {isSkipping ? (
        <SequentialFadeList
          title="Looking into..."
          listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
          items={['Reviewing regulatory obligations',
            'Analysing policies',
            'Comparing historical scope',
            'Reviewing open findings',
            'Mapping risks and controls',
            'Assessing evidence ',
            'Developing scope direction',
            'processing....']}
        />
      ) : (
        <SequentialFadeList
          title="Aligning with:"
          listClassName={styles['nor-loading-list']}
          items={[
            'Review objective',
            'Ownership',
            'Assessment unit',
            'Risk type, controls & source lineage'
          ]}
          intervalMs={40000}
        />
      )}

      {/* Keeping parity with NOIR loading experience */}
    </Stack>
  );
};

interface NorGeneratedResponseProps {
  payload: NorResponsePayload;
  onAccept: () => void;
}

const NorGeneratedResponse: React.FC<NorGeneratedResponseProps> = ({ payload, onAccept }) => {
  return (
    <div className={styles['nor-response']}>
      <div className={styles['nor-preview']}>
        <div className={styles['nor-preview-label']}>
          <Text fontWeight="bold">Preview - NOR Output</Text>
        </div>

        <div style={{ maxHeight: '300px', overflowY: 'auto', paddingRight: '8px', paddingBottom: '8px' }}>
          <div style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: '14px', lineHeight: '1.5' }}>
            {payload.message ? payload.message.replace(/\\n/g, '\n').replace(/\\/g, '') : ''}
          </div>
          <ul className={styles['nor-preview-list']} style={{ marginTop: '16px' }}>
            <li>
              <Text variant="secondary">{payload.findingsMapped} Findings mapped</Text>
            </li>
            <li>
              <Text variant="secondary">
                Taxonomy alignment {payload.taxonomyAligned ? 'completed' : 'pending'}
              </Text>
            </li>
            <li>
              <Text variant="secondary">
                Recipients {payload.recipientsValidated ? 'validated' : 'pending'}
              </Text>
            </li>
          </ul>
        </div>

        <div className={styles['nor-actions']}>
          <Button onClick={onAccept} variant="primary">
            Accept
          </Button>
        </div>
      </div>
    </div>
  );
};

// --- Main flow (initial upload bubble) ----------------------------------
interface NorGenerationFlowProps {
  messageId?: string;
}

export const NorGenerationFlow: React.FC<NorGenerationFlowProps> = ({ messageId }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isNorGenerationInFlightRef = useRef(false);

  // Inject keyframe animation if not already present
  React.useEffect(() => {
    if (!document.getElementById('recipient-badge-animation')) {
      const style = document.createElement('style');
      style.id = 'recipient-badge-animation';
      style.textContent = `
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  const [step, setStep] = useState<'loading' | 'preview' | 'recipients' | 'error'>('recipients');
  const [payload, setPayload] = useState<NorResponsePayload | null>(null);

  const [isAddMoreOpen, setIsAddMoreOpen] = useState(false);
  const [recipients, setRecipients] = useState<RecipientItem[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [errors, setErrors] = useState<string[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [newRecipientIndices, setNewRecipientIndices] = useState<Set<number>>(new Set());
  const isSubmittingRef = useRef(false);

  useEffect(() => {
    dispatch({ type: 'scoping/setRecipients', payload: recipients });
  }, [recipients, dispatch]);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const parseEmails = (text: string) => {
    return text
      .split(',')
      .map(email => email.trim())
      .filter(email => email.length > 0);
  };

  const handleAddRecipients = () => {
    const emails = parseEmails(inputValue);
    const newErrors: string[] = [];
    const validEmails: string[] = [];

    emails.forEach(email => {
      if (validateEmail(email)) {
        validEmails.push(email);
      } else {
        newErrors.push(email);
      }
    });

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    if (validEmails.length > 0) {
      const startIndex = recipients.length;
      const newIndices = new Set<number>();
      for (let i = 0; i < validEmails.length; i++) {
        newIndices.add(startIndex + i);
      }
      setNewRecipientIndices(newIndices);

      const newRecipients: RecipientItem[] = validEmails.map((email) => ({
        id: Math.random().toString(36).substr(2, 9),
        type: 'Email',
        attachment: email,
        status: 'Added',
        emails: [email]
      }));

      setRecipients([...recipients, ...newRecipients]);
      setInputValue('');
      setErrors([]);

      setTimeout(() => {
        setNewRecipientIndices(new Set());
      }, 300);
    }
  };

  const handleRemoveRecipient = (id: string) => {
    setRecipients(prev => prev.filter(r => r.id !== id));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
    setErrors([]);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddRecipients();
    }
  };

  // Extract planId from URL
  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const planId = dashboardMatch?.params?.planId;

  // Open recipient-first flow. NOR generation runs on Submit/Skip.
  useEffect(() => {
    window.dispatchEvent(new CustomEvent('ai-chat:set-input-disabled', { detail: { disabled: true } }));
    navigate(planId ? `/nor/${planId}` : '/nor');
    dispatch({ type: 'nor/setIsGeneratingNor', payload: false });

    return () => {
      if (!isNorGenerationInFlightRef.current) {
        dispatch({ type: 'nor/setIsGeneratingNor', payload: false });
      }
      window.dispatchEvent(new CustomEvent('ai-chat:set-input-disabled', { detail: { disabled: false } }));
    };
  }, []);

  const handleAcceptPreview = () => {
    if (payload) {
      dispatch({ type: 'nor/setNorData', payload: payload.norData });
    }
    navigate(planId ? `/nor/${planId}` : '/nor');
    setStep('recipients');
  };

  const handleSubmitRecipients = (skipRecipients = false) => {
    if (isSubmittingRef.current || !planId) return;
    if (!skipRecipients && recipients.length === 0) return;

    if (skipRecipients) {
      emitAddMessage('user', 'Skip recipient entry');
    } else {
      emitAddMessage('user', <RecipientsSummary recipients={recipients} />);
    }

    window.dispatchEvent(new CustomEvent('ai-chat:nor-generation-started', {
      detail: { planNumber: String(planId || '').trim() }
    }));

    setStep('preview');
    isSubmittingRef.current = true;
    isNorGenerationInFlightRef.current = true;
    dispatch({ type: 'nor/setIsGeneratingNor', payload: true });

    generateNor(planId)
      .then(norData => {
        const item = norData.original_data?.[0];
        const combinedContent = norData.body && norData.subject
          ? `Subject: ${norData.subject}\n\nBody:\n${norData.body}`
          : (norData.email_content || norData.email);
        const emailContent = combinedContent || item?.['Description of Plan Item'];

        const nextPayload: NorResponsePayload = {
          norData,
          findingsMapped: 0,
          taxonomyAligned: true,
          recipientsValidated: (norData.recipients?.length ?? 0) > 0,
          message: emailContent ?? 'The NOR data has been successfully generated.'
        };

        setPayload(nextPayload);
        dispatch({ type: 'nor/setNorData', payload: norData });
        emitAddMessage('ai', <NorAcceptedResponse />);

        setTimeout(() => {
          const previewMessageId = Math.random().toString(36).substr(2, 9);
          emitAddMessage(
            'ai',
            <NorPreviewWithNext
              norData={norData}
              messageId={previewMessageId}
              planId={planId}
            />,
            previewMessageId
          );
        }, 1000);

        if (messageId) {
          emitRemoveMessage(messageId);
        }
      })
      .catch(err => {
        console.error('Failed to generate NOR', err);
        emitAddMessage('ai', 'Sorry, generating the NOR failed. Please try again.');
      })
      .finally(() => {
        isSubmittingRef.current = false;
        isNorGenerationInFlightRef.current = false;
        dispatch({ type: 'nor/setIsGeneratingNor', payload: false });
        window.dispatchEvent(new CustomEvent('ai-chat:nor-generation-finished', {
          detail: { planNumber: String(planId || '').trim() }
        }));
      });
  };

  if (step === 'loading') {
    return <NorLoadingBubble isSkipping={false} isCompleted={payload !== null} />;
  }

  if (step === 'error') {
    return <Text>Sorry, generating the NOR failed. Please try again.</Text>;
  }

  if (step === 'preview' && payload) {
    return (
      <NorGeneratedResponse
        payload={payload}
        onAccept={handleAcceptPreview}
      />
    );
  }

  if (step === 'recipients') {
    const displayedRecipients = isExpanded ? recipients : recipients.slice(0, 4);
    const hasMoreRecipients = recipients.length > 4;

    const handleModalSubmit = (items: any[]) => {
      const newErrors: string[] = [];
      const validEmails: string[] = [];

      items.forEach(item => {
        if (item.emails && Array.isArray(item.emails)) {
          item.emails.forEach((email: string) => {
            if (validateEmail(email)) {
              validEmails.push(email);
            } else {
              newErrors.push(email);
            }
          });
        }
      });

      if (newErrors.length > 0) {
        setErrors(newErrors);
      } else {
        setErrors([]);
      }

      if (validEmails.length > 0) {
        const startIndex = recipients.length;
        const newIndices = new Set<number>();
        for (let i = 0; i < validEmails.length; i++) {
          newIndices.add(startIndex + i);
        }
        setNewRecipientIndices(newIndices);

        // Create individual recipient entries for each email from the file
        const newRecipients: RecipientItem[] = validEmails.map((email) => ({
          id: Math.random().toString(36).substr(2, 9),
          type: 'File' as const,
          attachment: email,
          status: 'Uploaded',
          emails: [email]
        }));

        setRecipients([...recipients, ...newRecipients]);

        setTimeout(() => {
          setNewRecipientIndices(new Set());
        }, 300);
      }
    };

    return (
      <div className={styles['recipients-container']} style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <div>
          <Text className={styles['recipients-header']}>
            Would you like to upload the Recipient list?
          </Text>
          <div style={{ width: '85%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1px' }}>
            <Text style={{ fontWeight: '400' }}>Add Recipients</Text>
            <Button
              icon={<DocumentAddSolid />}
              variant="link"
              onClick={() => setIsAddMoreOpen(true)}
            >
              Upload Files
            </Button>
          </div>

          <Stack direction="row" gap="base">
            <Stack grow={1}>
              <TextInput
                style={{ width: "100%" }}
                placeholder="Add or paste a recipient list"
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                value={inputValue}
              />
            </Stack>
            <Stack grow={0}>
              <Button icon={<PlusSolid />} variant="link" onClick={handleAddRecipients}>
                Add
              </Button>
            </Stack>
          </Stack>

          <Text style={{ fontSize: '11px', color: 'rgba(23, 25, 69, 0.75)', marginBottom: '12px', display: 'block' }}>
            Use comma-separated addresses
          </Text>

          {errors.length > 0 && (
            <div style={{
              padding: '8px',
              backgroundColor: '#FFEBEE',
              border: '1px solid #FFCDD2',
              borderRadius: '4px',
              marginBottom: '12px'
            }}>
              <Text style={{ color: '#C62828', fontSize: '12px', fontWeight: 500 }}>
                Invalid email(s): {errors.join(', ')}
              </Text>
            </div>
          )}

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', padding: '4px 0', minHeight: 'auto', marginBottom: recipients.length > 0 ? '16px' : '0' }}>
            {displayedRecipients.map((recipient, index) => (
              <div
                key={recipient.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '2px',
                  padding: '2px 6px',
                  backgroundColor: '#E3F1FF',
                  borderRadius: '4px',
                  border: '1px solid #B3D9FF',
                  fontSize: '11px',
                  color: '#171945',
                  animation: newRecipientIndices.has(index) ? 'fadeIn 0.3s ease-out forwards' : 'none'
                }}
              >
                <span>{recipient.attachment || recipient.emails?.[0]}</span>
                <button
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '0',
                    marginLeft: '4px',
                    color: '#0550D1',
                    transition: 'color 0.2s ease'
                  }}
                  onClick={() => handleRemoveRecipient(recipient.id)}
                  type='button'
                  onMouseEnter={(e) => (e.currentTarget.style.color = '#0340A6')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = '#0550D1')}
                >
                  <XSolid style={{ width: '14px', height: '14px' }} />
                </button>
              </div>
            ))}
          </div>

          {hasMoreRecipients && (
            <div style={{ marginTop: '8px', display: 'flex', justifyContent: 'flex-start' }}>
              <Button
                variant="link"
                onClick={() => setIsExpanded(!isExpanded)}
                icon={isExpanded ? <SingleChevronUpSolid /> : <SingleChevronDownSolid />}
                style={{ color: '#0550D1', fontSize: '12px', fontWeight: 500 }}
              >
                {isExpanded
                  ? `Show Less (${recipients.length})`
                  : `Show More (+${recipients.length - 4})`
                }
              </Button>
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', alignSelf: 'stretch' }}>
            <div className='xcm' style={{ display: 'flex', gap: '8px', margin: '15px' }}>
              {recipients.length === 0 && (
                <Button
                  variant="link"
                  onClick={() => handleSubmitRecipients(true)}
                >
                  Skip for now
                </Button>
              )}
              <OutlineButton
                disabled={recipients.length === 0}
                onClick={() => handleSubmitRecipients()}
              >
                Submit
              </OutlineButton>
            </div>
          </div>
        </div>

        <AddRecipientModal
          isOpen={isAddMoreOpen}
          onClose={() => setIsAddMoreOpen(false)}
          onSubmit={handleModalSubmit}
        />
      </div>
    );
  }

  return null;
};
