import React from 'react';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { BrowserRouter } from 'react-router-dom';
import { AiChatPresenter } from './AiChatPresenter';

let mockState: any = {
    scoping: {
        taskDefinitionKeyByPlan: {},
        nextAvailableActionsByPlan: {},
    },
};

vi.mock('react-redux', async () => {
    const actual = await vi.importActual<typeof import('react-redux')>('react-redux');
    return {
        ...actual,
        useSelector: (selector: any) => selector(mockState),
    };
});

// 1. Mock the internal WADK and AFCC components to isolate our presenter logic
vi.mock('@wadk/icons', () => ({
    AiLogoSolid: () => <svg data-testid="icon-ai-logo" />,
    CrosshairOutline: () => <svg data-testid="icon-screenshot" />,
    AttachSolid: () => <svg data-testid="icon-attach" />,
    PaperPlaneOutline: () => <svg data-testid="icon-paper-plane" />,
    CheckmarkCircleOutline: () => <svg data-testid="icon-checkmark" />,
    SingleChevronDownSolid: () => <svg data-testid="icon-chevron-down" />,
    SingleChevronUpSolid: () => <svg data-testid="icon-chevron-up" />,
    CheckmarkSolid: () => <svg data-testid="icon-check" />,
    DocumentOutline: () => <svg data-testid="icon-doc" />,
}));

vi.mock('com.db.rca.commons.afcc-components', () => ({
    AiInputPanelContent: ({ children, actions }: any) => (
        <div data-testid="mock-input-panel">
            <div data-testid="mock-actions">{actions}</div>
            {children}
        </div>
    ),
    AiInputPanelTextarea: ({ value, onChange, onKeyDown, placeholder }: any) => (
        <textarea
            data-testid="mock-textarea"
            value={value}
            onChange={onChange}
            onKeyDown={onKeyDown}
            placeholder={placeholder}
        />
    ),
    AiQuestion: ({ children }: any) => <div data-testid="mock-ai-question">{children}</div>,
    AiResponse: ({ children }: any) => <div data-testid="mock-ai-response">{children ?? 'Generating response...'}</div>,
    AiQuestions: ({ children, header }: any) => (
        <div data-testid="mock-ai-questions">
            {header}
            {children}
        </div>
    ),
    AiQuestionsPrompt: ({ children, onClick }: any) => <button type="button" onClick={onClick}>{children}</button>,
    AutoLoadingProgress: () => <div data-testid="mock-auto-loading-progress" />,
}));

vi.mock('@wadk/ui', () => ({
    Button: ({ children, onClick, disabled }: any) => <button type="button" onClick={onClick} disabled={disabled}>{children}</button>,
    Card: ({ children }: any) => <div data-testid="mock-card">{children}</div>,
    CardHeader: ({ children }: any) => <div data-testid="mock-card-header">{children}</div>,
    CardTitle: ({ content }: any) => <h1>{content}</h1>,
    LeftSlot: ({ children }: any) => <div>{children}</div>,
    Stack: ({ children }: any) => <div>{children}</div>,
    StatusLabel: ({ children }: any) => <span>{children}</span>,
    TextInput: ({ value, onChange, placeholder }: any) => (
        <input value={value || ''} onChange={onChange} placeholder={placeholder} />
    ),
}));

vi.mock('../../CurrentPlan/CurrentPlan.tsx', () => ({
    CurrentPlan: () => <div data-testid="mock-current-plan" />,
}));

vi.mock('../Loader/SequentialFadeList.tsx', () => ({
    SequentialFadeList: () => <div data-testid="mock-sequential-fade-list" />,
}));

describe('AiChatPresenter', () => {
    const mockOnInputChange = vi.fn();
    const mockOnSend = vi.fn();

    const defaultProps = {
        messages: [],
        inputValue: '',
        isGenerating: false,
        isInputDisabled: false,
        recommendedActions: [
            { id: '1', label: 'Generate Preliminary Research' },
            { id: '2', label: 'Review objective' }
        ],
        onInputChange: mockOnInputChange,
        onSend: mockOnSend,
    };

    beforeEach(() => {
        vi.clearAllMocks();
        mockState = {
            scoping: {
                taskDefinitionKeyByPlan: {},
                nextAvailableActionsByPlan: {},
            },
        };
    });

    afterEach(() => {
        cleanup();
    });

    it('renders recommended actions when the message list is empty', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} />
            </BrowserRouter>
        );

        expect(screen.getByText('Recommended Actions')).toBeDefined();
        expect(screen.getByText('Generate NOIR')).toBeDefined();
    });

    it('calls onSend with the action label when a recommended action is clicked', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} />
            </BrowserRouter>
        );

        const actionBtn = screen.getByText('Generate NOIR');
        fireEvent.click(actionBtn);

        expect(mockOnSend).toHaveBeenCalledTimes(1);
        expect(mockOnSend).toHaveBeenCalledWith('Generate NOIR');
    });

    it('hides recommended actions and renders chat bubbles when messages exist', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    messages={[{ id: 'msg-1', content: 'Hello AI', sender: 'user', timestamp: new Date().toISOString() }]}
                />
            </BrowserRouter>
        );

        expect(screen.queryByText('Recommended Actions')).toBeNull();
        expect(screen.getByText('Hello AI')).toBeDefined();
    });

    it('calls onInputChange when the user types in the textarea', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} />
            </BrowserRouter>
        );

        const textarea = screen.getByTestId('mock-textarea');
        fireEvent.change(textarea, { target: { value: 'New prompt' } });

        expect(mockOnInputChange).toHaveBeenCalledTimes(1);
    });

    it('calls onSend when the Enter key is pressed without the Shift key', () => {
        // Pass a valid input value so the send action isn't conceptually "disabled" by our tests
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} inputValue="Hello" />
            </BrowserRouter>
        );

        const textarea = screen.getByTestId('mock-textarea');

        // Pressing shift+enter shouldn't trigger send (usually creates a newline)
        fireEvent.keyDown(textarea, { key: 'Enter', shiftKey: true });
        expect(mockOnSend).not.toHaveBeenCalled();

        // Pressing enter alone should trigger send
        fireEvent.keyDown(textarea, { key: 'Enter', shiftKey: false });
        expect(mockOnSend).toHaveBeenCalledTimes(1);
        expect(mockOnSend).toHaveBeenCalledWith(); // Called with no args
    });

    it('shows a loading indicator when isGenerating is true', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} isGenerating={true} messages={[]} />
            </BrowserRouter>
        );

        expect(screen.getByText('Generating response...')).toBeDefined();
    });
});