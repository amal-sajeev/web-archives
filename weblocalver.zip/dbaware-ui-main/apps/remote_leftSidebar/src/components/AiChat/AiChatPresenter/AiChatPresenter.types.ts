import type { ChatMessage, RecommendedAction } from '../../../types/aiChat';

export interface AiChatPresenterProps {
  messages: ChatMessage[];
  inputValue: string;
  isGenerating: boolean;
  isInputDisabled: boolean;
  recommendedActions: RecommendedAction[];
  onInputChange: (val: string) => void;
  onSend: (val?: string, attachments?: File[]) => void;
  currentTab?: string;
  planNumber?: string;
}

export type ExclusionSourceMode = 'historical' | 'documents';