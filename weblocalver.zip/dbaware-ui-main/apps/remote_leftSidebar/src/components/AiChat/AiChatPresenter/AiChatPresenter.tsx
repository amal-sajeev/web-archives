import React, { useRef, useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Card, CardHeader, CardTitle, LeftSlot, Stack, StatusLabel, Button, TextInput } from '@wadk/ui';
import { SingleChevronDownSolid, SingleChevronUpSolid, CheckmarkSolid, DocumentOutline } from '@wadk/icons';
import {
  AiInputPanelContent,
  AiInputPanelTextarea,
  AiQuestion,
  AiResponse,
  AiQuestions,
  AiQuestionsPrompt,
  AutoLoadingProgress
} from 'com.db.rca.commons.afcc-components';
import { CurrentPlan } from '../../CurrentPlan/CurrentPlan.tsx';
import styles from '../AiChat.module.css';
import { SequentialFadeList } from '../Loader/SequentialFadeList.tsx';
import { AiChatModeMenu } from '../AiChatModeMenu/AiChatModeMenu.tsx';
import { AddRecipientModal } from '../UploadModal/UploadModal.tsx';
import type { AiChatPresenterProps, ExclusionSourceMode } from './AiChatPresenter.types';
import PreliminaryResearchEditMode from '../tabs/preliminaryResearch/preliminaryResearchEditMode.tsx';
import { executeDataExtractionFlow, getPlanArtifact, startLrrProcess, startLrrPdfProcess, getLrrProcessStatus, getLrrRunDetails } from '../../../api/dataGatheringClient.ts';
import {
  fetchPreliminaryResearchSourceDocuments,
  fetchHistoricalPreliminaryResearchSourceDocuments,
  deleteHistoricalPreliminaryResearchSourceDocuments,
  HistoricalPlanItem,
  PreliminaryResearchDocumentItem,
  PreliminaryResearchDocumentType,
  regeneratePreliminaryResearchWithExclusions,
} from '../../../api/preliminaryResearchClient.ts';
import { postJson } from '../../../api/sharedApi.ts';
import {
  GENERATION_LOADING_CONFIG,
  GENERATION_LOADING_MESSAGE_TO_TAB,
  GENERATION_LOADING_STORAGE_KEY,
  LRR_UPLOAD_POLL_INTERVAL_MS,
  REGENERATE_PRELIMINARY_RESEARCH_HISTORICAL_SECTIONS,
  REGENERATE_PRELIMINARY_RESEARCH_SECTIONS,
  type GenerationLoadingTab,
} from '../../../constants/index.ts';

export const AiChatPresenter: React.FC<AiChatPresenterProps> = ({
  messages,
  inputValue,
  isGenerating,
  isInputDisabled,
  onInputChange,
  onSend,
  currentTab = 'noir',
  planNumber = ''
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const PRELIM_EDIT_CONTENT_PROMPT_ID = 'prelim-edit-content-prompt';
  const PRELIM_LRR_UPLOAD_PROMPT_ID = 'prelim-lrr-upload-prompt';
  const navigate = useNavigate();
  const taskDefinitionKeyByPlan = useSelector((state: any) => state.scoping?.taskDefinitionKeyByPlan || {});
  const nextAvailableActionsByPlan = useSelector((state: any) => state.scoping?.nextAvailableActionsByPlan || {});
  const isNorOrNoirTab = currentTab === 'nor' || currentTab === 'noir';
  const [chatMode, setChatMode] = useState<'Chat Only' | 'Edit Content'>(isNorOrNoirTab ? 'Edit Content' : 'Chat Only');
  const [isPreliminaryResearchGenerated, setIsPreliminaryResearchGenerated] = useState(false);
  const [isPreliminaryResearchGenerationInProgress, setIsPreliminaryResearchGenerationInProgress] = useState(false);
  const [isScopeRecEnabled, setIsScopeRecEnabled] = useState(false);
  const [isTestStepsGenerated, setIsTestStepsGenerated] = useState(false);
  const [isTestStepsUploadFlowVisible, setIsTestStepsUploadFlowVisible] = useState(false);
  const isDataGatheringEnabled = localStorage.getItem('dataGatheringToggle') === 'true';
  const documentTypes: PreliminaryResearchDocumentType[] = ['Policies', 'KOD', 'Procedure Documents'];
  const [isExcludeFlowVisible, setIsExcludeFlowVisible] = useState(false);
  const [isExcludeActionLoading, setIsExcludeActionLoading] = useState(false);
  const [excludeSourceMode, setExcludeSourceMode] = useState<ExclusionSourceMode | null>(null);
  const [isExcludeSourceModeDropdownOpen, setIsExcludeSourceModeDropdownOpen] = useState(false);
  const [openDropdownType, setOpenDropdownType] = useState<PreliminaryResearchDocumentType | null>(null);
  const [isHistoricalDropdownOpen, setIsHistoricalDropdownOpen] = useState(false);
  const [historicalPlanItems, setHistoricalPlanItems] = useState<HistoricalPlanItem[]>([]);
  const [selectedHistoricalPlanItemNumbers, setSelectedHistoricalPlanItemNumbers] = useState<number[]>([]);
  const [historicalSearchText, setHistoricalSearchText] = useState('');
  const [documentsByType, setDocumentsByType] = useState<Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>>({
    Policies: [],
    KOD: [],
    'Procedure Documents': [],
  });
  const [selectedByType, setSelectedByType] = useState<Record<PreliminaryResearchDocumentType, string[]>>({
    Policies: [],
    KOD: [],
    'Procedure Documents': [],
  });
  const [searchByType, setSearchByType] = useState<Record<PreliminaryResearchDocumentType, string>>({
    Policies: '',
    KOD: '',
    'Procedure Documents': '',
  });
  const [takenPrelimActions, setTakenPrelimActions] = useState<Record<'generate' | 'exclude' | 'regenerate' | 'cancel', boolean>>({
    generate: false,
    exclude: false,
    regenerate: false,
    cancel: false,
  });
  const [isPrelimRegenerationInProgress, setIsPrelimRegenerationInProgress] = useState(false);
  const [prelimStatusMessage, setPrelimStatusMessage] = useState('');
  const [isLrrUploadPromptVisible, setIsLrrUploadPromptVisible] = useState(false);
  const [isAddRecipientModalOpen, setIsAddRecipientModalOpen] = useState(false);
  const [uploadedLrrUrls, setUploadedLrrUrls] = useState<string[]>([]);
  const [lrrUploadSourceType, setLrrUploadSourceType] = useState<'urls' | 'pdf' | null>(null);
  const [isLrrUploadInProgress, setIsLrrUploadInProgress] = useState(false);
  const [lrrUploadStatusMessage, setLrrUploadStatusMessage] = useState('');
  const [lrrUploadRunId, setLrrUploadRunId] = useState('');
  const [shouldAutoGeneratePrelim, setShouldAutoGeneratePrelim] = useState(false);
  const [pendingGenerationResultByKey, setPendingGenerationResultByKey] = useState<Record<string, React.ReactNode>>({});
  const [generationLoadingByKey, setGenerationLoadingByKey] = useState<Record<string, boolean>>(() => {
    try {
      const stored = sessionStorage.getItem(GENERATION_LOADING_STORAGE_KEY);
      if (!stored) return {};
      const parsed = JSON.parse(stored);
      return typeof parsed === 'object' && parsed !== null ? parsed as Record<string, boolean> : {};
    } catch {
      return {};
    }
  });
  const lrrUploadPromptTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lrrUploadPollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const totalSelectedDocuments = excludeSourceMode === 'historical'
    ? selectedHistoricalPlanItemNumbers.length
    : documentTypes.reduce((count, type) => count + selectedByType[type].length, 0);
  const hasSelectedSourceDocuments = totalSelectedDocuments > 0;
  const isFetchingSourceDocuments = isExcludeActionLoading && takenPrelimActions.exclude && !isExcludeFlowVisible;
  const excludeSourceModeLabel = excludeSourceMode === 'historical'
    ? 'Past Review, Broad Scope'
    : excludeSourceMode === 'documents'
      ? 'Policies, KODs, Procedures'
      : 'Select section you want to exclude';
  const filteredHistoricalPlanItems = historicalPlanItems.filter((item) => {
    const searchText = historicalSearchText.toLowerCase().trim();
    if (!searchText) return true;
    return item.planItemTitle.toLowerCase().includes(searchText);
  });
  const selectedHistoricalPlanItems = historicalPlanItems.filter((item) => (
    selectedHistoricalPlanItemNumbers.includes(item.planItemNumber)
  ));
  const historicalDropdownLabel = selectedHistoricalPlanItems.length > 0
    ? selectedHistoricalPlanItems.length === 1
      ? selectedHistoricalPlanItems[0].planItemTitle
      : `${selectedHistoricalPlanItems[0].planItemTitle} +${selectedHistoricalPlanItems.length - 1} more`
    : historicalPlanItems.length > 0
      ? `Historical documents (${historicalPlanItems.length})`
      : 'Historical documents';

  const currentPlanNumber = String(planNumber || '').trim();
  const buildGenerationLoadingKey = useCallback((tab: GenerationLoadingTab, plan: string) => {
    return `${plan || '__NO_PLAN__'}::${tab}`;
  }, []);

  const clearGenerationLoadingStateForTab = useCallback((tab: GenerationLoadingTab) => {
    setGenerationLoadingByKey((prev) => {
      const next: Record<string, boolean> = {};
      const suffix = `::${tab}`;
      Object.entries(prev).forEach(([key, value]) => {
        if (!key.endsWith(suffix)) {
          next[key] = value;
        }
      });

      try {
        if (Object.keys(next).length === 0) {
          sessionStorage.removeItem(GENERATION_LOADING_STORAGE_KEY);
        } else {
          sessionStorage.setItem(GENERATION_LOADING_STORAGE_KEY, JSON.stringify(next));
        }
      } catch {}

      return next;
    });
  }, []);

  const setGenerationLoadingState = useCallback((tab: GenerationLoadingTab, isLoading: boolean, targetPlanNumber = currentPlanNumber) => {
    const loadingKey = buildGenerationLoadingKey(tab, targetPlanNumber);
    setGenerationLoadingByKey((prev) => {
      const next = { ...prev };
      if (isLoading) {
        next[loadingKey] = true;
      } else {
        delete next[loadingKey];
      }
      try {
        if (Object.keys(next).length === 0) {
          sessionStorage.removeItem(GENERATION_LOADING_STORAGE_KEY);
        } else {
          sessionStorage.setItem(GENERATION_LOADING_STORAGE_KEY, JSON.stringify(next));
        }
      } catch {}
      return next;
    });
  }, [buildGenerationLoadingKey, currentPlanNumber]);

  const buildPendingGenerationResultKey = useCallback((tab: string, plan: string) => {
    return `${plan || '__NO_PLAN__'}::${tab}`;
  }, []);

  const emitOrQueueGenerationResult = useCallback((tab: string, content: React.ReactNode, targetPlanNumber = currentPlanNumber) => {
    const normalizedPlanNumber = String(targetPlanNumber || '').trim();
    const isCurrentPlan = !normalizedPlanNumber || normalizedPlanNumber === currentPlanNumber;

    if (currentTab === tab && isCurrentPlan) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content,
        }
      }));
      return;
    }

    const pendingKey = buildPendingGenerationResultKey(tab, normalizedPlanNumber);
    setPendingGenerationResultByKey((prev) => ({
      ...prev,
      [pendingKey]: content,
    }));
  }, [buildPendingGenerationResultKey, currentPlanNumber, currentTab]);

  const currentTabLoadingConfig = (Object.prototype.hasOwnProperty.call(GENERATION_LOADING_CONFIG, currentTab)
    ? GENERATION_LOADING_CONFIG[currentTab as GenerationLoadingTab]
    : null);
  const isCurrentTabGenerationLoading = currentTabLoadingConfig
    ? Boolean(generationLoadingByKey[buildGenerationLoadingKey(currentTab as GenerationLoadingTab, currentPlanNumber)])
    : false;
  const hasCurrentTabLoadingMessage = currentTabLoadingConfig
    ? messages.some((message) => message.id === currentTabLoadingConfig.messageId)
    : false;
  const shouldRenderPersistentGenerationLoading = Boolean(
    currentTabLoadingConfig && isCurrentTabGenerationLoading && !hasCurrentTabLoadingMessage
  );
  const isTestStepsGenerationInProgress = currentTab === 'test-steps'
    && (isCurrentTabGenerationLoading || hasCurrentTabLoadingMessage || shouldRenderPersistentGenerationLoading);
  const isPreliminaryResearchLoadingPersisted = Boolean(
    generationLoadingByKey[buildGenerationLoadingKey('preliminary-research', currentPlanNumber)]
  );

  const taskDefinitionKeyForPlan = currentPlanNumber ? String(taskDefinitionKeyByPlan[currentPlanNumber] || '') : '';
  const normalizedTaskDefinitionKey = taskDefinitionKeyForPlan
    .trim()
    .replace(/[\s-]+/g, '_')
    .toUpperCase();
  const taskDefinitionTabByKey: Record<string, string> = {
    NOIR: 'noir',
    NOR: 'nor',
    PRELIMINARY_RESEARCH: 'preliminary-research',
    DISCOVERY_WALKTHROUGH: 'discovery-walkthrough',
    DISCOVERY_WALKTHROUGH_AGENDA: 'discovery-walkthrough',
    SCOPE_RECOMMENDATION: 'scope-recommendation',
    TEST_STEPS: 'test-steps',
    SCOPING_DOCUMENT: 'final-scope-document',
    FINAL_SCOPE_DOCUMENT: 'final-scope-document',
  };
  const taskDefinitionTab = taskDefinitionTabByKey[normalizedTaskDefinitionKey] || '';
  const isCurrentTabActionable = !taskDefinitionTab || currentTab === taskDefinitionTab;

  const actionsForPlan = currentPlanNumber
    ? (Array.isArray(nextAvailableActionsByPlan[currentPlanNumber]) ? nextAvailableActionsByPlan[currentPlanNumber] : [])
    : [];
  const normalizedActionsForPlan = actionsForPlan
    .map((action: unknown) => String(action || '').trim().toUpperCase())
    .filter(Boolean);

  const isNoirTaskDefinition = normalizedTaskDefinitionKey === 'NOIR';
  const isNorTaskDefinition = normalizedTaskDefinitionKey === 'NOR';
  const isPreliminaryResearchTaskDefinition = normalizedTaskDefinitionKey === 'PRELIMINARY_RESEARCH';
  const isDiscoveryWalkthroughTaskDefinition =
    normalizedTaskDefinitionKey === 'DISCOVERY_WALKTHROUGH' ||
    normalizedTaskDefinitionKey === 'DISCOVERY_WALKTHROUGH_AGENDA';
  const isScopeRecommendationTaskDefinition = normalizedTaskDefinitionKey === 'SCOPE_RECOMMENDATION';
  const isTestStepsTaskDefinition = normalizedTaskDefinitionKey === 'TEST_STEPS';
  const isScopingDocumentTaskDefinition =
    normalizedTaskDefinitionKey === 'SCOPING_DOCUMENT' ||
    normalizedTaskDefinitionKey === 'FINAL_SCOPE_DOCUMENT';
  const hasGenerateNoirAction = normalizedActionsForPlan.includes('GENERATE_NOIR');
  const hasSkipNoirAction = normalizedActionsForPlan.includes('SKIP_NOIR');
  const hasEditNoirAction =
    normalizedActionsForPlan.includes('EDIT_NOIR') ||
    normalizedActionsForPlan.includes('PROMPT_BASED_REFINEMENT');
  const hasGenerateNorAction = normalizedActionsForPlan.includes('GENERATE_NOR');
  const hasEditNorAction =
    normalizedActionsForPlan.includes('EDIT_NOR') ||
    normalizedActionsForPlan.includes('PROMPT_BASED_REFINEMENT') ||
    normalizedActionsForPlan.includes('PROMPT_BASED_REFINEMENT_NOR');
  const hasRunAnalyticsAction = normalizedActionsForPlan.includes('RUN_ANALYTICS');
  const hasQnaChatAction = normalizedActionsForPlan.includes('QNA_CHAT');
  const hasGenerateDiscoveryWalkthroughAction = normalizedActionsForPlan.includes('GENERATE_DISCOVERY_WALKTHROUGH');
  const hasGenerateScopeRecommendationAction = normalizedActionsForPlan.includes('GENERATE_INSCOPE_OUTSCOPE');
  const hasGenerateTestStepsAction = normalizedActionsForPlan.includes('GENERATE_TEST_STEPS');
  const hasGetTestStepsAction = normalizedActionsForPlan.includes('GET_TEST_STEPS');
  const hasGenerateFinalScopingDocumentAction = normalizedActionsForPlan.includes('GENERATE_SCOPING_DOCUMENT');
  const hasGetPreliminaryResearchDocumentAction = normalizedActionsForPlan.includes('GET_PRELIMINARY_RESEARCH_DOCUMENT');
  const shouldShowGenerateNoirPrompt = currentTab === 'noir' && isCurrentTabActionable && hasGenerateNoirAction;
  const shouldShowSkipNoirPrompt = currentTab === 'noir' && isCurrentTabActionable;
  const shouldShowGenerateNorPrompt = currentTab === 'nor' && isCurrentTabActionable && (!isNorTaskDefinition || hasGenerateNorAction);
  const shouldShowGeneratePreliminaryResearchByTaskStatus =
    isCurrentTabActionable && (!isPreliminaryResearchTaskDefinition || hasRunAnalyticsAction);


  const shouldShowReGeneratePreliminaryResearchByTaskStatus =
    isCurrentTabActionable && isPreliminaryResearchTaskDefinition;


  const shouldShowGenerateDiscoveryWalkthroughByTaskStatus =
    isCurrentTabActionable && (!isDiscoveryWalkthroughTaskDefinition || hasGenerateDiscoveryWalkthroughAction);
  const shouldShowGenerateScopeRecommendationByTaskStatus =
    isCurrentTabActionable && (!isScopeRecommendationTaskDefinition || hasGenerateScopeRecommendationAction);
  const shouldShowGenerateTestStepsByTaskStatus =
    isCurrentTabActionable && hasGenerateTestStepsAction;
  const shouldShowTestStepsUploadAction = isTestStepsGenerated || hasGetTestStepsAction;
  const shouldShowGenerateFinalScopingDocumentByTaskStatus =
    isCurrentTabActionable && (!isScopingDocumentTaskDefinition || hasGenerateFinalScopingDocumentAction);
  const isNoirTextareaLockedByTaskStatus = currentTab === 'noir' && isNoirTaskDefinition && !hasEditNoirAction;
  const isNorTextareaLockedByTaskStatus = currentTab === 'nor' && isNorTaskDefinition && !hasEditNorAction;
  const isTextareaLockedByTaskDefinition = !isCurrentTabActionable;
  const isPreliminaryResearchTextareaLockedByTaskStatus =
    currentTab === 'preliminary-research' &&
    isPreliminaryResearchTaskDefinition &&
    !hasQnaChatAction;
  const canEnablePreliminaryResearchEditContentByTaskStatus =
    currentTab === 'preliminary-research' &&
    isPreliminaryResearchTaskDefinition &&
    hasGetPreliminaryResearchDocumentAction;
  const isPreliminaryResearchEditContentEnabled =
    isPreliminaryResearchGenerated || canEnablePreliminaryResearchEditContentByTaskStatus;
  const canShowExcludeSourceDocumentsAction = isCurrentTabActionable
    && currentTab === 'preliminary-research'
    && chatMode === 'Edit Content'
    && isPreliminaryResearchEditContentEnabled;
  const canShowGeneratePreliminaryResearchAction = !isPreliminaryResearchGenerated
    && chatMode === 'Chat Only'
    && !takenPrelimActions.generate;
  const isDiscoveryWalkthroughTextareaLockedByTaskStatus =
    currentTab === 'discovery-walkthrough' &&
    isDiscoveryWalkthroughTaskDefinition &&
    !hasQnaChatAction;
  const isScopeRecommendationTextareaLockedByTaskStatus =
    currentTab === 'scope-recommendation' &&
    isScopeRecommendationTaskDefinition &&
    !hasQnaChatAction;
  const isTestStepsTextareaLockedByTaskStatus =
    currentTab === 'test-steps' &&
    isTestStepsTaskDefinition &&
    !hasQnaChatAction;
  const isScopingDocumentTextareaLockedByTaskStatus =
    currentTab === 'final-scope-document' &&
    isScopingDocumentTaskDefinition &&
    !hasQnaChatAction;

  const recommendedActionsHeader = isCurrentTabActionable
    ? <div className={styles['recommended-actions-header']}>Recommended Actions</div>
    : null;
  const scopeRecommendationHeader = isCurrentTabActionable
    ? <div className={styles['recommended-actions-header']}>{!isScopeRecEnabled ? 'Is there any additional information you would like to upload before generating Scope Recommendation?' : 'Recommended Actions'}</div>
    : null;
  const discoveryWalkthroughHeader = isCurrentTabActionable
    ? <div className={styles['recommended-actions-header']}>Is there any additional information you would like to upload before generating Discovery Walkthrough?</div>
    : null;
  const testStepsHeader = isCurrentTabActionable
    ? <div className={styles['recommended-actions-header']}>Is there any additional information you would like to upload before generating Test Steps?</div>
    : null;

  const stopLrrUploadPolling = useCallback(() => {
    if (lrrUploadPollIntervalRef.current) {
      clearInterval(lrrUploadPollIntervalRef.current);
      lrrUploadPollIntervalRef.current = null;
    }
  }, []);

  const buildLrrRunSummaryMessage = useCallback((currentRunId: string, details: any, fallback: string) => {
    const normalizedStatus = details?.status ? String(details.status).toLowerCase() : fallback;
    const base = `LRR URL processing ${normalizedStatus} (Run ID: ${currentRunId}).`;

    if (normalizedStatus === 'queued' || normalizedStatus === 'running' || normalizedStatus === 'pending' || normalizedStatus === 'in_progress') {
      const step = details?.step;
      const pipeline = details?.pipeline;
      if (typeof step === 'number' && pipeline) {
        return `${base} Pipeline: ${pipeline}. Step: ${step}.`;
      }
      if (typeof step === 'number') {
        return `${base} Step: ${step}.`;
      }
      if (pipeline) {
        return `${base} Pipeline: ${pipeline}.`;
      }
      return base;
    }

    if (details?.error) {
      return `${base} Error: ${details.error}`;
    }

    const accepted = details?.accepted ?? 0;
    const rejected = details?.rejected ?? 0;
    const review = details?.review ?? 0;
    return `${base} Accepted: ${accepted}, Review: ${review}, Rejected: ${rejected}.`;
  }, []);

  const pollLrrUploadStatusOnce = useCallback(async (currentRunId: string): Promise<'in_progress' | 'completed' | 'failed'> => {
    try {
      const status = await getLrrProcessStatus(currentRunId);
      const statusLabel = status.status || 'in_progress';
      const uploadTargetLabel = lrrUploadSourceType === 'pdf' ? 'PDF' : 'URL';

      if (status.isComplete) {
        setIsLrrUploadInProgress(false);
        setLrrUploadStatusMessage(`LRR ${uploadTargetLabel} processing completed.`);
        stopLrrUploadPolling();
        window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
          detail: {
            sender: 'ai',
            content: `${uploadTargetLabel} uploaded successfully.`
          }
        }));
        setShouldAutoGeneratePrelim(true);
        return 'completed';
      }

      if (status.isFailed) {
        const details = await getLrrRunDetails(currentRunId).catch(() => null);
        const failedMessage =
          buildLrrRunSummaryMessage(currentRunId, details, statusLabel) ||
          status.message ||
          'LRR URL processing failed.';
        setIsLrrUploadInProgress(false);
        setLrrUploadStatusMessage(failedMessage);
        stopLrrUploadPolling();
        window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
          detail: {
            sender: 'ai',
            content: failedMessage
          }
        }));
        return 'failed';
      }

      const details = await getLrrRunDetails(currentRunId).catch(() => null);
      setLrrUploadStatusMessage(
        buildLrrRunSummaryMessage(currentRunId, details, statusLabel) ||
        status.message ||
        `LRR URL processing is in progress (${statusLabel}).`
      );
      return 'in_progress';
    } catch (statusError: any) {
      const failedMessage = statusError?.message || 'Failed to fetch LRR process status.';
      setIsLrrUploadInProgress(false);
      setLrrUploadStatusMessage(failedMessage);
      stopLrrUploadPolling();
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: failedMessage
        }
      }));
      return 'failed';
    }
  }, [buildLrrRunSummaryMessage, lrrUploadSourceType, stopLrrUploadPolling]);

  const startLrrUploadPolling = useCallback((currentRunId: string) => {
    stopLrrUploadPolling();
    lrrUploadPollIntervalRef.current = setInterval(() => {
      void pollLrrUploadStatusOnce(currentRunId);
    }, LRR_UPLOAD_POLL_INTERVAL_MS);
  }, [pollLrrUploadStatusOnce, stopLrrUploadPolling]);

  const handleLrrUrlsSubmit = useCallback(async ({ urls }: { urls: string[] }) => {
    const normalizedUrls = (urls || []).map((url) => url.trim()).filter((url) => Boolean(url));

    setUploadedLrrUrls(normalizedUrls);
    setLrrUploadSourceType('urls');
    setIsLrrUploadPromptVisible(false);

    window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
      detail: { id: PRELIM_LRR_UPLOAD_PROMPT_ID }
    }));

    if (normalizedUrls.length === 0) {
      return;
    }

    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: {
        sender: 'user',
        content: (
          <Stack direction="column" gap="xs">
            <div>LRRs addresses updated:</div>
            {normalizedUrls.map((url, index) => (
              <div key={`${url}-${index}`}>{url}</div>
            ))}
          </Stack>
        )
      }
    }));

    if (!planNumber) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: 'Error: Plan number not found. Please ensure you are on the correct page.'
        }
      }));
      return;
    }

    setIsLrrUploadInProgress(true);
    setLrrUploadRunId('');
    setLrrUploadStatusMessage('Uploading LRR URLs and preparing extraction...');

    try {
      const response = await startLrrProcess(planNumber, normalizedUrls);
      if (!response.runId) {
        throw new Error('LRR process did not return a run ID.');
      }

      setLrrUploadRunId(response.runId);
      setLrrUploadStatusMessage(response.message || 'LRR URL processing started.');

      const latest = await pollLrrUploadStatusOnce(response.runId);
      if (latest === 'in_progress') {
        startLrrUploadPolling(response.runId);
      }
    } catch (submitError: any) {
      const failedMessage = submitError?.message || 'Failed to start LRR URL processing.';
      setIsLrrUploadInProgress(false);
      setLrrUploadStatusMessage(failedMessage);
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: failedMessage
        }
      }));
    }
  }, [PRELIM_LRR_UPLOAD_PROMPT_ID, planNumber, pollLrrUploadStatusOnce, startLrrUploadPolling]);

  const handleLrrPdfSubmit = useCallback(async (files: File[]) => {
    const normalizedFiles = (files || []).filter((file) => Boolean(file));

    setIsLrrUploadPromptVisible(false);
    setLrrUploadSourceType('pdf');

    window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
      detail: { id: PRELIM_LRR_UPLOAD_PROMPT_ID }
    }));

    if (normalizedFiles.length === 0) {
      return;
    }

    const firstFile = normalizedFiles[0];

    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: {
        sender: 'user',
        content: `LRR PDF uploaded: ${firstFile.name}`
      }
    }));

    if (!planNumber) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: 'Error: Plan number not found. Please ensure you are on the correct page.'
        }
      }));
      return;
    }

    setIsLrrUploadInProgress(true);
    setLrrUploadRunId('');
    setLrrUploadStatusMessage('Uploading LRR PDF and preparing extraction...');

    try {
      const response = await startLrrPdfProcess(planNumber, firstFile);
      if (response.runId) {
        setLrrUploadRunId(response.runId);
        setLrrUploadStatusMessage(response.message || 'LRR PDF processing started.');

        const latest = await pollLrrUploadStatusOnce(response.runId);
        if (latest === 'in_progress') {
          startLrrUploadPolling(response.runId);
        }
      } else {
        setIsLrrUploadInProgress(false);
        setLrrUploadStatusMessage(response.message || 'LRR PDF uploaded successfully.');
        window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
          detail: {
            sender: 'ai',
            content: response.message || 'PDF uploaded successfully.'
          }
        }));
        setShouldAutoGeneratePrelim(true);
      }
    } catch (submitError: any) {
      const failedMessage = submitError?.message || 'Failed to start LRR PDF processing.';
      setIsLrrUploadInProgress(false);
      setLrrUploadStatusMessage(failedMessage);
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: failedMessage
        }
      }));
    }
  }, [PRELIM_LRR_UPLOAD_PROMPT_ID, planNumber, pollLrrUploadStatusOnce, startLrrUploadPolling]);

  const getCleanDocumentName = useCallback((documentTitle: string) => {
    return documentTitle
      .replace(/\.[^/.]+$/, '')
      .replace(/[_\-\u2010-\u2015]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }, []);

  const normalizeDocumentsByType = useCallback((
    source: Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>,
  ): Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]> => {
    return {
      Policies: (source.Policies || []).map(doc => ({
        ...doc,
        title: getCleanDocumentName(doc.title),
      })),
      KOD: (source.KOD || []).map(doc => ({
        ...doc,
        title: getCleanDocumentName(doc.title),
      })),
      'Procedure Documents': (source['Procedure Documents'] || []).map(doc => ({
        ...doc,
        title: getCleanDocumentName(doc.title),
      })),
    };
  }, [getCleanDocumentName]);

  useEffect(() => {
    setChatMode(isNorOrNoirTab ? 'Edit Content' : 'Chat Only');
    setIsPreliminaryResearchGenerated(false);
    setIsPreliminaryResearchGenerationInProgress(false);
    setIsScopeRecEnabled(false);
    setIsTestStepsGenerated(false);
    setIsTestStepsUploadFlowVisible(false);
    setIsExcludeFlowVisible(false);
    setIsExcludeActionLoading(false);
    setExcludeSourceMode(null);
    setIsExcludeSourceModeDropdownOpen(false);
    setOpenDropdownType(null);
    setIsHistoricalDropdownOpen(false);
    setHistoricalPlanItems([]);
    setSelectedHistoricalPlanItemNumbers([]);
    setHistoricalSearchText('');
    setDocumentsByType({
      Policies: [],
      KOD: [],
      'Procedure Documents': [],
    });
    setSelectedByType({
      Policies: [],
      KOD: [],
      'Procedure Documents': [],
    });
    setSearchByType({
      Policies: '',
      KOD: '',
      'Procedure Documents': '',
    });
    setTakenPrelimActions({
      generate: false,
      exclude: false,
      regenerate: false,
      cancel: false,
    });
    setIsPrelimRegenerationInProgress(false);
    setPrelimStatusMessage('');
    setIsLrrUploadPromptVisible(false);
    setIsAddRecipientModalOpen(false);
    setUploadedLrrUrls([]);
    setLrrUploadSourceType(null);
    setIsLrrUploadInProgress(false);
    setLrrUploadStatusMessage('');
    setLrrUploadRunId('');
    setShouldAutoGeneratePrelim(false);
    stopLrrUploadPolling();
    if (lrrUploadPromptTimeoutRef.current) {
      clearTimeout(lrrUploadPromptTimeoutRef.current);
      lrrUploadPromptTimeoutRef.current = null;
    }
  }, [currentTab, isNorOrNoirTab, stopLrrUploadPolling, currentPlanNumber]);

  useEffect(() => {
    return () => {
      if (lrrUploadPromptTimeoutRef.current) {
        clearTimeout(lrrUploadPromptTimeoutRef.current);
      }
      stopLrrUploadPolling();
    };
  }, [stopLrrUploadPolling]);

  useEffect(() => {
    const handleNoirGenerationStarted = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string }>;
      const targetPlanNumber = String(customEvent.detail?.planNumber || currentPlanNumber || '').trim();
      setGenerationLoadingState('noir', true, targetPlanNumber);
    };

    const handleNoirGenerationFinished = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string }>;
      const targetPlanNumber = String(customEvent.detail?.planNumber || currentPlanNumber || '').trim();
      setGenerationLoadingState('noir', false, targetPlanNumber);
    };

    const handleNorGenerationStarted = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string }>;
      const targetPlanNumber = String(customEvent.detail?.planNumber || currentPlanNumber || '').trim();
      setGenerationLoadingState('nor', true, targetPlanNumber);
    };

    const handleNorGenerationFinished = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string }>;
      const targetPlanNumber = String(customEvent.detail?.planNumber || currentPlanNumber || '').trim();
      setGenerationLoadingState('nor', false, targetPlanNumber);
    };

    window.addEventListener('ai-chat:noir-generation-started', handleNoirGenerationStarted as EventListener);
    window.addEventListener('ai-chat:noir-generation-finished', handleNoirGenerationFinished as EventListener);
    window.addEventListener('ai-chat:nor-generation-started', handleNorGenerationStarted as EventListener);
    window.addEventListener('ai-chat:nor-generation-finished', handleNorGenerationFinished as EventListener);

    return () => {
      window.removeEventListener('ai-chat:noir-generation-started', handleNoirGenerationStarted as EventListener);
      window.removeEventListener('ai-chat:noir-generation-finished', handleNoirGenerationFinished as EventListener);
      window.removeEventListener('ai-chat:nor-generation-started', handleNorGenerationStarted as EventListener);
      window.removeEventListener('ai-chat:nor-generation-finished', handleNorGenerationFinished as EventListener);
    };
  }, [currentPlanNumber, setGenerationLoadingState]);

  useEffect(() => {
    const handleAddMessage = (event: Event) => {
      const { id } = (event as CustomEvent<{ id?: string }>).detail || {};
      if (!id) return;
      const tab = GENERATION_LOADING_MESSAGE_TO_TAB[id];
      if (!tab) return;
      setGenerationLoadingState(tab, true);
    };

    const handleRemoveMessage = (event: Event) => {
      const { id } = (event as CustomEvent<{ id?: string }>).detail || {};
      if (!id) return;
      const tab = GENERATION_LOADING_MESSAGE_TO_TAB[id];
      if (!tab) return;
      clearGenerationLoadingStateForTab(tab);
    };

    window.addEventListener('ai-chat:add-message', handleAddMessage as EventListener);
    window.addEventListener('ai-chat:remove-message', handleRemoveMessage as EventListener);

    return () => {
      window.removeEventListener('ai-chat:add-message', handleAddMessage as EventListener);
      window.removeEventListener('ai-chat:remove-message', handleRemoveMessage as EventListener);
    };
  }, [clearGenerationLoadingStateForTab, setGenerationLoadingState]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isGenerating, shouldRenderPersistentGenerationLoading]);

  const getBadgeLabel = () => {
    if (currentTab === 'data-gathering') return 'DATA GATHERING';
    if (currentTab === 'preliminary-research') return 'PRELIMINARY RESEARCH';
    if (currentTab === 'discovery-walkthrough') return 'DISCOVERY WALKTHROUGH';
    if (currentTab === 'scope-recommendation') return 'SCOPE RECOMMENDATION';
    if (currentTab === 'final-scope-document') return 'FINAL SCOPE DOCUMENT';
    if (currentTab === 'test-steps') return 'TEST STEPS';
    if (currentTab === 'nor') return 'NOR';
    return 'NOIR';
  };

  const getInputPlaceholder = () => {
    if (currentTab === 'data-gathering') return 'Ask AI about Data Gathering';
    if (currentTab === 'preliminary-research') return 'Ask AI about Preliminary Research';
    if (currentTab === 'discovery-walkthrough') return 'Ask AI about Discovery Walkthrough';
    if (currentTab === 'scope-recommendation') return 'Ask AI about Scope Recommendation';
    if (currentTab === 'final-scope-document') return 'Ask AI about Final Scope Document';
    if (currentTab === 'test-steps') return 'Ask AI about Test Steps';
    if (currentTab === 'nor') return 'Ask AI about NoR';
    return 'Ask AI about NOIR';
  };

  const handleGenerateDataGathering = useCallback(() => {
    if (!planNumber) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'ai', content: 'Error: Plan number not found. Please ensure you are on the correct page.' }
      }));
      return;
    }

    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Generate Data Gathering' }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: {
        id: 'data-gathering-loading',
        sender: 'ai',
        content: (
          <Stack gap="md" direction="column">
            <div style={{ fontWeight: 'bold' }}>Generating Data Gathering...</div>
            <SequentialFadeList
              title="Looking into..."
              listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
              items={[
                'Reviewing regulatory obligations',
                'Analysing policies',
                'Comparing historical scope',
                'Reviewing open findings',
                'Mapping risks and controls',
                'Assessing evidence',
                'Developing scope direction',
                'Processing results...'
              ]}
              intervalMs={60000}
            />
          </Stack>
        )
      }
    }));

    window.dispatchEvent(new CustomEvent('data-gathering:sync', {
      detail: {
        planNumber,
        status: 'triggered',
        message: 'Starting data extraction...'
      }
    }));

    const hasArtifactData = (data: unknown): boolean => {
      if (data === null || data === undefined) return false;
      if (Array.isArray(data)) return data.length > 0;
      if (typeof data === 'object') return Object.keys(data as Record<string, unknown>).length > 0;
      if (typeof data === 'string') return data.trim().length > 0;
      return true;
    };

    const emitAlreadyGenerated = () => {
      window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
        detail: { id: 'data-gathering-loading' }
      }));
      window.dispatchEvent(new CustomEvent('data-gathering:sync', {
        detail: {
          planNumber,
          status: 'completed',
          message: 'Data gathering already available.'
        }
      }));
    };

    getPlanArtifact(planNumber, 'current_details').then((existingArtifact) => {
      if (hasArtifactData(existingArtifact?.data)) {
        emitAlreadyGenerated();
        return;
      }
      runExtractionFlow();
    }).catch(() => {
      runExtractionFlow();
    });

    function runExtractionFlow() {
    executeDataExtractionFlow(planNumber, 'lrr', 5000, 120, (status, message) => {
      window.dispatchEvent(new CustomEvent('ai-chat:update-message', {
        detail: {
          id: 'data-gathering-loading',
          status,
          message
        }
      }));

      window.dispatchEvent(new CustomEvent('data-gathering:sync', {
        detail: {
          planNumber,
          status: 'polling',
          message: message || status
        }
      }));
    }).then(() => {
      window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
        detail: { id: 'data-gathering-loading' }
      }));

      window.dispatchEvent(new CustomEvent('data-gathering:sync', {
        detail: {
          planNumber,
          status: 'completed',
          message: 'Data gathering completed successfully.'
        }
      }));
    }).catch((error) => {
      window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
        detail: { id: 'data-gathering-loading' }
      }));

      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      window.dispatchEvent(new CustomEvent('data-gathering:sync', {
        detail: {
          planNumber,
          status: 'failed',
          message: errorMessage
        }
      }));
    });
    }
  }, [planNumber]);

  useEffect(() => {
    const handler = () => handleGenerateDataGathering();
    window.addEventListener('ai-chat:trigger-generate-data-gathering', handler as EventListener);
    return () => {
      window.removeEventListener('ai-chat:trigger-generate-data-gathering', handler as EventListener);
    };
  }, [handleGenerateDataGathering]);

  const startPreliminaryResearchGeneration = useCallback((
    addUserMessage = true,
    runAnalyticsPayload?: { sections: string[] }
  ) => {
    setIsPreliminaryResearchGenerated(false);
    setIsPreliminaryResearchGenerationInProgress(true);
    setTakenPrelimActions(prev => ({ ...prev, generate: true }));
    if (addUserMessage) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'user', content: 'Generate Preliminary Research' }
      }));
    }
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: {
        id: 'prelim-research-loading',
        sender: 'ai',
        content: (
          <Stack gap="md" direction="column">
            <div style={{ fontWeight: 'bold' }}>Generating Preliminary Research...</div>
            <SequentialFadeList
              title="Looking into..."
              listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
              items={['Reviewing regulatory obligations',
                'Analysing policies',
                'Comparing historical scope',
                'Reviewing open findings',
                'Mapping risks and controls',
                'Assessing evidence ',
                'Developing scope direction',
                'processing....']}
              intervalMs={40000}
            />
          </Stack>
        )
      }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:generate-preliminary-research', {
      detail: runAnalyticsPayload ? { payload: runAnalyticsPayload } : undefined,
    }));
  }, []);

  useEffect(() => {
    if (!shouldAutoGeneratePrelim) {
      return;
    }

    setShouldAutoGeneratePrelim(false);
    startPreliminaryResearchGeneration(false);
  }, [shouldAutoGeneratePrelim, startPreliminaryResearchGeneration]);

  const handleSkipLrrUpload = useCallback(() => {
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Skip for now' }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
      detail: { id: PRELIM_LRR_UPLOAD_PROMPT_ID }
    }));
    setIsLrrUploadPromptVisible(false);
    if (lrrUploadPromptTimeoutRef.current) {
      clearTimeout(lrrUploadPromptTimeoutRef.current);
      lrrUploadPromptTimeoutRef.current = null;
    }
    startPreliminaryResearchGeneration(false);
  }, [PRELIM_LRR_UPLOAD_PROMPT_ID, startPreliminaryResearchGeneration]);

  const handleGeneratePreliminaryResearch = useCallback(() => {
    setIsLrrUploadPromptVisible(true);
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Generate Preliminary Research' }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: {
        id: PRELIM_LRR_UPLOAD_PROMPT_ID,
        sender: 'ai',
        content: (
          <Stack gap="md" direction="column">
            <AiResponse isLoading>
              <AutoLoadingProgress
                durationMs={1000}
                messages={[
                  'Profile analysis',
                  'Data control',
                  'Finding data',
                  'Executive summary',
                  'Complete'
                ]}
                prefix="Preparing"
              />
            </AiResponse>
          </Stack>
        )
      }
    }));

    if (lrrUploadPromptTimeoutRef.current) {
      clearTimeout(lrrUploadPromptTimeoutRef.current);
    }

    lrrUploadPromptTimeoutRef.current = setTimeout(() => {
      window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
        detail: { id: PRELIM_LRR_UPLOAD_PROMPT_ID }
      }));
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          id: PRELIM_LRR_UPLOAD_PROMPT_ID,
          sender: 'ai',
          content: (
            <div className={styles['lrr-upload-flow']}>
              <div className={styles['lrr-upload-title']}>Would you like to upload the LRR addresses?</div>

              <Button
                icon={<DocumentOutline />}
                variant="link"
                className={styles['lrr-upload-outline-button']}
                onClick={() => setIsAddRecipientModalOpen(true)}
              >
                <>Upload Files or Address (URLs)</>
              </Button>

              <div className={styles['lrr-upload-actions-row']}>
                <Button variant="link" onClick={handleSkipLrrUpload}>Skip for now</Button>
                <Button disabled>Submit</Button>
              </div>
            </div>
          )
        }
      }));
      lrrUploadPromptTimeoutRef.current = null;
    }, 4000);
  }, [PRELIM_LRR_UPLOAD_PROMPT_ID, handleSkipLrrUpload]);

  const handleSwitchToEditContent = useCallback(() => {
    setChatMode('Edit Content');
    window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
      detail: { id: PRELIM_EDIT_CONTENT_PROMPT_ID }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Edit Content enabled' }
    }));
  }, [PRELIM_EDIT_CONTENT_PROMPT_ID]);

  const handleExcludeSourceDocumentsClick = useCallback(async () => {
    if (!planNumber) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'ai', content: 'Error: Plan number not found. Please ensure you are on the correct page.' }
      }));
      return;
    }

    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Exclude Source Documents' }
    }));

    setTakenPrelimActions(prev => ({ ...prev, exclude: true }));
    setExcludeSourceMode(null);
    setIsExcludeSourceModeDropdownOpen(false);
    setSelectedHistoricalPlanItemNumbers([]);
    setHistoricalSearchText('');
    setOpenDropdownType(null);
    setIsHistoricalDropdownOpen(false);
    setIsExcludeFlowVisible(true);
  }, [planNumber]);

  const handleSelectExcludeSourceMode = useCallback(async (mode: ExclusionSourceMode) => {
    if (!planNumber) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'ai', content: 'Error: Plan number not found. Please ensure you are on the correct page.' }
      }));
      return;
    }

    setExcludeSourceMode(mode);
    setIsExcludeSourceModeDropdownOpen(false);
    setOpenDropdownType(null);
    setIsHistoricalDropdownOpen(false);
    setSelectedByType({
      Policies: [],
      KOD: [],
      'Procedure Documents': [],
    });
    setSelectedHistoricalPlanItemNumbers([]);

    try {
      setIsExcludeActionLoading(true);

      if (mode === 'documents') {
        const response = await fetchPreliminaryResearchSourceDocuments(planNumber);
        setDocumentsByType(normalizeDocumentsByType(response.documentsByType));
        return;
      }

      const planItems = await fetchHistoricalPreliminaryResearchSourceDocuments(planNumber);
      setHistoricalPlanItems(planItems);
    } catch (error) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'ai', content: 'Unable to process the request, Please try again.' }
      }));
      setExcludeSourceMode(null);
    } finally {
      setIsExcludeActionLoading(false);
    }
  }, [normalizeDocumentsByType, planNumber]);

  const toggleDocumentSelection = useCallback((type: PreliminaryResearchDocumentType, documentId: string) => {
    setSelectedByType(prev => {
      const selectedForType = prev[type];
      const exists = selectedForType.includes(documentId);
      return {
        ...prev,
        [type]: exists
          ? selectedForType.filter(id => id !== documentId)
          : [...selectedForType, documentId],
      };
    });
  }, []);

  const clearTypeSelection = useCallback((type: PreliminaryResearchDocumentType) => {
    setSelectedByType(prev => ({
      ...prev,
      [type]: [],
    }));
  }, []);

  const toggleHistoricalItemSelection = useCallback((planItemNumber: number) => {
    setSelectedHistoricalPlanItemNumbers((prev) => {
      return prev.includes(planItemNumber)
        ? prev.filter((value) => value !== planItemNumber)
        : [...prev, planItemNumber];
    });
  }, []);

  const clearHistoricalSelection = useCallback(() => {
    setSelectedHistoricalPlanItemNumbers([]);
  }, []);

  const closeExcludeFlow = useCallback(() => {
    setIsExcludeFlowVisible(false);
    setExcludeSourceMode(null);
    setIsExcludeSourceModeDropdownOpen(false);
    setOpenDropdownType(null);
    setIsHistoricalDropdownOpen(false);
    setPrelimStatusMessage('');
    setHistoricalSearchText('');
    setSelectedHistoricalPlanItemNumbers([]);
    setSearchByType({
      Policies: '',
      KOD: '',
      'Procedure Documents': '',
    });
    setSelectedByType({
      Policies: [],
      KOD: [],
      'Procedure Documents': [],
    });
  }, []);

  const handleCancelExcludeSourceDocuments = useCallback(() => {
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Cancel' }
    }));
    setTakenPrelimActions(prev => ({
      ...prev,
      exclude: false,
      regenerate: false,
      cancel: false,
    }));
    closeExcludeFlow();
  }, [closeExcludeFlow]);

  const handleChatModeChange = useCallback((mode: 'Chat Only' | 'Edit Content') => {
    if (mode !== chatMode) {
      if (mode === 'Chat Only') {
        closeExcludeFlow();
        setTakenPrelimActions(prev => ({
          ...prev,
          exclude: false,
          regenerate: false,
          cancel: false,
        }));
      }

      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'user',
          content: mode === 'Chat Only' ? 'Chat Only enabled' : 'Edit Content enabled'
        }
      }));
    }

    setChatMode(mode);
  }, [chatMode, closeExcludeFlow]);

  const handleRegeneratePreliminaryResearch = useCallback(async () => {
    if (!planNumber) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'ai', content: 'Error: Plan number not found. Please ensure you are on the correct page.' }
      }));
      return;
    }

    if (!excludeSourceMode) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'ai', content: 'Please select an exclusion source first.' }
      }));
      return;
    }

    if (!hasSelectedSourceDocuments) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: excludeSourceMode === 'historical'
            ? 'Please select at least one past review item.'
            : 'Please select at least one source document from Policies, KOD, or Procedure Documents.'
        }
      }));
      return;
    }

    try {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'user', content: 'Regenerate PR' }
      }));
      setPrelimStatusMessage('Source documents getting removed.');
      setTakenPrelimActions(prev => ({ ...prev, regenerate: true }));
      setIsExcludeActionLoading(true);

      if (excludeSourceMode === 'historical') {
        const selectedPlanItems = historicalPlanItems.filter((item) => (
          selectedHistoricalPlanItemNumbers.includes(item.planItemNumber)
        ));

        await deleteHistoricalPreliminaryResearchSourceDocuments(planNumber, selectedPlanItems);
      } else {
        await regeneratePreliminaryResearchWithExclusions({
          planNumber,
          exclusions: selectedByType,
        });
      }

      if (!shouldShowReGeneratePreliminaryResearchByTaskStatus) {
        setTakenPrelimActions(prev => ({
          ...prev,
          regenerate: false,
          cancel: false,
        }));
        closeExcludeFlow();
        setPrelimStatusMessage('');
        window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
          detail: {
            sender: 'ai',
            content: 'Source documents were removed successfully. Regeneration is not available at this stage.'
          }
        }));
        return;
      }
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: 'Source documents were removed successfully. Proceeding to regenerate Preliminary Research.'
        }
      }));
      setIsPreliminaryResearchGenerated(false);
      setIsPrelimRegenerationInProgress(true);
      setTakenPrelimActions(prev => ({
        ...prev,
        regenerate: false,
        cancel: false,
      }));
      closeExcludeFlow();
      startPreliminaryResearchGeneration(false, {
        sections: excludeSourceMode === 'historical'
          ? REGENERATE_PRELIMINARY_RESEARCH_HISTORICAL_SECTIONS
          : REGENERATE_PRELIMINARY_RESEARCH_SECTIONS,
      });
    } catch (error) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: { sender: 'ai', content: 'Unable to process the request, Please try again.' }
      }));
      setTakenPrelimActions(prev => ({
        ...prev,
        exclude: false,
        regenerate: false,
        cancel: false,
      }));
      closeExcludeFlow();
      setPrelimStatusMessage('');
    } finally {
      setIsExcludeActionLoading(false);
    }
  }, [closeExcludeFlow, excludeSourceMode, hasSelectedSourceDocuments, historicalPlanItems, planNumber, selectedByType, selectedHistoricalPlanItemNumbers, shouldShowReGeneratePreliminaryResearchByTaskStatus, startPreliminaryResearchGeneration]);

  const handleGenerateDiscoveryWalkthrough = useCallback(() => {
    if (!shouldShowGenerateDiscoveryWalkthroughByTaskStatus) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: 'Generate Discovery Walkthrough is not available at this stage.'
        }
      }));
      return;
    }

    onSend('Generate Discovery Walkthrough');
  }, [onSend, shouldShowGenerateDiscoveryWalkthroughByTaskStatus]);

  const handleGenerateScopeRecommendation = useCallback(() => {
    if (isScopeRecommendationTaskDefinition && !hasGenerateScopeRecommendationAction) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: 'Generate Scope Recommendation is not available at this stage.'
        }
      }));
      return;
    }

    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Generate Scope Recommendation' }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: {
        id: 'scope-recommendation-loading',
        sender: 'ai',
        content: (
          <Stack gap="md" direction="column">
            <div style={{ fontWeight: 'bold' }}>Generating Scope Recommendation...</div>
            <SequentialFadeList
              title="Looking into..."
              listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
              items={['Reviewing regulatory obligations',
                'Analysing policies',
                'Comparing historical scope',
                'Reviewing open findings',
                'Mapping risks and controls',
                'Assessing evidence ',
                'Developing scope direction',
                'processing....'
              ]}
              intervalMs={40000}
            />
          </Stack>
        )
      }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:generate-scope-recommendation'));
  }, [isScopeRecommendationTaskDefinition, hasGenerateScopeRecommendationAction]);

  const handleGenerateTestSteps = useCallback(() => {
    if (!hasGenerateTestStepsAction) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: 'Generate Test Steps is not available for your permissions.'
        }
      }));
      return;
    }

    onSend('Generate Test Steps');
  }, [hasGenerateTestStepsAction, onSend]);

  const handleGenerateFinalScopingDocument = useCallback(() => {
    if (isScopingDocumentTaskDefinition && !hasGenerateFinalScopingDocumentAction) {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
        detail: {
          sender: 'ai',
          content: 'Generate Final Scope Document is not available at this stage.'
        }
      }));
      return;
    }

    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: { sender: 'user', content: 'Generate Final Scope Document' }
    }));
    window.dispatchEvent(new CustomEvent('ai-chat:generate-final-scope-document'));
  }, [isScopingDocumentTaskDefinition, hasGenerateFinalScopingDocumentAction]);

  useEffect(() => {
    const pr = () => handleGeneratePreliminaryResearch();
    const dw = () => handleGenerateDiscoveryWalkthrough();
    const sr = () => handleGenerateScopeRecommendation();
    const ts = () => handleGenerateTestSteps();
    window.addEventListener('ai-chat:trigger-generate-preliminary-research', pr as EventListener);
    window.addEventListener('ai-chat:trigger-generate-discovery-walkthrough', dw as EventListener);
    window.addEventListener('ai-chat:trigger-generate-scope-recommendation', sr as EventListener);
    window.addEventListener('ai-chat:trigger-generate-test-steps', ts as EventListener);
    return () => {
      window.removeEventListener('ai-chat:trigger-generate-preliminary-research', pr as EventListener);
      window.removeEventListener('ai-chat:trigger-generate-discovery-walkthrough', dw as EventListener);
      window.removeEventListener('ai-chat:trigger-generate-scope-recommendation', sr as EventListener);
      window.removeEventListener('ai-chat:trigger-generate-test-steps', ts as EventListener);
    };
  }, [handleGeneratePreliminaryResearch, handleGenerateDiscoveryWalkthrough, handleGenerateScopeRecommendation, handleGenerateTestSteps]);

  useEffect(() => {
    const prelimSyncHandler = (event: Event) => {
      const customEvent = event as CustomEvent<{ status?: string }>;
      const { status } = customEvent.detail || {};

      if (status === 'generating') {
        setIsPreliminaryResearchGenerated(false);
        setIsPreliminaryResearchGenerationInProgress(true);
        setGenerationLoadingState('preliminary-research', true);
      }

      if (status === 'completed') {
        setIsPreliminaryResearchGenerated(true);
        setIsPreliminaryResearchGenerationInProgress(false);
        clearGenerationLoadingStateForTab('preliminary-research');
        setIsLrrUploadPromptVisible(false);
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: PRELIM_LRR_UPLOAD_PROMPT_ID }
        }));
        const isEditContentMode = chatMode === 'Edit Content';
        const prelimSuccessMessage = isPrelimRegenerationInProgress
          ? 'Premilary research regenrate successfully'
          : 'Preliminary research has been generated successfully.';

        if (currentTab === 'preliminary-research') {
          window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
            detail: {
              id: PRELIM_EDIT_CONTENT_PROMPT_ID,
              sender: 'ai',
              content: (
                <Stack gap="sm" direction="column">
                  <div>{prelimSuccessMessage}</div>
                  {!isEditContentMode && (
                    <AiQuestions
                      className={styles['ai-questions']}
                      header={<div className={styles['recommended-actions-header']}>{"To edit the policies please move to Edit Content."}</div>}
                    >
                      <AiQuestionsPrompt onClick={handleSwitchToEditContent}>
                        Edit Content
                      </AiQuestionsPrompt>
                    </AiQuestions>
                  )}
                  
                </Stack>
              )
            }
          }));
        } else {
          emitOrQueueGenerationResult('preliminary-research', prelimSuccessMessage, currentPlanNumber);
        }
      }

      if (status === 'failed') {
        setIsPreliminaryResearchGenerated(false);
        setIsPreliminaryResearchGenerationInProgress(false);
        clearGenerationLoadingStateForTab('preliminary-research');
        setIsLrrUploadPromptVisible(false);
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: PRELIM_LRR_UPLOAD_PROMPT_ID }
        }));
      }

      if (status === 'completed' || status === 'failed') {
        setIsPrelimRegenerationInProgress(false);
        setTakenPrelimActions(prev => ({
          ...prev,
          exclude: false,
          regenerate: false,
          cancel: false,
        }));
      }
    };

    window.addEventListener('preliminary-research:sync', prelimSyncHandler as EventListener);
    return () => {
      window.removeEventListener('preliminary-research:sync', prelimSyncHandler as EventListener);
    };
  }, [PRELIM_EDIT_CONTENT_PROMPT_ID, PRELIM_LRR_UPLOAD_PROMPT_ID, chatMode, clearGenerationLoadingStateForTab, currentPlanNumber, currentTab, emitOrQueueGenerationResult, handleSwitchToEditContent, isPrelimRegenerationInProgress, setGenerationLoadingState]);

  useEffect(() => {
    const handleGenerationSyncResult = (
      tab: string,
      status: string | undefined,
      message: string | undefined,
      targetPlanNumber: string,
      loadingMessageId?: string,
      completedFallback?: string,
      failedFallback?: string,
    ) => {
      if (status !== 'completed' && status !== 'failed') {
        return;
      }

      if (loadingMessageId) {
        window.dispatchEvent(new CustomEvent('ai-chat:remove-message', {
          detail: { id: loadingMessageId }
        }));
      }

      if (tab === 'data-gathering') {
        clearGenerationLoadingStateForTab('data-gathering');
      }
      if (tab === 'discovery-walkthrough') {
        clearGenerationLoadingStateForTab('discovery-walkthrough');
      }
      if (tab === 'scope-recommendation') {
        clearGenerationLoadingStateForTab('scope-recommendation');
      }
      if (tab === 'test-steps') {
        clearGenerationLoadingStateForTab('test-steps');
      }

      const content = status === 'completed'
        ? (message || completedFallback || 'Generation completed successfully.')
        : (message || failedFallback || 'Generation failed. Please try again.');

      emitOrQueueGenerationResult(tab, content, targetPlanNumber);
    };

    const dataGatheringSyncHandler = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string; status?: string; message?: string }>;
      const { planNumber: eventPlanNumber, status, message } = customEvent.detail || {};
      const targetPlanNumber = String(eventPlanNumber || currentPlanNumber || '').trim();
      handleGenerationSyncResult(
        'data-gathering',
        status,
        message,
        targetPlanNumber,
        'data-gathering-loading',
        'Data gathering completed successfully.',
        'Data gathering generation failed. Please try again.'
      );
    };

    const discoveryWalkthroughSyncHandler = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string; status?: string; message?: string }>;
      const { planNumber: eventPlanNumber, status, message } = customEvent.detail || {};
      const targetPlanNumber = String(eventPlanNumber || currentPlanNumber || '').trim();
      handleGenerationSyncResult(
        'discovery-walkthrough',
        status,
        message,
        targetPlanNumber,
        'discovery-walkthrough-loading',
        'Discovery Walkthrough has been generated successfully.',
        'Failed to generate Discovery Walkthrough. Please try again.'
      );
    };

    const scopeRecommendationSyncHandler = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string; status?: string; message?: string }>;
      const { planNumber: eventPlanNumber, status, message } = customEvent.detail || {};
      const targetPlanNumber = String(eventPlanNumber || currentPlanNumber || '').trim();
      handleGenerationSyncResult(
        'scope-recommendation',
        status,
        message,
        targetPlanNumber,
        'scope-recommendation-loading',
        'Scope Recommendation has been generated successfully.',
        'Failed to generate Scope Recommendation. Please try again.'
      );
    };

    const testStepsSyncHandler = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string; status?: string; message?: string }>;
      const { planNumber: eventPlanNumber, status, message } = customEvent.detail || {};
      const targetPlanNumber = String(eventPlanNumber || currentPlanNumber || '').trim();

      if (!eventPlanNumber || targetPlanNumber === currentPlanNumber) {
        if (status === 'completed') {
          setIsTestStepsGenerated(true);
          setIsTestStepsUploadFlowVisible(false);
        }
        if (status === 'failed') {
          setIsTestStepsGenerated(false);
          setIsTestStepsUploadFlowVisible(false);
        }
      }

      handleGenerationSyncResult(
        'test-steps',
        status,
        message,
        targetPlanNumber,
        'test-steps-loading',
        'Test Steps have been generated successfully.',
        'Failed to generate Test Steps. Please try again.'
      );
    };

    const finalScopeSyncHandler = (event: Event) => {
      const customEvent = event as CustomEvent<{ planNumber?: string; status?: string; message?: string }>;
      const { planNumber: eventPlanNumber, status, message } = customEvent.detail || {};
      const targetPlanNumber = String(eventPlanNumber || currentPlanNumber || '').trim();
      handleGenerationSyncResult(
        'final-scope-document',
        status,
        message,
        targetPlanNumber,
        undefined,
        'Final Scope Document has been generated.',
        'Failed to generate Final Scope Document.'
      );
    };

    window.addEventListener('data-gathering:sync', dataGatheringSyncHandler as EventListener);
    window.addEventListener('discovery-walkthrough:sync', discoveryWalkthroughSyncHandler as EventListener);
    window.addEventListener('scope-recommendation:sync', scopeRecommendationSyncHandler as EventListener);
    window.addEventListener('test-steps:sync', testStepsSyncHandler as EventListener);
    window.addEventListener('final-scope-document:sync', finalScopeSyncHandler as EventListener);
    return () => {
      window.removeEventListener('data-gathering:sync', dataGatheringSyncHandler as EventListener);
      window.removeEventListener('discovery-walkthrough:sync', discoveryWalkthroughSyncHandler as EventListener);
      window.removeEventListener('scope-recommendation:sync', scopeRecommendationSyncHandler as EventListener);
      window.removeEventListener('test-steps:sync', testStepsSyncHandler as EventListener);
      window.removeEventListener('final-scope-document:sync', finalScopeSyncHandler as EventListener);
    };
  }, [clearGenerationLoadingStateForTab, currentPlanNumber, emitOrQueueGenerationResult]);

  useEffect(() => {
    const pendingKey = buildPendingGenerationResultKey(currentTab, currentPlanNumber);
    const pendingMessage = pendingGenerationResultByKey[pendingKey];
    if (!pendingMessage) {
      return;
    }

    window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
      detail: {
        sender: 'ai',
        content: pendingMessage,
      }
    }));

    setPendingGenerationResultByKey((prev) => {
      const next = { ...prev };
      delete next[pendingKey];
      return next;
    });
  }, [buildPendingGenerationResultKey, currentPlanNumber, currentTab, pendingGenerationResultByKey]);

  const isChatInputDisabled =
    isInputDisabled ||
    isTextareaLockedByTaskDefinition ||
    isNoirTextareaLockedByTaskStatus ||
    isNorTextareaLockedByTaskStatus ||
    isPreliminaryResearchTextareaLockedByTaskStatus ||
    isDiscoveryWalkthroughTextareaLockedByTaskStatus ||
    isScopeRecommendationTextareaLockedByTaskStatus ||
    isTestStepsTextareaLockedByTaskStatus ||
    isScopingDocumentTextareaLockedByTaskStatus;

  const shouldRenderPreliminaryResearchSmartEditor =
    currentTab === 'preliminary-research' && chatMode === 'Edit Content';

  const chatBubbleTextStyle: React.CSSProperties = {
    whiteSpace: 'pre-wrap',
    overflowWrap: 'anywhere',
    wordBreak: 'break-word',
    maxWidth: '100%',
  };


  return (
    <Card
      outlined
      radius="lg"
      raise="2-subtle"
      className={styles['ai-chat-card']}
      style={{ height: '100%', flexGrow: 1, width: '100%', minWidth: 0 }}
    >
      <AddRecipientModal
        isOpen={isAddRecipientModalOpen}
        onClose={() => {
          setIsAddRecipientModalOpen(false);
          setIsTestStepsUploadFlowVisible(false);
        }}
        onUrlsSubmit={handleLrrUrlsSubmit}
        onPdfSubmit={handleLrrPdfSubmit}
        isUrls={true}
        title="Upload LRR"
      />
      <CardHeader>
        <LeftSlot>
          <Stack gap="xs">
            <CardTitle content="AI Assistant" />
          </Stack>
        </LeftSlot>
      </CardHeader>
      <CurrentPlan />

      <div ref={scrollRef} className={styles['chat-history']}>
        {messages.map((msg) => (
          msg.sender === 'user' ? (
            <AiQuestion key={msg.id} className={styles['ai-questions']}>
              <div style={chatBubbleTextStyle}>{msg.content}</div>
            </AiQuestion>
          ) : msg.id === PRELIM_LRR_UPLOAD_PROMPT_ID ? (
            <React.Fragment key={msg.id}>{msg.content}</React.Fragment>
          ) : (
            <AiResponse key={msg.id} isLoading={msg.isStreaming} name="AI Assistant" className={styles['ai-questions']}>
              <div style={chatBubbleTextStyle}>{msg.content}</div>
            </AiResponse>
          )
        ))}

        {shouldRenderPersistentGenerationLoading && currentTabLoadingConfig && (
          <AiResponse name="AI Assistant" className={styles['ai-questions']}>
            <Stack gap="md" direction="column">
              <div style={{ fontWeight: 'bold' }}>{currentTabLoadingConfig.title}</div>
              <SequentialFadeList
                title="Looking into..."
                listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
                items={currentTabLoadingConfig.items}
                intervalMs={currentTabLoadingConfig.intervalMs}
              />
            </Stack>
          </AiResponse>
        )}

        {isGenerating && (
          <AiResponse isLoading={true} name="AI Assistant" className={styles['ai-questions']} />
        )}

        {isLrrUploadInProgress && (
          <AiQuestion className={styles['ai-questions']}>
            <Stack gap="sm" direction="column">
              <div>{lrrUploadStatusMessage || (lrrUploadSourceType === 'pdf' ? 'Uploading LRR PDF...' : 'Uploading LRR URLs...')}</div>
              <AutoLoadingProgress
                intervalMs={180000}
                messages={['Uploading...', 'Processing...', 'Checking status...']}
              />
              {lrrUploadRunId ? <div>{`Run ID: ${lrrUploadRunId}`}</div> : null}
            </Stack>
          </AiQuestion>
        )}

        {((messages.length === 0 && !shouldRenderPersistentGenerationLoading) || currentTab === 'preliminary-research' || currentTab === 'test-steps') && (
          <>
            {currentTab === 'scope-recommendation' ? (
              <AiQuestions
                className={styles['ai-questions']}
                header={scopeRecommendationHeader}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '100%' }}>
                  {!isScopeRecEnabled && (
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                      {isCurrentTabActionable && (
                        <AiQuestionsPrompt
                          disabled={!shouldShowGenerateScopeRecommendationByTaskStatus}
                         onClick={() => onSend('Yes')}>Yes</AiQuestionsPrompt>
                      )}
                       <AiQuestionsPrompt
                      disabled={!shouldShowGenerateScopeRecommendationByTaskStatus}
                      onClick={() => {
                        window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
                          detail: { sender: 'user', content: 'Generate Scope Recommendation' }
                        }));
                        window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
                          detail: {
                            id: 'scope-recommendation-loading',
                            sender: 'ai',
                            content: (
                              <Stack gap="md" direction="column">
                                <div style={{ fontWeight: 'bold' }}>Generating Scope Recommendation...</div>
                                <SequentialFadeList
                                  title="Looking into..."
                                  listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
                                  items={['Reviewing regulatory obligations',
                                    'Analysing policies',
                                    'Comparing historical scope',
                                    'Reviewing open findings',
                                    'Mapping risks and controls',
                                    'Assessing evidence ',
                                    'Developing scope direction',
                                    'processing....']}
                                  intervalMs={40000}
                                />
                              </Stack>
                            )
                          }
                        }));
                        window.dispatchEvent(new CustomEvent('ai-chat:generate-scope-recommendation'));
                      }}
                    >
                      Generate Scope Recommendation
                    </AiQuestionsPrompt>
                    </div>
                  )}
                </div>
              </AiQuestions>
            ) : currentTab === 'preliminary-research' ? (
              isPrelimRegenerationInProgress || isPreliminaryResearchGenerationInProgress || isPreliminaryResearchLoadingPersisted || isLrrUploadInProgress || shouldAutoGeneratePrelim ? null : (
              <AiQuestions
                className={styles['ai-questions']}
                header={null}
              >
                {!isLrrUploadPromptVisible && !isLrrUploadInProgress && !shouldAutoGeneratePrelim && !isExcludeFlowVisible && !isFetchingSourceDocuments && !isPrelimRegenerationInProgress && (
                  <div className={styles['prelim-actions-container']}>
                    {canShowGeneratePreliminaryResearchAction && !isLrrUploadPromptVisible && (
                      <AiQuestionsPrompt
                        onClick={handleGeneratePreliminaryResearch}
                        disabled={!shouldShowGeneratePreliminaryResearchByTaskStatus}
                      >
                        Generate Preliminary Research
                      </AiQuestionsPrompt>
                    )}
                  </div>
                )}

                {isExcludeFlowVisible && (
                  <>
                  <div className={styles['exclude-panel']}>
                    <div className={styles['exclude-panel-header']}>
                      <div className={styles['exclude-panel-title']}>
                        Choose what to exclude from Preliminary Research
                      </div>
                      <div className={styles['exclude-panel-subtitle']}>
                        First, select a section. Then choose source documents to exclude.
                      </div>
                    </div>

                    <div className={styles['exclude-dropdown-group']}>
                      <Button
                        variant="standard"
                        size="sm"
                        className={styles['exclude-dropdown-trigger']}
                        onClick={() => setIsExcludeSourceModeDropdownOpen((prev) => !prev)}
                        icon={isExcludeSourceModeDropdownOpen ? <SingleChevronUpSolid /> : <SingleChevronDownSolid />}
                      >
                        <span>{excludeSourceModeLabel}</span>
                      </Button>

                      {isExcludeSourceModeDropdownOpen && (
                        <div className={styles['exclude-dropdown-surface']}>
                          <button
                            type="button"
                            className={styles['exclude-doc-item']}
                            onClick={() => handleSelectExcludeSourceMode('historical')}
                          >
                            <span>Past Review</span>
                          </button>
                          <button
                            type="button"
                            className={styles['exclude-doc-item']}
                            onClick={() => handleSelectExcludeSourceMode('documents')}
                          >
                            <span>Policies, KODs, Procedures</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {excludeSourceMode && (
                      <div className={styles['exclude-panel-header']} style={{ marginTop: '16px' }}>
                        <div className={styles['exclude-panel-subtitle']} style={{ marginBottom: '8px' }}>
                            Now pick one or more source documents from the selected section                        </div>
                        <div className={styles['exclude-panel-title']}>
                          Select source documents to exclude
                        </div>
                        <div className={styles['exclude-panel-subtitle']}>
                          {excludeSourceMode === 'historical'
                            ? 'Select one or more past review and broad scope items to exclude from the regenerated Preliminary Research.'
                            : 'Select one or more policies, KODs, and procedures to exclude from the regenerated Preliminary Research.'}
                        </div>
                      </div>
                    )}

                    {excludeSourceMode === 'documents' && documentTypes.map((type) => {
                      const typeDocuments = documentsByType[type] || [];
                      const searchText = searchByType[type].toLowerCase().trim();
                      const filteredDocuments = typeDocuments.filter(doc => {
                        const cleanTitle = getCleanDocumentName(doc.title).toLowerCase();
                        return doc.title.toLowerCase().includes(searchText) || cleanTitle.includes(searchText);
                      });
                      const selectedCount = selectedByType[type].length;

                      return (
                        <div className={styles['exclude-dropdown-group']} key={type}>
                          <Button
                            variant="standard"
                            size="sm"
                            className={styles['exclude-dropdown-trigger']}
                            onClick={() => setOpenDropdownType(prev => prev === type ? null : type)}
                            icon={openDropdownType === type ? <SingleChevronUpSolid /> : <SingleChevronDownSolid />}
                          >
                            <span>{type}{selectedCount > 0 ? ` (${selectedCount})` : ''}</span>
                          </Button>

                          {openDropdownType === type && (
                            <div className={styles['exclude-dropdown-surface']}>
                              <TextInput
                                value={searchByType[type]}
                                onChange={(e: any) => setSearchByType(prev => ({ ...prev, [type]: e.target.value }))}
                                className={styles['exclude-search-input']}
                                placeholder={`Search ${type}`}
                              />

                              <div className={styles['exclude-doc-list']}>
                                {filteredDocuments.length > 0 ? (
                                  filteredDocuments.map(doc => (
                                    <button
                                      type="button"
                                      key={doc.id}
                                      className={styles['exclude-doc-item']}
                                      onClick={() => toggleDocumentSelection(type, doc.id)}
                                    >
                                      <span className={styles['exclude-doc-checkbox']}>
                                        {selectedByType[type].includes(doc.id) && (
                                          <CheckmarkSolid style={{ width: '12px', height: '12px', color: 'var(--wadk-text-basic-action-link, #0550D1)' }} />
                                        )}
                                      </span>
                                      <span>{getCleanDocumentName(doc.title)}</span>
                                    </button>
                                  ))
                                ) : (
                                  <div className={styles['exclude-empty-state']}>No documents found.</div>
                                )}
                              </div>

                              <div className={styles['exclude-dropdown-footer']}>
                                <button
                                  type="button"
                                  className={styles['exclude-clear-button']}
                                  onClick={() => clearTypeSelection(type)}
                                >
                                  Clear Selection
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}

                    {excludeSourceMode === 'historical' && (
                      <div className={styles['exclude-dropdown-group']}>
                        <Button
                          variant="standard"
                          size="sm"
                          className={styles['exclude-dropdown-trigger']}
                          onClick={() => setIsHistoricalDropdownOpen((prev) => !prev)}
                          icon={isHistoricalDropdownOpen ? <SingleChevronUpSolid /> : <SingleChevronDownSolid />}
                        >
                          <span>{historicalDropdownLabel}</span>
                        </Button>

                        {isHistoricalDropdownOpen && (
                          <div className={styles['exclude-dropdown-surface']}>
                            <TextInput
                              value={historicalSearchText}
                              onChange={(e: any) => setHistoricalSearchText(e.target.value)}
                              className={styles['exclude-search-input']}
                              placeholder="Search past review items"
                            />

                            <div className={styles['exclude-doc-list']}>
                              {filteredHistoricalPlanItems.length > 0 ? (
                                filteredHistoricalPlanItems.map((item) => (
                                  <button
                                    type="button"
                                    key={item.planItemNumber}
                                    className={styles['exclude-doc-item']}
                                    onClick={() => toggleHistoricalItemSelection(item.planItemNumber)}
                                  >
                                    <span className={styles['exclude-doc-checkbox']}>
                                      {selectedHistoricalPlanItemNumbers.includes(item.planItemNumber) && (
                                        <CheckmarkSolid style={{ width: '12px', height: '12px', color: '#0550D1' }} />
                                      )}
                                    </span>
                                    <span>{item.planItemTitle}</span>
                                  </button>
                                ))
                              ) : (
                                <div className={styles['exclude-empty-state']}>No documents found.</div>
                              )}
                            </div>

                            <div className={styles['exclude-dropdown-footer']}>
                              <button
                                type="button"
                                className={styles['exclude-clear-button']}
                                onClick={clearHistoricalSelection}
                              >
                                Clear Selection
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {excludeSourceMode && (
                      <>
                        <div className={styles['exclude-panel-actions']}>
                          {!takenPrelimActions.regenerate && (
                            <AiQuestionsPrompt
                              onClick={handleRegeneratePreliminaryResearch}
                              disabled={isExcludeActionLoading || !hasSelectedSourceDocuments}
                            >
                              Remove documents and regenerate Preliminary Research
                            </AiQuestionsPrompt>
                          )}
                          {!takenPrelimActions.cancel && (
                            <AiQuestionsPrompt
                              onClick={handleCancelExcludeSourceDocuments}
                              disabled={isExcludeActionLoading}
                            >
                              Cancel
                            </AiQuestionsPrompt>
                          )}
                        </div>

                        <div className={styles['exclude-selection-summary']}>
                          Total of {totalSelectedDocuments} source documents selected.
                        </div>
                      </>
                    )}
                  </div>

                  {prelimStatusMessage && (
                    <AiResponse>
                      <div style={{ fontWeight: 'bold' }}>{prelimStatusMessage}</div>
                    </AiResponse>
                  )}
                  </>
                )}
              </AiQuestions>
              )
            ) : currentTab === 'data-gathering' ? (
              <AiQuestions
                className={styles['ai-questions']}
                header={recommendedActionsHeader}
              >
                <div style={{ display: 'flex', justifyContent: 'flex-start', width: '100%' }}>
                  {isCurrentTabActionable && (
                    <AiQuestionsPrompt onClick={handleGenerateDataGathering}>
                      Generate Data Gathering
                    </AiQuestionsPrompt>
                  )}
                </div>
              </AiQuestions>
            ) : currentTab === 'discovery-walkthrough' ? (
              <AiQuestions
                className={styles['ai-questions']}
                header={discoveryWalkthroughHeader}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '100%' }}>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    {isCurrentTabActionable && (
                      <AiQuestionsPrompt
                        disabled={!shouldShowGenerateDiscoveryWalkthroughByTaskStatus}
                        onClick={() => onSend('Yes')}
                      >
                        Yes
                      </AiQuestionsPrompt>
                    )}
                    <AiQuestionsPrompt
                      disabled={!shouldShowGenerateDiscoveryWalkthroughByTaskStatus}
                      onClick={handleGenerateDiscoveryWalkthrough}>
                      Generate Discovery Walkthrough
                    </AiQuestionsPrompt>
                  </div>
                </div>
              </AiQuestions>
            ) : currentTab === 'test-steps' ? (
              (isAddRecipientModalOpen || isTestStepsUploadFlowVisible || isTestStepsGenerationInProgress) ? null : (
              <AiQuestions
                className={styles['ai-questions']}
                header={shouldShowTestStepsUploadAction
                  ? <div className={styles['recommended-actions-header']}>Is there any additional information you would like to upload before generating Test Steps?</div>
                  : testStepsHeader}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '100%' }}>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    {!shouldShowTestStepsUploadAction ? (
                      <>
                        {isCurrentTabActionable && (
                          <AiQuestionsPrompt
                            disabled={!shouldShowGenerateTestStepsByTaskStatus}
                            onClick={() => {
                              setIsTestStepsUploadFlowVisible(true);
                              onSend('Yes');
                            }}
                          >
                            Yes
                          </AiQuestionsPrompt>
                        )}
                        <AiQuestionsPrompt
                          onClick={handleGenerateTestSteps}
                          disabled={!shouldShowGenerateTestStepsByTaskStatus}
                        >
                          Generate Test Steps
                        </AiQuestionsPrompt>
                      </>
                    ) : (
                      <AiQuestionsPrompt
                        onClick={() => {
                          setIsTestStepsUploadFlowVisible(true);
                          onSend('Yes');
                        }}
                      >
                        Upload
                      </AiQuestionsPrompt>
                    )}
                  </div>
                </div>
              </AiQuestions>
              )
            ) : currentTab === 'final-scope-document' ? (
              <AiQuestions
                className={styles['ai-questions']}
                header={recommendedActionsHeader}
              >
                <div style={{ display: 'flex', justifyContent: 'flex-start', width: '100%' }}>
                  <AiQuestionsPrompt
                    onClick={handleGenerateFinalScopingDocument}
                    disabled={!shouldShowGenerateFinalScopingDocumentByTaskStatus}
                  >
                      Generate Final Scope Document
                    </AiQuestionsPrompt>
                </div>
              </AiQuestions>
            ) : currentTab === 'nor' ? (
              <AiQuestions
                className={styles['ai-questions']}
                header={recommendedActionsHeader}
              >
                <div style={{ display: 'flex', justifyContent: 'flex-start', width: '100%' }}>
                  <AiQuestionsPrompt
                    onClick={() => onSend('Generate Nor')}
                    disabled={!shouldShowGenerateNorPrompt}
                  >
                      Generate Nor
                    </AiQuestionsPrompt>
                </div>
              </AiQuestions>
            ) : currentTab === 'noir' ? (
                 <AiResponse style={{maxHeight: 'fit-content'}}>
                <AiQuestions
                className={styles['ai-questions']}
                header={recommendedActionsHeader}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '100%' }}>
                  {!isScopeRecEnabled && (
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                      <AiQuestionsPrompt
                        onClick={() => onSend('Generate NOIR')}
                        disabled={!shouldShowGenerateNoirPrompt}
                      >Generate NOIR</AiQuestionsPrompt>
                      {shouldShowSkipNoirPrompt && (
                        <AiQuestionsPrompt onClick={async () => {
                        if (!planNumber) {
                          window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
                            detail: { sender: 'ai', content: 'Error: Plan number not found. Please ensure you are on the correct page.' }
                          }));
                          return;
                        }

                        const targetTab = isDataGatheringEnabled ? 'data-gathering' : 'preliminary-research';
                        const targetLabel = isDataGatheringEnabled ? 'Data Gathering' : 'Preliminary Research';

                        if (targetTab === 'preliminary-research') {
                          try {
                            await postJson('/dbaware-api-gateway/api/v1/actions', {
                              planNumber,
                              action: 'SKIP_NOIR',
                              payload: {
                                plan_item_number: planNumber,
                              },
                            });
                          } catch (error) {
                            console.error('Skip Noir Error:', error);
                            window.dispatchEvent(new CustomEvent('ai-chat:add-message', {
                              detail: { sender: 'ai', content: 'Unable to skip Noir right now. Please try again.' }
                            }));
                            return;
                          }
                        }

                        navigate(`/${targetTab}/${planNumber}`);
                      }} disabled={!hasSkipNoirAction}>{isDataGatheringEnabled ? 'Skip to Data Gathering' : 'Skip to Preliminary Research'}</AiQuestionsPrompt>
                      )}
                    </div>
                  )}
                </div>
              </AiQuestions>
                  </AiResponse>
            ) : null}
          </>
        )}
      </div>

      {currentTab !== 'data-gathering' && (
        <div className={styles['chat-input-container']}>
            <AiChatModeMenu
              currentTab={currentTab}
              selectedMode={chatMode}
              onModeChange={handleChatModeChange}
              isEditContentEnabled={
                currentTab === 'preliminary-research'
                  ? isPreliminaryResearchEditContentEnabled
                  : true
              }
            />
          {shouldRenderPreliminaryResearchSmartEditor ? (
            <div className={styles['chat-input-shell']}>
              <PreliminaryResearchEditMode
                badgeLabel={getBadgeLabel()}
                planNumber={currentPlanNumber}
                disabled={isChatInputDisabled}
                onInputChange={onInputChange}
                onSend={onSend}
              />
            </div>
          ) : (
            <div className={styles['chat-input-shell']}>
              <div className={styles['chat-input-badge']}>
                <StatusLabel
                  appearance="subtle-pill"
                  size="xs"
                  variant="neutral"
                >
                  {getBadgeLabel()}
                </StatusLabel>
              </div>
              <AiInputPanelContent
                className={styles['chat-input-panel']}
                onButtonClick={() => onSend()}
              >
                <AiInputPanelTextarea
                  placeholder={getInputPlaceholder()}
                  value={inputValue}
                  disabled={isChatInputDisabled}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => onInputChange(e.target.value)}
                  onKeyDown={(e: React.KeyboardEvent<HTMLTextAreaElement>) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      onSend();
                    }
                  }}
                />
              </AiInputPanelContent>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};
