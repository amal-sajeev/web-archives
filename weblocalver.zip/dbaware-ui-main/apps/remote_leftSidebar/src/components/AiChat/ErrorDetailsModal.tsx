import React, { useEffect, useState } from 'react';
import { Button } from '@wadk/ui';
import { SHOW_ERROR_MODAL_EVENT, dispatchErrorModal, type ApiErrorDetails } from '../../api/sharedApi';
import styles from './AiChat.module.css';

export { SHOW_ERROR_MODAL_EVENT, dispatchErrorModal };

export const ErrorDetailsModal: React.FC = () => {
  const [errorDetails, setErrorDetails] = useState<ApiErrorDetails | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const handler = (event: Event) => {
      const detail = (event as CustomEvent<ApiErrorDetails>).detail;
      if (!detail) return;
      setCopied(false);
      setErrorDetails(detail);
    };
    window.addEventListener(SHOW_ERROR_MODAL_EVENT, handler as EventListener);
    return () => {
      window.removeEventListener(SHOW_ERROR_MODAL_EVENT, handler as EventListener);
    };
  }, []);

  if (!errorDetails) return null;

  const rawJsonText = JSON.stringify(errorDetails.raw ?? errorDetails, null, 2);
  const titleText = errorDetails.title || errorDetails.operation || 'Request Failed';
  const statusLabel =
    errorDetails.status !== undefined
      ? `HTTP ${errorDetails.status}${errorDetails.statusText ? ` ${errorDetails.statusText}` : ''}`
      : 'Error';

  const handleCopy = async () => {
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(rawJsonText);
        setCopied(true);
      }
    } catch {
      // Ignore clipboard failure
    }
  };

  return (
    <div
      className={styles['error-modal-backdrop']}
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-chat-error-modal-title"
    >
      <div className={styles['error-modal-card']}>
        <div className={styles['error-modal-header']}>
          <div className={styles['error-modal-title-row']}>
            <h3 id="ai-chat-error-modal-title" className={styles['error-modal-title']}>
              {titleText}
            </h3>
            <span className={styles['error-modal-badge']}>{statusLabel}</span>
          </div>
          <button
            type="button"
            className={styles['error-modal-close']}
            onClick={() => setErrorDetails(null)}
            aria-label="Close error details"
          >
            ✕
          </button>
        </div>

        <div className={styles['error-modal-body']}>
          <div className={styles['error-modal-message']}>{errorDetails.message}</div>

          {(errorDetails.operation || errorDetails.endpoint) && (
            <div className={styles['error-modal-meta']}>
              {errorDetails.operation && <span>Operation: {errorDetails.operation}</span>}
              {errorDetails.endpoint && <span>Endpoint: {errorDetails.endpoint}</span>}
            </div>
          )}

          {Array.isArray(errorDetails.errorDetails) && errorDetails.errorDetails.length > 0 && (
            <div className={styles['error-modal-failures']}>
              <div className={styles['error-modal-section-label']}>Item Failures</div>
              <ul className={styles['error-modal-failure-list']}>
                {errorDetails.errorDetails.map((item, idx) => (
                  <li key={`err-item-${idx}`}>
                    <strong>{item.title || item.document_type || `Item ${idx + 1}`}</strong>
                    {': '}
                    {String(item.error || item.reason || item.detail || 'Failed')}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className={styles['error-modal-section-label']}>Raw Details</div>
          <pre className={styles['error-modal-pre']}>{rawJsonText}</pre>
        </div>

        <div className={styles['error-modal-footer']}>
          <Button variant="standard" size="sm" onClick={handleCopy}>
            {copied ? 'Copied JSON' : 'Copy JSON'}
          </Button>
          <Button variant="primary" size="sm" onClick={() => setErrorDetails(null)}>
            Dismiss
          </Button>
        </div>
      </div>
    </div>
  );
};
