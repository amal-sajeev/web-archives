import React, { useEffect, useState } from 'react';
import { ContextHelpOutline, DocumentOutline } from '@wadk/icons';
import styles from './AiChatModeMenu.module.css';

interface AiChatModeMenuProps {
  currentTab?: string;
  selectedMode?: 'Chat Only' | 'Edit Content';
  onModeChange?: (mode: 'Chat Only' | 'Edit Content') => void;
  isEditContentEnabled?: boolean;
}

export const AiChatModeMenu: React.FC<AiChatModeMenuProps> = ({
  currentTab = '',
  selectedMode,
  onModeChange,
  isEditContentEnabled = true,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const isNorOrNoir = currentTab === 'nor' || currentTab === 'noir';
  const canSelectEditContent = currentTab === 'nor' || currentTab === 'noir' || currentTab === 'preliminary-research';
  const [internalSelectedMode, setInternalSelectedMode] = useState<'Chat Only' | 'Edit Content'>(isNorOrNoir ? 'Edit Content' : 'Chat Only');
  const effectiveSelectedMode = selectedMode ?? internalSelectedMode;

  useEffect(() => {
    const defaultMode: 'Chat Only' | 'Edit Content' = isNorOrNoir ? 'Edit Content' : 'Chat Only';
    setInternalSelectedMode(defaultMode);
    setIsOpen(false);
  }, [isNorOrNoir]);

  const handleSelect = (value: 'Chat Only' | 'Edit Content') => {
    setInternalSelectedMode(value);
    onModeChange?.(value);
    setIsOpen(false);
  };

  const isChatOnlyDisabled = isNorOrNoir;
  const isEditContentDisabled = !canSelectEditContent || !isEditContentEnabled;

  return (
    <div className={styles['chat-mode-menu']}>
      <button
        type="button"
        className={styles['chat-mode-trigger']}
        onClick={() => setIsOpen((prev) => !prev)}
      >
        <span>{effectiveSelectedMode}</span>
        <span className={styles['chat-mode-chevron']}>▾</span>
      </button>
      {isOpen && (
        <div className={styles['chat-mode-dropdown']}>
          <button
            type="button"
            className={`${styles['chat-mode-item']} ${effectiveSelectedMode === 'Chat Only' ? styles['chat-mode-item-active'] : ''} ${isChatOnlyDisabled ? styles['chat-mode-item-disabled'] : ''}`}
            disabled={isChatOnlyDisabled}
            onClick={() => handleSelect('Chat Only')}
          >
            <span className={styles['chat-mode-item-icon']}>
              <ContextHelpOutline />
            </span>
            <span>
              <span className={styles['chat-mode-item-title']}>Chat Only</span>
              <span className={styles['chat-mode-item-description']}>Ask any questions on the output & get response on the chat</span>
            </span>
          </button>
          <button
            type="button"
            className={`${styles['chat-mode-item']} ${effectiveSelectedMode === 'Edit Content' ? styles['chat-mode-item-active'] : ''} ${isEditContentDisabled ? styles['chat-mode-item-disabled'] : ''}`}
            disabled={isEditContentDisabled}
            onClick={() => handleSelect('Edit Content')}
          >
            <span className={styles['chat-mode-item-icon']}>
              <DocumentOutline />
            </span>
            <span>
              <span className={styles['chat-mode-item-title']}>Edit Content</span>
              <span className={styles['chat-mode-item-description']}>Edit the generated output</span>
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
