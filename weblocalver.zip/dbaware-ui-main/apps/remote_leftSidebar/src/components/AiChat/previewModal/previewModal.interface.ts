export interface PreviewModalProps {
	isOpen: boolean;
	title: string;
	subject?: string;
	body?: string;
	fallbackText?: string;
	onClose: () => void;
	onAccept?: () => void;
	acceptText?: string;
	closeText?: string;
}
