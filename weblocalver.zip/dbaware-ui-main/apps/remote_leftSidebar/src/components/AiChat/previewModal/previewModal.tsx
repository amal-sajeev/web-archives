import React from 'react';
import { Button, OutlineButton, Text, ModalDialog } from '@wadk/ui';
import type { PreviewModalProps } from './previewModal.interface';
import './previewModal.css';

export const PreviewModal: React.FC<PreviewModalProps> = ({
	isOpen,
	title,
	subject,
	body,
	fallbackText,
	onClose,
	onAccept,
	acceptText = 'Accept',
	closeText = 'Close'
}) => {
	if (!isOpen) {
		return null;
	}

	return (
		<ModalDialog
			opened={isOpen}
			title={title}
			width="xl2"
			height="xl2"
			onClose={onClose}
			position="center"
			actions={
				<div className="preview-modal-actions">
					<OutlineButton onClick={onClose}>
						{closeText}
					</OutlineButton>
					{onAccept && (
						<Button variant="primary" onClick={onAccept}>
							{acceptText}
						</Button>
					)}
				</div>
			}
		>
			<div className="preview-modal-content">
				{subject && (
					<div className="preview-modal-section">
						<Text fontWeight="bold" size="sm" className="preview-modal-label">
							Subject:
						</Text>
						<Text size="md" className="preview-modal-text">
							{subject}
						</Text>
					</div>
				)}

				{body && (
					<div>
						<Text fontWeight="bold" size="sm" className="preview-modal-label">
							Body:
						</Text>
						<div className="preview-modal-text-scroll">
							<Text size="md" className="preview-modal-text">
								{body}
							</Text>
						</div>
					</div>
				)}

				{!subject && !body && fallbackText && (
					<div>
						<div className="preview-modal-text-scroll">
							<Text size="md" className="preview-modal-text">
								{fallbackText}
							</Text>
						</div>
					</div>
				)}
			</div>
		</ModalDialog>
	);
};



