import React, { useState } from 'react';
import { Stack, Box, Text, OutlineButton, FileUpload, Button, TextInput } from '@wadk/ui';
import { DocumentOutline, TrashOutline, CheckmarkSolid } from '@wadk/icons';
import { DraggableDialog, FileUploadList, ScreenReaderOnly } from 'com.db.rca.commons.afcc-components';
import type { RecipientItem } from '../../types/aiChat';
import './AddRecipientModal.css';

interface AddRecipientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit?: (items: RecipientItem[]) => void;
  onUrlsSubmit?: (payload: { urls: string[] }) => void;
  onPdfSubmit?: (files: File[]) => void;
  onFilesSubmit?: (files: File[]) => void;
  isUrls?: boolean;
  title?: string;
  fileAccept?: string;
  fileRestrictionsMessage?: string;
  allowMultipleFiles?: boolean;
  fileLabel?: string;
  useSingleModal?: boolean;
  openFileUploadModalOnly?: boolean;
}

export const AddRecipientModal: React.FC<AddRecipientModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  onUrlsSubmit,
  onPdfSubmit,
  onFilesSubmit,
  isUrls = false,
  title,
  fileAccept,
  fileRestrictionsMessage,
  allowMultipleFiles,
  fileLabel,
  useSingleModal = true,
  openFileUploadModalOnly = false,
}) => {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isFileUploadModalOpen, setIsFileUploadModalOpen] = useState(false);
  const [urlInputValue, setUrlInputValue] = useState('');
  const [insertedUrls, setInsertedUrls] = useState<string[]>([]);
  const [urlValidationError, setUrlValidationError] = useState('');
  const hasInsertedUrls = insertedUrls.length > 0;
  const hasUploadedFiles = uploadedFiles.length > 0;
  const uploadButtonText = isUrls && hasInsertedUrls && !hasUploadedFiles ? 'Submit' : 'Upload';
  const trimmedUrlInput = urlInputValue.trim();
  const resolvedFileAccept = fileAccept || (isUrls ? '.pdf' : '.txt');
  const resolvedFileRestrictionMessage = fileRestrictionsMessage || (isUrls ? 'Up to 200MB per file. PDF only.' : 'Up to 200MB per file. TXT only.');
  const resolvedAllowMultipleFiles = typeof allowMultipleFiles === 'boolean' ? allowMultipleFiles : !isUrls;
  const resolvedFileLabel = fileLabel || (isUrls ? '.pdf' : '.txt');

  const isValidHttpUrl = (value: string) => {
    try {
      const parsed = new URL(value);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  };

  const formatFileSize = (bytes: number): string => {
    const kb = bytes / 1024;
    if (kb < 1024) {
      return `${kb.toFixed(2)} KB`;
    }
    return `${(kb / 1024).toFixed(2)} MB`;
  };

  if (!isOpen) return null;

  const resetStateAndClose = () => {
    setUploadedFiles([]);
    setIsFileUploadModalOpen(false);
    setUrlInputValue('');
    setInsertedUrls([]);
    setUrlValidationError('');
    onClose();
  };

  const handleInsertLink = () => {
    const value = trimmedUrlInput;
    if (!value) return;

    if (!isValidHttpUrl(value)) {
      setUrlValidationError('Only http:// and https:// URLs are allowed.');
      return;
    }

    setInsertedUrls(prev => (prev.includes(value) ? prev : [...prev, value]));
    setUrlInputValue('');
    setUrlValidationError('');
  };

  const handleUploadClick = async () => {
    if (isUrls) {
      const linkItems: RecipientItem[] = insertedUrls.map((url) => ({
        id: Math.random().toString(36).substr(2, 9),
        type: 'Link',
        attachment: url,
        category: 'Not categorized',
        status: 'Uploaded'
      }));

      const fileItems: RecipientItem[] = uploadedFiles.map((file) => ({
        id: Math.random().toString(36).substr(2, 9),
        type: 'File',
        attachment: file.name,
        category: 'Not categorized',
        status: 'Uploaded'
      }));

      if (onSubmit) {
        onSubmit([...fileItems, ...linkItems]);
      }

      if (hasUploadedFiles && onPdfSubmit) {
        onPdfSubmit([...uploadedFiles]);
      } else if (hasInsertedUrls && onUrlsSubmit) {
        onUrlsSubmit({
          urls: [...insertedUrls],
        });
      }

      resetStateAndClose();
      return;
    }

    if (onFilesSubmit) {
      onFilesSubmit([...uploadedFiles]);
      resetStateAndClose();
      return;
    }

    const itemsToSave: RecipientItem[] = [];

    for (const file of uploadedFiles) {
      try {
        const text = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.onerror = reject;
          reader.readAsText(file);
        });

        const extractedEmails = text
          .split(/[\r\n,;]+/)
          .map(e => e.trim())
          .filter(e => e.length > 0 && e.includes('@'));

        itemsToSave.push({
          id: Math.random().toString(36).substr(2, 9),
          type: 'File',
          attachment: file.name,
          category: 'Not categorized',
          status: 'Uploaded',
          emails: extractedEmails
        });
      } catch (err) {
        console.error("Failed to read file", file.name, err);
      }
    }

    if (onSubmit) {
      onSubmit(itemsToSave);
    }

    resetStateAndClose();
  };

  if (openFileUploadModalOnly && !isUrls && !useSingleModal) {
    return (
      <DraggableDialog
        title="Upload Document"
        onClose={resetStateAndClose}
        style={{ minWidth: '600px' }}
        actions={
          <div style={{ display: 'flex', gap: '16px', justifyContent: 'flex-end', width: '100%' }}>
            <OutlineButton onClick={resetStateAndClose} variant="primary">Cancel</OutlineButton>
            <Button
              onClick={handleUploadClick}
              disabled={!hasUploadedFiles}
              variant="primary"
            >
              Upload
            </Button>
          </div>
        }
      >
        <Box>
          <Stack gap="base">
            <FileUpload
              className="add-recipient-file-upload"
              icon="upload"
              inputTitle={isUrls ? 'Select file to upload or drag and drop it here' : 'Select file(s) to upload or drag and drop it here'}
              fileRestrictionsMessage={resolvedFileRestrictionMessage}
              accept={resolvedFileAccept}
              onUpload={(files: any) => {
                if (!files || files.length === 0) return;

                const normalizedFiles = files
                  .map((item: any) => item instanceof File ? item : item.file)
                  .filter((item: File | undefined) => Boolean(item));

                if (!resolvedAllowMultipleFiles) {
                  const first = normalizedFiles[0];
                  setUploadedFiles(first ? [first] : []);
                  return;
                }

                setUploadedFiles((prev) => [...prev, ...normalizedFiles]);
              }}
              multiple={resolvedAllowMultipleFiles}
            />
            {hasUploadedFiles && (
              <Box style={{ marginTop: '16px' }}>
                <FileUploadList
                  fileList={uploadedFiles}
                  columns={[
                    'File Name',
                    'Size',
                    <ScreenReaderOnly key="actions">Actions</ScreenReaderOnly>
                  ]}
                  FileItem={(props: any) => {
                    const file = props.file as File;
                    return (
                      <tr>
                        <td>
                          <Stack direction="row" gap="xs" align="center">
                            <Text>{file.name}</Text>
                            <CheckmarkSolid style={{ color: '#008a00' }} />
                          </Stack>
                        </td>
                        <td>
                          <Text>{formatFileSize(file.size)}</Text>
                        </td>
                        <td>
                          <Button
                            icon={<TrashOutline />}
                            variant="link"
                            onClick={() => {
                              setUploadedFiles((prev) => prev.filter((f) => f !== file));
                            }}
                          />
                        </td>
                      </tr>
                    );
                  }}
                />
              </Box>
            )}
          </Stack>
        </Box>
      </DraggableDialog>
    );
  }

  return (
    <DraggableDialog
      title={title || 'Upload'}
      onClose={resetStateAndClose}
      style={{ minWidth: useSingleModal ? (isUrls ? '720px' : '600px') : '813px', width: 'min(92vw, 920px)' }}
      actions={
        <div style={{ display: 'flex', gap: '16px', justifyContent: 'flex-end', width: '100%', marginTop: '20px' }}>
          <OutlineButton key="cancel" onClick={resetStateAndClose} variant="primary">Cancel</OutlineButton>
          <Button
            key="upload"
            onClick={handleUploadClick}
            variant="primary"
            disabled={isUrls ? !hasInsertedUrls && !hasUploadedFiles : !hasUploadedFiles}
          >
            {uploadButtonText}
          </Button>
        </div>
      }
    >
      <div className="add-recipient-modal-content">
        <Stack direction="row" className={`add-recipient-top-row ${isUrls ? 'url-mode' : ''}`}>
          <Box className={`add-recipient-file-section ${isUrls ? 'url-mode' : ''}`}>
            <Stack gap="base">
              <Stack direction="row" gap="sm" align="center">
                <DocumentOutline />
                <Text style={{ fontWeight: 'bold' }}>Files</Text>
              </Stack>

              <div style={{ marginTop: '4px', border: '1px dashed #ccc', padding: isUrls ? '9px' : '16px', borderRadius: '4px' }}>
                <Stack direction="column" gap="xs">
                  <Text style={{ fontWeight: 'bold' }}>{`Upload file (${resolvedFileLabel})`}</Text>
                  <Text variant="secondary">{hasUploadedFiles ? `${uploadedFiles.length} file(s) chosen` : 'No file chosen'}</Text>
                  <Text variant="secondary" size="xs">{resolvedFileRestrictionMessage.replace('Up to 200MB per file. ', '200MB per file • ').replace(' only.', '')}</Text>
                  {useSingleModal ? (
                    <div style={{ marginTop: '12px' }}>
                      <FileUpload
                        className="add-recipient-file-upload"
                        icon="upload"
                        inputTitle={isUrls ? 'Select file to upload or drag and drop it here' : 'Select file(s) to upload or drag and drop it here'}
                        fileRestrictionsMessage={resolvedFileRestrictionMessage}
                        accept={resolvedFileAccept}
                        disabled={isUrls && hasInsertedUrls}
                        onUpload={(files: any) => {
                          if (!files || files.length === 0) return;

                          const normalizedFiles = files
                            .map((item: any) => item instanceof File ? item : item.file)
                            .filter((item: File | undefined) => Boolean(item));

                          if (!resolvedAllowMultipleFiles) {
                            const first = normalizedFiles[0];
                            setUploadedFiles(first ? [first] : []);
                            return;
                          }

                          setUploadedFiles((prev) => [...prev, ...normalizedFiles]);
                        }}
                        multiple={resolvedAllowMultipleFiles}
                      />
                    </div>
                  ) : (
                    <div style={{ marginTop: '12px' }}>
                      <Button
                        onClick={() => setIsFileUploadModalOpen(true)}
                        disabled={isUrls && hasInsertedUrls}
                      >
                        Upload
                      </Button>
                    </div>
                  )}
                </Stack>
              </div>
            </Stack>
          </Box>

          {isUrls && (
            <div className="add-recipient-or-divider">
              <Text style={{ fontWeight: 600, color: '#6b7280' }}>or</Text>
            </div>
          )}

          {isUrls && (
            <Box className="add-recipient-url-section">
              <Stack gap="base" style={{ width: '100%' }}>
                <Text style={{ fontWeight: 600 }}>Address (URL):</Text>
                <div className="add-recipient-url-row">
                  <div className="add-recipient-url-input-wrap">
                    <TextInput
                      style={{ width: '100%' }}
                      placeholder="Enter http:// or https:// URL"
                      value={urlInputValue}
                      disabled={isUrls && hasUploadedFiles}
                      onKeyDown={(e: any) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          if (trimmedUrlInput && isValidHttpUrl(trimmedUrlInput) && !(isUrls && hasUploadedFiles)) {
                            handleInsertLink();
                          }
                        }
                      }}
                      onChange={(e: any) => {
                        setUrlInputValue(e.target.value);
                        if (urlValidationError) {
                          setUrlValidationError('');
                        }
                      }}
                    />
                  </div>
                  <div className="add-recipient-url-button-wrap">
                    <OutlineButton
                      onClick={handleInsertLink}
                      disabled={!trimmedUrlInput || !isValidHttpUrl(trimmedUrlInput) || (isUrls && hasUploadedFiles)}
                      style={{ minWidth: '120px' }}
                    >
                      Insert link
                    </OutlineButton>
                  </div>
                </div>
                {urlValidationError && (
                  <Text style={{ color: '#c51f1f', fontSize: '12px' }}>{urlValidationError}</Text>
                )}
              </Stack>
            </Box>
          )}
        </Stack>
        <Stack direction="row" style={{ gap: isUrls ? '24px' : '0' }}>
          {hasUploadedFiles && (
            <Box style={{ marginTop: '16px', width: '100%' }}>
              <FileUploadList
                fileList={uploadedFiles}
                columns={[
                  'File Name',
                  'Size',
                  <ScreenReaderOnly>Actions</ScreenReaderOnly>
                ]}
                FileItem={(props: any) => {
                  const file = props.file as File;
                  return (
                    <tr>
                      <td>
                        <Stack direction="row" gap="xs" align="center">
                          <Text>{file.name}</Text>
                          <CheckmarkSolid style={{ color: '#008a00' }} />
                        </Stack>
                      </td>
                      <td>
                        <Text>{formatFileSize(file.size)}</Text>
                      </td>
                      <td>
                        <Button
                          icon={<TrashOutline />}
                          variant="link"
                          onClick={() => {
                            setUploadedFiles((prev) => prev.filter((f) => f !== file));
                          }}
                        />
                      </td>
                    </tr>
                  );
                }}
              />
            </Box>
          )}

          {isUrls && insertedUrls.length > 0 && (
            <Box style={{ marginTop: '16px', width: '100%' }}>
              <Stack gap="sm">
                {insertedUrls.map((url) => (
                  <Stack key={url} direction="row" align="center" justifyContent="space-between" style={{ border: '1px solid #e1e1e1', borderRadius: '6px', padding: '8px 10px' }}>
                    <Text>{url}</Text>
                    <Button
                      icon={<TrashOutline />}
                      variant="link"
                      onClick={() => setInsertedUrls(prev => prev.filter(item => item !== url))}
                    />
                  </Stack>
                ))}
              </Stack>
            </Box>
          )}
        </Stack>
      </div>

      {!useSingleModal && isFileUploadModalOpen && (
        <DraggableDialog
          title="Upload Document"
          onClose={() => setIsFileUploadModalOpen(false)}
          style={{ minWidth: '600px' }}
          actions={
            <div style={{ display: 'flex', gap: '16px', justifyContent: 'flex-end', width: '100%' }}>
              <OutlineButton onClick={() => setIsFileUploadModalOpen(false)} variant="primary">Cancel</OutlineButton>
              <Button
                onClick={() => setIsFileUploadModalOpen(false)}
                disabled={!hasUploadedFiles}
                variant="primary"
              >
                Upload
              </Button>
            </div>
          }
        >
          <Box>
            <Stack gap="base">
              <FileUpload
                className="add-recipient-file-upload"
                icon="upload"
                inputTitle={isUrls ? 'Select file to upload or drag and drop it here' : 'Select file(s) to upload or drag and drop it here'}
                fileRestrictionsMessage={resolvedFileRestrictionMessage}
                accept={resolvedFileAccept}
                onUpload={(files: any) => {
                  if (!files || files.length === 0) return;

                  const normalizedFiles = files
                    .map((item: any) => item instanceof File ? item : item.file)
                    .filter((item: File | undefined) => Boolean(item));

                  if (!resolvedAllowMultipleFiles) {
                    const first = normalizedFiles[0];
                    setUploadedFiles(first ? [first] : []);
                    return;
                  }

                  setUploadedFiles((prev) => [...prev, ...normalizedFiles]);
                }}
                multiple={resolvedAllowMultipleFiles}
              />
              {hasUploadedFiles && (
                <Box style={{ marginTop: '16px' }}>
                  <FileUploadList
                    fileList={uploadedFiles}
                    columns={[
                      'File Name',
                      'Size',
                      <ScreenReaderOnly key="actions">Actions</ScreenReaderOnly>
                    ]}
                    FileItem={(props: any) => {
                      const file = props.file as File;
                      return (
                        <tr>
                          <td>
                            <Stack direction="row" gap="xs" align="center">
                              <Text>{file.name}</Text>
                              <CheckmarkSolid style={{ color: '#008a00' }} />
                            </Stack>
                          </td>
                          <td>
                            <Text>{formatFileSize(file.size)}</Text>
                          </td>
                          <td>
                            <Button
                              icon={<TrashOutline />}
                              variant="link"
                              onClick={() => {
                                setUploadedFiles((prev) => prev.filter((f) => f !== file));
                              }}
                            />
                          </td>
                        </tr>
                      );
                    }}
                  />
                </Box>
              )}
            </Stack>
          </Box>
        </DraggableDialog>
      )}
    </DraggableDialog>
  );
};
