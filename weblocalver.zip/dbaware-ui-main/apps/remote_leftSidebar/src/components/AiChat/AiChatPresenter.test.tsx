import React from 'react';
import { render, screen, fireEvent, cleanup, waitFor, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { BrowserRouter } from 'react-router-dom';
import { AiChatPresenter } from './AiChatPresenter';
import * as prelimClient from '../../api/preliminaryResearchClient';

let mockState: any = {
    scoping: {
        taskDefinitionKeyByPlan: {},
        nextAvailableActionsByPlan: {},
    },
};

vi.mock('react-redux', async () => {
    const actual = await vi.importActual<typeof import('react-redux')>('react-redux');
    return {
        ...actual,
        useSelector: (selector: any) => selector(mockState),
    };
});

// 1. Mock the internal WADK and AFCC components to isolate our presenter logic
vi.mock('@wadk/icons', () => ({
    AiLogoSolid: () => <svg data-testid="icon-ai-logo" />,
    CrosshairOutline: () => <svg data-testid="icon-screenshot" />,
    AttachSolid: () => <svg data-testid="icon-attach" />,
    PaperPlaneOutline: () => <svg data-testid="icon-paper-plane" />,
    CheckmarkCircleOutline: () => <svg data-testid="icon-checkmark-circle" />,
    SingleChevronDownSolid: () => <svg data-testid="icon-chevron-down" />,
    SingleChevronUpSolid: () => <svg data-testid="icon-chevron-up" />,
    CheckmarkSolid: () => <svg data-testid="icon-checkmark" />,
    DocumentOutline: () => <svg data-testid="icon-doc-outline" />,
    ContextHelpOutline: () => <svg data-testid="icon-context-help" />,
    TrashOutline: () => <svg data-testid="icon-trash-outline" />,
}));

vi.mock('com.db.rca.commons.afcc-components', () => ({
    AiInputPanelContent: ({ children, actions }: any) => (
        <div data-testid="mock-input-panel">
            <div data-testid="mock-actions">{actions}</div>
            {children}
        </div>
    ),
    AiInputPanelTextarea: ({ value, onChange, onKeyDown, placeholder }: any) => (
        <textarea
            data-testid="mock-textarea"
            value={value}
            onChange={onChange}
            onKeyDown={onKeyDown}
            placeholder={placeholder}
        />
    ),
    AiQuestion: ({ children }: any) => <div data-testid="mock-ai-question">{children}</div>,
    AiResponse: ({ children }: any) => <div data-testid="mock-ai-response">{children ?? 'Generating response...'}</div>,
    AiQuestions: ({ children, header }: any) => (
        <div data-testid="mock-ai-questions">
            {header}
            {children}
        </div>
    ),
    AiQuestionsPrompt: ({ children, onClick, disabled }: any) => (
        <button type="button" onClick={onClick} data-disabled={disabled ? 'true' : 'false'}>{children}</button>
    ),
    AutoLoadingProgress: () => <div data-testid="mock-auto-loading-progress" />,
    DraggableDialog: ({ children, actions }: any) => (
        <div data-testid="mock-draggable-dialog">
            {children}
            {actions}
        </div>
    ),
    FileUploadList: () => <div data-testid="mock-file-upload-list" />,
    ScreenReaderOnly: ({ children }: any) => <span>{children}</span>,
}));

vi.mock('@wadk/ui', () => ({
    Button: ({ children, onClick, disabled, icon }: any) => (
        <button type="button" onClick={onClick} disabled={disabled}>{icon}{children}</button>
    ),
    OutlineButton: ({ children, onClick, disabled, icon }: any) => (
        <button type="button" onClick={onClick} disabled={disabled}>{icon}{children}</button>
    ),
    TextInput: ({ value, onChange, placeholder, className }: any) => (
        <input value={value} onChange={onChange} placeholder={placeholder} className={className} />
    ),
    Card: ({ children }: any) => <div data-testid="mock-card">{children}</div>,
    CardHeader: ({ children }: any) => <div data-testid="mock-card-header">{children}</div>,
    CardTitle: ({ content }: any) => <h1>{content}</h1>,
    LeftSlot: ({ children }: any) => <div>{children}</div>,
    Stack: ({ children }: any) => <div>{children}</div>,
    Box: ({ children }: any) => <div>{children}</div>,
    Text: ({ children }: any) => <span>{children}</span>,
    FileUpload: ({ children }: any) => <div data-testid="mock-file-upload">{children}</div>,
    StatusLabel: ({ children }: any) => <span>{children}</span>,
}));

vi.mock('../CurrentPlan/CurrentPlan', () => ({
    CurrentPlan: () => <div data-testid="mock-current-plan" />,
}));

vi.mock('./SequentialFadeList', () => ({
    SequentialFadeList: () => <div data-testid="mock-sequential-fade-list" />,
}));

describe('AiChatPresenter', () => {
    const mockOnInputChange = vi.fn();
    const mockOnSend = vi.fn();

    const defaultProps = {
        messages: [],
        inputValue: '',
        isGenerating: false,
        isInputDisabled: false,
        recommendedActions: [
            { id: '1', label: 'Generate Preliminary Research' },
            { id: '2', label: 'Review objective' }
        ],
        onInputChange: mockOnInputChange,
        onSend: mockOnSend,
    };

    beforeEach(() => {
        vi.clearAllMocks();
        mockState = {
            scoping: {
                taskDefinitionKeyByPlan: {},
                nextAvailableActionsByPlan: {},
            },
        };
    });

    afterEach(() => {
        cleanup();
    });

    it('renders recommended actions when the message list is empty', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} />
            </BrowserRouter>
        );

        expect(screen.getByText('Recommended Actions')).toBeDefined();
        expect(screen.getByText('Generate NOIR')).toBeDefined();
    });

    it('calls onSend with the action label when a recommended action is clicked', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} />
            </BrowserRouter>
        );

        const actionBtn = screen.getByText('Generate NOIR');
        fireEvent.click(actionBtn);

        expect(mockOnSend).toHaveBeenCalledTimes(1);
        expect(mockOnSend).toHaveBeenCalledWith('Generate NOIR');
    });

    it('hides recommended actions and renders chat bubbles when messages exist', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    messages={[{ id: 'msg-1', content: 'Hello AI', sender: 'user', timestamp: new Date().toISOString() }]}
                />
            </BrowserRouter>
        );

        expect(screen.queryByText('Recommended Actions')).toBeNull();
        expect(screen.getByText('Hello AI')).toBeDefined();
    });

    it('calls onInputChange when the user types in the textarea', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} />
            </BrowserRouter>
        );

        const textarea = screen.getByTestId('mock-textarea');
        fireEvent.change(textarea, { target: { value: 'New prompt' } });

        expect(mockOnInputChange).toHaveBeenCalledTimes(1);
    });

    it('calls onSend when the Enter key is pressed without the Shift key', () => {
        // Pass a valid input value so the send action isn't conceptually "disabled" by our tests
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} inputValue="Hello" />
            </BrowserRouter>
        );

        const textarea = screen.getByTestId('mock-textarea');

        // Pressing shift+enter shouldn't trigger send (usually creates a newline)
        fireEvent.keyDown(textarea, { key: 'Enter', shiftKey: true });
        expect(mockOnSend).not.toHaveBeenCalled();

        // Pressing enter alone should trigger send
        fireEvent.keyDown(textarea, { key: 'Enter', shiftKey: false });
        expect(mockOnSend).toHaveBeenCalledTimes(1);
        expect(mockOnSend).toHaveBeenCalledWith(); // Called with no args
    });

    it('shows a loading indicator when isGenerating is true', () => {
        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} isGenerating={true} messages={[]} />
            </BrowserRouter>
        );

        expect(screen.getByText('Generating response...')).toBeDefined();
    });

    it('renders 5 source categories, section checkboxes, include/exclude toggle, and partial regeneration', async () => {
        mockState = {
            scoping: {
                taskDefinitionKeyByPlan: { '20440': 'PRELIMINARY_RESEARCH' },
                nextAvailableActionsByPlan: {
                    '20440': ['RUN_ANALYTICS', 'QNA_CHAT'],
                },
            },
        };

        const fetchSpy = vi.spyOn(prelimClient, 'fetchPreliminaryResearchSourceDocuments').mockResolvedValue({
            documentsByType: {
                Policies: [{ id: 'p1', title: 'Policy One', type: 'Policies', excluded: false, sections: [] }],
                KOD: [{ id: 'k1', title: 'KOD One', type: 'KOD', excluded: false, sections: [] }],
                'Procedure Documents': [{ id: 'pr1', title: 'Proc One', type: 'Procedure Documents', excluded: false, sections: [] }],
                'GFMS Data': [
                    {
                        id: 'gfms-1',
                        title: 'GFMS Findings',
                        type: 'GFMS Data',
                        excluded: false,
                        sections: [
                            { section_id: 'F-10', section_title: 'Access Finding', excluded: false },
                            { section_id: 'F-11', section_title: 'Old Excluded Finding', excluded: true },
                        ],
                    },
                ],
                'Historical Scoping Documents': [
                    { id: 'h1', title: 'Historical Plan 20400', type: 'Historical Scoping Documents', excluded: true, sections: [] },
                ],
                LRR: [
                    { id: 'lrr1', title: 'BaFin Mandate', type: 'LRR', excluded: false, sections: [] },
                ],
            },
        });

        const regenSpy = vi.spyOn(prelimClient, 'regeneratePreliminaryResearchWithExclusions').mockResolvedValue({
            deletedCount: 1,
            generated: true,
            affectedSections: ['broad_scope'],
        });

        const genEvents: any[] = [];
        const genHandler = (e: Event) => genEvents.push((e as CustomEvent).detail);
        window.addEventListener('ai-chat:generate-preliminary-research', genHandler);

        render(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    messages={[]}
                />
            </BrowserRouter>
        );

        // Switch to Edit Content via AiChatModeMenu, then complete PR generation so Exclude Source Documents unlocks
        fireEvent.click(screen.getByText('Chat Only'));
        fireEvent.click(screen.getByText('Edit Content'));

        act(() => {
            window.dispatchEvent(new CustomEvent('preliminary-research:sync', { detail: { status: 'completed' } }));
        });

        const excludeBtn = await screen.findByText('Exclude Source Documents');
        fireEvent.click(excludeBtn);

        await waitFor(() => expect(fetchSpy).toHaveBeenCalledWith('20440'));

        // All 6 categories visible
        expect(screen.getByText('Policies')).toBeDefined();
        expect(screen.getByText('KOD')).toBeDefined();
        expect(screen.getByText('Procedure Documents')).toBeDefined();
        expect(screen.getByText('GFMS Data')).toBeDefined();
        expect(screen.getByText('Historical Scoping Documents')).toBeDefined();
        expect(screen.getByText('LRR')).toBeDefined();

        // Open GFMS Data dropdown and expand section list
        fireEvent.click(screen.getByText('GFMS Data'));
        fireEvent.click(screen.getByLabelText('Toggle sections for GFMS Findings'));
        fireEvent.click(screen.getByText('Access Finding'));
        expect(screen.getByText('Total of 1 source items selected.')).toBeDefined();

        // Switch mode toggle to Restore Excluded and inspect excluded docs, then switch back
        fireEvent.click(screen.getByText('Restore Excluded'));
        fireEvent.click(screen.getByText('Historical Scoping Documents'));
        expect(screen.getByText('Historical Plan 20400')).toBeDefined();

        fireEvent.click(screen.getByText('Exclude Active'));
        fireEvent.click(screen.getByText('GFMS Data'));
        fireEvent.click(screen.getByText('Access Finding'));

        fireEvent.click(screen.getByText('Remove Documents and Regenerate PR'));

        await waitFor(() => expect(regenSpy).toHaveBeenCalledTimes(1));
        expect(genEvents.some((d) => d?.payload?.sections?.includes('broad_scope'))).toBe(true);

        // Also test ai-chat:preliminary-research-workflow-executed triggers partial regeneration
        act(() => {
            window.dispatchEvent(
                new CustomEvent('ai-chat:preliminary-research-workflow-executed', {
                    detail: { planId: '20440', affectedSections: ['past_review', 'broad_scope'] },
                })
            );
        });
        expect(genEvents.some((d) => d?.payload?.sections?.includes('past_review'))).toBe(true);

        window.removeEventListener('ai-chat:generate-preliminary-research', genHandler);
    });

    it('renders workflow approval buttons and triggers Approve & Regenerate or Cancel', () => {
        const mockOnWorkflowDecision = vi.fn();

        render(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    onWorkflowDecision={mockOnWorkflowDecision}
                    messages={[
                        {
                            id: 'wf-msg-1',
                            sender: 'ai',
                            content: 'Approve excluding Finding F-10?',
                            timestamp: new Date().toISOString(),
                            workflowState: {
                                status: 'pending_approval',
                                planId: 'plan-1',
                                requiresApproval: true,
                            },
                        },
                    ]}
                />
            </BrowserRouter>
        );

        const approveBtn = screen.getByText(/Approve & Regenerate/);
        fireEvent.click(approveBtn);

        expect(mockOnWorkflowDecision).toHaveBeenCalledWith('approve', 'wf-msg-1', 'plan-1');
    });

    it('lazy-loads documents on @ mention, filters suggestions, and inserts selection via click or keyboard', async () => {
        const fetchSpy = vi.spyOn(prelimClient, 'fetchPreliminaryResearchSourceDocuments').mockResolvedValue({
            documentsByType: {
                Policies: [
                    {
                        id: 'pol-1',
                        title: 'Access Control Policy',
                        type: 'Policies',
                        excluded: false,
                        sections: [
                            { section_id: '2.1', section_title: 'Password Rules', excluded: false },
                        ],
                    },
                ],
                KOD: [],
                'Procedure Documents': [],
                'GFMS Data': [
                    {
                        id: 'gfms-1',
                        title: 'GFMS Findings',
                        type: 'GFMS Data',
                        excluded: true,
                        sections: [
                            { section_id: 'F-10', section_title: 'Access Finding', excluded: true },
                        ],
                    },
                ],
                'Historical Scoping Documents': [],
                LRR: [],
            },
        });

        let controlledValue = 'Exclude @';
        const handleControlledChange = vi.fn((next: string) => {
            controlledValue = next;
        });

        const { rerender } = render(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    inputValue={controlledValue}
                    onInputChange={handleControlledChange}
                />
            </BrowserRouter>
        );

        await waitFor(() => expect(fetchSpy).toHaveBeenCalledWith('20440'));

        const listbox = await screen.findByRole('listbox', { name: 'Document mention suggestions' });
        expect(listbox).toBeDefined();
        expect(screen.getByText('Access Control Policy')).toBeDefined();

        // Narrow down with @2.1 and select section via Enter
        rerender(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    inputValue="Exclude @Password"
                    onInputChange={handleControlledChange}
                />
            </BrowserRouter>
        );

        expect(screen.getByText('Password Rules')).toBeDefined();
        const textarea = screen.getByTestId('mock-textarea');
        fireEvent.keyDown(textarea, { key: 'Enter', shiftKey: false });

        expect(mockOnSend).not.toHaveBeenCalled();
        expect(handleControlledChange).toHaveBeenCalledWith(
            'Exclude @[Policies: Access Control Policy > Section 2.1: Password Rules] '
        );

        // Once annotation is inserted into inputValue, popover stays closed
        rerender(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    inputValue={controlledValue}
                    onInputChange={handleControlledChange}
                />
            </BrowserRouter>
        );
        expect(screen.queryByRole('listbox', { name: 'Document mention suggestions' })).toBeNull();

        // Click selection on @GFMS F-10 also shows Excluded badge and inserts cleanly
        rerender(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    inputValue="Include @F-10"
                    onInputChange={handleControlledChange}
                />
            </BrowserRouter>
        );
        expect(screen.getByText('Excluded')).toBeDefined();
        fireEvent.click(screen.getByText('Access Finding'));
        expect(handleControlledChange).toHaveBeenCalledWith(
            'Include @[GFMS Data: GFMS Findings > Section F-10: Access Finding] '
        );

        // ArrowDown / ArrowUp highlight navigation and Escape dismisses the popover
        rerender(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    inputValue="Exclude @Policy"
                    onInputChange={handleControlledChange}
                />
            </BrowserRouter>
        );
        const optionsBefore = screen.getAllByRole('option');
        expect(optionsBefore[0].getAttribute('aria-selected')).toBe('true');

        fireEvent.keyDown(textarea, { key: 'ArrowDown' });
        expect(screen.getAllByRole('option')[1].getAttribute('aria-selected')).toBe('true');

        fireEvent.keyDown(textarea, { key: 'ArrowUp' });
        expect(screen.getAllByRole('option')[0].getAttribute('aria-selected')).toBe('true');

        fireEvent.keyDown(textarea, { key: 'Escape' });
        expect(screen.queryByRole('listbox', { name: 'Document mention suggestions' })).toBeNull();
    });

    it('renders the shared error details modal with item failures and raw diagnostics', async () => {
        render(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    messages={[]}
                />
            </BrowserRouter>
        );

        expect(screen.queryByRole('dialog')).toBeNull();

        act(() => {
            window.dispatchEvent(
                new CustomEvent('ai-chat:show-error-modal', {
                    detail: {
                        title: 'Document Workflow Error',
                        operation: 'QNA_CHAT',
                        endpoint: '/dbaware-api-gateway/api/v1/actions',
                        status: 502,
                        statusText: 'Bad Gateway',
                        message: 'password authentication failed',
                        errorDetails: [{ title: 'Policy One', error: 'password authentication failed' }],
                        raw: { stage: 'error', registration_step: 'execute' },
                    },
                })
            );
        });

        const dialog = await screen.findByRole('dialog');
        expect(dialog).toBeDefined();
        expect(screen.getByText('Document Workflow Error')).toBeDefined();
        expect(screen.getByText('HTTP 502 Bad Gateway')).toBeDefined();
        expect(screen.getAllByText(/password authentication failed/).length).toBeGreaterThan(0);
        expect(screen.getByText('Item Failures')).toBeDefined();
        expect(screen.getByText('Raw Details')).toBeDefined();
        expect(screen.getByText(/registration_step/)).toBeDefined();

        fireEvent.click(screen.getByLabelText('Close error details'));
        expect(screen.queryByRole('dialog')).toBeNull();
    });

    it('uploads source documents from the upload strip and regenerates preliminary research', async () => {
        mockState = {
            scoping: {
                taskDefinitionKeyByPlan: { '20440': 'PRELIMINARY_RESEARCH' },
                nextAvailableActionsByPlan: { '20440': ['RUN_ANALYTICS', 'QNA_CHAT'] },
            },
        };

        const ingestSpy = vi.spyOn(prelimClient, 'ingestPreliminaryResearchDocument').mockResolvedValue({
            status: 'success',
            jobId: 'job-9',
            documentIds: [301, 302],
            persistedFiles: ['New_Policy.pdf'],
            registryUpdated: true,
            affectedSections: ['policy_regulation', 'broad_scope'],
            message: 'Uploaded and persisted.',
        });

        const genEvents: any[] = [];
        const genHandler = (e: Event) => genEvents.push((e as CustomEvent).detail);
        window.addEventListener('ai-chat:generate-preliminary-research', genHandler);

        render(
            <BrowserRouter>
                <AiChatPresenter {...defaultProps} currentTab="preliminary-research" planNumber="20440" messages={[]} />
            </BrowserRouter>
        );

        fireEvent.click(screen.getByText('Chat Only'));
        fireEvent.click(screen.getByText('Edit Content'));
        act(() => {
            window.dispatchEvent(new CustomEvent('preliminary-research:sync', { detail: { status: 'completed' } }));
        });

        fireEvent.click(await screen.findByText('Upload Source Document'));

        const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
        expect(fileInput).toBeTruthy();
        const file = new File(['%PDF-1.4'], 'New_Policy.pdf', { type: 'application/pdf' });
        fireEvent.change(fileInput, { target: { files: [file] } });

        fireEvent.click(screen.getByText('Upload & Regenerate PR'));

        await waitFor(() => expect(ingestSpy).toHaveBeenCalledWith('20440', [file], 'auto'));
        await waitFor(() =>
            expect(genEvents.some((detail) => detail?.payload?.sections?.includes('policy_regulation'))).toBe(true)
        );
        await waitFor(() => expect(screen.queryByText('Upload & Regenerate PR')).toBeNull());

        window.removeEventListener('ai-chat:generate-preliminary-research', genHandler);
    });

    it('refreshes the @ mention catalog after a workflow execution event', async () => {
        mockState = {
            scoping: {
                taskDefinitionKeyByPlan: { '20440': 'PRELIMINARY_RESEARCH' },
                nextAvailableActionsByPlan: { '20440': ['RUN_ANALYTICS', 'QNA_CHAT'] },
            },
        };

        let includeNewDoc = false;
        const fetchSpy = vi
            .spyOn(prelimClient, 'fetchPreliminaryResearchSourceDocuments')
            .mockImplementation(async () => ({
                documentsByType: {
                    Policies: [{ id: 'p1', title: 'Original Policy', type: 'Policies', excluded: false, sections: [] }],
                    KOD: [],
                    'Procedure Documents': [],
                    'GFMS Data': [],
                    'Historical Scoping Documents': [],
                    LRR: includeNewDoc
                        ? [{ id: 'lrr-new', title: 'Workflow Added Mandate', type: 'LRR', excluded: false, sections: [] }]
                        : [],
                },
            }));

        render(
            <BrowserRouter>
                <AiChatPresenter
                    {...defaultProps}
                    currentTab="preliminary-research"
                    planNumber="20440"
                    inputValue="Exclude @"
                />
            </BrowserRouter>
        );

        await waitFor(() => expect(fetchSpy).toHaveBeenCalledWith('20440'));
        expect(await screen.findByText('Original Policy')).toBeDefined();
        expect(screen.queryByText('Workflow Added Mandate')).toBeNull();

        includeNewDoc = true;
        act(() => {
            window.dispatchEvent(
                new CustomEvent('ai-chat:preliminary-research-workflow-executed', {
                    detail: { planId: '20440', affectedSections: ['broad_scope'] },
                })
            );
        });

        expect(await screen.findByText('Workflow Added Mandate')).toBeDefined();
    });
});