import React, { useEffect, useState } from 'react';
import { useLocation, matchPath } from 'react-router-dom';
import { KeyValuePair, KeyValuePairItem } from 'com.db.rca.commons.afcc-components';
import styles from './CurrentPlan.module.css';
import { getPlanArtifact } from '../../api/dataGatheringClient';

interface CurrentDetailsPayload {
  plan_details?: {
    'Plan Item Type'?: string;
    'Plan Item Title'?: string;
  };
}

export const CurrentPlan: React.FC = () => {
  const location = useLocation();
  const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
  const docsMatch = matchPath({ path: '/:planId/docs/*', end: false }, location.pathname);
  const planId = docsMatch?.params?.planId || dashboardMatch?.params?.planId || 'Unknown';
  const [planNumber, setPlanNumber] = useState(planId);
  const [planItemType, setPlanItemType] = useState('Review');
  const [planItemTitle, setPlanItemTitle] = useState('Review');
  const [showPlanDetails, setShowPlanDetails] = useState(false);

  useEffect(() => {
    let mounted = true;

    const loadCurrentDetails = async () => {
      const normalizedPlanId = (planId || '').trim();

      if (!normalizedPlanId || normalizedPlanId === 'Unknown' || !/^\d+$/.test(normalizedPlanId)) {
        if (!mounted) return;
        setPlanNumber(normalizedPlanId || 'Unknown');
        setPlanItemType('Review');
        setPlanItemTitle('Review');
        setShowPlanDetails(false);
        return;
      }

      try {
        const response = await getPlanArtifact<CurrentDetailsPayload>(normalizedPlanId, 'current_details');
        if (!mounted) return;

        setPlanNumber(response.plan_number || normalizedPlanId);
        setPlanItemType(response.data?.plan_details?.['Plan Item Type'] || 'Review');
        setPlanItemTitle(response.data?.plan_details?.['Plan Item Title'] || 'Review');
        setShowPlanDetails(true);
      } catch {
        if (!mounted) return;
        setPlanNumber(normalizedPlanId);
        setPlanItemType('Review');
        setPlanItemTitle('Review');
        setShowPlanDetails(false);
      }
    };

    void loadCurrentDetails();

    return () => {
      mounted = false;
    };
  }, [planId]);

  return (
    <div className={styles.container}>
      <div className={styles.header}>Current Plan</div>
      <div className={styles.headerSeparator} />
      <div className={styles.content}>
        <KeyValuePair alignment="stacked" wrap>
          <KeyValuePairItem term="Plan Number">{planNumber}</KeyValuePairItem>
          {showPlanDetails && <KeyValuePairItem term="Plan Item Type">{planItemType}</KeyValuePairItem>}
          {showPlanDetails && <KeyValuePairItem term="Plan Item Title">{planItemTitle}</KeyValuePairItem>}
        </KeyValuePair>
      </div>
    </div>
  );
};

export default CurrentPlan;
