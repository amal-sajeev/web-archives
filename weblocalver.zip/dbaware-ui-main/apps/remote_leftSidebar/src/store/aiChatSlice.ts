import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { ChatMessage } from '../types/aiChat';

interface AiChatReduxState {
  messages: ChatMessage[];
}

const initialState: AiChatReduxState = {
  messages: []
};

const aiChatSlice = createSlice({
  name: 'aiChat',
  initialState,
  reducers: {
    addMessage: (state, action: PayloadAction<ChatMessage>) => {
      state.messages.push(action.payload);
    },
    removeMessage: (state, action: PayloadAction<string>) => {
      state.messages = state.messages.filter(message => message.id !== action.payload);
    },
    clearMessages: (state) => {
      state.messages = [];
    }
  }
});

export const { addMessage, removeMessage, clearMessages } = aiChatSlice.actions;
export default aiChatSlice.reducer;
