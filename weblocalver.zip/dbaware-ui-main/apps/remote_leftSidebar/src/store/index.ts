import { configureStore } from '@reduxjs/toolkit';
import aiChatReducer from './aiChatSlice';

export const store = configureStore({
  reducer: {
    aiChat: aiChatReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false
    })
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
