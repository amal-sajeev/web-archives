import { describe, it, expect } from 'vitest';
import reducer, { addMessage, removeMessage, clearMessages } from './aiChatSlice';

describe('aiChatSlice', () => {
  it('adds, removes, and clears chat messages', () => {
    const initial = reducer(undefined, { type: 'unknown' });
    expect(initial.messages).toEqual([]);

    const withOne = reducer(
      initial,
      addMessage({ id: 'm1', sender: 'user', content: 'hi', timestamp: '2026-01-01T00:00:00Z' })
    );
    expect(withOne.messages).toHaveLength(1);

    const removed = reducer(withOne, removeMessage('m1'));
    expect(removed.messages).toHaveLength(0);

    const withTwo = reducer(
      withOne,
      addMessage({ id: 'm2', sender: 'ai', content: 'hello', timestamp: '2026-01-01T00:00:01Z' })
    );
    const cleared = reducer(withTwo, clearMessages());
    expect(cleared.messages).toEqual([]);
  });
});
