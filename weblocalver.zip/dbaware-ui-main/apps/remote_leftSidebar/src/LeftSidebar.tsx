import React from 'react';
import AiChatContainer from './components/AiChat/AiChatContainer/AiChatContainer';
import './LeftSidebar.css';

const LeftSidebar: React.FC = () => {
  return (
    <div className="left-sidebar-container">
      <AiChatContainer />
    </div>
  );
};

export default LeftSidebar;
