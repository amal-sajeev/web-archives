export const LRR_UPLOAD_POLL_INTERVAL_MS = 20000;

export const REGENERATE_PRELIMINARY_RESEARCH_SECTIONS = ['policy_regulation', 'broad_scope'];

export const REGENERATE_PRELIMINARY_RESEARCH_HISTORICAL_SECTIONS = ['past_review', 'broad_scope'];

export const GENERATION_LOADING_STORAGE_KEY = 'ai-chat:generation-loading-by-plan-tab';

export const COMMON_GENERATION_LOADING_ITEMS = [
  'Reviewing regulatory obligations',
  'Analysing policies',
  'Comparing historical scope',
  'Reviewing open findings',
  'Mapping risks and controls',
  'Assessing evidence ',
  'Developing scope direction',
  'processing....',
];

export type GenerationLoadingTab =
  | 'noir'
  | 'nor'
  | 'data-gathering'
  | 'preliminary-research'
  | 'discovery-walkthrough'
  | 'scope-recommendation'
  | 'test-steps';

export const GENERATION_LOADING_CONFIG: Record<GenerationLoadingTab, {
  messageId: string;
  title: string;
  items: string[];
  intervalMs: number;
}> = {
  noir: {
    messageId: 'noir-loading',
    title: 'Generating NOIR...',
    items: COMMON_GENERATION_LOADING_ITEMS,
    intervalMs: 40000,
  },
  nor: {
    messageId: 'nor-loading',
    title: 'Generating NOR...',
    items: COMMON_GENERATION_LOADING_ITEMS,
    intervalMs: 40000,
  },
  'data-gathering': {
    messageId: 'data-gathering-loading',
    title: 'Generating Data Gathering...',
    items: [
      'Reviewing regulatory obligations',
      'Analysing policies',
      'Comparing historical scope',
      'Reviewing open findings',
      'Mapping risks and controls',
      'Assessing evidence',
      'Developing scope direction',
      'Processing results...'
    ],
    intervalMs: 60000,
  },
  'preliminary-research': {
    messageId: 'prelim-research-loading',
    title: 'Generating Preliminary Research...',
    items: COMMON_GENERATION_LOADING_ITEMS,
    intervalMs: 40000,
  },
  'discovery-walkthrough': {
    messageId: 'discovery-walkthrough-loading',
    title: 'Generating Discovery Walkthrough...',
    items: COMMON_GENERATION_LOADING_ITEMS,
    intervalMs: 40000,
  },
  'scope-recommendation': {
    messageId: 'scope-recommendation-loading',
    title: 'Generating Scope Recommendation...',
    items: COMMON_GENERATION_LOADING_ITEMS,
    intervalMs: 40000,
  },
  'test-steps': {
    messageId: 'test-steps-loading',
    title: 'Generating Test Steps...',
    items: COMMON_GENERATION_LOADING_ITEMS,
    intervalMs: 40000,
  },
};

export const GENERATION_LOADING_MESSAGE_TO_TAB: Record<string, GenerationLoadingTab> = {
  'noir-loading': 'noir',
  'nor-loading': 'nor',
  'data-gathering-loading': 'data-gathering',
  'prelim-research-loading': 'preliminary-research',
  'discovery-walkthrough-loading': 'discovery-walkthrough',
  'scope-recommendation-loading': 'scope-recommendation',
  'test-steps-loading': 'test-steps',
};