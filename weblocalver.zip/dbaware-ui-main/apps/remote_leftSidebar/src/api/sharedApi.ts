/**
 * Bridge to the globally-registered API client exposed by remote_dashboard
 * (see `apps/remote_dashboard/src/api/apiClient.ts`).
 *
 * We deliberately avoid a static cross-remote import so this remote can be
 * loaded independently. If the shared client is not yet registered on
 * `window.__dbaware`, we fall back to a plain `fetch` call.
 */

export interface ApiErrorItemDetail {
    title?: string;
    document_type?: string;
    error?: string;
    reason?: string;
    detail?: unknown;
    db_result?: Record<string, unknown>;
    [key: string]: unknown;
}

export interface ApiErrorDetails {
    title?: string;
    operation?: string;
    endpoint?: string;
    status?: number;
    statusText?: string;
    message: string;
    detail?: unknown;
    errorDetails?: ApiErrorItemDetail[];
    raw?: unknown;
}

export class ApiRequestError extends Error {
    readonly details: ApiErrorDetails;

    constructor(message: string, details: ApiErrorDetails) {
        super(message);
        this.name = 'ApiRequestError';
        this.details = details;
    }
}

const parseFetchErrorResponse = async (
    res: Response,
    fullUrl: string,
    operation: string
): Promise<ApiRequestError> => {
    const baseMsg = `POST ${fullUrl} failed: ${res.status} ${res.statusText}`;
    let rawText = '';
    let parsed: any = undefined;
    try {
        if (typeof (res as any).text === 'function') {
            rawText = await res.text();
            if (rawText) {
                try {
                    parsed = JSON.parse(rawText);
                } catch {
                    parsed = rawText;
                }
            }
        }
    } catch {
        // Ignore body read error and fall back to status text
    }

    const detailValue = parsed && typeof parsed === 'object' ? (parsed.detail ?? parsed.error ?? parsed.message) : undefined;
    const detailText =
        typeof detailValue === 'string'
            ? detailValue
            : detailValue && typeof detailValue === 'object'
              ? String((detailValue as any).message || (detailValue as any).error || JSON.stringify(detailValue))
              : typeof parsed === 'string' && parsed
                ? parsed
                : '';

    const fullMsg = detailText ? `${baseMsg} - ${detailText}` : baseMsg;
    const errorDetailsArr: ApiErrorItemDetail[] | undefined =
        parsed && typeof parsed === 'object' && Array.isArray(parsed.error_details)
            ? parsed.error_details
            : parsed?.detail && typeof parsed.detail === 'object' && Array.isArray(parsed.detail.error_details)
              ? parsed.detail.error_details
              : undefined;

    return new ApiRequestError(fullMsg, {
        operation,
        endpoint: fullUrl,
        status: res.status,
        statusText: res.statusText,
        message: detailText || baseMsg,
        detail: parsed?.detail ?? parsed,
        errorDetails: errorDetailsArr,
        raw: parsed ?? (rawText || undefined),
    });
};

export const extractErrorDetails = (
    error: unknown,
    context?: { title?: string; operation?: string; endpoint?: string }
): ApiErrorDetails => {
    if (error instanceof ApiRequestError) {
        return {
            ...error.details,
            title: context?.title ?? error.details.title,
            operation: context?.operation ?? error.details.operation,
            endpoint: context?.endpoint ?? error.details.endpoint,
        };
    }

    const errAny = error as any;
    const resp = errAny?.response;
    const data = resp?.data;
    const status = typeof resp?.status === 'number' ? resp.status : typeof errAny?.status === 'number' ? errAny.status : undefined;
    const statusText = typeof resp?.statusText === 'string' ? resp.statusText : undefined;
    const endpoint = context?.endpoint || errAny?.config?.url;

    let message =
        error instanceof Error
            ? error.message
            : typeof error === 'string'
              ? error
              : 'Unexpected request error';

    if (data && typeof data === 'object') {
        const d = data.detail ?? data.error ?? data.message;
        if (typeof d === 'string' && d.trim()) {
            message = d;
        } else if (d && typeof d === 'object' && typeof d.message === 'string' && d.message.trim()) {
            message = d.message;
        }
    } else if (typeof data === 'string' && data.trim()) {
        message = data;
    }

    const errorDetailsArr: ApiErrorItemDetail[] | undefined =
        data && typeof data === 'object' && Array.isArray(data.error_details)
            ? data.error_details
            : data?.detail && typeof data.detail === 'object' && Array.isArray(data.detail.error_details)
              ? data.detail.error_details
              : Array.isArray(errAny?.errorDetails)
                ? errAny.errorDetails
                : undefined;

    return {
        title: context?.title,
        operation: context?.operation,
        endpoint,
        status,
        statusText,
        message,
        detail: data?.detail ?? errAny?.detail,
        errorDetails: errorDetailsArr,
        raw: data ?? (error instanceof Error ? { name: error.name, message: error.message } : error),
    };
};

export const SHOW_ERROR_MODAL_EVENT = 'ai-chat:show-error-modal';

export const dispatchErrorModal = (details: ApiErrorDetails): void => {
    if (typeof window === 'undefined') return;
    window.dispatchEvent(new CustomEvent<ApiErrorDetails>(SHOW_ERROR_MODAL_EVENT, { detail: details }));
};

type ApiClientLike = {
    post: <T>(url: string, data?: unknown, config?: unknown) => Promise<T>;
    get: <T>(url: string, config?: unknown) => Promise<T>;
    put: <T>(url: string, data?: unknown, config?: unknown) => Promise<T>;
    delete: <T>(url: string, config?: unknown) => Promise<T>;
};

type ApiClientFullResponseLike = {
    post: <T>(
        url: string,
        data?: unknown,
        config?: unknown
    ) => Promise<{ data: T; headers?: Record<string, string> | Headers }>;
};

declare global {
    interface Window {
        __dbaware?: {
            apiClient?: ApiClientLike;
            apiClientFullResponse?: ApiClientFullResponseLike;
            [key: string]: unknown;
        };
    }
}

export const getSharedApiClient = (): ApiClientLike | undefined => {
    if (typeof window === 'undefined') return undefined;
    return window.__dbaware?.apiClient;
};

const getSharedApiClientFullResponse = (): ApiClientFullResponseLike | undefined => {
    if (typeof window === 'undefined') return undefined;
    return window.__dbaware?.apiClientFullResponse;
};

/** Resolve the API base URL for the fetch fallback path - uses relative path */
const resolveBaseUrl = (): string => '/';

const isAbsoluteUrl = (url: string): boolean => /^https?:\/\//i.test(url);

const RC_TOKEN_GLOBAL_KEY = '__dbawareRcToken';

const getRcToken = (): string | null => {
    if (typeof window === 'undefined') return null;
    const token = (window as any)[RC_TOKEN_GLOBAL_KEY];
    return typeof token === 'string' && token.trim().length > 0 ? token : null;
};

const buildHeaders = (baseHeaders?: Record<string, string>): Record<string, string> => {
    const token = getRcToken();
    return token
        ? { ...(baseHeaders ?? {}), 'x-asm-rctoken': token }
        : { ...(baseHeaders ?? {}) };
};

const toHeaderRecord = (headers?: Record<string, string> | Headers): Record<string, string> => {
    if (!headers) return {};

    if (headers instanceof Headers) {
        const entries: Record<string, string> = {};
        headers.forEach((value, key) => {
            entries[key] = value;
        });
        return entries;
    }

    return Object.entries(headers).reduce<Record<string, string>>((acc, [key, value]) => {
        acc[key] = String(value);
        return acc;
    }, {});
};

/**
 * Convenience: POST form-data using the shared client when available,
 * otherwise fall back to native fetch.
 */
export const postFormData = async <T>(
    url: string,    fields: Record<string, string | Blob | Array<string | Blob>>
): Promise<T> => {
    const form = new FormData();
    Object.entries(fields).forEach(([k, v]) => {
        if (Array.isArray(v)) v.forEach((item) => form.append(k, item as any));
        else form.append(k, v as any);
    });

    const fullUrl = isAbsoluteUrl(url) ? url : `${resolveBaseUrl()}${url}`;

    const client = getSharedApiClient();
    if (client && !isAbsoluteUrl(url)) {
        return client.post<T>(url, form, {
            headers: buildHeaders({ 'Content-Type': 'multipart/form-data' }),
            timeout: 600000, // 10 minutes timeout
        });
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 600000); // 10 minutes timeout

    try {
        const res = await fetch(fullUrl, { 
            method: 'POST', 
            headers: buildHeaders(),
            body: form,
            signal: controller.signal
        });
        if (!res.ok) {
            throw await parseFetchErrorResponse(res, fullUrl, 'postFormData');
        }
        return (await res.json()) as T;
    } finally {
        clearTimeout(timeoutId);
    }
};

/**
 * Convenience: POST JSON using the shared client when available,
 * otherwise fall back to native fetch.
 */
export const postJson = async <T>(
    url: string,
    payload: any
): Promise<T> => {
    const response = await postJsonWithHeaders<T>(url, payload);
    return response.data;
};

export const postJsonWithHeaders = async <T>(
    url: string,
    payload: any
): Promise<{ data: T; headers: Record<string, string> }> => {
    const fullUrl = isAbsoluteUrl(url) ? url : `${resolveBaseUrl()}${url}`;

    const clientWithFullResponse = getSharedApiClientFullResponse();
    if (clientWithFullResponse && !isAbsoluteUrl(url)) {
        const response = await clientWithFullResponse.post<T>(url, payload, {
            headers: buildHeaders({ 'Content-Type': 'application/json' }),
            timeout: 600000,
        });

        return {
            data: response.data,
            headers: toHeaderRecord(response.headers),
        };
    }

    const client = getSharedApiClient();
    if (client && !isAbsoluteUrl(url)) {
        const data = await client.post<T>(url, payload, {
            headers: buildHeaders({ 'Content-Type': 'application/json' }),
            timeout: 600000, // 10 minutes timeout
        });

        return {
            data,
            headers: {},
        };
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 600000); // 10 minutes timeout

    try {
        const res = await fetch(fullUrl, { 
            method: 'POST', 
            headers: buildHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload),
            signal: controller.signal
        });
        if (!res.ok) {
            throw await parseFetchErrorResponse(res, fullUrl, 'postJson');
        }
        return {
            data: (await res.json()) as T,
            headers: toHeaderRecord(res.headers),
        };
    } finally {
        clearTimeout(timeoutId);
    }
};
