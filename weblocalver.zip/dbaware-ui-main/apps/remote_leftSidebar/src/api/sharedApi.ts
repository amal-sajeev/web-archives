/**
 * Bridge to the globally-registered API client exposed by remote_dashboard
 * (see `apps/remote_dashboard/src/api/apiClient.ts`).
 *
 * We deliberately avoid a static cross-remote import so this remote can be
 * loaded independently. If the shared client is not yet registered on
 * `window.__dbaware`, we fall back to a plain `fetch` call.
 */

type ApiClientLike = {
    post: <T>(url: string, data?: unknown, config?: unknown) => Promise<T>;
    get: <T>(url: string, config?: unknown) => Promise<T>;
    put: <T>(url: string, data?: unknown, config?: unknown) => Promise<T>;
    delete: <T>(url: string, config?: unknown) => Promise<T>;
};

type ApiClientFullResponseLike = {
    post: <T>(
        url: string,
        data?: unknown,
        config?: unknown
    ) => Promise<{ data: T; headers?: Record<string, string> | Headers }>;
};

declare global {
    interface Window {
        __dbaware?: {
            apiClient?: ApiClientLike;
            apiClientFullResponse?: ApiClientFullResponseLike;
            [key: string]: unknown;
        };
    }
}

export const getSharedApiClient = (): ApiClientLike | undefined => {
    if (typeof window === 'undefined') return undefined;
    return window.__dbaware?.apiClient;
};

const getSharedApiClientFullResponse = (): ApiClientFullResponseLike | undefined => {
    if (typeof window === 'undefined') return undefined;
    return window.__dbaware?.apiClientFullResponse;
};

/** Resolve the API base URL for the fetch fallback path - uses relative path */
const resolveBaseUrl = (): string => '/';

const isAbsoluteUrl = (url: string): boolean => /^https?:\/\//i.test(url);

const RC_TOKEN_GLOBAL_KEY = '__dbawareRcToken';

const getRcToken = (): string | null => {
    if (typeof window === 'undefined') return null;
    const token = (window as any)[RC_TOKEN_GLOBAL_KEY];
    return typeof token === 'string' && token.trim().length > 0 ? token : null;
};

const buildHeaders = (baseHeaders?: Record<string, string>): Record<string, string> => {
    const token = getRcToken();
    return token
        ? { ...(baseHeaders ?? {}), 'x-asm-rctoken': token }
        : { ...(baseHeaders ?? {}) };
};

const toHeaderRecord = (headers?: Record<string, string> | Headers): Record<string, string> => {
    if (!headers) return {};

    if (headers instanceof Headers) {
        const entries: Record<string, string> = {};
        headers.forEach((value, key) => {
            entries[key] = value;
        });
        return entries;
    }

    return Object.entries(headers).reduce<Record<string, string>>((acc, [key, value]) => {
        acc[key] = String(value);
        return acc;
    }, {});
};

/**
 * Convenience: POST form-data using the shared client when available,
 * otherwise fall back to native fetch.
 */
export const postFormData = async <T>(
    url: string,    fields: Record<string, string | Blob | Array<string | Blob>>
): Promise<T> => {
    const form = new FormData();
    Object.entries(fields).forEach(([k, v]) => {
        if (Array.isArray(v)) v.forEach((item) => form.append(k, item as any));
        else form.append(k, v as any);
    });

    const fullUrl = isAbsoluteUrl(url) ? url : `${resolveBaseUrl()}${url}`;

    const client = getSharedApiClient();
    if (client && !isAbsoluteUrl(url)) {
        return client.post<T>(url, form, {
            headers: buildHeaders({ 'Content-Type': 'multipart/form-data' }),
            timeout: 600000, // 10 minutes timeout
        });
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 600000); // 10 minutes timeout

    try {
        const res = await fetch(fullUrl, { 
            method: 'POST', 
            headers: buildHeaders(),
            body: form,
            signal: controller.signal
        });
        if (!res.ok) {
            throw new Error(`POST ${fullUrl} failed: ${res.status} ${res.statusText}`);
        }
        return (await res.json()) as T;
    } finally {
        clearTimeout(timeoutId);
    }
};

/**
 * Convenience: POST JSON using the shared client when available,
 * otherwise fall back to native fetch.
 */
export const postJson = async <T>(
    url: string,
    payload: any
): Promise<T> => {
    const response = await postJsonWithHeaders<T>(url, payload);
    return response.data;
};

export const postJsonWithHeaders = async <T>(
    url: string,
    payload: any
): Promise<{ data: T; headers: Record<string, string> }> => {
    const fullUrl = isAbsoluteUrl(url) ? url : `${resolveBaseUrl()}${url}`;

    const clientWithFullResponse = getSharedApiClientFullResponse();
    if (clientWithFullResponse && !isAbsoluteUrl(url)) {
        const response = await clientWithFullResponse.post<T>(url, payload, {
            headers: buildHeaders({ 'Content-Type': 'application/json' }),
            timeout: 600000,
        });

        return {
            data: response.data,
            headers: toHeaderRecord(response.headers),
        };
    }

    const client = getSharedApiClient();
    if (client && !isAbsoluteUrl(url)) {
        const data = await client.post<T>(url, payload, {
            headers: buildHeaders({ 'Content-Type': 'application/json' }),
            timeout: 600000, // 10 minutes timeout
        });

        return {
            data,
            headers: {},
        };
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 600000); // 10 minutes timeout

    try {
        const res = await fetch(fullUrl, { 
            method: 'POST', 
            headers: buildHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload),
            signal: controller.signal
        });
        if (!res.ok) {
            throw new Error(`POST ${fullUrl} failed: ${res.status} ${res.statusText}`);
        }
        return {
            data: (await res.json()) as T,
            headers: toHeaderRecord(res.headers),
        };
    } finally {
        clearTimeout(timeoutId);
    }
};
