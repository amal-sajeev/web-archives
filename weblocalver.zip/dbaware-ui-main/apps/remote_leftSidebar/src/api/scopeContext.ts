export interface StoredScopingContext {
  planNumber: string;
  processInstanceId?: string;
  taskId?: string;
  taskDefinitionKey?: string;
  owner?: string;
  reviewScopeId?: string;
}

export interface ApiUserDetails {
  review_scope_id?: string;
  process_instance_id?: string;
  task_id?: string;
  review_scope_stage?: string;
  user?: string;
}

const SCOPING_CONTEXT_PREFIX = 'scopingContext:';

export const getScopingContext = (
  planNumber: string | number | undefined | null
): StoredScopingContext | null => {
  if (typeof window === 'undefined' || !window.sessionStorage) return null;
  const plan = String(planNumber ?? '').trim();
  if (!plan) return null;
  try {
    const raw = window.sessionStorage.getItem(`${SCOPING_CONTEXT_PREFIX}${plan}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? (parsed as StoredScopingContext) : null;
  } catch {
    return null;
  }
};

export const buildUserDetailsForPlan = (
  planNumber: string | number | undefined | null
): ApiUserDetails | undefined => {
  const ctx = getScopingContext(planNumber);
  if (!ctx) return undefined;

  const details: ApiUserDetails = {};
  if (ctx.reviewScopeId) details.review_scope_id = ctx.reviewScopeId;
  if (ctx.processInstanceId) details.process_instance_id = ctx.processInstanceId;
  if (ctx.taskId) details.task_id = ctx.taskId;
  if (ctx.taskDefinitionKey) details.review_scope_stage = ctx.taskDefinitionKey;
  if (ctx.owner) details.user = ctx.owner;

  return Object.keys(details).length > 0 ? details : undefined;
};
