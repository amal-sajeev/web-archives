import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  ALL_PRELIMINARY_RESEARCH_DOCUMENT_TYPES,
  computeAffectedPreliminaryResearchSections,
  createEmptyPreliminaryResearchDocumentsByType,
  fetchPreliminaryResearchSourceDocuments,
  regeneratePreliminaryResearchWithExclusions,
  triggerPreliminaryResearchGeneration,
} from './preliminaryResearchClient';
import * as sharedApi from './sharedApi';

describe('preliminaryResearchClient', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('computes deduplicated affected sections in canonical order across all 5 sources', () => {
    expect(ALL_PRELIMINARY_RESEARCH_DOCUMENT_TYPES).toEqual([
      'Policies',
      'KOD',
      'Procedure Documents',
      'GFMS Data',
      'Historical Scoping Documents',
    ]);

    expect(computeAffectedPreliminaryResearchSections(['Policies', 'KOD'])).toEqual([
      'policy_regulation',
      'broad_scope',
    ]);
    expect(computeAffectedPreliminaryResearchSections(['GFMS Data'])).toEqual([
      'findings_analysis',
      'broad_scope',
    ]);
    expect(
      computeAffectedPreliminaryResearchSections(['Historical Scoping Documents', 'GFMS Data', 'Policies'])
    ).toEqual(['historical_plan', 'findings_analysis', 'policy_regulation', 'broad_scope']);
  });

  it('fetches and normalizes all 5 source categories with sections and storage URIs', async () => {
    const postSpy = vi.spyOn(sharedApi, 'postJson').mockResolvedValue({
      response: {
        data: {
          document_groups: [
            {
              document_type: 'policy',
              documents: [
                {
                  file_name: 'pol1.json',
                  document_title: 'Policy One',
                  document_id: 'pol-1',
                  storage_uri: 'gs://bucket/pol1.json',
                  status: 'active',
                  excluded: false,
                  sections: [
                    { section_id: 1, section_title: 'Intro', node_id: 'n1', status: 'active', excluded: false },
                  ],
                },
              ],
            },
            {
              document_type: 'kod',
              documents: [{ file_name: 'kod1.json', document_title: 'KOD 1', document_id: 'kod-1', excluded: true }],
            },
            {
              document_type: 'procedure',
              documents: [{ file_name: 'proc1.json', document_title: 'Proc 1', document_id: 'proc-1' }],
            },
            {
              document_type: 'gfms',
              documents: [
                {
                  file_name: 'gfms.json',
                  document_title: 'GFMS Findings',
                  document_id: 'gfms-doc',
                  sections: [
                    { section_id: 'F-10', section_title: 'Access Finding', node_id: 'gfms:finding:F-10', status: 'excluded' },
                    { section_id: 'F-11', section_title: 'Logging Finding', node_id: 'gfms:finding:F-11', status: 'active' },
                  ],
                },
              ],
            },
            {
              document_type: 'historical_scoping_document',
              documents: [
                {
                  file_name: 'hist.json',
                  document_title: 'Prior Plan',
                  document_id: 'hist-doc',
                },
              ],
            },
            {
              document_type: 'unknown_type',
              documents: [],
            },
          ],
        },
      },
    });

    const res = await fetchPreliminaryResearchSourceDocuments('20440');
    expect(postSpy).toHaveBeenCalledTimes(1);
    expect(res.documentsByType.Policies[0]).toMatchObject({
      id: 'pol-1',
      storageUri: 'gs://bucket/pol1.json',
      excluded: false,
    });
    expect(res.documentsByType.KOD[0].excluded).toBe(true);
    expect(res.documentsByType['Procedure Documents']).toHaveLength(1);
    expect(res.documentsByType['GFMS Data'][0].sections).toHaveLength(2);
    expect(res.documentsByType['GFMS Data'][0].sections?.[0].excluded).toBe(true);
    expect(res.documentsByType['Historical Scoping Documents'][0].id).toBe('hist-doc');
  });

  it('supports whole-doc, single-section, and multi-section exclude and include regeneration', async () => {
    vi.spyOn(sharedApi, 'postJson')
      .mockResolvedValueOnce({
        document_groups: [
          {
            document_type: 'gfms',
            documents: [
              {
                file_name: 'gfms.json',
                document_title: 'GFMS',
                document_id: 'gfms-1',
                sections: [
                  { section_id: 'F-1', section_title: 'Finding 1', node_id: 'gfms:finding:F-1', excluded: false },
                  { section_id: 'F-2', section_title: 'Finding 2', node_id: 'gfms:finding:F-2', excluded: false },
                ],
              },
            ],
          },
          {
            document_type: 'historical_scoping_document',
            documents: [{ file_name: 'hist.json', document_title: 'Hist', document_id: 'hist-1', excluded: true }],
          },
        ],
      })
      .mockResolvedValueOnce({
        results: [{ total_deleted: 2, affected_sections: ['findings_analysis', 'broad_scope'] }],
      })
      .mockResolvedValueOnce({
        total_deleted: 1,
      });

    await fetchPreliminaryResearchSourceDocuments('20440');

    // Exclude two sections of GFMS (multi-section -> `sections` array) + whole Historical doc
    const exRes = await regeneratePreliminaryResearchWithExclusions({
      planNumber: '20440',
      exclusions: {
        ...createEmptyPreliminaryResearchDocumentsByType(),
        'Historical Scoping Documents': ['hist-1'],
      } as any,
      mode: 'exclude',
      sectionExclusions: {
        'GFMS Data': { 'gfms-1': ['F-1', 'F-2'] },
      },
    });
    expect(exRes.deletedCount).toBe(2);
    expect(exRes.affectedSections).toEqual(['findings_analysis', 'broad_scope']);

    // Include single section -> `section_id`, `section_title`, `node_id` + client fallback affectedSections
    const incRes = await regeneratePreliminaryResearchWithExclusions({
      planNumber: '20440',
      exclusions: {},
      mode: 'include',
      sectionExclusions: {
        'GFMS Data': { 'gfms-1': ['F-1'] },
      },
    });
    expect(incRes.deletedCount).toBe(1);
    expect(incRes.affectedSections).toEqual(['findings_analysis', 'broad_scope']);
  });

  it('triggers RUN_ANALYTICS via triggerPreliminaryResearchGeneration with sections and dispatches event', async () => {
    const postSpy = vi.spyOn(sharedApi, 'postJson').mockResolvedValue({ status: 'ok' });
    const eventSpy = vi.fn();
    window.addEventListener('ai-chat:generate-preliminary-research', eventSpy);

    await triggerPreliminaryResearchGeneration('20440', ['findings_analysis', 'broad_scope']);
    expect(eventSpy).toHaveBeenCalledTimes(1);
    expect((eventSpy.mock.calls[0][0] as CustomEvent).detail).toEqual({
      payload: { sections: ['findings_analysis', 'broad_scope'] },
    });
    expect(postSpy).toHaveBeenCalledWith('/dbaware-api-gateway/api/v1/actions', {
      planNumber: '20440',
      action: 'RUN_ANALYTICS',
      payload: { sections: ['findings_analysis', 'broad_scope'] },
    });

    await triggerPreliminaryResearchGeneration('20440');
    expect(postSpy).toHaveBeenLastCalledWith('/dbaware-api-gateway/api/v1/actions', {
      planNumber: '20440',
      action: 'RUN_ANALYTICS',
      payload: {},
    });

    window.removeEventListener('ai-chat:generate-preliminary-research', eventSpy);
  });
});
