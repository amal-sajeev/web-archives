import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  ALL_PRELIMINARY_RESEARCH_DOCUMENT_TYPES,
  computeAffectedPreliminaryResearchSections,
  createEmptyPreliminaryResearchDocumentsByType,
  fetchPreliminaryResearchSourceDocuments,
  ingestPreliminaryResearchDocument,
  regeneratePreliminaryResearchWithExclusions,
  triggerPreliminaryResearchGeneration,
} from './preliminaryResearchClient';
import * as sharedApi from './sharedApi';

describe('preliminaryResearchClient', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('computes deduplicated affected sections in canonical order across all 6 sources', () => {
    expect(ALL_PRELIMINARY_RESEARCH_DOCUMENT_TYPES).toEqual([
      'Policies',
      'KOD',
      'Procedure Documents',
      'GFMS Data',
      'Historical Scoping Documents',
      'LRR',
    ]);

    expect(computeAffectedPreliminaryResearchSections(['Policies', 'KOD', 'LRR'])).toEqual([
      'policy_regulation',
      'broad_scope',
    ]);
    expect(computeAffectedPreliminaryResearchSections(['GFMS Data'])).toEqual([
      'broad_scope',
    ]);
    expect(
      computeAffectedPreliminaryResearchSections(['Historical Scoping Documents', 'GFMS Data', 'Policies'])
    ).toEqual(['past_review', 'policy_regulation', 'broad_scope']);
  });

  it('fetches and normalizes all 6 source categories with sections and storage URIs', async () => {
    const postSpy = vi.spyOn(sharedApi, 'postJson').mockResolvedValue({
      response: {
        data: {
          document_groups: [
            {
              document_type: 'policy',
              documents: [
                {
                  file_name: 'pol1.json',
                  document_title: 'Policy One',
                  document_id: 'pol-1',
                  storage_uri: 'gs://bucket/pol1.json',
                  status: 'active',
                  excluded: false,
                  sections: [
                    { section_id: 1, section_title: 'Intro', node_id: 'n1', status: 'active', excluded: false },
                  ],
                },
              ],
            },
            {
              document_type: 'kod',
              documents: [{ file_name: 'kod1.json', document_title: 'KOD 1', document_id: 'kod-1', excluded: true }],
            },
            {
              document_type: 'procedure',
              documents: [{ file_name: 'proc1.json', document_title: 'Proc 1', document_id: 'proc-1' }],
            },
            {
              document_type: 'gfms',
              documents: [
                {
                  file_name: 'gfms.json',
                  document_title: 'GFMS Findings',
                  document_id: 'gfms-doc',
                  sections: [
                    { section_id: 'F-10', section_title: 'Access Finding', node_id: 'gfms:finding:F-10', status: 'excluded' },
                    { section_id: 'F-11', section_title: 'Logging Finding', node_id: 'gfms:finding:F-11', status: 'active' },
                  ],
                },
              ],
            },
            {
              document_type: 'historical_scoping_document',
              documents: [
                {
                  file_name: 'hist.json',
                  document_title: 'Prior Plan',
                  document_id: 'hist-doc',
                },
              ],
            },
            {
              document_type: 'lrr',
              documents: [
                {
                  file_name: 'internet_search_data_enriched.json',
                  document_title: 'Regulatory & Internet Search Mandates',
                  document_id: 'lrr_internet_search_data_enriched',
                  sections: [
                    { section_id: 1, section_title: 'BaFin Mandate', node_id: 'lrr:mandate:1', excluded: false },
                  ],
                },
              ],
            },
            {
              document_type: 'unknown_type',
              documents: [],
            },
          ],
        },
      },
    });

    const res = await fetchPreliminaryResearchSourceDocuments('20440');
    expect(postSpy).toHaveBeenCalledTimes(1);
    expect(res.documentsByType.Policies[0]).toMatchObject({
      id: 'pol-1',
      storageUri: 'gs://bucket/pol1.json',
      excluded: false,
    });
    expect(res.documentsByType.KOD[0].excluded).toBe(true);
    expect(res.documentsByType['Procedure Documents']).toHaveLength(1);
    expect(res.documentsByType['GFMS Data'][0].sections).toHaveLength(2);
    expect(res.documentsByType['GFMS Data'][0].sections?.[0].excluded).toBe(true);
    expect(res.documentsByType['Historical Scoping Documents'][0].id).toBe('hist-doc');
    expect(res.documentsByType.LRR[0].sections).toHaveLength(1);
  });

  it('supports whole-doc, single-section, and multi-section exclude and include regeneration', async () => {
    vi.spyOn(sharedApi, 'postJson')
      .mockResolvedValueOnce({
        document_groups: [
          {
            document_type: 'gfms',
            documents: [
              {
                file_name: 'gfms.json',
                document_title: 'GFMS',
                document_id: 'gfms-1',
                sections: [
                  { section_id: 'F-1', section_title: 'Finding 1', node_id: 'gfms:finding:F-1', excluded: false },
                  { section_id: 'F-2', section_title: 'Finding 2', node_id: 'gfms:finding:F-2', excluded: false },
                ],
              },
            ],
          },
          {
            document_type: 'historical_scoping_document',
            documents: [{ file_name: 'hist.json', document_title: 'Hist', document_id: 'hist-1', excluded: true }],
          },
        ],
      })
      .mockResolvedValueOnce({
        results: [{ total_deleted: 2, affected_sections: ['past_review', 'broad_scope'] }],
      })
      .mockResolvedValueOnce({
        total_deleted: 1,
      });

    await fetchPreliminaryResearchSourceDocuments('20440');

    // Exclude two sections of GFMS (multi-section -> `sections` array) + whole Historical doc
    const exRes = await regeneratePreliminaryResearchWithExclusions({
      planNumber: '20440',
      exclusions: {
        ...createEmptyPreliminaryResearchDocumentsByType(),
        'Historical Scoping Documents': ['hist-1'],
      } as any,
      mode: 'exclude',
      sectionExclusions: {
        'GFMS Data': { 'gfms-1': ['F-1', 'F-2'] },
      },
    });
    expect(exRes.deletedCount).toBe(2);
    expect(exRes.affectedSections).toEqual(['past_review', 'broad_scope']);

    // Include single section -> `section_id`, `section_title`, `node_id` + client fallback affectedSections
    const incRes = await regeneratePreliminaryResearchWithExclusions({
      planNumber: '20440',
      exclusions: {},
      mode: 'include',
      sectionExclusions: {
        'GFMS Data': { 'gfms-1': ['F-1'] },
      },
    });
    expect(incRes.deletedCount).toBe(1);
    expect(incRes.affectedSections).toEqual(['broad_scope']);
  });

  it('triggers RUN_ANALYTICS via triggerPreliminaryResearchGeneration with sections and dispatches event', async () => {
    const postSpy = vi.spyOn(sharedApi, 'postJson').mockResolvedValue({ status: 'ok' });
    const eventSpy = vi.fn();
    window.addEventListener('ai-chat:generate-preliminary-research', eventSpy);

    await triggerPreliminaryResearchGeneration('20440', ['past_review', 'broad_scope']);
    expect(eventSpy).toHaveBeenCalledTimes(1);
    expect((eventSpy.mock.calls[0][0] as CustomEvent).detail).toEqual({
      payload: { sections: ['past_review', 'broad_scope'] },
    });
    expect(postSpy).toHaveBeenCalledWith('/dbaware-api-gateway/api/v1/actions', {
      planNumber: '20440',
      action: 'RUN_ANALYTICS',
      payload: { sections: ['past_review', 'broad_scope'] },
    });

    await triggerPreliminaryResearchGeneration('20440');
    expect(postSpy).toHaveBeenLastCalledWith('/dbaware-api-gateway/api/v1/actions', {
      planNumber: '20440',
      action: 'RUN_ANALYTICS',
      payload: {},
    });

    window.removeEventListener('ai-chat:generate-preliminary-research', eventSpy);
  });

  it('attaches userDetails from sessionStorage scoping context', async () => {
    window.sessionStorage.setItem(
      'scopingContext:20440',
      JSON.stringify({ planNumber: '20440', processInstanceId: 'proc-1', taskId: 'task-1', taskDefinitionKey: 'PRELIMINARY_RESEARCH' })
    );
    const postSpy = vi.spyOn(sharedApi, 'postJson').mockResolvedValue({ document_groups: [] });
    await fetchPreliminaryResearchSourceDocuments('20440');
    expect(postSpy.mock.calls[0][1].payload.userDetails).toEqual({
      process_instance_id: 'proc-1',
      task_id: 'task-1',
      review_scope_stage: 'PRELIMINARY_RESEARCH',
    });
    window.sessionStorage.removeItem('scopingContext:20440');
  });

  it('maps findings_details and historical_plan_details artifact aliases into GFMS and Historical sources', async () => {
    vi.spyOn(sharedApi, 'postJson').mockResolvedValue({
      response: {
        data: {
          document_groups: [
            {
              document_type: 'findings_details',
              documents: [
                {
                  document_id: 'fd-1',
                  document_title: 'GFMS Findings Feed',
                  sections: [{ section_id: 'F-1', section_title: 'Finding One', excluded: false }],
                },
              ],
            },
            {
              document_type: 'historical_plan_details',
              documents: [{ document_id: 'hp-1', document_title: 'Historical Plan 2024' }],
            },
          ],
        },
      },
    });

    const res = await fetchPreliminaryResearchSourceDocuments('20440');

    expect(res.documentsByType['GFMS Data']).toHaveLength(1);
    expect(res.documentsByType['GFMS Data'][0]).toMatchObject({ id: 'fd-1', title: 'GFMS Findings Feed' });
    expect(res.documentsByType['GFMS Data'][0].sections).toHaveLength(1);
    expect(res.documentsByType['Historical Scoping Documents']).toHaveLength(1);
    expect(res.documentsByType['Historical Scoping Documents'][0]).toMatchObject({ id: 'hp-1' });
    expect(res.documentsByType.Policies).toHaveLength(0);
  });

  it('ingests source documents with scope form fields and persists relevant context', async () => {
    window.sessionStorage.setItem(
      'scopingContext:20440',
      JSON.stringify({
        planNumber: '20440',
        processInstanceId: 'proc-9',
        taskId: 'task-9',
        taskDefinitionKey: 'PRELIMINARY_RESEARCH',
        reviewScopeId: 'rs-9',
        owner: 'reviewer@db.com',
      })
    );

    const formSpy = vi
      .spyOn(sharedApi, 'postFormData')
      .mockResolvedValue({ status: 'accepted', job_id: 'job-9', document_ids: [301] });
    const postSpy = vi.spyOn(sharedApi, 'postJson').mockResolvedValue({
      status: 'success',
      persisted_files: ['New_Policy.pdf'],
      registry_updated: true,
      message: 'Uploaded document persisted into plan context.',
    });

    const file = new File(['%PDF-1.4'], 'New_Policy.pdf', { type: 'application/pdf' });
    const res = await ingestPreliminaryResearchDocument('20440', [file], 'policy');

    expect(formSpy).toHaveBeenCalledTimes(1);
    const [ingestPath, fields] = formSpy.mock.calls[0] as [string, Record<string, any>];
    expect(ingestPath).toBe('/query-service/qna/documents/ingest');
    expect(fields).toMatchObject({
      plan_number: '20440',
      document_type: 'policy',
      review_scope_id: 'rs-9',
      process_instance_id: 'proc-9',
      task_id: 'task-9',
      review_scope_stage: 'PRELIMINARY_RESEARCH',
    });
    expect(JSON.parse(fields.user_details)).toMatchObject({
      review_scope_id: 'rs-9',
      process_instance_id: 'proc-9',
      task_id: 'task-9',
    });

    expect(postSpy).toHaveBeenCalledTimes(1);
    const [, relevantRequest] = postSpy.mock.calls[0] as [string, any];
    expect(relevantRequest).toMatchObject({
      planNumber: '20440',
      action: 'QNA_GET_RELEVANT_DATA',
      payload: {
        plan_number: '20440',
        persist_to_context: true,
        documents: [{ document_type: 'policy', document_ids: [301], top_k: 5 }],
      },
    });
    expect(relevantRequest.payload.userDetails).toMatchObject({ review_scope_id: 'rs-9' });

    expect(res).toMatchObject({
      status: 'success',
      jobId: 'job-9',
      documentIds: [301],
      persistedFiles: ['New_Policy.pdf'],
      registryUpdated: true,
      affectedSections: ['policy_regulation', 'broad_scope'],
    });

    window.sessionStorage.removeItem('scopingContext:20440');
  });

  it('throws with details when every delete item failed', async () => {
    vi.spyOn(sharedApi, 'postJson').mockResolvedValue({
      total_deleted: 0,
      results: [{ document_type: 'policy', total_deleted: 0, files_failed: ['p1.json'], error_details: [{ title: 'p1', error: 'db write failed' }] }],
    });
    await expect(
      regeneratePreliminaryResearchWithExclusions({
        planNumber: '20440',
        exclusions: { Policies: ['p1'] } as any,
        mode: 'exclude',
      })
    ).rejects.toMatchObject({ details: { errorDetails: [{ title: 'p1', error: 'db write failed' }] } });
  });
});
