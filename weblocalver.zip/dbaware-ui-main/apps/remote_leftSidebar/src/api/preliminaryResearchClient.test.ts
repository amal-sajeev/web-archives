import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  fetchPreliminaryResearchSourceDocuments,
  fetchPreliminaryResearchDocumentGroups,
  regeneratePreliminaryResearchWithExclusions,
  fetchHistoricalPreliminaryResearchSourceDocuments,
  deleteHistoricalPreliminaryResearchSourceDocuments,
} from './preliminaryResearchClient';
import * as sharedApi from './sharedApi';

describe('preliminaryResearchClient', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.sessionStorage.clear();
  });

  it('fetches and normalizes document groups forwarding review_scope_id from p_REVIEW_SCOPE_ID', async () => {
    const getSpy = vi.fn().mockResolvedValue({
      processInstanceId: 'proc-11',
      taskId: 'task-22',
      taskDefinitionKey: 'PRELIMINARY_RESEARCH',
      variables: { p_REVIEW_SCOPE_ID: 88 },
    });
    const postSpy = vi.fn().mockResolvedValue({
      response: {
        document_groups: [
          {
            document_type: 'policy',
            documents: [
              {
                document_id: '10',
                document_title: 'Access Policy',
                file_name: 'policy10.json',
                status: 'active',
                excluded: false,
                sections: [
                  { section_id: '1', section_title: 'Scope', node_id: '10:section:1', status: 'active', excluded: false },
                ],
              },
            ],
          },
          {
            document_type: 'gfms',
            documents: [
              {
                document_id: 'gfms-1',
                document_title: 'GFMS Findings',
                file_name: 'findings_details.json',
                status: 'active',
                excluded: false,
                sections: [],
              },
            ],
          },
        ],
      },
    });
    (window as any).__dbaware = { apiClient: { get: getSpy, post: postSpy } };

    const groups = await fetchPreliminaryResearchDocumentGroups('20583');
    expect(getSpy).toHaveBeenCalledWith('/dbaware-api-gateway/api/v1/task/status/20583', { timeout: 600000 });
    expect(postSpy).toHaveBeenCalledWith(
      '/dbaware-api-gateway/api/v1/actions',
      expect.objectContaining({
        planNumber: '20583',
        action: 'QNA_LIST_DOCUMENTS',
        payload: {
          user_details: expect.objectContaining({
            review_scope_instance_id: 88,
            review_scope_id: 88,
            process_instance_id: 'proc-11',
            task_id: 'task-22',
            review_scope_stage: 'PRELIMINARY_RESEARCH',
          }),
        },
      }),
      expect.any(Object)
    );
    expect(groups).toHaveLength(2);
    expect(groups[0].documents[0].sections[0].title).toBe('Scope');

    const docsResp = await fetchPreliminaryResearchSourceDocuments('20583');
    expect(docsResp.documentsByType.Policies).toHaveLength(1);
    expect(docsResp.documentsByType.Policies[0].title).toBe('Access Policy');
  });

  it('falls back to sessionStorage scopingContext when /task/status fails', async () => {
    window.sessionStorage.setItem(
      'scopingContext:20584',
      JSON.stringify({
        planNumber: '20584',
        reviewScopeId: '99',
        processInstanceId: 'proc-99',
        taskId: 'task-99',
        taskDefinitionKey: 'PRELIMINARY_RESEARCH',
        owner: 'reviewer@db.com',
      })
    );

    const getSpy = vi.fn().mockRejectedValue(new Error('task status unavailable'));
    const postSpy = vi.fn().mockResolvedValue({ response: { document_groups: [] } });
    (window as any).__dbaware = { apiClient: { get: getSpy, post: postSpy } };

    const groups = await fetchPreliminaryResearchDocumentGroups('20584');
    expect(groups).toEqual([]);
    expect(postSpy).toHaveBeenCalledWith(
      '/dbaware-api-gateway/api/v1/actions',
      expect.objectContaining({
        planNumber: '20584',
        action: 'QNA_LIST_DOCUMENTS',
        payload: {
          user_details: expect.objectContaining({
            review_scope_instance_id: 99,
            review_scope_id: 99,
            process_instance_id: 'proc-99',
            task_id: 'task-99',
            review_scope_stage: 'PRELIMINARY_RESEARCH',
            user: 'reviewer@db.com',
          }),
        },
      }),
      expect.any(Object)
    );
  });

  it('sends user_details on QNA_DELETE_DOCUMENTS and supports historical list/delete', async () => {
    window.sessionStorage.setItem(
      'scopingContext:20585',
      JSON.stringify({ planNumber: '20585', reviewScopeId: '105', processInstanceId: 'proc-105' })
    );
    const getSpy = vi.fn().mockResolvedValue({});
    const postSpy = vi
      .fn()
      .mockResolvedValueOnce({
        response: {
          document_groups: [
            { document_type: 'policy', documents: [{ document_id: 'p1', document_title: 'Pol 1', file_name: 'p1.json' }] },
          ],
        },
      })
      .mockResolvedValueOnce({ response: { total_deleted: 1 } })
      .mockResolvedValueOnce({ response: { plan_items: [{ plan_item_number: 19001, plan_item_title: 'Past Review' }] } })
      .mockResolvedValueOnce({ response: { deleted_count: 1 } });
    (window as any).__dbaware = { apiClient: { get: getSpy, post: postSpy } };

    await fetchPreliminaryResearchSourceDocuments('20585');
    const regen = await regeneratePreliminaryResearchWithExclusions({
      planNumber: '20585',
      exclusions: { Policies: ['p1'], KOD: [], 'Procedure Documents': [] },
    });
    expect(regen).toEqual({ deletedCount: 1, generated: true });
    expect(postSpy.mock.calls[1][1]).toMatchObject({
      planNumber: '20585',
      action: 'QNA_DELETE_DOCUMENTS',
      payload: {
        user_details: expect.objectContaining({ review_scope_instance_id: 105, process_instance_id: 'proc-105' }),
      },
    });

    const hist = await fetchHistoricalPreliminaryResearchSourceDocuments('20585');
    expect(hist).toEqual([{ planItemNumber: 19001, planItemTitle: 'Past Review' }]);
    const delHist = await deleteHistoricalPreliminaryResearchSourceDocuments('20585', hist);
    expect(delHist).toEqual({ deletedCount: 1 });
  });
});
