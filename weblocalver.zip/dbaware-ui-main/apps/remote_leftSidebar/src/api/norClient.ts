import { postJson } from './sharedApi';

export interface NorOriginalData {
    'Plan Item Number'?: number;
    'Plan Item Title'?: string;
    'Description of Plan Item'?: string;
    'Coordinating Team Lead'?: string;
    'Review Lead'?: string;
    'Risk Types'?: string[];
    [key: string]: any;
}

export interface NorGenerateResponse {
    subject?: string;
    body?: string;
    email_content?: string;
    email: string;
    recipients?: string[];
    original_data: NorOriginalData[];
}

export interface EditNorPayload {
    plan_item_number: string;
    user_instruction: string;
}

export interface HumanEditNorPayload {
    plan_item_number: string;
    subject?: string;
    body?: string;
    nor: {
        subject: string;
        body: string;
    };
}

export interface SendNorPayload {
    plan_item_number: string;
    subject: string;
    body: string;
    to_recipients: string[];
    from_address: string;
}

type NorAction = 'GET_NOR' | 'GENERATE_NOR' | 'EDIT_NOR' | 'HUMAN_EDIT_NOR' | 'SEND_NOR_EMAIL';

interface NorGatewayRequest<TPayload> {
    planNumber: string;
    action: NorAction;
    payload: TPayload;
}

type HumanEditNorGatewayPayload = Omit<HumanEditNorPayload, 'nor'> & {
    /** Gateway expects this key for edited document payload. */
    nor: {
        subject: string;
        body: string;
    };
};

export const NOR_ACTIONS_URL = '/dbaware-api-gateway/api/v1/actions';

const buildPlanNumber = (planNumber: number | string): string => String(planNumber);

const extractNorPayload = (response: unknown): Record<string, any> => {
    const queue: unknown[] = [response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();

        if (!current || typeof current !== 'object' || visited.has(current)) {
            continue;
        }

        visited.add(current);

        const candidate = current as Record<string, any>;
        const nestedNor =
            candidate.nor && typeof candidate.nor === 'object'
                ? {
                    ...candidate.nor,
                    original_data:
                        candidate.original_data ??
                        candidate.updated_data ??
                        candidate.nor.original_data,
                }
                : null;

        const nestedNoir =
            candidate.noir && typeof candidate.noir === 'object'
                ? {
                    ...candidate.noir,
                    original_data:
                        candidate.original_data ??
                        candidate.updated_data ??
                        candidate.noir.original_data,
                }
                : null;

        if (
            nestedNor ||
            nestedNoir ||
            'subject' in candidate ||
            'body' in candidate ||
            'email' in candidate ||
            'email_content' in candidate ||
            'recipients' in candidate ||
            'original_data' in candidate ||
            'updated_data' in candidate
        ) {
            return nestedNor ?? nestedNoir ?? candidate;
        }

        if ('payload' in candidate) queue.push(candidate.payload);
        if ('data' in candidate) queue.push(candidate.data);
        if ('result' in candidate) queue.push(candidate.result);
        if ('response' in candidate) queue.push(candidate.response);
    }

    return (response ?? {}) as Record<string, any>;
};

const normalizeNorData = (response: unknown): NorGenerateResponse => {
    const payload = extractNorPayload(response);
    const emailBody = payload.email_content ?? payload.email ?? '';

    return {
        subject: payload.subject,
        body: payload.body,
        email: emailBody, // Assign to a single field (e.g., 'email' or 'emailBody')
        recipients: Array.isArray(payload.recipients) ? payload.recipients : [],
        original_data: Array.isArray(payload.original_data)
            ? payload.original_data
            : Array.isArray(payload.updated_data)
                ? payload.updated_data
                : []
    };
};

const postNorAction = <TResponse, TPayload>(
    planNumber: number | string,
    action: NorAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: NorGatewayRequest<TPayload> = {
        planNumber: buildPlanNumber(planNumber),
        action,
        payload,
    };

    return postJson<TResponse>(NOR_ACTIONS_URL, request);
};

export const getNor = async (
    planItemNumber: number | string
): Promise<NorGenerateResponse> => {
    const response = await postNorAction<unknown, Record<string, never>>(planItemNumber, 'GET_NOR', {});
    return normalizeNorData(response);
};

export const generateNor = async (
    planItemNumber: number | string
): Promise<NorGenerateResponse> => {
    const response = await postNorAction<unknown, { plan_item_number: string }>(
        planItemNumber,
        'GENERATE_NOR',
        { plan_item_number: buildPlanNumber(planItemNumber) }
    );

    return normalizeNorData(response);
};

export const editNor = async (payload: EditNorPayload): Promise<NorGenerateResponse> => {
    const response = await postNorAction<unknown, EditNorPayload>(
        payload.plan_item_number,
        'EDIT_NOR',
        payload
    );

    return normalizeNorData(response);
};

export const humanEditNor = async (payload: HumanEditNorPayload): Promise<NorGenerateResponse> => {
    const gatewayPayload: HumanEditNorGatewayPayload = {
        plan_item_number: payload.plan_item_number,
        subject: payload.subject ?? payload.nor.subject,
        body: payload.body ?? payload.nor.body,
        nor: {
            subject: payload.nor.subject,
            body: payload.nor.body,
        },
    };

    const response = await postNorAction<unknown, HumanEditNorGatewayPayload>(
        payload.plan_item_number,
        'HUMAN_EDIT_NOR',
        gatewayPayload
    );

    return normalizeNorData(response);
};

export const sendNor = (payload: SendNorPayload): Promise<unknown> =>
    postNorAction<unknown, SendNorPayload>(
        payload.plan_item_number,
        'SEND_NOR_EMAIL',
        payload
    );