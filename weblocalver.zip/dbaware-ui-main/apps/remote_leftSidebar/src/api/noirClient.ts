import { postJson, postJsonWithHeaders } from './sharedApi';

export interface NoirOriginalData {
    'Plan Item Number': number;
    'Plan Item Title': string;
    'Description of Plan Item': string;
    'AU Aggregation point 2': string;
    'UoT KCs': string[];
    'Review Coverage Period Start Date': string | null;
    'Review Coverage Period End Date': string | null;
    'Plan Item original Target Start date': string;
    'Plan Item Current Target Start Date': string;
    'Plan Item Actual Start Date': string;
    'Draft Reporting Original Target Start Date': string;
    'Draft Reporting Current Target Start Date': string;
    'Report Publication Original Target Start Date': string;
    'Report Publication Current Target Start Date': string;
    'Coordinating Team Lead': string;
    'Review Lead': string;
    'Risk Types': string[];
}

export interface NoirGenerateResponse {
    subject?: string;
    body?: string;
    email?: string;
    recipients?: string[];
    next_available_actions?: string[];
    task_definition_key?: string;
    original_data: NoirOriginalData[];
}

export interface EditNoirPayload {
    plan_item_number: string;
    user_instruction: string;
}

export interface HumanEditNoirPayload {
    plan_item_number: string;
    subject?: string;
    body?: string;
    noir: {
        subject: string;
        body: string;
    };
}

export interface SendNoirPayload {
    plan_item_number: string;
    subject: string;
    body: string;
    to_recipients: string[];
    from_address: string;
}

type NoirAction = 'GET_NOIR' | 'GENERATE_NOIR' | 'EDIT_NOIR' | 'HUMAN_EDIT' | 'SEND_NOIR_EMAIL';

interface NoirGatewayRequest<TPayload> {
    planNumber: string;
    action: NoirAction;
    payload: TPayload;
}

export const NOIR_ACTIONS_URL = '/dbaware-api-gateway/api/v1/actions';

const buildPlanNumber = (planNumber: number | string): string => String(planNumber);

const serializeHumanEditPayload = (payload: HumanEditNoirPayload): HumanEditNoirPayload => ({
    ...payload,
    subject: payload.subject ?? payload.noir.subject,
    body: payload.body ?? payload.noir.body,
});

const extractNoirPayload = (response: unknown): Record<string, any> => {
    const queue: unknown[] = [response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();

        if (!current || typeof current !== 'object' || visited.has(current)) {
            continue;
        }

        visited.add(current);

        const candidate = current as Record<string, any>;
        const nestedNoir = candidate.noir && typeof candidate.noir === 'object'
            ? {
                ...candidate.noir,
                original_data: candidate.original_data ?? candidate.updated_data ?? candidate.noir.original_data,
            }
            : null;

        if (
            nestedNoir ||
            'subject' in candidate ||
            'body' in candidate ||
            'email' in candidate ||
            'email_content' in candidate ||
            'recipients' in candidate ||
            'original_data' in candidate ||
            'updated_data' in candidate
        ) {
            return nestedNoir ?? candidate;
        }

        if ('payload' in candidate) queue.push(candidate.payload);
        if ('data' in candidate) queue.push(candidate.data);
        if ('result' in candidate) queue.push(candidate.result);
        if ('response' in candidate) queue.push(candidate.response);
    }

    return (response ?? {}) as Record<string, any>;
};

const normalizeNoirData = (response: unknown): NoirGenerateResponse => {
    const payload = extractNoirPayload(response);

    return {
        subject: payload.subject,
        body: payload.body,
        email: payload.email_content ?? payload.email,
        recipients: Array.isArray(payload.recipients) ? payload.recipients : [],
        original_data: payload.original_data ?? payload.updated_data ?? [],
    };
};

interface PlanStatusWorkflowAction {
    action?: string;
    sub_action?: string | null;
}

interface PlanStatusHeaderPayload {
    taskDefinitionKey?: string;
    variables?: {
        p_NEXT_AVAILABLE_ACTIONS?: string;
        [key: string]: unknown;
    };
    nextAvailableWorkflowActions?: PlanStatusWorkflowAction[];
}

const parseTaskDefinitionKeyFromHeader = (headerValue?: string): string | undefined => {
    if (!headerValue) return undefined;

    try {
        const parsed = JSON.parse(headerValue) as PlanStatusHeaderPayload;
        if (typeof parsed.taskDefinitionKey === 'string' && parsed.taskDefinitionKey.trim().length > 0) {
            return parsed.taskDefinitionKey.trim();
        }
    } catch (error) {
        console.warn('Unable to parse taskDefinitionKey from x-plan-status header', error);
    }

    return undefined;
};

const parseNextAvailableActionsFromHeader = (headerValue?: string): string[] => {
    if (!headerValue) return [];

    try {
        const parsed = JSON.parse(headerValue) as PlanStatusHeaderPayload;
        const fromVariables = parsed.variables?.p_NEXT_AVAILABLE_ACTIONS;

        if (typeof fromVariables === 'string' && fromVariables.trim().length > 0) {
            return fromVariables
                .split(',')
                .map((action) => action.trim())
                .filter(Boolean);
        }

        if (Array.isArray(parsed.nextAvailableWorkflowActions)) {
            return parsed.nextAvailableWorkflowActions
                .map((item) => (typeof item.action === 'string' ? item.action.trim() : ''))
                .filter(Boolean);
        }
    } catch (error) {
        console.warn('Unable to parse x-plan-status header', error);
    }

    return [];
};

const postNoirAction = <TResponse, TPayload>(
    planNumber: number | string,
    action: NoirAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: NoirGatewayRequest<TPayload> = {
        planNumber: buildPlanNumber(planNumber),
        action,
        payload,
    };

    return postJson<TResponse>(NOIR_ACTIONS_URL, request);
};

export const getNoir = async (
    planItemNumber: number | string
): Promise<NoirGenerateResponse> => {
    const response = await postNoirAction<unknown, Record<string, never>>(planItemNumber, 'GET_NOIR', {});
    return normalizeNoirData(response);
};

export const generateNoir = async (
    planItemNumber: number | string
): Promise<NoirGenerateResponse> => {
    const request: NoirGatewayRequest<{ plan_item_number: string; review_scope_instance_id: number }> = {
        planNumber: buildPlanNumber(planItemNumber),
        action: 'GENERATE_NOIR',
        payload: {
            plan_item_number: buildPlanNumber(planItemNumber),
            review_scope_instance_id: 1,
        },
    };

    const response = await postJsonWithHeaders<unknown>(NOIR_ACTIONS_URL, request);
    console.log('GENERATE_NOIR response headers:', response.headers);

    const planStatusHeader = response.headers['x-plan-status'];
    const nextAvailableActions = parseNextAvailableActionsFromHeader(planStatusHeader);
    const taskDefinitionKey = parseTaskDefinitionKeyFromHeader(planStatusHeader);
    const normalized = normalizeNoirData(response.data);

    return {
        ...normalized,
        next_available_actions: nextAvailableActions,
        task_definition_key: taskDefinitionKey,
    };
};

export const editNoir = (payload: EditNoirPayload): Promise<NoirGenerateResponse> =>
    postNoirAction<unknown, EditNoirPayload>(
        payload.plan_item_number,
        'EDIT_NOIR',
        payload
    ).then(normalizeNoirData);

export const humanEditNoir = (payload: HumanEditNoirPayload): Promise<NoirGenerateResponse> =>
    postNoirAction<unknown, HumanEditNoirPayload>(
        payload.plan_item_number,
        'HUMAN_EDIT',
        serializeHumanEditPayload(payload)
    ).then(normalizeNoirData);

export const sendNoir = (payload: SendNoirPayload): Promise<unknown> =>
    postNoirAction<unknown, SendNoirPayload>(
        payload.plan_item_number,
        'SEND_NOIR_EMAIL',
        payload
    );
