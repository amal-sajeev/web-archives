import { ApiRequestError, postFormData, postJson } from './sharedApi';
import type { ApiErrorItemDetail } from './sharedApi';
import { buildUserDetailsForPlan } from './scopeContext';
import type { ApiUserDetails } from './scopeContext';

export type PreliminaryResearchDocumentType =
    | 'Policies'
    | 'KOD'
    | 'Procedure Documents'
    | 'GFMS Data'
    | 'Historical Scoping Documents'
    | 'LRR';

export const ALL_PRELIMINARY_RESEARCH_DOCUMENT_TYPES: PreliminaryResearchDocumentType[] = [
    'Policies',
    'KOD',
    'Procedure Documents',
    'GFMS Data',
    'Historical Scoping Documents',
    'LRR',
];

export interface PreliminaryResearchSectionRecord {
    section_id: string | number;
    section_title?: string;
    node_id?: string;
    status?: 'active' | 'inactive' | 'excluded';
    excluded?: boolean;
}

export interface PreliminaryResearchDocumentItem {
    id: string;
    title: string;
    type: PreliminaryResearchDocumentType;
    fileName?: string;
    documentTitle?: string;
    documentId?: string;
    storageUri?: string;
    status?: 'active' | 'inactive' | 'excluded';
    excluded?: boolean;
    sections?: PreliminaryResearchSectionRecord[];
}

export interface PreliminaryResearchDocumentsResponse {
    documentsByType: Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>;
}

export interface RegeneratePreliminaryResearchRequest {
    planNumber: string;
    exclusions: Partial<Record<PreliminaryResearchDocumentType, string[]>>;
    mode?: 'exclude' | 'include';
    sectionExclusions?: Partial<
        Record<PreliminaryResearchDocumentType, Record<string, Array<string | number>>>
    >;
}

export interface RegeneratePreliminaryResearchResponse {
    deletedCount: number;
    generated: boolean;
    affectedSections?: string[];
    failedItems?: string[];
    errorDetails?: ApiErrorItemDetail[];
}

export interface IngestPreliminaryResearchDocumentOptions {
    pollIntervalMs?: number;
    maxPolls?: number;
}

export interface IngestPreliminaryResearchDocumentResponse {
    status: string;
    jobId?: string;
    documentIds: number[];
    persistedFiles: string[];
    registryUpdated: boolean;
    affectedSections: string[];
    message: string;
}

interface ListAllDocumentsRequest {
    plan_number: string;
    userDetails?: ApiUserDetails;
}

interface ListAllDocument {
    file_name?: string;
    document_title?: string;
    document_id?: string;
    storage_uri?: string;
    status?: 'active' | 'inactive' | 'excluded';
    excluded?: boolean;
    sections?: PreliminaryResearchSectionRecord[];
}

interface ListAllDocumentGroup {
    document_type?: string;
    documents?: ListAllDocument[];
}

interface ListAllDocumentsResponse {
    document_groups?: ListAllDocumentGroup[];
}

interface DeleteDocumentsItem {
    file_name: string;
    document_title: string;
    document_id: string;
    section_id?: string | number;
    section_title?: string;
    node_id?: string;
    action?: 'exclude' | 'include';
    sections?: PreliminaryResearchSectionRecord[];
}

interface DeleteDocumentsGroup {
    document_type: string;
    items: DeleteDocumentsItem[];
}

interface DeleteDocumentsRequest {
    documents: DeleteDocumentsGroup[];
    userDetails?: ApiUserDetails;
}

interface DeleteDocumentsResult {
    document_type?: string;
    total_deleted?: number;
    files_failed?: string[];
    affected_sections?: string[];
    error_details?: ApiErrorItemDetail[];
    message?: string;
}

interface DeleteDocumentsResponse {
    total_deleted?: number;
    results?: DeleteDocumentsResult[];
    affected_sections?: string[];
    error_details?: ApiErrorItemDetail[];
    message?: string;
}

export const PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS = {
    actions: '/dbaware-api-gateway/api/v1/actions',
    ingest: '/query-service/qna/documents/ingest',
};

const PRELIMINARY_RESEARCH_ACTIONS = {
    list: 'QNA_LIST_DOCUMENTS',
    delete: 'QNA_DELETE_DOCUMENTS',
    runAnalytics: 'RUN_ANALYTICS',
    ingestJobStatus: 'QNA_GET_INGEST_JOB_STATUS',
    categorizeDocuments: 'QNA_CATEGORIZE_DOCUMENTS',
    getRelevantData: 'QNA_GET_RELEVANT_DATA',
} as const;

const CANONICAL_SECTION_ORDER = [
    'past_review',
    'policy_regulation',
    'broad_scope',
] as const;

const TYPE_TO_AFFECTED_SECTIONS: Record<PreliminaryResearchDocumentType, string[]> = {
    Policies: ['policy_regulation', 'broad_scope'],
    KOD: ['policy_regulation', 'broad_scope'],
    'Procedure Documents': ['policy_regulation', 'broad_scope'],
    'GFMS Data': ['broad_scope'],
    'Historical Scoping Documents': ['past_review', 'broad_scope'],
    LRR: ['policy_regulation', 'broad_scope'],
};

export const createEmptyPreliminaryResearchDocumentsByType = (): Record<
    PreliminaryResearchDocumentType,
    PreliminaryResearchDocumentItem[]
> => ({
    Policies: [],
    KOD: [],
    'Procedure Documents': [],
    'GFMS Data': [],
    'Historical Scoping Documents': [],
    LRR: [],
});

export const EMPTY_PRELIMINARY_RESEARCH_DOCUMENTS_BY_TYPE: Record<
    PreliminaryResearchDocumentType,
    PreliminaryResearchDocumentItem[]
> = createEmptyPreliminaryResearchDocumentsByType();

export const computeAffectedPreliminaryResearchSections = (
    types: PreliminaryResearchDocumentType[]
): string[] => {
    const affected = new Set<string>();
    types.forEach((type) => {
        (TYPE_TO_AFFECTED_SECTIONS[type] || []).forEach((sec) => affected.add(sec));
    });
    return CANONICAL_SECTION_ORDER.filter((sec) => affected.has(sec));
};

const toRecord = (value: unknown): Record<string, any> | null => {
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
        return value as Record<string, any>;
    }
    return null;
};

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const extractGatewayPayload = (response: unknown, hints: string[]): Record<string, any> => {
    const preferred = unwrapGatewayEnvelope(response);
    const queue: unknown[] = preferred === response ? [response] : [preferred, response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        const record = toRecord(current);

        if (!record || visited.has(record)) {
            continue;
        }

        visited.add(record);

        if (hints.some((hint) => hint in record)) {
            return record;
        }

        if ('payload' in record) queue.push(record.payload);
        if ('data' in record) queue.push(record.data);
        if ('result' in record) queue.push(record.result);
        if ('response' in record) queue.push(record.response);
    }

    return toRecord(response) ?? {};
};

const lastFetchedDocumentsByPlan: Record<
    string,
    Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>
> = {};

const toUiDocumentType = (documentType?: string): PreliminaryResearchDocumentType | null => {
    const normalized = (documentType || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
    if (normalized === 'policy' || normalized === 'policies' || normalized === 'policy_policy') {
        return 'Policies';
    }
    if (normalized === 'kod' || normalized === 'policy_kod') {
        return 'KOD';
    }
    if (
        normalized === 'procedure' ||
        normalized === 'procedures' ||
        normalized === 'procedure_documents' ||
        normalized === 'policy_procedure'
    ) {
        return 'Procedure Documents';
    }
    if (
        normalized === 'gfms' ||
        normalized === 'gfms_data' ||
        normalized === 'findings' ||
        normalized === 'findings_details'
    ) {
        return 'GFMS Data';
    }
    if (
        normalized === 'historical_scoping_document' ||
        normalized === 'historical_scoping_documents' ||
        normalized === 'historical_plan' ||
        normalized === 'historical_plan_details' ||
        normalized === 'historical_scoping' ||
        normalized === 'historical'
    ) {
        return 'Historical Scoping Documents';
    }
    if (
        normalized === 'lrr' ||
        normalized === 'lrr_mandates' ||
        normalized === 'laws_rules_and_regulations' ||
        normalized === 'regulations' ||
        normalized === 'regulatory' ||
        normalized === 'regulatory_mandates' ||
        normalized === 'internet_search_data' ||
        normalized === 'internet_search_data_enriched'
    ) {
        return 'LRR';
    }
    return null;
};

const toApiDocumentType = (documentType: PreliminaryResearchDocumentType): string => {
    if (documentType === 'Policies') return 'policy';
    if (documentType === 'KOD') return 'kod';
    if (documentType === 'Procedure Documents') return 'procedure';
    if (documentType === 'GFMS Data') return 'gfms';
    if (documentType === 'LRR') return 'lrr';
    return 'historical_scoping_document';
};

const normalizeSections = (rawSections: unknown): PreliminaryResearchSectionRecord[] => {
    if (!Array.isArray(rawSections)) return [];
    return rawSections
        .filter((sec): sec is Record<string, any> => sec !== null && typeof sec === 'object')
        .map((sec, idx) => ({
            section_id: sec.section_id ?? sec.id ?? idx + 1,
            section_title: sec.section_title ?? sec.title,
            node_id: sec.node_id,
            status: sec.status ?? (sec.excluded ? 'excluded' : 'active'),
            excluded: Boolean(sec.excluded) || String(sec.status || '').toLowerCase() === 'excluded' || String(sec.status || '').toLowerCase() === 'inactive',
        }));
};

/**
 * Fetch source documents (Policies, KOD, Procedures, GFMS Data, Historical Scoping Documents) for Preliminary Research.
 */
export const fetchPreliminaryResearchSourceDocuments = async (
    planNumber: string
): Promise<PreliminaryResearchDocumentsResponse> => {
    const userDetails = buildUserDetailsForPlan(planNumber);
    const request: ListAllDocumentsRequest = userDetails
        ? { plan_number: planNumber, userDetails }
        : { plan_number: planNumber };
    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.list,
            payload: request,
        }
    );
    const payload = extractGatewayPayload(response, ['document_groups']);
    const listResponse = payload as ListAllDocumentsResponse;

    const documentsByType = createEmptyPreliminaryResearchDocumentsByType();

    const groups = Array.isArray(listResponse?.document_groups) ? listResponse.document_groups : [];
    groups.forEach((group) => {
        const uiType = toUiDocumentType(group?.document_type);
        if (!uiType) return;

        const docs = Array.isArray(group?.documents) ? group.documents : [];
        documentsByType[uiType] = docs.map((doc, index) => {
            const id = doc.document_id || doc.file_name || `${uiType}-${index}`;
            const title = doc.document_title || doc.file_name || id;
            const excluded =
                Boolean(doc.excluded) ||
                String(doc.status || '').toLowerCase() === 'excluded' ||
                String(doc.status || '').toLowerCase() === 'inactive';

            return {
                id,
                title,
                type: uiType,
                fileName: doc.file_name,
                documentTitle: doc.document_title,
                documentId: doc.document_id,
                storageUri: doc.storage_uri,
                status: doc.status ?? (excluded ? 'excluded' : 'active'),
                excluded,
                sections: normalizeSections(doc.sections),
            };
        });
    });

    lastFetchedDocumentsByPlan[planNumber] = documentsByType;

    return {
        documentsByType,
    };
};

/**
 * Soft-exclude or restore selected source documents or sections, then return affected Preliminary Research sections.
 */
export const regeneratePreliminaryResearchWithExclusions = async (
    request: RegeneratePreliminaryResearchRequest
): Promise<RegeneratePreliminaryResearchResponse> => {
    const cachedByType =
        lastFetchedDocumentsByPlan[request.planNumber] || createEmptyPreliminaryResearchDocumentsByType();
    const actionMode: 'exclude' | 'include' = request.mode === 'include' ? 'include' : 'exclude';
    const modifiedTypes: PreliminaryResearchDocumentType[] = [];

    const candidateTypes = Array.from(
        new Set<PreliminaryResearchDocumentType>([
            ...(Object.keys(request.exclusions || {}) as PreliminaryResearchDocumentType[]),
            ...(Object.keys(request.sectionExclusions || {}) as PreliminaryResearchDocumentType[]),
        ])
    );

    const documents: DeleteDocumentsGroup[] = candidateTypes
        .map((type) => {
            const selectedDocIds = request.exclusions?.[type] || [];
            const sectionSelectionsByDoc = request.sectionExclusions?.[type] || {};
            const hasSectionSelections = Object.values(sectionSelectionsByDoc).some(
                (ids) => Array.isArray(ids) && ids.length > 0
            );

            if (selectedDocIds.length === 0 && !hasSectionSelections) {
                return null;
            }

            const available = cachedByType[type] || [];
            const availableById = new Map(available.map((item) => [item.id, item]));
            const items: DeleteDocumentsItem[] = [];
            const wholeDocIdSet = new Set(selectedDocIds);

            selectedDocIds.forEach((docId) => {
                const item = availableById.get(docId);
                items.push({
                    file_name: item?.fileName || docId,
                    document_title: item?.documentTitle || item?.title || docId,
                    document_id: item?.documentId || docId,
                    action: actionMode,
                });
            });

            Object.entries(sectionSelectionsByDoc).forEach(([docId, rawSectionIds]) => {
                if (wholeDocIdSet.has(docId) || !Array.isArray(rawSectionIds) || rawSectionIds.length === 0) {
                    return;
                }
                const item = availableById.get(docId);
                const selectedSectionIdStrs = new Set(rawSectionIds.map((sid) => String(sid)));
                const matchedSections: PreliminaryResearchSectionRecord[] = (item?.sections || []).filter((sec) =>
                    selectedSectionIdStrs.has(String(sec.section_id))
                );
                const normalizedTargets: PreliminaryResearchSectionRecord[] =
                    matchedSections.length > 0
                        ? matchedSections
                        : rawSectionIds.map((sid) => ({ section_id: sid }));

                if (normalizedTargets.length === 1) {
                    const sec = normalizedTargets[0];
                    items.push({
                        file_name: item?.fileName || docId,
                        document_title: item?.documentTitle || item?.title || docId,
                        document_id: item?.documentId || docId,
                        section_id: sec.section_id,
                        section_title: sec.section_title,
                        node_id: sec.node_id,
                        action: actionMode,
                    });
                } else {
                    items.push({
                        file_name: item?.fileName || docId,
                        document_title: item?.documentTitle || item?.title || docId,
                        document_id: item?.documentId || docId,
                        action: actionMode,
                        sections: normalizedTargets,
                    });
                }
            });

            if (items.length === 0) {
                return null;
            }

            modifiedTypes.push(type);
            return {
                document_type: toApiDocumentType(type),
                items,
            };
        })
        .filter((group): group is DeleteDocumentsGroup => !!group && group.items.length > 0);

    const userDetails = buildUserDetailsForPlan(request.planNumber);
    const payload: DeleteDocumentsRequest = userDetails
        ? { documents, userDetails }
        : { documents };

    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber: request.planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.delete,
            payload,
        }
    );
    const resultPayload = extractGatewayPayload(response, ['total_deleted', 'results', 'affected_sections', 'error_details']);
    const deleteResponse = resultPayload as DeleteDocumentsResponse;

    const deletedCount =
        typeof deleteResponse?.total_deleted === 'number'
            ? deleteResponse.total_deleted
            : Array.isArray(deleteResponse?.results)
              ? deleteResponse.results.reduce((sum, result) => sum + (result.total_deleted || 0), 0)
              : 0;

    const resultsArr = Array.isArray(deleteResponse?.results) ? deleteResponse.results : [];
    const failedItems = resultsArr.flatMap((r) => (Array.isArray(r.files_failed) ? r.files_failed : []));
    const errorDetails: ApiErrorItemDetail[] = [
        ...(Array.isArray(deleteResponse?.error_details) ? deleteResponse.error_details : []),
        ...resultsArr.flatMap((r) => (Array.isArray(r.error_details) ? r.error_details : [])),
    ];

    if (deletedCount === 0 && (failedItems.length > 0 || errorDetails.length > 0)) {
        const firstErr = errorDetails[0];
        const firstMsg =
            firstErr && typeof firstErr === 'object'
                ? String(firstErr.error || firstErr.reason || firstErr.detail || '')
                : '';
        const errMessage =
            firstMsg ||
            deleteResponse?.message ||
            `Document update failed for: ${failedItems.join(', ') || 'selected items'}`;
        throw new ApiRequestError(errMessage, {
            title: 'Source Document Mutation Failed',
            operation: PRELIMINARY_RESEARCH_ACTIONS.delete,
            endpoint: PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
            message: errMessage,
            errorDetails: errorDetails.length > 0
                ? errorDetails
                : failedItems.map((name) => ({ title: name, error: 'Failed to update document' })),
            raw: deleteResponse,
        });
    }

    const serverAffectedSections = Array.isArray(deleteResponse?.affected_sections)
        ? deleteResponse.affected_sections
        : Array.isArray(deleteResponse?.results)
          ? Array.from(
                new Set(
                    deleteResponse.results.flatMap((result) =>
                        Array.isArray(result.affected_sections) ? result.affected_sections : []
                    )
                )
            )
          : [];

    const affectedSections =
        serverAffectedSections.length > 0
            ? serverAffectedSections
            : computeAffectedPreliminaryResearchSections(modifiedTypes);

    return {
        deletedCount,
        generated: true,
        affectedSections,
        ...(failedItems.length > 0 ? { failedItems } : {}),
        ...(errorDetails.length > 0 ? { errorDetails } : {}),
    };
};

/**
 * Trigger full or partial Preliminary Research regeneration via the RUN_ANALYTICS gateway action.
 */
export const triggerPreliminaryResearchGeneration = async (
    planId: string,
    sectionsToGenerate?: string[]
): Promise<unknown> => {
    const sections = Array.isArray(sectionsToGenerate) ? sectionsToGenerate.filter(Boolean) : [];
    const userDetails = buildUserDetailsForPlan(planId);
    const payload: Record<string, unknown> = {
        ...(sections.length > 0 ? { sections } : {}),
        ...(userDetails ? { userDetails } : {}),
    };

    if (typeof window !== 'undefined') {
        window.dispatchEvent(
            new CustomEvent('ai-chat:generate-preliminary-research', {
                detail: sections.length > 0 ? { payload: { sections } } : undefined,
            })
        );
    }

    return postJson<unknown>(PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions, {
        planNumber: planId,
        action: PRELIMINARY_RESEARCH_ACTIONS.runAnalytics,
        payload,
    });
};

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const extractNumericDocIds = (raw: unknown): number[] => {
    if (!Array.isArray(raw)) return [];
    return Array.from(
        new Set(
            raw
                .map((id) => Number(id))
                .filter((id) => Number.isFinite(id) && id > 0)
        )
    );
};

const extractCategorizedSpecs = (
    categorizeResp: unknown,
    fallbackDocType: 'auto' | 'policy' | 'kod' | 'procedure',
    docIds: number[]
): Array<{ document_type: string; document_ids: number[]; top_k: number }> => {
    const payload = extractGatewayPayload(categorizeResp, ['categorized_documents', 'categorized', 'categories']);
    const catRoot = toRecord(payload.categorized_documents) || payload;
    const buckets = toRecord(catRoot.categorized) || toRecord(catRoot.categories) || catRoot;
    const specs: Array<{ document_type: string; document_ids: number[]; top_k: number }> = [];

    for (const dtype of ['policy', 'kod', 'procedure'] as const) {
        const directIds = extractNumericDocIds(buckets[dtype] ?? buckets[`${dtype}_ids`]);
        if (directIds.length > 0) {
            specs.push({ document_type: dtype, document_ids: directIds, top_k: 5 });
        }
    }

    if (specs.length === 0 && docIds.length > 0) {
        const targetType = fallbackDocType === 'auto' ? 'policy' : fallbackDocType;
        specs.push({ document_type: targetType, document_ids: docIds, top_k: 5 });
    }
    return specs;
};

/**
 * Uploads policy, KOD, or procedure files into RAG (/qna/documents/ingest), polls job completion
 * via QNA_GET_INGEST_JOB_STATUS, categorizes document IDs, and persists relevant sections into plan context.
 */
export const ingestPreliminaryResearchDocument = async (
    planNumber: string,
    files: File[],
    documentType: 'auto' | 'policy' | 'kod' | 'procedure' = 'auto',
    options: IngestPreliminaryResearchDocumentOptions = {}
): Promise<IngestPreliminaryResearchDocumentResponse> => {
    if (!planNumber || !String(planNumber).trim()) {
        throw new Error('Plan number is required for document upload.');
    }
    if (!Array.isArray(files) || files.length === 0) {
        throw new Error('Please choose at least one file to upload.');
    }

    const userDetails = buildUserDetailsForPlan(planNumber);
    const fieldName =
        documentType === 'policy'
            ? 'policy_files'
            : documentType === 'kod'
              ? 'kod_files'
              : documentType === 'procedure'
                ? 'procedure_files'
                : 'files';

    const formFields: Record<string, string | Blob | Array<string | Blob>> = {
        plan_number: String(planNumber).trim(),
        document_type: documentType === 'auto' ? 'policy' : documentType,
        [fieldName]: files,
    };
    if (userDetails?.review_scope_id) formFields.review_scope_id = userDetails.review_scope_id;
    if (userDetails?.process_instance_id) formFields.process_instance_id = userDetails.process_instance_id;
    if (userDetails?.task_id) formFields.task_id = userDetails.task_id;
    if (userDetails?.review_scope_stage) formFields.review_scope_stage = userDetails.review_scope_stage;
    if (userDetails) formFields.user_details = JSON.stringify(userDetails);

    const ingestRaw = await postFormData<unknown>(PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.ingest, formFields);
    const ingestPayload = extractGatewayPayload(ingestRaw, ['status', 'job_id', 'document_ids', 'message']);
    const ingestStatus = String(ingestPayload.status || 'accepted').toLowerCase();
    if (ingestStatus === 'error' || ingestStatus === 'failed') {
        throw new ApiRequestError(
            String(ingestPayload.message || 'RAG document ingestion failed.'),
            {
                title: 'Document Upload Failed',
                operation: 'QNA_INGEST_DOCUMENTS',
                endpoint: PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.ingest,
                message: String(ingestPayload.message || 'RAG document ingestion failed.'),
                raw: ingestPayload,
            }
        );
    }

    let documentIds = extractNumericDocIds(ingestPayload.document_ids);
    const jobId = typeof ingestPayload.job_id === 'string' && ingestPayload.job_id.trim() ? ingestPayload.job_id.trim() : undefined;

    if (documentIds.length === 0 && jobId) {
        const pollIntervalMs = options.pollIntervalMs ?? 2500;
        const maxPolls = options.maxPolls ?? 120;
        const terminalSuccess = new Set(['complete', 'completed', 'done', 'success', 'succeeded']);
        const terminalFailure = new Set(['failed', 'error', 'cancelled', 'canceled']);

        for (let attempt = 0; attempt < maxPolls; attempt++) {
            if (attempt > 0 && pollIntervalMs > 0) {
                await sleep(pollIntervalMs);
            }
            const jobRaw = await postJson<unknown>(PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions, {
                planNumber,
                action: PRELIMINARY_RESEARCH_ACTIONS.ingestJobStatus,
                payload: { job_id: jobId },
            });
            const jobPayload = extractGatewayPayload(jobRaw, ['status', 'document_ids', 'job_id']);
            const jobStatus = String(jobPayload.status || '').toLowerCase();
            if (terminalFailure.has(jobStatus)) {
                throw new ApiRequestError(
                    String(jobPayload.message || `RAG ingest job ${jobId} failed.`),
                    {
                        title: 'RAG Ingestion Job Failed',
                        operation: PRELIMINARY_RESEARCH_ACTIONS.ingestJobStatus,
                        endpoint: PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
                        message: String(jobPayload.message || `RAG ingest job ${jobId} failed.`),
                        raw: jobPayload,
                    }
                );
            }
            const polledIds = extractNumericDocIds(jobPayload.document_ids);
            if (terminalSuccess.has(jobStatus) || polledIds.length > 0) {
                documentIds = polledIds;
                break;
            }
        }
    }

    if (documentIds.length === 0) {
        throw new ApiRequestError(
            'Document upload completed without producing any indexed document IDs.',
            {
                title: 'Document Upload Incomplete',
                operation: 'QNA_INGEST_DOCUMENTS',
                endpoint: PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.ingest,
                message: 'No document_ids returned after ingestion.',
                raw: ingestPayload,
            }
        );
    }

    let docSpecs: Array<{ document_type: string; document_ids: number[]; top_k: number }>;
    if (documentType === 'auto') {
        const catRaw = await postJson<unknown>(PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions, {
            planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.categorizeDocuments,
            payload: { plan_number: planNumber, document_ids: documentIds },
        });
        docSpecs = extractCategorizedSpecs(catRaw, documentType, documentIds);
    } else {
        docSpecs = [{ document_type: documentType, document_ids: documentIds, top_k: 5 }];
    }

    const relevantRaw = await postJson<unknown>(PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions, {
        planNumber,
        action: PRELIMINARY_RESEARCH_ACTIONS.getRelevantData,
        payload: {
            plan_number: planNumber,
            documents: docSpecs,
            persist_to_context: true,
            ...(userDetails ? { userDetails } : {}),
        },
    });
    const relevantPayload = extractGatewayPayload(relevantRaw, ['persisted_files', 'registry_updated', 'status', 'message']);
    if (String(relevantPayload.status || '').toLowerCase() === 'error') {
        throw new ApiRequestError(
            String(relevantPayload.message || 'Failed to persist uploaded document data to plan context.'),
            {
                title: 'Context Persistence Failed',
                operation: PRELIMINARY_RESEARCH_ACTIONS.getRelevantData,
                endpoint: PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
                message: String(relevantPayload.message || 'Failed to persist uploaded document data to plan context.'),
                raw: relevantPayload,
            }
        );
    }

    const persistedFiles = Array.isArray(relevantPayload.persisted_files)
        ? relevantPayload.persisted_files.map((p: unknown) => String(p))
        : [];
    return {
        status: String(relevantPayload.status || 'success'),
        jobId,
        documentIds,
        persistedFiles,
        registryUpdated: Boolean(relevantPayload.registry_updated),
        affectedSections: ['policy_regulation', 'broad_scope'],
        message: String(relevantPayload.message || 'Document uploaded and persisted into plan context.'),
    };
};
