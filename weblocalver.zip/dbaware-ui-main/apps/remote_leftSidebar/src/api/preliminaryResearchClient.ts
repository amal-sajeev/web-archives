import { postJson } from './sharedApi';

export type PreliminaryResearchDocumentType =
    | 'Policies'
    | 'KOD'
    | 'Procedure Documents'
    | 'GFMS Data'
    | 'Historical Scoping Documents';

export const ALL_PRELIMINARY_RESEARCH_DOCUMENT_TYPES: PreliminaryResearchDocumentType[] = [
    'Policies',
    'KOD',
    'Procedure Documents',
    'GFMS Data',
    'Historical Scoping Documents',
];

export interface PreliminaryResearchSectionRecord {
    section_id: string | number;
    section_title?: string;
    node_id?: string;
    status?: 'active' | 'inactive' | 'excluded';
    excluded?: boolean;
}

export interface PreliminaryResearchDocumentItem {
    id: string;
    title: string;
    type: PreliminaryResearchDocumentType;
    fileName?: string;
    documentTitle?: string;
    documentId?: string;
    storageUri?: string;
    status?: 'active' | 'inactive' | 'excluded';
    excluded?: boolean;
    sections?: PreliminaryResearchSectionRecord[];
}

export interface PreliminaryResearchDocumentsResponse {
    documentsByType: Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>;
}

export interface RegeneratePreliminaryResearchRequest {
    planNumber: string;
    exclusions: Partial<Record<PreliminaryResearchDocumentType, string[]>>;
    mode?: 'exclude' | 'include';
    sectionExclusions?: Partial<
        Record<PreliminaryResearchDocumentType, Record<string, Array<string | number>>>
    >;
}

export interface RegeneratePreliminaryResearchResponse {
    deletedCount: number;
    generated: boolean;
    affectedSections?: string[];
}

interface ListAllDocumentsRequest {
    plan_number: string;
}

interface ListAllDocument {
    file_name?: string;
    document_title?: string;
    document_id?: string;
    storage_uri?: string;
    status?: 'active' | 'inactive' | 'excluded';
    excluded?: boolean;
    sections?: PreliminaryResearchSectionRecord[];
}

interface ListAllDocumentGroup {
    document_type?: string;
    documents?: ListAllDocument[];
}

interface ListAllDocumentsResponse {
    document_groups?: ListAllDocumentGroup[];
}

interface DeleteDocumentsItem {
    file_name: string;
    document_title: string;
    document_id: string;
    section_id?: string | number;
    section_title?: string;
    node_id?: string;
    action?: 'exclude' | 'include';
    sections?: PreliminaryResearchSectionRecord[];
}

interface DeleteDocumentsGroup {
    document_type: string;
    items: DeleteDocumentsItem[];
}

interface DeleteDocumentsRequest {
    documents: DeleteDocumentsGroup[];
}

interface DeleteDocumentsResult {
    total_deleted?: number;
    affected_sections?: string[];
}

interface DeleteDocumentsResponse {
    total_deleted?: number;
    results?: DeleteDocumentsResult[];
    affected_sections?: string[];
}

export const PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS = {
    actions: '/dbaware-api-gateway/api/v1/actions',
};

const PRELIMINARY_RESEARCH_ACTIONS = {
    list: 'QNA_LIST_DOCUMENTS',
    delete: 'QNA_DELETE_DOCUMENTS',
    runAnalytics: 'RUN_ANALYTICS',
} as const;

const CANONICAL_SECTION_ORDER = [
    'historical_plan',
    'findings_analysis',
    'policy_regulation',
    'broad_scope',
] as const;

const TYPE_TO_AFFECTED_SECTIONS: Record<PreliminaryResearchDocumentType, string[]> = {
    Policies: ['policy_regulation', 'broad_scope'],
    KOD: ['policy_regulation', 'broad_scope'],
    'Procedure Documents': ['policy_regulation', 'broad_scope'],
    'GFMS Data': ['findings_analysis', 'broad_scope'],
    'Historical Scoping Documents': ['historical_plan', 'broad_scope'],
};

export const createEmptyPreliminaryResearchDocumentsByType = (): Record<
    PreliminaryResearchDocumentType,
    PreliminaryResearchDocumentItem[]
> => ({
    Policies: [],
    KOD: [],
    'Procedure Documents': [],
    'GFMS Data': [],
    'Historical Scoping Documents': [],
});

export const EMPTY_PRELIMINARY_RESEARCH_DOCUMENTS_BY_TYPE: Record<
    PreliminaryResearchDocumentType,
    PreliminaryResearchDocumentItem[]
> = createEmptyPreliminaryResearchDocumentsByType();

export const computeAffectedPreliminaryResearchSections = (
    types: PreliminaryResearchDocumentType[]
): string[] => {
    const affected = new Set<string>();
    types.forEach((type) => {
        (TYPE_TO_AFFECTED_SECTIONS[type] || []).forEach((sec) => affected.add(sec));
    });
    return CANONICAL_SECTION_ORDER.filter((sec) => affected.has(sec));
};

const toRecord = (value: unknown): Record<string, any> | null => {
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
        return value as Record<string, any>;
    }
    return null;
};

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const extractGatewayPayload = (response: unknown, hints: string[]): Record<string, any> => {
    const preferred = unwrapGatewayEnvelope(response);
    const queue: unknown[] = preferred === response ? [response] : [preferred, response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        const record = toRecord(current);

        if (!record || visited.has(record)) {
            continue;
        }

        visited.add(record);

        if (hints.some((hint) => hint in record)) {
            return record;
        }

        if ('payload' in record) queue.push(record.payload);
        if ('data' in record) queue.push(record.data);
        if ('result' in record) queue.push(record.result);
        if ('response' in record) queue.push(record.response);
    }

    return toRecord(response) ?? {};
};

const lastFetchedDocumentsByPlan: Record<
    string,
    Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>
> = {};

const toUiDocumentType = (documentType?: string): PreliminaryResearchDocumentType | null => {
    const normalized = (documentType || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
    if (normalized === 'policy' || normalized === 'policies' || normalized === 'policy_policy') {
        return 'Policies';
    }
    if (normalized === 'kod' || normalized === 'policy_kod') {
        return 'KOD';
    }
    if (
        normalized === 'procedure' ||
        normalized === 'procedures' ||
        normalized === 'procedure_documents' ||
        normalized === 'policy_procedure'
    ) {
        return 'Procedure Documents';
    }
    if (normalized === 'gfms' || normalized === 'gfms_data') {
        return 'GFMS Data';
    }
    if (
        normalized === 'historical_scoping_document' ||
        normalized === 'historical_scoping_documents' ||
        normalized === 'historical_plan' ||
        normalized === 'historical'
    ) {
        return 'Historical Scoping Documents';
    }
    return null;
};

const toApiDocumentType = (documentType: PreliminaryResearchDocumentType): string => {
    if (documentType === 'Policies') return 'policy';
    if (documentType === 'KOD') return 'kod';
    if (documentType === 'Procedure Documents') return 'procedure';
    if (documentType === 'GFMS Data') return 'gfms';
    return 'historical_scoping_document';
};

const normalizeSections = (rawSections: unknown): PreliminaryResearchSectionRecord[] => {
    if (!Array.isArray(rawSections)) return [];
    return rawSections
        .filter((sec): sec is Record<string, any> => sec !== null && typeof sec === 'object')
        .map((sec, idx) => ({
            section_id: sec.section_id ?? sec.id ?? idx + 1,
            section_title: sec.section_title ?? sec.title,
            node_id: sec.node_id,
            status: sec.status ?? (sec.excluded ? 'excluded' : 'active'),
            excluded: Boolean(sec.excluded) || String(sec.status || '').toLowerCase() === 'excluded' || String(sec.status || '').toLowerCase() === 'inactive',
        }));
};

/**
 * Fetch source documents (Policies, KOD, Procedures, GFMS Data, Historical Scoping Documents) for Preliminary Research.
 */
export const fetchPreliminaryResearchSourceDocuments = async (
    planNumber: string
): Promise<PreliminaryResearchDocumentsResponse> => {
    const request: ListAllDocumentsRequest = { plan_number: planNumber };
    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.list,
            payload: request,
        }
    );
    const payload = extractGatewayPayload(response, ['document_groups']);
    const listResponse = payload as ListAllDocumentsResponse;

    const documentsByType = createEmptyPreliminaryResearchDocumentsByType();

    const groups = Array.isArray(listResponse?.document_groups) ? listResponse.document_groups : [];
    groups.forEach((group) => {
        const uiType = toUiDocumentType(group?.document_type);
        if (!uiType) return;

        const docs = Array.isArray(group?.documents) ? group.documents : [];
        documentsByType[uiType] = docs.map((doc, index) => {
            const id = doc.document_id || doc.file_name || `${uiType}-${index}`;
            const title = doc.document_title || doc.file_name || id;
            const excluded =
                Boolean(doc.excluded) ||
                String(doc.status || '').toLowerCase() === 'excluded' ||
                String(doc.status || '').toLowerCase() === 'inactive';

            return {
                id,
                title,
                type: uiType,
                fileName: doc.file_name,
                documentTitle: doc.document_title,
                documentId: doc.document_id,
                storageUri: doc.storage_uri,
                status: doc.status ?? (excluded ? 'excluded' : 'active'),
                excluded,
                sections: normalizeSections(doc.sections),
            };
        });
    });

    lastFetchedDocumentsByPlan[planNumber] = documentsByType;

    return {
        documentsByType,
    };
};

/**
 * Soft-exclude or restore selected source documents or sections, then return affected Preliminary Research sections.
 */
export const regeneratePreliminaryResearchWithExclusions = async (
    request: RegeneratePreliminaryResearchRequest
): Promise<RegeneratePreliminaryResearchResponse> => {
    const cachedByType =
        lastFetchedDocumentsByPlan[request.planNumber] || createEmptyPreliminaryResearchDocumentsByType();
    const actionMode: 'exclude' | 'include' = request.mode === 'include' ? 'include' : 'exclude';
    const modifiedTypes: PreliminaryResearchDocumentType[] = [];

    const candidateTypes = Array.from(
        new Set<PreliminaryResearchDocumentType>([
            ...(Object.keys(request.exclusions || {}) as PreliminaryResearchDocumentType[]),
            ...(Object.keys(request.sectionExclusions || {}) as PreliminaryResearchDocumentType[]),
        ])
    );

    const documents: DeleteDocumentsGroup[] = candidateTypes
        .map((type) => {
            const selectedDocIds = request.exclusions?.[type] || [];
            const sectionSelectionsByDoc = request.sectionExclusions?.[type] || {};
            const hasSectionSelections = Object.values(sectionSelectionsByDoc).some(
                (ids) => Array.isArray(ids) && ids.length > 0
            );

            if (selectedDocIds.length === 0 && !hasSectionSelections) {
                return null;
            }

            const available = cachedByType[type] || [];
            const availableById = new Map(available.map((item) => [item.id, item]));
            const items: DeleteDocumentsItem[] = [];
            const wholeDocIdSet = new Set(selectedDocIds);

            selectedDocIds.forEach((docId) => {
                const item = availableById.get(docId);
                items.push({
                    file_name: item?.fileName || docId,
                    document_title: item?.documentTitle || item?.title || docId,
                    document_id: item?.documentId || docId,
                    action: actionMode,
                });
            });

            Object.entries(sectionSelectionsByDoc).forEach(([docId, rawSectionIds]) => {
                if (wholeDocIdSet.has(docId) || !Array.isArray(rawSectionIds) || rawSectionIds.length === 0) {
                    return;
                }
                const item = availableById.get(docId);
                const selectedSectionIdStrs = new Set(rawSectionIds.map((sid) => String(sid)));
                const matchedSections: PreliminaryResearchSectionRecord[] = (item?.sections || []).filter((sec) =>
                    selectedSectionIdStrs.has(String(sec.section_id))
                );
                const normalizedTargets: PreliminaryResearchSectionRecord[] =
                    matchedSections.length > 0
                        ? matchedSections
                        : rawSectionIds.map((sid) => ({ section_id: sid }));

                if (normalizedTargets.length === 1) {
                    const sec = normalizedTargets[0];
                    items.push({
                        file_name: item?.fileName || docId,
                        document_title: item?.documentTitle || item?.title || docId,
                        document_id: item?.documentId || docId,
                        section_id: sec.section_id,
                        section_title: sec.section_title,
                        node_id: sec.node_id,
                        action: actionMode,
                    });
                } else {
                    items.push({
                        file_name: item?.fileName || docId,
                        document_title: item?.documentTitle || item?.title || docId,
                        document_id: item?.documentId || docId,
                        action: actionMode,
                        sections: normalizedTargets,
                    });
                }
            });

            if (items.length === 0) {
                return null;
            }

            modifiedTypes.push(type);
            return {
                document_type: toApiDocumentType(type),
                items,
            };
        })
        .filter((group): group is DeleteDocumentsGroup => !!group && group.items.length > 0);

    const payload: DeleteDocumentsRequest = {
        documents,
    };

    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber: request.planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.delete,
            payload,
        }
    );
    const resultPayload = extractGatewayPayload(response, ['total_deleted', 'results', 'affected_sections']);
    const deleteResponse = resultPayload as DeleteDocumentsResponse;

    const deletedCount =
        typeof deleteResponse?.total_deleted === 'number'
            ? deleteResponse.total_deleted
            : Array.isArray(deleteResponse?.results)
              ? deleteResponse.results.reduce((sum, result) => sum + (result.total_deleted || 0), 0)
              : 0;

    const serverAffectedSections = Array.isArray(deleteResponse?.affected_sections)
        ? deleteResponse.affected_sections
        : Array.isArray(deleteResponse?.results)
          ? Array.from(
                new Set(
                    deleteResponse.results.flatMap((result) =>
                        Array.isArray(result.affected_sections) ? result.affected_sections : []
                    )
                )
            )
          : [];

    const affectedSections =
        serverAffectedSections.length > 0
            ? serverAffectedSections
            : computeAffectedPreliminaryResearchSections(modifiedTypes);

    return {
        deletedCount,
        generated: true,
        affectedSections,
    };
};

/**
 * Trigger full or partial Preliminary Research regeneration via the RUN_ANALYTICS gateway action.
 */
export const triggerPreliminaryResearchGeneration = async (
    planId: string,
    sectionsToGenerate?: string[]
): Promise<unknown> => {
    const sections = Array.isArray(sectionsToGenerate) ? sectionsToGenerate.filter(Boolean) : [];
    const payload = sections.length > 0 ? { sections } : {};

    if (typeof window !== 'undefined') {
        window.dispatchEvent(
            new CustomEvent('ai-chat:generate-preliminary-research', {
                detail: sections.length > 0 ? { payload: { sections } } : undefined,
            })
        );
    }

    return postJson<unknown>(PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions, {
        planNumber: planId,
        action: PRELIMINARY_RESEARCH_ACTIONS.runAnalytics,
        payload,
    });
};
