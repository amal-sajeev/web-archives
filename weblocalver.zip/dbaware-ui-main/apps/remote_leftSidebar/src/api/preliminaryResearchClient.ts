import { getSharedApiClient, postJson } from './sharedApi';
import { buildUserDetailsForPlan } from './scopeContext';

export type PreliminaryResearchDocumentType = 'Policies' | 'KOD' | 'Procedure Documents';

export interface PreliminaryResearchDocumentItem {
    id: string;
    title: string;
    type: PreliminaryResearchDocumentType;
    fileName?: string;
    documentTitle?: string;
    documentId?: string;
}

export interface PreliminaryResearchDocumentsResponse {
    documentsByType: Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>;
}

export interface RegeneratePreliminaryResearchRequest {
    planNumber: string;
    exclusions: Record<PreliminaryResearchDocumentType, string[]>;
    sections?: string[];
    userDetails?: Record<string, unknown>;
}

export interface RegeneratePreliminaryResearchResponse {
    deletedCount: number;
    generated: boolean;
}

export interface HistoricalPlanItem {
    planItemNumber: number;
    planItemTitle: string;
}

interface ListAllDocumentsRequest {
    plan_number: string;
}

interface ListAllDocument {
    file_name?: string;
    document_title?: string;
    document_id?: string;
    status?: string;
    excluded?: boolean;
    sections?: Array<{
        section_id?: string | number;
        section_title?: string;
        node_id?: string;
        status?: string;
        excluded?: boolean;
    }>;
}

interface ListAllDocumentGroup {
    document_type?: string;
    documents?: ListAllDocument[];
}

interface ListAllDocumentsResponse {
    document_groups?: ListAllDocumentGroup[];
}

interface PermissionStatusResponse {
    processInstanceId?: string;
    process_instance_id?: string;
    review_scope_instance_id?: number;
    reviewScopeInstanceId?: number;
    review_scope_id?: number;
    reviewScopeId?: number;
    task_id?: string;
    taskId?: string;
    task_definition_key?: string;
    taskDefinitionKey?: string;
    variables?: Record<string, unknown>;
}

export interface PreliminaryResearchSectionNode {
    id: string;
    title: string;
    sectionId?: string | number;
    nodeId?: string;
    status?: string;
    excluded?: boolean;
}

export interface PreliminaryResearchDocumentNode {
    id: string;
    title: string;
    fileName?: string;
    documentType: string;
    status?: string;
    excluded?: boolean;
    sections: PreliminaryResearchSectionNode[];
}

export interface PreliminaryResearchDocumentGroupNode {
    documentType: string;
    documents: PreliminaryResearchDocumentNode[];
}

interface DeleteDocumentsItem {
    file_name: string;
    document_title: string;
    document_id: string;
}

interface DeleteDocumentsGroup {
    document_type: string;
    items: DeleteDocumentsItem[];
}

interface DeleteDocumentsRequest {
    documents: DeleteDocumentsGroup[];
    user_details?: Record<string, unknown>;
}

interface DeleteDocumentsResult {
    total_deleted?: number;
}

interface DeleteDocumentsResponse {
    total_deleted?: number;
    results?: DeleteDocumentsResult[];
}

interface ListHistoricalDocumentsResponse {
    plan_items?: Array<{
        plan_item_number?: number;
        plan_item_title?: string;
    }>;
    data?: Array<{
        plan_item_number?: number;
        plan_item_title?: string;
    }>;
}

interface DeleteHistoricalDocumentsRequest {
    plan_items: Array<{
        plan_item_number: number;
        plan_item_title: string;
    }>;
}

export const PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS = {
    actions: '/dbaware-api-gateway/api/v1/actions',
};

const PRELIMINARY_RESEARCH_ACTIONS = {
    list: 'QNA_LIST_DOCUMENTS',
    delete: 'QNA_DELETE_DOCUMENTS',
    listHistorical: 'LIST_HISTORICAL_DOCUMENT',
    deleteHistorical: 'DELETE_HISTORICAL_DOCUMENT',
} as const;

const getJson = async <T>(url: string): Promise<T> => {
    const client = getSharedApiClient();
    if (client) {
        return client.get<T>(url, {
            timeout: 600000,
        });
    }

    const response = await fetch(url, {
        method: 'GET',
    });

    if (!response.ok) {
        throw new Error(`GET ${url} failed: ${response.status} ${response.statusText}`);
    }

    return response.json() as Promise<T>;
};

const toFiniteNumber = (value: unknown): number | undefined => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string' && value.trim().length > 0) {
        const parsed = Number(value);
        if (Number.isFinite(parsed)) return parsed;
    }
    return undefined;
};

const toNonEmptyString = (value: unknown): string | undefined => {
    if (typeof value === 'number' && Number.isFinite(value)) {
        return String(value);
    }
    if (typeof value !== 'string') return undefined;
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : undefined;
};

type ExtractedUserDetails = {
    review_scope_instance_id?: number;
    review_scope_id?: number;
    process_instance_id?: string;
    task_id?: string;
    review_scope_stage?: string;
    user?: string;
};

const resolveUserDetailsFromStatusAndContext = (
    status: PermissionStatusResponse,
    planNumber?: string
): ExtractedUserDetails => {
    const variables = toRecord(status.variables) ?? {};
    const nestedUserDetails = toRecord(variables.user_details) ?? toRecord(variables.userDetails) ?? {};
    const storedDetails = planNumber ? (buildUserDetailsForPlan(planNumber) ?? {}) : {};

    const reviewScope =
        toFiniteNumber(status.review_scope_instance_id)
        ?? toFiniteNumber(status.reviewScopeInstanceId)
        ?? toFiniteNumber(status.review_scope_id)
        ?? toFiniteNumber(status.reviewScopeId)
        ?? toFiniteNumber(variables.review_scope_instance_id)
        ?? toFiniteNumber(variables.reviewScopeInstanceId)
        ?? toFiniteNumber(variables.review_scope_id)
        ?? toFiniteNumber(variables.reviewScopeId)
        ?? toFiniteNumber(variables.p_REVIEW_SCOPE_ID)
        ?? toFiniteNumber(variables.p_review_scope_id)
        ?? toFiniteNumber(variables.p_review_scope_instance_id)
        ?? toFiniteNumber(variables.p_reviewScopeId)
        ?? toFiniteNumber(variables.p_reviewScopeInstanceId)
        ?? toFiniteNumber(nestedUserDetails.review_scope_instance_id)
        ?? toFiniteNumber(nestedUserDetails.reviewScopeInstanceId)
        ?? toFiniteNumber(nestedUserDetails.review_scope_id)
        ?? toFiniteNumber(nestedUserDetails.reviewScopeId)
        ?? toFiniteNumber(storedDetails.review_scope_id);

    const processInstance =
        toNonEmptyString(status.process_instance_id)
        ?? toNonEmptyString(status.processInstanceId)
        ?? toNonEmptyString(variables.process_instance_id)
        ?? toNonEmptyString(variables.processInstanceId)
        ?? toNonEmptyString(variables.p_process_instance_id)
        ?? toNonEmptyString(variables.p_processInstanceId)
        ?? toNonEmptyString(storedDetails.process_instance_id);

    const taskId =
        toNonEmptyString(status.task_id)
        ?? toNonEmptyString(status.taskId)
        ?? toNonEmptyString(variables.task_id)
        ?? toNonEmptyString(variables.taskId)
        ?? toNonEmptyString(storedDetails.task_id);

    const stage =
        toNonEmptyString(status.task_definition_key)
        ?? toNonEmptyString(status.taskDefinitionKey)
        ?? toNonEmptyString(variables.task_definition_key)
        ?? toNonEmptyString(variables.review_scope_stage)
        ?? toNonEmptyString(storedDetails.review_scope_stage);

    const user =
        toNonEmptyString(nestedUserDetails.user)
        ?? toNonEmptyString(storedDetails.user);

    const details: ExtractedUserDetails = {};
    if (typeof reviewScope === 'number') {
        details.review_scope_instance_id = reviewScope;
        details.review_scope_id = reviewScope;
    } else if (storedDetails.review_scope_id) {
        (details as Record<string, unknown>).review_scope_id = storedDetails.review_scope_id;
        (details as Record<string, unknown>).review_scope_instance_id = storedDetails.review_scope_id;
    }
    if (processInstance) {
        details.process_instance_id = processInstance;
    }
    if (taskId) {
        details.task_id = taskId;
    }
    if (stage) {
        details.review_scope_stage = stage;
    }
    if (user) {
        details.user = user;
    }
    return details;
};

const fetchResolvedUserDetailsForPlan = async (planNumber: string): Promise<ExtractedUserDetails> => {
    let permissionStatus: PermissionStatusResponse = {};
    try {
        permissionStatus = (await getJson<PermissionStatusResponse>(`/dbaware-api-gateway/api/v1/task/status/${planNumber}`)) || {};
    } catch {
        permissionStatus = {};
    }
    return resolveUserDetailsFromStatusAndContext(permissionStatus, planNumber);
};

const fetchQnaListDocumentsPayload = async (planNumber: string): Promise<ListAllDocumentsResponse> => {
    const userDetails = await fetchResolvedUserDetailsForPlan(planNumber);
    const payload = Object.keys(userDetails).length > 0
        ? { user_details: userDetails }
        : {};

    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.list,
            payload,
        }
    );

    const extracted = extractGatewayPayload(response, ['document_groups']);
    return extracted as ListAllDocumentsResponse;
};

const toRecord = (value: unknown): Record<string, any> | null => {
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
        return value as Record<string, any>;
    }
    return null;
};

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const extractGatewayPayload = (response: unknown, hints: string[]): Record<string, any> => {
    const preferred = unwrapGatewayEnvelope(response);
    const queue: unknown[] = preferred === response ? [response] : [preferred, response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        const record = toRecord(current);

        if (!record || visited.has(record)) {
            continue;
        }

        visited.add(record);

        if (hints.some((hint) => hint in record)) {
            return record;
        }

        if ('payload' in record) queue.push(record.payload);
        if ('data' in record) queue.push(record.data);
        if ('result' in record) queue.push(record.result);
        if ('response' in record) queue.push(record.response);
    }

    return toRecord(response) ?? {};
};

const lastFetchedDocumentsByPlan: Record<string, Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]>> = {};

const EMPTY_DOCUMENTS: Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]> = {
    Policies: [],
    KOD: [],
    'Procedure Documents': [],
};

const toUiDocumentType = (documentType?: string): PreliminaryResearchDocumentType | null => {
    const normalized = (documentType || '').trim().toLowerCase();
    if (normalized === 'policy' || normalized === 'policies') return 'Policies';
    if (normalized === 'kod') return 'KOD';
    if (normalized === 'procedure' || normalized === 'procedures') return 'Procedure Documents';
    return null;
};

const toApiDocumentType = (documentType: PreliminaryResearchDocumentType): string => {
    if (documentType === 'Policies') return 'policy';
    if (documentType === 'KOD') return 'kod';
    return 'procedure';
};

/**
 * Fetch excludable source documents for Preliminary Research.
 */
export const fetchPreliminaryResearchSourceDocuments = async (
    planNumber: string
): Promise<PreliminaryResearchDocumentsResponse> => {
    const listResponse = await fetchQnaListDocumentsPayload(planNumber);

    const documentsByType: Record<PreliminaryResearchDocumentType, PreliminaryResearchDocumentItem[]> = {
        ...EMPTY_DOCUMENTS,
    };

    const groups = Array.isArray(listResponse?.document_groups) ? listResponse.document_groups : [];
    groups.forEach((group) => {
        const uiType = toUiDocumentType(group?.document_type);
        if (!uiType) return;

        const docs = Array.isArray(group?.documents) ? group.documents : [];
        documentsByType[uiType] = docs.map((doc, index) => {
            const id = doc.document_id || doc.file_name || `${uiType}-${index}`;
            const title = doc.document_title || doc.file_name || id;

            return {
                id,
                title,
                type: uiType,
                fileName: doc.file_name,
                documentTitle: doc.document_title,
                documentId: doc.document_id,
            };
        });
    });

    lastFetchedDocumentsByPlan[planNumber] = documentsByType;

    return {
        documentsByType,
    };
};

/**
 * Delete selected source documents, then allow Preliminary Research regeneration flow to continue.
 */
export const regeneratePreliminaryResearchWithExclusions = async (
    request: RegeneratePreliminaryResearchRequest
): Promise<RegeneratePreliminaryResearchResponse> => {
    const cachedByType = lastFetchedDocumentsByPlan[request.planNumber] || EMPTY_DOCUMENTS;

    const documents: DeleteDocumentsGroup[] = (Object.keys(request.exclusions) as PreliminaryResearchDocumentType[])
        .map((type) => {
            const selectedIds = request.exclusions[type] || [];
            if (selectedIds.length === 0) return null;

            const available = cachedByType[type] || [];
            const selectedItems = available.filter(item => selectedIds.includes(item.id));

            const items: DeleteDocumentsItem[] = selectedItems.map((item) => ({
                file_name: item.fileName || item.id,
                document_title: item.documentTitle || item.title || item.id,
                document_id: item.documentId || item.id,
            }));

            return {
                document_type: toApiDocumentType(type),
                items,
            };
        })
        .filter((group): group is DeleteDocumentsGroup => !!group && group.items.length > 0);

    const resolvedUserDetails = request.userDetails && Object.keys(request.userDetails).length > 0
        ? request.userDetails
        : await fetchResolvedUserDetailsForPlan(request.planNumber);

    const payload: DeleteDocumentsRequest = {
        documents,
        ...(Object.keys(resolvedUserDetails).length > 0 ? { user_details: resolvedUserDetails } : {}),
    };

    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber: request.planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.delete,
            payload,
        }
    );
    const resultPayload = extractGatewayPayload(response, ['total_deleted', 'results']);
    const deleteResponse = resultPayload as DeleteDocumentsResponse;

    const deletedCount = typeof deleteResponse?.total_deleted === 'number'
        ? deleteResponse.total_deleted
        : Array.isArray(deleteResponse?.results)
            ? deleteResponse.results.reduce((sum, result) => sum + (result.total_deleted || 0), 0)
            : 0;

    return {
        deletedCount,
        generated: true,
    };
};

export const fetchHistoricalPreliminaryResearchSourceDocuments = async (
    planNumber: string
): Promise<HistoricalPlanItem[]> => {
    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.listHistorical,
            payload: {},
        }
    );

    const payload = extractGatewayPayload(response, ['plan_items', 'data']);
    const listResponse = payload as ListHistoricalDocumentsResponse;
    const planItems = Array.isArray(listResponse?.plan_items)
        ? listResponse.plan_items
        : Array.isArray(listResponse?.data)
            ? listResponse.data
            : [];

    return planItems
        .map((item) => ({
            planItemNumber: Number(item?.plan_item_number),
            planItemTitle: String(item?.plan_item_title || '').trim(),
        }))
        .filter((item) => Number.isFinite(item.planItemNumber) && item.planItemNumber > 0 && item.planItemTitle.length > 0);
};

export const deleteHistoricalPreliminaryResearchSourceDocuments = async (
    planNumber: string,
    planItems: HistoricalPlanItem[]
): Promise<{ deletedCount: number }> => {
    const payload: DeleteHistoricalDocumentsRequest = {
        plan_items: planItems.map((item) => ({
            plan_item_number: item.planItemNumber,
            plan_item_title: item.planItemTitle,
        })),
    };

    const response = await postJson<unknown>(
        PRELIMINARY_RESEARCH_DOCUMENTS_API_PATHS.actions,
        {
            planNumber,
            action: PRELIMINARY_RESEARCH_ACTIONS.deleteHistorical,
            payload,
        }
    );

    const resultPayload = extractGatewayPayload(response, ['total_deleted', 'deleted_count', 'remaining_count']);
    const result = (toRecord(resultPayload) ?? {}) as Record<string, unknown>;
    const deletedCount = typeof result.total_deleted === 'number'
        ? Number(result.total_deleted)
        : typeof result.deleted_count === 'number'
            ? Number(result.deleted_count)
            : payload.plan_items.length;

    return {
        deletedCount,
    };
};

export const fetchPreliminaryResearchDocumentGroups = async (
    planNumber: string
): Promise<PreliminaryResearchDocumentGroupNode[]> => {
    const listResponse = await fetchQnaListDocumentsPayload(planNumber);
    const groups = Array.isArray(listResponse?.document_groups) ? listResponse.document_groups : [];

    return groups.map((group) => {
        const documentType = String(group?.document_type || '').trim();
        const documents = (Array.isArray(group?.documents) ? group.documents : []).map((doc, index) => {
            const documentId = String(doc?.document_id || doc?.file_name || `${documentType}-${index}`);
            const title = String(doc?.document_title || doc?.file_name || documentId);
            const sections = (Array.isArray(doc?.sections) ? doc.sections : []).map((section, sectionIndex) => {
                const nodeId = section?.node_id;
                const sectionId = section?.section_id;
                const sectionTitle = String(section?.section_title || section?.section_id || `Section ${sectionIndex + 1}`);
                const id = String(nodeId || `${documentId}-section-${sectionId ?? sectionIndex}`);

                return {
                    id,
                    title: sectionTitle,
                    sectionId,
                    nodeId,
                    status: section?.status,
                    excluded: section?.excluded,
                } satisfies PreliminaryResearchSectionNode;
            });

            return {
                id: documentId,
                title,
                fileName: doc?.file_name,
                documentType,
                status: doc?.status,
                excluded: doc?.excluded,
                sections,
            } satisfies PreliminaryResearchDocumentNode;
        });

        return {
            documentType,
            documents,
        } satisfies PreliminaryResearchDocumentGroupNode;
    });
};