import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getSharedApiClient, postJson, postJsonWithHeaders, postFormData } from './sharedApi';

describe('sharedApi', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    delete (window as any).__dbaware;
    delete (window as any).__dbawareRcToken;
  });

  it('uses shared apiClientFullResponse and headers when registered', async () => {
    (window as any).__dbawareRcToken = 'rc-tok-1';
    const postSpy = vi.fn().mockResolvedValue({
      data: { ok: true },
      headers: new Headers({ 'x-run-id': 'r1' }),
    });
    (window as any).__dbaware = {
      apiClientFullResponse: { post: postSpy },
    };

    const res = await postJsonWithHeaders<{ ok: boolean }>('/api/test', { a: 1 });
    expect(res.data).toEqual({ ok: true });
    expect(res.headers['x-run-id']).toBe('r1');
  });

  it('falls back to apiClient and native fetch for postJson and postFormData', async () => {
    const clientPost = vi.fn().mockResolvedValue({ done: true });
    (window as any).__dbaware = { apiClient: { post: clientPost } };
    expect(getSharedApiClient()).toBeDefined();
    expect(await postJson('/api/test', { b: 2 })).toEqual({ done: true });
    expect(await postFormData('/api/upload', { file: new Blob(['hi']), tags: ['a', 'b'] })).toEqual({ done: true });

    delete (window as any).__dbaware;
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ fetched: true }),
      headers: { 'x-trace': 't1' },
    });
    vi.stubGlobal('fetch', fetchMock);
    expect(await postJson('https://example.com/api', { c: 3 })).toEqual({ fetched: true });
    expect(await postFormData('https://example.com/upload', { k: 'v' })).toEqual({ fetched: true });

    fetchMock.mockResolvedValueOnce({ ok: false, status: 500, statusText: 'Err' });
    await expect(postJson('/fail', {})).rejects.toThrow('POST //fail failed: 500 Err');
  });

  it('preserves upstream JSON error body on ApiRequestError', async () => {
    delete (window as any).__dbaware;
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 502,
      statusText: 'Bad Gateway',
      text: async () => JSON.stringify({ detail: 'db down', error_details: [{ title: 'p1', error: 'boom' }] }),
    });
    vi.stubGlobal('fetch', fetchMock);
    try {
      await postJson('/x', {});
      throw new Error('should fail');
    } catch (e: any) {
      expect(e.message).toContain('POST //x failed: 502 Bad Gateway');
      expect(e.details.status).toBe(502);
      expect(e.details.message).toBe('db down');
      expect(e.details.errorDetails[0].error).toBe('boom');
    }
  });
});
