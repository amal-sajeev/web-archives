import { postJson, postFormData, getSharedApiClient } from './sharedApi';
import { buildUserDetailsForPlan } from './scopeContext';

type DataGatheringAction =
    | 'DATA_EXTRACTION'
    | 'GET_DATA_EXTRACTION_STATUS'
    | 'GET_PLAN_AVAILABILITY'
    | 'GET_PLAN_ARTIFACT';

interface DataGatheringGatewayRequest<TPayload> {
    planNumber: string;
    action: DataGatheringAction;
    payload: TPayload;
}

export interface DataExtractionTriggerResponse {
    planNumber: string;
    sessionId?: string;
    status?: string;
    message?: string;
    accepted: boolean;
}

export interface DataExtractionStatusResponse {
    planNumber: string;
    sessionId?: string;
    status: string;
    message?: string;
    isComplete: boolean;
    isFailed: boolean;
}

export interface PlanAvailabilityResponse {
    planNumber: string;
    available: boolean;
    status?: string;
    sessionId?: string;
    message?: string;
}

export interface PlanArtifactResponse<T = any> {
    plan_number: string;
    artifact: string;
    source: string;
    data: T;
}

export interface LrrProcessStartResponse {
    runId: string;
    requestId?: string;
    status?: string;
    objective?: string;
    seeds?: string[];
    pipeline?: string;
    message?: string;
}

export interface LrrProcessStatusResponse {
    runId: string;
    status: string;
    progress?: number;
    totalSteps?: number;
    currentStep?: number;
    pipeline?: string;
    message?: string;
    isComplete: boolean;
    isFailed: boolean;
}

export interface LrrRunDetailsResponse {
    runId: string;
    objective?: string;
    status: string;
    step?: number;
    durationMs?: number;
    sources?: number;
    documents?: number;
    accepted?: number;
    review?: number;
    rejected?: number;
    createdAt?: string;
    live?: boolean;
    error?: string;
    seeds?: string[];
    pipeline?: string;
    message?: string;
    isComplete: boolean;
    isFailed: boolean;
}

const DATA_GATHERING_ACTIONS_URL = '/dbaware-api-gateway/api/v1/actions';
const LRR_AGENT_BASE_URL = '/scoping-lrrextraction-agent';
const LRR_PROCESS_URL = `${LRR_AGENT_BASE_URL}/lrr/process`;
const LRR_PROCESS_PDF_URL = `${LRR_AGENT_BASE_URL}/lrr/process-pdf`;
const LRR_STATUS_URL = `${LRR_AGENT_BASE_URL}/lrr/process`;
const LRR_RUNS_URL = `${LRR_AGENT_BASE_URL}/lrr/runs`;
const EXTRACTION_TERMINAL_SUCCESS = new Set(['complete', 'completed', 'done', 'success', 'succeeded', 'available']) as ReadonlySet<string>;
const EXTRACTION_TERMINAL_FAILURE = new Set(['failed', 'error', 'cancelled', 'canceled']) as ReadonlySet<string>;
const LRR_TERMINAL_SUCCESS = new Set(['complete', 'completed', 'done', 'success', 'succeeded']) as ReadonlySet<string>;
const LRR_TERMINAL_FAILURE = new Set(['failed', 'error', 'cancelled', 'canceled']) as ReadonlySet<string>;

const buildPlanNumber = (planNumber: string | number): string => String(planNumber);

const toRecord = (value: unknown): Record<string, any> | null => {
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
        return value as Record<string, any>;
    }
    return null;
};

const unwrapGatewayEnvelope = (response: unknown): unknown => {
    const root = toRecord(response);
    if (!root) return response;

    if (toRecord(root.response)) return root.response;
    if (toRecord(root.payload)) return root.payload;
    if (toRecord(root.data)) return root.data;

    return response;
};

const extractActionPayload = (response: unknown, hints: string[]): Record<string, any> => {
    const preferred = unwrapGatewayEnvelope(response);
    const queue: unknown[] = preferred === response ? [response] : [preferred, response];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        const record = toRecord(current);

        if (!record || visited.has(record)) {
            continue;
        }

        visited.add(record);

        if (hints.some(hint => hint in record)) {
            return record;
        }

        if ('payload' in record) queue.push(record.payload);
        if ('data' in record) queue.push(record.data);
        if ('result' in record) queue.push(record.result);
        if ('response' in record) queue.push(record.response);
    }

    return toRecord(response) ?? {};
};

const getStringField = (record: Record<string, any>, keys: string[]): string | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (typeof value === 'string' && value.trim()) {
            return value;
        }
    }

    return undefined;
};

const getBooleanField = (record: Record<string, any>, keys: string[]): boolean | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (typeof value === 'boolean') {
            return value;
        }
        if (typeof value === 'string') {
            const normalized = value.trim().toLowerCase();
            if (normalized === 'true') return true;
            if (normalized === 'false') return false;
        }
    }

    return undefined;
};

const getNumberField = (record: Record<string, any>, keys: string[]): number | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (typeof value === 'number' && Number.isFinite(value)) {
            return value;
        }
        if (typeof value === 'string') {
            const parsed = Number(value);
            if (Number.isFinite(parsed)) {
                return parsed;
            }
        }
    }

    return undefined;
};

const getStringArrayField = (record: Record<string, any>, keys: string[]): string[] | undefined => {
    for (const key of keys) {
        const value = record[key];
        if (Array.isArray(value)) {
            return value
                .map((item) => (typeof item === 'string' ? item.trim() : ''))
                .filter((item) => Boolean(item));
        }
    }

    return undefined;
};

const normalizeStatus = (status?: string): string => (status || 'pending').toLowerCase();

const RC_TOKEN_GLOBAL_KEY = '__dbawareRcToken';

const buildRcTokenHeader = (): Record<string, string> => {
    if (typeof window === 'undefined') return {};
    const token = (window as any)[RC_TOKEN_GLOBAL_KEY];
    return typeof token === 'string' && token.trim().length > 0
        ? { 'x-asm-rctoken': token }
        : {};
};

const buildLrrStatusMessage = (payload: Record<string, any>, status: string): string | undefined => {
    const explicitMessage = getStringField(payload, ['message', 'detail']);
    if (explicitMessage) {
        return explicitMessage;
    }

    const progress = getNumberField(payload, ['progress']);
    const currentStep = getNumberField(payload, ['current_step', 'currentStep']);
    const totalSteps = getNumberField(payload, ['total_steps', 'totalSteps']);

    if (typeof progress === 'number') {
        return `LRR URL processing status: ${status} (${progress}%).`;
    }

    if (typeof currentStep === 'number' && typeof totalSteps === 'number' && totalSteps > 0) {
        return `LRR URL processing status: ${status} (step ${currentStep}/${totalSteps}).`;
    }

    return `LRR URL processing status: ${status}.`;
};

const getJson = async <T>(url: string): Promise<T> => {
    const client = getSharedApiClient();
    if (client) {
        return client.get<T>(url, {
            timeout: 600000,
        });
    }

    const response = await fetch(url, {
        method: 'GET',
        headers: buildRcTokenHeader(),
    });

    if (!response.ok) {
        throw new Error(`GET ${url} failed: ${response.status} ${response.statusText}`);
    }

    return response.json() as Promise<T>;
};

const postDataGatheringAction = <TResponse, TPayload>(
    planNumber: string | number,
    action: DataGatheringAction,
    payload: TPayload
): Promise<TResponse> => {
    const request: DataGatheringGatewayRequest<TPayload> = {
        planNumber: buildPlanNumber(planNumber),
        action,
        payload,
    };

    return postJson<TResponse>(DATA_GATHERING_ACTIONS_URL, request);
};

export const triggerDataExtraction = async (
    planNumber: string | number
): Promise<DataExtractionTriggerResponse> => {
    const userDetails = buildUserDetailsForPlan(planNumber);
    const body: Record<string, unknown> = { planNumber: buildPlanNumber(planNumber) };
    if (userDetails) {
        body.userDetails = userDetails;
    }
    const response = await postDataGatheringAction<unknown, Record<string, unknown>>(
        planNumber,
        'DATA_EXTRACTION',
        body
    );

    const payload = extractActionPayload(response, ['session_id', 'sessionId', 'status', 'plan_number']);
    const status = getStringField(payload, ['status', 'state']);
    const sessionId = getStringField(payload, ['session_id', 'sessionId', 'extraction_session_id']);

    return {
        planNumber: buildPlanNumber(planNumber),
        sessionId: sessionId,
        status,
        message: getStringField(payload, ['message', 'detail']),
        accepted: !!sessionId,
    };
};

export const getDataExtractionStatus = async (
    planNumber: string | number,
    sessionId: string
): Promise<DataExtractionStatusResponse> => {
    const response = await postDataGatheringAction<unknown, { session_id: string }>(
        planNumber,
        'GET_DATA_EXTRACTION_STATUS',
        { session_id: sessionId }
    );

    const payload = extractActionPayload(response, ['session_id', 'sessionId', 'status', 'stage_name', 'error']);
    const statusValue = getStringField(payload, ['status', 'state']);
    const status = normalizeStatus(statusValue);

    return {
        planNumber: buildPlanNumber(planNumber),
        sessionId: getStringField(payload, ['session_id', 'sessionId', 'extraction_session_id']) || sessionId,
        status,
        message: getStringField(payload, ['message', 'detail', 'error']),
        isComplete: EXTRACTION_TERMINAL_SUCCESS.has(status),
        isFailed: EXTRACTION_TERMINAL_FAILURE.has(status),
    };
};

export const getPlanAvailability = async (
    planNumber: string | number
): Promise<PlanAvailabilityResponse> => {
    const response = await postDataGatheringAction<unknown, Record<string, never>>(
        planNumber,
        'GET_PLAN_AVAILABILITY',
        {}
    );

    const payload = extractActionPayload(response, ['availability', 'available', 'is_available', 'plan_number']);
    const status = getStringField(payload, ['status', 'state']);
    const explicitAvailability = getBooleanField(payload, ['availability', 'available', 'is_available', 'plan_available']);

    return {
        planNumber: buildPlanNumber(planNumber),
        available: explicitAvailability ?? false,
        status,
        sessionId: getStringField(payload, ['session_id', 'sessionId', 'extraction_session_id']),
        message: getStringField(payload, ['message', 'detail']),
    };
};

export const getPlanArtifact = async <T = any>(
    planNumber: string | number,
    artifact: string
): Promise<PlanArtifactResponse<T>> => {
    const userDetails = buildUserDetailsForPlan(planNumber);
    const body: Record<string, unknown> = { artifact };
    if (userDetails?.review_scope_id) body.review_scope_id = userDetails.review_scope_id;
    if (userDetails?.process_instance_id) body.process_instance_id = userDetails.process_instance_id;
    if (userDetails?.task_id) body.task_id = userDetails.task_id;
    const response = await postDataGatheringAction<unknown, Record<string, unknown>>(
        planNumber,
        'GET_PLAN_ARTIFACT',
        body
    );

    const payload = extractActionPayload(response, ['artifact_name', 'artifact_url', 'plan_number']);

    return {
        plan_number: getStringField(payload, ['plan_number', 'planNumber']) || buildPlanNumber(planNumber),
        artifact: getStringField(payload, ['artifact_name', 'artifact']) || artifact,
        source: getStringField(payload, ['artifact_url', 'source']) || 'gateway',
        data: (payload.data ?? payload) as T,
    };
};

export const startLrrProcess = async (
    planNumber: string | number,
    urls: string[]
): Promise<LrrProcessStartResponse> => {
    const response = await postJson<unknown>(
        LRR_PROCESS_URL,
        {
            urls,
            request_id: buildPlanNumber(planNumber),
        }
    );

    const payload = extractActionPayload(response, ['run_id', 'runId', 'request_id', 'status', 'objective', 'seeds', 'pipeline']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        runId: getStringField(payload, ['run_id', 'runId', 'id']) || '',
        requestId: getStringField(payload, ['request_id', 'requestId']),
        status: getStringField(payload, ['status', 'state']),
        objective: getStringField(payload, ['objective', 'goal']),
        seeds: getStringArrayField(payload, ['seeds', 'urls']),
        pipeline: getStringField(payload, ['pipeline']),
        message: buildLrrStatusMessage(payload, status),
    };
};

export const startLrrPdfProcess = async (
    planNumber: string | number,
    file: File
): Promise<LrrProcessStartResponse> => {
    const response = await postFormData<unknown>(
        LRR_PROCESS_PDF_URL,
        {
            request_id: buildPlanNumber(planNumber),
            files: file,
        }
    );

    const payload = extractActionPayload(response, ['run_id', 'runId', 'request_id', 'status', 'objective', 'seeds', 'pipeline']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        runId: getStringField(payload, ['run_id', 'runId', 'id']) || '',
        requestId: getStringField(payload, ['request_id', 'requestId']),
        status: getStringField(payload, ['status', 'state']),
        objective: getStringField(payload, ['objective', 'goal']),
        seeds: getStringArrayField(payload, ['seeds', 'urls']),
        pipeline: getStringField(payload, ['pipeline']),
        message: buildLrrStatusMessage(payload, status),
    };
};

export const getLrrProcessStatus = async (
    runId: string
): Promise<LrrProcessStatusResponse> => {
    const response = await getJson<unknown>(`${LRR_STATUS_URL}/${encodeURIComponent(runId)}/status`);

    const payload = extractActionPayload(response, ['run_id', 'runId', 'status', 'state', 'message']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        runId: getStringField(payload, ['run_id', 'runId', 'id']) || runId,
        status,
        progress: getNumberField(payload, ['progress']),
        totalSteps: getNumberField(payload, ['total_steps', 'totalSteps']),
        currentStep: getNumberField(payload, ['current_step', 'currentStep']),
        pipeline: getStringField(payload, ['pipeline']),
        message: buildLrrStatusMessage(payload, status),
        isComplete: LRR_TERMINAL_SUCCESS.has(status),
        isFailed: LRR_TERMINAL_FAILURE.has(status),
    };
};

export const getLrrRunDetails = async (
    runId: string
): Promise<LrrRunDetailsResponse> => {
    const response = await getJson<unknown>(`${LRR_RUNS_URL}/${encodeURIComponent(runId)}`);

    const payload = extractActionPayload(response, ['run_id', 'runId', 'status', 'objective', 'error', 'seeds', 'pipeline']);
    const status = normalizeStatus(getStringField(payload, ['status', 'state']));

    return {
        runId: getStringField(payload, ['run_id', 'runId', 'id']) || runId,
        objective: getStringField(payload, ['objective', 'goal']),
        status,
        step: getNumberField(payload, ['step']),
        durationMs: getNumberField(payload, ['duration_ms', 'durationMs']),
        sources: getNumberField(payload, ['sources']),
        documents: getNumberField(payload, ['documents']),
        accepted: getNumberField(payload, ['accepted']),
        review: getNumberField(payload, ['review']),
        rejected: getNumberField(payload, ['rejected']),
        createdAt: getStringField(payload, ['created_at', 'createdAt']),
        live: getBooleanField(payload, ['live']),
        error: getStringField(payload, ['error']),
        seeds: getStringArrayField(payload, ['seeds', 'urls']),
        pipeline: getStringField(payload, ['pipeline']),
        message: getStringField(payload, ['message', 'detail']) || getStringField(payload, ['error']),
        isComplete: LRR_TERMINAL_SUCCESS.has(status),
        isFailed: LRR_TERMINAL_FAILURE.has(status),
    };
};

/**
 * Executes the complete data extraction flow:
 * 1. Triggers data extraction and gets a session ID
 * 2. Polls the status until completion
 * 3. Retrieves the plan artifact (LRR)
 *
 * @param planNumber - The plan number to extract data for
 * @param artifactName - The artifact to retrieve (default: 'lrr')
 * @param pollingIntervalMs - How often to poll status (default: 5000ms)
 * @param maxPollingAttempts - Maximum number of polling attempts (default: 200 = 16 minutes 40 seconds)
 * @param onStatusUpdate - Optional callback for status updates during polling
 * @returns The extracted artifact data.
 */
export const executeDataExtractionFlow = async <T = any>(
    planNumber: string | number,
    artifactName: string = 'lrr',
    pollingIntervalMs: number = 5000,
    maxPollingAttempts: number = 200,
    onStatusUpdate?: (status: string, message?: string) => void
): Promise<PlanArtifactResponse<T>> => {
    try {
        // Step 1: Trigger data extraction
        onStatusUpdate?.('Triggering data extraction...', 'Sending extraction request');
        const triggerResponse = await triggerDataExtraction(planNumber);

        if (!triggerResponse.accepted || !triggerResponse.sessionId) {
            throw new Error(
                triggerResponse.message || 'Data extraction trigger failed: no session ID received'
            );
        }

        const sessionId = triggerResponse.sessionId;
        onStatusUpdate?.('Polling', `Session started: ${sessionId}`);

        // Step 2: Poll status until completion
        let pollAttempt = 0;
        let statusResponse: DataExtractionStatusResponse;

        while (pollAttempt < maxPollingAttempts) {
            statusResponse = await getDataExtractionStatus(planNumber, sessionId);

            onStatusUpdate?.(
                statusResponse.status,
                statusResponse.message || `Processing results...`
            );

            if (statusResponse.isComplete) {
                onStatusUpdate?.('COMPLETED', 'Data extraction completed successfully');
                break;
            }

            if (statusResponse.isFailed) {
                throw new Error(
                    statusResponse.message || `Data extraction failed with status: ${statusResponse.status}`
                );
            }

            pollAttempt++;
            await new Promise(resolve => setTimeout(resolve, pollingIntervalMs));
        }

        if (pollAttempt >= maxPollingAttempts) {
            throw new Error('Data extraction polling timeout - status never reached completion');
        }

        // Step 3: Get the artifact
        onStatusUpdate?.('Retrieving artifact', `Fetching ${artifactName} artifact`);
        const artifactResponse = await getPlanArtifact<T>(planNumber, artifactName);

        onStatusUpdate?.('SUCCESS', 'Data extraction completed and artifact retrieved');
        return artifactResponse;
    } catch (error) {
        const message = error instanceof Error ? error.message : 'Unknown error during data extraction';
        onStatusUpdate?.('ERROR', message);
        throw error;
    }
};