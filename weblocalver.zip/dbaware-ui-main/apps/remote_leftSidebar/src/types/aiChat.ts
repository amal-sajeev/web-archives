import type { ReactNode } from 'react';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string | ReactNode;
  timestamp: string;
  isStreaming?: boolean;
}

export interface RecommendedAction {
  id: string;
  label: string;
}

export interface AiChatState {
  messages: ChatMessage[];
  inputValue: string;
  isGenerating: boolean;
  recommendedActions: RecommendedAction[];
}

export interface RecipientItem {
  id: string;
  type: 'File' | 'Link' | 'Email';
  attachment: string;
  category?: string;
  status: string;
  emails?: string[];
}
