import React, { useState, useCallback, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Stack } from '@wadk/ui';
import { AutoLoadingProgress } from 'com.db.rca.commons.afcc-components';
import type { ChatMessage, RecommendedAction, WorkflowMessageState } from '../types/aiChat';
import { NoirGenerationFlow } from '../components/AiChat/NoirGenerationFlow';
import { NoirEditFlow } from '../components/AiChat/NoirEditFlow';
import { NorGenerationFlow } from '../components/AiChat/NorGenerationFlow';
import { NorEditFlow } from '../components/AiChat/NorEditFlow';
import { DataGatheringGenerationFlow } from '../components/AiChat/DataGatheringGenerationFlow';
import { ScopeRecommendationUploadFlow } from '../components/AiChat/ScopeRecommendationUploadFlow';
import { SequentialFadeList } from '../components/AiChat/SequentialFadeList';
import { useCurrentPath } from './useCurrentPath';
import { useLocation, matchPath } from 'react-router-dom';
import { postJson } from '../api/sharedApi';

const INITIAL_RECOMMENDATIONS: RecommendedAction[] = [
  { id: '1', label: 'Generate NOIR' }, { id: '2', label: 'Skip Noir' }
];

const formatInlineBold = (text: string): React.ReactNode[] => {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, index) => {
    if (/^\*\*[^*]+\*\*$/.test(part)) {
      return <strong key={`b-${index}`}>{part.slice(2, -2)}</strong>;
    }
    return <React.Fragment key={`t-${index}`}>{part}</React.Fragment>;
  });
};

const formatQnaAnswerContent = (answer: string): React.ReactNode => {
  const normalized = String(answer || '')
    .replace(/\r\n/g, '\n')
    .replace(/\s\*\s(?=\*\*)/g, '\n* ');

  const lines = normalized.split('\n');
  const blocks: React.ReactNode[] = [];
  let bulletItems: string[] = [];

  const flushBullets = () => {
    if (bulletItems.length === 0) return;
    const items = [...bulletItems];
    bulletItems = [];
    blocks.push(
      <ul key={`ul-${blocks.length}`} style={{ margin: '0 0 8px 18px', padding: 0 }}>
        {items.map((item, idx) => (
          <li key={`li-${idx}`} style={{ marginBottom: '4px' }}>
            {formatInlineBold(item)}
          </li>
        ))}
      </ul>
    );
  };

  lines.forEach((rawLine) => {
    const line = rawLine.trim();
    if (!line) {
      flushBullets();
      return;
    }

    if (line.startsWith('* ')) {
      bulletItems.push(line.slice(2).trim());
      return;
    }

    flushBullets();
    blocks.push(
      <div key={`p-${blocks.length}`} style={{ marginBottom: '8px' }}>
        {formatInlineBold(line)}
      </div>
    );
  });

  flushBullets();

  return (
    <div style={{ whiteSpace: 'pre-wrap', lineHeight: 1.5 }}>
      {blocks.length > 0 ? blocks : formatInlineBold(normalized)}
    </div>
  );
};

export const
  useAiChat = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [isInputDisabled, setIsInputDisabled] = useState(false);
    const [recommendedActions] = useState<RecommendedAction[]>(INITIAL_RECOMMENDATIONS);
    const path = useCurrentPath();

    // Extract planId from URL
    const location = useLocation();
    const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, location.pathname);
    const planId = dashboardMatch?.params?.planId;

    const validTabs = [
      'noir',
      'data-gathering',
      'preliminary-research',
      'discovery-walkthrough',
      'scope-recommendation',
      'test-steps',
      'final-scope-document',
      'nor'
    ];
    const currentTab = path.split('/').reverse().find(segment => validTabs.includes(segment)) || 'noir';

    const noirData = useSelector((state: any) => state.scoping?.noirData);
    const norData = useSelector((state: any) => state.nor?.norData);

    // Clear messages when tab changes
    useEffect(() => {
      setMessages([]);
      setIsGenerating(false);
      setInputValue('');
    }, [currentTab]);

    const handleInputChange = useCallback((value: string) => {
      setInputValue(value);
    }, []);

    const extractWorkflowState = (result: any): WorkflowMessageState | undefined => {
      if (!result || typeof result !== 'object') return undefined;
      const wf =
        result.document_workflow ||
        result.workflow ||
        (result.workflow_status || result.requires_approval ? result : null);
      if (!wf || typeof wf !== 'object') return undefined;

      const status = wf.status || wf.stage || result.workflow_status;
      const affectedSections = Array.isArray(wf.affected_sections)
        ? wf.affected_sections
        : Array.isArray(result.affected_sections)
          ? result.affected_sections
          : undefined;

      return {
        status,
        planId: wf.plan_id ?? result.plan_id,
        planNumber: wf.plan_number ?? result.plan_number,
        affectedSections,
        requiresApproval: Boolean(
          wf.requires_approval ?? (status === 'pending_approval' || status === 'awaiting_approval')
        ),
        summary: wf.summary,
      };
    };

    const handleQnaApiSend = async (
      message: string,
      tab: string
    ): Promise<{ answer: string; workflowState?: WorkflowMessageState }> => {
      const contextTypeMap: Record<string, string> = {
        'preliminary-research': 'Preliminary Research Walkthrough',
        'discovery-walkthrough': 'Discovery Walkthrough',
        'scope-recommendation': 'Scope Recommendation',
        'test-steps': 'Test Steps',
        'final-scope-document': 'Final Scope Document',
      };

      // Map tabs to appropriate API action types
      const actionTypeMap: Record<string, string> = {
        'preliminary-research': 'QNA_CHAT',
        'discovery-walkthrough': 'QNA_CHAT',
        'scope-recommendation': 'QNA_CHAT',
        'test-steps': 'QNA_CHAT',
        'final-scope-document': 'QNA_CHAT',
      };

      const contextType = contextTypeMap[tab] || 'Preliminary Research Walkthrough';
      const actionType = actionTypeMap[tab] || 'QNA_CHAT';

      const payload = {
        planNumber: planId,
        action: actionType,
        payload: {
          question: message,
          planNumber: planId,
          planName: "string",
          contextType,
          contextGcsUri: "string",
          researchSections: {
            additionalProp1: {}
          }
        }
      };

      try {
        const response = await postJson<any>('/dbaware-api-gateway/api/v1/actions', payload);
        const result = response?.response || response?.payload || response?.data || response;
        const answer = result?.answer || 'Sorry, I could not generate a response.';
        const workflowState = extractWorkflowState(result);

        if (
          workflowState &&
          (workflowState.status === 'executed' || workflowState.status === 'success')
        ) {
          window.dispatchEvent(
            new CustomEvent('ai-chat:preliminary-research-workflow-executed', {
              detail: {
                planId: planId || workflowState.planNumber,
                workflowPlanId: workflowState.planId,
                affectedSections: workflowState.affectedSections || [],
              },
            })
          );
        }

        return { answer, workflowState };
      } catch (error) {
        console.error('QnA Chat Error:', error);
        return { answer: 'Sorry, there was an error processing your request.' };
      }
    };

    const handleSend = useCallback(async (content?: string) => {
      const textToSend = content || inputValue;
      if (!textToSend.trim()) return;

      // Add user message
      const newUserMsg: ChatMessage = {
        id: Date.now().toString(),
        sender: 'user',
        content: textToSend,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, newUserMsg]);
      setInputValue('');
      setIsGenerating(true);

      const newAiMsgId = (Date.now() + 1).toString();
      let aiResponseContent: React.ReactNode;

      if (currentTab === 'scope-recommendation') {
        const lowerText = textToSend.toLowerCase();

        if (lowerText === 'yes') {
          aiResponseContent = <ScopeRecommendationUploadFlow messageId={newAiMsgId} />;
          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        } else if (lowerText === 'no') {
          aiResponseContent = "Skipping document upload. Redirecting to generation...";
          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);

          setTimeout(() => {
            window.dispatchEvent(new CustomEvent('ai-chat:send-message', { detail: { content: 'Generate scope recommendation' } }));
          }, 500);
        } else if (lowerText === 'generate scope recommendation') {
          aiResponseContent = (
            <Stack gap="md" direction="column">
              <div style={{ fontWeight: 'bold' }}>Generating Scope Recommendation...</div>
              <SequentialFadeList
                title="Looking into..."
                listStyle={{ margin: '8px 0', paddingLeft: '24px' }}
                items={['Reviewing regulatory obligations',
                  'Analysing policies',
                  'Comparing historical scope',
                  'Reviewing open findings',
                  'Mapping risks and controls',
                  'Assessing evidence ',
                  'Developing scope direction',
                  'processing....']}
                intervalMs={40000}
              />
              {/* <AutoLoadingProgress
                intervalMs={180000}
                messages={['Analyzing data...', 'Preparing recommendation...', 'Almost Done...']}
              /> */}
            </Stack>
          );
          const newAiMsg: ChatMessage = {
            id: 'scope-recommendation-loading',
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
          window.dispatchEvent(new CustomEvent('ai-chat:generate-scope-recommendation'));
        } else {
          const qnaResult = await handleQnaApiSend(textToSend, currentTab);
          aiResponseContent = formatQnaAnswerContent(qnaResult.answer);
          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false,
            ...(qnaResult.workflowState ? { workflowState: qnaResult.workflowState } : {}),
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }
      } else if (currentTab === 'data-gathering') {
        setTimeout(() => {
          if (textToSend.toLowerCase() === 'generate data gathering') {
            aiResponseContent = <DataGatheringGenerationFlow messageId={newAiMsgId} />;
          } else {
            aiResponseContent = `I've prepared the information regarding: "${textToSend}". Let me know what you want to do next.`;
          }

          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };

          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }, 500);
      } else if (currentTab !== 'noir' && currentTab !== 'nor') {
        // Send all non-noir and non-nor queries to the real QnA API
        const qnaResult = await handleQnaApiSend(textToSend, currentTab);
        aiResponseContent = formatQnaAnswerContent(qnaResult.answer);

        const newAiMsg: ChatMessage = {
          id: newAiMsgId,
          sender: 'ai',
          content: aiResponseContent,
          timestamp: new Date().toISOString(),
          isStreaming: false,
          ...(qnaResult.workflowState ? { workflowState: qnaResult.workflowState } : {}),
        };
        setMessages(prev => [...prev, newAiMsg]);
        setIsGenerating(false);
      } else if (currentTab === 'nor') {
        setTimeout(() => {
          if (textToSend.toLowerCase() === 'generate nor') {
            aiResponseContent = <NorGenerationFlow messageId={newAiMsgId} />;
          } else if (norData) {
            aiResponseContent = <NorEditFlow messageId={newAiMsgId} instruction={textToSend} />;
          } else {
            aiResponseContent = `I've prepared the information regarding: "${textToSend}". Let me know what you want to do next.`;
          }

          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };

          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }, 2000);
      } else {
        // Retain the mock timeout behavior for noir flow
        setTimeout(() => {
          if (textToSend.toLowerCase() === 'generate noir') {
            aiResponseContent = <NoirGenerationFlow messageId={newAiMsgId} />;
          } else if (textToSend.toLowerCase() === 'skip noir') {
            aiResponseContent = "Skipping Noir generation. Redirecting...";
            setTimeout(() => {
              window.location.href = planId ? `/dbaware-ui/preliminary-research/${planId}` : '/dbaware-ui/preliminary-research';
            }, 500); // Short delay before redirect to show the message
          } else if (noirData) {
            // Treat as an edit instruction for the NOIR document
            aiResponseContent = <NoirEditFlow messageId={newAiMsgId} instruction={textToSend} />;
          } else {
            aiResponseContent = `I've prepared the information regarding: "${textToSend}". Let me know what you want to do next.`;
          }

          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };

          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }, 2000);
      }
    }, [inputValue, noirData, norData, currentTab, planId]);
    // Listen for cross-microfrontend events
    useEffect(() => {
      const handleGenerateNoirEvent = () => {
        handleSend('Generate Noir');
      };

      const handleGenerateNorEvent = () => {
        handleSend('Generate Nor');
      };

      const handleAddMessage = (e: Event) => {
        const detail = (e as CustomEvent).detail as {
          id?: string;
          sender: 'user' | 'ai';
          content: React.ReactNode;
        };
        const newMsg: ChatMessage = {
          id: detail.id ?? Date.now().toString() + Math.random().toString(36).slice(2, 7),
          sender: detail.sender,
          content: detail.content,
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, newMsg]);
      };

      const handleRemoveMessage = (e: Event) => {
        const { id } = (e as CustomEvent).detail as { id: string };
        setMessages(prev => prev.filter(m => m.id !== id));
      };

      const handleSetInputDisabled = (e: Event) => {
        const { disabled } = (e as CustomEvent).detail as { disabled: boolean };
        setIsInputDisabled(disabled);
      };

      const handleSendMessageEvent = (e: Event) => {
        const { content } = (e as CustomEvent).detail as { content: string };
        handleSend(content);
      };

      const handleResetChatEvent = () => {
        setMessages([]);
        setIsGenerating(false);
        setInputValue('');
      };

      window.addEventListener('ai-chat:generate-noir', handleGenerateNoirEvent);
      window.addEventListener('ai-chat:generate-nor', handleGenerateNorEvent);
      window.addEventListener('ai-chat:add-message', handleAddMessage as EventListener);
      window.addEventListener('ai-chat:remove-message', handleRemoveMessage as EventListener);
      window.addEventListener('ai-chat:set-input-disabled', handleSetInputDisabled as EventListener);
      window.addEventListener('ai-chat:send-message', handleSendMessageEvent as EventListener);
      window.addEventListener('ai-chat:reset-chat', handleResetChatEvent as EventListener);

      return () => {
        window.removeEventListener('ai-chat:generate-noir', handleGenerateNoirEvent);
        window.removeEventListener('ai-chat:generate-nor', handleGenerateNorEvent);
        window.removeEventListener('ai-chat:add-message', handleAddMessage as EventListener);
        window.removeEventListener('ai-chat:remove-message', handleRemoveMessage as EventListener);
        window.removeEventListener('ai-chat:set-input-disabled', handleSetInputDisabled as EventListener);
        window.removeEventListener('ai-chat:send-message', handleSendMessageEvent as EventListener);
        window.removeEventListener('ai-chat:reset-chat', handleResetChatEvent as EventListener);
      };
    }, [handleSend]);

    const handleWorkflowDecision = useCallback(
      async (decision: 'approve' | 'reject', messageId?: string) => {
        if (messageId) {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === messageId && m.workflowState
                ? { ...m, workflowState: { ...m.workflowState, resolvedDecision: decision } }
                : m
            )
          );
        }
        await handleSend(decision === 'approve' ? 'approve' : 'reject');
      },
      [handleSend]
    );

    return {
      messages,
      inputValue,
      isGenerating,
      isInputDisabled,
      recommendedActions,
      handleInputChange,
      handleSend,
      handleWorkflowDecision,
      currentTab
    };
  };
