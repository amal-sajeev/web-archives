import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import { Button, Stack } from '@wadk/ui';
import { AutoLoadingProgress } from 'com.db.rca.commons.afcc-components';
import type { ChatMessage, RecommendedAction } from '../types/aiChat';
import { NoirGenerationFlow } from '../components/AiChat/tabs/noir/NoirGenerationFlow';
import { NoirEditFlow } from '../components/AiChat/tabs/noir/NoirEditFlow';
import { NorGenerationFlow } from '../components/AiChat/tabs/nor/NorGenerationFlow';
import { NorEditFlow } from '../components/AiChat/tabs/nor/NorEditFlow';
import { DataGatheringGenerationFlow } from '../components/AiChat/tabs/dataGatheringGeneration/DataGatheringGenerationFlow';
import { ScopeRecommendationUploadFlow } from '../components/AiChat/tabs/scopeRecommendation/ScopeRecommendationUploadFlow';
import { DiscoveryWalkthroughUploadFlow } from '../components/AiChat/tabs/discoveryWalkthrough/DiscoveryWalkthroughUploadFlow';
import { TestStepsUploadFlow } from '../components/AiChat/tabs/testSteps/TestStepsUploadFlow';
import { useCurrentPath } from './useCurrentPath';
import { useLocation, matchPath } from 'react-router-dom';
import { getSharedApiClient, postJson } from '../api/sharedApi';
import { buildUserDetailsForPlan } from '../api/scopeContext';

type UserDetails = {
  review_scope_instance_id?: number;
  review_scope_id?: number | string;
  process_instance_id?: string;
  task_id?: string;
  review_scope_stage?: string;
  user?: string;
};

type DocumentWorkflowInfo = {
  status?: string;
  stage?: string;
  plan_id?: string;
  proposed_actions?: unknown[];
  steps?: unknown[];
  affected_sections?: string[];
};

type QnaChatResult = {
  answer: string;
  documentWorkflow?: DocumentWorkflowInfo;
  userDetails?: UserDetails;
};

type DocumentDecisionResult = {
  message: string;
  affectedSections: string[];
};

const UPLOAD_SEND_ERROR_MESSAGE = 'Unable to upload and send. Please try again.';

const INITIAL_RECOMMENDATIONS: RecommendedAction[] = [
  { id: '1', label: 'Generate NOIR' }, { id: '2', label: 'Skip Noir' }
];

const formatInlineBold = (text: string): React.ReactNode[] => {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, index) => {
    if (/^\*\*[^*]+\*\*$/.test(part)) {
      return <strong key={`b-${index}`}>{part.slice(2, -2)}</strong>;
    }
    return <React.Fragment key={`t-${index}`}>{part}</React.Fragment>;
  });
};

const formatQnaAnswerContent = (answer: string): React.ReactNode => {
  const normalized = String(answer || '')
    .replace(/\r\n/g, '\n')
    .replace(/\s\*\s(?=\*\*)/g, '\n* ');

  const lines = normalized.split('\n');
  const blocks: React.ReactNode[] = [];
  let bulletItems: string[] = [];

  const flushBullets = () => {
    if (bulletItems.length === 0) return;
    const items = [...bulletItems];
    bulletItems = [];
    blocks.push(
      <ul key={`ul-${blocks.length}`} style={{ margin: '0 0 8px 18px', padding: 0 }}>
        {items.map((item, idx) => (
          <li key={`li-${idx}`} style={{ marginBottom: '4px' }}>
            {formatInlineBold(item)}
          </li>
        ))}
      </ul>
    );
  };

  lines.forEach((rawLine) => {
    const line = rawLine.trim();
    if (!line) {
      flushBullets();
      return;
    }

    if (line.startsWith('* ')) {
      bulletItems.push(line.slice(2).trim());
      return;
    }

    flushBullets();
    blocks.push(
      <div key={`p-${blocks.length}`} style={{ marginBottom: '8px' }}>
        {formatInlineBold(line)}
      </div>
    );
  });

  flushBullets();

  return (
    <div style={{ whiteSpace: 'pre-wrap', lineHeight: 1.5 }}>
      {blocks.length > 0 ? blocks : formatInlineBold(normalized)}
    </div>
  );
};

const TAB_UPLOAD_FLOW_CONFIG: Partial<Record<string, {
  generateCommand: string;
  generationEventName: string;
  loadingMessageId: string;
  loadingTitle: string;
  UploadFlowComponent: React.ComponentType<{ messageId?: string }>;
}>> = {
  'scope-recommendation': {
    generateCommand: 'generate scope recommendation',
    generationEventName: 'ai-chat:generate-scope-recommendation',
    loadingMessageId: 'scope-recommendation-loading',
    loadingTitle: 'Generating Scope Recommendation...',
    UploadFlowComponent: ScopeRecommendationUploadFlow,
  },
  'discovery-walkthrough': {
    generateCommand: 'generate discovery walkthrough',
    generationEventName: 'ai-chat:generate-discovery-walkthrough',
    loadingMessageId: 'discovery-walkthrough-loading',
    loadingTitle: 'Generating Discovery Walkthrough...',
    UploadFlowComponent: DiscoveryWalkthroughUploadFlow,
  },
  'test-steps': {
    generateCommand: 'generate test steps',
    generationEventName: 'ai-chat:generate-test-steps',
    loadingMessageId: 'test-steps-loading',
    loadingTitle: 'Generating Test Steps...',
    UploadFlowComponent: TestStepsUploadFlow,
  },
};

export const
  useAiChat = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [isInputDisabled, setIsInputDisabled] = useState(false);
    const [recommendedActions] = useState<RecommendedAction[]>(INITIAL_RECOMMENDATIONS);
    const path = useCurrentPath();

    // Extract planId from URL (prefer live window path in MFE shell, fallback to router path for MemoryRouter tests)
    const location = useLocation();
    const cleanWindowPath = (path || '').replace(/^\/dbaware-ui(?=\/|$)/, '');
    const cleanRouterPath = (location.pathname || '').replace(/^\/dbaware-ui(?=\/|$)/, '');
    const effectivePath =
      cleanWindowPath && cleanWindowPath !== '/'
        ? cleanWindowPath
        : cleanRouterPath || cleanWindowPath || '/';
    const dashboardMatch = matchPath({ path: '/:tab/:planId', end: false }, effectivePath);
    const planId = dashboardMatch?.params?.planId;

    const validTabs = [
      'noir',
      'data-gathering',
      'preliminary-research',
      'discovery-walkthrough',
      'scope-recommendation',
      'test-steps',
      'final-scope-document',
      'nor'
    ];
    const currentTab = effectivePath.split('/').reverse().find(segment => validTabs.includes(segment)) || 'noir';

    const noirData = useSelector((state: any) => state.scoping?.noirData);
    const norData = useSelector((state: any) => state.nor?.norData);
    const pendingWorkflowPlanIdRef = useRef<string>('');

    // Clear messages when tab or plan changes
    useEffect(() => {
      setMessages([]);
      setIsGenerating(false);
      setInputValue('');
      pendingWorkflowPlanIdRef.current = '';
    }, [currentTab, planId]);

    const handleInputChange = useCallback((value: string) => {
      setInputValue(value);
    }, []);

    const extractUserDetails = (taskStatus: any, targetPlanId?: string): UserDetails => {
      const asNumber = (value: unknown): number | undefined => {
        if (typeof value === 'number' && Number.isFinite(value)) return value;
        if (typeof value === 'string' && value.trim()) {
          const parsed = Number(value);
          return Number.isFinite(parsed) ? parsed : undefined;
        }
        return undefined;
      };

      const asString = (value: unknown): string | undefined => {
        if (typeof value === 'number' && Number.isFinite(value)) return String(value);
        if (typeof value !== 'string') return undefined;
        const trimmed = value.trim();
        return trimmed || undefined;
      };

      const variables = taskStatus?.variables || {};
      const nestedUser = variables?.user_details || variables?.userDetails || {};
      const stored = targetPlanId ? buildUserDetailsForPlan(targetPlanId) : undefined;

      const resolvedScopeNum =
        asNumber(taskStatus?.review_scope_instance_id)
        ?? asNumber(taskStatus?.reviewScopeInstanceId)
        ?? asNumber(taskStatus?.review_scope_id)
        ?? asNumber(taskStatus?.reviewScopeId)
        ?? asNumber(variables?.review_scope_instance_id)
        ?? asNumber(variables?.reviewScopeInstanceId)
        ?? asNumber(variables?.review_scope_id)
        ?? asNumber(variables?.reviewScopeId)
        ?? asNumber(variables?.p_REVIEW_SCOPE_ID)
        ?? asNumber(variables?.p_review_scope_id)
        ?? asNumber(variables?.p_review_scope_instance_id)
        ?? asNumber(variables?.p_reviewScopeId)
        ?? asNumber(variables?.p_reviewScopeInstanceId)
        ?? asNumber(nestedUser?.review_scope_instance_id)
        ?? asNumber(nestedUser?.review_scope_id)
        ?? asNumber(stored?.review_scope_id);

      const resolvedScopeFallback = resolvedScopeNum ?? asString(stored?.review_scope_id);

      const out: UserDetails = {};
      if (resolvedScopeNum !== undefined) {
        out.review_scope_instance_id = resolvedScopeNum;
        out.review_scope_id = resolvedScopeNum;
      } else if (resolvedScopeFallback) {
        (out as Record<string, unknown>).review_scope_instance_id = resolvedScopeFallback;
        out.review_scope_id = resolvedScopeFallback;
      }

      const processInstanceId =
        asString(taskStatus?.process_instance_id)
        ?? asString(taskStatus?.processInstanceId)
        ?? asString(variables?.process_instance_id)
        ?? asString(variables?.processInstanceId)
        ?? asString(variables?.p_process_instance_id)
        ?? asString(variables?.p_processInstanceId)
        ?? asString(stored?.process_instance_id);
      if (processInstanceId) out.process_instance_id = processInstanceId;

      const taskId =
        asString(taskStatus?.task_id)
        ?? asString(taskStatus?.taskId)
        ?? asString(variables?.task_id)
        ?? asString(variables?.taskId)
        ?? asString(stored?.task_id);
      if (taskId) out.task_id = taskId;

      const stage =
        asString(taskStatus?.task_definition_key)
        ?? asString(taskStatus?.taskDefinitionKey)
        ?? asString(variables?.task_definition_key)
        ?? asString(variables?.review_scope_stage)
        ?? asString(stored?.review_scope_stage);
      if (stage) out.review_scope_stage = stage;

      const user = asString(nestedUser?.user) ?? asString(stored?.user);
      if (user) out.user = user;

      return out;
    };

    const fetchTaskUserDetails = async (planNumber?: string): Promise<UserDetails | undefined> => {
      if (!planNumber) return undefined;
      let taskStatus: any = {};
      try {
        const client = getSharedApiClient();
        taskStatus = client
          ? await client.get<any>(`/dbaware-api-gateway/api/v1/task/status/${planNumber}`, { timeout: 600000 })
          : await (await fetch(`/dbaware-api-gateway/api/v1/task/status/${planNumber}`)).json();
      } catch {
        taskStatus = {};
      }
      const details = extractUserDetails(taskStatus, planNumber);
      return Object.keys(details).length > 0 ? details : undefined;
    };

    const sendDocumentDecision = async (
      decision: 'approve' | 'reject',
      workflowPlanId: string,
      userDetails?: UserDetails
    ): Promise<DocumentDecisionResult> => {
      if (!planId) {
        return {
          message: 'Missing plan number.',
          affectedSections: [],
        };
      }

      const response = await postJson<any>('/dbaware-api-gateway/api/v1/actions', {
        planNumber: planId,
        action: 'QNA_DECIDE_DOCUMENT_ACTIONS',
        payload: {
          plan_id: workflowPlanId,
          decision,
          approved_by: 'auditor@db.com',
          ...(userDetails ? { user_details: userDetails } : {}),
        },
      });

      const result = response?.response || response?.payload || response?.data || response;
      const affectedSections = Array.isArray(result?.affected_sections) ? result.affected_sections : [];
      const base = result?.answer || result?.message || `Decision ${decision} submitted.`;
      return {
        message: affectedSections.length > 0
          ? `${base} Affected sections: ${affectedSections.join(', ')}.`
          : base,
        affectedSections,
      };
    };

    const runPostDecisionRefresh = async (affectedSections: string[], userDetails?: UserDetails) => {
      if (!planId) return;

      window.dispatchEvent(new CustomEvent('prelim-research:refresh-documents', {
        detail: { planNumber: planId }
      }));

      if (!Array.isArray(affectedSections) || affectedSections.length === 0) {
        return;
      }

      try {
        await postJson<any>('/dbaware-api-gateway/api/v1/actions', {
          planNumber: planId,
          action: 'RUN_ANALYTICS',
          payload: {
            sections: affectedSections,
            sections_to_generate: affectedSections,
            ...(userDetails ? { user_details: userDetails } : {}),
          },
        });

        const refreshedDocument = await postJson<any>('/dbaware-api-gateway/api/v1/actions', {
          planNumber: planId,
          action: 'GET_PRELIMINARY_RESEARCH_DOCUMENT',
          payload: {
            ...(userDetails ? { user_details: userDetails } : {}),
          },
        });

        window.dispatchEvent(new CustomEvent('preliminary-research:sync', {
          detail: { planNumber: planId, status: 'completed' }
        }));
        window.dispatchEvent(new CustomEvent('ai-chat:preliminary-research-workflow-executed', {
          detail: { planNumber: planId, planId, affectedSections, document: refreshedDocument }
        }));
        window.dispatchEvent(new CustomEvent('scoping:refresh-plan-status'));
      } catch {
        // best effort refresh only
      }
    };

    const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = String(reader.result || '');
        const base64 = result.includes(',') ? result.split(',')[1] : result;
        resolve(base64);
      };
      reader.onerror = () => reject(new Error(`Failed to read file: ${file.name}`));
      reader.readAsDataURL(file);
    });

    const extractDocumentIds = (response: any): number[] => {
      const result = response?.response || response?.payload || response?.data || response || {};
      const payloadDocIds = Array.isArray(result?.document_ids) ? result.document_ids : [];
      return payloadDocIds
        .map((id: unknown) => Number(id))
        .filter((id: number) => Number.isFinite(id));
    };

    const extractJobStatusPayload = (response: any): any => {
      return response?.response || response?.payload || response?.data || response || {};
    };

    const ingestAndAttachDocumentsToQnaContext = async (
      files: File[],
      contextType: string,
      userDetails?: UserDetails
    ): Promise<number[]> => {
      if (!planId || files.length === 0) return [];

      const payloadFiles = await Promise.all(files.map(async (file) => {
        const base64Content = await toBase64(file);
        return {
          filename: file.name,
          content: base64Content,
          content_base64: base64Content,
          content_type: file.type || 'application/octet-stream',
        };
      }));

      const ingestResponse = await postJson<any>('/dbaware-api-gateway/api/v1/actions', {
        planNumber: planId,
        action: 'QNA_INGEST_DOCUMENTS',
        payload: {
          files: payloadFiles,
          form_data: { user: 'auditor@db.com' },
        },
      });

      const ingestResult = extractJobStatusPayload(ingestResponse);
      let documentIds = extractDocumentIds(ingestResult);

      if (documentIds.length === 0) {
        const status = String(ingestResult?.status || '').toLowerCase();
        const jobId = String(ingestResult?.job_id || '').trim();
        if (status === 'accepted' && jobId) {
          for (let i = 0; i < 12; i += 1) {
            await new Promise((resolve) => setTimeout(resolve, 2000));
            const pollResponse = await postJson<any>('/dbaware-api-gateway/api/v1/actions', {
              planNumber: planId,
              action: 'QNA_GET_INGEST_JOB_STATUS',
              payload: { job_id: jobId },
            });
            const pollResult = extractJobStatusPayload(pollResponse);
            const pollStatus = String(pollResult?.status || '').toLowerCase();
            if (pollStatus === 'completed') {
              documentIds = extractDocumentIds(pollResult);
              break;
            }
            if (pollStatus === 'failed' || pollStatus === 'error') {
              break;
            }
          }
        }
      }

      if (documentIds.length > 0) {
        await postJson<any>('/dbaware-api-gateway/api/v1/actions', {
          planNumber: planId,
          action: 'QNA_ADD_CHAT_CONTEXT',
          payload: {
            context_type: contextType,
            document_ids: documentIds,
            persist_to_gcs: true,
            ...(userDetails ? { user_details: userDetails } : {}),
          },
        });
      }

      return documentIds;
    };

    const DocumentApprovalCard: React.FC<{
      planActionId: string;
      proposedActions: unknown[];
      userDetails?: UserDetails;
    }> = ({ planActionId, proposedActions, userDetails }) => {
      const [isSubmitting, setIsSubmitting] = useState(false);
      const [done, setDone] = useState(false);

      const handleDecision = async (decision: 'approve' | 'reject') => {
        if (isSubmitting || done) return;
        setIsSubmitting(true);
        try {
          const actionLabel = decision === 'approve' ? 'Approve' : 'Reject';
          setMessages(prev => [...prev, {
            id: `${Date.now()}-${decision}-action`,
            sender: 'user',
            content: actionLabel,
            timestamp: new Date().toISOString(),
            isStreaming: false,
          }]);

          const { message, affectedSections } = await sendDocumentDecision(decision, planActionId, userDetails);
          setMessages(prev => [...prev, {
            id: `${Date.now()}-${decision}`,
            sender: 'ai',
            content: formatQnaAnswerContent(message),
            timestamp: new Date().toISOString(),
            isStreaming: false,
          }]);
          pendingWorkflowPlanIdRef.current = '';
          void runPostDecisionRefresh(affectedSections, userDetails);
          setDone(true);
        } catch {
          setMessages(prev => [...prev, {
            id: `${Date.now()}-${decision}-err`,
            sender: 'ai',
            content: formatQnaAnswerContent('Unable to submit decision right now. Please try again.'),
            timestamp: new Date().toISOString(),
            isStreaming: false,
          }]);
        } finally {
          setIsSubmitting(false);
        }
      };

      if (done) {
        return null;
      }

      return (
        <div style={{ border: '1px solid #dbe2ea', borderRadius: 8, padding: 10, marginTop: 8 }}>
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Document action approval</div>
          {proposedActions.length > 0 && (
            <div style={{ fontSize: 12, color: '#475569', marginBottom: 8 }}>
              {`${proposedActions.length} proposed action(s) pending approval.`}
            </div>
          )}
          <Stack direction="row" gap="xs">
            <Button variant="primary" disabled={isSubmitting || done} onClick={() => handleDecision('approve')}>Approve</Button>
            <Button variant="standard" disabled={isSubmitting || done} onClick={() => handleDecision('reject')}>Reject</Button>
          </Stack>
        </div>
      );
    };

    const renderQnaResponse = (result: QnaChatResult): React.ReactNode => {
      const content: React.ReactNode[] = [
        <div key="answer">{formatQnaAnswerContent(result.answer)}</div>
      ];

      const workflow = result.documentWorkflow;
      const workflowStatus = String(workflow?.status || '').toLowerCase();
      const workflowStage = String(workflow?.stage || '').toLowerCase();
      const workflowPlanId = String(workflow?.plan_id || '').trim();
      const workflowActions = Array.isArray(workflow?.proposed_actions)
        ? workflow!.proposed_actions!
        : (Array.isArray(workflow?.steps) ? workflow!.steps! : []);

      if (workflowStatus === 'pending_approval' && workflowPlanId) {
        pendingWorkflowPlanIdRef.current = workflowPlanId;
      } else {
        pendingWorkflowPlanIdRef.current = '';
      }
      if (workflowStatus === 'pending_approval' && workflowPlanId) {
        content.push(
          <DocumentApprovalCard
            key={`approve-${workflowPlanId}`}
            planActionId={workflowPlanId}
            proposedActions={workflowActions}
            userDetails={result.userDetails}
          />
        );
      } else if (workflowStatus === 'executed' || workflowStage === 'executed') {
        const affectedSections = Array.isArray(workflow?.affected_sections)
          ? workflow!.affected_sections!
          : [];
        void runPostDecisionRefresh(affectedSections, result.userDetails);
      }

      return <>{content}</>;
    };

    const handleQnaApiSend = async (message: string, tab: string, attachments: File[] = []) => {
      const contextTypeMap: Record<string, string> = {
        'preliminary-research': 'Preliminary Research Walkthrough',
        'discovery-walkthrough': 'Discovery Walkthrough',
        'scope-recommendation': 'Scope Recommendation',
        'test-steps': 'Test Steps',
        'final-scope-document': 'Final Scope Document',
      };

      // Map tabs to appropriate API action types
      const actionTypeMap: Record<string, string> = {
        'preliminary-research': 'QNA_CHAT',
        'discovery-walkthrough': 'QNA_CHAT',
        'scope-recommendation': 'QNA_CHAT',
        'test-steps': 'QNA_CHAT',
        'final-scope-document': 'QNA_CHAT',
      };

      const contextType = contextTypeMap[tab] || 'Preliminary Research Walkthrough';
      const actionType = actionTypeMap[tab] || 'QNA_CHAT';

      const userDetails = await fetchTaskUserDetails(planId);

      if (attachments.length > 0) {
        try {
          await ingestAndAttachDocumentsToQnaContext(attachments, contextType, userDetails);
        } catch (error) {
          console.error('QnA Upload Error:', error);
          return {
            answer: UPLOAD_SEND_ERROR_MESSAGE,
            userDetails,
          } satisfies QnaChatResult;
        }
      }

      const payload = {
        planNumber: planId,
        action: actionType,
        payload: {
          question: message,
          context_type: contextType,
          contextType,
          ...(userDetails ? { user_details: userDetails } : {}),
        }
      };

      try {
        const response = await postJson<any>('/dbaware-api-gateway/api/v1/actions', payload);
        const result = response?.response || response?.payload || response?.data || response;
        return {
          answer: result?.answer || 'Sorry, I could not generate a response.',
          documentWorkflow: result?.document_workflow,
          userDetails,
        } satisfies QnaChatResult;
      } catch (error) {
        console.error('QnA Chat Error:', error);
        return {
          answer: UPLOAD_SEND_ERROR_MESSAGE,
          userDetails,
        } satisfies QnaChatResult;
      }
    };

    const handleSend = useCallback(async (content?: string, attachments: File[] = []) => {
      const textToSend = content || inputValue;
      if (!textToSend.trim()) return;

      // Add user message
      const newUserMsg: ChatMessage = {
        id: Date.now().toString(),
        sender: 'user',
        content: textToSend,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, newUserMsg]);
      setInputValue('');
      setIsGenerating(true);

      const normalizedText = textToSend.trim().toLowerCase();
      if ((normalizedText === 'approve' || normalizedText === 'reject') && pendingWorkflowPlanIdRef.current && currentTab === 'preliminary-research') {
        try {
          const userDetails = await fetchTaskUserDetails(planId);
          const { message, affectedSections } = await sendDocumentDecision(
            normalizedText as 'approve' | 'reject',
            pendingWorkflowPlanIdRef.current,
            userDetails
          );
          setMessages(prev => [...prev, {
            id: `${Date.now()}-${normalizedText}-chat`,
            sender: 'ai',
            content: formatQnaAnswerContent(message),
            timestamp: new Date().toISOString(),
            isStreaming: false,
          }]);
          pendingWorkflowPlanIdRef.current = '';
          void runPostDecisionRefresh(affectedSections, userDetails);
        } catch {
          setMessages(prev => [...prev, {
            id: `${Date.now()}-${normalizedText}-chat-err`,
            sender: 'ai',
            content: formatQnaAnswerContent('Unable to submit decision right now. Please try again.'),
            timestamp: new Date().toISOString(),
            isStreaming: false,
          }]);
        } finally {
          setIsGenerating(false);
        }
        return;
      }

      const newAiMsgId = (Date.now() + 1).toString();
      let aiResponseContent: React.ReactNode;

      if (currentTab === 'scope-recommendation' || currentTab === 'discovery-walkthrough' || currentTab === 'test-steps') {
        const lowerText = textToSend.toLowerCase();
        const tabUploadFlow = TAB_UPLOAD_FLOW_CONFIG[currentTab];

        if (!tabUploadFlow) {
          const qnaResult = await handleQnaApiSend(textToSend, currentTab, attachments);
          aiResponseContent = renderQnaResponse(qnaResult);
          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
          return;
        }

        if (lowerText === 'yes') {
          const UploadFlowComponent = tabUploadFlow.UploadFlowComponent;
          aiResponseContent = <UploadFlowComponent messageId={newAiMsgId} />;
          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        } else if (lowerText === 'no') {
          aiResponseContent = "Skipping document upload. Redirecting to generation...";
          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);

          setTimeout(() => {
            window.dispatchEvent(new CustomEvent('ai-chat:send-message', { detail: { content: tabUploadFlow.generateCommand } }));
          }, 500);
        } else if (lowerText === tabUploadFlow.generateCommand) {
          aiResponseContent = (
            <Stack gap="md" direction="column">
              <div style={{ fontWeight: 'bold' }}>{tabUploadFlow.loadingTitle}</div>
            </Stack>
          );
          const newAiMsg: ChatMessage = {
            id: tabUploadFlow.loadingMessageId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
          window.dispatchEvent(new CustomEvent(tabUploadFlow.generationEventName));
        } else {
          const qnaResult = await handleQnaApiSend(textToSend, currentTab, attachments);
          aiResponseContent = renderQnaResponse(qnaResult);
          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };
          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }
      } else if (currentTab === 'data-gathering') {
        setTimeout(() => {
          if (textToSend.toLowerCase() === 'generate data gathering') {
            aiResponseContent = <DataGatheringGenerationFlow messageId={newAiMsgId} />;
          } else {
            aiResponseContent = `I've prepared the information regarding: "${textToSend}". Let me know what you want to do next.`;
          }

          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };

          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }, 500);
      } else if (currentTab !== 'noir' && currentTab !== 'nor') {
        // Send all non-noir and non-nor queries to the real QnA API
        const qnaResult = await handleQnaApiSend(textToSend, currentTab, attachments);
        aiResponseContent = renderQnaResponse(qnaResult);

        const newAiMsg: ChatMessage = {
          id: newAiMsgId,
          sender: 'ai',
          content: aiResponseContent,
          timestamp: new Date().toISOString(),
          isStreaming: false
        };
        setMessages(prev => [...prev, newAiMsg]);
        setIsGenerating(false);
      } else if (currentTab === 'nor') {
        setTimeout(() => {
          if (textToSend.toLowerCase() === 'generate nor') {
            aiResponseContent = <NorGenerationFlow messageId={newAiMsgId} />;
          } else if (norData) {
            aiResponseContent = <NorEditFlow messageId={newAiMsgId} instruction={textToSend} />;
          } else {
            aiResponseContent = `I've prepared the information regarding: "${textToSend}". Let me know what you want to do next.`;
          }

          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };

          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }, 2000);
      } else {
        // Retain the mock timeout behavior for noir flow
        setTimeout(() => {
          if (textToSend.toLowerCase() === 'generate noir') {
            aiResponseContent = <NoirGenerationFlow messageId={newAiMsgId} />;
          } else if (textToSend.toLowerCase() === 'skip noir') {
            aiResponseContent = "Skipping Noir generation. Redirecting...";
            setTimeout(() => {
              window.location.href = planId ? `/dbaware-ui/preliminary-research/${planId}` : '/dbaware-ui/preliminary-research';
            }, 500); // Short delay before redirect to show the message
          } else if (noirData) {
            // Treat as an edit instruction for the NOIR document
            aiResponseContent = <NoirEditFlow messageId={newAiMsgId} instruction={textToSend} />;
          } else {
            aiResponseContent = `I've prepared the information regarding: "${textToSend}". Let me know what you want to do next.`;
          }

          const newAiMsg: ChatMessage = {
            id: newAiMsgId,
            sender: 'ai',
            content: aiResponseContent,
            timestamp: new Date().toISOString(),
            isStreaming: false
          };

          setMessages(prev => [...prev, newAiMsg]);
          setIsGenerating(false);
        }, 2000);
      }
    }, [inputValue, noirData, norData, currentTab, planId]);
    // Listen for cross-microfrontend events
    useEffect(() => {
      const handleGenerateNoirEvent = () => {
        handleSend('Generate Noir');
      };

      const handleGenerateNorEvent = () => {
        handleSend('Generate Nor');
      };

      const handleAddMessage = (e: Event) => {
        const detail = (e as CustomEvent).detail as {
          id?: string;
          sender: 'user' | 'ai';
          content: React.ReactNode;
        };
        const newMsg: ChatMessage = {
          id: detail.id ?? Date.now().toString() + Math.random().toString(36).slice(2, 7),
          sender: detail.sender,
          content: detail.content,
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, newMsg]);
      };

      const handleRemoveMessage = (e: Event) => {
        const { id } = (e as CustomEvent).detail as { id: string };
        setMessages(prev => prev.filter(m => m.id !== id));
      };

      const handleSetInputDisabled = (e: Event) => {
        const { disabled } = (e as CustomEvent).detail as { disabled: boolean };
        setIsInputDisabled(disabled);
      };

      const handleSendMessageEvent = (e: Event) => {
        const { content } = (e as CustomEvent).detail as { content: string };
        handleSend(content);
      };

      const handleOpenCitationEvent = async (e: Event) => {
        const { documentUri } = (e as CustomEvent<{ documentUri?: string }>).detail || {};
        const uri = String(documentUri || '').trim();
        if (!uri || !planId) return;

        try {
          const response = await postJson<any>('/dbaware-api-gateway/api/v1/actions', {
            planNumber: planId,
            action: 'GET_CITATION_DOCUMENT',
            payload: { document_uri: uri },
          });
          const result = response?.response || response?.payload || response?.data || response || {};
          const url = String(result?.url || result?.signed_url || result?.download_url || '').trim();
          if (url) {
            window.open(url, '_blank', 'noopener,noreferrer');
          }
        } catch {
          setMessages(prev => [...prev, {
            id: `${Date.now()}-citation-err`,
            sender: 'ai',
            content: formatQnaAnswerContent('Unable to open citation document right now.'),
            timestamp: new Date().toISOString(),
            isStreaming: false,
          }]);
        }
      };

      const handleResetChatEvent = () => {
        setMessages([]);
        setIsGenerating(false);
        setInputValue('');
        pendingWorkflowPlanIdRef.current = '';
      };

      window.addEventListener('ai-chat:generate-noir', handleGenerateNoirEvent);
      window.addEventListener('ai-chat:generate-nor', handleGenerateNorEvent);
      window.addEventListener('ai-chat:add-message', handleAddMessage as EventListener);
      window.addEventListener('ai-chat:remove-message', handleRemoveMessage as EventListener);
      window.addEventListener('ai-chat:set-input-disabled', handleSetInputDisabled as EventListener);
      window.addEventListener('ai-chat:send-message', handleSendMessageEvent as EventListener);
      window.addEventListener('ai-chat:open-citation', handleOpenCitationEvent as EventListener);
      window.addEventListener('ai-chat:reset-chat', handleResetChatEvent as EventListener);

      return () => {
        window.removeEventListener('ai-chat:generate-noir', handleGenerateNoirEvent);
        window.removeEventListener('ai-chat:generate-nor', handleGenerateNorEvent);
        window.removeEventListener('ai-chat:add-message', handleAddMessage as EventListener);
        window.removeEventListener('ai-chat:remove-message', handleRemoveMessage as EventListener);
        window.removeEventListener('ai-chat:set-input-disabled', handleSetInputDisabled as EventListener);
        window.removeEventListener('ai-chat:send-message', handleSendMessageEvent as EventListener);
        window.removeEventListener('ai-chat:open-citation', handleOpenCitationEvent as EventListener);
        window.removeEventListener('ai-chat:reset-chat', handleResetChatEvent as EventListener);
      };
    }, [handleSend, planId]);

    return {
      messages,
      inputValue,
      isGenerating,
      isInputDisabled,
      recommendedActions,
      handleInputChange,
      handleSend,
      currentTab
    };
  };
