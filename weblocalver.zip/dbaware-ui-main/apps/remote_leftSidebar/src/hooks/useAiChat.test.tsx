import React from 'react';
import { render, screen, renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { useAiChat } from './useAiChat';
import * as sharedApi from '../api/sharedApi';

vi.mock('react-redux', async () => {
  const actual = await vi.importActual<typeof import('react-redux')>('react-redux');
  return {
    ...actual,
    useSelector: () => undefined,
  };
});

vi.mock('@wadk/ui', () => ({
  Button: ({ children, onClick, disabled }: any) => (
    <button type="button" onClick={onClick} disabled={disabled}>
      {children}
    </button>
  ),
  Stack: ({ children }: any) => <div>{children}</div>,
}));

vi.mock('com.db.rca.commons.afcc-components', () => ({
  AutoLoadingProgress: () => <div />,
}));

vi.mock('../components/AiChat/tabs/noir/NoirGenerationFlow', () => ({ NoirGenerationFlow: () => <div /> }));
vi.mock('../components/AiChat/tabs/noir/NoirEditFlow', () => ({ NoirEditFlow: () => <div /> }));
vi.mock('../components/AiChat/tabs/nor/NorGenerationFlow', () => ({ NorGenerationFlow: () => <div /> }));
vi.mock('../components/AiChat/tabs/nor/NorEditFlow', () => ({ NorEditFlow: () => <div /> }));
vi.mock('../components/AiChat/tabs/dataGatheringGeneration/DataGatheringGenerationFlow', () => ({
  DataGatheringGenerationFlow: () => <div />,
}));
vi.mock('../components/AiChat/tabs/scopeRecommendation/ScopeRecommendationUploadFlow', () => ({
  ScopeRecommendationUploadFlow: () => <div />,
}));
vi.mock('../components/AiChat/tabs/discoveryWalkthrough/DiscoveryWalkthroughUploadFlow', () => ({
  DiscoveryWalkthroughUploadFlow: () => <div />,
}));
vi.mock('../components/AiChat/tabs/testSteps/TestStepsUploadFlow', () => ({
  TestStepsUploadFlow: () => <div />,
}));

const createWrapper = (initialPath = '/preliminary-research/20583') => {
  return ({ children }: { children: React.ReactNode }) => (
    <MemoryRouter initialEntries={[initialPath]}>
      <Routes>
        <Route path="/dbaware-ui/:tab/:planId" element={<>{children}</>} />
        <Route path="/:tab/:planId" element={<>{children}</>} />
      </Routes>
    </MemoryRouter>
  );
};

describe('useAiChat', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.sessionStorage.clear();
    delete (window as any).__dbaware;
    window.history.pushState({}, '', '/');
  });

  it('resolves user_details from sessionStorage and approves pending workflow sending sections on RUN_ANALYTICS', async () => {
    window.sessionStorage.setItem(
      'scopingContext:20583',
      JSON.stringify({
        planNumber: '20583',
        processInstanceId: 'proc-77',
        taskId: 'task-77',
        taskDefinitionKey: 'PRELIMINARY_RESEARCH',
        reviewScopeId: '77',
        owner: 'reviewer@db.com',
      })
    );

    const getSpy = vi.fn().mockResolvedValue({});
    (window as any).__dbaware = { apiClient: { get: getSpy } };

    const postSpy = vi
      .spyOn(sharedApi, 'postJson')
      .mockResolvedValueOnce({
        response: {
          answer: '**Proposed Change**\n* Exclude GFMS Finding F-10',
          document_workflow: {
            stage: 'pending_approval',
            status: 'pending_approval',
            plan_id: 'wf-123',
            steps: [{ action: 'exclude', document_type: 'gfms', title: 'F-10' }],
          },
        },
      })
      .mockResolvedValueOnce({
        response: {
          answer: 'Applied change successfully.',
          affected_sections: ['broad_scope'],
        },
      })
      .mockResolvedValueOnce({ response: { status: 'started' } })
      .mockResolvedValueOnce({ response: { analysis_report: {} } });

    const refreshSpy = vi.fn();
    const workflowEventSpy = vi.fn();
    window.addEventListener('scoping:refresh-plan-status', refreshSpy);
    window.addEventListener('ai-chat:preliminary-research-workflow-executed', workflowEventSpy);

    const { result } = renderHook(() => useAiChat(), {
      wrapper: createWrapper('/preliminary-research/20583'),
    });

    await act(async () => {
      await result.current.handleSend('exclude finding F-10');
    });

    expect(postSpy).toHaveBeenCalledTimes(1);
    expect(postSpy.mock.calls[0][1]).toMatchObject({
      planNumber: '20583',
      action: 'QNA_CHAT',
      payload: {
        user_details: expect.objectContaining({
          review_scope_instance_id: 77,
          review_scope_id: 77,
          process_instance_id: 'proc-77',
          task_id: 'task-77',
          review_scope_stage: 'PRELIMINARY_RESEARCH',
          user: 'reviewer@db.com',
        }),
      },
    });

    const aiMsg = result.current.messages.find((m) => m.sender === 'ai');
    expect(aiMsg).toBeDefined();
    render(<>{aiMsg!.content}</>);
    expect(screen.getByText('1 proposed action(s) pending approval.')).toBeTruthy();

    await act(async () => {
      await result.current.handleSend('approve');
    });

    expect(postSpy.mock.calls[1][1]).toMatchObject({
      planNumber: '20583',
      action: 'QNA_DECIDE_DOCUMENT_ACTIONS',
      payload: { plan_id: 'wf-123', decision: 'approve' },
    });
    expect(postSpy.mock.calls[2][1]).toMatchObject({
      planNumber: '20583',
      action: 'RUN_ANALYTICS',
      payload: { sections: ['broad_scope'], sections_to_generate: ['broad_scope'] },
    });
    expect(workflowEventSpy).toHaveBeenCalledTimes(1);
    expect(refreshSpy).toHaveBeenCalledTimes(1);

    window.removeEventListener('scoping:refresh-plan-status', refreshSpy);
    window.removeEventListener('ai-chat:preliminary-research-workflow-executed', workflowEventSpy);
  });

  it('triggers refresh when QNA_CHAT directly returns executed workflow status', async () => {
    const getSpy = vi.fn().mockResolvedValue({ variables: { p_REVIEW_SCOPE_ID: 42 } });
    (window as any).__dbaware = { apiClient: { get: getSpy } };

    const postSpy = vi
      .spyOn(sharedApi, 'postJson')
      .mockResolvedValueOnce({
        response: {
          answer: 'Executed removal directly.',
          document_workflow: {
            stage: 'executed',
            status: 'executed',
            affected_sections: ['policy_regulation'],
          },
        },
      })
      .mockResolvedValueOnce({ response: { status: 'started' } })
      .mockResolvedValueOnce({ response: { analysis_report: {} } });

    const { result } = renderHook(() => useAiChat(), {
      wrapper: createWrapper('/preliminary-research/20590'),
    });

    await act(async () => {
      await result.current.handleSend('yes, exclude it');
    });

    expect(postSpy).toHaveBeenCalledWith('/dbaware-api-gateway/api/v1/actions', {
      planNumber: '20590',
      action: 'RUN_ANALYTICS',
      payload: expect.objectContaining({
        sections: ['policy_regulation'],
        sections_to_generate: ['policy_regulation'],
      }),
    });
  });

  it('clears chat messages when switching plans in MFE path', async () => {
    window.history.pushState({}, '', '/dbaware-ui/preliminary-research/20440');
    const { result, rerender } = renderHook(() => useAiChat(), {
      wrapper: createWrapper('/dbaware-ui/preliminary-research/20440'),
    });

    act(() => {
      window.dispatchEvent(new CustomEvent('ai-chat:add-message', { detail: { id: 'm1', sender: 'ai', content: 'Plan 20440 msg' } }));
    });
    expect(result.current.messages).toHaveLength(1);

    act(() => {
      window.history.pushState({}, '', '/dbaware-ui/preliminary-research/20583');
    });
    rerender();
    expect(result.current.messages).toHaveLength(0);
  });
});
