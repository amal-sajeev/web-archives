import React from 'react';
import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { useAiChat } from './useAiChat';
import * as sharedApi from '../api/sharedApi';

vi.mock('react-redux', async () => {
  const actual = await vi.importActual<typeof import('react-redux')>('react-redux');
  return {
    ...actual,
    useSelector: () => undefined,
  };
});

vi.mock('@wadk/ui', () => ({
  Stack: ({ children }: any) => <div>{children}</div>,
}));

vi.mock('com.db.rca.commons.afcc-components', () => ({
  AutoLoadingProgress: () => <div />,
}));

vi.mock('../components/AiChat/NoirGenerationFlow', () => ({ NoirGenerationFlow: () => <div /> }));
vi.mock('../components/AiChat/NoirEditFlow', () => ({ NoirEditFlow: () => <div /> }));
vi.mock('../components/AiChat/NorGenerationFlow', () => ({ NorGenerationFlow: () => <div /> }));
vi.mock('../components/AiChat/NorEditFlow', () => ({ NorEditFlow: () => <div /> }));
vi.mock('../components/AiChat/DataGatheringGenerationFlow', () => ({ DataGatheringGenerationFlow: () => <div /> }));
vi.mock('../components/AiChat/ScopeRecommendationUploadFlow', () => ({ ScopeRecommendationUploadFlow: () => <div /> }));
vi.mock('../components/AiChat/SequentialFadeList', () => ({ SequentialFadeList: () => <div /> }));

const createWrapper = (initialPath = '/preliminary-research/20440') => {
  return ({ children }: { children: React.ReactNode }) => (
    <MemoryRouter initialEntries={[initialPath]}>
      <Routes>
        <Route path="/:tab/:planId" element={<>{children}</>} />
      </Routes>
    </MemoryRouter>
  );
};

describe('useAiChat', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    window.history.pushState({}, '', '/preliminary-research/20440');
  });

  it('handles QNA workflow proposal and approval dispatching regeneration event', async () => {
    const postSpy = vi
      .spyOn(sharedApi, 'postJson')
      .mockResolvedValueOnce({
        response: {
          answer: '**Proposed Change**\n* Exclude GFMS Finding F-10',
          document_workflow: {
            stage: 'pending_approval',
            status: 'pending_approval',
            plan_id: 'wf-123',
            plan_number: '20440',
            requires_approval: true,
          },
        },
      })
      .mockResolvedValueOnce({
        response: {
          answer: 'Applied change successfully.',
          document_workflow: {
            stage: 'executed',
            status: 'executed',
            plan_id: 'wf-123',
            plan_number: '20440',
            affected_sections: ['findings_analysis', 'broad_scope'],
          },
        },
      });

    const workflowEventSpy = vi.fn();
    window.addEventListener('ai-chat:preliminary-research-workflow-executed', workflowEventSpy);

    const { result } = renderHook(() => useAiChat(), {
      wrapper: createWrapper('/preliminary-research/20440'),
    });

    act(() => {
      result.current.handleInputChange('exclude finding F-10');
    });
    expect(result.current.inputValue).toBe('exclude finding F-10');

    await act(async () => {
      await result.current.handleSend();
    });

    expect(postSpy).toHaveBeenCalledTimes(1);
    const aiProposalMsg = result.current.messages.find((m) => m.sender === 'ai');
    expect(aiProposalMsg?.workflowState).toMatchObject({
      status: 'pending_approval',
      planId: 'wf-123',
      requiresApproval: true,
    });

    await act(async () => {
      await result.current.handleWorkflowDecision('approve', aiProposalMsg?.id);
    });

    expect(postSpy).toHaveBeenCalledTimes(2);
    expect(workflowEventSpy).toHaveBeenCalledTimes(1);
    expect((workflowEventSpy.mock.calls[0][0] as CustomEvent).detail).toMatchObject({
      planId: '20440',
      workflowPlanId: 'wf-123',
      affectedSections: ['findings_analysis', 'broad_scope'],
    });
    const updatedProposalMsg = result.current.messages.find((m) => m.id === aiProposalMsg?.id);
    expect(updatedProposalMsg?.workflowState?.resolvedDecision).toBe('approve');

    window.removeEventListener('ai-chat:preliminary-research-workflow-executed', workflowEventSpy);
  });

  it('handles reject decision, QNA error fallback, and window chat events', async () => {
    vi.spyOn(sharedApi, 'postJson').mockRejectedValue(new Error('network fail'));

    const { result } = renderHook(() => useAiChat(), {
      wrapper: createWrapper('/preliminary-research/20440'),
    });

    await act(async () => {
      await result.current.handleSend('hello?');
    });

    expect(result.current.messages).toHaveLength(2);

    act(() => {
      window.dispatchEvent(
        new CustomEvent('ai-chat:add-message', { detail: { id: 'custom-1', sender: 'ai', content: 'Hi' } })
      );
      window.dispatchEvent(new CustomEvent('ai-chat:set-input-disabled', { detail: { disabled: true } }));
    });
    expect(result.current.isInputDisabled).toBe(true);
    expect(result.current.messages.some((m) => m.id === 'custom-1')).toBe(true);

    act(() => {
      window.dispatchEvent(new CustomEvent('ai-chat:remove-message', { detail: { id: 'custom-1' } }));
    });
    expect(result.current.messages.some((m) => m.id === 'custom-1')).toBe(false);

    await act(async () => {
      await result.current.handleWorkflowDecision('reject', 'non-existent');
    });

    act(() => {
      window.dispatchEvent(new CustomEvent('ai-chat:reset-chat'));
    });
    expect(result.current.messages).toHaveLength(0);
  });
});
