import { useState, useEffect } from 'react';

export const useCurrentPath = () => {
  const [path, setPath] = useState(window.location.pathname);

  useEffect(() => {
    const handleLocationChange = () => {
      setPath(window.location.pathname);
    };

    // Override pushState and replaceState to catch react-router navigation
    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;

    window.history.pushState = function (...args) {
      const result = originalPushState.apply(this, args);
      handleLocationChange();
      return result;
    };

    window.history.replaceState = function (...args) {
      const result = originalReplaceState.apply(this, args);
      handleLocationChange();
      return result;
    };

    window.addEventListener('popstate', handleLocationChange);

    // Fallback for microfrontend environments where router history might be isolated
    const intervalId = setInterval(() => {
      setPath(prevPath => {
        if (prevPath !== window.location.pathname) {
          return window.location.pathname;
        }
        return prevPath;
      });
    }, 100);

    return () => {
      window.history.pushState = originalPushState;
      window.history.replaceState = originalReplaceState;
      window.removeEventListener('popstate', handleLocationChange);
      clearInterval(intervalId);
    };
  }, []);

  return path;
};
