import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const rootDir = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@wadk/ui': path.resolve(rootDir, 'src/test/mocks/wadkUi.tsx'),
      '@wadk/icons': path.resolve(rootDir, 'src/test/mocks/wadkIcons.tsx'),
      'com.db.rca.commons.afcc-components': path.resolve(rootDir, 'src/test/mocks/afccComponents.tsx'),
    },
  },
  test: {
    environment: 'jsdom',
    setupFiles: [path.resolve(rootDir, 'src/test/setupTests.ts')],
    coverage: {
      provider: 'v8',
      include: [
        'src/api/preliminaryResearchClient.ts',
        'src/api/sharedApi.ts',
        'src/hooks/useAiChat.tsx',
        'src/hooks/useCurrentPath.ts',
        'src/store/aiChatSlice.ts',
        'src/components/AiChat/AiChatContainer.tsx',
        'src/components/AiChat/AiChatModeMenu/AiChatModeMenu.tsx',
      ],
    },
  },
});
