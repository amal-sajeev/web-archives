import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setupTests.ts'],
    coverage: {
      provider: 'v8',
      include: [
        'src/api/preliminaryResearchClient.ts',
        'src/api/sharedApi.ts',
        'src/hooks/useAiChat.tsx',
        'src/hooks/useCurrentPath.ts',
        'src/store/aiChatSlice.ts',
        'src/components/AiChat/AiChatContainer.tsx',
        'src/components/AiChat/AiChatModeMenu/AiChatModeMenu.tsx',
      ],
    },
  },
});
