export const Dashboard = () => <div>Mock Dashboard</div>;
