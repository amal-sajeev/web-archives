export const LeftSidebar = () => <div>Mock Left Sidebar</div>;
