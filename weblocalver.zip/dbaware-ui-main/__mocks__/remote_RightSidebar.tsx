export const RightSidebar = () => <div>Mock Right Sidebar</div>;
