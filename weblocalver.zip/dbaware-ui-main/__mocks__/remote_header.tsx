export const Header = () => <div>Mock Header</div>;
