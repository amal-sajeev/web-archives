# WADK UI & Form Component Guide

This document is the **strict reference guide** for implementing form controls using `@wadk/ui` and internal shared wrappers in the `dbaware-ui` application. Any AI agent or developer building UI features MUST adhere to these structural rules.

---

## 1. The Golden Rule of WADK Forms

Native `@wadk/ui` input primitives (`TextInput`, `SelectInput`, `Checkbox`, `RadioButton`, `DateInput`, `NumberInput`, `TextArea`) **CANNOT** be used standalone. They lack built-in label and layout management. They **MUST** be wrapped in a `<FormGroup>` and `<FormItem>`.

### Standard Implementation Pattern
```tsx
import { FormGroup, FormItem, TextInput } from '@wadk/ui';

// CORRECT
<FormGroup direction="vertical" id="unique-field-id" label="Field Label" required>
    <FormItem>
        {/* DO NOT pass a `type` prop to TextInput. It does not exist on the type definition. */}
        <TextInput 
            id="unique-field-id"
            value={value} 
            onChange={handleChange} 
            readOnly={isReadOnly} 
        />
    </FormItem>
</FormGroup>

// INCORRECT (Missing Wrappers or passing invalid props)
<TextInput type="text" value={value} onChange={handleChange} />
```

### Grouping Multiple Inputs (Radios/Checkboxes)
When grouping multiple `RadioButton` or `Checkbox` components under a single label, wrap the entire group container inside the `<FormItem>`.
```tsx
<FormGroup direction="vertical" id="statusGroup" label="Status">
    <FormItem>
        <div className="flex-row-gap">
            <RadioButton name="status" label="Active" checked={isActive} />
            <RadioButton name="status" label="Inactive" checked={!isActive} />
        </div>
    </FormItem>
</FormGroup>
```

### SelectInput Implementation Rule
The `<SelectInput>` component **DOES NOT** accept `children` (e.g., `<option>` tags). You **MUST** pass the options array to the `model` prop. The array must be of type `{ label: string; value: string | number }[]`.

```tsx
import { SelectInput } from '@wadk/ui';

// CORRECT
<SelectInput
    id="mySelect"
    value={selectedValue}
    onValueChange={handleValueChange}
    model={[
        { label: 'Option 1', value: '1' },
        { label: 'Option 2', value: '2' }
    ]}
/>

// INCORRECT
<SelectInput value={selectedValue} onValueChange={handleValueChange}>
    <option value="1">Option 1</option>
</SelectInput>
```

### 2. WADK Specific Prop Rules (CRITICAL)
- **`TextInput`:**
  - **NEVER** use `onValueChange`. You MUST use the standard React `onChange` prop (e.g., `onChange={(e) => onChange('fieldName', e.target.value)}`).
- **`SelectInput`:** 
  - **NEVER** use HTML `<option>` children. You MUST use the `model` prop: `model={[{ label: 'A', value: '1' }]}`.
  - **NEVER** use `onChange`. You MUST use `onValueChange={(val: string | string[]) => void}`.

---

## 3. Custom Internal Wrappers

The project contains several custom wrapper components that **ALREADY** implement `FormGroup` and `FormItem` internally. **NEVER wrap these in another `FormGroup` or `FormItem`**. Doing so causes layout nesting errors and duplicate labels.

### A. `TextAreaWithCounter`
**Path:** `src/components/shared/TextAreaWithCounter.tsx`
- **Purpose:** Standard component for text areas requiring strict character limits.
- **Wrappers:** NONE. Do not wrap.
- **Key Props (Strict Typing):**
  - `label` (`ReactNode`): The label text.
  - `value` (`string`): The controlled value.
  - `onChange` (`(value: string) => void`): Note this returns a string directly, not an Event object.
  - `maxLength` (`number`): The character limit.
  - `readonly` (`boolean`): Note the lowercase `readonly` (not `readOnly`).
  - `required` (`boolean`): Adds the required asterisk.
  - `layout` (`'vertical' | 'horizontal'`): Controls the internal `FormGroup` direction.

**Example Usage:**
```tsx
import TextAreaWithCounter from '@components/shared/TextAreaWithCounter';

<TextAreaWithCounter
    id="controlDescription"
    label="Control Description"
    layout="vertical"
    value={data.description}
    onChange={(val) => handleDataChange('description', val)}
    maxLength={2000}
    readonly={isReadOnly}
    required
/>
```

### B. Extended Inputs (`TextInputExtended`, `SelectInputExtended`, etc.)
**Path:** `src/components/shared/wadk/InputExtendedProps.tsx`
- **Purpose:** Used primarily in older or specific sub-modules that map simple standalone inputs to internal error states.
- **Wrappers:** NONE. Do not wrap.
- **Key Props:**
  - `label` (`string`)
  - `error` (`string`)
  - `labelDirection` (`'row' | 'column'`)

### C. Search Component Implementation Pattern
When implementing search functionality with `@wadk/ui` that requires an async API call, you MUST use a specific multi-component pattern. **Do not hallucinate `loading` or `onSelect` props on the input itself.**
1. **`<SearchInput>`**: Captures user input via the `onSearch` prop.
2. **`<ValueList>`**: Displays the results. Its `model` prop requires an array of `ValueListItemBase` objects (`{id, label, description}`). The `columns` prop is mandatory. Handle selections via the `onSelect` prop.
3. **`<Spinner>`**: Use a separate WADK `<Spinner />` for loading states. Conditionally render the Spinner or the ValueList based on your `isLoading` state.

---

## 4. Form Layout & Styling

- **Flex Layouts**: Use Vanilla CSS Modules (`display: flex`, `gap`, `flex-direction`) for arranging `FormGroup` components side-by-side or stacked.
- **Do Not Use Tailwind**: Always use native CSS mapping to WADK CSS Custom Properties (e.g., `var(--wadk-space-4)`).
- **Responsive Widths**: Use `flex: 1` on form groups to ensure they scale evenly across standard grid layouts.

---

## 5. Exact @wadk/ui TypeScript API Reference

The following are the exact prop definitions extracted directly from the `@wadk/ui` library.

### `FormGroupProps`
```typescript
type FormGroupProps = {
    id: string;
    required?: boolean;
    label?: string;
    className?: string;
    children: React.ReactElement;
    subLabel?: string;
    hint?: {
        content: React.ReactElement | string;
        title?: string;
        placement?: string;
    };
    direction?: 'vertical' | 'horizontal' | GridLayoutType;
};
```

### `FormItemProps`
```typescript
type FormItemProps = {
    invalid?: boolean;
    error?: ItemError;
    infoMessage?: string;
    children: ReactElement;
    validationStatus?: ValidationStatus;
    defaultMessage?: string;
};
```

### `TextInputProps`
```typescript
type TextInputProps = {
    maxLength?: number;
} & Omit<BaseInputProps, 'type'>;

type BaseInputProps = {
    autoComplete?: string;
    autoFocus?: boolean;
    name?: string;
    type: 'text' | 'number' | 'date' | 'search' | 'file' | 'time';
    defaultValue?: string | ReadonlyArray<string> | number | undefined;
    tabIndex?: number;
    value?: string | ReadonlyArray<string> | number | undefined;
    placeholder?: string;
    onClick?: React.MouseEventHandler<HTMLInputElement>;
    onChange?: React.ChangeEventHandler<HTMLInputElement>;
    onFocus?: React.FocusEventHandler<HTMLInputElement>;
    onBlur?: React.FocusEventHandler<HTMLInputElement>;
    onKeyDown?: React.KeyboardEventHandler<HTMLInputElement>;
    onKeyUp?: React.KeyboardEventHandler<HTMLInputElement>;
    className?: string;
    style?: CSSProperties;
    variant?: InputVariant;
    disabled?: boolean;
    readOnly?: boolean;
}
```

### `TextAreaProps`
```typescript
type TextAreaProps = {
    variant?: InputVariant;
    resizable?: 'vertical' | 'horizontal' | 'both' | 'none';
} & React.TextareaHTMLAttributes<HTMLTextAreaElement>;
```

### `RadioButtonProps`
```typescript
type RadioButtonProps = {
    id?: string;
    name?: string;
    checked?: boolean;
    value: string | number;
    disabled?: boolean;
    className?: string;
    onChange?: (value: string | number) => void; // Note: returns value directly, not event
    label: string;
    labelNoWrap?: boolean;
} & React.HTMLAttributes<HTMLInputElement>;
```

### `CheckboxProps`
```typescript
type CheckboxProps = {
    checked?: boolean;
    isIndeterminate?: boolean;
    label?: string;
    disabled?: boolean;
    onChange?: (value: boolean) => void; // Note: returns boolean directly, not event
    value?: string;
    tabIndex?: number;
    index?: number;
} & Omit<React.HTMLAttributes<HTMLElement>, 'onChange'>;
```

### `SelectInputProps`
```typescript
type SelectInputProps = {
    required?: boolean;
    searchable?: boolean;
    variant?: InputVariant;
    onSearch?: (query: string) => void;
    onKeyDown?: (e: React.KeyboardEvent) => void;
    hideSelectAll?: boolean;
    disableChevron?: boolean;
    selectionMode?: 'single' | 'multiple';
    onValueChange?: (newVal: string | string[]) => void;
} & Omit<WithMenuProps, 'anchor'> & Omit<SelectInputBaseProps, 'value'>;
```

## 6. Official Figma Code Connect Snippets

When mapping Figma layouts to React, ALWAYS use these exact Code Connect structures for the respective components:

### Radio Button Group
``tsx
import { RadioButtonGroup, RadioButton } from "@wadk/ui"
<RadioButtonGroup name="group_name" value={stateValue} onChange={handleChange}>
  <RadioButton label="Yes" value="yes" />
  <RadioButton label="No" value="no" />
</RadioButtonGroup>
``

### Checkbox Group
``tsx
import { CheckboxGroup, Checkbox } from "@wadk/ui"
<CheckboxGroup value={selectedValues} onChange={handleChange}>
  <Checkbox label="Option 1" value="1" />
  <Checkbox label="Option 2" value="2" />
</CheckboxGroup>
``

### Select Input
``tsx
import { SelectInput } from "@wadk/ui"
<SelectInput model={[]} placeholder="Select..." onValueChange={handleChange} />
``

### Search Input
``tsx
import { SearchInput } from "@wadk/ui"
<SearchInput placeholder="Search" onSearch={() => {}} onChange={handleChange} />
``

### Text Input (Read Only)
``tsx
import { TextInput } from "@wadk/ui"
<TextInput placeholder="-" readOnly readOnlySilently />
``

## 7. AI Components Implementation Pattern

When implementing AI interfaces, such as chat or prompt input panels, you MUST use the specialized AI components from `com.db.rca.commons.afcc-components`.

### AI Input Panel Structure

Always use `AiInputPanelContent` and `AiInputPanelTextarea` following this exact structure:

```tsx
import { AiInputPanelContent, AiInputPanelTextarea } from "com.db.rca.commons.afcc-components"
// Assuming Button, Stack, Screenshot, AttachSolid are imported from @wadk/ui or @wadk/icons

<AiInputPanelContent
  actions={
    <>
      <Button
        icon={<Screenshot />}
        variant="link"
      ></Button>
      <Button
        icon={<AttachSolid />}
        variant="link"
      ></Button>
    </>
  }
>
  <Stack
    direction="row"
    gap="sm"
  ></Stack>
  <AiInputPanelTextarea defaultValue="Ask Anything...." />
</AiInputPanelContent>
```
