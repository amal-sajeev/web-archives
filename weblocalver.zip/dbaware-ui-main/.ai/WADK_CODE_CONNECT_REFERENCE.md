# WADK UI Figma Code Connect Reference (AI Translation Guide)

This document is the **EXHAUSTIVE, error-proof source of truth** for translating Figma designs into `@wadk/ui` React components. 

To prevent AI hallucination, missing props, or incorrect nesting (e.g., passing `<option>` to `SelectInput` instead of using the `model` prop), this guide provides the **EXACT usage snippets and strict prop rules** for every component category.

---

## 1. Forms & Form Controls (CRITICAL)

**ABSOLUTE RULE:** Every WADK input primitive MUST be wrapped in a `<FormGroup>` and `<FormItem>`. You cannot use `TextInput` or `SelectInput` directly on the page without this wrapper layout.

**ANTI-PATTERN WARNING:** Do **NOT** pass standard HTML attributes like `className` or `style` directly to `<FormItem>`. WADK's `<FormItem>` does not extend standard `HTMLAttributes` and will throw a TypeScript error. Use `<Box>` wrappers or CSS targeting if specific layout constraints are needed beyond what WADK provides natively.

### A. Radio Buttons
`RadioButtonGroup` must wrap individual `RadioButton` components.
```tsx
import { FormGroup, FormItem, RadioButtonGroup, RadioButton } from "@wadk/ui";

<FormGroup id="status-group" label="Status" direction="vertical" required>
  <FormItem>
    <RadioButtonGroup 
      name="status" 
      value={currentValue} 
      onValueChange={(val?: string | number) => handleChange(val)}
      orientation="row" // 'row' | 'column'
    >
      <RadioButton label="Active" value="active" />
      <RadioButton label="Inactive" value="inactive" disabled />
    </RadioButtonGroup>
  </FormItem>
</FormGroup>
```

### B. Checkboxes
Use `CheckboxGroup` for arrays of selections, or a standalone `Checkbox` for a single boolean toggle.
```tsx
import { FormGroup, FormItem, CheckboxGroup, Checkbox } from "@wadk/ui";

<FormGroup id="roles-group" label="Roles">
  <FormItem>
    <CheckboxGroup 
      value={selectedRolesArray} 
      onValueChange={(vals?: string[]) => setRoles(vals || [])}
      orientation="column" // 'row' | 'column'
    >
      <Checkbox label="Admin" value="admin" />
      <Checkbox label="User" value="user" />
    </CheckboxGroup>
  </FormItem>
</FormGroup>

// Standalone boolean
<Checkbox 
  label="I agree to terms" 
  checked={isAgreed} 
  onChange={(val: boolean) => setAgreed(val)} 
/>
```

### C. Select Input (Dropdown)
**NEVER** use `<option>` tags. You MUST pass an array of `{ label: string, value: string }` to the `model` prop.
```tsx
import { FormGroup, FormItem, SelectInput } from "@wadk/ui";

<FormGroup id="country-select" label="Country">
  <FormItem>
    <SelectInput
      placeholder="Select Country..."
      model={[
        { label: 'United States', value: 'US' },
        { label: 'Germany', value: 'DE' }
      ]}
      selectionMode="single" // or 'multiple'
      value={selectedValue}
      onValueChange={(val: string | string[]) => handleSelect(val)}
    />
  </FormItem>
</FormGroup>
```

### D. Text & Text Area Inputs
`onChange` returns a standard React SyntheticEvent, but always check project context if internal wrappers simplify this.
```tsx
import { FormGroup, FormItem, TextInput, TextArea } from "@wadk/ui";

<FormGroup id="name-input" label="Full Name">
  <FormItem>
    <TextInput 
      placeholder="Enter name" 
      value={name} 
      onChange={(e) => setName(e.target.value)}
      maxLength={100}
    />
  </FormItem>
</FormGroup>

<FormGroup id="desc-input" label="Description">
  <FormItem>
    <TextArea 
      placeholder="Enter details" 
      value={desc} 
      onChange={(e) => setDesc(e.target.value)}
      resizable="none" // 'vertical' | 'horizontal' | 'both' | 'none'
    />
  </FormItem>
</FormGroup>
```

### E. Date & Number Inputs
```tsx
import { FormGroup, FormItem, DateInput, NumberInput } from "@wadk/ui";

<FormGroup id="start-date" label="Start Date">
  <FormItem>
    <DateInput 
      value={dateValue} 
      onChange={(date) => setDateValue(date)} 
    />
  </FormItem>
</FormGroup>

<FormGroup id="amount" label="Amount">
  <FormItem>
    <NumberInput 
      value={amount} 
      onValueChange={(val: number) => setAmount(val)} 
      placeholder="0.00"
    />
  </FormItem>
</FormGroup>
```

### F. Search Input
Used for dedicated search bars. Uses `onSearch` instead of `onChange`.
```tsx
import { FormGroup, FormItem, SearchInput } from "@wadk/ui";

<FormGroup id="search-group">
  <FormItem>
    <SearchInput 
      searchTerm={query}
      onSearch={(term: string) => setQuery(term)} 
      mode="delayed" // 'instant' | 'delayed' | 'manual'
      debounceMs={300}
    />
  </FormItem>
</FormGroup>
```

### G. Form Validation & Errors
To display validation errors, pass `invalid` and an `error` object (not a string) to `FormItem`.
```tsx
<FormGroup id="email-group" label="Email" required>
  <FormItem 
    invalid={hasError} 
    error={hasError ? { type: 'danger', message: 'Invalid email address' } : undefined}
  >
    <TextInput value={email} onChange={(e) => setEmail(e.target.value)} />
  </FormItem>
</FormGroup>
```

---

## 2. Layout Primitives (Figma Auto Layout)

Map Figma properties exactly to these layout wrappers.

### Stack (Flexbox)
For pure alignment without padding or borders.
```tsx
import { Stack } from "@wadk/ui";

// Figma: Flex:row, justify:SPACE_BETWEEN, align:CENTER, gap:16
<Stack direction="row" justifyContent="space-between" align="center" gap="lg" grow={1}>
  {children}
</Stack>
```

### Box (Flexbox + Spacing)
Extends `Stack`. Use when the node has padding/margin.
```tsx
import { Box } from "@wadk/ui";

// Figma: pT:16, pB:16, pL:24, pR:24
<Box paddingY="md" paddingX="lg" direction="column">
  {children}
</Box>
```

### Surface (Containers with Visuals)
Extends `Box`. Use when there are fills (backgrounds), borders, or shadows.
```tsx
import { Surface } from "@wadk/ui";

// Figma: Radius:8, Shadow, Background
<Surface padding="base" radius="md" raise="1-base" shade="light" outlined>
  {children}
</Surface>
```

---

## 3. Buttons & Typography

### Buttons
```tsx
import { Button, OutlineButton, LightButton } from "@wadk/ui";

<Button variant="standard" size="md" loading={false}>Submit</Button>
<OutlineButton>Cancel</OutlineButton>
<LightButton icon={<YourIconComponent />}>Actions</LightButton>
```

### Typography
```tsx
import { Text, Heading, Paragraph, Label } from "@wadk/ui";

<Heading level="1" nowrap>Dashboard</Heading>
<Text variant="secondary" fontWeight="bold">Active Status</Text>
<Paragraph>Long text block mapping to Figma text node.</Paragraph>
<Label required>Standalone Field Label</Label>
```

---

## 4. Overlays & Context Menus

### Tooltip
Wrap the trigger element directly.
```tsx
import { Tooltip } from "@wadk/ui";

<Tooltip content="Helper text goes here" placement="top">
  <IconComponent />
</Tooltip>
```

### Modal & Modal Dialog
Use the `actions` prop in `ModalContent` to natively render footer buttons.

```tsx
import { ModalDialog } from "@wadk/ui";

// (Note: The library exports ModalDialog or you can build it with ModalContent manually,
// but ModalDialog is the standard wrapper for full dialogs)

<ModalDialog
  opened={isOpen}
  onClose={() => setIsOpen(false)}
  title="Confirm Action"
  width="md"
  actions={[
    {
      name: "Cancel",
      variant: "standard", // Maps to Outline or Standard style depending on WADK version context
      callback: () => setIsOpen(false),
      position: "left"
    },
    {
      name: "Confirm",
      variant: "danger",
      callback: handleConfirm,
      position: "right"
    }
  ]}
>
  <Paragraph>Are you sure you want to proceed?</Paragraph>
</ModalDialog>
```

---

## 5. Accordions & Data Display

**ANTI-PATTERN WARNING:** NEVER build expandable or collapsible layouts manually using standard HTML like `div` or custom chevrons. You MUST use WADK's `<Accordion>` semantic components.

### Accordion
```tsx
import { Accordion, AccordionItem } from "@wadk/ui";

<Accordion variant="standard" collapseStrategy="free-for-all">
  <AccordionItem title="Risk Details">
    <Text>Content goes here.</Text>
  </AccordionItem>
</Accordion>
```