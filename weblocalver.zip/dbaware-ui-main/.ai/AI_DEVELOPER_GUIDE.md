# AI Developer Guide (IQ200 Protocol)

This guide outlines the **strict operational protocol** for any AI agent or LLM interacting with the `dbaware-ui` repository. It is the absolute entry point for all AI operations.

## 1. Mandatory Initialization Cascade
Before starting any task, the AI MUST load and understand the following context:
- `.ai/GEMINI.md`: Understand the MFE Architecture, State Migration strategy (Redux to Apollo/GraphQL), Folder Structure, and Coding Standards. **Never violate GEMINI.md.**
- `.ai/IMPLEMENTATION_CONTEXT.md`: The active feature's business logic, UI mapping, and API/GraphQL details.
- `.ai/PROGRESS.md`: The exact state of the current implementation sprint.

## 2. Autonomous Research & Strategy Protocol
- **Architecture First**: Always identify whether the target component is Host-level orchestration, a Remote Top-Level Page, or a Remote Sub-Component.
- **Migration Awareness**: When analyzing legacy code or building new features, always structure the data-fetching layer (Container) to be easily swappable to GraphQL + Apollo Client. If Redux is still required temporarily, isolate it.
- **Do not ask for permission to read**: You are authorized to read files, list directories, and use search tools (e.g., `grep_search`, `glob`) to build your context.

## 3. Strict Implementation Constraints
- **Module Federation Boundaries**: NEVER import files across `apps/` boundaries (e.g., `remote_dashboard` cannot import from `remote_header`). All sharing must happen via the Host or an explicit shared library.
- **Scope Boundaries**: Implement ONLY the requested feature. Do not perform unrelated refactoring.
- **Type Safety**: Use `import type { ... }` for all TypeScript interfaces. NEVER use `any`.
- **Zero Assumption Policy (CRITICAL)**: Never self-authorize architectural decisions. If the architecture is ambiguous, present a Plan based on `GEMINI.md` and await confirmation.

## 4. Implementation Priority & Conflict Resolution
**Priority Ranking:**
1. `.ai/GEMINI.md` & `.ai/AI_DEVELOPER_GUIDE.md`
2. GraphQL Schema / API Contracts (If provided)
3. Explicit User Prompts
4. Existing Workspace Conventions

**Conflict Resolution Rules:**
- Architecture always wins.
- New GraphQL endpoints win over Legacy REST API.
- **Never violate architecture.**

## 5. Execution Lifecycle
You must follow this exact lifecycle for every task:

**STAGE 1: Discovery, Strategy & MFE Triage (Plan Mode)**
- **MFE Identification & Routing**: 
  - Based on the feature domain, explicitly determine the correct target remote (e.g., `remote_dashboard`, `remote_planning`).
  - If a new route is required, define how the Host will expose it, and how the Remote will handle internal sub-routing.
- **Component Breakdown (Container/Presenter)**:
  - Break down the provided UI (screen/mockup) into logical, reusable components.
  - Separate stateful data-fetching (Container) from stateless UI rendering (Presenter).
- **Context Isolation**: Update or generate a completely new `IMPLEMENTATION_CONTEXT.md` for every new feature request, overwriting any previous feature's context.
- **State Strategy**: Plan the state layer integration (Apollo `useQuery`/`useMutation`, or Redux if transitional).

**STAGE 2: Local Setup & MFE Configuration**
- **Dependency & Port Verification**: Ensure the target MFE (`apps/remote_[name]`) has its designated port configured in its `vite.config.ts` and the Host's `vite.config.ts`.
- **Local Runner Check**: Instruct the user (if necessary) on which scripts to run (e.g., `npm run start:dashboard` or `npm run start` for full suite) to view the MFE locally.
- **Mocking**: Setup MSW handlers in the specific remote if the backend API/GraphQL is not yet available, ensuring local dev is unblocked.

**STAGE 3: React UI Implementation & API Integration (Execution)**
- Execute the component implementation covering:
  - Strict UI encapsulation via CSS Modules.
  - Business Logic & Calculations inside Custom Hooks.
  - Integration with Apollo `useQuery`/`useMutation` (or Redux if transitional).
  - Loading, Empty States, and Error Boundaries.

**STAGE 3: Validation & QA**
- Ensure Type Safety (run `tsc` if necessary).
- Verify standard UI library usage.
- Check cross-MFE boundaries.

**STAGE 4: Final Output (Reporting)**
- Provide a final summary containing files modified, reused components, and implemented rules.
- Update `PROGRESS.md` immediately.

## 6. Continuous Documentation
- **IMPLEMENTATION_CONTEXT.md**: Generate/update this file for each new feature to isolate context.
- **PROGRESS.md**: Maintain an immutable save-state of current tasks. Update immediately after completing a discrete task.

## 7. Mandatory Verification Loop
Before concluding any response:
1. Ensure no `any` types were introduced.
2. Ensure no cross-app imports exist.
3. Ensure no placeholder comments exist (e.g., `// Add logic here`).

---
*Follow this guide rigidly. Employ maximum analytical rigor (IQ200 standard) for every decision.*