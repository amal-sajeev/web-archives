# GEMINI.md: The Master Architecture Document

This document is the **absolute single source of truth** for the `dbaware-ui` project. It defines a highly scalable, fault-tolerant React Micro-Frontend (MFE) architecture designed for long-term enterprise maintainability. All AI agents and developers MUST rigidly follow these guidelines.

## 1. Project Overview & Domain
- **Project Purpose**: dbaware-ui is an Enterprise Audit Management System for Deutsche Bank (DB).
- **Core Features**: Audit Planning, Fieldwork Management, Dashboards, and Administration.
- **Target Architecture Standard**: A highly scalable Vite Module Federation MFE. The Host acts purely as an integration shell and provider registry. Remotes act as autonomous, bounded-context feature domains.

## 2. Micro-Frontend (MFE) Architecture Rules

### 2.1. The Host (Shell)
- **Responsibility**: Orchestration. It manages the global `BrowserRouter`, centralized providers (Redux, Apollo, Theme Context), global layouts (Navigation/Sidebars), and fallback Error Boundaries.
- **Constraint**: The Host must contain minimal business logic. It should never render feature-level data directly.
- **Fault Tolerance**: ALL remote imports MUST be wrapped in a React `<Suspense>` boundary and a custom `<ErrorBoundary>`. A failing remote must **never** crash the host or other remotes.

### 2.2. The Remotes (Micro-Frontends)
- **Responsibility**: Bounded Contexts (e.g., `remote_dashboard`, `remote_planning`).
- **Constraint**: Remotes MUST NOT import modules from each other at build time. Cross-remote communication must happen via shared Host context, URL routing parameters, or global event buses (if absolutely necessary).
- **Exposure**: Expose tightly scoped functional components, not entire single-page applications.

### 2.3. Shared Dependencies (Module Federation)
- Core libraries (`react`, `react-dom`, `react-router-dom`, `@apollo/client`, `react-redux`) are marked as singletons in `vite.config.ts`. The Host enforces the version to prevent multiple React instances or memory leaks.

## 3. The Great State Migration: Redux -> GraphQL + Apollo Client

We are currently transitioning our server-state management to **GraphQL and Apollo Client**. This is the core of our future-proof MFE architecture.

### 3.1. Current State (Legacy/Transitional)
- **Redux Toolkit**: Used for both client and server state. Employs a dynamic Reducer Manager so Remotes can inject their own slices into the Host's global store at runtime.
- **Axios**: Used for RESTful API calls.

### 3.2. Future State (Target Architecture)
- **Apollo Client**: The single source of truth for **all server-state**. It will replace Axios and Redux Thunks.
  - **In-Memory Cache**: Apollo's normalized cache will automatically deduplicate fetches across different MFEs.
  - **Provider**: The `<ApolloProvider>` sits exclusively at the Host level. Remotes consume GraphQL via standard `useQuery` / `useMutation` hooks.
- **Client State**: Redux will be entirely deprecated or relegated ONLY to complex, multi-step UI client state (like multi-page form wizards). Local component state (`useState`, `useReducer`) and React Context will handle 95% of client-side needs.
- **Migration Path**: All new features must be designed with clean API abstractions so they can seamlessly swap their underlying data layer to Apollo when the GraphQL endpoints are ready.

## 4. Coding & React Standards (IQ200 Guidelines)

- **Strict Composition over Configuration**: Avoid passing giant JSON configuration objects to components. Use React's `children` API to compose layouts flexibly.
- **Container/Presenter Pattern**: Separate data-fetching (Container) from UI rendering (Presenter). The Presenter must be a pure function of its props, easily testable without Apollo/Redux providers.
- **Custom Hooks for Logic**: Any component exceeding 150 lines is likely doing too much. Extract business logic, state derivation, and data fetching into custom hooks (e.g., `useAuditPlanning()`).
- **Memoization & Rerenders**: Use `useMemo` for heavy transformations (e.g., parsing large data sets for AG Grid). Use `useCallback` for functions passed to deeply nested child components. Avoid premature optimization, but strictly prevent root-level re-renders on keystrokes in forms.
- **Controlled Components**: All forms must be strictly controlled, utilizing specialized hooks for draft state.

## 5. TypeScript Standards (Strict)

- **No `any`**: The use of `any` is strictly forbidden. Use `unknown` with type-guards.
- **Explicit Return Types**: All custom hooks and API abstraction functions must have explicit return types to aid inference across MFE boundaries.
- **Type-Only Imports**: Because `verbatimModuleSyntax` is enabled, you MUST use `import type { X } from '...'` for all interfaces/types.
- **DTOs vs. View Models**: Distinguish between the data shape from the API (Data Transfer Object) and the shape required by the UI (View Model). Map them explicitly at the service boundary.

## 6. Styling & UI Abstractions

- **CSS Modules**: Strict usage of `[Name].module.css` to enforce CSS encapsulation. Global CSS is forbidden outside of the Host's CSS reset and theme variable definition.
- **Design Tokens**: Rely exclusively on CSS variables (`var(--wadk-color-primary)`) for theming. Never hardcode hex colors.
- **Component Library**: Utilize `@wadk/ui` primitives. Never build native HTML equivalents if a UI kit component exists.

## 7. Routing & Navigation

- **Centralized Router**: `BrowserRouter` lives in the Host.
- **Remote Routing**: Remotes may use descendant `<Routes>` but must relative match (e.g., `path="dashboard/*"`).
- **Navigation State**: Pass transient state (like success notifications) via the React Router `state` object, not global Redux.

## 8. Development & Workflow

### 8.1. Screen Breakdown & MFE Assignment (Mandatory Workflow)
When requested to build a new screen or feature, the developer (or AI) MUST execute the following breakdown process before writing code:

1. **MFE Triage (Where does it live?)**:
   - Analyze the business domain of the screen (e.g., is it related to Audit Execution, Taxonomy Administration, or the User Dashboard?).
   - Assign the feature to the correct Remote application in `apps/`.
   - *Example: A new "Risk Assessment Matrix" belongs in `apps/remote_dashboard` (or a dedicated planning remote).*
2. **Routing Integration**:
   - Define how the Host (`apps/host/src/App.tsx`) will expose the base route to this remote.
   - Define the internal React Router (`<Routes>`) inside the specific Remote to handle sub-navigation.
3. **Component Breakdown**:
   - Break the UI mockup into semantic, reusable React components.
   - Strictly separate Data Containers (which talk to Apollo/Redux) from pure UI Presenters.
4. **Local Development Setup**:
   - Configure/Verify MSW (Mock Service Worker) for the specific Remote if the backend isn't ready.
   - Verify the Vite dev server port configuration in `vite.config.ts`.
   - Boot the specific MFE locally using `npm run start:[remote-name]` to isolate testing, rather than booting the entire Host infrastructure.

### 8.2. Quality Assurance
- **Zero Warning Policy**: Code must pass ESLint and TypeScript compilation with zero warnings.
- **Testing**: Vitest + React Testing Library. Test behaviors and accessibility (ARIA), not implementation details.

---
*End of Architectural Directives. Enforce strictly.*