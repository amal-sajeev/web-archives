# Implementation Context: AI Chat Section

## 1. Feature Overview
- **Name**: Ai Chat Section
- **Type**: Sub-Component & Shared Component (Micro-Frontend)
- **Target Remote**: `apps/remote_leftSidebar` (Will be updated to house and expose the AiChat component, or we can create a dedicated `remote_ai_chat` if preferred, but reusing the existing left sidebar remote aligns with the current layout and "mostly will use left side on the page" requirement).
- **Description**: A shared AI chat integration component. It will provide the interface for users to interact with the LLM API. It uses the `AiInputPanelContent` and `AiInputPanelTextarea` from `com.db.rca.commons.afcc-components`.

## 2. Architecture & State Strategy
- **State Layer**: Since the LLM API will be provided later, we will use Local State for UI interactions for now, structured to be easily swappable to GraphQL/Apollo Client or Redux Thunks when the API is ready.
- **Data Flow**: The Container component will manage the chat history, user input state, and loading/generating states. It will pass down state and callbacks to the Presenter component. Data sharing across micro-frontends can be achieved via the Host's Redux store (exposed via `./store`) or a shared context if needed.
- **Container/Presenter Separation**: 
  - `AiChatContainer.tsx`: Manages chat state (messages, input value, generation status) and future API calls.
  - `AiChatPresenter.tsx`: Stateless UI component rendering the chat history and input panel using WADK AI components.

## 3. UI Component Mapping
| UI Element | WADK Component | Data Binding | Validation / Rules |
| :--- | :--- | :--- | :--- |
| Chat Input Panel | `AiInputPanelContent`, `AiInputPanelTextarea` | `inputValue` state | Standard character limits |
| Attach/Screenshot | WADK `Button`, `Screenshot` / `AttachSolid` icons | N/A | Opens file dialog (future) |
| Chat Message List | Custom mapping in Presenter | `messages` array | Scrollable, distinguishes User/AI |

## 4. API / GraphQL Mapping
- **Queries / Mutations**: TBD (LLM API will be provided later).
- **Mocking**: A mock service or local state delay will simulate AI responses during STAGE 2/3.

## 5. Implementation Plan
- [ ] 1. Scaffold `AiChatContainer` and `AiChatPresenter` components inside `apps/remote_leftSidebar`.
- [ ] 2. Define TypeScript interfaces for Chat Messages (DTOs and View Models).
- [ ] 3. Implement custom hooks (`useAiChat`) for business logic (managing message list and simulating API calls).
- [ ] 4. Implement UI with CSS Modules in `AiChatPresenter`, strictly using `com.db.rca.commons.afcc-components` for the input panel.
- [ ] 5. Update `apps/remote_leftSidebar/vite.config.ts` to expose the new `AiChat` component so it can be shared across other micro-frontends.
- [ ] 6. Update `apps/remote_leftSidebar/src/LeftSidebar.tsx` to render the `AiChatContainer` as its primary content.