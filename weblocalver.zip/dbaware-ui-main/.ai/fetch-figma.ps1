param (
    [Parameter(Mandatory=$true)][string]$FileId,
    [Parameter(Mandatory=$true)][string]$NodeId
)

$envFile = Join-Path $PSScriptRoot "..\.env"
$tokenLine = Get-Content $envFile -ErrorAction SilentlyContinue | Select-String "FIGMA_ACCESS_TOKEN"

if (-not $tokenLine) {
    Write-Error "FIGMA_ACCESS_TOKEN not found in .env"
    exit 1
}

$token = $tokenLine.Line.Split("=")[1].Trim()
$url = "https://api.figma.com/v1/files/$FileId/nodes?ids=$NodeId"

Write-Host "Fetching from Figma API via corporate proxy..."
try {
    $response = Invoke-WebRequest -Uri $url -Headers @{ "X-Figma-Token" = $token } -Proxy "http://sdod3-proxy.intranet.db.com:8080" -ProxyUseDefaultCredentials -UseBasicParsing
    $jsonPath = Join-Path $PSScriptRoot "figma_output.json"
    $response.Content | Out-File $jsonPath -Encoding utf8
    Write-Host "Raw JSON saved to $jsonPath"
} catch {
    Write-Error "Error fetching data: $($_.Exception.Message)"
    exit 1
}

# Fetch Dev Resources (Code Connect Links / Component URLs)
$devResPath = Join-Path $PSScriptRoot "figma_dev_resources.json"
try {
    Write-Host "Fetching Dev Resources (Code Connect)..."
    $devResResponse = Invoke-WebRequest -Uri "https://api.figma.com/v1/files/$FileId/dev_resources" -Headers @{ "X-Figma-Token" = $token } -Proxy "http://sdod3-proxy.intranet.db.com:8080" -ProxyUseDefaultCredentials -UseBasicParsing
    $devResResponse.Content | Out-File $devResPath -Encoding utf8
} catch {
    Write-Host "Warning: Could not fetch dev_resources. $($_.Exception.Message)"
}

# Automatically extract a readable structure to save tokens
$structPath = Join-Path $PSScriptRoot "figma_structure.txt"

function Extract-FigmaStructure {
    param ($JsonPath, $NodeId, $OutPath, $DevResPath)
    $json = Get-Content -Raw $JsonPath
    $data = $json | ConvertFrom-Json
    $nodeIdFormatted = $NodeId.Replace("-", ":")
    $node = $data.nodes.$nodeIdFormatted.document
    
    $devResMap = @{}
    if (Test-Path $DevResPath) {
        $devResJson = Get-Content -Raw $DevResPath -ErrorAction SilentlyContinue | ConvertFrom-Json
        if ($devResJson -and $devResJson.dev_resources) {
            foreach ($res in $devResJson.dev_resources) {
                if (-not $devResMap.ContainsKey($res.node_id)) { $devResMap[$res.node_id] = @() }
                $devResMap[$res.node_id] += $res
            }
        }
    }

    function Get-FigmaColor($color) {
        if (-not $color) { return "" }
        $r = [math]::Round($color.r * 255); $g = [math]::Round($color.g * 255); $b = [math]::Round($color.b * 255); $a = [math]::Round($color.a, 2)
        if ($a -eq 1) { return "rgb($r, $g, $b)" }
        return "rgba($r, $g, $b, $a)"
    }

    function Get-NodeData($n, $depth) {
        if (-not $n) { return }
        $pad = "  " * $depth
        $type = $n.type
        $name = $n.name
        $text = if ($n.characters) { " Text: `"$($n.characters -replace "`n", "\n")`"" } else { "" }
        $visibility = if ($null -ne $n.visible -and $n.visible -eq $false) { " [HIDDEN]" } else { "" }
        
        # Auto Layout (Flexbox properties)
        $layout = ""
        if ($n.layoutMode -and $n.layoutMode -ne "NONE") {
            $layout = " Flex:$($n.layoutMode)"
            if ($n.layoutWrap) { $layout += " wrap:$($n.layoutWrap)" }
            if ($n.primaryAxisAlignItems) { $layout += " justify:$($n.primaryAxisAlignItems)" }
            if ($n.counterAxisAlignItems) { $layout += " align:$($n.counterAxisAlignItems)" }
            if ($n.paddingTop -ne $null) { $layout += " pT:$($n.paddingTop)" }
            if ($n.paddingBottom -ne $null) { $layout += " pB:$($n.paddingBottom)" }
            if ($n.paddingLeft -ne $null) { $layout += " pL:$($n.paddingLeft)" }
            if ($n.paddingRight -ne $null) { $layout += " pR:$($n.paddingRight)" }
            if ($n.itemSpacing -ne $null) { $layout += " gap:$($n.itemSpacing)" }
        }
        
        # Dimensions & Sizing (Crucial for flex children: HUG, FILL, FIXED)
        $width = ""
        if ($n.absoluteBoundingBox) { $width = " W:$($n.absoluteBoundingBox.width) H:$($n.absoluteBoundingBox.height)" }
        if ($n.minWidth -ne $null) { $width += " minW:$($n.minWidth)" }
        if ($n.maxWidth -ne $null) { $width += " maxW:$($n.maxWidth)" }
        if ($n.minHeight -ne $null) { $width += " minH:$($n.minHeight)" }
        if ($n.maxHeight -ne $null) { $width += " maxH:$($n.maxHeight)" }
        
        if ($n.layoutSizingHorizontal) { $width += " sizingH:$($n.layoutSizingHorizontal)" }
        if ($n.layoutSizingVertical) { $width += " sizingV:$($n.layoutSizingVertical)" }
        if ($n.layoutAlign) { $width += " alignSelf:$($n.layoutAlign)" }
        if ($n.layoutGrow) { $width += " flexGrow:$($n.layoutGrow)" }
        
        # Typography (Including case and auto-resize)
        $style = ""
        if ($n.style) { 
            $style = " Font:$($n.style.fontFamily) Size:$($n.style.fontSize) Weight:$($n.style.fontWeight)" 
            if ($n.style.lineHeightPx) { $style += " LineHeight:$([math]::Round($n.style.lineHeightPx, 1))px" }
            if ($n.style.letterSpacing) { $style += " LetterSpacing:$([math]::Round($n.style.letterSpacing, 2))" }
            if ($n.style.textAlignHorizontal) { $style += " AlignH:$($n.style.textAlignHorizontal)" }
            if ($n.style.textAlignVertical) { $style += " AlignV:$($n.style.textAlignVertical)" }
            if ($n.style.textCase) { $style += " Case:$($n.style.textCase)" }
            if ($n.style.textAutoResize) { $style += " AutoResize:$($n.style.textAutoResize)" }
            if ($n.style.textDecoration) { $style += " Decoration:$($n.style.textDecoration)" }
        }
        
        # Borders & Opacity
        $borderStr = ""
        if ($null -ne $n.cornerRadius) { $borderStr += " Radius:$($n.cornerRadius)" }
        elseif ($n.rectangleCornerRadii) { $borderStr += " Radius:($($n.rectangleCornerRadii -join ','))" }
        if ($null -ne $n.opacity) { $borderStr += " Opacity:$($n.opacity)" }
        
        # Fills (Handles gradients and multiple backgrounds)
        $fillsStr = ""
        if ($n.fills) {
            $fillArr = @()
            foreach ($f in $n.fills) {
                if ($f.visible -eq $false) { continue }
                if ($f.type -eq "SOLID") { $fillArr += "Solid($(Get-FigmaColor $f.color))" }
                elseif ($f.type -match "GRADIENT") { $fillArr += "$($f.type)" }
                elseif ($f.type -eq "IMAGE") { $fillArr += "IMAGE" }
            }
            if ($fillArr.Length -gt 0) { $fillsStr = " Fills:[$($fillArr -join ', ')]" }
        }

        # Strokes (Including strokeAlign)
        $strokeStr = ""
        if ($n.strokes) {
            $strokeArr = @()
            foreach ($s in $n.strokes) {
                if ($s.visible -eq $false) { continue }
                if ($s.type -eq "SOLID") { $strokeArr += "Solid($(Get-FigmaColor $s.color))" }
            }
            if ($strokeArr.Length -gt 0) { 
                $strokeStr = " Strokes:[$($strokeArr -join ', ')] Weight:$($n.strokeWeight)" 
                if ($n.strokeAlign) { $strokeStr += " Align:$($n.strokeAlign)" }
            }
        }

        # Effects (Shadows with Spread, Blurs)
        $effectStr = ""
        if ($n.effects) {
            $effArr = @()
            foreach ($ef in $n.effects) {
                if ($ef.visible -eq $false) { continue }
                if ($ef.type -eq "DROP_SHADOW" -or $ef.type -eq "INNER_SHADOW") {
                    $effectColor = Get-FigmaColor $ef.color
                    $spread = if ($null -ne $ef.spread) { $ef.spread } else { 0 }
                    $effArr += "$($ef.type)(x:$($ef.offset.x) y:$($ef.offset.y) blur:$($ef.radius) spread:$spread $effectColor)"
                } elseif ($ef.type -eq "LAYER_BLUR" -or $ef.type -eq "BACKGROUND_BLUR") {
                    $effArr += "$($ef.type)(blur:$($ef.radius))"
                }
            }
            if ($effArr.Length -gt 0) { $effectStr = " Effects:[$($effArr -join ', ')]" }
        }

        # Positioning & Constraints
        $constraints = ""
        if ($n.layoutPositioning -eq "ABSOLUTE") { 
            $constraints += " Pos:ABSOLUTE x:$($n.absoluteBoundingBox.x) y:$($n.absoluteBoundingBox.y)" 
        }
        if ($n.constraints) { $constraints += " Constraints:(H:$($n.constraints.horizontal) V:$($n.constraints.vertical))" }
        
        # Component Props
        $props = ""
        if ($n.componentProperties) {
            $propStr = ($n.componentProperties.PSObject.Properties | ForEach-Object { "$($_.Name)=$($_.Value.value)" }) -join ", "
            if ($propStr) { $props = " Props:[$propStr]" }
        }

        $devStr = ""
        if ($n.id -and $devResMap.ContainsKey($n.id)) {
            $resList = $devResMap[$n.id]
            $resStrings = $resList | ForEach-Object { "$($_.name) [$($_.url)]" }
            $devStr = " DevResource:{$($resStrings -join ' | ')}"
        }
        
        Write-Output "$pad- [$type]$visibility $name$text$layout$width$props$style$borderStr$fillsStr$strokeStr$effectStr$constraints$devStr"
        if ($n.children) {
            foreach ($c in $n.children) {
                Get-NodeData $c ($depth + 1)
            }
        }
    }
    
    Get-NodeData $node 0 | Out-File $OutPath -Encoding utf8
}

Extract-FigmaStructure -JsonPath $jsonPath -NodeId $NodeId -OutPath $structPath -DevResPath $devResPath
Write-Host "Readable structure saved to $structPath"
Write-Host "Done. You can now read $structPath"