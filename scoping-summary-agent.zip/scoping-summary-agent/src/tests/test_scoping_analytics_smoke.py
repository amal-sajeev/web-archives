from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


def _load_module_from_path(module_path: Path, module_name: str):
    spec = spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise AssertionError(f"Unable to load module at {module_path}")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_analytics_config_smoke():
    module_path = Path(__file__).resolve().parents[1] / "main" / "config" / "config.py"
    module = _load_module_from_path(module_path, "analytics_config")

    assert hasattr(module, "Config")
    assert isinstance(module.Config.MODEL_NAME, str)