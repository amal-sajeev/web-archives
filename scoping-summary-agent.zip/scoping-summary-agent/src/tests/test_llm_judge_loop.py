import pytest

from llm_judge import ReviewLoopError, review_and_revise


def _rejected(candidate):
    return {"approved": False, "feedback": f"Fix {candidate}"}


def test_zero_revisions_reviews_once_and_returns_candidate():
    calls = []
    result = review_and_revise(
        "draft-1",
        reviewer=lambda candidate: calls.append(candidate) or _rejected(candidate),
        reviser=lambda candidate, _review: f"revised-{candidate}",
        approved=lambda review: review["approved"],
        has_feedback=lambda review: bool(review["feedback"]),
        stage="example",
        max_revisions=0,
    )

    assert calls == ["draft-1"]
    assert result.candidate == "draft-1"
    assert result.revisions == 0
    assert result.outcome == "revision_limit"


def test_revision_failure_keeps_latest_candidate_or_raises_by_policy():
    common = {
        "candidate": "draft-1",
        "reviewer": _rejected,
        "reviser": lambda _candidate, _review: (_ for _ in ()).throw(ValueError("private details")),
        "approved": lambda review: review["approved"],
        "has_feedback": lambda review: bool(review["feedback"]),
        "stage": "example",
        "max_revisions": 1,
    }
    result = review_and_revise(**common, failure_policy="fail_open")
    assert result.candidate == "draft-1"
    assert result.outcome == "revision_failure"

    with pytest.raises(ReviewLoopError, match="LLM revision failed"):
        review_and_revise(**common, failure_policy="fail_closed")


def test_validation_callback_failure_uses_review_failure_policy():
    args = {
        "candidate": "draft-1",
        "reviewer": lambda _candidate: object(),
        "reviser": lambda candidate, _review: candidate,
        "approved": lambda _review: (_ for _ in ()).throw(ValueError("private details")),
        "has_feedback": lambda _review: True,
        "stage": "example",
    }
    assert review_and_revise(**args, failure_policy="fail_open").outcome == "review_failure"
    with pytest.raises(ReviewLoopError, match="LLM review failed"):
        review_and_revise(**args, failure_policy="fail_closed")
