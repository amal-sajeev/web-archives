from model.response_model import ParagraphMetadata, ScopingReport
from service import pdf_download_service as pdf


def test_section_start_renders_level_one_heading_only_on_first_line():
    html_block = pdf._content_to_html("**Section 2: Traceability**\nBody text.", is_section_start=True)
    assert html_block == '<p><font size="13"><b>Section 2: Traceability</b></font><br>Body text.</p>'


def test_explicit_heading_levels_two_and_three():
    level2 = pdf._content_to_html("**Policy**", is_section_start=False, heading_level=2)
    assert level2 == '<p><font size="12"><b>Policy</b></font></p>'

    # Level 3 keeps inline bold so only the name is bold, applicability stays regular weight.
    level3 = pdf._content_to_html(
        "1. **GBSA** - Directly Applicable\nRelevance Score: 0.50",
        is_section_start=False,
        heading_level=3,
    )
    assert level3 == '<p><font size="11">1. <b>GBSA</b> - Directly Applicable</font><br>Relevance Score: 0.50</p>'


def test_bold_only_lines_become_level_two_and_inline_bold_is_untouched():
    html_block = pdf._content_to_html(
        "**Immediate Impact**\n- item with **inline** bold\n  **Monitor Only:**",
        is_section_start=False,
    )
    assert '<font size="12"><b>Immediate Impact</b></font>' in html_block
    assert "- item with <b>inline</b> bold" in html_block
    assert '&nbsp;&nbsp;<font size="12"><b>Monitor Only:</b></font>' in html_block


def test_plain_paragraph_has_no_heading_markup():
    assert pdf._content_to_html("Plain body.", is_section_start=False) == "<p>Plain body.</p>"


def test_narrative_units_apply_heading_level_to_first_unit_only():
    html_block, _ = pdf._narrative_units_to_html(
        [{"content": "**Sub-heading**\nFirst."}, {"content": "**Not a heading level 3**"}],
        is_section_start=False,
        plan_number=None,
        plan_name=None,
        pdf_citation_base_url=None,
        citation_number_start=1,
        heading_level=3,
    )
    assert html_block.startswith('<p><font size="11"><b>Sub-heading</b></font>')
    assert '<font size="12"><b>Not a heading level 3</b></font>' in html_block


def test_heading_level_hidden_from_model_schema_but_serialized():
    schema_text = str(ScopingReport.model_json_schema())
    assert "heading_level" not in schema_text
    assert ParagraphMetadata(is_section_start=False, heading_level=2).model_dump()["heading_level"] == 2


def test_build_report_pdf_renders_with_heading_levels():
    report = {
        "Policy, KOD and Regulatory Analysis": {
            "report_title": "Policy, KOD and Regulatory Analysis",
            "paragraphs": [
                {"content": "Section 1: Context\nIntro.", "metadata": {"is_section_start": True}},
                {"content": "**Regulatory Mandates**", "metadata": {"is_section_start": False, "heading_level": 2}},
                {
                    "content": "1. **Mandate** - Directly Applicable\nBody.",
                    "metadata": {"is_section_start": False, "heading_level": 3},
                    "supporting_citations": [{"chunk_id": "REG|1|1|1", "citation_label": "finra.org 3110",
                                              "url": "https://www.finra.org/rules#:~:text=x"}],
                },
            ],
        },
    }
    pdf_bytes = pdf.build_report_pdf(report, plan_number="1", plan_name="Plan")
    assert pdf_bytes.startswith(b"%PDF")
