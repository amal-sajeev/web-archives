from unittest.mock import patch, MagicMock
from fastapi import FastAPI
from fastapi.testclient import TestClient
import pytest

from app import app as main_app
from router import router as router_module
from model.response_model import PreliminaryResearchDocument

app = FastAPI()
app.include_router(router_module.router)
client = TestClient(app)


def test_main_app_registers_each_endpoint_once():
    expected = {
        ("GET", "/health"),
        ("POST", "/run-analytics-agent"),
        ("POST", "/get_document"),
        ("POST", "/get-preliminary-research-document"),
        ("POST", "/edit-preliminary-research-document"),
        ("POST", "/download"),
    }
    def registered_routes(routes):
        for route in routes:
            if hasattr(route, "original_router"):
                yield from registered_routes(route.original_router.routes)
            elif getattr(route, "path", None) in {path for _, path in expected}:
                for method in route.methods:
                    yield method, route.path

    routes = list(registered_routes(main_app.routes))
    for endpoint in expected:
        assert routes.count(endpoint) == 1


def test_router_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


@patch("agent_helper.action_service.construct_ai_actor_record")
@patch("agent_helper.action_service.construct_human_actor_record")
@patch("router.router.persist_review_research_recommendation", return_value=101)
@patch("router.router.has_plan_data", return_value=True)
@patch("router.router.run_analytics_task")
def test_run_analytics_agent_success(mock_task, mock_has_data, mock_persist, mock_human_rec, mock_ai_rec):
    mock_task.return_value = PreliminaryResearchDocument(
        plan_number="20587",
        analysis_report={"Past Review Analysis": {"report_title": "Baseline", "paragraphs": []}},
    )
    response = client.post(
        "/run-analytics-agent",
        json={
            "planNumber": "20587",
            "userDetails": {
                "review_scope_instance_id": 55,
                "user": "jdoe",
                "remarks": "note",
            },
        },
    )
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"
    assert mock_human_rec.called
    assert mock_ai_rec.called
    # Persistence invoked with values sourced from userDetails.
    mock_persist.assert_called_once()
    _, kwargs = mock_persist.call_args
    assert kwargs["review_scope_instance_id"] == 55
    assert kwargs["created_by"] == "jdoe"
    assert kwargs["remarks"] == "note"
    assert kwargs["report_type"] == "PRELIMINARY_RESEARCH"


@patch("router.router.persist_review_research_recommendation", return_value=101)
@patch("router.router.has_plan_data", return_value=False)
def test_run_analytics_agent_not_found(mock_has_data, mock_persist):
    response = client.post(
        "/run-analytics-agent",
        json={"planNumber": "missing", "userDetails": {"user": "jdoe"}},
    )
    assert response.status_code == 404


@patch("agent_helper.action_service.construct_ai_actor_record")
@patch("agent_helper.action_service.construct_human_actor_record")
@patch("router.router.persist_review_research_recommendation", side_effect=RuntimeError("db down"))
@patch("router.router.has_plan_data", return_value=True)
@patch("router.router.run_analytics_task")
def test_run_analytics_agent_persist_failure_does_not_break_response(
    mock_task, mock_has_data, mock_persist, mock_human_rec, mock_ai_rec
):
    """Persistence is best-effort: a DB failure must not fail the analytics response."""
    mock_task.return_value = PreliminaryResearchDocument(
        plan_number="20587",
        analysis_report={"Past Review Analysis": {"report_title": "Baseline", "paragraphs": []}},
    )
    response = client.post(
        "/run-analytics-agent",
        json={"planNumber": "20587", "userDetails": {"user": "jdoe"}},
    )
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"
    mock_persist.assert_called_once()


@patch("router.router.has_plan_data", return_value=True)
def test_run_analytics_agent_missing_user_details(mock_has_data):
    """userDetails is required; omitting it yields a 422 validation error."""
    response = client.post("/run-analytics-agent", json={"planNumber": "20587"})
    assert response.status_code == 422


@patch("router.router.process_document_uri")
def test_get_document_direct_uri(mock_proc):
    mock_proc.return_value = {"type": "pdf", "text": "Extracted"}
    response = client.post("/get_document", json={"document_uri": "gs://bucket/file.pdf"})
    assert response.status_code == 200
    assert response.json()["text"] == "Extracted"


@patch("router.router.process_document_uri")
def test_get_document_unsupported_type(mock_proc):
    mock_proc.return_value = {"type": "unsupported"}
    response = client.post("/get_document", json={"document_uri": "gs://bucket/file.xyz"})
    assert response.status_code == 415


@patch("router.router.process_citations")
def test_get_document_citation_success(mock_proc):
    mock_proc.return_value = {"type": "success", "content": "Evidence"}
    response = client.post("/get_document", json={"planNumber": "20587", "chunk_id": "chunk_1"})
    assert response.status_code == 200
    assert response.json()["content"] == "Evidence"


@patch("router.router.process_citations")
def test_get_document_citation_error_status(mock_proc):
    mock_proc.return_value = {"type": "error", "message": "Chunk not found"}
    response = client.post("/get_document", json={"planNumber": "20587", "chunk_id": "invalid"})
    assert response.status_code == 404


def test_get_document_missing_parameters():
    response = client.post("/get_document", json={})
    assert response.status_code == 400


@patch("router.router.blob_exists", return_value=True)
@patch("router.router.read_blob_json")
def test_get_preliminary_research_document_success(mock_read, mock_exists):
    mock_read.return_value = {
        "plan_number": "20587",
        "analysis_report": {"Past Review Analysis": {"report_title": "Scope data", "paragraphs": []}},
    }
    response = client.post("/get-preliminary-research-document", json={"planNumber": "20587"})
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"


@patch("router.router.blob_exists", return_value=False)
def test_get_preliminary_research_document_not_found(mock_exists):
    response = client.post("/get-preliminary-research-document", json={"planNumber": "20587"})
    assert response.status_code == 404


@patch("router.router.blob_exists", return_value=True)
@patch("router.router.read_blob_json")
@pytest.mark.parametrize("payload, detail", [
    ({"plan_number": "20587", "analysis_report": "invalid"}, "analysis_report must be a dictionary"),
    ("invalid blob", "Stored preliminary research must be a dictionary"),
])
def test_get_preliminary_research_document_invalid_blob(mock_read, mock_exists, payload, detail):
    mock_read.return_value = payload
    response = client.post("/get-preliminary-research-document", json={"planNumber": "20587"})
    assert response.status_code == 500
    assert detail in response.json()["detail"]


@patch("agent_helper.action_service.construct_human_update_record")
@patch("router.router.update_review_research_recommendation", return_value=101)
@patch("router.router.write_blob_json")
def test_edit_preliminary_research_document(mock_write, mock_update, mock_update_rec):
    payload = {
        "plan_number": "20587",
        "analysis_report": {"Past Review Analysis": {"report_title": "Updated", "paragraphs": []}},
        "userDetails": {"review_scope_instance_id": 55, "user": "jdoe"},
    }
    response = client.post("/edit-preliminary-research-document", json=payload)
    assert response.status_code == 200
    assert response.json()["plan_number"] == "20587"
    assert mock_write.called
    assert mock_update_rec.called
    # DB update invoked with updated_by/metadata sourced from userDetails + document.
    mock_update.assert_called_once()
    _, kwargs = mock_update.call_args
    assert kwargs["review_scope_instance_id"] == 55
    assert kwargs["updated_by"] == "jdoe"


@patch("router.router.download_research_walkthrough_pdf")
def test_download_success(mock_download):
    mock_download.return_value = (
        b"%PDF-report",
        {"Content-Disposition": 'attachment; filename="report.pdf"'},
    )
    payload = {
        "plan_number": "20587",
        "analysis_report": {"Past Review Analysis": {"report_title": "Report", "paragraphs": []}},
    }
    response = client.post("/download", json=payload)
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert response.content == b"%PDF-report"


@patch("router.router.download_research_walkthrough_pdf", side_effect=ValueError("Bad PDF data"))
def test_download_value_error(mock_download):
    payload = {
        "plan_number": "20587",
        "analysis_report": {},
    }
    response = client.post("/download", json=payload)
    assert response.status_code == 400


@patch("router.router.download_research_walkthrough_pdf")
def test_main_app_download_passes_plan_name(mock_download):
    mock_download.return_value = (b"%PDF-report", {})
    response = TestClient(main_app).post("/download", json={
        "planNumber": "20587",
        "planName": "Current Plan Item",
        "analysisReport": {},
    })
    assert response.status_code == 200
    assert mock_download.call_args.kwargs["plan_name"] == "Current Plan Item"