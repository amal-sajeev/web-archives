"""Unit tests for the new/updated Pydantic models."""
import sys
from pathlib import Path

import pytest
from pydantic import ValidationError

MAIN_DIR = Path(__file__).resolve().parents[1] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))

from model.request_model import AnalyticsRequest, UserRequest


class TestAnalyticsRequest:
    def test_requires_user_details(self) -> None:
        with pytest.raises(ValidationError):
            AnalyticsRequest(planNumber="123")

    def test_parses_user_details_into_model(self) -> None:
        req = AnalyticsRequest(
            planNumber="123",
            userDetails={"review_scope_instance_id": 55, "user": "jdoe", "remarks": "n"},
        )
        assert isinstance(req.userDetails, UserRequest)
        assert req.userDetails.review_scope_instance_id == 55
        assert req.userDetails.user == "jdoe"
        assert req.userDetails.remarks == "n"

    def test_user_details_fields_optional(self) -> None:
        req = AnalyticsRequest(planNumber="123", userDetails={})
        assert req.userDetails.user is None
        assert req.userDetails.review_scope_instance_id is None

    def test_user_max_length_enforced(self) -> None:
        with pytest.raises(ValidationError):
            UserRequest(user="x" * 101)
