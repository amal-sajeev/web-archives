import uuid
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock
import pytest
from fastapi.testclient import TestClient

from app import app
from agent_helper.action_service import (
    call_to_action_service,
    construct_human_actor_record,
    construct_ai_actor_record,
    construct_human_update_record,
)
from agent_helper.agent_card import build_agent_card
from model.response_model import PreliminaryResearchDocument

client = TestClient(app)


def test_call_to_action_service_payload_structure():
    """Verify call_to_action_service produces the standard CTA_ACTION payload."""
    session_id = str(uuid.uuid4())
    card = {
        "ENTITY_ID": session_id,
        "ENTITY_TYPE": "PRELIMINARY_RESEARCH",
        "PARENT_ENTITY_TYPE": "SCOPING_SUMMARY",
        "PARENT_ENTITY_ID": "20583",
        "CORRELATION_ID": session_id,
        "ACTOR_TYPE": "HUMAN",
        "ACTOR_ID": "dbaware@db.com",
        "ACTION_TYPE": "GENERATE",
        "ACTIVITY_TYPE": "PRELIMINARY_RESEARCH",
    }
    data = {"action_type": "GENERATE", "Human_Notes": "Test note", "Remarks": ""}
    
    result = call_to_action_service(card, data)
    assert "CTA_ACTION" in result
    action = result["CTA_ACTION"]
    assert action["entity_id"] == session_id
    assert action["entity_type"] == "PRELIMINARY_RESEARCH"
    assert action["parent_entity_type"] == "SCOPING_SUMMARY"
    assert action["parent_entity_id"] == "20583"
    assert action["payload"]["correlation_id"] == session_id
    assert action["actor_type"] == "HUMAN"
    assert action["activity_type"] == "PRELIMINARY_RESEARCH"
    # Timestamp must end with minute precision 'Z'
    assert action["create_ts"].endswith("Z")


@patch("agent_helper.action_service.call_to_action_service")
def test_construct_human_actor_record(mock_call):
    """Verify construct_human_actor_record sets HUMAN and GENERATE attributes."""
    agent_card = build_agent_card(
        activity_type="PRELIMINARY_RESEARCH",
        query="Generate report",
        plan_item_number="20583",
        correlation_id="corr-123"
    )
    construct_human_actor_record(agent_card, "Generate report")
    
    mock_call.assert_called_once()
    args, _ = mock_call.call_args
    card_arg, data_arg = args
    assert card_arg["ACTOR_TYPE"] == "HUMAN"
    assert card_arg["ACTION_TYPE"] == "GENERATE"
    assert data_arg["Human_Notes"] == "Generate report"


@patch("agent_helper.action_service.call_to_action_service")
def test_construct_ai_actor_record(mock_call):
    """Verify construct_ai_actor_record records model metadata and minute precision timestamps."""
    agent_card = {
        "ACTOR_ID": "scoping_summary_agent",
        "ENTITY_ID": "entity-123",
        "CORRELATION_ID": "corr-123",
        "PARENT_ENTITY_ID": "20583",
        "PARENT_ENTITY_TYPE": "SCOPING_SUMMARY",
    }
    start = datetime(2026, 9, 24, 12, 0, 0, tzinfo=timezone.utc)
    end = datetime(2026, 9, 24, 12, 5, 0, tzinfo=timezone.utc)
    
    construct_ai_actor_record(
        agent_card=agent_card,
        total_input_tokens=100,
        total_output_tokens=50,
        final_answer="Report answer",
        start_time=start,
        end_time=end,
        score=0.95,
        reasoning="Test rationale",
        prompt_version="1.0"
    )
    
    mock_call.assert_called_once()
    _, data_arg = mock_call.call_args[0]
    assert data_arg["action_type"] == "RESPONSE"
    assert data_arg["Prompt_Version"] == "1.0"
    assert data_arg["Execution_Start_Time"] == "2026-09-24T12:00:00Z"
    assert data_arg["Execution_End_Time"] == "2026-09-24T12:05:00Z"
    assert data_arg["Token_Input_Count"] == 100
    assert data_arg["Token_Output_Count"] == 50


@patch("agent_helper.action_service.call_to_action_service")
def test_construct_human_update_record(mock_call):
    """Verify construct_human_update_record records REVISE action."""
    agent_card = {}
    construct_human_update_record(agent_card, remarks="Edited section 2")
    
    mock_call.assert_called_once()
    card_arg, data_arg = mock_call.call_args[0]
    assert card_arg["ACTOR_TYPE"] == "HUMAN"
    assert card_arg["ACTION_TYPE"] == "REVISE"
    assert data_arg["Remarks"] == "Edited section 2"


@patch("agent_helper.action_service.construct_human_actor_record")
@patch("agent_helper.action_service.construct_ai_actor_record")
@patch("router.router.persist_review_research_recommendation", return_value=101)
@patch("router.router.has_plan_data", return_value=True)
@patch("router.router.run_analytics_task")
def test_run_analytics_agent_endpoint(mock_run, mock_has_data, mock_persist, mock_ai_rec, mock_human_rec):
    """Test /run-analytics-agent endpoint triggers both human and AI action records."""
    mock_response = PreliminaryResearchDocument(
        plan_number="20583",
        analysis_report={
            "summary": {"report_title": "Summary", "paragraphs": []}
        },
    )
    mock_run.return_value = mock_response

    response = client.post(
        "/run-analytics-agent",
        json={"planNumber": "20583", "userDetails": {"user": "jdoe"}},
    )
    assert response.status_code == 200
    assert mock_human_rec.called
    assert mock_ai_rec.called


@patch("agent_helper.action_service.construct_human_update_record")
@patch("router.router.update_review_research_recommendation", return_value=101)
@patch("router.router.write_blob_json")
def test_edit_preliminary_research_document_endpoint(mock_write_blob, mock_update, mock_update_rec):
    """Test /edit-preliminary-research-document endpoint triggers human revision record."""
    payload = {
        "planNumber": "20583",
        "analysis_report": {
            "summary": {"report_title": "Summary", "paragraphs": []}
        },
        "userDetails": {"review_scope_instance_id": 55, "user": "jdoe"},
    }
    response = client.post("/edit-preliminary-research-document", json=payload)
    assert response.status_code == 200
    assert mock_update_rec.called