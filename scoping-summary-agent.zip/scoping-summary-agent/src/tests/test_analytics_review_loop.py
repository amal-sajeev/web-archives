import asyncio

import pytest

from agents import analytics_agent


class _QueuedStructuredModel:
    def __init__(self, schema, responses):
        self.schema = schema
        self.responses = responses

    def invoke(self, _payload):
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return self.schema.model_validate(value)


class _QueuedModel:
    def __init__(self, responses_by_schema):
        self.responses_by_schema = responses_by_schema

    def with_structured_output(self, schema, **_kwargs):
        return _QueuedStructuredModel(schema, self.responses_by_schema[schema.__name__])


def _approve_section():
    return {
        "criteria": [
            {"name": name, "passed": True, "issue": "", "action": ""}
            for name in (
                "evidence_support",
                "citation_validity",
                "required_content",
                "schema_compliance",
            )
        ]
    }


def _approve_report():
    return {
        "criteria": [
            {
                "name": name,
                "passed": True,
                "issue": "",
                "action": "",
                "affected_sections": [],
            }
            for name in (
                "section_coverage",
                "cross_section_consistency",
                "review_identifier_consistency",
                "duplication_and_structure",
            )
        ]
    }


def test_section_review_revises_with_feedback_and_stops_after_approval():
    generated_feedback = []
    model = _QueuedModel({
        "SectionReview": [
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "The conclusion is not supported.",
                        "action": "Add supporting evidence or remove the conclusion.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
            _approve_section(),
        ],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example",
        builder,
        [{"chunk_id": "source-1", "content": "Evidence."}],
        model,
        max_revisions=1,
        failure_policy="fail_open",
    )

    assert result == "draft-2"
    assert generated_feedback == [
        None,
        "[evidence_support] The conclusion is not supported. Action: Add supporting evidence or remove the conclusion.",
    ]


def test_section_review_returns_latest_valid_draft_when_revision_limit_is_reached():
    generated_feedback = []
    model = _QueuedModel({
        "SectionReview": [
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "First issue.",
                        "action": "First correction.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
            {
                "criteria": [
                    {
                        "name": "evidence_support",
                        "passed": False,
                        "issue": "Still unsupported.",
                        "action": "Still needs work.",
                    },
                    *[
                        {"name": name, "passed": True, "issue": "", "action": ""}
                        for name in (
                            "citation_validity",
                            "required_content",
                            "schema_compliance",
                        )
                    ],
                ]
            },
        ],
    })

    def builder(_chunks, _model, review_feedback=None):
        generated_feedback.append(review_feedback)
        return f"draft-{len(generated_feedback)}"

    result = analytics_agent._generate_reviewed_section(
        "Example", builder, [], model, max_revisions=1, failure_policy="fail_open"
    )

    assert result == "draft-2"
    assert len(generated_feedback) == 2


def test_section_review_failure_policy_can_fail_open_or_closed():
    model = _QueuedModel({"SectionReview": [RuntimeError("judge unavailable")]})
    builder = lambda _chunks, _model, review_feedback=None: "valid draft"

    result = analytics_agent._generate_reviewed_section(
        "Example", builder, [], model, max_revisions=1, failure_policy="fail_open"
    )
    assert result == "valid draft"

    model = _QueuedModel({"SectionReview": [RuntimeError("judge unavailable")]})
    with pytest.raises(RuntimeError, match="LLM review failed"):
        analytics_agent._generate_reviewed_section(
            "Example", builder, [], model, max_revisions=1, failure_policy="fail_closed"
        )


def test_report_review_revises_only_flagged_section_then_reviews_again():
    builder_calls = {"Past Review Analysis": [], "Broad Scope Direction": []}

    def past_builder(_chunks, _model, review_feedback=None):
        builder_calls["Past Review Analysis"].append(review_feedback)
        return {"section": "past revised"}

    def broad_builder(_chunks, _model, review_feedback=None):
        builder_calls["Broad Scope Direction"].append(review_feedback)
        return {"section": "broad"}

    model = _QueuedModel({
        "ReportReview": [
            {
                "criteria": [
                    {
                        "name": "review_identifier_consistency",
                        "passed": False,
                        "issue": "The review identifier differs between sections.",
                        "action": "Align the identifier to the value used in the other sections.",
                        "affected_sections": ["Past Review Analysis"],
                    },
                    *[
                        {
                            "name": name,
                            "passed": True,
                            "issue": "",
                            "action": "",
                            "affected_sections": [],
                        }
                        for name in (
                            "section_coverage",
                            "cross_section_consistency",
                            "duplication_and_structure",
                        )
                    ],
                ]
            },
            _approve_report(),
        ],
        "SectionReview": [_approve_section()],
    })

    result = asyncio.run(analytics_agent._review_complete_report(
        {
            "Past Review Analysis": {"section": "past original"},
            "Broad Scope Direction": {"section": "broad original"},
        },
        model,
        {
            "Past Review Analysis": (past_builder, []),
            "Broad Scope Direction": (broad_builder, []),
        },
        max_revisions=1,
        failure_policy="fail_open",
    ))

    assert result["Past Review Analysis"] == {"section": "past revised"}
    assert result["Broad Scope Direction"] == {"section": "broad original"}
    assert builder_calls["Past Review Analysis"] == [
        "[review_identifier_consistency] The review identifier differs between sections. "
        "Action: Align the identifier to the value used in the other sections."
    ]
    assert builder_calls["Broad Scope Direction"] == []


def test_review_settings_default_and_vertex_connection_configuration(monkeypatch):
    from utils import gemini_connection

    captured = {}

    def fake_chat_model(**kwargs):
        captured.update(kwargs)
        return "configured model"

    monkeypatch.setattr(gemini_connection, "ChatGoogleGenerativeAI", fake_chat_model)
    result = gemini_connection.initialize_gemini_model()

    assert result == "configured model"
    assert captured["model"] == gemini_connection.Config.MODEL_NAME
    assert captured["project"] == gemini_connection.Config.PROJECT_NAME
    assert captured["location"] == gemini_connection.Config.PROJECT_LOCATION
    assert analytics_agent._review_settings() == (
        gemini_connection.Config.SUMMARY_AGENT_REVIEW_MAX_REVISIONS,
        gemini_connection.Config.SUMMARY_AGENT_REVIEW_FAILURE_POLICY,
    )


