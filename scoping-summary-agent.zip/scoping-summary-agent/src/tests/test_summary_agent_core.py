from importlib.util import module_from_spec, spec_from_file_location
import sys
import types
from pathlib import Path


MAIN_DIR = Path(__file__).resolve().parents[1] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))


def _install_google_stubs() -> None:
    if "google.api_core.exceptions" not in sys.modules:
        google_module = sys.modules.setdefault("google", types.ModuleType("google"))
        api_core_module = sys.modules.setdefault("google.api_core", types.ModuleType("google.api_core"))
        exceptions_module = types.ModuleType("google.api_core.exceptions")

        class NotFound(Exception):
            pass

        exceptions_module.NotFound = NotFound
        sys.modules["google.api_core.exceptions"] = exceptions_module
        api_core_module.exceptions = exceptions_module
        google_module.api_core = api_core_module

    if "google.cloud.storage" not in sys.modules:
        google_module = sys.modules.setdefault("google", types.ModuleType("google"))
        cloud_module = sys.modules.setdefault("google.cloud", types.ModuleType("google.cloud"))
        storage_module = types.ModuleType("google.cloud.storage")

        class Client:
            def __init__(self, *args, **kwargs):
                pass

            def bucket(self, *args, **kwargs):
                return Bucket()

        class Bucket:
            def blob(self, *args, **kwargs):
                return Blob()

        class Blob:
            def exists(self):
                return False

            def download_as_text(self, encoding="utf-8"):
                raise NotImplementedError

            def download_as_bytes(self):
                raise NotImplementedError

            def upload_from_string(self, *args, **kwargs):
                return None

        storage_module.Client = Client
        storage_module.Bucket = Bucket
        storage_module.Blob = Blob
        sys.modules["google.cloud.storage"] = storage_module
        cloud_module.storage = storage_module
        google_module.cloud = cloud_module


_install_google_stubs()


def _load_module(module_path: Path, module_name: str):
    spec = spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise AssertionError(f"Unable to load module at {module_path}")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


data_manager = _load_module(MAIN_DIR / "utils" / "data_manager.py", "data_manager_test")

create_citation_mapping = data_manager.create_citation_mapping
process_citations = data_manager.process_citations


def test_create_citation_mapping_uses_string_chunk_ids():
    indexed_data = {
        "output1": [
            {
                "chunk_id": 7,
                "source_name": "relevant_policy",
                "metadata": {"url": "gs://bucket/source.json"},
                "content": {
                    "citations": [
                        {
                            "document_name": "policy.pdf",
                            "gs_uri": "gs://bucket/policy.pdf",
                            "page_number": 4,
                        }
                    ]
                },
            }
        ]
    }

    mapping = create_citation_mapping(indexed_data)

    assert "7" in mapping
    assert 7 not in mapping
    assert mapping["7"][0]["document_name"] == "policy.pdf"
    assert mapping["7"][0]["access_info"]["uri"] == "gs://bucket/policy.pdf"


def test_process_citations_handles_integer_chunk_keys(monkeypatch):
    citation_source = {
        3: [
            {
                "content_type": "application/json",
                "document_name": "document.json",
                "access_info": {"uri": "gs://bucket/document.json"},
                "location_metadata": {},
            }
        ]
    }

    monkeypatch.setattr(data_manager, "read_citation_mapping", lambda plan_number: citation_source)
    monkeypatch.setattr(data_manager, "read_plan_json_by_path", lambda path: {"status": "ok", "path": path})

    result = process_citations("123", 3)

    assert result["type"] == "json"
    assert result["content"] == {"status": "ok", "path": "gs://bucket/document.json"}
    assert result["source"]["document_name"] == "document.json"
