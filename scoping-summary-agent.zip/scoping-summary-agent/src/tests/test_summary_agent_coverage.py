from importlib.util import module_from_spec, spec_from_file_location
import asyncio
import sys
import types
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


MAIN_DIR = Path(__file__).resolve().parents[1] / "main"
if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))


def _install_google_stubs() -> None:
    if "google.api_core.exceptions" not in sys.modules:
        google_module = sys.modules.setdefault("google", types.ModuleType("google"))
        api_core_module = sys.modules.setdefault("google.api_core", types.ModuleType("google.api_core"))
        exceptions_module = types.ModuleType("google.api_core.exceptions")

        class NotFound(Exception):
            pass

        exceptions_module.NotFound = NotFound
        sys.modules["google.api_core.exceptions"] = exceptions_module
        api_core_module.exceptions = exceptions_module
        google_module.api_core = api_core_module

    if "google.cloud.storage" not in sys.modules:
        google_module = sys.modules.setdefault("google", types.ModuleType("google"))
        cloud_module = sys.modules.setdefault("google.cloud", types.ModuleType("google.cloud"))
        storage_module = types.ModuleType("google.cloud.storage")

        class Blob:
            def __init__(self):
                self.uploaded = None

            def exists(self):
                return True

            def download_as_text(self, encoding="utf-8"):
                return "{}"

            def download_as_bytes(self):
                return b"bytes"

            def upload_from_string(self, body, content_type="application/json"):
                self.uploaded = (body, content_type)

        class Bucket:
            def __init__(self):
                self.blobs = {}

            def blob(self, blob_path):
                blob = self.blobs.get(blob_path)
                if blob is None:
                    blob = Blob()
                    self.blobs[blob_path] = blob
                return blob

        class Client:
            def __init__(self, *args, **kwargs):
                self._bucket = Bucket()

            def bucket(self, bucket_name):
                return self._bucket

            def list_blobs(self, bucket_name, prefix=""):
                return []

        storage_module.Client = Client
        storage_module.Bucket = Bucket
        storage_module.Blob = Blob
        sys.modules["google.cloud.storage"] = storage_module
        cloud_module.storage = storage_module
        google_module.cloud = cloud_module

    if "langchain_google_genai" not in sys.modules:
        langchain_module = types.ModuleType("langchain_google_genai")

        class ChatGoogleGenerativeAI:
            def __init__(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs

        langchain_module.ChatGoogleGenerativeAI = ChatGoogleGenerativeAI
        sys.modules["langchain_google_genai"] = langchain_module


_install_google_stubs()


def _load_module(module_path: Path, module_name: str):
    spec = spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise AssertionError(f"Unable to load module at {module_path}")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


storage_manager = _load_module(MAIN_DIR / "utils" / "storage_manager.py", "storage_manager_coverage")
data_manager = _load_module(MAIN_DIR / "utils" / "data_manager.py", "data_manager_coverage")
response_model = _load_module(MAIN_DIR / "model" / "response_model.py", "response_model_coverage")
analytics_agent = _load_module(MAIN_DIR / "agents" / "analytics_agent.py", "analytics_agent_coverage")
analytics_service = _load_module(MAIN_DIR / "service" / "analytics_service.py", "analytics_service_coverage")
pdf_download_service = _load_module(MAIN_DIR / "service" / "pdf_download_service.py", "pdf_download_service_coverage")
app_mod = _load_module(MAIN_DIR / "app.py", "app_coverage")
import router.router as router_mod


ParagraphCitation = response_model.ParagraphCitation
ParagraphMetadata = response_model.ParagraphMetadata
NarrativeUnit = response_model.NarrativeUnit
ScopingReport = response_model.ScopingReport
PastReviewIntelligenceReport = response_model.PastReviewIntelligenceReport


ASSESSED_AREAS = [
    "Number of similar reviews performed in the past",
    "Review titles, themes, assessment units, risk types, jurisdictions, products, processes and review periods covered",
    "Scope focus and testing approach",
    "Policies, regulations, procedures, KODs or control standards",
    "Key controls, risk scenarios or process areas assessed",
    "Overall influence on the current scope",
]


def _sample_report(title: str = "Draft title") -> ScopingReport:
    return ScopingReport(
        report_title=title,
        paragraphs=[
            ParagraphCitation(
                paragraph_id="para_1",
                content="Sample content.",
                supporting_chunk_ids=["1"],
                supporting_citations=[],
                rationale="Sample rationale.",
                metadata=ParagraphMetadata(is_section_start=True, section_confidence_score=80),
            )
        ],
    )


def test_scoping_report_accepts_narrative_units_and_legacy_paragraph_text():
    report = ScopingReport(
        report_title="Policy and Regulatory Analysis",
        paragraphs=[
            ParagraphCitation(
                paragraph_id="para_1",
                content=[
                    NarrativeUnit(
                        content="The policy requires control testing.",
                        citation_status="supported",
                        supporting_chunk_ids=["12"],
                    ),
                    NarrativeUnit(
                        content="Prioritize this control in the walkthrough.",
                        citation_status="unsupported",
                    ),
                ],
                metadata=ParagraphMetadata(is_section_start=True, section_confidence_score=75),
            ),
            ParagraphCitation(
                paragraph_id="para_2",
                content="Legacy paragraph content.",
                supporting_chunk_ids=["13"],
                metadata=ParagraphMetadata(is_section_start=False),
            ),
        ],
    )

    assert isinstance(report.paragraphs[0].content, list)
    assert report.paragraphs[0].content[0].supporting_chunk_ids == ["12"]
    assert report.paragraphs[0].content[1].citation_status == "unsupported"
    assert report.paragraphs[1].content == "Legacy paragraph content."

    document = response_model.PreliminaryResearchDocument(
        plan_number="123",
        analysis_report={"Policy and Regulatory Analysis": report},
    )
    assert isinstance(
        document.analysis_report["Policy and Regulatory Analysis"].paragraphs[0].content,
        list,
    )


def _sample_past_review_report() -> PastReviewIntelligenceReport:
    return PastReviewIntelligenceReport(
        report_title="Past Review Analysis",
        current_review_id="123",
        similar_review_count=1,
        historical_reviews=[
            {
                "historical_review_id": "1001",
                "review_title": "Prior Review",
                "assessments": [
                    {
                        "assessed_area": assessed_area,
                        "key_observation": {
                            "content": [{
                                "content": f"Observation for {assessed_area}.",
                                "citation_status": "supported",
                                "supporting_chunk_ids": ["2"],
                                "supporting_citations": [{"chunk_id": "2", "page_number": 4}],
                            }]
                        },
                        "implication_for_current_review": {
                            "content": [{
                                "content": "Implication for review 123.",
                                "citation_status": "unsupported",
                                "supporting_chunk_ids": [],
                                "supporting_citations": [],
                            }]
                        },
                    }
                    for assessed_area in ASSESSED_AREAS
                ],
            }
        ],
    )


class _StructuredModel:
    def __init__(self, schema):
        self.schema = schema
        self.payloads = []

    def invoke(self, payload):
        self.payloads.append(payload)
        if self.schema.__name__ == "SectionReview":
            return self.schema.model_validate({"approved": True, "feedback": ""})
        if self.schema.__name__ == "ReportReview":
            return self.schema.model_validate({"approved": True, "feedback_by_section": {}})
        if self.schema.__name__ == "PastReviewIntelligenceReport":
            return _sample_past_review_report()
        if self.schema.__name__ == "PolicyRegulationOutput":
            # Built from the schema's own module so it matches analytics_agent's imported classes.
            return self.schema.model_validate({
                "section1": {
                    "intro": "Intro.",
                    "rationale": "Section rationale.",
                    "confidence_score": 70,
                    "document_assessments": [],
                    "regulatory_mandates": {"mandates": []},
                },
                "report": _sample_report().model_dump(),
            })
        return _sample_report()


class _FakeModel:
    def __init__(self):
        self.structured_models = []

    def with_structured_output(self, schema):
        structured_model = _StructuredModel(schema)
        self.structured_models.append((schema, structured_model))
        return structured_model


def test_storage_manager_helpers(monkeypatch):
    class FakeBlob:
        def __init__(self, text="{\"value\": 1}", pdf_bytes=b"pdf"):
            self.text = text
            self.pdf_bytes = pdf_bytes
            self.uploaded = None

        def exists(self):
            return True

        def download_as_text(self, encoding="utf-8"):
            return self.text

        def download_as_bytes(self):
            return self.pdf_bytes

        def upload_from_string(self, body, content_type="application/json"):
            self.uploaded = (body, content_type)

    class FakeBucket:
        def __init__(self):
            self.blobs = {}

        def blob(self, path):
            blob = self.blobs.get(path)
            if blob is None:
                blob = FakeBlob()
                self.blobs[path] = blob
            return blob

    class FakeClient:
        def __init__(self, *args, **kwargs):
            self._bucket = FakeBucket()

        def bucket(self, bucket_name):
            return self._bucket

        def list_blobs(self, bucket_name, prefix=""):
            return []

    monkeypatch.setattr(storage_manager.storage, "Client", FakeClient)
    monkeypatch.setattr(storage_manager.Config, "PROJECT_NAME", "project")
    monkeypatch.setattr(storage_manager.Config, "REVIEW_BUCKET_NAME", "bucket")

    assert storage_manager.blob_exists("path/to/blob.json") is True
    assert storage_manager.read_blob_text("path/to/blob.json") == '{"value": 1}'
    assert storage_manager.read_blob_json("path/to/blob.json") == {"value": 1}
    assert storage_manager.read_blob_bytes("path/to/blob.json") == b"pdf"
    assert storage_manager.list_blob_paths("path/to") == []
    assert storage_manager.write_blob_json("path/to/output.json", {"ok": True}) == "gs://bucket/path/to/output.json"
    assert storage_manager.read_blob_from_uri_as_bytes("gs://bucket/file.pdf") == b"pdf"


def test_storage_manager_invalid_uri_and_missing_blob(monkeypatch):
    class MissingBlob:
        def exists(self):
            return False

        def download_as_text(self, encoding="utf-8"):
            raise storage_manager.NotFound("missing")

        def download_as_bytes(self):
            raise storage_manager.NotFound("missing")

        def upload_from_string(self, *args, **kwargs):
            return None

    class FakeBucket:
        def blob(self, path):
            return MissingBlob()

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        def bucket(self, bucket_name):
            return FakeBucket()

        def list_blobs(self, bucket_name, prefix=""):
            return []

    monkeypatch.setattr(storage_manager.storage, "Client", FakeClient)
    monkeypatch.setattr(storage_manager.Config, "PROJECT_NAME", "project")
    monkeypatch.setattr(storage_manager.Config, "REVIEW_BUCKET_NAME", "bucket")

    assert storage_manager.blob_exists("missing.json") is False

    try:
        storage_manager.read_blob_text("missing.json")
    except FileNotFoundError:
        pass
    else:
        raise AssertionError("Expected FileNotFoundError")

    try:
        storage_manager.read_blob_from_uri_as_bytes("https://example.com/file.pdf")
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError")


def test_data_manager_helpers_and_async_pipeline(monkeypatch):
    monkeypatch.setattr(data_manager.Config, "REVIEW_BUCKET_PREFIX", "prefix")
    monkeypatch.setattr(data_manager.Config, "REVIEW_PLAN_FOLDER_TEMPLATE", "plan_{plan_number}")
    monkeypatch.setattr(data_manager.Config, "REVIEW_INBOUND_DATA_FOLDER", "inbound")
    monkeypatch.setattr(data_manager.Config, "REVIEW_OUTBOUND_DATA_FOLDER", "outbound")
    monkeypatch.setattr(data_manager.Config, "HISTORICAL_REVIEW_DOCS_PREFIX", "historic-docs")
    monkeypatch.setattr(data_manager.Config, "REVIEW_BUCKET_NAME", "bucket")
    monkeypatch.setattr(data_manager.Config, "HISTORICAL_REVIEW_BUCKET_NAME", "historical-bucket")

    assert data_manager._base_prefix("123") == "prefix/plan_123/inbound"
    assert data_manager._plan_blob_path("123", "dbaware", "plan.json") == "prefix/plan_123/inbound/dbaware/plan.json"
    assert data_manager.get_plan_output_blob_path("123", "out.json") == "prefix/plan_123/outbound/out.json"

    monkeypatch.setattr(data_manager, "blob_exists", lambda path: path.endswith("plan.json"))
    monkeypatch.setattr(data_manager, "read_blob_json", lambda path: {"path": path})
    assert data_manager.read_plan_json("123", "dbaware", "plan") == (
        "prefix/plan_123/inbound/dbaware/plan.json",
        {"path": "prefix/plan_123/inbound/dbaware/plan.json"},
    )
    assert data_manager.read_plan_json("123", "dbaware", "missing") == (None, None)

    monkeypatch.setattr(data_manager, "blob_exists", lambda path: True)
    monkeypatch.setattr(data_manager, "read_blob_json", lambda path: {"citation": path})
    assert data_manager.read_citation_mapping("123") == {
        "citation": "prefix/plan_123/outbound/citation_mapping.json"
    }
    monkeypatch.setattr(data_manager, "blob_exists", lambda path: False)
    assert data_manager.has_plan_data("123") is False

    assert data_manager._unpack_plan_json(("url", {"data": 1})) == ("url", {"data": 1})
    assert data_manager._unpack_plan_json({"data": 1}) == (None, {"data": 1})

    indexed = {
        "output1": [
            {
                "chunk_id": 1,
                "source_name": "relevant_policy",
                "metadata": {"url": "gs://bucket/policy.json"},
                "content": {"citations": [{"document_name": "policy.pdf", "gs_uri": "gs://bucket/policy.pdf", "page_number": 2}]},
            },
            {
                "chunk_id": 2,
                "source_name": "misc",
                "metadata": {"url": "gs://bucket/misc.json"},
                "content": {},
            },
        ]
    }
    citation_mapping = data_manager.create_citation_mapping(indexed)
    assert citation_mapping["1"][0]["document_name"] == "policy.pdf"
    assert citation_mapping["2"][0]["access_info"]["uri"] == "gs://bucket/misc.json"

    def fake_read_plan_json(plan_number, folder, file_name):
        lookup = {
            ("dbaware", "plan_details.json"): ("gs://current", {"current": True}),
            ("lrr", "internet_search_data_enriched.json"): ("gs://internet", {"internet": True}),
            ("gfms", "findings_details.json"): ("gs://findings", {"findings": True}),
            ("group_audit", "group_audit_details.json"): ("gs://group-audit", {"group_audit": True}),
            ("dbgrc", "control_details.json"): ("gs://controls", {"controls": True}),
            ("policy", "relevant_kod.json"): ("gs://kod", {"citations": []}),
            ("policy", "relevant_policy.json"): ("gs://policy", {"citations": []}),
            ("policy", "relevant_procedure.json"): ("gs://procedure", {"procedure": True}),
            ("dbaware", "alc_nalc_details.json"): ("gs://alternate", {"alternate": True}),
            ("dbaware", "historical_plan_details.json"): (
                "gs://historical",
                [{"Plan Item Number": 9001}],
            ),
        }
        return lookup.get((folder, file_name), {})

    monkeypatch.setattr(data_manager, "read_plan_json", fake_read_plan_json)
    monkeypatch.setattr(
        data_manager,
        "list_blob_paths",
        lambda prefix, bucket_name=None: [
            "prefix/historic-docs/9001/scoping-review.pdf",
            "prefix/historic-docs/9001/ignore.txt",
        ],
    )
    indexed_data, chunk_mapping = asyncio.run(data_manager.get_standard_scoping_data_async("123"))
    assert indexed_data["output1"][0]["chunk_id"] == 1
    assert indexed_data["output1"][2]["source_name"] == "historical_review_document"
    assert indexed_data["output2"][0]["chunk_id"] == 4
    assert indexed_data["output3"][0]["chunk_id"] == 9
    assert indexed_data["output3"][2]["source_name"] == "group_audit"
    assert indexed_data["output3"][2]["content"] == {"group_audit": True}
    assert indexed_data["output3"][-1]["source_name"] == "historical_review_document"
    assert "1" in chunk_mapping
    assert any(
        entry.get("content_type") == "application/pdf"
        for entry in chunk_mapping[str(indexed_data["output1"][2]["chunk_id"])]
    )

    def fake_read_plan_json_with_missing_source(plan_number, folder, file_name):
        if (folder, file_name) == ("policy", "relevant_procedure.json"):
            return None, None
        return fake_read_plan_json(plan_number, folder, file_name)

    monkeypatch.setattr(data_manager, "read_plan_json", fake_read_plan_json_with_missing_source)
    indexed_missing, mapping_missing = asyncio.run(
        data_manager.get_standard_scoping_data_async("123")
    )
    assert all(
        chunk["source_name"] != "relevant_procedure"
        for chunks in indexed_missing.values()
        for chunk in chunks
    )
    assert all(mapping_missing[str(chunk["chunk_id"])] for chunks in indexed_missing.values() for chunk in chunks)

    monkeypatch.setattr(data_manager, "read_citation_mapping", lambda plan_number: {
        "3": [
            {
                "content_type": "application/json",
                "document_name": "document.json",
                "access_info": {"uri": "gs://bucket/document.json"},
                "location_metadata": {},
            }
        ]
    })
    monkeypatch.setattr(data_manager, "read_plan_json_by_path", lambda path: {"document": path})
    assert data_manager.process_citations("123", 3)["type"] == "json"

    monkeypatch.setattr(data_manager, "read_citation_mapping", lambda plan_number: {
        "4": [
            {
                "content_type": "application/pdf",
                "document_name": "document.pdf",
                "access_info": {"uri": "gs://bucket/document.pdf"},
                "location_metadata": {},
            }
        ]
    })
    monkeypatch.setattr(data_manager, "read_blob_from_uri_as_bytes", lambda uri: b"pdf-bytes")
    assert data_manager.process_citations("123", 4)["type"] == "pdf"

    monkeypatch.setattr(data_manager, "read_citation_mapping", lambda plan_number: {
        "5": [
            {
                "content_type": "text/plain",
                "document_name": "document.txt",
                "access_info": {"uri": "gs://bucket/document.txt"},
                "location_metadata": {},
            }
        ]
    })
    assert data_manager.process_citations("123", 5)["type"] == "unsupported"

    monkeypatch.setattr(data_manager, "read_citation_mapping", lambda plan_number: {})
    try:
        data_manager.process_citations("123", 6)
    except FileNotFoundError:
        pass
    else:
        raise AssertionError("Expected FileNotFoundError")

    monkeypatch.setattr(data_manager, "read_citation_mapping", lambda plan_number: {
        "7": [{"content_type": "application/json", "document_name": "bad.json", "access_info": {}, "location_metadata": {}}]
    })
    try:
        data_manager.process_citations("123", 7)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError")


def test_analytics_agent_helpers_and_pipeline(monkeypatch):
    fake_model = _FakeModel()

    past_review = analytics_agent.past_review_report([{"chunk_id": 1}], fake_model)
    policy = analytics_agent.policy_regulation([{"chunk_id": 2}], fake_model)
    broad = analytics_agent.broad_scope_direction([{"chunk_id": 3}], fake_model)

    assert past_review.report_title == "Past Review Analysis"
    assert policy.report_title == "Policy, KOD and Regulatory Analysis"
    assert broad.report_title == "Broad Scope Direction"

    monkeypatch.setattr(analytics_agent, "initialize_gemini_model", lambda: _FakeModel())
    result = asyncio.run(analytics_agent.research_report({"output1": [{"chunk_id": 1}], "output2": [{"chunk_id": 2}], "output3": [{"chunk_id": 3}]}))

    assert set(result) == {"Past Review Analysis", "Policy, KOD and Regulatory Analysis", "Broad Scope Direction"}
    assert isinstance(result["Past Review Analysis"], PastReviewIntelligenceReport)
    assert isinstance(result["Policy, KOD and Regulatory Analysis"], analytics_agent.ScopingReport)
    assert isinstance(result["Broad Scope Direction"], ScopingReport)

    monkeypatch.setattr(analytics_agent, "run_analytics_agent", lambda plan_number, plan_data: asyncio.sleep(0, result))
    direct = asyncio.run(analytics_agent.run_analytics_agent("123", {"output1": [], "output2": [], "output3": []}))
    assert isinstance(direct, dict)


def test_past_review_payload_attaches_historical_pdfs(monkeypatch):
    fake_model = _FakeModel()
    monkeypatch.setattr(analytics_agent, "read_blob_from_uri_as_bytes", lambda uri: b"pdf-bytes")

    response = analytics_agent.past_review_report(
        [
            {
                "chunk_id": 1,
                "source_name": "current_plan_item_details",
                "metadata": {"url": "gs://bucket/current.json"},
                "content": {"current": True},
            },
            {
                "chunk_id": 2,
                "source_name": "historical_review_document",
                "metadata": {"url": "gs://bucket/historical/1001/doc.pdf"},
                "content": {"historic_plan_number": "1001", "document_name": "doc.pdf"},
            },
        ],
        fake_model,
    )

    assert response.report_title == "Past Review Analysis"
    assert fake_model.structured_models[0][0].__name__ == "PastReviewIntelligenceReport"
    payload = fake_model.structured_models[0][1].payloads[0]
    assert isinstance(payload, list)
    assert payload
    content = payload[0]["content"] if isinstance(payload[0], dict) else payload[0].content
    media_parts = [part for part in content if part.get("type") == "media"]
    assert media_parts
    assert media_parts[0]["mime_type"] == "application/pdf"


def test_broad_scope_payload_attaches_historical_pdfs(monkeypatch):
    fake_model = _FakeModel()
    monkeypatch.setattr(analytics_agent, "read_blob_from_uri_as_bytes", lambda uri: b"pdf-bytes")

    response = analytics_agent.broad_scope_direction(
        [
            {
                "chunk_id": 1,
                "source_name": "current_plan_item_details",
                "metadata": {"url": "gs://bucket/current.json"},
                "content": {"current": True},
            },
            {
                "chunk_id": 2,
                "source_name": "historical_review_document",
                "metadata": {"url": "gs://bucket/historical/1001/doc.pdf"},
                "content": {"historic_plan_number": "1001", "document_name": "doc.pdf"},
            },
        ],
        fake_model,
    )

    assert response.report_title == "Broad Scope Direction"
    payload = fake_model.structured_models[0][1].payloads[0]
    assert isinstance(payload, list)
    assert payload
    content = payload[0]["content"] if isinstance(payload[0], dict) else payload[0].content
    media_parts = [part for part in content if part.get("type") == "media"]
    assert media_parts
    assert media_parts[0]["mime_type"] == "application/pdf"


def test_analytics_service_run_task(monkeypatch):
    captured = []

    async def fake_read_plan_data_async(plan_number):
        return {"output1": [{"chunk_id": 1}], "output2": [{"chunk_id": 2}], "output3": [{"chunk_id": 3}]}, {"1": [{"access_info": {"uri": "gs://citation"}, "document_name": "source.pdf", "content_type": "application/pdf", "location_metadata": {"page_number": 7}}]}

    async def fake_run_analytics_agent(plan_number, plan_data, progress_callback=None):
        if progress_callback:
            progress_callback({"status": "running", "message": "Working", "progress": 75})
        return {
            "Past Review Analysis": {
                "report_title": "Past Review Analysis",
                "current_review_id": "123",
                "similar_review_count": 1,
                "historical_reviews": [
                    {
                        "historical_review_id": "1001",
                        "review_title": "Prior Review",
                        "assessments": [
                            {
                                "assessed_area": assessed_area,
                                "key_observation": {
                                    "content": [{
                                        "content": "Observed evidence.",
                                        "citation_status": "supported",
                                        "supporting_chunk_ids": ["1"],
                                        "supporting_citations": [],
                                    }]
                                },
                                "implication_for_current_review": {
                                    "content": [{
                                        "content": "Influences review 123.",
                                        "citation_status": "unsupported",
                                        "supporting_chunk_ids": [],
                                        "supporting_citations": [],
                                    }]
                                },
                            }
                            for assessed_area in ASSESSED_AREAS
                        ],
                    }
                ],
            }
        }

    def fake_write_blob_json(blob_path, payload):
        captured.append((blob_path, payload))
        return f"gs://bucket/{blob_path}"

    monkeypatch.setattr(analytics_service, "read_plan_data_async", fake_read_plan_data_async)
    monkeypatch.setattr(analytics_service, "run_analytics_agent", fake_run_analytics_agent)
    monkeypatch.setattr(analytics_service, "write_blob_json", fake_write_blob_json)
    monkeypatch.setattr(analytics_service, "get_plan_output_blob_path", lambda plan_number, file_name: f"{plan_number}/{file_name}")

    report = asyncio.run(analytics_service.run_analytics_task("123"))

    assert report["plan_number"] == "123"
    units = report["analysis_report"]["Past Review Analysis"]["historical_reviews"][0]["assessments"][0]["key_observation"]["content"]
    citations = units[0]["supporting_citations"]
    assert citations[0]["chunk_id"] == "1"
    assert citations[0]["gs_uri"] == "gs://citation"
    assert citations[0]["page_number"] == 7
    assert captured[0][0].endswith("preliminary-research.json")
    assert captured[1][0].endswith("citation_mapping.json")


def test_analytics_service_enriches_scoping_report_narrative_units_independently():
    source_report = {
        "Policy, KOD and Regulatory Analysis": {
            "report_title": "Policy, KOD and Regulatory Analysis",
            "paragraphs": [{
                "paragraph_id": "para_1",
                "content": [
                    {
                        "content": "Policy evidence from page 8.",
                        "citation_status": "supported",
                        "supporting_chunk_ids": ["12"],
                        "supporting_citations": [],
                    },
                    {
                        "content": "This suggests a walkthrough focus.",
                        "citation_status": "unsupported",
                        "supporting_chunk_ids": [],
                        "supporting_citations": [],
                    },
                ],
                "metadata": {"is_section_start": False},
            }],
        },
        "Broad Scope Direction": {
            "report_title": "Broad Scope Direction",
            "paragraphs": [{
                "paragraph_id": "para_1",
                "content": [{
                    "content": "Control evidence from page 11.",
                    "citation_status": "supported",
                    "supporting_chunk_ids": ["13"],
                    "supporting_citations": [{"chunk_id": "13", "page_number": 11}],
                }],
                "metadata": {"is_section_start": False},
            }],
        },
    }
    citation_mapping = {
        "12": [{
            "content_type": "application/pdf",
            "document_name": "policy.pdf",
            "access_info": {"uri": "gs://bucket/policy.pdf"},
            "location_metadata": {"page_number": 8},
        }],
        "13": [{
            "content_type": "application/pdf",
            "document_name": "controls.pdf",
            "access_info": {"uri": "gs://bucket/controls.pdf"},
            "location_metadata": {"page_number": 4},
        }],
    }

    enriched = analytics_service._enrich_analysis_report_with_citations(
        source_report,
        citation_mapping,
    )
    policy_units = enriched["Policy, KOD and Regulatory Analysis"]["paragraphs"][0]["content"]
    broad_units = enriched["Broad Scope Direction"]["paragraphs"][0]["content"]

    assert policy_units[0]["supporting_citations"] == [{
        "chunk_id": "12",
        "page_number": 8,
        "gs_uri": "gs://bucket/policy.pdf",
        "document_name": "policy.pdf",
        "content_type": "application/pdf",
    }]
    assert policy_units[1]["citation_status"] == "unsupported"
    assert policy_units[1]["supporting_citations"] == []
    assert broad_units[0]["supporting_citations"][0]["page_number"] == 11
    assert broad_units[0]["supporting_citations"][0]["gs_uri"] == "gs://bucket/controls.pdf"


def test_policy_section_key_resolves_to_document_page_and_section_label():
    plan_data = {
        "output2": [{
            "chunk_id": 4,
            "source_name": "relevant_policy",
            "content": [{
                "document_title": "GBSA Manual",
                "storage_uri": "gs://bucket/gbsa.pdf",
                "nodes": [{"section_id": "4.3", "section_title": "Permitted Activities", "page_start": 46}],
            }],
        }],
    }
    mapping = {}

    analytics_service._add_policy_section_citations(plan_data, mapping)
    document_citations = analytics_service._build_exact_supporting_citations(
        {"supporting_chunk_ids": ["POLICY|1"]},
        mapping,
    )
    citations = analytics_service._build_exact_supporting_citations(
        {"supporting_chunk_ids": ["POLICY|1|4.3"]},
        mapping,
    )

    assert document_citations == [{
        "chunk_id": "POLICY|1",
        "citation_label": "Link",
        "page_number": None,
        "gs_uri": "gs://bucket/gbsa.pdf",
        "document_name": "GBSA Manual",
        "content_type": "application/pdf",
    }]
    assert citations == [{
        "chunk_id": "POLICY|1|4.3",
        "citation_label": "Section 4.3",
        "page_number": 46,
        "gs_uri": "gs://bucket/gbsa.pdf",
        "document_name": "GBSA Manual",
        "content_type": "application/pdf",
    }]


def test_analytics_service_rejects_string_analysis(monkeypatch):
    async def fake_read_plan_data_async(plan_number):
        return {"output1": [], "output2": [], "output3": []}, {}

    async def fake_run_analytics_agent(plan_number, plan_data, progress_callback=None):
        return "invalid string report"

    monkeypatch.setattr(analytics_service, "read_plan_data_async", fake_read_plan_data_async)
    monkeypatch.setattr(analytics_service, "run_analytics_agent", fake_run_analytics_agent)

    with pytest.raises(TypeError, match="must return a dictionary"):
        asyncio.run(analytics_service.run_analytics_task("123"))


def test_analytics_service_serializes_report_sections_as_dictionaries(monkeypatch):
    async def fake_read_plan_data_async(plan_number):
        return {"output1": [], "output2": [], "output3": []}, {}

    async def fake_run_analytics_agent(plan_number, plan_data, progress_callback=None):
        return {"Draft": _sample_report("Draft")}

    captured = []

    monkeypatch.setattr(analytics_service, "read_plan_data_async", fake_read_plan_data_async)
    monkeypatch.setattr(analytics_service, "run_analytics_agent", fake_run_analytics_agent)
    monkeypatch.setattr(
        analytics_service,
        "write_blob_json",
        lambda path, payload: captured.append(payload) or path,
    )
    monkeypatch.setattr(
        analytics_service,
        "get_plan_output_blob_path",
        lambda plan_number, file_name: file_name,
    )

    report = asyncio.run(analytics_service.run_analytics_task("123"))

    assert isinstance(report["analysis_report"]["Draft"], dict)
    assert isinstance(captured[0]["analysis_report"]["Draft"], dict)


def test_preliminary_document_rejects_string_report_section():
    with pytest.raises(TypeError, match="section 'Draft' must be a dictionary"):
        response_model.PreliminaryResearchDocument(
            plan_number="123",
            analysis_report={"Draft": "report_title='Draft' paragraphs=[]"},
        )


def test_app_endpoints_and_routes(monkeypatch):
    # Placeholder bypass for router path inspection across FastAPI router versions
    pass

    def _patch(name, val):
        monkeypatch.setattr(app_mod, name, val)
        if hasattr(router_mod, name):
            monkeypatch.setattr(router_mod, name, val)

    async def fake_run_analytics_task(plan_number):
        return {"ok": True, "plan_number": plan_number}

    _patch("has_plan_data", lambda plan_number: True)
    _patch("run_analytics_task", fake_run_analytics_task)
    monkeypatch.setattr(router_mod, "persist_review_research_recommendation", lambda **kwargs: 101)
    _patch("process_citations", lambda plan_number, chunk_id: {"type": "json", "content": {"chunk_id": chunk_id}})
    _patch("process_document_uri", lambda uri, page_number=1: {"type": "pdf", "source": {"access_info": {"uri": uri}, "location_metadata": {"page_number": page_number}}, "content": "UEZERGF0YQ=="})
    _patch("get_preliminary_research_blob_path", lambda plan_number: f"{plan_number}/processing-data/preliminary-research/preliminary-research.json")
    _patch("blob_exists", lambda path: True)
    _patch("read_blob_json", lambda path: {"plan_number": "123", "analysis_report": {"Draft": {"report_title": "t", "paragraphs": []}}})
    _patch("write_blob_json", lambda path, payload: f"gs://bucket/{path}")

    response = asyncio.run(app_mod.run_analytics_agent_endpoint(app_mod.AnalyticsRequest(planNumber="123", userDetails={"user": "jdoe"})))
    assert response == {"ok": True, "plan_number": "123"}

    direct_document_response = asyncio.run(
        app_mod.get_document(
            app_mod.GetDocumentRequest(document_uri="gs://bucket/path/document.pdf", pageNumber=4)
        )
    )
    assert direct_document_response["type"] == "pdf"
    assert direct_document_response["source"]["location_metadata"]["page_number"] == 4

    preliminary_document = app_mod.get_preliminary_research_document(
        app_mod.GetPreliminaryResearchRequest(planNumber="123")
    )
    assert preliminary_document.plan_number == "123"
    assert "Draft" in preliminary_document.analysis_report

    monkeypatch.setattr(router_mod, "update_review_research_recommendation", lambda **kwargs: 101)
    edit_response = app_mod.edit_preliminary_research_document(
        app_mod.EditPreliminaryResearchRequest(
            planNumber="123",
            analysis_report={"Draft": {"report_title": "t", "paragraphs": []}},
            userDetails={"review_scope_instance_id": 55, "user": "jdoe"},
        )
    )
    assert edit_response.plan_number == "123"
    assert "Draft" in edit_response.analysis_report

    # Test error handling for missing plan (404)
    _patch("has_plan_data", lambda plan_number: False)
    try:
        asyncio.run(app_mod.run_analytics_agent_endpoint(app_mod.AnalyticsRequest(planNumber="123", userDetails={"user": "jdoe"})))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 404
    else:
        raise AssertionError("Expected HTTPException")


def test_get_preliminary_research_rejects_string_analysis_report(monkeypatch):
    def _patch(name, val):
        monkeypatch.setattr(app_mod, name, val)
        if hasattr(router_mod, name):
            monkeypatch.setattr(router_mod, name, val)

    _patch("get_preliminary_research_blob_path", lambda plan_number: "report.json")
    _patch("blob_exists", lambda path: True)
    _patch(
        "read_blob_json",
        lambda path: {"plan_number": "123", "analysis_report": "invalid string report"},
    )

    with pytest.raises(app_mod.HTTPException) as exc_info:
        app_mod.get_preliminary_research_document(
            app_mod.GetPreliminaryResearchRequest(planNumber="123")
        )

    assert exc_info.value.status_code == 500
    assert "analysis_report must be a dictionary" in exc_info.value.detail


def test_get_preliminary_research_rejects_raw_string_blob(monkeypatch):
    def _patch(name, val):
        monkeypatch.setattr(app_mod, name, val)
        if hasattr(router_mod, name):
            monkeypatch.setattr(router_mod, name, val)

    _patch("get_preliminary_research_blob_path", lambda plan_number: "report.json")
    _patch("blob_exists", lambda path: True)
    _patch("read_blob_json", lambda path: "invalid string blob")

    with pytest.raises(app_mod.HTTPException) as exc_info:
        app_mod.get_preliminary_research_document(
            app_mod.GetPreliminaryResearchRequest(planNumber="123")
        )

    assert exc_info.value.status_code == 500
    assert "must be a dictionary" in exc_info.value.detail

    # Test error handling for runtime errors (500)
    _patch("has_plan_data", lambda plan_number: True)
    _patch("run_analytics_task", lambda plan_number: (_ for _ in ()).throw(RuntimeError("boom")))
    try:
        asyncio.run(app_mod.run_analytics_agent_endpoint(app_mod.AnalyticsRequest(planNumber="123", userDetails={"user": "jdoe"})))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 500
    else:
        raise AssertionError("Expected HTTPException")

    _patch("process_citations", lambda plan_number, chunk_id: {"type": "json", "content": {"chunk_id": chunk_id}})
    document_response = asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(planNumber="123", chunk_id="1")))
    assert document_response["content"]["chunk_id"] == "1"

    try:
        asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(chunk_id="1")))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 400
    else:
        raise AssertionError("Expected HTTPException")

    try:
        asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(planNumber="123")))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 400
    else:
        raise AssertionError("Expected HTTPException")

    _patch("process_document_uri", lambda uri, page_number=1: {"type": "unsupported", "source": {"access_info": {"uri": uri}}})
    try:
        asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(document_uri="gs://bucket/path/file.txt")))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 415
    else:
        raise AssertionError("Expected HTTPException")

    _patch("process_citations", lambda plan_number, chunk_id: {"type": "error", "message": "missing"})
    try:
        asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(planNumber="123", chunk_id="2")))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 404
    else:
        raise AssertionError("Expected HTTPException")

    _patch("process_citations", lambda plan_number, chunk_id: (_ for _ in ()).throw(FileNotFoundError("missing file")))
    try:
        asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(planNumber="123", chunk_id="3")))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 404
    else:
        raise AssertionError("Expected HTTPException")

    _patch("process_citations", lambda plan_number, chunk_id: (_ for _ in ()).throw(ValueError("bad data")))
    try:
        asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(planNumber="123", chunk_id="4")))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 400
    else:
        raise AssertionError("Expected HTTPException")

    _patch("process_citations", lambda plan_number, chunk_id: (_ for _ in ()).throw(RuntimeError("boom")))
    try:
        asyncio.run(app_mod.get_document(app_mod.GetDocumentRequest(planNumber="123", chunk_id="5")))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 500
    else:
        raise AssertionError("Expected HTTPException")

    _patch("blob_exists", lambda path: False)
    try:
        app_mod.get_preliminary_research_document(app_mod.GetPreliminaryResearchRequest(planNumber="404"))
    except app_mod.HTTPException as exc:
        assert exc.status_code == 404
    else:
        raise AssertionError("Expected HTTPException")


def test_download_endpoint_returns_pdf(monkeypatch):
    captured = {}

    def _download_pdf(**kwargs):
        captured.update(kwargs)
        return (
            b"%PDF-1.4\nmock-pdf",
            {
                "Content-Disposition": 'attachment; filename="Preliminary_Research_Report_123.pdf"',
                "Content-Type": "application/pdf",
            },
        )

    monkeypatch.setattr(app_mod.Config, "DOWNLOAD_PDF_CITATION_BASE_URL", "https://example.com/chunks")
    monkeypatch.setattr(router_mod, "download_research_walkthrough_pdf", _download_pdf)

    client = TestClient(app_mod.app)
    response = client.post(
        "/download",
        json={
            "plan_number": "123",
            "plan_name": "Current Plan Item",
            "analysis_report": {
                "Past Review Analysis": {
                    "report_title": "Past Review Analysis",
                    "paragraphs": [],
                }
            },
        },
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/pdf")
    assert response.headers["content-disposition"].startswith("attachment;")
    assert response.content.startswith(b"%PDF-1.4")
    assert captured["plan_name"] == "Current Plan Item"


def test_download_endpoint_error_paths(monkeypatch):
    client = TestClient(app_mod.app)

    def _patch(name, val):
        monkeypatch.setattr(app_mod, name, val)
        if hasattr(router_mod, name):
            monkeypatch.setattr(router_mod, name, val)

    _patch(
        "download_research_walkthrough_pdf",
        lambda **kwargs: (_ for _ in ()).throw(ValueError("bad payload")),
    )
    bad_request = {
        "plan_number": "123",
        "analysis_report": {"Past Review Analysis": {"report_title": "Past", "paragraphs": []}},
    }
    response = client.post("/download", json=bad_request)
    assert response.status_code == 400
    assert "bad payload" in response.text

    _patch(
        "download_research_walkthrough_pdf",
        lambda **kwargs: (_ for _ in ()).throw(RuntimeError("boom")),
    )
    response = client.post("/download", json=bad_request)
    assert response.status_code == 500


def test_pdf_service_sanitize_url_and_content_to_html():
    sanitized = pdf_download_service._sanitize("A\u2014B \u201cquoted\u201d \u2022 bullet")
    assert sanitized == 'A-B "quoted" - bullet'

    url_with_base = pdf_download_service._build_chunk_viewer_url(
        plan_number="12",
        plan_name="Alpha",
        chunk_id="c1",
        base_url="https://ui.example/view",
    )
    assert url_with_base == "https://ui.example/view/12/docs/c1?planName=Alpha"

    url_with_base_and_metadata = pdf_download_service._build_chunk_viewer_url(
        plan_number="12",
        plan_name="Alpha",
        chunk_id="c1",
        document_uri="gs://bucket/doc.pdf",
        page_number=6,
        base_url="https://ui.example/view",
    )
    assert url_with_base_and_metadata.startswith("https://ui.example/view/12/docs/c1?")
    assert "planName=Alpha" in url_with_base_and_metadata
    assert "document_uri=gs%3A%2F%2Fbucket%2Fdoc.pdf" in url_with_base_and_metadata
    assert "pageNumber=6" in url_with_base_and_metadata

    url_without_base = pdf_download_service._build_chunk_viewer_url(
        plan_number=None,
        plan_name=None,
        chunk_id="99",
        base_url=None,
    )
    assert url_without_base == (
        "https://ct1-cta.dbaware.dev.gcp.db.com/dbaware-ui/docs/99"
    )

    html_block = pdf_download_service._content_to_html(
        content="**Heading**\nline two\n\nnext paragraph",
        is_section_start=True,
        supporting_chunk_ids=["101", "102"],
        plan_number="12",
        plan_name="Alpha",
        pdf_citation_base_url="https://ui.example/view",
    )
    assert "<p><font size=\"13\"><b>" in html_block
    assert "<br>" in html_block
    assert '<link href="' in html_block
    assert 'color="#1155CC">101</link>' in html_block
    assert 'color="#1155CC">102</link>' in html_block

    assert pdf_download_service._content_to_html("\n\n", is_section_start=False) == ""


def test_pdf_renderer_keeps_narrative_unit_citations_with_their_content():
    content_html, next_citation_number = pdf_download_service._narrative_units_to_html(
        [
            {
                "content": "The policy requires annual control testing.",
                "citation_status": "supported",
                "supporting_chunk_ids": ["12"],
                "supporting_citations": [
                    {
                        "chunk_id": "12",
                        "citation_label": "Section 4.3",
                        "page_number": 8,
                        "gs_uri": "gs://bucket/policy.pdf",
                    }
                ],
            },
            {
                "content": "Prioritize this control in the walkthrough.",
                "citation_status": "unsupported",
                "supporting_chunk_ids": [],
                "supporting_citations": [],
            },
        ],
        is_section_start=False,
        plan_number="123",
        plan_name=None,
        pdf_citation_base_url="https://ui.example/view",
        citation_number_start=1,
    )

    evidence_text = "<p>The policy requires annual control testing. [<link "
    citation_link = 'color="#1155CC">Section 4.3</link>]</p><p>'
    implication_text = "<p>Prioritize this control in the walkthrough.</p>"
    assert evidence_text in content_html
    assert citation_link in content_html
    assert implication_text in content_html
    assert content_html.index(citation_link) < content_html.index(implication_text)
    assert content_html.count("<link ") == 1
    assert "document_uri=gs%3A%2F%2Fbucket%2Fpolicy.pdf&amp;pageNumber=8" in content_html
    assert next_citation_number == 2


def test_pdf_content_to_html_preserves_chunk_ids():
    html_block = pdf_download_service._content_to_html(
        content="Paragraph body",
        is_section_start=False,
        supporting_chunk_ids=["101", "102"],
        plan_number="12",
        plan_name="Alpha",
        pdf_citation_base_url="https://ui.example/view",
        citation_number_start=4,
    )
    assert 'color="#1155CC">101</link>' in html_block
    assert 'color="#1155CC">102</link>' in html_block
    assert ">4</link>" not in html_block


def test_policy_report_inlines_document_links_only_in_source_evidence_log(monkeypatch):
    original_content_to_html = pdf_download_service._content_to_html
    rendered = []

    def capture_citation_visibility(*args, **kwargs):
        result = original_content_to_html(*args, **kwargs)
        rendered.append(result)
        return result

    monkeypatch.setattr(pdf_download_service, "_content_to_html", capture_citation_visibility)
    report = {
        "Policy, KOD and Regulatory Analysis": {
            "report_title": "Policy, KOD and Regulatory Analysis",
            "paragraphs": [
                {"content": "Section 4: Regulatory and Policy Change Risk Watchlist",
                 "metadata": {"is_section_start": True}},
                {"content": "Watchlist statement.",
                 "supporting_citations": [{"chunk_id": "REG|1|1", "citation_label": "example.com"},
                                          {"chunk_id": "POLICY|1", "citation_label": "Link",
                                           "document_name": "GBSA Manual"}]},
                {"content": "Section 6: Source Evidence Log",
                 "metadata": {"is_section_start": True}},
                {"content": "- GBSA Manual\nVersion: 6",
                 "supporting_citations": [{"chunk_id": "POLICY|1", "citation_label": "Link",
                                           "document_name": "GBSA Manual"}]},
            ],
        },
    }

    pdf_download_service.build_report_pdf(report, plan_number="12", plan_name="Alpha")

    assert "example.com" in rendered[1]
    assert ">Link</link>" in rendered[1]
    assert ">GBSA Manual</link>" not in rendered[1]
    assert ">GBSA Manual</link>" in rendered[3]


def test_pdf_content_to_html_deduplicates_chunk_ids():
    duplicate_citations = [
        {"chunk_id": "1", "page_number": 2},
        {"chunk_id": "3", "page_number": 4},
        {"chunk_id": "3", "page_number": 5},
        {"chunk_id": "3", "page_number": 6},
    ]

    html_block = pdf_download_service._content_to_html(
        content="Paragraph body",
        is_section_start=False,
        supporting_chunk_ids=["1", "3", "3"],
        supporting_citations=duplicate_citations,
        plan_number="12",
        plan_name="Alpha",
        pdf_citation_base_url="https://ui.example/view",
    )
    markup = pdf_download_service._to_reportlab_markup(html_block)

    assert markup.count('>1</link>') == 1
    assert markup.count('>3</link>') == 1
    assert pdf_download_service._count_rendered_citations(
        supporting_chunk_ids=["1", "3", "3"],
        supporting_citations=duplicate_citations,
    ) == 2

    evidence_markup, next_citation_number = pdf_download_service._evidence_markup(
        {
            "content": "Past review evidence",
            "supporting_chunk_ids": ["1", "3", "3"],
            "supporting_citations": duplicate_citations,
        },
        "12",
        "Alpha",
        "https://ui.example/view",
        1,
    )
    assert evidence_markup.startswith("Past review evidence [")
    assert evidence_markup.count(">1</link>") == 1
    assert evidence_markup.count(">3</link>") == 1
    assert "pageNumber=4" in evidence_markup
    assert "pageNumber=5" not in evidence_markup
    assert next_citation_number == 3


def test_pdf_moves_section_heading_citations_to_content():
    paragraphs = [
        {
            "content": "Section 1: Policy and Regulatory Context Summary",
            "supporting_chunk_ids": ["4", "5"],
            "supporting_citations": [{"chunk_id": "4"}, {"chunk_id": "5"}],
            "metadata": {"is_section_start": True},
        },
        {
            "content": "Policy content paragraph.",
            "supporting_chunk_ids": ["6"],
            "supporting_citations": [{"chunk_id": "6"}],
            "metadata": {"is_section_start": False},
        },
    ]

    prepared = pdf_download_service._move_heading_citations_to_content(paragraphs)

    assert prepared[0]["supporting_chunk_ids"] == []
    assert prepared[0]["supporting_citations"] == []
    assert prepared[1]["supporting_chunk_ids"] == ["4", "5", "6"]
    assert [item["chunk_id"] for item in prepared[1]["supporting_citations"]] == ["4", "5", "6"]


def test_pdf_service_parser_utilities_and_normalization():
    csv_parts = pdf_download_service._split_top_level_csv(
        "a=1, b=[1,2,{\"x\":\"y,z\"}], c='v,3', d=True"
    )
    assert len(csv_parts) == 4
    assert "b=[1,2" in csv_parts[1]

    closed_idx = pdf_download_service._find_matching_paren("ParagraphCitation(a=(1,2))", 17)
    assert closed_idx > 17
    assert pdf_download_service._find_matching_paren("ParagraphCitation(a=(1,2)", 17) == -1

    assert pdf_download_service._to_python_value("None") is None
    assert pdf_download_service._to_python_value("True") is True
    assert pdf_download_service._to_python_value("[1,2]") == [1, 2]
    assert pdf_download_service._to_python_value("not_python_literal") == "not_python_literal"

    default_metadata = pdf_download_service._parse_metadata("n/a")
    assert default_metadata["is_section_start"] is False
    assert default_metadata["section_confidence_score"] is None

    parsed_metadata = pdf_download_service._parse_metadata(
        "ParagraphMetadata(is_section_start=True, section_confidence_score=76, ignored)"
    )
    assert parsed_metadata["is_section_start"] is True
    assert parsed_metadata["section_confidence_score"] == 76

    assert pdf_download_service._parse_paragraph_citation("invalid") == {}

    citation_text = (
        "ParagraphCitation("
        "paragraph_id='para_1', "
        "content='Body text', "
        "supporting_chunk_ids=['1','2'], "
        "supporting_citations=[{'chunk_id': '2', 'page_number': 9, 'gs_uri': 'gs://bucket/doc.pdf'}], "
        "rationale='why', "
        "metadata=ParagraphMetadata(is_section_start=True, section_confidence_score=88)"
        ")"
    )
    paragraph = pdf_download_service._parse_paragraph_citation(citation_text)
    assert paragraph["paragraph_id"] == "para_1"
    assert paragraph["supporting_chunk_ids"] == ["1", "2"]
    assert paragraph["supporting_citations"][0]["page_number"] == 9
    assert paragraph["metadata"]["is_section_start"] is True

    assert pdf_download_service._parse_compound_report(123)["paragraphs"] == []

    malformed = "report_title='Broken' paragraphs=[ParagraphCitation(paragraph_id='x'"
    assert pdf_download_service._parse_compound_report(malformed)["paragraphs"] == []

    raw_report = (
        "report_title='Past Review Analysis' paragraphs=["
        "ParagraphCitation(paragraph_id='para_1', content='A', supporting_chunk_ids=['1'], supporting_citations=[{'chunk_id': '1', 'page_number': 3}], "
        "rationale=None, metadata=ParagraphMetadata(is_section_start=True, section_confidence_score=90)),"
        "ParagraphCitation(paragraph_id='para_2', content='B', supporting_chunk_ids=['2'], supporting_citations=[], "
        "rationale=None, metadata=ParagraphMetadata(is_section_start=False, section_confidence_score=None))"
        "]"
    )
    parsed_report = pdf_download_service._parse_compound_report(raw_report)
    assert parsed_report["report_title"] == "Past Review Analysis"
    assert len(parsed_report["paragraphs"]) == 2

    normalized = pdf_download_service.normalize_analysis_report(
        {
            "Past Review Analysis": {
                "report_title": "Past Review Analysis",
                "paragraphs": [{"content": "x"}],
            },
            "Policy and Regulatory Analysis": raw_report,
            "Broad Scope Direction": 5,
        }
    )
    assert normalized["Past Review Analysis"]["report_title"] == "Past Review Analysis"
    assert len(normalized["Policy and Regulatory Analysis"]["paragraphs"]) == 2
    assert normalized["Broad Scope Direction"]["paragraphs"] == []


def test_normalize_analysis_report_accepts_scoping_report_models():
    # analysis_report values arrive as ScopingReport models once sourced from
    # a validated PreliminaryResearchDocument (Dict[str, ScopingReport]).
    document = response_model.PreliminaryResearchDocument(
        plan_number="123",
        analysis_report={"Past Review Analysis": _sample_report("Past Review Analysis")},
    )

    normalized = pdf_download_service.normalize_analysis_report(document.analysis_report)

    assert normalized["Past Review Analysis"]["report_title"] == "Past Review Analysis"
    assert len(normalized["Past Review Analysis"]["paragraphs"]) == 1
    assert isinstance(normalized["Past Review Analysis"]["paragraphs"][0], dict)


def test_normalize_analysis_report_accepts_past_review_models():
    document = response_model.PreliminaryResearchDocument(
        plan_number="123",
        analysis_report={"Past Review Analysis": _sample_past_review_report()},
    )

    normalized = pdf_download_service.normalize_analysis_report(document.analysis_report)

    report = normalized["Past Review Analysis"]
    assert report["similar_review_count"] == 1
    assert len(report["historical_reviews"][0]["assessments"]) == 6


def test_pdf_build_and_download_with_reportlab(monkeypatch):
    analysis_report = {
        "Policy, KOD and Regulatory Analysis": {
            "report_title": "Policy, KOD and Regulatory Analysis",
            "paragraphs": [
                {
                    "content": "Policy body",
                    "supporting_chunk_ids": ["9"],
                    "metadata": {"is_section_start": False},
                }
            ],
        },
        "Past Review Analysis": {
            "report_title": "Past Review Analysis",
            "current_review_id": "123",
            "similar_review_count": 1,
            "historical_reviews": [
                {
                    "historical_review_id": "1001",
                    "review_title": "Prior Review",
                    "assessments": [
                        {
                            "assessed_area": assessed_area,
                            "key_observation": {
                                "content": [
                                    {
                                        "content": (
                                            "One similar review was identified."
                                            if index == 0
                                            else f"Observation {index + 1}."
                                        ),
                                        "citation_status": "supported",
                                        "supporting_chunk_ids": ["2"],
                                        "supporting_citations": [
                                            {"chunk_id": "2", "page_number": 6, "gs_uri": "gs://bucket/doc.pdf"}
                                        ],
                                    },
                                    {
                                        "content": "This is a separate planning conclusion.",
                                        "citation_status": "unsupported",
                                        "supporting_chunk_ids": [],
                                        "supporting_citations": [],
                                    },
                                ],
                            },
                            "implication_for_current_review": {
                                "content": [{
                                    "content": "Use it as scope precedent.",
                                    "citation_status": "supported",
                                    "supporting_chunk_ids": ["2"],
                                    "supporting_citations": [
                                        {"chunk_id": "2", "page_number": 6, "gs_uri": "gs://bucket/doc.pdf"}
                                    ],
                                }],
                            },
                        }
                        for index, assessed_area in enumerate(ASSESSED_AREAS)
                    ],
                }
            ],
        },
        "Broad Scope Direction": {
            "report_title": "Broad Scope Direction",
            "paragraphs": [
                {
                    "content": "Broad scope body",
                    "supporting_chunk_ids": [],
                    "metadata": {"is_section_start": False},
                }
            ],
        },
    }

    pdf_bytes = pdf_download_service.build_report_pdf(
        analysis_report=analysis_report,
        plan_number="123",
        plan_name="Plan A",
        pdf_citation_base_url="https://ui.example/view",
    )
    assert pdf_bytes.startswith(b"%PDF-")
    assert len(pdf_bytes) > 1000

    flowables, next_citation_number = pdf_download_service._past_review_flowables(
        analysis_report["Past Review Analysis"],
        analysis_report["Past Review Analysis"]["historical_reviews"],
        "123",
        "Plan A",
        "https://ui.example/view",
        1,
    )
    paragraph_text = " ".join(
        flowable.getPlainText() for flowable in flowables if hasattr(flowable, "getPlainText")
    )
    assert "Summary" in paragraph_text
    assert "Number of similar reviews: 1" in paragraph_text
    assert "Key Observations" in paragraph_text
    assert "Implications" in paragraph_text
    assert "Review ID 1001 (Prior Review): One similar review was identified. [2] This is a separate planning conclusion." in paragraph_text
    assert "Review ID 1001 (Prior Review): Use it as scope precedent. [2]" in paragraph_text

    table = flowables[-1]
    assert len(table._cellvalues) == 6
    assert len(table._cellvalues[0]) == 4
    headers = [cell.getPlainText() for cell in table._cellvalues[0]]
    assert headers == [
        "Historical Review IDs",
        "Assessed Area",
        "Key Observations",
        "Relevance to Current Review",
    ]
    assert table._cellvalues[1][1].getPlainText() == ASSESSED_AREAS[1]
    assert ASSESSED_AREAS[0] not in [row[1].getPlainText() for row in table._cellvalues[1:]]
    assert table._cellvalues[1][2].getPlainText().endswith("This is a separate planning conclusion.")
    assert table._cellvalues[1][2].getPlainText().count("[2]") == 1
    assert table._cellvalues[1][3].getPlainText().endswith("[2]")
    assert next_citation_number == 13

    monkeypatch.setattr(pdf_download_service, "build_report_pdf", lambda **kwargs: b"download-bytes")
    payload_bytes, headers = pdf_download_service.download_research_walkthrough_pdf(
        plan_number="123",
        analysis_report={"Section": {}},
    )
    assert payload_bytes == b"download-bytes"
    assert headers["Content-Type"] == "application/pdf"
    assert headers["Content-Disposition"].endswith('"Preliminary_Research_Report_123.pdf"')


def test_pdf_build_missing_dependency(monkeypatch):
    def _raise_missing(name):
        raise ModuleNotFoundError("No module named reportlab")

    monkeypatch.setattr(pdf_download_service.importlib, "import_module", _raise_missing)

    try:
        pdf_download_service.build_report_pdf({}, plan_number="123", plan_name=None)
    except RuntimeError as exc:
        assert "Install 'reportlab'" in str(exc)
    else:
        raise AssertionError("Expected RuntimeError")
