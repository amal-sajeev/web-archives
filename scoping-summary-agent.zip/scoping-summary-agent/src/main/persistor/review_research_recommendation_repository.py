"""SQLAlchemy ORM model and persistence helpers for review_research_recommendation."""
import logging
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base

from persistor.database_connector import get_session

logger = logging.getLogger(__name__)

SCHEMA_NAME = "dbaware_scoping"

Base = declarative_base()


def _to_jsonable(value: Any) -> Any:
    """Convert Pydantic models / arbitrary objects into JSON-serializable data.

    JSONB columns require plain Python primitives (dict/list/str/number/bool/None).
    Pydantic models (e.g. ``PreliminaryResearchDocument``) must be converted first,
    otherwise psycopg raises ``Object of type X is not JSON serializable``.
    """
    if value is None:
        return None
    # Pydantic v2
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    # Pydantic v1
    if hasattr(value, "dict"):
        return value.dict()
    if isinstance(value, dict):
        return {k: _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]
    return value


class ReviewResearchRecommendationORM(Base):
    __tablename__ = "review_research_recommendation"
    __table_args__ = {"schema": SCHEMA_NAME}

    # review_rr_id auto-increments in the database (IDENTITY/sequence default),
    # so inserts don't need to supply a PK.
    review_rr_id = Column(Integer, primary_key=True)
    review_scope_instance_id = Column(Integer, nullable=True)
    metadata_ = Column("metadata", JSONB, nullable=True)
    report_type = Column(String(30), nullable=True)
    created_by = Column(String(100), nullable=True)
    created_on = Column(DateTime, nullable=True)
    updated_by = Column(String(100), nullable=True)
    updated_on = Column(DateTime, nullable=True)
    remarks = Column(String(500), nullable=True)


def persist_review_research_recommendation(
    *,
    review_scope_instance_id: Optional[int] = None,
    metadata: Optional[Dict[str, Any]] = None,
    report_type: Optional[str] = None,
    created_by: Optional[str] = None,
    remarks: Optional[str] = None,
) -> int:
    """Insert a review_research_recommendation row and return the generated review_rr_id."""
    session = get_session()
    try:
        row = ReviewResearchRecommendationORM(
            review_scope_instance_id=review_scope_instance_id,
            metadata_=_to_jsonable(metadata),
            report_type=report_type,
            created_by=created_by,
            created_on=datetime.utcnow(),
            remarks=remarks,
        )
        session.add(row)
        session.commit()
        session.refresh(row)
        logger.info(
            "Persisted review_research_recommendation review_rr_id=%s review_scope_instance_id=%s",
            row.review_rr_id,
            review_scope_instance_id,
        )
        return row.review_rr_id
    except Exception:
        session.rollback()
        logger.exception("Failed to persist review_research_recommendation")
        raise
    finally:
        session.close()


def update_review_research_recommendation(
    *,
    review_scope_instance_id: int,
    report_type: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    updated_by: Optional[str] = None,
) -> Optional[int]:
    """Update the latest review_research_recommendation row for a scope instance.

    Multiple rows can share the same ``review_scope_instance_id`` with different
    ``report_type`` values, so matching is done on both ``review_scope_instance_id``
    and ``report_type`` (when provided).

    Sets ``metadata``, ``updated_by`` and ``updated_on``. Returns the updated
    ``review_rr_id`` or ``None`` when no matching row exists.
    """
    session = get_session()
    try:
        query = session.query(ReviewResearchRecommendationORM).filter(
            ReviewResearchRecommendationORM.review_scope_instance_id
            == review_scope_instance_id
        )
        if report_type is not None:
            query = query.filter(
                ReviewResearchRecommendationORM.report_type == report_type
            )
        row = (
            query.order_by(ReviewResearchRecommendationORM.review_rr_id.desc())
            .first()
        )
        if row is None:
            logger.warning(
                "No review_research_recommendation row to update "
                "review_scope_instance_id=%s report_type=%s",
                review_scope_instance_id,
                report_type,
            )
            return None

        if metadata is not None:
            row.metadata_ = _to_jsonable(metadata)
        row.updated_by = updated_by
        row.updated_on = datetime.utcnow()

        session.commit()
        session.refresh(row)
        logger.info(
            "Updated review_research_recommendation review_rr_id=%s "
            "review_scope_instance_id=%s report_type=%s",
            row.review_rr_id,
            review_scope_instance_id,
            report_type,
        )
        return row.review_rr_id
    except Exception:
        session.rollback()
        logger.exception("Failed to update review_research_recommendation")
        raise
    finally:
        session.close()
