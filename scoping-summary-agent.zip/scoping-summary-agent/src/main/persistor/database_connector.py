import logging

import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from config.config import Config

logger = logging.getLogger(__name__)


def get_session():
    if not Config.db_pass:
        logger.error("Database password is not configured (scoping_db_pass is empty).")
        raise ValueError("Database password is not configured.")

    try:
        engine = create_engine(
            sqlalchemy.engine.url.URL.create(
                drivername="postgresql+pg8000",
                username=Config.db_user,
                password=Config.db_pass,
                host=Config.db_host,
                port=Config.db_port,
                database=Config.db_name,
            ),
        )
        session_local = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        logger.info(
            "Database session created host=%s port=%s database=%s",
            Config.db_host,
            Config.db_port,
            Config.db_name,
        )
        return session_local()
    except Exception:
        logger.exception("Failed to create database session.")
        raise