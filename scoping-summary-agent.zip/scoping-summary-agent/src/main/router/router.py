import logging
from fastapi import APIRouter, HTTPException, Response

from agent_helper.action_service import (
    audit_generation_start,
    audit_revision,
    audit_ai_response,
)
from service.analytics_service import run_analytics_task
from config.config import Config
from utils.data_manager import (
    get_preliminary_research_blob_path,
    process_citations,
    process_document_uri,
    has_plan_data,
)
from utils.storage_manager import blob_exists, read_blob_json, write_blob_json
from model.request_model import (
    AnalyticsRequest,
    DownloadResearchWalkthroughRequest,
    EditPreliminaryResearchRequest,
    GetDocumentRequest,
    GetPreliminaryResearchRequest,
)
from model.response_model import PreliminaryResearchDocument
from service.pdf_download_service import download_research_walkthrough_pdf

from persistor.review_research_recommendation_repository import (
    persist_review_research_recommendation,
    update_review_research_recommendation,
)
logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/run-analytics-agent")
async def run_analytics_agent_endpoint(
    request: AnalyticsRequest,
) -> PreliminaryResearchDocument:
    planNumber = request.planNumber
    logger.info("Received analytics request plan_number=%s", planNumber)

    agent_card, start_time = audit_generation_start(
        activity_type="PRELIMINARY_RESEARCH_GENERATION",
        entity_type="PRELIMINARY_RESEARCH",
        plan_number=planNumber,
        description="preliminary research baseline report",
        request_obj=request,
    )

    try:
        if not has_plan_data(planNumber):
            logger.warning("Plan not found plan_number=%s", planNumber)
            raise FileNotFoundError(f"No data found for plan '{planNumber}'.")
        response = await run_analytics_task(planNumber)
        logger.info("Analytics completed plan_number=%s", planNumber)

        try:
            review_rr_id = persist_review_research_recommendation(
                review_scope_instance_id=request.userDetails.review_scope_instance_id,
                metadata=response,
                report_type="PRELIMINARY_RESEARCH",
                created_by=request.userDetails.user,
                remarks=request.userDetails.remarks,
            )
            logger.info(
                "Persisted research recommendation plan_number=%s review_rr_id=%s",
                planNumber,
                review_rr_id,
            )
        except Exception as e:
            # Persistence is best-effort; do not fail the analytics response.
            logger.exception(
                "Failed to persist research recommendation plan_number=%s", planNumber
            )

        audit_ai_response(
            agent_card=agent_card,
            start_time=start_time,
            result_payload=response,
            default_reasoning="Successfully compiled GRC, Policy, and Historical context into a Preliminary Research baseline.",
        )
        return response
    except FileNotFoundError as exc:
        logger.warning("Plan not found plan_number=%s error=%s", planNumber, exc)
        raise HTTPException(status_code=404, detail=str(exc))
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error processing plan plan_number=%s", planNumber)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get_document")
async def get_document(request: GetDocumentRequest):
    try:
        document_uri = (request.document_uri or "").strip()
        chunk_id = (request.chunk_id or "").strip()
        page_number = request.page_number or 1

        if document_uri:
            logger.info("Received get_document request via direct uri=%s", document_uri)
            document_data = process_document_uri(document_uri, page_number=page_number)
            if document_data.get("type") == "unsupported":
                raise HTTPException(status_code=415, detail="Unsupported document type for provided document_uri.")
            return document_data

        if not chunk_id:
            raise ValueError("Either chunk_id or document_uri is required.")
        if not request.planNumber:
            raise ValueError("planNumber is required when chunk_id is provided.")

        logger.info("Received get_document request plan_number=%s chunk_id=%s", request.planNumber, chunk_id)
        citation_data = process_citations(request.planNumber, chunk_id)

        if citation_data.get("type") == "error":
            raise HTTPException(status_code=404, detail=citation_data.get("message", "Cited document not found."))

        return citation_data
    except FileNotFoundError as exc:
        logger.warning("File not found for get_document request. plan_number=%s. Error: %s", request.planNumber, exc)
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        logger.warning("Invalid data for get_document request. plan_number=%s. Error: %s", request.planNumber, exc)
        raise HTTPException(status_code=400, detail=str(exc))
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_document. plan_number=%s", request.planNumber)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/get-preliminary-research-document")
def get_preliminary_research_document(request: GetPreliminaryResearchRequest) -> PreliminaryResearchDocument:
    plan_number = request.planNumber
    path = get_preliminary_research_blob_path(plan_number)
    try:
        logger.info("Fetching preliminary research document plan_number=%s path=%s", plan_number, path)
        if not blob_exists(path):
            logger.warning("Preliminary research document not found plan_number=%s path=%s", plan_number, path)
            raise HTTPException(status_code=404, detail="Document not found.")
        payload = read_blob_json(path)
        if isinstance(payload, dict) and "plan_number" in payload and "analysis_report" in payload:
            if not isinstance(payload["analysis_report"], dict):
                logger.error(
                    "Stored preliminary research has an invalid analysis_report type "
                    "plan_number=%s type=%s",
                    plan_number,
                    type(payload["analysis_report"]).__name__,
                )
                raise HTTPException(
                    status_code=500,
                    detail="Stored preliminary research analysis_report must be a dictionary.",
                )
            return PreliminaryResearchDocument(**payload)

        # Backward compatibility for older payloads that only stored report content.
        if not isinstance(payload, dict):
            logger.error(
                "Stored preliminary research has an invalid payload type plan_number=%s type=%s",
                plan_number,
                type(payload).__name__,
            )
            raise HTTPException(
                status_code=500,
                detail="Stored preliminary research must be a dictionary.",
            )
        return PreliminaryResearchDocument(plan_number=plan_number, analysis_report=payload)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error fetching preliminary research plan_number=%s", plan_number)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/edit-preliminary-research-document")
def edit_preliminary_research_document(request: EditPreliminaryResearchRequest) -> PreliminaryResearchDocument:
    plan_number = request.plan_number
    path = get_preliminary_research_blob_path(plan_number)
    try:
        if not isinstance(request.analysis_report, dict):
            raise ValueError("analysis_report must be a dictionary.")
        audit_revision(
            activity_type="PRELIMINARY_RESEARCH",
            entity_type="PRELIMINARY_RESEARCH",
            plan_number=plan_number,
            request_obj=request,
            description="preliminary research document",
        )
        document = PreliminaryResearchDocument(plan_number=plan_number, analysis_report=request.analysis_report)
        write_blob_json(path, document.model_dump())
        logger.info("Updated preliminary research document plan_number=%s path=%s", plan_number, path)

        try:
            updated_id = update_review_research_recommendation(
                review_scope_instance_id=request.userDetails.review_scope_instance_id,
                metadata=document,
                updated_by=request.userDetails.user,
            )
            logger.info(
                "Updated research recommendation plan_number=%s review_rr_id=%s",
                plan_number,
                updated_id,
            )
        except Exception:
            # Persistence is best-effort; do not fail the edit response.
            logger.exception(
                "Failed to update research recommendation plan_number=%s", plan_number
            )

        return document
    except Exception as exc:
        logger.exception("Unexpected error updating preliminary research plan_number=%s", plan_number)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/download")
def download_research_walkthrough(request: DownloadResearchWalkthroughRequest) -> Response:
    try:
        pdf_bytes, headers = download_research_walkthrough_pdf(
            plan_number=request.plan_number,
            plan_name=request.plan_name,
            analysis_report=request.analysis_report,
            pdf_citation_base_url=Config.DOWNLOAD_PDF_CITATION_BASE_URL or None,
        )
        return Response(content=pdf_bytes, media_type="application/pdf", headers=headers)
    except ValueError as exc:
        logger.warning("Invalid request for download endpoint plan_number=%s error=%s", request.plan_number, exc)
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error generating walkthrough PDF plan_number=%s", request.plan_number)
        raise HTTPException(status_code=500, detail=str(exc))