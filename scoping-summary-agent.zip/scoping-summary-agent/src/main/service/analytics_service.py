
import logging
from typing import Any, Callable, Dict, Optional

from agents.analytics_agent import run_analytics_agent
from config.config import Config
from model.response_model import PreliminaryResearchDocument
from utils.data_manager import get_plan_output_blob_path, get_preliminary_research_blob_path, read_plan_data_async
from utils.policy_section_builder import (
    _section_citation_label,
    build_policy_manifest,
    build_regulation_manifest,
    regulation_citation_mapping,
)
from utils.storage_manager import write_blob_json


logger = logging.getLogger(__name__)


ProgressCallback = Optional[Callable[[Dict[str, Any]], None]]


def _add_policy_section_citations(
    plan_data: Dict[str, Any],
    chunk_id_path_mapping: Dict[str, Any],
) -> None:
    manifest = build_policy_manifest(plan_data.get("output2") or [])
    for source in manifest.values():
        for document in source["documents"]:
            document_uri = document.get("storage_uri")
            if not document_uri:
                logger.warning("Policy document has no storage URI doc_key=%s", document["doc_key"])
                continue
            chunk_id_path_mapping[document["doc_key"]] = [{
                "content_type": "application/pdf",
                "document_name": document["title"],
                "access_info": {"uri": document_uri},
                "location_metadata": {},
                "citation_label": "Link",
            }]
            for section in document["sections"]:
                page_number = section.get("page_start")
                if page_number is None:
                    continue
                chunk_id = section["key"]
                chunk_id_path_mapping[chunk_id] = [{
                    "content_type": "application/pdf",
                    "document_name": document["title"],
                    "access_info": {"uri": document_uri},
                    "location_metadata": {"page_number": page_number},
                    "citation_label": _section_citation_label(section),
                }]
    chunk_id_path_mapping.update(
        regulation_citation_mapping(build_regulation_manifest(plan_data.get("output2") or []))
    )


def _emit_progress(
    progress_callback: ProgressCallback,
    status: str,
    message: str,
    progress: int,
    phase: Optional[str] = None,
) -> None:
    if progress_callback:
        progress_callback({"status": status, "message": message, "progress": progress, "phase": phase})


def _build_exact_supporting_citations(
    paragraph: Dict[str, Any],
    chunk_id_path_mapping: Dict[str, Any],
) -> list[Dict[str, Any]]:
    if not isinstance(paragraph, dict):
        return []

    supporting_chunk_ids = paragraph.get("supporting_chunk_ids") or []
    raw_supporting_citations = paragraph.get("supporting_citations") or []

    exact_citations: list[Dict[str, Any]] = []
    seen_keys: set[tuple[Any, ...]] = set()

    citation_candidates: list[Dict[str, Any]] = []
    if isinstance(raw_supporting_citations, list) and raw_supporting_citations:
        for item in raw_supporting_citations:
            if isinstance(item, dict) and item.get("chunk_id") not in (None, ""):
                citation_candidates.append(item)
    else:
        for chunk_id in supporting_chunk_ids:
            citation_candidates.append({"chunk_id": str(chunk_id), "page_number": None})

    for candidate in citation_candidates:
        chunk_id = str(candidate.get("chunk_id"))
        mapping_entries = chunk_id_path_mapping.get(chunk_id) or chunk_id_path_mapping.get(candidate.get("chunk_id")) or []
        first_mapping = mapping_entries[0] if mapping_entries else {}
        access_info = first_mapping.get("access_info") or {}
        location_metadata = first_mapping.get("location_metadata") or {}

        page_number = candidate.get("page_number")
        if first_mapping.get("citation_label") and location_metadata.get("page_number") is not None:
            page_number = location_metadata["page_number"]
        elif page_number in (None, ""):
            page_number = location_metadata.get("page_number")

        entry = {
            "chunk_id": chunk_id,
            "page_number": page_number,
            # Web citations (e.g. regulatory deep links) carry their link in `url`; gs_uri stays storage-only.
            "gs_uri": None if first_mapping.get("url") else access_info.get("uri"),
            "document_name": first_mapping.get("document_name"),
            "content_type": first_mapping.get("content_type"),
        }
        if first_mapping.get("citation_label"):
            entry["citation_label"] = first_mapping["citation_label"]
        if first_mapping.get("url"):
            entry["url"] = first_mapping["url"]
        dedupe_key = (
            entry["chunk_id"],
            entry["page_number"],
            entry["gs_uri"],
            entry["document_name"],
            entry["content_type"],
        )
        if dedupe_key in seen_keys:
            continue
        seen_keys.add(dedupe_key)
        exact_citations.append(entry)

    return exact_citations


def _enrich_evidence_block(block: Any, chunk_id_path_mapping: Dict[str, Any]) -> Dict[str, Any]:
    if hasattr(block, "model_dump"):
        block = block.model_dump()
    if not isinstance(block, dict):
        return {
            "content": str(block or ""),
            "supporting_chunk_ids": [],
            "supporting_citations": [],
        }

    block = dict(block)
    content_units = block.get("content")
    if isinstance(content_units, list):
        enriched_units: list[Any] = []
        for unit in content_units:
            if hasattr(unit, "model_dump"):
                unit = unit.model_dump()
            if not isinstance(unit, dict):
                enriched_units.append(unit)
                continue
            enriched_unit = dict(unit)
            enriched_unit["supporting_chunk_ids"] = enriched_unit.get("supporting_chunk_ids") or []
            enriched_unit["supporting_citations"] = _build_exact_supporting_citations(
                enriched_unit,
                chunk_id_path_mapping,
            )
            enriched_units.append(enriched_unit)
        block["content"] = enriched_units
        return block

    block["supporting_chunk_ids"] = block.get("supporting_chunk_ids") or []
    block["supporting_citations"] = _build_exact_supporting_citations(block, chunk_id_path_mapping)
    if not block.get("content") and isinstance(block.get("text"), str):
        block["content"] = block["text"]
    return block


def _enrich_analysis_report_with_citations(
    analysis_report: Dict[str, Any],
    chunk_id_path_mapping: Dict[str, Any],
) -> Dict[str, Any]:
    if not isinstance(analysis_report, dict):
        return analysis_report

    enriched_report: Dict[str, Any] = {}
    for section_name, section_payload in analysis_report.items():
        if hasattr(section_payload, "model_dump"):
            section_payload = section_payload.model_dump()
        if not isinstance(section_payload, dict):
            enriched_report[section_name] = section_payload
            continue

        enriched_section = dict(section_payload)
        historical_reviews = section_payload.get("historical_reviews")
        if isinstance(historical_reviews, list):
            enriched_reviews: list[Dict[str, Any]] = []
            for historical_review in historical_reviews:
                if not isinstance(historical_review, dict):
                    continue
                enriched_review = dict(historical_review)
                enriched_assessments: list[Dict[str, Any]] = []
                for assessment in historical_review.get("assessments") or []:
                    if not isinstance(assessment, dict):
                        continue
                    enriched_assessment = dict(assessment)
                    enriched_assessment.pop("supporting_chunk_ids", None)
                    for field_name in ("key_observation", "implication_for_current_review"):
                        if field_name in enriched_assessment:
                            enriched_assessment[field_name] = _enrich_evidence_block(
                                enriched_assessment[field_name],
                                chunk_id_path_mapping,
                            )
                    enriched_assessments.append(enriched_assessment)
                enriched_review["assessments"] = enriched_assessments
                enriched_reviews.append(enriched_review)
            enriched_section["historical_reviews"] = enriched_reviews
            enriched_report[section_name] = enriched_section
            continue

        paragraphs = section_payload.get("paragraphs") or []
        enriched_paragraphs: list[Dict[str, Any]] = []
        for paragraph in paragraphs:
            if hasattr(paragraph, "model_dump"):
                paragraph = paragraph.model_dump()
            if not isinstance(paragraph, dict):
                enriched_paragraphs.append(paragraph)
                continue

            enriched_paragraph = dict(paragraph)
            content_units = enriched_paragraph.get("content")
            if isinstance(content_units, list):
                enriched_block = _enrich_evidence_block(
                    {"content": content_units},
                    chunk_id_path_mapping,
                )
                enriched_paragraph["content"] = enriched_block["content"]
            else:
                enriched_paragraph["supporting_citations"] = _build_exact_supporting_citations(
                    enriched_paragraph,
                    chunk_id_path_mapping,
                )
            enriched_paragraphs.append(enriched_paragraph)

        enriched_section["paragraphs"] = enriched_paragraphs
        enriched_report[section_name] = enriched_section

    return enriched_report


async def run_analytics_task(plan_number: str, progress_callback: ProgressCallback = None) -> Dict[str, Any]:
    logger.info("Analytics task started plan_number=%s", plan_number)
    _emit_progress(progress_callback, "running", "Gathering source material.", 10, phase="gathering_data")
    plan_data, chunk_id_path_mapping = await read_plan_data_async(plan_number)
    _add_policy_section_citations(plan_data, chunk_id_path_mapping)
    logger.info("Plan data loaded plan_number=%s", plan_number)

    _emit_progress(progress_callback, "running", "Source material is ready.", 20, phase="gathering_data")
    analysis = await run_analytics_agent(plan_number, plan_data, progress_callback=progress_callback)
    analysis = _enrich_analysis_report_with_citations(analysis, chunk_id_path_mapping)
    logger.info("Analytics agent completed plan_number=%s", plan_number)
    if not isinstance(analysis, dict):
        logger.error(
            "Analytics agent returned an invalid report type plan_number=%s type=%s",
            plan_number,
            type(analysis).__name__,
        )
        raise TypeError("Analytics agent must return a dictionary report.")

    report_model = PreliminaryResearchDocument(
        plan_number=plan_number,
        analysis_report=analysis,
    )
    report: Dict[str, Any] = report_model.model_dump()
    _emit_progress(progress_callback, "running", "Consolidating the report and saving the draft.", 90, phase="consolidating_sections")
    report_path = write_blob_json(
        get_preliminary_research_blob_path(plan_number),
        report,
    )
    logger.info(
        "Report persisted plan_number=%s path=%s",
        plan_number,
        report_path,
    )
    citation_path_mapping = write_blob_json(get_plan_output_blob_path(plan_number, "citation_mapping.json"), chunk_id_path_mapping)
    logger.info(
        "citation mapping persisted plan_number=%s path=%s",
        plan_number,
        citation_path_mapping,
    )
    _emit_progress(progress_callback, "complete", "Final touch complete. Your report is ready.", 100, phase="final_touch")
    return report
