from __future__ import annotations

import ast
import html
import importlib
import io
import re
from typing import Any
from urllib.parse import quote, urlencode


CONSOLIDATED_SECTIONS = [
    "Past Review Analysis",
    "Policy, KOD and Regulatory Analysis",
    "Broad Scope Direction",
]

DEFAULT_PDF_CITATION_BASE_URL = "https://ct1-cta.dbaware.dev.gcp.db.com/dbaware-ui"

# Heading font sizes (pt): 1 = section title, 2 = sub-section label, 3 = document/mandate item. Body text is 10pt.
REPORT_TITLE_FONT_SIZE = 15
HEADING_FONT_SIZES = {1: 13, 2: 12, 3: 11}
_BOLD_ONLY_LINE_RE = re.compile(r"^((?:&nbsp;)*)<b>((?:(?!</?b>).)+)</b>(:?)$")


def _sanitize(text: str) -> str:
    """Normalize punctuation for consistent built-in PDF font rendering."""
    if not text:
        return ""

    replacements = {
        "\u2013": "-",
        "\u2014": "-",
        "\u2212": "-",
        "\u2018": "'",
        "\u2019": "'",
        "\u201a": "'",
        "\u201b": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u201e": '"',
        "\u2026": "...",
        "\u2022": "-",
        "\u00b7": "-",
        "\u25cf": "-",
        "\u00a0": " ",
        "\u2009": " ",
        "\u202f": " ",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)

    return text.encode("latin-1", "replace").decode("latin-1")


def _build_chunk_viewer_url(
    plan_number: str | int | None,
    plan_name: str | None,
    chunk_id: str,
    document_uri: str | None = None,
    page_number: int | None = None,
    base_url: str | None = None,
) -> str:
    trimmed = (base_url or DEFAULT_PDF_CITATION_BASE_URL).strip().rstrip("/")
    path_plan_number = quote(str(plan_number or ""), safe="")
    path_chunk_id = quote(str(chunk_id), safe="")
    params_dict = {}
    if plan_name:
        params_dict["planName"] = str(plan_name)
    if document_uri:
        params_dict["document_uri"] = document_uri
    if page_number is not None:
        params_dict["pageNumber"] = str(page_number)

    plan_path = f"/{path_plan_number}" if path_plan_number else ""
    url = f"{trimmed}{plan_path}/docs/{path_chunk_id}"
    if params_dict:
        return f"{url}?{urlencode(params_dict)}"
    return url


def _citation_href(
    citation: dict[str, Any],
    plan_number: str | int | None,
    plan_name: str | None,
    base_url: str | None,
) -> str:
    """External web citations (e.g. regulatory deep links) link out directly; others use the doc viewer."""
    url = str(citation.get("url") or "")
    if url.lower().startswith(("https://", "http://")):
        return url
    return _build_chunk_viewer_url(
        plan_number,
        plan_name,
        str(citation.get("chunk_id")),
        document_uri=citation.get("gs_uri"),
        page_number=citation.get("page_number"),
        base_url=base_url,
    )


def _preserve_line_indentation(line: str) -> str:
    """Keep a line's leading indentation when rendered by ReportLab.

    ReportLab's ``Paragraph`` collapses and strips leading whitespace, so plain
    leading spaces used to indent nested bullets are lost and the list renders
    flat. Converting the leading spaces to non-breaking spaces preserves the
    visual nesting. Trailing whitespace is trimmed and runs of indentation are
    kept verbatim (one non-breaking space per leading space).
    """
    without_trailing = line.rstrip()
    stripped = without_trailing.lstrip(" ")
    indent = len(without_trailing) - len(stripped)
    if indent:
        return "&nbsp;" * indent + stripped
    return stripped


def _heading_line(line: str, level: int) -> str:
    """Render one line at the given heading level. Levels 1-2 are fully bold; level 3 keeps its inline bold."""
    if level in (1, 2):
        line = f"<b>{line.replace('<b>', '').replace('</b>', '')}</b>"
    return f'<font size="{HEADING_FONT_SIZES[level]}">{line}</font>'


def _promote_bold_only_lines(block: str) -> str:
    """A line that is entirely bold (e.g. a model-written sub-heading) renders as a level-2 heading."""
    lines = block.split("<br>")
    for index, line in enumerate(lines):
        match = _BOLD_ONLY_LINE_RE.match(line)
        if match:
            indent, text, colon = match.groups()
            lines[index] = f"{indent}{_heading_line(f'<b>{text}{colon}</b>', 2)}"
    return "<br>".join(lines)


def _content_to_html(
    content: str,
    is_section_start: bool,
    supporting_chunk_ids: list[str] | None = None,
    supporting_citations: list[dict[str, Any]] | None = None,
    plan_number: str | int | None = None,
    plan_name: str | None = None,
    pdf_citation_base_url: str | None = None,
    citation_number_start: int = 1,
    heading_level: int | None = None,
    inline_document_links: bool = False,
) -> str:
    content = _sanitize(content)
    safe = html.escape(content)
    safe = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", safe)
    # Preserve <u>...</u> underline markup (used for policy/procedure/KOD/mandate
    # names) that html.escape would otherwise have turned into literal text.
    safe = safe.replace("&lt;u&gt;", "<u>").replace("&lt;/u&gt;", "</u>")

    blocks = []
    for raw_block in safe.split("\n\n"):
        # Preserve per-line leading indentation so nested bullets keep their
        # hierarchy. ReportLab's Paragraph (like HTML) collapses and strips
        # leading spaces, which would otherwise flatten indented sub-bullets onto
        # the same margin as their parent. Convert each line's leading spaces to
        # non-breaking spaces, trim trailing whitespace, and drop blank edge lines.
        rendered_lines = [_preserve_line_indentation(line) for line in raw_block.split("\n")]
        while rendered_lines and not rendered_lines[0]:
            rendered_lines.pop(0)
        while rendered_lines and not rendered_lines[-1]:
            rendered_lines.pop()
        if not rendered_lines:
            continue
        block = "<br>".join(rendered_lines)
        blocks.append(block)

    if not blocks:
        return ""

    level = 1 if is_section_start else heading_level
    if level not in HEADING_FONT_SIZES:
        level = None
    parts: list[str] = []
    for idx, block in enumerate(blocks):
        if level and idx == 0:
            # Only the heading line (up to the first line break) is treated as the
            # heading. Any remaining lines in this block are body content and must
            # stay at body size, otherwise an entire section packed into a single
            # section-start paragraph would render as a heading.
            heading, separator, remainder = block.partition("<br>")
            remainder = _promote_bold_only_lines(remainder) if remainder else remainder
            parts.append(f"<p>{_heading_line(heading, level)}{separator}{remainder}</p>")
        else:
            parts.append(f"<p>{_promote_bold_only_lines(block)}</p>")

    citations_to_render = _unique_citations(supporting_citations)

    if citations_to_render or supporting_chunk_ids:
        links = []
        iterable = citations_to_render or _unique_citations(
            [{"chunk_id": chunk_id} for chunk_id in (supporting_chunk_ids or [])]
        )
        for citation in iterable:
            chunk_id = str(citation.get("chunk_id"))
            citation_label = citation.get("citation_label")
            if citation_label == "Link" and inline_document_links:
                source_name = html.escape(_sanitize(str(citation.get("document_name") or "")))
                if source_name:
                    href = html.escape(
                        _citation_href(citation, plan_number, plan_name, pdf_citation_base_url),
                        quote=True,
                    )
                    source_link = f'<link href="{href}" color="#1155CC">{source_name}</link>'
                    for index, part in enumerate(parts):
                        if source_name in part:
                            parts[index] = part.replace(source_name, source_link, 1)
                            break
                    else:
                        links.append(source_link)
                continue
            display_label = citation_label
            safe_chunk_id = html.escape(_sanitize(display_label or chunk_id))
            href = html.escape(
                _citation_href(citation, plan_number, plan_name, pdf_citation_base_url),
                quote=True,
            )
            links.append(f'<link href="{href}" color="#1155CC">{safe_chunk_id}</link>')

        if links and parts:
            # Keep the citation inside the closing </p>; otherwise "</p> [link]<p>"
            # no longer matches "</p><p>" and the next unit is glued to the citation.
            parts[-1] = f"{parts[-1][:-len('</p>')]} [{', '.join(links)}]</p>"
        elif links:
            parts.append(f"<p>[{', '.join(links)}]</p>")

    return "".join(parts)


def _unique_citations(citations: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    """Keep the first citation for each chunk ID while preserving source order."""
    unique: list[dict[str, Any]] = []
    seen_chunk_ids: set[str] = set()
    for citation in citations or []:
        if not isinstance(citation, dict) or citation.get("chunk_id") in (None, ""):
            continue
        chunk_id = str(citation["chunk_id"])
        if chunk_id in seen_chunk_ids:
            continue
        seen_chunk_ids.add(chunk_id)
        unique.append(citation)
    return unique


def _count_rendered_citations(
    supporting_chunk_ids: list[str] | None = None,
    supporting_citations: list[dict[str, Any]] | None = None,
) -> int:
    citations_to_render = _unique_citations(supporting_citations)
    if citations_to_render:
        return len(citations_to_render)
    return len(_unique_citations([{"chunk_id": chunk_id} for chunk_id in (supporting_chunk_ids or [])]))


def _narrative_units_to_html(
    units: list[Any],
    is_section_start: bool,
    plan_number: str | int | None,
    plan_name: str | None,
    pdf_citation_base_url: str | None,
    citation_number_start: int,
    heading_level: int | None = None,
    inline_document_links: bool = False,
) -> tuple[str, int]:
    rendered_units: list[str] = []
    next_citation_number = citation_number_start

    for index, unit in enumerate(units):
        if hasattr(unit, "model_dump"):
            unit = unit.model_dump()
        if isinstance(unit, str):
            unit = {"content": unit}
        if not isinstance(unit, dict):
            continue

        content = str(unit.get("content") or "")
        if not content:
            continue
        supporting_chunk_ids = unit.get("supporting_chunk_ids") or []
        supporting_citations = unit.get("supporting_citations") or []
        rendered_units.append(
            _content_to_html(
                content,
                is_section_start and index == 0,
                supporting_chunk_ids=supporting_chunk_ids,
                supporting_citations=supporting_citations,
                plan_number=plan_number,
                plan_name=plan_name,
                pdf_citation_base_url=pdf_citation_base_url,
                citation_number_start=next_citation_number,
                heading_level=heading_level if index == 0 else None,
                inline_document_links=inline_document_links,
            )
        )
        next_citation_number += _count_rendered_citations(
            supporting_chunk_ids=supporting_chunk_ids,
            supporting_citations=supporting_citations,
        )

    return "".join(rendered_units), next_citation_number


def _to_reportlab_markup(content_html: str) -> str:
    """Convert the existing section HTML into ReportLab Paragraph markup."""
    markup = content_html.replace("</p><p>", "<br/><br/>")
    markup = markup.replace("<p>", "").replace("</p>", "")
    return markup.replace("<br>", "<br/>")


def _move_heading_citations_to_content(paragraphs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Move section-heading citations onto the next content paragraph."""
    prepared: list[dict[str, Any]] = []
    pending_chunk_ids: list[str] = []
    pending_citations: list[dict[str, Any]] = []
    for paragraph in paragraphs:
        prepared_paragraph = dict(paragraph)
        metadata = prepared_paragraph.get("metadata") or {}
        chunk_ids = list(prepared_paragraph.get("supporting_chunk_ids") or [])
        citations = list(prepared_paragraph.get("supporting_citations") or [])
        if metadata.get("is_section_start", False):
            pending_chunk_ids.extend(chunk_ids)
            pending_citations.extend(citations)
            prepared_paragraph["supporting_chunk_ids"] = []
            prepared_paragraph["supporting_citations"] = []
        elif pending_chunk_ids or pending_citations:
            prepared_paragraph["supporting_chunk_ids"] = pending_chunk_ids + chunk_ids
            prepared_paragraph["supporting_citations"] = pending_citations + citations
            pending_chunk_ids = []
            pending_citations = []
        prepared.append(prepared_paragraph)
    return prepared


def _normalize_evidence_block(value: Any) -> dict[str, Any]:
    """Coerce nested evidence blocks to the field-specific citation format."""
    if hasattr(value, "model_dump"):
        value = value.model_dump()
    if isinstance(value, str):
        value = {"content": value}
    if not isinstance(value, dict):
        return {"content": [], "supporting_chunk_ids": [], "supporting_citations": []}

    content = value.get("content")
    if content is None and value.get("text") is not None:
        content = value.get("text")
    if isinstance(content, str):
        content = [{
            "content": content,
            "supporting_chunk_ids": value.get("supporting_chunk_ids") or [],
            "supporting_citations": value.get("supporting_citations") or [],
        }]
    units = []
    for unit in content if isinstance(content, list) else []:
        if hasattr(unit, "model_dump"):
            unit = unit.model_dump()
        if isinstance(unit, str):
            unit = {"content": unit}
        if not isinstance(unit, dict):
            continue
        units.append({
            "content": _sanitize(str(unit.get("content") or "")),
            "supporting_chunk_ids": [
                str(chunk_id) for chunk_id in (unit.get("supporting_chunk_ids") or []) if str(chunk_id).strip()
            ],
            "supporting_citations": unit.get("supporting_citations") or [],
        })
    return {
        "content": units,
        "supporting_chunk_ids": [],
        "supporting_citations": [],
    }


def _evidence_markup(
    evidence_block: dict[str, Any],
    plan_number: str | int | None,
    plan_name: str | None,
    pdf_citation_base_url: str | None,
    citation_number_start: int,
) -> tuple[str, int]:
    next_citation_number = citation_number_start
    rendered_units: list[str] = []
    for unit in _normalize_evidence_block(evidence_block)["content"]:
        content = html.escape(_sanitize(str(unit.get("content") or ""))).replace("\n", "<br/>")
        citations = _unique_citations(unit.get("supporting_citations"))
        if not citations:
            citations = _unique_citations([
                {"chunk_id": chunk_id} for chunk_id in (unit.get("supporting_chunk_ids") or [])
            ])

        links: list[str] = []
        for citation in citations:
            href = html.escape(
                _citation_href(citation, plan_number, plan_name, pdf_citation_base_url),
                quote=True,
            )
            safe_chunk_id = html.escape(_sanitize(citation.get("citation_label") or str(citation["chunk_id"])))
            links.append(f'<link href="{href}" color="#1155CC">{safe_chunk_id}</link>')
            next_citation_number += 1

        if links:
            content = f"{content} [{', '.join(links)}]"
        rendered_units.append(content)
    return " ".join(rendered_units), next_citation_number


def _past_review_flowables(
    sub_report: dict[str, Any],
    historical_reviews: list[dict[str, Any]],
    plan_number: str | int | None,
    plan_name: str | None,
    pdf_citation_base_url: str | None,
    citation_number_start: int,
) -> tuple[list[Any], int]:
    reportlab_colors = importlib.import_module("reportlab.lib.colors")
    reportlab_enums = importlib.import_module("reportlab.lib.enums")
    reportlab_styles = importlib.import_module("reportlab.lib.styles")
    reportlab_units = importlib.import_module("reportlab.lib.units")
    reportlab_platypus = importlib.import_module("reportlab.platypus")

    styles = reportlab_styles.getSampleStyleSheet()
    body_style = reportlab_styles.ParagraphStyle(
        "PastReviewBody",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=8,
        leading=10,
        spaceAfter=4,
    )
    heading_style = reportlab_styles.ParagraphStyle(
        "PastReviewHeading",
        parent=styles["Heading3"],
        fontName="Helvetica-Bold",
        fontSize=HEADING_FONT_SIZES[1],
        leading=HEADING_FONT_SIZES[1] + 3,
        spaceBefore=8,
        spaceAfter=5,
    )
    centered_style = reportlab_styles.ParagraphStyle(
        "PastReviewCentered",
        parent=body_style,
        alignment=reportlab_enums.TA_CENTER,
    )

    flowables: list[Any] = [
        reportlab_platypus.Paragraph("<b>Summary</b>", heading_style),
        reportlab_platypus.Paragraph(
            "<b>Number of similar reviews:</b> "
            f"{html.escape(_sanitize(str(sub_report.get('similar_review_count', 0))))}",
            body_style,
        ),
        reportlab_platypus.Paragraph("<b>Key Observations</b>", heading_style),
    ]
    next_citation_number = citation_number_start

    normalized_reviews: list[tuple[str, str | None, list[dict[str, Any]]]] = []
    for historical_review in historical_reviews:
        if not isinstance(historical_review, dict):
            continue
        historical_review_id = _sanitize(str(historical_review.get("historical_review_id") or "Data Not Available"))
        review_title_value = historical_review.get("review_title")
        review_title = _sanitize(str(review_title_value)) if review_title_value else None
        assessments = [
            assessment
            for assessment in (historical_review.get("assessments") or [])
            if isinstance(assessment, dict)
        ]
        normalized_reviews.append((historical_review_id, review_title, assessments))
        if assessments:
            observation_markup, next_citation_number = _evidence_markup(
                _normalize_evidence_block(assessments[0].get("key_observation")),
                plan_number,
                plan_name,
                pdf_citation_base_url,
                next_citation_number,
            )
            review_label = f"Review ID {html.escape(historical_review_id)}"
            if review_title:
                review_label += f" ({html.escape(review_title)})"
            flowables.append(
                reportlab_platypus.Paragraph(
                    f"<b>{review_label}:</b> {observation_markup}",
                    body_style,
                )
            )

    flowables.append(reportlab_platypus.Paragraph("<b>Implications</b>", heading_style))
    for historical_review_id, review_title, assessments in normalized_reviews:
        if assessments:
            implication_markup, next_citation_number = _evidence_markup(
                _normalize_evidence_block(assessments[0].get("implication_for_current_review")),
                plan_number,
                plan_name,
                pdf_citation_base_url,
                next_citation_number,
            )
            review_label = f"Review ID {html.escape(historical_review_id)}"
            if review_title:
                review_label += f" ({html.escape(review_title)})"
            flowables.append(
                reportlab_platypus.Paragraph(
                    f"<b>{review_label}:</b> {implication_markup}",
                    body_style,
                )
            )

    table_data: list[list[Any]] = [[
        reportlab_platypus.Paragraph("<b>Historical Review IDs</b>", centered_style),
        reportlab_platypus.Paragraph("<b>Assessed Area</b>", centered_style),
        reportlab_platypus.Paragraph("<b>Key Observations</b>", centered_style),
        reportlab_platypus.Paragraph("<b>Relevance to Current Review</b>", centered_style),
    ]]
    for historical_review_id, _review_title, assessments in normalized_reviews:
        for assessment in assessments[1:]:
            key_observation_block = _normalize_evidence_block(assessment.get("key_observation"))
            implication_block = _normalize_evidence_block(assessment.get("implication_for_current_review"))
            observation_markup, next_citation_number = _evidence_markup(
                key_observation_block,
                plan_number,
                plan_name,
                pdf_citation_base_url,
                next_citation_number,
            )
            implication_markup, next_citation_number = _evidence_markup(
                implication_block,
                plan_number,
                plan_name,
                pdf_citation_base_url,
                next_citation_number,
            )
            table_data.append([
                reportlab_platypus.Paragraph(html.escape(historical_review_id), centered_style),
                reportlab_platypus.Paragraph(
                    html.escape(_sanitize(str(assessment.get("assessed_area") or ""))),
                    body_style,
                ),
                reportlab_platypus.Paragraph(observation_markup, body_style),
                reportlab_platypus.Paragraph(implication_markup, body_style),
            ])

    if len(table_data) > 1:
        flowables.append(reportlab_platypus.Spacer(1, 8))
        table = reportlab_platypus.LongTable(
            table_data,
            colWidths=[32 * reportlab_units.mm, 50 * reportlab_units.mm, 92 * reportlab_units.mm, 92 * reportlab_units.mm],
            repeatRows=1,
            splitByRow=1,
        )
        table.setStyle(reportlab_platypus.TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), reportlab_colors.HexColor("#D9E2F3")),
            ("TEXTCOLOR", (0, 0), (-1, 0), reportlab_colors.HexColor("#1F1F1F")),
            ("GRID", (0, 0), (-1, -1), 0.5, reportlab_colors.HexColor("#808080")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        flowables.append(table)
    return flowables, next_citation_number


def _split_top_level_csv(text: str) -> list[str]:
    parts: list[str] = []
    start = 0
    depth = 0
    quote: str | None = None
    escaped = False

    for idx, ch in enumerate(text):
        if escaped:
            escaped = False
            continue

        if quote:
            if ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue

        if ch in ("'", '"'):
            quote = ch
            continue
        if ch in "([{":
            depth += 1
            continue
        if ch in ")]}":
            depth = max(0, depth - 1)
            continue
        if ch == "," and depth == 0:
            parts.append(text[start:idx].strip())
            start = idx + 1

    tail = text[start:].strip()
    if tail:
        parts.append(tail)

    return [part for part in parts if part]


def _find_matching_paren(text: str, open_idx: int) -> int:
    depth = 0
    quote: str | None = None
    escaped = False

    for idx in range(open_idx, len(text)):
        ch = text[idx]
        if escaped:
            escaped = False
            continue

        if quote:
            if ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue

        if ch in ("'", '"'):
            quote = ch
            continue
        if ch == "(":
            depth += 1
            continue
        if ch == ")":
            depth -= 1
            if depth == 0:
                return idx

    return -1


def _to_python_value(raw: str) -> Any:
    value = raw.strip()
    if value == "None":
        return None
    if value in {"True", "False"}:
        return value == "True"
    try:
        return ast.literal_eval(value)
    except (ValueError, SyntaxError):
        return value


def _parse_metadata(raw: str) -> dict[str, Any]:
    text = raw.strip()
    prefix = "ParagraphMetadata("
    if not text.startswith(prefix) or not text.endswith(")"):
        return {
            "is_section_start": False,
            "section_confidence_score": None,
        }

    inner = text[len(prefix):-1]
    parsed: dict[str, Any] = {
        "is_section_start": False,
        "section_confidence_score": None,
    }

    for token in _split_top_level_csv(inner):
        if "=" not in token:
            continue
        key, value = token.split("=", 1)
        parsed[key.strip()] = _to_python_value(value)

    return {
        "is_section_start": bool(parsed.get("is_section_start", False)),
        "section_confidence_score": parsed.get("section_confidence_score"),
    }


def _parse_paragraph_citation(raw: str) -> dict[str, Any]:
    text = raw.strip()
    prefix = "ParagraphCitation("
    if not text.startswith(prefix) or not text.endswith(")"):
        return {}

    inner = text[len(prefix):-1]
    fields: dict[str, Any] = {}
    for token in _split_top_level_csv(inner):
        if "=" not in token:
            continue
        key, value = token.split("=", 1)
        fields[key.strip()] = value.strip()

    return {
        "paragraph_id": _to_python_value(fields.get("paragraph_id", "None")),
        "content": _to_python_value(fields.get("content", "''")) or "",
        "supporting_chunk_ids": _to_python_value(fields.get("supporting_chunk_ids", "[]")) or [],
        "supporting_citations": _to_python_value(fields.get("supporting_citations", "[]")) or [],
        "rationale": _to_python_value(fields.get("rationale", "None")),
        "metadata": _parse_metadata(fields.get("metadata", "")),
    }


def _parse_compound_report(raw: str) -> dict[str, Any]:
    if not isinstance(raw, str) or "paragraphs=[" not in raw:
        return {
            "report_title": "Untitled Report Section",
            "paragraphs": [],
        }

    report_title_match = re.search(r"report_title\s*=\s*(['\"])(.*?)\1", raw, flags=re.DOTALL)
    report_title = report_title_match.group(2) if report_title_match else "Untitled Report Section"

    start = raw.find("paragraphs=[")
    if start == -1:
        return {
            "report_title": report_title,
            "paragraphs": [],
        }

    list_start = start + len("paragraphs=")
    if list_start >= len(raw) or raw[list_start] != "[":
        return {
            "report_title": report_title,
            "paragraphs": [],
        }

    depth = 0
    list_end = -1
    quote: str | None = None
    escaped = False
    for idx in range(list_start, len(raw)):
        ch = raw[idx]
        if escaped:
            escaped = False
            continue

        if quote:
            if ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue

        if ch in ("'", '"'):
            quote = ch
            continue
        if ch == "[":
            depth += 1
            continue
        if ch == "]":
            depth -= 1
            if depth == 0:
                list_end = idx
                break

    if list_end == -1:
        return {
            "report_title": report_title,
            "paragraphs": [],
        }

    raw_list = raw[list_start + 1:list_end]
    paragraphs: list[dict[str, Any]] = []
    search_from = 0
    marker = "ParagraphCitation("
    while True:
        marker_idx = raw_list.find(marker, search_from)
        if marker_idx == -1:
            break

        open_idx = marker_idx + len(marker) - 1
        close_idx = _find_matching_paren(raw_list, open_idx)
        if close_idx == -1:
            break

        citation_text = raw_list[marker_idx:close_idx + 1]
        parsed = _parse_paragraph_citation(citation_text)
        if parsed:
            paragraphs.append(parsed)

        search_from = close_idx + 1

    return {
        "report_title": report_title,
        "paragraphs": paragraphs,
    }


def normalize_analysis_report(analysis_report: dict[str, Any]) -> dict[str, Any]:
    """Normalize section payload into the structure expected by PDF generation."""
    normalized: dict[str, Any] = {}

    for section_name, section_value in (analysis_report or {}).items():
        # Sections may arrive as validated ScopingReport models (e.g. from PreliminaryResearchDocument).
        if hasattr(section_value, "model_dump"):
            section_value = section_value.model_dump()

        if isinstance(section_value, dict):
            report_title = section_value.get("report_title") or section_name
            historical_reviews = section_value.get("historical_reviews")
            if isinstance(historical_reviews, list):
                normalized[section_name] = {
                    "report_title": report_title,
                    "current_review_id": section_value.get("current_review_id"),
                    "similar_review_count": section_value.get("similar_review_count", 0),
                    "historical_reviews": historical_reviews,
                }
                continue
            paragraphs = section_value.get("paragraphs") or []
            normalized[section_name] = {
                "report_title": report_title,
                "paragraphs": paragraphs,
            }
            continue

        if isinstance(section_value, str):
            parsed = _parse_compound_report(section_value)
            if parsed["report_title"] == "Untitled Report Section":
                parsed["report_title"] = section_name
            normalized[section_name] = parsed
            continue

        normalized[section_name] = {
            "report_title": section_name,
            "paragraphs": [],
        }

    return normalized


def build_report_pdf(
    analysis_report: dict[str, Any],
    plan_number: str | int | None,
    plan_name: str | None,
    pdf_citation_base_url: str | None = None,
) -> bytes:
    try:
        reportlab_pagesizes = importlib.import_module("reportlab.lib.pagesizes")
        reportlab_styles = importlib.import_module("reportlab.lib.styles")
        reportlab_units = importlib.import_module("reportlab.lib.units")
        reportlab_platypus = importlib.import_module("reportlab.platypus")
    except ModuleNotFoundError as exc:
        raise RuntimeError("PDF generation dependency missing. Install 'reportlab'.") from exc

    styles = reportlab_styles.getSampleStyleSheet()
    body_style = reportlab_styles.ParagraphStyle(
        "ReportBody",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=10,
        leading=14,
        spaceAfter=7,
        autoLeading="max",
    )
    report_title_style = reportlab_styles.ParagraphStyle(
        "ReportSectionTitle",
        parent=styles["Heading2"],
        fontSize=REPORT_TITLE_FONT_SIZE,
        leading=REPORT_TITLE_FONT_SIZE + 4,
    )
    buffer = io.BytesIO()
    document = reportlab_platypus.SimpleDocTemplate(
        buffer,
        pagesize=reportlab_pagesizes.landscape(reportlab_pagesizes.A4),
        title="Preliminary Research Report",
        leftMargin=15 * reportlab_units.mm,
        rightMargin=15 * reportlab_units.mm,
        topMargin=15 * reportlab_units.mm,
        bottomMargin=15 * reportlab_units.mm,
    )
    story: list[Any] = [reportlab_platypus.Paragraph("Preliminary Research Report", styles["Title"])]
    if plan_number:
        story.append(reportlab_platypus.Paragraph(
            f"<b>Plan Number:</b> {html.escape(_sanitize(str(plan_number)))}",
            body_style,
        ))
    if plan_name:
        story.append(reportlab_platypus.Paragraph(
            f"<b>Plan Title:</b> {html.escape(_sanitize(str(plan_name)))}",
            body_style,
        ))

    ordered_keys = [key for key in CONSOLIDATED_SECTIONS if key in analysis_report]
    ordered_keys += [key for key in analysis_report if key not in CONSOLIDATED_SECTIONS]
    next_citation_number = 1

    for section_name in ordered_keys:
        sub_report = analysis_report.get(section_name) or {}
        report_title = sub_report.get("report_title") or "Untitled Report Section"
        story.append(reportlab_platypus.Paragraph(html.escape(_sanitize(report_title)), report_title_style))

        historical_reviews = sub_report.get("historical_reviews")
        if isinstance(historical_reviews, list):
            past_review_flowables, next_citation_number = _past_review_flowables(
                sub_report,
                historical_reviews,
                plan_number,
                plan_name,
                pdf_citation_base_url,
                next_citation_number,
            )
            story.extend(past_review_flowables)
            continue

        paragraphs = _move_heading_citations_to_content(sub_report.get("paragraphs", []))
        is_policy_report = section_name == "Policy, KOD and Regulatory Analysis"
        in_source_evidence_log = False
        for paragraph in paragraphs:
            content = paragraph.get("content", "")
            if not content:
                continue
            is_section_start = paragraph.get("metadata", {}).get("is_section_start", False)
            if is_policy_report and is_section_start:
                if isinstance(content, list):
                    first_unit = content[0] if content else {}
                    if hasattr(first_unit, "model_dump"):
                        first_unit = first_unit.model_dump()
                    heading_text = first_unit.get("content", "") if isinstance(first_unit, dict) else ""
                else:
                    heading_text = content
                in_source_evidence_log = (
                    str(heading_text).splitlines()[0].strip() == "Section 6: Source Evidence Log"
                )
            inline_document_links = is_policy_report and in_source_evidence_log
            heading_level = (paragraph.get("metadata") or {}).get("heading_level")
            supporting_chunk_ids = paragraph.get("supporting_chunk_ids") or []
            supporting_citations = paragraph.get("supporting_citations") or []
            if isinstance(content, list):
                content_html, next_citation_number = _narrative_units_to_html(
                    content,
                    is_section_start,
                    plan_number,
                    plan_name,
                    pdf_citation_base_url,
                    next_citation_number,
                    heading_level=heading_level,
                    inline_document_links=inline_document_links,
                )
            else:
                content_html = _content_to_html(
                    content,
                    is_section_start,
                    supporting_chunk_ids=supporting_chunk_ids,
                    supporting_citations=supporting_citations,
                    plan_number=plan_number,
                    plan_name=plan_name,
                    pdf_citation_base_url=pdf_citation_base_url,
                    citation_number_start=next_citation_number,
                    heading_level=heading_level,
                    inline_document_links=inline_document_links,
                )
                next_citation_number += _count_rendered_citations(
                    supporting_chunk_ids=supporting_chunk_ids,
                    supporting_citations=supporting_citations,
                )
            story.append(reportlab_platypus.Paragraph(
                _to_reportlab_markup(content_html),
                body_style,
            ))

    document.build(story)
    return buffer.getvalue()


def download_research_walkthrough_pdf(
    plan_number: str,
    analysis_report: dict[str, Any],
    plan_name: str | None = None,
    pdf_citation_base_url: str | None = None,
) -> tuple[bytes, dict[str, str]]:
    """Generate research walkthrough PDF bytes and response headers."""
    normalized_report = normalize_analysis_report(analysis_report)
    pdf_bytes = build_report_pdf(
        analysis_report=normalized_report,
        plan_number=plan_number,
        plan_name=plan_name,
        pdf_citation_base_url=pdf_citation_base_url,
    )

    file_name = (
        f"Preliminary_Research_Report_{plan_number}.pdf"
        if plan_number
        else "Preliminary_Research_Report.pdf"
    )
    headers = {
        "Content-Disposition": f'attachment; filename="{file_name}"',
        "Content-Type": "application/pdf",
    }
    return pdf_bytes, headers
