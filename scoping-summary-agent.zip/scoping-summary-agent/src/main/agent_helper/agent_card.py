def build_agent_card(activity_type: str, query: str, plan_item_number: str, correlation_id: str) -> dict:
    """
    Builds a structured metadata context map (Agent Card) required by the Action Service client.
    """
    return {
        "ENTITY_ID": plan_item_number,
        "PARENT_ENTITY_TYPE": "SCOPING_SUMMARY",
        "PARENT_ENTITY_ID": plan_item_number,
        "CORRELATION_ID": correlation_id,
        "ACTOR_TYPE": "HUMAN",
        "ACTOR_ID": "dbaware@db.com",
        "ACTION_TYPE": "QUERY",
        # Summary Agent details
        "ACTION_ID": "",
        "INSERT_TS": "",
        "CREATE_TS": ""
    }
