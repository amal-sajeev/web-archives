import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    db_host = os.getenv("db_host","localhost")
    db_user = os.getenv("db_user")
    db_name = os.getenv("db_name")
    db_port = os.getenv("db_port","5432")
    db_pass = os.getenv("scoping_db_pass")
    MODEL_NAME = "gemini-2.5-pro"
    SUMMARY_AGENT_REVIEW_MAX_REVISIONS = int(
        os.getenv("SUMMARY_AGENT_REVIEW_MAX_REVISIONS", "1")
    )
    SUMMARY_AGENT_REVIEW_FAILURE_POLICY = os.getenv(
        "SUMMARY_AGENT_REVIEW_FAILURE_POLICY", "fail_open"
    ).strip().lower()
    if SUMMARY_AGENT_REVIEW_MAX_REVISIONS < 0:
        raise ValueError("SUMMARY_AGENT_REVIEW_MAX_REVISIONS must be 0 or greater")
    if SUMMARY_AGENT_REVIEW_FAILURE_POLICY not in {"fail_open", "fail_closed"}:
        raise ValueError(
            "SUMMARY_AGENT_REVIEW_FAILURE_POLICY must be 'fail_open' or 'fail_closed'"
        )
    GENERATION_CONFIG = {
        "temperature": 0.0,
        "top_p": 0.5,
        "top_k": 32
    }
    SAFETY_CONFIG = {
        "safety_settings": {
            "HARM_CATEGORY_HARASSMENT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_HATE_SPEECH": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_MEDIUM_AND_ABOVE",
            "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_MEDIUM_AND_ABOVE"
        }
    }
    PROJECT_NAME = (
        os.getenv("PROJECT_NAME")
        or os.getenv("project_name")
    
    )
    PROJECT_LOCATION = (
        os.getenv("PROJECT_LOCATION")
        or os.getenv("project_location")
        
    )
    REVIEW_BUCKET_NAME = os.getenv(
        "DBAWARE_REVIEW_BUCKET_NAME",
    )
    HISTORICAL_REVIEW_BUCKET_NAME = os.getenv(
        "DBAWARE_HISTORICAL_REVIEW_BUCKET_NAME",
        REVIEW_BUCKET_NAME,
    )
    REVIEW_BUCKET_PREFIX = os.getenv("DBAWARE_REVIEW_BUCKET_PREFIX", "")
    REVIEW_PLAN_FOLDER_TEMPLATE = "dbaware_review_{plan_number}"
    REVIEW_INBOUND_DATA_FOLDER = "inbound-data"
    REVIEW_OUTBOUND_DATA_FOLDER = "processing-data/preliminary-research"
    REVIEW_OUTBOUND_DATA_FILE = "preliminary-research.json"
    HISTORICAL_REVIEW_DOCS_PREFIX = os.getenv(
        "DBAWARE_HISTORICAL_REVIEW_DOCS_PREFIX",
        "historical_scoping_documents",
    )
    DOWNLOAD_PDF_CITATION_BASE_URL = os.getenv(
        "SUMMARY_AGENT_PDF_CITATION_BASE_URL",
        "https://ct1-cta.dbaware.dev.gcp.db.com/dbaware-ui",
    )

    
    REVIEW_DATA_FILES = {
        "plan_details": {
            "folder": "dbaware",
            "file_name": os.getenv("DBAWARE_PLAN_DETAILS_FILE", "plan_details.json"),
        },
        "alc_nalc_details": {
            "folder": "dbaware",
            "file_name": os.getenv("DBAWARE_ALC_NALC_DETAILS_FILE", "alc_nalc_details.json"),
        },
        "historical_plan_details": {
            "folder": "dbaware",
            "file_name": os.getenv(
                "DBAWARE_HISTORICAL_PLAN_DETAILS_FILE",
                "historical_plan_details.json",
            ),
        },
        "control_details": {
            "folder": "dbgrc",
            "file_name": os.getenv("DBAWARE_CONTROL_DETAILS_FILE", "control_details.json"),
        },
        "findings_details": {
            "folder": "gfms",
            "file_name": os.getenv("DBAWARE_FINDINGS_DETAILS_FILE", "findings_details.json"),
        },
        "group_audit_details": {
            "folder": "group_audit",
            "file_name": os.getenv("DBAWARE_GROUP_AUDIT_DETAILS_FILE", "group_audit_details.json"),
        },
        "internet_search_data": {
            "folder": "lrr",
            "file_name": os.getenv(
                "DBAWARE_INTERNET_SEARCH_FILE",
                "internet_search_data_enriched.json",
            ),
        },
        "relevant_kod": {
            "folder": "policy",
            "parts_folder": "policy/relevant_kod",
            "file_name": os.getenv("DBAWARE_RELEVANT_KOD_PROCEDURE_FILE", "relevant_kod.json"),
        },
        "relevant_procedure":{
            "folder": "policy",
            "parts_folder": "policy/relevant_procedure",
            "file_name": os.getenv("DBAWARE_RELEVANT_PROCEDURE_FILE", "relevant_procedure.json"),

        },
        "relevant_policy": {
            "folder": "policy",
            "parts_folder": "policy/relevant_policy",
            "file_name": os.getenv("DBAWARE_RELEVANT_POLICY_FILE", "relevant_policy.json"),
        },
    }
    DATA_EXTRACTION_SYSTEM_PROMPT="You are a Data Extraction Assistant with an access to mcp tools to fetch required data. Please call relevant mcp tools to get the data."
    


