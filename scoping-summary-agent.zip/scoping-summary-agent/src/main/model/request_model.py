from typing import Any, Dict, Optional
from model.response_model import AnalysisReportSection
from pydantic import BaseModel, ConfigDict, Field

class UserRequest(BaseModel):
    review_scope_instance_id: Optional[int] = Field(None)
    user: Optional[str] = Field(None, max_length=100)
    remarks: Optional[str] = Field(None, max_length=500)

class AnalyticsRequest(BaseModel):
    planNumber: str = Field(..., description="The plan number to analyze.")
    userDetails: UserRequest = Field(..., description="User details for the request.")

class GetDocumentRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    planNumber: Optional[str] = Field(
        None,
        description="Plan number. Required when requesting by chunk_id.",
    )
    chunk_id: Optional[str] = Field(
        None,
        description="Chunk identifier used to resolve citations from a plan mapping.",
    )
    document_uri: Optional[str] = Field(
        None,
        description="Direct gs:// document URI. When provided, document is fetched directly.",
    )
    page_number: Optional[int] = Field(
        None,
        alias="pageNumber",
        ge=1,
        description="Optional page number for direct document fetches or page-aware viewers.",
    )


class GetPreliminaryResearchRequest(BaseModel):
    planNumber: str = Field(
        ...,
        description="Plan number for retrieving the preliminary research document.",
    )


class EditPreliminaryResearchRequest(BaseModel):
    userDetails: UserRequest = Field(..., description="User details for the request.")
    model_config = ConfigDict(populate_by_name=True)

    plan_number: str = Field(
        ...,
        alias="planNumber",
        description="Plan number for updating the preliminary research document.",
    )
    analysis_report: Dict[str, AnalysisReportSection] = Field(
        ...,
        description="Updated analytics report to persist for the plan.",
    )


class DownloadResearchWalkthroughRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    plan_number: str = Field(
        ...,
        alias="planNumber",
        description="Plan number for generating the walkthrough PDF.",
    )
    plan_name: Optional[str] = Field(
        None,
        alias="planName",
        description="Optional plan display name used in PDF metadata.",
    )
    analysis_report: Dict[str, Any] = Field(
        ...,
        alias="analysisReport",
        description="Research walkthrough analysis payload to convert into PDF.",
    )
