import asyncio
import base64
import json
import logging
import re
from typing import Any, Dict, Optional
from urllib.parse import urlparse

from config.config import Config
from utils.storage_manager import blob_exists, list_blob_paths, read_blob_json, read_blob_from_uri_as_bytes

logger = logging.getLogger(__name__)



def _base_prefix(plan_number: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number),
    )
    parts = [p.strip("/") for p in [Config.REVIEW_BUCKET_PREFIX, plan_folder, Config.REVIEW_INBOUND_DATA_FOLDER] if p]
    return "/".join(parts)


def _historical_bucket_name() -> str:
    return Config.HISTORICAL_REVIEW_BUCKET_NAME or Config.REVIEW_BUCKET_NAME


def _plan_blob_path(plan_number: str, folder: str, file_name: str) -> str:
    return "/".join([_base_prefix(plan_number), folder, file_name])


def _build_gs_uri(blob_path: str, bucket_name: Optional[str] = None) -> str:
    resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
    return f"gs://{resolved_bucket_name}/{blob_path.lstrip('/')}"


def _historical_documents_prefix(historical_plan_number: str) -> str:
    """Build the prefix that stores historical scoping docs for a historical review id."""
    parts = [
        p.strip("/")
        for p in [
            Config.HISTORICAL_REVIEW_DOCS_PREFIX,
            str(historical_plan_number),
        ]
        if p
    ]
    return "/".join(parts)


def _extract_historical_plan_numbers(node: Any) -> list[str]:
    """Extract historical plan numbers from fixed historical_plan_details format.

    Expected input is a list of objects where each object contains
    "Plan Item Number".
    """
    if not isinstance(node, list):
        return []

    plan_numbers: list[str] = []
    for item in node:
        if not isinstance(item, dict):
            continue
        plan_number = item.get("Plan Item Number")
        if plan_number not in (None, ""):
            plan_numbers.append(str(plan_number).strip())

    deduped = []
    seen = set()
    for item in plan_numbers:
        if item not in seen:
            deduped.append(item)
            seen.add(item)
    return deduped


def _list_historical_review_documents(historical_plan_numbers: list[str]) -> list[Dict[str, Any]]:
    """Discover historical scoping documents for the given historical review ids.

    Expected layout: <historical_docs_prefix>/<historical_review_id>/<files>
    Only PDF files are currently attached to the model payload.
    """
    documents: list[Dict[str, Any]] = []
    bucket_name = _historical_bucket_name()
    for historical_plan_number in historical_plan_numbers:
        prefix = _historical_documents_prefix(historical_plan_number)

        try:
            blob_paths = list_blob_paths(prefix, bucket_name=bucket_name)
        except Exception:
            logger.exception(
                "Failed to list historical documents historical_plan_number=%s prefix=%s",
                historical_plan_number,
                prefix,
            )
            continue

        for blob_path in blob_paths:
            if blob_path.endswith("/"):
                continue
            if not blob_path.lower().endswith(".pdf"):
                logger.debug("Skipping unsupported historical document blob_path=%s", blob_path)
                continue

            documents.append(
                {
                    "historic_plan_number": str(historical_plan_number),
                    "document_name": blob_path.rsplit("/", 1)[-1],
                    "uri": _build_gs_uri(blob_path, bucket_name=bucket_name),
                }
            )

    logger.info(
        "Discovered historical review documents count=%s from_plans=%s",
        len(documents),
        [str(plan_number) for plan_number in historical_plan_numbers],
    )
    return documents


def _build_historical_document_chunk(document: Dict[str, Any]) -> Dict[str, Any]:
    """Build a standard source chunk for a historical review document."""
    return {
        "source_name": "historical_review_document",
        "metadata": {
            "url": document["uri"],
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
        "content": {
            "historic_plan_number": document["historic_plan_number"],
            "document_name": document["document_name"],
        },
    }


def get_plan_output_blob_path(plan_number: str, file_name: str) -> str:
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    )
    outbound_folder = (Config.REVIEW_OUTBOUND_DATA_FOLDER).strip("/")

    parts = [
        p.strip("/")
        for p in [
            Config.REVIEW_BUCKET_PREFIX,
            plan_folder,
            outbound_folder,
            file_name,
        ]
        if p
    ]
    return "/".join(parts)


def get_preliminary_research_blob_path(plan_number: str) -> str:
    """Build preliminary research blob path under the plan folder.

    Target format:
    dbaware_review_{plan_number}/processing-data/preliminary-research/preliminary-research.json
    """
    plan_folder = Config.REVIEW_PLAN_FOLDER_TEMPLATE.format(
        plan_number=str(plan_number)
    ).strip("/")
    outbound_folder = Config.REVIEW_OUTBOUND_DATA_FOLDER.strip("/")
    file_name = Config.REVIEW_OUTBOUND_DATA_FILE.strip("/")
    return "/".join([plan_folder, outbound_folder, file_name])


def read_plan_json(plan_number: str,  folder: str, file_name: str) -> Any:

    candidates = [file_name]
    if not file_name.lower().endswith(".json"):
        candidates.append(f"{file_name}.json")
    checked_paths = []

    for candidate in candidates:
        path = _plan_blob_path(plan_number, folder, candidate)
        checked_paths.append(path)
        if blob_exists(path):
            logger.info("Reading plan JSON blob path=%s", path)
            return path, read_blob_json(path)

    logger.warning(
        "Plan JSON blob not found plan_number=%s folder=%s file_name=%s bucket=%s checked_paths=%s",
        plan_number,
        folder,
        file_name,
        Config.REVIEW_BUCKET_NAME,
        checked_paths,
    )
    return None, None

def _natural_key(path: str) -> list:
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", path)]


def _relevance(doc: Any) -> float:
    try:
        return float(doc.get("document_relevance_score"))
    except (AttributeError, TypeError, ValueError):
        return float("-inf")


async def read_plan_json_parts_async(plan_number: str, cfg: Dict[str, str]) -> Any:
    """Merge the per-document JSON parts in cfg['parts_folder'] into one list, most relevant first.

    Falls back to the legacy single file when the folder has no parts.
    """
    prefix = _plan_blob_path(plan_number, cfg["parts_folder"], "")
    try:
        listed = await asyncio.to_thread(list_blob_paths, prefix)
    except Exception:
        logger.exception("Failed to list parts prefix=%s", prefix)
        listed = []
    # list_blob_paths strips the trailing "/", so the legacy sibling file (relevant_policy.json) also matches.
    paths = sorted(
        (p for p in listed if p.startswith(prefix) and p.lower().endswith(".json")),
        key=_natural_key,
    )
    if not paths:
        logger.info("No parts under prefix=%s, falling back to %s", prefix, cfg["file_name"])
        return await asyncio.to_thread(read_plan_json, plan_number, cfg["folder"], cfg["file_name"])

    contents = await asyncio.gather(*(asyncio.to_thread(read_blob_json, p) for p in paths))

    documents: list = []
    for path, content in zip(paths, contents):
        if isinstance(content, list):
            documents.extend(d for d in content if isinstance(d, dict))
        elif isinstance(content, dict) and isinstance(content.get("documents"), list):
            documents.extend(d for d in content["documents"] if isinstance(d, dict))
        elif isinstance(content, dict):
            documents.append(content)
        else:
            logger.warning("Skipping unreadable part path=%s", path)

    # Stable sort keeps filename order for equal/missing scores.
    documents.sort(key=_relevance, reverse=True)
    logger.info("Merged %s parts into %s documents prefix=%s", len(paths), len(documents), prefix)
    return prefix.rstrip("/"), documents


def read_citation_mapping(plan_number: str) -> Dict[str, str]:
    """Reads the chunk_id to path mapping file from blob storage."""
    file_name = "citation_mapping.json"
    path = get_plan_output_blob_path(plan_number, file_name)
    logger.info("Reading citation mapping from path=%s", path)
    if blob_exists(path):
        return read_blob_json(path)
    
    logger.warning("Citation mapping not found at path=%s", path)
    raise FileNotFoundError(f"Citation mapping for plan {plan_number} not found at {path}")


def read_plan_json_by_path(path: str) -> Any: 
    return read_blob_json(path)


def has_plan_data(plan_number: str) -> bool:
    plan_details_config = Config.REVIEW_DATA_FILES["plan_details"]
    plan_details_path = _plan_blob_path(
        plan_number,
        plan_details_config["folder"],
        plan_details_config["file_name"],
    )
    logger.info(
        "Checking for plan data existence plan_number=%s path=%s",
        plan_number,
        plan_details_path,
    )
    exists = blob_exists(plan_details_path)
    logger.info(
        "Plan data existence plan_number=%s path=%s exists=%s",
        plan_number,
        plan_details_path,
        exists,
    )
    return exists

async def read_plan_data_async(plan_number: str) -> Dict[str, Any]:
    logger.info("Reading plan data asynchronously plan_number=%s", plan_number)
    return await get_standard_scoping_data_async(plan_number)


def _unpack_plan_json(result: Any) -> tuple:
    """Normalize the output of read_plan_json into (url, content).

    read_plan_json returns (path, data) when the blob is found, or (None, None) when it
    is missing. This helper safely handles both cases so callers always get a
    (url, content) pair without risking a KeyError/IndexError on missing data.
    """
    if isinstance(result, tuple) and len(result) == 2:
        return result[0], result[1]
    return None, result


async def get_standard_scoping_data_async(plan_number: str) -> Dict[str, Any]:
    logger.debug("Building standard scoping data asynchronously")
    complete_plan_cfg = Config.REVIEW_DATA_FILES["plan_details"]
    internet_cfg = Config.REVIEW_DATA_FILES["internet_search_data"]
    findings_cfg = Config.REVIEW_DATA_FILES["findings_details"]
    group_audit_cfg = Config.REVIEW_DATA_FILES["group_audit_details"]
    controls_cfg = Config.REVIEW_DATA_FILES["control_details"]
    relevant_kod = Config.REVIEW_DATA_FILES["relevant_kod"]
    relevant_policy = Config.REVIEW_DATA_FILES["relevant_policy"]
    alternate_cfg = Config.REVIEW_DATA_FILES["alc_nalc_details"]
    historical_cfg = Config.REVIEW_DATA_FILES["historical_plan_details"]
    relevant_procedure = Config.REVIEW_DATA_FILES["relevant_procedure"]

    (
        current_plan_data,
        internet_search_data,
        findings_data,
        group_audit_data,
        controls_data,
        relevant_kod,
        relevant_policy,
        relevant_procedure,
        alternate_coverage_data,
        historical_data,
    ) = await asyncio.gather(
        asyncio.to_thread(
            read_plan_json,
            plan_number,
            complete_plan_cfg["folder"],
            complete_plan_cfg["file_name"],
        ),
        asyncio.to_thread(
            read_plan_json,
            plan_number,
            internet_cfg["folder"],
            internet_cfg["file_name"],
        ),
        asyncio.to_thread(
            read_plan_json,
            plan_number,
            findings_cfg["folder"],
            findings_cfg["file_name"],
        ),
        asyncio.to_thread(
            read_plan_json,
            plan_number,
            group_audit_cfg["folder"],
            group_audit_cfg["file_name"],
        ),
        asyncio.to_thread(
            read_plan_json,
            plan_number,
            controls_cfg["folder"],
            controls_cfg["file_name"],
        ),
        read_plan_json_parts_async(plan_number, relevant_kod),
        read_plan_json_parts_async(plan_number, relevant_policy),
        read_plan_json_parts_async(plan_number, relevant_procedure),
        asyncio.to_thread(
            read_plan_json,
            plan_number,
            alternate_cfg["folder"],
            alternate_cfg["file_name"],
        ),
        asyncio.to_thread(
            read_plan_json,
            plan_number,
            historical_cfg["folder"],
            historical_cfg["file_name"],
        ),
    )

    # Normalize each result into (url, content). read_plan_json returns
    # (path, data) when the blob exists and {} when it is missing, so unpacking
    # safely here avoids KeyError/IndexError for absent files (e.g. procedure).
    current_plan_url, current_plan_data = _unpack_plan_json(current_plan_data)
    internet_search_url, internet_search_data = _unpack_plan_json(internet_search_data)
    findings_url, findings_data = _unpack_plan_json(findings_data)
    group_audit_url, group_audit_data = _unpack_plan_json(group_audit_data)
    controls_url, controls_data = _unpack_plan_json(controls_data)
    relevant_kod_url, relevant_kod = _unpack_plan_json(relevant_kod)
    relevant_policy_url, relevant_policy = _unpack_plan_json(relevant_policy)
    relevant_procedure_url, relevant_procedure = _unpack_plan_json(relevant_procedure)
    alternate_coverage_url, alternate_coverage_data = _unpack_plan_json(alternate_coverage_data)
    historical_url, historical_data = _unpack_plan_json(historical_data)
    historical_plan_numbers = _extract_historical_plan_numbers(historical_data)
    historical_documents = _list_historical_review_documents(historical_plan_numbers)

    output1 = [
        {
            "source_name": "current_plan_item_details",
            "metadata": {"url": current_plan_url},
            "content": current_plan_data,
        },
        {
            "source_name": "historical_plan_item_details",
            "metadata": {"url": historical_url},
            "content": historical_data,
        },
    ]
    # Build independent chunk dicts per output; add_chunk_id mutates in place and
    # sharing objects across outputs would silently overwrite/gap their chunk_id.
    output1.extend(
        _build_historical_document_chunk(document)
        for document in historical_documents
    )
    # built_historical_documents = [
    #     _build_historical_document_chunk(document)
    #     for document in historical_documents
    # ]
    # logger.info("created historical documents ")
    # print(built_historical_documents)

    data = {
        "output1": output1,


        "output2": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            }
            ],


        "output3": [
            {
                "source_name": "current_plan_item_details",
                "metadata": {"url": current_plan_url},
                "content": current_plan_data,
            },
            {
                "source_name": "alternate_coverage",
                "metadata": {"url": alternate_coverage_url},
                "content": alternate_coverage_data,
            },
            {
                "source_name": "group_audit",
                "metadata": {"url": group_audit_url},
                "content": group_audit_data,
            },
            {
                "source_name": "key_controls",
                "metadata": {"url": controls_url},
                "content": controls_data,
            },
            {
                "source_name": "findings",
                "metadata": {"url": findings_url},
                "content": findings_data,
            },
            {
                "source_name": "relevant_kod",
                "metadata": {"url": relevant_kod_url},
                "content": relevant_kod,
            },
            {
                "source_name": "relevant_procedure",
                "metadata": {"url": relevant_procedure_url},
                "content": relevant_procedure,
            },
            {
                "source_name": "relevant_policy",
                "metadata": {"url": relevant_policy_url},
                "content": relevant_policy,
            },
            {
                "source_name": "internet_search",
                "metadata": {"url": internet_search_url},
                "content": internet_search_data,
            },
            *(
                _build_historical_document_chunk(document)
                for document in historical_documents
            ),
        ],
    }

    # A missing configured blob is returned as (None, None). Do not expose it
    # as a numbered prompt chunk: it has no URI that get_document can resolve.
    for output_name, chunks in data.items():
        resolved_chunks = []
        for chunk in chunks:
            metadata = chunk.get("metadata") or {}
            content = chunk.get("content") or {}
            embedded_citations = (
                content.get("citations") or content.get("sources")
                if isinstance(content, dict)
                else None
            )
            has_embedded_uri = (
                isinstance(embedded_citations, list)
                and any(
                    isinstance(citation, dict) and citation.get("gs_uri")
                    for citation in embedded_citations
                )
            )
            if metadata.get("url") or has_embedded_uri:
                resolved_chunks.append(chunk)
                continue
            logger.warning(
                "Skipping unresolved source chunk plan_number=%s output=%s source_name=%s",
                plan_number,
                output_name,
                chunk.get("source_name"),
            )
        data[output_name] = resolved_chunks

    indexed_data = add_chunk_id(data)
    chunk_id_path_mapping = create_citation_mapping(indexed_data)
    return indexed_data, chunk_id_path_mapping


def add_chunk_id(data):
    chunk_id = 1

    for key in data: 
        for chunk in data[key]:
            chunk["chunk_id"] = chunk_id
            chunk_id +=1

    return data 

def create_citation_mapping(indexed_data: Dict[str, Any]) -> Dict[int, list]:
    """
    Creates a mapping from chunk_id to a list of citation details.

    This function processes indexed data to extract citation information.
    For certain source types (containing 'kod', 'policy', or 'scoping'), it
    attempts to extract detailed citations from the content. Otherwise, it
    falls back to using the metadata URL as the citation source.

    The format for the output is:
    {
        "chunk_id": [{
            "content_type": "application/json" or "application/pdf",
            "document_name": "...",
            "access_info": {
                "uri": "..."
            }
        }]
    }

    Args:
        indexed_data: A dictionary containing the structured data with chunk_ids.

    Returns:
        A dictionary mapping each chunk_id to a list of citation objects.
    """
    chunk_id_path_mapping = {}
    source_keywords = ["kod", "policy", "scoping"]

    try:
        for key in indexed_data:
            if not isinstance(indexed_data.get(key), list):
                continue

            for chunk in indexed_data[key]:
                try:
                    chunk_id = chunk.get("chunk_id")
                    if not chunk_id:
                        logger.warning("Skipping chunk without chunk_id in key '%s'", key)
                        continue

                    citations_for_chunk = []
                    content = chunk.get("content")
                    source_name = chunk.get("source_name", "")
                    metadata = chunk.get("metadata", {})
                    url = metadata.get("url")

                    # Check if source_name contains keywords and content has 'citations'
                    if (any(keyword in source_name.lower() for keyword in source_keywords) and
                            isinstance(content, dict) and
                            "citations" in content and
                            isinstance(content.get("citations"), list)):

                        for citation in content["citations"]:
                            if isinstance(citation, dict):
                                doc_name = citation.get("document_name", "")
                                gs_uri = citation.get("gs_uri")
                                page_number = citation.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # parsing logic for new policy/kod/scoping structures using a "sources" list
                    if (not citations_for_chunk and
                            isinstance(content, dict) and
                            isinstance(content.get("sources"), list)):

                        for source in content["sources"]:
                            if isinstance(source, dict):
                                doc_name = source.get("document_name", "")
                                gs_uri = source.get("gs_uri")
                                page_number = source.get("page_number")

                                if gs_uri:
                                    content_type = "application/pdf" if doc_name.lower().endswith(".pdf") else "application/octet-stream"
                                    citations_for_chunk.append({
                                        "content_type": content_type,
                                        "document_name": doc_name,
                                        "access_info": {"uri": gs_uri},
                                        "location_metadata": {
                                            "page_number": page_number
                                        }
                                    })

                    # Fallback to metadata URL if no content citations were found or applicable
                    if not citations_for_chunk and url:
                        doc_name = url.split("/")[-1]
                        lower_name = doc_name.lower()
                        fallback_content_type = (
                            "application/pdf"
                            if lower_name.endswith(".pdf")
                            else "application/json"
                        )
                        citations_for_chunk.append({
                            "content_type": fallback_content_type,
                            "document_name": doc_name,
                            "access_info": {"uri": url},
                            "location_metadata": {}
                        })

                    chunk_id_path_mapping[str(chunk_id)] = citations_for_chunk
                    logger.info("mapping created for chunk_id = %s, citations = %s", chunk_id, str(citations_for_chunk[0])) 

                except Exception as e:
                    logger.error(
                        "Error processing chunk %s for citation mapping: %s",
                        chunk.get("chunk_id", "N/A"), e, exc_info=True
                    )

    except Exception as e:
        logger.error("Failed to create citation mapping. Error: %s", e, exc_info=True)

    return chunk_id_path_mapping



def process_citations(planNumber: str, chunk_id: int) -> Dict[str, Any]:
    """
    Fetches and processes the first citation document for a given chunk_id.

    This function reads the citation mapping for a plan, finds the relevant
    citations for the given chunk_id, and processes the first one based on its
    content type.
    - For JSON documents, it reads and returns the content.
    - For PDF documents, it fetches the document, encodes it in base64, and
      returns it along with metadata.

    Args:
        planNumber: The plan number.
        chunk_id: The chunk ID to retrieve citations for.

    Returns:
        A dictionary representing the processed citation. This contains the
        type, source metadata, and either the content (for JSON) or base64
        encoded content (for PDF).

    Raises:
        FileNotFoundError: If the citation mapping for the plan is not found,
                           or if the chunk_id does not exist in the mapping.
        RuntimeError: For any other unexpected errors during processing.
        ValueError: If the citation entry is missing a URI.
    """
    try:
        logger.info(
            "Processing citation for plan_number=%s  chunk_id=%s",
            planNumber,
            chunk_id,
        )
        mapping = read_citation_mapping(planNumber)  # Can raise FileNotFoundError
        chunk_id_str = str(chunk_id)
        citations = mapping.get(chunk_id_str) or mapping.get(chunk_id)
        logger.info("printing citation mapping ")
        print(mapping)
        if not citations:
            logger.warning("No citations found for chunk_id %s in plan %s", chunk_id, planNumber)
            raise FileNotFoundError(f"Document for chunk_id {chunk_id} not found in mapping for plan {planNumber}")

        # Per requirement, only process the first citation
        first_citation = citations[0]

        content_type = first_citation.get("content_type")
        uri = first_citation.get("access_info", {}).get("uri")

        if not uri:
            logger.error("First citation for chunk_id %s is missing a URI.", chunk_id)
            raise ValueError(f"Citation for chunk_id {chunk_id} is invalid; missing URI.")

        if content_type == "application/json":
            try:
                json_content = read_plan_json_by_path(uri)
                return {"type": "json", "source": first_citation, "content": json_content}
            except FileNotFoundError:
                logger.error("JSON blob not found at path: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        elif content_type == "application/pdf":
            try:
                pdf_bytes = read_blob_from_uri_as_bytes(uri)
                pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
                return {"type": "pdf", "source": first_citation, "content": pdf_base64}
            except FileNotFoundError:
                logger.error("PDF blob not found at URI: %s for chunk_id %s", uri, chunk_id)
                return {"type": "error", "source": first_citation, "message": f"File not found at {uri}"}
        else:
            logger.warning("Unsupported content_type '%s' for chunk_id %s and uri %s", content_type, chunk_id, uri)
            return {"type": "unsupported", "source": first_citation}
    except FileNotFoundError:
        logger.warning("Citation file or chunk_id not found for plan_number=%s.", planNumber)
        raise
    except ValueError as e:
        logger.error(str(e))
        raise
    except Exception as exc:
        logger.exception("Unexpected error in process_citations. plan_number=%s chunk_id=%s", planNumber, chunk_id)
        raise RuntimeError(f"An unexpected error occurred while processing citations for chunk {chunk_id}.") from exc


def process_document_uri(document_uri: str, page_number: int = 1) -> Dict[str, Any]:
    """Fetches and processes a document directly from a gs:// URI."""
    parsed_uri = urlparse(document_uri)
    if parsed_uri.scheme != "gs":
        raise ValueError("document_uri must use the gs:// scheme.")

    document_name = parsed_uri.path.rsplit("/", 1)[-1] if parsed_uri.path else "document"
    source = {
        "content_type": "application/octet-stream",
        "document_name": document_name,
        "access_info": {"uri": document_uri},
        "location_metadata": {"page_number": page_number},
    }

    if document_name.lower().endswith(".json"):
        raw_bytes = read_blob_from_uri_as_bytes(document_uri)
        raw_text = raw_bytes.decode("utf-8")
        try:
            content = json.loads(raw_text)
        except json.JSONDecodeError:
            content = raw_text
        source["content_type"] = "application/json"
        return {"type": "json", "source": source, "content": content}

    if document_name.lower().endswith(".pdf"):
        pdf_bytes = read_blob_from_uri_as_bytes(document_uri)
        pdf_base64 = base64.b64encode(pdf_bytes).decode("utf-8")
        source["content_type"] = "application/pdf"
        return {"type": "pdf", "source": source, "content": pdf_base64}

    return {"type": "unsupported", "source": source}