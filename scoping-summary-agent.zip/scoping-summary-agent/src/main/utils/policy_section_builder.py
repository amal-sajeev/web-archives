"""Deterministic assembly of Section 1 (Policy / Procedure / KOD) of the policy report.

The model only writes per-section summaries and applicability; document order, section
order, section headings, document applicability (from the RAG verdict), verbatim rationale
and scores all come from the source JSON.
"""

import logging
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

from model.response_model import (
    ParagraphCitation,
    ParagraphMetadata,
    PolicyRegulationOutput,
    ScopingReport,
)

logger = logging.getLogger(__name__)

# (source_name, key prefix, display label) in the order the sub-sections are rendered.
POLICY_SOURCES = (
    ("relevant_policy", "POLICY", "Policy"),
    ("relevant_procedure", "PROCEDURE", "Procedure"),
    ("relevant_kod", "KOD", "KOD"),
)
SECTION1_TITLE = "Section 1: Policy and Regulatory Context Summary"
MISSING_SUMMARY_TEXT = "Summary not available for this section."
VERDICT_APPLICABILITY = {
    "HIGH": "Directly Applicable",
    "MEDIUM": "Partially Applicable",
}
REGULATION_SOURCE = "internet_search"
REGULATION_PREFIX = "REG"

_SECTION_ID_RE = re.compile(r"^(\d+(?:\.\d+)*)(.*)$")


def _documents_from_content(content: Any) -> List[dict]:
    if isinstance(content, list):
        return [doc for doc in content if isinstance(doc, dict)]
    if isinstance(content, dict) and isinstance(content.get("documents"), list):
        return [doc for doc in content["documents"] if isinstance(doc, dict)]
    return []


def _section_sort_key(section_id: Optional[str]) -> tuple:
    """Natural sort: 4.2 < 4.2.1 < 4.2.1(EU) < 4.10; unnumbered pieces go last."""
    if not section_id:
        return (1, (), "")
    match = _SECTION_ID_RE.match(section_id.strip())
    if not match:
        return (1, (), section_id)
    numbers = tuple(int(part) for part in match.group(1).split("."))
    return (0, numbers, match.group(2).strip().lower())


def _pretty_title(title: Any) -> str:
    text = str(title or "").replace("_", " ")
    return re.sub(r"\s+", " ", text).strip()


def _format_score(score: Any) -> Optional[str]:
    try:
        return f"{float(score):.2f}"
    except (TypeError, ValueError):
        return None


def _section_heading(section_id: Optional[str], section_title: Optional[str]) -> str:
    title = (section_title or "").strip()
    if not section_id:
        return title
    # Glossary-style ids such as "5(GBSA)" carry the title "(GBSA)"; avoid repeating it.
    if not title or section_id.endswith(title):
        return f"Section {section_id}"
    return f"Section {section_id} {title}"


def _section_path_list(path: Any) -> List[str]:
    # New part files store section_path as a " > " joined string; older files use a list.
    if isinstance(path, str):
        return [p.strip() for p in path.split(">") if p.strip()]
    return list(path or [])


def _build_document(doc: dict, prefix: str, index: int) -> dict:
    doc_key = f"{prefix}|{index}"
    grouped: Dict[str, dict] = {}
    storage_uri = doc.get("storage_uri")
    for position, node in enumerate(doc.get("nodes") or []):
        if not isinstance(node, dict):
            continue
        storage_uri = storage_uri or node.get("storage_uri")
        section_id = str(node.get("section_id")).strip() if node.get("section_id") else None
        group_id = section_id or f"node:{node.get('node_id') or position}"
        key = f"{doc_key}|{group_id}"
        entry = grouped.get(key)
        if entry is None:
            entry = {
                "key": key,
                "section_id": section_id,
                "section_title": node.get("section_title"),
                "section_path": _section_path_list(node.get("section_path")),
                "page_start": node.get("page_start"),
                "page_end": node.get("page_end"),
                "texts": [],
            }
            grouped[key] = entry
        text = node.get("original_text")
        if text and text not in entry["texts"]:
            entry["texts"].append(text)
        for page_field, pick in (("page_start", min), ("page_end", max)):
            value = node.get(page_field)
            if isinstance(value, int):
                current = entry[page_field]
                entry[page_field] = value if not isinstance(current, int) else pick(current, value)

    sections = sorted(grouped.values(), key=lambda item: _section_sort_key(item["section_id"]))
    return {
        "doc_key": doc_key,
        "title": _pretty_title(doc.get("document_title")),
        "version": doc.get("document_version"),
        "storage_uri": storage_uri,
        "relevance_score": doc.get("document_relevance_score"),
        "rationale": doc.get("rationale"),
        "applicability": VERDICT_APPLICABILITY.get(
            str(doc.get("document_relevance_verdict") or "").strip().upper()
        ),
        "sections": sections,
    }


def build_policy_manifest(source_chunks: List[dict]) -> Dict[str, dict]:
    """Return {source_name: {"chunk_id", "label", "documents": [...]}} for policy, procedure and KOD."""
    chunks_by_source = {chunk.get("source_name"): chunk for chunk in source_chunks if isinstance(chunk, dict)}
    manifest: Dict[str, dict] = {}
    for source_name, prefix, label in POLICY_SOURCES:
        chunk = chunks_by_source.get(source_name) or {}
        documents = _documents_from_content(chunk.get("content"))
        manifest[source_name] = {
            "chunk_id": chunk.get("chunk_id"),
            "label": label,
            "documents": [_build_document(doc, prefix, idx) for idx, doc in enumerate(documents, start=1)],
        }
    return manifest


def _risk_entries(content: Any) -> List[dict]:
    if isinstance(content, dict):
        content = next(
            (value for value in content.values()
             if isinstance(value, list) and any(isinstance(v, dict) and "Mandates" in v for v in value)),
            [],
        )
    if not isinstance(content, list):
        return []
    return [risk for risk in content if isinstance(risk, dict) and isinstance(risk.get("Mandates"), list)]


def _evidence_label(evidence: dict) -> str:
    parsed = urlparse(str(evidence.get("source_url") or evidence.get("deep_link") or ""))
    host = parsed.netloc.removeprefix("www.")
    last_segment = parsed.path.rstrip("/").rsplit("/", 1)[-1]
    return " ".join(part for part in (host, last_segment) if part) or "Source"


def build_regulation_manifest(source_chunks: List[dict]) -> List[dict]:
    """Flatten regulatory risks into keyed mandates; each evidence item becomes a citable deep link."""
    chunk = next(
        (c for c in source_chunks if isinstance(c, dict) and c.get("source_name") == REGULATION_SOURCE),
        {},
    )
    mandates: List[dict] = []
    for risk_index, risk in enumerate(_risk_entries(chunk.get("content")), start=1):
        for mandate_index, mandate in enumerate(risk["Mandates"], start=1):
            if not isinstance(mandate, dict):
                continue
            key = f"{REGULATION_PREFIX}|{risk_index}|{mandate_index}"
            evidence = []
            for evidence_index, item in enumerate(mandate.get("Evidence") or [], start=1):
                if not isinstance(item, dict):
                    continue
                evidence.append({
                    "key": f"{key}|{evidence_index}",
                    "source_url": item.get("source_url"),
                    "deep_link": item.get("deep_link") or item.get("source_url"),
                    "evidence_text": item.get("evidence_text"),
                    "label": _evidence_label(item),
                })
            mandates.append({
                "key": key,
                "risk_name": risk.get("Risk Name"),
                "mandate": mandate.get("Regulatory Mandate"),
                "confidence_score": mandate.get("Confidence Score"),
                "rationale": mandate.get("AI Rationale"),
                "evidence": evidence,
            })
    return mandates


def regulation_citation_mapping(mandates: List[dict]) -> Dict[str, list]:
    """Map mandate and evidence keys to their external source links."""
    mapping: Dict[str, list] = {}
    for mandate in mandates:
        first_link = None
        for evidence in mandate["evidence"]:
            if not evidence["deep_link"]:
                continue
            citation = {
                "content_type": "text/html",
                "document_name": evidence["source_url"] or evidence["deep_link"],
                "access_info": {"uri": evidence["deep_link"]},
                "location_metadata": {},
                "citation_label": evidence["label"],
                "url": evidence["deep_link"],
            }
            mapping[evidence["key"]] = [citation]
            if first_link is None:
                first_link = citation
        if first_link is not None:
            mapping[mandate["key"]] = [first_link]
    return mapping


def to_model_source_chunks(
    source_chunks: List[dict],
    manifest: Dict[str, dict],
    regulation_mandates: Optional[List[dict]] = None,
) -> List[dict]:
    """Replace raw policy/procedure/KOD content with the compact keyed manifest the model must answer against."""
    model_chunks: List[dict] = []
    for chunk in source_chunks:
        source_name = chunk.get("source_name") if isinstance(chunk, dict) else None
        if source_name == REGULATION_SOURCE and regulation_mandates:
            model_chunks.append({
                "chunk_id": chunk.get("chunk_id"),
                "source_name": source_name,
                "content": [
                    {
                        "key": mandate["key"],
                        "risk_name": mandate["risk_name"],
                        "regulatory_mandate": mandate["mandate"],
                        "confidence_score": mandate["confidence_score"],
                        "rationale": mandate["rationale"],
                        "evidence": [
                            {
                                "key": item["key"],
                                "source_url": item["source_url"],
                                "evidence_text": item["evidence_text"],
                                "label": item["label"],
                            }
                            for item in mandate["evidence"]
                        ],
                    }
                    for mandate in regulation_mandates
                ],
            })
            continue
        if source_name not in manifest:
            model_chunks.append(chunk)
            continue
        model_chunks.append({
            "chunk_id": chunk.get("chunk_id"),
            "source_name": source_name,
            "content": [
                {
                    "doc_key": doc["doc_key"],
                    "document_title": doc["title"],
                    "document_version": doc["version"],
                    "rationale": doc["rationale"],
                    "sections": [
                        {
                            "key": section["key"],
                            "section_id": section["section_id"],
                            "section_title": section["section_title"],
                            "section_path": section["section_path"],
                            "text": "\n\n".join(section["texts"]),
                        }
                        for section in doc["sections"]
                    ],
                }
                for doc in manifest[source_name]["documents"]
            ],
        })
    return model_chunks


def _render_sections(doc: dict, summaries: Dict[str, Any]) -> List[str]:
    blocks: List[str] = []
    for section in doc["sections"]:
        summary = summaries.get(section["key"])
        if summary is None:
            body = MISSING_SUMMARY_TEXT
        else:
            body = (
                f"{summary.summary.strip()}\n"
                f"Applicability: {summary.applicability.strip()}. {summary.relevance.strip()}"
            )
        heading = _section_heading(section["section_id"], section["section_title"])
        blocks.append(f"<u>{heading}</u>: {body}" if heading else body)
    return blocks


def _render_document(number: int, doc: dict) -> str:
    heading = f"{number}. **{doc['title']}**"
    if doc["applicability"]:
        heading += f" - {doc['applicability']}"

    detail_parts = []
    score = _format_score(doc["relevance_score"])
    if score is not None:
        detail_parts.append(f"Relevance Score: {score}")

    lines = [heading]
    if detail_parts:
        lines.append(" | ".join(detail_parts))
    rationale = str(doc["rationale"] or "").strip()
    if rationale:
        lines.append(rationale)
    return "\n".join(lines)


def _render_mandate(number: int, mandate: dict, summary: Any) -> str:
    """Mandate block laid out like a policy document: heading with applicability, rationale, body."""
    name = (summary.name.strip() if summary is not None else "") or mandate["risk_name"] or "Regulatory Mandate"
    heading = f"{number}. **{name}**"
    if summary is not None and summary.applicability.strip():
        heading += f" - {summary.applicability.strip()}"

    lines = [heading]
    if mandate["rationale"]:
        lines.append(str(mandate["rationale"]).strip())
    body = summary.content.strip() if summary is not None else str(mandate["mandate"] or "").strip()
    if body:
        lines.append(body)
    return "\n".join(lines)


def _section_citation_label(section: dict) -> str:
    section_id = section.get("section_id")
    if section_id:
        return f"Section {section_id}"
    return f"Section {section.get('section_title') or 'source'}"


def _paragraph(content: str, chunk_ids: List[Any], **metadata: Any) -> ParagraphCitation:
    return ParagraphCitation(
        paragraph_id="",
        content=content,
        supporting_chunk_ids=[str(chunk_id) for chunk_id in chunk_ids if chunk_id not in (None, "")],
        supporting_citations=[],
        rationale=metadata.pop("rationale", None),
        metadata=ParagraphMetadata(
            is_section_start=metadata.pop("is_section_start", False),
            section_confidence_score=metadata.pop("section_confidence_score", None),
            heading_level=metadata.pop("heading_level", None),
        ),
    )


def _leading_text(content: Any) -> str:
    """Return the paragraph's leading text whether content is a string or narrative units."""
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        first = content[0]
        unit_text = getattr(first, "content", None)
        if unit_text is None and isinstance(first, dict):
            unit_text = first.get("content")
        if isinstance(unit_text, str):
            return unit_text
    return ""


def _drop_model_section1(paragraphs: List[ParagraphCitation]) -> List[ParagraphCitation]:
    """Guard against the model emitting its own Section 1 despite being told not to."""
    if not paragraphs or not _leading_text(paragraphs[0].content).lstrip().lower().startswith("section 1"):
        return paragraphs
    logger.warning("Model returned its own Section 1 in policy report paragraphs; discarding it")
    for index, paragraph in enumerate(paragraphs[1:], start=1):
        if paragraph.metadata.is_section_start:
            return paragraphs[index:]
    return []


def assemble_policy_report(
    output: PolicyRegulationOutput,
    manifest: Dict[str, dict],
    source_chunks: List[dict],
    report_title: str,
) -> ScopingReport:
    section1 = output.section1
    assessments = {item.doc_key: item for item in section1.document_assessments}
    summaries = {
        summary.key: summary
        for item in section1.document_assessments
        for summary in item.sections
    }

    expected_doc_keys = {doc["doc_key"] for entry in manifest.values() for doc in entry["documents"]}
    expected_section_keys = {
        section["key"] for entry in manifest.values() for doc in entry["documents"] for section in doc["sections"]
    }
    missing_sections = expected_section_keys - summaries.keys()
    if expected_doc_keys - assessments.keys() or missing_sections:
        logger.warning(
            "Policy report missing model output docs=%s sections=%s",
            sorted(expected_doc_keys - assessments.keys()),
            sorted(missing_sections),
        )
    unknown_keys = (summaries.keys() - expected_section_keys) | (assessments.keys() - expected_doc_keys)
    if unknown_keys:
        logger.warning("Policy report ignoring unknown model keys=%s", sorted(unknown_keys))

    current_plan_ids = [
        chunk.get("chunk_id") for chunk in source_chunks
        if isinstance(chunk, dict) and chunk.get("source_name") == "current_plan_item_details"
    ]
    paragraphs: List[ParagraphCitation] = [
        _paragraph(
            f"{SECTION1_TITLE}\n{section1.intro.strip()}",
            current_plan_ids,
            is_section_start=True,
            section_confidence_score=section1.confidence_score,
            rationale=section1.rationale,
        )
    ]

    mandates = section1.regulatory_mandates
    mandate_summaries = {item.key: item for item in mandates.mandates}
    regulation_mandates = build_regulation_manifest(source_chunks)
    unknown_mandates = mandate_summaries.keys() - {m["key"] for m in regulation_mandates}
    if unknown_mandates:
        logger.warning("Policy report ignoring unknown mandate keys=%s", sorted(unknown_mandates))
    if not regulation_mandates:
        paragraphs.append(_paragraph(
            "**Regulatory Mandates**\nData Not Available - no regulatory mandates were retrieved for this plan.",
            [],
            heading_level=2,
        ))
    else:
        paragraphs.append(_paragraph("**Regulatory Mandates**", [], heading_level=2))
        for number, mandate in enumerate(regulation_mandates, start=1):
            summary = mandate_summaries.get(mandate["key"])
            if summary is None:
                logger.warning("Policy report missing mandate key=%s", mandate["key"])
            # Only evidence with a link has a citation_mapping entry; citing the rest would render dead links.
            linked_keys = [evidence["key"] for evidence in mandate["evidence"] if evidence["deep_link"]]
            paragraphs.append(_paragraph(_render_mandate(number, mandate, summary), linked_keys, heading_level=3))

    for source_name, _prefix, label in POLICY_SOURCES:
        entry = manifest[source_name]
        if not entry["documents"]:
            paragraphs.append(_paragraph(
                f"**{label}**\nData Not Available - no relevant {label} documents were retrieved for this plan.",
                [],
                heading_level=2,
            ))
            continue
        paragraphs.append(_paragraph(f"**{label}**", [], heading_level=2))
        for number, doc in enumerate(entry["documents"], start=1):
            paragraphs.append(_paragraph(
                _render_document(number, doc),
                [],
                heading_level=3,
            ))
            for section, section_text in zip(doc["sections"], _render_sections(doc, summaries)):
                paragraphs.append(_paragraph(section_text, [section["key"]]))

    paragraphs.extend(_drop_model_section1(list(output.report.paragraphs)))
    for index, paragraph in enumerate(paragraphs, start=1):
        paragraph.paragraph_id = f"para_{index}"

    return ScopingReport(report_title=report_title, paragraphs=paragraphs)
