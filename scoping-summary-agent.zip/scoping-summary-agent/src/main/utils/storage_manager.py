import json
import logging
from typing import Any, Optional
from urllib.parse import urlparse

from google.api_core.exceptions import NotFound
from google.cloud import storage

from config.config import Config


logger = logging.getLogger(__name__)


def get_storage_client() -> storage.Client:
    logger.debug("Initializing GCS storage client project=%s", Config.PROJECT_NAME)
    return storage.Client(project=Config.PROJECT_NAME)


def get_bucket(bucket_name: Optional[str] = None) -> storage.Bucket:
    client = get_storage_client()
    resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
    bucket = client.bucket(resolved_bucket_name)
    logger.info("Using GCS bucket name=%s", resolved_bucket_name)
    return bucket


def blob_exists(blob_path: str, bucket_name: Optional[str] = None) -> bool:
    bucket = get_bucket(bucket_name)
    exists = bucket.blob(blob_path).exists()
    logger.info("Blob exists check path=%s exists=%s", blob_path, exists)
    return exists


def read_blob_text(blob_path: str, bucket_name: Optional[str] = None) -> str:
    bucket = get_bucket(bucket_name)
    blob = bucket.blob(blob_path)
    try:
        data = blob.download_as_text(encoding="utf-8")
    except NotFound as exc:
        resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
        raise FileNotFoundError(f"Blob not found: gs://{resolved_bucket_name}/{blob_path}") from exc
    logger.info("Read blob path=%s size=%s", blob_path, len(data))
    return data


def read_blob_json(blob_path: str, bucket_name: Optional[str] = None) -> Any:
    raw = read_blob_text(blob_path, bucket_name=bucket_name)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("Blob is not valid JSON path=%s", blob_path)
        return raw


def write_blob_json(blob_path: str, payload: Any, bucket_name: Optional[str] = None) -> str:
    bucket = get_bucket(bucket_name)
    blob = bucket.blob(blob_path)
    body = json.dumps(payload, indent=2, ensure_ascii=False, default=str)
    blob.upload_from_string(body, content_type="application/json")
    resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
    uri = f"gs://{resolved_bucket_name}/{blob_path}"
    logger.info("Wrote JSON blob uri=%s", uri)
    return uri


def read_blob_bytes(blob_path: str, bucket_name: Optional[str] = None) -> bytes:
    """Read a blob from the configured review bucket and return raw bytes."""
    bucket = get_bucket(bucket_name)
    blob = bucket.blob(blob_path)
    try:
        data = blob.download_as_bytes()
    except NotFound as exc:
        resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
        raise FileNotFoundError(f"Blob not found: gs://{resolved_bucket_name}/{blob_path}") from exc
    logger.info("Read blob bytes path=%s size=%s", blob_path, len(data))
    return data


def list_blob_paths(prefix: str, bucket_name: Optional[str] = None) -> list[str]:
    """List blob paths in the configured review bucket under the given prefix."""
    client = get_storage_client()
    clean_prefix = (prefix or "").strip("/")
    resolved_bucket_name = bucket_name or Config.REVIEW_BUCKET_NAME
    iterator = client.list_blobs(resolved_bucket_name, prefix=clean_prefix)
    paths = [blob.name for blob in iterator]
    logger.info("Listed blobs bucket=%s prefix=%s count=%s", resolved_bucket_name, clean_prefix, len(paths))
    return paths


def read_blob_from_uri_as_bytes(uri: str) -> bytes:
    """Reads a blob from a GCS URI and returns its content as bytes."""
    try:
        parsed_uri = urlparse(uri)
        if parsed_uri.scheme != "gs":
            raise ValueError("URI scheme must be 'gs'")

        bucket_name = parsed_uri.netloc
        blob_path = parsed_uri.path.lstrip("/")

        client = get_storage_client()
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(blob_path)

        logger.info("Reading blob from URI uri=%s", uri)
        return blob.download_as_bytes()
    except NotFound as exc:
        raise FileNotFoundError(f"Blob not found at URI: {uri}") from exc
    except Exception as exc:
        logger.error("Failed to read blob from URI %s. Error: %s", uri, exc)
        raise
