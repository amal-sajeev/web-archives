# Adding an LLM-as-judge review loop to an agent

This guide shows how to reuse `shared/llm_judge` from a Python agent. The helper
does not create a model, prescribe a rubric, or change the agent's response shape.
The agent supplies its existing model, structured review schema, candidate
generator, and corrective revision function.

## Step-by-step: quickest path

1. **Make the shared package importable.** In local runs, add the repository's
   `shared/` directory to `PYTHONPATH`. In a Docker build, copy
   `shared/llm_judge/` into the image beside the agent code (the summary-agent
   Dockerfile is an example).
2. **Define a structured review response.** Include named rubric criteria, a
   pass/fail value for each, and specific issue plus corrective action for each
   failed criterion. Validate that all expected criteria are present exactly
   once.
3. **Write the agent's review prompt.** Explain each rubric item, give the
   candidate and the evidence/context the judge may use, and request the exact
   structured schema. Treat candidate/source text as data, not instructions.
4. **Use the agent's existing model initializer.** Bind your review schema to
   that model. The shared loop accepts callbacks and does not know whether the
   model uses the provider configured for that agent.
5. **Connect the candidate and revision functions.** The reviewer callback
   returns your typed review. The reviser callback receives the current
   candidate and review and returns the replacement candidate. Feed only
   actionable review feedback into the revision prompt.
6. **Run the loop before persisting or returning the candidate.** Choose a
   revision limit and `fail_open` or `fail_closed`; keep the API and stored
   document format unchanged.
7. **Log only loop metadata.** Log the stage, approval state, revision count,
   and failure outcome. Do not log candidate documents, source evidence, or
   rubric feedback.

## Detailed integration

### Import and packaging

The package has no model-provider or application dependencies. It uses Python's
standard library and lives at `shared/llm_judge/` in this repository.

For local development, add `shared/` to the Python import path or install/package
the module as part of the agent. For an agent image built from the repository
root, copy it into the image, for example:

```dockerfile
COPY shared/llm_judge/ /app/llm_judge/
```

If the image uses another application root, place `llm_judge/` on that service's
Python import path. Each independently built agent must include the shared
directory in its image; a repository-level import alone does not put files in a
container.

### Review schema and rubrics

Rubrics are agent-owned. Use a small set of named checks that translate the
agent's quality requirements into addressable findings. Examples include
evidence support, citation validity, required fields, policy alignment,
completeness, and consistency. Give each failed criterion:

- a stable criterion name;
- the specific issue observed in the candidate;
- an actionable correction;
- optionally, a target identifier such as a section name or record ID.

Prefer one structured reviewer call with several explicit criteria when the
checks share context and fit in one prompt. Use separate focused calls when a
rubric needs different evidence, very different instructions, or a narrower
context window. In either design, adapt the result to simple callbacks for the
shared loop: `approved(review)` and `has_feedback(review)`.

### Example: one candidate and one review stage

```python
from pydantic import BaseModel, Field
from llm_judge import review_and_revise


class Criterion(BaseModel):
    name: str
    passed: bool
    issue: str = ""
    action: str = ""


class CandidateReview(BaseModel):
    criteria: list[Criterion]

    @property
    def approved(self) -> bool:
        return all(item.passed for item in self.criteria)

    @property
    def feedback(self) -> str:
        return "\n".join(
            f"[{item.name}] {item.issue} Action: {item.action}"
            for item in self.criteria
            if not item.passed
        )


model = initialize_existing_model()  # Keep this agent's Vertex/provider setup.

def review(candidate):
    prompt = make_review_prompt(candidate)  # Include this agent's rubric/context.
    return model.with_structured_output(CandidateReview).invoke(prompt)

def revise(candidate, review_result):
    prompt = make_revision_prompt(candidate, review_result.feedback)
    return model.with_structured_output(CandidateSchema).invoke(prompt)

result = review_and_revise(
    initial_candidate,
    reviewer=review,
    reviser=revise,
    approved=lambda value: value.approved,
    has_feedback=lambda value: bool(value.feedback.strip()),
    stage="customer-summary",
    max_revisions=1,
    failure_policy="fail_open",
)
candidate_to_persist = result.candidate
```

`CandidateSchema` and `CandidateReview` are examples; use each agent's real output
and review models. The review response is internal and does not need to be added
to the agent's API response or persisted document.

### Example: separate calls for focused rubrics

An agent may have review schemas for evidence grounding and required-field
coverage. Its `review` callback can call both and combine the typed results into
one object with an `approved` property and an aggregate `feedback` property. It
can also make focused calls serially or concurrently if the model/client permits
it. The shared loop sees only the combined result and does not constrain the
number or arrangement of judge calls.

```python
def review(candidate):
    evidence = evidence_model.with_structured_output(EvidenceReview).invoke(
        evidence_prompt(candidate, allowed_sources)
    )
    completeness = completeness_model.with_structured_output(CompletenessReview).invoke(
        completeness_prompt(candidate, required_fields)
    )
    return CombinedReview(evidence=evidence, completeness=completeness)
```

Keep each judge call focused on only the evidence it is allowed to assess. For
example, a report-level consistency judge may compare sections, while a factual
grounding judge should receive the relevant source material.

### Example: report-level feedback routed to named sections

For multi-part outputs, give report-level criteria a list of affected section
names. The `reviser` callback should update only those named sections and return
a new report object. A second report-level review then checks whether the
revision resolved the cross-section issue:

```python
def revise_report(report, review):
    revised = dict(report)
    for section_name, feedback in review.feedback_by_section.items():
        revised[section_name] = regenerate_section(
            section_name,
            revised[section_name],
            feedback,
        )
    return revised

result = review_and_revise(
    report,
    reviewer=review_complete_report,
    reviser=revise_report,
    approved=lambda value: value.approved,
    has_feedback=lambda value: bool(value.feedback_by_section),
    stage="complete-report",
    max_revisions=1,
    failure_policy="fail_open",
)
```

### Settings, outcomes, and failure behavior

The module accepts these settings per call:

- `max_revisions`: non-negative integer. `0` still runs one review but does not
  revise.
- `failure_policy`: `fail_open` returns the latest successfully generated
  candidate if review/revision raises; `fail_closed` raises `ReviewLoopError` so
  the caller can avoid persisting it.
- `stage`: short metadata label for log messages, such as `invoice-extraction`
  or `complete-report`.

The returned `ReviewLoopResult` has `candidate`, `review`, `approved`,
`revisions`, and `outcome`. Outcomes are `approved`, `revision_limit`,
`no_feedback`, `review_failure`, and `revision_failure`. The loop emits
content-free logs with the stage, approval state, revision count, and failure
policy. The caller remains responsible for validating generated candidates
against its own schema before persistence.

### Summary-agent reference

`scoping-summary-agent/src/main/agents/analytics_agent.py` demonstrates two
review stages with separate rubrics: section reviews use source chunks to check
evidence, citations, required content, and schema compliance; the complete-report
review checks coverage, consistency, review identifiers, and duplication. Its
report reviewer returns feedback keyed to exact section names, and only those
sections are regenerated. `initialize_gemini_model()` remains the single model
initializer, so judge calls share the configured Vertex project and location.

### Integration checklist

- [ ] The candidate generator creates the normal output schema before review.
- [ ] Review criteria and allowed evidence are specific to this agent.
- [ ] Every failed criterion produces corrective feedback.
- [ ] Revisions preserve the output schema and use only allowed source material.
- [ ] Revision and failure behavior are configured intentionally.
- [ ] Fail-closed failures occur before persistence.
- [ ] Existing API and stored document shapes remain unchanged.
- [ ] Logs include status only, never candidate or source contents.
- [ ] The shared package is included in local and deployed Python import paths.
