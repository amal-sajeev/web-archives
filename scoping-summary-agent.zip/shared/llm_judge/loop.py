"""Bounded review/revision orchestration without model or schema dependencies.

Callers own prompts, structured review schemas, model initialization, and candidate
generation. This module only coordinates review results and corrective revisions.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Generic, Literal, TypeVar


CandidateT = TypeVar("CandidateT")
ReviewT = TypeVar("ReviewT")
FailurePolicy = Literal["fail_open", "fail_closed"]

logger = logging.getLogger(__name__)


class ReviewLoopError(RuntimeError):
    """Raised when a review or revision fails under the fail-closed policy."""


@dataclass(frozen=True)
class ReviewLoopResult(Generic[CandidateT, ReviewT]):
    """Candidate and minimal, content-free loop status for caller observability."""

    candidate: CandidateT
    review: ReviewT | None
    approved: bool
    revisions: int
    outcome: Literal[
        "approved", "revision_limit", "no_feedback", "review_failure", "revision_failure"
    ]


def review_and_revise(
    candidate: CandidateT,
    *,
    reviewer: Callable[[CandidateT], ReviewT],
    reviser: Callable[[CandidateT, ReviewT], CandidateT],
    approved: Callable[[ReviewT], bool],
    has_feedback: Callable[[ReviewT], bool],
    stage: str,
    max_revisions: int = 1,
    failure_policy: FailurePolicy = "fail_open",
    log: logging.Logger | None = None,
) -> ReviewLoopResult[CandidateT, ReviewT]:
    """Review a candidate and make at most ``max_revisions`` corrective drafts.

    ``reviewer`` and ``reviser`` are application-provided callbacks. A returned
    candidate is therefore only as schema-valid as the caller's generator makes
    it. Keep source checks, schemas, rubrics, and model construction in the agent.

    Fail-open returns the latest candidate that was successfully generated. A
    failed revision leaves the preceding candidate intact. Fail-closed raises
    before the caller can persist the result.
    """
    active_logger = log or logger
    if max_revisions < 0:
        raise ValueError("max_revisions must be 0 or greater")
    if failure_policy not in ("fail_open", "fail_closed"):
        raise ValueError("failure_policy must be 'fail_open' or 'fail_closed'")

    revision_count = 0
    latest_review: ReviewT | None = None
    while True:
        try:
            latest_review = reviewer(candidate)
            is_approved = approved(latest_review)
            actionable_feedback = has_feedback(latest_review)
        except Exception as exc:
            active_logger.error(
                "LLM review failed stage=%s policy=%s revisions=%d error_type=%s",
                stage,
                failure_policy,
                revision_count,
                type(exc).__name__,
            )
            if failure_policy == "fail_closed":
                raise ReviewLoopError(f"LLM review failed at stage '{stage}'.") from exc
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "review_failure"
            )

        active_logger.info(
            "LLM review completed stage=%s approved=%s revisions=%d",
            stage,
            is_approved,
            revision_count,
        )
        if is_approved:
            return ReviewLoopResult(candidate, latest_review, True, revision_count, "approved")
        if not actionable_feedback:
            active_logger.warning("LLM review returned no actionable feedback stage=%s", stage)
            return ReviewLoopResult(candidate, latest_review, False, revision_count, "no_feedback")
        if revision_count >= max_revisions:
            active_logger.warning(
                "LLM review revision limit reached stage=%s revisions=%d",
                stage,
                revision_count,
            )
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_limit"
            )

        try:
            revised_candidate = reviser(candidate, latest_review)
        except Exception as exc:
            active_logger.error(
                "LLM revision failed stage=%s policy=%s revisions=%d error_type=%s",
                stage,
                failure_policy,
                revision_count,
                type(exc).__name__,
            )
            if failure_policy == "fail_closed":
                raise ReviewLoopError(f"LLM revision failed at stage '{stage}'.") from exc
            return ReviewLoopResult(
                candidate, latest_review, False, revision_count, "revision_failure"
            )
        candidate = revised_candidate
        revision_count += 1
