"""TF3 — the trade processing system.

Stands in for the system the validated record is finally posted to. There is no
API yet, so postings are held in memory and can be read back; swapping this for
the real call is a change to one function.

What gets posted is what the procedure names: the resolved ports, the third
party details, and the charges, against the Bill of Entry.

A posting is filed under the collection's own TF3 reference - the one
TradePay already carries for the payment, which every bill under that
collection shares. TF3 does not mint a second reference for a record it
already has one for; a reference is only made up here when the payment
has none at all, and the message says so.
"""

from __future__ import annotations

import threading
from datetime import datetime

_lock = threading.RLock()
_posted: dict[str, dict] = {}
_seq = 0


def post(payload: dict) -> dict:
    """Post a validated record. Returns the TF3 reference it was filed under."""
    global _seq
    required = ("billOfEntryNumber", "importer", "portOfLoading", "portOfDischarge")
    missing = [f for f in required if not payload.get(f)]
    if missing:
        return {"accepted": False,
                "message": "TF3 rejected the posting; these are required: "
                           + ", ".join(missing)}

    with _lock:
        boe = str(payload["billOfEntryNumber"])
        reference = payload.get("tf3Reference")
        if reference:
            message = f"Bill of Entry {boe} posted under TF3 {reference}."
        else:
            _seq += 1
            reference = f"TF3-{datetime.now():%Y}-{_seq:05d}"
            message = (f"Bill of Entry {boe} had no TF3 reference on the payment; "
                       f"filed as {reference}.")
        record = {
            **payload,
            "tf3Reference": reference,
            "postedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        # One collection can carry several bills, each posted on its own.
        _posted[f"{reference}/{boe}"] = record

    return {"accepted": True, "tf3Reference": reference,
            "message": message, "record": record}


def get(reference: str, boe: str | None = None) -> dict | None:
    """A posting: the bill named, or the latest under the reference."""
    if boe is not None:
        return _posted.get(f"{reference}/{boe}")
    mine = [r for k, r in _posted.items() if k.split("/", 1)[0] == reference]
    return max(mine, key=lambda r: r["postedAt"]) if mine else None


def all_postings() -> list[dict]:
    with _lock:
        return sorted(_posted.values(), key=lambda r: r["postedAt"], reverse=True)


def reset() -> None:
    """Clear the postings. Used when the demo is restarted."""
    global _seq
    with _lock:
        _posted.clear()
        _seq = 0
