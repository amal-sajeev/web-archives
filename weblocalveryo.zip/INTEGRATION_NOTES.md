# FIU worklist integration

The default FIU worklist now includes the imported Bosch Limited and Henkel Adhesive Technologies India customer batches in the existing collection table.

- Bosch Limited: 247 Bills of Entry, 364 invoices.
- Henkel Adhesive Technologies India: 228 Bills of Entry, 362 invoices.
- Each customer batch is one collection row with its Bills of Entry and invoice checks nested underneath.
- FIU and FEMA invoice check payloads remain available through the existing check-detail buttons.
- Search, importer, currency, status and sort handling are wired into the combined collection list.
- The separate FEMA customer table remains available on `/?tab=fema`. It is no longer appended under the default FIU worklist.
- Corporate classic, corporate modern and desk layouts render the combined data.

Verification performed against the bundled data:

- FastAPI route smoke tests: `/`, `/?layout=modern`, `/?v=desk`, `/?tab=fema`, customer search, importer filtering and sorted view all returned HTTP 200.
- Default FIU view: one top-level worklist table, 11 collection groups, 726 imported invoice rows, and no duplicate FEMA customer table.
- `python -m compileall` completed successfully.

Run the application from its package parent using the project's usual command, for example `uvicorn app.main:app --port 8000`.
