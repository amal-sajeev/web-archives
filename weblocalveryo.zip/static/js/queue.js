/* Queue: type to filter, and keep the processing rows moving. */

(function () {
  "use strict";
  const { api } = window.App;

  const q = document.getElementById("q");

  /* The corporate toolbar is a real form and submits natively, carrying its
     own filters and sort. Only the desk view needs the JS redirect. */
  if (q && !q.closest("form")) {
    let t;
    q.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(() => {
        // build from the current URL so the page you are on and any sort survive
        const url = new URL(location.href);
        const v = q.value.trim();
        if (v) url.searchParams.set("q", v);
        else url.searchParams.delete("q");
        location.href = url.toString();
      }, 420);
    });
    // carry the caret on only when the page came back from a search
    if (q.value) {
      q.focus();
      q.setSelectionRange(q.value.length, q.value.length);
    }
  }

  // Only poll while something is actually in flight.
  if (document.querySelector(".gauge")) {
    setInterval(async () => {
      try {
        const data = await api("GET", "/api/cases/live");
        let finished = false;
        data.cases.forEach(c => {
          const row = document.querySelector('a[href="/cases/' + c.case_id + '"] .gauge i')
                   || document.querySelector('[data-case-row="' + c.case_id + '"] .gauge i');
          if (!row) return;
          if (c.status === "ai_processing") row.style.width = c.progress + "%";
          else finished = true;
        });
        if (finished) location.reload();
      } catch (_) { /* transient */ }
    }, 2500);
  }
})();

/* The worklist groups on the TF3 reference, and a group opens onto its
 * invoices. Delegated from the table so it costs one listener however many
 * collections are on the page, and keyed on the row rather than an index, so
 * nothing has to be renumbered when the list is filtered or sorted.
 */
(function () {
  "use strict";

  function toggle(head) {
    var group = head.closest(".cgrp");
    if (!group) return;
    var open = group.classList.toggle("is-open");
    head.setAttribute("aria-expanded", String(open));
  }

  document.addEventListener("click", function (e) {
    if (!e.target.closest) return;
    var head = e.target.closest(".grid tr.cg");
    if (head && !e.target.closest("a, button")) toggle(head);
  });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Enter" && e.key !== " ") return;
    if (!e.target.closest) return;
    var head = e.target.closest(".grid tr.cg");
    if (!head) return;
    e.preventDefault();
    toggle(head);
  });
}());

/* Landing on an invoice.
 *
 * An invoice is a line of its bill rather than a thing with a page, so it
 * gets an address instead: a row id keyed on bill-of-entry-plus-number. Two
 * things arrive at one — a search whose term matched the number, which the
 * server has already marked and opened, and a link to the row's anchor,
 * which has to be opened here. Both end the same way: the collection is
 * open, the row is marked, and the page is scrolled to it.
 */
(function () {
  "use strict";

  function reveal(row) {
    if (!row) return;
    var box = row.closest("details.coll");          // the desk view
    if (box) box.open = true;
    var group = row.closest(".cgrp");               // the corporate one
    if (group) {
      group.classList.add("is-open");
      var head = group.querySelector(".cg");
      if (head) head.setAttribute("aria-expanded", "true");
    }
    row.classList.add("is-hit");
    // After the open, so the row is laid out where it will finally sit.
    requestAnimationFrame(function () {
      row.scrollIntoView({ block: "center", behavior: "smooth" });
    });
  }

  function fromHash() {
    var id = (location.hash || "").slice(1);
    if (!id || (id.indexOf("inv-") !== 0 && id.indexOf("fema-") !== 0)) return false;
    // Not a selector: an id built from a bill and an invoice number can
    // hold characters querySelector would read as syntax.
    var row = document.getElementById(id);
    if (!row) return false;
    reveal(row);
    return true;
  }

  if (!fromHash()) reveal(document.querySelector("tr.is-hit"));
  window.addEventListener("hashchange", fromHash);
}());

/* Invoice-level FIU and FEMA check details popup modal. */
(function () {
  "use strict";

  function esc(str) {
    return String(str == null ? "" : str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function fmtNum(val) {
    var n = Number(val || 0);
    return n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function openCheckPopup(btn) {
    var raw = btn.getAttribute("data-check-payload");
    if (!raw) return;
    var data;
    try {
      data = JSON.parse(raw);
    } catch (_) {
      return;
    }

    var kindEl = document.getElementById("chk-modal-kind");
    var titleEl = document.getElementById("chk-modal-title");
    var badgeEl = document.getElementById("chk-modal-badge");
    var metaEl = document.getElementById("chk-modal-meta");
    var sumEl = document.getElementById("chk-modal-summary");
    var oemsEl = document.getElementById("chk-modal-oems");
    var itemsEl = document.getElementById("chk-modal-items");

    if (!titleEl || !itemsEl) return;

    var kind = data.kind || btn.getAttribute("data-check-popup") || "CHECK";
    var passed = !!data.passed;

    if (kindEl) kindEl.textContent = kind + " INVOICE-LEVEL COMPLIANCE CHECK";
    titleEl.textContent = "Invoice " + (data.invoiceNo || "—") + " · BOE " + (data.boe || "—");

    if (badgeEl) {
      badgeEl.className = "chkbtn chkbtn--" + (passed ? "pass" : "fail");
      badgeEl.innerHTML =
        '<span class="chkbtn__sym" aria-hidden="true">' + (passed ? "✓" : "✗") + "</span>" +
        '<span class="chkbtn__txt">' + (passed ? "PASS" : "FAIL") + "</span>";
    }

    if (metaEl) {
      metaEl.innerHTML =
        "<div><span>Customer / Importer</span><b>" + esc(data.customer || "—") + "</b></div>" +
        "<div><span>Supplier / Vendor</span><b>" + esc(data.supplier || "—") + "</b></div>" +
        "<div><span>Bill of Entry</span><b>" + esc(data.boe || "—") + "</b></div>" +
        "<div><span>Invoice Value</span><b>" + esc(data.currency || "") + " " + fmtNum(data.amount) + "</b></div>";
    }

    if (sumEl) {
      sumEl.className = "chk-modal__sum chk-modal__sum--" + (passed ? "pass" : "fail");
      sumEl.textContent = data.summary || "";
    }

    if (oemsEl) {
      if (kind === "FEMA" && (data.oemsGoods || data.oemsLob || data.turnover)) {
        var to = data.turnover || {};
        oemsEl.hidden = false;
        oemsEl.innerHTML =
          '<div class="chk-oems-card">' +
            '<div class="chk-oems-card__hd">Customer Profile &amp; AI Goods / Turnover Benchmark</div>' +
            '<div class="chk-oems-card__grid">' +
              '<div><span>Invoice (Client Goods)</span><b>' + esc(data.clientGoods || "—") + '</b></div>' +
              '<div><span>Line of Business</span><b>' + esc(data.oemsLob || "—") + '</b></div>' +
              '<div><span>Approved Goods Description</span><b>' + esc(data.oemsGoods || "—") + '</b></div>' +
              '<div><span>Total Turnover (10% Cap)</span><b>INR ' + fmtNum(to.totalTurnoverInr || 0) +
                ' (Cap: INR ' + fmtNum(to.thresholdInr || 0) + ')</b></div>' +
            '</div>' +
          '</div>';
      } else {
        oemsEl.hidden = true;
        oemsEl.innerHTML = "";
      }
    }

    var items = data.items || [];
    itemsEl.innerHTML = items.map(function (it) {
      var ok = !!it.passed;
      var actSub = it.actualSub ? '<small class="chk-item__sub">' + esc(it.actualSub) + '</small>' : '';
      var expSub = it.expectedSub ? '<small class="chk-item__sub">' + esc(it.expectedSub) + '</small>' : '';
      return (
        '<div class="chk-item chk-item--' + (ok ? "pass" : "fail") + '">' +
          '<div class="chk-item__top">' +
            '<span class="chk-item__title">' + esc(it.label) + '</span>' +
            '<span class="chkbtn chkbtn--sm chkbtn--' + (ok ? "pass" : "fail") + '">' +
              '<span class="chkbtn__sym" aria-hidden="true">' + (ok ? "✓" : "✗") + '</span>' +
              '<span class="chkbtn__txt">' + (ok ? "PASS" : "FAIL") + '</span>' +
            '</span>' +
          '</div>' +
          '<div class="chk-item__cmp">' +
            '<div><span>Invoice (Client Upload)</span><b>' + esc(it.actual || "—") + '</b>' + actSub + '</div>' +
            '<div><span>Reference</span><b>' + esc(it.expected || "—") + '</b>' + expSub + '</div>' +
          '</div>' +
          (it.note ? '<p class="chk-item__note">' + esc(it.note) + '</p>' : '') +
        '</div>'
      );
    }).join("");

    if (window.App && window.App.openModal) {
      window.App.openModal("check-detail-modal");
    } else {
      var m = document.getElementById("check-detail-modal");
      if (m) m.classList.add("is-open");
    }
  }

  document.addEventListener("click", function (e) {
    if (!e.target.closest) return;
    var btn = e.target.closest("[data-check-popup]");
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();
    openCheckPopup(btn);
  });
}());
