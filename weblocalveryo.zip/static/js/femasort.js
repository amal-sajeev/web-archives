/* Sorting the FEMA view's tables in place, Wikipedia-style.
 *
 * Two shapes of table carry the FEMA data, and each sorts in the way that
 * keeps its grouping intact:
 *
 *   .fema-grid   one body per customer (a summary row plus a hidden drill
 *                row). A heading orders the customers by reordering those
 *                bodies, so a customer's drill always travels with it.
 *
 *   .lines--inv  one body per bill of entry, the bill's own cell spanning
 *                its invoices. Ordering the bill column orders the bills;
 *                ordering any other column orders the invoices inside each
 *                bill, so an invoice never leaves the bill it belongs to.
 *
 * Every heading is a button. The one in charge carries aria-sort, and
 * clicking it again turns the order round. A cell may name its own sort key
 * with data-sort-value (a number, a name, or an ISO date), which is used in
 * preference to the text the reader sees; otherwise the text is read and
 * coerced to the column's data-kind. It is all done in place: no request, no
 * URL, and it behaves the same frozen as served.
 */
(function () {
  "use strict";

  function parseDate(text) {
    var s = (text || "").trim();
    var m = /(\d{4})-(\d{2})-(\d{2})/.exec(s);          /* YYYY-MM-DD */
    if (m) return Number(m[1] + m[2] + m[3]);
    m = /(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})/.exec(s); /* DD-MM-YYYY */
    if (m) {
      var d = ("0" + m[1]).slice(-2), mo = ("0" + m[2]).slice(-2);
      return Number(m[3] + mo + d);
    }
    return 0;
  }

  function cellValue(cell, kind) {
    if (!cell) return kind === "num" || kind === "date" ? 0 : "";
    var raw = cell.getAttribute && cell.getAttribute("data-sort-value");
    var text = raw !== null && raw !== undefined
      ? String(raw)
      : (cell.textContent || "").replace(/\s+/g, " ").trim();
    if (kind === "num") {
      var m = /-?[\d,]+(?:\.\d+)?/.exec(text);
      return m ? parseFloat(m[0].replace(/,/g, "")) : 0;
    }
    if (kind === "date") return parseDate(text);
    return text.toLowerCase();
  }

  function compare(dir, kind) {
    return function (a, b) {
      var c = 0;
      if (kind === "num" || kind === "date") {
        c = a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
      } else {
        c = String(a.key).localeCompare(String(b.key), undefined, { numeric: true, sensitivity: "base" });
      }
      if (dir === "descending") c = -c;
      return c || a.index - b.index;        /* a tie keeps the order it had */
    };
  }

  /* The customer grid: reorder the per-customer bodies by their summary row,
     or restore their initial order when returning to the default state. */
  function sortGrid(table, col, kind, dir) {
    var bodies = Array.prototype.slice.call(table.tBodies)
      .filter(function (b) { return b.classList.contains("cgrp"); });
    bodies.forEach(function (body, idx) {
      if (!body.hasAttribute("data-orig-index")) {
        body.setAttribute("data-orig-index", String(idx));
      }
    });
    if (dir === "default") {
      bodies.sort(function (a, b) {
        return Number(a.getAttribute("data-orig-index")) - Number(b.getAttribute("data-orig-index"));
      });
      bodies.forEach(function (b) { table.appendChild(b); });
      return;
    }
    var keyed = bodies.map(function (body, index) {
      var head = body.querySelector("tr.cg");
      var orig = Number(body.getAttribute("data-orig-index"));
      return { body: body, index: isNaN(orig) ? index : orig, key: cellValue(head ? head.cells[col] : null, kind) };
    });
    keyed.sort(compare(dir, kind));
    keyed.forEach(function (k) { table.appendChild(k.body); });
  }

  /* Extract all invoice rows from the table into a flat list with their BOE
     metadata and original sequence index. */
  function extractAllInvoices(table) {
    var bodies = Array.prototype.slice.call(table.tBodies);
    var items = [];
    var seq = 0;
    bodies.forEach(function (body) {
      var boe = body.getAttribute("data-boe") || "";
      var boeDate = body.getAttribute("data-boe-date") || "";
      var rows = Array.prototype.slice.call(body.rows);
      rows.forEach(function (row) {
        if (!row.getAttribute("data-boe")) row.setAttribute("data-boe", boe);
        if (!row.getAttribute("data-boe-date")) row.setAttribute("data-boe-date", boeDate);
        if (!row.hasAttribute("data-orig-index")) row.setAttribute("data-orig-index", String(seq));
        seq += 1;
        items.push({
          row: row,
          boe: row.getAttribute("data-boe") || boe,
          boeDate: row.getAttribute("data-boe-date") || boeDate,
          origIndex: Number(row.getAttribute("data-orig-index"))
        });
      });
    });
    return items;
  }

  /* Rebuild tbody.boe elements from an ordered list of invoice items, grouping
     consecutive rows that share a BOE into one tbody. */
  function rebuildLinesTable(table, orderedItems) {
    var oldBodies = Array.prototype.slice.call(table.tBodies);
    oldBodies.forEach(function (b) {
      if (b.parentNode === table) table.removeChild(b);
    });

    var runs = [];
    orderedItems.forEach(function (item) {
      var last = runs[runs.length - 1];
      if (last && last.boe === item.boe) {
        last.items.push(item);
      } else {
        runs.push({ boe: item.boe, boeDate: item.boeDate, items: [item] });
      }
    });

    runs.forEach(function (run) {
      var tbody = document.createElement("tbody");
      tbody.className = "boe";
      tbody.setAttribute("data-boe", run.boe);
      tbody.setAttribute("data-boe-date", run.boeDate);
      run.items.forEach(function (it) {
        tbody.appendChild(it.row);
      });
      table.appendChild(tbody);
    });
  }

  /* The invoice lines: sort across ALL invoices of the customer, or restore
     the original order when returning to the default state. */
  function sortLines(table, col, kind, dir) {
    var all = extractAllInvoices(table);
    if (!all.length) return;

    if (dir === "default") {
      all.sort(function (a, b) { return a.origIndex - b.origIndex; });
      rebuildLinesTable(table, all);
      return;
    }

    var keyed = all.map(function (item) {
      var cell = item.row.cells[col];
      return { item: item, index: item.origIndex, key: cellValue(cell, kind) };
    });
    keyed.sort(compare(dir, kind));
    rebuildLinesTable(table, keyed.map(function (k) { return k.item; }));
  }

  document.addEventListener("click", function (e) {
    if (!e.target.closest) return;
    var th = e.target.closest(".fema-grid thead th, .fema-board .lines--inv thead th");
    if (!th) {
      var btn = e.target.closest("button.femasort");
      if (btn) th = btn.closest("th");
    }
    if (!th) return;
    var table = th.closest("table");
    if (!table || !table.tBodies.length) return;
    e.preventDefault();
    e.stopPropagation();

    var current = th.getAttribute("aria-sort");
    var dir;
    if (current === "ascending") {
      dir = "descending";
    } else if (current === "descending") {
      dir = "default";
    } else {
      dir = "ascending";
    }

    var heads = th.parentNode.children;
    for (var i = 0; i < heads.length; i++) heads[i].removeAttribute("aria-sort");
    if (dir !== "default") {
      th.setAttribute("aria-sort", dir);
    }

    var kind = th.getAttribute("data-kind") || "text";
    if (table.classList.contains("fema-grid")) sortGrid(table, th.cellIndex, kind, dir);
    else sortLines(table, th.cellIndex, kind, dir);
  });
}());
