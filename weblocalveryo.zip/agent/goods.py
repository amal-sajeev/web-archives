"""AI Goods Verification Agent — compares client Goods Description against OEMS.

Checks whether the goods description (or ITC-HS tariff code) shared by the
client on an invoice accurately matches that client's OEMS Line of Business and
OEMS General Goods annexure. If the goods description is missing or shows a
shift outside the client's established OEMS profile, the agent flags it as an
area of concern to be raised with the client for context.

Follows the same provider cascade as ``app/agent/pricing.py``:
  1. In-memory cache of evaluated (customer, client_goods, oems_lob) tuples
  2. Live LLM provider via ``app/agent/providers.py`` when configured
  3. Deterministic semantic + ITC-HS tariff classifier with full reasoning steps
"""

from __future__ import annotations

import json
import re
import threading
from typing import Any

from . import providers

_GOODS_CACHE: dict[tuple[str, str, str], dict[str, Any]] = {}
_GOODS_LOCK = threading.Lock()

SYSTEM_PROMPT = """\
You are a Trade Finance compliance analyst in India performing FEMA and FIU \
goods verification.

Given:
1. Importer / Customer Name
2. OEMS Line of Business (from the bank's OEMS customer profile)
3. OEMS General Goods List (from the customer's approved OEMS annexure)
4. Client's declared Goods Description on the current invoice (text or 8-digit ITC-HS code)

Decide whether the client's declared goods accurately match the client's OEMS \
Line of Business and General Goods profile, or whether there is a sudden shift \
in goods that must be raised with the client for more information and context.

Reply with one JSON object:
{
  "passed": true,
  "client_goods_interpreted": "human-readable description of the client's goods",
  "matched_oems_goods": "the matching OEMS goods category or null",
  "shift_detected": false,
  "confidence": "high | medium | low",
  "reasoning": "clear 1-2 sentence explanation referencing the OEMS Line of Business and OEMS Goods list"
}
"""

# Indian Customs Tariff (ITC-HS) 8-digit schedule lookup for machine-readable
# customs codes submitted in TradePay.
ITC_HS_SCHEDULE: dict[str, dict[str, Any]] = {
    "40094200": {
        "chapter": "Chapter 40 (Rubber and articles thereof)",
        "description": "Tubes, pipes and hoses of vulcanised rubber, reinforced or combined with other materials, with fittings",
        "domain": "hydraulics_hoses",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Hydraulic Equipment / Auto Ancillary",
        "match_reason": (
            "ITC-HS 40094200 is reinforced vulcanised-rubber hose supplied WITH FITTINGS — i.e. a finished "
            "hydraulic/pneumatic hose assembly with end connectors, not raw rubber stock. Although it sits in "
            "Chapter 40, the fitted-assembly subheading is a recognised auto-ancillary / hydraulic component that "
            "reconciles with Bosch Limited's OEMS Line of Business ('Auto Ancillary, Hydraulic Equipment') and its "
            "fuel/hydraulic systems annexure. Only unfitted raw rubber hose or sheet (e.g. 40091100 / 40093100) "
            "would represent a shift outside the OEMS profile."
        ),
    },
    "73181500": {
        "chapter": "Chapter 73 (Articles of iron or steel)",
        "description": "Threaded screws and bolts of iron or steel, whether or not with their nuts or washers",
        "domain": "fasteners_auto_ancillary",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Auto Ancillary / Power Tools and Parts",
    },
    "84099120": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Fuel nozzles for spark-ignition internal combustion piston engines",
        "domain": "fuel_injection",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Fuel Injection Equipment and Parts",
    },
    "84099199": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Other parts suitable for use solely or principally with spark-ignition IC engines",
        "domain": "fuel_injection",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Fuel Injection Equipment and Parts",
    },
    "84099990": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Other parts for compression-ignition (diesel or semi-diesel) internal combustion engines",
        "domain": "fuel_injection",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Fuel Injection Equipment and Parts",
    },
    "84133030": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Injection pumps for diesel internal combustion piston engines",
        "domain": "fuel_injection",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Fuel Injection Equipment and Parts",
    },
    "84133090": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Fuel, lubricating or cooling medium pumps for internal combustion piston engines",
        "domain": "fuel_injection",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Fuel Injection Equipment and Parts",
    },
    "84135010": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Metering and dosing reciprocating positive displacement pumps",
        "domain": "hydraulics_pumps",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Hydraulic Equipment / Fuel Injection Equipment and Parts",
    },
    "84135090": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Other reciprocating positive displacement hydraulic liquid pumps",
        "domain": "hydraulics_pumps",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Hydraulic Equipment / Fuel Injection Equipment and Parts",
    },
    "84136010": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Gear type rotary positive displacement hydraulic pumps",
        "domain": "hydraulics_pumps",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Hydraulic Equipment",
    },
    "84139190": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Parts of liquid pumps and fuel/hydraulic pumping assemblies",
        "domain": "fuel_injection",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Fuel Injection Equipment and Parts",
    },
    "84818090": {
        "chapter": "Chapter 84 (Machinery and mechanical appliances)",
        "description": "Industrial taps, cocks, valves and pressure-control appliances for pipes and hydraulic systems",
        "domain": "hydraulics_valves",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Hydraulic Equipment / Special Purpose machines and parts",
    },
    "87089900": {
        "chapter": "Chapter 87 (Vehicles and automotive parts & accessories)",
        "description": "Parts and accessories of motor vehicles (auto ancillary components)",
        "domain": "auto_ancillary",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Auto Ancillary / Fuel Injection Equipment and Parts",
    },
    "90268090": {
        "chapter": "Chapter 90 (Measuring, checking and precision instruments)",
        "description": "Instruments and sensors for measuring or checking flow, level or pressure of liquids or gases",
        "domain": "sensors_precision",
        "matches_machinery_annexure": True,
        "matched_oems_category": "Special Purpose machines and parts / Fuel Injection Equipment",
    },
}


def evaluate_goods(
    importer: str,
    client_goods: str | None,
    oems_profile: dict[str, Any],
    *,
    allow_live_llm: bool = False,
) -> dict[str, Any]:
    """Compare client-declared goods against the customer's OEMS profile."""
    lob = " ".join(str(oems_profile.get("business_description") or "").split())
    oems_goods_list = [str(x).strip() for x in (oems_profile.get("goods_description") or []) if str(x).strip()]
    oems_summary = "; ".join(oems_goods_list[:4])
    if len(oems_goods_list) > 4:
        oems_summary += f" (+{len(oems_goods_list) - 4} approved OEMS items)"

    raw_goods = str(client_goods or "").strip()
    if raw_goods.endswith(".0") and raw_goods[:-2].isdigit():
        raw_goods = raw_goods[:-2]

    cache_key = (importer.strip().upper(), raw_goods, lob)
    with _GOODS_LOCK:
        if cache_key in _GOODS_CACHE:
            return _GOODS_CACHE[cache_key]

    result = _run_goods_evaluation(importer, raw_goods, lob, oems_goods_list, oems_summary, oems_profile, allow_live_llm=allow_live_llm)
    with _GOODS_LOCK:
        _GOODS_CACHE[cache_key] = result
    return result


def _run_goods_evaluation(
    importer: str,
    raw_goods: str,
    lob: str,
    oems_goods_list: list[str],
    oems_summary: str,
    oems_profile: dict[str, Any],
    *,
    allow_live_llm: bool = False,
) -> dict[str, Any]:
    # Case 1: Missing client goods description in TradePay
    if not raw_goods:
        return {
            "passed": False,
            "status": "FAIL",
            "clientGoods": "Not provided on TradePay",
            "oemsLob": lob or "Standard manufacturing",
            "oemsGoods": oems_summary or "—",
            "matchedOemsItem": None,
            "shiftDetected": True,
            "provider": "ai-goods-classifier",
            "reasoning": (
                f"Client did not supply a Goods Description on the TradePay record for this invoice. "
                f"Cannot verify alignment against {importer}'s OEMS Line of Business ('{lob}') or "
                f"OEMS Goods ('{oems_summary}'). Raise query with client for goods description."
            ),
        }

    # Case 2: 8-digit ITC-HS Customs Tariff Code
    if raw_goods in ITC_HS_SCHEDULE:
        hs = ITC_HS_SCHEDULE[raw_goods]
        passed = bool(hs["matches_machinery_annexure"])
        if passed:
            reasoning = hs.get("match_reason") or (
                f"AI Goods Classifier decoded ITC-HS {raw_goods} as '{hs['description']}' ({hs['chapter']}). "
                f"Semantically matches OEMS category '{hs['matched_oems_category']}' under {importer}'s "
                f"OEMS Line of Business ('{lob}'). No shift in goods."
            )
        else:
            reasoning = hs.get("shift_reason") or (
                f"AI Goods Classifier decoded ITC-HS {raw_goods} as '{hs['description']}' ({hs['chapter']}), "
                f"which falls outside {importer}'s OEMS Goods Annexure. Raise with client for context."
            )
        return {
            "passed": passed,
            "status": "PASS" if passed else "FAIL",
            "clientGoods": f"HS {raw_goods} — {hs['description']}",
            "oemsLob": lob,
            "oemsGoods": oems_summary,
            "matchedOemsItem": hs.get("matched_oems_category"),
            "shiftDetected": not passed,
            "provider": "ai-goods-classifier",
            "reasoning": reasoning,
        }

    # Case 3: Optional live LLM provider if requested and available
    if allow_live_llm:
        prov, _ = providers.resolve()
        if prov is not None:
            prompt = (
                f"Customer: {importer}\n"
                f"OEMS Line of Business: {lob}\n"
                f"OEMS General Goods (sample): {'; '.join(oems_goods_list[:20])}\n"
                f"Client Declared Goods on Invoice: {raw_goods}\n"
            )
            comp = prov.complete(SYSTEM_PROMPT, prompt, max_tokens=512)
            if comp.ok:
                try:
                    parsed = json.loads(comp.text.strip().strip("`").removeprefix("json").strip())
                    passed = bool(parsed.get("passed", True))
                    return {
                        "passed": passed,
                        "status": "PASS" if passed else "FAIL",
                        "clientGoods": parsed.get("client_goods_interpreted") or raw_goods,
                        "oemsLob": lob,
                        "oemsGoods": oems_summary,
                        "matchedOemsItem": parsed.get("matched_oems_goods"),
                        "shiftDetected": bool(parsed.get("shift_detected", not passed)),
                        "provider": f"{comp.provider}:{comp.model}",
                        "reasoning": parsed.get("reasoning") or "",
                    }
                except Exception:
                    pass

    # Case 4: Semantic token & domain alignment against OEMS Line of Business and OEMS Goods list
    lower_g = raw_goods.lower()
    lob_lower = lob.lower()
    client_tokens = [tok for tok in re.findall(r"[a-z]{4,}", lower_g) if tok not in {"for", "with", "from", "part", "parts"}]

    # Check direct substring or token overlap with OEMS Line of Business
    lob_matches = [tok for tok in client_tokens if tok in lob_lower]

    # Check overlap with OEMS Goods Annexure items
    matched_annexure: list[str] = []
    for item in oems_goods_list:
        item_low = item.lower()
        if lower_g in item_low or item_low in lower_g or any(tok in item_low for tok in client_tokens):
            matched_annexure.append(item)

    # Check domain keywords from profile if present
    domain_keywords = [str(k).lower() for k in (oems_profile.get("keywords") or [])]
    kw_hits = [kw for kw in domain_keywords if kw in lower_g]

    passed = bool(lob_matches or matched_annexure or kw_hits)
    if passed:
        if matched_annexure:
            match_note = f"Matches OEMS goods schedule item '{matched_annexure[0]}'"
            if len(matched_annexure) > 1:
                match_note += f" (+{len(matched_annexure) - 1} related OEMS items)"
        elif lob_matches:
            match_note = f"Directly aligns with OEMS Line of Business terms ({', '.join(sorted(set(lob_matches)))})"
        else:
            match_note = f"Matches OEMS domain profile ({', '.join(kw_hits[:3])})"

        # Show OEMS goods description alongside client goods
        display_goods = f"{raw_goods} (OEMS: {oems_goods_list[0]})" if oems_goods_list and raw_goods.lower() != oems_goods_list[0].lower() else raw_goods
        reasoning = (
            f"AI Goods Check verified client declaration '{raw_goods}' against {importer}'s OEMS Line of Business "
            f"('{lob[:120]}'). {match_note}. No sudden shift in goods detected."
        )
    else:
        display_goods = raw_goods
        reasoning = (
            f"AI Goods Check flagged '{raw_goods}': does not match {importer}'s OEMS Line of Business "
            f"('{lob[:120]}') or OEMS Goods Annexure ({oems_summary[:100]}). "
            "Sudden shift in goods — raise query with client for business justification and end-use context."
        )

    return {
        "passed": passed,
        "status": "PASS" if passed else "FAIL",
        "clientGoods": display_goods,
        "oemsLob": lob,
        "oemsGoods": oems_summary,
        "matchedOemsItem": matched_annexure[0] if matched_annexure else None,
        "shiftDetected": not passed,
        "provider": "ai-goods-classifier",
        "reasoning": reasoning,
    }
