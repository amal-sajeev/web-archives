# The pricing agent

The charge instruction held against a client in Autobahn is prose, written by
relationship managers over several years. It is not a rate card, and it is not
consistent:

```
Import Payment: INR 450 per document
Pricing to be levied at remittance level as
per approvals from Gaurav dtd 21.01.2019
```

Those two lines are different instructions. This remittance covers three
invoices, so "per document" is INR 1,350 and "at remittance level" is INR 450.
A regular expression picks one silently. The agent notices the conflict, prices
the lower reading, states what the other would cost, and marks the case for a
human — which is the behaviour an audit expects.

The agent's reasoning is kept on the case and opens from the charges card:
the instruction it read, the numbered argument, the exact words behind each
decision, where it hedged, what it deliberately did not charge, and every
figure re-computed independently.

## What the agent decides, and what the code decides

The split matters, because arithmetic should not be delegated to a language
model and prose should not be delegated to a regex.

| | Decided by |
|---|---|
| What the instruction prices, and at what rate | the agent |
| The charging basis, and how many units this consignment makes | the agent |
| Whether the instruction contradicts itself | the agent |
| What is provenance rather than pricing (approval notes, master numbers) | the agent |
| Every multiplication and total | the code |
| The forex conversion clause | the code, from the published tiers |
| GST | the code |

The agent is also asked for its own figure, and the two are compared. A
disagreement is reported on the case, and the computed figure is the one
charged. Each quote the agent relies on is checked against the instruction
text, and each rate against the numbers the text actually contains — so a
fabricated rate shows up as a failed check rather than a charge.

The forex clause is computed here rather than read, because it is a published
tier table. The agent is shown the result and may object; an objection is
recorded and marks the case for a human. It earned that: the first run against
real data objected that the fee applied 0.5% to the whole gross when the clause
charges it only on the amount above one lakh. It was right, and the calculation
was fixed.

## Model backends

Four, tried in order. `GET /api/agent/status` reports which one is live and why
the others were skipped; the same thing is shown on the **Client pricing** page.

| Order | Backend | Role |
|---|---|---|
| 1 | Gemini on Vertex AI | the deployment target |
| 2 | the Anthropic API | used when `ANTHROPIC_API_KEY` is set |
| 3 | the `claude` CLI | local testing; carries its own auth, needs no key |
| 4 | pattern rules | no model at all, labelled as such on every case |

`PRICING_AGENT_PROVIDER` pins one (`vertex`, `anthropic`, `claude-cli` or
`rules`). The fourth tier never presents itself as reasoning: the case says the
instruction was matched by pattern rather than read, and asks for confirmation.

## Vertex AI with Workload Identity Federation

This follows the pattern the evaluation service already uses in this estate
(its `docs/VERTEX_INTEGRATION.md`), so one credential setup serves both.

**No credential file is read by this code.** `GOOGLE_APPLICATION_CREDENTIALS`
points at a WIF *credential configuration* — an `external_account` file that
tells google-auth to read a local JWT, exchange it at Google's STS endpoint and
impersonate a service account. `google.auth.default()` does all of that itself,
and no long-lived key material exists anywhere.

```bash
PROJECT_NAME=db-dev-46jr-mp-cta-analytics        # the project Vertex is called in
PROJECT_LOCATION=us-central1
GOOGLE_APPLICATION_CREDENTIALS=.../wif-file-based.json
PRICING_AGENT_MODEL=gemini-2.5-pro               # optional, this is the default
```

`PROJECT_NAME`, `PROJECT_LOCATION` and `GOOGLE_APPLICATION_CREDENTIALS` are
deliberately the same names the evaluation service uses — they are per-environment
GCP settings and should be shared. The model is **not**: `JUDGE_MODEL` belongs to
that service and is already set to something else on developer machines, so this
reads `PRICING_AGENT_MODEL` instead.

Behind the corporate proxy, Google traffic (Azure AD, Google STS, IAM Credentials
and Vertex) also needs the internal CA bundle, or the TLS handshake fails before
any of this is reached:

```bash
SSL_CERT_FILE=.../cacert.crt
REQUESTS_CA_BUNDLE=.../cacert.crt
```

The WIF JWT is short-lived and regenerated on a schedule by the estate's existing
tooling; google-auth picks up the refreshed file on its own.

Locally, the same ADC path is satisfied by a gcloud login instead:

```powershell
gcloud auth application-default login
gcloud auth application-default set-quota-project <project-id>
```

### Two deliberate guards

**The project must be set.** Without it the Google libraries quietly fall back to
the Gemini Developer API and fail complaining about a missing API key, which
sends you looking in entirely the wrong place.

**Credentials are resolved before the client is built.** `google-genai` resolves
them early in `BaseApiClient.__init__` but assigns `_async_httpx_client` late, so
a credentials failure leaves a half-built object whose `__del__` raises
`AttributeError: 'BaseApiClient' object has no attribute '_async_httpx_client'`.
Checking up front turns that into a message that says what to do.

### Knowing which credential actually answered

`GET /api/agent/status` reports the credential **class name**, which is the one
string that tells you whether WIF is really in play:

| Class | Means |
|---|---|
| `IdentityPoolCredentials`, `ExternalAccountCredentials` | Workload Identity Federation |
| `Credentials` | a developer's gcloud login |
| `ServiceAccountCredentials` | a service-account key file |

The **Client pricing** page shows the same thing. Without it, a deployment can
sit quietly on somebody's personal gcloud login and nobody would know.

Resolution is cached for 300 seconds so a rotated or revoked credential is
noticed without an ADC lookup per call. Failures are never cached, so fixing
credentials takes effect on the next request.

## Caching

A model call takes seconds, and the agent's decision depends only on the
instruction text and how many documents the remittance covers — not on the
rupee value, which feeds only the forex clause and is computed locally. So the
reading is cached on (client, document count) and the money is worked out per
case. The **Read the instruction again** button bypasses the cache, and the
trace says whether a reading was reused.
