# Trade portal screenshot reference bundle

## What is included

- `screenshots/raw/`: all 19 original embedded PNG screenshots, extracted without altering the pixels.
- `screenshots/stitched/`: 11 case-level composites. Related screenshot panels are grouped under a common case ID and labeled with their source screenshot IDs and Excel anchors.
- `case_index.json`: primary machine-readable index, raw screenshot inventory, source cell references, IDPMS row links, match rationale, amount checks, and review flags.
- `idpms_records.json`: all 22 IDPMS transaction rows, preserving source field names and raw values, with separate ISO-normalized date fields where a date could be safely interpreted.
- `idpms_records.csv`: flat table of the source IDPMS columns. Raw date values are preserved here.
- `case_linkage.csv`: compact case-to-IDPMS crosswalk.
- `source_workbooks/`: the four supplied source workbooks, retained for audit.
- `review/case_overview.png`: thumbnails of the stitched composites.

## Important joins

1. Prefer invoice number plus importer/IE name. Validate with BoE number, BoE date, port, currency, and amount.
2. For multi-invoice remittances, use only the explicit IDPMS Excel rows listed in `primary_idpms_excel_rows`; do not attach every invoice under a similarly named importer or BoE.
3. Keep primary transaction links separate from company-profile context. Scenario 3 screenshots are customer configuration notes, not transaction evidence.
4. Keep raw IDs and names. Normalize punctuation, whitespace, corporate suffix variations, and known numeric prefixes only for comparison.
5. Never join by BoE number alone. BoE `9152082` occurs for Hella and Rothe Erde with different dates and ports.
6. Any `amount_validation.status` containing `conflict` requires manual review. Do not overwrite the source value.

## High-priority review item

Putzmeister invoice `2025XYW65` is displayed in Scenario 2 as `15,255.93 EUR` (dated 20-11-2025), while IDPMS Excel row 23 records `486 USD` for the same invoice number and importer. The same IDPMS row contains suspicious values `14911.43` in `sellerAddress` and `CNY` in `sellerCountry`. The bundle preserves both versions and flags this as a data conflict.

## Other reconciliation notes

- Symrise: portal/scenario amount `11,699.72 SGD` equals IDPMS invoice amount `11,619.72 SGD` plus `80 SGD` miscellaneous charges.
- Rothe Erde: nine screenshot-listed invoices total exactly `4,027,521 CNY`; IDPMS rows 3 and 10 contain sibling invoices `HAILU202611042` and `HAILU202611043` that are not present in the screenshot batch and are excluded from that sum.
- Bosch Rexroth: invoice `60075468` for `300 EUR` is the exact transaction. IDPMS row 15 invoice `60075467` for `403 EUR` shares BoE `3079950` but is a separate invoice and not included in this transaction.
- Bosch Automotive Electronics India: IDPMS rows 19 and 20 total `2,489.20 SGD`.
- Sigma Aldrich: IDPMS rows 21 and 22 total `5,816 USD`.

## Parsing entry point

Start with `case_index.json`. For a case, read `source_images` / `source_image_files`, inspect the `stitched_image`, then load the IDPMS rows listed in `primary_idpms_excel_rows`. The row numbers are 1-based Excel row numbers, including the header at row 1.
