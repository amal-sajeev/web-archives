/* The snapshot shim.
 *
 * This build is the application rendered once, as a folder of files. Reading
 * works exactly as it does on the server; writing cannot, because there is no
 * server to write to. Rather than let a click fail on a request that will
 * never be answered, the API helper is replaced here with one that says what
 * this build is. It has to load before each page own script, which takes its
 * copy of the helper the moment it runs.
 *
 * Searching and filtering move into the page for the same reason: a GET form
 * in a folder of files lands on the file and drops what was typed.
 */
(function () {
  "use strict";
  if (!window.App) return;

  var SAYS = "This is a saved copy of the workbench. It shows the finished "
           + "state of every case; validating, approving and raising queries "
           + "need the live service.";

  /* Reads are the live poll, which has nothing to poll and is already caught
     by its caller. Only a write is worth interrupting someone over. */
  window.App.api = function (method) {
    if (String(method).toUpperCase() !== "GET") {
      window.App.toast("info", "Saved copy", SAYS);
    }
    return Promise.reject(new Error(SAYS));
  };

  document.addEventListener("DOMContentLoaded", function () {
    var writes = "[data-run-all],[data-reset],[data-approve],[data-return],"
               + "[data-query],[data-answer],[data-start],[data-switch-role],"
               + "#validate-btn,.review__box input,#agree,#agree2";
    document.querySelectorAll(writes).forEach(function (el) {
      el.disabled = true;
      el.title = SAYS;
    });

    /* The page own scripts bind at parse time, before this runs. Replacing a
       control with a copy of itself is how their listeners come off it. */
    function fresh(el) {
      if (!el || !el.parentNode) return el;
      var copy = el.cloneNode(true);
      el.parentNode.replaceChild(copy, el);
      return copy;
    }

    var box = fresh(document.getElementById("q"));
    var selects = [];
    /* Importer and currency can be answered by reading the rows. Status is
       held as a case state that the markup never spells out, and sort is the
       server own ordering; a control that quietly does nothing is worse than
       one that says it cannot, so those two are turned off rather than
       bound to a pass that would ignore them. The desk orderings are links,
       and every one of them is a page in this build, so they still work. */
    document.querySelectorAll("form.sift select, form.toolbar select")
      .forEach(function (s) {
        s = fresh(s);
        s.removeAttribute("onchange");
        if (s.name === "status" || s.name === "sort") {
          s.disabled = true;
          s.title = "Not available in a saved copy — the live service does "
                  + "this ordering.";
          return;
        }
        s.addEventListener("change", sift);
        selects.push(s);
      });
    document.querySelectorAll("form.sift, form.toolbar").forEach(function (f) {
      f.addEventListener("submit", function (e) { e.preventDefault(); sift(); });
    });
    if (box) {
      box.addEventListener("input", sift);
      box.addEventListener("search", sift);
    }

    function chosen(name) {
      var el = selects.filter(function (s) { return s.name === name; })[0];
      return el && el.value && el.value !== "all" ? el.value.toLowerCase() : "";
    }

    /* One pass over the collections: hide the ones that do not answer, open
       the ones that do, and mark the invoice row that was asked for. */
    function sift() {
      var term = ((box && box.value) || "").trim().toLowerCase();
      var importer = chosen("importer"), currency = chosen("currency");
      var shown = 0;

      document.querySelectorAll("details.coll, tbody.cgrp").forEach(function (g) {
        var text = (g.textContent || "").toLowerCase();
        var ok = (!term || text.indexOf(term) !== -1)
              && (!importer || text.indexOf(importer) !== -1)
              && (!currency || text.indexOf(currency) !== -1);
        g.hidden = !ok;
        if (!ok) return;
        shown += 1;

        var hit = false;
        g.querySelectorAll("tr[id^='inv-']").forEach(function (row) {
          var cell = row.querySelector("td.ref");
          var on = !!term && !!cell
                && cell.textContent.toLowerCase().indexOf(term) !== -1;
          row.classList.toggle("is-hit", on);
          hit = hit || on;
        });
        if (hit) {
          if (g.tagName === "DETAILS") g.open = true;
          else g.classList.add("is-open");
        }
      });

      /* A band heading with nothing under it is worse than no heading. */
      document.querySelectorAll("section.book").forEach(function (s) {
        s.hidden = !s.querySelector("details.coll:not([hidden])");
      });
      var blank = document.querySelector(".nothing, .blank");
      if (blank && (term || importer || currency)) blank.hidden = shown !== 0;

      /* The count in the heading was written by the server for the whole
         book. Narrowed here, it would stand over a shorter list saying a
         number that is no longer true. */
      var head = document.querySelector(".lede h1, .panel__hd h2");
      if (head) {
        if (!head.dataset.said) head.dataset.said = head.textContent;
        head.textContent = (term || importer || currency)
          ? shown + (shown === 1 ? " collection" : " collections") + " shown"
          : head.dataset.said;
      }
    }
  });
}());
