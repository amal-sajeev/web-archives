# Trade Collections — saved copy

A browsable snapshot of the Maker Workbench. Every page is a file, every link
is relative, and nothing is fetched from anywhere, so it runs from a folder on
disk or from any static host.

## Looking at it

Open `index.html`. It opens the corporate view; `Desk view` in the top right
crosses to the other one, and both show the same book.

## Putting it on GitHub Pages

Commit this folder to a repository and point Pages at it:

* **Settings -> Pages -> Build and deployment**, source *Deploy from a branch*
* pick the branch, and the folder this file is in

The site is then at `https://<user>.github.io/<repo>/`. `.nojekyll` is here
so Pages serves the files as they are rather than running them through Jekyll.

## What works, and what does not

Reading works throughout: the worklist, opening a collection onto its
invoices, every case with its checks and its charges, the counterparty map,
the port directory, the client pricing, the checks and the three source
workbooks. Searching and filtering the worklist work, in the page.

Writing does not, because there is no service behind it. Validating,
approving, resolving a check and raising a query are disabled, and say so.
The state shown is the state the pipeline finished in when this was built:
12 consignments in 9 collections, 57 checks passed,
10 failed and 6 unable to run.

Built 2026-10-09 from the application in this repository, by `tools/freeze.py`.
