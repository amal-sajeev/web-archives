"""Produce a Vertex-only copy of the project.

The agent ships with three model backends and a deterministic fallback. Only
Vertex is usable in a deployed environment; the other two exist so the agent can
be developed and tested on a laptop. This writes out a copy with those two
removed — source, dependencies, configuration and documentation — leaving
Vertex and the no-model rules fallback.

    .venv\\Scripts\\python tools\\vertex_only.py ..\\trademo-vertex

The original is never modified, so the local development setup keeps working.
The script verifies its own output: if a single mention survives anywhere in the
copy, it says so and exits non-zero rather than leaving you to find out later.
"""

from __future__ import annotations

import argparse
import pathlib
import re
import shutil
import sys

SKIP_DIRS = {".venv", "__pycache__", ".git", "node_modules", ".pytest_cache",
             ".ruff_cache"}
SKIP_EXT = {".pyc", ".pyo", ".zip"}
SKIP_NAMES = {".env"}
# This script names both backends on every other line; it has no business in a
# copy that is meant not to mention them.
SKIP_RELATIVE = {"tools/vertex_only.py"}

# Files that are expected to mention the other backends and are rewritten below.
# Anything else that mentions them is a surprise and is reported.
REWRITTEN = {
    "app/agent/providers.py", "app/api.py", "requirements.txt",
    "README.md", "docs/pricing-agent.md", ".env.example",
}

PROVIDERS_DOC = '''"""Where the pricing agent\'s thinking actually happens.

    vertex  Gemini on Vertex AI, authenticated by Application Default
            Credentials — Workload Identity Federation in a deployed
            environment, a gcloud login locally.
    rules   No model at all: the regex reading. Clearly labelled as such, so a
            trace can never be mistaken for reasoning that did not happen.

Selection is overridable with PRICING_AGENT_PROVIDER. Nothing here raises on a
missing dependency — an unavailable provider reports itself unavailable, and
the rules fallback takes over and says so on every case.
"""
'''

SELECTION = '''ORDER = ["vertex"]

_BUILDERS = {"vertex": VertexGemini}
'''

API_DOC = '''    """Whether the pricing agent can reach Vertex, and why not if it cannot.

    With Vertex unavailable the charge instruction is matched by pattern
    instead of read, and every case says so rather than presenting a pattern
    match as reasoning.
    """
'''


def rewrite_providers(text: str) -> str:
    # module docstring
    text = text[text.index('"""', text.index('"""') + 3) + 4:]
    text = PROVIDERS_DOC + text

    # Each class sits under a three-line banner comment. Cut from the start of
    # that banner to the start of the next one, so no orphan heading is left.
    for cls in ("AnthropicAPI", "ClaudeCLI"):
        marker = f"class {cls}(Provider):"
        rule = "# " + "-" * 75
        # The banner is three lines — rule, title, rule — so walking back one
        # rule lands on its closing line and leaves the title orphaned. Go back
        # two to reach the top of the block.
        closing = text.rindex(rule, 0, text.index(marker))
        start = text.rindex(rule, 0, closing)
        end = text.index(rule, text.index(marker))
        text = text[:start] + text[end:]

    # selection
    start = text.index('ORDER = [')
    end = text.index("def build(name: str)")
    text = text[:start] + SELECTION + "\n\n" + text[end:]

    # the role map in status()
    text = text.replace(
        '''               "role": {"vertex": "deployment target",
                        "anthropic": "API fallback",
                        "claude-cli": "local testing"}[name]}''',
        '''               "role": "deployment target"}''')

    # no subprocess or shutil left once the CLI backend is gone
    for unused in ("import shutil\n", "import subprocess\n"):
        if unused.strip().split()[1] not in text.split("import", 1)[1]:
            continue
    text = re.sub(r"^import shutil\n", "", text, flags=re.M)
    text = re.sub(r"^import subprocess\n", "", text, flags=re.M)
    return text


def rewrite_api(text: str) -> str:
    start = text.index('    """Which model backend the pricing agent would use')
    end = text.index('    from .agent import AGENT_VERSION, provider_status')
    return text[:start] + API_DOC + "\n" + text[end:]


def rewrite_requirements(text: str) -> str:
    start = text.index("# --- the pricing agent's model backends")
    return text[:start] + '''# --- the pricing agent -------------------------------------------------
#
# Not required to run the demo: with Vertex unreachable the agent falls back to
# matching the charge text by pattern, and labels every case accordingly.
#
# Vertex AI with Gemini, authenticated by Application Default Credentials —
# Workload Identity Federation in a deployed environment, a gcloud login
# locally. Same credential setup as the evaluation service; see
# docs/pricing-agent.md.
google-genai>=1.0,<2.0
google-auth>=2.30,<3.0
'''


def rewrite_env_example(text: str) -> str:
    text = text.replace(
        """# Copy to .env and fill in. Nothing here is required to run the demo: with none
# of it set the pricing agent falls back to the `claude` CLI if one is on PATH,
# and to pattern matching if not — and says so on every case rather than
# presenting a pattern match as reasoning.""",
        """# Copy to .env and fill in. Nothing here is required to run the demo: with
# none of it set the pricing agent matches the charge text by pattern instead
# of reading it, and says so on every case rather than presenting a pattern
# match as reasoning.""")
    start = text.index("# ------------------------------------------------------"
                       "---------------------\n# Fallbacks")
    end = text.index("# ------------------------------------------------------"
                     "---------------------\n# Checking it works")
    return text[:start] + '''# Pin the provider instead of letting it fall back:
#   vertex | rules
# PRICING_AGENT_PROVIDER=

''' + text[end:]


def rewrite_markdown(text: str, path: str) -> str:
    """Drop the backend table rows and paragraphs about the other providers."""
    if path == "docs/pricing-agent.md":
        start = text.index("## Model backends")
        end = text.index("## Vertex AI with Workload Identity Federation")
        text = text[:start] + '''## Model backend

Gemini on Vertex AI, with a deterministic fallback when it cannot be reached.
`GET /api/agent/status` reports which one is live and why; the same is shown on
the **Client pricing** page.

| Order | Backend | Role |
|---|---|---|
| 1 | Gemini on Vertex AI | the deployment target |
| 2 | pattern rules | no model at all, labelled as such on every case |

`PRICING_AGENT_PROVIDER` pins one (`vertex` or `rules`). The fallback never
presents itself as reasoning: the case says the instruction was matched by
pattern rather than read, and asks for confirmation.

''' + text[end:]
        text = text.replace(
            "The Anthropic backend does the same through extended thinking. The\n"
            "CLI backend exposes no thinking blocks, which is why the agent is asked to put "
            "its argument\nin its answer rather than relying on a provider to reveal it — "
            "the reasoning is\nthen tied to quoted source text, which is more use to a maker "
            "than a raw\nthought stream.",
            "The agent is also asked to put its argument in its answer rather than "
            "relying\non the provider to reveal it, so the reasoning is tied to quoted "
            "source text,\nwhich is more use to a maker than a raw thought stream.")
        # the Windows CLI note no longer applies
        text = re.sub(r"\n> The `claude` CLI on Windows.*?stdin\.\n", "\n",
                      text, flags=re.S)
    else:  # README.md
        # The section describing this script would itself be a tell, and it
        # names both backends, so the copy does not carry it.
        if "## Making a Vertex-only build" in text:
            start = text.index("## Making a Vertex-only build")
            end = text.index("## Resetting between demo runs")
            text = text[:start] + text[end:]
        text = text.replace(
            """It runs on **Gemini via Vertex AI with Workload Identity Federation** in the
bank's environment, falls back to the Anthropic API, then to the local `claude`
CLI for testing, then to pattern matching — which it labels as such on every
case rather than passing off as reasoning. `GET /api/agent/status` says which
one is live.""",
            """It runs on **Gemini via Vertex AI with Workload Identity Federation**, and
falls back to pattern matching when Vertex cannot be reached — which it labels
as such on every case rather than passing off as reasoning.
`GET /api/agent/status` says which one is live.""")
        text = text.replace(
            """- **Live credentials for Vertex.** The WIF path is built and configurable but
  has not been exercised against a real project; the agent was tested on the
  `claude` CLI backend.""",
            """- **Live credentials for Vertex.** The WIF path is built and configurable but
  has not been exercised against a real project.""")
        text = text.replace(
            """It runs on **Gemini via Vertex AI with Workload Identity Federation** in
the bank's environment, falls back to the Anthropic API, then to the local `claude`
CLI for testing, then to pattern matching — which it labels as such on every
case rather than passing off as reasoning. `GET /api/agent/status` says which
one is live.""",
            """It runs on **Gemini via Vertex AI with Workload Identity Federation**, and
falls back to pattern matching when Vertex cannot be reached — which it labels
as such on every case rather than passing off as reasoning.
`GET /api/agent/status` says which one is live.""")
        text = text.replace(
            "| `agent/providers.py` | Vertex AI, the Anthropic API, the `claude` CLI |",
            "| `agent/providers.py` | Vertex AI |")
        text = text.replace(
            """    providers.py     Vertex / Anthropic / claude CLI / rules""",
            """    providers.py     Vertex, and the no-model rules fallback""")
    return text


REWRITERS = {
    "app/agent/providers.py": rewrite_providers,
    "app/api.py": rewrite_api,
    "requirements.txt": rewrite_requirements,
    ".env.example": rewrite_env_example,
    "README.md": lambda t: rewrite_markdown(t, "README.md"),
    "docs/pricing-agent.md": lambda t: rewrite_markdown(t, "docs/pricing-agent.md"),
}

PATTERN = re.compile(r"claude|anthropic", re.I)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out", help="directory to write the Vertex-only copy into")
    ap.add_argument("--force", action="store_true",
                    help="overwrite the output directory if it exists")
    args = ap.parse_args()

    root = pathlib.Path(__file__).resolve().parent.parent
    out = pathlib.Path(args.out).resolve()
    if out.exists():
        if not args.force:
            print(f"{out} already exists. Pass --force to replace it.",
                  file=sys.stderr)
            return 2
        shutil.rmtree(out)

    copied = rewritten = 0
    for src in sorted(root.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(root)
        if any(p in SKIP_DIRS for p in rel.parts) or src.suffix.lower() in SKIP_EXT \
                or src.name in SKIP_NAMES or rel.as_posix() in SKIP_RELATIVE:
            continue
        dst = out / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        key = rel.as_posix()
        if key in REWRITERS:
            text = src.read_text(encoding="utf-8")
            dst.write_text(REWRITERS[key](text), encoding="utf-8")
            rewritten += 1
            print(f"  rewritten  {key}")
        else:
            shutil.copy2(src, dst)
            copied += 1

    print(f"\n{copied} file(s) copied, {rewritten} rewritten -> {out}")

    # --- verify: nothing may survive anywhere in the copy ------------------
    leftovers: list[str] = []
    for f in sorted(out.rglob("*")):
        if not f.is_file() or f.suffix.lower() in {".png", ".jpg", ".jpeg",
                                                   ".pptx", ".xlsx", ".db"}:
            continue
        try:
            text = f.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for i, line in enumerate(text.splitlines(), 1):
            if PATTERN.search(line):
                leftovers.append(f"{f.relative_to(out).as_posix()}:{i}: {line.strip()[:90]}")

    print()
    if leftovers:
        print(f"{len(leftovers)} mention(s) survived:")
        for line in leftovers[:40]:
            print("  " + line)
        return 1

    print("Verified: no mention of either backend survives in the copy.")

    # --- and the copy must still import --------------------------------
    import subprocess
    probe = subprocess.run(
        [sys.executable, "-c",
         "import sys; sys.path.insert(0, r'%s'); import app.main, app.agent; "
         "from app.agent import provider_status; "
         "print('providers:', [p['provider'] for p in provider_status()])" % out],
        capture_output=True, text=True, cwd=str(out))
    print((probe.stdout or probe.stderr).strip())
    return 0 if probe.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
