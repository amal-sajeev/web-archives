"""Splice a supplied port directory into app/data/ports.json.

The directory arrives as a bare JSON array of {code, name, country, unlocode}.
This checks it against the codes the sample data actually uses, reports what is
missing or unsure, and writes it into the "ports" slot — leaving the search
rule and the codes-seen list alone.

    .venv\\Scripts\\python tools\\load_ports.py ports-from-chatgpt.json

Add --force to write even when something is missing or flagged unsure.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
from datetime import datetime

ROOT = pathlib.Path(__file__).resolve().parent.parent
TARGET = ROOT / "app" / "data" / "ports.json"


def wanted(existing: dict) -> list[str]:
    """Every term a lookup could search for, from the codes seen in the data."""
    terms: set[str] = set()
    for entry in existing.get("codesSeenInData", []):
        if entry.get("code"):
            terms.add(entry["code"].upper())
        if entry.get("searchAs"):
            terms.add(entry["searchAs"].upper())
    return sorted(terms)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("source", help="the JSON array of ports")
    ap.add_argument("--force", action="store_true",
                    help="write even when codes are missing or flagged unsure")
    args = ap.parse_args()

    raw = pathlib.Path(args.source).read_text(encoding="utf-8").strip()
    # tolerate a markdown fence, since that is what usually comes back
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0].strip()

    try:
        supplied = json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"That file is not valid JSON: {exc}", file=sys.stderr)
        return 2

    # tolerate {"ports": [...]} as well as a bare array
    if isinstance(supplied, dict):
        supplied = supplied.get("ports", [])
    if not isinstance(supplied, list):
        print("Expected a JSON array of port objects.", file=sys.stderr)
        return 2

    existing = json.loads(TARGET.read_text(encoding="utf-8"))

    clean: list[dict] = []
    unsure: list[str] = []
    problems: list[str] = []

    for i, item in enumerate(supplied, 1):
        if not isinstance(item, dict):
            problems.append(f"entry {i} is not an object")
            continue
        code = str(item.get("code") or "").strip().upper()
        name = str(item.get("name") or "").strip()
        if not code:
            problems.append(f"entry {i} has no code")
            continue
        if not name:
            problems.append(f"{code} has no name")
            continue
        if item.get("confident") is False:
            unsure.append(f"{code} -> {name}")
        clean.append({
            "code": code,
            "name": name,
            "city": str(item.get("city") or "").strip() or None,
            "country": str(item.get("country") or "").strip() or None,
            "unlocode": (str(item["unlocode"]).strip().upper()
                         if item.get("unlocode") else None),
        })

    have = {p["code"] for p in clean}
    need = wanted(existing)
    missing = [c for c in need if c not in have]
    extra = sorted(have - set(need))

    print(f"supplied : {len(clean)} port(s)")
    print(f"needed   : {len(need)} code(s) from the sample data")
    if extra:
        print(f"extra    : {len(extra)} beyond what the data uses "
              f"({', '.join(extra[:8])}{'...' if len(extra) > 8 else ''})")
    if missing:
        print(f"MISSING  : {', '.join(missing)}")
    if unsure:
        print(f"UNSURE   : {len(unsure)} entry(ies) flagged by whoever produced it")
        for line in unsure:
            print(f"           {line}")
    if problems:
        print(f"PROBLEMS : {len(problems)}")
        for line in problems[:10]:
            print(f"           {line}")

    if (missing or problems) and not args.force:
        print("\nNothing written. Fix the above, or pass --force to write anyway.")
        return 1

    existing["ports"] = sorted(clean, key=lambda p: p["code"])
    existing["awaitingDirectory"] = False
    existing["source"] = f"supplied directory, loaded from {pathlib.Path(args.source).name}"
    if unsure:
        existing["unverified"] = [u.split(" -> ")[0] for u in unsure]
    else:
        # a reload with everything confirmed must clear a previous flag, or a
        # corrected entry keeps reading as doubtful
        existing.pop("unverified", None)
    existing["_loaded"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    TARGET.write_text(json.dumps(existing, indent=2, ensure_ascii=False) + "\n",
                      encoding="utf-8")

    print(f"\nWritten to {TARGET.relative_to(ROOT)}.")
    print("Restart the app, or POST /api/mock/reload, and the port checks resolve.")
    if unsure:
        print("The unsure entries are recorded under \"unverified\" so they can be "
              "checked before this goes anywhere real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
