/* The case screen.

   Every action posts to the JSON API and the page reloads from the server, so
   what you see is always what is stored. Reloading keeps this file small and
   the behaviour obvious — there is no client-side copy of the case to drift. */

(function () {
  "use strict";
  const { api, toast, openModal, closeModals } = window.App;

  const root = document.querySelector("[data-case]");
  if (!root) return;
  const caseId = root.dataset.case;
  const url = p => "/api/cases/" + caseId + p;

  function after(message, title, action) {
    toast("ok", title || "Saved", message, action);
    setTimeout(() => location.reload(), action ? 2600 : 850);
  }

  /* When a fix clears the last thing standing in the way, say so and offer the
     next step. The action only takes you to the decision; it does not validate,
     because the attestation is a control and must stay deliberate. */
  function onward(res) {
    const d = res.data || {};
    if (d.ready_to_validate) {
      try { sessionStorage.setItem("tc:focus-decision:" + caseId, "1"); } catch (e) {}
      after(res.message, "Nothing else outstanding", {
        label: "Review and send",
        onClick: () => location.reload()
      });
    } else {
      after(res.message);
    }
  }

  function fail(err) { toast("bad", "Didn't work", err.message); }

  /* A workflow transition stays reversible for a short window. Hold on the page
     until that window closes, then move on. */
  function offerUndo(title, res, nextHref) {
    const token = res.data && res.data.undo_token;
    if (!token) {
      toast("ok", title, res.message);
      setTimeout(() => { location.href = nextHref; }, 950);
      return;
    }
    let moved = false;
    toast("ok", title, res.message, {
      label: "Undo",
      seconds: 15,
      onClick: async () => {
        moved = true;
        try {
          const u = await api("POST", url("/undo"), { token: token });
          toast("info", "Undone", u.message);
          setTimeout(() => location.reload(), 900);
        } catch (err) { toast("bad", "Could not undo", err.message); }
      }
    });
    setTimeout(() => { if (!moved) location.href = nextHref; }, 15500);
  }

  /* Any control can open a named dialog. The corporate view reaches the
     documents this way, as the deck does. */
  document.querySelectorAll("[data-open]").forEach(b =>
    b.addEventListener("click", () => openModal(b.dataset.open)));


  /* ---------------------------------------------------- draft autosave --
     Typing a resolution or a query is real work. Keep it per case and field so
     dismissing a dialog by accident does not throw it away. Storage can be
     unavailable (private mode), so every call is guarded. */

  const DRAFT_FIELDS = ["resolve-text", "q-reason", "edit-value", "edit-note", "text-value"];
  const draftKey = id => "tc:draft:" + caseId + ":" + id;

  function readDraft(id) {
    try { return localStorage.getItem(draftKey(id)) || ""; } catch (e) { return ""; }
  }
  function writeDraft(id, value) {
    try {
      if (value) localStorage.setItem(draftKey(id), value);
      else localStorage.removeItem(draftKey(id));
    } catch (e) { /* storage unavailable */ }
  }
  function clearDrafts(ids) { ids.forEach(id => writeDraft(id, "")); }
  function restoreDrafts(ids) {
    ids.forEach(id => {
      const el = document.getElementById(id);
      const saved = readDraft(id);
      if (el && saved && !el.value) el.value = saved;
    });
  }

  DRAFT_FIELDS.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    let t;
    el.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(() => writeDraft(id, el.value), 300);
    });
  });

  /* ------------------------------------------------- document viewer -- */

  const tabs = document.querySelectorAll(".tab");
  const pages = document.querySelectorAll(".paper");

  function showDoc(id) {
    tabs.forEach(t => t.setAttribute("aria-selected", String(t.dataset.doc === id)));
    pages.forEach(p => p.classList.toggle("is-hidden", p.dataset.doc !== id));
  }
  tabs.forEach(t => t.addEventListener("click", () => showDoc(t.dataset.doc)));

  /* ------------------------------------------------ name a port by hand */

  let portRole = null;

  document.querySelectorAll("[data-port]").forEach(btn =>
    btn.addEventListener("click", () => {
      portRole = btn.dataset.port;
      const code = btn.dataset.code || "";
      const label = document.getElementById("port-label");
      if (label) label.textContent = "Name the port of " + portRole;
      const ctx = document.getElementById("port-ctx");
      if (ctx) {
        ctx.textContent = code
          ? "The transport document carries " + code +
            ". TF3 needs the full name, and the directory is not connected yet."
          : "No code was supplied for the port of " + portRole + ".";
      }
      document.getElementById("port-name").value = "";
      document.getElementById("port-note").value = "";
      restoreDrafts(["port-name", "port-note"]);
      openModal("m-port");
      document.getElementById("port-name").focus();
    }));

  const portSave = document.getElementById("port-save");
  if (portSave) {
    portSave.addEventListener("click", async () => {
      const name = document.getElementById("port-name").value.trim();
      if (!name) {
        toast("bad", "Needs a name", "Type the port's full name.");
        return;
      }
      try {
        const res = await api("POST", url("/ports/" + portRole), {
          name,
          note: document.getElementById("port-note").value.trim() || null
        });
        clearDrafts(["port-name", "port-note"]);
        onward(res);
      } catch (err) { fail(err); }
    });
  }

  /* ------------------------------------- read the charge instruction again */

  document.querySelectorAll("[data-recalc]").forEach(btn =>
    btn.addEventListener("click", async () => {
      const was = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Reading\u2026";
      try {
        const res = await api("POST", url("/charges/recalculate"), {});
        onward(res);
      } catch (err) {
        fail(err);
      } finally {
        btn.disabled = false;
        btn.textContent = was;
      }
    }));

  /* ------------------------------------------------------- resolve a check */

  let resolveId = null;

  document.querySelectorAll("[data-resolve]").forEach(btn =>
    btn.addEventListener("click", () => {
      resolveId = btn.dataset.resolve;
      const todo = btn.closest("[data-todo]");
      document.getElementById("resolve-check").textContent =
        todo ? todo.querySelector("p").textContent : "";
      document.getElementById("resolve-text").value = "";
      restoreDrafts(["resolve-text"]);
      openModal("m-resolve");
    }));

  const resolveSave = document.getElementById("resolve-save");
  if (resolveSave) {
    resolveSave.addEventListener("click", async () => {
      const text = document.getElementById("resolve-text").value.trim();
      if (!text) { toast("bad", "Needs a reason", "A line is enough — the checker reads it."); return; }
      try {
        const res = await api("POST", url("/checks/" + resolveId + "/resolve"), { resolution: text });
        clearDrafts(["resolve-text"]);
        onward(res);
      } catch (err) { fail(err); }
    });
  }

  /* --------------------------------------------------------- ask the branch */

  document.querySelectorAll("[data-query]").forEach(btn =>
    btn.addEventListener("click", () => {
      document.getElementById("q-check").value = btn.dataset.query || "";
      document.getElementById("q-reason").value = "";
      restoreDrafts(["q-reason"]);
      openModal("m-query");
    }));

  const qSend = document.getElementById("q-send");
  if (qSend) {
    qSend.addEventListener("click", async () => {
      const reason = document.getElementById("q-reason").value.trim();
      if (!reason) { toast("bad", "Needs a question", "Say what they need to confirm."); return; }
      try {
        const res = await api("POST", url("/queries"), {
          check_id: document.getElementById("q-check").value || null,
          recipient: document.getElementById("q-to").value || "Branch operations",
          reason
        });
        clearDrafts(["q-reason"]);
        after(res.message, "Sent");
      } catch (err) { fail(err); }
    });
  }

  /* ------------------------------------------------------ small text dialog */

  let textHandler = null;
  function textModal(title, label, handler) {
    document.getElementById("text-title").textContent = title;
    document.getElementById("text-label").textContent = label;
    document.getElementById("text-value").value = "";
    textHandler = handler;
    openModal("m-text");
  }

  const textSave = document.getElementById("text-save");
  if (textSave) {
    textSave.addEventListener("click", async () => {
      const text = document.getElementById("text-value").value.trim();
      if (!text) { toast("bad", "Needs a note", "Add a line before confirming."); return; }
      try { await textHandler(text); closeModals(); } catch (err) { fail(err); }
    });
  }

  document.querySelectorAll("[data-answer]").forEach(btn =>
    btn.addEventListener("click", () =>
      textModal("Record the reply", "What did the branch say?", async text => {
        const res = await api("POST", url("/queries/" + btn.dataset.answer + "/answer"),
                              { response: text });
        after(res.message);
      })));

  /* -------------------------------------------------------------- decide */

  const agrees = Array.from(document.querySelectorAll("#agree, #agree2"));
  const validate = document.getElementById("validate-btn");
  const gated = validate && !validate.disabled && agrees.length;

  function sync() {
    if (gated) validate.disabled = !agrees.every(a => a.checked);
  }
  if (gated) { validate.disabled = true; agrees.forEach(a => a.addEventListener("change", sync)); }

  if (validate) {
    validate.addEventListener("click", async () => {
      validate.disabled = true;
      try {
        const res = await api("POST", url("/validate"), {
          source_reviewed: true, exceptions_resolved: true
        });
        if (!res.ok) { toast("bad", "Not sent", res.message); validate.disabled = false; return; }
        offerUndo("Sent to the checker", res, res.data.next || "/");
      } catch (err) { fail(err); validate.disabled = false; }
    });
  }

  const approve = document.querySelector("[data-approve]");
  if (approve) {
    approve.addEventListener("click", async () => {
      try {
        const res = await api("POST", url("/approve"), {});
        offerUndo("Approved and closed", res, "/");
      } catch (err) { fail(err); }
    });
  }

  const sendBack = document.querySelector("[data-return]");
  if (sendBack) {
    sendBack.addEventListener("click", () =>
      textModal("Send back to the maker", "What needs doing?", async text => {
        const res = await api("POST", url("/return"), { reason: text });
        offerUndo("Returned to the maker", res, "/");
      }));
  }

  const start = document.querySelector("[data-start]");
  if (start) {
    start.addEventListener("click", async () => {
      start.disabled = true;
      start.textContent = "Running\u2026";
      try {
        const res = await api("POST", url("/start"), {});
        toast("ok", "Running", res.message);
        /* Stay on the page and watch it, rather than reloading into a page
           that has already missed the first few steps. */
        root.dataset.status = "ai_processing";
        window.TCFollowRun();
      } catch (err) { fail(err); start.disabled = false; }
    });
  }

  /* after a chained fix, land on the decision rather than the top of the page */
  try {
    if (sessionStorage.getItem("tc:focus-decision:" + caseId)) {
      sessionStorage.removeItem("tc:focus-decision:" + caseId);
      const first = document.getElementById("agree");
      if (first) {
        first.closest("label").scrollIntoView({ block: "center", behavior: "smooth" });
        setTimeout(() => first.focus(), 400);
      }
    }
  } catch (e) { /* storage unavailable */ }

  /* ------------------------------------------------------- live progress --
     While a case is running, ask the server for the run panel about once a
     second and put it on the page. The panel is rendered by the same template
     that drew it on load, so there is no second copy of the markup here — and
     what you see is the steps the pipeline has actually recorded, never a
     client-side guess at how far along it is.

     The panel itself says when the run is over, and then the page reloads to
     pick up the checks, the charges and the decision. */

  const RUN_EVERY_MS = 900;

  function startedRunning() {
    const panel = document.querySelector("[data-runlog]");
    if (panel) return;
    /* The run began on this page view, so there is no panel yet. Make a home
       for it where the template would have put it. */
    const host = document.createElement("div");
    host.dataset.runlogHost = "1";
    const snap = document.querySelector(".snap, .verdict");
    if (snap && snap.parentNode) snap.parentNode.insertBefore(host, snap.nextSibling);
    else root.parentNode.appendChild(host);
  }

  async function follow() {
    let stop = false;
    try {
      const res = await fetch(url("/runlog"), { headers: { "Accept": "text/html" } });
      if (!res.ok) throw new Error(res.status);
      const html = await res.text();
      const panel = document.querySelector("[data-runlog]");
      const host = document.querySelector("[data-runlog-host]");
      if (panel) panel.outerHTML = html;
      else if (host) host.innerHTML = html;
      const now = document.querySelector("[data-runlog]");
      stop = !now || now.dataset.runDone === "1";
    } catch (_) {
      /* A transient failure is not a finished run: keep asking. */
    }
    if (stop) { setTimeout(() => location.reload(), 700); return; }
    setTimeout(follow, RUN_EVERY_MS);
  }

  if (root.dataset.status === "ai_processing") {
    startedRunning();
    follow();
  }

  /* Expose it so the start button can switch straight into following the run
     instead of reloading the page and losing the first few steps. */
  window.TCFollowRun = () => { startedRunning(); follow(); };
})();

/* The blotter: the bench's tabs, and the docket beside it.
 *
 * Both do the same small thing — show one of several panels — but they are
 * not the same control. The tabs choose what kind of thing you are looking
 * at; the docket chooses which open item, and has to switch to the work pane
 * first if you are somewhere else. Keeping that distinction in one place is
 * what stops the docket quietly becoming a second row of tabs.
 */
(function () {
  "use strict";

  var blot = document.querySelector(".blot");
  if (!blot) return;

  var panes = blot.querySelectorAll(".pane");
  var tabs = blot.querySelectorAll(".bt");

  function openPane(name) {
    panes.forEach(function (p) {
      p.classList.toggle("is-on", p.dataset.pane === name);
    });
    tabs.forEach(function (t) {
      t.setAttribute("aria-selected", String(t.dataset.pane === name));
    });
    var inner = blot.querySelector(".bench__in");
    if (inner) inner.scrollTop = 0;
  }

  tabs.forEach(function (t) {
    t.addEventListener("click", function () { openPane(t.dataset.pane); });
  });

  blot.addEventListener("click", function (e) {
    var hit = e.target.closest("[data-goto]");
    if (!hit) return;
    var want = hit.dataset.goto;

    if (want === "checks") { openPane("checks"); return; }

    openPane("work");
    blot.querySelectorAll(".dock").forEach(function (d) {
      d.classList.toggle("is-on", d === hit);
    });
    var snag = blot.querySelector('[data-todo="' + CSS.escape(want) + '"]');
    if (!snag) return;
    blot.querySelectorAll(".snag").forEach(function (s) {
      s.classList.toggle("is-on", s === snag);
    });
    snag.scrollIntoView({ block: "nearest", behavior: "smooth" });
  });

  /* Keyboard: the tab strip behaves like one control, not five. */
  blot.querySelector(".bench__tabs").addEventListener("keydown", function (e) {
    var step = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0;
    if (!step) return;
    e.preventDefault();
    var list = Array.prototype.slice.call(tabs);
    var at = list.indexOf(document.activeElement);
    var next = list[(at + step + list.length) % list.length];
    next.focus();
    openPane(next.dataset.pane);
  });
}());
