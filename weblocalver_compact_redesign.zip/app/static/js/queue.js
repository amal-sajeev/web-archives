/* Queue: type to filter, and keep the processing rows moving. */

(function () {
  "use strict";
  const { api } = window.App;

  const q = document.getElementById("q");

  /* The corporate toolbar is a real form and submits natively, carrying its
     own filters and sort. Only the desk view needs the JS redirect. */
  if (q && !q.closest("form")) {
    let t;
    q.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(() => {
        // build from the current URL so the page you are on and any sort survive
        const url = new URL(location.href);
        const v = q.value.trim();
        if (v) url.searchParams.set("q", v);
        else url.searchParams.delete("q");
        location.href = url.toString();
      }, 420);
    });
    // carry the caret on only when the page came back from a search
    if (q.value) {
      q.focus();
      q.setSelectionRange(q.value.length, q.value.length);
    }
  }

  // Only poll while something is actually in flight.
  if (document.querySelector(".gauge")) {
    setInterval(async () => {
      try {
        const data = await api("GET", "/api/cases/live");
        let finished = false;
        data.cases.forEach(c => {
          const row = document.querySelector('a[href="/cases/' + c.case_id + '"] .gauge i')
                   || document.querySelector('[data-case-row="' + c.case_id + '"] .gauge i');
          if (!row) return;
          if (c.status === "ai_processing") row.style.width = c.progress + "%";
          else finished = true;
        });
        if (finished) location.reload();
      } catch (_) { /* transient */ }
    }, 2500);
  }
})();

/* The worklist groups on the TF3 reference, and a group opens onto its
 * invoices. Delegated from the table so it costs one listener however many
 * collections are on the page, and keyed on the row rather than an index, so
 * nothing has to be renumbered when the list is filtered or sorted.
 */
(function () {
  "use strict";

  var grid = document.querySelector(".grid");
  if (!grid) return;

  function toggle(head) {
    var group = head.closest(".cgrp");
    if (!group) return;
    var open = group.classList.toggle("is-open");
    head.setAttribute("aria-expanded", String(open));
  }

  grid.addEventListener("click", function (e) {
    var head = e.target.closest(".cg");
    if (head && !e.target.closest("a")) toggle(head);
  });
  grid.addEventListener("keydown", function (e) {
    if (e.key !== "Enter" && e.key !== " ") return;
    var head = e.target.closest(".cg");
    if (!head) return;
    e.preventDefault();
    toggle(head);
  });
}());

/* Landing on an invoice.
 *
 * An invoice is a line of its bill rather than a thing with a page, so it
 * gets an address instead: a row id keyed on bill-of-entry-plus-number. Two
 * things arrive at one — a search whose term matched the number, which the
 * server has already marked and opened, and a link to the row's anchor,
 * which has to be opened here. Both end the same way: the collection is
 * open, the row is marked, and the page is scrolled to it.
 */
(function () {
  "use strict";

  function reveal(row) {
    if (!row) return;
    var box = row.closest("details.coll");          // the desk view
    if (box) box.open = true;
    var group = row.closest(".cgrp");               // the corporate one
    if (group) {
      group.classList.add("is-open");
      var head = group.querySelector(".cg");
      if (head) head.setAttribute("aria-expanded", "true");
    }
    row.classList.add("is-hit");
    // After the open, so the row is laid out where it will finally sit.
    requestAnimationFrame(function () {
      row.scrollIntoView({ block: "center", behavior: "smooth" });
    });
  }

  function fromHash() {
    var id = (location.hash || "").slice(1);
    if (!id || id.indexOf("inv-") !== 0) return false;
    // Not a selector: an id built from a bill and an invoice number can
    // hold characters querySelector would read as syntax.
    var row = document.getElementById(id);
    if (!row) return false;
    reveal(row);
    return true;
  }

  if (!fromHash()) reveal(document.querySelector("tr.is-hit"));
  window.addEventListener("hashchange", fromHash);
}());
