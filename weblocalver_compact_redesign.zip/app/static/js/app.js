/* Shared bits: fetch, toasts, dialogs, role switch. */

window.App = (function () {
  "use strict";

  async function api(method, url, body) {
    const opts = { method, headers: {} };
    if (body !== undefined) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || data.message || "Something went wrong");
    return data;
  }

  /* toast(tone, title, message, action?)
     action = { label, onClick, seconds } — `seconds` counts down in the label
     and dismisses the toast when it reaches zero, which is how the undo window
     is surfaced. */
  function toast(tone, title, message, action) {
    const host = document.getElementById("toasts");
    if (!host) return;

    const el = document.createElement("div");
    el.className = "notice notice--" + tone;
    const text = document.createElement("div");
    text.innerHTML = "<b></b><span></span>";
    text.querySelector("b").textContent = title;
    text.querySelector("span").textContent = message || "";
    el.appendChild(text);

    let life = (action && action.seconds) ? action.seconds * 1000 : 4200;
    let timer, tick;

    const close = () => {
      clearTimeout(timer); clearInterval(tick);
      el.style.transition = "opacity .3s, transform .3s";
      el.style.opacity = "0";
      el.style.transform = "translateY(6px)";
      setTimeout(() => el.remove(), 320);
    };

    if (action) {
      const btn = document.createElement("button");
      btn.className = "notice__do";
      let left = action.seconds || 0;
      const label = () => btn.textContent = left ? `${action.label} ${left}s` : action.label;
      label();
      if (left) tick = setInterval(() => { left -= 1; label(); if (left <= 0) clearInterval(tick); }, 1000);
      btn.addEventListener("click", () => { close(); action.onClick(); });
      el.appendChild(btn);
    }

    host.appendChild(el);
    timer = setTimeout(close, life);
  }

  function openModal(id) {
    const m = document.getElementById(id);
    if (!m) return null;
    m.classList.add("is-open");
    const f = m.querySelector("input:not([type=hidden]), textarea");
    if (f) setTimeout(() => f.focus(), 40);
    return m;
  }

  function closeModals() {
    document.querySelectorAll(".sheet-over.is-open").forEach(m => m.classList.remove("is-open"));
  }

  document.addEventListener("click", e => {
    if (e.target.closest("[data-close]")) closeModals();
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") closeModals();
  });

  document.querySelectorAll("[data-switch-role]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const next = document.body.dataset.role === "Checker" ? "Maker" : "Checker";
      try {
        await api("POST", "/api/session/role", { role: next });
        location.href = "/";
      } catch (err) { toast("bad", "Could not switch", err.message); }
    });
  });

  /* Rebuild the cases and leave them unrun, which is what you want before
     showing the pipeline working: open any case and the run panel fills in
     step by step. Offered from both footer buttons rather than taking a third
     one, because it is only ever wanted straight after one of them. */
  async function stageUnrun() {
    try {
      const r = await api("POST", "/api/demo/reset", { run: false });
      toast("ok", "Queue staged", r.message ||
            "Cases rebuilt, none run. Open one and run it.");
      setTimeout(() => { location.href = "/"; }, 600);
    } catch (err) { toast("bad", "Could not stage", err.message); }
  }

  /* ------------------------------------------------- run the queue ------ */
  /* Puts every case that has not been run through the port lookups, the
     checks and the charges. On a fresh start nothing has been run, so this is
     what gets the queue into the state a demo opens on without clicking into
     twelve cases. It only touches unrun cases, so it can never undo a maker's
     or a checker's work — which is why it does not ask first. */
  document.querySelectorAll("[data-run-all]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const was = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Running…";
      try {
        const res = await api("POST", "/api/cases/run-all");
        if (res.ran) {
          btn.textContent = "Done";
          toast("ok", "Checks run", res.message);
          setTimeout(() => { location.href = "/"; }, 600);
          return;
        }
        /* Nothing was pending. Say so, and offer the one thing that makes the
           button useful again, rather than leaving a dead end. */
        btn.disabled = false;
        btn.textContent = was;
        toast("ok", "Nothing left to run",
              "Every case has already been through the checks.",
              { label: "Put them back unrun", seconds: 8, onClick: stageUnrun });
      } catch (err) {
        btn.disabled = false;
        btn.textContent = was;
        toast("bad", "Could not run the checks", err.message);
      }
    });
  });

  /* ----------------------------------------------- put the demo back ---- */
  /* Discards every maker and checker action and rebuilds the cases from the
     data files. Destructive, so it asks first — a mis-click during a demo is
     exactly when you least want to lose the state you set up. */
  document.querySelectorAll("[data-reset]").forEach(btn => {
    btn.addEventListener("click", async () => {
      if (!window.confirm(
        "Reset the demo?\n\n" +
        "This discards every validation, approval, settled check, typed port " +
        "name and query, and puts all cases back through the checks.")) return;

      const was = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Resetting\u2026";
      try {
        const res = await api("POST", "/api/demo/reset", { run: true });
        btn.textContent = "Ready";
        toast("ok", "Demo reset", res.message || "Cases rebuilt.");
        setTimeout(() => { location.href = "/"; }, 600);
      } catch (err) {
        btn.disabled = false;
        btn.textContent = was;
        toast("bad", "Could not reset", err.message);
      }
    });
  });

  return { api, toast, openModal, closeModals };
})();
