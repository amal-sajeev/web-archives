/* Counterparty map — highlighting, and panning the plane.
 *
 * The drawing arrives finished: every coordinate is in the SVG the server
 * sent, so there is no layout, no simulation and nothing to measure here.
 * Two jobs only.
 *
 * Highlighting answers "what does this touch?", which means one class on the
 * figure and one class on the handful of elements concerned. Built once into
 * two lookups — node id to its elements, link id to its elements — so a hover
 * is O(degree) rather than O(everything), which matters when the plane holds a
 * thousand discs.
 *
 * Panning and zooming move the viewBox. Nothing is re-laid-out, nothing is
 * read back off the DOM, and the cost does not depend on how much is drawn.
 */
(function () {
  "use strict";

  var map = document.querySelector("[data-netmap]");
  if (!map) return;

  var svg = map.querySelector(".netmap__svg, .netplane__svg");
  if (!svg) return;

  /* Hovering a party should light its neighbourhood: the party, what it
     trades with, and the lines between. An earlier version indexed only the
     party and its own lines, so the counterparty at the far end dimmed with
     everything else and each line ran off to a ghost — which is no use at
     all, since what somebody hovers a node to find out is who is on the
     other side of it. */
  var nodeEls = {};    /* node id -> [itself, its edges, the nodes they reach] */
  var linkEls = {};    /* link id -> [the edge, the two nodes it joins] */
  var byId = {};       /* node id -> its element */
  var lit = [];

  function note(index, key, el) {
    var at = index[key] || (index[key] = []);
    if (at.indexOf(el) === -1) at.push(el);
  }

  var nodes = svg.querySelectorAll("[data-node]");
  Array.prototype.forEach.call(nodes, function (g) {
    var id = g.getAttribute("data-node");
    byId[id] = g;
    note(nodeEls, id, g);
  });
  Array.prototype.forEach.call(nodes, function (g) {
    (g.getAttribute("data-links") || "").split(/\s+/).forEach(function (id) {
      if (id) note(linkEls, id, g);
    });
  });

  Array.prototype.forEach.call(svg.querySelectorAll("[data-link]"), function (a) {
    var id = a.getAttribute("data-link");
    note(linkEls, id, a);
    note(nodeEls, id, a);
    var ends = (a.getAttribute("data-nodes") || "").split(/\s+/)
      .filter(function (nid) { return nid; });
    ends.forEach(function (nid) {
      note(nodeEls, nid, a);                     /* the line itself */
      ends.forEach(function (other) {            /* and who it reaches */
        if (byId[other]) note(nodeEls, nid, byId[other]);
      });
    });
  });

  function clear() {
    for (var i = 0; i < lit.length; i++) lit[i].classList.remove("is-on");
    lit = [];
    map.classList.remove("is-focused");
  }

  function light(groups) {
    holdOff();
    clear();
    var seen = [];
    groups.forEach(function (els) {
      if (!els) return;
      for (var i = 0; i < els.length; i++) {
        if (seen.indexOf(els[i]) === -1) {
          els[i].classList.add("is-on");
          seen.push(els[i]);
        }
      }
    });
    if (!seen.length) return;
    lit = seen;
    map.classList.add("is-focused");
  }

  var pinned = null;

  /* Coming off a node, the rest of the graph comes back on a delay rather
     than the instant the pointer crosses the edge of a disc. Two reasons: a
     highlight that vanishes the moment you stop pointing at it is hard to
     read, because reading it means looking away from the thing under the
     cursor; and the gaps between discs are wide here, so travelling from one
     to its neighbour would otherwise flicker the whole picture on and off at
     every step. Pointing at something else cancels the wait immediately. */
  var FADE_AFTER = 500;
  var fading = null;

  function holdOff() {
    if (fading) { clearTimeout(fading); fading = null; }
  }

  function fadeBack() {
    holdOff();
    if (pinned) return;
    fading = setTimeout(function () { fading = null; clear(); }, FADE_AFTER);
  }

  function show(el) {
    var key = el.getAttribute("data-node") || el.getAttribute("data-link");
    light([nodeEls[key]]);
  }

  svg.addEventListener("mouseover", function (e) {
    if (pinned || dragging) return;
    var el = e.target.closest("[data-node], [data-link]");
    if (el) { holdOff(); show(el); } else { fadeBack(); }
  });
  svg.addEventListener("mouseleave", function () {
    if (!pinned && !dragging) fadeBack();
  });
  svg.addEventListener("focusin", function (e) {
    var el = e.target.closest("[data-node], [data-link]");
    if (el) { pinned = null; holdOff(); show(el); }
  });
  svg.addEventListener("focusout", function () {
    if (!pinned) fadeBack();
  });

  /* ---- a finding pins what it is about -------------------------------- */
  document.querySelectorAll("[data-focus-nodes], [data-focus-links]")
    .forEach(function (btn) {
      btn.addEventListener("click", function () {
        var item = btn.closest(".netfind__i");
        var already = item && item.classList.contains("is-picked");
        document.querySelectorAll(".netfind__i.is-picked")
          .forEach(function (el) { el.classList.remove("is-picked"); });
        if (already) { pinned = null; holdOff(); clear(); return; }

        var groups = [];
        (btn.getAttribute("data-focus-nodes") || "").split(/\s+/)
          .forEach(function (id) { if (id) groups.push(nodeEls[id]); });
        (btn.getAttribute("data-focus-links") || "").split(/\s+/)
          .forEach(function (id) { if (id) groups.push(linkEls[id]); });
        light(groups);
        pinned = btn;
        if (item) item.classList.add("is-picked");
        if (map.getBoundingClientRect().bottom < 120) {
          map.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
      });
    });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && pinned) {
      document.querySelectorAll(".netfind__i.is-picked")
        .forEach(function (el) { el.classList.remove("is-picked"); });
      pinned = null;
      holdOff();
      clear();
    }
  });

  /* ---- panning and zooming the plane ---------------------------------- */
  var home = svg.getAttribute("data-home");
  var dragging = false;
  if (!home) return;                      /* the two-column view: nothing to pan */

  function read(s) {
    var p = s.trim().split(/[\s,]+/).map(Number);
    return { x: p[0], y: p[1], w: p[2], h: p[3] };
  }
  var box = read(home);
  var start = read(home);

  /* Names are set in drawing units, which the browser then scales along with
     everything else - so zooming in would magnify a name exactly as much as
     the disc it labels and never give it any more room. Resetting the size
     against the current viewBox keeps a name the same number of pixels at
     every zoom, which is what makes zooming in a way to read more of them. */
  var names = svg.querySelector(".netplane__nodes");
  var basis = names ? parseFloat(names.getAttribute("font-size")) : 0;
  var span = basis ? basis / read(home).w : 0;

  function apply() {
    svg.setAttribute("viewBox",
      box.x.toFixed(1) + " " + box.y.toFixed(1) + " " +
      box.w.toFixed(1) + " " + box.h.toFixed(1));
    if (span) names.setAttribute("font-size", (span * box.w).toFixed(2));
  }

  /* Zoom about a point so the thing under the cursor stays under it.
     The limits clamp rather than refuse: a step that would overshoot used to
     be dropped entirely, so the last press before the limit did nothing at
     all and the button felt broken rather than finished. */
  var OUT_TO = 3, IN_TO = 40;

  function scale(factor, ax, ay) {
    var want = Math.min(Math.max(box.w * factor, start.w / IN_TO),
                        start.w * OUT_TO);
    if (Math.abs(want - box.w) < 0.01) return;
    var h = box.h * (want / box.w);
    box.x += (box.w - want) * ax;
    box.y += (box.h - h) * ay;
    box.w = want;
    box.h = h;
    apply();
  }

  svg.addEventListener("wheel", function (e) {
    e.preventDefault();
    var r = svg.getBoundingClientRect();
    scale(e.deltaY > 0 ? 1.15 : 1 / 1.15,
          (e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height);
  }, { passive: false });

  var from = null;
  /* Pointer capture is taken only once a drag is genuinely under way, never
     on the way down. Capturing on pointerdown retargets the pointer events
     to the element holding the capture, and the browser then dispatches the
     click there too — so every click landed on the <svg> instead of the <a>
     inside it, and clicking a disc did nothing at all. A plain click now
     never involves capture and reaches its link untouched.

     The threshold is in screen pixels rather than drawing units, because a
     drawing unit is a different distance at every zoom: three units is a
     third of a pixel when zoomed out, which turned the smallest wobble of
     the hand into a drag. */
  var DRAG_FROM = 4;
  var draggedAt = 0;

  svg.addEventListener("pointerdown", function (e) {
    if (e.button !== 0) return;
    from = { x: e.clientX, y: e.clientY, bx: box.x, by: box.y,
             moved: false, id: e.pointerId };
  });
  svg.addEventListener("pointermove", function (e) {
    if (!from) return;
    var mx = e.clientX - from.x, my = e.clientY - from.y;
    if (!from.moved && Math.abs(mx) + Math.abs(my) < DRAG_FROM) return;
    if (!from.moved) {
      from.moved = dragging = true;
      svg.classList.add("is-dragging");
      try { svg.setPointerCapture(from.id); } catch (err) { /* gone already */ }
    }
    var r = svg.getBoundingClientRect();
    box.x = from.bx - mx * box.w / r.width;
    box.y = from.by - my * box.h / r.height;
    apply();
  });

  /* A drag must not also count as a click on whatever it started over. One
     listener, always attached, rather than one added per drag — the old
     version added a one-shot that leaked whenever no click followed. */
  svg.addEventListener("click", function (e) {
    if (Date.now() - draggedAt < 250) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);

  function endDrag(e) {
    if (!from) return;
    if (from.moved) draggedAt = Date.now();
    if (e && e.pointerId !== undefined && svg.hasPointerCapture(e.pointerId)) {
      svg.releasePointerCapture(e.pointerId);
    }
    from = null;
    dragging = false;
    svg.classList.remove("is-dragging");
  }
  svg.addEventListener("pointerup", endDrag);
  svg.addEventListener("pointercancel", endDrag);

  /* Delegated from the figure and keyed on the attribute the buttons carry,
     not on the class of the box they sit in. The previous version looked for
     a container by class name, that class was renamed in the markup, and the
     listener silently attached to nothing — plus, minus and fit did exactly
     nothing and there was no error to notice. Nothing here depends on where
     the buttons live or what their wrapper is called. */
  map.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-zoom]");
    if (!btn || !map.contains(btn)) return;
    e.preventDefault();
    var how = btn.getAttribute("data-zoom");
    if (how === "home") { box = read(home); apply(); return; }
    scale(how === "in" ? 1 / 1.4 : 1.4, 0.5, 0.5);
  });
}());

/* The hover card.
 *
 * The browser's own tooltip waits a second, ignores the page's typography and
 * looks different on every machine. On a drawing whose entire purpose is to
 * be pointed at, that box is the most-read surface on the page, so it is
 * built here instead. The wording is composed server-side and carried on
 * data attributes; this only places it.
 *
 * It is fixed to the viewport rather than to the drawing, so it is never
 * clipped by the stage's overflow when a disc sits at the edge, and it
 * follows the pointer on an animation frame so a fast sweep across a hundred
 * discs costs one reposition per frame instead of one per mouse event.
 */
(function () {
  "use strict";

  var host = document.querySelector("[data-netmap]");
  if (!host) return;

  var card = document.createElement("div");
  card.className = "nettip";
  card.setAttribute("role", "tooltip");
  card.hidden = true;
  document.body.appendChild(card);

  var at = null, queued = false, over = null;

  function draw(el) {
    var rows = (el.getAttribute("data-tip-rows") || "")
      .split("|").filter(function (r) { return r; });
    var html = "<b></b><i></i><dl></dl><u></u>";
    card.innerHTML = html;
    card.querySelector("b").textContent = el.getAttribute("data-tip") || "";
    card.querySelector("i").textContent = el.getAttribute("data-tip-sub") || "";
    var dl = card.querySelector("dl");
    rows.forEach(function (r) {
      var d = document.createElement("dd");
      d.textContent = r;
      dl.appendChild(d);
    });
    var foot = el.getAttribute("data-tip-foot") || "";
    card.querySelector("u").textContent = foot;
    if (!foot) card.querySelector("u").remove();
    card.hidden = false;
  }

  /* Placed after it is visible, so its real size decides which way it flips. */
  function place() {
    queued = false;
    if (!at || card.hidden) return;
    var box = card.getBoundingClientRect();
    var pad = 14;
    var x = at.x + pad;
    var y = at.y + pad;
    if (x + box.width > window.innerWidth - 8) x = at.x - box.width - pad;
    if (y + box.height > window.innerHeight - 8) y = at.y - box.height - pad;
    card.style.transform = "translate(" + Math.max(8, Math.round(x)) + "px," +
      Math.max(8, Math.round(y)) + "px)";
  }

  function follow(e) {
    at = { x: e.clientX, y: e.clientY };
    if (!queued) { queued = true; requestAnimationFrame(place); }
  }

  function hide() {
    over = null;
    card.hidden = true;
    card.style.transform = "";
  }

  host.addEventListener("mouseover", function (e) {
    var el = e.target.closest("[data-tip]");
    if (!el) { if (over) hide(); return; }
    if (el !== over) { over = el; draw(el); }
    follow(e);
    place();
  });
  host.addEventListener("mousemove", function (e) { if (over) follow(e); });
  host.addEventListener("mouseleave", hide);
  /* A drag is not a hover, and the card should not ride along with it. */
  host.addEventListener("pointerdown", hide);
  window.addEventListener("scroll", hide, { passive: true });
  window.addEventListener("blur", hide);
}());
