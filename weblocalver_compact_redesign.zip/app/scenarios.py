"""The book, arranged the way the bank sent it: three workbooks.

This is a demo aid and nothing else. A maker never thinks in scenarios — the
worklist is indexed on the TF3 reference because that is what payment runs
against — but the people being shown this sent three files, each making a
different point, and when they ask "where did the Rothe Erde case come from"
the answer should take one click rather than a search through the source
folder.

Attribution is read out of the data rather than written down here: every
TradePay row carries the capture it was transcribed from, every booked deal
carries its scenario number, and the Autobahn pricing pages carry theirs. A
consignment the portal has no row for belongs to no capture, and is shown as
that rather than filed under a guess.
"""

from __future__ import annotations

import re

from .sources._data import load, normalise_name

# What each workbook is for. The counts and the cases underneath are derived;
# these are the one-line characterisations, which no amount of parsing will
# produce.
ABOUT = {
    1: {
        "file": "Scenario 1.xlsx",
        "what": "The TradePay portal, captured for five collections, with the "
                "FX deals booked against them.",
        "shows": "One TF3 reference carrying two Bills of Entry, a Bill of "
                 "Entry number used by two unrelated importers, and party "
                 "names the portal returns cut to its column width.",
    },
    2: {
        "file": "Scenario 2.xlsx",
        "what": "Three more collections from the portal, and their deals.",
        "shows": "Records that disagree: a drawer in Hong Kong paid as though "
                 "it were in mainland China, and an invoice in one currency "
                 "remitted in another.",
    },
    3: {
        "file": "Scenario 3.xlsx",
        "what": "The Products tab in Autobahn: the free-format pricing text "
                "held against a client.",
        "shows": "Prose that contradicts itself — one client priced per "
                 "document on one line and at remittance level on the next — "
                 "which is what the pricing agent has to read.",
    },
}


def _scenario_of(case) -> int | None:
    """Which workbook this consignment's portal record came from."""
    source = (case.tradepay or {}).get("_source") or ""
    found = re.search(r"Scenario\s+(\d+)", source)
    return int(found.group(1)) if found else None


def build(cases: list, groups: list[dict]) -> dict:
    """Each workbook, what came out of it, and what that is doing here."""
    deals = load("deals").get("records", [])
    pricing = load("autobahn").get("clients", [])

    out = []
    for number in (1, 2, 3):
        mine = [c for c in cases if _scenario_of(c) == number]
        keys = {c.case_id for c in mine}
        out.append({
            **ABOUT[number],
            "number": number,
            "collections": [g for g in groups
                            if any(c.case_id in keys for c in g["cases"])],
            "cases": mine,
            "deals": [d for d in deals if d.get("scenario") == number],
            # Only the third workbook carries pricing, and it carries all of it.
            "pricing": pricing if number == 3 else [],
            "valueInr": round(sum(c.charges.gross_inr for c in mine), 2),
        })

    # A consignment IDPMS holds that no portal capture covers. Hella's is the
    # only one, and it is the reason four of its checks cannot run, so it is
    # named rather than quietly left out of all three.
    orphans = [c for c in cases if _scenario_of(c) is None]
    return {
        "scenarios": out,
        "orphans": orphans,
        "orphanGroups": [g for g in groups
                         if any(c in orphans for c in g["cases"])],
        "totals": {
            "cases": len(cases),
            "placed": sum(len(s["cases"]) for s in out),
            "deals": len(deals),
            "pricing": len(pricing),
        },
    }


def pricing_match(client: str, cases: list) -> list[str]:
    """Which importers in the book a pricing page actually answers to."""
    want = normalise_name(client)
    return sorted({c.importer for c in cases
                   if want and (want in normalise_name(c.importer)
                                or normalise_name(c.importer) in want)})
