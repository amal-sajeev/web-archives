"""TradePay — the payment and invoice portal.

Stands in for the per-entity TradePay domains (cnsymrisetrade.ap and the rest).

Matching is the delicate part, and the key is the Bill of Entry **and** the
invoice number together — not the Bill of Entry with the invoice number kept
back as a tie-breaker. A Bill of Entry number is not unique: 9152082 is Hella's
consignment of 28 March 2025 through Gurgaon ICD *and* Rothe Erde's of 9 May
2026 through Mumbai. One number, two unrelated transactions, fourteen months
apart. Several invoices under one number is therefore the ordinary case rather
than an exception, and the thing that tells two transactions apart is the
invoice number.

So every lookup here takes the consignment's own invoice numbers and returns
only rows that carry one of them. Where none does, it returns nothing and says
which invoice it was looking for, rather than handing back a row that belongs
to somebody else's consignment.
"""

from __future__ import annotations

from ..text import listed, n
from ._data import normalise_name, normalise_ref, records


def all_records() -> list[dict]:
    return records("tradepay")


def rows_for_bill_of_entry(boe: str) -> list[dict]:
    return [r for r in all_records()
            if str(r.get("billOfEntryNumber")) == str(boe)]


def rows_for_invoice(invoice_no: str) -> list[dict]:
    """Every row carrying this invoice number, whatever Bill of Entry it is filed under.

    The other half of the key, searched on its own. A remittance filed against
    the wrong Bill of Entry is still the right remittance, and it is found here
    rather than reported missing.
    """
    want = normalise_ref(invoice_no)
    if not want:
        return []
    return [r for r in all_records()
            if normalise_ref(r.get("invoiceNo")) == want]


def for_consignment(boe: str, invoice_nos: list[str] | None = None) -> dict | None:
    """The TradePay record for one consignment, or None if it cannot be told.

    ``invoice_nos`` are the consignment's own invoice numbers, from IDPMS.
    Punctuation differs between the two systems — IDPMS holds INV2606/12999
    where the portal shows INV260612999 — so they are compared normalised.
    """
    rows = rows_for_bill_of_entry(boe)
    if not rows:
        return None

    wanted = {normalise_ref(n) for n in (invoice_nos or []) if n}
    matched = [r for r in rows if normalise_ref(r.get("invoiceNo")) in wanted] \
        if wanted else []

    if matched:
        head = dict(matched[0])
        if len(matched) > 1:
            # Several invoice rows under one remittance: the party and currency
            # are the record's, the amount is the sum of the rows matched.
            total = sum(float(r.get("invoiceAmount") or 0) for r in matched)
            head["invoiceAmount"] = round(total, 2)
            head["invoiceNo"] = ", ".join(str(r.get("invoiceNo")) for r in matched)
            head["matchedInvoiceCount"] = len(matched)
        return head

    if len(rows) == 1 and not wanted:
        # One row and no invoice number to match it on. Nothing else can be
        # done, so the Bill of Entry has to stand on its own here.
        return dict(rows[0])

    # Either the rows answer to none of this consignment's invoices, or there
    # are several and no invoice number to choose between them. Both are a
    # failure to identify the transaction, and neither is improved by guessing.
    return None


def coverage(boe: str, invoice_nos: list[str]) -> dict:
    """Which of a consignment's invoices TradePay holds a remittance for.

    This is the lookup done one invoice at a time rather than once for the
    Bill of Entry, which is what tells a maker that four of five invoices have
    been paid and names the fifth, instead of leaving the Bill of Entry looking
    either settled or broken as a whole.
    """
    rows = rows_for_bill_of_entry(boe)
    by_invoice: dict[str, dict] = {}
    for r in rows:
        key = normalise_ref(r.get("invoiceNo"))
        if key:
            by_invoice[key] = r

    matched, missing = [], []
    for n in invoice_nos:
        if not n:
            continue
        row = by_invoice.get(normalise_ref(n))
        (matched if row else missing).append(n)

    # Rows under this number that belong to no invoice of this consignment:
    # another transaction that happens to share the Bill of Entry number.
    mine = {normalise_ref(ref) for ref in invoice_nos if ref}
    foreign = [r for r in rows if normalise_ref(r.get("invoiceNo")) not in mine]

    # An invoice with no row under its own Bill of Entry may still have one
    # filed under a different number. Saying "no remittance" without looking is
    # the same mistake as matching on the Bill of Entry alone, in reverse.
    elsewhere = {}
    for ref in missing:
        found = [r for r in rows_for_invoice(ref)
                 if str(r.get("billOfEntryNumber")) != str(boe)]
        if found:
            elsewhere[str(ref)] = found

    return {"matched": matched, "missing": missing, "rows": len(rows),
            "foreignRows": foreign, "elsewhere": elsewhere,
            "absent": [ref for ref in missing if str(ref) not in elsewhere]}


def _dates(rows: list[dict]) -> list[str]:
    return sorted({str(r.get("billOfEntryDate")) for r in rows
                   if r.get("billOfEntryDate")})


def why_no_match(boe: str, invoice_nos: list[str] | None = None,
                 boe_date: str | None = None) -> str | None:
    """Why the lookup came back empty, for the maker.

    Written from the invoice number out, because that is what was looked up.
    Three sentences at most: what was not found, what sits under the number
    instead, and the dates that settle whether the two are the same Bill of
    Entry or only the same figure.
    """
    mine = [str(ref) for ref in (invoice_nos or []) if ref]
    if not mine:
        named = "this consignment"
    elif len(mine) == 1:
        named = f"invoice {mine[0]}"
    else:
        named = f"{n(len(mine), 'invoice')} {listed(mine)}"

    # Before saying no remittance exists, look for these invoice numbers under
    # every other Bill of Entry. One found there is misfiled, not missing.
    misfiled = {}
    for ref in mine:
        found = [r for r in rows_for_invoice(ref)
                 if str(r.get("billOfEntryNumber")) != str(boe)]
        if found:
            misfiled[ref] = sorted({str(r.get("billOfEntryNumber")) for r in found})
    if misfiled:
        shown = [f"{ref} under {listed(where)}" for ref, where in
                 list(misfiled.items())[:3]]
        return (f"No TradePay row carries {named} under Bill of Entry {boe}, but "
                f"TradePay does hold {listed(shown, limit=3)}. The remittance "
                "exists and is filed against a different Bill of Entry.")

    # The first sentence is the one the queue shows as the case's headline, so
    # it carries the fact and nothing else. Everything that makes it stand up
    # goes in the sentences after it, each beginning with a word rather than a
    # figure so the split that finds the heading fires in the right place.
    rows = rows_for_bill_of_entry(boe)
    held = f"TradePay holds no remittance for {named}."
    searched = (f"Nothing under Bill of Entry {boe}, or under any other number, "
                "carries it.")
    if not rows:
        return f"{held} {searched}"

    others = sorted({str(r.get("invoiceNo")) for r in rows
                     if normalise_ref(r.get("invoiceNo"))
                     not in {normalise_ref(ref) for ref in mine}})
    if not others:
        return f"{held} {searched}"

    theirs = [d for d in _dates(rows) if d != (boe_date or "")]
    dated = f", against a Bill of Entry dated {listed([_say(d) for d in theirs])}" \
        if theirs else ""
    apart = (f", which is dated {_say(boe_date)}" if boe_date and theirs
             else " under the same number")
    instead = (f"The {n(len(others), 'row')} that do sit under {boe} "
               f"{'carries' if len(others) == 1 else 'carry'} {listed(others)}"
               f"{dated} \u2014 a different transaction from this one{apart}.")
    return f"{held} {searched} {instead}"


_MONTHS = ("January", "February", "March", "April", "May", "June", "July",
           "August", "September", "October", "November", "December")


def _say(iso: str) -> str:
    """2026-05-09 as 9 May 2026. Dates in prose are not read as figures."""
    try:
        y, m, d = (int(p) for p in str(iso).split("-")[:3])
        return f"{d} {_MONTHS[m - 1]} {y}"
    except (ValueError, IndexError):
        return str(iso)


def for_bill_of_entry(boe: str, invoice_no: str | None = None) -> dict | None:
    """For the mock API. Returns a row only when one can be identified.

    Without an invoice number this can only answer where the Bill of Entry
    carries a single row; it will not pick the first of several, which is the
    mistake the invoice number exists to prevent.
    """
    return for_consignment(boe, [invoice_no] if invoice_no else None)


def for_importer(name: str) -> list[dict]:
    want = normalise_name(name)
    return [r for r in all_records() if normalise_name(r.get("entity")) == want]
