"""The external systems, mocked.

Each module here stands in for a system the bank has not given us access to:

    idpms      the import transaction extract
    tradepay   the payment and invoice portal
    ports      the port directory lookup (Volza)
    autobahn   the per-client pricing text held in OEMS
    checks     the consistency rules between IDPMS and TradePay
    tf3        the trade processing system we post the final record to

They read the JSON under ``app/data`` and nothing else, so swapping one for a
real integration means replacing a single module. Every one is also exposed
over HTTP under ``/api/mock`` so you can call it, inspect it, or point another
client at it.
"""

from . import autobahn, checks, idpms, ports, tf3, tradepay  # noqa: F401

__all__ = ["idpms", "tradepay", "ports", "autobahn", "checks", "tf3"]
