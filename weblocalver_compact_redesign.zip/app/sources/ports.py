"""The port directory.

Stands in for the Volza lookup. The directory itself has not been supplied yet,
so every lookup reports that it is awaiting the export rather than pretending a
code could not be found.

The search rule is already known and is applied regardless:
  a five-digit code is searched as it stands;
  a three-digit code has the two-letter country code prepended first.
"""

from __future__ import annotations

from ._data import load


def _directory() -> dict[str, dict]:
    return {p["code"].upper(): p for p in load("ports").get("ports", []) if p.get("code")}


def directory_loaded() -> bool:
    return bool(_directory())


def search_term(code: str, country_iso2: str | None = None) -> str:
    """What to search the directory for, per the rule."""
    code = (code or "").strip().upper()
    if len(code) == 3 and country_iso2:
        return f"{country_iso2.strip().upper()}{code}"
    return code


def resolve(code: str, country_iso2: str | None = None) -> dict:
    """Resolve a port code to its full name.

    Always reports which term was searched, so a maker can see why a lookup
    behaved the way it did.
    """
    raw = (code or "").strip().upper()
    term = search_term(raw, country_iso2)
    result = {
        "code": raw,
        "searchedAs": term,
        "prefixApplied": term != raw,
        "countryHint": (country_iso2 or "").upper() or None,
    }

    if not raw:
        return {**result, "status": "invalid", "name": None,
                "message": "No port code on the record."}

    if not directory_loaded():
        return {**result, "status": "directory_unavailable", "name": None,
                "message": "The port directory has not been loaded. Drop the export "
                           "into app/data/ports.json and this resolves itself."}

    hit = _directory().get(term) or _directory().get(raw)
    if hit:
        return {**result, "status": "resolved", "name": hit.get("name"),
                "city": hit.get("city"), "country": hit.get("country"),
                "unlocode": hit.get("unlocode"), "message": None}

    return {**result, "status": "not_found", "name": None,
            "message": f"{term} is not in the port directory."}


def status() -> dict:
    data = load("ports")
    return {
        "loaded": directory_loaded(),
        "count": len(data.get("ports", [])),
        "awaitingDirectory": data.get("awaitingDirectory", False),
        "searchRule": data.get("searchRule", {}),
        "codesSeenInData": data.get("codesSeenInData", []),
    }
