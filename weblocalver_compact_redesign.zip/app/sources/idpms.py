"""IDPMS — the import transaction extract.

Stands in for the customs feed. The real thing delivers one row per invoice
line, so a Bill of Entry carrying several invoices appears several times; the
procedure says to deduplicate before anything reaches TF3.
"""

from __future__ import annotations

from ._data import normalise_ref, records


def all_lines() -> list[dict]:
    """Every row as supplied, repeats included."""
    return records("idpms")


def bills_of_entry() -> list[str]:
    seen: list[str] = []
    for r in all_lines():
        boe = r["billOfEntryNumber"]
        if boe not in seen:
            seen.append(boe)
    return seen


def lines_for(boe: str, invoice_no: str | None = None) -> list[dict]:
    """Lines for a Bill of Entry, narrowed by invoice when one is given.

    The key is the Bill of Entry and the invoice number together. Asking for an
    invoice that is not under this number returns nothing: falling back to
    every line under the number would hand back another importer's transaction,
    since the number is not unique.
    """
    rows = [r for r in all_lines() if r["billOfEntryNumber"] == str(boe)]
    if invoice_no:
        want = normalise_ref(invoice_no)
        return [r for r in rows if normalise_ref(r.get("invoiceNo")) == want]
    return rows


def consignments() -> list[dict]:
    """One entry per distinct Bill of Entry *and* importer.

    A Bill of Entry number is not unique and a single number ordinarily carries
    several invoices. 9152082 is Hella's consignment of 28 March 2025 through
    Gurgaon ICD and Rothe Erde's of 9 May 2026 through Mumbai — one number, two
    unrelated transactions. So the number alone identifies nothing: a
    transaction is its Bill of Entry together with its invoice numbers, and the
    importer is what groups those invoices into one piece of work.
    """
    grouped: dict[tuple[str, str], list[dict]] = {}
    for r in all_lines():
        key = (r["billOfEntryNumber"], r.get("IEName") or "")
        grouped.setdefault(key, []).append(r)

    out = []
    for (boe, importer), lines in grouped.items():
        # dedupe identical invoice lines, keeping the latest shipment
        by_invoice: dict[str, dict] = {}
        for line in lines:
            key = normalise_ref(line.get("invoiceNo")) or line["recordId"]
            prior = by_invoice.get(key)
            if prior is None or _shipment_date(line) > _shipment_date(prior):
                by_invoice[key] = line
        unique = list(by_invoice.values())
        head = unique[0]

        out.append({
            "billOfEntryNumber": boe,
            "importer": importer,
            "importerAddress": head.get("IEAddress"),
            "importerCode": head.get("IECode"),
            "importerPan": head.get("IEPANNumber"),
            "adCode": head.get("ADCode"),
            "billOfEntryDate": head.get("billOfEntryDate"),
            "portOfShipment": head.get("portOfShipment"),
            "portOfDischarge": head.get("portOfDischarge"),
            "supplierCountryIso2": head.get("supplierCountryIso2"),
            "latestShipmentDate": _shipment_date(max(unique, key=_shipment_date)) or None,
            "invoiceLines": unique,
            "duplicateLinesRemoved": len(lines) - len(unique),
            "sharesBoeWithAnotherImporter": _shared(boe, importer),
            "thirdParties": _third_parties(unique),
        })
    out.sort(key=lambda c: (c["billOfEntryDate"] or "", c["billOfEntryNumber"]), reverse=True)
    return out


def _shipment_date(line: dict) -> str:
    """Latest of the transport dates on the line; the procedure asks for it."""
    return max(str(line.get(k) or "") for k in ("HAWB-HBLDate", "MAWB-MBLDate", "IGMDate"))


def _shared(boe: str, importer: str) -> bool:
    others = {r.get("IEName") for r in all_lines() if r["billOfEntryNumber"] == boe}
    return len({o for o in others if o}) > 1


def _third_parties(lines: list[dict]) -> list[dict]:
    """Parties other than the drawer and the drawee."""
    out, seen = [], set()
    for line in lines:
        name = line.get("thirdPartyName")
        if name and name not in seen:
            seen.add(name)
            out.append({
                "name": name,
                "address": line.get("thirdPartyAddress"),
                "country": line.get("thirdPartyCountry"),
            })
        # a seller distinct from the supplier is a third party too
        seller = line.get("sellerName")
        if seller and seller != line.get("supplierName") and seller not in seen:
            seen.add(seller)
            out.append({
                "name": seller,
                "address": line.get("sellerAddress"),
                "country": line.get("sellerCountry"),
                "role": "seller",
            })
    return out
