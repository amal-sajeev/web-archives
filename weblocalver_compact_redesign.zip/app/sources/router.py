"""The mock external systems, over HTTP.

Mounted under /api/mock. The application calls the modules directly rather than
coming back through HTTP, but these endpoints exist so the seam is real: you can
curl them, show them to the bank, and when a system becomes available you point
a client at the live URL and delete the module behind it.
"""

from __future__ import annotations

from fastapi import APIRouter, Body, HTTPException, Query

from . import autobahn, checks, idpms, ports, tf3, tradepay
from ._data import load, reload
from ..text import listed, n

router = APIRouter(prefix="/api/mock", tags=["mock external systems"])


@router.get("/", summary="What is mocked, and where the data came from")
def index() -> dict:
    return {
        "systems": {
            "idpms": "/api/mock/idpms — import transactions from the customs extract",
            "tradepay": "/api/mock/tradepay — payment and invoice records",
            "ports": "/api/mock/ports/{code} — port code to full name",
            "autobahn": "/api/mock/autobahn/{client} — pricing text, parsed",
            "checks": "/api/mock/checks/{boe} — consistency between IDPMS and TradePay",
            "tf3": "/api/mock/tf3 — post the validated record",
        },
        "data": {name: load(name).get("source") for name in
                 ("idpms", "tradepay", "autobahn", "fx", "deals", "ports", "checks")},
    }


# --------------------------------------------------------------- IDPMS ----

@router.get("/idpms", summary="Import transactions")
def get_idpms(boe: str | None = Query(default=None, description="Bill of Entry"),
              invoice: str | None = Query(default=None)) -> dict:
    if boe:
        lines = idpms.lines_for(boe, invoice)
        if not lines:
            raise HTTPException(404, f"No IDPMS record for Bill of Entry {boe}")
        return {"billOfEntryNumber": boe, "lines": lines}
    return {"count": len(idpms.all_lines()), "lines": idpms.all_lines()}


@router.get("/idpms/consignments", summary="Transactions, deduplicated")
def get_consignments() -> dict:
    rows = idpms.consignments()
    return {"count": len(rows), "consignments": rows}


# ------------------------------------------------------------ TradePay ----

@router.get("/tradepay", summary="Payment and invoice records")
def get_tradepay(boe: str | None = None, invoice: str | None = None) -> dict:
    if boe:
        rec = tradepay.for_bill_of_entry(boe, invoice)
        if rec is None:
            rows = tradepay.rows_for_bill_of_entry(boe)
            if len(rows) > 1 and not invoice:
                # The number is not a key on its own, and picking the first row
                # would hand back whichever transaction happens to be first.
                raise HTTPException(409, (
                    f"Bill of Entry {boe} carries {n(len(rows), 'invoice row')}, "
                    "which may belong to more than one transaction. Add the "
                    f"invoice number: ?boe={boe}&invoice=<invoiceNo>. The rows are "
                    "for " + listed([r.get("invoiceNo") for r in rows], limit=8)))
            if invoice:
                # The invoice number is half the key, so it is worth saying
                # whether the row is missing or merely filed elsewhere.
                found = tradepay.rows_for_invoice(invoice)
                raise HTTPException(404, (
                    f"No TradePay record for Bill of Entry {boe} and invoice "
                    f"{invoice}. " + (
                        "That invoice is held under Bill of Entry "
                        + listed(sorted({str(r.get("billOfEntryNumber"))
                                         for r in found}))
                        + " instead." if found else
                        "No Bill of Entry in TradePay carries that invoice "
                        "number.")))
            raise HTTPException(404, f"No TradePay record for Bill of Entry {boe}")
        return rec
    return {"count": len(tradepay.all_records()), "records": tradepay.all_records()}


# --------------------------------------------------------------- ports ----

@router.get("/ports/status", summary="Is the port directory loaded?")
def port_status() -> dict:
    return ports.status()


@router.get("/ports/{code}", summary="Resolve a port code to its full name")
def get_port(code: str, country: str | None = Query(
        default=None, description="2-letter country code, needed for a 3-digit port code")
) -> dict:
    return ports.resolve(code, country)


# ------------------------------------------------------------ Autobahn ----

@router.get("/autobahn", summary="Every client with pricing on file")
def autobahn_clients() -> dict:
    rows = autobahn.clients()
    return {"count": len(rows), "clients": rows}


@router.get("/autobahn/{client}", summary="Pricing text for a client, parsed")
def autobahn_client(client: str) -> dict:
    entry = autobahn.instruction_for(client)
    if entry is None:
        raise HTTPException(404, f"No processing instruction held for {client}")
    return {**entry, "reading": autobahn.parse(entry["processingText"])}


@router.get("/autobahn/{client}/quote", summary="What to charge")
def autobahn_quote(client: str, documents: int = 1, gross_inr: float = 0.0) -> dict:
    return autobahn.quote(client, documents=documents, gross_inr=gross_inr)


# -------------------------------------------------------------- checks ----

@router.get("/checks", summary="The checks that are run, as specified")
def check_definitions() -> dict:
    return load("checks")


@router.get("/checks/{boe}", summary="Run the checks for a Bill of Entry")
def run_checks(boe: str, importer: str | None = None) -> dict:
    matches = [c for c in idpms.consignments()
               if c["billOfEntryNumber"] == str(boe)
               and (importer is None or c["importer"] == importer)]
    if not matches:
        raise HTTPException(404, f"No consignment for Bill of Entry {boe}")
    if len(matches) > 1 and importer is None:
        raise HTTPException(409, {
            "message": f"Bill of Entry {boe} is held by more than one importer. "
                       "Name the importer.",
            "importers": [c["importer"] for c in matches],
        })
    consignment = matches[0]
    record = tradepay.for_consignment(
        boe, [l.get("invoiceNo") for l in consignment["invoiceLines"]])
    results = checks.run(consignment, record)
    return {"billOfEntryNumber": boe, "importer": consignment["importer"],
            "summary": checks.summary(results), "checks": results}


# ----------------------------------------------------------------- TF3 ----

@router.post("/tf3", summary="Post a validated record to TF3")
def post_tf3(payload: dict = Body(...)) -> dict:
    result = tf3.post(payload)
    if not result["accepted"]:
        raise HTTPException(422, result["message"])
    return result


@router.get("/tf3", summary="Everything posted so far")
def list_tf3() -> dict:
    rows = tf3.all_postings()
    return {"count": len(rows), "postings": rows}


@router.get("/tf3/{reference}", summary="One posting")
def get_tf3(reference: str) -> dict:
    rec = tf3.get(reference)
    if rec is None:
        raise HTTPException(404, f"{reference} was not found in TF3")
    return rec


# ---------------------------------------------------------------- admin ---

@router.post("/reload", summary="Re-read the JSON files from disk")
def reload_data() -> dict:
    reload()
    return {"reloaded": True,
            "ports": ports.status(),
            "message": "Data files re-read. Dropping in the port directory takes "
                       "effect immediately."}
