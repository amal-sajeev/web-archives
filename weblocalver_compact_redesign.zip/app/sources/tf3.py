"""TF3 — the trade processing system.

Stands in for the system the validated record is finally posted to. There is no
API yet, so postings are held in memory and can be read back; swapping this for
the real call is a change to one function.

What gets posted is what the procedure names: the resolved ports, the third
party details, and the charges, against the Bill of Entry.
"""

from __future__ import annotations

import threading
from datetime import datetime

_lock = threading.RLock()
_posted: dict[str, dict] = {}
_seq = 0


def post(payload: dict) -> dict:
    """Post a validated record. Returns the TF3 reference it was filed under."""
    global _seq
    required = ("billOfEntryNumber", "importer", "portOfLoading", "portOfDischarge")
    missing = [f for f in required if not payload.get(f)]
    if missing:
        return {"accepted": False,
                "message": "TF3 rejected the posting; these are required: "
                           + ", ".join(missing)}

    with _lock:
        _seq += 1
        boe = str(payload["billOfEntryNumber"])
        reference = f"TF3-{datetime.now():%Y}-{_seq:05d}"
        record = {
            **payload,
            "tf3Reference": reference,
            "postedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        _posted[reference] = record

    return {"accepted": True, "tf3Reference": reference,
            "message": f"Filed against Bill of Entry {boe} as {reference}.",
            "record": record}


def get(reference: str) -> dict | None:
    return _posted.get(reference)


def all_postings() -> list[dict]:
    with _lock:
        return sorted(_posted.values(), key=lambda r: r["postedAt"], reverse=True)


def reset() -> None:
    """Clear the postings. Used when the demo is restarted."""
    global _seq
    with _lock:
        _posted.clear()
        _seq = 0
