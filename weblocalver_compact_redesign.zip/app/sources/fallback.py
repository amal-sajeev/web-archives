"""The second and third places to look, when IDPMS does not carry a field.

The procedure does not treat IDPMS as the only reference. Each consistency
check is written as

    Drawer Name:    Trade Pay  <->  IDPMS / Trade Pay Documents / WFMS
    Drawer Country: Trade Pay  <->  IDPMS / Trade Pay Documents / WFMS
    Currency:       Trade Pay  <->  IDPMS / Trade Pay Documents / WFMS

and step 6 says plainly: *"If the required information is incomplete or
unavailable in IDPMS, refer to the supporting documents attached in Trade Pay
and extract the necessary details from those documents."*

So the right-hand side of every check is a cascade, not a single system:

    1. IDPMS                    — connected, the extract in app/data/idpms.json
    2. TradePay supporting documents — the portal's Document Repository
    3. WFMS                     — the workflow management system

Neither of the last two has been supplied, so they are declared here and report
themselves unavailable, exactly as the port directory did before its export
arrived. A check that needs them says which source it is waiting on instead of
failing or quietly passing. When a real integration is dropped in, only this
module changes.
"""

from __future__ import annotations

from typing import Any, Callable

from . import idpms

# Each source: a name, whether it is connected, and how to read a field from it.
_DOCUMENTS_NOTE = (
    "The supporting documents attached in TradePay have not been supplied. In "
    "the portal they sit under Review → Document Repository; a maker can "
    "open them there."
)
_WFMS_NOTE = (
    "WFMS has not been connected, so the third source in the cascade cannot be "
    "consulted."
)


def _from_idpms(field: str, head: dict, consignment: dict) -> Any:
    value = head.get(field)
    if value in (None, ""):
        # The field may be populated on another line of the same consignment.
        for line in consignment.get("invoiceLines", []):
            if line.get(field) not in (None, ""):
                return line[field]
    return value


def documents_available() -> bool:
    return False


def wfms_available() -> bool:
    return False


def resolve(field: str, head: dict, consignment: dict) -> dict:
    """Read a field from the first source in the cascade that carries it.

    Returns the value, which source supplied it, and — when nothing could —
    which source the case is waiting on and why.
    """
    value = _from_idpms(field, head, consignment)
    if value not in (None, ""):
        return {"value": value, "source": "IDPMS", "status": "found",
                "message": None, "consulted": ["IDPMS"]}

    consulted = ["IDPMS"]

    if documents_available():  # pragma: no cover - nothing supplied yet
        consulted.append("TradePay documents")
    else:
        return {"value": None, "source": None, "status": "awaiting_source",
                "waitingOn": "TradePay supporting documents",
                "consulted": consulted,
                "message": f"IDPMS does not carry {field} for this consignment. "
                           f"The next source is the supporting documents attached "
                           f"in TradePay. {_DOCUMENTS_NOTE}"}

    if wfms_available():  # pragma: no cover - nothing supplied yet
        consulted.append("WFMS")
    else:
        return {"value": None, "source": None, "status": "awaiting_source",
                "waitingOn": "WFMS", "consulted": consulted,
                "message": f"IDPMS and the TradePay documents do not carry "
                           f"{field}. {_WFMS_NOTE}"}

    return {"value": None, "source": None, "status": "not_found",
            "consulted": consulted,
            "message": f"{field} could not be found in IDPMS, the TradePay "
                       "supporting documents or WFMS."}


def status() -> dict:
    """What the cascade looks like right now, for the reference page."""
    return {
        "order": [
            {"source": "IDPMS", "connected": True,
             "detail": "The extract in app/data/idpms.json.",
             "role": "first reference"},
            {"source": "TradePay supporting documents",
             "connected": documents_available(),
             "detail": _DOCUMENTS_NOTE,
             "role": "used where IDPMS is incomplete"},
            {"source": "WFMS", "connected": wfms_available(),
             "detail": _WFMS_NOTE,
             "role": "last reference"},
        ],
        "quotedAs": "Trade Pay ↔ IDPMS / Trade Pay Documents / WFMS",
        "rule": "If the required information is incomplete or unavailable in "
                "IDPMS, refer to the supporting documents attached in TradePay "
                "and extract the necessary details from those documents.",
    }
