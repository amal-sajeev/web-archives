"""A spatial layout for the counterparty graph: everyone in one plane.

Two columns of chips is a one-dimensional layout, and one dimension runs out.
Twenty-two rows is about what a screen holds, so a book with three hundred
counterparties in it has to be folded before it can be drawn, and folding hides
the thing the page exists to show. A plane does not run out the same way: three
hundred discs at a readable size fit in a viewport with room to spare, and
where they end up *is itself information* - the things that trade with each
other end up near each other.

So this lays the graph out the way a notes app lays out a vault. The shape of
real trade data decides how:

    the real sample   17 entities,   8 components, largest 3, median degree 1

Most counterparties sell to exactly one importer, so the graph is not one
tangle, it is a scatter of small stars with the occasional hub bridging a few.
A single force simulation over all of it would be wrong twice: disconnected
pieces have nothing pushing them apart except a centring force they would all
pile into, and a force run is wasted on a component of two nodes whose layout
is a line. Instead:

  * split into connected components;
  * lay each one out on its own - analytically where its shape is known (a
    point, a pair, a star), and with Fruchterman-Reingold where it is not;
  * pack the components into the viewport, biggest first, on a spiral.

That also makes it fast, because the expensive part only runs on the pieces
that need it. And it is deterministic: seeded on a golden-angle spiral in a
stable order, with no random number generator anywhere, so the same book draws
the same picture every time. A layout that rearranges itself on every reload is
not a thing anybody can learn, point at, or screenshot for a meeting.

It all runs here rather than in the browser, so the page arrives as finished
SVG. Panning and zooming are a viewBox; they do not re-run any of this.
"""

from __future__ import annotations

import math
from typing import Iterable

GOLDEN = math.pi * (3.0 - math.sqrt(5.0))


# ---------------------------------------------------------------------------
# components
# ---------------------------------------------------------------------------

def components(ids: list[str], edges: Iterable[tuple[str, str]]
               ) -> list[list[str]]:
    """The connected pieces, each in a stable order.

    Iterative rather than recursive: a long chain of transactions would put a
    recursive walk into the interpreter's stack limit, and this runs on data
    nobody here controls.
    """
    adj: dict[str, set[str]] = {i: set() for i in ids}
    for a, b in edges:
        if a in adj and b in adj and a != b:
            adj[a].add(b)
            adj[b].add(a)

    seen: set[str] = set()
    out: list[list[str]] = []
    for start in ids:                      # ids order fixes the output order
        if start in seen:
            continue
        seen.add(start)
        stack, group = [start], [start]
        while stack:
            node = stack.pop()
            for peer in sorted(adj[node]):
                if peer not in seen:
                    seen.add(peer)
                    stack.append(peer)
                    group.append(peer)
        out.append(group)
    return out, adj


# ---------------------------------------------------------------------------
# one component
# ---------------------------------------------------------------------------

def _ring(group: list[str], adj: dict[str, set[str]], radius: dict[str, float],
          gap: float) -> dict[str, tuple[float, float]] | None:
    """A star laid out as a hub and a ring, which is what a star looks like.

    Most components here are one importer and the counterparties that sell to
    it. Running a force simulation on that produces a hub and a ring after a
    few hundred iterations; placing one directly produces a better one
    immediately, and an evenly spaced ring rather than a lumpy one.
    """
    hubs = [n for n in group if len(adj[n]) == len(group) - 1]
    if not hubs or len(group) < 3:
        return None
    hub = max(hubs, key=lambda n: (radius[n], n))
    leaves = [n for n in group if n != hub]
    if any(len(adj[n]) != 1 for n in leaves):
        return None                         # not a pure star

    # The ring has to be wide enough that no two leaves touch.
    biggest = max(radius[n] for n in leaves)
    need = (biggest * 2 + gap) * len(leaves) / (2 * math.pi)
    r = max(radius[hub] + biggest + gap * 1.6, need)
    out = {hub: (0.0, 0.0)}
    for i, leaf in enumerate(leaves):
        a = GOLDEN * 0 + 2 * math.pi * i / len(leaves) - math.pi / 2
        out[leaf] = (r * math.cos(a), r * math.sin(a))
    return out


def _spread(group: list[str], adj: dict[str, set[str]],
            radius: dict[str, float], gap: float,
            weights: dict[tuple[str, str], float]) -> dict[str, tuple[float, float]]:
    """Fruchterman-Reingold, seeded deterministically, with grid repulsion.

    Repulsion between every pair is quadratic, which is fine for the twenty
    nodes a component usually has and not fine for the few hundred a dense
    book puts in one piece. Past a threshold the nodes go into a uniform grid
    and only neighbouring cells repel, which is the same idea as Barnes-Hut
    with far less machinery: beyond two cells the force is small enough that
    leaving it out moves nothing a person could see.
    """
    n = len(group)
    # k is Fruchterman-Reingold's ideal *edge length*: how far apart two nodes
    # that are joined should finish. That is a property of how big a node is,
    # not of how many there are - scaling it by the square root of n (as the
    # classic formulation does, where it derives k from a fixed drawing area)
    # spreads a fifty-node component over a thousand pixels of mostly nothing,
    # and the whole picture then has to be shrunk until the nodes are specks.
    # Here the area follows from the layout rather than the other way round.
    ideal = max(radius[nid] for nid in group) * 2 + gap
    k = ideal * 1.15

    # Seed on a golden-angle spiral, biggest first: deterministic, and already
    # roughly the right shape, so the simulation has less to undo.
    order = sorted(group, key=lambda nid: (-radius[nid], nid))
    pos: dict[str, list[float]] = {}
    span = k * math.sqrt(n) * 0.5
    for i, nid in enumerate(order):
        r = span * math.sqrt((i + 0.5) / n)
        a = i * GOLDEN
        pos[nid] = [r * math.cos(a), r * math.sin(a)]

    # The frame a component is allowed to occupy: wide enough that n nodes at
    # spacing k fit comfortably, tight enough that they stay a cluster.
    frame = k * math.sqrt(n) * 0.55
    iterations = 260 if n <= 40 else (160 if n <= 160 else 110)
    temp = k * 1.1
    cool = temp / (iterations + 1)
    grid_on = n > 60
    cell = k * 2.0

    for _ in range(iterations):
        disp = {nid: [0.0, 0.0] for nid in group}

        # --- repulsion ---------------------------------------------------
        if grid_on:
            buckets: dict[tuple[int, int], list[str]] = {}
            for nid, (x, y) in pos.items():
                buckets.setdefault((int(x // cell), int(y // cell)), []).append(nid)
            for (cx, cy), here in buckets.items():
                near: list[str] = []
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        near.extend(buckets.get((cx + dx, cy + dy), ()))
                for a in here:
                    ax, ay = pos[a]
                    da = disp[a]
                    for b in near:
                        if a is b:
                            continue
                        rx, ry = ax - pos[b][0], ay - pos[b][1]
                        d2 = rx * rx + ry * ry
                        if d2 < 1e-9:
                            rx, ry, d2 = (hash(a) % 7 - 3) or 1.0, 1.0, 10.0
                        f = (k * k) / d2
                        da[0] += rx * f
                        da[1] += ry * f
        else:
            for i, a in enumerate(order):
                ax, ay = pos[a]
                da = disp[a]
                for b in order[i + 1:]:
                    rx, ry = ax - pos[b][0], ay - pos[b][1]
                    d2 = rx * rx + ry * ry
                    if d2 < 1e-9:
                        rx, ry, d2 = 1.0, 1.0, 10.0
                    f = (k * k) / d2
                    da[0] += rx * f
                    da[1] += ry * f
                    disp[b][0] -= rx * f
                    disp[b][1] -= ry * f

        # --- attraction along the edges -----------------------------------
        for a in group:
            for b in adj[a]:
                if b <= a or b not in pos:
                    continue
                rx, ry = pos[a][0] - pos[b][0], pos[a][1] - pos[b][1]
                d = math.hypot(rx, ry) or 0.01
                w = min(max(weights.get((a, b)) or weights.get((b, a)) or 1.0,
                            0.4), 2.0)
                f = (d * d) / k * w
                ux, uy = rx / d * f, ry / d * f
                disp[a][0] -= ux
                disp[a][1] -= uy
                disp[b][0] += ux
                disp[b][1] += uy

        # --- move, capped by the temperature, kept inside the frame -------
        # Fruchterman-Reingold is defined on a bounded frame, and the bound is
        # not decoration: nodes that share no edge feel only repulsion, so
        # without something holding them in, a sparse component inflates for
        # as many iterations as it is given. Leaving it out gave a fifty-seven
        # node component a radius of 1,392 where 220 was right, and the whole
        # picture then had to be scaled down until every node was a speck.
        for nid in group:
            dx, dy = disp[nid]
            d = math.hypot(dx, dy)
            p = pos[nid]
            if d > 1e-9:
                step = min(d, temp)
                p[0] += dx / d * step
                p[1] += dy / d * step
            out = math.hypot(p[0], p[1])
            if out > frame:
                p[0] *= frame / out
                p[1] *= frame / out
        temp -= cool

    _unoverlap(order, pos, radius, gap)
    return {nid: (xy[0], xy[1]) for nid, xy in pos.items()}


def _unoverlap(order: list[str], pos: dict[str, list[float]],
               radius: dict[str, float], gap: float, rounds: int = 24) -> None:
    """Push apart any two discs that still touch.

    Fruchterman-Reingold knows about points, not about how big the things it
    is placing are, so a large node and a small one can finish on top of each
    other. A few rounds of pairwise separation afterwards is cheaper and more
    reliable than trying to teach the simulation about radii.
    """
    n = len(order)
    if n < 2:
        return
    cell = max((radius[i] for i in order), default=1.0) * 2 + gap
    for _ in range(rounds):
        moved = False
        buckets: dict[tuple[int, int], list[str]] = {}
        for nid in order:
            x, y = pos[nid]
            buckets.setdefault((int(x // cell), int(y // cell)), []).append(nid)
        for (cx, cy), here in buckets.items():
            near: list[str] = []
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    near.extend(buckets.get((cx + dx, cy + dy), ()))
            for a in here:
                for b in near:
                    if a >= b:
                        continue
                    want = radius[a] + radius[b] + gap
                    rx, ry = pos[a][0] - pos[b][0], pos[a][1] - pos[b][1]
                    d = math.hypot(rx, ry)
                    if d >= want:
                        continue
                    if d < 1e-6:
                        rx, ry, d = 1.0, 0.0, 1.0
                    push = (want - d) / 2
                    ux, uy = rx / d * push, ry / d * push
                    pos[a][0] += ux
                    pos[a][1] += uy
                    pos[b][0] -= ux
                    pos[b][1] -= uy
                    moved = True
        if not moved:
            return


# ---------------------------------------------------------------------------
# packing the components
# ---------------------------------------------------------------------------

class _Link:
    """One circle's place in the front chain, as a ring."""
    __slots__ = ("at", "prev", "next")

    def __init__(self, at: dict) -> None:
        self.at = at
        self.prev: _Link = self
        self.next: _Link = self


def _place(p: dict, q: dict, c: dict) -> None:
    """Put ``c`` tangent to both ``p`` and ``q``, on the outside."""
    dx, dy = p["cx"] - q["cx"], p["cy"] - q["cy"]
    d2 = dx * dx + dy * dy
    if d2 <= 0:
        c["cx"], c["cy"] = q["cx"] + c["_r"], q["cy"]
        return
    a2 = (q["_r"] + c["_r"]) ** 2
    b2 = (p["_r"] + c["_r"]) ** 2
    if a2 > b2:
        x = (d2 + b2 - a2) / (2 * d2)
        y = math.sqrt(max(b2 / d2 - x * x, 0.0))
        c["cx"] = p["cx"] - x * dx - y * dy
        c["cy"] = p["cy"] - x * dy + y * dx
    else:
        x = (d2 + a2 - b2) / (2 * d2)
        y = math.sqrt(max(a2 / d2 - x * x, 0.0))
        c["cx"] = q["cx"] + x * dx - y * dy
        c["cy"] = q["cy"] + x * dy + y * dx


def _hits(a: dict, b: dict) -> bool:
    dr = a["_r"] + b["_r"] - 1e-6
    dx, dy = b["cx"] - a["cx"], b["cy"] - a["cy"]
    return dr > 0 and dr * dr > dx * dx + dy * dy


def _score(link: _Link) -> float:
    """How close this pair of neighbours sits to the middle of the packing."""
    a, b = link.at, link.next.at
    ab = a["_r"] + b["_r"]
    dx = (a["cx"] * b["_r"] + b["cx"] * a["_r"]) / ab
    dy = (a["cy"] * b["_r"] + b["cy"] * a["_r"]) / ab
    return dx * dx + dy * dy


def _pack(blobs: list[dict], gap: float) -> None:
    """Pack the components so none overlaps and no space is wasted.

    A spiral is the obvious way and it is a bad one: stepping outwards until
    something fits leaves most of the plane empty, which at screen scale turns
    three hundred counterparties into three hundred invisible specks.

    This is front-chain packing, the same algorithm a circle-packing chart
    uses. Three circles go down mutually tangent, and the hull of everything
    placed so far is kept as a ring. Each new circle is set tangent to the
    pair on that ring nearest the middle; if it lands on top of another
    circle on the ring, the arc between is enclosed, so it is spliced out and
    the circle is tried again. Everything finishes touching something, which
    is as tight as circles get, and the packing stays roughly round rather
    than growing an arm.
    """
    for blob in blobs:
        blob["_r"] = blob["radius"] + gap
        blob["cx"] = blob["cy"] = 0.0
    if len(blobs) < 2:
        return

    a, b = blobs[0], blobs[1]
    a["cx"], a["cy"] = -b["_r"], 0.0
    b["cx"], b["cy"] = a["_r"], 0.0
    if len(blobs) == 2:
        return

    c = blobs[2]
    _place(b, a, c)

    la, lb, lc = _Link(a), _Link(b), _Link(c)
    la.next = lc.prev = lb
    lb.next = la.prev = lc
    lc.next = lb.prev = la

    i = 3
    while i < len(blobs):
        item = blobs[i]
        _place(la.at, lb.at, item)
        lnew = _Link(item)

        # Walk outwards along the chain in both directions at once, taking
        # whichever side has covered less distance, and stop at the first
        # circle this one runs into. That is the nearest obstruction along the
        # hull, and everything between it and the insertion point is enclosed.
        j, k = lb.next, la.prev
        sj, sk = lb.at["_r"], la.at["_r"]
        clashed = False
        while True:
            if sj <= sk:
                if _hits(j.at, item):
                    lb = j
                    la.next, lb.prev = lb, la    # splice the arc away
                    clashed = True
                    break
                sj += j.at["_r"]
                j = j.next
            else:
                if _hits(k.at, item):
                    la = k
                    la.next, lb.prev = lb, la
                    clashed = True
                    break
                sk += k.at["_r"]
                k = k.prev
            if j is k.next:
                break
        if clashed:
            continue                          # same circle, shorter chain

        lnew.prev, lnew.next = la, lb
        la.next = lb.prev = lnew

        # The next circle goes against whichever neighbouring pair is now
        # closest to the middle, which is what keeps the packing round.
        lb = lnew
        best = _score(la)
        node = lnew.next
        while node is not lb:
            s = _score(node)
            if s < best:
                la, best = node, s
            node = node.next
        lb = la.next
        i += 1

    for blob in blobs:
        blob.pop("_r", None)


# ---------------------------------------------------------------------------
# the whole thing
# ---------------------------------------------------------------------------

def layout(ids: list[str], edges: list[tuple[str, str, float]],
           radius: dict[str, float], *, gap: float = 14.0,
           aspect: float = 1.9) -> dict:
    """Positions for every node, and the box they occupy.

    ``edges`` are (a, b, weight); weight pulls harder, so a relationship worth
    more sits closer. Returns positions in their own coordinate space - the
    caller fits that to a viewBox, which is also what lets the page zoom
    without anything being recomputed.
    """
    if not ids:
        return {"pos": {}, "x": 0.0, "y": 0.0, "w": 1.0, "h": 1.0,
                "components": 0}

    groups, adj = components(ids, [(a, b) for a, b, _ in edges])
    weights = {(a, b): w for a, b, w in edges}

    blobs: list[dict] = []
    for group in groups:
        local = _place_one(group, adj, radius, gap, weights)
        xs = [p[0] for p in local.values()]
        ys = [p[1] for p in local.values()]
        cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
        rad = max(math.hypot(p[0] - cx, p[1] - cy) + radius[nid]
                  for nid, p in local.items())
        blobs.append({"nodes": {nid: (p[0] - cx, p[1] - cy)
                                for nid, p in local.items()},
                      "radius": rad, "cx": 0.0, "cy": 0.0,
                      "size": len(group)})

    # Biggest first so the dense piece takes the middle; ties broken on the
    # node names so two identical books pack identically.
    blobs.sort(key=lambda b: (-b["radius"], -b["size"], min(b["nodes"])))
    _pack(blobs, gap * 1.5)

    # Circle packing produces a round arrangement, and a browser window is
    # not round: a square drawing letterboxed into a 2:1 panel leaves a third
    # of it empty and shrinks everything to fit the short side. Spreading the
    # component *centres* horizontally fills the width without touching any
    # component's own shape, and since it only ever increases the horizontal
    # distance between two circles it cannot introduce an overlap.
    span_x = max(b["cx"] + b["radius"] for b in blobs) -         min(b["cx"] - b["radius"] for b in blobs)
    span_y = max(b["cy"] + b["radius"] for b in blobs) -         min(b["cy"] - b["radius"] for b in blobs)
    stretch = 1.0
    if span_x > 0 and span_y > 0 and aspect > 0:
        stretch = max(1.0, min(aspect * span_y / span_x, 3.0))

    pos: dict[str, tuple[float, float]] = {}
    for blob in blobs:
        for nid, (x, y) in blob["nodes"].items():
            pos[nid] = (x + blob["cx"] * stretch, y + blob["cy"])

    x0 = min(pos[n][0] - radius[n] for n in pos)
    x1 = max(pos[n][0] + radius[n] for n in pos)
    y0 = min(pos[n][1] - radius[n] for n in pos)
    y1 = max(pos[n][1] + radius[n] for n in pos)
    pad = gap * 2
    return {"pos": pos, "x": x0 - pad, "y": y0 - pad,
            "w": max(x1 - x0 + pad * 2, 1.0), "h": max(y1 - y0 + pad * 2, 1.0),
            "components": len(blobs)}


def _place_one(group: list[str], adj: dict[str, set[str]],
               radius: dict[str, float], gap: float,
               weights: dict) -> dict[str, tuple[float, float]]:
    """One component, by the cheapest method that suits its shape."""
    if len(group) == 1:
        return {group[0]: (0.0, 0.0)}
    if len(group) == 2:
        a, b = group
        d = (radius[a] + radius[b] + gap * 1.8) / 2
        return {a: (-d, 0.0), b: (d, 0.0)}
    star = _ring(group, adj, radius, gap)
    if star is not None:
        return star
    return _spread(group, adj, radius, gap, weights)


# ---------------------------------------------------------------------------
# caching
# ---------------------------------------------------------------------------
# A layout is a pure function of the graph, and the graph changes only when the
# book does. A thousand entities take a third of a second to place, which is
# fine once and not fine on every page load, every filter and every theme
# switch - so the result is kept against a fingerprint of what went into it.

_CACHE: dict[str, dict] = {}
_CACHE_MAX = 24


def cached_layout(ids: list[str], edges: list[tuple[str, str, float]],
                  radius: dict[str, float], *, gap: float = 14.0,
                  aspect: float = 1.9) -> dict:
    import hashlib

    stamp = hashlib.blake2b(
        repr((sorted(ids), sorted((a, b, round(w, 3)) for a, b, w in edges),
              sorted((k, round(v, 2)) for k, v in radius.items()),
              round(gap, 2), round(aspect, 2))).encode(),
        digest_size=16).hexdigest()
    hit = _CACHE.get(stamp)
    if hit is not None:
        return hit
    out = layout(ids, edges, radius, gap=gap, aspect=aspect)
    if len(_CACHE) >= _CACHE_MAX:
        _CACHE.pop(next(iter(_CACHE)))
    _CACHE[stamp] = out
    return out


def forget() -> None:
    """Drop the cached layouts. Called when the book is rebuilt."""
    _CACHE.clear()
