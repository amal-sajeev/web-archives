"""The counterparty map: who ships to whom, and where that stops making sense.

A worklist is a hundred rows that each look reasonable on their own. The things
worth a maker's attention are relations *between* rows - one counterparty filed
under two names, one Bill of Entry number used by two unrelated shipments, a
supplier in Hong Kong paid as though it were in mainland China - and a list
cannot show a relation. A picture can.

The hard part is that a batch is not twelve transactions. Drawn naively, three
hundred of them is an eleven-thousand-pixel column of hairlines with forty
thousand crossings and eighteen thousand "findings", which is not a tool, it is
a refusal to summarise. Four things keep it a tool at any size:

**One ribbon per relationship, not per transaction.** Three hundred
transactions between ninety suppliers and twenty-five importers are rarely
three hundred relationships; they are perhaps a hundred and twenty. The drawing
is about who trades with whom, and the count rides on the ribbon.

**A budget, and an honest fold.** Only so many rows fit before a chip is
thinner than its own label, so the columns are ranked - anything carrying a
discrepancy first, then by value - and everything past the budget is folded
into one chip per country rather than dropped. The totals stay right and the
page says plainly what it folded.

**Findings that group.** "Paid a different party" on forty transactions is one
finding with a count and four examples, not forty rows. Each one carries a
filter, so reading it is also the way to drill into it.

**Filters, server-side.** Narrowing to one country, one importer or one kind of
discrepancy is a query string, so the drawing that comes back is small enough
to read and the page stays a plain page.

Layout is the barycentre heuristic over the two columns, which is deterministic
and cheap, with crossings counted by a Fenwick tree. All of it runs here, so the
page arrives as finished SVG with no physics in the browser.
"""

from __future__ import annotations

import math
from typing import Any

from .agent import arithmetic
from .sources._data import longest_common_run, normalise_country, normalise_name
from .text import n as _count

# --- what fits ------------------------------------------------------------
# A drawing surface the SVG scales into; nothing here is screen pixels.
W = 1180
PAD_Y = 26
CHIP_W = 310
LEFT_X = 18
RIGHT_X = W - 18 - CHIP_W
SWEEPS = 6

ROWS_MAX = 22          # chips per column before the tail is folded by country
FOLD_MAX = 4           # how many country chips the fold may use
LINKS_MAX = 140        # ribbons before the quietest are left undrawn
EXAMPLES = 4           # how many to name inside a grouped finding
DENSE = 45             # relationships past which the whole book is a mesh

# Each kind of discrepancy, as the grouped finding says it: the phrase for one
# transaction, the phrase for several, and why it matters. Written out rather
# than pluralised by rule, because the verb moves as well as the noun.
FLAG_LABELS = {
    "party": ("was paid to a party other than the shipper",
              "were paid to a party other than the shipper",
              "TradePay paid someone other than the supplier IDPMS holds."),
    "country": ("names two different countries",
                "name two different countries",
                "IDPMS and TradePay disagree about where the counterparty is."),
    "currency": ("is in two currencies",
                 "are in two currencies",
                 "The invoice and the remittance are not in the same currency."),
    "amount": ("has amounts that do not agree",
               "have amounts that do not agree",
               "IDPMS and TradePay hold different totals for the same invoices."),
    "noremit": ("has no remittance matched",
                "have no remittance matched",
                "TradePay holds no row for the transaction's invoice numbers."),
}


def _fmt_inr(v: float) -> str:
    """Rupees the way a desk says them aloud: crore, lakh, or the figure."""
    if v >= 1_00_00_000:
        return f"{v / 1_00_00_000:,.2f} cr"
    if v >= 1_00_000:
        return f"{v / 1_00_000:,.2f} L"
    return f"{v:,.0f}"


def _listed(items: list[str], limit: int = EXAMPLES) -> str:
    items = [str(i) for i in items]
    if len(items) <= limit:
        return ", ".join(items[:-1]) + (" and " if len(items) > 1 else "") + items[-1] \
            if items else ""
    return ", ".join(items[:limit]) + f" and {len(items) - limit} more"


# ---------------------------------------------------------------------------
# one transaction
# ---------------------------------------------------------------------------

def _state(case) -> str:
    if any(c.status == "blocked" for c in case.checks):
        return "blocked"
    if any(c.status in ("fail", "warn") for c in case.checks):
        return "broken"
    if not case.checks:
        return "unrun"
    return "clear"


_WORST = {"broken": 0, "blocked": 1, "unrun": 2, "clear": 3}


def _value(case) -> float:
    """What this transaction is worth in rupees, run or not.

    A case that has not been through the pipeline has no charges and so no
    rupee value, which would draw the whole map as identical hairlines on a
    cold start. The conversion does not depend on the pipeline, so it is done
    here by the same function the charges use, not a second opinion about it.
    """
    if case.charges.gross_inr:
        return float(case.charges.gross_inr)
    from .sources._data import load
    return float(arithmetic.gross_exchanged(
        amount=case.total_amount, currency=case.currency,
        deal=case.deal, fx=load("fx"))["amountInr"] or 0.0)


def _counterparty_key(case) -> tuple[str, str]:
    """Who the other side is, and the best name to put on the chip.

    TradePay's drawer is who the money actually went to, so it decides
    identity. It does not always decide the *name*: the portal returns a party
    name cut to its column width, so one drawer reads "E GMBH CO KG".
    Labelling a node with the tail of a name is worse than useless, so where
    the drawer is cut short the full IDPMS supplier name goes on the chip.
    """
    tp = case.tradepay or {}
    drawer = tp.get("drawerName")
    if drawer:
        name = (str(case.supplier) if tp.get("drawerNameTruncated")
                and case.supplier else str(drawer))
        return normalise_name(drawer), name
    return normalise_name(case.supplier), str(case.supplier or "")


def _flags(case) -> list[dict]:
    """The things about one transaction worth marking on its ribbon."""
    out: list[dict] = []
    tp = case.tradepay or {}

    if not tp:
        return [{"id": "noremit", "label": "No remittance matched",
                 "detail": "TradePay holds no row for this transaction's invoice "
                           "numbers, so nothing could be compared."}]

    supplier, drawer = case.supplier, tp.get("drawerName")
    if drawer and normalise_name(drawer) != normalise_name(supplier) \
            and not tp.get("drawerNameTruncated"):
        out.append({"id": "party", "label": "Paid a different party",
                    "detail": f"IDPMS ships from {supplier}; TradePay paid "
                              f"{drawer}."})

    s_ctry, d_ctry = case.supplier_country, tp.get("drawerCountry")
    if s_ctry and d_ctry and normalise_country(s_ctry) != normalise_country(d_ctry):
        out.append({"id": "country", "label": "Two countries",
                    "detail": f"IDPMS holds {s_ctry}; TradePay holds {d_ctry}."})

    if tp.get("invoiceCurrency") and tp["invoiceCurrency"] != case.currency:
        out.append({"id": "currency", "label": "Two currencies",
                    "detail": f"The invoice is in {case.currency}; the "
                              f"remittance is in {tp['invoiceCurrency']}."})

    # An amount gap on a remittance covering only some of the invoices is not a
    # discrepancy; the invoice-match check names the outstanding ones.
    amt = tp.get("invoiceAmount")
    covers_all = tp.get("matchedInvoiceCount", 1) >= len(case.invoice_lines)
    if covers_all and isinstance(amt, (int, float)) and case.total_amount and \
            abs(amt - case.total_amount) > max(case.total_amount * 0.02, 1):
        out.append({"id": "amount", "label": "Amounts apart",
                    "detail": f"IDPMS totals {case.total_amount:,.2f}; TradePay "
                              f"holds {amt:,.2f}."})
    return out


# ---------------------------------------------------------------------------
# the whole picture
# ---------------------------------------------------------------------------

def build(cases: list, *, view: str = "", only: str = "", country: str = "",
          importer: str = "", q: str = "", currency: str = "", port: str = "",
          band: str = "") -> dict[str, Any]:
    """Nodes, ribbons, the layout and what stands out, within a budget.

    ``only`` keeps one kind of discrepancy ("flagged" for any); ``country`` and
    ``importer`` keep one party's country or one importer. Filtering happens
    before anything is laid out, so a narrowed map is a small map.
    """
    everything = list(cases)
    txns = [_transaction(c) for c in everything]
    shown = _filtered(txns, only, country, importer, q, currency, port, band)

    parties, importers = _columns(shown)
    rels = _relationships(shown, parties, importers)

    # A hundred relationships between twenty chips is a mesh, however neatly it
    # is ordered: the ribbons cross more than they run. Rather than draw that
    # and call it a map, a book too dense to show at once opens on the part
    # that is worth looking at - the transactions carrying a discrepancy - and
    # says so, with a way back to all of it. Narrowing is the way to read a
    # large book, so the page starts narrow instead of starting unreadable.
    auto = ""
    narrowed = any((only, country, importer, q, currency, port, band))
    if view != "map" and not narrowed and len(rels) > DENSE:
        flagged = _filtered(txns, "flagged")
        if flagged and len(flagged) < len(shown):
            auto, only = "flagged", "flagged"
            shown = flagged
            parties, importers = _columns(shown)
            rels = _relationships(shown, parties, importers)

    if view not in ("map", "flow"):
        # The plane is the map. Choosing by entity count was neat and wrong:
        # it meant the nav link landed on a different drawing depending on how
        # much was in the book that morning, so nobody could learn what the
        # page looks like, and on the supplied data it always landed on the
        # columns. Columns remain a click away, and are still the better read
        # for a small book - that is a choice the reader makes, not one the
        # row count makes for them.
        view = "map"

    if view == "map":
        plane = _map(parties, importers, rels)
        return {
            **plane,
            "view": "map", "canSwitch": True,
            "findings": _findings(shown, parties, importers, rels, only,
                                  country, importer),
            "folds": [], "density": {"auto": "", "ribbons": len(rels),
                                     "dense": False, "crossings": 0},
            "filters": _filter_menu(txns, only, country, importer, q,
                                currency, port, band),
        "qs": _query(only=only, country=country, importer=importer,
                     q=q, currency=currency, port=port, band=band),
            "totals": _totals(shown, txns, rels),
        }

    left, right, rels, folds = _fit(parties, importers, rels)

    rows = max(len(left), len(right), 1)
    row = 58 if rows <= 12 else (46 if rows <= 18 else 38)
    _order(left, right, rels)
    _place(left, right, row)
    _route(rels, left, right, row)

    return {
        "view": "flow", "canSwitch": True,
        "parties": left, "importers": right, "links": rels,
        "findings": _findings(shown, parties, importers, rels, only, country,
                              importer),
        "folds": folds,
        "density": {
            "auto": auto,
            "ribbons": len(rels),
            "dense": len(rels) > DENSE,
            "crossings": _crossings(rels, {x["id"]: x for x in left + right}),
        },
        "width": W, "height": rows * row + PAD_Y * 2,
        "leftX": LEFT_X, "rightX": RIGHT_X, "chipW": CHIP_W,
        "chipH": row - 18, "row": row, "compact": row < 46,
        "filters": _filter_menu(txns, only, country, importer, q,
                                currency, port, band),
        "qs": _query(only=only, country=country, importer=importer,
                     q=q, currency=currency, port=port, band=band),
        "totals": _totals(shown, txns, rels),
    }


def _query(**bits: str) -> str:
    """The current narrowing as a query fragment, for the view links."""
    from urllib.parse import quote_plus
    return "".join(f"&{k}={quote_plus(v)}" for k, v in bits.items() if v)


def _filter_menu(txns: list[dict], only: str, country: str, importer: str,
                 q: str = "", currency: str = "", port: str = "",
                 band: str = "") -> dict:
    return {
        "only": only, "country": country, "importer": importer, "q": q,
        "currency": currency, "port": port, "band": band,
        "active": any((only, country, importer, q, currency, port, band)),
        "countries": _choices(txns, "country"),
        "importers": _choices(txns, "importer"),
        "currencies": sorted({t["currency"] for t in txns if t["currency"]}),
        "ports": sorted({t["port"] for t in txns if t["port"]}),
        "bands": [(k, v[1]) for k, v in BANDS.items()],
        "kinds": [(k, FLAG_LABELS[k][1]) for k in sorted(
            {f["id"] for t in txns for f in t["flags"]})],
    }


def _totals(shown: list[dict], txns: list[dict], rels: list[dict]) -> dict:
    return {
        "parties": len({t["partyKey"] for t in shown}),
        "importers": len({t["importerKey"] for t in shown}),
        "transactions": len(shown),
        "relationships": len(rels),
        "ofTransactions": len(txns),
        "valueInr": round(sum(t["valueInr"] for t in shown), 2),
        "flagged": sum(1 for t in shown if t["flags"]),
    }


def _transaction(case) -> dict:
    key, label = _counterparty_key(case)
    if not key:
        key, label = f"case:{case.case_id}", case.supplier or "Unnamed"
    return {
        "id": case.case_id, "partyKey": key, "partyName": label,
        "importerKey": normalise_name(case.importer), "importer": case.importer,
        "supplier": case.supplier,
        "drawer": (case.tradepay or {}).get("drawerName"),
        # A name the portal returned cut to its column width is the same name
        # shorter, not a second one, and the checks already report it. Counting
        # it as an alias invents a naming problem on transactions without one.
        "drawerCut": bool((case.tradepay or {}).get("drawerNameTruncated")),
        "country": (case.supplier_country
                    or (case.tradepay or {}).get("drawerCountry") or ""),
        "drawerCountry": (case.tradepay or {}).get("drawerCountry") or "",
        "valueInr": _value(case), "currency": case.currency,
        "amount": float(case.total_amount or 0.0),
        "boe": case.bill_of_entry, "boeDate": case.bill_of_entry_date,
        "lines": len(case.invoice_lines), "state": _state(case),
        "flags": _flags(case),
        "invoices": [str(l.invoice_no) for l in case.invoice_lines if l.invoice_no],
        "port": next((p.name or p.code for p in case.ports
                      if p.role == "discharge" and (p.name or p.code)), ""),
    }


# How much is worth looking at on its own. Lakh and crore because that is
# what these figures are read in, not because the numbers are round.
BANDS = {
    "1l": (1_00_000.0, "over INR 1 lakh"),
    "10l": (10_00_000.0, "over INR 10 lakh"),
    "1c": (1_00_00_000.0, "over INR 1 crore"),
}


def _filtered(txns: list[dict], only: str = "", country: str = "",
              importer: str = "", q: str = "", currency: str = "",
              port: str = "", band: str = "") -> list[dict]:
    """Narrow the book. The filters are independent and they compose."""
    out = txns
    if only == "flagged":
        out = [t for t in out if t["flags"]]
    elif only:
        out = [t for t in out if any(f["id"] == only for f in t["flags"])]
    if country:
        want = normalise_country(country)
        out = [t for t in out
               if normalise_country(t["country"]) == want
               or normalise_country(t["drawerCountry"]) == want]
    if importer:
        want = normalise_name(importer)
        out = [t for t in out if t["importerKey"] == want]
    if currency:
        out = [t for t in out if t["currency"] == currency]
    if port:
        out = [t for t in out if t["port"] == port]
    if band in BANDS:
        floor = BANDS[band][0]
        out = [t for t in out if t["valueInr"] >= floor]
    if q:
        # The same words a maker would type into the worklist search: a
        # counterparty, an importer, a Bill of Entry or an invoice number.
        want = " ".join(q.split()).upper()
        out = [t for t in out if want in " ".join(
            [str(t["partyName"]), str(t["supplier"] or ""), str(t["drawer"] or ""),
             str(t["importer"]), str(t["boe"]), *t["invoices"]]).upper()]
    return out


def _choices(txns: list[dict], field: str) -> list[str]:
    if field == "country":
        return sorted({t["country"].title() for t in txns if t["country"]})
    return sorted({t["importer"] for t in txns if t["importer"]})


def _columns(txns: list[dict]) -> tuple[dict[str, dict], dict[str, dict]]:
    parties: dict[str, dict] = {}
    importers: dict[str, dict] = {}
    for t in txns:
        p = parties.setdefault(t["partyKey"], {
            "id": f"p{len(parties)}", "key": t["partyKey"], "name": t["partyName"],
            "side": "party", "aliases": [], "countries": [], "links": [],
            "valueInr": 0.0, "count": 0, "flagged": 0, "folded": 0})
        for alias, cut in ((t["supplier"], False), (t["drawer"], t["drawerCut"])):
            if alias and not cut and str(alias) not in p["aliases"]:
                p["aliases"].append(str(alias))
        for c in (t["country"], t["drawerCountry"]):
            if c and str(c) not in p["countries"]:
                p["countries"].append(str(c))
        p["valueInr"] += t["valueInr"]
        p["count"] += 1
        p["flagged"] += 1 if t["flags"] else 0

        i = importers.setdefault(t["importerKey"], {
            "id": f"i{len(importers)}", "key": t["importerKey"], "name": t["importer"],
            "side": "importer", "aliases": [], "countries": [], "links": [],
            "valueInr": 0.0, "count": 0, "flagged": 0, "folded": 0})
        i["valueInr"] += t["valueInr"]
        i["count"] += 1
        i["flagged"] += 1 if t["flags"] else 0
    return parties, importers


# --- one ribbon per relationship ------------------------------------------

def _relationships(txns: list[dict], parties: dict, importers: dict) -> list[dict]:
    """Collapse transactions onto the pair of parties they are between.

    This is the change that makes the drawing survive a real batch. Three
    hundred transactions are perhaps a hundred relationships, and the drawing
    is about relationships; how many transactions sit inside one is a number on
    the ribbon.
    """
    rels: dict[tuple[str, str], dict] = {}
    for t in txns:
        src, dst = parties[t["partyKey"]]["id"], importers[t["importerKey"]]["id"]
        r = rels.setdefault((src, dst), {
            "id": f"r{len(rels)}", "source": src, "target": dst,
            "sourceKey": t["partyKey"], "targetKey": t["importerKey"],
            "party": t["partyName"], "importer": t["importer"],
            "valueInr": 0.0, "count": 0, "cases": [], "currencies": [],
            "state": "clear", "flagIds": [], "flags": [], "boes": [],
        })
        r["valueInr"] += t["valueInr"]
        r["count"] += 1
        if len(r["cases"]) < 60:
            r["cases"].append(t["id"])
        if t["currency"] and t["currency"] not in r["currencies"]:
            r["currencies"].append(t["currency"])
        if len(r["boes"]) < 8 and t["boe"] not in r["boes"]:
            r["boes"].append(t["boe"])
        if _WORST[t["state"]] < _WORST[r["state"]]:
            r["state"] = t["state"]
        for f in t["flags"]:
            if f["id"] not in r["flagIds"]:
                r["flagIds"].append(f["id"])
                r["flags"].append(f)
    return list(rels.values())


# --- fitting the budget ----------------------------------------------------

def _fit(parties: dict, importers: dict,
         rels: list[dict]) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    """Rank each column, fold what will not fit, and re-point the ribbons."""
    folds: list[dict] = []
    left, lmap = _fold(list(parties.values()), "counterparty", "counterparties", folds)
    right, rmap = _fold(list(importers.values()), "importer", "importers", folds)

    if lmap or rmap:
        rels = _reaggregate(rels, lmap, rmap)

    # Attach each ribbon to its two chips, and cap how many are drawn.
    by_id = {n["id"]: n for n in left + right}
    rels.sort(key=lambda r: (0 if r["flags"] else 1, -r["valueInr"]))
    if len(rels) > LINKS_MAX:
        dropped = rels[LINKS_MAX:]
        rels = rels[:LINKS_MAX]
        folds.append({
            "kind": "links",
            "text": f"{len(dropped):,} further relationships are not drawn - "
                    f"the quietest by value, none of them carrying a "
                    f"discrepancy, worth INR "
                    f"{_fmt_inr(sum(r['valueInr'] for r in dropped))} between "
                    f"them. Narrow the map to see them.",
        })
    for r in rels:
        for end in ("source", "target"):
            node = by_id.get(r[end])
            if node is not None:
                node["links"].append(r["id"])
    return left, right, rels, folds


def _fold(nodes: list[dict], one: str, many: str,
          folds: list[dict]) -> tuple[list[dict], dict[str, str]]:
    """Keep the chips that earn a row; fold the rest into one chip per country.

    Ranked by whether anything on them is flagged, then by value, so a small
    counterparty with a discrepancy keeps its row and a large quiet one does
    not lose its money - it moves into its country's chip.
    """
    if len(nodes) <= ROWS_MAX:
        return sorted(nodes, key=lambda n: -n["valueInr"]), {}

    nodes.sort(key=lambda n: (0 if n["flagged"] else 1, -n["valueInr"]))
    keep, tail = nodes[:ROWS_MAX - FOLD_MAX], nodes[ROWS_MAX - FOLD_MAX:]

    # Group the tail by country, largest few by value, the rest together.
    groups: dict[str, list[dict]] = {}
    for n in tail:
        groups.setdefault((n["countries"] or ["Elsewhere"])[0].title(),
                          []).append(n)
    ranked = sorted(groups.items(),
                    key=lambda kv: -sum(n["valueInr"] for n in kv[1]))
    chosen, rest = ranked[:FOLD_MAX - 1], ranked[FOLD_MAX - 1:]
    if rest:
        chosen.append(("Elsewhere", [n for _, g in rest for n in g]))

    remap: dict[str, str] = {}
    made: list[dict] = []
    for label, group in chosen:
        if not group:
            continue
        node = {
            "id": f"g{len(made)}{one[0]}", "key": f"fold:{label}",
            "name": f"{len(group):,} other {many} — {label}"
                    if label != "Elsewhere" else
                    f"{len(group):,} other {many}",
            "side": group[0]["side"], "aliases": [], "countries": [label],
            "links": [], "folded": len(group), "count": sum(n["count"] for n in group),
            "flagged": sum(n["flagged"] for n in group),
            "valueInr": sum(n["valueInr"] for n in group),
        }
        for n in group:
            remap[n["id"]] = node["id"]
        made.append(node)

    folds.append({
        "kind": one,
        "text": f"{len(tail):,} of {len(nodes):,} {many} are folded into "
                f"{_count(len(made), 'chip')} by country, worth INR "
                f"{_fmt_inr(sum(n['valueInr'] for n in tail))} between them. "
                f"The {len(keep)} shown are those carrying a discrepancy, then "
                f"the largest by value.",
    })
    for n in keep:
        n["links"] = []
    return keep + made, remap


def _reaggregate(rels: list[dict], lmap: dict, rmap: dict) -> list[dict]:
    """Point ribbons at the fold chips and merge the ones that now coincide."""
    merged: dict[tuple[str, str], dict] = {}
    for r in rels:
        src = lmap.get(r["source"], r["source"])
        dst = rmap.get(r["target"], r["target"])
        key = (src, dst)
        if key not in merged:
            r = dict(r)
            r["source"], r["target"] = src, dst
            r["id"] = f"r{len(merged)}"
            merged[key] = r
            continue
        m = merged[key]
        m["valueInr"] += r["valueInr"]
        m["count"] += r["count"]
        m["cases"] = (m["cases"] + r["cases"])[:60]
        for c in r["currencies"]:
            if c not in m["currencies"]:
                m["currencies"].append(c)
        if _WORST[r["state"]] < _WORST[m["state"]]:
            m["state"] = r["state"]
        for f in r["flags"]:
            if f["id"] not in m["flagIds"]:
                m["flagIds"].append(f["id"])
                m["flags"].append(f)
        if m["party"] != r["party"]:
            m["party"] = ""          # a fold chip stands for several parties
        if m["importer"] != r["importer"]:
            m["importer"] = ""
    return list(merged.values())


# ---------------------------------------------------------------------------
# ordering: fewest crossings wins
# ---------------------------------------------------------------------------

def _order(left: list[dict], right: list[dict], links: list[dict]) -> None:
    """Order both columns so the ribbons cross as little as possible.

    Barycentre sweeps: hold one column still, move each node of the other to
    the average position of the nodes it joins, re-sort, repeat. Ties break on
    value so the picture is stable and the big flows sit together.
    """
    by_id = {n["id"]: n for n in left + right}
    for column in (left, right):
        for i, node in enumerate(sorted(column, key=lambda n: -n["valueInr"])):
            node["_i"] = i

    adj: dict[str, list[str]] = {n["id"]: [] for n in left + right}
    for l in links:
        if l["source"] in adj and l["target"] in adj:
            adj[l["source"]].append(l["target"])
            adj[l["target"]].append(l["source"])

    def sweep(movers: list[dict]) -> int:
        for node in movers:
            peers = [by_id[p]["_i"] for p in adj[node["id"]] if p in by_id]
            node["_b"] = sum(peers) / len(peers) if peers else node["_i"]
        movers.sort(key=lambda n: (n["_b"], -n["valueInr"], n["name"]))
        for i, node in enumerate(movers):
            node["_i"] = i
        return _crossings(links, by_id)

    best = _crossings(links, by_id)
    best_state = {n["id"]: n["_i"] for n in left + right}
    for _ in range(SWEEPS):
        sweep(left)
        score = sweep(right)
        if score < best:
            best, best_state = score, {n["id"]: n["_i"] for n in left + right}
        if best == 0:
            break
    for node in left + right:
        node["_i"] = best_state[node["id"]]
    left.sort(key=lambda n: n["_i"])
    right.sort(key=lambda n: n["_i"])


def _crossings(links: list[dict], by_id: dict[str, dict]) -> int:
    """How many pairs of ribbons cross, given the current order.

    Two ribbons in a two-column drawing cross exactly when their endpoints are
    in the opposite order on the two sides, so the count is the number of
    inversions in the target column once the pairs are sorted by the source
    column. Counting those pairwise is quadratic and this runs twelve times per
    layout; a Fenwick tree counts the same inversions in n log n.
    """
    pos = sorted((by_id[l["source"]]["_i"], by_id[l["target"]]["_i"])
                 for l in links if l["source"] in by_id and l["target"] in by_id)
    if not pos:
        return 0

    size = max(p[1] for p in pos) + 2
    tree = [0] * (size + 1)
    crossings = seen = 0
    for _, right in pos:
        i, below = right + 1, 0
        while i > 0:
            below += tree[i]
            i -= i & -i
        crossings += seen - below
        seen += 1
        i = right + 1
        while i <= size:
            tree[i] += 1
            i += i & -i
    return crossings


def _place(left: list[dict], right: list[dict], row: int) -> None:
    """Rows to coordinates. The shorter column is centred against the longer."""
    chip_h = row - 18
    tall = max(len(left), len(right))
    for column, x in ((left, LEFT_X), (right, RIGHT_X)):
        offset = (tall - len(column)) * row / 2
        for i, node in enumerate(column):
            node["x"] = x
            node["y"] = round(PAD_Y + offset + i * row, 1)
            node["cy"] = round(node["y"] + chip_h / 2, 1)
            node.pop("_b", None)


# ---------------------------------------------------------------------------
# ribbons
# ---------------------------------------------------------------------------

def _route(links: list[dict], left: list[dict], right: list[dict],
           row: int) -> None:
    """A path and a width for each ribbon.

    Value spans several orders of magnitude, so width is on a log scale.
    Linear would draw a hundred hairlines and one bar.
    """
    chip_h = row - 18
    by_id = {n["id"]: n for n in left + right}
    x1, x2 = LEFT_X + CHIP_W, RIGHT_X
    mid = (x1 + x2) / 2

    values = [l["valueInr"] for l in links if l["valueInr"] > 0]
    lo = math.log10(min(values)) if values else 0.0
    hi = math.log10(max(values)) if values else 1.0
    span = (hi - lo) or 1.0
    fattest = min(13.0, max(3.0, chip_h * 0.38))

    # Several ribbons land on one chip; fan them so none hides another.
    fan: dict[str, list[dict]] = {}
    for l in links:
        fan.setdefault(l["source"], []).append(l)
        fan.setdefault(l["target"], []).append(l)
    for node_id, group in fan.items():
        other = "target" if node_id.startswith(("p", "gc")) else "source"
        group.sort(key=lambda l: by_id[l[other]]["cy"] if l[other] in by_id else 0)

    for l in links:
        src, dst = by_id.get(l["source"]), by_id.get(l["target"])
        if not src or not dst:
            l["path"], l["w"] = "", 2.0
            continue
        v = l["valueInr"]
        t = (math.log10(v) - lo) / span if v > 0 else 0.0
        l["w"] = round(1.8 + t * fattest, 2)
        l["y1"] = _offset(src, l, fan, chip_h)
        l["y2"] = _offset(dst, l, fan, chip_h)
        l["path"] = (f"M{x1},{l['y1']} C{mid},{l['y1']} {mid},{l['y2']} "
                     f"{x2},{l['y2']}")
        l["labelX"] = round(mid, 1)
        l["labelY"] = round((l["y1"] + l["y2"]) / 2, 1)
        l["href"] = (f"/cases/{l['cases'][0]}" if l["count"] == 1 and l["cases"]
                     else "")
    links.sort(key=lambda l: -l["w"])        # thin ribbons draw on top


def _offset(node: dict, link: dict, fan: dict, chip_h: float) -> float:
    group = fan.get(node["id"], [])
    if len(group) <= 1:
        return node["cy"]
    i = group.index(link)
    room = max(chip_h - 8, 4)
    step = room / max(len(group) - 1, 1)
    return round(node["y"] + 4 + i * step, 1)


# ---------------------------------------------------------------------------
# what stands out
# ---------------------------------------------------------------------------

def _findings(txns: list[dict], parties: dict, importers: dict,
              rels: list[dict], only: str, country: str,
              importer: str) -> list[dict]:
    """The relations a worklist cannot show, grouped so they stay readable.

    One finding per kind, with a count, a few named examples and a filter that
    narrows the whole page to it. Forty transactions paid to the wrong party
    are one line and a way in, not forty lines.
    """
    out: list[dict] = []
    nodes_for = {t["id"]: (parties[t["partyKey"]]["id"],
                           importers[t["importerKey"]]["id"]) for t in txns}
    rel_for: dict[tuple[str, str], str] = {(r["source"], r["target"]): r["id"]
                                           for r in rels}

    def refs(group: list[dict]) -> dict:
        ns, ls = set(), set()
        for t in group[:400]:
            pair = nodes_for.get(t["id"])
            if not pair:
                continue
            ns.update(pair)
            rid = rel_for.get(pair)
            if rid:
                ls.add(rid)
        return {"nodes": sorted(ns), "links": sorted(ls)}

    # --- discrepancies, one line per kind ---------------------------------
    for kind, (one_phrase, many_phrase, why) in FLAG_LABELS.items():
        group = [t for t in txns if any(f["id"] == kind for f in t["flags"])]
        if not group:
            continue
        worst = sorted(group, key=lambda t: -t["valueInr"])
        out.append({
            "kind": "flag", "tone": "bad" if kind != "noremit" else "warn",
            "title": f"{len(group):,} transaction"
                     f"{'' if len(group) == 1 else 's'} "
                     f"{one_phrase if len(group) == 1 else many_phrase}",
            "detail": why + " " + (
                f"Largest: {worst[0]['party' + 'Name']} → "
                f"{worst[0]['importer']} on Bill of Entry {worst[0]['boe']}, "
                f"INR {_fmt_inr(worst[0]['valueInr'])}."
                if len(group) > 1 else
                next(f["detail"] for f in group[0]["flags"] if f["id"] == kind)),
            "filter": f"only={kind}",
            "case": group[0]["id"] if len(group) == 1 else None,
            **refs(group),
        })

    # --- one party, several names ------------------------------------------
    multi = [p for p in parties.values()
             if len({normalise_name(a) for a in p["aliases"]}) > 1]
    if multi:
        out.append({
            "kind": "identity", "tone": "warn",
            "title": f"{len(multi):,} counterpart"
                     f"{'y is' if len(multi) == 1 else 'ies are'} filed under "
                     "more than one name",
            "detail": "Treated as one party here because TradePay pays them as "
                      "one. " + _listed([f"{p['name']} ({len(p['aliases'])})"
                                         for p in multi]) + ".",
            **refs([t for t in txns
                    if t["partyKey"] in {p["key"] for p in multi}]),
        })

    # --- two parties that are probably one ---------------------------------
    pairs = _near_duplicates(list(parties.values()))
    if pairs:
        out.append({
            "kind": "identity", "tone": "warn",
            "title": f"{len(pairs):,} pair"
                     f"{'' if len(pairs) == 1 else 's'} of counterparties may "
                     "be the same party",
            "detail": "The names share most of their length but are held "
                      "separately, so nothing compares one against the other. "
                      + _listed([f"{a['name']} / {b['name']}" for a, b in pairs])
                      + ".",
            **refs([t for t in txns if t["partyKey"] in
                    {n["key"] for pair in pairs for n in pair}]),
        })

    # --- one Bill of Entry number, two unrelated transactions --------------
    by_boe: dict[str, list[dict]] = {}
    for t in txns:
        by_boe.setdefault(str(t["boe"]), []).append(t)
    shared = {b: g for b, g in by_boe.items()
              if len(g) > 1 and len({x["importerKey"] for x in g}) > 1}
    if shared:
        example = sorted(shared.items())[0]
        dates = sorted({x["boeDate"] for x in example[1] if x["boeDate"]})
        out.append({
            "kind": "boe", "tone": "info",
            "title": f"{len(shared):,} Bill of Entry number"
                     f"{'' if len(shared) == 1 else 's'} "
                     f"{'is' if len(shared) == 1 else 'are'} used by more than "
                     "one importer",
            "detail": f"{example[0]} is held by "
                      + _listed(sorted({x["importer"] for x in example[1]}))
                      + (f", dated {' and '.join(dates)}" if len(dates) > 1 else "")
                      + ". The number is not unique; the invoice numbers are "
                        "what tell the transactions apart."
                      + (f" {len(shared) - 1:,} other numbers do the same."
                         if len(shared) > 1 else ""),
            **refs([x for g in shared.values() for x in g]),
        })

    # --- a counterparty behind several importers ---------------------------
    spread = {}
    for t in txns:
        spread.setdefault(t["partyKey"], set()).add(t["importerKey"])
    many = sorted([(k, v) for k, v in spread.items() if len(v) > 1],
                  key=lambda kv: -len(kv[1]))
    if many:
        out.append({
            "kind": "shared", "tone": "info",
            "title": f"{len(many):,} counterpart"
                     f"{'y supplies' if len(many) == 1 else 'ies supply'} more "
                     "than one of these importers",
            "detail": "Worth knowing when a discrepancy turns up on one of "
                      "them. " + _listed([
                          f"{parties[k]['name']} ({len(v)})" for k, v in many])
                      + ".",
            **refs([t for t in txns if t["partyKey"] in
                    {k for k, _ in many[:EXAMPLES]}]),
        })

    # --- one transaction carrying most of the value ------------------------
    total = sum(t["valueInr"] for t in txns) or 1.0
    big = max(txns, key=lambda t: t["valueInr"], default=None)
    if big and big["valueInr"] / total > 0.4 and len(txns) > 2:
        out.append({
            "kind": "size", "tone": "info",
            "title": f"One transaction is "
                     f"{big['valueInr'] / total * 100:,.0f}% of everything here",
            "detail": f"{big['partyName']} → {big['importer']}, "
                      f"INR {_fmt_inr(big['valueInr'])} of "
                      f"INR {_fmt_inr(total)} across {len(txns):,} transactions.",
            "case": big["id"], **refs([big]),
        })

    order = {"bad": 0, "warn": 1, "info": 2}
    out.sort(key=lambda f: (order.get(f["tone"], 3), -len(f.get("links") or [])))
    return out


def _near_duplicates(nodes: list[dict]) -> list[tuple[dict, dict]]:
    """Counterparties whose names are close enough to be one party filed twice.

    Only names opening on the same word are compared: a company filed twice is
    filed twice under nearly the same name, and bucketing that way turns a
    comparison of every pair into a comparison inside small groups.
    """
    buckets: dict[str, list[dict]] = {}
    for node in nodes:
        buckets.setdefault(node["key"].split(" ")[0][:6], []).append(node)
    out: list[tuple[dict, dict]] = []
    for group in buckets.values():
        if len(group) > 40:               # a bucket that big is a common word
            continue
        for i, a in enumerate(group):
            for b in group[i + 1:]:
                if _probably_same(a["key"], b["key"]):
                    out.append((a, b))
    return out


def _probably_same(a: str, b: str) -> bool:
    if not a or not b or a == b:
        return False
    short = min(len(a), len(b))
    if short < 8:
        return False
    run = longest_common_run(a.replace(" ", ""), b.replace(" ", ""))
    return run >= max(8, int(short * 0.6))


fmt_inr = _fmt_inr


# ---------------------------------------------------------------------------
# the plane
# ---------------------------------------------------------------------------
# Everyone in one space rather than two columns. Nothing is folded away here:
# that is the whole reason for the layout. A node's area is its value, so the
# eye lands on the money; its colour is its state, the same colour language as
# every other screen, so red still means a discrepancy and nothing else.

R_MIN, R_MAX = 7.0, 30.0
TONES = 7              # distinct country colours before the rest share one
LABEL_AT = 13.0        # a node smaller than this gets its name on hover only
LABEL_CAP = 40         # and no more than this many names stand at once


def _map(parties: dict, importers: dict, rels: list[dict]) -> dict:
    """Lay the whole book out in a plane and hand back finished coordinates."""
    from . import graphmap

    nodes = list(parties.values()) + list(importers.values())
    if not nodes:
        return {"nodes": [], "links": [], "box": "0 0 1 1", "width": 1,
                "height": 1, "components": 0, "maxR": 0}

    # Size follows the value, but on a log scale rather than by area. A book
    # spans three orders of magnitude - the largest counterparty here is 1,789
    # times the smallest - and sizing a disc by area means the smallest
    # thirteen all land on the floor within a pixel of each other while two
    # fill the screen. That is not a scale, it is a yes-or-no. On a log scale
    # the whole range is readable, at the price that a disc twice the width is
    # not twice the money; the caption says so rather than implying otherwise.
    values = [max(n["valueInr"], 1.0) for n in nodes]
    lo, hi = math.log10(min(values)), math.log10(max(values))
    span = (hi - lo) or 1.0
    radius = {n["id"]: round(
        R_MIN + (R_MAX - R_MIN)
        * (math.log10(max(n["valueInr"], 1.0)) - lo) / span, 2) for n in nodes}

    # A relationship worth more pulls its two ends closer, so the big trade
    # sits tight and the occasional one-off hangs off the edge where it shows.
    values = [r["valueInr"] for r in rels if r["valueInr"] > 0]
    vmax = max(values) if values else 1.0
    edges = [(r["source"], r["target"],
              0.6 + 0.9 * (math.log10(max(r["valueInr"], 1.0))
                           / math.log10(max(vmax, 10.0))))
             for r in rels]

    # Which relationships touch each entity. The two-column path gets this
    # from the fold step, which the plane does not run - and without it a
    # hover over a disc lights nothing, because nothing knows what it joins.
    for node in nodes:
        node["links"] = []
    by_id = {node["id"]: node for node in nodes}
    for r in rels:
        for end in ("source", "target"):
            node = by_id.get(r[end])
            if node is not None:
                node["links"].append(r["id"])

    placed = graphmap.cached_layout([n["id"] for n in nodes], edges, radius)
    pos = placed["pos"]

    # --- the names -------------------------------------------------------
    # Type is measured in pixels and the drawing is measured in its own
    # units, which the browser scales to fit. Setting a font size in drawing
    # units therefore sets a different size on screen for every book - on the
    # supplied one it came out at twice the diameter of the discs it was
    # labelling. So the fit scale is worked out here and the size divided
    # back through it, which puts the name at a readable size whatever the
    # book, and lets it grow when somebody zooms in, as it should.
    scale = min(STAGE_W / max(placed["w"], 1.0),
                STAGE_H / max(placed["h"], 1.0))
    font = round(LABEL_PX / max(scale, 0.05), 2)

    ranked = sorted(nodes, key=lambda n: (-radius[n["id"]], n["name"]))
    want = ranked if len(nodes) <= LABEL_CAP else [
        n for n in ranked[:LABEL_CAP] if radius[n["id"]] >= LABEL_AT]
    labels = _label_positions(want, pos, radius, font)

    # Counterparties take the colour of where they are. The importers are
    # all Indian, so a hue would say nothing about them - they stay one dark
    # ink, which also keeps them reading as the hubs they are. Countries are
    # ranked by value so the same country gets the same colour whichever way
    # the book is filtered, and the long tail shares the last tone rather
    # than the palette growing until no two colours can be told apart.
    weight: dict[str, float] = {}
    for n in nodes:
        if n["side"] != "party":
            continue
        weight[_country_of(n)] = weight.get(_country_of(n), 0.0) + n["valueInr"]
    order = sorted(weight, key=lambda c: (-weight[c], c))
    tone_of = {c: (i if i < TONES - 1 else TONES - 1)
               for i, c in enumerate(order)}

    out_nodes = []
    for n in nodes:
        x, y = pos.get(n["id"], (0.0, 0.0))
        spot = labels.get(n["id"])
        out_nodes.append({
            **n, "x": round(x, 1), "y": round(y, 1), "r": radius[n["id"]],
            "big": spot is not None,
            "lx": spot[0] if spot else round(x, 1),
            "ly": spot[1] if spot else round(y + radius[n["id"]] + font, 1),
            "anchor": spot[2] if spot else "middle",
            "short": _short(n["name"]),
            "country": _country_of(n),
            "tone": tone_of.get(_country_of(n), TONES - 1)
                    if n["side"] == "party" else -1,
            "tip": _node_tip({**n, "country": _country_of(n)}),
        })
    out_nodes.sort(key=lambda n: -n["r"])      # small discs draw on top

    out_links = []
    for r in rels:
        a, b = pos.get(r["source"]), pos.get(r["target"])
        if not a or not b:
            continue
        out_links.append({
            **r,
            "x1": round(a[0], 1), "y1": round(a[1], 1),
            "x2": round(b[0], 1), "y2": round(b[1], 1),
            "mx": round((a[0] + b[0]) / 2, 1), "my": round((a[1] + b[1]) / 2, 1),
            "w": round(0.9 + 3.6 * (math.log10(max(r["valueInr"], 1.0))
                                    / math.log10(max(vmax, 10.0))), 2),
            "href": (f"/cases/{r['cases'][0]}" if r["count"] == 1 and r["cases"]
                     else ""),
            "tip": _link_tip(r),
        })
    out_links.sort(key=lambda l: -l["w"])

    # The names hang off the discs, and a box drawn round the discs alone
    # clips whichever name sits at the top - which is what was cutting the
    # first label in half. Widen it to hold the text as well.
    x0, y0 = placed["x"], placed["y"]
    x1, y1 = x0 + placed["w"], y0 + placed["h"]
    for nd in out_nodes:
        if not nd["big"]:
            continue
        half = len(nd["short"]) * CHAR_W * font
        left = nd["lx"] - (half / 2 if nd["anchor"] == "middle"
                           else (half if nd["anchor"] == "end" else 0))
        x0, x1 = min(x0, left - 2), max(x1, left + half + 2)
        y0, y1 = min(y0, nd["ly"] - font * 1.1), max(y1, nd["ly"] + font * 0.4)

    return {
        "nodes": out_nodes, "links": out_links,
        "box": f"{x0:.1f} {y0:.1f} {x1 - x0:.1f} {y1 - y0:.1f}",
        "width": round(x1 - x0, 1), "height": round(y1 - y0, 1),
        "components": placed["components"],
        "maxR": max(radius.values()),
        "labelFont": font,
        "spread": f"{max(values) / max(min(values), 1.0):,.0f}",
        "legend": [{"name": c.title(), "tone": tone_of[c],
                    "count": sum(1 for n in nodes if n["side"] == "party"
                                 and _country_of(n) == c)}
                   for c in order],
    }


def _country_of(node: dict) -> str:
    """One country per counterparty, normalised, for grouping and colour."""
    for raw in node.get("countries") or ():
        done = normalise_country(raw)
        if done:
            return done
    return "Elsewhere"


# ---------------------------------------------------------------------------
# putting the names somewhere they can be read
# ---------------------------------------------------------------------------
# Two discs a short distance apart will have their names centred under them,
# and the names are far wider than the discs, so they print on top of one
# another: on the supplied book six of the eight groups came out as things
# like "LeSIGMA ALDRICH CHEMICALS PRI...", which is two companies' names
# interleaved. A name that cannot be read is worse than no name, because it
# also hides the one it collided with.
#
# So each name is tried below its disc, then above, then out to either side,
# and taken at the first position that clears every name already placed and
# every disc. One that fits nowhere is left to the hover, which is the right
# answer: the drawing stays legible and nothing is lost.

STAGE_W, STAGE_H = 1150.0, 700.0   # the panel a reader sees it in, roughly
LABEL_PX = 10.5                    # how big a name should look on screen
CHAR_W = 0.54                      # average glyph width, in ems
MIN_LABELS = 8                     # a graph with no names tells nobody anything


def _short(name: str, limit: int = 22) -> str:
    """A name at a length that can sit under a disc."""
    name = " ".join(str(name).split())
    if len(name) <= limit:
        return name
    cut = name[:limit].rsplit(" ", 1)[0]
    return (cut if len(cut) >= limit - 8 else name[:limit]).rstrip(" ,.") + "…"


def _label_positions(wanted: list[dict], pos: dict, radius: dict,
                     font: float) -> dict[str, tuple[float, float, str]]:
    """Where each name goes, or nothing if it has nowhere to go."""
    placed: list[tuple[float, float, float, float]] = []   # x0, y0, x1, y1
    out: dict[str, tuple[float, float, str]] = {}
    pad = font * 0.25

    def clear(box, nid, strict=True) -> bool:
        x0, y0, x1, y1 = box
        for bx0, by0, bx1, by1 in placed:
            if x0 < bx1 and bx0 < x1 and y0 < by1 and by0 < y1:
                return False
        if not strict:
            return True
        # A name may not sit on a disc either, its own excepted.
        for other, (ox, oy) in pos.items():
            if other == nid:
                continue
            r = radius[other]
            if (x0 < ox + r and ox - r < x1 and y0 < oy + r and oy - r < y1):
                return False
        return True

    def attempt(node, strict):
        nid = node["id"]
        if nid in out:
            return
        x, y = pos.get(nid, (0.0, 0.0))
        r = radius[nid]
        w = len(_short(node["name"])) * CHAR_W * font
        h = font * 1.15
        gap = r + font * 0.75
        tries = (
            (x, y + gap + h * 0.5, "middle"),          # below
            (x, y - gap - h * 0.2, "middle"),          # above
            (x + gap, y + h * 0.3, "start"),           # to the right
            (x - gap, y + h * 0.3, "end"),             # to the left
        )
        for tx, ty, anchor in tries:
            if anchor == "middle":
                x0, x1 = tx - w / 2, tx + w / 2
            elif anchor == "start":
                x0, x1 = tx, tx + w
            else:
                x0, x1 = tx - w, tx
            box = (x0 - pad, ty - h, x1 + pad, ty + pad)
            if clear(box, nid, strict):
                placed.append(box)
                out[nid] = (round(tx, 1), round(ty, 1), anchor)
                return

    for node in wanted:
        attempt(node, strict=True)

    # Zoomed right out, a readable name is wide next to a seven-pixel disc, so
    # on a large book the strict pass can place almost nothing - and a graph
    # with no names at all tells a reader nothing about what they are looking
    # at. The biggest few get a second try that only avoids other names, so
    # they may sit across a small disc. They are the largest things on the
    # page; a name on them is worth more than the disc it clips.
    if len(out) < MIN_LABELS:
        for node in wanted[:MIN_LABELS]:
            attempt(node, strict=False)
    return out


# ---------------------------------------------------------------------------
# what the hover card says
# ---------------------------------------------------------------------------
# The browser's own tooltip is an operating-system box: it waits a second,
# ignores the page's typography, cannot be styled and renders differently on
# every machine. On a drawing whose whole purpose is to be pointed at, that is
# the most-used surface on the page, so it is built here instead - the text is
# composed server-side and the script only places it.
#
# Fields are pipe-separated because the alternative is JSON inside an HTML
# attribute, which means escaping quotes in company names and getting it wrong
# once. A pipe never appears in a counterparty's name; it is stripped if it
# ever does.

def _clean(value) -> str:
    return " ".join(str(value or "").replace("|", "/").split())


def _node_tip(node: dict) -> dict:
    """The card for a counterparty or an importer."""
    rows = [_count(node["count"], "transaction"),
            f"INR {_fmt_inr(node['valueInr'])}"]
    if len(node["links"]) != 1:
        rows.append(_count(len(node["links"]), "trading relationship"))
    if node.get("flagged"):
        rows.append(f"{node['flagged']} of {node['count']} "
                    f"{'carries' if node['flagged'] == 1 else 'carry'} "
                    "a discrepancy")
    sub = ("Importer" if node["side"] == "importer" else
           f"Counterparty in {node['country'].title()}"
           if node.get("country") and node["country"] != "Elsewhere"
           else "Counterparty")
    return {"title": _clean(node["name"]), "sub": sub,
            "rows": "|".join(_clean(r) for r in rows),
            "foot": "Click to search the worklist for this party"}


def _link_tip(rel: dict) -> dict:
    """The card for one trading relationship."""
    rows = [_count(rel["count"], "transaction"),
            f"INR {_fmt_inr(rel['valueInr'])}"]
    if rel.get("currencies"):
        rows.append(", ".join(rel["currencies"]))
    if rel.get("boes"):
        rows.append(f"Bill of Entry {_listed(rel['boes'], limit=3)}")
    for flag in rel.get("flags") or ():
        rows.append(flag["label"])
    return {
        "title": f"{_clean(rel['party']) or 'Several counterparties'} "
                 f"\u2192 {_clean(rel['importer']) or 'several importers'}",
        "sub": "Trading relationship",
        "rows": "|".join(_clean(r) for r in rows),
        "foot": ("Click to open the transaction" if rel["count"] == 1
                 else "Click to list these in the worklist"),
    }
