"""Trade Collections — Maker Workbench.

Reads a ``.env`` beside the project, if there is one, before anything else
looks at the environment. A real environment variable always wins, so running

    PRICING_AGENT_PROVIDER=rules python -m uvicorn app.main:app

still does what it says even with a .env present.

This is a dozen lines rather than a dependency on purpose: one less package to
get approved, and the file format is the obvious subset — KEY=value, # comments,
optional surrounding quotes, blank lines ignored.
"""

from __future__ import annotations

import os
from pathlib import Path

_ENV_FILE = Path(__file__).resolve().parent.parent / ".env"


def load_env(path: Path = _ENV_FILE) -> list[str]:
    """Set any variable the file names that is not already set. Returns the names."""
    if not path.is_file():
        return []

    applied: list[str] = []
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export "):].strip()
        if not key or key in os.environ:
            continue                      # the real environment wins
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if value:
            os.environ[key] = value
            applied.append(key)
    return applied


LOADED_FROM_ENV_FILE = load_env()
