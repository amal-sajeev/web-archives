"""Where the pricing agent's thinking actually happens.

Four providers, tried in order, so the same agent runs in the bank's dev
environment and on a laptop with nothing configured:

    vertex    Gemini on Vertex AI, authenticated by Workload Identity
              Federation. This is the deployment target.
    anthropic Claude through the Anthropic API, if a key is in the environment.
    claude-cli The `claude` binary, run headlessly. Needs no key, so it is what
              makes the agent testable locally.
    rules     No model at all: the regex reading. Clearly labelled as such, so
              a trace can never be mistaken for reasoning that did not happen.

Selection is overridable with PRICING_AGENT_PROVIDER. Nothing here raises on a
missing dependency — an unavailable provider simply reports itself unavailable
and the next one is tried.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field

# Resolved ADC lookups, shared by every VertexGemini instance.
_VERTEX_CREDS_LOCK = threading.Lock()
_VERTEX_CREDS_CACHE: dict[str, tuple[float, str]] = {}


@dataclass
class Completion:
    """One model turn, with whatever reasoning the provider exposed."""

    text: str
    provider: str
    model: str
    thinking: str | None = None
    latency_ms: int = 0
    usage: dict[str, int] = field(default_factory=dict)
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None and bool(self.text.strip())


class Provider:
    name = "provider"
    model = ""

    def available(self) -> tuple[bool, str]:
        """(usable, why not) — never raises."""
        return False, "not implemented"

    def complete(self, system: str, prompt: str, *, max_tokens: int = 4096) -> Completion:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Vertex AI — the deployment target
# ---------------------------------------------------------------------------

class VertexGemini(Provider):
    """Gemini on Vertex AI, authenticated by Application Default Credentials.

    This follows the pattern the evaluation service already uses in this estate
    (see its docs/VERTEX_INTEGRATION.md), so one credential setup serves both.

    **No credential file is ever read here.** ``GOOGLE_APPLICATION_CREDENTIALS``
    points at a Workload Identity Federation *credential configuration* — an
    ``external_account`` file that tells google-auth to read a local JWT,
    exchange it at Google's STS endpoint and impersonate a service account.
    ``google.auth.default()`` does all of that on its own, and no long-lived key
    material exists anywhere. Locally, ``gcloud auth application-default login``
    supplies the same thing through a different branch of the ADC search order.

    Two things are deliberate:

    * **The project must be set.** Without it the Google libraries quietly fall
      back to the Gemini Developer API and then fail complaining about a missing
      API key, which sends you looking in the wrong place entirely.
    * **Credentials are resolved before the client is built.** google-genai
      resolves them early in ``BaseApiClient.__init__`` but assigns
      ``_async_httpx_client`` late, so a credentials failure leaves a half-built
      object whose ``__del__`` raises ``AttributeError: 'BaseApiClient' object
      has no attribute '_async_httpx_client'``. Checking up front turns that
      into a message that says what to do.

    Configure with the same names the evaluation service uses:

        PROJECT_NAME            the GCP project Vertex is called in
        PROJECT_LOCATION        region, default us-central1
        PRICING_AGENT_MODEL     model id, default gemini-2.5-pro
        GOOGLE_APPLICATION_CREDENTIALS   path to the WIF external_account file

    Behind a corporate proxy, Google traffic (Azure AD, Google STS, IAM
    Credentials and Vertex) also needs ``SSL_CERT_FILE`` and
    ``REQUESTS_CA_BUNDLE`` pointing at the internal CA bundle, or the TLS
    handshake fails before any of this is reached.
    """

    name = "vertex"

    # The resolved credential is reused for this long before resolving again, so
    # a rotated or revoked credential is noticed without a lookup per call. The
    # WIF JWT is short-lived — it is regenerated hourly — and google-auth
    # refreshes it underneath us; this TTL is only about re-resolving ADC.
    CREDENTIALS_TTL_S = 300.0

    def __init__(self) -> None:
        self.project = (os.getenv("PROJECT_NAME")
                        or os.getenv("VERTEX_PROJECT")
                        or os.getenv("GOOGLE_CLOUD_PROJECT"))
        self.location = (os.getenv("PROJECT_LOCATION")
                         or os.getenv("VERTEX_LOCATION")
                         or os.getenv("GOOGLE_CLOUD_LOCATION")
                         or "us-central1")
        # The project, region and credential path are shared estate settings and
        # use the estate's names. The model is this application's own choice, so
        # it gets its own name: JUDGE_MODEL belongs to the evaluation service and
        # is already set to something else on developer machines.
        self.model = (os.getenv("PRICING_AGENT_MODEL")
                      or os.getenv("VERTEX_MODEL")
                      or "gemini-2.5-pro")
        self.thinking_budget = int(os.getenv("VERTEX_THINKING_BUDGET", "4096"))
        self.timeout = float(os.getenv("VERTEX_CALL_TIMEOUT", "120"))
        self._client = None
        self._why: str | None = None
        self.credential_kind: str | None = None

    # -- credentials -------------------------------------------------------
    def _resolve_credentials(self) -> str:
        """Resolve ADC and return the credential class name.

        The class name is the useful diagnostic: ``Credentials`` means a gcloud
        user login, ``IdentityPoolCredentials`` or ``ExternalAccountCredentials``
        means Workload Identity Federation is actually in play.
        """
        import google.auth

        try:
            creds, _ = google.auth.default()
        except Exception as exc:
            raise RuntimeError(
                "No Application Default Credentials available for Vertex AI. "
                "Locally, run: gcloud auth application-default login. "
                "In a deployed environment, check the Workload Identity "
                "Federation credential config is mounted and "
                f"GOOGLE_APPLICATION_CREDENTIALS points at it. ({exc})"
            ) from exc
        return type(creds).__name__

    def require_credentials(self) -> str:
        """Guard, and report which ADC branch answered. Failures are not cached."""
        if not self.project:
            raise RuntimeError(
                "PROJECT_NAME is not set, so the Google libraries would fall "
                "back to the Gemini Developer API and fail asking for an API "
                "key. Set PROJECT_NAME to the project Vertex is called in.")

        now = time.monotonic()
        with _VERTEX_CREDS_LOCK:
            cached = _VERTEX_CREDS_CACHE.get(self.project)
            if cached and now - cached[0] < self.CREDENTIALS_TTL_S:
                self.credential_kind = cached[1]
                return cached[1]

        kind = self._resolve_credentials()
        with _VERTEX_CREDS_LOCK:
            _VERTEX_CREDS_CACHE[self.project] = (now, kind)
        self.credential_kind = kind
        return kind

    def available(self) -> tuple[bool, str]:
        if self._client is not None:
            return True, ""
        try:
            from google import genai  # noqa: F401
        except Exception as exc:
            return False, f"google-genai is not installed ({exc})"
        try:
            self.require_credentials()
        except RuntimeError as exc:
            return False, str(exc)
        try:
            from google import genai
            # project= and location= with vertexai=True select Vertex; the
            # credentials come from ADC, which is the whole point of WIF.
            self._client = genai.Client(vertexai=True, project=self.project,
                                        location=self.location)
        except Exception as exc:
            return False, f"could not open a Vertex client ({type(exc).__name__}: {exc})"
        return True, ""

    def describe(self) -> str:
        kind = self.credential_kind
        if kind in ("IdentityPoolCredentials", "ExternalAccountCredentials",
                    "AwsCredentials", "PluggableAuthCredentials"):
            how = f"WIF ({kind})"
        elif kind:
            how = f"ADC ({kind})"
        else:
            how = "ADC"
        return f"{self.model} (vertex {self.location}, {how})"

    def complete(self, system: str, prompt: str, *, max_tokens: int = 4096) -> Completion:
        ok, why = self.available()
        if not ok:
            return Completion("", self.name, self.model, error=why)

        from google.genai import types
        started = time.perf_counter()
        try:
            response = self._client.models.generate_content(
                model=self.model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=system,
                    temperature=0.0,
                    max_output_tokens=max_tokens,
                    response_mime_type="application/json",
                    http_options=types.HttpOptions(timeout=int(self.timeout * 1000)),
                    thinking_config=types.ThinkingConfig(
                        include_thoughts=True,
                        thinking_budget=self.thinking_budget),
                ),
            )
        except Exception as exc:
            return Completion("", self.name, self.describe(),
                              latency_ms=int((time.perf_counter() - started) * 1000),
                              error=f"{type(exc).__name__}: {exc}")

        answer, thoughts = [], []
        for candidate in (response.candidates or []):
            for part in (getattr(candidate.content, "parts", None) or []):
                text = getattr(part, "text", None)
                if not text:
                    continue
                (thoughts if getattr(part, "thought", False) else answer).append(text)

        usage = {}
        meta = getattr(response, "usage_metadata", None)
        if meta is not None:
            usage = {"input": getattr(meta, "prompt_token_count", 0) or 0,
                     "output": getattr(meta, "candidates_token_count", 0) or 0,
                     "thinking": getattr(meta, "thoughts_token_count", 0) or 0}

        return Completion(
            text="".join(answer).strip(),
            provider=self.name,
            model=self.describe(),
            thinking="".join(thoughts).strip() or None,
            latency_ms=int((time.perf_counter() - started) * 1000),
            usage=usage,
        )


def reset_vertex_credentials_cache() -> None:
    """Forget resolved ADC lookups, for tests and credential rotation."""
    with _VERTEX_CREDS_LOCK:
        _VERTEX_CREDS_CACHE.clear()


# ---------------------------------------------------------------------------
# Anthropic API
# ---------------------------------------------------------------------------

class AnthropicAPI(Provider):
    name = "anthropic"

    def __init__(self) -> None:
        self.model = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")
        self.key = os.getenv("ANTHROPIC_API_KEY")
        self.budget = int(os.getenv("ANTHROPIC_THINKING_BUDGET", "4000"))

    def available(self) -> tuple[bool, str]:
        if not self.key:
            return False, "ANTHROPIC_API_KEY is not set"
        try:
            import anthropic  # noqa: F401
        except Exception as exc:
            return False, f"the anthropic package is not installed ({exc})"
        return True, ""

    def complete(self, system: str, prompt: str, *, max_tokens: int = 4096) -> Completion:
        ok, why = self.available()
        if not ok:
            return Completion("", self.name, self.model, error=why)

        import anthropic
        started = time.perf_counter()
        # Extended thinking needs headroom above the budget for the answer.
        budget = max(1024, min(self.budget, max_tokens - 1024))
        try:
            message = anthropic.Anthropic(api_key=self.key).messages.create(
                model=self.model,
                max_tokens=max(max_tokens, budget + 1024),
                system=system,
                thinking={"type": "enabled", "budget_tokens": budget},
                messages=[{"role": "user", "content": prompt}],
            )
        except Exception as exc:
            return Completion("", self.name, self.model,
                              latency_ms=int((time.perf_counter() - started) * 1000),
                              error=f"{type(exc).__name__}: {exc}")

        answer, thoughts = [], []
        for block in message.content:
            if block.type == "text":
                answer.append(block.text)
            elif block.type == "thinking":
                thoughts.append(block.thinking)

        return Completion(
            text="".join(answer).strip(),
            provider=self.name,
            model=self.model,
            thinking="".join(thoughts).strip() or None,
            latency_ms=int((time.perf_counter() - started) * 1000),
            usage={"input": message.usage.input_tokens,
                   "output": message.usage.output_tokens},
        )


# ---------------------------------------------------------------------------
# the claude CLI — what makes this testable with nothing configured
# ---------------------------------------------------------------------------

class ClaudeCLI(Provider):
    """The `claude` binary, run headlessly.

    It carries its own authentication, so this is the provider that works on a
    developer machine with no API key and no cloud project. It does not return
    thinking blocks, which is the reason the agent is asked to put its
    reasoning in the answer rather than relying on the provider to expose it.
    """

    name = "claude-cli"

    def __init__(self) -> None:
        self.model = os.getenv("CLAUDE_CLI_MODEL", "sonnet")
        self.binary = os.getenv("CLAUDE_CLI_BINARY") or shutil.which("claude")
        self.timeout = int(os.getenv("CLAUDE_CLI_TIMEOUT", "180"))

    def available(self) -> tuple[bool, str]:
        if not self.binary:
            return False, "the claude CLI is not on PATH"
        return True, ""

    def complete(self, system: str, prompt: str, *, max_tokens: int = 4096) -> Completion:
        ok, why = self.available()
        if not ok:
            return Completion("", self.name, self.model, error=why)

        # The prompt goes in on stdin, not as an argument. On Windows the CLI is
        # a .CMD wrapper, and cmd.exe truncates a command line past 8191
        # characters - a system prompt and a charge instruction together go well
        # past that, and the call hangs rather than failing.
        argv = [self.binary, "-p", "--output-format", "json"]
        if self.model:
            argv += ["--model", self.model]
        stdin_text = system + "\n\n---\n\n" + prompt

        started = time.perf_counter()
        try:
            done = subprocess.run(argv, input=stdin_text, capture_output=True,
                                  text=True, timeout=self.timeout,
                                  encoding="utf-8", errors="replace")
        except subprocess.TimeoutExpired:
            return Completion("", self.name, self.model,
                              latency_ms=int((time.perf_counter() - started) * 1000),
                              error=f"the claude CLI did not answer within "
                                    f"{self.timeout}s")
        except Exception as exc:
            return Completion("", self.name, self.model,
                              error=f"{type(exc).__name__}: {exc}")

        latency = int((time.perf_counter() - started) * 1000)
        if done.returncode != 0:
            detail = (done.stderr or done.stdout or "").strip()[:400]
            return Completion("", self.name, self.model, latency_ms=latency,
                              error=f"the claude CLI exited {done.returncode}: {detail}")

        text, usage, model = done.stdout.strip(), {}, self.model
        try:
            envelope = json.loads(done.stdout)
            if isinstance(envelope, dict):
                text = (envelope.get("result") or "").strip() or text
                model = envelope.get("modelUsage") and \
                    next(iter(envelope["modelUsage"]), self.model) or self.model
                raw = envelope.get("usage") or {}
                usage = {"input": raw.get("input_tokens", 0),
                         "output": raw.get("output_tokens", 0)}
        except json.JSONDecodeError:
            pass

        return Completion(text=text, provider=self.name, model=model,
                          latency_ms=latency, usage=usage)


# ---------------------------------------------------------------------------
# selection
# ---------------------------------------------------------------------------

ALL = ["vertex", "anthropic", "claude-cli"]


def _order() -> list[str]:
    """Which providers this deployment admits, in preference order.

    A build that is only ever meant to reach one of them should not list the
    others on its own status page: the page is a statement about the
    deployment, and naming a fallback that is neither configured nor
    permitted there is a statement about the machine it was built on.

        AGENT_PROVIDERS=vertex

    Unset, every provider is listed, which is what local development wants.
    """
    want = [p.strip().lower()
            for p in os.getenv("AGENT_PROVIDERS", "").split(",") if p.strip()]
    if not want:
        return list(ALL)
    return [p for p in ALL if p in want] or list(ALL)


ORDER = _order()

_BUILDERS = {"vertex": VertexGemini, "anthropic": AnthropicAPI,
             "claude-cli": ClaudeCLI}


def build(name: str) -> Provider | None:
    builder = _BUILDERS.get(name)
    return builder() if builder else None


def preference() -> list[str]:
    """Which providers to try, in order. PRICING_AGENT_PROVIDER pins one."""
    forced = (os.getenv("PRICING_AGENT_PROVIDER") or "").strip().lower()
    if forced in _BUILDERS:
        return [forced]
    if forced == "rules":
        return []
    return list(ORDER)


def resolve() -> tuple[Provider | None, list[dict]]:
    """The first usable provider, and why each earlier one was skipped."""
    tried: list[dict] = []
    for name in preference():
        provider = build(name)
        if provider is None:
            continue
        ok, why = provider.available()
        tried.append({"provider": name, "model": provider.model,
                      "available": ok, "reason": why or None})
        if ok:
            return provider, tried
    return None, tried


def status() -> list[dict]:
    """Every provider and whether it could run right now, for the UI.

    For Vertex this also reports which branch of the ADC search order answered,
    by credential class name. That one string tells you whether Workload
    Identity Federation is actually in play or whether you are quietly running
    on somebody's gcloud login:

        Credentials                 a gcloud user login
        IdentityPoolCredentials     WIF
        ExternalAccountCredentials  WIF
        ServiceAccountCredentials   a service-account key file
    """
    out = []
    for name in ORDER:
        provider = build(name)
        ok, why = provider.available()
        row = {"provider": name, "model": provider.model,
               "available": ok, "reason": why or None,
               "role": {"vertex": "deployment target",
                        "anthropic": "API fallback",
                        "claude-cli": "local testing"}[name]}
        kind = getattr(provider, "credential_kind", None)
        if kind:
            row["credentialKind"] = kind
            row["federated"] = kind in ("IdentityPoolCredentials",
                                        "ExternalAccountCredentials",
                                        "AwsCredentials",
                                        "PluggableAuthCredentials")
            row["model"] = provider.describe()
        out.append(row)
    return out
