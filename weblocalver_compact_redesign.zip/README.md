# Trade Collections — Maker Workbench

An import-collections maker workbench for the IDPMS / TradePay → TF3 flow,
served in **two house styles off one API**. Same data, same routes, same
behaviour — only the presentation differs.

The cases are the **real sample transactions** the bank supplied: 22 IDPMS
invoice lines, the matching TradePay records, the booked deals, the FX card
rates and the Autobahn charge instructions, all converted to JSON under
`app/data/`. Nothing is invented — no service levels, no priorities, no
pre-assigned owners. The only state the application adds is the state a person
creates by using it.

The charge instructions are free-format prose, and they are read by an
**AI pricing agent** whose reasoning opens from the case. See
[docs/pricing-agent.md](docs/pricing-agent.md).

## Run

Double-click **`run.bat`**. The first run builds a local `.venv`, installs what
it needs and opens the browser; after that it starts in a couple of seconds.
Pass a port if 8000 is busy:

```
run.bat 8080
```

By hand, if you prefer:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m uvicorn app.main:app --port 8000
```

| Link | View |
| --- | --- |
| `http://127.0.0.1:8000/?v=desk` | **Desk** — the collections-desk interpretation |
| `http://127.0.0.1:8000/?v=corp` | **Corporate** — the project deck's house style |

Either link is shareable and the choice sticks via a cookie. Both carry a
switch link in the top bar.

## The flow

1. **Cases are built from IDPMS**, grouped by Bill of Entry *and importer*.
   A Bill of Entry number is not unique and ordinarily carries several
   invoices: 9152082 is Hella's consignment of 28 March 2025 through Gurgaon
   ICD *and* Rothe Erde's of 9 May 2026 through Mumbai. Repeated invoice lines
   are deduplicated, keeping the latest shipment date.
2. **The transaction key is Bill of Entry *and* invoice number**, together, on
   every lookup — not the Bill of Entry with the invoice number held back as a
   tie-breaker. 9152082 carries four TradePay rows that are all Rothe Erde's,
   so the number alone would hand Hella's case somebody else's drawer, country
   and currency. The lookup is also done one invoice at a time, which is what
   reports that a remittance covers four of five invoices and names the fifth
   rather than leaving the whole Bill of Entry looking settled or broken.
   And an invoice with no row under its own Bill of Entry is looked for under
   every other number before anyone is told there is no remittance: a row found
   there is a correction to make, not a payment to chase, and the two read
   differently on screen. Where nothing matches anywhere, the checks name the
   invoice they were looking for, say where they searched, and give the dates of
   the two Bills of Entry that share the number — Hella's 28 March 2025
   against Rothe Erde's 9 May 2026 — rather than comparing the wrong record.
3. **The three specified consistency checks run** — drawer name, drawer country,
   currency. The procedure writes each as
   `Trade Pay ↔ IDPMS / Trade Pay Documents / WFMS`, so the reference value is a
   **cascade**: IDPMS first, then the supporting documents attached in TradePay,
   then WFMS. Only IDPMS has been supplied; the other two report themselves
   unavailable rather than being skipped, and a check that needs them says which
   one it is waiting on. Names are normalised so `TWINTECH(S) PTE LTD` matches
   `TWINTECH S PTE LTD`, countries so `PEOPLES REP OF CHINA` matches `CHINA`
   (Hong Kong is deliberately kept separate — that difference is real), and
   references so `INV2606/12999` matches `INV260612999`.
4. **The ports are resolved.** A five-digit code is searched as it stands, a
   three-digit code with its two-letter country prefix (`SIN` → `SGSIN`). Every
   code in the sample data resolves. Where a code is not in the directory, the
   case blocks and the maker types the name in — recorded as theirs.
5. **The charges are read** by the pricing agent out of the client's Autobahn
   processing text, with the forex conversion clause and GST computed from the
   published tiers.
6. **Every figure is worked out again**, by a route that shares no code with
   the one that produced it, and a disagreement holds the case for a person.
   See *Checking the arithmetic* below.
7. **The maker validates**, the checker approves, and the case is posted to TF3.

Checks beyond the specified three are labelled as such rather than presented as
requirements — an invoice-amount difference, which invoices the remittance
covers, an unresolved port. Several invoices under one Bill of Entry is the
ordinary case and is not reported as anything; neither is a number shared with
another importer, since the invoice number is what tells them apart and a maker
has nothing to do about either.

## Checking the arithmetic

A model that is fluent about money is not thereby accurate about it: it will
write `INR 450 x 3 = INR 1,250` with total confidence and carry it into a
total. So the agent reads the instruction and decides *what* to charge — which
rate, charged per what, how many of them — and `app/agent/arithmetic.py`
computes every number.

That alone is not enough, because the computing code can be wrong too. The
forex fee used to be "verified" by calling the same function that produced it,
which is a check that cannot fail. Everything is now derived a second time by a
different route and compared:

| Figure | Checked against |
|---|---|
| The rupee value exchanged | The booked deal's rate applied to this transaction's own amount, or the rate card |
| Each charge | Its rate times a unit count that this transaction actually has — 1 remittance, or its invoice lines, and nothing else |
| Each rate and quote | The words of the instruction they were read from |
| Forex conversion fee | The clause walked band by band, charging each band's percentage on the slice of the gross inside it, rather than selecting a tier |
| The clause itself | Each band's fixed figure must equal what the bands below it accumulate to |
| GST | 18% of a base that is the other lines and excludes GST |
| The total | The sum of the lines, and separately commission + forex + GST |
| All of it | Positive, finite, in whole paise, and not an implausible fraction of the remittance |

Anything that disagrees pulls the case back to *needs confirmation*, names the
difference in rupees, and appears as its own step in the live run panel — so a
maker watches the re-check happen rather than taking it on faith.

Two calculation faults turned up when this went in, both in the deterministic
code rather than the model's answer:

- A single FX deal settles Rothe Erde's whole shipment across two Bills of
  Entry. Its INR total was being applied in full to *each* case, so the forex
  clause was charged at its INR 60,000 cap twice. A deal is evidence of a
  *rate*; its total is this transaction's only when the deal is for this
  transaction and nothing else.
- A deal carrying a rate but no INR total was ignored altogether, so four
  cases converted at a card rate well away from the rate they had dealt at —
  Symrise at 50.26 where the booked deal was 75.2055.

## Looking at it

```
python tools/shoot.py                   every screen, both views, into shots/
python tools/shoot.py "/network?v=desk" one page
```

Headless Chrome, no dependency beyond a browser that is already installed.
It is in the repository because a house style cannot be reviewed by reading
its stylesheet: the desk view's contrast failure, its collided graph labels
and its clipped top row were each found by looking at a picture of the page,
and none of them by reading the CSS that caused them.

Both views are measured rather than eyeballed. Every text colour clears
4.5:1 on every surface it is used on — the desk view's lowest is 4.62, and
its `--ink-faint` used to be 2.89 on the page ground, which is why the quiet
labels were unreadable. The desk ground was deepened so a sheet of paper laid
on it reads as a separate thing: it stood paper off at 1.29 before, which is
barely a difference, and a list of rows looked like beige text on beige
rather than documents on a desk.

## The counterparty map

`/network` draws the book as a graph of who trades with whom. It exists
because the things worth a maker's attention are often *between* two rows and
a list can only show one row at a time — one party filed under three names,
one Bill of Entry number on two unrelated shipments, a supplier in Hong Kong
paid as though it were in mainland China. Those are worked out server-side and
listed in words under the drawing, grouped by kind so the list stays readable
whatever the size of the book.

There are two drawings of the same data, because each stops working where the
other starts.

**Columns** — counterparties left, importers right, one ribbon per trading
relationship, thickness the rupee value on a log scale. Exact, easy to read
along, ordered by the barycentre heuristic to minimise crossings (zero on the
supplied data) with crossings counted by a Fenwick tree. Its limit is rows: a
screen holds about 22, so a bigger book has to fold entities away by country,
and folding hides the thing the page exists to show.

**Plane** — every entity a disc in one space, area proportional to value,
joined where they trade. Nothing is folded. A plane does not run out of rows,
and *where* a disc sits is information: things that trade together pack
together, and a pair alone at the edge is a counterparty nobody else deals
with. Pan by dragging, zoom by scrolling; labels stand on the largest discs
and appear on hover for the rest.

The plane is what `/network` opens on; columns are one click away. Choosing
between them by entity count was neat and wrong — the nav link landed on a
different drawing depending on how much was in the book that morning, so
nobody could learn what the page looks like, and on the supplied data it
always landed on the columns. Which drawing suits the question is the
reader's call, not the row count's. Both share the filter bar and the
findings list, and both are query strings rather than client state, so a
narrowed map is a link somebody can send.

### Laying out the plane

Real trade data decides the method. The supplied sample is 17 entities in 8
components with a median degree of 1: most counterparties sell to exactly one
importer, so the graph is not one tangle but a scatter of small stars with the
occasional hub bridging a few. So `app/graphmap.py` splits into connected
components, lays each out by the cheapest method that suits its shape — a
point, a pair, a hub and a ring for a star, Fruchterman-Reingold for anything
else — and packs the components with front-chain circle packing.

It is deterministic: seeded on a golden-angle spiral in a stable order, no
random number generator anywhere, so the same book draws the same picture
every time and a screenshot still means something next week. It runs on the
server and is cached against a fingerprint of the graph, so the page arrives
as finished SVG and panning recomputes nothing.

| transactions | entities | groups | canvas | cold | cached |
|---|---|---|---|---|---|
| 12 | 17 | 8 | 354 × 363 | 1 ms | 0.7 ms |
| 130 | 158 | 29 | 1130 × 1200 | 83 ms | 6.6 ms |
| 349 | 426 | 79 | 1963 × 2017 | 243 ms | 20 ms |
| 789 | 954 | 167 | 2849 × 2886 | 590 ms | 43 ms |

Two mistakes worth recording, because both made the picture useless in the
same way — everything correct, every node a speck:

- Fruchterman-Reingold's `k` is the ideal *edge length*, a property of how big
  a node is. Deriving it from a notional drawing area, as the classic
  formulation does, scaled it by √n and spread a fifty-node component over a
  thousand pixels of mostly nothing.
- The algorithm is defined on a bounded frame, and the bound is not
  decoration. Nodes sharing no edge feel only repulsion, so without it a
  sparse component inflates for as many iterations as it is given. Leaving it
  out gave a 57-node component a radius of 1,392 where 220 was right.

Together those two had 1,026 entities occupying 17,844 × 15,629. Fixed, the
same graph is 2,830 × 2,722.

## The pricing agent

The charge instruction held against a client is prose, and it contradicts
itself. Hella's reads `INR 450 per document` on one line and
`Pricing to be levied at remittance level` on the next; on a remittance covering
three invoices those are INR 1,350 and INR 450. A regex picks one silently.

The agent reads it, prices the lower figure, says what the other reading would
cost, and marks the case for a human. Its reasoning opens from the charges card:
the instruction, the numbered argument, the exact words behind each decision,
what it deliberately did not charge, and every figure re-computed independently.

It runs on **Gemini via Vertex AI with Workload Identity Federation** in the
bank's environment, falls back to the Anthropic API, then to the local `claude`
CLI for testing, then to pattern matching — which it labels as such on every
case rather than passing off as reasoning. `GET /api/agent/status` says which
one is live.

> On its first run against real data the agent objected that the forex
> conversion fee applied 0.5% to the whole gross when the clause charges it only
> on the amount above one lakh. It was right, and the calculation was fixed.

## Where the real systems plug in

Each external system is mocked in its own module under `app/sources/`, and
mounted read-only under `/api/mock`. Replacing a mock with a real integration
means changing that one module; `store.py` does not care where the data came
from.

| Module | Real source |
| --- | --- |
| `sources/idpms.py` | IDPMS — the Bills of Entry and their invoice lines |
| `sources/tradepay.py` | The TradePay portal's outward remittance records |
| `sources/ports.py` | The port directory (volza.com/ports) |
| `sources/autobahn.py` | Autobahn / OEMS, Products tab, the *Processing* field |
| `sources/checks.py` | The specified consistency checks |
| `sources/tf3.py` | TF3 — the posting of the final data and charges |
| `agent/providers.py` | Vertex AI, the Anthropic API, the `claude` CLI |

The JSONs under `app/data/` are regenerated from the supplied workbooks with:

```powershell
.venv\Scripts\python tools\build_mock_data.py
```

A port directory is loaded with:

```powershell
.venv\Scripts\python tools\load_ports.py <the-directory>.json
```

It takes a JSON array of `{code, name, country, unlocode}`, checks it against
the codes the sample data actually uses, and refuses to write if any are missing
— so a truncated file cannot half-load. Entries marked `"confident": false` are
recorded under `"unverified"` in `ports.json` rather than silently trusted.

## Taking it to another environment

Copy `.env.example` to `.env` and fill in the Vertex settings. It is read at
start-up, and a real environment variable always beats the file, so pinning a
provider on the command line still works:

```powershell
copy .env.example .env
.venv\Scripts\python -m uvicorn app.main:app --port 8000
```

`.env` is gitignored and excluded from the distribution zip — only
`.env.example` travels.

`GET /api/agent/status` is the first thing to check once it is up: it names the
provider that answered and, for Vertex, the credential class, which is what
tells you whether Workload Identity Federation is really in play or whether you
are on somebody's gcloud login.

## Making a Vertex-only build

The agent carries two development backends besides Vertex so it can be worked on
without a cloud project. Neither is usable in a deployed environment. To produce
a copy with only Vertex and the no-model fallback:

```powershell
.venv\Scripts\python toolsertex_only.py ..	rademo-vertex
```

It rewrites the source, the dependencies, the configuration and the
documentation, then **verifies its own output** — if one mention survives
anywhere in the copy it reports the file and line and exits non-zero. It also
imports the result and prints the remaining providers, so a copy that does not
run never passes silently.

The original is untouched, so local development keeps working.

## Resetting between demo runs

**Reset the demo** sits in the footer of every page. It discards every maker and
checker action — settled checks, typed port names, queries, validations,
approvals and TF3 postings — re-reads `app/data/*.json` and puts all twelve
cases back through the pipeline, leaving the queue exactly as it opens.

It is immediate, because the pricing agent'"'"'s readings are cached on (client,
document count) and survive a reset; they do not depend on anything a maker did.
A server restart clears that cache, so the first run afterwards costs one model
call per priced client.

`POST /api/demo/reset {"run": false}` does the same but leaves the cases unrun,
if you would rather show the pipeline working live.

## API

Full reference at `/docs`. The screens use exactly these routes.

```
GET   /api/cases              ?view= &search= &importer= &currency= &status= &sort= &direction=
GET   /api/cases/counts | /live
GET   /api/cases/{id}         | /state
GET   /api/agent/status       which model is reading the charge instructions
GET   /api/checks/sources     the IDPMS / TradePay documents / WFMS cascade

POST  /api/cases/{id}/ports/{loading|discharge}      {name, note}
POST  /api/cases/{id}/checks/{cid}/resolve           {resolution}
POST  /api/cases/{id}/charges/recalculate            re-reads, bypassing the cache
POST  /api/cases/{id}/queries                        {reason, recipient, check_id}
POST  /api/cases/{id}/queries/{qid}/answer           {response}
POST  /api/cases/{id}/start | /validate | /approve | /return | /undo
POST  /api/cases/run-all
POST  /api/demo/reset                                {run}  put the demo back
POST  /api/session/role                              {role}
```

The mocked external systems, so they can be exercised on their own:

```
GET   /api/mock/idpms | /idpms/consignments | /tradepay
GET   /api/mock/ports/{code} | /ports/status
GET   /api/mock/autobahn/{client} | /autobahn/{client}/quote
GET   /api/mock/checks/{boe}
GET   /api/mock/tf3                 everything posted so far
POST  /api/mock/reload              re-read app/data/*.json from disk
```

## Layout

```
app/
  main.py            page routes + theme resolution
  api.py             the application's own JSON API
  store.py           cases, the pipeline, undo
  models.py          Pydantic schemas (the UI contract)
  network.py         the counterparty map: identity, findings, the columns
  graphmap.py        the plane: components, force layout, circle packing
  text.py            counts and plurals, so "1 check" is never "1 check(s)"
  agent/
    pricing.py       the pricing agent: prompt, parsing, the reading
    arithmetic.py    every figure re-derived by a second route
    providers.py     Vertex / Anthropic / claude CLI / rules
  sources/           one module per mocked external system
  data/              the sample data as JSON
  templates/_shared/ the map's markup, shared by both house styles
  templates/desk/    base, queue, case, network, reference, partials/
  templates/corp/    the same screens in the deck's house style
  static/css/        desk.css, corp.css
  static/js/         app.js, queue.js, case.js, network.js
tools/
  build_mock_data.py rebuilds app/data/*.json from the supplied workbooks
  shoot.py           screenshots every screen in both views, headless
docs/
  pricing-agent.md   the agent, and the Vertex / WIF setup
```

## Still outstanding

- **`INGHR6` is unverified.** The loaded directory names it Garhi Harsaru
  Inland Container Depot, but whoever produced it was not sure. It is listed
  under `"unverified"` in `app/data/ports.json` and should be confirmed against
  the real directory before this is used in anger.
- **Only 3 of the 12 importers have pricing on file in Autobahn.** That is what
  the sample data contains, so the other cases correctly report that there is
  nothing to charge rather than inventing a rate.
- **Five genuine discrepancies remain, and should.** Putzmeister's invoice
  `2025XYW65` reads `15,255.93 EUR` in TradePay and `486 USD` in IDPMS; Sigma
  Aldrich's drawer is in Hong Kong per IDPMS and the Peoples Rep of China per
  TradePay, and is named `Leap Chem Co Ltd` against `LEAP LABCHEM CO.,LTD.`
  These are what the checks exist to find.
- **Some portal columns are cut off** in the screenshots the sample data was
  transcribed from. Where the legible part agrees with IDPMS the check passes
  and says so; where a column is not visible at all the check reports that there
  is nothing to compare. Neither is reported as a mismatch.
- **Live credentials for Vertex.** The WIF path is built and configurable but
  has not been exercised against a real project; the agent was tested on the
  `claude` CLI backend.
