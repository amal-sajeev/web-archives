"""Screenshot the running demo with headless Chrome.

    python tools/shoot.py                     every screen, both views
    python tools/shoot.py /network?v=desk     one page
    python tools/shoot.py --dir shots --wide  where to put them, how wide

No dependency beyond a Chrome that is already installed: it writes a PNG
straight from the command line. This exists because a house style cannot be
reviewed by reading its stylesheet - the contrast failures and the collided
labels on this project were all found by looking at a picture of the page,
and none of them by reading the CSS that caused them.
"""

from __future__ import annotations

import argparse
import pathlib
import shutil
import subprocess
import sys

CHROME = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "google-chrome", "chromium", "chromium-browser",
]

PAGES = [
    ("queue", "/"), ("done", "/done"), ("map", "/network?view=map"),
    ("columns", "/network?view=flow"), ("ports", "/ports"),
    ("tariffs", "/tariffs"), ("rules", "/rules"),
]


def browser() -> str | None:
    for candidate in CHROME:
        if pathlib.Path(candidate).exists():
            return candidate
        found = shutil.which(candidate)
        if found:
            return found
    return None


def shoot(exe: str, url: str, out: pathlib.Path, w: int, h: int) -> bool:
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    subprocess.run(
        [exe, "--headless=new", "--disable-gpu", "--hide-scrollbars",
         "--no-first-run", "--force-device-scale-factor=1",
         f"--window-size={w},{h}", "--virtual-time-budget=6000",
         f"--screenshot={out}", url],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    return out.exists()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="?", help="one page, e.g. /network?v=desk")
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    ap.add_argument("--dir", default="shots")
    ap.add_argument("--wide", type=int, default=1560)
    ap.add_argument("--tall", type=int, default=1200)
    args = ap.parse_args()

    exe = browser()
    if not exe:
        print("No Chrome or Edge found. Tried:\n  " + "\n  ".join(CHROME))
        return 1

    out = pathlib.Path(args.dir)
    jobs = ([("page", args.path)] if args.path else
            [(f"{name}-{view}", f"{path}{'&' if '?' in path else '?'}v={view}")
             for name, path in PAGES for view in ("corp", "desk")])

    ok = 0
    for name, path in jobs:
        target = out / f"{name}.png"
        if shoot(exe, args.base + path, target, args.wide, args.tall):
            print(f"  {target}  {target.stat().st_size:,} bytes")
            ok += 1
        else:
            print(f"  {name}: FAILED  ({args.base}{path})")
    print(f"\n{ok} of {len(jobs)} written. Is the demo running on {args.base}?"
          if ok < len(jobs) else f"\n{ok} screens written to {out}/")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
