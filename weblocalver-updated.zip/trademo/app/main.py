"""Trade Collections — Maker Workbench.

Run with:  uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

import inspect
from pathlib import Path
from urllib.parse import quote_plus
from collections import defaultdict

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .api import router as api_router
from .models import CaseStatus
from .sources.router import router as mock_router
from .store import VIEWS, CaseStore, get_store
from .text import is_are, n

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title="Trade Collections — Maker Workbench",
    description="Import collections from IDPMS and TradePay, checked, priced and "
                "posted to TF3. External systems are mocked under /api/mock.",
    version="3.0.0",
)
app.include_router(api_router)
app.include_router(mock_router)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
# "1 invoice line", not "1 invoice line(s)". See app/text.py.
templates.env.globals["n"] = n
from .network import fmt_inr as _fmt_inr
templates.env.globals["inr"] = _fmt_inr

THEMES = {"desk", "corp"}
DEFAULT_THEME = "corp"

# Only dimensions the supplied data actually carries.
SORT_LABELS = {
    "boe_date":    "Bill of Entry date",
    "shipment":    "Shipment date",
    "amount":      "Invoice value",
    "charges":     "Charges",
    "outstanding": "Things outstanding",
    "checks":      "Checks passed",
    "importer":    "Importer",
    "supplier":    "Supplier",
    "invoices":    "Invoice lines",
    "currency":    "Currency",
    "port":        "Port of discharge",
    "boe":         "Bill of Entry",
    "status":      "Status",
}

DESK_SORTS = ["boe_date", "amount", "outstanding", "importer", "charges", "shipment"]


def pick_theme(request: Request, v: str | None) -> str:
    if v in THEMES:
        return v
    cookie = request.cookies.get("view")
    return cookie if cookie in THEMES else DEFAULT_THEME


_TEMPLATE_WANTS_REQUEST = "request" in inspect.signature(
    Jinja2Templates.TemplateResponse).parameters


def render(theme: str, name: str, ctx: dict) -> HTMLResponse:
    path = f"{theme}/{name}"
    if _TEMPLATE_WANTS_REQUEST:
        response = templates.TemplateResponse(request=ctx["request"], name=path, context=ctx)
    else:
        response = templates.TemplateResponse(path, ctx)
    response.set_cookie("view", theme, max_age=60 * 60 * 24 * 30, samesite="lax")
    return response


def _qs(q: str | None, path: str, filters: dict | None) -> str:
    parts = [f"q={quote_plus(q or '')}"]
    for key, val in (filters or {}).items():
        if val and val != "all":
            parts.append(f"{key}={quote_plus(val)}")
    return f"{path}?" + "&".join(parts)



def _tf3_groups(cases: list) -> list[dict]:
    """Collapse case/BOE records into the TF3 payment hierarchy for the dashboard."""
    buckets: dict[str, list] = defaultdict(list)
    for case in cases:
        ref = case.tf3_reference or (case.tradepay or {}).get("tf3Reference")
        key = ref or f"PENDING:{case.importer}:{case.bill_of_entry}"
        buckets[key].append(case)

    groups: list[dict] = []
    for key, members in buckets.items():
        ref = None if key.startswith("PENDING:") else key
        importers = list(dict.fromkeys(c.importer for c in members if c.importer))
        suppliers = list(dict.fromkeys(c.supplier for c in members if c.supplier and c.supplier != "—"))
        invoices = []
        transaction_charges = 0.0
        invoice_charges = 0.0
        tf3_charges_by_code: dict[str, dict] = {}
        for case in members:
            invoice_count = max(len(case.invoice_lines), 1)
            per_invoice = sum(l.amount_inr for l in case.charges.lines if l.level == "invoice")
            per_transaction = sum(l.amount_inr for l in case.charges.lines if l.level == "transaction")
            invoice_charges += per_invoice
            transaction_charges += per_transaction
            for line in case.charges.lines:
                if line.level == "tf3":
                    # A remittance-level charge is charged once for the TF3, even
                    # when its TradePay rows span several BOEs.
                    tf3_charges_by_code.setdefault(line.code, {
                        "code": line.code, "label": line.label, "amount": line.amount_inr,
                        "basis": line.basis})
            for idx, line in enumerate(case.invoice_lines):
                invoice_charge = per_invoice / invoice_count if invoice_count else 0.0
                transaction_charge = per_transaction if idx == 0 else 0.0
                invoices.append({
                    "case_id": case.case_id,
                    "boe": case.bill_of_entry,
                    "boe_date": case.bill_of_entry_date,
                    "invoice": line.invoice_no or "—",
                    "invoice_date": line.invoice_date,
                    "supplier": line.supplier_name or case.supplier,
                    "amount": line.amount or 0.0,
                    "currency": line.currency or "",
                    "ports": case.ports,
                    "status": case.status_label,
                    "status_tone": case.status_tone,
                    "checks": f"{case.checks_passed}/{case.checks_total}" if case.checks_total else "—",
                    "invoice_charge": round(invoice_charge, 2),
                    "transaction_charge": round(transaction_charge, 2),
                    "charge_level": case.charges.display_level,
                    "case": case,
                })

        tf3_charge_total = sum(x["amount"] for x in tf3_charges_by_code.values())
        total_charges = round(invoice_charges + transaction_charges + tf3_charge_total, 2)
        levels = set()
        for c in members:
            levels.update(c.charges.display_levels)
        charge_levels = [x for x in ("tf3", "transaction", "invoice") if x in levels]
        groups.append({
            "reference": ref or "TF3 pending",
            "reference_missing": ref is None,
            "importer": ", ".join(importers) or "—",
            "supplier": ", ".join(suppliers) or "—",
            "boe_count": len({c.bill_of_entry for c in members}),
            "invoice_count": len(invoices),
            "amount": round(sum(i["amount"] for i in invoices), 2),
            "currencies": list(dict.fromkeys(i["currency"] for i in invoices if i["currency"])),
            "charges": total_charges,
            "invoice_charges": round(invoice_charges, 2),
            "transaction_charges": round(transaction_charges, 2),
            "tf3_charges": round(tf3_charge_total, 2),
            "charge_levels": charge_levels,
            "tf3_charge_lines": list(tf3_charges_by_code.values()),
            "invoices": invoices,
            "cases": members,
            "needs_attention": any(c.needs_maker for c in members),
            "status": "Needs attention" if any(c.needs_maker for c in members) else
                      ("With checker" if any(c.status is CaseStatus.IN_CHECKER_QUEUE for c in members) else
                       "Ready for review" if any(c.status is CaseStatus.READY_FOR_REVIEW for c in members) else
                       "Running" if any(c.status in (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING) for c in members) else
                       "Posted" if all(c.status is CaseStatus.COMPLETED for c in members) else "Open"),
        })
    groups.sort(key=lambda g: g["reference"])
    return groups

def _shell(request: Request, store: CaseStore, active: str, theme: str) -> dict:
    cases = store.all_cases()
    checker = store.session.role == "Checker"
    todo = (sum(1 for c in cases if c.status is CaseStatus.IN_CHECKER_QUEUE) if checker
            else sum(1 for c in cases if c.needs_maker))
    return {"request": request, "session": store.session, "active": active,
            "theme": theme, "counts": {"todo": todo}}


def _groups(store: CaseStore, q: str | None, sort: str | None,
            direction: str, filters: dict) -> tuple[list, list, list, list]:
    """todo, ready, held (waiting on a source), waiting (not yet run).

    Every open case must land in exactly one of these. A case that matches none
    of them disappears from the worklist, which is worse than showing it in the
    wrong place.
    """
    kw = {"search": q, **{k: v for k, v in filters.items() if v and v != "all"}}
    if sort:
        kw |= {"sort": sort, "direction": direction}
    if store.session.role == "Checker":
        return store.list_cases(view="checker", **kw), [], [], []
    rows = store.list_cases(view="all", **kw)
    running = (CaseStatus.RECEIVED, CaseStatus.AI_PROCESSING)
    todo, ready, held, waiting = [], [], [], []
    for c in rows:
        if c.status in running:
            waiting.append(c)
        elif c.needs_maker or c.status is CaseStatus.RETURNED:
            todo.append(c)
        elif c.waiting_on_source:
            held.append(c)
        else:
            ready.append(c)
    return todo, ready, held, waiting


@app.get("/", response_class=HTMLResponse)
def queue(request: Request, q: str | None = None, v: str | None = None,
          sort: str | None = None, direction: str = "asc",
          importer: str = "all", currency: str = "all", status: str = "all",
          store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    if sort not in SORT_LABELS:
        sort = None
    direction = "desc" if direction == "desc" else "asc"
    filters = {"importer": importer, "currency": currency, "status": status}
    todo, ready, held, waiting = _groups(store, q, sort, direction, filters)
    checker = store.session.role == "Checker"
    total = len(todo) + len(ready) + len(held)

    if checker:
        greeting = f"{len(todo)} to check" if todo else "Nothing to check yet"
        if todo:
            summary = ("Each has been validated by a maker and is waiting on your "
                       "control. Approve it, or send it back with a reason.")
        else:
            # NB: not `ready` — that name holds the ready list from _groups.
            awaiting_maker = sum(
                1 for c in store.all_cases()
                if c.status is CaseStatus.READY_FOR_REVIEW and not c.needs_maker)
            summary = ("A case reaches you once a maker has validated it — the "
                       "second pair of eyes is the point, so you cannot check your "
                       "own work."
                       + (f" {n(awaiting_maker, 'case')} "
                          f"{is_are(awaiting_maker)} ready for a maker to "
                          "validate now." if awaiting_maker else ""))
    elif total:
        greeting = f"{total} collections open"
        parts = []
        if todo:
            parts.append(f"{len(todo)} need a decision")
        if ready:
            parts.append(f"{len(ready)} ready to post")
        if held:
            parts.append(f"{len(held)} waiting on a source")
        summary = (", ".join(parts[:-1]) + (" and " if len(parts) > 1 else "")
                   + parts[-1] + ".").capitalize()
    else:
        greeting = "Queue is clear"
        summary = "No open collections."

    ctx = _shell(request, store, "queue", theme)
    ctx.update({
        "todo": todo, "ready": ready, "held": held, "waiting": waiting,
        "q": q or "", "greeting": greeting, "summary": summary,
        "progress": {c.case_id: store.progress(c) for c in waiting},
        "sort": sort, "direction": direction, "sort_labels": SORT_LABELS,
        "desk_sorts": DESK_SORTS, "filters": filters,
        "filtered": any(x != "all" for x in filters.values()),
        "base_qs": _qs(q, "/", filters),
        "importers": store.importers(), "currencies": store.currencies(),
        "rows": (store.list_cases(view="checker" if checker else "all", search=q,
                                  sort=sort, direction=direction,
                                  **{k: val for k, val in filters.items() if val != "all"})
                 if sort else todo + ready + held + waiting),
        "todo_groups": _tf3_groups(todo),
        "ready_groups": _tf3_groups(ready),
        "held_groups": _tf3_groups(held),
        "waiting_groups": _tf3_groups(waiting),
    })
    return render(theme, "queue.html", ctx)


@app.get("/done", response_class=HTMLResponse)
def done(request: Request, q: str | None = None, v: str | None = None,
         sort: str | None = None, direction: str = "asc",
         store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    if sort not in SORT_LABELS:
        sort = None
    direction = "desc" if direction == "desc" else "asc"
    kw = {"search": q} | ({"sort": sort, "direction": direction} if sort else {})
    posted = store.list_cases(view="completed", **kw)
    sent = store.list_cases(view="checker", **kw)
    ctx = _shell(request, store, "done", theme)
    ctx.update({
        "todo": [], "ready": sent, "held": [], "waiting": posted, "q": q or "",
        "greeting": "Finished",
        "summary": f"{len(sent)} with the checker, {len(posted)} posted to TF3.",
        "progress": {}, "sort": sort, "direction": direction,
        "sort_labels": SORT_LABELS, "desk_sorts": DESK_SORTS,
        "filters": {"importer": "all", "currency": "all", "status": "all"},
        "filtered": False, "base_qs": _qs(q, "/done", None),
        "importers": store.importers(), "currencies": store.currencies(),
        "rows": sent + posted,
        "todo_groups": [], "ready_groups": _tf3_groups(sent),
        "held_groups": [], "waiting_groups": _tf3_groups(posted),
    })
    return render(theme, "queue.html", ctx)


@app.get("/cases/{case_id}", response_class=HTMLResponse)
def case_detail(request: Request, case_id: str, v: str | None = None,
                store: CaseStore = Depends(get_store)) -> HTMLResponse:
    theme = pick_theme(request, v)
    case = store.get(case_id)
    if case is None:
        raise HTTPException(404, f"Case {case_id} not found")
    todo, ready, held, _ = _groups(store, None, None, "asc",
                                   {"importer": "all", "currency": "all",
                                    "status": "all"})
    queue = [c for c in todo + ready + held if c.case_id != case.case_id]
    ctx = _shell(request, store, "queue", theme)
    ctx["case"] = case
    ctx["next_case"] = queue[0] if queue else None
    return render(theme, "case.html", ctx)


@app.get("/cases/{case_id}/runlog", response_class=HTMLResponse)
def case_runlog(request: Request, case_id: str, v: str | None = None,
                store: CaseStore = Depends(get_store)) -> HTMLResponse:
    """Just the run panel.

    The case page asks for this every second while a run is in flight, so the
    panel is drawn by the same template whether it arrives with the page or
    arrives on its own. One renderer, no second copy of the markup in JS.
    """
    case = store.get(case_id)
    if case is None:
        raise HTTPException(404, f"Case {case_id} not found")
    theme = pick_theme(request, v)
    return render(theme, "partials/_runlog.html",
                  {"request": request, "case": case})


# --------------------------------------------------------------- reference

@app.get("/network", response_class=HTMLResponse)
def network_page(request: Request, v: str | None = None, view: str = "",
                 only: str = "", country: str = "", importer: str = "",
                 q: str = "", currency: str = "", port: str = "",
                 band: str = "",
                 store: CaseStore = Depends(get_store)) -> HTMLResponse:
    """The whole book as one picture: counterparties, importers, transactions.

    The layout and the findings are worked out in ``app/network.py`` and sent
    as coordinates, so the page needs no script to draw itself. Narrowing is a
    query string rather than client state, because a large book is read by
    narrowing it and a link to a narrowed map should be a link somebody can
    send.
    """
    from . import network
    theme = pick_theme(request, v)
    ctx = _shell(request, store, "network", theme)
    ctx["graph"] = network.build(store.all_cases(), view=view, only=only,
                                 country=country, importer=importer, q=q,
                                 currency=currency, port=port, band=band)
    return render(theme, "network.html", ctx)


@app.get("/ports", response_class=HTMLResponse)
def ports_page(request: Request, q: str = "", v: str | None = None,
               store: CaseStore = Depends(get_store)) -> HTMLResponse:
    from .sources import ports as port_src
    theme = pick_theme(request, v)
    state = port_src.status()
    rows = [p for p in state["codesSeenInData"]
            if not q or q.lower() in p["code"].lower()]
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "ports", "title": "Port directory", "rows": rows, "q": q,
                "port_state": state,
                "blurb": "Transport documents carry a short code; TF3 needs the full "
                         "name. A five-digit code is searched as it stands, a "
                         "three-digit code with its country prefix."})
    return render(theme, "reference.html", ctx)


@app.get("/tariffs", response_class=HTMLResponse)
def tariffs_page(request: Request, v: str | None = None,
                 store: CaseStore = Depends(get_store)) -> HTMLResponse:
    from .agent import provider_status
    from .sources import autobahn
    theme = pick_theme(request, v)
    providers = provider_status()
    live = next((p for p in providers if p["available"]), None)
    coverage = autobahn.coverage(sorted({c.importer for c in store.all_cases()}))
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "tariffs", "title": "Client pricing", "q": "",
                "rows": autobahn.clients(),
                "providers": providers, "live": live, "coverage": coverage,
                "blurb": "The free-format processing text held against each client in "
                         "Autobahn. The pricing agent reads this, and its reasoning "
                         "opens from the charges card on a case."})
    return render(theme, "reference.html", ctx)


@app.get("/rules", response_class=HTMLResponse)
def rules_page(request: Request, v: str | None = None,
               store: CaseStore = Depends(get_store)) -> HTMLResponse:
    from .sources import fallback
    from .sources._data import load
    theme = pick_theme(request, v)
    data = load("checks")
    ctx = _shell(request, store, "ref", theme)
    ctx.update({"kind": "rules", "title": "Checks and procedure", "q": "",
                "rows": data["checks"], "procedure": data,
                "cascade": fallback.status(),
                "blurb": "The consistency checks between IDPMS and TradePay, and the "
                         "procedure they sit in, as specified."})
    return render(theme, "reference.html", ctx)
