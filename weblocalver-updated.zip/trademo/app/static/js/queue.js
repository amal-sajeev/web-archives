/* Queue: type to filter, and keep the processing rows moving. */

(function () {
  "use strict";
  const { api } = window.App;

  const q = document.getElementById("q");

  /* The corporate toolbar is a real form and submits natively, carrying its
     own filters and sort. Only the desk view needs the JS redirect. */
  if (q && !q.closest("form")) {
    let t;
    q.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(() => {
        // build from the current URL so the page you are on and any sort survive
        const url = new URL(location.href);
        const v = q.value.trim();
        if (v) url.searchParams.set("q", v);
        else url.searchParams.delete("q");
        location.href = url.toString();
      }, 420);
    });
    // carry the caret on only when the page came back from a search
    if (q.value) {
      q.focus();
      q.setSelectionRange(q.value.length, q.value.length);
    }
  }

  // Only poll while something is actually in flight.
  if (document.querySelector(".gauge")) {
    setInterval(async () => {
      try {
        const data = await api("GET", "/api/cases/live");
        let finished = false;
        data.cases.forEach(c => {
          const row = document.querySelector('a[href="/cases/' + c.case_id + '"] .gauge i')
                   || document.querySelector('[data-case-row="' + c.case_id + '"] .gauge i');
          if (!row) return;
          if (c.status === "ai_processing") row.style.width = c.progress + "%";
          else finished = true;
        });
        if (finished) location.reload();
      } catch (_) { /* transient */ }
    }, 2500);
  }
})();
