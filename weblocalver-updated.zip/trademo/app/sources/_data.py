"""Loading the JSON that stands in for the external systems.

Everything is read once and cached. ``reload()`` drops the cache, which is what
lets you edit a file — dropping in the real port directory, say — and see the
effect without restarting.
"""

from __future__ import annotations

import json
import pathlib
import threading

DATA = pathlib.Path(__file__).resolve().parent.parent / "data"

_cache: dict[str, dict] = {}
_lock = threading.RLock()


def load(name: str) -> dict:
    """Read app/data/<name>.json, cached."""
    with _lock:
        if name not in _cache:
            path = DATA / f"{name}.json"
            if not path.exists():
                raise FileNotFoundError(
                    f"{path} is missing. Run: python tools/build_mock_data.py")
            _cache[name] = json.loads(path.read_text(encoding="utf-8"))
        return _cache[name]


def reload(name: str | None = None) -> None:
    with _lock:
        if name is None:
            _cache.clear()
        else:
            _cache.pop(name, None)


def records(name: str) -> list[dict]:
    return load(name).get("records", [])


# --- comparison helpers the checks and the matching both need ---------------

_NOISE = {
    "pvt", "private", "ltd", "limited", "inc", "co", "company", "corp",
    "corporation", "gmbh", "ag", "sa", "nv", "bv", "plc", "llc", "lp",
    "pte", "sdn", "bhd", "kg", "spa", "srl", "oy", "ab", "as",
}


def normalise_name(value: str | None) -> str:
    """Company names rarely match character for character across systems.

    'TWINTECH(S) PTE LTD' and 'TWINTECH S PTE LTD' are the same counterparty;
    so are 'BOSCH REXROTH (INDIA) PRIVATE LIMITED' and 'BOSCH REXROTH INDIA
    PVT LTD'. Strip punctuation and the legal-form words, then compare.
    """
    if not value:
        return ""
    cleaned = "".join(ch if ch.isalnum() else " " for ch in str(value).upper())
    words = [w for w in cleaned.split() if w and w.lower() not in _NOISE]
    return " ".join(words)


# The two systems name the same country differently. These are the same place;
# Hong Kong is deliberately NOT folded into China, because the two are separate
# jurisdictions for FEMA purposes and a difference between them is real.
_COUNTRY_ALIASES = {
    "PEOPLES REP OF CHINA": "CHINA",
    "PEOPLE S REP OF CHINA": "CHINA",
    "PEOPLES REPUBLIC OF CHINA": "CHINA",
    "P R CHINA": "CHINA",
    "PRC": "CHINA",
    "CHINA PEOPLES REPUBLIC": "CHINA",
    "UNITED STATES OF AMERICA": "UNITED STATES",
    "USA": "UNITED STATES",
    "US": "UNITED STATES",
    "UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND": "UNITED KINGDOM",
    "UK": "UNITED KINGDOM",
    "REPUBLIC OF SINGAPORE": "SINGAPORE",
    "FEDERAL REPUBLIC OF GERMANY": "GERMANY",
    "KINGDOM OF THAILAND": "THAILAND",
    "HONG KONG SAR": "HONG KONG",
    "HONGKONG": "HONG KONG",
}


def normalise_country(value: str | None) -> str:
    """One spelling per country, so 'PEOPLES REP OF CHINA' matches 'CHINA'."""
    if not value:
        return ""
    cleaned = "".join(ch if ch.isalnum() else " " for ch in str(value).upper())
    cleaned = " ".join(cleaned.split())
    return _COUNTRY_ALIASES.get(cleaned, cleaned)


def longest_common_run(a: str, b: str) -> int:
    """The longest run of characters the two strings share.

    Used to judge a value that is cut off in a source screenshot: if a long
    enough stretch of what is legible appears in the reference, the two agree
    as far as anyone can tell.
    """
    if not a or not b:
        return 0
    prev = [0] * (len(b) + 1)
    best = 0
    for i in range(1, len(a) + 1):
        cur = [0] * (len(b) + 1)
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                cur[j] = prev[j - 1] + 1
                if cur[j] > best:
                    best = cur[j]
        prev = cur
    return best


def normalise_ref(value: str | None) -> str:
    """Invoice numbers differ only by punctuation across systems.

    IDPMS carries 'INV2606/12999' where TradePay shows 'INV260612999'.
    """
    if not value:
        return ""
    return "".join(ch for ch in str(value).upper() if ch.isalnum())
