"""TF3 — the trade processing system.

Stands in for the system the validated record is finally posted to. There is no
API yet, so postings are held in memory and can be read back; swapping this for
the real call is a change to one function.

What gets posted is what the procedure names: the resolved ports, the third
party details, and the charges, against the Bill of Entry.
"""

from __future__ import annotations

import threading
from datetime import datetime

_lock = threading.RLock()
_posted: dict[str, dict] = {}
_seq = 0


def post(payload: dict) -> dict:
    """Post one BOE/invoice transaction under its TF3 payment reference."""
    global _seq
    required = ("billOfEntryNumber", "importer", "portOfLoading", "portOfDischarge")
    missing = [f for f in required if not payload.get(f)]
    if missing:
        return {"accepted": False,
                "message": "TF3 rejected the posting; these are required: "
                           + ", ".join(missing)}

    with _lock:
        requested = str(payload.get("tf3Reference") or "").strip() or None
        reference = requested
        if not reference:
            _seq += 1
            reference = f"TF3-{datetime.now():%Y}-{_seq:05d}"

        transaction = {
            "billOfEntryNumber": payload["billOfEntryNumber"],
            "billOfEntryDate": payload.get("billOfEntryDate"),
            "importer": payload.get("importer"),
            "importerCode": payload.get("importerCode"),
            "adCode": payload.get("adCode"),
            "portOfLoading": payload.get("portOfLoading"),
            "portOfLoadingCode": payload.get("portOfLoadingCode"),
            "portOfDischarge": payload.get("portOfDischarge"),
            "portOfDischargeCode": payload.get("portOfDischargeCode"),
            "thirdParties": payload.get("thirdParties", []),
            "invoices": payload.get("invoices", []),
            "charges": payload.get("charges", {"totalInr": 0.0, "lines": []}),
            "approvedBy": payload.get("approvedBy"),
            "postedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        existing = _posted.get(reference)
        if existing:
            existing.setdefault("transactions", []).append(transaction)
            existing["invoices"] = [
                invoice for tx in existing["transactions"] for invoice in tx.get("invoices", [])
            ]
            # Keep TF3's gross charge as the sum of its underlying transactions.
            existing["charges"] = {
                "totalInr": round(sum(float(tx.get("charges", {}).get("totalInr") or 0)
                                      for tx in existing["transactions"]), 2),
                "lines": [line for tx in existing["transactions"]
                          for line in tx.get("charges", {}).get("lines", [])],
            }
            existing["postedAt"] = transaction["postedAt"]
            existing["approvedBy"] = payload.get("approvedBy")
            message = (f"Added Bill of Entry {payload['billOfEntryNumber']} to "
                       f"TF3 {reference}.")
            return {"accepted": True, "tf3Reference": reference,
                    "message": message, "record": existing}

        record = {
            "tf3Reference": reference,
            "postedAt": transaction["postedAt"],
            "transactions": [transaction],
            "invoices": list(transaction["invoices"]),
            "charges": transaction["charges"],
            "importer": transaction["importer"],
            "approvedBy": transaction["approvedBy"],
        }
        _posted[reference] = record

    return {"accepted": True, "tf3Reference": reference,
            "message": f"Filed Bill of Entry {payload['billOfEntryNumber']} under TF3 {reference}.",
            "record": record}


def get(reference: str) -> dict | None:
    return _posted.get(reference)


def all_postings() -> list[dict]:
    with _lock:
        return sorted(_posted.values(), key=lambda r: r["postedAt"], reverse=True)


def reset() -> None:
    """Clear the postings. Used when the demo is restarted."""
    global _seq
    with _lock:
        _posted.clear()
        _seq = 0
