"""The small words the screens get wrong if nobody owns them.

A maker reads "1 check outstanding", not "1 check(s) outstanding". The bracketed
plural is log-file English and it is the first thing anyone notices on a screen
that is otherwise careful about its wording, so counting and pluralising belongs
in one place that both the Python and the templates call.
"""

from __future__ import annotations


def n(count: int, thing: str, plural: str | None = None) -> str:
    """"1 check", "3 checks" — a count and its noun, agreeing."""
    return f"{count} {thing if count == 1 else (plural or thing + 's')}"


def s(count: int, singular: str = "", plural: str = "s") -> str:
    """The suffix alone, for a noun already written out."""
    return singular if count == 1 else plural


def were(count: int) -> str:
    return "was" if count == 1 else "were"


def is_are(count: int) -> str:
    return "is" if count == 1 else "are"


def has_have(count: int) -> str:
    return "has" if count == 1 else "have"


def listed(items: list, limit: int = 4, more: str = "others") -> str:
    """"A", "A and B", "A, B and C", "A, B, C, D and 3 others".

    A maker reads these aloud down the phone, so the last comma becomes "and"
    and a long tail is counted rather than spelled out.
    """
    parts = [str(i) for i in items if i is not None and str(i) != ""]
    if not parts:
        return ""
    if len(parts) > limit:
        head, rest = parts[:limit], len(parts) - limit
        return ", ".join(head) + f" and {rest} {more if rest != 1 else more.rstrip('s')}"
    if len(parts) == 1:
        return parts[0]
    return ", ".join(parts[:-1]) + " and " + parts[-1]
